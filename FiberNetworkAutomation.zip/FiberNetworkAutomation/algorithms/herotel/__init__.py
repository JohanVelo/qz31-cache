# HeroTel Group C Algorithms — Network Design (TSD standard)
