# -*- coding: utf-8 -*-
# Build the HLD map-book layouts INSIDE the live QGIS project so JJ can tweak them
# by hand in the Print Layout designer and export the PDF himself (his usual way of
# getting a nice PDF). This is the interactive counterpart to the headless one-shot
# generator (hld_generate.py) — same engine, same config, but run on the GUI thread
# against QgsProject.instance() and then the designer is opened.
#
# SAFE on the GUI thread: the engine only *builds* layout items (fast) and freezes
# the canvas while it does; the heavy N-page render happens later, when JJ hits
# Export in the designer — never here.
import os
import traceback


def _layer_source_path(layer):
    try:
        return os.path.normpath(layer.source().split("|")[0])
    except Exception:
        return ""


def _add_missing_extras(project, extra_layers):
    """Load framing helpers (e.g. the greenfield boundary) if not already present,
    mirroring the headless generator so the overview frames identically."""
    from qgis.core import QgsVectorLayer, QgsFillSymbol
    have = {_layer_source_path(l) for l in project.mapLayers().values()
            if isinstance(l, QgsVectorLayer)}
    for el in (extra_layers or []):
        src = el.get("path")
        if not src or not os.path.exists(src):
            continue
        if os.path.normpath(src) in have:
            continue
        vl = QgsVectorLayer(src, el.get("name", os.path.basename(src)), "ogr")
        if not vl.isValid():
            continue
        if el.get("fill"):
            try:
                vl.renderer().setSymbol(QgsFillSymbol.createSimple(el["fill"]))
            except Exception:
                pass
        project.addMapLayer(vl, el.get("add_to_tree", True))


def _downloads_dir():
    d = os.path.join(os.path.expanduser("~"), "Downloads")
    return d if os.path.isdir(d) else os.path.expanduser("~")


def _relock_frame(layout):
    """QGIS4's atlas preview / page-flip grows the map-frame ITEM to the current feature's
    aspect; force every map item back to its engine-designed page geometry (stashed as custom
    properties). Called right before export so exported pages never clip — this also makes the
    headless export path safe (the old one-shot clipped precisely because it never relocked)."""
    from qgis.core import QgsLayoutItemMap, QgsLayoutPoint, QgsLayoutSize, QgsUnitTypes
    MM = QgsUnitTypes.LayoutUnit.LayoutMillimeters
    for it in layout.items():
        if isinstance(it, QgsLayoutItemMap):
            w = it.customProperty("hld_frame_w"); h = it.customProperty("hld_frame_h")
            x = it.customProperty("hld_frame_x"); y = it.customProperty("hld_frame_y")
            if w and h:
                if x is not None and y is not None:
                    it.attemptMove(QgsLayoutPoint(float(x), float(y), MM))
                it.attemptResize(QgsLayoutSize(float(w), float(h), MM))


def _safe_unlink(pth):
    try:
        if pth and os.path.exists(pth):
            os.remove(pth)
    except Exception:
        pass


def _count_pdf_pages(pdf_path):
    """Best-effort PDF page count from the file bytes (no Ghostscript dependency). -1 on error."""
    import re
    try:
        with open(pdf_path, "rb") as f:
            data = f.read()
    except Exception:
        return -1
    counts = [int(m) for m in re.findall(rb"/Type\s*/Pages\b[^>]*?/Count\s+(\d+)", data)]
    if not counts:
        counts = [int(m) for m in re.findall(rb"/Count\s+(\d+)[^>]*?/Type\s*/Pages\b", data)]
    if counts:
        return max(counts)
    return len(re.findall(rb"/Type\s*/Page(?![s])", data))


MIN_PDF_MB = 0.3


def _write_atlas_pdf(layout, path, cov=None, eff=None, dpi=300, qa=None):
    """Gated export core (no UI): relock frame → hard QA gate → export to a STAGED temp →
    verify page count + size → bookmarks → atomic replace onto `path`. A broken layout or a
    short/partial PDF NEVER lands at the deliverable path. Returns (ok, message). Testable
    headlessly. `qa` is the engine's `_layout_qa` callable (returns (hard[], soft[]))."""
    from qgis.core import QgsLayoutExporter, QgsProject
    if not path.lower().endswith(".pdf"):
        path += ".pdf"
    # 1. Re-lock the map frame to its designed size — the designer's atlas preview (or a prior
    #    page-flip) can grow the frame item and clip the exported pages.
    try:
        _relock_frame(layout)
        layout.refresh()
    except Exception as e:
        print("HLD export: frame relock skipped:", e)
    # 2. Hard QA gate (frame-agnostic; HLD / commercial / wayleave) — a broken page can't ship.
    if callable(qa):
        try:
            hard, soft = qa(layout)
            for s in (soft or []):
                print("HLD QA warn:", s)
            if hard:
                return (False, "Layout QA blocked the export: " + "; ".join(list(hard)[:3]))
        except Exception as e:
            print("HLD export: QA gate skipped (fail-open):", e)
    # 3. Export to a STAGED file (never straight onto the deliverable path).
    staged = path + ".stage.tmp.pdf"
    settings = QgsLayoutExporter.PdfExportSettings()
    settings.dpi = int(dpi)
    res = QgsLayoutExporter(layout).exportToPdf(layout.atlas(), staged, settings)
    code = res[0] if isinstance(res, tuple) else res
    if int(code) != 0:
        _safe_unlink(staged)
        return (False, f"QGIS could not write the PDF (code {code}).")
    # 4. Verify page count (overview + one per coverage feature) + size.
    try:
        n_expected = 1 + (cov.featureCount() if cov else 0)
    except Exception:
        n_expected = None
    pages = _count_pdf_pages(staged)
    if n_expected is not None and pages >= 0 and pages != n_expected:
        _safe_unlink(staged)
        return (False, f"page count {pages} ≠ expected {n_expected} — export incomplete.")
    try:
        if os.path.getsize(staged) < MIN_PDF_MB * 1024 * 1024:
            _safe_unlink(staged)
            return (False, "exported PDF is too small — the render likely failed.")
    except Exception:
        pass
    # 5. Navigable bookmarks (Overview · Zone/PON 1…N) on the staged file — never blocks.
    try:
        from . import hld_generate as HG
        base = (eff or {}).get("project_name") or os.path.splitext(os.path.basename(path))[0]
        labels = HG._book_page_labels(QgsProject.instance(), cov, eff or {}, True)
        meta = {"/Title": base,
                "/Author": (eff or {}).get("designer") or (eff or {}).get("company") or "Velocity Fibre",
                "/Subject": "HLD Network Atlas", "/Creator": "Velocity Nexus"}
        HG._add_bookmarks(staged, labels, meta)
    except Exception as e:
        print("HLD export: bookmarks skipped:", e)
    # 6. Atomic replace — only a verified PDF reaches the deliverable path.
    try:
        os.replace(staged, path)
    except Exception as e:
        _safe_unlink(staged)
        return (False, f"could not finalise the PDF: {e}")
    return (True, path)


def _export_atlas_pdf(layout, parent, cov=None, eff=None, qa=None):
    """UI wrapper: Save-As dialog -> gated _write_atlas_pdf -> open the result."""
    from qgis.PyQt.QtWidgets import QFileDialog, QMessageBox
    base = (layout.name() or "HLD").replace("/", "-").replace("\\", "-")
    path, _sel = QFileDialog.getSaveFileName(
        parent, "Export Atlas as PDF", os.path.join(_downloads_dir(), base + ".pdf"),
        "PDF files (*.pdf)")
    if not path:
        return
    try:
        ok, msg = _write_atlas_pdf(layout, path, cov, eff, qa=qa)
    except Exception as e:
        QMessageBox.critical(parent, "Export error", str(e)); return
    if not ok:
        QMessageBox.warning(parent, "Export failed", msg); return
    try:
        os.startfile(msg)   # noqa: S606 - open the exact PDF just written
    except Exception:
        pass
    try:
        from qgis.utils import iface
        iface.messageBar().pushSuccess("HLD Export", f"✅ Atlas PDF saved: {msg}")
    except Exception:
        pass


def _add_export_button(designer, layout, cov=None, eff=None, qa=None):
    """Add a big, unmissable green “📄 Export Atlas as PDF” button to the designer's toolbar.
    QGIS's own atlas-export action is buried in a dropdown, so operators miss it — this makes
    the one thing they need to click when they're happy obvious."""
    try:
        from qgis.PyQt.QtWidgets import QToolBar
        from qgis.PyQt.QtGui import QAction
        from qgis.PyQt.QtCore import Qt
        win = designer.window() if hasattr(designer, "window") else None
        if win is None:
            return
        if win.findChild(QToolBar, "vfExportToolbar") is not None:
            return                                        # already added — don't duplicate
        tb = QToolBar("Export HLD", win)
        tb.setObjectName("vfExportToolbar")
        act = QAction("📄  Export Atlas as PDF", win)
        act.setObjectName("vfExportAtlasPdf")
        act.setToolTip("Save the whole map book to a PDF (all pages) — click when you're happy.")
        act.triggered.connect(
            lambda _=False, ly=layout, w=win: _export_atlas_pdf(ly, w, cov, eff, qa))
        tb.addAction(act)
        win.addToolBar(Qt.ToolBarArea.TopToolBarArea, tb)
        try:
            tb.setStyleSheet(
                "QToolBar#vfExportToolbar{background:#0f9d58;border:0;padding:2px;spacing:0;}"
                "QToolBar#vfExportToolbar QToolButton{color:white;font-weight:bold;"
                "font-size:13px;padding:6px 14px;}")
        except Exception:
            pass
    except Exception as e:
        print("HLD export button skipped:", e)


def build_in_project(iface, hld_cfg, extra_layers=None):
    """Build both HLD layouts in the CURRENT project and open the Print Layout designer.

    Returns (ok: bool, message: str, overview_name: str|None, atlas_name: str|None).
    The map layers get the HLD deliverable styling (the layouts render the live
    layers, so the styling has to live on them). Nothing is saved — close without
    saving to revert, or Save to keep the layouts + styling in your project.
    """
    from qgis.core import QgsProject
    p = QgsProject.instance()
    here = os.path.dirname(os.path.abspath(__file__))
    engine = os.path.join(here, "hld_atlas_engine.py")
    if not os.path.exists(engine):
        return (False, f"Engine not found: {engine}", None, None)

    try:
        _add_missing_extras(p, extra_layers)
    except Exception as e:
        # framing helper is optional — never fail the whole build over it
        print("HLD live build: extra-layer add skipped:", e)

    hld_cfg = dict(hld_cfg or {})
    hld_cfg["build_mode"] = "layouts"          # page-view overview + detail atlas (WYSIWYG)
    ns = {"HLD_CFG": hld_cfg}
    try:
        with open(engine, encoding="utf-8") as f:
            exec(compile(f.read(), engine, "exec"), ns)   # runs build_all() at module end
    except Exception as e:
        return (False, f"Layout build failed: {e}\n{traceback.format_exc()[-700:]}", None, None)

    eff = ns.get("CFG", {}) or {}
    ov_name = eff.get("layout_overview", "MOA PH2 HLD Overview")
    at_name = eff.get("layout_atlas", "MOA PH2 HLD Atlas")
    lm = p.layoutManager()
    overview = lm.layoutByName(ov_name)     # only exists in grid/commercial page-layout mode
    atlas = lm.layoutByName(at_name)        # the book atlas (overview page 1 + detail pages)
    if atlas is None:
        return (False, "Layout was not created (engine build produced nothing).", None, None)

    _role = ns.get("_role")
    cov = _role("coverage") if callable(_role) else None
    n = cov.featureCount() if cov else 0
    if not cov or n < 1:
        return (False, "Coverage layer is empty or unresolved — check the coverage/model selection.",
                None, None)

    def _show_atlas_toolbar(designer):
        """The Atlas Toolbar (◀ [page] ▶ page-flip arrows) is hidden by default in a fresh
        designer window — show it so the operator can flip through the pages."""
        try:
            from qgis.PyQt.QtWidgets import QToolBar
            win = designer.window() if hasattr(designer, "window") else None
            if win is None:
                return
            for tb in win.findChildren(QToolBar):
                if (tb.objectName() or "").lower() == "matlastoolbar":
                    tb.setVisible(True)
        except Exception:
            pass

    def _open_front(layout, atlas_preview=False):
        try:
            d = iface.openLayoutDesigner(layout)
            if atlas_preview:
                try:
                    d.setAtlasPreviewEnabled(True)
                    layout.atlas().seekTo(0)
                    _relock_frame(layout)                 # undo the preview resize, then fit
                    layout.atlas().refreshCurrentFeature()
                    _relock_frame(layout)                 # belt-and-suspenders
                    layout.refresh()
                    _show_atlas_toolbar(d)                # reveal the page-flip arrows
                except Exception:
                    pass
            if atlas_preview:
                # the obvious "Export Atlas as PDF" — wired to the same hard QA gate as headless
                _add_export_button(d, layout, cov, eff, ns.get("_layout_qa"))
            try:
                w = d.window() if hasattr(d, "window") else None
                if w is not None:
                    w.show(); w.raise_(); w.activateWindow()
            except Exception:
                pass
        except Exception as e:
            print("HLD live build: openLayoutDesigner skipped:", e)

    # open the book atlas: page 1 = overview, flip ▶ to each detail page
    if overview is not None and overview is not atlas:
        _open_front(overview)                          # grid/commercial: separate overview
    _open_front(atlas, atlas_preview=True)

    # advisory QA — a broken layout can't silently sail through; warn (never block) so the
    # operator fine-tunes before exporting. Frame-agnostic (HLD / commercial / wayleave).
    try:
        _qa = ns.get("_layout_qa")
        if callable(_qa):
            hard, _soft = _qa(atlas)
            if hard:
                from qgis.core import Qgis
                iface.messageBar().pushMessage(
                    "HLD layout check",
                    f"{len(hard)} item(s) may overlap or sit off-page — nudge them before you "
                    f"export. (e.g. {hard[0]})",
                    level=Qgis.MessageLevel.Warning, duration=12)
    except Exception as e:
        print("HLD advisory QA skipped:", e)

    pages = 1 + n
    return (True, f"Built “{at_name}” — page 1 overview, flip ▶ through {n} detail pages "
            f"({pages} total).", at_name, None)
