# -*- coding: utf-8 -*-
"""HLD Book (custom pages) — every QGIS-side read and write.

A custom-pages book is ONE print layout with ONE atlas over a private virtual layer
(`vfbk_<id>_pages`). Each row of that layer is a page: the overview pages first, then one
row per PON, read live from the PON layer. A row's `page_ids` lists the layer ids that page
draws; the map's data-defined layer list turns those ids into current names when it draws
(a rename never drops a layer) and falls back to a private, empty guard layer so it can
never come out empty.

Nothing here edits a layer's data, style or labelling. Book-owned layers are private and
kept out of the Layers panel; their names start `vfbk_<12 hex>` so no engine role finder
can mistake them for network layers, and the engine skips anything carrying a book id.

Entry points used by the dialog, the designer hook and the tests:
    default_spec(cfg, project, phase=None)      -> spec dict
    build_or_update(cfg, spec, project=None)    -> (layout, message)
    update_book(layout, spec)                   -> layout
    check_book(layout)                          -> (hard[], soft[])  never raises
    backup_book / restore_book / rebuild_book / remove_book / clone_book
    reattach_pon / add_override / discard_override / reattach_override
"""
import json
import re
import os
import time
from urllib.parse import quote

from qgis.core import (QgsProject, QgsVectorLayer, QgsRasterLayer, QgsMapLayer, QgsPrintLayout,
                       QgsLayoutItemMap, QgsLayoutItemLegend, QgsLayoutObject, QgsProperty,
                       QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsGeometry,
                       QgsPointXY, QgsRectangle, QgsNullSymbolRenderer, QgsPalLayerSettings,
                       QgsVectorLayerSimpleLabeling, QgsLayoutPoint, QgsLayoutSize, QgsUnitTypes,
                       QgsReadWriteContext, QgsWkbTypes)
from qgis.PyQt.QtCore import QMetaType

from . import book_pages as BP

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

HERE = os.path.dirname(os.path.abspath(__file__))
ENGINE = os.path.join(HERE, "hld_atlas_engine.py")
MM = QgsUnitTypes.LayoutUnit.LayoutMillimeters

# A3 landscape frame (same geometry as the engine's HLD frame, hld_atlas_engine.build_frame)
MAP = dict(x=6.0, y=28.0, w=322.0, h=263.0)
SB_W = 80.0
SB_X = round(MAP["x"] + MAP["w"] + (417.0 - (MAP["x"] + MAP["w"]) - SB_W) / 2.0, 1)
PAGE_H = 297.0
NOTE_H = 24.0


# ── small helpers ──────────────────────────────────────────────────────────────────────
def _mm_pt(x, y):
    return QgsLayoutPoint(float(x), float(y), MM)


def _mm_sz(w, h):
    return QgsLayoutSize(float(w), float(h), MM)


def engine_ns(cfg):
    """The engine's namespace with `cfg` merged — defines only, builds nothing."""
    ns = {"HLD_CFG": dict(cfg or {})}
    with open(ENGINE, encoding="utf-8") as f:
        exec(compile(f.read(), ENGINE, "exec"), ns)
    return ns


def is_book_layer(layer):
    try:
        return bool(layer.customProperty(BP.PROP_BOOK_ID))
    except Exception:
        return False


def is_book_layout(layout):
    try:
        return BP.is_book_id(layout.customProperty(BP.PROP_BOOK_ID))
    except Exception:
        return False


def names_by_id(project=None):
    p = project or QgsProject.instance()
    return {lid: l.name() for lid, l in p.mapLayers().items()}


def _kind(layer):
    if isinstance(layer, QgsRasterLayer):
        return "raster"
    if isinstance(layer, QgsVectorLayer):
        try:
            gt = layer.geometryType()
            return {QgsWkbTypes.GeometryType.PointGeometry: "point",
                    QgsWkbTypes.GeometryType.LineGeometry: "line",
                    QgsWkbTypes.GeometryType.PolygonGeometry: "polygon"}.get(gt, "unknown")
        except Exception:
            return "unknown"
    return "unknown"


def kinds_by_id(project=None):
    p = project or QgsProject.instance()
    return {lid: _kind(l) for lid, l in p.mapLayers().items()}


def tree_order(project=None):
    p = project or QgsProject.instance()
    return [n.layerId() for n in p.layerTreeRoot().findLayers()]


def ticked_vectors(project=None):
    p = project or QgsProject.instance()
    out = []
    for node in p.layerTreeRoot().findLayers():
        l = node.layer()
        if isinstance(l, QgsVectorLayer) and node.isVisible() and not is_book_layer(l):
            out.append((l.id(), l.name()))
    return out


def book_layers(book_id, project=None):
    p = project or QgsProject.instance()
    return [l for l in p.mapLayers().values() if str(l.customProperty(BP.PROP_BOOK_ID) or "") == book_id]


def layouts_for_book(book_id, project=None):
    p = project or QgsProject.instance()
    return [lay for lay in p.layoutManager().printLayouts()
            if str(lay.customProperty(BP.PROP_BOOK_ID) or "") == book_id]


def all_book_layouts(project=None):
    p = project or QgsProject.instance()
    return [lay for lay in p.layoutManager().printLayouts() if is_book_layout(lay)]


def orphan_book_layers(project=None):
    """Book-owned layers whose book id no layout carries any more."""
    p = project or QgsProject.instance()
    held = {str(lay.customProperty(BP.PROP_BOOK_ID)) for lay in all_book_layouts(p)}
    return [l for l in p.mapLayers().values() if is_book_layer(l)
            and str(l.customProperty(BP.PROP_BOOK_ID)) not in held]


def get_spec(layout):
    try:
        return BP.from_json(layout.customProperty(BP.PROP_SPEC) or "")
    except Exception:
        return None


def set_spec(layout, spec):
    layout.setCustomProperty(BP.PROP_SPEC, BP.to_json(spec))
    layout.setCustomProperty(BP.PROP_BOOK_ID, spec["book_id"])


def book_map(layout):
    for it in layout.items():
        if isinstance(it, QgsLayoutItemMap) and it.id() == "bookmap":
            return it
    return next((it for it in layout.items() if isinstance(it, QgsLayoutItemMap)), None)


def book_legend(layout):
    for it in layout.items():
        if isinstance(it, QgsLayoutItemLegend) and it.id() == "booklegend":
            return it
    return None


def is_original(layout, spec=None):
    """The layout the book was built as (a duplicated layout carries the same id)."""
    spec = spec or get_spec(layout)
    return bool(spec) and layout.name() == spec.get("layout_name")


# ── defaults ───────────────────────────────────────────────────────────────────────────
def _role_ids(ns, role, allowed=None):
    """The engine's own resolution for a role (v1-canonical names, else one fuzzy match),
    restricted to `allowed` ids in phase mode. Book layers are never returned."""
    out = []
    try:
        for l in ns["_role_layers"](role) or []:
            if l is not None and not is_book_layer(l) and (allowed is None or l.id() in allowed):
                out.append(l.id())
    except Exception:
        _swallowed_note()
    if not out and allowed is not None:
        # phase mode: the engine's names did not match inside the phase - use the phase's
        # own layers whose name carries the role's fuzzy keywords (same table as the engine)
        spec = (ns.get("_FUZZY_ROLES") or {}).get(role)
        if spec:
            geom, inc, exc = spec
            p = QgsProject.instance()
            for lid in allowed:
                l = p.mapLayer(lid)
                if l is None or not isinstance(l, QgsVectorLayer):
                    continue
                nm = l.name().lower()
                if _kind(l) == geom and any(k in nm for k in inc) and not any(k in nm for k in exc):
                    out.append(lid)
                    break
    return out


def _metric_epsg(layer):
    try:
        ext = layer.extent()
        c = ext.center()
        tr = QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem("EPSG:4326"),
                                    QgsProject.instance())
        ll = tr.transform(QgsPointXY(c.x(), c.y()))
        return BP.utm_epsg(ll.x(), ll.y())
    except Exception:
        return 32735


def _label_field(layer, ns=None):
    names = [f.name() for f in layer.fields()]
    for cand in ("label", "pon_no", "pon", "PON", "name", "Name", "zone_id", "id", "fid"):
        if cand in names:
            return cand
    for f in layer.fields():
        if f.type() in (QMetaType.Type.QString,):
            return f.name()
    return names[0] if names else ""


def _numeric_field(layer, field):
    try:
        idx = layer.fields().indexOf(field)
        if idx < 0:
            return False
        if layer.fields().at(idx).isNumeric():
            return True
        vals = [f[field] for f in layer.getFeatures()][:200]
        return bool(vals) and all(str(v).strip().lstrip("-").replace(".", "", 1).isdigit()
                                  for v in vals if v is not None)
    except Exception:
        return False


def _overview_geom(spec, pon_layer, aoi_layer):
    """Overview page framing = bbox of the AOI and the PON layer, in the PON layer's CRS."""
    ext = QgsRectangle(pon_layer.extent())
    if aoi_layer is not None:
        try:
            e2 = aoi_layer.extent()
            if aoi_layer.crs() != pon_layer.crs():
                e2 = QgsCoordinateTransform(aoi_layer.crs(), pon_layer.crs(),
                                            QgsProject.instance()).transformBoundingBox(e2)
            ext.combineExtentWith(e2)
        except Exception:
            _swallowed_note()
    if ext.isNull() or ext.width() <= 0 or ext.height() <= 0:
        ext = QgsRectangle(0, 0, 1, 1)
    spec["overview_wkt"] = QgsGeometry.fromRect(ext).asWkt(9)
    spec["overview_srid"] = int(pon_layer.crs().postgisSrid())


def _asbuilt_layers(p, allowed=None):
    """[(id, name, kind, feature count)] for the as-built role finder, Layers-panel order,
    book layers left out (phase mode: the phase's own layers only)."""
    out = []
    for lid in tree_order(p):
        l = p.mapLayer(lid)
        if not isinstance(l, QgsVectorLayer) or is_book_layer(l) or (allowed is not None and lid not in allowed):
            continue
        try:
            n = int(l.featureCount())
        except Exception:
            n = 0
        out.append((lid, l.name(), _kind(l), n))
    return out


def _typed_cable_layers(p, roles, allowed=None):
    """Universality: a line layer holding several cable kinds in one type column (Mahikeng
    'Phase 1 Cables', Palm Ridge 'Cables') fills every line role that found no layer with
    features. Edits `roles` in place; returns {layer id: {"field", "roles": {role: [values]}}}."""
    empty = [r for r in BP.ASBUILT_LINE_ROLES
             if not any(isinstance(p.mapLayer(i), QgsVectorLayer) and p.mapLayer(i).featureCount() > 0
                        for i in roles.get(r) or [])]
    if not empty:
        return {}
    out = {}
    for lid in tree_order(p):
        l = p.mapLayer(lid)
        if (not isinstance(l, QgsVectorLayer) or is_book_layer(l) or not l.isValid() or _kind(l) != "line"
                or (allowed is not None and lid not in allowed) or l.featureCount() <= 0):
            continue
        names = l.fields().names()
        vals = {}
        for f in names:
            if BP._TYPE_FIELD_RE.match(f.strip()):
                try:
                    vals[f] = [v for v in l.uniqueValues(l.fields().indexOf(f), 200) if not _null(v)]
                except Exception:
                    _swallowed_note()
        got = BP.typed_cable_roles(names, vals)
        if got is None:
            continue
        field, by_role = got
        used = {r: v for r, v in by_role.items() if r in empty}
        if not used:
            continue
        for r in used:
            roles[r] = [lid]
        empty = [r for r in empty if r not in used]
        out[lid] = {"field": field, "roles": used}
        if not empty:
            break
    return out


def _asbuilt_outline(p, pon_layer, aoi, allowed=None):
    """Universality: the overview pages frame on the phase outline. A non-empty polygon layer
    named as a phase ('Phase 1', 'phase_1') is the outline when the engine's AOI is none or is
    not itself a phase layer; else the AOI stays."""
    if aoi is not None and BP.outline_rank(aoi.name()) == 0:
        return aoi
    for lid in tree_order(p):
        l = p.mapLayer(lid)
        if (not isinstance(l, QgsVectorLayer) or is_book_layer(l) or not l.isValid() or _kind(l) != "polygon"
                or lid == pon_layer.id() or (allowed is not None and lid not in allowed)):
            continue
        if BP.outline_rank(l.name()) == 0 and l.featureCount() > 0:
            return l
    return aoi


def _typed_info(spec, lid):
    """(type field, {role: [values]}) of a typed cable layer in this book, else (None, None)."""
    t = ((spec.get("asbuilt") or {}).get("typed") or {}).get(lid or "")
    if not t:
        return None, None
    return t.get("field"), t.get("roles") or {}


def _typed_keep(spec, layer, feature, keys):
    """True unless `layer` is a typed cable layer and the feature's type is not one of `keys` roles."""
    field, by_role = _typed_info(spec, layer.id())
    if not field or layer.fields().indexOf(field) < 0:
        return True
    want = set()
    for k in keys:
        want |= set(by_role.get(k) or [])
    v = feature[field]
    return (not _null(v)) and str(v) in want


def _typed_filters(spec, p):
    """{layer id: render filter} for the typed cable layers on the overview pages that draw them."""
    out = {}
    for lid, t in ((spec.get("asbuilt") or {}).get("typed") or {}).items():
        l = p.mapLayer(lid)
        if not isinstance(l, QgsVectorLayer) or not l.isValid() or l.fields().indexOf(t.get("field") or "") < 0:
            continue
        pv = {}
        for i, pg in enumerate(spec["overview"]):
            if lid in pg["ids"]:
                v = BP.typed_page_values(pg["title"], t.get("roles"))
                if v:
                    pv[i] = v
        e = BP.typed_filter_expr(t["field"], pv)
        if e:
            out[lid] = e
    return out


def _drop_not_loaded(p, roles):
    """A layer that does not load here (Cradock's BH Poles points at a table renamed since) stays out of a
    new book: listed on a page, the export check refuses the whole PDF. Returns (roles, names left out)."""
    gone, out = [], {}
    for role, ids in (roles or {}).items():
        keep = []
        for i in ids or []:
            l = p.mapLayer(i)
            if isinstance(l, QgsVectorLayer) and not l.isValid():
                gone.append(l.name())
            else:
                keep.append(i)
        out[role] = keep
    return out, BP._uniq(gone)


def _drop_twin_poles(p, roles):
    """Cradock keeps its backhaul poles in 'BH Poles' AND in 'Poles' (26 of them, same spot): both
    drawn means every one labelled twice, 430 poles counted instead of 404. A pole layer named for the
    backhaul whose every pole sits on a pole of another pole layer leaves the role. A layer that does
    not load stays, so the build message still names it."""
    ids = list(roles.get("poles") or [])
    others = [p.mapLayer(i) for i in ids if not BP.is_backhaul_name(p.mapLayer(i).name())] if ids else []
    others = [l for l in others if isinstance(l, QgsVectorLayer) and l.isValid() and l.featureCount() > 0]
    if not others:
        return roles
    web = QgsCoordinateReferenceSystem("EPSG:3857")
    pts = []
    for l in others:
        tr = QgsCoordinateTransform(l.crs(), web, p)
        for f in l.getFeatures():
            if f.hasGeometry():
                g = QgsGeometry(f.geometry())
                g.transform(tr)
                c = g.centroid().asPoint()
                pts.append((round(c.x()), round(c.y())))
    near = set()
    for x, y in pts:
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                near.add((x + dx, y + dy))
    keep = []
    for i in ids:
        l = p.mapLayer(i)
        if not (isinstance(l, QgsVectorLayer) and l.isValid() and BP.is_backhaul_name(l.name())):
            keep.append(i)
            continue
        tr = QgsCoordinateTransform(l.crs(), web, p)
        twin = True
        for f in l.getFeatures():
            if not f.hasGeometry():
                continue
            g = QgsGeometry(f.geometry())
            g.transform(tr)
            c = g.centroid().asPoint()
            if (round(c.x()), round(c.y())) not in near:
                twin = False
                break
        if not twin:
            keep.append(i)
    return dict(roles, poles=keep)


def _asbuilt_pon_labels(p, roles, pon_ids, pon_labels, every=True):
    """New As-Built builds: the layers the operator labels (poles, FAPs, CTPs, cables) are labelled on
    the PON pages by the book's own readable copy - short pole numbers (Cradock's sheets), FAP / CTP
    labels ahead of pole labels, cable names along the line with overrun - instead of the live
    labels, which crowd each other out on a dense page (Mahikeng: 1 in 3 CTP labels dropped behind
    full pole names). `every` (the "Make every label readable" tick): a pole, FAP, CTP or cable layer
    with a name column is labelled even with its live labels switched off (Cradock's cables, Botshabelo's
    poles: a sheet shows them whatever the panel's label tick says while somebody works). Off: only the
    layers labelled live."""
    out = list(pon_labels)
    for r in ("fap", "ctp", "existing_pole", "poles", "feeder", "feeder_link", "distribution", "spur", "backhaul"):
        for lid in roles.get(r) or []:
            l = p.mapLayer(lid)
            if lid not in pon_ids or lid in out or not isinstance(l, QgsVectorLayer) or not l.isValid():
                continue
            names = l.fields().names()
            named = (BP.cable_name_field(names) if _kind(l) == "line"
                     else BP.short_pole_field(names) if r == "poles"
                     else BP.splitter_name_field(names) if r in ("fap", "ctp") else None)
            if (l.labelsEnabled() and l.labeling() is not None) or (every and named):
                out.append(lid)
    return out


def _asbuilt_saved(key, default=""):
    """Last typed As-Built detail on this machine (province, drawn by, splitting ratio)."""
    try:
        from qgis.core import QgsSettings
        v = QgsSettings().value("vf/hld/asbuilt/" + key, default)
        return str(v if v is not None else default)
    except Exception:
        return default


def asbuilt_remember(details):
    try:
        from qgis.core import QgsSettings
        s = QgsSettings()
        for k in ("province", "drawn_by", "split_ratio"):
            if details.get(k) is not None:
                s.setValue("vf/hld/asbuilt/" + k, str(details[k]))
    except Exception:
        _swallowed_note()


def default_spec(cfg, project=None, phase=None, pon_layer=None, frame_kind=None):
    """A ready-to-build spec for this project (or one phase group). frame_kind "asbuilt"
    (or cfg["book_frame"]) gives the As-Built page set and A4 strip; default is the A3 book."""
    frame_kind = frame_kind or (cfg or {}).get("book_frame") or BP.FRAME_HLD
    p = project or QgsProject.instance()
    ns = engine_ns(cfg)
    allowed = None
    aoi = None
    if phase is not None:
        allowed = {l.id() for l in (phase.get("content") or [])}
        if phase.get("coverage") is not None:
            allowed.add(phase["coverage"].id())
        aoi = phase.get("boundary")
        pon_layer = pon_layer or phase.get("coverage")
    else:
        try:
            aoi = ns["_aoi_layer"]()          # NOTE: never _restore_aoi (it edits the AOI)
        except Exception:
            aoi = None
    if pon_layer is None:
        try:
            pon_layer = ns["_role"]("coverage")
        except Exception:
            pon_layer = None
    if pon_layer is None:
        raise ValueError("No PON / zone polygon layer found — pick one under “Each page shows”.")
    if frame_kind == BP.FRAME_ASBUILT:
        fam = BP.per_pon_layers(pon_layer.name(), [l.name() for l in p.mapLayers().values()
                                                   if isinstance(l, QgsVectorLayer) and _kind(l) == "polygon"
                                                   and not is_book_layer(l)])
        if fam:
            raise ValueError("The PON zones are split over %d layers (%s … %s), one per PON. An As-Built book "
                             "pages over ONE PON layer: merge them first (Vector ▸ Data Management Tools ▸ "
                             "Merge Vector Layers), then pick the merged layer under “Each page shows”."
                             % (len(fam), sorted(fam)[0], sorted(fam)[-1]))
    if aoi is not None and (is_book_layer(aoi) or aoi.id() == pon_layer.id()):
        aoi = None
    roles = {r: _role_ids(ns, r, allowed) for r in BP.PON_PAGE_ROLES}
    roles["coverage"] = [pon_layer.id()]
    fts = (roles.get("fts") or [""])[0]
    ticked = [(i, n) for i, n in ticked_vectors(p) if allowed is None or i in allowed]
    ov, pon_ids, pon_labels = BP.default_pages(roles, ticked, aoi.id() if aoi else "",
                                               pon_layer.id(), fts)
    ab_roles = None
    not_loaded = []
    typed = {}
    if frame_kind == BP.FRAME_ASBUILT:
        ab_roles, not_loaded = _drop_not_loaded(p, BP.asbuilt_roles(_asbuilt_layers(p, allowed)))
        ab_roles = _drop_twin_poles(p, ab_roles)
        typed = _typed_cable_layers(p, ab_roles, allowed)
        if phase is None:
            aoi = _asbuilt_outline(p, pon_layer, aoi, allowed)
        ab = BP.asbuilt_default_pages(ab_roles, pon_layer.id(), aoi.id() if aoi else "")
        if ab is not None:                 # none of the as-built cables found: standard pages
            ov, pon_ids, pon_labels = ab
            _v2_phase_label_default(ov, aoi, phase.get("phase_no") if phase is not None else None)
    title = str(cfg.get("project_name") or "HLD").strip()
    spec = BP.empty_spec(title=title)
    if frame_kind == BP.FRAME_ASBUILT:
        spec["frame_kind"] = BP.FRAME_ASBUILT
        details = BP.asbuilt_default_details(title, phase.get("phase_no") if phase is not None else None,
                                             time.strftime("%Y/%m/%d"))
        for k in ("province", "drawn_by", "split_ratio"):
            details[k] = _asbuilt_saved(k, details[k])
        spec["asbuilt"] = {"roles": ab_roles or {}, "details": details}
        if typed:
            spec["asbuilt"]["typed"] = typed
        # As-Built fixes: titles from Name, readable book labels; isolate is set from the
        # Build tick in build_or_update (nothing read from cfg here)
        spec["asbuilt_fix"] = BP.new_asbuilt_fix(False)
        spec["asbuilt_fix"][V2_MARK] = 1          # v2 defaults already put the zones under the backhaul
        spec["asbuilt_fix"][UNIV_MARK] = 1        # universality defaults (PON-page label copies) - new books only
    spec["phase"] = phase.get("phase_no") if phase is not None else None
    # a default page whose layer this project does not have (no FTS layer, no feeders) is left
    # out rather than built empty; the build message names it and Edit pages can add it back
    if frame_kind == BP.FRAME_ASBUILT:
        # universality: a backhaul / feeder page whose own layers hold no features (Palm Ridge:
        # 'Feeder Fibre' and 'Feeder Joints' are empty) is left out and named, never printed blank
        keep_ids = {pon_layer.id(), aoi.id() if aoi is not None else ""}
        for pg in ov:
            own = [i for i in pg["ids"] if i not in keep_ids
                   and not (pg["title"] == "Feeder Overview" and i in ((ab_roles or {}).get("backhaul") or []))]
            if pg["title"] != "PON Overview" and own and all(
                    isinstance(p.mapLayer(i), QgsVectorLayer) and p.mapLayer(i).featureCount() == 0 for i in own):
                pg["ids"] = []
    spec["defaults_left_out"] = [pg["title"] for pg in ov if not pg["ids"]]
    if frame_kind == BP.FRAME_ASBUILT:
        spec["defaults_left_out"] += ["%s (this layer does not load)" % n for n in not_loaded]
    spec["overview"] = [pg for pg in ov if pg["ids"]]
    if frame_kind == BP.FRAME_ASBUILT and ab_roles:
        pon_labels = _asbuilt_pon_labels(p, ab_roles, pon_ids, pon_labels, every=cfg.get("label_fit") is not False)
    spec["pon"] = {"ids": pon_ids, "labels": pon_labels, "note": ""}
    spec["pon_layer_id"] = pon_layer.id()
    unit, id_field, sort_field = "PON", "", ""
    try:
        from .presets import coverage_descriptor
        unit, id_field, sort_field = coverage_descriptor(pon_layer)
    except Exception:
        _swallowed_note()
    names_ = pon_layer.fields().names()
    spec["pon_label_field"] = id_field if id_field in names_ else _label_field(pon_layer)
    spec["pon_sort_field"] = sort_field if sort_field in names_ else spec["pon_label_field"]
    spec["pon_sort_numeric"] = _numeric_field(pon_layer, spec["pon_sort_field"])
    unit = unit or "PON"
    spec["pon_title_prefix"] = "%s - %s " % (title, unit) if title else "%s " % unit
    if spec["frame_kind"] == BP.FRAME_ASBUILT:
        # Lodewijk's sheets: "PON 01", no project name (it is in the facts table). A label
        # that already reads "PON 01" gets no second "PON".
        first = next((str(f[spec["pon_label_field"]]) for f in pon_layer.getFeatures()
                      if spec["pon_label_field"] and f[spec["pon_label_field"]] is not None), "")
        spec["pon_title_prefix"] = "" if first.strip().lower().startswith(unit.lower()) else "%s " % unit
    spec["metric_epsg"] = _metric_epsg(pon_layer)
    try:
        base = ns["_basemap_layer"]()
    except Exception:
        base = None
    spec["aerial_id"] = base.id() if (base is not None and not is_book_layer(base)) else ""
    _overview_geom(spec, pon_layer, aoi)
    return BP.normalise(spec)


def _v2_phase_label_default(ov, aoi, phase_no):
    """v2 new build: the phase outline is labelled 'Phase N' on the PON Overview (Cradock p2) when
    the outline is a phase layer whose name, feature or book says which phase."""
    if aoi is None or BP.outline_rank(aoi.name()) is None:
        return
    try:
        f0 = next(aoi.getFeatures(), None)
        vals = [v for v in f0.attributes() if not _null(v)][:30] if f0 is not None else []
    except Exception:
        vals = []
    if not BP.phase_text(phase_no, aoi.name(), vals, ""):
        return
    for pg in ov:
        if pg["title"] == "PON Overview" and aoi.id() in pg["ids"] and aoi.id() not in pg["labels"]:
            pg["labels"].append(aoi.id())


# ── book-owned layers ──────────────────────────────────────────────────────────────────
def _own(layer, book_id, role):
    layer.setFlags(layer.flags() | QgsMapLayer.LayerFlag.Private)
    layer.setCustomProperty(BP.PROP_BOOK_ID, book_id)
    layer.setCustomProperty(BP.PROP_ROLE, role)
    return layer


def _add_private(layer):
    p = QgsProject.instance()
    p.addMapLayer(layer, False)
    node = p.layerTreeRoot().findLayer(layer.id())
    if node is not None:                      # never in the Layers panel
        node.parent().removeChildNode(node)
    return layer


def _ensure_guard(spec, crs):
    p = QgsProject.instance()
    g = p.mapLayer(spec.get("guard_id") or "")
    name = BP.guard_layer_name(spec["book_id"])
    if g is None or not is_book_layer(g):
        g = QgsVectorLayer("Point?crs=%s" % crs.authid(), name, "memory")
        _add_private(_own(g, spec["book_id"], "guard"))
        spec["guard_id"] = g.id()
    elif g.name() != name:
        g.setName(name)
    return g


def _label_settings_for(src):
    """Labelling for a book label layer: a clone of the source's own labelling when it has
    one (source untouched), else a plain label on the best name field."""
    try:
        if src.labeling() is not None:
            lab = src.labeling().clone()
            return lab
    except Exception:
        _swallowed_note()
    s = QgsPalLayerSettings()
    s.fieldName = BP.splitter_name_field(src.fields().names()) or _label_field(src)
    s.enabled = True
    try:
        s.placement = (QgsPalLayerSettings.Placement.Horizontal
                       if _kind(src) == "polygon" else s.placement)
    except Exception:
        _swallowed_note()
    return QgsVectorLayerSimpleLabeling(s)


def _readable_labeling(lab, src, is_pon=False):
    """S3: a book label copy made readable. Text, font, size, colour and scale range are kept;
    buffer on (kept if present, else 0.7 mm), overlap prevented, labels act as obstacles, a
    point label drawn over its point moves around it, one label per line, and a priority
    (PON 9 > FAP/CTP 8 > poles 6 > cables 4). No masks, no callouts (2026-07-28 crash)."""
    from qgis.core import Qgis
    lab = lab.clone()
    kind = _kind(src) if src is not None else "unknown"
    prio = BP.label_priority(src.name() if src is not None else "", kind, is_pon)
    # the copy draws no symbol, so "around point" must clear the live marker by its own size
    gap_mm = _marker_half_mm(src) + 0.4 if kind == "point" else 0.0

    def fix(s):
        s = QgsPalLayerSettings(s)
        try:
            fmt = s.format()
            b = fmt.buffer()
            if not b.enabled():
                b.setEnabled(True)
                b.setSize(0.7)
                b.setSizeUnit(Qgis.RenderUnit.Millimeters)
                fmt.setBuffer(b)
                s.setFormat(fmt)
        except Exception:
            _swallowed_note()
        try:
            ps = s.placementSettings()
            ps.setOverlapHandling(Qgis.LabelOverlapHandling.PreventOverlap)
            s.setPlacementSettings(ps)
        except Exception:
            _swallowed_note()
        try:
            ob = s.obstacleSettings()
            ob.setIsObstacle(True)
            s.setObstacleSettings(ob)
        except Exception:
            _swallowed_note()
        try:
            if kind == "point" and s.placement == Qgis.LabelPlacement.OverPoint:
                s.placement = Qgis.LabelPlacement.AroundPoint
            if kind == "point" and s.placement == Qgis.LabelPlacement.AroundPoint and \
                    (s.distUnits != Qgis.RenderUnit.Millimeters or s.dist < gap_mm):
                s.dist = round(gap_mm, 2)
                s.distUnits = Qgis.RenderUnit.Millimeters
            if kind == "line":
                ls = s.lineSettings()
                ls.setMergeLines(False)
                s.setLineSettings(ls)
                s.repeatDistance = 0
        except Exception:
            _swallowed_note()
        s.priority = prio
        return s
    _map_label_settings(lab, fix)
    return lab


def _marker_half_mm(src):
    """Half the largest marker size of the live layer's legend symbols, in mm (1.0 if unknown)."""
    from qgis.core import Qgis, QgsMarkerSymbol
    best = 0.0
    try:
        for it in src.renderer().legendSymbolItems():
            sym = it.symbol()
            if not isinstance(sym, QgsMarkerSymbol):
                continue
            u, sz = sym.sizeUnit(), float(sym.size())
            if u == Qgis.RenderUnit.Millimeters:
                best = max(best, sz)
            elif u == Qgis.RenderUnit.Points:
                best = max(best, sz * 0.3528)
    except Exception:
        _swallowed_note()
    return (best / 2.0) if best > 0 else 1.0


def _map_label_settings(lab, fn):
    """Apply fn(settings) -> settings to a simple or rule-based labeling, in place."""
    t = lab.type()
    if t == "simple":
        lab.setSettings(fn(lab.settings()))
    elif t == "rule-based":
        stack = [lab.rootRule()]
        while stack:
            r = stack.pop()
            if r.settings() is not None:
                r.setSettings(fn(r.settings()))
            stack.extend(r.children())
    return lab


def _ensure_label_layers(spec, seed=None):
    """One private label layer per labelled source layer; unused ones are removed.
    Fixed As-Built books (spec has asbuilt_fix): a NEW copy is made readable, from seed[src]
    (the book copy's own format, kept by Rebuild - rule S) when given, else from the live layer."""
    p = QgsProject.instance()
    fixed = spec.get("asbuilt_fix") is not None
    seed = seed or {}
    wanted = set()
    for pg in spec["overview"]:
        wanted |= set(pg["labels"])
    wanted |= set(spec["pon"]["labels"])
    for o in spec["overrides"]:
        wanted |= set(o["labels"])
    cur = dict(spec.get("label_layers") or {})
    used_n = set()
    for lid in list(cur.values()):
        l = p.mapLayer(lid)
        if l is not None:
            try:
                used_n.add(int(l.name().rsplit("_", 1)[1]))
            except Exception:
                _swallowed_note()
    for src_id, lab_id in list(cur.items()):
        if src_id not in wanted or p.mapLayer(src_id) is None or p.mapLayer(lab_id) is None:
            if p.mapLayer(lab_id) is not None:
                p.removeMapLayer(lab_id)
            cur.pop(src_id, None)
    n = 1
    for src_id in sorted(wanted):
        if src_id in cur:
            continue
        src = p.mapLayer(src_id)
        if not isinstance(src, QgsVectorLayer):
            continue
        while n in used_n:
            n += 1
        used_n.add(n)
        uri = "?layer_ref=%s:src&query=%s" % (src_id, quote("SELECT * FROM src"))
        lab = QgsVectorLayer(uri, BP.label_layer_name(spec["book_id"], n), "virtual")
        if not lab.isValid():
            continue
        lab.setRenderer(QgsNullSymbolRenderer())
        if fixed:
            base = seed.get(src_id) or _label_settings_for(src)
            lab.setLabeling(_readable_labeling(base, src, src_id == spec.get("pon_layer_id")))
        else:
            lab.setLabeling(_label_settings_for(src))
        lab.setLabelsEnabled(True)
        lab.setCustomProperty("vf_book_label_source", src_id)
        _add_private(_own(lab, spec["book_id"], "label"))
        cur[src_id] = lab.id()
    spec["label_layers"] = cur
    return cur


def _page_rows(spec, project=None):
    p = project or QgsProject.instance()
    kinds = kinds_by_id(p)
    order = tree_order(p)
    ll = spec.get("label_layers") or {}
    aerial = spec.get("aerial_id") if p.mapLayer(spec.get("aerial_id") or "") is not None else ""
    guard = spec.get("guard_id") or ""

    def ids_text(ids, labels):
        return BP.join_ids(BP.page_id_list(ids, labels, ll, aerial, guard, kinds, order))
    return {
        "overview": [(pg["title"], ids_text(pg["ids"], pg["labels"]), pg["note"]) for pg in spec["overview"]],
        "pon_ids": ids_text(spec["pon"]["ids"], spec["pon"]["labels"]),
        "pon_note": spec["pon"]["note"],
        "overrides": [(o["cx"], o["cy"], o["area"], ids_text(o["ids"], o["labels"]), o["note"])
                      for o in spec["overrides"]],
        "aerial_guard": BP.join_ids([x for x in (aerial, guard) if x]),
    }


def _title_field_now(spec, project=None):
    """S1: the Name field of the CURRENT PON layer for a fixed As-Built book, else None."""
    if spec.get("asbuilt_fix") is None or spec.get("frame_kind") != BP.FRAME_ASBUILT:
        return None
    p = project or QgsProject.instance()
    pon = p.mapLayer(spec.get("pon_layer_id") or "")
    if not isinstance(pon, QgsVectorLayer) or not pon.isValid():
        return None
    try:
        pk = [pon.fields().at(i).name() for i in pon.primaryKeyAttributes()]
    except Exception:
        pk = []
    names = pon.fields().names()
    lf = spec.get("pon_label_field")
    cands = BP.title_candidates(names, lf)
    values = {f: [] for f in cands}
    if cands:
        try:
            from qgis.core import QgsFeatureRequest
            req = QgsFeatureRequest()
            req.setSubsetOfAttributes(cands, pon.fields())
            for i, f in enumerate(pon.getFeatures(req)):
                if i >= 20000:
                    break
                for c in cands:
                    values[c].append(f[c])
        except Exception:
            _swallowed_note()
    return BP.asbuilt_title_pick(names, lf, pk, values)


def _pages_uri(spec, project=None):
    tf = _title_field_now(spec, project)
    if tf:                                    # transient: never stored in the spec
        spec = dict(spec, pon_title_field=tf)
    skip = skip_pon_fids(spec, project)
    if skip:                                  # transient too: a stray blank zone gets no page
        spec = dict(spec, skip_pon_fids=skip)
    rows = _page_rows(spec, project)
    if _v2_on(spec):                          # As-Built v2: own overview frames + the tie-in marker
        p = project or QgsProject.instance()
        try:
            info = asbuilt_tiein(spec, p)
            frames = _overview_frames(spec, p, info)
            if any(frames):
                spec = dict(spec, overview_wkts=frames)
            tie = p.mapLayer(spec.get("tiein_id") or "")
            if info is not None and tie is not None and tie.isValid() and info["page"] < len(rows["overview"]):
                t, ids_text, note = rows["overview"][info["page"]]
                rows["overview"][info["page"]] = (t, BP.join_ids(BP._uniq([tie.id()] + BP.split_ids(ids_text))), note)
        except Exception:
            _swallowed_note()
    sql = BP.page_layer_sql(spec, rows)
    return ("?layer_ref=%s:pon&query=%s&geometry=geometry:3:%d&uid=seq"
            % (spec["pon_layer_id"], quote(sql), int(spec["overview_srid"])))


def _ensure_pages(spec):
    p = QgsProject.instance()
    uri = _pages_uri(spec, p)
    name = BP.pages_layer_name(spec["book_id"])
    lyr = p.mapLayer(spec.get("pages_id") or "")
    if lyr is not None and is_book_layer(lyr):
        lyr.setDataSource(uri, name, "virtual")       # same layer id -> atlas stays attached
        if not lyr.isValid():
            raise RuntimeError("Book page list could not be rebuilt: %s"
                               % lyr.dataProvider().error().message())
        return lyr
    lyr = QgsVectorLayer(uri, name, "virtual")
    if not lyr.isValid():
        raise RuntimeError("Book page list could not be created: %s" % lyr.dataProvider().error().message())
    _add_private(_own(lyr, spec["book_id"], "pages"))
    spec["pages_id"] = lyr.id()
    return lyr


# ── layout ─────────────────────────────────────────────────────────────────────────────
def _layout_name(spec, project=None):
    p = project or QgsProject.instance()
    kind = "As-Built Book" if spec.get("frame_kind") == BP.FRAME_ASBUILT else "Pages Book"
    base = "%s %s" % (spec.get("title") or "HLD", kind)
    if spec.get("phase") is not None:
        base = "%s Phase %s %s" % (spec.get("title") or "HLD", spec["phase"], kind)
    name, n = base, 2
    while True:
        ex = p.layoutManager().layoutByName(name)
        if ex is None or str(ex.customProperty(BP.PROP_BOOK_ID) or "") == spec["book_id"]:
            return name
        name = "%s (%d)" % (base, n); n += 1


def _legend_layer_ids(spec, project=None):
    p = project or QgsProject.instance()
    ids = []
    for pg in spec["overview"]:
        ids += pg["ids"]
    ids += spec["pon"]["ids"]
    for o in spec["overrides"]:
        ids += o["ids"]
    # As-Built sheets carry no PON or area rows in the legend (Lodewijk's: the zones are
    # labelled on the map instead)
    skip = set()
    if spec.get("frame_kind") == BP.FRAME_ASBUILT:
        skip.add(spec.get("pon_layer_id"))
        for pg in spec["overview"]:
            for i in pg["ids"]:
                lyr = p.mapLayer(i)
                if lyr is not None and _kind(lyr) == "polygon":
                    skip.add(i)
    out = []
    for i in BP._uniq(ids):
        l = p.mapLayer(i)
        if isinstance(l, QgsVectorLayer) and not is_book_layer(l) and i not in skip:
            out.append(i)
    return BP.ordered_ids(out, kinds_by_id(p), tree_order(p))


def _asbuilt_role_of(spec):
    """{layer id: role} from the as-built role finder (empty for the A3 book)."""
    out = {}
    for role, ids in ((spec.get("asbuilt") or {}).get("roles") or {}).items():
        for i in ids or []:
            out.setdefault(i, (role, len(ids)))
    return out


def _auto_label(ns, layer, spec=None):
    role = _asbuilt_role_of(spec or {}).get(layer.id())
    if role and role[1] == 1 and role[0] in BP.ASBUILT_LABELS:
        lab = BP.ASBUILT_LABELS[role[0]]             # one layer per role: Lodewijk's wording
    else:
        try:
            lab = ns["_legend_label"](layer)
        except Exception:
            lab = layer.name()
    if (spec or {}).get("frame_kind") == BP.FRAME_ASBUILT and _kind(layer) == "point":
        lab = re.sub(r"\s*\([\d\s,.]+\)\s*$", "", str(lab)).strip()
        if layer.isValid() and layer.featureCount() >= 0:
            lab = "%s [%d]" % (lab, layer.featureCount())   # "Poles [404]", like Lodewijk's
    return lab


def _legend_category_counts(node, lyr):
    """'5m [243]' / '7m [161]' as the rows' own text. QGIS's live feature count is reset by the book's
    per-page styles, so at export it printed '[N/A]'. A row the operator renamed is left alone."""
    from qgis.core import QgsMapLayerLegendUtils
    from qgis.PyQt.QtCore import QCoreApplication
    try:
        ren = lyr.renderer()
        items = ren.legendSymbolItems() if ren is not None and lyr.isValid() else []
        if len(items) < 2:
            return
        task = lyr.countSymbolFeatures()
        if task is not None:
            task.waitForFinished(30000)
        QCoreApplication.sendPostedEvents(lyr)   # delivers this layer's result only, no other event
        for i, it in enumerate(items):
            n = lyr.featureCount(it.ruleKey())
            prop = "vf/legend_auto_row/%d" % i
            cur = QgsMapLayerLegendUtils.legendNodeUserLabel(node, i)
            if n < 0 or (cur and cur != (node.customProperty(prop) or "")):
                continue
            text = "%s [%d]" % (it.label(), n)
            QgsMapLayerLegendUtils.setLegendNodeUserLabel(node, i, text)
            node.setCustomProperty(prop, text)
    except Exception:
        _swallowed_note()


def _sync_legend(layout, spec, ns, first=False):
    """Legend writes allowed after the first build: rows for layers NEWLY added to a page
    and the label of a row the operator has not renamed. Box, columns, fonts, symbol sizes,
    title, order and deleted rows are never touched."""
    leg = book_legend(layout)
    if leg is None:
        return
    p = QgsProject.instance()
    root = leg.model().rootGroup()
    want = _legend_layer_ids(spec, p)
    known = set(spec.get("legend_known") or [])
    present = {n.layerId(): n for n in root.findLayers()}
    for lid in want:
        if lid in known and not first:
            continue                                      # the operator may have deleted it
        if lid in present:
            continue
        lyr = p.mapLayer(lid)
        if lyr is None:
            continue
        node = root.addLayer(lyr)
        lab = _auto_label(ns, lyr, spec)
        node.setCustomProperty("legend/title-label", lab)
        node.setCustomProperty(BP.PROP_AUTO_LABEL, lab)
        present[lid] = node
    for lid, node in present.items():
        lyr = p.mapLayer(lid)
        if lyr is None:
            continue
        stored = node.customProperty(BP.PROP_AUTO_LABEL)
        if stored is not None and (node.customProperty("legend/title-label") or "") == stored:
            lab = _auto_label(ns, lyr, spec)
            node.setCustomProperty("legend/title-label", lab)
            node.setCustomProperty(BP.PROP_AUTO_LABEL, lab)
    spec["legend_known"] = BP._uniq(list(known) + want)
    if spec.get("frame_kind") == BP.FRAME_ASBUILT:
        for lid, node in present.items():
            lyr = p.mapLayer(lid)
            if isinstance(lyr, QgsVectorLayer) and _kind(lyr) == "point":
                _legend_category_counts(node, lyr)
    try:
        leg.updateLegend()
    except Exception:
        _swallowed_note()


def _sample_pages(n, spec):
    """Every page for a short book; else every overview page plus 12 PON pages spread out
    (all PON pages share one layer set unless overridden, so the legend barely varies)."""
    k = len(spec.get("overview") or [])
    if n <= 30:
        return list(range(n))
    pon = list(range(k, n))
    step = max(1, len(pon) // 12)
    return sorted(set(list(range(min(k, n))) + pon[::step] + [n - 1]))


def _legend_heights(layout, spec=None):
    """Legend content height (mm) on the sampled pages. The legend only learns its filtered
    size when the page is RENDERED, so each sampled page is drawn once at 12 dpi."""
    from qgis.core import QgsLayoutExporter
    leg = book_legend(layout)
    at = layout.atlas()
    out = []
    if leg is None or not at.enabled():
        return out
    leg.setResizeToContents(True)
    ex = QgsLayoutExporter(layout)
    at.updateFeatures()
    at.beginRender()
    try:
        for i in _sample_pages(at.count(), spec or get_spec(layout) or {}):
            at.seekTo(i)
            ex.renderPageToImage(0, dpi=12)
            leg.adjustBoxSize()
            out.append(float(leg.rect().height()))
    finally:
        at.endRender()
    return out


def _new_layout(ns, cfg, spec, pages, guard):
    p = QgsProject.instance()
    lay = QgsPrintLayout(p)
    lay.initializeDefaults()
    lay.setName(_layout_name(spec, p))
    lay.pageCollection().page(0).setPageSize("A3", ns["LAND"])
    add_rect = ns["add_rect"]
    add_rect(lay, 3, 3, 414, 291, stroke_w=1.0)
    add_rect(lay, MAP["x"], 6, MAP["w"], 18, stroke_w=0.8)
    # Native text boxes and tables, not HTML labels, so the sheet is editable in the designer
    # like the other layout models (JJ 2026-10-20). [% %] expressions still evaluate per page.
    t = ns["_nt_title_text"](lay, "[% attribute(@atlas_feature,'page_title') %]", MAP["x"], 6, MAP["w"], 18)
    t.setId("booktitle")
    # map
    m = QgsLayoutItemMap(lay)
    m.setId("bookmap")
    lay.addLayoutItem(m)
    m.attemptMove(_mm_pt(MAP["x"], MAP["y"])); m.attemptResize(_mm_sz(MAP["w"], MAP["h"]))
    aerial = p.mapLayer(spec.get("aerial_id") or "")
    m.setLayers([x for x in (guard, aerial) if x is not None])
    m.setKeepLayerSet(True)
    m.dataDefinedProperties().setProperty(
        QgsLayoutObject.DataDefinedProperty.MapLayers,
        QgsProperty.fromExpression(BP.map_layers_expression(guard.name())))
    m.setFrameEnabled(True)
    m.setFrameStrokeWidth(ns["QgsLayoutMeasurement"](0.4, MM))
    m.setBackgroundColor(ns["QColor"](255, 255, 255))
    m.setAtlasDriven(True)
    m.setAtlasScalingMode(ns["ATLAS_AUTO"])
    m.setAtlasMargin(float(cfg.get("atlas_margin", 0.15)))
    m.attemptMove(_mm_pt(MAP["x"], MAP["y"])); m.attemptResize(_mm_sz(MAP["w"], MAP["h"]))
    for k, v in (("hld_frame_x", MAP["x"]), ("hld_frame_y", MAP["y"]),
                 ("hld_frame_w", MAP["w"]), ("hld_frame_h", MAP["h"])):
        m.setCustomProperty(k, float(v))
    spec["frame"] = dict(MAP)
    # legend (native, one, rows follow the page)
    leg = QgsLayoutItemLegend(lay)
    leg.setId("booklegend")
    lay.addLayoutItem(leg)
    leg.setLinkedMap(m)
    leg.setAutoUpdateModel(False)
    leg.setTitle("LEGEND")
    try:
        leg.setLegendFilterByMapEnabled(True)
    except Exception:
        _swallowed_note()
    leg.model().rootGroup().removeAllChildren()
    leg.setFrameEnabled(True)
    leg.setResizeToContents(True)
    leg.attemptMove(_mm_pt(SB_X, 6))
    # note
    note = ns["_nt_text"](lay, "[% coalesce(attribute(@atlas_feature,'page_note'),'') %]",
                          SB_X, 120, SB_W, NOTE_H, pt=9, bold=True, valign="top", key="booknote")
    # title block: native tables, bottom-anchored at their measured height
    title_y, _tb = ns["_nt_titleblock"](lay, SB_X, SB_W, PAGE_H - 3.0, key="booktitleblock")
    # atlas
    at = lay.atlas()
    at.setCoverageLayer(pages)
    at.setEnabled(True)
    at.setHideCoverage(True)
    at.setSortFeatures(True)
    at.setSortExpression('"seq"')
    at.setFilenameExpression("'page_' || \"seq\"")
    return lay, m, leg, note, title_y


def _legend_style(leg, size):
    """Legend text sizes in points (item = size); symbols scaled with it."""
    from qgis.core import QgsLegendStyle
    try:
        for st, sz in ((QgsLegendStyle.Style.Title, size + 3.0), (QgsLegendStyle.Style.Group, size + 1.0),
                       (QgsLegendStyle.Style.Subgroup, size + 0.5), (QgsLegendStyle.Style.SymbolLabel, size)):
            style = leg.rstyle(st)
            tf = style.textFormat()
            tf.setSize(sz)
            style.setTextFormat(tf)
            leg.setStyle(st, style)
        leg.setSymbolHeight(max(2.5, size * 0.45))
        leg.setSymbolWidth(max(4.0, size * 0.7))
    except Exception:
        _swallowed_note()


def _place_sidebar(ns, lay, leg, note, title_y):
    """Size the legend box once, to the tallest (sampled) page, then place note, north and
    logo below it. Fit order: 7.5 pt, 6 pt, then drop the logo and shrink the north arrow,
    and only then two columns (which may run wider than the sidebar - the bar warns)."""
    full = title_y - 6.0 - (3 + NOTE_H + 3 + 26 + 3 + 22 + 3)       # note + north + logo
    lean = title_y - 6.0 - (3 + NOTE_H + 3 + 16 + 3)                # note + small north
    _legend_style(leg, 7.5)
    hs = _legend_heights(lay)
    h = max(hs) if hs else 40.0
    fit = "7.5pt"
    if h > full:
        _legend_style(leg, 6.0)
        hs = _legend_heights(lay)
        h = max(hs) if hs else h
        fit = "6pt"
    show_logo, arrow = True, 18.0
    if h > full:
        show_logo, arrow, fit = False, 10.0, "6pt, no logo"
    if h > lean:
        leg.setColumnCount(2)
        leg.setSplitLayer(True)
        hs = _legend_heights(lay)
        h = max(hs) if hs else h
        fit = "6pt, no logo, 2 columns"
    room = full if show_logo else lean
    box = min(h, max(room, 20.0))
    leg.setResizeToContents(False)
    leg.attemptMove(_mm_pt(SB_X, 6))
    leg.attemptResize(_mm_sz(SB_W, box))
    y = 6 + box + 3
    note.attemptMove(_mm_pt(SB_X, y)); note.attemptResize(_mm_sz(SB_W, NOTE_H))
    y += NOTE_H + 3
    north = ns.get("NORTH_SVG")
    if north:
        from qgis.core import QgsLayoutItemPicture
        pic = QgsLayoutItemPicture(lay)
        pic.setPicturePath(north)
        lay.addLayoutItem(pic)
        pic.attemptMove(_mm_pt(SB_X + (SB_W - arrow) / 2.0, y))
        pic.attemptResize(_mm_sz(arrow, arrow))
        if os.path.basename(north) != "NorthArrow_VF.svg":     # the VF arrow carries its own N
            ns["add_label"](lay, SB_X, y + arrow, SB_W, 5, text="N", size=9 if arrow < 15 else 11, bold=True)
    y += arrow + 8 + 3
    logo = ns.get("LOGO")
    if show_logo and logo and os.path.exists(logo) and y + 22 <= title_y:
        from qgis.core import QgsLayoutItemPicture
        lg = QgsLayoutItemPicture(lay)
        lg.setPicturePath(logo)
        lg.setResizeMode(QgsLayoutItemPicture.ResizeMode.Zoom)
        lay.addLayoutItem(lg)
        lw = min(SB_W, 22 * (48.0 / 28.0))
        lg.attemptMove(_mm_pt(SB_X + (SB_W - lw) / 2.0, y))
        lg.attemptResize(_mm_sz(lw, 22))
    lay.setCustomProperty("vf_book_legend_fit", "%s · tallest page %.0f mm · box %.0f mm" % (fit, h, box))
    return h


# ── As-Built frame (A4, bottom strip) ──────────────────────────────────────────────────
TIEIN_HEAD = "Tie in Pole Location"


def _asbuilt_counts(spec, project=None):
    """Count expressions for the facts table, from the layers the role finder picked."""
    p = project or QgsProject.instance()
    roles = (spec.get("asbuilt") or {}).get("roles") or {}

    def alive(key):
        return [i for i in roles.get(key) or [] if p.mapLayer(i) is not None]
    out = {k: BP.asbuilt_count_expr(alive(k)) for k in ("units", "poles", "fap", "ctp")}
    drop_filter, dl = None, None
    if not out["units"] and alive("drops"):     # no demand points (Cradock): the drops give the unit count
        dl = p.mapLayer(alive("drops")[0])
        if isinstance(dl, QgsVectorLayer) and dl.isValid() and dl.featureCount() > 0:
            vals = {f.name(): list(dl.uniqueValues(dl.fields().indexOf(f.name()), 50))
                    for f in dl.fields() if BP._TYPE_FIELD_RE.match(f.name().strip())}
            drop_filter = BP.drop_unit_filter(vals)
            out["units"] = BP.asbuilt_drop_count_expr(dl.id(), drop_filter)
    out["pons"] = BP.asbuilt_count_expr([spec["pon_layer_id"]])
    skip = skip_pon_fids(spec, p)
    if out["pons"] and skip:                  # a stray blank zone with no network is not a PON
        out["pons"] = "(%s) - %d" % (out["pons"], len(skip))
    units = alive("units")
    pon = p.mapLayer(spec["pon_layer_id"])
    if units and pon is not None:
        u = p.mapLayer(units[0])
        out["units_in_pon"] = BP.asbuilt_in_page_expr(units[0], (pon.crs().authid(), u.crs().authid()))
    elif drop_filter is not None and pon is not None:
        out["units_in_pon"] = BP.asbuilt_drop_in_page_expr(
            dl.id(), drop_filter, (pon.crs().authid(), dl.crs().authid()))
    return out


def _page1_only(item):
    """Print `item` on page 1 only (and in the designer when no atlas page is shown)."""
    rule = "coalesce(attribute(@atlas_feature,'seq'), 0) <> 0"
    dd = item.dataDefinedProperties()
    dd.setProperty(QgsLayoutObject.DataDefinedProperty.ExcludeFromExports, QgsProperty.fromExpression(rule))
    dd.setProperty(QgsLayoutObject.DataDefinedProperty.Opacity,
                   QgsProperty.fromExpression("if(%s, 0, 100)" % rule))
    item.setDataDefinedProperties(dd)


def _new_layout_asbuilt(ns, cfg, spec, pages, guard):
    from qgis.core import QgsLayoutItemPicture
    A = BP.ASBUILT
    p = QgsProject.instance()
    lay = QgsPrintLayout(p)
    lay.initializeDefaults()
    lay.setName(_layout_name(spec, p))
    lay.pageCollection().page(0).setPageSize("A4", ns["LAND"])
    ns["add_rect"](lay, A["frame_x"], A["frame_y"], A["frame_w"], A["frame_h"], stroke_w=0.6)
    m = QgsLayoutItemMap(lay)
    m.setId("bookmap")
    lay.addLayoutItem(m)
    aerial = p.mapLayer(spec.get("aerial_id") or "")
    m.setLayers([x for x in (guard, aerial) if x is not None])
    m.setKeepLayerSet(True)
    m.dataDefinedProperties().setProperty(
        QgsLayoutObject.DataDefinedProperty.MapLayers,
        QgsProperty.fromExpression(BP.map_layers_expression(guard.name())))
    m.setFrameEnabled(True)
    m.setFrameStrokeWidth(ns["QgsLayoutMeasurement"](0.6, MM))
    m.setBackgroundColor(ns["QColor"](255, 255, 255))
    m.setAtlasDriven(True)
    m.setAtlasScalingMode(ns["ATLAS_AUTO"])
    m.setAtlasMargin(float(cfg.get("atlas_margin", 0.10)))
    frame = dict(x=A["map_x"], y=A["map_y"], w=A["map_w"], h=A["map_h"])
    m.attemptMove(_mm_pt(frame["x"], frame["y"])); m.attemptResize(_mm_sz(frame["w"], frame["h"]))
    for k in ("x", "y", "w", "h"):
        m.setCustomProperty("hld_frame_" + k, float(frame[k]))
    spec["frame"] = frame
    # strip backing: white, over the map, under every strip item
    from qgis.core import QgsLayoutItemShape
    bg = QgsLayoutItemShape(lay)
    bg.setShapeType(ns["_enum"](QgsLayoutItemShape, "Shape.Rectangle", "Rectangle"))
    lay.addLayoutItem(bg)
    bg.attemptMove(_mm_pt(A["frame_x"], A["strip_y"]))
    bg.attemptResize(_mm_sz(A["frame_w"], A["frame_y"] + A["frame_h"] - A["strip_y"]))
    sym = bg.symbol()
    if sym is not None:
        sym.setColor(ns["QColor"](255, 255, 255))
        try:
            sym.symbolLayer(0).setStrokeColor(ns["QColor"](0, 0, 0))
            sym.symbolLayer(0).setStrokeWidth(0.6)
        except Exception:
            _swallowed_note()
    bg.setId("bookstrip")
    # strip: "Asbuilt" + page name, north arrow
    ns["_nt_text"](lay, "Asbuilt\n[% attribute(@atlas_feature,'page_title') %]", A["title_x"], A["title_y"],
                   A["title_w"], A["title_h"], pt=10, bold=True, valign="top", key="booktitle")
    north = ns.get("NORTH_SVG")
    if north:
        pic = QgsLayoutItemPicture(lay)
        pic.setPicturePath(north)
        lay.addLayoutItem(pic)
        pic.attemptMove(_mm_pt(A["north_x"], A["north_y"])); pic.attemptResize(_mm_sz(A["north_w"], A["north_h"]))
        pic.setId("booknorth")
    # legend: no title, no frame, rows follow the page, point layers show their counts
    leg = QgsLayoutItemLegend(lay)
    leg.setId("booklegend")
    lay.addLayoutItem(leg)
    leg.setLinkedMap(m)
    leg.setAutoUpdateModel(False)
    leg.setTitle("")
    try:
        leg.setLegendFilterByMapEnabled(True)
    except Exception:
        _swallowed_note()
    leg.model().rootGroup().removeAllChildren()
    leg.setFrameEnabled(False)
    leg.setBackgroundEnabled(False)
    leg.setResizeToContents(True)
    leg.attemptMove(_mm_pt(A["legend_x"], A["legend_y"]))
    # facts table: typed cells are plain text, counts are expressions (live on every page)
    details = (spec.get("asbuilt") or {}).get("details") or {}
    rows = BP.asbuilt_facts_rows(details, _asbuilt_counts(spec, p))
    # five 6 mm rows: 9 pt text + 0.6 mm cell margins fits; the row minimum makes every row
    # exactly one pitch so the grid lines sit where Lodewijk's do
    # The largest font whose five rows fit the 30 mm block (9 pt on Arial); measured, never
    # assumed, because text height differs per QGIS version and font.
    margin, grid = 0.6, 0.3
    frame_h = 5 * A["table_row_h"] + grid
    col_w = ns["_nt_cols"](A["table_w"], A["table_cols"], margin, grid)
    for pt in (9.0, 8.5, 8.0, 7.5, 7.0):
        f, _h = ns["_nt_table"](lay, rows, A["table_x"], A["table_y"], A["table_w"], col_w=col_w, key="bookfacts",
                                pt=pt, margin=margin, grid=grid, frame_h=frame_h)
        t = f.multiFrame()
        need = ns["_nt_table_content_h"](t, f)
        if need <= frame_h + 0.01 or pt == 7.0:
            break
        lay.removeMultiFrame(t)
    try:
        # spread the spare height so every row is one 6 mm pitch, like Lodewijk's grid
        text_h = (need - grid) / 5.0 - 2 * margin - grid
        # 0.05 mm under the pitch per row: an exact fit loses the fifth row to rounding
        row_min = max(text_h, (frame_h - grid) / 5.0 - 2 * margin - grid - 0.05)
        t.setRowHeights([row_min] * 5)
        t.refresh()
        t.recalculateFrameSizes()
    except Exception:
        _swallowed_note()
    # logo box
    ns["add_rect"](lay, A["logo_x"], A["strip_y"], A["logo_w"], A["strip_h"], stroke_w=0.6)
    logo = ns.get("LOGO")
    v2 = spec.get("asbuilt_fix") is not None
    if v2 and not (logo and os.path.exists(logo)):
        logo = VELOCITY_LOGO                    # v2: the Velocity logo when no client logo resolves
    if logo and os.path.exists(logo):
        lg = QgsLayoutItemPicture(lay)
        if v2:
            _set_picture(lg, _logo_data(logo))   # embedded: no path into one PC's plugin folder
        else:
            lg.setPicturePath(logo)
        lg.setResizeMode(QgsLayoutItemPicture.ResizeMode.Zoom)
        lay.addLayoutItem(lg)
        lg.attemptMove(_mm_pt(A["logo_x"] + 3.0, A["strip_y"] + 2.0))
        lg.attemptResize(_mm_sz(A["logo_w"] - 6.0, A["strip_h"] - 4.0))
        lg.setId("booklogo")
    # page 1 (Backhaul overview): the tie-in pole box beside the page picture
    if spec["overview"] and spec["overview"][0]["title"].startswith("Backhaul"):
        t = ns["_nt_text"](lay, TIEIN_HEAD + "\n", A["tiein_x"], A["tiein_y"], A["tiein_w"], A["tiein_h"],
                           pt=9, bold=True, valign="top", key="booktiein", frame=True)
        t.setBackgroundEnabled(True)
        t.setBackgroundColor(ns["QColor"](255, 255, 255))
        t.setMarginX(1.5)
        _page1_only(t)
    at = lay.atlas()
    at.setCoverageLayer(pages)
    at.setEnabled(True)
    at.setHideCoverage(True)
    at.setSortFeatures(True)
    at.setSortExpression('"seq"')
    at.setFilenameExpression("'page_' || \"seq\"")
    return lay, m, leg


def _legend_extent(layout, spec=None, styles=None):
    """(tallest, widest) legend content in mm over the sampled pages (rendered at 12 dpi).
    styles = [(size, columns)]: one (tallest, widest) per style instead, from ONE render per page
    (the render only teaches the legend its page's filtered rows; the size and column count of
    each style are then measured on those rows - 7 styles no longer cost 7 renders of every page)."""
    from qgis.core import QgsLayoutExporter
    leg = book_legend(layout)
    at = layout.atlas()
    many = styles is not None
    styles = list(styles or [None])
    hs, ws = [[] for _s in styles], [[] for _s in styles]
    if leg is None or not at.enabled():
        return [(0.0, 0.0) for _s in styles] if many else (0.0, 0.0)
    leg.setResizeToContents(True)
    ex = QgsLayoutExporter(layout)
    at.updateFeatures()
    at.beginRender()
    try:
        for i in _sample_pages(at.count(), spec or get_spec(layout) or {}):
            at.seekTo(i)
            ex.renderPageToImage(0, dpi=12)
            for k, sty in enumerate(styles):
                if sty is not None:
                    _legend_style(leg, sty[0])
                    leg.setColumnCount(sty[1])
                    leg.setSplitLayer(True)
                leg.adjustBoxSize()
                hs[k].append(float(leg.rect().height()))
                ws[k].append(float(leg.rect().width()))
    finally:
        at.endRender()
    out = [((max(h) if h else 0.0), (max(w) if w else 0.0)) for h, w in zip(hs, ws)]
    return out if many else out[0]


_STRIP_STYLES = ((10.0, 2), (9.0, 2), (8.0, 2), (8.0, 3), (7.0, 3), (6.0, 3), (6.0, 4))


def _place_strip(lay, leg, spec):
    """Fit the legend into its slot in the strip: 10 pt in 2 columns first, then smaller
    and more columns. The box is then fixed at the slot size (the bar warns on overflow)."""
    A = BP.ASBUILT
    fit, h, w = "", 0.0, 0.0
    ext = _legend_extent(lay, spec, styles=_STRIP_STYLES)
    size, cols = _STRIP_STYLES[-1]
    for (size, cols), (h, w) in zip(_STRIP_STYLES, ext):
        fit = "%gpt, %d columns" % (size, cols)
        if h <= A["legend_h"] and w <= A["legend_w"]:
            break
    _legend_style(leg, size)
    leg.setColumnCount(cols)
    leg.setSplitLayer(True)
    leg.setResizeToContents(False)
    leg.attemptMove(_mm_pt(A["legend_x"], A["legend_y"]))
    leg.attemptResize(_mm_sz(A["legend_w"], A["legend_h"]))
    lay.setCustomProperty("vf_book_legend_fit", "%s · tallest page %.0f mm · widest %.0f mm" % (fit, h, w))
    return h, w


def set_tiein(layout, lat, lon):
    """Write the tie-in pole coordinates into page 1's box (from a photo's GPS). Returns the
    text written, or None when the book has no tie-in box. Only the coordinates line changes."""
    for it in layout.items():
        if getattr(it, "id", lambda: "")() == "booktiein" and hasattr(it, "setText"):
            txt = "%s\n%s" % (TIEIN_HEAD, BP.format_latlon(lat, lon))
            it.setText(txt)
            it.refresh()
            return txt
    return None


def tiein_is_blank(layout):
    for it in layout.items():
        if getattr(it, "id", lambda: "")() == "booktiein" and hasattr(it, "text"):
            lines = [x.strip() for x in (it.text() or "").splitlines()]
            return len(lines) < 2 or not lines[1]
    return False


def _apply_clip(m, spec, enabled):
    if not enabled:
        return
    try:
        from qgis.core import QgsMapClippingRegion
        p = QgsProject.instance()
        cs = m.atlasClippingSettings()
        cs.setEnabled(True)
        cs.setFeatureClippingType(QgsMapClippingRegion.FeatureClippingType.ClipToIntersection)
        cs.setForceLabelsInsideFeature(True)
        keep = ("feeder", "primary", "adss")
        clip = []
        for lid in _legend_layer_ids(spec, p):
            l = p.mapLayer(lid)
            nm = (l.name() or "").lower()
            if "mini" not in nm and any(k in nm for k in keep):
                continue
            clip.append(l)
        for lid in (spec.get("label_layers") or {}).values():
            if p.mapLayer(lid) is not None:
                clip.append(p.mapLayer(lid))
        cs.setRestrictToLayers(True)
        cs.setLayersToClip(clip)
    except Exception:
        _swallowed_note()


# ── As-Built fixes: the book map's own style copies (S2 isolate, S3 live labels off) ────
PROP_FIX = "vf_asbuilt_fix"            # mirror of spec["asbuilt_fix"] on the book map item
OVR_MARK = "vf_book_override"          # attribute on the root element of every override we write
ISO_MARK = "vf_isolate"                # description of the root rule of an isolate renderer


def asbuilt_fix_of(layout, spec=None):
    """The book's As-Built fix dict: the spec's key, else the map item's mirror (an older
    plugin's Edit pages drops the spec key but never touches the map), else None."""
    spec = spec if spec is not None else get_spec(layout)
    if spec is None or spec.get("frame_kind") != BP.FRAME_ASBUILT:
        return None
    if spec.get("asbuilt_fix") is not None:
        return spec["asbuilt_fix"] if BP.valid_asbuilt_fix(spec["asbuilt_fix"]) else None
    m = book_map(layout)
    if m is None:
        return None
    raw = m.customProperty(PROP_FIX)
    if not raw:
        return None
    try:
        fix = json.loads(str(raw))
    except Exception:
        return None
    return fix if BP.valid_asbuilt_fix(fix) else None


def _store_fix(layout, spec, fix):
    spec["asbuilt_fix"] = fix
    m = book_map(layout)
    if m is not None:
        m.setCustomProperty(PROP_FIX, json.dumps(fix, sort_keys=True))


def _iso_zones(pages, metric, p):
    """[(unit, metric geometry, prepared engine)] + spatial index, PON rows of the page list."""
    from qgis.core import QgsSpatialIndex, QgsFeature
    tr = QgsCoordinateTransform(pages.crs(), metric, p)
    zones, idx = [], QgsSpatialIndex()
    for f in pages.getFeatures():
        try:
            if int(f["is_overview"] or 0) == 1:
                continue
        except Exception:
            continue
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        g = QgsGeometry(g)
        g.transform(tr)
        eng = QgsGeometry.createGeometryEngine(g.constGet())
        eng.prepareGeometry()
        zf = QgsFeature(len(zones))
        zf.setGeometry(g)
        idx.addFeature(zf)
        zones.append((str(f["unit"]), g, eng))
    return zones, idx


def _iso_keys(layer):
    """{fid: isolate key} through the SAME expression the render-time filter evaluates."""
    from qgis.core import QgsExpression, QgsExpressionContext, QgsExpressionContextUtils, QgsFeatureRequest
    expr_text = BP.iso_key_expr(layer.crs().isGeographic())
    ex = QgsExpression(expr_text)
    ctx = QgsExpressionContext(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
    ex.prepare(ctx)
    out = {}
    req = QgsFeatureRequest().setNoAttributes()
    for f in layer.getFeatures(req):
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        ctx.setFeature(f)
        k = ex.evaluate(ctx)
        if k:
            out[f.id()] = (str(k), QgsGeometry(g))
    return expr_text, out


def _iso_candidates(spec, p):
    """(layers to isolate, {reason: [names]} left whole). Left whole: not a vector layer, a book
    layer, the backbone keep rule (feeder / primary / adss, not 'mini'), a polygon on an overview
    page other than the PON layer, not loaded, a style type we cannot copy, a CRS without a
    usable id, or more than BP.ISO_MAX_FEATURES features."""
    from qgis.core import QgsCoordinateReferenceSystem as CRS
    pon_id = spec.get("pon_layer_id") or ""
    ids = list(spec["pon"]["ids"])
    for o in spec["overrides"]:
        ids += o["ids"]
    ov_polys = set()
    for pg in spec["overview"]:
        for i in pg["ids"]:
            lyr = p.mapLayer(i)
            if i != pon_id and isinstance(lyr, QgsVectorLayer) and lyr.isValid() and _kind(lyr) == "polygon":
                ov_polys.add(i)
    keep = ("feeder", "primary", "adss")
    out, skipped = [], {}

    def skip(why, lyr):
        skipped.setdefault(why, []).append(lyr.name())
    for lid in BP._uniq(ids + [pon_id]):
        lyr = p.mapLayer(lid)
        if not isinstance(lyr, QgsVectorLayer) or is_book_layer(lyr):
            continue
        if not lyr.isValid() or lyr.renderer() is None:          # tested FIRST (exit 139 otherwise)
            skip("not loaded - not isolated", lyr)
            continue
        nm = (lyr.name() or "").lower()
        if lid != pon_id and "mini" not in nm and any(k in nm for k in keep):
            continue
        if lid in ov_polys:
            continue
        c = lyr.crs()
        if not c.isValid() or not c.authid() or CRS(c.authid()) != c:
            if lid == pon_id:
                return [], {"Isolate not applied: the PON layer's CRS has no usable id": [lyr.name()]}
            skip("not isolated (CRS)", lyr)
            continue
        if lyr.renderer().type() not in BP.ISO_RENDERERS:
            skip("not isolated (style type)", lyr)
            continue
        n = lyr.featureCount()
        if n is None or n < 0 or n > BP.ISO_MAX_FEATURES:
            skip("not isolated (too large)", lyr)
            continue
        out.append(lyr)
    return out, skipped


def iso_filters(spec, pages, project=None):
    """{layer id: render-time filter expression} for every layer isolated on PON pages, plus
    {reason: [names]} for the layers left whole. Main thread, bulk reads only, no edits."""
    p = project or QgsProject.instance()
    metric = QgsCoordinateReferenceSystem("EPSG:%d" % int(spec.get("metric_epsg") or 0))
    if not metric.isValid():
        return {}, {"Isolate not applied: no metric CRS for this book": [""]}
    layers, skipped = _iso_candidates(spec, p)
    if not layers:
        return {}, skipped
    zones, idx = _iso_zones(pages, metric, p)
    if not zones:
        return {}, dict(skipped, **{"Isolate not applied: the page list has no PON pages": [""]})
    tol = BP.ISO_TOL_M
    pon_id = spec.get("pon_layer_id")
    page_keys = None
    filters = {}
    for lyr in layers:
        expr_text, keys = _iso_keys(lyr)
        by_key = {}
        if lyr.id() == pon_id:
            # the PON layer itself: each polygon on its own page only (the page row's geometry
            # IS that polygon, so the same key matches)
            if page_keys is None:
                _e, pk = _iso_keys(pages)
                page_keys = {}
                for fid, (k, _g) in pk.items():
                    f = pages.getFeature(fid)
                    if int(f["is_overview"] or 0) == 0:
                        page_keys.setdefault(k, []).append(str(f["unit"]))
            for fid, (k, _g) in keys.items():
                if k in page_keys:
                    by_key[k] = BP.iso_merge(by_key.get(k), page_keys[k], k not in by_key)
        else:
            tr = QgsCoordinateTransform(lyr.crs(), metric, p)
            for fid, (k, g) in keys.items():
                try:
                    g.transform(tr)
                except Exception:
                    by_key[k] = None
                    continue
                bb = g.boundingBox()
                bb.grow(tol)
                hits = []
                gc = g.constGet()
                for zi in idx.intersects(bb):
                    unit, zg, eng = zones[zi]
                    if eng.intersects(gc):
                        hits.append((unit, 0.0))
                    else:
                        d = zg.distance(g)
                        if d <= tol:
                            hits.append((unit, d))
                by_key[k] = BP.iso_merge(by_key.get(k), BP.iso_pages_for(hits, tol), k not in by_key)
        js = BP.iso_map_json(by_key)
        if len(js) > BP.ISO_MAX_JSON:
            skipped.setdefault("not isolated (too large)", []).append(lyr.name())
            continue
        filters[lyr.id()] = BP.iso_filter_expr(js, expr_text)
    return filters, skipped


def _zone_ticks_on(renderer):
    """The PON layer's renderer with every named category ticked, or None when none was off. A zone
    unticked in the Layers panel while somebody works must not vanish from a client sheet (Cradock:
    12 of 13 unticked in the saved project). Book copy only. A blank catch-all keeps its tick."""
    if renderer is None or renderer.type() != "categorizedSymbol":
        return None
    off = [i for i, c in enumerate(renderer.categories())
           if not c.renderState() and c.value() not in (None, "") and str(c.value()).strip() != ""]
    if not off:
        return None
    new = renderer.clone()
    for i in off:
        new.updateCategoryRenderState(i, True)
    return new


def _bh_pole_filters(spec, p):
    """{pole layer id: render filter}: on the backhaul page(s) only the poles on the backhaul route
    (within BP.ISO_TOL_M) draw and are labelled, keyed by geometry like the isolate filter."""
    out = {}
    roles = (spec.get("asbuilt") or {}).get("roles") or {}
    seqs = [i for i, pg in enumerate(spec["overview"]) if BP.is_backhaul_title(pg["title"])]
    if not seqs or not roles.get("backhaul"):
        return out
    metric = _metric_crs(spec)
    parts = []
    for l in _page_layers(list(roles["backhaul"]), p):
        for f in l.getFeatures():
            if f.hasGeometry() and _typed_keep(spec, l, f, ("backhaul",)):
                try:
                    parts.append(_in_crs(f.geometry(), l.crs(), metric, p))
                except Exception:
                    _swallowed_note()
    if not parts:
        return out
    line = QgsGeometry.unaryUnion(parts)
    box = line.boundingBox()
    box.grow(BP.ISO_TOL_M)
    drawn = set()
    for i in seqs:
        drawn |= set(spec["overview"][i]["ids"])
    for lid in roles.get("poles") or []:
        l = p.mapLayer(lid)
        if lid not in drawn or not isinstance(l, QgsVectorLayer) or not l.isValid():
            continue
        key_expr, keys = _iso_keys(l)
        tr = QgsCoordinateTransform(l.crs(), metric, p)
        on = {}
        for _fid, (k, g) in keys.items():
            try:
                g.transform(tr)
            except Exception:
                continue
            if box.contains(g.boundingBox().center()) and g.distance(line) <= BP.ISO_TOL_M:
                on[k] = 1
        out[lid] = BP.bh_pole_filter_expr(seqs, BP.json_lit(on), key_expr)
    return out


def _iso_renderer(layer, filt, base=None):
    """A rule-based copy of the layer's own renderer with `filt` on the root rule. Each top-level
    rule keeps its symbol, legend text, scale range, children, filter, legend key and ticked
    state; a top-level ELSE becomes the explicit NOT(...) of its siblings. (None, reason) when
    the style cannot be copied faithfully - the layer is then left whole."""
    from qgis.core import QgsRuleBasedRenderer
    r = base if base is not None else layer.renderer()
    if r is None:
        return None, "not loaded - not isolated"
    t = r.type()
    if t not in BP.ISO_RENDERERS:
        return None, "not isolated (style type)"
    if t == "RuleRenderer":
        new = r.clone()
        kids = new.rootRule().children()
    else:
        new = QgsRuleBasedRenderer.convertFromRenderer(r)
        if new is None:
            return None, "not isolated (style type)"
        items = r.legendSymbolItems()
        kids = new.rootRule().children()
        if len(kids) != len(items):
            return None, "not isolated (style type)"
        checkable = r.legendSymbolItemsCheckable()
        for rule, it in zip(kids, items):
            rule.setRuleKey(it.ruleKey())
            if checkable:
                rule.setActive(bool(r.legendSymbolItemChecked(it.ruleKey())))
        try:
            new.setUsingSymbolLevels(r.usingSymbolLevels())
            new.setOrderBy(r.orderBy())
            new.setOrderByEnabled(r.orderByEnabled())
        except Exception:
            _swallowed_note()
    non_else = [k for k in kids if not k.isElse()]
    for k in kids:
        if not k.isElse():
            continue
        if t == "RuleRenderer" and any(n.dependsOnScale() for n in non_else):
            return None, "not isolated (style type)"
        parts = ["coalesce((%s), false)" % (n.filterExpression() or "true") for n in non_else]
        k.setIsElse(False)
        k.setFilterExpression("NOT (%s)" % " OR ".join(parts) if parts else "true")
    root = new.rootRule()
    old = root.filterExpression()
    root.setFilterExpression("(%s) AND (%s)" % (old, filt) if old else filt)
    root.setDescription(ISO_MARK)
    return new, None


def _with_show(lab, filt):
    """A label copy's labelling with `filt` AND-ed into its data-defined Show."""
    key = getattr(QgsPalLayerSettings, "Property", QgsPalLayerSettings).Show
    lab = lab.clone()

    def fix(s):
        s = QgsPalLayerSettings(s)
        dd = s.dataDefinedProperties()
        old = dd.property(key)
        expr = filt
        try:
            if old.isActive() and old.asExpression():
                expr = "(%s) AND (%s)" % (old.asExpression(), filt)
        except Exception:
            _swallowed_note()
        dd.setProperty(key, QgsProperty.fromExpression(expr))
        s.setDataDefinedProperties(dd)
        return s
    return _map_label_settings(lab, fix)


def _style_xml(layer, renderer=None, labeling=None, labels_off=False):
    """The layer's full current style as a map-item style override, with the renderer and/or
    labelling replaced and/or labels switched off. Nothing is written to the layer."""
    from qgis.PyQt.QtXml import QDomDocument
    # Symbology + Labeling only: the override's root carries styleCategories, so applying it at
    # each render imports just those two parts (fields, forms, etc. are never touched)
    cats = QgsMapLayer.StyleCategory.Symbology | QgsMapLayer.StyleCategory.Labeling
    doc = QDomDocument("qgis")
    ctx = QgsReadWriteContext()
    layer.exportNamedStyle(doc, ctx, cats)
    root = doc.documentElement()
    for tag, obj in (("renderer-v2", renderer), ("labeling", labeling)):
        if obj is None:
            continue
        el = obj.save(doc, ctx)
        old = root.firstChildElement(tag)
        if old.isNull():
            root.appendChild(el)
        else:
            root.replaceChild(el, old)
    if labels_off:
        root.setAttribute("labelsEnabled", "0")
    root.setAttribute(OVR_MARK, "1")
    return doc.toString()


def _labels_moved_ids(spec, p):
    """Live layers whose labels the book draws from its own copy instead (S3(3)): loaded, live
    labelled, ticked for labels on EVERY page that draws it, and its copy exists and loads."""
    lists = [(pg["ids"], pg["labels"]) for pg in spec["overview"]] + [(spec["pon"]["ids"], spec["pon"]["labels"])]
    lists += [(o["ids"], o["labels"]) for o in spec["overrides"]]
    out = []
    for src, lab in (spec.get("label_layers") or {}).items():
        lyr, cl = p.mapLayer(src), p.mapLayer(lab)
        if not (isinstance(lyr, QgsVectorLayer) and lyr.isValid() and lyr.labelsEnabled()
                and lyr.labeling() is not None):
            continue
        if cl is None or not cl.isValid():
            continue
        draws = [labels for ids, labels in lists if src in ids]
        if draws and all(src in labels for labels in draws):
            out.append(src)
    return out


def _labels_partial(spec, p, moved):
    """v2: live-labelled layers whose book copy labels them on SOME pages only -> {id: Show
    expression for the live labels on the book map} (live labels step aside where the copy draws)."""
    out = {}
    for src, lab in (spec.get("label_layers") or {}).items():
        if src in moved:
            continue
        lyr, cl = p.mapLayer(src), p.mapLayer(lab)
        if not (isinstance(lyr, QgsVectorLayer) and lyr.isValid() and lyr.labelsEnabled()
                and lyr.labeling() is not None and cl is not None and cl.isValid()):
            continue
        ov = [i for i, pg in enumerate(spec["overview"]) if src in pg["ids"] and src in pg["labels"]]
        pon = src in spec["pon"]["ids"] and src in spec["pon"]["labels"]
        e = BP.live_label_show_expr(ov, pon)
        if e:
            out[src] = e
    return out


def sync_overrides(layout, spec, project=None):
    """Write this fixed As-Built book's own style copies on its map (never a live layer):
    isolate filters (when isolate is on) and live labels off where the book's label copy draws
    them. Our previous copies are replaced; anyone else's are left alone. Returns a list of
    message lines. Unfixed and A3 books: nothing happens."""
    fix = asbuilt_fix_of(layout, spec)
    if fix is None:
        return []
    fix = json.loads(json.dumps(fix))
    p = project or QgsProject.instance()
    m = book_map(layout)
    if m is None:
        return []
    cur = dict(m.layerStyleOverrides())
    had_ours = False
    for lid in list(cur):
        if lid in (fix.get("owned_overrides") or []) or ('%s="1"' % OVR_MARK) in (cur[lid] or ""):
            cur.pop(lid)
            had_ours = True
    msgs = []
    filters, skipped = {}, {}
    pages = p.mapLayer(spec.get("pages_id") or "")
    if fix.get("isolate") and pages is not None and pages.isValid():
        filters, skipped = iso_filters(spec, pages, p)
    moved = set(_labels_moved_ids(spec, p))
    partial = _labels_partial(spec, p, moved) if _v2_on(spec) else {}
    typedf = _typed_filters(spec, p) if _v2_on(spec) else {}
    zone_id, zone_base = None, None
    if _v2_on(spec):
        for lid, e in _bh_pole_filters(spec, p).items():
            typedf[lid] = "(%s) AND (%s)" % (typedf[lid], e) if typedf.get(lid) else e
        zone = p.mapLayer(spec.get("pon_layer_id") or "")
        if isinstance(zone, QgsVectorLayer) and zone.isValid():
            zone_base = _zone_ticks_on(zone.renderer())
            zone_id = zone.id() if zone_base is not None else None
    owned, isolated, used = [], [], {}
    for lid in sorted(set(filters) | moved | set(partial) | set(typedf) | ({zone_id} if zone_id else set())):
        lyr = p.mapLayer(lid)
        ren = None
        parts = [f for f in (filters.get(lid), typedf.get(lid)) if f]
        filt = parts[0] if len(parts) == 1 else ("(%s) AND (%s)" % tuple(parts) if parts else None)
        if filt:
            ren, why = _iso_renderer(lyr, filt, zone_base if lid == zone_id else None)
            if ren is None:
                skipped.setdefault(why, []).append(lyr.name())
            else:
                used[lid] = filt
                if lid in filters:
                    isolated.append(lid)
        if ren is None and lid == zone_id:
            ren = zone_base
        if ren is None and lid not in moved and lid not in partial:
            continue
        lab = _with_show(lyr.labeling(), partial[lid]) if lid in partial else None
        cur[lid] = _style_xml(lyr, renderer=ren, labeling=lab, labels_off=(lid in moved))
        owned.append(lid)
    for src, lab in (spec.get("label_layers") or {}).items():
        if src not in used:
            continue
        cl = p.mapLayer(lab)
        if isinstance(cl, QgsVectorLayer) and cl.isValid() and cl.labeling() is not None:
            cur[lab] = _style_xml(cl, labeling=_with_show(cl.labeling(), used[src]))
            owned.append(lab)
    m.setLayerStyleOverrides(cur)
    if cur:
        m.setKeepLayerStyles(True)
    elif had_ours:
        m.setKeepLayerStyles(False)
    if fix.get("isolate"):
        try:
            m.atlasClippingSettings().setEnabled(False)       # isolate replaces atlas clipping
        except Exception:
            _swallowed_note()
    fix["owned_overrides"] = sorted(owned)
    fix["clip_ids"] = sorted(isolated)
    _store_fix(layout, spec, fix)
    names = names_by_id(p)
    if isolated:
        msgs.append("Isolated on PON pages: %s." % ", ".join(sorted(names.get(i, i) for i in isolated)))
    for why, nms in sorted(skipped.items()):
        msgs.append("%s: %s." % (why, ", ".join(n for n in nms if n)) if any(nms) else why + ".")
    if moved:
        msgs.append("Labels drawn by the book's own readable copy (live labels off on this map only): %s."
                    % ", ".join(sorted(names.get(i, i) for i in moved)))
    return msgs


def skip_pon_fids(spec, project=None):
    """Fixed As-Built books: a PON zone with no title value (no Name / PON id) whose only content is
    already on other pages gets no page. Its own network = point / line features of the PON pages'
    layers and of every network role layer inside it that touch no NAMED zone and are not backhaul
    (a backhaul-role layer, or a point within BP.ISO_TOL_M of a backhaul line - those are drawn on
    the Backhaul page). Cradock
    fid 58: the backhaul and its 12 poles only -> no page. Botshabelo fid 215: its own feeder ->
    keeps its 'PON (no Name)' page. Never every zone. Returns sorted fids ([] for any other book)."""
    if not _v2_on(spec):
        return []
    from qgis.core import QgsFeatureRequest
    p = project or QgsProject.instance()
    pon = p.mapLayer(spec.get("pon_layer_id") or "")
    if not isinstance(pon, QgsVectorLayer) or not pon.isValid():
        return []
    tf = _title_field_now(spec, p) or spec.get("pon_label_field") or ""
    if pon.fields().indexOf(tf) < 0:
        return []
    blank, named, total = [], [], 0
    for f in pon.getFeatures():
        total += 1
        v = f[tf]
        if _null(v) or not str(v).strip() or str(v) == "NULL":
            blank.append(f)
        elif f.hasGeometry():
            named.append(QgsGeometry(f.geometry()))
    if not blank or len(blank) >= total:
        return []
    roles = (spec.get("asbuilt") or {}).get("roles") or {}
    bh_ids = set(roles.get("backhaul") or [])
    net = list((spec.get("pon") or {}).get("ids") or [])
    for role, ids_ in roles.items():          # every network role layer (Botshabelo's own feeder is
        if role not in ("backhaul", "units", "drops"):  # not on its PON pages), never demand points / drops
            net += list(ids_ or [])
    layers = [l for l in _page_layers(BP._uniq(net), p)
              if l.id() != pon.id() and l.id() not in bh_ids and _kind(l) in ("point", "line")]
    metric = _metric_crs(spec)
    bh = None
    try:
        parts = []
        for l in _page_layers(list(bh_ids), p):
            if _kind(l) == "line":
                for h in l.getFeatures(QgsFeatureRequest().setNoAttributes()):
                    if h.hasGeometry():
                        parts.append(_in_crs(h.geometry(), l.crs(), metric, p))
        bh = QgsGeometry.unaryUnion(parts) if parts else None
    except Exception:
        _swallowed_note()
    out = []
    for f in blank:
        g = f.geometry() if f.hasGeometry() else None
        found = False
        for l in layers if g is not None and not g.isEmpty() else []:
            try:
                gl = _in_crs(g, pon.crs(), l.crs(), p)
                eng = QgsGeometry.createGeometryEngine(gl.constGet())
                eng.prepareGeometry()
                req = QgsFeatureRequest().setFilterRect(gl.boundingBox()).setNoAttributes()
                for h in l.getFeatures(req):
                    if not (h.hasGeometry() and eng.intersects(h.geometry().constGet())):
                        continue
                    hp = _in_crs(h.geometry(), l.crs(), pon.crs(), p)
                    if any(z.intersects(hp) for z in named):
                        continue              # drawn on a named zone's page
                    if (bh is not None and _kind(l) == "point"
                            and _in_crs(h.geometry(), l.crs(), metric, p).distance(bh) <= BP.ISO_TOL_M):
                        continue              # a backhaul pole: on the Backhaul page
                    found = True
                    break
            except Exception:
                _swallowed_note()
                found = True                  # unsure: keep the page
            if found:
                break
        if not found:
            out.append(int(f.id()))
    return sorted(out)


def pon_name_report(spec, project=None):
    """Message lines for PON rows with a blank or duplicated Name (fixed As-Built books)."""
    p = project or QgsProject.instance()
    tf = _title_field_now(spec, p)
    pon = p.mapLayer(spec.get("pon_layer_id") or "")
    if not tf or pon is None:
        return []
    skip = skip_pon_fids(spec, p)
    blank, dup = BP.name_defects([(f.id(), f[tf]) for f in pon.getFeatures()])
    out = []
    if skip:
        out.append("%d PON zone(s) with no %s and nothing of their own (only backhaul / features of other "
                   "PONs) - no page made: %s." % (len(skip), tf, ", ".join("fid %s" % x for x in skip)))
        blank = [x for x in blank if int(x) not in set(skip)]
    if blank:
        out.append("%d PON(s) have no %s - titled “%s”: %s." % (
            len(blank), tf, BP.NO_NAME_TITLE, ", ".join("fid %s" % x for x in blank)))
    for nm, fids in sorted(dup.items()):
        out.append("%s “%s” is used by %d PONs (%s)." % (tf, nm, len(fids), ", ".join("fid %s" % x for x in fids)))
    return out


# ── As-Built v2 (JJ 2026-10-30, decision asbuilt-fixes-cradock-gaps; Cradock Phase 1 pages 1-4):
# backhaul page with the tie-in pole, overview pages framed on the phase, FAP / cable labels and
# the Velocity logo. Fixed As-Built books only; every write is a book-owned layer, a book label
# copy or a layout item - never a live layer. ─────────────────────────────────────────────
V2_MARK = "v2"                          # in asbuilt_fix once Rebuild put the PON zones under the backhaul
UNIV_MARK = "univ"                      # in asbuilt_fix of books built with the universality defaults (2026-10-30)
TIEIN_COLOR = "#f39200"
TIEIN_AUTO = "vf_tiein_auto"            # on the tie-in box: the text we last wrote
TIEIN_POS = "vf_tiein_pos"              # on the tie-in box: where we last put it ("x,y" mm)
LEGEND_TIEIN = "vf_tiein_node"
VELOCITY_LOGO = os.path.join(HERE, "assets", "velocity_logo.jpg")


def _v2_on(spec):
    s = spec or {}
    return s.get("frame_kind") == BP.FRAME_ASBUILT and s.get("asbuilt_fix") is not None


def _metric_crs(spec):
    return QgsCoordinateReferenceSystem("EPSG:%d" % int(spec.get("metric_epsg") or 32735))


def _srid_crs(spec):
    return QgsCoordinateReferenceSystem("EPSG:%d" % int(spec.get("overview_srid") or 4326))


def _null(v):
    try:
        return v is None or (hasattr(v, "isNull") and v.isNull())
    except Exception:
        return v is None


def _page_layers(ids, p):
    return [l for l in (p.mapLayer(i) for i in ids)
            if isinstance(l, QgsVectorLayer) and l.isValid() and not is_book_layer(l)]


def _in_crs(geom, src, dest, p):
    g = QgsGeometry(geom)
    if src != dest:
        g.transform(QgsCoordinateTransform(src, dest, p))
    return g


def _named_zones(spec, p, dest):
    """[(page name, geometry in dest)] of the PON zones that have a page name (the Name field,
    else the label field). An unnamed zone (Botshabelo fid 215) never frames an overview."""
    pon = p.mapLayer(spec.get("pon_layer_id") or "")
    if not isinstance(pon, QgsVectorLayer) or not pon.isValid():
        return []
    fld = _title_field_now(spec, p) or spec.get("pon_label_field") or ""
    if pon.fields().indexOf(fld) < 0:
        return []
    out = []
    for f in pon.getFeatures():
        v = f[fld]
        s = "" if _null(v) else str(v).strip()
        if not s or not f.hasGeometry():
            continue
        try:
            out.append((s, _in_crs(f.geometry(), pon.crs(), dest, p)))
        except Exception:
            _swallowed_note()
    return out


def _box(geoms):
    r = None
    for g in geoms:
        b = g.boundingBox()
        if b.isNull():
            continue
        if r is None:
            r = QgsRectangle(b)
        else:
            r.combineExtentWith(b)
    return r


def _tup(r):
    return None if r is None else (r.xMinimum(), r.yMinimum(), r.xMaximum(), r.yMaximum())


def _phase_outline(spec, p, dest, skip_page=None):
    """The phase outline of the overview pages: a polygon layer drawn on an overview page whose
    name says phase (else AOI / boundary), its feature for this phase (one feature, or the one
    naming spec['phase']). {layer, box (dest), text ('Phase 1' or None)} or None."""
    pon_id = spec.get("pon_layer_id")
    cands = []
    for i, pg in enumerate(spec["overview"]):
        if i == skip_page:
            continue
        for l in _page_layers(pg["ids"], p):
            r = BP.outline_rank(l.name()) if (l.id() != pon_id and _kind(l) == "polygon") else None
            if r is not None:
                cands.append((r, i, l))
    if not cands:
        return None
    lyr = sorted(cands, key=lambda t: (t[0], t[1]))[0][2]
    feats = [f for f in lyr.getFeatures() if f.hasGeometry()]
    ph = spec.get("phase")
    if len(feats) > 1 and ph is not None and str(ph).strip():
        want = {str(ph).strip().lower(), "phase %s" % str(ph).strip().lower()}
        feats = [f for f in feats if any(not _null(v) and str(v).strip().lower() in want for v in f.attributes())]
    if not feats:
        return None
    try:
        box = _box([_in_crs(f.geometry(), lyr.crs(), dest, p) for f in feats])
    except Exception:
        return None
    vals = [v for v in feats[0].attributes() if not _null(v)][:30]
    typed = ((spec.get("asbuilt") or {}).get("details") or {}).get("phase") or ""
    return {"layer": lyr, "box": box, "text": BP.phase_text(ph, lyr.name(), vals, typed)}


def _feeder_geoms(spec, p, dest, skip=()):
    """Feeder + feeder-link cables (role layers and any line layer named feeder), in dest."""
    roles = (spec.get("asbuilt") or {}).get("roles") or {}
    ids = list(roles.get("feeder") or []) + list(roles.get("feeder_link") or [])
    for lid, l in p.mapLayers().items():
        if isinstance(l, QgsVectorLayer) and _kind(l) == "line" and "feeder" in l.name().lower():
            ids.append(lid)
    out = []
    for l in _page_layers(BP._uniq(ids), p):
        if l.id() in skip or _kind(l) != "line":
            continue
        for f in l.getFeatures():
            if f.hasGeometry() and _typed_keep(spec, l, f, ("feeder", "feeder_link")):
                try:
                    out.append(_in_crs(f.geometry(), l.crs(), dest, p))
                except Exception:
                    _swallowed_note()
    return out


def _resolve_photo(value, layer, p):
    """A pole photo attribute -> an existing image path (absolute, beside the layer's file or a
    parent folder of it, or in the project folder), else None."""
    if _null(value) or not str(value).strip():
        return None
    v = str(value).strip().replace("\\", "/")
    if os.path.isabs(v):
        return v if os.path.isfile(v) else None
    roots = []
    d = os.path.dirname(layer.source().split("|")[0])
    for _ in range(4):
        if d and d not in roots:
            roots.append(d)
        d = os.path.dirname(d)
    if p.homePath():
        roots.append(p.homePath())
    for r in roots:
        cand = os.path.join(r, v)
        if os.path.isfile(cand):
            return os.path.normpath(cand)
    return None


def asbuilt_tiein(spec, project=None):
    """The backhaul page and its tie-in pole (v2), or None when the book has no backhaul page.

    Rule, derived from the data (Botshabelo: every feeder starts where 'BH POP Route' starts;
    Cradock: FEEDER starts where BACKHAUL ends, at the OLT): the backhaul cable's free end that is
    FARTHEST from the feeder network is the tie-in; the other end is the POP. A pole within 15 m
    of that end (an existing-pole layer first, then poles drawn on the backhaul page, then any
    pole layer) is the tie-in pole; with none, the cable end itself is marked.
    Returns {page, backhaul_id, pt (metric x, y), wgs (lat, lon), pole, photo}."""
    p = project or QgsProject.instance()
    if not _v2_on(spec):
        return None
    roles = (spec.get("asbuilt") or {}).get("roles") or {}
    bh_role = list(roles.get("backhaul") or [])
    idx = BP.backhaul_page_index([(pg["title"], pg["ids"]) for pg in spec["overview"]], bh_role)
    if idx is None:
        return None
    on_page = _page_layers(spec["overview"][idx]["ids"], p)
    bh_id = BP.pick_backhaul_layer([(l.id(), l.name(), _kind(l)) for l in on_page], bh_role)
    info = {"page": idx, "backhaul_id": bh_id, "pt": None, "wgs": None, "pole": None, "photo": None,
            "metric_epsg": int(spec.get("metric_epsg") or 0)}
    bh = p.mapLayer(bh_id or "")
    if not isinstance(bh, QgsVectorLayer):
        return info
    metric = _metric_crs(spec)
    parts = []
    for f in bh.getFeatures():
        if not f.hasGeometry() or not _typed_keep(spec, bh, f, ("backhaul",)):
            continue
        try:
            g = _in_crs(f.geometry(), bh.crs(), metric, p)
        except Exception:
            continue
        for ln in (g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]):
            if len(ln) >= 2:
                parts.append(((ln[0].x(), ln[0].y()), (ln[-1].x(), ln[-1].y())))
    if not parts:
        return info
    ends = BP.free_ends(parts) or [pt for ab in parts for pt in ab]

    def dist(geoms, pt):
        if not geoms:
            return None
        q = QgsGeometry.fromPointXY(QgsPointXY(pt[0], pt[1]))
        return min(g.distance(q) for g in geoms)
    feeders = _feeder_geoms(spec, p, metric, skip=set() if _typed_info(spec, bh.id())[0] else {bh.id()})
    zones = [g for _u, g in _named_zones(spec, p, metric)]
    k = BP.tiein_pick([dist(feeders, e) for e in ends], [dist(zones, e) for e in ends])
    if k is None:
        if len(ends) != 1:
            return info
        k = 0
    end = QgsPointXY(ends[k][0], ends[k][1])
    # snap to a pole near the end
    pri = {}
    for i in roles.get("existing_pole") or []:
        pri.setdefault(i, 0)
    for l in on_page:
        if _kind(l) == "point" and "pole" in l.name().lower():
            pri.setdefault(l.id(), 1)
    for i in roles.get("poles") or []:
        pri.setdefault(i, 2)
    cands, feats = [], {}
    tol = BP.TIEIN_SNAP_M
    for lid, pr in pri.items():
        l = p.mapLayer(lid)
        if not isinstance(l, QgsVectorLayer) or not l.isValid() or _kind(l) != "point":
            continue
        try:
            box = QgsCoordinateTransform(metric, l.crs(), p).transformBoundingBox(
                QgsRectangle(end.x() - tol, end.y() - tol, end.x() + tol, end.y() + tol))
            for f in l.getFeatures(box):
                if not f.hasGeometry():
                    continue
                g = _in_crs(f.geometry(), l.crs(), metric, p)
                key = "%s|%d" % (lid, f.id())
                feats[key] = (l, f, g)
                cands.append((pr, g.distance(QgsGeometry.fromPointXY(end)), key))
        except Exception:
            _swallowed_note()
    hit = BP.snap_pick(cands, tol)
    if hit is not None:
        l, f, g = feats[hit]
        end = g.centroid().asPoint()
        nm = next((str(f[x]) for x in ("NAME", "Name", "LABEL", "Label", "POLE_NO", "Pole_No")
                   if l.fields().indexOf(x) >= 0 and not _null(f[x])), "")
        info["pole"] = {"layer": l.id(), "fid": int(f.id()), "name": nm}
        pf = BP.photo_field(l.fields().names())
        if pf:
            info["photo"] = _resolve_photo(f[pf], l, p)
    info["pt"] = (end.x(), end.y())
    w = QgsCoordinateTransform(metric, QgsCoordinateReferenceSystem("EPSG:4326"), p).transform(end)
    info["wgs"] = (w.y(), w.x())
    return info


def _overview_frames(spec, p, info=None):
    """[wkt | None] per overview page, in the page layer's CRS (v2). Every overview page frames
    the phase outline (else the union of the NAMED PON zones); the backhaul page frames what it
    draws (its cables and poles), the tie-in and that same phase frame."""
    dest = _srid_crs(spec)
    if not dest.isValid():
        return []
    bh = info["page"] if info else None
    zbox = _box([g for _u, g in _named_zones(spec, p, dest)])
    ol = _phase_outline(spec, p, dest, skip_page=bh)
    frame = None
    if ol is not None and BP.frame_ok(_tup(ol["box"]), _tup(zbox)):
        frame = QgsRectangle(ol["box"])
    elif zbox is not None:
        frame = QgsRectangle(zbox)
    out = []
    for i, pg in enumerate(spec["overview"]):
        r = QgsRectangle(frame) if frame is not None else None
        if i == bh:
            # the backhaul, its tie-in and the phase (Cradock p1); other cables on the page run
            # off the edge like the backhaul does on the feeder page
            bl = p.mapLayer((info or {}).get("backhaul_id") or "")
            for l in ([bl] if isinstance(bl, QgsVectorLayer) and bl.isValid() else []):
                if l.featureCount() <= 0:
                    continue
                try:
                    if _typed_info(spec, l.id())[0]:     # typed cable layer: the backhaul rows only
                        e = _box([_in_crs(f.geometry(), l.crs(), dest, p) for f in l.getFeatures()
                                  if f.hasGeometry() and _typed_keep(spec, l, f, ("backhaul",))])
                        if e is None:
                            continue
                    else:
                        e = l.extent() if l.crs() == dest else \
                            QgsCoordinateTransform(l.crs(), dest, p).transformBoundingBox(l.extent())
                except Exception:
                    continue
                if r is None:
                    r = QgsRectangle(e)
                else:
                    r.combineExtentWith(e)
            if info and info.get("pt") and r is not None:
                q = QgsCoordinateTransform(_metric_crs(spec), dest, p).transform(QgsPointXY(*info["pt"]))
                r.combineExtentWith(q.x(), q.y())
        ok = r is not None and r.width() > 0 and r.height() > 0
        out.append(QgsGeometry.fromRect(r).asWkt(9) if ok else None)
    det = {d.get("title"): d.get("wkt") for d in spec.get("auto_details") or [] if d.get("wkt")}
    if det:                                   # detail pages (round 2): their own frame
        out = [det.get(pg["title"]) or w for pg, w in zip(spec["overview"], out)]
    return out


def _tiein_uri(spec, info, p):
    """One point in the page layer's CRS (the book map's own), 9 decimals."""
    dest = _srid_crs(spec)
    q = QgsCoordinateTransform(_metric_crs(spec), dest, p).transform(QgsPointXY(*info["pt"]))
    srid = int(spec.get("overview_srid") or 4326)
    sql = "SELECT 1 AS id, %s AS name, MakePoint(%.9f, %.9f, %d) AS geometry" % (
        BP.sql_str(BP.TIEIN_LABEL), q.x(), q.y(), srid)
    return "?query=%s&geometry=geometry:1:%d&uid=id" % (quote(sql), srid)


def _style_tiein(lyr):
    """Orange 'P' marker (Cradock's Existing Herotel Pole) + an orange label clear of it."""
    from qgis.core import (Qgis, QgsMarkerSymbol, QgsSimpleMarkerSymbolLayer, QgsFontMarkerSymbolLayer,
                           QgsSingleSymbolRenderer, QgsTextFormat, QgsTextBufferSettings)
    from qgis.PyQt.QtGui import QColor, QFont
    sym = QgsMarkerSymbol()
    sym.deleteSymbolLayer(0)
    c = QgsSimpleMarkerSymbolLayer()
    c.setSize(4.0)
    c.setColor(QColor(TIEIN_COLOR))
    c.setStrokeColor(QColor(255, 255, 255))
    c.setStrokeWidth(0.3)
    sym.appendSymbolLayer(c)
    try:
        t = QgsFontMarkerSymbolLayer("Arial", "P", 2.6, QColor(255, 255, 255))
        t.setFontStyle("Bold")
        sym.appendSymbolLayer(t)
    except Exception:
        _swallowed_note()
    lyr.setRenderer(QgsSingleSymbolRenderer(sym))
    s = QgsPalLayerSettings()
    s.fieldName = "name"
    s.enabled = True
    fmt = QgsTextFormat()
    f = QFont("Arial")
    f.setBold(True)
    fmt.setFont(f)
    fmt.setSize(7.0)
    fmt.setSizeUnit(Qgis.RenderUnit.Points)
    fmt.setColor(QColor(TIEIN_COLOR))
    b = QgsTextBufferSettings()
    b.setEnabled(True)
    b.setSize(0.8)
    b.setSizeUnit(Qgis.RenderUnit.Millimeters)
    b.setColor(QColor(255, 255, 255))
    fmt.setBuffer(b)
    s.setFormat(fmt)
    s.placement = Qgis.LabelPlacement.AroundPoint
    s.dist = 2.4
    s.distUnits = Qgis.RenderUnit.Millimeters
    s.priority = 10
    try:
        ps = s.placementSettings()
        ps.setOverlapHandling(Qgis.LabelOverlapHandling.PreventOverlap)
        s.setPlacementSettings(ps)
        ob = s.obstacleSettings()
        ob.setIsObstacle(True)
        s.setObstacleSettings(ob)
    except Exception:
        _swallowed_note()
    lyr.setLabeling(QgsVectorLayerSimpleLabeling(s))
    lyr.setLabelsEnabled(True)


def _ensure_tiein_layer(spec, info, p):
    """The book-owned tie-in marker (a virtual layer holding one point, so it survives a save and
    reopen). Removed when the book has no tie-in."""
    lid = spec.get("tiein_id") or ""
    lyr = p.mapLayer(lid) if lid else None
    if lyr is not None and not is_book_layer(lyr):
        lyr = None
    if info is None or info.get("pt") is None:
        if lyr is not None:
            p.removeMapLayer(lyr.id())
        spec.pop("tiein_id", None)
        return None
    uri = _tiein_uri(spec, info, p)
    name = "vfbk_%s_tiein" % spec["book_id"]
    if lyr is not None:
        if lyr.source() != uri:
            lyr.setDataSource(uri, name, "virtual")
        return lyr
    lyr = QgsVectorLayer(uri, name, "virtual")
    if not lyr.isValid():
        return None
    _style_tiein(lyr)
    _add_private(_own(lyr, spec["book_id"], "tiein"))
    spec["tiein_id"] = lyr.id()
    return lyr


def _label_fix(kind, names, layer_name, arg=None):
    """fn(settings) -> settings for one v2 label copy (see _tune_label_copies)."""
    from qgis.core import Qgis, QgsTextBufferSettings
    from qgis.PyQt.QtGui import QColor

    def size_at(fmt, lo=None, hi=None):
        try:
            if fmt.sizeUnit() == Qgis.RenderUnit.Points:
                if hi is not None and fmt.size() > hi:
                    fmt.setSize(hi)
                if lo is not None and fmt.size() < lo:
                    fmt.setSize(lo)
        except Exception:
            _swallowed_note()
        return fmt

    def fn(s):
        s = QgsPalLayerSettings(s)
        if kind in ("pon_bh", "polygon"):
            try:                              # a zone too thin for its label: just outside it
                s.polygonPlacementFlags = (Qgis.LabelPolygonPlacementFlag.AllowPlacementInsideOfPolygon |
                                           Qgis.LabelPolygonPlacementFlag.AllowPlacementOutsideOfPolygon)
            except Exception:
                _swallowed_note()
        if kind in ("phase", "pon_bh", "polygon"):
            # a zone / phase polygon is the thing its own label sits on: as an obstacle its whole
            # interior pushed FAP, pole and cable labels off the overview pages (measured)
            # (overview pages only: PON pages keep c0eceacf's obstacles, data-defined per page)
            try:
                dd = s.dataDefinedProperties()
                dd.setProperty(QgsPalLayerSettings.Property.IsObstacle, QgsProperty.fromExpression(
                    "coalesce(attribute(@atlas_feature,'is_overview'),0) = 0"))
                s.setDataDefinedProperties(dd)
            except Exception:
                _swallowed_note()
        if kind == "phase":
            s.fieldName = BP.sql_str(arg)
            s.isExpression = True
            fmt = s.format()
            f = fmt.font()
            f.setBold(True)
            fmt.setFont(f)
            fmt.setSize(11.0)
            fmt.setSizeUnit(Qgis.RenderUnit.Points)
            fmt.setColor(QColor(60, 60, 60))
            b = QgsTextBufferSettings()
            b.setEnabled(True)
            b.setSize(1.0)
            b.setSizeUnit(Qgis.RenderUnit.Millimeters)
            b.setColor(QColor(255, 255, 255))
            fmt.setBuffer(b)
            s.setFormat(fmt)
            s.placement = Qgis.LabelPlacement.Horizontal
            s.priority = 8
        elif kind == "pole":
            cur = s.fieldName or ""
            if not (s.isExpression and "'^.*_'" in cur and cur.startswith("regexp_replace(")):
                s.fieldName = BP.short_pole_expr(names, cur, s.isExpression)
                s.isExpression = True
            fmt = size_at(s.format(), hi=BP.POLE_PT)
            try:
                b = fmt.buffer()
                if b.enabled() and b.sizeUnit() == Qgis.RenderUnit.Millimeters and b.size() > BP.POLE_BUF_MM:
                    b.setSize(BP.POLE_BUF_MM)
                    fmt.setBuffer(b)
            except Exception:
                _swallowed_note()
            s.setFormat(fmt)
            if arg:                           # ladder: perpendicular to the pole line (Cradock p1)
                lit, key = arg
                dd = s.dataDefinedProperties()
                dd.setProperty(QgsPalLayerSettings.Property.LabelRotation, QgsProperty.fromExpression(
                    "coalesce(to_real(array_get(map_get(from_json(%s), %s), 0)), 0)" % (lit, key)))
                near = BP.ladder_base_dist(s.dist, dd.property(QgsPalLayerSettings.Property.LabelDistance).asExpression()
                                           if dd.property(QgsPalLayerSettings.Property.LabelDistance).isActive() else "")
                if near is not None:
                    s.dist = near
                    dd.setProperty(QgsPalLayerSettings.Property.LabelDistance, QgsProperty.fromExpression(
                        "if(coalesce(to_int(array_get(map_get(from_json(%s), %s), 1)), 0) = 1, %g, %g)"
                        % (lit, key, near + BP.LADDER_STAGGER_MM, near)))
                s.setDataDefinedProperties(dd)
                if s.placement == Qgis.LabelPlacement.OverPoint:
                    s.placement = Qgis.LabelPlacement.AroundPoint
        elif kind == "pole_pon":
            cur = s.fieldName if s.isExpression else (s.fieldName or "")
            if not (s.isExpression and cur.startswith("regexp_replace(regexp_replace(to_string(")):
                s.fieldName = BP.short_pole_line_expr(names, cur, s.isExpression)
                s.isExpression = True
            fmt = s.format()
            if fmt.sizeUnit() != Qgis.RenderUnit.Points or fmt.size() > BP.POLE_PT:
                fmt.setSize(BP.POLE_PT)
                fmt.setSizeUnit(Qgis.RenderUnit.Points)
            try:
                b = fmt.buffer()
                if b.enabled() and (b.sizeUnit() != Qgis.RenderUnit.Millimeters or b.size() > BP.POLE_BUF_MM):
                    b.setSize(BP.POLE_BUF_MM)
                    b.setSizeUnit(Qgis.RenderUnit.Millimeters)
                    fmt.setBuffer(b)
            except Exception:
                _swallowed_note()
            s.setFormat(fmt)
            try:                              # the operator's data-defined size would undo the cap
                dd = s.dataDefinedProperties()
                dd.setProperty(QgsPalLayerSettings.Property.Size, QgsProperty())
                s.setDataDefinedProperties(dd)
            except Exception:
                _swallowed_note()
        elif kind == "pon_bh":
            # the backhaul page shows the zones small: the short page name ('PON 001') there only
            cur = s.fieldName if s.isExpression else BP.sql_ident(s.fieldName or "")
            e = BP.page_text_expr(arg[0], arg[1], cur)
            if e:
                s.fieldName = e
                s.isExpression = True
            key = QgsPalLayerSettings.Property.Size
            dd = s.dataDefinedProperties()
            old = dd.property(key)
            ours = old.isActive() and (old.asExpression() or "").startswith("if(coalesce(attribute(@atlas_feature,'seq'),-1) = ")
            if not old.isActive() or ours:
                base = "%g" % s.format().size()
                e2 = BP.page_size_expr(arg[0], BP.BH_PON_PT, base)
                if e2 and (not ours or old.asExpression() != e2):
                    dd.setProperty(key, QgsProperty.fromExpression(e2))
                    s.setDataDefinedProperties(dd)
        elif kind == "fap":
            e = BP.splitter_label_expr(names, layer_name, s.fieldName or "")
            if e:
                s.fieldName = e
                s.isExpression = True
            s.setFormat(size_at(s.format(), hi=6.0))
            nm = BP.splitter_name_field(names)
            if arg and nm:                    # splitters sharing a joint: one label per joint
                key = QgsPalLayerSettings.Property.Show
                dd = s.dataDefinedProperties()
                old = dd.property(key)
                want = BP.splitter_show_expr(nm)
                if not old.isActive() or (old.asExpression() or "").startswith("$id = minimum("):
                    dd.setProperty(key, QgsProperty.fromExpression(want))
                    s.setDataDefinedProperties(dd)
        elif kind == "cable":
            if not s.isExpression and not BP.cable_field_ok(s.fieldName, names):
                f = BP.cable_name_field(names)
                if f:
                    s.fieldName = f
            s.setFormat(size_at(s.format(), lo=BP.CABLE_PT, hi=BP.CABLE_PT))
            if s.placement not in (Qgis.LabelPlacement.Line, Qgis.LabelPlacement.Curved):
                s.placement = Qgis.LabelPlacement.Line      # along the cable, like Cradock p3
            s.priority = 9                                  # the one cable name goes first; pole numbers fit round it
            s.labelPerPart = False                          # a cable's name once, not once per part (Fouriesburg)
            s.repeatDistance = 0                            # ... and not repeated along the line
            try:
                ls = s.lineSettings()
                ls.setPlacementFlags(Qgis.LabelLinePlacementFlag.AboveLine |
                                     Qgis.LabelLinePlacementFlag.BelowLine)
                ls.setOverrunDistance(10.0)
                ls.setOverrunDistanceUnit(Qgis.RenderUnit.Millimeters)
                s.setLineSettings(ls)
                ps = s.placementSettings()
                ps.setAllowDegradedPlacement(True)
                s.setPlacementSettings(ps)
            except Exception:
                _swallowed_note()
        return s
    return fn


def _joint_duplicates(src):
    """True when two splitters share one joint (same place, same name) - Cradock 0218DJ SP08/09."""
    nm = BP.splitter_name_field(src.fields().names())
    if not nm or src.featureCount() > BP.LADDER_MAX:
        return False
    seen = set()
    for f in src.getFeatures():
        if not f.hasGeometry():
            continue
        k = (f.geometry().asWkt(6), str(f[nm]))
        if k in seen:
            return True
        seen.add(k)
    return False


def _ladder_map(src, p):
    """(JSON literal, key expression) giving each pole of `src` its ladder rotation, keyed by
    geometry (the isolate key) so the label copy finds it without any overlay at render time.
    None for a layer too big or empty."""
    try:
        if src.featureCount() > BP.LADDER_MAX:
            return None
        key_expr, keys = _iso_keys(src)
        if not keys:
            return None
        tr = QgsCoordinateTransform(src.crs(), p.crs(), p) if p.crs().isValid() and p.crs() != src.crs() else None
        items = []
        for _fid, (k, g) in keys.items():
            c = g.centroid().asPoint()
            if tr is not None:
                c = tr.transform(c)
            items.append((k, (c.x(), c.y())))
        lay_out = BP.ladder_layout([xy for _k, xy in items])
        m = {k: [r, st] for (k, _xy), (r, st) in zip(items, lay_out)}
        lit = "'" + json.dumps(m, sort_keys=True, separators=(",", ":")).replace("\\", "\\\\").replace("'", "''") + "'"
        return lit, key_expr
    except Exception:
        _swallowed_note()
        return None


def _obstacle_renderer(cl, src, only_when=None):
    """The label copy gets a fully transparent copy of the live layer's symbols: nothing more is
    drawn, but the labelling engine now sees every pole's real symbol size and keeps the short
    labels off the poles (Botshabelo page 1: 11 labels over poles -> 0). Book copies only."""
    from qgis.core import QgsRenderContext
    try:
        r = src.renderer().clone()
        for sym in r.symbols(QgsRenderContext()):
            sym.setOpacity(0.0)
        if only_when:                         # gate every symbol behind one rule (e.g. overview pages)
            from qgis.core import QgsRuleBasedRenderer
            rb = QgsRuleBasedRenderer.convertFromRenderer(r)
            if rb is None:
                return
            root = rb.rootRule()
            gate = QgsRuleBasedRenderer.Rule(None, 0, 0, only_when, "vf_obstacle_gate")
            for ch in list(root.children()):
                gate.appendChild(root.takeChild(ch))
            root.appendChild(gate)
            # elsewhere a speck, still transparent: the feature must be RENDERED or QGIS registers
            # no label for it at all (a gate alone dropped every FAP label on the PON pages)
            from qgis.core import QgsMarkerSymbol
            speck = QgsMarkerSymbol.createSimple({"size": "0.01", "color": "0,0,0,0", "outline_style": "no"})
            speck.setOpacity(0.0)
            root.appendChild(QgsRuleBasedRenderer.Rule(speck, 0, 0, "", "vf_obstacle_else", "", True))
            r = rb
        cl.setRenderer(r)
    except Exception:
        _swallowed_note()


def _is_fap_name(name):
    low, tight = BP._role_name(name)
    return any(w in low or w.replace(" ", "") in tight
               for w in ("fap", "16way", "16 way", "1:16", "feeder joint", "link joint", "splitter"))


def _label_scale_limit(cl, src, keep=False):
    """Tick on: a sheet prints every label it was asked for, at whatever scale the page falls - the
    project's 'labels only below 1:9000' (Cradock's poles) hid every pole number on the backhaul page,
    and hidden labels are not even counted as missed. Tick off: the source layer's limit again. Book's
    own copy only."""
    limits = []

    def read(st):
        limits.append((st.scaleVisibility, st.minimumScale, st.maximumScale))
        return st
    if keep and isinstance(src, QgsVectorLayer) and src.labeling() is not None:
        _map_label_settings(src.labeling().clone(), read)
    use = limits[0] if limits else (False, 0.0, 0.0)

    def fn(st):
        st = QgsPalLayerSettings(st)
        st.scaleVisibility, st.minimumScale, st.maximumScale = use
        return st
    lab = cl.labeling().clone()
    _map_label_settings(lab, fn)
    cl.setLabeling(lab)
    if keep and isinstance(src, QgsVectorLayer):
        cl.setScaleBasedVisibility(src.hasScaleBasedVisibility())
    else:
        cl.setScaleBasedVisibility(False)


def label_report(layout, spec=None, project=None, dpi=150, tick=None):
    """The check after a PDF export, read from QGIS's own PDF exporter page by page (the only measure
    that matched the real PDF on QGIS 3.38): which labels did not print, which overlap each other,
    which touch a point symbol. tick() between pages keeps the window alive; it returns False to stop.
    Returns [{title, placed, missing, overlaps, over_symbols}]."""
    import tempfile
    from qgis.core import QgsLayoutExporter, QgsSpatialIndex, QgsFeature, QgsRenderContext, QgsRectangle
    p = project or QgsProject.instance()
    spec = spec or get_spec(layout) or {}
    m = book_map(layout)
    at = layout.atlas()
    fd, tmp = tempfile.mkstemp(suffix=".pdf", prefix="vf_label_check_")
    os.close(fd)
    rows = []
    settings = QgsLayoutExporter.PdfExportSettings()
    settings.dpi = dpi
    try:
        at.beginRender()
        titles = {int(f["seq"]): str(f["page_title"]) for f in at.coverageLayer().getFeatures()}
        for i in range(at.count()):
            if tick is not None and tick(i) is False:
                break
            at.seekTo(i)
            m.refresh()
            ex = QgsLayoutExporter(layout)
            ex.exportToPdf(tmp, settings)
            res = ex.labelingResults().get(m.uuid())
            upm = m.extent().width() / m.rect().width()
            placed, missing = [], []
            for lp in (res.allLabels() if res is not None else []):
                if lp.isUnplaced:
                    missing.append(str(lp.labelText))
                else:
                    g = lp.labelGeometry if lp.labelGeometry is not None and not lp.labelGeometry.isEmpty() \
                        else QgsGeometry.fromRect(lp.labelRect)
                    placed.append((QgsGeometry(g), lp.layerID, int(lp.featureId), str(lp.labelText)))
            idx = QgsSpatialIndex()
            for n, (g, _l, _f, _t) in enumerate(placed):
                fe = QgsFeature(n)
                fe.setGeometry(g)
                idx.addFeature(fe)
            tol = 0.1 * upm * upm                 # 0.1 mm2 on paper: a rounding touch is not an overlap
            overlaps = 0
            for n, (g, _l, _f, _t) in enumerate(placed):
                for k in idx.intersects(g.boundingBox()):
                    if k > n and placed[k][1:3] != placed[n][1:3]:   # a curved label's own letters touch
                        inter = g.intersection(placed[k][0])
                        if inter is not None and not inter.isEmpty() and inter.area() > tol:
                            overlaps += 1
            touching = set()
            for lyr in m.layersToRender():
                if (not isinstance(lyr, QgsVectorLayer) or is_book_layer(lyr) or _kind(lyr) != "point"
                        or lyr.crs() != m.crs() or lyr.renderer() is None):
                    continue
                rc = QgsRenderContext()
                rnd = lyr.renderer().clone()
                rnd.startRender(rc, lyr.fields())
                for f in lyr.getFeatures(m.extent()):
                    sym = rnd.symbolForFeature(f, rc)
                    if sym is None or not f.hasGeometry():
                        continue
                    pt = f.geometry().centroid().asPoint()
                    try:
                        half = float(sym.size()) * upm / 2.0
                    except Exception:
                        half = 1.0 * upm
                    box = QgsRectangle(pt.x() - half, pt.y() - half, pt.x() + half, pt.y() + half)
                    bg = QgsGeometry.fromRect(box)
                    for k in idx.intersects(box):
                        g, lid, fid, _t = placed[k]
                        cl = p.mapLayer(lid)
                        own = cl is not None and str(cl.customProperty("vf_book_label_source") or "") == lyr.id() \
                            and fid == f.id()
                        if own:
                            continue
                        inter = g.intersection(bg)
                        if inter is not None and not inter.isEmpty() and inter.area() > tol:
                            touching.add(k)
                rnd.stopRender(rc)
            rows.append({"title": titles.get(i, "page %d" % (i + 1)), "placed": len({x[1:3] for x in placed}),
                         "missing": missing, "overlaps": overlaps, "over_symbols": len(touching),
                         "printed_twice": BP.label_printed_twice([x[1:] for x in placed])})
    finally:
        at.endRender()
        try:
            os.remove(tmp)
        except OSError:
            pass
    return rows


def _tune_label_copies(spec, p, info):
    """v2 on the book's own label copies (live layers untouched): short pole numbers on the
    backhaul page, FAP splitter + ratio, a cable-name field for cables labelled on overview pages
    when the copy's field does not exist, and the 'Phase 1' label on the phase outline."""
    roles = (spec.get("asbuilt") or {}).get("roles") or {}
    fap_ids = set(roles.get("fap") or [])
    pole_ids = set(roles.get("poles") or []) | set(roles.get("existing_pole") or [])
    univ = bool((spec.get("asbuilt_fix") or {}).get(UNIV_MARK))   # books built before keep their PON-page labels
    bh = info["page"] if info else None
    bh_labels = set(spec["overview"][bh]["labels"]) if bh is not None else set()
    on_ov = set()
    for pg in spec["overview"]:
        on_ov |= set(pg["labels"])
    ol = _phase_outline(spec, p, _srid_crs(spec), skip_page=bh)
    ladder_ids, obstacle_ids = set(), set()
    code_hint = _project_code(spec, p) if univ else ""
    for src_id, lab_id in (spec.get("label_layers") or {}).items():
        src, cl = p.mapLayer(src_id), p.mapLayer(lab_id)
        if not (isinstance(src, QgsVectorLayer) and src.isValid() and isinstance(cl, QgsVectorLayer)
                and cl.isValid() and cl.labeling() is not None):
            continue
        k, names, kind = None, src.fields().names(), _kind(src)
        arg = ol["text"] if ol is not None else None
        if src_id == spec.get("pon_layer_id"):
            tf = _title_field_now(spec, p)
            k, arg = ("pon_bh", (bh, tf)) if (bh is not None and src_id in bh_labels and tf) else ("polygon", None)
        elif ol is not None and ol["text"] and src_id == ol["layer"].id():
            k = "phase"
        elif (kind == "point" and src_id in bh_labels and "pole" in src.name().lower() and src_id not in fap_ids
              and not (univ and src_id in (spec["pon"]["labels"] or []))):
            k, arg = "pole", _ladder_map(src, p)
            ladder_ids.add(src_id)
        elif (univ and kind == "point" and src_id in (spec["pon"]["labels"] or []) and src_id in pole_ids
              and src_id not in fap_ids):
            k, arg = "pole_pon", None         # PON pages: the short pole number, like Cradock's sheets
        elif kind == "point" and src_id in on_ov and (src_id in fap_ids or _is_fap_name(src.name())):
            k, arg = "fap", _joint_duplicates(src)
        elif kind == "line" and (src_id in on_ov or (univ and src_id in (spec["pon"]["labels"] or []))):
            k = "cable"                       # along the cable, overrun + fallback: short spans keep their name
        hide = _tiein_twin_expr(info, src_id, src, p)
        strip = univ and src_id != spec.get("pon_layer_id") and k != "phase"
        if k is None and not hide and not strip:
            continue
        lab = cl.labeling().clone()
        if univ:
            lab = _unwrap_round2(lab)         # a Rebuild seeds the copy with our last wraps: start clean
        if k is not None:
            _map_label_settings(lab, _label_fix(k, names, src.name(), arg))
        if hide and hide not in _show_text(lab):
            lab = _with_show(lab, hide)
        if src_id == spec.get("pon_layer_id"):
            lab = _pon_label_fallback(spec, p, src, lab)
        if strip:
            lab = _strip_code_prefix(lab, src, p, hint=code_hint)
        if univ and kind == "point" and src_id != spec.get("pon_layer_id"):
            lab = _dup_combine(lab, src, p)
        if univ:
            lab = _detail_hide(lab, spec, src_id, src)
        cl.setLabeling(lab)
        if k == "pole" and src_id not in (spec["pon"]["ids"] or []):
            _obstacle_renderer(cl, src)
        if k == "fap" and BP.FAP_OBSTACLE:
            _obstacle_renderer(cl, src)
        if univ and k == "pole_pon":
            # universality books: the PON pages' pole copy carries the live pole symbols, transparent,
            # so no label is placed over a pole (Cradock 169 -> 3 labels over symbols). Poles only:
            # CTP / FAP symbols as obstacles left no room for the pole label on their own pole
            # (Middelburg 0 -> 133 dropped labels, measured)
            _obstacle_renderer(cl, src)
            obstacle_ids.add(src_id)
        elif univ and kind == "point" and src_id != spec.get("pon_layer_id") and k != "pole" \
                and src_id in on_ov:
            # FAP / CTP symbols keep labels off them on the OVERVIEW pages only (a rule-gated copy):
            # on PON pages they left no room for the pole label on their own pole (Middelburg)
            _obstacle_renderer(cl, src, BP.OVERVIEW_ONLY_FILTER)
        cl.triggerRepaint()
    if univ:
        _clear_shared_symbols(spec, p, ladder_ids, obstacle_ids)


def _clear_shared_symbols(spec, p, skip_ids=(), obstacle_ids=()):
    """Universality books: a point label must clear the obstacle symbols on its spot, not just its
    own: a CTP / splitter drawn on a pole whose symbol is an obstacle (obstacle_ids) - each point's
    label distance becomes at least that symbol's radius + 0.4 mm, on top of the
    copy's own distance (its data-defined one too: Middelburg's labels moved by hand carry a stored
    distance). Book copy only, a data-defined distance keyed by geometry; others are untouched."""
    from qgis.core import Qgis, QgsSpatialIndex, QgsFeature, QgsFeatureRequest, QgsExpression, \
        QgsExpressionContext, QgsExpressionContextUtils
    pon_id = spec.get("pon_layer_id")
    metric = _metric_crs(spec)
    pts = []
    for src_id, lab_id in (spec.get("label_layers") or {}).items():
        src, cl = p.mapLayer(src_id), p.mapLayer(lab_id)
        if (src_id != pon_id and src_id not in skip_ids and isinstance(src, QgsVectorLayer) and src.isValid()
                and _kind(src) == "point" and isinstance(cl, QgsVectorLayer) and cl.isValid()
                and cl.labeling() is not None and src.featureCount() <= BP.DUP_MAX):
            pts.append((src, cl, _marker_half_mm(src)))
    if len(pts) < 2 or not any(s_.id() in obstacle_ids for s_, _c, _h in pts):
        return
    try:
        layer_pts = []
        for src, cl, half in pts:
            tr = QgsCoordinateTransform(src.crs(), metric, p)
            idx, xy = QgsSpatialIndex(), {}
            for f in src.getFeatures(QgsFeatureRequest().setNoAttributes()):
                if not f.hasGeometry() or f.geometry().isEmpty():
                    continue
                g = QgsGeometry(f.geometry())
                g.transform(tr)
                c = g.centroid().asPoint()
                q = QgsFeature(f.id())
                q.setGeometry(QgsGeometry.fromPointXY(c))
                idx.addFeature(q)
                xy[f.id()] = c
            layer_pts.append((idx, xy, half))
    except Exception:
        _swallowed_note()
        return
    tol = BP.COINCIDE_M
    key_d = getattr(QgsPalLayerSettings, "Property", QgsPalLayerSettings).LabelDistance
    for n, (src, cl, half) in enumerate(pts):
        lab = cl.labeling().clone()
        if lab.type() != "simple":
            continue
        st = QgsPalLayerSettings(lab.settings())
        if st.placement != Qgis.LabelPlacement.AroundPoint or st.distUnits != Qgis.RenderUnit.Millimeters:
            continue
        dd = st.dataDefinedProperties()
        pr = dd.property(key_d)
        cur = None
        if pr.isActive():
            cur = pr.asExpression() or (QgsExpression.quotedColumnRef(pr.field()) if pr.field() else None)
            if cur is None:
                continue
            cur = BP.unwrap_gap_dist(cur)[0]
        base = float(st.dist)
        try:
            if cur is not None and abs(float(cur) - base) < 1e-9:
                cur = None                             # our own wrap of the plain distance
        except (TypeError, ValueError):
            pass
        need = {}
        _idx_l, xy_l, _h = layer_pts[n]
        for fid, c in xy_l.items():
            want = 0.0
            for m_i, (idx, xy, h_m) in enumerate(layer_pts):
                if m_i == n or pts[m_i][0].id() not in obstacle_ids:
                    continue
                r = QgsRectangle(c.x() - tol, c.y() - tol, c.x() + tol, c.y() + tol)
                if any(xy[j].distance(c) <= tol for j in idx.intersects(r)):
                    want = max(want, h_m + 0.4)
            if want > 0 and (cur is not None or want > base + 1e-6):
                need[fid] = round(want, 2)
        key = BP.iso_key_expr(src.crs().isGeographic())
        m = {}
        if need:
            ex = QgsExpression(key)
            ctx = QgsExpressionContext(QgsExpressionContextUtils.globalProjectLayerScopes(src))
            ex.prepare(ctx)
            for f in src.getFeatures(QgsFeatureRequest().setFilterFids(list(need)).setNoAttributes()):
                ctx.setFeature(f)
                kv = ex.evaluate(ctx)
                if not _null(kv):
                    m[str(kv)] = max(m.get(str(kv), 0.0), need[f.id()])
        if m:
            dd.setProperty(key_d, QgsProperty.fromExpression(
                BP.gap_dist_expr(BP.json_lit(m), key, cur if cur is not None else "%g" % base, base)))
        elif cur is not None:
            dd.setProperty(key_d, QgsProperty.fromExpression(cur))
        else:
            dd.setProperty(key_d, QgsProperty())
        st.setDataDefinedProperties(dd)
        lab.setSettings(st)
        cl.setLabeling(lab)


def _dd_size_key():
    return getattr(QgsPalLayerSettings, "Property", QgsPalLayerSettings).Size


def _unwrap_round2(lab):
    """Undo our round-2 wraps on a label copy's labelling (dup text + its Show part, fit size)."""
    key_show = getattr(QgsPalLayerSettings, "Property", QgsPalLayerSettings).Show

    def fn(st):
        st = QgsPalLayerSettings(st)
        try:
            if st.isExpression:
                inner, was = BP.unwrap_dup_text(st.fieldName)
                if was:
                    st.fieldName = inner
                    dd = st.dataDefinedProperties()
                    pr = dd.property(key_show)
                    if pr.isActive() and pr.asExpression():
                        rest = BP.remove_dup_show(pr.asExpression(), inner)
                        dd.setProperty(key_show, QgsProperty.fromExpression(rest) if rest else QgsProperty())
                        st.setDataDefinedProperties(dd)
            dd = st.dataDefinedProperties()
            pr = dd.property(key_show)
            if pr.isActive() and pr.asExpression() and BP.remove_detail_hide(pr.asExpression()) != pr.asExpression():
                rest = BP.remove_detail_hide(pr.asExpression())
                dd.setProperty(key_show, QgsProperty.fromExpression(rest) if rest else QgsProperty())
                st.setDataDefinedProperties(dd)
            dd = st.dataDefinedProperties()
            pr = dd.property(_dd_size_key())
            if pr.isActive() and pr.asExpression():
                base, was = BP.unwrap_fit_size(pr.asExpression())
                if was:
                    dd.setProperty(_dd_size_key(), QgsProperty() if _is_static_size(base, st)
                                   else QgsProperty.fromExpression(base))
                    st.setDataDefinedProperties(dd)
        except Exception:
            _swallowed_note()
        return st
    lab = lab.clone()
    _map_label_settings(lab, fn)
    return lab


def _is_static_size(base, st):
    """True when a fit wrap's base is just the format's own size (we wrote it: no expression before)."""
    try:
        return abs(float(base) - float(st.format().size())) < 1e-9
    except (TypeError, ValueError):
        return False


def _dup_combine(lab, src, p):
    """Universality books: points drawn on one spot (two poles captured twice, Lulekani 3200PL +
    3201PL) get ONE label listing every text ('3200PL / 3201PL') instead of one label the page has no
    room for. Book copy only, simple labelling only; keyed by geometry, never the fid."""
    from qgis.core import QgsExpression, QgsExpressionContext, QgsExpressionContextUtils, QgsFeatureRequest
    if lab.type() != "simple" or src.featureCount() > BP.DUP_MAX or src.featureCount() < 2:
        return lab
    st = lab.settings()
    text = st.fieldName if st.isExpression else QgsExpression.quotedColumnRef(st.fieldName or "")
    if not text:
        return lab
    key = BP.iso_key_expr(src.crs().isGeographic())
    try:
        ctx = QgsExpressionContext()
        ctx.appendScope(QgsExpressionContextUtils.globalScope())
        ctx.appendScope(QgsExpressionContextUtils.projectScope(p))
        ctx.appendScope(QgsExpressionContextUtils.layerScope(src))
        ex_t, ex_k = QgsExpression(text), QgsExpression(key)
        if ex_t.hasParserError() or ex_k.hasParserError():
            return lab
        ex_t.prepare(ctx)
        ex_k.prepare(ctx)
        items = []
        for f in src.getFeatures(QgsFeatureRequest()):
            if not f.hasGeometry():
                continue
            ctx.setFeature(f)
            kv, tv = ex_k.evaluate(ctx), ex_t.evaluate(ctx)
            if ex_t.hasEvalError():
                return lab
            items.append((None if _null(kv) else str(kv), None if _null(tv) else str(tv)))
        groups = BP.dup_groups(items)
    except Exception:
        _swallowed_note()
        return lab
    if not groups:
        return lab
    lit = BP.json_lit(groups)
    st = QgsPalLayerSettings(st)
    st.fieldName = BP.dup_text_expr(lit, key, text)
    st.isExpression = True
    lab = lab.clone()
    lab.setSettings(st)
    return _with_show(lab, BP.dup_show_expr(lit, key, text))


def _page_unplaced(m, ids, dpi=150, found=None):
    """Book labels the engine could not place on the CURRENT atlas page: the map item's own map
    settings (page extent, layers, style overrides, scale) rendered off-screen at `dpi` with the
    vector layers only - labels never depend on a raster, and the basemap is never fetched.
    found (a list) collects (label layer id, feature id) of each label left out."""
    from qgis.core import QgsMapRendererCustomPainterJob, QgsLabelingEngineSettings
    from qgis.PyQt.QtCore import QSize, QSizeF
    from qgis.PyQt.QtGui import QImage, QPainter, QColor
    w = max(1, int(round(m.rect().width() * dpi / 25.4)))
    h = max(1, int(round(m.rect().height() * dpi / 25.4)))
    ms = m.mapSettings(m.extent(), QSizeF(w, h), dpi, True)
    ms.setOutputSize(QSize(w, h))
    ms.setLayers([l for l in ms.layers() if isinstance(l, QgsVectorLayer)])
    les = ms.labelingEngineSettings()
    les.setFlag(QgsLabelingEngineSettings.Flag.CollectUnplacedLabels, True)
    ms.setLabelingEngineSettings(les)
    img = QImage(QSize(w, h), QImage.Format.Format_ARGB32)
    img.fill(QColor(255, 255, 255))
    pa = QPainter(img)
    try:
        job = QgsMapRendererCustomPainterJob(ms, pa)
        job.renderSynchronously()
    finally:
        pa.end()
    res = job.takeLabelingResults()
    if res is None:
        return 0
    n = 0
    for lp in res.allLabels():
        if lp.isUnplaced and lp.layerID in ids:
            n += 1
            if found is not None:
                found.append((lp.layerID, int(lp.featureId)))
    return n


def _fit_size_fn(factors):
    from qgis.core import Qgis

    def fn(st):
        st = QgsPalLayerSettings(st)
        fmt = st.format()
        u = fmt.sizeUnit()
        floor = (BP.FIT_FLOOR_PT if u == Qgis.RenderUnit.Points else
                 BP.FIT_FLOOR_MM if u == Qgis.RenderUnit.Millimeters else None)
        if floor is None:
            return st
        dd = st.dataDefinedProperties()
        pr = dd.property(_dd_size_key())
        cur = pr.asExpression() if pr.isActive() and pr.asExpression() else None
        base, was = BP.unwrap_fit_size(cur) if cur else ("%g" % fmt.size(), False)
        e = BP.fit_size_expr(base, floor, factors)
        if e:
            dd.setProperty(_dd_size_key(), QgsProperty.fromExpression(e))
        elif was:
            dd.setProperty(_dd_size_key(), QgsProperty() if _is_static_size(base, st)
                           else QgsProperty.fromExpression(base))
        st.setDataDefinedProperties(dd)
        return st
    return fn


def _short_pages_fn(short):
    def fn(st):
        if st.isExpression and BP.has_short_pages(st.fieldName):
            st = QgsPalLayerSettings(st)
            st.fieldName = BP.set_short_pages(st.fieldName, short)
        return st
    return fn


def _fit_pass(layout, spec, p, factors, only=None, cables=None, short=None):
    """One fit run: start from `factors` ({page seq: factor}), measure the pages (`only`, else every
    page), shrink the crowded ones step by step. Returns (factors, misses, found) or None.
    `cables` (a dict) collects {page seq: cable names with no room}; those never shrink a page."""
    cables = {} if cables is None else cables
    short = set() if short is None else short      # pages whose labels drop the project code
    copies = [l for l in (p.mapLayer(i) for i in (spec.get("label_layers") or {}).values())
              if isinstance(l, QgsVectorLayer) and l.isValid() and l.labeling() is not None]
    m = book_map(layout)
    at = layout.atlas()
    if not copies or m is None or not at.enabled():
        return None
    ids = {l.id() for l in copies}
    lines = {l.id() for l in copies if _kind(l) == "line"}
    n_ov = len(spec["overview"])
    factors = dict(factors or {})
    found = {}

    def apply():
        for cl in copies:
            lab = cl.labeling().clone()
            _map_label_settings(lab, _fit_size_fn(factors))
            _map_label_settings(lab, _short_pages_fn(short))
            cl.setLabeling(lab)
        sync_overrides(layout, spec, p)       # the map's style copies snapshot the label copies

    def stub(item):
        """True when this unplaced label is a cable with only a short piece on the current page."""
        if item[0] not in lines:
            return False
        try:
            cl = p.mapLayer(item[0])
            g = _in_crs(cl.getFeature(item[1]).geometry(), cl.crs(), m.crs(), p)
            ext = m.extent()
            inside = g.intersection(QgsGeometry.fromRect(ext))
            return inside.length() / (ext.width() / m.rect().width()) < BP.CABLE_STUB_MM
        except Exception:
            _swallowed_note()
            return False

    def measure(pages):
        out = {}
        at.beginRender()
        try:
            for i in pages:
                at.seekTo(i)
                f = []
                _page_unplaced(m, ids, found=f)
                # a cable stub at the map edge cannot hold its name (the cable is named on its own
                # page): that must not shrink every other label on the sheet (Cradock PON 01: 58%)
                found[i] = f if i < n_ov else [x for x in f if not stub(x)]
                cables[i] = len(f) - len(found[i])
                out[i] = len(found[i])
        finally:
            at.endRender()
        return out
    apply()
    at.updateFeatures()
    pages = list(only) if only is not None else list(range(at.count()))
    miss = measure(pages)
    tight = [i for i in pages if miss[i] > 0 or cables.get(i)]
    if tight:                                 # 1st: this page only, drop the project code from the names
        short.update(tight)
        apply()
        miss.update(measure(tight))
    pending = [i for i in pages if miss[i] > 0]
    for step in BP.FIT_STEPS:  # 2nd: smaller labels. A cable name with no room never shrinks a page
        if not pending:
            break
        for i in pending:
            factors[i] = step
        apply()
        miss.update(measure(pending))
        pending = [i for i in pending if miss[i] > 0]
    return factors, miss, found


def _drop_details(layout, spec, p):
    """Remove the detail pages a previous build added (they are re-made from the data now)."""
    titles = {d.get("title") for d in spec.get("auto_details") or []}
    spec["overview"] = [pg for pg in spec["overview"] if pg["title"] not in titles]
    spec["auto_details"] = []
    update_book(layout, spec, fit=False)
    new = get_spec(layout)
    spec.clear()
    spec.update(new)


def _add_details(layout, spec, p, crowded, found):
    """Detail pages after each crowded overview page, framed on the features whose labels found no
    room there (BP.detail_frames); on the overview those labels step aside for the detail page.
    Returns {overview index: pages added}."""
    from qgis.core import QgsExpression, QgsExpressionContext, QgsExpressionContextUtils
    dest = _srid_crs(spec)
    m = book_map(layout)
    at = layout.atlas()
    boxes = {}
    at.beginRender()
    try:
        for i in crowded:
            at.seekTo(i)
            boxes[i] = QgsCoordinateTransform(m.crs(), dest, p).transformBoundingBox(m.extent())
    finally:
        at.endRender()
    new_ov = [dict(pg) for pg in spec["overview"]]
    dets, added = [], {}
    for i in sorted(crowded, reverse=True):
        pts, hide = [], {}
        for lid, fid in found.get(i) or []:
            cl = p.mapLayer(lid)
            if not isinstance(cl, QgsVectorLayer):
                continue
            src_id = str(cl.customProperty("vf_book_label_source") or "")
            f = cl.getFeature(fid)
            if not src_id or not f.isValid() or not f.hasGeometry():
                continue
            c = _in_crs(f.geometry().centroid(), cl.crs(), dest, p).asPoint()
            pts.append((c.x(), c.y()))
            ex = QgsExpression(BP.iso_key_expr(cl.crs().isGeographic()))
            ctx = QgsExpressionContext(QgsExpressionContextUtils.globalProjectLayerScopes(cl))
            ctx.setFeature(f)
            kv = ex.evaluate(ctx)
            if not _null(kv):
                hide.setdefault(src_id, set()).add(str(kv))
        b = boxes[i]
        fr = BP.detail_frames(pts, (b.xMinimum(), b.yMinimum(), b.xMaximum(), b.yMaximum()))
        if not fr:
            continue
        pg = spec["overview"][i]
        for k, box in enumerate(fr, 1):
            t = BP.detail_title(pg["title"], k, len(fr))
            outline = _phase_outline(spec, p, _srid_crs(spec))       # a zoom-in does not need the phase name
            out_id = outline["layer"].id() if outline is not None else ""
            new_ov.insert(i + k, BP.make_page(t, [x for x in pg["ids"] if x != out_id],
                                              [x for x in pg["labels"] if x != out_id], pg.get("note", "")))
            dets.append({"title": t, "of": pg["title"], "wkt": QgsGeometry.fromRect(QgsRectangle(*box)).asWkt(9),
                         "hide": {s: sorted(v) for s, v in hide.items()} if k == 1 else {}})
        added[i] = len(fr)
    if not added:
        return {}
    spec["overview"] = new_ov
    spec["auto_details"] = list(spec.get("auto_details") or []) + dets
    update_book(layout, spec, fit=False)
    new = get_spec(layout)
    spec.clear()
    spec.update(new)
    return added


def _detail_hide(lab, spec, src_id, src):
    """Show parts: on an overview page with detail pages, the labels the detail pages carry."""
    dets = spec.get("auto_details") or []
    if not dets:
        return lab
    titles = [pg["title"] for pg in spec["overview"]]
    by_main = {}
    for d in dets:
        keys = (d.get("hide") or {}).get(src_id) or []
        if keys and d.get("of") in titles:
            by_main.setdefault(titles.index(d["of"]), set()).update(keys)
    key = BP.iso_key_expr(src.crs().isGeographic())
    for i, ks in sorted(by_main.items()):
        lab = _with_show(lab, BP.detail_hide_expr(i, BP.json_lit({k: 1 for k in sorted(ks)}), key))
    return lab


def _fit_labels(layout, spec, p, details=True):
    """Universality books: a page that drops a book label (a whole-town Feeder Overview, 68 FAPs +
    68 zones; a PON page with poles a metre apart) shrinks every book label ON THAT PAGE by
    BP.FIT_STEPS in turn until all fit, never below BP.FIT_FLOOR_PT; pages that already fit keep
    their sizes. An overview page still too crowded at the smallest size gets detail pages right
    after it (3x the scale) that carry the labels it had no room for. Book copies only (a
    data-defined size per page); live layers untouched. `spec` is updated in place.
    Returns message lines."""
    asb = spec.get("frame_kind") == BP.FRAME_ASBUILT
    if not asb or not (spec.get("asbuilt_fix") or {}).get(UNIV_MARK):
        return []                                 # the A3 book draws live labels; a book built before keeps what it has
    on = BP.label_fit_on(spec)
    copies = [(p.mapLayer(s), p.mapLayer(c)) for s, c in (spec.get("label_layers") or {}).items()]
    copies = [(s, c) for s, c in copies if isinstance(c, QgsVectorLayer) and c.isValid() and c.labeling() is not None]
    for s, c in copies:
        _label_scale_limit(c, s, keep=not on)
    if not on:
        if asb and spec.get("auto_details"):
            _drop_details(layout, spec, p)
        for s, c in copies:
            lab = c.labeling().clone()
            _map_label_settings(lab, _fit_size_fn({}))
            _map_label_settings(lab, _short_pages_fn(()))
            c.setLabeling(lab)
        sync_overrides(layout, spec, p)
        return []
    details = details and asb                     # detail pages are an As-Built sheet's
    msgs = []
    cables = {}
    short = set()
    try:
        if details and spec.get("auto_details"):
            _drop_details(layout, spec, p)
        res = _fit_pass(layout, spec, p, {}, cables=cables, short=short)
        if res is None:
            return []
        factors, miss, found = res
        names, n_added = [], 0
        for _round in range(BP.DETAIL_ROUNDS if details else 0):
            n_ov = len(spec["overview"])
            crowded = [i for i in range(n_ov) if miss.get(i)]
            if not crowded:
                break
            names += [spec["overview"][i]["title"] for i in crowded]
            added = _add_details(layout, spec, p, crowded, found)
            if not added:
                break
            n_added += sum(added.values())

            def moved(j, added=added):
                return j + sum(n for i, n in added.items() if i < j)
            keep_f = {moved(k): v for k, v in factors.items() if k >= n_ov}
            keep_m = {moved(k): v for k, v in miss.items() if k >= n_ov}
            cables = {moved(k): v for k, v in cables.items() if k >= n_ov}
            short = {moved(k) for k in short if k >= n_ov}
            res2 = _fit_pass(layout, spec, p, keep_f, range(len(spec["overview"])), cables=cables, short=short)
            if res2 is None:
                break
            factors, miss2, found = res2
            miss = dict(keep_m)
            miss.update(miss2)
        if n_added:
            msgs.append("Too crowded for one sheet: %s - %d detail page(s) added after it, carrying the "
                        "labels the sheet had no room for." % (", ".join("“%s”" % t for t in BP._uniq(names)),
                                                                n_added))
    except Exception:
        _swallowed_note()
        return msgs
    titles = {}
    try:
        for f in layout.atlas().coverageLayer().getFeatures():
            titles[int(f["seq"])] = str(f["page_title"])
    except Exception:
        _swallowed_note()
    if short:
        msgs.append("Names shortened on these pages only (the project code taken off), so every label fits: %s."
                    % ", ".join(titles.get(i, "page %d" % (i + 1)) for i in sorted(short)))
    shrunk = {i: f for i, f in factors.items() if f < 1.0}
    if shrunk:
        msgs.append("Labels drawn smaller so every label fits (book copy only): %s." % ", ".join(
            "%s %d%%" % (titles.get(i, "page %d" % (i + 1)), round((1 - f) * 100)) for i, f in sorted(shrunk.items())))
    left = {i: c for i, c in miss.items() if c}
    room = {i: c for i, c in cables.items() if c}
    if room:
        msgs.append("Cable names with no room on the sheet (short piece of cable): %s." % ", ".join(
            "%s (%d)" % (titles.get(i, "page %d" % (i + 1)), c) for i, c in sorted(room.items())))
    if left:
        msgs.append("Still too crowded at the smallest label size: %s." % ", ".join(
            "%s (%d label%s)" % (titles.get(i, "page %d" % (i + 1)), c, "" if c == 1 else "s")
            for i, c in sorted(left.items())))
    return msgs


def _label_values(st, src, p, cap=5000):
    """The texts a label setting gives the first `cap` features of `src` ([] if it cannot be read)."""
    from qgis.core import QgsExpression, QgsExpressionContext, QgsExpressionContextUtils, QgsFeatureRequest
    text = st.fieldName if st.isExpression else QgsExpression.quotedColumnRef(st.fieldName or "")
    if not text:
        return []
    ex = QgsExpression(text)
    if ex.hasParserError():
        return []
    ctx = QgsExpressionContext()
    ctx.appendScope(QgsExpressionContextUtils.globalScope())
    ctx.appendScope(QgsExpressionContextUtils.projectScope(p))
    ctx.appendScope(QgsExpressionContextUtils.layerScope(src))
    ex.prepare(ctx)
    req = QgsFeatureRequest()
    req.setLimit(cap)
    vals = []
    for f in src.getFeatures(req):
        ctx.setFeature(f)
        v = ex.evaluate(ctx)
        if ex.hasEvalError():
            return []
        if not _null(v):
            vals.append(str(v))
    return vals


def _project_code(spec, p):
    """The code most of the book's line layers repeat ('HT_CDKP2_'): a one-cable layer (one Feeder Link)
    has no 'shared' prefix of its own but carries the same code."""
    counts = {}
    for src_id in (spec.get("label_layers") or {}):
        src = p.mapLayer(src_id)
        if not isinstance(src, QgsVectorLayer) or not src.isValid() or _kind(src) != "line" or src.labeling() is None:
            continue
        found = []

        def grab(st, found=found, src=src):
            try:
                f = BP.cable_name_field(src.fields().names())
                if f:
                    probe = QgsPalLayerSettings(st)
                    probe.fieldName, probe.isExpression = f, False
                    found.append(BP.common_code_prefix(_label_values(probe, src, p, 500)))
            except Exception:
                _swallowed_note()
            return st
        _map_label_settings(src.labeling().clone(), grab)
        for pre in found:
            if pre:
                counts[pre] = counts.get(pre, 0) + 1
    return max(sorted(counts), key=lambda k: counts[k]) if counts else ""


def _strip_code_prefix(lab, src, p, cap=5000, hint=""):
    """Universality books: a label copy whose every text repeats the same project code
    ('HT_MFKGP4_DC01_12F_Aerial', 'HT_PABA1_Z1_0059DJ_1SP') drops it on the book's own copy
    ('DC01_12F_Aerial', '0059DJ_1SP') - the sheet's title block already names the project, and the
    shorter text is what lets long cable names fit short spans and a whole-town overview place every
    FAP label. Live layers untouched; a text not starting with the code shows unchanged."""
    from qgis.core import QgsExpression, QgsExpressionContext, QgsExpressionContextUtils, QgsFeatureRequest

    def fn(st):
        text = st.fieldName if st.isExpression else QgsExpression.quotedColumnRef(st.fieldName or "")
        if not text or BP.is_strip_expr(text) or BP.has_short_pages(text):
            return st
        try:
            ex = QgsExpression(text)
            if ex.hasParserError():
                return st
            ctx = QgsExpressionContext()
            ctx.appendScope(QgsExpressionContextUtils.globalScope())
            ctx.appendScope(QgsExpressionContextUtils.projectScope(p))
            ctx.appendScope(QgsExpressionContextUtils.layerScope(src))
            ex.prepare(ctx)
            vals = []
            req = QgsFeatureRequest()
            req.setLimit(cap)
            for f in src.getFeatures(req):
                ctx.setFeature(f)
                v = ex.evaluate(ctx)
                if ex.hasEvalError():
                    return st
                if not _null(v):
                    vals.append(str(v))
            pre = BP.common_code_prefix(vals)
            if not pre and hint and vals and all(v.startswith(hint) and len(v) > len(hint) for v in vals):
                pre = hint
        except Exception:
            _swallowed_note()
            return st
        if not pre:
            return st
        st = QgsPalLayerSettings(st)
        st.fieldName = BP.page_strip_expr(text, pre)
        st.isExpression = True
        return st
    lab = lab.clone()
    _map_label_settings(lab, fn)
    return lab


def _pon_label_fallback(spec, p, pon, lab):
    """Universality: a PON layer whose own label text is blank on every zone (Palm Ridge: KML Name
    column empty) labels its zones on the book copy with the page title column instead, so the
    overview pages are never left with unnamed zones. The operator's text wins whenever it shows."""
    from qgis.core import QgsExpression, QgsExpressionContext, QgsExpressionContextUtils
    fld = _title_field_now(spec, p) or spec.get("pon_label_field") or ""
    if pon.fields().indexOf(fld) < 0 or lab.type() != "simple":
        return lab
    st = lab.settings()
    text = st.fieldName if st.isExpression else QgsExpression.quotedColumnRef(st.fieldName or "")
    if not text or text == QgsExpression.quotedColumnRef(fld):
        return lab
    ex = QgsExpression(text)
    ctx = QgsExpressionContext()
    ctx.appendScope(QgsExpressionContextUtils.layerScope(pon))
    ex.prepare(ctx)
    for i, f in enumerate(pon.getFeatures()):
        if i >= 500:
            break
        ctx.setFeature(f)
        v = ex.evaluate(ctx)
        if not _null(v) and str(v).strip():
            return lab                          # the operator's label shows: keep it
    unit = BP.asbuilt_unit_word(spec)
    q = QgsExpression.quotedColumnRef(fld)
    st = QgsPalLayerSettings(st)
    st.fieldName = ("CASE WHEN lower(trim(to_string(%s))) LIKE lower(%s) || '%%' THEN trim(to_string(%s)) "
                    "ELSE %s || ' ' || trim(to_string(%s)) END" % (q, BP.sql_str(unit), q, BP.sql_str(unit), q))
    st.isExpression = True
    lab = lab.clone()
    lab.setSettings(st)
    return lab


def _show_text(lab):
    """The data-defined Show expressions of a labeling (all rules), joined - for idempotence checks."""
    key = getattr(QgsPalLayerSettings, "Property", QgsPalLayerSettings).Show
    out = []

    def grab(st):
        try:
            pr = st.dataDefinedProperties().property(key)
            if pr.isActive() and pr.asExpression():
                out.append(pr.asExpression())
        except Exception:
            _swallowed_note()
        return st
    _map_label_settings(lab.clone(), grab)
    return " ".join(out)


def _tiein_twin_expr(info, src_id, src, p):
    """Show expression hiding, on the backhaul page only, the label of the pole the tie-in marker
    sits on (the marker already says 'Existing HT Pole - Breakpoint'; Cradock's existing-pole
    layer labels the same pole the same way - two labels for one pole). None when not needed."""
    pole = (info or {}).get("pole") or {}
    if not pole or pole.get("layer") != src_id or info.get("page") is None or not info.get("pt"):
        return None
    try:
        q = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:%d" % int(info.get("metric_epsg") or 0))
                                   if info.get("metric_epsg") else src.crs(), src.crs(), p).transform(
            QgsPointXY(*info["pt"])) if info.get("metric_epsg") else None
    except Exception:
        q = None
    if q is None:
        return None
    tol = 1e-5 if src.crs().isGeographic() else 0.5
    return ("NOT (coalesce(attribute(@atlas_feature, 'seq'), -1) = %d AND "
            "distance($geometry, make_point(%.9f, %.9f)) < %s)" % (int(info["page"]), q.x(), q.y(), tol))


def _v2_pon_on_backhaul(spec, p):
    """Rebuild (once per book): the PON zones drawn and labelled under the backhaul (Cradock p1)."""
    roles = (spec.get("asbuilt") or {}).get("roles") or {}
    idx = BP.backhaul_page_index([(pg["title"], pg["ids"]) for pg in spec["overview"]],
                                 roles.get("backhaul") or [])
    pon = spec.get("pon_layer_id")
    if idx is None or not pon or p.mapLayer(pon) is None:
        return False
    pg = spec["overview"][idx]
    pg["ids"] = BP._uniq(list(pg["ids"]) + [pon])
    pg["labels"] = BP._uniq(list(pg["labels"]) + [pon])
    return True


def _ensure_asbuilt_extras(spec, project=None):
    """v2 layers before the page list is (re)written: the tie-in marker and the tuned label
    copies. Returns the tie-in info (None for books without a backhaul page / not v2)."""
    if not _v2_on(spec):
        return None
    p = project or QgsProject.instance()
    info = None
    try:
        info = asbuilt_tiein(spec, p)
        _ensure_tiein_layer(spec, info, p)
        _tune_label_copies(spec, p, info)
    except Exception:
        _swallowed_note()
    return info


def _logo_data(path):
    import base64
    with open(path, "rb") as f:
        return "base64:" + base64.b64encode(f.read()).decode("ascii")


def _set_picture(pic, data):
    from qgis.core import Qgis, QgsLayoutItemPicture
    fmt = getattr(getattr(Qgis, "PictureFormat", None), "Raster", None)
    if fmt is None:
        fmt = getattr(getattr(QgsLayoutItemPicture, "Format", QgsLayoutItemPicture), "FormatRaster", None)
    try:
        pic.setPicturePath(data, fmt) if fmt is not None else pic.setPicturePath(data)
    except TypeError:
        pic.setPicturePath(data)


def _picture_loads(path):
    s = str(path or "")
    return s.startswith("base64:") or os.path.isfile(s)


def _ensure_logo(layout, logo=None):
    """The logo box always shows a logo: a missing or broken picture gets the bundled asset of the
    same name, else the Velocity logo, embedded in the layout (a path into one PC's plugin
    folder is how Botshabelo's box came out empty). A logo that loads is left alone."""
    from qgis.core import QgsLayoutItemPicture
    A = BP.ASBUILT
    pic = next((it for it in layout.items() if isinstance(it, QgsLayoutItemPicture)
                and it.id() == "booklogo"), None)
    if pic is not None and _picture_loads(pic.picturePath()):
        return False
    src = logo if logo and os.path.isfile(logo) else None
    if src is None and pic is not None:
        cand = os.path.join(HERE, "assets", os.path.basename(str(pic.picturePath() or "").replace("\\", "/")))
        if os.path.isfile(cand):
            src = cand
    src = src or VELOCITY_LOGO
    if not os.path.isfile(src):
        return False
    if pic is None:
        pic = QgsLayoutItemPicture(layout)
        pic.setResizeMode(QgsLayoutItemPicture.ResizeMode.Zoom)
        layout.addLayoutItem(pic)
        pic.attemptMove(_mm_pt(A["logo_x"] + 3.0, A["strip_y"] + 2.0))
        pic.attemptResize(_mm_sz(A["logo_w"] - 6.0, A["strip_h"] - 4.0))
        pic.setId("booklogo")
    _set_picture(pic, _logo_data(src))
    pic.refresh()
    return True


def _only_on_seq(item, seq):
    """Print `item` on page `seq` only (and in the designer when no atlas page is shown)."""
    rule = "coalesce(attribute(@atlas_feature,'seq'), %d) <> %d" % (int(seq), int(seq))
    dd = item.dataDefinedProperties()
    dd.setProperty(QgsLayoutObject.DataDefinedProperty.ExcludeFromExports, QgsProperty.fromExpression(rule))
    dd.setProperty(QgsLayoutObject.DataDefinedProperty.Opacity,
                   QgsProperty.fromExpression("if(%s, 0, 100)" % rule))
    item.setDataDefinedProperties(dd)


def _top_left_stack(layout, skip):
    """Bottom edge (mm) and left x of the operator's items in the map's top-left corner (notes,
    page pictures), or None. The tie-in box goes under them."""
    from qgis.core import QgsLayoutItemLabel, QgsLayoutItemPicture
    A = BP.ASBUILT
    bottom, left = None, None
    for it in layout.items():
        if it in skip or not isinstance(it, (QgsLayoutItemLabel, QgsLayoutItemPicture)):
            continue
        if it.id() in ("booklogo", "booknorth", "booktitle"):
            continue
        pos, sz = it.positionWithUnits(), it.sizeWithUnits()
        if pos.y() >= A["strip_y"] or pos.x() > 100.0:
            continue
        b = pos.y() + sz.height()
        bottom = b if bottom is None else max(bottom, b)
        left = pos.x() if left is None else min(left, pos.x())
    return None if bottom is None else (bottom, left)


def _ensure_tiein_box(layout, info):
    """The 'Tie in Pole Location' box on the backhaul page, filled from the tie-in's EPSG:4326
    coordinates. Text the operator typed is never overwritten; an operator note that reuses the
    old box keeps it and the coordinates get a box of their own under it."""
    from qgis.core import QgsLayoutItemLabel, QgsTextFormat
    from qgis.PyQt.QtGui import QColor, QFont
    A = BP.ASBUILT
    box, made = None, False
    for it in layout.items():
        if isinstance(it, QgsLayoutItemLabel) and it.id() in ("booktiein", "booktiein_pt"):
            if (it.text() or "").strip().startswith(TIEIN_HEAD) or it.customProperty(TIEIN_AUTO) is not None:
                box = it
                break
    if box is None:
        ids = {getattr(it, "id", lambda: "")() for it in layout.items()}
        box = QgsLayoutItemLabel(layout)
        box.setText(TIEIN_HEAD + "\n")
        try:
            fmt = QgsTextFormat()
            f = QFont("Arial")
            f.setBold(True)
            fmt.setFont(f)
            fmt.setSize(9.0)
            box.setTextFormat(fmt)
        except Exception:
            _swallowed_note()
        box.setFrameEnabled(True)
        box.setBackgroundEnabled(True)
        box.setBackgroundColor(QColor(255, 255, 255))
        box.setMarginX(1.5)
        layout.addLayoutItem(box)
        box.attemptResize(_mm_sz(A["tiein_w"], A["tiein_h"]))
        box.setId("booktiein" if "booktiein" not in ids else "booktiein_pt")
        made = True
    _only_on_seq(box, info["page"])
    if info.get("wgs"):
        lines = [x.strip() for x in (box.text() or "").splitlines()]
        blank = len(lines) < 2 or not lines[1]
        auto = box.customProperty(TIEIN_AUTO)
        if blank or (auto is not None and str(auto) == box.text()):
            txt = "%s\n%s" % (TIEIN_HEAD, BP.format_latlon(info["wgs"][0], info["wgs"][1]))
            box.setText(txt)
            box.setCustomProperty(TIEIN_AUTO, txt)
    _stack_tiein_box(layout, box, made)
    box.refresh()
    return box


def _stack_tiein_box(layout, box, force=False):
    """Put the tie-in box under the operator's top-left items (photo, notes) - only while it sits
    where we last put it (or at the model's default): a box moved by hand stays put."""
    A = BP.ASBUILT
    pos = box.positionWithUnits()
    here = "%.2f,%.2f" % (pos.x(), pos.y())
    default = "%.2f,%.2f" % (A["tiein_x"], A["tiein_y"])
    if force or here == str(box.customProperty(TIEIN_POS) or "") or (box.customProperty(TIEIN_POS) is None and here == default):
        st = _top_left_stack(layout, {box})
        x, y = (A["map_x"] + 2.0, A["map_y"] + 2.0) if st is None else (st[1], st[0] + 1.5)
        box.attemptMove(_mm_pt(x, y))
        box.setCustomProperty(TIEIN_POS, "%.2f,%.2f" % (x, y))
        return True
    return False


def restack_tiein_box(layout):
    """After a page picture is added in the designer: the auto-placed tie-in box moves under it."""
    from qgis.core import QgsLayoutItemLabel
    for it in layout.items():
        if isinstance(it, QgsLayoutItemLabel) and it.customProperty(TIEIN_POS) is not None:
            moved = _stack_tiein_box(layout, it)
            it.refresh()
            return moved
    return False


def _ensure_tiein_photo(layout, info, stash=None):
    """A pole photo from the data (when the tie-in snapped to a pole whose photo field names an
    existing image) goes on the backhaul page as a page picture. None when the page already has
    one, or there is no photo: the slot stays empty - never a broken frame."""
    from . import page_pictures as PP
    path = info.get("photo")
    if not path or not os.path.isfile(path):
        return None
    cov = layout.atlas().coverageLayer()
    if cov is None:
        return None
    title = next((str(f["page_title"]) for f in cov.getFeatures() if int(f["seq"] or 0) == info["page"]
                  and int(f["is_overview"] or 0) == 1), None)
    if not title:
        return None
    key = {"kind": "field", "field": "page_title", "value": title, "label": title}
    for it in PP._pictures(layout):
        try:
            if json.loads(it.customProperty(PP.PIC_KEY) or "{}").get("value") == title:
                return None
        except Exception:
            continue
    if not PP.page_exists(layout, key):
        return None
    A = BP.ASBUILT
    if stash is not None:                  # a photo picked by the operator: copied beside the project
        path = PP._stash(path, stash)
    skip = {it for it in layout.items() if getattr(it, "id", lambda: "")() in ("booktiein", "booktiein_pt")
            and it.customProperty(TIEIN_AUTO) is not None}
    st = _top_left_stack(layout, skip)     # under an operator's note (Botshabelo), else the corner
    x, y = (A["map_x"] + 2.0, A["map_y"] + 2.0) if st is None else (st[1], st[0] + 1.5)
    pic = PP._add_picture(layout, path, x, y, 60.0, 62.0)
    pic.setId("Page picture - %s" % title)
    PP.pin(pic, layout, key)
    PP.capture(layout)
    return pic


def _legend_h_on(layout, page):
    """(legend content height, legend box height) in mm on one atlas page; the box is put back."""
    from qgis.core import QgsLayoutExporter
    leg = book_legend(layout)
    at = layout.atlas()
    size = leg.sizeWithUnits()
    rr = leg.resizeToContents()
    leg.setResizeToContents(True)
    h = 0.0
    at.updateFeatures()
    at.beginRender()
    try:
        at.seekTo(int(page))
        QgsLayoutExporter(layout).renderPageToImage(0, dpi=12)
        leg.adjustBoxSize()
        h = float(leg.rect().height())
    finally:
        at.endRender()
        leg.setResizeToContents(rr)
        leg.attemptResize(size)
    return h, float(size.height())


def _ensure_tiein_legend(layout, spec, p, info=None):
    """Legend row 'Existing Herotel Pole' for the tie-in marker (shown on the backhaul page only:
    the legend follows the map). A row left by a removed marker is dropped."""
    leg = book_legend(layout)
    if leg is None:
        return
    root = leg.model().rootGroup()
    lyr = p.mapLayer(spec.get("tiein_id") or "")
    pole = (info or {}).get("pole") or {}
    roles = (spec.get("asbuilt") or {}).get("roles") or {}
    if (lyr is not None and pole.get("layer") in (roles.get("existing_pole") or [])
            and pole.get("layer") in spec["overview"][info["page"]]["ids"]):
        lyr = None      # the marker sits on an existing-pole layer drawn on the page: its own row says it
    have, out = None, None
    for n in list(root.findLayers()):
        if n.customProperty(LEGEND_TIEIN):
            if lyr is not None and n.layerId() == lyr.id() and have is None:
                have = n
            else:
                n.parent().removeChildNode(n)
    # Cradock p1: the zones under the backhaul are labelled on the map, not listed in the legend
    # (a legend row filter on the PON node, true on every page but the backhaul page)
    try:
        from qgis.core import QgsLayerTreeUtils
        bh = info["page"] if info else None
        want = None if bh is None else "coalesce(attribute(@atlas_feature,'seq'),-1) <> %d" % int(bh)
        for n in root.findLayers():
            if n.layerId() != spec.get("pon_layer_id"):
                continue
            cur, _on = QgsLayerTreeUtils.legendFilterByExpression(n)
            ours = (cur or "").startswith("coalesce(attribute(@atlas_feature,'seq'),-1) <> ")
            if want and (not cur or ours) and cur != want:
                QgsLayerTreeUtils.setLegendFilterByExpression(n, want, True)
            elif not want and ours:
                QgsLayerTreeUtils.setLegendFilterByExpression(n, "", False)
    except Exception:
        _swallowed_note()
    if lyr is not None and have is None:
        fixed = info is not None and not leg.resizeToContents()
        if fixed:
            leg.updateLegend()
        before = _legend_h_on(layout, info["page"]) if fixed else None
        node = root.insertLayer(0, lyr)
        node.setCustomProperty("legend/title-label", BP.TIEIN_LEGEND)
        node.setCustomProperty(LEGEND_TIEIN, 1)
        if fixed:
            # an existing book's legend box is the operator's: the row stays only when the
            # backhaul page's legend still fits (or already overflowed before it)
            leg.updateLegend()
            after, box = _legend_h_on(layout, info["page"])
            if after > box + 0.5 and before[0] <= box + 0.5:
                root.removeChildNode(node)
                out = "left_out"
    try:
        leg.updateLegend()
    except Exception:
        _swallowed_note()
    return out


def _sync_asbuilt_items(layout, spec, info, project=None, logo=None):
    """v2 layout items: logo, tie-in photo + box, tie-in legend row. Fixed As-Built books only."""
    if not _v2_on(spec):
        return []
    p = project or QgsProject.instance()
    msgs = []
    try:
        if _ensure_logo(layout, logo):
            msgs.append("Logo box: Velocity logo embedded in the layout.")
    except Exception:
        _swallowed_note()
    if info is None:
        return msgs
    try:
        if _ensure_tiein_photo(layout, info) is not None:
            msgs.append("Tie-in pole photo placed from the pole's photo field.")
        else:
            typed = ((spec.get("asbuilt") or {}).get("details") or {}).get("tiein_photo") or ""
            if typed and os.path.isfile(typed):
                if _ensure_tiein_photo(layout, dict(info, photo=typed), stash=p) is not None:
                    msgs.append("Tie-in pole photo placed (picked in As-Built details).")
        _ensure_tiein_box(layout, info)
        if _ensure_tiein_legend(layout, spec, p, info) == "left_out":
            msgs.append("Legend: the 'Existing Herotel Pole' row was left out - the backhaul page's legend box is full.")
    except Exception:
        _swallowed_note()
    if info.get("wgs"):
        msgs.append("Tie-in %s at %s." % ("pole %s" % info["pole"]["name"] if info.get("pole") else "point (backhaul end)",
                                          BP.format_latlon(info["wgs"][0], info["wgs"][1])))
    return msgs


def build_or_update(cfg, spec, project=None):
    if cfg.get("label_fit") is not None:
        spec["label_fit"] = bool(cfg["label_fit"])
    return _build_or_update(cfg, spec, project)


def _build_or_update(cfg, spec, project=None):
    """Build the book, or — when a layout already carries this book id — update it in place
    (the operator's Print Layout edits stay). Returns (layout, message)."""
    p = project or QgsProject.instance()
    spec = BP.normalise(spec)
    names = names_by_id(p)
    errors, warnings = BP.validate(spec, names)
    if errors:
        raise ValueError("Book not built:\n• " + "\n• ".join(errors))
    existing = [lay for lay in layouts_for_book(spec["book_id"], p) if is_original(lay, get_spec(lay))]
    if existing:
        lay = update_book(existing[0], spec, cfg=cfg)
        return lay, "Updated “%s” in place — your Print Layout edits were kept." % lay.name()
    ns = engine_ns(cfg)
    pon = p.mapLayer(spec["pon_layer_id"])
    guard = _ensure_guard(spec, pon.crs())
    _ensure_label_layers(spec)
    tie = _ensure_asbuilt_extras(spec, p)          # v2 (fixed As-Built only): tie-in + label copies
    pages = _ensure_pages(spec)
    asbuilt = spec.get("frame_kind") == BP.FRAME_ASBUILT
    note = title_y = None
    if asbuilt:
        lay, m, leg = _new_layout_asbuilt(ns, cfg, spec, pages, guard)
    else:
        lay, m, leg, note, title_y = _new_layout(ns, cfg, spec, pages, guard)
    spec["layout_name"] = lay.name()
    fix_msgs = []
    if asbuilt and spec.get("asbuilt_fix") is not None:
        # fixed As-Built book: the Build tick ("Isolate each PON page") is stored as isolate;
        # the book map's own style copies replace atlas clipping (S2)
        fix = dict(spec["asbuilt_fix"], isolate=bool(cfg.get("atlas_clip")))
        _store_fix(lay, spec, fix)
        fix_msgs = sync_overrides(lay, spec, p) + pon_name_report(spec, p)
    else:
        _apply_clip(m, spec, bool(cfg.get("atlas_clip")))
    set_spec(lay, spec)
    if not p.layoutManager().addLayout(lay):
        for l in book_layers(spec["book_id"], p):
            p.removeMapLayer(l.id())
        raise RuntimeError("QGIS refused to add the layout “%s”." % lay.name())
    _sync_legend(lay, spec, ns, first=True)
    if asbuilt:
        fix_msgs += _sync_asbuilt_items(lay, spec, tie, p, ns.get("LOGO"))
        _place_strip(lay, leg, spec)
        relock_frame(lay)                 # the legend fit flips pages, which grows the frame
        fix_msgs += _fit_labels(lay, spec, p)
    else:
        _place_sidebar(ns, lay, leg, note, title_y)
    set_spec(lay, spec)
    msg = "Built “%s” — %d overview page(s) + %d PON page(s)." % (
        lay.name(), len(spec["overview"]), pon.featureCount() - len(skip_pon_fids(spec, p)))
    if spec.get("defaults_left_out"):
        msg += "  Left out (no matching layer in this project): %s — add them in Book Pages ▸ Edit pages." % (
            ", ".join(spec["defaults_left_out"]))
    if warnings:
        msg += "  Note: " + " ".join(warnings[:3])
    if fix_msgs:
        msg += "  " + "  ".join(fix_msgs)
    return lay, msg


def update_book(layout, spec, cfg=None, fit=True):
    """Rewrite the page list, label layers, notes and the allowed legend parts in place."""
    p = QgsProject.instance()
    old = get_spec(layout)
    if old is None or not is_original(layout, old):
        raise ValueError("This layout is a copy of a book — use “Make this copy its own book” first.")
    spec = BP.normalise(spec)
    for k in ("book_id", "layout_name", "pages_id", "guard_id", "label_layers", "legend_known", "frame"):
        spec[k] = old.get(k) if k not in ("label_layers",) else (spec.get(k) or old.get(k) or {})
    BP.carry_asbuilt_fix(asbuilt_fix_of(layout, old), spec)       # rule C
    if _v2_on(spec) and old.get("tiein_id") and not spec.get("tiein_id"):
        spec["tiein_id"] = old["tiein_id"]
    errors, _w = BP.validate(spec, names_by_id(p))
    if errors:
        raise ValueError("Book not updated:\n• " + "\n• ".join(errors))
    pon = p.mapLayer(spec["pon_layer_id"])
    guard = _ensure_guard(spec, pon.crs())
    _ensure_label_layers(spec)
    tie = _ensure_asbuilt_extras(spec, p)
    pages = _ensure_pages(spec)
    m = book_map(layout)
    if m is not None:
        aerial = p.mapLayer(spec.get("aerial_id") or "")
        m.setLayers([x for x in (guard, aerial) if x is not None])
        m.dataDefinedProperties().setProperty(
            QgsLayoutObject.DataDefinedProperty.MapLayers,
            QgsProperty.fromExpression(BP.map_layers_expression(guard.name())))
    if layout.atlas().coverageLayer() is None or layout.atlas().coverageLayer().id() != pages.id():
        layout.atlas().setCoverageLayer(pages)
    sync_overrides(layout, spec, p)
    ns = engine_ns(cfg or {"project_name": spec.get("title")})
    _sync_legend(layout, spec, ns)
    _sync_asbuilt_items(layout, spec, tie, p)
    if fit:
        _fit_labels(layout, spec, p)
    set_spec(layout, spec)
    layout.refresh()
    return layout


# ── checks ─────────────────────────────────────────────────────────────────────────────
def guard_enabled():
    try:
        from qgis.core import QgsSettings
        v = QgsSettings().value(BP.SETTING_GUARD, BP.GUARD_DEFAULT_ON)
        return str(v).lower() not in ("false", "0", "off", "no")
    except Exception:
        return True


def check_book(layout, force=False):
    """Fail-closed draw check for our exports. Returns (hard, soft); never raises.

    hard (refuse): spec unreadable, a copy not made its own book, PON layer missing, page
    count != overview pages + live PON count, any page drawing something it should not or
    missing a listed layer that exists, a listed layer deleted, a '|' in a listed name.
    soft (warn): same-named twins drawn, switch off."""
    hard, soft = [], []
    try:
        p = QgsProject.instance()
        spec = get_spec(layout)
        if spec is None:
            return ["Book spec is missing or unreadable on this layout."], []
        if not guard_enabled() and not force:
            return [], ["Book draw check is switched off (%s)." % BP.SETTING_GUARD]
        if not is_original(layout, spec):
            hard.append("This layout is a copy of book “%s” — use “Make this copy its own book”."
                        % spec.get("layout_name"))
        names = names_by_id(p)
        errors, warns = BP.validate(spec, names)
        hard += errors
        for w in warns:
            if "no longer exists" in w:
                hard.append(w)
            else:
                soft.append(w)
        pon = p.mapLayer(spec.get("pon_layer_id") or "")
        at = layout.atlas()
        cov = at.coverageLayer()
        if cov is None or cov.id() != spec.get("pages_id") or not cov.isValid():
            hard.append("The book's page list is missing or broken (re-attach the PON layer).")
            return hard, soft
        try:
            at.updateFeatures()                  # count() is 0 until the atlas reads its rows
        except Exception:
            _swallowed_note()
        if pon is not None:
            n_pon = pon.featureCount() - len(skip_pon_fids(spec, p))
            want = len(spec["overview"]) + n_pon
            if at.count() != want:
                hard.append("Page count %d ≠ %d overview + %d PON pages." % (
                    at.count(), len(spec["overview"]), n_pon))
        m = book_map(layout)
        if m is None:
            hard.append("The book's map item is missing.")
            return hard, soft
        twins_seen = set()
        at.beginRender()
        try:
            for i in range(at.count()):
                at.seekTo(i)
                f = layout.reportContext().feature()
                title = f["page_title"]
                ids = BP.split_ids(f["page_ids"])
                rendered = [l.id() for l in m.layersToRender()]
                v = BP.check_page(ids, rendered, names)
                if not v["ok"]:
                    bits = []
                    if v["extra"]:
                        bits.append("draws unlisted: " + ", ".join(names.get(x, x) for x in v["extra"]))
                    if v["missing"]:
                        bits.append("missing: " + ", ".join(names.get(x, x) for x in v["missing"]))
                    hard.append("Page “%s”: %s." % (title, "; ".join(bits)))
                for t in v["twins"]:
                    twins_seen.add(names.get(t, t))
        finally:
            at.endRender()
        for n in sorted(twins_seen):
            soft.append("Two or more layers are named “%s”; all of them draw." % n)
        unmatched = unmatched_overrides(spec, pon)
        if unmatched:
            soft.append("%d per-PON override(s) no longer match a zone (merged or reshaped) and "
                        "are not drawn: %s." % (len(unmatched), ", ".join("PON %s" % o.get("pon") for o in unmatched)))
    except Exception as e:
        hard.append("Book draw check failed: %s" % e)
    return hard, soft


def make_qa(engine_qa=None):
    """QA callable for live_build._write_atlas_pdf: engine layout QA + the book draw check.
    Never raises (the caller's wrapper is fail-open), so a crash here blocks the export."""
    def _qa(layout):
        hard, soft = [], []
        if callable(engine_qa):
            try:
                h, s = engine_qa(layout)
                soft += list(h) + list(s)       # engine QA stays advisory for the book frame
            except Exception as e:
                soft.append("engine QA skipped: %s" % e)
        h2, s2 = check_book(layout)
        return hard + h2, soft + s2
    return _qa


# ── overrides ──────────────────────────────────────────────────────────────────────────
def fingerprint(geom, crs, metric_epsg):
    g = QgsGeometry(geom)
    g.transform(QgsCoordinateTransform(crs, QgsCoordinateReferenceSystem("EPSG:%d" % int(metric_epsg)),
                                       QgsProject.instance()))
    c = g.centroid().asPoint()
    return float(c.x()), float(c.y()), float(g.area())


def unmatched_overrides(spec, pon_layer):
    if pon_layer is None or not spec.get("overrides"):
        return []
    fps = [fingerprint(f.geometry(), pon_layer.crs(), spec["metric_epsg"])
           for f in pon_layer.getFeatures() if f.geometry() and not f.geometry().isEmpty()]
    out = []
    for o in spec["overrides"]:
        if not any(BP.zone_matches(o, cx, cy, a) for cx, cy, a in fps):
            out.append(o)
    return out


def add_override(spec, pon_feature, pon_layer, ids=None, labels=None, note=None):
    cx, cy, a = fingerprint(pon_feature.geometry(), pon_layer.crs(), spec["metric_epsg"])
    spec = BP.normalise(spec)
    spec["overrides"] = [o for o in spec["overrides"] if not BP.zone_matches(o, cx, cy, a)]
    fld = spec.get("pon_label_field")
    spec["overrides"].append({
        "cx": cx, "cy": cy, "area": a,
        "pon": str(pon_feature[fld]) if fld and fld in pon_feature.fields().names() else "",
        "ids": list(ids if ids is not None else spec["pon"]["ids"]),
        "labels": list(labels if labels is not None else spec["pon"]["labels"]),
        "note": spec["pon"]["note"] if note is None else note})
    return BP.normalise(spec)


def discard_override(spec, index):
    spec = BP.normalise(spec)
    if 0 <= index < len(spec["overrides"]):
        spec["overrides"].pop(index)
    return spec


def reattach_override(spec, index, pon_feature, pon_layer):
    spec = BP.normalise(spec)
    o = spec["overrides"][index]
    cx, cy, a = fingerprint(pon_feature.geometry(), pon_layer.crs(), spec["metric_epsg"])
    o.update({"cx": cx, "cy": cy, "area": a})
    fld = spec.get("pon_label_field")
    if fld and fld in pon_feature.fields().names():
        o["pon"] = str(pon_feature[fld])
    return BP.normalise(spec)


def override_index_for(spec, pon_feature, pon_layer):
    cx, cy, a = fingerprint(pon_feature.geometry(), pon_layer.crs(), spec["metric_epsg"])
    for i, o in enumerate(spec["overrides"]):
        if BP.zone_matches(o, cx, cy, a):
            return i
    return -1


# ── re-attach / copies / backup / restore / rebuild / remove ──────────────────────────
def reattach_pon(layout, new_layer, cfg=None):
    spec = get_spec(layout)
    if spec is None:
        raise ValueError("Not a book layout.")
    old = spec["pon_layer_id"]
    spec["pon_layer_id"] = new_layer.id()
    for coll in [spec["pon"]] + spec["overview"] + spec["overrides"]:
        coll["ids"] = [new_layer.id() if x == old else x for x in coll["ids"]]
        coll["labels"] = [new_layer.id() if x == old else x for x in coll["labels"]]
    if old in (spec.get("label_layers") or {}):
        lab = QgsProject.instance().mapLayer(spec["label_layers"].pop(old))
        if lab is not None:
            QgsProject.instance().removeMapLayer(lab.id())
    spec["overview_srid"] = int(new_layer.crs().postgisSrid())
    if spec.get("pon_label_field") not in new_layer.fields().names():
        spec["pon_label_field"] = _label_field(new_layer)
        spec["pon_sort_numeric"] = _numeric_field(new_layer, spec["pon_label_field"])
    # update_book needs the stored spec to agree on identity - write it first
    set_spec(layout, dict(get_spec(layout) or spec, pon_layer_id=new_layer.id()))
    return update_book(layout, spec, cfg=cfg)


def _backup_root():
    env = os.environ.get("VF_BOOK_BACKUP_DIR")
    if env:
        return env
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(base, "VelocityNexus", "book_backups")


def backup_book(layout, reason="backup"):
    """.qpt (every layout item, your edits included) + spec. The private layers are
    regenerated from the spec on restore, so the pair is the whole book."""
    import hashlib
    p = QgsProject.instance()
    spec = get_spec(layout)
    if spec is None:
        raise ValueError("Not a book layout.")
    key = hashlib.sha256((p.fileName() or "unsaved").lower().encode()).hexdigest()[:16]
    d = os.path.join(_backup_root(), key, spec["book_id"], time.strftime("%Y%m%d_%H%M%S") + "_" + reason)
    os.makedirs(d, exist_ok=True)
    qpt = os.path.join(d, "layout.qpt")
    if not layout.saveAsTemplate(qpt, QgsReadWriteContext()):
        raise RuntimeError("Could not write the layout backup %s" % qpt)
    with open(os.path.join(d, "spec.json"), "w", encoding="utf-8") as f:
        f.write(BP.to_json(spec))
    with open(os.path.join(d, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump({"project": p.fileName(), "book_id": spec["book_id"], "layout": layout.name(),
                   "reason": reason, "t": time.time()}, f)
    if not (os.path.getsize(qpt) > 0):
        raise RuntimeError("Layout backup is empty: %s" % qpt)
    return d


def list_backups(project=None):
    import hashlib
    p = project or QgsProject.instance()
    key = hashlib.sha256((p.fileName() or "unsaved").lower().encode()).hexdigest()[:16]
    root = os.path.join(_backup_root(), key)
    out = []
    if not os.path.isdir(root):
        return out
    for bid in sorted(os.listdir(root)):
        for stamp in sorted(os.listdir(os.path.join(root, bid)), reverse=True):
            d = os.path.join(root, bid, stamp)
            try:
                with open(os.path.join(d, "manifest.json"), encoding="utf-8") as f:
                    man = json.load(f)
            except Exception:
                continue
            if os.path.normcase(str(man.get("project") or "")) == os.path.normcase(p.fileName() or ""):
                out.append((d, man))
    return out


def _retarget_items(layout, spec, guard, pages):
    m = book_map(layout)
    p = QgsProject.instance()
    if m is not None:
        aerial = p.mapLayer(spec.get("aerial_id") or "")
        m.setLayers([x for x in (guard, aerial) if x is not None])
        m.dataDefinedProperties().setProperty(
            QgsLayoutObject.DataDefinedProperty.MapLayers,
            QgsProperty.fromExpression(BP.map_layers_expression(guard.name())))
    leg = book_legend(layout)
    if leg is not None and m is not None:
        leg.setLinkedMap(m)
    layout.atlas().setCoverageLayer(pages)
    layout.atlas().setEnabled(True)


def restore_book(backup_dir, cfg=None):
    """Recreate a removed book from its backup: layout items from the .qpt, private layers
    regenerated from the spec (detached, private, never in the Layers panel)."""
    p = QgsProject.instance()
    with open(os.path.join(backup_dir, "manifest.json"), encoding="utf-8") as f:
        man = json.load(f)
    if os.path.normcase(str(man.get("project") or "")) != os.path.normcase(p.fileName() or ""):
        raise ValueError("That backup belongs to a different project (%s)." % man.get("project"))
    with open(os.path.join(backup_dir, "spec.json"), encoding="utf-8") as f:
        spec = BP.from_json(f.read())
    if layouts_for_book(spec["book_id"], p):
        spec["book_id"] = BP.new_book_id()          # the original still exists: a new book
    for k in ("pages_id", "guard_id"):
        spec[k] = ""
    spec["label_layers"] = {}
    spec.pop("tiein_id", None)
    pon = p.mapLayer(spec["pon_layer_id"])
    if pon is None:
        raise ValueError("The book's PON layer is not in this project.")
    guard = _ensure_guard(spec, pon.crs())
    _ensure_label_layers(spec)
    tie = _ensure_asbuilt_extras(spec, p)
    pages = _ensure_pages(spec)
    from qgis.PyQt.QtXml import QDomDocument
    doc = QDomDocument()
    with open(os.path.join(backup_dir, "layout.qpt"), encoding="utf-8") as f:
        doc.setContent(f.read())
    lay = QgsPrintLayout(p)
    lay.initializeDefaults()
    lay.loadFromTemplate(doc, QgsReadWriteContext(), True)
    spec["layout_name"] = _layout_name(spec, p) if p.layoutManager().layoutByName(man.get("layout") or "") \
        else (man.get("layout") or _layout_name(spec, p))
    lay.setName(spec["layout_name"])
    _retarget_items(lay, spec, guard, pages)
    sync_overrides(lay, spec, p)
    _sync_asbuilt_items(lay, spec, tie, p)
    set_spec(lay, spec)
    if not p.layoutManager().addLayout(lay):
        raise RuntimeError("QGIS refused to add the restored layout.")
    return lay


def rebuild_precheck(layout, project=None):
    """Error text when Rebuild must stop before ANY change (no backup, no removal), else None:
    not the original layout, the PON layer missing or not loaded, or the new page list would
    not build (a throw-away virtual layer, never added to the project)."""
    p = project or QgsProject.instance()
    spec = get_spec(layout)
    if spec is None or not is_original(layout, spec):
        return "Only the original book layout can be rebuilt."
    pon = p.mapLayer(spec.get("pon_layer_id") or "")
    if not isinstance(pon, QgsVectorLayer) or not pon.isValid():
        return "Rebuild stopped before any change: the book's PON layer is missing - re-attach it first."
    s2 = dict(spec)
    if s2.get("frame_kind") == BP.FRAME_ASBUILT and s2.get("asbuilt_fix") is None:
        s2["asbuilt_fix"] = BP.new_asbuilt_fix(True)
    try:
        dry = QgsVectorLayer(_pages_uri(s2, p), "vf_book_rebuild_dry_run", "virtual")
        if not dry.isValid() or dry.featureCount() <= 0:
            err = dry.dataProvider().error().message() if dry.dataProvider() is not None else ""
            return "Rebuild stopped before any change: the page list could not be built (%s)." % (err or "no rows")
    except Exception as e:
        return "Rebuild stopped before any change: the page list could not be built (%s)." % e
    return None


def title_preview(layout, project=None):
    """[(old title, new title)] for PON pages whose title a Rebuild with the fixes changes."""
    p = project or QgsProject.instance()
    spec = get_spec(layout)
    cov = layout.atlas().coverageLayer()
    if spec is None or cov is None or spec.get("frame_kind") != BP.FRAME_ASBUILT:
        return []
    s2 = dict(spec, asbuilt_fix=spec.get("asbuilt_fix") or BP.new_asbuilt_fix(True))
    try:
        dry = QgsVectorLayer(_pages_uri(s2, p), "vf_book_title_preview", "virtual")
        if not dry.isValid():
            return []
        new = {(str(f["unit"]), int(f["is_overview"] or 0)): str(f["page_title"]) for f in dry.getFeatures()}
        out = []
        for f in sorted(cov.getFeatures(), key=lambda f: (f["seq"] is None, f["seq"] or 0)):
            if int(f["is_overview"] or 0) == 1:
                continue
            n = new.get((str(f["unit"]), 0))
            if n is not None and n != str(f["page_title"]):
                out.append((str(f["page_title"]), n))
        return out
    except Exception:
        return []


def beside_copy(project_path, book_id):
    """Copy the SAVED project file (its bytes, never a Save) beside it, exclusive create, and
    prove the copy's sha256 equals the source's. Returns the copy path; raises on any doubt."""
    import hashlib
    if not project_path or not os.path.isfile(project_path):
        raise ValueError("Save the project once first - Rebuild copies the saved file before it changes anything.")
    with open(project_path, "rb") as f:
        data = f.read()
    target = BP.beside_copy_name(project_path, book_id, time.strftime("%Y%m%d-%H%M%S"))
    with open(target, "xb") as f:                 # an existing name raises: nothing overwritten
        f.write(data)
    with open(target, "rb") as f:
        ok = hashlib.sha256(f.read()).hexdigest() == hashlib.sha256(data).hexdigest()
    if not ok:
        os.remove(target)                          # our own just-written file only
        raise RuntimeError("The safety copy %s did not read back equal - Rebuild stopped." % target)
    if target.lower().endswith(".qgs"):
        qgd = os.path.splitext(project_path)[0] + ".qgd"
        if os.path.isfile(qgd):
            with open(qgd, "rb") as f:
                d2 = f.read()
            with open(os.path.splitext(target)[0] + ".qgd", "xb") as f:
                f.write(d2)
    return target


def rebuild_book_ex(layout, cfg=None, isolate=None, project=None, label_fit=None):
    """rebuild_book plus a result dict {copy, messages, converted, kept}. An As-Built book is
    rebuilt WITH the As-Built fixes: a book without them yet (converting) first gets the saved
    project copied beside itself; `isolate` None keeps the stored choice (converting: on)."""
    p = project or QgsProject.instance()
    err = rebuild_precheck(layout, p)
    if err:
        raise ValueError(err)
    spec = get_spec(layout)
    if label_fit is not None:
        spec["label_fit"] = bool(label_fit)
    asb = spec.get("frame_kind") == BP.FRAME_ASBUILT
    fix = asbuilt_fix_of(layout, spec) if asb else None
    converting = asb and fix is None
    info = {"copy": None, "messages": [], "converted": converting, "kept": []}
    if asb:
        fix = BP.new_asbuilt_fix(True) if fix is None else json.loads(json.dumps(fix))
        if isolate is not None:
            fix["isolate"] = bool(isolate)
        if converting:
            info["copy"] = beside_copy(p.fileName(), spec["book_id"])
    backup_book(layout, "before_rebuild")
    seed, keep = {}, {}
    if asb:
        for src_id, lab_id in (spec.get("label_layers") or {}).items():
            src, cl = p.mapLayer(src_id), p.mapLayer(lab_id)
            if src is not None and not src.isValid() and cl is not None:
                keep[src_id] = lab_id              # rule K: its source does not load here
                info["kept"].append(src.name())
            elif cl is not None and cl.labeling() is not None:
                seed[src_id] = cl.labeling().clone()   # rule S: the copy keeps its own format
    for lyr in book_layers(spec["book_id"], p):
        if lyr.id() not in keep.values():
            p.removeMapLayer(lyr.id())
    for k in ("pages_id", "guard_id"):
        spec[k] = ""
    spec["label_layers"] = dict(keep)
    if asb:
        spec["asbuilt_fix"] = fix
        if not fix.get(V2_MARK):                  # v2, once: PON zones under the backhaul (Cradock p1)
            _v2_pon_on_backhaul(spec, p)
            fix[V2_MARK] = 1
    pon = p.mapLayer(spec["pon_layer_id"])
    guard = _ensure_guard(spec, pon.crs())
    _ensure_label_layers(spec, seed=seed)
    tie = _ensure_asbuilt_extras(spec, p)
    pages = _ensure_pages(spec)
    _retarget_items(layout, spec, guard, pages)
    if asb:
        _store_fix(layout, spec, fix)
        info["messages"] = sync_overrides(layout, spec, p) + pon_name_report(spec, p)
        info["messages"] += _sync_asbuilt_items(layout, spec, tie, p)
        info["messages"] += _fit_labels(layout, spec, p)
    set_spec(layout, spec)
    layout.refresh()
    return layout, info


def rebuild_book(layout, cfg=None):
    """Recreate the book's private layers, page list, atlas binding and clip set. The layout
    object and every item on it (your edits) are kept. Backs up first. An As-Built book is
    rebuilt with the As-Built fixes (rebuild_book_ex)."""
    return rebuild_book_ex(layout, cfg)[0]


def remove_book(layout, backup=True):
    """Delete only this book's id-tagged items (its layout and its private layers)."""
    p = QgsProject.instance()
    spec = get_spec(layout)
    if spec is None:
        raise ValueError("Not a book layout.")
    if not is_original(layout, spec):
        raise ValueError("This layout is a copy — use “Make this copy its own book” first.")
    d = backup_book(layout, "before_remove") if backup else None
    others = [lay for lay in layouts_for_book(spec["book_id"], p) if lay is not layout]
    p.layoutManager().removeLayout(layout)
    if not others:
        for l in book_layers(spec["book_id"], p):
            p.removeMapLayer(l.id())
    return d


def remove_orphans(project=None):
    p = project or QgsProject.instance()
    n = 0
    for l in orphan_book_layers(p):
        p.removeMapLayer(l.id()); n += 1
    return n


def clone_book(layout, cfg=None):
    """Make a duplicated layout its own book: new id, its own private layers, its atlas,
    map, clip set and legend re-pointed. The original is untouched."""
    p = QgsProject.instance()
    spec = get_spec(layout)
    if spec is None:
        raise ValueError("Not a book layout.")
    if is_original(layout, spec):
        raise ValueError("This is the original book; it is already its own book.")
    spec = BP.normalise(spec)
    spec["book_id"] = BP.new_book_id()
    for k in ("pages_id", "guard_id"):
        spec[k] = ""
    spec["label_layers"] = {}
    spec.pop("tiein_id", None)
    pon = p.mapLayer(spec["pon_layer_id"])
    if pon is None:
        raise ValueError("The book's PON layer is missing.")
    guard = _ensure_guard(spec, pon.crs())
    _ensure_label_layers(spec)
    tie = _ensure_asbuilt_extras(spec, p)
    pages = _ensure_pages(spec)
    _retarget_items(layout, spec, guard, pages)
    m = book_map(layout)
    if asbuilt_fix_of(layout, spec) is not None:
        sync_overrides(layout, spec, p)
        _sync_asbuilt_items(layout, spec, tie, p)
    elif m is not None and m.atlasClippingSettings().enabled():
        _apply_clip(m, spec, True)
    spec["layout_name"] = layout.name()
    set_spec(layout, spec)
    layout.refresh()
    return layout


# ── designer helpers ───────────────────────────────────────────────────────────────────
def relock_frame(layout):
    """Put the map frame back to its designed size (QGIS 4 preview grows it)."""
    m = book_map(layout)
    if m is None:
        return False
    try:
        w = m.customProperty("hld_frame_w"); h = m.customProperty("hld_frame_h")
        x = m.customProperty("hld_frame_x"); y = m.customProperty("hld_frame_y")
        if not (w and h):
            return False
        cur = m.sizeWithUnits(); pos = m.positionWithUnits()
        if (abs(cur.width() - float(w)) < 0.01 and abs(cur.height() - float(h)) < 0.01
                and abs(pos.x() - float(x)) < 0.01 and abs(pos.y() - float(y)) < 0.01):
            return False                                  # already right: no edit recorded
        m.attemptMove(_mm_pt(x, y)); m.attemptResize(_mm_sz(w, h))
        return True
    except Exception:
        _swallowed_note()
        return False


def lock_frame_position_here(layout):
    """Store the frame's CURRENT position AND size as the designed ones, so an operator who
    restyles the layout (other page size, frame moved or resized) keeps it on every page."""
    m = book_map(layout)
    if m is None:
        return False
    pos = m.positionWithUnits()
    size = m.sizeWithUnits()
    m.setCustomProperty("hld_frame_x", float(pos.x()))
    m.setCustomProperty("hld_frame_y", float(pos.y()))
    m.setCustomProperty("hld_frame_w", float(size.width()))
    m.setCustomProperty("hld_frame_h", float(size.height()))
    relock_frame(layout)
    return True


def page_titles(layout):
    at = layout.atlas()
    out = []
    cov = at.coverageLayer()
    if cov is None:
        return out
    feats = sorted(cov.getFeatures(), key=lambda f: (f["seq"] is None, f["seq"] or 0))
    for i, f in enumerate(feats):
        out.append((i, str(f["page_title"] or "Page %d" % (i + 1))))
    return out


def legend_overflow_pages(layout):
    """Pages whose legend content is taller than the legend box (bar warning). The box itself
    is put back exactly as it was - this only measures."""
    from qgis.core import QgsLayoutExporter
    leg = book_legend(layout)
    if leg is None or not layout.atlas().enabled():
        return []
    size = leg.sizeWithUnits()
    box_h = float(size.height())
    rr = leg.resizeToContents()
    leg.setResizeToContents(True)
    out = []
    at = layout.atlas()
    ex = QgsLayoutExporter(layout)
    at.updateFeatures()
    at.beginRender()
    try:
        for i in range(at.count()):
            at.seekTo(i)
            ex.renderPageToImage(0, dpi=12)
            leg.adjustBoxSize()
            if float(leg.rect().height()) > box_h + 0.5:
                out.append(i)
    finally:
        at.endRender()
        leg.setResizeToContents(rr)
        leg.attemptResize(size)
    return out
