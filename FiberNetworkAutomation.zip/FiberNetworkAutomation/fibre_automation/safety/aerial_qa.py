"""aerial_qa — aerial fibre-engineering QA (pure math, zero deps, shippable).

Catches the aerial-plant problems that bite in the field: over-length spans,
excessive cable sag, and insufficient ground clearance over roads/paths. Pure
functions (data in → verdict out), so they plug into /audit or any layer sweep
without coupling to QGIS.

  span_check(span_m, cable_class)            ≤ max span for the cable role
  sag_m(span_m, weight, tension)             parabolic sag D = w·S²/(8·T)
  clearance_check(attach_h, span_m, terrain) ground clearance after sag vs NESC/SANS
  aerial_qa(spans)                           summarise a list of spans
"""

# Max pole-to-pole span (m) by cable role (project spec: 70 m ADSS feeder/dist, 50 m drop).
SPAN_LIMITS_M = {"feeder": 70.0, "distribution": 70.0, "secondary": 70.0,
                 "primary": 70.0, "drop": 50.0}

# Minimum ground clearance (m) by what the span crosses (NESC/SANS-aligned).
MIN_CLEARANCE_M = {"road": 5.5, "highway": 6.0, "driveway": 4.6,
                   "pedestrian": 3.5, "field": 3.0, "rail": 7.2}

# SA minimum pole height above ground (m) for aerial fibre.
MIN_POLE_HEIGHT_M = 9.0

# ADSS defaults: cable weight (N/m) and stringing tension (N) — override per project.
DEFAULT_WEIGHT_N_PER_M = 1.2
DEFAULT_TENSION_N = 2000.0


def span_check(span_m, cable_class="feeder"):
    limit = SPAN_LIMITS_M.get(cable_class, 70.0)
    over = max(0.0, span_m - limit)
    return {"span_m": round(span_m, 2), "limit_m": limit,
            "over_m": round(over, 2), "pass": over <= 0.0}


def sag_m(span_m, weight_n_per_m=DEFAULT_WEIGHT_N_PER_M, tension_n=DEFAULT_TENSION_N):
    """Parabolic mid-span sag (m). D = w·S²/(8·T)."""
    if tension_n <= 0:
        # Invalid/zero tension means the cable cannot be held taut — physically it
        # droops maximally, not zero. Return inf so clearance_check fails (safe-fail)
        # instead of falsely passing every terrain threshold.
        return float('inf')
    return (weight_n_per_m * span_m * span_m) / (8.0 * tension_n)


def clearance_check(attach_height_m, span_m, terrain="road",
                    weight_n_per_m=DEFAULT_WEIGHT_N_PER_M, tension_n=DEFAULT_TENSION_N):
    """Ground clearance at mid-span after sag, vs the minimum for the terrain."""
    d = sag_m(span_m, weight_n_per_m, tension_n)
    ground = attach_height_m - d
    req = MIN_CLEARANCE_M.get(terrain, 3.0)
    return {"sag_m": round(d, 3), "ground_clearance_m": round(ground, 3),
            "required_m": req, "terrain": terrain, "pass": ground >= req}


def pole_height_check(height_m):
    return {"height_m": round(height_m, 2), "min_m": MIN_POLE_HEIGHT_M,
            "pass": height_m >= MIN_POLE_HEIGHT_M}


def aerial_qa(spans, weight_n_per_m=DEFAULT_WEIGHT_N_PER_M, tension_n=DEFAULT_TENSION_N):
    """spans = list of dicts: {span_m, cable_class?, attach_height_m?, terrain?}.
    Returns {total, span_fails, clearance_fails, issues:[...]}."""
    total = 0
    span_fails = clear_fails = 0
    issues = []
    for i, s in enumerate(spans):
        if not isinstance(s, dict) or s.get("span_m") is None:
            continue
        total += 1
        sm = s["span_m"]
        sc = span_check(sm, s.get("cable_class", "feeder"))
        if not sc["pass"]:
            span_fails += 1
            issues.append({"index": i, "type": "span", **sc})
        ah = s.get("attach_height_m")
        if ah is not None:
            cc = clearance_check(ah, sm, s.get("terrain", "road"),
                                 weight_n_per_m, tension_n)
            if not cc["pass"]:
                clear_fails += 1
                issues.append({"index": i, "type": "clearance", "span_m": round(sm, 2), **cc})
    return {"total": total, "span_fails": span_fails,
            "clearance_fails": clear_fails, "issues": issues[:100]}
