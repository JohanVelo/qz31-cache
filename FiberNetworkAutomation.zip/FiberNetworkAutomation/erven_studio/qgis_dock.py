"""Erven Studio — QGIS dock + toolbar button. Runs INSIDE QGIS (qgis.PyQt / QgsTask).

Adjust sliders -> Run -> a QgsTask shells out to the venv worker (qgis_worker.py, heavy deps) ->
loads Buildings / Erven / Demand as layers. QGIS never freezes (background task); the worker never
touches QGIS objects (we pass only a serialized AOI + params).

Install in the running QGIS (via the bridge):
    exec(open(r"<repo>/erven_studio/qgis_dock.py", encoding="utf-8").read())
    ErvenStudio.install()
"""
import json
import os
import subprocess
from pathlib import Path

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QDockWidget, QWidget, QVBoxLayout, QFormLayout,
                                 QLabel, QDoubleSpinBox, QCheckBox, QComboBox, QPushButton,
                                 QProgressBar, QFileDialog)
from qgis.core import (QgsTask, QgsApplication, QgsProject, QgsVectorLayer, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFillSymbol,
                       QgsMarkerSymbol)
from qgis.utils import iface

def _python_exe():
    """Worker interpreter: dev venv if present, else QGIS's bundled
    python.exe (sys.executable is qgis-bin.exe inside QGIS on Windows)."""
    try:
        from fibre_automation.shared.vf_paths import python_exe
        return python_exe()
    except Exception:
        import sys
        venv = Path.home() / ".qgis-venv" / "Scripts" / "python.exe"
        if venv.exists():
            return str(venv)
        cand = Path(sys.exec_prefix) / "python.exe"
        return str(cand) if cand.exists() else sys.executable


def _data_dir():
    try:
        from fibre_automation.shared.vf_paths import data_dir
        return data_dir()
    except Exception:
        import tempfile
        d = "C:/Temp" if os.path.isdir("C:/Temp") else \
            os.path.join(tempfile.gettempdir(), "VelocityFibre")
        os.makedirs(d, exist_ok=True)
        return d


VENV = _python_exe()
WORKER = str(Path(__file__).resolve().parent / "qgis_worker.py") if "__file__" in dir() \
    else r"C:/Users/jjsch/OneDrive - blitzfibre.com/Documents/Workspace/QGIS/erven_studio/qgis_worker.py"
OUTDIR = _data_dir()
AOI_PATH = OUTDIR + "/_studio_aoi.geojson"
PARAMS_PATH = OUTDIR + "/_studio_params.json"


# ── export the current AOI to GeoJSON (fresh every run) ──
def _export_aoi():
    p = QgsProject.instance()
    lyrs = {l.name(): l for l in p.mapLayers().values()}
    aoi = next((lyrs[n] for n in ("P2 AOI Poly", "AOI", "AOI Poly") if n in lyrs), None)
    dst = QgsCoordinateReferenceSystem("EPSG:4326")
    feats = []
    if aoi is not None:
        xf = QgsCoordinateTransform(aoi.crs(), dst, p) if aoi.crs() != dst else None
        for f in aoi.getFeatures():
            g = f.geometry()
            if xf:
                g.transform(xf)
            feats.append({"type": "Feature", "properties": {}, "geometry": json.loads(g.asJson())})
    if not feats:                                   # fall back to canvas extent
        e = iface.mapCanvas().extent(); c = iface.mapCanvas().mapSettings().destinationCrs()
        xf = QgsCoordinateTransform(c, dst, p) if c != dst else None
        from qgis.core import QgsGeometry
        g = QgsGeometry.fromRect(e)
        if xf:
            g.transform(xf)
        feats.append({"type": "Feature", "properties": {}, "geometry": json.loads(g.asJson())})
    Path(AOI_PATH).write_text(json.dumps({"type": "FeatureCollection", "features": feats}), encoding="utf-8")
    return aoi.name() if aoi is not None else "canvas extent"


def _load_layers():
    p = QgsProject.instance()
    specs = [("studio_buildings.geojson", "Buildings (studio)", "0,255,0,255", None),
             ("studio_erven.geojson", "Erven (studio)", "255,160,0,255", None),
             ("studio_demand.geojson", "Demand (studio)", None, "0,230,0,255")]
    for fn, name, line, pt in specs:
        path = f"{OUTDIR}/{fn}"
        if not Path(path).exists():
            continue
        for l in list(p.mapLayers().values()):
            if l.name() == name:
                p.removeMapLayer(l.id())
        v = QgsVectorLayer(path, name, "ogr")
        if not v.isValid():
            continue
        if pt:
            v.renderer().setSymbol(QgsMarkerSymbol.createSimple(
                {"name": "circle", "size": "1.1", "color": pt, "outline_style": "no"}))
        elif line:
            v.renderer().setSymbol(QgsFillSymbol.createSimple(
                {"color": "0,0,0,0", "outline_color": line, "outline_width": "0.4"}))
        p.addMapLayer(v)
    iface.mapCanvas().refreshAllLayers()


class ErvenTask(QgsTask):
    def __init__(self, params):
        super().__init__("Erven Studio detection", QgsTask.CanCancel)
        self.params = params; self.err = ""

    def run(self):
        Path(PARAMS_PATH).write_text(json.dumps(self.params), encoding="utf-8")
        proc = subprocess.Popen([VENV, WORKER, PARAMS_PATH], stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, text=True,
                                creationflags=0x08000000)  # no console window
        for line in proc.stdout:
            if line.startswith("PROGRESS:"):
                try:
                    self.setProgress(float(line.split(":")[1]))
                except ValueError:
                    pass
            if self.isCanceled():
                proc.terminate(); return False
        proc.wait()
        self.err = proc.stderr.read()
        return proc.returncode == 0

    def finished(self, ok):
        if ok:
            _load_layers()
            iface.messageBar().pushSuccess("Erven Studio", "Done — layers loaded.")
        else:
            iface.messageBar().pushWarning("Erven Studio", "Run failed. Last error: " + (self.err or "")[-300:])


class _Dock(QDockWidget):
    def __init__(self):
        super().__init__("Erven Studio")
        w = QWidget(); lay = QVBoxLayout(w)
        lay.addWidget(QLabel("<b>Detect buildings → cadastral erven → demand points</b>"))
        form = QFormLayout()

        def spin(lo, hi, val, step=1.0, dec=0):
            s = QDoubleSpinBox(); s.setRange(lo, hi); s.setValue(val); s.setSingleStep(step); s.setDecimals(dec)
            return s

        self.source = QComboBox(); self.source.addItems(["Google Open Buildings (crisp)", "Google Open Buildings (raw)"])
        self.merge = spin(6, 24, 12); self.sw = spin(0, 30, 0); self.sd = spin(15, 45, 27)
        self.osnap = QCheckBox(); self.osnap.setChecked(True)
        self.mina = spin(30, 300, 60, 10); self.maxa = spin(300, 2000, 1300, 50)
        form.addRow("Building source", self.source)
        form.addRow("Block merge (m)", self.merge)
        form.addRow("Stand width (m, 0=auto)", self.sw)
        form.addRow("Stand depth (m)", self.sd)
        form.addRow("Snap to street", self.osnap)
        form.addRow("Min erf (m²)", self.mina)
        form.addRow("Max erf (m²)", self.maxa)
        lay.addLayout(form)

        self.examples = None
        ex_btn = QPushButton("Learn lot size from example erven…")
        ex_btn.clicked.connect(self._pick_examples)
        self.ex_lbl = QLabel("(optional: pick a GeoJSON/SHP of example erven)")
        lay.addWidget(ex_btn); lay.addWidget(self.ex_lbl)

        self.run_btn = QPushButton("▶ Run")
        self.run_btn.clicked.connect(self._run)
        self.bar = QProgressBar(); self.bar.setRange(0, 100)
        self.status = QLabel("")
        lay.addWidget(self.run_btn); lay.addWidget(self.bar); lay.addWidget(self.status)
        lay.addStretch(1)
        self.setWidget(w)

    def _pick_examples(self):
        f, _ = QFileDialog.getOpenFileName(self, "Example erven", OUTDIR, "Vector (*.geojson *.shp)")
        if f:
            self.examples = f; self.ex_lbl.setText("examples: " + Path(f).name)

    def _run(self, detect_only=False):
        # release file locks: remove previous studio outputs before the worker overwrites them
        proj = QgsProject.instance()
        for l in list(proj.mapLayers().values()):
            if l.name() in ("Buildings (studio)", "Erven (studio)", "Demand (studio)"):
                proj.removeMapLayer(l.id())
        aoi_name = _export_aoi()
        crisp = self.source.currentIndex() == 0
        params = {
            "aoi_geojson_path": AOI_PATH, "outdir": OUTDIR, "crisp": crisp,
            "merge_m": self.merge.value(), "stand_W": self.sw.value(),
            "stand_depth": self.sd.value(), "orient_snap": self.osnap.isChecked(),
            "min_area": self.mina.value(), "max_area": self.maxa.value(),
            "detect_only": bool(detect_only),
        }
        if self.examples and not detect_only:
            params["example_erven_path"] = self.examples
        self.status.setText(("detecting buildings on " if detect_only else "running on ") + f"AOI: {aoi_name} …")
        task = ErvenTask(params)
        task.progressChanged.connect(lambda: self.bar.setValue(int(task.progress())))
        task.taskCompleted.connect(lambda: self.status.setText("done ✓"))
        task.taskTerminated.connect(lambda: self.status.setText("failed — see message bar"))
        QgsApplication.taskManager().addTask(task)
        ErvenStudio._task_ref = task                       # keep a reference alive


class ErvenStudio:
    _dock = None
    _action = None
    _task_ref = None

    @classmethod
    def install(cls):
        mw = iface.mainWindow()
        if cls._dock is None:
            cls._dock = _Dock()
            iface.addDockWidget(Qt.RightDockWidgetArea, cls._dock)
        cls._dock.show(); cls._dock.raise_()
        # toolbar button (toggle dock)
        if cls._action is None:
            from qgis.PyQt.QtWidgets import QAction
            cls._action = QAction("Erven Studio", mw)
            cls._action.setToolTip("Erven Studio — detect + tune erven")
            cls._action.triggered.connect(lambda: (cls._dock.show(), cls._dock.raise_()))
            iface.addToolBarIcon(cls._action)
        return "Erven Studio installed"

    @classmethod
    def run_now(cls):
        """One-click: detect → cadastral erven → demand on the live AOI (no server)."""
        cls.install()
        cls._dock._run()
        return "Erven Studio run started"

    @classmethod
    def detect_now(cls):
        """One-click building detection only (Google Open Buildings, no server)."""
        cls.install()
        cls._dock._run(detect_only=True)
        return "Building detection started"
