# QGIS Plugin: Fiber Network Automation
# Main plugin class — config-driven toolbar
# claude:approved-destructive — EnclosureEditorPanel writes only on explicit UI button clicks

import os
from collections import OrderedDict
from qgis.core import QgsApplication, QgsProject, QgsWkbTypes
from qgis.core import Qgis  # Qt6: messageBar/log levels are Qgis.MessageLevel enums
from qgis.PyQt.QtWidgets import QApplication, QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QFrame, QToolButton, QMenu, QWidgetAction, QWidget, QDockWidget
from qgis.PyQt.QtGui import QAction
from qgis.PyQt.QtCore import Qt, QSize, QTimer, QEvent
from qgis.PyQt.QtGui import QColor, QIcon, QPen, QPainter
from qgis.PyQt.QtCore import QPointF
from qgis.gui import QgsRubberBand, QgsMapCanvasItem

from .fiber_processing_provider import FiberNetworkProvider

try:
    from . import theme_safe
except ImportError:
    pass   # standalone fallback


# ══════════════════════════════════════════════════════════════════════════════
# TOOLBAR_SPEC — the single source of truth for every button on the toolbar.
# Add a new automation = one dict entry. Flip enabled:False → True to activate.
# ══════════════════════════════════════════════════════════════════════════════

TOOLBAR_SPEC = [
    # ── Brand tile + quick action (inline) ────────────────────────────────────
    {"id": "brand",      "kind": "brand",  "group": "quick"},
    {"id": "run_q",      "kind": "action", "group": "quick", "client": "dev",
     "label": "⚙ Run q.py", "icon": "/mActionTerminal.svg",
     "tooltip": "Copy  exec(open('C:/Temp/q.py').read())  to clipboard.\nPaste into the QGIS Python Console to run the script.",
     "callback": "_run_q"},
    {"id": "ai_detect",  "kind": "callback", "group": "quick", "client": "dev",
     "label": "AI Detect", "icon": "/mActionPointLayer.svg",
     "callback": "_erven_detect_run",
     "tooltip": (
        "AI DETECT — SAM2 AutoMask building footprints.\n"
        "─────────────────────────────\n"
        "1. Zoom canvas to ≤300m wide (1:1500 or closer)\n"
        "2. Click — current canvas extent is used\n"
        "3. Wait ~3–7 min · BF16 autocast on RTX 3050\n"
        "4. Layer 'Buildings_detected' added with confidence QA\n"
        "─────────────────────────────\n"
        "Server: erven_mcp HTTP @ 127.0.0.1:8780\n"
        "Start: python -m erven_mcp.server --http  (erven_detection/src/)\n"
        "GPU: RTX 3050 CUDA · sam2-hiera-small · BF16 autocast")
     },
    {"id": "ai_erven",  "kind": "callback", "group": "quick", "client": "dev",
     "label": "AI Erven", "icon": "/mActionAddPolygon.svg",
     "callback": "_erven_erven_run",
     "tooltip": (
        "AI ERVEN — Buildings + property parcels (momepy tessellation).\n"
        "─────────────────────────────\n"
        "Runs AI Detect THEN generates Erven_detected parcels:\n"
        "each building gets a territory extending to the road\n"
        "edge and the midpoint between neighbouring buildings.\n"
        "─────────────────────────────\n"
        "Requires: C:/Temp/roads.json  (run /roads to refresh)\n"
        "          momepy 0.11.0+ installed in qgis-venv\n"
        "Output layers: Buildings_detected + Erven_detected\n"
        "Time: ~5–10 min (canvas tile + tessellation)")
     },
    {"id": "velo_detect", "kind": "callback", "group": "quick", "client": "dev",
     "label": "AutoDetect", "icon": "/mActionInOverview.svg",
     "callback": "_velo_detect_run",
     "tooltip": (
        "VELODECT — batch SAM2 building detection over the full AOI.\n"
        "─────────────────────────────\n"
        "Tiles the entire AOI at 0.3 m/px, sends each 512px chip\n"
        "to the SAM2 server, and places all buildings as\n"
        "'AI Centroids' + 'AI Buildings' memory layers.\n"
        "─────────────────────────────\n"
        "SAM2: http://192.168.1.150:8102/predict\n"
        "No clicking required — processes full AOI automatically.\n"
        "Start server: python C:/Temp/sam2_server.py")
     },
    {"id": "update_git", "kind": "callback", "group": "quick", "client": "dev",
     "label": "⬇ Update", "icon": "/mActionRefresh.svg",
     "callback": "_update_from_github",
     "tooltip": (
        "UPDATE FROM GITHUB — pull the latest code and reload this plugin.\n"
        "─────────────────────────────\n"
        "1. Runs  git pull  in your VeloPlan repo clone\n"
        "2. Copies the updated plugin files into QGIS\n"
        "3. Reloads FiberNetworkAutomation live (no QGIS restart)\n"
        "─────────────────────────────\n"
        "First use: you'll be asked to pick your VeloPlan repo folder\n"
        "(the clone that contains a .git folder). Needs Git installed.")
     },
    # New project is handled entirely by the welcome dialog (_show_welcome_dialog)
    # which fires automatically on File → New.  No toolbar buttons needed here.

    # ── Labelling — PRAK / MALM legacy (dropdown) ─────────────────────────────
    {"id": "lbl_aggregation", "kind": "algo", "group": "labelling",
     "label": "Label Aggregation Polygons", "icon": "/mActionCapturePolygon.svg",
     "algorithm": "fibernetwork:labelaggregation",
     "tooltip": "PRAK / MALM — labels the aggregation polygons"},
    {"id": "lbl_blocks",      "kind": "algo", "group": "labelling",
     "label": "Label Blocks",               "icon": "/mActionCapturePolygon.svg",
     "algorithm": "fibernetwork:labelblocks",
     "tooltip": "PRAK / MALM — labels the block polygons"},
    {"id": "lbl_poles",       "kind": "algo", "group": "labelling",
     "label": "Label Poles",                "icon": "/mActionCapturePoint.svg",
     "algorithm": "fibernetwork:labelpoles",
     "tooltip": "PRAK / MALM — labels the poles"},
    {"id": "lbl_dome_joints", "kind": "algo", "group": "labelling",
     "label": "Label Dome Joints",          "icon": "/mActionCapturePoint.svg",
     "algorithm": "fibernetwork:labeldomejoints",
     "tooltip": "PRAK / MALM — labels the dome joints"},
    {"id": "lbl_feeder_joints","kind": "algo", "group": "labelling",
     "label": "Label Feeder Joints",        "icon": "/mActionCapturePoint.svg",
     "algorithm": "fibernetwork:labelfeederjoints",
     "tooltip": "PRAK / MALM — labels the feeder joints"},
    {"id": "lbl_demand_pts",  "kind": "algo", "group": "labelling",
     "label": "Label Demand Points",        "icon": "/mActionCapturePoint.svg",
     "algorithm": "fibernetwork:labeldemandpoints",
     "tooltip": "PRAK / MALM — labels the demand points"},
    {"id": "lbl_feeder_cables","kind": "algo", "group": "labelling",
     "label": "Label Feeder Cables",        "icon": "/mActionCaptureLine.svg",
     "algorithm": "fibernetwork:labelfeedercables",
     "tooltip": "PRAK / MALM — labels the feeder cables"},
    {"id": "lbl_dist_cables", "kind": "algo", "group": "labelling",
     "label": "Label Distribution Cables",  "icon": "/mActionCaptureLine.svg",
     "algorithm": "fibernetwork:labeldistributioncables",
     "tooltip": "PRAK / MALM — labels the distribution cables"},
    # ── Build FT 1-7 pipeline (dropdown with macro) ───────────────────────────
    {"id": "ft1", "kind": "algo", "group": "ft",
     "label": "FT1 · Label Poles",            "icon": "/mActionNewVectorLayer.svg",
     "algorithm": "fibernetwork:ft_label_poles",
     "tooltip": "Phase 2 / MOA — writes label, lat, lon to Poles v1"},
    {"id": "ft2", "kind": "algo", "group": "ft",
     "label": "FT2 · Label Distribution Cable","icon": "/mActionAddLineString.svg",
     "algorithm": "fibernetwork:ft_label_distribution_cable",
     "tooltip": "Phase 2 / MOA — labels Distribution Cable v1 (label poles first)"},
    {"id": "ft3", "kind": "algo", "group": "ft",
     "label": "FT3 · Label Secondary Cable",   "icon": "/mActionAddLineString.svg",
     "algorithm": "fibernetwork:ft_label_secondary_cable",
     "tooltip": "⚠ hardcodes 24F — do NOT run on Phase 2 / MOA"},
    {"id": "ft4", "kind": "algo", "group": "ft",
     "label": "FT4 · Label Enclosure",         "icon": "/mActionAddOgrLayer.svg",
     "algorithm": "fibernetwork:ft_label_enclosure",
     "tooltip": "Phase 2 / MOA — labels Enclosure v1 (AGG / DIS domes)"},
    {"id": "ft4b","kind": "algo", "group": "ft",
     "label": "FT4b · Label STS Splitters",    "icon": "/mActionCapturePoint.svg",
     "algorithm": "fibernetwork:ft_label_sts_splitters",
     "tooltip": "Phase 2 / MOA — labels the STS splitter points"},
    {"id": "ft5", "kind": "algo", "group": "ft",
     "label": "FT5 · Generate PON Zones",      "icon": "/mActionAddPolygon.svg",
     "algorithm": "fibernetwork:ft_generate_pon_zones",
     "tooltip": "Phase 2 / MOA — builds PON zones (16 PONs = 1 zone)"},
    {"id": "ft6", "kind": "algo", "group": "ft",
     "label": "FT6 · Apply PON Order",         "icon": "/mActionArrowDown.svg",
     "algorithm": "fibernetwork:ft_apply_pon_order",
     "tooltip": "Phase 2 / MOA — applies feeder-path PON order (needs pon_feeder_order.txt)"},
    {"id": "ft7", "kind": "algo", "group": "ft",
     "label": "FT7 · Pole Thickness",          "icon": "/mIconRulers.svg",
     "algorithm": "fibernetwork:ft_pole_thickness",
     "tooltip": "Phase 2 / MOA — classifies pole thickness (needs C:/Temp/roads.json)"},
    {"id": "ft_sep",    "kind": "separator", "group": "ft"},
    {"id": "ft_all",    "kind": "macro", "group": "ft",
     "label": "⚡ Run All (FT 1→7)", "icon": "/mActionStart.svg",
     "callback": "_run_ft_pipeline",
     "tooltip": "Runs FT1 → FT2 → FT3 → FT4 → FT5 → FT6 → FT7 sequentially."},

    # ── Audit & QA (dropdown) ────────────────────────────────────────────────
    {"id": "audit_hld",  "kind": "script", "group": "audit",
     "label": "HLD Audit",           "icon": "/mIconSuccess.svg",
     "script": r"C:/Users/jjsch/OneDrive - blitzfibre.com/Documents/Workspace/QGIS/audit_all_ph2.py",
     "tooltip": "Full Phase 2 HLD compliance audit — results in Python Console"},
    {"id": "span_check", "kind": "callback", "group": "audit",
     "label": "Check Spans",           "icon": "/mActionMeasure.svg",
     "callback": "_run_span_check",
     "tooltip": "Pole-to-pole span check. Drop>55m, Dist/Sec/Primary>70m.\nCreates a 'Span Violations' memory layer with each bad span as a red line."},
    {"id": "update_layers","kind": "callback", "group": "audit",
     "label": "Refresh Attributes",    "icon": "/mActionRefresh.svg",
     "callback": "_run_update_layers",
     "tooltip": "Re-run attribute refresh on Drop / Spare Drop / ONT / STS after edits"},

    # ── Automations menu removed — duplicated by fibretime_tools toolbar ──

    # ── Interactive tools (inline) ────────────────────────────────────────────
    {"id": "enc_editor", "kind": "callback", "group": "tools", "client": "both",
     "label": "Enclosures",           "icon": "/mActionAddOgrLayer.svg",
     "callback": "_open_enc_editor",
     "tooltip": (
        "ENCLOSURE EDITOR — inspect & reclassify enclosures on the canvas.\n"
        "─────────────────────────────\n"
        "Opens a floating panel. Use the Select Features tool (S key) to pick\n"
        "enclosures on the map, then click a type button to reclassify:\n"
        "  🟠 Distribution Joint (ODCFD0 / 24F)  — standard distribution dome\n"
        "  🟣 Spur Route (M16 Microloop / 48F)   — diverging-route dome\n"
        "  🔵 Feeder Splice UMJ / 72F            — secondary feeder joint\n"
        "  🟢 Feeder Splice CMJ / 144F           — primary feeder joint\n"
        "─────────────────────────────\n"
        "Canvas overlays:\n"
        "  🟠 orange diamond = Distribution (ODCFD0/24F)\n"
        "  🟣 purple square  = Spur Route (M16 Microloop/48F)\n"
        "  🔵 cyan circle    = Feeder UMJ/72F\n"
        "  🟢 green circle   = Feeder CMJ/144F")
     },
    {"id": "pole_editor","kind": "callback", "group": "tools", "client": "both",
     "label": "📍 Pole Editor",       "icon": "/mActionCapturePoint.svg",
     "callback": "_open_pole_editor",
     "tooltip": (
        "POLE EDITOR — inspect & correct individual poles on the canvas.\n"
        "─────────────────────────────\n"
        "Opens a floating panel. Click any pole on the map, then use buttons to:\n"
        "  🟢 Mark Road Crossing      — tag this pole as an RC (affects FT7 thickness)\n"
        "  🔴 Not Road Crossing       — revoke RC tag (auto-downgrade to 120-140mm)\n"
        "  🔵 140-160mm (Thick)        — force dim2=140-160mm (anchor/strain)\n"
        "  ⚪  120-140mm (Thin)        — force dim2=120-140mm (intermediate)\n"
        "─────────────────────────────\n"
        "Canvas legend (dots on poles):\n"
        "  🔵 Cyan   = 140-160mm thick pole\n"
        "  🟢 Green  = road crossing pole\n"
        "  🔴 Red    = confirmed NOT road crossing\n"
        "  🟡 Yellow = FTS splitter pole\n"
        "Tip: Shift+click to multi-select. Edits auto-refresh when the panel closes.")
     },
    {"id": "route_viewer","kind": "callback", "group": "tools", "client": "both",
     "label": "🔦 Splice Viewer",      "icon": "/mActionTracing.svg",
     "callback": "_open_route_viewer",
     "tooltip": (
        "SPLICE ROUTE VIEWER — cross-check the Excel splice plan on the canvas.\n"
        "─────────────────────────────\n"
        "Opens a floating panel. Pick an OLT port (= one PON sheet in the Excel)\n"
        "and the panel lights up that PON's entire fibre route on the map,\n"
        "colour-coded by hop, zooms to it, and selects the features (so the\n"
        "attribute table shows exactly what's lit).\n"
        "  OLT port → feeder → AGG dome → FTS → distribution → DIS dome →\n"
        "  STS → drop → ONT\n"
        "Narrow to a single STS leg to trace one branch. Prev/Next steps PONs.\n"
        "─────────────────────────────\n"
        "Canvas colours:\n"
        "  🟥 feeder cable   🟧 distribution cable   🟨 drop cables\n"
        "  🔷 AGG dome (FTS/fusion)   🔵 DIS dome (STS/connectorised)\n"
        "  🟪 FTS 1:16   🟩 STS 1:8   ⚪ ONT / home\n"
        "Read-out lists every label so you can tick it against the sheet.")
     },
    {"id": "canvas",     "kind": "callback", "group": "tools", "client": "dev",
     "label": "📸 Canvas",             "icon": "/mActionSaveMapAsImage.svg",
     "callback": "_snap_canvas",
     "tooltip": (
        "CANVAS SNAPSHOT — save current map view to disk for Claude.\n"
        "─────────────────────────────\n"
        "Writes the visible canvas (current extent + layer state) to\n"
        "  C:/Temp/canvas.png\n"
        "Then copies it to the clipboard so Claude can paste-receive it.\n"
        "Use for visual verification after edits or to share a view.")
     },
    # Erven Generator moved into Vuma ▼ dropdown as step 01c — not a standalone toolbar button.
]

GROUPS = OrderedDict([
    ("quick",     {"title": None,              "kind": "inline", "client": "both"}),
    ("labelling", {"title": "Label Layers",    "kind": "menu",  "client": "vuma",
                   "tooltip": (
                       "LABELLING (Group A) — legacy PRAK / MALM projects.\n"
                       "─────────────────────────\n"
                       "One algorithm per layer. Each takes a PROJECT enum\n"
                       "(PRAK or MALM) and writes the standard label fields:\n"
                       "  • Label Aggregation Polygons (Label, fid)\n"
                       "  • Label Blocks (Label., fid — trailing dot)\n"
                       "  • Label Poles (id, Name, X, Y, AG, Block, fid)\n"
                       "  • Label Dome Joints (id, Name, x, y, Block, AG)\n"
                       "  • Label Feeder Joints (Label, fid — AG prefix)\n"
                       "  • Label Demand Points (coords, AG, Block, Zone)\n"
                       "  • Label Feeder Cables (Feeder Cab, Tlenght, Slenght)\n"
                       "  • Label Distribution Cables (Dist Cable, AG, lengths)\n"
                       "Not for Phase 2 MOA. Use Build FT 1-7 for MOA.")}),
    ("ft",        {"title": "FT Pipeline",      "kind": "menu",  "client": "ft",
                   "tooltip": (
                       "BUILD FT 1-7 (Group B) — Fibertime MOA pipeline.\n"
                       "─────────────────────────\n"
                       "Run in order, or use ⚡ Run FT 1..7 to chain them all.\n"
                       "MOA-hardcoded — no PROJECT parameter.\n"
                       "  FT1 · Label Poles             — Label, lat, lon\n"
                       "  FT2 · Label Distribution Cable — pole-to-pole refs\n"
                       "  FT3 · Label Secondary Cable    — secondary feeder\n"
                       "  FT4 · Label Enclosure          — CMJ/UMJ splice domes\n"
                       "  FT4b · Label STS Splitters     — STS dome labels\n"
                       "  FT5 · Generate PON Zones       — PON polygons from ONT k-means\n"
                       "  FT6 · Apply PON Order          — feeder-path order → pon_no\n"
                       "  FT7 · Pole Thickness           — FOA 2015:35 (140-160 vs 120-140)\n"
                       "  ⚡  Run FT 1..7                 — runs all 7 in sequence.\n"
                       "FT6 needs pon_feeder_order.txt, FT7 needs C:/Temp/roads.json.")}),
    ("audit",     {"title": "✓ Compliance",     "kind": "menu",  "client": "ft",
                   "tooltip": (
                       "AUDIT & QA — compliance checks + maintenance.\n"
                       "─────────────────────────\n"
                       "  Run HLD Audit           — full Phase 2 audit_all_ph2.py\n"
                       "                            (null geoms, label, pon_no range,\n"
                       "                             zone/pon mismatch, datecrtd,\n"
                       "                             lat/lon, strtfeat/endfeat, etc.)\n"
                       "  Check Span Violations   — pole-to-pole geodesic spans.\n"
                       "                            Drop>55m, Dist/Sec/Primary>70m.\n"
                       "                            Creates 'Span Violations' memory\n"
                       "                            layer with each bad span as red line.\n"
                       "  Update Layer Attributes — re-run attribute refresh on Drop\n"
                       "                            Cable, Spare Drop, ONT, STS.\n"
                       "  Export HLD Package      — coming soon (QGZ + GPKG + BOM).")}),
    ("tools",     {"title": None,              "kind": "inline", "client": "both"}),
])


# ══════════════════════════════════════════════════════════════════════════════
# Stylesheet — applied once to the toolbar; children inherit.
# ══════════════════════════════════════════════════════════════════════════════
# Mirror eye QSS — three states (watching / idle / off)
_MIRROR_EYE_BASE = (
    "QPushButton#FNAMirrorEye {{"
    " background:{bg}; color:{fg};"
    " border:1px solid {border}; border-radius:6px;"
    " padding:4px 10px; margin:0 4px;"
    " font-family:'Segoe UI'; font-size:11px; font-weight:600;"
    " min-height:22px; }}"
    "QPushButton#FNAMirrorEye:hover {{ border:1px solid #8067D8; }}"
)
_MIRROR_EYE_WATCHING_QSS = _MIRROR_EYE_BASE.format(
    bg='#15803D', fg='#FFFFFF', border='#22C55E')
_MIRROR_EYE_IDLE_QSS = _MIRROR_EYE_BASE.format(
    bg='#92400E', fg='#FFFFFF', border='#F59E0B')
_MIRROR_EYE_OFF_QSS = _MIRROR_EYE_BASE.format(
    bg='#3A3D5C', fg='#A0A4BC', border='#5A5F88')

# Client-branded button QSS — Vuma = orange, Fibretime = teal
# Applied to group dropdown buttons and absorbed fibretime_tools buttons.
_VUMA_BTN_QSS = (
    'QToolButton { background: #FF0090; color: white; border: none;'
    ' border-radius: 4px; padding: 3px 10px;'
    ' font-family: "Segoe UI"; font-size: 11px; font-weight: 900; }'
    'QToolButton::menu-indicator { image: none; }'
    'QToolButton:hover { background: #FF33A8; }'
)
_FT_BTN_QSS = (
    'QToolButton { background: qlineargradient(x1:0,y1:0,x2:1,y2:0,'
    ' stop:0 #2ABFCC, stop:0.28 #2ABFCC,'
    ' stop:0.281 #FFE619, stop:0.719 #FFE619,'
    ' stop:0.72 #2ABFCC, stop:1 #2ABFCC);'
    ' color: #1A3040; border: none;'
    ' border-radius: 4px; padding: 3px 10px;'
    ' font-family: "Segoe UI"; font-size: 11px; font-weight: 800; }'
    'QToolButton::menu-indicator { image: none; }'
    'QToolButton:hover { background: #FFE619; color: #1A3040; }'
)
_HEROTEL_BTN_QSS = (
    'QToolButton { background: #FF4500; color: white; border: none;'
    ' border-radius: 4px; padding: 3px 10px;'
    ' font-family: "Segoe UI"; font-size: 11px; font-weight: 700; }'
    'QToolButton::menu-indicator { image: none; }'
    'QToolButton:hover { background: #FF6622; }'
)


_TOOLBAR_QSS_TEMPLATE = """
/* === FiberNetworkAutomation modern dark — scoped to plugin toolbar/menus ===
 * Material-3-derived tokens; does NOT touch QGIS chrome.
 * 2026-04-28 redesign per research_toolbar_ux_redesign_2026-04-28.md
 */
QToolBar#FiberNetworkAutomationToolbar {{
    background: {tb_bg}; border: 0;
    border-bottom: 1px solid {tb_border};
    padding: 4px 6px; spacing: 4px;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton {{
    background: {btn_bg}; color: {btn_text};
    border: 1px solid transparent; border-radius: 6px;
    padding: 6px 10px; margin: 0 2px;
    font-family: 'Segoe UI'; font-size: 12px; font-weight: 500;
    min-height: 22px;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton:hover {{
    background: {btn_hover}; border: 1px solid {tb_border};
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton:pressed {{
    background: {btn_hover};
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton:checked {{
    background: {checked_bg}; color: {checked_text}; border: 1px solid {checked_bg};
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton:disabled {{
    color: {disabled_text}; background: {tb_bg};
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton::menu-indicator {{
    subcontrol-position: right center; right: 4px;
    image: none; width: 8px;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton[popupMode="1"] {{
    padding-right: 16px;
}}

/* Brand tile — gradient + bridge state via dynamic property */
QToolBar#FiberNetworkAutomationToolbar QToolButton#FNABrandTile {{
    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                                stop:0 #6E56CF, stop:1 #8067D8);
    color: #FFFFFF; font-weight: 700;
    border: 1px solid #5A45B0; border-radius: 6px;
    padding: 6px 12px;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton#FNABrandTile:hover {{
    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                                stop:0 #8067D8, stop:1 #9A82E6);
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton#FNABrandTile[bridge="offline"] {{
    background: #DC2626; border-color: #991B1B;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton#FNABrandTile[bridge="online"] {{
    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                                stop:0 #16A34A, stop:1 #22C55E);
    border-color: #15803D;
}}

QToolBar#FiberNetworkAutomationToolbar::separator {{
    background: {tb_border}; width: 1px; margin: 6px 6px;
}}

/* Dropdown menus opened from toolbar */
QToolBar#FiberNetworkAutomationToolbar QMenu {{
    background: {btn_bg}; color: {btn_text};
    border: 1px solid {tb_border}; border-radius: 6px;
    padding: 4px;
}}
QToolBar#FiberNetworkAutomationToolbar QMenu::item {{
    padding: 6px 14px 6px 28px; border-radius: 4px;
}}
QToolBar#FiberNetworkAutomationToolbar QMenu::item:selected {{
    background: {btn_hover};
}}
QToolBar#FiberNetworkAutomationToolbar QMenu::separator {{
    height: 1px; background: {tb_border}; margin: 4px 6px;
}}
"""


# ── Velocity-Nexus-theme → toolbar colour mapping (ticket: themes must switch
# the toolbar too, not just the panel). Reads the SAME THEMES dict the home panel
# uses, so the toolbar always matches the active Nexus theme.
def _toolbar_qss_for_theme(theme_name=None):
    """Build the toolbar QSS from the active Velocity Nexus theme palette so the
    toolbar bar matches the panel and switches with it. Falls back to the previous
    dark palette if the theme pack can't be imported."""
    _fallback = {
        "tb_bg": "#05070C", "tb_border": "#1B2940", "btn_bg": "#0D1320",
        "btn_text": "#C9DDF2", "btn_hover": "#131D2E", "checked_bg": "#1AE5FF",
        "checked_text": "#04070D", "disabled_text": "#53678A",
    }
    try:
        try:
            from .velocity_home_panel import THEMES as _TH
        except Exception:
            from velocity_home_panel import THEMES as _TH
        if theme_name is None:
            from qgis.core import QgsSettings
            theme_name = QgsSettings().value("VelocityFibre/panel_theme") or "velocity"
        c = _TH.get(theme_name) or _TH.get("velocity") or {}
        pal = {
            "tb_bg":         c.get("bg", _fallback["tb_bg"]),
            "tb_border":     c.get("step_border", _fallback["tb_border"]),
            "btn_bg":        c.get("tool_bg", c.get("step_bg", _fallback["btn_bg"])),
            "btn_text":      c.get("tool_text", c.get("title", _fallback["btn_text"])),
            "btn_hover":     c.get("tool_hover", c.get("step_hover", _fallback["btn_hover"])),
            "checked_bg":    c.get("step_hi", _fallback["checked_bg"]),
            "checked_text":  c.get("badge_text", _fallback["checked_text"]),
            "disabled_text": c.get("sub", c.get("chev", _fallback["disabled_text"])),
        }
    except Exception:
        pal = _fallback
    return _TOOLBAR_QSS_TEMPLATE.format(**pal)


# ══════════════════════════════════════════════════════════════════════════════
# Plugin
# ══════════════════════════════════════════════════════════════════════════════

class FiberNetworkPlugin:
    """QGIS Plugin Implementation for Fiber Network Automation"""

    def __init__(self, iface):
        self.iface = iface
        self.provider = None
        self._toolbar = None
        self._dock_chrome_watcher = None
        self._ui_heal_timers = []
        # Pre-v2.5.322 hot reloads leaked one main-window event filter per
        # restart. Remove them before this instance creates any dock.
        try:
            from .nexus_dock import uninstall_dock_chrome_watcher
            uninstall_dock_chrome_watcher(self.iface.mainWindow())
        except Exception:
            pass
        # Tools mark themselves busy here (via self._busy(...)) so a plugin update
        # DEFERS instead of interrupting long work. A set of active-operation labels.
        self._busy_ops = set()
        self._pole_editor_panel = None
        self._pole_editor_dock = None     # _PanelDock hosting the pole editor
        self._home_panel = None
        self._np_dock = None
        self._enc_editor_panel  = None
        self._enc_editor_dock = None      # _PanelDock hosting the enclosure editor
        self._route_viewer_panel = None
        self._route_viewer_dock = None    # _PanelDock hosting the route viewer
        self._actions = {}         # id -> QAction for state management
        self._group_btns = {}      # group_id -> QToolButton (menu groups only)
        self._group_acts = {}      # group_id -> QWidgetAction from tb.addWidget(btn)
        self._brand_label = None   # VF badge QLabel
        self._brand_status = None  # "Bridge Online/Offline" status QLabel
        self._bridge_timer = None  # QTimer polling bridge_port.txt
        self._bridge_fail_streak = 0     # consecutive failed polls (debounce)
        self._bridge_last_shown_alive = None  # last rendered state
        self._automation_sep = None      # QAction separator before client dropdown
        self._automation_widget = None   # QToolButton (Vuma/FT steps dropdown)
        self._automation_action = None   # toolbar action wrapping the button
        self._absorbed_ft_widgets = []        # QToolButtons absorbed from fibretime_tools toolbar
        self._absorbed_ft_widget_acts = []   # QWidgetActions returned by addWidget() — use for visibility
        self._absorbed_ft_actions = []       # plain QActions absorbed from fibretime_tools toolbar

    def _busy(self, label):
        """Context manager a tool wraps around a long operation so a plugin update
        DEFERS while it runs and applies the moment it finishes — never interrupting
        the work. Always clears on exit, even if the operation raises:

            with self._busy("Exporting BOQ"):
                ...long work...
        """
        from contextlib import contextmanager

        @contextmanager
        def _cm():
            key = str(label)
            self._busy_ops.add(key)
            try:
                yield
            finally:
                self._busy_ops.discard(key)
        return _cm()

    # ── Setup ────────────────────────────────────────────────────────────────
    def initProcessing(self):
        reg = QgsApplication.processingRegistry()
        self.provider = FiberNetworkProvider()
        if not reg.addProvider(self.provider):
            # addProvider returned False → zombie "fibernetwork" key in the C++ map
            # (typically from a double-start or Plugin Reloader reload).
            # QGIS already deleted self.provider's C++ object; create a fresh probe
            # so removeProvider can look up and evict the zombie by ID.
            try:
                _probe = FiberNetworkProvider()
                reg.removeProvider(_probe)  # removes zombie by ID, NOT _probe itself
            except Exception:
                pass
            self.provider = FiberNetworkProvider()
            reg.addProvider(self.provider)

    def _erven_studio_dock_path(self):
        import os
        plugin_dir = os.path.dirname(__file__)
        cands = [
            os.path.join(plugin_dir, 'erven_studio', 'qgis_dock.py'),                   # bundled inside plugin
            os.path.join(os.path.dirname(plugin_dir), 'erven_studio', 'qgis_dock.py'),  # sibling
            r'C:/Users/jjsch/OneDrive - blitzfibre.com/Documents/Workspace/QGIS/erven_studio/qgis_dock.py',
        ]
        return next((p for p in cands if os.path.exists(p)), None)

    def _erven_studio_module(self):
        path = self._erven_studio_dock_path()
        if not path:
            self.iface.messageBar().pushWarning('Erven Studio', 'qgis_dock.py not found')
            return None
        import importlib.util
        spec = importlib.util.spec_from_file_location('erven_qgis_dock', path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod

    def _open_erven_studio(self):
        """Load erven_studio/qgis_dock.py and show the Erven Studio dock."""
        mod = self._erven_studio_module()
        if mod:
            mod.ErvenStudio.install()

    def _run_erven_now(self):
        """One-click: detect buildings → cadastral erven → demand points on the live AOI."""
        mod = self._erven_studio_module()
        if mod:
            mod.ErvenStudio.run_now()

    def _detect_buildings_now(self):
        """One-click building detection only (Google Open Buildings, no server)."""
        mod = self._erven_studio_module()
        if mod:
            mod.ErvenStudio.detect_now()

    def _install_ai_components(self):
        """One-time install of torch/sam2/geopandas etc. on plain QGIS so
        Detect Buildings works on a teammate's machine with zero setup."""
        try:
            from .fibre_automation.sam_detect.installer import get_installer
        except ImportError:
            from fibre_automation.sam_detect.installer import get_installer
        get_installer(self.iface).run()

    def _detect_buildings_sam(self):
        """Detect Buildings with local AI (SAM2) — works for ANY project AOI.

        Footprint boxes (GOB/Overture or an existing layer) -> SAM2 roof
        masks -> one house per erf (when a cadastre exists) -> regularized,
        shape-classified polygons. 100% local, no API keys/subscriptions.
        Degrades to the raw open-data footprints when the AI deps are absent.
        """
        runner = getattr(self, '_sam_detect_runner', None)
        if runner is None:
            try:
                from .fibre_automation.sam_detect.runner import SamDetectRunner
            except ImportError:
                from fibre_automation.sam_detect.runner import SamDetectRunner
            runner = SamDetectRunner(self.iface,
                                     fallback=self._detect_buildings_now)
            self._sam_detect_runner = runner
        runner.run()

    def _install_erven_studio_button(self):
        """Add an 'Erven Studio' toolbar button that opens the detect+tune dock."""
        from qgis.PyQt.QtGui import QAction
        if self._erven_studio_dock_path() is None:
            print('[FiberNet] Erven Studio: qgis_dock.py not found — button skipped')
            return
        act = QAction('Erven Studio', self.iface.mainWindow())
        act.setToolTip('Erven Studio — detect buildings + tune cadastral erven (sliders + Run)')
        act.triggered.connect(self._open_erven_studio)
        self._toolbar.addAction(act)
        self._actions['erven_studio'] = act
        self._erven_studio_action = act
        print('[FiberNet] Erven Studio button installed ✓')

    def _open_erven_detection(self):
        """Open the Erven Detection dock (SAM 2 + Grounding DINO via local MCP server).
        Lazy-loads erven_detection/ — works fully with the MCP server offline (the panel
        shows an offline notice and disables Run)."""
        from qgis.PyQt.QtCore import Qt
        panel = getattr(self, '_erven_detection_panel', None)
        if panel is not None:
            try:
                panel.show(); panel.raise_()
                return
            except RuntimeError:
                self._erven_detection_panel = None  # C++ object deleted — recreate
        try:
            from .erven_detection.erven_panel import ErvenPanel
        except ImportError:
            from erven_detection.erven_panel import ErvenPanel
        panel = ErvenPanel(self.iface, self.iface.mainWindow())
        _du = self._dock_util()
        if _du is not None:
            _du.dock_fully(self.iface, panel, width=440)
        else:
            self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, panel)
        panel.show(); panel.raise_()
        self._erven_detection_panel = panel

    def _run_splice_plan(self):
        """Step 5 — generate the splice plan (Excel workbook + A4 field cards) and open it.

        Runs the bundled fibre_automation/splice generators. They read the splice data
        JSON shipped alongside them and write to splice/output/. Falls back gracefully
        with a clear message if the Python deps (openpyxl/reportlab/networkx) are missing.
        """
        import os, subprocess
        from qgis.PyQt.QtWidgets import QApplication
        plugin_dir = os.path.dirname(__file__)
        cands = [
            os.path.join(plugin_dir, 'fibre_automation', 'splice'),                   # ZIP install (team)
            os.path.join(os.path.dirname(plugin_dir), 'fibre_automation', 'splice'),  # plugins-dir sibling
            os.path.expanduser('~/OneDrive - blitzfibre.com/Documents/Workspace/QGIS/'
                               'fibre_automation/splice'),                            # dev workspace fallback
        ]
        splice = next((c for c in cands if os.path.exists(os.path.join(c, 'build_splice_v3.py'))), cands[0])
        gen = os.path.join(splice, 'build_splice_v3.py')
        cards = os.path.join(splice, 'build_field_cards.py')
        flow = os.path.join(splice, 'build_flow_diagrams.py')
        if not os.path.exists(gen):
            self.iface.messageBar().pushWarning('Splice Plan', 'Splice generator not found.')
            return
        # Prefer a Python that has the deps (dev venv), else QGIS's bundled
        # python.exe — NEVER sys.executable here: inside QGIS on Windows that
        # is qgis-bin.exe and would open new QGIS windows.
        try:
            from .fibre_automation.shared.vf_paths import python_exe
        except ImportError:
            from fibre_automation.shared.vf_paths import python_exe
        py = python_exe()
        # Outputs go to the project folder (portable), not a hardcoded dev path.
        env = dict(os.environ)
        try:
            from .fibre_automation.shared.vf_paths import project_output_dir
            outdir = project_output_dir()
        except Exception:
            outdir = os.path.join(splice, 'output')
        os.makedirs(outdir, exist_ok=True)
        env['VF_SPLICE_OUT'] = outdir
        self.iface.messageBar().pushInfo('Splice Plan', 'Generating Excel + field cards + flow diagrams…')
        QApplication.processEvents()
        try:
            r1 = subprocess.run([py, gen], capture_output=True, text=True, timeout=300, cwd=splice, env=env)
            # Only run the downstream steps when the primary generator succeeded —
            # if r1 fails it produces no output files, so r2/r3 would only waste
            # ~600s of subprocess time failing too.
            if r1.returncode == 0:
                r2 = subprocess.run([py, cards], capture_output=True, text=True, timeout=300, cwd=splice, env=env)
                r3 = (subprocess.run([py, flow], capture_output=True, text=True, timeout=300, cwd=splice, env=env)
                      if os.path.exists(flow) else None)
            else:
                r2 = None
                r3 = None
        except Exception as e:
            self.iface.messageBar().pushWarning('Splice Plan', str(e)[:200])
            return
        if r1.returncode == 0:
            extra = '' if r2.returncode == 0 else ' (field cards step needs reportlab/qrcode)'
            if r3 is not None and r3.returncode != 0:
                extra += ' (flow diagrams step needs matplotlib)'
            self.iface.messageBar().pushSuccess('Splice Plan', f'Done → {outdir}{extra}')
            try:
                os.startfile(outdir)  # noqa: open the output folder for the user
            except Exception:
                pass
        else:
            msg = (r1.stderr or r1.stdout or 'failed').strip()[-220:]
            self.iface.messageBar().pushWarning(
                'Splice Plan', f'Could not generate: {msg}  (needs openpyxl/networkx)')

    def _open_network_planner(self):
        """Open the bundled Velocity Network Planner (FTTHPlanTool) dock."""
        from qgis.PyQt.QtCore import Qt
        try:
            try:
                from .network_planner.dock_widget import FTTHPlanToolDockWidget
            except Exception:
                from network_planner.dock_widget import FTTHPlanToolDockWidget
            try:
                if self._np_dock is not None:
                    self._np_dock.show(); self._np_dock.raise_(); return
            except RuntimeError:
                self._np_dock = None  # underlying C++ dock was deleted
            self._np_dock = FTTHPlanToolDockWidget(self.iface)
            _du = self._dock_util()
            if _du is not None:
                _du.dock_fully(self.iface, self._np_dock, width=460)
            else:
                self.iface.addDockWidget(
                    Qt.DockWidgetArea.RightDockWidgetArea, self._np_dock)
            # Tab it together with the Velocity Nexus Home panel so they share the
            # same area as tabs — opening the planner doesn't force Home to close.
            try:
                if self._home_panel is not None:
                    self.iface.mainWindow().tabifyDockWidget(self._home_panel, self._np_dock)
            except (RuntimeError, AttributeError):
                pass
            self._np_dock.show(); self._np_dock.raise_()
        except Exception as e:
            self.iface.messageBar().pushWarning(
                'Network Planner', f'Could not open: {str(e)[:200]}')

    def _open_labeling_wizard(self):
        """Open Label My Network — the recipe-dock edition (fibre_automation),
        the single source of truth: walk-order numbering, Find/Replace, per-row
        review, collision checks and the BETA relabel guard all live here."""
        try:
            try:
                from .fibre_automation.labeling_wizard import (
                    open_labeling_wizard)
            except Exception:
                from fibre_automation.labeling_wizard import (
                    open_labeling_wizard)
            open_labeling_wizard(self.iface)
        except Exception as e:
            self.iface.messageBar().pushWarning(
                'Label My Network', f'Could not open: {str(e)[:200]}')

    def _apply_toolbar_theme(self, theme_name=None):
        """Re-colour the plugin toolbar to match the active Velocity Nexus theme.
        Called on startup and whenever the user switches theme in the home panel."""
        try:
            if getattr(self, '_toolbar', None) is not None:
                self._toolbar.setStyleSheet(_toolbar_qss_for_theme(theme_name or None))
        except Exception:
            pass

    def _install_home_panel(self):
        """Branded Velocity Nexus home dock — fronts the main tools in a friendly panel."""
        import os
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtGui import QAction
        try:
            from .velocity_home_panel import VelocityHomePanel
        except Exception:
            from velocity_home_panel import VelocityHomePanel

        def act(_id):
            a = self._actions.get(_id)
            if a:
                return lambda: a.trigger()
            return lambda: self.iface.messageBar().pushInfo(
                'Velocity Nexus', f'"{_id}" is not available in this mode.')

        def _planner_version():
            import re
            try:
                mp = os.path.join(os.path.dirname(__file__),
                                  'network_planner', 'metadata.txt')
                with open(mp, encoding='utf-8') as f:
                    m = re.search(r'^version=(\S+)', f.read(), flags=re.M)
                return f'V{m.group(1)}' if m else ''
            except Exception:
                return ''

        _np_ver = _planner_version()
        steps = [
            ('Detect Buildings', 'Local AI (SAM2) — shape-classified, any AOI', self._detect_buildings_sam),
            ('Generate Erven',   'Cadastral erven + demand (no server)', self._run_erven_now),
            ('Network Planner',  (f'PON design pipeline — {_np_ver}' if _np_ver
                                  else 'PON design pipeline'),
             self._open_network_planner),
            ('Label My Network', 'Auto-label every layer by client recipe — Fibertime/Vuma/HeroTel (BETA)',
             self._open_labeling_wizard),
            ('Check & Audit',    'HLD compliance + span check',       act('audit_hld')),
            ('Splice Plan',      'Excel workbook + A4 field cards',   self._run_splice_plan),
            ('HLD Atlas PDF',    'Editable PDF book — overview + one page per unit (BETA)',
             self._generate_hld_pdf),
        ]
        # Automations & tools — each wired to a REAL, proven plugin tool, with a
        # hover description. (label, callback, tooltip). The panel's _safe()
        # wrapper catches any error so a click can never break the UI.
        # Manual Planning toolkit (was a ⚙ Menu submenu) → a collapsible panel group.
        _mp_tools_panel = []
        _mpt_p = None
        try:
            try:
                from .manual_planning import get_tools as _mp_get_p, MENU_SPEC as _MP_SPEC
            except ImportError:
                from manual_planning import get_tools as _mp_get_p, MENU_SPEC as _MP_SPEC
            _mpt_p = _mp_get_p(self.iface)
            for _e in _MP_SPEC:
                if not _e:
                    continue
                _lbl, _attr, _tip = _e
                if hasattr(_mpt_p, _attr):
                    # short button label (drop the parenthetical detail → tooltip),
                    # so the 2-col grid stays even (ticket #93)
                    _short = _lbl.split(" (")[0].strip()
                    _mp_tools_panel.append((_short, getattr(_mpt_p, _attr),
                                            _tip or _lbl))
            if hasattr(_mpt_p, '_toggle_pon_recorder'):
                _mp_tools_panel.append(('🔴 Record PON Order', _mpt_p._toggle_pon_recorder,
                                        'Click PON polygons in feeder order → pon_feeder_order.txt'))
        except Exception as _mpe:
            print(f'[FiberNet] Manual Planning panel tools failed: {_mpe}')

        # Grouped into collapsible categories so the panel reads as clean
        # sections, not a wall of 20+ buttons. (category, [(label, cb, tip), ...])
        tools = [
            ("QA & AUDIT", [
                ('🏅 Scorecard', self._run_acceptance_scorecard,
                 'Score the finished HLD against the spec → client-signable '
                 'ACCEPTED / CONDITIONAL / REJECTED certificate PDF.'),
                ('🔆 Power Budget', self._run_power_budget_check,
                 'Optical power-budget check (ITU-T G.984) — flags ONTs with tight '
                 'or failing optical margin before you build.'),
                ('📊 Capacity', self._run_capacity_report,
                 'Per-PON fill (80–102, max 128) + per-zone rollup; flags over/under.'),
                ('🔎 Anomalies', self._run_anomaly_scan,
                 'Orphaned poles + dangling cable ends → an "Anomalies" layer.'),
                ('🩺 Topology QA', self._run_topology_qa,
                 'Full integrity sweep: null geoms, dup DR/PON, zone-math, dangles, '
                 'over-length spans, ONTs outside AOI.'),
                ('📋 QA Report (HTML)', self._export_qa_report,
                 'Shareable PASS/REVIEW/FAIL HTML integrity report.'),
                ('🚦 FT Pre-Flight', self._run_preflight_check,
                 'Before FT6/FT7: verify pon_feeder_order.txt + roads.json + layers.'),
                ('📏 Span Inspector', self._open_span_inspector,
                 'Dial a max span (0–100 m) and every longer pole-to-pole run '
                 'lights up on the canvas — and clears itself the moment you fix '
                 'it. Read-only; never edits your data.'),
                ('🛡 Integrity Check', self._run_integrity_check,
                 'Fast structural self-check on the live project (<1s): off-map '
                 'blowout, null geoms, mixed CRS, empty key layers, span limits, '
                 'drop≈ONT → OK / REVIEW / FAIL. Run after any big edit or fix.'),
            ]),
            ("DELIVERABLES", [
                ('🧾 Cost / BOQ', self._run_boq_export,
                 'Reliable BoQ — cable lengths in real METRES (UTM), grouped counts, '
                 'slack/spools, editable rates, audit sheet → priced Excel.'),
                # '📘 HLD PDF' button removed — superseded by the step-7 "HLD Atlas PDF"
                # (the editable atlas book). Only one HLD PDF path now.
                ('📄 Design Report', self._export_design_report,
                 'PDF map-book of the design.'),
                ('📋 Pole Schedule', self._run_pole_schedule,
                 'GPS pole schedule CSV (label, lat/lon, thickness, type).'),
                ('🌍 Export KMZ', self._export_kmz,
                 'Pick layers → KMZ for Google Earth / field phones (with attributes).'),
                ('📐 Export DXF', self._export_dxf,
                 'Pick layers → DXF CAD (metres) for contractors.'),
                ('🗄 Export GeoPackage', self._export_styled_gpkg,
                 'Pick layers → one pre-styled .gpkg (cleanest handoff).'),
                ('🌐 Export KML', self._export_kml,
                 'GeoPackage or project → client-spec KML (correct symbology + '
                 'every attribute) for Google Earth.'),
                ('📦 Export GeoParquet/OFDS', self._export_cloud_formats,
                 'Cloud / open-standard export (GeoParquet + OFDS).'),
            ]),
            ("DETECTION & EDITORS", [
                ('🏠 Detect Buildings', self._detect_buildings_sam,
                 'Local-AI (SAM2) building detection for the current AOI.'),
                ('🛰 Fetch Erven (CSG)', self._fetch_csg_erven,
                 'Download the REAL surveyed erven from the SA CSG cadastre.'),
                ('📍 Poles', act('pole_editor'),
                 'Road-Crossing Pole Editor — mark/unmark with live highlighting.'),
                ('🔌 Enclosures', act('enc_editor'), 'Open the Enclosures editor.'),
            ]),
            ("SYSTEM", [
                ('💾 Back up Project', self._backup_project,
                 'Zip every layer + the project file into a timestamped archive.'),
                ('💬 Hover Tips', self._toggle_feature_map_tips,
                 'Toggle map hover tips (label/length/status/PON) on any feature.'),
                ('🛡 Guardian Incidents', self._show_guardian_incidents,
                 'Mass geometry losses the Guardian caught + auto-restored (local).'),
                ('🩺 System Health', self._show_health_panel,
                 'Green/Amber/Red status of the safety nets + offline outbox.'),
            ]),
        ]
        # Tools submenu → panel: Route Viewer + OES + the Manual Planning group.
        try:
            tools[2][1].append(('🛣 Route Viewer', self._open_route_viewer,
                                'Open the cable Route Viewer.'))
            tools[2][1].append(('🔍 Review Buildings', self._open_building_review,
                                'Review + correct detected buildings; every '
                                'decision trains the AI on your own corrections.'))
            if _mpt_p is not None and hasattr(_mpt_p, 'run_oes_export'):
                tools[1][1].append(('💾 Export OES CSV', _mpt_p.run_oes_export,
                                    'Export the OES CSV for the project.'))
        except Exception:
            pass
        if _mp_tools_panel:
            tools.insert(3, ("MANUAL PLANNING", _mp_tools_panel))
        # '⬇ Update' is a DEV-only git pull; teammates get the Workflow Guide.
        if self._is_dev_mode():
            tools[0][1].append(('🔬 Project Audit', self._open_project_audit,
                                'DEV only — deep cell-by-cell + geometry + GPON-standard '
                                'audit of the whole project → HTML report + a zoom-to-issue panel.'))
            tools[-1][1].append(('⬇ Update', act('update_git'),
                                 'DEV only — git-pull the latest plugin code.'))
        else:
            tools[-1][1].append(('🧭 Next steps', self._open_workflow_dock,
                                 'Step-by-step workflow guide — what to run next.'))
        logo = os.path.join(os.path.dirname(__file__), 'logo.png')
        self._home_panel = VelocityHomePanel(self.iface, steps, tools, logo_path=logo)
        # Keep the toolbar colours in sync with the Nexus theme the user picks.
        try:
            self._home_panel.themeChanged.connect(self._apply_toolbar_theme)
        except Exception:
            pass
        _du = self._dock_util()
        if _du is not None:
            _du.dock_fully(self.iface, self._home_panel, width=440)
        else:
            self.iface.addDockWidget(
                Qt.DockWidgetArea.RightDockWidgetArea, self._home_panel)
        # Chrome EVERY Velocity dock (bright ✕ / float title) — now AND whenever one
        # opens later (Label My Network, Network Planner, Team Monitor, Erven, Bridge…).
        # A persistent watcher so no dock class is ever missed again. Fail-open.
        try:
            from .nexus_dock import install_dock_chrome_watcher
            self._dock_chrome_watcher = install_dock_chrome_watcher(self.iface.mainWindow())
        except Exception:
            pass
        # auto-notify (panel banner + one-click update) when we publish.
        # The panel can be rebuilt (C++ object deleted) — stop any previous
        # checker first or its 30-min timer leaks and double-notifies.
        try:
            if getattr(self, '_update_checker', None) is not None:
                self._update_checker.stop()
                self._update_checker = None
            try:
                from .update_check import UpdateChecker
            except ImportError:
                from update_check import UpdateChecker
            self._update_checker = UpdateChecker(
                self.iface, lambda: self._home_panel,
                user_getter=lambda: (lambda pr: (getattr(pr, 'display_name', None)
                                                 or getattr(pr, 'username', None)) if pr else None)(
                    getattr(getattr(self, '_nexus', None), 'profile', None)))
            # Wire the panel's 🔄 Check-for-updates button to a manual check.
            try:
                self._home_panel.set_check_updates_callback(
                    self._update_checker.check_now_manual)
            except Exception:
                pass
        except Exception as e:
            print(f'[FiberNet] update checker not started: {e}')
        # Wire the inline activation card (shown only while locked)
        try:
            try:
                from . import activation as _act
            except ImportError:
                import activation as _act
            self._home_panel.set_locked(not _act.is_activated(), self._panel_activate)
        except Exception as e:
            print(f'[FiberNet] home lock wiring failed: {e}')
        # Wire the ⚙ gear button → pops the full Velocity Nexus menu
        try:
            self._home_panel.set_settings_callback(self._open_velo_menu)
        except Exception as e:
            print(f'[FiberNet] settings button wiring failed: {e}')
        # Wire the 🎫 red ticket button → log a bug / feature request to the office
        try:
            self._home_panel.set_ticket_callback(self._open_ticket_dialog)
        except Exception as e:
            print(f'[FiberNet] ticket button wiring failed: {e}')
        # Wire the 👤 profile chip → personalization card; live re-theming
        try:
            nx = getattr(self, '_nexus', None)
            if nx is not None and nx.signed_in_name():
                self._home_panel.set_profile(
                    nx.signed_in_name(), nx.avatar_color(),
                    nx.open_profile_card)
                # let the profile card re-skin the panel live
                nx.on_theme_changed = self._apply_panel_theme
        except Exception as e:
            print(f'[FiberNet] profile chip wiring failed: {e}')
        # NOTE: we intentionally do NOT prompt for a password at startup. Identity
        # was already proven once at registration (company team code + per-user
        # password). Sign-in / password-reset is available on demand from the
        # profile card (login.open_account_dialog); the anon fallback keeps
        # notifications working for everyone with no friction.
        # Bridge status is a dev-only Claude channel — teammates have no bridge,
        # so hide the line for them (it would otherwise sit at "checking…" or read
        # a stale bridge_port.txt). Only JJ's dev machine shows/polls it.
        if self._is_dev_mode():
            # Start at "checking" and let the 3 s poller supply the truth. This
            # used to read a shared file and assert set_bridge(True, port) —
            # claiming online without ever checking, from a port that may belong
            # to a different QGIS window, and never updating again.
            try:
                from .bridge_state import CONNECTING
                self._home_panel.set_bridge_state(CONNECTING, None)
            except Exception:
                pass
            # Click-to-switch is OFF unless the dev flag is explicitly set, so
            # the label stays inert for everyone else. Absent setting -> False.
            try:
                from . import bridge_switcher as _bsw
                if _bsw.is_enabled():
                    self._home_panel.set_bridge_click_handler(
                        self._open_bridge_switcher)
            except Exception:
                pass
        else:
            try:
                self._home_panel.set_bridge_visible(False)
            except Exception:
                pass
        # "You are here" — reflect real project state on the workflow cards, and
        # keep it live as layers are added/removed by the tools.
        try:
            from qgis.core import QgsProject
            self._refresh_home_steps()
            # disconnect-before-connect: _install_home_panel runs again when the
            # panel is reopened, so guard against duplicate slot connections.
            for sig in (QgsProject.instance().layersAdded,
                        QgsProject.instance().layersRemoved):
                for _slot in (self._refresh_home_steps, self._home_refresh_debounced):
                    try:
                        sig.disconnect(_slot)
                    except (TypeError, RuntimeError):
                        pass
                # Debounced: opening a project fires layersAdded once PER layer (20
                # layers => 20 full context recomputes). A 150 ms single-shot coalesces
                # the burst into ONE refresh. Same end result, far less churn.
                sig.connect(self._home_refresh_debounced)
        except Exception as e:
            print(f'[FiberNet] step-state wiring failed: {e}')
        # Remove any prior toolbar action first — _install_home_panel() re-runs on
        # a dock rebuild (user closes + reopens the panel), which would otherwise
        # stack duplicate 'Velocity Nexus Home' buttons.
        _old_home = getattr(self, '_home_action', None)
        if _old_home is not None:
            try:
                self._toolbar.removeAction(_old_home)
            except Exception:
                pass
        self._home_action = QAction('Velocity Nexus Home', self.iface.mainWindow())
        self._home_action.setToolTip('Open the Velocity Nexus home panel')
        # Use the guarded opener (handles None / deleted-C++ panel + rebuild)
        # rather than touching self._home_panel directly, which crashes if the
        # dock was closed.
        self._home_action.triggered.connect(self._show_home_panel)
        self._toolbar.addAction(self._home_action)
        self._actions['home'] = self._home_action
        # Park the Splice Viewer button right next to Velocity Nexus Home
        rv = self._actions.get('route_viewer')
        if rv is not None:
            try:
                self._toolbar.removeAction(rv)
                self._toolbar.insertAction(self._home_action, rv)
                btn = self._toolbar.widgetForAction(rv)
                if btn is not None:
                    btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
            except Exception:
                pass
        print('[FiberNet] Velocity Nexus home panel installed ✓')

    def _build_menu(self):
        """Build the single 'Velocity Nexus' menu — the JJ-approved Phase 1 unified tree.
        Replaces the old VeloPlan menu. Reuses toolbar QActions where they exist; AI Erven
        is RETIRED (tessellation violates the no-Voronoi erven rule) and deliberately absent."""
        from qgis.PyQt.QtWidgets import QMenu
        from qgis.PyQt.QtGui import QAction
        mw = self.iface.mainWindow()
        if getattr(self, '_velo_menu', None) is not None:
            try:
                mw.menuBar().removeAction(self._velo_menu.menuAction())
            except Exception:
                pass
        # The menu is now opened from the ⚙ button in the Velocity Nexus panel,
        # NOT from the menu bar (JJ: remove the top 'Velocity Nexus' menu). It is a
        # standalone QMenu parented to the main window and popped up by _open_velo_menu.
        self._velo_menu = QMenu('Velocity Nexus', mw)
        self._velo_menu.setToolTipsVisible(True)   # show the authored tooltips

        try:
            try:
                from . import error_reporter as _er
            except ImportError:
                import error_reporter as _er
        except Exception:
            _er = None

        def mk(label, cb, tip=None):
            a = QAction(label, mw)
            # Nexus telemetry: record every menu action (choke point) — one
            # place captures all tools without per-tool edits. Fail-silent.
            nexus = getattr(self, '_nexus', None)
            if nexus is not None:
                cb = nexus.wrap(label, cb)
            # Wrap so a teammate gets a logged report, not a crash.
            a.triggered.connect(_er.guard(self.iface, label, cb) if _er else cb)
            if tip:
                a.setToolTip(tip)
            return a

        # Is our processing provider actually loaded right now? (False in a
        # headless/unactivated context where the provider is withheld.) Computed
        # once so alg() doesn't cry wolf about "unknown id" when the WHOLE
        # provider simply isn't up yet — that's a different situation from a
        # genuinely typo'd id, and warning on it just adds noise.
        from qgis.core import QgsApplication as _QgsApp
        _provider_loaded = any(
            a.id().startswith('fibernetwork:')
            for a in _QgsApp.processingRegistry().algorithms())

        def alg(label, alg_id):
            import processing as _p
            # Guard against the FT9-class bug: a menu entry pointing at an
            # algorithm id that isn't actually registered dies silently on
            # click. Surface it loudly at build time — but only when the provider
            # is loaded, so a withheld-provider context stays quiet.
            from qgis.core import QgsApplication
            if _provider_loaded and QgsApplication.processingRegistry().algorithmById(alg_id) is None:
                print(f'[FiberNet] ⚠ menu "{label}" references unknown algorithm '
                      f'"{alg_id}" — entry will not work until the id is fixed.')
            return mk(label, lambda: _p.execAlgorithmDialog(alg_id, {}))

        dev = self._is_dev_mode()

        def add_ids(menu, ids):
            for _id in ids:
                # dev-only actions never reach a teammate's menu
                if _id in self._actions and (
                        dev or not any(e.get('id') == _id and e.get('client') == 'dev'
                                       for e in TOOLBAR_SPEC)):
                    menu.addAction(self._actions[_id])

        # ── top level ────────────────────────────────────────────────────────
        self._velo_menu.addAction(mk('🏠  Velocity Nexus Panel (home dashboard)', self._show_home_panel))
        self._velo_menu.addAction(mk('🆕  New Project…', self._show_welcome_dialog))
        self._velo_menu.addAction(mk('🧭  Workflow Guide (what to do next)…', self._open_workflow_dock))
        # NOTE: automation buttons live in the Velocity Nexus PANEL groups, never in this
        # menu (menu = options/settings only). "Generate HLD PDF" is a DELIVERABLES panel button.

        # AI Mapping (Detect Buildings, Fetch Erven) is now panel buttons — removed
        # from the menu. Erven Studio + dev experiments live on the toolbar / Dev.

        # ALL automations are now physical panel buttons (collapsible groups):
        #  • Manual Planning toolkit (Place Pole/Dome, Draw cables, Auto PON/Zone,
        #    Connect Drops, Record PON Order, …) → "MANUAL PLANNING" panel group.
        #  • Labelling / FT Pipeline / HeroTel → the panel workflow steps + the
        #    Processing Toolbox.
        #  • QA & Output (Topology QA, exports, Pre-Flight, …) + Tools (Poles,
        #    Enclosures, Route Viewer, Backup) → panel button groups.
        # The ⚙ Menu now carries ONLY settings/options (below). Handlers retained.

        # ── 🧪 Dev / Experimental (dev machine only — never on a teammate menu) ─
        if dev:
            m_dev = self._velo_menu.addMenu('🧪  Dev / Experimental')
            add_ids(m_dev, ['ai_detect', 'velo_detect', 'canvas', 'run_q', 'update_git'])
            m_dev.addAction(mk('🛣  Generate Erven from roads (no cadastre)', self._gen_erven_osm,
                               'For areas with NO CSG coverage: generate regular erven from the '
                               'OSM road network (blocks → ~14×22m stands). Dev/venv only.'))
            m_dev.addAction(mk('▶  Run Erven + Demand (full AOI)', self._run_erven_now))

        # ── ⚙ Settings & Help (footer submenu) ───────────────────────────────
        self._velo_menu.addSeparator()
        m_set = self._velo_menu.addMenu('⚙  Settings & Help')
        self._report_action = mk('🐞  Report a Problem…', self._open_problem_report)
        m_set.addAction(self._report_action)
        self._about_action = mk('ℹ️  About & Activation…', self._open_about_activation)
        m_set.addAction(self._about_action)
        m_set.addAction(mk('🔄  Check for updates…', self._check_for_updates))
        m_set.addAction(mk('🗺  Tool Map (what does what)', self._open_tool_map))
        m_set.addAction(mk('⌨  Command Palette  (Ctrl+Shift+P)',
                           self._open_command_palette))
        # Render-only smoothing for big layers (faster pan/zoom; data untouched).
        # QAction is already imported from qgis.PyQt.QtGui at the top of _build_menu
        # (Qt6 moved QAction out of QtWidgets — re-importing from QtWidgets would fail).
        try:
            from fibre_automation import ui_smooth as _uism
            self._smooth_action = QAction('⚡  Fast render (large projects)',
                                          self.iface.mainWindow())
            self._smooth_action.setCheckable(True)
            self._smooth_action.setChecked(_uism.enabled())

            def _toggle_smooth(on):
                _uism.set_enabled(on)
                if on:
                    _uism.apply()                       # heavy-layer geometry simplify
                    _uism.apply_canvas(self.iface)      # parallel render + caching
                    self.iface.mapCanvas().refresh()
                    msg = "Fast render ON — heavy layers simplified + parallel/cached rendering"
                else:
                    _uism.restore_canvas(self.iface)    # put canvas prefs back
                    self.iface.mapCanvas().refresh()
                    msg = "Fast render OFF — canvas restored (layer simplify clears on next project load)"
                try:
                    self.iface.messageBar().pushMessage(
                        "Velocity Nexus", msg,
                        level=Qgis.MessageLevel.Info, duration=5)
                except Exception:
                    pass
            self._smooth_action.toggled.connect(_toggle_smooth)
            m_set.addAction(self._smooth_action)
        except Exception:
            pass
        # Theme switcher — moved here from the header (the red Ticket button took
        # its place). Default look is the premium blue.
        m_theme = m_set.addMenu('🎨  Theme')
        try:
            from .velocity_home_panel import THEMES as _TH
        except Exception:
            _TH = {}
        for _k, _v in _TH.items():
            m_theme.addAction(mk(_v.get('name', _k),
                              lambda *a, k=_k: self._home_panel
                              and self._home_panel.set_theme(k)))
        m_set.addSeparator()
        m_set.addAction(mk('🧩  Install AI components (Detect Buildings)…',
                           self._install_ai_components))
        # Team Monitor — only shown to the planning-office admin (JJ).
        try:
            if getattr(self, '_nexus', None) is not None and self._nexus.is_admin():
                m_set.addAction(mk('🛰  Team Monitor (who is using Nexus)…',
                                   self._nexus.open_team_monitor))
        except Exception:
            pass
        m_set.addAction(mk('🩺  Run health check', self._run_health_check))
        m_set.addAction(mk('📂  Open log / output folder', self._open_data_folder))
        m_set.addAction(mk('📋  Copy diagnostics', self._copy_diagnostics))
        m_set.addAction(mk('📖  Team guide', self._open_team_guide))
        self._apply_activation_gate()
        print('[FiberNet] Velocity Nexus menu built ✓')

    # ── ⚙ Settings menu popup (opened from the panel gear, not the menu bar) ──
    def _open_ticket_dialog(self, anchor=None):
        """Open the 🎫 Log-a-ticket form. Submitting sends the bug/feature request
        to the planning office via the Nexus backend (offline-safe spool)."""
        try:
            try:
                from .ticket_dialog import TicketDialog
            except ImportError:
                from ticket_dialog import TicketDialog
            from qgis.PyQt.QtCore import Qt
            dlg = TicketDialog(self.iface, self._submit_ticket)
            # destroy on close so it doesn't linger as a hidden top-level window
            # (these were piling up — visible in the taskbar hover-preview).
            dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
            dlg.exec()
        except Exception as e:
            self.iface.messageBar().pushWarning(
                'Velocity Nexus', f'Ticket form failed: {str(e)[:160]}')

    def _submit_ticket(self, payload):
        """Attach who/version/project and send the ticket. Returns True if it was
        queued/sent (insert spools offline), False if there's no backend."""
        try:
            from qgis.core import QgsProject
            nx = getattr(self, '_nexus', None)
            prof = getattr(nx, 'profile', None) if nx else None
            payload = dict(payload)
            payload.update({
                'username': getattr(prof, 'username', None),
                'display_name': getattr(prof, 'display_name', None),
                'plugin_version': getattr(nx, 'plugin_version', None),
                'qgis_version': getattr(nx, 'qgis_version', None),
                'project_name': QgsProject.instance().baseName() or None,
            })
            backend = getattr(nx, 'backend', None) if nx else None
            if backend is None:
                return False
            # Cap how many screenshots ride as their OWN uploaded URL (each is a
            # sync upload); ALL shots are still embedded in the PDF below, so any
            # beyond the cap are NOT lost, they just don't get a standalone URL.
            shots = payload.pop('_shots', None) or []
            MAX_URL_SHOTS = 6
            to_upload = shots[:MAX_URL_SHOTS]
            # Render the PDF on the MAIN thread — Qt's QTextDocument/QPdfWriter are
            # NOT thread-safe. PDF-FIRST (hard rule): every ticket reaches Telegram
            # as a clean full-ticket document (also dodges Telegram's 4096-char
            # message limit on long tracebacks). Human-readable filename so it drags
            # out of Telegram named after the ticket, not a raw uuid.
            tag = 'BUG' if payload.get('kind') == 'bug' else 'FEATURE'
            fname = f"{tag}-{payload.get('title') or 'ticket'}"
            pdf = self._render_ticket_pdf(payload, shots)
            # Run the SLOW urllib uploads (screenshots + PDF) OFF the main thread so
            # QGIS never freezes during submit — these were up to 8 synchronous
            # uploads x 20s that blocked the UI. Delivery logic is unchanged; only
            # WHERE the network calls run moved. See _run_ticket_uploads_off_thread.
            up = self._run_ticket_uploads_off_thread(backend, to_upload, pdf, fname)
            urls = up.get('shot_urls', [])
            if urls:
                payload['screenshots'] = urls
            pdf_ok = bool(up.get('doc_url'))
            if pdf_ok:
                payload['body_doc_url'] = up['doc_url']
            backend.insert('tickets', payload)   # main thread (QgsNetworkAccessManager)
            # shots_total = how many we ATTEMPTED to upload as URLs (capped), not
            # the raw attach count — so the dialog warns only on a REAL upload
            # failure (uploaded < attempted), never just because extras were capped
            # (those still ship inside the PDF).
            return {'sent': True, 'shots_total': len(to_upload),
                    'shots_uploaded': len(urls), 'pdf_ok': pdf_ok}
        except Exception:
            return False

    def _boq_router(self):
        """Import the boq client router (bundled-tree or root path)."""
        try:
            from .fibre_automation.boq import router
        except ImportError:
            from fibre_automation.boq import router
        return router

    def _pick_boq_client(self, router):
        """Small Qt6-safe dialog: which client is this bill for? Returns key or None.

        Default selection comes from router.default_client() (layer-name fingerprint).
        WA_DeleteOnClose + value captured on OK BEFORE the widget is destroyed.
        """
        from qgis.PyQt.QtWidgets import (QDialog, QComboBox, QLabel, QVBoxLayout,
                                         QDialogButtonBox)
        from qgis.PyQt.QtCore import Qt
        default_key = router.default_client()
        holder = {"key": None}
        dlg = QDialog(self.iface.mainWindow())
        dlg.setWindowTitle("Bill of Quantities — choose client")
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        lay = QVBoxLayout(dlg)
        lay.addWidget(QLabel("Which client is this bill for?"))
        det = QLabel(f"✓ Auto-detected from this project: "
                     f"<b>{router.client_label(default_key)}</b>")
        det.setStyleSheet("color:#2563eb;font-size:11px;")
        lay.addWidget(det)
        combo = QComboBox(dlg)
        for key, label, _caption, _suffix in router.CLIENTS:
            combo.addItem(label, key)
        idx = combo.findData(default_key)
        if idx >= 0:
            combo.setCurrentIndex(idx)
        lay.addWidget(combo)
        caption = QLabel(router.client_caption(default_key))
        caption.setWordWrap(True)
        caption.setStyleSheet("color:#6b7280;font-size:11px;")
        lay.addWidget(caption)
        combo.currentIndexChanged.connect(
            lambda _i: caption.setText(router.client_caption(combo.currentData())))
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                              | QDialogButtonBox.StandardButton.Cancel, parent=dlg)
        lay.addWidget(bb)
        bb.rejected.connect(dlg.reject)

        def _ok():
            holder["key"] = combo.currentData()   # capture BEFORE the widget is gone
            dlg.accept()
        bb.accepted.connect(_ok)
        try:
            from .nexus_dock import chrome_dialog
            chrome_dialog(dlg)
        except Exception:
            pass
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return None
        return holder["key"]

    def _run_boq_export(self):
        """Generate the BoQ Excel for the chosen client from the live HLD layers."""
        try:
            from qgis.PyQt.QtWidgets import QFileDialog
            from qgis.core import QgsProject
            router = self._boq_router()
            client = self._pick_boq_client(router)
            if not client:
                return
            base = QgsProject.instance().baseName() or "BoQ"
            default = base + router.filename_suffix(client)
            path, _ = QFileDialog.getSaveFileName(
                self.iface.mainWindow(),
                f"Save Bill of Quantities ({router.client_label(client)})", default,
                "Excel (*.xlsx)")
            if not path:
                return
            try:
                res = router.run_client_boq(client, out_path=path)
                d = res.get("diag", {})
                verdict = res.get("verdict", "OK")
                fails = [m for s, m in res.get("findings", []) if s == "FAIL"]
                # Surface the audit verdict so the buyer trusts (or reviews) the bill.
                # OK→Success(3) · REVIEW→Warning(1) · FAIL→Critical(2). stub → Warning.
                lvl = {"OK": 3, "REVIEW": 1, "FAIL": 2}.get(verdict, 3)
                if res.get("stub"):
                    lvl = 1
                homes = f"{d.get('ont', 0)} homes · {d.get('poles', 0)} poles" \
                    if (d.get('ont') or d.get('poles')) else ""
                msg = (f"{res.get('format', 'BoQ')} saved — {res['lines']} line items"
                       + (f" ({homes})" if homes else "") + f". AUDIT: {verdict}"
                       + (f" — {len(fails)} blocking issue(s): {fails[0]}" if fails else
                          " — see the Audit sheet (every quantity tied to the design)."))
                self.iface.messageBar().pushMessage("Bill of Quantities", msg, level=lvl, duration=12)
            except Exception as _boq_err:
                # safe fallback to the legacy summary BoQ so the click never dead-ends
                try:
                    from .fibre_automation.boq import run_boq
                except ImportError:
                    from fibre_automation.boq import run_boq
                res = run_boq(path)
                self.iface.messageBar().pushMessage(
                    "Bill of Quantities",
                    f"{router.client_label(client)} format unavailable ({_boq_err}); "
                    f"saved summary BoQ — {len(res.lines)} lines",
                    level=Qgis.MessageLevel.Warning, duration=10)
            try:
                from qgis.PyQt.QtGui import QDesktopServices
                from qgis.PyQt.QtCore import QUrl
                QDesktopServices.openUrl(QUrl.fromLocalFile(path))
            except Exception:
                pass
        except Exception as e:
            try:
                self.iface.messageBar().pushMessage("Bill of Quantities",
                                                    f"BoQ failed: {e}", level=Qgis.MessageLevel.Critical)
            except Exception:
                pass

    def _open_span_inspector(self):
        """Open the Span Inspector dock (read-only pole-to-pole span highlighter)."""
        try:
            from .span_inspector import show_span_inspector
        except ImportError:
            from FiberNetworkAutomation.span_inspector import show_span_inspector
        try:
            show_span_inspector(self.iface)
        except Exception as e:
            try:
                self.iface.messageBar().pushMessage(
                    "Span Inspector", f"could not open: {e}",
                    level=Qgis.MessageLevel.Critical)
            except Exception:
                pass

    def _run_integrity_check(self):
        """Run the bundled safety/invariants self-check on the live project."""
        try:
            try:
                from .fibre_automation.safety import invariants
            except ImportError:
                from fibre_automation.safety import invariants
            r = invariants.run()
            v = r.get("verdict", "?")
            crit = r.get("critical", [])
            warn = r.get("warnings", [])
            lvl = {"OK": 3, "REVIEW": 1, "FAIL": 2}.get(v, 0)
            if crit:
                msg = f"{v} — {len(crit)} CRITICAL: " + " · ".join(crit[:2])
            elif warn:
                msg = f"{v} — {len(warn)} to review (see Log)"
            else:
                msg = f"{v} — structurally sound"
            self.iface.messageBar().pushMessage("🛡 Integrity Check", msg,
                                                level=lvl, duration=14)
            try:
                from qgis.core import QgsMessageLog, Qgis
                body = "\n".join(f"[{c['status']}] {c['check']}: {c['detail']}"
                                 for c in r.get("checks", []))
                QgsMessageLog.logMessage("Integrity Check — verdict " + v + "\n" + body,
                                         "VelocityNexus", level=Qgis.MessageLevel.Info)
            except Exception:
                pass
        except Exception as e:
            try:
                self.iface.messageBar().pushMessage("Integrity Check", f"failed: {e}", level=Qgis.MessageLevel.Critical)
            except Exception:
                pass

    def _show_health_panel(self):
        """Open the local, read-only System Health panel (Green/Amber/Red)."""
        try:
            try:
                from .health_panel import show_health_panel
            except ImportError:
                from health_panel import show_health_panel
            show_health_panel(self.iface)
        except Exception as e:
            try:
                self.iface.messageBar().pushMessage(
                    "System Health", f"Could not open health panel: {e}", level=Qgis.MessageLevel.Warning)
            except Exception:
                pass

    def _show_guardian_incidents(self):
        """Open the local, read-only Geometry Guardian incidents viewer."""
        try:
            try:
                from .guardian_panel import show_guardian_incidents
            except ImportError:
                from guardian_panel import show_guardian_incidents
            show_guardian_incidents(self.iface)
        except Exception as e:
            try:
                self.iface.messageBar().pushMessage(
                    "Geometry Guardian", f"Could not open incidents panel: {e}", level=Qgis.MessageLevel.Warning)
            except Exception:
                pass

    def _auto_ticket_from_incident(self, inc):
        """Geometry Guardian → ticket. Turn a mass-geometry-loss incident into a
        deduplicated 'bug' ticket carrying the full crash report, so the ROOT CAUSE
        lands in the dev queue automatically. Best-effort, rate-limited, never raises.
        """
        try:
            import json
            import hashlib
            import time
            layer = inc.get('layer', '?')
            ctx = inc.get('context') or []
            cause = ctx[-1] if ctx else ''
            stack = inc.get('stack', '') or ''
            # stack signature = the last real code frame (skip the guardian/timer frames)
            sig = ''
            for ln in reversed(stack.splitlines()):
                s = ln.strip()
                if s.startswith('File "') and 'geometry_guardian' not in s:
                    sig = s
                    break
            fp = hashlib.sha1(f"{layer}|{cause}|{sig}".encode('utf-8', 'ignore')).hexdigest()[:12]

            # In-memory atomic claim — checked + set synchronously (no IO between),
            # so no reentrancy / timer re-fire can ever double-file the same fp in
            # this session, even before the file-based store below is written.
            claimed = getattr(self, '_guardian_ticketed_fps', None)
            if claimed is None:
                claimed = self._guardian_ticketed_fps = set()
            if fp in claimed:
                return
            claimed.add(fp)

            # rate-limit: one ticket per fingerprint per 6h on this machine (no spam)
            store = os.path.join(os.path.expanduser('~'), '.velocity_nexus',
                                 'guardian_ticketed.json')
            seen = {}
            try:
                with open(store, encoding='utf-8') as f:
                    seen = json.load(f)
            except Exception:
                seen = {}
            now = time.time()
            if fp in seen and (now - seen[fp]) < 6 * 3600:
                return  # already filed recently

            # Record the fingerprint BEFORE the (slow, off-thread) send so a repeat
            # incident can't slip a duplicate through while the first is still
            # uploading. Better to under-ticket than spam dupes — the data is
            # restored regardless; the ticket is best-effort for the dev queue.
            seen[fp] = now
            seen = {k: v for k, v in seen.items() if now - v < 7 * 86400}
            try:
                os.makedirs(os.path.dirname(store), exist_ok=True)
                with open(store, 'w', encoding='utf-8') as f:
                    json.dump(seen, f)
            except Exception:
                pass

            body = (
                "[Bug]  [Priority: \U0001f6a8 Auto]  [Area: Geometry Guardian]\n\n"
                "\U0001f6e1 The Geometry Guardian auto-RESTORED a massive geometry loss "
                "that the operator did NOT cause. The data is back on the operator's "
                "machine — this ticket exists so the ROOT CAUSE gets fixed.\n\n"
                f"Layer:     {layer}\n"
                f"Lost:      {inc.get('lost')}   Restored: {inc.get('restored')}   "
                f"(before={inc.get('before')} after={inc.get('after')})\n"
                f"In edit:   {inc.get('in_edit')}\n"
                f"Project:   {inc.get('project')}\n"
                f"When:      {inc.get('ts_iso')}\n"
                f"Fingerprint: {fp}\n\n"
                "WHAT THE PLUGIN WAS DOING (oldest → newest):\n"
                + ("\n".join(f"  - {c}" for c in ctx[-15:]) or "  (no breadcrumb)")
                + "\n\nSTACK AT DETECTION:\n" + (stack[-2200:] or "(none)")
            )
            payload = {
                'kind': 'bug',
                'title': (f"\U0001f6e1 Auto: {inc.get('lost')} features vanished from "
                          f"'{layer}' (Geometry Guardian)")[:160],
                'body': body,
            }
            self._submit_ticket(payload)
        except Exception:
            pass

    def _auto_ticket_from_error(self, where, exc, tb_text):
        """A captured plugin CRASH → a deduplicated bug ticket in the dev queue, so
        a massive error reaches the dev (not just the errors table). Flood-guarded +
        rate-limited like the Geometry Guardian. Best-effort, never raises."""
        try:
            import json
            import hashlib
            import time
            import re
            tb = tb_text or ''
            etype = type(exc).__name__ if exc is not None else 'Error'
            emsg = (str(exc) or '')[:200]
            funcs = re.findall(r'line \d+, in (\w+)', tb)[-3:]
            where_func = funcs[-1] if funcs else (where or '?')
            fp = hashlib.sha1(('ERR|' + etype + '|' + '|'.join(funcs)).encode('utf-8', 'ignore')).hexdigest()[:12]

            # in-memory atomic claim (shared store with the guardian)
            claimed = getattr(self, '_guardian_ticketed_fps', None)
            if claimed is None:
                claimed = self._guardian_ticketed_fps = set()
            if fp in claimed:
                return
            claimed.add(fp)

            store = os.path.join(os.path.expanduser('~'), '.velocity_nexus',
                                 'guardian_ticketed.json')
            seen = {}
            try:
                with open(store, encoding='utf-8') as f:
                    seen = json.load(f)
            except Exception:
                seen = {}
            now = time.time()
            if fp in seen and (now - seen[fp]) < 6 * 3600:
                return
            seen[fp] = now
            seen = {k: v for k, v in seen.items() if now - v < 7 * 86400}
            try:
                os.makedirs(os.path.dirname(store), exist_ok=True)
                with open(store, 'w', encoding='utf-8') as f:
                    json.dump(seen, f)
            except Exception:
                pass

            try:
                from .geometry_guardian import recent_activity
            except ImportError:
                from geometry_guardian import recent_activity
            ctx = recent_activity()
            body = (
                "[Bug]  [Priority: \U0001f4a5 Auto-crash]  [Area: Auto-captured]\n\n"
                "\U0001f4a5 An unhandled error occurred in the plugin and was auto-captured "
                "on this machine. Root cause needs fixing.\n\n"
                f"Error:   {etype}: {emsg}\n"
                f"Where:   {where}  (in {where_func})\n"
                f"Fingerprint: {fp}\n\n"
                "WHAT THE PLUGIN WAS DOING (oldest -> newest):\n"
                + ("\n".join(f"  - {c}" for c in ctx[-15:]) or "  (no breadcrumb)")
                + "\n\nTRACEBACK:\n" + (tb[-3500:] or "(none)")
            )
            payload = {
                'kind': 'bug',
                'title': (f"\U0001f4a5 Auto: {etype} in {where_func} (crash)")[:160],
                'body': body,
            }
            self._submit_ticket(payload)
        except Exception:
            pass

    def _run_ticket_uploads_off_thread(self, backend, shots, pdf, fname):
        """Do the BLOCKING urllib uploads (screenshots + PDF doc) on a worker
        thread so the submit never freezes the QGIS UI, pumping events while we
        wait (the ux.py philosophy — NO nested QEventLoop). urllib is pure network
        → safe off the main thread; backend.insert (QgsNetworkAccessManager) stays
        on the main thread, called by the caller AFTER this returns.

        Returns {'shot_urls': [...], 'doc_url': str|None}. Fail-soft: if threading
        is unavailable for any reason it falls back to a synchronous upload so a
        ticket is NEVER lost (PDF-first)."""
        out = {'shot_urls': [], 'doc_url': None}

        def _do():
            for png in shots:
                try:
                    u = backend.upload_screenshot(png)
                except Exception:
                    u = None
                if u:
                    out['shot_urls'].append(u)
            if pdf:
                for _attempt in range(2):       # one retry — uploads fail transiently
                    try:
                        d = backend.upload_bytes(
                            pdf, 'pdf', 'application/pdf', filename=fname)
                    except Exception:
                        d = None
                    if d:
                        out['doc_url'] = d
                        break

        try:
            from qgis.PyQt.QtCore import QThread
            from qgis.PyQt.QtWidgets import QApplication

            class _Uploader(QThread):
                def run(self_):
                    _do()

            w = _Uploader()
            w.start()
            # keep the UI responsive while the worker uploads; wait(ms) returns
            # True once the thread has finished, so the loop exits cleanly.
            while not w.wait(25):
                QApplication.processEvents()
        except Exception:
            _do()                                # no threads → synchronous fallback
        return out

    def _render_ticket_pdf(self, payload, shots=None):
        """Render the WHOLE ticket — title, metadata, body, and the actual
        screenshot images embedded — to PDF bytes for Telegram delivery. Qt
        only, no external deps. Qt5/Qt6-safe. Returns bytes or None — fail-soft.

        shots: list of raw PNG bytes (the originals), so the images are embedded
        in the PDF rather than just linked."""
        try:
            from qgis.PyQt.QtGui import (QPdfWriter, QTextDocument, QImage)
            from qgis.PyQt.QtCore import (QBuffer, QByteArray, QIODevice, QUrl,
                                          Qt)

            def _esc(s):
                return (str(s).replace('&', '&amp;').replace('<', '&lt;')
                        .replace('>', '&gt;'))

            kind = ('Bug report' if payload.get('kind') == 'bug'
                    else 'Feature request')
            meta = [
                ('Type', kind),
                ('From', payload.get('display_name')
                 or payload.get('username') or '-'),
                ('Plugin', payload.get('plugin_version') or '-'),
                ('QGIS', payload.get('qgis_version') or '-'),
                ('Project', payload.get('project_name') or '-'),
            ]
            meta_html = ''.join(
                f"<tr><td><b>{_esc(k)}</b>&nbsp;&nbsp;</td>"
                f"<td>{_esc(v)}</td></tr>" for k, v in meta)
            body = payload.get('body') or '(no details given)'

            ba = QByteArray()
            buf = QBuffer(ba)
            buf.open(QIODevice.OpenModeFlag.WriteOnly)
            writer = QPdfWriter(buf)
            # High DPI so embedded screenshots + text are crisp, not blurry (JJ).
            _pdf_res = 300
            try:
                writer.setResolution(_pdf_res)
            except Exception:
                _pdf_res = 150
                try:
                    writer.setResolution(_pdf_res)
                except Exception:
                    pass
            doc = QTextDocument()
            # CRITICAL: make the document convert font point sizes (and <img>
            # widths) at the writer's DPI, not Qt's default 96 dpi. Without this,
            # the page is sized in 300-dpi pixels while text stays 96-dpi -> every
            # letter renders ~1/3 size, crammed into the top corner (JJ 2026-07-13,
            # "letters looking funny"). Also set a comfortable field-readable base
            # font. Fail-soft: on any error keep the old behaviour, never drop the PDF.
            try:
                doc.documentLayout().setPaintDevice(writer)
                _f = doc.defaultFont()
                _f.setPointSizeF(11.0)
                doc.setDefaultFont(_f)
            except Exception:
                pass

            # Fill the printable page width so each screenshot uses the MOST device
            # pixels possible. Make the document page match the PDF page; fall back to
            # a sensible fixed width if the layout API isn't available.
            _page_w = 2200
            try:
                from qgis.PyQt.QtCore import QSizeF as _QSizeF
                _pr = writer.pageLayout().paintRectPixels(_pdf_res)
                doc.setPageSize(_QSizeF(_pr.width(), _pr.height()))
                _page_w = int(_pr.width() * 0.98)
            except Exception:
                pass

            # Embed the actual screenshot images as document resources so they render
            # inside the PDF (not just listed as URLs). Display each at its NATIVE
            # resolution up to the page width — never upscaled (that's what blurs a
            # small grab) and never needlessly shrunk below page width.
            shots_html = ''
            for i, png in enumerate(shots or []):
                try:
                    img = QImage()
                    if not img.loadFromData(bytes(png), 'PNG') or img.isNull():
                        continue
                    # No need to embed more pixels than we can display (page width).
                    if img.width() > _page_w:
                        img = img.scaledToWidth(
                            _page_w, Qt.TransformationMode.SmoothTransformation)
                    _disp_w = min(_page_w, img.width())   # never upscale -> never blur
                    name = f"shot{i}"
                    doc.addResource(
                        QTextDocument.ResourceType.ImageResource,
                        QUrl(name), img)
                    shots_html += (f"<p><b>Screenshot {i + 1}</b></p>"
                                   f"<p><img src='{name}' width='{_disp_w}'></p>")
                except Exception:
                    continue

            html = (
                f"<h2>{_esc(payload.get('title') or 'Ticket')}</h2>"
                f"<table cellpadding='2'>{meta_html}</table><hr>"
                "<pre style=\"font-family:Consolas,'Courier New',monospace;"
                "font-size:10pt; white-space:pre-wrap;\">"
                f"{_esc(body)}</pre>{shots_html}")
            doc.setHtml(html)
            # PyQt5 exposes print_(), PyQt6 print() — support both.
            printer = getattr(doc, 'print_', None) or doc.print
            printer(writer)
            buf.close()
            return bytes(ba)
        except Exception:
            return None

    # ── Account guard (remote deactivate = total lockout) ─────────────────────
    def _start_account_guard(self):
        """Lock the whole tool if the planning office deactivated this account.
        Server-driven (is_user_active RPC) — only the office can reactivate; the
        teammate has no path to flip it. Cached lock survives restarts/offline."""
        try:
            from qgis.core import QgsSettings
            if QgsSettings().value('VelocityFibre/account_deactivated',
                                   False, type=bool):
                self._apply_deactivation(True)   # restore the lock immediately
        except Exception:
            pass
        self._report_machine_fingerprint()   # backfill so a deactivate can ban this PC
        self._check_account_active()
        try:
            from qgis.PyQt.QtCore import QTimer
            self._acct_timer = QTimer(self.iface.mainWindow())
            self._acct_timer.timeout.connect(self._check_account_active)
            self._acct_timer.start(10 * 60 * 1000)   # re-check every 10 min
            # notify-back: tell the teammate when a ticket they logged is fixed
            QTimer.singleShot(6000, self._check_resolved_tickets)
        except Exception:
            pass

    def _report_machine_fingerprint(self):
        """Record this machine's fingerprint on our installs row (anon UPDATE is
        allowed). If the office later deactivates this account, a DB trigger bans
        every fingerprint this user has used — so they can't sign up again under
        a new name from the same PC. Fire-and-forget; never blocks."""
        try:
            nx = getattr(self, '_nexus', None)
            backend = getattr(nx, 'backend', None) if nx else None
            prof = getattr(nx, 'profile', None) if nx else None
            if backend is None or prof is None:
                return
            try:
                from .fibre_automation.nexus_profile import fingerprint, profile as _pf
            except ImportError:
                from fibre_automation.nexus_profile import fingerprint, profile as _pf
            fp = fingerprint.machine_fingerprint()
            iid = _pf.Profile.install_id()
            if fp and iid:
                backend.update("installs", f"install_id=eq.{iid}",
                               {"machine_fingerprint": fp})
        except Exception:
            pass

    def _check_resolved_tickets(self):
        """Non-modal heads-up when a ticket THIS user logged has been resolved —
        either 'update to vX' or 'you're already on the fixed version'. Shown once
        per ticket (acknowledged IDs cached locally). Privacy-safe: the RPC only
        ever returns the caller's own tickets."""
        nx = getattr(self, '_nexus', None)
        prof = getattr(nx, 'profile', None) if nx else None
        backend = getattr(nx, 'backend', None) if nx else None
        u = getattr(prof, 'username', None)
        if backend is None or not u:
            return
        try:
            backend.my_resolved_tickets(u, self._on_resolved_tickets)
        except Exception:
            pass

    def _on_resolved_tickets(self, rows):
        if not rows:
            return
        try:
            import re as _re
            from qgis.core import QgsSettings, Qgis
            s = QgsSettings()
            acked = set(filter(None, (s.value('VelocityFibre/nexus/ackTickets', '')
                                      or '').split(',')))
            myver = getattr(getattr(self, '_nexus', None), 'plugin_version', None) or '0'

            def vt(x):
                return tuple(int(n) for n in _re.findall(r'\d+', str(x or '0')))

            new_ack = set(acked)
            shown = 0
            for r in rows:
                tid = str(r.get('id'))
                if not tid or tid in acked:
                    continue
                if shown >= 3:                       # don't flood the bar
                    # Do NOT ack here — leave un-shown tickets unacknowledged so
                    # they surface on a later call instead of being silenced forever.
                    continue
                title = r.get('title') or 'your ticket'
                fixver = r.get('resolved_in_version') or '?'
                is_bug = (r.get('kind') == 'bug')
                icon = '🐞' if is_bug else '💡'
                noun = 'bug report' if is_bug else 'feature request'
                verb = 'has been fixed' if is_bug else 'has been built'
                if vt(myver) >= vt(fixver):
                    self.iface.messageBar().pushSuccess(
                        'Velocity Nexus',
                        f'{icon} Your {noun} “{title}” {verb} — you’re already on the '
                        f'latest version. Thanks for reporting it!')
                else:
                    self.iface.messageBar().pushMessage(
                        'Velocity Nexus',
                        f'{icon} Your {noun} “{title}” {verb} in v{fixver} — please '
                        f'update (Plugins → Manage and Install Plugins → Upgradeable).',
                        level=Qgis.MessageLevel.Info, duration=15)
                new_ack.add(tid)
                shown += 1
            s.setValue('VelocityFibre/nexus/ackTickets', ','.join(sorted(new_ack)))
        except Exception:
            pass

    def _check_account_active(self):
        # Stage-2 tick first — runs every cycle even offline, so the 3-day
        # self-destruct countdown advances without needing the server.
        self._self_destruct_check()
        nx = getattr(self, '_nexus', None)
        prof = getattr(nx, 'profile', None) if nx else None
        backend = getattr(nx, 'backend', None) if nx else None
        u = getattr(prof, 'username', None)
        if backend is None or not u:
            return
        try:
            backend.check_active(u, self._on_active_result)
        except Exception:
            pass

    def _on_active_result(self, active):
        # True → active (lift any lock) · False → deactivated (lock) ·
        # None → offline/unknown (leave as-is; a cached lock persists)
        if active is True:
            self._apply_deactivation(False)
        elif active is False:
            self._apply_deactivation(True)

    def _is_owner_machine(self):
        """True on the planning-office (owner) machine — the admin read-key is
        present only there and never ships. Used to make the owner un-lockable."""
        try:
            from qgis.core import QgsSettings
            return bool(QgsSettings().value('VelocityFibre/nexus/adminKey') or '')
        except Exception:
            return False

    def _apply_deactivation(self, on):
        """Lock (on) or restore (off) the whole tool. Idempotent — only acts on
        an actual state change."""
        # Owner machine is NEVER locked — you can't deactivate yourself and get
        # shut out of the Team Monitor you'd need to re-enable from. (Restore,
        # on=False, is always allowed so a machine can never get stuck locked.)
        if on and self._is_owner_machine():
            return
        if getattr(self, '_deactivated', None) == on:
            return
        self._deactivated = on
        try:
            from qgis.core import QgsSettings
            QgsSettings().setValue('VelocityFibre/account_deactivated', on)
        except Exception:
            pass
        # 1. swap the home panel to the soft 'deactivated' screen
        try:
            if getattr(self, '_home_panel', None) is not None:
                self._home_panel.set_deactivated(on)
        except Exception:
            pass
        # 2. disable / re-enable the Velocity Nexus menu
        try:
            if getattr(self, '_velo_menu', None) is not None:
                self._velo_menu.menuAction().setEnabled(not on)
        except Exception:
            pass
        # 3. unregister / re-register the processing provider (no automation runs)
        try:
            from qgis.core import QgsApplication
            reg = QgsApplication.processingRegistry()
            if on:
                prov = getattr(self, 'provider', None)
                if prov is not None:
                    reg.removeProvider(prov)
            else:
                if reg.providerById('fibernetwork') is None:
                    self.initProcessing()
        except Exception:
            pass
        # 4. disable / re-enable the toolbar
        try:
            if getattr(self, '_toolbar', None) is not None:
                self._toolbar.setEnabled(not on)
        except Exception:
            pass
        # 5. disable / re-enable EVERY plugin action. This is what actually blocks
        #    the app-wide keyboard shortcuts (Ctrl+1..8, Ctrl+Shift+E, etc.) — a
        #    disabled QAction won't fire its shortcut, and disabling the toolbar
        #    alone does NOT do that. Remember prior enabled-state so restore is exact.
        try:
            acts = getattr(self, '_actions', {}) or {}
            if on:
                self._lock_prev_enabled = {k: a.isEnabled() for k, a in acts.items()}
                for a in acts.values():
                    a.setEnabled(False)
            else:
                prev = getattr(self, '_lock_prev_enabled', {})
                for k, a in acts.items():
                    a.setEnabled(prev.get(k, True))
                self._lock_prev_enabled = {}
        except Exception:
            pass
        # 6. Ctrl+K locator filter — deregister our results when locked (else a
        #    teammate could launch tools straight from the QGIS locator bar).
        try:
            if on:
                loc = getattr(self, '_locator', None)
                if loc is not None:
                    self.iface.deregisterLocatorFilter(loc)
                    self._locator = None
            elif getattr(self, '_locator', None) is None:
                self._install_locator_filter()
        except Exception:
            pass
        # 7. Ctrl+Shift+P command palette shortcut
        try:
            sc = getattr(self, '_cmd_palette_shortcut', None)
            if sc is not None:
                sc.setEnabled(not on)
        except Exception:
            pass
        # 8. close any floating tool panels that were already open at lock time
        if on:
            for attr in ('_pole_editor_panel', '_np_dock'):
                try:
                    w = getattr(self, attr, None)
                    if w is not None:
                        w.close()
                except Exception:
                    pass
        # 9. arm/disarm the self-destruct countdown (stamp now on a fresh lock,
        #    cancel it on reactivation). Stage 2 deletes the install after 3 days.
        self._self_destruct_check()

    def _self_destruct_check(self):
        """Stage 2 of the account guard. If this account has stayed deactivated
        for the configured window (default 3 days), remove the installed plugin
        from this machine. Owner-exempt and fail-open — see self_destruct.py."""
        try:
            import os
            try:
                from .fibre_automation.nexus_profile import self_destruct
            except ImportError:
                from fibre_automation.nexus_profile import self_destruct
            plugin_dir = os.path.dirname(os.path.abspath(__file__))
            self_destruct.evaluate(plugin_dir, self.iface)
        except Exception as e:
            print(f'[FiberNet] self-destruct check skipped: {e}')

    def _open_velo_menu(self, anchor=None):
        """Pop the full Velocity Nexus menu under the panel's ⚙ button."""
        from qgis.PyQt.QtCore import QPoint
        if getattr(self, '_velo_menu', None) is None:
            self._build_menu()
        try:
            if anchor is not None:
                self._velo_menu.popup(anchor.mapToGlobal(QPoint(0, anchor.height())))
            else:
                from qgis.PyQt.QtGui import QCursor
                self._velo_menu.popup(QCursor.pos())
        except Exception as e:
            self.iface.messageBar().pushWarning('Velocity Nexus', f'Menu error: {e}')

    def _run_health_check(self):
        """Quick self-check: bridge, roads data, PON order, activation, deps."""
        import os
        from qgis.PyQt.QtWidgets import QMessageBox
        rows = []
        try:
            from .fibre_automation.shared.vf_paths import roads_json, data_dir
        except ImportError:
            from fibre_automation.shared.vf_paths import roads_json, data_dir
        try:
            from . import activation as _a
        except ImportError:
            import activation as _a
        rows.append(('Activated', '✓' if _a.is_activated() else '✗ enter password'))
        rj = roads_json()
        rows.append(('Road data (FT7/FT8)', '✓ present' if os.path.exists(rj) else '— optional, not found'))
        rows.append(('Data/output folder', data_dir()))
        for pkg in ('geopandas', 'openpyxl', 'matplotlib'):
            try:
                __import__(pkg); rows.append((pkg, '✓'))
            except Exception:
                rows.append((pkg, '— installs on first use'))
        rows.append(('Plugin version', self._plugin_version()))
        QMessageBox.information(self.iface.mainWindow(), 'Velocity Nexus — Health check',
                               '\n'.join(f'{k}:  {v}' for k, v in rows))

    def _open_data_folder(self):
        from qgis.PyQt.QtCore import QUrl
        from qgis.PyQt.QtGui import QDesktopServices
        try:
            from .fibre_automation.shared.vf_paths import project_output_dir
        except ImportError:
            from fibre_automation.shared.vf_paths import project_output_dir
        try:
            QDesktopServices.openUrl(QUrl.fromLocalFile(project_output_dir()))
        except Exception as e:
            self.iface.messageBar().pushWarning('Velocity Nexus', str(e)[:160])

    def _copy_diagnostics(self):
        import platform
        from qgis.core import Qgis
        from qgis.PyQt.QtWidgets import QApplication
        try:
            from . import activation as _a
        except ImportError:
            import activation as _a
        txt = (f'Velocity Nexus {self._plugin_version()}\n'
               f'QGIS {Qgis.QGIS_VERSION}\nPython {platform.python_version()}\n'
               f'OS {platform.system()} {platform.release()} · {platform.node()}\n'
               f'Activated: {_a.is_activated()}')
        QApplication.clipboard().setText(txt)
        self.iface.messageBar().pushInfo('Velocity Nexus', 'Diagnostics copied to clipboard.')

    def _open_team_guide(self):
        """Show the bundled team guide rendered in-app (not the GitHub repo —
        that was the bug: with no local guide it fell back to opening GitHub)."""
        import os
        path = os.path.join(os.path.dirname(__file__), 'TEAM_GUIDE.md')
        if not os.path.exists(path):
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtGui import QDesktopServices
            QDesktopServices.openUrl(QUrl('https://github.com/JohanVelo/qz31-cache'))
            return
        try:
            from qgis.PyQt import sip
            _prev = getattr(self, '_team_guide_dlg', None)
            if _prev is not None and not sip.isdeleted(_prev):
                _prev.raise_(); _prev.activateWindow()
                return
        except Exception:
            pass
        try:
            from qgis.PyQt.QtCore import Qt
            from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QTextBrowser
            with open(path, encoding='utf-8') as _f:
                md = _f.read()
            dlg = QDialog(self.iface.mainWindow())
            dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)   # don't leak hidden windows
            dlg.setWindowTitle('Velocity Nexus — Team Guide')
            dlg.resize(780, 660)
            lay = QVBoxLayout(dlg)
            tb = QTextBrowser()
            tb.setOpenExternalLinks(True)
            try:
                tb.setMarkdown(md)          # Qt 5.14+: rendered markdown
            except Exception:
                tb.setPlainText(md)
            lay.addWidget(tb)
            try:
                from .nexus_dock import chrome_dialog
                chrome_dialog(dlg)
            except Exception:
                pass
            dlg.show()                      # non-modal (never block the UI)
            self._team_guide_dlg = dlg      # keep a ref so it isn't GC'd
        except Exception as e:
            self.iface.messageBar().pushWarning('Team guide', str(e)[:160])

    # ── Activation gate (build prompt §5) ────────────────────────────────────
    def _apply_activation_gate(self):
        """No valid token → every menu + toolbar action greyed except About & Activation."""
        try:
            try:
                from . import activation
            except ImportError:
                import activation
            active = activation.is_activated()
        except Exception as e:
            print(f'[FiberNet] activation check failed (leaving unlocked): {e}')
            return

        always_on = {getattr(self, '_about_action', None),
                     getattr(self, '_report_action', None)}

        def set_menu(menu, enabled):
            for a in menu.actions():
                sub = a.menu()
                if sub is not None:
                    set_menu(sub, enabled)
                    a.setEnabled(enabled)
                elif a not in always_on:
                    a.setEnabled(enabled)

        if getattr(self, '_velo_menu', None) is not None:
            try:
                set_menu(self._velo_menu, active)
            except RuntimeError:
                pass
        try:
            for a in self._toolbar.actions():
                a.setEnabled(active)
        except (RuntimeError, AttributeError):
            pass
        # No password → NOTHING works (JJ: "you won't get in at all"):
        # the Processing provider is unregistered (no Toolbox access) and the
        # Home panel is disabled, on top of the greyed menu/toolbar/shortcuts.
        try:
            from qgis.core import QgsApplication
            reg = QgsApplication.processingRegistry()
            registered = reg.providerById('fibernetwork') is not None
            if active and not registered:
                self.initProcessing()
            elif not active and registered:
                reg.removeProvider(self.provider)
                self.provider = None
        except Exception as e:
            print(f'[FiberNet] provider gate failed: {e}')
        try:
            if self._home_panel is not None:
                # The panel itself stays enabled so the lock card is usable;
                # the card visibility tracks activation.
                self._home_panel.setEnabled(True)
                self._home_panel.set_locked(not active, self._panel_activate)
        except (RuntimeError, AttributeError):
            pass
        if not active:
            self.iface.messageBar().pushWarning(
                'Velocity Nexus',
                'Locked — enter the company password in the Velocity Nexus panel (right) '
                'or via the popup to unlock all tools.')

    def _apply_panel_theme(self, theme_name, accent_hex):
        """Live re-skin the home panel when the user picks a theme/accent in
        their profile card."""
        try:
            if self._home_panel is not None:
                self._home_panel.apply_user_theme(theme_name, accent_hex)
                self._refresh_home_steps()   # re-apply step states after re-skin
        except Exception:
            pass

    # ── "you are here" workflow progress ─────────────────────────────────────
    def _proj_has_layer(self, *name_substrings):
        """True if a vector layer whose name contains any substring has >0
        features. Used to derive workflow progress from real project state."""
        try:
            from qgis.core import QgsProject, QgsMapLayer
            for lyr in QgsProject.instance().mapLayers().values():
                try:
                    if lyr.type() != QgsMapLayer.LayerType.VectorLayer:
                        continue
                    nm = lyr.name().lower()
                    if any(s in nm for s in name_substrings) and lyr.featureCount() > 0:
                        return True
                except Exception:
                    continue
        except Exception:
            pass
        return False

    def _compute_home_step_states(self):
        """Map the 6 home-panel macro steps to done/current/todo from the
        project's layers. Conservative: only marks 'done' when the step's
        output clearly exists (never a false ✓). 'current' = first not-done."""
        done = [
            self._proj_has_layer('building'),                       # 1 Detect Buildings
            self._proj_has_layer('erven', 'erf'),                   # 2 Generate Erven
            self._proj_has_layer('pon', 'zone', 'splitter'),        # 3 Network Planner
            (self._proj_has_layer('pole')
             and self._proj_has_layer('distribution', 'cable')),    # 4 Label Network
            False,                                                  # 5 Check & Audit (not layer-detectable)
            False,                                                  # 6 Splice Plan (file output)
            False,                                                  # 7 HLD Atlas PDF (file output)
        ]
        states, current_set = [], False
        for d in done:
            if d:
                states.append('done')
            elif not current_set:
                states.append('current')
                current_set = True
            else:
                states.append('todo')
        return states

    def _home_refresh_debounced(self, *args):
        """Coalesce a burst of layersAdded/Removed (project open adds N layers, a tool
        emits several) into ONE _refresh_home_steps ~150 ms later, instead of N full
        context recomputes. Falls back to an immediate refresh if the timer can't start
        (the refresh must never be silently skipped)."""
        try:
            from qgis.PyQt.QtCore import QTimer
            t = getattr(self, '_home_ctx_timer', None)
            if t is None:
                t = QTimer(self.iface.mainWindow())
                t.setSingleShot(True)
                t.timeout.connect(self._refresh_home_steps)
                self._home_ctx_timer = t
            t.start(150)
        except Exception:
            try:
                self._refresh_home_steps()
            except Exception:
                pass

    def _refresh_home_steps(self, *args):
        try:
            if getattr(self, '_home_panel', None) is not None:
                self._home_panel.set_step_states(self._compute_home_step_states())
                self._refresh_home_context()
        except Exception:
            pass

    def _refresh_home_context(self):
        """Feed the home panel's live project-context strip. CHEAP ONLY —
        featureCount() (cached metadata, instant) + the pre-computed HLD score
        file. NEVER iterate features here (would freeze the QGIS main thread;
        see feedback_never_heavy_loops_via_bridge)."""
        panel = getattr(self, '_home_panel', None)
        if panel is None:
            return
        try:
            from qgis.core import QgsProject, QgsMapLayer
            proj = QgsProject.instance()
            layers = list(proj.mapLayers().values())

            def _count(*keys, mode='sum'):
                vals = [ly.featureCount() for ly in layers
                        if ly.type() == QgsMapLayer.LayerType.VectorLayer
                        and any(k in ly.name().lower() for k in keys)]
                if not vals:
                    return 0
                return max(vals) if mode == 'max' else sum(vals)

            ctx = {
                'project_name': proj.baseName() or None,
                'layer_count': len(layers),
                # max (not sum) — there can be several building layers (GOB + SAM)
                'buildings': _count('building', mode='max'),
                'erven': _count('erven', 'erf', mode='max'),
                'poles': _count('pole'),
                'onts': _count('ont', 'home connection', mode='max'),
                'splitters': _count('splitter', 'sts'),
            }
            # HLD score from the cached file (NOT a live audit) — only show when
            # it carries a real result (pass or fail present), never "✓ 0".
            try:
                import json as _json
                with open('C:/Temp/hld_score.json', encoding='utf-8') as _f:
                    s = _json.load(_f)
                p, fl = s.get('pass') or 0, s.get('fail') or 0
                if p or fl:
                    # numeric 0–100 readiness for the score ring
                    ctx['hld_score'] = int(round(100 * p / (p + fl)))
                    ctx['hld'] = (f'HLD ✓ {p}/{p + fl}' if not fl
                                  else f'HLD ⚠ {fl} issue' + ('s' if fl != 1 else ''))
            except Exception:
                pass
            panel.set_context(ctx)
        except Exception:
            pass

    def _panel_activate(self, password):
        """Activation callback for the Home-panel lock card.
        Returns (ok, message). On success: unlock gate + welcome screen."""
        try:
            from . import activation
        except ImportError:
            import activation
        if activation.seconds_locked() > 0:
            return (False, f'Too many attempts — wait {activation.seconds_locked()}s.')
        if activation.try_activate(password):
            self._apply_activation_gate()
            try:
                self._welcome_splash = activation.show_welcome(self.iface, self._plugin_version())
            except Exception:
                pass
            return (True, '')
        if activation.seconds_locked() > 0:
            return (False, f'Too many attempts — wait {activation.seconds_locked()}s.')
        return (False, 'Wrong password. Please try again.')

    def _prompt_activation_if_locked(self):
        """On startup, if not activated, make it impossible to miss: pop the branded
        Activation dialog (non-blocking) AND show the Home-panel lock card."""
        try:
            from . import activation
        except ImportError:
            import activation
        try:
            if activation.is_activated():
                return
            if self._home_panel is not None:
                self._home_panel.set_locked(True, self._panel_activate)
                self._home_panel.setVisible(True)
                self._home_panel.raise_()
            # non-blocking modal dialog, centred — the first thing they see
            dlg = activation.ActivationDialog(self.iface)
            dlg.dlg.setModal(True)
            dlg.dlg.show()
            dlg.dlg.raise_()
            dlg.dlg.activateWindow()

            def _after():
                if activation.is_activated():
                    self._apply_activation_gate()
                    if self._home_panel is not None:
                        self._home_panel.set_locked(False)
                    try:
                        self._welcome_splash = activation.show_welcome(
                            self.iface, self._plugin_version())
                    except Exception:
                        pass
            dlg.dlg.finished.connect(lambda _=0: _after())
            self._activation_prompt = dlg
        except Exception as e:
            print(f'[FiberNet] activation prompt failed: {e}')

    def _open_about_activation(self):
        try:
            from . import activation
        except ImportError:
            import activation
        from qgis.PyQt.QtWidgets import QMessageBox
        if activation.is_activated():
            ret = QMessageBox.question(
                self.iface.mainWindow(), 'Velocity Nexus',
                f'Velocity Nexus {self._plugin_version()}\n'
                'Status: ACTIVATED on this machine ✓\n\n'
                'Deactivate this machine?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
            if ret == QMessageBox.StandardButton.Yes:
                activation.deactivate()
                self._apply_activation_gate()
        else:
            if activation.ActivationDialog(self.iface).exec():
                self._apply_activation_gate()
                self.iface.messageBar().pushSuccess(
                    'Velocity Nexus', 'Activated — all tools unlocked ✓')
                try:
                    self._welcome_splash = activation.show_welcome(
                        self.iface, self._plugin_version())
                except Exception as e:
                    print(f'[FiberNet] welcome splash failed: {e}')

    def _export_cloud_formats(self):
        """Export all layers to GeoParquet + the network to OFDS JSON
        (cloud-native + open-standard deliverables; plain-QGIS via GDAL)."""
        import os
        from qgis.PyQt.QtWidgets import QFileDialog
        from qgis.PyQt.QtCore import Qt
        from qgis.core import QgsProject, Qgis
        default = (os.path.dirname(QgsProject.instance().fileName())
                   or os.path.expanduser('~'))
        out_dir = QFileDialog.getExistingDirectory(
            self.iface.mainWindow(),
            'Export GeoParquet + OFDS to folder…', default)
        if not out_dir:
            return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        mb = self.iface.messageBar()
        running = mb.createMessage('Export', 'Writing GeoParquet + OFDS…')
        mb.pushWidget(running, Qgis.MessageLevel.Info)
        QApplication.processEvents()
        try:
            try:
                from .fibre_automation import cloud_export as ce
            except ImportError:
                from fibre_automation import cloud_export as ce
            res = ce.export_project_to_geoparquet(out_dir)
            ok = [r for r in res if r['ok']]
            _, ofds_msg = ce.export_ofds(
                os.path.join(out_dir, 'network.ofds.json'))
            mb.pushSuccess(
                'Export', f"GeoParquet: {len(ok)}/{len(res)} layers · "
                          f"OFDS: {ofds_msg.split(' →')[0]}  →  {out_dir}")
        except Exception as e:
            self._log_and_push_critical('cloud export', e)
        finally:
            QApplication.restoreOverrideCursor()
            try:
                mb.popWidget(running)
            except Exception:
                pass

    def _export_design_report(self):
        """Generate the one-click Design Report PDF (Atlas map-book over PON/Zone)."""
        from qgis.PyQt.QtWidgets import QApplication
        from qgis.PyQt.QtCore import Qt
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            try:
                from . import report
            except ImportError:
                import report
            report.export_design_report(self.iface)
        except Exception as e:
            self.iface.messageBar().pushWarning('Velocity Nexus', f'Design Report: {e}')
        finally:
            QApplication.restoreOverrideCursor()

    def _show_home_panel(self):
        """Open / re-show the Velocity Nexus home dashboard panel.
        Re-creates it if it was closed (C++ object deleted)."""
        try:
            panel = getattr(self, '_home_panel', None)
            if panel is not None:
                try:
                    panel.setVisible(True)
                    panel.raise_()
                    return
                except RuntimeError:
                    self._home_panel = None  # deleted — rebuild below
            self._install_home_panel()
            if self._home_panel is not None:
                self._home_panel.setVisible(True)
                self._home_panel.raise_()
        except Exception as e:
            self.iface.messageBar().pushWarning('Velocity Nexus', f'Could not open the panel: {e}')

    def _open_workflow_dock(self):
        """Open the guided Workflow dock (checklist + validation)."""
        try:
            try:
                from . import workflow_dock
            except ImportError:
                import workflow_dock
            self._workflow_dock = workflow_dock.open_dock(self.iface)
        except Exception as e:
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.warning(self.iface.mainWindow(), 'Velocity Nexus',
                                f'Could not open the Workflow dock:\n{e}')

    def _generate_hld_pdf(self):
        """Open the Generate HLD PDF (BETA) dialog — builds the A3 atlas PDF in a
        separate headless process (never freezes QGIS); working project untouched."""
        try:
            try:
                from .hld_pdf import open_hld_pdf_dialog
            except ImportError:
                from hld_pdf import open_hld_pdf_dialog
            open_hld_pdf_dialog(self.iface)
        except Exception as e:
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.warning(self.iface.mainWindow(), 'Velocity Nexus',
                                f'Could not open Generate HLD PDF:\n{e}')

    def _maybe_whats_new(self):
        """Show the premium What's-New board once per new version after an upgrade
        (gated to activated machines). Card design grouped NEW / FIXED / IMPROVED,
        listing EVERYTHING since the version they last saw."""
        try:
            try:
                from . import activation, whats_new
            except ImportError:
                import activation, whats_new
            if not activation.is_activated():
                return
            from qgis.core import QgsSettings
            s = QgsSettings()
            version = self._plugin_version().lstrip('v')
            # same gate key the old text popup used → once-per-version, consistent
            seen = s.value('VelocityFibre/whatsNewVersion', '')
            if seen == version:
                return
            if not seen:
                # first ever install — the welcome screen covers this
                s.setValue('VelocityFibre/whatsNewVersion', version)
                return
            self._whats_new_dlg = whats_new.show_whats_new(
                seen, version, parent=self.iface.mainWindow())
            # Persist 'seen' only AFTER the dialog was shown successfully, so a
            # failure to display doesn't silently suppress this version forever.
            s.setValue('VelocityFibre/whatsNewVersion', version)
        except Exception as e:
            print(f'[FiberNet] whats-new failed: {e}')

    def _open_problem_report(self):
        """Open the Report a Problem dialog — teammates send their error log to JJ."""
        try:
            try:
                from . import error_reporter
            except ImportError:
                import error_reporter
            # Close any previous instance so repeated opens don't stack dialogs.
            try:
                from qgis.PyQt import sip
                _prev = getattr(self, '_problem_dlg', None)
                if _prev is not None and getattr(_prev, 'dlg', None) is not None \
                        and not sip.isdeleted(_prev.dlg):
                    _prev.dlg.close()
            except Exception:
                pass
            self._problem_dlg = error_reporter.ProblemReportDialog(self.iface)
            self._problem_dlg.show()
        except Exception as e:
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.warning(self.iface.mainWindow(), 'Velocity Nexus',
                                f'Could not open the report dialog:\n{e}')

    def _open_tool_map(self):
        """Generate + open the Admin/Tool Map page (JJ requirement, Phase 0 sign-off):
        a tidy HTML page of every menu action so you can always see what's where.
        Built from the LIVE menu, so it can never drift out of date."""
        import html as _html
        import tempfile
        from qgis.PyQt.QtCore import QUrl
        from qgis.PyQt.QtGui import QDesktopServices
        from qgis.core import QgsApplication

        def walk(menu, depth=0):
            rows = []
            for a in menu.actions():
                if a.isSeparator():
                    continue
                sub = a.menu()
                if sub is not None:
                    rows.append((depth, sub.title(), '', True))
                    rows.extend(walk(sub, depth + 1))
                elif a.text():
                    rows.append((depth, a.text(), a.toolTip() or '', False))
            return rows

        rows = walk(self._velo_menu)
        algs = sorted(a.id() + ' — ' + a.displayName()
                      for a in QgsApplication.processingRegistry().algorithms()
                      if a.id().startswith('fibernetwork:'))
        try:
            ver = self._plugin_version()
        except Exception:
            ver = ''
        body = ['<!DOCTYPE html><html><head><meta charset="utf-8"><title>Velocity Nexus — Tool Map</title>',
                '<style>body{font-family:Segoe UI,sans-serif;margin:2em auto;max-width:880px;color:#1a2050}',
                'h1{border-bottom:3px solid #8b2450}h2{color:#3d5cb8;margin-top:1.6em}',
                'table{border-collapse:collapse;width:100%}td{padding:5px 10px;border-bottom:1px solid #eee;vertical-align:top}',
                '.grp{font-weight:bold;background:#f4f6fb}.tip{color:#667;font-size:0.9em}</style></head><body>',
                f'<h1>Velocity Nexus — Tool Map</h1><p>Every tool in the plugin, where it lives, and what it does. '
                f'Generated live from the menu — always current. {_html.escape(ver)}</p><h2>Menu</h2><table>']
        for depth, text, tip, is_group in rows:
            ind = '&nbsp;' * 6 * depth
            cls = ' class="grp"' if is_group else ''
            body.append(f'<tr{cls}><td>{ind}{_html.escape(text)}</td>'
                        f'<td class="tip">{_html.escape(tip).replace(chr(10), "<br>")}</td></tr>')
        body.append('</table><h2>Processing algorithms (Toolbox)</h2><ul>')
        body += [f'<li><code>{_html.escape(s)}</code></li>' for s in algs]
        body.append('</ul></body></html>')

        out = os.path.join(tempfile.gettempdir(), 'velocity_fibre_tool_map.html')
        with open(out, 'w', encoding='utf-8') as f:
            f.write('\n'.join(body))
        QDesktopServices.openUrl(QUrl.fromLocalFile(out))

    def _plugin_version(self):
        import configparser
        cp = configparser.ConfigParser()
        cp.read(os.path.join(os.path.dirname(__file__), 'metadata.txt'), encoding='utf-8')
        return 'v' + cp.get('general', 'version', fallback='?')

    def _check_for_updates(self):
        """Fetch the distro plugins.xml and compare versions (deep-link to Plugin
        Manager). The network fetch (urlopen, up to an 8 s timeout) runs OFF the
        main thread via off_thread so QGIS never freezes while waiting; the result
        dialog is shown back on the main thread. Same comparison + messages as
        before — only WHERE the network call runs changed."""
        import urllib.request
        from qgis.PyQt.QtWidgets import QMessageBox
        URL = ('https://raw.githubusercontent.com/JohanVelo/qz31-cache/main/plugins.xml')

        def _fetch():                        # WORKER THREAD — pure network IO
            return urllib.request.urlopen(URL, timeout=8).read().decode('utf-8', 'replace')

        def _show(xml):                      # MAIN THREAD — parse + compare + dialog
            import re as _re
            # match the PLUGIN tag's version, not the <?xml version="1.0"?> prolog
            m = _re.search(r'<pyqgis_plugin[^>]*\bversion="([\d.]+)"', xml)
            remote = m.group(1) if m else '?'
            local = self._plugin_version().lstrip('v')

            def _vt(v):
                try:
                    return tuple(int(x) for x in v.split('.'))
                except Exception:
                    return ()
            if remote != '?' and _vt(remote) > _vt(local):
                QMessageBox.information(
                    self.iface.mainWindow(), 'Velocity Nexus — update available',
                    f'Version {remote} is available (you have {local}).\n\n'
                    'Open Plugins → Manage and Install Plugins → Upgradeable to update.')
            else:
                QMessageBox.information(
                    self.iface.mainWindow(), 'Velocity Nexus',
                    f'You are up to date (v{local}).')

        def _fail(exc):                      # MAIN THREAD
            QMessageBox.warning(self.iface.mainWindow(), 'Velocity Nexus',
                                f'Could not check for updates:\n{exc}')

        try:
            from fibre_automation import off_thread
        except Exception:
            off_thread = None
        if off_thread is not None:
            try:
                self.iface.messageBar().pushInfo('Velocity Nexus', 'Checking for updates…')
            except Exception:
                pass
            # run_off_thread has its own synchronous fallback if no task manager.
            off_thread.run_off_thread(_fetch, on_done=_show, on_error=_fail,
                                      description='Check for updates')
        else:
            try:                             # module missing (older bundle) → sync
                _show(_fetch())
            except Exception as e:
                _fail(e)

    def initGui(self):
        # Nuke any stale FiberNetworkAutomation toolbar left behind by a
        # previous init (happens if startPlugin ran twice without a clean unload).
        from qgis.PyQt.QtWidgets import QToolBar
        for tb in self.iface.mainWindow().findChildren(QToolBar):
            try:
                if tb.objectName() == 'FiberNetworkAutomationToolbar':
                    self.iface.mainWindow().removeToolBar(tb)
                    tb.deleteLater()
            except RuntimeError:
                pass

        # Velocity Nexus per-user profile + telemetry + team monitor (v2.4.0).
        # Starts the session (first-run dialog on a fresh machine). Fail-silent
        # and dry-run-safe — never blocks plugin load.
        try:
            if getattr(self, '_nexus', None) is None:
                try:
                    from .fibre_automation.nexus_profile.manager import NexusManager
                except ImportError:
                    from fibre_automation.nexus_profile.manager import NexusManager
                self._nexus = NexusManager(self.iface)
                self._nexus.start()
            # Auto-capture errors -> Team Monitor (so teammates need not file tickets)
            if getattr(self, '_nexus', None) is not None:
                try:
                    from .fibre_automation.nexus_profile import error_capture
                except ImportError:
                    from fibre_automation.nexus_profile import error_capture
                error_capture.install(self._nexus)
                # Also auto-FILE A TICKET for each captured crash (deduped +
                # flood-guarded) so a massive error reaches the dev queue, not
                # just the errors table.
                try:
                    error_capture.set_ticket_callback(self._auto_ticket_from_error)
                except Exception:
                    pass
            # UI-freeze watchdog: detects when the Qt main thread is blocked
            # (e.g. a hang after an autonet/Network-Planner run) and reports the
            # culprit stack to telemetry. Daemon thread is pure-Python (no Qt),
            # reports drained on the main-thread heartbeat. Degrade-not-crash.
            try:
                try:
                    from .freeze_watchdog import FreezeWatchdog
                except ImportError:
                    from freeze_watchdog import FreezeWatchdog
                nx = getattr(self, '_nexus', None)

                def _on_freeze(rec):
                    try:
                        from qgis.core import QgsMessageLog, Qgis
                        QgsMessageLog.logMessage(
                            f"UI freeze {rec['duration_ms']}ms [{rec['severity']}] "
                            f"fp={rec['fingerprint']}\n{rec['stack_text']}",
                            "VelocityNexus", level=Qgis.MessageLevel.Warning)
                    except Exception:
                        pass
                    if nx is not None:
                        nx.report_freeze(rec)

                # A PERMANENT hang last session (QGIS killed before it recovered)
                # spools to disk — the live recover-then-report path can't fire in
                # that case. Drain + report it now, on the next clean start.
                try:
                    try:
                        from . import freeze_watchdog as _fw
                    except ImportError:
                        import freeze_watchdog as _fw
                    _prev = _fw.drain_spool()
                    if _prev is not None:
                        _on_freeze(_prev)
                        print(f"[FiberNet] reported a permanent hang from the "
                              f"previous session ({_prev['duration_ms']}ms)")
                except Exception:
                    pass

                self._freeze_watchdog = FreezeWatchdog()
                self._freeze_watchdog.start(self.iface.mainWindow(), _on_freeze)
                print('[FiberNet] UI-freeze watchdog started ✓')
            except Exception as e:
                self._freeze_watchdog = None
                print(f'[FiberNet] freeze watchdog not started: {e}')

            # Geometry Guardian: black-box recorder + auto-restore. When a MASSIVE
            # number of features/geometries disappears that the operator did NOT
            # cause (a bug / rogue regen wiping a layer), it restores them from a
            # rolling healthy snapshot and reports a full incident centrally — so
            # the team never has to reconstruct "what went wrong".
            try:
                try:
                    from .geometry_guardian import GeometryGuardian
                except ImportError:
                    from geometry_guardian import GeometryGuardian
                _gnx = getattr(self, '_nexus', None)
                _giface = self.iface

                def _on_guardian_incident(inc):
                    try:
                        from qgis.core import QgsMessageLog, Qgis
                        QgsMessageLog.logMessage(
                            f"Geometry Guardian: {inc['lost']} features vanished from "
                            f"'{inc['layer']}' (not an operator delete) — restored "
                            f"{inc['restored']}. before={inc['before']} after={inc['after']}",
                            "VelocityNexus", level=Qgis.MessageLevel.Critical)
                    except Exception:
                        pass
                    try:
                        from qgis.core import Qgis as _Q
                        _giface.messageBar().pushMessage(
                            "🛡️ Geometry Guardian",
                            f"{inc['lost']} features disappeared from '{inc['layer']}' "
                            f"(not an operator delete) — auto-restored {inc['restored']}. "
                            "Incident logged.",
                            level=_Q.MessageLevel.Critical, duration=12)
                    except Exception:
                        pass
                    try:
                        if _gnx is not None and hasattr(_gnx, 'record_error'):
                            _gnx.record_error(
                                "geometry_guardian",
                                RuntimeError(
                                    f"mass geometry loss: {inc['lost']} from "
                                    f"'{inc['layer']}', restored {inc['restored']}"),
                                user_note=str(inc))
                    except Exception:
                        pass
                    # Close the loop: auto-file a deduplicated bug ticket carrying the
                    # full crash report so the root cause lands in the dev queue.
                    try:
                        self._auto_ticket_from_incident(inc)
                    except Exception:
                        pass

                self._geometry_guardian = GeometryGuardian(report_cb=_on_guardian_incident)
                self._geometry_guardian.start()
                print('[FiberNet] Geometry Guardian started ✓')
            except Exception as e:
                self._geometry_guardian = None
                print(f'[FiberNet] Geometry Guardian not started: {e}')
        except Exception as e:
            self._nexus = None
            print(f'[FiberNet] Nexus profile init skipped: {e}')

        # Heal a stranded Splice-Viewer 'solo' dim on the ALREADY-open project
        # (readProject only fires for projects opened later). Fail-silent no-op
        # when nothing is stranded.
        try:
            self._heal_stranded_solo()
        except Exception:
            pass

        self._toolbar = self.iface.mainWindow().addToolBar('FiberNetworkAutomation')
        self._toolbar.setObjectName('FiberNetworkAutomationToolbar')
        self._toolbar.setIconSize(QSize(22, 22))  # research-recommended size
        # Toolbar QSS now follows the active Velocity Nexus theme (matches the panel
        # and switches with it).
        self._toolbar.setStyleSheet(_toolbar_qss_for_theme())
        self._build_toolbar()
        # Bridge poller is a dev-only Claude channel — teammates have no bridge.
        if self._is_dev_mode():
            self._start_bridge_poller()
        # Live HLD score tile in QGIS status bar (research_toolbar_ux 2026-04-28).
        # DEV ONLY — it polls a C:/Temp/hld_score.json every 30s; on a teammate
        # machine that file never exists, so it's a dead tile + a perpetual timer.
        if self._is_dev_mode():
            try:
                self._install_hld_score_tile()
            except Exception as e:
                print(f'[FiberNet] HLD score tile install failed: {e}')
        # Command palette — Ctrl+Shift+P fuzzy-finder for every plugin action
        try:
            self._install_command_palette()
        except Exception as e:
            print(f'[FiberNet] Command palette install failed: {e}')
        # Native QGIS locator — Ctrl+K, "vf <text>" jumps to a fiber feature
        try:
            self._install_locator_filter()
        except Exception as e:
            print(f'[FiberNet] Locator filter install failed: {e}')
        # Erven Studio — dock + button to detect buildings & tune cadastral erven (sliders + Run)
        try:
            self._install_erven_studio_button()
        except Exception as e:
            print(f'[FiberNet] Erven Studio button install failed: {e}')
        # Velocity Nexus branded home panel — friendly front-end for the main workflow
        try:
            self._install_home_panel()
        except Exception as e:
            print(f'[FiberNet] Home panel install failed: {e}')
        # Account guard — if the planning office deactivated this account, lock
        # the whole tool. Deferred so the panel + profile are fully ready.
        try:
            from qgis.PyQt.QtCore import QTimer as _QTimerAG
            _QTimerAG.singleShot(3000, self._start_account_guard)
        except Exception as e:
            print(f'[FiberNet] account guard schedule failed: {e}')
        # VeloPlan menu — one menu fronting every tool. Deferred so it captures ALL toolbar actions
        # (fibre_automation pipeline + absorbed fibretime actions are added after this point in initGui).
        try:
            from qgis.PyQt.QtCore import QTimer as _QTimer
            _QTimer.singleShot(2500, self._build_menu)
        except Exception as e:
            print(f'[FiberNet] VeloPlan menu schedule failed: {e}')
        # Mirror eye is a Claude dev tool — not installed for planners
        # Wire fibre_automation pipeline steps into STEP_MAP.
        # fibre_automation lives either:
        #   a) inside this plugin's directory (ZIP install — all planners)
        #   b) in the dev workspace (JJ's machine only, as a sibling folder)
        try:
            import sys, os
            plugin_dir = os.path.dirname(__file__)
            # (a) ZIP install: fibre_automation is a sub-package of the plugin dir
            if plugin_dir not in sys.path:
                sys.path.insert(0, plugin_dir)
            # (b) Dev fallback: workspace sibling (only adds if it actually exists)
            _ws = os.path.dirname(plugin_dir)
            if os.path.isdir(os.path.join(_ws, 'fibre_automation')) and _ws not in sys.path:
                sys.path.insert(0, _ws)
            # Evict cached fibre_automation modules so disk is read fresh — DEV
            # ONLY (a live-reload aid). On a teammate it would throw away cached
            # bytecode and force a ~24-module recompile on every plugin load.
            if self._is_dev_mode():
                for _mod in list(sys.modules.keys()):
                    if _mod.startswith('fibre_automation'):
                        del sys.modules[_mod]
            import fibre_automation.plugin_wiring  # noqa: F401
            print('[FiberNet] fibre_automation pipeline wired ✓')
        except Exception as e:
            print(f'[FiberNet] fibre_automation wiring failed: {e}')

        # Restore SESSION from project file on open; clear it on new project
        try:
            from qgis.core import QgsProject
            QgsProject.instance().readProject.connect(self._on_project_read)
            QgsProject.instance().cleared.connect(self._on_project_cleared)
            # Restore from the project that's already open when the plugin loads
            self._on_project_read()
        except Exception as e:
            print(f'[FiberNet] project signal wiring failed: {e}')
        from qgis.PyQt.QtCore import QTimer
        # iface.newProjectCreated fires once during QGIS startup for the initial
        # blank "Untitled Project", then again every time the user does File → New
        # or clicks "New Empty Project".  Skip the first (startup) firing; show the
        # welcome dialog for all subsequent ones.
        self._new_project_count = 0

        def _on_new_project_created():
            self._new_project_count += 1
            if self._new_project_count <= 1:
                return  # startup blank project — ignore
            QTimer.singleShot(300, self._show_welcome_dialog)

        self._on_new_project_created = _on_new_project_created
        try:
            self.iface.newProjectCreated.connect(self._on_new_project_created)
            print('[FiberNet] newProjectCreated wired ✓')
        except Exception as e:
            print(f'[FiberNet] newProjectCreated wiring failed: {e}')
        # Connect to bridge dock client_changed signal (retry if bridge not ready yet)
        if not self._connect_bridge_client_signal():
            QTimer.singleShot(2000, self._connect_bridge_client_signal)
        # fibretime_tools buttons are RETIRED — everything is in the published VeloPlan plugin now
        # (home panel + VeloPlan menu). Do NOT absorb the fibretime_tools toolbar; instead disable
        # that redundant plugin so its toolbar never appears. (JJ: remove those buttons permanently.)
        self._absorb_attempts = 0
        self._absorb_watchdog = None
        QTimer.singleShot(1200, self._retire_fibretime_tools)
        # UI crash guard: disable drag-reorder on QGIS dock tab bars (prevents a Qt 6.11
        # QTabBar::moveTab access-violation crash) + self-heal the branded toolbar if it
        # was restored collapsed in a corner. Installed immediately + again after the
        # layout settles. Fail-open — never blocks startup.
        try:
            from .ui_crash_guard import install as _install_tab_guard, heal_toolbar as _heal_tb
        except ImportError:
            from ui_crash_guard import install as _install_tab_guard, heal_toolbar as _heal_tb
        mw = self.iface.mainWindow()
        _install_tab_guard(mw)
        # Heal the toolbar at two moments — QGIS restores the saved window layout
        # (which can leave the branded toolbar collapsed/off-window) at slightly
        # different times across machines, so run once early and once after it settles.
        self._ui_heal_timers = []
        for delay, callback in (
                (1500, lambda: (_install_tab_guard(mw), _heal_tb(mw))),
                (4000, lambda: _heal_tb(mw))):
            timer = QTimer(mw)
            timer.setSingleShot(True)
            timer.timeout.connect(callback)
            timer.start(delay)
            self._ui_heal_timers.append(timer)
        # "What's New" popup once per new version after an upgrade (not first install)
        QTimer.singleShot(3200, self._maybe_whats_new)
        # If locked, make activation impossible to miss: auto-popup + Home-panel card.
        # Deferred so the menu + home panel exist first.
        QTimer.singleShot(2900, self._prompt_activation_if_locked)
        # Register processing algorithms last so a crash above doesn't create a
        # zombie "fibernetwork" entry in the C++ registry (unload() can't remove
        # it once the C++ object is deleted by QGIS's exception-path cleanup).
        # Activation-gated: an unactivated machine gets NO algorithms either —
        # _apply_activation_gate registers the provider after a successful unlock.
        try:
            try:
                from . import activation as _act
            except ImportError:
                import activation as _act
            _gate_ok = _act.is_activated()
        except Exception:
            _gate_ok = True   # never let a gate bug brick the plugin for the team
        if _gate_ok:
            self.initProcessing()
        else:
            print('[FiberNet] not activated — processing provider withheld')

    # ── Dev vs team mode ─────────────────────────────────────────────────────
    def _is_dev_mode(self):
        """True only on JJ's machine. Dev-only buttons (Run q.py, AI server
        detect, git-pull Update, Canvas snapshot, Mirror Eye, Bridge status)
        are shown ONLY in dev mode; teammates never see them.

        Dev = the QGIS Bridge plugin is LOADED/active (Claude's control channel,
        which teammates don't run) OR the VF_DEV env var is set."""
        cached = getattr(self, '_dev_mode_cached', None)
        if cached is not None:
            return cached
        dev = bool(os.environ.get('VF_DEV'))
        if not dev:
            try:
                import qgis.utils as _qu
                # LOADED, not merely installed/available: a teammate who only has
                # the QGIS Bridge plugin present (disabled) must NOT get dev tools.
                # JJ always runs it loaded (Claude's control channel), so he stays dev.
                dev = 'QGISBridgePlugin' in getattr(_qu, 'plugins', {})
            except Exception:
                dev = False
        self._dev_mode_cached = dev
        print(f"[FiberNet] mode: {'DEV (JJ)' if dev else 'TEAM'}")
        return dev

    # ── Toolbar builder ──────────────────────────────────────────────────────
    def _build_toolbar(self):
        tb = self._toolbar
        dev = self._is_dev_mode()
        # Group spec entries by group id, preserving spec order.
        # In team mode, drop every dev-only entry (client == "dev").
        groups = OrderedDict((g, []) for g in GROUPS)
        for entry in TOOLBAR_SPEC:
            if entry.get("client") == "dev" and not dev:
                continue
            groups[entry["group"]].append(entry)

        for gid, entries in groups.items():
            meta = GROUPS[gid]
            if meta["kind"] == "menu":
                btn = QToolButton(tb)
                btn.setText(meta["title"])
                btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
                btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
                if meta.get("tooltip"):
                    btn.setToolTip(meta["tooltip"])
                menu = QMenu(btn)
                menu.setToolTipsVisible(True)   # show per-item tooltips
                menu.setStyleSheet(
                    f"QMenu {{ background: {_PANEL}; color: {_TEXT};"
                    f" border: 1px solid {_BORDER}; padding: 4px; }}"
                    f"QMenu::item {{ padding: 5px 18px; border-radius: 3px; }}"
                    f"QMenu::item:selected {{ background: {_ACCENT}; color: {_BG}; }}"
                    f"QMenu::item:disabled {{ color: {_DIM}; background: transparent; }}"
                    f"QMenu::separator {{ height: 1px; background: {_BORDER}; margin: 4px 8px; }}"
                )
                for e in entries:
                    if e["kind"] == "separator":
                        menu.addSeparator()
                    elif e["kind"] == "header":
                        # Non-clickable header — styled as grey italic label
                        hdr = QAction(e["label"], menu)
                        hdr.setEnabled(False)
                        f = hdr.font()
                        f.setItalic(True); f.setBold(True); f.setPointSize(8)
                        hdr.setFont(f)
                        menu.addAction(hdr)
                    else:
                        menu.addAction(self._make_action(e))
                btn.setMenu(menu)
                grp_act = tb.addWidget(btn)
                self._group_btns[gid] = btn
                self._group_acts[gid] = grp_act
            else:  # inline
                for e in entries:
                    if e["kind"] == "brand":
                        if dev:
                            tb.addWidget(self._make_brand_tile())
                        else:
                            tb.addWidget(self._make_static_logo())
                    else:
                        act = self._make_action(e)
                        tb.addAction(act)
                        btn = tb.widgetForAction(act)
                        if btn is not None:
                            eid = e.get("id", "")
                            # Client-selector buttons: large, branded, text-beside-icon
                            if eid == 'select_vuma':
                                btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
                                btn.setStyleSheet(_VUMA_BTN_QSS)
                            elif eid == 'select_ft':
                                btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
                                btn.setStyleSheet(_FT_BTN_QSS)
                            # Other named tool buttons also get text beside icon
                            elif eid in ("enc_editor", "pole_editor", "canvas",
                                         "route_viewer"):
                                btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)

        # Admin-only: a dedicated Team Monitor button on the toolbar (the
        # planning office / JJ). Shown ONLY when the owner read-key is present,
        # so teammates never see it. One click opens the live monitor.
        try:
            nx = getattr(self, '_nexus', None)
            if nx is not None and nx.is_admin():
                tb.addSeparator()
                mon_btn = QToolButton(tb)
                mon_btn.setText('🛰  Team Monitor')
                mon_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
                mon_btn.setCursor(Qt.CursorShape.PointingHandCursor)
                mon_btn.setToolTip('Live team activity — who is online and what '
                                   'they are doing right now (admin only)')
                mon_btn.setStyleSheet(
                    "QToolButton{background:#F5A623;color:#1A1206;border:none;"
                    "border-radius:6px;padding:5px 12px;font-weight:700;}"
                    "QToolButton:hover{background:#ffbe4d;}")
                mon_btn.clicked.connect(self._open_team_monitor)
                tb.addWidget(mon_btn)
                self._admin_monitor_btn = mon_btn
        except Exception:
            pass

        # Default state: no client chosen → show only brand + Setup Project
        self._update_toolbar_for_client(None)

    def _open_team_monitor(self, *args):
        """Toolbar handler — open/raise the JJ-only Team Monitor dock."""
        try:
            nx = getattr(self, '_nexus', None)
            if nx is not None:
                nx.open_team_monitor()
        except Exception:
            pass

    def _icon(self, path):
        return QgsApplication.getThemeIcon(path) if path else QIcon()

    def _make_action(self, e):
        act = QAction(self._icon(e.get("icon", "")), e["label"],
                      self.iface.mainWindow())
        if "tooltip" in e:
            act.setToolTip(e["tooltip"])
            act.setWhatsThis(e["tooltip"])
        act.setEnabled(e.get("enabled", True))
        # 2026-04-28: keyboard shortcuts per research_toolbar_ux_redesign_2026-04-28.md
        # (ft_all/Ctrl+Shift+F removed — redundant with the ⚡ Run FT 1..7 button
        #  in the Build FT 1-7 dropdown.)
        # 2026-07-13 shortcut audit: Ctrl+Shift+A/S/U/C collided with QGIS core
        # (Deselect Features / Save Project As / Show All Layers / Set CRS).
        # As ApplicationShortcuts those were AMBIGUOUS — Qt fired neither, so we
        # were quietly breaking core QGIS shortcuts. Moved to free Ctrl+Alt
        # combos. FT digit shortcuts + pole_editor/run_q had no conflict.
        SHORTCUTS = {
            'ft1':           'Ctrl+1', 'ft2': 'Ctrl+2', 'ft3': 'Ctrl+3',
            'ft4':           'Ctrl+4', 'ft4b':'Ctrl+5', 'ft5': 'Ctrl+6',
            'ft6':           'Ctrl+7', 'ft7': 'Ctrl+8',
            'audit_hld':     'Ctrl+Alt+D',
            'span_check':    'Ctrl+Alt+S',
            'update_layers': 'Ctrl+Alt+U',
            'pole_editor':   'Ctrl+Shift+E',
            'run_q':         'Ctrl+Shift+Q',
            'canvas':        'Ctrl+Alt+C',
        }
        if e["id"] in SHORTCUTS:
            act.setShortcut(SHORTCUTS[e["id"]])
            act.setShortcutContext(Qt.ShortcutContext.ApplicationShortcut)
            # Annotate tooltip with the shortcut so the user discovers it
            cur = act.toolTip() or e.get("label", "")
            act.setToolTip(f"{cur}  ({SHORTCUTS[e['id']]})")

        # route toolbar handlers through the friendly report flow, like the menu
        # path — a crash becomes a logged "Report a Problem" nudge, not a raw
        # traceback dumped on a teammate.
        try:
            try:
                from . import error_reporter as _er
            except ImportError:
                import error_reporter as _er
        except Exception:
            _er = None

        def _wire(cb):
            return _er.guard(self.iface, e["label"], cb) if _er else cb

        kind = e["kind"]
        if kind == "callback":
            act.triggered.connect(_wire(getattr(self, e["callback"])))
        elif kind == "action":
            # plain action with optional callback (used for stubs)
            if "callback" in e:
                act.triggered.connect(_wire(getattr(self, e["callback"])))
        elif kind == "algo":
            algo_id = e["algorithm"]
            eid = e["id"]
            act.triggered.connect(
                lambda _=False, a=algo_id, i=eid: self._run_algo(a, i))
        elif kind == "script":
            spath = e["script"]
            eid = e["id"]
            act.triggered.connect(
                lambda _=False, s=spath, i=eid: self._run_script(s, i))
        elif kind == "macro":
            act.triggered.connect(getattr(self, e["callback"]))

        self._actions[e["id"]] = act
        return act

    def _make_static_logo(self):
        """Team-mode toolbar identity: the RED-KNIGHT Velocity Nexus mark — no bridge
        status, no dev tools, not clickable. Rendered from the bundled icon.png IMAGE
        (not a font glyph) so it looks IDENTICAL on every teammate's machine; the old
        path drew the legacy 'V-mark' via branding.vf_style, which is why teammates
        kept seeing the old logo even on the newest version."""
        import os
        from qgis.PyQt.QtWidgets import QLabel, QHBoxLayout
        from qgis.PyQt.QtGui import QPixmap
        from qgis.PyQt.QtCore import Qt
        cont = QWidget()
        lay = QHBoxLayout(cont)
        lay.setContentsMargins(6, 0, 10, 0)
        lay.setSpacing(6)
        mark = QLabel()
        _logo = os.path.join(os.path.dirname(__file__), 'icon.png')
        _pm = QPixmap(_logo) if os.path.exists(_logo) else QPixmap()
        if not _pm.isNull():
            mark.setPixmap(_pm.scaledToHeight(
                22, Qt.TransformationMode.SmoothTransformation))
        else:
            # last-resort fallback only if the image is missing
            mark.setText('♞')
            mark.setStyleSheet(f'color:{theme_safe.colors()["bad"]}; font-weight:800; font-size:16px;')
        word = QLabel('Velocity Nexus')
        word.setStyleSheet(f'color: {_TEXT}; font-weight: 700; font-family:"Segoe UI";')
        lay.addWidget(mark)
        lay.addWidget(word)
        cont.setToolTip('Velocity Nexus')
        return cont

    def _make_brand_tile(self):
        """Clickable container: [VF badge] + [Bridge status label].
        Click → opens the VeloGIS Bridge dock widget."""

        class ClickableBrand(QWidget):
            def __init__(self, plugin):
                super().__init__()
                self._plugin = plugin
                self.setCursor(Qt.CursorShape.PointingHandCursor)
            def mousePressEvent(self, ev):
                self._plugin._open_bridge_dock()
                super().mousePressEvent(ev)

        container = ClickableBrand(self)
        layout = QHBoxLayout(container)
        layout.setContentsMargins(2, 0, 6, 0)
        layout.setSpacing(6)

        # Brand mark = the red knight chess piece (♞), replacing the old VF badge.
        # The status border (green/red) is driven by the bridge poller.
        badge = QLabel("♞")
        badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        badge.setMinimumWidth(28)
        badge.setStyleSheet(
            f"QLabel {{ background: #0D1320; color: #EF4444;"
            f" font-family:'Segoe UI Symbol','Segoe UI'; font-weight:800;"
            f" font-size:17px;"
            f" border: 2px solid {_DIM}; border-radius: 4px;"
            f" padding: 1px 7px; }}")
        self._brand_label = badge

        status = QLabel("Bridge …")
        status.setStyleSheet(
            f"QLabel {{ color: {_DIM}; font-family:'Segoe UI';"
            f" font-size:10px; font-weight:600; padding: 2px 4px; }}")
        self._brand_status = status

        layout.addWidget(badge)
        layout.addWidget(status)
        container.setToolTip("VelocityFibre  •  Click to open Bridge dock")
        return container

    # ── HLD score tile (status-bar widget) ───────────────────────────────────
    def _install_hld_score_tile(self):
        """Permanent QStatusBar widget showing live HLD pre-flight score.
        Reads C:/Temp/hld_score.json (written by hld_audit_writer.py)."""
        from qgis.PyQt.QtWidgets import QPushButton
        from qgis.PyQt.QtCore import QTimer
        # Defensive cleanup: remove any orphan tiles left by an unclean prior
        # shutdown. Match by objectName OR by text starting with "HLD:" so we
        # catch tiles created before the objectName patch.
        # NO QApplication.processEvents() — that caused re-entrance / freeze
        # 2026-04-28. setParent(None) + hide() are synchronous enough.
        try:
            mw = self.iface.mainWindow()
            sb = mw.statusBar()
            victims = []
            for child in mw.findChildren(QPushButton):
                if child.objectName() == 'FNAHLDScoreTile' or \
                   (child.text() or '').startswith('HLD:'):
                    victims.append(child)
            for child in victims:
                try:
                    sb.removeWidget(child)
                except Exception:
                    pass
                try:
                    child.setParent(None)  # synchronous detach from layout
                except Exception:
                    pass
                try:
                    child.hide()
                except Exception:
                    pass
                child.deleteLater()
        except Exception:
            pass
        tile = QPushButton("HLD: —")
        tile.setObjectName('FNAHLDScoreTile')
        tile.setFlat(True)
        tile.setCursor(Qt.CursorShape.PointingHandCursor)
        tile.setStyleSheet(
            "QPushButton { color:#A0A4BC; padding:0 10px; font-weight:600;"
            " font-family:'Segoe UI'; font-size:11px; border:none; }"
            "QPushButton:hover { color:#E6E8F0; background:#3A3D5C; border-radius:4px; }"
        )
        tile.clicked.connect(self._refresh_hld_score)
        # First read
        self._hld_score_tile = tile
        self._refresh_hld_score_display()
        # Auto-refresh every 30s
        self._hld_timer = QTimer(self.iface.mainWindow())
        self._hld_timer.setInterval(30_000)
        self._hld_timer.timeout.connect(self._refresh_hld_score_display)
        self._hld_timer.start()
        # Add to status bar
        try:
            sb = self.iface.statusBarIface()
            sb.addPermanentWidget(tile, 0)
        except Exception:
            pass  # status bar API quirks — non-fatal

    def _refresh_hld_score_display(self):
        """Reads JSON, updates the tile label + colour. Does NOT run audit."""
        import json, os
        # Widget may have been deleted (deleteLater) between timer fire and
        # actual C++ destruction — catch the sip RuntimeError and self-clean.
        try:
            tile = self._hld_score_tile
            if tile is None:
                return
            path = 'C:/Temp/hld_score.json'
            if not os.path.exists(path):
                tile.setText("HLD: —")
                return
            try:
                with open(path, encoding='utf8') as f:
                    d = json.load(f)
            except Exception:
                return
            p = d.get('pass', 0); fa = d.get('fail', 0); n = d.get('note', 0)
            if fa == 0 and n == 0:
                color = "#16A34A"
            elif fa == 0:
                color = "#F59E0B"
            else:
                color = "#DC2626"
            tile.setText(f"HLD: {p}✓  {fa}✗  {n}!")
            tile.setStyleSheet(
                f"QPushButton {{ color:{color}; padding:0 10px; font-weight:700;"
                f" font-family:'Segoe UI'; font-size:11px; border:none; }}"
                f"QPushButton:hover {{ background:#3A3D5C; border-radius:4px; }}"
            )
            tile.setToolTip(
                f"Last audit: {d.get('ts','?')[:19]}\n"
                f"PASS: {p} · FAIL: {fa} · NOTE: {n}\n"
                "Click to re-run audit."
            )
        except RuntimeError:
            # C++ object already destroyed — stop the timer so it won't fire again
            try:
                if getattr(self, '_hld_timer', None):
                    self._hld_timer.stop()
            except RuntimeError:
                pass
            self._hld_score_tile = None

    def _refresh_hld_score(self):
        """Click handler — re-runs the audit script in-process.

        IMPORTANT: previously called the bridge via urllib.urlopen which
        deadlocked Qt main thread (bridge queue is processed on same
        thread → caused QGIS freeze + soft crash 2026-04-28).

        Now we just exec() the audit script directly since we're already
        inside QGIS. No HTTP, no thread, no deadlock.
        """
        from qgis.PyQt.QtWidgets import QApplication
        # Reentrancy guard: processEvents() below pumps the event loop, which can
        # deliver a queued clicked() and re-enter this handler (re-runs the audit
        # twice on the main thread / clobbers ns). Bail if already refreshing.
        if getattr(self, '_hld_refreshing', False):
            return
        self._hld_refreshing = True
        try:
            self.iface.messageBar().pushInfo("HLD score", "Refreshing…")
            QApplication.processEvents()
            with open('C:/Temp/hld_audit_writer.py', encoding='utf8') as f:
                code = f.read()
            # Run in a fresh namespace so we don't pollute plugin globals
            ns = {'__name__': '__hld_audit__'}
            exec(code, ns)
            self._refresh_hld_score_display()
            self.iface.messageBar().pushSuccess(
                "HLD score", "Audit refreshed — see status bar")
        except FileNotFoundError:
            self.iface.messageBar().pushWarning(
                "HLD score", "C:/Temp/hld_audit_writer.py not found")
        except Exception as e:
            self.iface.messageBar().pushWarning(
                "HLD score", f"refresh failed: {type(e).__name__}: {e}")
        finally:
            self._hld_refreshing = False

    # ── Cost estimator ────────────────────────────────────────────────────────
    def _run_cost_estimator(self):
        """Open the transparent CAPEX / cost-per-home estimator."""
        try:
            from . import cost_estimator
        except ImportError:
            import cost_estimator
        cost_estimator.open_dialog(self.iface)

    # ── HLD client PDF ────────────────────────────────────────────────────────
    def _run_hld_pdf(self):
        """Generate the client HLD PDF. Gathers CHEAP data (featureCount + light
        scorecard — no heavy iteration), then builds the PDF in the venv
        subprocess (reportlab) so the QGIS UI never blocks."""
        import os
        import json
        import time
        import datetime
        import subprocess
        from qgis.core import QgsProject, QgsMapLayer
        from qgis.PyQt.QtWidgets import QFileDialog
        from qgis.PyQt.QtCore import Qt

        proj = QgsProject.instance()
        layers = list(proj.mapLayers().values())

        def count(*keys, mode='sum'):
            vals = [l.featureCount() for l in layers
                    if l.type() == QgsMapLayer.LayerType.VectorLayer
                    and any(k in l.name().lower() for k in keys)]
            if not vals:
                return 0
            return max(vals) if mode == 'max' else sum(vals)

        poles = count('pole')
        erven = count('erven', 'erf', mode='max')
        onts = count('ont', 'home connection', mode='max')
        splitters = count('splitter')
        pons = count('pon v1', 'pon zones', mode='max') or count(' pon', mode='max')
        zones = count('zone')
        stats = {'Poles': poles, 'Erven': erven, 'ONTs / homes': onts,
                 'Splitters': splitters, 'PONs': pons, 'Zones': zones}
        # lightweight, honest scorecard — presence/counts (instant), not the full audit
        audit = []
        for label, n in (('Poles', poles), ('Erven', erven), ('ONTs', onts),
                         ('Splitters', splitters)):
            audit.append((label, 'pass' if n > 0 else 'warn',
                          f'{n:,} features' if n > 0 else 'layer absent / empty'))
        try:
            from . import power_budget as pb
            audit.append(('Optical reach (Combo-1, C+)', 'pass',
                          f'max ~{pb.max_reach_km():.0f} km — design ONTs within this'))
        except Exception:
            pass

        data = {
            'project': proj.baseName() or 'project',
            'client': '', 'date': datetime.date.fromtimestamp(time.time()).isoformat(),
            'stats': stats,
            'capacity': {'onts': onts, 'pons': pons, 'zones': zones, 'fill': '80–102'},
            'audit': audit,
        }
        out, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 'Save HLD report',
            f'C:/Temp/HLD_{data["project"]}.pdf', 'PDF (*.pdf)')
        if not out:
            return
        djson = 'C:/Temp/hld_data.json'
        with open(djson, 'w', encoding='utf-8') as _f:
            json.dump(data, _f)

        try:
            from .fibre_automation.shared.vf_paths import python_exe
        except ImportError:
            from fibre_automation.shared.vf_paths import python_exe
        py = python_exe()
        runner = os.path.join(os.path.dirname(__file__), 'fibre_automation', 'hld_report_runner.py')

        from qgis.PyQt.QtWidgets import QApplication
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            r = subprocess.run([py, runner, djson, out], capture_output=True,
                               text=True, timeout=120)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            self.iface.messageBar().pushWarning('HLD Report', f'Build failed: {str(e)[:160]}')
            return
        QApplication.restoreOverrideCursor()
        if r.returncode == 0 and os.path.exists(out):
            self.iface.messageBar().pushSuccess('HLD Report', f'Client HLD PDF ready → {out}')
            try:
                os.startfile(out)   # open in the default PDF viewer
            except Exception:
                pass
        else:
            self.iface.messageBar().pushWarning(
                'HLD Report', f'Build failed: {(r.stderr or r.stdout or "")[:200]}')

    # ── Acceptance Scorecard (client-signable PDF) ────────────────────────────
    def _run_acceptance_scorecard(self):
        """Score the finished HLD against the Phase-2 spec and render a
        client-signable certificate. The score is built from the live layers
        (FREEZE-SAFE single pass via acceptance_scorecard); the PDF is rendered
        in the venv subprocess (reportlab) so the QGIS UI never blocks."""
        import os
        import json
        import time
        import datetime
        import subprocess
        from qgis.PyQt.QtWidgets import QFileDialog, QApplication
        from qgis.PyQt.QtCore import Qt

        try:
            from . import acceptance_scorecard as asc
        except ImportError:
            import acceptance_scorecard as asc
        try:
            data = asc.build_scorecard()
        except Exception as e:
            self.iface.messageBar().pushWarning(
                'Acceptance Scorecard', f'Could not score project: {str(e)[:160]}')
            return
        data['date'] = datetime.date.fromtimestamp(time.time()).isoformat()

        out, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 'Save acceptance certificate',
            f'C:/Temp/Acceptance_{data.get("project", "project")}.pdf', 'PDF (*.pdf)')
        if not out:
            return
        djson = 'C:/Temp/scorecard_data.json'
        with open(djson, 'w', encoding='utf-8') as _f:
            json.dump(data, _f)

        try:
            from .fibre_automation.shared.vf_paths import python_exe
        except ImportError:
            from fibre_automation.shared.vf_paths import python_exe
        py = python_exe()
        runner = os.path.join(os.path.dirname(__file__), 'acceptance_scorecard_pdf.py')

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            r = subprocess.run([py, runner, djson, out], capture_output=True,
                               text=True, timeout=120)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            self.iface.messageBar().pushWarning(
                'Acceptance Scorecard', f'Build failed: {str(e)[:160]}')
            return
        QApplication.restoreOverrideCursor()
        if r.returncode == 0 and os.path.exists(out):
            self.iface.messageBar().pushSuccess(
                'Acceptance Scorecard',
                f'{data.get("verdict", "?")} · {data.get("overall", "?")}/100 → {out}')
            try:
                os.startfile(out)
            except Exception:
                pass
        else:
            self.iface.messageBar().pushWarning(
                'Acceptance Scorecard',
                f'Build failed: {(r.stderr or r.stdout or "")[:200]}')

    # ── Pole schedule (field CSV) ─────────────────────────────────────────────
    def _run_pole_schedule(self):
        """Export a GPS pole schedule CSV for field crews. Bounded iteration
        (guarded against huge layers) + WGS84 lat/lon. Read-only on the data."""
        import csv
        from qgis.core import (QgsProject, QgsMapLayer, QgsWkbTypes,
                               QgsCoordinateTransform, QgsCoordinateReferenceSystem)
        from qgis.PyQt.QtWidgets import QFileDialog

        poles = None
        for l in QgsProject.instance().mapLayers().values():
            if (l.type() == QgsMapLayer.LayerType.VectorLayer
                    and l.geometryType() == QgsWkbTypes.GeometryType.PointGeometry
                    and 'pole' in l.name().lower()):
                poles = l
                break
        if poles is None:
            self.iface.messageBar().pushWarning('Pole Schedule', 'No Poles layer found.')
            return
        n = poles.featureCount()
        if n > 100000:
            self.iface.messageBar().pushWarning('Pole Schedule', f'{n:,} poles — too many to export safely.')
            return

        fields = [f.name() for f in poles.fields()]
        def pick(*cands):
            return next((f for f in fields if f.lower() in cands), None)
        f_lbl = pick('label', 'label_1', 'name')
        f_dim = pick('dim2', 'thickness', 'thickness_')
        f_typ = pick('type_1', 'type', 'spec_1')

        path, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 'Save pole schedule',
            f'C:/Temp/pole_schedule_{QgsProject.instance().baseName() or "project"}.csv',
            'CSV (*.csv)')
        if not path:
            return
        xform = QgsCoordinateTransform(poles.crs(),
                                       QgsCoordinateReferenceSystem('EPSG:4326'),
                                       QgsProject.instance())
        written = 0
        try:
            with open(path, 'w', newline='', encoding='utf-8') as fh:
                w = csv.writer(fh)
                w.writerow(['label', 'lat', 'lon', 'thickness', 'type'])
                for ft in poles.getFeatures():
                    g = ft.geometry()
                    if not g or g.isEmpty():
                        continue
                    p = g.centroid().asPoint()
                    p = xform.transform(p)
                    w.writerow([
                        ft[f_lbl] if f_lbl else '',
                        f'{p.y():.6f}', f'{p.x():.6f}',
                        ft[f_dim] if f_dim else '',
                        ft[f_typ] if f_typ else '',
                    ])
                    written += 1
        except Exception as e:
            self.iface.messageBar().pushWarning('Pole Schedule', f'Export failed: {str(e)[:160]}')
            return
        self.iface.messageBar().pushSuccess('Pole Schedule', f'Exported {written:,} poles → {path}')

    # ── shared export helpers ─────────────────────────────────────────────────
    @staticmethod
    def _default_export_path(ext):
        """Suggested save path: NEXT TO THE PROJECT, not C:/Temp.

        Exports belong with the .qgz the planner is working in — hunting for a KMZ
        that silently landed in C:/Temp wastes real time. Falls back to C:/Temp only
        for an unsaved project, which has no folder of its own yet.
        """
        import os
        from qgis.core import QgsProject
        proj = QgsProject.instance()
        base = proj.baseName() or "network"
        folder = proj.absolutePath() or ""       # "" while the project is unsaved
        if not folder or not os.path.isdir(folder):
            folder = "C:/Temp"
        return os.path.join(folder, f"{base}.{ext}").replace("\\", "/")

    # ── shared layer picker (used by the export buttons) ──────────────────────
    def _pick_layers(self, title, preselect='visible', parent=None, checked_ids=None):
        """Modal checklist of the project's vector layers → list[layer] | None.

        None means the operator cancelled — the caller must write nothing.
        Rows follow Layers-panel order so what you see here matches the panel.
        preselect='visible' pre-ticks the currently-ticked layers.
        checked_ids overrides preselect (used to re-open with the previous choice).
        parent: pass the calling dialog when opening from inside another modal.

        Reusable on purpose: Export KMZ and Export KML both use it; Export DXF and
        Export GeoPackage carry the same "visible layers" assumption and can adopt
        it with a one-line change.

        Qt6 notes: item data holds the layer ID (a string), never the layer object —
        a held C++ pointer can dangle. The dialog is WA_DeleteOnClose, so the ticks
        are captured in the accept handler, BEFORE exec() returns and the widgets die.
        """
        from qgis.core import QgsProject, QgsMapLayer
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                                         QListWidget, QListWidgetItem, QPushButton,
                                         QDialogButtonBox)

        root = QgsProject.instance().layerTreeRoot()
        nodes = [n for n in root.findLayers()
                 if n.layer() is not None
                 and n.layer().type() == QgsMapLayer.LayerType.VectorLayer]
        if not nodes:
            self.iface.messageBar().pushWarning(
                title, 'This project has no vector layers to export.')
            return None

        dlg = QDialog(parent or self.iface.mainWindow())
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        dlg.setWindowTitle(f'{title} — choose layers')
        dlg.setMinimumWidth(430)
        dlg.setStyleSheet(
            "QDialog { background:#1A1B26; }"
            "QLabel { color:#E6E8F0; font-family:'Segoe UI'; font-size:12px; }"
            "QListWidget { background:#11131F; color:#E6E8F0; border:1px solid #3A3D5C;"
            "  border-radius:6px; font-family:'Segoe UI'; font-size:12px; padding:3px; }"
            "QListWidget::item { padding:5px 6px; }"
            "QListWidget::item:hover { background:#24253A; }"
            "QPushButton { background:#24253A; color:#E6E8F0; border:1px solid #3A3D5C;"
            "  border-radius:5px; padding:5px 13px; font-family:'Segoe UI'; font-size:12px; }"
            "QPushButton:hover { background:#3A3D5C; }"
            "QPushButton:default { background:#6E56CF; border:1px solid #6E56CF; }"
        )
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(12, 12, 12, 12)
        lay.setSpacing(8)
        lay.addWidget(QLabel('Tick the layers to include:'))

        listw = QListWidget()
        listw.setMaximumHeight(340)
        for n in nodes:
            lyr = n.layer()
            try:
                cnt = lyr.featureCount()
            except Exception:
                cnt = -1
            cnt_txt = f'{cnt:,}' if cnt is not None and cnt >= 0 else '?'
            it = QListWidgetItem(f'{lyr.name()}   ({cnt_txt})')
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            if checked_ids is not None:
                on = lyr.id() in checked_ids
            else:
                on = n.isVisible() if preselect == 'visible' else True
            it.setCheckState(Qt.CheckState.Checked if on else Qt.CheckState.Unchecked)
            it.setData(Qt.ItemDataRole.UserRole, lyr.id())   # ID, not the layer object
            listw.addItem(it)
        lay.addWidget(listw)

        tally = QLabel('')
        lay.addWidget(tally)

        def _checked_items():
            return [listw.item(i) for i in range(listw.count())
                    if listw.item(i).checkState() == Qt.CheckState.Checked]

        def _retally(*_):
            sel = _checked_items()
            feats = 0
            for it_ in sel:
                lyr_ = QgsProject.instance().mapLayer(it_.data(Qt.ItemDataRole.UserRole))
                if lyr_ is not None:
                    try:
                        c = lyr_.featureCount()
                        if c and c > 0:
                            feats += c
                    except Exception:
                        pass
            tally.setText(f'{len(sel)} of {listw.count()} layers · ~{feats:,} features')
            ok_btn = box.button(QDialogButtonBox.StandardButton.Ok)
            if ok_btn is not None:
                ok_btn.setEnabled(bool(sel))

        def _set_all(state):
            for i in range(listw.count()):
                listw.item(i).setCheckState(state)

        row = QHBoxLayout()
        b_all = QPushButton('All')
        b_none = QPushButton('None')
        b_vis = QPushButton('Visible')
        b_all.clicked.connect(lambda: _set_all(Qt.CheckState.Checked))
        b_none.clicked.connect(lambda: _set_all(Qt.CheckState.Unchecked))

        def _reset_visible():
            for i in range(listw.count()):
                it_ = listw.item(i)
                vis = nodes[i].isVisible()
                it_.setCheckState(Qt.CheckState.Checked if vis else Qt.CheckState.Unchecked)
        b_vis.clicked.connect(_reset_visible)
        for b in (b_all, b_none, b_vis):
            row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)

        box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                               | QDialogButtonBox.StandardButton.Cancel)
        ok = box.button(QDialogButtonBox.StandardButton.Ok)
        ok.setText('Export')
        ok.setDefault(True)
        box.rejected.connect(dlg.reject)
        lay.addWidget(box)

        listw.itemChanged.connect(_retally)
        _retally()

        # Capture BEFORE exec() returns — WA_DeleteOnClose destroys the widgets on accept.
        picked = {}

        def _capture():
            picked['ids'] = [it_.data(Qt.ItemDataRole.UserRole) for it_ in _checked_items()]
            dlg.accept()
        box.accepted.connect(_capture)

        try:
            from .nexus_dock import chrome_dialog
            chrome_dialog(dlg)
        except Exception:
            pass
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return None
        ids = picked.get('ids') or []
        # Resolve IDs -> layers now; skip anything removed while the dialog was open.
        layers = [QgsProject.instance().mapLayer(i) for i in ids]
        return [lyr for lyr in layers if lyr is not None] or None

    # ── KMZ layer + label-field picker ────────────────────────────────────────
    def _pick_layers_kmz(self, title='Export KMZ'):
        """Like _pick_layers, but adds a per-layer 'Label' chooser so the operator
        decides which attribute field shows as each feature's name in Google Earth.

        Returns (layers, name_fields) where name_fields = {layer_id: choice}; choice
        is a field name, '' (no label) or '__auto__' (the smart auto-pick). Returns
        (None, None) if cancelled or nothing ticked.

        Qt6-safe: widgets hold the layer ID (never the C++ object); ticks AND combo
        choices are captured in the accept handler BEFORE exec() returns and the
        WA_DeleteOnClose widgets die (the past dangling-widget bug)."""
        from qgis.core import QgsProject, QgsMapLayer
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                                         QTableWidget, QTableWidgetItem, QComboBox,
                                         QPushButton, QDialogButtonBox, QHeaderView)

        root = QgsProject.instance().layerTreeRoot()
        nodes = [n for n in root.findLayers()
                 if n.layer() is not None
                 and n.layer().type() == QgsMapLayer.LayerType.VectorLayer]
        if not nodes:
            self.iface.messageBar().pushWarning(
                title, 'This project has no vector layers to export.')
            return None, None

        # auto-pick helper (shows the operator which field "Auto" will use)
        try:
            from .fibre_automation.kmz_export import _name_field as _auto_name
        except ImportError:
            try:
                from fibre_automation.kmz_export import _name_field as _auto_name
            except Exception:
                _auto_name = lambda _l: None
        except Exception:
            _auto_name = lambda _l: None

        dlg = QDialog(self.iface.mainWindow())
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        dlg.setWindowTitle(f'{title} — choose layers & labels')
        dlg.setMinimumWidth(520)
        dlg.setStyleSheet(
            "QDialog { background:#1A1B26; }"
            "QLabel { color:#E6E8F0; font-family:'Segoe UI'; font-size:12px; }"
            "QTableWidget { background:#11131F; color:#E6E8F0; border:1px solid #3A3D5C;"
            "  border-radius:6px; font-family:'Segoe UI'; font-size:12px;"
            "  gridline-color:#24253A; }"
            "QTableWidget::item { padding:4px 6px; }"
            "QHeaderView::section { background:#24253A; color:#B7BCE0; border:none;"
            "  padding:5px 6px; font-family:'Segoe UI'; font-size:11px; }"
            "QComboBox { background:#181A28; color:#E6E8F0; border:1px solid #3A3D5C;"
            "  border-radius:4px; padding:2px 6px; font-family:'Segoe UI'; font-size:12px; }"
            "QComboBox QAbstractItemView { background:#11131F; color:#E6E8F0;"
            "  selection-background-color:#3A3D5C; }"
            "QPushButton { background:#24253A; color:#E6E8F0; border:1px solid #3A3D5C;"
            "  border-radius:5px; padding:5px 13px; font-family:'Segoe UI'; font-size:12px; }"
            "QPushButton:hover { background:#3A3D5C; }"
            "QPushButton:default { background:#6E56CF; border:1px solid #6E56CF; }"
        )
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(12, 12, 12, 12)
        lay.setSpacing(8)
        lay.addWidget(QLabel('Tick the layers to include, and pick the field to '
                             'label each with in Google Earth:'))

        tbl = QTableWidget(len(nodes), 2)
        tbl.setHorizontalHeaderLabels(['Layer', 'Label field'])
        tbl.verticalHeader().setVisible(False)
        tbl.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
        tbl.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        tbl.setMaximumHeight(360)
        hdr = tbl.horizontalHeader()
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        hdr.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        tbl.setColumnWidth(1, 190)

        combos = {}          # row -> QComboBox
        for r, n in enumerate(nodes):
            lyr = n.layer()
            try:
                cnt = lyr.featureCount()
            except Exception:
                cnt = -1
            cnt_txt = f'{cnt:,}' if cnt is not None and cnt >= 0 else '?'
            it = QTableWidgetItem(f'{lyr.name()}   ({cnt_txt})')
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(Qt.CheckState.Checked if n.isVisible()
                             else Qt.CheckState.Unchecked)
            it.setData(Qt.ItemDataRole.UserRole, lyr.id())
            tbl.setItem(r, 0, it)

            cb = QComboBox()
            try:
                auto = _auto_name(lyr)
            except Exception:
                auto = None
            cb.addItem(f'🔤 Auto ({auto})' if auto else '🔤 Auto', '__auto__')
            cb.addItem('— None (no label)', '')
            try:
                for f in lyr.fields():
                    cb.addItem(f.name(), f.name())
            except Exception:
                pass
            cb.setCurrentIndex(0)           # default = Auto
            combos[r] = cb
            tbl.setCellWidget(r, 1, cb)
        lay.addWidget(tbl)

        tally = QLabel('')
        lay.addWidget(tally)

        def _checked_rows():
            return [r for r in range(tbl.rowCount())
                    if tbl.item(r, 0).checkState() == Qt.CheckState.Checked]

        def _retally(*_):
            rows = _checked_rows()
            feats = 0
            for r in rows:
                lyr_ = QgsProject.instance().mapLayer(
                    tbl.item(r, 0).data(Qt.ItemDataRole.UserRole))
                if lyr_ is not None:
                    try:
                        c = lyr_.featureCount()
                        if c and c > 0:
                            feats += c
                    except Exception:
                        pass
            tally.setText(f'{len(rows)} of {tbl.rowCount()} layers · ~{feats:,} features')
            ok_btn = box.button(QDialogButtonBox.StandardButton.Ok)
            if ok_btn is not None:
                ok_btn.setEnabled(bool(rows))

        def _set_all(state):
            for r in range(tbl.rowCount()):
                tbl.item(r, 0).setCheckState(state)

        def _reset_visible():
            for r in range(tbl.rowCount()):
                vis = nodes[r].isVisible()
                tbl.item(r, 0).setCheckState(
                    Qt.CheckState.Checked if vis else Qt.CheckState.Unchecked)

        row = QHBoxLayout()
        b_all, b_none, b_vis = QPushButton('All'), QPushButton('None'), QPushButton('Visible')
        b_all.clicked.connect(lambda: _set_all(Qt.CheckState.Checked))
        b_none.clicked.connect(lambda: _set_all(Qt.CheckState.Unchecked))
        b_vis.clicked.connect(_reset_visible)
        for b in (b_all, b_none, b_vis):
            row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)

        box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                               | QDialogButtonBox.StandardButton.Cancel)
        ok = box.button(QDialogButtonBox.StandardButton.Ok)
        ok.setText('Export')
        ok.setDefault(True)
        box.rejected.connect(dlg.reject)
        lay.addWidget(box)

        tbl.itemChanged.connect(_retally)
        _retally()

        picked = {}

        def _capture():
            ids, nfields = [], {}
            for r in _checked_rows():
                lid = tbl.item(r, 0).data(Qt.ItemDataRole.UserRole)
                ids.append(lid)
                cb = combos.get(r)
                choice = cb.currentData() if cb is not None else '__auto__'
                if choice != '__auto__':           # only record real overrides
                    nfields[lid] = choice
            picked['ids'] = ids
            picked['name_fields'] = nfields
            dlg.accept()
        box.accepted.connect(_capture)

        try:
            from .nexus_dock import chrome_dialog
            chrome_dialog(dlg)
        except Exception:
            pass
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return None, None
        ids = picked.get('ids') or []
        layers = [QgsProject.instance().mapLayer(i) for i in ids]
        layers = [lyr for lyr in layers if lyr is not None]
        if not layers:
            return None, None
        return layers, (picked.get('name_fields') or {})

    # ── KMZ export (Google Earth / field) ─────────────────────────────────────
    def _export_kmz(self):
        """Export chosen vector layers to a KMZ for Google Earth / field phones.

        The operator picks the layers (pre-ticked to whatever is visible) AND, per
        layer, which attribute field shows as the on-map label in Google Earth
        (default = smart auto-pick); every attribute-table field still rides along in
        each Placemark's <ExtendedData>, so a field tech can tap a feature and read
        its full row. Zero-dependency (KML XML + zip); read-only on the data."""
        from qgis.PyQt.QtWidgets import QFileDialog, QApplication
        from qgis.PyQt.QtCore import Qt

        # Ask BEFORE the save dialog, so you never name a file then cancel.
        layers, name_fields = self._pick_layers_kmz('Export KMZ')
        if not layers:
            return          # cancelled, or nothing ticked — write nothing
        path, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 'Export network to KMZ',
            self._default_export_path('kmz'),
            'Google Earth KMZ (*.kmz)')
        if not path:
            return
        try:
            from .fibre_automation.kmz_export import build_kmz
        except ImportError:
            from fibre_automation.kmz_export import build_kmz
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            res = build_kmz(layers, path, name_fields=name_fields)
        except Exception as e:
            self.iface.messageBar().pushWarning('Export KMZ', f'Export failed: {str(e)[:160]}')
            return
        finally:
            QApplication.restoreOverrideCursor()
        opened = self._open_in_google_earth(res["path"])   # parity with Export KML
        tail = ' — opening in Google Earth…' if opened else ''
        self.iface.messageBar().pushSuccess(
            'Export KMZ',
            f'Exported {res["features"]:,} features from {res["layers"]} layers '
            f'→ {res["path"]}{tail}')

    # ── DXF export (contractor CAD) ───────────────────────────────────────────
    def _export_dxf(self):
        """Export the VISIBLE vector layers to a DXF CAD drawing (native QgsDxfExport,
        zero deps). Read-only on the data; exports in the data's own metric CRS."""
        from qgis.PyQt.QtWidgets import QFileDialog, QApplication
        from qgis.PyQt.QtCore import Qt

        # Ask BEFORE the save dialog, so you never name a file then cancel.
        layers = self._pick_layers('Export DXF')
        if not layers:
            return          # cancelled, or nothing ticked — write nothing
        path, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 'Export network to DXF',
            self._default_export_path('dxf'),
            'CAD DXF (*.dxf)')
        if not path:
            return
        try:
            from .fibre_automation.dxf_export import build_dxf
        except ImportError:
            from fibre_automation.dxf_export import build_dxf
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            res = build_dxf(layers, path)
        except Exception as e:
            self.iface.messageBar().pushWarning('Export DXF', f'Export failed: {str(e)[:160]}')
            return
        finally:
            QApplication.restoreOverrideCursor()
        if res.get('ok'):
            self.iface.messageBar().pushSuccess(
                'Export DXF',
                f'Exported {res["layers"]} layers ({res.get("crs") or "CRS"}) → {res["path"]}')
        else:
            self.iface.messageBar().pushWarning(
                'Export DXF', f'Export did not complete: {res.get("msg") or res.get("result")}')

    # ── Styled GeoPackage export (one file, pre-styled) ───────────────────────
    def _export_styled_gpkg(self):
        """Package chosen vector layers into ONE GeoPackage with styles + metadata
        embedded (native:package). Read-only on the project."""
        import processing
        from qgis.PyQt.QtWidgets import QFileDialog, QApplication
        from qgis.PyQt.QtCore import Qt

        # Ask BEFORE the save dialog, so you never name a file then cancel.
        layers = self._pick_layers('Export GeoPackage')
        if not layers:
            return          # cancelled, or nothing ticked — write nothing
        path, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 'Export styled GeoPackage',
            self._default_export_path('gpkg'),
            'GeoPackage (*.gpkg)')
        if not path:
            return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            processing.run('native:package', {
                'LAYERS': layers, 'OUTPUT': path, 'OVERWRITE': True,
                'SAVE_STYLES': True, 'SAVE_METADATA': True,
                'SELECTED_FEATURES_ONLY': False})
        except Exception as e:
            self.iface.messageBar().pushWarning('Export GeoPackage', f'Export failed: {str(e)[:160]}')
            return
        finally:
            QApplication.restoreOverrideCursor()
        self.iface.messageBar().pushSuccess(
            'Export GeoPackage', f'Packaged {len(layers)} styled layers → {path}')

    # ── KML export (client-spec, Google Earth) ────────────────────────────────
    def _export_kml(self):
        """Export a GeoPackage (or the open project) to a client-spec KML: correct
        per-client symbology (Fibertime HLD / Vuma / HeroTel), status-based pole/ONT/
        home colours, grouped folders, a clean info-balloon + every attribute in
        ExtendedData. Zero-dependency; read-only on the data."""
        import os
        from qgis.core import QgsProject, QgsMapLayer
        from qgis.PyQt.QtWidgets import (
            QVBoxLayout, QHBoxLayout, QRadioButton, QLineEdit, QPushButton,
            QComboBox, QLabel, QDialogButtonBox, QButtonGroup, QFileDialog, QApplication)
        from qgis.PyQt.QtCore import Qt

        dlg = QDialog(self.iface.mainWindow())
        dlg.setWindowTitle("Export KML")
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        dlg.setMinimumWidth(470)
        lay = QVBoxLayout(dlg)

        lay.addWidget(QLabel("<b>Source</b>"))
        rb_project = QRadioButton("Current project")
        rb_project.setChecked(True)
        rb_gpkg = QRadioButton("GeoPackage file:")
        grp = QButtonGroup(dlg)
        grp.addButton(rb_project)
        grp.addButton(rb_gpkg)
        lay.addWidget(rb_project)

        # Layer choice for the project source. Defaults to the visible layers — the
        # long-standing behaviour — so this changes nothing unless you use it.
        chosen = {"ids": None}          # None = "whatever is visible at export time"

        def _visible_layers():
            root_ = QgsProject.instance().layerTreeRoot()
            return [n.layer() for n in root_.findLayers()
                    if n.isVisible() and n.layer() is not None
                    and n.layer().type() == QgsMapLayer.LayerType.VectorLayer]

        lyr_row = QHBoxLayout()
        lyr_row.addSpacing(20)
        lyr_lbl = QLabel("")
        btn_layers = QPushButton("Choose layers…")

        def _refresh_lyr_lbl():
            if chosen["ids"] is None:
                lyr_lbl.setText(f"<i>visible layers ({len(_visible_layers())})</i>")
            else:
                lyr_lbl.setText(f"<b>{len(chosen['ids'])} layer(s) chosen</b>")

        def _choose_layers():
            picked = self._pick_layers('Export KML', parent=dlg,
                                       checked_ids=chosen["ids"])
            if picked:                  # None/empty = cancelled -> keep previous
                chosen["ids"] = [lyr.id() for lyr in picked]
                rb_project.setChecked(True)
                _refresh_lyr_lbl()

        btn_layers.clicked.connect(_choose_layers)
        lyr_row.addWidget(btn_layers)
        lyr_row.addWidget(lyr_lbl, 1)
        lay.addLayout(lyr_row)
        _refresh_lyr_lbl()

        row1 = QHBoxLayout()
        gpkg_edit = QLineEdit()
        gpkg_edit.setEnabled(False)
        btn_gpkg = QPushButton("Browse…")
        row1.addWidget(rb_gpkg)
        row1.addWidget(gpkg_edit, 1)
        row1.addWidget(btn_gpkg)
        lay.addLayout(row1)

        lay.addWidget(QLabel("<b>Client spec</b>"))
        client_combo = QComboBox()
        client_combo.addItem("Auto-detect", None)
        client_combo.addItem("fibertime", "fibertime")
        client_combo.addItem("Vuma", "vuma")
        client_combo.addItem("HeroTel", "herotel")
        lay.addWidget(client_combo)

        lay.addWidget(QLabel("<b>Output KML</b>"))
        row2 = QHBoxLayout()
        out_edit = QLineEdit(self._default_export_path('kml'))
        btn_out = QPushButton("Browse…")
        row2.addWidget(out_edit, 1)
        row2.addWidget(btn_out)
        lay.addLayout(row2)

        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                              | QDialogButtonBox.StandardButton.Cancel)
        bb.button(QDialogButtonBox.StandardButton.Ok).setText("Export KML")
        lay.addWidget(bb)

        def _pick_gpkg():
            p, _ = QFileDialog.getOpenFileName(
                dlg, "Select GeoPackage", "C:/Temp", "GeoPackage (*.gpkg)")
            if p:
                gpkg_edit.setText(p)
                rb_gpkg.setChecked(True)
                out_edit.setText(os.path.splitext(p)[0] + ".kml")

        def _pick_out():
            p, _ = QFileDialog.getSaveFileName(
                dlg, "Save KML as", out_edit.text() or "C:/Temp/network.kml", "KML (*.kml)")
            if p:
                out_edit.setText(p)

        btn_gpkg.clicked.connect(_pick_gpkg)
        btn_out.clicked.connect(_pick_out)
        rb_gpkg.toggled.connect(gpkg_edit.setEnabled)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)

        # Capture widget values WHILE the dialog is still alive (WA_DeleteOnClose).
        captured = {}

        def _capture():
            captured["use_gpkg"] = rb_gpkg.isChecked()
            captured["gpkg"] = gpkg_edit.text().strip()
            captured["client"] = client_combo.currentData()
            captured["out"] = out_edit.text().strip()
            captured["layer_ids"] = chosen["ids"]
        dlg.accepted.connect(_capture)

        try:
            from .nexus_dock import chrome_dialog
            chrome_dialog(dlg)
        except Exception:
            pass
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        out = captured.get("out")
        if not out:
            self.iface.messageBar().pushWarning('Export KML', 'No output path chosen.')
            return
        client = captured.get("client")
        try:
            from .fibre_automation.kml_export import build_kml, build_kml_from_gpkg
        except ImportError:
            from fibre_automation.kml_export import build_kml, build_kml_from_gpkg

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            if captured.get("use_gpkg"):
                gpkg = captured.get("gpkg")
                if not gpkg or not os.path.exists(gpkg):
                    raise RuntimeError("Pick an existing GeoPackage file.")
                res = build_kml_from_gpkg(gpkg, out, client=client)
            else:
                ids = captured.get("layer_ids")
                if ids:                      # explicit choice from "Choose layers…"
                    proj = QgsProject.instance()
                    layers = [proj.mapLayer(i) for i in ids]
                    layers = [lyr for lyr in layers if lyr is not None]
                    if not layers:
                        raise RuntimeError(
                            "The chosen layers are no longer in the project.")
                else:                        # unchanged default: visible layers
                    layers = _visible_layers()
                    if not layers:
                        raise RuntimeError(
                            "No visible vector layers — tick layers in the Layers panel, "
                            "or use “Choose layers…”.")
                # Fingerprint the client off the WHOLE project, not just the chosen
                # layers — otherwise ticking a subset could flip the detected client
                # and silently change the symbology.
                res = build_kml(layers, out, client=client,
                                detect_names=[lyr.name() for lyr
                                              in QgsProject.instance().mapLayers().values()])
        except Exception as e:
            self.iface.messageBar().pushWarning('Export KML', f'Export failed: {str(e)[:160]}')
            return
        finally:
            QApplication.restoreOverrideCursor()
        opened = self._open_in_google_earth(res["path"])
        tail = ' — opening in Google Earth…' if opened else ''
        self.iface.messageBar().pushSuccess(
            'Export KML',
            f'Exported {res["features"]:,} features from {res["layers"]} layers '
            f'({res["client"]}) → {res["path"]}{tail}')

    @staticmethod
    def _open_in_google_earth(path):
        """Best-effort: launch an exported KML *or KMZ* in Google Earth Pro (Windows).
        Tries the GE Pro exe directly, then the file's default handler. NEVER raises —
        a missing Earth must not fail an export that already wrote its file."""
        import os
        import subprocess
        for exe in (r"C:\Program Files\Google\Google Earth Pro\client\googleearth.exe",
                    r"C:\Program Files (x86)\Google\Google Earth Pro\client\googleearth.exe"):
            if os.path.exists(exe):
                try:
                    subprocess.Popen([exe, path])
                    return True
                except Exception:
                    break
        try:
            os.startfile(path)  # .kml is associated with Google Earth on team machines
            return True
        except Exception:
            return False

    # ── Project backup (zip all file-based layers) ────────────────────────────
    def _backup_project(self):
        """One-click zip backup of every file-based layer + the project file. Read-only."""
        import os
        from datetime import datetime
        from qgis.core import QgsProject
        from qgis.PyQt.QtWidgets import QFileDialog, QApplication
        from qgis.PyQt.QtCore import Qt
        try:
            from .fibre_automation.project_backup import backup_project
        except ImportError:
            from fibre_automation.project_backup import backup_project

        proj = QgsProject.instance()
        base = proj.baseName() or 'project'
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        default_dir = (os.path.join(os.path.dirname(proj.fileName()), 'Backups')
                       if proj.fileName() else 'C:/Temp')
        try:
            os.makedirs(default_dir, exist_ok=True)
        except Exception:
            default_dir = 'C:/Temp'
        path, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 'Back up project layers',
            os.path.join(default_dir, f'{base}_{stamp}.zip'), 'Zip archive (*.zip)')
        if not path:
            return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            res = backup_project(proj, path)
        except Exception as e:
            self.iface.messageBar().pushWarning('Backup', f'Backup failed: {str(e)[:160]}')
            return
        finally:
            QApplication.restoreOverrideCursor()
        if res.get('ok'):
            mb = res['bytes'] / (1024 * 1024)
            self.iface.messageBar().pushSuccess(
                'Backup', f'Backed up {res["files"]} files ({mb:.1f} MB) → {res["path"]}')
        else:
            self.iface.messageBar().pushWarning('Backup', res.get('msg') or 'nothing to back up')

    # ── QA report (shareable HTML) ────────────────────────────────────────────
    def _open_project_audit(self):
        """DEV only — run the deep project auditor (research/project_deep_audit.py),
        open the HTML report, and inject the interactive zoom-to-issue panel. The
        engine + panel live in the dev-only research/ folder, so this button is
        gated to dev mode (teammates never see it)."""
        import os
        from qgis.PyQt.QtCore import QUrl
        from qgis.PyQt.QtGui import QDesktopServices
        rd = r"C:/Users/jjsch/OneDrive - blitzfibre.com/Documents/Workspace/QGIS/research"
        engine = os.path.join(rd, 'project_deep_audit.py')
        panel = os.path.join(rd, 'audit_panel.py')
        report = r'C:/Temp/project_audit_report.html'
        bar = self.iface.messageBar()
        try:
            if os.path.exists(engine):
                bar.pushInfo('Project Audit', 'Scanning every layer/cell/geometry…')
                self.iface.mainWindow().repaint()
                exec(compile(open(engine, encoding='utf-8').read(), engine, 'exec'), {})
        except Exception as e:
            bar.pushWarning('Project Audit', f'Audit engine error: {e}')
        if os.path.exists(report):
            QDesktopServices.openUrl(QUrl.fromLocalFile(report))
        else:
            bar.pushWarning('Project Audit', 'No report produced — is research/project_deep_audit.py present?')
        try:
            if os.path.exists(panel):
                exec(compile(open(panel, encoding='utf-8').read(), panel, 'exec'), {})
        except Exception as e:
            bar.pushWarning('Project Audit', f'Panel error: {e}')

    def _export_qa_report(self):
        """Run the integrity QA and write a shareable HTML report. Read-only."""
        import webbrowser
        from datetime import datetime
        from qgis.core import QgsProject
        from qgis.PyQt.QtWidgets import QFileDialog, QApplication
        from qgis.PyQt.QtCore import Qt
        try:
            from .fibre_automation.topology_qa import run_qa
            from .fibre_automation.qa_report import render_html
        except ImportError:
            from fibre_automation.topology_qa import run_qa
            from fibre_automation.qa_report import render_html

        proj = QgsProject.instance()
        base = proj.baseName() or 'project'
        path, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 'Export QA report',
            f'C:/Temp/QA_report_{base}.html', 'HTML report (*.html)')
        if not path:
            return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            issues = run_qa(proj)
            doc = render_html(issues, base, datetime.now().strftime('%Y-%m-%d %H:%M'))
            with open(path, 'w', encoding='utf-8') as fh:
                fh.write(doc)
        except Exception as e:
            self.iface.messageBar().pushWarning('QA Report', f'Failed: {str(e)[:160]}')
            return
        finally:
            QApplication.restoreOverrideCursor()
        try:
            webbrowser.open('file:///' + path.replace('\\', '/'))
        except Exception:
            pass
        errs = sum(1 for i in issues if i['severity'] == 'ERROR')
        self.iface.messageBar().pushSuccess(
            'QA Report', f'Saved QA report — {len(issues)} issue(s), {errs} error(s) → {path}')

    # ── Topology & Integrity QA ───────────────────────────────────────────────
    def _run_topology_qa(self):
        """Comprehensive, dependency-free data-integrity / topology QA. Read-only.
        Builds a 'QA Issues' point layer (coloured by severity) + a console summary,
        and zooms to the first ERROR."""
        from collections import Counter
        from qgis.core import (QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry,
                               QgsPointXY, QgsField)
        from qgis.PyQt.QtCore import QMetaType, Qt
        from qgis.PyQt.QtWidgets import QApplication
        try:
            from .fibre_automation.topology_qa import run_qa
        except ImportError:
            from fibre_automation.topology_qa import run_qa

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            issues = run_qa(QgsProject.instance())
        except Exception as e:
            self.iface.messageBar().pushWarning('Topology QA', f'QA failed: {str(e)[:160]}')
            return
        finally:
            QApplication.restoreOverrideCursor()

        errors = [i for i in issues if i['severity'] == 'ERROR']
        warns = [i for i in issues if i['severity'] == 'WARN']

        crs = QgsProject.instance().crs().authid() or 'EPSG:4326'
        vl = QgsVectorLayer(f'Point?crs={crs}', 'QA Issues', 'memory')
        dp = vl.dataProvider()
        dp.addAttributes([QgsField('severity', QMetaType.Type.QString),
                          QgsField('check', QMetaType.Type.QString),
                          QgsField('layer', QMetaType.Type.QString),
                          QgsField('fid', QMetaType.Type.Int),
                          QgsField('desc', QMetaType.Type.QString)])
        vl.updateFields()
        feats = []
        for i in issues:
            f = QgsFeature(vl.fields())
            f.setAttributes([i['severity'], i['check'], i['layer'], int(i['fid']), i['desc']])
            if i['x'] or i['y']:
                f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(i['x'], i['y'])))
            feats.append(f)
        dp.addFeatures(feats)
        vl.updateExtents()
        # colour by severity so problems pop on the canvas: red ERROR, amber WARN
        try:
            from qgis.core import (QgsCategorizedSymbolRenderer, QgsRendererCategory,
                                   QgsMarkerSymbol)
            cats = [
                QgsRendererCategory('ERROR', QgsMarkerSymbol.createSimple(
                    {'name': 'circle', 'color': '#E11D48', 'size': '3.4',
                     'outline_color': '#FFFFFF', 'outline_width': '0.4'}), 'ERROR'),
                QgsRendererCategory('WARN', QgsMarkerSymbol.createSimple(
                    {'name': 'triangle', 'color': '#F59E0B', 'size': '3.2',
                     'outline_color': '#FFFFFF', 'outline_width': '0.4'}), 'WARN'),
            ]
            vl.setRenderer(QgsCategorizedSymbolRenderer('severity', cats))
        except Exception:
            pass
        for old in QgsProject.instance().mapLayersByName('QA Issues'):
            QgsProject.instance().removeMapLayer(old.id())

        print(f'[FiberNet] Topology QA: {len(errors)} ERROR / {len(warns)} WARN')
        for sev, lst in (('ERROR', errors), ('WARN', warns)):
            for chk, n in Counter(i['check'] for i in lst).most_common():
                print(f'   {sev} {chk}: {n}')

        if not issues:
            self.iface.messageBar().pushSuccess(
                'Topology QA', 'No issues found — network passes data-integrity QA. ✓')
            return

        QgsProject.instance().addMapLayer(vl)
        target = errors[0] if errors else warns[0]
        if target['x'] or target['y']:
            try:
                self.iface.mapCanvas().setCenter(QgsPointXY(target['x'], target['y']))
                self.iface.mapCanvas().refresh()
            except Exception:
                pass
        push = self.iface.messageBar().pushWarning if errors else self.iface.messageBar().pushInfo
        push('Topology QA',
             f'{len(errors)} error(s), {len(warns)} warning(s) — see the "QA Issues" layer '
             f'+ Python console for the breakdown.')

    # ── FT pipeline pre-flight check ──────────────────────────────────────────
    def _run_preflight_check(self):
        """Verify the FT6/FT7 prerequisites BEFORE the operator runs the pipeline,
        so the two silent-failure traps (missing PON feeder order, stale roads)
        surface up front. Cheap: file stats + featureCount only."""
        import os
        import time
        from qgis.core import QgsProject

        checks = []   # (ok, label, detail)

        # FT6 — pon_feeder_order.txt (64 or 66 entries)
        order = None
        for cand in (os.path.join(os.path.dirname(os.path.dirname(__file__)), 'pon_feeder_order.txt'),
                     'C:/Temp/pon_feeder_order.txt'):
            if os.path.exists(cand):
                order = cand
                break
        try:
            from .fibre_automation.shared.vf_paths import data_file
            if data_file and os.path.exists(data_file('pon_feeder_order.txt')):
                order = data_file('pon_feeder_order.txt')
        except Exception:
            pass
        if order:
            try:
                with open(order) as _f:
                    n = sum(1 for ln in _f if ln.strip())
            except Exception:
                n = 0
            ok = n in (64, 66)
            checks.append((ok, 'FT6 PON feeder order',
                           f'{n} entries' + ('' if ok else ' — expected 64 or 66; re-record')))
        else:
            checks.append((False, 'FT6 PON feeder order',
                           'pon_feeder_order.txt NOT found — record it (🔴 Record PON Order) before FT6'))

        # FT7 — roads.json present + fresh
        roads = None
        for cand in ('C:/Temp/roads.json',):
            if os.path.exists(cand):
                roads = cand
        try:
            from .fibre_automation.shared.vf_paths import roads_json
            if roads_json and os.path.exists(roads_json()):
                roads = roads_json()
        except Exception:
            pass
        if roads:
            age_d = (time.time() - os.path.getmtime(roads)) / 86400.0
            ok = age_d < 30
            checks.append((ok, 'FT7 roads.json',
                           f'{age_d:.0f} days old' + ('' if ok else ' — stale; run /roads to refresh')))
        else:
            checks.append((False, 'FT7 roads.json', 'NOT found — run /roads before FT7'))

        # key layers present
        proj = QgsProject.instance()
        for name_keys in (('Poles', ('pole',)), ('PON', ('pon',)), ('Cables', ('cable', 'feeder'))):
            label, keys = name_keys
            present = any(any(k in l.name().lower() for k in keys)
                          for l in proj.mapLayers().values())
            checks.append((present, f'Layer: {label}', 'present' if present else 'missing'))

        passed = sum(1 for ok, _, _ in checks if ok)
        lines = '  '.join(f'{"✓" if ok else "✗"} {lbl}' for ok, lbl, _ in checks)
        print('[FiberNet] Pre-flight:')
        for ok, lbl, detail in checks:
            print(f'   {"✓" if ok else "✗"} {lbl}: {detail}')
        msg = f'Pre-flight {passed}/{len(checks)} OK — {lines}'
        if passed == len(checks):
            self.iface.messageBar().pushSuccess('FT Pre-Flight', 'All prerequisites OK — safe to run the FT pipeline.')
        else:
            self.iface.messageBar().pushWarning('FT Pre-Flight', msg + '  (see Python console for details)')

    # ── Zone & PON capacity report ────────────────────────────────────────────
    def _run_capacity_report(self):
        """Per-PON fill + per-zone rollup from the ONT layer. Flags over-capacity
        (>128) and under-utilised (<80) PONs against the Velocity target band.
        Degrades gracefully if no ONT layer / pon field is present."""
        from qgis.core import QgsProject, QgsMapLayer, QgsFeatureRequest
        from collections import Counter

        ont = None
        for l in QgsProject.instance().mapLayers().values():
            if l.type() != QgsMapLayer.LayerType.VectorLayer:
                continue
            nm = l.name().lower()
            if any(k in nm for k in ('ont', 'home connection', 'home_conn')) \
                    and l.featureCount() > 0:
                ont = l
                break
        if ont is None:
            self.iface.messageBar().pushWarning(
                'Capacity', 'No ONT / Home-Connection layer found.')
            return

        fields = [f.name() for f in ont.fields()]
        pon_f = next((f for f in fields if f.lower() in ('pon_no', 'pon')), None)
        if pon_f is None:
            self.iface.messageBar().pushWarning(
                'Capacity', f'ONT layer "{ont.name()}" has no pon_no field — run FT5/FT6 first.')
            return

        per_pon = Counter()
        unassigned = 0
        for f in ont.getFeatures(QgsFeatureRequest().setSubsetOfAttributes([pon_f], ont.fields())):
            v = f[pon_f]
            if v in (None, '') or str(v).lower() == 'null':
                unassigned += 1
                continue
            try:
                per_pon[int(float(v))] += 1
            except (ValueError, TypeError):
                unassigned += 1

        if not per_pon:
            self.iface.messageBar().pushWarning(
                'Capacity', f'No ONTs carry a PON number yet ({unassigned} unassigned).')
            return

        TARGET_LO, TARGET_HI, HARD_MAX = 80, 102, 128
        fills = list(per_pon.values())
        over = sorted((p for p, c in per_pon.items() if c > HARD_MAX))
        under = sorted((p for p, c in per_pon.items() if c < TARGET_LO))
        zones = {(p - 235) // 16 + 17 for p in per_pon}
        total = sum(fills)
        msg = (f'{total} ONTs · {len(per_pon)} PONs · {len(zones)} zones · '
               f'fill {min(fills)}–{max(fills)} (avg {total // len(fills)}). '
               f'⛔ {len(over)} over {HARD_MAX} · ⚠ {len(under)} under {TARGET_LO}'
               + (f' · {unassigned} unassigned' if unassigned else ''))
        print('[FiberNet] Capacity: ' + msg)
        if over:
            print('  over-capacity PONs: ' + ', '.join(map(str, over)))
        if under:
            print('  under-utilised PONs: ' + ', '.join(map(str, under)))
        if over:
            self.iface.messageBar().pushCritical('Zone & PON Capacity', msg)
        elif under or unassigned:
            self.iface.messageBar().pushWarning('Zone & PON Capacity', msg)
        else:
            self.iface.messageBar().pushSuccess('Zone & PON Capacity', msg)

    # ── Spatial anomaly scan ──────────────────────────────────────────────────
    def _run_anomaly_scan(self):
        """Project-agnostic topology QA: flag orphaned poles (no cable vertex
        within the snap tolerance) and dangling cable ends (an endpoint not
        snapped to any node — pole/splitter/joint/enclosure). Loads the hits as
        an 'Anomalies' memory layer so they're zoomable. Read-only on the data."""
        from qgis.core import (QgsProject, QgsMapLayer, QgsWkbTypes,
                               QgsSpatialIndex, QgsFeature, QgsGeometry,
                               QgsPointXY, QgsVectorLayer, QgsField, QgsFeatureRequest)
        from qgis.PyQt.QtCore import QMetaType

        TOL_M = 10.0                   # 10 m snap tolerance (project convention)
        proj = QgsProject.instance()
        vlayers = [l for l in proj.mapLayers().values()
                   if l.type() == QgsMapLayer.LayerType.VectorLayer]

        # Skip temp / scratch / backup / working layers — QA only real deliverables.
        SKIP = ('temp', 'scratch', 'backup', '_bak', 'copy', '_best', '_old', 'test_')

        def _is(geom_type, *keys):
            out = []
            for l in vlayers:
                try:
                    nm = l.name().lower()
                    if l.geometryType() != geom_type:
                        continue
                    if any(s in nm for s in SKIP):
                        continue
                    if any(k in nm for k in keys):
                        out.append(l)
                except Exception:
                    pass
            return out

        pole_lyrs = _is(QgsWkbTypes.GeometryType.PointGeometry,
                        'pole', 'splitter', 'joint', 'enclosure', 'node', 'dome')
        # Connection cables only — NOT "span" (a Vuma midblock routing spine that
        # legitimately isn't pole-terminated, so it must not count as dangling).
        cable_lyrs = _is(QgsWkbTypes.GeometryType.LineGeometry,
                         'cable', 'feeder', 'distribution', 'drop', 'spur', 'link')
        cable_lyrs = [l for l in cable_lyrs if 'span' not in l.name().lower()]
        if not pole_lyrs or not cable_lyrs:
            self.iface.messageBar().pushWarning(
                'Anomaly Scan',
                'Need both point (pole/splitter) and line (cable) layers — '
                f'found {len(pole_lyrs)} point, {len(cable_lyrs)} line.')
            return

        # Scale the snap tolerance to the cable layer CRS: `d` below is a planar
        # Euclidean distance in CRS units. For a projected CRS (UTM metres, the
        # FTTH standard) compare against 10 m directly; for a geographic CRS
        # convert 10 m to degrees. Using degrees against metres flagged every
        # end/pole as an anomaly (and vice-versa).
        TOL = TOL_M / 111320.0 if cable_lyrs[0].crs().isGeographic() else TOL_M

        # index of all node points
        node_pts = []
        for l in pole_lyrs:
            for f in l.getFeatures(QgsFeatureRequest().setNoAttributes()):
                g = f.geometry()
                if g and not g.isEmpty():
                    node_pts.append(g.centroid().asPoint())
        node_idx = QgsSpatialIndex()
        for i, p in enumerate(node_pts):
            ft = QgsFeature(i)
            ft.setGeometry(QgsGeometry.fromPointXY(p))
            node_idx.addFeature(ft)

        anomalies = []   # (x, y, kind, detail)

        # 1) dangling cable ends — endpoint not within tol of any node
        for l in cable_lyrs:
            for f in l.getFeatures():
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                try:
                    pl = g.asMultiPolyline() or [g.asPolyline()]
                except Exception:
                    continue
                for line in pl:
                    if len(line) < 2:
                        continue
                    for end in (line[0], line[-1]):
                        ids = node_idx.nearestNeighbor(QgsPointXY(end), 1)
                        ok = False
                        if ids:
                            np_ = node_pts[ids[0]]
                            d = ((np_.x()-end.x())**2 + (np_.y()-end.y())**2) ** 0.5
                            ok = d <= TOL
                        if not ok:
                            anomalies.append((end.x(), end.y(), 'dangling_end', l.name()))

        # 2) orphaned poles — no cable vertex within tol
        cab_idx = QgsSpatialIndex()
        cab_pts = []
        k = 0
        for l in cable_lyrs:
            for f in l.getFeatures():
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                for v in g.vertices():
                    cab_pts.append(QgsPointXY(v))
                    ft = QgsFeature(k); ft.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(v)))
                    cab_idx.addFeature(ft); k += 1
        if cab_pts:
            for l in pole_lyrs:
                if 'pole' not in l.name().lower():
                    continue   # only true poles count as "orphaned"
                for f in l.getFeatures():
                    g = f.geometry()
                    if not g or g.isEmpty():
                        continue
                    p = g.asPoint() if g.wkbType() in (QgsWkbTypes.Point,) else g.centroid().asPoint()
                    ids = cab_idx.nearestNeighbor(p, 1)
                    if ids:
                        cv = cab_pts[ids[0]]
                        d = ((cv.x()-p.x())**2 + (cv.y()-p.y())**2) ** 0.5
                        if d > TOL:
                            anomalies.append((p.x(), p.y(), 'orphaned_pole', l.name()))

        # build / refresh the Anomalies memory layer
        crs = cable_lyrs[0].crs().authid() or 'EPSG:4326'
        for old in proj.mapLayersByName('Anomalies'):
            proj.removeMapLayer(old.id())
        mem = QgsVectorLayer(f'Point?crs={crs}', 'Anomalies', 'memory')
        dp = mem.dataProvider()
        dp.addAttributes([QgsField('kind', QMetaType.Type.QString),
                          QgsField('layer', QMetaType.Type.QString)])
        mem.updateFields()
        feats = []
        for x, y, kind, src in anomalies:
            ft = QgsFeature()
            ft.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
            ft.setAttributes([kind, src])
            feats.append(ft)
        dp.addFeatures(feats)
        mem.updateExtents()
        if anomalies:
            proj.addMapLayer(mem)

        dang = sum(1 for a in anomalies if a[2] == 'dangling_end')
        orph = sum(1 for a in anomalies if a[2] == 'orphaned_pole')
        msg = f'{len(anomalies)} anomalies — {dang} dangling cable ends, {orph} orphaned poles (10 m tol).'
        if anomalies:
            self.iface.messageBar().pushWarning('Spatial Anomaly Scan',
                                                msg + ' See the "Anomalies" layer.')
        else:
            self.iface.messageBar().pushSuccess('Spatial Anomaly Scan',
                                                'No orphaned poles or dangling cable ends ✓')
        print('[FiberNet] Anomaly scan: ' + msg)

    # ── Optical power budget (ITU-T G.984) ───────────────────────────────────
    def _run_power_budget_check(self):
        """First-order per-ONT GPON power-budget estimate. Uses straight-line
        POP→ONT distance × routing factor (true routed length isn't traced yet),
        the Combo-1 splitter chain (1:8 FTS + 1:16 STS) and standard ITU-T G.984
        losses. Honestly reported as an ESTIMATE — flags over-reach / over-split
        links so the planner can investigate. Degrades gracefully if layers are
        missing."""
        from qgis.core import (QgsProject, QgsMapLayer, QgsDistanceArea)
        try:
            from . import power_budget as pb
        except ImportError:
            import power_budget as pb

        def _find(keys):
            for lyr in QgsProject.instance().mapLayers().values():
                if lyr.type() != QgsMapLayer.LayerType.VectorLayer:
                    continue
                nm = lyr.name().lower()
                if any(k in nm for k in keys) and lyr.featureCount() > 0:
                    return lyr
            return None

        ont = _find(('ont', 'home connection', 'home_conn'))
        pop = _find(('pop', 'olt', 'core', 'aggregation'))
        if ont is None:
            self.iface.messageBar().pushWarning(
                'Power Budget', 'No ONT / Home-Connection layer found — cannot estimate.')
            return

        da = QgsDistanceArea()
        da.setEllipsoid('WGS84')
        try:
            da.setSourceCrs(ont.crs(), QgsProject.instance().transformContext())
        except Exception:
            pass

        # nearest POP point (single ref is fine for a first-order estimate)
        pop_pt = None
        if pop is not None:
            for f in pop.getFeatures():
                g = f.geometry()
                if g and not g.isEmpty():
                    pop_pt = g.centroid().asPoint()
                    break

        counts = {'green': 0, 'amber': 0, 'red': 0}
        worst = None
        n = 0
        for f in ont.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            pt = g.centroid().asPoint()
            if pop_pt is not None:
                try:
                    km = da.measureLine(pop_pt, pt) / 1000.0
                except Exception:
                    km = da.measureLine(pop_pt, pt)  # already deg→m fallback
            else:
                km = 2.0   # no POP: assume a typical 2 km reach for the estimate
            _loss, m, cls = pb.budget_for_ont(km)
            counts[cls] += 1
            n += 1
            if worst is None or m < worst[0]:
                worst = (m, km)

        if n == 0:
            self.iface.messageBar().pushWarning('Power Budget', 'No ONT geometries to evaluate.')
            return

        reach = pb.max_reach_km()
        src = 'POP→ONT distance' if pop_pt is not None else 'assumed 2 km (no POP layer)'
        msg = (f'{n} ONTs · ✅ {counts["green"]} healthy · '
               f'⚠ {counts["amber"]} tight · ⛔ {counts["red"]} failing  '
               f'(worst margin {worst[0]:.1f} dB @ {worst[1]:.2f} km). '
               f'Combo-1 max reach ≈ {reach:.1f} km. Estimate from {src}.')
        if counts['red']:
            self.iface.messageBar().pushCritical('Optical Power Budget', msg)
        elif counts['amber']:
            self.iface.messageBar().pushWarning('Optical Power Budget', msg)
        else:
            self.iface.messageBar().pushSuccess('Optical Power Budget', msg)
        print('[FiberNet] Power budget: ' + msg)

    # ── OSM no-data erven generation (dev/venv) ───────────────────────────────
    def _gen_erven_osm(self):
        """Generate regular erven from the OSM road network for the current view
        (where there's no CSG cadastre). osmnx/geopandas are venv-only, and OSM
        fetch is slow, so this runs a venv subprocess inside a QgsTask — fully
        off the QGIS main thread."""
        import os
        from qgis.core import (QgsProject, QgsCoordinateTransform, QgsApplication,
                               QgsCoordinateReferenceSystem, QgsTask, QgsVectorLayer)
        canvas = self.iface.mapCanvas()
        to4326 = QgsCoordinateTransform(canvas.mapSettings().destinationCrs(),
                                        QgsCoordinateReferenceSystem('EPSG:4326'),
                                        QgsProject.instance())
        b = to4326.transformBoundingBox(canvas.extent())
        if (b.width() > 0.1 or b.height() > 0.1):
            self.iface.messageBar().pushWarning('OSM Erven', 'Zoom in first (view too large).')
            return
        # locate the erven_studio runner + venv python (dev-only)
        runner = None
        for base in ('C:/Users/jjsch/OneDrive - blitzfibre.com/Documents/Workspace/QGIS/erven_studio',
                     os.path.join(os.path.dirname(os.path.dirname(__file__)), 'erven_studio')):
            cand = os.path.join(base, 'osm_blocks_runner.py')
            if os.path.exists(cand):
                runner = cand
                break
        try:
            from .fibre_automation.shared.vf_paths import python_exe
        except ImportError:
            from fibre_automation.shared.vf_paths import python_exe
        py = python_exe()
        if not runner or not py or not os.path.exists(py):
            self.iface.messageBar().pushWarning(
                'OSM Erven', 'erven_studio / venv not available — this is a dev feature.')
            return
        out = 'C:/Temp/osm_erven.geojson'
        bbox = (b.xMinimum(), b.yMinimum(), b.xMaximum(), b.yMaximum())
        self.iface.messageBar().pushInfo('OSM Erven', 'Generating erven from OSM roads (background)…')

        class _Task(QgsTask):
            def __init__(self, iface):
                super().__init__('Generate erven from OSM', QgsTask.Flag.CanCancel)
                self.iface = iface; self.err = None

            def run(self):
                import subprocess
                try:
                    r = subprocess.run([py, runner, *[f'{c}' for c in bbox], out],
                                       capture_output=True, text=True, timeout=180)
                    if r.returncode != 0:
                        self.err = (r.stderr or r.stdout or 'failed')[:200]
                        return False
                except Exception as e:
                    self.err = str(e)[:200]
                    return False
                return True

            def finished(self, ok):
                if not ok or self.err:
                    self.iface.messageBar().pushWarning('OSM Erven', f'Failed: {self.err}')
                    return
                lyr = QgsVectorLayer(out, 'Erven (OSM-generated)', 'ogr')
                if lyr.isValid() and lyr.featureCount() > 0:
                    QgsProject.instance().addMapLayer(lyr)
                    self.iface.messageBar().pushSuccess(
                        'OSM Erven', f'Generated {lyr.featureCount():,} erven from OSM roads.')
                else:
                    self.iface.messageBar().pushWarning('OSM Erven', 'No erven generated for this view.')

        task = _Task(self.iface)
        QgsApplication.taskManager().addTask(task)
        if not hasattr(self, '_osm_tasks'):
            self._osm_tasks = []
        self._osm_tasks.append(task)

    # ── CSG cadastre erven fetch ─────────────────────────────────────────────
    def _fetch_csg_erven(self):
        """Download real surveyed erven for the current view from the SA CSG
        cadastre — off the main thread (QgsTask), so it never freezes QGIS."""
        try:
            from . import csg_fetch
        except ImportError:
            import csg_fetch
        csg_fetch.run_fetch_erven(self.iface)

    # ── Feature hover tips ───────────────────────────────────────────────────
    def _toggle_feature_map_tips(self):
        """Set rich map-tip templates on the fiber layers, then toggle the
        canvas hover-tips on/off. Hover a pole/cable/splitter/ONT to see its
        key attributes without opening the attribute table."""
        from qgis.core import QgsProject, QgsMapLayer
        KW = ('pole', 'cable', 'splitter', 'ont', 'drop', 'enclosure',
              'feeder', 'distribution', 'pon', 'span', 'dome', 'joint', 'node')
        # fields worth surfacing, in priority order
        FIELDS = ['label', 'label_1', 'name', 'pon_no', 'dim2', 'length',
                  'status', 'spec_1', 'type_1', 'strtfeat', 'endfeat']
        tipped = 0
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                if lyr.type() != QgsMapLayer.LayerType.VectorLayer:
                    continue
                if not any(k in lyr.name().lower() for k in KW):
                    continue
                fns = [f.name() for f in lyr.fields()]
                rows = []
                for want in FIELDS:
                    actual = next((x for x in fns if x.lower() == want), None)
                    if actual:
                        rows.append(f'<b>{actual}:</b> [% "{actual}" %]')
                    if len(rows) >= 5:
                        break
                if not rows:
                    continue
                lyr.setMapTipTemplate(
                    '<div style="font-family:Segoe UI;font-size:11px;'
                    f'line-height:1.4">{"<br>".join(rows)}</div>')
                tipped += 1
            except Exception:
                continue
        # Toggle the global map-tips display action
        state = '?'
        try:
            act = self.iface.actionMapTips()
            if act is not None:
                act.trigger()                       # flips checked state
                state = 'ON' if act.isChecked() else 'OFF'
        except Exception:
            pass
        self.iface.messageBar().pushInfo(
            'Velocity Nexus',
            f'Feature hover tips {state} — {tipped} fiber layer(s) configured. '
            'Hover a feature on the map to see its details.')

    # ── Native QGIS locator (Ctrl+K) ─────────────────────────────────────────
    def _install_locator_filter(self):
        """Register the 'vf <text>' locator filter on the QGIS search bar."""
        try:
            from . import locator_filter
        except ImportError:
            import locator_filter
        # Drop a previous instance on reload so we don't stack duplicates.
        old = getattr(self, '_locator', None)
        if old is not None:
            try:
                self.iface.deregisterLocatorFilter(old)
            except Exception:
                pass
        self._locator = locator_filter.VelocityLocatorFilter(self.iface)
        self.iface.registerLocatorFilter(self._locator)
        print('[FiberNet] Locator filter "vf" registered ✓')

    # ── Command palette (Ctrl+Shift+P) ──────────────────────────────────────
    def _install_command_palette(self):
        """Bind Ctrl+Shift+P globally — fuzzy-finder for every plugin action."""
        from qgis.PyQt.QtGui import QShortcut
        from qgis.PyQt.QtGui import QKeySequence
        sc = QShortcut(QKeySequence("Ctrl+Shift+P"), self.iface.mainWindow())
        sc.setContext(Qt.ShortcutContext.ApplicationShortcut)
        sc.activated.connect(self._open_command_palette)
        self._cmd_palette_shortcut = sc

    # ── Mirror Eye indicator ──────────────────────────────────────────────────
    def _install_mirror_eye(self):
        """A small clickable eye on the toolbar that shows whether the Canvas
        Mirror server (port 8767) is actively watching JJ's screen.

        States (driven purely by file-mtime — NO HTTP from Qt main thread):
          - PNG age <5s   → 👁 Watching   (green, the eye is "open")
          - PNG age <30s  → 👁 Idle       (amber)
          - PNG age >30s  → 🚫 Off         (red, the eye is "closed")

        Click → opens http://127.0.0.1:8767/ in default browser.
        """
        from qgis.PyQt.QtWidgets import QPushButton
        from qgis.PyQt.QtCore import QTimer
        # Defensive cleanup — same lesson as HLD tile (don't leak on reload)
        try:
            for child in self._toolbar.findChildren(QPushButton):
                if child.objectName() == 'FNAMirrorEye':
                    child.setParent(None)
                    child.hide()
                    child.deleteLater()
        except Exception:
            pass

        eye = QPushButton('👁  …')
        eye.setObjectName('FNAMirrorEye')
        eye.setFlat(True)
        eye.setCursor(Qt.CursorShape.PointingHandCursor)
        eye.clicked.connect(self._open_mirror_viewer)
        eye.setToolTip(
            'Canvas Mirror — live screen capture of QGIS\n'
            'Click to open the viewer in your browser\n'
            'http://127.0.0.1:8767/'
        )
        self._mirror_eye = eye
        # Insert right after the brand tile, before any action
        self._toolbar.addWidget(eye)
        # Poll every 3s — file-mtime check only, no HTTP, no QGIS calls
        self._mirror_eye_timer = QTimer(self.iface.mainWindow())
        self._mirror_eye_timer.setInterval(3000)
        self._mirror_eye_timer.timeout.connect(self._refresh_mirror_eye)
        self._mirror_eye_timer.start()
        self._refresh_mirror_eye()  # initial state

    def _refresh_mirror_eye(self):
        """Update the eye state from PNG mtime. Pure file-stat — no I/O blocking."""
        import os
        import time
        if self._mirror_eye is None:
            return
        path = 'C:/Temp/canvas_mirror.png'
        try:
            if not os.path.exists(path):
                self._mirror_eye.setText('🚫  Mirror Off')
                self._mirror_eye.setStyleSheet(_MIRROR_EYE_OFF_QSS)
                return
            age = time.time() - os.path.getmtime(path)
            if age < 5:
                self._mirror_eye.setText(f'👁  Watching · {int(age)}s')
                self._mirror_eye.setStyleSheet(_MIRROR_EYE_WATCHING_QSS)
            elif age < 30:
                self._mirror_eye.setText(f'👁  Idle · {int(age)}s')
                self._mirror_eye.setStyleSheet(_MIRROR_EYE_IDLE_QSS)
            else:
                self._mirror_eye.setText('🚫  Mirror stale')
                self._mirror_eye.setStyleSheet(_MIRROR_EYE_OFF_QSS)
        except (OSError, RuntimeError):
            return  # widget was destroyed mid-tick; ignore

    def _open_mirror_viewer(self):
        """Click handler — opens the Canvas Mirror viewer in the user's default browser.
        Uses webbrowser stdlib (NOT urlopen — that would deadlock per
        feedback_never_http_to_self_from_qgis.md)."""
        import webbrowser
        webbrowser.open('http://127.0.0.1:8767/')

    def _open_command_palette(self):
        """Modal dialog with a single QLineEdit + filtered list of actions."""
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtWidgets import (QVBoxLayout, QLineEdit,
                                          QListWidget, QListWidgetItem)
        dlg = QDialog(self.iface.mainWindow())
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)   # don't leak hidden windows
        dlg.setWindowTitle("FiberNet — Command Palette")
        dlg.setMinimumWidth(520)
        dlg.setStyleSheet(
            "QDialog { background:#1A1B26; }"
            "QLineEdit { background:#24253A; color:#E6E8F0; border:1px solid #3A3D5C;"
            "  border-radius:6px; padding:8px 12px; font-size:14px;"
            "  font-family:'Segoe UI'; }"
            "QLineEdit:focus { border:1px solid #6E56CF; }"
            "QListWidget { background:#1A1B26; color:#E6E8F0; border:none;"
            "  font-family:'Segoe UI'; font-size:12px; padding:4px; }"
            "QListWidget::item { padding:7px 10px; border-radius:4px; }"
            "QListWidget::item:selected { background:#6E56CF; color:#FFFFFF; }"
            "QListWidget::item:hover { background:#3A3D5C; }"
        )
        layout = QVBoxLayout(dlg)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        edit = QLineEdit()
        edit.setPlaceholderText("Type to search actions… (Enter to run, Esc to close)")
        layout.addWidget(edit)

        listw = QListWidget()
        listw.setMaximumHeight(360)
        layout.addWidget(listw)

        # Build action catalogue.
        # Source 1: toolbar actions (self._actions).
        # Source 2: every action wired into the Velocity Nexus menu tree —
        # this is what surfaces the 18 Manual Planning tools, QA & Output and
        # Settings items that are added straight to the menu via mk() and never
        # land in self._actions. Without this the palette only finds toolbar
        # buttons (decode 1A: "biggest cheap discoverability win").
        items = []
        seen = set()  # dedup by the underlying QAction id()

        def _add(act, aid):
            if act is None or id(act) in seen:
                return
            if act.isSeparator() or act.menu() is not None:
                return  # skip dividers and submenu openers
            text = act.text().replace('&', '').strip()
            if not text:
                return
            seen.add(id(act))
            tip = act.toolTip() or ''
            ks = act.shortcut().toString() if act.shortcut() else ''
            items.append((aid, act, text, tip, ks))

        for aid, act in self._actions.items():
            _add(act, aid)

        def _walk_menu(menu):
            for act in menu.actions():
                sub = act.menu()
                if sub is not None:
                    _walk_menu(sub)
                else:
                    _add(act, act.text().replace('&', '').strip())

        velo_menu = getattr(self, '_velo_menu', None)
        if velo_menu is not None:
            try:
                _walk_menu(velo_menu)
            except Exception:
                pass  # never let palette-building crash the shortcut

        # Key every action by a stable integer so the list item can resolve
        # back to the exact QAction object — not all items live in self._actions
        # now that the menu tree is indexed too.
        act_by_key = {i: it[1] for i, it in enumerate(items)}

        def populate(query=''):
            listw.clear()
            q = query.lower().strip()
            scored = []
            for key, (aid, act, text, tip, ks) in enumerate(items):
                hay = f'{aid} {text} {tip}'.lower()
                if not q or all(part in hay for part in q.split()):
                    scored.append((key, text, ks))
            for key, text, ks in scored[:30]:
                label = f'{text}   ⌨ {ks}' if ks else text
                item = QListWidgetItem(label)
                item.setData(Qt.ItemDataRole.UserRole, key)
                listw.addItem(item)
            if listw.count() > 0:
                listw.setCurrentRow(0)

        populate()

        def trigger():
            cur = listw.currentItem()
            if cur:
                key = cur.data(Qt.ItemDataRole.UserRole)
                dlg.accept()
                act = act_by_key.get(key)
                if act is not None:
                    act.trigger()

        edit.textChanged.connect(populate)
        edit.returnPressed.connect(trigger)
        listw.itemActivated.connect(lambda _it: trigger())

        # Up/down arrow on the QLineEdit moves the list selection
        def edit_key(ev):
            if ev.key() == Qt.Key.Key_Down:
                listw.setCurrentRow(min(listw.currentRow()+1, listw.count()-1))
                return
            if ev.key() == Qt.Key.Key_Up:
                listw.setCurrentRow(max(listw.currentRow()-1, 0))
                return
            QLineEdit.keyPressEvent(edit, ev)
        edit.keyPressEvent = edit_key

        edit.setFocus()
        try:
            from .nexus_dock import chrome_dialog
            chrome_dialog(dlg)
        except Exception:
            pass
        dlg.exec()

    # ── Client selector (driven by VeloGIS Bridge dock) ──────────────────────

    def _get_bridge_dock(self):
        """Return the VeloGIS Bridge dock widget, or None if unavailable."""
        try:
            from qgis.utils import plugins as _plugins
            bp = _plugins.get('QGISBridgePlugin')
            if bp is None:
                return None
            for attr in ('_dock', 'dock', '_dock_widget', 'dock_widget'):
                dock = getattr(bp, attr, None)
                if dock is not None:
                    return dock
        except Exception:
            pass
        return None

    def _lock_dock_to_client(self, client: str):
        """Lock (or unlock) the bridge dock client buttons to match the project."""
        dock = self._get_bridge_dock()
        if dock is None:
            return
        try:
            if client:
                dock.set_client_locked(client.upper())
            else:
                dock.unlock_client()
        except AttributeError:
            pass  # older bridge plugin without locking support

    def _connect_bridge_client_signal(self) -> bool:
        """Connect to bridge dock client_changed signal. Returns True on success."""
        try:
            dock = self._get_bridge_dock()
            if dock is None:
                return False
            dock.client_changed.connect(self._rebuild_automation_group)
            print('[FiberNet] Bridge client_changed signal connected ✓')
            # Restore toolbar state from current dock selection
            current = getattr(dock, 'active_client', '')
            if current:
                self._rebuild_automation_group(current)
            return True
        except Exception as e:
            print(f'[FiberNet] Bridge signal connect failed: {e}')
            return False

    _VUMA_STEPS = [
        ('1 · Setup Layers',      'vuma_step_01'),
        ('1b · Fetch Data',       'vuma_step_01b'),
        ('1c · Erven Generator',  'vuma_step_01c'),
        ('2 · Tag Buildings',     'vuma_step_02'),
        ('3 · Demand Points',     'vuma_step_03'),
        ('4 · PON Zones',         'vuma_step_04'),
        ('5 · Place Nodes',       'vuma_step_05'),
        ('6 · Route Cables',      'vuma_step_06'),
        ('7 · Auto-Name',         'vuma_step_07'),
        ('8 · Attributes',        'vuma_step_08'),
        ('9 · QA Check',          'vuma_step_09'),
        ('10 · Export',           'vuma_step_10'),
    ]
    _FT_STEPS = [
        ('1 · Label Poles',       'ft_step_01'),
        ('2 · Distribution Cable','ft_step_02'),
        ('3 · Secondary Cable',   'ft_step_03'),
        ('4 · Enclosure',         'ft_step_04'),
        ('5 · PON Zones',         'ft_step_05'),
        ('6 · Apply PON Order',   'ft_step_06'),
        ('7 · Pole Thickness',    'ft_step_07'),
        ('8 · RC Update',         'ft_step_08'),
        ('9 · QA Report',         'ft_step_09'),
        ('10 · Export',           'ft_step_10'),
    ]
    _HEROTEL_STEPS = [
        ('1 · Setup Layers',      'herotel_step_01'),
        ('2 · Fetch Data',        'herotel_step_02'),
        ('3 · Place ONTs',        'herotel_step_03'),
        ('4 · Design Network',    'herotel_step_04'),
        ('5 · QA Check',          'herotel_step_05'),
        ('6 · Export',            'herotel_step_06'),
    ]

    def _update_toolbar_for_client(self, client):
        """Show/hide toolbar buttons based on selected client.

        client=None  → fresh project: show ONLY brand + Setup Project (clean UX for planners)
        client='vuma'→ show vuma + both; hide ft + dev
        client='ft'  → show ft + both; hide vuma + dev
        client='dev' → show everything (JJ's dev mode — not a real client value)
        """
        c = (client or '').lower()
        no_client = (c == '')

        # Menu-group dropdown buttons (Labelling, Build FT 1-7, Audit & QA)
        # Use the QWidgetAction (from tb.addWidget) for correct toolbar visibility
        for gid, meta in GROUPS.items():
            grp_client = meta.get('client', 'both')
            act = self._group_acts.get(gid)
            btn = self._group_btns.get(gid)
            if no_client:
                visible = False  # hide all groups until client is chosen
            else:
                visible = (grp_client == 'both' or grp_client == c)
            if act is not None:
                act.setVisible(visible)
            if btn is not None:
                btn.setVisible(visible)
                if visible and btn.styleSheet() == '':
                    # Apply client brand colour to this group button
                    if grp_client == 'vuma':
                        btn.setStyleSheet(_VUMA_BTN_QSS)
                    elif grp_client == 'ft':
                        btn.setStyleSheet(_FT_BTN_QSS)
                    elif grp_client == 'herotel':
                        btn.setStyleSheet(_HEROTEL_BTN_QSS)

        # Show/hide absorbed fibretime_tools buttons — they are FT-only
        ft_active = (c == 'ft')
        # QToolButton menus: must hide via the QWidgetAction returned by addWidget(),
        # not the button itself — toolbar visibility is controlled by the action wrapper.
        for act in getattr(self, '_absorbed_ft_widget_acts', []):
            try:
                act.setVisible(ft_active)
            except (RuntimeError, AttributeError):
                pass
        # Re-apply FT styling when shown
        if ft_active:
            for w in self._absorbed_ft_widgets:
                try:
                    if w.styleSheet() == '':
                        w.setStyleSheet(_FT_BTN_QSS)
                except (RuntimeError, AttributeError):
                    pass
        # Plain QActions — hide via the action itself (most reliable)
        for act in getattr(self, '_absorbed_ft_actions', []):
            try:
                act.setVisible(ft_active)
            except (RuntimeError, AttributeError):
                pass

        # All inline actions — apply per-item client visibility
        for entry in TOOLBAR_SPEC:
            item_client = entry.get('client', 'both')
            act = self._actions.get(entry['id'])
            if act is None:
                continue
            if item_client == 'dev':
                visible = False  # dev tools always hidden from planners
            elif item_client == 'both':
                visible = True   # always visible regardless of client selection
            elif item_client == 'none':
                # Client-selector buttons: show ONLY when no client is chosen
                visible = no_client
                # Apply brand styling while visible
                if visible and self._toolbar:
                    w = self._toolbar.widgetForAction(act)
                    if w:
                        qss = (_VUMA_BTN_QSS if entry['id'] == 'select_vuma'
                               else _FT_BTN_QSS)
                        try:
                            w.setStyleSheet(qss)
                        except (RuntimeError, AttributeError):
                            pass
            elif no_client:
                # Hide everything else on a fresh project (client selectors + New Project only)
                visible = False
            else:
                visible = (item_client == c)
            act.setVisible(visible)
            if self._toolbar:
                w = self._toolbar.widgetForAction(act)
                if w:
                    try:
                        w.setVisible(visible)
                    except (RuntimeError, AttributeError):
                        pass

    def _rebuild_automation_group(self, client: str):
        """Swap the automation toolbar section for the selected client."""
        from qgis.PyQt.QtWidgets import QToolButton, QMenu
        from qgis.PyQt.QtCore import Qt

        # Normalise client strings
        client = client.upper() if client else ''
        if client == 'FIBRETIME':
            client = 'FT'
        if client not in ('VUMA', 'FT', 'HEROTEL'):
            client = ''

        tb = self._toolbar

        # Show/hide fixed toolbar buttons for this client
        self._update_toolbar_for_client(client.lower() if client else '')

        # Remove previous automation widgets
        if self._automation_action is not None:
            tb.removeAction(self._automation_action)
            self._automation_action = None
        if self._automation_sep is not None:
            tb.removeAction(self._automation_sep)
            self._automation_sep = None
        if self._automation_widget is not None:
            self._automation_widget.deleteLater()
            self._automation_widget = None

        # Update SESSION
        try:
            from fibre_automation.startup import SESSION
            if client == 'VUMA':
                SESSION['client'] = 'VUMA'
            elif client == 'FT':
                SESSION['client'] = 'FT'
            elif client == 'HEROTEL':
                SESSION['client'] = 'HEROTEL'
            else:
                SESSION['client'] = None
        except Exception:
            pass

        if not client:
            return

        # Build step list + colours
        if client == 'VUMA':
            steps     = self._VUMA_STEPS
            btn_label = 'VUMA'
            run_key   = 'vuma_run_all'
            run_label = '⚡ Run All Steps'
            btn_qss   = _VUMA_BTN_QSS
        elif client == 'HEROTEL':
            steps     = self._HEROTEL_STEPS
            btn_label = 'herotel'
            run_key   = 'herotel_run_all'
            run_label = '⚡ Run All Steps'
            btn_qss   = _HEROTEL_BTN_QSS
        else:
            steps     = self._FT_STEPS
            btn_label = 'fibertime'
            run_key   = 'ft_run_all'
            run_label = '⚡ Run All Steps'
            btn_qss   = _FT_BTN_QSS

        # Dropdown button
        btn = QToolButton(tb)
        btn.setText(f'{btn_label} ▾')
        btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
        btn.setStyleSheet(btn_qss)

        menu = QMenu(btn)
        menu.setStyleSheet(
            f'QMenu {{ background: {_PANEL}; color: {_TEXT};'
            f' border: 1px solid {_BORDER}; padding: 4px; }}'
            f'QMenu::item {{ padding: 5px 18px; border-radius: 3px; }}'
            f'QMenu::item:selected {{ background: {_ACCENT}; color: {_BG}; }}'
            f'QMenu::separator {{ height: 1px; background: {_BORDER}; margin: 4px 8px; }}'
        )

        try:
            from fibre_automation.startup import STEP_MAP
        except Exception:
            STEP_MAP = {}

        for label, key in steps:
            action = menu.addAction(label)
            fn = STEP_MAP.get(key)
            if fn:
                action.triggered.connect(fn)
            else:
                action.setEnabled(False)

        menu.addSeparator()
        run_action = menu.addAction(run_label)
        run_fn = STEP_MAP.get(run_key)
        if run_fn:
            run_action.triggered.connect(run_fn)
        else:
            run_action.setEnabled(False)

        btn.setMenu(menu)
        self._automation_widget = btn

        # Insert BEFORE the erven_pipe action so it's always visible,
        # not buried after the absorbed fibretime_tools buttons.
        anchor = self._actions.get('erven_pipe')
        if anchor is not None:
            self._automation_action = tb.insertWidget(anchor, btn)
        else:
            self._automation_action = tb.addWidget(btn)

        btn.show()

    def _open_bridge_dock(self):
        """Find the VeloGIS Bridge QDockWidget and show/raise it.
        Falls back to searching by title if the plugin instance isn't reachable."""
        try:
            # Try via plugin registry first
            from qgis.utils import plugins as _plugins
            bp = _plugins.get('QGISBridgePlugin')
            if bp is not None:
                # Bridge plugin may expose its dock as _dock / dock / _dock_widget
                for attr in ('_dock', 'dock', '_dock_widget', 'dock_widget'):
                    dock = getattr(bp, attr, None)
                    if dock is not None:
                        dock.setVisible(True)
                        dock.raise_()
                        return
        except Exception:
            pass
        # Fallback: search by title
        for dock in self.iface.mainWindow().findChildren(QDockWidget):
            title = dock.windowTitle() or ""
            if "VeloGIS" in title or "Bridge" in title:
                dock.setVisible(True)
                dock.raise_()
                return
        self.iface.messageBar().pushWarning(
            "Bridge", "VeloGIS Bridge dock not found — is QGISBridgePlugin loaded?")

    # ── Algorithm / script / macro runners ───────────────────────────────────
    def _log_and_push_critical(self, where, exc):
        """Log a failure to the error log AND surface it on the message bar
        with the Report-a-Problem pointer. Use in every except handler that
        a teammate can hit — a flashed message without a log entry is
        un-debuggable from their side."""
        try:
            try:
                from . import error_reporter
            except ImportError:
                import error_reporter
            error_reporter.log_error(where, exc)
        except Exception:
            pass
        # Nexus auto-capture: send the error + breadcrumbs to the team monitor
        # (silent; the operator's deliberate Report-a-Problem still works too).
        try:
            if getattr(self, '_nexus', None) is not None:
                self._nexus.report_error(where, exc)
        except Exception:
            pass
        self.iface.messageBar().pushCritical(
            where,
            f'{exc} — logged. Velocity Nexus menu → Report a Problem '
            'to send it to support.')

    def _run_algo(self, algo_id, entry_id):
        """Open the Processing dialog so user can tweak params."""
        import processing
        from qgis.core import Qgis
        act = self._actions.get(entry_id)
        if act: act.setEnabled(False)
        mb = self.iface.messageBar()
        running = mb.createMessage(entry_id, f"Running {algo_id} …")
        mb.pushWidget(running, Qgis.MessageLevel.Info)
        QApplication.processEvents()
        try:
            processing.execAlgorithmDialog(algo_id, {})
            mb.pushSuccess(entry_id, f"{algo_id} ✓")
        except Exception as e:
            self._log_and_push_critical(f'algorithm {algo_id}', e)
        finally:
            try: mb.popWidget(running)   # never leave a stale "Running…" banner
            except Exception: pass
            if act: act.setEnabled(True)

    def _run_script(self, script_path, entry_id):
        # Resolve robustly: the spec path is the dev location; on a team install fall back to the
        # copy bundled inside the plugin (same basename). Never fail with a cryptic file-not-found.
        if not os.path.exists(script_path):
            alt = os.path.join(os.path.dirname(__file__), os.path.basename(script_path))
            if os.path.exists(alt):
                script_path = alt
            else:
                self.iface.messageBar().pushWarning(
                    entry_id, f"{os.path.basename(script_path)} not found (not bundled).")
                return
        from qgis.PyQt.QtCore import Qt
        from qgis.core import Qgis
        act = self._actions.get(entry_id)
        if act: act.setEnabled(False)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        mb = self.iface.messageBar()
        running = mb.createMessage(
            entry_id, f"Running {os.path.basename(script_path)} …")
        mb.pushWidget(running, Qgis.MessageLevel.Info)
        QApplication.processEvents()
        try:
            with open(script_path, encoding='utf-8') as _f:
                _src = _f.read()
            exec(_src, {'__name__': '__audit_script__'})
            mb.pushSuccess(
                entry_id, f"{os.path.basename(script_path)} ✓ (Ctrl+Alt+P for output)")
        except Exception as e:
            self._log_and_push_critical(entry_id, e)
        finally:
            QApplication.restoreOverrideCursor()
            try: mb.popWidget(running)   # clear the stale "Running…" banner
            except Exception: pass
            if act: act.setEnabled(True)

    def _run_clean_buildings(self, silent_if_missing=False):
        """Auto-discover Buildings + Erven layers and run cleanbuildings (1 building per erven).

        silent_if_missing: if True, return quietly when layers are absent or empty
                           (used for auto-fire at project startup for all 3 clients).
        """
        import processing
        from qgis.core import QgsProject, QgsWkbTypes, QgsProcessingFeedback
        from qgis.PyQt.QtWidgets import QProgressBar

        # --- Layer discovery: works for Vuma, Fibertime and HeroTel ---
        buildings_lyr = None
        erven_lyr = None
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                if lyr.geometryType() != QgsWkbTypes.GeometryType.PolygonGeometry:
                    continue
            except Exception:
                continue
            name_lower = lyr.name().lower()
            if 'building' in name_lower and buildings_lyr is None:
                buildings_lyr = lyr
            elif 'erven' in name_lower and erven_lyr is None:
                erven_lyr = lyr

        if buildings_lyr is None or erven_lyr is None:
            if not silent_if_missing:
                missing = []
                if buildings_lyr is None:
                    missing.append('Buildings')
                if erven_lyr is None:
                    missing.append('Erven')
                self.iface.messageBar().pushWarning(
                    'Clean Buildings',
                    f"Layer(s) not found: {', '.join(missing)}. Run Setup / Erven Generator first."
                )
            return

        total = buildings_lyr.featureCount()
        if total == 0:
            if not silent_if_missing:
                self.iface.messageBar().pushInfo(
                    'Clean Buildings', 'Buildings layer is empty — nothing to clean.'
                )
            return

        erven_count = erven_lyr.featureCount()

        # Interactive runs only: confirm before deleting (the startup auto-fire
        # passes silent_if_missing=True and must never prompt).
        if not silent_if_missing:
            from qgis.PyQt.QtWidgets import QMessageBox
            if QMessageBox.question(
                    self.iface.mainWindow(), 'Clean Buildings',
                    f"Reduce {total:,} buildings to one per erf "
                    f"({erven_count:,} erven)?\n\nThis deletes the extra "
                    "building polygons — make sure your layers are backed up.",
                    QMessageBox.StandardButton.Yes
                    | QMessageBox.StandardButton.Cancel,
                    QMessageBox.StandardButton.Cancel
            ) != QMessageBox.StandardButton.Yes:
                return

        # --- Embed a live progress bar in the message bar ---
        msg_item = self.iface.messageBar().createMessage(
            'Clean Buildings',
            f'Cleaning {total:,} buildings across {erven_count:,} erven…'
        )
        prog = QProgressBar()
        prog.setMinimum(0)
        prog.setMaximum(100)
        prog.setValue(0)
        prog.setFixedWidth(200)
        prog.setFormat('%p%')
        prog.setTextVisible(True)
        msg_item.layout().addWidget(prog)
        self.iface.messageBar().pushWidget(msg_item, level=Qgis.MessageLevel.Info, duration=0)
        QApplication.processEvents()

        # --- Custom feedback wired to the progress bar ---
        class _ProgressFeedback(QgsProcessingFeedback):
            def setProgress(self, progress):
                super().setProgress(progress)
                prog.setValue(int(progress))
                QApplication.processEvents()

        feedback = _ProgressFeedback()

        try:
            processing.run('fibernetwork:cleanbuildings', {
                'BUILDINGS': buildings_lyr,
                'ERVENS':    erven_lyr,
            }, feedback=feedback)
            remaining = buildings_lyr.featureCount()
            removed = total - remaining
            self.iface.messageBar().clearWidgets()
            self.iface.messageBar().pushSuccess(
                'Clean Buildings',
                f'Done — {removed:,} duplicate(s) removed, {remaining:,} buildings kept (1 per erven).'
            )
        except Exception as exc:
            self.iface.messageBar().clearWidgets()
            self._log_and_push_critical('Clean Buildings', exc)

    def _run_ft_pipeline(self):
        """Run FT1..7 (incl. FT4b) sequentially."""
        import processing
        pipeline = [
            ("FT1 Label Poles",            "fibernetwork:ft_label_poles"),
            ("FT2 Distribution Cable",     "fibernetwork:ft_label_distribution_cable"),
            ("FT3 Secondary Cable",        "fibernetwork:ft_label_secondary_cable"),
            ("FT4 Enclosure",              "fibernetwork:ft_label_enclosure"),
            ("FT4b STS Splitters",         "fibernetwork:ft_label_sts_splitters"),
            ("FT5 Generate PON Zones",     "fibernetwork:ft_generate_pon_zones"),
            ("FT6 Apply PON Order",        "fibernetwork:ft_apply_pon_order"),
            ("FT7 Pole Thickness",         "fibernetwork:ft_pole_thickness"),
        ]
        from qgis.PyQt.QtCore import Qt
        try:
            try:
                from .ux import StepProgress
            except ImportError:
                from ux import StepProgress
        except Exception:
            StepProgress = None
        # Pre-flight: warn (don't block) if FT6/FT7 inputs are missing, and
        # confirm — Run-All rewrites labels/attributes across the project.
        from qgis.PyQt.QtWidgets import QMessageBox
        warn = []
        try:
            from fibre_automation.shared import vf_paths
            if not os.path.exists(vf_paths.data_file('pon_feeder_order.txt')):
                warn.append("•  FT6 needs the PON feeder order — record it with "
                            "🔴 Record PON Order first, or FT6 will be wrong.")
            if not os.path.exists(vf_paths.roads_json()):
                warn.append("•  FT7 road-crossing needs roads.json — run /roads "
                            "first, or pole thickness skips road crossings.")
        except Exception:
            pass
        _msg = ("Run the full FT 1→7 pipeline?\n\nThis rewrites labels and "
                "attributes across Poles, Cables, Enclosures, PON/Zone and more.")
        if warn:
            _msg += "\n\nHeads-up:\n" + "\n".join(warn)
        if QMessageBox.question(
                self.iface.mainWindow(), "Run All FT 1→7", _msg,
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Cancel) != QMessageBox.StandardButton.Yes:
            return
        act = self._actions.get("ft_all")
        if act: act.setEnabled(False)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        ran = 0
        try:
            if StepProgress is not None:
                with StepProgress(self.iface, 'Run All FT 1→7',
                                  [n for n, _ in pipeline]) as prog:
                    for name, algo in pipeline:
                        if prog.canceled:
                            break
                        prog.step(name)
                        processing.run(algo, {})
                        ran += 1
                    prog.done()
            else:
                for name, algo in pipeline:
                    self.iface.messageBar().pushMessage(
                        "FT 1..7", f"{name} …", level=Qgis.MessageLevel.Info, duration=0)
                    QApplication.processEvents()
                    processing.run(algo, {})
                    ran += 1
            if ran == len(pipeline):
                self.iface.messageBar().pushSuccess(
                    "FT 1..7", f"✓ Ran all {ran} algorithms successfully")
            else:
                self.iface.messageBar().pushWarning(
                    "FT 1..7", f"Stopped after {ran}/{len(pipeline)} (cancelled)")
        except Exception as e:
            self._log_and_push_critical(f"FT 1..7 (step {ran + 1})", e)
        finally:
            QApplication.restoreOverrideCursor()
            if act: act.setEnabled(True)

    def _run_span_check(self):
        """Busy-cursor wrapper — the span walk can take a while on large
        projects; show a wait cursor so the UI reads as 'working', not frozen.
        The span maths + layer build are unchanged (in _span_check_impl)."""
        from qgis.PyQt.QtWidgets import QApplication
        from qgis.PyQt.QtGui import QCursor
        from qgis.PyQt.QtCore import Qt as _Qt
        QApplication.setOverrideCursor(QCursor(_Qt.CursorShape.WaitCursor))
        QApplication.processEvents()          # render the cursor before the walk
        try:
            self._span_check_impl()
        finally:
            QApplication.restoreOverrideCursor()

    def _span_check_impl(self):
        """Pole-to-pole span checker (v6, 2026-04-20).

        Produces a 'Span Violations' memory layer with one pink line per
        offending span. Thresholds:
          Drop / Spare Drop: 50 m · Distribution / Secondary / Primary: 70 m

        How it works:
          - Walks each v1 cable segment-by-segment.
          - For each segment's straight line, finds every pole within 5 m.
            (Matches physical reality: a cable running A→B is clamped to any
            pole its line passes within 5 m of, even if no vertex is drawn
            at that pole.)
          - Concatenates hits in along-cable order; collapses adjacent dupes
            (same pid at seg boundary) while preserving zig-zag re-visits.
          - For each consecutive pair, measures TRUE GEODESIC (ellipsoidal)
            distance via QgsDistanceArea (WGS84) — matches QGIS Measure
            tool. Prior versions used planar 111320 m/°, which over-inflated
            longitude by ~12% at MOA latitude.
          - Cables with <2 poles detected fall back to straight-line distance
            between first and last cable vertex (method='straight-endpoints').
        """
        from qgis.core import (QgsSpatialIndex, QgsFeature, QgsGeometry,
                                QgsVectorLayer, QgsField, QgsLineSymbol,
                                QgsRectangle, QgsDistanceArea,
                                QgsCoordinateReferenceSystem)
        from qgis.PyQt.QtCore import QMetaType
        import math
        M_DEG = 111320.0   # rough latitude metres per degree (dy only)
        SNAP_M = 5.0
        SNAP_DEG = SNAP_M / M_DEG

        # v6 (2026-04-20): use ellipsoidal distance via QgsDistanceArea to match
        # what QGIS Measure tool reports. Prior versions treated longitude and
        # latitude as equal metres-per-degree which inflated spans ~12% at MOA
        # latitude (cos(-26.74°) ≈ 0.893). Fix: compute dx using cos(lat), or
        # use QgsDistanceArea for true geodesic distance.
        _da = QgsDistanceArea()
        _da.setEllipsoid("WGS84")
        _da.setSourceCrs(QgsCoordinateReferenceSystem("EPSG:4326"),
                         QgsProject.instance().transformContext())

        def _geodesic_m(pa, pb):
            """True ellipsoidal metres between two WGS84 points."""
            return _da.measureLine([pa, pb])

        def _seg_dist_m(pt_xy, a, b):
            """Perpendicular distance pt→segment(a,b) in metres (corrected)."""
            seg = QgsGeometry.fromPolylineXY([a, b])
            # For distance-to-segment we still use planar approx but with the
            # longitude correction applied. For short cable segments this is
            # accurate to better than 1 cm.
            d_deg = seg.distance(QgsGeometry.fromPointXY(pt_xy))
            cos_lat = math.cos(math.radians((a.y()+b.y())/2))
            # Planar distance mixes dx and dy; use geometric mean scale.
            return d_deg * M_DEG * cos_lat  # conservative: use lon scale
        def _seg_along_m(pt_xy, a, b):
            ax, ay = a.x(), a.y(); bx, by = b.x(), b.y()
            dx, dy = (bx-ax), (by-ay)
            seg_len2 = dx*dx + dy*dy
            if seg_len2 == 0: return 0.0
            t = max(0.0, min(1.0, ((pt_xy.x()-ax)*dx + (pt_xy.y()-ay)*dy) / seg_len2))
            return t * _geodesic_m(a, b)
        THRESH = {
            "drop cable v1":         50.0,
            "spare drop cable v1":   50.0,
            "distribution cable v1": 70.0,
            "secondary cable v1":    70.0,
            "primary cable v1":      70.0,
        }
        act = self._actions.get("span_check")
        if act: act.setEnabled(False)
        self.iface.messageBar().pushMessage(
            "Span Check", "Scanning pole-to-pole spans …", level=Qgis.MessageLevel.Info, duration=0)
        QApplication.processEvents()
        try:
            proj = QgsProject.instance()
            pole_lyr = next((l for l in proj.mapLayers().values()
                             if l.name().lower() == "poles v1"), None)
            if not pole_lyr:
                self.iface.messageBar().pushCritical(
                    "Span Check", "Poles v1 layer not found.")
                return
            pole_index = QgsSpatialIndex()
            pole_pt = {}
            for f in pole_lyr.getFeatures():
                g = f.geometry()
                if not g or g.isEmpty(): continue
                pole_pt[f.id()] = (str(f["Label"] or "").strip(), g.asPoint())
                pf = QgsFeature(f.id())
                pf.setGeometry(g)
                pole_index.addFeature(pf)

            # remove existing violation layer
            for l in list(proj.mapLayers().values()):
                if l.name() == "Span Violations":
                    proj.removeMapLayer(l.id())

            crs = pole_lyr.crs().authid()
            mem = QgsVectorLayer(f"LineString?crs={crs}", "Span Violations", "memory")
            mp = mem.dataProvider()
            mp.addAttributes([
                QgsField("source",     QMetaType.Type.QString),
                QgsField("cable_lbl",  QMetaType.Type.QString),
                QgsField("pole_a",     QMetaType.Type.QString),
                QgsField("pole_b",     QMetaType.Type.QString),
                QgsField("span_m",     QMetaType.Type.Double),
                QgsField("threshold",  QMetaType.Type.Double),
                QgsField("excess_m",   QMetaType.Type.Double),
                QgsField("method",     QMetaType.Type.QString),
            ])
            mem.updateFields()

            feats = []
            per_layer = {}
            for lname, max_span in THRESH.items():
                lyr = next((l for l in proj.mapLayers().values()
                            if l.name().lower() == lname), None)
                if not lyr: continue
                n_viol = 0
                for f in lyr.getFeatures():
                    g = f.geometry()
                    if not g or g.isEmpty(): continue
                    try: cable_lbl = str(f["label"])
                    except (KeyError, IndexError): cable_lbl = f"fid={f.id()}"
                    lines = g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]
                    for line in lines:
                        if len(line) < 2: continue
                        # v5 (2026-04-20): per-segment-line detection.
                        # A pole is ATTACHED wherever it sits within SNAP_M of a
                        # cable SEGMENT LINE (not just at a drawn vertex). This
                        # matches physical reality: a cable running straight
                        # from A to B is clamped at every pole its line passes
                        # within arm's reach of — even if the drawing only has
                        # vertices at A and B. v4 was too strict (demanded
                        # vertex); v3 had wrong dedup on zigzag.
                        cable_poles = []
                        cum = 0.0
                        for i in range(len(line)-1):
                            a = line[i]; b = line[i+1]
                            seg_len_m = _geodesic_m(a, b)
                            bbox = QgsRectangle(
                                min(a.x(),b.x())-SNAP_DEG, min(a.y(),b.y())-SNAP_DEG,
                                max(a.x(),b.x())+SNAP_DEG, max(a.y(),b.y())+SNAP_DEG)
                            sp = []
                            for pid in pole_index.intersects(bbox):
                                lbl, ppt = pole_pt[pid]
                                if _seg_dist_m(ppt, a, b) < SNAP_M:
                                    sp.append((_seg_along_m(ppt, a, b), lbl, ppt, pid))
                            sp.sort()
                            for along, lbl, ppt, pid in sp:
                                cable_poles.append((cum + along, lbl, ppt, pid))
                            cum += seg_len_m

                        # Collapse IMMEDIATELY consecutive same-pid entries
                        # (same pole detected at seg boundary). Preserves
                        # re-visits on zigzag loops.
                        collapsed = []
                        for entry in cable_poles:
                            if collapsed and collapsed[-1][3] == entry[3]:
                                continue
                            collapsed.append(entry)

                        if len(collapsed) < 2:
                            pa = line[0]; pb = line[-1]
                            span = _geodesic_m(pa, pb)
                            if span > max_span:
                                nf = QgsFeature(mem.fields())
                                nf.setGeometry(QgsGeometry.fromPolylineXY([pa, pb]))
                                nf.setAttributes([lyr.name(), cable_lbl, "", "",
                                                  round(span,1), max_span,
                                                  round(span-max_span,1),
                                                  "straight-endpoints"])
                                feats.append(nf); n_viol += 1
                            continue
                        for j in range(len(collapsed)-1):
                            _, la, pa, _ = collapsed[j]
                            _, lb, pb, _ = collapsed[j+1]
                            span = _geodesic_m(pa, pb)
                            if span > max_span:
                                nf = QgsFeature(mem.fields())
                                nf.setGeometry(QgsGeometry.fromPolylineXY([pa, pb]))
                                nf.setAttributes([lyr.name(), cable_lbl, la, lb,
                                                  round(span,1), max_span,
                                                  round(span-max_span,1),
                                                  "pole-to-pole"])
                                feats.append(nf); n_viol += 1
                per_layer[lyr.name()] = n_viol

            mp.addFeatures(feats)
            mem.updateExtents()
            sym = QgsLineSymbol.createSimple({"color": "#ff0066", "width": "1.5",
                                              "capstyle": "round"})
            mem.renderer().setSymbol(sym)
            proj.addMapLayer(mem)
            if feats:
                self.iface.mapCanvas().setExtent(mem.extent().buffered(50 / M_DEG))
            self.iface.mapCanvas().refresh()

            summary = " · ".join(f"{k.replace(' v1','')}:{v}"
                                 for k, v in per_layer.items() if v > 0)
            self.iface.messageBar().pushSuccess(
                "Span Check", f"✓ {len(feats)} violations — {summary or 'none'}")
        except Exception as e:
            self._log_and_push_critical("Span Check", e)
        finally:
            if act: act.setEnabled(True)

    def _run_update_layers(self):
        """Run the post-edit attribute refresh pipeline."""
        act = self._actions.get("update_layers")
        if act: act.setEnabled(False)
        self.iface.messageBar().pushMessage(
            "Update Layers", "Running attribute refresh across layers …",
            level=Qgis.MessageLevel.Info, duration=0)
        QApplication.processEvents()
        scripts = [
            "C:/Temp/prod_strtfeat_fix.py",
            "C:/Temp/drop_fix.py",
            "C:/Temp/sdrop_strtfeat_fix.py",
            "C:/Temp/ont_fix.py",
            "C:/Temp/sts_full_fix.py",
        ]
        try:
            ok = 0; failed = []; missing = []
            for s in scripts:
                if not os.path.exists(s):
                    missing.append(os.path.basename(s)); continue
                try:
                    with open(s, encoding='utf-8') as _f:
                        exec(_f.read(), {'__name__': '__update__'})
                    ok += 1
                except Exception as e:
                    # Per-script try/except — one failing script shouldn't kill the chain
                    failed.append(f"{os.path.basename(s)}: {type(e).__name__}: {e}")
            if failed:
                self.iface.messageBar().pushWarning(
                    "Update Layers",
                    f"{ok}/{len(scripts)} OK · {len(failed)} failed · {len(missing)} missing — check Console")
                from qgis.core import QgsMessageLog
                for line in failed:
                    QgsMessageLog.logMessage(line, "Update Layers", level=Qgis.MessageLevel.Critical)
            elif ok == 0:
                # nothing ran — saying "✓ Refreshed" here would be a lie
                self.iface.messageBar().pushWarning(
                    "Update Layers",
                    "No refresh scripts found on this machine "
                    f"({len(missing)} missing from C:/Temp) — nothing was "
                    "updated. These are dev-machine fix scripts.")
            else:
                self.iface.messageBar().pushSuccess(
                    "Update Layers",
                    f"✓ Refreshed {ok}/{len(scripts)} scripts" +
                    (f" ({len(missing)} missing)" if missing else ""))
        except Exception as e:
            self._log_and_push_critical("Update Layers", e)
        finally:
            if act: act.setEnabled(True)

    # ── Direct callbacks (used by tools + quick actions) ─────────────────────
    def _select_client_vuma(self):
        """Toolbar client-selector: set client to VUMA and trigger dock update."""
        dock = self._get_bridge_dock()
        if dock:
            try:
                dock._select_client('VUMA')
                return
            except Exception:
                pass
        # Fallback — no dock available, update toolbar directly
        self._rebuild_automation_group('VUMA')
        self._lock_dock_to_client('VUMA')

    def _select_client_ft(self):
        """Toolbar client-selector: set client to FT and trigger dock update."""
        dock = self._get_bridge_dock()
        if dock:
            try:
                dock._select_client('FT')
                return
            except Exception:
                pass
        self._rebuild_automation_group('FT')
        self._lock_dock_to_client('FT')

    def _run_q(self):
        QApplication.clipboard().setText("exec(open('C:/Temp/q.py').read())")
        self.iface.messageBar().pushMessage(
            '⚙️ Run q.py', 'Copied — paste in Python Console (Ctrl+V)',
            level=Qgis.MessageLevel.Info, duration=3)

    def _update_from_github(self):
        """One-click 'git pull' on the VeloPlan repo clone + live plugin reload.

        Lets anyone (e.g. a colleague who just pulls) get the newest code from
        GitHub without touching a command line. The repo location is remembered
        in QSettings; first use prompts for it.
        """
        import os
        import shutil
        import subprocess
        from qgis.PyQt.QtCore import QSettings, QTimer
        from qgis.PyQt.QtWidgets import QMessageBox, QFileDialog

        mw = self.iface.mainWindow()
        s = QSettings()
        key = 'FiberNetworkAutomation/repo_path'
        repo = s.value(key, '', type=str)

        def _valid(p):
            return bool(p) and os.path.isdir(os.path.join(p, '.git')) \
                and os.path.isdir(os.path.join(p, 'FiberNetworkAutomation'))

        # First use (or stale path) → ask for the VeloPlan clone folder
        if not _valid(repo):
            picked = QFileDialog.getExistingDirectory(
                mw, 'Select your VeloPlan repo folder (the clone containing .git)')
            if not picked:
                return
            if not _valid(picked):
                QMessageBox.warning(
                    mw, 'Update from GitHub',
                    'That folder is not a VeloPlan git clone.\n'
                    'Pick the folder that contains a ".git" folder and a '
                    '"FiberNetworkAutomation" subfolder.')
                return
            repo = picked
            s.setValue(key, repo)

        # 1. git pull (fast-forward only — clean for pull-only users)
        try:
            res = subprocess.run(
                ['git', '-C', repo, 'pull', '--ff-only'],
                capture_output=True, text=True, timeout=180)
        except FileNotFoundError:
            QMessageBox.critical(mw, 'Update from GitHub',
                                 'Git is not installed / not on PATH.')
            return
        except Exception as e:
            QMessageBox.critical(mw, 'Update from GitHub', f'git pull failed:\n{e}')
            return
        if res.returncode != 0:
            QMessageBox.critical(mw, 'Update from GitHub',
                                 f'git pull failed:\n\n{res.stderr.strip()}')
            return
        pull_msg = (res.stdout.strip() or 'Already up to date.')

        # 2. Copy the updated plugin into the installed location (this folder),
        #    unless the plugin is already running from the clone itself.
        src = os.path.join(repo, 'FiberNetworkAutomation')
        dst = os.path.dirname(os.path.abspath(__file__))
        copied = False
        if os.path.normcase(os.path.normpath(src)) != \
           os.path.normcase(os.path.normpath(dst)):
            try:
                shutil.copytree(
                    src, dst, dirs_exist_ok=True,
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
                copied = True
            except Exception as e:
                QMessageBox.critical(mw, 'Update from GitHub',
                                     f'Pulled OK but copy failed:\n{e}')
                return

        # 3. Reload the plugin AFTER this handler returns (it is part of the
        #    plugin being unloaded), via the 3-step that re-registers the
        #    processing provider (reloadPlugin alone does not).
        def _do_reload():
            try:
                from qgis.utils import unloadPlugin, loadPlugin, startPlugin
                unloadPlugin('FiberNetworkAutomation')
                loadPlugin('FiberNetworkAutomation')
                startPlugin('FiberNetworkAutomation')
                self.iface.messageBar().pushMessage(
                    '⬇ Update', 'Reloaded with the latest code from GitHub.',
                    level=Qgis.MessageLevel.Info, duration=4)
            except Exception as e:
                self.iface.messageBar().pushCritical('⬇ Update', f'Reload failed: {e}')

        QMessageBox.information(
            mw, 'Update from GitHub',
            f'{pull_msg}\n\n'
            + ('Plugin files updated. ' if copied else '')
            + 'Reloading FiberNetworkAutomation now…')
        QTimer.singleShot(300, _do_reload)

    def _exec_erven_pipeline(self, action):
        script = r"C:/Users/jjsch/OneDrive - blitzfibre.com/Documents/Workspace/QGIS/run_erven_pipeline.py"
        btn_ids = ("erven_pipe", "erven_continue")
        for bid in btn_ids:
            a = self._actions.get(bid)
            if a: a.setEnabled(False)
        QApplication.processEvents()
        try:
            with open(script, encoding="utf-8") as _f:
                _code = compile(_f.read(), script, "exec")
            exec(_code, {"__name__": "__main__", "ACTION": action})
        except Exception as e:
            self._log_and_push_critical('Erven Pipeline', e)
        finally:
            for bid in btn_ids:
                a = self._actions.get(bid)
                if a: a.setEnabled(True)

    def _run_erven_pipeline(self):
        self._exec_erven_pipeline("start")

    def _continue_erven_pipeline(self):
        self._exec_erven_pipeline("continue")

    def _open_pole_editor(self):
        from qgis.PyQt import sip
        dock = getattr(self, '_pole_editor_dock', None)
        if dock is not None and not sip.isdeleted(dock):
            dock.setVisible(True); dock.raise_()
            if dock.isFloating():
                dock.activateWindow()
            return
        lyr = next(
            (l for l in QgsProject.instance().mapLayers().values()
             if 'poles v1' in l.name().lower()),
            None)
        if not lyr:
            self.iface.messageBar().pushWarning('Pole Editor', 'No "poles v1" layer found.')
            return
        panel = PoleEditorPanel(self.iface, lyr)
        self._pole_editor_panel = panel
        # interactive editor → finalize+destroy on close (delete-on-close dock runs _teardown)
        self._pole_editor_dock = self._dock_panel(
            panel, '🔧 Pole Editor', 'VFPoleEditorDock',
            on_close=panel._teardown, delete_on_close=True, float_size=(380, 660))
        self._pole_editor_dock.destroyed.connect(
            lambda *_: (setattr(self, '_pole_editor_dock', None),
                        setattr(self, '_pole_editor_panel', None)))
        # Summary counts — guard the field reads so a non-standard poles schema
        # (missing dim2 / thickness_) can't crash the editor on open.
        try:
            names = lyr.fields().names()
            thick = (sum(1 for f in lyr.getFeatures() if str(f['dim2']) == '140-160mm')
                     if 'dim2' in names else 0)
            rc = (sum(1 for f in lyr.getFeatures()
                      if 'road crossing' in str(f['thickness_']).lower())
                  if 'thickness_' in names else 0)
            self.iface.messageBar().pushMessage(
                '🔧 Pole Editor', f'{thick} thick (blue) · {rc} road crossings (green)',
                level=Qgis.MessageLevel.Info, duration=4)
        except Exception:
            pass

    def _dock_util(self):
        """The shared dock opener (bundled under fibre_automation)."""
        try:
            try:
                from .fibre_automation import dock_util
            except ImportError:
                from fibre_automation import dock_util
            return dock_util
        except Exception:
            return None

    def _dock_panel(self, content, title, object_name, on_close=None,
                    area=None, floating=False, float_size=(440, 820),
                    delete_on_close=False):
        """Host any content QWidget in a dockable + scrollable QGIS dock (see
        _PanelDock). Opens FULLY docked on a side (full height + a sensible
        width, raised) via dock_util.dock_fully — never a half floating window
        that needs a re-snap. Pass floating=True for the rare panel that must
        float. delete_on_close=True → closing DESTROYS it (finalize-on-close
        editors); default just hides (re-openable)."""
        from qgis.PyQt.QtWidgets import QScrollArea
        dock = _PanelDock(title, self.iface, on_close=on_close)
        dock.setObjectName(object_name)
        if delete_on_close:
            dock.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidget(content)
        dock.setWidget(scroll)
        area = area or Qt.DockWidgetArea.RightDockWidgetArea
        du = self._dock_util()
        if du is not None:
            du.dock_fully(self.iface, dock, area=area,
                          width=float_size[0], prefer_float=floating)
        else:                                   # fallback: at least dock it
            self.iface.addDockWidget(area, dock)
        return dock

    def _open_building_review(self):
        """Open the human-in-the-loop Detected Buildings review dock. Every
        keep/delete/fix is logged to corrections.gpkg (active-learning fuel)."""
        try:
            try:
                from .review_dock import open_building_review
            except ImportError:
                from review_dock import open_building_review
            open_building_review(self)
        except Exception as exc:
            try:
                try:
                    from . import error_reporter
                except ImportError:
                    import error_reporter
                error_reporter.log_error("Open Review Buildings", exc)
            except Exception:
                pass

    def _open_route_viewer(self):
        from qgis.PyQt import sip
        dock = getattr(self, '_route_viewer_dock', None)
        if dock is not None and not sip.isdeleted(dock):
            dock.setVisible(True); dock.raise_()
            if dock.isFloating():
                dock.activateWindow()
            return
        self._route_viewer_panel = SpliceRouteViewerPanel(self.iface)
        # dock-close just HIDES (cleanup runs on plugin unload), so re-opening the
        # same dock keeps the Excel poll + identify handlers working.
        self._route_viewer_dock = self._dock_panel(
            self._route_viewer_panel, '🔦 Splice Route Viewer',
            'VFSpliceRouteViewerDock', float_size=(440, 820))
        n = len(self._route_viewer_panel._idx['ports'])
        if n:
            self.iface.messageBar().pushMessage(
                '🔦 Route Viewer',
                f'{n} OLT ports loaded — pick one to light its fibre route. '
                'Drag the title bar to dock it on any edge.',
                level=Qgis.MessageLevel.Info, duration=5)
        else:
            self.iface.messageBar().pushWarning(
                '🔦 Route Viewer',
                'No FTS Splitters layer in this project — open the splice project.')

    def _open_enc_editor(self):
        from qgis.PyQt import sip
        dock = getattr(self, '_enc_editor_dock', None)
        if dock is not None and not sip.isdeleted(dock):
            dock.setVisible(True); dock.raise_()
            if dock.isFloating():
                dock.activateWindow()
            return
        panel = EnclosureEditorPanel(self.iface)
        self._enc_editor_panel = panel
        # interactive editor → finalize+destroy on close (delete-on-close dock runs _teardown)
        self._enc_editor_dock = self._dock_panel(
            panel, '🧰 Enclosure Editor', 'VFEncEditorDock',
            on_close=panel._teardown, delete_on_close=True, float_size=(400, 680))
        self._enc_editor_dock.destroyed.connect(
            lambda *_: (setattr(self, '_enc_editor_dock', None),
                        setattr(self, '_enc_editor_panel', None)))
        conn = next((l for l in QgsProject.instance().mapLayers().values()
                     if l.name() == 'Enclosures Connectorised v1'), None)
        splice = next((l for l in QgsProject.instance().mapLayers().values()
                       if l.name() == 'Enclosures Splice v1'), None)
        if not conn and not splice:
            self.iface.messageBar().pushWarning(
                'Enclosure Editor', 'No Enclosure layers found.')
            return
        parts = []
        if conn:
            feats = list(conn.getFeatures())
            n_spur = sum(1 for f in feats if str(f['spec_1']) == 'M16 Microloop')
            parts.append(f'{len(feats) - n_spur} dist · {n_spur} spur')
        if splice:
            feats = list(splice.getFeatures())
            n_cmj = sum(1 for f in feats if str(f['spec_1']) == 'CMJ')
            parts.append(f'{len(feats) - n_cmj} UMJ · {n_cmj} CMJ')
        self.iface.messageBar().pushMessage(
            '🔲 Enclosure Editor', '  |  '.join(parts),
            level=Qgis.MessageLevel.Info, duration=4)

    def _snap_canvas(self):
        import subprocess
        path = 'C:/Temp/canvas.png'
        win = self.iface.mainWindow()
        screen = QApplication.primaryScreen()
        pixmap = screen.grabWindow(win.winId())
        if pixmap.width() > 900:
            pixmap = pixmap.scaledToWidth(900, Qt.TransformationMode.SmoothTransformation)
        pixmap.save(path, 'JPEG', 82)
        ps1 = r'C:\Temp\canvas_paste.ps1'
        if os.path.exists(ps1):
            subprocess.Popen(
                [r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                 '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ps1],
                creationflags=0x08000000)
        size = os.path.getsize(path)
        self.iface.messageBar().pushMessage(
            '📷 Canvas', f'Sent to Claude  ({size//1024} KB)',
            level=Qgis.MessageLevel.Info, duration=3)

    # ── Bridge status poller (brand tile lamp) ───────────────────────────────
    def _start_bridge_poller(self):
        self._bridge_timer = QTimer(self.iface.mainWindow())
        self._bridge_timer.setInterval(3000)  # 3s
        self._bridge_timer.timeout.connect(self._bridge_tick)
        self._bridge_timer.start()
        self._bridge_tick()  # immediate first check

    def _bridge_tick(self):
        """Scan ports 8765-8769 for live bridges, then verify the CURRENT port
        (from bridge_port.txt) is among them.

        Green  = current port is in the list of open bridge ports AND QGISBridgePlugin is loaded.
        Red    = current port is NOT a working bridge, even if other ports are open.

        Tooltip lists all available ports so user can switch to one.

        Note: socket.connect_ex() is used because urllib to our own bridge
        would deadlock (HTTP handler needs main thread we're blocking).
        Debouncing: 2 fails before flipping red."""
        if not self._brand_label:
            return
        import socket
        from qgis.utils import plugins as _plugins

        # Current port: the LOCAL bridge plugin's actual bound port. This is the
        # ONLY instance-specific truth — bridge_port.txt is one file shared by
        # every QGIS process and cannot distinguish them, so it is read only as
        # "which bridge is Claude pointed at", never as "which port am I on".
        current_port = None
        server_alive = None
        try:
            bp = _plugins.get('QGISBridgePlugin')
            srv = getattr(bp, '_server', None) if bp is not None else None
            if srv is not None:
                current_port = int(srv.port)
                # `running` is a PROPERTY (not a method) reporting whether the
                # serving thread is actually alive — a bound port with a dead
                # thread is "not responding", a different problem from "no
                # bridge here". Stays None if an older server object lacks it:
                # unknown must not masquerade as either answer.
                try:
                    server_alive = bool(srv.running)
                except Exception:
                    server_alive = None
        except Exception:
            pass
        # Separate question: which bridge has Claude been told to talk to?
        claude_port = None
        try:
            with open('C:/Temp/bridge_port.txt', 'r') as f:
                claude_port = int(f.read().strip())
        except Exception:
            pass

        # Scan 8765-8769 concurrently with NON-BLOCKING connects + a single bounded
        # select. The old version did 5 SEQUENTIAL blocking connects every 3s on the Qt
        # main thread, so a filtered/slow port stacked timeouts into a 3-4s UI freeze
        # (the #1 freeze on recent versions). This is behaviour-identical (same set of
        # locally-listening ports) but capped at one 0.3s select — pure socket, no Qt.
        import select as _select

        from .bridge_state import PORT_RANGE
        available_ports = []
        _pending = {}
        for p in PORT_RANGE:
            s = None
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.setblocking(False)
                rc = s.connect_ex(('127.0.0.1', p))
            except Exception:
                if s is not None:
                    try: s.close()
                    except Exception: pass
                continue
            if rc == 0:                       # connected immediately
                available_ports.append(p)
                s.close()
            else:                             # in progress (EWOULDBLOCK / EINPROGRESS)
                _pending[s] = p
        if _pending:
            try:
                _, _writable, _exc = _select.select([], list(_pending), list(_pending), 0.3)
            except Exception:
                _writable = []
            for s in _writable:
                try:
                    if s.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR) == 0:
                        available_ports.append(_pending[s])
                except Exception:
                    pass
            for s in _pending:
                try: s.close()
                except Exception: pass
        available_ports.sort()

        from . import bridge_state as _bs
        bridge_plugin_loaded = _plugins.get('QGISBridgePlugin') is not None
        state = _bs.classify(
            polled=True,
            plugin_loaded=bridge_plugin_loaded,
            server_port=current_port,
            server_alive=server_alive,
            listening_ports=available_ports)

        # Debounce only ever DELAYS bad news; it can never show green early.
        if state == _bs.CONNECTED:
            self._bridge_fail_streak = 0
        else:
            self._bridge_fail_streak += 1
        prev = getattr(self, '_bridge_last_state', _bs.CONNECTING)
        state = _bs.apply_debounce(state, prev, self._bridge_fail_streak)

        try:
            self._set_bridge_status(state, current_port, available_ports,
                                    claude_port)
            self._bridge_last_state = state
            self._bridge_last_shown_alive = _bs.is_healthy(state)
        except RuntimeError:
            pass

    def _open_bridge_switcher(self):
        """Dev-only: choose which bridge Claude talks to (never this window's).

        Reached only when velocity_nexus/dev/bridge_switcher_enabled is on --
        with the flag absent the handler is never attached."""
        try:
            from qgis.core import QgsProject
            from qgis.utils import plugins as _plugins
            from .bridge_switcher import BridgeSwitcherDialog
            own_port = None
            bp = _plugins.get('QGISBridgePlugin')
            srv = getattr(bp, '_server', None) if bp is not None else None
            if srv is not None:
                own_port = int(srv.port)
            dlg = BridgeSwitcherDialog(
                self.iface.mainWindow(), own_port=own_port,
                own_project=QgsProject.instance().baseName())
            # WA_DeleteOnClose: read what we need from the dialog BEFORE exec()
            # returns and the C++ object is freed.
            if dlg.exec():
                chosen = dlg.chosen_port()
                if chosen is not None:
                    self.iface.messageBar().pushMessage(
                        'Bridge',
                        f'Claude now talks to port {chosen}. This window still '
                        f'runs its own bridge on '
                        f'{own_port if own_port is not None else "—"}.',
                        level=Qgis.MessageLevel.Info, duration=5)
                    self._bridge_tick()      # repaint immediately
        except Exception as e:
            self.iface.messageBar().pushMessage(
                'Bridge', f'Could not open the bridge picker: {e}',
                level=Qgis.MessageLevel.Warning, duration=6)

    def _set_bridge_status(self, state, port, available_ports=None,
                           claude_port=None):
        """Paint every bridge indicator from ONE decided state.

        `state` is a bridge_state constant, not a bool: "the bridge is loaded but
        not serving" and "there is no bridge here" are different problems and
        used to render identically."""
        from . import bridge_state as _bs
        available_ports = available_ports or []
        alive = _bs.is_healthy(state)
        colour = (_GREEN if alive else
                  _AMBER if state == _bs.DEGRADED else _RED)
        text, tip_line = _bs.describe(state, port, claude_port)

        # The home panel is the indicator this fixes: it was told a hardcoded
        # True once at startup and never updated. Now it is driven from the same
        # decided state as the toolbar, every tick. Guarded because the panel is
        # WA_DeleteOnClose — a closed dock leaves a dead C++ object behind, and
        # `is None` does not catch that.
        from qgis.PyQt import sip
        panel = getattr(self, '_home_panel', None)
        if panel is not None and not sip.isdeleted(panel):
            try:
                panel.set_bridge_state(state, port, claude_port, text)
            except (RuntimeError, AttributeError):
                pass

        if not self._brand_label:
            return
        # Badge: red knight (♞) brand mark, border reflects bridge status
        self._brand_label.setStyleSheet(
            f"QLabel {{ background: #0D1320; color: #EF4444;"
            f" font-family:'Segoe UI Symbol','Segoe UI'; font-weight:800;"
            f" font-size:17px;"
            f" border: 2px solid {colour}; border-radius: 4px;"
            f" padding: 1px 7px; }}")

        # Status label: text + colour
        if getattr(self, '_brand_status', None):
            self._brand_status.setText(text)
            self._brand_status.setStyleSheet(
                f"QLabel {{ color: {colour}; font-family:'Segoe UI';"
                f" font-size:10px; font-weight:700; padding: 2px 4px; }}")

        # Tooltip on the container — lists available ports for easy switching
        parent = self._brand_label.parentWidget()
        if parent is not None:
            avail_str = (", ".join(str(p) for p in available_ports)
                         if available_ports else "none")
            # Deliberately "answering", not "bridges": this is a socket probe,
            # and other local servers sit in the same range (the canvas mirror
            # answers on 8767). Calling them bridges would be a guess.
            tip = (f"VelocityFibre Bridge\n{tip_line}\n\n"
                   f"This window: port {port if port is not None else '—'}\n"
                   f"Claude → port {claude_port if claude_port is not None else '—'}\n"
                   f"Ports answering {_bs.PORT_MIN}-{_bs.PORT_MAX}: {avail_str}\n\n"
                   f"Click to open Bridge dock (switch ports)")
            try:
                parent.setToolTip(tip)
            except RuntimeError:
                pass

    # ── Retire the redundant fibretime_tools plugin (its toolbar buttons) ────
    def _retire_fibretime_tools(self):
        """Permanently remove the separate fibretime_tools toolbar buttons: disable that plugin
        (won't load on restart), unload it now, and remove any leftover FibretimeToolbar.
        Everything those buttons did lives in the published VeloPlan plugin."""
        try:
            from qgis.core import QgsSettings
            from qgis.PyQt.QtWidgets import QToolBar
            import qgis.utils as U
            QgsSettings().setValue('PythonPlugins/fibretime_tools', False)
            if 'fibretime_tools' in U.plugins:
                try:
                    U.unloadPlugin('fibretime_tools')
                except Exception:
                    pass
            for tb in self.iface.mainWindow().findChildren(QToolBar):
                if tb.objectName() == 'FibretimeToolbar' or tb.windowTitle() == 'Fibertime Tools':
                    self.iface.mainWindow().removeToolBar(tb)
                    tb.setParent(None); tb.deleteLater()
            # erven_qgis_plugin is absorbed as erven_detection/ (Phase 1) — retire it too
            QgsSettings().setValue('PythonPlugins/erven_qgis_plugin', False)
            if 'erven_qgis_plugin' in U.plugins:
                try:
                    U.unloadPlugin('erven_qgis_plugin')
                except Exception:
                    pass
        except Exception as e:
            print(f'[FiberNet] retire fibretime_tools failed: {e}')

    # ── Watchdog — re-absorb if fibretime toolbar reappears ──────────────────
    def _watchdog_check(self):
        try:
            from qgis.PyQt.QtWidgets import QToolBar
            for tb in self.iface.mainWindow().findChildren(QToolBar):
                if tb.objectName() == "FibretimeToolbar" and tb.isVisible() and tb.actions():
                    # A fresh visible fibretime toolbar — re-absorb (idempotent)
                    self._fibretime_absorbed = False
                    self._absorb_attempts = 0
                    self._absorb_fibretime_toolbar()
                    return
        except RuntimeError:
            pass

    # ── Absorb fibretime_tools toolbar into ours ─────────────────────────────
    def _absorb_fibretime_toolbar(self):
        """Move actions from FibretimeToolbar + VelocityFibreLogoBar onto our
        toolbar so the user has a single, flowing bar. Hides the originals."""
        from qgis.PyQt.QtWidgets import QToolBar
        if not self._toolbar:
            return
        mw = self.iface.mainWindow()
        ft_bar = None
        logo_bar = None
        for tb in mw.findChildren(QToolBar):
            n = tb.objectName()
            if n == "FibretimeToolbar":
                ft_bar = tb
            elif n == "VelocityFibreLogoBar":
                logo_bar = tb
        if ft_bar is None:
            # fibretime_tools not yet loaded — retry up to 10 times at 1s intervals
            self._absorb_attempts += 1
            if self._absorb_attempts < 10:
                from qgis.PyQt.QtCore import QTimer
                QTimer.singleShot(1000, self._absorb_fibretime_toolbar)
            return
        # Guard — don't absorb twice
        if getattr(self, "_fibretime_absorbed", False):
            return
        self._fibretime_absorbed = True
        self._absorbed_from = (ft_bar, logo_bar)

        # Idempotent absorb: collect texts already present on our toolbar
        # so re-runs don't duplicate. Also skip fibretime duplicates we retire.
        from qgis.PyQt.QtWidgets import QToolButton
        from qgis.PyQt.QtCore import Qt as _Qt
        # Fibertime items retired in favour of FNA equivalents (stronger impl).
        RETIRED = {"📏  Check Long Spans", "New Project"}
        existing = set()
        for a in self._toolbar.actions():
            t = a.text()
            if not t:
                w = self._toolbar.widgetForAction(a)
                if w is not None and hasattr(w, "text"):
                    t = w.text()
            if t: existing.add(t.strip())

        self._absorbed_ft_widgets = []       # QToolButtons (for styling)
        self._absorbed_ft_widget_acts = []   # QWidgetActions from addWidget() — use for visibility
        self._absorbed_ft_actions = []       # plain QActions — hidden/shown via act.setVisible()
        added = False
        for act in list(ft_bar.actions()):
            if isinstance(act, QWidgetAction):
                w = act.defaultWidget()
                if isinstance(w, QToolButton) and w.menu() is not None:
                    label = (w.text() or "").strip()
                    if label in existing:
                        continue
                    added = True
                    new_btn = QToolButton(self._toolbar)
                    new_btn.setText(w.text())
                    new_btn.setIcon(w.icon())
                    new_btn.setToolTip(w.toolTip())
                    new_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
                    new_btn.setToolButtonStyle(_Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
                    new_btn.setMenu(w.menu())
                    new_btn.setStyleSheet(_FT_BTN_QSS)
                    widget_act = self._toolbar.addWidget(new_btn)
                    self._absorbed_ft_widgets.append(new_btn)
                    self._absorbed_ft_widget_acts.append(widget_act)
                    existing.add(label)
            else:
                label = (act.text() or "").strip()
                if label in existing or label in RETIRED:
                    continue
                added = True
                self._toolbar.addAction(act)
                # Style the button if we can get a handle to it
                w = self._toolbar.widgetForAction(act)
                if w is not None and hasattr(w, "setToolButtonStyle"):
                    try:
                        w.setToolButtonStyle(_Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
                        w.setStyleSheet(_FT_BTN_QSS)
                    except Exception:
                        pass
                # Always store the action — setVisible on the action is reliable
                self._absorbed_ft_actions.append(act)
                existing.add(label)

        # Fully remove the original toolbars — not just hide, so QGIS can't re-show
        mw = self.iface.mainWindow()
        try: mw.removeToolBar(ft_bar)
        except RuntimeError: pass
        try: ft_bar.hide()
        except RuntimeError: pass
        if logo_bar is not None:
            try: mw.removeToolBar(logo_bar)
            except RuntimeError: pass
            try: logo_bar.hide()
            except RuntimeError: pass

        # Re-apply current client visibility so absorbed buttons respect Vuma/FT/None
        try:
            from fibre_automation.startup import SESSION
            current_client = (SESSION.get('client') or '').lower()
            self._update_toolbar_for_client(current_client or None)
        except Exception:
            self._update_toolbar_for_client(None)

    # ── Project session persistence ───────────────────────────────────────────
    def _heal_stranded_solo(self):
        """If the Splice Viewer's 'solo' dim was left active by a crash/hide (so the
        whole project is stranded at 15 % opacity), restore the saved originals and
        clear the flag. No-op when nothing is stranded. Fail-silent."""
        try:
            import json as _json
            from qgis.core import QgsProject
            val, ok = QgsProject.instance().readEntry('SpliceViewer', 'soloSaved', '')
            if not ok or not val:
                return 0
            saved = _json.loads(val)
            n = 0
            for lid, op in saved.items():
                l = QgsProject.instance().mapLayer(lid)
                if l is not None:
                    try:
                        if abs(l.opacity() - float(op)) > 1e-6:
                            l.setOpacity(float(op)); l.triggerRepaint()
                        n += 1
                    except Exception:
                        pass
            QgsProject.instance().removeEntry('SpliceViewer', 'soloSaved')
            if n:
                print(f"[FiberNet] healed stranded 'solo' dim — restored {n} layer opacities")
                try:
                    self.iface.mapCanvas().refresh()
                except Exception:
                    pass
            return n
        except Exception as e:
            print(f"[FiberNet] solo heal skipped: {e}")
            return 0

    def _on_project_read(self, *_args):
        """Restore SESSION from the project that was just opened."""
        try:
            from fibre_automation.startup import load_session_from_project, SESSION
            if load_session_from_project():
                client = SESSION.get('client') or ''
                print(f"[FiberNet] Session restored: {client} / {SESSION.get('area_code')}")
                self._rebuild_automation_group(client)
                # Lock the bridge dock to this project's client
                self._lock_dock_to_client(client)
            else:
                # No stored session → collapse to Setup Project only
                self._update_toolbar_for_client(None)
                self._lock_dock_to_client('')
        except Exception as e:
            print(f'[FiberNet] session restore failed: {e}')
        # Self-heal basemaps: a project saved on a newer QGIS (4.0/Qt6) embeds its
        # XYZ tile layers with datasource cruft an OLDER QGIS (3.40/3.44) can't
        # round-trip, so the basemap opens as an INVALID "bad layer" and looks
        # deleted. Rebuild any such layer from a portable URI. No-op on the machine
        # that saved the project (everything already valid). Fail-silent.
        try:
            from fibre_automation import basemaps
            n_healed = basemaps.heal_basemaps()
            if n_healed:
                print(f"[FiberNet] healed {n_healed} basemap(s) after cross-version open")
        except Exception as e:
            print(f"[FiberNet] basemap heal skipped: {e}")
        # Self-heal a stranded Splice-Viewer 'solo' dim (project saved/opened with all
        # vector layers at 15 % because the viewer was closed/crashed mid-solo).
        self._heal_stranded_solo()
        # Re-point the home panel at the project just opened — its context strip
        # (name + live counts) and step "you are here" are driven by
        # QgsProject.instance(), so a project switch must refresh them. Without
        # this the panel keeps showing the previous project's name/counts until a
        # layer happens to be added/removed.
        self._refresh_home_steps()
        # Render-only smoothing for heavy layers (faster pan/zoom; data untouched).
        # Toggleable in ⚙ Settings & Help; fail-silent.
        try:
            from fibre_automation import ui_smooth
            n = ui_smooth.apply()
            ui_smooth.apply_canvas(self.iface)          # parallel render + caching
            if n:
                print(f"[FiberNet] render smoothing applied to {n} heavy layer(s)")
        except Exception as e:
            print(f"[FiberNet] render smoothing skipped: {e}")

    def _on_project_cleared(self, *_args):
        """Clear SESSION when the project is cleared (startup or File → New).
        The welcome dialog is triggered separately by iface.newProjectCreated,
        which only fires on explicit user-initiated new project, not on startup.
        """
        try:
            from fibre_automation.startup import clear_session
            clear_session()
            print('[FiberNet] Session cleared (new project)')
        except Exception as e:
            print(f'[FiberNet] session clear failed: {e}')
        # Collapse toolbar to brand only
        try:
            self._update_toolbar_for_client(None)
            self._rebuild_automation_group('')
        except Exception:
            pass
        # Unlock the bridge dock so the user can pick a client for the new project
        self._lock_dock_to_client('')
        # Reset the home panel to the now-empty project (no name, zero counts)
        self._refresh_home_steps()

    def _show_welcome_dialog(self):
        """Centered project-setup wizard — always shown on every new/blank project.

        Non-modal so the planner can drag-and-drop an AOI shapefile into the
        Layers panel while the dialog is open.  A blinking arrow to the left of
        the dialog points at the Layers panel with "Drag & drop AOI" text.
        When a polygon layer lands in the project the AOI combo is auto-filled
        and the arrow dismissed.  On "Start Project" the full step-01 pipeline
        (layers + basemap + Overture) is kicked off for the chosen client.
        """
        from qgis.PyQt.QtWidgets import (QVBoxLayout, QHBoxLayout,
                                          QPushButton, QLabel, QLineEdit,
                                          QComboBox, QFrame, QSizePolicy)
        from qgis.PyQt.QtCore import Qt, QPoint, QTimer

        mw = self.iface.mainWindow()

        # ── Kill any existing welcome dialog + arrow (singleton pattern) ──────
        _prev = getattr(self, '_welcome_dlg', None)
        if _prev is not None:
            try:
                _prev.hide()
                _prev.close()
                _prev.deleteLater()
            except RuntimeError:
                pass
            self._welcome_dlg = None

        for _old in mw.findChildren(QLabel):
            if _old.objectName() == "FNAWelcomeArrow":
                try:
                    _old.hide()
                    _old.deleteLater()
                except RuntimeError:
                    pass
        from qgis.PyQt.QtGui import QFont
        from qgis.core import (QgsCoordinateReferenceSystem, QgsWkbTypes,
                                QgsProject)

        _VUMA_PROJECTS = [
            ("— select project —",         "",      ""),
            ("Malmesbury",                  "MALM",  "Z1"),
            ("Praktiseer",                  "PRAK",  "Z1"),
            ("Ipelegeng",                   "IPG",   "Z1"),
            ("Driekoppies",                 "DRIEK", "Z1"),
            ("Kamatsamo",                   "KAM",   "Z1"),
            ("Schweizer-Reneke",            "SCHW",  "Z1"),
            ("Mothibistad",                 "MOTH",  "Z1"),
            ("Kuruman",                     "KUR",   "Z1"),
            ("Wrenchville",                 "WREN",  "Z1"),
            ("Zastron",                     "ZAST",  "Z1"),
            ("Tonga",                       "TONG",  "Z1"),
            ("Other (enter code manually)", "",      ""),
        ]
        _CRS_OPTIONS = [
            ("EPSG:4326",  "WGS 84 — geographic (default)"),
            ("EPSG:32734", "UTM Zone 34S"),
            ("EPSG:32735", "UTM Zone 35S"),
            ("EPSG:2048",  "Hartbeesthoek94 / LO19"),
        ]

        _chosen = {"client": None}

        # ── Blinking arrow overlay (parented to main window, NOT the dialog) ─
        arrow = QLabel(mw)
        arrow.setObjectName("FNAWelcomeArrow")
        arrow.setText("◀\nDrag & drop\nyour AOI here")
        arrow.setAlignment(Qt.AlignmentFlag.AlignCenter)
        arrow.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        arrow.setStyleSheet(
            "QLabel { background: rgba(0,0,0,210); color: #FFFFFF;"
            " border: 2px solid #FFFFFF; border-radius: 10px;"
            " padding: 12px 14px; }"
        )
        arrow.adjustSize()
        arrow.hide()  # positioned + shown after dialog is placed

        _blink_bright = [True]
        _blink_timer = QTimer(mw)
        _blink_timer.setInterval(550)

        def _arrow_blink():
            _blink_bright[0] = not _blink_bright[0]
            try:
                if _blink_bright[0]:
                    arrow.setStyleSheet(
                        "QLabel { background: rgba(0,0,0,210); color: #FFFFFF;"
                        " border: 2px solid #FFFFFF; border-radius: 10px;"
                        " padding: 12px 14px; }"
                    )
                else:
                    arrow.setStyleSheet(
                        "QLabel { background: rgba(40,40,60,160); color: #AAAAAA;"
                        " border: 2px solid #666688; border-radius: 10px;"
                        " padding: 12px 14px; }"
                    )
            except RuntimeError:
                _blink_timer.stop()

        _blink_timer.timeout.connect(_arrow_blink)

        def _stop_arrow():
            """Stop blinking; turn green with AOI-detected confirmation."""
            _blink_timer.stop()
            try:
                arrow.setText("✓  AOI detected")
                arrow.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
                arrow.setStyleSheet(
                    "QLabel { background: #14532d; color: #86efac;"
                    " border: 2px solid #22c55e; border-radius: 10px;"
                    " padding: 14px 20px; }"
                )
                arrow.adjustSize()
            except RuntimeError:
                pass

        # ── Dialog (non-modal, always-on-top) ─────────────────────────────────
        dlg = QDialog(mw)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)  # don't leak hidden windows
        dlg.setWindowTitle("VeloGIS — New Project")
        dlg.setWindowFlags(
            Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.Tool
        )
        dlg.setModal(False)
        dlg.setMinimumWidth(560)
        self._welcome_dlg = dlg  # singleton ref — killed on next call

        _QSS = """
        QDialog {
            background: #0E1525;
            border: 1px solid #1A2840;
            border-radius: 20px;
        }
        QLabel { color: #E6E8F0; font-family: 'Segoe UI'; }
        QLabel#hdr {
            font-size: 22px; font-weight: 900; color: #FFFFFF;
            letter-spacing: 0.5px;
        }
        QLabel#sub  { font-size: 11px; color: #3E4A62; }
        QLabel#field_lbl {
            font-size: 10px; color: #3E4A62; font-weight: 700;
            letter-spacing: 1.5px;
        }
        QLabel#client_desc { font-size: 10px; color: #3E4A62; }
        QLabel#section_label {
            font-size: 9px; color: #2A3450; font-weight: 700;
            letter-spacing: 2px;
        }

        QLineEdit, QComboBox {
            background: #091220; color: #B0BAD0;
            border: 1px solid #1A2840; border-radius: 8px;
            padding: 8px 12px; font-family: 'Segoe UI'; font-size: 12px;
        }
        QLineEdit:focus, QComboBox:focus {
            border: 1.5px solid #6050CC;
            background: #0D1830;
        }
        QComboBox QAbstractItemView {
            background: #091220; color: #B0BAD0;
            border: 1px solid #1A2840;
            selection-background-color: #1A2840;
        }
        QComboBox::drop-down { border: none; }

        /* ── Client card wrappers ─────────────────────────── */
        QFrame#card_vuma {
            background: #141830;
            border: 1.5px solid #251535;
            border-radius: 14px;
        }
        QFrame#card_vuma[active="true"] {
            border: 2px solid #FF0090;
            background: #180F28;
        }
        QFrame#card_ft {
            background: #141830;
            border: 1.5px solid #122030;
            border-radius: 14px;
        }
        QFrame#card_ft[active="true"] {
            border: 2px solid #2ABFCC;
            background: #0C1C28;
        }
        QFrame#card_herotel {
            background: #141830;
            border: 1.5px solid #221410;
            border-radius: 14px;
        }
        QFrame#card_herotel[active="true"] {
            border: 2px solid #FF4500;
            background: #1C0E08;
        }

        /* ── VUMA  hot magenta ─────────────────────────────── */
        QPushButton#vuma_sel {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #FF1FA0, stop:1 #CC0072);
            color: white; border: none; border-radius: 10px;
            font-family: 'Segoe UI'; font-size: 17px; font-weight: 900;
            letter-spacing: 5px;
            padding: 22px 16px; min-width: 130px;
        }
        QPushButton#vuma_sel:hover {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #FF44B4, stop:1 #FF0090);
        }

        /* ── fibertime  yellow + cyan columns ─────────────── */
        QPushButton#ft_sel {
            background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0    #2ABFCC, stop:0.25 #2ABFCC,
                stop:0.251 #FFE619, stop:0.749 #FFE619,
                stop:0.75 #2ABFCC, stop:1    #2ABFCC);
            color: #1A3040; border: none; border-radius: 10px;
            font-family: 'Segoe UI'; font-size: 17px; font-weight: 800;
            padding: 22px 16px; min-width: 130px;
        }
        QPushButton#ft_sel:hover {
            background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0    #40D8E4, stop:0.25 #40D8E4,
                stop:0.251 #FFF040, stop:0.749 #FFF040,
                stop:0.75 #40D8E4, stop:1    #40D8E4);
        }

        /* ── herotel  bright orange ────────────────────────── */
        QPushButton#herotel_sel {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #FF5500, stop:1 #CC3A00);
            color: white; border: none; border-radius: 10px;
            font-family: 'Segoe UI'; font-size: 17px; font-weight: 700;
            padding: 22px 16px; min-width: 130px;
        }
        QPushButton#herotel_sel:hover {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #FF6E1F, stop:1 #FF4400);
        }

        /* ── form container ─────────────────────────────────── */
        QFrame#form_box {
            background: #0A1220;
            border: 1px solid #1A2840;
            border-radius: 12px;
        }

        /* ── action buttons ─────────────────────────────────── */
        QPushButton#start_btn {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #7E66D8, stop:1 #5A48C0);
            color: white; border: none; border-radius: 9px;
            font-family: 'Segoe UI'; font-size: 13px; font-weight: 700;
            padding: 12px 40px; min-width: 160px;
        }
        QPushButton#start_btn:hover {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #9278E0, stop:1 #7E66D8);
        }
        QPushButton#start_btn:disabled { background: #101828; color: #252B3A; }
        QPushButton#cancel_btn {
            background: transparent; color: #303850;
            border: 1px solid #1A2840; border-radius: 7px;
            font-family: 'Segoe UI'; font-size: 11px; padding: 8px 20px;
        }
        QPushButton#cancel_btn:hover { color: #6070A0; border-color: #304060; }

        QFrame#accent_bar {
            background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0 #FF0090, stop:0.33 #7060D8,
                stop:0.66 #FFE619, stop:1 #FF4500);
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
        }
        """
        dlg.setStyleSheet(_QSS)


        root = QVBoxLayout(dlg)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── 5px rainbow accent bar pinned to top ──────────────────────────────
        accent_bar = QFrame()
        accent_bar.setObjectName("accent_bar")
        accent_bar.setFixedHeight(5)
        root.addWidget(accent_bar)

        # ── Inner layout carries side + bottom margins ─────────────────────────
        inner = QVBoxLayout()
        inner.setContentsMargins(32, 20, 32, 28)
        inner.setSpacing(0)
        root.addLayout(inner)

        # header row: centred title + a clear Windows-style ✕ in the top-right (this
        # dialog is frameless, so without this there is NO visible way to close it).
        from qgis.PyQt.QtWidgets import QToolButton as _QTB
        hdr_row = QHBoxLayout()
        hdr_row.setContentsMargins(0, 0, 0, 0)
        _lspacer = QWidget(); _lspacer.setFixedWidth(28)   # balance the ✕ → title stays centred
        hdr_row.addWidget(_lspacer)
        hdr_row.addStretch(1)
        hdr = QLabel("New Project")
        hdr.setObjectName("hdr")
        hdr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        hdr_row.addWidget(hdr)
        hdr_row.addStretch(1)
        _close_x = _QTB()
        _close_x.setFixedSize(28, 26)
        try:
            from .nexus_dock import style_windows_close
            style_windows_close(_close_x, dlg.reject)
        except Exception:
            _close_x.setText("✕"); _close_x.clicked.connect(dlg.reject)
        hdr_row.addWidget(_close_x, 0, Qt.AlignmentFlag.AlignTop)
        inner.addLayout(hdr_row)
        inner.addSpacing(5)

        sub = QLabel("Select your network client, then fill in the project details.")
        sub.setObjectName("sub")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub.setWordWrap(True)
        inner.addWidget(sub)
        inner.addSpacing(20)

        # ── Client card builder ───────────────────────────────────────────────
        def _make_shadow(blur=20, dy=5, alpha=130):
            from qgis.PyQt.QtWidgets import QGraphicsDropShadowEffect
            from qgis.PyQt.QtGui import QColor as _QColor
            sh = QGraphicsDropShadowEffect()
            sh.setBlurRadius(blur)
            sh.setOffset(0, dy)
            sh.setColor(_QColor(0, 0, 0, alpha))
            return sh

        sel_row = QHBoxLayout()
        sel_row.setSpacing(12)

        # VUMA card
        vuma_card = QFrame()
        vuma_card.setObjectName("card_vuma")
        vuma_card.setProperty("active", "false")
        vuma_card.setGraphicsEffect(_make_shadow())
        _vc = QVBoxLayout(vuma_card)
        _vc.setContentsMargins(8, 8, 8, 10)
        _vc.setSpacing(7)
        vuma_btn = QPushButton("VUMA")
        vuma_btn.setObjectName("vuma_sel")
        vuma_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        vuma_sub = QLabel("GPON aerial · Britelink / VTC")
        vuma_sub.setObjectName("client_desc")
        vuma_sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        _vc.addWidget(vuma_btn)
        _vc.addWidget(vuma_sub)
        sel_row.addWidget(vuma_card)

        # fibertime card
        ft_card = QFrame()
        ft_card.setObjectName("card_ft")
        ft_card.setProperty("active", "false")
        ft_card.setGraphicsEffect(_make_shadow())
        _fc = QVBoxLayout(ft_card)
        _fc.setContentsMargins(8, 8, 8, 10)
        _fc.setSpacing(7)
        ft_btn = QPushButton("fibertime")
        ft_btn.setObjectName("ft_sel")
        ft_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        ft_sub = QLabel("Informal settlement · VelocityFibre")
        ft_sub.setObjectName("client_desc")
        ft_sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        _fc.addWidget(ft_btn)
        _fc.addWidget(ft_sub)
        sel_row.addWidget(ft_card)

        # HeroTel card
        herotel_card = QFrame()
        herotel_card.setObjectName("card_herotel")
        herotel_card.setProperty("active", "false")
        herotel_card.setGraphicsEffect(_make_shadow())
        _hc = QVBoxLayout(herotel_card)
        _hc.setContentsMargins(8, 8, 8, 10)
        _hc.setSpacing(7)
        herotel_btn = QPushButton("herotel")
        herotel_btn.setObjectName("herotel_sel")
        herotel_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        herotel_sub = QLabel("FTTH aerial · SDU & MDU")
        herotel_sub.setObjectName("client_desc")
        herotel_sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        _hc.addWidget(herotel_btn)
        _hc.addWidget(herotel_sub)
        sel_row.addWidget(herotel_card)

        inner.addLayout(sel_row)
        inner.addSpacing(18)

        # ── Project details section label ─────────────────────────────────────
        sec_lbl = QLabel("PROJECT DETAILS")
        sec_lbl.setObjectName("section_label")
        inner.addWidget(sec_lbl)
        inner.addSpacing(6)

        # ── Glass form container ───────────────────────────────────────────────
        form_box = QFrame()
        form_box.setObjectName("form_box")
        form_inner = QVBoxLayout(form_box)
        form_inner.setContentsMargins(14, 12, 14, 12)
        form_inner.setSpacing(8)

        def _field_row(label_txt, widget):
            row = QHBoxLayout()
            lbl = QLabel(label_txt)
            lbl.setObjectName("field_lbl")
            lbl.setFixedWidth(90)
            row.addWidget(lbl)
            row.addWidget(widget)
            return row

        proj_combo = QComboBox()
        proj_combo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        for disp, _code, _zone in _VUMA_PROJECTS:
            proj_combo.addItem(disp)
        proj_row_widget = QFrame()
        proj_row_widget.setLayout(_field_row("Project:", proj_combo))
        proj_row_widget.setVisible(False)
        form_inner.addWidget(proj_row_widget)

        area_edit = QLineEdit()
        area_edit.setPlaceholderText("e.g. MALM, PRAK, MOA")
        area_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        form_inner.addLayout(_field_row("Area Code:", area_edit))

        zone_edit = QLineEdit()
        zone_edit.setPlaceholderText("e.g. Z1, Z2  (Vuma only)")
        zone_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        zone_row_frame = QFrame()
        zone_row_frame.setLayout(_field_row("Zone:", zone_edit))
        zone_row_frame.setVisible(False)
        form_inner.addWidget(zone_row_frame)

        crs_combo = QComboBox()
        crs_combo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        for authid, desc in _CRS_OPTIONS:
            crs_combo.addItem(f"{authid}  —  {desc}", userData=authid)
        form_inner.addLayout(_field_row("CRS:", crs_combo))

        # AOI layer picker — pre-populated + updated live when layers are dropped
        aoi_combo = QComboBox()
        aoi_combo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        aoi_combo.setToolTip(
            "Drag a shapefile into the Layers panel — it auto-fills here.\n"
            "An AOI must be selected before you can start the project."
        )
        aoi_combo.addItem("— drag & drop AOI shapefile —", userData=None)
        _sys_names = {
            "Erven", "Buildings", "P2 AOI Poly", "Aggregation Polygon", "Block",
            "Poles", "Dome Joint", "Spur Joints", "Feeder Joints", "Demand Points",
        }
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name() in _sys_names:
                continue
            try:
                gtype = lyr.geometryType()
            except Exception:
                continue
            if gtype == QgsWkbTypes.GeometryType.PolygonGeometry and lyr.featureCount() > 0:
                aoi_combo.addItem(
                    f"{lyr.name()}  ({lyr.featureCount()} features)",
                    userData=lyr.id(),
                )
        form_inner.addLayout(_field_row("AOI Layer:", aoi_combo))

        aoi_error_lbl = QLabel("⚠  AOI required — drag & drop a shapefile into the Layers panel")
        aoi_error_lbl.setStyleSheet(
            f"QLabel {{ color: {theme_safe.colors()['bad']}; font-size: 11px; font-style: italic;"
            " padding-left: 96px; margin-top: 0px; }}"
        )
        aoi_error_lbl.setVisible(False)
        form_inner.addWidget(aoi_error_lbl)

        # ── Project folder ────────────────────────────────────────────────────
        from qgis.PyQt.QtWidgets import QFileDialog
        folder_row = QHBoxLayout()
        folder_row.setSpacing(6)
        folder_lbl = QLabel("Save Folder:")
        folder_lbl.setObjectName("field_lbl")
        folder_lbl.setFixedWidth(90)
        folder_edit = QLineEdit()
        folder_edit.setPlaceholderText("Choose folder for shapefiles…")
        folder_edit.setReadOnly(True)
        folder_edit.setStyleSheet(
            "QLineEdit { background: #091220; color: #4A5570;"
            " border: 1px solid #1A2840; border-radius: 8px; padding: 8px 12px; }"
            "QLineEdit[populated='true'] { color: #B0BAD0; border-color: #22c55e; }"
        )
        browse_btn = QPushButton("Browse")
        browse_btn.setObjectName("cancel_btn")
        browse_btn.setFixedWidth(72)
        browse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        folder_row.addWidget(folder_lbl)
        folder_row.addWidget(folder_edit)
        folder_row.addWidget(browse_btn)
        form_inner.addLayout(folder_row)

        inner.addWidget(form_box)
        inner.addSpacing(18)

        def _browse_folder():
            path = QFileDialog.getExistingDirectory(
                dlg, "Select folder for shapefiles"
            )
            if path:
                folder_edit.setText(path)
                folder_edit.setProperty("populated", "true")
                folder_edit.style().unpolish(folder_edit)
                folder_edit.style().polish(folder_edit)

        browse_btn.clicked.connect(_browse_folder)

        act_row = QHBoxLayout()
        act_row.setSpacing(12)
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setObjectName("cancel_btn")
        start_btn = QPushButton("Start Project")
        start_btn.setObjectName("start_btn")
        start_btn.setEnabled(False)
        start_btn.setGraphicsEffect(_make_shadow(blur=14, dy=3, alpha=100))
        act_row.addStretch()
        act_row.addWidget(cancel_btn)
        act_row.addWidget(start_btn)
        inner.addLayout(act_row)

        # ── Logic ─────────────────────────────────────────────────────────────
        def _refresh_card(card, active):
            card.setProperty("active", "true" if active else "false")
            card.style().unpolish(card)
            card.style().polish(card)

        _ACCENT_STYLES = {
            "vuma":      ("stop:0 #FF1FA0, stop:0.5 #CC0072, stop:1 #FF1FA0",),
            "fibretime": ("stop:0 #2ABFCC, stop:0.4 #FFE619, stop:1 #2ABFCC",),
            "herotel":   ("stop:0 #FF5500, stop:0.5 #CC3A00, stop:1 #FF5500",),
        }

        def _on_proj_preset(idx):
            _disp, code, zone = _VUMA_PROJECTS[idx]
            if code:
                area_edit.setText(code)
                zone_edit.setText(zone)

        proj_combo.currentIndexChanged.connect(_on_proj_preset)

        def _select(client):
            _chosen["client"] = client
            is_vuma = client == "vuma"
            _refresh_card(vuma_card, is_vuma)
            _refresh_card(ft_card, client == "fibretime")
            _refresh_card(herotel_card, client == "herotel")
            # Dynamic accent bar — changes to selected client's brand color
            stops = _ACCENT_STYLES.get(client, ("stop:0 #7060D8, stop:1 #7060D8",))[0]
            accent_bar.setStyleSheet(
                f"QFrame#accent_bar {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
                f" {stops}); border-top-left-radius: 20px; border-top-right-radius: 20px; }}"
            )
            proj_row_widget.setVisible(is_vuma)
            zone_row_frame.setVisible(is_vuma)
            if is_vuma:
                area_edit.setPlaceholderText("e.g. MALM, PRAK, MOA")
            elif client == "herotel":
                area_edit.setPlaceholderText("e.g. HRT, KRN, BRK")
            else:
                area_edit.setPlaceholderText("e.g. MOA, VEL")
            _validate()

        # ── AOI validation — blocks Start until a real layer is chosen ──────────
        _AOI_COMBO_ERROR = (
            "QComboBox { background: #1A0808; color: #C0BAD0;"
            " border: 1.5px solid #EF4444; border-radius: 8px; padding: 6px 10px; }"
            "QComboBox::drop-down { border: none; width: 24px; }"
            "QComboBox QAbstractItemView { background: #0D1B2E; color: #B0BAD0;"
            " selection-background-color: #1A2840; }"
        )

        def _validate():
            client = _chosen.get("client")
            has_aoi = aoi_combo.currentData() is not None
            if not client:
                # No client chosen yet — neutral, button already disabled
                aoi_combo.setStyleSheet("")
                aoi_error_lbl.setVisible(False)
                start_btn.setEnabled(False)
            elif not has_aoi:
                # Client chosen but no AOI — show red + block
                aoi_combo.setStyleSheet(_AOI_COMBO_ERROR)
                aoi_error_lbl.setVisible(True)
                start_btn.setEnabled(False)
            else:
                # Both client + AOI — clear and enable
                aoi_combo.setStyleSheet("")
                aoi_error_lbl.setVisible(False)
                start_btn.setEnabled(True)
            _reposition()

        aoi_combo.currentIndexChanged.connect(_validate)

        vuma_btn.clicked.connect(lambda: _select("vuma"))
        ft_btn.clicked.connect(lambda: _select("fibretime"))
        herotel_btn.clicked.connect(lambda: _select("herotel"))

        # ── Live AOI detection — fires when planner drops a shapefile ─────────
        # Do NOT filter by _sys_names here — on a blank project the user's
        # shapefile IS the AOI, even if it happens to share a system name.
        def _on_layers_added(layers):
            for lyr in layers:
                try:
                    gtype = lyr.geometryType()
                except Exception:
                    continue
                if gtype == QgsWkbTypes.GeometryType.PolygonGeometry:
                    label = f"{lyr.name()}  ({lyr.featureCount()} features)"
                    # Avoid duplicates (keyed by layer ID)
                    existing = [aoi_combo.itemData(i) for i in range(aoi_combo.count())]
                    if lyr.id() not in existing:
                        aoi_combo.addItem(label, userData=lyr.id())
                    # Auto-select the newly dropped layer
                    idx = aoi_combo.findData(lyr.id())
                    if idx >= 0:
                        aoi_combo.setCurrentIndex(idx)
                    # Dismiss the blinking arrow — planner has loaded an AOI
                    _stop_arrow()

        QgsProject.instance().layersAdded.connect(_on_layers_added)

        # ── Start Project — save SESSION and kick off step 01 ─────────────────
        _cleaned_up = [False]

        def _cleanup():
            if _cleaned_up[0]:
                return
            _cleaned_up[0] = True
            # Clear singleton ref so next call starts fresh
            if getattr(self, '_welcome_dlg', None) is dlg:
                self._welcome_dlg = None
            _blink_timer.stop()
            try:
                arrow.hide()
                arrow.deleteLater()
            except RuntimeError:
                pass
            try:
                QgsProject.instance().layersAdded.disconnect(_on_layers_added)
            except Exception:
                pass

        def _on_start():
            client = _chosen["client"]
            if not client:
                return
            authid = crs_combo.currentData()
            folder = folder_edit.text().strip() or None

            # Save session if fibre_automation is installed — optional, never blocks dialog close
            try:
                from fibre_automation.startup import SESSION, save_session_to_project
                SESSION.update({
                    "client":         client,
                    "area_code":      area_edit.text().strip().upper() or None,
                    "zone_code":      zone_edit.text().strip() or None,
                    "crs":            QgsCoordinateReferenceSystem(authid),
                    "aoi_source":     aoi_combo.currentData(),
                    "project_folder": folder,
                })
                save_session_to_project()
            except Exception:
                pass  # fibre_automation missing OR session-save errored — never block
                      # the dialog close (contract: session save is best-effort)

            _cleanup()
            dlg.close()
            # Defer post-close work — calling QGIS setup directly from a
            # button click handler while the dialog is being destroyed can
            # cause a Qt access violation.
            _chosen_client = client

            def _post_start():
                try:
                    self._rebuild_automation_group(_chosen_client.upper())
                    self._lock_dock_to_client(_chosen_client.upper())
                except Exception as e:
                    self.iface.messageBar().pushWarning("New Project", f"Toolbar rebuild failed: {e}")
                try:
                    if _chosen_client in ("ft", "fibretime"):
                        from fibre_automation.fibretime.step_01_setup import ft_step_01_setup
                        ft_step_01_setup()
                    elif _chosen_client == "herotel":
                        from fibre_automation.herotel.step_01_setup import herotel_step_01_setup
                        herotel_step_01_setup()
                    else:
                        from fibre_automation.vuma.step_01_setup import vuma_step_01_setup
                        vuma_step_01_setup()
                except Exception as e:
                    self._log_and_push_critical("New Project (Step 01)", e)
                    import traceback
                    traceback.print_exc()

                # Always run clean buildings as the final startup step — silently
                # skips if Buildings / Erven layers are missing or empty.
                self._run_clean_buildings(silent_if_missing=True)

            QTimer.singleShot(50, _post_start)

        start_btn.clicked.connect(_on_start)

        cancel_btn.clicked.connect(lambda: (_cleanup(), dlg.close()))
        dlg.finished.connect(lambda _r: _cleanup())

        # ── Position dialog + arrow ───────────────────────────────────────────
        def _reposition():
            if _cleaned_up[0]:
                return
            dlg.adjustSize()
            # Centre over the map canvas widget, not the full main window
            canvas = self.iface.mapCanvas()
            canvas_tl = canvas.mapToGlobal(canvas.rect().topLeft())
            dlg_x = canvas_tl.x() + (canvas.width() - dlg.width()) // 2
            dlg_y = canvas_tl.y() + (canvas.height() - dlg.height()) // 2
            dlg.move(dlg_x, dlg_y)

            # Find right edge of the Layers dock to anchor the arrow
            mw_geo = mw.geometry()
            layers_right = mw_geo.x() + 230  # default fallback
            try:
                for dw in mw.findChildren(QDockWidget):
                    if "layer" in (dw.windowTitle() or "").lower():
                        pt = dw.mapToGlobal(QPoint(dw.width(), 0))
                        layers_right = pt.x()
                        break
            except Exception:
                pass

            gap_center_x = layers_right + (dlg_x - layers_right) // 2
            try:
                arrow_x = gap_center_x - arrow.width() // 2
                arrow_y = dlg_y + (dlg.height() - arrow.height()) // 2
                # Convert global → main-window-local coords
                arrow_local = mw.mapFromGlobal(QPoint(arrow_x, arrow_y))
                arrow.move(arrow_local)
                arrow.raise_()
                arrow.show()
            except RuntimeError:
                pass  # arrow already deleted after _cleanup()

        _reposition()
        _blink_timer.start()
        dlg.show()

    # ── Unload ────────────────────────────────────────────────────────────────
    def unload(self):
        """Idempotent: safe to call multiple times; swallows C++-deleted-object errors."""
        # Stop instance-owned delayed UI work before removing any toolbar/dock.
        # Static singleShot callbacks once survived into the next plugin instance.
        for timer in list(getattr(self, "_ui_heal_timers", []) or []):
            try:
                timer.stop()
                timer.timeout.disconnect()
                timer.deleteLater()
            except Exception:
                pass
        self._ui_heal_timers = []
        try:
            from .nexus_dock import uninstall_dock_chrome_watcher
            uninstall_dock_chrome_watcher(
                self.iface.mainWindow(),
                getattr(self, "_dock_chrome_watcher", None))
        except Exception:
            pass
        self._dock_chrome_watcher = None
        # Span Inspector first: drop its canvas rubber band and layer-edit signal
        # connections before anything else is torn down, so a reload can't leave a
        # highlight painted over the map or a signal pointing at a dead panel.
        try:
            from .span_inspector import close_span_inspector
            close_span_inspector()
        except Exception:
            pass
        # Persist the Network Planner session BEFORE the dock is destroyed, so a
        # one-click update (which unloads + reloads the plugin) doesn't leave the
        # user's splitters/zones/groups "dead" — the fresh dock re-binds them.
        try:
            from qgis.PyQt import sip
            np = getattr(self, '_np_dock', None)
            if np is not None and not sip.isdeleted(np) and hasattr(np, '_session_save'):
                np._session_save()
        except Exception:
            pass
        try:
            from .fibre_automation.nexus_profile import error_capture
            error_capture.uninstall()
        except Exception:
            pass
        try:
            if getattr(self, '_freeze_watchdog', None) is not None:
                self._freeze_watchdog.stop()
                self._freeze_watchdog = None
        except Exception:
            pass
        try:
            if getattr(self, '_geometry_guardian', None) is not None:
                self._geometry_guardian.stop()
                self._geometry_guardian = None
        except Exception:
            pass
        try:
            if getattr(self, '_nexus', None) is not None:
                self._nexus.unload()
                self._nexus = None
        except Exception:
            pass
        try:
            if getattr(self, '_update_checker', None) is not None:
                self._update_checker.stop()
                self._update_checker = None
        except Exception:
            pass
        # Deregister the native locator filter
        try:
            if getattr(self, '_locator', None) is not None:
                self.iface.deregisterLocatorFilter(self._locator)
                self._locator = None
        except Exception:
            pass
        # Disconnect project signals
        try:
            from qgis.core import QgsProject
            QgsProject.instance().readProject.disconnect(self._on_project_read)
            QgsProject.instance().cleared.disconnect(self._on_project_cleared)
        except Exception:
            pass
        try:
            from qgis.core import QgsProject
            # _install_home_panel connects BOTH slots (incl. _home_refresh_debounced);
            # disconnect both or the debounced slot leaks on the dead instance.
            for _sig in (QgsProject.instance().layersAdded,
                         QgsProject.instance().layersRemoved):
                for _slot in (self._refresh_home_steps, self._home_refresh_debounced):
                    try:
                        _sig.disconnect(_slot)
                    except (TypeError, RuntimeError):
                        pass
        except Exception:
            pass
        # Disconnect the external bridge dock's client_changed (it lives in a
        # different plugin that isn't unloaded — leaks the old instance otherwise).
        try:
            dock = self._get_bridge_dock()
            if dock is not None:
                dock.client_changed.disconnect(self._rebuild_automation_group)
        except Exception:
            pass
        try:
            self.iface.newProjectCreated.disconnect(self._on_new_project_created)
        except Exception:
            pass

        # VeloPlan menu
        try:
            if getattr(self, '_velo_menu', None) is not None:
                self.iface.mainWindow().menuBar().removeAction(self._velo_menu.menuAction())
                self._velo_menu.deleteLater()
        except (RuntimeError, AttributeError):
            pass
        self._velo_menu = None

        # Erven Detection dock (ported erven_qgis_plugin panel)
        try:
            if getattr(self, '_erven_detection_panel', None) is not None:
                self.iface.removeDockWidget(self._erven_detection_panel)
                self._erven_detection_panel.deleteLater()
        except (RuntimeError, AttributeError):
            pass
        self._erven_detection_panel = None

        # Timer first — prevent further _bridge_tick calls on deleted widgets
        try:
            if self._bridge_timer:
                self._bridge_timer.stop()
        except RuntimeError:
            pass
        self._bridge_timer = None
        try:
            if getattr(self, "_absorb_watchdog", None):
                self._absorb_watchdog.stop()
        except RuntimeError:
            pass
        self._absorb_watchdog = None

        # Account-guard timer — was leaking on every reload (fires _check_account_active
        # against a torn-down instance). Stop it like every other timer.
        try:
            if getattr(self, "_acct_timer", None):
                self._acct_timer.stop()
                self._acct_timer.timeout.disconnect()
        except (RuntimeError, TypeError):
            pass
        self._acct_timer = None

        # Home-context debounce timer — stop so it can't fire _refresh_home_steps
        # against a torn-down panel after unload.
        try:
            if getattr(self, "_home_ctx_timer", None):
                self._home_ctx_timer.stop()
                self._home_ctx_timer.timeout.disconnect()
        except (RuntimeError, TypeError):
            pass
        self._home_ctx_timer = None

        # Deferred-update poller (module-global in update_check) — cancel so it
        # can't survive this unload and trigger a second hot-reload.
        try:
            from . import update_check as _uc
            _uc.cancel_deferred()
        except Exception:
            pass

        # HLD tile + timer — every reload was leaking another tile (2026-04-28).
        try:
            if getattr(self, "_hld_timer", None):
                self._hld_timer.stop()
                self._hld_timer.timeout.disconnect()
        except RuntimeError:
            pass
        self._hld_timer = None
        try:
            tile = getattr(self, "_hld_score_tile", None)
            self._hld_score_tile = None   # null FIRST so queued callbacks see None
            if tile is not None:
                self.iface.statusBarIface().removeWidget(tile)
                tile.deleteLater()
        except (RuntimeError, AttributeError):
            self._hld_score_tile = None

        # Command palette shortcut
        try:
            sc = getattr(self, "_cmd_palette_shortcut", None)
            if sc is not None:
                sc.setEnabled(False)
                sc.deleteLater()
        except (RuntimeError, AttributeError):
            pass
        self._cmd_palette_shortcut = None

        # Mirror eye + its timer
        try:
            t = getattr(self, "_mirror_eye_timer", None)
            if t is not None:
                t.stop()
        except RuntimeError:
            pass
        self._mirror_eye_timer = None
        try:
            eye = getattr(self, "_mirror_eye", None)
            if eye is not None:
                eye.setParent(None)
                eye.hide()
                eye.deleteLater()
        except (RuntimeError, AttributeError):
            pass
        self._mirror_eye = None

        try:
            # Prefer the live registry entry over the potentially-dead Python wrapper.
            # If self.provider's C++ object was already deleted (e.g. addProvider failed
            # and QGIS cleaned it up), calling removeProvider(dead_ptr) silently no-ops
            # inside QGIS but leaves the "fibernetwork" key in the C++ map → zombie.
            reg = QgsApplication.processingRegistry()
            live = reg.providerById("fibernetwork")
            target = None
            try:
                if live and live.id() == "fibernetwork":
                    target = live
            except RuntimeError:
                pass
            if target is None and self.provider:
                try:
                    if self.provider.id() == "fibernetwork":
                        target = self.provider
                except RuntimeError:
                    pass
            if target is not None:
                reg.removeProvider(target)
        except Exception:
            pass
        self.provider = None

        # Restore fibretime toolbars we hid during absorb
        try:
            absorbed = getattr(self, "_absorbed_from", None)
            if absorbed:
                for tb in absorbed:
                    if tb is not None:
                        try: tb.show()
                        except RuntimeError: pass
        except Exception:
            pass
        self._absorbed_from = None
        self._fibretime_absorbed = False

        try:
            if self._toolbar:
                self._toolbar.clear()
                self.iface.mainWindow().removeToolBar(self._toolbar)
        except RuntimeError:
            pass
        self._toolbar = None

        try:
            from qgis.PyQt import sip
            if self._pole_editor_panel is not None:
                self._pole_editor_panel._teardown()
            d = getattr(self, '_pole_editor_dock', None)
            if d is not None and not sip.isdeleted(d):
                self.iface.removeDockWidget(d); d.deleteLater()
        except Exception:
            pass
        self._pole_editor_dock = None
        self._pole_editor_panel = None

        try:
            if self._route_viewer_panel is not None:
                self._route_viewer_panel.cleanup()
        except Exception:
            pass
        try:
            from qgis.PyQt import sip
            d = getattr(self, '_route_viewer_dock', None)
            if d is not None and not sip.isdeleted(d):
                self.iface.removeDockWidget(d)
                d.deleteLater()
        except Exception:
            pass
        self._route_viewer_dock = None
        self._route_viewer_panel = None

        try:
            if self._home_panel:
                self.iface.removeDockWidget(self._home_panel)
                self._home_panel.deleteLater()
        except RuntimeError:
            pass
        self._home_panel = None

        try:
            if self._np_dock:
                self.iface.removeDockWidget(self._np_dock)
                self._np_dock.deleteLater()
        except RuntimeError:
            pass
        self._np_dock = None

        try:
            from qgis.PyQt import sip
            if self._enc_editor_panel is not None:
                self._enc_editor_panel._teardown()
            d = getattr(self, '_enc_editor_dock', None)
            if d is not None and not sip.isdeleted(d):
                self.iface.removeDockWidget(d); d.deleteLater()
        except Exception:
            pass
        self._enc_editor_dock = None
        self._enc_editor_panel = None

        # WA_DeleteOnClose dialogs parented to mainWindow() — close any that are
        # still open so they don't linger / leave dangling SIP wrappers on reload.
        try:
            from qgis.PyQt import sip
            for _attr in ('_team_guide_dlg', '_welcome_dlg', '_problem_dlg'):
                _d = getattr(self, _attr, None)
                if _d is None:
                    continue
                # _problem_dlg wraps the real QDialog in a .dlg attribute.
                _qd = getattr(_d, 'dlg', _d)
                try:
                    if _qd is not None and not sip.isdeleted(_qd):
                        _qd.close()
                except Exception:
                    pass
                setattr(self, _attr, None)
        except Exception:
            pass

        try:                                  # SAM2 detect poll-timer could fire into a torn-down plugin
            if getattr(self, "_erven_detect_poll_timer", None):
                self._erven_detect_poll_timer.stop()
        except (RuntimeError, AttributeError):
            pass
        self._erven_detect_poll_timer = None

        self._actions.clear()
        self._brand_label = None
        self._brand_status = None

    # ── Erven Detection (SAM2 + GroundingDINO via erven_mcp) ─────────────────

    def _erven_detect_run(self):
        """AI Detect button — SAM2 building footprints only (Buildings_detected)."""
        self._ai_detect_run(run_tessellation=False)

    def _erven_erven_run(self):
        """AI Erven button — buildings + momepy parcel tessellation (+ Erven_detected)."""
        self._ai_detect_run(run_tessellation=True)

    def _ai_detect_run(self, run_tessellation: bool = False):
        """Shared runner for AI Detect / AI Erven buttons.

        Posts to erven_mcp HTTP server on port 8780, polls progress every 2s,
        calls _erven_detect_on_complete() when done.

        Args:
            run_tessellation: If True, also generate Erven_detected property parcels
                              via momepy enclosed_tessellation (requires roads.json).
        """
        import json as _json
        import urllib.request

        from qgis.PyQt.QtCore import QTimer

        ERVEN_MCP_URL = "http://127.0.0.1:8780"
        iface = self.iface
        label = "AI Erven" if run_tessellation else "AI Detect"

        # ── Check server is up ───────────────────────────────────────────────
        try:
            with urllib.request.urlopen(f"{ERVEN_MCP_URL}/health", timeout=3) as r:
                pass
        except Exception:
            iface.messageBar().pushMessage(
                label,
                "❌ erven_mcp server not running on port 8780.  "
                "Start: cd erven_detection/src && python -m erven_mcp.server --http",
                level=Qgis.MessageLevel.Critical, duration=20,
            )
            return

        # ── POST /pipeline/run ───────────────────────────────────────────────
        config = {
            "source": "canvas",
            "preset": "sa_formal_low",
            "run_tessellation": run_tessellation,
            "roads_source": "roads_json",
            "roads_json_path": "C:/Temp/roads.json",
        }
        payload = _json.dumps(config).encode("utf-8")
        req = urllib.request.Request(
            f"{ERVEN_MCP_URL}/pipeline/run",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                start_data = _json.loads(resp.read().decode("utf-8"))
        except Exception as exc:
            iface.messageBar().pushMessage(
                label, f"Could not start pipeline: {exc}", level=Qgis.MessageLevel.Critical, duration=10,
            )
            return

        if not start_data.get("started"):
            msg = start_data.get("message", "Pipeline not started")
            iface.messageBar().pushMessage(label, msg, level=Qgis.MessageLevel.Warning, duration=8)
            return

        est = "~5–10 min (buildings + erven)" if run_tessellation else "~3–7 min"
        iface.messageBar().pushMessage(
            label,
            f"⏳ SAM2 running… ({est})  Polling every 2s…",
            level=Qgis.MessageLevel.Info, duration=120,
        )

        # ── Poll /progress every 2 s ─────────────────────────────────────────
        poll_timer = QTimer(iface.mainWindow())   # parented so teardown can't orphan it
        poll_timer.setInterval(2000)
        plugin_self = self

        def _poll():
            try:
                with urllib.request.urlopen(
                    f"{ERVEN_MCP_URL}/progress", timeout=3
                ) as r:
                    prog = _json.loads(r.read().decode("utf-8"))
            except Exception:
                return  # transient error — keep polling

            # Default to False so a malformed/partial progress body (missing the
            # 'pipeline_running' key) STOPS the poll instead of looping forever.
            still_running = prog.get("pipeline_running", False)
            step    = prog.get("step", "")
            pct     = int(prog.get("progress", 0) * 100)
            message = prog.get("message", "")

            if still_running:
                iface.messageBar().pushMessage(
                    label,
                    f"[{pct}%] {step}: {message}",
                    level=Qgis.MessageLevel.Info, duration=3,
                )
                return

            poll_timer.stop()
            plugin_self._erven_detect_poll_timer = None
            plugin_self._erven_detect_on_complete(run_tessellation=run_tessellation)

        poll_timer.timeout.connect(_poll)
        poll_timer.start()
        self._erven_detect_poll_timer = poll_timer
        self._erven_mcp_url = ERVEN_MCP_URL

    def _erven_detect_on_complete(self, run_tessellation: bool = False):
        """Fetch /pipeline/result and show summary in the status bar."""
        import json as _json
        import urllib.request

        iface = self.iface
        url   = getattr(self, "_erven_mcp_url", "http://127.0.0.1:8780")
        label = "AI Erven" if run_tessellation else "AI Detect"

        try:
            with urllib.request.urlopen(f"{url}/pipeline/result", timeout=5) as r:
                result = _json.loads(r.read().decode("utf-8"))
        except Exception as exc:
            iface.messageBar().pushMessage(
                label, f"Could not fetch result: {exc}", level=Qgis.MessageLevel.Critical, duration=10,
            )
            return

        error = result.get("error")
        if error:
            failed_step = result.get("failed_step", "unknown")
            iface.messageBar().pushMessage(
                label,
                f"❌ Failed at step '{failed_step}': {error}",
                level=Qgis.MessageLevel.Critical, duration=15,
            )
            return

        n_buildings = result.get("num_buildings", result.get("num_erven", 0))
        n_erven     = result.get("num_erven", 0)    # only set if tessellation ran
        elapsed     = result.get("elapsed_s", 0)
        summary     = result.get("summary", f"{n_buildings} buildings")

        # Pipeline already loaded layer(s) via the bridge — just refresh canvas
        iface.mapCanvas().refreshAllLayers()
        iface.mapCanvas().refresh()

        if run_tessellation and n_erven:
            layers_msg = f"'Buildings_detected' + 'Erven_detected' ({n_erven} parcels)"
        else:
            layers_msg = "'Buildings_detected'"

        iface.messageBar().pushMessage(
            label,
            f"✅ {summary}  — {layers_msg} added to canvas",
            level=Qgis.MessageLevel.Success, duration=15,
        )

    # ──────────────────────────────────────────────────────────────────────────
    # VeloDetect — batch SAM2 building detection over full AOI
    # ──────────────────────────────────────────────────────────────────────────

    def _place_ai_results(self, results, iface_ref):
        """Create 'AI Buildings' polygon + 'AI Centroids' point memory layers.

        Used by VeloDetect (_velo_detect_run).
        results: list of (cx_lon, cx_lat, [(lon, lat), ...])
        """
        from qgis.core import (
            QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY,
            QgsProject, QgsField,
            QgsSingleSymbolRenderer, QgsFillSymbol, QgsMarkerSymbol,
        )
        from qgis.PyQt.QtCore import QMetaType  # used by QgsField below (was NameError)

        proj = QgsProject.instance()

        poly_vl = QgsVectorLayer("Polygon?crs=EPSG:4326", "AI Buildings", "memory")
        poly_pr = poly_vl.dataProvider()
        poly_pr.addAttributes([QgsField("idx", QMetaType.Type.Int)])
        poly_vl.updateFields()
        poly_feats = []
        for i, (cx, cy, poly_pts) in enumerate(results):
            f = QgsFeature()
            f.setGeometry(QgsGeometry.fromPolygonXY(
                [[QgsPointXY(lon, lat) for lon, lat in poly_pts]]))
            f.setAttributes([i + 1])
            poly_feats.append(f)
        poly_pr.addFeatures(poly_feats)
        poly_vl.updateExtents()
        poly_vl.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple({
            "color": "0,212,255,60", "outline_color": "0,212,255,255",
            "outline_width": "0.5", "outline_width_unit": "MM",
        })))

        pt_vl = QgsVectorLayer("Point?crs=EPSG:4326", "AI Centroids", "memory")
        pt_pr = pt_vl.dataProvider()
        pt_pr.addAttributes([
            QgsField("idx", QMetaType.Type.Int),
            QgsField("lon", QMetaType.Type.Double),
            QgsField("lat", QMetaType.Type.Double),
        ])
        pt_vl.updateFields()
        pt_feats = []
        for i, (cx, cy, _) in enumerate(results):
            f = QgsFeature()
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(cx, cy)))
            f.setAttributes([i + 1, round(cx, 6), round(cy, 6)])
            pt_feats.append(f)
        pt_pr.addFeatures(pt_feats)
        pt_vl.updateExtents()
        pt_vl.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple({
            "name": "circle", "color": "255,210,0,220",
            "size": "2", "size_unit": "MM", "outline_style": "no",
        })))

        for name in ("AI Buildings", "AI Centroids"):
            for old in proj.mapLayersByName(name):
                proj.removeMapLayer(old)
        proj.addMapLayer(poly_vl)
        proj.addMapLayer(pt_vl)

    def _velo_detect_run(self):
        """Tile the full AOI and send each chip to the SAM2 server.

        Renders 512×512 JPEG tiles at 0.3 m/px, POSTs to SAM2 at :8101,
        collects building polygons, deduplicates at tile borders, and places
        results as 'AI Buildings' + 'AI Centroids' memory layers.
        """
        import math
        import json
        import urllib.request
        from qgis.core import (
            QgsProject, QgsMapSettings, QgsMapRendererCustomPainterJob,
            QgsRectangle, QgsGeometry, QgsPointXY,
            QgsCoordinateTransform, QgsCoordinateReferenceSystem,
        )
        from qgis.PyQt.QtCore import QSize, QBuffer, Qt
        from qgis.PyQt.QtGui import QImage, QPainter, QColor
        from qgis.PyQt.QtWidgets import QProgressDialog, QApplication

        SAM2_URL = "http://127.0.0.1:8102/predict"
        GSD_M    = 0.3    # target ground sampling distance (m/pixel)
        TILE_PX  = 512
        MIN_AREA = 50     # min mask area in pixels² (≈15 m² at 0.3 m/px)

        canvas       = self.iface.mapCanvas()
        map_settings = canvas.mapSettings()
        dest_crs     = map_settings.destinationCrs()
        wgs84        = QgsCoordinateReferenceSystem("EPSG:4326")
        proj         = QgsProject.instance()

        # ── 1. Ping SAM2 server ───────────────────────────────────────────────
        try:
            with urllib.request.urlopen(
                    SAM2_URL.replace("/predict", "/health"), timeout=4) as r:
                health = json.loads(r.read())
            if not health.get("model_loaded", False):
                self.iface.messageBar().pushMessage(
                    "AutoDetect",
                    "SAM2 server is up but model not loaded — check server logs.",
                    level=Qgis.MessageLevel.Critical, duration=10)
                return
        except Exception as exc:
            self.iface.messageBar().pushMessage(
                "AutoDetect",
                f"SAM2 server unreachable at {SAM2_URL}. "
                f"Run: python C:/Temp/sam2_server.py on 192.168.1.150  ({exc})",
                level=Qgis.MessageLevel.Critical, duration=15)
            return

        # ── 2. Find AOI layer ─────────────────────────────────────────────────
        aoi_geom = None
        aoi_bbox = None
        for name in ("P2 AOI Poly", "AOI", "Mohadin AOI", "AOI Poly"):
            layers = proj.mapLayersByName(name)
            if layers:
                feats = list(layers[0].getFeatures())
                if feats:
                    aoi_geom = feats[0].geometry()
                    # Null/empty geometry → boundingBox() returns a degenerate
                    # all-zero rect that bypasses the canvas-extent fallback.
                    if not aoi_geom or aoi_geom.isNull() or aoi_geom.isEmpty():
                        aoi_geom = None
                        continue
                    if layers[0].crs() != dest_crs:
                        xf = QgsCoordinateTransform(layers[0].crs(), dest_crs, proj)
                        aoi_geom.transform(xf)
                    aoi_bbox = aoi_geom.boundingBox()
                    break

        if aoi_bbox is None:
            # Fall back to current canvas extent
            aoi_bbox = canvas.extent()
            self.iface.messageBar().pushMessage(
                "AutoDetect",
                "No AOI layer found — using current canvas extent as AOI.",
                level=Qgis.MessageLevel.Warning, duration=6)

        # ── 3. Compute tile grid in CRS units ─────────────────────────────────
        cy = aoi_bbox.center().y()
        if dest_crs.isGeographic():
            m_per_lat = 110574.0
            m_per_lon = 111320.0 * math.cos(math.radians(cy))
            tile_w = (GSD_M * TILE_PX) / m_per_lon
            tile_h = (GSD_M * TILE_PX) / m_per_lat
        else:
            tile_w = tile_h = GSD_M * TILE_PX

        tiles = []
        y = aoi_bbox.yMinimum()
        while y < aoi_bbox.yMaximum():
            x = aoi_bbox.xMinimum()
            while x < aoi_bbox.xMaximum():
                tile_ext = QgsRectangle(x, y, x + tile_w, y + tile_h)
                if aoi_geom is None or aoi_geom.intersects(
                        QgsGeometry.fromRect(tile_ext)):
                    tiles.append(tile_ext)
                x += tile_w
            y += tile_h

        if not tiles:
            self.iface.messageBar().pushMessage(
                "AutoDetect", "No tiles generated — check AOI layer.", level=Qgis.MessageLevel.Critical, duration=8)
            return

        to_wgs84 = QgsCoordinateTransform(dest_crs, wgs84, proj)

        def _px2geo(px_x, px_y, tile_ext):
            mx = tile_ext.xMinimum() + (px_x / TILE_PX) * tile_ext.width()
            my = tile_ext.yMaximum() - (px_y / TILE_PX) * tile_ext.height()
            try:
                pt = to_wgs84.transform(QgsPointXY(mx, my))
                return (pt.x(), pt.y())
            except Exception:
                return (mx, my)

        # ── 4. Progress dialog ────────────────────────────────────────────────
        prog = QProgressDialog(
            f"AutoDetect — 0 / {len(tiles)} tiles", "Cancel", 0, len(tiles))
        prog.setWindowTitle("VeloDetect — Batch SAM2 Building Detection")
        prog.setWindowModality(Qt.WindowModality.WindowModal)
        prog.setMinimumDuration(0)
        prog.setValue(0)

        # ── 5. Tile → render → POST → collect ────────────────────────────────
        all_results = []
        errors      = 0

        for i, tile_ext in enumerate(tiles):
            QApplication.processEvents()
            if prog.wasCanceled():
                break

            prog.setLabelText(
                f"AutoDetect — {i}/{len(tiles)} tiles  "
                f"({len(all_results)} buildings so far)")

            # Render tile on main thread
            ts = QgsMapSettings()
            ts.setLayers(map_settings.layers())
            ts.setDestinationCrs(dest_crs)
            ts.setExtent(tile_ext)
            ts.setOutputSize(QSize(TILE_PX, TILE_PX))
            ts.setBackgroundColor(map_settings.backgroundColor())
            img = QImage(QSize(TILE_PX, TILE_PX), QImage.Format.Format_ARGB32)
            img.fill(QColor(255, 255, 255))
            painter = QPainter(img)
            job = QgsMapRendererCustomPainterJob(ts, painter)
            job.start()
            job.waitForFinished()
            painter.end()
            buf = QBuffer()
            buf.open(QBuffer.WriteOnly)
            img.save(buf, "JPEG", 85)
            jpg_bytes = bytes(buf.data())
            buf.close()

            # POST to SAM2 (synchronous, main thread — ~200-500 ms on GPU)
            try:
                boundary = b"VeloDetectBoundary7x3"
                body = (
                    b"--" + boundary + b"\r\n"
                    b'Content-Disposition: form-data; name="file"; filename="tile.jpg"\r\n'
                    b"Content-Type: image/jpeg\r\n\r\n"
                    + jpg_bytes
                    + b"\r\n--" + boundary + b"--\r\n"
                )
                req = urllib.request.Request(
                    SAM2_URL, data=body,
                    headers={"Content-Type":
                             f"multipart/form-data; boundary={boundary.decode()}"},
                    method="POST")
                with urllib.request.urlopen(req, timeout=60) as resp:
                    data = json.loads(resp.read())

                for bldg in data.get("buildings", []):
                    if bldg.get("area_px", 0) < MIN_AREA:
                        continue
                    cx_lon, cx_lat = _px2geo(bldg["cx_px"], bldg["cy_px"], tile_ext)
                    poly_pts = [_px2geo(p[0], p[1], tile_ext)
                                for p in bldg.get("polygon_px", [])]
                    if len(poly_pts) < 3:
                        poly_pts = [  # fallback bounding box
                            _px2geo(bldg["cx_px"]-10, bldg["cy_px"]-10, tile_ext),
                            _px2geo(bldg["cx_px"]+10, bldg["cy_px"]-10, tile_ext),
                            _px2geo(bldg["cx_px"]+10, bldg["cy_px"]+10, tile_ext),
                            _px2geo(bldg["cx_px"]-10, bldg["cy_px"]+10, tile_ext),
                        ]
                    all_results.append((cx_lon, cx_lat, poly_pts))

            except Exception as exc:
                errors += 1
                if errors <= 5:
                    print(f"[VeloDetect] tile {i} error: {exc}")

            prog.setValue(i + 1)

        prog.close()

        if not all_results:
            self.iface.messageBar().pushMessage(
                "AutoDetect",
                f"No buildings detected across {len(tiles)} tiles "
                f"({errors} tile errors).",
                level=Qgis.MessageLevel.Critical, duration=15)
            return

        # ── 6. Deduplicate cross-tile duplicates (5 m grid hash) ─────────────
        kept = []
        seen_cells = set()
        # cell size ≈ 5 m in degrees at Mohadin latitude.
        # all_results are WGS84 degrees (via _px2geo → to_wgs84), so the
        # cosine MUST use geographic latitude. cy is in dest_crs units (a
        # UTM northing when projected), so derive a real WGS84 latitude.
        ctr_geo = to_wgs84.transform(aoi_bbox.center())
        cell_lat = 5.0 / 110574.0
        cell_lon = 5.0 / (111320.0 * math.cos(math.radians(ctr_geo.y())))
        for cx, cl, poly in all_results:
            cell = (int(cx / cell_lon), int(cl / cell_lat))
            if cell not in seen_cells:
                seen_cells.add(cell)
                kept.append((cx, cl, poly))

        # ── 7. Place on canvas ────────────────────────────────────────────────
        self._place_ai_results(kept, self.iface)
        self.iface.messageBar().pushMessage(
            "AutoDetect",
            f"{len(kept)} buildings detected in {len(tiles)} tiles "
            f"({errors} errors). "
            f"Layers: 'AI Buildings' (cyan) · 'AI Centroids' (gold dots).",
            level=Qgis.MessageLevel.Success, duration=20)


# ── Bridge colour palette (mirrors bridge_dock.py) ────────────────────────────
_BG      = "#0f1117"
_PANEL   = "#1a1d2e"
_ACCENT  = "#00d4ff"
_VIOLET  = "#7c3aed"
_BLUE    = "#2563eb"
_GREEN   = "#22c55e"
_RED     = "#ef4444"
# Amber = the bridge is present but not serving — a third state that used to be
# painted the same red as "there is no bridge here".
_AMBER   = "#f59e0b"
_TEXT    = "#e2e8f0"
_DIM     = "#64748b"
_BORDER  = "#2d3148"

_DIALOG_BG = f"QDialog {{ background: {_BG}; }}"

_SECTION_LBL = (f"QLabel {{ color: {_DIM}; font-family: 'Segoe UI'; font-size: 9px; "
                f"font-weight: 700; letter-spacing: 1px; }}")

_SUBTITLE_LBL = (f"QLabel {{ color: {_TEXT}; font-family: 'Segoe UI'; font-size: 10px; }}")

_STATUS_LBL = (f"QLabel {{ color: {_DIM}; font-family: Consolas; font-size: 10px; "
               f"padding: 2px; }}")

_HINT_LBL = (f"QLabel {{ color: {_DIM}; font-family: 'Segoe UI'; font-size: 9px; "
             f"border-top: 1px solid {_BORDER}; padding-top: 6px; }}")

_DIVIDER = f"QFrame {{ color: {_BORDER}; }}"

def _btn(bg, hover, pressed, text_col="white"):
    return (f"QPushButton {{ background: {bg}; color: {text_col}; border: none; "
            f"border-radius: 4px; padding: 5px 10px; font-family: 'Segoe UI'; "
            f"font-size: 11px; font-weight: 700; letter-spacing: 0.5px; min-height: 32px; }}"
            f"QPushButton:hover {{ background: {hover}; }}"
            f"QPushButton:pressed {{ background: {pressed}; }}")

_BTN_GREEN   = _btn(_GREEN,   "#16a34a", "#15803d")
_BTN_RED     = _btn(_RED,     "#dc2626", "#991b1b")
_BTN_GRADIENT = (
    f"QPushButton {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
    f"stop:0 {_VIOLET},stop:1 {_BLUE}); color: white; border: none; "
    f"border-radius: 4px; padding: 5px 10px; font-family: 'Segoe UI'; "
    f"font-size: 11px; font-weight: 700; letter-spacing: 0.5px; min-height: 32px; }}"
    f"QPushButton:hover {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
    f"stop:0 #9333ea,stop:1 #3b82f6); }}"
    f"QPushButton:pressed {{ background: {_VIOLET}; }}"
)
_BTN_CLEAR = (
    f"QPushButton {{ background: transparent; color: {_DIM}; "
    f"border: 1px solid {_BORDER}; border-radius: 4px; padding: 5px 10px; "
    f"font-family: 'Segoe UI'; font-size: 11px; min-height: 32px; }}"
    f"QPushButton:hover {{ color: {_TEXT}; border-color: {_ACCENT}; }}"
    f"QPushButton:pressed {{ color: {_ACCENT}; }}"
)
# S5 Slack Bracket — amber/gold gradient so it's visually distinct from the
# violet/blue Thick button. Matches the canvas legend "violet ring = S5" only
# at the outline; the fill is a warm gold to mean "optional manual kit".
_BTN_S5 = (
    "QPushButton { background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
    "stop:0 #f59e0b,stop:1 #d97706); color: white; border: none; "
    "border-radius: 4px; padding: 5px 10px; font-family: 'Segoe UI'; "
    "font-size: 11px; font-weight: 700; letter-spacing: 0.5px; min-height: 32px; }"
    "QPushButton:hover { background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
    "stop:0 #fbbf24,stop:1 #ea580c); }"
    "QPushButton:pressed { background: #d97706; }"
)
_BTN_ORANGE = _btn("#ea7320", "#c2601a", "#a05015")
_BTN_PURPLE = _btn("#9333ea", "#7e22ce", "#6b21a8")
_BTN_CYAN   = _btn("#0891b2", "#0e7490", "#155e75")
_BTN_TEAL   = _btn("#059669", "#047857", "#065f46")

# ── Animated dashed-ring overlay (marching ants around each pole) ─────────────

class _SpinRing(QgsMapCanvasItem):
    """Draws dashed circles at a set of map points with an animated dash
    offset so the dashes appear to travel around the ring (marching ants)."""

    def __init__(self, canvas, color, radius_px, width_px, dash_pattern, tick_ms=80):
        super().__init__(canvas)
        self._canvas = canvas
        self._color = color
        self._radius = float(radius_px)
        self._width = float(width_px)
        self._pattern = list(dash_pattern)
        self._phase = 0.0
        self._points = []
        # Animation timer exists for API compatibility but is NOT started —
        # static dashed rings keep the visual distinction without the per-frame
        # repaint cost.
        self._timer = QTimer()
        self._timer.timeout.connect(self._tick)
        self.setZValue(100)

    def _tick(self):
        pass  # no-op — spin disabled for performance

    def setPoints(self, pts):
        self.prepareGeometryChange()
        self._points = list(pts)
        self.update()

    def setTickInterval(self, ms):
        ms = int(ms)
        if self._timer.interval() != ms:
            self._timer.setInterval(ms)

    def clear(self):
        self.setPoints([])

    def stop(self):
        self._timer.stop()

    def boundingRect(self):
        return self._canvas.sceneRect()

    def paint(self, painter, option=None, widget=None):
        if not self._points:
            return
        pen = QPen(self._color)
        pen.setWidthF(self._width)
        pen.setStyle(Qt.PenStyle.SolidLine)
        pen.setCapStyle(Qt.PenCapStyle.FlatCap)
        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        m2p = self._canvas.mapSettings().mapToPixel()
        for p in self._points:
            sp = m2p.transform(p.x(), p.y())
            painter.drawEllipse(QPointF(sp.x(), sp.y()), self._radius, self._radius)


class _NullRing:
    """Stub that accepts the ring API but draws nothing and uses no CPU."""
    def setPoints(self, pts): pass
    def setTickInterval(self, ms): pass
    def clear(self): pass
    def stop(self): pass


class _SpinRingPreview(QLabel):
    """Small animated dashed-ring widget for the panel legend so the preview
    visually matches the canvas overlay (same colour, dash rhythm, and spin)."""

    def __init__(self, color, dash_pattern, diameter_px=22, width_px=2.0, tick_ms=80):
        super().__init__()
        self._color = color
        self._pattern = list(dash_pattern)
        self._diameter = int(diameter_px)
        self._width = float(width_px)
        self._phase = 0.0
        self.setFixedSize(self._diameter + 4, self._diameter + 4)
        self.setStyleSheet('background: transparent;')
        # Spin disabled — static dashed ring in the legend.

    def _tick(self):
        pass

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        pen = QPen(self._color)
        pen.setWidthF(self._width)
        pen.setStyle(Qt.PenStyle.SolidLine)
        pen.setCapStyle(Qt.PenCapStyle.FlatCap)
        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        cx = self.width() / 2.0
        cy = self.height() / 2.0
        r = self._diameter / 2.0
        painter.drawEllipse(QPointF(cx, cy), r, r)


# ── Splice Route Viewer panel ─────────────────────────────────────────────────
# Colour-codes every fibre hop of a chosen PON on the canvas so the Excel splice
# plan can be cross-checked against the physical layers at a glance. Each row in a
# per-PON sheet (OLT port → feeder → AGG dome → FTS → distribution → DIS dome →
# STS → drop → ONT) maps to features here via shared label fields.

_HOP_COLOURS = OrderedDict([
    ('feeder', QColor(239,  68,  68, 255)),   # red    — feeder cable (secondary/primary)
    ('dist',   QColor(234, 115,  32, 255)),   # orange — distribution cable
    ('drop',   QColor(250, 204,  21, 235)),   # yellow — drop cables
    ('agg',    QColor( 34, 211, 238, 255)),   # cyan   — AGG dome (FTS / fusion)
    ('dis',    QColor( 59, 130, 246, 255)),   # blue   — DIS dome (STS / connectorised)
    ('fts',    QColor(217,  70, 239, 255)),   # magenta— FTS splitter (1:16)
    ('sts',    QColor( 34, 197,  94, 255)),   # green  — STS splitter (1:8)
    ('ont',    QColor(248, 250, 252, 235)),   # white  — ONT / home
])

_HOP_TITLES = {
    'feeder': 'FEEDER', 'dist': 'DISTRIBUTION', 'drop': 'DROPS',
    'agg': 'AGG DOME', 'dis': 'DIS DOMES', 'fts': 'FTS 1:16',
    'sts': 'STS 1:8', 'ont': 'ONTs',
}


class _RouteLabels(QgsMapCanvasItem):
    """Canvas overlay that draws small text pills at map points — used by the
    Route Viewer to label the splitters / legs / domes / cables of the shown route
    (QgsRubberBand can't render text)."""

    def __init__(self, canvas):
        super().__init__(canvas)
        self._canvas = canvas
        self._items = []          # list of (QgsPointXY, text, QColor)
        self.setZValue(130)

    def set_items(self, items):
        self.prepareGeometryChange()
        self._items = list(items)
        self.update()

    def clear(self):
        self.set_items([])

    def boundingRect(self):
        return self._canvas.sceneRect()

    def paint(self, painter, option=None, widget=None):
        if not self._items:
            return
        from qgis.PyQt.QtGui import QFont, QFontMetrics
        from qgis.PyQt.QtCore import QRectF
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        m2p = self._canvas.mapSettings().mapToPixel()
        for item in self._items:
            pt, text, col = item[0], item[1], item[2]
            sz = item[3] if len(item) > 3 else 9          # optional per-label size
            font = QFont('Segoe UI', sz); font.setBold(True)
            painter.setFont(font)
            fm = QFontMetrics(font)
            sp = m2p.transform(pt.x(), pt.y())
            w = fm.horizontalAdvance(text) + 10
            h = fm.height() + 4
            rect = QRectF(sp.x() + 8, sp.y() - h / 2.0, w, h)
            painter.setPen(QPen(QColor(0, 0, 0, 160)))     # thin dark outline pill
            painter.setBrush(QColor(8, 10, 18, 225))
            painter.drawRoundedRect(rect, 4, 4)
            painter.setPen(QPen(col))
            painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, text)


class _ClickFrame(QFrame):
    """A QFrame that runs a callback when clicked — used for the route-diagram hop
    cards (click a hop → isolate it on the canvas). Crash-proof: a raising callback
    is swallowed so a bad click can never take QGIS down."""

    def __init__(self, on_click, parent=None):
        super().__init__(parent)
        self._on_click = on_click
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def mousePressEvent(self, e):
        try:
            if self._on_click is not None:
                self._on_click()
        except Exception:
            pass
        super().mousePressEvent(e)


class _PanelDock(QDockWidget):
    """QGIS dock that hosts a plugin tool panel so it behaves exactly like the
    native attribute-table dock: dockable to ANY edge (left/right/top/bottom),
    floatable, freely resizable (drag to any size, up to full screen), closable,
    and — because its content sits in a QScrollArea — it never runs off-screen.
    Pass on_close to run teardown when the dock is destroyed."""

    def __init__(self, title, iface, on_close=None):
        super().__init__(title, iface.mainWindow())
        self._on_close = on_close
        self.setAllowedAreas(Qt.DockWidgetArea.AllDockWidgetAreas)
        self.setFeatures(QDockWidget.DockWidgetFeature.DockWidgetClosable
                         | QDockWidget.DockWidgetFeature.DockWidgetMovable
                         | QDockWidget.DockWidgetFeature.DockWidgetFloatable)
        # Flat Velocity title bar (minimise · maximise · close) when docked; a real OS
        # window frame (min/max/close + resize + taskbar) when floating. Both the flat
        # bar AND the float-frame swap are owned by apply_dock_chrome now, so there is
        # no local topLevelChanged handler here (it would double-fire). Fail-open so a
        # styling hiccup never blocks a tool panel opening.
        try:
            from .nexus_dock import apply_dock_chrome
            apply_dock_chrome(self)
        except Exception:
            pass

    def closeEvent(self, e):
        # the dock's X just hides it (Qt default) so re-opening keeps the panel
        # alive; on_close (when set by the caller) runs teardown on real destroy.
        try:
            if callable(self._on_close):
                self._on_close()
        except Exception:
            pass
        super().closeEvent(e)


class SpliceRouteViewerPanel(QWidget):
    """Dockable panel: pick an OLT port (PON) and light up its whole fibre route
    on the canvas, colour-coded by hop, with a label read-out to tick against the
    Excel splice plan. Optionally narrows to a single STS leg."""

    PORT_OFFSET = {15: 224, 16: 240, 17: 256, 18: 272, 19: 288}

    def __init__(self, iface, parent=None):
        super().__init__(parent)                 # hosted in a _PanelDock (dockable)
        self.setObjectName('vfRouteViewerPanel')
        self.iface  = iface
        self.canvas = iface.mapCanvas()
        self.setWindowTitle('🔦 Splice Route Viewer')
        self.setMinimumWidth(360)

        self._bands = {}
        self._build_bands()
        self._layers = {}
        self._idx    = None          # built lazily on first show / index build
        self._solo_saved = None       # {layer_id: original_opacity} when solo active
        self._programmatic_select = False   # True while WE drive layer selection
        self._walk_timer = None       # short-lived QTimer for "walk the route"
        self._build_index()
        self._build_ui()

    # ── port ↔ pon helpers ──────────────────────────────────────────────────
    @classmethod
    def _port_to_pon(cls, port):
        try:
            card = int(port[1:3]); p = int(port[4:6])
            return cls.PORT_OFFSET[card] + p
        except Exception:
            return None

    @staticmethod
    def _pon_to_zone(pon):
        try:
            return (int(pon) - 235) // 16 + 17
        except Exception:
            return None

    @classmethod
    def _pon_to_port(cls, pon):
        try:
            pon = int(pon)
            for card, off in cls.PORT_OFFSET.items():
                p = pon - off
                if 1 <= p <= 16:
                    return f"C{card}P{p:02d}"
        except Exception:
            pass
        return None

    def _feature_info(self, layer, feat):
        """Identify a clicked feature → which PON sheet it belongs to. Returns a
        dict {label, lname, pon, zone, sheet, in_plan, note, extra}."""
        import re
        lname = layer.name()
        lab = self._label_of(feat) or '(no label)'
        # PON: pon_no field first, else OLT port in the label (splitters)
        pon = None
        for fld in ('pon_no', 'PON_no', 'pon'):
            i = feat.fields().indexOf(fld)
            if i >= 0 and feat[i] not in (None, ''):
                try:
                    pon = int(feat[i]); break
                except Exception:
                    pass
        if pon is None:
            m = re.search(r'C\d\dP\d\d', lab)
            if m:
                pon = self._port_to_pon(m.group(0))
        low = lname.lower()
        spare = 'spare' in low
        info = {'label': lab, 'lname': lname, 'pon': pon,
                'zone': self._pon_to_zone(pon) if pon else None,
                'sheet': self._pon_to_port(pon) if pon else None,
                'in_plan': not spare, 'note': '', 'extra': ''}
        # which section of the sheet this feature lives in
        if spare:
            info['note'] = 'SPARE capacity — NOT in the splice plan'
        elif 'distribution' in low:
            info['note'] = 'DISTRIBUTION section'
        elif 'secondary' in low or 'primary' in low:
            info['note'] = 'FEEDER row'
        elif 'fts' in low:
            info['note'] = 'FTS 1:16 (sheet header + feeder row)'
        elif 'sts' in low:
            info['note'] = 'STS 1:8 (one leg block)'
        elif 'drop' in low:
            info['note'] = 'DROP rows (DR number)'
        elif 'ont' in low or 'home' in low:
            info['note'] = 'DR rows (one home)'
        elif 'splice' in low:
            info['note'] = 'AGG dome (FTS fusion)'
        elif 'connectorised' in low:
            info['note'] = 'DIS dome (STS connector)'
        cc = feat.fields().indexOf('cblcpty')
        if cc >= 0 and feat[cc] not in (None, ''):
            info['extra'] = str(feat[cc])
        return info

    # ── layer / rubber-band setup ───────────────────────────────────────────
    def _lyr(self, *names):
        proj = QgsProject.instance()
        lays = list(proj.mapLayers().values())
        # Exact name match. When a project carries BOTH a bare layer and its
        # canonical "… v1" HLD deliverable (e.g. a raw/stale import shadowing the
        # real layer — bare 'Drop Cable' with null strtfeat vs 'Drop Cable v1'),
        # prefer the "v1" layer so the viewer always reads the splice-plan data.
        exact = [l for n in names for l in lays if l.name().lower() == n.lower()]
        if exact:
            return next((l for l in exact if l.name().lower().endswith(' v1')), exact[0])
        for n in names:                                   # fuzzy contains (fallback)
            for l in lays:
                if n.lower() in l.name().lower():
                    return l
        return None

    @staticmethod
    def _label_of(feat):
        for c in ('label', 'label_1', 'Label', 'LABEL', 'name'):
            i = feat.fields().indexOf(c)
            if i >= 0 and feat[i] not in (None, ''):
                return str(feat[i])
        return None

    @staticmethod
    def _field_val(feat, *names):
        for n in names:
            i = feat.fields().indexOf(n)
            if i >= 0 and feat[i] not in (None, ''):
                return str(feat[i])
        return None

    @staticmethod
    def _line_far_end(line_geom, ref_geom):
        """The line's endpoint FARTHEST from ref_geom, as a point QgsGeometry — i.e.
        a drop cable's HOME end (the STS/DIS is the near end). None if unusable."""
        from qgis.core import QgsGeometry, QgsPointXY
        try:
            if line_geom is None or line_geom.isEmpty():
                return None
            if line_geom.isMultipart():
                pts = [p for pl in line_geom.asMultiPolyline() for p in pl]
            else:
                pts = line_geom.asPolyline()
            if len(pts) < 2:
                return None
            ends = [pts[0], pts[-1]]
            if ref_geom is not None and not ref_geom.isEmpty():
                rc = ref_geom.centroid().asPoint()
                far = max(ends, key=lambda q: (q.x() - rc.x()) ** 2 + (q.y() - rc.y()) ** 2)
            else:
                far = pts[-1]
            return QgsGeometry.fromPointXY(QgsPointXY(far))
        except Exception:
            return None

    def _build_bands(self):
        line_hops = [('feeder', 7), ('dist', 5), ('drop', 3)]
        for hop, w in line_hops:
            b = QgsRubberBand(self.canvas, QgsWkbTypes.GeometryType.LineGeometry)
            b.setColor(_HOP_COLOURS[hop]); b.setWidth(w)
            self._bands[hop] = b
        pt_hops = [
            ('agg', QgsRubberBand.IconType.ICON_FULL_DIAMOND, 26),
            ('dis', QgsRubberBand.IconType.ICON_CIRCLE,       16),
            ('fts', QgsRubberBand.IconType.ICON_FULL_DIAMOND, 30),
            ('sts', QgsRubberBand.IconType.ICON_BOX,          20),
            ('ont', QgsRubberBand.IconType.ICON_CIRCLE,        9),
        ]
        for hop, icon, size in pt_hops:
            b = QgsRubberBand(self.canvas, QgsWkbTypes.GeometryType.PointGeometry)
            b.setColor(_HOP_COLOURS[hop]); b.setIcon(icon)
            b.setIconSize(size); b.setWidth(3)
            b.setSecondaryStrokeColor(QColor(10, 12, 20, 220))
            self._bands[hop] = b
        # POP marker — only lit when the POP hop card is clicked (it sits ~km from
        # the cluster, so it never joins the default whole-route extent).
        pb = QgsRubberBand(self.canvas, QgsWkbTypes.GeometryType.PointGeometry)
        pb.setColor(QColor(_ACCENT)); pb.setIcon(QgsRubberBand.IconType.ICON_FULL_DIAMOND)
        pb.setIconSize(34); pb.setWidth(3)
        pb.setSecondaryStrokeColor(QColor(10, 12, 20, 220))
        self._bands['pop'] = pb
        # flow arrows: a soft cyan GLOW band underneath + a crisp head on top, for a
        # neon look that reads on any basemap. Both marched by _tick_arrows.
        ag = QgsRubberBand(self.canvas, QgsWkbTypes.GeometryType.PolygonGeometry)
        ag.setColor(QColor(0, 231, 255, 55))         # soft halo edge
        ag.setFillColor(QColor(0, 231, 255, 60))     # soft cyan glow
        ag.setWidth(3)
        self._bands['arrow_glow'] = ag
        ab = QgsRubberBand(self.canvas, QgsWkbTypes.GeometryType.PolygonGeometry)
        ab.setColor(QColor(8, 20, 34, 235))          # crisp dark edge
        ab.setFillColor(QColor(120, 244, 255, 250))  # bright cyan-white core
        ab.setWidth(1)
        self._bands['arrow'] = ab
        # bright halo ring around whatever is SELECTED on the Excel sheet (or the
        # scope-combo STS) so the picked splitter/home is unmistakable
        halo = QgsRubberBand(self.canvas, QgsWkbTypes.GeometryType.PointGeometry)
        halo.setColor(QColor(255, 235, 0, 255))           # vivid yellow
        halo.setIcon(QgsRubberBand.IconType.ICON_CIRCLE)
        halo.setIconSize(44); halo.setWidth(5)
        halo.setSecondaryStrokeColor(QColor(0, 0, 0, 200))
        self._bands['halo'] = halo
        # text-label overlay (splitters / legs / domes / cables)
        self._labels = _RouteLabels(self.canvas)

    def _build_index(self):
        """Read the splice layers once into light lookup tables keyed for fast
        per-port route resolution. Stores feature ids so we can also select the
        features in their layers (drives the attribute table for cross-check)."""
        import re
        from qgis.core import QgsGeometry
        L = self._layers = {
            'fts':  self._lyr('FTS Splitters', 'FTS Splitters v1'),
            'sts':  self._lyr('STS Splitters', 'STS Splitters v1'),
            'agg':  self._lyr('Enclosures Splice', 'Enclosures Splice v1'),
            'dis':  self._lyr('Enclosures Connectorised', 'Enclosures Connectorised v1'),
            'dist': self._lyr('Distribution Cable', 'Distribution Cable v1'),
            'drop': self._lyr('Drop Cable', 'Drop Cable v1'),
            'ont':  self._lyr('ONT', 'ONT v1'),
            'sec':  self._lyr('Secondary Cable', 'Secondary Cable v1'),
            'pri':  self._lyr('Primary Cable', 'Primary Cable v1'),
            'spare': self._lyr('Spare Drop Cable', 'Spare Drop Cable v1'),
            'pop':  self._lyr('POP', 'POP'),
        }
        PORT = re.compile(r'C\d\dP\d\d')
        # The AGG/DIS dome token is embedded INSIDE the splitter label after a
        # prefix (e.g. "MOA.STS.16.DIS.DM.P.F726.C15P11.L1"), so match the bare
        # "AGG.DM.P.x" / "DIS.DM.P.x" token and rebuild the dome label "MOA.<tok>"
        # to match the dome layer's label_1 and the drop strtfeat values.
        AGG  = re.compile(r'AGG\.DM\.P\.\w+')
        DIS  = re.compile(r'DIS\.DM\.P\.\w+')
        LEG  = re.compile(r'\.(L\d+)')

        idx = {
            'fts_by_port':  {},     # port -> {fid, geom, label, agg}
            'sts_by_port':  {},     # port -> [ {fid, geom, label, dis, leg} ]
            'agg_by_label': {},     # label_1 -> {fid, geom}
            'dis_by_label': {},     # label_1 -> {fid, geom}
            'drops_by_dis': {},     # dis label -> [ {fid, geom, label, ont} ]
            'ont_by_label': {},     # ont label -> {fid, geom}
            'dist_by_pon':  {},     # pon -> [ {fid, geom, label} ]
            'feed_by_pon':  {},     # pon -> [ {fid, geom, label, kind} ]  (fallback)
            'feed_by_label': {},    # cable label -> {fid, geom, strt, end, kind}
            'feed_by_endfeat': {},  # endfeat pole -> [cable label]  (upstream trace)
            'ports':        [],     # sorted port list
        }

        if L['fts']:
            for f in L['fts'].getFeatures():
                lab = self._label_of(f)
                if not lab:
                    continue
                m = PORT.search(lab)
                if not m or m.group(0) in idx['fts_by_port']:
                    continue
                a = AGG.search(lab)
                idx['fts_by_port'][m.group(0)] = {
                    'fid': f.id(), 'geom': QgsGeometry(f.geometry()),
                    'label': lab, 'agg': ('MOA.' + a.group(0)) if a else None,
                    'strtfeat': self._field_val(f, 'strtfeat')}
        if L['sts']:
            for f in L['sts'].getFeatures():
                lab = self._label_of(f)
                if not lab:
                    continue
                m = PORT.search(lab)
                if not m:
                    continue
                d = DIS.search(lab); lg = LEG.search(lab)
                idx['sts_by_port'].setdefault(m.group(0), []).append({
                    'fid': f.id(), 'geom': QgsGeometry(f.geometry()),
                    'label': lab, 'dis': ('MOA.' + d.group(0)) if d else None,
                    'leg': lg.group(1) if lg else None})
        for key, lyr in (('agg_by_label', L['agg']), ('dis_by_label', L['dis'])):
            if not lyr:
                continue
            for f in lyr.getFeatures():
                lab = self._label_of(f)
                if lab and lab not in idx[key]:
                    idx[key][lab] = {'fid': f.id(), 'geom': QgsGeometry(f.geometry())}
        if L['drop']:
            for f in L['drop'].getFeatures():
                lab = self._label_of(f)
                strt = self._field_val(f, 'strtfeat')
                ont  = self._field_val(f, 'endfeat')
                if strt is None:
                    continue
                idx['drops_by_dis'].setdefault(strt, []).append({
                    'fid': f.id(), 'geom': QgsGeometry(f.geometry()),
                    'label': lab, 'ont': ont})
        if L['ont']:
            for f in L['ont'].getFeatures():
                lab = self._label_of(f)
                if lab and lab not in idx['ont_by_label']:
                    idx['ont_by_label'][lab] = {'fid': f.id(), 'geom': QgsGeometry(f.geometry())}
        # POP — the single aggregation point (lives in the PH1/POP layer, ~km from
        # the PON cluster). Indexed so the POP hop card can light it on demand.
        idx['pop'] = None
        if L.get('pop'):
            for f in L['pop'].getFeatures():
                g = QgsGeometry(f.geometry())
                if g and not g.isEmpty():
                    idx['pop'] = {'fid': f.id(), 'geom': g,
                                  'label': self._label_of(f) or 'POP'}
                    break
        if L['dist']:
            for f in L['dist'].getFeatures():
                pon = self._field_val(f, 'pon_no')
                if pon is None:
                    continue
                idx['dist_by_pon'].setdefault(pon, []).append({
                    'fid': f.id(), 'geom': QgsGeometry(f.geometry()),
                    'label': self._label_of(f)})
        for kind, lyr in (('Secondary', L['sec']), ('Primary', L['pri'])):
            if not lyr:
                continue
            for f in lyr.getFeatures():
                lab  = self._label_of(f)
                geom = QgsGeometry(f.geometry())
                strt = self._field_val(f, 'strtfeat')
                end  = self._field_val(f, 'endfeat')
                pon  = self._field_val(f, 'pon_no')
                if pon is not None:
                    idx['feed_by_pon'].setdefault(pon, []).append(
                        {'fid': f.id(), 'geom': geom, 'label': lab, 'kind': kind})
                if lab:
                    idx['feed_by_label'][lab] = {'fid': f.id(), 'geom': geom,
                                                 'strt': strt, 'end': end, 'kind': kind}
                if end:
                    idx['feed_by_endfeat'].setdefault(end, []).append(lab)
        # The generator picks the feeder by WHICH cable the FTS physically sits on
        # (vertex analysis in fts_cable_map.json), then traces upstream — NOT by
        # pon_no (feeders are shared trunks). Load that map so the highlighted
        # feeder matches the Excel feeder row exactly.
        idx['fts_cable_map'] = {}
        try:
            import json as _json, os as _os
            _p = r'C:/Temp/fts_cable_map.json'
            if _os.path.exists(_p):
                with open(_p, encoding='utf-8') as _f:
                    idx['fts_cable_map'] = _json.loads(_f.read())
        except Exception:
            idx['fts_cable_map'] = {}
        # Corrected feeder path per PON — the SAME geometry-rooted POP->AGG route the
        # Excel splice plan consumes (feeder_routes.json from feeder_fix_fable.py).
        # Aligns the viewer's feeder hop with the Excel; absent -> legacy trace.
        idx['feeder_routes'] = {}
        try:
            import json as _jf, os as _osf
            _fp = _osf.environ.get('VF_FEEDER_ROUTES', r'C:/Temp/feeder_routes.json')
            if _osf.path.exists(_fp):
                with open(_fp, encoding='utf-8') as _ff:
                    _routes = _jf.loads(_ff.read()).get('routes', {})
                for _rpon, _rt in _routes.items():
                    _cables = [h.get('cable') for h in (_rt.get('hops') or []) if h.get('cable')]
                    if _cables:
                        idx['feeder_routes'][str(_rpon)] = _cables
        except Exception:
            idx['feeder_routes'] = {}
        # Resolve each FTS to its real AGG dome FEATURE by GEOMETRY — the FTS lives
        # inside its AGG dome, so the nearest Enclosures-Splice dome IS the
        # aggregation point. The AGG name embedded in the FTS label is drifted
        # (matches a dome for only ~5/66, those 0.6-2.4 km off), so we do NOT trust
        # it — same nearest-dome resolution the splice plan uses (JJ 2026-06-30).
        # Label is a last resort only when no dome geometry exists.
        agg_items = [(lab, e['fid'], e['geom'])
                     for lab, e in idx['agg_by_label'].items()
                     if e['geom'] is not None and not e['geom'].isEmpty()]
        for fts in idx['fts_by_port'].values():
            fg = fts['geom']
            best = None
            if fg is not None and not fg.isEmpty() and agg_items:
                fc = fg.centroid()
                best = min(agg_items, key=lambda it: it[2].centroid().distance(fc))
            if best:
                fts.update(agg_fid=best[1], agg_geom=best[2],
                           agg_label=best[0], agg_matched='nearest')
            else:
                hit = idx['agg_by_label'].get(fts['agg'])
                if hit:
                    fts.update(agg_fid=hit['fid'], agg_geom=hit['geom'],
                               agg_label=fts['agg'], agg_matched='label')
                else:
                    fts.update(agg_fid=None, agg_geom=None,
                               agg_label=fts['agg'], agg_matched='none')

        # Resolve each STS to the DIS dome FEATURE it physically sits on (nearest).
        # The STS's label-dome is a clean 1:1 reference, but the dome POINT layer
        # wasn't snapped with the STS, so the label-point is often stray (250-530m
        # away). Draw the marker at the co-located dome instead, keeping the plan
        # label. Zero data change — display only.
        from qgis.core import QgsSpatialIndex
        dis_lyr = L['dis']
        if dis_lyr is not None:
            si = QgsSpatialIndex()
            di_geom = {}
            for f in dis_lyr.getFeatures():
                g = f.geometry()
                if g and not g.isEmpty():
                    si.insertFeature(f)
                    di_geom[f.id()] = QgsGeometry(g)
            for lst in idx['sts_by_port'].values():
                for s in lst:
                    g = s.get('geom')
                    s['dis_geom'] = None; s['dis_fid'] = None
                    if g is None or g.isEmpty():
                        continue
                    try:
                        nb = si.nearestNeighbor(g.centroid().asPoint(), 1)
                    except Exception:
                        nb = []
                    if nb:
                        s['dis_fid'] = nb[0]
                        s['dis_geom'] = di_geom.get(nb[0])

        # Spatial index of distribution cables so we can draw the cable each dome
        # PHYSICALLY sits on, regardless of pon_no tag — distribution cables are
        # shared trunks tagged to one PON, like the feeder. pon_no filtering alone
        # leaves most of the route undrawn.
        idx['dist_index'] = None
        idx['dist_feats'] = {}
        if L['dist'] is not None:
            dsi = QgsSpatialIndex()
            for f in L['dist'].getFeatures():
                g = f.geometry()
                if g and not g.isEmpty():
                    dsi.insertFeature(f)
                    idx['dist_feats'][f.id()] = {
                        'fid': f.id(), 'geom': QgsGeometry(g),
                        'label': self._label_of(f)}
            idx['dist_index'] = dsi

        idx['ports'] = sorted(idx['fts_by_port'].keys())
        self._idx = idx

    def _resolve_distribution(self, dome_geoms, agg_geom, pon):
        """Distribution cables that PHYSICALLY serve this PON — the cable each of
        its domes (and the AGG dome) sits on — unioned with the pon_no-tagged ones.
        Cables are shared trunks, so the tag alone misses most of the route."""
        si = self._idx.get('dist_index')
        feats = self._idx.get('dist_feats') or {}
        out = {}
        if si is not None:
            pts = list(dome_geoms)
            if agg_geom is not None and not agg_geom.isEmpty():
                pts.append(agg_geom)
            for g in pts:
                if g is None or g.isEmpty():
                    continue
                try:
                    cand = si.nearestNeighbor(g.centroid().asPoint(), 3)
                except Exception:
                    cand = []
                best, bestd = None, 1e18
                for fid in cand:
                    fe = feats.get(fid)
                    if fe and g.distance(fe['geom']) < bestd:
                        bestd = g.distance(fe['geom']); best = fid
                if best is not None and bestd * 111320 < 30:   # dome sits on this cable
                    out[best] = feats[best]
        for dc in self._idx['dist_by_pon'].get(pon, []):
            if dc.get('fid') is not None:
                out.setdefault(dc['fid'], dc)
        return list(out.values())

    # ── UI ──────────────────────────────────────────────────────────────────
    def _build_ui(self):
        from qgis.PyQt.QtWidgets import QComboBox, QListWidget
        self.setStyleSheet(f"QWidget#vfRouteViewerPanel {{ background: {_BG}; }}")
        layout = QVBoxLayout(self)
        layout.setSpacing(6); layout.setContentsMargins(12, 12, 12, 10)

        subtitle = QLabel('Pick an OLT port (PON) → light up its fibre route on the canvas.')
        subtitle.setWordWrap(True); subtitle.setStyleSheet(_SUBTITLE_LBL)
        layout.addWidget(subtitle)

        if not self._idx['ports']:
            warn = QLabel('⚠ No FTS Splitters layer found in this project.\n'
                          'Open the splice project (with FTS/STS/dome layers) and reopen.')
            warn.setWordWrap(True); warn.setStyleSheet(_STATUS_LBL)
            layout.addWidget(warn)
            return

        # ── Find box: type any DR / dome / STS / cable / port → jump + highlight
        from qgis.PyQt.QtWidgets import QLineEdit
        find_lbl = QLabel('FIND  (DR · dome · STS · cable · port)')
        find_lbl.setStyleSheet(_SECTION_LBL); layout.addWidget(find_lbl)
        self.find_edit = QLineEdit()
        self.find_edit.setPlaceholderText('e.g. DR1876230, F726, C16P04, DF.24F…')
        self.find_edit.setStyleSheet(
            f"QLineEdit {{ background:#11131f; color:{_TEXT}; border:1px solid {_BORDER};"
            f" border-radius:4px; padding:6px 8px; font-family:Consolas; font-size:11px; }}"
            f"QLineEdit:focus {{ border-color:{_ACCENT}; }}")
        self.find_edit.returnPressed.connect(self._find)
        layout.addWidget(self.find_edit)

        sel_lbl = QLabel('OLT PORT  ·  PON')
        sel_lbl.setStyleSheet(_SECTION_LBL); layout.addWidget(sel_lbl)

        self.port_combo = QComboBox()
        self.port_combo.setStyleSheet(_COMBO_CSS)
        for port in self._idx['ports']:
            pon = self._port_to_pon(port); zone = self._pon_to_zone(pon)
            homes = self._home_count(port)
            self.port_combo.addItem(
                f'{port}    PON {pon} · Zone {zone}    ({homes} homes)', port)
        self.port_combo.currentIndexChanged.connect(self._on_port_changed)
        layout.addWidget(self.port_combo)

        nav = QHBoxLayout(); nav.setSpacing(8)
        btn_prev = QPushButton('◀  Prev'); btn_prev.setStyleSheet(_BTN_CLEAR)
        btn_prev.clicked.connect(lambda: self._step(-1)); nav.addWidget(btn_prev)
        btn_next = QPushButton('Next  ▶'); btn_next.setStyleSheet(_BTN_CLEAR)
        btn_next.clicked.connect(lambda: self._step(1)); nav.addWidget(btn_next)
        layout.addLayout(nav)

        # health card: homes · fill% · loss-margin (green/amber/red at a glance)
        self._health_box = QFrame()
        self._health_layout = QHBoxLayout(self._health_box)
        self._health_layout.setContentsMargins(0, 4, 0, 0)
        self._health_layout.setSpacing(8)
        layout.addWidget(self._health_box)

        sts_lbl = QLabel('SCOPE  (narrow to one STS leg)')
        sts_lbl.setStyleSheet(_SECTION_LBL); layout.addWidget(sts_lbl)
        self.sts_combo = QComboBox(); self.sts_combo.setStyleSheet(_COMBO_CSS)
        layout.addWidget(self.sts_combo)

        act = QHBoxLayout(); act.setSpacing(8)
        btn_show = QPushButton('🔦  Show on Canvas'); btn_show.setStyleSheet(_BTN_GREEN)
        btn_show.clicked.connect(self._show_route); act.addWidget(btn_show)
        btn_clear = QPushButton('Clear'); btn_clear.setStyleSheet(_BTN_CLEAR)
        btn_clear.clicked.connect(self._clear); act.addWidget(btn_clear)
        layout.addLayout(act)

        act2 = QHBoxLayout(); act2.setSpacing(8)
        btn_walk = QPushButton('▶  Walk the route'); btn_walk.setStyleSheet(_BTN_GRADIENT)
        btn_walk.clicked.connect(self._walk_route); act2.addWidget(btn_walk)
        btn_zoom = QPushButton('🔍 Zoom'); btn_zoom.setStyleSheet(_BTN_CLEAR)
        btn_zoom.clicked.connect(self._zoom_route); act2.addWidget(btn_zoom)
        btn_card = QPushButton('🖨 Route card'); btn_card.setStyleSheet(_BTN_CLEAR)
        btn_card.clicked.connect(self._route_card); act2.addWidget(btn_card)
        layout.addLayout(act2)

        # ── THE ROUTE — visual hop chain POP -> home (the headline view) ──────
        diag_lbl = QLabel('THE ROUTE  ·  POP → home   (click a hop to isolate it)')
        diag_lbl.setStyleSheet(_SECTION_LBL); layout.addWidget(diag_lbl)
        # plain container — the whole panel scrolls inside its dock, so the diagram
        # shows all 9 hops inline (no nested scroll area).
        diagram_box = QFrame()
        diagram_box.setObjectName('vfDiagramBox')
        diagram_box.setStyleSheet(
            f"QFrame#vfDiagramBox {{ background:#0a111d; border:1px solid {_BORDER};"
            f" border-radius:8px; }}")
        self._diagram_layout = QVBoxLayout(diagram_box)
        self._diagram_layout.setContentsMargins(10, 10, 10, 10)
        self._diagram_layout.setSpacing(0)
        self._hop_cards = {}
        self._isolated_hop = None
        layout.addWidget(diagram_box)

        # plain-English "how this PON runs" — no fibre background needed to read it
        self._why_box = QFrame()
        self._why_box.setObjectName('vfWhyBox')
        self._why_box.setStyleSheet(
            "QFrame#vfWhyBox { background:rgba(34,197,94,0.06);"
            " border:1px solid #1c3a30; border-radius:8px; }")
        why_lay = QVBoxLayout(self._why_box)
        why_lay.setContentsMargins(11, 9, 11, 10); why_lay.setSpacing(4)
        why_hdr = QLabel('HOW THIS PON RUNS')
        why_hdr.setStyleSheet(
            "color:#3DFF9A; font-family:Consolas; font-size:9px;"
            " font-weight:700; letter-spacing:1px; background:transparent; border:none;")
        why_lay.addWidget(why_hdr)
        self._why_lbl = QLabel('—'); self._why_lbl.setWordWrap(True)
        self._why_lbl.setStyleSheet(
            "color:#cfe0f5; font-family:'Segoe UI'; font-size:11px;"
            " background:transparent; border:none;")
        why_lay.addWidget(self._why_lbl)
        layout.addWidget(self._why_box)

        # ⚠ flags — dome-with-no-STS / stranded homes / unresolved hop (hidden when clean)
        self._flags_lbl = QLabel(''); self._flags_lbl.setWordWrap(True)
        self._flags_lbl.setVisible(False)
        self._flags_lbl.setStyleSheet(
            "QLabel { background:rgba(245,166,35,0.08); color:#f1d9a8;"
            " border:1px solid #5a4520; border-radius:8px; padding:7px 9px;"
            " font-family:Consolas; font-size:9px; }")
        layout.addWidget(self._flags_lbl)

        from qgis.PyQt.QtWidgets import QCheckBox
        _chk_css = f"QCheckBox {{ color:{_TEXT}; font-family:'Segoe UI'; font-size:10px; }}"
        self.solo_chk = QCheckBox('Solo — dim every other layer so only this route shows')
        self.solo_chk.setChecked(True); self.solo_chk.setStyleSheet(_chk_css)
        self.solo_chk.toggled.connect(self._on_solo_toggled)
        layout.addWidget(self.solo_chk)

        # last-mile drop cables fan out 1:8 from every STS — off by default so the
        # canvas shows the clean trunk (feeder -> FTS -> distribution -> STS) flow.
        self.drops_chk = QCheckBox('Show drop cables (last-mile — busy)')
        self.drops_chk.setChecked(False); self.drops_chk.setStyleSheet(_chk_css)
        self.drops_chk.toggled.connect(lambda *_: self._show_route())
        layout.addWidget(self.drops_chk)

        # on-canvas labels: FTS, each STS leg, domes, distribution + feeder cables
        self.labels_chk = QCheckBox('Show labels (splitters · legs · domes · cables)')
        self.labels_chk.setChecked(True); self.labels_chk.setStyleSheet(_chk_css)
        self.labels_chk.toggled.connect(lambda *_: self._show_route())
        layout.addWidget(self.labels_chk)

        # animated flow-direction arrows (POP → homes) on the trunk + drops
        self.arrows_chk = QCheckBox('Flow arrows on the selected drop (animated)')
        self.arrows_chk.setChecked(True); self.arrows_chk.setStyleSheet(_chk_css)
        self.arrows_chk.toggled.connect(lambda *_: self._show_route())
        layout.addWidget(self.arrows_chk)

        # follow the live Excel sheet + cell selection (via excel_watch.py)
        self.excel_chk = QCheckBox('Follow Excel selection (sheet + selected rows)')
        self.excel_chk.setChecked(True); self.excel_chk.setStyleSheet(_chk_css)
        layout.addWidget(self.excel_chk)

        # ── STS-leg list (collapsible): L1..L16 → DIS dome + homes, click to isolate ─
        from qgis.PyQt.QtWidgets import QToolButton
        legs_wrap = QFrame(); legs_wrap.setObjectName('vfLegsWrap')
        legs_wrap.setStyleSheet(
            f"QFrame#vfLegsWrap {{ background:#0a111d; border:1px solid {_BORDER};"
            f" border-radius:8px; }}")
        lw = QVBoxLayout(legs_wrap); lw.setContentsMargins(0, 0, 0, 0); lw.setSpacing(0)
        self._legs_toggle = QToolButton(); self._legs_toggle.setText('▾  STS legs')
        self._legs_toggle.setCheckable(True); self._legs_toggle.setChecked(True)
        self._legs_toggle.setStyleSheet(
            f"QToolButton {{ color:{_TEXT}; background:transparent; border:none;"
            f" padding:7px 10px; font-family:Consolas; font-size:10px; text-align:left; }}"
            f"QToolButton:hover {{ color:{_ACCENT}; }}")
        self._legs_toggle.clicked.connect(self._toggle_legs)
        lw.addWidget(self._legs_toggle)
        self._legs_box = QFrame()
        self._legs_layout = QVBoxLayout(self._legs_box)
        self._legs_layout.setContentsMargins(0, 0, 0, 4); self._legs_layout.setSpacing(0)
        lw.addWidget(self._legs_box)
        layout.addWidget(legs_wrap)

        line = QFrame(); line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet(_DIVIDER); layout.addWidget(line)

        # IDENTIFY — click any cable / splitter / dome on the map → which PON sheet
        id_lbl = QLabel('IDENTIFY  (click a feature on the map)')
        id_lbl.setStyleSheet(_SECTION_LBL); layout.addWidget(id_lbl)
        self._id_lbl = QLabel('Select a feature on the canvas…')
        self._id_lbl.setWordWrap(True)
        self._id_lbl.setStyleSheet(
            f"QLabel {{ background:#11131f; color:{_TEXT}; border:1px solid {_BORDER};"
            f" border-radius:4px; padding:6px 8px; font-family:Consolas; font-size:10px; }}")
        layout.addWidget(self._id_lbl)
        id_row = QHBoxLayout(); id_row.setSpacing(8)
        self._id_open_btn = QPushButton('↪  Open that PON')
        self._id_open_btn.setStyleSheet(_BTN_GRADIENT); self._id_open_btn.setEnabled(False)
        self._id_open_btn.clicked.connect(self._open_identified_pon)
        id_row.addWidget(self._id_open_btn)
        self.idjump_chk = QCheckBox('auto-jump')
        self.idjump_chk.setChecked(False); self.idjump_chk.setStyleSheet(_chk_css)
        id_row.addWidget(self.idjump_chk)
        layout.addLayout(id_row)
        self._id_target_port = None

        line2 = QFrame(); line2.setFrameShape(QFrame.Shape.HLine)
        line2.setStyleSheet(_DIVIDER); layout.addWidget(line2)

        ro_row = QHBoxLayout(); ro_row.setSpacing(8)
        ro_lbl = QLabel('ROUTE  (tick against the Excel sheet)')
        ro_lbl.setStyleSheet(_SECTION_LBL); ro_row.addWidget(ro_lbl, 1)
        btn_copy = QPushButton('📋 Copy')
        btn_copy.setStyleSheet(_BTN_CLEAR)
        btn_copy.setMaximumWidth(80)
        btn_copy.clicked.connect(self._copy_route)
        ro_row.addWidget(btn_copy)
        layout.addLayout(ro_row)
        self.readout = QListWidget()
        self.readout.setStyleSheet(
            f"QListWidget {{ background:#11131f; color:{_TEXT}; border:1px solid {_BORDER};"
            f" border-radius:4px; font-family:Consolas; font-size:10px; }}"
            f"QListWidget::item {{ padding:2px 6px; }}")
        self.readout.setMinimumHeight(150)
        self.readout.setMaximumHeight(260)
        layout.addWidget(self.readout)

        self._status_lbl = QLabel(''); self._status_lbl.setWordWrap(True)
        self._status_lbl.setStyleSheet(_STATUS_LBL); layout.addWidget(self._status_lbl)

        # legend
        legend = QLabel(
            '🟥 feeder  🟧 distribution  🟨 drops   '
            '🔷 AGG dome  🔵 DIS dome   🟪 FTS  🟩 STS  ⚪ ONT')
        legend.setWordWrap(True); legend.setStyleSheet(_HINT_LBL)
        layout.addWidget(legend)

        self._on_port_changed()          # populate STS combo for first port

        # populate the hop diagram for the opening port WITHOUT drawing on the
        # canvas (resolve is side-effect-free) so the panel reads useful at a glance
        try:
            r0 = self._resolve_route(None)
            if r0:
                self._route = r0
                self._refresh_panel(r0)
        except Exception:
            pass

        # live poll: re-show automatically when the Excel sheet/selection changes
        self._xl_last_key = None
        self._xl_timer = QTimer(self)
        self._xl_timer.setInterval(1200)
        self._xl_timer.timeout.connect(self._poll_excel)
        self._xl_timer.start()

        # flow-arrow animation: a bounded timer that marches the arrowheads while
        # the viewer is visible AND the arrows checkbox is on (stops otherwise).
        self._arrow_phase = 0.0
        self._arrow_geoms = None
        self._arrow_dome = None
        self._arrow_timer = QTimer(self)
        self._arrow_timer.setInterval(45)
        self._arrow_timer.timeout.connect(self._tick_arrows)

        # IDENTIFY: react when the user clicks/selects a feature on any route layer
        for lyr in self._layers.values():
            if lyr is not None:
                try:
                    lyr.selectionChanged.connect(self._on_user_select)
                except Exception:
                    pass

    # ── identify clicked feature -> PON sheet ────────────────────────────────
    def _on_user_select(self, selected=None, deselected=None, clearAndSelect=None):
        if getattr(self, '_programmatic_select', False):
            return                                  # ignore our own route selection
        lyr = self.sender()
        if lyr is None:
            return
        try:
            # identify the NEWLY-selected feature (the user's click) — not the whole
            # selection, so it still works when the route viewer leaves features
            # selected. selectionChanged passes the new-selection delta.
            ids = list(selected) if selected else []
            if not ids:
                if lyr.selectedFeatureCount() == 1:
                    ids = [next(lyr.getSelectedFeatures()).id()]
                else:
                    return
            if len(ids) > 12:                        # huge select -> not a click
                return
            feat = lyr.getFeature(ids[-1])           # the last one the user added
        except Exception:
            return
        info = self._feature_info(lyr, feat)
        self._show_identify(info)

    def _show_identify(self, info):
        lab, lname = info['label'], info['lname']
        cap = f'  ·  {info["extra"]}' if info['extra'] else ''
        if info['pon'] and info['sheet']:
            head = (f'<b>{lab}</b>{cap}<br>{lname}<br>'
                    f'➜ <b>PON {info["pon"]}</b> · Zone {info["zone"]} · sheet '
                    f'<b>{info["sheet"]}</b>')
            body = (f'<br><span style="color:#f59e0b">{info["note"]}</span>'
                    if not info['in_plan']
                    else f'<br><span style="color:#22c55e">in plan → {info["note"]}</span>')
            self._id_lbl.setText(head + body)
            self._id_target_port = info['sheet']
            self._id_open_btn.setEnabled(True)
            self._id_open_btn.setText(f'↪  Open {info["sheet"]} (PON {info["pon"]})')
            if getattr(self, 'idjump_chk', None) and self.idjump_chk.isChecked():
                self._open_identified_pon()
        else:
            self._id_lbl.setText(f'<b>{lab}</b>{cap}<br>{lname}<br>'
                                 f'<span style="color:#94a3b8">no PON tag on this feature</span>')
            self._id_target_port = None
            self._id_open_btn.setEnabled(False)
            self._id_open_btn.setText('↪  Open that PON')

    def _open_identified_pon(self):
        port = getattr(self, '_id_target_port', None)
        if not port:
            return
        i = self.port_combo.findData(port)
        if i < 0:
            return
        # opening a neighbour PON: stop following Excel so it doesn't snap back
        if getattr(self, 'excel_chk', None) and self.excel_chk.isChecked():
            self.excel_chk.setChecked(False)
        self.port_combo.setCurrentIndex(i)
        self._on_port_changed()
        self._show_route()

    def _poll_excel(self):
        if not self.isVisible():
            return
        xl = self._read_excel_sel()
        if not xl:
            return
        key = (xl.get('sheet'), xl.get('selection'),
               tuple(xl.get('sts', [])), tuple(xl.get('drs', [])))
        if key != self._xl_last_key:
            self._xl_last_key = key
            self._show_route()

    def _home_count(self, port):
        n = 0
        for s in self._idx['sts_by_port'].get(port, []):
            n += len(self._idx['drops_by_dis'].get(s['dis'], []))
        return n

    def _loss_budget(self, fts, sts_list, feeder_lbls, dist_cables):
        """Estimate worst-case optical loss POP→ONT vs GPON Class B+ (28 dB).
        Cascaded splitters dominate: 1:16 FTS ≈13.5 + 1:8 STS ≈10.5 = 24 dB;
        + 3 connectors (0.30) + 4 splices (0.10) + fibre 0.35 dB/km. Returns
        (loss_db, margin_db, status, fibre_km)."""
        def km(g):
            try:
                return g.length() * 111.32        # degrees → km (approx at this lat)
            except Exception:
                return 0.0
        feeder_km = sum(km(self._idx['feed_by_label'][fl]['geom'])
                        for fl in (feeder_lbls or [])
                        if fl in self._idx['feed_by_label'])
        dist_km = max([km(dc.get('geom')) for dc in (dist_cables or [])] or [0.0])
        drop_km = 0.0
        for s in sts_list:
            for dr in self._idx['drops_by_dis'].get(s['dis'], []):
                drop_km = max(drop_km, km(dr.get('geom')))
        fibre_km = feeder_km + dist_km + drop_km
        loss = 10.5 + 13.5 + 3 * 0.30 + 4 * 0.10 + fibre_km * 0.35
        margin = 28.0 - loss
        status = 'PASS' if margin >= 3 else ('MARGINAL' if margin >= 1 else 'FAIL')
        return round(loss, 1), round(margin, 1), status, round(fibre_km, 2)

    def _feeder_route_labels(self, pon):
        """Corrected feeder path for this PON — ordered cable labels from
        feeder_routes.json (the SAME geometry-rooted POP->AGG route the Excel
        splice plan uses). Empty when the route file is absent, so teammates
        without it fall back to the legacy upstream-endfeat trace."""
        return list(self._idx.get('feeder_routes', {}).get(str(pon), []))

    def _resolve_feeders(self, fts):
        """Mirror the generator's feeder_hops: find the feeder cable the FTS
        physically sits on (fts_cable_map keyed by the FTS pole, else the AGG-dome
        pole), then trace upstream via endfeat. Returns [cable_label, ...] in the
        same set the Excel feeder row lists. Empty list -> caller falls back to
        the pon_no-tagged feeder."""
        import re
        cmap = self._idx.get('fts_cable_map') or {}
        if not cmap:
            return []
        pole = fts.get('strtfeat')
        hit = cmap.get(pole)
        # fall back to the AGG dome's pole — use the GEOMETRY-resolved dome label
        # (the real co-located dome) so the feeder traces from the cluster, not the
        # drifted FTS-embedded name. MOA.AGG.DM.P.G586 -> MOA.P.G586.
        if not hit:
            agg_lbl = fts.get('agg_label') or fts.get('agg') or ''
            if agg_lbl:
                hit = cmap.get(re.sub(r'AGG\.DM\.', '', agg_lbl))
        if not hit:
            return []
        out = []
        seen = set()
        lbl = hit.get('cable')
        while lbl and lbl not in seen:
            seen.add(lbl); out.append(lbl)
            cab = self._idx['feed_by_label'].get(lbl)
            if not cab or not cab.get('strt'):
                break
            ups = self._idx['feed_by_endfeat'].get(cab['strt'], [])
            lbl = ups[0] if ups else None
        return out

    def _on_port_changed(self):
        port = self.port_combo.currentData()
        self.sts_combo.blockSignals(True)
        self.sts_combo.clear()
        self.sts_combo.addItem('All STS in PON', None)
        for s in sorted(self._idx['sts_by_port'].get(port, []),
                        key=lambda x: (x['leg'] or '')):
            n = len(self._idx['drops_by_dis'].get(s['dis'], []))
            self.sts_combo.addItem(f"{s['leg'] or '—'}  {s['dis']}  ({n})", s['label'])
        self.sts_combo.blockSignals(False)

    def _step(self, delta):
        i = self.port_combo.currentIndex() + delta
        if 0 <= i < self.port_combo.count():
            self.port_combo.setCurrentIndex(i)
            self._show_route()

    def _jump_to(self, port, sts_label=None):
        """Switch the viewer to *port* (and optionally narrow to one STS) and show
        it. Turns off Excel-follow so the jump sticks."""
        i = self.port_combo.findData(port)
        if i < 0:
            return False
        if getattr(self, 'excel_chk', None) and self.excel_chk.isChecked():
            self.excel_chk.setChecked(False)
        self.port_combo.setCurrentIndex(i)
        self._on_port_changed()
        if sts_label:
            for j in range(self.sts_combo.count()):
                if self.sts_combo.itemData(j) == sts_label:
                    self.sts_combo.setCurrentIndex(j); break
        else:
            self.sts_combo.setCurrentIndex(0)
        self._show_route()
        return True

    def _find(self):
        """Resolve the Find text (DR / dome / STS / cable / port) to a PON and jump
        there, narrowing to the matching STS when relevant."""
        import re
        q = self.find_edit.text().strip()
        if not q:
            return
        idx = self._idx
        # 1. DR number -> the STS/dome that serves it
        m = re.search(r'DR\s*0*(\d+)', q, re.I)
        if m:
            dr = 'DR' + m.group(1)
            for port, lst in idx['sts_by_port'].items():
                for s in lst:
                    for drp in idx['drops_by_dis'].get(s['dis'], []):
                        if dr in ((drp.get('label') or '') + ' ' + (drp.get('ont') or '')):
                            self._jump_to(port, sts_label=s['label'])
                            self._set_status(f'Found {dr} → {s["leg"]} · {s["dis"].split(".")[-1]}',
                                             colour=_GREEN)
                            return
        # 2. explicit OLT port
        mp = re.search(r'C\d\dP\d\d', q, re.I)
        if mp and mp.group(0).upper() in idx['fts_by_port']:
            self._jump_to(mp.group(0).upper()); return
        # 3. DIS dome
        md = re.search(r'(?:DIS\.DM\.P\.)?([A-Z]?\d{3,})', q, re.I)
        token = md.group(1).upper() if md else None
        if token:
            for port, lst in idx['sts_by_port'].items():
                for s in lst:
                    if s.get('dis') and s['dis'].endswith('.' + token):
                        self._jump_to(port, sts_label=s['label'])
                        self._set_status(f'Found dome {token} → {port}', colour=_GREEN)
                        return
            # 4. AGG dome
            for port, fts in idx['fts_by_port'].items():
                if fts.get('agg') and fts['agg'].endswith('.' + token):
                    self._jump_to(port); self._set_status(f'Found AGG {token} → {port}', colour=_GREEN)
                    return
        # 5. cable label substring (distribution / feeder)
        ql = q.lower()
        for fid, fe in (idx.get('dist_feats') or {}).items():
            if fe.get('label') and ql in fe['label'].lower():
                info = {'label': fe['label'], 'lname': 'Distribution Cable'}
                # find pon via the route resolution: jump to the cable's pon_no tag
                for pon, cs in idx['dist_by_pon'].items():
                    if any(c.get('fid') == fid for c in cs):
                        port = self._pon_to_port(pon)
                        if port and self._jump_to(port):
                            self._set_status(f'Found cable {fe["label"].split(".P.")[-1]} → {port}',
                                             colour=_GREEN)
                            return
        self._set_status(f'"{q}" not found', colour=_RED)

    def _read_excel_sel(self):
        """Read C:/Temp/excel_selection.json (written by excel_watch.py) — the live
        active splice sheet + selected STS/DR. Returns None if disabled, stale
        (watcher not running), or the active sheet isn't a known PON."""
        if not getattr(self, 'excel_chk', None) or not self.excel_chk.isChecked():
            return None
        import json, os, time
        p = r'C:/Temp/excel_selection.json'
        try:
            if not os.path.exists(p) or (time.time() - os.path.getmtime(p)) > 8:
                return None
            with open(p) as _f:
                d = json.load(_f)
        except Exception:
            return None
        if not d.get('valid') or d.get('sheet') not in self._idx['fts_by_port']:
            return None
        return d

    # ── route resolution + draw ─────────────────────────────────────────────
    def _show_route(self):
        # follow the live Excel sheet + selection if enabled
        xl = self._read_excel_sel()
        if xl:
            i = self.port_combo.findData(xl['sheet'])
            if i >= 0 and i != self.port_combo.currentIndex():
                self.port_combo.blockSignals(True)
                self.port_combo.setCurrentIndex(i)
                self.port_combo.blockSignals(False)
                self._on_port_changed()
        route = self._resolve_route(xl)
        if route is None:
            return
        self._route = route                  # remember for isolate / walk / card
        self._isolated_hop = None
        self._draw_route(route)
        self._fill_route_readout(route)
        self._refresh_panel(route)

    def _resolve_route(self, xl):
        """Resolve the whole PON route into a structured dict WITHOUT touching the
        canvas, so the rubber-band draw AND the on-panel hop diagram are driven by
        the SAME pass. Returns None when no port is selected."""
        port = self.port_combo.currentData()
        if not port:
            return None
        pon  = str(self._port_to_pon(port))
        only_sts = self.sts_combo.currentData()       # None = whole PON

        # Excel-driven filter: restrict to the STS / DR rows selected on the sheet
        xl_sts = set(xl['sts']) if (xl and not xl.get('whole') and xl.get('sts')) else None
        xl_drs = set(xl['drs']) if (xl and not xl.get('whole') and xl.get('drs')) else None

        sel = {}                                       # layer -> set(fid)
        geoms = {hop: [] for hop in _HOP_COLOURS}
        labels = OrderedDict((hop, []) for hop in _HOP_COLOURS)

        def add(hop, lyr_key, entry):
            if not entry:
                return
            if entry.get('geom') is not None and not entry['geom'].isEmpty():
                geoms[hop].append(entry['geom'])
            if entry.get('label'):
                labels[hop].append(entry['label'])
            lyr = self._layers.get(lyr_key)
            if lyr is not None and entry.get('fid') is not None:
                sel.setdefault(lyr.id(), (lyr, set()))[1].add(entry['fid'])

        # FTS + AGG dome (the head of the PON). Show the CANONICAL AGG label from
        # the FTS (matches the Excel sheet) for the read-out; light the dome at the
        # nearest physical Enclosures-Splice feature (the FTS label only matches the
        # layer's label_1 for 9/66 — known quirk), noting the feature label.
        fts = self._idx['fts_by_port'].get(port)
        add('fts', 'fts', fts)
        agg_disp = None
        if fts and fts.get('agg_geom') is not None:
            canon = fts.get('agg')                         # name embedded in the FTS label (drifted)
            feat_lab = fts.get('agg_label')                # the real co-located dome's label_1
            if fts.get('agg_matched') == 'nearest' and feat_lab and feat_lab != canon:
                # show the REAL co-located dome (matches the splice plan); note the
                # drifted FTS-embedded name in parens so the cross-check is still clear.
                lab = f'{feat_lab}   (FTS label: {canon.split(".")[-1]})'
            else:
                lab = canon
            agg_disp = lab
            add('agg', 'agg', {'fid': fts.get('agg_fid'),
                               'geom': fts['agg_geom'], 'label': lab})
        elif fts and fts.get('agg'):
            agg_disp = fts['agg'] + '  (no dome feature)'
            labels['agg'].append(agg_disp)

        # feeder: prefer the geometry-corrected POP->AGG route (feeder_routes.json,
        # identical to the Excel feeder row); fall back to the legacy upstream trace,
        # then to the pon_no-tagged feeder. Keeps viewer + Excel feeders in lock-step.
        feeder_lbls = self._feeder_route_labels(pon) or (self._resolve_feeders(fts) if fts else [])
        if feeder_lbls:
            for fl in feeder_lbls:
                cab = self._idx['feed_by_label'].get(fl)
                if cab:
                    add('feeder', 'sec' if cab['kind'] == 'Secondary' else 'pri',
                        {'fid': cab['fid'], 'geom': cab['geom'], 'label': fl})
        else:
            for fc in self._idx['feed_by_pon'].get(pon, []):
                add('feeder', 'sec' if fc['kind'] == 'Secondary' else 'pri', fc)

        # STS → DIS dome → drops → ONTs, restricted by the active filter:
        #   Excel-selected STS  >  the scope combo's single STS  >  all STS
        import re as _re
        sts_all = self._idx['sts_by_port'].get(port, [])
        sts_list = sts_all
        if xl_sts is not None:
            sts_list = [s for s in sts_all if s['label'] in xl_sts]
        elif only_sts:
            sts_list = [s for s in sts_all if s['label'] == only_sts]
        legs = []
        for s in sts_list:
            add('sts', 'sts', s)
            legs.append({'leg': s.get('leg'), 'dis': s.get('dis'),
                         'sts_label': s.get('label'),
                         'homes': (len(self._idx['drops_by_dis'].get(s['dis'], []))
                                   if s.get('dis') else 0)})
            if s.get('dis'):
                # draw the DIS dome at the co-located feature (nearest to the STS),
                # not the stray label-point; keep the plan label
                if s.get('dis_geom') is not None:
                    add('dis', 'dis', {'fid': s.get('dis_fid'),
                                       'geom': s['dis_geom'], 'label': s['dis']})
                else:
                    dis = self._idx['dis_by_label'].get(s['dis'])
                    if dis:
                        add('dis', 'dis', {**dis, 'label': s['dis']})
                for dr in self._idx['drops_by_dis'].get(s['dis'], []):
                    if xl_drs is not None:                 # only the selected DR rows
                        m = _re.search(r'DR\d+', dr.get('ont') or dr.get('label') or '')
                        if not m or m.group(0) not in xl_drs:
                            continue
                    add('drop', 'drop', dr)
                    if dr.get('ont'):
                        # Anchor the ONT/home marker to the DROP's home end, not the
                        # ONT-feature lookup: the DR number drifts between the Drop and
                        # ONT layers, so ~21/99 ONT features resolve hundreds–thousands
                        # of m away (the white stragglers JJ flagged). The drop's far
                        # endpoint IS the home. Use the ONT feature only when it's truly
                        # co-located (<80 m) — then it also selects for the attr table;
                        # otherwise draw at the drop end and DON'T select the stray feature.
                        ref = s.get('dis_geom') or s.get('geom')
                        home = self._line_far_end(dr.get('geom'), ref)
                        ont = self._idx['ont_by_label'].get(dr['ont'])
                        og = ont.get('geom') if ont else None
                        near = (home is not None and og is not None and not og.isEmpty()
                                and og.distance(home) * 111320 < 80)
                        if near:
                            add('ont', 'ont', {**ont, 'label': dr['ont']})
                        elif home is not None:
                            add('ont', 'ont', {'geom': home, 'label': dr['ont']})
                        elif ont:
                            add('ont', 'ont', {**ont, 'label': dr['ont']})

        # distribution: every cable the route's domes physically sit on (shared
        # trunks tagged to other PONs included), so the WHOLE route shows — not
        # just the 2-3 cables that happen to carry this PON's tag. CLIP each cable
        # to the cluster vicinity so a long shared trunk doesn't shoot a tail
        # across the map (deviation).
        from qgis.core import QgsRectangle, QgsGeometry
        agg_g = fts.get('agg_geom') if fts else None
        dist_cables = self._resolve_distribution(geoms['dis'], agg_g, pon)
        crect = None
        for hop in ('dis', 'sts', 'ont', 'drop'):
            for g in geoms[hop]:
                bb = g.boundingBox()
                if not bb.isEmpty():
                    crect = QgsRectangle(bb) if crect is None else (crect.combineExtentWith(bb) or crect)
        clip = None
        if crect is not None and not crect.isEmpty():
            buf = 0.0014                      # ~150 m around the cluster
            clip = QgsGeometry.fromRect(QgsRectangle(
                crect.xMinimum()-buf, crect.yMinimum()-buf,
                crect.xMaximum()+buf, crect.yMaximum()+buf))
        clipped = []
        for dc in dist_cables:
            g = dc.get('geom')
            if g is None:
                continue
            if clip is not None:
                gi = g.intersection(clip)
                if gi is None or gi.isEmpty():
                    continue
                dc = {**dc, 'geom': gi}
            clipped.append(dc)
            add('dist', 'dist', dc)
        dist_cables = clipped

        # the 100 last-mile drop lines fan out from each STS into a starburst —
        # only draw them when the user asks (checkbox); the read-out always counts
        # them. Default view = clean trunk: feeder -> FTS -> distribution -> STS.
        show_drops = bool(getattr(self, 'drops_chk', None) and self.drops_chk.isChecked())
        draw_geoms = dict(geoms)
        if not show_drops:
            draw_geoms['drop'] = []

        # flow radiates from the AGG dome (PON source) — keep its point for arrows
        dome_pt = None
        if fts and fts.get('agg_geom') is not None and not fts['agg_geom'].isEmpty():
            dome_pt = fts['agg_geom'].centroid().asPoint()
        # halo only when narrowed to a specific STS / DR (Excel or scope combo)
        filtered = (xl_sts is not None) or (xl_drs is not None) or bool(only_sts)

        # counts + worst-case optical loss budget (POP->ONT vs GPON Class B+ 28 dB)
        nhomes = len(labels['drop']); nsts = len(labels['sts'])
        cap = nsts * 8                                 # each 1:8 STS = 8 ports
        spare = cap - nhomes
        fill = round(nhomes / cap * 100) if cap else 0
        loss = self._loss_budget(fts, sts_list, feeder_lbls, dist_cables)

        return {
            'port': port, 'pon': pon, 'zone': self._pon_to_zone(pon),
            'only_sts': only_sts, 'xl': xl, 'xl_sts': xl_sts, 'xl_drs': xl_drs,
            'filtered': filtered, 'fts': fts, 'agg_disp': agg_disp,
            'feeder_lbls': feeder_lbls, 'sts_all': sts_all, 'sts_list': sts_list,
            'legs': legs, 'dist_cables': dist_cables,
            'geoms': geoms, 'draw_geoms': draw_geoms, 'labels': labels, 'sel': sel,
            'show_drops': show_drops, 'dome_pt': dome_pt,
            'counts': {'nhomes': nhomes, 'nsts': nsts, 'cap': cap,
                       'spare': spare, 'fill': fill},
            'loss': loss,
            'pop_geom': (self._idx['pop']['geom'] if self._idx.get('pop') else None),
            'pop_label': (self._idx['pop']['label'] if self._idx.get('pop') else None),
            'flags': self._route_flags(port, fts, sts_all, legs, feeder_lbls),
        }

    def _draw_route(self, route):
        """Render the resolved route on the canvas — rubber bands, halo, flow
        arrows, text labels, layer selection, solo + zoom. Pure side effects, so
        the diagram-hop isolate / walk can re-draw any subset without re-resolving."""
        self._clear(keep_status=True)
        # rubber bands (drops only when the user asked — read-out still counts them)
        for hop, glist in route['draw_geoms'].items():
            band = self._bands[hop]
            gt = (QgsWkbTypes.GeometryType.LineGeometry if hop in ('feeder', 'dist', 'drop')
                  else QgsWkbTypes.GeometryType.PointGeometry)
            band.reset(gt)
            for g in glist:
                band.addGeometry(g, None)
        # bright halo around the SELECTED splitters + homes (Excel / scope combo)
        halo = self._bands['halo']
        halo.reset(QgsWkbTypes.GeometryType.PointGeometry)
        if route['filtered']:
            for g in route['geoms']['sts'] + route['geoms']['ont']:
                halo.addGeometry(g, None)
        # flow arrows trace ONLY the selected drop/STS path (feeder → its dist leg →
        # the drop). No selection = no arrows, so the whole PON isn't flooded.
        self._arrow_dome = route['dome_pt']
        if (getattr(self, 'arrows_chk', None) and self.arrows_chk.isChecked()
                and route.get('filtered')):
            self._arrow_geoms = self._selected_path_geoms(route)
            self._draw_arrows(self._arrow_geoms, self._arrow_dome,
                              getattr(self, '_arrow_phase', 0.0))
            self._start_arrow_anim()
        else:
            self._arrow_geoms = None
            self._stop_arrow_anim()
            for _bk in ('arrow', 'arrow_glow'):
                _ab = self._bands.get(_bk)
                if _ab is not None:
                    _ab.reset(QgsWkbTypes.GeometryType.PolygonGeometry)
        # on-canvas text labels: FTS, each STS leg, AGG/DIS domes, dist + feeder
        self._draw_labels(route['port'], route['fts'], route['sts_list'], route['pon'],
                          route['feeder_lbls'], route['show_drops'], route['filtered'],
                          route['dist_cables'])
        # select features in their layers (feeds the attribute table). Flag it so
        # the IDENTIFY handler ignores our own selection (only user clicks count).
        self._programmatic_select = True
        try:
            for lyr, fids in route['sel'].values():
                try:
                    lyr.selectByIds(list(fids))
                except Exception:
                    pass
        finally:
            self._programmatic_select = False
        # solo: dim every other layer so only this route stands out
        if getattr(self, 'solo_chk', None) and self.solo_chk.isChecked():
            self._apply_solo()
        else:
            self._restore_solo()
        self._zoom_to(route['geoms'])
        self.canvas.refresh()

    def _fill_route_readout(self, route):
        """Tick-list read-out (per-label, against the Excel sheet) + loss line +
        status bar — all from the resolved route dict."""
        self._fill_readout(route['port'], route['pon'], route['only_sts'], route['labels'])
        c = route['counts']; xl = route['xl']
        if route['xl_sts'] is not None or route['xl_drs'] is not None:
            tag = f'  ◀ Excel selection ({xl.get("selection","")})'
        elif xl:
            tag = '  ◀ following Excel sheet'
        else:
            tag = ''
        self._set_status(
            f'PON {route["pon"]} · {route["port"]} — {c["nsts"]} STS · {c["nhomes"]} homes · '
            f'{c["spare"]} spare · {c["cap"]} ports · {c["fill"]}% fill{tag}',
            colour=_GREEN)

    # ── visual hop-chain diagram ─────────────────────────────────────────────
    @staticmethod
    def _short_cable(l):
        """MOA.SF.48F.P.H161-P.H130 -> H161-H130 (compact for a diagram sub-label)."""
        import re
        if not l:
            return '—'
        return re.sub(r'^MOA\.\w+\.\d+F\.P\.', '', l).replace('-P.', '-')

    @staticmethod
    def _legnum(lg):
        """Natural leg order: L1, L2 … L10 (not the string sort L1, L10, L2)."""
        s = ''.join(ch for ch in (lg.get('leg') or '') if ch.isdigit())
        return int(s) if s else 0

    def _diagram_items(self, route):
        """Build the ordered POP -> ONT hop list the diagram renders. Each item:
        {hop, name, count, sub, color}. 'pop' is synthetic (no rubber band)."""
        c = route['counts']; lbl = route['labels']
        port = route['port']; pon = route['pon']
        fts = route['fts']
        card = port[:3]; pp = port[3:]
        feeder_lbl = (route['feeder_lbls'][0] if route['feeder_lbls']
                      else (lbl['feeder'][0] if lbl['feeder'] else None))
        agg_n = len(lbl['agg']) or (1 if (fts and fts.get('agg')) else 0)
        return [
            {'hop': 'pop', 'name': f'POP · OLT {port}', 'count': 'port',
             'sub': f'card {card} · port {pp} → PON {pon}', 'color': QColor(_ACCENT)},
            {'hop': 'feeder', 'name': 'Feeder', 'count': len(lbl['feeder']),
             'sub': self._short_cable(feeder_lbl), 'color': _HOP_COLOURS['feeder']},
            {'hop': 'agg', 'name': 'AGG dome', 'count': agg_n,
             'sub': route.get('agg_disp') or '—', 'color': _HOP_COLOURS['agg']},
            {'hop': 'fts', 'name': 'FTS splitter', 'count': '1:16',
             'sub': (fts.get('label') if fts else None) or '—',
             'color': _HOP_COLOURS['fts']},
            {'hop': 'dist', 'name': 'Distribution', 'count': len(route['dist_cables']),
             'sub': '24F Mini-ADSS legs → DIS domes', 'color': _HOP_COLOURS['dist']},
            {'hop': 'dis', 'name': 'DIS domes', 'count': len(lbl['dis']),
             'sub': 'one per STS · tap points', 'color': _HOP_COLOURS['dis']},
            {'hop': 'sts', 'name': 'STS splitters', 'count': c['nsts'],
             'sub': f"{c['nsts']} legs · 1:8 each", 'color': _HOP_COLOURS['sts']},
            {'hop': 'drop', 'name': 'Drops', 'count': c['nhomes'],
             'sub': '1F drop per home (≤55 m)', 'color': _HOP_COLOURS['drop']},
            {'hop': 'ont', 'name': 'ONT · homes', 'count': len(lbl['ont']) or c['nhomes'],
             'sub': f"{c['nhomes']} live homes · {c['spare']} ports spare",
             'color': _HOP_COLOURS['ont']},
        ]

    def _render_diagram(self, route):
        """(Re)build the vertical hop-chain cards from the resolved route. Cheap —
        ~9 cards — so just rebuild on every show."""
        lay = getattr(self, '_diagram_layout', None)
        if lay is None:
            return
        while lay.count():
            it = lay.takeAt(0)
            w = it.widget()
            if w is not None:
                w.setParent(None)
        self._hop_cards = {}
        items = self._diagram_items(route)
        for i, item in enumerate(items):
            lay.addWidget(self._build_diagram_card(item, is_last=(i == len(items) - 1)))
        lay.addStretch(1)
        self._highlight_diagram_hop(getattr(self, '_isolated_hop', None))

    # ── health card + plain-English explainer ────────────────────────────────
    def _hcell(self, k, v, vcolor, u, badge=None, gauge_pct=None, gauge_col=None):
        """One health-card cell: KEY · big value · unit, with an optional fill gauge
        or a status badge."""
        cell = QFrame()
        cell.setStyleSheet(f"QFrame {{ background:#0b1220; border:1px solid {_BORDER};"
                           f" border-radius:8px; }}")
        cl = QVBoxLayout(cell); cl.setContentsMargins(7, 7, 7, 7); cl.setSpacing(2)
        for text, css in (
            (k, "color:#6680a6; font-size:8px; letter-spacing:1px;"),
            (str(v), f"color:{vcolor}; font-size:17px; font-weight:700;"),
            (u, "color:#8fa6c6; font-size:8px;")):
            w = QLabel(text); w.setAlignment(Qt.AlignmentFlag.AlignHCenter)
            w.setStyleSheet(f"{css} font-family:Consolas; background:transparent; border:none;")
            cl.addWidget(w)
        if gauge_pct is not None:
            from qgis.PyQt.QtWidgets import QProgressBar
            g = QProgressBar(); g.setRange(0, 100)
            g.setValue(max(0, min(100, int(gauge_pct))))
            g.setTextVisible(False); g.setFixedHeight(5)
            g.setStyleSheet(
                f"QProgressBar {{ background:#16263a; border:none; border-radius:3px; }}"
                f"QProgressBar::chunk {{ background:{gauge_col or _ACCENT}; border-radius:3px; }}")
            cl.addWidget(g)
        if badge is not None:
            btxt, bcol = badge
            bl = QLabel(btxt); bl.setAlignment(Qt.AlignmentFlag.AlignHCenter)
            bl.setStyleSheet(f"color:{bcol}; font-family:Consolas; font-size:8px;"
                             f" font-weight:700; letter-spacing:1px;"
                             f" background:transparent; border:none;")
            cl.addWidget(bl)
        return cell

    def _render_health(self, route):
        """Homes / fill% / loss-margin cells — green/amber/red read at a glance."""
        lay = getattr(self, '_health_layout', None)
        if lay is None:
            return
        while lay.count():
            it = lay.takeAt(0); w = it.widget()
            if w is not None:
                w.setParent(None)
        c = route['counts']
        fill = c['fill']
        fcol = (_RED if fill > 100 else ('#f59e0b' if fill > 90 else _GREEN))
        lay.addWidget(self._hcell('HOMES', c['nhomes'], _ACCENT,
                                  f"of {c['cap']} ports", gauge_pct=fill, gauge_col=_ACCENT))
        lay.addWidget(self._hcell('FILL', f"{fill}%", fcol,
                                  f"{c['spare']} spare", gauge_pct=fill, gauge_col=fcol))

    def _render_explainer(self, route):
        """Write 'how this PON runs' in plain English from the resolved route."""
        lbl = getattr(self, '_why_lbl', None)
        if lbl is None:
            return
        import re
        c = route['counts']; fts = route['fts']
        port = route['port']; pon = route['pon']
        feeder_lbl = (route['feeder_lbls'][0] if route['feeder_lbls']
                      else (route['labels']['feeder'][0] if route['labels']['feeder'] else None))
        m = re.search(r'(\d+F)', feeder_lbl or '')
        fspec = m.group(1) if m else 'feeder'
        ftail = self._short_cable(feeder_lbl) if feeder_lbl else '—'
        agg = route.get('agg_disp') or ''
        am = re.search(r'\.P\.([A-Za-z]?\d+)', agg)
        agg_tail = am.group(1) if am else (agg.split('.')[-1] if agg else '—')
        ndist = len(route['dist_cables']); nsts = c['nsts']
        if fts:
            txt = (
                f"OLT port <b>{port}</b> (PON {pon}) feeds a <b>{fspec}</b> feeder "
                f"(<b>{ftail}</b>) to the AGG dome at <b>{agg_tail}</b>, where a "
                f"<b>1:16 splitter</b> fans out to <b>{ndist}</b> distribution "
                f"leg{'s' if ndist != 1 else ''}. Each ends at a DIS dome with a "
                f"<b>1:8 splitter</b>. Together the <b>{nsts} STS</b> serve "
                f"<b>{c['nhomes']} homes</b> ({c['spare']} ports spare).")
        else:
            txt = (f"No FTS splitter resolves for <b>{port}</b> — open the splice "
                   f"project (with the FTS / STS / dome layers).")
        lbl.setText(txt)

    def _refresh_panel(self, route):
        """Rebuild every on-panel readout from one resolved route (diagram, health,
        explainer, leg list, flags). The canvas draw is separate (_draw_route)."""
        self._render_diagram(route)
        self._render_health(route)
        self._render_explainer(route)
        self._render_legs(route)
        self._render_flags(route)

    def _toggle_legs(self):
        on = self._legs_toggle.isChecked()
        self._legs_box.setVisible(on)
        cur = self._legs_toggle.text()
        self._legs_toggle.setText(('▾' if on else '▸') + cur[1:])

    def _render_legs(self, route):
        """List every STS leg (L1..Ln → DIS dome + home count). Click a leg to
        narrow the canvas to just that STS (reuses the scope-combo path)."""
        lay = getattr(self, '_legs_layout', None)
        if lay is None:
            return
        while lay.count():
            it = lay.takeAt(0); w = it.widget()
            if w is not None:
                w.setParent(None)
        import re
        legs = route.get('legs') or []
        on = self._legs_toggle.isChecked()
        self._legs_toggle.setText(
            ('▾' if on else '▸')
            + f"  {len(legs)} STS legs   ·  click a leg to isolate it")
        for lg in sorted(legs, key=self._legnum):
            tail = re.sub(r'.*\.P\.', '', lg.get('dis') or '') or '—'
            row = _ClickFrame(lambda s=lg.get('sts_label'): self._isolate_leg(s))
            row.setObjectName('legrow')
            row.setStyleSheet(
                "QFrame#legrow { background:transparent; border:none;"
                " border-top:1px solid #101c2c; }"
                "QFrame#legrow:hover { background:#0e1830; }")
            rl = QHBoxLayout(row); rl.setContentsMargins(10, 5, 10, 5); rl.setSpacing(8)
            lgl = QLabel(lg.get('leg') or '—'); lgl.setFixedWidth(34)
            lgl.setStyleSheet(f"color:{_GREEN}; font-family:Consolas; font-weight:700;"
                              f" font-size:10px; background:transparent; border:none;")
            dml = QLabel(tail)
            dml.setStyleSheet("color:#90a6c6; font-family:Consolas; font-size:10px;"
                              " background:transparent; border:none;")
            hml = QLabel(f"{lg.get('homes', 0)} homes")
            hml.setStyleSheet(f"color:{_ACCENT}; font-family:Consolas; font-size:10px;"
                              f" background:transparent; border:none;")
            rl.addWidget(lgl); rl.addWidget(dml, 1); rl.addWidget(hml)
            lay.addWidget(row)

    def _isolate_leg(self, sts_label):
        """Narrow the route to one STS leg via the scope combo, then redraw."""
        if not sts_label:
            return
        if getattr(self, 'excel_chk', None) and self.excel_chk.isChecked():
            self.excel_chk.setChecked(False)     # so the narrow sticks
        for j in range(self.sts_combo.count()):
            if self.sts_combo.itemData(j) == sts_label:
                self.sts_combo.setCurrentIndex(j)
                break
        self._show_route()

    def _render_flags(self, route):
        """Show route sanity flags (red/amber); hide the banner when clean."""
        lbl = getattr(self, '_flags_lbl', None)
        if lbl is None:
            return
        flags = route.get('flags') or []
        if not flags:
            lbl.setVisible(False); lbl.setText('')
            return
        rows = []
        for sev, text in flags[:8]:
            colr = '#FF5C6C' if sev == 'red' else '#F5A623'
            rows.append(f"<span style='color:{colr}'>⚠ {text}</span>")
        if len(flags) > 8:
            rows.append(f"… +{len(flags) - 8} more")
        lbl.setText('<br>'.join(rows))
        lbl.setVisible(True)

    # ── walk-the-route · zoom · route card ───────────────────────────────────
    def _zoom_route(self):
        route = getattr(self, '_route', None)
        if route:
            self._zoom_to(route['geoms']); self.canvas.refresh()

    def _draw_single_hop(self, hop):
        """Light ONLY one hop's band (used by isolate + walk). No selection/solo."""
        route = getattr(self, '_route', None)
        if not route:
            return
        for h, band in self._bands.items():
            gt = (QgsWkbTypes.GeometryType.LineGeometry
                  if h in ('feeder', 'dist', 'drop', 'arrow')
                  else QgsWkbTypes.GeometryType.PointGeometry)
            band.reset(gt)
        band = self._bands.get(hop)
        if band is not None:
            for g in route['geoms'].get(hop, []):
                band.addGeometry(g, None)
        self.canvas.refresh()

    def _walk_route(self):
        """Guided tour: step POP→home lighting each hop in turn. Click again to stop."""
        if getattr(self, '_walk_timer', None) is not None:
            self._stop_walk(); return
        route = getattr(self, '_route', None)
        if not route or not any(route['geoms'].get(h) for h in _HOP_COLOURS):
            self._show_route(); route = getattr(self, '_route', None)
        if not route:
            return
        order = ['feeder', 'agg', 'fts', 'dist', 'dis', 'sts', 'drop', 'ont']
        self._walk_hops = [h for h in order if route['geoms'].get(h)]
        if not self._walk_hops:
            return
        self._walk_idx = 0
        self._walk_timer = QTimer(self)
        self._walk_timer.setInterval(850)
        self._walk_timer.timeout.connect(self._walk_step)
        self._walk_step()                 # light the first hop immediately
        self._walk_timer.start()

    def _walk_step(self):
        hops = getattr(self, '_walk_hops', [])
        i = getattr(self, '_walk_idx', 0)
        if i >= len(hops):
            self._stop_walk(); return
        hop = hops[i]; self._walk_idx = i + 1
        self._draw_single_hop(hop)
        self._highlight_diagram_hop(hop)
        self._set_status(
            f'Walking… {i + 1}/{len(hops)}: {_HOP_TITLES.get(hop, hop.upper())}',
            colour=_HOP_COLOURS[hop].name() if hop in _HOP_COLOURS else _ACCENT)

    def _stop_walk(self):
        t = getattr(self, '_walk_timer', None)
        if t is not None:
            try:
                t.stop(); t.deleteLater()
            except Exception:
                pass
        self._walk_timer = None
        route = getattr(self, '_route', None)
        if route:
            self._isolated_hop = None
            self._draw_route(route)
            self._highlight_diagram_hop(None)
            self._set_status(f'Walk done — whole PON {route["pon"]}', colour=_GREEN)

    def _route_card(self):
        """Export a one-PON A4 route card (HTML) and open it for printing."""
        route = getattr(self, '_route', None)
        if not route:
            self._show_route(); route = getattr(self, '_route', None)
        if not route:
            return
        try:
            import os, tempfile
            html = self._route_card_html(route)
            outdir = r'C:/Users/jjsch/OneDrive/ON LAPTOP FIBRE/QGIS test'
            if not os.path.isdir(outdir):
                outdir = tempfile.gettempdir()
            path = os.path.join(outdir, f"Route_Card_{route['port']}_PON{route['pon']}.html")
            with open(path, 'w', encoding='utf-8') as f:
                f.write(html)
            from qgis.PyQt.QtGui import QDesktopServices
            from qgis.PyQt.QtCore import QUrl
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))
            self._set_status(
                f'Route card → {os.path.basename(path)} (print A4 from the browser)',
                colour=_ACCENT)
        except Exception as e:
            self._set_status(f'Route card failed: {e}', colour=_RED)

    def _route_card_html(self, route):
        import re, html as _h
        c = route['counts']
        items = self._diagram_items(route)
        why = self._why_lbl.text() if getattr(self, '_why_lbl', None) else ''
        legs = sorted(route.get('legs') or [], key=self._legnum)
        hop_rows = ''
        for it in items:
            hop_rows += (
                f"<tr><td class='dot'><span style='background:{it['color'].name()}'></span></td>"
                f"<td class='nm'>{_h.escape(str(it['name']))}</td>"
                f"<td class='ct'>{_h.escape(str(it['count']))}</td>"
                f"<td class='sb'>{_h.escape(str(it.get('sub') or ''))}</td></tr>")
        leg_rows = ''
        for lg in legs:
            tail = re.sub(r'.*\.P\.', '', lg.get('dis') or '') or '—'
            leg_rows += (f"<tr><td>{_h.escape(lg.get('leg') or '—')}</td>"
                         f"<td>{_h.escape(tail)}</td><td>{lg.get('homes', 0)} homes</td></tr>")
        flags = route.get('flags') or []
        flag_html = ''
        if flags:
            fl = ''.join(f"<li>{_h.escape(t)}</li>" for _s, t in flags)
            flag_html = f"<h2>⚠ Flags</h2><ul class='flags'>{fl}</ul>"
        return (
            "<!DOCTYPE html><html><head><meta charset='utf-8'><style>"
            "@page{size:A4;margin:16mm} body{font-family:'Segoe UI',Arial,sans-serif;color:#13202e}"
            "h1{font-size:20px;margin:0 0 2px} h2{font-size:13px;margin:14px 0 4px}"
            ".sub{color:#5a6b80;font-size:12px;margin-bottom:14px}"
            ".cards{display:flex;gap:10px;margin:10px 0 6px}"
            ".card{flex:1;border:1px solid #cfd8e3;border-radius:8px;padding:8px 10px}"
            ".card .k{font-size:9px;letter-spacing:1px;color:#6b7c90}"
            ".card .v{font-size:20px;font-weight:700}"
            "table{width:100%;border-collapse:collapse;font-size:11px}"
            "td,th{text-align:left;padding:4px 6px;border-bottom:1px solid #e6ecf3}"
            "td.dot{width:14px} td.dot span{display:inline-block;width:11px;height:11px;border-radius:50%}"
            ".nm{font-weight:700} .ct{color:#5a6b80} .sb{color:#5a6b80;font-family:Consolas}"
            ".why{background:#f3f8f4;border:1px solid #cfe3d4;border-radius:8px;padding:10px 12px;"
            "font-size:12px;line-height:1.5;margin-top:8px} .flags{color:#b9770a;font-size:11px}"
            "</style></head><body>"
            f"<h1>Splice Route Card — {_h.escape(route['port'])}</h1>"
            f"<div class='sub'>PON {route['pon']} · Zone {route['zone']} · "
            f"{c['nhomes']} homes · {c['nsts']} STS · {c['spare']} ports spare · Velocity Fibre</div>"
            "<div class='cards'>"
            f"<div class='card'><div class='k'>HOMES</div><div class='v'>{c['nhomes']}</div>"
            f"<div>of {c['cap']} ports</div></div>"
            f"<div class='card'><div class='k'>FILL</div><div class='v'>{c['fill']}%</div>"
            f"<div>{c['spare']} spare</div></div></div>"
            "<h2>Route — POP → home</h2>"
            f"<table>{hop_rows}</table>"
            f"<div class='why'>{why}</div>"
            f"<h2>STS legs ({len(legs)})</h2>"
            f"<table><tr><th>Leg</th><th>DIS dome</th><th>Homes</th></tr>{leg_rows}</table>"
            f"{flag_html}</body></html>")

    def _build_diagram_card(self, item, is_last=False):
        from qgis.PyQt.QtWidgets import QSizePolicy
        hop = item['hop']; hexc = item['color'].name()
        row = QWidget()
        h = QHBoxLayout(row); h.setContentsMargins(0, 0, 0, 0); h.setSpacing(8)
        # rail: colour dot + connecting line down to the next hop
        rail = QWidget(); rail.setFixedWidth(18)
        rv = QVBoxLayout(rail); rv.setContentsMargins(0, 4, 0, 0); rv.setSpacing(0)
        dot = QLabel(); dot.setFixedSize(13, 13)
        dot.setStyleSheet(f"background:{hexc}; border-radius:6px; border:none;")
        rv.addWidget(dot, 0, Qt.AlignmentFlag.AlignHCenter)
        if not is_last:
            line = QFrame(); line.setFixedWidth(2)
            line.setStyleSheet("background:#26405e; border:none;")
            line.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
            rv.addWidget(line, 1, Qt.AlignmentFlag.AlignHCenter)
        h.addWidget(rail)
        # card body
        card = _ClickFrame(lambda hp=hop: self._isolate_hop(hp))
        card.setObjectName('hopcard')
        card.setStyleSheet(
            f"QFrame#hopcard {{ background:#0b1322; border:1px solid {_BORDER};"
            f" border-radius:6px; }}"
            f"QFrame#hopcard:hover {{ border-color:{hexc}; background:#0e1830; }}")
        cv = QVBoxLayout(card); cv.setContentsMargins(9, 6, 9, 6); cv.setSpacing(2)
        top = QHBoxLayout(); top.setSpacing(6)
        nm = QLabel(item['name'])
        nm.setStyleSheet(f"color:{hexc}; font-family:'Segoe UI'; font-weight:700;"
                         f" font-size:11px; background:transparent; border:none;")
        top.addWidget(nm); top.addStretch(1)
        badge = QLabel(str(item['count']))
        badge.setStyleSheet(f"background:{hexc}; color:#04070d; border-radius:8px;"
                            f" padding:1px 8px; font-family:Consolas; font-weight:700;"
                            f" font-size:9px;")
        top.addWidget(badge)
        cv.addLayout(top)
        sub = item.get('sub')
        if sub:
            sl = QLabel(sub); sl.setWordWrap(True)
            sl.setStyleSheet("color:#90a6c6; font-family:Consolas; font-size:9px;"
                             " background:transparent; border:none;")
            cv.addWidget(sl)
        h.addWidget(card, 1)
        self._hop_cards[hop] = card
        return row

    def _highlight_diagram_hop(self, hop):
        """Outline the active hop card; restore the rest to their resting style."""
        for hp, card in getattr(self, '_hop_cards', {}).items():
            qcol = QColor(_ACCENT) if hp == 'pop' else _HOP_COLOURS.get(hp, QColor(_ACCENT))
            hexc = qcol.name()
            if hp == hop:
                card.setStyleSheet(
                    f"QFrame#hopcard {{ background:#0e1830; border:2px solid {hexc};"
                    f" border-radius:6px; }}")
            else:
                card.setStyleSheet(
                    f"QFrame#hopcard {{ background:#0b1322; border:1px solid {_BORDER};"
                    f" border-radius:6px; }}"
                    f"QFrame#hopcard:hover {{ border-color:{hexc}; background:#0e1830; }}")

    def _isolate_hop(self, hop):
        """Click a diagram hop → light ONLY that hop on the canvas (toggle: click
        again, or a hop with no geometry, restores the whole route)."""
        route = getattr(self, '_route', None)
        if not route:
            return
        # POP: light the single aggregation point (it lives ~km from the cluster,
        # so it's only drawn when its card is clicked). Toggle off like any hop.
        if hop == 'pop':
            pg = route.get('pop_geom')
            if pg is None or pg.isEmpty():
                self._set_status('POP feature not found in the project', colour=_RED)
                return
            if getattr(self, '_isolated_hop', None) == 'pop':
                self._isolated_hop = None
                self._draw_route(route)
                self._highlight_diagram_hop(None)
                self._set_status(f'Showing whole PON {route["pon"]}', colour=_ACCENT)
                return
            self._isolated_hop = 'pop'
            for h, band in self._bands.items():
                gt = (QgsWkbTypes.GeometryType.LineGeometry
                      if h in ('feeder', 'dist', 'drop', 'arrow')
                      else QgsWkbTypes.GeometryType.PointGeometry)
                band.reset(gt)
            pb = self._bands.get('pop')
            if pb is not None:
                pb.addGeometry(pg, None)
            # select the POP feature so its attributes show for cross-check
            lyr = self._layers.get('pop')
            if lyr is not None and self._idx.get('pop'):
                self._programmatic_select = True
                try:
                    lyr.selectByIds([self._idx['pop']['fid']])
                except Exception:
                    pass
                finally:
                    self._programmatic_select = False
            self._zoom_to({'pop': [pg]})
            self.canvas.refresh()
            self._highlight_diagram_hop('pop')
            self._set_status(f'POP · {route.get("pop_label") or "aggregation point"}',
                             colour=_ACCENT)
            return
        glist = route['geoms'].get(hop, [])
        if not glist or getattr(self, '_isolated_hop', None) == hop:
            self._isolated_hop = None
            self._draw_route(route)
            self._highlight_diagram_hop(None)
            self._set_status(f'Showing whole PON {route["pon"]}', colour=_ACCENT)
            return
        self._isolated_hop = hop
        for h, band in self._bands.items():
            gt = (QgsWkbTypes.GeometryType.LineGeometry
                  if h in ('feeder', 'dist', 'drop', 'arrow')
                  else QgsWkbTypes.GeometryType.PointGeometry)
            band.reset(gt)
        band = self._bands.get(hop)
        if band is not None:
            for g in glist:
                band.addGeometry(g, None)
        self._zoom_to({hop: glist})
        self.canvas.refresh()
        self._highlight_diagram_hop(hop)
        self._set_status(
            f'Isolated {_HOP_TITLES.get(hop, hop.upper())} ({len(glist)}) — '
            f'click it again to show the whole route',
            colour=_HOP_COLOURS[hop].name() if hop in _HOP_COLOURS else _ACCENT)

    def _route_flags(self, port, fts, sts_all, legs, feeder_lbls=None):
        """Cheap sanity flags surfaced beside the route (expanded in a later step):
        an unresolved feeder cable, no FTS, no resolvable AGG dome feature, or a
        leg whose dome has 0 homes."""
        flags = []
        # A cached feeder label that no longer matches a live cable is DROPPED
        # silently by _resolve_route (and excluded from _loss_budget), so the route
        # looks complete while a hop is missing and the loss is understated. That
        # bit us on 2026-07-15 (G997) and again on 2026-07-27 (G901 -> H022) after
        # a live rename. Say so instead of hiding it. Checked BEFORE the no-FTS
        # early return so it is never swallowed.
        #
        # Only pole-to-pole CABLES are expected to resolve. The POP->manhole duct
        # hop (MOA.AGG.POP.01-MH.A001/A002) lives in the Ducts layer, which we do
        # not index, and is legitimately absent on every route -- flagging it would
        # fire on all 66 PONs and bury the real hit. Measured on live PH2:
        # 30/30 feeder cables contain '-P.', 0/2 duct hops do. Unknown naming on
        # another client simply stays quiet (fails safe, no false alarm).
        # isinstance guard: the labels come from a JSON cache, so a malformed file
        # could hand us a non-string -- `'-P.' in fl` would raise where the old
        # dict .get() never did. Never let a warning break the route it warns about.
        for fl in (feeder_lbls or []):
            if (isinstance(fl, str) and '-P.' in fl
                    and fl not in self._idx.get('feed_by_label', {})):
                flags.append(('amber',
                              f'Feeder cable not found live: {fl} '
                              '- hop not drawn, loss understated (stale cache?)'))
        if not fts:
            flags.append(('red', f'No FTS splitter resolves for {port}'))
            return flags
        if fts.get('agg_geom') is None:
            flags.append(('amber', 'FTS has no AGG dome feature on the map'))
        for lg in legs:
            if lg.get('homes', 0) == 0 and lg.get('dis'):
                tail = (lg.get('dis') or '').split('.')[-1]
                flags.append(('amber',
                              f"{lg.get('leg') or 'STS'} · {tail}: dome serves 0 homes"))
        return flags

    def _copy_route(self):
        """Copy the read-out (the full route breakdown) to the clipboard."""
        lines = [self.readout.item(i).text() for i in range(self.readout.count())]
        if not lines:
            return
        try:
            QApplication.clipboard().setText('\n'.join(lines))
            self._set_status(f'Copied {len(lines)} route lines to clipboard', colour=_ACCENT)
        except Exception:
            pass

    def _selected_path_geoms(self, route):
        """Arrow geoms for JUST the current selection's path: the feeder trunk +
        the distribution leg(s) that reach the selected DIS dome(s) + the selected
        drop(s). Everything else in the PON is left un-arrowed."""
        g = route['geoms']
        dis_geoms = [dm for dm in g.get('dis', []) if dm is not None and not dm.isEmpty()]
        th = 25 / 111320.0                      # ~25 m in degrees
        dist = []
        for dc in route.get('dist_cables', []):
            dgm = dc.get('geom')
            if dgm is None or dgm.isEmpty():
                continue
            if any(dgm.distance(dm) <= th for dm in dis_geoms):
                dist.append(dgm)
        # ONE clean POP -> ONT flow: trace a single drop (the selected DR, or the
        # first of a leg), not the whole STS drop-fan.
        return {
            'feeder': list(g.get('feeder', [])),
            'dist':   dist,
            'drop':   list(g.get('drop', []))[:1],
            'sts': [], 'dis': [], 'agg': [],
        }

    def _tick_arrows(self):
        """March the flow arrows one step. Bounded — self-stops when the viewer is
        hidden or the arrows checkbox is off (no always-on loop)."""
        if (not self.isVisible()
                or not (getattr(self, 'arrows_chk', None) and self.arrows_chk.isChecked())
                or not self._arrow_geoms):
            self._stop_arrow_anim()
            return
        self._arrow_phase = (self._arrow_phase + 0.005) % 1.0
        try:
            self._draw_arrows(self._arrow_geoms, self._arrow_dome, self._arrow_phase)
        except Exception:
            self._stop_arrow_anim()

    def _start_arrow_anim(self):
        t = getattr(self, '_arrow_timer', None)
        if t is not None and not t.isActive():
            t.start()

    def _stop_arrow_anim(self):
        t = getattr(self, '_arrow_timer', None)
        if t is not None and t.isActive():
            t.stop()

    def _draw_arrows(self, geoms, dome_pt, phase=0.0):
        """Draw filled flow-direction arrowheads along the feeder/dist/drop lines.
        Flow radiates from the AGG dome (the PON source): the feeder flows INTO
        the dome (from the POP), distribution + drops flow OUTWARD to the homes.
        `phase` (0..1) marches the heads along each line for the flow animation."""
        import math
        from qgis.core import QgsGeometry, QgsPointXY
        band = self._bands.get('arrow')
        glow = self._bands.get('arrow_glow')
        if band is None:
            return
        band.reset(QgsWkbTypes.GeometryType.PolygonGeometry)
        if glow is not None:
            glow.reset(QgsWkbTypes.GeometryType.PolygonGeometry)
        if dome_pt is None:
            return
        dx0, dy0 = dome_pt.x(), dome_pt.y()
        def dist2(p): return (p.x() - dx0) ** 2 + (p.y() - dy0) ** 2

        def polylines(geom):
            try:
                if geom.isMultipart():
                    return [pl for pl in geom.asMultiPolyline() if len(pl) >= 2]
                pl = geom.asPolyline()
                return [pl] if len(pl) >= 2 else []
            except Exception:
                return []

        # arrowhead size from the route's OWN cluster extent (deterministic — the
        # canvas may still be mid-zoom when this runs)
        from qgis.core import QgsRectangle
        rect = None
        for hop in ('dist', 'drop', 'sts', 'dis', 'agg', 'feeder'):
            for g in geoms.get(hop, []):
                bb = g.boundingBox()
                if not bb.isEmpty():
                    rect = QgsRectangle(bb) if rect is None else (rect.combineExtentWith(bb) or rect)
        span = max(rect.width(), rect.height()) if rect else 0.005
        SIZE = min(max(span * 0.018, 2e-5), 1.2e-4)

        glow_polys, crisp_polys = [], []
        def _tri(store, p, ux, uy, sz, wide):
            # collect a solid triangle ring (tip + two swept-back wings) — added to
            # its band in ONE multipolygon at the end (one repaint = smooth).
            bx, by = -ux * sz, -uy * sz                    # back along flow
            px, py = -uy * sz * wide, ux * sz * wide       # perpendicular half-width
            tip = QgsPointXY(p.x(), p.y())
            wl  = QgsPointXY(p.x() + bx + px, p.y() + by + py)
            wr  = QgsPointXY(p.x() + bx - px, p.y() + by - py)
            store.append([QgsPointXY(p.x(), p.y()), wl, wr, QgsPointXY(p.x(), p.y())])

        def add_head(p, ux, uy, sz):
            # a soft cyan halo under a crisp, sleeker head — a neon flow arrow
            if glow is not None:
                _tri(glow_polys, p, ux, uy, sz * 1.7, 0.62)
            _tri(crisp_polys, p, ux, uy, sz, 0.5)

        # trunk arrows (feeder/dist) large & prominent; drop arrows small & subtle
        HOP_SZ = {'feeder': SIZE * 1.4, 'dist': SIZE * 1.3, 'drop': SIZE * 0.55}
        for hop in ('feeder', 'dist', 'drop'):
            outward = hop != 'feeder'               # feeder flows toward the dome
            sz = HOP_SZ[hop]
            for g in geoms.get(hop, []):
                for pl in polylines(g):
                    # orient vertex list upstream -> downstream
                    if outward:
                        if dist2(pl[0]) > dist2(pl[-1]):
                            pl = pl[::-1]            # ensure increasing dist (outward)
                    else:
                        if dist2(pl[0]) < dist2(pl[-1]):
                            pl = pl[::-1]            # ensure decreasing dist (toward dome)
                    # total length + sample points
                    segs = [(pl[i], pl[i + 1]) for i in range(len(pl) - 1)]
                    seglen = [math.hypot(b.x() - a.x(), b.y() - a.y()) for a, b in segs]
                    total = sum(seglen)
                    if total <= 0:
                        continue
                    # number of arrowheads: drops 1, trunk lines scale with length
                    n = 1 if hop == 'drop' else min(4, max(1, int(total / (SIZE * 6))))
                    for k in range(n):
                        # marching offset: heads slide along the flow as phase 0->1
                        frac = ((k + 1) / (n + 1) + phase) % 1.0
                        target = total * frac
                        acc = 0.0
                        for (a, b), L in zip(segs, seglen):
                            if acc + L >= target and L > 0:
                                t = (target - acc) / L
                                px = a.x() + (b.x() - a.x()) * t
                                py = a.y() + (b.y() - a.y()) * t
                                ux, uy = (b.x() - a.x()) / L, (b.y() - a.y()) / L
                                # gentle size pulse travelling with the march
                                hz = sz * (0.82 + 0.30 * (0.5 + 0.5 * math.sin(2 * math.pi * frac)))
                                add_head(QgsPointXY(px, py), ux, uy, hz)
                                break
                            acc += L
        # flush each band as ONE multipolygon -> a single repaint per frame (smooth)
        if glow is not None and glow_polys:
            glow.addGeometry(QgsGeometry.fromMultiPolygonXY([[r] for r in glow_polys]), None)
        if crisp_polys:
            band.addGeometry(QgsGeometry.fromMultiPolygonXY([[r] for r in crisp_polys]), None)

    def _draw_labels(self, port, fts, sts_list, pon, feeder_lbls, show_drops,
                     emphasize=False, dist_cables=None):
        """Populate the text-label overlay: FTS, each STS leg + its DIS dome, the
        AGG dome, and the distribution + feeder cable IDs. When *emphasize* (a
        specific STS/DR is selected) the STS labels are drawn larger."""
        if not getattr(self, 'labels_chk', None) or not self.labels_chk.isChecked():
            self._labels.clear()
            return
        import re
        def sd(l):   # dome/pole tail: MOA.DIS.DM.P.F726 -> F726
            return re.sub(r'.*\.P\.', '', l or '')
        def sc(l):   # cable: MOA.DF.24F.P.F409-P.H263 -> F409-H263
            if not l:
                return ''
            return re.sub(r'^MOA\.\w+\.\d+F\.P\.', '', l).replace('-P.', '-')
        def ctr(g):
            try:
                return g.centroid().asPoint()
            except Exception:
                return None

        sts_sz = 14 if emphasize else 9       # selected splitter labels pop bigger
        items = []
        if fts and fts.get('geom') is not None and not fts['geom'].isEmpty():
            p = ctr(fts['geom'])
            if p: items.append((p, f'FTS 1:16 · {port}', QColor(245, 170, 255), 10))
        if fts and fts.get('agg_geom') is not None and not fts['agg_geom'].isEmpty():
            p = ctr(fts['agg_geom'])
            if p: items.append((p, 'AGG ' + sd(fts.get('agg')), QColor(120, 225, 245), 10))
        for s in sts_list:
            g = s.get('geom')
            if g is not None and not g.isEmpty():
                p = ctr(g)
                if p:
                    items.append((p, f"{s.get('leg') or 'STS'} · {sd(s.get('dis'))}",
                                  QColor(150, 245, 165), sts_sz))
        for dc in (dist_cables if dist_cables is not None
                   else self._idx['dist_by_pon'].get(str(pon), [])):
            g = dc.get('geom')
            if g is not None and not g.isEmpty():
                p = ctr(g)
                if p: items.append((p, sc(dc.get('label')), QColor(250, 180, 110), 9))
        for fl in (feeder_lbls or []):
            cab = self._idx['feed_by_label'].get(fl)
            if cab and cab.get('geom') is not None and not cab['geom'].isEmpty():
                p = ctr(cab['geom'])
                if p: items.append((p, 'feeder ' + sc(fl), QColor(255, 150, 150), 9))
        self._labels.set_items(items)

    def _zoom_to(self, geoms):
        from qgis.core import QgsRectangle
        rect = None
        # Frame the PON access cluster — the homes and their splitters/domes.
        # The feeder runs back to the POP and the distribution can fan out, so
        # zoom to drops/ONTs/STS/DIS first (the splice detail JJ checks); only
        # broaden to the other hops if that cluster is empty.
        cluster = ['drop', 'ont', 'sts', 'dis']
        broad   = ['agg', 'dist', 'fts', 'feeder']
        use = [h for h in cluster if geoms.get(h)]
        if not use:
            use = [h for h in (cluster + broad) if geoms.get(h)] or list(geoms.keys())
        for hop in use:
            for g in geoms.get(hop, []):
                bb = g.boundingBox()
                if bb.isEmpty():
                    continue
                rect = QgsRectangle(bb) if rect is None else (rect.combineExtentWith(bb) or rect)
        if rect is None or rect.isEmpty():
            return
        # buffer 12 %
        dx = rect.width() * 0.12 or 0.0005
        dy = rect.height() * 0.12 or 0.0005
        rect = QgsRectangle(rect.xMinimum() - dx, rect.yMinimum() - dy,
                            rect.xMaximum() + dx, rect.yMaximum() + dy)
        self.canvas.setExtent(rect)

    def _fill_readout(self, port, pon, only_sts, labels):
        from qgis.PyQt.QtWidgets import QListWidgetItem
        self.readout.clear()
        head = QListWidgetItem(
            f'━━ PON {pon} · Zone {self._pon_to_zone(pon)} · {port}'
            + (f'  ·  STS {only_sts.split(".")[-1]}' if only_sts else '  ·  WHOLE PON')
            + ' ━━')
        head.setForeground(QColor(_ACCENT)); self.readout.addItem(head)
        order = ['feeder', 'fts', 'agg', 'dist', 'sts', 'dis', 'drop', 'ont']
        for hop in order:
            vals = labels[hop]
            if not vals:
                continue
            hdr = QListWidgetItem(f'{_HOP_TITLES[hop]}  ({len(vals)})')
            hdr.setForeground(_HOP_COLOURS[hop]); self.readout.addItem(hdr)
            shown = vals if len(vals) <= 30 else vals[:30]
            for v in shown:
                self.readout.addItem(QListWidgetItem('   ' + str(v)))
            if len(vals) > 30:
                self.readout.addItem(QListWidgetItem(f'   … +{len(vals) - 30} more'))

    # ── solo (dim other layers) ──────────────────────────────────────────────
    def _apply_solo(self):
        """Fade every VECTOR layer to 15 % so only the bright route rubber bands
        (and the satellite basemap) stand out. Stores originals for restore."""
        from qgis.core import QgsVectorLayer
        if self._solo_saved is None:
            self._solo_saved = {}
            for l in QgsProject.instance().mapLayers().values():
                if isinstance(l, QgsVectorLayer):
                    try:
                        self._solo_saved[l.id()] = l.opacity()
                    except Exception:
                        pass
        # Persist the originals to the project so a CRASH/hide (where _restore_solo
        # never runs) can't strand the whole project at 15 % — heal_stranded_solo()
        # restores them on next plugin start. See ticket: recurring "greyed out" bug.
        try:
            import json as _json
            QgsProject.instance().writeEntry('SpliceViewer', 'soloSaved',
                                             _json.dumps(self._solo_saved))
        except Exception:
            pass
        for lid in list(self._solo_saved):
            l = QgsProject.instance().mapLayer(lid)
            if l:
                try:
                    l.setOpacity(0.15); l.triggerRepaint()
                except Exception:
                    pass

    def _restore_solo(self):
        # always clear the persisted safety copy — solo is (being) turned off
        try:
            QgsProject.instance().removeEntry('SpliceViewer', 'soloSaved')
        except Exception:
            pass
        if not self._solo_saved:
            self._solo_saved = None
            return
        for lid, op in self._solo_saved.items():
            l = QgsProject.instance().mapLayer(lid)
            if l:
                try:
                    l.setOpacity(op); l.triggerRepaint()
                except Exception:
                    pass
        self._solo_saved = None

    def _on_solo_toggled(self, on):
        # live toggle while a route is shown
        if on:
            if self.port_combo.currentData():
                self._apply_solo(); self.canvas.refresh()
        else:
            self._restore_solo(); self.canvas.refresh()

    def _set_status(self, msg, colour=_DIM):
        self._status_lbl.setText(msg)
        self._status_lbl.setStyleSheet(
            f"QLabel {{ color: {colour}; font-family: Consolas; font-size: 10px;"
            f" padding: 2px; }}")

    def _clear(self, keep_status=False):
        for hop, band in self._bands.items():
            gt = (QgsWkbTypes.GeometryType.LineGeometry if hop in ('feeder', 'dist', 'drop', 'arrow')
                  else QgsWkbTypes.GeometryType.PointGeometry)
            band.reset(gt)
        self._programmatic_select = True
        try:
            for lyr in self._layers.values():
                if lyr is not None:
                    try:
                        lyr.removeSelection()
                    except Exception:
                        pass
        finally:
            self._programmatic_select = False
        if getattr(self, '_labels', None) is not None:
            self._labels.clear()
        self._restore_solo()
        self.canvas.refresh()
        if not keep_status and hasattr(self, '_status_lbl'):
            self._set_status('Cleared.')

    def cleanup(self):
        """Stop the Excel poll timer, drop the per-layer selection handlers, and
        clear the canvas overlays. Called when the host dock is destroyed (or on
        plugin unload) — NOT on a plain hide, so a re-opened dock keeps working."""
        from qgis.PyQt import sip
        # CRITICAL: if 'solo' (dim-others) mode is still active, restore layer
        # opacity BEFORE we tear down — otherwise every vector layer is stranded at
        # 15 % (the whole project goes grey / invisible, and can get saved that way).
        try:
            self._restore_solo()
        except Exception:
            pass
        try:
            if getattr(self, '_xl_timer', None) is not None:
                self._xl_timer.stop()
        except Exception:
            pass
        try:
            if getattr(self, '_arrow_timer', None) is not None:
                self._arrow_timer.stop()
        except Exception:
            pass
        try:
            if getattr(self, '_walk_timer', None) is not None:
                self._walk_timer.stop()
            self._walk_timer = None
        except Exception:
            pass
        # guard each disconnect with sip.isdeleted: on app exit the C++ layer may
        # already be gone, and disconnecting a dead sender is an access violation.
        for lyr in self._layers.values():
            if lyr is not None and not sip.isdeleted(lyr):
                try:
                    lyr.selectionChanged.disconnect(self._on_user_select)
                except Exception:
                    pass
        try:
            self._clear()
        except Exception:
            pass

    def closeEvent(self, e):
        self.cleanup()
        super().closeEvent(e)


# combo styling reused by the route viewer
_COMBO_CSS = (
    f"QComboBox {{ background:#11131f; color:{_TEXT}; border:1px solid {_BORDER};"
    f" border-radius:4px; padding:5px 8px; font-family:Consolas; font-size:11px; }}"
    f"QComboBox:hover {{ border-color:{_ACCENT}; }}"
    f"QComboBox QAbstractItemView {{ background:#11131f; color:{_TEXT};"
    f" selection-background-color:{_VIOLET}; font-family:Consolas; font-size:11px; }}")


# ── Merged Pole Editor panel ──────────────────────────────────────────────────

class PoleEditorPanel(QWidget):

    def __init__(self, iface, lyr, parent=None):
        super().__init__(parent)                 # hosted in a _PanelDock (dockable)
        self.setObjectName('vfPoleEditorPanel')
        self.iface        = iface
        self.lyr          = lyr
        # Resolve thickness reason field name. Shapefile truncates to 10
        # chars ('thickness_'); GPKG keeps the full 'thickness_reason'.
        self.ti_thickness = lyr.fields().indexOf('thickness_')
        if self.ti_thickness < 0:
            self.ti_thickness = lyr.fields().indexOf('thickness_reason')
        if self.ti_thickness < 0:
            iface.messageBar().pushWarning(
                'Pole Editor',
                f"'{lyr.name()}' has no thickness_/thickness_reason field — "
                "RC and thickness buttons will be disabled."
            )
        self.ti_dim2      = lyr.fields().indexOf('dim2')
        # S5 Slack Bracket slot — note field name is 'subtype5' (NO underscore)
        self.ti_t5        = lyr.fields().indexOf('type_5')
        self.ti_st5       = lyr.fields().indexOf('subtype5')
        self.ti_sp5       = lyr.fields().indexOf('spec_5')
        self.ti_d5        = lyr.fields().indexOf('dim1_5')
        self.ti_d5_2      = lyr.fields().indexOf('dim2_5')
        self.setWindowTitle('Pole Editor')
        self.setMinimumWidth(360)

        # Static dashed rings — no animation, just visual markers.
        self._not_rc_geoms = {}
        self._blue_band = _SpinRing(
            iface.mapCanvas(), QColor(0, 170, 255, 255),          # electric blue
            radius_px=14, width_px=3.0, dash_pattern=[6, 3])
        self._yellow_band = _SpinRing(
            iface.mapCanvas(), QColor(0, 230, 80, 255),           # vivid lime
            radius_px=9, width_px=3.0, dash_pattern=[2, 2])
        self._red_band = _SpinRing(
            iface.mapCanvas(), QColor(255, 40, 80, 255),          # vivid red
            radius_px=11, width_px=3.0, dash_pattern=[1, 2])

        # Green diamonds — FTS splitters (reference overlay)
        self._fts_band = QgsRubberBand(iface.mapCanvas(), QgsWkbTypes.GeometryType.PointGeometry)
        self._fts_band.setColor(QColor(34, 197, 94, 255))           # bright green fill
        self._fts_band.setIcon(QgsRubberBand.IconType.ICON_FULL_DIAMOND)
        self._fts_band.setIconSize(26)
        self._fts_band.setWidth(3)                                    # outline stroke
        self._fts_band.setSecondaryStrokeColor(QColor(0, 80, 0, 220))  # dark green border

        # S5 band kept as a dummy so legacy callbacks don't AttributeError
        self._s5_band = QgsRubberBand(iface.mapCanvas(), QgsWkbTypes.GeometryType.PointGeometry)
        self._s5_band.setWidth(0)

        self._redraw_bands()

        # Keep the panel pinned to the canvas top-left corner
        canvas = iface.mapCanvas()
        canvas.installEventFilter(self)
        canvas.viewport().installEventFilter(self)

        # ── Layout ────────────────────────────────────────────────────────────
        self.setStyleSheet(f"QWidget#vfPoleEditorPanel {{ background: {_BG}; }}")
        layout = QVBoxLayout(self)
        layout.setSpacing(6)
        layout.setContentsMargins(12, 12, 12, 10)

        subtitle = QLabel('Click a pole on the map to select it, then:')
        subtitle.setStyleSheet(_SUBTITLE_LBL)
        layout.addWidget(subtitle)

        # Road crossing section
        rc_label = QLabel('ROAD CROSSING')
        rc_label.setStyleSheet(_SECTION_LBL)
        layout.addWidget(rc_label)

        rc_row = QHBoxLayout()
        rc_row.setSpacing(8)

        btn_mark_rc = QPushButton('🟢  Mark Road Crossing')
        btn_mark_rc.setStyleSheet(_BTN_GREEN)
        btn_mark_rc.clicked.connect(self._mark_rc)
        rc_row.addWidget(btn_mark_rc)

        btn_unmark_rc = QPushButton('🔴  Not Road Crossing')
        btn_unmark_rc.setStyleSheet(_BTN_RED)
        btn_unmark_rc.clicked.connect(self._unmark_rc)
        rc_row.addWidget(btn_unmark_rc)

        layout.addLayout(rc_row)

        # Divider
        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet(_DIVIDER)
        layout.addWidget(line)

        # Thickness section
        th_label = QLabel('POLE THICKNESS')
        th_label.setStyleSheet(_SECTION_LBL)
        layout.addWidget(th_label)

        th_row = QHBoxLayout()
        th_row.setSpacing(8)

        btn_thick = QPushButton('🔵  140-160mm  (Thick)')
        btn_thick.setStyleSheet(_BTN_GRADIENT)
        btn_thick.clicked.connect(self._make_thick)
        th_row.addWidget(btn_thick)

        btn_thin = QPushButton('⚪  120-140mm  (Thin)')
        btn_thin.setStyleSheet(_BTN_CLEAR)
        btn_thin.clicked.connect(self._make_thin)
        th_row.addWidget(btn_thin)

        layout.addLayout(th_row)

        # Slack Bracket (S5) — manual-only per project_s5_slack_bracket_decision.md
        s5_label = QLabel('SLACK BRACKET (S5 · MANUAL)')
        s5_label.setStyleSheet(_SECTION_LBL)
        layout.addWidget(s5_label)

        s5_row = QHBoxLayout(); s5_row.setSpacing(8)
        btn_s5_add = QPushButton('🟣  Add Slack Bracket')
        btn_s5_add.setStyleSheet(_BTN_S5)
        btn_s5_add.clicked.connect(self._mark_s5)
        s5_row.addWidget(btn_s5_add)

        btn_s5_rm = QPushButton('🚫  Remove Slack Bracket')
        btn_s5_rm.setStyleSheet(_BTN_CLEAR)
        btn_s5_rm.clicked.connect(self._unmark_s5)
        s5_row.addWidget(btn_s5_rm)
        layout.addLayout(s5_row)

        # Status
        self._status_lbl = QLabel('')
        self._status_lbl.setWordWrap(True)
        self._status_lbl.setStyleSheet(_STATUS_LBL)
        layout.addWidget(self._status_lbl)

        # Legend — static dashed-ring previews that match the canvas overlays
        legend_frame = QFrame()
        legend_frame.setStyleSheet('background: transparent;')
        lg = QVBoxLayout(legend_frame)
        lg.setContentsMargins(0, 0, 0, 0)
        lg.setSpacing(4)
        for hex6, pattern, label in (
            ('#00aaff', [], '  large blue ring  =  140-160mm thick pole'),
            ('#00e650', [], '  medium green ring  =  road crossing'),
            ('#ff2850', [], '  small red ring  =  NOT a road crossing'),
        ):
            row = QHBoxLayout()
            row.setSpacing(6)
            ring = _SpinRingPreview(QColor(hex6), pattern, diameter_px=22, width_px=2.2)
            row.addWidget(ring)
            lbl = QLabel(label)
            lbl.setStyleSheet(_HINT_LBL)
            row.addWidget(lbl, 1)
            lg.addLayout(row)
        fts_lbl = QLabel('🟢 green diamond = FTS splitter (main cable origin)')
        fts_lbl.setStyleSheet(_HINT_LBL)
        lg.addWidget(fts_lbl)
        layout.addWidget(legend_frame)

        click_hint = QLabel('Click to select · Shift+click to add · Edits auto-fill attrs')
        click_hint.setWordWrap(True)
        click_hint.setStyleSheet(_HINT_LBL)
        layout.addWidget(click_hint)

    # ── Internals ─────────────────────────────────────────────────────────────

    def _set_status(self, msg, colour=_TEXT):
        self._status_lbl.setText(msg)
        self._status_lbl.setStyleSheet(
            f"QLabel {{ color: {colour}; font-family: Consolas; "
            f"font-size: 10px; padding: 2px; }}"
        )

    def _redraw_bands(self):
        blue_pts = []
        green_pts = []
        red_pts = []
        for f in self.lyr.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            pt = g.asPoint()
            if str(f['dim2']) == '140-160mm':
                blue_pts.append(pt)
            # Use the resolved thickness-reason index (shapefile 'thickness_' vs
            # GPKG 'thickness_reason') so the green RC overlay works on both.
            ti = getattr(self, 'ti_thickness', -1)
            tval = f.attribute(ti) if ti is not None and ti >= 0 else None
            if tval is not None and 'road crossing' in str(tval).lower():
                green_pts.append(pt)
        for geom in self._not_rc_geoms.values():
            if geom and not geom.isEmpty():
                red_pts.append(geom.asPoint())
        self._blue_band.setPoints(blue_pts)
        self._yellow_band.setPoints(green_pts)
        self._red_band.setPoints(red_pts)
        # FTS splitters — yellow diamonds (rubber band, not animated)
        self._fts_band.reset(QgsWkbTypes.GeometryType.PointGeometry)
        proj = QgsProject.instance()
        candidates = [l for l in proj.mapLayers().values()
                      if 'fts' in l.name().lower() and 'splitter' in l.name().lower()]
        fts_lyr = next((l for l in candidates if 'v1' in l.name().lower()), None) \
                  or (candidates[0] if candidates else None)
        if fts_lyr:
            for f in fts_lyr.getFeatures():
                g = f.geometry()
                if g and not g.isEmpty():
                    self._fts_band.addGeometry(g, None)

    def _write_attrs(self, attr_map):
        """Write attribute changes through the edit buffer when the layer is
        editable, otherwise via the data provider. Returns True on success."""
        if not attr_map:
            return True
        if self.lyr.isEditable():
            ok = True
            for fid, kv in attr_map.items():
                for idx, val in kv.items():
                    if not self.lyr.changeAttributeValue(fid, idx, val):
                        ok = False
            return ok
        return self.lyr.dataProvider().changeAttributeValues(attr_map)

    def _auto_populate_new(self, fids):
        """For any pole in *fids* that still has a null Label / Pole Type /
        hardware / lat / lon / dim2, compute and fill in the canonical PH2
        attribute set (H-sequence label, Pole Type from nearest cable, way
        count, Tangent-vs-Dead-End hardware per PH1 rule, Slot 4 Hook, Slot 6/7
        BandIt, dim2 default 140-160mm, lat/lon from geometry). Silent no-op
        for poles that already have everything filled in."""
        import math, re
        from qgis.core import QgsProject

        lyr = self.lyr
        flds = lyr.fields()
        def fi(n): return flds.indexOf(n)
        F_LBL=fi("Label"); F_PT=fi("Pole Type")
        F_T2=fi("type_2"); F_ST2=fi("subtype_2"); F_D2=fi("dim1_2"); F_SP2=fi("spec_2"); F_FN1=fi("featno1")
        F_T3=fi("type_3"); F_ST3=fi("subtype_3"); F_D3=fi("dim1_3"); F_SP3=fi("spec_3"); F_FN2=fi("featno2")
        F_T4=fi("type_4"); F_ST4=fi("subtype4"); F_SP4=fi("spec_4"); F_D4=fi("dim1_4"); F_FN3=fi("featno3"); F_FN4=fi("featno4")
        F_T6=fi("type_6"); F_ST6=fi("subtype_6"); F_SP6=fi("spec_6"); F_DM6=fi("dim1_6"); F_FN5=fi("featno5")
        F_T7=fi("type_7"); F_ST7=fi("subtype7");  F_SP7=fi("spec_7"); F_DM7=fi("dim1_7"); F_FN6=fi("featno6")
        F_LAT=fi("lat"); F_LON=fi("lon"); F_DIM2=fi("dim2")

        def is_null(v): return v is None or str(v).strip() in ("", "NULL", "None")

        needs = []
        for fid in fids:
            f = lyr.getFeature(fid)
            if (is_null(f.attribute(F_LBL)) or is_null(f.attribute(F_PT)) or
                (is_null(f.attribute(F_T2)) and is_null(f.attribute(F_T3))) or
                is_null(f.attribute(F_DIM2)) or is_null(f.attribute(F_LAT)) or
                is_null(f.attribute(F_LON)) or is_null(f.attribute(F_SP4)) or
                is_null(f.attribute(F_SP6))):
                needs.append(fid)
        if not needs:
            return

        target_geoms = {}
        for fid in needs:
            g = lyr.getFeature(fid).geometry()
            if g and not g.isEmpty():
                target_geoms[fid] = g.asPoint()
        if not target_geoms:
            return

        SNAP_M = 3.0
        SNAP_DEG = SNAP_M / 111320.0

        CABLE_LAYERS = [
            ("Primary Cable v1",    "Primary Feeder",   3),
            ("Secondary Cable v1",  "Secondary Feeder", 2),
            ("Distribution Cable v1","Distribution",    1),
            ("Drop Cable v1",       "Drop",             0),
        ]
        proj = QgsProject.instance()
        hits = {fid: [] for fid in target_geoms}
        for lname, ptype, rank in CABLE_LAYERS:
            clyr = next((l for l in proj.mapLayers().values()
                         if l.name().lower() == lname.lower()), None)
            if not clyr:
                continue
            for feat in clyr.getFeatures():
                g = feat.geometry()
                if not g or g.isEmpty():
                    continue
                cbb = g.boundingBox()
                relevant = [(fid, pt) for fid, pt in target_geoms.items()
                            if cbb.xMinimum() - SNAP_DEG <= pt.x() <= cbb.xMaximum() + SNAP_DEG
                            and cbb.yMinimum() - SNAP_DEG <= pt.y() <= cbb.yMaximum() + SNAP_DEG]
                if not relevant:
                    continue
                lines = [g.asPolyline()] if not g.isMultipart() else g.asMultiPolyline()
                for line in lines:
                    if len(line) < 2:
                        continue
                    for i, v in enumerate(line):
                        for fid, pt in relevant:
                            dx = v.x() - pt.x(); dy = v.y() - pt.y()
                            if (dx*dx + dy*dy) ** 0.5 > SNAP_DEG:
                                continue
                            neighbours = []
                            if i > 0:
                                for j in range(i - 1, -1, -1):
                                    nv = line[j]
                                    if ((nv.x() - pt.x())**2 + (nv.y() - pt.y())**2) ** 0.5 > SNAP_DEG:
                                        neighbours.append(nv); break
                            if i < len(line) - 1:
                                for j in range(i + 1, len(line)):
                                    nv = line[j]
                                    if ((nv.x() - pt.x())**2 + (nv.y() - pt.y())**2) ** 0.5 > SNAP_DEG:
                                        neighbours.append(nv); break
                            for nv in neighbours:
                                bin_ = round(math.degrees(math.atan2(nv.y() - pt.y(),
                                                                      nv.x() - pt.x())) / 15) * 15
                                hits[fid].append((bin_, rank, ptype))

        max_h = 0
        for f in lyr.getFeatures():
            m = re.search(r"\.H(\d+)$", str(f.attribute(F_LBL) or ""))
            if m:
                max_h = max(max_h, int(m.group(1)))

        null_lbl_fids = [fid for fid in needs
                         if is_null(lyr.getFeature(fid).attribute(F_LBL))]
        null_lbl_fids.sort()
        label_assign = {fid: f"MOA.P.H{max_h + 1 + i}"
                        for i, fid in enumerate(null_lbl_fids)}

        updates = {}
        for fid, pt in target_geoms.items():
            f = lyr.getFeature(fid)
            upd = updates.setdefault(fid, {})

            def fill(idx, val):
                # Only write if the cell is currently null — never clobber
                # a value the user set.
                if idx >= 0 and is_null(f.attribute(idx)):
                    upd[idx] = val

            if fid in label_assign:
                fill(F_LBL, label_assign[fid])

            h = hits.get(fid, [])
            non_drop_dirs = {x[0] for x in h if x[1] > 0}
            way_count = max(1, len(non_drop_dirs))

            cur_pt = str(f.attribute(F_PT))
            new_pt = None
            non_drop = [x for x in h if x[1] > 0]
            if non_drop:
                new_pt = max(non_drop, key=lambda x: x[1])[2]
            elif h:
                new_pt = "Drop"
            if is_null(cur_pt) and new_pt:
                fill(F_PT, new_pt)
                cur_pt = new_pt

            cur_t2 = str(f.attribute(F_T2))
            cur_t3 = str(f.attribute(F_T3))

            # Only write hardware slots if BOTH t2 and t3 are currently null
            # (i.e. the pole has never been classified). Never overwrite an
            # existing Tangent/Dead-End choice — that includes manual exceptions.
            if is_null(cur_t2) and is_null(cur_t3):
                cable_dim = "10,54-11,65mm" if cur_pt == "Primary Feeder" else "9,40-10,50mm"
                fill(F_T2, "Dead-End"); fill(F_ST2, "ADSS")
                fill(F_SP2, "Galvanised Steel Wire/Steel Thimble")
                fill(F_D2, cable_dim)
                fill(F_FN1, way_count)

            # Slot 4 Hook — fill only if null
            fill(F_T4, "Hook"); fill(F_ST4, "Offset Bracket")
            fill(F_SP4, f"{way_count}Way")
            fill(F_D4, f"(R19*W12,50mm)*{way_count}")
            fill(F_FN3, way_count)
            fill(F_FN4, 1)
            # Slot 6 / 7 BandIt — fill only if null
            fill(F_T6, "Attachment"); fill(F_ST6, "Strapping")
            fill(F_SP6, "Grade304 BandIt"); fill(F_DM6, "19*0,5mm"); fill(F_FN5, 4)
            fill(F_T7, "Attachment"); fill(F_ST7, "Buckle")
            fill(F_SP7, "Grade304 BandIt"); fill(F_DM7, "19mm"); fill(F_FN6, 2)

            # dim2 default — only if still null (never overwrites a manual 120/140)
            fill(F_DIM2, "140-160mm")
            # lat/lon — only if null
            if is_null(f.attribute(F_LAT)):
                fill(F_LAT, round(pt.y(), 6))
            if is_null(f.attribute(F_LON)):
                fill(F_LON, round(pt.x(), 6))

        # Drop empty update dicts
        updates = {k: v for k, v in updates.items() if v}
        if updates:
            self._write_attrs(updates)

    def _mark_rc(self):
        feats = self.lyr.selectedFeatures()
        if not feats:
            self._set_status('No poles selected — click a pole first.', '#f59e0b')
            return
        attr_map = {}
        skipped = 0
        for f in feats:
            cur = str(f[self.ti_thickness]).strip()
            self._not_rc_geoms.pop(f.id(), None)
            if 'road crossing' in cur.lower():
                skipped += 1
                continue
            new_val = (cur + '; road crossing') if cur not in ('', 'NULL', 'None') else 'road crossing'
            attr_map[f.id()] = {self.ti_thickness: new_val}
        if attr_map:
            self._write_attrs(attr_map)
            self._auto_populate_new([f.id() for f in feats])
            self.lyr.triggerRepaint()
        self._redraw_bands()
        msg = f'Marked {len(attr_map)} as road crossing'
        if skipped:
            msg += f'  ({skipped} already flagged)'
        self._set_status(msg, '#22c55e')

    def _unmark_rc(self):
        feats = self.lyr.selectedFeatures()
        if not feats:
            self._set_status('No poles selected — click a pole first.', '#f59e0b')
            return
        attr_map = {}
        skipped = 0
        for f in feats:
            cur = str(f[self.ti_thickness]).strip()
            if 'road crossing' not in cur.lower():
                skipped += 1
                continue
            new_val = (cur
                       .replace('; road crossing', '')
                       .replace('road crossing; ', '')
                       .replace('road crossing', '')
                       .strip().strip(';').strip())
            attr_map[f.id()] = {self.ti_thickness: new_val if new_val.lower() not in ('', 'null', 'none') else None}
            if f.geometry() and not f.geometry().isEmpty():
                self._not_rc_geoms[f.id()] = f.geometry()
        if attr_map:
            self._write_attrs(attr_map)
            self._auto_populate_new([f.id() for f in feats])
            self.lyr.triggerRepaint()
        self._redraw_bands()
        msg = f'Removed road crossing from {len(attr_map)} poles'
        if skipped:
            msg += f'  ({skipped} not flagged)'
        self._set_status(msg, '#ef4444')

    def _ensure_committed(self):
        """If the layer is in an edit session with pending changes, ask the
        user before committing. dataProvider().changeAttributeValues can't see
        uncommitted features (negative fids) so we need them flushed first."""
        if not self.lyr.isEditable():
            return True
        buf = self.lyr.editBuffer()
        if buf is None:
            # Editable but nothing pending — safe to leave as-is
            return True
        pending_add = len(buf.addedFeatures()) if hasattr(buf, "addedFeatures") else 0
        pending_chg = len(buf.changedAttributeValues()) if hasattr(buf, "changedAttributeValues") else 0
        pending_geo = len(buf.changedGeometries()) if hasattr(buf, "changedGeometries") else 0
        pending_del = len(buf.deletedFeatureIds()) if hasattr(buf, "deletedFeatureIds") else 0
        total = pending_add + pending_chg + pending_geo + pending_del
        if total == 0:
            return True

        from qgis.PyQt.QtWidgets import QMessageBox
        reply = QMessageBox.question(
            self, "Commit pending edits?",
            f"The poles layer has unsaved edits:\n"
            f"  • {pending_add} new pole(s)\n"
            f"  • {pending_chg} attribute change(s)\n"
            f"  • {pending_geo} geometry change(s)\n"
            f"  • {pending_del} deletion(s)\n\n"
            "The Pole Editor needs these saved before it can tag the new\n"
            "pole(s). Commit now and continue?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.Yes)
        if reply != QMessageBox.StandardButton.Yes:
            self._set_status("Cancelled — commit your edits first.", "#f59e0b")
            return False
        ok = self.lyr.commitChanges()
        if not ok:
            err = "; ".join(self.lyr.commitErrors()[:3])
            self._set_status(f"Commit failed: {err}", "#ef4444")
            return False
        # Reopen edit session so user can keep drawing without losing mode
        self.lyr.startEditing()
        return True

    def _make_thick(self):
        feats = self.lyr.selectedFeatures()
        if not feats:
            self._set_status('No poles selected — click a pole first.', '#f59e0b')
            return
        attr_map = {}
        skipped = 0
        for f in feats:
            if str(f['dim2']) == '140-160mm':
                skipped += 1
                continue
            cur = str(f[self.ti_thickness]).strip()
            new_thick = (cur + '; manual override') if cur not in ('', 'NULL', 'None') else 'manual override'
            attr_map[f.id()] = {self.ti_dim2: '140-160mm', self.ti_thickness: new_thick}
        if attr_map:
            self._write_attrs(attr_map)
            self._auto_populate_new([f.id() for f in feats])
            self.lyr.triggerRepaint()
        self._redraw_bands()
        msg = f'Upgraded {len(attr_map)} to 140-160mm'
        if skipped:
            msg += f'  ({skipped} already thick)'
        self._set_status(msg, '#3b82f6')

    def _make_thin(self):
        feats = self.lyr.selectedFeatures()
        if not feats:
            self._set_status('No poles selected — click a pole first.', '#f59e0b')
            return
        attr_map = {}
        skipped = 0
        for f in feats:
            if str(f['dim2']) == '120-140mm':
                skipped += 1
                continue
            cur = str(f[self.ti_thickness]).strip()
            new_thick = (cur + '; manual override') if cur not in ('', 'NULL', 'None') else 'manual override'
            attr_map[f.id()] = {self.ti_dim2: '120-140mm', self.ti_thickness: new_thick}
        if attr_map:
            self._write_attrs(attr_map)
            self._auto_populate_new([f.id() for f in feats])
            self.lyr.triggerRepaint()
        self._redraw_bands()
        msg = f'Downgraded {len(attr_map)} to 120-140mm'
        if skipped:
            msg += f'  ({skipped} already thin)'
        self._set_status(msg, '#94a3b8')

    def _mark_s5(self):
        """Write canonical S5 Slack Bracket values to selected poles.
        Canonical values from PH2 live scan 2026-04-17: see
        project_s5_slack_bracket_decision.md."""
        feats = self.lyr.selectedFeatures()
        if not feats:
            self._set_status('No poles selected — click a pole first.', '#f59e0b')
            return
        if min(self.ti_t5, self.ti_st5, self.ti_sp5, self.ti_d5) < 0:
            self._set_status(
                'S5 fields missing (type_5 / subtype5 / spec_5 / dim1_5). '
                'Cannot write.', '#ef4444')
            return
        attr_map = {}
        skipped = 0
        for f in feats:
            if str(f['type_5']).strip() == 'Slack Bracket':
                skipped += 1
                continue
            row = {
                self.ti_t5:  'Slack Bracket',
                self.ti_st5: 'Bracket',
                self.ti_sp5: 'Extreme Slack',
                self.ti_d5:  'D620',
            }
            # dim2_5 'D516' confirmed against PH1 (4633 live examples, 2026-04-28)
            if self.ti_d5_2 >= 0:
                row[self.ti_d5_2] = 'D516'
            attr_map[f.id()] = row
        if attr_map:
            self._write_attrs(attr_map)
            self.lyr.triggerRepaint()
        self._redraw_bands()
        msg = f'Added Slack Bracket (S5) to {len(attr_map)} poles'
        if skipped:
            msg += f'  ({skipped} already had S5)'
        self._set_status(msg, '#7c3aed')

    def _unmark_s5(self):
        feats = self.lyr.selectedFeatures()
        if not feats:
            self._set_status('No poles selected — click a pole first.', '#f59e0b')
            return
        if min(self.ti_t5, self.ti_st5, self.ti_sp5, self.ti_d5) < 0:
            self._set_status(
                'S5 fields missing (type_5 / subtype5 / spec_5 / dim1_5). '
                'Cannot write.', '#ef4444')
            return
        attr_map = {}
        skipped = 0
        for f in feats:
            if str(f['type_5']).strip() != 'Slack Bracket':
                skipped += 1
                continue
            row = {
                self.ti_t5:  None,
                self.ti_st5: None,
                self.ti_sp5: None,
                self.ti_d5:  None,
            }
            if self.ti_d5_2 >= 0:
                row[self.ti_d5_2] = None
            attr_map[f.id()] = row
        if attr_map:
            self._write_attrs(attr_map)
            self.lyr.triggerRepaint()
        self._redraw_bands()
        msg = f'Removed Slack Bracket (S5) from {len(attr_map)} poles'
        if skipped:
            msg += f'  ({skipped} had no S5)'
        self._set_status(msg, '#94a3b8')

    def _snap_to_canvas_topleft(self):
        canvas = self.iface.mapCanvas()
        top_left = canvas.viewport().mapToGlobal(canvas.viewport().rect().topLeft())
        self.move(top_left.x() + 8, top_left.y() + 8)

    def _refresh_all_incomplete(self):
        """Auto-populate all poles that still have null Label / Pole Type /
        hardware / dim2 / lat / lon. Never overrides existing non-null values,
        so manual marks (road crossing, thick, thin, Tangent exceptions, S5)
        stay untouched."""
        try:
            fids = [f.id() for f in self.lyr.getFeatures()]
            self._auto_populate_new(fids)
        except Exception as e:
            print(f"[PoleEditor] auto-refresh skipped: {e}")

    def showEvent(self, event):
        super().showEvent(event)
        QTimer.singleShot(0, self._snap_to_canvas_topleft)
        # Fill in attrs on any new/incomplete poles when the panel opens
        QTimer.singleShot(50, self._refresh_all_incomplete)

    def eventFilter(self, obj, event):
        if event.type() in (QEvent.Type.Resize, QEvent.Type.Move, QEvent.Type.Show):
            QTimer.singleShot(0, self._snap_to_canvas_topleft)
        return super().eventFilter(obj, event)

    def _teardown(self):
        """Finalize + clean up: run a last auto-populate pass, drop the canvas event
        filters, and stop/remove the rings + bands. Called when the host dock closes
        (or on unload). Idempotent + sip-guarded so it's safe to call more than once."""
        if getattr(self, '_torn_down', False):
            return
        self._torn_down = True
        from qgis.PyQt import sip
        try:
            self._refresh_all_incomplete()       # final auto-populate of marked poles
        except Exception:
            pass
        try:
            canvas = self.iface.mapCanvas()
            if sip.isdeleted(canvas):
                return
            canvas.removeEventFilter(self)
            canvas.viewport().removeEventFilter(self)
            scene = canvas.scene()
            for ring in (self._blue_band, self._yellow_band, self._red_band):
                ring.stop(); ring.clear()
                if scene is not None and isinstance(ring, QgsMapCanvasItem):
                    scene.removeItem(ring)
            self._fts_band.reset()
            self._s5_band.reset()
        except Exception:
            pass

    def closeEvent(self, event):
        self._teardown()
        super().closeEvent(event)


# ── Enclosure Editor panel ────────────────────────────────────────────────────
# claude:approved-destructive — writes only on explicit user button clicks; no bulk auto-run

class EnclosureEditorPanel(QWidget):
    """Floating panel for reclassifying enclosures on the canvas.

    Reads selected features from:
      - Enclosures Connectorised v1  (Distribution vs Spur Route)
      - Enclosures Splice v1         (UMJ/72F vs CMJ/144F)

    Use QGIS Select Features tool (S key) to click enclosures on the map,
    then click a type button to apply the canonical spec values.
    """

    _CONN_SPECS = {
        'distribution': {'spec_1': 'ODCFD0',       'cblcpty1': '24F', 'dim1': 'L220*W120*H73mm'},
        'spur':         {'spec_1': 'M16 Microloop', 'cblcpty1': '48F', 'dim1': 'H275*W160*D96mm'},
    }
    _SPLICE_SPECS = {
        'umj': {'spec_1': 'UMJ', 'cblcpty1': '72F',  'dim1': 'L250*W231*D164mm'},
        'cmj': {'spec_1': 'CMJ', 'cblcpty1': '144F', 'dim1': 'L290*W231*D164mm'},
    }

    def __init__(self, iface, parent=None):
        super().__init__(parent)                 # hosted in a _PanelDock (dockable)
        self.setObjectName('vfEncEditorPanel')
        self.iface = iface
        self.setWindowTitle('Enclosure Editor')
        self.setMinimumWidth(380)

        canvas = iface.mapCanvas()
        self._dist_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PointGeometry)
        self._dist_band.setColor(QColor(234, 115, 32, 210))
        self._dist_band.setIcon(QgsRubberBand.IconType.ICON_FULL_DIAMOND)
        self._dist_band.setIconSize(11)

        self._spur_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PointGeometry)
        self._spur_band.setColor(QColor(147, 51, 234, 210))
        self._spur_band.setIcon(QgsRubberBand.IconType.ICON_BOX)
        self._spur_band.setIconSize(13)

        self._umj_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PointGeometry)
        self._umj_band.setColor(QColor(8, 145, 178, 210))
        self._umj_band.setIcon(QgsRubberBand.IconType.ICON_CIRCLE)
        self._umj_band.setIconSize(11)

        self._cmj_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PointGeometry)
        self._cmj_band.setColor(QColor(34, 197, 94, 210))
        self._cmj_band.setIcon(QgsRubberBand.IconType.ICON_CIRCLE)
        self._cmj_band.setIconSize(13)

        # Cable route highlights — line rubber bands over Distribution Cable v1
        self._main_cable_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.LineGeometry)
        self._main_cable_band.setColor(QColor(56, 189, 248, 170))   # sky blue
        self._main_cable_band.setWidth(4)

        self._spur_cable_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.LineGeometry)
        self._spur_cable_band.setColor(QColor(234, 115, 32, 220))    # orange
        self._spur_cable_band.setWidth(4)

        # FTS splitter locations — large bright green diamonds
        self._fts_enc_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PointGeometry)
        self._fts_enc_band.setColor(QColor(34, 197, 94, 240))       # bright green fill
        self._fts_enc_band.setIcon(QgsRubberBand.IconType.ICON_FULL_DIAMOND)
        self._fts_enc_band.setIconSize(20)
        self._fts_enc_band.setWidth(4)                               # outline width
        self._fts_enc_band.setSecondaryStrokeColor(QColor(0, 60, 0, 255))  # dark border

        self._redraw_bands()
        self._redraw_cable_bands()

        canvas.installEventFilter(self)
        canvas.viewport().installEventFilter(self)

        self.setStyleSheet(f"QWidget#vfEncEditorPanel {{ background: {_BG}; }}")
        layout = QVBoxLayout(self)
        layout.setSpacing(8)
        layout.setContentsMargins(12, 12, 12, 12)

        # ── How to use ─────────────────────────────────────────────────────
        steps_frame = QFrame()
        steps_frame.setStyleSheet(
            f"QFrame {{ background: {_PANEL}; border-radius: 6px;"
            f" border: 1px solid {_BORDER}; }}")
        sl = QVBoxLayout(steps_frame)
        sl.setContentsMargins(10, 8, 10, 8)
        sl.setSpacing(3)
        how_lbl = QLabel("HOW TO USE")
        how_lbl.setStyleSheet(_SECTION_LBL)
        sl.addWidget(how_lbl)
        _step_ss = (f"QLabel {{ color: {_TEXT}; font-family: 'Segoe UI';"
                    f" font-size: 10px; }}")
        for step in (
            "1  Press S key, then click an enclosure on the map",
            "2  Shift+click to add more enclosures to the selection",
            "3  Click the correct type button below",
        ):
            lbl = QLabel(step)
            lbl.setStyleSheet(_step_ss)
            sl.addWidget(lbl)

        div = QFrame()
        div.setFrameShape(QFrame.Shape.HLine)
        div.setStyleSheet(f"QFrame {{ color: {_BORDER}; margin-top: 4px; }}")
        sl.addWidget(div)

        ovr_hdr = QLabel("CANVAS OVERLAY — Distribution cables")
        ovr_hdr.setStyleSheet(_SECTION_LBL)
        sl.addWidget(ovr_hdr)
        _ovr_ss = (f"QLabel {{ color: {_TEXT}; font-family: 'Segoe UI'; font-size: 9px; }}")
        for col, sym, desc in (
            ("#38bdf8", "━━━", "Main distribution route"),
            ("#ea7320", "━━━", "Spur cable (branches off main)"),
        ):
            row_lbl = QLabel(
                f'<span style="color:{col}; font-weight:900; font-size:13px">{sym}</span>'
                f'  {desc}')
            row_lbl.setStyleSheet(_ovr_ss)
            sl.addWidget(row_lbl)
        layout.addWidget(steps_frame)

        # ── Connectorised section ───────────────────────────────────────────
        _hdr_ss = (f"QLabel {{ color: {_TEXT}; font-family: 'Segoe UI';"
                   f" font-size: 10px; font-weight: 700; padding-top: 4px; }}")
        conn_hdr = QLabel(
            '<span style="color:#ea7320">◆</span>'
            ' <span style="color:#9333ea">■</span>'
            '  CONNECTORISED  —  Enclosures Connectorised v1')
        conn_hdr.setStyleSheet(_hdr_ss)
        layout.addWidget(conn_hdr)

        conn_leg = QLabel(
            '<span style="color:#ea7320">◆ orange diamond</span>'
            '  = Distribution   '
            '<span style="color:#9333ea">■ purple square</span>'
            '  = Spur Route')
        conn_leg.setStyleSheet(
            f"QLabel {{ color: {_DIM}; font-family: 'Segoe UI'; font-size: 9px; }}")
        layout.addWidget(conn_leg)

        def _tall_btn(base, extra=''):
            return (base.replace('min-height: 32px', 'min-height: 60px')
                       .replace('font-size: 11px', 'font-size: 10px') + extra)

        conn_row = QHBoxLayout()
        conn_row.setSpacing(8)
        btn_dist = QPushButton(
            '◆  DISTRIBUTION\nODCFD0  ·  24F  ·  6-8 drops\nAlong main distribution route')
        btn_dist.setStyleSheet(_tall_btn(_BTN_ORANGE))
        btn_dist.clicked.connect(self._set_distribution)
        conn_row.addWidget(btn_dist)
        btn_spur = QPushButton(
            '■  SPUR ROUTE\nM16 Microloop  ·  48F  ·  16 drops\nAt cable branch-off point only')
        btn_spur.setStyleSheet(_tall_btn(_BTN_PURPLE))
        btn_spur.clicked.connect(self._set_spur)
        conn_row.addWidget(btn_spur)
        layout.addLayout(conn_row)

        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet(_DIVIDER)
        layout.addWidget(line)

        # ── Splice section ──────────────────────────────────────────────────
        splice_hdr = QLabel(
            '<span style="color:#0891b2">●</span>'
            ' <span style="color:#22c55e">●</span>'
            '  SPLICE  —  Enclosures Splice v1  (feeder domes)')
        splice_hdr.setStyleSheet(_hdr_ss)
        layout.addWidget(splice_hdr)

        splice_leg = QLabel(
            '<span style="color:#0891b2">● cyan circle</span>'
            '  = Secondary feeder   '
            '<span style="color:#22c55e">● green circle</span>'
            '  = Primary feeder')
        splice_leg.setStyleSheet(
            f"QLabel {{ color: {_DIM}; font-family: 'Segoe UI'; font-size: 9px; }}")
        layout.addWidget(splice_leg)

        splice_row = QHBoxLayout()
        splice_row.setSpacing(8)
        btn_umj = QPushButton(
            '●  UMJ\n72F  ·  Secondary feeder\nAt secondary cable splice points')
        btn_umj.setStyleSheet(_tall_btn(_BTN_CYAN))
        btn_umj.clicked.connect(self._set_umj)
        splice_row.addWidget(btn_umj)
        btn_cmj = QPushButton(
            '●  CMJ\n144F  ·  Primary feeder\nAt primary cable splice points')
        btn_cmj.setStyleSheet(_tall_btn(_BTN_TEAL))
        btn_cmj.clicked.connect(self._set_cmj)
        splice_row.addWidget(btn_cmj)
        layout.addLayout(splice_row)

        # ── Summary + status ────────────────────────────────────────────────
        self._status_lbl = QLabel('')
        self._status_lbl.setWordWrap(True)
        self._status_lbl.setStyleSheet(_STATUS_LBL)
        layout.addWidget(self._status_lbl)

        self._summary_lbl = QLabel('')
        self._summary_lbl.setStyleSheet(_HINT_LBL)
        layout.addWidget(self._summary_lbl)

        self._update_summary()

    def _get_conn_lyr(self):
        return next((l for l in QgsProject.instance().mapLayers().values()
                     if l.name() == 'Enclosures Connectorised v1'), None)

    def _get_splice_lyr(self):
        return next((l for l in QgsProject.instance().mapLayers().values()
                     if l.name() == 'Enclosures Splice v1'), None)

    def _redraw_bands(self):
        conn_lyr   = self._get_conn_lyr()
        splice_lyr = self._get_splice_lyr()
        for band in (self._dist_band, self._spur_band,
                     self._umj_band, self._cmj_band,
                     self._fts_enc_band):
            band.reset(QgsWkbTypes.GeometryType.PointGeometry)
        fts_lyr = next((l for l in QgsProject.instance().mapLayers().values()
                        if l.name() == 'FTS Splitters v1'), None)
        if fts_lyr:
            for f in fts_lyr.getFeatures():
                g = f.geometry()
                if g and not g.isEmpty():
                    self._fts_enc_band.addGeometry(g, None)
        if conn_lyr:
            for f in conn_lyr.getFeatures():
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                if str(f['spec_1']) == 'M16 Microloop':
                    self._spur_band.addGeometry(g, None)
                else:
                    self._dist_band.addGeometry(g, None)
        if splice_lyr:
            for f in splice_lyr.getFeatures():
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                if str(f['spec_1']) == 'CMJ':
                    self._cmj_band.addGeometry(g, None)
                else:
                    self._umj_band.addGeometry(g, None)

    def _set_status(self, msg, colour='#e2e8f0'):
        self._status_lbl.setText(msg)
        self._status_lbl.setStyleSheet(
            f"QLabel {{ color: {colour}; font-family: Consolas; "
            f"font-size: 10px; padding: 2px; }}"
        )

    def _update_summary(self):
        parts = []
        conn_lyr = self._get_conn_lyr()
        if conn_lyr:
            feats  = list(conn_lyr.getFeatures())
            n_spur = sum(1 for f in feats if str(f['spec_1']) == 'M16 Microloop')
            parts.append(f'Conn: {len(feats) - n_spur} dist  {n_spur} spur')
        splice_lyr = self._get_splice_lyr()
        if splice_lyr:
            feats = list(splice_lyr.getFeatures())
            n_cmj = sum(1 for f in feats if str(f['spec_1']) == 'CMJ')
            parts.append(f'Splice: {len(feats) - n_cmj} UMJ  {n_cmj} CMJ')
        self._summary_lbl.setText('  |  '.join(parts))

    def _write_attrs(self, lyr, spec_vals):
        """Bulk-write spec_vals to all selected features in lyr."""
        if not lyr:
            return 0
        feats = lyr.selectedFeatures()
        if not feats:
            return 0
        flds    = lyr.fields()
        indices = {k: flds.indexOf(k) for k in spec_vals}
        writes  = {}
        for f in feats:
            row = {indices[k]: v for k, v in spec_vals.items() if indices[k] >= 0}
            if row:
                writes[f.id()] = row
        if writes:
            lyr.dataProvider().changeAttributeValues(writes)
            lyr.triggerRepaint()
        return len(writes)

    def _set_distribution(self):
        n = self._write_attrs(self._get_conn_lyr(), self._CONN_SPECS['distribution'])
        if n:
            self._redraw_bands(); self._update_summary()
            self._set_status(f'Changed {n}  Distribution (ODCFD0 / 24F)', '#ea7320')
        else:
            self._set_status(
                'No Connectorised enclosures selected.\n'
                'Use S key + click an orange/purple dot.', '#f59e0b')

    def _set_spur(self):
        n = self._write_attrs(self._get_conn_lyr(), self._CONN_SPECS['spur'])
        if n:
            self._redraw_bands(); self._update_summary()
            self._set_status(
                f'Changed {n}  Spur Route (M16 Microloop / 48F)', '#9333ea')
        else:
            self._set_status(
                'No Connectorised enclosures selected.\n'
                'Use S key + click an orange/purple dot.', '#f59e0b')

    def _set_umj(self):
        n = self._write_attrs(self._get_splice_lyr(), self._SPLICE_SPECS['umj'])
        if n:
            self._redraw_bands(); self._update_summary()
            self._set_status(f'Changed {n}  UMJ / 72F  (Secondary feeder)', '#0891b2')
        else:
            self._set_status(
                'No Splice enclosures selected.\n'
                'Use S key + click a cyan/green dot.', '#f59e0b')

    def _set_cmj(self):
        n = self._write_attrs(self._get_splice_lyr(), self._SPLICE_SPECS['cmj'])
        if n:
            self._redraw_bands(); self._update_summary()
            self._set_status(f'Changed {n}  CMJ / 144F  (Primary feeder)', '#22c55e')
        else:
            self._set_status(
                'No Splice enclosures selected.\n'
                'Use S key + click a cyan/green dot.', '#f59e0b')

    def _snap_to_canvas_topleft(self):
        canvas = self.iface.mapCanvas()
        tl = canvas.viewport().mapToGlobal(canvas.viewport().rect().topLeft())
        self.move(tl.x() + 8, tl.y() + 8)

    def showEvent(self, event):
        super().showEvent(event)
        QTimer.singleShot(0, self._snap_to_canvas_topleft)

    def eventFilter(self, obj, event):
        if event.type() in (QEvent.Type.Resize, QEvent.Type.Move, QEvent.Type.Show):
            QTimer.singleShot(0, self._snap_to_canvas_topleft)
        return super().eventFilter(obj, event)

    def _get_dist_lyr(self):
        return next((l for l in QgsProject.instance().mapLayers().values()
                     if l.name() == 'Distribution Cable v1'), None)

    def _classify_cables(self):
        """Return (main_fids, spur_fids) for Distribution Cable v1.

        Algorithm:
          1. Seed: cables whose endpoint is within FTS_SNAP of an FTS Splitter v1
          2. Network BFS: expand through connected cables (endpoints within VERTEX_SNAP)
             - Only propagate along a cable if its far end has degree >= 2 (not a dead-end)
             - If both ends of a cable are already visited (loop), always add as main
          3. Main = everything reachable; Spur = unreachable dead-end branches
        """
        from qgis.core import QgsPointXY, QgsGeometry
        dist_lyr = self._get_dist_lyr()
        fts_lyr  = next((l for l in QgsProject.instance().mapLayers().values()
                         if l.name() == 'FTS Splitters v1'), None)
        if not dist_lyr:
            return set(), set()

        FTS_SNAP    = 12.0 / 111320.0  # 12 m — cable endpoint at FTS pole
        VERTEX_SNAP = 6.0  / 111320.0  # 6 m  — shared cable endpoint (connected)

        # --- collect cable endpoints ---
        cable_pts = {}   # fid -> (start_QgsPointXY, end_QgsPointXY)
        for cable in dist_lyr.getFeatures():
            g = cable.geometry()
            if not g or g.isEmpty():
                continue
            verts = (g.asPolyline() if not g.isMultipart()
                     else [v for part in g.asMultiPolyline() for v in part])
            if len(verts) < 2:
                continue
            cable_pts[cable.id()] = (QgsPointXY(verts[0]), QgsPointXY(verts[-1]))

        # No FTS Splitters layer → we have no seed for the backbone walk. Without
        # this guard near_fts() is always False, no cable is seeded, and EVERY
        # cable would be mis-classified as a spur. Safe fallback: treat all as main.
        if fts_lyr is None:
            return set(cable_pts.keys()), set()

        # --- quantize endpoints into node keys ---
        def node_key(pt):
            return (round(pt.x() / VERTEX_SNAP), round(pt.y() / VERTEX_SNAP))

        node_cables = {}   # node_key -> set of fids touching that node
        cable_nodes = {}   # fid -> (node_start, node_end)
        for fid, (s, e) in cable_pts.items():
            ns, ne = node_key(s), node_key(e)
            cable_nodes[fid] = (ns, ne)
            node_cables.setdefault(ns, set()).add(fid)
            node_cables.setdefault(ne, set()).add(fid)

        # --- find FTS-attached nodes ---
        fts_geoms = []
        if fts_lyr:
            for f in fts_lyr.getFeatures():
                if f.hasGeometry():
                    fts_geoms.append(f.geometry())

        def near_fts(pt):
            g = QgsGeometry.fromPointXY(pt)
            return any(g.distance(fg) <= FTS_SNAP for fg in fts_geoms)

        fts_nodes = set()
        for fid, (s, e) in cable_pts.items():
            ns, ne = cable_nodes[fid]
            if near_fts(s):
                fts_nodes.add(ns)
            if near_fts(e):
                fts_nodes.add(ne)

        # --- seed: cables with an endpoint at an FTS node ---
        main_fids = set()
        visited_nodes = set(fts_nodes)
        for fid, (ns, ne) in cable_nodes.items():
            if ns in fts_nodes or ne in fts_nodes:
                main_fids.add(fid)
                visited_nodes.add(ns)
                visited_nodes.add(ne)

        # --- BFS: propagate main status through the backbone ---
        changed = True
        while changed:
            changed = False
            for fid, (ns, ne) in cable_nodes.items():
                if fid in main_fids:
                    continue
                s_vis = ns in visited_nodes
                e_vis = ne in visited_nodes
                if not s_vis and not e_vis:
                    continue
                if s_vis and e_vis:
                    # Cable connects two already-visited nodes (closes a loop) → main
                    main_fids.add(fid)
                    changed = True
                    continue
                # One end visited, one end not: only extend if far end is not a dead-end
                far_node = ne if s_vis else ns
                if len(node_cables.get(far_node, set())) >= 2:
                    main_fids.add(fid)
                    visited_nodes.add(far_node)
                    changed = True

        spur_fids = set(cable_pts.keys()) - main_fids
        return main_fids, spur_fids

    def _redraw_cable_bands(self):
        self._main_cable_band.reset(QgsWkbTypes.GeometryType.LineGeometry)
        self._spur_cable_band.reset(QgsWkbTypes.GeometryType.LineGeometry)
        dist_lyr = self._get_dist_lyr()
        if not dist_lyr:
            return
        main_fids, spur_fids = self._classify_cables()
        crs = dist_lyr.crs()
        for cable in dist_lyr.getFeatures():
            g = cable.geometry()
            if not g or g.isEmpty():
                continue
            if cable.id() in spur_fids:
                self._spur_cable_band.addGeometry(g, crs)
            else:
                self._main_cable_band.addGeometry(g, crs)

    def _teardown(self):
        """Drop the canvas event filters + reset/remove all rubber bands. Called when
        the host dock closes (or on unload). Idempotent + sip-guarded."""
        if getattr(self, '_torn_down', False):
            return
        self._torn_down = True
        from qgis.PyQt import sip
        try:
            canvas = self.iface.mapCanvas()
            if sip.isdeleted(canvas):
                return
            canvas.removeEventFilter(self)
            canvas.viewport().removeEventFilter(self)
            scene = canvas.scene()
            for band in (self._dist_band, self._spur_band,
                         self._umj_band, self._cmj_band,
                         self._main_cable_band, self._spur_cable_band,
                         self._fts_enc_band):
                band.reset()
                try:
                    scene.removeItem(band)
                except Exception:
                    pass
            # Clear any lingering q.py test rubber bands on the iface namespace
            for b in getattr(self.iface, '_spur_check_bands', []):
                try:
                    b.reset(); scene.removeItem(b)
                except Exception:
                    pass
            self.iface._spur_check_bands = []
            canvas.refresh()
        except Exception:
            pass

    def closeEvent(self, event):
        self._teardown()
        super().closeEvent(event)
