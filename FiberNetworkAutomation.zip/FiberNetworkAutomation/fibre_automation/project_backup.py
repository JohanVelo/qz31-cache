"""project_backup — one-click zip backup of every file-based layer + the project file.

JJ's standing rule: back up all shapefiles before any destructive operation. This zips each
layer's source (shapefiles incl. ALL sidecars: .dbf/.shx/.prj/.cpg/…, GeoPackages, CSVs) plus
the .qgz/.qgs project file into one timestamped archive. Read-only; pure stdlib — zero deps.

API:  backup_project(project, out_path, feedback=None) -> {"files":n,"bytes":n,"path":..,"ok":bool}
"""
import os
import zipfile

# Every sidecar a shapefile can carry — miss one and the backup is silently corrupt.
# These are appended to the basename WITHOUT ".shp", so both spellings are needed:
# GDAL writes "X.shp.aux.xml", QGIS/ESRI also produce "X.aux.xml".
_SHP_SIDECARS = (".shp", ".dbf", ".shx", ".prj", ".cpg", ".qpj", ".qix",
                 ".sbn", ".sbx", ".shp.xml", ".aux.xml", ".shp.aux.xml",
                 ".qml", ".qlr")


def collect_sources(project):
    """Set of on-disk files backing the project's layers + the project file itself."""
    files = set()
    pf = project.fileName()
    if pf and os.path.isfile(pf):
        files.add(pf)
    for lyr in project.mapLayers().values():
        try:
            src = lyr.source().split("|")[0]      # strip |layername=, |layerid=, …
        except Exception:
            continue
        if not src or not os.path.isfile(src):     # skip memory/remote/db layers
            continue
        files.add(src)
        low = src.lower()
        if low.endswith(".shp"):
            base = src[:-4]
            for ext in _SHP_SIDECARS:
                cand = base + ext
                if os.path.exists(cand):
                    files.add(cand)
    return files


def backup_project(project, out_path, feedback=None):
    files = sorted(collect_sources(project))
    if not files:
        return {"files": 0, "bytes": 0, "path": out_path, "ok": False,
                "msg": "no file-based layers to back up (memory/remote layers are skipped)"}
    if not out_path.lower().endswith(".zip"):
        out_path += ".zip"
    seen, total, n = {}, 0, 0
    failed = []
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        for i, f in enumerate(files):
            arc = os.path.basename(f)
            # disambiguate same-named files from different folders by prefixing the parent
            if arc in seen and seen[arc] != f:
                arc = os.path.join(os.path.basename(os.path.dirname(f)), arc)
            # keep disambiguating with a numeric suffix until the arc is unique —
            # 3+ files sharing basename AND parent-folder name would otherwise collide
            # and silently overwrite each other inside the zip (data loss)
            if arc in seen and seen[arc] != f:
                root, ext = os.path.splitext(arc)
                counter = 1
                while arc in seen and seen[arc] != f:
                    arc = f"{root}_{counter}{ext}"
                    counter += 1
            seen[arc] = f
            try:
                z.write(f, arc)
                total += os.path.getsize(f)
                n += 1
            except Exception as exc:
                # A dropped file must NEVER pass as success. Restoring a shapefile
                # whose .dbf went missing yields a layer that opens with the right
                # feature count and geometry and SILENTLY no attributes — the worst
                # way for a safety net to fail. Record it and fail the whole backup.
                failed.append("%s (%s)" % (os.path.basename(f), type(exc).__name__))
                continue
            if feedback is not None:
                try:
                    feedback.setProgress(int((i + 1) / len(files) * 100))
                except Exception:
                    pass
    if failed:
        msg = "backup INCOMPLETE — %d of %d file(s) could not be written: %s%s. " \
              "Do not rely on this archive." % (
                  len(failed), len(files), ", ".join(failed[:5]),
                  "" if len(failed) <= 5 else " (+%d more)" % (len(failed) - 5))
    elif n == 0:
        msg = "all file writes failed — backup zip is empty"
    else:
        msg = None
    return {"files": n, "bytes": total, "path": out_path,
            "ok": n > 0 and not failed, "failed": failed, "msg": msg}
