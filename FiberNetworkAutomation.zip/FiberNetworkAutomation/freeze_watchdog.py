"""freeze_watchdog — detect when the QGIS GUI (Qt main) thread is blocked and
capture WHAT froze it, so intermittent "QGIS keeps hanging" reports become hard
data instead of guesswork (e.g. a hang after an autonet / Network-Planner run).

How it works (proven pattern — same as NVDA's watchdog):
  * A 1-second QTimer on the MAIN thread stamps a monotonic "last alive" time.
    If the event loop is responsive the stamp stays fresh; if the main thread is
    blocked in a long synchronous operation the timer can't fire and the stamp
    goes stale.
  * A daemon thread wakes every 0.5 s and, if the stamp is stale beyond a
    threshold, it's a freeze. The daemon captures the MAIN thread's Python stack
    with sys._current_frames() (GIL-safe, no Qt) — that stack is the culprit.

Critical design points for this plugin:
  * The freeze is DETECTED on the daemon thread, but REPORTING goes through Qt
    networking (telemetry → Supabase) which is main-thread-only — and the main
    thread is frozen at detection time. So the daemon only CAPTURES + BUFFERS;
    the main-thread heartbeat DRAINS the buffer and reports once the UI is
    responsive again. That also yields the accurate TOTAL freeze duration.
  * The daemon touches ONLY pure-Python (time, sys, traceback, hashlib) — never
    Qt, never iface, never layers — so it is GIL-safe and cannot crash QGIS.
  * Modal dialogs run a nested event loop, so the heartbeat keeps firing during
    them → they never false-trigger. Only genuine main-thread blocking is
    flagged, which is exactly what we want.
  * Dedup by stack fingerprint + cooldown so a repeating freeze can't spam.
  * Degrade-not-crash everywhere; clean shutdown on plugin unload.
"""
import hashlib
import os
import re
import sys
import threading
import time
import traceback

_HOME = os.path.expanduser("~")
_PATH_RE = re.compile(r"(?:[A-Za-z]:\\|/home/|/Users/|/mnt/|\\\\)[^\s'\"]+")


class FreezeWatchdog:
    """Start with start(report_cb); report_cb(record: dict) is called ON THE
    MAIN THREAD for each finished freeze. `record` keys: duration_ms, severity,
    stack_text, fingerprint, started_iso."""

    HEARTBEAT_MS = 1000        # main-thread liveness stamp
    CHECK_INTERVAL = 0.5       # daemon poll
    FREEZE_THRESHOLD = 3.0     # seconds blocked before it counts as a freeze
    FROZEN_THRESHOLD = 8.0     # >= this is reported as "frozen" (vs "slow")
    GRACE_S = 6.0              # ignore the first N s (plugin/QGIS startup)
    COOLDOWN_S = 60.0          # min seconds between reports of the same fingerprint

    def __init__(self):
        self._main_id = threading.main_thread().ident
        self._last_alive = time.monotonic()
        self._start_mono = time.monotonic()
        self._stop = threading.Event()
        self._thread = None
        self._timer = None
        self._lock = threading.Lock()
        self._pending = []                 # finished freezes awaiting main-thread report
        self._seen = {}                    # fingerprint -> last_reported_monotonic
        self._report_cb = None
        # in-progress freeze state (daemon-owned)
        self._fz_active = False
        self._fz_max = 0.0
        self._fz_stack = ""
        self._fz_fp = ""
        self._fz_started = 0.0

    # ── lifecycle ────────────────────────────────────────────────────────────
    def start(self, main_window, report_cb):
        self._report_cb = report_cb
        try:
            from qgis.PyQt.QtCore import QTimer
            self._timer = QTimer(main_window)
            self._timer.setInterval(self.HEARTBEAT_MS)
            self._timer.timeout.connect(self._on_heartbeat)
            self._timer.start()
        except Exception:
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._monitor, name="VFFreezeWatchdog", daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        try:
            if self._timer is not None:
                self._timer.stop()
                self._timer.deleteLater()
        except Exception:
            pass
        self._timer = None
        t = self._thread
        if t is not None:
            try:
                t.join(timeout=2.0)
            except Exception:
                pass
        self._thread = None

    # ── main thread: liveness stamp + report drain ─────────────────────────────
    def _on_heartbeat(self):
        # If we're here, the event loop is responsive → stamp + flush any freezes
        # the daemon captured while we were blocked.
        self._last_alive = time.monotonic()
        drained = None
        with self._lock:
            if self._pending:
                drained = self._pending
                self._pending = []
        if drained and callable(self._report_cb):
            for rec in drained:
                try:
                    self._report_cb(rec)
                except Exception:
                    pass

    # ── daemon thread: detect freezes (pure-Python only, never Qt) ─────────────
    def _monitor(self):
        while not self._stop.wait(self.CHECK_INTERVAL):
            try:
                self._check()
            except Exception:
                pass

    def _check(self):
        now = time.monotonic()
        if now - self._start_mono < self.GRACE_S:
            return
        stale = now - self._last_alive
        if stale >= self.FREEZE_THRESHOLD:
            # main thread is currently blocked
            if not self._fz_active:
                self._fz_active = True
                self._fz_started = time.time()        # wall-clock start (for the record)
                self._fz_fp = ""
            self._fz_max = stale
            # (re)capture the stuck stack — keep the latest sample
            txt, fp = self._capture_main_stack()
            if txt:
                self._fz_stack = txt
                self._fz_fp = fp
        elif self._fz_active:
            # main thread just recovered → finalize this freeze
            self._finalize()

    def _finalize(self):
        dur = self._fz_max
        fp = self._fz_fp or "unknown"
        self._fz_active = False
        # dedup + cooldown
        now = time.monotonic()
        last = self._seen.get(fp, 0.0)
        if last and now - last < self.COOLDOWN_S:
            return
        self._seen[fp] = now
        if len(self._seen) > 200:
            self._seen.clear()
            self._seen[fp] = now
        rec = {
            "duration_ms": int(dur * 1000),
            "severity": "frozen" if dur >= self.FROZEN_THRESHOLD else "slow",
            "stack_text": self._fz_stack or "<no stack captured>",
            "fingerprint": fp,
            "started_iso": _iso(self._fz_started),
        }
        with self._lock:
            self._pending.append(rec)
            if len(self._pending) > 50:
                self._pending = self._pending[-50:]

    def _capture_main_stack(self):
        """Top frames of the MAIN thread, scrubbed, + a fingerprint of the top 3
        (file:line). Pure-Python — safe from the daemon thread (GIL-protected)."""
        try:
            frame = sys._current_frames().get(self._main_id)
            if frame is None:
                return "", ""
            stack = traceback.extract_stack(frame)
        except Exception:
            return "", ""
        top = stack[-12:]
        lines = []
        for fr in top:
            fn = _scrub(fr.filename)
            lines.append(f'  File "{fn}", line {fr.lineno}, in {fr.name}\n'
                         f'    {(fr.line or "").strip()}')
        text = "\n".join(lines)
        fp_src = "|".join(f"{os.path.basename(fr.filename)}:{fr.lineno}:{fr.name}"
                          for fr in stack[-3:])
        fp = hashlib.sha1(fp_src.encode("utf-8", "replace")).hexdigest()[:12]
        return text, fp


def _scrub(text):
    if not text:
        return text
    try:
        text = text.replace(_HOME, "<user>")
        text = _PATH_RE.sub(lambda m: "<path>/" + os.path.basename(m.group(0)), text)
    except Exception:
        pass
    return text


def _iso(epoch):
    try:
        import datetime
        return datetime.datetime.fromtimestamp(
            epoch, datetime.timezone.utc).isoformat()
    except Exception:
        return ""
