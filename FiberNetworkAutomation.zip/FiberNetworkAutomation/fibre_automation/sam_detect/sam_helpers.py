"""sam_helpers — image/mask utilities for the SAM detect worker.

Runs OUTSIDE QGIS (venv subprocess). No qgis imports allowed here.
Validated on the Mohadin full-AOI runs (sam_masker v5/v6).
"""
from __future__ import annotations

import math
import os

import numpy as np

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass


def load_image(path: str) -> np.ndarray:
    from PIL import Image
    return np.asarray(Image.open(path).convert("RGB"), dtype=np.uint8)


def clahe_enhance(img, clip_limit=2.0, grid=8):
    """CLAHE on the LAB L-channel. Sharpens low-contrast roof edges under
    tree shadow. Falls back to the input unchanged if cv2 is unavailable."""
    try:
        import cv2
    except Exception:
        return img
    rgb = img.astype(np.uint8)
    lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB)
    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=(grid, grid))
    lab[:, :, 0] = clahe.apply(lab[:, :, 0])
    return cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)


def split_touching_roofs(mask, min_size_m2=20.0, gsd=0.25):
    """Marker-controlled watershed split. Returns a LIST of component masks.
    A single SAM blob that merged two adjacent roofs is split at the valley
    between distance-transform peaks. Only splits when >=2 roof-sized peaks
    exist, so a single complex roof is NOT over-split."""
    m = (mask > 0).astype(np.uint8)
    min_px = max(1, int(min_size_m2 / (gsd ** 2)))
    if m.sum() < 2 * min_px:
        return [m]
    try:
        from scipy import ndimage
        from skimage.feature import peak_local_max
        from skimage.segmentation import watershed
    except Exception:
        return [m]
    dist = ndimage.distance_transform_edt(m)
    if dist.max() <= 0:
        return [m]
    min_dist = max(3, int(math.sqrt(min_px) * 0.5))
    coords = peak_local_max(dist, min_distance=min_dist,
                            labels=m.astype(bool),
                            threshold_abs=float(dist.max()) * 0.3)
    if len(coords) <= 1:
        return [m]
    markers = np.zeros(m.shape, dtype=np.int32)
    for k, (yy, xx) in enumerate(coords, start=1):
        markers[yy, xx] = k
    markers, _ = ndimage.label(markers > 0)
    labels = watershed(-dist, markers, mask=m.astype(bool))
    out = []
    for lab_id in range(1, int(labels.max()) + 1):
        comp = (labels == lab_id).astype(np.uint8)
        if comp.sum() >= min_px:
            out.append(comp)
    return out if len(out) >= 2 else [m]


def autocast_ctx(device):
    """bf16 autocast on CUDA (halves VRAM); a no-op context on CPU."""
    import contextlib
    import torch
    if str(device).startswith("cuda"):
        return torch.autocast("cuda", dtype=torch.bfloat16)
    return contextlib.nullcontext()


def resolve_device(prefer="auto"):
    """'auto' uses CUDA if available, else CPU."""
    if prefer == "cpu":
        os.environ["CUDA_VISIBLE_DEVICES"] = ""
        return "cpu"
    try:
        import torch
        if prefer in ("auto", "cuda") and torch.cuda.is_available():
            return "cuda"
    except Exception:
        _swallowed_note()
    os.environ.setdefault("CUDA_VISIBLE_DEVICES", "")
    return "cpu"


def refine_mask(mask, fill_holes=True, min_area_px=50):
    m = (mask > 0).astype(np.uint8)
    try:
        from scipy import ndimage
        if fill_holes:
            m = ndimage.binary_fill_holes(m).astype(np.uint8)
        if min_area_px > 0:
            lbl, n = ndimage.label(m)
            if n:
                sizes = np.bincount(lbl.ravel())
                keep = sizes >= min_area_px
                keep[0] = False
                m = keep[lbl].astype(np.uint8)
    except ImportError:
        pass
    return m


def mask_to_polygon(mask, transform, simplify_m=0.0):
    """Union all shapes in a (single-building) mask into one shapely polygon."""
    from rasterio.features import shapes as rio_shapes
    from shapely.geometry import shape as shp_shape
    from shapely.ops import unary_union

    m = mask.astype(np.uint8)
    if m.sum() == 0:
        return None
    geoms = []
    for geom, val in rio_shapes(m, mask=m > 0, connectivity=4,
                                transform=transform):
        if val == 0:
            continue
        g = shp_shape(geom)
        if not g.is_valid:
            g = g.buffer(0)
        if not g.is_empty:
            geoms.append(g)
    if not geoms:
        return None
    u = unary_union(geoms)
    if simplify_m > 0:
        u = u.simplify(simplify_m, preserve_topology=True)
    if not u.is_valid:
        u = u.buffer(0)
    return None if u.is_empty else u


def mask_spectral_ok(rgb, mask, exg_veg=0.08, y_shadow=70.0):
    """True if the pixels under `mask` look like a ROOF, not vegetation/shadow.
    A positive SAM point-prompt on a vacant stand often returns a compact tree
    crown or a shadow that passes the shape gate; this rejects those on colour.
    Sample the RAW (pre-CLAHE) RGB: excess-green ExG = 2g-r-b (normalised) high
    ⇒ vegetation; luminance Y low ⇒ shadow. Ported from erven_mcp
    `_filter_vegetation` (validated). Non-fatal → True if it can't sample."""
    try:
        m = mask > 0
        if not m.any():
            return False
        px = rgb[m].astype(np.float32)
        r, g, b = px[:, 0] / 255.0, px[:, 1] / 255.0, px[:, 2] / 255.0
        exg = float(np.mean(2.0 * g - r - b))
        y = float(np.mean(0.299 * px[:, 0] + 0.587 * px[:, 1] + 0.114 * px[:, 2]))
        if exg > exg_veg:            # green canopy
            return False
        if y < y_shadow:             # deep shadow / very dark
            return False
        return True
    except Exception:
        return True


def building_like(geom, area_m2, amin=10.0, amax=300.0):
    """Strict "is this actually a building?" gate for RESCUED / gap-filled
    candidates (NOT the box-prompt primary — that stays pristine). A positive
    point prompt on a vacant stand still returns *some* SAM mask (bare ground,
    a tree, the whole yard); this rejects those so a genuinely vacant erf is
    never falsely marked occupied. Ported from erven_mcp `_building_like`
    (validated 2026-05-29): area 10-300 m2, solidity >= 0.60, MRR aspect <= 3,
    compactness >= 0.35. Ratios are scale-invariant so geom CRS units are fine;
    area_m2 is the already-deflated metric area."""
    if geom is None or geom.is_empty:
        return False
    if not (amin <= area_m2 <= amax):
        return False
    hull = geom.convex_hull.area
    if hull <= 0 or geom.area / hull < 0.60:
        return False
    mrr = geom.minimum_rotated_rectangle
    if mrr.geom_type != "Polygon" or mrr.area <= 0:
        return False
    cc = list(mrr.exterior.coords)
    sides = [math.hypot(cc[i][0] - cc[i + 1][0], cc[i][1] - cc[i + 1][1])
             for i in range(min(4, len(cc) - 1))]
    if sides and min(sides) > 0 and max(sides) / min(sides) > 3.0:
        return False
    per = geom.length
    if per > 0 and (4 * math.pi * geom.area / (per * per)) < 0.35:
        return False
    return True


def classify_shape(geom, area_m2):
    """Shape category from geometry (3857 units, area already deflated).
    Returns (category, rect_ratio, aspect, corners). Tuned on Mohadin."""
    mrr = geom.minimum_rotated_rectangle
    if mrr.geom_type != "Polygon" or mrr.area <= 0:
        # Degenerate (near-collinear/sliver) input: MRR is a LineString/Point
        # with no .exterior. Classify as complex instead of crashing.
        return "complex", 0.0, 99.0, 99
    rect_ratio = geom.area / mrr.area
    xs, ys = mrr.exterior.coords.xy
    e1 = math.hypot(xs[1] - xs[0], ys[1] - ys[0])
    e2 = math.hypot(xs[2] - xs[1], ys[2] - ys[1])
    long_e, short_e = max(e1, e2), max(min(e1, e2), 0.01)
    aspect = long_e / short_e
    simp = geom.simplify(1.0)
    corners = len(simp.exterior.coords) - 1 if simp.geom_type == "Polygon" else 99
    if area_m2 < 35:
        cat = "shack"
    elif rect_ratio >= 0.88 and aspect <= 1.3:
        cat = "square"
    elif rect_ratio >= 0.88:
        cat = "rectangle"
    elif rect_ratio >= 0.65 and corners <= 8:
        cat = "L-shape"
    else:
        cat = "complex"
    return cat, round(rect_ratio, 3), round(aspect, 2), corners
