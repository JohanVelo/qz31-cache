"""Vuma Step 1b — Fetch CSG erven + Overture buildings for the project AOI.

Smart re-run behaviour:
  - Erven already populated  → skip CSG fetch
  - Buildings already loaded → skip Overture fetch
  - Both already present     → skip all downloads, run cleanup only
  - Always runs one-per-erven cleanup to ensure is_primary is correct

Downloads run via QgsTask (background thread) — bridge stays online during fetch.
"""

# claude:approved-destructive  (only modifies is_primary on freshly-loaded buildings)

import json
import subprocess
from pathlib import Path

from qgis.core import (
    QgsApplication,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsProject,
    QgsSpatialIndex,
    QgsTask,
    QgsVectorLayer,
)
from qgis.utils import iface

WORKER = str(Path(__file__).parent / "_fetch_worker.py")
CFG_FILE = r"C:/Temp/_vuma_fetch_cfg.json"
ERVEN_OUT = r"C:/Temp/vuma_erven.geojson"
BUILDINGS_OUT = r"C:/Temp/vuma_buildings.geojson"
RAMP_CENTROIDS_OUT = Path(r"C:/Temp/vuma_ramp_centroids.geojson")
CREATE_NO_WINDOW = 0x08000000


def _get_python() -> str:
    """Return path to a Python executable that has geopandas + overturemaps.

    Priority:
      1. A dedicated venv at ~/.qgis-venv (JJ's setup — fastest if present)
      2. QGIS's own sys.executable (works on any machine)

    If neither has the required packages, auto-installs them into QGIS Python.
    Result is cached in module state after the first successful call.
    """
    import os
    import sys

    if _get_python._cache:
        return _get_python._cache[0]

    # vf_paths.python_exe resolves the REAL interpreter — inside QGIS on
    # Windows sys.executable is qgis-bin.exe and would open a new QGIS window
    try:
        from ..shared.vf_paths import python_exe as _vf_py
    except ImportError:
        try:
            from fibre_automation.shared.vf_paths import python_exe as _vf_py
        except ImportError:
            _vf_py = None

    candidates = [
        # dedicated venv takes priority — already has all deps pre-installed
        os.path.expanduser("~/.qgis-venv/Scripts/python.exe"),
        os.path.expanduser("~/.qgis-venv/bin/python"),
    ]
    if _vf_py is not None:
        candidates.append(_vf_py())
    if sys.executable.lower().endswith("python.exe"):
        candidates.append(sys.executable)

    for py in candidates:
        if not os.path.exists(py):
            continue
        try:
            result = subprocess.run(
                [py, "-c", "import geopandas, overturemaps"],
                capture_output=True, timeout=15,
            )
            if result.returncode == 0:
                _get_python._cache.append(py)
                return py
        except Exception:
            continue

    # Fall back to QGIS Python and auto-install missing packages
    py = _vf_py() if _vf_py is not None else (
        sys.executable if sys.executable.lower().endswith("python.exe")
        else os.path.join(sys.exec_prefix, "python.exe"))
    print("  ⚙  First-time setup: installing geopandas + overturemaps into QGIS Python …")
    print("     (this happens once per machine and may take a few minutes)")
    subprocess.run(
        [py, "-m", "pip", "install", "geopandas", "overturemaps", "--quiet", "--user"],
        timeout=600, check=False,
    )
    _get_python._cache.append(py)
    return py


_get_python._cache = []  # type: ignore[attr-defined]

# Module-level reference prevents Python GC from collecting running QgsTasks
_active_tasks: list = []


def _get_layer(name):
    lyrs = QgsProject.instance().mapLayersByName(name)
    return lyrs[0] if lyrs else None


def _get_aoi_bbox_4326():
    lyr = _get_layer("P2 AOI Poly")
    if not lyr or lyr.featureCount() == 0:
        return None
    lyr.updateExtents()  # refresh cache after addFeatures()
    ext = lyr.extent()
    src_crs = lyr.crs()
    wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
    if src_crs != wgs84:
        xform = QgsCoordinateTransform(src_crs, wgs84, QgsProject.instance())
        ext = xform.transformBoundingBox(ext)
    return [ext.xMinimum(), ext.yMinimum(), ext.xMaximum(), ext.yMaximum()]


def _get_aoi_geojson() -> str | None:
    """Export P2 AOI Poly features as a GeoJSON string (WGS84) for the worker."""
    lyr = _get_layer("P2 AOI Poly")
    if not lyr or lyr.featureCount() == 0:
        return None
    src_crs = lyr.crs()
    wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
    xform = (QgsCoordinateTransform(src_crs, wgs84, QgsProject.instance())
             if src_crs != wgs84 else None)
    feats = []
    for feat in lyr.getFeatures():
        geom = feat.geometry()
        if geom.isEmpty():
            continue
        if xform:
            geom.transform(xform)
        feats.append(geom.asJson())
    if not feats:
        return None
    # Return as a FeatureCollection so the worker handles multi-polygon AOIs
    fc_geoms = ",".join(
        f'{{"type":"Feature","geometry":{g},"properties":{{}}}}' for g in feats
    )
    return f'{{"type":"FeatureCollection","features":[{fc_geoms}]}}'


def _enforce_one_per_erven(erven_lyr, bld_lyr):
    """Ensure each erven has exactly one is_primary=1 building (the largest).
    Buildings outside all erven parcels keep is_primary=1.
    """
    prim_idx = bld_lyr.fields().indexOf("is_primary")
    area_idx = bld_lyr.fields().indexOf("area_m2")
    if prim_idx < 0:
        print("  ! Buildings layer missing 'is_primary' field — skipping cleanup")
        return 0

    bld_feats = {f.id(): f for f in bld_lyr.getFeatures()}
    if not bld_feats:
        return 0

    bld_index = QgsSpatialIndex()
    for f in bld_feats.values():
        bld_index.addFeature(f)

    assigned = set()
    attr_changes = {}

    for erven_feat in erven_lyr.getFeatures():
        erven_geom = erven_feat.geometry()
        if not erven_geom or erven_geom.isEmpty():
            continue
        candidates = bld_index.intersects(erven_geom.boundingBox())
        inside = []
        for fid in candidates:
            bgeom = bld_feats[fid].geometry()
            if erven_geom.intersects(bgeom):
                area = bld_feats[fid][area_idx] if area_idx >= 0 else bgeom.area()
                inside.append((fid, float(area or 0)))
        if not inside:
            continue
        assigned.update(fid for fid, _ in inside)
        if len(inside) == 1:
            attr_changes[inside[0][0]] = {prim_idx: 1}
        else:
            inside.sort(key=lambda x: x[1], reverse=True)
            attr_changes[inside[0][0]] = {prim_idx: 1}
            for fid, _ in inside[1:]:
                attr_changes[fid] = {prim_idx: 0}

    for fid in bld_feats:
        if fid not in assigned and fid not in attr_changes:
            attr_changes[fid] = {prim_idx: 1}

    if attr_changes:
        BATCH = 2000
        items = list(attr_changes.items())
        for i in range(0, len(items), BATCH):
            bld_lyr.dataProvider().changeAttributeValues(  # claude:approved-destructive
                dict(items[i:i + BATCH])
            )

    # Delete non-primary buildings so only one footprint shows per erven
    to_delete = [fid for fid, attrs in attr_changes.items() if attrs.get(prim_idx) == 0]
    if to_delete:
        BATCH = 2000
        for i in range(0, len(to_delete), BATCH):
            bld_lyr.dataProvider().deleteFeatures(to_delete[i:i + BATCH])  # claude:approved-destructive
        print(f"  ✓ Removed {len(to_delete):,} secondary buildings (outbuildings/garages)")

    bld_lyr.updateExtents()
    bld_lyr.triggerRepaint()

    primary_count = sum(1 for v in attr_changes.values() if v.get(prim_idx) == 1)
    print(f"  ✓ One-per-erven: {primary_count:,} primary / {len(bld_feats):,} total buildings")
    return primary_count


def _load_geojson_into_layer(geojson_path, layer_name, field_map):
    target = _get_layer(layer_name)
    if not target:
        print(f"  ✗ Layer '{layer_name}' not found — run Step 1 first.")
        return 0
    src = QgsVectorLayer(geojson_path, "_tmp", "ogr")
    if not src.isValid():
        print(f"  ✗ Could not read {geojson_path}")
        return 0
    fields = target.fields()
    src_crs, dst_crs = src.crs(), target.crs()
    xform = (QgsCoordinateTransform(src_crs, dst_crs, QgsProject.instance())
             if src_crs != dst_crs else None)
    new_feats = []
    for feat in src.getFeatures():
        geom = feat.geometry()
        if geom.isEmpty():
            continue
        if xform:
            geom.transform(xform)
        nf = QgsFeature(fields)
        nf.setGeometry(geom)
        for src_fld, dst_fld in field_map.items():
            idx = fields.indexOf(dst_fld)
            if idx < 0:
                continue
            if feat.fieldNameIndex(src_fld) >= 0:
                nf.setAttribute(idx, feat[src_fld])
        new_feats.append(nf)
    if new_feats:
        BATCH = 2000
        for i in range(0, len(new_feats), BATCH):
            target.dataProvider().addFeatures(new_feats[i:i + BATCH])
        target.triggerRepaint()
    return len(new_feats)


def _load_ramp_into_demand_points(ramp_path: Path) -> int:
    """Load RAMP Point centroids directly into the Demand Points layer.

    Bypasses the Buildings layer (which is Polygon-only).
    Returns number of features added.
    """
    dp_lyr = _get_layer("Demand Points")
    if dp_lyr is None:
        print("  ✗ 'Demand Points' layer not found — cannot load RAMP centroids")
        return 0

    src = QgsVectorLayer(str(ramp_path), "_ramp", "ogr")
    if not src.isValid() or src.featureCount() == 0:
        print(f"  ✗ RAMP centroids file empty or invalid: {ramp_path}")
        return 0

    fields = dp_lyr.fields()
    f_name     = fields.indexOf("Name")
    f_lat      = fields.indexOf("Geo Latitu")
    f_lon      = fields.indexOf("Geo Longit")
    f_type     = fields.indexOf("Type")
    f_status   = fields.indexOf("Status")
    f_ntwk     = fields.indexOf("Network Ty")
    f_build    = fields.indexOf("Build Meth")
    f_premises = fields.indexOf("Premises T")
    f_conn     = fields.indexOf("Connectabl")
    f_country  = fields.indexOf("Geo Countr")

    src_crs = src.crs()
    dst_crs = dp_lyr.crs()
    xform = (
        QgsCoordinateTransform(src_crs, dst_crs, QgsProject.instance())
        if src_crs != dst_crs
        else None
    )

    next_seq = dp_lyr.featureCount() + 1
    new_feats = []

    for feat in src.getFeatures():
        geom = feat.geometry()
        if geom.isEmpty():
            continue
        if xform:
            geom.transform(xform)
        pt = geom.asPoint()

        nf = QgsFeature(fields)
        nf.setGeometry(geom)
        attrs: dict = {}
        if f_name     >= 0: attrs[f_name]     = f"{next_seq:04d}"
        if f_lat      >= 0: attrs[f_lat]      = round(pt.y(), 8)
        if f_lon      >= 0: attrs[f_lon]      = round(pt.x(), 8)
        if f_type     >= 0: attrs[f_type]     = "SDU"
        if f_status   >= 0: attrs[f_status]   = "planned"
        if f_ntwk     >= 0: attrs[f_ntwk]     = "GPON"
        if f_build    >= 0: attrs[f_build]    = "Aerial"
        if f_premises >= 0: attrs[f_premises] = "Residentia"
        if f_conn     >= 0: attrs[f_conn]     = "Yes"
        if f_country  >= 0: attrs[f_country]  = "South Africa"
        for k, v in attrs.items():
            nf.setAttribute(k, v)
        new_feats.append(nf)
        next_seq += 1

    if new_feats:
        BATCH = 2000
        for i in range(0, len(new_feats), BATCH):
            dp_lyr.dataProvider().addFeatures(new_feats[i : i + BATCH])
        dp_lyr.updateExtents()
        dp_lyr.triggerRepaint()

    return len(new_feats)


class _VumaFetchTask(QgsTask):
    """Background task: subprocess runs in worker thread; results load on main thread."""

    def __init__(self, bbox, aoi_geojson, fetch_erven, fetch_buildings, project_folder):
        what = " + ".join(filter(None, [
            "CSG erven" if fetch_erven else "",
            "Overture buildings" if fetch_buildings else "",
        ]))
        super().__init__(f"Vuma: Fetching {what}", QgsTask.Flag.CanCancel)
        self._bbox = bbox
        self._aoi_geojson = aoi_geojson
        self._fetch_erven = fetch_erven
        self._fetch_buildings = fetch_buildings
        self._project_folder = project_folder
        self._ok = False
        self._stdout = ""
        self._proc = None

    def run(self):
        """Worker thread — run subprocess (does NOT touch QGIS APIs)."""
        try:
            cfg = {
                "bbox_4326": self._bbox,
                "aoi_geojson": self._aoi_geojson,
                "fetch_erven": self._fetch_erven,
                "fetch_buildings": self._fetch_buildings,
                "project_folder": self._project_folder,
            }
            Path(CFG_FILE).write_text(json.dumps(cfg), encoding="utf-8")
            proc = subprocess.Popen(
                [_get_python(), WORKER],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, creationflags=CREATE_NO_WINDOW,
            )
            self._proc = proc  # handle for cancel() to kill
            self._stdout, _ = proc.communicate(timeout=1200)
            self._ok = proc.returncode == 0
        except subprocess.TimeoutExpired:
            # Required cleanup: kill the child + drain its pipe, else it
            # zombies holding the stdout PIPE + shared temp files open
            try:
                proc.kill()
                proc.communicate()
            except Exception:
                pass
            self._stdout = "Timed out after 1200 s"
            self._ok = False
        except Exception as e:
            self._stdout = str(e)
            self._ok = False
        return self._ok

    def finished(self, result):
        """Main thread — load downloaded data into QGIS layers."""
        try:
            _active_tasks.remove(self)
        except ValueError:
            pass
        iface.messageBar().clearWidgets()
        print(f"\n{'═' * 55}")
        print("  VUMA STEP 1b — Download Complete")
        print(f"{'═' * 55}")
        for line in self._stdout.splitlines():
            print(f"  {line}")

        if not result:
            print("  ✗ Fetch subprocess failed — see output above")
            print(f"{'═' * 55}\n")
            return

        if self._fetch_erven and Path(ERVEN_OUT).exists():
            n = _load_geojson_into_layer(
                ERVEN_OUT, "Erven",
                {"Label": "Label", "Area": "Area",
                 "PRCL_KEY": "PRCL_KEY", "LSTATUS": "LSTATUS", "WSTATUS": "WSTATUS"},
            )
            print(f"  ✓ Erven loaded: {n:,} parcels")

        ramp_loaded = 0
        if self._fetch_buildings and Path(BUILDINGS_OUT).exists():
            n = _load_geojson_into_layer(
                BUILDINGS_OUT, "Buildings",
                {"id": "id", "Name": "Name", "Discriptio": "Discriptio",
                 "building_t": "building_t", "area_m2": "area_m2",
                 "is_primary": "is_primary"},
            )
            if n > 0:
                print(f"  ✓ Buildings loaded: {n:,} footprints")
            else:
                # Overture returned nothing — check for RAMP centroids
                if RAMP_CENTROIDS_OUT.exists() and RAMP_CENTROIDS_OUT.stat().st_size > 50:
                    ramp_loaded = _load_ramp_into_demand_points(RAMP_CENTROIDS_OUT)
                    try:
                        RAMP_CENTROIDS_OUT.unlink()
                    except Exception:
                        pass
                    if ramp_loaded > 0:
                        print(f"  ✓ RAMP centroids loaded: {ramp_loaded:,} demand points")
                    else:
                        print("  ⚠  RAMP produced 0 centroids — check model / NGI connectivity")
                else:
                    print(
                        "  ⚠  No Overture buildings and no RAMP model found.\n"
                        "     Copy building_detect.onnx to C:/Temp/ for automatic detection,\n"
                        "     or place demand points manually."
                    )

        erven_lyr = _get_layer("Erven")
        bld_lyr   = _get_layer("Buildings")
        if erven_lyr and erven_lyr.featureCount() > 0 and bld_lyr and bld_lyr.featureCount() > 0:
            print("  Running one-per-erven cleanup …")
            _enforce_one_per_erven(erven_lyr, bld_lyr)
        elif bld_lyr and bld_lyr.featureCount() > 0:
            print("  (No erven data — buildings kept as-is)")

        iface.mapCanvas().refreshAllLayers()
        iface.mapCanvas().refresh()

        e = erven_lyr.featureCount() if erven_lyr else 0
        b = bld_lyr.featureCount()   if bld_lyr   else 0
        print(f"\n  ✓ Step 1b complete — {e:,} erven · {b:,} buildings · {ramp_loaded:,} RAMP pts")

        if e > 0 or b > 0 or ramp_loaded > 0:
            _run_centroid_step()
        print(f"{'═' * 55}\n")

    def cancel(self):
        super().cancel()
        proc = getattr(self, "_proc", None)
        if proc is not None and proc.poll() is None:
            try:
                proc.kill()
            except Exception:
                pass


def _run_centroid_step():
    """Place one demand point / ONT centroid per primary building for all clients.

    Routing: FibreTime → ONT v1 + Home Connection v1
             Vuma / HeroTel / unknown → Demand Points
    """
    from fibre_automation.startup import SESSION
    client = SESSION.get("client", "")
    if client == "FT":
        from fibre_automation.fibretime.step_01c_ont import ft_step_01c_ont
        ft_step_01c_ont()
    else:
        from fibre_automation.vuma.step_01c_centroids import vuma_step_01c_centroids
        vuma_step_01c_centroids()


def vuma_step_01b_fetch(silent_if_no_aoi=False):
    """Fetch CSG erven + Overture buildings, then enforce one centroid per erven.

    STATUS: [x] BUILT
    Safe to re-run — skips downloads when layers already have data.
    Downloads run via QgsTask — bridge stays online, QGIS stays responsive.
    """
    from fibre_automation.startup import SESSION

    print(f"\n{'═' * 55}")
    print("  VUMA STEP 1b — Cadastral Data + Buildings")
    print(f"{'═' * 55}")

    erven_lyr = _get_layer("Erven")
    bld_lyr   = _get_layer("Buildings")

    erven_has_data = bool(erven_lyr and erven_lyr.featureCount() > 0)
    bld_has_data   = bool(bld_lyr and bld_lyr.featureCount() > 0)
    need_erven = not erven_has_data
    need_bld   = not bld_has_data

    if erven_has_data:
        print(f"  ⊘ Erven: {erven_lyr.featureCount():,} parcels already loaded — skipping CSG fetch")
    if bld_has_data:
        print(f"  ⊘ Buildings: {bld_lyr.featureCount():,} footprints already loaded — skipping Overture fetch")

    if need_erven or need_bld:
        bbox = _get_aoi_bbox_4326()
        if bbox is None:
            if silent_if_no_aoi:
                print(
                    "  ℹ  No AOI drawn yet.\n"
                    "     Add your area polygon to 'P2 AOI Poly',\n"
                    "     then run Step 1b (or re-run Step 1) to auto-fetch data."
                )
            else:
                print("  ✗ No features in 'P2 AOI Poly' — draw the AOI first.")
            print(f"{'═' * 55}\n")
            return

        what = " + ".join(filter(None, [
            "CSG erven" if need_erven else "",
            "Overture buildings" if need_bld else "",
        ]))
        print(f"  AOI: {bbox[0]:.4f},{bbox[1]:.4f} → {bbox[2]:.4f},{bbox[3]:.4f}")
        print(f"  Queuing: {what}")
        iface.messageBar().pushMessage("Vuma", f"Fetching {what}…", level=0, duration=0)

        aoi_geojson = _get_aoi_geojson()
        task = _VumaFetchTask(
            bbox, aoi_geojson, need_erven, need_bld,
            SESSION.get("project_folder") or "C:/Temp",
        )
        _active_tasks.append(task)  # prevent GC before finished() fires
        QgsApplication.taskManager().addTask(task)
        print("  ⏳ Running in background — QGIS + bridge stay online")
        print("     Results load automatically when done (≈2–15 min)")
        print(f"{'═' * 55}\n")
        return

    # No download needed — just run cleanup
    if erven_lyr and erven_lyr.featureCount() > 0 and bld_lyr and bld_lyr.featureCount() > 0:
        print("  Running one-per-erven cleanup …")
        _enforce_one_per_erven(erven_lyr, bld_lyr)
    elif bld_lyr and bld_lyr.featureCount() > 0:
        print("  (No erven data — buildings kept as-is)")

    iface.mapCanvas().refreshAllLayers()
    iface.mapCanvas().refresh()

    e = erven_lyr.featureCount() if erven_lyr else 0
    b = bld_lyr.featureCount()   if bld_lyr   else 0
    dp_lyr = _get_layer("Demand Points")
    d = dp_lyr.featureCount() if dp_lyr else 0
    print(f"\n  ✓ Step 1b complete — {e:,} erven · {b:,} buildings · {d:,} demand pts")

    if e > 0 or b > 0 or d > 0:
        _run_centroid_step()
    print(f"{'═' * 55}\n")
