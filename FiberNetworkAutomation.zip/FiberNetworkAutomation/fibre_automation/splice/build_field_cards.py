"""
MOA Phase 2 — Per-Closure A4 PDF Field Cards  (fusion / AGG domes)
==================================================================
The missing deliverable v8 (MOA_Splice_Plan_v8.xlsx) does not produce: one printable
A4 card per AGG dome for the splicing technician. Data is READ FROM v8 so the cards
can never disagree with the Excel splice plan (single source of truth).

Each card:
  - Header: closure label, spec, capacity, PON(s)/OLT port(s), zone, GPS  + QR (maps link)
  - FEEDER splices      : feeder cable fibre -> FTS input            (fusion)
  - DISTRIBUTION splices: FTS output leg -> distribution fibre -> DIS dome
  - TIA-598-C colour swatches, 24-position tray numbering
  - Loss budget + standards footer (TIA-568.3-D, ISO/IEC 14763-3:2024 Ed 3.0)

Reads : MOA_Splice_Plan_v8.xlsx  +  C:/Temp/splice_data.json (GPS/spec/capacity)
Writes: C:/Users/jjsch/OneDrive/ON LAPTOP FIBRE/QGIS test/MOA_Splice_FieldCards.pdf
"""
import json
import re
from io import BytesIO
from collections import defaultdict, OrderedDict

import qrcode
import openpyxl
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (SimpleDocTemplate, Table, TableStyle, Paragraph,
                                Spacer, Image, PageBreak)

import os as _os
from pathlib import Path as _Path
_HERE = _Path(__file__).resolve().parent
_OUT_DIR = _Path(_os.environ.get('VF_SPLICE_OUT', _HERE / 'output'))
_OUT_DIR.mkdir(parents=True, exist_ok=True)
XLSX = str(_OUT_DIR / 'MOA_Splice_Plan_v9.xlsx')
DATA = str(_Path(_os.environ.get('VF_SPLICE_DATA', _HERE / 'splice_data.json')))
if not _os.path.exists(DATA) and _os.path.exists('C:/Temp/splice_data.json'):
    DATA = 'C:/Temp/splice_data.json'
OUT = str(_OUT_DIR / 'MOA_Splice_FieldCards_v9.pdf')

TIA598C = ["Blue", "Orange", "Green", "Brown", "Slate", "White",
           "Red", "Black", "Yellow", "Violet", "Rose", "Aqua"]
SWATCH = {"Blue": "#1F77B4", "Orange": "#FF7F0E", "Green": "#2CA02C",
          "Brown": "#8C564B", "Slate": "#7F7F7F", "White": "#FFFFFF",
          "Red": "#D62728", "Black": "#000000", "Yellow": "#FFD700",
          "Violet": "#9467BD", "Rose": "#E377C2", "Aqua": "#17BECF"}
DARK = {"Blue", "Brown", "Slate", "Black", "Red", "Violet"}
OLT_OFFSET = {15: 224, 16: 240, 17: 256, 18: 272, 19: 288}


def fnum(s):
    m = re.search(r'(\d+)', str(s or ''))
    return int(m.group(1)) if m else None


def colour_of(flabel):
    n = fnum(flabel)
    if not n:
        return None, None
    return TIA598C[(n - 1) % 12], (n - 1) // 12 + 1


def agg_of_fts(label):
    left = (label or "").split('-OLT')[0]
    i = left.find('.AGG')
    return ('MOA' + left[i:]) if i >= 0 else None


def olt_to_pon(port):
    m = re.match(r'C(\d+)P(\d+)', port or '')
    return OLT_OFFSET.get(int(m.group(1)), 0) + int(m.group(2)) if m else None


def olt_port(label):
    m = re.search(r'C\d+P\d+', label or '')
    return m.group(0) if m else None


def extract_dome_data():
    """Read v8 + splice_data.json -> {agg_dome: {meta, feeders[], legs[]}}.

    NOTE: the AGG-dome label embedded in FTS labels (…AGG.DM.P.<pole>) does NOT
    match the Enclosures Splice layer label_1 for the same PON, so GPS/zone are
    taken from the FTS point itself (exact) and spec/capacity by PON (best effort).
    """
    data = json.load(open(DATA))
    fts_by_olt = {olt_port(f['label']): f for f in data['fts']}
    agg_by_pon = {}
    for a in data['agg_domes']:
        p = str(a.get('pon_no'))
        agg_by_pon.setdefault(p, a)
    wb = openpyxl.load_workbook(XLSX, read_only=False, data_only=True)
    domes = OrderedDict()

    for name in wb.sheetnames:
        if not re.match(r'^C\d+P\d+$', name):
            continue
        ws = wb[name]
        fts_label = ws.cell(3, 17).value
        dome = agg_of_fts(fts_label)
        if not dome:
            continue
        rec = domes.setdefault(dome, {"feeders": [], "legs": [], "pons": set(),
                                      "olts": set()})
        rec["olts"].add(name)
        rec["pons"].add(olt_to_pon(name))

        # feeder splice: feeder cable fibre -> FTS input
        rec["feeders"].append({
            "cable": ws.cell(3, 3).value, "fibre": ws.cell(3, 6).value,
            "fts": fts_label, "olt": name, "pon": olt_to_pon(name),
        })

        # distribution: collapse 16 port-rows per leg into one leg record
        seen, drops = OrderedDict(), defaultdict(int)
        r = 7
        while True:
            sts = ws.cell(r, 8).value
            if sts is None and ws.cell(r, 1).value is None:
                break
            if sts:
                if sts not in seen:
                    seen[sts] = {
                        "fts": ws.cell(r, 1).value, "leg": ws.cell(r, 2).value,
                        "fibre_out": ws.cell(r, 7).value,
                        "dist_cable": ws.cell(r, 4).value,
                        "dis_dome": ws.cell(r, 6).value, "sts": sts,
                    }
                dr = ws.cell(r, 10).value
                if dr and str(dr).upper() != "SPARE":
                    drops[sts] += 1
            r += 1
            if r > 5000:
                break
        for sts, leg in seen.items():
            leg["drops"] = drops[sts]
            rec["legs"].append(leg)

    wb.close()
    # attach meta: GPS/zone/pole from the FTS point (exact); spec/cap by PON
    for dome, rec in domes.items():
        fts_recs = [fts_by_olt[o] for o in rec["olts"] if o in fts_by_olt]
        f0 = fts_recs[0] if fts_recs else {}
        pon0 = sorted(x for x in rec["pons"] if x)
        a0 = agg_by_pon.get(str(pon0[0])) if pon0 else None
        a0 = a0 or {}
        rec["meta"] = {
            "lat": f0.get("lat"), "lon": f0.get("lon"),
            "zone_no": f0.get("zone_no") or a0.get("zone_no"),
            "strtfeat": f0.get("strtfeat"),
            "spec_1": a0.get("spec_1"), "cblcpty1": a0.get("cblcpty1"),
            "enclosure_label": a0.get("label_1"),
        }
    return domes


def qr_image(lat, lon, label):
    target = (f"https://maps.google.com/?q={lat},{lon}"
              if lat and lon else label)
    qr = qrcode.QRCode(box_size=3, border=1)
    qr.add_data(target)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")  # PilImage wrapper
    pil = img.get_image()         # underlying PIL.Image (robust across qrcode versions)
    buf = BytesIO()
    pil.save(buf, format="PNG")
    buf.seek(0)
    return Image(buf, width=24 * mm, height=24 * mm)


def swatch_cell(name):
    if not name:
        return ""
    return name


def build():
    domes = extract_dome_data()
    styles = getSampleStyleSheet()
    h = ParagraphStyle("h", parent=styles["Heading2"], fontSize=13,
                       textColor=colors.HexColor("#2C3E50"), spaceAfter=2)
    sub = ParagraphStyle("sub", parent=styles["Normal"], fontSize=8,
                         textColor=colors.HexColor("#7F7F7F"))
    sec = ParagraphStyle("sec", parent=styles["Normal"], fontSize=9,
                         textColor=colors.white, fontName="Helvetica-Bold")
    foot = ParagraphStyle("foot", parent=styles["Normal"], fontSize=6.5,
                          textColor=colors.HexColor("#7F7F7F"))

    doc = SimpleDocTemplate(OUT, pagesize=A4,
                            leftMargin=14 * mm, rightMargin=14 * mm,
                            topMargin=12 * mm, bottomMargin=10 * mm,
                            title="MOA Ph2 Splice Field Cards")
    story = []
    page = 0
    total_splices = 0

    for dome, rec in domes.items():
        m = rec["meta"]
        lat, lon = m.get("lat"), m.get("lon")
        pons = ", ".join(str(p) for p in sorted(x for x in rec["pons"] if x))
        olts = ", ".join(sorted(rec["olts"]))

        # ---- header band ----
        story.append(Paragraph(f"FUSION SPLICE FIELD CARD &nbsp;|&nbsp; {dome}", h))
        story.append(Paragraph(
            f"AGG dome (fusion) &nbsp;·&nbsp; spec {m.get('spec_1') or '—'} "
            f"&nbsp;·&nbsp; capacity {m.get('cblcpty1') or '—'} "
            f"&nbsp;·&nbsp; PON {pons or '—'} ({olts}) "
            f"&nbsp;·&nbsp; zone {m.get('zone_no') or '—'}", sub))
        story.append(Spacer(1, 3 * mm))

        info = [[Paragraph(f"<b>Pole:</b> {m.get('strtfeat','?')}<br/>"
                           f"<b>GPS:</b> {lat}, {lon}<br/>"
                           f"<b>FTS hosted:</b> {len(rec['feeders'])}"
                           f" &nbsp; <b>Legs:</b> {len(rec['legs'])}", styles["Normal"]),
                 qr_image(lat, lon, dome)]]
        it = Table(info, colWidths=[150 * mm, 26 * mm])
        it.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                                ("ALIGN", (1, 0), (1, 0), "RIGHT")]))
        story.append(it)
        story.append(Spacer(1, 3 * mm))

        # ---- splice rows: feeder first, then legs; tray/pos sequential ----
        tray, pos = 1, 0
        rows = [["Tray", "Pos", "Type", "In Cable", "In F#", "Col",
                 "Out / Dest", "Out F#", "Col", "Drops"]]
        stys = [
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2C3E50")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 7),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#BBBBBB")),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]

        def add(rtype, in_cable, in_f, out_dest, out_f, drops=""):
            nonlocal tray, pos, total_splices
            pos += 1
            if pos > 24:
                tray, pos = tray + 1, 1
            ic, _ = colour_of(in_f)
            oc, _ = colour_of(out_f)
            ri = len(rows)
            rows.append([tray, pos, rtype, (in_cable or "")[:30], in_f or "",
                         swatch_cell(ic), (out_dest or "")[:34], out_f or "",
                         swatch_cell(oc), drops])
            if ic in SWATCH:
                stys.append(("BACKGROUND", (5, ri), (5, ri), colors.HexColor(SWATCH[ic])))
                if ic in DARK:
                    stys.append(("TEXTCOLOR", (5, ri), (5, ri), colors.white))
            if oc in SWATCH:
                stys.append(("BACKGROUND", (8, ri), (8, ri), colors.HexColor(SWATCH[oc])))
                if oc in DARK:
                    stys.append(("TEXTCOLOR", (8, ri), (8, ri), colors.white))
            total_splices += 1

        for fd in rec["feeders"]:
            add("feeder→FTS", fd["cable"], fd["fibre"],
                f"{fd['fts']}", "", "")
        for lg in sorted(rec["legs"], key=lambda x: (str(x["fts"]), x["leg"] or 0)):
            add("FTS→dist", f"STS #{lg['leg']}", lg["fibre_out"],
                f"{lg['dis_dome']}", lg["fibre_out"], lg["drops"])

        t = Table(rows, repeatRows=1,
                  colWidths=[9 * mm, 8 * mm, 17 * mm, 34 * mm, 10 * mm, 13 * mm,
                             38 * mm, 10 * mm, 13 * mm, 11 * mm])
        t.setStyle(TableStyle(stys))
        story.append(t)
        story.append(Spacer(1, 3 * mm))

        story.append(Paragraph(
            "<b>Acceptance (per splice):</b> fusion loss target ≤ 0.10 dB, max ≤ 0.30 dB "
            "(TIA-568.3-D) · single-mode ORL ≥ 26 dB · verify bi-directional OTDR "
            "(ISO/IEC 14763-3:2024 Ed 3.0). Colour code: TIA-598-C.", foot))
        story.append(Paragraph(
            "<b>Optical loss budget (worst-case POP→ONT):</b> cascaded 1:8 FTS (10.5 dB) + "
            "1:16 STS (13.5 dB) = 24 dB · + connectors/splices/fibre ≈ 25–26 dB total → "
            "~2–2.5 dB margin on GPON Class B+ (28 dB), ~6 dB on Class C+ (32 dB). "
            "Per-PON value on the sheet banner / Splice Viewer. Confirm each drop with OTDR.", foot))
        story.append(PageBreak())
        page += 1

    doc.build(story)
    print(f"  AGG closure cards : {page}")
    print(f"  total splice rows : {total_splices}")
    print(f"  PDF -> {OUT}")


if __name__ == "__main__":
    build()
