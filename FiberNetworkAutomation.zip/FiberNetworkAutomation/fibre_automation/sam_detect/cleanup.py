"""cleanup — final topological cleanup for Detect Buildings (SAM) output.

Runs in-worker over the assembled feature list (EPSG:3857) just before write, so
it also cleans resumed runs. Two jobs:

  1. GLOBAL DEDUP across ALL emitters (erf + standalone + rescue): the pipeline
     has three separate pools and never cross-checks them, and its one NMS is
     IoU-only — so a circle *inside* a polygon (IoU 0.25) survives as a
     duplicate. We suppress any pair with IoU>0.30 OR intersection/min_area>0.30
     (containment), keeping the higher-quality one. Quality favours erf-tagged
     over standalone over rescue, rectangles over circles.
  2. FLAG (never silently drop): near-circular blobs (Polsby-Popper>0.90 — tree/
     tank or a real rondavel) and merged-neighbour polygons (negative-buffer
     waist) get flag_for_review=1 + a defect_flags tag for human triage.

Ratios (IoU, containment, Polsby-Popper) are scale-invariant, so we work
directly in the worker's 3857 geometries; only the two absolute thresholds
(1.5 m erode, 12 m² part) are de-projected via `af` (=cos²lat; real = map*af).
Off via VF_SAM_CLEANUP=0.
"""
from __future__ import annotations

import math
import os

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

CLEANUP_ENABLED = os.environ.get("VF_SAM_CLEANUP", "1") != "0"
DUP_IOU = 0.30
DUP_CONTAIN = 0.30
CIRCLE_PP = 0.90          # near-perfect circle
CIRCLE_SOFT = 0.85        # quality penalty ramps from here
SOURCE_PRIOR = {"erf": 1.0, "standalone": 0.6, "rescue": 0.3}
MERGE_ERODE_M = 1.5
MERGE_PART_M2 = 12.0


def _pp(geom):
    per = geom.length
    return (4 * math.pi * geom.area / (per * per)) if per > 0 else 0.0


def _quality(props, pp):
    prior = SOURCE_PRIOR.get(props.get("source"), 0.6)
    rr = props.get("rect_ratio")
    rr = float(rr) if rr is not None else 0.5
    sc = props.get("clf_score")
    sc = float(sc) if sc is not None else 0.5
    return 2.0 * prior + rr + 0.5 * sc - 2.0 * max(0.0, (pp - CIRCLE_SOFT) / 0.15)


def _is_merged(geom, erode_map, minpart_map):
    try:
        er = geom.buffer(-erode_map)
        if er.is_empty:
            return False
        parts = list(er.geoms) if er.geom_type == "MultiPolygon" else [er]
        return sum(1 for p in parts if p.area >= minpart_map) >= 2
    except Exception:
        return False


def global_cleanup(feats, af):
    """feats: list of GeoJSON feature dicts (3857). af: cos^2(lat) area factor.
    Returns (cleaned_feats, stats). Buildings are deduped; vacant outlines pass
    through untouched. Every output feature gains a `defect_flags` property."""
    if not CLEANUP_ENABLED:
        for f in feats:
            f["properties"].setdefault("defect_flags", "")
        return feats, {"enabled": False}

    from shapely.geometry import shape

    sqrt_af = math.sqrt(af) if af > 0 else 1.0
    erode_map = MERGE_ERODE_M / sqrt_af          # 1.5 m real -> map units
    minpart_map = MERGE_PART_M2 / af if af > 0 else MERGE_PART_M2  # 12 m² real -> map

    geoms = {}
    for i, f in enumerate(feats):
        if f["properties"].get("has_building") != 1:
            continue
        try:
            g = shape(f["geometry"])
            if g.is_valid and not g.is_empty:
                geoms[i] = g
        except Exception:
            _swallowed_note()

    # greedy keep-best NMS (IoU + containment). N is small (~few k); brute-force
    # against the accepted set with an envelope pre-check is fine and deterministic.
    order = sorted(geoms, key=lambda i: -_quality(feats[i]["properties"], _pp(geoms[i])))
    kept, kept_g = [], []
    for i in order:
        gi = geoms[i]
        conflict = False
        for kg in kept_g:
            if not gi.envelope.intersects(kg.envelope):
                continue
            inter = gi.intersection(kg).area
            if inter <= 0:
                continue
            iou = inter / (gi.area + kg.area - inter)
            if iou > DUP_IOU or inter > DUP_CONTAIN * min(gi.area, kg.area):
                conflict = True
                break
        if not conflict:
            kept.append(i)
            kept_g.append(gi)
    kept_set = set(kept)
    n_dedup = len(geoms) - len(kept)

    n_circle = n_merged = 0
    for i in kept:
        g = geoms[i]
        flags = []
        if _pp(g) > CIRCLE_PP:
            flags.append("circle")
            n_circle += 1
        if _is_merged(g, erode_map, minpart_map):
            flags.append("merged")
            n_merged += 1
        p = feats[i]["properties"]
        p["defect_flags"] = ",".join(flags)
        if flags:
            p["flag_for_review"] = 1

    out = []
    for i, f in enumerate(feats):
        if f["properties"].get("has_building") == 1:
            if i not in kept_set:
                continue                          # dropped duplicate
        f["properties"].setdefault("defect_flags", "")
        out.append(f)

    return out, {"enabled": True, "deduped": n_dedup,
                 "circles_flagged": n_circle, "merged_flagged": n_merged}
