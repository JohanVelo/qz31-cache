"""branding — the Velocity Fibre look (Phase 2 of the unified-plugin build).

Single source of truth for colours, dialog QSS, the drawn V-mark, and helpers:

    from FiberNetworkAutomation.branding import vf_style
    vf_style.apply_vf_style(dialog, title='New Project')

Palette: sampled from velocity_logo.jpg (navy #1A2050, crimson #8B2450, blue #3D5CB8)
+ the established Home-panel dark violet UI (#24253A / #6E56CF) + the fibertime mark
accents (cyan #2ABFCC, yellow #FFE619).
"""
from . import vf_style  # noqa: F401
