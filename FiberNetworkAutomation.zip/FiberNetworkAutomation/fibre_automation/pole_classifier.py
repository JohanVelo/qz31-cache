# -*- coding: utf-8 -*-
"""Client-aware pole classifier — "FT7 for HeroTel" (and Fibertime).

Given a pole's GEOMETRY FACTS (bend angle of the cable through it, whether it is
a road crossing, whether it is the end of a run, its span), assign the correct
engineering class per the CLIENT's spec table:

  role   — midblock / corner / road-crossing / exception   (HeroTel)
           intermediate / anchor-strain                     (Fibertime)
  height — 5.4m / 7.2m / 9m   (HeroTel; Fibertime uses no height field)
  thick  — 100-120 / 120-140 / 140-160 mm
  reason — plain-English "why" (road crossing; dir change 34°; end of run; …)
  road_cross / road_name — the explicit road-crossing flag HeroTel's table lacks

The spec tables are the two operators we focus on, distilled from:
  * HeroTel TSD "Fibre Aerial Deployment" (2025-09-01) — 5.4m/100-120 straight,
    5.4m/120-140 corner (>15deg), 7.2m road crossing, 9m/140-160 exception.
  * Fibertime MOA / FT7 — 140-160 anchor/strain on end-of-run | road crossing |
    dir change >15deg; else 120-140 intermediate (FOA 2015:35).

Pure python — no QGIS. The QGIS side extracts the facts and writes the result.
"""

__all__ = ["ANCHOR_DEG", "CLIENTS", "CORNER_DEG", "classify"]

# bend angle (deg) above which a pole is a corner (HeroTel) / anchor (Fibertime)
CORNER_DEG = 15.0
ANCHOR_DEG = 15.0

CLIENTS = ("Fibertime", "HeroTel")


def _num(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _classify_herotel(facts):
    bend = _num(facts.get("bend_deg"))
    rc = bool(facts.get("road_crossing"))
    exc = bool(facts.get("exception"))
    corner = bend > CORNER_DEG
    if exc:                                   # rare: extra-height exception
        role, height, thick, reason = "exception", "9m", "140-160mm", "exception"
    elif rc:                                  # road crossing -> 7.2m (clearance)
        role, height = "road-crossing", "7.2m"
        thick = "120-140mm" if corner else "100-120mm"
        reason = "road crossing" + (" + dir change %.0f°" % bend
                                    if corner else "")
    elif corner:                              # >15deg deviation -> thicker
        role, height, thick = "corner", "5.4m", "120-140mm"
        reason = "dir change %.0f°" % bend
    else:                                     # straight midblock
        role, height, thick, reason = "midblock", "5.4m", "100-120mm", "midblock"
    return {"role": role, "height": height, "thick": thick, "reason": reason,
            "road_cross": "Y" if rc else "N",
            "road_name": facts.get("road_name") or ""}


def _classify_fibertime(facts):
    bend = _num(facts.get("bend_deg"))
    rc = bool(facts.get("road_crossing"))
    end = bool(facts.get("end_of_run"))
    dead = bool(facts.get("dead_end"))
    reasons = []
    if end:
        reasons.append("end of run")
    if rc:
        reasons.append("road crossing")
    if bend > ANCHOR_DEG:
        reasons.append("dir change %.0f°" % bend)
    if dead:
        reasons.append("dead-end")
    if reasons:                               # anchor / strain -> 140-160
        role, thick, reason = "anchor/strain", "140-160mm", "; ".join(reasons)
    else:                                     # intermediate -> 120-140
        role, thick, reason = "intermediate", "120-140mm", "intermediate"
    return {"role": role, "height": None, "thick": thick, "reason": reason,
            "road_cross": "Y" if rc else "N",
            "road_name": facts.get("road_name") or ""}


def classify(client, facts):
    """Classify one pole for a client from its geometry facts.

    client : "HeroTel" | "Fibertime" (anything else -> Fibertime rules).
    facts  : {"bend_deg": float, "road_crossing": bool, "end_of_run": bool,
              "dead_end": bool, "span_m": float, "exception": bool,
              "road_name": str}.  Missing keys default to 0 / False / "".
    Returns {"role","height","thick","reason","road_cross","road_name"}.
    """
    if client == "HeroTel":
        return _classify_herotel(facts)
    return _classify_fibertime(facts)
