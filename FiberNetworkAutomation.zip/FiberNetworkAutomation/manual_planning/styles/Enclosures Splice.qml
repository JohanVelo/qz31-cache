<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyDrawingHints="0" symbologyReferenceScale="-1" maxScale="0" hasScaleBasedVisibilityFlag="0" minScale="100000000" simplifyDrawingTol="1" simplifyLocal="1" styleCategories="AllStyleCategories" autoRefreshMode="Disabled" simplifyAlgorithm="0" version="3.44.4-Solothurn" readOnly="0" labelsEnabled="0" autoRefreshTime="0" simplifyMaxScale="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endField="" startExpression="" endExpression="" durationField="pon_no" mode="0" limitMode="0" startField="" enabled="0" fixedDuration="0" durationUnit="min" accumulate="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation zoffset="0" extrusion="0" type="IndividualFeatures" zscale="1" clamping="Terrain" extrusionEnabled="0" binding="Centroid" customToleranceEnabled="0" showMarkerSymbolInSurfacePlots="0" symbology="Line" respectLayerSymbol="1">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol name="" clip_to_extent="1" type="line" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleLine" id="{9a83820f-de16-4fd0-bd8b-28984157a8b8}" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="213,180,60,255,rgb:0.8352941,0.7058824,0.2352941,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol name="" clip_to_extent="1" type="fill" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleFill" id="{edc88887-b78c-435b-8c97-e2283158c7c8}" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="213,180,60,255,rgb:0.8352941,0.7058824,0.2352941,1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="152,129,43,255,rgb:0.5966278,0.5042039,0.1680629,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol name="" clip_to_extent="1" type="marker" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleMarker" id="{cf50ba0c-cc23-4ef4-bc0d-cef2fd9a8e43}" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="213,180,60,255,rgb:0.8352941,0.7058824,0.2352941,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="diamond"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="152,129,43,255,rgb:0.5966278,0.5042039,0.1680629,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" type="singleSymbol" forceraster="0" referencescale="-1" symbollevels="0">
    <symbols>
      <symbol name="0" clip_to_extent="1" type="marker" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleMarker" id="{1e0d2893-68a3-4537-b957-37d701f6cb57}" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="114,155,111,255,rgb:0.4470588,0.6078431,0.4352941,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3.2"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol name="" clip_to_extent="1" type="marker" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleMarker" id="{43385ef4-8fdd-4459-b057-c7ddb947e5d1}" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="255,0,0,255,rgb:1,0,0,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="2"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <customproperties>
    <Option type="Map">
      <Option name="dualview/previewExpressions" type="List">
        <Option type="QString" value="&quot;label_1&quot;"/>
      </Option>
      <Option name="embeddedWidgets/count" type="int" value="0"/>
      <Option name="variableNames" type="invalid"/>
      <Option name="variableValues" type="invalid"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field name="label_1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="type_1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subtyp_1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="spec_1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cblcpty1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="conntr1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cmpownr" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="label_2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="type_2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subtyp_2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="spec_2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim1_2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim2_2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cblcpty2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="conntr2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="featno1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="label_3" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="type_3" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subtyp3" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="spec_3" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim1_3" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim2_3" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cblcpty3" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="conntr3" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="featno2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="strtfeat" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="endfeat" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="lat" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="lon" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sg21" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sg26" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="address" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="pon_no" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="zone_no" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subplace" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="mainplce" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="mun" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="stackref" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="datecrtd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="crtdby" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="date_edt" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="editby" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="comments" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" index="0" field="label_1"/>
    <alias name="" index="1" field="type_1"/>
    <alias name="" index="2" field="subtyp_1"/>
    <alias name="" index="3" field="spec_1"/>
    <alias name="" index="4" field="dim1"/>
    <alias name="" index="5" field="dim2"/>
    <alias name="" index="6" field="cblcpty1"/>
    <alias name="" index="7" field="conntr1"/>
    <alias name="" index="8" field="cmpownr"/>
    <alias name="" index="9" field="label_2"/>
    <alias name="" index="10" field="type_2"/>
    <alias name="" index="11" field="subtyp_2"/>
    <alias name="" index="12" field="spec_2"/>
    <alias name="" index="13" field="dim1_2"/>
    <alias name="" index="14" field="dim2_2"/>
    <alias name="" index="15" field="cblcpty2"/>
    <alias name="" index="16" field="conntr2"/>
    <alias name="" index="17" field="featno1"/>
    <alias name="" index="18" field="label_3"/>
    <alias name="" index="19" field="type_3"/>
    <alias name="" index="20" field="subtyp3"/>
    <alias name="" index="21" field="spec_3"/>
    <alias name="" index="22" field="dim1_3"/>
    <alias name="" index="23" field="dim2_3"/>
    <alias name="" index="24" field="cblcpty3"/>
    <alias name="" index="25" field="conntr3"/>
    <alias name="" index="26" field="featno2"/>
    <alias name="" index="27" field="strtfeat"/>
    <alias name="" index="28" field="endfeat"/>
    <alias name="" index="29" field="lat"/>
    <alias name="" index="30" field="lon"/>
    <alias name="" index="31" field="sg21"/>
    <alias name="" index="32" field="sg26"/>
    <alias name="" index="33" field="address"/>
    <alias name="" index="34" field="pon_no"/>
    <alias name="" index="35" field="zone_no"/>
    <alias name="" index="36" field="subplace"/>
    <alias name="" index="37" field="mainplce"/>
    <alias name="" index="38" field="mun"/>
    <alias name="" index="39" field="stackref"/>
    <alias name="" index="40" field="datecrtd"/>
    <alias name="" index="41" field="crtdby"/>
    <alias name="" index="42" field="date_edt"/>
    <alias name="" index="43" field="editby"/>
    <alias name="" index="44" field="comments"/>
  </aliases>
  <defaults>
    <default expression="" field="label_1" applyOnUpdate="0"/>
    <default expression="" field="type_1" applyOnUpdate="0"/>
    <default expression="" field="subtyp_1" applyOnUpdate="0"/>
    <default expression="" field="spec_1" applyOnUpdate="0"/>
    <default expression="" field="dim1" applyOnUpdate="0"/>
    <default expression="" field="dim2" applyOnUpdate="0"/>
    <default expression="" field="cblcpty1" applyOnUpdate="0"/>
    <default expression="" field="conntr1" applyOnUpdate="0"/>
    <default expression="" field="cmpownr" applyOnUpdate="0"/>
    <default expression="" field="label_2" applyOnUpdate="0"/>
    <default expression="" field="type_2" applyOnUpdate="0"/>
    <default expression="" field="subtyp_2" applyOnUpdate="0"/>
    <default expression="" field="spec_2" applyOnUpdate="0"/>
    <default expression="" field="dim1_2" applyOnUpdate="0"/>
    <default expression="" field="dim2_2" applyOnUpdate="0"/>
    <default expression="" field="cblcpty2" applyOnUpdate="0"/>
    <default expression="" field="conntr2" applyOnUpdate="0"/>
    <default expression="" field="featno1" applyOnUpdate="0"/>
    <default expression="" field="label_3" applyOnUpdate="0"/>
    <default expression="" field="type_3" applyOnUpdate="0"/>
    <default expression="" field="subtyp3" applyOnUpdate="0"/>
    <default expression="" field="spec_3" applyOnUpdate="0"/>
    <default expression="" field="dim1_3" applyOnUpdate="0"/>
    <default expression="" field="dim2_3" applyOnUpdate="0"/>
    <default expression="" field="cblcpty3" applyOnUpdate="0"/>
    <default expression="" field="conntr3" applyOnUpdate="0"/>
    <default expression="" field="featno2" applyOnUpdate="0"/>
    <default expression="" field="strtfeat" applyOnUpdate="0"/>
    <default expression="" field="endfeat" applyOnUpdate="0"/>
    <default expression="" field="lat" applyOnUpdate="0"/>
    <default expression="" field="lon" applyOnUpdate="0"/>
    <default expression="" field="sg21" applyOnUpdate="0"/>
    <default expression="" field="sg26" applyOnUpdate="0"/>
    <default expression="" field="address" applyOnUpdate="0"/>
    <default expression="" field="pon_no" applyOnUpdate="0"/>
    <default expression="" field="zone_no" applyOnUpdate="0"/>
    <default expression="" field="subplace" applyOnUpdate="0"/>
    <default expression="" field="mainplce" applyOnUpdate="0"/>
    <default expression="" field="mun" applyOnUpdate="0"/>
    <default expression="" field="stackref" applyOnUpdate="0"/>
    <default expression="" field="datecrtd" applyOnUpdate="0"/>
    <default expression="" field="crtdby" applyOnUpdate="0"/>
    <default expression="" field="date_edt" applyOnUpdate="0"/>
    <default expression="" field="editby" applyOnUpdate="0"/>
    <default expression="" field="comments" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="label_1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="type_1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subtyp_1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="spec_1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="cblcpty1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="conntr1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="cmpownr"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="label_2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="type_2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subtyp_2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="spec_2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim1_2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim2_2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="cblcpty2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="conntr2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="featno1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="label_3"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="type_3"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subtyp3"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="spec_3"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim1_3"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim2_3"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="cblcpty3"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="conntr3"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="featno2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="strtfeat"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="endfeat"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="lat"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="lon"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="sg21"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="sg26"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="address"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="pon_no"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="zone_no"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subplace"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="mainplce"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="mun"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="stackref"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="datecrtd"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="crtdby"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="date_edt"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="editby"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="comments"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" field="label_1" desc=""/>
    <constraint exp="" field="type_1" desc=""/>
    <constraint exp="" field="subtyp_1" desc=""/>
    <constraint exp="" field="spec_1" desc=""/>
    <constraint exp="" field="dim1" desc=""/>
    <constraint exp="" field="dim2" desc=""/>
    <constraint exp="" field="cblcpty1" desc=""/>
    <constraint exp="" field="conntr1" desc=""/>
    <constraint exp="" field="cmpownr" desc=""/>
    <constraint exp="" field="label_2" desc=""/>
    <constraint exp="" field="type_2" desc=""/>
    <constraint exp="" field="subtyp_2" desc=""/>
    <constraint exp="" field="spec_2" desc=""/>
    <constraint exp="" field="dim1_2" desc=""/>
    <constraint exp="" field="dim2_2" desc=""/>
    <constraint exp="" field="cblcpty2" desc=""/>
    <constraint exp="" field="conntr2" desc=""/>
    <constraint exp="" field="featno1" desc=""/>
    <constraint exp="" field="label_3" desc=""/>
    <constraint exp="" field="type_3" desc=""/>
    <constraint exp="" field="subtyp3" desc=""/>
    <constraint exp="" field="spec_3" desc=""/>
    <constraint exp="" field="dim1_3" desc=""/>
    <constraint exp="" field="dim2_3" desc=""/>
    <constraint exp="" field="cblcpty3" desc=""/>
    <constraint exp="" field="conntr3" desc=""/>
    <constraint exp="" field="featno2" desc=""/>
    <constraint exp="" field="strtfeat" desc=""/>
    <constraint exp="" field="endfeat" desc=""/>
    <constraint exp="" field="lat" desc=""/>
    <constraint exp="" field="lon" desc=""/>
    <constraint exp="" field="sg21" desc=""/>
    <constraint exp="" field="sg26" desc=""/>
    <constraint exp="" field="address" desc=""/>
    <constraint exp="" field="pon_no" desc=""/>
    <constraint exp="" field="zone_no" desc=""/>
    <constraint exp="" field="subplace" desc=""/>
    <constraint exp="" field="mainplce" desc=""/>
    <constraint exp="" field="mun" desc=""/>
    <constraint exp="" field="stackref" desc=""/>
    <constraint exp="" field="datecrtd" desc=""/>
    <constraint exp="" field="crtdby" desc=""/>
    <constraint exp="" field="date_edt" desc=""/>
    <constraint exp="" field="editby" desc=""/>
    <constraint exp="" field="comments" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="&quot;label_1&quot;" sortOrder="0">
    <columns>
      <column name="label_1" type="field" width="167" hidden="0"/>
      <column name="type_1" type="field" width="-1" hidden="0"/>
      <column name="subtyp_1" type="field" width="-1" hidden="0"/>
      <column name="spec_1" type="field" width="-1" hidden="0"/>
      <column name="dim1" type="field" width="-1" hidden="0"/>
      <column name="dim2" type="field" width="-1" hidden="0"/>
      <column name="cblcpty1" type="field" width="-1" hidden="0"/>
      <column name="conntr1" type="field" width="-1" hidden="0"/>
      <column name="cmpownr" type="field" width="-1" hidden="0"/>
      <column name="label_2" type="field" width="-1" hidden="0"/>
      <column name="type_2" type="field" width="-1" hidden="0"/>
      <column name="subtyp_2" type="field" width="-1" hidden="0"/>
      <column name="spec_2" type="field" width="-1" hidden="0"/>
      <column name="dim1_2" type="field" width="-1" hidden="0"/>
      <column name="dim2_2" type="field" width="-1" hidden="0"/>
      <column name="cblcpty2" type="field" width="-1" hidden="0"/>
      <column name="conntr2" type="field" width="-1" hidden="0"/>
      <column name="featno1" type="field" width="-1" hidden="0"/>
      <column name="label_3" type="field" width="-1" hidden="0"/>
      <column name="type_3" type="field" width="-1" hidden="0"/>
      <column name="subtyp3" type="field" width="-1" hidden="0"/>
      <column name="spec_3" type="field" width="-1" hidden="0"/>
      <column name="dim1_3" type="field" width="-1" hidden="0"/>
      <column name="dim2_3" type="field" width="-1" hidden="0"/>
      <column name="cblcpty3" type="field" width="-1" hidden="0"/>
      <column name="conntr3" type="field" width="-1" hidden="0"/>
      <column name="featno2" type="field" width="-1" hidden="0"/>
      <column name="strtfeat" type="field" width="-1" hidden="0"/>
      <column name="endfeat" type="field" width="-1" hidden="0"/>
      <column name="lat" type="field" width="-1" hidden="0"/>
      <column name="lon" type="field" width="-1" hidden="0"/>
      <column name="sg21" type="field" width="-1" hidden="0"/>
      <column name="sg26" type="field" width="-1" hidden="0"/>
      <column name="address" type="field" width="-1" hidden="0"/>
      <column name="pon_no" type="field" width="-1" hidden="0"/>
      <column name="zone_no" type="field" width="-1" hidden="0"/>
      <column name="subplace" type="field" width="-1" hidden="0"/>
      <column name="mainplce" type="field" width="-1" hidden="0"/>
      <column name="mun" type="field" width="-1" hidden="0"/>
      <column name="stackref" type="field" width="-1" hidden="0"/>
      <column name="datecrtd" type="field" width="-1" hidden="0"/>
      <column name="crtdby" type="field" width="-1" hidden="0"/>
      <column name="date_edt" type="field" width="-1" hidden="0"/>
      <column name="editby" type="field" width="-1" hidden="0"/>
      <column name="comments" type="field" width="-1" hidden="0"/>
      <column type="actions" width="-1" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="address" editable="1"/>
    <field name="cblcpty1" editable="1"/>
    <field name="cblcpty2" editable="1"/>
    <field name="cblcpty3" editable="1"/>
    <field name="cmpownr" editable="1"/>
    <field name="comments" editable="1"/>
    <field name="conntr1" editable="1"/>
    <field name="conntr2" editable="1"/>
    <field name="conntr3" editable="1"/>
    <field name="crtdby" editable="1"/>
    <field name="date_edt" editable="1"/>
    <field name="datecrtd" editable="1"/>
    <field name="dim1" editable="1"/>
    <field name="dim1_2" editable="1"/>
    <field name="dim1_3" editable="1"/>
    <field name="dim2" editable="1"/>
    <field name="dim2_2" editable="1"/>
    <field name="dim2_3" editable="1"/>
    <field name="editby" editable="1"/>
    <field name="endfeat" editable="1"/>
    <field name="featno1" editable="1"/>
    <field name="featno2" editable="1"/>
    <field name="label_1" editable="1"/>
    <field name="label_2" editable="1"/>
    <field name="label_3" editable="1"/>
    <field name="lat" editable="1"/>
    <field name="lon" editable="1"/>
    <field name="mainplce" editable="1"/>
    <field name="mun" editable="1"/>
    <field name="pon_no" editable="1"/>
    <field name="sg21" editable="1"/>
    <field name="sg26" editable="1"/>
    <field name="spec_1" editable="1"/>
    <field name="spec_2" editable="1"/>
    <field name="spec_3" editable="1"/>
    <field name="stackref" editable="1"/>
    <field name="strtfeat" editable="1"/>
    <field name="subplace" editable="1"/>
    <field name="subtyp3" editable="1"/>
    <field name="subtyp_1" editable="1"/>
    <field name="subtyp_2" editable="1"/>
    <field name="type_1" editable="1"/>
    <field name="type_2" editable="1"/>
    <field name="type_3" editable="1"/>
    <field name="zone_no" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="address" labelOnTop="0"/>
    <field name="cblcpty1" labelOnTop="0"/>
    <field name="cblcpty2" labelOnTop="0"/>
    <field name="cblcpty3" labelOnTop="0"/>
    <field name="cmpownr" labelOnTop="0"/>
    <field name="comments" labelOnTop="0"/>
    <field name="conntr1" labelOnTop="0"/>
    <field name="conntr2" labelOnTop="0"/>
    <field name="conntr3" labelOnTop="0"/>
    <field name="crtdby" labelOnTop="0"/>
    <field name="date_edt" labelOnTop="0"/>
    <field name="datecrtd" labelOnTop="0"/>
    <field name="dim1" labelOnTop="0"/>
    <field name="dim1_2" labelOnTop="0"/>
    <field name="dim1_3" labelOnTop="0"/>
    <field name="dim2" labelOnTop="0"/>
    <field name="dim2_2" labelOnTop="0"/>
    <field name="dim2_3" labelOnTop="0"/>
    <field name="editby" labelOnTop="0"/>
    <field name="endfeat" labelOnTop="0"/>
    <field name="featno1" labelOnTop="0"/>
    <field name="featno2" labelOnTop="0"/>
    <field name="label_1" labelOnTop="0"/>
    <field name="label_2" labelOnTop="0"/>
    <field name="label_3" labelOnTop="0"/>
    <field name="lat" labelOnTop="0"/>
    <field name="lon" labelOnTop="0"/>
    <field name="mainplce" labelOnTop="0"/>
    <field name="mun" labelOnTop="0"/>
    <field name="pon_no" labelOnTop="0"/>
    <field name="sg21" labelOnTop="0"/>
    <field name="sg26" labelOnTop="0"/>
    <field name="spec_1" labelOnTop="0"/>
    <field name="spec_2" labelOnTop="0"/>
    <field name="spec_3" labelOnTop="0"/>
    <field name="stackref" labelOnTop="0"/>
    <field name="strtfeat" labelOnTop="0"/>
    <field name="subplace" labelOnTop="0"/>
    <field name="subtyp3" labelOnTop="0"/>
    <field name="subtyp_1" labelOnTop="0"/>
    <field name="subtyp_2" labelOnTop="0"/>
    <field name="type_1" labelOnTop="0"/>
    <field name="type_2" labelOnTop="0"/>
    <field name="type_3" labelOnTop="0"/>
    <field name="zone_no" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="address" reuseLastValue="0"/>
    <field name="cblcpty1" reuseLastValue="0"/>
    <field name="cblcpty2" reuseLastValue="0"/>
    <field name="cblcpty3" reuseLastValue="0"/>
    <field name="cmpownr" reuseLastValue="0"/>
    <field name="comments" reuseLastValue="0"/>
    <field name="conntr1" reuseLastValue="0"/>
    <field name="conntr2" reuseLastValue="0"/>
    <field name="conntr3" reuseLastValue="0"/>
    <field name="crtdby" reuseLastValue="0"/>
    <field name="date_edt" reuseLastValue="0"/>
    <field name="datecrtd" reuseLastValue="0"/>
    <field name="dim1" reuseLastValue="0"/>
    <field name="dim1_2" reuseLastValue="0"/>
    <field name="dim1_3" reuseLastValue="0"/>
    <field name="dim2" reuseLastValue="0"/>
    <field name="dim2_2" reuseLastValue="0"/>
    <field name="dim2_3" reuseLastValue="0"/>
    <field name="editby" reuseLastValue="0"/>
    <field name="endfeat" reuseLastValue="0"/>
    <field name="featno1" reuseLastValue="0"/>
    <field name="featno2" reuseLastValue="0"/>
    <field name="label_1" reuseLastValue="0"/>
    <field name="label_2" reuseLastValue="0"/>
    <field name="label_3" reuseLastValue="0"/>
    <field name="lat" reuseLastValue="0"/>
    <field name="lon" reuseLastValue="0"/>
    <field name="mainplce" reuseLastValue="0"/>
    <field name="mun" reuseLastValue="0"/>
    <field name="pon_no" reuseLastValue="0"/>
    <field name="sg21" reuseLastValue="0"/>
    <field name="sg26" reuseLastValue="0"/>
    <field name="spec_1" reuseLastValue="0"/>
    <field name="spec_2" reuseLastValue="0"/>
    <field name="spec_3" reuseLastValue="0"/>
    <field name="stackref" reuseLastValue="0"/>
    <field name="strtfeat" reuseLastValue="0"/>
    <field name="subplace" reuseLastValue="0"/>
    <field name="subtyp3" reuseLastValue="0"/>
    <field name="subtyp_1" reuseLastValue="0"/>
    <field name="subtyp_2" reuseLastValue="0"/>
    <field name="type_1" reuseLastValue="0"/>
    <field name="type_2" reuseLastValue="0"/>
    <field name="type_3" reuseLastValue="0"/>
    <field name="zone_no" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"label_1"</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
