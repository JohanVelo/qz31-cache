# Fibertime: Label Poles Algorithm (MOA standard)

from qgis.core import (
    QgsProcessingParameterVectorLayer,
    QgsProcessing
)

from .base_algorithm import BaseFiberAlgorithm

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass


class FTPolesAlgorithm(BaseFiberAlgorithm):
    """Populate Fibertime Poles v1 coordinate and static fields (MOA standard)."""

    def name(self):
        return 'ft_label_poles'

    def displayName(self):
        return 'FT 1. Label Poles'

    def group(self):
        return 'Fibertime Network Labeling'

    def groupId(self):
        return 'fibertimenetworklabeling'

    def shortHelpString(self):
        return """
        Populate Fibertime Poles v1 coordinate and static fields.

        Does NOT modify the pole label field — labels are pre-populated
        via null_label_poles_population.py.

        Fields updated:
        - X: longitude (EPSG:4326)
        - Y: latitude (EPSG:4326)
        - companyown: VelocityFibre
        - createdby: Johan Scholtz
        - municipal: JB Marks LM
        - subplace: 676007
        - mainplace: 676007
        - stack: MOA

        Note: `status` is NOT written by FT1 — it is owned by the field
        permissions team (removed 2026-04-28).

        Fields skipped if not present in layer (warning only).
        """

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT,
                'Poles v1 Layer',
                [QgsProcessing.SourceType.TypeVectorPoint]
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        feedback.pushInfo(f"Populating Fibertime Poles v1 — {layer.name()}...")

        # Build field index map (only for fields that exist)
        def idx(name):
            return layer.fields().indexOf(name)

        # Static fields — fill-null-only per merge-not-override pattern.
        # `status` is OWNED by the field permissions team (manual). FT1 must
        # NEVER auto-write it. Removed from this dict 2026-04-28.
        static = {
            "companyown": "VelocityFibre",
            "cmpownr":    "VelocityFibre",
            "createdby":  "Johan Scholtz",
            "crtdby":     "Johan Scholtz",
            "municipal":  "JB Marks LM",
            "mun":        "JB Marks LM",
            "subplace":   "676007",
            "mainplace":  "676007",
            "mainplce":   "676007",
            "stack":      "MOA",
            "stackref":   "MOA",
        }
        # Coordinate fields — FT1 IS source of truth: always recompute from geometry
        x_idx   = idx("X")
        y_idx   = idx("Y")
        lon_idx = idx("lon")
        lat_idx = idx("lat")

        try:
            from qgis.core import NULL
        except Exception:
            NULL = None

        def _is_blank(v):
            if v is None: return True
            if NULL is not None:
                try:
                    if v == NULL: return True
                except Exception: _swallowed_note()
            if isinstance(v, str) and v.strip() in ('', 'NULL', 'null', 'None'):
                return True
            return False

        total = layer.featureCount()
        attr_map = {}
        for i, feat in enumerate(layer.getFeatures()):
            if feedback.isCanceled():
                return {}
            row = {}
            # Static fields: only write if currently NULL (preserve manual edits)
            for fname, val in static.items():
                fidx = idx(fname)
                if fidx < 0:
                    continue
                if _is_blank(feat[fname]):
                    row[fidx] = val
            # Coords: FT1 owns these — always sync to geometry
            geom = feat.geometry()
            if geom and not geom.isEmpty():
                pt = geom.asPoint()
                if x_idx >= 0:
                    row[x_idx] = pt.x()
                if y_idx >= 0:
                    row[y_idx] = pt.y()
                if lon_idx >= 0:
                    row[lon_idx] = round(pt.x(), 6)
                if lat_idx >= 0:
                    row[lat_idx] = round(pt.y(), 6)
            if row:
                attr_map[feat.id()] = row
            if total > 0:
                feedback.setProgress(int(i / total * 100))

        if attr_map:
            layer.dataProvider().changeAttributeValues(attr_map)
        layer.triggerRepaint()
        feedback.pushInfo(f"[OK] Poles fields populated — {len(attr_map)} features updated.")
        return {self.INPUT: layer.id()}

    def createInstance(self):
        return FTPolesAlgorithm()
