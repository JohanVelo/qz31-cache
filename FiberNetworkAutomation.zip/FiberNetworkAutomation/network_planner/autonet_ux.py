"""Pass 2 (AutoNet) — pure, unit-testable helper for the run report.

The 5-step AutoNet pipeline itself lives in ``on_autonet_clicked`` and is NOT touched.
This turns the record of completed steps into clean summary lines shown when the run
finishes, so the planner sees exactly what was built and how long it took. Pure Python
— no QGIS objects — so it is fully testable on its own.
"""


def format_run_report(steps, total_seconds=None):
    """Render an AutoNet run report from a list of step records.

    ``steps`` is a list of dicts with keys: ``step`` (int), ``label`` (str),
    ``layer`` (str | None — the output layer name), ``count`` (int | None — its
    feature count), ``seconds`` (float | None — how long the step took), and ``ok``
    (bool — whether the step produced its output). Returns a list of strings.
    """
    lines = ["── AutoNet run report ─────────────────────────"]
    for s in (steps or []):
        mark = "✓" if s.get("ok", True) else "⚠"
        piece = f"  {mark} Step {s.get('step')}  {s.get('label', '')}".rstrip()
        if s.get("layer"):
            piece += f" → {s['layer']}"
        if s.get("count") is not None:
            piece += f" ({s['count']} features)"
        secs = s.get("seconds")
        if secs is not None:
            piece += f"  · {secs:.1f}s"
        lines.append(piece)
    if total_seconds is not None:
        lines.append(f"  ⏱ total {total_seconds:.1f}s")
    return lines
