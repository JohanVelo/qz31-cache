# The canonical HeroTel layer + attribute schema, and the checks over it.
#
# HeroTel never supplied a schema - their spec set has a governing LABELLING
# standard and nothing else, and their own status table says "Layer schema
# definition — Pending". So `schema.yaml` is DERIVED from the three delivered
# towns HeroTel accepted (Middelburg Rev1.4, Botchabelo Rev1.3, Barberton
# Rev1.0), which share an identical 16-layer core.
#
# Everything here is READ-ONLY. `core.check()` cannot write, because a
# LayerView has no write path at all. Turning a finding into a fix is the
# mapper's job, and the mapper always writes to a NEW GeoPackage.

from .core import (ERROR, INFO, VALUE_SAMPLE, WARN, Finding, LayerView,
                   check, load_schema, normalise_name, normalise_value,
                   summarise)
from .views import from_ogr, from_qgis

__all__ = [
                   "ERROR",
                   "INFO",
                   "VALUE_SAMPLE",
                   "WARN",
                   "Finding",
                   "LayerView",
                   "check",
                   "from_ogr",
                   "from_qgis",
                   "load_schema",
                   "normalise_name",
                   "normalise_value",
                   "summarise",
]
