"""Full correctness audit of MOA_Splice_Plan_v9.xlsx (Cover + Port Allocations + Feeder
+ per-PON cross-consistency) vs live ground truth. Reports ERRORS and WARNINGS."""
import re, json
from collections import Counter, defaultdict
import openpyxl

XLSX = "C:/Temp/_v9_audit2.xlsx"           # byte-identical copy of the open v9
with open("C:/Temp/splice_gt.json") as _f:
    gt = json.load(_f)
with open("C:/Temp/splice_data.json") as _f:
    data = json.load(_f)
ont_set = set(gt['ont'])
pon_ont = {int(k): int(v) for k, v in data['pon_ont_counts'].items() if str(k).isdigit()}
OLT_OFF = {15: 224, 16: 240, 17: 256, 18: 272, 19: 288}
def pon_of(p):
    m = re.match(r'C(\d+)P(\d+)', p); return OLT_OFF.get(int(m.group(1)), -1000) + int(m.group(2))
def zone_of(pon): return (pon - 235) // 16 + 17

errs, warns = [], []
def E(m): errs.append(m)
def W(m): warns.append(m)

wb = openpyxl.load_workbook(XLSX, read_only=False, data_only=True)
ports = sorted([s for s in wb.sheetnames if re.match(r'^C\d\dP\d\d$', s)], key=pon_of)
pons  = [pon_of(p) for p in ports]

# ── per-PON sheet pass: collect DRs, filled/spare, FTS, title ──────────────────
sheet = {}
all_dr = Counter()
for p in ports:
    ws = wb[p]
    title = ws.cell(1, 1).value or ""
    fts = ws.cell(3, 17).value
    filled = spare = 0
    sts_blocks = defaultdict(lambda: [0, 0])
    r = 7
    while r < 6000:
        a = ws.cell(r, 1).value; s = ws.cell(r, 8).value
        if a is None and s is None: break
        if s:
            dr = ws.cell(r, 10).value
            if dr and str(dr).upper() == 'SPARE':
                spare += 1; sts_blocks[s][1] += 1
            elif dr:
                filled += 1; sts_blocks[s][0] += 1
                all_dr[str(dr)] += 1
                if ('MOA.ONT.' + str(dr)) not in ont_set:
                    E(f"[{p}] DR {dr} has no matching ONT in live layer")
        r += 1
    for s, (f, sp) in sts_blocks.items():
        if f + sp != 16:
            E(f"[{p}] STS {s} has {f+sp} ports (expected 16)")
    sheet[p] = {'title': title, 'fts': fts, 'filled': filled, 'spare': spare}

# DR global integrity
dups = {d: c for d, c in all_dr.items() if c > 1}
if dups: E(f"{len(dups)} DR numbers appear >1 time across workbook e.g. {list(dups)[:5]}")
print(f"DR placed: {sum(all_dr.values())}  distinct: {len(all_dr)}  dup: {len(dups)}")

# ── Cover sheet ────────────────────────────────────────────────────────────────
cov = wb['Cover']
cov_txt = {}
for row in cov.iter_rows(values_only=True):
    cells = [c for c in row if c not in (None, '')]
    if len(cells) >= 2 and isinstance(cells[0], str):
        cov_txt[cells[0].strip()] = cells[1]
def cov_has(label, expect):
    v = str(cov_txt.get(label, ''))
    if str(expect) not in v: E(f"[Cover] '{label}' = '{v}'  (expected to contain '{expect}')")
exp_total = sum(pon_ont.values())
cov_has('PON Range', f"{min(pons)} – {max(pons)}")
cov_has('PON Range', f"{len(pons)} PON")
cov_has('Total ONTs', f"{exp_total:,}")
cov_has('OLT Port Range', f"{ports[0]} – {ports[-1]}")
cov_has('AGG Domes (FTS splice)', str(len(gt['agg'])))
cov_has('DIS Domes (STS connect)', str(len(gt['dis'])))

# ── Port Allocations ───────────────────────────────────────────────────────────
pa = wb['Port Allocations']
pa_rows = [r for r in pa.iter_rows(min_row=2, values_only=True) if r and r[0]]
if len(pa_rows) != len(ports): E(f"[PortAlloc] {len(pa_rows)} rows != {len(ports)} ports")
pa_units_sum = 0
seen_ports = set()
for r in pa_rows:
    olt, card, port_n, fibre, cable, pon, zone, units, fillpct = r[:9]
    if card is None or port_n is None:
        E(f"[PortAlloc row] missing card/port in row {r}"); continue
    key = f"C{card}P{int(port_n):02d}"
    seen_ports.add(key)
    if pon != OLT_OFF.get(int(card), 0) + int(port_n):
        E(f"[PortAlloc {key}] PON {pon} != computed {OLT_OFF.get(int(card),0)+int(port_n)}")
    if zone != zone_of(pon):
        E(f"[PortAlloc {key}] zone {zone} != computed {zone_of(pon)}")
    exp_u = pon_ont.get(int(pon))
    if exp_u is not None and units != exp_u:
        W(f"[PortAlloc {key}] units {units} != ONT-count {exp_u}")
    try:
        exp_pct = round(int(units) / 128 * 100, 1)
        if str(fillpct).rstrip('%') and abs(float(str(fillpct).rstrip('%')) - exp_pct) > 0.05:
            E(f"[PortAlloc {key}] fill% {fillpct} != {exp_pct}%")
    except Exception: pass
    pa_units_sum += int(units) if units is not None else 0
miss = set(ports) - seen_ports
if miss: E(f"[PortAlloc] missing port rows: {sorted(miss)}")
if pa_units_sum != exp_total:
    W(f"[PortAlloc] sum(units)={pa_units_sum} != total ONTs {exp_total}")

# ── Feeder sheet: 66 rows, FTS matches per-PON sheet ──────────────────────────
fd = wb['Feeder']
fd_rows = [r for r in fd.iter_rows(min_row=3, values_only=True) if r and r[1]]  # col2=POP port
fd_map = {}
for r in fd_rows:
    pop = r[1]
    fts_cell = next((c for c in r if isinstance(c, str) and c.startswith('MOA.FTS')), None)
    fd_map[pop] = fts_cell
if len(fd_rows) != len(ports): E(f"[Feeder] {len(fd_rows)} rows != {len(ports)}")
for p in ports:
    if fd_map.get(p) != sheet[p]['fts']:
        E(f"[Feeder] {p} FTS '{fd_map.get(p)}' != per-PON sheet FTS '{sheet[p]['fts']}'")

# ── Cross-sheet: title PON/zone, units vs filled drops ────────────────────────
for p in ports:
    pon = pon_of(p)
    t = sheet[p]['title']
    if f"PON {pon}" not in str(t): E(f"[{p}] title PON mismatch: {t}")
    if f"Zone {zone_of(pon)}" not in str(t): E(f"[{p}] title Zone mismatch: {t}")
    # units (ONT pon_no count) vs filled drops actually placed (topology)
    u = pon_ont.get(pon); fl = sheet[p]['filled']
    if u is not None and u != fl:
        W(f"[{p}] PON {pon}: ONT-count(units)={u} != drops placed on sheet={fl} (delta {u-fl})")

print(f"\nTotal ONTs (cover expects): {exp_total}")
print(f"Sum drops placed on sheets : {sum(s['filled'] for s in sheet.values())}")
print(f"ERRORS  : {len(errs)}")
for e in errs[:60]: print("  E ", e)
print(f"WARNINGS: {len(warns)}")
for w in warns[:40]: print("  W ", w)
