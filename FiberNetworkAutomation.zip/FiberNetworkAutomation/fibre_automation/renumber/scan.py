"""scan — find every numbering system in a project and report its true state.

You cannot safely renumber what you have not measured. Before anything is
changed, this answers, per system: how many, what range, WHICH NUMBERS ARE
ALREADY MISSING, are there duplicates, how is it padded, and — the one that
bites — EVERY field the number is written into.

The three facts that shaped this module (probed live on Malmsbury 2026-07-15):

  * `SP##` in a joint's name IS the PON number. Dome Joints 485/485 and Feeder
    Joints 37/37 match the PON polygon they physically sit inside. So `SP` is a
    REFERENCE (``follows="PON"``), not an id — it never gets its own sequence, it
    rides on PON's remap. Miss this and renumbering a PON silently points a whole
    sub-network at the wrong one, invisibly.
  * `DJ` is ONE numbering space spread across TWO layers (Dome Joints + Feeder
    Joints). Renumber them separately and they collide → ``shared=True``.
  * `DC` and `FC/LC` write their number in TWO fields (``Name`` AND
    ``"Feeder Cab"``). Rewrite one and not the other and the row contradicts
    itself → ``fields`` is a list, always.

Design rules (match historical quantity take-off implementation + tagging/zone_tag.py):
  * READ-ONLY. Nothing here writes. Ever.
  * SCHEMA-AGNOSTIC — systems come from a client config; nothing is hardcoded to
    HeroTel or Fibertime.
  * HONEST — an unparseable value is reported, never quietly skipped, because a
    feature we cannot read is a feature we cannot renumber.
  * No Qt at module level; qgis imports are function-local (unit-testable).
"""
import re

# ── the client config ────────────────────────────────────────────────────────
# A NumberSpec says: this number lives in these layers, in these fields, matched
# by this pattern. Everything else is derived by measuring the data.
#
# min_width: the SMALLEST number of digits a value is written with. Malmsbury is
#   "natural" for DR/DJ (DR1 .. DR3622) but zero-padded elsewhere (P001, DC01,
#   MMB_0001PL, 001MH). Measured, not assumed — see `_measure_width`.


class NumberSpec:
    """One numbering system (an id like PON/DR, or a reference like SP)."""

    def __init__(self, name, layers, fields, pattern, min_width=1,
                 shared=False, follows=None, label="", by_feature=False,
                 numeric=False, one_per=()):
        self.name = name
        self.layers = list(layers)          # layer NAMES (matched case-insensitively)
        self.fields = list(fields)          # every field the number is written in
        self.pattern = pattern              # ONE capture group = the digits
        # one_per: which layers must carry EXACTLY ONE entry per target number, and
        #   WHICH ROWS COUNT. Either a plain list of layer names, or
        #   {layer: (field, regex)} to count only the rows whose `field` matches.
        #
        #   That filter is not decoration. "One feeder joint per PON" is wrong —
        #   the rule is one SPLITTER per PON, and the Feeder Joints layer also holds
        #   plain joints. Malmsbury: 37 rows but Splitters is '1:16' on exactly 35
        #   and 'No Splitter' on 2. Counting ROWS said P013 had 3 FTS (a false alarm
        #   — it has 1 splitter + 2 plain joints); counting SPLITTERS says what is
        #   really true: 35 splitters for 35 PONs, but P014 has 2 and P019 has 0,
        #   so one of P014's is almost certainly P019's, mislabelled. Found by
        #   studying the data 2026-07-16.
        self.one_per = dict(one_per) if isinstance(one_per, dict) else \
            {str(n): None for n in one_per}
        # by_feature: this number is a ROW NUMBER, not an identity anything else
        #   points at (the plain `id` column). So every FEATURE gets the next
        #   number — which also means duplicates simply resolve themselves instead
        #   of blocking (Trenching.id has 11 dupes today). A PON is the opposite:
        #   its number IS its identity, so it renumbers per VALUE and duplicates
        #   are a hard stop.
        self.by_feature = bool(by_feature)
        # numeric: the field is an integer column, so write an int, not "274"
        self.numeric = bool(numeric)
        # int, or {field: int} — the SAME system can be written differently in
        # different fields: Pons.PON is 'P001' (3-wide) but Pons."Label." is
        # 'Malmesbury Pon 07' (2-wide). One width for both writes 'Pon 015'.
        self.min_width = min_width
        self.shared = bool(shared)          # one space across several layers
        self.follows = follows              # this is a REFERENCE to that system
        self.label = label or name

    def width_for(self, field):
        """Minimum digits for `field` — per-field when the conventions differ."""
        if isinstance(self.min_width, dict):
            want = str(field).strip().lower()
            for k, v in self.min_width.items():
                if str(k).strip().lower() == want:
                    return v
            return self.min_width.get("*", 1)
        return self.min_width

    @property
    def is_reference(self):
        return self.follows is not None

    def to_dict(self):
        return {"name": self.name, "layers": self.layers, "fields": self.fields,
                "pattern": self.pattern, "min_width": self.min_width,
                "shared": self.shared, "follows": self.follows,
                "label": self.label, "by_feature": self.by_feature,
                "numeric": self.numeric, "one_per": self.one_per}

    @classmethod
    def from_dict(cls, d):
        return cls(d["name"], d.get("layers", []), d.get("fields", []),
                   d["pattern"], d.get("min_width", 1), d.get("shared", False),
                   d.get("follows"), d.get("label", ""),
                   d.get("by_feature", False), d.get("numeric", False),
                   d.get("one_per", ()))

    def __repr__(self):   # pragma: no cover - debug aid
        kind = f"->{self.follows}" if self.follows else "id"
        return f"NumberSpec({self.name} {kind} {self.layers}.{self.fields})"


def herotel_malmesbury_specs():
    """The Malmsbury HeroTel numbering, as measured live on 2026-07-15.

    Kept as code (not JSON) so the shape is reviewable; `to_dict`/`from_dict`
    round-trip it for a per-client JSON when a second client needs one.
    """
    return [
        # NB the per-field widths: 'P001' is 3-wide, 'Malmesbury Pon 07' is 2-wide.
        NumberSpec("PON", ["Pons"], ["PON", "Label."],
                   r"(?:^P|Pon\s*)(\d+)", min_width={"PON": 3, "Label.": 2},
                   label="PON"),
        # A REFERENCE, not an id.
        # NB the (?!\d) and NOT \b: real names include 'MMB_DJ351_SP16_S', and
        # `\b` NEVER matches between '6' and '_' because underscore is a word
        # character. The old r"_SP(\d+)\b" silently failed on 46 of 534 Dome
        # Joints — so they were never renumbered and never even flagged, which
        # means deleting their PON would have left them pointing at the wrong
        # one. Found 2026-07-15. (?!\d) = "digits not followed by more digits".
        # one_per=["Feeder Joints"]: the FTS is one-per-PON, so a PON with none —
        # or with three — is a real network error. Dome Joints are legitimately
        # many-per-PON, hence the per-layer rule rather than a blanket one.
        # one_per counts only Feeder Joints rows whose Splitters value is a real
        # ratio ('1:16'), NOT the plain joints ('No Splitter') that share the layer.
        NumberSpec("SP", ["Dome Joints", "Feeder Joints"], ["Name", "Label"],
                   r"_SP0*(\d+)(?!\d)", min_width=2, shared=True, follows="PON",
                   label="PON references (_SP)",
                   one_per={"Feeder Joints": ("Splitters", r"^\s*\d+\s*:\s*\d+\s*$")}),
        NumberSpec("DR", ["drops"], ["Name"], r"_DR(\d+)(?!\d)", min_width=1,
                   label="drops"),
        NumberSpec("DC", ["Distribution Cable"], ["Name", "Feeder Cab"],
                   r"(?:_DC|^DC)(\d+)(?!\d)", min_width=2,
                   label="distribution cable"),
        # DJ spans TWO layers as ONE space (570 of 572 numbers are unique across
        # both, over the same range — one allocation, split across two layers).
        # by_feature: nothing in the project REFERENCES a DJ number — it is a
        # label, not an identity — so each joint simply takes the next number and
        # the 2 accidental collisions (259, 505) resolve themselves instead of
        # hard-blocking the whole run.
        NumberSpec("DJ", ["Dome Joints", "Feeder Joints"], ["Name", "Label"],
                   r"_DJ(\d+)(?!\d)", min_width=1, shared=True, by_feature=True,
                   label="joints"),
        NumberSpec("PL", ["poles"], ["Name."], r"_(\d+)PL(?!\w)", min_width=4,
                   label="poles"),
        NumberSpec("MH", ["Manholes"], ["Name"], r"_(\d+)MH(?!\w)", min_width=3,
                   label="manholes"),
    ]


ID_PREFIX = "ID:"          # id-column systems are named "ID:<layer>"
_ID_FIELDS = ("id", "fid")
_INT_TYPES = ("int", "integer", "integer64", "longlong", "long")


def is_shapefile(layer):
    try:
        return "shapefile" in (layer.dataProvider().storageType() or "").lower()
    except Exception:
        return False


def id_specs(project=None):
    """One spec per layer's plain `id` column — the row numbers in the table.

    JJ, looking at Dome Joints after a delete (2026-07-15): "you should renumber
    and relabel everything in all of the attribute tables so there is no gaps".
    The id column is exactly that — id 273 then 286, because 274..285 were the
    deleted features.

    One spec PER LAYER because each table's ids are its own sequence (both Dome
    Joints and 8Way Splitters run 1..533; they are not one shared space).
    by_feature=True: an id is a row number, not an identity — every feature gets
    the next one, so duplicates resolve instead of blocking.
    """
    from qgis.core import QgsProject, QgsVectorLayer
    project = project or QgsProject.instance()
    out = []
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
            continue
        for f in lyr.fields():
            if f.name().strip().lower() not in _ID_FIELDS:
                continue
            tn = (f.typeName() or "").lower()
            if not any(t in tn for t in _INT_TYPES):
                continue          # a text 'ID' (Erven) is a key, not a row number
            # `fid` is the real primary key on GPKG/Postgres — renumbering it
            # there would fight the provider. On a shapefile it is an ordinary
            # column and safe to compact.
            if f.name().strip().lower() == "fid" and not is_shapefile(lyr):
                continue
            out.append(NumberSpec(
                f"{ID_PREFIX}{lyr.name()}", [lyr.name()], [f.name()],
                r"^\s*(\d+)\s*$", min_width=1, by_feature=True, numeric=True,
                label=f"{lyr.name()} · {f.name()} column"))
            break              # one id column per layer
    out.sort(key=lambda s: s.name.lower())
    return out


# ── occurrences ──────────────────────────────────────────────────────────────
class Occurrence:
    """One place a number is written: (layer, feature, field) → number."""

    __slots__ = (
        "end",
        "fid",
        "field",
        "layer_id",
        "layer_name",
        "number",
        "start",
        "value",
        "width",
    )

    def __init__(self, layer_id, layer_name, fid, field, value, number, width,
                 start, end):
        self.layer_id = layer_id
        self.layer_name = layer_name
        self.fid = fid
        self.field = field
        self.value = value          # the whole original string
        self.number = number        # the parsed int
        self.width = width          # digits as written ("0306" -> 4)
        self.start = start          # span of the digits inside `value`
        self.end = end

    @property
    def zero_padded(self):
        """Was this value ACTUALLY zero-padded, or just a long number?

        The distinction the whole rewrite hangs on: `DR10` is 2 digits because
        10 has 2 digits, whereas `P016` is 3 because it was padded. You can only
        tell by comparing the written width to the number's natural length.
        Getting this wrong renumbers DR10 -> "DR09" instead of "DR9".
        """
        return self.width > len(str(self.number))

    def rewritten(self, new_number, min_width):
        """`value` with just the digits swapped — everything else untouched.

        Only the digit span is replaced, so prefixes/suffixes/case survive
        exactly. Width: an explicitly zero-padded value keeps its own width
        (P016 -> P015, MMB_0001PL -> MMB_0002PL); anything else uses the system's
        minimum, which is 1 for the natural systems (DR1000 -> DR999, DR10 -> DR9).
        zfill only ever pads, so a number that outgrows the width still fits.
        """
        w = self.width if self.zero_padded else min_width
        return self.value[:self.start] + str(new_number).zfill(w) + self.value[self.end:]


class SystemScan:
    """What a NumberSpec actually looks like in this project, right now."""

    def __init__(self, spec):
        self.spec = spec
        self.occurrences = []       # [Occurrence]
        self.unparsed = []          # ["layer.field fid=N value=…"] — reported, never guessed
        self.layers_missing = []    # configured layers not in the project
        self.fields_missing = []    # configured fields not on a layer

    # -- derived facts ------------------------------------------------------
    @property
    def numbers(self):
        return [o.number for o in self.occurrences]

    @property
    def distinct(self):
        return sorted(set(self.numbers))

    @property
    def count(self):
        return len(self.occurrences)

    @property
    def lo(self):
        d = self.distinct
        return d[0] if d else None

    @property
    def hi(self):
        d = self.distinct
        return d[-1] if d else None

    @property
    def gaps(self):
        """Numbers missing between lo and hi — the ones a compaction would close."""
        if not self.distinct:
            return []
        return sorted(set(range(self.lo, self.hi + 1)) - set(self.distinct))

    @property
    def widths(self):
        w = {}
        for o in self.occurrences:
            w[o.width] = w.get(o.width, 0) + 1
        return dict(sorted(w.items()))

    def entities(self):
        """number → the features carrying it.

        For an ID system this should be 1 feature per number; more than one means
        a genuine duplicate. For a REFERENCE (SP) many features legitimately share
        a number — that is the point of a reference, so it is never a duplicate.
        """
        out = {}
        for o in self.occurrences:
            out.setdefault(o.number, set()).add((o.layer_id, o.fid))
        return out

    @property
    def duplicates(self):
        """Numbers used by MORE THAN ONE feature. Empty for reference systems."""
        if self.spec.is_reference:
            return {}
        return {n: sorted(f) for n, f in self.entities().items() if len(f) > 1}

    def blast_radius(self, doomed=()):
        """How many OCCURRENCES a compaction would rewrite.

        The honest number for "what does ticking this cost me": every occurrence
        whose number would move. Note this counts gaps that ALREADY exist — on
        Malmsbury that is ~2,853 drops before a single deletion, which is exactly
        the surprise this method exists to surface.
        """
        survivors = [n for n in self.distinct if n not in set(doomed)]
        remap = {old: i for i, old in enumerate(survivors, start=1)}
        return sum(1 for o in self.occurrences
                   if o.number in remap and remap[o.number] != o.number)

    def summary(self):
        return {
            "name": self.spec.name,
            "label": self.spec.label,
            "is_reference": self.spec.is_reference,
            "follows": self.spec.follows,
            "shared": self.spec.shared,
            "occurrences": self.count,
            "features": len({(o.layer_id, o.fid) for o in self.occurrences}),
            "distinct": len(self.distinct),
            "lo": self.lo,
            "hi": self.hi,
            "gaps": self.gaps,
            "n_gaps": len(self.gaps),
            "duplicates": self.duplicates,
            "widths": self.widths,
            "unparsed": len(self.unparsed),
            "fields": sorted({(o.layer_name, o.field) for o in self.occurrences}),
        }


# ── the scan ─────────────────────────────────────────────────────────────────
def _layers_by_name(project, names):
    """Every valid vector layer whose name matches (case-insensitive)."""
    from qgis.core import QgsVectorLayer
    want = {n.strip().lower() for n in names}
    out = []
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
            continue
        if lyr.name().strip().lower() in want:
            out.append(lyr)
    return out


def _real_field(layer, name):
    want = str(name).strip().lower()
    for f in layer.fields():
        if f.name().strip().lower() == want:
            return f.name()
    return None


def scan_system(project, spec):
    """Measure one NumberSpec against the live project. READ-ONLY."""
    out = SystemScan(spec)
    rx = re.compile(spec.pattern)
    layers = _layers_by_name(project, spec.layers)
    found_names = {l.name().strip().lower() for l in layers}
    for want in spec.layers:
        if want.strip().lower() not in found_names:
            out.layers_missing.append(want)

    for lyr in layers:
        reals = []
        for fname in spec.fields:
            real = _real_field(lyr, fname)
            if real is not None:
                reals.append(real)
        if not reals:
            out.fields_missing.append(
                f"{lyr.name()}: none of {spec.fields}")
            continue
        for feat in lyr.getFeatures():
            for real in reals:
                v = feat[real]
                if v is None:
                    continue
                s = str(v)
                m = rx.search(s)
                if not m:
                    # Only a miss if the field looks like it should carry one.
                    # A blank/None is normal; a populated value that will not
                    # parse is a fact the user must see before renumbering.
                    if s.strip():
                        out.unparsed.append(
                            f"{lyr.name()}.{real} fid={feat.id()} value={s!r}")
                    continue
                digits = m.group(1)
                out.occurrences.append(Occurrence(
                    lyr.id(), lyr.name(), feat.id(), real, s, int(digits),
                    len(digits), m.start(1), m.end(1)))
    return out


def scan_project(project=None, specs=None):
    """Measure every system → {name: SystemScan}. READ-ONLY.

    Defaults to the label systems (PON/SP/DR/DC/DJ/PL/MH) PLUS an auto-detected
    id-column system per layer, because "no gaps in the attribute table" means
    the id column too.
    """
    from qgis.core import QgsProject
    project = project or QgsProject.instance()
    if specs is None:
        specs = herotel_malmesbury_specs() + id_specs(project)
    return {s.name: scan_system(project, s) for s in specs}


def validate(scans, project=None):
    """Problems that must be shown BEFORE any renumber. [] means clean.

    Not warnings-for-warnings'-sake: each of these is a way a renumber goes
    silently wrong, and every one of them is real on Malmsbury today.

    `project` is OPTIONAL and only enables the checks that need to read a field the
    number did not come from (one_per's qualifier — e.g. Feeder Joints.Splitters).
    Without it those checks are skipped rather than guessed at. Everything here is a
    WARNING; nothing here ever blocks a run.
    """
    out = []
    for name, sc in scans.items():
        if sc.spec.is_reference:
            target = scans.get(sc.spec.follows)
            if target is None:
                out.append(f"{name} references {sc.spec.follows}, which was not scanned.")
                continue
            # a reference pointing at a number that does not exist
            orphans = sorted(set(sc.distinct) - set(target.distinct))
            if orphans:
                out.append(f"{name}: {len(orphans)} value(s) point at a "
                           f"{sc.spec.follows} that does not exist: {orphans[:8]}")

            # one-per-target layers. The rule is one SPLITTER per PON, not one ROW —
            # the Feeder Joints layer also holds plain joints, and counting rows
            # produced a FALSE alarm ("P013 has 3 FTS" when it has 1 splitter + 2
            # plain joints). `qual` = (field, regex): only rows whose field matches
            # are real entries. Needs the project to read a field the number did not
            # come from, so this check is skipped when validate() is called without
            # one — it warns, it never blocks, so skipping it is safe.
            for lname, qual in getattr(sc.spec, "one_per", {}).items():
                per, kind = {}, "entr"
                keep = None
                if qual and project is not None:
                    qfield, qrx = qual
                    lyrs = _layers_by_name(project, [lname])
                    if lyrs:
                        rx = re.compile(qrx)
                        real = _real_field(lyrs[0], qfield)
                        if real:
                            keep = {f.id() for f in lyrs[0].getFeatures()
                                    if rx.match(str(f[real] or "").strip())}
                            kind = "splitter" if "split" in qfield.lower() else "entr"
                elif qual and project is None:
                    continue                       # cannot judge honestly — say nothing
                for o in sc.occurrences:
                    if str(o.layer_name).strip().lower() != str(lname).strip().lower():
                        continue
                    if keep is not None and o.fid not in keep:
                        continue                   # a row that is not a real entry
                    per.setdefault(o.number, []).append(o.value)
                if not per:
                    continue                       # layer absent — nothing to judge
                word = "splitter(s)" if kind == "splitter" else "entry/entries"
                empty = sorted(set(target.distinct) - set(per))
                if empty:
                    out.append(
                        f"{lname}: {len(empty)} {sc.spec.follows}(s) have NO {word} "
                        f"— {', '.join(str(n) for n in empty[:8])}"
                        + (" …" if len(empty) > 8 else "")
                        + ". The renumber cannot create one.")
                many = sorted(n for n, v in per.items() if len(v) > 1)
                for n in many[:4]:
                    vals = ", ".join(str(v) for v in per[n][:3])
                    out.append(
                        f"{lname}: {sc.spec.follows} {n} has {len(per[n])} {word} "
                        f"({vals}) — expected one. All of them will be renumbered; "
                        f"the tool cannot tell which is correct.")
                if len(many) > 4:
                    out.append(f"{lname}: …and {len(many) - 4} more "
                               f"{sc.spec.follows}(s) with more than one {word}.")
                # The counts hand you a real clue for free: if the TOTAL is right
                # but the distribution is off, the network has the correct AMOUNT of
                # gear, just assigned wrong. Say exactly that — and DO NOT claim which
                # way it goes. Whether one of PON N's is really PON M's (a label
                # error) or PON M genuinely lacks gear (a planning gap) can only be
                # settled by tracing the cables, which this scan does not do. An
                # earlier version asserted "most likely M's, mislabelled"; a cable
                # trace on Malmsbury 2026-07-16 showed both P014 splitters genuinely
                # serve P014, so that assertion was wrong. Honest uncertainty only.
                if empty and many and len(per) + len(empty) == len(target.distinct):
                    tot = sum(len(v) for v in per.values())
                    if tot == len(target.distinct):
                        out.append(
                            f"{lname}: the COUNT is right ({tot} {word} for "
                            f"{len(target.distinct)} {sc.spec.follows}s) but the "
                            f"assignment is off — {sc.spec.follows} {many[0]} has a "
                            f"spare and {sc.spec.follows} {empty[0]} has none. Either "
                            f"a label is wrong or a splitter is misplaced; trace the "
                            f"cables to decide. The renumber leaves this untouched.")
        elif sc.duplicates and not sc.spec.by_feature:
            # Only an IDENTITY number is broken by duplicates: if two cables are
            # both DC07, renumbering cannot tell them apart.
            #
            # A by_feature number (the id columns, DJ) is a ROW NUMBER — plan.py
            # re-allocates it per surviving FEATURE, ordered by what it has now with
            # fid breaking ties, so duplicates resolve themselves by construction
            # ("Trenching.id has 11 dupes today and they are meaningless for a row
            # number"). Warning "cannot renumber safely until they are unique" for
            # those was a FALSE ALARM that scared the operator off a valid run —
            # and it fires on Malmsbury today (DJ [259, 505], Trenching id
            # [50, 97, 137]). Found 2026-07-16.
            out.append(f"{name}: {len(sc.duplicates)} duplicate number(s) — "
                       f"{sorted(sc.duplicates)[:6]} — cannot renumber safely "
                       f"until they are unique.")
        if sc.unparsed:
            out.append(f"{name}: {len(sc.unparsed)} value(s) could not be read, "
                       f"so they cannot be renumbered, e.g. {sc.unparsed[0]}")
        for miss in sc.layers_missing:
            out.append(f"{name}: layer '{miss}' is not in this project.")
    return out
