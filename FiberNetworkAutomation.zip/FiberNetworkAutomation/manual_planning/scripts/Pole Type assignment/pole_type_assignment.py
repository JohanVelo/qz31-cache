import sys, os
if sys.stderr is None: sys.stderr = open(os.devnull, 'w')
if sys.stdout is None: sys.stdout = open(os.devnull, 'w')

# ============================================================
# POLE TYPE ASSIGNMENT
# Project: Fibre Time (all projects)
# Logic:   For each pole, find the nearest Primary, Secondary,
#          and Distribution cable.  Whichever is closest
#          (within TOLERANCE) wins — closest-distance-wins rule.
# Fallback: dim1 field value if no cable within tolerance.
# Field updated: 'Pole Type'
# ============================================================

POLES_LAYER_NAME     = 'poles v1'
PRIMARY_LAYER_NAME   = 'Primary Cable v1'
SECONDARY_LAYER_NAME = 'Secondary Cable v1'
DISTRIB_LAYER_NAME   = 'Distribution Cable v1'
TOLERANCE            = 5.0   # metres — adjust if needed

# --- GET LAYERS ---
poles_lyr = prim_lyr = sec_lyr = dist_lyr = None
for lyr in QgsProject.instance().mapLayers().values():
    n = lyr.name()
    if n == POLES_LAYER_NAME:     poles_lyr = lyr
    elif n == PRIMARY_LAYER_NAME:   prim_lyr  = lyr
    elif n == SECONDARY_LAYER_NAME: sec_lyr   = lyr
    elif n == DISTRIB_LAYER_NAME:   dist_lyr  = lyr

missing = [n for n, l in [
    (POLES_LAYER_NAME, poles_lyr),
    (PRIMARY_LAYER_NAME, prim_lyr),
    (SECONDARY_LAYER_NAME, sec_lyr),
    (DISTRIB_LAYER_NAME, dist_lyr),
] if not l]

if missing:
    print(f"ERROR: Missing layers: {missing}")
    print("Update the layer name variables at the top of this script to match your project.")
else:
    from qgis.core import QgsSpatialIndex

    print(f"Poles layer:       {POLES_LAYER_NAME} ({poles_lyr.featureCount()} features)")
    print(f"Primary Cable:     {PRIMARY_LAYER_NAME} ({prim_lyr.featureCount()} features)")
    print(f"Secondary Cable:   {SECONDARY_LAYER_NAME} ({sec_lyr.featureCount()} features)")
    print(f"Distribution Cable:{DISTRIB_LAYER_NAME} ({dist_lyr.featureCount()} features)")
    print("Building spatial indices...")

    prim_index = QgsSpatialIndex(prim_lyr.getFeatures())
    sec_index  = QgsSpatialIndex(sec_lyr.getFeatures())
    dist_index = QgsSpatialIndex(dist_lyr.getFeatures())
    prim_feats = {f.id(): f for f in prim_lyr.getFeatures()}
    sec_feats  = {f.id(): f for f in sec_lyr.getFeatures()}
    dist_feats = {f.id(): f for f in dist_lyr.getFeatures()}
    print("✅ Spatial indices ready.")

    def nearest_dist(index, feats, pole_geom):
        """Distance from pole_geom to the nearest cable in the given layer."""
        candidates = index.nearestNeighbor(pole_geom.centroid().asPoint(), 3)
        best = float('inf')
        for fid in candidates:
            d = pole_geom.distance(feats[fid].geometry())
            if d < best:
                best = d
        return best

    pt_idx = poles_lyr.fields().indexOf('Pole Type')
    if pt_idx == -1:
        print("ERROR: 'Pole Type' field not found in poles layer.")
    else:
        attr_map   = {}
        total      = poles_lyr.featureCount()
        spatial    = 0
        fallback   = 0
        unresolved = 0

        print(f"\nProcessing {total} poles...")

        for i, pole in enumerate(poles_lyr.getFeatures()):
            geom = pole.geometry()
            if not geom or geom.isNull() or geom.isEmpty():
                unresolved += 1
                continue

            d_prim = nearest_dist(prim_index, prim_feats, geom)
            d_sec  = nearest_dist(sec_index,  sec_feats,  geom)
            d_dist = nearest_dist(dist_index, dist_feats, geom)

            min_d = min(d_prim, d_sec, d_dist)

            if min_d <= TOLERANCE:
                # Closest-distance-wins — never priority order
                if d_prim == min_d:
                    pole_type = 'Primary Feeder'
                elif d_sec == min_d:
                    pole_type = 'Secondary Feeder'
                else:
                    pole_type = 'Distribution'
                spatial += 1
            else:
                # Attribute fallback using dim1
                dim1 = str(pole['dim1'] or '').strip()
                if dim1 == '120-140mm':
                    pole_type = 'Distribution'
                    fallback += 1
                elif dim1 in ('140-160mm', '160-180mm'):
                    pole_type = 'Secondary Feeder'
                    fallback += 1
                else:
                    pole_type = None
                    unresolved += 1

            if pole_type:
                attr_map[pole.id()] = {pt_idx: pole_type}

            if (i + 1) % 200 == 0:
                print(f"  ...{i + 1}/{total} processed")

        poles_lyr.dataProvider().changeAttributeValues(attr_map)

        print("=" * 50)
        print(f"✅ DONE — {total} poles processed")
        print(f"  Spatial match (closest):  {spatial}")
        print(f"  Attribute fallback:        {fallback}")
        print(f"  ⚠️  Unresolved (NULL):     {unresolved}  ← review these manually")
        print("=" * 50)
        if unresolved:
            print("TIP: Filter 'Pole Type' IS NULL in the attribute table to find unresolved poles.")
