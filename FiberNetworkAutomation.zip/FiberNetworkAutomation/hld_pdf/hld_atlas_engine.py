# -*- coding: utf-8 -*-
# ============================================================================
# HLD Atlas Engine  (Phase 0 — config-driven)
# ----------------------------------------------------------------------------
# Builds two editable QgsPrintLayouts in the CURRENT project:
#     <layout_overview>  (1 page: PON numbers + feeder routes)
#     <layout_atlas>     (N pages: one per coverage feature, full detail)
# A3 landscape, big map + sidebar (Legend / North / logo / title block),
# matching the Phase 1 reference deliverable.
#
# Idempotent: removes+recreates its own layouts each run. Does NOT export
# (export is a separate headless step — never render a big atlas on the GUI thread).
#
# DE-HARDCODED: every project-specific value lives in DEFAULT_CFG below.
# A caller injects overrides by defining a dict `HLD_CFG` in the namespace
# BEFORE exec()'ing this file, e.g.:
#     ns = {"HLD_CFG": {...}}
#     exec(open("hld_atlas_engine.py").read(), ns)
# With no HLD_CFG defined, it reproduces the Mohadin Phase 2 PDF exactly.
# ============================================================================
import os
import copy
from qgis.core import (
    QgsProject, QgsPrintLayout, QgsLayoutItemPage, QgsLayoutItemMap,
    QgsLayoutItemLabel, QgsLayoutItemPicture, QgsLayoutItemShape,
    QgsLayoutPoint, QgsLayoutSize, QgsUnitTypes, QgsRectangle, QgsLayoutMeasurement,
)
from qgis.PyQt.QtGui import QColor, QFont

# ---------------------------------------------------------------------------
# DEFAULT CONFIG = Mohadin Phase 2 (the proven deliverable).
# ---------------------------------------------------------------------------
DEFAULT_CFG = {
    # --- identity / title block ---
    "project_name":   "Mohadin Phase 2",
    "company":        "Velocity Fibre",
    "designer":       "Johan Scholtz",
    "date_str":       "07-07-2026",
    "revision":       "1",
    "title_overview": "Mohadin Phase 2 Overview",
    "title_atlas_expr": 'Mohadin Phase 2 - PON [% "pon_no" %]',   # dynamic per-page

    # --- assets ---
    "logo_path":  r"C:/Temp/ph2_hld_assets/fibertime_logo.png",
    "legend_dir": r"C:/Temp/ph2_hld_assets/legend",

    # --- layout names (this engine owns exactly these two) ---
    "layout_overview": "MOA PH2 HLD Overview",
    "layout_atlas":    "MOA PH2 HLD Atlas",

    # --- layer resolution ---
    "group_name":  "phase 2 hld",   # resolve layers inside this group (JJ renames v1->friendly)
    "aoi_layer":   "greenfield and overbuild poly",
    "aoi_subset":  '"Name" = \'Greenfield\'',   # only the Greenfield polygon; None to keep all
    "basemap":     "Google Satellite",

    # role -> ordered candidate layer names (first found wins; group first, then whole project)
    "roles": {
        "coverage":     ["PON v1"],
        "primary":      ["ADSS", "Primary Cable v1"],
        "secondary":    ["Secondary Cable v1", "Secondary Cable"],
        "distribution": ["Mini-ADSS", "Distribution Cable v1"],
        "drop":         ["Drop Cable", "Drop Cable v1"],
        "spare_drop":   ["Spare Drop Cable v1", "Spare Drop Cable"],
        "poles":        ["Pole", "poles v1"],
        "fts":          ["FTS Splitter", "FTS Splitters v1"],
        "sts":          ["STS Splitter", "STS Splitters v1"],
        "enc_splice":   ["Enclosures Splice v1", "Enclosures Splice"],
        "enc_conn":     ["Enclosures Connectorised v1", "Enclosures Connectorised"],
        "enclosure":    ["Enclosure v1"],
        "ont":          ["ONT v1"],
    },

    # detail-page layers when there is NO group (saved 'HLD only' project). Draw order = top first.
    # NO primary/secondary feeders (they are overview-only).
    "detail_fallback": [
        "STS Splitters v1", "STS Splitter",
        "Enclosures Splice v1", "Enclosures Splice",
        "Enclosures Connectorised v1", "Enclosures Connectorised",
        "FTS Splitters v1", "FTS Splitter",
        "ONT v1", "Distribution Cable v1", "Mini-ADSS",
        "Drop Cable v1", "Drop Cable", "Spare Drop Cable v1",
        "poles v1", "Pole", "PON v1",
    ],
    "detail_exclude": ["Zones v1", "where slack applies", "Erven v1"],

    # --- atlas ---
    "coverage_sort_field": "label",
    "atlas_filename_expr": "'MOA_PH2_PON_' || \"label\"",
    "atlas_margin": 0.15,

    # --- styling ---
    "enc_splice_rgb": "0,60,255",    # splice = blue
    "enc_conn_rgb":   "0,200,200",   # connectorised = cyan
    "pon_fill_alpha": 45,            # see houses through the PON fill

    # --- labels: role -> settings dict (label ON) or None (label OFF on detail pages) ---
    "labels": {
        "distribution": {"size": 5.5, "along_line": True,  "buf": 0.8, "strip": "MOA."},
        "poles":        {"size": 5.0, "along_line": False, "buf": 0.5, "strip": "MOA.P."},
        "fts":          {"size": 6.5, "along_line": False, "buf": 0.8, "strip": "MOA."},
        "sts":          {"size": 5.5, "along_line": False, "buf": 0.8, "strip": "MOA.STS.8.DIS.DM.P."},
        "primary":   None,   # feeders overview-only
        "secondary": None,
        "drop":      None,   # drop labels OFF (JJ)
        "spare_drop": None,
    },
    "label_min_scale": 9000.0,

    # --- legend ---
    # points render the layer's REAL symbol; lines draw as a coloured bar
    "legend_points": [
        ("FTS Splitter", "fts"), ("STS Splitter", "sts"),
        ("Enclosure (Splice)", "enc_splice"), ("Enclosure (Connectorised)", "enc_conn"),
        ("Pole", "poles"),
    ],
    "legend_lines": [
        ("ADSS", "primary", "#0000ff"),
        ("Mini-ADSS", "distribution", "#ef3ec8"),
        ("Drop Cable", "drop", "#29a500"),
    ],

    # --- MODEL / frame style: "hld" (default network atlas) | "commercial" (grid drawing) ---
    "frame_style":  "hld",
    "subtitle":     "",                # e.g. "COMMERCIAL DRAWING" (shown in the commercial sidebar)
    "created_by":   "",                # e.g. "Johan Scholtz"
    "scale_note":   "As-Shown (A3)",
    # explicit map layer lists (top-first). None -> HLD group/fallback logic.
    "detail_layers":   None,
    "overview_layers": None,
    # extra legend rows for fill/outline swatches (commercial zoning legend):
    "legend_fills":   [],              # [(label, "r,g,b" | layer_name)] -> filled colour box
    "legend_outline": [],              # [(label, "r,g,b")] -> outline-only box (e.g. AOI)
    # manual count tables in the sidebar: [{"title","headers":[...],"rows":[[...]]}]
    "count_tables": [],
    # label the coverage cells on the overview (grid numbers) with this field:
    "coverage_label_field": None,
    "logo_zoom": True,                 # Zoom (keep aspect); commercial logo is wider
}


def _deep_merge(base, over):
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


# caller may inject HLD_CFG in the exec namespace before running this file
CFG = _deep_merge(DEFAULT_CFG, globals().get("HLD_CFG", {}) or {})


def _enum(cls, *names):
    for n in names:
        obj = cls
        try:
            for part in n.split("."):
                obj = getattr(obj, part)
            return obj
        except AttributeError:
            continue
    raise AttributeError(f"none of {names} on {cls}")


MM = _enum(QgsUnitTypes, "LayoutUnit.LayoutMillimeters", "LayoutMillimeters")
LAND = _enum(QgsLayoutItemPage, "Orientation.Landscape", "Landscape")
HTMLMODE = _enum(QgsLayoutItemLabel, "Mode.ModeHtml", "ModeHtml")
ATLAS_AUTO = _enum(QgsLayoutItemMap, "AtlasScalingMode.Auto", "Auto")

p = QgsProject.instance()


def _lyr(name):
    for l in p.mapLayers().values():
        if l.name() == name:
            return l
    return None


# ---- group resolution (resolve layers within the configured group, not by hard-coded names) ----
def _p2_group():
    root = p.layerTreeRoot()
    want = CFG["group_name"].strip().lower()
    try:
        groups = root.findGroups(True)          # recursive (group may be nested)
    except TypeError:
        groups = []
        def _walk(node):
            for ch in node.children():
                if hasattr(ch, "children") and not hasattr(ch, "layer"):
                    groups.append(ch); _walk(ch)
        _walk(root)
    for g in groups:
        if g.name().strip().lower() == want:
            return g
    return None


def _p2_layer(*names):
    g = _p2_group()
    if g:
        for ch in g.findLayers():
            l = ch.layer()
            if l and l.name() in names:
                return l
    for n in names:
        x = _lyr(n)
        if x:
            return x
    return None


def _role(role):
    """Resolve a configured role to its layer (group-first, then whole project)."""
    names = CFG["roles"].get(role, [])
    return _p2_layer(*names) if names else None


def _p2_visible_layers(exclude=()):
    g = _p2_group()
    out = []
    if g:
        for ch in g.findLayers():
            l = ch.layer()
            if l and ch.isVisible() and l.name() not in exclude:
                out.append(l)
    return out


def _p2_enclosure():
    g = _p2_group()
    if g:
        for ch in g.findLayers():
            l = ch.layer()
            if not l:
                continue
            try:
                if any("Enclosure" in (c.label() or "") for c in l.renderer().categories()):
                    return l
            except Exception:
                pass
    return _role("enclosure")


def find_north_svg():
    from qgis.core import QgsApplication
    for base in QgsApplication.svgPaths():
        for cand in ("arrows/NorthArrow_02.svg", "arrows/NorthArrow_01.svg",
                     "arrows/NorthArrow_04.svg", "arrows/NorthArrow_11.svg"):
            fp = os.path.normpath(os.path.join(base, cand))
            if os.path.exists(fp):
                return fp
    return None


NORTH_SVG = find_north_svg()
LOGO = CFG["logo_path"]


def mmpoint(x, y): return QgsLayoutPoint(x, y, MM)
def mmsize(w, h): return QgsLayoutSize(w, h, MM)


def add_label(layout, x, y, w, h, html=None, text=None, size=9, bold=False,
              align_center=True, valign_center=True, frame=False):
    lbl = QgsLayoutItemLabel(layout)
    if html is not None:
        lbl.setMode(HTMLMODE)
        lbl.setText(html)
    else:
        lbl.setText(text or "")
        f = QFont(); f.setPointSize(size); f.setBold(bold)
        lbl.setFont(f)
    from qgis.PyQt.QtCore import Qt
    hz = _enum(Qt, "AlignmentFlag.AlignHCenter", "AlignHCenter") if align_center else _enum(Qt, "AlignmentFlag.AlignLeft", "AlignLeft")
    vt = _enum(Qt, "AlignmentFlag.AlignVCenter", "AlignVCenter") if valign_center else _enum(Qt, "AlignmentFlag.AlignTop", "AlignTop")
    try: lbl.setHAlign(hz); lbl.setVAlign(vt)
    except Exception: pass
    layout.addLayoutItem(lbl)
    lbl.attemptMove(mmpoint(x, y)); lbl.attemptResize(mmsize(w, h))
    if frame:
        lbl.setFrameEnabled(True); lbl.setFrameStrokeColor(QColor(0, 0, 0))
        lbl.setFrameStrokeWidth(QgsLayoutMeasurement(0.4, MM))
    return lbl


def add_rect(layout, x, y, w, h, stroke_w=0.6):
    RECT = _enum(QgsLayoutItemShape, "Shape.Rectangle", "Rectangle")
    sh = QgsLayoutItemShape(layout)
    try: sh.setShapeType(RECT)
    except Exception: pass
    layout.addLayoutItem(sh)
    sh.attemptMove(mmpoint(x, y)); sh.attemptResize(mmsize(w, h))
    sym = sh.symbol()
    if sym is not None:
        sym.setColor(QColor(255, 255, 255, 0))
        try:
            sl = sym.symbolLayer(0)
            sl.setStrokeColor(QColor(90, 90, 90)); sl.setStrokeWidth(stroke_w)
            sl.setFillColor(QColor(255, 255, 255, 0))
        except Exception: pass
    return sh


def _lyr_color(name, default):
    l = _lyr(name)
    if not l:
        return default
    try:
        return l.renderer().symbol().color().name()
    except Exception:
        return default


def _role_color(role, default):
    """Colour of the SAME layer the map draws for this role (group-first resolution).
    Using _role() — not a raw whole-project name scan — avoids grabbing a Phase-1
    'Drop Cable' when the map draws the Phase-2 'Drop Cable v1' (legend/map mismatch)."""
    l = _role(role)
    if l is not None:
        try:
            return l.renderer().symbol().color().name()
        except Exception:
            pass
    # last-ditch: any resolvable candidate by name
    for name in CFG["roles"].get(role, []):
        c = _lyr_color(name, None)
        if c:
            return c
    return default


def _render_legend_symbols():
    """Render each point role's ACTUAL symbol to a small PNG so the legend shows the real physical symbols."""
    from qgis.core import QgsSymbolLayerUtils
    from qgis.PyQt.QtCore import QSize
    d = CFG["legend_dir"]
    os.makedirs(d, exist_ok=True)
    out = {}

    def render(sym, name, w, h, mm=5.5):
        if sym is None:
            return
        try:
            s2 = sym.clone()
            try:
                if hasattr(s2, "setSize"):
                    s2.setSize(mm)   # bump marker size so the preview fills (real symbols are tiny)
            except Exception:
                pass
            pm = QgsSymbolLayerUtils.symbolPreviewPixmap(s2, QSize(w, h))
            path = f"{d}/{name}.png"
            pm.save(path)
            out[name] = path
        except Exception as e:
            print("legend sym err", name, e)

    def rsym(role):
        l = _role(role)
        if not l:
            return None
        r = l.renderer()
        try:
            if hasattr(r, "symbol"):
                s = r.symbol()
                if s is not None:
                    return s
        except Exception:
            pass
        try:
            from qgis.core import QgsRenderContext
            ss = r.symbols(QgsRenderContext())
            return ss[0] if ss else None
        except Exception:
            return None

    def enc(contains):
        l = _p2_enclosure()
        if not l:
            return None
        r = l.renderer()
        if not hasattr(r, "categories"):
            return r.symbol() if hasattr(r, "symbol") else None
        for c in r.categories():
            if contains.lower() in str(c.value()).lower():
                return c.symbol()
        return None

    # points only (scaled up to fill); lines are drawn as coloured bars in the HTML
    for _label, key in CFG["legend_points"]:
        if key == "enc_splice":
            render(rsym("enc_splice") or enc("splice"), "enc_splice", 30, 30)
        elif key == "enc_conn":
            render(rsym("enc_conn") or enc("connect"), "enc_conn", 30, 30)
        else:
            render(rsym(key), key, 30, 30)
    return out


def _fill_or_color(spec):
    """Resolve a legend fill spec: a layer name (read its fill colour), "r,g,b", or "#hex"."""
    l = _lyr(spec)
    if l is not None:
        try:
            return l.renderer().symbol().color().name()
        except Exception:
            pass
    if "," in str(spec):
        try:
            r, g, b = [int(x) for x in str(spec).split(",")[:3]]
            return f"#{r:02x}{g:02x}{b:02x}"
        except Exception:
            pass
    return spec


def _resolve_layer_list(names):
    """Resolve an explicit layer-name list to layers (group-first, then whole project),
    de-duplicated, preserving order. Used by the commercial model's detail/overview sets."""
    out = []
    seen = set()
    g = _p2_group()
    for n in names:
        l = None
        if g:
            for ch in g.findLayers():
                if ch.layer() and ch.layer().name() == n:
                    l = ch.layer(); break
        if l is None:
            l = _lyr(n)
        if l and l.id() not in seen:
            seen.add(l.id()); out.append(l)
    return out


def build_legend_html():
    syms = _render_legend_symbols()

    def img(name, w=17, h=17):
        pth = syms.get(name)
        return f"<img src='file:///{pth}' width='{w}' height='{h}'>" if pth else ""

    def bar(color):
        return (f"<table border='0' cellspacing='0' cellpadding='0' align='center'>"
                f"<tr><td bgcolor='{color}' width='34' height='5'>&nbsp;</td></tr></table>")

    def swatch(color, outline_only=False):
        if outline_only:
            return (f"<table border='0' cellspacing='0' cellpadding='0' align='center'><tr>"
                    f"<td style='border:2px solid {color}' width='16' height='10'>&nbsp;</td></tr></table>")
        return (f"<table border='0' cellspacing='0' cellpadding='0' align='center'><tr>"
                f"<td bgcolor='{color}' width='18' height='10' style='border:1px solid #444'>"
                f"&nbsp;</td></tr></table>")

    rows = [(lab, img(key)) for lab, key in CFG["legend_points"]]
    for lab, color in CFG.get("legend_outline", []):
        rows.append((lab, swatch(_fill_or_color(color), outline_only=True)))
    for lab, spec in CFG.get("legend_fills", []):
        rows.append((lab, swatch(_fill_or_color(spec))))
    for lab, role, default in CFG["legend_lines"]:
        rows.append((lab, bar(_role_color(role, default))))
    trs = "".join(f"<tr><td>{k}</td><td align='center'>{v}</td></tr>" for k, v in rows)
    return (f"<table cellpadding='2' cellspacing='0' style='font-family:Arial;font-size:8px' width='100%'>"
            f"<tr><td colspan='2' align='center' style='font-weight:bold'>LEGEND</td></tr>{trs}</table>")


def count_tables_html():
    """Manual count tables (commercial model) → stacked HTML tables for the sidebar."""
    tables = CFG.get("count_tables") or []
    out = []
    for t in tables:
        headers = t.get("headers", [])
        span = max(1, len(headers))
        hdr = "".join(f"<td style='font-weight:bold'>{h}</td>" for h in headers)
        body = ""
        for row in t.get("rows", []):
            body += "<tr>" + "".join(f"<td>{c}</td>" for c in row) + "</tr>"
        out.append(
            f"<table cellpadding='2' cellspacing='0' border='1' width='100%' "
            f"style='font-family:Arial;font-size:7px'>"
            f"<tr><td colspan='{span}' align='center' style='font-weight:bold;"
            f"text-decoration:underline'>{t.get('title', '')}</td></tr>"
            f"<tr>{hdr}</tr>{body}</table>")
    return "<br>".join(out)


def titleblock_html():
    rows = [("Project", CFG["project_name"]), ("Company", CFG["company"]),
            ("Designer", CFG["designer"]), ("Date", CFG["date_str"]), ("Revision", CFG["revision"])]
    trs = "".join(
        f"<tr><td style='font-weight:bold' width='42%'>{k}:</td><td align='center'>{v}</td></tr>" for k, v in rows)
    return f"<table cellpadding='4' cellspacing='0' border='1' width='100%' style='font-family:Arial;font-size:12px'>{trs}</table>"


def build_frame_commercial(layout, title_text):
    """Commercial-drawing frame: full-height map (no title bar) + a stacked sidebar
    (project / COMMERCIAL DRAWING / page / created-by · LEGEND · count tables · scale · logo)."""
    MAP = dict(x=6, y=6, w=322, h=285)      # full-height map, no title bar over it
    SB_X, SB_W = 334, 80
    add_rect(layout, 3, 3, 414, 291, stroke_w=1.0)                 # outer border
    add_rect(layout, MAP["x"], MAP["y"], MAP["w"], MAP["h"], stroke_w=0.6)  # map border
    # ── title block (stacked, centred) ──
    head = ("<div style='font-family:Arial;text-align:center'>"
            f"<div style='font-size:12px;font-weight:bold'>{CFG['project_name']}</div>"
            f"<div style='font-size:11px;font-weight:bold'>{CFG.get('subtitle', '')}</div>"
            f"<div style='font-size:9px;font-weight:bold;border:1px solid #000;"
            f"margin:2px 12px;padding:1px'>{title_text}</div>"
            + (f"<div style='font-size:8px'>Created by {CFG['created_by']}</div>"
               if CFG.get("created_by") else "")
            + "</div>")
    add_label(layout, SB_X, 5, SB_W, 26, html=head)
    # ── legend ──
    add_label(layout, SB_X, 33, SB_W, 46, html=build_legend_html(), frame=True)
    # ── count tables ──
    ct = count_tables_html()
    if ct:
        add_label(layout, SB_X, 81, SB_W, 168, html=ct, align_center=True, valign_center=False)
    # ── scale note ──
    add_label(layout, SB_X, 251, SB_W, 8,
              text=f"Scale: {CFG.get('scale_note', 'As-Shown (A3)')}", size=8, bold=True)
    # ── logo (wide) at the bottom ──
    if os.path.exists(LOGO):
        logo = QgsLayoutItemPicture(layout)
        logo.setPicturePath(LOGO)
        logo.setResizeMode(_enum(QgsLayoutItemPicture, "ResizeMode.Zoom", "Zoom"))
        layout.addLayoutItem(logo)
        logo.attemptMove(mmpoint(SB_X + 6, 262)); logo.attemptResize(mmsize(68, 28))
    return MAP


def build_frame(layout, title_text):
    if CFG.get("frame_style") == "commercial":
        return build_frame_commercial(layout, title_text)
    # geometry (mm) for A3 landscape 420x297
    MAP = dict(x=6, y=28, w=322, h=263)
    SB_X, SB_W = 334, 80
    add_rect(layout, 3, 3, 414, 291, stroke_w=1.0)          # outer border
    # title bar
    add_rect(layout, MAP["x"], 6, MAP["w"], 18, stroke_w=0.8)
    add_label(layout, MAP["x"], 6, MAP["w"], 18,
              html=f"<div style='font-family:Arial;font-size:19px;font-weight:bold;text-decoration:underline'>{title_text}</div>")
    # legend — real layer symbols rendered to images; compact box
    add_label(layout, SB_X, 6, SB_W, 46, html=build_legend_html(), frame=True)
    # north arrow
    if NORTH_SVG:
        pic = QgsLayoutItemPicture(layout)
        pic.setPicturePath(NORTH_SVG)
        layout.addLayoutItem(pic)
        pic.attemptMove(mmpoint(SB_X + 22, 88)); pic.attemptResize(mmsize(36, 46))
    add_label(layout, SB_X, 134, SB_W, 8, text="N", size=12, bold=True)
    # logo (keep aspect)
    if os.path.exists(LOGO):
        logo = QgsLayoutItemPicture(layout)
        logo.setPicturePath(LOGO)
        logo.setResizeMode(_enum(QgsLayoutItemPicture, "ResizeMode.Zoom", "Zoom"))
        layout.addLayoutItem(logo)
        logo.attemptMove(mmpoint(SB_X + 14, 150)); logo.attemptResize(mmsize(52, 48))
    # title block
    add_label(layout, SB_X, 249, SB_W, 45, html=titleblock_html())
    return MAP


def make_map(layout, MAP, layers, extent=None, atlas_driven=False, margin=0.10):
    m = QgsLayoutItemMap(layout)
    m.setId("mainmap")
    layout.addLayoutItem(m)
    m.attemptMove(mmpoint(MAP["x"], MAP["y"])); m.attemptResize(mmsize(MAP["w"], MAP["h"]))
    m.setLayers(layers)
    m.setFrameEnabled(True); m.setFrameStrokeWidth(QgsLayoutMeasurement(0.4, MM))
    m.setBackgroundColor(QColor(255, 255, 255))
    if extent is not None:
        m.setExtent(extent)
    if atlas_driven:
        m.setAtlasDriven(True)
        m.setAtlasScalingMode(ATLAS_AUTO)
        m.setAtlasMargin(margin)
    return m


def remove_layout(name):
    lm = p.layoutManager()
    ex = lm.layoutByName(name)
    if ex is not None:
        lm.removeLayout(ex)


def new_layout(name):
    remove_layout(name)
    layout = QgsPrintLayout(p)
    layout.initializeDefaults()
    layout.setName(name)
    pc = layout.pageCollection()
    pg = pc.page(0)
    pg.setPageSize("A3", LAND)
    return layout


def _restore_aoi():
    aoi = _lyr(CFG["aoi_layer"])
    if aoi is not None:
        try:
            aoi.setOpacity(1.0)
            if CFG.get("aoi_subset"):
                aoi.setSubsetString(CFG["aoi_subset"])
            aoi.triggerRepaint()
        except Exception:
            pass
    return aoi


def _greenfield_extent():
    aoi = _lyr(CFG["aoi_layer"])
    if aoi is None:
        return None
    nmf = next((f.name() for f in aoi.fields() if f.name().lower() == "name"), None)
    ext = QgsRectangle(); ext.setMinimal(); n = 0
    for f in aoi.getFeatures():
        v = str(f[nmf]) if nmf else ""
        if "greenfield" in v.lower():
            g = f.geometry()
            if g and not g.isEmpty():
                ext.combineExtentWith(g.boundingBox()); n += 1
    return ext if n else None


def _style_labels():
    """Cable/pole/splitter labels ON with white halos (per CFG['labels']); OFF where configured None."""
    from qgis.core import (QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                           QgsVectorLayerSimpleLabeling, QgsUnitTypes)
    from qgis.PyQt.QtGui import QColor, QFont
    PT = _enum(QgsUnitTypes, "RenderUnit.RenderPoints", "RenderPoints")
    MMU = _enum(QgsUnitTypes, "RenderUnit.RenderMillimeters", "RenderMillimeters")

    def field(layer, *cands):
        names = [f.name() for f in layer.fields()]
        for c in cands:
            if c in names:
                return c
        return names[0] if names else None

    def lbl(layer, size, along_line, buf=0.8, strip=None):
        if layer is None:
            return
        s = QgsPalLayerSettings()
        fld = field(layer, "label", "Label", "name")
        if strip:
            s.fieldName = 'replace("' + fld + '", \'' + strip + '\', \'\')'
            s.isExpression = True
        else:
            s.fieldName = fld
        s.enabled = True
        fmt = QgsTextFormat(); fmt.setFont(QFont("Arial")); fmt.setSize(size)
        try: fmt.setSizeUnit(PT)
        except Exception: pass
        b = QgsTextBufferSettings(); b.setEnabled(True); b.setSize(buf); b.setColor(QColor(255, 255, 255))
        try: b.setSizeUnit(MMU)
        except Exception: pass
        fmt.setBuffer(b); s.setFormat(fmt)
        try:
            s.placement = (_enum(QgsPalLayerSettings, "Placement.Curved", "Curved", "Line") if along_line
                           else _enum(QgsPalLayerSettings, "Placement.AroundPoint", "AroundPoint", "OverPoint"))
        except Exception: pass
        # scale-based: labels ONLY when zoomed into a page (detail export) -> full-project canvas stays fast
        s.scaleVisibility = True
        s.minimumScale = float(CFG["label_min_scale"])
        s.maximumScale = 0.0
        layer.setLabeling(QgsVectorLayerSimpleLabeling(s))
        layer.setLabelsEnabled(True)   # NO triggerRepaint -> don't force a heavy canvas re-render

    def off(layer):
        if layer:
            layer.setLabelsEnabled(False)

    for role, spec in CFG["labels"].items():
        layer = _role(role)
        if spec is None:
            off(layer)
        else:
            lbl(layer, spec["size"], spec["along_line"], spec.get("buf", 0.8), spec.get("strip"))


def _style_enclosures():
    """Distinct colours for splice vs connectorised enclosures (per CFG rgb values)."""
    from qgis.core import QgsMarkerSymbol, QgsSingleSymbolRenderer
    def style(layer, rgb):
        if layer is None:
            return
        try:
            sym = QgsMarkerSymbol.createSimple({"name": "circle", "color": rgb,
                                                "outline_color": "40,40,40", "outline_width": "0.2", "size": "1.7"})
            layer.setRenderer(QgsSingleSymbolRenderer(sym))
        except Exception as e:
            print("enc style err", e)
    style(_role("enc_splice"), CFG["enc_splice_rgb"])
    style(_role("enc_conn"), CFG["enc_conn_rgb"])


def _style_pon():
    """See-through PON fill + crisp outline; PON labels get a white halo."""
    from qgis.PyQt.QtGui import QColor
    from qgis.core import QgsVectorLayerSimpleLabeling, QgsUnitTypes
    pon = _role("coverage")
    if pon is None:
        return
    try:
        s = pon.renderer().symbol(); sl = s.symbolLayer(0)
        s.setOpacity(1.0)
        fc = sl.fillColor(); fc.setAlpha(int(CFG["pon_fill_alpha"])); sl.setFillColor(fc)
        st = sl.strokeColor(); st.setAlpha(255); sl.setStrokeColor(st)
        if pon.labeling():
            settings = pon.labeling().settings()
            fmt = settings.format()
            fmt.setSize(9)
            buf = fmt.buffer(); buf.setEnabled(True); buf.setSize(1.1)
            try:
                buf.setSizeUnit(_enum(QgsUnitTypes, "RenderUnit.RenderMillimeters", "RenderMillimeters"))
            except Exception:
                pass
            buf.setColor(QColor(255, 255, 255)); buf.setOpacity(1.0)
            fmt.setBuffer(buf)
            settings.setFormat(fmt)
            pon.setLabeling(QgsVectorLayerSimpleLabeling(settings))
        pon.triggerRepaint()
    except Exception as e:
        print("style_pon err", e)


def _style_commercial():
    """Commercial model: number the grid cells (coverage) for the overview; transparent
    fill + dark outline so the numbered grid reads over the basemap."""
    from qgis.core import (QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                           QgsVectorLayerSimpleLabeling, QgsUnitTypes, QgsFillSymbol,
                           QgsSingleSymbolRenderer)
    from qgis.PyQt.QtGui import QColor, QFont
    grid = _role("coverage")
    fld = CFG.get("coverage_label_field")
    if grid is None or not fld:
        return
    try:
        grid.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple(
            {"color": "0,0,0,0", "outline_color": "0,0,0", "outline_width": "0.4"})))
    except Exception as e:
        print("grid style err", e)
    try:
        s = QgsPalLayerSettings()
        s.fieldName = fld
        s.enabled = True
        try:
            s.centroidInside = True
        except Exception:
            pass
        try:
            s.placement = _enum(QgsPalLayerSettings, "Placement.Horizontal", "Horizontal",
                                "AroundPoint", "OverPoint")
        except Exception:
            pass
        fmt = QgsTextFormat(); fmt.setFont(QFont("Arial")); fmt.setSize(18)
        try:
            fmt.setSizeUnit(_enum(QgsUnitTypes, "RenderUnit.RenderPoints", "RenderPoints"))
        except Exception:
            pass
        b = QgsTextBufferSettings(); b.setEnabled(True); b.setSize(1.2); b.setColor(QColor(255, 255, 255))
        fmt.setBuffer(b); s.setFormat(fmt)
        grid.setLabeling(QgsVectorLayerSimpleLabeling(s))
        grid.setLabelsEnabled(True)
    except Exception as e:
        print("grid label err", e)


# ---- OVERVIEW ----
def build_overview():
    name = CFG["layout_overview"]
    layout = new_layout(name)
    MAP = build_frame(layout, CFG["title_overview"])
    basemap = _lyr(CFG["basemap"])
    aoi = _restore_aoi()
    pon = _role("coverage")
    if CFG.get("overview_layers"):
        # commercial: explicit overview layer set (numbered grid + zoning + boundary + basemap)
        ov_layers = _resolve_layer_list(CFG["overview_layers"])
        ext = pon.extent() if pon else _greenfield_extent()
        gf_ext = _greenfield_extent()
        if gf_ext:
            ext.combineExtentWith(gf_ext)
    else:
        primary = _role("primary")
        secondary = _role("secondary")
        # OVERVIEW = PON numbers + primary & secondary FEEDER ROUTES only
        ov_layers = [l for l in (primary, secondary, pon, aoi, basemap) if l]
        ext = _greenfield_extent()
        if ext is None:
            ext = pon.extent()
        ext.combineExtentWith(pon.extent())   # every PON guaranteed in
        for _fl in (primary, secondary):      # include feeder routes so none run off the edge
            if _fl:
                ext.combineExtentWith(_fl.extent())
    ext.scale(1.04)
    # force the extent to EXACTLY the map-item aspect (add to the shorter side) -> fills, no white bands
    target_ar = MAP["w"] / MAP["h"]
    cur_ar = ext.width() / ext.height()
    c = ext.center()
    if cur_ar > target_ar:                # too wide -> add height
        nh = ext.width() / target_ar
        ext.setYMinimum(c.y() - nh / 2); ext.setYMaximum(c.y() + nh / 2)
    else:                                 # too tall -> add width
        nw = ext.height() * target_ar
        ext.setXMinimum(c.x() - nw / 2); ext.setXMaximum(c.x() + nw / 2)
    make_map(layout, MAP, ov_layers, extent=ext)
    p.layoutManager().addLayout(layout)
    return name


# ---- ATLAS ----
def build_atlas():
    name = CFG["layout_atlas"]
    layout = new_layout(name)
    MAP = build_frame(layout, CFG["title_atlas_expr"])
    gf = _restore_aoi()
    if CFG.get("detail_layers"):
        # commercial: explicit detail layer set (zoning + SDU + boundary + basemap; NO grid overlay)
        layers = _resolve_layer_list(CFG["detail_layers"])
    else:
        # take exactly the visible group layers (adapts to renames); drop clutter + feeders
        feeder_names = set(CFG["roles"].get("primary", [])) | set(CFG["roles"].get("secondary", []))
        det_layers = _p2_visible_layers(exclude=set(CFG["detail_exclude"]) | feeder_names)
        if not det_layers:
            # no group (e.g. saved 'HLD only' project) -> known network layers, NO feeders
            seen = set(); det_layers = []
            for n in CFG["detail_fallback"]:
                l = _lyr(n)
                if l and l.id() not in seen:
                    seen.add(l.id()); det_layers.append(l)
        bm = _lyr(CFG["basemap"])
        layers = det_layers + [l for l in (gf, bm) if l]
    pon = _role("coverage")
    make_map(layout, MAP, layers, extent=pon.extent(), atlas_driven=True, margin=float(CFG["atlas_margin"]))
    # atlas config
    at = layout.atlas()
    at.setEnabled(True)
    at.setCoverageLayer(pon)
    at.setHideCoverage(bool(CFG.get("hide_coverage", False)))
    at.setSortFeatures(True)
    at.setSortExpression('"' + CFG["coverage_sort_field"] + '"')
    at.setFilenameExpression(CFG["atlas_filename_expr"])
    p.layoutManager().addLayout(layout)
    return name


def build_all():
    """Build both layouts inside a canvas freeze (safe on the GUI thread; no-op headless)."""
    try:
        from qgis.utils import iface as _iface
        _canvas = _iface.mapCanvas() if _iface else None
    except Exception:
        _canvas = None
    if _canvas is not None:
        _canvas.setRenderFlag(False)
    try:
        if CFG.get("frame_style") == "commercial":
            _style_commercial()
        else:
            _style_enclosures()
            _style_pon()
            _style_labels()
        ov = build_overview()
        at = build_atlas()
        print("BUILT:", ov, "|", at, "| style:", CFG.get("frame_style"), "| logo:", os.path.exists(LOGO))
        return ov, at
    finally:
        if _canvas is not None:
            try:
                _ext = _greenfield_extent()
                if _ext is not None:
                    _ext.scale(1.1); _canvas.setExtent(_ext)
            except Exception:
                pass
            _canvas.setRenderFlag(True)


# run on exec (preserves the original drop-in behaviour)
build_all()
