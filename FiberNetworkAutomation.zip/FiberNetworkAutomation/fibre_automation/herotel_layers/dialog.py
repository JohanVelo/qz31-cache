"""Ask, build, and add the HeroTel standard layers to the open project (VN 1).

Order of questions: where to save -> CRS (only when the project has none) -> add to this
project? (only when the project is not blank). The GeoPackage is always built first; a blank
project (no file name, no layers) gets the layers straight away, any other project is asked
first, defaulting to No. Exactly one VN1 log record is written per run.

The flow takes its questions as plain callables so it runs headless in tests; qt_prompts()
supplies the real dialogs for the plugin button.
"""
import json
from os.path import splitext

from qgis.core import Qgis, QgsMessageLog, QgsVectorLayer

from . import build as _build

GROUP_NAME = "HeroTel Standard Layers"


def is_blank(project):
    return not project.fileName() and not project.mapLayers()


def project_label(project):
    return project.baseName() if project.fileName() else "unsaved project"


def collisions(project, names, role_of=None):
    """Layers already in the project that look like one of `names`: same name, or same known role."""
    wanted = {n.strip().lower() for n in names}
    roles = {role_of(n) for n in names} - {None} if role_of else set()
    hits = []
    for layer in project.mapLayers().values():
        existing = layer.name()
        if existing.strip().lower() in wanted or (role_of and role_of(existing) in roles):
            hits.append(existing)
    return sorted(hits)


def add_to_project(project, path, names):
    """Add every built layer, in spec order, inside one group at the top of the layer tree."""
    layers = []
    for name in names:
        layer = QgsVectorLayer(f"{path}|layername={name}", name, "ogr")
        if not layer.isValid():
            raise _build.BuildError(f"Layer '{name}' could not be opened from {path}")
        layers.append(layer)
    group = project.layerTreeRoot().insertGroup(0, GROUP_NAME)
    for layer in layers:
        project.addMapLayer(layer, False)
        group.addLayer(layer)
    return layers


def run_build_dialog(project, parent, ask_path, ask_crs, confirm_add, role_of=None, log=None):
    """Run the whole VN 1 flow and return its log record. `parent` is kept for the Qt wiring."""
    emit = log or (lambda text: QgsMessageLog.logMessage(text, _build.LOG_TAG, Qgis.MessageLevel.Info))
    captured = []
    try:
        record = _build.build_with_prompts(project, ask_path, ask_crs, log=captured.append)
    except Exception:
        for text in captured:
            emit(text)
        raise
    if record["outcome"] == "built":
        names = list(_build.load_spec()["layers"])
        added = []
        if is_blank(project):
            added = add_to_project(project, record["path"], names)
        else:
            hits = collisions(project, names, role_of)
            record["collisions"] = hits
            record["confirm_shown"] = True
            answer = bool(confirm_add(project_label(project), hits))
            record["confirm_answer"] = answer
            if answer:
                added = add_to_project(project, record["path"], names)
        record["layers_added"] = len(added)
    emit(json.dumps(record, sort_keys=True))
    return record


def qt_prompts(parent):
    """The real questions: save dialog, CRS picker, Yes/No (default No)."""
    from qgis.gui import QgsProjectionSelectionDialog
    from qgis.PyQt.QtWidgets import QFileDialog, QMessageBox

    def ask_path():
        path, _ = QFileDialog.getSaveFileName(parent, "Save the HeroTel standard layers", "", "GeoPackage (*.gpkg)")
        if path and splitext(path)[1].lower() != ".gpkg":
            path += ".gpkg"
        return path or None

    def ask_crs():
        dialog = QgsProjectionSelectionDialog(parent)
        dialog.setWindowTitle("Coordinate system for the new layers")
        accepted = dialog.exec()
        crs = dialog.crs()
        return crs if accepted and crs.isValid() else None

    def confirm_add(name, hits):
        text = f"The new GeoPackage has been saved.\n\nAdd its 16 layers to {name}?"
        if hits:
            text += "\n\nThis project already has layers that look the same:\n  " + "\n  ".join(hits)
        answer = QMessageBox.question(parent, "Add HeroTel standard layers", text,
                                      QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                      QMessageBox.StandardButton.No)
        return answer == QMessageBox.StandardButton.Yes

    return ask_path, ask_crs, confirm_add
