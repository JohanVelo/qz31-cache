"""Phase 3 — erven generation with tunable sliders (NO Voronoi).

Wraps the validated cadastral pipeline (cadastral_erven.py): buildings -> watershed road-bounded
blocks -> uniform street-aligned rectangular stand grid. Exposes the knobs as params:
  merge_m, stand_W (0=auto from building spacing), stand_depth, orient_snap (bool), min_area, max_area.

generate_erven(buildings_gdf, aoi_gdf, params) -> GeoDataFrame(EPSG:4326).
"""
import sys
from pathlib import Path

import geopandas as gpd

def _fa_dir():
    """Locate fibre_automation whether erven_studio sits inside the plugin or beside it."""
    here = Path(__file__).resolve().parent
    for c in (here.parent / "fibre_automation",                              # bundled in plugin
              here.parent / "FiberNetworkAutomation" / "fibre_automation",    # repo-root layout
              here / "fibre_automation"):
        if (c / "cadastral_erven.py").exists():
            return str(c)
    return str(here.parent / "fibre_automation")


sys.path.insert(0, _fa_dir())
from cadastral_erven import buildings_to_blocks, _dominant_azimuths, subdivide

UTM = 32735


def generate_erven(buildings_gdf, aoi_gdf, params=None):
    p = {"merge_m": 12.0, "stand_W": 0.0, "stand_depth": 27.0, "orient_snap": True,
         "min_area": 60.0, "max_area": 1300.0, **(params or {})}
    b = buildings_gdf.to_crs(UTM)
    b = b[b.geometry.notna() & ~b.geometry.is_empty]
    ageom = aoi_gdf.to_crs(UTM).geometry.union_all()
    bgeoms = list(b.geometry)
    bpts = [g.representative_point() for g in bgeoms]

    blocks = buildings_to_blocks(bgeoms, ageom, merge_m=p["merge_m"])
    if p.get("orient") is not None:                       # explicit (e.g. learned from examples)
        peaks = [float(p["orient"])]
    elif p["orient_snap"]:
        peaks = _dominant_azimuths(list(blocks.geometry))
    else:
        peaks = None

    stands = []
    for blk in blocks.geometry:
        if blk and not blk.is_empty:
            stands.extend(subdivide(
                blk, bpts, peaks=peaks, d_target=p["stand_depth"],
                w_override=(p["stand_W"] or None),
                min_area=p["min_area"], max_area=p["max_area"]))
    gen = gpd.GeoDataFrame(geometry=[s for s in stands if s and not s.is_empty], crs=UTM)
    if len(gen):
        gen["area_m2"] = gen.geometry.area
    return gen.to_crs(4326)
