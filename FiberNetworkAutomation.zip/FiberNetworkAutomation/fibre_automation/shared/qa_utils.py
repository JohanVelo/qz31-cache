"""Shared QA check helpers used by both pipelines."""

from qgis.core import QgsProject


def get_layer(name: str):
    """Return first layer matching name, or None."""
    layers = QgsProject.instance().mapLayersByName(name)
    return layers[0] if layers else None


def check_no_null_names(layer, field: str = "Name") -> list:
    """Return list of FIDs where the name field is NULL or empty."""
    bad = []
    if layer is None:
        return bad
    idx = layer.fields().indexOf(field)
    if idx == -1:
        return bad
    for feat in layer.getFeatures():
        val = feat[idx]
        if val is None or str(val).strip() == "":
            bad.append(feat.id())
    return bad


def check_no_duplicate_names(layer, field: str = "Name") -> list:
    """Return list of duplicate name values."""
    if layer is None:
        return []
    idx = layer.fields().indexOf(field)
    if idx == -1:
        return []
    seen = {}
    for feat in layer.getFeatures():
        val = str(feat[idx]).strip()
        if not val:
            continue
        seen[val] = seen.get(val, 0) + 1
    return [v for v, cnt in seen.items() if cnt > 1]


def check_sequential_numbers(layer, field: str, prefix: str = "") -> list:
    """Return gaps in a sequential numeric suffix field (e.g. DR0001, DR0003 → gap at 0002)."""
    if layer is None:
        return []
    idx = layer.fields().indexOf(field)
    if idx == -1:
        return []
    nums = []
    for feat in layer.getFeatures():
        val = str(feat[idx]).strip().lstrip(prefix)
        try:
            nums.append(int(val))
        except ValueError:
            pass
    if not nums:
        return []
    nums.sort()
    gaps = []
    for i in range(nums[0], nums[-1] + 1):
        if i not in nums:
            gaps.append(i)
    return gaps


def check_crs_consistent(layer_names: list) -> list:
    """Return list of layer names whose CRS differs from the first layer."""
    layers = [get_layer(n) for n in layer_names]
    layers = [lyr for lyr in layers if lyr]
    if len(layers) < 2:
        return []
    ref = layers[0].crs().authid()
    return [lyr.name() for lyr in layers[1:] if lyr.crs().authid() != ref]


def check_empty_layers(layer_names: list) -> list:
    """Return names of layers that exist but have 0 features."""
    empty = []
    for name in layer_names:
        lyr = get_layer(name)
        if lyr and lyr.featureCount() == 0:
            empty.append(name)
    return empty


def check_missing_layers(layer_names: list) -> list:
    """Return names of layers not found in project."""
    return [n for n in layer_names if not get_layer(n)]


def print_qa_report(client: str, errors: list, warnings: list):
    """Print a formatted QA report to the QGIS console."""
    sep = "═" * 50
    print(f"\n{sep}")
    print(f"  {client.upper()} QA REPORT")
    print(sep)
    for msg in errors:
        print(f"  ✗ ERROR:   {msg}")
    for msg in warnings:
        print(f"  ⚠ WARNING: {msg}")
    if not errors and not warnings:
        print("  ✓ All checks passed")
    print(f"\n  RESULT: {len(errors)} ERROR(S) / {len(warnings)} WARNING(S)")
    print(sep + "\n")
    return len(errors), len(warnings)
