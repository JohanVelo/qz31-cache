# -*- coding: utf-8 -*-
"""nexus_drag — smooth, phone-like dragging for Velocity panels.

WHY THIS EXISTS
---------------
Qt drags a QDockWidget *opaquely*: the real panel is torn into a live window and
moved under the cursor, so every mouse move re-lays-out and repaints the whole
thing — 173 child widgets with gradients and borders for the Nexus home panel.
Measured on 2026-08-27 (stock Qt, QGIS 4.0.3, input delivered at 120 Hz):

    median of 5 paired runs   73.1 fps   p50 10.6 ms   p90 29.1 ms   max 47.0 ms

The median is fine; the tail is what the eye reads as choppy. Freezing the
panel's repaint during the gesture was tried first and rejected: it is faster
(84 fps, p50 7.5 ms, max 36.8 ms) but the panel renders BLANK while it moves,
because a torn-out dock gets a fresh window with no backing store to blit.

So this module does what Qt Advanced Docking System does internally, and what
every phone does: **do not move the real thing.** Take one picture of the panel,
leave the panel exactly where it is, and slide the picture. One blit per frame,
no layout, no repaint. The dock is only touched once, on drop.

WHAT IT GIVES
-------------
* a drag preview that tracks the cursor
* the target dock area highlighted while you move, so you can see where it lands
* **Escape cancels** mid-drag — stock QDockWidget has no cancel at all
* the real dock is modified exactly once, when the mouse is released

SAFETY
------
* ``VF_NO_SMOOTH_DRAG=1`` disables it completely; Qt's own behaviour returns.
* Every entry point is wrapped: on any exception the engine tears itself down and
  hands the gesture back to Qt rather than leaving a panel that cannot be moved.
* The mouse *press* is never consumed, so the title bar's close and float buttons
  keep working; only the moves are taken, which is what stops Qt from starting
  its own opaque drag.
* Velocity panels only — QGIS's own docks are never touched.
"""
from __future__ import annotations

import os

# How far the pointer must travel before a click becomes a drag. Qt's own
# startDragDistance is used when available; this is the fallback.
_DRAG_START_PX = 8

# A very tall panel makes a very tall preview. Cap it — the preview is a hint,
# not a copy, and a smaller pixmap is a cheaper blit every frame.
_PREVIEW_MAX_H = 460
_PREVIEW_OPACITY = 1.0     # opaque: a layered window re-composites on every move

# How close to an edge counts as "drop into that dock area".
_EDGE_FRACTION = 0.22

# The card is drawn slightly smaller than the panel so it reads as something you
# picked up, not the panel itself stuck to the cursor.
_PREVIEW_SCALE = 0.92

# The card flies into its landing rectangle instead of teleporting. Short enough
# not to feel like waiting; 0 disables.
_DROP_ANIM_MS = 130
_HIGHLIGHT_ANIM_MS = 90


def is_disabled():
    return os.environ.get("VF_NO_SMOOTH_DRAG") == "1"


# ── the preview and the highlight ────────────────────────────────────────────
def _make_preview(dock):
    """A frameless, click-through card showing a picture of the panel.

    Scaled slightly down so it reads as something you have picked UP rather than
    the panel itself sitting under the cursor, and captioned with the one thing a
    first-time user cannot discover on their own: Escape gets you out.
    """
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import QLabel

    pix = dock.grab()
    if pix.isNull():
        return None
    if pix.height() > _PREVIEW_MAX_H:
        pix = pix.scaledToHeight(_PREVIEW_MAX_H, Qt.TransformationMode.SmoothTransformation)
    if _PREVIEW_SCALE < 1.0:
        pix = pix.scaled(int(pix.width() * _PREVIEW_SCALE),
                         int(pix.height() * _PREVIEW_SCALE),
                         Qt.AspectRatioMode.IgnoreAspectRatio,
                         Qt.TransformationMode.SmoothTransformation)

    w = QLabel(None)
    w._vf_drag_preview = True      # marker: lets a stray card be found and killed
    w.setWindowTitle(dock.windowTitle() or "Velocity Nexus")
    w.setWindowFlags(
        Qt.WindowType.FramelessWindowHint
        | Qt.WindowType.Tool
        | Qt.WindowType.WindowStaysOnTopHint
        | Qt.WindowType.WindowTransparentForInput
    )
    w.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
    if _PREVIEW_OPACITY < 1.0:
        w.setWindowOpacity(_PREVIEW_OPACITY)
    w.setPixmap(pix)
    w.resize(pix.size())

    hint = QLabel(w)
    hint.setText("  Esc to cancel  ")
    hint.setStyleSheet(
        "background: #05070C; color: #7E93B8; border: 1px solid #1AE5FF;"
        "border-radius: 3px; font-family: 'Chakra Petch','Segoe UI',sans-serif;"
        "font-size: 10px; font-weight: bold; letter-spacing: 1px; padding: 2px;")
    hint.adjustSize()
    hint.move(max(0, (w.width() - hint.width()) // 2), max(0, w.height() - hint.height() - 6))
    return w


def _make_highlight():
    """The cyan block that shows where the panel will land."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import QWidget

    w = QWidget(None)
    w.setWindowFlags(
        Qt.WindowType.FramelessWindowHint
        | Qt.WindowType.Tool
        | Qt.WindowType.WindowStaysOnTopHint
        | Qt.WindowType.WindowTransparentForInput
    )
    w.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
    # WA_StyledBackground is required: a plain QWidget ignores a stylesheet
    # background without it, and the highlight silently paints nothing.
    w.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
    w.setWindowOpacity(0.30)
    w.setStyleSheet("background: #1AE5FF; border: 2px solid #EAF3FF;")
    return w


# ── where would it land? ─────────────────────────────────────────────────────
def build_zones(main_window, dock):
    """Snapshot the drop zones ONCE, at the start of a gesture.

    Resolving the target used to walk ``findChildren(QDockWidget)`` and map
    coordinates on every mouse move — a full object-tree walk per frame, at 120
    frames a second. That alone made the preview slower than the thing it was
    meant to replace (measured: 18.9 fps against stock Qt's 75.4). Nothing in this
    list can move while the mouse button is held, so it is computed once.
    """
    from qgis.PyQt.QtCore import QRect
    from qgis.PyQt.QtWidgets import QDockWidget

    tl = main_window.mapToGlobal(main_window.rect().topLeft())
    mw_rect = QRect(tl.x(), tl.y(), main_window.width(), main_window.height())
    tabs = []
    for other in main_window.findChildren(QDockWidget):
        if other is dock or not other.isVisible() or other.isFloating():
            continue
        if other.window() is not main_window:
            continue
        otl = other.mapToGlobal(other.rect().topLeft())
        orect = QRect(otl.x(), otl.y(), other.width(), other.height())
        # A dock that is stacked behind another (a non-current tab) keeps a stale
        # rectangle far outside the window — one was measured at (1072, -1278).
        # Offering that as a drop zone means a drop can target something the
        # operator cannot even see, so only on-screen docks become zones.
        if not mw_rect.contains(orect.center()):
            continue
        inner = orect.adjusted(int(orect.width() * 0.25), int(orect.height() * 0.25),
                               -int(orect.width() * 0.25), -int(orect.height() * 0.25))
        tabs.append((inner, other, orect))
    return mw_rect, tabs


def _target_for(zones, gpos):
    """Resolve a cursor position to a drop target, using the snapshot.

    Returns ``(kind, payload, highlight_rect)`` where kind is one of
    ``"area"`` (payload = Qt.DockWidgetArea), ``"tab"`` (payload = the dock to tab
    with) or ``"float"`` (payload = None).
    """
    from qgis.PyQt.QtCore import QRect, Qt

    mw_rect, tabs = zones
    if not mw_rect.contains(gpos):
        return "float", None, None

    for inner, other, orect in tabs:
        if inner.contains(gpos):
            return "tab", other, orect

    x = (gpos.x() - mw_rect.x()) / max(1.0, float(mw_rect.width()))
    y = (gpos.y() - mw_rect.y()) / max(1.0, float(mw_rect.height()))
    band = min(x, 1.0 - x, y, 1.0 - y)

    # The middle of the window floats the panel, the way it does in stock Qt.
    # Without this every drop inside the window snapped to whichever edge happened
    # to be nearest, and a panel could not be torn out over the map at all.
    if band > _EDGE_FRACTION:
        return "float", None, None

    if band == x:
        area = Qt.DockWidgetArea.LeftDockWidgetArea
        rect = QRect(mw_rect.x(), mw_rect.y(),
                     int(mw_rect.width() * _EDGE_FRACTION), mw_rect.height())
    elif band == 1.0 - x:
        w = int(mw_rect.width() * _EDGE_FRACTION)
        area = Qt.DockWidgetArea.RightDockWidgetArea
        rect = QRect(mw_rect.right() - w, mw_rect.y(), w, mw_rect.height())
    elif band == y:
        area = Qt.DockWidgetArea.TopDockWidgetArea
        rect = QRect(mw_rect.x(), mw_rect.y(), mw_rect.width(),
                     int(mw_rect.height() * _EDGE_FRACTION))
    else:
        h = int(mw_rect.height() * _EDGE_FRACTION)
        area = Qt.DockWidgetArea.BottomDockWidgetArea
        rect = QRect(mw_rect.x(), mw_rect.bottom() - h, mw_rect.width(), h)

    return "area", area, rect


# ── the engine ───────────────────────────────────────────────────────────────
def install(dock, main_window=None):
    """Give one Velocity dock the smooth drag. Idempotent and fail-open."""
    if is_disabled():
        return dock
    kill_stray_previews()      # a reload can leave one behind
    try:
        if getattr(dock, "_vf_smooth_drag", None) is not None:
            return dock

        from qgis.PyQt.QtCore import QEvent, QObject, QPoint, Qt, QTimer
        from qgis.PyQt.QtWidgets import QApplication, QStyle, QStyleOptionDockWidget

        if main_window is None:
            main_window = dock.parent()

        class _SmoothDrag(QObject):
            def __init__(self, target, mw):
                super().__init__(target)
                self._dock = target
                self._mw = mw
                self._armed = False
                self._dragging = False
                self._press_global = None
                self._grab_offset = QPoint(0, 0)
                self._preview = None
                self._highlight = None
                self._target = ("float", None, None)
                self._start_size = None
                self._zones = None
                self._last_rect = None
                self._hl_anim = None
                self._drop_anim = None
                self._committing = False
                # If the release is never delivered — alt-tab mid-drag, a window
                # steals focus, the session is interrupted — the preview would sit
                # on screen forever. Two stray previews were left behind exactly
                # that way while this was being built. Poll and clean up.
                self._watchdog = QTimer(self)
                self._watchdog.setInterval(250)
                self._watchdog.timeout.connect(self._abort_if_idle)

            # -- geometry helpers ------------------------------------------
            def _title_rect(self):
                """The draggable strip: the title bar minus its buttons."""
                d = self._dock
                body = d.widget()
                h = 28 if body is None else max(1, d.height() - body.height())
                r = d.rect()
                r.setHeight(h)
                try:
                    opt = QStyleOptionDockWidget()
                    d.initStyleOption(opt)
                    st = d.style()
                    for se in (QStyle.SubElement.SE_DockWidgetCloseButton,
                               QStyle.SubElement.SE_DockWidgetFloatButton):
                        btn = st.subElementRect(se, opt, d)
                        if btn.isValid() and btn.width() > 0:
                            r.setRight(min(r.right(), btn.left() - 2))
                except Exception:
                    pass          # buttons stay clickable regardless: press is never eaten
                return r

            # -- lifecycle -------------------------------------------------
            def _start(self, gpos):
                # Remember how big the panel was. Qt gives a re-docked panel its
                # MINIMUM size, not the size it had — dropping a 440x788 panel and
                # getting back a 258x82 stub is what "it went weird" looks like.
                self._start_size = self._dock.size()
                self._zones = build_zones(self._mw, self._dock)
                self._last_rect = None
                self._preview = _make_preview(self._dock)
                if self._preview is None:
                    return False
                self._highlight = _make_highlight()
                # keep the grab point under the cursor, like picking up a card
                local = self._dock.mapFromGlobal(gpos)
                fx = local.x() / max(1.0, float(self._dock.width()))
                self._grab_offset = QPoint(int(self._preview.width() * fx), 14)
                self._dragging = True
                self._watchdog.start()
                QApplication.instance().installEventFilter(self)   # for Escape
                self._move(gpos)
                self._preview.show()
                return True

            def _move(self, gpos):
                if self._preview is not None:
                    self._preview.move(gpos - self._grab_offset)
                self._target = _target_for(self._zones, gpos)
                rect = self._target[2]
                hl = self._highlight
                if hl is None:
                    return
                # the highlight only changes when the target does; re-setting the
                # same geometry every frame is a wasted window operation
                if rect == self._last_rect:
                    return
                old = self._last_rect
                self._last_rect = rect
                if rect is None:
                    hl.hide()
                    return
                if old is None or _HIGHLIGHT_ANIM_MS <= 0:
                    hl.setGeometry(rect)
                    hl.show()
                    return
                try:
                    from qgis.PyQt.QtCore import QEasingCurve, QPropertyAnimation
                    anim = QPropertyAnimation(hl, b"geometry", self)
                    anim.setDuration(_HIGHLIGHT_ANIM_MS)
                    anim.setStartValue(hl.geometry())
                    anim.setEndValue(rect)
                    anim.setEasingCurve(QEasingCurve.Type.OutCubic)
                    self._hl_anim = anim        # keep a ref or it is collected
                    anim.start()
                except Exception:
                    hl.setGeometry(rect)
                if not hl.isVisible():
                    hl.show()

            def _abort_if_idle(self):
                try:
                    if not self._dragging and not self._committing:
                        self._watchdog.stop()
                        kill_stray_previews()   # nothing in flight -> no card may remain
                        return
                    if self._committing:
                        return                  # landing; the backstop will finish it
                    if QApplication.mouseButtons() == Qt.MouseButton.NoButton:
                        self._teardown()      # cancel: the panel never moved
                except Exception:
                    self._teardown()

            def _teardown(self):
                try:
                    self._watchdog.stop()
                except Exception:
                    pass
                try:
                    QApplication.instance().removeEventFilter(self)
                except Exception:
                    pass
                for name in ("_preview", "_highlight"):
                    w = getattr(self, name, None)
                    if w is not None:
                        try:
                            w.hide()
                            w.deleteLater()
                        except Exception:
                            pass
                    setattr(self, name, None)
                self._dragging = False
                self._armed = False

            def _restore_size(self, area):
                """Give the panel back the size it had before the drag."""
                size = self._start_size
                if size is None:
                    return
                try:
                    horizontal = area in (Qt.DockWidgetArea.LeftDockWidgetArea,
                                          Qt.DockWidgetArea.RightDockWidgetArea)
                    if horizontal:
                        self._mw.resizeDocks([self._dock], [max(240, size.width())],
                                             Qt.Orientation.Horizontal)
                    else:
                        self._mw.resizeDocks([self._dock], [max(160, size.height())],
                                             Qt.Orientation.Vertical)
                except Exception:
                    pass

            def _commit(self, kind, payload, gpos, size):
                if not self._committing:
                    return                      # already landed (animation or backstop)
                self._committing = False
                d = self._dock
                self._teardown()
                try:
                    if kind == "area":
                        d.setFloating(False)
                        self._mw.addDockWidget(payload, d)
                        self._restore_size(payload)
                    elif kind == "tab":
                        d.setFloating(False)
                        self._mw.tabifyDockWidget(payload, d)
                        d.show()
                        d.raise_()
                        self._restore_size(self._mw.dockWidgetArea(payload))
                    else:
                        d.setFloating(True)
                        if size is not None:
                            d.resize(size)
                        d.move(gpos - QPoint(int(d.width() * 0.5), 12))
                except Exception:
                    pass

            def _drop(self, gpos):
                kind, payload, rect = self._target
                size = self._start_size
                pv = self._preview

                # Fly the card into the place it is going, THEN commit. Without
                # this the card vanishes and the panel appears somewhere else in
                # the same instant, which reads as a jump however fast it is.
                self._committing = True
                if (pv is None or rect is None or kind == "float"
                        or _DROP_ANIM_MS <= 0):
                    self._commit(kind, payload, gpos, size)
                    return

                try:
                    from qgis.PyQt.QtCore import QEasingCurve, QPropertyAnimation

                    if self._highlight is not None:
                        self._highlight.hide()
                    anim = QPropertyAnimation(pv, b"geometry", self)
                    anim.setDuration(_DROP_ANIM_MS)
                    anim.setStartValue(pv.geometry())
                    anim.setEndValue(rect)
                    anim.setEasingCurve(QEasingCurve.Type.OutCubic)
                    self._drop_anim = anim          # keep a ref or it is collected
                    self._dragging = False          # the gesture is over; the flight is not
                    self._committing = True         # ...but the card is still on screen
                    anim.finished.connect(
                        lambda: self._commit(kind, payload, gpos, size))
                    anim.start()
                    # Hard backstop. If ``finished`` never arrives — the animation is
                    # collected, the plugin reloads mid-flight, anything — the card
                    # would sit on screen with no drag behind it, which is exactly
                    # what happened live. Commit anyway, shortly after it should
                    # have landed. _commit is idempotent via _committing.
                    QTimer.singleShot(
                        _DROP_ANIM_MS + 250,
                        lambda: self._commit(kind, payload, gpos, size))
                except Exception:
                    self._commit(kind, payload, gpos, size)

            # -- the filter ------------------------------------------------
            def eventFilter(self, obj, ev):
                try:
                    from qgis.PyQt import sip
                    if sip.isdeleted(self._dock) or sip.isdeleted(self._mw):
                        return False          # shutting down: hands off
                    t = ev.type()

                    # Escape aborts, and the panel has not moved at all — the whole
                    # point of never touching it until the mouse comes up.
                    if self._dragging and t == QEvent.Type.KeyPress:
                        if ev.key() == Qt.Key.Key_Escape:
                            self._teardown()
                            return True
                        return False

                    if obj is not self._dock:
                        return False

                    if (t == QEvent.Type.MouseButtonPress
                            and ev.button() == Qt.MouseButton.LeftButton):
                        # NOT consumed: the close/float buttons must keep working,
                        # and Qt only starts its opaque drag once it sees a MOVE.
                        pos = ev.position().toPoint()
                        self._armed = self._title_rect().contains(pos)
                        self._press_global = ev.globalPosition().toPoint()
                        return False

                    if t == QEvent.Type.MouseMove and (self._armed or self._dragging):
                        gpos = ev.globalPosition().toPoint()
                        if not self._dragging:
                            try:
                                thresh = QApplication.startDragDistance()
                            except Exception:
                                thresh = _DRAG_START_PX
                            if (gpos - self._press_global).manhattanLength() < thresh:
                                return False
                            if not self._start(gpos):
                                self._armed = False
                                return False        # no preview -> let Qt do it
                        else:
                            self._move(gpos)
                        return True                 # Qt never starts its own drag

                    if t == QEvent.Type.MouseButtonRelease:
                        if self._dragging:
                            self._drop(ev.globalPosition().toPoint())
                            return True
                        self._armed = False
                        return False
                except Exception:
                    self._teardown()
                return False

        eng = _SmoothDrag(dock, main_window)
        dock.installEventFilter(eng)
        dock._vf_smooth_drag = eng
    except Exception:
        pass
    return dock


def kill_stray_previews():
    """Destroy any drag card left on screen with no drag behind it.

    The card is a parentless top-level window, so nothing else will ever collect
    it: a plugin reload, an animation that never emitted ``finished``, or an
    interrupted session all leave it floating over QGIS forever. Observed live
    2026-08-27 — a card sat at the left edge with no gesture in progress.
    """
    n = 0
    try:
        from qgis.PyQt import sip
        from qgis.PyQt.QtWidgets import QApplication
        for w in QApplication.topLevelWidgets():
            try:
                if sip.isdeleted(w) or not getattr(w, "_vf_drag_preview", False):
                    continue
                w.hide()
                w.deleteLater()
                n += 1
            except Exception:
                continue
    except Exception:
        pass
    return n


def uninstall_all(main_window):
    """Remove the engine from EVERY dock before the plugin unloads.

    This matters across plugin boundaries. The engine is installed on any Velocity
    panel, including the VeloGIS Bridge dock, which belongs to a DIFFERENT plugin.
    QGIS unloads plugins one by one; if ours goes first and leaves a filter behind,
    the other plugin's ``removeDockWidget`` dispatches events into a filter whose
    module is already being torn down — an access violation at exit, in
    ``QgisApp::saveWindowState``. Observed 2026-08-27.
    """
    n = 0
    kill_stray_previews()
    try:
        from qgis.PyQt import sip
        from qgis.PyQt.QtWidgets import QDockWidget
        if main_window is None or sip.isdeleted(main_window):
            return 0
        for d in main_window.findChildren(QDockWidget):
            try:
                if sip.isdeleted(d):
                    continue
                if getattr(d, "_vf_smooth_drag", None) is not None:
                    uninstall(d)
                    n += 1
            except Exception:
                continue
    except Exception:
        pass
    return n


def uninstall(dock):
    """Hand the gesture back to Qt. Used by the A/B harness and the kill switch."""
    try:
        eng = getattr(dock, "_vf_smooth_drag", None)
        if eng is None:
            return dock
        try:
            eng._teardown()
        except Exception:
            pass
        dock.removeEventFilter(eng)
        dock._vf_smooth_drag = None
        eng.deleteLater()
    except Exception:
        pass
    return dock
