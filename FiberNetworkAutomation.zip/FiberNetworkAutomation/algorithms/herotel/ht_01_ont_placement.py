# HeroTel: ONT Placement Algorithm (TSD standard)

from qgis.core import (
    QgsProcessingParameterVectorLayer,
    QgsProcessing,
)

from .ht_base_algorithm import HeroTelBaseAlgorithm


class HT01OntPlacementAlgorithm(HeroTelBaseAlgorithm):
    """
    HT 1 — ONT Placement (Overture + RAMP) — TSD standard.

    Detects building footprints from aerial imagery and places one ONT centroid per house.

    PENDING: HeroTel TSD specification document from JJ.
    This is a stub algorithm. Full implementation will:
      1. Query Overture Maps building footprints for the AOI
      2. Fall back to RAMP (ONNX roof detection) for unmapped areas
      3. Generate ONT centroids at representative_point() for each building
      4. Create approximate erf boundaries via Voronoi polygons (clipped to AOI)
      5. Label ONTs as {PROJECT}.ONT.DR{num}
      6. Populate base attributes: lat, lon, type=Home Connection, subtype=ONT

    Run BEFORE: HT 2 (PON Clustering)
    Requires: AOI polygon, high-resolution satellite imagery (0.5m/px or better)
    Produces: ONT v1, Erven v1 (if enabled)
    """

    INPUT = 'INPUT'

    def name(self):
        return 'ht_01_ont_placement'

    def displayName(self):
        return 'HT 1 — ONT Placement (Overture + RAMP)'

    def shortHelpString(self):
        return """
        <p><b>HT 1 — ONT Placement (Overture + RAMP)</b></p>

        <p>Detects building footprints and places one ONT centroid per house.</p>

        <h4>Approach</h4>
        <ol>
          <li><b>Overture Maps</b> — 95% coverage for formal areas; fastest</li>
          <li><b>RAMP ONNX</b> — Fallback for informal/unmapped areas; CNN roof detection on 256px tiles</li>
          <li><b>Voronoi</b> — Generate approximate erf boundaries from ONT centroids</li>
        </ol>

        <h4>Output</h4>
        <ul>
          <li><b>ONT v1</b> — Home Connection points (lat, lon, label, pon_no=NULL initially)</li>
          <li><b>Erven v1</b> — Voronoi polygons clipped to AOI (one per ONT)</li>
        </ul>

        <h4>Requirements</h4>
        <ul>
          <li>AOI polygon layer (defines network boundary)</li>
          <li>High-resolution satellite basemap (0.5m/px or better for RAMP)</li>
          <li>Internet connection (Overture Maps API)</li>
        </ul>

        <p><b>⚠️ PENDING:</b> HeroTel TSD specification from JJ. Full implementation awaiting PDF.</p>
        """

    def initAlgorithm(self, config=None):
        from qgis.core import QgsProject
        proj = QgsProject.instance()
        aoi_layers = proj.mapLayersByName('AOI')

        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT,
                'AOI polygon layer',
                [QgsProcessing.TypeVectorPolygon],
                defaultValue=aoi_layers[0] if aoi_layers else None,
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """Algorithm entry point — STUB pending TSD specification"""
        raise NotImplementedError(
            '\n'.join([
                'HT 1 — ONT Placement is not yet implemented.',
                '',
                'PENDING: HeroTel TSD (Telecommunications System Design) specification from JJ.',
                '',
                'This stub is ready to accept:',
                '  • AOI polygon input',
                '  • Overture Maps API key + bounding box query',
                '  • RAMP ONNX model path + tile configuration',
                '  • Output layer schema for ONT v1 + Erven v1',
                '',
                'Full implementation will cover:',
                '  1. Overture building footprint download + parsing',
                '  2. RAMP inference on 256px chips (fallback for unmapped areas)',
                '  3. Centroid extraction + Hilbert curve DR numbering (1853300+)',
                '  4. Voronoi erf generation + AOI clipping',
                '  5. Label generation + attribute population (lat/lon/type/subtype/spec)',
                '',
                'Contact: ai@velocityfibre.co.za',
            ])
        )

    def postProcessAlgorithm(self, context, feedback):
        return {}
