<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="4.2.0" styleCategories="Symbology|Labeling" labelsEnabled="0">
  <renderer-v2 type="singleSymbol" symbollevels="0" enableorderby="0" forceraster="0" referencescale="-1">
        <symbols>
          <symbol alpha="1" is_animated="0" force_rhr="0" type="fill" clip_to_extent="1" name="0" frame_rate="10">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" name="name" value="" />
                <Option name="properties" />
                <Option type="QString" name="type" value="collection" />
              </Option>
            </data_defined_properties>
            <layer locked="0" pass="0" class="SimpleLine" enabled="1" id="{0379afab-7137-4511-8013-33f036bcd297}">
              <Option type="Map">
                <Option type="QString" name="align_dash_pattern" value="0" />
                <Option type="QString" name="capstyle" value="square" />
                <Option type="QString" name="customdash" value="5;2" />
                <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" />
                <Option type="QString" name="customdash_unit" value="MM" />
                <Option type="QString" name="dash_pattern_offset" value="0" />
                <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" />
                <Option type="QString" name="dash_pattern_offset_unit" value="MM" />
                <Option type="QString" name="draw_inside_polygon" value="0" />
                <Option type="QString" name="joinstyle" value="bevel" />
                <Option type="QString" name="line_color" value="0,0,0,255,rgb:0,0,0,1" />
                <Option type="QString" name="line_style" value="solid" />
                <Option type="QString" name="line_width" value="0.26" />
                <Option type="QString" name="line_width_unit" value="MM" />
                <Option type="QString" name="offset" value="0" />
                <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" />
                <Option type="QString" name="offset_unit" value="MM" />
                <Option type="QString" name="ring_filter" value="0" />
                <Option type="QString" name="trim_distance_end" value="0" />
                <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" />
                <Option type="QString" name="trim_distance_end_unit" value="MM" />
                <Option type="QString" name="trim_distance_start" value="0" />
                <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" />
                <Option type="QString" name="trim_distance_start_unit" value="MM" />
                <Option type="QString" name="tweak_dash_pattern_on_corners" value="0" />
                <Option type="QString" name="use_custom_dash" value="0" />
                <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" name="name" value="" />
                  <Option name="properties" />
                  <Option type="QString" name="type" value="collection" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </symbols>
        <rotation />
        <sizescale />
        <data-defined-properties>
          <Option type="Map">
            <Option type="QString" name="name" value="" />
            <Option name="properties" />
            <Option type="QString" name="type" value="collection" />
          </Option>
        </data-defined-properties>
      </renderer-v2>
</qgis>
