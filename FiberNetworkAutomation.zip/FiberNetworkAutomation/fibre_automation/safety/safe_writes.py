# claude:approved-destructive — this module DEFINES the safe edit/delete wrappers;
# the startEditing/deleteFeatures calls are the wrapper bodies, not a live run.
"""safe_writes — bulletproof layer-edit helpers (bundled; stdlib + native QGIS only).

The PyQGIS edit paths fail quietly: a provider write can return True on a no-op,
an edit session can commit partially, a missing field/CRS mismatch corrupts data
with no error. These helpers make every write either fully succeed or fail LOUD,
and they feed the Geometry Guardian breadcrumb so a bad write is explainable.

  validate_layer(...)        pre-flight gate — raises LayerValidationError, clear msg
  safe_bulk_edit(...)        provider bulk attr write + VERIFY it actually applied
  safe_add_features(...)     add features + verify the count grew
  safe_delete(...)           delete fids + verify the count dropped
  safe_edit(layer)           context manager: commit on success, rollBack on any error

Design: never raises out of the breadcrumb path; pairs with QgsTransaction (for
DB-side atomic rollback on transactional backends) which is layered on separately.
"""
from contextlib import contextmanager

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass


class LayerValidationError(ValueError):
    """A layer failed a pre-flight check — do NOT proceed with the write."""


def _breadcrumb(msg):
    """Record to the Guardian black-box so a failed/odd write is explainable."""
    try:
        from ...geometry_guardian import record_activity
        record_activity(str(msg)[:240])
    except Exception:
        try:
            from FiberNetworkAutomation.geometry_guardian import record_activity
            record_activity(str(msg)[:240])
        except Exception:
            _swallowed_note()


def validate_layer(layer, required_fields=None, required_crs=None, geom_type=None,
                   min_features=0, allow_null_geom=True):
    """Pre-flight gate. Raises LayerValidationError with a clear message on any
    problem, so a bad write never starts. Returns True if the layer is good.

    required_crs : an authid like 'EPSG:4326' (compared to layer.crs().authid())
    geom_type    : QgsWkbTypes geometry type int (0 point / 1 line / 2 polygon)
    """
    from qgis.core import QgsVectorLayer
    if not isinstance(layer, QgsVectorLayer) or not layer.isValid():
        raise LayerValidationError(f"not a valid vector layer: {layer!r}")
    errs = []
    if required_fields:
        have = {f.name() for f in layer.fields()}
        miss = [f for f in required_fields if f not in have]
        if miss:
            errs.append(f"missing fields: {', '.join(miss)}")
    if required_crs:
        authid = layer.crs().authid()
        if authid != required_crs:
            errs.append(f"CRS {authid or '(none)'} != required {required_crs}")
    if geom_type is not None and layer.geometryType() != geom_type:
        errs.append(f"geometry type {layer.geometryType()} != required {geom_type}")
    if layer.featureCount() < min_features:
        errs.append(f"too few features: {layer.featureCount()} < {min_features}")
    if not allow_null_geom:
        nulls = 0
        for f in layer.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                nulls += 1
        if nulls:
            errs.append(f"{nulls} null/empty geometries")
    if errs:
        msg = f"layer '{layer.name()}' failed validation: " + "; ".join(errs)
        _breadcrumb("[safe_writes] " + msg)
        raise LayerValidationError(msg)
    return True


def safe_bulk_edit(layer, fid_attr_map, on_error="abort"):
    """Bulk attribute write via the data provider, then VERIFY it applied (QGIS can
    return True on a silent no-op). fid_attr_map = {fid: {field_idx: value}}.

    on_error='abort' → raise IOError on failure; 'log' → breadcrumb + return count
    actually written. Returns the number of features written.
    """
    if not fid_attr_map:
        return 0
    prov = layer.dataProvider()
    ok = prov.changeAttributeValues(fid_attr_map)
    if not ok:
        msg = (f"changeAttributeValues returned False on '{layer.name()}' "
               f"({len(fid_attr_map)} features)")
        _breadcrumb("[safe_writes] " + msg)
        if on_error == "abort":
            raise IOError(msg)
        return 0
    # spot-verify up to 5 features actually carry the new values
    bad = []
    for fid in list(fid_attr_map)[:5]:
        feat = layer.getFeature(fid)
        if feat is None or not feat.isValid():
            bad.append((fid, "missing"))
            continue
        for idx, val in fid_attr_map[fid].items():
            try:
                if feat.attribute(idx) != val:
                    bad.append((fid, idx))
            except Exception:
                bad.append((fid, idx))
    if bad:
        msg = f"write verification FAILED on '{layer.name()}': {bad[:3]}"
        _breadcrumb("[safe_writes] " + msg)
        if on_error == "abort":
            raise IOError(msg)
        return 0
    try:
        layer.triggerRepaint()
    except Exception:
        _swallowed_note()
    return len(fid_attr_map)


def safe_add_features(layer, feats, on_error="abort"):
    """Add features and verify the feature count actually grew. Returns count added."""
    feats = list(feats)
    if not feats:
        return 0
    prov = layer.dataProvider()
    before = layer.featureCount()
    res = prov.addFeatures(feats)
    ok = res[0] if isinstance(res, tuple) else bool(res)
    try:
        layer.updateExtents()
        layer.triggerRepaint()
    except Exception:
        _swallowed_note()
    added = layer.featureCount() - before
    if not ok or added < len(feats):
        msg = (f"addFeatures incomplete on '{layer.name()}': "
               f"added {added}/{len(feats)} (ok={ok})")
        _breadcrumb("[safe_writes] " + msg)
        if on_error == "abort":
            raise IOError(msg)
    return added


def safe_delete(layer, fids, on_error="abort"):
    """Delete features by id and verify the count dropped. Returns count removed.
    NOTE: callers should mark intentional bulk deletes with the Geometry Guardian's
    note_operator_delete() so the guardian doesn't treat it as an anomaly."""
    fids = list(fids)
    if not fids:
        return 0
    prov = layer.dataProvider()
    before = layer.featureCount()
    ok = prov.deleteFeatures(fids)
    try:
        layer.updateExtents()
        layer.triggerRepaint()
    except Exception:
        _swallowed_note()
    removed = before - layer.featureCount()
    if not ok or removed < len(fids):
        msg = (f"deleteFeatures incomplete on '{layer.name()}': "
               f"removed {removed}/{len(fids)} (ok={ok})")
        _breadcrumb("[safe_writes] " + msg)
        if on_error == "abort":
            raise IOError(msg)
    return removed


@contextmanager
def safe_edit(layer, validate=None):
    """Edit-session context manager with auto-rollback. Use for add/delete/geometry
    edits that must be atomic via the edit buffer:

        with safe_edit(layer, validate={'required_fields': ['pon_no']}):
            layer.addFeature(f)        # any edit-buffer ops

    Commits on clean exit; on ANY exception (or a failed commit) it rolls back the
    whole session and re-raises — so a half-finished batch never persists.
    """
    if validate:
        validate_layer(layer, **validate)
    if layer.isEditable():
        # Already in an edit session (e.g. a manual QGIS edit with uncommitted
        # changes). startEditing() would silently reuse it and our commitChanges()
        # on exit would persist the caller's pending edits too — fail LOUD instead
        # of silently committing someone else's buffer.  # claude:approved-destructive
        _err = (f"layer '{layer.name()}' is already in an edit session — "
                f"safe_edit cannot safely start one")
        _breadcrumb("[safe_writes] " + _err)
        raise LayerValidationError(_err)
    layer.startEditing()
    try:
        yield layer
        if not layer.commitChanges():
            errs = layer.commitErrors()
            try:
                layer.rollBack()
            except Exception:
                _swallowed_note()
            msg = f"commit failed on '{layer.name()}': {errs}"
            _breadcrumb("[safe_writes] " + msg)
            raise IOError(msg)
    except Exception:
        try:
            if layer.isEditable():
                layer.rollBack()
        except Exception:
            _swallowed_note()
        raise
