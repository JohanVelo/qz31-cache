# -*- coding: utf-8 -*-
"""Keep the installed plugin folder deletable so QGIS "Upgrade" can always replace it.

QGIS's plugin installer deletes the old plugin folder before unpacking the new zip. On
Windows a folder (or file) carrying the ReadOnly attribute cannot be removed, so the
installer stops half-way: the files are gone, a few empty read-only folders remain, and
QGIS reports "Failed to remove the directory ... Check permissions" followed by
"This plugin is broken - Missing metadata file" (JJ, 2026-11-11, v2.5.375 upgrade).

The flag arrives from OneDrive, which marks synced workspace folders ReadOnly; any copy
that carries folder attributes across brings it into the install. Clearing it on every
load is cheap (~500 entries) and makes the next upgrade succeed whatever put it there.
"""
import os
import stat


def clear_readonly(root=None):
    """Clear the ReadOnly attribute on `root` and everything under it. Returns the count.
    Windows only; never raises."""
    if os.name != "nt":
        return 0
    root = root or os.path.dirname(os.path.abspath(__file__))
    n = 0
    try:
        for dp, _dn, fn in os.walk(root):
            for p in [dp] + [os.path.join(dp, f) for f in fn]:
                try:
                    if os.stat(p).st_file_attributes & stat.FILE_ATTRIBUTE_READONLY:
                        os.chmod(p, stat.S_IWRITE | stat.S_IREAD)
                        n += 1
                except OSError:
                    continue
    except Exception:
        return n
    return n
