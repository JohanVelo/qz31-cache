"""Fibre Time Step 1 — Create all project layers, groups, and apply styles."""

from qgis.PyQt.QtCore import QMetaType
from qgis.core import QgsCoordinateReferenceSystem, QgsProject, QgsWkbTypes

from fibre_automation.startup import SESSION
from fibre_automation.shared.layer_utils import (
    apply_label,
    apply_ft_style,
    create_shapefile,
    get_or_create_group,
    load_or_create_layer,
)

S = QMetaType.Type.QString
D = QMetaType.Type.Double
I = QMetaType.Type.Int
L = QMetaType.Type.LongLong

# ── Admin fields — both short and long forms kept (FT1 writes both) ──────────
# Order: company → municipality → location fields → stack → date → created-by → status
_STATIC = [
    ("cmpownr", S), ("companyown", S),   # company owner        (short | long)
    ("mun", S),     ("municipal", S),    # municipality         (short | long)
    ("subplace", S),                      # sub place
    ("mainplce", S), ("mainplace", S),   # main place           (short | long)
    ("stackref", S), ("stack", S),       # stack reference      (short | long)
    ("datecrtd", S),                      # date created
    ("crtdby", S),  ("createdby", S),    # created by           (short | long)
    ("status", S),                        # feature status
]

# ── Canonical FT layer definitions (MOA v1 schema) ───────────────────────────
# Column order within each layer follows: identity → specs → lengths → topology → location → network → admin → hardware
# (layer_name, WKB type, [(field_name, QVariant_type), ...], sub-group)

FT_LAYER_DEFS = [

    # ── Boundary / polygon layers ─────────────────────────────────────────────
    (
        "P2 AOI Poly",
        QgsWkbTypes.Type.Polygon,
        [("id", S), ("Name", S), ("Discriptio", S)],
        "Boundaries",
    ),
    (
        "Erven",
        QgsWkbTypes.Type.Polygon,
        # Cadastral parcel data from CSG — PRCL_KEY = SG21 parcel reference
        [("Label", S), ("Area", D), ("PRCL_KEY", S), ("LSTATUS", S), ("WSTATUS", S)],
        "Boundaries",
    ),
    (
        "Buildings",
        QgsWkbTypes.Type.Polygon,
        # building_t filled by Step 2 classifier (SDU / MDU / SHACK)
        [("id", S), ("Name", S), ("Discriptio", S), ("building_t", S),
         ("area_m2", D), ("is_primary", I)],
        "Boundaries",
    ),
    (
        "PON v1",
        QgsWkbTypes.Type.Polygon,
        # FT5 writes label/pon_no/zone_no/units/n_sts; FT6 may update pon_no
        [("label", S), ("pon_no", I), ("zone_no", I), ("units", I), ("n_sts", I),
         ("type", S), ("subtyp", S), ("spec", S),
         ("stackref", S), ("status", S)],
        "Boundaries",
    ),
    (
        "Zones v1",
        QgsWkbTypes.Type.Polygon,
        [("label", S), ("pon_no", I), ("zone_no", I), ("units", I), ("n_sts", I),
         ("type", S), ("subtyp", S), ("spec", S),
         ("stackref", S), ("status", S)],
        "Boundaries",
    ),

    # ── Point / infrastructure layers ─────────────────────────────────────────
    (
        "Poles v1",
        QgsWkbTypes.Type.Point,
        [
            # ── Identity ─────────────────────────────────────────────────────
            ("Label", S),        # pole label e.g. MOA.P.H001  (FT1 writes)
            ("Pole Type", S),    # Primary Feeder / Secondary Feeder / Distribution / Drop

            # ── Location ─────────────────────────────────────────────────────
            ("lat", D), ("lon", D),   # WGS84 decimal degrees   (FT1 writes)
            ("X", D),   ("Y", D),     # same coords, alternate names (FT1 writes)

            # ── Thickness classification (FT7 writes) ─────────────────────────
            ("dim2", S),         # FOA class: "140-160mm" or "120-140mm"
            ("thickness_", S),   # reason string (anchor/intermediate/road crossing)

            # ── Network assignment (FT5/FT6 write) ───────────────────────────
            ("pon_no", I), ("zone_no", I),

            # ── Admin fields (FT1 writes) — short form first, long form second
            ("cmpownr", S), ("companyown", S),
            ("crtdby", S),  ("createdby", S),
            ("mun", S),     ("municipal", S),
            ("subplace", S),
            ("mainplce", S), ("mainplace", S),
            ("stack", S),   ("stackref", S),
            ("datecrtd", S), ("status", S),

            # ── Hardware Slot 2 — Dead-End (FT8 writes) ──────────────────────
            ("type_2", S), ("subtype_2", S), ("dim1_2", S), ("spec_2", S),
            ("featno1", I),   # number of cable ways

            # ── Hardware Slot 3 — Tangent (FT8 writes; PF poles only) ─────────
            ("type_3", S), ("subtype_3", S), ("dim1_3", S), ("spec_3", S),
            ("featno2", I),   # number of tangent ways

            # ── Hardware Slot 4 — Hook / Offset Bracket (FT8 writes) ─────────
            ("type_4", S), ("subtype4", S), ("dim1_4", S), ("spec_4", S),
            # note: subtype4 has NO underscore — matches MOA shapefile schema

            # ── Hardware Slot 5 — Slack Bracket (manual only, FT8 does not write)
            ("type_5", S), ("subtype5", S), ("dim1_5", S), ("spec_5", S),
            # note: subtype5 has NO underscore — matches MOA shapefile schema

            # ── Hardware Slot 6 — BandIt Strap (FT8 writes; every pole) ──────
            ("type_6", S), ("subtype_6", S), ("dim1_6", S), ("spec_6", S),
            ("featno5", I),   # strap count (always 4)

            # ── Hardware Slot 7 — BandIt Buckle (FT8 writes; every pole) ─────
            ("type_7", S), ("subtype7", S), ("dim1_7", S), ("spec_7", S),
            ("featno6", I),   # buckle count (always 2)
            # note: subtype7 has NO underscore — matches MOA shapefile schema
        ],
        "Infrastructure",
    ),
    (
        "FTS Splitters v1",
        QgsWkbTypes.Type.Point,
        # 1:8 splitter — one per PON; FT4 writes label/type/subtyp/spec/strtfeat
        [("label", S), ("type", S), ("subtyp", S), ("spec", S),
         ("lat", D), ("lon", D),
         ("strtfeat", S),
         ("pon_no", I), ("zone_no", I)] + _STATIC,
        "Infrastructure",
    ),
    (
        "STS Splitters v1",
        QgsWkbTypes.Type.Point,
        # 1:16 splitter — up to 8 per FTS; FT4 writes label/type/subtyp/spec/strtfeat
        [("label", S), ("type", S), ("subtyp", S), ("spec", S),
         ("lat", D), ("lon", D),
         ("strtfeat", S),
         ("pon_no", I), ("zone_no", I)] + _STATIC,
        "Infrastructure",
    ),
    (
        "Enclosures Connectorised v1",
        QgsWkbTypes.Type.Point,
        # Connectorised dome joint — DIS type at STS location; FT4 writes label_1
        [("label_1", S), ("type", S), ("subtyp", S),
         ("spec_1", S), ("cblcpty1", S),
         ("strtfeat", S),
         ("lat", D), ("lon", D),
         ("pon_no", I), ("zone_no", I),
         ("cmpownr", S), ("mun", S), ("subplace", S), ("mainplce", S),
         ("stackref", S), ("datecrtd", S), ("crtdby", S), ("status", S)],
        "Infrastructure",
    ),
    (
        "Enclosures Splice v1",
        QgsWkbTypes.Type.Point,
        # Splice dome joint — AGG type on feeder route; FT4 writes label_1
        [("label_1", S), ("type", S), ("subtyp", S),
         ("spec_1", S), ("cblcpty1", S),
         ("strtfeat", S),
         ("lat", D), ("lon", D),
         ("pon_no", I), ("zone_no", I),
         ("cmpownr", S), ("mun", S), ("subplace", S), ("mainplce", S),
         ("stackref", S), ("datecrtd", S), ("crtdby", S), ("status", S)],
        "Infrastructure",
    ),
    (
        "ONT v1",
        QgsWkbTypes.Type.Point,
        # Optical Network Terminal — one per home; label = MOA.ONT.DR<num>
        [("label", S), ("type", S), ("subtyp", S), ("spec", S),
         ("lat", D), ("lon", D),
         ("strtfeat", S),
         ("pon_no", I), ("zone_no", I)] + _STATIC,
        "Infrastructure",
    ),
    (
        "Home Connection v1",
        QgsWkbTypes.Type.Point,
        # Home connection point — paired with ONT; label = MOA.ONT.DR<num>
        [("label", S), ("type", S), ("subtyp", S), ("spec", S),
         ("lat", D), ("lon", D),
         ("strtfeat", S),
         ("pon_no", I), ("zone_no", I)] + _STATIC,
        "Infrastructure",
    ),

    # ── Cable / line layers ───────────────────────────────────────────────────
    # Column order: label → type/subtyp/spec → dim1/dim2 → capacity/connector/network
    #               → tlenght/slenght → strtfeat/endfeat → lat/lon → pon/zone → admin
    (
        "Drop Cable v1",
        QgsWkbTypes.Type.LineString,
        # 1F drop — ONT to STS; label = DR<num> (bare number, no prefix)
        [("label", S), ("type", S), ("subtyp", S), ("spec", S),
         ("dim1", S), ("cblcpty", S),
         ("tlenght", D), ("slenght", D),
         ("strtfeat", S), ("endfeat", S),
         ("lat", D), ("lon", D),
         ("pon_no", I), ("zone_no", I)] + _STATIC,
        "Cables",
    ),
    (
        "Spare Drop Cable v1",
        QgsWkbTypes.Type.LineString,
        # Unused spare drop — same schema as Drop Cable
        [("label", S), ("type", S), ("subtyp", S), ("spec", S),
         ("dim1", S), ("cblcpty", S),
         ("tlenght", D), ("slenght", D),
         ("strtfeat", S), ("endfeat", S),
         ("lat", D), ("lon", D),
         ("pon_no", I), ("zone_no", I)] + _STATIC,
        "Cables",
    ),
    (
        "Distribution Cable v1",
        QgsWkbTypes.Type.LineString,
        # 24F Mini-ADSS — STS to FTS; FT2 writes label/lengths/strtfeat/endfeat
        [("label", S), ("type", S), ("subtyp", S), ("spec", S),
         ("dim1", S), ("dim2", S), ("cblcpty", S), ("conntr", S), ("ntwrkptn", S),
         ("tlenght", D), ("slenght", D),
         ("strtfeat", S), ("endfeat", S),
         ("lat", D), ("lon", D),
         ("pon_no", I), ("zone_no", I)] + _STATIC,
        "Cables",
    ),
    (
        "Secondary Cable v1",
        QgsWkbTypes.Type.LineString,
        # 24F+ Mini-ADSS — FTS groups to trunk; FT3 writes label/lengths/strtfeat/endfeat
        [("label", S), ("type", S), ("subtyp", S), ("spec", S),
         ("dim1", S), ("dim2", S), ("cblcpty", S), ("conntr", S), ("ntwrkptn", S),
         ("tlenght", D), ("slenght", D),
         ("strtfeat", S), ("endfeat", S),
         ("lat", D), ("lon", D),
         ("pon_no", I), ("zone_no", I)] + _STATIC,
        "Cables",
    ),
    (
        "Primary Cable v1",
        QgsWkbTypes.Type.LineString,
        # 96F ADSS — trunk to POP along main road
        [("label", S), ("type", S), ("subtyp", S), ("spec", S),
         ("dim1", S), ("dim2", S), ("cblcpty", S), ("conntr", S), ("ntwrkptn", S),
         ("tlenght", D), ("slenght", D),
         ("strtfeat", S), ("endfeat", S),
         ("lat", D), ("lon", D),
         ("pon_no", I), ("zone_no", I)] + _STATIC,
        "Cables",
    ),
    (
        "Span v1",
        QgsWkbTypes.Type.LineString,
        # Geometric pole-to-pole span for compliance checking (max 70m feeder, 50m drop)
        [("strtfeat", S), ("endfeat", S), ("span_m", D),
         ("cable_lay", S), ("exceeds", I)],
        "Cables",
    ),
]


def _add_ngi_basemap(proj):
    """Add NGI 25cm aerial XYZ tile layer at the bottom of the layer tree."""
    existing_names = {l.name() for l in proj.mapLayers().values()}
    if any(n in existing_names for n in ("NGI Aerial", "Google Satellite")):
        return
    try:
        from qgis.core import QgsRasterLayer
        url = (
            "type=xyz"
            "&url=https://aerial.openstreetmap.org.za/layer/ngi-aerial/%7Bz%7D/%7Bx%7D/%7By%7D.jpg"
            "&zmax=20&zmin=0"
        )
        lyr = QgsRasterLayer(url, "NGI Aerial", "wms")
        if not lyr.isValid():
            print("  ⚠ NGI basemap layer invalid — skipping")
            return
        # Let the layer-tree own the node (addLayer appends at the bottom of the
        # panel) instead of a hand-built QgsLayerTreeLayer + insertChildNode(-1),
        # which was fragile on older QGIS (registered-but-legendless / dropped).
        proj.addMapLayer(lyr, False)
        proj.layerTreeRoot().addLayer(lyr)
        print("  ✓ NGI 25cm aerial basemap added")
    except Exception as e:
        print(f"  ⚠ Basemap add failed: {e}")


def ft_step_01_setup():
    """Create all Fibre Time layers, groups, fields, and symbology.

    STATUS: [x] BUILT
    Safe to re-run — skips layers that already exist.
    """
    area = SESSION.get("area_code")
    if not area:
        print("✗ No project active — use the New Project wizard first.")
        return
    crs = SESSION.get("crs")
    crs_authid = crs.authid() if crs else "EPSG:4326"

    folder_path = SESSION.get("project_folder")
    if not folder_path:
        from qgis.PyQt.QtWidgets import QFileDialog
        folder_path = QFileDialog.getExistingDirectory(
            None,
            f"Select folder to save {area} shapefiles",
        )
        if not folder_path:
            print("✗ No folder selected — setup cancelled.")
            return
        SESSION["project_folder"] = folder_path

    print(f"\n{'═' * 55}")
    print("  FIBRE TIME STEP 1 — Layer Setup")
    print(f"  Area: {area}  |  CRS: {crs_authid}")
    print(f"  Folder: {folder_path}")
    print(f"{'═' * 55}")

    group_name = f"FibreTime — {area}"
    root_group = get_or_create_group(group_name)

    sub_groups = {}
    for sub in ("Boundaries", "Infrastructure", "Cables"):
        sub_groups[sub] = get_or_create_group(sub, parent=root_group)

    created = []
    skipped = []
    errors = []

    for layer_name, wkb_type, field_defs, sub_group_name in FT_LAYER_DEFS:
        try:
            was_new = not QgsProject.instance().mapLayersByName(layer_name)
            shp_path = create_shapefile(
                layer_name,
                wkb_type,
                field_defs,
                folder_path,
                crs_authid=crs_authid,
                overwrite=False,
            )
            lyr = load_or_create_layer(
                layer_name,
                shp_path,
                sub_groups[sub_group_name],
            )
            if lyr:
                apply_ft_style(lyr)
                lyr.saveNamedStyle(shp_path.replace(".shp", ".qml"))
                name_field = None
                for candidate in ("Label", "label", "Name"):
                    if lyr.fields().indexOf(candidate) >= 0:
                        name_field = candidate
                        break
                # Only label infrastructure/cable layers — never boundary polygons
                label_layers = {"Poles v1", "STS Splitters v1", "FTS Splitters v1",
                                "Enclosures Connectorised v1", "Enclosures Splice v1",
                                "Distribution Cable v1", "Secondary Cable v1", "Primary Cable v1"}
                if name_field and layer_name in label_layers:
                    apply_label(lyr, name_field)
                (created if was_new else skipped).append(layer_name)
        except Exception as exc:
            errors.append(layer_name)
            print(f"  ✗ ERROR creating {layer_name}: {exc}")

    proj = QgsProject.instance()
    if not proj.crs().isValid():
        proj.setCrs(QgsCoordinateReferenceSystem(crs_authid))

    _add_ngi_basemap(proj)

    from qgis.utils import iface
    iface.mapCanvas().refresh()

    print(f"\n  ✓ Created: {len(created)}  |  ⊘ Exists: {len(skipped)}  |  ✗ Errors: {len(errors)}")
    if errors:
        for e in errors:
            print(f"    ✗ {e}")
    print(f"{'═' * 55}\n")

    # Auto-fetch cadastral + buildings if AOI polygon is already present
    aoi_source = SESSION.get("aoi_source")
    if aoi_source:
        try:
            from fibre_automation.vuma.step_01_setup import _copy_aoi_into_layer
            _copy_aoi_into_layer(aoi_source)
        except Exception as exc:
            print(f"  ⚠ AOI copy skipped — {exc}")

    from fibre_automation.vuma.step_01b_fetch import vuma_step_01b_fetch
    vuma_step_01b_fetch(silent_if_no_aoi=True)
