

def _safe_ellipsoid(project, crs=None):
    """Never 'NONE' — see fibre_automation/shared/crs_utils.safe_ellipsoid.

    QgsProject.ellipsoid() returns the STRING 'NONE' for a project with no
    ellipsoid (QGIS's default for a new project). 'NONE' is truthy, so
    `project.ellipsoid() or "WGS84"` did NOT fall back and lengths came back in
    DEGREES — a 1976 m cable measuring 0.019. Found 2026-07-15.
    """
    try:
        from fibre_automation.shared.crs_utils import safe_ellipsoid
        return safe_ellipsoid(project, crs)
    except Exception:
        pass
    for get in (lambda: project.ellipsoid(),
                (lambda: crs.ellipsoidAcronym()) if crs is not None else None):
        if get is None:
            continue
        try:
            v = (get() or "").strip()
        except Exception:
            continue
        if v and v.upper() != "NONE":
            return v
    return "WGS84"
# -*- coding: utf-8 -*-
# ============================================================================
# HLD Atlas Engine  (Phase 0 — config-driven)
# ----------------------------------------------------------------------------
# Builds two editable QgsPrintLayouts in the CURRENT project:
#     <layout_overview>  (1 page: PON numbers + feeder routes)
#     <layout_atlas>     (N pages: one per coverage feature, full detail)
# A3 landscape, big map + sidebar (Legend / North / logo / title block),
# matching the Phase 1 reference deliverable.
#
# Idempotent: removes+recreates its own layouts each run. Does NOT export
# (export is a separate headless step — never render a big atlas on the GUI thread).
#
# DE-HARDCODED: every project-specific value lives in DEFAULT_CFG below.
# A caller injects overrides by defining a dict `HLD_CFG` in the namespace
# BEFORE exec()'ing this file, then calls build() explicitly:
#     ns = {"HLD_CFG": {...}}
#     exec(open("hld_atlas_engine.py").read(), ns)   # defines; builds nothing
#     ns["build"]()                                  # runs the build
# With no HLD_CFG defined, it reproduces the Mohadin Phase 2 PDF exactly.
#
# EXEC'ING THIS FILE NO LONGER BUILDS. It used to end in a bare build_all(), so
# loading the module WAS the build - see research/A2_explicit_entry_point.md.
# Set HLD_AUTORUN = True in the namespace before exec() for the old behaviour
# (e.g. pasting this file straight into the QGIS Python console).
# ============================================================================
import os
import copy
from qgis.core import (
    QgsProject, QgsPrintLayout, QgsLayoutItemPage, QgsLayoutItemMap,
    QgsLayoutItemLabel, QgsLayoutItemPicture, QgsLayoutItemShape,
    QgsLayoutPoint, QgsLayoutSize, QgsUnitTypes, QgsRectangle, QgsLayoutMeasurement,
)
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtCore import QMetaType

# ---------------------------------------------------------------------------
# DEFAULT CONFIG = Mohadin Phase 2 (the proven deliverable).
# ---------------------------------------------------------------------------
def _default_legend_dir():
    """Per-user, always-writable scratch directory for the rendered legend swatches."""
    import tempfile
    return os.path.join(tempfile.gettempdir(), "vf_hld_legend")


DEFAULT_CFG = {
    # --- live-layer safety ---
    # The _style_* helpers below call setRenderer()/setLabeling() on the OPERATOR'S OWN
    # layers, which overwrites whatever symbology and labelling they had configured.
    # A build must render the project as the operator has it, so this is OPT-IN and
    # defaults to False. Set True (dialog tick) to apply the HLD house style.
    "restyle_layers": False,

    # --- isolate the unit on each detail page ---
    # QGIS-native atlas clipping on the detail map: everything outside the current page's
    # coverage polygon (the PON) is cut away, so one PON stands alone on its page. Layers
    # whose name contains one of `atlas_clip_keep` (backbone cables) plus rasters and the AOI
    # stay unclipped for context. Off by default — the book renders exactly as before.
    "atlas_clip": False,
    "atlas_clip_keep": ["feeder", "primary", "adss"],

    # --- identity / title block ---
    "project_name":   "Mohadin Phase 2",
    "company":        "Velocity Fibre",
    "designer":       "Johan Scholtz",
    "date_str":       "07-07-2026",
    "revision":       "1",
    # P1.4 ISO 7200 title block: dynamic Sheet "X of Y" + revision history + sign-off.
    # False → the simple 5-row block (MOA deliverable unchanged).
    "iso_title_block": False,
    "scale_note":      "As-Shown (A3)",
    "revision_rows":   [],          # [(rev, date, description, by), ...] up to 5
    "signoff":         ["Designed", "Reviewed", "Approved"],
    "cover_page":      False,       # P3: prepend a KPI + table-of-contents cover page (hld_generate)
    "title_overview": "Mohadin Phase 2 Overview",
    "title_atlas_expr": 'Mohadin Phase 2 - PON [% "pon_no" %]',   # dynamic per-page

    # --- assets ---
    # Written to at build time (every legend swatch is rendered to a PNG here and then
    # placed in the layout), so it MUST be somewhere every teammate can write. It used to
    # be C:/Temp/ph2_hld_assets/legend — fine on the machine that wrote it, and on a
    # laptop where C:\Temp is not writable the swatches silently fail to save and the
    # legend loses every row that is drawn from real symbology. The OS temp directory is
    # per-user and always writable; a preset may still override it.
    "logo_path":  "",                       # client presets resolve their own bundled logo
    "legend_dir": _default_legend_dir(),

    # --- layout names ---
    # The deliverable is ONE Report: header = overview (page 1), field-group body =
    # one detail page per coverage feature. The overview/detail layouts are OWNED by
    # the report (not separate entries in the Layout Manager).
    "layout_overview": "MOA PH2 HLD Overview",     # report header (page 1)
    "layout_atlas":    "MOA PH2 HLD Atlas",        # report body (per-PON detail)
    "layout_report":   "MOA PH2 HLD Book",         # the QgsReport shown in the manager

    # --- layer resolution ---
    "group_name":  "phase 2 hld",   # resolve layers inside this group (JJ renames v1->friendly)
    "aoi_layer":   "greenfield and overbuild poly",
    "aoi_subset":  '"Name" = \'Greenfield\'',   # only the Greenfield polygon; None to keep all
    "basemap":     "Google Satellite",

    # role -> ordered candidate layer names (first found wins; group first, then whole project)
    "roles": {
        "coverage":     ["PON v1"],
        "primary":      ["ADSS", "Primary Cable v1"],
        "secondary":    ["Secondary Cable v1", "Secondary Cable"],
        "distribution": ["Mini-ADSS", "Distribution Cable v1"],
        "drop":         ["Drop Cable", "Drop Cable v1"],
        "spare_drop":   ["Spare Drop Cable v1", "Spare Drop Cable"],
        "poles":        ["Pole", "poles v1"],
        "fts":          ["FTS Splitter", "FTS Splitters v1"],
        "sts":          ["STS Splitter", "STS Splitters v1"],
        "enc_splice":   ["Enclosures Splice v1", "Enclosures Splice"],
        "enc_conn":     ["Enclosures Connectorised v1", "Enclosures Connectorised"],
        "enclosure":    ["Enclosure v1"],
        "ont":          ["ONT v1"],
        # stable area layers for the summary (independent of the atlas coverage choice)
        "pon_area":     ["PON v1", "PON"],
        "zones":        ["Zones v1", "Zone v1", "Zones", "Zone"],
    },

    # detail-page layers when there is NO group (saved 'HLD only' project). Draw order = top first.
    # NO primary/secondary feeders (they are overview-only).
    "detail_fallback": [
        "STS Splitters v1", "STS Splitter",
        "Enclosures Splice v1", "Enclosures Splice",
        "Enclosures Connectorised v1", "Enclosures Connectorised",
        "FTS Splitters v1", "FTS Splitter",
        "ONT v1", "Distribution Cable v1", "Mini-ADSS",
        "Drop Cable v1", "Drop Cable", "Spare Drop Cable v1",
        "poles v1", "Pole", "PON v1",
    ],
    "detail_exclude": ["Zones v1", "where slack applies", "Erven v1"],

    # --- atlas ---
    "coverage_sort_field": "label",
    "atlas_filename_expr": "'MOA_PH2_PON_' || \"label\"",
    "atlas_margin": 0.15,

    # --- grid coverage (auto-tile the AOI; one detail page per grid cell) ---
    # >0 triggers grid mode: the engine builds a grid over the AOI polygon at this cell
    # size (metres) and uses it as the coverage. Cell width/height come from the box the
    # operator drags on the canvas. 0 = off (per-PON / per-Zone coverage as normal).
    "grid_cell_w_m": 0.0,
    "grid_cell_h_m": 0.0,
    "grid_layer_name": "HLD Grid",

    # "report" (Generate PDF: one book, overview page 1) | "layouts" (Open in Print Layout:
    # page-view overview + detail atlas you edit directly). Set by the caller.
    "build_mode": "report",

    # --- styling ---
    "enc_splice_rgb": "0,60,255",    # splice = blue
    "enc_conn_rgb":   "0,200,200",   # connectorised = cyan
    "pon_fill_alpha": 45,            # see houses through the PON fill
    # P1.3 optional tiered cable symbology. None = keep each layer's own style
    # (default → MOA deliverable unchanged). Else role -> {"w": <mm>, "color": "#hex"}
    # applied at build time so cluttered per-project cable styles become a clean HLD look.
    "hld_cable_style": None,
    # P2 QA overlay: flag cables whose longest pole-to-pole span (max vertex-to-vertex
    # segment) exceeds the limit, drawn thick RED on the map so violations show on the
    # page. False/{} = off (MOA unchanged). qa_span_limits: role -> max span (metres).
    "hld_qa_overlay": False,
    "qa_span_limits":  {},          # e.g. {"drop": 75, "distribution": 70, "primary": 70}

    # --- labels: role -> settings dict (label ON) or None (label OFF on detail pages) ---
    "labels": {
        "distribution": {"size": 5.5, "along_line": True,  "buf": 0.8, "strip": "MOA."},
        "poles":        {"size": 5.0, "along_line": False, "buf": 0.5, "strip": "MOA.P."},
        "fts":          {"size": 6.5, "along_line": False, "buf": 0.8, "strip": "MOA."},
        "sts":          {"size": 5.5, "along_line": False, "buf": 0.8, "strip": "MOA.STS.8.DIS.DM.P."},
        "primary":   None,   # feeders overview-only
        "secondary": None,
        "drop":      None,   # drop labels OFF (JJ)
        "spare_drop": None,
    },
    "label_min_scale": 9000.0,

    # --- legend ---
    # points render the layer's REAL symbol; lines draw as a coloured bar
    "legend_points": [
        ("FTS Splitter", "fts"), ("STS Splitter", "sts"),
        ("Enclosure (Splice)", "enc_splice"), ("Enclosure (Connectorised)", "enc_conn"),
        ("Pole", "poles"),
    ],
    "legend_lines": [
        ("ADSS", "primary", "#0000ff"),
        ("Mini-ADSS", "distribution", "#ef3ec8"),
        ("Drop Cable", "drop", "#29a500"),
    ],
    # GUARD RAIL: auto-complete the legend from the layers actually drawn on the map,
    # so nothing on the canvas is left out (the configured rows above render first for
    # nice names/order; any remaining drawn layer is appended with its REAL symbol).
    "legend_auto":         True,
    "legend_basemap_note": "Satellite Photography",
    "legend_compact":      False,    # tight rows/font (force); else auto below legend_max_h
    "legend_max_h":        82.0,     # mm: a taller normal legend auto-re-renders compact
    # raw layer name -> friendly legend label (else the name minus a trailing " v1")
    "legend_aliases": {
        "ONT v1":               "Home Connections (ONT)",
        "Home Connection v1":   "Home Connections",
        "Spare Drop Cable v1":  "Spare Drop Cables",
        "Secondary Cable v1":   "Secondary Feeder",
        "Primary Cable v1":     "Primary Feeder (ADSS)",
        "Distribution Cable v1": "Distribution (Mini-ADSS)",
        "PON v1":               "PONs",
        "Zones v1":             "Zones",
        "Erven v1":             "Erfs",
        "poles v1":             "Poles",
        "greenfield and overbuild poly": "Project Boundary",
    },

    # --- sidebar detail (fill the empty space with real info, like the reference) ---
    "show_map_info":   True,                 # Scale / Projection block
    "projection_note": "EPSG:4326 · WGS 84",
    "show_summary":    True,                 # project feature-count summary panel
    "summary_title":   "PROJECT TOTALS",
    # per-PAGE summary: when True, atlas detail pages show the CURRENT coverage
    # feature's own stats (from its stat_* fields) instead of whole-project totals.
    "per_page_summary": False,
    "zone_stat_source": {},        # {"units":"<zone field>","splitters":"<zone field>"} or {}
    "zone_stat_prefix": "ZONE ",
    # --- P3.3 per-page cable schedule table (config-gated; off => default/MOA unchanged) ---
    # A native QgsLayoutItemAttributeTable on the chosen cable role, filtered to the current
    # atlas unit (only cables intersecting THIS PON/Zone), row-capped, hidden on the overview.
    "per_page_table": False,
    "table_role":     "distribution",   # which cable role to schedule (drops would be 100s/unit)
    "table_columns":  None,             # [(field,"Header"), ...] or None -> auto-pick from fields
    "table_max_rows": 40,
    "table_title":    "CABLE SCHEDULE",
    "table_box_h":    58.0,             # sidebar box height (mm) reserved for title + table
    "summary_roles": [                       # (label, role) — counts read live at build time
        ("Homes (ONT)", "ont"),      ("Poles", "poles"),
        ("FTS Splitters", "fts"),    ("STS Splitters", "sts"),
        ("Enclosures", "enclosure"), ("PONs", "pon_area"),
        ("Zones", "zones"),          ("Drop Cables", "drop"),
        ("Spare Drops", "spare_drop"), ("Distribution", "distribution"),
    ],

    # --- page size for new_layout: "A3" (HLD/commercial) | "A4" (wayleave) ---
    "page_size":    "A3",

    # --- MODEL / frame style: "hld" (default network atlas) | "commercial" (grid drawing)
    #     | "wayleave" (A4 grid wayleave — Cambridge Village style: full-bleed map + bottom
    #       title strip + Poles/Span/Erven/POP legend + Velocity logo) ---
    "frame_style":  "hld",
    # wayleave bottom-strip content (only used by frame_style == "wayleave"):
    "wayleave_desc": ("Application for wayleave for the purpose of installing aerial fibre.\n"
                      "Fibre to be installed exclusively in mid-block deployment so as to avoid "
                      "any other services."),
    "wayleave_scale_note": "NTS",

    # ── wayleave house symbology (project-agnostic: matched on LAYER-NAME KEYWORDS,
    #    never on a fixed layer name, so the same preset styles any town's project) ──
    # Span/route pink is the colour Velocity already draws distribution cable in, so the
    # wayleave sheet and the working QGIS project read the same. Poles are red and demand
    # points stay white, which is what separates "the thing we are applying for" from
    # "the houses it serves" on a printed A4. Any of these can be overridden per client.
    # Measured off the issued reference sheet (Burgersdorp Wayleave.pdf): the span red is
    # 255,34,0 and the poles are small HOLLOW circles, not filled dots. Eleven wayleaves
    # have already gone to municipalities looking like this, so this is the house standard
    # and every new drawing has to match the ones clients have signed.
    "wayleave_span_color":      "255,34,0",
    "wayleave_span_width":      0.6,
    "wayleave_pole_color":      "255,255,255",
    "wayleave_pole_outline":    "0,0,0",
    "wayleave_pole_outline_w":  0.3,
    "wayleave_pole_size":       1.4,
    "wayleave_demand_color":    "255,255,255",
    "wayleave_demand_outline":  "85,85,85",
    "wayleave_demand_outline_w": 0.1,
    "wayleave_demand_size":     1.1,
    # The obstacle is the thing the route must NOT cross, so it is drawn in warning red
    # rather than whatever colour the operator's project happens to use (Fouriesburg had
    # it in a sandy orange that read as farmland). Poles are red too, but a solid polygon
    # and a 1.4 mm dot will not be confused, and the legend names both.
    "wayleave_obstacle_color":   "255,0,0",
    "wayleave_obstacle_outline": "35,35,35",

    # ── wayleave label sizes, in POINTS, pinned per role ──
    # The erf numbers arrived at 10 pt against 5 pt pole numbers, so on a detail page the
    # cadastral numbering covered the route it is supposed to sit behind. Sizes are pinned
    # (not scaled) and the unit is forced to Points, because "the same result on any
    # project" has to survive a project whose labels are set in map units — where a
    # relative tweak means metres and the sheet comes out unreadable in a different way.
    # None for any role leaves that layer's labelling exactly as the operator set it.
    "wayleave_erf_label_size":      5.0,
    "wayleave_erf_label_buffer":    0.5,      # mm
    "wayleave_pole_label_size":     5.0,
    "wayleave_route_label_size":    5.5,
    "wayleave_splitter_label_size": 6.5,
    # Which numbering the sheet actually carries. A wayleave asks a municipality for
    # permission over ERVEN, so the erf number is the only number that has a reader: the
    # pole, cable and splitter numbering is ours, it means nothing to them, and at sheet
    # scale it buried the route it was printed over. Off here, untouched on the layers
    # themselves — the operator's own labelling comes back the moment they close without
    # saving. Street names are kept: they are how a reader finds the place on the ground.
    "wayleave_erf_labels":       True,
    # Field candidates for the erf number, in order. Only used when the project has no
    # erven labelling of its own — then the sheet builds one, because "the erf number is
    # the only number on the drawing" cannot depend on the operator having set it up.
    # Matched case-insensitively, first hit wins; anything not listed still gets picked up
    # by the erf/parcel/stand/lot name sniff in _build_erf_labeling.
    "wayleave_erf_fields": ["PARCEL_NO", "ERF_NO", "ERFNO", "ERF", "ERF_NUMBER",
                            "ERFNUMBER", "STAND_NO", "STANDNO", "STAND", "PARCEL",
                            "PARCELNO", "PRCL_NO", "LOT_NO", "LOTNO", "PLOT_NO",
                            "SG_CODE", "SG26_CODE", "CADASTRE", "PORTION", "label"],
    "wayleave_pole_labels":      True,     # the reference sheet numbers its poles
    "wayleave_route_labels":     False,
    "wayleave_splitter_labels":  False,
    "wayleave_demand_labels":    False,

    # ── things the wayleave does NOT show ──
    # A wayleave asks a municipality for permission over a ROUTE. Splitters and demand
    # points are our internal build detail, they are not on the reference sheet, and an
    # unexplained mark on a drawing is a question the client has to ask. Hidden here AND
    # absent from the legend, so what is drawn and what is named stay the same set.
    "wayleave_hide_roles": ["splitter", "demand"],

    # ── the aerial sits UNDER the drawing, it is not the drawing ──
    # The reference sheet's basemap is almost greyscale (58% of its pixels have zero
    # saturation) because it is drawn at reduced opacity over the white page. Same effect,
    # set automatically, so the red route and the erf numbers read over any imagery.
    "wayleave_basemap_opacity": 0.35,

    # ── the POP mark ──
    # The reference sheet draws the POP as an orange starburst. Left to the project it is
    # whatever that operator chose (Fouriesburg: a red diamond, Middelburg: a black star),
    # so two wayleaves off the same tool did not match. Forced to the house mark; set to
    # None to keep the project's own symbol instead.
    "wayleave_pop_color":       "245,166,35",
    "wayleave_pop_outline":     "180,90,0",
    "wayleave_pop_size":        4.4,

    # ── street names ──
    # How a municipal reader locates the application on the ground; the reference sheet
    # labels every street. Enabled and sized here rather than left to the project.
    "wayleave_road_labels":      True,
    "wayleave_road_label_size":  7.5,

    # ── data credit ──
    # The street names and the road centrelines come from OpenStreetMap, which is ODbL:
    # it requires visible attribution wherever the data is DISPLAYED, and a wayleave sheet
    # is displayed to a municipality. One line in the description block settles it. Set to
    # "" to drop the line on a project whose roads did not come from OSM.
    # NOTE the size is an INT on purpose: Qt6's QFont.setPointSize() rejects a float
    # outright (TypeError), and _wl_text hands this straight to it.
    "wayleave_attribution":      "Street names and road centrelines © OpenStreetMap contributors (ODbL).",
    "wayleave_attribution_size": 6,

    # ── the legend is data, not code ──
    # Rows in the order they print, as ["Label", "role"]. Edit, reorder, rename or delete
    # rows here or in a client/model preset .json and the block follows — no code change.
    # `role` is what _wl_classify() calls the layer, so the swatch is always rendered from
    # the layer the sheet actually draws: pole · route · erven · pop · splitter · demand ·
    # boundary · obstacle · road. A row whose role has no layer in this project, or whose
    # role is in `wayleave_hide_roles`, drops out on its own.
    # None -> the built-in WL_LEGEND_SPEC (the issued reference sheet's four rows).
    "wayleave_legend_rows": None,

    # ── don't print a sheet with nothing on it ──
    # The grid tiles the AOI's bounding box, so a town that is not a rectangle produces
    # cells holding only veld. Those pages went to the client as blank aerials. True drops
    # any cell containing none of the network layers and renumbers the survivors 1..N, so
    # the numbers on the overview still match the pages that follow it.
    "grid_skip_empty_cells": False,
    # Optional: require a LINE to run this many metres inside a cell before it earns a
    # page, so a corner clip does not. 0 (the default) means any visible feature in the
    # cell counts — what the canvas shows is what gets a page.
    "grid_min_route_m": 0.0,
    # Explicit layer ids the grid may cover. Empty -> whatever is ticked on in the Layers
    # panel. The export dialog fills this so unticking for one drawing never touches the
    # operator's own layer tree.
    "grid_content_layer_ids": [],
    # The exact cells the operator approved in the export dialog, as WKT + their CRS. When
    # set, the grid is built from these verbatim - no re-framing, no re-tiling, no filter.
    # What was on screen is what prints, including in the headless render, which runs in a
    # separate process where a re-derivation could quietly land somewhere else.
    "grid_cells_wkt": [],
    "grid_cells_crs": "",
    # The grid must cover THE THING THE WAYLEAVE IS ASKING FOR — the network. The AOI is
    # the right frame when there is one, but "aoi_layer" is often unset and the fuzzy
    # fallback matches on words like "boundary"/"extent", which on a 65-layer project can
    # latch onto a small polygon that is not the study area at all: Middelburg came out as
    # a ONE-CELL, two-page book covering two PONs of a whole town, and nothing said so.
    # When this is on, an AOI that fails to cover the network is replaced by the network's
    # own extent. An AOI that does cover it is left alone, so projects that frame correctly
    # today keep the same pages.
    # Frame the grid on the VISIBLE layers instead of the AOI polygon. grid_frame_on_network
    # is the original name and still honoured; "network" was always a misnomer for it.
    "grid_frame_on_content": None,
    "grid_frame_on_network": False,
    # How much of the network's extent the AOI must cover to be trusted, 0..1 by area.
    "grid_aoi_min_cover": 0.6,
    "page_label_expr": "",   # e.g. "Page [%@atlas_featurenumber%] of [%@atlas_totalfeatures%]"
    "subtitle":     "",                # e.g. "COMMERCIAL DRAWING" (shown in the commercial sidebar)
    "created_by":   "",                # e.g. "Johan Scholtz"
    # (scale_note defined once, above, in the title-block group)
    # explicit map layer lists (top-first). None -> HLD group/fallback logic.
    "detail_layers":   None,
    "overview_layers": None,
    # operator hand-picked HLD layers (names, top-first). Set -> use exactly these on the
    # map (overview + detail) AND build the legend from their real symbology.
    "hld_layers":         None,
    "legend_from_symbology": False,
    # extra legend rows for fill/outline swatches (commercial zoning legend):
    "legend_fills":   [],              # [(label, "r,g,b" | layer_name)] -> filled colour box
    "legend_outline": [],              # [(label, "r,g,b")] -> outline-only box (e.g. AOI)
    # manual count tables in the sidebar: [{"title","headers":[...],"rows":[[...]]}]
    "count_tables": [],
    # label the coverage cells on the overview (grid numbers) with this field:
    "coverage_label_field": None,
    "logo_zoom": True,                 # Zoom (keep aspect); commercial logo is wider

    # ── per-book namespacing (phase books build EIGHT books into one project) ──
    # Map themes and the generated page-coverage layer are addressed BY NAME, and every
    # build deletes the existing one before creating its own. Building more than one book
    # in a session therefore has book N stealing books 1..N-1's themes and coverage — they
    # still export, they just render the wrong layers. A prefix gives each book its own
    # names. Empty prefix == the historical names, so single-book callers are unchanged.
    "book_prefix": "",
    # Overview-page framing: union these layers' geometries instead of the AOI. None keeps
    # the AOI behaviour. Phase books use it to frame page 1 on ALL phase boundaries at once.
    "overview_geometry_layers": None,
    # The atlas map's per-page theme switch is what keeps the phase boundary polygons off
    # the detail pages. If binding it fails the map silently falls back to its full layer
    # set and the boundaries paint over the network — so a phase book demands it be proven
    # bound, and refuses to build otherwise. Historical callers keep the tolerant path.
    "require_theme_binding": False,
    # Separate from require_theme_binding ON PURPOSE. That flag ALSO makes the overview
    # framing/CRS-overlap check at _build_book_coverage() fatal, which is a phase-book
    # policy — flipping it globally would turn a warning into a refused build for every
    # other caller. This one does the single thing that is universally right: PROVE the
    # per-page theme actually bound. A silent binding failure renders the union of both
    # layer sets, which looks exactly like the feeder-on-the-overview fault this work
    # exists to remove, and every check that reads the theme record still passes.
    "require_theme_bound": True,
    # The default (no operator layer list) overview draws the primary + secondary feeder
    # routes. That is the MOA/wayleave deliverable and stays. It is a flag only so a caller
    # can turn it off without going through the layer list; an operator layer list already
    # suppresses it, because those ticks decide the set on their own.
    "overview_add_feeders": True,
    # Overview page 1 shows the WHOLE area at once, so the erf-number labels that read
    # fine on a detail page collapse into an unreadable mat of digits over the network.
    # True -> the overview map theme renders erven with a labels-off style variant; every
    # detail page keeps the operator's labelling untouched. Wayleave sets this.
    "overview_hide_erven_labels": False,
    # Overview declutter: page 1 shows the whole town, so 1 689 poles + 3 808 demand points
    # at their detail-page marker size merge into a solid white mat and nothing reads. True
    # -> the overview theme renders those markers at `overview_marker_scale` and drops the
    # point/cable labels; the POP and the splitters keep full size (they are the few marks
    # the reader is looking FOR), and every detail page is untouched.
    "overview_declutter": False,
    "overview_marker_scale": 0.6,
}


def _deep_merge(base, over):
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


# caller may inject HLD_CFG in the exec namespace before running this file
CFG = _deep_merge(DEFAULT_CFG, globals().get("HLD_CFG", {}) or {})


def _enum(cls, *names):
    for n in names:
        obj = cls
        try:
            for part in n.split("."):
                obj = getattr(obj, part)
            return obj
        except AttributeError:
            continue
    raise AttributeError(f"none of {names} on {cls}")


MM = _enum(QgsUnitTypes, "LayoutUnit.LayoutMillimeters", "LayoutMillimeters")
LAND = _enum(QgsLayoutItemPage, "Orientation.Landscape", "Landscape")
HTMLMODE = _enum(QgsLayoutItemLabel, "Mode.ModeHtml", "ModeHtml")
ATLAS_AUTO = _enum(QgsLayoutItemMap, "AtlasScalingMode.Auto", "Auto")

p = QgsProject.instance()


# ── CRS-aware length (kills the hardcoded ×111320 deg→m that only held for EPSG:4326) ──
_DA = None


def _dist_area():
    """Cached QgsDistanceArea on the project CRS + ellipsoid → geodesic metres on ANY CRS.
    The old ×111320 constant is only ~correct at the equator on EPSG:4326; at Mohadin's
    latitude it overstates E-W distance ~12% and is pure garbage on a projected CRS."""
    global _DA
    if _DA is None:
        from qgis.core import QgsDistanceArea
        da = QgsDistanceArea()
        da.setSourceCrs(p.crs(), p.transformContext())
        try:
            da.setEllipsoid(_safe_ellipsoid(p, p.crs()))
        except Exception:
            da.setEllipsoid("WGS84")
        _DA = da
    return _DA


def _len_m(geom):
    """Geodesic length (metres) of a geometry in the project CRS. 0.0 for null/empty/error."""
    import math
    if geom is None or geom.isEmpty():
        return 0.0
    try:
        v = _dist_area().measureLength(geom)
        return v if (v is not None and math.isfinite(v) and v >= 0) else 0.0
    except Exception:
        return 0.0


def _lyr(name):
    for l in p.mapLayers().values():
        if l.name() == name:
            return l
    return None


def _is_v1(name):
    """True for a canonical '… v1' layer name."""
    import re
    return bool(re.search(r"\bv1\b", name.lower())) or name.lower().rstrip().endswith("v1")


def _canonical_names(names):
    """If any candidate is a '… v1' layer, keep ONLY the v1 candidates — drop the bare
    Phase-1 decoys (e.g. 'Drop Cable' 22140 alongside 'Drop Cable v1' 6335) that otherwise
    get picked first (wrong colour/label) or SUMMED (≈4.5× inflated counts). Mirrors the
    shipped boq.select_canonical. No-op when a role lists no v1 candidate."""
    names = list(names or [])
    v1 = [n for n in names if _is_v1(n)]
    return v1 if v1 else names


# ── schema-agnostic fallback ────────────────────────────────────────────────────────
# When a project doesn't use the exact Fibertime names (PON v1, poles v1, …), find each
# role by GEOMETRY + name keywords instead, so the tool works on ANY project's schema.
_FUZZY_ROLES = {
    "fts":          ("point",   ["fts", "agg"],                                 ["sts"]),
    "sts":          ("point",   ["sts", "splitter"],                            ["fts"]),
    "poles":        ("point",   ["pole"],                                       []),
    "enclosure":    ("point",   ["enclosure", "closure", "joint", "manhole",
                                 "chamber", "handhole"],                        []),
    "enc_splice":   ("point",   ["splice"],                                     []),
    "enc_conn":     ("point",   ["connectoris", "connectoriz"],                 []),
    "ont":          ("point",   ["ont", "home connection", "premise",
                                 "drop point", "customer"],                     []),
    "primary":      ("line",    ["primary", "feeder"],                          ["secondary", "distribution"]),
    "secondary":    ("line",    ["secondary"],                                  ["primary"]),
    "distribution": ("line",    ["distribution", "mini"],                       ["spare"]),
    "drop":         ("line",    ["drop"],                                       ["spare", "distribution"]),
    "spare_drop":   ("line",    ["spare drop", "spare"],                        []),
    "coverage":     ("polygon", ["pon"],                                        ["zone"]),
    "pon_area":     ("polygon", ["pon"],                                        ["zone"]),
    "zones":        ("polygon", ["zone"],                                       []),
}


def _fuzzy_layer(geom, include, exclude=()):
    """First vector layer whose geometry is `geom` and whose name contains an `include`
    keyword and no `exclude` keyword. Prefers a non-empty layer."""
    from qgis.core import QgsVectorLayer
    inc = [s.lower() for s in include]
    exc = [s.lower() for s in exclude]
    fallback = None
    for l in p.mapLayers().values():
        if not isinstance(l, QgsVectorLayer):
            continue
        if geom and _geom_of(l) != geom:
            continue
        nm = l.name().lower()
        if any(x in nm for x in exc) or not any(x in nm for x in inc):
            continue
        try:
            if l.featureCount() > 0:
                return l
        except Exception:
            return l
        fallback = fallback or l
    return fallback


def _aoi_layer():
    """The area-of-interest polygon (greenfield boundary), by name then fuzzy."""
    l = _lyr(CFG["aoi_layer"])
    if l is not None:
        return l
    return _fuzzy_layer("polygon",
                        ["greenfield", "overbuild", "boundary", "aoi", "area of interest", "extent"],
                        ["pon", "zone", "erven", "erf", "building", "grid"])


def _basemap_layer():
    """The basemap raster, by name then any raster in the project."""
    l = _lyr(CFG["basemap"])
    if l is not None:
        return l
    from qgis.core import QgsRasterLayer
    for x in p.mapLayers().values():
        if isinstance(x, QgsRasterLayer):
            return x
    return None


# ---- group resolution (resolve layers within the configured group, not by hard-coded names) ----
def _p2_group():
    root = p.layerTreeRoot()
    want = CFG["group_name"].strip().lower()
    try:
        groups = root.findGroups(True)          # recursive (group may be nested)
    except TypeError:
        groups = []
        def _walk(node):
            for ch in node.children():
                if hasattr(ch, "children") and not hasattr(ch, "layer"):
                    groups.append(ch); _walk(ch)
        _walk(root)
    for g in groups:
        if g.name().strip().lower() == want:
            return g
    return None


def _p2_layer(*names):
    g = _p2_group()
    if g:
        for ch in g.findLayers():
            l = ch.layer()
            if l and l.name() in names:
                return l
    for n in names:
        x = _lyr(n)
        if x:
            return x
    return None


def _best_polygon_coverage():
    """Last-resort per-page coverage when the configured + fuzzy resolution both fail: the
    best polygon layer in the project. Prefers a 'pon' polygon, then a 'zone' polygon (a zone
    layer IS a valid per-page unit — e.g. the Matiko sandbox has ONLY zones), then any
    non-empty polygon. Never a raster/point/line. Stops the atlas crashing on a project whose
    coverage layer the fuzzy rules don't anticipate (they exclude 'zone' to avoid picking a
    zone OVER a pon when both exist — but when only zones exist, a zone is the right pick)."""
    from qgis.core import QgsVectorLayer
    polys = [l for l in p.mapLayers().values()
             if isinstance(l, QgsVectorLayer) and _geom_of(l) == "polygon"]

    def nonempty(l):
        try:
            return l.featureCount() > 0
        except Exception:
            return True
    for want in ("pon", "zone"):
        for l in polys:
            if want in l.name().lower() and nonempty(l):
                return l
    for l in polys:
        if nonempty(l):
            return l
    return None


def _role(role):
    """Resolve a role: exact configured names first (fast path, unchanged for Fibertime),
    then a schema-agnostic fuzzy match by geometry + name so it works on ANY project."""
    names = _canonical_names(CFG["roles"].get(role, []))
    l = _p2_layer(*names) if names else None
    if l is not None:
        return l
    spec = _FUZZY_ROLES.get(role)
    l = _fuzzy_layer(*spec) if spec else None
    if l is not None:
        return l
    # last resort for the per-page coverage: any polygon, so the book still builds (never
    # crash on a None coverage). Only fires when nothing else matched -> MOA/Fibertime unchanged.
    if role in ("coverage", "pon_area"):
        return _best_polygon_coverage()
    return None


def _p2_visible_layers(exclude=()):
    from qgis.core import QgsVectorLayer
    g = _p2_group()
    out = []
    if g:
        for ch in g.findLayers():
            l = ch.layer()
            if l and ch.isVisible() and l.name() not in exclude:
                out.append(l)
        if out:
            return out
    # no HLD group (or empty) -> every VISIBLE vector layer in the tree (schema-agnostic)
    for ch in p.layerTreeRoot().findLayers():
        l = ch.layer()
        if isinstance(l, QgsVectorLayer) and ch.isVisible() and l.name() not in exclude:
            out.append(l)
    return out


def _p2_enclosure():
    g = _p2_group()
    if g:
        for ch in g.findLayers():
            l = ch.layer()
            if not l:
                continue
            try:
                if any("Enclosure" in (c.label() or "") for c in l.renderer().categories()):
                    return l
            except Exception:
                pass
    return _role("enclosure")


def find_north_svg():
    from qgis.core import QgsApplication
    for base in QgsApplication.svgPaths():
        for cand in ("arrows/NorthArrow_02.svg", "arrows/NorthArrow_01.svg",
                     "arrows/NorthArrow_04.svg", "arrows/NorthArrow_11.svg"):
            fp = os.path.normpath(os.path.join(base, cand))
            if os.path.exists(fp):
                return fp
    return None


NORTH_SVG = find_north_svg()
LOGO = CFG["logo_path"]


def mmpoint(x, y): return QgsLayoutPoint(x, y, MM)
def mmsize(w, h): return QgsLayoutSize(w, h, MM)


def add_label(layout, x, y, w, h, html=None, text=None, size=9, bold=False,
              align_center=True, valign_center=True, frame=False):
    lbl = QgsLayoutItemLabel(layout)
    if html is not None:
        lbl.setMode(HTMLMODE)
        lbl.setText(html)
    else:
        lbl.setText(text or "")
        f = QFont(); f.setPointSize(size); f.setBold(bold)
        lbl.setFont(f)
    from qgis.PyQt.QtCore import Qt
    hz = _enum(Qt, "AlignmentFlag.AlignHCenter", "AlignHCenter") if align_center else _enum(Qt, "AlignmentFlag.AlignLeft", "AlignLeft")
    vt = _enum(Qt, "AlignmentFlag.AlignVCenter", "AlignVCenter") if valign_center else _enum(Qt, "AlignmentFlag.AlignTop", "AlignTop")
    try: lbl.setHAlign(hz); lbl.setVAlign(vt)
    except Exception: pass
    layout.addLayoutItem(lbl)
    lbl.attemptMove(mmpoint(x, y)); lbl.attemptResize(mmsize(w, h))
    if frame:
        lbl.setFrameEnabled(True); lbl.setFrameStrokeColor(QColor(0, 0, 0))
        lbl.setFrameStrokeWidth(QgsLayoutMeasurement(0.4, MM))
    return lbl


def add_rect(layout, x, y, w, h, stroke_w=0.6):
    RECT = _enum(QgsLayoutItemShape, "Shape.Rectangle", "Rectangle")
    sh = QgsLayoutItemShape(layout)
    try: sh.setShapeType(RECT)
    except Exception: pass
    layout.addLayoutItem(sh)
    sh.attemptMove(mmpoint(x, y)); sh.attemptResize(mmsize(w, h))
    sym = sh.symbol()
    if sym is not None:
        sym.setColor(QColor(255, 255, 255, 0))
        try:
            sl = sym.symbolLayer(0)
            sl.setStrokeColor(QColor(90, 90, 90)); sl.setStrokeWidth(stroke_w)
            sl.setFillColor(QColor(255, 255, 255, 0))
        except Exception: pass
    return sh


def _any_symbol(rndr):
    """A representative QgsSymbol from ANY renderer — single-symbol, categorized,
    rule-based or graduated. `.symbol()` only exists on single-symbol renderers, so
    fall back to `.symbols(context)[0]` which every renderer implements. This is what
    makes the LEGEND colours match the MAP on projects that use categorized styling
    (e.g. Matiko's cables) instead of falling back to a hard-coded default."""
    if rndr is None:
        return None
    try:
        if hasattr(rndr, "symbol") and rndr.symbol() is not None:
            return rndr.symbol()
    except Exception:
        pass
    try:
        from qgis.core import QgsRenderContext
        ss = rndr.symbols(QgsRenderContext())
        return ss[0] if ss else None
    except Exception:
        return None


def _sym_color_name(sym):
    try:
        return sym.color().name() if sym is not None else None
    except Exception:
        return None


def _lyr_color(name, default):
    l = _lyr(name)
    if not l:
        return default
    return _sym_color_name(_any_symbol(l.renderer())) or default


def _role_color(role, default):
    """Colour of the SAME layer the map draws for this role (group-first resolution).
    Using _role() — not a raw whole-project name scan — avoids grabbing a Phase-1
    'Drop Cable' when the map draws the Phase-2 'Drop Cable v1' (legend/map mismatch).
    Works for categorized/rule-based renderers via _any_symbol()."""
    l = _role(role)
    if l is not None:
        c = _sym_color_name(_any_symbol(l.renderer()))
        if c:
            return c
    # last-ditch: any resolvable candidate by name
    for name in CFG["roles"].get(role, []):
        c = _lyr_color(name, None)
        if c:
            return c
    return default


def _render_legend_symbols():
    """Render each point role's ACTUAL symbol to a small PNG so the legend shows the real physical symbols."""
    from qgis.core import QgsSymbolLayerUtils
    from qgis.PyQt.QtCore import QSize
    d = _legend_dir()
    os.makedirs(d, exist_ok=True)
    out = {}

    def render(sym, name, w=200, h=200, mm=44):
        # render the REAL symbol big + anti-aliased so it FILLS the box (bold, not a tiny
        # marker floating in white). 200px source at ~44mm marker = crisp and prominent.
        if sym is None:
            return
        try:
            s2 = sym.clone()
            try:
                if hasattr(s2, "setSize"):
                    s2.setSize(mm)
            except Exception:
                pass
            pm = QgsSymbolLayerUtils.symbolPreviewPixmap(s2, QSize(w, h))
            path = f"{d}/{name}.png"
            pm.save(path)
            out[name] = path
        except Exception as e:
            print("legend sym err", name, e)

    def rsym(role):
        l = _role(role)
        if not l:
            return None
        r = l.renderer()
        try:
            if hasattr(r, "symbol"):
                s = r.symbol()
                if s is not None:
                    return s
        except Exception:
            pass
        try:
            from qgis.core import QgsRenderContext
            ss = r.symbols(QgsRenderContext())
            return ss[0] if ss else None
        except Exception:
            return None

    def enc(contains):
        l = _p2_enclosure()
        if not l:
            return None
        r = l.renderer()
        if not hasattr(r, "categories"):
            return r.symbol() if hasattr(r, "symbol") else None
        for c in r.categories():
            if contains.lower() in str(c.value()).lower():
                return c.symbol()
        return None

    # points only (rendered big + crisp); lines are drawn as coloured bars in the HTML
    for _label, key in CFG["legend_points"]:
        if key == "enc_splice":
            render(rsym("enc_splice") or enc("splice"), "enc_splice")
        elif key == "enc_conn":
            render(rsym("enc_conn") or enc("connect"), "enc_conn")
        else:
            render(rsym(key), key)
    return out


def _fill_or_color(spec):
    """Resolve a legend fill spec: a layer name (read its fill colour), "r,g,b", or "#hex"."""
    l = _lyr(spec)
    if l is not None:
        # _any_symbol, not .symbol(): the latter exists ONLY on single-symbol renderers,
        # so a categorized layer (HeroTel/Vuma) raised, the except swallowed it, and the
        # legend silently fell back to the spec/default instead of the real map colour.
        try:
            c = _sym_color_name(_any_symbol(l.renderer()))
            if c:
                return c
        except Exception:
            pass
    if "," in str(spec):
        try:
            r, g, b = [int(x) for x in str(spec).split(",")[:3]]
            return f"#{r:02x}{g:02x}{b:02x}"
        except Exception:
            pass
    return spec


def _resolve_layer_list(names):
    """Resolve an explicit layer-name list to layers (group-first, then whole project),
    de-duplicated, preserving order. Used by the commercial model's detail/overview sets."""
    out = []
    seen = set()
    g = _p2_group()
    for n in names:
        l = None
        if g:
            for ch in g.findLayers():
                if ch.layer() and ch.layer().name() == n:
                    l = ch.layer(); break
        if l is None:
            l = _lyr(n)
        if l and l.id() not in seen:
            seen.add(l.id()); out.append(l)
    return out


def _geom_of(layer):
    """point / line / polygon / other for any vector layer (Qt5/6-safe)."""
    from qgis.core import QgsWkbTypes
    try:
        return {0: "point", 1: "line", 2: "polygon"}.get(
            int(QgsWkbTypes.geometryType(layer.wkbType())), "other")
    except Exception:
        return "other"


def _safe_key(s):
    return "".join(ch if ch.isalnum() else "_" for ch in str(s))


def _layer_color(layer, default="#000000"):
    try:
        r = layer.renderer()
        if hasattr(r, "symbol") and r.symbol():
            return r.symbol().color().name()
        from qgis.core import QgsRenderContext
        ss = r.symbols(QgsRenderContext())
        return ss[0].color().name() if ss else default
    except Exception:
        return default


def _poly_swatch(layer):
    """(colour, outline_only) for a polygon legend swatch: use the outline colour when the
    fill is transparent (e.g. a boundary drawn as green outline, not a black box)."""
    try:
        # ANY renderer — a categorized polygon layer has no .symbol() and used to fall
        # straight into the except, so its legend swatch never reflected the map.
        sym = _any_symbol(layer.renderer())
        if sym is None:
            return "#888888", False       # same grey the except-path returns
        fill = sym.color()
        if fill.alpha() < 30:                     # transparent fill -> outline layer
            sl = sym.symbolLayer(0)
            oc = sl.strokeColor() if hasattr(sl, "strokeColor") else fill
            if oc is not None and oc.alpha() > 0:
                return oc.name(), True
        return fill.name(), False
    except Exception:
        return "#888888", False


def _legend_dir():
    """The legend scratch directory, guaranteed to exist and be writable.

    Falls back to the OS temp directory if the configured one cannot be created — a
    wayleave whose legend swatches cannot be written is a wayleave with half a legend,
    and that is not something to discover on a client's desk.
    """
    import tempfile
    d = CFG.get("legend_dir") or _default_legend_dir()
    for cand in (d, os.path.join(tempfile.gettempdir(), "vf_hld_legend")):
        try:
            os.makedirs(cand, exist_ok=True)
            probe = os.path.join(cand, ".w")
            with open(probe, "w") as fh:
                fh.write("1")
            os.remove(probe)
            if cand != d:
                print("legend_dir %r not writable - using %r" % (d, cand))
            return cand
        except Exception:
            continue
    print("legend_dir: no writable location found - legend swatches will be skipped")
    return d


def _crop_to_ink(path, pad=2):
    """Trim the fully transparent margin off a rendered swatch PNG, in place."""
    from qgis.PyQt.QtGui import QImage
    try:
        img = QImage(path)
        if img.isNull():
            return path
        img = img.convertToFormat(QImage.Format.Format_ARGB32)
        w, h = img.width(), img.height()
        x0, y0, x1, y1 = w, h, -1, -1
        for y in range(h):
            for x in range(w):
                if (img.pixel(x, y) >> 24) & 0xFF:
                    if x < x0: x0 = x
                    if x > x1: x1 = x
                    if y < y0: y0 = y
                    if y > y1: y1 = y
        if x1 < x0 or y1 < y0:
            return path                       # fully transparent — nothing to crop
        x0 = max(0, x0 - pad); y0 = max(0, y0 - pad)
        x1 = min(w - 1, x1 + pad); y1 = min(h - 1, y1 + pad)
        img.copy(x0, y0, x1 - x0 + 1, y1 - y0 + 1).save(path)
    except Exception as e:
        print("crop swatch err", path, e)
    return path


def _render_layer_symbol(layer, key):
    """Render a layer's REAL marker symbol to a small PNG for the legend."""
    from qgis.core import QgsSymbolLayerUtils, QgsRenderContext
    from qgis.PyQt.QtCore import QSize
    d = _legend_dir()
    try:
        r = layer.renderer()
        sym = r.symbol() if (hasattr(r, "symbol") and r.symbol()) else None
        if sym is None:
            ss = r.symbols(QgsRenderContext()); sym = ss[0] if ss else None
        if sym is None:
            return None
        s2 = sym.clone()
        try:
            if hasattr(s2, "setSize"):
                # Blow the marker up so it fills the swatch — but scale its OUTLINE by the
                # same factor. setSize() leaves stroke width alone, so a pole drawn at
                # 1.4 mm with a 0.3 mm ring became a 44 mm disc with a 0.3 mm hairline:
                # a white circle with an invisible edge on white paper, which is exactly
                # what "I can't make out what it is" looks like. The cap keeps a very
                # heavy ring from closing up the middle of a small marker.
                old_size = float(s2.size() or 0)
                k = (44.0 / old_size) if old_size > 0 else 1.0
                s2.setSize(44)
                for _i in range(s2.symbolLayerCount()):
                    _sl = s2.symbolLayer(_i)
                    if hasattr(_sl, "strokeWidth") and hasattr(_sl, "setStrokeWidth"):
                        try:
                            _w = float(_sl.strokeWidth() or 0)
                            if _w > 0:
                                _sl.setStrokeWidth(min(_w * k, 44.0 * 0.16))
                        except Exception:
                            pass
        except Exception:
            pass
        pm = QgsSymbolLayerUtils.symbolPreviewPixmap(s2, QSize(240, 240))
        pth = f"{d}/auto_{key}.png"; pm.save(pth)
        return _crop_to_ink(pth)
    except Exception as e:
        print("auto legend sym err", key, e)
        return None


def _friendly_name(layer):
    alias = CFG.get("legend_aliases", {}).get(layer.name())
    if alias:
        return alias
    n = layer.name()
    return n[:-3].strip() if n.lower().endswith(" v1") else n


def _rect_png(key, fill=None, w=44, h=14, outline=None, outline_w=1.4):
    """Render a coloured rectangle (line bar / fill swatch / outline swatch) to a PNG so it
    aligns exactly like the point-symbol images (nested HTML tables don't align)."""
    from qgis.PyQt.QtGui import QImage, QPainter, QColor, QPen, QBrush
    d = _legend_dir()
    S = 6
    img = QImage(int(w * S), int(h * S), QImage.Format.Format_ARGB32)
    img.fill(0)
    pa = QPainter(img)
    try:
        pa.setRenderHint(_enum(QPainter, "RenderHint.Antialiasing", "Antialiasing"), True)
    except Exception:
        pass
    pa.setBrush(QBrush(QColor(fill) if fill is not None else QColor(0, 0, 0, 0)))
    pa.setPen(QPen(QColor(outline), outline_w * S) if outline else QPen(QColor("#444444"), 0.7 * S))
    m = (outline_w * S) if outline else (0.7 * S)
    pa.drawRect(int(m), int(m), int(w * S - 2 * m), int(h * S - 2 * m))
    pa.end()
    path = os.path.join(d, f"rect_{key}.png"); img.save(path)
    return path


def _drawn_role_filter(drawn):
    """Predicate(role) -> is that role's layer actually drawn in this book?

    `drawn` is the union of the overview and detail layer sets. Returns None (meaning "do not
    filter") when there is nothing to filter against, or when the caller supplied its own
    overview list — phase/grid/commercial books legitimately draw different things on page 1
    and the detail pages, so filtering their single sidebar against the union would put a
    symbol on page 1 for something page 1 never draws. Those keep the pre-2026-09 behaviour."""
    if not drawn or CFG.get("overview_layers"):
        return None
    ids = {l.id() for l in drawn if l is not None}

    def keeps(role):
        for lyr in _role_layers(role):
            if lyr is not None and lyr.id() in ids:
                return True
        return False
    return keeps


def _legend_rows(map_layers=None, drawn=None):
    """The ordered [(label, swatch_html)] rows: configured rows first (nice names/order),
    then any drawn layer not yet shown (guard rail), then the basemap note.

    When `drawn` is given, a configured row whose role resolves to no layer in the book is
    dropped — otherwise a trenching-only drawing prints HeroTel's full curated legend
    (splitters, domes, feeder …) for layers that are nowhere on the page."""
    syms = _render_legend_symbols()

    def img(name, w=22, h=22):
        pth = syms.get(name)
        return f"<img src='file:///{pth}' width='{w}' height='{h}'>" if pth else ""

    def bar(key, color):
        p = _rect_png("bar_" + _safe_key(key), color, w=44, h=12)
        return f"<img src='file:///{p}' width='44' height='12'>"

    def swatch(key, color, outline_only=False):
        if outline_only:
            p = _rect_png("sw_" + _safe_key(key), None, w=26, h=15, outline=color, outline_w=1.8)
        else:
            p = _rect_png("sw_" + _safe_key(key), color, w=26, h=15, outline="#444444", outline_w=0.7)
        return f"<img src='file:///{p}' width='26' height='15'>"

    keeps = _drawn_role_filter(drawn)
    rows = [(lab, img(key)) for lab, key in CFG["legend_points"]
            if keeps is None or keeps(key)]
    for lab, color in CFG.get("legend_outline", []):
        rows.append((lab, swatch(lab, _fill_or_color(color), outline_only=True)))
    for lab, spec in CFG.get("legend_fills", []):
        rows.append((lab, swatch(lab, _fill_or_color(spec))))
    for lab, role, default in CFG["legend_lines"]:
        if keeps is None or keeps(role):
            rows.append((lab, bar(lab, _role_color(role, default))))
    # NOTE: no fallback here. Filtering every curated row away is the CORRECT result for a
    # book that draws none of them (a trenching-only drawing draws no splitter, dome or
    # feeder) — the legend_auto guard rail below then fills the legend from what IS drawn.
    # An earlier version restored the full curated set at this point and silently undid the
    # whole filter; the only real empty-legend risk is handled after the guard rail runs.

    # --- GUARD RAIL: append any DRAWN layer not already represented above ---
    if CFG.get("legend_auto") and map_layers:
        covered = set()
        for role in ("fts", "sts", "enc_splice", "enc_conn", "poles", "enclosure",
                     "primary", "secondary", "distribution", "drop"):
            rl = _role(role)
            if rl is not None:
                covered.add(rl.id())
        bm = _basemap_layer()
        bm_id = bm.id() if bm else None
        for l in map_layers:
            if l is None or l.id() == bm_id or l.id() in covered:
                continue
            covered.add(l.id())
            g = _geom_of(l)
            nm = _friendly_name(l)
            if g == "point":
                pth = _render_layer_symbol(l, _safe_key(l.name()))
                cell = f"<img src='file:///{pth}' width='22' height='22'>" if pth else ""
            elif g == "line":
                cell = bar(nm, _layer_color(l))
            elif g == "polygon":
                col, outline = _poly_swatch(l)
                cell = swatch(nm, col, outline_only=outline)
            else:
                cell = ""
            rows.append((nm, cell))
        note = CFG.get("legend_basemap_note")
        if note and bm_id is not None and any(x is not None and x.id() == bm_id for x in map_layers):
            rows.append((note, ""))
    if keeps is not None and not rows:
        # Filtered to nothing AND the guard rail added nothing: the roles did not resolve
        # rather than the page being empty. An empty legend box helps nobody, so print the
        # unfiltered set. This is the only place the fallback is safe.
        return _legend_rows(map_layers, drawn=None)
    return rows


def _legend_table(rows, compact=False):
    # QTextDocument ignores <td height>, so force EVEN rows with a fixed-height transparent
    # spacer in every cell — point symbols, bars and swatches then all line up.
    # compact = tighter rows/font so a many-layer legend fits the small wayleave strip.
    from qgis.PyQt.QtGui import QImage
    d = _legend_dir()
    sp_h = 15 if compact else 28
    font_px = 8 if compact else 9
    hdr_px = 9 if compact else 11
    pad = 2 if compact else 8
    spacer = ""
    try:
        sp = os.path.join(d, f"spacer{sp_h}.png")
        _im = QImage(1, sp_h, QImage.Format.Format_ARGB32); _im.fill(0)   # transparent
        _im.save(sp)
        spacer = f"<img src='file:///{sp}' width='1' height='{sp_h}'>"
    except Exception:
        pass
    trs = "".join(
        f"<tr><td valign='middle'>{spacer}{k}</td>"
        f"<td width='66' align='center' valign='middle'>{spacer}{v}</td></tr>"
        for k, v in rows)
    return (f"<table cellpadding='0' cellspacing='0' width='100%' "
            f"style='font-family:Arial;font-size:{font_px}px;color:#000000'>"
            f"<tr><td colspan='2' align='center' style='font-weight:bold;font-size:{hdr_px}px;"
            f"text-decoration:underline;padding-bottom:{pad}px'>LEGEND</td></tr>{trs}</table>")


def _symbology_legend_rows(layers):
    """Legend rows built PURELY from each drawn layer's REAL QGIS symbology — points render
    the actual marker image, lines a bar of the real colour, polygons a fill/outline swatch.
    Used when the operator hand-picks the HLD layers ('pull the legend from the project')."""
    def bar(key, color):
        pth = _rect_png("bar_" + _safe_key(key), color, w=44, h=12)
        return f"<img src='file:///{pth}' width='44' height='12'>"

    def swatch(key, color, outline_only=False):
        if outline_only:
            pth = _rect_png("sw_" + _safe_key(key), None, w=26, h=15, outline=color, outline_w=1.8)
        else:
            pth = _rect_png("sw_" + _safe_key(key), color, w=26, h=15, outline="#444444", outline_w=0.7)
        return f"<img src='file:///{pth}' width='26' height='15'>"

    rows = []
    bm = _basemap_layer(); bm_id = bm.id() if bm else None
    seen = set()
    for l in (layers or []):
        if l is None or l.id() in seen or (bm_id and l.id() == bm_id):
            continue
        seen.add(l.id())
        g = _geom_of(l); nm = _friendly_name(l)
        if g == "point":
            pth = _render_layer_symbol(l, _safe_key(l.name()))
            cell = f"<img src='file:///{pth}' width='22' height='22'>" if pth else ""
        elif g == "line":
            cell = bar(nm, _layer_color(l))
        elif g == "polygon":
            col, outline = _poly_swatch(l); cell = swatch(nm, col, outline_only=outline)
        else:
            cell = ""
        rows.append((nm, cell))
    note = CFG.get("legend_basemap_note")
    if note and bm_id is not None and any(x is not None and x.id() == bm_id for x in (layers or [])):
        rows.append((note, ""))
    return rows


def build_legend_html(map_layers=None, compact=False):
    if CFG.get("legend_from_symbology"):
        # show EXACTLY the operator-picked layers (not the auto-added grid/AOI/basemap),
        # so the legend is identical on the overview and every detail page.
        layers = _resolve_layer_list(CFG["hld_layers"]) if CFG.get("hld_layers") else map_layers
        return _legend_table(_symbology_legend_rows(layers), compact=compact)
    return _legend_table(_legend_rows(map_layers), compact=compact)


def map_info_html():
    """Scale + projection block for the sidebar (matches the reference)."""
    rows = [("Scale", CFG.get("scale_note", "As-Shown (A3)")),
            ("Projection", CFG.get("projection_note", "EPSG:4326 · WGS 84"))]
    trs = "".join(f"<tr><td style='font-weight:bold' width='42%'>{k}:</td><td>{v}</td></tr>"
                  for k, v in rows)
    return (f"<table cellpadding='3' cellspacing='0' width='100%' "
            f"style='font-family:Arial;font-size:10px;color:#000000'>{trs}</table>")


def _summary_rows(drawn=None):
    """PROJECT TOTALS rows. With `drawn` supplied, a role whose layer is not in the book is
    skipped — a trenching-only drawing was otherwise printing 798 poles and 414 splitters
    that appear nowhere on it. `drawn=None` keeps the pre-2026-09 whole-project counts."""
    keeps = _drawn_role_filter(drawn)
    rows = []
    _counted = set()
    for lab, role in CFG.get("summary_roles", []):
        if keeps is not None and not keeps(role):
            continue
        layers = _role_layers(role)     # canonical (v1) layers, summed → no undercount
        if not layers:
            continue
        try:
            total = sum(l.featureCount() for l in layers)
        except Exception:
            continue
        rows.append((lab, f"{total:,}"))
        for lyr in layers:
            if lyr is not None:
                _counted.add(lyr.id())
    # GUARD RAIL (mirrors legend_auto): the configured summary_roles are a fixed client list,
    # so a ticked layer with no role of its own — POP, Trenching, PON Progress — would be on
    # the page and missing from PROJECT TOTALS. Append a count for every drawn layer not
    # already represented, so the table says what the drawing actually contains.
    if keeps is not None:
        bm = _basemap_layer()
        bm_id = bm.id() if bm is not None else None
        for l in drawn:
            if l is None or l.id() in _counted or l.id() == bm_id:
                continue
            _counted.add(l.id())
            try:
                n = l.featureCount()          # rasters have none -> skipped by the except
            except Exception:
                continue
            if n is None or n < 0:
                continue
            rows.append((_friendly_name(l), f"{n:,}"))
    return rows


def summary_html(drawn=None):
    """Project feature-count summary (fills the empty sidebar band with real detail)."""
    rows = _summary_rows(drawn)
    if not rows:
        return ""
    body = "".join(f"<tr><td>{k}</td><td align='right' style='font-weight:bold'>{v}</td></tr>"
                   for k, v in rows)
    return (f"<table cellpadding='3' cellspacing='0' border='1' width='100%' "
            f"style='font-family:Arial;font-size:9px;color:#000000'>"
            f"<tr><td colspan='2' align='center' style='font-weight:bold;font-size:10px;"
            f"text-decoration:underline'>{CFG.get('summary_title', 'PROJECT TOTALS')}</td></tr>{body}</table>")


def _zone_summary_label(layout, w):
    """Atlas-driven per-page stats box: a REAL QgsLayoutItemLabel (not a baked image),
    so [% attribute(@atlas_feature,'stat_*') %] re-evaluates for each atlas page — the
    overview shows PROJECT TOTALS, every detail page shows that zone's own numbers."""
    from qgis.core import QgsLayoutItemLabel
    lbl = QgsLayoutItemLabel(layout)
    lbl.setMode(_enum(QgsLayoutItemLabel, "Mode.ModeHtml", "ModeHtml"))
    a = "attribute(@atlas_feature,"
    row = "<tr><td>%s</td><td align='right' style='font-weight:bold'>[%% %s%s) %%]</td></tr>"
    body = "".join(row % (lab, a, fld) for lab, fld in (
        ("Homes / Units", "'stat_units'"), ("Splitters", "'stat_spl'"),
        ("Drop cables", "'stat_drops'"), ("Poles", "'stat_poles'"),
        ("Distribution (m)", "'stat_distm'")))
    lbl.setText(
        "<div style='font-family:Arial;color:#000;font-size:9px'>"
        "<div style='text-align:center;font-weight:bold;font-size:11px;"
        "text-decoration:underline'>[% " + a + "'stat_name') %]</div>"
        "<table width='100%' cellspacing='0' cellpadding='3' border='1' "
        "style='border-collapse:collapse;font-size:9px'>" + body + "</table></div>")
    layout.addLayoutItem(lbl)
    lbl.attemptResize(mmsize(w, 42.0))
    return lbl, 42.0


def count_tables_html():
    """Manual count tables (commercial model) → stacked HTML tables for the sidebar."""
    tables = CFG.get("count_tables") or []
    out = []
    for t in tables:
        headers = t.get("headers", [])
        span = max(1, len(headers))
        hdr = "".join(f"<td style='font-weight:bold'>{h}</td>" for h in headers)
        body = ""
        for row in t.get("rows", []):
            body += "<tr>" + "".join(f"<td>{c}</td>" for c in row) + "</tr>"
        out.append(
            f"<table cellpadding='2' cellspacing='0' border='1' width='100%' "
            f"style='font-family:Arial;font-size:7px'>"
            f"<tr><td colspan='{span}' align='center' style='font-weight:bold;"
            f"text-decoration:underline'>{t.get('title', '')}</td></tr>"
            f"<tr>{hdr}</tr>{body}</table>")
    return "<br>".join(out)


def titleblock_html():
    base = [("Project", CFG["project_name"]), ("Company", CFG["company"]),
            ("Designer", CFG["designer"]), ("Date", CFG["date_str"]), ("Revision", CFG["revision"])]

    def tbl(rows, fs=12):
        trs = "".join(f"<tr><td style='font-weight:bold' width='42%'>{k}:</td>"
                      f"<td align='center'>{v}</td></tr>" for k, v in rows)
        return (f"<table cellpadding='4' cellspacing='0' border='1' width='100%' "
                f"style='font-family:Arial;font-size:{fs}px'>{trs}</table>")

    if not CFG.get("iso_title_block"):
        return tbl(base)                                   # simple block — MOA unchanged
    # ISO 7200-style: identity (+ Scale/Datum/Sheet) + revision history + sign-off.
    # Sheet is a per-page atlas expression (add_label evaluates [% ... %] in HTML mode).
    ident = base + [("Scale", CFG.get("scale_note", "As-Shown (A3)")),
                    ("Datum / CRS", CFG.get("projection_note", "EPSG:4326 · WGS 84")),
                    ("Sheet", "[% @atlas_featurenumber %] of [% @atlas_totalfeatures %]")]
    out = tbl(ident, fs=10)
    rev = CFG.get("revision_rows") or []
    if rev:
        head = ("<tr><td style='font-weight:bold'>Rev</td><td style='font-weight:bold'>Date</td>"
                "<td style='font-weight:bold'>Description</td><td style='font-weight:bold'>By</td></tr>")
        body = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in (list(r) + ['', '', '', ''])[:4])
                       + "</tr>" for r in rev[:5])
        out += ("<table cellpadding='2' cellspacing='0' border='1' width='100%' "
                "style='font-family:Arial;font-size:8px;margin-top:2px'>"
                "<tr><td colspan='4' align='center' style='font-weight:bold'>REVISION HISTORY</td></tr>"
                + head + body + "</table>")
    signoff = "".join(f"<tr><td style='font-weight:bold' width='34%'>{r}:</td><td>&nbsp;</td></tr>"
                      for r in (CFG.get("signoff") or ["Designed", "Reviewed", "Approved"]))
    out += ("<table cellpadding='3' cellspacing='0' border='1' width='100%' "
            "style='font-family:Arial;font-size:9px;margin-top:2px'>" + signoff + "</table>")
    return out


def build_frame_commercial(layout, title_text, map_layers=None):
    """Commercial-drawing frame: full-height map (no title bar) + a stacked sidebar
    (project / COMMERCIAL DRAWING / page / created-by · LEGEND · count tables · scale · logo)."""
    MAP = dict(x=6, y=6, w=322, h=285)      # full-height map, no title bar over it
    SB_X, SB_W = 334, 80
    add_rect(layout, 3, 3, 414, 291, stroke_w=1.0)                 # outer border
    add_rect(layout, MAP["x"], MAP["y"], MAP["w"], MAP["h"], stroke_w=0.6)  # map border
    # ── title block (stacked, centred) ──
    head = ("<div style='font-family:Arial;text-align:center'>"
            f"<div style='font-size:12px;font-weight:bold'>{CFG['project_name']}</div>"
            f"<div style='font-size:11px;font-weight:bold'>{CFG.get('subtitle', '')}</div>"
            f"<div style='font-size:9px;font-weight:bold;border:1px solid #000;"
            f"margin:2px 12px;padding:1px'>{title_text}</div>"
            + (f"<div style='font-size:8px'>Created by {CFG['created_by']}</div>"
               if CFG.get("created_by") else "")
            + "</div>")
    add_label(layout, SB_X, 5, SB_W, 26, html=head)
    # ── legend ──
    add_label(layout, SB_X, 33, SB_W, 46, html=build_legend_html(map_layers), frame=True)
    # ── count tables ──
    ct = count_tables_html()
    if ct:
        add_label(layout, SB_X, 81, SB_W, 168, html=ct, align_center=True, valign_center=False)
    # ── scale note ──
    add_label(layout, SB_X, 251, SB_W, 8,
              text=f"Scale: {CFG.get('scale_note', 'As-Shown (A3)')}", size=8, bold=True)
    # ── logo (wide) at the bottom ──
    if os.path.exists(LOGO):
        logo = QgsLayoutItemPicture(layout)
        logo.setPicturePath(LOGO)
        logo.setResizeMode(_enum(QgsLayoutItemPicture, "ResizeMode.Zoom", "Zoom"))
        layout.addLayoutItem(logo)
        logo.attemptMove(mmpoint(SB_X + 6, 262)); logo.attemptResize(mmsize(68, 28))
    return MAP


def _wayleave_icon(kind):
    """Draw one fixed legend icon (Cambridge wayleave style) to a PNG:
    poles = hollow circle · span = the house span colour · erven = black rectangle ·
    pop = orange star. Colours come from CFG, so they follow the house standard.

    Only reached when the project has no matching layer to read the real symbology off —
    a legend row is drawn from the LAYER wherever one exists."""
    from qgis.PyQt.QtGui import QImage, QPainter, QColor, QPen, QBrush, QPolygonF
    from qgis.PyQt.QtCore import QPointF
    import math
    d = _legend_dir()
    S = 8
    w = h = 24
    img = QImage(w * S, h * S, QImage.Format.Format_ARGB32); img.fill(0)
    pa = QPainter(img)
    try:
        pa.setRenderHint(_enum(QPainter, "RenderHint.Antialiasing", "Antialiasing"), True)
    except Exception:
        pass
    cx, cy = w * S / 2.0, h * S / 2.0
    def _cfg_qcolor(key, default):
        try:
            parts = [int(v) for v in str(CFG.get(key, default)).split(",")[:3]]
            return QColor(*parts)
        except Exception:
            return QColor(*[int(v) for v in default.split(",")])
    if kind == "poles":
        pa.setPen(QPen(QColor(255, 255, 255), 2 * S))
        pa.setBrush(QBrush(_cfg_qcolor("wayleave_pole_color", "255,0,0")))
        r = 6 * S; pa.drawEllipse(int(cx - r), int(cy - r), int(2 * r), int(2 * r))
    elif kind == "span":
        pa.setPen(QPen(_cfg_qcolor("wayleave_span_color", "252,7,183"), 5 * S))
        pa.drawLine(int(2 * S), int(cy), int((w - 2) * S), int(cy))
    elif kind == "erven":
        pa.setPen(QPen(QColor(0, 0, 0), 2 * S)); pa.setBrush(QBrush(QColor(0, 0, 0, 0)))
        pa.drawRect(int(3 * S), int(7 * S), int((w - 6) * S), int((h - 14) * S))
    elif kind == "pop":
        pa.setPen(QPen(QColor(180, 90, 0), 1)); pa.setBrush(QBrush(QColor(245, 166, 35)))
        pts = []
        for i in range(10):
            ang = math.pi / 2 + i * math.pi / 5
            rr = (9 * S) if i % 2 == 0 else (3.8 * S)
            pts.append(QPointF(cx + rr * math.cos(ang), cy - rr * math.sin(ang)))
        pa.drawPolygon(QPolygonF(pts))
    pa.end()
    # The filename carries the colours for the same reason the layer swatches do: a
    # picture item caches by path, so reusing wl_span.png across a colour change printed
    # the old icon next to the new map.
    tag = "%s_%s" % (_safe_key(str(CFG.get("wayleave_span_color", ""))),
                     _safe_key(str(CFG.get("wayleave_pole_color", ""))))
    path = os.path.join(d, f"wl_{kind}_{tag}.png"); img.save(path)
    return path


def _wl_text(layout, x, y, w, h, text, size=9, bold=False, left=False, top=False,
             frame=False, bg=False, z=None):
    """A NATIVE plain-text layout label (NOT HTML) — individually selectable + editable in
    the designer. [% … %] expressions still evaluate in text mode."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtGui import QFont
    lbl = QgsLayoutItemLabel(layout)
    lbl.setText(text or "")
    f = QFont("Arial"); f.setPointSize(size); f.setBold(bold); lbl.setFont(f)
    hz = (_enum(Qt, "AlignmentFlag.AlignLeft", "AlignLeft") if left
          else _enum(Qt, "AlignmentFlag.AlignHCenter", "AlignHCenter"))
    vt = (_enum(Qt, "AlignmentFlag.AlignTop", "AlignTop") if top
          else _enum(Qt, "AlignmentFlag.AlignVCenter", "AlignVCenter"))
    try:
        lbl.setHAlign(hz); lbl.setVAlign(vt)
    except Exception:
        pass
    layout.addLayoutItem(lbl)
    lbl.attemptMove(mmpoint(x, y)); lbl.attemptResize(mmsize(w, h))
    if frame:
        lbl.setFrameEnabled(True); lbl.setFrameStrokeColor(QColor(0, 0, 0))
        lbl.setFrameStrokeWidth(QgsLayoutMeasurement(0.4, MM))
    if bg:
        try:
            lbl.setBackgroundEnabled(True); lbl.setBackgroundColor(QColor(255, 255, 255))
        except Exception:
            pass
    if z is not None:
        lbl.setZValue(z)
    return lbl


def _wl_pic(layout, x, y, w, h, path, z=None):
    """A native Picture item (logo / north / legend icon)."""
    if not path or not os.path.exists(path):
        return None
    pic = QgsLayoutItemPicture(layout)
    pic.setPicturePath(path)
    pic.setResizeMode(_enum(QgsLayoutItemPicture, "ResizeMode.Zoom", "Zoom"))
    layout.addLayoutItem(pic)
    pic.attemptMove(mmpoint(x, y)); pic.attemptResize(mmsize(w, h))
    if z is not None:
        pic.setZValue(z)
    return pic


# Wayleave legend, in drawing order: (label, geometry, name keywords, name anti-keywords).
# Every row is rendered from the layer's OWN symbology, so a restyle cannot leave the
# legend describing something the sheet no longer draws. A row whose layer is absent from
# the map (or empty) is dropped rather than shown as a promise the drawing does not keep.
# Legend rows, in drawing order: (label, role). The role is resolved by the SAME
# classifier the styler uses, so a legend row can never describe a layer the sheet did
# not draw, or go missing because two keyword lists disagreed.
# Legend rows, in the order the issued reference sheet lists them: Poles, Span, Erven,
# POP — and nothing else. The role is resolved by the SAME classifier the styler uses, so
# a row can never describe a layer the sheet did not draw. Rows whose role is in
# `wayleave_hide_roles` are dropped, and a role with no layer in this project is dropped
# too, so the block only ever names marks that are actually on the page.
WL_LEGEND_SPEC = [
    ("Poles",        "pole"),
    ("Span",         "route"),
    ("Erven",        "erven"),
    ("POP",          "pop"),
    ("Boundary",     "boundary"),
    ("Obstacle",     "obstacle"),
]
# The first four have a hand-drawn fallback icon (the Cambridge Village set) for projects
# that carry no such layer; the rest are simply omitted when there is nothing to draw.
WL_FALLBACK_ICON = {"Poles": "poles", "Span": "span", "Erven": "erven", "POP": "pop"}


def _wl_legend_spec():
    """[(label, role)] for the legend — CFG['wayleave_legend_rows'] when set, else the
    built-in reference-sheet rows.

    Accepts ["Label", "role"] pairs or {"label":…, "role":…} dicts, so the preset .json
    can be written either way. A malformed row is skipped WITH A MESSAGE rather than
    silently dropped: a legend that quietly lost a row is how a drawing goes out promising
    less than it shows.
    """
    rows = CFG.get("wayleave_legend_rows")
    if not rows:
        return list(WL_LEGEND_SPEC)
    known = {r for r, _g, _i, _e in WL_ROLE_SPEC}
    out = []
    for row in rows:
        try:
            if isinstance(row, dict):
                label, role = row.get("label"), row.get("role")
            else:
                label, role = row[0], row[1]
            role = str(role).strip().lower()
            if not label or role not in known:
                print("legend row skipped (unknown role %r): %r" % (role, row))
                continue
            out.append((str(label), role))
        except Exception as e:
            print("legend row skipped (%s): %r" % (e, row))
    if not out:
        print("wayleave_legend_rows produced no usable rows - using the built-in set")
        return list(WL_LEGEND_SPEC)
    return out


def _wl_swatch_for(layer, geom, key):
    """A legend swatch PNG rendered from `layer`'s real symbology.

    The filename carries the COLOUR, not just the row label. It used to be label-only, so
    changing the house span colour rewrote the same path — and QgsLayoutItemPicture caches
    an image by its path, so the sheet kept printing the previous swatch while the map
    drew the new colour. That shipped a legend that contradicted its own map.
    """
    col_key = _safe_key(_layer_color(layer) or "x")
    if geom == "point":
        return _render_layer_symbol(layer, "%s_%s" % (_safe_key(key), col_key))
    if geom == "line":
        return _rect_png("bar_%s_%s" % (_safe_key(key), col_key),
                         _layer_color(layer), w=40, h=13)
    col, outline_only = _poly_swatch(layer)
    ck = _safe_key(col or "x")
    if outline_only:
        return _rect_png("sw_%s_%s_o" % (_safe_key(key), ck), None, w=26, h=14,
                         outline=col, outline_w=1.6)
    return _rect_png("sw_%s_%s_f" % (_safe_key(key), ck), col, w=26, h=14,
                     outline="#444444", outline_w=0.7)


def _wl_fixed_legend_items(map_layers):
    """The wayleave legend rows, each drawn from the layer the sheet actually renders.

    Scoped to `map_layers` on purpose: the legend must describe THIS drawing, not every
    layer that happens to be open in the project.
    """
    from qgis.core import QgsVectorLayer
    pool = [l for l in (map_layers or []) if l is not None]
    if not pool:
        pool = [l for l in p.mapLayers().values() if isinstance(l, QgsVectorLayer)]
    bm = _basemap_layer()
    bm_id = bm.id() if bm else None
    pool = [l for l in pool
            if isinstance(l, QgsVectorLayer) and not (bm_id and l.id() == bm_id)]
    by_role = _wl_layers_by_role(pool)
    hide = _wl_hidden_roles()
    out = []
    for label, role in _wl_legend_spec():
        if role in hide:
            continue
        hit = None
        for l in by_role.get(role, []):
            try:
                if l.featureCount() == 0:      # nothing drawn -> no row promising it
                    continue
            except Exception:
                pass
            hit = l
            break
        if hit is not None:
            png = _wl_swatch_for(hit, _geom_of(hit), label)
            if png:
                out.append((label, png))
                continue
        # No layer for this role in THIS project: only the four canonical rows get a
        # hand-drawn stand-in, and only when the drawing would otherwise lose a row the
        # reference sheet always carries.
        fb = WL_FALLBACK_ICON.get(label)
        if fb and role not in hide:
            out.append((label, _wayleave_icon(fb)))
    return out


def _wl_overview_only_box(item):
    """Make a layout label's white fill + black frame appear on the OVERVIEW page only.

    The title is one atlas-expression label reused on every page; it renders empty on the
    detail pages, and an empty label with a background is still a white rectangle stamped
    over the aerial photo. Data-defining the two colours off `is_overview` leaves the item
    (and its expression) exactly as it was and simply paints it to nothing elsewhere.
    """
    if item is None:
        return item
    try:
        from qgis.core import QgsLayoutObject, QgsProperty
        cond = "attribute(@atlas_feature,'is_overview')=1"
        dd = item.dataDefinedProperties()
        dd.setProperty(QgsLayoutObject.DataDefinedProperty.BackgroundColor,
                       QgsProperty.fromExpression(
                           "if(%s,'255,255,255,255','255,255,255,0')" % cond))
        dd.setProperty(QgsLayoutObject.DataDefinedProperty.FrameColor,
                       QgsProperty.fromExpression(
                           "if(%s,'0,0,0,255','0,0,0,0')" % cond))
    except Exception as e:
        print("title box dd err", e)
    return item


def _wl_legend_items(map_layers):
    """[(label, icon_png_path)] for the wayleave legend — from the picked layers' REAL
    symbology when the operator chose layers, else the fixed wayleave row set."""
    if CFG.get("legend_from_symbology"):
        layers = _resolve_layer_list(CFG["hld_layers"]) if CFG.get("hld_layers") else (map_layers or [])
        bm = _basemap_layer(); bm_id = bm.id() if bm else None
        out = []; seen = set()
        for l in layers:
            if l is None or l.id() in seen or (bm_id and l.id() == bm_id):
                continue
            seen.add(l.id())
            g = _geom_of(l); nm = _friendly_name(l)
            if g == "point":
                png = _render_layer_symbol(l, _safe_key(l.name()))
            elif g == "line":
                png = _rect_png("bar_" + _safe_key(nm), _layer_color(l), w=44, h=10)
            elif g == "polygon":
                col, outline = _poly_swatch(l)
                png = (_rect_png("sw_" + _safe_key(nm), None, w=26, h=14, outline=col, outline_w=1.6)
                       if outline else
                       _rect_png("sw_" + _safe_key(nm), col, w=26, h=14, outline="#444444", outline_w=0.7))
            else:
                png = None
            out.append((nm, png))
        return out
    return _wl_fixed_legend_items(map_layers)


def build_frame_wayleave(layout, title_text, map_layers=None):
    """Cambridge wayleave frame (A4 landscape), built from NATIVE layout items ONLY — no
    HTML anywhere. Every piece (title, page number, description, each legend row, each
    title-block cell, logo) is an individually selectable + editable text / rectangle /
    picture item. Full-bleed map + bottom strip (Description · legend · Date/Scale/Project ·
    logo). Used inside the unified single-layout book (overview = page 1, then tiles)."""
    PAGE_W, PAGE_H = 297.0, 210.0
    STRIP_H = 34.0
    strip_y = PAGE_H - 3.0 - STRIP_H
    MAP = dict(x=4, y=4, w=PAGE_W - 8, h=strip_y - 4 - 1)
    ZTOP = 900.0                                       # keep frame items above the later map
    add_rect(layout, 3, 3, PAGE_W - 6, PAGE_H - 6, stroke_w=1.0)                 # outer border
    add_rect(layout, MAP["x"], MAP["y"], MAP["w"], MAP["h"], stroke_w=0.6)       # map border

    # ── title (expression -> "Wayleave Application" on the overview, blank on tiles) ──
    if title_text:
        # White box behind it: plain black text sat straight on the satellite image and was
        # unreadable over pale veld. The reference sheet boxes its title the same way.
        _t = _wl_text(layout, (PAGE_W - 120) / 2.0, 5, 120, 11, title_text, size=15,
                      bold=True, frame=True, bg=True, z=ZTOP)
        _wl_overview_only_box(_t)

    # ── north arrow ──
    _wl_pic(layout, PAGE_W - 22, 8, 13, 13, NORTH_SVG, z=ZTOP)

    # ── page-number corner (expression) — native bordered white box ──
    corner = CFG.get("page_label_expr") or ""
    if corner:
        _wl_text(layout, PAGE_W - 3 - 46, strip_y - 10, 46, 9, corner,
                 size=10, bold=True, frame=True, bg=True, z=ZTOP)

    # ── bottom strip dividers ──
    x_desc, x_leg, x_info, x_logo, x_end = 4.0, 142.0, 200.0, 254.0, PAGE_W - 3.0
    for xd in (x_leg, x_info, x_logo):
        add_rect(layout, xd, strip_y, 0.0, STRIP_H, stroke_w=0.6)

    # ── Project Description (native heading + body text) ──
    # The credit line, when there is one, takes the bottom of this column, so the body
    # box gives up exactly that much height — otherwise the two overlap and the drawing
    # ships with the description printed through the attribution.
    _attrib = str(CFG.get("wayleave_attribution", "") or "").strip()
    _attrib_h = 5.0 if _attrib else 0.0
    _wl_text(layout, x_desc + 2, strip_y + 1.5, x_leg - x_desc - 4, 6,
             "Project Description:", size=9, bold=True, left=True, top=True)
    _wl_text(layout, x_desc + 2, strip_y + 8, x_leg - x_desc - 4, STRIP_H - 10 - _attrib_h,
             str(CFG.get("wayleave_desc", "")), size=8, left=True, top=True)
    if _attrib:
        _wl_text(layout, x_desc + 2, strip_y + STRIP_H - _attrib_h - 1.0,
                 x_leg - x_desc - 4, _attrib_h, _attrib,
                 size=int(round(float(CFG.get("wayleave_attribution_size", 6)))),
                 left=True, top=True)

    # ── Legend (no heading — symbol then label, as on the reference sheet) ──
    # Each row is its own picture + text item, so the whole block stays editable in the
    # designer. Past four rows it splits into two columns rather than shrinking the type:
    # a wayleave is read at arm's length off a printed A4.
    items = _wl_legend_items(map_layers)
    n = max(1, len(items))
    ncol = 2 if n > 4 else 1
    per_col = -(-n // ncol)                      # ceil
    col_w = (x_info - x_leg) / ncol
    row_h = min(7.0, (STRIP_H - 2.0) / max(1, per_col))
    icon_w = 11.0
    top = strip_y + (STRIP_H - row_h * per_col) / 2.0
    for i, (lab, png) in enumerate(items):
        cx = x_leg + (i // per_col) * col_w
        ry = top + (i % per_col) * row_h
        _wl_pic(layout, cx + 1.5, ry + 0.4, icon_w, max(2.5, row_h - 1.4), png)
        _wl_text(layout, cx + icon_w + 3.0, ry, col_w - icon_w - 4.5, row_h, lab,
                 size=7, left=True)

    # ── Title block: Date / Scale / Project as native boxed rows ──
    info_rows = [("Date", str(CFG.get("date_str", ""))),
                 ("Scale", str(CFG.get("wayleave_scale_note", "NTS"))),
                 ("Project", str(CFG.get("project_name", "")))]
    bh = STRIP_H / 3.0
    key_w = (x_logo - x_info) * 0.36
    for i, (k, val) in enumerate(info_rows):
        yy = strip_y + i * bh
        add_rect(layout, x_info, yy, key_w, bh, stroke_w=0.5)
        add_rect(layout, x_info + key_w, yy, (x_logo - x_info) - key_w, bh, stroke_w=0.5)
        _wl_text(layout, x_info + 1.5, yy, key_w - 2, bh, k + ":", size=9, bold=True, left=True)
        _wl_text(layout, x_info + key_w + 1, yy, (x_logo - x_info) - key_w - 2, bh, val, size=9)

    # ── logo ──
    _wl_pic(layout, x_logo + 3, strip_y + 4, x_end - x_logo - 6, STRIP_H - 8, LOGO)
    return MAP


def _html_panel(layout, html, x, y, w, key, frame=False):
    """Render an HTML fragment to a PNG (via QTextDocument) and place it as a Picture at
    the EXACT height of its content. Bulletproof vs QGIS's HTML-label height quirks:
    the picture is a fixed image, so it can never overflow into a neighbour, and it
    looks identical in the live designer and the headless export. Returns (item, h_mm)."""
    from qgis.PyQt.QtGui import QTextDocument, QImage, QPainter, QColor
    d = _legend_dir()
    base, scale = 96.0, 5.0                       # 96-dpi CSS px; 5x = ~480dpi, crisp even zoomed
    px_w = max(10, int(round(w / 25.4 * base)))
    doc = QTextDocument(); doc.setHtml(html); doc.setTextWidth(px_w)
    px_h = max(10, int(round(doc.size().height())))
    img = QImage(int(px_w * scale), int(px_h * scale), QImage.Format.Format_ARGB32)
    img.fill(QColor(255, 255, 255))
    pa = QPainter(img)
    try:
        pa.setRenderHint(_enum(QPainter, "RenderHint.Antialiasing", "Antialiasing"), True)
        pa.setRenderHint(_enum(QPainter, "RenderHint.TextAntialiasing", "TextAntialiasing"), True)
    except Exception:
        pass
    pa.setPen(QColor(0, 0, 0))
    pa.scale(scale, scale)
    doc.drawContents(pa)
    pa.end()
    path = os.path.join(d, f"panel_{key}.png"); img.save(path)
    h_mm = px_h / base * 25.4
    pic = QgsLayoutItemPicture(layout)
    pic.setPicturePath(path)
    pic.setResizeMode(_enum(QgsLayoutItemPicture, "ResizeMode.Stretch", "Stretch"))
    layout.addLayoutItem(pic)
    pic.attemptMove(mmpoint(x, y)); pic.attemptResize(mmsize(w, h_mm))
    if frame:
        pic.setFrameEnabled(True)
        pic.setFrameStrokeColor(QColor(0, 0, 0))
        pic.setFrameStrokeWidth(QgsLayoutMeasurement(0.4, MM))
    return pic, h_mm


def _exclude_on_overview(item):
    """Data-defined: keep this layout item OUT of the exported overview page (is_overview=1),
    so a per-page table/title only appears on the detail pages (re-evaluates per atlas page)."""
    from qgis.core import QgsLayoutObject, QgsProperty
    try:
        item.dataDefinedProperties().setProperty(
            QgsLayoutObject.DataDefinedProperty.ExcludeFromExports,
            QgsProperty.fromExpression("attribute(@atlas_feature,'is_overview')=1"))
    except Exception:
        pass


def _auto_table_columns(fields):
    """Pick sensible cable-schedule columns from whatever fields the layer actually has
    (schema-agnostic; tolerates the 'Lenght' misspelling in the Matiko data)."""
    low = {f.lower(): f for f in fields}
    picks = []

    def add(cands, head):
        for c in cands:
            if c in low:
                picks.append((low[c], head))
                return
    add(["cable_id", "id", "name", "cab name", "label"], "ID")
    add(["type", "tier", "size", "cable_type", "fiber_size"], "Type")
    add(["lenght", "length", "cable_leng", "len_m", "dim2"], "Length")
    if not picks and fields:
        picks = [(fields[0], fields[0])]
    return picks


def _add_per_page_table(layout, x, y, w, h):
    """P3.3: native per-page cable schedule — an attribute table on the configured cable role,
    filtered to the current atlas feature, row-capped, hidden on the overview page. Editable
    in the designer. Returns the frame (or None if the role can't be resolved)."""
    from qgis.core import (QgsLayoutItemAttributeTable, QgsLayoutFrame, QgsLayoutTableColumn)
    from qgis.PyQt.QtGui import QFont
    lyr = _role(CFG.get("table_role", "distribution"))
    if lyr is None:
        return None
    t = QgsLayoutItemAttributeTable.create(layout)
    layout.addMultiFrame(t)
    t.setVectorLayer(lyr)
    for setter, arg in (("setFilterToAtlasFeature", True),
                        ("setMaximumNumberOfFeatures", int(CFG.get("table_max_rows", 40))),
                        ("setDisplayOnlyVisibleFeatures", False),
                        ("setShowEmptyRows", False)):
        try:
            getattr(t, setter)(arg)
        except Exception:
            pass
    fields = [f.name() for f in lyr.fields()]
    spec_cols = CFG.get("table_columns") or _auto_table_columns(fields)
    cols = []
    for spec in spec_cols:
        fld, head = (spec if isinstance(spec, (list, tuple)) else (spec, spec))
        if fld in fields:
            c = QgsLayoutTableColumn()
            c.setAttribute(fld)
            c.setHeading(head)
            cols.append(c)
    if cols:
        try:
            t.setColumns(cols)
        except Exception:
            pass
    cf = QFont("Arial"); cf.setPointSize(6)
    hf = QFont("Arial"); hf.setPointSize(6); hf.setBold(True)
    try:
        t.setContentFont(cf); t.setHeaderFont(hf)
    except Exception:
        pass
    frame = QgsLayoutFrame(layout, t)
    frame.attemptMove(mmpoint(x, y)); frame.attemptResize(mmsize(w, h))
    frame.setFrameEnabled(True)
    frame.setFrameStrokeColor(QColor(0, 0, 0))
    frame.setFrameStrokeWidth(QgsLayoutMeasurement(0.4, MM))
    t.addFrame(frame)
    _exclude_on_overview(frame)      # no table on the whole-AOI overview page
    return frame


def _place_per_page_table(layout, x, y, w, box_h):
    """Title label + the schedule table stacked in a reserved sidebar box; both hidden on
    the overview page. Called from the band-distribution loop with the resolved y."""
    title = CFG.get("table_title", "CABLE SCHEDULE")
    th = 5.0
    lbl = add_label(
        layout, x, y, w, th,
        html=("<div style='font-family:Arial;font-size:9px;font-weight:bold;"
              "text-decoration:underline;text-align:center'>%s</div>" % title))
    _exclude_on_overview(lbl)
    _add_per_page_table(layout, x, y + th, w, max(8.0, box_h - th))


def _distribute_sidebar(items, top, bottom):
    """Place sidebar items top->bottom, GUARANTEEING every item stays within
    [top, bottom] with no overlap — so the last item can never cross the bottom-anchored
    title block. Even gaps when there's room; when the band is tight, gaps collapse to a
    minimum and the FLEXIBLE items (north arrow, logo) shrink toward their floor until
    everything fits. Deterministic — identical on every page. items = list of mutable
    [reserve_h, place_fn(y, h), flex(bool), floor_h]."""
    MIN_GAP = 3.0                          # matches the historical floor (keeps MOA identical)
    avail = bottom - top

    def tight():
        return sum(it[0] for it in items) + MIN_GAP * (len(items) + 1)

    # Only engage the NEW safety behaviour when the content would otherwise overflow the band:
    # shrink the flexible items (north/logo) toward their floor until it fits. When everything
    # already fits, fall through to the ORIGINAL even-gap formula below -> byte-identical output.
    guard = 0
    while tight() > avail and guard < 600:
        guard += 1
        flex = [it for it in items if it[2] and it[0] > it[3] + 0.05]
        if not flex:
            break                          # only fixed panels left -> can't shrink further
        tallest = max(flex, key=lambda it: it[0])
        tallest[0] = max(tallest[3], tallest[0] - 1.0)
    total = sum(it[0] for it in items)
    gap = max(MIN_GAP, (avail - total) / (len(items) + 1))   # original formula (no upper cap)
    y = top + gap
    for h, place, _flex, _floor in items:
        place(y, h)
        y += h + gap


def build_frame(layout, title_text, map_layers=None, drawn=None):
    """`map_layers` = what THIS page draws. `drawn` = every layer the BOOK draws anywhere
    (overview ∪ detail). The sidebar is built once while the map switches theme per page, so
    the legend and the totals table are filtered against `drawn`, not against one page's set —
    filtering against either half alone would leave a page with a symbol it does not draw, or
    drop one it does. `drawn=None` keeps the pre-2026-09 behaviour (no filtering)."""
    if CFG.get("frame_style") == "wayleave":
        return build_frame_wayleave(layout, title_text, map_layers)
    if CFG.get("frame_style") == "commercial":
        return build_frame_commercial(layout, title_text, map_layers)
    # geometry (mm) for A3 landscape 420x297
    MAP = dict(x=6, y=28, w=322, h=263)
    SB_W = 80.0
    # centre the sidebar in the white band between the map's right edge and the border
    _white_l = MAP["x"] + MAP["w"]      # 328
    _white_r = 417.0                    # inner border right
    SB_X = round(_white_l + (_white_r - _white_l - SB_W) / 2.0, 1)   # 332.5
    PAGE_H = 297.0
    add_rect(layout, 3, 3, 414, 291, stroke_w=1.0)          # outer border
    # title bar
    add_rect(layout, MAP["x"], 6, MAP["w"], 18, stroke_w=0.8)
    add_label(layout, MAP["x"], 6, MAP["w"], 18,
              html=f"<div style='font-family:Arial;font-size:19px;font-weight:bold;text-decoration:underline'>{title_text}</div>")

    # ── legend — pre-rendered image at its exact content height (never overflows) ──
    if CFG.get("legend_from_symbology"):
        _picked = _resolve_layer_list(CFG["hld_layers"]) if CFG.get("hld_layers") else map_layers
        leg_rows = _symbology_legend_rows(_picked)
    else:
        leg_rows = _legend_rows(map_layers, drawn=drawn)
    _compact = bool(CFG.get("legend_compact"))
    _leg, h_leg = _html_panel(layout, _legend_table(leg_rows, compact=_compact),
                              SB_X, 6, SB_W, "legend", frame=True)
    # ADAPTIVE: a many-layer legend can grow tall enough to crowd the sidebar. If a normal
    # legend exceeds its height budget, re-render it COMPACT so the middle band keeps room
    # for north/logo. Short legends (e.g. MOA/Fibertime) stay under budget -> untouched.
    _leg_budget = float(CFG.get("legend_max_h", 82.0))
    if not _compact and h_leg > _leg_budget:
        layout.removeLayoutItem(_leg)
        _leg, h_leg = _html_panel(layout, _legend_table(leg_rows, compact=True),
                                  SB_X, 6, SB_W, "legend", frame=True)
        print("legend auto-compacted: %.1fmm -> %.1fmm (%d rows)" % (_leg_budget, h_leg, len(leg_rows)))

    # ── title block — HTML label with a generous fixed box (few rows), bottom-anchored ──
    h_title = 76.0 if CFG.get("iso_title_block") else 46.0   # ISO block has more rows
    title_y = PAGE_H - 3.0 - h_title
    add_label(layout, SB_X, title_y, SB_W, h_title, html=titleblock_html(), valign_center=False)

    # ── middle blocks: build them (measured), then distribute evenly in the free band ──
    band_top = 6.0 + h_leg

    def _place_north(y, h=31.0):
        arrow = max(12.0, min(24.0, h - 7.0))       # arrow scales with the reserved box
        if NORTH_SVG:
            pic = QgsLayoutItemPicture(layout)
            pic.setPicturePath(NORTH_SVG)
            layout.addLayoutItem(pic)
            pic.attemptMove(mmpoint(SB_X + (SB_W - arrow) / 2.0, y))
            pic.attemptResize(mmsize(arrow, arrow))
        add_label(layout, SB_X, y + arrow, SB_W, 7, text="N", size=11, bold=True)

    def _place_logo(y, h=28.0):
        if os.path.exists(LOGO):
            lw = min(SB_W, h * (48.0 / 28.0))        # keep the 48x28 aspect while scaling
            logo = QgsLayoutItemPicture(layout)
            logo.setPicturePath(LOGO)
            logo.setResizeMode(_enum(QgsLayoutItemPicture, "ResizeMode.Zoom", "Zoom"))
            layout.addLayoutItem(logo)
            logo.attemptMove(mmpoint(SB_X + (SB_W - lw) / 2.0, y))
            logo.attemptResize(mmsize(lw, h))

    # middle band items, top->bottom: [reserve_h, place_fn(y,h), flexible, floor_h].
    # summary/tables are FIXED (pre-rendered); north + logo are FLEXIBLE (can shrink to fit).
    items = []
    if CFG.get("show_summary"):
        if CFG.get("per_page_summary"):
            sm, h_sm = _zone_summary_label(layout, SB_W)
            items.append([h_sm, lambda y, h, it=sm: it.attemptMove(mmpoint(SB_X, y)), False, h_sm])
        else:
            sm_html = summary_html(drawn)
            if sm_html:
                sm, h_sm = _html_panel(layout, sm_html, SB_X, band_top, SB_W, "summary")
                items.append([h_sm, lambda y, h, it=sm: it.attemptMove(mmpoint(SB_X, y)), False, h_sm])
    # the ISO title block already carries Scale + Datum/CRS → skip the redundant map-info panel
    if CFG.get("show_map_info") and not CFG.get("iso_title_block"):
        mi, h_mi = _html_panel(layout, map_info_html(), SB_X, band_top, SB_W, "mapinfo", frame=True)
        items.append([h_mi, lambda y, h, it=mi: it.attemptMove(mmpoint(SB_X, y)), False, h_mi])
    # ── P3.3: per-page cable schedule (config-gated) — reserve a box in the sidebar band ──
    if CFG.get("per_page_table"):
        _box = float(CFG.get("table_box_h", 58.0))
        items.append([_box, lambda y, h: _place_per_page_table(layout, SB_X, y, SB_W, h), False, _box])
    items.append([31.0, _place_north, True, 20.0])
    items.append([28.0, _place_logo, True, 16.0])

    # guaranteed-fit distribution: nothing ever crosses the title block (title_y)
    _distribute_sidebar(items, band_top, title_y)
    return MAP


def _keep_unclipped(layer):
    """Layers that stay whole when the page is clipped to its PON: rasters (basemap), the AOI
    boundary, and any backbone cable named by CFG['atlas_clip_keep'] (feeder / primary / ADSS,
    but never Mini-ADSS, which is a distribution cable)."""
    from qgis.core import QgsVectorLayer
    try:
        if not isinstance(layer, QgsVectorLayer):
            return True                                   # basemap / rasters give context
        nm = (layer.name() or "").lower()
        if nm == str(CFG.get("aoi_layer", "")).lower():
            return True
        if "mini" in nm:
            return False
        return any(k in nm for k in (CFG.get("atlas_clip_keep") or []))
    except Exception:
        return False


def _apply_atlas_clip(m, layers):
    """Isolate the current atlas feature on the detail map (JJ, 2026-08-26): QGIS's own
    per-page clipping cuts every clipped layer to the PON polygon, labels are kept inside it,
    and the keep-list layers render untouched. Nothing on the live layers changes."""
    from qgis.core import QgsMapClippingRegion
    try:
        cs = m.atlasClippingSettings()
        cs.setEnabled(True)
        cs.setFeatureClippingType(QgsMapClippingRegion.FeatureClippingType.ClipToIntersection)
        cs.setForceLabelsInsideFeature(True)
        clip = [l for l in (layers or []) if not _keep_unclipped(l)]
        cs.setRestrictToLayers(True)
        cs.setLayersToClip(clip)
        print("HLD atlas clip: %d layers clipped, %d kept whole"
              % (len(clip), len(layers or []) - len(clip)))
    except Exception as e:
        print("HLD atlas clip skipped:", e)


def make_map(layout, MAP, layers, extent=None, atlas_driven=False, margin=0.10):
    m = QgsLayoutItemMap(layout)
    m.setId("mainmap")
    layout.addLayoutItem(m)
    m.attemptMove(mmpoint(MAP["x"], MAP["y"])); m.attemptResize(mmsize(MAP["w"], MAP["h"]))
    m.setLayers(layers)
    m.setFrameEnabled(True); m.setFrameStrokeWidth(QgsLayoutMeasurement(0.4, MM))
    m.setBackgroundColor(QColor(255, 255, 255))
    # NOTE: QGIS4 setExtent() RESIZES the item to the extent's aspect. For a fixed page
    # frame we must only ever hand it an extent that already matches the item aspect.
    if extent is not None and not atlas_driven:
        m.setExtent(extent)                        # overview: caller pre-fit to item aspect
    if atlas_driven:
        # Atlas "Auto" sets the per-feature extent itself (fitting it INSIDE this frame),
        # so we do NOT setExtent() here — that would resize the frame off the page.
        m.setAtlasDriven(True)
        m.setAtlasScalingMode(ATLAS_AUTO)
        m.setAtlasMargin(margin)
        if CFG.get("atlas_clip"):
            _apply_atlas_clip(m, layers)
    # lock the frame to the page-fitting size (belt-and-suspenders vs any resize)
    m.attemptMove(mmpoint(MAP["x"], MAP["y"])); m.attemptResize(mmsize(MAP["w"], MAP["h"]))
    # remember the designed frame so the page-view atlas can RE-lock after preview resizes it
    # (QGIS4 atlas preview grows the frame to the first feature's aspect once; re-locking
    # once makes it hold across all features — verified).
    try:
        m.setCustomProperty("hld_frame_x", float(MAP["x"]))
        m.setCustomProperty("hld_frame_y", float(MAP["y"]))
        m.setCustomProperty("hld_frame_w", float(MAP["w"]))
        m.setCustomProperty("hld_frame_h", float(MAP["h"]))
    except Exception:
        pass
    return m


def remove_layout(name):
    lm = p.layoutManager()
    ex = lm.layoutByName(name)
    if ex is not None:
        lm.removeLayout(ex)


def new_layout(name):
    remove_layout(name)
    layout = QgsPrintLayout(p)
    layout.initializeDefaults()
    layout.setName(name)
    pc = layout.pageCollection()
    pg = pc.page(0)
    pg.setPageSize(CFG.get("page_size", "A3"), LAND)
    return layout


def _restore_aoi():
    aoi = _aoi_layer()
    if aoi is not None:
        try:
            aoi.setOpacity(1.0)
            if CFG.get("aoi_subset"):
                aoi.setSubsetString(CFG["aoi_subset"])
            aoi.triggerRepaint()
        except Exception:
            pass
    return aoi


def _aoi_filter_greenfield(aoi):
    """True only when this AOI layer distinguishes 'Greenfield' rows AND no subset is
    already applied. Mohadin's boundary carries Greenfield + Overbuild polygons (filter to
    Greenfield); a generic client boundary has no such row -> use the whole layer."""
    if aoi.subsetString():
        return False, None
    nmf = next((f.name() for f in aoi.fields() if f.name().lower() == "name"), None)
    if not nmf:
        return False, None
    try:
        has_gf = any("greenfield" in str(f[nmf]).lower() for f in aoi.getFeatures())
    except Exception:
        has_gf = False
    return has_gf, nmf


def _greenfield_extent():
    aoi = _aoi_layer()
    if aoi is None:
        return None
    filter_gf, nmf = _aoi_filter_greenfield(aoi)
    ext = QgsRectangle(); ext.setMinimal(); n = 0
    for f in aoi.getFeatures():
        if filter_gf and "greenfield" not in str(f[nmf]).lower():
            continue
        g = f.geometry()
        if g and not g.isEmpty():
            ext.combineExtentWith(g.boundingBox()); n += 1
    return ext if n else None


def _aoi_geometry():
    """Union polygon of the AOI (greenfield) features; returns (geometry, crs) or (None, None).
    Honours aoi_subset (already applied by _restore_aoi); else keeps only 'greenfield' rows."""
    aoi = _restore_aoi()
    if aoi is None:
        return None, None
    from qgis.core import QgsGeometry
    filter_gf, nmf = _aoi_filter_greenfield(aoi)
    geom = None
    for f in aoi.getFeatures():
        if filter_gf and "greenfield" not in str(f[nmf]).lower():
            continue
        g = f.geometry()
        if g and not g.isEmpty():
            geom = QgsGeometry(g) if geom is None else geom.combine(g)
    return geom, aoi.crs()


def _overview_geometry(target_crs=None):
    """Geometry the overview page is framed on: (geometry, crs) or (None, None).

    Default is the AOI, unchanged. When `overview_geometry_layers` names layers, their
    features are unioned instead — a phase book frames page 1 on ALL eight phase
    boundaries so every book opens on the same whole-town picture, not on its own phase.
    Falls through to the AOI if none of the named layers resolve, so a typo degrades to
    the old behaviour rather than producing an empty overview.

    ⚠ EVERY geometry is transformed into `target_crs` before it is combined. Unioning
    across layers without that is silently catastrophic: QgsGeometry.combine() does not
    check CRS, so mixing a degrees layer with a metres layer yields a "valid" geometry
    whose bounding box spans from 25 to 2 858 496. The atlas then frames the overview page
    on that box, the map lands on empty space, and the page exports BLANK — with correct
    layers, a correct theme and every structural check passing. (Exactly what happened on
    2026-08-26: layersToRender() reported all 8 boundaries on a page that drew nothing.)
    """
    names = CFG.get("overview_geometry_layers")
    if not names:
        geom, crs = _aoi_geometry()
        return _to_crs(geom, crs, target_crs), (target_crs or crs)
    from qgis.core import QgsGeometry
    geom = None
    for nm in names:
        l = _lyr(nm)
        if l is None:
            continue
        for f in l.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            g = _to_crs(QgsGeometry(g), l.crs(), target_crs)
            if g is None or g.isEmpty():
                continue
            geom = g if geom is None else geom.combine(g)
    if geom is None:
        geom, crs = _aoi_geometry()
        return _to_crs(geom, crs, target_crs), (target_crs or crs)
    return geom, target_crs


def _to_crs(geom, src_crs, dst_crs):
    """Reproject `geom` from `src_crs` to `dst_crs`. Returns the geometry unchanged when
    either CRS is missing or they already match; None only if the transform itself fails."""
    if geom is None or dst_crs is None or src_crs is None:
        return geom
    try:
        if src_crs.authid() and src_crs.authid() == dst_crs.authid():
            return geom
        from qgis.core import QgsCoordinateTransform, QgsGeometry
        tr = QgsCoordinateTransform(src_crs, dst_crs, p)
        out = QgsGeometry(geom)
        out.transform(tr)
        return out
    except Exception as e:
        print("overview geometry transform failed (%s -> %s): %s"
              % (src_crs.authid(), dst_crs.authid(), e))
        return None


def _metres_to_units(cw, ch, crs, ext):
    """Cell width/height in metres -> layer units. For geographic CRS, convert with a
    latitude correction so cells are ~square on the ground."""
    import math
    if crs is not None and crs.isGeographic():
        lat = (ext.yMinimum() + ext.yMaximum()) / 2.0
        dx = cw / (111320.0 * max(0.15, math.cos(math.radians(lat))))
        dy = ch / 110540.0
        return dx, dy
    return cw, ch


def _visible_content_layers():
    """The vector layers the grid is allowed to cover: whatever is TICKED ON in the
    Layers panel, or an explicit list the dialog handed us.

    This is the whole selection rule, and it is deliberately dumb. An earlier version
    matched layer names against a list of fibre roles and decided for the operator which
    of them mattered; that bakes one project's idea of "important" into a tool that runs
    on everyone's. The canvas already carries that decision — tick the erven off and the
    grid stops covering them.

    Two exclusions, neither of them a judgement about content:
      * rasters — a basemap covers the planet, so counting one keeps every tile and makes
        the whole test inert;
      * the grid layer itself, which would otherwise mark every cell as occupied.

    `grid_content_layer_ids` in CFG overrides the tick state (the export dialog sets it),
    so unticking a layer for THIS drawing never touches the operator's own layer tree.
    """
    from qgis.core import QgsVectorLayer
    grid_name = CFG.get("grid_layer_name", "HLD Grid")
    ids = CFG.get("grid_content_layer_ids")
    if ids:
        pool = [p.mapLayer(i) for i in ids]
    else:
        try:
            pool = list(p.layerTreeRoot().checkedLayers())
        except Exception as e:
            print("grid: cannot read the layer tree (%s) - falling back to all layers" % e)
            pool = list(p.mapLayers().values())
    out = []
    for l in pool:
        if l is None or not isinstance(l, QgsVectorLayer):
            continue
        if l.name() == grid_name:
            continue
        try:
            if l.featureCount() <= 0:
                continue
        except Exception:
            continue
        out.append(l)
    return out


def _cells_with_visible_content(cells, cell_crs=None):
    """Subset of `cells` carrying something the operator can actually see on the canvas.

    A cell is kept when any feature of any visible layer falls inside it. For line layers
    `grid_min_route_m` can require a real run rather than a corner clip; it defaults to 0,
    i.e. any feature in the cell earns a page — exactly what the canvas shows.

    Layers whose CRS differs from `cell_crs` are reprojected, not skipped. A mismatch used
    to drop every cell, and the caller's fail-open fallback then quietly kept them all —
    the filter looked like it was running when it was doing nothing.
    """
    from qgis.core import QgsSpatialIndex, QgsWkbTypes, QgsGeometry, QgsFeature
    try:
        min_m = float(CFG.get("grid_min_route_m", 0.0) or 0.0)
    except Exception:
        min_m = 0.0
    scan = []
    for l in _visible_content_layers():
        try:
            geoms = {}
            for f in l.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g = _to_crs(QgsGeometry(g), l.crs(), cell_crs)
                if g is None or g.isEmpty():
                    continue
                geoms[f.id()] = g
            if not geoms:
                continue
            is_line = QgsWkbTypes.geometryType(l.wkbType()) == QgsWkbTypes.LineGeometry
            idx = QgsSpatialIndex()
            for fid, g in geoms.items():
                ft = QgsFeature(fid)
                ft.setGeometry(g)
                idx.addFeature(ft)
            scan.append((idx, geoms, is_line))
        except Exception as e:
            print("grid content scan skipped", l.name(), e)
    if not scan:
        return []
    kept = []
    for cell in cells:
        bb = cell.boundingBox()
        hit = False
        for idx, geoms, is_line in scan:
            run_m = 0.0
            for fid in idx.intersects(bb):
                g = geoms.get(fid)
                if g is None or g.isEmpty() or not g.intersects(cell):
                    continue
                if not is_line or min_m <= 0:
                    hit = True
                    break
                try:
                    clipped = g.intersection(cell)
                except Exception:
                    clipped = None
                if clipped is None or clipped.isEmpty():
                    continue
                run_m += _len_m(_to_crs(clipped, cell_crs, p.crs()))
                if run_m >= min_m:
                    hit = True
                    break
            if hit:
                break
        if hit:
            kept.append(cell)
    return kept


def _visible_content_extent():
    """(QgsRectangle, crs) covering every layer the grid is allowed to cover, or (None, None).

    Same input as the cell test: whatever is ticked on, or the dialog's explicit list. So
    the frame and the kept cells can never disagree about what "the data" is.

    Layers whose CRS differs from the first are reprojected rather than skipped — a project
    mixing CRSs would otherwise silently frame on only some of its data.
    """
    from qgis.core import QgsRectangle, QgsCoordinateTransform
    union, ucrs = None, None
    for l in _visible_content_layers():
        try:
            e = l.extent()
            if e is None or e.isNull() or e.isEmpty():
                continue
            if union is None:
                union, ucrs = QgsRectangle(e), l.crs()
                continue
            if l.crs() != ucrs:
                try:
                    tr = QgsCoordinateTransform(l.crs(), ucrs, p)
                    e = tr.transformBoundingBox(e)
                except Exception as ex:
                    print("content extent: could not reproject", l.name(), ex)
                    continue
            union.combineExtentWith(e)
        except Exception as ex:
            print("content extent skipped", getattr(l, "name", lambda: "?")(), ex)
    return union, ucrs


def _frame_on_content():
    """True when the grid should be framed on the visible data instead of the AOI polygon.

    `grid_frame_on_network` is the original key and still works; wayleave.json and any
    saved client config carry it.
    """
    v = CFG.get("grid_frame_on_content")
    if v is None:
        v = CFG.get("grid_frame_on_network")
    return bool(v)


def _covers(outer, inner, min_frac):
    """Does `outer` cover at least `min_frac` of `inner`'s area? (both QgsRectangle)"""
    try:
        if outer is None or inner is None:
            return False
        ia = inner.width() * inner.height()
        if ia <= 0:
            return False
        x = outer.intersect(inner)
        if x is None or x.isNull() or x.isEmpty():
            return False
        return (x.width() * x.height()) / ia >= float(min_frac)
    except Exception:
        return False


def _grid_layer_from_cells(cells, crs):
    """Build (and register) the numbered grid memory layer from `cells`, in order.

    Cells are renumbered 1..N here and nowhere else, so the atlas order, the overview boxes
    and "Page N of M" cannot disagree about which page is which.
    """
    from qgis.core import QgsVectorLayer, QgsField, QgsFeature
    name = CFG.get("grid_layer_name", "HLD Grid")
    for l in list(p.mapLayers().values()):
        if l.name() == name:
            p.removeMapLayer(l.id())
    vl = QgsVectorLayer("Polygon?crs=%s" % crs.authid(), name, "memory")
    dp = vl.dataProvider()
    dp.addAttributes([QgsField("cell_no", QMetaType.Type.Int)])
    vl.updateFields()
    feats = []
    for k, cell in enumerate(cells, start=1):
        feat = QgsFeature(vl.fields())
        feat.setGeometry(cell)
        feat.setAttribute("cell_no", k)
        feats.append(feat)
    dp.addFeatures(feats)
    vl.updateExtents()
    # add to the layer TREE (True) so the overview map theme can include the numbered grid
    # (map themes only capture tree layers), then UNCHECK it so it does not clutter the live
    # canvas - the overview theme record still shows it explicitly.
    p.addMapLayer(vl, True)
    try:
        node = p.layerTreeRoot().findLayer(vl.id())
        if node is not None:
            node.setItemVisibilityChecked(False)
    except Exception:
        pass
    return vl


def _approved_cells():
    """(cells, crs) the operator ticked in the export dialog, or (None, None).

    A WKT round-trip, deliberately: the headless render is a different process reading a
    saved project, so anything re-derived there could land somewhere other than what was on
    screen. Geometry travels; a recipe does not.
    """
    wkts = CFG.get("grid_cells_wkt") or []
    authid = (CFG.get("grid_cells_crs") or "").strip()
    if not wkts or not authid:
        return None, None
    from qgis.core import QgsGeometry, QgsCoordinateReferenceSystem
    crs = QgsCoordinateReferenceSystem(authid)
    if not crs.isValid():
        print("grid: approved cells carry an unusable CRS (%r) - re-deriving instead" % authid)
        return None, None
    cells = []
    for w in wkts:
        g = QgsGeometry.fromWkt(w)
        if g is None or g.isEmpty():
            continue
        cells.append(g)
    if not cells:
        print("grid: approved cell list was unreadable - re-deriving instead")
        return None, None
    return cells, crs


def plan_grid():
    """What a grid book WOULD produce, without building anything.

    Returns (cells, crs, rows); `rows` is one dict per cell - {"n", "wkt", "counts"} - where
    counts is {layer name: features falling in that cell}. The export dialog lists these and
    hands the ones it keeps straight back as grid_cells_wkt, so the pages shown are the
    pages printed.
    """
    from qgis.core import QgsSpatialIndex, QgsGeometry, QgsFeature
    cells, crs, _nx, _ny = _planned_cells()
    if not cells:
        return [], None, []
    scan = []
    for l in _visible_content_layers():
        try:
            geoms = {}
            for f in l.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g = _to_crs(QgsGeometry(g), l.crs(), crs)
                if g is None or g.isEmpty():
                    continue
                geoms[f.id()] = g
            if not geoms:
                continue
            idx = QgsSpatialIndex()
            for fid, g in geoms.items():
                ft = QgsFeature(fid)
                ft.setGeometry(g)
                idx.addFeature(ft)
            scan.append((l.name(), idx, geoms))
        except Exception as e:
            print("grid plan skipped", l.name(), e)
    rows = []
    for n, cell in enumerate(cells, start=1):
        bb = cell.boundingBox()
        counts = {}
        for nm, idx, geoms in scan:
            c = 0
            for fid in idx.intersects(bb):
                g = geoms.get(fid)
                if g is not None and not g.isEmpty() and g.intersects(cell):
                    c += 1
            if c:
                counts[nm] = c
        rows.append({"n": n, "wkt": cell.asWkt(), "counts": counts})
    return cells, crs, rows


def _candidate_cells():
    """(cells, crs, nx, ny): every tile the grid could use, before the empty-cell filter.

    Framing comes from the visible layers when the model opts in, otherwise from the AOI,
    with the old coverage-layer / any-layer fallbacks behind both. ([], None, 0, 0) when
    there is nothing tileable at all.
    """
    import math
    from qgis.core import QgsGeometry, QgsRectangle
    cw = float(CFG.get("grid_cell_w_m") or 0.0)
    ch = float(CFG.get("grid_cell_h_m") or 0.0)
    if cw <= 0 or ch <= 0:
        return [], None, 0, 0

    def _usable(r):
        """A QgsRectangle we can actually tile: real, non-empty, finite. A null rectangle
        reports DBL_MAX bounds, so width()/height() come back as inf and int(ceil(inf))
        raises OverflowError - which is exactly how a wayleave on a project with no AOI
        polygon used to die."""
        if r is None or r.isNull() or r.isEmpty():
            return False
        w, h = r.width(), r.height()
        return all(math.isfinite(v) for v in (w, h)) and w > 0 and h > 0

    geom, crs = _aoi_geometry()
    ext = geom.boundingBox() if geom is not None else None
    if _frame_on_content():
        # ALWAYS, not just when the AOI is missing. Framing on the boundary is what tiled
        # open veld: a municipal AOI is drawn around a town, the fibre occupies part of it,
        # and every cell in between became a page.
        #
        # An earlier version did this by heuristic - it replaced an AOI that covered less
        # than `grid_aoi_min_cover` of the network - and it silently re-paginated a
        # Fouriesburg book that was already correct. The difference now is that this is not
        # a guess: the operator opts the MODEL in, the frame comes from the layers they
        # ticked, and the export dialog shows the resulting pages before anything prints.
        # A model that does not set the flag (the A3 HLD book) is untouched.
        cx_ext, cx_crs = _visible_content_extent()
        if cx_ext is not None and (cx_ext.width() <= 0 or cx_ext.height() <= 0):
            # A single point, or a row of points on one line, has a zero-area extent. That
            # is a legitimate drawing (a POP-only sheet), but it tiles to nothing, so grow
            # it to one whole cell around the content.
            gx, gy = _metres_to_units(cw, ch, cx_crs, cx_ext)
            cx_ext.grow(max(gx, gy) / 2.0)
            print("grid: visible content has no area - grown to one cell around it")
        if _usable(cx_ext):
            print("grid: framing on the visible layers (%s)"
                  % ("no AOI in this project" if ext is None else "not the AOI boundary"))
            geom, crs = QgsGeometry.fromRect(cx_ext), cx_crs
            ext = cx_ext
        elif ext is not None:
            print("grid: WARNING - nothing visible to frame on; falling back to the AOI. "
                  "Tick the layers this drawing is about, or the grid will tile the whole "
                  "boundary.")
    if not _usable(ext):
        # 1) the per-page coverage layer (PONs / blocks), 2) failing that, every vector
        # layer with real features - so a plain project with no AOI polygon still tiles.
        geom = None
        cand = _role("coverage")
        if cand is not None and _usable(cand.extent()):
            geom = QgsGeometry.fromRect(cand.extent())
            crs = cand.crs()
        else:
            from qgis.core import QgsVectorLayer as _VL
            union = None
            ucrs = None
            for lyr in p.mapLayers().values():
                if not isinstance(lyr, _VL) or lyr.featureCount() <= 0:
                    continue
                e = lyr.extent()
                if not _usable(e):
                    continue
                if union is None:
                    union = QgsRectangle(e)
                    ucrs = lyr.crs()
                elif lyr.crs() == ucrs:
                    union.combineExtentWith(e)
            if union is not None:
                geom = QgsGeometry.fromRect(union)
                crs = ucrs
        if geom is None:
            print("grid: no AOI, no coverage layer and no usable layer extent - grid skipped")
            return [], None, 0, 0
        ext = geom.boundingBox()
        if not _usable(ext):
            print("grid: fallback extent still unusable - grid skipped")
            return [], None, 0, 0
    dx, dy = _metres_to_units(cw, ch, crs, ext)
    if dx <= 0 or dy <= 0 or not (math.isfinite(dx) and math.isfinite(dy)):
        return [], None, 0, 0
    nx = max(1, int(math.ceil(ext.width() / dx)))
    ny = max(1, int(math.ceil(ext.height() / dy)))
    cells = []
    for j in range(ny):                       # top row first -> readable numbering
        for i in range(nx):
            x0 = ext.xMinimum() + i * dx
            y1 = ext.yMaximum() - j * dy
            cell = QgsGeometry.fromRect(QgsRectangle(x0, y1 - dy, x0 + dx, y1))
            if cell.intersects(geom):
                cells.append(cell)
    return cells, crs, nx, ny


def _planned_cells():
    """(cells, crs, nx, ny): the tiles that would actually be printed - candidates minus
    the ones carrying nothing visible. One code path, so the export dialog cannot list a
    different set of pages from the one the render produces.
    """
    cells, crs, nx, ny = _candidate_cells()
    if not cells:
        return cells, crs, nx, ny
    if CFG.get("grid_skip_empty_cells"):
        kept = _cells_with_visible_content(cells, crs)
        # If the scan matched nothing at all, no visible vector layer covers any cell -
        # dropping every page would be worse than printing them, so keep the lot and say so.
        if kept:
            print("grid: %d of %d cells carry visible content - %d blank page(s) dropped"
                  % (len(kept), len(cells), len(cells) - len(kept)))
            cells = kept
        else:
            print("grid: nothing visible matched any cell, keeping all %d" % len(cells))
    return cells, crs, nx, ny


def _generate_grid():
    """Tile the visible content (or the AOI) at the configured cell size; add the result as
    a memory layer and return it. No-op unless grid_cell_w_m/h_m are set.

    An approved cell list from the export dialog wins outright: those cells print, exactly
    as they were shown, with no re-derivation.
    """
    cw = float(CFG.get("grid_cell_w_m") or 0.0)
    ch = float(CFG.get("grid_cell_h_m") or 0.0)
    if cw <= 0 or ch <= 0:
        return None
    cells, crs = _approved_cells()
    if cells:
        print("grid: %d cells approved in the export dialog" % len(cells))
        return _grid_layer_from_cells(cells, crs)
    cells, crs, nx, ny = _planned_cells()
    if not cells:
        return None
    vl = _grid_layer_from_cells(cells, crs)
    print("grid: %d cells (%dx%d scan) at %.0fx%.0f m" % (len(cells), nx, ny, cw, ch))
    return vl


def _style_labels():
    """Cable/pole/splitter labels ON with white halos (per CFG['labels']); OFF where configured None."""
    from qgis.core import (QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                           QgsVectorLayerSimpleLabeling, QgsUnitTypes)
    from qgis.PyQt.QtGui import QColor, QFont
    PT = _enum(QgsUnitTypes, "RenderUnit.RenderPoints", "RenderPoints")
    MMU = _enum(QgsUnitTypes, "RenderUnit.RenderMillimeters", "RenderMillimeters")

    def field(layer, *cands):
        names = [f.name() for f in layer.fields()]
        for c in cands:
            if c in names:
                return c
        return names[0] if names else None

    def lbl(layer, size, along_line, buf=0.8, strip=None):
        if layer is None:
            return
        s = QgsPalLayerSettings()
        fld = field(layer, "label", "Label", "name")
        if strip:
            s.fieldName = 'replace("' + fld + '", \'' + strip + '\', \'\')'
            s.isExpression = True
        else:
            s.fieldName = fld
        s.enabled = True
        fmt = QgsTextFormat(); fmt.setFont(QFont("Arial")); fmt.setSize(size)
        try: fmt.setSizeUnit(PT)
        except Exception: pass
        b = QgsTextBufferSettings(); b.setEnabled(True); b.setSize(buf); b.setColor(QColor(255, 255, 255))
        try: b.setSizeUnit(MMU)
        except Exception: pass
        fmt.setBuffer(b); s.setFormat(fmt)
        try:
            s.placement = (_enum(QgsPalLayerSettings, "Placement.Curved", "Curved", "Line") if along_line
                           else _enum(QgsPalLayerSettings, "Placement.AroundPoint", "AroundPoint", "OverPoint"))
        except Exception: pass
        # scale-based: labels ONLY when zoomed into a page (detail export) -> full-project canvas stays fast
        s.scaleVisibility = True
        s.minimumScale = float(CFG["label_min_scale"])
        s.maximumScale = 0.0
        layer.setLabeling(QgsVectorLayerSimpleLabeling(s))
        layer.setLabelsEnabled(True)   # NO triggerRepaint -> don't force a heavy canvas re-render

    def off(layer):
        if layer:
            layer.setLabelsEnabled(False)

    for role, spec in CFG["labels"].items():
        layer = _role(role)
        if spec is None:
            off(layer)
        else:
            lbl(layer, spec["size"], spec["along_line"], spec.get("buf", 0.8), spec.get("strip"))


def _rgb(spec):
    try:
        r, g, b = [int(x) for x in str(spec).split(",")[:3]]
        return QColor(r, g, b)
    except Exception:
        return QColor(spec)


def _style_enclosures():
    """Distinct colours for splice (blue) vs connectorised (cyan) enclosures — so they read
    clearly on the map AND the legend (which renders these same symbols) matches. Works for
    BOTH project shapes: separate splice/connectorised layers, or one categorized layer."""
    from qgis.core import (QgsMarkerSymbol, QgsSingleSymbolRenderer,
                           QgsCategorizedSymbolRenderer, QgsRendererCategory)

    def style_single(layer, rgb):
        if layer is None:
            return
        try:
            sym = QgsMarkerSymbol.createSimple({"name": "circle", "color": rgb,
                                                "outline_color": "40,40,40", "outline_width": "0.2", "size": "1.7"})
            layer.setRenderer(QgsSingleSymbolRenderer(sym)); layer.triggerRepaint()
        except Exception as e:
            print("enc style err", e)

    # (a) separate layers, if the project has them
    style_single(_role("enc_splice"), CFG["enc_splice_rgb"])
    style_single(_role("enc_conn"), CFG["enc_conn_rgb"])

    # (b) one categorized "Enclosure" layer -> recolour its splice/connectorised categories
    enc = _p2_enclosure()
    if enc is None:
        return
    r = enc.renderer()
    if not hasattr(r, "categories"):
        return
    try:
        cats = []
        for c in r.categories():
            v = str(c.value()).lower()
            sym = c.symbol().clone()
            if "splice" in v:
                sym.setColor(_rgb(CFG["enc_splice_rgb"]))
            elif "connect" in v:
                sym.setColor(_rgb(CFG["enc_conn_rgb"]))
            # keep every category enabled (map shows them all; don't trust a stray False)
            cats.append(QgsRendererCategory(c.value(), sym, c.label(), True))
        enc.setRenderer(QgsCategorizedSymbolRenderer(r.classAttribute(), cats))
        enc.triggerRepaint()
    except Exception as e:
        print("enc cat style err", e)


def _style_hld_cables():
    """Optional tiered cable symbology (feeder thick, distribution medium, drop thin)
    with a clean, colourblind-safe palette. Config-gated via CFG['hld_cable_style'] so it
    never overrides a project's own careful styling (default None → MOA untouched).
    Tames cluttered per-project cable rendering (e.g. Matiko's magenta spaghetti)."""
    spec = CFG.get("hld_cable_style")
    if not spec:
        return
    from qgis.core import QgsLineSymbol, QgsSingleSymbolRenderer
    order = ("primary", "secondary", "distribution", "spare_drop", "drop")  # thick→thin draw order
    for role in order:
        st = spec.get(role)
        if not st:
            continue
        lyr = _role(role)
        if lyr is None:
            continue
        try:
            sym = QgsLineSymbol.createSimple({
                "color": str(st.get("color", "#555555")),
                "width": str(st.get("w", 0.4)),
                "capstyle": "round", "joinstyle": "round",
            })
            lyr.setRenderer(QgsSingleSymbolRenderer(sym))
            lyr.triggerRepaint()
        except Exception as e:
            print("hld_cable_style err", role, e)


def _style_pon():
    """See-through PON fill + crisp outline; PON labels get a white halo."""
    from qgis.PyQt.QtGui import QColor
    from qgis.core import QgsVectorLayerSimpleLabeling, QgsUnitTypes
    pon = _role("coverage")
    if pon is None:
        return
    try:
        # EVERY symbol, not just .symbol(): that only exists on a single-symbol renderer,
        # so on a categorized PON layer (Malmesbury = 90 categories) this raised on the
        # first line, the except below swallowed it, and the PON fill stayed fully opaque
        # with no label halo on every client atlas. MOA is single-symbol, which is why it
        # looked fine. Alpha must be applied to ALL categories or half the map is opaque.
        from qgis.core import QgsRenderContext
        rndr = pon.renderer()
        try:
            syms = list(rndr.symbols(QgsRenderContext()))
        except Exception:
            syms = [_any_symbol(rndr)]
        syms = [s for s in syms if s is not None]
        if not syms:
            return
        for s in syms:
            s.setOpacity(1.0)
            sl = s.symbolLayer(0)
            if sl is None:
                continue
            if hasattr(sl, "fillColor"):
                fc = sl.fillColor(); fc.setAlpha(int(CFG["pon_fill_alpha"])); sl.setFillColor(fc)
            if hasattr(sl, "strokeColor"):
                st = sl.strokeColor(); st.setAlpha(255); sl.setStrokeColor(st)
        if pon.labeling():
            settings = pon.labeling().settings()
            fmt = settings.format()
            fmt.setSize(9)
            buf = fmt.buffer(); buf.setEnabled(True); buf.setSize(1.1)
            try:
                buf.setSizeUnit(_enum(QgsUnitTypes, "RenderUnit.RenderMillimeters", "RenderMillimeters"))
            except Exception:
                pass
            buf.setColor(QColor(255, 255, 255)); buf.setOpacity(1.0)
            fmt.setBuffer(buf)
            settings.setFormat(fmt)
            pon.setLabeling(QgsVectorLayerSimpleLabeling(settings))
        pon.triggerRepaint()
    except Exception as e:
        print("style_pon err", e)


def _set_label_size(layer, size_pt, buffer_mm=None):
    """Pin a layer's label size to `size_pt` POINTS (and optionally its buffer, in mm).

    Only the size is touched — field, placement, font, colour and scale rules are the
    operator's and stay exactly as they were. Simple labelling only: a rule-based setup
    has no single size to pin, and quietly flattening one into a single rule would lose
    the operator's rules, so it is left alone and reported.
    """
    from qgis.core import QgsVectorLayerSimpleLabeling
    if layer is None or size_pt is None:
        return False
    # NOTE: deliberately does NOT require labelsEnabled(). It used to, and that is how a
    # freshly-opened project shipped a wayleave with no erf numbers at all: the caller had
    # just asked for them to be shown, this returned False without a word, and the one
    # number the sheet exists to carry was missing. Enabling is the caller's job (_wl_label).
    lab = layer.labeling()
    if not isinstance(lab, QgsVectorLayerSimpleLabeling):
        if lab is not None:
            print("label size: %r uses %s, left as-is" % (layer.name(), type(lab).__name__))
        return False
    try:
        lab = lab.clone()
        st = lab.settings()
        fmt = st.format()
        fmt.setSize(float(size_pt))
        try:
            fmt.setSizeUnit(QgsUnitTypes.RenderUnit.RenderPoints)
        except Exception:
            try:
                fmt.setSizeUnit(QgsUnitTypes.RenderPoints)
            except Exception:
                pass                      # keep the project's unit rather than fail
        if buffer_mm is not None:
            buf = fmt.buffer()
            if buf.enabled():
                buf.setSize(float(buffer_mm))
                fmt.setBuffer(buf)
        st.setFormat(fmt)
        lab.setSettings(st)
        layer.setLabeling(lab)
        layer.triggerRepaint()
        return True
    except Exception as e:
        print("label size err", layer.name(), e)
        return False


def _wl_label(layer, role):
    """Apply the wayleave label policy for `role` to `layer`.

    `wayleave_<role>_labels` False switches that layer's labelling off for this build;
    True pins its size via `wayleave_<role>_label_size`. Nothing is written to disk —
    these are in-session renderer/labelling changes like the rest of the wayleave style.
    """
    if layer is None:
        return False
    if not CFG.get("wayleave_%s_labels" % role, True):
        try:
            if layer.labelsEnabled():
                layer.setLabelsEnabled(False)
                layer.triggerRepaint()
            return True
        except Exception as e:
            print("label off err", layer.name(), e)
            return False
    # Asked to SHOW them: the project may have this layer's labelling switched off, or
    # never have configured any. Both are normal on a project that has not made a wayleave
    # before, and both used to come out as a sheet with the numbering silently missing.
    try:
        if layer.labeling() is None and role == "erf":
            if not _build_erf_labeling(layer):
                return False
        if layer.labeling() is not None and not layer.labelsEnabled():
            layer.setLabelsEnabled(True)
    except Exception as e:
        print("label on err", layer.name(), e)
    return _set_label_size(layer, CFG.get("wayleave_%s_label_size" % role),
                           CFG.get("wayleave_%s_label_buffer" % role))


def _build_erf_labeling(layer):
    """Give an erven layer a plain erf-number labelling when it has none of its own.

    Picks the first field from `wayleave_erf_fields` that the layer actually has; if none
    match, falls back to the first field whose name looks like an erf/parcel number, and
    gives up rather than labelling the sheet with something arbitrary.
    """
    from qgis.core import (QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                           QgsVectorLayerSimpleLabeling)
    from qgis.PyQt.QtGui import QColor, QFont
    names = [f.name() for f in layer.fields()]
    fld = next((c for c in CFG.get("wayleave_erf_fields", []) if c in names), None)
    if fld is None:
        fld = next((n for n in names
                    if any(k in n.lower() for k in ("erf", "parcel", "stand"))), None)
    if fld is None:
        print("erf labelling: %r has no erf-number field in %s - left unlabelled"
              % (layer.name(), names[:8]))
        return False
    st = QgsPalLayerSettings()
    st.fieldName = fld
    st.enabled = True
    fmt = QgsTextFormat()
    fmt.setFont(QFont("Arial"))
    fmt.setSize(float(CFG.get("wayleave_erf_label_size", 5.0)))
    buf = QgsTextBufferSettings()
    buf.setEnabled(True)
    buf.setSize(float(CFG.get("wayleave_erf_label_buffer", 0.5)))
    buf.setColor(QColor(255, 255, 255))
    fmt.setBuffer(buf)
    st.setFormat(fmt)
    layer.setLabeling(QgsVectorLayerSimpleLabeling(st))
    layer.setLabelsEnabled(True)
    print("erf labelling: built on %r from field %r" % (layer.name(), fld))
    return True


def _style_wayleave():
    """Velocity wayleave look, applied to ANY project via _wl_classify():

      AOI      invisible (the numbered grid defines the area)
      Erven    outline only, so the aerial and the route read through
      Span     every fibre route in one pink  (`wayleave_span_color`)
      Poles    red dots                       (`wayleave_pole_color`)
      Demand   white dots                     (`wayleave_demand_color`)

    POP and splitters keep their project symbols — they are the marks the reader is
    hunting for and every operator already draws them distinctly. Each colour is a CFG
    key, so a client preset overrides one without a code change."""
    from qgis.core import QgsFillSymbol, QgsSingleSymbolRenderer
    aoi = _aoi_layer()
    if aoi is not None:
        try:
            aoi.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple(
                {"color": "0,0,0,0", "outline_color": "0,0,0,0", "outline_width": "0"})))
            aoi.triggerRepaint()
        except Exception as e:
            print("wayleave aoi style err", e)
    by_role = _wl_layers_by_role()
    obs = (by_role.get("obstacle") or [None])[0]
    if obs is not None:
        try:
            obs.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple({
                "color": str(CFG.get("wayleave_obstacle_color", "255,0,0")),
                "outline_color": str(CFG.get("wayleave_obstacle_outline", "35,35,35")),
                "outline_width": "0.26"})))
            obs.triggerRepaint()
        except Exception as e:
            print("wayleave obstacle style err", e)
    erv = (by_role.get("erven") or [None])[0]
    if erv is not None:
        try:
            erv.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple(
                {"color": "0,0,0,0", "outline_color": "35,35,35", "outline_width": "0.2"})))
            erv.triggerRepaint()
        except Exception as e:
            print("wayleave erven style err", e)
        # Erf numbers sit BEHIND the route, not over it — and are the only numbering left.
        _wl_label(erv, "erf")
    # ── the aerial, faded ──
    _bm = _basemap_layer()
    _op = CFG.get("wayleave_basemap_opacity")
    if _bm is not None and _op is not None:
        try:
            # QgsRasterLayer keeps opacity on its RENDERER; setOpacity() on the layer is a
            # different (vector) API and silently does nothing here.
            r = _bm.renderer()
            if r is not None and hasattr(r, "setOpacity"):
                r.setOpacity(float(_op))
            elif hasattr(_bm, "setOpacity"):
                _bm.setOpacity(float(_op))
            _bm.triggerRepaint()
            print("wayleave: basemap %r faded to %.0f%%" % (_bm.name(), 100.0 * float(_op)))
        except Exception as e:
            print("wayleave basemap opacity err", e)

    # Poles -> hollow circles, every fibre route -> one red "Span".
    # Everything here matches on NAME KEYWORDS, never on a fixed layer name, so the same
    # preset produces the same sheet on any town's project whatever the layers are called.
    from qgis.core import (QgsMarkerSymbol, QgsLineSymbol, QgsVectorLayer)
    for l in p.mapLayers().values():
        if not isinstance(l, QgsVectorLayer):
            continue
        role = _wl_role_of(l)
        if role is None:
            continue
        nm = l.name()
        try:
            if role == "pole":
                l.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple({
                    "name": "circle",
                    "color": str(CFG.get("wayleave_pole_color", "255,0,0")),
                    "outline_color": str(CFG.get("wayleave_pole_outline", "255,255,255")),
                    "outline_width": str(CFG.get("wayleave_pole_outline_w", 0.25)),
                    "size": str(CFG.get("wayleave_pole_size", 1.4))})))
                l.triggerRepaint()
                _wl_label(l, "pole")
            elif role == "demand":
                # Styled explicitly rather than left alone: on another project the demand
                # points arrive in whatever colour that operator chose, and the legend row
                # reads off the layer — so leaving them be made the sheet project-specific.
                l.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple({
                    "name": "circle",
                    "color": str(CFG.get("wayleave_demand_color", "255,255,255")),
                    "outline_color": str(CFG.get("wayleave_demand_outline", "85,85,85")),
                    "outline_width": str(CFG.get("wayleave_demand_outline_w", 0.1)),
                    "size": str(CFG.get("wayleave_demand_size", 1.1))})))
                l.triggerRepaint()
                _wl_label(l, "demand")
            # The wayleave sheet draws the WHOLE aerial route in one "Span" — that is what
            # the legend promises and what the client signs. Matching only the literal names
            # "span"/"running line" quietly left every project whose routes are called
            # "Distribution Cable" / "Feeder Cable" (HeroTel, Fouriesburg) drawn in their live
            # magenta/blue, contradicting the legend on the same page.
            elif role == "route":
                l.setRenderer(QgsSingleSymbolRenderer(QgsLineSymbol.createSimple({
                    "color": str(CFG.get("wayleave_span_color", "252,7,183")),
                    "width": str(CFG.get("wayleave_span_width", 0.6))})))
                l.triggerRepaint()
                _wl_label(l, "route")
            elif role == "splitter":
                _wl_label(l, "splitter")
            elif role == "pop" and CFG.get("wayleave_pop_color"):
                # star_diamond is the closest built-in QGIS marker to the reference
                # sheet's starburst, and unlike an SVG it needs no asset on disk.
                l.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple({
                    "name": "star_diamond",
                    "color": str(CFG.get("wayleave_pop_color")),
                    "outline_color": str(CFG.get("wayleave_pop_outline", "180,90,0")),
                    "outline_width": "0.3",
                    "size": str(CFG.get("wayleave_pop_size", 4.4))})))
                l.triggerRepaint()
            elif role == "road":
                _wl_label(l, "road")            # street names — see wayleave_road_labels
        except Exception as e:
            print("wayleave point/line style err", nm, e)


def _style_commercial():
    """Commercial model: number the grid cells (coverage) for the overview; transparent
    fill + dark outline so the numbered grid reads over the basemap."""
    from qgis.core import (QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                           QgsVectorLayerSimpleLabeling, QgsUnitTypes, QgsFillSymbol,
                           QgsSingleSymbolRenderer)
    from qgis.PyQt.QtGui import QColor, QFont
    grid = _role("coverage")
    fld = CFG.get("coverage_label_field")
    if grid is None or not fld:
        return
    try:
        grid.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple(
            {"color": "0,0,0,0", "outline_color": "0,0,0", "outline_width": "0.4"})))
    except Exception as e:
        print("grid style err", e)
    try:
        s = QgsPalLayerSettings()
        s.fieldName = fld
        s.enabled = True
        try:
            s.centroidInside = True
        except Exception:
            pass
        try:
            s.placement = _enum(QgsPalLayerSettings, "Placement.Horizontal", "Horizontal",
                                "AroundPoint", "OverPoint")
        except Exception:
            pass
        fmt = QgsTextFormat(); fmt.setFont(QFont("Arial")); fmt.setSize(18)
        try:
            fmt.setSizeUnit(_enum(QgsUnitTypes, "RenderUnit.RenderPoints", "RenderPoints"))
        except Exception:
            pass
        b = QgsTextBufferSettings(); b.setEnabled(True); b.setSize(1.2); b.setColor(QColor(255, 255, 255))
        fmt.setBuffer(b); s.setFormat(fmt)
        grid.setLabeling(QgsVectorLayerSimpleLabeling(s))
        grid.setLabelsEnabled(True)
    except Exception as e:
        print("grid label err", e)


# ---- OVERVIEW (report header / page 1) ----
def _make_overview():
    name = CFG["layout_overview"]
    layout = new_layout(name)
    basemap = _basemap_layer()
    aoi = _restore_aoi()
    pon = _role("coverage")
    if CFG.get("overview_layers"):
        # commercial: explicit overview layer set (numbered grid + zoning + boundary + basemap)
        ov_layers = _resolve_layer_list(CFG["overview_layers"])
        ext = pon.extent() if pon else _greenfield_extent()
        gf_ext = _greenfield_extent()
        if gf_ext:
            ext.combineExtentWith(gf_ext)
    elif CFG.get("hld_layers"):
        # operator hand-picked the layers -> coverage + those + basemap
        ov_layers = [l for l in ([pon] + _resolve_layer_list(CFG["hld_layers"]) + [basemap]) if l]
        ext = _greenfield_extent() or (pon.extent() if pon else None)
        if ext is not None and pon:
            ext.combineExtentWith(pon.extent())
    else:
        primary = _role("primary")
        secondary = _role("secondary")
        # OVERVIEW = PON numbers + primary & secondary FEEDER ROUTES only
        ov_layers = [l for l in (primary, secondary, pon, aoi, basemap) if l]
        ext = _greenfield_extent()
        if ext is None:
            ext = pon.extent()
        ext.combineExtentWith(pon.extent())   # every PON guaranteed in
        for _fl in (primary, secondary):      # include feeder routes so none run off the edge
            if _fl:
                ext.combineExtentWith(_fl.extent())
    # frame AFTER the layer list is known -> legend auto-completes from what's drawn
    MAP = build_frame(layout, CFG["title_overview"], map_layers=ov_layers, drawn=ov_layers)
    ext.scale(1.04)
    # force the extent to EXACTLY the map-item aspect (add to the shorter side) -> fills, no white bands
    target_ar = MAP["w"] / MAP["h"]
    cur_ar = ext.width() / ext.height()
    c = ext.center()
    if cur_ar > target_ar:                # too wide -> add height
        nh = ext.width() / target_ar
        ext.setYMinimum(c.y() - nh / 2); ext.setYMaximum(c.y() + nh / 2)
    else:                                 # too tall -> add width
        nw = ext.height() * target_ar
        ext.setXMinimum(c.x() - nw / 2); ext.setXMaximum(c.x() + nw / 2)
    make_map(layout, MAP, ov_layers, extent=ext)
    return layout                       # owned by the report (not added to the manager)


# ---- DETAIL (report body / one page per coverage feature) ----
def _make_detail():
    name = CFG["layout_atlas"]
    layout = new_layout(name)
    gf = _restore_aoi()
    if CFG.get("hld_layers"):
        # operator hand-picked the HLD layers -> use exactly those (+ basemap under them)
        layers = _resolve_layer_list(CFG["hld_layers"])
        bm = _basemap_layer()
        if bm is not None and bm.id() not in {l.id() for l in layers}:
            layers = layers + [bm]
    elif CFG.get("detail_layers"):
        # commercial: explicit detail layer set (zoning + SDU + boundary + basemap; NO grid overlay)
        layers = _resolve_layer_list(CFG["detail_layers"])
    else:
        # take exactly the visible group layers (adapts to renames); drop clutter + feeders
        feeder_names = set(CFG["roles"].get("primary", [])) | set(CFG["roles"].get("secondary", []))
        det_layers = _p2_visible_layers(exclude=set(CFG["detail_exclude"]) | feeder_names)
        if not det_layers:
            # no group (e.g. saved 'HLD only' project) -> known network layers, NO feeders
            seen = set(); det_layers = []
            for n in CFG["detail_fallback"]:
                l = _lyr(n)
                if l and l.id() not in seen:
                    seen.add(l.id()); det_layers.append(l)
        bm = _basemap_layer()
        layers = det_layers + [l for l in (gf, bm) if l]
    # frame AFTER the layer list is known -> legend auto-completes from what's drawn
    MAP = build_frame(layout, CFG["title_atlas_expr"], map_layers=layers, drawn=layers)
    pon = _role("coverage")
    # atlas-driven map => the report field-group sets the current feature and this map
    # zooms/fits to it (proven: each body page frames its own PON inside the fixed frame).
    make_map(layout, MAP, layers, extent=pon.extent(), atlas_driven=True, margin=float(CFG["atlas_margin"]))
    return layout                       # owned by the report (not added to the manager)


def build_report():
    """Assemble ONE editable Report: header = overview (page 1), field-group body =
    one detail page per coverage feature. Exports to a single PDF (overview first)."""
    from qgis.core import QgsReport, QgsReportSectionFieldGroup
    name = CFG["layout_report"]
    lm = p.layoutManager()
    # drop any previous run's report + its stray header/body layouts
    for nm in (name, CFG["layout_overview"], CFG["layout_atlas"]):
        ex = lm.layoutByName(nm)
        if ex is not None:
            lm.removeLayout(ex)
    if _role("coverage") is None:
        raise ValueError(
            "HLD report: no coverage layer (PON/Zone polygon) resolved. Pick or add one.")
    overview = _make_overview()
    detail = _make_detail()
    pon = _role("coverage")
    rep = QgsReport(p)
    rep.setName(name)
    rep.setHeaderEnabled(True)
    rep.setHeader(overview)             # PAGE 1
    fg = QgsReportSectionFieldGroup()
    fg.setLayer(pon)
    fg.setField(CFG["coverage_sort_field"])   # one body page per value, ascending
    try:
        fg.setSortAscending(True)
    except Exception:
        pass
    fg.setBody(detail)
    fg.setBodyEnabled(True)
    rep.appendChild(fg)
    lm.addLayout(rep)
    return name


def _book_layer_sets():
    """(overview_layers, detail_layers, all_layers) for the unified atlas. The overview page
    shows the grid (if grid mode) or feeders + PON + AOI + basemap; detail pages show the
    full network. The grid coverage layer never shows on the detail pages."""
    basemap = _basemap_layer()
    aoi = _restore_aoi()
    # hld_layers is THREE-VALUED: None = no layer list was supplied (keep the defaults below);
    # a list = use exactly it; [] = the operator unticked everything, which is refused rather
    # than falling through to the feeder-injecting default. A non-empty list that resolves to
    # nothing is the same failure wearing a different hat (a name that does not match any
    # layer - e.g. a trailing space), so it is refused with the names that failed.
    _hl = CFG.get("hld_layers")
    picked = None if _hl is None else _resolve_layer_list(_hl)
    if picked is not None and not picked:
        raise ValueError(
            "HLD atlas: no layers to draw. Tick at least one layer under LAYERS."
            + (" (none of these resolved to a layer in this project: %s)" % ", ".join(map(repr, _hl))
               if _hl else ""))
    if CFG.get("overview_layers"):
        overview_layers = _resolve_layer_list(CFG["overview_layers"])   # grid mode: numbered grid + net
        # An explicit overview list that forgets the basemap gives a page of floating
        # polygons on white. Append it if the caller did not name it; harmless when they did.
        if basemap is not None and basemap.id() not in {l.id() for l in overview_layers if l}:
            overview_layers = overview_layers + [basemap]
    elif picked is not None:
        # The operator's ticks, plus the coverage polygon and the basemap - and nothing else.
        # Both extras go through an id-membership guard: ticking the coverage layer or the
        # basemap yourself would otherwise list it twice.
        net_cov = _role("coverage")
        _pids = {l.id() for l in picked}
        overview_layers = [l for l in ([net_cov] if net_cov is not None
                                       and net_cov.id() not in _pids else []) if l]
        overview_layers += picked
        if basemap is not None and basemap.id() not in {l.id() for l in overview_layers}:
            overview_layers.append(basemap)
    else:
        net_cov = _role("coverage")
        if CFG.get("overview_add_feeders", True):
            primary = _role("primary"); secondary = _role("secondary")
        else:
            primary = secondary = None
        overview_layers = [l for l in (primary, secondary, net_cov, aoi, basemap) if l]
    if picked is not None:
        detail_layers = picked + [l for l in (basemap,) if l and l.id() not in {x.id() for x in picked}]
    else:
        feeder_names = set(CFG["roles"].get("primary", [])) | set(CFG["roles"].get("secondary", []))
        exclude = set(CFG["detail_exclude"]) | feeder_names | {CFG.get("grid_layer_name", "HLD Grid")}
        det = _p2_visible_layers(exclude=exclude)
        if not det:
            seen = set(); det = []
            for n in CFG["detail_fallback"]:
                l = _lyr(n)
                if l and l.id() not in seen:
                    seen.add(l.id()); det.append(l)
        detail_layers = det + [l for l in (aoi, basemap) if l]
    # Drop the roles the wayleave does not draw (splitters, demand points) HERE, at the
    # single point both page kinds are decided, so the map, the per-page themes and the
    # legend all see the same set. Doing it per-call let them disagree.
    overview_layers = _wl_drop_hidden(overview_layers)
    detail_layers = _wl_drop_hidden(detail_layers)
    if CFG.get("wayleave_road_labels") and CFG.get("frame_style") == "wayleave":
        # Street names have to come from a ROAD LAYER of ours. They appeared to work
        # before only because the Google basemap has its own street labels baked into the
        # imagery — fading that basemap to 35% faded those away with it, which is exactly
        # what the reference sheet does NOT do: its names are crisp black over a washed
        # aerial. So put our own road layer on both page kinds, directly beneath the
        # network and above the basemap, and label it ourselves.
        overview_layers = _wl_with_roads(overview_layers)
        detail_layers = _wl_with_roads(detail_layers)
    allm = []; seen = set()
    for l in overview_layers + detail_layers:
        if l and l.id() not in seen:
            seen.add(l.id()); allm.append(l)
    return overview_layers, detail_layers, allm


def _role_layers(role):
    """ALL layers configured for a role (not just the first). Multi-layer roles like poles
    (e.g. Distribution Poles + Feeder Poles) would otherwise be undercounted. Falls back to
    the fuzzy single-layer _role() when nothing is configured by exact name."""
    names = _canonical_names(CFG["roles"].get(role, []))   # prefer v1, drop bare decoys
    out, seen = [], set()
    for nm in names:
        l = _lyr(nm)
        if l is not None and l.id() not in seen:
            seen.add(l.id()); out.append(l)
    if out:
        return out
    one = _role(role)
    return [one] if one is not None else []


def _zone_stat_index():
    """Spatial indexes + feature caches for per-zone stats (drops / poles / distribution).
    Merges ALL layers per role into one index with synthetic unique ids (raw feature ids
    collide across layers), so multi-layer roles (poles = Distribution + Feeder) count in full."""
    from qgis.core import QgsSpatialIndex, QgsFeature
    out = {}
    for key, role in (("drops", "drop"), ("poles", "poles"), ("dist", "distribution")):
        layers = _role_layers(role)
        if not layers:
            out[key] = (None, {})
            continue
        idx = QgsSpatialIndex(); cache = {}; uid = 0
        for lyr in layers:
            for f in lyr.getFeatures():
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                nf = QgsFeature(); nf.setId(uid); nf.setGeometry(g)
                idx.addFeature(nf); cache[uid] = nf; uid += 1
        out[key] = (idx, cache)
    return out


def _zone_stats(geom, srcfeat, sidx):
    """Per-coverage-feature stats. Prefer source fields (e.g. unit_count / splitter_c),
    else spatial counts within `geom`. Returns dict of display strings."""
    src_map = CFG.get("zone_stat_source") or {}

    def src(field):
        if not field or srcfeat is None:
            return None
        try:
            return srcfeat[field] if field in srcfeat.fields().names() else None
        except Exception:
            return None

    def within(key):
        idx, feats = sidx.get(key, (None, {}))
        if idx is None or geom is None:
            return 0, 0.0
        n, length = 0, 0.0
        for fid in idx.intersects(geom.boundingBox()):
            fg = feats[fid].geometry()
            if fg and not fg.isEmpty() and geom.intersects(fg):
                n += 1
                length += _len_m(fg)                 # CRS-aware geodesic metres
        return n, length

    units = src(src_map.get("units"))
    spl = src(src_map.get("splitters"))
    n_drops, _ = within("drops")
    n_poles, _ = within("poles")
    _, dist_m = within("dist")
    if units is None:
        units = n_drops
    return {"units": str(units), "spl": "" if spl is None else str(spl),
            "drops": str(n_drops), "poles": str(n_poles), "distm": "%.0f" % dist_m}


def _build_book_coverage():
    """Unified atlas coverage: an OVERVIEW feature (whole AOI) FIRST, then one feature per
    network coverage unit (PON/Zone). Fields: seq (sort), is_overview, unit (page label)."""
    from qgis.core import QgsVectorLayer, QgsField, QgsFeature, QgsGeometry
    cov = _role("coverage")
    if cov is None:
        return None
    name = str(CFG.get("book_prefix") or "") + "HLD Book Pages"
    for l in list(p.mapLayers().values()):
        if l.name() == name:
            p.removeMapLayer(l.id())
    vl = QgsVectorLayer(f"Polygon?crs={cov.crs().authid()}", name, "memory")
    dp = vl.dataProvider()
    dp.addAttributes([QgsField("seq", QMetaType.Type.Int), QgsField("is_overview", QMetaType.Type.Int),
                      QgsField("unit", QMetaType.Type.QString),
                      # per-page stats (populated below; drive the per-zone summary box)
                      QgsField("stat_name", QMetaType.Type.QString),
                      QgsField("stat_units", QMetaType.Type.QString),
                      QgsField("stat_spl", QMetaType.Type.QString),
                      QgsField("stat_drops", QMetaType.Type.QString),
                      QgsField("stat_poles", QMetaType.Type.QString),
                      QgsField("stat_distm", QMetaType.Type.QString)])
    vl.updateFields()
    # target CRS = the memory layer we are about to fill, so the overview feature's geometry
    # is in the SAME CRS as the per-PON features beside it. Anything else frames page 1 on a
    # bounding box that spans two coordinate systems and exports blank.
    geom, _crs = _overview_geometry(vl.crs())
    if geom is None:
        g = None
        for f in cov.getFeatures():
            fg = f.geometry()
            if fg and not fg.isEmpty():
                g = QgsGeometry(fg) if g is None else g.combine(fg)
        geom = g
    feats = []
    per_page = bool(CFG.get("per_page_summary"))     # only compute stats when shown
    sidx = _zone_stat_index() if per_page else None
    ovf = QgsFeature(vl.fields())
    if geom is not None:
        ovf.setGeometry(geom)
    # The overview page is framed on this geometry. If it does not overlap the coverage the
    # atlas frames page 1 on empty space and the page exports BLANK while every structural
    # check still passes — so prove the overlap here, where it is cheap, instead of finding
    # out from a printed book.
    if geom is not None and not geom.isEmpty():
        try:
            if not geom.boundingBox().intersects(cov.extent()):
                msg = ("HLD atlas: the overview page's framing geometry (%s) does not overlap "
                       "the coverage layer %r (%s) — page 1 would render blank. Usually a CRS "
                       "mismatch between overview_geometry_layers and the coverage."
                       % (geom.boundingBox().toString(3), cov.name(), cov.extent().toString(3)))
                if CFG.get("require_theme_binding"):
                    raise ValueError(msg)
                print(msg)
        except ValueError:
            raise
        except Exception:
            pass
    ovf.setAttribute("seq", 0); ovf.setAttribute("is_overview", 1); ovf.setAttribute("unit", "Overview")
    if per_page:
        ov = _zone_stats(geom, None, sidx)
        _sts = _role("sts")
        ovf.setAttribute("stat_name", CFG.get("summary_title", "PROJECT TOTALS"))
        ovf.setAttribute("stat_units", ov["units"])
        ovf.setAttribute("stat_spl", str(_sts.featureCount()) if _sts else "")
        ovf.setAttribute("stat_drops", ov["drops"])
        ovf.setAttribute("stat_poles", ov["poles"])
        ovf.setAttribute("stat_distm", ov["distm"])
    feats.append(ovf)
    # sort field: use the configured one, else fall back so ANY coverage layer works
    sf = CFG["coverage_sort_field"]
    cov_fields = [fld.name() for fld in cov.fields()]
    if sf not in cov_fields:
        for cand in ("label", "pon_no", "zone_id", "zone_name", "name", "id", "fid"):
            if cand in cov_fields:
                sf = cand
                break
        else:
            sf = cov_fields[0] if cov_fields else None

    def _cov_val(f):
        return f.id() if sf is None else f[sf]

    def _sortkey(f):
        v = _cov_val(f)
        # string-safe: coverage pages may mix int/str keys
        return (v is None, str(v) if not isinstance(v, (int, float)) else "", v if isinstance(v, (int, float)) else 0, str(v))
    rows = sorted(cov.getFeatures(), key=_sortkey)
    zprefix = CFG.get("zone_stat_prefix", "ZONE ")
    for i, f in enumerate(rows, start=1):
        nf = QgsFeature(vl.fields()); nf.setGeometry(f.geometry())
        nf.setAttribute("seq", i); nf.setAttribute("is_overview", 0)
        v = _cov_val(f)
        nf.setAttribute("unit", "" if v is None else str(v))
        if per_page:
            st = _zone_stats(f.geometry(), f, sidx)
            nf.setAttribute("stat_name", zprefix + ("" if v is None else str(v)))
            nf.setAttribute("stat_units", st["units"])
            nf.setAttribute("stat_spl", st["spl"])
            nf.setAttribute("stat_drops", st["drops"])
            nf.setAttribute("stat_poles", st["poles"])
            nf.setAttribute("stat_distm", st["distm"])
        feats.append(nf)
    dp.addFeatures(feats); vl.updateExtents()
    p.addMapLayer(vl, False)
    return vl


def _theme_binding_ok(map_item):
    """Is the per-page theme switch REALLY bound on this map item? Returns (ok, why).

    Checked against the live Qt objects, not against what we asked for a moment ago:
    the enum lookup, setFollowVisibilityPreset and the data-defined property each fail
    differently across Qt5/Qt6, and a failure here is invisible in the exported PDF
    except as the exact defect (boundary polygon over every detail page) we are
    preventing. Also confirms both named themes exist to be switched to.
    """
    from qgis.core import QgsLayoutObject
    try:
        if not map_item.followVisibilityPreset():
            return False, "followVisibilityPreset is off"
        prop = map_item.dataDefinedProperties().property(
            QgsLayoutObject.DataDefinedProperty.MapStylePreset)
        if prop is None or not prop.isActive():
            return False, "MapStylePreset property is not active"
        expr = prop.expressionString() or ""
        ov_name, det_name = _theme_names()
        for nm in (ov_name, det_name):
            if nm not in expr:
                return False, "theme %r missing from the expression %r" % (nm, expr)
        mtc = p.mapThemeCollection()
        for nm in (ov_name, det_name):
            if not mtc.hasMapTheme(nm):
                return False, "map theme %r was never registered" % nm
    except Exception as e:
        return False, "binding could not be read back: %s" % e
    return True, ""


def _theme_names():
    """(overview_theme, detail_theme) for THIS book. `book_prefix` keeps parallel books
    from overwriting each other's themes; empty prefix == the historical names."""
    pre = str(CFG.get("book_prefix") or "")
    return pre + "HLD_Overview", pre + "HLD_Detail"


# ───────────────────────────────────────────────────────────────────────────
# WHAT IS THIS LAYER? — one classifier, three consumers.
#
# The wayleave styler, the legend and the drop-blank-pages filter all have to
# agree on which layer is "the poles" and which is "the route". They used to
# each carry their own keyword list, which is three lists that must stay in
# step and will not. They now all call _wl_classify().
#
# Matching is on NAME TOKENS, not raw substrings. Substring matching reads the
# PROJECT's name as if it were the layer's: a town called Fibreville makes every
# layer in it match "fibre", and every layer becomes a fibre route. Tokens with a
# plural allowance ("pole" matches "Poles", not "Fibreville") avoid that while
# still catching how differently planners name the same thing — "Poles v1",
# "poles", "POLE_POINTS", "PoleLayer", "MOA Poles" are all the poles.
#
# Vocabulary is deliberately wide: these are the words seen across HeroTel,
# Fibertime, Vuma and municipal as-builts for the same physical thing. Add to a
# list rather than inventing a second matching rule.
# ───────────────────────────────────────────────────────────────────────────
WL_ROLE_SPEC = [
    # (role, geometry, include, exclude)
    # ORDER MATTERS for point roles: a layer called "Mamelodi POP 3 ONTs" contains both
    # "POP" and "ONT", and the project prefix must not win. The specific roles are tested
    # first and "pop" last, so that layer classifies as the demand points it actually is.
    ("pole",     "point",   ("pole", "poles", "mast", "pylon", "standard"),
                            ("photo", "image", "picture", "note", "label", "buffer",
                             "gap", "gaps", "gapstat", "error", "issue")),
    ("splitter", "point",   ("splitter", "fdt", "fat", "sts", "fts", "dome", "closure",
                             "joint", "cabinet", "enclosure", "aggregation",
                             # a manhole / access chamber is where the joint lives, and a
                             # wayleave has to show it — 28 projects call it one of these.
                             "manhole", "chamber"),
                            ("photo", "image", "note", "label", "error")),
    ("demand",   "point",   ("demand", "ont", "onts", "home", "homes", "premise",
                             "premises", "hhp", "sdu", "mdu", "customer", "customers",
                             "subscriber", "dwelling", "dwellings", "building",
                             "buildings", "structure", "structures", "connection",
                             "connections"),
                            ("contour", "control", "front", "month", "photo", "note")),
    ("pop",      "point",   ("pop", "olt", "headend", "exchange", "node"),
                            ("population", "photo", "note")),
    ("route",    "line",    ("span", "spans", "cable", "cables", "fibre", "fiber",
                             "route", "routes", "aerial", "backbone", "feeder",
                             "distribution", "drop", "drops", "lead", "leadin",
                             "midblock", "running line", "running lines",
                             # underground route still needs a wayleave, and the network
                             # tiers Vuma / DFA projects name their line layers after.
                             "duct", "ducts", "ductbank", "conduit", "conduits",
                             "microduct", "adss", "access", "metro", "fsn", "link",
                             "trench", "trenching",
                             # horizontal directional drilling is a route under a road,
                             # and "cabel" is how a real project on file spells cable.
                             "hdd", "drilling", "directional", "cabel", "cabels"),
                            ("road", "roads", "street", "streets", "contour", "contours",
                             "boundary", "grid", "rail", "railway", "river",
                             "servitude", "photo", "note")),
    # Roads are NOT a route (the route spec excludes them) but they are the thing that
    # carries the street names, so they get a role of their own — after "route", so a
    # cable never lands here by accident.
    ("road",     "line",    ("road", "roads", "street", "streets", "avenue", "avenues",
                             "drive", "lane", "centreline", "centrelines"),
                            ("cable", "fibre", "fiber", "span", "duct", "trench")),
    ("erven",    "polygon", ("erf", "erven", "erwe", "stand", "stands", "parcel",
                             "parcels", "cadastre", "cadastral", "plot", "plots",
                             "property", "properties", "lot", "lots"),
                            ("pon", "zone", "zones", "grid", "overbuild", "greenfield",
                             "aoi", "boundary", "obstacle", "phase")),
    # "zone" is NOT an exclusion here: a planner's "Restricted Zone" is exactly an
    # obstacle, and a PON zone matches none of these words anyway.
    ("obstacle", "polygon", ("obstacle", "obstacles", "nogo", "no go", "no-go",
                             "restriction", "restricted", "exclusion", "servitude",
                             "wetland"),
                            ("erf", "erven", "grid")),
    ("boundary", "polygon", ("boundary", "boundaries", "kmz", "kml", "municipal",
                             "township", "extent", "outline"),
                            ("erf", "erven", "pon", "zone", "grid", "obstacle", "aoi",
                             "greenfield", "overbuild")),
]
# Roles whose presence on a page means the page is worth printing.


def _name_tokens(name):
    """Lower-case word tokens of a layer name, splitting on punctuation AND camelCase.

    "Poles v1" -> {poles, v1} · "POLE_POINTS" -> {pole, points} ·
    "PoleLayer" -> {pole, layer} · "Fouriesburg - KMZ.kmz" -> {fouriesburg, kmz}
    """
    import re
    spaced = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", str(name or ""))
    return {t for t in re.split(r"[^A-Za-z0-9]+", spaced.lower()) if t}


def _name_phrase(name):
    """The layer name as lower-case words in their ORIGINAL order, punctuation and
    camelCase collapsed to single spaces — what multi-word keywords are matched against."""
    import re
    spaced = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", str(name or ""))
    return " ".join(t for t in re.split(r"[^A-Za-z0-9]+", spaced.lower()) if t)


def _tok_hit(tokens, joined, keywords):
    """True when any keyword matches. A single-word keyword must equal a token (or the
    token is that keyword pluralised) — never merely be contained in one, which is what
    let a project name leak into the match. A multi-word keyword is matched as a phrase.
    """
    for k in keywords:
        if " " in k:
            if k in joined:
                return True
            continue
        for t in tokens:
            if t == k or t == k + "s" or t == k + "es" or k == t + "s":
                return True
    return False


def _wl_classify(name, geom):
    """The wayleave role of a layer with this NAME and GEOMETRY, or None.

    Takes name + geometry rather than a layer so it can be exercised directly against a
    table of real-world layer names — the matching rules are the thing that has to be
    right, and they should not need a live QGIS project to test.
    """
    tokens = _name_tokens(name)
    # ORDER MATTERS here: a multi-word keyword like "running line" is matched against this
    # string, and building it from sorted(tokens) turned "Running Line" into "line running",
    # which matched nothing. Keep the name's own word order.
    joined = _name_phrase(name)
    raw = str(name or "").lower()
    for role, g, inc, exc in WL_ROLE_SPEC:
        if g != geom:
            continue
        if not _tok_hit(tokens, joined, inc):
            continue
        if _tok_hit(tokens, joined, exc) or any(e in raw for e in ("photo", "screenshot")):
            continue
        return role
    return None


def _wl_role_of(layer):
    """_wl_classify() for a live layer."""
    if layer is None:
        return None
    try:
        return _wl_classify(layer.name(), _geom_of(layer))
    except Exception:
        return None


def _wl_hidden_roles():
    """Roles the wayleave does not draw at all (CFG['wayleave_hide_roles'])."""
    try:
        return {str(r).strip().lower() for r in (CFG.get("wayleave_hide_roles") or [])}
    except Exception:
        return set()


def _wl_drop_hidden(layers):
    """`layers` minus every layer whose role the WAYLEAVE hides.

    Applied to the map's layer sets AND used to skip legend rows, so a hidden thing can
    never be drawn without a legend row or named in the legend without being drawn — the
    two used to be decided in different places and could disagree.

    WAYLEAVE SHEETS ONLY (2026-09-09). `wayleave_hide_roles` defaults to
    ["splitter", "demand"] for every book, and this was called unconditionally from
    _book_layer_sets() — so on an ordinary HLD book, ticking Dome Joints / 8Way Splitters /
    Demand points drew none of them, with no error and a legend that still named them.
    Measured on two projects: tick 4 layers on Malmesbury, 2 render; Ventersdorp lost 3.
    The config key, this function and the log line all say "wayleave" — so it now only
    runs for one, and every other book draws what the operator ticked."""
    if CFG.get("frame_style") != "wayleave":
        return list(layers or [])
    hide = _wl_hidden_roles()
    if not hide:
        return list(layers or [])
    out, dropped = [], []
    for l in (layers or []):
        if l is None:
            continue
        if _wl_role_of(l) in hide:
            dropped.append(l.name())
            continue
        out.append(l)
    if dropped:
        print("wayleave: not drawing %s (hidden roles: %s)"
              % (", ".join(sorted(dropped)[:8]), ", ".join(sorted(hide))))
    return out


def _wl_with_roads(layers):
    """`layers` with the project's road layer inserted above the basemap, if missing.

    Lists are TOP-FIRST, so the road goes immediately before the first raster: under
    every network mark, over the aerial.
    """
    from qgis.core import QgsRasterLayer
    have = {l.id() for l in (layers or []) if l is not None}
    roads = [l for l in _wl_layers_by_role().get("road", []) if l.id() not in have]
    if not roads:
        return list(layers or [])
    out = list(layers or [])
    at = next((i for i, l in enumerate(out) if isinstance(l, QgsRasterLayer)), len(out))
    for i, rd in enumerate(roads):
        out.insert(at + i, rd)
    print("wayleave: street names from %s" % ", ".join(r.name() for r in roads))
    return out


def _wl_layers_by_role(pool=None):
    """{role: [layers]} over `pool` (default: every vector layer in the project)."""
    from qgis.core import QgsVectorLayer
    out = {}
    src = pool if pool is not None else list(p.mapLayers().values())
    for l in src:
        if not isinstance(l, QgsVectorLayer):
            continue
        r = _wl_role_of(l)
        if r:
            out.setdefault(r, []).append(l)
    return out


NO_LABEL_STYLE = "HLD_NoLabels"


def _current_style_name(layer):
    """The name of `layer`'s current style ("default" on a normal layer), or "" if it has
    no style manager. Map theme records need a real name to switch back to."""
    try:
        sm = layer.styleManager()
        return sm.currentStyle() if sm is not None else ""
    except Exception:
        return ""


def _ensure_overview_style(layer, labels=None, scale=None, name=NO_LABEL_STYLE):
    """Add (or refresh) a named style on `layer` that is the layer EXACTLY as it stands now
    except for the overview-only tweaks asked for, and leave the layer back on the style it
    arrived on. `labels=False` drops labelling; `scale` multiplies every marker size.

    Used to change ONE page of a book without touching what the operator sees everywhere
    else: a map theme can pin a layer to a named style, so the overview theme points at
    this one and every other page keeps its own. Returns the style name, or None if the
    layer has no style manager (then the caller must not pin anything).

    setCurrentStyle() snapshots the outgoing style off the live layer before switching,
    which is what makes the sequence below work: the edits land in `name` and are carried
    back out of the layer when we switch home.
    """
    if layer is None or (labels is None and scale is None):
        return None
    try:
        from qgis.core import QgsRenderContext
        sm = layer.styleManager()
        if sm is None:
            return None
        home = sm.currentStyle()
        if name in sm.styles():
            sm.removeStyle(name)
        if not sm.addStyleFromLayer(name):
            return None
        if not sm.setCurrentStyle(name):
            return None
        if labels is not None:
            layer.setLabelsEnabled(bool(labels))
        if scale:
            try:
                for sym in layer.renderer().symbols(QgsRenderContext()):
                    if hasattr(sym, "size") and hasattr(sym, "setSize"):
                        sym.setSize(max(0.2, float(sym.size()) * float(scale)))
            except Exception as e:
                print("overview marker scale err", layer.name(), e)
        sm.setCurrentStyle(home)          # writes the operator's own style back
        return name if name in sm.styles() else None
    except Exception as e:
        print("overview style err", getattr(layer, "name", lambda: "?")(), e)
        return None


def _overview_style_map(overview_layers):
    """{layer id: style name} of the overview-only style variants - erven without their erf
    numbers, and (declutter) shrunken pole/demand-point markers with the point + cable
    labels dropped. Everything not in the map renders exactly as the operator styled it.

    Polygons are never de-labelled here: the Plotting Grid IS a polygon and its cell numbers
    are the whole point of the overview page. `road` keeps its labels too - the street names
    are how a municipal reader locates the application on the ground.
    """
    out = {}
    by_role = _wl_layers_by_role([l for l in (overview_layers or []) if l is not None])
    if CFG.get("overview_hide_erven_labels"):
        for erv in by_role.get("erven", [])[:1]:
            st = _ensure_overview_style(erv, labels=False)
            if st:
                out[erv.id()] = st
            else:
                print("overview_hide_erven_labels: no labels-off style for", erv.name())
    if CFG.get("overview_declutter"):
        scale = float(CFG.get("overview_marker_scale") or 0.6)
        # Only the two roles that CARPET the page get smaller — the POP and the splitters
        # are what the reader is hunting for and keep full size. Roles, not name keywords:
        # the classifier already decided what each layer is.
        SHRINK_ROLES = ("pole", "demand")
        for role, layers in by_role.items():
            if role in ("erven", "obstacle", "boundary"):
                continue          # polygons keep their labels (the grid numbers live there)
            for l in layers:
                if l.id() in out:
                    continue
                st = _ensure_overview_style(
                    l, labels=False,
                    scale=(scale if role in SHRINK_ROLES else None))
                if st:
                    out[l.id()] = st
    return out


def _register_book_themes(overview_layers, detail_layers):
    """Two map themes the unified atlas map switches between per page: HLD_Overview
    (feeders + coverage + AOI + basemap) and HLD_Detail (full network)."""
    from qgis.core import QgsMapThemeCollection
    mtc = p.mapThemeCollection()

    # Overview-only style variants (erf numbers off, markers shrunk) - page 1 only.
    ov_styles = _overview_style_map(overview_layers)

    def rec(layers, overview=False):
        r = QgsMapThemeCollection.MapThemeRecord()
        for l in layers:
            if l is None:
                continue
            lr = QgsMapThemeCollection.MapThemeLayerRecord(l)
            try:
                lr.usingCurrentStyle = True
                # Pin every record to a style that EXISTS. A theme applies its record by
                # calling styleManager().setCurrentStyle(currentStyle), and that call is a
                # no-op for a name the layer does not have - so leaving this empty would
                # have left whichever style was applied last in force, i.e. the detail
                # pages inheriting the overview's labels-off style. Name the layer's own
                # current style instead, which is what every other page must render.
                lr.currentStyle = ((ov_styles.get(l.id()) if overview else None)
                                   or _current_style_name(l))
            except Exception:
                pass
            r.addLayerRecord(lr)
        return r

    ov_name, det_name = _theme_names()
    for nm in (ov_name, det_name):
        if mtc.hasMapTheme(nm):
            mtc.removeMapTheme(nm)
    mtc.insert(ov_name, rec(overview_layers, overview=True))
    mtc.insert(det_name, rec(detail_layers))
    return ov_name, det_name


def _max_span_m(g):
    """Longest vertex-to-vertex segment of a (multi)line in metres (CRS-aware geodesic)."""
    from qgis.core import QgsPointXY
    verts = [QgsPointXY(pt) for pt in g.vertices()]
    da = _dist_area()
    mx = 0.0
    for i in range(len(verts) - 1):
        try:
            d = da.measureLine(verts[i], verts[i + 1])
        except Exception:
            d = 0.0
        if d > mx:
            mx = d
    return mx


def _build_qa_layer():
    """'HLD Issues' overlay: cables whose longest span exceeds the configured limit,
    as a thick-red memory line layer added on top of the map. Returns (layer, count)."""
    limits = CFG.get("qa_span_limits") or {}
    if not CFG.get("hld_qa_overlay") or not limits:
        return None, 0
    from qgis.core import (QgsVectorLayer, QgsField, QgsFeature, QgsLineSymbol,
                           QgsSingleSymbolRenderer)
    name = "HLD Issues"
    for l in list(p.mapLayers().values()):
        if l.name() == name:
            p.removeMapLayer(l.id())
    vl = dp = None
    feats = []
    for role, lim in limits.items():
        lyr = _role(role)
        if lyr is None:
            continue
        if vl is None:
            vl = QgsVectorLayer(f"LineString?crs={lyr.crs().authid()}", name, "memory")
            dp = vl.dataProvider()
            dp.addAttributes([QgsField("issue", QMetaType.Type.QString),
                              QgsField("role", QMetaType.Type.QString),
                              QgsField("span_m", QMetaType.Type.Double)])
            vl.updateFields()
        for f in lyr.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            span = _max_span_m(g)
            if span > lim:
                nf = QgsFeature(vl.fields())
                nf.setGeometry(g)
                nf.setAttribute("issue", "over-span")
                nf.setAttribute("role", role)
                nf.setAttribute("span_m", round(span, 1))
                feats.append(nf)
    if vl is None or not feats:
        return None, 0
    dp.addFeatures(feats)
    vl.updateExtents()
    # bold red (a white casing beneath makes it pop on red-hued zones too)
    sym = QgsLineSymbol.createSimple({"color": "#dc0000", "width": "1.0",
                                      "capstyle": "round"})
    try:
        from qgis.core import QgsSimpleLineSymbolLayer
        from qgis.PyQt.QtGui import QColor
        casing = QgsSimpleLineSymbolLayer(QColor(255, 255, 255))
        casing.setWidth(1.9)
        sym.insertSymbolLayer(0, casing)          # white casing UNDER the red core
    except Exception:
        pass
    vl.setRenderer(QgsSingleSymbolRenderer(sym))
    p.addMapLayer(vl, False)
    return vl, len(feats)


def build_unified_atlas():
    """ONE atlas book: page 1 = overview (whole project, feeders + PON only), then one
    detail page per unit (full network). Flip overview -> PONs in a single editable layout;
    export gives the same book. The map switches map-theme per page (data-defined)."""
    from qgis.core import (QgsProperty, QgsLayoutObject, QgsLayoutItemMap)
    lm = p.layoutManager()
    for nm in (CFG["layout_report"], CFG["layout_overview"], CFG["layout_atlas"]):
        ex = lm.layoutByName(nm)
        if ex is not None:
            lm.removeLayout(ex)
    ov_set, det_set, all_set = _book_layer_sets()
    qa_layer, qa_n = _build_qa_layer()            # P2 QA overlay (config-gated)
    if qa_layer is not None:
        det_set = [qa_layer] + det_set            # draw violations on top of detail pages
        all_set = [qa_layer] + all_set
        print("HLD QA overlay: %d over-span cables flagged" % qa_n)
    _register_book_themes(ov_set, det_set)
    cover = _build_book_coverage()
    if cover is None:
        # no per-page coverage AND no polygon fallback -> a clear, actionable error beats an
        # AttributeError deep in _make_overview (build_report needs coverage too).
        raise ValueError(
            "HLD atlas: no per-page coverage layer found. Pick the PON/Zone polygon under "
            "“Each page shows”, or add a coverage polygon to the project.")
    # per-page title: page 1 = overview, else the per-unit heading.
    proj = str(CFG["project_name"]).replace("'", "''")
    if CFG.get("frame_style") == "wayleave":
        # wayleave: overview shows "Wayleave Application", tiles show no heading; the page
        # number lives in the corner box ("Page Overview" / "Page N of M").
        CFG["title_atlas_expr"] = ("[% if(attribute(@atlas_feature,'is_overview')=1,"
                                   "'Wayleave Application','') %]")
        CFG["page_label_expr"] = ("[% if(attribute(@atlas_feature,'is_overview')=1,'Page Overview',"
                                  "'Page ' || attribute(@atlas_feature,'seq') || ' of ' || "
                                  "(@atlas_totalfeatures - 1)) %]")
    else:
        prefix = str(CFG.get("title_atlas_expr", f"{CFG['project_name']} - PON ")).split("[%")[0]
        prefix = prefix.replace("'", "''")
        CFG["title_atlas_expr"] = (f"[% if(\"is_overview\"=1, '{proj} Overview', "
                                   f"'{prefix}' || \"unit\") %]")
    layout = new_layout(CFG["layout_atlas"])
    MAP = build_frame(layout, CFG["title_atlas_expr"], map_layers=det_set, drawn=all_set)
    make_map(layout, MAP, all_set, atlas_driven=True, margin=float(CFG["atlas_margin"]))
    m = next((it for it in layout.items() if isinstance(it, QgsLayoutItemMap)), None)
    if m is not None:
        # This binding is the ONLY thing keeping the overview-only layers (the phase
        # boundary polygons) off the detail pages: make_map() gave the map item the UNION
        # of both layer sets, and the per-page theme is what narrows it. If the binding is
        # missing the map renders that union — boundary fills over the whole network — and
        # every downstream check that reads the theme record still passes. So a phase book
        # sets require_theme_binding and we prove the binding took, or refuse to build.
        ov_theme, det_theme = _theme_names()
        try:
            m.setFollowVisibilityPreset(True)
            expr = (f"if(attribute(@atlas_feature,'is_overview')=1,"
                    f"'{ov_theme}','{det_theme}')")
            m.dataDefinedProperties().setProperty(
                QgsLayoutObject.DataDefinedProperty.MapStylePreset,
                QgsProperty.fromExpression(expr))
        except Exception as e:
            if CFG.get("require_theme_binding") or CFG.get("require_theme_bound", True):
                raise RuntimeError(
                    "HLD atlas: could not bind the per-page map theme (%s). Detail pages "
                    "would render the phase boundary over the network." % e)
            print("book theme dd err", e)
        if CFG.get("require_theme_binding") or CFG.get("require_theme_bound", True):
            ok, why = _theme_binding_ok(m)
            if not ok:
                raise RuntimeError(
                    "HLD atlas: the per-page map theme did not bind (%s). Refusing to "
                    "build a book whose detail pages would show the phase boundary." % why)
    at = layout.atlas()
    at.setEnabled(True)
    at.setCoverageLayer(cover)
    at.setSortFeatures(True)
    at.setSortExpression('"seq"')
    at.setFilenameExpression("'page_' || \"seq\"")
    lm.addLayout(layout)
    return CFG["layout_atlas"]


def build_page_layouts():
    """Build the overview + detail as standalone, PAGE-VIEW print layouts in the Layout
    Manager (WYSIWYG editing — you see + tweak each page immediately). The detail is a
    normal atlas: one page per coverage feature. Used by 'Open in Print Layout'."""
    lm = p.layoutManager()
    for nm in (CFG["layout_report"], CFG["layout_overview"], CFG["layout_atlas"]):
        ex = lm.layoutByName(nm)
        if ex is not None:
            lm.removeLayout(ex)
    overview = _make_overview()
    lm.addLayout(overview)
    detail = _make_detail()
    cov = _role("coverage")
    at = detail.atlas()
    at.setEnabled(True)
    at.setCoverageLayer(cov)
    at.setHideCoverage(bool(CFG.get("hide_coverage", False)))
    at.setSortFeatures(True)
    at.setSortExpression('"' + CFG["coverage_sort_field"] + '"')
    at.setFilenameExpression(CFG.get("atlas_filename_expr") or ('"' + CFG["coverage_sort_field"] + '"'))
    lm.addLayout(detail)
    return CFG["layout_overview"], CFG["layout_atlas"]


def _qa_strip_html(t):
    import re
    return re.sub(r"<[^>]+>", " ", t or "").replace("&nbsp;", " ").replace("&amp;", "&")


def _qa_desc(it):
    tn = type(it).__name__.replace("QgsLayoutItem", "")
    try:
        from qgis.core import QgsLayoutItemPicture, QgsLayoutItemLabel
        if isinstance(it, QgsLayoutItemPicture):
            return "%s(%s)" % (tn, os.path.basename(it.picturePath() or ""))
        if isinstance(it, QgsLayoutItemLabel):
            return "%s(%s)" % (tn, _qa_strip_html(it.text() or "")[:24].strip())
    except Exception:
        pass
    return tn


def _layout_qa(layout):
    """PERFECT-RENDER self-check. Returns (hard, soft): hard = must-not-ship problems,
    soft = warnings. Frame-agnostic — works on ANY built layout (HLD atlas / commercial /
    wayleave, any client). Checks: item overlap (excl. the map + legitimate label-in-frame),
    items off the page, map has layers + a non-empty extent, legend rendered, and static-text
    integrity (empty / None / nan). Atlas-expression labels ([% … %]) are evaluated per page,
    so they're skipped here and covered by the post-render pixel check."""
    from qgis.core import (QgsLayoutItemMap, QgsLayoutItemLabel, QgsLayoutItemPicture,
                           QgsLayoutItemShape, QgsLayoutItemPage)
    hard, soft = [], []
    items = [it for it in layout.items()
             if hasattr(it, "sceneBoundingRect")
             and (it.sceneBoundingRect().width() > 0.1 or it.sceneBoundingRect().height() > 0.1)]
    try:
        pg = layout.pageCollection().page(0)
        pr = pg.sceneBoundingRect() if pg else None
    except Exception:
        pr = None

    def rct(it):
        r = it.sceneBoundingRect()
        return (r.x(), r.y(), r.x() + r.width(), r.y() + r.height())

    def is_bg(it):
        # background / structural items that legitimately sit under or around content:
        # shapes (table cells, panel backgrounds, the border), the page item, and the
        # scene's page-boundary rect. Frame-agnostic (works for A3 HLD and A4 wayleave).
        if isinstance(it, (QgsLayoutItemShape, QgsLayoutItemPage)):
            return True
        return type(it).__name__ in ("QgsLayoutItemPage", "QGraphicsRectItem")

    # FOREGROUND content only: a bad layout is two pieces of content colliding (logo on the
    # title text, a summary box on the title block). Overlaps that INVOLVE a background shape
    # or the page are legitimate by design (labels sit inside their cells) -> never flagged.
    fg = [it for it in items if not isinstance(it, QgsLayoutItemMap) and not is_bg(it)]
    # 1) overlaps (foreground vs foreground only)
    for i in range(len(fg)):
        for j in range(i + 1, len(fg)):
            a, b = rct(fg[i]), rct(fg[j])
            ix = max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
            iy = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
            if ix * iy <= 1.5:
                continue
            hard.append("overlap %.0fx%.0fmm: %s <-> %s"
                        % (ix, iy, _qa_desc(fg[i]), _qa_desc(fg[j])))
    # 2) off the page (foreground content only)
    if pr is not None:
        for it in fg:
            r = it.sceneBoundingRect()
            if (r.x() < pr.x() - 1.0 or r.y() < pr.y() - 1.0
                    or r.x() + r.width() > pr.x() + pr.width() + 1.0
                    or r.y() + r.height() > pr.y() + pr.height() + 1.0):
                hard.append("off-page: %s" % _qa_desc(it))
    # 3) map validity
    maps = [it for it in items if isinstance(it, QgsLayoutItemMap)]
    if not maps:
        hard.append("no map item on the page")
    for m in maps:
        try:
            if not m.layers() and not m.followVisibilityPreset():
                hard.append("map has no layers")
            drv = False
            try:
                drv = m.atlasDriven()
            except Exception:
                drv = False
            if not drv:                       # atlas maps get their extent per-feature at render
                ext = m.extent()
                if ext is None or ext.isEmpty() or ext.width() <= 0:
                    hard.append("map extent is empty")
        except Exception as e:
            soft.append("map check error: %s" % e)
    # 4) legend rendered (picture file present + non-empty)
    for it in items:
        if isinstance(it, QgsLayoutItemPicture):
            pth = it.picturePath() or ""
            if "legend" in os.path.basename(pth).lower():
                if not (os.path.exists(pth) and os.path.getsize(pth) > 0):
                    hard.append("legend image missing/empty")
    # 5) static-text integrity (skip atlas templates)
    for it in items:
        if isinstance(it, QgsLayoutItemLabel):
            try:
                t = it.text() or ""
            except Exception:
                t = ""
            if "[%" in t:
                continue
            plain = _qa_strip_html(t).strip()
            if plain.lower() in ("", "none", "nan", "null"):
                soft.append("empty/placeholder label")
    return hard, soft


def build_all():
    """Style the layers + build the Report (safe on the GUI thread; no-op headless)."""
    try:
        from qgis.utils import iface as _iface
        _canvas = _iface.mapCanvas() if _iface else None
    except Exception:
        _canvas = None
    if _canvas is not None:
        _canvas.setRenderFlag(False)
    try:
        # ── GRID MODE: auto-tile the AOI, switch coverage to the grid (one page per cell) ──
        grid_mode = float(CFG.get("grid_cell_w_m") or 0.0) > 0.0
        if grid_mode:
            grid = _generate_grid()
            if grid is None:
                grid_mode = False                     # couldn't build (no AOI) -> normal coverage
            else:
                CFG["roles"] = dict(CFG.get("roles", {}))
                CFG["roles"]["coverage"] = [grid.name()]
                CFG["coverage_sort_field"] = "cell_no"
                CFG["coverage_label_field"] = "cell_no"
                CFG["hide_coverage"] = True
                CFG["atlas_filename_expr"] = "'grid_' || \"cell_no\""
                _wayleave = CFG.get("frame_style") == "wayleave"
                if not _wayleave:
                    # wayleave shows NO per-page heading (its preset sets title_atlas_expr="")
                    CFG["title_atlas_expr"] = f'{CFG["project_name"]} - Grid [% "cell_no" %]'
                # grid overview = the NUMBERED grid + network + boundary + basemap.
                # wayleave shows the full network (span/poles/erven/pop); HLD/commercial
                # show the feeder routes only (PON zones would clutter the numbered grid).
                ov = [grid.name()]
                if CFG.get("hld_layers"):
                    # operator hand-picked the layers -> numbered grid + exactly those
                    for _l in _resolve_layer_list(CFG["hld_layers"]):
                        ov.append(_l.name())
                elif _wayleave:
                    for _l in _p2_visible_layers(exclude={grid.name()}):
                        ov.append(_l.name())
                else:
                    for _r in ("primary", "secondary"):
                        _l = _role(_r)
                        if _l:
                            ov.append(_l.name())
                for _n in (CFG["aoi_layer"], CFG["basemap"]):
                    _l = _lyr(_n)
                    if _l:
                        ov.append(_l.name())
                CFG["overview_layers"] = ov

        # ── LAYER STYLING — OPT-IN ONLY (CFG["restyle_layers"], default False) ──
        # Every helper here calls setRenderer()/setLabeling() on the operator's live
        # layers and destroys the styling they had set up. Default is to touch nothing
        # and render the project exactly as it stands.
        _restyle = bool(CFG.get("restyle_layers"))
        _did_commercial = False
        if _restyle:
            if CFG.get("frame_style") == "commercial":
                _style_commercial()
                _did_commercial = True
            elif CFG.get("frame_style") == "wayleave":
                # ORDER MATTERS. _style_labels() rebuilds each role's labelling from
                # CFG["labels"] and ends every one with setLabelsEnabled(True) — run after
                # _style_wayleave() it silently switched the pole, cable and splitter
                # numbering back on, so the wayleave label policy had no effect at all and
                # the sheet still shipped covered in our own numbering. Base first, then
                # the wayleave policy, which gets the last word.
                _style_labels()                       # base HLD label config
                _style_wayleave()                     # wayleave look + label policy
            else:
                _style_hld_cables()                   # optional tiered cable style (config-gated)
                _style_enclosures()
                _style_pon()
                _style_labels()
        if grid_mode and not _did_commercial:
            # The grid is a layer THIS engine generated seconds ago (coverage was
            # repointed at it above), never one of the operator's — numbering its
            # cells is what makes the overview readable and owns nothing of theirs.
            _style_commercial()
        if CFG.get("frame_style") == "commercial":
            # commercial keeps the report-or-page-layouts flow.
            if CFG.get("build_mode") == "layouts":
                res = build_page_layouts()
                print("BUILT PAGE LAYOUTS:", res)
            else:
                res = build_report()
                print("BUILT REPORT:", res)
        else:
            # standard HLD *and* grid: ONE book atlas — overview page 1 (grid = numbered grid,
            # else feeders + PON) then flip -> every detail page. Serves editing + export.
            res = build_unified_atlas()
            print("BUILT UNIFIED ATLAS:", res, "| grid:", grid_mode)
        return res
    finally:
        if _canvas is not None:
            try:
                _ext = _greenfield_extent()
                if _ext is not None:
                    _ext.scale(1.1); _canvas.setExtent(_ext)
            except Exception:
                pass
            _canvas.setRenderFlag(True)


def build():
    """Explicit entry point - the supported way to run a build.

    Takes no arguments by design. Configuration still arrives the way it always
    has: seed `HLD_CFG` in the namespace BEFORE exec()'ing this file, which the
    module-level merge at :284 applies.

    An earlier draft of A2 accepted `build(cfg)` and re-merged CFG here. That was
    withdrawn: module-level values derived from CFG at load time - NORTH_SVG
    (:555) and LOGO (:556) - are NOT recomputed, so a cfg passed here would be
    silently ignored for those keys. Rather than ship an argument no caller used
    and no test covered, config-by-argument is left to Plan A item A4, which has
    to solve the load-time-derived-value problem properly.

    Returns whatever build_all() returns.
    """
    return build_all()


# Loading this file no longer builds a book.
#
# It used to end in a bare `build_all()`, so exec()'ing the file WAS the calling
# convention: there was no way to read the code, inspect CFG or call one helper
# without running a full build first - and a full build removes every layer,
# layout and map theme whose name matches ours before it creates anything.
# Callers now exec the file and then call build() explicitly.
#
# Set HLD_AUTORUN = True in the namespace before exec() to get the old drop-in
# behaviour back (e.g. pasting this file straight into the QGIS Python console).
if globals().get("HLD_AUTORUN", False):
    build()
else:
    print("hld_atlas_engine loaded - no build ran. Call build(), or set "
          "HLD_AUTORUN = True before exec() for the old drop-in behaviour.")
