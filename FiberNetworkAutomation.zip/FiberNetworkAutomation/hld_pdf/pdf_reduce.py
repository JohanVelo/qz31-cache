# -*- coding: utf-8 -*-
# Shrink an exported atlas PDF while holding its look (JJ 2026-09-28: level A, one file,
# every atlas PDF writer).
#
# Why the atlas PDFs are big: QGIS rasterises each page's map into ONE large JPEG
# (3803x3106 on a 300 dpi A3 page) at ~q96 with no chroma subsampling. That is ~95% of
# the file. Measured on the 195 MB Ventersdorp atlas: re-encoding those images at q85
# 4:2:0, SAME pixel size, gives 109 MB in ~10 s with page-render SSIM 0.987-0.996.
#
# What this does NOT touch: text, vectors, fonts, bookmarks, metadata, page labels —
# only the bytes of big DCT image streams are swapped, everything else is copied as-is.
#
# Safety rules:
#   * never raises — every failure returns {"ok": False, ...} and the input is untouched
#   * per image: keep the original bytes unless the new ones are smaller AND their SSIM
#     against the original is >= the floor AND the image is not already at/below target
#   * the result is written to a sibling temp, verified (pages, outline, metadata,
#     page labels, smaller), and only then atomically replaced onto the input path
#   * kill switch: VF_NO_PDF_REDUCE=1, or QSettings VelocityNexus/pdf_reduce = "off"
#
# Pure Python (pypdf + Pillow + numpy, all bundled with QGIS 4.2) and no Qt objects,
# so it is safe to run on a worker thread or inside the headless hld_generate process.
# The one exception, reduce_on_gui_thread(), imports Qt lazily just to pump events.
import io
import os
import time

DEFAULT_QUALITY = 85        # JPEG quality for re-encoded map images (level A)
DEFAULT_SSIM_FLOOR = 0.96   # per-image luma SSIM below this -> keep the original bytes
DEFAULT_MIN_SIDE = 1000     # images whose longer side is smaller are left alone (logos)

_SETTINGS_KEY = "VelocityNexus/pdf_reduce"


def enabled():
    """False when switched off by env var or QSettings. Headless/no-Qt -> env var only."""
    if os.environ.get("VF_NO_PDF_REDUCE", "").strip() not in ("", "0"):
        return False
    try:
        from qgis.PyQt.QtCore import QSettings
        val = QSettings().value(_SETTINGS_KEY, "on")
        return str(val).strip().lower() not in ("off", "0", "false", "no")
    except Exception:
        return True


def ssim_luma(a, b, row_step=2):
    """Mean SSIM over 8x8 luma blocks (the same measure the plan's numbers use).
    `row_step` samples every n-th row of blocks: on a 3803x3106 map image that is still
    ~92k blocks, the mean moves <0.001, and it halves the cost."""
    import numpy as np
    ya = np.asarray(a.convert("L"), dtype=np.float32)
    yb = np.asarray(b.convert("L"), dtype=np.float32)
    h, w = ya.shape
    h -= h % 8
    w -= w % 8
    if h == 0 or w == 0:
        return 1.0
    A = ya[:h, :w].reshape(h // 8, 8, w // 8, 8)[::row_step]
    B = yb[:h, :w].reshape(h // 8, 8, w // 8, 8)[::row_step]
    ma, mb = A.mean((1, 3)), B.mean((1, 3))
    va = (A * A).mean((1, 3)) - ma * ma
    vb = (B * B).mean((1, 3)) - mb * mb
    cov = (A * B).mean((1, 3)) - ma * mb
    c1, c2 = (0.01 * 255) ** 2, (0.03 * 255) ** 2
    s = ((2 * ma * mb + c1) * (2 * cov + c2)) / ((ma * ma + mb * mb + c1) * (va + vb + c2))
    return float(s.mean())


_TARGET_QSUM = {}


def _target_luma_qsum(quality):
    """Sum of the luma quantisation table Pillow uses at `quality` (bigger = coarser)."""
    if quality not in _TARGET_QSUM:
        from PIL import Image
        buf = io.BytesIO()
        Image.new("L", (16, 16)).save(buf, "JPEG", quality=quality)
        buf.seek(0)
        _TARGET_QSUM[quality] = sum(Image.open(buf).quantization[0])
    return _TARGET_QSUM[quality]


def _candidate(obj, min_side):
    """True if `obj` is an image stream this module knows how to re-encode exactly."""
    try:
        if obj.get("/Subtype") != "/Image" or obj.get("/Filter") != "/DCTDecode":
            return False
        if int(obj.get("/BitsPerComponent", 8)) != 8:
            return False
        if "/Decode" in obj or "/ImageMask" in obj:
            return False
        cs = obj.get("/ColorSpace")
        cs = cs.get_object() if hasattr(cs, "get_object") else cs
        if cs not in ("/DeviceRGB", "/DeviceGray"):
            return False
        return max(int(obj.get("/Width", 0)), int(obj.get("/Height", 0))) >= min_side
    except Exception:
        return False


def _iter_images(writer):
    """Yield each distinct image XObject used by the pages (page and nested Form XObjects)."""
    from pypdf.generic import IndirectObject
    seen = set()
    stack = []
    for page in writer.pages:
        res = page.get("/Resources")
        if res is not None:
            stack.append(res)
    while stack:
        res = stack.pop()
        res = res.get_object() if hasattr(res, "get_object") else res
        xo = res.get("/XObject") if hasattr(res, "get") else None
        xo = xo.get_object() if hasattr(xo, "get_object") else xo
        if not xo:
            continue
        for ref in xo.values():
            key = (ref.idnum, ref.generation) if isinstance(ref, IndirectObject) else id(ref)
            if key in seen:
                continue
            seen.add(key)
            obj = ref.get_object()
            sub = obj.get("/Subtype")
            if sub == "/Image":
                yield obj
            elif sub == "/Form" and obj.get("/Resources") is not None:
                stack.append(obj.get("/Resources"))


def _recode(raw, quality, ssim_floor):
    """(new JPEG bytes, ssim) for one image stream, or (None, reason) to keep the original.
    Pure bytes in / bytes out so it can run on a worker thread."""
    from PIL import Image
    if not raw.startswith(b"\xff\xd8"):
        return None, "not-jpeg"
    src = Image.open(io.BytesIO(raw))
    if src.mode not in ("RGB", "L"):
        return None, f"mode-{src.mode}"
    q = getattr(src, "quantization", None) or {}
    if q and sum(q[0]) >= _target_luma_qsum(quality):
        return None, "already-reduced"
    src.load()
    buf = io.BytesIO()
    save_kw = {"quality": quality, "optimize": True}
    if src.mode == "RGB":
        save_kw["subsampling"] = 2          # 4:2:0
    src.save(buf, "JPEG", **save_kw)
    new = buf.getvalue()
    if len(new) >= len(raw):
        return None, "not-smaller"
    s = ssim_luma(src, Image.open(io.BytesIO(new)))
    if s < ssim_floor:
        return None, f"ssim-{s:.4f}"
    return new, s


def _outline_count(reader):
    def walk(items):
        n = 0
        for it in items:
            n += walk(it) if isinstance(it, list) else 1
        return n
    try:
        return walk(reader.outline)
    except Exception:
        return -1


def _fingerprint(path):
    """What must be identical before/after: pages, outline, metadata, page labels."""
    from pypdf import PdfReader
    r = PdfReader(path)
    meta = {}
    try:
        meta = {str(k): str(v) for k, v in (r.metadata or {}).items()}
    except Exception:
        meta = {"?": "unreadable"}
    try:
        labels = list(r.page_labels)
    except Exception:
        labels = None
    return {"pages": len(r.pages), "outline": _outline_count(r), "meta": meta, "labels": labels}


def _safe_unlink(p):
    try:
        if os.path.exists(p):
            os.remove(p)
    except Exception:
        pass


def reduce_pdf_file(path, *, quality=DEFAULT_QUALITY, ssim_floor=DEFAULT_SSIM_FLOOR,
                    min_side=DEFAULT_MIN_SIDE, progress=None, cancel=None, force=False):
    """Shrink `path` IN PLACE. Returns a stats dict; never raises.

    progress(done, total) is called after each candidate image; cancel() -> True stops
    the run and leaves `path` untouched. `force` ignores the kill switch (tests)."""
    t0 = time.time()
    out = {"ok": False, "reduced": False, "path": path, "before": 0, "after": 0,
           "images": 0, "kept": 0, "reasons": {}, "reason": "", "secs": 0.0}

    def done(**kw):
        out.update(kw)
        out["secs"] = round(time.time() - t0, 2)
        return out

    tmp = path + ".reduce.tmp.pdf"
    try:
        out["before"] = out["after"] = os.path.getsize(path)
        if not force and not enabled():
            return done(ok=True, reason="switched off")
        try:
            import numpy  # noqa: F401
            from PIL import Image  # noqa: F401
            from pypdf import PdfWriter
        except Exception as e:
            return done(ok=True, reason=f"libraries missing ({e.__class__.__name__}: {e})")
        before_fp = _fingerprint(path)
        writer = PdfWriter(clone_from=path)
        from pypdf.generic import StreamObject
        cands = [o for o in _iter_images(writer) if _candidate(o, min_side)]
        total = len(cands)

        def work(raw):
            try:
                return _recode(raw, quality, ssim_floor)
            except Exception as e:
                return None, f"error-{e.__class__.__name__}"

        # Pillow and numpy release the GIL for decode / encode / array maths, so two
        # workers roughly halve the wall time. Two, not more: each in-flight map image
        # holds ~150 MB of pixels and teammates' laptops are not all 32 GB.
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=2) as pool:
            # pypdf objects stay on this thread; only the raw JPEG bytes go to a worker.
            futures = [(obj, pool.submit(work, obj.get_data())) for obj in cands]
            for i, (obj, fut) in enumerate(futures, 1):
                if cancel is not None and cancel():
                    for _o, f in futures:
                        f.cancel()
                    return done(ok=True, reason="cancelled")
                new, why = fut.result()
                if new:
                    StreamObject.set_data(obj, new)   # base setter: raw bytes, /Length on write
                    out["images"] += 1
                else:
                    out["kept"] += 1
                    key = str(why).split("-")[0]
                    out["reasons"][key] = out["reasons"].get(key, 0) + 1
                if progress is not None:
                    try:
                        progress(i, total)
                    except Exception:
                        pass
        if out["images"] == 0:
            return done(ok=True, reason="nothing to reduce")
        if cancel is not None and cancel():
            return done(ok=True, reason="cancelled")
        with open(tmp, "wb") as f:
            writer.write(f)
        after_fp = _fingerprint(tmp)
        if after_fp != before_fp:
            diff = [k for k in before_fp if before_fp[k] != after_fp.get(k)]
            _safe_unlink(tmp)
            return done(ok=True, reason=f"integrity check failed ({', '.join(diff)}) - kept original")
        new_size = os.path.getsize(tmp)
        if new_size >= out["before"]:
            _safe_unlink(tmp)
            return done(ok=True, reason="not smaller - kept original")
        os.replace(tmp, path)
        return done(ok=True, reduced=True, after=new_size, reason="reduced")
    except Exception as e:
        _safe_unlink(tmp)
        return done(ok=False, reason=f"{e.__class__.__name__}: {e}")


def reduce_on_gui_thread(path, *, on_tick=None, is_cancelled=None, **kw):
    """For callers ON the Qt GUI thread (the atlas export, the Design Report).

    Runs reduce_pdf_file on a worker thread and pumps Qt events until it finishes, so a
    ~15 s reduce can never trip Windows' hung-app kill (AppHangB1, 2026-08-26).
    on_tick(done, total) runs on the GUI thread between pumps; is_cancelled() -> True asks
    the worker to stop (the file is then left exactly as it was). Never raises."""
    import threading
    try:
        from qgis.PyQt.QtCore import QCoreApplication
        pump = QCoreApplication.processEvents
    except Exception:
        pump = None
    box, tick, stop = {}, {"i": 0, "n": 0}, {"flag": False}

    def _progress(i, n):
        tick["i"], tick["n"] = i, n

    def _target():
        box["r"] = reduce_pdf_file(path, progress=_progress,
                                   cancel=lambda: stop["flag"], **kw)

    worker = threading.Thread(target=_target, name="pdf_reduce", daemon=True)
    worker.start()
    while worker.is_alive():
        try:
            if pump is not None:
                pump()
            if is_cancelled is not None and is_cancelled():
                stop["flag"] = True
            if on_tick is not None:
                on_tick(tick["i"], tick["n"])
        except Exception:
            pass
        worker.join(0.05)
    return box.get("r") or {"ok": False, "reduced": False, "path": path,
                            "reason": "worker ended without a result"}


def summary(stats):
    """One line for a message bar: '195.5 -> 108.9 MB (-44%)' or why it was skipped."""
    mb = 1024 * 1024
    if stats.get("reduced"):
        b, a = stats["before"] / mb, stats["after"] / mb
        pct = 100 * (1 - stats["after"] / stats["before"]) if stats["before"] else 0
        return f"{b:.1f} -> {a:.1f} MB (-{pct:.0f}%)"
    return f"not reduced: {stats.get('reason') or 'unknown'}"
