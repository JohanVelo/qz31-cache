"""Phase 1 — building proposal with tunable sliders.

propose_buildings(img, transform_6, params, mode) -> GeoDataFrame(EPSG:3857) of building polygons.
  mode 'sam_auto'  : SAM2 automatic masks, filtered by sliders (the interactive engine)
  mode 'gob_batch' : load a prebuilt footprint GeoJSON (Google Open Buildings/Overture), area-filtered
Sliders (params dict): iou, stability, points_per_side, min_area, max_area, min_solidity, roof_colour_on

SAM2 model is loaded once and cached (0.58 GB on the 4 GB GPU — see NOTES.md Phase 0).
"""
from functools import lru_cache

import numpy as np
import cv2
import geopandas as gpd
from rasterio.transform import Affine
from shapely.geometry import Polygon

# torch + SAM2 are OPTIONAL — only the 'sam_auto' AI-detection mode needs them.
# Tuning, export and 'gob_batch' (prebuilt footprints) run with no AI/GPU, so the
# studio still launches and works on a laptop without torch installed.
try:
    import torch
    _HAVE_TORCH = True
except ImportError:
    torch = None
    _HAVE_TORCH = False

CKPT = "C:/Temp/sam2.1_hiera_tiny.pt"
CFG = "configs/sam2.1/sam2.1_hiera_t.yaml"
UTM = 32735


@lru_cache(maxsize=1)
def _sam2():
    from sam2.build_sam import build_sam2
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    return build_sam2(CFG, CKPT, device=dev), dev


def _roof_like(img, mask):
    """Cheap roof-colour gate (HSV): keep warm/grey roofs, reject green veg & deep shadow."""
    px = img[mask]
    if len(px) < 10:
        return False
    hsv = cv2.cvtColor(px.reshape(-1, 1, 3), cv2.COLOR_RGB2HSV).reshape(-1, 3)
    h, s, v = hsv[:, 0], hsv[:, 1], hsv[:, 2]
    green = ((h > 35) & (h < 90) & (s > 60)).mean()      # vegetation
    dark = (v < 40).mean()                                # shadow
    return green < 0.5 and dark < 0.6


def propose_buildings(img, transform_6, params, mode="sam_auto"):
    a, b, c, d, e, f = transform_6
    tr = Affine(a, b, c, d, e, f)
    p = {"iou": 0.7, "stability": 0.9, "points_per_side": 24, "min_area": 20.0,
         "max_area": 600.0, "min_solidity": 0.55, "roof_colour_on": True, **(params or {})}

    if mode == "gob_batch":
        gdf = gpd.read_file(params["source"]).to_crs(3857)
        am = gdf.to_crs(UTM).geometry.area
        gdf = gdf[(am >= p["min_area"]) & (am <= p["max_area"] * 50)].reset_index(drop=True)
        return gdf

    # sam_auto — AI detection, needs torch + SAM2 (GPU). Optional on a no-AI laptop.
    if not _HAVE_TORCH:
        raise RuntimeError(
            "AI building detection ('sam_auto') needs PyTorch + SAM2, which are not "
            "installed here. Use 'gob_batch' mode with a footprint GeoJSON instead, "
            "or run on a GPU machine with torch+sam2. Tuning and export work without AI.")
    from sam2.automatic_mask_generator import SAM2AutomaticMaskGenerator
    model, dev = _sam2()
    gen = SAM2AutomaticMaskGenerator(
        model, points_per_side=int(p["points_per_side"]),
        pred_iou_thresh=float(p["iou"]), stability_score_thresh=float(p["stability"]),
        min_mask_region_area=int(p["min_area"] / abs(a * e)) if a else 50,
    )
    autocast = (torch.autocast("cuda", dtype=torch.bfloat16) if dev == "cuda"
                else torch.autocast("cpu", dtype=torch.bfloat16))
    with torch.inference_mode(), autocast:
        masks = gen.generate(np.ascontiguousarray(img))

    px_m2 = abs(a * e)
    geoms = []
    for m in masks:
        seg = m["segmentation"].astype("uint8")
        area_m2 = int(seg.sum()) * px_m2
        if not (p["min_area"] <= area_m2 <= p["max_area"]):
            continue
        if p["roof_colour_on"] and not _roof_like(img, seg.astype(bool)):
            continue
        cnts, _ = cv2.findContours(seg, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            continue
        ct = max(cnts, key=cv2.contourArea)
        if len(ct) < 3:
            continue
        poly = Polygon([tr * (float(x) + 0.5, float(y) + 0.5) for x, y in ct.reshape(-1, 2)])
        if not poly.is_valid:
            poly = poly.buffer(0)
        if poly.is_empty:
            continue
        hull = poly.convex_hull.area
        if hull > 0 and poly.area / hull < p["min_solidity"]:   # reject ragged blobs
            continue
        geoms.append(poly)
    return gpd.GeoDataFrame(geometry=geoms, crs=3857)
