# Fibertime: Road Crossing Update Algorithm (MOA standard)

import math
import re

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProject,
    QgsGeometry,
    QgsSpatialIndex,
    QgsRectangle,
)
import processing


class FTRoadCrossingUpdateAlgorithm(QgsProcessingAlgorithm):
    """
    Full pole attribute refresh for road crossing update:
      0. Assign H-sequence labels to null poles
      1. Save current road crossing state
      2. FT1 — fill static fields
      3. FT7 — classify pole thickness (requires C:/Temp/roads.json)
      4. Restore manual road crossing corrections
      5. Force dim2=140-160mm for confirmed RC poles
      6. Re-run hardware assignment (type_2 / type_3)
      6b. Slack Brackets — every pole on a Distribution cable route
      7. Safety net lat/lon fill
      8. Verification report
    """

    def name(self):
        return 'ft_road_crossing_update'

    def displayName(self):
        return 'FT 8. Road Crossing Update'

    def group(self):
        return 'Fibertime Network Labeling'

    def groupId(self):
        return 'fibertimenetworklabeling'

    def shortHelpString(self):
        return (
            'Full pole attribute refresh after road crossing edits.\n\n'
            'Steps:\n'
            '  0. Label any null-label poles with H-sequence\n'
            '  1. Save current RC state (manual corrections)\n'
            '  2. FT1 — fill static fields\n'
            '  3. FT7 — classify thickness (needs C:/Temp/roads.json)\n'
            '  4. Restore manual RC corrections over FT7 output\n'
            '  5. Force dim2=140-160mm for all RC poles\n'
            '  6. Reassign hardware: Primary Feeder→Tangent, others→Dead-End (manual Tangent preserved)\n'
            '  6b. Slack Brackets: every pole on any Distribution Cable route\n'
            '  7. Safety net lat/lon fill\n'
            '  8. Verification — all ✅ before submitting\n\n'
            'Prerequisites: C:/Temp/roads.json must exist (run /roads first if missing).'
        )

    def initAlgorithm(self, config=None):
        pass   # No parameters — operates on the active project layers

    def processAlgorithm(self, parameters, context, feedback):
        import os
        try:
            from fibre_automation.shared.vf_paths import roads_json
            roads_path = roads_json()
        except Exception:
            roads_path = os.path.join(os.environ.get('VF_DATA_DIR', 'C:/Temp'), 'roads.json')
        if not os.path.exists(roads_path):
            raise QgsProcessingException(
                f'Road data not found at {roads_path}. Use the Velocity Nexus menu -> '
                'Tools to refresh road data first, or set VF_DATA_DIR to a folder '
                'that contains roads.json.')
        globals()['_RC_ROADS_PATH'] = roads_path

        proj = QgsProject.instance()
        lyr  = next(
            (l for l in proj.mapLayers().values() if 'poles v1' in l.name().lower()),
            None
        )
        if not lyr:
            raise QgsProcessingException('No "poles v1" layer found in this project.')

        flds = lyr.fields()
        def fi(n): return flds.indexOf(n)

        ti_label     = fi('Label')
        ti_thickness = fi('thickness_')
        ti_dim2      = fi('dim2')
        ti_lat       = fi('lat')
        ti_lon       = fi('lon')
        ti_t2  = fi('type_2');  ti_st2 = fi('subtype_2')
        ti_d2  = fi('dim1_2');  ti_sp2 = fi('spec_2')
        ti_t3  = fi('type_3');  ti_st3 = fi('subtype_3')
        ti_d3  = fi('dim1_3');  ti_sp3 = fi('spec_3')
        ti_fn1 = fi('featno1'); ti_fn2 = fi('featno2')
        ti_t4  = fi('type_4');  ti_st4 = fi('subtype4')
        ti_d4  = fi('dim1_4');  ti_sp4 = fi('spec_4')
        ti_t5  = fi('type_5');  ti_st5 = fi('subtype5')
        ti_sp5 = fi('spec_5');  ti_d5  = fi('dim1_5'); ti_dd5 = fi('dim2_5')
        ti_fn4 = fi('featno4')
        ti_t6  = fi('type_6');  ti_st6 = fi('subtype_6')
        ti_d6  = fi('dim1_6');  ti_sp6 = fi('spec_6'); ti_fn5 = fi('featno5')
        ti_t7  = fi('type_7');  ti_st7 = fi('subtype7')
        ti_d7  = fi('dim1_7');  ti_sp7 = fi('spec_7'); ti_fn6 = fi('featno6')
        ti_poletype = fi('Pole Type')

        # ── Step 0: Label null poles ──────────────────────────────────────────
        feedback.pushInfo('Step 0: Labelling null poles...')
        feedback.setProgress(0)
        max_h = 0
        for f in lyr.getFeatures():
            m = re.search(r'H(\d+)', str(f['Label']))
            if m:
                max_h = max(max_h, int(m.group(1)))
        null_ids = sorted(
            f.id() for f in lyr.getFeatures()
            if not f['Label'] or str(f['Label']).strip() in ('NULL', 'None', '')
        )
        if null_ids:
            lyr.dataProvider().changeAttributeValues(
                {fid: {ti_label: f'MOA.P.H{max_h + 1 + i}'}
                 for i, fid in enumerate(null_ids)}
            )
            feedback.pushInfo(f'  Assigned H{max_h+1}–H{max_h+len(null_ids)} to {len(null_ids)} poles')
        else:
            feedback.pushInfo('  No null poles — nothing to label')

        # ── Step 1: Save RC state ─────────────────────────────────────────────
        feedback.pushInfo('Step 1: Saving road crossing state...')
        feedback.setProgress(10)
        labeled_rc = set()
        labeled_not_rc = set()
        for f in lyr.getFeatures():
            lbl = str(f['Label'])
            if lbl and lbl not in ('NULL', 'None', ''):
                if 'road crossing' in str(f['thickness_']).lower():
                    labeled_rc.add(f.id())
                else:
                    labeled_not_rc.add(f.id())
        feedback.pushInfo(f'  {len(labeled_rc)} RC, {len(labeled_not_rc)} non-RC saved')
        has_manual_rc_state = len(labeled_rc) > 0

        # ── Step 2: FT1 ───────────────────────────────────────────────────────
        feedback.pushInfo('Step 2: FT1 — filling static fields...')
        feedback.setProgress(20)
        processing.run('fibernetwork:ft_label_poles', {'INPUT': lyr},
                       context=context, feedback=feedback)
        new_ids = {f.id() for f in lyr.getFeatures()
                   if f.id() not in labeled_rc and f.id() not in labeled_not_rc}
        feedback.pushInfo(f'  {len(new_ids)} new poles processed')

        # ── Step 3: FT7 ───────────────────────────────────────────────────────
        feedback.pushInfo('Step 3: FT7 — classifying pole thickness...')
        feedback.setProgress(35)
        processing.run('fibernetwork:ft_pole_thickness', {'INPUT': lyr},
                       context=context, feedback=feedback)
        feedback.pushInfo('  FT7 done.')

        # ── Step 4: Restore manual corrections ───────────────────────────────
        feedback.setProgress(50)
        if has_manual_rc_state:
            feedback.pushInfo('Step 4: Restoring manual corrections...')
            attr = {}
            for f in lyr.getFeatures():
                fid  = f.id()
                thick = str(f['thickness_']).strip()
                has_rc = 'road crossing' in thick.lower()
                if fid in new_ids:
                    continue
                if fid in labeled_rc and not has_rc:
                    new_val = (thick + '; road crossing') if thick not in ('', 'NULL', 'None') else 'road crossing'
                    attr[fid] = {ti_thickness: new_val}
                elif fid in labeled_not_rc and has_rc:
                    new_val = (thick
                               .replace('; road crossing', '')
                               .replace('road crossing; ', '')
                               .replace('road crossing', '')
                               .strip().strip(';').strip())
                    attr[fid] = {ti_thickness: new_val if new_val.lower() not in ('', 'null', 'none') else None}
            if attr:
                lyr.dataProvider().changeAttributeValues(attr)
            feedback.pushInfo(f'  Restored {len(attr)} corrections')
        else:
            feedback.pushInfo('Step 4: No prior RC state — trusting FT7 output directly.')

        # ── Step 5: dim2 upgrade for RC poles ─────────────────────────────────
        feedback.pushInfo('Step 5: Upgrading dim2 for RC poles...')
        feedback.setProgress(60)
        d = {
            f.id(): {ti_dim2: '140-160mm'}
            for f in lyr.getFeatures()
            if 'road crossing' in str(f['thickness_']).lower()
            and str(f['dim2']) != '140-160mm'
        }
        if d:
            lyr.dataProvider().changeAttributeValues(d)
        feedback.pushInfo(f'  Upgraded {len(d)} poles to 140-160mm')

        # ── Step 6: Hardware assignment ───────────────────────────────────────
        feedback.pushInfo('Step 6: Hardware assignment...')
        feedback.setProgress(70)
        # Per-cable direction counting (fixes 2026-04-17 H090 double-count bug).
        # A cable is counted ONCE per pole. Directions = number of sides the cable
        # leaves the NEAR zone to reach a vertex past EXIT_M.
        #   - NEAR zone vertices: candidate "at pole" vertices (snap tolerance)
        #   - EXIT zone: a cable side must reach a vertex past this distance to count
        #   - Pass-through with NO inside vertex: counted via perpendicular test + 2 ways
        M_DEG   = 111320.0
        NEAR_M  = 3.0     # vertex "at pole" (tight to avoid phantom zig-zag vertices)
        EXIT_M  = 5.0     # direction must reach past this to count as a real way

        # OD → (dead_end_dim, tangent_dim) per Master Material List 2026-05-28
        def _od_clamps(od_str):
            try: od = float(od_str.replace('mm','').replace(',','.').strip())
            except: return ('9,40-10,50mm', '10,10-10,80mm')
            if od <= 6.19:  return ('4,50-6,19mm',   '4,50-6,19mm')
            if od <= 10.5:  return ('9,40-10,50mm',  '10,10-10,80mm')
            if od <= 11.65: return ('10,54-11,65mm', '10,80-11,55mm')
            if od <= 12.9:  return ('11,70-12,90mm', '12,50-13,30mm')
            if od <= 17.27: return ('15,60-17,27mm', '15,11-16,00mm')
            return ('17,30-19,10mm', '17,9mm-19,0mm')

        # Build PF cable spatial index for per-pole OD lookup
        _pf_idx = QgsSpatialIndex()
        _pf_od  = {}
        _pf_geom = {}
        _pfc_lyrs = proj.mapLayersByName('Primary Cable v1')
        if _pfc_lyrs:
            for _cf in _pfc_lyrs[0].getFeatures():
                if _cf.geometry() and not _cf.geometry().isEmpty():
                    _pf_idx.addFeature(_cf)
                    _pf_od[_cf.id()]   = str(_cf['dim1'])
                    _pf_geom[_cf.id()] = _cf.geometry()

        _SNAP_DEG = 10.0 / M_DEG

        def _pole_pf_od(pt_geom):
            bbox = pt_geom.boundingBox(); bbox.grow(_SNAP_DEG * 5)
            best_od, best_d = None, 999.0
            for cid in _pf_idx.intersects(bbox):
                d = pt_geom.distance(_pf_geom[cid])
                if d < best_d:
                    best_d, best_od = d, _pf_od[cid]
            return best_od if best_d <= _SNAP_DEG * 3 else None

        # B2 fix 2026-04-28: cos(lat) correction so 3m east-west is actually 3m
        # at MOA latitude (~26.7°S). Without this, dx is over-counted by ~12% so
        # the effective east-west exclusion zone was ~2.7m instead of 3m.
        def _pole_d(pt, v):
            lat_rad = math.radians(pt.y())
            dx = (pt.x() - v.x()) * M_DEG * math.cos(lat_rad)
            dy = (pt.y() - v.y()) * M_DEG
            return math.sqrt(dx*dx + dy*dy)

        # AOI geometry for Tangent decision (Fibertime evaluator rule 2026-04-30):
        # outside-AOI = Tangent (long-haul), inside-AOI = Dead-End (clustered).
        aoi_geom = None
        aoi_layers = [l for l in proj.mapLayers().values() if 'aoi' in l.name().lower()]
        if aoi_layers:
            aoi_lyr = aoi_layers[0]
            ag = next(aoi_lyr.getFeatures(), None)
            if ag is not None:
                aoi_geom = ag.geometry()
                if aoi_lyr.crs() != lyr.crs():
                    from qgis.core import QgsCoordinateTransform
                    xform = QgsCoordinateTransform(aoi_lyr.crs(), lyr.crs(), proj)
                    aoi_geom = QgsGeometry(aoi_geom)
                    aoi_geom.transform(xform)

        feeder_lines = []  # [(cable_id, line_vertices)]
        for lname in ('Primary Cable v1', 'Secondary Cable v1', 'Distribution Cable v1'):
            ll = proj.mapLayersByName(lname)
            if not ll:
                continue
            for feat in ll[0].getFeatures():
                g = feat.geometry()
                if not g or g.isEmpty():
                    continue
                lines = g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]
                for line in lines:
                    if len(line) >= 2:
                        feeder_lines.append((f'{lname}:{feat.id()}', line))

        hw = {}
        for f in lyr.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            pt = g.asPoint()
            nconn = 0
            for _cid, line in feeder_lines:
                # Inside vertex indices (within NEAR_M)
                inside = [i for i, v in enumerate(line) if _pole_d(pt, v) < NEAR_M]
                if inside:
                    # Count directions reaching past EXIT_M on each side of the inside run
                    first, last = inside[0], inside[-1]
                    j = first - 1
                    while j >= 0:
                        if _pole_d(pt, line[j]) >= EXIT_M:
                            nconn += 1
                            break
                        j -= 1
                    j = last + 1
                    while j < len(line):
                        if _pole_d(pt, line[j]) >= EXIT_M:
                            nconn += 1
                            break
                        j += 1
                else:
                    # No vertex inside NEAR — check pass-through via any segment within NEAR_M
                    for i in range(len(line) - 1):
                        seg = QgsGeometry.fromPolylineXY([line[i], line[i+1]])
                        if g.distance(seg) * M_DEG < NEAR_M:
                            nconn += 2
                            break

            nconn = max(1, nconn)   # minimum 1Way (orphan default)

            # Tangent rule (Fibertime evaluator 2026-04-30): outside-AOI = long-haul Tangent;
            # inside-AOI = Dead-End regardless of Pole Type. Replaces the old PF-only rule.
            pole_type   = str(f['Pole Type']).strip() if ti_poletype >= 0 else ''
            is_outside_aoi = bool(aoi_geom) and (not aoi_geom.contains(g))

            # S6/S7 BandIt — all poles, always the same (Phase 1: 5393/5393)
            bandit_row = {
                ti_t6: 'Attachment', ti_st6: 'Strapping',
                ti_sp6: 'Grade304 BandIt', ti_d6: '19*0,5mm', ti_fn5: 4,
                ti_t7: 'Attachment', ti_st7: 'Buckle',
                ti_sp7: 'Grade304 BandIt', ti_d7: '19mm',    ti_fn6: 2,
            }

            hook_way = f'{nconn}Way'
            hook_dim = f'(R19*W12,50mm)*{nconn}'
            hook_row = {ti_t4: 'Hook', ti_st4: 'Offset Bracket', ti_sp4: hook_way, ti_d4: hook_dim}

            if is_outside_aoi:
                # Outside AOI: Tangent only, no Dead-End; minimum 2Way.
                # Tangent clamp size is OD-matched to the PF cable on this pole.
                tang_way = max(2, nconn)
                _pf_od_val = _pole_pf_od(g)
                _de_dim, _tang_dim = _od_clamps(_pf_od_val) if _pf_od_val else ('9,40-10,50mm', '10,10-10,80mm')
                hw[f.id()] = {
                    ti_t2:  None, ti_st2: None, ti_sp2: None, ti_d2: None, ti_fn1: None,
                    ti_t3:  'Tangent', ti_st3: 'ADSS',
                    ti_sp3: 'Galvanised Steel Wire/Nylon Sheave',
                    ti_d3:  _tang_dim,
                    ti_fn2: tang_way,
                    ti_t4: 'Hook', ti_st4: 'Offset Bracket',
                    ti_sp4: f'{tang_way}Way', ti_d4: f'(R19*W12,50mm)*{tang_way}',
                    **bandit_row,
                }
            elif pole_type == 'Primary Feeder':
                # PF pole inside AOI: Dead-End ADSS, OD-matched clamp.
                _pf_od_val = _pole_pf_od(g)
                _de_dim, _tang_dim = _od_clamps(_pf_od_val) if _pf_od_val else ('9,40-10,50mm', '10,10-10,80mm')
                row = {
                    ti_t2:  'Dead-End',
                    ti_st2: 'ADSS',
                    ti_sp2: 'Galvanised Steel Wire/Steel Thimble',
                    ti_d2:  _de_dim,
                    ti_fn1: nconn,
                    **hook_row,
                    **bandit_row,
                }
                hw[f.id()] = row
            else:
                # Distribution / Secondary Feeder inside AOI: Dead-End ADSS.
                # subtype=ADSS (Fibertime convention — mechanism type, not cable trade name).
                # 5,6mm cable OD → 4,50-6,19mm jaw. Tangent clamps are MANUAL.
                # B1 fix 2026-04-28: clear stale auto-Tangent if pole was reclassified from PF.
                row = {
                    ti_t2:  'Dead-End',
                    ti_st2: 'ADSS',
                    ti_sp2: 'Galvanised Steel Wire/Steel Thimble',
                    ti_d2:  '9,40-10,50mm',
                    ti_fn1: nconn,
                    **hook_row,
                    **bandit_row,
                }
                # Stale-Tangent detection: only the FT8 PF auto-write produces all 4 of:
                #   type_3=Tangent, subtype_3=ADSS, spec_3 includes 'Galvanised Steel',
                #   dim1_3='15,11-16,00mm'. If all match exactly, this is a stale FT8 leftover.
                cur_t3   = str(f['type_3']).strip()    if ti_t3 >= 0 else ''
                cur_st3  = str(f['subtype_3']).strip() if ti_st3 >= 0 else ''
                cur_sp3  = str(f['spec_3']).strip()    if ti_sp3 >= 0 else ''
                cur_d3   = str(f['dim1_3']).strip()    if ti_d3 >= 0 else ''
                if (cur_t3 == 'Tangent' and cur_st3 == 'ADSS'
                        and 'Galvanised Steel' in cur_sp3
                        and cur_d3 in ('15,11-16,00mm', '10,10-10,80mm')):
                    # Stale auto-Tangent from a prior PF run — clear it
                    row[ti_t3]  = None
                    row[ti_st3] = None
                    row[ti_sp3] = None
                    row[ti_d3]  = None
                    row[ti_fn2] = None
                hw[f.id()] = row
        if hw:
            lyr.dataProvider().changeAttributeValues(hw)  # claude:approved-destructive
        feedback.pushInfo(f'  Hardware updated for {len(hw)} poles')

        # ── Step 6b: Slack Brackets ───────────────────────────────────────────
        # Rule (verified against PH1 — 4438/4441 match): every pole that has a
        # Distribution cable running through it gets a Slack Bracket. Backbone
        # Primary/Secondary Feeder poles that carry no Distribution cable do not.
        # Spec: type_5=Slack Bracket, subtype5=Bracket, spec_5=Extreme Slack, dim1_5=D620, dim2_5=D516
        feedback.pushInfo('Step 6b: Assigning Slack Brackets (all poles on Distribution cable)...')
        feedback.setProgress(77)

        NEAR_DEG = NEAR_M / M_DEG  # conservative bbox expansion (~0.000027°)

        # Build spatial index and geometry map for poles
        pole_geoms = {}   # fid → QgsPointXY
        pole_index = QgsSpatialIndex()
        for f in lyr.getFeatures():
            g = f.geometry()
            if g and not g.isEmpty():
                pole_geoms[f.id()] = g.asPoint()
                pole_index.addFeature(f)

        # Mark every pole that any Distribution Cable vertex snaps to (within NEAR_M)
        slack_pole_ids = set()
        dist_ll = proj.mapLayersByName('Distribution Cable v1')
        if dist_ll:
            for cable_feat in dist_ll[0].getFeatures():
                cg = cable_feat.geometry()
                if not cg or cg.isEmpty():
                    continue
                lines = cg.asMultiPolyline() if cg.isMultipart() else [cg.asPolyline()]
                for line in lines:
                    for v in line:
                        bbox = QgsRectangle(
                            v.x() - NEAR_DEG, v.y() - NEAR_DEG,
                            v.x() + NEAR_DEG, v.y() + NEAR_DEG)
                        for fid in pole_index.intersects(bbox):
                            if fid not in slack_pole_ids and fid in pole_geoms:
                                if _pole_d(pole_geoms[fid], v) < NEAR_M:
                                    slack_pole_ids.add(fid)

        # Write: set for qualifying poles, clear for all others (clean slate)
        slack_vals = {
            ti_t5: 'Slack Bracket', ti_st5: 'Bracket',
            ti_sp5: 'Extreme Slack', ti_d5: 'D620', ti_dd5: 'D516', ti_fn4: 1,
        }
        clear_vals = {ti_t5: None, ti_st5: None, ti_sp5: None,
                      ti_d5: None, ti_dd5: None, ti_fn4: None}
        sb_attr = {
            fid: (slack_vals if fid in slack_pole_ids else clear_vals)
            for fid in pole_geoms
        }
        lyr.dataProvider().changeAttributeValues(sb_attr)  # claude:approved-destructive
        feedback.pushInfo(f'  Slack Brackets: {len(slack_pole_ids)} poles on Distribution Cable routes')

        # ── Step 7: lat/lon safety net ────────────────────────────────────────
        feedback.pushInfo('Step 7: Safety net lat/lon fill...')
        feedback.setProgress(88)
        latlon = {}
        for f in lyr.getFeatures():
            if str(f['lat']) in ('NULL', 'None', '') or str(f['lon']) in ('NULL', 'None', ''):
                g = f.geometry()
                if g and not g.isEmpty():
                    pt = g.asPoint()
                    latlon[f.id()] = {ti_lat: round(pt.y(), 6), ti_lon: round(pt.x(), 6)}
        if latlon:
            lyr.dataProvider().changeAttributeValues(latlon)
            feedback.pushInfo(f'  Filled lat/lon for {len(latlon)} poles')
        else:
            feedback.pushInfo('  All poles have lat/lon ✅')

        lyr.triggerRepaint()

        # ── Step 8: Verification ──────────────────────────────────────────────
        feedback.pushInfo('\n── Verification ─────────────────────────────────────')
        feedback.setProgress(95)
        total = lyr.featureCount()
        null_labels, null_latlon, null_dim2, null_hw, null_geom = [], [], [], [], []
        rc_count = mm_140 = mm_120 = tangent_ct = dead_end_ct = pf_count = slack_ct = 0
        NULLY = ('NULL', 'None', '')
        for f in lyr.getFeatures():  # single pass — was 14 separate scans
            lbl   = str(f['Label']).strip()
            lat   = str(f['lat'])
            lon   = str(f['lon'])
            dim2  = str(f['dim2']).strip()
            t2    = str(f['type_2']).strip()
            t3    = str(f['type_3']).strip()
            thick = str(f['thickness_']).lower()
            g     = f.geometry()
            if lbl in NULLY:                          null_labels.append(lbl)
            if lat in NULLY or lon in NULLY:          null_latlon.append(lbl)
            if dim2 in NULLY:                         null_dim2.append(lbl)
            # Tangent poles (PF auto + manual overrides on SF/Distribution) have NULL type_2
            if t2 in NULLY and t3 != 'Tangent':       null_hw.append(lbl)
            if not g or g.isEmpty():                  null_geom.append(lbl)
            if 'road crossing' in thick:              rc_count += 1
            if dim2 == '140-160mm':                   mm_140 += 1
            elif dim2 == '120-140mm':                 mm_120 += 1
            if t3 == 'Tangent':                       tangent_ct += 1
            if t2 == 'Dead-End':                      dead_end_ct += 1
            if ti_poletype >= 0 and str(f['Pole Type']).strip() == 'Primary Feeder':
                pf_count += 1
            if ti_t5 >= 0 and str(f['type_5']).strip() == 'Slack Bracket':
                slack_ct += 1

        def vstatus(lst, label):
            if lst:
                feedback.pushInfo(f'  ⚠  {label}: {len(lst)} — {lst[:5]}{"..." if len(lst) > 5 else ""}')
            else:
                feedback.pushInfo(f'  ✅ {label}: 0')

        feedback.pushInfo(f'  Total poles: {total}')
        vstatus(null_labels, 'Null labels')
        vstatus(null_latlon, 'Null lat/lon')
        vstatus(null_dim2,   'Null dim2')
        vstatus(null_hw,     'Null hardware (no Dead-End AND no Tangent)')
        vstatus(null_geom,   'Null geometry')
        feedback.pushInfo(f'  ✅ Road crossing poles: {rc_count}')
        feedback.pushInfo(f'  ✅ 140-160mm: {mm_140}')
        feedback.pushInfo(f'  ✅ 120-140mm: {mm_120}')
        feedback.pushInfo(f'  ✅ Tangent poles: {tangent_ct} (Primary Feeder: {pf_count})')
        feedback.pushInfo(f'  ✅ Dead-End poles: {dead_end_ct}')
        feedback.pushInfo(f'  ✅ Slack Brackets: {slack_ct}')

        issues = any([null_labels, null_latlon, null_dim2, null_hw, null_geom])
        if not issues:
            feedback.pushInfo('\n✅ All poles complete — no issues found.')
        else:
            feedback.reportError('\n⚠  Issues found — review above.', fatalError=False)

        feedback.setProgress(100)
        return {}

    def createInstance(self):
        return FTRoadCrossingUpdateAlgorithm()
