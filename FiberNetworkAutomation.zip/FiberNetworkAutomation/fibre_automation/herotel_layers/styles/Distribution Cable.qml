<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="4.2.0" styleCategories="Symbology|Labeling" labelsEnabled="0">
  <renderer-v2 referencescale="-1" forceraster="0" enableorderby="0" type="singleSymbol" symbollevels="0">
        <symbols>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="line" name="0" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleLine" pass="0" id="{7c24aa07-82c3-4ce0-84cd-f565eaa8c813}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="0" name="align_dash_pattern" />
                <Option type="QString" value="round" name="capstyle" />
                <Option type="QString" value="0.66;2" name="customdash" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" />
                <Option type="QString" value="MM" name="customdash_unit" />
                <Option type="QString" value="0" name="dash_pattern_offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" />
                <Option type="QString" value="MM" name="dash_pattern_offset_unit" />
                <Option type="QString" value="0" name="draw_inside_polygon" />
                <Option type="QString" value="round" name="joinstyle" />
                <Option type="QString" value="23,253,11,255,hsv:0.32458333333333333,0.95822079804684523,0.99237048905165182,1" name="line_color" />
                <Option type="QString" value="solid" name="line_style" />
                <Option type="QString" value="0.66" name="line_width" />
                <Option type="QString" value="MM" name="line_width_unit" />
                <Option type="QString" value="0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="0" name="ring_filter" />
                <Option type="QString" value="0" name="trim_distance_end" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" />
                <Option type="QString" value="MM" name="trim_distance_end_unit" />
                <Option type="QString" value="0" name="trim_distance_start" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" />
                <Option type="QString" value="MM" name="trim_distance_start_unit" />
                <Option type="QString" value="0" name="tweak_dash_pattern_on_corners" />
                <Option type="QString" value="0" name="use_custom_dash" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </symbols>
        <rotation />
        <sizescale />
        <data-defined-properties>
          <Option type="Map">
            <Option type="QString" value="" name="name" />
            <Option name="properties" />
            <Option type="QString" value="collection" name="type" />
          </Option>
        </data-defined-properties>
      </renderer-v2>
</qgis>
