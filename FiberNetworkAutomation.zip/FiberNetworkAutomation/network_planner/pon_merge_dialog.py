"""The PON list — how many units are in each PON, so the planner can decide.

Deliberately opinion-free. It shows counts and nothing else: no "too small"
badge, no suggested merge, no capacity rule. JJ was explicit — "people will
automatically calculate the amount of units they should be inside of a PON and
whether the PON should merge or not. Just show us the numbers of units."

Qt6-safe per the plugin's rules: imports go through the ``qgis.PyQt`` shim,
enums are fully scoped, and the dialog is ``WA_DeleteOnClose`` with every value
read BEFORE ``exec()``.
"""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from . import pon_merge, pon_merge_ux, pon_stats

_HEADERS = ["", "PON", "Units", "Splitters", "Name"]
_COL_TICK, _COL_PON, _COL_UNITS = 0, 1, 2


class PonListDialog(QDialog):
    """Read-only table of every PON with its counted unit total."""

    def __init__(self, project, parent=None, term="PON"):
        super().__init__(parent)
        self._project = project
        self._term = term or "PON"
        self.setWindowTitle(f"Merge {self._term}s")
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self.setMinimumSize(620, 540)
        self._rows = []
        self._build()
        self.reload()

    # ── construction ────────────────────────────────────────────────────────
    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(10)

        self._summary = QLabel("…")
        self._summary.setWordWrap(True)
        self._summary.setStyleSheet(
            "QLabel { background-color: #0e2233; color: #7fb2e5; "
            "border: 1px solid #2f5f88; border-left: 4px solid #2f5f88; "
            "border-radius: 4px; padding: 6px 8px; font-size: 9pt; }")
        root.addWidget(self._summary)

        self._table = QTableWidget(0, len(_HEADERS), self)
        self._table.setHorizontalHeaderLabels(_HEADERS)
        self._table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers)
        self._table.setAlternatingRowColors(True)
        self._table.setSortingEnabled(True)
        self._table.verticalHeader().setVisible(False)
        hh = self._table.horizontalHeader()
        for col in range(len(_HEADERS) - 1):
            hh.setSectionResizeMode(col, QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(len(_HEADERS) - 1, QHeaderView.ResizeMode.Stretch)
        root.addWidget(self._table, 1)

        # ── merge controls ──────────────────────────────────────────────
        pick = QHBoxLayout()
        pick.addWidget(QLabel("Tick the ones to merge, then merge them into:"))
        self._target = QComboBox()
        self._target.setMinimumWidth(110)
        self._target.setToolTip(
            f"The {self._term} that keeps its number. Everything ticked is "
            f"absorbed into it.")
        pick.addWidget(self._target)
        pick.addStretch(1)
        root.addLayout(pick)

        self._preview = QLabel("")
        self._preview.setWordWrap(True)
        self._preview.setVisible(False)
        self._preview.setStyleSheet(
            "QLabel { background-color: #1d2b1f; color: #a9dcb4; "
            "border: 1px solid #3c7a4c; border-left: 4px solid #3c7a4c; "
            "border-radius: 4px; padding: 6px 8px; font-size: 9pt; }")
        root.addWidget(self._preview)

        row = QHBoxLayout()
        self._btn_reload = QPushButton("↻ Refresh")
        self._btn_reload.setToolTip(
            "Re-count from the layers. The counts are read fresh every time — "
            "they are never taken from a cached value.")
        self._btn_reload.clicked.connect(self.reload)
        row.addWidget(self._btn_reload)

        self._btn_preview = QPushButton("👁 Preview merge")
        self._btn_preview.setToolTip(
            "Work out exactly what would change — without changing anything.")
        self._btn_preview.clicked.connect(self._on_preview)
        row.addWidget(self._btn_preview)

        self._btn_merge = QPushButton("⇔ Merge")
        self._btn_merge.setToolTip(
            "Reassign the ticked PONs into the target, fuse their boundaries, "
            "square the result and close the numbering gap.\n"
            "A backup is taken first — if it fails, nothing is written.")
        self._btn_merge.setStyleSheet(
            "QPushButton { background-color: #6b3a1c; color: #ffd9b8; "
            "font-weight: bold; border: 1px solid #a05a2c; border-radius: 4px; "
            "padding: 5px 10px; }"
            "QPushButton:hover { background-color: #8a4b24; }")
        self._btn_merge.clicked.connect(self._on_merge)
        row.addWidget(self._btn_merge)

        row.addStretch(1)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.rejected.connect(self.reject)
        row.addWidget(buttons)
        root.addLayout(row)

    # ── selection ───────────────────────────────────────────────────────────
    def _ticked_pons(self):
        """PONs the operator ticked, read off the table."""
        out = []
        for r in range(self._table.rowCount()):
            cell = self._table.item(r, _COL_TICK)
            if cell is None:
                continue
            if cell.checkState() == Qt.CheckState.Checked:
                pon_cell = self._table.item(r, _COL_PON)
                if pon_cell is not None:
                    out.append(pon_cell.data(Qt.ItemDataRole.DisplayRole))
        return out

    def _current_target(self):
        return self._target.currentData()

    def _build_plan(self):
        """(plan, error) for the current selection. Never raises."""
        sources = self._ticked_pons()
        target = self._current_target()
        if target is None:
            return None, f"Pick the {self._term} to merge into."
        sources = [s for s in sources if s != target]
        if not sources:
            return None, (f"Tick at least one {self._term} to merge — and it "
                          f"must be different from the target.")
        try:
            return pon_merge.plan(self._project, target, sources), None
        except Exception as exc:
            return None, f"Could not work out the merge: {exc}"

    def _on_preview(self):
        plan_obj, err = self._build_plan()
        if err:
            self._preview.setVisible(True)
            self._preview.setText(err)
            return
        self._preview.setVisible(True)
        try:
            self._preview.setText(
                pon_merge_ux.merge_preview_html(
                    pon_merge_ux.facts_from_plan(plan_obj)))
        except Exception:
            # a formatting slip must never hide the preview — fall back to plain text
            self._preview.setText(plan_obj.describe().replace("\n", "<br>"))

    def _on_merge(self):
        plan_obj, err = self._build_plan()
        if err:
            QMessageBox.information(self, f"Merge {self._term}s", err)
            return

        # Show exactly what will happen and make them confirm it. Everything the
        # dialog needs is read BEFORE any modal opens (WA_DeleteOnClose rule).
        try:
            detail = pon_merge_ux.merge_preview_html(
                pon_merge_ux.facts_from_plan(plan_obj))
        except Exception:
            detail = plan_obj.describe().replace("\n", "<br>")
        ans = QMessageBox.question(
            self, f"Merge {self._term}s",
            f"{detail}<br><br>A backup is taken first. Go ahead?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if ans != QMessageBox.StandardButton.Yes:
            return

        backup = self._take_backup()
        if not backup:
            QMessageBox.warning(
                self, f"Merge {self._term}s",
                "Nothing was merged — the backup could not be written, so the "
                "write was not attempted.")
            return

        log = []
        try:
            ok, msg = pon_merge.apply_plan(plan_obj, backup, feedback=log.append)
        except Exception as exc:
            QMessageBox.critical(
                self, f"Merge {self._term}s",
                f"The merge failed and stopped:\n{exc}\n\nBackup: {backup}")
            return

        if not ok:
            QMessageBox.warning(
                self, f"Merge {self._term}s",
                f"{msg}\n\nBackup: {backup}")
            return

        self.reload()
        QMessageBox.information(
            self, f"Merge {self._term}s",
            f"{msg}\n\n" + "\n".join(log) + f"\n\nBackup: {backup}")

    def _take_backup(self):
        """Snapshot every PON-carrying layer. Returns a path, or '' on failure.

        The merge refuses to run without this, so a silent failure here is a
        refusal to write — never a write without a net.
        """
        try:
            parent = self.parent()
            writer = getattr(parent, "_pon_write_renumber_backup", None)
            if writer is None:
                return ""
            layers = [lyr for lyr, _f in pon_merge._pon_layers(self._project)]
            if not layers:
                return ""
            ok, dest = writer(layers)
            return dest if ok else ""
        except Exception:
            return ""

    # ── data ────────────────────────────────────────────────────────────────
    def _num_item(self, value):
        """Right-aligned cell that sorts NUMERICALLY, not as text.

        Without the numeric role a click on 'Units' orders 100 before 99.
        """
        item = QTableWidgetItem()
        item.setData(Qt.ItemDataRole.DisplayRole, value)
        item.setTextAlignment(int(Qt.AlignmentFlag.AlignRight
                                 | Qt.AlignmentFlag.AlignVCenter))
        return item

    def reload(self):
        try:
            rows = pon_stats.collect(self._project)
        except Exception as exc:                       # never take the dock down
            self._summary.setText(f"Could not read the PONs: {exc}")
            self._table.setRowCount(0)
            return

        summary = pon_stats.summarise(rows)
        term = self._term
        text = (f"<b>{summary['pons']}</b> {term}s &nbsp;·&nbsp; "
                f"<b>{summary['units']}</b> units &nbsp;·&nbsp; "
                f"<b>{summary['splitters']}</b> splitters &nbsp;·&nbsp; "
                f"smallest <b>{summary['smallest']}</b>, "
                f"largest <b>{summary['largest']}</b>")
        if summary["stale"]:
            text += (f"<br><span style='color:#e0a458'>"
                     f"{summary['stale']} {term}(s) have a stale stored count — "
                     f"the numbers shown are counted live and are the correct "
                     f"ones.</span>")
        self._summary.setText(text)

        # Sorting must be off while filling or Qt re-sorts mid-insert and the
        # cells land in the wrong rows.
        self._table.setSortingEnabled(False)
        self._table.setRowCount(len(rows))
        stale_bg = QColor("#3a2d12")
        bold = QFont()
        bold.setBold(True)
        for r, row in enumerate(rows):
            tick = QTableWidgetItem()
            tick.setFlags(Qt.ItemFlag.ItemIsUserCheckable
                          | Qt.ItemFlag.ItemIsEnabled
                          | Qt.ItemFlag.ItemIsSelectable)
            tick.setCheckState(Qt.CheckState.Unchecked)
            tick.setToolTip(f"Tick to merge {self._term} {row.pon} into the target")
            self._table.setItem(r, _COL_TICK, tick)

            pon_item = QTableWidgetItem()
            pon_item.setData(Qt.ItemDataRole.DisplayRole, row.pon)
            pon_item.setFont(bold)
            self._table.setItem(r, _COL_PON, pon_item)
            self._table.setItem(r, _COL_UNITS, self._num_item(row.units))
            self._table.setItem(r, _COL_UNITS + 1, self._num_item(row.splitters))
            name_item = QTableWidgetItem(str(row.name) if row.name else "")
            self._table.setItem(r, _COL_UNITS + 2, name_item)
            if row.units_are_stale:
                tip = (f"Stored count says {row.stored_units}, actual is "
                       f"{row.units}. The actual number is shown.")
                for c in range(len(_HEADERS)):
                    cell = self._table.item(r, c)
                    cell.setBackground(stale_bg)
                    cell.setToolTip(tip)
        self._table.setSortingEnabled(True)
        # Re-enabling sorting makes Qt apply whatever sort indicator it already
        # had, which opened the list backwards (55, 54, 53...). Ask for PON
        # ascending explicitly so it always opens in the order people expect;
        # clicking a header still re-sorts normally afterwards.
        self._table.sortItems(_COL_PON, Qt.SortOrder.AscendingOrder)

        # Target dropdown — keep the operator's choice across a refresh.
        previous = self._target.currentData()
        self._target.blockSignals(True)
        self._target.clear()
        for row in rows:
            self._target.addItem(f"{self._term} {row.pon}  ({row.units} units)",
                                 row.pon)
        if previous is not None:
            i = self._target.findData(previous)
            if i >= 0:
                self._target.setCurrentIndex(i)
        self._target.blockSignals(False)
        self._preview.setVisible(False)


def open_pon_list(project, parent=None, term="PON"):
    """Show the PON list and merge tool."""
    dlg = PonListDialog(project, parent=parent, term=term)
    dlg.exec()
    return None
