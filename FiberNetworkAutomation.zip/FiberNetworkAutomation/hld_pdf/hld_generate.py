# -*- coding: utf-8 -*-
# ============================================================================
# HLD Generate  (Phase 3 — combined headless generator behind the Nexus button)
# ----------------------------------------------------------------------------
# ONE separate QGIS process (no canvas -> can never freeze the live session) that:
#   builds the two layouts -> saves an editable "*_HLD.qgz" copy (+ .qpt template)
#   -> exports overview + atlas -> merges to ONE verified PDF -> optional email copy.
#
# Runs via: <QGIS>/bin/python-qgis.bat hld_generate.py <config.json>
# All machine-specific paths come from the config (the plugin fills them in), so
# this is portable across teammates' installs.
#
# Config JSON:
#   {
#     "project":        "C:/.../working.qgz",          # source (read-only)
#     "output":         "C:/.../<name> HLD.pdf",        # the deliverable PDF
#     "output_project": "C:/.../<name> HLD.qgz",        # editable copy (optional)
#     "qpt_out":        "C:/.../hld_frame.qpt",         # frame template (optional)
#     "hld_cfg":        { ... engine overrides ... },
#     "extra_layers":   [ {"path","name","fill"} ],     # e.g. greenfield boundary
#     "dpi": 150, "compress": true,
#     "qgis_prefix": "...", "gs": "...", "engine": "...",  # filled by the plugin
#     "result":         "C:/.../result.json"
#   }
# result.json: {ok, stage, message, pages, output, email, output_project, size_mb, log}
#
# Contract: callers trust result.json's `ok` flag. (Exit code is clean too, but the
# flag is the signal — headless QGIS teardown is unreliable, so we os._exit.)
# ============================================================================
import os
import sys
import json
import shutil
import datetime
import subprocess
import traceback

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

_HERE = os.path.dirname(os.path.abspath(__file__))
_APP = None   # keep QgsApplication alive past return; its destructor segfaults headless
FONTS = ("arial.ttf", "arialbd.ttf", "ariali.ttf", "arialbi.ttf")
MIN_FREE_MB = 500
MIN_PDF_MB = 0.3

LOG = []
def log(msg):
    LOG.append(str(msg)); print(msg, flush=True)


def _write_result(path, obj):
    obj.setdefault("log", LOG)
    if not path:
        return
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, indent=2)
    except Exception as e:
        log(f"could not write result.json: {e}")


def fail(result_path, stage, message):
    _write_result(result_path, {"ok": False, "stage": stage, "message": message})
    log(f"FAIL [{stage}]: {message}")
    return 1


def _count_pdf_pages(pdf_path, gs):
    """Robust page count: Ghostscript pdfpagecount (compression-proof), regex fallback."""
    if gs and os.path.exists(gs):
        try:
            ps = pdf_path.replace("\\", "/")
            r = subprocess.run([gs, "-q", "-dNODISPLAY", "-dNOSAFER", "-c",
                                f"({ps}) (r) file runpdfbegin pdfpagecount = quit"],
                               capture_output=True, text=True, timeout=60)
            for line in (r.stdout or "").splitlines():
                if line.strip().isdigit():
                    return int(line.strip())
        except Exception:
            _swallowed_note()
    try:
        with open(pdf_path, "rb") as f:
            data = f.read()
    except Exception:
        return -1
    import re
    counts = [int(m) for m in re.findall(rb"/Type\s*/Pages\b[^>]*?/Count\s+(\d+)", data)]
    if not counts:
        counts = [int(m) for m in re.findall(rb"/Count\s+(\d+)[^>]*?/Type\s*/Pages\b", data)]
    if counts:
        return max(counts)
    return len(re.findall(rb"/Type\s*/Page(?![s])", data))


def _gs_run(gs, args, label):
    if not gs or not os.path.exists(gs):
        raise RuntimeError(f"Ghostscript not found: {gs}")
    r = subprocess.run([gs] + args, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"Ghostscript {label} failed: {r.stderr[-400:]}")


def _pixel_check(pdf_path, gs, pages, tmp):
    """Blank-MAP guard: rasterize a few pages and confirm the map area (left ~68% of the
    page — where the map sits in HLD / commercial / wayleave frames) actually has ink. A
    failed/empty map render would leave that region near-white. Uses QImage (no new deps).
    Returns a list of problem strings (empty = fine). Best-effort: any error -> skip that page."""
    from qgis.PyQt.QtGui import QImage
    issues = []
    for pno in pages:
        png = os.path.join(tmp, f"_pxchk_{pno}.png")
        try:
            _gs_run(gs, ["-dBATCH", "-dNOPAUSE", "-q", "-sDEVICE=png16m", "-r36",
                         f"-dFirstPage={pno}", f"-dLastPage={pno}", "-dUseCropBox",
                         f"-sOutputFile={png}", pdf_path], f"pxchk{pno}")
            img = QImage(png)
            if img.isNull() or img.width() < 8 or img.height() < 8:
                continue
            w, h = img.width(), img.height()
            x1 = int(w * 0.68)                       # map region = left portion of the page
            nonwhite = tot = 0
            for y in range(0, h, max(1, h // 150)):
                for x in range(0, x1, max(1, x1 // 150)):
                    c = img.pixel(x, y)
                    if ((c >> 16) & 255) < 244 or ((c >> 8) & 255) < 244 or (c & 255) < 244:
                        nonwhite += 1
                    tot += 1
            frac = (nonwhite / tot) if tot else 1.0
            if frac < 0.05:
                issues.append(f"page {pno} map area near-blank ({frac * 100:.1f}% ink)")
        except Exception as e:
            log(f"pixel-check page {pno} skipped: {e}")
    return issues


def _backup(path, suffix):
    if not os.path.exists(path):
        return
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    bak = f"{os.path.splitext(path)[0]}.{stamp}.bak{suffix}"
    try:
        shutil.copy2(path, bak); log(f"backup: {bak}")
    except Exception as e:
        log(f"backup failed (continuing): {e}")


# ── P3.1: PDF bookmarks (outline) + document metadata ───────────────────────
def _book_page_labels(proj, cov, eff, atlas_ok):
    """Ordered [(0-based page index, bookmark label)] matching the exported book's pages.
    Atlas path -> the 'HLD Book Pages' coverage (seq/is_overview/unit); report/fallback ->
    page 1 = overview then coverage features by the sort field. The unit word (PON/Zone/…)
    comes from the REAL coverage layer's name, so bookmarks read 'PON 235', not '235'."""
    def unit_word():
        cn = (cov.name() if cov else "").lower()
        if "zone" in cn:
            return "Zone"
        if "pon" in cn:
            return "PON"
        parts = cov.name().split() if cov else []
        return parts[0] if parts else "Page"
    uw = unit_word()

    def lab(u, i):
        return f"{uw} {i}" if (u is None or str(u) == "") else f"{uw} {u}"

    out = []
    if atlas_ok:
        pages = next((l for l in proj.mapLayers().values() if l.name() == "HLD Book Pages"), None)
        if pages is not None:
            feats = sorted(pages.getFeatures(),
                           key=lambda f: (f["seq"] is None, f["seq"] if f["seq"] is not None else 0))
            for i, f in enumerate(feats):
                out.append((i, "Overview" if f["is_overview"] == 1 else lab(f["unit"], i)))
            return out
    # report / fallback: page 1 = overview, then coverage features by the sort field
    names = [fld.name() for fld in cov.fields()] if cov else []
    sf = eff.get("coverage_sort_field", "label")
    if sf not in names:
        sf = names[0] if names else None

    def sk(f):
        v = f[sf] if sf else f.id()
        return (v is None, 0 if isinstance(v, (int, float)) else 1,
                v if isinstance(v, (int, float)) else 0, str(v))
    out.append((0, "Overview"))
    for i, f in enumerate(sorted(cov.getFeatures(), key=sk) if cov else [], start=1):
        out.append((i, lab(f[sf] if sf else None, i)))
    return out


def _add_bookmarks(pdf_path, labels, meta):
    """Add a PDF outline + document metadata IN PLACE via pypdf — lossless (page streams are
    copied verbatim, no re-encode, so 300dpi vector quality is untouched). Returns the number
    of outline entries written. Raises on any failure so the caller can fail open."""
    from pypdf import PdfReader, PdfWriter
    reader = PdfReader(pdf_path)
    n = len(reader.pages)
    writer = PdfWriter()
    writer.append(reader)
    written = 0
    for idx, title in labels:
        if 0 <= idx < n:
            writer.add_outline_item(str(title), idx)
            written += 1
    clean = {k: v for k, v in (meta or {}).items() if v}
    if clean:
        writer.add_metadata(clean)
    tmp = pdf_path + ".bm.tmp"
    with open(tmp, "wb") as fh:
        writer.write(fh)
    os.replace(tmp, pdf_path)
    return written


def _cover_kpis(proj, cov, eff):
    """Headline KPIs, summed across ALL configured layer names per role. (_role() returns
    only the FIRST match, which undercounts multi-layer roles like poles — so we sum by
    the configured names here.) Returns an ordered list of (label, value_str)."""
    roles_cfg = eff.get("roles") or {}
    by_name = {}
    for l in proj.mapLayers().values():
        by_name.setdefault(l.name(), l)

    def _count(role):
        n = 0
        for nm in roles_cfg.get(role, []) or []:
            l = by_name.get(nm)
            if l is not None:
                try:
                    n += l.featureCount()
                except Exception:
                    _swallowed_note()
        return n

    def _km(role):
        m = 0.0
        for nm in roles_cfg.get(role, []) or []:
            l = by_name.get(nm)
            if l is None:
                continue
            for f in l.getFeatures():
                g = f.geometry()
                if g and not g.isEmpty():
                    m += g.length() * 111320.0     # deg -> m (CRS 4326)
        return m / 1000.0

    zones = cov.featureCount() if cov else 0
    drops = _count("drop")
    units, uf = 0, None
    if cov:
        cov_fields = [fld.name() for fld in cov.fields()]
        for cand in ("unit_count", "units", "homes", "home_count"):
            if cand in cov_fields:
                uf = cand
                break
    if uf:
        for f in cov.getFeatures():
            try:
                units += int(f[uf] or 0)
            except Exception:
                _swallowed_note()
    if not units:
        units = drops
    sts, fts, poles = _count("sts"), _count("fts"), _count("poles")
    dist_km, feed_km = _km("distribution"), _km("primary")
    viol = 0
    hi = by_name.get("HLD Issues")
    if hi is not None:
        try:
            viol = hi.featureCount()
        except Exception:
            viol = 0
    out = [
        ("Homes / Units", f"{units:,}"),
        ("PON Zones", f"{zones:,}"),
        ("STS Splitters", f"{sts:,}"),
        ("FTS Splitters", f"{fts:,}"),
        ("Poles", f"{poles:,}"),
        ("Drop Cables", f"{drops:,}"),
        ("Distribution", f"{dist_km:,.1f} km"),
        ("Feeder", f"{feed_km:,.1f} km"),
    ]
    if viol:
        out.append(("Span Violations", f"{viol:,}"))
    return out


def _cover_html(eff, kpis, toc):
    """A3-landscape cover markup: title band, KPI grid (4/row), 3-column table of contents.
    Plain HTML only (tables + inline CSS) — QTextDocument has no flexbox/grid."""
    def esc(s):
        return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
    name = esc(eff.get("project_name") or "Network")
    company = esc(eff.get("company") or "Velocity Fibre")
    designer = esc(eff.get("designer") or "")
    today = datetime.date.today().strftime("%d %b %Y")
    rev = ""
    rows = eff.get("revision_rows") or []
    if rows:
        try:
            rev = "Rev %s &middot; %s" % (esc(rows[-1][0]), esc(rows[-1][1]))
        except Exception:
            rev = ""

    cells = []
    for label, val in kpis:
        v, lb = esc(val), esc(label).upper()
        cells.append(
            f'<td width="25%" style="padding:6px;">'
            f'<table width="100%" cellpadding="12" cellspacing="0" bgcolor="#0d1b2a">'
            f'<tr><td align="center">'
            f'<div style="color:#4cc9f0;font-size:30pt;font-weight:bold;">{v}</div>'
            f'<div style="color:#cbd5e1;font-size:10pt;">{lb}</div>'
            f'</td></tr></table></td>')
    while len(cells) % 4 != 0:
        cells.append('<td width="25%"></td>')
    kpi_rows = ""
    for i in range(0, len(cells), 4):
        kpi_rows += "<tr>" + "".join(cells[i:i + 4]) + "</tr>"

    ncol = 3
    per = max(1, (len(toc) + ncol - 1) // ncol)
    cols = [toc[i:i + per] for i in range(0, len(toc), per)]
    toc_cells = []
    for col in cols:
        lines = "".join(
            f'<tr><td width="34" style="color:#64748b;font-size:9pt;">{pg}</td>'
            f'<td style="color:#1e293b;font-size:10pt;">{esc(lbl)}</td></tr>'
            for pg, lbl in col)
        toc_cells.append(f'<td width="33%" valign="top">'
                         f'<table cellpadding="2" cellspacing="0">{lines}</table></td>')
    while len(toc_cells) < ncol:
        toc_cells.append('<td width="33%"></td>')
    toc_table = "<tr>" + "".join(toc_cells) + "</tr>"

    rev_bit = ("&nbsp;&middot;&nbsp;" + rev) if rev else ""
    return (
        f'<div style="font-family:Arial;">'
        f'<table width="100%" cellpadding="0" cellspacing="0"><tr>'
        f'<td><div style="color:#0d1b2a;font-size:34pt;font-weight:bold;">{name}</div>'
        f'<div style="color:#334155;font-size:16pt;">High-Level Design &mdash; Network Atlas</div></td>'
        f'<td align="right" valign="top">'
        f'<div style="color:#334155;font-size:12pt;">{company}</div>'
        f'<div style="color:#64748b;font-size:10pt;">{designer}</div>'
        f'<div style="color:#64748b;font-size:10pt;">{today}{rev_bit}</div></td>'
        f'</tr></table>'
        f'<div style="border-top:3px solid #4cc9f0;">&nbsp;</div>'
        f'<div style="color:#0d1b2a;font-size:12pt;font-weight:bold;">PROJECT TOTALS</div>'
        f'<table width="100%" cellpadding="0" cellspacing="0">{kpi_rows}</table>'
        f'<div style="color:#0d1b2a;font-size:12pt;font-weight:bold;">&nbsp;<br>CONTENTS</div>'
        f'<table width="100%" cellpadding="0" cellspacing="0">{toc_table}</table>'
        f'</div>')


def _render_cover_pdf(path, html, dpi):
    """Render the cover HTML to ONE A3-landscape PDF page. Raster (QTextDocument -> QImage,
    painted onto the QPdfWriter page) so it looks identical headless and matches the raster
    atlas pages; crisp at the book dpi. Returns True on success. Caller fails open."""
    from qgis.PyQt.QtGui import (QTextDocument, QImage, QPainter, QColor,
                                 QPdfWriter, QPageSize, QPageLayout)
    from qgis.PyQt.QtCore import QMarginsF, QRect
    PW, PH, margin = 420.0, 297.0, 16.0            # A3 landscape, mm
    cw, ch = PW - 2 * margin, PH - 2 * margin
    base = 96.0
    px_w = max(10, int(round(cw / 25.4 * base)))
    px_h = max(10, int(round(ch / 25.4 * base)))
    doc = QTextDocument()
    doc.setHtml(html)
    doc.setTextWidth(px_w)
    scale = max(1.0, dpi / base)                    # supersample for a crisp raster
    img = QImage(int(px_w * scale), int(px_h * scale), QImage.Format.Format_ARGB32)
    img.fill(QColor(255, 255, 255))
    pa = QPainter(img)
    try:
        pa.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        pa.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
    except Exception:
        _swallowed_note()
    pa.scale(scale, scale)
    doc.drawContents(pa)
    pa.end()
    writer = QPdfWriter(path)
    writer.setPageSize(QPageSize(QPageSize.PageSizeId.A3))
    writer.setPageOrientation(QPageLayout.Orientation.Landscape)
    writer.setResolution(int(dpi))
    writer.setPageMargins(QMarginsF(margin, margin, margin, margin), QPageLayout.Unit.Millimeter)
    pen = QPainter(writer)
    pen.drawImage(QRect(0, 0, writer.width(), writer.height()), img)
    pen.end()
    return True


def main():
    if len(sys.argv) < 2:
        print("usage: hld_generate.py <config.json>", flush=True); return 2
    with open(sys.argv[1], encoding="utf-8") as f:
        cfg = json.load(f)

    project = cfg["project"]
    output = cfg["output"]
    output_project = cfg.get("output_project")
    hld_cfg = cfg.get("hld_cfg", {}) or {}
    extra_layers = cfg.get("extra_layers", []) or []
    dpi = int(cfg.get("dpi", 150))
    do_compress = bool(cfg.get("compress", False))
    cover_added = 0     # P3: 1 once a cover page is prepended (shifts pages + bookmarks)
    result_path = cfg.get("result") or (os.path.splitext(output)[0] + ".result.json")
    tmp = cfg.get("tmp") or os.path.join(os.path.dirname(output) or ".", "_hld_tmp")
    os.makedirs(tmp, exist_ok=True)

    engine = cfg.get("engine") or os.path.join(_HERE, "hld_atlas_engine.py")
    # Ask where QGIS and Ghostscript actually are on THIS machine before falling back to
    # where they happen to live on the author's. A teammate on a different QGIS version or
    # a non-default install directory got a headless export that could not start.
    # This module is ALSO run as a standalone script (python-qgis.bat hld_generate.py
    # cfg.json), where __package__ is empty and a relative import raises ImportError
    # before the first line of work — so import it both ways and never let the lookup
    # itself break an export.
    try:
        from .presets import find_qgis_prefix, find_gs          # imported as a package
    except Exception:
        try:
            sys.path.insert(0, _HERE)
            from presets import find_qgis_prefix, find_gs        # run as a script
        except Exception:
            find_qgis_prefix = find_gs = lambda: None
    qgis_prefix = cfg.get("qgis_prefix")
    if not qgis_prefix:
        # find_qgis_prefix(), NOT find_python_qgis(): this value is handed to
        # QgsApplication.setPrefixPath(), so it must be the .../apps/qgis resource root.
        # The launcher .bat that find_python_qgis() returns would point QGIS's resource
        # root at a file and every icon, SVG and provider lookup would come up empty.
        try:
            found = find_qgis_prefix()
        except Exception:
            found = None
        qgis_prefix = found or r"C:/Program Files/QGIS 4.0.3/apps/qgis"
    gs = cfg.get("gs")
    if not gs:
        try:
            found = find_gs()
        except Exception:
            found = None
        gs = found or r"C:/Program Files/QGIS 4.0.3/bin/gswin64c.exe"

    # ---- pre-flight (cheap) ----
    if not os.path.exists(project):
        return fail(result_path, "preflight", f"project not found: {project}")
    if not os.path.exists(engine):
        return fail(result_path, "preflight", f"engine not found: {engine}")
    if output_project and os.path.abspath(output_project) == os.path.abspath(project):
        return fail(result_path, "preflight", "output_project must differ from the source project")
    out_dir = os.path.dirname(output) or "."
    os.makedirs(out_dir, exist_ok=True)
    try:
        free_mb = shutil.disk_usage(out_dir).free / (1024 * 1024)
        if free_mb < MIN_FREE_MB:
            return fail(result_path, "preflight", f"low disk: {free_mb:.0f} MB free (< {MIN_FREE_MB})")
        log(f"disk free: {free_mb:.0f} MB")
    except Exception as e:
        log(f"disk check skipped: {e}")

    # ---- boot QGIS headless ----
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from qgis.core import (QgsApplication, QgsProject, QgsLayoutExporter,
                           QgsVectorLayer, QgsFillSymbol)
    from qgis.PyQt.QtGui import QFontDatabase

    global _APP
    QgsApplication.setPrefixPath(qgis_prefix, True)
    app = QgsApplication([], False)
    app.initQgis()
    _APP = app
    try:
        _fdir = os.path.join(os.environ.get("WINDIR", r"C:/Windows"), "Fonts")
        ids = [QFontDatabase.addApplicationFont(os.path.join(_fdir, fn)) for fn in FONTS]
        if all(i < 0 for i in ids):
            log("WARNING: no Arial fonts registered -> text may be boxes")

        proj = QgsProject.instance()
        if not proj.read(project):
            return fail(result_path, "read", f"could not read project: {project}")
        log(f"project read: {len(proj.mapLayers())} layers")

        for el in extra_layers:
            vl = QgsVectorLayer(el["path"], el.get("name", os.path.basename(el["path"])), "ogr")
            if vl.isValid():
                if el.get("fill"):
                    try: vl.renderer().setSymbol(QgsFillSymbol.createSimple(el["fill"]))
                    except Exception as e: log(f"extra-layer style skipped: {e}")
                proj.addMapLayer(vl, el.get("add_to_tree", True))
                log(f"extra layer: {el.get('name')} ({vl.featureCount()})")
            else:
                log(f"WARNING: extra layer invalid: {el['path']}")

        # ---- build layouts via the engine ----
        # The engine defaults restyle_layers=False so a LIVE in-session build never
        # overwrites the operator's own symbology/labels. This path is different: a
        # separate headless QGIS process that read the project off disk and saves
        # nothing back, so the house style is applied here as it always was. An
        # explicit value in the caller's config still wins.
        hld_cfg = dict(hld_cfg or {})
        hld_cfg.setdefault("restyle_layers", True)
        ns = {"HLD_CFG": hld_cfg}
        try:
            with open(engine, encoding="utf-8") as f:
                exec(compile(f.read(), engine, "exec"), ns)  # defines the engine; builds nothing
            # `engine` is caller-configurable, so it may be an OLD engine that still
            # builds on exec and defines no build(). Call it only if it exists.
            if callable(ns.get("build")):
                ns["build"]()
            else:
                log("engine exposes no build() - assuming legacy build-on-exec engine")
        except Exception as e:
            return fail(result_path, "build", f"engine raised: {e}\n{traceback.format_exc()[-800:]}")

        eff = ns.get("CFG", {})
        lm = proj.layoutManager()
        at_name = eff.get("layout_atlas", "MOA PH2 HLD Atlas")
        rep_name = eff.get("layout_report", "MOA PH2 HLD Book")
        atlas = lm.layoutByName(at_name)
        rep = lm.layoutByName(rep_name)
        atlas_ok = atlas is not None and getattr(atlas, "atlas", None) and atlas.atlas().enabled()
        if not atlas_ok and rep is None:
            return fail(result_path, "build", "no atlas/report produced by the engine")

        _role = ns.get("_role")
        cov = _role("coverage") if callable(_role) else None
        n_feat = cov.featureCount() if cov else 0
        if not cov or n_feat < 1:
            return fail(result_path, "preflight", f"coverage layer empty/unresolved (features={n_feat})")
        log(f"coverage: {cov.name()} ({n_feat} features)")

        # ---- Perfect-Render QA gate — a broken page (overlap / off-page / blank map / missing
        #      legend) can never ship. Frame-agnostic: HLD atlas, commercial, wayleave; any client.
        _qa = ns.get("_layout_qa")
        qa_layout = atlas if atlas_ok else None
        if callable(_qa) and qa_layout is not None and cfg.get("qa_gate", True):
            try:
                hard, soft = _qa(qa_layout)
                for s in soft:
                    log(f"QA warn: {s}")
                if hard:
                    for h in hard:
                        log(f"QA FAIL: {h}")
                    return fail(result_path, "qa",
                                f"layout QA found {len(hard)} blocking issue(s): " + "; ".join(hard[:4]))
                log(f"QA: layout clean ({len(soft)} warning(s))")
            except Exception as e:
                log(f"QA skipped (fail-open): {e}")

        # ---- save editable *_HLD.qgz copy (the layouts live in the project) ----
        if output_project:
            os.makedirs(os.path.dirname(output_project) or ".", exist_ok=True)
            _backup(output_project, ".qgz")
            if proj.write(output_project):
                log(f"editable project saved: {output_project}")
            else:
                log(f"WARNING: could not save editable project: {output_project}")
                output_project = None

        # ---- export to ONE PDF (overview page 1 + one page per feature) ----
        # Re-lock every map item to its engine-designed page geometry FIRST. Building the
        # atlas grows the map frame to the current feature's aspect ratio, and headless we
        # never went through live_build._relock_frame — so the map overran the page and ate
        # the wayleave title strip (Project Description / legend / Date-Scale-Project /
        # logo), which is drawn UNDER the map area. The live "Open in Print Layout" path
        # already relocks; this makes the headless path produce the identical sheet.
        def _relock(layout):
            from qgis.core import QgsLayoutItemMap, QgsLayoutPoint, QgsLayoutSize, QgsUnitTypes
            MM = QgsUnitTypes.LayoutUnit.LayoutMillimeters
            n = 0
            for it in layout.items():
                if not isinstance(it, QgsLayoutItemMap):
                    continue
                w = it.customProperty("hld_frame_w"); h = it.customProperty("hld_frame_h")
                x = it.customProperty("hld_frame_x"); y = it.customProperty("hld_frame_y")
                if w and h:
                    if x is not None and y is not None:
                        it.attemptMove(QgsLayoutPoint(float(x), float(y), MM))
                    it.attemptResize(QgsLayoutSize(float(w), float(h), MM))
                    n += 1
            return n

        try:
            _n = _relock(atlas if atlas_ok else rep)
            log(f"map frame re-locked to the designed geometry ({_n} map item(s))")
        except Exception as e:
            log(f"WARNING: frame re-lock skipped: {e}")

        # Re-locking ONCE before the export is not enough. The atlas re-fits the map to
        # each feature as it renders, and in QGIS 4 setting a map's extent RESIZES the
        # item to that extent's aspect (see make_map's note in the engine) — so the frame
        # grows again on the very first feature and every page after it. Headless that ate
        # the wayleave title strip outright: the layout was saved with mainmap at the
        # designed 289x168, and the exported page still had the map over the whole sheet.
        # Re-locking on EVERY featureChanged keeps it pinned for the whole render.
        # Nothing disconnects this: the layout and its atlas are torn down with the
        # process at the end of this run, and re-locking to the designed geometry is
        # idempotent, so a stray late signal cannot do harm.
        try:
            _lay_for_atlas = atlas if atlas_ok else rep
            _at = _lay_for_atlas.atlas()
            if _at is not None:
                _at.featureChanged.connect(lambda *_a: _relock(_lay_for_atlas))
                log("frame re-lock armed on every atlas feature")
        except Exception as e:
            log(f"WARNING: per-feature frame re-lock not armed: {e}")

        S = QgsLayoutExporter.PdfExportSettings(); S.dpi = dpi
        # P3.2: keep text/lines VECTOR (zoom-crisp, selectable) when the operator asks.
        # Off by default so the approved MOA render (raster @ its dpi) is unchanged.
        S.forceVectorOutput = bool(cfg.get("force_vector", False))
        log(f"export dpi={dpi} forceVector={S.forceVectorOutput}")
        staged = os.path.join(tmp, "_book.pdf")
        if atlas_ok:
            r = QgsLayoutExporter(atlas).exportToPdf(atlas.atlas(), staged, S)   # unified atlas
            what = "atlas"
        else:
            r = QgsLayoutExporter.exportToPdf(rep, staged, S)                    # report
            what = "report"
        if int(r[0] if isinstance(r, tuple) else r) != 0:
            return fail(result_path, "export", f"{what} export failed (code {r})")
        log(f"exported {what} (overview + detail)")

        # ---- P3: KPI + table-of-contents COVER page (config-gated; off -> MOA unchanged) ----
        if eff.get("cover_page"):
            try:
                kpis = _cover_kpis(proj, cov, eff)
                labels0 = _book_page_labels(proj, cov, eff, atlas_ok)
                # cover becomes page 1, so page N (0-based idx) is shown as idx + 2
                toc = [(idx + 2, lbl) for idx, lbl in labels0]
                cover_pdf = os.path.join(tmp, "_cover.pdf")
                _render_cover_pdf(cover_pdf, _cover_html(eff, kpis, toc), dpi)
                from pypdf import PdfReader, PdfWriter
                w = PdfWriter()
                w.append(PdfReader(cover_pdf))       # cover first
                w.append(PdfReader(staged))          # then the book (lossless copy)
                merged = staged + ".cover.tmp"
                with open(merged, "wb") as fh:
                    w.write(fh)
                os.replace(merged, staged)
                cover_added = 1
                log(f"cover page: {len(kpis)} KPIs + {len(toc)} TOC entries")
            except Exception as e:
                cover_added = 0
                log(f"cover page skipped (fail-open): {e}")

        # ---- P3.1: outline bookmarks + document metadata (pypdf, fail-open) ----
        if cfg.get("bookmarks", True):
            try:
                labels = _book_page_labels(proj, cov, eff, atlas_ok)
                labels = [(i + cover_added, t) for i, t in labels]   # shift past the cover
                if cover_added:
                    labels = [(0, "Cover")] + labels
                meta = {
                    "/Title":   eff.get("project_name") or os.path.splitext(os.path.basename(output))[0],
                    "/Author":  eff.get("designer") or eff.get("company") or "Velocity Fibre",
                    "/Subject": "HLD Network Atlas",
                    "/Creator": "Velocity Nexus",
                }
                nb = _add_bookmarks(staged, labels, meta)
                log(f"bookmarks: {nb} outline entries + metadata")
            except Exception as e:
                log(f"bookmarks skipped (fail-open): {e}")

    except Exception as e:
        return fail(result_path, "render", f"unexpected: {e}\n{traceback.format_exc()[-800:]}")
    # NOTE: no app.exitQgis() — segfaults headless; os._exit() handles teardown.

    # ---- verify -> swap ----
    pages = _count_pdf_pages(staged, gs)
    expected = 1 + n_feat + cover_added
    if pages != expected:
        return fail(result_path, "verify", f"page count {pages} != expected {expected}")
    size_mb = os.path.getsize(staged) / (1024 * 1024)
    if size_mb < MIN_PDF_MB:
        return fail(result_path, "verify", f"output too small: {size_mb:.2f} MB")
    log(f"verify OK: {pages} pages, {size_mb:.1f} MB")

    # ---- P3: optional post-render pixel check — a page whose MAP area came out blank can't ship
    if cfg.get("pixel_check"):
        sample = sorted(set([1, min(2, pages), max(1, pages)]))
        px = _pixel_check(staged, gs, sample, tmp)
        for m in px:
            log(f"pixel-check FAIL: {m}")
        if px and cfg.get("qa_gate", True):
            return fail(result_path, "qa", "pixel check: " + "; ".join(px))
        log(f"pixel-check: map area OK on pages {sample}")

    if os.path.exists(output):
        try: shutil.copy2(output, output + ".bak")
        except Exception as e: log(f"prev-PDF backup skipped: {e}")
    os.replace(staged, output)
    log(f"written: {output}")

    email_path = None
    if do_compress:
        email_path = os.path.splitext(output)[0] + " (email).pdf"
        staged_email = os.path.join(tmp, "_email.pdf")
        try:
            _gs_run(gs, ["-dBATCH", "-dNOPAUSE", "-q", "-sDEVICE=pdfwrite",
                         "-dCompatibilityLevel=1.5", "-dPDFSETTINGS=/ebook",
                         "-dDownsampleColorImages=true", "-dColorImageResolution=90",
                         "-dDownsampleGrayImages=true", "-dGrayImageResolution=90",
                         f"-sOutputFile={staged_email}", output], "compress")
            os.replace(staged_email, email_path)
            log(f"email copy: {email_path} ({os.path.getsize(email_path)/(1024*1024):.1f} MB)")
        except Exception as e:
            log(f"compress skipped: {e}"); email_path = None

    _write_result(result_path, {"ok": True, "stage": "done", "message": "HLD PDF generated",
                                "pages": pages, "output": output, "email": email_path,
                                "output_project": output_project, "size_mb": round(size_mb, 1)})
    log("HLD GENERATE OK")
    return 0


if __name__ == "__main__":
    rc = 1
    try:
        rc = main()
    except Exception as e:
        print("FATAL:", e, flush=True); traceback.print_exc()
    sys.stdout.flush(); sys.stderr.flush()
    os._exit(rc)   # skip QGIS teardown segfault; result.json already written
