<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyDrawingHints="1" symbologyReferenceScale="-1" maxScale="0" hasScaleBasedVisibilityFlag="0" minScale="100000000" simplifyDrawingTol="1" simplifyLocal="1" styleCategories="AllStyleCategories" autoRefreshMode="Disabled" simplifyAlgorithm="0" version="3.44.4-Solothurn" readOnly="0" labelsEnabled="1" autoRefreshTime="0" simplifyMaxScale="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endField="" startExpression="" endExpression="" durationField="units" mode="0" limitMode="0" startField="" enabled="0" fixedDuration="0" durationUnit="min" accumulate="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation zoffset="0" extrusion="0" type="IndividualFeatures" zscale="1" clamping="Terrain" extrusionEnabled="0" binding="Centroid" customToleranceEnabled="1" showMarkerSymbolInSurfacePlots="0" symbology="Line" respectLayerSymbol="1">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol name="" clip_to_extent="1" type="line" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleLine" id="{b1580ef9-3396-4692-a112-6c486a464cbe}" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="196,60,57,255,rgb:0.7686275,0.2352941,0.2235294,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol name="" clip_to_extent="1" type="fill" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleFill" id="{38c88e0c-1c27-406a-ad5d-c2321d0b056c}" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="196,60,57,255,rgb:0.7686275,0.2352941,0.2235294,1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="140,43,41,255,rgb:0.5490196,0.1680323,0.1596704,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol name="" clip_to_extent="1" type="marker" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleMarker" id="{1c13dc3b-9bcf-4169-9bca-ac573696a7b0}" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="196,60,57,255,rgb:0.7686275,0.2352941,0.2235294,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="diamond"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="140,43,41,255,rgb:0.5490196,0.1680323,0.1596704,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" type="singleSymbol" forceraster="0" referencescale="-1" symbollevels="0">
    <symbols>
      <symbol name="0" clip_to_extent="1" type="fill" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleFill" id="{0f5bd816-b055-4f05-bd92-7034a61c9734}" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="9,240,248,56,hsv:0.50530555555555556,0.96322575722896164,0.97087052719920652,0.22105745021744105"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="9,240,248,255,hsv:0.50530555555555556,0.96322575722896164,0.97087052719920652,1"/>
            <Option name="outline_style" type="QString" value="dash"/>
            <Option name="outline_width" type="QString" value="0.46"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol name="" clip_to_extent="1" type="fill" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleFill" id="{feb77b50-7aab-4fd8-bb57-a08ddb1b449b}" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="0,0,255,255,rgb:0,0,1,1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.26"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style fontWeight="50" textOpacity="1" multilineHeight="1" fontSizeUnit="Point" forcedItalic="0" stretchFactor="100" isExpression="0" fontFamily="Open Sans" textOrientation="horizontal" tabStopDistance="80" fontKerning="1" capitalization="0" tabStopDistanceUnit="Point" legendString="Aa" blendMode="0" useSubstitutions="0" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" textColor="50,50,50,255,rgb:0.1960784,0.1960784,0.1960784,1" forcedBold="0" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fieldName="pon_no" multilineHeightUnit="Percentage" allowHtml="0" fontLetterSpacing="0" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" fontWordSpacing="0" namedStyle="Regular" fontItalic="0" fontStrikeout="0" fontSize="10">
        <families/>
        <text-buffer bufferSizeUnits="MM" bufferNoFill="1" bufferSize="1" bufferOpacity="1" bufferDraw="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferColor="250,250,250,255,rgb:0.9803922,0.9803922,0.9803922,1" bufferBlendMode="0"/>
        <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSize="1.5" maskedSymbolLayers="" maskSizeUnits="MM" maskEnabled="0" maskType="0" maskSize2="1.5" maskJoinStyle="128" maskOpacity="1"/>
        <background shapeBorderWidthUnit="Point" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeSizeX="0" shapeRadiiUnit="Point" shapeBlendMode="0" shapeDraw="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeSizeY="0" shapeSizeUnit="Point" shapeType="0" shapeOffsetY="0" shapeOffsetUnit="Point" shapeRadiiY="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeBorderWidth="0" shapeSVGFile="" shapeOffsetX="0" shapeRotation="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeSizeType="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeRotationType="0">
          <symbol name="markerSymbol" clip_to_extent="1" type="marker" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer locked="0" enabled="1" class="SimpleMarker" id="" pass="0">
              <Option type="Map">
                <Option name="angle" type="QString" value="0"/>
                <Option name="cap_style" type="QString" value="square"/>
                <Option name="color" type="QString" value="232,113,141,255,rgb:0.9098039,0.4431373,0.5529412,1"/>
                <Option name="horizontal_anchor_point" type="QString" value="1"/>
                <Option name="joinstyle" type="QString" value="bevel"/>
                <Option name="name" type="QString" value="circle"/>
                <Option name="offset" type="QString" value="0,0"/>
                <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="offset_unit" type="QString" value="MM"/>
                <Option name="outline_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
                <Option name="outline_style" type="QString" value="solid"/>
                <Option name="outline_width" type="QString" value="0"/>
                <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="outline_width_unit" type="QString" value="MM"/>
                <Option name="scale_method" type="QString" value="diameter"/>
                <Option name="size" type="QString" value="2"/>
                <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="size_unit" type="QString" value="MM"/>
                <Option name="vertical_anchor_point" type="QString" value="1"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol name="fillSymbol" clip_to_extent="1" type="fill" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer locked="0" enabled="1" class="SimpleFill" id="" pass="0">
              <Option type="Map">
                <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                <Option name="joinstyle" type="QString" value="bevel"/>
                <Option name="offset" type="QString" value="0,0"/>
                <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="offset_unit" type="QString" value="MM"/>
                <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                <Option name="outline_style" type="QString" value="no"/>
                <Option name="outline_width" type="QString" value="0"/>
                <Option name="outline_width_unit" type="QString" value="Point"/>
                <Option name="style" type="QString" value="solid"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowBlendMode="6" shadowOffsetAngle="135" shadowOffsetGlobal="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowScale="100" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetDist="1" shadowRadiusUnit="MM"/>
        <dd_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format rightDirectionSymbol=">" decimals="3" autoWrapLength="0" addDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" plussign="0" wrapChar="" reverseDirectionSymbol="0" placeDirectionSymbol="0" multilineAlign="3" leftDirectionSymbol="&lt;" formatNumbers="0"/>
      <placement preserveRotation="1" lineAnchorType="0" quadOffset="4" lineAnchorClipping="0" distMapUnitScale="3x:0,0,0,0,0,0" polygonPlacementFlags="2" geometryGenerator="" layerType="PolygonGeometry" dist="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" rotationAngle="0" rotationUnit="AngleDegrees" maxCurvedCharAngleIn="25" priority="5" centroidInside="0" yOffset="0" prioritization="PreferCloser" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" lineAnchorTextPoint="FollowPlacement" fitInPolygonOnly="0" repeatDistance="0" maximumDistanceUnit="MM" geometryGeneratorEnabled="0" repeatDistanceUnits="MM" overlapHandling="PreventOverlap" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" placementFlags="10" lineAnchorPercent="0.5" centroidWhole="0" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" maximumDistance="0" xOffset="0" placement="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" overrunDistanceUnit="MM" allowDegraded="0" distUnits="MM"/>
      <rendering labelPerPart="0" obstacleType="1" fontMaxPixelSize="10000" fontMinPixelSize="3" scaleMax="0" scaleMin="0" obstacle="1" maxNumLabels="2000" upsidedownLabels="0" obstacleFactor="1" scaleVisibility="0" fontLimitPixelSize="0" zIndex="0" unplacedVisibility="0" drawLabels="1" minFeatureSize="0" mergeLines="0" limitNumLabels="0"/>
      <dd_properties>
        <Option type="Map">
          <Option name="name" type="QString" value=""/>
          <Option name="properties"/>
          <Option name="type" type="QString" value="collection"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
          <Option name="blendMode" type="int" value="0"/>
          <Option name="ddProperties" type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
          <Option name="drawToAllParts" type="bool" value="false"/>
          <Option name="enabled" type="QString" value="0"/>
          <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
          <Option name="lineSymbol" type="QString" value="&lt;symbol name=&quot;symbol&quot; clip_to_extent=&quot;1&quot; type=&quot;line&quot; is_animated=&quot;0&quot; force_rhr=&quot;0&quot; alpha=&quot;1&quot; frame_rate=&quot;10&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; enabled=&quot;1&quot; class=&quot;SimpleLine&quot; id=&quot;{c079a07f-8d2f-417b-ab02-ecea642971f8}&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
          <Option name="minLength" type="double" value="0"/>
          <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="minLengthUnit" type="QString" value="MM"/>
          <Option name="offsetFromAnchor" type="double" value="0"/>
          <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
          <Option name="offsetFromLabel" type="double" value="0"/>
          <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option name="QFieldSync/action" type="QString" value="copy"/>
      <Option name="QFieldSync/attachment_naming" type="QString" value="{}"/>
      <Option name="QFieldSync/attribute_editing_locked_expression" type="invalid"/>
      <Option name="QFieldSync/cloud_action" type="QString" value="offline"/>
      <Option name="QFieldSync/feature_addition_locked_expression" type="invalid"/>
      <Option name="QFieldSync/feature_deletion_locked_expression" type="invalid"/>
      <Option name="QFieldSync/geometry_editing_locked_expression" type="invalid"/>
      <Option name="QFieldSync/photo_naming" type="QString" value="{}"/>
      <Option name="QFieldSync/relationship_maximum_visible" type="QString" value="{}"/>
      <Option name="QFieldSync/tracking_distance_requirement_minimum_meters" type="int" value="30"/>
      <Option name="QFieldSync/tracking_erroneous_distance_safeguard_maximum_meters" type="int" value="1"/>
      <Option name="QFieldSync/tracking_measurement_type" type="int" value="0"/>
      <Option name="QFieldSync/tracking_time_requirement_interval_seconds" type="int" value="30"/>
      <Option name="QFieldSync/value_map_button_interface_threshold" type="int" value="0"/>
      <Option name="dualview/previewExpressions" type="List">
        <Option type="QString" value="&quot;label&quot;"/>
      </Option>
      <Option name="embeddedWidgets/count" type="int" value="0"/>
      <Option name="variableNames" type="invalid"/>
      <Option name="variableValues" type="invalid"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration type="Map">
      <Option name="QgsGeometryGapCheck" type="Map">
        <Option name="allowedGapsBuffer" type="double" value="0"/>
        <Option name="allowedGapsEnabled" type="bool" value="false"/>
        <Option name="allowedGapsLayer" type="invalid"/>
      </Option>
    </checkConfiguration>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field name="label" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="type" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subtyp" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="spec" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cblcpty" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="conntr" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="units" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="status" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cmpownr" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="strtfeat" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="endfeat" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="lat" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="lon" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sg21" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sg26" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="address" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="pon_no" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="zone_no" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subplace" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="mainplce" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="mun" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="stackref" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="datecrtd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="crtdby" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="date_edt" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="editby" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="comments" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" index="0" field="label"/>
    <alias name="" index="1" field="type"/>
    <alias name="" index="2" field="subtyp"/>
    <alias name="" index="3" field="spec"/>
    <alias name="" index="4" field="dim1"/>
    <alias name="" index="5" field="dim2"/>
    <alias name="" index="6" field="cblcpty"/>
    <alias name="" index="7" field="conntr"/>
    <alias name="" index="8" field="units"/>
    <alias name="" index="9" field="status"/>
    <alias name="" index="10" field="cmpownr"/>
    <alias name="" index="11" field="strtfeat"/>
    <alias name="" index="12" field="endfeat"/>
    <alias name="" index="13" field="lat"/>
    <alias name="" index="14" field="lon"/>
    <alias name="" index="15" field="sg21"/>
    <alias name="" index="16" field="sg26"/>
    <alias name="" index="17" field="address"/>
    <alias name="" index="18" field="pon_no"/>
    <alias name="" index="19" field="zone_no"/>
    <alias name="" index="20" field="subplace"/>
    <alias name="" index="21" field="mainplce"/>
    <alias name="" index="22" field="mun"/>
    <alias name="" index="23" field="stackref"/>
    <alias name="" index="24" field="datecrtd"/>
    <alias name="" index="25" field="crtdby"/>
    <alias name="" index="26" field="date_edt"/>
    <alias name="" index="27" field="editby"/>
    <alias name="" index="28" field="comments"/>
  </aliases>
  <defaults>
    <default expression="" field="label" applyOnUpdate="0"/>
    <default expression="" field="type" applyOnUpdate="0"/>
    <default expression="" field="subtyp" applyOnUpdate="0"/>
    <default expression="" field="spec" applyOnUpdate="0"/>
    <default expression="" field="dim1" applyOnUpdate="0"/>
    <default expression="" field="dim2" applyOnUpdate="0"/>
    <default expression="" field="cblcpty" applyOnUpdate="0"/>
    <default expression="" field="conntr" applyOnUpdate="0"/>
    <default expression="" field="units" applyOnUpdate="0"/>
    <default expression="" field="status" applyOnUpdate="0"/>
    <default expression="" field="cmpownr" applyOnUpdate="0"/>
    <default expression="" field="strtfeat" applyOnUpdate="0"/>
    <default expression="" field="endfeat" applyOnUpdate="0"/>
    <default expression="" field="lat" applyOnUpdate="0"/>
    <default expression="" field="lon" applyOnUpdate="0"/>
    <default expression="" field="sg21" applyOnUpdate="0"/>
    <default expression="" field="sg26" applyOnUpdate="0"/>
    <default expression="" field="address" applyOnUpdate="0"/>
    <default expression="" field="pon_no" applyOnUpdate="0"/>
    <default expression="" field="zone_no" applyOnUpdate="0"/>
    <default expression="" field="subplace" applyOnUpdate="0"/>
    <default expression="" field="mainplce" applyOnUpdate="0"/>
    <default expression="" field="mun" applyOnUpdate="0"/>
    <default expression="" field="stackref" applyOnUpdate="0"/>
    <default expression="" field="datecrtd" applyOnUpdate="0"/>
    <default expression="" field="crtdby" applyOnUpdate="0"/>
    <default expression="" field="date_edt" applyOnUpdate="0"/>
    <default expression="" field="editby" applyOnUpdate="0"/>
    <default expression="" field="comments" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="label"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="type"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subtyp"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="spec"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="cblcpty"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="conntr"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="units"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="status"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="cmpownr"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="strtfeat"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="endfeat"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="lat"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="lon"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="sg21"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="sg26"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="address"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="pon_no"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="zone_no"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subplace"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="mainplce"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="mun"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="stackref"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="datecrtd"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="crtdby"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="date_edt"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="editby"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="comments"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" field="label" desc=""/>
    <constraint exp="" field="type" desc=""/>
    <constraint exp="" field="subtyp" desc=""/>
    <constraint exp="" field="spec" desc=""/>
    <constraint exp="" field="dim1" desc=""/>
    <constraint exp="" field="dim2" desc=""/>
    <constraint exp="" field="cblcpty" desc=""/>
    <constraint exp="" field="conntr" desc=""/>
    <constraint exp="" field="units" desc=""/>
    <constraint exp="" field="status" desc=""/>
    <constraint exp="" field="cmpownr" desc=""/>
    <constraint exp="" field="strtfeat" desc=""/>
    <constraint exp="" field="endfeat" desc=""/>
    <constraint exp="" field="lat" desc=""/>
    <constraint exp="" field="lon" desc=""/>
    <constraint exp="" field="sg21" desc=""/>
    <constraint exp="" field="sg26" desc=""/>
    <constraint exp="" field="address" desc=""/>
    <constraint exp="" field="pon_no" desc=""/>
    <constraint exp="" field="zone_no" desc=""/>
    <constraint exp="" field="subplace" desc=""/>
    <constraint exp="" field="mainplce" desc=""/>
    <constraint exp="" field="mun" desc=""/>
    <constraint exp="" field="stackref" desc=""/>
    <constraint exp="" field="datecrtd" desc=""/>
    <constraint exp="" field="crtdby" desc=""/>
    <constraint exp="" field="date_edt" desc=""/>
    <constraint exp="" field="editby" desc=""/>
    <constraint exp="" field="comments" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="&quot;label&quot;" sortOrder="0">
    <columns>
      <column name="label" type="field" width="-1" hidden="0"/>
      <column name="type" type="field" width="-1" hidden="0"/>
      <column name="subtyp" type="field" width="-1" hidden="0"/>
      <column name="spec" type="field" width="128" hidden="0"/>
      <column name="dim1" type="field" width="-1" hidden="0"/>
      <column name="dim2" type="field" width="-1" hidden="0"/>
      <column name="cblcpty" type="field" width="-1" hidden="0"/>
      <column name="conntr" type="field" width="-1" hidden="0"/>
      <column name="units" type="field" width="-1" hidden="0"/>
      <column name="status" type="field" width="-1" hidden="0"/>
      <column name="cmpownr" type="field" width="-1" hidden="0"/>
      <column name="strtfeat" type="field" width="-1" hidden="0"/>
      <column name="endfeat" type="field" width="-1" hidden="0"/>
      <column name="lat" type="field" width="-1" hidden="0"/>
      <column name="lon" type="field" width="-1" hidden="0"/>
      <column name="sg21" type="field" width="-1" hidden="0"/>
      <column name="sg26" type="field" width="-1" hidden="0"/>
      <column name="address" type="field" width="-1" hidden="0"/>
      <column name="pon_no" type="field" width="-1" hidden="0"/>
      <column name="zone_no" type="field" width="-1" hidden="0"/>
      <column name="subplace" type="field" width="-1" hidden="0"/>
      <column name="mainplce" type="field" width="-1" hidden="0"/>
      <column name="mun" type="field" width="-1" hidden="0"/>
      <column name="stackref" type="field" width="-1" hidden="0"/>
      <column name="datecrtd" type="field" width="-1" hidden="0"/>
      <column name="crtdby" type="field" width="-1" hidden="0"/>
      <column name="date_edt" type="field" width="-1" hidden="0"/>
      <column name="editby" type="field" width="-1" hidden="0"/>
      <column name="comments" type="field" width="-1" hidden="0"/>
      <column type="actions" width="-1" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="address" editable="1"/>
    <field name="cblcpty" editable="1"/>
    <field name="cmpownr" editable="1"/>
    <field name="comments" editable="1"/>
    <field name="conntr" editable="1"/>
    <field name="crtdby" editable="1"/>
    <field name="date_edt" editable="1"/>
    <field name="datecrtd" editable="1"/>
    <field name="dim1" editable="1"/>
    <field name="dim2" editable="1"/>
    <field name="editby" editable="1"/>
    <field name="endfeat" editable="1"/>
    <field name="label" editable="1"/>
    <field name="lat" editable="1"/>
    <field name="lon" editable="1"/>
    <field name="mainplce" editable="1"/>
    <field name="mun" editable="1"/>
    <field name="pon_no" editable="1"/>
    <field name="sg21" editable="1"/>
    <field name="sg26" editable="1"/>
    <field name="spec" editable="1"/>
    <field name="stackref" editable="1"/>
    <field name="status" editable="1"/>
    <field name="strtfeat" editable="1"/>
    <field name="subplace" editable="1"/>
    <field name="subtyp" editable="1"/>
    <field name="type" editable="1"/>
    <field name="units" editable="1"/>
    <field name="zone_no" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="address" labelOnTop="0"/>
    <field name="cblcpty" labelOnTop="0"/>
    <field name="cmpownr" labelOnTop="0"/>
    <field name="comments" labelOnTop="0"/>
    <field name="conntr" labelOnTop="0"/>
    <field name="crtdby" labelOnTop="0"/>
    <field name="date_edt" labelOnTop="0"/>
    <field name="datecrtd" labelOnTop="0"/>
    <field name="dim1" labelOnTop="0"/>
    <field name="dim2" labelOnTop="0"/>
    <field name="editby" labelOnTop="0"/>
    <field name="endfeat" labelOnTop="0"/>
    <field name="label" labelOnTop="0"/>
    <field name="lat" labelOnTop="0"/>
    <field name="lon" labelOnTop="0"/>
    <field name="mainplce" labelOnTop="0"/>
    <field name="mun" labelOnTop="0"/>
    <field name="pon_no" labelOnTop="0"/>
    <field name="sg21" labelOnTop="0"/>
    <field name="sg26" labelOnTop="0"/>
    <field name="spec" labelOnTop="0"/>
    <field name="stackref" labelOnTop="0"/>
    <field name="status" labelOnTop="0"/>
    <field name="strtfeat" labelOnTop="0"/>
    <field name="subplace" labelOnTop="0"/>
    <field name="subtyp" labelOnTop="0"/>
    <field name="type" labelOnTop="0"/>
    <field name="units" labelOnTop="0"/>
    <field name="zone_no" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="address" reuseLastValue="0"/>
    <field name="cblcpty" reuseLastValue="0"/>
    <field name="cmpownr" reuseLastValue="0"/>
    <field name="comments" reuseLastValue="0"/>
    <field name="conntr" reuseLastValue="0"/>
    <field name="crtdby" reuseLastValue="0"/>
    <field name="date_edt" reuseLastValue="0"/>
    <field name="datecrtd" reuseLastValue="0"/>
    <field name="dim1" reuseLastValue="0"/>
    <field name="dim2" reuseLastValue="0"/>
    <field name="editby" reuseLastValue="0"/>
    <field name="endfeat" reuseLastValue="0"/>
    <field name="label" reuseLastValue="0"/>
    <field name="lat" reuseLastValue="0"/>
    <field name="lon" reuseLastValue="0"/>
    <field name="mainplce" reuseLastValue="0"/>
    <field name="mun" reuseLastValue="0"/>
    <field name="pon_no" reuseLastValue="0"/>
    <field name="sg21" reuseLastValue="0"/>
    <field name="sg26" reuseLastValue="0"/>
    <field name="spec" reuseLastValue="0"/>
    <field name="stackref" reuseLastValue="0"/>
    <field name="status" reuseLastValue="0"/>
    <field name="strtfeat" reuseLastValue="0"/>
    <field name="subplace" reuseLastValue="0"/>
    <field name="subtyp" reuseLastValue="0"/>
    <field name="type" reuseLastValue="0"/>
    <field name="units" reuseLastValue="0"/>
    <field name="zone_no" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"label"</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
