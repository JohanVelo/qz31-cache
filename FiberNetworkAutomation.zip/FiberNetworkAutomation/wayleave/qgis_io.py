"""QGIS side of the Wayleave tools: find the layers, read them for the engine, write the results.

Everything that writes goes through the layers' EDIT BUFFERS and is left uncommitted, so
QGIS's own Save / Roll Back is the Keep / Undo. A backup copy of every layer it will touch
is written first to a folder the planner chooses.
Works on QGIS 3.38 - 4.2 (qgis.PyQt shim, scoped enums, no shapely / networkx).
"""
# claude:intent MUTATE — user asked: "Then it says, Generate finished Wayleave, and that should do all of
# this that we did" (JJ 2026-10-23, GO on the plan). — plan: writes only when the planner presses Generate,
# only into edit buffers (Keep = save, Undo = roll back), after a verified backup; Check never writes
# except a temporary scratch marker layer.
# claude:approved-destructive — plugin code: backup() writes and verifies a copy of every target layer
# before apply() opens any edit session; nothing is committed until the planner presses Keep.
import datetime
import json
import os
import shutil

from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature, QgsField,
                       QgsFields, QgsGeometry, QgsMapLayer, QgsMapThemeCollection, QgsPointXY,
                       QgsProject, QgsRasterLayer, QgsSettings, QgsVectorFileWriter, QgsVectorLayer,
                       QgsWkbTypes)
from qgis.PyQt.QtCore import QVariant

try:
    from qgis.PyQt.QtCore import QMetaType
    _T = dict(Real=QMetaType.Type.Double, Integer=QMetaType.Type.Int, Integer64=QMetaType.Type.LongLong, String=QMetaType.Type.QString)
except (ImportError, AttributeError):   # older Qt5 builds: QgsField still takes QVariant types
    _T = dict(Real=QVariant.Double, Integer=QVariant.Int, Integer64=QVariant.LongLong, String=QVariant.String)

HERE = os.path.dirname(os.path.abspath(__file__))
STYLES = os.path.join(HERE, 'styles')
GOLD_PATHS = [os.path.join(HERE, '..', 'fibre_automation', 'herotel_layers', 'gold_spec.json'),
              os.path.join(HERE, '..', '..', 'fibre_automation', 'herotel_layers', 'gold_spec.json')]

# role -> (label for people, geometry, name candidates in order, required for Check/Generate)
ROLES = {
    'feeder': ('Feeder Cable', 'line', ['feeder cable', 'feeder cables', 'feeder'], True),
    'link': ('Link Cable', 'line', ['link cable', 'link cables', 'link'], False),
    'dc': ('Distribution Cable', 'line', ['distribution cable', 'distribution cables', 'distribution'], True),
    's16': ('1:16 Splitter', 'point', ['feeder splitter', '1:16 splitter', 'fts splitter', '16 way splitter', '16way splitter', '1:16'], True),
    'pons': ('PON', 'polygon', ['pons', 'pon', 'pon zones'], True),
    'pop': ('POP', 'point', ['pop'], True),
    'poles': ('Poles', 'point', ['poles'], False),
    'span': ('Span', 'line', ['span'], False),
    'erven': ('Erven', 'polygon', ['erven'], False),
    'dps': ('Demand Points', 'point', ['demand points', 'demand point'], False),
    'roads': ('Roads', 'line', ['roads', 'road'], False),
    'aoi': ('AOI', 'polygon', ['aoi', 'area of interest'], False),
}
from qgis.core import Qgis
GEOM = {'point': Qgis.GeometryType.Point, 'line': Qgis.GeometryType.Line, 'polygon': Qgis.GeometryType.Polygon}
GOLD_KEY = {'feeder': 'Feeder', 'link': 'Link', 'dc': 'Distribution Cable', 's16': '16 Way Splitter', 'pons': 'PON', 'poles': 'Poles'}
SPAN_FIELDS = [dict(name='Name', type='String', width=100), dict(name='Length', type='Real', width=11, precision=2)]
SETTINGS = 'VelocityFibre/wayleave'
STYLE_ROLES = ('feeder', 'link', 'dc', 's16', 'poles', 'span', 'pons', 'pop', 'erven', 'dps', 'aoi')
WGS84 = 'EPSG:4326'


class WayleaveIOError(Exception):
    pass


def gold_fields(role):
    if role == 'span':
        return SPAN_FIELDS
    if role == 'dps':
        return [dict(name='PON', type='String', width=100)]
    for p in GOLD_PATHS:
        if os.path.exists(p):
            with open(p, encoding='utf-8') as f:
                return json.load(f)['layers'][GOLD_KEY[role]]['fields']
    raise WayleaveIOError('The HeroTel field list (gold_spec.json) is missing from the plugin.')


def _project_key():
    p = QgsProject.instance().fileName() or 'unsaved'
    return f"{SETTINGS}/projects/{abs(hash(os.path.normcase(p))) % 10 ** 10}"


def setting(name, default=None, per_project=True):
    return QgsSettings().value((_project_key() if per_project else SETTINGS) + '/' + name, default)


def set_setting(name, value, per_project=True):
    QgsSettings().setValue((_project_key() if per_project else SETTINGS) + '/' + name, value)


def vector_layers(geom=None):
    out = []
    for lyr in QgsProject.instance().mapLayers().values():
        if isinstance(lyr, QgsVectorLayer) and lyr.isValid():
            if geom is None or lyr.geometryType() == GEOM[geom]:
                out.append(lyr)
    return out


def find_layers():
    """role -> layer (or None). A pick saved for this project wins; then the name candidates."""
    proj = QgsProject.instance(); found = {}
    for role, (_, geom, names, _) in ROLES.items():
        lid = setting(f'layer/{role}', '')
        lyr = proj.mapLayer(lid) if lid else None
        if lyr is None or not lyr.isValid() or not isinstance(lyr, QgsVectorLayer) or lyr.geometryType() != GEOM[geom]:
            lyr = None
            cands = vector_layers(geom)
            for n in names:
                hit = [c for c in cands if c.name().strip().lower() == n]
                if hit:
                    lyr = hit[0]; break
            if lyr is None and role == 'aoi':
                lyr = next((c for c in cands if 'aoi' in c.name().lower()), None)
        found[role] = lyr
    return found


def save_layer_picks(found):
    for role, lyr in found.items():
        set_setting(f'layer/{role}', lyr.id() if lyr else '')


def utm_for(layer):
    tr = QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem(WGS84), QgsProject.instance())
    c = tr.transform(layer.extent().center())
    zone = int((c.x() + 180) // 6) + 1
    return QgsCoordinateReferenceSystem(f"EPSG:{(32700 if c.y() < 0 else 32600) + zone}")


def _lines(geom):
    if geom is None or geom.isEmpty():
        return []
    if geom.isMultipart():
        return [[(p.x(), p.y()) for p in part] for part in geom.asMultiPolyline()]
    return [[(p.x(), p.y()) for p in geom.asPolyline()]]


def _point(geom):
    if geom is None or geom.isEmpty():
        return None
    if geom.isMultipart():
        pts = geom.asMultiPoint()
        return (pts[0].x(), pts[0].y()) if pts else None
    p = geom.asPoint()
    return (p.x(), p.y())


def _polys(geom):
    if geom is None or geom.isEmpty():
        return []
    polys = geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]
    return [[[(p.x(), p.y()) for p in ring] for ring in poly] for poly in polys]


def _to(crs_from, crs_to):
    t = QgsCoordinateTransform(crs_from, crs_to, QgsProject.instance())

    def f(xy):
        q = t.transform(QgsPointXY(xy[0], xy[1]))
        return (q.x(), q.y())
    return f


def read_inputs(found):
    """Layers -> engine inputs. Raises WayleaveIOError with a plain message when something is missing."""
    missing = [ROLES[r][0] for r, (_, _, _, req) in ROLES.items() if req and found.get(r) is None]
    if missing:
        raise WayleaveIOError('Missing layer(s): ' + ', '.join(missing) + '. Pick them under "Layers".')
    cab_layers = [found[r] for r in ('feeder', 'link', 'dc') if found.get(r) is not None]
    crs0 = cab_layers[0].crs()
    if any(lyr.crs() != crs0 for lyr in cab_layers):
        raise WayleaveIOError('Feeder, Link and Distribution layers must use the same CRS, so new vertices can be added without moving yours.')
    for lyr in cab_layers:
        if QgsWkbTypes.isCurvedType(lyr.wkbType()):
            raise WayleaveIOError(f'"{lyr.name()}" holds curved lines. Generate only adds vertices to straight segments; save it as a LineString layer first.')
        if QgsWkbTypes.hasZ(lyr.wkbType()) or QgsWkbTypes.hasM(lyr.wkbType()):
            raise WayleaveIOError(f'"{lyr.name()}" has Z/M values. Use Vector > Geometry Tools > Drop M/Z Values, then try again.')
    metric = utm_for(found['feeder'])
    cables = []
    for role, kind, label in (('feeder', 'F', 'feeder cable'), ('link', 'L', 'link cable'), ('dc', 'D', 'distribution cable')):
        lyr = found.get(role)
        if lyr is None:
            continue
        tm = _to(lyr.crs(), metric)
        for f in lyr.getFeatures():
            g = f.geometry(); parts = _lines(g)
            if not parts:
                continue
            if any(len(p) < 2 for p in parts):
                raise WayleaveIOError(f'"{lyr.name()}" feature {f.id()} has a part with a single point. Delete that part '
                                      '(Vertex tool) so nothing of yours is dropped, then try again.')
            cables.append(dict(fid=f.id(), kind=kind, label=label, multi=g.isMultipart(), parts_l=parts,
                               parts_m=[[tm(v) for v in p] for p in parts]))
    s16 = []
    tm = _to(found['s16'].crs(), metric)
    for f in found['s16'].getFeatures():
        p = _point(f.geometry())
        if p:
            s16.append(dict(fid=f.id(), m=tm(p)))
    pons = []
    lyr = found['pons']; tm = _to(lyr.crs(), metric)
    names = lyr.fields().names(); idf = next((n for n in ('PON', 'id', 'ID', 'Name') if n in names), None)
    for f in lyr.getFeatures():
        polys = _polys(f.geometry())
        if polys:
            lab = f[idf] if idf else None
            pons.append(dict(fid=f.id(), label=str(lab) if lab not in (None, '') else str(f.id()),
                             area=[[[tm(v) for v in ring] for ring in poly] for poly in polys]))
    pop = None
    tm = _to(found['pop'].crs(), metric)
    for f in found['pop'].getFeatures():
        p = _point(f.geometry())
        if p:
            pop = tm(p); break
    roads = []
    if found.get('roads') is not None:
        tm = _to(found['roads'].crs(), metric)
        for f in found['roads'].getFeatures():
            roads += [[tm(v) for v in part] for part in _lines(f.geometry()) if len(part) >= 2]
    dps = []
    if found.get('dps') is not None:
        lyr = found['dps']; tm = _to(lyr.crs(), metric); names = lyr.fields().names()
        for f in lyr.getFeatures():
            p = _point(f.geometry())
            if p:
                try:
                    cnt = int(f['Count']) if 'Count' in names else 1
                except (TypeError, ValueError):
                    cnt = 1
                dps.append(dict(fid=f.id(), m=tm(p), type=(f['Type'] if 'Type' in names else None) or None, count=cnt))
    poles_count = found['poles'].featureCount() if found.get('poles') is not None else 0
    return dict(cables=cables, s16=s16, pons=pons, pop=pop, roads=roads, dps=dps, poles_count=poles_count)


def metric_to(found, crs):
    """metric (UTM) -> crs, as QgsPointXY, for markers."""
    t = QgsCoordinateTransform(utm_for(found['feeder']), crs, QgsProject.instance())
    return lambda xy: t.transform(QgsPointXY(xy[0], xy[1]))


# ── writing ──────────────────────────────────────────────────────────────────────

def _qfield(spec):
    t = spec['type']
    f = QgsField(spec['name'], _T.get(t, _T['String']))
    if t == 'Real':
        # a DBF number is at most 20 wide: the spec's 21 is refused by the shapefile driver without an error
        f.setLength(min(20, int(spec.get('width', 0) or 0))); f.setPrecision(int(spec.get('precision', 0) or 0))
    elif t == 'String':
        f.setLength(int(spec.get('width', 0) or 0))
    return f


def ensure_fields(layer, role):
    """Add the HeroTel fields this layer lacks (inside its edit buffer)."""
    have = set(layer.fields().names()); added = []
    for spec in gold_fields(role):
        if spec['name'] not in have:
            layer.addAttribute(_qfield(spec)); added.append(spec['name'])
    if added:
        layer.updateFields()
    lost = [n for n in added if layer.fields().indexOf(n) < 0]
    if lost:
        raise WayleaveIOError(f'"{layer.name()}" refused the field(s) {", ".join(lost)}. Nothing was saved; press Undo.')
    return added


def create_layer(role, crs, folder):
    """New empty shapefile for Poles / Span in `folder`, added to the top of the project."""
    os.makedirs(folder, exist_ok=True)
    base = ROLES[role][0]; path = os.path.join(folder, base + '.shp'); n = 2
    while os.path.exists(path):
        path = os.path.join(folder, f'{base} {n}.shp'); n += 1
    fields = QgsFields()
    for spec in gold_fields(role):
        fields.append(_qfield(spec))
    wkb = Qgis.WkbType.Point if role == 'poles' else Qgis.WkbType.LineString
    opts = QgsVectorFileWriter.SaveVectorOptions(); opts.driverName = 'ESRI Shapefile'; opts.fileEncoding = 'UTF-8'
    w = QgsVectorFileWriter.create(path, fields, wkb, crs, QgsProject.instance().transformContext(), opts)
    if w is None or w.hasError() != QgsVectorFileWriter.WriterError.NoError:
        raise WayleaveIOError(f'Could not create {path}: {w.errorMessage() if w else "unknown error"}')
    del w
    lyr = QgsVectorLayer(path, os.path.splitext(os.path.basename(path))[0], 'ogr')
    if not lyr.isValid():
        raise WayleaveIOError(f'Created {path} but QGIS cannot open it.')
    QgsProject.instance().addMapLayer(lyr, False)
    QgsProject.instance().layerTreeRoot().insertLayer(0, lyr)
    return lyr


def backup(found, root_folder, roles):
    """Copy every layer about to change (and the project file) to root_folder/<timestamp>. Returns the folder."""
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    dest = os.path.join(root_folder, f'Wayleave backup {stamp}')
    os.makedirs(dest, exist_ok=True)
    ctx = QgsProject.instance().transformContext(); written = []
    for role in roles:
        lyr = found.get(role)
        if lyr is None:
            continue
        safe = ROLES[role][0].replace(':', '-')
        opts = QgsVectorFileWriter.SaveVectorOptions(); opts.driverName = 'GPKG'; opts.layerName = safe; opts.fileEncoding = 'UTF-8'
        out = os.path.join(dest, safe + '.gpkg')
        res = QgsVectorFileWriter.writeAsVectorFormatV3(lyr, out, ctx, opts)
        if res[0] != QgsVectorFileWriter.WriterError.NoError:
            raise WayleaveIOError(f'Backup of "{lyr.name()}" failed: {res[1]}. Nothing was changed.')
        chk = QgsVectorLayer(f'{out}|layername={safe}', 'chk', 'ogr')
        n = chk.featureCount(); have = {f.lower() for f in chk.fields().names()}; del chk
        # 'fid' is the GeoPackage's own key column: a layer field of that name is stored as the key, not lost
        missing = [f for f in lyr.fields().names() if f.lower() not in have and f.lower() != 'fid']
        if n != lyr.featureCount() or missing:
            raise WayleaveIOError(f'Backup of "{lyr.name()}" is incomplete ({n} of {lyr.featureCount()} features'
                                  f'{"; fields missing: " + ", ".join(missing) if missing else ""}). Nothing was changed.')
        lyr.saveNamedStyle(os.path.join(dest, safe + '.qml'))
        written.append(f'{lyr.name()} ({n} features)')
    # styles of every layer Generate may restyle, so Undo can put the look back too
    for role in STYLE_ROLES:
        lyr = found.get(role)
        if lyr is not None and role not in roles:
            lyr.saveNamedStyle(os.path.join(dest, ROLES[role][0].replace(':', '-') + '.qml'))
    pf = QgsProject.instance().fileName()
    if pf and os.path.exists(pf):
        shutil.copy2(pf, os.path.join(dest, os.path.basename(pf)))
    with open(os.path.join(dest, 'README.txt'), 'w', encoding='utf-8') as f:
        f.write('Backup taken by Velocity Nexus "Generate finished Wayleave" before it changed these layers:\n'
                + '\n'.join(' - ' + w for w in written) + '\n\nEach .gpkg holds the layer exactly as it was and the .qml its style.\n'
                'Before you save, Undo in the Wayleave panel (or Roll Back Edits) puts everything back.\n'
                'After you saved, drag a .gpkg into QGIS to recover a layer from here.\n')
    return dest


def apply(found, res, progress=None):
    """Write the engine result into the layers' edit buffers. Returns {layer name: what changed}."""
    say = progress or (lambda pct, msg: None)
    done = {}
    to84 = lambda lyr: QgsCoordinateTransform(lyr.crs(), QgsCoordinateReferenceSystem(WGS84), QgsProject.instance())

    def begin(lyr):
        if not lyr.isEditable():
            lyr.startEditing()
        lyr.beginEditCommand('Generate finished wayleave')

    # cables: new vertices (shape unchanged) + attributes
    for role, kind in (('feeder', 'F'), ('link', 'L'), ('dc', 'D')):
        lyr = found.get(role)
        if lyr is None:
            continue
        say(10 + len(done) * 8, f'Writing {lyr.name()}')
        begin(lyr); added = ensure_fields(lyr, role)
        idx = {n: lyr.fields().indexOf(n) for n in lyr.fields().names()}
        nv = 0
        for c in res['cables']:
            if c['kind'] != kind:
                continue
            parts = [[QgsPointXY(x, y) for x, y in p] for p in c['parts_l']]
            g = QgsGeometry.fromMultiPolylineXY(parts) if c['multi'] else QgsGeometry.fromPolylineXY(parts[0])
            _must(lyr.changeGeometry(c['fid'], g), lyr, f"geometry of feature {c['fid']}"); nv += 1
            vals = res['attrs'].get(role, {}).get(c['fid'], {})
            _must(lyr.changeAttributeValues(c['fid'], {idx[k]: v for k, v in vals.items() if k in idx}), lyr, f"attributes of feature {c['fid']}")
        lyr.endEditCommand(); done[lyr.name()] = f'{nv} cables updated; fields added: {", ".join(added) or "none"}'
    # 1:16, PONs, demand points: attributes only
    for role in ('s16', 'pons', 'dps'):
        lyr = found.get(role)
        if lyr is None:
            continue
        say(40 + len(done) * 4, f'Writing {lyr.name()}')
        begin(lyr); added = ensure_fields(lyr, role)
        idx = {n: lyr.fields().indexOf(n) for n in lyr.fields().names()}
        rows = res['attrs'].get(role, {}); t84 = to84(lyr)
        for fid, vals in rows.items():
            vals = dict(vals)
            if role == 's16' and 'x' in idx:
                p = _point(lyr.getFeature(fid).geometry())
                if p:
                    w = t84.transform(QgsPointXY(*p)); vals['x'], vals['y'] = round(w.x(), 10), round(w.y(), 10)
            _must(lyr.changeAttributeValues(fid, {idx[k]: v for k, v in vals.items() if k in idx}), lyr, f'attributes of feature {fid}')
        lyr.endEditCommand(); done[lyr.name()] = f'{len(rows)} rows filled; fields added: {", ".join(added) or "none"}'
    # poles + span: rebuilt from scratch
    cab_crs = found['feeder'].crs(); t84 = to84(found['feeder'])
    for role in ('poles', 'span'):
        lyr = found[role]
        say(70 if role == 'poles' else 85, f'Writing {lyr.name()}')
        begin(lyr); added = ensure_fields(lyr, role)
        old = [f.id() for f in lyr.getFeatures()]
        if old:
            _must(lyr.deleteFeatures(old), lyr, 'removing the old features')
        tr = QgsCoordinateTransform(cab_crs, lyr.crs(), QgsProject.instance())
        feats = []
        for item in (res['poles'] if role == 'poles' else res['spans']):
            f = QgsFeature(lyr.fields())
            if role == 'poles':
                g = QgsGeometry.fromPointXY(QgsPointXY(*item['l']))
                w = t84.transform(QgsPointXY(*item['l']))
                vals = dict(item['attrs'], x=round(w.x(), 10), y=round(w.y(), 10))
            else:
                g = QgsGeometry.fromPolylineXY([QgsPointXY(*v) for v in item['l']]); vals = item['attrs']
            if lyr.crs() != cab_crs:
                g.transform(tr)
            f.setGeometry(g)
            for k, v in vals.items():
                i = lyr.fields().indexOf(k)
                if i >= 0:
                    f.setAttribute(i, v)
            feats.append(f)
        _must(lyr.addFeatures(feats), lyr, 'adding the new features')
        lyr.endEditCommand(); done[lyr.name()] = f'{len(old)} removed, {len(feats)} added'
    return done


def _must(ok, lyr, what):
    if not ok:
        raise WayleaveIOError(f'"{lyr.name()}" refused {what}.')


def edited_layers(found):
    return [lyr for lyr in {id(v): v for v in found.values() if v is not None}.values() if lyr.isEditable() and lyr.isModified()]


def keep(found):
    """Save every layer Generate changed. Returns the names of layers that failed to save."""
    bad = []
    for lyr in edited_layers(found):
        if not lyr.commitChanges():
            bad.append(f"{lyr.name()}: {'; '.join(lyr.commitErrors())[:200]}")
    return bad


def undo(found, backup_dir=None, created=(), themes_before=None):
    """Put everything back: roll back the edit buffers, reload each layer's style from the backup,
    restore or remove the map themes, and take layers Generate created out of the project
    (their new empty files stay on disk, in the folder you chose)."""
    for lyr in edited_layers(found):
        lyr.rollBack()
        lyr.triggerRepaint()
    if backup_dir:
        for role, lyr in found.items():
            qml = os.path.join(backup_dir, ROLES[role][0].replace(':', '-') + '.qml')
            if lyr is not None and lyr not in created and os.path.exists(qml):
                lyr.loadNamedStyle(qml); lyr.triggerRepaint()
    if themes_before is not None:
        col = QgsProject.instance().mapThemeCollection()
        for name in ('Network', 'Wayleave'):
            if name in themes_before:
                col.update(name, themes_before[name])
            elif col.hasMapTheme(name):
                col.removeMapTheme(name)
    for lyr in created:
        if lyr is not None and QgsProject.instance().mapLayer(lyr.id()) is not None:
            if lyr.isEditable():
                lyr.rollBack()
            QgsProject.instance().removeMapLayer(lyr.id())


def themes_snapshot():
    col = QgsProject.instance().mapThemeCollection()
    return {n: col.mapThemeState(n) for n in ('Network', 'Wayleave') if col.hasMapTheme(n)}


def apply_styles(found):
    """Vrede wayleave symbology on each layer (a fresh renderer from the bundled .qml)."""
    styled = []
    for role in STYLE_ROLES:
        lyr = found.get(role); qml = os.path.join(STYLES, role + '.qml')
        if lyr is None or not os.path.exists(qml):
            continue
        cats = QgsMapLayer.StyleCategory.Symbology
        if not (role == 'erven' and 'PARCEL_NO' not in lyr.fields().names()):
            cats = cats | QgsMapLayer.StyleCategory.Labeling   # no parcel field: keep the outline, skip the label
        _msg, ok = lyr.loadNamedStyle(qml, cats)
        if ok:
            lyr.triggerRepaint(); styled.append(lyr.name())
    return styled


def make_themes(found):
    """Vrede's two map themes: Network (everything) and Wayleave (Span + poles + erven, cables hidden)."""
    proj = QgsProject.instance(); root = proj.layerTreeRoot(); col = proj.mapThemeCollection()
    base = [n.layer() for n in root.findLayers() if n.layer() is not None
            and isinstance(n.layer(), QgsRasterLayer) and n.isVisible()]
    sets = {'Network': [found.get(r) for r in ('span', 'pons', 'feeder', 'roads', 'pop', 'erven', 'link', 'dps', 'poles', 'aoi', 's16', 'dc')],
            'Wayleave': [found.get(r) for r in ('span', 'roads', 'pop', 'erven', 'poles', 'aoi')]}
    for name, lyrs in sets.items():
        rec = QgsMapThemeCollection.MapThemeRecord()
        rec.setLayerRecords([QgsMapThemeCollection.MapThemeLayerRecord(lyr) for lyr in lyrs + base if lyr is not None])
        if col.hasMapTheme(name):
            col.update(name, rec)
        else:
            col.insert(name, rec)
    return list(sets)


def put_markers(found, issues, name='Wayleave Check (temporary)'):
    """Check results as a temporary scratch layer (memory only, never saved, never touches your data)."""
    proj = QgsProject.instance()
    for lyr in proj.mapLayersByName(name):
        if lyr.providerType() == 'memory' and lyr.customProperty('velocity_wayleave_check'):
            proj.removeMapLayer(lyr.id())
    crs = found['feeder'].crs() if found.get('feeder') is not None else QgsCoordinateReferenceSystem(WGS84)
    lyr = QgsVectorLayer(f'Point?crs={crs.authid()}&field=No:integer&field=Level:string(10)&field=Issue:string(254)', name, 'memory')
    tr = metric_to(found, crs); feats = []
    for n, i in enumerate([i for i in issues if i.get('at') is not None], 1):
        f = QgsFeature(lyr.fields()); f.setGeometry(QgsGeometry.fromPointXY(tr(i['at'])))
        f.setAttributes([n, i['level'], i['msg'][:254]]); feats.append(f)
        i['no'] = n
    lyr.dataProvider().addFeatures(feats); lyr.updateExtents()
    _marker_style(lyr); lyr.setCustomProperty('velocity_wayleave_check', True)
    proj.addMapLayer(lyr, False); proj.layerTreeRoot().insertLayer(0, lyr)
    return lyr


def _marker_style(lyr):
    """Red / amber / blue rings by level, numbered; built from fresh symbols, no style file."""
    from qgis.core import (QgsCategorizedSymbolRenderer, QgsMarkerSymbol, QgsPalLayerSettings, QgsRendererCategory,
                           QgsTextBufferSettings, QgsTextFormat, QgsVectorLayerSimpleLabeling)
    cats = []
    for value, label, fill, line, size in (('error', 'Error', '229,57,53,70', '229,57,53,255', '7'),
                                            ('warn', 'Warning', '245,166,35,60', '230,140,0,255', '5'),
                                            ('info', 'Note', '31,143,176,50', '31,143,176,255', '4')):
        sym = QgsMarkerSymbol.createSimple({'name': 'circle', 'color': fill, 'outline_color': line,
                                            'outline_width': '0.7', 'size': size})
        cats.append(QgsRendererCategory(value, sym, label))
    lyr.setRenderer(QgsCategorizedSymbolRenderer('Level', cats))
    pal = QgsPalLayerSettings(); pal.fieldName = "'#' || \"No\""; pal.isExpression = True
    fmt = QgsTextFormat(); fmt.setSize(9)
    buf = QgsTextBufferSettings(); buf.setEnabled(True); buf.setSize(1); fmt.setBuffer(buf)
    pal.setFormat(fmt)
    lyr.setLabeling(QgsVectorLayerSimpleLabeling(pal)); lyr.setLabelsEnabled(True)


def town_default():
    base = os.path.splitext(os.path.basename(QgsProject.instance().fileName() or ''))[0]
    letters = ''.join(ch for ch in base.upper() if ch.isalpha())
    return letters[:3] or 'XXX'
