"""guardian_panel — a local viewer for Geometry Guardian incidents.

Shows what the Geometry Guardian caught + auto-restored on THIS machine, read
from ~/.velocity_nexus/guardian_incidents.json. Purely LOCAL and READ-ONLY — it
never touches the ticket queue or the network. So the operator (and JJ) can see
"what went wrong and what was saved" at a glance, with the full crash report
(breadcrumb + stack), without anything being filed or sent.
"""
import os
import json

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QListWidget, QListWidgetItem,
    QPlainTextEdit, QPushButton, QSplitter,
)

_INCIDENT_FILE = os.path.join(os.path.expanduser("~"), ".velocity_nexus",
                              "guardian_incidents.json")
_prev = [None]   # ref to the last dialog so we can close it (WA_DeleteOnClose leak fix)

# Mission-Control palette (self-styled so it reads in BOTH light + dark QGIS)
_BG = "#0d0f12"
_PANEL = "#14181d"
_INK = "#e6edf3"
_DIM = "#8b98a5"
_CYAN = "#22d3ee"
_AMBER = "#f59e0b"
_GREEN = "#34d399"
_MONO = "Consolas, 'JetBrains Mono', monospace"


def load_incidents():
    """Read the local incident log (newest last in file). Best-effort."""
    try:
        with open(_INCIDENT_FILE, encoding="utf-8") as f:
            rows = json.load(f)
        return rows if isinstance(rows, list) else []
    except Exception:
        return []


def _fmt_time(iso):
    if not iso:
        return "—"
    s = str(iso).replace("T", " ")
    return s[:19]   # YYYY-MM-DD HH:MM:SS


class GuardianPanel(QDialog):
    def __init__(self, iface=None, parent=None):
        super().__init__(parent)
        self._iface = iface
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self.setWindowTitle("Geometry Guardian — Incidents")
        self.resize(940, 580)
        self.setStyleSheet(f"""
            QDialog {{ background:{_BG}; }}
            QLabel {{ color:{_INK}; }}
            QListWidget {{ background:{_PANEL}; color:{_INK}; border:1px solid #232a31;
                           border-radius:8px; font-family:{_MONO}; font-size:12px;
                           outline:none; }}
            QListWidget::item {{ padding:8px 10px; border-bottom:1px solid #1c2228; }}
            QListWidget::item:selected {{ background:#0f2730; color:{_CYAN}; }}
            QPlainTextEdit {{ background:{_PANEL}; color:{_INK}; border:1px solid #232a31;
                              border-radius:8px; font-family:{_MONO}; font-size:12px; padding:8px; }}
            QPushButton {{ background:#1b2128; color:{_INK}; border:1px solid #2a323a;
                           border-radius:7px; padding:6px 14px; font-weight:600; }}
            QPushButton:hover {{ border-color:{_CYAN}; color:{_CYAN}; }}
        """)
        self._build()
        # Velocity red-✕ title bar (frameless + draggable). Fail-open: if it can't
        # chrome safely the dialog stays framed + fully working.
        try:
            from .nexus_dock import chrome_dialog
            chrome_dialog(self, "🛡  GEOMETRY GUARDIAN  //  INCIDENTS")
        except Exception:
            pass
        self._reload()

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(14, 14, 14, 14)
        root.setSpacing(10)

        # header
        head = QHBoxLayout()
        title = QLabel("\U0001f6e1  GEOMETRY GUARDIAN  //  INCIDENTS")
        title.setStyleSheet(f"color:{_CYAN}; font-family:{_MONO}; font-size:15px; font-weight:700;")
        head.addWidget(title)
        head.addStretch(1)
        self._count = QLabel("")
        self._count.setStyleSheet(f"color:{_DIM}; font-family:{_MONO};")
        head.addWidget(self._count)
        root.addLayout(head)

        sub = QLabel("Mass geometry losses NOT caused by the operator — caught and "
                     "auto-restored on this machine. Read-only; nothing here is sent.")
        sub.setStyleSheet(f"color:{_DIM};")
        sub.setWordWrap(True)
        root.addWidget(sub)

        # split: list | detail
        split = QSplitter(Qt.Orientation.Horizontal)
        self._list = QListWidget()
        self._list.currentItemChanged.connect(self._on_select)
        split.addWidget(self._list)
        self._detail = QPlainTextEdit()
        self._detail.setReadOnly(True)
        split.addWidget(self._detail)
        split.setSizes([360, 580])
        root.addWidget(split, 1)

        # footer
        foot = QHBoxLayout()
        self._empty = QLabel("")
        self._empty.setStyleSheet(f"color:{_GREEN}; font-family:{_MONO};")
        foot.addWidget(self._empty)
        foot.addStretch(1)
        btn_open = QPushButton("Open log folder")
        btn_open.clicked.connect(self._open_folder)
        foot.addWidget(btn_open)
        btn_refresh = QPushButton("Refresh")
        btn_refresh.clicked.connect(self._reload)
        foot.addWidget(btn_refresh)
        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.close)
        foot.addWidget(btn_close)
        root.addLayout(foot)

    def _reload(self):
        rows = load_incidents()
        rows = list(reversed(rows))   # newest first
        self._list.clear()
        self._count.setText(f"{len(rows)} incident(s)")
        if not rows:
            self._empty.setText("\U0001f7e2  No incidents — nothing has gone wrong on this machine.")
            self._detail.setPlainText("")
            return
        self._empty.setText("")
        for inc in rows:
            lost = inc.get("lost", 0)
            restored = inc.get("restored", 0)
            full = restored >= lost and lost > 0
            arrow = f"{lost}→{restored} restored"
            label = f"{_fmt_time(inc.get('ts_iso'))}   {inc.get('layer','?')}   {arrow}"
            it = QListWidgetItem(label)
            it.setData(Qt.ItemDataRole.UserRole, inc)
            it.setForeground(_qcolor(_GREEN if full else _AMBER))
            self._list.addItem(it)
        self._list.setCurrentRow(0)

    def _on_select(self, cur, _prev_item=None):
        if cur is None:
            self._detail.setPlainText("")
            return
        inc = cur.data(Qt.ItemDataRole.UserRole) or {}
        ctx = inc.get("context") or []
        lines = [
            "=== GEOMETRY GUARDIAN — INCIDENT ===",
            "",
            f"Layer:     {inc.get('layer','?')}",
            f"Lost:      {inc.get('lost')}    Restored: {inc.get('restored')}",
            f"Counts:    before={inc.get('before')}  after={inc.get('after')}",
            f"In edit:   {inc.get('in_edit')}",
            f"Project:   {inc.get('project')}",
            f"When:      {inc.get('ts_iso')}",
            "",
            "WHAT THE PLUGIN WAS DOING (oldest -> newest):",
        ]
        lines += [f"   - {c}" for c in ctx[-20:]] or ["   (no breadcrumb)"]
        lines += ["", "STACK AT DETECTION:", inc.get("stack", "") or "(none)"]
        self._detail.setPlainText("\n".join(lines))

    def _open_folder(self):
        try:
            folder = os.path.dirname(_INCIDENT_FILE)
            os.makedirs(folder, exist_ok=True)
            from qgis.PyQt.QtGui import QDesktopServices
            from qgis.PyQt.QtCore import QUrl
            QDesktopServices.openUrl(QUrl.fromLocalFile(folder))
        except Exception:
            pass


def _qcolor(hex_str):
    from qgis.PyQt.QtGui import QColor
    return QColor(hex_str)


def show_guardian_incidents(iface=None):
    """Open (or re-open) the Guardian incidents panel. Closes any previous one so
    it can't pile up hidden windows (WA_DeleteOnClose). Best-effort."""
    try:
        if _prev[0] is not None:
            try:
                _prev[0].close()
            except Exception:
                pass
        parent = iface.mainWindow() if iface else None
        dlg = GuardianPanel(iface, parent)
        _prev[0] = dlg
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()
        return dlg
    except Exception:
        return None
