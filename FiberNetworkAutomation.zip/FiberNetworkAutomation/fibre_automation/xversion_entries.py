"""Cross-version project entries: give QGIS < 3.44 back what a 3.44+ save wrote.

QGIS 3.44 (PR #60855) changed how project properties are written:

    old (3.43 and older)                     new (3.44+, every 4.x)
    <properties>                             <properties>
      <VelocityNexus>                          <properties name="VelocityNexus">
        <v3_marker type="QString">x</...>        <properties name="v3_marker" type="QString">x</properties>

3.44+ reads both layouts.  3.43 and older read only the old one, so a project saved on 4.2 and opened on
3.38 / 3.40 keeps its layers, styles and layouts but every project entry comes back empty: Atlas page
sets, page pictures, the Nexus session, Splice Viewer and Network Planner state.

The shim: on QGIS < 3.44, when a project has been read, look at the new-layout block of that same
project document and write every Nexus entry the open project is missing back into it, typed as saved.
The project file on disk is never written, and the project is left exactly as clean or dirty as it was.
QGIS's own scopes (Measurement, PAL, Paths, Gui, ...) are only reported, never restored.  On 3.44+ the
shim does nothing.

``parse_new_layout`` and ``plan_restore`` are pure Python (no QGIS) so they test anywhere.
"""
import xml.etree.ElementTree as ET
import zipfile

from .shared.swallowed import note as _note

# Every project-entry scope the plugin writes.  tests/contracts/test_xversion_scopes.py scans the code
# for writeEntry() scopes and fails when one is missing here, so this list cannot rot silently.
NEXUS_SCOPES = (
    "FiberNetworkAutomation",   # fibre_automation/startup.py session (_NS)
    "VelocityNexus",            # Atlas page sets, page pictures
    "VelocityFibre",            # workflow ft_done, Network Planner flags + force_cross
    "velocity_nexus",           # deliver/aoi_layer
    "velocity",                 # Network Planner np_session
    "VelocityClickLine",        # click pole walk revert record
    "SpliceViewer",             # soloSaved
    "FTTHPlanTool",             # Network Planner output_gpkg
)

FIXED_VERSION = 34400           # Qgis.versionInt() from which QGIS reads the new layout itself
ENV_OFF = "VF_XVERSION_SHIM_OFF"  # set to 1 to switch the shim off (planted-control runs)

_TYPES = ("QString", "int", "double", "bool", "QStringList")


def needs_shim(version_int):
    return int(version_int) < FIXED_VERSION


def _leaf(el):
    """(type, value) of a typed leaf element, or None for a group."""
    typ = el.get("type")
    if typ is None:
        return None
    if typ == "QStringList":
        return typ, [(v.text or "") for v in el if v.tag == "value"]
    return typ, el.text or ""


def _walk(el, prefix, out):
    for child in el:
        if child.tag != "properties":
            continue
        name = child.get("name")
        if not name:
            continue
        path = prefix + "/" + name if prefix else name
        leaf = _leaf(child)
        if leaf is not None:
            out.append((path, leaf[0], leaf[1]))
        else:
            _walk(child, path, out)


def parse_new_layout(props_el):
    """{scope: [(key path, type, value), ...]} from a project's top-level <properties> element.

    Only new-layout children (<properties name=...>) are read; an old-layout block gives {}.
    """
    scopes = {}
    if props_el is None:
        return scopes
    for scope_el in props_el:
        if scope_el.tag != "properties" or not scope_el.get("name"):
            continue
        items = []
        leaf = _leaf(scope_el)
        if leaf is not None:          # a value written straight on the scope (rare); keep it addressable
            items.append(("", leaf[0], leaf[1]))
        _walk(scope_el, "", items)
        scopes[scope_el.get("name")] = items
    return scopes


def properties_element(xml_text):
    """The top-level <properties> element of a .qgs document (text or bytes), or None."""
    root = ET.fromstring(xml_text)
    return root.find("properties")


def read_project_xml(path):
    """The .qgs XML of a .qgs or .qgz file, read-only (bytes).  Raises on a missing/odd file."""
    p = str(path)
    if p.lower().endswith(".qgz"):
        with zipfile.ZipFile(p) as z:
            names = [n for n in z.namelist() if n.lower().endswith(".qgs")]
            if not names:
                raise ValueError("no .qgs inside " + p)
            return z.read(names[0])
    with open(p, "rb") as f:
        return f.read()


def plan_restore(scopes, has_entry, nexus_scopes=NEXUS_SCOPES):
    """Split the parsed file into (to restore, core scopes lost).

    ``has_entry(scope, key) -> bool`` asks the open project.  To restore = Nexus entries the project
    lacks; core lost = non-Nexus scope names with at least one entry the project lacks (report only).
    """
    restore, core_lost = [], []
    for scope, items in scopes.items():
        missing = [it for it in items if it[0] and not has_entry(scope, it[0])]
        if not missing:
            continue
        if scope in nexus_scopes:
            restore.extend((scope,) + it for it in missing)
        else:
            core_lost.append(scope)
    return restore, sorted(core_lost)


def _typed(typ, value):
    if typ == "int":
        try:
            return int(value)
        except ValueError:
            return value
    if typ == "double":
        try:
            return float(value)
        except ValueError:
            return value
    if typ == "bool":
        return str(value).strip().lower() in ("true", "1")
    return value


# ---------------------------------------------------------------- QGIS side

def _has_entry(project):
    def has(scope, key):
        try:
            if project.readEntry(scope, key, "")[1]:          # ok is True only when the entry exists
                return True
            return bool(project.readListEntry(scope, key, [])[1])   # 3.x readEntry says ok=False for a list
        except Exception:
            _note()
            return True             # cannot tell: treat as present, so the shim never overwrites (fail closed)
    return has


def _write(project, scope, key, typ, value):
    v = _typed(typ, value)
    if typ == "bool":
        return project.writeEntryBool(scope, key, v)
    if typ == "double" and isinstance(v, float):
        return project.writeEntryDouble(scope, key, v)
    return project.writeEntry(scope, key, v)


def restore_from_element(project, props_el):
    """Restore missing Nexus entries into ``project`` from a parsed <properties> element.

    Returns {"restored": n, "core_lost": [...]}.  Never changes the project's dirty state.
    """
    scopes = parse_new_layout(props_el)
    if not scopes:
        return {"restored": 0, "core_lost": []}
    todo, core_lost = plan_restore(scopes, _has_entry(project))
    was_dirty = project.isDirty()
    n = 0
    try:
        for scope, key, typ, value in todo:
            if _write(project, scope, key, typ, value):
                n += 1
    finally:                        # a write that raises half-way must not leave a clean project marked changed
        if not was_dirty and project.isDirty():
            project.setDirty(False)
    return {"restored": n, "core_lost": core_lost}


def _props_from_qdom(doc):
    """The top-level <properties> of a QDomDocument as an ElementTree element (small copy only)."""
    from qgis.PyQt.QtXml import QDomDocument
    props = doc.documentElement().firstChildElement("properties")
    if props.isNull():
        return None
    small = QDomDocument()
    small.appendChild(small.importNode(props, True))
    return ET.fromstring(small.toString())


def _enabled():
    import os
    if os.environ.get(ENV_OFF, "").strip() in ("1", "true", "yes"):
        return False
    from qgis.core import Qgis
    return needs_shim(Qgis.versionInt())


def _report(result):
    if result.get("restored"):
        print("[FiberNet] cross-version: restored %d Nexus project entr%s saved by a newer QGIS"
              % (result["restored"], "y" if result["restored"] == 1 else "ies"))
    lost = result.get("core_lost") or []
    if not lost:
        return
    msg = ("This project was saved on QGIS 3.44 or newer. This QGIS cannot read some of its own project "
           "settings (%s); they use defaults here. Nexus data is kept." % ", ".join(lost))
    print("[FiberNet] cross-version: " + msg)
    try:
        from qgis.utils import iface
        from qgis.core import Qgis
        if iface is not None:
            level = getattr(Qgis, "MessageLevel", Qgis).Warning    # scoped on Qt6 builds
            iface.messageBar().pushMessage("Velocity Nexus", msg, level, 12)
    except Exception:
        from fibre_automation.shared.swallowed import note
        note()                                            # the print above already told the log


def on_read_project(doc, project=None):
    """readProject(QDomDocument) slot.  Fail-silent: a shim error must never break a project open."""
    try:
        if not _enabled():
            return None
        from qgis.core import QgsProject
        project = project or QgsProject.instance()
        result = restore_from_element(project, _props_from_qdom(doc))
        _report(result)
        return result
    except Exception as e:
        print("[FiberNet] cross-version shim skipped: %s" % e)
        return None


def _no_nexus_entries(project):
    """True when the open project holds no entry in any Nexus scope: the symptom of the 3.44+ -> 3.x loss.  Any Nexus entry
    means the plugin or the user already wrote state in this session, so the file on disk may be older than it: skip."""
    try:
        return not any(project.entryList(sc, "") or project.subkeyList(sc, "") for sc in NEXUS_SCOPES)
    except Exception:
        _note()
        return False


def restore_open_project(project=None):
    """For a project that was already open before the plugin loaded: read its file (read-only)."""
    try:
        if not _enabled():
            return None
        from qgis.core import QgsProject
        project = project or QgsProject.instance()
        path = project.fileName()
        if not path or project.isDirty() or not _no_nexus_entries(project):
            return None             # unsaved, edited in memory, or Nexus state already present: never guess
        result = restore_from_element(project, properties_element(read_project_xml(path)))
        _report(result)
        return result
    except Exception as e:
        print("[FiberNet] cross-version shim skipped: %s" % e)
        return None

