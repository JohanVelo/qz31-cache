"""profile — the signed-in user's identity + local persistence.

Holds username/display_name/theme/accent, persists to QgsSettings under the
existing VelocityFibre/* namespace, and registers the user/install with the
backend (queued in dry-run). All names the UI shows come from here — never
hardcoded.
"""
import json

from . import config, hashing, identity


def _settings():
    from qgis.core import QgsSettings
    return QgsSettings()


def _get(key):
    v = _settings().value(f"{config.SETTINGS_NS}/{key}")
    return v if v not in (None, "") else None


def _set(key, value):
    _settings().setValue(f"{config.SETTINGS_NS}/{key}", value)


class Profile:
    """Current operator. Construct via load() / create()."""

    def __init__(self, username, display_name=None, theme="velocity",
                 accent=None, created_at=None):
        self.username = username
        self.display_name = display_name or username
        self.theme = theme
        self.accent = accent
        self.created_at = created_at

    # ── persistence ─────────────────────────────────────────────────────────
    def save_local(self):
        _set(config.KEY_USERNAME, self.username)
        _set(config.KEY_PROFILE, json.dumps({
            "display_name": self.display_name,
            "theme": self.theme,
            "accent": self.accent,
            "created_at": self.created_at,
        }))

    @staticmethod
    def load_local():
        """Return a Profile if a user is signed in on this machine, else None."""
        username = _get(config.KEY_USERNAME)
        if not username:
            return None
        try:
            blob = json.loads(_get(config.KEY_PROFILE) or "{}")
        except ValueError:
            blob = {}
        return Profile(username,
                       display_name=blob.get("display_name"),
                       theme=blob.get("theme", "velocity"),
                       accent=blob.get("accent"),
                       created_at=blob.get("created_at"))

    @staticmethod
    def sign_out():
        _set(config.KEY_USERNAME, "")

    @staticmethod
    def install_id():
        return identity.get_or_create_install_id(_get, _set)


def team_code_ok(entered):
    """True if the entered team code matches the shipped hash. If no hash is
    configured yet (pre-Phase-1), accept anything so dev can proceed."""
    if not config.TEAM_CODE_HASH:
        return True
    return hashing.sha256_hex(entered) == config.TEAM_CODE_HASH


def register(backend, username, password, display_name=None,
             qgis_version="", plugin_version=""):
    """Create the profile locally + register user/install with the backend
    (queued in dry-run). Returns the new Profile. Caller has already validated
    the team code and that the username/password are non-empty."""
    pw_hash, salt = hashing.hash_password(password)
    from datetime import datetime, timezone
    created = datetime.now(timezone.utc).isoformat()

    prof = Profile(username, display_name=display_name)
    prof.created_at = created
    prof.save_local()

    iid = Profile.install_id()
    backend.insert("users", {
        "username": username,
        "display_name": prof.display_name,
        "pw_hash": pw_hash,
        "pw_salt": salt,
        "plugin_version": plugin_version,
        "schema_version": config.SCHEMA_VERSION,
    })
    backend.insert("installs", {
        "install_id": iid,
        "username": username,
        "qgis_version": qgis_version,
        "plugin_version": plugin_version,
    })
    backend.insert("user_consent", {
        "username": username,
        "version": config.CONSENT_VERSION,
    })
    _set(config.KEY_CONSENT, config.CONSENT_VERSION)
    return prof
