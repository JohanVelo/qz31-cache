"""Dock widget for FTTH Plan Tool."""

import os
from qgis.PyQt import sip
from qgis.core import Qgis  # Qt6: messageBar/log levels are Qgis.MessageLevel enums
import time

from qgis.PyQt import QtWidgets, uic
from qgis.PyQt.QtCore import pyqtSignal, Qt
try:
    from .. import theme_safe
except ImportError:
    pass   # standalone fallback
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import QApplication
from qgis.core import (
    QgsVectorLayer, QgsWkbTypes, QgsProject, QgsGeometry, QgsPointXY,
    QgsField, QgsSpatialIndex, QgsMarkerSymbol, QgsSingleSymbolRenderer,
    QgsCategorizedSymbolRenderer, QgsLineSymbol,
    QgsCoordinateTransform,
    QgsDistanceArea,
)
from qgis.gui import QgsMapToolEmitPoint, QgsMapTool, QgsRubberBand

from .layer_utils import (
    get_layer_features,
    get_point_coordinates,
    get_linestring_coordinates,
    create_memory_layer,
    add_fields_to_layer,
    add_line_feature,
    count_features_by_geometry_type
)
from .core import NetworkGraph, _snap_coord
# Aliased to vf_fields, NOT field_names: 'field_names' is already used as a local
# variable/parameter name 34 times in this file and importing it plainly would
# shadow the module at those call sites.
from . import field_names as vf_fields
# ONE definition of what a PON is called, shared with the merge tool's name
# resync. Seven places in this file used to write the literal f"Zone {n}"
# straight into a feature attribute — those are DATA, not labels, and a blind
# find/replace on the word "Zone" would have changed stored values silently.
from .pon_merge import pon_name_for as vf_pon_name
from .erf_grouping import (
    get_batch_statistics,
    find_optimal_splitter_locations,
    cluster_tight_groups_of_8,
    group_zones_from_groups,
    SKLEARN_AVAILABLE,
    NUMPY_AVAILABLE
)

# Cable profile functions (embedded until cable_profiles.py can be created)
import math
import bisect
import re

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass


def _safe_ellipsoid(project, crs=None):
    """The ellipsoid to really use — never 'NONE'.

    QgsProject.ellipsoid() returns the STRING 'NONE' when a project has no
    ellipsoid set (QGIS's default for a new project). 'NONE' is truthy, so
    `project.ellipsoid() or "WGS84"` does NOT fall back — it sets "NONE", and a
    geographic CRS then measures in DEGREES: a 1976 m cable measures 0.019, so
    every span/drop/feeder length here would be wrong by ~100000x, silently.
    Found 2026-07-15. See fibre_automation/shared/crs_utils.safe_ellipsoid.
    """
    try:
        from ..fibre_automation.shared.crs_utils import safe_ellipsoid
        return safe_ellipsoid(project, crs)
    except Exception:
        pass
    try:
        from fibre_automation.shared.crs_utils import safe_ellipsoid
        return safe_ellipsoid(project, crs)
    except Exception:
        pass
    for get in (lambda: project.ellipsoid(),
                (lambda: crs.ellipsoidAcronym()) if crs is not None else None):
        if get is None:
            continue
        try:
            v = (get() or "").strip()
        except Exception:
            continue
        if v and v.upper() != "NONE":
            return v
    return "WGS84"




def snap_point_to_project(canvas, pt):
    """Snap a map-CRS QgsPointXY to the project's active QGIS snapping (the native
    'Enable Snapping' toggle + snapping toolbar settings). Returns the snapped point
    when there's a valid match, otherwise the original point unchanged.

    Shared by every Velocity Nexus map tool (place splitter / demand point, draw span,
    move splitter, create enclosure, …) so that turning on QGIS snapping makes ALL of
    them snap — not just one tool. Fail-safe: any error → original point.
    """
    try:
        from qgis.core import QgsPointXY
        _m = canvas.snappingUtils().snapToMap(pt)
        if _m.isValid():
            _p = _m.point()
            return QgsPointXY(_p.x(), _p.y())
    except Exception:
        pass
    return pt

# #79: a demand point's group-link field must be detected by PATTERN, never a
# hardcoded size list. Groups are created as f'group_{target_size}' (dock ~2895),
# so HeroTel projects use group_32 / group_64 etc. The drop generators used to
# look only for ['group_8','group_16','group_128','group_100','batch_id'] — so on
# any other splitter size NO demand point matched, group_id came back None, and
# every drop was skipped ("drops don't generate to their dedicated splitter on
# all the buttons"). 'group_id' is the SPLITTER's field and is excluded here.
# Zone->PON rename (2026-07-23): size-keyed splitter columns are created as
# spl_<N> going forward (group_<N> historically) — see field_names.py for why the
# short prefix is mandatory rather than splitter_<N>. This pattern matches BOTH
# generations so a project written by either version still resolves its drops.
_DROP_GRP_RE = vf_fields.SIZE_FIELD_RE

# Beta-access list (usernames, lowercased) — who may use work-in-progress PON Tools
# (Inspector now; Renumber once its engine lands). Keeps WIP off the wider team.
# Add a tester here to unlock for them; empty = locked for everyone.
PON_BETA_USERS = {"luke", "johan", "jaun"}


def _demand_group_field(field_names):
    """Return the demand group-link field (group_<N> for ANY size, or batch_id),
    or None. Mirrors the #75 cascade detector so every drop path agrees."""
    return next((n for n in field_names
                 if _DROP_GRP_RE.fullmatch(n) or n == 'batch_id'), None)


def _categorized_with_catch_all(layer, attr, categories, default_color=None):
    """Categorized renderer that ALWAYS carries an 'all other values' catch-all.

    Audit Batch A (same class as #77/#78): a QgsCategorizedSymbolRenderer paints
    NOTHING for a feature whose value matches no category, and an EMPTY category
    list blanks the whole layer. The null-valued category appended here is QGIS's
    'all other values' bucket, so unexpected / null values (and an empty list)
    still render instead of silently vanishing.
    """
    from qgis.PyQt.QtCore import QVariant
    from qgis.core import (QgsRendererCategory,
                           QgsSymbol)
    from qgis.PyQt.QtGui import QColor
    cats = list(categories)
    sym = QgsSymbol.defaultSymbol(layer.geometryType())
    try:
        sym.setColor(QColor(default_color) if default_color else QColor(150, 150, 150))
    except Exception:
        pass
    cats.append(QgsRendererCategory(QVariant(), sym, "Other", True))
    return QgsCategorizedSymbolRenderer(attr, cats)

def _m_to_units(meters, layer):
    """Convert a metre distance to the layer's CRS units.

    Batch B: on a GEOGRAPHIC CRS returns degrees (≈ meters / (111320·cos lat)); on a
    projected/metric CRS returns meters unchanged. Stops metre thresholds being
    compared against degree coordinates (a 5 m tolerance was ~550 km on EPSG:4326).
    """
    try:
        crs = layer.crs()
        if crs.isValid() and crs.isGeographic():
            import math as _mu
            lat = layer.extent().center().y()
            return meters / (111320.0 * max(0.1, _mu.cos(_mu.radians(lat))))
    except Exception:
        pass
    return meters


def _coord_round(x, y):
    """Snap a coordinate to a node-merge grid whose precision matches the CRS units.

    Batch B: a fixed round(_, 4) is ~11 m in DEGREES (merges genuinely distinct graph
    nodes) and ~0.1 mm in METRES (fails to merge coincident endpoints that differ by
    sub-mm float drift → the routing graph fragments → via-span routing silently falls
    back to straight lines). Infer the units from magnitude — geographic coordinates
    are bounded by ±180/±90, projected metric coordinates are far larger — and pick a
    precision giving a ~0.1 m merge grid either way.
    """
    if abs(x) <= 180.0 and abs(y) <= 90.0:
        return (round(x, 6), round(y, 6))   # degrees → ~0.1 m grid
    return (round(x, 1), round(y, 1))       # metres  → 0.1 m grid


# ── Windows MAX_PATH, and the renumber/merge backup ─────────────────────────
# MEASURED on JJ's machine 2026-07-28 (QGIS 4.0.3 Qt6, LongPathsEnabled = 0):
# a plain path wrote a GPKG *and re-read it* clean at 245 characters, and failed
# outright from 260. 245 was measured with a REAL GPKG write, which creates
# SQLite's `-journal` sidecar at +8 characters (253) — so the sidecars are
# already proven inside the wall. Do NOT raise this on a hunch; re-measure.
#
# The `\\?\` extended-length prefix is NOT an option and was tested, not assumed:
# makedirs, open() and even GDAL's GPKG write all succeed with it at 289 chars,
# but NOTHING can read the result back — a GeoPackage is SQLite and sqlite3_open
# ignores the prefix (QgsVectorLayer invalid via every URI form; raw ogr.Open
# errors "unable to open database file"). Copying that same file to a short path
# reads perfectly, so the bytes are fine and the PATH is the problem. It would
# have handed us a backup that writes and can never restore — worse than
# refusing, and invisible to every gate we own.
# The budget and the fallback location live in fibre_automation.shared.vf_paths so
# this and fibre_automation/renumber/apply.py cannot drift apart. The literals
# below are only a last-resort fallback if that import ever fails; a stress check
# asserts the two agree, so a silent divergence cannot survive a publish.
try:
    from fibre_automation.shared.vf_paths import MAXPATH_BUDGET as _BACKUP_PATH_BUDGET
    from fibre_automation.shared.vf_paths import spill_root as _vf_shared_spill_root
except Exception:                                    # pragma: no cover
    _BACKUP_PATH_BUDGET = 245
    _vf_shared_spill_root = None

_BACKUP_DIRNAME = "_renumber_backup"


def _vf_geom_key(geom):
    """A comparable key for a geometry, or None when there is nothing to compare.

    WKB is the exact stored bytes, so this is an identity test and never a
    tolerance test — two features either occupy the same geometry or they do not.
    """
    try:
        if geom is None or geom.isNull() or geom.isEmpty():
            return None
        return bytes(geom.asWkb()).hex()
    except Exception:
        return None


def _vf_safe_layer_name(name):
    """Filesystem-safe stem for a layer name. Must stay byte-identical to what
    _pon_restore_zone_backup's fallback recomputes, or a restore stops matching."""
    return "".join(c if c.isalnum() else "_" for c in name)


def _vf_safe_names(layer_names):
    """[layer name] → [(safe stem, original name)], stems guaranteed UNIQUE.

    `BF_PON's` and `BF_PON s` both sanitise to `BF_PON_s`, and the writer names
    each snapshot `<stem>.gpkg` — so without this the second layer's file
    silently OVERWRITES the first and half the backup is gone with no error.
    Disambiguation happens BEFORE the path budget is measured, because a `_2`
    suffix can be what pushes a borderline path over the limit.
    """
    out, taken = [], set()
    for name in layer_names:
        stem = base = _vf_safe_layer_name(name)
        n = 1
        # count up until the stem is genuinely free — a plain counter is not
        # enough, because the `_2` it invents can itself be another layer's
        # sanitised name (["A'B", "A B", "A_B_2"] all wanted `A_B_2`).
        while stem in taken:
            n += 1
            stem = "%s_%d" % (base, n)
        taken.add(stem)
        out.append((stem, name))
    return out


def _vf_backup_longest_path(root, stems, ts="20260728_082300"):
    """Length of the longest path the backup will write under `root`.

    Every candidate is measured — the timestamp folder, `manifest.json`, and
    each `<stem>.gpkg` — because any one of them can be the longest.
    """
    base = os.path.join(root, _BACKUP_DIRNAME, ts)
    cands = [len(base), len(os.path.join(base, "manifest.json"))]
    cands += [len(os.path.join(base, s + ".gpkg")) for s in stems]
    return max(cands)


def vf_spill_root(project_path):
    """The short fallback folder for `project_path`, independent of layer names.

    Keyed by a hash of the project path so two projects can never share one, and
    stable for a given path so a restore can always find what a write left.

    Deliberately NOT derived from the layer list: the restore has to look here
    whatever the project's depth, because a shallow project with one very long
    layer name can spill too. Working that out from `vf_backup_root_for` — which
    returns the project folder for a shallow project — meant the restore silently
    never looked in the spill root at all for exactly those projects.
    """
    if _vf_shared_spill_root is not None:
        return _vf_shared_spill_root(project_path)
    import hashlib                                    # pragma: no cover

    key = hashlib.sha1((project_path or "").encode("utf-8",
                                                   "replace")).hexdigest()[:10]
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(base, "VelocityFibre", "spill", key)


def vf_pair_backup_rows(backup_rows, live_rows):
    """Pair a backup's rows to the live features they belong to.

    backup_rows : [(stored_fid, geometry_key_or_None, attrs_dict)]
    live_rows   : [(live_fid, geometry_key_or_None)]
    → ({live_fid: attrs}, stats dict)

    Pure — no Qt, no QGIS — so the matching rule is directly testable.

    WHY THIS IS NOT JUST fid
    -----------------------
    The snapshot stores the live feature id in `_vf_fid`, and the restore used to
    look features up by it alone. That is safe on a GeoPackage, where `fid` is a
    stable primary key. It is NOT safe on a SHAPEFILE, where ids are positional:
    delete one feature and OGR renumbers everything after it, so the stored ids
    now point one row further along. Measured 2026-07-28 on a 9-row layer — after
    deleting the 3rd feature, 6 of the 8 survivors would have had another
    feature's attributes written onto them. Malmesbury and MOA are shapefile
    projects, so this was live exposure on a safety net.

    So GEOMETRY is the arbiter (JJ's standing rule: verify by geometry, never by
    fid), with the fid kept as the fast path *only where geometry corroborates
    it*. That means a GeoPackage restore takes exactly the same route it always
    did — this is not a behaviour change where the old rule was already right.

    A live feature whose geometry is nowhere in the backup is SKIPPED, not
    guessed at by fid. Writing attributes onto a feature we cannot identify is
    precisely the corruption this is here to prevent, and the caller reports the
    count rather than hiding it.
    """
    by_fid, by_geom = {}, {}
    for fid, gkey, attrs in backup_rows:
        if fid is not None:
            by_fid[int(fid)] = (gkey, attrs)
        if gkey is not None:
            by_geom.setdefault(gkey, []).append(attrs)

    out = {}
    stats = {"fid": 0, "geometry": 0, "ambiguous": 0, "missing": 0}
    for lfid, lgkey in live_rows:
        cand = by_fid.get(int(lfid))
        # The fid answer stands only when the geometry agrees, or when neither
        # side has a geometry to compare (a null-geometry feature keeps working
        # exactly as before).
        if cand is not None and (cand[0] == lgkey or cand[0] is None
                                 or lgkey is None):
            out[lfid] = cand[1]
            stats["fid"] += 1
            continue
        rows = by_geom.get(lgkey) if lgkey is not None else None
        if rows and len(rows) == 1:
            out[lfid] = rows[0]
            stats["geometry"] += 1
        elif rows:
            stats["ambiguous"] += 1     # identical geometries AND the fid moved
        else:
            stats["missing"] += 1
    return out, stats


def vf_backup_root_for(project_path, layer_names, budget=_BACKUP_PATH_BUDGET):
    """Where the backup for `project_path` can actually be written.

    → (root, spilled, longest_in_project)

    Pure function, no Qt, no QGIS — so it is directly property-testable.

    Prefers the project's own folder, which keeps the backup beside the data and
    inside OneDrive/SharePoint sync, and keeps behaviour byte-identical for every
    project that works today. Only when that would breach MAX_PATH does it fall
    back to the short local root.
    """
    proj_dir = os.path.dirname(project_path or "")
    stems = [s for s, _n in _vf_safe_names(layer_names)]
    longest = _vf_backup_longest_path(proj_dir, stems) if proj_dir else 10 ** 6
    if proj_dir and longest <= budget:
        return proj_dir, False, longest
    return vf_spill_root(project_path), True, longest


CABLE_PROFILES = [2, 4, 6, 12, 24, 36, 48, 72, 96, 144, 288]
PROFILE_TYPE_DEFAULT = 'default'
PROFILE_TYPE_POPC = 'popc'
PROFILE_TYPE_OPERATOR = 'operator'

def get_cable_profile(demand, profile_type=PROFILE_TYPE_DEFAULT, reserve_percent=0.0):
    """Select smallest cable profile that accommodates demand."""
    if demand <= 0:
        return CABLE_PROFILES[0]
    if profile_type == PROFILE_TYPE_POPC:
        effective_demand = math.ceil(demand * 1.30)
    elif profile_type == PROFILE_TYPE_OPERATOR:
        return _get_operator_profile(demand)
    else:
        if reserve_percent > 0:
            effective_demand = math.ceil(demand * (1 + reserve_percent / 100))
        else:
            effective_demand = demand
    return _select_profile(effective_demand)

def _select_profile(demand):
    """Select smallest cable profile >= demand."""
    if demand <= 0:
        return CABLE_PROFILES[0]
    if demand in CABLE_PROFILES:
        return demand
    idx = bisect.bisect_right(CABLE_PROFILES, demand)
    if idx < len(CABLE_PROFILES):
        return CABLE_PROFILES[idx]
    else:
        return CABLE_PROFILES[-1]

def _get_operator_profile(demand):
    """Operator-specific cable thresholds."""
    if demand <= 9:
        return 12
    elif demand <= 20:
        return 24
    elif demand <= 40:
        return 48
    elif demand <= 60:
        return 72
    elif demand <= 80:
        return 96
    elif demand <= 120:
        return 144
    elif demand <= 180:
        return 216
    else:
        return 288

def format_cable_profile(profile):
    """Format cable profile as '48F', '144F', etc."""
    return f"{profile}F"


# ---------------------------------------------------------------------------
# Client profiles — network design parameters per operator
# ---------------------------------------------------------------------------
CLIENT_PROFILES = {
    "Herotel": {
        "max_pon_size": 128,
        "target_pon_size": 96,
        "splitter_ratio_feeder": "1:16",
        "splitter_ratio_dist": "1:8",
        "max_feeder_cable_fibres": 144,
        "feeder_pole_height_m": 7,
        "dist_pole_height_m": 6,
        "max_span_m": 70,
        "max_drop_length_m": 150,
        "description": "Herotel GPON — high-density, cascaded 1:16×1:8 split",
    },
    "Vuma": {
        "max_pon_size": 64,
        "target_pon_size": 48,
        "splitter_ratio_feeder": "1:32",
        "splitter_ratio_dist": "1:4",
        "max_feeder_cable_fibres": 96,
        "feeder_pole_height_m": 7,
        "dist_pole_height_m": 5,
        "max_span_m": 60,
        "max_drop_length_m": 100,
        "description": "Vuma FTTH — standard 1:32 split, 64-unit PON",
    },
    "Fibertime": {
        "max_pon_size": 96,
        "target_pon_size": 72,
        "splitter_ratio_feeder": "1:16",
        "splitter_ratio_dist": "1:4",
        "max_feeder_cable_fibres": 96,
        "feeder_pole_height_m": 7,
        "dist_pole_height_m": 5,
        "max_span_m": 70,
        "max_drop_length_m": 120,
        "description": "Fibertime GPON — balanced 1:16×1:4 split, 96-unit PON",
    },
}


FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'forms', 'dockwidget_base.ui'))


# ---------------------------------------------------------------------------
# Span-network routing helpers (used by Generate Drop Cables)
# ---------------------------------------------------------------------------

def _find_seg_index(pts, snap_pt):
    """Return (i, t) — index of sub-segment and fractional position along it
    where snap_pt is closest to the polyline defined by *pts*.
    """
    import math
    min_d = float('inf')
    best_i, best_t = 0, 0.0
    for i in range(len(pts) - 1):
        ax, ay = pts[i].x(), pts[i].y()
        bx, by = pts[i + 1].x(), pts[i + 1].y()
        dx, dy = bx - ax, by - ay
        seg_sq = dx * dx + dy * dy
        if seg_sq > 1e-20:
            t = max(0.0, min(1.0,
                ((snap_pt.x() - ax) * dx + (snap_pt.y() - ay) * dy) / seg_sq))
        else:
            t = 0.0
        cx, cy = ax + t * dx, ay + t * dy
        d = math.sqrt((snap_pt.x() - cx) ** 2 + (snap_pt.y() - cy) ** 2)
        if d < min_d:
            min_d, best_i, best_t = d, i, t
    return best_i, best_t


def _build_span_routing_graph(span_feats):
    """Build a NetworkX graph of the span network.

    Nodes  : _coord_round(x, y) tuples for segment endpoints — 6 d.p. for
             geographic CRS, 1 d.p. for projected metric CRS.
    Edges  : one per span feature, carrying *pts* (vertex list) and *weight* (length).
    Returns: (G, seg_ep) where seg_ep[fid] = (start_node, end_node, [QgsPointXY …]).
    """
    import networkx as nx
    from qgis.core import QgsPointXY

    G = nx.Graph()
    seg_ep = {}
    for fid, feat in span_feats.items():
        geom = feat.geometry()
        if not geom or geom.isEmpty():
            continue
        pts = [QgsPointXY(v.x(), v.y()) for v in geom.vertices()]
        if len(pts) < 2:
            continue
        n_s = _coord_round(pts[0].x(), pts[0].y())
        n_e = _coord_round(pts[-1].x(), pts[-1].y())
        length = geom.length()
        if not G.has_edge(n_s, n_e) or G[n_s][n_e]['weight'] > length:
            G.add_edge(n_s, n_e, weight=length, fid=fid, pts=pts)
        seg_ep[fid] = (n_s, n_e, pts)
    return G, seg_ep


def _span_route_pts(snap_a, fid_a, snap_b, fid_b, G, seg_ep):
    """Return [QgsPointXY, …] following the span network from *snap_a* to *snap_b*.

    The list includes *snap_a* and *snap_b*.  Returns *None* if no path exists.
    """
    import networkx as nx
    import math

    n_sa, n_ea, pts_a = seg_ep[fid_a]
    n_sb, n_eb, pts_b = seg_ep[fid_b]
    i_a, _ = _find_seg_index(pts_a, snap_a)
    i_b, _ = _find_seg_index(pts_b, snap_b)

    # ---- Same segment: extract the portion between the two snap points -----
    if fid_a == fid_b:
        # Determine which snap is earlier along the segment
        def _along(pts, idx):
            return sum(math.dist((pts[j].x(), pts[j].y()),
                                 (pts[j + 1].x(), pts[j + 1].y()))
                       for j in range(idx))
        if _along(pts_a, i_a) <= _along(pts_a, i_b):
            return [snap_a] + pts_a[i_a + 1:i_b + 1] + [snap_b]
        else:
            return [snap_a] + list(reversed(pts_a[i_b + 1:i_a + 1])) + [snap_b]

    # ---- Different segments: route via endpoint graph ----------------------
    best_path, best_cost = None, float('inf')
    for da in [n_sa, n_ea]:
        for db in [n_sb, n_eb]:
            try:
                plen = nx.shortest_path_length(G, da, db, weight='weight')
                pnodes = nx.shortest_path(G, da, db, weight='weight')
            except Exception:
                continue
            cost = (plen
                    + math.dist(da, (snap_a.x(), snap_a.y()))
                    + math.dist(db, (snap_b.x(), snap_b.y())))
            if cost < best_cost:
                best_cost, best_path = cost, (pnodes, da, db)

    if best_path is None:
        return None

    pnodes, da, db = best_path
    result = [snap_a]

    # Part 1: snap_a → da along segment A
    if da == n_ea:
        result.extend(pts_a[i_a + 1:])               # forward to end
    else:
        result.extend(reversed(pts_a[:i_a + 1]))     # backward to start

    # Part 2: traverse path_nodes da → … → db
    for k in range(len(pnodes) - 1):
        n1, n2 = pnodes[k], pnodes[k + 1]
        ed = G[n1][n2]
        eps = ed['pts']
        en_s = _coord_round(eps[0].x(), eps[0].y())
        if n1 == en_s:
            result.extend(eps[1:])           # forward  — skip eps[0] (= n1, already added)
        else:
            result.extend(reversed(eps[:-1]))  # backward — skip eps[-1] (= n1, already added)

    # Part 3: db → snap_b along segment B  (db is already the last element)
    if db == n_sb:
        result.extend(pts_b[1:i_b + 1])              # forward from start
    else:
        result.extend(reversed(pts_b[i_b + 1:-1]))   # backward from end
    result.append(snap_b)

    return result

# ---------------------------------------------------------------------------


def _safe_commit(layer, log=None):
    """Commit a layer's edit buffer, RELIABLY.

    `QgsVectorLayer.commitChanges()` returns False (it does NOT raise) when a
    commit fails — locked GeoPackage, a constraint, a provider hiccup — leaving the
    edits silently unsaved while the caller happily reports success. Worse, the edit
    buffer is left open, so the next startEditing() piles onto it. This helper makes
    every commit fail-safe: on failure it rolls the buffer back and reports, so the
    layer is never left in a half-edited state and the user isn't told a save worked
    when it didn't. Returns True only on a real, persisted commit. Behaviour on the
    SUCCESS path is identical to a bare commitChanges() (just returns the bool)."""
    try:
        if layer is not None and layer.commitChanges():
            return True
    except Exception:
        _swallowed_note()
    # Failure (or exception) — roll the buffer back so it can't linger / corrupt.
    try:
        if layer is not None and layer.isEditable():
            layer.rollBack()
    except Exception:
        _swallowed_note()
    if log is not None:
        try:
            log("⚠ Save failed — changes were rolled back (layer may be locked or "
                "read-only). Nothing was persisted.")
        except Exception:
            _swallowed_note()
    return False


class AutoNetProgressDialog(QtWidgets.QDialog):
    """Modal progress dialog shown while AutoNet pipeline runs.

    Displays a scrolling log, per-step progress bar, elapsed timer and a
    Close button that is only enabled once the pipeline finishes.
    """

    STEP_LABELS = [
        "Detecting layers…",
        "Step 1/5 — Generate PONs",
        "Step 2/5 — Generate Demand Points",
        "Step 3/5 — Generate PON Boundaries",
        "Step 4/5 — Generate Splitter Points",
        "Step 5/5 — Generate Drops PTP",
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        # parented to the dock; without this the C++ QDialog lingers as a hidden
        # child for the dock's whole lifetime on every AutoNet run (leak)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.setWindowTitle("⚡ AutoNet — Pipeline Progress")
        self.setMinimumWidth(560)
        self.setMinimumHeight(420)
        self.setModal(True)

        from qgis.PyQt.QtWidgets import (
            QVBoxLayout, QHBoxLayout, QLabel, QTextEdit,
            QProgressBar, QPushButton, QSizePolicy,
        )
        from qgis.PyQt.QtGui import QFont

        root = QVBoxLayout(self)
        root.setSpacing(6)
        root.setContentsMargins(10, 10, 10, 10)

        # ── Step label ────────────────────────────────────────────────
        self._step_lbl = QLabel("Initialising…")
        self._step_lbl.setStyleSheet(f'font-weight:bold;color:{theme_safe.colors()["accent"]};font-size:11px;')
        root.addWidget(self._step_lbl)

        # ── Progress bar ──────────────────────────────────────────────
        self._prog = QProgressBar()
        self._prog.setRange(0, 100)
        self._prog.setValue(0)
        self._prog.setTextVisible(True)
        self._prog.setFixedHeight(18)
        self._prog.setStyleSheet(
            "QProgressBar{border:1px solid #aaa;border-radius:4px;background:#f0f0f0;}"
            "QProgressBar::chunk{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,"
            "stop:0 #2196F3,stop:1 #21CBF3);border-radius:3px;}"
        )
        root.addWidget(self._prog)

        # ── Timer row ─────────────────────────────────────────────────
        timer_row = QHBoxLayout()
        self._timer_lbl = QLabel("⏱ 0s")
        self._timer_lbl.setStyleSheet(f'color:{theme_safe.colors()["muted"]};font-size:10px;')
        timer_row.addWidget(self._timer_lbl)
        timer_row.addStretch()
        root.addLayout(timer_row)

        # ── Log / terminal output ─────────────────────────────────────
        self._log = QTextEdit()
        self._log.setReadOnly(True)
        self._log.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)  # #130: fully-scoped enum (Qt6-safe; unscoped QTextEdit.NoWrap AttributeErrors on Qt6)
        font = QFont("Consolas", 9)
        if not font.exactMatch():
            font = QFont("Courier New", 9)
        self._log.setFont(font)
        self._log.setStyleSheet(
            "QTextEdit{background:#1e1e1e; color:#d4d4d4; border:1px solid #333;}"
        )
        self._log.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        root.addWidget(self._log, 1)

        # ── Close button (disabled until done) ───────────────────────
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        self._close_btn = QPushButton("Close")
        self._close_btn.setEnabled(False)
        self._close_btn.setFixedWidth(100)
        self._close_btn.setStyleSheet(
            "QPushButton{background:#2196F3;color:white;border-radius:4px;padding:4px 12px;}"
            "QPushButton:disabled{background:#aaa;color:#ddd;}"
            "QPushButton:hover:!disabled{background:#1565C0;}"
        )
        self._close_btn.clicked.connect(self.accept)
        btn_row.addWidget(self._close_btn)
        root.addLayout(btn_row)

        # ── Internal timer ────────────────────────────────────────────
        from qgis.PyQt.QtCore import QTimer
        self._t0 = time.time()
        self._tick_timer = QTimer(self)
        self._tick_timer.setInterval(500)
        self._tick_timer.timeout.connect(self._on_tick)
        self._tick_timer.start()

    # ------------------------------------------------------------------
    def _on_tick(self):
        elapsed = time.time() - self._t0
        if elapsed >= 3600:
            s = f"{int(elapsed // 3600)}h {int((elapsed % 3600) // 60)}m"
        elif elapsed >= 60:
            s = f"{int(elapsed // 60)}m {int(elapsed % 60)}s"
        else:
            s = f"{elapsed:.1f}s"
        pct = self._prog.value()
        if pct > 0:
            eta = elapsed * (100 - pct) / pct
            if eta >= 60:
                eta_s = f" | ETA ~{int(eta // 60)}m {int(eta % 60)}s"
            else:
                eta_s = f" | ETA ~{eta:.0f}s"
        else:
            eta_s = ""
        self._timer_lbl.setText(f"⏱ {s}{eta_s}")

    def set_step(self, step: int, label: str = ""):
        """Update step label and progress bar (step 0..5, TOTAL_STEPS=5)."""
        TOTAL = 5
        pct = int(step / TOTAL * 100) if step <= TOTAL else 100
        self._prog.setValue(pct)
        text = label or (self.STEP_LABELS[step] if step < len(self.STEP_LABELS) else "")
        self._step_lbl.setText(text)
        QApplication.processEvents()

    def append_log(self, message: str):
        """Append a line to the log area and auto-scroll."""
        self._log.append(message)
        sb = self._log.verticalScrollBar()
        sb.setValue(sb.maximum())
        QApplication.processEvents()

    def mark_complete(self, success: bool = True):
        """Called when the pipeline finishes."""
        self._tick_timer.stop()
        self._on_tick()  # final time update
        if success:
            self._step_lbl.setText(f"⚡ AutoNet Complete ✓  ({self._timer_lbl.text().replace('⏱ ', '')})")
            self._step_lbl.setStyleSheet(f'font-weight:bold;color:{theme_safe.colors()["ok"]};font-size:11px;')
            self._prog.setValue(100)
        else:
            self._step_lbl.setText("⚠ AutoNet encountered errors — see log")
            self._step_lbl.setStyleSheet(f'font-weight:bold;color:{theme_safe.colors()["bad"]};font-size:11px;')
        self._close_btn.setEnabled(True)
        self._close_btn.setFocus()
        QApplication.processEvents()

    def mark_error(self, msg: str = ""):
        self._tick_timer.stop()
        self._step_lbl.setText(f"❌ Error: {msg}")
        self._step_lbl.setStyleSheet(f'font-weight:bold;color:{theme_safe.colors()["bad"]};font-size:11px;')
        self._close_btn.setEnabled(True)
        self._close_btn.setFocus()
        QApplication.processEvents()


class ZonePickTool(QgsMapTool):
    """Click a zone polygon on the canvas → emit its id. Used by the manual
    'renumber by clicking zones in order' flow. Read-only; never edits."""

    zone_clicked = pyqtSignal(str)   # the clicked zone's id (as string)

    def __init__(self, canvas, zone_layer, zone_field):
        super().__init__(canvas)
        self._lyr = zone_layer
        self._field = zone_field

    def canvasReleaseEvent(self, e):
        from qgis.core import (QgsGeometry, QgsPointXY, QgsCoordinateTransform,
                               QgsProject)
        try:
            pt = self.toMapCoordinates(e.pos())   # project/canvas CRS
            p = QgsPointXY(pt)
            src = QgsProject.instance().crs()
            dst = self._lyr.crs()
            if src.isValid() and dst.isValid() and src != dst:
                p = QgsCoordinateTransform(src, dst, QgsProject.instance()).transform(p)
            pg = QgsGeometry.fromPointXY(p)
            hit = None
            for f in self._lyr.getFeatures():
                g = f.geometry()
                if g and not g.isEmpty() and g.contains(pg):
                    hit = f
                    break
            if hit is not None:
                self.zone_clicked.emit(str(hit[self._field]))
        except Exception:
            pass


class PonPolygonSelectTool(QgsMapTool):
    """Rubber-band polygon map tool for PON-per-PON dual-layer selection.

    Left-click  → add vertex to polygon.
    Right-click → complete polygon and select intersecting features on both layers.
    Escape      → cancel.
    """

    selection_complete = pyqtSignal(object, object)  # (demand_layer, span_layer)
    cancelled = pyqtSignal()

    def __init__(self, canvas, demand_lyr, span_lyr):
        super().__init__(canvas)
        self._demand_lyr = demand_lyr
        self._span_lyr = span_lyr
        self._points = []

        self._rb = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PolygonGeometry)
        self._rb.setColor(QColor(255, 165, 0, 90))
        self._rb.setStrokeColor(QColor(200, 120, 0, 220))
        self._rb.setWidth(2)

    # ------------------------------------------------------------------ events
    def canvasPressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            pt = self.toMapCoordinates(event.pos())
            self._points.append(pt)
            self._rb.addPoint(pt, True)
        elif event.button() == Qt.MouseButton.RightButton:
            self._finish()

    def canvasMoveEvent(self, event):
        if self._points:
            pt = self.toMapCoordinates(event.pos())
            self._rb.movePoint(pt)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self._reset()
            self.cancelled.emit()

    # ------------------------------------------------------------------ logic
    def _finish(self):
        if len(self._points) < 3:
            self._reset()
            self.cancelled.emit()
            return

        poly_geom = QgsGeometry.fromPolygonXY([self._points])
        self._reset()

        # #7 CRS-safe: the polygon vertices come from toMapCoordinates → the CANVAS
        # (project) CRS. Testing them against layer geometries in a DIFFERENT CRS (e.g.
        # a metre-projected layer under a 4326 canvas, or vice-versa) selects nothing or
        # nonsense. Transform the polygon into each layer's own CRS before testing, and
        # use a bbox prefilter so only candidates are geometry-tested. Same-CRS projects
        # (the common 4326 case) transform to a no-op → identical selection, just faster.
        from qgis.core import (QgsCoordinateTransform, QgsProject as _QP,
                               QgsFeatureRequest)
        try:
            _canvas_crs = self.canvas().mapSettings().destinationCrs()
        except Exception:
            _canvas_crs = None

        for lyr in (self._demand_lyr, self._span_lyr):
            if not lyr:
                continue
            _pg = QgsGeometry(poly_geom)   # per-layer copy so transforms don't stack
            try:
                if (_canvas_crs is not None and _canvas_crs.isValid()
                        and lyr.crs().isValid() and _canvas_crs != lyr.crs()):
                    _pg.transform(QgsCoordinateTransform(_canvas_crs, lyr.crs(), _QP.instance()))
            except Exception:
                _pg = QgsGeometry(poly_geom)   # untransformed fallback on error
            lyr.removeSelection()
            _req = QgsFeatureRequest().setFilterRect(_pg.boundingBox())
            ids = [f.id() for f in lyr.getFeatures(_req)
                   if f.geometry() and f.geometry().intersects(_pg)]
            lyr.selectByIds(ids)

        self.selection_complete.emit(self._demand_lyr, self._span_lyr)

    def _reset(self):
        self._rb.reset(QgsWkbTypes.GeometryType.PolygonGeometry)
        self._points = []

    def deactivate(self):
        self._reset()
        super().deactivate()


# Big handlers live in mixin modules beside this file (moved verbatim 2026-09-22).
# Imported here, after every helper above exists, because they import those helpers.
from .dock_widget_override import ManualOverrideMixin  # noqa: E402
from .dock_widget_generate import GenerateMixin  # noqa: E402
from .dock_widget_renumber import RenumberMixin  # noqa: E402


class FTTHPlanToolDockWidget(ManualOverrideMixin, GenerateMixin, RenumberMixin, QtWidgets.QDockWidget, FORM_CLASS):
    """Dock widget for the FTTH Plan Tool plugin."""

    closingPlugin = pyqtSignal()

    def __init__(self, iface, parent=None):
        """Constructor.
        
        Args:
            iface: QGIS interface instance
            parent: Parent widget
        """
        super(FTTHPlanToolDockWidget, self).__init__(parent)
        self.setupUi(self)
        # Make the whole dock vertically scrollable so the bottom sections
        # (Feeder Route Generation + any loading/progress states) are always
        # reachable when the panel is taller than the screen. setupUi sets
        # dockWidgetContents as the dock widget; re-parent it into a QScrollArea.
        _scroll = QtWidgets.QScrollArea(self)
        _scroll.setObjectName("npScrollArea")
        _scroll.setWidgetResizable(True)             # content fills width, grows vertically
        _scroll.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)
        _scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        _scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        _scroll.setWidget(self.dockWidgetContents)   # re-parents the existing content
        self.setWidget(_scroll)
        self._np_scroll = _scroll
        # Header (ticket #50): plain "Network Planner" — no "Velocity", no version.
        self.setWindowTitle("Network Planner")
        self.iface = iface
        self.network_graph = None
        self.result_layer = None
        self.grouped_layer = None
        self.demand_points_layer = None
        self.splitter_points_layer = None
        self.zone_boundaries_layer = None  # step 3 output — stored for PON-per-PON merge
        self.drop_ptp_layer = None          # step 5 output — stored for PON-per-PON merge
        self._op_last_pct = -1
        self._strip_gen = 0
        self.active_client = None
        self._cancel_requested = False  # set to True by Kill button to abort running operations
        # PON-per-PON state: tracks run count and cumulative zone/group offsets
        self._pon_batch_count   = 0   # increments each completed PON-per-PON run
        self._pon_zone_offset   = 0   # running max zone_id across all runs
        self._pon_group_offset  = 0   # running max group_id across all runs
        self._current_batch_label = None  # set during autonet run, used by steps 4 & 5
        self._pon_full_span_layer = None  # full (unfiltered) span layer preserved for splitter snapping
        self._pon_color_offset = 0.0  # hue offset for zone polygon colors (rotates per batch)
        # PON-per-PON persistent accumulator layers (append-only across batches)
        self._pon_accum_groups    = None  # "PON Groups" — all grouped demand points
        self._pon_accum_zones     = None  # "PON Zone Boundaries" — all zone polygons
        self._pon_accum_splitters = None  # "PON Splitter Points" — all splitters
        self._pon_accum_drops     = None  # "PON Drop Cables" — all drop lines
        # When True, the NEXT PON-per-PON run will start a fresh session (new layers,
        # counters reset to 1).  Accumulators are NOT nulled on cancel so that Manual
        # Override can continue editing the existing layers after the button is closed.
        self._pon_new_session_needed = False

        # Persist-through-updates: a plugin reload (one-click update) builds a FRESH
        # dock, so every layer handle above resets to None and the user's splitters/
        # zones/groups appear "dead". Restore those handles + the Properties picks
        # from the PROJECT (custom properties survive a reload) once the event loop
        # turns (so setupUi's combos exist). See _session_save/_session_restore.
        from qgis.PyQt.QtCore import QTimer as _QTm0
        _QTm0.singleShot(0, self._session_restore)
        # Pass 0 (Shell & Look): one shared, theme-safe visual language across the
        # whole dock. Deferred a tick so the palette/theme is fully settled before
        # we read it. STYLING ONLY — no widget moved, no handler touched.
        _QTm0.singleShot(0, self._apply_np_shell_style)

        # --- Progress strip (inserted above textEdit_output) ---
        from qgis.PyQt.QtWidgets import QWidget as _QW, QHBoxLayout as _QHL, QProgressBar as _QPB, QLabel as _QL, QPushButton as _QPBS
        from qgis.PyQt.QtCore import QTimer as _QTm
        self._prog_strip = _QW()
        self._prog_strip.setFixedHeight(30)
        _ps_lay = _QHL(self._prog_strip)
        _ps_lay.setContentsMargins(4, 3, 4, 3)
        _ps_lay.setSpacing(6)
        self._prog_op_lbl = _QL("Processing...")
        self._prog_op_lbl.setStyleSheet(f'font-weight:bold;color:{theme_safe.colors()["accent"]};')
        _ps_lay.addWidget(self._prog_op_lbl)
        self._prog_bar = _QPB()
        self._prog_bar.setRange(0, 100)
        self._prog_bar.setValue(0)
        self._prog_bar.setTextVisible(False)
        self._prog_bar.setFixedHeight(14)
        self._prog_bar.setStyleSheet(
            "QProgressBar{border:1px solid #bbb;border-radius:4px;background:#f0f0f0;}"
            "QProgressBar::chunk{background:#2a6ebb;border-radius:3px;}"
        )
        _ps_lay.addWidget(self._prog_bar, 1)
        self._prog_time_lbl = _QL("0s")
        self._prog_time_lbl.setMinimumWidth(140)
        self._prog_time_lbl.setStyleSheet(f'color:{theme_safe.colors()["muted"]};font-size:9pt;')
        _ps_lay.addWidget(self._prog_time_lbl)
        # Kill / cancel button — stops any running operation
        self._prog_kill_btn = _QPBS("✕ Kill")
        self._prog_kill_btn.setFixedHeight(22)
        self._prog_kill_btn.setStyleSheet(
            "QPushButton{background:#c0392b;color:white;font-weight:bold;"
            "border-radius:3px;padding:0 8px;font-size:9pt;}"
            "QPushButton:hover{background:#e74c3c;}"
        )
        self._prog_kill_btn.setToolTip("Cancel the current operation")
        self._prog_kill_btn.clicked.connect(self._on_kill_clicked)
        _ps_lay.addWidget(self._prog_kill_btn)
        self._prog_strip.setVisible(False)
        _main_lay = self.dockWidgetContents.layout()
        for _i in range(_main_lay.count()):
            _item = _main_lay.itemAt(_i)
            if _item and _item.widget() is self.textEdit_output:
                _main_lay.insertWidget(_i, self._prog_strip)
                break

        # Hide the terminal log panel — output is shown in the AutoNet popup dialog
        self.textEdit_output.setVisible(False)
        self.textEdit_output.setMaximumHeight(0)
        self._prog_timer = _QTm(self)
        self._prog_timer.setInterval(500)
        self._prog_timer.timeout.connect(self._op_tick)
        self.active_client_profile = None

        # Connect client profile button
        self.pushButton_set_client.clicked.connect(self.on_set_client_clicked)
        self.pushButton_calculate.clicked.connect(self.on_calculate_clicked)
        self.pushButton_clear.clicked.connect(self.on_clear_clicked)
        self.pushButton_build_graph.clicked.connect(self.on_build_graph_clicked)
        self.pushButton_analyze.clicked.connect(self.on_analyze_clicked)
        self.pushButton_group_erven.clicked.connect(self.on_cluster_erven_clicked)
        self.pushButton_generate_demand_points.clicked.connect(self.on_generate_demand_points_clicked)
        self.pushButton_show_batch_stats.clicked.connect(self.on_show_batch_stats_clicked)
        self.pushButton_generate_boundaries.clicked.connect(self.on_generate_boundaries_clicked)
        self.pushButton_generate_splitters.clicked.connect(self.on_generate_splitters_clicked)
        self.pushButton_generate_drop_lashed.clicked.connect(self.on_generate_drop_lashed_clicked)
        self.pushButton_generate_drop_ptp.clicked.connect(self.on_generate_drop_ptp_clicked)
        self.pushButton_generate_aggregation_points.clicked.connect(self.on_generate_aggregation_points_clicked)
        # ONE Manual Override (JJ 2026-06-25): the single button always opens the layer
        # picker (smart, field-aware defaults) then the editor — works even when several
        # splitter/demand layers exist. The separate "Manual Override Final" is removed.
        self.pushButton_manual_override.clicked.connect(self.on_manual_override_final_clicked)
        self.pushButton_validate_span_network.clicked.connect(self.on_validate_span_network_clicked)
        self.pushButton_generate_feeder_routes.clicked.connect(self.on_generate_feeder_routes_clicked)
        self.pushButton_generate_poles.clicked.connect(self.on_generate_poles_clicked)
        self.pushButton_span_evaluate.clicked.connect(self.on_span_evaluate_clicked)
        self.pushButton_span_evaluate.setStyleSheet(
            "QPushButton { background-color: #2e4057; color: white; font-weight: bold; "
            "border-radius: 3px; padding: 3px; }"
            "QPushButton:hover { background-color: #3d5270; }"
            "QPushButton:pressed { background-color: #1e2d3e; }"
        )
        self.pushButton_restore_span_backup.clicked.connect(self.on_restore_span_backup_clicked)
        self.pushButton_restore_span_backup.setStyleSheet(
            "QPushButton { background-color: #7a3b2e; color: white; font-weight: bold; "
            "border-radius: 3px; padding: 3px; }"
            "QPushButton:hover { background-color: #9c4c3b; }"
            "QPushButton:pressed { background-color: #5c2c22; }"
            "QPushButton:disabled { background-color: #cccccc; color: #888888; }"
        )
        self.pushButton_explode_span.clicked.connect(self.on_explode_span_clicked)
        self.pushButton_explode_span.setStyleSheet(
            "QPushButton { background-color: #4a3060; color: white; font-weight: bold; "
            "border-radius: 3px; padding: 3px; }"
            "QPushButton:hover { background-color: #5e3d7a; }"
            "QPushButton:pressed { background-color: #36224a; }"
        )
        self._span_snap_backup = None   # {layer_id, layer_name, features: {fid: wkt}}

        # Hide buttons not needed at this stage
        self.pushButton_validate_span_network.setVisible(False)
        self.pushButton_show_batch_stats.setVisible(False)

        # ── Reorganize Generate PON groupbox layout ──────────────────────────
        # Final order:  [AutoNet] [ManualNet] [Manual Override] [_manual_section (hidden)]
        # _manual_section contains: form rows + all step buttons (shown on ManualNet toggle)
        from qgis.PyQt.QtWidgets import QPushButton as _QPB2, QWidget as _QW2, QVBoxLayout as _QVB2

        gb_layout = self.groupBox_4.layout()   # QVBoxLayout from UI file

        # 1. Drain ALL existing items from the groupBox layout (keeps widgets alive via parent)
        _gb_items = []
        while gb_layout.count():
            _item = gb_layout.takeAt(0)
            _w = _item.widget()
            _l = _item.layout()
            if _w:
                _gb_items.append(('widget', _w))
            elif _l:
                _gb_items.append(('layout', _l))

        # 2. Build _manual_section container for all items EXCEPT Manual Override
        self._manual_section = _QW2()
        self._manual_section.setObjectName("manualSection")
        _ms_lay = _QVB2(self._manual_section)
        _ms_lay.setContentsMargins(0, 0, 0, 0)
        _ms_lay.setSpacing(gb_layout.spacing())

        for _kind, _item in _gb_items:
            if _kind == 'widget' and _item is self.pushButton_manual_override:
                continue  # placed separately below
            if _kind == 'layout':
                _ms_lay.addLayout(_item)
            else:
                _ms_lay.addWidget(_item)

        # Extract ONLY the property fields (Demand / Method / Route / Road / Span
        # Corridor = formLayout_2) into a separate collapsible section that opens &
        # closes directly UNDER the 🔧 Properties button (ticket #38). The rest of
        # the manual section (Refresh Layers, Individual Steps, Sum buttons) stays
        # where it is and remains always visible.
        self._props_section = _QW2()
        self._props_section.setObjectName("propsSection")
        _ps_lay = _QVB2(self._props_section)
        _ps_lay.setContentsMargins(0, 0, 0, 0)
        _ps_lay.setSpacing(gb_layout.spacing())
        _ms_lay.removeItem(self.formLayout_2)     # take the 5 fields out of the manual block
        _ps_lay.addLayout(self.formLayout_2)      # …and into the Properties dropdown
        self._props_section.setVisible(False)     # collapsed by default (Properties off)
        self._manual_section.setVisible(True)     # the rest stays visible

        # ── 🔄 Refresh button (top of Properties) — re-detect project layers ──
        self._btn_refresh_props = _QPB2("🔄 Reload Layers")
        self._btn_refresh_props.setToolTip(
            "Re-scan the project and auto-detect the demand / route / road layers "
            "into the dropdowns — use after you add, rename or reload layers.")
        self._btn_refresh_props.setStyleSheet(
            "QPushButton { background-color: #0e7490; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #0891b2; }"
            "QPushButton:pressed { background-color: #155e75; }")
        self._btn_refresh_props.clicked.connect(self._refresh_properties)
        _ms_lay.insertWidget(0, self._btn_refresh_props)

        # ── "Sum Span Distance" button — added at the bottom of the manual section
        self._btn_sum_span = _QPB2("📏 Sum Span Distance")
        self._btn_sum_span.setToolTip(
            "Calculate the total length of all features in the selected Span (Route) layer.")
        self._btn_sum_span.setStyleSheet(
            "QPushButton { background-color: #5d4e8c; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #7060a8; }"
            "QPushButton:pressed { background-color: #46387a; }"
        )
        self._btn_sum_span.clicked.connect(self.on_sum_span_distance_clicked)
        _ms_lay.addWidget(self._btn_sum_span)

        # ── "Sum Pole Numbers" button
        self._btn_sum_poles = _QPB2("🔢 Sum Pole Numbers")
        self._btn_sum_poles.setToolTip(
            "Count the total number of poles across all Poles layers in the project.")
        self._btn_sum_poles.setStyleSheet(
            "QPushButton { background-color: #7a4a1e; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #9a5e28; }"
            "QPushButton:pressed { background-color: #5c3716; }"
        )
        self._btn_sum_poles.clicked.connect(self.on_sum_pole_numbers_clicked)
        _ms_lay.addWidget(self._btn_sum_poles)

        # ── "Sum Demand Points" button
        self._btn_sum_demand = _QPB2("🏠 Sum Demand Points")
        self._btn_sum_demand.setToolTip(
            "Count the total number of demand points in the Demand Points layer.")
        self._btn_sum_demand.setStyleSheet(
            "QPushButton { background-color: #1a5276; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #2471a3; }"
            "QPushButton:pressed { background-color: #154360; }"
        )
        self._btn_sum_demand.clicked.connect(self.on_sum_demand_points_clicked)
        _ms_lay.addWidget(self._btn_sum_demand)

        # ── "AutoSum" button
        self._btn_autosum = _QPB2("🧮 Auto-Sum")
        self._btn_autosum.setToolTip(
            "Calculate Span Distance + Pole Count + Demand Point Count and show all results in one window.")
        self._btn_autosum.setStyleSheet(
            "QPushButton { background-color: #4a235a; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #6c3483; }"
            "QPushButton:pressed { background-color: #381748; }"
        )
        self._btn_autosum.clicked.connect(self.on_auto_sum_clicked)
        _ms_lay.addWidget(self._btn_autosum)

        # ── "Tag by PON / Phase" button — which area does each feature fall in?
        self._btn_zone_tag = _QPB2("🏷 Tag by PON / Phase")
        self._btn_zone_tag.setToolTip(
            "Add a column to any layer saying which PON / Phase (or any polygon "
            "layer) each feature falls in:\n"
            "• pick the polygon layers to tag with + the field holding the value\n"
            "• pick the layers that get the new column\n"
            "• points get the one area they sit in; cables list every area they "
            "cross\n"
            "Previews everything first — nothing is written until you press Apply.")
        self._btn_zone_tag.setStyleSheet(
            "QPushButton { background-color: #1e5f7a; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #2879a0; }"
            "QPushButton:pressed { background-color: #16465a; }"
        )
        self._btn_zone_tag.clicked.connect(self.on_zone_tag_clicked)
        _ms_lay.addWidget(self._btn_zone_tag)

        self._btn_autonet = _QPB2("⚡ AutoNet")
        self._btn_autonet.setToolTip(
            "Auto-detect layers and run the full pipeline:\n"
            "Generate PONs → Demand Points → PON Boundaries → Splitter Points → Drops PTP"
        )
        self._btn_autonet.setStyleSheet(
            "QPushButton { background-color: #1a6b3c; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #238a4f; }"
            "QPushButton:pressed { background-color: #145230; }"
        )
        self._btn_autonet.clicked.connect(self.on_autonet_clicked)

        # 4. ManualNet toggle button
        self._btn_manualnet = _QPB2("🔧 Properties")
        self._btn_manualnet.setCheckable(True)
        self._btn_manualnet.setChecked(False)
        self._btn_manualnet.setToolTip("Show / hide manual step controls")
        self._btn_manualnet.setStyleSheet(
            "QPushButton { background-color: #2a5b8a; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #336fa5; }"
            "QPushButton:pressed { background-color: #1f4468; }"
            "QPushButton:checked { background-color: #1f4468; }"
        )
        self._btn_manualnet.toggled.connect(
            lambda checked: self._props_section.setVisible(checked)
        )

        # 5. Output GeoPackage row (always visible — path stored inside the .qgz project file)
        from qgis.PyQt.QtWidgets import (QWidget as _QW3, QHBoxLayout as _QHL3,
                                         QLabel as _QL3, QLineEdit as _QLE3,
                                         QToolButton as _QTB3)
        from qgis.PyQt.QtCore import QSize as _QSz3

        _gpkg_row = _QW3()
        _gpkg_hl = _QHL3(_gpkg_row)
        _gpkg_hl.setContentsMargins(2, 2, 2, 2)
        _gpkg_hl.setSpacing(4)
        _gpkg_lbl = _QL3("Output GPKG:")
        _gpkg_lbl.setStyleSheet(f'font-size:8pt;color:{theme_safe.colors()["muted"]};')
        _gpkg_hl.addWidget(_gpkg_lbl)
        self._output_gpkg_edit = _QLE3()
        self._output_gpkg_edit.setPlaceholderText("(scratch — set file to persist layers)")
        self._output_gpkg_edit.setToolTip(
            "GeoPackage where ALL output layers are saved.\n"
            "Set once per project — layers reload automatically when project is reopened.")
        self._output_gpkg_edit.setStyleSheet("font-size: 8pt;")
        _gpkg_hl.addWidget(self._output_gpkg_edit, 1)
        _gpkg_btn = _QTB3()
        _gpkg_btn.setText("📁")
        _gpkg_btn.setFixedSize(_QSz3(26, 22))
        _gpkg_btn.setToolTip("Browse for output GeoPackage file")
        _gpkg_hl.addWidget(_gpkg_btn)

        _gpkg_btn.clicked.connect(self._browse_gpkg_path)

        # textChanged fires on every keystroke AND after setText — use it to always persist
        self._output_gpkg_edit.textChanged.connect(self._save_gpkg_path)

        # Load path whenever a project is opened or created
        from qgis.core import QgsProject as _QP4
        _QP4.instance().readProject.connect(self._reload_gpkg_path)
        _QP4.instance().cleared.connect(self._clear_gpkg_path)

        # ── "PON per PON Manual" button ────────────────────────────────
        # Base label kept in one place so the toggle states stay consistent.
        self._PON_PER_PON_LABEL = "🎯 PON per PON Manual  ·BETA"
        self._btn_pon_per_pon = _QPB2(self._PON_PER_PON_LABEL)
        self._btn_pon_per_pon.setToolTip(
            "Select a subset of Span features and Demand Points on the map,\n"
            "then run the full AutoNet pipeline on only those selected features.\n"
            "Repeat for each PON area individually."
        )
        self._btn_pon_per_pon.setStyleSheet(
            "QPushButton { background-color: #7d4e00; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #a06300; }"
            "QPushButton:pressed { background-color: #5a3800; }"
            "QPushButton:checked { background-color: #5a3800; }"
        )
        self._btn_pon_per_pon.setCheckable(True)
        self._btn_pon_per_pon.clicked.connect(self.on_pon_per_pon_clicked)
        self._pon_per_pon_active = False   # track whether we're in selection mode

        # 6. Rebuild layout: GPKG row → Properties (top, per request) → AutoNet → PON per PON → Manual Override → Create Enclosure → collapsible section
        gb_layout.addWidget(_gpkg_row)
        gb_layout.addWidget(self._btn_manualnet)        # 🔧 Properties — moved to top
        gb_layout.addWidget(self._props_section)        # 5 config fields collapse right under Properties
        gb_layout.addWidget(self._btn_autonet)
        gb_layout.addWidget(self._btn_pon_per_pon)

        # ── PON Tools (BETA) — gated to beta testers; safe on permanent data ──
        # PON per PON Manual above generates pons (everyone). The PON Inspector is
        # READ-ONLY (cannot change data). Renumber is still being built and stays
        # LOCKED until its engine lands. Both are unlocked only for beta testers
        # (see _pon_is_beta_user) so work-in-progress can't reach the wider team.
        from qgis.PyQt.QtWidgets import QLabel as _QLbeta
        _is_beta = self._pon_is_beta_user()
        _term = self._pon_term()   # 'Zone' (zone polygon IS the PON) or 'PON'
        _banner_txt = (
            "ℹ️ Renumber previews the full change first, then renumbers every zone in "
            "feeder-route order. A backup is taken automatically before it writes — if "
            "the backup fails, nothing is renumbered. Use ↩ Undo last Renumber to roll "
            "it back.")
        self._pon_beta_banner = _QLbeta(_banner_txt)
        self._pon_beta_banner.setWordWrap(True)
        self._pon_beta_banner.setStyleSheet(
            "QLabel { background-color: #0e2233; color: #7fb2e5; border: 1px solid #2f5f88; "
            "border-left: 4px solid #2f5f88; border-radius: 4px; padding: 5px 7px; "
            "font-size: 8.5pt; }")
        gb_layout.addWidget(self._pon_beta_banner)

        # (🔍 Inspect {term}s removed at JJ's request, 2026-06-25 — Renumber is the keeper.)

        # 📊 Unit counts — "just show us the numbers of units in that PON"
        # (JJ 2026-07-23). READ-ONLY: counts demand points per PON straight from
        # the layers every time it opens. Deliberately makes no judgement about
        # which PONs should merge — the planner decides that.
        self._btn_pon_counts = _QPB2(f"⇔ Merge {_term}s")
        self._btn_pon_counts.setToolTip(
            f"Show every {_term} with its unit (demand point) and splitter count, "
            f"then merge the ones you pick.\n"
            "Counts are read live from the layers — never from a cached value.\n"
            "Opens read-only: nothing changes until you press Merge, and a "
            "backup is taken first.")
        self._btn_pon_counts.setStyleSheet(
            "QPushButton { background-color: #1c2f3f; color: #9fd0f5; font-weight: bold; "
            "border: 1px solid #35617f; border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #24405a; }")
        self._btn_pon_counts.clicked.connect(self._open_pon_unit_counts)
        gb_layout.addWidget(self._btn_pon_counts)

        # ⬡ Boundary Reshaper — ticket #139 (Luke, 2026-07-28). His Phalaborwa
        # project holds three networks and only Benfarm has neat boundaries
        # (median 14 vertices); Lulekani and Makhushane are buffer-union blobs at
        # 416 and 379. This rebuilds them as straight tiles using the SAME engine
        # the Merge tool already uses, so the two paths can never drift apart.
        # Preview-first and backup-gated, exactly like Merge.
        self._btn_pon_reshape = _QPB2(f"⬡ {_term} Boundary Reshaper")
        self._btn_pon_reshape.setToolTip(
            f"Turn rounded, bubble-shaped {_term} boundaries into straight-edged "
            "ones.\n"
            "Shows every boundary that would change before anything is written, "
            "and takes a backup first.\n"
            "Only the outlines move — no home changes "
            f"{_term}, and no other layer is touched.")
        self._btn_pon_reshape.setStyleSheet(
            "QPushButton { background-color: #1c2f3f; color: #9fd0f5; font-weight: bold; "
            "border: 1px solid #35617f; border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #24405a; }")
        self._btn_pon_reshape.clicked.connect(self._open_boundary_reshaper)
        gb_layout.addWidget(self._btn_pon_reshape)

        # 🔌 Connectivity Check — ticket #140 (Luke, 2026-07-28). Two questions he
        # asked in one breath: poles with nothing attached (his green dots) and
        # homes with no drop cable (his blue dots). Measured on his own project:
        # 65 unattached Benfarm poles and 267 homes with no drop across the three
        # networks. Both scans are read-only; only the Attach button writes, and
        # it states the BoQ change before it does.
        self._btn_connectivity = _QPB2("🔌 Connectivity Check")
        self._btn_connectivity.setToolTip(
            "Find poles with no cable attached, and homes with no drop cable.\n"
            "Highlights them on the map so you can see them.\n"
            "Scanning is read-only. Attaching drop cables CHANGES THE BoQ — it "
            "says how much before it writes, and takes a backup first.")
        self._btn_connectivity.setStyleSheet(
            "QPushButton { background-color: #1c2f3f; color: #9fd0f5; font-weight: bold; "
            "border: 1px solid #35617f; border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #24405a; }")
        self._btn_connectivity.clicked.connect(self._open_connectivity_check)
        gb_layout.addWidget(self._btn_connectivity)

        # 🔢 Renumber PONs — feeder-route renumber. Unlocked for beta testers and
        # ONLY runnable on a sandbox/test project (hard guard inside). Locked for team.
        self._btn_pon_renumber = _QPB2(f"🔢 Renumber {_term}s")
        self._btn_pon_renumber.setToolTip(
            "Renumber PONs/Zones in feeder-route order. Runs on any project — previews the "
            "full change first. Use the 💾 Backup button first if you want a safety copy.")
        self._btn_pon_renumber.setStyleSheet(
            "QPushButton { background-color: #1d3a2a; color: #8fe6b8; font-weight: bold; "
            "border: 1px solid #2f8860; border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #254a35; }")
        self._btn_pon_renumber.clicked.connect(
            self._open_zone_renumber if _is_beta else self._on_pon_renumber_locked)
        gb_layout.addWidget(self._btn_pon_renumber)

        # ↩ Undo last renumber — the other half of the backup. _pon_restore_zone_backup
        # existed but nothing called it (and nothing wrote its backups), so a renumber
        # was one-way. Both halves are live again as of 2026-07-15.
        self._btn_pon_restore = _QPB2("↩ Undo last Renumber")
        self._btn_pon_restore.setToolTip(
            "Roll every layer back to the snapshot taken before the LAST renumber.\n"
            "Restores the attribute tables exactly as they were, matched feature by "
            "feature.\nA backup is written automatically before every renumber — if "
            "it can't be written, the renumber is refused.")
        self._btn_pon_restore.setStyleSheet(
            "QPushButton { background-color: #6b5320; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #8a6c2a; }"
            "QPushButton:pressed { background-color: #4d3b17; }"
        )
        self._btn_pon_restore.clicked.connect(self._pon_restore_zone_backup)
        gb_layout.addWidget(self._btn_pon_restore)

        # 🔢 Delete + Renumber — remove PONs and close the gaps they leave
        self._btn_del_renum = _QPB2("🗑 Delete + Renumber  ·BETA")
        self._btn_del_renum.setToolTip(
            "Remove PONs (and, if you tick them, the drops / joints / splitters "
            "inside them), then renumber the survivors so there are no gaps —\n"
            "delete PON 15 and 16 becomes 15, 17 becomes 16, keeping the order "
            "they flow in now.\n"
            "Everything referencing a PON (the _SP tokens in the joint names) "
            "follows automatically.\n"
            "Previews the whole change first; backs up before it writes, and "
            "refuses to write if the backup fails.")
        self._btn_del_renum.setStyleSheet(
            "QPushButton { background-color: #7a2e2e; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #9c3d3d; }"
            "QPushButton:pressed { background-color: #5c2222; }"
        )
        self._btn_del_renum.clicked.connect(self.on_delete_renumber_clicked)
        gb_layout.addWidget(self._btn_del_renum)

        # Ticket #42 — all override buttons light blue (shared style)
        _OVERRIDE_BTN_QSS = (
            "QPushButton { background-color: #4FC3F7; color: #06283D; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover   { background-color: #81D4FA; }"
            "QPushButton:pressed { background-color: #29B6F6; }"
        )
        self.pushButton_manual_override.setStyleSheet(_OVERRIDE_BTN_QSS)
        gb_layout.addWidget(self.pushButton_manual_override)


        self._btn_create_enclosure = _QPB2("📍 Create Enclosure")
        self._btn_create_enclosure.setToolTip("Manually place a Feeder Splice or First Tier Splitter Splice enclosure on the map")
        self._btn_create_enclosure.setStyleSheet(
            "QPushButton { background-color: #2d6e2d; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #3d8f3d; }"
            "QPushButton:pressed { background-color: #1f4f1f; }"
            "QPushButton:checked { background-color: #1f4f1f; border: 2px solid #90ee90; }"
        )
        self._btn_create_enclosure.setCheckable(True)
        self._btn_create_enclosure.clicked.connect(self.on_create_enclosure_clicked)
        self._create_enclosure_tool = None   # holds active map tool
        self._create_enclosure_type = None   # 'FS' or 'FTS'
        gb_layout.addWidget(self._btn_create_enclosure)

        # ── "Create Span" manual line drawing button ──────────────────────
        self._btn_create_span = _QPB2("📐 Create Span")
        self._btn_create_span.setToolTip("Manually draw Feeder, Distribution, or other span cables on the map")
        self._btn_create_span.setStyleSheet(
            "QPushButton { background-color: #3d5a7a; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #4d7a9a; }"
            "QPushButton:pressed { background-color: #2d3a5a; }"
            "QPushButton:checked { background-color: #2d3a5a; border: 2px solid #87ceeb; }"
        )
        self._btn_create_span.setCheckable(True)
        self._btn_create_span.clicked.connect(self.on_create_span_clicked)
        self._create_span_tool = None   # holds active map tool
        self._create_span_type = None   # 'Feeder', 'Second Feeder', etc.
        # Ticket #51 — Create Span (Generate Span Lines) + Generate Poles to the TOP
        # of the menu (index 1/2, right under the GPKG output row).
        gb_layout.insertWidget(1, self._btn_create_span)
        gb_layout.insertWidget(2, self.pushButton_generate_poles)

        gb_layout.addWidget(self._manual_section)
        
        # Connect collapsible group boxes
        self.groupBox_4.toggled.connect(lambda checked: self.toggle_groupbox(self.groupBox_4, checked))
        self.groupBox_feeder_routes.toggled.connect(lambda checked: self.toggle_groupbox(self.groupBox_feeder_routes, checked))
        self.groupBox_individual_steps.toggled.connect(
            lambda checked: self.toggle_groupbox(self.groupBox_individual_steps, checked)
        )

        # Style the individual steps groupbox as a collapsible section
        self.groupBox_individual_steps.setStyleSheet(
            "QGroupBox {"
            f"  font-weight: bold; font-size: 9pt; color: {theme_safe.colors()['accent']};"
            "  border: 1px solid #7090b0; border-radius: 4px;"
            "  margin-top: 6px; padding-top: 6px;"
            "}"
            "QGroupBox::title {"
            "  subcontrol-origin: margin; subcontrol-position: top left;"
            "  padding: 0 4px; left: 6px;"
            "}"
            "QGroupBox::indicator { width: 14px; height: 14px; }"
        )

        # Initialize collapsed state for groups that start collapsed
        self.toggle_groupbox(self.groupBox_feeder_routes, False)
        self.toggle_groupbox(self.groupBox_individual_steps, False)
        
        # Connect layer type combo box to update label
        self.comboBox_clustering_method.currentIndexChanged.connect(self.on_clustering_method_changed)
        
        # Check if advanced libraries are available
        if not SKLEARN_AVAILABLE or not NUMPY_AVAILABLE:
            self.log_message("NOTE: Advanced clustering (DBSCAN, K-Means) requires scikit-learn and numpy.")
            self.log_message("Install with: pip install scikit-learn numpy")

        # Lock all planning sections until a client profile is loaded
        self._set_planning_sections_enabled(False)

        self.log_message("Velocity Network Planner initialized. Select a Client Profile to begin.")

    def on_clustering_method_changed(self, index):
        """Update UI elements based on selected clustering method."""
        # Only "Tight Groups of 8" method remains, no UI updates needed

    def on_layer_type_changed(self, index):
        """Layer type is fixed to Demand Points."""

    def on_set_client_clicked(self):
        """Load the selected client profile and unlock planning tools."""
        client_name = self.comboBox_client.currentText()
        if client_name == "-- Select Client --":
            self.log_message("ERROR: Please select a client from the dropdown before loading a profile.")
            return

        self.active_client = client_name
        self.active_client_profile = CLIENT_PROFILES[client_name]
        profile = self.active_client_profile

        # Update status label
        self.label_active_client.setText(client_name)
        self.label_active_client.setStyleSheet("color: green; font-weight: bold;")

        # Unlock planning sections
        self._set_planning_sections_enabled(True)

        self.log_message(f"--- Client Profile Loaded: {client_name} ---")
        self.log_message(f"  {profile['description']}")
        self.log_message(f"  Max PON size: {profile['max_pon_size']}  |  Target: {profile['target_pon_size']}")
        self.log_message(f"  Split ratio: Feeder {profile['splitter_ratio_feeder']}  |  Dist {profile['splitter_ratio_dist']}")
        self.log_message(f"  Max feeder cable: {profile['max_feeder_cable_fibres']}F  |  Max span: {profile['max_span_m']}m")
        self.log_message(f"  Pole heights: Feeder {profile['feeder_pole_height_m']}m  |  Dist {profile['dist_pole_height_m']}m")
        self.log_message("Planning tools are now unlocked.")

    def _set_planning_sections_enabled(self, enabled: bool):
        """Enable or disable all planning group boxes."""
        for gb in (self.groupBox_4, self.groupBox_feeder_routes, self.groupBox_individual_steps):
            gb.setEnabled(enabled)

    def toggle_groupbox(self, groupbox, checked):
        """Toggle visibility of groupbox contents for collapsible behavior."""
        # Get the layout inside the groupbox
        layout = groupbox.layout()
        if layout:
            # Show/hide all widgets in the layout
            for i in range(layout.count()):
                item = layout.itemAt(i)
                widget = item.widget()
                if widget:
                    widget.setVisible(checked)
                # Handle nested layouts
                nested_layout = item.layout()
                if nested_layout:
                    for j in range(nested_layout.count()):
                        nested_item = nested_layout.itemAt(j)
                        nested_widget = nested_item.widget()
                        if nested_widget:
                            nested_widget.setVisible(checked)

    # ── Persist the Network Planner session across plugin reloads (updates) ──────
    def _session_layer_map(self):
        """attr-name -> live layer handle, for the refs that must survive a reload."""
        return {
            "grouped_layer":          getattr(self, "grouped_layer", None),
            "splitter_points_layer":  getattr(self, "splitter_points_layer", None),
            "zone_boundaries_layer":  getattr(self, "zone_boundaries_layer", None),
            "drop_ptp_layer":         getattr(self, "drop_ptp_layer", None),
            "demand_points_layer":    getattr(self, "demand_points_layer", None),
            "_pon_accum_groups":      getattr(self, "_pon_accum_groups", None),
            "_pon_accum_zones":       getattr(self, "_pon_accum_zones", None),
            "_pon_accum_splitters":   getattr(self, "_pon_accum_splitters", None),
            "_pon_accum_drops":       getattr(self, "_pon_accum_drops", None),
        }

    def _session_save(self):
        """Snapshot the active layer handles + Properties picks to the PROJECT (custom
        property). The layers themselves live in the project and survive a plugin
        reload; only the dock's in-memory handles are lost — this lets the fresh dock
        re-bind them so splitters/zones/groups stay live through a one-click update."""
        try:
            import json
            from qgis.PyQt import sip as _sip_s
            from qgis.core import QgsProject
            data = {"layers": {}, "combos": {}}
            for name, ref in self._session_layer_map().items():
                try:
                    if ref is not None and not _sip_s.isdeleted(ref):
                        data["layers"][name] = ref.id()
                except Exception:
                    pass
            for ckey, attr in (("demand", "comboBox_erf"),
                               ("route", "comboBox_span_layer"),
                               ("road", "comboBox_road_layer")):
                cb = getattr(self, attr, None)
                try:
                    lyr = cb.currentLayer() if cb is not None else None
                    if lyr is not None:
                        data["combos"][ckey] = lyr.id()
                except Exception:
                    pass
            proj = QgsProject.instance()
            # writeEntry() marks the project DIRTY — but stashing our session is not a
            # user edit, so don't trigger a spurious "Save changes?" prompt. Preserve
            # whatever dirty state the project already had.
            _was_dirty = proj.isDirty()
            proj.writeEntry("velocity", "np_session", json.dumps(data))
            if not _was_dirty:
                proj.setDirty(False)
        except Exception:
            pass

    def _session_restore(self):
        """Rebind the dock's layer handles + Properties picks from the saved session,
        binding only to layers that still exist. No-op if there's no saved session
        (fresh project). Name-resolution (#60/#67) still backstops anything missed."""
        try:
            import json
            from qgis.core import QgsProject
            proj = QgsProject.instance()
            raw, ok = proj.readEntry("velocity", "np_session", "")
            if not ok or not raw:
                return
            data = json.loads(raw)
            rebound = 0
            for name, lid in (data.get("layers") or {}).items():
                lyr = proj.mapLayer(lid)
                if lyr is not None:
                    setattr(self, name, lyr)
                    rebound += 1
            for ckey, attr in (("demand", "comboBox_erf"),
                               ("route", "comboBox_span_layer"),
                               ("road", "comboBox_road_layer")):
                lid = (data.get("combos") or {}).get(ckey)
                cb = getattr(self, attr, None)
                if lid and cb is not None:
                    lyr = proj.mapLayer(lid)
                    if lyr is not None:
                        try:
                            cb.setLayer(lyr)
                        except Exception:
                            pass
            if rebound:
                self.log_message(
                    f"  ↺ Restored {rebound} Network Planner layer(s) after update — "
                    f"your splitters / zones / groups are still live.")
        except Exception:
            pass

    def _refresh_canvas_now(self):
        """Force an IMMEDIATE canvas redraw. `layer.triggerRepaint()` only QUEUES a
        repaint, which then waits behind the heavy drop-regen on the main thread —
        that's the 'takes a second to show on the canvas' lag when reassigning demand
        points / moving splitters. mapCanvas().refresh() renders as soon as the edit
        handler returns instead of on some later, unrelated repaint event."""
        try:
            self.iface.mapCanvas().refresh()
        except Exception:
            pass

    def log_message(self, message: str):
        """Add a message to the output text area.

        Args:
            message: Message to display
        """
        # Ticket #100 (#65 class): the dock's QTextEdit can be deleted out from under
        # us — a plugin reload/unload while a map tool is still active fires a canvas
        # callback that logs into the now-deleted C++ widget, raising
        # "RuntimeError: wrapped C/C++ object of type QTextEdit has been deleted" and
        # crashing the plugin. Logging must NEVER crash, so guard the append with both
        # a sip.isdeleted check and a RuntimeError catch (sip can lag a frame).
        try:
            if not sip.isdeleted(self.textEdit_output):
                self.textEdit_output.append(message)
        except RuntimeError:
            pass   # QTextEdit already torn down — nothing to log into
        except Exception:
            pass
        # Feed the Geometry Guardian's black-box breadcrumb so that, if geometry
        # mass-vanishes, the incident report shows what the plugin was doing.
        try:
            from ..geometry_guardian import record_activity
            record_activity(message)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Timer / progress helpers
    # ------------------------------------------------------------------
    def _fmt_time(self, secs: float) -> str:
        """Format seconds into human-readable string."""
        if secs >= 3600:
            return f"{int(secs // 3600)}h {int((secs % 3600) // 60)}m"
        elif secs >= 60:
            return f"{int(secs // 60)}m {int(secs % 60)}s"
        else:
            return f"{secs:.1f}s"

    def _op_tick(self):
        """Called every 500 ms by _prog_timer to update the elapsed/ETA display."""
        import time
        if self._op_t0 is None:
            return
        secs = time.time() - self._op_t0
        elapsed_str = self._fmt_time(secs)
        pct = self._prog_bar.value()
        if pct > 0:
            eta_secs = secs * (100 - pct) / pct
            eta_str = f" | ETA: ~{self._fmt_time(eta_secs)}"
        else:
            eta_str = ""
        self._prog_time_lbl.setText(f"\u23f1 {elapsed_str}{eta_str}")

    def _start_timer(self):
        """Record the start time and show the progress strip."""
        import time
        self._op_t0 = time.time()
        self._op_last_pct = -1
        self._strip_gen += 1
        self._prog_bar.setValue(0)
        self._prog_time_lbl.setText("0s")
        self._prog_op_lbl.setText("Processing\u2026")
        self._prog_strip.setVisible(True)
        self._prog_timer.start()

    def _hide_prog_strip(self, gen: int):
        """Hide the progress strip only if no newer operation has started since gen."""
        if self._strip_gen == gen:
            self._prog_strip.setVisible(False)

    def _elapsed(self, label: str = ''):
        """Log time elapsed since _start_timer() was called, then finalise the strip."""
        import time
        from qgis.PyQt.QtCore import QTimer as _QT
        from qgis.PyQt.QtWidgets import QApplication as _QApp
        if self._op_t0 is None:
            return
        secs = time.time() - self._op_t0
        t_str = self._fmt_time(secs)
        prefix = f"{label} \u2014 " if label else ''
        self.log_message(f"  \u23f1 {prefix}{t_str}")
        # Finalise the strip
        self._prog_timer.stop()
        self._prog_bar.setValue(100)
        self._prog_op_lbl.setText(f"\u2713 {label}" if label else "\u2713 Done")
        self._prog_time_lbl.setText(f"\u23f1 {t_str}")
        _QApp.processEvents()
        _gen = self._strip_gen
        _QT.singleShot(3000, lambda: self._hide_prog_strip(_gen))
        self._op_t0 = None

    def _progress(self, done: int, total: int, label: str = ''):
        """Update progress bar and log at 25 % milestones; flush Qt event queue."""
        from qgis.PyQt.QtWidgets import QApplication
        import time
        if total > 0:
            pct = done * 100 // total
            self._prog_bar.setValue(pct)
            if label:
                self._prog_op_lbl.setText(label)
            milestone = (pct // 25) * 25
            if milestone > 0 and milestone != self._op_last_pct:
                self._op_last_pct = milestone
                elapsed = (time.time() - self._op_t0) if self._op_t0 is not None else 0.0
                tag = f"{label}: " if label else ''
                self.log_message(
                    f"  {tag}{milestone}%  ({done}/{total})  [{elapsed:.1f}s]"
                )
        QApplication.processEvents()

    def _on_kill_clicked(self):
        """Set the cancel flag so any running loop can detect and abort."""
        self._cancel_requested = True
        self._prog_op_lbl.setText("⛔ Cancelled — stopping…")
        self.log_message("⛔ CANCELLED by user — operation stopped.")

    def _cancel_check(self) -> bool:
        """Return True (and reset flag) if the user pressed Kill. Callers should return early."""
        if self._cancel_requested:
            self._cancel_requested = False
            return True
        return False

    def _start_operation(self, label: str = "Processing…"):
        """Reset cancel flag and start the progress strip."""
        self._cancel_requested = False
        self._start_timer()
        self._prog_op_lbl.setText(label)
    # keeps a strong reference and the signal connections stay alive)
    # ------------------------------------------------------------------
    def _save_gpkg_path(self, text: str):
        """Write the GPKG path into the current project's custom properties."""
        from qgis.core import QgsProject
        QgsProject.instance().writeEntry("FTTHPlanTool", "output_gpkg", text.strip())

    def _reload_gpkg_path(self):
        """Read back the GPKG path from the project and populate the field."""
        from qgis.core import QgsProject
        path = QgsProject.instance().readEntry("FTTHPlanTool", "output_gpkg", "")[0]
        self._output_gpkg_edit.blockSignals(True)
        self._output_gpkg_edit.setText(path)
        self._output_gpkg_edit.blockSignals(False)

    def _clear_gpkg_path(self):
        """Clear the GPKG field when a new/empty project is created."""
        self._output_gpkg_edit.blockSignals(True)
        self._output_gpkg_edit.clear()
        self._output_gpkg_edit.blockSignals(False)

    def _browse_gpkg_path(self):
        """Open file browser, set the GPKG path field, and immediately persist it."""
        from qgis.core import QgsProject
        from qgis.PyQt.QtWidgets import QFileDialog
        start = self._output_gpkg_edit.text() or QgsProject.instance().homePath() or ''
        path, _ = QFileDialog.getSaveFileName(self, "Select Output GeoPackage", start,
                                              "GeoPackage (*.gpkg)")
        if path:
            if not path.lower().endswith('.gpkg'):
                path += '.gpkg'
            self._output_gpkg_edit.setText(path)   # triggers textChanged → _save_gpkg_path

    # ------------------------------------------------------------------
    # Output layer persistence
    # ------------------------------------------------------------------
    def _add_layer_on_top(self, layer):
        """Add a layer to the project ABOVE the existing layers.

        Audit Batch A: every generated output (poles/drops/splitters/zones/…) used
        a bare `addMapLayer(layer)`, which lets QGIS drop the new layer wherever the
        current tree selection points — frequently UNDER the opaque satellite
        basemap, so the operator gets a 'Created N …' log but a blank canvas. Adding
        with addToLegend=False then inserting the tree node at index 0 guarantees the
        output sits on top and is visible + toggleable. Best-effort: on any failure
        fall back to the plain add so a layer is never lost.
        """
        from qgis.core import QgsProject, QgsLayerTreeLayer
        proj = QgsProject.instance()
        try:
            proj.addMapLayer(layer, False)
            proj.layerTreeRoot().insertChildNode(0, QgsLayerTreeLayer(layer))
        except Exception:
            try:
                proj.addMapLayer(layer)
            except Exception:
                pass
        return layer

    def _add_output_layer(self, mem_layer: 'QgsVectorLayer') -> 'QgsVectorLayer':
        """Write a memory layer to the configured output GeoPackage and add to project.

        If no GeoPackage path is configured, falls back to adding the memory
        (scratch) layer directly.  Returns the layer that was added to the project
        (file-based if GPKG was used, otherwise the original memory layer).
        """
        import os
        from qgis.core import QgsVectorFileWriter, QgsProject

        gpkg_path = self._output_gpkg_edit.text().strip()

        if not gpkg_path:
            self._add_layer_on_top(mem_layer)
            return mem_layer

        # Sanitize layer name → GPKG table name
        layer_name = mem_layer.name()
        table_name = re.sub(r'[^a-zA-Z0-9]', '_', layer_name).strip('_') or 'ftth_layer'

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        options.layerName = table_name
        # If the GPKG file doesn't exist yet use CreateOrOverwriteFile (creates the file).
        # If it does exist use CreateOrOverwriteLayer (adds/replaces just this table).
        if os.path.exists(gpkg_path):
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
        else:
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile

        self.log_message(f"  💾 Writing '{layer_name}' → {os.path.basename(gpkg_path)} …")

        try:
            error, msg, _, _ = QgsVectorFileWriter.writeAsVectorFormatV3(
                mem_layer, gpkg_path, QgsProject.instance().transformContext(), options)
        except Exception as exc:
            self.log_message(f"  ❌ GPKG write exception: {exc}")
            self.log_message("  Layer added as temporary scratch layer instead.")
            self._add_layer_on_top(mem_layer)
            return mem_layer

        if error != QgsVectorFileWriter.NoError:
            self.log_message(f"  ❌ GPKG write failed (code {error}): {msg}")
            self.log_message("  Layer added as temporary scratch layer instead.")
            self._add_layer_on_top(mem_layer)
            return mem_layer

        # Reload from GPKG as a persistent file-based layer
        uri = f"{gpkg_path}|layername={table_name}"
        file_layer = QgsVectorLayer(uri, layer_name, "ogr")
        if not file_layer.isValid():
            self.log_message(f"  ❌ Saved OK but reload failed for '{layer_name}' — using scratch.")
            self._add_layer_on_top(mem_layer)
            return mem_layer

        # Transfer renderer and labeling from the memory layer
        if mem_layer.renderer():
            file_layer.setRenderer(mem_layer.renderer().clone())
        if mem_layer.labeling():
            file_layer.setLabeling(mem_layer.labeling().clone())
            file_layer.setLabelsEnabled(mem_layer.labelsEnabled())

        self._add_layer_on_top(file_layer)
        self.log_message(f"  ✅ Saved [{table_name}]")
        return file_layer


    def on_build_graph_clicked(self):
        """Build network graph from selected layers."""
        nodes_layer = self.comboBox_nodes.currentLayer()
        ducts_layer = self.comboBox_ducts.currentLayer()
        
        if not ducts_layer:
            self.log_message("ERROR: Please select a ducts layer.")
            return
        
        self._start_timer()
        try:
            self.log_message("Building network graph...")
            # CRS-aware metre-distance so edge lengths / optical loss / the
            # total-length figure are in real metres, not decimal degrees,
            # when the ducts layer is in a geographic CRS (e.g. EPSG:4326).
            self.network_graph = NetworkGraph(
                dist_func=self._make_metre_dist_func(ducts_layer)
            )

            # Add named nodes if a nodes layer is selected
            if nodes_layer:
                self.log_message(f"Loading nodes from '{nodes_layer.name()}'...")
                node_count = 0
                for feature in get_layer_features(nodes_layer):
                    coords = get_point_coordinates(feature)
                    if coords:
                        self.network_graph.add_node_from_qgis(
                            f"node_{feature.id()}",
                            coords,
                            properties=feature.attributeMap(),
                        )
                        node_count += 1
                self.log_message(f"  Added {node_count} nodes")

            # Add edges from ducts (intermediate vertices included)
            self.log_message(f"Loading ducts from '{ducts_layer.name()}'...")
            duct_count = 0
            for feature in get_layer_features(ducts_layer):
                coords = get_linestring_coordinates(feature)
                if coords and len(coords) >= 2:
                    self.network_graph.add_edge_from_qgis(
                        coords,
                        properties=feature.attributeMap(),
                    )
                    duct_count += 1
            self.log_message(f"  Processed {duct_count} duct features")

            # Display graph info
            info = self.network_graph.get_graph_info()
            self.log_message("\nGraph built successfully:")
            self.log_message(f"  Total nodes  : {info['nodes']}")
            self.log_message(f"  Total edges  : {info['edges']}")
            self.log_message(f"  Total length : {info.get('total_length', 0):.2f}")
            self.log_message(f"  Connected    : {info['connected']}")
            if info['components'] > 1:
                self.log_message(
                    f"  WARNING: {info['components']} isolated network islands detected. "
                    f"Sizes: {info['component_sizes']}"
                )
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR building graph: {e!s}")

    def _make_metre_dist_func(self, layer):
        """Return an ``f((x,y),(x,y)) -> metres`` for *layer*'s CRS.

        Uses ``QgsDistanceArea`` configured with the layer CRS + the project
        ellipsoid so distances are real metres even for a geographic CRS
        (EPSG:4326).  Falls back to plain Euclidean if the layer/CRS is
        unavailable (correct only when the CRS is already projected metres).
        """
        try:
            crs = layer.crs() if layer else None
            if crs is None or not crs.isValid():
                return None
            da = QgsDistanceArea()
            da.setSourceCrs(crs, QgsProject.instance().transformContext())
            da.setEllipsoid(_safe_ellipsoid(QgsProject.instance(), crs))

            def _dist_m(a, b):
                return da.measureLine(
                    QgsPointXY(a[0], a[1]), QgsPointXY(b[0], b[1])
                )

            return _dist_m
        except Exception:
            return None

    def on_calculate_clicked(self):
        """Calculate shortest path between two points."""
        if not self.network_graph or self.network_graph.G.number_of_nodes() == 0:
            self.log_message("ERROR: Please build the network graph first.")
            return
        
        ducts_layer = self.comboBox_ducts.currentLayer()
        if not ducts_layer:
            self.log_message("ERROR: No ducts layer selected.")
            return
        
        # Use first and last node coordinates as example
        nodes = list(self.network_graph.G.nodes(data=True))
        if len(nodes) < 2:
            self.log_message("ERROR: Need at least 2 nodes for routing.")
            return
        
        source_coord = nodes[0][1]['coord']
        target_coord = nodes[-1][1]['coord']
        
        self.log_message("\nCalculating route...")
        self.log_message(f"  From: {source_coord}")
        self.log_message(f"  To: {target_coord}")
        self._start_timer()
        try:
            path_coords, total_length = self.network_graph.shortest_path_with_cost(
                source_coord, target_coord
            )
            self.log_message(f"  Route found with {len(path_coords)} vertices")
            self.log_message(f"  Total length : {total_length:.2f}")
            self.log_message(f"  Optical loss : {self._path_loss_db(path_coords):.3f} dB")

            # Create result layer
            self.create_result_layer(path_coords, total_length)
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR calculating route: {e!s}")

    def create_result_layer(self, path_coords, total_length):
        """Create a layer to display the routing result.
        
        Args:
            path_coords: List of (x, y) coordinate tuples
            total_length: Total path length
        """
        # Remove old result layer if exists
        if self.result_layer:
            QgsProject.instance().removeMapLayer(self.result_layer.id())
        
        # Get CRS from ducts layer
        ducts_layer = self.comboBox_ducts.currentLayer()
        crs = ducts_layer.crs().authid() if ducts_layer else "EPSG:4326"
        
        # Create new result layer
        self.result_layer = create_memory_layer("FTTH Route Result", "LineString", crs)
        
        # Add fields
        add_fields_to_layer(self.result_layer, [
            ('route_id', int, 'Integer'),
            ('length', float, 'Double'),
            ('num_points', int, 'Integer')
        ])
        self.result_layer.updateFields()
        
        # Add the route as a line feature
        attributes = {
            'route_id': 1,
            'length': total_length,
            'num_points': len(path_coords)
        }
        add_line_feature(self.result_layer, path_coords, attributes)
        
        # Update layer extent and add to map
        self.result_layer.updateExtents()
        QgsProject.instance().addMapLayer(self.result_layer)
        
        self.log_message("  Result layer added to map.")

    def _path_loss_db(self, path_coords: list) -> float:
        """Sum optical loss_db across graph edges that form *path_coords*.

        Walks consecutive coordinate pairs and looks up the edge in the graph.
        Coordinates are snapped via the graph's own precision before lookup.
        """
        if not self.network_graph:
            return 0.0
        ng = self.network_graph
        total = 0.0
        for raw_u, raw_v in zip(path_coords[:-1], path_coords[1:]):
            su = _snap_coord(raw_u, ng.snap_precision)
            sv = _snap_coord(raw_v, ng.snap_precision)
            nu = ng._coord_index.get(su)
            nv = ng._coord_index.get(sv)
            if nu and nv and ng.G.has_edge(nu, nv):
                total += ng.G.edges[nu, nv].get('loss_db', 0.0)
        return total

    def on_analyze_clicked(self):
        """Analyze selected layers and display statistics."""
        nodes_layer = self.comboBox_nodes.currentLayer()
        ducts_layer = self.comboBox_ducts.currentLayer()
        
        self.log_message("\n=== Layer Analysis ===")
        self._start_timer()
        if nodes_layer:
            self.log_message(f"\nNodes Layer: '{nodes_layer.name()}'")
            self.log_message(f"  Feature count: {nodes_layer.featureCount()}")
            self.log_message(f"  CRS: {nodes_layer.crs().authid()}")
            counts = count_features_by_geometry_type(nodes_layer)
            for geom_type, count in counts.items():
                if count > 0:
                    self.log_message(f"  {geom_type}: {count}")
            
            # List fields
            fields = nodes_layer.fields()
            field_names = [field.name() for field in fields]
            self.log_message(f"  Fields: {', '.join(field_names)}")
        
        if ducts_layer:
            self.log_message(f"\nDucts Layer: '{ducts_layer.name()}'")
            self.log_message(f"  Feature count: {ducts_layer.featureCount()}")
            self.log_message(f"  CRS: {ducts_layer.crs().authid()}")
            counts = count_features_by_geometry_type(ducts_layer)
            for geom_type, count in counts.items():
                if count > 0:
                    self.log_message(f"  {geom_type}: {count}")
            
            # List fields
            fields = ducts_layer.fields()
            field_names = [field.name() for field in fields]
            self.log_message(f"  Fields: {', '.join(field_names)}")
            
            # Calculate total length in metres using QgsDistanceArea (handles geographic/projected CRS)
            from qgis.core import QgsDistanceArea
            da = QgsDistanceArea()
            da.setSourceCrs(ducts_layer.crs(), QgsProject.instance().transformContext())
            da.setEllipsoid(_safe_ellipsoid(QgsProject.instance(), ducts_layer.crs()))
            total_length = 0
            for feature in get_layer_features(ducts_layer):
                geom = feature.geometry()
                if geom and not geom.isEmpty():
                    total_length += da.measureLength(geom)
            self.log_message(f"  Total length: {total_length:.2f} m")
        self._elapsed("Total time")

    def on_clear_clicked(self):
        """Clear output and remove result layer."""
        self.textEdit_output.clear()
        
        if self.result_layer:
            QgsProject.instance().removeMapLayer(self.result_layer.id())
            self.result_layer = None

    def _refresh_properties(self):
        """🔄 Re-scan the project and auto-detect the demand / route / road layers
        into the dropdowns — so newly added, renamed or reloaded layers are picked
        up without re-running AutoNet. Purely re-selects layers; changes no data."""
        try:
            from qgis.core import QgsProject, QgsMapLayer, QgsWkbTypes
            G = QgsWkbTypes.GeometryType
            vlayers = [lyr for lyr in QgsProject.instance().mapLayers().values()
                       if lyr.type() == QgsMapLayer.LayerType.VectorLayer]

            # candidate + ambiguity counts per role, for the honest report below
            # (pure describe-only; the SELECTION logic is unchanged).
            cand_counts, ambiguous = {}, {}

            def pick(role, combo, keywords, geoms):
                if combo is None:
                    return None
                cands = [lyr for lyr in vlayers if lyr.geometryType() in geoms]
                cand_counts[role] = len(cands)
                ambiguous[role] = sum(
                    1 for lyr in cands
                    if any(kw in lyr.name().lower() for kw in keywords))
                for kw in keywords:
                    for lyr in cands:
                        if kw in lyr.name().lower():
                            combo.setLayer(lyr)
                            return lyr.name()
                return None

            picked = {
                "demand": pick("demand", getattr(self, "comboBox_erf", None),
                               ("demand", "parcel", "erf", "erven", "building",
                                "stand", "subscriber", "home", "ont"),
                               (G.PolygonGeometry, G.PointGeometry)),
                "route": pick("route", getattr(self, "comboBox_span_layer", None),
                              ("span", "route", "fibre", "fiber", "cable", "duct",
                               "trunk", "backbone"), (G.LineGeometry,)),
                "road": pick("road", getattr(self, "comboBox_road_layer", None),
                             ("road", "street", "highway", "lane", "avenue"),
                             (G.LineGeometry,)),
            }
            hits = ", ".join(f"{k}={v}" for k, v in picked.items() if v) or "no matches"
            try:
                self.log_message(f"🔄 Layers refreshed — {hits}")
            except Exception:
                pass
            # Pass 7: honest per-role report (what matched / not found / ambiguous).
            try:
                try:
                    from .properties_ux import detect_report
                except ImportError:
                    from properties_ux import detect_report
                for _ln in detect_report(picked, cand_counts, ambiguous):
                    self.log_message(_ln)
            except Exception:
                pass
            try:
                self.iface.messageBar().pushSuccess(
                    "Network Planner", f"Layers refreshed ({hits}).")
            except Exception:
                pass
        except Exception as e:
            try:
                self.log_message(f"Refresh failed: {e}")
            except Exception:
                pass

    # ------------------------------------------------------------------
    # PON Tools (BETA) — beta-access gate + read-only Inspector + locked Renumber
    # ------------------------------------------------------------------
    def _pon_is_beta_user(self):
        """Renumber {Zone}s is OPEN TO EVERYONE now (JJ 2026-06-25) but stays BETA:
        the button keeps its ·BETA badge + warning banner, and Finalize still backs up
        first and is sandbox-guarded. (Was limited to PON_BETA_USERS.)"""
        return True

    def _on_pon_feature_locked(self):
        """Generic 'locked for the team' message for non-beta users."""
        from qgis.PyQt.QtWidgets import QMessageBox
        QMessageBox.information(
            self, "PON Tools — BETA",
            "🧪 These PON tools are in BETA and currently limited to testers.\n\n"
            "• You CAN use 🎯 PON per PON Manual to generate PONs now.\n"
            "• Renumber will open up to everyone once testing is done.")

    # ------------------------------------------------------------------
    # PON Renumber by feeder route (BETA) — sandbox-guarded, preview-first.
    # ------------------------------------------------------------------
    def _pon_project_is_sandbox(self):
        """GRADUATED (JJ 2026-07-03): Renumber is out of BETA and runs on ANY project.
        The sandbox-only restriction is lifted — the safety net is now the preview-first
        flow plus the automatic project backup taken before any write. Returns True so
        the guard call-sites allow the renumber to proceed on real projects too."""
        return True

    def _feeder_trunk_geoms(self, lyr):
        """Return ([geometries], capacity_field, capacity_value) for the FEEDER TRUNK:
        the highest-capacity class only (e.g. 144F), not every capacity mixed. A feeder
        layer typically carries 144F + 48F + 24F; only the 144F line is the continuous
        trunk to follow. Falls back to all features when no capacity field is found."""

        def cap_num(v):
            m = re.search(r"\d+", str(v) if v is not None else "")
            return int(m.group()) if m else None

        # prefer the categorized renderer's class field (what the legend groups by)
        field = None
        try:
            from qgis.core import QgsCategorizedSymbolRenderer
            r = lyr.renderer()
            if isinstance(r, QgsCategorizedSymbolRenderer):
                field = r.classAttribute()
        except Exception:
            field = None
        names = {f.name().lower(): f.name() for f in lyr.fields()}
        all_names = {f.name() for f in lyr.fields()}
        if not field or field not in all_names:
            field = None
            for cand in ("capacity", "cable_size", "cable", "size", "fibre",
                         "fiber", "cores", "core", "fibre_coun", "cap", "count"):
                if cand in names:
                    field = names[cand]
                    break
        if field:
            buckets = {}
            for ft in lyr.getFeatures():
                try:
                    n = cap_num(ft[field])
                except Exception:
                    n = None
                if n is not None:
                    buckets.setdefault(n, []).append(ft)
            if buckets:
                top = max(buckets.keys())  # highest capacity = the trunk
                geoms = [ft.geometry() for ft in buckets[top]
                         if ft.geometry() and not ft.geometry().isEmpty()]
                if geoms:
                    return geoms, field, top
        # fallback — no capacity field: use every feature
        geoms = [f.geometry() for f in lyr.getFeatures()
                 if f.geometry() and not f.geometry().isEmpty()]
        return geoms, None, None

    def _pon_renumber_fields(self):
        """Decide which field IS the PON across this project, ONCE (field names are
        consistent project-wide). Returns (pon_field, zone_field, zone_name_field,
        is_real_pon):
          • pon_no/pon present → that is the PON; zone_id is a SEPARATE parent zone to
            derive (is_real_pon=True). (finished HLD, e.g. Mohadin)
          • else zone_id/zone_no/zone → the zone polygon IS the PON; no separate zone
            (is_real_pon=False). (network-planner / sandbox, e.g. Matiko)
        group_id is deliberately ignored — those are splitters, not PONs."""
        from qgis.core import QgsProject, QgsVectorLayer
        have = {}
        for lyr in QgsProject.instance().mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
                continue
            for f in lyr.fields():
                k = f.name().lower()
                if k in ("pon_no", "pon", "zone_id", "zone_no", "zone", "zone_name") \
                        and k not in have:
                    have[k] = f.name()
        pon_field, is_real = None, False
        for k in ("pon_no", "pon"):
            if k in have:
                pon_field, is_real = have[k], True
                break
        if not pon_field:
            for k in ("zone_id", "zone_no", "zone"):
                if k in have:
                    pon_field = have[k]
                    break
        zone_field = None
        if is_real:
            for k in ("zone_id", "zone_no", "zone"):
                if k in have and have[k] != pon_field:
                    zone_field = have[k]
                    break
        return pon_field, zone_field, have.get("zone_name"), is_real

    def _pon_min_id(self):
        """Lowest existing PON-id value in the project (int), or None — used to default
        the 'first PON #' so a renumber preserves the project's numbering base."""
        from qgis.core import QgsProject, QgsVectorLayer
        pon_field, _zf, _znf, _ir = self._pon_renumber_fields()
        if not pon_field:
            return None
        pk = pon_field.lower()
        vals = []
        for lyr in QgsProject.instance().mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
                continue
            fn = {f.name().lower(): f.name() for f in lyr.fields()}
            if pk not in fn:
                continue
            for ft in lyr.getFeatures():
                try:
                    vals.append(int(float(ft[fn[pk]])))
                except Exception:
                    pass
            if vals:
                break
        return min(vals) if vals else None

    def _apply_np_shell_style(self):
        """Pass 0 (Shell & Look) — one shared, theme-safe visual language for the
        whole Network Planner dock.

        Goal: every tab and button reads as one polished product — consistent button
        shape, clear hover / pressed / disabled feedback, tidy group boxes, readable
        inputs and a slim scrollbar — in light, dark and custom themes.

        Why it is SAFE: this sets *geometry and states* (padding, radius, borders,
        hover) via type selectors on ``dockWidgetContents`` only. It never sets a
        button ``background-color``, so the semantic colours applied inline elsewhere
        (AutoNet green, Delete red, …) win and are preserved. No widget is moved and
        no handler is touched, so behaviour is identical. Fail-open: any error just
        leaves the previous look in place.
        """
        try:
            target = getattr(self, "dockWidgetContents", None)
            if target is None:
                return
            c = theme_safe.colors(self)
            accent, muted = c["accent"], c["muted"]
            line = "rgba(128,128,128,0.32)"
            line_soft = "rgba(128,128,128,0.18)"
            qss = f"""
            QPushButton {{
                padding: 7px 11px;
                border: 1px solid {line};
                border-radius: 6px;
                min-height: 17px;
            }}
            QPushButton:hover:enabled {{ border: 1px solid {accent}; }}
            QPushButton:pressed {{ padding-top: 8px; padding-bottom: 6px; }}
            QPushButton:disabled {{ color: {muted}; border-color: {line_soft}; }}
            QGroupBox {{
                border: 1px solid {line};
                border-radius: 8px;
                margin-top: 11px;
                padding: 9px 8px 8px 8px;
                font-weight: bold;
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                subcontrol-position: top left;
                left: 10px;
                padding: 0 4px;
                color: {accent};
            }}
            QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit {{
                padding: 4px 6px;
                border: 1px solid {line};
                border-radius: 5px;
                min-height: 17px;
            }}
            QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus, QLineEdit:focus {{
                border: 1px solid {accent};
            }}
            QCheckBox {{ spacing: 7px; }}
            QScrollBar:vertical {{ width: 10px; background: transparent; margin: 0; }}
            QScrollBar::handle:vertical {{
                background: {line}; border-radius: 5px; min-height: 32px;
            }}
            QScrollBar::handle:vertical:hover {{ background: {accent}; }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ background: transparent; }}
            """
            target.setStyleSheet(qss)
        except Exception:
            pass

    def _pon_term(self):
        """The word for the unit the planner works in. Always 'PON'.

        It used to return 'Zone' whenever the zone polygon WAS the PON — which is
        the common case in the Network Planner, so most people only ever saw the
        word "Zone". JJ 2026-07-23: "zones are actually PONs at the current
        moment, but they don't want to see it that way, and it confuses a lot of
        people." So there is one word now, and it is the correct one.

        UI ONLY. Verified before changing: every call site puts this into a button
        label, a dialog title or a message — none of it reaches an attribute
        write, so no stored data changes and no existing project is affected.
        """
        return "PON"

    def _open_pon_unit_counts(self):
        """Open the read-only unit-count list for every PON.

        Wrapped end-to-end: a broken layer in someone's project must not take
        the whole dock down, so any failure becomes a message, never a crash.
        """
        try:
            from qgis.core import QgsProject

            from .pon_merge_dialog import open_pon_list
            open_pon_list(QgsProject.instance(), parent=self,
                          term=self._pon_term())
        except Exception as exc:
            try:
                from qgis.PyQt.QtWidgets import QMessageBox
                QMessageBox.warning(self, "Unit counts",
                                    f"Could not open the unit counts:\n{exc}")
            except Exception:
                pass

    def _open_boundary_reshaper(self):
        """Open the PON Boundary Reshaper (ticket #139).

        Wrapped end-to-end for the same reason as the unit counts above: a broken
        layer in someone's project must become a message, never a dead dock.
        """
        try:
            from qgis.core import QgsProject

            from .boundary_reshaper_dialog import open_boundary_reshaper
            open_boundary_reshaper(QgsProject.instance(), parent=self,
                                   term=self._pon_term())
        except Exception as exc:
            try:
                from qgis.PyQt.QtWidgets import QMessageBox
                QMessageBox.warning(self, "Boundary Reshaper",
                                    f"Could not open the reshaper:\n{exc}")
            except Exception:
                pass

    def _open_connectivity_check(self):
        """Open the Connectivity Check (ticket #140).

        Wrapped end-to-end for the same reason as the reshaper above: a broken
        layer in someone's project must become a message, never a dead dock.
        """
        try:
            from qgis.core import QgsProject

            from .connectivity_dialog import open_connectivity_check
            open_connectivity_check(QgsProject.instance(), parent=self,
                                    iface=getattr(self, "iface", None))
        except Exception as exc:
            try:
                from qgis.PyQt.QtWidgets import QMessageBox
                QMessageBox.warning(self, "Connectivity Check",
                                    f"Could not open the connectivity check:\n{exc}")
            except Exception:
                pass

    def _pon_zone_polys(self, pon_field):
        """{pon_id_str: QgsGeometry} of the zone/PON BOUNDARY polygons (the 'big
        blobs') so the animation can flash each one as the walker dives in."""
        from qgis.core import QgsProject, QgsVectorLayer
        out = {}
        pk = (pon_field or "").lower()
        best = None
        for lyr in QgsProject.instance().mapLayers().values():
            if (isinstance(lyr, QgsVectorLayer) and lyr.isValid()
                    and lyr.geometryType() == 2
                    and pk in {f.name().lower(): 1 for f in lyr.fields()}):
                nl = lyr.name().lower()
                if best is None or ("zone" in nl or "pon" in nl):
                    best = lyr
        if not best:
            return out
        fn = {f.name().lower(): f.name() for f in best.fields()}
        for ft in best.getFeatures():
            try:
                v = ft[fn[pk]]
            except Exception:
                v = None
            if v in (None, "") or str(v) in out:
                continue
            g = ft.geometry()
            if g and not g.isEmpty():
                out[str(v)] = QgsGeometry(g)
        return out

    def _pon_zone_distribution(self, zone_polys, feeder_geom):
        """For each zone, the REAL distribution cable to dive along: the cable inside the
        zone polygon whose end is nearest the feeder, oriented entry(near feeder)→into
        the zone. Returns {zone_id_str: [QgsPointXY,...]}. Spatial — needs no zone tag."""
        from qgis.core import (QgsProject, QgsVectorLayer, QgsSpatialIndex,
                               QgsGeometry, QgsPointXY)
        dls = [l for l in QgsProject.instance().mapLayers().values()
               if isinstance(l, QgsVectorLayer) and l.isValid()
               and l.geometryType() == 1 and "distribution" in l.name().lower()]
        if not dls:
            return {}
        dl = dls[0]
        feats = {}
        idx = QgsSpatialIndex()
        for ft in dl.getFeatures():
            g = ft.geometry()
            if g and not g.isEmpty():
                feats[ft.id()] = g
                idx.insertFeature(ft)

        def _line(g):
            if g.isMultipart():
                parts = g.asMultiPolyline()
                return max(parts, key=len) if parts else []
            return g.asPolyline()

        out = {}
        for z, poly in zone_polys.items():
            inside = [feats[fid] for fid in idx.intersects(poly.boundingBox())
                      if fid in feats and poly.intersects(feats[fid])]
            best, best_d = None, 1e18
            for g in inside:
                ln = _line(g)
                if len(ln) < 2:
                    continue
                d0 = feeder_geom.distance(QgsGeometry.fromPointXY(QgsPointXY(ln[0])))
                d1 = feeder_geom.distance(QgsGeometry.fromPointXY(QgsPointXY(ln[-1])))
                dmin = min(d0, d1)
                if dmin < best_d:
                    best_d = dmin
                    best = [QgsPointXY(p) for p in (ln if d0 <= d1 else list(reversed(ln)))]
            if best:
                out[str(z)] = best
        return out

    def _pon_anim_cleanup(self):
        """Stop + remove the running renumber animation (its own rubber bands + timer)."""
        a = getattr(self, "_pon_anim", None)
        if not a:
            return
        try:
            if a.get("timer"):
                a["timer"].stop()
        except Exception:
            pass
        for k in ("path", "walker", "dive"):
            try:
                if a.get(k):
                    a[k].reset()
            except Exception:
                pass
        self._pon_anim = None

    def _pon_clear_display(self):
        """Wipe everything the renumber drew: the walk overlays + the 'Renumber Flow'
        and 'PON Renumber Path' display layers. Touches no real data."""
        self._pon_anim_cleanup()
        try:
            from qgis.core import QgsProject, QgsVectorLayer
            for l in list(QgsProject.instance().mapLayers().values()):
                if isinstance(l, QgsVectorLayer) and (
                        l.name() == "PON Renumber Path"
                        or l.name().startswith("Renumber Flow")):
                    QgsProject.instance().removeMapLayer(l.id())
            self.iface.mapCanvas().refresh()
        except Exception:
            pass

    def _pon_animate_trace(self, feeder_layer, mapping, rep, term, start_spec=None,
                           on_done=None):
        """Animate the renumber walk like the HTML mockup: the marker flows FORWARD
        along the feeder from the start point, and at each zone (the first in line, then
        the next) dives along that zone's distribution cable into the blob, numbers it,
        and climbs back — monotonic, never running the whole feeder and back. Visual
        only. mapping = [(old, new, zone)] in feeder order, rep = {old: centroid}."""
        from qgis.PyQt.QtCore import QTimer, QMetaType
        from qgis.PyQt.QtGui import QColor
        from qgis.gui import QgsRubberBand
        from qgis.core import (QgsWkbTypes, QgsGeometry, QgsPointXY, QgsProject,
                               QgsVectorLayer, QgsField, QgsFeature,
                               QgsPalLayerSettings, QgsTextFormat,
                               QgsVectorLayerSimpleLabeling)
        canvas = self.iface.mapCanvas()
        self._pon_anim_cleanup()
        pon_field = self._pon_renumber_fields()[0]
        zpoly = self._pon_zone_polys(pon_field)
        # ── Build the WALK: flow along the feeder, then DIVE each zone's real
        # distribution cable into the blob, number it, climb back — feeder order. ──
        geoms, _cf, _cv = self._feeder_trunk_geoms(feeder_layer)
        fg = geoms[0] if geoms else None
        for g in (geoms[1:] if geoms else []):
            fg = fg.combine(g)
        try:
            mm = fg.mergeLines() if fg else None
            if mm and not mm.isEmpty():
                fg = mm
        except Exception:
            _swallowed_note()
        zone_dc = self._pon_zone_distribution(zpoly, fg) if fg else {}
        total = (fg.length() if fg else 0) or 1.0
        # Resolve the start position s0 + walk direction along the feeder, exactly like
        # the renumber order — so the walk is FORWARD from the start (rel distance),
        # never the raw geometry distance that wraps and runs to the end + back.
        s0, forward = 0.0, True
        try:
            mode, start_pt = (start_spec if isinstance(start_spec, (tuple, list))
                              else ("endA", None))
            if mode == "endB":
                s0, forward = total, False
            elif mode == "point" and start_pt is not None:
                from qgis.core import QgsCoordinateTransform
                p = QgsPointXY(start_pt)
                src = QgsProject.instance().crs()
                dst = feeder_layer.crs()
                if src.isValid() and dst.isValid() and src != dst:
                    p = QgsCoordinateTransform(src, dst, QgsProject.instance()).transform(p)
                s0 = fg.lineLocatePoint(QgsGeometry.fromPointXY(p)) if fg else 0.0
        except Exception:
            s0, forward = 0.0, True

        def _feeder_at(rel):
            dd = ((s0 + rel) if forward else (s0 - rel)) % total
            return QgsPointXY(fg.interpolate(dd).asPoint())

        WP = []   # (QgsPointXY, kind, new_pon, old)  kind ∈ feeder|dive|arrive
        prev_rel = 0.0   # start AT the start point and only ever move forward
        for old, new_pon, _z in mapping:
            cent = rep.get(str(old))
            if cent is None:
                continue
            try:
                d = fg.lineLocatePoint(QgsGeometry.fromPointXY(QgsPointXY(cent))) if fg else 0.0
            except Exception:
                d = 0.0
            rel = ((d - s0) if forward else (s0 - d)) % total   # forward dist from start
            # flow forward along the feeder from the previous zone's branch to this one
            seg = rel - prev_rel
            if seg < 0:          # safety: never walk backwards
                seg = 0
            nstep = max(1, int(seg / (total / 80.0)))
            for s in range(1, nstep + 1):
                try:
                    WP.append((_feeder_at(prev_rel + seg * s / nstep), "feeder", None, None))
                except Exception:
                    _swallowed_note()
            try:
                branch = _feeder_at(rel)
            except Exception:
                branch = QgsPointXY(cent)
            WP.append((branch, "feeder", None, None))
            # dive along the zone's real distribution cable (down-sampled for speed)
            dive = zone_dc.get(str(old)) or [QgsPointXY(cent)]
            if len(dive) > 6:
                stepf = len(dive) / 6.0
                dive = [dive[int(j * stepf)] for j in range(6)] + [dive[-1]]
            for p in dive:
                WP.append((QgsPointXY(p), "dive", None, None))
            WP.append((QgsPointXY(dive[-1]), "arrive", new_pon, str(old)))
            for p in reversed(dive[:-1]):
                WP.append((QgsPointXY(p), "dive", None, None))
            WP.append((branch, "feeder", None, None))
            prev_rel = rel

        feeder_trail = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.LineGeometry)
        feeder_trail.setColor(QColor(90, 200, 255))   # cyan: the feeder route, persisted
        feeder_trail.setWidth(3)
        dive_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.LineGeometry)
        dive_band.setColor(QColor(255, 255, 255))     # white: the CURRENT dive, transient
        dive_band.setWidth(2)
        walker = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PointGeometry)
        walker.setColor(QColor(255, 80, 0))
        try:
            walker.setIconSize(22)
            walker.setIcon(QgsRubberBand.ICON_CIRCLE)
        except Exception:
            _swallowed_note()
        crs = feeder_layer.crs().authid()
        flow = QgsVectorLayer(f"Point?crs={crs}", f"Renumber Flow ({term} order)", "memory")
        # claude:intent MUTATE — user asked to "watch it go ... flow on the feeder line and
        # go into the distribution". Plan: in-MEMORY display-only point layer that fills
        # with the new numbers as the walk arrives at each zone. No source data touched.
        flow.dataProvider().addAttributes([QgsField("n", QMetaType.Type.Int)])
        flow.updateFields()
        ls = QgsPalLayerSettings()
        ls.fieldName = "n"
        ls.enabled = True
        tf = QgsTextFormat()
        tf.setSize(13)
        tf.setColor(QColor(255, 255, 0))
        ls.setFormat(tf)
        flow.setLabeling(QgsVectorLayerSimpleLabeling(ls))
        flow.setLabelsEnabled(True)
        for lyr in list(QgsProject.instance().mapLayers().values()):
            if isinstance(lyr, QgsVectorLayer) and lyr.name().startswith("Renumber Flow"):
                QgsProject.instance().removeMapLayer(lyr.id())
        QgsProject.instance().addMapLayer(flow)

        # Slow + deliberate so the order can be double-checked: ~4 fps base glide, with a
        # PAUSE at each zone arrival so you can read every number as it drops.
        GLIDE = getattr(self, "_pon_anim_glide", 6)
        ARRIVE_PAUSE = 9   # frames the walker holds on each zone after numbering it
        timer = QTimer(self)   # parent to the DOCK so it dies on reload (no orphans)
        timer.setInterval(getattr(self, "_pon_anim_interval", 38))
        self._pon_anim = {"path": feeder_trail, "dive": dive_band, "walker": walker,
                          "flow": flow, "timer": timer, "zpoly": zpoly, "wp": WP,
                          "i": 0, "t": 0.0, "prev": None, "pause": 0}

        def _finish(a):
            a["timer"].stop()
            try:
                a["walker"].reset()
                a["dive"].reset()
            except Exception:
                pass
            if on_done:
                on_done()

        def _step():
            try:
                _step_inner()
            except Exception:
                # Never let the timer spam the Python-error banner — log once + stop.
                try:
                    import traceback
                    with open("C:/Temp/renumber_anim_err.log", "w", encoding="utf-8") as fh:
                        fh.write(traceback.format_exc())
                except Exception:
                    _swallowed_note()
                a = getattr(self, "_pon_anim", None)
                if a and a.get("timer"):
                    a["timer"].stop()
                self._pon_anim = None

        def _step_inner():
            a = self._pon_anim
            if not a:
                return
            WPl = a["wp"]
            if not WPl or a["i"] >= len(WPl):
                _finish(a)
                return
            if a["prev"] is None:
                a["prev"] = WPl[0][0]
                a["path"].addPoint(WPl[0][0])
                a["i"] = 1
                return
            # hold on the current zone so each number is readable
            if a["pause"] > 0:
                a["pause"] -= 1
                return
            i = a["i"]
            prev = a["prev"]
            target, kind, new_pon, old = WPl[i]
            a["t"] += 1.0 / GLIDE
            if a["t"] >= 1.0:
                wpos = target
                if kind == "feeder":
                    a["path"].addPoint(target)   # persist ONLY the feeder route (clean)
                    a["dive"].reset()            # clear the dive line back on the feeder
                elif kind == "dive":
                    a["dive"].addPoint(target)   # draw the current dive into the zone
                elif kind == "arrive":
                    a["dive"].addPoint(target)
                    fg_flash = a["zpoly"].get(old) or QgsGeometry.fromPointXY(target)
                    try:
                        canvas.flashGeometries([fg_flash], feeder_layer.crs())
                    except Exception:
                        _swallowed_note()
                    f = QgsFeature(a["flow"].fields())
                    f.setAttribute("n", new_pon)
                    f.setGeometry(QgsGeometry.fromPointXY(target))
                    a["flow"].dataProvider().addFeature(f)
                    a["flow"].triggerRepaint()
                    a["pause"] = ARRIVE_PAUSE   # hold so you can read the number
                a["prev"] = target
                a["i"] = i + 1
                a["t"] = 0.0
            else:
                k = a["t"]
                wpos = QgsPointXY(prev.x() + (target.x() - prev.x()) * k,
                                  prev.y() + (target.y() - prev.y()) * k)
            try:
                a["walker"].reset(QgsWkbTypes.GeometryType.PointGeometry)
                a["walker"].addPoint(wpos)
            except Exception:
                _swallowed_note()

        timer.timeout.connect(_step)
        timer.start()

    def _pon_renumber_collect(self, feeder_layer, start_spec, first_pon):
        """Compute the feeder-route order. start_spec = ('endA'|'endB'|'point', pt).
        Returns (mapping, rep_points, traced_ok).
        mapping = [(old_pon, new_pon, new_zone)] sorted by feeder distance then spur.
        traced_ok = False when the feeder couldn't be traced into a coherent route
        (disconnected segments / degenerate geom) → caller must NOT allow Apply.
        Pure read — no writes."""
        from qgis.core import QgsProject, QgsVectorLayer, QgsGeometry, QgsPointXY
        # Follow ONLY the highest-capacity line (the 144F trunk), not every capacity
        # class mixed together — mixing 144F/48F/24F gives "too many segments" and the
        # route can't be traced (JJ 2026-06-24). _feeder_trunk_geoms picks the top one.
        geoms, _capfield, cap_used = self._feeder_trunk_geoms(feeder_layer)
        if not geoms:
            return [], {}, False, None, {"reason": "no feeder geometry"}
        n_seg = len(geoms)
        feeder_geom = geoms[0]
        for g in geoms[1:]:
            feeder_geom = feeder_geom.combine(g)
        # Stitch connected segments into a proper route so lineLocatePoint measures
        # real along-feeder distance (combine() alone leaves an unordered multipart).
        try:
            merged = feeder_geom.mergeLines()
            if merged and not merged.isEmpty():
                feeder_geom = merged
        except Exception:
            pass
        total_len = feeder_geom.length() or 1.0
        # Resolve the start position (s0) along the feeder + the walk direction.
        # endA = route start, forward; endB = route end, walk backward; point =
        # the clicked location snapped onto the feeder, walk forward from there.
        mode, start_pt = (start_spec if isinstance(start_spec, (tuple, list))
                          else ("endA", None))
        forward = True
        s0 = 0.0
        if mode == "endB":
            s0, forward = total_len, False
        elif mode == "point" and start_pt is not None:
            try:
                from qgis.core import QgsCoordinateTransform
                p = QgsPointXY(start_pt)
                src = QgsProject.instance().crs()
                dst = feeder_layer.crs()
                if src.isValid() and dst.isValid() and src != dst:
                    p = QgsCoordinateTransform(src, dst, QgsProject.instance()).transform(p)
                s0 = feeder_geom.lineLocatePoint(QgsGeometry.fromPointXY(p))
            except Exception:
                s0 = 0.0
            forward = True
        # The PON identifier for THIS project: pon_no on a finished HLD; else zone_id —
        # here a "zone" polygon IS a PON (JJ #107). group_id = splitters, NEVER the PON.
        pon_field, zone_field, zone_name_field, is_real = self._pon_renumber_fields()
        if not pon_field:
            return [], {}, False, cap_used, {"reason": "no pon_no/zone field found"}
        pkey = pon_field.lower()
        rep = {}
        cand = []
        for lyr in QgsProject.instance().mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
                continue
            fn = {f.name().lower(): f.name() for f in lyr.fields()}
            if pkey not in fn:
                continue
            gt = lyr.geometryType()
            if gt not in (0, 2):   # point or polygon — one representative point per PON
                continue
            nl = lyr.name().lower()
            score = (4 if (gt == 2 and ("zone" in nl or "pon" in nl)) else  # PON polygon
                     3 if gt == 2 else
                     2 if "splitter" in nl else
                     1 if ("pon" in nl or "zone" in nl) else 0)
            cand.append((score, lyr, fn[pkey]))
        cand.sort(key=lambda t: t[0], reverse=True)
        for _score, lyr, pf in cand:
            for feat in lyr.getFeatures():
                try:
                    pon = feat[pf]
                except Exception:
                    pon = None
                if pon in (None, "") or str(pon).upper() == "NULL":
                    continue
                key = str(pon)
                if key in rep:
                    continue
                g = feat.geometry()
                if not g or g.isEmpty():
                    continue
                rep[key] = g.asPoint() if g.type() == 0 else g.centroid().asPoint()
            if rep:
                break
        order = []
        for pon, pt in rep.items():
            pg = QgsGeometry.fromPointXY(QgsPointXY(pt))
            try:
                d_along = feeder_geom.lineLocatePoint(pg)
            except Exception:
                d_along = 0.0
            spur = feeder_geom.distance(pg)
            # distance walked FROM the start, wrapping around the route so a start
            # placed mid-feeder numbers outward from there, then wraps to the rest.
            rel = ((d_along - s0) if forward else (s0 - d_along)) % total_len
            order.append((rel, spur, pon))
        order.sort(key=lambda t: (t[0], t[1]))
        # traced_ok: the route must spread the PONs along it. A degenerate combine of
        # disconnected segments (or a feeder the PONs don't run along) collapses every
        # distance to ~one position → refuse. Lenient (≥10%, min 3 distinct) so a real
        # feeder where PONs cluster at junctions is NOT false-refused.
        distinct = len({round(o[0], 6) for o in order})
        traced_ok = (total_len > 1e-9 and len(order) > 1
                     and distinct >= max(3, len(order) // 10))
        mapping = []
        for i, (_d, _s, pon) in enumerate(order):
            new_pon = first_pon + i
            # Derive a SEPARATE zone only when pon_no is the real id (zone is its parent).
            # When the PON *is* the zone (Matiko), there is no separate zone to derive.
            new_zone = ((new_pon - first_pon) // 16 + 17) if is_real else None
            mapping.append((pon, new_pon, new_zone))
        diag = {"pons": len(order), "segments": n_seg, "route_len": total_len,
                "distinct": distinct, "cap": cap_used,
                "pon_field": pon_field, "zone_field": zone_field,
                "zone_name_field": zone_name_field, "is_real": is_real,
                "reason": ("ok" if traced_ok else
                           ("no PONs found" if not order else
                            "feeder doesn't spread the PONs (segments/CRS?)"))}
        return mapping, rep, traced_ok, cap_used, diag

    def _pon_autowalk_order(self, zlyr, zfield, start=None):
        """READ-ONLY: compute the PON order by walking the cable hierarchy
        (144F -> 24F/48F link -> distribution dip -> zone). Returns
        (order_list, walk_pts_wgs84, pen_flags, message). `start` (optional
        [lon,lat] in WGS84) overrides the POP as the walk start point. Never
        raises out. The validated engine lives in network_planner/feeder_walk.py."""
        from qgis.core import (QgsProject, QgsVectorLayer, QgsGeometry,
                               QgsCoordinateReferenceSystem, QgsCoordinateTransform)
        try:
            from . import feeder_walk
        except Exception:
            try:
                import feeder_walk
            except Exception as e:
                return [], [], [], f"feeder_walk engine not found: {e}"
        try:
            proj = QgsProject.instance()
            wgs = QgsCoordinateReferenceSystem("EPSG:4326")

            def to_wgs(geom, src):
                if geom is None or geom.isEmpty():
                    return geom
                if src.isValid() and src != wgs:
                    g = QgsGeometry(geom)
                    g.transform(QgsCoordinateTransform(src, wgs, proj))
                    return g
                return geom

            def parts_line(lyr):
                out = []
                for ft in lyr.getFeatures():
                    g = to_wgs(ft.geometry(), lyr.crs())
                    if not g or g.isEmpty():
                        continue
                    ps = g.asMultiPolyline() if g.isMultipart() else (
                        [g.asPolyline()] if g.asPolyline() else [])
                    for part in ps:
                        if part:
                            out.append([[p.x(), p.y()] for p in part])
                return out

            feeder_lyr = dist_lyr = pop_lyr = None
            for l in proj.mapLayers().values():
                if not isinstance(l, QgsVectorLayer) or not l.isValid():
                    continue
                nm = l.name().lower()
                if l.geometryType() == 1 and "feeder" in nm and feeder_lyr is None:
                    feeder_lyr = l
                if l.geometryType() == 1 and "distribution" in nm and dist_lyr is None:
                    dist_lyr = l
                if l.geometryType() == 0 and "pop" in nm and pop_lyr is None:
                    pop_lyr = l
            if feeder_lyr is None:
                return [], [], [], ("No Feeder cable layer found (need a line layer "
                                    "named '…Feeder…').")
            sf = {f.name().lower(): f.name() for f in feeder_lyr.fields()}.get("size")
            feeder = []
            for ft in feeder_lyr.getFeatures():
                g = to_wgs(ft.geometry(), feeder_lyr.crs())
                if not g or g.isEmpty():
                    continue
                m = re.search(r"\d+", str(ft[sf]) if sf else "")
                sz = int(m.group()) if m else 0
                ps = g.asMultiPolyline() if g.isMultipart() else (
                    [g.asPolyline()] if g.asPolyline() else [])
                for part in ps:
                    if part:
                        feeder.append({'pts': [[p.x(), p.y()] for p in part], 'size': sz})
            dist = parts_line(dist_lyr) if dist_lyr else []
            zones = []
            for ft in zlyr.getFeatures():
                g = to_wgs(ft.geometry(), zlyr.crs())
                if not g or g.isEmpty():
                    continue
                rings = []
                if g.isMultipart():
                    for poly in g.asMultiPolygon():
                        if poly:
                            rings.append([[p.x(), p.y()] for p in poly[0]])
                else:
                    poly = g.asPolygon()
                    if poly:
                        rings.append([[p.x(), p.y()] for p in poly[0]])
                c = g.centroid().asPoint()
                zones.append({'id': str(ft[zfield]), 'rings': rings,
                              'c': [c.x(), c.y()]})
            pop = None
            if pop_lyr:
                for ft in pop_lyr.getFeatures():
                    g = to_wgs(ft.geometry(), pop_lyr.crs())
                    if g and not g.isEmpty():
                        pt = g.asPoint()
                        pop = [pt.x(), pt.y()]
                        break
            if start is not None and len(start) >= 2:
                pop = [float(start[0]), float(start[1])]
            elif pop is None and feeder:
                pop = feeder[0]['pts'][0]
            res = feeder_walk.compute(feeder, dist, zones, pop)
            order = res.get('order', [])
            walk = res.get('walk', [])
            pen = res.get('pen', [])
            if not order:
                return [], [], [], ("Auto-walk produced no order — check the Feeder has "
                                    "a Size field (144/48/24) and the cables connect.")
            where = "your chosen start point" if start is not None else "the POP"
            return order, walk, pen, (
                f"Auto-walk ordered {len(order)} of {len(zones)} zones, walking the feeder "
                f"hierarchy from {where}. Review, then Finalize.")
        except Exception as e:
            return [], [], [], f"Auto-walk failed: {e}"

    def _pon_draw_renumber_path(self, feeder_layer):
        """Draw a 'PON Renumber Path' layer = a copy of the feeder (+distribution)
        cable geometry, so it FOLLOWS the cables exactly (no diagonal short-cuts)."""
        from qgis.core import QgsProject, QgsVectorLayer, QgsFeature
        try:
            crs = feeder_layer.crs().authid()
            for l in list(QgsProject.instance().mapLayers().values()):
                if isinstance(l, QgsVectorLayer) and l.name() == "PON Renumber Path":
                    QgsProject.instance().removeMapLayer(l.id())
            path = QgsVectorLayer(f"LineString?crs={crs}", "PON Renumber Path", "memory")
            feats = []
            # ONLY the feeder trunk (highest-capacity line) — the clean route the walk
            # follows. NOT the distribution cables (those radiate from the POP and make
            # a scrambled spiderweb). JJ #107.
            trunk_geoms, _cf, _cv = self._feeder_trunk_geoms(feeder_layer)
            for g in trunk_geoms:
                nf = QgsFeature()
                nf.setGeometry(g)
                feats.append(nf)
            # claude:intent MUTATE — user asked: "make sure the line that follows the
            # feeder is also visually available in qgis" + "this is all scrambled".
            # Plan: write an in-MEMORY display-only line layer holding ONLY the feeder
            # trunk geometry (clean route reference). No project/source data touched.
            path.dataProvider().addFeatures(feats)
            path.updateExtents()
            try:
                path.renderer().symbol().setColor(QColor(34, 211, 238))
                path.renderer().symbol().setWidth(0.8)
            except Exception:
                _swallowed_note()
            QgsProject.instance().addMapLayer(path)
        except Exception:
            _swallowed_note()

    def _pon_label_layer(self):
        """(layer, label_field, prefix, pad) for a POLYGON layer whose label reads
        like '<prefix><number>' — e.g. Malmesbury 'Pons.Label.' = 'Malmesbury Pon 07'.
        This is how Renumber Zones works on projects that were NOT built by the
        Network Planner (no numeric pon_no/zone_id field — the PON lives in a text
        label).  None when there is no such label-based PON.  Prefers a layer named
        like a pon/zone."""
        from qgis.core import QgsProject, QgsVectorLayer
        numre = re.compile(r"(\d+)\s*$")
        best, best_score = None, 0
        for lyr in QgsProject.instance().mapLayers().values():
            if (not isinstance(lyr, QgsVectorLayer) or not lyr.isValid()
                    or lyr.geometryType() != 2):
                continue
            nl = lyr.name().lower()
            for f in lyr.fields():
                fn = f.name()
                prefixes, widths, hits, n = {}, {}, 0, 0
                for ft in lyr.getFeatures():
                    v = ft[fn]
                    if isinstance(v, str):
                        m = numre.search(v)
                        if m:
                            hits += 1
                            pre = v[:m.start(1)]
                            prefixes[pre] = prefixes.get(pre, 0) + 1
                            widths[len(m.group(1))] = widths.get(len(m.group(1)), 0) + 1
                    n += 1
                    if n >= 400:
                        break
                if hits < 2 or not prefixes:
                    continue
                prefix = max(prefixes, key=prefixes.get)
                if not prefix.strip():           # pure numbers — that's the numeric path
                    continue
                score = hits
                if "pon" in prefix.lower():
                    score += 1000
                if "pon" in nl or "zone" in nl:
                    score += 500
                if score > best_score:
                    pad = max(widths, key=widths.get)
                    best, best_score = (lyr, fn, prefix, pad), score
        return best

    # ------------------------------------------------------------------
    # Renumber backup — re-instated 2026-07-15 (JJ: "fix it")
    # ------------------------------------------------------------------
    # The auto-backup was removed 2026-07-03, which left _pon_restore_zone_backup()
    # reading a _renumber_backup/ folder that NOTHING wrote any more — a restore
    # button that could never restore, and a renumber that rewrote labels across
    # every layer with no way back. A renumber can undo days of work; the write is
    # now gated on a snapshot succeeding.
    def _pon_snapshot_to_gpkg(self, lyr, path, layer_name):
        """Copy `lyr` to a GPKG carrying an explicit `_vf_fid` = the LIVE feature id.

        Why not just write the layer straight out: GPKG assigns its own `fid`
        starting at 1, while a shapefile's feature ids start at 0. A restore that
        matched on the GPKG `fid` would therefore write every feature's attributes
        onto the NEXT feature — verified 2026-07-15 on `feeder`: 8/8 wrong, shifted
        by one. So the live id is stored as a real column and matched on explicitly.
        Returns (ok, msg).
        """
        # claude:intent MUTATE FiberNetworkAutomation/network_planner/dock_widget.py
        #   The addFeatures() below writes ONLY to a throwaway in-process `memory`
        #   layer used to stage the snapshot; the live layer is read-only here.
        #   This is the BACKUP path — it exists to protect data, not change it.
        #   approved-destructive
        from qgis.PyQt.QtCore import QMetaType
        from qgis.core import (QgsCoordinateTransformContext, QgsFeature,
                               QgsField, QgsVectorFileWriter, QgsVectorLayer,
                               QgsWkbTypes)
        crs = lyr.crs().authid() or lyr.crs().toWkt()
        gt = QgsWkbTypes.displayString(lyr.wkbType())
        mem = QgsVectorLayer(f"{gt}?crs={crs}", layer_name, "memory")
        if not mem.isValid():
            return False, f"could not build a snapshot layer ({gt} / {crs})"
        mdp = mem.dataProvider()
        src_fields = list(lyr.fields())
        if not mdp.addAttributes(
                src_fields + [QgsField("_vf_fid", QMetaType.Type.LongLong)]):
            return False, "could not add the snapshot fields"
        mem.updateFields()
        feats = []
        for f in lyr.getFeatures():
            nf = QgsFeature(mem.fields())
            nf.setAttributes(list(f.attributes()) + [int(f.id())])
            nf.setGeometry(f.geometry())
            feats.append(nf)
        if feats and not mdp.addFeatures(feats):
            return False, "could not fill the snapshot"
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = "GPKG"
        opts.layerName = layer_name
        try:
            res = QgsVectorFileWriter.writeAsVectorFormatV3(
                mem, path, QgsCoordinateTransformContext(), opts)
        except Exception as e:
            return False, str(e)
        if int(res[0]) != 0:                    # 0 == NoError (version-safe)
            return False, str(res[1] if len(res) > 1 else res[0])

        # PROVE the snapshot can be read back. A success code is NOT proof:
        # measured 2026-07-28, GDAL wrote a perfect 98 KB GeoPackage at a
        # 289-character path and reported NoError, yet nothing could ever reopen
        # it (GPKG is SQLite; sqlite3_open could not touch that path). A backup
        # that writes and cannot restore is worse than no backup, because every
        # gate we own passes it. So: reopen it, and count what came back.
        try:
            check = QgsVectorLayer(f"{path}|layername={layer_name}", "_v", "ogr")
            if not check.isValid():
                check = QgsVectorLayer(path, "_v", "ogr")
            if not check.isValid():
                return False, ("written but could not be reopened — the backup "
                               "would not be restorable, so it is being "
                               "rejected (path length is the usual cause: "
                               f"{len(path)} characters)")
            wrote, back = len(feats), check.featureCount()
            if back != wrote:
                return False, (f"written but reopened with {back} of {wrote} "
                               f"feature(s) — rejected as incomplete")
        except Exception as e:
            return False, f"written but the read-back check failed: {e}"
        return True, ""

    def _pon_write_renumber_backup(self, layers):
        """Snapshot every layer a renumber is about to touch → (ok, dest_or_msg).

        Writes _renumber_backup/<ts>/<safe>.gpkg + manifest.json — exactly the
        layout _pon_restore_zone_backup() reads. Callers MUST abort on ok=False:
        no backup, no write.
        """
        import os
        from datetime import datetime
        from qgis.core import QgsProject
        proj = QgsProject.instance()
        proj_path = proj.fileName() or ""
        proj_dir = os.path.dirname(proj_path)
        if not proj_dir or not os.path.isdir(proj_dir):
            return False, ("the project has not been saved to disk, so there is "
                           "nowhere to put the backup — save the project first")

        # Unique stems FIRST, then measure — a `_2` suffix can be the thing that
        # pushes a borderline path past MAX_PATH.
        pairs = _vf_safe_names([lyr.name() for lyr in layers])
        if not pairs:
            return False, "there was nothing to back up"
        stems = [s for s, _n in pairs]
        root, spilled, longest = vf_backup_root_for(proj_path,
                                                    [n for _s, n in pairs])
        if spilled:
            # Even the short root has to fit — a pathologically long layer name
            # can breach the limit anywhere. Refuse cleanly; never truncate.
            spill_longest = _vf_backup_longest_path(root, stems)
            if spill_longest > _BACKUP_PATH_BUDGET:
                return False, (
                    f"the layer names are too long to back up anywhere on this "
                    f"machine — even the short fallback folder needs "
                    f"{spill_longest} characters and Windows allows "
                    f"{_BACKUP_PATH_BUDGET}. Shorten the longest layer name.")

        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        dest = os.path.join(root, _BACKUP_DIRNAME, ts)
        try:
            self._vf_retry_io(lambda: os.makedirs(dest, exist_ok=True))
        except OSError as e:
            hint = ""
            if not spilled and longest > _BACKUP_PATH_BUDGET:
                hint = (f" — the path would be {longest} characters and Windows "
                        f"allows about 260")
            return False, f"could not create the backup folder{hint}: {e}"

        name_map = {}
        for (safe, _orig), lyr in zip(pairs, layers):
            ok, msg = self._pon_snapshot_to_gpkg(
                lyr, os.path.join(dest, safe + ".gpkg"), safe)
            if not ok:
                return False, f"backing up '{lyr.name()}' failed: {msg}"
            name_map[safe] = lyr.name()
        try:
            self._vf_retry_io(lambda: self._vf_write_manifest(
                os.path.join(dest, "manifest.json"),
                {"layers": name_map, "when": ts, "project": proj_path}))
        except OSError as e:
            return False, f"could not write the backup manifest: {e}"
        if spilled:
            self._vf_note_spill(dest, longest)
        return True, dest

    @staticmethod
    def _vf_write_manifest(path, payload):
        import json as _json
        with open(path, "w", encoding="utf-8") as fh:
            _json.dump(payload, fh, indent=1)

    @staticmethod
    def _vf_retry_io(fn, tries=4, delay=0.15):
        """Run a filesystem write, retrying a transient LOCK (not a real error).

        The project trees live in OneDrive/SharePoint, whose uploader takes brief
        exclusive handles — a sharing violation there means "try again in a
        moment", not "this cannot be written". Anything that is not a lock
        (a path too long, a missing folder, no permission) is raised at once, so
        a genuine failure is never masked by four seconds of retrying.
        """
        last = None
        for i in range(max(1, tries)):
            try:
                return fn()
            except PermissionError as e:      # WinError 32/33 — a lock
                last = e
            except OSError as e:
                if getattr(e, "winerror", None) not in (32, 33):
                    raise
                last = e
            if i + 1 < tries:
                time.sleep(delay * (i + 1))
        raise last

    def _vf_note_spill(self, dest, longest):
        """Tell the operator the backup went somewhere else, and why. Never raises."""
        try:
            # `longest` is the length of the PATH we would have written, not the
            # depth of the project folder — do not describe it as the latter.
            self.iface.messageBar().pushMessage(
                "Backup",
                f"The safety backup could not be written next to this project — "
                f"that path would be {longest} characters and Windows allows "
                f"about 260. It went to {dest} instead. Undo last Renumber will "
                f"still find it.",
                level=Qgis.MessageLevel.Info, duration=12)
        except Exception:
            pass

    def _pon_renumber_apply_label(self, order, base, layer, label_field,
                                  prefix, pad):
        """Renumber a LABEL-based PON ('Malmesbury Pon 07') in click order, AND
        cascade every OTHER layer that references the PON as an '_SP<n>' token
        (Feeder Joints, Dome Joints).  order = clicked label strings; new number =
        base + click-index.  Never raises out → (ok, message)."""
        from qgis.core import QgsProject, QgsVectorLayer
        try:
            numre = re.compile(r"(\d+)\s*$")
            sp_re = re.compile(r"SP(\d+)", re.I)
            proj = QgsProject.instance()
            idx = layer.fields().indexOf(label_field)
            if idx < 0:
                return False, "Label field not found."
            # remap {old_pon_num: new_pon_num} from the click order
            remap = {}
            old_label_to_new = {}
            for i, old_label in enumerate(order):
                m = numre.search(str(old_label))
                if not m:
                    continue
                old_num = int(m.group(1))
                new_num = base + i
                remap[old_num] = new_num
                old_label_to_new[str(old_label)] = prefix + str(new_num).zfill(pad)
            # every PON number in the project (to spot _SP-linked fields)
            all_pon = set()
            for f in layer.getFeatures():
                m = numre.search(str(f[label_field] or ""))
                if m:
                    all_pon.add(int(m.group(1)))

            def _remap_sp(text):
                def repl(mm):
                    old = int(mm.group(1))
                    if old in remap:
                        head = mm.group(0)[:len(mm.group(0)) - len(mm.group(1))]
                        return head + str(remap[old]).zfill(len(mm.group(1)))
                    return mm.group(0)
                return sp_re.sub(repl, text)

            # claude:intent MUTATE — user asked (verbatim): "make it so that the
            # network planners re-number ... work for anything" + "it should also
            # ... renumber [PON references in other layers] as well". Plan: rewrite
            # the PON label in click order, then remap the _SP<n> token in every
            # linked layer. Preview-first, and now BACKUP-GATED (2026-07-15).
            # claude:approved-destructive
            #
            # Computed in full BEFORE anything is written, so the backup can cover
            # every layer we are about to touch (the cascade discovers its targets)
            # and so a failure part-way cannot leave a half-renumbered project.
            # Output-neutral: each layer's changes depend only on `remap`, never on
            # another layer's write.

            # 1) work out the PON label changes
            changes = {}
            for f in layer.getFeatures():
                lab = f[label_field]
                if (isinstance(lab, str) and lab in old_label_to_new
                        and old_label_to_new[lab] != lab):
                    changes[f.id()] = {idx: old_label_to_new[lab]}

            # 2) work out the _SP<n> cascade for every OTHER layer whose SP tokens
            #    are PON-range
            pending = []                         # [(layer, field_name, lchg)]
            for lyr in proj.mapLayers().values():
                if (not isinstance(lyr, QgsVectorLayer) or not lyr.isValid()
                        or lyr.id() == layer.id()):
                    continue
                for fld in lyr.fields().names():
                    fidx = lyr.fields().indexOf(fld)
                    hits = inr = n = 0
                    for ft in lyr.getFeatures():
                        v = ft[fld]
                        if isinstance(v, str):
                            for mm in sp_re.finditer(v):
                                hits += 1
                                if int(mm.group(1)) in all_pon:
                                    inr += 1
                        n += 1
                        if n >= 300:
                            break
                    if hits < 3 or inr < hits * 0.5:
                        continue
                    lchg = {}
                    for ft in lyr.getFeatures():
                        old = ft[fld]
                        if isinstance(old, str):
                            new = _remap_sp(old)
                            if new != old:
                                lchg[ft.id()] = {fidx: new}
                    if lchg:
                        pending.append((lyr, fld, lchg))
                    break                       # one field per layer is enough

            # 3) BACKUP OR ABORT — everything we are about to touch
            touch = ([layer] if changes else []) + [l for l, _f, _c in pending]
            if touch:
                ok, dest = self._pon_write_renumber_backup(touch)
                if not ok:
                    return False, ("Nothing was renumbered — the backup failed, so "
                                   "the write was not attempted: %s" % dest)

            # 4) WRITE
            total = 0
            if changes:
                layer.dataProvider().changeAttributeValues(changes)
                layer.triggerRepaint()
                total = len(changes)
            casc, casc_layers = 0, []
            for lyr, fld, lchg in pending:
                lyr.dataProvider().changeAttributeValues(lchg)
                lyr.triggerRepaint()
                casc += len(lchg)
                casc_layers.append("%s.%s" % (lyr.name(), fld))
            try:
                self.iface.mapCanvas().refreshAllLayers()
            except Exception:
                _swallowed_note()
            msg = "Renumbered %d PON label(s)" % total
            if casc:
                msg += " + %d linked _SP label(s) (%s)" % (casc,
                                                           ", ".join(casc_layers))
            return True, msg + "."
        except Exception as e:
            return False, "Renumber failed: %s" % e

    def _pon_renumber_apply(self, mapping, pon_field, zone_field, zone_name_field, is_real):
        """Backup → renumber the PON id (pon_field = pon_no or zone_id) + its parent zone
        + the zone label across every layer that carries the PON id → (ok, message).
        mapping = {old_pon_str: (new_pon, new_zone_or_None)}. SANDBOX-guarded by the
        caller. Never raises out.

        The backup is a hard gate (re-instated 2026-07-15): if the snapshot cannot be
        written, nothing is renumbered. Undo it with `↩ Undo last Renumber`."""
        from qgis.core import (QgsProject, QgsVectorLayer)
        try:
            proj = QgsProject.instance()
            pkey = (pon_field or "").lower()
            zkey = (zone_field or "").lower()
            znkey = (zone_name_field or "").lower()
            if not pkey:
                return False, "No PON id field to renumber."
            # affected = every layer carrying the PON id (its zone + zone label ride along)
            affected = []
            for lyr in proj.mapLayers().values():
                if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
                    continue
                fn = {f.name().lower(): f.name() for f in lyr.fields()}
                if pkey in fn:
                    affected.append((lyr, fn))
            if not affected:
                return False, "No PON layers found to renumber."
            # BACKUP OR ABORT (re-instated 2026-07-15). A renumber rewrites labels
            # across every layer carrying the PON — days of work ride on it.
            ok, dest = self._pon_write_renumber_backup([l for l, _fn in affected])
            if not ok:
                return False, (f"Nothing was renumbered — the backup failed, so the "
                               f"write was not attempted: {dest}")
            # WRITE per layer (bulk, type-preserving). Remap keyed on the PON id.
            def _typed(layer, idx, val):
                tn = layer.fields()[idx].typeName().lower()
                return str(val) if tn in ("string", "text") else val
            total = 0
            for lyr, fn in affected:
                flds = lyr.fields()
                p_idx = flds.indexOf(fn[pkey])
                z_idx = flds.indexOf(fn[zkey]) if (zkey and zkey in fn) else -1
                zn_idx = flds.indexOf(fn[znkey]) if (znkey and znkey in fn) else -1
                changes = {}
                for feat in lyr.getFeatures():
                    try:
                        cur = feat[flds[p_idx].name()]
                    except Exception:
                        _swallowed_note(); continue
                    if cur in (None, ""):
                        continue
                    m = mapping.get(str(cur))
                    if not m:
                        continue
                    new_pon, new_zone = m
                    # label number follows the zone (which equals the pon when pon IS zone)
                    label_num = new_zone if (is_real and new_zone is not None) else new_pon
                    fld = {p_idx: _typed(lyr, p_idx, new_pon)}
                    if z_idx >= 0:
                        zval = new_zone if (is_real and new_zone is not None) else new_pon
                        fld[z_idx] = _typed(lyr, z_idx, zval)
                    if zn_idx >= 0:
                        cur_zn = feat[flds[zn_idx].name()]
                        if cur_zn not in (None, "") and re.search(r"\d", str(cur_zn)):
                            fld[zn_idx] = re.sub(r"\d+", str(label_num), str(cur_zn), count=1)
                        else:
                            fld[zn_idx] = vf_pon_name(label_num)
                    changes[feat.id()] = fld
                if changes:
                    # claude:intent MUTATE — user asked to renumber PONs/zones in feeder
                    # order (and, 2026-07-03, to drop the forced auto-backup + sandbox
                    # limit so it runs on any project). Plan: remap the PON id (pon_no or
                    # zone_id) + parent zone + zone label in feeder order; preview-gated;
                    # bulk changeAttributeValues. Backup is now the user's 💾 button.
                    lyr.dataProvider().changeAttributeValues(changes)
                    lyr.triggerRepaint()
                    total += len(changes)
            try:
                self.iface.mapCanvas().refreshAllLayers()
            except Exception:
                _swallowed_note()
            return True, (f"Renumbered {total} feature(s) across {len(affected)} layer(s) "
                          f"by feeder route.")
        except Exception as e:
            return False, (f"Renumber failed: {e}")

    def _pon_restore_zone_backup(self):
        """Full UNDO: roll every layer back to the MOST RECENT renumber backup.
        Matches by fid so every attribute reverts exactly. Sandbox-guarded, confirms
        first, never raises out. This is the safety net JJ asked for — if a renumber
        ever breaks real work, one click gets it back."""
        import os, json as _json
        from qgis.PyQt.QtWidgets import QMessageBox
        from qgis.core import QgsProject, QgsVectorLayer
        try:
            if not self._pon_project_is_sandbox():
                QMessageBox.warning(self, "Restore",
                                    "Restore only runs on a SANDBOX/test project.")
                return
            proj = QgsProject.instance()
            proj_path = proj.fileName() or ""
            proj_dir = os.path.dirname(proj_path) or os.path.expanduser("~")
            # Look in BOTH places: beside the project (where it goes normally)
            # and the short spill root used when the project folder is too deep
            # for Windows. The newest timestamp across both wins, so the most
            # recent backup is always the one offered.
            roots = [proj_dir]
            spill = vf_spill_root(proj_path)
            if os.path.normcase(spill) != os.path.normcase(proj_dir):
                roots.append(spill)
            found = []                             # (ts, prefer_in_project, folder)
            for rank, base in enumerate(roots):
                root = os.path.join(base, _BACKUP_DIRNAME)
                if not os.path.isdir(root):
                    continue
                try:
                    kids = os.listdir(root)
                except OSError:
                    continue
                for d in kids:
                    full = os.path.join(root, d)
                    if os.path.isdir(full):
                        # rank keeps the ordering deterministic when the same
                        # timestamp exists in both roots — the project's own
                        # folder wins rather than whichever listdir returned first.
                        found.append((d, -rank, full))
            if not found:
                QMessageBox.information(self, "Restore", "No renumber backups found yet.")
                return
            found.sort(key=lambda t: (t[0], t[1]), reverse=True)
            stamp, _rank, latest = found[0]
            name_map, m_project = {}, None
            mpath = os.path.join(latest, "manifest.json")
            if os.path.exists(mpath):
                try:
                    _man = _json.load(open(mpath, encoding="utf-8"))
                    name_map = _man.get("layers", {})
                    m_project = _man.get("project")
                except Exception:
                    name_map = {}
            gpkgs = [f for f in os.listdir(latest) if f.lower().endswith(".gpkg")]
            if not gpkgs:
                QMessageBox.information(self, "Restore", "Backup folder has no layers.")
                return
            # A backup carries the project it was taken from. If that is not THIS
            # project, refuse by default — a copied _renumber_backup folder, a
            # renamed project or a moved file would otherwise write one project's
            # attributes onto another's features, silently.
            if m_project and proj_path and \
                    os.path.normcase(os.path.abspath(m_project)) != \
                    os.path.normcase(os.path.abspath(proj_path)):
                if QMessageBox.warning(
                        self, "Restore — wrong project?",
                        f"This backup was taken from a DIFFERENT project:\n\n"
                        f"{m_project}\n\nYou currently have open:\n\n{proj_path}\n\n"
                        f"Restoring it would write that project's attributes onto "
                        f"this one's features. Only continue if you know the "
                        f"project was moved or renamed.",
                        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                        QMessageBox.StandardButton.No
                        ) != QMessageBox.StandardButton.Yes:
                    return
            if QMessageBox.question(
                    self, "Restore last renumber?",
                    f"Roll every layer back to the backup from {stamp} "
                    f"({len(gpkgs)} layer(s))?\n\nThis reverts the attribute tables to "
                    f"exactly before the last renumber.\n\nFrom: {latest}",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                    ) != QMessageBox.StandardButton.Yes:
                return
            live_by_name = {l.name(): l for l in proj.mapLayers().values()
                            if isinstance(l, QgsVectorLayer) and l.isValid()}
            total, done, skipped, moved = 0, 0, [], []
            for gp in gpkgs:
                safe = gp[:-5]
                lname = name_map.get(safe)
                live = live_by_name.get(lname) if lname else None
                if live is None:
                    for nm, l in live_by_name.items():
                        if "".join(c if c.isalnum() else "_" for c in nm) == safe:
                            live = l
                            break
                if live is None:
                    continue
                blyr = QgsVectorLayer(os.path.join(latest, gp), "_b", "ogr")
                if not blyr.isValid():
                    continue
                # Match on the explicit _vf_fid column written by
                # _pon_snapshot_to_gpkg — NOT on the GPKG's own `fid`. GPKG numbers
                # its fid from 1 while a shapefile's ids start at 0, so matching on
                # `fid` restores every feature's attributes onto the NEXT feature
                # (verified 2026-07-15 on `feeder`: 8/8 wrong). A backup that
                # silently corrupts on restore is worse than no backup at all.
                #
                # And the stored fid is only trusted where GEOMETRY agrees with it
                # — see vf_pair_backup_rows for why (shapefile ids move on delete).
                bnames = [f.name() for f in blyr.fields()]
                fidname = next((n for n in bnames if n.lower() == "_vf_fid"), None)
                if fidname is None:
                    skipped.append(f"{live.name()} (backup predates the "
                                   f"_vf_fid fix — cannot be matched safely)")
                    continue
                drop = {"_vf_fid", "fid"}
                backup_rows = []
                for bf in blyr.getFeatures():
                    backup_rows.append((
                        bf[fidname],
                        _vf_geom_key(bf.geometry()),
                        {n: bf[n] for n in bnames if n.lower() not in drop}))
                live_rows = [(lf.id(), _vf_geom_key(lf.geometry()))
                             for lf in live.getFeatures()]
                paired, mstats = vf_pair_backup_rows(backup_rows, live_rows)
                if mstats["geometry"]:
                    moved.append(f"{live.name()}: {mstats['geometry']} row(s) "
                                 f"re-matched by geometry (the feature ids had "
                                 f"shifted since the backup)")
                if mstats["ambiguous"] or mstats["missing"]:
                    skipped.append(
                        f"{live.name()}: {mstats['ambiguous'] + mstats['missing']} "
                        f"feature(s) left untouched — not identifiable in the "
                        f"backup ({mstats['missing']} absent, "
                        f"{mstats['ambiguous']} with duplicate geometry). Their "
                        f"attributes were NOT guessed at.")
                lfields = live.fields()
                lidx = {lfields.at(i).name(): i for i in range(lfields.count())}
                changes = {}
                for lfid, src in paired.items():
                    fld = {lidx[n]: v for n, v in src.items() if n in lidx}
                    if fld:
                        changes[lfid] = fld
                if changes:
                    # claude:intent MUTATE — user asked: "make sure the backups can be
                    # gotten back ... if we break someone's work that's days of redoing".
                    # Plan: write the backed-up attribute values back onto the live layer,
                    # matched by fid (full undo). Sandbox-guarded + confirmed above.
                    # claude:approved-destructive
                    live.dataProvider().changeAttributeValues(changes)
                    live.triggerRepaint()
                    total += len(changes)
                    done += 1
            try:
                self.iface.mapCanvas().refreshAllLayers()
            except Exception:
                _swallowed_note()
            note = ""
            if moved:
                note += "\n\nRE-MATCHED BY GEOMETRY (these restored correctly):\n  • " \
                        + "\n  • ".join(moved)
            if skipped:
                note += "\n\nSKIPPED (nothing was changed on these):\n  • " + \
                        "\n  • ".join(skipped)
            QMessageBox.information(
                self, "Restore done",
                f"Restored {total} feature(s) across {done} layer(s) from:\n"
                f"{latest}{note}")
        except Exception as e:
            QMessageBox.warning(self, "Restore failed",
                                f"Could not restore: {e}\n\nThe backup files are safe in "
                                f"the _renumber_backup folder.")

    # ------------------------------------------------------------------
    # PON Renumber (BETA, locked) — intentionally inert: no data path.
    # ------------------------------------------------------------------
    def _on_pon_renumber_locked(self):
        """BETA placeholder. Renumber-by-feeder-route is still in development and is
        HARD-LOCKED: it reads nothing, writes nothing, and cannot lose data. It only
        tells the operator the feature is not ready. JJ unlocks it once it's final."""
        from qgis.PyQt.QtWidgets import QMessageBox
        QMessageBox.information(
            self, "Renumber PONs — BETA (locked)",
            "🔢 Renumber PONs is still being built and is locked.\n\n"
            "• You CAN use 🎯 PON per PON Manual to generate PONs now.\n"
            "• Renumbering is NOT enabled yet — it will not run, so it cannot change "
            "or lose any data.\n\n"
            "⚠ When it is unlocked it must only ever be tested on a sandbox/copy, "
            "never on permanent/production data.")

    # PON per PON Manual
    # ------------------------------------------------------------------
    def on_pon_per_pon_clicked(self):
        """Toggle PON-per-PON selection mode.

        First click  → prompt user to select features on map, then run pipeline.
        Second click → cancel / exit selection mode.
        """
        if not self._btn_pon_per_pon.isChecked():
            # Button was unchecked — cancel any pending selection mode
            self._pon_per_pon_cancel()
            return
        self._pon_per_pon_start()

    def _pon_per_pon_cancel(self):
        """Exit PON-per-PON mode without running the pipeline."""
        canvas = self.iface.mapCanvas()
        if hasattr(self, '_pon_select_tool') and self._pon_select_tool:
            if hasattr(self, '_prev_map_tool') and self._prev_map_tool:
                canvas.setMapTool(self._prev_map_tool)
            self._pon_select_tool = None
        self.iface.messageBar().clearWidgets()
        self._btn_pon_per_pon.setChecked(False)
        self._btn_pon_per_pon.setText(getattr(self, "_PON_PER_PON_LABEL", "🎯 PON per PON Manual  ·BETA"))
        self._pon_per_pon_active = False
        # Signal that the NEXT PON-per-PON run should start a fresh session.
        # We deliberately do NOT null the accumulator refs here so that Manual
        # Override can continue editing the existing layers after this button is
        # closed.  The accumulators will be nulled at the start of the next run.
        self._pon_new_session_needed = True
        # NOTE: _pon_batch_count / _pon_zone_offset / _pon_group_offset are
        # intentionally NOT reset here — they will be reset in _pon_per_pon_run
        # when _pon_new_session_needed is True.


    def _pon_per_pon_start(self):
        """Install the rubber-band polygon map tool for dual-layer PON selection."""
        from qgis.PyQt.QtWidgets import QMessageBox

        self._btn_pon_per_pon.setText("✏ Drawing selection — Right-click to finish")
        self._pon_per_pon_active = True

        demand_lyr = self.comboBox_erf.currentLayer()
        span_lyr = self.comboBox_span_layer.currentLayer()

        if not demand_lyr or not span_lyr:
            QMessageBox.warning(
                self, "PON per PON",
                "Please set the Demand Layer and Route Layer combos before using PON per PON Manual."
            )
            self._pon_per_pon_cancel()
            return

        canvas = self.iface.mapCanvas()

        # Store the previous map tool so we can restore it on cancel
        self._prev_map_tool = canvas.mapTool()

        tool = PonPolygonSelectTool(canvas, demand_lyr, span_lyr)
        tool.selection_complete.connect(self._pon_per_pon_polygon_done)
        tool.cancelled.connect(self._pon_per_pon_cancel)
        self._pon_select_tool = tool
        canvas.setMapTool(tool)

        # Show a non-modal floating hint
        self.iface.messageBar().pushMessage(
            "PON per PON",
            "Left-click to draw polygon vertices. Right-click to complete selection. Esc to cancel.",
            level=Qgis.MessageLevel.Info,   # Qgis.Info
            duration=0
        )

    def _pon_per_pon_polygon_done(self, demand_lyr, span_lyr):
        """Called when the rubber-band polygon is complete; restore map tool then review."""
        canvas = self.iface.mapCanvas()

        # Restore previous map tool
        if hasattr(self, '_prev_map_tool') and self._prev_map_tool:
            canvas.setMapTool(self._prev_map_tool)
        self._pon_select_tool = None

        # Clear message bar hint
        self.iface.messageBar().clearWidgets()

        self._btn_pon_per_pon.setText(getattr(self, "_PON_PER_PON_LABEL", "🎯 PON per PON Manual  ·BETA"))
        self._pon_per_pon_review(demand_lyr, span_lyr)

    def _pon_per_pon_review(self, demand_lyr, span_lyr):
        """Show count of selected features and ask user to confirm or reselect."""
        from qgis.PyQt.QtWidgets import QMessageBox, QDialog, QVBoxLayout, QLabel, QPushButton, QHBoxLayout
        from qgis.PyQt.QtCore import Qt

        n_demand = demand_lyr.selectedFeatureCount()
        n_span = span_lyr.selectedFeatureCount()

        if n_demand == 0 and n_span == 0:
            btn = QMessageBox.question(
                self, "PON per PON — No Selection",
                "No features are currently selected on either layer.\n\n"
                "Would you like to go back and select features?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if btn == QMessageBox.StandardButton.Yes:
                self._pon_per_pon_start()
            else:
                self._pon_per_pon_cancel()
            return

        # Build confirmation dialog
        dlg = QDialog(self)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        dlg.setWindowTitle("PON per PON — Confirm Selection")
        dlg.setMinimumWidth(380)
        lay = QVBoxLayout(dlg)
        lay.setSpacing(10)
        lay.setContentsMargins(16, 16, 16, 16)

        title_lbl = QLabel("<b>Selection Summary</b>")
        title_lbl.setStyleSheet(f'font-size:11px;color:{theme_safe.colors()["accent"]};')
        lay.addWidget(title_lbl)

        import math as _math
        n_groups = _math.ceil(n_demand / 8) if n_demand > 0 else 0

        summary = (
            f"<table cellspacing='6'>"
            f"<tr><td>🏠 Demand points selected:</td><td><b>{n_demand}</b></td></tr>"
            f"<tr><td>📡 Span features selected:</td><td><b>{n_span}</b></td></tr>"
            f"<tr><td>🔀 Splitter groups (est.):</td><td><b>{n_groups}</b></td></tr>"
            f"</table>"
        )
        if n_demand == 0:
            summary += "<br><span style='color:#c0392b;'>⚠ No demand points selected — pipeline will have nothing to group.</span>"
        elif n_demand < 4:
            summary += f"<br><span style='color:#d35400;'>⚠ Only {n_demand} demand point(s) selected — very small PON.</span>"
        else:
            pct = min(100, int(n_demand / 96 * 100))
            summary += f"<br><span style='color:#1e8449;'>✓ ~{pct}% of a full 96-unit PON capacity.</span>"

        sum_lbl = QLabel(summary)
        sum_lbl.setTextFormat(Qt.TextFormat.RichText)
        sum_lbl.setWordWrap(True)
        lay.addWidget(sum_lbl)

        btn_row = QHBoxLayout()
        btn_run = QPushButton("▶ Run AutoNet on Selection")
        btn_run.setStyleSheet(
            "QPushButton{background:#1a6b3c;color:white;font-weight:bold;"
            "border-radius:4px;padding:5px 12px;}"
            "QPushButton:hover{background:#238a4f;}"
        )
        btn_reselect = QPushButton("↩ Reselect")
        btn_reselect.setStyleSheet(
            "QPushButton{background:#7d4e00;color:white;font-weight:bold;"
            "border-radius:4px;padding:5px 12px;}"
            "QPushButton:hover{background:#a06300;}"
        )
        btn_cancel = QPushButton("✕ Cancel")
        btn_cancel.setStyleSheet(
            "QPushButton{background:#922b21;color:white;font-weight:bold;"
            "border-radius:4px;padding:5px 12px;}"
            "QPushButton:hover{background:#b03a2e;}"
        )
        btn_row.addWidget(btn_run)
        btn_row.addWidget(btn_reselect)
        btn_row.addWidget(btn_cancel)
        lay.addLayout(btn_row)

        dlg._choice = 'cancel'
        btn_run.clicked.connect(lambda: (setattr(dlg, '_choice', 'run'), dlg.accept()))
        btn_reselect.clicked.connect(lambda: (setattr(dlg, '_choice', 'reselect'), dlg.accept()))
        btn_cancel.clicked.connect(lambda: (setattr(dlg, '_choice', 'cancel'), dlg.accept()))

        dlg.exec()

        if dlg._choice == 'reselect':
            self._pon_per_pon_start()
        elif dlg._choice == 'run':
            self._pon_per_pon_run(demand_lyr, span_lyr)
        else:
            self._pon_per_pon_cancel()

    def _pon_is_accum_valid(self, layer_ref):
        """Return True if an accumulator layer reference is still alive in the project."""
        from qgis.PyQt import sip as _s
        try:
            if layer_ref is None or _s.isdeleted(layer_ref):
                return False
            from qgis.core import QgsProject
            return layer_ref.id() in QgsProject.instance().mapLayers()
        except Exception:
            return False

    # geom_str → QgsVectorLayer.geometryType() int (0=Point, 1=Line, 2=Polygon)
    _PON_GEOM_INT = {'Point': 0, 'LineString': 1, 'Polygon': 2}

    def _pon_find_existing_accum(self, accum_name, geom_str):
        """Find an existing project layer that an accumulator should reuse.

        Ticket #60: when the PON-per-PON button is toggled off and back on (or the
        project is re-opened), the in-memory accumulator reference is gone — but the
        actual "PON Groups" / "PON Zone Boundaries" / etc. layers are still in the
        project. Re-binding to them makes the next batch APPEND into the existing
        layers instead of spawning duplicate layers. Matches by exact name + geometry
        type; if several match (a project that already accumulated duplicates), reuse
        the one with the most features so we keep extending the real accumulator."""
        from qgis.core import QgsProject, QgsVectorLayer
        want_geom = self._PON_GEOM_INT.get(geom_str)
        best = None
        best_n = -1
        for lyr in QgsProject.instance().mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer):
                continue
            if lyr.name() != accum_name:
                continue
            if want_geom is not None and lyr.geometryType() != want_geom:
                continue
            n = lyr.featureCount()
            if n > best_n:
                best, best_n = lyr, n
        return best

    def _crash_safe_remove_layers(self, layer_ids):
        """Remove map layers crash-safely (Pattern C hardening).

        Removing a layer while an in-flight canvas render job still references it is
        a classic Qt5 sip double-free / segfault on older QGIS — the exact class
        behind "QGIS crashed and my basemaps/project were lost". Freeze the canvas
        first so no render job is running, remove each id (sip-guarded), then
        unfreeze + refresh ONCE. Behaviour-neutral: the same layers are removed,
        just without the mid-removal repaint that can re-enter and crash."""
        from qgis.core import QgsProject
        ids = [i for i in (layer_ids or []) if i]
        if not ids:
            return
        proj = QgsProject.instance()
        canvas = None
        try:
            canvas = self.iface.mapCanvas()
        except Exception:
            canvas = None
        if canvas is not None:
            try:
                canvas.freeze(True)
            except Exception:
                canvas = None
        try:
            for lid in ids:
                try:
                    proj.removeMapLayer(lid)
                except Exception:
                    pass
        finally:
            if canvas is not None:
                try:
                    canvas.freeze(False)
                    canvas.refresh()
                except Exception:
                    pass

    def _pon_merge_batch_into_accumulators(self):
        """After a batch run, merge the batch-specific layers into the 4 persistent
        accumulator layers using direct stored references (not name searching).

        Accumulator layers created (first batch) or appended to (subsequent batches):
          • PON Groups          — grouped demand points (self.grouped_layer)
          • PON Zone Boundaries — zone polygon boundaries (self.zone_boundaries_layer)
          • PON Splitter Points — splitter points (self.splitter_points_layer)
          • PON Drop Cables     — drop cables PTP (self.drop_ptp_layer)
        """
        from qgis.PyQt import sip as _sip_m
        from qgis.core import QgsProject, QgsVectorLayer, QgsFeature

        batch_label = getattr(self, '_current_batch_label', None) or 'unknown batch'

        # Map: (source ref attr, accumulator attr, accumulator name, geom_type str)
        ACCUM_MAP = [
            ('grouped_layer',          '_pon_accum_groups',    'PON Groups',          'Point'),
            ('zone_boundaries_layer',  '_pon_accum_zones',     'PON Zone Boundaries', 'Polygon'),
            ('splitter_points_layer',  '_pon_accum_splitters', 'PON Splitter Points', 'Point'),
            ('drop_ptp_layer',         '_pon_accum_drops',     'PON Drop Cables',     'LineString'),
        ]

        merged_count = 0
        _pending_removals = []   # batch intermediates → removed together, canvas-frozen
        for src_attr, accum_attr, accum_name, geom_str in ACCUM_MAP:
            # Get the batch layer from the stored reference
            batch_layer = getattr(self, src_attr, None)
            if batch_layer is None:
                self.log_message(f"  ⚠ Merge: '{accum_name}' — no source layer (self.{src_attr} is None)")
                continue
            try:
                if _sip_m.isdeleted(batch_layer):
                    self.log_message(f"  ⚠ Merge: '{accum_name}' — source layer was deleted")
                    continue
            except Exception:
                self.log_message(f"  ⚠ Merge: '{accum_name}' — source layer reference invalid")
                continue

            # Get or create the accumulator layer
            accum = getattr(self, accum_attr, None)
            if not self._pon_is_accum_valid(accum):
                # Ticket #60: the in-memory ref is gone (button toggled off/on, or
                # project re-opened). Re-bind to the EXISTING accumulator layer in the
                # project so this batch APPENDS into it instead of creating a duplicate.
                existing = self._pon_find_existing_accum(accum_name, geom_str)
                if existing is not None:
                    accum = existing
                    setattr(self, accum_attr, accum)
                    self.log_message(
                        f"  ✦ Reusing existing accumulator: '{accum_name}' "
                        f"({accum.featureCount()} features) — appending into it")
                else:
                    crs = batch_layer.crs().authid()
                    accum = QgsVectorLayer(f"{geom_str}?crs={crs}", accum_name, "memory")
                    accum.dataProvider().addAttributes(batch_layer.fields().toList())
                    accum.updateFields()
                    if batch_layer.renderer():
                        accum.setRenderer(batch_layer.renderer().clone())
                    if batch_layer.labeling():
                        accum.setLabeling(batch_layer.labeling().clone())
                        accum.setLabelsEnabled(batch_layer.labelsEnabled())
                    QgsProject.instance().addMapLayer(accum)
                    setattr(self, accum_attr, accum)
                    self.log_message(f"  ✦ Created accumulator: '{accum_name}'")

            # Append features from batch layer into accumulator
            feats = [QgsFeature(f) for f in batch_layer.getFeatures()]
            accum.dataProvider().addFeatures(feats)
            accum.updateExtents()
            accum.triggerRepaint()
            self.log_message(f"  ✦ '{accum_name}': +{len(feats)} → {accum.featureCount()} total")
            merged_count += 1

            # Defer removal: collect now, remove all batch intermediates together
            # with the canvas frozen once the merge loop is done (Qt5 crash-safe).
            _pending_removals.append(batch_layer.id())

        if merged_count == 0:
            self.log_message(f"  ⚠ No layers merged for {batch_label} — check pipeline completed all 5 steps")
        else:
            self.log_message(f"  ✓ Merge complete: {merged_count}/4 layers merged for {batch_label}")

        # Also remove the Step 2 demand points layer (intermediate layer, data lives in PON Groups)
        dp_layer = getattr(self, 'demand_points_layer', None)
        if dp_layer is not None:
            try:
                if not _sip_m.isdeleted(dp_layer):
                    _pending_removals.append(dp_layer.id())
                    self.log_message("  ✦ Removed intermediate demand points layer")
            except Exception:
                _swallowed_note()

        # Remove every batch intermediate in ONE canvas-frozen pass — no render job
        # is ever left holding a just-removed layer (the Qt5 segfault path).
        self._crash_safe_remove_layers(_pending_removals)

        # Refresh all accumulator renderers so new zone categories are visible
        self._pon_refresh_accum_renderers()

        # Force the map canvas to actually redraw — triggerRepaint only queues a redraw
        try:
            from qgis.PyQt.QtWidgets import QApplication as _QApp
            self.iface.mapCanvas().refresh()
            _QApp.processEvents()
        except Exception:
            _swallowed_note()

        # Persist the new accumulator handles so they survive a plugin reload (update).
        self._session_save()

    def _pon_refresh_accum_renderers(self):
        """Rebuild the categorized renderer on each accumulator layer so that all
        zone/group values added from the latest batch appear with correct colours.
        Called after every merge."""
        import colorsys
        from qgis.PyQt.QtGui import QColor
        from qgis.PyQt.QtCore import QVariant
        from qgis.core import (QgsRendererCategory,
                               QgsFillSymbol)

        def _categorized_with_catch_all(attr, categories, default_sym):
            """Build a categorized renderer that ALWAYS includes an 'all other
            values' catch-all, so no feature is ever silently invisible.

            Ticket #76/#77: a categorized renderer with no catch-all draws NOTHING
            for a feature whose value matches no category — and if the value list
            comes back empty (e.g. every zone_id is null/-1 mid-edit) it builds a
            zero-category renderer that hides the ENTIRE layer. That looked exactly
            like 'all my drop cables were deleted' when the data was still there.
            The null-valued category below is QGIS's 'all other values' bucket, so
            unmatched / null / -1 features (and an empty category list) still paint."""
            cats = list(categories)
            cats.append(QgsRendererCategory(QVariant(), default_sym, "Other", True))
            return QgsCategorizedSymbolRenderer(attr, cats)

        # ── Zone Boundaries: categorized by zone_name, distinct hue per zone ──
        zones_accum = getattr(self, '_pon_accum_zones', None)
        if self._pon_is_accum_valid(zones_accum):
            try:
                unique_zones = sorted(set(
                    str(f['zone_name']) for f in zones_accum.getFeatures()
                    if f['zone_name'] is not None
                ))
                n = max(len(unique_zones), 1)
                categories = []
                for i, z_name in enumerate(unique_zones):
                    hue = (i / n) % 1.0
                    r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.65, 0.88)]
                    fill_col    = QColor(r, g, b, 70)
                    outline_col = QColor(r, g, b, 230)
                    sym = QgsFillSymbol.createSimple({
                        'color':         fill_col.name(QColor.NameFormat.HexArgb),
                        'outline_color': outline_col.name(),
                        'outline_width': '1.2',
                        'outline_style': 'solid',
                    })
                    categories.append(QgsRendererCategory(z_name, sym, z_name))
                _zone_other = QgsFillSymbol.createSimple({
                    'color': '#28808080', 'outline_color': '#808080',
                    'outline_width': '0.8', 'outline_style': 'solid',
                })
                zones_accum.setRenderer(
                    _categorized_with_catch_all('zone_name', categories, _zone_other))
                zones_accum.triggerRepaint()
            except Exception as _e:
                self.log_message(f"  ⚠ PON boundary renderer refresh failed: {_e}")

        # ── PON Groups: categorized by zone_id, distinct hue per zone ──
        groups_accum = getattr(self, '_pon_accum_groups', None)
        if self._pon_is_accum_valid(groups_accum):
            try:
                unique_zones = sorted(set(
                    f['zone_id'] for f in groups_accum.getFeatures()
                    if f['zone_id'] is not None
                ))
                n = max(len(unique_zones), 1)
                categories = []
                for i, z_id in enumerate(unique_zones):
                    hue = (i / n) % 1.0
                    r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.7, 0.9)]
                    sym = QgsMarkerSymbol.createSimple({
                        'name': 'circle', 'color': QColor(r, g, b).name(),
                        'size': '2.5', 'outline_style': 'no'
                    })
                    categories.append(QgsRendererCategory(z_id, sym, vf_pon_name(z_id)))
                _grp_other = QgsMarkerSymbol.createSimple({
                    'name': 'circle', 'color': '#808080',
                    'size': '2.5', 'outline_style': 'no'
                })
                groups_accum.setRenderer(
                    _categorized_with_catch_all('zone_id', categories, _grp_other))
                groups_accum.triggerRepaint()
            except Exception as _e:
                self.log_message(f"  ⚠ PON renderer refresh failed: {_e}")

        # ── Splitters: categorized by zone_id ──
        splitters_accum = getattr(self, '_pon_accum_splitters', None)
        if self._pon_is_accum_valid(splitters_accum):
            try:
                unique_zones = sorted(set(
                    f['zone_id'] for f in splitters_accum.getFeatures()
                    if f['zone_id'] is not None
                ))
                n = max(len(unique_zones), 1)
                categories = []
                for i, z_id in enumerate(unique_zones):
                    hue = (i / n) % 1.0
                    r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.8, 0.85)]
                    sym = QgsMarkerSymbol.createSimple({
                        'name': 'circle', 'color': QColor(r, g, b).name(),
                        'size': '4', 'outline_color': 'black', 'outline_width': '0.5'
                    })
                    categories.append(QgsRendererCategory(z_id, sym, vf_pon_name(z_id)))
                _sp_other = QgsMarkerSymbol.createSimple({
                    'name': 'circle', 'color': '#808080',
                    'size': '4', 'outline_color': 'black', 'outline_width': '0.5'
                })
                splitters_accum.setRenderer(
                    _categorized_with_catch_all('zone_id', categories, _sp_other))
                splitters_accum.triggerRepaint()
            except Exception as _e:
                self.log_message(f"  ⚠ Splitters renderer refresh failed: {_e}")

        # ── Drop Cables: categorized by zone_id, colour-coded lines ──
        drops_accum = getattr(self, '_pon_accum_drops', None)
        if self._pon_is_accum_valid(drops_accum):
            try:
                unique_zones = sorted(set(
                    f['zone_id'] for f in drops_accum.getFeatures()
                    if f['zone_id'] is not None
                ))
                n = max(len(unique_zones), 1)
                categories = []
                for i, z_id in enumerate(unique_zones):
                    hue = (i / n) % 1.0
                    r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.9, 0.85)]
                    sym = QgsLineSymbol.createSimple({
                        'color': QColor(r, g, b).name(), 'width': '0.4'
                    })
                    categories.append(QgsRendererCategory(z_id, sym, vf_pon_name(z_id)))
                # Drops MUST never vanish: unmatched / null / -1 zone_id (the
                # regen default) paints as a plain black drop line, not nothing.
                _drop_other = QgsLineSymbol.createSimple({
                    'color': '0,0,0', 'width': '0.4', 'line_style': 'solid'
                })
                drops_accum.setRenderer(
                    _categorized_with_catch_all('zone_id', categories, _drop_other))
                drops_accum.triggerRepaint()
            except Exception as _e:
                self.log_message(f"  ⚠ Drop cables renderer refresh failed: {_e}")

        # ── PON detail counts: keep zone labels (units + splitters) current ──
        self._pon_refresh_zone_counts()

    def _pon_refresh_zone_counts(self):
        """Recompute unit_count + splitter_count on each PON Zone Boundary feature
        from the LIVE splitter + groups accumulators, so the zone labels stay
        correct after a splitter or demand point is added/deleted in Manual
        Override (ticket #37 — counts must update on changes). No-op if there is
        no zone-boundary layer or it has neither count field."""
        from qgis.PyQt import sip
        zones = getattr(self, '_pon_accum_zones', None)
        try:
            if not zones or sip.isdeleted(zones):
                return
        except Exception:
            return
        zfields = [f.name() for f in zones.fields()]
        # Resolve the count field NAMES robustly. Shapefiles truncate DBF field names
        # to 10 chars, so 'splitter_count' becomes 'splitter_c' — matching the literal
        # 'splitter_count' silently missed it and the splitter count never refreshed on
        # shapefile-backed zone layers. Match the full name first, then by prefix.
        sc_name = ('splitter_count' if 'splitter_count' in zfields
                   else next((n for n in zfields if n.lower().startswith('splitter_c')), None))
        uc_name = ('unit_count' if 'unit_count' in zfields
                   else next((n for n in zfields if n.lower().startswith('unit_c')), None))
        has_sc = sc_name is not None
        has_uc = uc_name is not None
        if not (has_sc or has_uc) or 'zone_id' not in zfields:
            return

        def _alive(lyr):
            try:
                return lyr is not None and not sip.isdeleted(lyr)
            except Exception:
                return lyr is not None

        def _count_by_zone(layer):
            out = {}
            if not _alive(layer):
                return out
            _has_zone_id = 'zone_id' in [fld.name() for fld in layer.fields()]
            for f in layer.getFeatures():
                z = f['zone_id'] if _has_zone_id else None
                if z is None:
                    continue
                try:
                    z = int(z)
                except (TypeError, ValueError):
                    continue
                out[z] = out.get(z, 0) + 1
            return out

        def _sum_by_zone(layer, field):
            out = {}
            if not _alive(layer):
                return out
            _fn = [fld.name() for fld in layer.fields()]
            if 'zone_id' not in _fn or field not in _fn:
                return out
            for f in layer.getFeatures():
                z = f['zone_id']
                if z is None:
                    continue
                try:
                    z = int(z)
                except (TypeError, ValueError):
                    continue
                try:
                    v = int(f[field] or 0)
                except (TypeError, ValueError):
                    v = 0
                out[z] = out.get(z, 0) + v
            return out

        # Splitters in a zone = splitter features by zone_id, EXCLUDING empty
        # (drop_count == 0) residue splitters that serve no homes. UNITS in a zone =
        # the GREATER of (a) the demand points assigned to that zone and (b) the sum of
        # the splitter drop_counts. Taking the max means neither a group left without a
        # splitter (drop_count misses its homes) nor a demand point with a NULL zone_id
        # (home count misses it) can undercount the units label — whichever source has
        # the fuller picture wins.
        _sp_acc = getattr(self, '_pon_accum_splitters', None)
        _grp_acc = getattr(self, '_pon_accum_groups', None)

        def _count_splitters_by_zone(layer):
            out = {}
            if not _alive(layer):
                return out
            _fn = [fld.name() for fld in layer.fields()]
            _has_z = 'zone_id' in _fn
            _has_dc = 'drop_count' in _fn
            for f in layer.getFeatures():
                z = f['zone_id'] if _has_z else None
                if z is None:
                    continue
                if _has_dc:
                    _dcv = f['drop_count']
                    # Skip ONLY splitters with an explicit drop_count of 0 (empty residue
                    # that serves no homes). A NULL/unknown drop_count is kept as a real
                    # splitter so a legit-but-unpopulated count is never silently dropped.
                    try:
                        if _dcv is not None and int(_dcv) == 0:
                            continue
                    except (TypeError, ValueError):
                        pass
                try:
                    z = int(z)
                except (TypeError, ValueError):
                    continue
                out[z] = out.get(z, 0) + 1
            return out

        sp_by_zone = _count_splitters_by_zone(_sp_acc)
        _dc_by_zone = _sum_by_zone(_sp_acc, 'drop_count')
        _homes_by_zone = _count_by_zone(_grp_acc)   # demand points assigned to each zone
        uc_by_zone = {z: max(_homes_by_zone.get(z, 0), _dc_by_zone.get(z, 0))
                      for z in set(_homes_by_zone) | set(_dc_by_zone)}

        sc_idx = zones.fields().indexFromName(sc_name) if has_sc else -1
        uc_idx = zones.fields().indexFromName(uc_name) if has_uc else -1
        attr_map = {}
        for f in zones.getFeatures():
            z = f['zone_id']
            try:
                z = int(z)
            except (TypeError, ValueError):
                continue
            upd = {}
            if has_sc:
                upd[sc_idx] = sp_by_zone.get(z, 0)
            if has_uc:
                # write 0 (not skip) when a zone has lost all its demand points,
                # otherwise the stale non-zero unit_count label persists
                upd[uc_idx] = uc_by_zone.get(z, 0)
            if upd:
                attr_map[f.id()] = upd
        if attr_map:
            try:
                zones.dataProvider().changeAttributeValues(attr_map)
                zones.updateExtents()
                zones.triggerRepaint()
                self.log_message(
                    f"  ✦ PON counts refreshed ({len(attr_map)} PONs: "
                    f"units + splitters)")
            except Exception as _e:
                self.log_message(f"  ⚠ PON count refresh failed: {_e}")

    def _pon_existing_offsets(self):
        """Highest zone_id and group_id already present in the project's PON
        layers, so a resumed / re-opened PON-per-PON session CONTINUES numbering
        instead of restarting at Zone 1. Reads from the SAVED layers via the
        provider's maximumValue (cheap), so it survives a project re-open even
        though the in-memory accumulators are gone. Returns (max_zone, max_group)."""
        from qgis.core import QgsProject, QgsVectorLayer
        max_zone = 0
        max_group = 0
        for lyr in QgsProject.instance().mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer):
                continue
            fnames = [f.name() for f in lyr.fields()]
            if 'zone_id' in fnames:
                try:
                    v = lyr.maximumValue(lyr.fields().indexFromName('zone_id'))
                    if v is not None:
                        max_zone = max(max_zone, int(v))
                except Exception:
                    pass
            # Ticket #69: consider EVERY group-like field on the layer (a splitter
            # layer carries group_id, a grouped-demand layer group_8/…); taking the
            # max across all of them avoids reading a stale lower field and reusing
            # group numbers in the next batch.
            for gf in [n for n in fnames
                       if n == 'group_id' or _DROP_GRP_RE.fullmatch(n)]:  # #79: any group_<N>
                # gf is drawn from fnames, so no membership re-check is needed.
                try:
                    v = lyr.maximumValue(lyr.fields().indexFromName(gf))
                    if v is not None:
                        max_group = max(max_group, int(v))
                except Exception:
                    pass
        return max_zone, max_group

    def _pon_per_pon_run(self, demand_lyr, span_lyr):
        """Run the full AutoNet pipeline (all 5 steps) on only the polygon-selected features."""
        from qgis.PyQt.QtWidgets import QMessageBox
        from qgis.core import QgsVectorLayer, QgsFeatureRequest, QgsProject, QgsWkbTypes

        demand_ids = list(demand_lyr.selectedFeatureIds())
        span_ids   = list(span_lyr.selectedFeatureIds())

        if not demand_ids:
            QMessageBox.warning(self, "PON per PON", "No demand points selected — aborting.")
            self._pon_per_pon_cancel()
            return

        # Build an in-memory copy containing only the selected features
        def _filtered_layer(source_lyr, sel_ids, name):
            wkb = source_lyr.wkbType()
            geom_str = QgsWkbTypes.displayString(wkb)
            crs_str  = source_lyr.crs().authid()
            tmp = QgsVectorLayer(f"{geom_str}?crs={crs_str}", name, "memory")
            tmp.dataProvider().addAttributes(source_lyr.fields().toList())
            tmp.updateFields()
            feats = list(source_lyr.getFeatures(QgsFeatureRequest().setFilterFids(sel_ids)))
            tmp.dataProvider().addFeatures(feats)
            return tmp

        # Name the temp layers identically to the originals so on_autonet_clicked
        # layer-detection resolves them via the combo (not by name-search fallback)
        tmp_demand = _filtered_layer(demand_lyr, demand_ids, demand_lyr.name())
        tmp_span   = _filtered_layer(span_lyr, span_ids, span_lyr.name()) if span_ids else None

        _orig_demand = self.comboBox_erf.currentLayer()
        _orig_span   = self.comboBox_span_layer.currentLayer()
        _orig_road   = self.comboBox_road_layer.currentLayer()

        tmp_demand_id = None
        tmp_span_id   = None

        try:
            # Add WITH legend visibility so QgsMapLayerComboBox can reference them
            QgsProject.instance().addMapLayer(tmp_demand, True)
            tmp_demand_id = tmp_demand.id()
            self.comboBox_erf.setLayer(tmp_demand)

            if tmp_span:
                QgsProject.instance().addMapLayer(tmp_span, True)
                tmp_span_id = tmp_span.id()
                self.comboBox_span_layer.setLayer(tmp_span)

            # Ensure Tight PON of 96 clustering method is active
            for i in range(self.comboBox_clustering_method.count()):
                if 'tight' in self.comboBox_clustering_method.itemText(i).lower():
                    self.comboBox_clustering_method.setCurrentIndex(i)
                    break

            # Preserve the full (unfiltered) span layer so splitter snapping
            # can use all Distribution spans — not just those inside the polygon
            self._pon_full_span_layer = span_lyr

            # BUGFIX: Reset ALL layer references before each batch so that if any step
            # fails silently, subsequent steps won't use previous batch's stale layers.
            # Previously only grouped_layer was reset; demand_points_layer and
            # splitter_points_layer stale references caused missing drops on some zones.
            self.grouped_layer = None
            self.demand_points_layer = None
            self.splitter_points_layer = None
            self.zone_boundaries_layer = None
            self.drop_ptp_layer = None

            # If the previous session was closed (button toggled off), start fresh:
            # null the old accumulators so the merge step creates new ones, and reset
            # zone/group counters so numbering starts from 1 again.
            # Also treat truly first-ever run (all None) as a fresh session.
            _accum_fresh = (
                getattr(self, '_pon_new_session_needed', False) or
                (getattr(self, '_pon_accum_groups',    None) is None and
                 getattr(self, '_pon_accum_splitters', None) is None)
            )
            if _accum_fresh:
                self._pon_accum_groups    = None
                self._pon_accum_zones     = None
                self._pon_accum_splitters = None
                self._pon_accum_drops     = None
                self._pon_batch_count  = 0
                # Pass 4: reset the session report for the new session.
                self._pon_session_report = []
                self._pon_session_cum = (0, 0, 0)
                # Persistent numbering: continue from the highest zone/group that
                # already exists in the project's SAVED PON layers, so a planner
                # who stops & resumes (or re-opens the project) keeps counting up
                # instead of restarting at Zone 1.
                _ez, _eg = self._pon_existing_offsets()
                self._pon_zone_offset  = _ez
                self._pon_group_offset = _eg
                self._pon_new_session_needed = False
                if _ez or _eg:
                    self.log_message(
                        f"  [PON per PON] Resuming — continuing numbering from "
                        f"zone {_ez + 1} / group {_eg + 1} (existing PON layers found)")
                else:
                    self.log_message("  [PON per PON] Fresh project — PON/splitter numbering starts at 1")

            # Advance the batch counter BEFORE running so the label is correct
            self._pon_batch_count += 1
            batch_label = f"PON Batch {self._pon_batch_count}"

            # Rotate zone polygon colors per batch (golden angle ~137.5° for max separation)
            self._pon_color_offset = (self._pon_batch_count * 0.382) % 1.0

            # Ticket #69 + #70: derive the offsets from the ACTUAL groups/zones still
            # in the project (accumulators are merged after every batch). This makes
            # numbering follow reality in BOTH directions: it advances above existing
            # numbers so two batches never duplicate (#69), AND it drops back down
            # when the planner deletes a bad batch's layers so a new batch continues
            # from the real remaining count instead of "what would have been" (#70).
            _ez_now, _eg_now = self._pon_existing_offsets()
            self._pon_group_offset = _eg_now
            self._pon_zone_offset  = _ez_now

            # Run the full 5-step pipeline with sequential offsets
            self.on_autonet_clicked(
                _zone_offset=self._pon_zone_offset,
                _group_offset=self._pon_group_offset,
                _batch_label=batch_label,
            )

            # Advance offsets for the next run using the max IDs written this run
            self._pon_group_offset = getattr(self, '_last_max_group', self._pon_group_offset)
            self._pon_zone_offset  = getattr(self, '_last_max_zone',  self._pon_zone_offset)

            # Merge batch-specific layers into persistent accumulators
            self.log_message("\n── Merging batch layers into persistent accumulators ──")
            self._pon_merge_batch_into_accumulators()

            # Pass 4: record this batch + print a per-batch line and the cumulative
            # session summary. READS the accumulators only (feature counts — one boundary
            # per PON); the pipeline, offset arithmetic and merge above are untouched.
            try:
                from .pon_per_pon_ux import batch_line, session_summary
            except ImportError:
                from pon_per_pon_ux import batch_line, session_summary
            try:
                from qgis.PyQt import sip as _pp_sip

                def _pp_cnt(_l):
                    return _l.featureCount() if (_l is not None and not _pp_sip.isdeleted(_l)) else 0

                _cum = (_pp_cnt(getattr(self, '_pon_accum_zones', None)),
                        _pp_cnt(getattr(self, '_pon_accum_splitters', None)),
                        _pp_cnt(getattr(self, '_pon_accum_groups', None)))
                _prev = getattr(self, '_pon_session_cum', (0, 0, 0))
                _b = tuple(max(0, _cum[i] - _prev[i]) for i in range(3))
                self._pon_session_cum = _cum
                if not hasattr(self, '_pon_session_report'):
                    self._pon_session_report = []
                self._pon_session_report.append(
                    {"batch": self._pon_batch_count, "pons": _b[0],
                     "splitters": _b[1], "stands": _b[2]})
                self.log_message(batch_line(self._pon_batch_count, _b[0], _b[1], _b[2]))
                for _ln in session_summary(self._pon_session_report):
                    self.log_message(_ln)
            except Exception as _pp_e:
                self.log_message(f"  (PON per PON summary skipped: {_pp_e})")

            # CRITICAL: clear the batch label NOW so that Manual Override drop regen
            # (which calls on_generate_drop_ptp_clicked) does NOT think it is inside a
            # batch run and correctly targets the accumulator instead of creating a new layer.
            self._current_batch_label = None

        finally:
            # #8: also clear the batch label HERE (not only in the try above). An
            # exception mid-batch must not leave the dock stuck in "batch mode", or the
            # next Manual Override drop regen creates a stray '- PON Batch N' layer
            # instead of updating the accumulator. (The early clear in the try still
            # stands — it must precede any post-merge regen.)
            self._current_batch_label = None
            # Clear the full-span override and color offset now that the pipeline is done
            self._pon_full_span_layer = None
            self._pon_color_offset = 0.0

            # Restore original combo selections
            self.comboBox_erf.setLayer(_orig_demand)
            self.comboBox_span_layer.setLayer(_orig_span)
            if _orig_road:
                self.comboBox_road_layer.setLayer(_orig_road)

            # Remove the temporary filtered layers from the project. These were
            # added with legend visibility + set on the layer combos, so they are
            # the most likely to be held by an in-flight render job — remove them
            # canvas-frozen (Qt5 crash-safe). Combos were already restored above.
            self._crash_safe_remove_layers([tmp_demand_id, tmp_span_id])

            demand_lyr.removeSelection()
            span_lyr.removeSelection()

        # Stay in PON-per-PON mode so user can immediately select the next batch
        self._btn_pon_per_pon.setChecked(True)
        self._btn_pon_per_pon.setText(getattr(self, "_PON_PER_PON_LABEL", "🎯 PON per PON Manual  ·BETA"))

        btn = QMessageBox.question(
            self, "PON per PON — Continue?",
            "PON pipeline complete for this batch.\n\n"
            "Would you like to select and run the next PON batch?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if btn == QMessageBox.StandardButton.Yes:
            self._pon_per_pon_start()
        else:
            self._pon_per_pon_cancel()

    def on_generate_demand_points_clicked(self):
        """Generate demand points from grouped parcels at their centroids."""
        # Use the most recently generated grouped layer
        selected_layer = self.grouped_layer

        # sip guard: a stored handle to a since-deleted layer is still truthy but its
        # C++ object is gone — `.name()`/`.getFeatures()` would raise RuntimeError.
        if not selected_layer or sip.isdeleted(selected_layer):
            self.log_message("ERROR: Please generate grouped parcels first.")
            return
        
        self.log_message("\n=== Generating Demand Points ===")
        self.log_message(f"Source Layer: '{selected_layer.name()}'")
        
        try:
            from qgis.core import QgsVectorLayer, QgsFeature
            
            # Get features from source layer
            features = list(selected_layer.getFeatures())
            
            if len(features) == 0:
                self.log_message("ERROR: Layer has no features.")
                return
            
            # Create new point layer with same CRS
            crs = selected_layer.crs().authid()
            demand_layer = QgsVectorLayer(f"Point?crs={crs}", 
                                         f"{selected_layer.name()} - Demand Points", 
                                         "memory")
            provider = demand_layer.dataProvider()
            
            # Copy all fields from source layer
            provider.addAttributes(selected_layer.fields().toList())
            demand_layer.updateFields()
            
            # Create demand point for each parcel at its centroid
            total_src = len(features)
            self.log_message(f"Processing {total_src} features...")
            self._start_timer()
            demand_features = []
            for idx, feature in enumerate(features):
                self._progress(idx + 1, total_src, 'Demand pts')
                geom = feature.geometry()
                if geom and not geom.isEmpty():
                    # Get centroid
                    centroid = geom.centroid()
                    
                    # Create new point feature
                    demand_feature = QgsFeature(demand_layer.fields())
                    demand_feature.setGeometry(centroid)
                    
                    # Copy all attributes from source feature
                    for field in selected_layer.fields():
                        demand_feature[field.name()] = feature[field.name()]
                    
                    demand_features.append(demand_feature)
            
            # Add features to layer
            provider.addFeatures(demand_features)
            demand_layer.updateExtents()
            
            # Add layer to project
            demand_layer = self._add_output_layer(demand_layer)
            
            # Store reference for drop cable generation
            self.demand_points_layer = demand_layer
            
            self.log_message(f"\nCreated {len(demand_features)} demand points")
            self._elapsed("Total time")
            self.log_message(f"New layer: '{demand_layer.name()}'")
            self.log_message("All attributes copied from source parcels")
            
        except Exception as e:
            self.log_message(f"ERROR: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def apply_batch_symbology(self, layer: QgsVectorLayer, field_name: str = 'batch_id'):
        """Apply categorized symbology to show different batches/clusters in different colors.
        
        Args:
            layer: Layer with grouping field
            field_name: Name of the field to use for symbology
        """
        try:
            from qgis.core import (
                QgsRendererCategory,
                QgsSymbol
            )
            from qgis.PyQt.QtGui import QColor
            import random
            
            field_idx = layer.fields().indexOf(field_name)
            
            if field_idx < 0:
                return
            
            # Get unique values
            unique_values = set()
            for feature in layer.getFeatures():
                value = feature.attribute(field_name)
                if value is not None:
                    unique_values.add(value)
            
            # Create categories
            categories = []
            for value in sorted(unique_values):
                # Generate a color for each group
                random.seed(value)  # Consistent colors for same value
                color = QColor(
                    random.randint(100, 255),
                    random.randint(100, 255),
                    random.randint(100, 255),
                    180  # Some transparency
                )
                
                symbol = QgsSymbol.defaultSymbol(layer.geometryType())
                symbol.setColor(color)
                
                # Determine label — for zone_name the stored value IS already
                # the human-readable label ("Zone 1", "Zone 2", …)
                if field_name == 'zone_name':
                    label = str(value)
                elif 'batch' in field_name.lower():
                    label = f"Batch {value}"
                elif 'cluster' in field_name.lower():
                    label = f"Cluster {value}"
                elif 'pon' in field_name.lower():
                    label = f"PON {value}"
                elif 'zone' in field_name.lower():
                    label = vf_pon_name(value)   # a zone IS a PON
                else:
                    label = f"Splitter {value}"
                
                category = QgsRendererCategory(
                    value,
                    symbol,
                    label
                )
                categories.append(category)
            
            # Apply renderer (Batch A: with 'all other values' catch-all so null/
            # unexpected values never make a feature — or the whole layer — vanish)
            renderer = _categorized_with_catch_all(layer, field_name, categories)
            layer.setRenderer(renderer)
            layer.triggerRepaint()

            self.log_message("  Applied color-coded symbology.")
            
        except Exception as e:
            # If symbology fails, just log it but don't fail the whole operation
            self.log_message(f"  (Could not apply symbology: {e!s})")

    def on_find_splitters_clicked(self):
        """Find and display optimal splitter locations."""
        selected_layer = self.comboBox_erf.currentLayer()
        
        if not selected_layer:
            self.log_message("ERROR: Please select a layer.")
            return
        
        if not SKLEARN_AVAILABLE or not NUMPY_AVAILABLE:
            self.log_message("ERROR: Splitter optimization requires scikit-learn and numpy.")
            self.log_message("Install with: pip install scikit-learn numpy")
            return
        
        num_splitters = 10  # Default number of splitters
        
        self.log_message("\n=== Finding Optimal Splitter Locations ===")
        self.log_message(f"Layer: '{selected_layer.name()}'")
        self.log_message(f"Number of splitters: {num_splitters}")
        
        try:
            # Get features
            features = list(selected_layer.getFeatures())
            
            if len(features) == 0:
                self.log_message("ERROR: Layer has no features.")
                return
            
            # Find optimal locations
            self._start_timer()
            splitter_locations = find_optimal_splitter_locations(features, num_splitters)
            
            # Create a memory layer for splitter points
            from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject, QgsField
            from qgis.PyQt.QtCore import QMetaType
            
            # Get CRS from source layer
            crs = selected_layer.crs().authid()
            splitter_layer = QgsVectorLayer(f"Point?crs={crs}", "Optimal Splitter Locations", "memory")
            provider = splitter_layer.dataProvider()
            
            # Add fields
            provider.addAttributes([
                QgsField("splitter_id", QMetaType.Type.Int),
                QgsField("x_coord", QMetaType.Type.Double),
                QgsField("y_coord", QMetaType.Type.Double)
            ])
            splitter_layer.updateFields()
            
            # Add splitter points
            splitter_features = []
            for idx, location in enumerate(splitter_locations):
                feat = QgsFeature()
                feat.setGeometry(QgsGeometry.fromPointXY(location))
                feat.setAttributes([idx + 1, location.x(), location.y()])
                splitter_features.append(feat)
            
            provider.addFeatures(splitter_features)
            splitter_layer.updateExtents()
            
            # Style the splitter layer
            from qgis.core import QgsMarkerSymbol, QgsSingleSymbolRenderer
            
            symbol = QgsMarkerSymbol.createSimple({
                'name': 'star',
                'color': 'red',
                'size': '4',
                'outline_color': 'white',
                'outline_width': '0.5'
            })
            renderer = QgsSingleSymbolRenderer(symbol)
            splitter_layer.setRenderer(renderer)
            
            # Add layer to project
            QgsProject.instance().addMapLayer(splitter_layer)
            
            self.log_message(f"\nCreated {len(splitter_locations)} optimal splitter locations.")
            self.log_message("Splitter layer added to map.")
            self.log_message("Locations minimize average distance to parcels/points.")
            self._elapsed("Total time")
            
        except Exception as e:
            self.log_message(f"ERROR: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_cluster_erven_clicked(self, _zone_offset=0, _group_offset=0, _batch_label=None):
        """Generate PON groups using Tight PON of 96 (groups of 8) along Distribution spans.

        _zone_offset  – add this to every zone_id so runs don't clash (PON-per-PON mode).
        _group_offset – add this to every group_id so runs don't clash.
        _batch_label  – suffix appended to output layer names (e.g. "PON Batch 2").
        """
        from qgis.core import QgsVectorLayer, QgsFeature, QgsField
        from qgis.PyQt.QtCore import QMetaType

        selected_layer = self.comboBox_erf.currentLayer()
        if not selected_layer:
            self.log_message("ERROR: Please select a layer.")
            return

        layer_type_name = "Demand Points"
        target_size = 8

        self.log_message(f"\n=== Grouping {layer_type_name} ===")
        self.log_message(f"Layer: '{selected_layer.name()}' ({selected_layer.featureCount()} features)")

        _input_fields = [f.name() for f in selected_layer.fields()]
        _subset = selected_layer.subsetString()
        # Pass 1: run the pre-flight checks up front through the pure helper — one clear
        # message before the run, not surprises mid-way. 'error' stops; 'warn' continues.
        try:
            from .pon_cluster_ux import cluster_preflight
        except ImportError:
            from pon_cluster_ux import cluster_preflight
        _preflight = cluster_preflight(
            _input_fields, _subset, selected_layer.featureCount(),
            bool(_demand_group_field(_input_fields)))   # #79: any group_<N>
        for _sev, _msg in _preflight:
            self.log_message(("⛔ ERROR: " if _sev == "error" else "⚠ WARNING: ") + _msg)
        if any(_sev == "error" for _sev, _ in _preflight):
            return

        try:
            features = list(selected_layer.getFeatures())
            total_features = len(features)

            if total_features == 0:
                self.log_message("ERROR: Layer has no features.")
                return

            route_layer = self.comboBox_span_layer.currentLayer()
            road_layer  = self.comboBox_road_layer.currentLayer()
            if road_layer:
                self.log_message(f"Road barrier layer: '{road_layer.name()}'")

            try:
                network_coverage = self.doubleSpinBox_span_corridor.value()
            except AttributeError:
                network_coverage = 150.0
            group_cohesion = 120
            gap_tolerance  = 3

            geom_type     = selected_layer.geometryType()

            if route_layer:
                self.log_message(f"Grouping along route: '{route_layer.name()}'")
                route_field_names = [f.name() for f in route_layer.fields()]
                if 'Cable Type' in route_field_names:
                    self.log_message("🎯 FILTERING: Only Distribution spans (Cable Type = 'Distribution')")
                else:
                    self.log_message("⚠ WARNING: Span layer has no 'Cable Type' field — using ALL spans")
                self.log_message(f"Span corridor: {network_coverage:.0f} m")
            else:
                self.log_message("Grouping without route — detecting block boundaries...")

            self.log_message(f"Clustering {total_features} features into PONs of {target_size}...")
            self._start_operation("Generating PON Groups…")
            QApplication.processEvents()

            feature_to_group = cluster_tight_groups_of_8(
                features,
                route_layer=route_layer,
                target_size=target_size,
                span_proximity_limit=network_coverage,
                adjacency_distance=group_cohesion,
                gap_tolerance_multiplier=gap_tolerance,
                progress_callback=lambda done, total, lbl='Clustering': self._progress(done, total, lbl),
                road_layer=road_layer,
                demand_crs=selected_layer.crs(),
            )

            if not feature_to_group:
                self.log_message("ERROR: No features could be grouped.")
                return

            import time as _time
            self.log_message(f"  ⏱ Clustering — {self._fmt_time(_time.time() - self._op_t0)}")

            # Pass 1: clean result summary (pure helper) — splitters formed, avg size,
            # and any over/under-target splitters flagged, so the planner sees the shape
            # of the cluster at a glance instead of scrolling raw output.
            try:
                from .pon_cluster_ux import cluster_summary, format_summary
            except ImportError:
                from pon_cluster_ux import cluster_summary, format_summary
            try:
                for _ln in format_summary(cluster_summary(feature_to_group)):
                    self.log_message(_ln)
            except Exception as _sum_e:
                self.log_message(f"  (summary skipped: {_sum_e})")

            crs = selected_layer.crs().authid()
            geom_name = {0: "Point", 1: "LineString", 2: "Polygon"}.get(geom_type, "Polygon")
            _lyr_suffix = f" - {_batch_label}" if _batch_label else f" - Groups of {target_size}"
            new_layer = QgsVectorLayer(
                f"{geom_name}?crs={crs}",
                f"{selected_layer.name()}{_lyr_suffix}",
                "memory"
            )
            provider = new_layer.dataProvider()
            provider.addAttributes(selected_layer.fields().toList())
            field_name = f'group_{target_size}'
            provider.addAttributes([QgsField(field_name, QMetaType.Type.Int)])
            zone_field_name  = 'zone_id'
            zone_name_field  = 'zone_name'
            local_field_name = 'group_local'   # per-zone rank 1..N (DISPLAY-only)
            provider.addAttributes([
                QgsField(zone_field_name,  QMetaType.Type.Int),
                QgsField(zone_name_field,  QMetaType.Type.QString),
                # group_local = the group's rank WITHIN its zone (1..N). group_id stays
                # globally-unique (routing + Manual Override untouched); this is the
                # per-zone number crews read on the label. The splitter copies it verbatim
                # so the two always agree (#114/#126 mismatch guard).
                QgsField(local_field_name, QMetaType.Type.Int),
            ])
            new_layer.updateFields()

            feature_positions = {}
            for feat in features:
                geom = feat.geometry()
                if geom and not geom.isEmpty():
                    c = geom.centroid().asPoint()
                    feature_positions[feat.id()] = (c.x(), c.y())

            # In PON-per-PON mode the whole selection IS one zone — no 96-unit cap.
            # In normal AutoNet mode keep the 96-unit cap.
            zone_max_size = total_features if _batch_label else 96
            olt_layer = self.comboBox_olt_layer.currentLayer()
            feature_to_zone = group_zones_from_groups(
                feature_to_group,
                max_zone_size=zone_max_size,
                feature_positions=feature_positions,
                route_layer=route_layer,
                pop_layer=olt_layer,
            )

            _no_group = sum(1 for f in features if feature_to_group.get(f.id()) is None)
            self.log_message(
                f"Grouped: {len(feature_to_group)} / {total_features} features "
                f"({_no_group} skipped)"
            )

            # DISPLAY-ONLY per-zone numbering: rank each group WITHIN its zone (1..N).
            # Keyed on the pre-offset (zone, group) — the rank is independent of the
            # global offset, so it's the clean "Grp 1..N per zone" crews want, while the
            # stored group_id remains globally-unique for routing. Sorting the distinct
            # group_ids per zone makes the rank deterministic + stable across re-runs.
            _groups_per_zone = {}
            for _fid_r, _gid_r in feature_to_group.items():
                if _gid_r is None:
                    continue
                _zz_r = feature_to_zone.get(_fid_r)
                if _zz_r is None:
                    continue
                _groups_per_zone.setdefault(_zz_r, set()).add(_gid_r)
            _local_rank = {}   # (zone_id, group_id) -> per-zone rank 1..N
            for _zz_r, _gids_r in _groups_per_zone.items():
                for _rnk, _gid_r in enumerate(sorted(_gids_r), start=1):
                    _local_rank[(_zz_r, _gid_r)] = _rnk

            self.log_message("Building output layer...")
            new_features = []
            _ungrouped_count = 0
            for idx, feat in enumerate(features):
                self._progress(idx + 1, total_features, 'Output')
                group_id = feature_to_group.get(feat.id())
                z_id = feature_to_zone.get(feat.id()) if group_id is not None else None
                if group_id is None:
                    _ungrouped_count += 1

                # Apply offsets so each PON-per-PON batch has globally unique IDs
                g_out = (group_id + _group_offset) if group_id is not None else None
                z_out = (z_id    + _zone_offset)   if z_id    is not None else None
                # per-zone rank (display-only) — keyed on the PRE-offset (zone, group)
                local_out = _local_rank.get((z_id, group_id)) if (
                    group_id is not None and z_id is not None) else None

                new_feat = QgsFeature(new_layer.fields())
                new_feat.setGeometry(feat.geometry())
                for field in selected_layer.fields():
                    new_feat[field.name()] = feat[field.name()]
                new_feat[field_name]        = g_out
                new_feat[zone_field_name]   = z_out
                new_feat[zone_name_field]   = vf_pon_name(z_out) if z_out is not None else None
                new_feat[local_field_name]  = local_out
                new_features.append(new_feat)

            if _ungrouped_count:
                self.log_message(
                    f"WARNING: {_ungrouped_count} features had no group assignment"
                )

            provider.addFeatures(new_features)
            new_layer.updateExtents()
            new_layer = self._add_output_layer(new_layer)

            self.grouped_layer = new_layer

            total_clusters = len(set(v for v in feature_to_group.values() if v is not None))
            total_zones    = len(set(v for v in feature_to_zone.values()  if v is not None)) if feature_to_zone else 0

            # Compute the true max output IDs (with offset applied) for the caller
            max_group_out = (max((v for v in feature_to_group.values() if v is not None), default=0)
                             + _group_offset)
            max_zone_out  = (max((v for v in feature_to_zone.values()  if v is not None), default=0)
                             + _zone_offset) if feature_to_zone else _zone_offset

            self.apply_batch_symbology(new_layer, zone_name_field)

            self.log_message(
                f"\nCreated {total_clusters} groups → {total_zones} zones "
                f"(max {zone_max_size} units/zone)"
            )
            if _zone_offset:
                self.log_message(f"  PON numbers: {_zone_offset + 1} – {max_zone_out}")
            self.log_message("\nPON clustering completed successfully!")
            self._elapsed("Total time")
            self.log_message(f"  New layer: '{new_layer.name()}'")

            # Expose the max IDs so _pon_per_pon_run can advance the offsets
            self._last_max_group = max_group_out
            self._last_max_zone  = max_zone_out
        except Exception as e:
            # Never let a clustering failure take the dock down — report it clearly with
            # a concrete next step, and keep the full traceback for debugging below.
            self.log_message(
                f"⛔ ERROR while clustering: {e!s}\n"
                "   Try: pick the ORIGINAL demand points layer, clear any active layer "
                "filter, and make sure a Distribution span layer is selected.")
            import traceback
            self.log_message(traceback.format_exc())

    def _apply_cluster_symbology(self, layer: QgsVectorLayer):
        """Apply categorized symbology to show different clusters in different colors.
        
        Args:
            layer: Layer with cluster_id field
        """
        try:
            from qgis.core import (
                QgsRendererCategory,
                QgsSymbol
            )
            from qgis.PyQt.QtGui import QColor
            import random
            
            field_name = 'cluster_id'
            field_idx = layer.fields().indexOf(field_name)
            
            if field_idx < 0:
                return
            
            # Get unique cluster values
            unique_values = set()
            for feature in layer.getFeatures():
                cluster_id = feature.attribute(field_name)
                if cluster_id is not None:
                    unique_values.add(cluster_id)
            
            # Create categories
            categories = []
            for cluster_id in sorted(unique_values):
                # Generate a color for each cluster
                random.seed(cluster_id)  # Consistent colors for same cluster
                color = QColor(
                    random.randint(100, 255),
                    random.randint(100, 255),
                    random.randint(100, 255),
                    200  # Some transparency
                )
                
                symbol = QgsSymbol.defaultSymbol(layer.geometryType())
                symbol.setColor(color)
                
                category = QgsRendererCategory(
                    cluster_id,
                    symbol,
                    f"Cluster {cluster_id}"
                )
                categories.append(category)
            
            # Create and set the renderer (Batch A: catch-all so null/unexpected
            # cluster_id never hides a feature or the whole layer)
            renderer = _categorized_with_catch_all(layer, field_name, categories)
            layer.setRenderer(renderer)
            layer.triggerRepaint()

        except Exception as e:
            # If symbology fails, just log it but don't fail the whole operation
            self.log_message(f"  (Could not apply cluster symbology: {e!s})")

    def on_show_batch_stats_clicked(self):
        """Show statistics about batch assignments."""
        erf_layer = self.comboBox_erf.currentLayer()
        
        if not erf_layer:
            self.log_message("ERROR: Please select an ERF layer.")
            return
        
        field_idx = erf_layer.fields().indexOf('batch_id')
        if field_idx < 0:
            self.log_message("ERROR: Layer has no 'batch_id' field. Please cluster ERF parcels first.")
            return
        
        self.log_message("\n=== Batch Statistics ===")
        self.log_message(f"Layer: '{erf_layer.name()}'")
        
        try:
            stats = get_batch_statistics(erf_layer)
            self._start_timer()
            if not stats:
                self.log_message("No batch data found.")
                return
            
            self.log_message(f"\nTotal batches: {stats['total_batches']}")
            self.log_message(f"Average batch size: {stats['avg_batch_size']:.1f}")
            
            # Show details for each batch
            self.log_message("\nBatch Details:")
            for batch_id in sorted(stats['batch_counts'].keys()):
                count = stats['batch_counts'][batch_id]
                extent = stats['batch_extents'].get(batch_id)
                
                if extent:
                    extent_str = f"({extent.xMinimum():.2f}, {extent.yMinimum():.2f}) to ({extent.xMaximum():.2f}, {extent.yMaximum():.2f})"
                else:
                    extent_str = "N/A"
                
                self.log_message(f"  Batch {batch_id}: {count} parcels")
                self.log_message(f"    Extent: {extent_str}")
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR getting batch statistics: {e!s}")

    # ------------------------------------------------------------------
    # PON boundary from an edit — a TILE, not a bubble.
    #
    # Measured on a live PON (2026-07-23): the buffer path below produces a
    # 985-vertex union of circles, against 40 for the tile Generate makes, and
    # it covers only 82% of the tile's area because a circle-union loses the
    # land between the houses. Tidying that up afterwards only gets to 362
    # vertices — still nine times a real tile. So the fix is to not build a
    # bubble at all: tile the coverage the same way Generate does.
    #
    # Every Manual Override edit goes through here, which is why the whole
    # "blobs instead of neat PONs" complaint traces back to this one function.
    # ------------------------------------------------------------------
    _TILE_CACHE_KEY = None
    _TILE_CACHE_VAL = None

    def _tile_zone_polygon(self, grouped_layer, zone_feats, zone_key=None):
        """A straight-edged tile for ``zone_feats``, or None to fall back.

        The tiler works on the WHOLE coverage, so the other PONs are read off
        the layer as they currently stand and the features being edited are
        placed in their own bucket. That way the new tile is shaped correctly
        against its real neighbours instead of being grown in isolation.

        Returns None on anything unexpected — the caller then uses the original
        buffer path, so this can only improve the result, never break it.
        """
        try:
            from qgis.core import QgsGeometry
            if not zone_feats:
                return None
            fld = vf_fields.resolve(grouped_layer, vf_fields.PON_NAME) \
                or vf_fields.resolve(grouped_layer, vf_fields.PON_NUM)
            if not fld:
                return None
            key = zone_key or "__EDITED__"
            moving = {f.id() for f in zone_feats}

            by_zone = {}
            for f in grouped_layer.getFeatures():
                if f.id() in moving:
                    continue                     # counted under the edited key
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                z = f[fld]
                if z is None or str(z).strip() == "":
                    continue
                by_zone.setdefault(str(z), []).append(f)
            by_zone[key] = list(zone_feats)
            if len(by_zone) < 2:
                return None                      # nothing to tile against

            # Re-tiling costs ~1.5-2 s on 5,000 homes and a single Manual
            # Override edit calls this up to three times. Cache on the exact
            # membership so those repeats are free; any real change misses.
            sig = (id(grouped_layer), fld,
                   tuple(sorted((z, len(v)) for z, v in by_zone.items())),
                   tuple(sorted(moving)))
            if type(self)._TILE_CACHE_KEY == sig:
                tiles = type(self)._TILE_CACHE_VAL
            else:
                tiles = self._voronoi_zone_polygons(grouped_layer, by_zone)
                type(self)._TILE_CACHE_KEY = sig
                type(self)._TILE_CACHE_VAL = tiles
            if not tiles:
                return None
            geom = tiles.get(key)
            if geom is None or geom.isEmpty() or not geom.isGeosValid():
                return None

            # Pull it in so it does not touch its neighbours — the 4 m corridor
            # measured off the Malmesbury reference design.
            try:
                from . import pon_merge as _pm
                pulled, ok = _pm.shrink(geom, grouped_layer)
                if ok:
                    geom = pulled
            except Exception:
                pass
            return geom if isinstance(geom, QgsGeometry) else None
        except Exception:
            return None

    def _build_zone_polygon(self, grouped_layer, zone_feats, zone_key=None):
        """Return a QgsGeometry zone polygon for a list of demand features.

        Prefers a straight-edged TILE (see _tile_zone_polygon). Falls back to
        the original buffer + morphological-closing algorithm only when tiling
        is not possible, so behaviour degrades to exactly what it was before
        rather than failing."""
        _tile = self._tile_zone_polygon(grouped_layer, zone_feats, zone_key)
        if _tile is not None and not _tile.isEmpty():
            return _tile
        # MO audit 2026-06-18: (a) GUARD null geometries — the project ships null-geom
        # features and `f.geometry().isEmpty()` on a None geometry crashed every
        # zone-affecting edit (apply_change / reassign / edit-splitter, none wrapped in
        # try/except). (b) NEVER convex-hull — a hull balloons the zone across the map
        # (the #63 failure); bridge multipart results with thin corridors via
        # _snap_parts_together, exactly like _rebuild_zone_boundary.
        from qgis.core import QgsGeometry, QgsUnitTypes
        is_point_layer = grouped_layer.geometryType() == 0
        geoms = [f.geometry() for f in zone_feats
                 if f.geometry() and not f.geometry().isEmpty()]
        if not geoms:
            return QgsGeometry()
        if is_point_layer:
            unit_type = grouped_layer.crs().mapUnits()
            if unit_type == QgsUnitTypes.DistanceUnit.DistanceDegrees:
                min_r, max_r = 0.00005, 0.00025
            else:
                min_r, max_r = 5.0, 30.0
            coords = [g.asPoint() for g in geoms]
            if len(coords) <= 1:
                radius = max_r
            else:
                nn_sum, nn_count = 0.0, 0
                for i, pt in enumerate(coords):
                    best = float('inf')
                    for j, other in enumerate(coords):
                        if i == j:
                            continue
                        d = ((pt.x() - other.x()) ** 2 +
                             (pt.y() - other.y()) ** 2) ** 0.5
                        if d < best:
                            best = d
                    if best < float('inf'):
                        nn_sum += best
                        nn_count += 1
                mean_nn = nn_sum / nn_count if nn_count else max_r
                radius = max(min(mean_nn * 0.55, max_r), min_r)
            zone_geom = geoms[0].buffer(radius, 8)
            for g in geoms[1:]:
                zone_geom = zone_geom.combine(g.buffer(radius, 8))
            gap_r = radius * 2.5
            zone_geom = zone_geom.buffer(gap_r, 6).buffer(-gap_r * 0.92, 6)
            if not zone_geom.isEmpty():
                if zone_geom.isMultipart():
                    zone_geom = self._snap_parts_together(zone_geom, radius)
                else:
                    poly = zone_geom.asPolygon()
                    if poly:
                        zone_geom = QgsGeometry.fromPolygonXY([poly[0]])
        else:
            merged = geoms[0]
            for g in geoms[1:]:
                merged = merged.combine(g)
            if merged.isMultipart():
                _bb = merged.boundingBox()
                _r = (max(_bb.width(), _bb.height()) * 0.02) or 1.0
                zone_geom = self._snap_parts_together(merged, _r)
            else:
                zone_geom = merged
        return zone_geom

    def _voronoi_zone_polygons(self, grouped_layer, features_by_zone):
        """③ Clean Voronoi-tiled zone boundaries (JJ 2026-06-25, approved option ③).

        The implementation moved to ``pon_tiles`` on 2026-07-27 so the Merge tool
        can produce the SAME straight-edged boundaries this path always has. It
        never used ``self``, so nothing changed but its address — and now there is
        exactly one copy, which is the point: two copies would drift.
        """
        from . import pon_tiles
        return pon_tiles.voronoi_zone_polygons(grouped_layer, features_by_zone)

    # ── Boundary-generation helpers (class-level so they aren't recreated ──
    # ── on every button click)                                            ──

    @staticmethod
    def _snap_parts_together(geom, bridge_r):
        """Connect all multipart fragments by bridging nearest-point pairs."""
        if not geom.isMultipart():
            return geom
        parts = list(geom.asGeometryCollection())
        while len(parts) > 1:
            min_d = float('inf')
            bi, bj = 0, 1
            bp1 = bp2 = None
            for ii in range(len(parts)):
                for jj in range(ii + 1, len(parts)):
                    d = parts[ii].distance(parts[jj])
                    if d < min_d:
                        min_d = d
                        bi, bj = ii, jj
                        bp1 = parts[ii].nearestPoint(parts[jj]).asPoint()
                        bp2 = parts[jj].nearestPoint(parts[ii]).asPoint()
            if bp1 is None or bp2 is None:
                break
            bridge = QgsGeometry.fromPolylineXY([
                QgsPointXY(bp1.x(), bp1.y()),
                QgsPointXY(bp2.x(), bp2.y()),
            ]).buffer(bridge_r, 4)
            merged_part = parts[bi].combine(parts[bj]).combine(bridge)
            parts = [parts[k] for k in range(len(parts)) if k != bi and k != bj]
            parts.append(merged_part)
        return parts[0] if parts else geom

    @staticmethod
    def _centroid_xy(pts):
        """Return (mean_x, mean_y) of a list of QgsPointXY."""
        if not pts:
            return (0, 0)
        return (sum(p.x() for p in pts) / len(pts),
                sum(p.y() for p in pts) / len(pts))

    @staticmethod
    def _force_single(geom, z_n, zone_build_params):
        """Rebuild a multipart geometry into one solid polygon."""
        if not geom.isMultipart():
            return geom
        zp = zone_build_params.get(z_n, {})
        radius_z = zp.get('radius', 5.0)
        result = FTTHPlanToolDockWidget._snap_parts_together(geom, radius_z)
        if not result.isMultipart():
            return result
        # NEVER convex-hull — a hull balloons the zone across the map (the #63 failure).
        # If parts still won't snap together, keep the largest single part instead.
        coll = result.asGeometryCollection()
        if coll:
            return max(coll, key=lambda g: g.area())
        return result

    @staticmethod
    def _make_combo_searchable(combo, max_visible=15):
        """Ticket #61: make a long splitter/group combo (a) type-to-search — the
        planner can type the splitter/group number instead of scrolling — and
        (b) show a real scrollbar in the drop-down popup. Safe on any QComboBox:
        the placeholder + index-based logic still work because we use NoInsert and
        a contains-filter completer, so picking a match still sets currentIndex."""
        from qgis.PyQt.QtWidgets import QComboBox, QCompleter
        from qgis.PyQt.QtCore import Qt
        try:
            combo.setEditable(True)
            combo.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
            combo.setMaxVisibleItems(max_visible)
            # combobox-popup:0 forces a scrollable QListView popup (with scrollbar)
            # instead of the native menu that only scrolls via edge arrows.
            combo.setStyleSheet(
                (combo.styleSheet() or "") + "\nQComboBox { combobox-popup: 0; }")
            comp = QCompleter(combo.model(), combo)
            comp.setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
            comp.setFilterMode(Qt.MatchFlag.MatchContains)
            comp.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
            combo.setCompleter(comp)
            _le = combo.lineEdit()
            if _le is not None:
                _le.setPlaceholderText("Type a number to search…")
            # Ticket #64 (CRITICAL): on an editable combo, picking a match from the
            # completer only sets the line-edit TEXT — currentIndex() stays stale, so
            # any handler that reads currentIndex()/currentData() (splitter delete,
            # add-demand) targets the WRONG row. Re-sync the index whenever the text
            # resolves to a real item, so currentIndex/currentData stay correct.
            def _sync_index(_txt=None):
                t = combo.currentText()
                i = combo.findText(t)
                if i >= 0 and i != combo.currentIndex():
                    combo.setCurrentIndex(i)
            comp.textActivated.connect(_sync_index)
            if _le is not None:
                _le.editingFinished.connect(_sync_index)
        except Exception:
            pass

    def _build_road_crossing_checker(self, demand_crs=None):
        """Return a callable _crosses_road(x1,y1,x2,y2)->bool using the current road layer.

        Returns a no-op function (always False) if no road layer is selected.
        Handles CRS mismatch between demand layer and road layer.
        """
        from qgis.core import QgsGeometry, QgsPointXY, QgsProject
        road_layer = self.comboBox_road_layer.currentLayer() if hasattr(self, 'comboBox_road_layer') else None
        if road_layer is None:
            return lambda x1, y1, x2, y2: False

        road_geom_by_id = {}
        road_index = QgsSpatialIndex()
        _road_transform = None
        try:
            road_crs = road_layer.crs()
            if demand_crs is not None and demand_crs.isValid() and road_crs.isValid() and demand_crs != road_crs:
                _road_transform = QgsCoordinateTransform(demand_crs, road_crs, QgsProject.instance())
            for rf in road_layer.getFeatures():
                rg = rf.geometry()
                if rg and not rg.isEmpty():
                    road_geom_by_id[rf.id()] = rg
                    road_index.addFeature(rf)
        except Exception:
            return lambda x1, y1, x2, y2: False

        def _crosses_road(x1, y1, x2, y2):
            if not road_geom_by_id:
                return False
            if _road_transform is not None:
                try:
                    p1 = _road_transform.transform(QgsPointXY(x1, y1))
                    p2 = _road_transform.transform(QgsPointXY(x2, y2))
                except Exception:
                    p1, p2 = QgsPointXY(x1, y1), QgsPointXY(x2, y2)
            else:
                p1, p2 = QgsPointXY(x1, y1), QgsPointXY(x2, y2)
            line = QgsGeometry.fromPolylineXY([p1, p2])
            bbox = line.boundingBox()
            bbox.grow(max(abs(p2.x() - p1.x()), abs(p2.y() - p1.y())) * 0.05 + 1e-9)
            for fid in road_index.intersects(bbox):
                rg = road_geom_by_id.get(fid)
                if rg and line.intersects(rg) and not line.touches(rg):
                    return True
            return False

        return _crosses_road

    # ---- Tickets #111/#112: persistent manual road-cross approvals --------------
    def _force_cross_key(self, layer):
        """(scope, key) under which a demand layer's manual road-cross approvals live."""
        import re as _re_fc
        lid = "none"
        try:
            if layer is not None:
                lid = _re_fc.sub(r'[^A-Za-z0-9_]', '_', layer.id())
        except Exception:
            lid = "none"
        return ("VelocityFibre", "NetworkPlanner/force_cross/" + lid)

    def _load_force_cross(self, layer):
        """Demand-point FIDs the planner manually approved to route across a road, read
        back from the project. Persisting this set (tickets #111/#112) is what makes a
        manual drop reassignment survive a dialog close / zone revisit / Regenerate
        Drops / project reload — otherwise every regen re-applies the road barrier and
        the planner's manually-routed drops are skipped and silently deleted."""
        from qgis.core import QgsProject
        if layer is None:
            return set()
        try:
            scope, key = self._force_cross_key(layer)
            raw, ok = QgsProject.instance().readEntry(scope, key, "")
            if ok and raw:
                out = set()
                for tok in raw.split(","):
                    try:
                        out.add(int(tok.strip()))
                    except (TypeError, ValueError):
                        continue
                return out
        except Exception:
            pass
        return set()

    def _save_force_cross(self, layer, fids):
        """Persist the manual road-cross approval set on the project (see _load_force_cross).
        Monotonic: only ever adds, never clears, so a stray empty call can't wipe approvals."""
        from qgis.core import QgsProject
        if layer is None or not fids:
            return
        try:
            scope, key = self._force_cross_key(layer)
            QgsProject.instance().writeEntry(
                scope, key, ",".join(str(int(x)) for x in sorted(fids)))
        except Exception:
            pass

    # ---- Ticket #113: "show all drops" — draw every drop even across a road --------
    def _show_all_drops(self):
        """True when the planner chose to draw EVERY drop, ignoring the road barrier
        (ticket #113 — Luke wanted visual proof of all connections). Persisted on the
        project so it survives reload. OFF by default so the road barrier still applies
        for planners (e.g. Rico, #68) who rely on road-crossing drops being skipped."""
        from qgis.core import QgsProject
        try:
            raw, ok = QgsProject.instance().readEntry("VelocityFibre", "NetworkPlanner/show_all_drops", "0")
            return bool(ok and str(raw).strip() in ("1", "true", "True"))
        except Exception:
            return False

    def _set_show_all_drops(self, on):
        from qgis.core import QgsProject
        try:
            QgsProject.instance().writeEntry(
                "VelocityFibre", "NetworkPlanner/show_all_drops", "1" if on else "0")
        except Exception:
            pass

    # ================================================================
    def on_manual_override_final_clicked(self):
        """Open layer-picker then launch Manual Override on any existing saved layers.

        Works independently of whether a PON per PON session was ever run.
        The user selects which project layers represent splitters, demand points,
        zone boundaries and drop cables, then the full Manual Override dialog opens
        pointed at those layers.
        """
        from qgis.PyQt.QtWidgets import (
            QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
            QComboBox, QFrame, QFormLayout, QMessageBox)
        from qgis.PyQt.QtCore import Qt
        from qgis.core import QgsProject, QgsVectorLayer

        proj_layers = {
            lyr.name(): lyr
            for lyr in QgsProject.instance().mapLayers().values()
            if isinstance(lyr, QgsVectorLayer)
        }
        if not proj_layers:
            QMessageBox.warning(self, "No Layers", "No vector layers found in the current project.")
            return

        # ── Auto-detect layers by name patterns ──────────────────────────
        def _best(patterns, geom_type=None):
            """Return the best-matching layer name, or '' if none found."""
            for lyr_name, lyr in proj_layers.items():
                n = lyr_name.lower()
                if geom_type is not None and lyr.geometryType() != geom_type:
                    continue
                if any(p in n for p in patterns):
                    return lyr_name
            return ''

        def_splitters = _best(['splitter'], geom_type=0)
        # Prefer a splitter layer that actually carries group_id+zone_id — a project can
        # have several 'splitter' layers and only the planner's has the fields (JJ 2026-06-25).
        for _sn, _sl in proj_layers.items():
            if _sl.geometryType() == 0 and 'splitter' in _sn.lower():
                _sfn = [f.name() for f in _sl.fields()]
                if 'group_id' in _sfn and 'zone_id' in _sfn:
                    def_splitters = _sn
                    break
        def_demand    = _best(['demand', 'groups of'], geom_type=0)
        # Prefer a demand layer that actually carries a group-link field (group_<N>/
        # batch_id). The planner's PON output ('PON Groups') has it; the raw imported
        # 'Demand Points' does not — and auto-detect used to grab 'Demand Points', so
        # zone/group reassignment silently no-op'd (the "Layers may not be ready" warning).
        for _dn, _dl in proj_layers.items():
            if _dl.geometryType() == 0 and any(
                    p in _dn.lower() for p in ('demand', 'group', 'pon')):
                if _demand_group_field([f.name() for f in _dl.fields()]):
                    def_demand = _dn
                    break
        def_zones     = _best(['zone', 'boundar'], geom_type=2)
        def_drops     = _best(['drop', 'cable'], geom_type=1)

        # ── Layer-picker dialog ───────────────────────────────────────────
        picker = QDialog(self)
        picker.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        picker.setWindowTitle("Manual Override — Select Layers")
        picker.setMinimumWidth(480)
        picker.setModal(True)
        picker.setWindowFlags(picker.windowFlags() | Qt.WindowType.WindowStaysOnTopHint)
        pl = QVBoxLayout(picker)
        pl.setSpacing(8)

        info = QLabel(
            "<b>Select the layers to edit.</b><br>"
            "Splitters and Demand Points are required.<br>"
            "PON Boundaries and Drop Cables are optional but enable PON updates and drop regeneration."
        )
        info.setWordWrap(True)
        pl.addWidget(info)

        sep = QFrame(); sep.setFrameShape(QFrame.Shape.HLine); sep.setFrameShadow(QFrame.Shadow.Sunken)
        pl.addWidget(sep)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)

        def _combo(default_name, geom_type=None):
            cb = QComboBox()
            filtered = [''] + [n for n, lyr in proj_layers.items()
                               if geom_type is None or lyr.geometryType() == geom_type]
            cb.addItems(filtered)
            if default_name in filtered:
                cb.setCurrentText(default_name)
            return cb

        # Recall the planner's last Manual Override Final layer choice so re-opening
        # the picker keeps the chosen working set (ticket #73 — "layers chosen before
        # starting the edits"). Falls back to name auto-detect when unset/stale.
        from qgis.core import QgsSettings as _QSet
        _ovset = _QSet()

        def _recall(key, auto):
            v = _ovset.value(f"VelocityFibre/override_final/{key}", "") or ""
            return v if v in proj_layers else auto

        cb_sp  = _combo(_recall('splitters', def_splitters), geom_type=0)
        cb_dem = _combo(_recall('demand',    def_demand),    geom_type=0)
        cb_zon = _combo(_recall('zones',     def_zones),     geom_type=2)
        cb_drp = _combo(_recall('drops',     def_drops),     geom_type=1)

        form.addRow("🔴 Splitters layer (required):", cb_sp)
        form.addRow("🔵 Demand Points layer (required):", cb_dem)
        form.addRow("🟩 PON Boundaries layer (optional):", cb_zon)
        form.addRow("⬛ Drop Cables layer (optional):", cb_drp)
        pl.addLayout(form)

        btns = QHBoxLayout()
        btn_ok     = QPushButton("Open Manual Override")
        btn_cancel = QPushButton("Cancel")
        btn_ok.setStyleSheet(
            "QPushButton { background-color: #1a3a5c; color: white; font-weight: bold; "
            "border-radius: 3px; padding: 4px 12px; }")
        btns.addStretch()
        btns.addWidget(btn_cancel)
        btns.addWidget(btn_ok)
        pl.addLayout(btns)

        btn_cancel.clicked.connect(picker.reject)
        # #101/#102 class (audit): picker is WA_DeleteOnClose, so reading the combos
        # AFTER picker.exec() can crash ("QComboBox has been deleted"). Capture the
        # chosen layer names up-front in the accept handler, while the widgets are alive.
        _pick_vals = {}

        def _picker_accept():
            try:
                _pick_vals['sp'] = cb_sp.currentText()
                _pick_vals['dem'] = cb_dem.currentText()
                _pick_vals['zon'] = cb_zon.currentText()
                _pick_vals['drp'] = cb_drp.currentText()
            except RuntimeError:
                pass
            picker.accept()

        btn_ok.clicked.connect(_picker_accept)

        if picker.exec() != QDialog.DialogCode.Accepted:
            return

        # ── Validate ─────────────────────────────────────────────────────
        sp_name  = _pick_vals.get('sp', '')
        dem_name = _pick_vals.get('dem', '')
        zon_name = _pick_vals.get('zon', '')
        drp_name = _pick_vals.get('drp', '')

        if not sp_name:
            QMessageBox.warning(self, "Missing Layer", "Please select a Splitters layer.")
            return
        if not dem_name:
            QMessageBox.warning(self, "Missing Layer", "Please select a Demand Points layer.")
            return

        # ── Verify the chosen layers carry the fields the Manual Override +
        # PON-per-PON features need (ticket #73/#67). Without group_id/zone_id on
        # splitters or a group-link field on demand, zone/group reassignment silently
        # does nothing — the exact "only works after re-running PON-per-PON" failure.
        # Warn with specifics but let the planner proceed (some flows are geometry-only).
        _sp_fields  = [f.name() for f in proj_layers[sp_name].fields()]
        _dem_fields = [f.name() for f in proj_layers[dem_name].fields()]
        _grp_link = _demand_group_field(_dem_fields)  # #79: pattern, not fixed sizes
        _missing = []
        if 'group_id' not in _sp_fields or 'zone_id' not in _sp_fields:
            _missing.append(f"• Splitters '{sp_name}' is missing group_id / zone_id")
        if not _grp_link:
            _missing.append(f"• Demand '{dem_name}' has no group link field (group_8/16/128/100)")
        if _missing:
            if QMessageBox.question(
                self, "Layers may not be ready",
                "These features need fields that aren't present on the chosen layers:\n\n"
                + "\n".join(_missing)
                + "\n\nZone / group reassignment may not apply. Continue anyway?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            ) != QMessageBox.StandardButton.Yes:
                return

        # Remember this working set for next time.
        for _k, _v in (('splitters', sp_name), ('demand', dem_name),
                       ('zones', zon_name), ('drops', drp_name)):
            _ovset.setValue(f"VelocityFibre/override_final/{_k}", _v)

        # ── Wire accumulators to selected layers ─────────────────────────
        self._pon_accum_splitters = proj_layers[sp_name]
        self._pon_accum_groups    = proj_layers[dem_name]
        self._pon_accum_zones     = proj_layers[zon_name]  if zon_name else None
        self._pon_accum_drops     = proj_layers[drp_name]  if drp_name else None
        # MO audit: record an EXPLICIT skip when the planner left a layer blank, so the
        # engine honors "leave this layer alone" instead of re-resolving a stale or
        # name-matched layer. Consumed (reset) by on_manual_override_clicked.
        self._mo_final_skip_zones = (not zon_name)
        self._mo_final_skip_drops = (not drp_name)

        # Prevent _pon_per_pon_run from nulling these on next run
        self._pon_new_session_needed = False

        # Also mirror to the standard single-run layer refs used by drop regen
        self.splitter_points_layer = self._pon_accum_splitters
        self.demand_points_layer   = self._pon_accum_groups
        if self._pon_accum_zones:
            self.zone_boundaries_layer = self._pon_accum_zones
        if self._pon_accum_drops:
            self.drop_ptp_layer = self._pon_accum_drops

        self.log_message(
            f"[Manual Override] Layers linked — "
            f"Splitters: '{sp_name}', Demand: '{dem_name}', "
            f"PONs: '{zon_name or 'none'}', Drops: '{drp_name or 'none'}'"
        )

        # ── Open the standard Manual Override dialog ──────────────────────
        self.on_manual_override_clicked()

    def on_create_span_clicked(self):
        """Open span type chooser, then let user draw lines on the map."""
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                          QPushButton)
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY, QgsField, QgsProject, QgsLineSymbol, QgsSingleSymbolRenderer)
        from qgis.PyQt.QtCore import QMetaType
        from qgis.PyQt.QtGui import QColor

        # If button is unchecked, cancel any active drawing
        if not self._btn_create_span.isChecked():
            if self._create_span_tool:
                self.iface.mapCanvas().unsetMapTool(self._create_span_tool)
                self._create_span_tool = None
            self._create_span_type = None
            self.log_message("Create Span: drawing cancelled.")
            return

        # ── Step 1: Ask user what type of span ─────────────────────────────
        dlg = QDialog(self.iface.mainWindow())
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)   # don't leak hidden windows
        dlg.setWindowTitle("Create Span — Select Type")
        dlg.setMinimumWidth(340)
        layout = QVBoxLayout(dlg)

        lbl = QLabel("Select the span cable type to draw on the map:")
        lbl.setWordWrap(True)
        layout.addWidget(lbl)

        # Create buttons for each span type
        btn_feeder = QPushButton("🔴  Feeder")
        btn_feeder.setStyleSheet(
            "QPushButton { background-color: #8B0000; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #B22222; }"
        )
        
        btn_second = QPushButton("🟣  Second Feeder")
        btn_second.setStyleSheet(
            "QPushButton { background-color: #8B008B; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #BA55D3; }"
        )
        
        btn_third = QPushButton("🔵  Third Feeder")
        btn_third.setStyleSheet(
            "QPushButton { background-color: #00008B; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #0000FF; }"
        )
        
        btn_dist1 = QPushButton("🟢  Distribution 1")
        btn_dist1.setStyleSheet(
            "QPushButton { background-color: #008000; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #00FF00; color: #111; }"
        )

        btn_dist2 = QPushButton("🔷  Distribution 2")
        btn_dist2.setStyleSheet(
            "QPushButton { background-color: #008080; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #00FFFF; color: #111; }"
        )

        btn_dist3 = QPushButton("🟡  Distribution 3")
        btn_dist3.setStyleSheet(
            "QPushButton { background-color: #808000; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #FFFF00; color: #111; }"
        )
        
        btn_cancel = QPushButton("Cancel")

        layout.addWidget(btn_feeder)
        layout.addWidget(btn_second)
        layout.addWidget(btn_third)
        layout.addWidget(btn_dist1)
        layout.addWidget(btn_dist2)
        layout.addWidget(btn_dist3)
        layout.addSpacing(6)
        layout.addWidget(btn_cancel)

        chosen_type = [None]

        def _pick(span_type):
            chosen_type[0] = span_type
            dlg.accept()

        btn_feeder.clicked.connect(lambda: _pick('Feeder'))
        btn_second.clicked.connect(lambda: _pick('Second Feeder'))
        btn_third.clicked.connect(lambda: _pick('Third Feeder'))
        btn_dist1.clicked.connect(lambda: _pick('Distribution 1'))
        btn_dist2.clicked.connect(lambda: _pick('Distribution 2'))
        btn_dist3.clicked.connect(lambda: _pick('Distribution 3'))
        btn_cancel.clicked.connect(dlg.reject)

        if dlg.exec() != QDialog.DialogCode.Accepted or not chosen_type[0]:
            self._btn_create_span.setChecked(False)
            return

        span_type = chosen_type[0]
        self._create_span_type = span_type
        self.log_message(f"Create Span: type={span_type} — click on the map to draw vertices. Right-click to finish.")

        # ── Step 2: Activate map tool ────────────────────────────────────────
        canvas = self.iface.mapCanvas()
        crs = canvas.mapSettings().destinationCrs().authid()
        layer_name = f"Manual Spans ({span_type})"

        # Span type colors and cable type
        span_colors = {
            'Feeder': ('#FF0000', 'Feeder'),
            'Second Feeder': ('#FF00FF', 'Second Feeder'),
            'Third Feeder': ('#0000FF', 'Third Feeder'),
            'Distribution 1': ('#00FF00', 'Distribution'),
            'Distribution 2': ('#00FFFF', 'Distribution'),
            'Distribution 3': ('#FFFF00', 'Distribution'),
        }
        color_hex, cable_type = span_colors.get(span_type, ('#000000', 'Unknown'))

        # Get or create the span layer for this type
        span_layer = None
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name() == layer_name:
                span_layer = lyr
                break

        if span_layer is None:
            span_layer = QgsVectorLayer(f"LineString?crs={crs}", layer_name, "memory")
            provider = span_layer.dataProvider()
            provider.addAttributes([
                QgsField('span_id', QMetaType.Type.Int),
                QgsField('span_name', QMetaType.Type.QString),
                QgsField('span_type', QMetaType.Type.QString),
                QgsField('Cable Type', QMetaType.Type.QString),
                QgsField('length_m', QMetaType.Type.Double),  # Length in meters
            ])
            span_layer.updateFields()

            # Convert hex color to RGB
            r = int(color_hex[1:3], 16)
            g = int(color_hex[3:5], 16)
            b = int(color_hex[5:7], 16)

            symbol = QgsLineSymbol.createSimple({
                'line_color': f'{r},{g},{b}',
                'line_width': '1.86',
                'line_width_unit': 'mm',
                'line_style': 'solid',
            })
            span_layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            QgsProject.instance().addMapLayer(span_layer)
            self.log_message(f"  Created new layer: '{layer_name}'")

        # Ensure length_m field exists on any pre-existing layer
        if span_layer.fields().indexOf('length_m') < 0:
            span_layer.dataProvider().addAttributes([QgsField('length_m', QMetaType.Type.Double)])
            span_layer.updateFields()

        # Track next ID and current line vertices
        existing_ids = [f['span_id'] for f in span_layer.getFeatures() if f['span_id']]
        next_id = [max(existing_ids) + 1 if existing_ids else 1]
        vertices = [[]]  # list of vertex lists per line being drawn

        # ── Create rubber band for preview line trace ────────────────────────
        from qgis.gui import QgsRubberBand
        from qgis.core import QgsWkbTypes
        rubber_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.LineGeometry)
        # Convert hex color to bright RGB for visibility
        r = int(color_hex[1:3], 16)
        g = int(color_hex[3:5], 16)
        b = int(color_hex[5:7], 16)
        # Boost saturation for preview visibility
        preview_color = QColor(r, g, b, 200)  # 200 alpha for semi-transparency
        rubber_band.setColor(preview_color)
        rubber_band.setWidth(3)  # Thicker for visibility during drawing

        # Map click tool
        map_tool = QgsMapToolEmitPoint(canvas)

        def _on_map_click(point, button):
            from qgis.PyQt.QtCore import Qt as _Qt
            if button == _Qt.MouseButton.RightButton:   # Qt6: fully-scoped enum (#110)
                # Right-click to finish current line
                if vertices[-1]:
                    line_pts = [QgsPointXY(v.x(), v.y()) for v in vertices[-1]]
                    geom = QgsGeometry.fromPolylineXY(line_pts)
                    
                    # Calculate length in meters using QgsDistanceArea (handles geographic/projected CRS)
                    from qgis.core import QgsDistanceArea
                    da = QgsDistanceArea()
                    da.setSourceCrs(span_layer.crs(), QgsProject.instance().transformContext())
                    da.setEllipsoid(_safe_ellipsoid(QgsProject.instance(), span_layer.crs()))
                    line_length = round(da.measureLength(geom), 2)  # Meters, 2 decimal places
                    
                    feat = QgsFeature(span_layer.fields())
                    feat.setGeometry(geom)
                    span_name = f"{span_type.replace(' ', '_')}_{next_id[0]:03d}"
                    feat.setAttributes([next_id[0], span_name, span_type, cable_type, line_length])
                    span_layer.dataProvider().addFeatures([feat])
                    span_layer.updateExtents()
                    span_layer.triggerRepaint()
                    self.log_message(f"  Completed: {span_name} ({len(vertices[-1])} vertices, {line_length:.2f} m)")
                    next_id[0] += 1
                    vertices.append([])  # start fresh for next line
                    
                    # Clear rubber band for next line
                    rubber_band.reset(QgsWkbTypes.GeometryType.LineGeometry)
                else:
                    # No vertices on current line — just finish
                    rubber_band.reset()
                    canvas.unsetMapTool(map_tool)
                    self._btn_create_span.setChecked(False)
                    self._create_span_tool = None
                    self.log_message(f"Create Span: drawing finished. {next_id[0]-1} span(s) created.")
                    return
            else:
                # Left-click: add vertex (honour QGIS native snapping so span vertices
                # land on cables/poles/vertices when snapping is on — JJ).
                point = snap_point_to_project(canvas, point)
                vertices[-1].append(QgsPointXY(point.x(), point.y()))

                # Update rubber band with new point
                rubber_band.addPoint(QgsPointXY(point.x(), point.y()))

                self.log_message(f"  Vertex added: ({point.x():.2f}, {point.y():.2f})")

        map_tool.canvasClicked.connect(_on_map_click)
        self._create_span_tool = map_tool
        canvas.setMapTool(map_tool)
        self.log_message("  Click on the map to add vertices. Right-click to finish the current line.")

    def on_generate_aggregation_points_clicked(self):
        """Generate Enclosure points where 2+ Feeder/Second/Third Feeder cables converge (at any point, including mid-path)."""
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject, QgsField,
                                QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                                QgsVectorLayerSimpleLabeling)
        from qgis.PyQt.QtCore import QMetaType
        from qgis.PyQt.QtGui import QColor, QFont

        # ── 1. Get the Span layer ──────────────────────────────────────────────
        span_layer = self.comboBox_span_layer.currentLayer()
        if span_layer is None:
            self.log_message("ERROR: Please select a Span (Route) layer first.")
            return

        if span_layer.geometryType() != 1:   # 1 = Line
            self.log_message(f"ERROR: '{span_layer.name()}' is not a line layer.")
            return

        self.log_message("\n=== Generating Feeder Enclosure Points ===")
        self.log_message(f"Source layer: '{span_layer.name()}'")
        self.log_message(f"Feature count: {span_layer.featureCount()}")

        # ── 2. Identify feeder-class cables ────────────────────────────────────
        _span_field_names = [f.name() for f in span_layer.fields()]
        has_cable_type = 'Cable Type' in _span_field_names
        _has_name = 'Name' in _span_field_names   # hoisted: was rebuilt per feature
        feeder_cables = []

        for feat in span_layer.getFeatures():
            geom = feat.geometry()
            if geom is None or geom.isEmpty():
                continue

            # Filter to feeder-class cables
            cable_type_str = ''
            if has_cable_type:
                cable_type_str = str(feat['Cable Type'] or '').strip().lower()

            cable_lower = str(feat['Name'] or '').lower() if _has_name else ''
            is_feeder_class = (
                ('feeder' in cable_lower or 'second' in cable_lower or 'third' in cable_lower)
                and 'distribution' not in cable_lower
            ) or cable_type_str in ['feeder', 'second feeder', 'third feeder']

            if is_feeder_class:
                feat_id = feat.id()
                feeder_cables.append((feat_id, geom, feat))

        if not feeder_cables:
            self.log_message("⚠ No Feeder-class cables found.")
            return

        self.log_message(f"Found {len(feeder_cables)} feeder-class cables")

        # ── 3. Collect convergence points: Method 1 (vertex-based) ─────────────
        processed_locations = set()
        convergence_points = {}  # {rounded_key: {"count": N, "geoms": [list], "exact_pts": [list]}}

        for feat_id, geom, feat in feeder_cables:
            # Collect all vertices along the cable
            all_points = []
            if geom.wkbType() in [2, 1002]:  # LineString
                pts = geom.asPolyline()
            elif geom.wkbType() in [5, 1005]:  # MultiLineString
                pts = []
                for part in geom.asMultiPolyline():
                    pts.extend(part)
            else:
                continue

            for pt in pts:
                # Round for deduplication
                key = (round(pt.x(), 2), round(pt.y(), 2))
                if key not in processed_locations:
                    all_points.append((key, pt))
                    processed_locations.add(key)

            # Collect all unique points for this cable
            for rounded_key, exact_pt in all_points:
                if rounded_key not in convergence_points:
                    convergence_points[rounded_key] = {"count": 0, "geoms": [], "exact_pts": []}
                convergence_points[rounded_key]["count"] += 1
                convergence_points[rounded_key]["geoms"].append(feat_id)
                convergence_points[rounded_key]["exact_pts"].append(exact_pt)

        # ── 4. Method 2: Geometry intersection detection ────────────────────────
        for i, (feat_id_1, geom_1, _) in enumerate(feeder_cables):
            for feat_id_2, geom_2, _ in feeder_cables[i+1:]:
                if geom_1.intersects(geom_2):
                    # Use centroid as intersection point
                    int_geom = geom_1.intersection(geom_2)
                    if int_geom and not int_geom.isEmpty():
                        if int_geom.type() == 0:  # Point geometry
                            # Two cables can intersect at MULTIPLE points → MultiPoint;
                            # .asPoint() raises on a multipart, so take the first part.
                            pt = (int_geom.asMultiPoint()[0] if int_geom.isMultipart()
                                  else int_geom.asPoint())
                        elif int_geom.type() == 1:  # Line
                            pt = int_geom.centroid().asPoint()
                        else:
                            continue

                        key = (round(pt.x(), 2), round(pt.y(), 2))
                        if key not in processed_locations:
                            if key not in convergence_points:
                                convergence_points[key] = {"count": 0, "geoms": [], "exact_pts": []}
                            convergence_points[key]["count"] += 1
                            convergence_points[key]["geoms"].extend([feat_id_1, feat_id_2])
                            convergence_points[key]["exact_pts"].append(pt)
                            processed_locations.add(key)

        # ── 5. Filter: only points where 2+ cables meet ─────────────────────────
        enclosure_locations = {}
        for rounded_key, data in convergence_points.items():
            if len(set(data["geoms"])) >= 2:  # At least 2 distinct cables
                # Use the first exact point (they're all very close)
                exact_pt = data["exact_pts"][0]
                enclosure_locations[rounded_key] = exact_pt

        if not enclosure_locations:
            self.log_message("⚠ No convergence points found.")
            return

        self.log_message(f"Found {len(enclosure_locations)} convergence points")

        # ── 6. Create or find Enclosure layer ──────────────────────────────────
        enclosure_layer_name = "Feeder Enclosures"
        enclosure_layer = None

        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name() == enclosure_layer_name:
                enclosure_layer = lyr
                break

        if enclosure_layer is None:
            crs = span_layer.crs().authid()
            enclosure_layer = QgsVectorLayer(f"Point?crs={crs}", enclosure_layer_name, "memory")
            provider = enclosure_layer.dataProvider()
            provider.addAttributes([
                QgsField('enclosure_id', QMetaType.Type.Int),
                QgsField('enclosure_name', QMetaType.Type.QString),
                QgsField('converging_cables', QMetaType.Type.Int),
            ])
            enclosure_layer.updateFields()

            # Apply symbology - cyan/teal squares
            symbol = QgsMarkerSymbol.createSimple({
                'name': 'square',
                'color': '0,200,200,255',
                'outline_color': '0,0,0,255',
                'outline_width': '0.5',
                'size': '5',
            })
            enclosure_layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            # Labels
            lbl_settings = QgsPalLayerSettings()
            lbl_settings.fieldName = 'enclosure_name'
            lbl_settings.enabled = True
            fmt = QgsTextFormat()
            fmt.setFont(QFont("Arial", 7))
            fmt.setColor(QColor(0, 0, 0))
            buf = QgsTextBufferSettings()
            buf.setEnabled(True)
            buf.setSize(1.0)
            buf.setColor(QColor(255, 255, 255))
            fmt.setBuffer(buf)
            lbl_settings.setFormat(fmt)
            enclosure_layer.setLabeling(QgsVectorLayerSimpleLabeling(lbl_settings))
            enclosure_layer.setLabelsEnabled(True)

            QgsProject.instance().addMapLayer(enclosure_layer)
            self.log_message(f"  Created layer: '{enclosure_layer_name}'")

        # ── 7. Add features ────────────────────────────────────────────────────
        existing_ids = [f['enclosure_id'] for f in enclosure_layer.getFeatures() if f['enclosure_id']]
        next_id = max(existing_ids) + 1 if existing_ids else 1

        provider = enclosure_layer.dataProvider()
        features = []

        for rounded_key, exact_pt in enclosure_locations.items():
            feat = QgsFeature(enclosure_layer.fields())
            feat.setGeometry(QgsGeometry.fromPointXY(exact_pt))
            feat.setAttributes([
                next_id,
                f"Encl_{next_id:03d}",
                convergence_points[rounded_key]["count"],
            ])
            features.append(feat)
            next_id += 1

        provider.addFeatures(features)
        enclosure_layer.updateExtents()
        enclosure_layer.triggerRepaint()

        self.log_message(f"✓ Created {len(features)} enclosure point(s)")
        return   # ── canonical implementation ends here ──
        # Everything below to the end of this method (the old `agg_*`/`feeder_count`
        # block) is a SUPERSEDED DUPLICATE left by a refactor. It used to run a SECOND
        # time right after the block above (no return), creating duplicate enclosures.
        # Now unreachable. Slated for physical deletion (manifest 3a-bis).
        # ---------------------------------------------------------------------------


    def on_sum_span_distance_clicked(self):
        """Calculate total length of the selected Span layer and show a persistent result dialog."""
        from qgis.core import QgsUnitTypes
        from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton
        from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
        from qgis.PyQt.QtGui import QFont

        span_layer = self.comboBox_span_layer.currentLayer()
        if span_layer is None:
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.warning(None, "No Span Layer",
                                "Please select a Span (Route) layer first.")
            return

        if span_layer.geometryType() != 1:   # 1 = Line
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.warning(None, "Wrong Layer Type",
                                f"'{span_layer.name()}' is not a line layer.")
            return

        layer_name = span_layer.name()
        feature_count = span_layer.featureCount()

        # ── Worker thread ────────────────────────────────────────────────────
        class _Worker(QThread):
            finished = pyqtSignal(float, int)   # total_m, feature_count
            error    = pyqtSignal(str)

            def __init__(self, geoms, crs, tctx, ellipsoid):
                super().__init__()
                self._geoms = geoms        # pre-extracted on the main thread
                self._crs = crs
                self._tctx = tctx
                self._ellipsoid = ellipsoid

            def run(self):
                try:
                    da = QgsDistanceArea()
                    da.setSourceCrs(self._crs, self._tctx)
                    da.setEllipsoid(self._ellipsoid)
                    total = 0.0
                    count = 0
                    for geom in self._geoms:
                        total += da.measureLength(geom)
                        count += 1
                    # Convert to metres
                    total_m = da.convertLengthMeasurement(
                        total, QgsUnitTypes.DistanceUnit.DistanceMeters)
                    self.finished.emit(total_m, count)
                except Exception as exc:
                    self.error.emit(str(exc))

        # ── Progress / waiting dialog (non-blocking) ─────────────────────────
        wait_dlg = QDialog(None)
        wait_dlg.setWindowTitle("Calculating…")
        wait_dlg.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint | Qt.WindowType.CustomizeWindowHint)
        wait_dlg.setFixedWidth(300)
        wait_lay = QVBoxLayout(wait_dlg)
        wait_lbl = QLabel(
            f"<b>Summing span distances…</b><br>"
            f"Layer: <i>{layer_name}</i><br>"
            f"{feature_count} features")
        wait_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wait_lay.addWidget(wait_lbl)
        wait_dlg.show()
        QApplication.processEvents()

        # ── Result dialog builder ─────────────────────────────────────────────
        def _show_result(total_m, counted):
            from qgis.PyQt import sip as _sipw
            wait_dlg.close()   # always dismiss the orphan, even if the dock is gone
            if _sipw.isdeleted(self):
                return   # dock closed while the worker ran — don't touch dead widgets

            from qgis.PyQt.QtWidgets import (QFrame, QHBoxLayout, QDoubleSpinBox,
                                             QLabel as _QL)

            res_dlg = QDialog(None)
            res_dlg.setWindowTitle("Span Layer — Total Distance")
            res_dlg.setWindowFlags(
                Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
            res_dlg.setMinimumWidth(380)
            res_lay = QVBoxLayout(res_dlg)
            res_lay.setSpacing(10)
            res_lay.setContentsMargins(18, 18, 18, 18)

            title_lbl = QLabel("📏  Span Layer — Total Distance")
            title_fnt = QFont()
            title_fnt.setBold(True)
            title_fnt.setPointSize(11)
            title_lbl.setFont(title_fnt)
            title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            res_lay.addWidget(title_lbl)

            # ── Base distance display ─────────────────────────────────────
            km = total_m / 1000.0
            base_lbl = QLabel(
                f"<table cellspacing='6'>"
                f"<tr><td><b>Layer:</b></td><td>{layer_name}</td></tr>"
                f"<tr><td><b>Features measured:</b></td><td>{counted:,}</td></tr>"
                f"<tr><td><b>Raw total distance:</b></td>"
                f"<td><span style='font-size:12pt; color:#555;'>"
                f"<b>{total_m:,.1f} m</b></span></td></tr>"
                f"<tr><td></td>"
                f"<td><span style='font-size:9pt; color:#888;'>"
                f"({km:,.3f} km)</span></td></tr>"
                f"</table>")
            base_lbl.setAlignment(Qt.AlignmentFlag.AlignLeft)
            res_lay.addWidget(base_lbl)

            # ── Divider ───────────────────────────────────────────────────
            div = QFrame()
            div.setFrameShape(QFrame.Shape.HLine)
            div.setStyleSheet("color: #ccc;")  # dual-theme-ok: dark #0e2233 panel / decorative divider
            res_lay.addWidget(div)

            # ── Slack / Sag % row ─────────────────────────────────────────
            pct_row = QHBoxLayout()
            pct_lbl = _QL("Slack & Sag allowance:")
            pct_lbl.setToolTip(
                "Extra cable percentage added for slack, sag, splices and\n"
                "vertical drops on HLD cable quantity estimations.")
            pct_spin = QDoubleSpinBox()
            pct_spin.setRange(0.0, 100.0)
            pct_spin.setDecimals(1)
            pct_spin.setSingleStep(0.5)
            pct_spin.setSuffix(" %")
            pct_spin.setValue(22.0)
            pct_spin.setFixedWidth(90)
            pct_spin.setToolTip("Default 22 % — edit as required")
            pct_row.addWidget(pct_lbl)
            pct_row.addStretch()
            pct_row.addWidget(pct_spin)
            res_lay.addLayout(pct_row)

            # ── Adjusted distance display (updates live) ──────────────────
            adj_lbl = QLabel()
            adj_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            adj_lbl.setStyleSheet(
                "background: #eaf4ea; border: 1px solid #a8d5a8; "
                "border-radius: 5px; padding: 8px;")
            res_lay.addWidget(adj_lbl)

            def _update_adjusted():
                pct = pct_spin.value()
                adj_m  = total_m * (1.0 + pct / 100.0)
                adj_km = adj_m / 1000.0
                extra_m = adj_m - total_m
                adj_lbl.setText(
                    f"<div style='text-align:center;'>"
                    f"<span style='font-size:9pt; color:#555;'>Adjusted total (+{pct:.1f}%)</span><br>"
                    f"<span style='font-size:14pt; color:#1a6b3c; font-weight:bold;'>"
                    f"{adj_m:,.1f} m</span>"
                    f"<span style='font-size:9pt; color:#555;'>  ({adj_km:,.3f} km)</span><br>"
                    f"<span style='font-size:8pt; color:#888;'>"
                    f"+{extra_m:,.1f} m slack/sag allowance</span>"
                    f"</div>")

            pct_spin.valueChanged.connect(_update_adjusted)
            _update_adjusted()   # populate on open

            # ── Close button ──────────────────────────────────────────────
            close_btn = QPushButton("Close")
            close_btn.setStyleSheet(
                "QPushButton { background-color: #2a5b8a; color: white; "
                "font-weight: bold; padding: 5px 20px; border-radius: 4px; }"
                "QPushButton:hover { background-color: #336fa5; }")
            close_btn.clicked.connect(res_dlg.accept)
            res_lay.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)

            res_dlg.exec()   # modal — stays open until user clicks Close

        def _show_error(msg):
            from qgis.PyQt import sip as _sipw
            wait_dlg.close()   # always dismiss the orphan, even if the dock is gone
            if _sipw.isdeleted(self):
                return
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.critical(None, "Error Calculating Span Distance",
                                 f"An error occurred:\n{msg}")

        # Extract geometries on the MAIN thread — QgsVectorLayer.getFeatures() is NOT
        # thread-safe; only the pure measureLength math runs in the worker.
        _crs = span_layer.crs()
        _tctx = QgsProject.instance().transformContext()
        _ellipsoid = QgsProject.instance().ellipsoid()
        _geoms = [QgsGeometry(f.geometry()) for f in span_layer.getFeatures()
                  if f.geometry() and not f.geometry().isEmpty()]
        worker = _Worker(_geoms, _crs, _tctx, _ellipsoid)
        worker.finished.connect(_show_result)
        worker.error.connect(_show_error)
        # Keep reference so GC doesn't destroy it
        self._span_dist_worker = worker
        worker.start()

    def on_sum_pole_numbers_clicked(self):
        """Count total poles across all Poles layers and show a persistent result dialog."""
        from qgis.core import QgsProject, QgsVectorLayer
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                         QPushButton, QMessageBox)
        from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
        from qgis.PyQt.QtGui import QFont

        # Find all poles layers (name starts with 'Poles_' and has pole_type field)
        pole_layers = []
        for lyr in QgsProject.instance().mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer):
                continue
            if lyr.geometryType() != 0:   # Point only
                continue
            ln = lyr.name().lower()
            fnames = [f.name() for f in lyr.fields()]
            if ln.startswith('poles_') and 'pole_type' in fnames:
                pole_layers.append(lyr)

        if not pole_layers:
            QMessageBox.warning(None, "No Poles Layer Found",
                                "No Poles layer was found in the project.\n"
                                "Run Generate Poles first.")
            return

        # ── Worker thread ──────────────────────────────────────────────────
        class _PoleWorker(QThread):
            # emits list of (layer_name, count) and grand total
            finished = pyqtSignal(list, int)
            error    = pyqtSignal(str)

            def __init__(self, results):
                super().__init__()
                self._results = results   # [(name, count)] read on the main thread

            def run(self):
                try:
                    total = sum(c for _, c in self._results)
                    self.finished.emit(self._results, total)
                except Exception as exc:
                    self.error.emit(str(exc))

        # ── Waiting dialog ─────────────────────────────────────────────────
        wait_dlg = QDialog(None)
        wait_dlg.setWindowTitle("Counting…")
        wait_dlg.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint | Qt.WindowType.CustomizeWindowHint)
        wait_dlg.setFixedWidth(280)
        wait_lay = QVBoxLayout(wait_dlg)
        wait_lbl = QLabel(
            f"<b>Counting poles…</b><br>"
            f"{len(pole_layers)} Poles layer(s) found")
        wait_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wait_lay.addWidget(wait_lbl)
        wait_dlg.show()
        QApplication.processEvents()

        def _show_result(results, total):
            from qgis.PyQt import sip as _sipw
            wait_dlg.close()   # always dismiss the orphan, even if the dock is gone
            if _sipw.isdeleted(self):
                return

            res_dlg = QDialog(None)
            res_dlg.setWindowTitle("Poles — Total Count")
            res_dlg.setWindowFlags(
                Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
            res_dlg.setMinimumWidth(340)
            res_lay = QVBoxLayout(res_dlg)
            res_lay.setSpacing(10)
            res_lay.setContentsMargins(18, 18, 18, 18)

            title_lbl = QLabel("🔢  Poles — Total Count")
            title_fnt = QFont()
            title_fnt.setBold(True)
            title_fnt.setPointSize(11)
            title_lbl.setFont(title_fnt)
            title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            res_lay.addWidget(title_lbl)

            # Build per-layer rows
            rows_html = "".join(
                f"<tr><td>&nbsp;&nbsp;{name}:</td>"
                f"<td align='right'><b>{cnt:,}</b></td></tr>"
                for name, cnt in results)
            info_lbl = QLabel(
                f"<table cellspacing='6'>"
                f"{rows_html}"
                f"<tr><td colspan='2'><hr/></td></tr>"
                f"<tr><td><b>Total Poles:</b></td>"
                f"<td align='right'><span style='font-size:13pt; color:#7a4a1e;'>"
                f"<b>{total:,}</b></span></td></tr>"
                f"</table>")
            info_lbl.setAlignment(Qt.AlignmentFlag.AlignLeft)
            res_lay.addWidget(info_lbl)

            close_btn = QPushButton("Close")
            close_btn.setStyleSheet(
                "QPushButton { background-color: #7a4a1e; color: white; "
                "font-weight: bold; padding: 5px 20px; border-radius: 4px; }"
                "QPushButton:hover { background-color: #9a5e28; }")
            close_btn.clicked.connect(res_dlg.accept)
            res_lay.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)

            res_dlg.exec()   # modal — stays open until user clicks Close

        def _show_error(msg):
            from qgis.PyQt import sip as _sipw
            wait_dlg.close()   # always dismiss the orphan, even if the dock is gone
            if _sipw.isdeleted(self):
                return
            QMessageBox.critical(None, "Error Counting Poles",
                                 f"An error occurred:\n{msg}")

        # featureCount()/name() read on the MAIN thread (provider access is not
        # thread-safe); the worker only sums the pre-computed counts.
        _pole_results = [(lyr.name(), lyr.featureCount()) for lyr in pole_layers]
        worker = _PoleWorker(_pole_results)
        worker.finished.connect(_show_result)
        worker.error.connect(_show_error)
        self._pole_count_worker = worker
        worker.start()

    # ── Delete + Renumber ────────────────────────────────────────────────────
    def on_delete_renumber_clicked(self):
        """Remove PONs and close the numbering gaps they leave behind.

        The dock stays thin: everything lives in fibre_automation/renumber/.
        """
        from qgis.PyQt import sip
        from qgis.PyQt.QtWidgets import QMessageBox
        from qgis.core import QgsProject

        if sip.isdeleted(self):
            return
        try:
            try:
                from ..fibre_automation.renumber import dialog as _rn_dialog
            except ImportError:
                from fibre_automation.renumber import dialog as _rn_dialog
        except Exception as exc:   # pragma: no cover - import guard
            QMessageBox.critical(None, "Delete + Renumber",
                                 f"Could not load the renumber module:\n{exc}")
            return
        try:
            _rn_dialog.open_dialog(parent=None, project=QgsProject.instance())
        except Exception as exc:
            if not sip.isdeleted(self):
                QMessageBox.critical(None, "Delete + Renumber",
                                     f"An error occurred:\n{exc}")

    # ── Tag by PON / Phase ───────────────────────────────────────────────────
    def on_zone_tag_clicked(self):
        """Add a 'which PON / Phase am I in?' column to the chosen layers.

        The dock stays thin: everything lives in fibre_automation/tagging/.
        """
        from qgis.PyQt import sip
        from qgis.PyQt.QtWidgets import QMessageBox
        from qgis.core import QgsProject

        if sip.isdeleted(self):
            return
        try:
            try:
                from ..fibre_automation.tagging import zone_tag_dialog
            except ImportError:
                from fibre_automation.tagging import zone_tag_dialog
        except Exception as exc:   # pragma: no cover - import guard
            QMessageBox.critical(None, "Tag by PON / Phase",
                                 f"Could not load the tagging module:\n{exc}")
            return

        try:
            zone_tag_dialog.open_dialog(parent=None, project=QgsProject.instance())
        except Exception as exc:
            if not sip.isdeleted(self):
                QMessageBox.critical(None, "Tag by PON / Phase",
                                     f"An error occurred:\n{exc}")





    # ── tab builders ─────────────────────────────────────────────────────────








    def on_sum_demand_points_clicked(self):
        """Count total demand points in the Demand Points layer and show a persistent result dialog."""
        from qgis.PyQt import sip
        from qgis.core import QgsProject, QgsVectorLayer
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                         QPushButton, QMessageBox)
        from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
        from qgis.PyQt.QtGui import QFont

        # Resolve demand points layer — prefer stored reference, then search by name
        dp_layer = None
        try:
            if self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                dp_layer = self.demand_points_layer
        except Exception:
            pass

        if not dp_layer:
            for lyr in QgsProject.instance().mapLayers().values():
                if not isinstance(lyr, QgsVectorLayer):
                    continue
                if lyr.geometryType() != 0:   # Point only
                    continue
                ln = lyr.name().lower()
                if 'demand points' in ln or 'demand_points' in ln:
                    dp_layer = lyr
                    break

        if not dp_layer:
            QMessageBox.warning(None, "No Demand Points Layer Found",
                                "No Demand Points layer was found in the project.\n"
                                "Please generate demand points first.")
            return

        # ── Worker thread ──────────────────────────────────────────────────
        class _DPWorker(QThread):
            finished = pyqtSignal(str, int)
            error    = pyqtSignal(str)

            def __init__(self, name, count):
                super().__init__()
                self._name = name        # read on the main thread
                self._count = count

            def run(self):
                try:
                    self.finished.emit(self._name, self._count)
                except Exception as exc:
                    self.error.emit(str(exc))

        # ── Waiting dialog ─────────────────────────────────────────────────
        wait_dlg = QDialog(None)
        wait_dlg.setWindowTitle("Counting…")
        wait_dlg.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint | Qt.WindowType.CustomizeWindowHint)
        wait_dlg.setFixedWidth(280)
        wait_lay = QVBoxLayout(wait_dlg)
        wait_lbl = QLabel(f"<b>Counting demand points…</b><br>{dp_layer.name()}")
        wait_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wait_lay.addWidget(wait_lbl)
        wait_dlg.show()
        QApplication.processEvents()

        def _show_result(layer_name, total):
            wait_dlg.close()   # always dismiss the orphan, even if the dock is gone
            if sip.isdeleted(self):
                return

            res_dlg = QDialog(None)
            res_dlg.setWindowTitle("Demand Points — Total Count")
            res_dlg.setWindowFlags(
                Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
            res_dlg.setMinimumWidth(340)
            res_lay = QVBoxLayout(res_dlg)
            res_lay.setSpacing(10)
            res_lay.setContentsMargins(18, 18, 18, 18)

            title_lbl = QLabel("🏠  Demand Points — Total Count")
            title_fnt = QFont()
            title_fnt.setBold(True)
            title_fnt.setPointSize(11)
            title_lbl.setFont(title_fnt)
            title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            res_lay.addWidget(title_lbl)

            info_lbl = QLabel(
                f"<table cellspacing='6'>"
                f"<tr><td>Layer:</td><td><b>{layer_name}</b></td></tr>"
                f"<tr><td colspan='2'><hr/></td></tr>"
                f"<tr><td><b>Total Demand Points:</b></td>"
                f"<td align='right'><span style='font-size:13pt; color:#1a5276;'>"
                f"<b>{total:,}</b></span></td></tr>"
                f"</table>")
            info_lbl.setAlignment(Qt.AlignmentFlag.AlignLeft)
            res_lay.addWidget(info_lbl)

            close_btn = QPushButton("Close")
            close_btn.setStyleSheet(
                "QPushButton { background-color: #1a5276; color: white; "
                "font-weight: bold; padding: 5px 20px; border-radius: 4px; }"
                "QPushButton:hover { background-color: #2471a3; }")
            close_btn.clicked.connect(res_dlg.accept)
            res_lay.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)

            res_dlg.exec()   # stays open until user clicks Close

        def _show_error(msg):
            wait_dlg.close()   # always dismiss the orphan, even if the dock is gone
            if sip.isdeleted(self):
                return
            QMessageBox.critical(None, "Error Counting Demand Points",
                                 f"An error occurred:\n{msg}")

        # featureCount()/name() read on the MAIN thread (provider access is not
        # thread-safe); the worker just relays the pre-read values.
        _dp_name, _dp_count = dp_layer.name(), dp_layer.featureCount()
        worker = _DPWorker(_dp_name, _dp_count)
        worker.finished.connect(_show_result)
        worker.error.connect(_show_error)
        self._dp_count_worker = worker
        worker.start()

    def on_auto_sum_clicked(self):
        """Run Span Distance + Pole Count + Demand Count in one thread and show combined result."""
        from qgis.PyQt import sip
        from qgis.core import (QgsProject, QgsVectorLayer,
                               QgsUnitTypes)
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                         QPushButton, QMessageBox)
        from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
        from qgis.PyQt.QtGui import QFont

        # ── Resolve span layer ────────────────────────────────────────────
        span_layer = self.comboBox_span_layer.currentLayer()
        span_ok = span_layer is not None and span_layer.geometryType() == 1

        # ── Resolve pole layers ───────────────────────────────────────────
        pole_layers = []
        for lyr in QgsProject.instance().mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer):
                continue
            if lyr.geometryType() != 0:
                continue
            ln = lyr.name().lower()
            fnames = [f.name() for f in lyr.fields()]
            if ln.startswith('poles_') and 'pole_type' in fnames:
                pole_layers.append(lyr)

        # ── Resolve demand points layer ───────────────────────────────────
        dp_layer = None
        try:
            if self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                dp_layer = self.demand_points_layer
        except Exception:
            pass
        if not dp_layer:
            for lyr in QgsProject.instance().mapLayers().values():
                if not isinstance(lyr, QgsVectorLayer):
                    continue
                if lyr.geometryType() != 0:
                    continue
                ln = lyr.name().lower()
                if 'demand points' in ln or 'demand_points' in ln:
                    dp_layer = lyr
                    break

        if not span_ok and not pole_layers and not dp_layer:
            QMessageBox.warning(None, "AutoSum",
                                "No Span layer, Poles layers, or Demand Points layer found.\n"
                                "Please generate network layers first.")
            return

        # ── Single worker thread ──────────────────────────────────────────
        class _AutoSumWorker(QThread):
            # span_m, span_name, span_feat_count, pole_results, pole_total, dp_name, dp_count
            finished = pyqtSignal(float, str, int, list, int, str, int)
            error    = pyqtSignal(str)

            def __init__(self, span_geoms, crs, tctx, ellipsoid, span_name,
                         pole_results, dp_name, dp_count):
                super().__init__()
                # everything below is plain data read on the MAIN thread
                self._span_geoms = span_geoms
                self._crs = crs
                self._tctx = tctx
                self._ellipsoid = ellipsoid
                self._span_name = span_name
                self._pole_results = pole_results
                self._dp_name = dp_name
                self._dp_count = dp_count

            def run(self):
                try:
                    # Span distance (pure math over pre-extracted geometries)
                    span_m, span_cnt = 0.0, 0
                    if self._span_geoms is not None:
                        da = QgsDistanceArea()
                        da.setSourceCrs(self._crs, self._tctx)
                        da.setEllipsoid(self._ellipsoid)
                        for geom in self._span_geoms:
                            span_m += da.measureLength(geom)
                            span_cnt += 1
                        span_m = da.convertLengthMeasurement(
                            span_m, QgsUnitTypes.DistanceUnit.DistanceMeters)

                    pole_total = sum(c for _, c in self._pole_results)

                    self.finished.emit(
                        span_m, self._span_name, span_cnt,
                        self._pole_results, pole_total,
                        self._dp_name, self._dp_count)
                except Exception as exc:
                    self.error.emit(str(exc))

        # ── Waiting dialog ────────────────────────────────────────────────
        wait_dlg = QDialog(None)
        wait_dlg.setWindowTitle("AutoSum — Calculating…")
        wait_dlg.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint | Qt.WindowType.CustomizeWindowHint)
        wait_dlg.setFixedWidth(320)
        wait_lay = QVBoxLayout(wait_dlg)
        wait_lbl = QLabel(
            "<b>AutoSum running…</b><br>"
            "Calculating Span Distance, Poles &amp; Demand Points.")
        wait_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wait_lay.addWidget(wait_lbl)
        wait_dlg.show()
        QApplication.processEvents()

        # ── Result dialog ─────────────────────────────────────────────────
        def _show_result(span_m, span_name, span_cnt,
                         pole_results, pole_total, dp_name, dp_count):
            wait_dlg.close()   # always dismiss the orphan, even if the dock is gone
            if sip.isdeleted(self):
                return

            res_dlg = QDialog(None)
            res_dlg.setWindowTitle("AutoSum — Network Summary")
            res_dlg.setWindowFlags(
                Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
            res_dlg.setMinimumWidth(380)
            res_lay = QVBoxLayout(res_dlg)
            res_lay.setSpacing(12)
            res_lay.setContentsMargins(20, 20, 20, 20)

            # Title
            title_lbl = QLabel("🧮  AutoSum — Network Summary")
            title_fnt = QFont()
            title_fnt.setBold(True)
            title_fnt.setPointSize(11)
            title_lbl.setFont(title_fnt)
            title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            res_lay.addWidget(title_lbl)

            # ── Span Distance section ─────────────────────────────────────
            span_header = QLabel("📏  Span Distance")
            span_hfnt = QFont()
            span_hfnt.setBold(True)
            span_hfnt.setPointSize(9)
            span_header.setFont(span_hfnt)
            span_header.setStyleSheet(f'color:{theme_safe.colors()["ok"]};')
            res_lay.addWidget(span_header)

            if span_name:
                km = span_m / 1000.0
                span_html = (
                    f"<table cellspacing='4'>"
                    f"<tr><td>Layer:</td><td><b>{span_name}</b></td></tr>"
                    f"<tr><td>Features:</td><td>{span_cnt:,}</td></tr>"
                    f"<tr><td>Total:</td>"
                    f"<td><b><span style='color:#1a6b3c; font-size:12pt;'>"
                    f"{span_m:,.1f} m</span></b>"
                    f"&nbsp;&nbsp;<span style='color:#555;'>({km:,.3f} km)</span></td></tr>"
                    f"</table>")
            else:
                span_html = "<i style='color:#888;'>No span layer selected.</i>"
            span_lbl = QLabel(span_html)
            res_lay.addWidget(span_lbl)

            # ── Pole Count section ────────────────────────────────────────
            pole_header = QLabel("🔢  Pole Count")
            pole_hfnt = QFont()
            pole_hfnt.setBold(True)
            pole_hfnt.setPointSize(9)
            pole_header.setFont(pole_hfnt)
            pole_header.setStyleSheet(f'color:{theme_safe.colors()["warn"]};')
            res_lay.addWidget(pole_header)

            if pole_results:
                rows = "".join(
                    f"<tr><td>&nbsp;&nbsp;{n}:</td>"
                    f"<td align='right'><b>{c:,}</b></td></tr>"
                    for n, c in pole_results)
                pole_html = (
                    f"<table cellspacing='4'>{rows}"
                    f"<tr><td colspan='2'><hr/></td></tr>"
                    f"<tr><td><b>Total:</b></td>"
                    f"<td align='right'><b><span style='color:#7a4a1e; font-size:12pt;'>"
                    f"{pole_total:,}</span></b></td></tr>"
                    f"</table>")
            else:
                pole_html = "<i style='color:#888;'>No Poles layers found.</i>"
            pole_lbl = QLabel(pole_html)
            res_lay.addWidget(pole_lbl)

            # ── Demand Points section ─────────────────────────────────────
            dp_header = QLabel("🏠  Demand Points")
            dp_hfnt = QFont()
            dp_hfnt.setBold(True)
            dp_hfnt.setPointSize(9)
            dp_header.setFont(dp_hfnt)
            dp_header.setStyleSheet(f'color:{theme_safe.colors()["accent"]};')
            res_lay.addWidget(dp_header)

            if dp_name:
                dp_html = (
                    f"<table cellspacing='4'>"
                    f"<tr><td>Layer:</td><td><b>{dp_name}</b></td></tr>"
                    f"<tr><td><b>Total:</b></td>"
                    f"<td><b><span style='color:#1a5276; font-size:12pt;'>"
                    f"{dp_count:,}</span></b></td></tr>"
                    f"</table>")
            else:
                dp_html = "<i style='color:#888;'>No Demand Points layer found.</i>"
            dp_lbl = QLabel(dp_html)
            res_lay.addWidget(dp_lbl)

            # ── Close button ──────────────────────────────────────────────
            close_btn = QPushButton("Close")
            close_btn.setStyleSheet(
                "QPushButton { background-color: #4a235a; color: white; "
                "font-weight: bold; padding: 5px 20px; border-radius: 4px; }"
                "QPushButton:hover { background-color: #6c3483; }")
            close_btn.clicked.connect(res_dlg.accept)
            res_lay.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)

            res_dlg.exec()   # stays open until user clicks Close

        def _show_error(msg):
            wait_dlg.close()   # always dismiss the orphan, even if the dock is gone
            if sip.isdeleted(self):
                return
            QMessageBox.critical(None, "AutoSum Error",
                                 f"An error occurred:\n{msg}")

        # Read ALL layer data on the MAIN thread (getFeatures/featureCount are not
        # thread-safe); the worker does only the measureLength math + summation.
        _crs = _tctx = _ellipsoid = None
        _span_geoms = None
        _span_name = ''
        if span_ok:
            _crs = span_layer.crs()
            _tctx = QgsProject.instance().transformContext()
            _ellipsoid = QgsProject.instance().ellipsoid()
            _span_geoms = [QgsGeometry(f.geometry()) for f in span_layer.getFeatures()
                           if f.geometry() and not f.geometry().isEmpty()]
            _span_name = span_layer.name()
        _pole_results = [(lyr.name(), lyr.featureCount()) for lyr in pole_layers]
        _dp_name, _dp_count = (dp_layer.name(), dp_layer.featureCount()) if dp_layer else ('', 0)
        worker = _AutoSumWorker(_span_geoms, _crs, _tctx, _ellipsoid, _span_name,
                                _pole_results, _dp_name, _dp_count)
        worker.finished.connect(_show_result)
        worker.error.connect(_show_error)
        self._autosum_worker = worker
        worker.start()

    def on_restore_span_backup_clicked(self):
        """Restore the span layer to the geometry state captured before the last Span Evaluate & Snap."""
        from qgis.core import QgsProject, QgsGeometry
        from qgis.PyQt.QtWidgets import QMessageBox

        backup = getattr(self, '_span_snap_backup', None)
        if not backup:
            QMessageBox.information(None, "Restore Span Backup",
                                    "No backup available.\n\n"
                                    "Run Span Evaluate & Snap first (not dry run) to create a backup.")
            return

        layer_id   = backup.get('layer_id')
        layer_name = backup.get('layer_name', 'unknown')
        features   = backup.get('features', {})

        # Resolve layer
        layer = QgsProject.instance().mapLayer(layer_id)
        if layer is None:
            QMessageBox.warning(None, "Restore Span Backup",
                                f"Layer '{layer_name}' (id: {layer_id}) is no longer in the project.\n"
                                "Cannot restore.")
            return

        reply = QMessageBox.question(
            None, "Restore Span Backup",
            f"This will restore <b>{layer_name}</b> to its state before the last snap.<br><br>"
            f"<b>{len(features)}</b> feature geometry/geometries will be reverted.<br><br>"
            "Are you sure?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return

        full = backup.get('full')
        restored = 0
        errors = 0
        _restore_ok = True
        if full:
            # MERGE-PROOF restore: the merge step (dissolve) deletes + re-adds
            # features with NEW FIDs, so a per-FID changeGeometry silently misses.
            # Replace ALL features with the backed-up geometry + attributes instead.
            # Mirrors the merge write-back pattern used in on_span_evaluate_clicked.
            # Operates on a backup captured before any edit → safe.
            from qgis.core import QgsFeature
            new_feats = []
            for wkt, attrs in full:
                nf = QgsFeature(layer.fields())
                if attrs:
                    nf.setAttributes(list(attrs))
                if wkt:
                    g = QgsGeometry.fromWkt(wkt)
                    if g and not g.isEmpty():
                        nf.setGeometry(g)
                new_feats.append(nf)
            # Batch C: ADD-verify-THEN-delete. This is the RECOVERY path, so a failed
            # add must NEVER destroy the only remaining copy. Add first, confirm it
            # landed, then drop the originals; on failure roll back + keep the backup.
            _prov = layer.dataProvider()  # claude:approved-destructive (restore from pre-snap backup)
            _old_ids = layer.allFeatureIds()
            _before = layer.featureCount()
            _res = _prov.addFeatures(new_feats)
            _ok = _res[0] if isinstance(_res, tuple) else bool(_res)
            _added = _res[1] if (isinstance(_res, tuple) and len(_res) > 1) else []
            if _ok and layer.featureCount() > _before:
                _prov.deleteFeatures(_old_ids)
                restored = len(new_feats)
            else:
                try:
                    if _added:
                        _prov.deleteFeatures([f.id() for f in _added])
                except Exception:
                    _swallowed_note()
                _restore_ok = False
        else:
            # Legacy backups (geometry-only, no merge had run): per-FID restore.
            layer.startEditing()  # claude:approved-destructive (restore from pre-snap backup)
            for fid, wkt in features.items():
                if wkt is None:
                    continue
                geom = QgsGeometry.fromWkt(wkt)
                if geom and not geom.isEmpty():
                    if layer.changeGeometry(fid, geom):
                        restored += 1
                    else:
                        errors += 1
            _safe_commit(layer)
        layer.triggerRepaint()

        # Clear backup so the restore button can't be used again for the same snap —
        # Batch C: ONLY when the restore actually succeeded, so a failed write never
        # discards the user's last recovery copy.
        if _restore_ok:
            self._span_snap_backup = None
            self.pushButton_restore_span_backup.setEnabled(False)
        else:
            QMessageBox.warning(None, "Restore Span Backup",
                                "Restore write FAILED — your backup was KEPT so you can retry.")
        self.pushButton_restore_span_backup.setToolTip(
            "Restore the span layer to the state before the last Span Evaluate & Snap was applied")

        msg = (f"✅ Restore complete.\n\n"
               f"Layer: {layer_name}\n"
               f"Features restored: {restored}")
        if errors:
            msg += f"\nErrors: {errors} (feature IDs may have changed after merge step)"
        QMessageBox.information(None, "Restore Span Backup", msg)

    def on_explode_span_clicked(self):
        """Explode the span layer into individual 2-point segments.

        Each polyline (or multipart polyline) is broken into its constituent
        straight-line segments, one segment per feature.  This is the reverse
        of a dissolve/merge and restores the layer to separate line segments.
        """
        from qgis.core import QgsGeometry, QgsFeature
        from qgis.PyQt.QtWidgets import QMessageBox, QApplication
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtGui import QCursor

        span_layer = self.comboBox_span_layer.currentLayer()
        if span_layer is None:
            QMessageBox.warning(None, "Explode to Segments",
                                "Please select a Span (Route) layer first.")
            return
        if span_layer.geometryType() != 1:
            QMessageBox.warning(None, "Explode to Segments",
                                f"'{span_layer.name()}' is not a line layer.")
            return

        feat_count = span_layer.featureCount()
        reply = QMessageBox.question(
            None, "Explode to Segments",
            f"Break all lines in <b>{span_layer.name()}</b> into individual 2-point segments?<br><br>"
            f"Current feature count: <b>{feat_count}</b><br>"
            "Each polyline with N vertices will become N–1 separate features.<br><br>"
            "This cannot be undone automatically — save a backup first if needed.<br>"
            "Continue?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return

        QApplication.setOverrideCursor(QCursor(Qt.CursorShape.WaitCursor))
        QApplication.processEvents()

        try:
            # Collect all existing features and their attribute data
            all_feats = list(span_layer.getFeatures())
            fields = span_layer.fields()

            # Build new segment features
            new_segments = []
            for feat in all_feats:
                geom = feat.geometry()
                if not geom or geom.isEmpty():
                    continue
                if geom.isMultipart():
                    parts = geom.asMultiPolyline()
                else:
                    parts = [geom.asPolyline()]

                attrs = feat.attributes()
                for part in parts:
                    for i in range(len(part) - 1):
                        seg = QgsFeature(fields)
                        seg.setAttributes(attrs)
                        seg.setGeometry(QgsGeometry.fromPolylineXY([part[i], part[i+1]]))
                        new_segments.append(seg)

            if not new_segments:
                QApplication.restoreOverrideCursor()
                QMessageBox.information(None, "Explode to Segments",
                                        "No segments could be extracted from the layer.")
                return

            # Replace layer contents — Batch C: ADD-verify-THEN-delete so a failed
            # add (read-only/locked/schema issue on a disk span layer) can't wipe the
            # layer with nothing written back. On failure originals are left intact.
            _prov = span_layer.dataProvider()
            _old_ids = span_layer.allFeatureIds()
            _before = span_layer.featureCount()
            _res = _prov.addFeatures(new_segments)
            _ok = _res[0] if isinstance(_res, tuple) else bool(_res)
            _added = _res[1] if (isinstance(_res, tuple) and len(_res) > 1) else []
            if not _ok or span_layer.featureCount() <= _before:
                try:
                    if _added:
                        _prov.deleteFeatures([f.id() for f in _added])
                except Exception:
                    _swallowed_note()
                QApplication.restoreOverrideCursor()
                QMessageBox.warning(
                    None, "Explode to Segments — Aborted",
                    "Could not write the new segments — the layer was left UNCHANGED "
                    "(nothing deleted). It may be read-only or locked.")
                return
            _prov.deleteFeatures(_old_ids)
            span_layer.triggerRepaint()

            QApplication.restoreOverrideCursor()
            QMessageBox.information(
                None, "Explode to Segments — Done",
                f"✅ Explode complete.\n\n"
                f"Layer: {span_layer.name()}\n"
                f"Original features: {feat_count}\n"
                f"Segments created: {len(new_segments)}")

        except Exception as exc:
            QApplication.restoreOverrideCursor()
            import traceback
            QMessageBox.critical(None, "Explode to Segments — Error",
                                 f"An error occurred:\n{exc}\n\n{traceback.format_exc()}")

    def on_validate_span_network_clicked(self):
        """Validate span network topology and identify connectivity issues."""
        from qgis.core import QgsVectorLayer, QgsProject, QgsGeometry, QgsPointXY, QgsFeature
        from qgis.PyQt.QtCore import QMetaType
        import math
        
        self.log_message("="*60)
        self.log_message("VALIDATING SPAN NETWORK TOPOLOGY")
        self.log_message("="*60)
        self._start_timer()
        span_layer = self.comboBox_span_layer.currentLayer()
        if not span_layer:
            self.log_message("ERROR: No span layer selected")
            return
        
        # Validate geometry type
        geom_type = span_layer.geometryType()
        if geom_type != 1:  # LineString
            self.log_message(f"ERROR: Span layer must contain LineString geometry (found type {geom_type})")
            return
        
        self.log_message(f"Analyzing span layer: {span_layer.name()}")
        self.log_message(f"Total features: {span_layer.featureCount()}")
        
        # Build endpoint catalog
        endpoints = {}  # {(x, y): [feature_ids]}
        segment_endpoints = {}  # {feature_id: [(x1, y1), (x2, y2)]}
        valid_segments = 0
        
        for feat in span_layer.getFeatures():
            geom = feat.geometry()
            if geom and not geom.isEmpty():
                if geom.wkbType() in [2, 5, 1002, 1005]:  # (Multi)LineString incl. 25D/Z
                    if geom.isMultipart():
                        lines = geom.asMultiPolyline()
                        if lines:
                            points = lines[0]
                        else:
                            continue
                    else:
                        points = geom.asPolyline()
                    
                    if len(points) >= 2:
                        valid_segments += 1
                        start = _coord_round(points[0].x(), points[0].y())
                        end = _coord_round(points[-1].x(), points[-1].y())
                        
                        segment_endpoints[feat.id()] = (start, end)
                        
                        # Track which segments connect to each endpoint
                        if start not in endpoints:
                            endpoints[start] = []
                        endpoints[start].append(feat.id())
                        
                        if end not in endpoints:
                            endpoints[end] = []
                        endpoints[end].append(feat.id())
        
        self.log_message(f"Valid line segments: {valid_segments}")
        self.log_message(f"Unique endpoints: {len(endpoints)}")
        
        # Analyze connectivity
        dead_ends = []  # Endpoints with only 1 connection
        junctions = []  # Endpoints with 3+ connections
        
        for coord, feature_ids in endpoints.items():
            connection_count = len(feature_ids)
            if connection_count == 1:
                dead_ends.append((coord, feature_ids[0]))
            elif connection_count >= 3:
                junctions.append((coord, connection_count))
        
        self.log_message("\nCONNECTIVITY ANALYSIS:")
        self.log_message(f"  Dead ends (dangling nodes): {len(dead_ends)}")
        self.log_message(f"  Junctions (3+ connections): {len(junctions)}")
        self.log_message(f"  Normal connections (2 segments): {len(endpoints) - len(dead_ends) - len(junctions)}")
        
        # Find disconnected components using flood-fill
        visited = set()
        components = []
        
        def flood_fill(start_coord):
            """Find all connected endpoints from starting point."""
            component = set()
            stack = [start_coord]
            
            while stack:
                coord = stack.pop()
                if coord in visited:
                    continue
                
                visited.add(coord)
                component.add(coord)
                
                # Find all segments connected to this endpoint
                if coord in endpoints:
                    for fid in endpoints[coord]:
                        if fid in segment_endpoints:
                            start, end = segment_endpoints[fid]
                            if start not in visited:
                                stack.append(start)
                            if end not in visited:
                                stack.append(end)
            
            return component
        
        # Find all connected components
        for coord in endpoints:
            if coord not in visited:
                component = flood_fill(coord)
                if component:
                    components.append(component)
        
        self.log_message("\nCOMPONENT ANALYSIS:")
        self.log_message(f"  Number of disconnected components: {len(components)}")
        
        for i, component in enumerate(components, 1):
            segment_count = sum(1 for fid, (s, e) in segment_endpoints.items() if s in component or e in component)
            self.log_message(f"  Component {i}: {len(component)} endpoints, {segment_count} segments")
        
        # Check aggregation points connectivity (if they exist)
        agg_layer = None
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer):
                if 'aggregation' in layer.name().lower() and 'point' in layer.name().lower():
                    agg_layer = layer
                    break
        
        if agg_layer and len(components) > 1:
            self.log_message("\nAGGREGATION POINTS ANALYSIS:")
            
            # Map each agg point to nearest component
            agg_to_component = {}
            # 'group_100' is not a field on aggregation-point layers (which carry
            # enclosure_id/_name/converging_cables); reading it raised KeyError.
            _agg_has_g100 = agg_layer.fields().lookupField('group_100') >= 0

            for agg_feat in agg_layer.getFeatures():
                agg_geom = agg_feat.geometry()
                if agg_geom and not agg_geom.isEmpty():
                    agg_point = agg_geom.asPoint()
                    agg_coord = (agg_point.x(), agg_point.y())
                    
                    # Find nearest endpoint in any component
                    min_dist = float('inf')
                    nearest_component = None
                    
                    for comp_idx, component in enumerate(components):
                        for endpoint in component:
                            dist = math.sqrt((agg_coord[0] - endpoint[0])**2 + 
                                           (agg_coord[1] - endpoint[1])**2)
                            if dist < min_dist:
                                min_dist = dist
                                nearest_component = comp_idx
                    
                    if nearest_component is not None:
                        if nearest_component not in agg_to_component:
                            agg_to_component[nearest_component] = []
                        agg_to_component[nearest_component].append(
                            agg_feat['group_100'] if _agg_has_g100 else agg_feat.id())
            
            # Report distribution
            for comp_idx in range(len(components)):
                agg_groups = agg_to_component.get(comp_idx, [])
                self.log_message(f"  Component {comp_idx + 1} has {len(agg_groups)} aggregation points")
                if agg_groups and len(agg_groups) <= 5:
                    self.log_message(f"    Groups: {', '.join(map(str, agg_groups))}")
        
        # Create visualization layer for problem areas
        if dead_ends or len(components) > 1:
            self.log_message("\nCREATING VISUALIZATION LAYER...")
            
            # Create problem points layer
            problem_layer = QgsVectorLayer(
                "Point?crs=" + span_layer.crs().authid(),
                "Span Network Issues",
                "memory"
            )
            
            provider = problem_layer.dataProvider()
            provider.addAttributes([
                QgsField("issue_type", QMetaType.Type.QString),
                QgsField("description", QMetaType.Type.QString),
                QgsField("component", QMetaType.Type.Int)
            ])
            problem_layer.updateFields()
            
            features = []
            
            # Add dead ends
            for coord, fid in dead_ends:
                feat = QgsFeature(problem_layer.fields())
                feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(coord[0], coord[1])))
                feat['issue_type'] = 'Dead End'
                feat['description'] = f'Segment {fid} has dangling endpoint'
                feat['component'] = -1
                features.append(feat)
            
            # Add component markers (first endpoint of each component)
            for comp_idx, component in enumerate(components):
                if component:
                    coord = next(iter(component))
                    feat = QgsFeature(problem_layer.fields())
                    feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(coord[0], coord[1])))
                    feat['issue_type'] = 'Component'
                    feat['description'] = f'Component {comp_idx + 1} ({len(component)} endpoints)'
                    feat['component'] = comp_idx + 1
                    features.append(feat)
            
            provider.addFeatures(features)
            
            # Style the layer
            symbol = QgsMarkerSymbol.createSimple({
                'name': 'triangle',
                'color': 'red',
                'size': '4',
                'outline_color': 'black',
                'outline_width': '0.5'
            })
            problem_layer.setRenderer(QgsSingleSymbolRenderer(symbol))
            
            QgsProject.instance().addMapLayer(problem_layer)
            self.log_message(f"Created layer 'Span Network Issues' with {len(features)} problem points")
        
        # Provide recommendations
        self.log_message("\n" + "="*60)
        self.log_message("RECOMMENDATIONS:")
        
        if len(components) > 1:
            self.log_message(f"  ⚠ CRITICAL: Network has {len(components)} disconnected components")
            self.log_message("  → Use Vector → Geometry Tools → Snap Geometries (tolerance: 0.0001)")
            self.log_message("  → Or use Processing → GRASS → v.clean (tools: break,snap,rmdupl)")
        
        if len(dead_ends) > 10:
            self.log_message(f"  ⚠ WARNING: {len(dead_ends)} dead ends found")
            self.log_message("  → Check if these are intentional network endpoints")
            self.log_message("  → Use Topology Checker to find gaps")
        
        if len(components) == 1 and len(dead_ends) <= 10:
            self.log_message("  ✓ Network appears well-connected!")
            self.log_message("  ✓ Ready for feeder route generation")
        
        self.log_message("="*60)
        self._elapsed("Validation")
        return   # ── validation ends here ──
        # Everything below to the end of this method is a SUPERSEDED feeder-route
        # generator that fell through with no return — clicking "Validate" used to
        # ALSO run feeder generation (incl. the recursive get_edge_level that can
        # RecursionError on a large network). The LIVE generator is the separate
        # on_generate_feeder_routes_clicked. Now unreachable. Slated for deletion.
        # ---------------------------------------------------------------------------

    # ── PHASE 1: POLE SPECIFICATION HELPERS (Herotel FTTH Standards) ──
    def _detect_span_type(self, layer_name: str) -> str:
        """Auto-detect span type from layer name.
        Returns 'feeder' if 'feeder' in name (case-insensitive), else 'distribution'."""
        if not layer_name:
            return "distribution"
        return "feeder" if "feeder" in layer_name.lower() else "distribution"

    def _get_pole_height(self, pole_role: str, is_crossing: bool = False) -> float:
        """Get pole height per Herotel spec.
        Feeder: 7m | Distribution midblock: 5.4m | Distribution crossing: 7m"""
        if pole_role == "feeder":
            return 7.0
        if pole_role == "distribution":
            return 7.0 if is_crossing else 5.4
        if pole_role == "support":
            return 5.4
        return 5.4

    def _get_pole_thickness(self, pole_role: str, is_corner: bool = False) -> str:
        """Get pole thickness per Herotel spec (mm).
        Standard: 100/120 | Corner (>15°): 120/140"""
        return "120/140" if (is_corner or pole_role in ["terminal", "support"]) else "100/120"

    def _get_installation_notes(self, pole_role: str, pole_type: str,
                                 pole_height: float, pole_thickness: str) -> str:
        """Generate SANS 754 H4 compliant installation notes."""
        notes = [
            "SANS 754 (63 MPa H4 treated)",
            f"Diameter: {pole_thickness}mm | Height: {pole_height}m",
            f"Depth: {'1.0' if pole_height != 9.0 else '1.2'}m hole | 300x300mm top, taper to 200x200mm bottom",
            "Backfill: 200mm soil + 2x 200mm Soil Crete + compacted fill",
        ]
        if pole_role == "feeder":
            notes.append("FEEDER: 70m max span, double+ capacity, hook @ 5.5m")
        elif pole_role == "distribution":
            notes.append("DISTRIBUTION: 8 homes per pole (4 direct + 4 via tangent)")
        if pole_type in ["start", "end"]:
            notes.append("TERMINAL: Verify cable slack")
        if pole_type == "kink":
            notes.append("KINK: Direction change — check support requirements")
        return " | ".join(notes)

    def _resolve_span_type_field(self, lyr):
        """Find the field holding the span TYPE (primary/secondary feeder,
        distribution, …). Span layers name this field many different ways, so the
        old hard-coded case-sensitive 'Type' lookup found nothing on most real
        layers (e.g. 'type', 'Span Type', 'Classification') and the Generate-Poles
        'Filter by Type' dropdown showed only 'All spans'. Match common names
        case-insensitively first, then fall back to scanning text fields for
        span-type-like values. Returns the field index, or -1 if none looks like
        a type field."""
        if not lyr:
            return -1
        flds = lyr.fields()
        # 1) common explicit names — lookupField is case-INSENSITIVE
        for cand in ('Type', 'span_type', 'spantype', 'SpanType', 'cable_type',
                     'cabletype', 'Cable Type', 'span_role', 'SpanRole', 'role',
                     'category', 'class', 'classification', 'Classification'):
            idx = flds.lookupField(cand)
            if idx >= 0:
                return idx
        # 2) fallback: single pass over text fields, pick the one whose values look
        #    most like span types (small category set + type keywords).
        _kw = ('feeder', 'distribution', 'primary', 'secondary', 'spur',
               'drop', 'trunk', 'backbone', 'link')
        str_idxs = []
        for i, f in enumerate(flds):
            try:
                tn = f.typeName().lower()
            except Exception:
                tn = ''
            if 'char' in tn or 'string' in tn or 'text' in tn:
                str_idxs.append(i)
        if not str_idxs:
            return -1
        vals = {i: set() for i in str_idxs}
        hits = {i: 0 for i in str_idxs}
        n = 0
        for ft in lyr.getFeatures():
            n += 1
            for i in str_idxs:
                v = ft[i]
                if v:
                    s = str(v).lower()
                    if len(vals[i]) <= 40:
                        vals[i].add(s)
                    if any(k in s for k in _kw):
                        hits[i] += 1
            if n >= 5000:          # cap the scan on very large layers
                break
        best_idx, best_hits = -1, 0
        for i in str_idxs:
            if hits[i] > best_hits and 1 <= len(vals[i]) <= 40:
                best_idx, best_hits = i, hits[i]
        return best_idx

    def on_generate_feeder_routes_clicked(self):
        """Generate fiber feeder routes from OLT to aggregation points along routing layer."""
        from qgis.core import (
            QgsVectorLayer, QgsFeature, QgsGeometry, QgsWkbTypes, QgsField
        )
        from qgis.PyQt.QtCore import QMetaType
        from qgis.PyQt.QtGui import QColor

        olt_layer = self.comboBox_olt_layer.currentLayer()
        agg_layer = self.comboBox_aggregation_layer.currentLayer()
        routing_layer = self.comboBox_routing_layer.currentLayer()

        if not olt_layer:
            self.log_message("ERROR: Please select an OLT layer.")
            return
        if not agg_layer:
            self.log_message("ERROR: Please select an Aggregation Points layer.")
            return

        self.log_message("\n=== Generating Feeder Routes ===")
        self._start_timer()  # _start_timer takes no args (matches all other call sites)
        from qgis.PyQt.QtWidgets import QApplication
        QApplication.processEvents()

        try:
            # Get OLT point (use first feature)
            olt_features = list(olt_layer.getFeatures())
            if not olt_features:
                self.log_message("ERROR: OLT layer has no features.")
                return
            olt_geom = olt_features[0].geometry()
            if not olt_geom or olt_geom.isEmpty():
                self.log_message("ERROR: OLT feature has no geometry.")
                return
            olt_point = olt_geom.asPoint() if olt_geom.type() == QgsWkbTypes.GeometryType.PointGeometry else olt_geom.centroid().asPoint()

            # Collect aggregation points
            agg_points = []
            _agg_has_zone_name = 'zone_name' in [f.name() for f in agg_layer.fields()]
            for feat in agg_layer.getFeatures():
                geom = feat.geometry()
                if geom and not geom.isEmpty():
                    pt = geom.asPoint() if geom.type() == QgsWkbTypes.GeometryType.PointGeometry else geom.centroid().asPoint()
                    zone_name = feat['zone_name'] if _agg_has_zone_name else str(feat.id())
                    agg_points.append((pt, zone_name, feat.id()))

            if not agg_points:
                self.log_message("ERROR: No aggregation points found.")
                return

            self.log_message(f"OLT point: ({olt_point.x():.1f}, {olt_point.y():.1f})")
            self.log_message(f"Aggregation points: {len(agg_points)}")

            # Build routing graph from span layer if available
            route_segments = []
            if routing_layer and routing_layer.geometryType() == QgsWkbTypes.GeometryType.LineGeometry:
                self.log_message(f"Routing layer: '{routing_layer.name()}'")
                for feat in routing_layer.getFeatures():
                    geom = feat.geometry()
                    if geom and not geom.isEmpty():
                        route_segments.append(geom)

            # Create feeder routes layer
            crs_str = agg_layer.crs().authid()
            feeder_layer = QgsVectorLayer(f"LineString?crs={crs_str}", "Feeder Routes", "memory")
            provider = feeder_layer.dataProvider()
            provider.addAttributes([
                QgsField('route_id', QMetaType.Type.Int),
                QgsField('zone_name', QMetaType.Type.QString),
                QgsField('agg_point_id', QMetaType.Type.Int),
                QgsField('length_m', QMetaType.Type.Double),
            ])
            feeder_layer.updateFields()

            from qgis.core import QgsDistanceArea
            _da_feeder = QgsDistanceArea()
            _da_feeder.setSourceCrs(agg_layer.crs(), QgsProject.instance().transformContext())
            _da_feeder.setEllipsoid(_safe_ellipsoid(QgsProject.instance(), agg_layer.crs()))

            route_id = 1
            feeder_layer.startEditing()

            for pt, zone_name, agg_id in agg_points:
                self._progress(route_id - 1, len(agg_points), f"Routing to {zone_name}")
                QApplication.processEvents()

                if route_segments:
                    # Snap OLT and target to nearest point on routing network, then connect via straight line
                    # Simple approach: find nearest route segment endpoints and connect
                    best_line = self._route_along_network(olt_point, pt, route_segments)
                else:
                    # Straight-line feeder
                    best_line = QgsGeometry.fromPolylineXY([olt_point, pt])

                feat = QgsFeature(feeder_layer.fields())
                feat.setGeometry(best_line)
                feat['route_id'] = route_id
                feat['zone_name'] = zone_name
                feat['agg_point_id'] = agg_id
                feat['length_m'] = round(_da_feeder.measureLength(best_line), 2)  # metres, not CRS degrees
                feeder_layer.addFeature(feat)
                route_id += 1

            _safe_commit(feeder_layer)

            # Style: dark blue line, width 0.8
            from qgis.core import QgsSimpleLineSymbolLayer, QgsSingleSymbolRenderer, QgsSymbol
            symbol = QgsSymbol.defaultSymbol(QgsWkbTypes.GeometryType.LineGeometry)
            sym_layer = QgsSimpleLineSymbolLayer()
            sym_layer.setColor(QColor('#003399'))
            sym_layer.setWidth(0.8)
            symbol.changeSymbolLayer(0, sym_layer)
            feeder_layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            feeder_layer = self._add_output_layer(feeder_layer)
            self.log_message(f"Generated {route_id - 1} feeder routes.")
            self._elapsed("Total time")

        except Exception as e:
            self.log_message(f"ERROR generating feeder routes: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def _route_along_network(self, start_pt, end_pt, route_segments):
        """Find a path along route segments from start to end using nearest-segment snapping.
        Falls back to straight line if no path found."""
        from qgis.core import QgsGeometry, QgsPointXY
        import math

        def dist(p1, p2):
            return math.sqrt((p1.x() - p2.x()) ** 2 + (p1.y() - p2.y()) ** 2)

        def nearest_point_on_segment(px, py, ax, ay, bx, by):
            dx, dy = bx - ax, by - ay
            if dx == 0 and dy == 0:
                return QgsPointXY(ax, ay)
            t = max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)))
            return QgsPointXY(ax + t * dx, ay + t * dy)

        # Find closest point on network to start and end
        best_start, best_end = None, None
        best_sd, best_ed = float('inf'), float('inf')

        for seg_geom in route_segments:
            pts = seg_geom.asPolyline() if seg_geom.isMultipart() is False else []
            if not pts:
                try:
                    for part in seg_geom.asMultiPolyline():
                        pts.extend(part)
                except Exception:
                    continue
            for i in range(len(pts) - 1):
                snap_s = nearest_point_on_segment(start_pt.x(), start_pt.y(), pts[i].x(), pts[i].y(), pts[i+1].x(), pts[i+1].y())
                snap_e = nearest_point_on_segment(end_pt.x(), end_pt.y(), pts[i].x(), pts[i].y(), pts[i+1].x(), pts[i+1].y())
                ds = dist(start_pt, snap_s)
                de = dist(end_pt, snap_e)
                if ds < best_sd:
                    best_sd, best_start = ds, snap_s
                if de < best_ed:
                    best_ed, best_end = de, snap_e

        if best_start and best_end:
            return QgsGeometry.fromPolylineXY([start_pt, best_start, best_end, end_pt])
        return QgsGeometry.fromPolylineXY([start_pt, end_pt])

    def on_clear_output_clicked(self):
        """Clear the output text."""
        self.textEdit_output.clear()
        self.log_message("Output cleared.")

    def closeEvent(self, event):
        """Handle the close event."""
        # Disconnect the QgsProject singleton signals wired in __init__ — otherwise a
        # one-click reload builds a fresh dock and the OLD (deleted) dock's slots stay
        # connected, so the next project open/clear fires into a deleted C++ widget
        # ("wrapped C/C++ object has been deleted"). Guarded: harmless if already gone.
        try:
            from qgis.core import QgsProject as _QPc
            try:
                _QPc.instance().readProject.disconnect(self._reload_gpkg_path)
            except (TypeError, RuntimeError):
                pass
            try:
                _QPc.instance().cleared.disconnect(self._clear_gpkg_path)
            except (TypeError, RuntimeError):
                pass
        except Exception:
            pass
        self.closingPlugin.emit()
        event.accept()


# The mixins that name this class at call time get it now that it exists.
from . import dock_widget_override as _dock_widget_override  # noqa: E402
_dock_widget_override.FTTHPlanToolDockWidget = FTTHPlanToolDockWidget
