"""Velocity Nexus — branded home dock panel (themeable).

A clean, friendly control panel that fronts the plugin's tools so QGIS feels like a
product, not raw QGIS. Header shows a wordmark (or logo.png if present) + live bridge
status + a theme switcher; below are numbered workflow step buttons and a tools row.
Each button just triggers the plugin's existing actions/callbacks — no logic here.

Two built-in themes:
  • velocity  — VF identity: navy #14213D, blue #3B6FE0 → magenta #C2255C, teal #2ABFCC
  • fibertime — client identity: deep blue #081634, electric blue #1463FF + yellow #FFD400

Everything is styled by objectName via QSS, so switching theme = one stylesheet swap.
"""
import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QPixmap  # QColor: glow; QPixmap: logo fallback
from qgis.PyQt.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame,
    QLineEdit, QGraphicsDropShadowEffect,  # glow on the "you are here" card
)

# ── theme palettes ───────────────────────────────────────────────────────────
THEMES = {
    "velocity": {
        "name": "Velocity Nexus",
        "egg": "The grid awaits.",
        # Mission Control — near-black console + electric cyan, green/amber status
        # (JJ pick, 2026-06-15). Matches design/velocity_nexus_mission_control.html
        # and the Ticket Mission Control board. Same keys/structure as before so
        # nothing in the layout changes — only the colour language.
        "bg":            "#05070C",   # near-black console base
        "header":        "qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #0B1019, stop:1 #070A11)",
        "accent":        "qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #1AE5FF, stop:1 #1AA6FF)",
        "word_top":      "#EAF3FF",
        "word_bot":      "#1AE5FF",   # electric cyan highlight on NEXUS
        "tagline":       "#7E93B8",
        "section":       "#7E93B8",
        "step_bg":       "#0D1320",   # console cell
        "step_hover":    "#131D2E",
        "step_border":   "#1B2940",   # faint blue-grey hairline
        "step_hi":       "#1AE5FF",   # electric cyan
        "title":         "#EAF3FF",
        "sub":           "#8AA0BE",
        "chev":          "#53678A",
        "tool_bg":       "#0D1320",
        "tool_text":     "#C9DDF2",
        "tool_hover":    "#131D2E",
        "tool_hi":       "#1AE5FF",
        "status_on":     "#3DFF9A",   # mission-control green = good
        "status_off":    "#FF4D5E",
        "badge_text":    "#04070D",   # dark text on cyan accent
    },
    "fibertime": {
        "name": "fibertime",
        "egg": "Light it up.",
        "bg":            "#081634",
        "header":        "qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #0B2A6B, stop:0.6 #103A8E, stop:1 #155FD0)",
        "accent":        "qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #1463FF, stop:1 #FFD400)",
        "word_top":      "#FFFFFF",
        "word_bot":      "#FFD400",
        "tagline":       "#9FB6E8",
        "section":       "#7089C8",
        "step_bg":       "#0E2356",
        "step_hover":    "#143071",
        "step_border":   "#1E3C82",
        "step_hi":       "#FFD400",
        "title":         "#EAF1FF",
        "sub":           "#9FB6E8",
        "chev":          "#5C77B8",
        "tool_bg":       "#0C1F4C",
        "tool_text":     "#BCD0F5",
        "tool_hover":    "#143071",
        "tool_hi":       "#FFD400",
        "status_on":     "#FFD400",
        "status_off":    "#FF6B6B",
        "badge_text":    "#08183A",
    },
}

# Merge the exotic theme pack (bundled, WCAG-verified). Each adds name + egg +
# the same colour keys, so the theme switcher + QSS pick them up automatically.
_REF_THEME = dict(next(iter(THEMES.values()))) if THEMES else {}
try:
    from .nexus_themes import NEW_THEMES as _EXOTIC
except ImportError:
    try:
        from nexus_themes import NEW_THEMES as _EXOTIC
    except Exception:
        _EXOTIC = {}
except Exception:
    _EXOTIC = {}
THEMES.update(_EXOTIC)
# Harden: _build_qss / _apply_theme index ~20 colour keys directly, so a theme
# missing even one key would KeyError into the UI when selected. Backfill any
# absent key from a complete reference theme — a no-op for complete themes.
for _t in THEMES.values():
    for _k, _v in _REF_THEME.items():
        _t.setdefault(_k, _v)

# ── Client / spec profiles ────────────────────────────────────────────────────
# Pick a client → the panel becomes their live spec sheet. Mirrored from
# design/DESIGN_velocity_nexus.md (the design-system source of truth). Values
# verified from the plugin algorithms (ht_base_algorithm.py) + master spec.
CLIENT_SPECS = {
    "fibertime": {
        "label": "Fibertime",
        "splitter": "1:8 FTS → 8× 1:16 STS",
        "cap": "128 max · target 80–102 ONT/PON",
        "zone": "16 PON = 1 zone",
        "drop_max_m": 50, "feeder_max_m": 70,
        "cable": "1F drop · 24F dist · 144F primary",
        "pole": "FOA 2015:35 creosote 120–160mm",
        "ont": "Nokia G-2425G-A",
    },
    "herotel": {
        "label": "HeroTel",
        "splitter": "Flexible 1:2–1:32 per node",
        "cap": "up to 128 per node (SDU + MDU)",
        "zone": "",
        "drop_max_m": 50, "feeder_max_m": 75,
        "cable": "4F dual-drop · 18–36F dist · 48–144F feeder (SSA)",
        "pole": "SANS 754 CCA H4 ≥63 MPa",
        "ont": "Per TSD",
    },
    "vuma": {
        "label": "Vuma",
        "splitter": "Fixed 1:128 cascade (1:4 + 1:32)",
        "cap": "128 max · target 110 ONT/PON",
        "zone": "",
        "drop_max_m": 50, "feeder_max_m": 70,
        "cable": "ADSS aerial (per capacity table)",
        "pole": "Creosote, FOA-classified",
        "ont": "Nokia G-2425G-A",
    },
}


# step title keyword → leading emoji icon (quick visual scanning)
_ICONS = [
    ("detect", "🛰"), ("erven", "📐"), ("planner", "🗺"), ("network", "🗺"),
    ("label", "🏷"), ("audit", "🔍"), ("check", "🔍"), ("splice", "🧵"),
]


def _icon_for(title):
    t = title.lower()
    for key, emo in _ICONS:
        if key in t:
            return emo
    return "▸"


class _ScoreRing(QWidget):
    """Compact circular HLD-readiness gauge (0–100), colour-coded, big number in
    the centre. Custom-painted so the arc + gradient look crisp at any DPI."""

    def __init__(self, size=66, parent=None):
        super().__init__(parent)
        self._score = None
        self.setFixedSize(size, size)

    def set_score(self, score):
        self._score = None if score is None else max(0, min(100, int(score)))
        self.update()

    def paintEvent(self, _e):
        from qgis.PyQt.QtCore import QRectF
        from qgis.PyQt.QtGui import QFont, QPainter, QPen
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        m = 5.0
        r = QRectF(m, m, self.width() - 2 * m, self.height() - 2 * m)
        # track (console hairline)
        p.setPen(QPen(QColor("#1B2940"), 5))
        p.drawArc(r, 0, 360 * 16)
        sc = self._score
        if sc is None:
            p.setPen(QColor("#53678A"))
            f = QFont(); f.setPointSize(13); f.setBold(True); p.setFont(f)
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "—")
            p.end(); return
        # Mission-Control arc: green (high) → cyan (good) → amber (low warn)
        col = (QColor("#3DFF9A") if sc >= 90
               else QColor("#1AE5FF") if sc >= 70 else QColor("#FFB020"))
        sweep = int(-sc / 100.0 * 360 * 16)   # 12 o'clock, clockwise
        # soft glow halo behind the arc
        halo = QPen(QColor(col.red(), col.green(), col.blue(), 70), 9)
        halo.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(halo)
        p.drawArc(r, 90 * 16, sweep)
        pen = QPen(col, 5)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(pen)
        p.drawArc(r, 90 * 16, sweep)
        p.setPen(QColor("#EAF3FF"))
        f = QFont(); f.setPointSize(15); f.setBold(True); p.setFont(f)
        p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, str(sc))
        p.end()


def _build_qss(c):
    """Build the full panel stylesheet from a theme colour dict."""
    return f"""
#vfRoot {{ background:{c['bg']}; }}
#vfHeader {{ background:{c['header']}; }}
#vfWordTop   {{ color:{c['word_top']}; font-size:16px; font-weight:800; letter-spacing:1.5px; }}
#vfWordBot   {{ color:#EF4444; font-size:10px; font-weight:700; letter-spacing:4px; }}
#vfTagline   {{ color:{c['tagline']}; font-size:10px; }}
#vfStatus    {{ color:{c['word_bot']}; font-size:10px; }}
#vfSection   {{ color:{c['section']}; font-size:10px; font-weight:700; letter-spacing:2px;
                font-family:'JetBrains Mono','Consolas','DejaVu Sans Mono',monospace;
                border-top:1px solid {c['step_border']}; padding-top:9px; margin-top:2px; }}

/* live project-context strip */
#vfContext {{ background:{c['header']}; border-bottom:1px solid {c['step_border']}; }}
QLabel#vfCtxProject {{ color:{c['title']}; font-size:14px; font-weight:800; }}
QLabel#vfCtxStats   {{ color:{c['sub']}; font-size:10px; font-weight:600; letter-spacing:0.3px; }}
/* KPI chips in the hero */
QFrame#vfKpi {{ background:{c['step_bg']}; border:1px solid {c['step_border']};
                border-radius:8px; }}
QLabel#vfKpiVal {{ color:{c['title']}; font-size:15px; font-weight:800; }}
QLabel#vfKpiCap {{ color:{c['section']}; font-size:8px; font-weight:700; letter-spacing:0.8px;
                font-family:'JetBrains Mono','Consolas','DejaVu Sans Mono',monospace; }}
/* hero workflow-completion bar */
QLabel#vfProgLbl {{ color:{c['section']}; font-size:9px; font-weight:700; letter-spacing:1px;
                font-family:'JetBrains Mono','Consolas','DejaVu Sans Mono',monospace; }}
QProgressBar#vfProg {{ background:{c['step_border']}; border:none; border-radius:4px; }}
QProgressBar#vfProg::chunk {{ background:{c['accent']}; border-radius:4px; }}
/* client / spec profiles */
QPushButton#vfClient {{ background:{c['tool_bg']}; color:{c['sub']};
    border:1px solid {c['step_border']}; border-radius:7px; padding:6px 4px;
    font-size:10px; font-weight:700; }}
QPushButton#vfClient:hover {{ color:#FFFFFF; border:1px solid {c['step_hi']}; }}
QPushButton#vfClient[active="true"] {{ background:{c['accent']};
    color:{c['badge_text']}; border:1px solid {c['step_hi']}; }}
QFrame#vfSpec {{ background:{c['step_bg']}; border:1px solid {c['step_hi']};
    border-radius:10px; }}
QLabel#vfSpecLine {{ color:{c['sub']}; font-size:10.5px; }}

#vfVmark {{ background:{c['accent']}; border-radius:9px; }}
#vfVmark QLabel {{ color:#FFFFFF; font-size:20px; font-weight:900; }}

QPushButton#vfThemeBtn {{
    color:{c['word_bot']}; background:rgba(255,255,255,0.06);
    border:1px solid rgba(255,255,255,0.12); border-radius:9px;
    padding:3px 9px; font-size:10px; font-weight:700;
}}
QPushButton#vfThemeBtn:hover {{ color:#FFFFFF; border:1px solid {c['step_hi']}; }}
QPushButton#vfThemeBtn[active="true"] {{
    color:{c['badge_text']}; background:{c['accent']};
    border:1px solid {c['step_hi']};
}}

QPushButton#vfGear {{
    color:{c['word_bot']}; background:rgba(255,255,255,0.06);
    border:1px solid rgba(255,255,255,0.12); border-radius:9px;
    padding:3px 9px; font-size:13px; font-weight:700;
}}
QPushButton#vfGear:hover {{ color:#FFFFFF; border:1px solid {c['step_hi']}; background:{c['step_hover']}; }}

/* red ticket button — report a bug / request a feature, straight to the office */
QPushButton#vfTicket {{
    color:#FFFFFF; background:#E0344B; border:1px solid #FF5C6E;
    border-radius:9px; padding:3px 10px; font-size:11px; font-weight:800;
}}
QPushButton#vfTicket:hover {{ background:#F0455C; border:1px solid #FFFFFF; }}
QPushButton#vfTicket:pressed {{ background:#B91E33; }}

/* step cards */
QFrame#vfStep {{
    border:1px solid {c['step_border']}; border-radius:12px; background:{c['step_bg']};
    min-height:46px;
}}
QFrame#vfStep:hover {{ border:1px solid {c['step_hi']}; background:{c['step_hover']}; }}
QFrame#vfStripe {{ background:{c['accent']}; border-top-left-radius:12px; border-bottom-left-radius:12px; }}
QLabel#vfStepNum {{
    background:{c['accent']}; color:{c['badge_text']};
    font-weight:900; font-size:14px; border-radius:14px;
}}
QLabel#vfStepTitle {{ color:{c['title']}; font-size:14px; font-weight:700; }}
QLabel#vfStepSub   {{ color:{c['sub']};   font-size:10px; }}
QLabel#vfStepChev  {{ color:{c['chev']};  font-size:20px; font-weight:800; }}

/* "you are here" states (set via the stepState property) — stripe colour
   tracks state so the left edge reads as a progress bar at a glance */
QFrame#vfStep[stepState="done"] {{ border:1px solid {c['status_on']}; }}
QFrame#vfStep[stepState="done"] QLabel#vfStepNum {{ background:{c['status_on']}; }}
QFrame#vfStep[stepState="done"] QFrame#vfStripe {{ background:{c['status_on']}; }}
QFrame#vfStep[stepState="current"] {{ border:1px solid {c['step_hi']}; background:{c['step_hover']}; }}
QFrame#vfStep[stepState="current"] QLabel#vfStepChev {{ color:{c['step_hi']}; }}
QFrame#vfStep[stepState="current"] QFrame#vfStripe {{ background:{c['step_hi']}; }}
QFrame#vfStep[stepState="todo"] QLabel#vfStepNum {{ background:{c['step_border']}; color:{c['sub']}; }}
QFrame#vfStep[stepState="todo"] QLabel#vfStepTitle {{ color:{c['sub']}; }}
QFrame#vfStep[stepState="todo"] QFrame#vfStripe {{ background:{c['step_border']}; }}

/* smart "next step" CTA */
QPushButton#vfNextCta {{
    text-align:left; padding:10px 14px; border-radius:10px;
    background:{c['accent']}; color:{c['badge_text']};
    border:1px solid {c['step_hi']}; font-size:12px; font-weight:800;
}}
QPushButton#vfNextCta:hover {{ border:1px solid #FFFFFF; }}
QPushButton#vfNextCta[done="true"] {{
    background:{c['step_bg']}; color:{c['status_on']};
    border:1px solid {c['status_on']}; font-weight:700;
}}

/* tools */
QPushButton#vfTool {{
    padding:9px 6px; border:1px solid {c['step_border']}; border-radius:10px;
    background:{c['tool_bg']}; color:{c['tool_text']}; font-size:11px; font-weight:700;
}}
QPushButton#vfTool:hover {{ background:{c['tool_hover']}; border:1px solid {c['tool_hi']}; color:#FFFFFF; }}
QPushButton#vfTool:pressed {{ background:{c['bg']}; border:1px solid #FFFFFF; }}
QPushButton#vfTool:focus {{ border:2px solid {c['step_hi']}; outline:none; }}
QPushButton#vfTool:disabled {{ color:{c['sub']}; background:{c['bg']}; border:1px solid {c['step_border']}; }}

/* activation (lock) card */
QFrame#vfLock {{
    background:{c['step_bg']}; border:2px solid {c['step_hi']}; border-radius:12px;
}}
QLabel#vfLockTitle {{ color:{c['title']}; font-size:14px; font-weight:800; }}
QLabel#vfLockSub   {{ color:{c['sub']};   font-size:10px; }}
QLabel#vfLockMsg   {{ color:{c['status_off']}; font-size:10px; font-weight:700; }}
QLineEdit#vfLockInput {{
    background:{c['tool_bg']}; color:{c['title']};
    border:1px solid {c['step_border']}; border-radius:8px; padding:8px 10px; font-size:12px;
}}
QLineEdit#vfLockInput:focus {{ border:1px solid {c['step_hi']}; }}
QPushButton#vfLockBtn {{
    background:{c['accent']}; color:{c['badge_text']};
    border:none; border-radius:9px; padding:9px; font-size:12px; font-weight:800;
}}
QPushButton#vfLockBtn:hover {{ border:1px solid #FFFFFF; }}
"""


class VelocityHomePanel(QDockWidget):
    """Branded dock. steps = [(title, subtitle, callable)], tools = [(label, callable)]."""

    # Emitted whenever the user switches Nexus theme, so other surfaces (the plugin
    # toolbar) can re-colour to match. Arg = the new theme key.
    from qgis.PyQt.QtCore import pyqtSignal as _pyqtSignal
    themeChanged = _pyqtSignal(str)

    def __init__(self, iface, steps, tools, logo_path=None, theme="velocity", parent=None):
        super().__init__("Velocity Nexus", parent or iface.mainWindow())
        self.setObjectName("VelocityHomePanel")
        self.iface = iface
        # theme: explicit arg wins, else the user's last pick (QgsSettings), else default
        if theme not in THEMES:
            try:
                from qgis.core import QgsSettings
                saved = QgsSettings().value("VelocityFibre/panel_theme")
                theme = saved if saved in THEMES else "velocity"
            except Exception:
                theme = "velocity"
        self._theme = theme if theme in THEMES else "velocity"
        self._egg_clicks = []
        self._status = None
        self._theme_btns = {}
        self._last_online = False
        self._last_port = None

        self._root = QWidget()
        self._root.setObjectName("vfRoot")
        v = QVBoxLayout(self._root)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)

        v.addWidget(self._build_header(logo_path))
        # Live project-context strip — "this is your project, right now"
        v.addWidget(self._build_context_card())

        body = QVBoxLayout()
        body.setContentsMargins(14, 14, 14, 12)
        body.setSpacing(11)
        # Update banner — hidden until update_check finds a newer version
        self._update_card = self._build_update_card()
        body.addWidget(self._update_card)
        # Activation card — shown only while locked (impossible to miss, top of panel)
        self._lock_card = self._build_lock_card()
        body.addWidget(self._lock_card)
        # Client / spec profile — the panel becomes the chosen client's spec sheet
        body.addWidget(self._build_spec_section())
        self._workflow_lbl = self._label("// WORKFLOW", "vfSection")
        body.addWidget(self._workflow_lbl)
        # Smart "next step" call-to-action — tells the operator exactly what to
        # do next and runs it in one click. Updated by set_step_states().
        self._steps = list(steps)
        self._next_cb = None
        self._next_cta = QPushButton("")
        self._next_cta.setObjectName("vfNextCta")
        self._next_cta.setCursor(Qt.CursorShape.PointingHandCursor)
        self._next_cta.clicked.connect(self._on_next_cta)
        self._next_cta.setVisible(False)
        body.addWidget(self._next_cta)
        self._step_cards = []
        for i, (title, sub, cb) in enumerate(steps, 1):
            c = self._step_card(i, title, sub, cb)
            self._step_cards.append(c)
            body.addWidget(c)
        # Step cards render in their natural order. In-panel drag-reorder retired
        # 2026-07-21 (JJ: "it's bad") → replaced by the dockable-tools panel
        # (open_tools_dock). Refs kept so nothing downstream breaks.
        self._body_layout = body
        self._step_ids = [str(s[0]) for s in self._steps]
        self._step_id_widget = dict(zip(self._step_ids, self._step_cards))
        body.addSpacing(6)
        _auto_lbl = self._label("// AUTOMATIONS & TOOLS", "vfSection")
        _auto_lbl.setToolTip("Right-click → open the tools as dockable panels "
                             "(float / tab / redock, layout saved).")
        _auto_lbl.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        _auto_lbl.customContextMenuRequested.connect(
            lambda pos, w=_auto_lbl: self._layout_ctx_menu(w, pos))
        body.addWidget(_auto_lbl)
        # Tools are GROUPED into collapsible categories. A "★ FAVORITES" group is
        # rendered FIRST, holding whatever the user right-click-pinned. Favorites are
        # stored per-USER in QgsSettings, so they persist across projects + QGIS
        # restarts (each teammate keeps their own). Backwards-compatible: a flat
        # (label, cb, tip) list is wrapped into a single "TOOLS" group.
        _grouped = (tools and isinstance(tools[0], (list, tuple)) and len(tools[0]) == 2
                    and isinstance(tools[0][1], (list, tuple)))
        self._tool_groups_data = list(tools) if _grouped else [("TOOLS", list(tools))]
        self._favorites = self._load_favorites()
        # tools live in their own container so pinning can rebuild just this section
        self._tools_container = QWidget()
        self._tools_vlayout = QVBoxLayout(self._tools_container)
        self._tools_vlayout.setContentsMargins(0, 0, 0, 0)
        self._tools_vlayout.setSpacing(0)
        body.addWidget(self._tools_container)
        self._build_tools_section()
        body.addStretch(1)
        v.addLayout(body)

        # Scrollable — the panel keeps growing as we add tools, so let it scroll
        # up/down instead of overflowing the dock.
        from qgis.PyQt.QtWidgets import QScrollArea
        scroll = QScrollArea()
        scroll.setObjectName("vfScroll")
        scroll.setWidget(self._root)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet(
            "QScrollArea{background:transparent;border:none;}"
            "QScrollBar:vertical{background:transparent;width:9px;margin:0;}"
            "QScrollBar::handle:vertical{background:rgba(120,160,200,0.35);"
            "border-radius:4px;min-height:34px;}"
            "QScrollBar::handle:vertical:hover{background:rgba(46,196,241,0.75);}"
            "QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0;}"
            "QScrollBar::add-page:vertical,QScrollBar::sub-page:vertical"
            "{background:transparent;}")
        self._scroll = scroll
        self._deact_widget = self._build_deact_widget()
        self.setWidget(scroll)
        self.setMinimumWidth(258)
        self._cap_scroll_height()
        self._apply_theme()
        # Velocity heading + Windows-red ✕ on the native dock title bar. Styles the
        # QDockWidget frame only (the theme QSS above styles _root), so theme switches
        # never clobber it. Fail-open so it can never block the panel from building.
        try:
            from .nexus_dock import apply_dock_chrome
            apply_dock_chrome(self)
        except Exception:
            pass

    def _build_deact_widget(self):
        """Full-panel 'account deactivated' screen (soft wording, no input — the
        user cannot reactivate themselves; only the planning office can)."""
        w = QWidget()
        w.setObjectName("vfDeact")
        w.setStyleSheet(
            "QWidget#vfDeact{background:#0F172A;}"
            "QLabel#vfDeactIcon{font-size:46px;}"
            "QLabel#vfDeactTitle{color:#F1F5F9;font-size:16px;font-weight:800;}"
            "QLabel#vfDeactSub{color:#94A3B8;font-size:12px;}")
        lay = QVBoxLayout(w)
        lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.setContentsMargins(26, 26, 26, 26)
        lay.setSpacing(10)
        icon = QLabel("🔒")
        icon.setObjectName("vfDeactIcon")
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title = QLabel("Your account has been deactivated")
        title.setObjectName("vfDeactTitle")
        title.setWordWrap(True)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub = QLabel("Please contact the planning office to restore access.")
        sub.setObjectName("vfDeactSub")
        sub.setWordWrap(True)
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(icon)
        lay.addWidget(title)
        lay.addWidget(sub)
        return w

    def set_deactivated(self, on):
        """Swap the whole panel to the deactivated screen (on) or back to the
        normal scrollable panel (off)."""
        try:
            want = self._deact_widget if on else self._scroll
            if self.widget() is not want:
                self.setWidget(want)
        except Exception:
            pass

    def _cap_scroll_height(self):
        """Cap the scroll area to the VISIBLE screen space below where the panel
        starts, so a docked panel ALWAYS scrolls when content overflows what you
        can see — even if QGIS over-allocates the dock (some setups report a
        window far taller than the screen, so the dock fills it and the scrollbar
        would never appear)."""
        try:
            from qgis.PyQt.QtWidgets import QApplication
            sc = getattr(self, "_scroll", None)
            if sc is None:
                return
            scr = self.screen() or QApplication.primaryScreen()
            if scr is None:
                return
            geo = scr.availableGeometry()
            # how far down the screen does the scroll area actually start?
            try:
                top = sc.mapToGlobal(sc.rect().topLeft()).y()
                offset = top - geo.y()
            except Exception:
                offset = 0
            if not (0 < offset < geo.height()):
                offset = 120          # sane default before the panel is realized
            avail = geo.height() - offset - 16
            if avail > 200:
                sc.setMaximumHeight(int(avail))
        except Exception:
            pass

    def _cap_soon(self):
        """Re-cap now and again after the dock layout settles (QGIS resizes the
        dock on the next ticks, so a single immediate cap can be undone)."""
        self._cap_scroll_height()
        try:
            from qgis.PyQt.QtCore import QTimer
            QTimer.singleShot(0, self._cap_scroll_height)
            QTimer.singleShot(80, self._cap_scroll_height)
        except Exception:
            pass

    def showEvent(self, e):
        super().showEvent(e)
        self._cap_soon()

    def moveEvent(self, e):       # re-cap on dock/undock/move to another screen
        super().moveEvent(e)
        self._cap_soon()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._cap_scroll_height()

    # ── update banner ──
    def _build_update_card(self):
        card = QFrame()
        card.setObjectName("vfUpdateCard")
        card.setStyleSheet(
            "#vfUpdateCard{background:#0D1320;border:1px solid #1AE5FF;"
            "border-radius:8px;}"
            "#vfUpdateCard QLabel{color:#E8EEF8;background:transparent;"
            "font-size:11px;}"
            "#vfUpdateCard QLabel#vfUpdTitle{color:#1AE5FF;font-weight:800;"
            "font-size:12px;}"
            "#vfUpdateCard QPushButton{background:#1AE5FF;color:#04070D;"
            "font-weight:800;border:none;border-radius:6px;"
            "padding:6px 14px;}"
            "#vfUpdateCard QPushButton:hover{background:#5BF0FF;}")
        lay = QVBoxLayout(card)
        lay.setContentsMargins(10, 8, 10, 9)
        lay.setSpacing(5)
        self._upd_title = QLabel('<span style="color:#EF4444;">&#9822;</span>'
                                 '&nbsp;&nbsp;Update available')
        self._upd_title.setTextFormat(Qt.TextFormat.RichText)
        self._upd_title.setObjectName("vfUpdTitle")
        lay.addWidget(self._upd_title)
        self._upd_text = QLabel("")
        self._upd_text.setWordWrap(True)
        lay.addWidget(self._upd_text)
        row = QHBoxLayout()
        self._upd_btn = QPushButton("Update now")
        self._upd_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        row.addWidget(self._upd_btn)
        row.addStretch(1)
        lay.addLayout(row)
        card.hide()
        return card

    def show_update_banner(self, version, on_update):
        """Called by update_check when the team channel has a newer build."""
        try:
            self._upd_title.setText('<span style="color:#EF4444;">&#9822;</span>'
                                    '&nbsp;&nbsp;Update available')
            self._upd_text.setText(
                f"Velocity Nexus v{version} is out — one click takes you straight "
                "to the latest (your activation is kept).")
            try:
                self._upd_btn.clicked.disconnect()
            except Exception:
                pass

            def _go():
                self._upd_btn.setEnabled(False)
                self._upd_btn.setText("Updating…")
                on_update()

            self._upd_btn.setEnabled(True)
            self._upd_btn.setText("Update now")
            self._upd_btn.clicked.connect(_go)
            self._update_card.show()
        except RuntimeError:
            pass                        # panel mid-teardown

    @staticmethod
    def _plugin_version():
        import re
        try:
            mp = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "metadata.txt")
            with open(mp, encoding="utf-8") as f:
                m = re.search(r"^version=([\d.]+)", f.read(), flags=re.M)
            return m.group(1) if m else "?"
        except Exception:
            return "?"

    # ── header ──
    def _brand_mark(self, logo_path, size=38):
        """The Velocity Nexus brand mark: the red knight chess piece (the ♞ font
        glyph — a clean, classic knight) with a soft red glow. The glyph renders
        far better than a hand-drawn path. Falls back to logo.png / a 'V' box."""
        from qgis.PyQt.QtWidgets import QLabel, QWidget, QVBoxLayout
        try:
            from qgis.PyQt.QtGui import QColor, QFont
            from qgis.PyQt.QtWidgets import QGraphicsDropShadowEffect
            lab = QLabel("♞")
            lab.setObjectName("vfMark")
            lab.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lab.setFixedSize(size, size)
            f = QFont()
            f.setPixelSize(int(size * 0.92))
            f.setBold(True)
            lab.setFont(f)
            lab.setStyleSheet("color:#EF4444; background:transparent;")
            lab.setToolTip("Velocity Nexus")
            lab.mousePressEvent = self._on_logo_click   # 5 fast clicks = Easter egg
            glow = QGraphicsDropShadowEffect(lab)
            glow.setBlurRadius(12)
            glow.setOffset(0, 0)
            glow.setColor(QColor(239, 68, 68, 170))   # soft red glow
            lab.setGraphicsEffect(glow)
            return lab
        except Exception:
            pass
        if logo_path and os.path.exists(logo_path):
            lab = QLabel()
            lab.setPixmap(QPixmap(logo_path).scaledToHeight(
                size, Qt.TransformationMode.SmoothTransformation))
            return lab
        mark = QWidget()
        mark.setObjectName("vfVmark")
        mark.setFixedSize(size, size)
        ml = QVBoxLayout(mark)
        ml.setContentsMargins(0, 0, 0, 0)
        vlab = QLabel("V")
        vlab.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ml.addWidget(vlab)
        return mark

    def _build_header(self, logo_path):
        h = QWidget()
        h.setObjectName("vfHeader")
        lay = QVBoxLayout(h)
        lay.setContentsMargins(14, 12, 14, 11)
        lay.setSpacing(3)

        top = QHBoxLayout()
        top.setSpacing(10)
        top.addWidget(self._brand_mark(logo_path, 36),
                      alignment=Qt.AlignmentFlag.AlignVCenter)
        words = QVBoxLayout()
        words.setSpacing(0)
        words.addWidget(self._label("VELOCITY", "vfWordTop"))
        words.addWidget(self._label("NEXUS", "vfWordBot"))
        top.addLayout(words)
        top.addStretch(1)
        # profile chip — opens the personalization card (set via set_profile)
        self._chip = QPushButton("")
        self._chip.setObjectName("vfChip")
        self._chip.setCursor(Qt.CursorShape.PointingHandCursor)
        self._chip.setToolTip("Your profile, theme & sign-out")
        self._chip.setVisible(False)
        self._chip.clicked.connect(self._on_chip)
        top.addWidget(self._chip, alignment=Qt.AlignmentFlag.AlignTop)
        ver = QLabel(f"v{self._plugin_version()}")
        ver.setObjectName("vfVersion")
        ver.setStyleSheet("color:#7E8DB0;font-size:10px;font-weight:700;")
        ver.setToolTip("Installed Velocity Nexus version")
        top.addWidget(ver, alignment=Qt.AlignmentFlag.AlignTop)
        # 🔄 Check for updates — pulls the latest team build on demand (no 30-min
        # wait); shows "you're on the latest" or the one-click update prompt.
        self._chk_cb = None
        chk = QPushButton("🔄")
        chk.setObjectName("vfChkUpd")
        chk.setCursor(Qt.CursorShape.PointingHandCursor)
        chk.setToolTip("Check for updates now")
        chk.setStyleSheet(
            "QPushButton#vfChkUpd{background:transparent;color:#7E8DB0;"
            "border:none;font-size:12px;padding:0 2px;}"
            "QPushButton#vfChkUpd:hover{color:#22D3EE;}")
        chk.clicked.connect(self._on_check_updates)
        self._chk_btn = chk
        top.addWidget(chk, alignment=Qt.AlignmentFlag.AlignTop)
        lay.addLayout(top)
        lay.addWidget(self._label("FTTH Network Planner", "vfTagline"))

        # 💾 Backup Project — its own row, right-aligned, just above the Ticket/Menu row
        # (the red-box gap). Labeled so it's clear, on its own row so it never crowds.
        brow = QHBoxLayout()
        brow.addStretch(1)
        bkp = QPushButton("💾  Backup Project")
        bkp.setObjectName("vfBackup")
        bkp.setCursor(Qt.CursorShape.PointingHandCursor)
        bkp.setToolTip("Back up this project + every layer into one self-contained, "
                       "openable folder (GeoPackage or Shapefiles) — ready for anything.")
        bkp.setStyleSheet(
            "QPushButton#vfBackup{background:#0a2730;color:#22D3EE;border:1px solid #19414c;"
            "border-radius:6px;padding:5px 12px;font-weight:700;font-size:11px;}"
            "QPushButton#vfBackup:hover{background:#0e3a45;border:1px solid #22D3EE;}")
        bkp.clicked.connect(self._on_backup)
        self._backup_btn = bkp
        brow.addWidget(bkp)
        lay.addLayout(brow)

        # ticket + status row
        row = QHBoxLayout()
        row.setSpacing(6)
        self._status = self._label("●  Bridge: checking…", "vfStatus")
        row.addWidget(self._status)
        row.addStretch(1)
        # Red ticket button (left of the menu) — log a bug / feature request that
        # goes straight to the planning office. (Theme switching moved into ⚙ Menu.)
        self._ticket_cb = None
        tkt = QPushButton("🎫  Ticket")
        tkt.setObjectName("vfTicket")
        tkt.setCursor(Qt.CursorShape.PointingHandCursor)
        tkt.setToolTip("Log a ticket — report a bug or request a feature you'd like "
                       "built into the tool. It goes straight to the planning office.")
        tkt.clicked.connect(self._on_ticket)
        self._ticket_btn = tkt
        row.addWidget(tkt)
        # ⚙ Settings / menu button — opens the full Velocity Nexus menu + settings
        self._settings_cb = None
        gear = QPushButton("⚙ Menu")
        gear.setObjectName("vfGear")
        gear.setCursor(Qt.CursorShape.PointingHandCursor)
        gear.setToolTip("All tools, settings & help — every Velocity Nexus tool, "
                        "Report a Problem, About & Activation, updates "
                        "(tip: press Ctrl+Shift+P for the command palette)")
        gear.clicked.connect(self._on_settings)
        self._gear_btn = gear
        row.addWidget(gear)
        lay.addLayout(row)
        return h

    # ── live project context strip ──
    def _build_context_card(self):
        """Hero block: live project identity + a colour-coded HLD score ring +
        a row of at-a-glance KPI chips. First thing the operator reads."""
        card = QFrame()
        card.setObjectName("vfContext")
        lay = QVBoxLayout(card)
        lay.setContentsMargins(14, 11, 14, 12)
        lay.setSpacing(9)

        # row 1 — project name (+ HLD verdict line) on the left, score ring right
        top = QHBoxLayout()
        top.setSpacing(11)
        pcol = QVBoxLayout()
        pcol.setSpacing(2)
        self._ctx_project = QLabel("📂  No project open")
        self._ctx_project.setObjectName("vfCtxProject")
        self._ctx_project.setWordWrap(True)
        self._ctx_stats = QLabel("Open a project to see live stats")
        self._ctx_stats.setObjectName("vfCtxStats")
        self._ctx_stats.setWordWrap(True)
        pcol.addWidget(self._ctx_project)
        pcol.addWidget(self._ctx_stats)
        top.addLayout(pcol, 1)
        self._score_ring = _ScoreRing(64)
        top.addWidget(self._score_ring, 0, Qt.AlignmentFlag.AlignVCenter)
        lay.addLayout(top)

        # row 2 — workflow completion bar ("how far through the build am I?")
        from qgis.PyQt.QtWidgets import QProgressBar
        self._prog_lbl = QLabel("// WORKFLOW")
        self._prog_lbl.setObjectName("vfProgLbl")
        lay.addWidget(self._prog_lbl)
        self._prog_bar = QProgressBar()
        self._prog_bar.setObjectName("vfProg")
        self._prog_bar.setTextVisible(False)
        self._prog_bar.setFixedHeight(7)
        self._prog_bar.setRange(0, 100)
        self._prog_bar.setValue(0)
        lay.addWidget(self._prog_bar)

        # row 3 — KPI chips (value over caption)
        krow = QHBoxLayout()
        krow.setSpacing(6)
        self._kpi_chips = {}
        for key, cap in (('onts', 'ONTs'), ('poles', 'POLES'),
                         ('erven', 'ERVEN'), ('splitters', 'STS')):
            chip = QFrame()
            chip.setObjectName("vfKpi")
            cl = QVBoxLayout(chip)
            cl.setContentsMargins(8, 6, 8, 6)
            cl.setSpacing(0)
            val = QLabel("—")
            val.setObjectName("vfKpiVal")
            capl = QLabel(cap)
            capl.setObjectName("vfKpiCap")
            cl.addWidget(val)
            cl.addWidget(capl)
            self._kpi_chips[key] = val
            krow.addWidget(chip)
        lay.addLayout(krow)
        return card

    def set_context(self, ctx):
        """Update the context strip. ctx keys (all optional): project_name,
        layer_count, buildings, erven, poles, splitters, onts, hld (display str).
        Caller MUST pass cheap data only (featureCount/cached) — never iterate
        features here (freezes the UI)."""
        try:
            ctx = ctx or {}
            name = ctx.get('project_name') or 'No project open'
            proj_txt = '📂  ' + name
            # Dev-only bridge indicator: only the dev machine has bridge_port.txt,
            # so teammates never see this. Reads the configured port (no network
            # call → never blocks the UI). Fail-silent.
            try:
                import os as _os
                _bp = r'C:/Temp/bridge_port.txt'
                if _os.path.isfile(_bp):
                    with open(_bp, encoding='utf-8') as _f:
                        _port = _f.read().strip()
                    if _port:
                        proj_txt += f'   ·   🔌 Bridge {_port}'
            except Exception:
                pass
            self._ctx_project.setText(proj_txt)

            # HLD score → ring (accept a numeric hld_score, else parse digits
            # out of the hld display string, e.g. "HLD 73%")
            score = ctx.get('hld_score')
            if score is None and ctx.get('hld'):
                import re as _re
                m = _re.search(r'(\d{1,3})', str(ctx.get('hld')))
                score = int(m.group(1)) if m else None
            self._score_ring.set_score(score)
            if score is None:
                lc = ctx.get('layer_count')
                self._ctx_stats.setText(f'{lc} layers — run an audit for HLD score'
                                        if lc else 'Open a project to see live stats')
            else:
                verdict = ('On track' if score >= 90 else
                           'Needs work' if score >= 70 else 'At risk')
                self._ctx_stats.setText(f'HLD readiness · {verdict}')

            # KPI chips
            for key, lbl in self._kpi_chips.items():
                v = ctx.get(key)
                lbl.setText(f'{v:,}' if v is not None and isinstance(v, (int, float)) else '—')
        except Exception:
            pass

    # ── client / spec profile ────────────────────────────────────────────────
    def _active_client(self):
        try:
            from qgis.core import QgsSettings
            k = QgsSettings().value("VelocityFibre/client", "fibertime")
            return k if k in CLIENT_SPECS else "fibertime"
        except Exception:
            return "fibertime"

    def _build_spec_section(self):
        """Client switcher + live spec card — the panel as the chosen client's
        spec sheet (split architecture, targets, span limits, SKUs)."""
        wrap = QWidget()
        lay = QVBoxLayout(wrap)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(7)
        lay.addWidget(self._label("// CLIENT SPEC", "vfSection"))
        row = QHBoxLayout()
        row.setSpacing(5)
        self._client_btns = {}
        for key, spec in CLIENT_SPECS.items():
            b = QPushButton(spec["label"])
            b.setObjectName("vfClient")
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setToolTip(f"Switch to {spec['label']} specification — split ratio, "
                         "ONT/PON target, span limits & cable/pole/ONT SKUs")
            b.clicked.connect(lambda _=False, k=key: self.set_client(k))
            self._client_btns[key] = b
            row.addWidget(b)
        lay.addLayout(row)
        self._spec_card = QFrame()
        self._spec_card.setObjectName("vfSpec")
        sl = QVBoxLayout(self._spec_card)
        sl.setContentsMargins(11, 9, 11, 10)
        sl.setSpacing(3)
        self._spec_lines = []
        for _ in range(4):
            lab = QLabel("")
            lab.setObjectName("vfSpecLine")
            lab.setTextFormat(Qt.TextFormat.RichText)
            lab.setWordWrap(True)
            sl.addWidget(lab)
            self._spec_lines.append(lab)
        lay.addWidget(self._spec_card)
        self.set_client(self._active_client(), persist=False)
        return wrap

    def set_client(self, key, persist=True):
        """Switch the active client → repaint the spec card + remember the choice."""
        if key not in CLIENT_SPECS:
            return
        self._client = key
        s = CLIENT_SPECS[key]
        for k, b in getattr(self, "_client_btns", {}).items():
            b.setProperty("active", "true" if k == key else "false")
            b.style().unpolish(b)
            b.style().polish(b)
        lines = [
            f"🔀 <b>{s['splitter']}</b>",
            f"🎯 {s['cap']}" + (f" · {s['zone']}" if s.get("zone") else ""),
            f"📏 Spans: drop ≤ <b>{s['drop_max_m']}m</b>"
            f" · feeder/span ≤ <b>{s['feeder_max_m']}m</b>",
            f"🧵 {s['cable']}<br>📍 {s['pole']} · ONT {s['ont']}",
        ]
        for lab, txt in zip(self._spec_lines, lines):
            lab.setText(txt)
        if persist:
            try:
                from qgis.core import QgsSettings
                QgsSettings().setValue("VelocityFibre/client", key)
            except Exception:
                pass

    def _on_settings(self):
        if self._settings_cb:
            self._settings_cb(self._gear_btn)

    def set_settings_callback(self, cb):
        """cb(anchor_widget) is called when the ⚙ button is clicked."""
        self._settings_cb = cb

    def _on_ticket(self):
        if callable(getattr(self, "_ticket_cb", None)):
            self._ticket_cb(self._ticket_btn)

    def set_ticket_callback(self, cb):
        """cb(anchor_widget) is called when the 🎫 Ticket button is clicked."""
        self._ticket_cb = cb

    def _on_check_updates(self):
        if callable(getattr(self, "_chk_cb", None)):
            self._chk_cb()

    def set_check_updates_callback(self, cb):
        """cb() is called when the 🔄 Check-for-updates button is clicked."""
        self._chk_cb = cb

    def _on_backup(self):
        """💾 Backup — open the self-contained project-backup dialog."""
        try:
            from . import project_backup
        except Exception:
            import project_backup
        try:
            project_backup.open_backup_dialog(self.iface)
        except Exception as e:
            try:
                self.iface.messageBar().pushWarning("Backup Project", str(e)[:200])
            except Exception:
                pass

    def set_profile(self, name, avatar_color, on_click):
        """Show the 👤 chip for the signed-in user. on_click(anchor) opens the
        profile card. Pass name=None to hide the chip."""
        self._chip_cb = on_click
        if not name:
            try:
                self._chip.setVisible(False)
            except Exception:
                pass
            return
        try:
            from .fibre_automation.nexus_profile import themes as _th
            ini = _th.initials(name)
        except Exception:
            ini = (name[:2] or "?").upper()
        self._chip.setText(f"  {ini}  ")
        self._chip.setVisible(True)
        self._chip.setStyleSheet(
            f"QPushButton#vfChip{{background:{avatar_color};color:#fff;"
            "border:none;border-radius:11px;font-size:11px;font-weight:800;"
            "min-height:22px;padding:0 4px;}"
            f"QPushButton#vfChip:hover{{border:2px solid #FFFFFF;}}")
        self._chip.setToolTip(f"{name} — profile, theme & sign-out")

    def _on_chip(self):
        cb = getattr(self, "_chip_cb", None)
        if callable(cb):
            cb(self._chip)

    # ── activation (lock) card ──
    def _build_lock_card(self):
        """A prominent 'enter password to unlock' card. Hidden once activated.
        Wired to self._activate_cb(password) which the plugin sets."""
        self._activate_cb = None
        card = QFrame()
        card.setObjectName("vfLock")
        lay = QVBoxLayout(card)
        lay.setContentsMargins(14, 13, 14, 13)
        lay.setSpacing(8)
        title = QLabel("🔒  Activation required")
        title.setObjectName("vfLockTitle")
        lay.addWidget(title)
        sub = QLabel("Enter the company password once to unlock every tool on this machine.")
        sub.setObjectName("vfLockSub")
        sub.setWordWrap(True)
        lay.addWidget(sub)
        self._pw_edit = QLineEdit()
        self._pw_edit.setObjectName("vfLockInput")
        self._pw_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self._pw_edit.setPlaceholderText("Company password")
        lay.addWidget(self._pw_edit)
        self._lock_msg = QLabel("")
        self._lock_msg.setObjectName("vfLockMsg")
        self._lock_msg.setWordWrap(True)
        lay.addWidget(self._lock_msg)
        btn = QPushButton("Unlock")
        btn.setObjectName("vfLockBtn")
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        lay.addWidget(btn)
        btn.clicked.connect(self._on_unlock_clicked)
        self._pw_edit.returnPressed.connect(self._on_unlock_clicked)
        return card

    def _on_unlock_clicked(self):
        if not self._activate_cb:
            return
        ok, msg = self._activate_cb(self._pw_edit.text())
        if ok:
            self._pw_edit.clear()
            self.set_locked(False)
        else:
            self._lock_msg.setText(msg or "Wrong password.")
            self._pw_edit.selectAll()

    def set_locked(self, locked, on_activate=None):
        """Show/hide the activation card. on_activate(password) -> (ok, message)."""
        if on_activate is not None:
            self._activate_cb = on_activate
        try:
            self._lock_card.setVisible(locked)
        except RuntimeError:
            pass

    def lock_message(self, text):
        try:
            self._lock_msg.setText(text or "")
        except RuntimeError:
            pass

    # ── widgets ──
    def _label(self, text, obj):
        lab = QLabel(text)
        lab.setObjectName(obj)
        return lab

    def _step_card(self, n, title, sub, cb):
        card = QFrame()
        card.setObjectName("vfStep")
        card.setCursor(Qt.CursorShape.PointingHandCursor)
        card.setToolTip(f"{title} — {sub}")   # proper hover description
        lay = QHBoxLayout(card)
        lay.setContentsMargins(0, 0, 10, 0)
        lay.setSpacing(0)

        stripe = QFrame()
        stripe.setObjectName("vfStripe")
        stripe.setFixedWidth(5)
        lay.addWidget(stripe)
        card._stripe = stripe

        inner = QHBoxLayout()
        inner.setContentsMargins(9, 8, 0, 8)
        inner.setSpacing(11)
        num = QLabel(str(n))
        num.setObjectName("vfStepNum")
        num.setFixedSize(28, 28)
        num.setAlignment(Qt.AlignmentFlag.AlignCenter)
        inner.addWidget(num)
        card._num = num
        card._step_index = n - 1

        txt = QVBoxLayout()
        txt.setSpacing(1)
        t = QLabel(f"{_icon_for(title)}  {title}")
        t.setObjectName("vfStepTitle")
        s = QLabel(sub)
        s.setObjectName("vfStepSub")
        txt.addWidget(t)
        txt.addWidget(s)
        inner.addLayout(txt)
        inner.addStretch(1)
        lay.addLayout(inner)

        chev = QLabel("›")
        chev.setObjectName("vfStepChev")
        lay.addWidget(chev)
        card._chev = chev

        if cb:
            card.mousePressEvent = lambda _e, f=cb: self._safe(f)
        return card

    def set_step_states(self, states):
        """Render 'you are here' on the workflow cards.

        states: list of 'done' | 'current' | 'todo', one per step card. Done
        cards show a ✓ badge + accent border; the current card is highlighted
        with a ▶; todo cards are dimmed. Driven by real project state.
        """
        glow_rgb = THEMES[self._theme].get('step_hi', '#00D4FF')
        for card in zip(getattr(self, '_step_cards', []), states):
            card, st = card
            try:
                # JJ: no completion check-marks — always show the step number;
                # only the 'current' card is highlighted ("you are here").
                vis = "current" if st == "current" else "todo"
                card.setProperty("stepState", vis)
                card._num.setText(str(card._step_index + 1))
                card._chev.setText("▶" if st == "current" else "›")
                # re-polish so the property selectors re-apply (stripe colour
                # tracks state: done=green, current=accent, todo=dim)
                for w in (card, card._num, card._chev, card._stripe):
                    w.style().unpolish(w)
                    w.style().polish(w)
                # Soft accent glow on the current card only — "you are here"
                # pops. Qt QSS can't do box-shadow, so use a graphics effect.
                self._set_card_glow(card, st == "current", glow_rgb)
            except Exception:
                pass
        # JJ: drop the auto "X of Y done / %" completion readout (the check-mark
        # feature) — it guessed done-state from the project and read as confusing
        # and unreliable. Keep a plain "WORKFLOW" header, hide the % bar.
        try:
            self._prog_lbl.setText("// WORKFLOW")
            self._prog_bar.setVisible(False)
        except Exception:
            pass
        self._update_next_cta(list(states))

    def _update_next_cta(self, states):
        """Point the 'Next' CTA at the current (or first todo) step."""
        cta = getattr(self, '_next_cta', None)
        if cta is None:
            return
        try:
            idx = states.index('current') if 'current' in states \
                else (states.index('todo') if 'todo' in states else -1)
            if idx < 0 or idx >= len(self._steps):
                # no check-mark "all complete" state — just hide the CTA
                self._next_cb = None
                cta.setVisible(False)
                return
            title = self._steps[idx][0]
            cta.setText(f"▶  Next:  {title}")
            cta.setProperty("done", "false")
            self._next_cb = self._steps[idx][2]
            cta.style().unpolish(cta)
            cta.style().polish(cta)
            cta.setVisible(True)
        except Exception:
            cta.setVisible(False)

    def _on_next_cta(self):
        if self._next_cb:
            self._safe(self._next_cb)

    def _set_card_glow(self, card, on, rgb):
        """Attach (or clear) a soft accent drop-shadow glow on a step card."""
        if not on:
            card.setGraphicsEffect(None)
            return
        eff = QGraphicsDropShadowEffect(card)
        eff.setBlurRadius(30)   # Aurora Signature — more glow
        eff.setOffset(0, 0)
        col = QColor(rgb)
        col.setAlpha(175)
        eff.setColor(col)
        card.setGraphicsEffect(eff)

    # ── Favorites (right-click a tool to pin) — per-user, persists across projects ──
    _FAV_KEY = "velocity_nexus/favorite_tools"

    def _load_favorites(self):
        """Read pinned tool labels from QgsSettings (per QGIS profile → survives project
        switches + restarts). Tolerates the single-item-string quirk of QSettings."""
        try:
            from qgis.core import QgsSettings
            v = QgsSettings().value(self._FAV_KEY, [])
        except Exception:
            return []
        if v is None:
            return []
        if isinstance(v, str):
            return [v] if v else []
        return [str(x) for x in v]

    def _save_favorites(self):
        try:
            from qgis.core import QgsSettings
            QgsSettings().setValue(self._FAV_KEY, list(self._favorites))
        except Exception:
            pass

    def _toggle_favorite(self, label):
        if label in self._favorites:
            self._favorites = [x for x in self._favorites if x != label]
        else:
            self._favorites = list(self._favorites) + [label]
        self._save_favorites()
        self._build_tools_section()

    def _tool_ctx_menu(self, label, btn, pos):
        from qgis.PyQt.QtWidgets import QMenu
        m = QMenu(btn)
        if label in self._favorites:
            act = m.addAction("☆  Remove from Favorites")
        else:
            act = m.addAction("★  Pin to Favorites")
        act.triggered.connect(lambda _=False, l=label: self._toggle_favorite(l))
        m.exec(btn.mapToGlobal(pos))

    def _layout_ctx_menu(self, widget, pos):
        from qgis.PyQt.QtWidgets import QMenu
        m = QMenu(widget)
        m.addAction("⊞  Open tools as dockable panels (beta)", self.open_tools_dock)
        m.addAction("↺  Reset dockable-tools layout", self.reset_tools_dock_layout)
        m.exec(widget.mapToGlobal(pos))

    def reset_layout(self):
        """Rebuild the tools section to defaults (in-panel drag-reorder retired; kept
        as a harmless rebuild in case anything still calls it)."""
        try:
            self._build_tools_section()
        except Exception:
            pass

    def _build_tools_section(self):
        """(Re)build the tools area: a ★ FAVORITES group (if any) then the normal
        categories. Called on init and whenever a favorite is toggled."""
        from qgis.PyQt.QtWidgets import QGridLayout, QSizePolicy
        # drop tool-group drag handlers from the previous build (they point at widgets
        # we're about to delete); the step-card dragger (scope 'steps') is kept.
        if hasattr(self, "_vf_draggers"):
            self._vf_draggers = [d for d in self._vf_draggers
                                 if not str(getattr(d, "scope", "")).startswith("tool:")]
        lay = self._tools_vlayout
        while lay.count():                       # clear previous build
            it = lay.takeAt(0)
            w = it.widget()
            if w:
                w.setParent(None)
                w.deleteLater()
        # registry so a favorite can be resolved back to its (cb, tip)
        self._tool_registry = {}
        for grp in self._tool_groups_data:
            for it in grp[1]:
                self._tool_registry[it[0]] = (it[1], it[2] if len(it) > 2 else None)

        def _tool_grid(items):
            w = QWidget()
            g = QGridLayout(w)
            g.setSpacing(6)
            g.setContentsMargins(0, 2, 8, 8)
            g.setColumnStretch(0, 1)
            g.setColumnStretch(1, 1)
            btns = {}
            for i, it in enumerate(items):
                tip = it[2] if len(it) > 2 else None
                btn = self._tool_button(it[0], it[1], tip)
                btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
                btn.setMinimumWidth(70)
                g.addWidget(btn, i // 2, i % 2)
                btns[it[0]] = btn
            return w, g, btns

        def _apply_tool_order(cat, items):
            # drag-reorder retired 2026-07-21 (replaced by the dockable-tools panel,
            # open_tools_dock) — tools render in their natural order.
            return items

        def _install_tool_drag(cat, grid, btns):
            return    # no-op: in-panel drag-reorder removed

        display = []
        fav_items = [(l, self._tool_registry[l][0], self._tool_registry[l][1])
                     for l in self._favorites if l in self._tool_registry]
        if fav_items:
            display.append(("★ FAVORITES", fav_items))
        display += list(self._tool_groups_data)

        self._tool_groups = []
        for gi, grp in enumerate(display):
            cat = grp[0]
            items = _apply_tool_order(cat, grp[1])
            cont, grid, btns = _tool_grid(items)
            _install_tool_drag(cat, grid, btns)
            opened = (gi == 0)               # first group (Favorites if present) open
            cont.setVisible(opened)
            hdr = QPushButton(("▾  " if opened else "▸  ") + f"{cat}  ({len(items)})")
            hdr.setObjectName("vfToolCat")
            hdr.setCheckable(True)
            hdr.setChecked(opened)
            hdr.setCursor(Qt.CursorShape.PointingHandCursor)
            hdr.setStyleSheet(
                "QPushButton{text-align:left;padding:8px 8px;border:none;"
                "background:transparent;color:#8fa6bd;font-weight:800;"
                "font-size:10px;letter-spacing:1.2px;}"
                "QPushButton:hover{color:#22d3ee;}")

            def _tog(on, c=cont, h=hdr, n=cat, k=len(items)):
                c.setVisible(on)
                h.setText(("▾  " if on else "▸  ") + f"{n}  ({k})")
            hdr.toggled.connect(_tog)
            lay.addWidget(hdr)
            lay.addWidget(cont)
            self._tool_groups.append((hdr, cont))

    def open_tools_dock(self):
        """Step 3 — pop the tool groups into an IDE-style DockArea (float / tab /
        redock, layout saved to QgsSettings). ADDITIVE + fail-open: the home panel's
        own tools stay intact; any error just returns None and changes nothing.
        Kill-switch: set VF_NO_DOCK=1 to disable the dockable-tools panel entirely."""
        import os
        if os.environ.get("VF_NO_DOCK") == "1":
            try:
                self.iface.messageBar().pushInfo(
                    "Velocity Nexus", "Dockable tools disabled (VF_NO_DOCK=1).")
            except Exception:
                pass
            return None
        try:
            from qgis.PyQt.QtWidgets import QDockWidget
            from qgis.PyQt.QtCore import Qt
            from qgis.PyQt import sip
            try:
                from . import nexus_dock as nd
            except ImportError:
                from FiberNetworkAutomation import nexus_dock as nd
            existing = getattr(self, "_tools_dock", None)
            if existing is not None and not sip.isdeleted(existing):
                existing.show(); existing.raise_()
                return existing
            groups = []
            for grp in getattr(self, "_tool_groups_data", []):
                name = str(grp[0]).lstrip("★ ").strip() or "Tools"
                btns = [nd.make_tool_button(it[0], it[1]) for it in grp[1] if len(it) >= 2]
                if btns:
                    groups.append((name, nd.make_group_body(name, btns)))
            if not groups:
                return None
            area, docks = nd.build_dockarea(groups)
            nd.apply_polish(area, docks)
            dock = QDockWidget("Velocity Nexus — Tools", self.iface.mainWindow())
            dock.setObjectName("VelocityNexusToolsDock")
            dock.setWidget(area)
            self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dock)
            nd.apply_dock_chrome(dock)
            nd.restore_layout(area)                       # last saved arrangement
            dock.visibilityChanged.connect(
                lambda vis, a=area: None if vis else nd.save_layout(a))
            self._tools_dock = dock
            self._tools_dockarea = area
            dock.show(); dock.raise_()
            return dock
        except Exception:
            return None

    def reset_tools_dock_layout(self):
        """'Reset layout' — clear the saved DockArea arrangement + rebuild the dock."""
        try:
            from . import nexus_dock as nd
        except ImportError:
            from FiberNetworkAutomation import nexus_dock as nd
        try:
            nd.clear_layout()
            d = getattr(self, "_tools_dock", None)
            if d is not None:
                from qgis.PyQt import sip
                if not sip.isdeleted(d):
                    self.iface.removeDockWidget(d); d.deleteLater()
            self._tools_dock = None
            return self.open_tools_dock()
        except Exception:
            return None

    def _tool_button(self, label, cb, tip=None):
        fav = label in getattr(self, "_favorites", [])
        b = QPushButton(("★ " + label) if fav else label)
        b.setObjectName("vfTool")
        b.setProperty("_toollabel", label)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        hint = "Right-click to pin/unpin ★"
        b.setToolTip((tip + "\n\n" + hint) if tip else hint)
        if cb:
            b.clicked.connect(lambda _=False, f=cb: self._safe(f))
        # right-click → pin/unpin
        b.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        b.customContextMenuRequested.connect(
            lambda pos, l=label, btn=b: self._tool_ctx_menu(l, btn, pos))
        return b

    def _safe(self, fn):
        try:
            fn()
        except Exception as e:  # never let a panel click raise into the UI
            try:
                self.iface.messageBar().pushWarning("Velocity Nexus", str(e)[:200])
            except Exception:
                pass

    # ── theming ──
    def _apply_theme(self):
        c = THEMES[self._theme]
        self._root.setStyleSheet(_build_qss(c))
        for key, btn in self._theme_btns.items():
            btn.setProperty("active", "true" if key == self._theme else "false")
            btn.style().unpolish(btn)
            btn.style().polish(btn)
        # re-apply status colour (it's set inline) for the new palette
        self.set_bridge(self._last_online, self._last_port)

    def set_theme(self, name):
        if name in THEMES and name != self._theme:
            self._theme = name
            self._apply_theme()
            try:
                from qgis.core import QgsSettings
                QgsSettings().setValue("VelocityFibre/panel_theme", name)
            except Exception:
                pass
            # Tell the toolbar (and anything else listening) to re-colour to match.
            try:
                self.themeChanged.emit(name)
            except Exception:
                pass

    # ── Easter egg: click the knight logo 5× fast → a themed reveal ──────────
    def _on_logo_click(self, _ev):
        import time
        now = time.monotonic()
        self._egg_clicks = [t for t in getattr(self, "_egg_clicks", [])
                            if now - t < 2.0] + [now]
        if len(self._egg_clicks) >= 5:
            self._egg_clicks = []
            self._reveal_egg()

    def _reveal_egg(self):
        try:
            from qgis.PyQt.QtWidgets import QLabel
            from qgis.PyQt.QtCore import QTimer
            c = THEMES.get(self._theme, {})
            egg = c.get("egg") or "✦"
            lab = QLabel(f"♞  {egg}", self)
            lab.setObjectName("vfEgg")
            lab.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lab.setStyleSheet(
                f"background:{c.get('step_bg', '#111')};"
                f"color:{c.get('step_hi', '#19E5FF')};"
                f"border:2px solid {c.get('step_hi', '#19E5FF')};"
                "border-radius:12px; padding:11px 18px; font-size:13px; font-weight:800;")
            lab.adjustSize()
            lab.move(max(8, (self.width() - lab.width()) // 2), 64)
            lab.show()
            lab.raise_()
            QTimer.singleShot(2600, lab.deleteLater)
        except Exception:
            pass
        # …and play the theme's distinct animated effect over the visible panel.
        try:
            host = (self._scroll.viewport()
                    if getattr(self, "_scroll", None) is not None else self)
            try:
                from .nexus_eggs import play as _egg_play
            except ImportError:
                from nexus_eggs import play as _egg_play
            _egg_play(host, self._theme)
        except Exception:
            pass

    def apply_user_theme(self, theme_name, accent_hex=None):
        """Recolour the whole panel to a chosen preset + optional custom accent
        (live, no restart). Builds a derived palette so all 6 presets work, not
        just the two built-ins."""
        # Full-palette themes (the 12 in THEMES incl. the exotic pack) apply
        # their WHOLE rich palette via set_theme — not a 2-colour derivation. A
        # deliberate custom accent (accent_hex set) still routes to the derived
        # blend below so the user can recolour any theme.
        if theme_name in THEMES and not accent_hex:
            self.set_theme(theme_name)
            return
        try:
            from .fibre_automation.nexus_profile import themes as _th
        except Exception:
            try:
                from fibre_automation.nexus_profile import themes as _th
            except Exception:
                _th = None
        # base palette: the chosen preset's bg, on the velocity layout
        base = dict(THEMES.get(theme_name if theme_name in THEMES
                               else "velocity"))
        if _th is not None and theme_name in _th.PRESETS:
            base["bg"] = _th.PRESETS[theme_name]["bg"]
        accent = accent_hex or (
            _th.PRESETS[theme_name]["accent"] if _th and theme_name in _th.PRESETS
            else base.get("accent"))
        if accent and _th is not None:
            lad = _th.derive_accent(accent)
            # repaint every accent-driven token
            for k in ("accent", "step_hi", "tool_hi", "status_on"):
                if k in base:
                    base[k] = accent
            if "step_hover" in base:
                base["step_hover"] = lad["hover"]
        try:
            self._root.setStyleSheet(_build_qss(base))
            self._root.repaint()
        except Exception:
            pass

    # ── public ──
    def set_bridge_visible(self, visible):
        """Show/hide the bridge-status line. The bridge is a dev-only Claude
        control channel teammates don't have, so on team machines it's hidden
        (otherwise it sticks at 'Bridge: checking…' forever — confusing noise)."""
        try:
            if self._status is not None:
                self._status.setVisible(bool(visible))
        except (RuntimeError, AttributeError):
            pass

    def set_bridge(self, online, port=None):
        self._last_online, self._last_port = online, port
        if self._status is None:
            return
        try:
            c = THEMES[self._theme]
            if online:
                self._status.setText("●  Bridge online" + (f" · {port}" if port else ""))
                self._status.setStyleSheet(f"color:{c['status_on']}; font-size:10px;")
            else:
                self._status.setText("●  Bridge offline")
                self._status.setStyleSheet(f"color:{c['status_off']}; font-size:10px;")
        except (RuntimeError, AttributeError):
            pass
