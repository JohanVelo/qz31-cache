"""Categorised styles for the canonical layers — harvested, not invented.

The colours below were read out of Lulekani's and Matiko's own `.qgz` files on
2026-09-11, not chosen. Where the two towns agree, that is the convention; where
they disagree it is recorded as a disagreement rather than resolved by taste.

⛔ THE FINDING THAT SHAPED THIS MODULE
--------------------------------------
Both projects carry 15 categorised renderers between them and **not one has an
all-other-values catch-all**. A feature whose value is not in the enumerated
list draws NOTHING — no warning, no placeholder, an empty patch of map. Add one
PON to Lulekani and it is invisible; Matiko goes further and carries a `NULL`
category with `render="false"`, so its null-size feeder cables are hidden on
purpose and indistinguishable from absent.

This repo has already shipped that bug once: ticking a splitter layer drew
nothing, on every project that had one. So here the catch-all is not an option
a caller can forget — `categorized_qml()` always writes one, and
`has_catch_all()` exists so a test can prove it.

Two kinds of categorised layer, and only one is a style
------------------------------------------------------
    VOCABULARY-driven   pole thickness, fibre size — a short, stable list that
                        means the same thing in every town. A real style, and
                        what this module carries.

    DATA-driven         zone_id / zone_name, with 82 categories in Lulekani and
                        56 in Matiko. That is one town's data, not a look.
                        Baking it into a benchmark would ship Lulekani's zone
                        list to every other project, so these are GENERATED from
                        whatever the layer actually contains, at apply time.

Writes QML text. No QGIS import, so it is testable headless.
"""
from __future__ import annotations

import colorsys
import re

#: Colours read from the two projects. `towns` is the evidence; `agreed` says
#: whether they actually agree, so a reader can tell a convention from a guess.
#:
#: Pole thickness is unanimous across two towns and four layers: the thinner
#: product is black, the thicker one red. Fibre size is not - 144F is amber in
#: Lulekani and red in Matiko - so the disagreement is recorded and Lulekani's
#: is used only because it is the fuller set (it alone styles 12F).
HARVESTED = {
    "pole_thickness": {
        "agreed": True,
        "towns": ["Lulekani", "Matiko"],
        "colours": {
            "100-120mm": "0,0,0,255",
            "120-140mm": "255,32,0,255",
        },
        "note": "black / red, unanimous across 4 layers in 2 towns",
    },
    "fibre_size": {
        "agreed": False,
        "towns": ["Lulekani", "Matiko"],
        "colours": {
            "12F": "0,242,255,255",
            "24F": "255,8,216,255",
            "48F": "106,30,255,255",
            "96F": "80,200,120,255",
            "144F": "229,182,54,255",
        },
        "note": ("24F agrees (magenta) and 48F is close (blue-violet); 144F does "
                 "NOT - amber in Lulekani, red in Matiko. Lulekani's set is used "
                 "because it is the only one that styles 12F. 96F was in neither "
                 "and is the one invented colour here."),
        "invented": ["96F"],
    },
    "enclosure_type": {
        "agreed": False,
        "towns": [],
        "colours": {"FS": "255,127,0,255", "FTS": "31,120,180,255"},
        "note": ("Both towns draw these as single-symbol layers, so there is no "
                 "harvested convention. These two are chosen, and marked as such."),
        "invented": ["FS", "FTS"],
    },
}

#: The catch-all. Deliberately loud: a mid-grey with a visible outline, so a
#: value nobody anticipated LOOKS like something nobody anticipated rather than
#: blending into the design.
CATCH_ALL_COLOUR = "160,160,160,255"
CATCH_ALL_LABEL = "other / unlisted"


def _esc(text):
    return (str(text).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def spread_colours(n, saturation=0.75, value=0.92):
    """`n` visually distinct RGBA strings, for a data-driven category list.

    Golden-ratio hue stepping rather than an even split: with 82 PON zones an
    even split puts neighbouring zones at nearly the same hue, and adjacent
    zones are exactly the ones a reader needs to tell apart.
    """
    out = []
    golden = 0.61803398875
    h = 0.0
    for _ in range(max(0, n)):
        r, g, b = colorsys.hsv_to_rgb(h % 1.0, saturation, value)
        out.append("%d,%d,%d,255" % (round(r * 255), round(g * 255), round(b * 255)))
        h += golden
    return out


def _symbol(idx, colour, geometry):
    """One QGIS symbol block for point / line / polygon."""
    geom = (geometry or "").lower().replace("multi", "")
    if geom == "point":
        layer = ('<layer class="SimpleMarker">'
                 '<Option type="Map">'
                 '<Option name="color" type="QString" value="%s"/>'
                 '<Option name="name" type="QString" value="circle"/>'
                 '<Option name="outline_color" type="QString" value="35,35,35,255"/>'
                 '<Option name="outline_width" type="QString" value="0.2"/>'
                 '<Option name="size" type="QString" value="2.2"/>'
                 '</Option></layer>' % _esc(colour))
        stype = "marker"
    elif geom == "polygon":
        layer = ('<layer class="SimpleFill">'
                 '<Option type="Map">'
                 '<Option name="color" type="QString" value="%s"/>'
                 '<Option name="outline_color" type="QString" value="35,35,35,255"/>'
                 '<Option name="outline_width" type="QString" value="0.26"/>'
                 '<Option name="style" type="QString" value="solid"/>'
                 '</Option></layer>' % _esc(colour))
        stype = "fill"
    else:
        layer = ('<layer class="SimpleLine">'
                 '<Option type="Map">'
                 '<Option name="line_color" type="QString" value="%s"/>'
                 '<Option name="line_width" type="QString" value="0.46"/>'
                 '<Option name="capstyle" type="QString" value="round"/>'
                 '</Option></layer>' % _esc(colour))
        stype = "line"
    return ('<symbol name="%s" type="%s" alpha="1" force_rhr="0">%s</symbol>'
            % (idx, stype, layer))


def categorized_qml(attribute, values, geometry, colours=None):
    """A categorised QML for `attribute`, ALWAYS carrying a catch-all.

    `values` is the list of values to enumerate. The catch-all is appended by
    this function and cannot be switched off: a renderer without one silently
    hides every value nobody thought of, which is the bug this module exists to
    stop shipping.
    """
    values = list(values)
    colours = dict(colours or {})
    auto = spread_colours(len([v for v in values if v not in colours]))
    ai = 0
    cats, syms = [], []
    for i, v in enumerate(values):
        col = colours.get(v)
        if col is None:
            col = auto[ai] if ai < len(auto) else CATCH_ALL_COLOUR
            ai += 1
        syms.append(_symbol(str(i), col, geometry))
        cats.append('<category render="true" value="%s" symbol="%s" label="%s"/>'
                    % (_esc(v), i, _esc(v)))

    # ⛔ The catch-all. render="true" and last, so an unlisted value is drawn
    # and visibly odd rather than absent.
    syms.append(_symbol("catchall", CATCH_ALL_COLOUR, geometry))
    cats.append('<category render="true" value="" symbol="catchall" label="%s"/>'
                % _esc(CATCH_ALL_LABEL))

    return ('<!DOCTYPE qgis PUBLIC \'http://mrcc.com/qgis.dtd\' \'SYSTEM\'>\n'
            '<qgis version="3.40.0" styleCategories="Symbology">\n'
            '  <renderer-v2 type="categorizedSymbol" attr="%s" '
            'forceraster="0" enableorderby="0" symbollevels="0">\n'
            '    <categories>%s</categories>\n'
            '    <symbols>%s</symbols>\n'
            '  </renderer-v2>\n'
            '</qgis>\n' % (_esc(attribute), "".join(cats), "".join(syms)))


def single_qml(colour, geometry):
    return ('<!DOCTYPE qgis PUBLIC \'http://mrcc.com/qgis.dtd\' \'SYSTEM\'>\n'
            '<qgis version="3.40.0" styleCategories="Symbology">\n'
            '  <renderer-v2 type="singleSymbol" forceraster="0" '
            'enableorderby="0" symbollevels="0">\n'
            '    <symbols>%s</symbols>\n'
            '  </renderer-v2>\n'
            '</qgis>\n' % _symbol("0", colour, geometry))


def has_catch_all(qml_text):
    """True if a categorised QML carries an all-other-values category.

    The check a test can run against a rendererer we DID write, and against one
    harvested from a real project — where the honest answer, on all fifteen in
    Lulekani and Matiko, is False.
    """
    if 'type="categorizedSymbol"' not in qml_text:
        return True                      # not categorised; nothing to catch
    return bool(re.search(r'<category[^>]*\svalue=""', qml_text))


def style_for(spec, view, schema):
    """The QML for one canonical layer, or None to leave its style alone.

    Chooses between the two kinds described in the module docstring:
    a vocabulary-driven field gets the harvested colours; `zone_id`/`zone_name`
    get categories generated from whatever the layer actually holds.
    """
    geom = getattr(view, "geometry", "") or spec.get("geometry") or ""
    fields = {f: f for f in getattr(view, "fields", [])}
    values = getattr(view, "values", {}) or {}

    for fspec in spec.get("fields") or []:
        name = fspec["name"]
        vocab_name = fspec.get("vocabulary")
        if not vocab_name or name not in fields:
            continue
        harvested = HARVESTED.get(vocab_name) or {}
        vocab = (schema.get("vocabularies") or {}).get(vocab_name) or {}
        listed = list(vocab.get("values") or [])
        if not listed:
            continue
        return {"attribute": name, "kind": "vocabulary",
                "vocabulary": vocab_name,
                "qml": categorized_qml(name, listed, geom,
                                       harvested.get("colours")),
                "evidence": harvested.get("note")}

    # Data-driven: one category per value PRESENT, never a stored list.
    for name in ("zone_name", "zone_id", "pon", "pon_num"):
        if name in fields:
            present = [v for v in (values.get(name) or []) if v is not None]
            uniq = sorted({str(v) for v in present}, key=str)
            if not uniq:
                continue
            return {"attribute": name, "kind": "data",
                    "qml": categorized_qml(name, uniq, geom),
                    "evidence": "%d categories generated from this layer's own "
                                "values — never a stored list" % len(uniq)}
    return None
