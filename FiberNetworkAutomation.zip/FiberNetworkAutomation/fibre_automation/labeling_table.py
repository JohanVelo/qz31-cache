# -*- coding: utf-8 -*-
"""Label My Network — ATTRIBUTE-TABLE edition.

A dockable "Label My Network" that looks and works like the QGIS attribute
table (planners already know it): a layer rail on the left, a Field-Calculator
style "ƒ NEW LABEL =" rule bar, and a grid showing each feature's CURRENT label
next to the live-computed NEW LABEL (red where it needs a pole).  Nothing is
written until the operator presses Label; a backup is taken first and a
one-click UNDO is offered.

# claude:intent MUTATE — user asked (verbatim): "yes" (build the attribute-table
# Label My Network into QGIS, per the approved mock). The ONLY writes are the
# operator-triggered Label button (label_recipe.apply, backup-first) and its
# one-click UNDO (restores saved old values). No write happens at import, on
# open, or on preview — preview is read-only. Plan: reuse the wizard's proven
# backup/apply/undo helpers unchanged; this file only adds the table UI.

This is a THIN presentation layer.  All the real work is reused, unchanged:
  * label_recipe.py  — the composition engine (dry_run / apply / recipe_preset)
  * labeling_wizard.py — layer/host/polygon auto-detection, backup, undo helpers

Qt6/Qt5-safe: Qt via the qgis.PyQt shim, enums fully scoped, no QGIS call at
import time (engine + helpers imported lazily inside methods).
"""
import re

from qgis.PyQt import QtWidgets, QtCore, QtGui

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

Qt = QtCore.Qt

__all__ = ["LabelTableDock", "LabelTableWidget", "open_labeling_table"]

# ---------------------------------------------------------------------------
# palette — same Mission-Control console as the wizard / approved mock
# ---------------------------------------------------------------------------
_BG = "#0c1013"
_PANEL = "#12171d"
_HEAD = "#1b232c"
_LINE = "#242e38"
_LINE2 = "#303c47"
_INK = "#e7edf3"
_MUT = "#8291a0"
_DIM = "#5a6875"
_CYAN = "#22d3ee"
_AMBER = "#f0b429"
_GREEN = "#34d399"
_RED = "#f87171"
_SEL = "#12303a"

# role -> (emoji, friendly display)  — friendly name only; the engine roles
# themselves come from the picked client preset.
_ICON = {
    "ONT": "🏠", "DIST_CABLE": "🧵", "SEC_CABLE": "🧵", "PRI_CABLE": "🧵",
    "STS_SPLITTER": "🔀", "FTS_SPLITTER": "🔱", "ENCL_CONN": "📦",
    "ENCL_SPLICE": "📦", "DROP_CABLE": "🧵", "POLE": "📍", "MANHOLE": "⚫",
    "POP": "🏢",
}
_FRIENDLY = {
    "ONT": "Homes / ONT", "DIST_CABLE": "Distribution cable",
    "SEC_CABLE": "Secondary cable", "PRI_CABLE": "Primary cable",
    "STS_SPLITTER": "Street splitters", "FTS_SPLITTER": "Zone splitters",
    "ENCL_CONN": "Enclosures — dist", "ENCL_SPLICE": "Enclosures — agg",
    "DROP_CABLE": "Drop cable",
}
# preferred rail order
_ORDER = ["ONT", "DIST_CABLE", "SEC_CABLE", "PRI_CABLE", "STS_SPLITTER",
          "FTS_SPLITTER", "ENCL_CONN", "ENCL_SPLICE", "DROP_CABLE"]

# the table is a PREVIEW of the naming RULE, not an audit of every feature —
# so we only render a few example rows (the status bar shows the real total).
_EXAMPLE_ROWS = 8

# layers with more rows than this compute the preview OFF the UI thread (the
# heavy auto-numbering is O(n^2)); smaller layers compute inline (no task
# latency, so small layers stay instant).
_ASYNC_MIN = 800

# geometry/derived tokens -> "from the map" (cyan) in the rule bar
_MAP_TOKENS = {"host", "host_full", "start", "end", "start_full", "end_full",
               "pon_no", "zone_no", "zone", "ag", "card", "port", "polenum",
               "chainage"}
_AUTO_TOKENS = {"leg", "seq", "mhnum", "pnum", "popnum", "num"}

# engine flag code -> plain-English reason a feature can't be labelled, so the
# preview says WHY (not a blanket "needs a pole" when no pole is involved).
_FLAG_REASON = {"no_host": "no nearby pole", "no_pon": "needs a PON number",
                "no_sequence": "number field empty", "no_chainage": "needs a length"}

# "show all rows" is opt-in and capped so a 4,711-row render can never hang.
_SHOW_ALL_CAP = 3000


def _label_of(val):
    """The composed label from a labels-dict value (label, fills) | None."""
    return val[0] if isinstance(val, (list, tuple)) else val


def _fills_of(val):
    """The also-fill dict from a labels-dict value (label, fills), or {}."""
    return val[1] if isinstance(val, (list, tuple)) and len(val) > 1 else {}


def _duplicate_labels(labels):
    """Set of composed labels that occur more than once (identical labels break
    the network model).  Ignores None (unlabelled) values."""
    seen = {}
    for val in labels.values():
        lab = _label_of(val)
        if lab is not None:
            seen[lab] = seen.get(lab, 0) + 1
    return {lab for lab, n in seen.items() if n > 1}


def _auto_dedupe(labels):
    """Overrides {fid: unique_label} that de-duplicate identical labels: keep the
    first occurrence of each label, suffix the rest _2/_3…  Deterministic (fids
    sorted); a suffix that would collide with an existing label is bumped."""
    groups = {}
    existing = set()
    for fid, val in labels.items():
        lab = _label_of(val)
        if lab is not None:
            groups.setdefault(lab, []).append(fid)
            existing.add(lab)
    out = {}
    for lab, fids in groups.items():
        if len(fids) < 2:
            continue
        k = 2
        for fid in sorted(fids)[1:]:
            cand = "%s_%d" % (lab, k)
            while cand in existing:
                k += 1
                cand = "%s_%d" % (lab, k)
            existing.add(cand)
            out[fid] = cand
            k += 1
    return out


def _output_dir():
    """Project output dir for CSV exports — tries the relative/absolute import
    forms so this stays byte-identical across both bundled copies; falls back to
    the home directory."""
    getters = []
    try:
        from ..fibre_automation.shared.vf_paths import project_output_dir as p
        getters.append(p)
    except Exception:
        pass
    try:
        from .shared.vf_paths import project_output_dir as p
        getters.append(p)
    except Exception:
        pass
    try:
        from fibre_automation.shared.vf_paths import project_output_dir as p
        getters.append(p)
    except Exception:
        pass
    for p in getters:
        try:
            d = p()
            if d:
                return d
        except Exception:
            pass
    import os
    return os.path.expanduser("~")


def _wiz():
    """The sibling wizard module — reused for detection/backup/apply helpers."""
    try:
        from . import labeling_wizard as w
    except ImportError:                      # pragma: no cover - flat copy
        import labeling_wizard as w
    return w


def _engine():
    """The label_recipe composition engine."""
    try:
        from . import label_recipe as eng
    except ImportError:                      # pragma: no cover - flat copy
        import label_recipe as eng
    return eng


# preset ratio/format defaults that reproduce the real as-builts (the approved
# mock).  Applied on top of engine.recipe_preset() WITHOUT touching the engine.
def _tune_preset(client, recs):
    if client != "Fibertime":
        return recs
    sts = recs.get("STS_SPLITTER")
    if sts is not None:
        sts.template = ("{stack}.STS.{ratio}.DIS.DM.{host}-OLT.{olt}"
                        ".C{card}P{port:02}.L{leg}")
        sts.constants.setdefault("ratio", "8")
    fts = recs.get("FTS_SPLITTER")
    if fts is not None:
        fts.template = ("{stack}.FTS.{ratio}.AGG.DM.{host}-OLT.{olt}"
                        ".C{card}P{port:02}")
        fts.constants.setdefault("ratio", "16")
    return recs


class LabelTableWidget(QtWidgets.QWidget):
    """The whole tool as one widget (put inside a QgsDockWidget)."""

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setObjectName("vnLblTblRoot")
        self._client = "Fibertime"
        self._recipes = {}          # role -> engine Recipe (tuned)
        self._role_layer = {}       # role -> QgsVectorLayer
        self._active = None         # active role key
        self._dry = None            # last dry-run result for active layer
        self._undo_all = []
        self._preview_error = None
        self._preview_seq = 0       # staleness token — a late worker for an old
        #                             layer/client must never paint over a newer one
        self._only_problems = False  # filter: show only skipped/flagged/dup rows
        self._show_all = False       # show all rows (capped) vs 8 examples
        self._overrides = {}         # (role, fid) -> manual/auto label override
        self._label_layer_id = None  # temp "labels on map" layer (remove by id)
        self._build_ui()
        self._remove_orphan_label_layers()   # drop a stale temp layer from a reload
        self._autodetect()
        self._reload_recipes()
        self._select_first_layer()

    # -- construction --------------------------------------------------------
    def _build_ui(self):
        w = _wiz()
        # remembered choices from the last session (B) — read BEFORE any signal
        # is wired so restoring a value never triggers a preview/recurse.
        self._client = w._setting("client", self._client)
        if self._client not in ("Fibertime", "Vuma", "HeroTel"):
            self._client = "Fibertime"
        self.setStyleSheet(_qss())
        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # toolbar
        tb = QtWidgets.QFrame(objectName="tbar")
        tbl = QtWidgets.QHBoxLayout(tb)
        tbl.setContentsMargins(14, 8, 14, 8)
        tbl.setSpacing(12)
        brand = QtWidgets.QLabel("🏷️  LABEL MY NETWORK")
        brand.setObjectName("brand")
        beta = QtWidgets.QLabel("BETA")
        beta.setObjectName("beta")
        tbl.addWidget(brand)
        tbl.addWidget(beta)
        tbl.addSpacing(6)
        tbl.addWidget(_lbl("Company"))
        self.client_cb = QtWidgets.QComboBox()
        self.client_cb.addItems(["Fibertime", "Vuma", "HeroTel"])
        self.client_cb.setCurrentText(self._client)   # set BEFORE wiring signal
        self.client_cb.currentTextChanged.connect(self._on_client)
        tbl.addWidget(self.client_cb)
        tbl.addWidget(_lbl("Project"))
        self.stack_ed = QtWidgets.QLineEdit(str(w._setting("stack", "MOA")))
        self.stack_ed.setMaximumWidth(72)
        self.stack_ed.setObjectName("mono")
        self.stack_ed.textEdited.connect(lambda *_: self._on_cfg_edited())
        tbl.addWidget(self.stack_ed)
        tbl.addWidget(_lbl("AOI"))
        self.aoi_ed = QtWidgets.QLineEdit(str(w._setting("aoi", "")))
        self.aoi_ed.setMaximumWidth(84)
        self.aoi_ed.setObjectName("mono")
        self.aoi_ed.setPlaceholderText("PABA2")
        self.aoi_ed.textEdited.connect(lambda *_: self._on_cfg_edited())
        tbl.addWidget(self.aoi_ed)
        self.zoned_chk = QtWidgets.QCheckBox("per-zone")
        self.zoned_chk.setChecked(
            str(w._setting("zoned", "false")).lower() in ("1", "true", "yes"))
        self.zoned_chk.toggled.connect(lambda *_: self._on_zoned())
        tbl.addWidget(self.zoned_chk)
        tbl.addWidget(_lbl("OLT"))
        self.olt_ed = QtWidgets.QLineEdit(str(w._setting("olt", "01")))
        self.olt_ed.setMaximumWidth(52)
        self.olt_ed.setObjectName("mono")
        self.olt_ed.textEdited.connect(lambda *_: self._on_cfg_edited())
        tbl.addWidget(self.olt_ed)
        tbl.addStretch(1)
        hint = QtWidgets.QLabel("looks & works like your attribute table — "
                                "nothing changes until you press Label")
        hint.setObjectName("hint")
        tbl.addWidget(hint)
        root.addWidget(tb)

        # body split: rail | content
        body = QtWidgets.QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)

        railwrap = QtWidgets.QFrame(objectName="rail")
        railwrap.setFixedWidth(230)
        rv = QtWidgets.QVBoxLayout(railwrap)
        rv.setContentsMargins(0, 0, 0, 0)
        rv.setSpacing(0)
        rh = QtWidgets.QLabel("LAYERS")
        rh.setObjectName("railhead")
        rv.addWidget(rh)
        self.rail_list = QtWidgets.QListWidget()
        self.rail_list.setObjectName("railList")
        self.rail_list.currentRowChanged.connect(self._on_rail)
        rv.addWidget(self.rail_list, 1)
        body.addWidget(railwrap)

        content = QtWidgets.QVBoxLayout()
        content.setContentsMargins(0, 0, 0, 0)
        content.setSpacing(0)

        # rule bar
        fc = QtWidgets.QFrame(objectName="fcbar")
        fcl = QtWidgets.QHBoxLayout(fc)
        fcl.setContentsMargins(14, 8, 14, 8)
        fcl.setSpacing(9)
        fx = QtWidgets.QLabel("ƒ  NEW LABEL =")
        fx.setObjectName("fx")
        fcl.addWidget(fx)
        self.expr_lbl = QtWidgets.QLabel("")
        self.expr_lbl.setObjectName("expr")
        self.expr_lbl.setTextFormat(Qt.TextFormat.RichText)
        fcl.addWidget(self.expr_lbl, 1)
        self.edit_btn = QtWidgets.QPushButton("⚙ Edit rule")
        self.edit_btn.setObjectName("gh")
        self.edit_btn.setCheckable(True)
        self.edit_btn.toggled.connect(lambda *_: self._render_drawer())
        fcl.addWidget(self.edit_btn)
        content.addWidget(fc)

        # editor drawer (hidden until Edit rule)
        self.drawer = QtWidgets.QFrame(objectName="drawer")
        self.drawer.setVisible(False)
        self.drawer_l = QtWidgets.QVBoxLayout(self.drawer)
        self.drawer_l.setContentsMargins(16, 12, 16, 14)
        self.drawer_l.setSpacing(10)
        content.addWidget(self.drawer)

        # table
        self.table = QtWidgets.QTableWidget()
        self.table.setObjectName("attrTable")
        self.table.setEditTriggers(
            QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(
            QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.setShowGrid(False)
        # (1) double-click the NEW LABEL cell to type a custom override
        self.table.cellDoubleClicked.connect(self._on_cell_dblclick)
        content.addWidget(self.table, 1)

        # status bar
        sb = QtWidgets.QFrame(objectName="statusbar")
        sbl = QtWidgets.QHBoxLayout(sb)
        sbl.setContentsMargins(14, 8, 14, 8)
        sbl.setSpacing(16)
        self.status_lbl = QtWidgets.QLabel("")
        self.status_lbl.setObjectName("status")
        sbl.addWidget(self.status_lbl)
        self.busy_bar = QtWidgets.QProgressBar()      # indeterminate busy (4)
        self.busy_bar.setRange(0, 0)
        self.busy_bar.setFixedWidth(90)
        self.busy_bar.setTextVisible(False)
        self.busy_bar.setVisible(False)
        sbl.addWidget(self.busy_bar)
        sbl.addStretch(1)
        self.only_prob_chk = QtWidgets.QCheckBox("only problems")   # (3)
        self.only_prob_chk.toggled.connect(self._on_filter)
        sbl.addWidget(self.only_prob_chk)
        self.showall_chk = QtWidgets.QCheckBox("show all")          # (3)
        self.showall_chk.toggled.connect(self._on_filter)
        sbl.addWidget(self.showall_chk)
        self.map_chk = QtWidgets.QCheckBox("labels on map")        # (3)
        self.map_chk.toggled.connect(lambda *_: self._on_map_toggle())
        sbl.addWidget(self.map_chk)
        self.csv_btn = QtWidgets.QPushButton("Export → CSV")        # (4)
        self.csv_btn.setObjectName("gh")
        self.csv_btn.clicked.connect(lambda *_: self._export_csv())
        sbl.addWidget(self.csv_btn)
        self.dedupe_btn = QtWidgets.QPushButton("Fix duplicates")   # (2)
        self.dedupe_btn.setObjectName("gh")
        self.dedupe_btn.setVisible(False)
        self.dedupe_btn.clicked.connect(lambda *_: self._fix_duplicates())
        sbl.addWidget(self.dedupe_btn)
        self.prob_btn = QtWidgets.QPushButton("")   # "Select N problems" (D)
        self.prob_btn.setObjectName("gh")
        self.prob_btn.setVisible(False)
        self.prob_btn.clicked.connect(lambda *_: self._select_problems())
        sbl.addWidget(self.prob_btn)
        self.backup_chk = QtWidgets.QCheckBox("Back up first")
        self.backup_chk.setChecked(True)
        sbl.addWidget(self.backup_chk)
        self.all_btn = QtWidgets.QPushButton("Label ALL layers")
        self.all_btn.setObjectName("gh")
        self.all_btn.clicked.connect(lambda *_: self._apply(all_layers=True))
        sbl.addWidget(self.all_btn)
        self.go_btn = QtWidgets.QPushButton("Label this layer  →")
        self.go_btn.setObjectName("go")
        self.go_btn.clicked.connect(lambda *_: self._apply(all_layers=False))
        sbl.addWidget(self.go_btn)
        content.addWidget(sb)

        body.addLayout(content, 1)
        root.addLayout(body, 1)

        # toast for undo
        self.toast = QtWidgets.QLabel("")
        self.toast.setObjectName("toast")
        self.toast.setVisible(False)
        self.toast.setWordWrap(True)
        root.addWidget(self.toast)

    # -- detection + recipes -------------------------------------------------
    def _project_layers(self):
        try:
            from qgis.core import QgsProject
            return list(QgsProject.instance().mapLayers().values())
        except Exception:
            return []

    def _autodetect(self):
        w = _wiz()
        layers = self._project_layers()
        self._role_layer = {}
        kinds = {"DIST_CABLE": "cable", "SEC_CABLE": "cable",
                 "PRI_CABLE": "cable", "DROP_CABLE": "cable",
                 "STS_SPLITTER": "point", "FTS_SPLITTER": "point",
                 "ENCL_CONN": "point", "ENCL_SPLICE": "point", "ONT": "point"}
        for role, kind in kinds.items():
            try:
                lyr = w._match_layer(role, kind, layers)
            except Exception:
                lyr = None
            if lyr is not None:
                self._role_layer[role] = lyr
        try:
            self._poles = w._guess_named_layer(layers, "point", "poles", "pole")
            self._man = w._guess_named_layer(layers, "point", "manhole")
            self._pon = w._guess_named_layer(layers, "polygon", "pon")
            self._zone = w._guess_named_layer(layers, "polygon", "zone")
        except Exception:
            self._poles = self._man = self._pon = self._zone = None
        try:
            st = w._detect_stack()
            if st:
                self.stack_ed.setText(str(st))
        except Exception:
            pass

    def _reload_recipes(self):
        eng = _engine()
        consts = {"stack": self.stack_ed.text().strip() or "MOA",
                  "olt": self.olt_ed.text().strip() or "01",
                  "aoi": self.aoi_ed.text().strip()}
        zoned = self.zoned_chk.isChecked()
        try:
            recs = eng.recipe_preset(self._client, zoned=zoned, **consts)
        except Exception:
            recs = {}
        self._recipes = _tune_preset(self._client, recs)

    def _host_field(self, lyr):
        w = _wiz()
        names = w._field_names(lyr) if lyr is not None else []
        return (w._guess_field(names, "label", "label_1", "name",
                               contains="label") or (names[0] if names else ""))

    def _host_index(self):
        eng = _engine()
        hosts = []
        for lyr in (self._poles, self._man):
            if lyr is not None:
                hosts.append((lyr, self._host_field(lyr)))
        return eng.build_host_index(hosts)

    def _polygons(self):
        eng = _engine()
        cfg = {}
        if self._pon is not None:
            cfg["pon_no"] = (self._pon, _pick(self._pon, "pon_no", "pon"))
        if self._zone is not None:
            cfg["zone_no"] = (self._zone, _pick(self._zone, "zone_no", "zone"))
            # per-zone HeroTel labels resolve {zone} from the containing zone
            # polygon (engine falls back to the zone constant if absent).
            if self.zoned_chk.isChecked():
                cfg["zone"] = (self._zone, _pick(self._zone, "zone_no", "zone"))
        return eng.build_polygons(cfg)

    def _constants(self):
        return {"stack": self.stack_ed.text().strip() or "MOA",
                "olt": self.olt_ed.text().strip() or "01",
                "aoi": self.aoi_ed.text().strip()}

    # -- config change handlers ---------------------------------------------
    def _save_settings(self):
        w = _wiz()
        w._set_setting("client", self._client)
        w._set_setting("stack", self.stack_ed.text().strip())
        w._set_setting("olt", self.olt_ed.text().strip())
        w._set_setting("aoi", self.aoi_ed.text().strip())
        w._set_setting("zoned",
                       "true" if self.zoned_chk.isChecked() else "false")

    def _on_cfg_edited(self):
        """Project/AOI/OLT edited — session constants override recipe defaults,
        so a plain refresh re-previews with the new value (no recipe reload)."""
        self._save_settings()
        self.refresh()

    def _on_zoned(self):
        """per-zone toggled — this changes the TEMPLATE (adds _Z{zone}), so the
        recipes must be rebuilt before re-previewing."""
        self._reload_recipes()
        self._save_settings()
        self.refresh()

    def _select_problems(self):
        """Select + zoom to the features that can't be labelled (skipped or
        flagged) so the planner can fix them.  Selection only — no data write."""
        role = self._active
        if not role or role not in self._role_layer or self._dry is None:
            return
        lyr = self._role_layer[role]
        labels = self._effective_labels()       # overrides fix problems
        skips = self._dry.get("skips", {})
        ov_fids = set(self._role_overrides())
        dups = _duplicate_labels(labels)
        fids = set(skips) - ov_fids
        for fid, v in labels.items():
            lab = _label_of(v)
            if lab is None or lab in dups:      # flagged OR duplicate
                fids.add(fid)
        if not fids:
            return
        try:
            lyr.selectByIds(list(fids))
            if self.iface is not None:
                self.iface.mapCanvas().zoomToSelected(lyr)
                self.iface.mapCanvas().refresh()
        except Exception:
            pass

    def _on_filter(self, *_):
        """Filter toggles (3) — re-render from the cached result, no recompute."""
        self._only_problems = self.only_prob_chk.isChecked()
        self._show_all = self.showall_chk.isChecked()
        if self._dry is not None:
            self._paint()

    def _rebind(self, rec, token, value):
        """Field rebinding (2) — point a token at a column, or fall back to the
        typed/constant value.  Recomputes the preview with the new source."""
        if value == "(typed value)":
            rec.field_map.pop(token, None)
        else:
            rec.field_map[token] = value
        self.refresh()

    def _export_csv(self):
        """Export the planned labels to a CSV in the project output dir (4)."""
        import csv
        import os
        role = self._active
        if not role or self._dry is None or role not in self._role_layer:
            self._show_toast("warn", "Nothing to export yet — pick a layer.")
            return
        lyr = self._role_layer[role]
        lf = self._recipes[role].label_field
        labels = self._effective_labels()       # export reflects overrides
        skips = self._dry.get("skips", {})
        ov_fids = set(self._role_overrides())
        dups = _duplicate_labels(labels)
        has_lf = lf in lyr.fields().names()
        safe_role = re.sub(r"[^A-Za-z0-9_-]+", "_", role)
        path = os.path.join(_output_dir(), "label_preview_%s.csv" % safe_role)
        try:
            with open(path, "w", newline="", encoding="utf-8") as fh:
                wr = csv.writer(fh)
                wr.writerow(["fid", "current", "new_label", "status"])
                for f in lyr.getFeatures():
                    fid = f.id()
                    cur = f[lf] if has_lf else ""
                    lab = _label_of(labels.get(fid))
                    if lab is None and fid in skips:
                        new, status = "", "skipped:%s" % skips[fid]
                    elif lab is None:
                        new, status = "", "flagged"
                    else:
                        new = lab
                        status = ("overridden" if fid in ov_fids
                                  else "duplicate" if lab in dups else "ok")
                    wr.writerow([fid, _s(cur), _s(new), status])
        except Exception as exc:
            self._show_toast("error", "Export failed: %s" % exc)
            return
        self._show_toast("ok", "Exported → %s" % path)

    # -- per-feature overrides (1) + auto-dedupe (2) -------------------------
    def _role_overrides(self, role=None):
        role = role or self._active
        return {fid: lab for (r, fid), lab in self._overrides.items()
                if r == role}

    def _effective_labels(self):
        """Composed labels for the active role with its overrides applied — an
        override can add a fid that wasn't composed (e.g. a fixed skip)."""
        labels = dict(self._dry.get("labels", {})) if self._dry else {}
        for fid, lab in self._role_overrides().items():
            labels[fid] = (lab, _fills_of(labels.get(fid)))
        return labels

    def _on_cell_dblclick(self, row, col):
        if col != 2 or not self._active or self._dry is None:
            return                          # only the NEW LABEL column
        it = self.table.item(row, 0)
        try:
            fid = int(it.text()) if it is not None else None
        except (TypeError, ValueError):
            return
        if fid is None:
            return
        role = self._active
        cur = self._role_overrides().get(fid)
        if cur is None:
            cur = _label_of(self._dry.get("labels", {}).get(fid)) or ""
        from qgis.PyQt.QtWidgets import QInputDialog
        text, ok = QInputDialog.getText(
            self, "Override label",
            "Custom label for feature %d (blank = use the rule):" % fid,
            text=str(cur))
        if not ok:
            return
        text = text.strip()
        if text:
            self._overrides[(role, fid)] = text
        else:
            self._overrides.pop((role, fid), None)
        self._repaint_and_map()

    def _fix_duplicates(self):
        if not self._active or self._dry is None:
            return
        role = self._active
        fixes = _auto_dedupe(self._effective_labels())
        for fid, lab in fixes.items():
            self._overrides[(role, fid)] = lab
        if fixes:
            self._repaint_and_map()
            self._show_toast("ok", "De-duplicated %d label(s)." % len(fixes))
        else:
            self._show_toast("warn", "No duplicates to fix.")

    def _repaint_and_map(self):
        """Overrides/dedupe change only self._overrides — re-render instantly
        (no recompute) and refresh the on-map labels if they're shown."""
        self._paint()
        if self.map_chk.isChecked():
            self._build_label_layer()

    # -- labels on the canvas (3) — temp layer, remove BY ID only -----------
    def _on_map_toggle(self):
        if self.map_chk.isChecked():
            self._build_label_layer()
        else:
            self._remove_label_layer()

    def _clear_map(self):
        """Remove the temp layer + untick the box without recursing."""
        self._remove_label_layer()
        try:
            self.map_chk.blockSignals(True)
            self.map_chk.setChecked(False)
            self.map_chk.blockSignals(False)
        except Exception:
            pass

    def _remove_label_layer(self):
        lid = self._label_layer_id
        self._label_layer_id = None
        if not lid:
            return
        try:
            from qgis.core import QgsProject
            proj = QgsProject.instance()
            if proj.mapLayer(lid) is not None:      # remove ONLY our layer
                proj.removeMapLayer(lid)
            if self.iface is not None:
                self.iface.mapCanvas().refresh()
        except Exception:
            pass

    def _remove_orphan_label_layers(self):
        """On construction, drop any stale temp layer left by a prior reload."""
        try:
            from qgis.core import QgsProject
            proj = QgsProject.instance()
            for lyr in list(proj.mapLayers().values()):
                if lyr.name() == "⚡ Label preview (temp)":
                    proj.removeMapLayer(lyr.id())
        except Exception:
            pass

    def _build_label_layer(self):
        self._remove_label_layer()              # never stack two
        role = self._active
        if not role or self._dry is None or role not in self._role_layer:
            return
        try:
            from qgis.core import (QgsProject, QgsVectorLayer, QgsFeature,
                                   QgsField, QgsPalLayerSettings,
                                   QgsVectorLayerSimpleLabeling)
            from qgis.PyQt.QtCore import QMetaType
        except Exception:
            return
        src = self._role_layer[role]
        eff = self._effective_labels()
        crs = src.crs().authid() or "EPSG:4326"
        mem = QgsVectorLayer("Point?crs=" + crs, "⚡ Label preview (temp)",
                             "memory")
        pr = mem.dataProvider()
        pr.addAttributes([QgsField("label", QMetaType.Type.QString)])
        mem.updateFields()
        feats = []
        for f in src.getFeatures():
            lab = _label_of(eff.get(f.id()))
            if lab is None:
                continue
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            try:
                pt = g.centroid()
            except Exception:
                _swallowed_note(); continue
            nf = QgsFeature(mem.fields())
            nf.setGeometry(pt)
            nf.setAttribute("label", str(lab))
            feats.append(nf)
        pr.addFeatures(feats)
        mem.updateExtents()
        try:                                    # minimal PAL labeling only
            pal = QgsPalLayerSettings()
            pal.fieldName = "label"
            pal.enabled = True
            mem.setLabeling(QgsVectorLayerSimpleLabeling(pal))
            mem.setLabelsEnabled(True)
        except Exception:
            _swallowed_note()
        QgsProject.instance().addMapLayer(mem)
        self._label_layer_id = mem.id()
        if self.iface is not None:
            self.iface.mapCanvas().refresh()

    # -- rail ----------------------------------------------------------------
    def _select_first_layer(self):
        self._fill_rail()
        if self.rail_list.count():
            self.rail_list.setCurrentRow(0)

    def _rail_roles(self):
        return [r for r in _ORDER if r in self._role_layer and
                r in self._recipes]

    def _fill_rail(self):
        self.rail_list.blockSignals(True)
        self.rail_list.clear()
        for role in self._rail_roles():
            lyr = self._role_layer[role]
            try:
                cnt = lyr.featureCount()
                nm = lyr.name()
            except Exception:
                cnt, nm = 0, "?"
            it = QtWidgets.QListWidgetItem(
                "%s  %s\n      %s · %s" % (_ICON.get(role, "▫"),
                                          _FRIENDLY.get(role, role),
                                          "{:,}".format(cnt), nm))
            it.setData(Qt.ItemDataRole.UserRole, role)
            self.rail_list.addItem(it)
        self.rail_list.blockSignals(False)

    def _on_rail(self, row):
        if row < 0:
            return
        it = self.rail_list.item(row)
        if it is None:
            return
        self._clear_map()               # on-map labels were for the old layer
        self._active = it.data(Qt.ItemDataRole.UserRole)
        self.edit_btn.setChecked(False)
        self.refresh()

    # -- events --------------------------------------------------------------
    def _on_client(self, name):
        self._client = name
        self._clear_map()               # on-map labels were for the old client
        self._reload_recipes()
        self._save_settings()
        self.edit_btn.setChecked(False)
        self._fill_rail()
        if self.rail_list.count():
            self.rail_list.setCurrentRow(0)
        else:
            self.refresh()

    # -- rule bar + drawer ---------------------------------------------------
    def _segments(self, role):
        tmpl = self._recipes[role].template
        parts = re.split(r"(\{[^}]+\})", tmpl)
        out = []
        for p in parts:
            if not p:
                continue
            m = re.match(r"^\{([^}]+)\}$", p)
            if not m:
                out.append(("fixed", p))
                continue
            name = m.group(1).split(":")[0]
            cls = ("map" if name in _MAP_TOKENS
                   else "auto" if name in _AUTO_TOKENS
                   else "set")
            out.append((cls, m.group(1)))
        return out

    def _render_expr(self):
        if not self._active:
            self.expr_lbl.setText("")
            return
        cols = {"fixed": _MUT, "map": _CYAN, "auto": "#a78bfa", "set": _AMBER}
        html = []
        for cls, txt in self._segments(self._active):
            safe = txt.replace("<", "&lt;")
            if cls == "fixed":
                html.append('<span style="color:%s">%s</span>' % (_MUT, safe))
            else:
                html.append('<span style="color:%s">{%s}</span>'
                            % (cols[cls], safe))
        self.expr_lbl.setText("".join(html))

    def _render_drawer(self):
        _clear(self.drawer_l)
        show = self.edit_btn.isChecked() and bool(self._active)
        self.drawer.setVisible(show)
        if not show:
            return
        rec = self._recipes[self._active]
        toks = [m.split(":")[0]
                for m in re.findall(r"\{([^}]+)\}", rec.template)]
        cap = QtWidgets.QLabel("This column is built like:")
        cap.setObjectName("cap")
        self.drawer_l.addWidget(cap)
        seg = QtWidgets.QLabel(self._segmented_html(self._active))
        seg.setObjectName("bigexpr")
        seg.setTextFormat(Qt.TextFormat.RichText)
        seg.setWordWrap(True)
        self.drawer_l.addWidget(seg)
        legend = QtWidgets.QLabel(
            '<span style="color:%s">■</span> from the map &nbsp; '
            '<span style="color:%s">■</span> value you set / a column &nbsp; '
            '<span style="color:#a78bfa">■</span> counted automatically &nbsp; '
            '<span style="color:%s">■</span> fixed text'
            % (_CYAN, _AMBER, _MUT))
        legend.setObjectName("legend")
        legend.setTextFormat(Qt.TextFormat.RichText)
        self.drawer_l.addWidget(legend)
        # (2) field rebinding — pick which column each field-backed token reads
        try:
            field_names = self._role_layer[self._active].fields().names()
        except Exception:
            field_names = []
        set_toks = [t for t in dict.fromkeys(toks)
                    if t not in _MAP_TOKENS and t not in _AUTO_TOKENS]
        if set_toks and field_names:
            rb = QtWidgets.QLabel("Bind a token to a column (or keep typed):")
            rb.setObjectName("cap")
            self.drawer_l.addWidget(rb)
            grid = QtWidgets.QHBoxLayout()
            grid.setSpacing(14)
            for t in set_toks:
                cell = QtWidgets.QVBoxLayout()
                cell.setSpacing(2)
                cell.addWidget(_lbl("{%s} reads" % t))
                cb = QtWidgets.QComboBox()
                cur = rec.field_map.get(t)
                items = ["(typed value)"] + list(field_names)
                if cur and cur not in items:
                    items.append(cur)
                cb.addItems(items)
                cb.setCurrentText(cur if cur in items else "(typed value)")
                cb.currentTextChanged.connect(
                    lambda v, tok=t, r=rec: self._rebind(r, tok, v))
                cell.addWidget(cb)
                cw = QtWidgets.QWidget()
                cw.setLayout(cell)
                grid.addWidget(cw)
            grid.addStretch(1)
            gw = QtWidgets.QWidget()
            gw.setLayout(grid)
            self.drawer_l.addWidget(gw)
        opts = QtWidgets.QHBoxLayout()
        opts.setSpacing(20)
        if any(t in toks for t in ("host", "start", "end")):
            opts.addWidget(QtWidgets.QLabel("Names each feature after the "
                                            "nearest pole."))
        if "ratio" in rec.constants:
            opts.addWidget(_lbl("Splitter ratio"))
            ratio_ed = QtWidgets.QLineEdit(str(rec.constants.get("ratio", "")))
            ratio_ed.setMaximumWidth(56)
            ratio_ed.setObjectName("mono")
            ratio_ed.textEdited.connect(
                lambda v, r=rec: (r.constants.__setitem__("ratio", v),
                                  self.refresh()))
            opts.addWidget(ratio_ed)
        opts.addStretch(1)
        writeto = QtWidgets.QLabel("writes into column: <b>%s</b>"
                                   % rec.label_field)
        writeto.setObjectName("cap")
        writeto.setTextFormat(Qt.TextFormat.RichText)
        opts.addWidget(writeto)
        wrap = QtWidgets.QWidget()
        wrap.setLayout(opts)
        self.drawer_l.addWidget(wrap)
        done = QtWidgets.QPushButton("Done")
        done.setObjectName("go")
        done.clicked.connect(lambda *_: self.edit_btn.setChecked(False))
        row = QtWidgets.QHBoxLayout()
        row.addWidget(done)
        row.addStretch(1)
        w2 = QtWidgets.QWidget()
        w2.setLayout(row)
        self.drawer_l.addWidget(w2)

    def _segmented_html(self, role):
        cols = {"fixed": _MUT, "map": _CYAN, "auto": "#a78bfa", "set": _AMBER}
        html = ['<span style="font-family:Consolas;font-size:13px">']
        for cls, txt in self._segments(role):
            safe = txt.replace("<", "&lt;")
            if cls == "fixed":
                html.append('<span style="color:%s">%s</span>' % (_MUT, safe))
            else:
                bg = {"map": "#0c2b33", "auto": "#221b3a",
                      "set": "#2b230c"}[cls]
                html.append('<span style="color:%s;background:%s">&nbsp;{%s}'
                            '&nbsp;</span>' % (cols[cls], bg, safe))
        html.append("</span>")
        return "".join(html)

    # -- preview -------------------------------------------------------------
    def refresh(self):
        # a stale active role (e.g. after a client switch on an empty project)
        # must never reach the renderers, which index self._recipes directly.
        if self._active is not None and (
                self._active not in self._recipes
                or self._active not in self._role_layer):
            self._active = None
        self._render_expr()
        self._render_drawer()
        self._start_preview()

    # -- preview: MAIN-thread extract -> WORKER compute -> MAIN-thread paint --
    def _extract_active(self):
        """MAIN-thread extraction for the ACTIVE layer -> (extracted, host,
        polys, consts).  QGIS reads are not thread-safe, so ALL layer access
        happens here; the returned pack is pure-python for the worker.  Records
        geometry-skipped features so the honest counts survive off-thread."""
        role = self._active
        w = _wiz()
        lyr = self._role_layer[role]
        rec = self._recipes[role]
        names = lyr.fields().names()
        lf = rec.label_field
        has_lf = lf in names
        rows = []
        skips = {}
        for f in lyr.getFeatures():
            fid = f.id()
            g = f.geometry()
            if not g or g.isEmpty():
                skips[fid] = "no geometry"
                continue
            if rec.kind == "cable":
                coords = w._line_coords(g)
                if coords is None:
                    skips[fid] = "bad geometry"
                    continue
                xy = None
            else:
                xy = w._point_xy(g)
                if xy is None:
                    skips[fid] = "bad geometry"
                    continue
                coords = None
            rows.append({"fid": fid, "qfid": f.id(),
                         "coords": coords, "xy": xy,
                         "attrs": {n: w._pyval(f[n]) for n in names},
                         "old": w._pyval(f[lf]) if has_lf else None})
        targets = [lf] + [k for k in rec.also_fill if k != lf]
        create_fields = [n for n in targets if n and n not in names]
        extracted = {role: {"recipe": rec, "rows": rows,
                            "create_fields": create_fields,
                            "skips": skips, "skipped": len(skips)}}
        return (extracted, self._host_index(), self._polygons(),
                self._constants())

    def _set_busy(self, busy):
        """Disable the write buttons + show a computing note while a preview
        runs on the worker thread (never leave them stuck disabled)."""
        for b in (getattr(self, "go_btn", None), getattr(self, "all_btn", None)):
            try:
                if b is not None:
                    b.setEnabled(not busy)
            except Exception:
                pass
        try:
            self.busy_bar.setVisible(busy)      # indeterminate progress (4)
        except Exception:
            pass
        if busy:
            self.status_lbl.setText("⏳ computing preview…")
            try:
                self.prob_btn.setVisible(False)
            except Exception:
                pass

    def _start_preview(self):
        """Kick a preview: extract on the UI thread, then compute inline (small
        layer) or on a worker thread (big layer), then paint.  A staleness token
        drops a late worker whose layer/client the user has since changed."""
        role = self._active
        if not role:
            self._set_busy(False)
            self.table.clear()
            self.table.setRowCount(0)
            self.status_lbl.setText("Pick a layer on the left.")
            return
        self._preview_seq += 1
        seq = self._preview_seq
        w = _wiz()
        try:
            extracted, host, polys, consts = self._extract_active()
        except Exception as exc:            # never crash the dock on preview
            self._preview_error = "%s: %s" % (type(exc).__name__, exc)
            self._dry = None
            self._set_busy(False)
            self._paint()
            return
        self._preview_error = None
        nrows = len(extracted[role]["rows"])

        def _done(result):              # MAIN thread
            if w._is_deleted(self) or seq != self._preview_seq:
                return                  # dock closed, or user moved on
            self._set_busy(False)
            self._dry = result.get(role) if result else None
            self._paint()

        def _fail(exc):                 # MAIN thread
            if w._is_deleted(self) or seq != self._preview_seq:
                return
            self._set_busy(False)
            self._preview_error = "%s: %s" % (type(exc).__name__, exc)
            self._dry = None
            self._paint()

        # small layer -> inline (no task latency); big -> off the UI thread
        if nrows <= _ASYNC_MIN:
            try:
                _done(w._compose_dry(extracted, host, polys, consts))
            except Exception as exc:
                _fail(exc)
            return
        self._set_busy(True)
        w._run_async(lambda: w._compose_dry(extracted, host, polys, consts),
                     _done, _fail, "Label preview — %s" % role)

    def _paint(self):
        role = self._active
        if not role:
            self.table.clear()
            self.table.setRowCount(0)
            self.status_lbl.setText("Pick a layer on the left.")
            return
        lyr = self._role_layer[role]
        rec = self._recipes[role]
        lf = rec.label_field
        if self._dry is None:
            self.table.clear()
            self.table.setRowCount(0)
            self.prob_btn.setVisible(False)
            self.status_lbl.setText(
                "Couldn't preview: %s"
                % (self._preview_error or "no data"))
            return
        base_labels = self._dry.get("labels", {})    # composed (no overrides)
        labels = self._effective_labels()             # (1) overrides applied
        ov = self._role_overrides()
        ov_fids = set(ov)
        skips = self._dry.get("skips", {})        # fid -> reason (skipped geom)
        # WHY a flagged feature can't be labelled (C) — real reason, not "pole"
        reason = {}
        for fl in self._dry.get("flags", []):
            reason.setdefault(fl.get("fid"),
                              _FLAG_REASON.get(fl.get("code"), "can't build label"))
        fill_cols = []
        for _fid, val in list(labels.items())[:200]:
            for k in _fills_of(val):
                if k not in fill_cols and k != lf:
                    fill_cols.append(k)
        headers = ["#", "%s (current)" % lf, "✦ NEW LABEL"] + fill_cols + [""]
        newcol_idx = 2
        self.table.clear()
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        names = lyr.fields().names()
        has_lf = lf in names
        # (1) duplicates (on effective labels) + the "problem" fids of any kind
        dups = _duplicate_labels(labels)
        dup_fids = {fid for fid, v in labels.items() if _label_of(v) in dups}
        base_flagged = {fid for fid, v in base_labels.items()
                        if _label_of(v) is None}
        # an override fixes a skip/flag, so it stops being a problem
        problem_fids = ((set(skips) | base_flagged) - ov_fids) | dup_fids
        # (3) how many rows to render: 8 examples / only problems / show-all(cap)
        limit = (_SHOW_ALL_CAP if (self._only_problems or self._show_all)
                 else _EXAMPLE_ROWS)
        rows = []
        for f in lyr.getFeatures():
            fid = f.id()
            if self._only_problems and fid not in problem_fids:
                continue
            in_labels = fid in labels
            val = labels.get(fid, (None, {}))
            new, fills = (val if isinstance(val, (list, tuple))
                          else (None, {}))
            cur = f[lf] if has_lf else None
            skip = None if in_labels else skips.get(fid, "no geometry")
            dup = new is not None and new in dups
            rows.append((fid, cur, new, fills, skip, dup, fid in ov_fids))
            if len(rows) >= limit:
                break
        self.table.setRowCount(len(rows))
        for r, (fid, cur, new, fills, skip, dup, is_ov) in enumerate(rows):
            self.table.setItem(r, 0, _cell(str(fid), _DIM, mono=True))
            self.table.setItem(r, 1, _cell(_s(cur), _MUT, mono=True))
            if is_ov:                       # (1) manual/auto override wins
                nc = _cell("✎ %s" % _s(new), "#a78bfa", mono=True, bold=True)
                nc.setBackground(QtGui.QColor("#1c1830"))
                st = _cell("✎", "#a78bfa")
            elif skip is not None:
                # needs a GEOMETRY, not a host — amber, distinct from red flag
                nc = _cell("✋ %s" % skip, _AMBER, mono=True)
                nc.setBackground(QtGui.QColor("#241f10"))
                st = _cell("⊘", _AMBER)
            elif new is None:
                nc = _cell("✋ %s" % reason.get(fid, "needs attention"),
                           _RED, mono=True)
                nc.setBackground(QtGui.QColor("#241315"))
                st = _cell("!", _AMBER)
            elif dup:                       # (1) duplicate — real value, warned
                nc = _cell("⚠ %s" % _s(new), _AMBER, mono=True)
                nc.setBackground(QtGui.QColor("#241f10"))
                st = _cell("⚠", _AMBER)
            else:
                nc = _cell(_s(new), _INK, mono=True, bold=True)
                nc.setBackground(QtGui.QColor("#0c1f27"))
                st = _cell("✔", _GREEN)
            self.table.setItem(r, newcol_idx, nc)
            for j, k in enumerate(fill_cols):
                self.table.setItem(r, 3 + j,
                                   _cell(_s(fills.get(k)), _CYAN, mono=True))
            self.table.setItem(r, len(headers) - 1, st)
        hh = self.table.horizontalHeader()
        hh.setStretchLastSection(False)
        hh.setSectionResizeMode(
            QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        # counts reflect overrides: an overridden skip/flag now "will be named"
        base_total = (self._dry.get("ready", 0) + self._dry.get("flagged", 0)
                      + self._dry.get("skipped", 0))
        skipped = len(set(skips) - ov_fids)
        flagged = len(base_flagged - ov_fids)
        ndup = len(dup_fids)
        nov = len(ov_fids)
        ready = base_total - skipped - flagged
        parts = ["%s features" % "{:,}".format(base_total),
                 "%s will be named" % "{:,}".format(ready)]
        if flagged:
            parts.append("%s need attention" % "{:,}".format(flagged))
        if skipped:
            parts.append("%s skipped (no geometry)" % "{:,}".format(skipped))
        if ndup:
            parts.append("%s duplicate labels" % "{:,}".format(ndup))
        if nov:
            parts.append("%s overridden" % "{:,}".format(nov))
        if self._only_problems:
            parts.append("showing problems")
        elif len(rows) >= _SHOW_ALL_CAP and base_total > len(rows):
            parts.append("showing first %s of %s"
                         % ("{:,}".format(len(rows)), "{:,}".format(base_total)))
        elif base_total > len(rows):
            parts.append("%d examples shown" % len(rows))
        self.status_lbl.setText("  ·  ".join(parts))
        self.dedupe_btn.setVisible(bool(ndup))    # (2) "Fix duplicates"
        # "Select N problems" — skipped / flagged / duplicate (D + 1)
        nprob = flagged + skipped + ndup
        self.prob_btn.setVisible(bool(nprob))
        if nprob:
            self.prob_btn.setText(
                "⚠ Select %d problem%s" % (nprob, "" if nprob == 1 else "s"))

    # -- apply / undo --------------------------------------------------------
    def _apply(self, all_layers):
        w = _wiz()
        eng = _engine()
        roles = (self._rail_roles() if all_layers
                 else ([self._active] if self._active else []))
        roles = [r for r in roles
                 if r in self._role_layer and r in self._recipes]
        if not roles:
            self._show_toast("warn", "Nothing to label.")
            return
        if self.backup_chk.isChecked():
            QtWidgets.QApplication.setOverrideCursor(
                QtGui.QCursor(Qt.CursorShape.WaitCursor))
            try:
                ok, detail = w._run_backup()
            finally:
                QtWidgets.QApplication.restoreOverrideCursor()
            if not ok:
                self._show_toast("error",
                                 "Backup failed — NOTHING written. %s" % detail)
                return
        host = self._host_index()
        polys = self._polygons()
        consts = self._constants()
        total_undo = 0
        total_dups = 0
        self._undo_all = []
        QtWidgets.QApplication.setOverrideCursor(
            QtGui.QCursor(Qt.CursorShape.WaitCursor))
        try:
            for role in roles:
                lrc = eng.LayerRecipe(self._role_layer[role],
                                      self._recipes[role])
                dry = eng.dry_run([lrc], host, polys, consts)
                res = dry.get(role, {})
                ovr = self._role_overrides(role)        # (1) write overrides
                if ovr:
                    labs = res.get("labels", {})
                    for fid, lab in ovr.items():
                        labs[fid] = (lab, _fills_of(labs.get(fid)))
                    res["labels"] = labs
                total_dups += len(_duplicate_labels(res.get("labels", {})))
                undo = eng.apply([lrc], dry)
                if undo:
                    total_undo += len(undo)
                    self._undo_all.append((lrc, undo))
        except Exception as exc:
            QtWidgets.QApplication.restoreOverrideCursor()
            self._show_toast("error", "Writing labels failed: %s: %s"
                             % (type(exc).__name__, exc))
            return
        finally:
            QtWidgets.QApplication.restoreOverrideCursor()
        try:
            if self.iface is not None:
                self.iface.messageBar().pushSuccess(
                    "Label My Network",
                    "Labelled %s feature(s)." % "{:,}".format(total_undo))
        except Exception:
            pass
        msg = "Labelled %s feature(s)." % "{:,}".format(total_undo)
        if total_dups:
            msg += "  ⚠ %s duplicate label(s) — check before submitting." \
                % "{:,}".format(total_dups)
        self._show_toast("ok", msg, undo=(total_undo > 0))
        self.refresh()

    def _do_undo(self):
        w = _wiz()
        restored = 0
        for lrc, undo in list(getattr(self, "_undo_all", [])):
            lyr = lrc.layer
            if lyr is None or w._is_deleted(lyr):
                continue
            role = lrc.recipe.layer_role
            idx = {n: lyr.fields().indexOf(n) for n in lyr.fields().names()}
            changes = {}
            for f in lyr.getFeatures():
                old = undo.get((role, w._fid_of(f, lrc.id_field)))
                if not old:
                    continue
                rowmap = {idx[fld]: v for fld, v in old.items() if fld in idx}
                if rowmap:
                    changes[f.id()] = rowmap
            if changes:
                # restore previously-saved values (operator pressed UNDO)
                lyr.dataProvider().changeAttributeValues(changes)
                lyr.triggerRepaint()
                restored += len(changes)
        self._undo_all = []
        self._show_toast("ok", "Undone — %s feature(s) restored."
                         % "{:,}".format(restored))
        self.refresh()

    def _show_toast(self, kind, msg, undo=False):
        col = {"ok": _GREEN, "warn": _AMBER, "error": _RED}.get(kind, _INK)
        self.toast.setStyleSheet(
            "#toast{background:%s;color:%s;padding:9px 14px;"
            "border-top:1px solid %s;font-weight:600}" % (_PANEL, col, _LINE2))
        self.toast.setText(msg + ("   ↩ click here to UNDO" if undo else ""))
        self.toast.setVisible(True)
        try:
            self.toast.mousePressEvent = (
                (lambda *_: self._do_undo()) if undo else (lambda *_: None))
        except Exception:
            pass


class LabelTableDock(QtWidgets.QDockWidget):
    def __init__(self, iface, parent=None):
        super().__init__("Label My Network", parent)
        self.setObjectName("LabelMyNetworkTableDock")
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, False)
        self._w = LabelTableWidget(iface, self)
        self.setWidget(self._w)


_DOCK = None


def open_labeling_table(iface):
    """Open (or raise) the attribute-table Label My Network dock.

    Singleton by dock objectName so a plugin reload (which resets this
    module's _DOCK global) can never leave two docks stacked."""
    global _DOCK
    w = _wiz()
    if _DOCK is not None and not w._is_deleted(_DOCK):
        _DOCK.show()
        _DOCK.raise_()
        return _DOCK
    if iface is not None:                       # reuse an existing dock if any
        try:
            found = None
            for d in iface.mainWindow().findChildren(QtWidgets.QDockWidget):
                if d.objectName() != "LabelMyNetworkTableDock":
                    continue
                if found is None and isinstance(d, LabelTableDock):
                    found = d                   # keep the first real one
                else:
                    d.close()                   # drop stale/duplicate docks
                    d.setParent(None)
            if found is not None:
                _DOCK = found
                found.show()
                found.raise_()
                return found
        except Exception:
            pass
    _DOCK = LabelTableDock(iface, iface.mainWindow() if iface else None)
    if iface is not None:
        # open FULLY docked via the shared helper (works from either copy)
        try:
            from ..fibre_automation import dock_util as _du
        except Exception:
            try:
                from . import dock_util as _du
            except Exception:
                try:
                    from fibre_automation import dock_util as _du
                except Exception:
                    _du = None
        if _du is not None:
            _du.dock_fully(iface, _DOCK, width=460)
        else:
            iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, _DOCK)
    _DOCK.show()
    _DOCK.raise_()
    return _DOCK


# ---------------------------------------------------------------------------
# small helpers
# ---------------------------------------------------------------------------
def _lbl(text):
    la = QtWidgets.QLabel(text)
    la.setObjectName("fld")
    return la


def _s(v):
    if v is None:
        return ""
    return str(v)


def _cell(text, colour, mono=False, bold=False):
    it = QtWidgets.QTableWidgetItem(text)
    it.setForeground(QtGui.QColor(colour))
    it.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
    f = it.font()
    if mono:
        f.setFamily("Consolas")
    if bold:
        f.setBold(True)
    it.setFont(f)
    return it


def _pick(layer, *cands):
    try:
        names = layer.fields().names()
    except Exception:
        return cands[0] if cands else ""
    for c in cands:
        if c in names:
            return c
    return names[0] if names else ""


def _clear(layout):
    while layout.count():
        it = layout.takeAt(0)
        wdg = it.widget()
        if wdg is not None:
            wdg.setParent(None)


def _qss():
    return """
    #vnLblTblRoot{background:%(bg)s;color:%(ink)s;font-family:'Segoe UI';}
    QLabel{color:%(ink)s;}
    #tbar,#statusbar{background:%(head)s;border-bottom:1px solid %(line)s;}
    #statusbar{border-bottom:0;border-top:1px solid %(line2)s;}
    #brand{font-weight:700;letter-spacing:1px;}
    #beta{color:%(amber)s;border:1px solid %(amber)s;border-radius:3px;
          padding:0px 5px;font-size:9px;}
    #hint{color:%(dim)s;font-size:11px;}
    #fld{color:%(mut)s;font-size:11px;}
    QLineEdit#mono{background:%(panel)s;border:1px solid %(line2)s;
          border-radius:6px;padding:4px 8px;color:%(ink)s;
          font-family:'Consolas';}
    QComboBox{background:%(panel)s;border:1px solid %(line2)s;border-radius:6px;
          padding:4px 9px;color:%(ink)s;}
    QComboBox QAbstractItemView{background:%(panel)s;color:%(ink)s;
          selection-background-color:%(sel)s;}
    #rail{background:%(panel)s;border-right:1px solid %(line)s;}
    #railhead{color:%(mut)s;font-size:10px;letter-spacing:2px;
          padding:12px 14px 6px;}
    #railList{background:transparent;border:0;outline:0;}
    #railList::item{border-left:3px solid transparent;padding:8px 12px;
          color:%(ink)s;}
    #railList::item:selected{background:%(sel)s;border-left:3px solid %(cyan)s;
          color:%(ink)s;}
    #fcbar{background:#161d25;border-bottom:1px solid %(line)s;}
    #fx{color:%(cyan)s;font-weight:700;font-family:'Consolas';}
    #expr{background:%(panel)s;border:1px solid %(line2)s;border-radius:7px;
          padding:6px 11px;font-family:'Consolas';}
    #drawer{background:#0b1015;border-bottom:1px solid %(line)s;}
    #cap{color:%(mut)s;font-size:11px;}
    #bigexpr{background:%(panel)s;border:1px solid %(line2)s;border-radius:8px;
          padding:10px 12px;}
    #legend{color:%(mut)s;font-size:11px;}
    #status{color:%(mut)s;font-size:12px;}
    QPushButton#gh{background:transparent;border:1px solid %(line2)s;
          border-radius:8px;padding:7px 13px;color:%(ink)s;}
    QPushButton#gh:hover{border-color:%(cyan)s;color:%(cyan)s;}
    QPushButton#gh:checked{border-color:%(cyan)s;color:%(cyan)s;}
    QPushButton#go{background:%(cyan)s;border:0;border-radius:8px;
          padding:8px 18px;color:#04222b;font-weight:700;}
    QCheckBox{color:%(mut)s;font-size:12px;}
    QTableWidget#attrTable{background:%(bg)s;border:0;gridline-color:%(line)s;
          color:%(ink)s;}
    QHeaderView::section{background:%(head)s;color:%(mut)s;border:0;
          border-bottom:2px solid %(line2)s;padding:7px 12px;
          font-weight:700;}
    QTableWidget#attrTable::item{padding:5px 12px;}
    QTableWidget#attrTable::item:selected{background:%(sel)s;}
    """ % {"bg": _BG, "panel": _PANEL, "head": _HEAD, "line": _LINE,
           "line2": _LINE2, "ink": _INK, "mut": _MUT, "dim": _DIM,
           "cyan": _CYAN, "amber": _AMBER, "sel": _SEL}
