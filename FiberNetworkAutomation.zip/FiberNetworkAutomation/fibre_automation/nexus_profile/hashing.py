"""hashing — password hashing with the STDLIB only (no bcrypt/argon2 = no pip).

PBKDF2-HMAC-SHA256, 200k iterations. Salt + hash are hex strings; the salt is
stored alongside the hash. Plaintext never leaves the laptop. Pure Python —
unit-testable without QGIS.
"""
import hashlib
import hmac
import os

_ITERS = 200_000


def new_salt():
    return os.urandom(16).hex()


def hash_password(password, salt=None):
    """Return (hash_hex, salt_hex). Pass an existing salt to re-derive."""
    if salt is None:
        salt = new_salt()
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                             bytes.fromhex(salt), _ITERS)
    return dk.hex(), salt


def verify_password(password, hash_hex, salt_hex):
    """Constant-time check of password against a stored hash+salt."""
    calc, _ = hash_password(password, salt_hex)
    return hmac.compare_digest(calc, hash_hex)


def sha256_hex(text):
    """For the team-code check (compare to config.TEAM_CODE_HASH)."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()
