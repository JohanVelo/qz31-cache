"""Pole-to-pole span scanning — the measurement core of the Span Inspector.

WHAT A SPAN IS (JJ, 2026-07-23 — this is the whole point of the tool):

    A span is the run from ONE POLE to the NEXT POLE, measured ALONG the cable
    geometry. It is NOT the whole cable, and it is NOT vertex-to-vertex.

Poles are placed ON the cable, but the cable's VERTICES are not poles. A cable can
run dead straight through six poles with no vertex between them, or bend twice
between two poles. So measuring vertex→vertex is simply the wrong question: it
reported 181.9 m across a stretch that is really four ~45 m spans, and flagged
violations that do not exist. (v1 did exactly that; JJ measured 42.793 m by hand
where v1 claimed a violation.)

The algorithm, per cable part:
  1. walk the vertices, accumulating TRUE metre distance along the line;
  2. find every pole lying on that cable (perpendicular distance <= tolerance),
     and project each onto the line to get its distance-along;
  3. sort the poles by distance-along;
  4. each consecutive PAIR of poles is one span, its length the difference of
     their distances-along — i.e. the cable path between them, bends included.

DROPS AND CABLE ENDS (JJ, 2026-07-23): a drop runs pole → house, so it carries only
ONE pole and strict pole-to-pole finds nothing — 2,848 Malmesbury drops yielded just
81 spans. With `include_ends=True` (the default) the cable's own ends also bound a
span, so a drop's pole → house run is measured, which is what "is this drop over
30 m?" actually means. On a backbone cable that already starts and ends at a pole the
end coincides with that pole and is collapsed away, so nothing changes there. Pass
`include_ends=False` for strict pole-to-pole only.

READ-ONLY: nothing here opens an edit session or writes a feature. Safe on live
Mohadin PH2 / Malmesbury, which are write-off-limits.

Measurement goes through `crs_utils.metre_measurer`, which verifies it really
returns metres. Never call `setEllipsoid` directly: an ellipsoid of 'NONE' is
truthy, so an `or "WGS84"` fallback never fires and every length silently comes back
in DEGREES (incident 2026-07-15).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

# The dial the operator turns. 70 m is the ADSS feeder/distribution limit; drops
# spec at 55 m (relaxed from 50 m, JJ 2026-04-17).
DEFAULT_LIMIT_M = 70.0
MIN_LIMIT_M = 0.0
MAX_LIMIT_M = 100.0

# How far off the line a pole may sit and still count as "on this cable". Poles are
# snapped onto the route when placed, so this only absorbs rounding + hand-nudges.
DEFAULT_POLE_TOL_M = 2.0

# Two poles closer together than this along the line are treated as one structure
# (duplicate/stacked poles) rather than a zero-length span.
_MIN_SPAN_M = 0.05

# Shown in the results list where a span ends at the cable itself (a drop's
# house end) rather than at a pole.
END_LABEL = "cable end"

_LABEL_FIELDS = ("label", "name", "pole_id", "cable_id", "id")
_POLE_HINTS = ("pole", "paal")
# Splitter node layers — the Span Inspector can measure spans to SPLITTERS (STS/FTS)
# instead of poles, so a drop's splitter→house run is checked against the drop limit.
_SPLITTER_HINTS = ("splitter", "sts", "fts", "spl")


@dataclass(frozen=True)
class Span:
    """One pole-to-pole run along a cable."""

    layer_id: str
    layer_name: str
    feature_id: int
    label: str                 # the CABLE's label
    index: int                 # 1-based span number along that cable
    length_m: float            # distance ALONG the cable between the two poles
    pole_a: str                # label of the pole at the start
    pole_b: str                # label of the pole at the end
    path: list = field(default_factory=list)   # QgsPointXY route between the poles

    @property
    def p1(self):
        return self.path[0] if self.path else None

    @property
    def p2(self):
        return self.path[-1] if self.path else None

    @property
    def key(self):
        """Stable identity — used to diff one scan against the next."""
        return (self.layer_id, self.feature_id, self.index)


def clamp_limit(value) -> float:
    """Force any user input into the supported 0–100 m range."""
    try:
        v = float(value)
    except (TypeError, ValueError):
        return DEFAULT_LIMIT_M
    if math.isnan(v):
        return DEFAULT_LIMIT_M
    return max(MIN_LIMIT_M, min(MAX_LIMIT_M, v))


def label_field(layer):
    """First present name-ish field, else None (callers fall back to the fid)."""
    try:
        names = {f.name().lower(): f.name() for f in layer.fields()}
    except Exception:
        return None
    for want in _LABEL_FIELDS:
        if want in names:
            return names[want]
    return None


def _feat_label(feat, lfield, prefix="fid"):
    if lfield is not None:
        try:
            raw = feat[lfield]
            if raw is not None and str(raw).strip():
                return str(raw)
        except Exception:
            pass
    return f"{prefix} {feat.id()}"


def _parts(geom):
    """Vertex lists for a line geometry — one per part, [] if unusable.

    Guards BOTH None and isEmpty (the null-geometry bug class).
    """
    if geom is None or geom.isEmpty():
        return []
    try:
        if geom.isMultipart():
            return [p for p in geom.asMultiPolyline() if p and len(p) >= 2]
        line = geom.asPolyline()
        return [line] if line and len(line) >= 2 else []
    except Exception:
        return []


def is_line_layer(layer):
    try:
        from qgis.core import QgsMapLayer, QgsWkbTypes
        return (layer.type() == QgsMapLayer.LayerType.VectorLayer
                and layer.geometryType() == QgsWkbTypes.GeometryType.LineGeometry)
    except Exception:
        return False


def is_point_layer(layer):
    try:
        from qgis.core import QgsMapLayer, QgsWkbTypes
        return (layer.type() == QgsMapLayer.LayerType.VectorLayer
                and layer.geometryType() == QgsWkbTypes.GeometryType.PointGeometry)
    except Exception:
        return False


def find_pole_layers(project=None):
    """Point layers that look like pole/structure layers, best guess first."""
    from qgis.core import QgsProject
    project = project or QgsProject.instance()
    pts = [l for l in project.mapLayers().values() if is_point_layer(l)]
    named = [l for l in pts if any(h in l.name().lower() for h in _POLE_HINTS)]
    named.sort(key=lambda l: (0 if l.name().lower().strip() in ("poles", "pole")
                              else 1, l.name().lower()))
    return named or pts


def find_splitter_layers(project=None):
    """Point layers that look like SPLITTER layers (STS/FTS), best guess first — the
    node set for a drop→splitter distance check. Named matches only; if none match,
    returns [] (unlike find_pole_layers, we do NOT fall back to every point layer here,
    so 'Splitters' mode never silently offers pole layers)."""
    from qgis.core import QgsProject
    project = project or QgsProject.instance()
    pts = [l for l in project.mapLayers().values() if is_point_layer(l)]
    named = [l for l in pts if any(h in l.name().lower() for h in _SPLITTER_HINTS)]
    named.sort(key=lambda l: (0 if "sts" in l.name().lower() else 1, l.name().lower()))
    return named


class PoleIndex:
    """Poles prepared once, reused for every cable (spatial index + labels).

    Built in the CABLE layer's CRS so projections need no per-point transform.
    """

    def __init__(self, pole_layer, target_crs, project=None):
        from qgis.core import (QgsCoordinateTransform, QgsFeatureRequest,
                               QgsProject, QgsSpatialIndex)
        project = project or QgsProject.instance()
        self.points = {}          # fid -> QgsPointXY (in target_crs)
        self.labels = {}          # fid -> label
        self.index = QgsSpatialIndex()
        if pole_layer is None:
            return
        lfield = label_field(pole_layer)
        xform = None
        try:
            if pole_layer.crs() != target_crs:
                xform = QgsCoordinateTransform(pole_layer.crs(), target_crs, project)
        except Exception:
            xform = None
        from qgis.core import QgsFeature, QgsGeometry
        feats = []
        for f in pole_layer.getFeatures(QgsFeatureRequest()):
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            try:
                pt = g.asPoint()
            except Exception:
                continue
            if xform is not None:
                try:
                    pt = xform.transform(pt)
                except Exception:
                    continue
            self.points[f.id()] = pt
            self.labels[f.id()] = _feat_label(f, lfield, prefix="pole")
            nf = QgsFeature(f.id())
            nf.setGeometry(QgsGeometry.fromPointXY(pt))
            feats.append(nf)
        if feats:
            self.index.addFeatures(feats)

    def __len__(self):
        return len(self.points)

    def near(self, rect):
        return self.index.intersects(rect)


def _cumulative(pts, da):
    """Cumulative TRUE metres at each vertex. cum[0] = 0."""
    cum = [0.0]
    total = 0.0
    for i in range(len(pts) - 1):
        try:
            d = da.measureLine(pts[i], pts[i + 1])
        except Exception:
            d = 0.0
        if not math.isfinite(d) or d < 0:
            d = 0.0
        total += d
        cum.append(total)
    return cum


def _poles_on_part(pts, cum, poles, da, tol_m, include_ends=False):
    """[(along_m, QgsPointXY, label)] for every structure bounding a span.

    Poles sitting on this part, plus — when `include_ends` — the cable's own two
    ends. Ends matter for DROPS: a drop runs pole → house, so it carries only ONE
    pole and pure pole-to-pole finds no span at all (2,848 Malmesbury drops yielded
    81 spans). Treating the cable end as the far structure makes the drop itself
    measurable, which is what an operator means by "is this drop over 30 m?".

    On a cable that already starts/ends at a pole the end coincides with that pole
    and is collapsed away, so backbone cables are unaffected.
    """
    from qgis.core import QgsGeometry, QgsPointXY, QgsRectangle
    if not poles or len(poles) == 0:
        return []
    line = QgsGeometry.fromPolylineXY(pts)
    # bbox + a generous degree-or-metre padding; the real test is the metre check
    rect = QgsRectangle(line.boundingBox())
    pad = max(rect.width(), rect.height()) * 0.02 or 0.001
    rect.grow(pad)
    found = []
    for fid in poles.near(rect):
        pt = poles.points.get(fid)
        if pt is None:
            continue
        try:
            # closestSegmentWithContext -> (sqrDist, closestPoint, indexOfNextVertex, ...)
            res = line.closestSegmentWithContext(pt)
            closest = QgsPointXY(res[1])
            nxt = int(res[2])
        except Exception:
            continue
        try:
            off = da.measureLine(pt, closest)          # perpendicular offset, metres
        except Exception:
            continue
        if not math.isfinite(off) or off > tol_m:
            continue                                    # pole is not on this cable
        i = max(1, min(nxt, len(pts) - 1))              # segment pts[i-1] -> pts[i]
        try:
            along = cum[i - 1] + da.measureLine(pts[i - 1], closest)
        except Exception:
            continue
        if not math.isfinite(along):
            continue
        found.append((along, closest, poles.labels.get(fid, f"pole {fid}"), True))
    if include_ends:
        found.append((0.0, pts[0], END_LABEL, False))
        found.append((cum[-1], pts[-1], END_LABEL, False))
    found.sort(key=lambda t: t[0])
    # Collapse stacked poles / an end that sits on a pole, so neither can create a
    # 0 m span. A real pole always wins the label over a cable end.
    out = []
    for item in found:
        if out and (item[0] - out[-1][0]) < _MIN_SPAN_M:
            if item[3] and not out[-1][3]:          # pole beats a coincident end
                out[-1] = item
            continue
        out.append(item)
    return [(a, p, lbl) for a, p, lbl, _is_pole in out]


def _path_between(pts, cum, a_along, a_pt, b_along, b_pt):
    """The cable route between two projected poles, bends included."""
    path = [a_pt]
    for i, c in enumerate(cum):
        if a_along < c < b_along:
            path.append(pts[i])
    path.append(b_pt)
    return path


def iter_spans(cable_layer, pole_index, da=None, project=None,
               tol_m=DEFAULT_POLE_TOL_M, include_ends=True):
    """Yield EVERY pole-to-pole span on `cable_layer` (no limit applied)."""
    try:
        from .shared.crs_utils import metre_measurer
    except ImportError:
        from fibre_automation.shared.crs_utils import metre_measurer

    if cable_layer is None or pole_index is None or len(pole_index) == 0:
        return
    if da is None:
        da = metre_measurer(cable_layer.crs(), project)
    lid = cable_layer.id()
    lname = cable_layer.name()
    lfield = label_field(cable_layer)
    for feat in cable_layer.getFeatures():
        try:
            geom = feat.geometry()
        except Exception:
            continue
        label = _feat_label(feat, lfield, prefix="cable")
        n = 0
        for pts in _parts(geom):
            cum = _cumulative(pts, da)
            on = _poles_on_part(pts, cum, pole_index, da, tol_m, include_ends)
            for k in range(len(on) - 1):
                a_along, a_pt, a_lbl = on[k]
                b_along, b_pt, b_lbl = on[k + 1]
                length = b_along - a_along
                if not math.isfinite(length) or length <= 0:
                    continue
                n += 1
                yield Span(lid, lname, feat.id(), label, n, float(length),
                           a_lbl, b_lbl,
                           _path_between(pts, cum, a_along, a_pt, b_along, b_pt))


def scan_layer(cable_layer, pole_index, limit_m=DEFAULT_LIMIT_M, project=None,
               tol_m=DEFAULT_POLE_TOL_M, include_ends=True):
    """Pole-to-pole spans on `cable_layer` STRICTLY longer than limit_m.

    Strictly greater: a span measuring exactly the limit is compliant.
    """
    limit = clamp_limit(limit_m)
    over = [s for s in iter_spans(cable_layer, pole_index, project=project,
                                  tol_m=tol_m, include_ends=include_ends)
            if s.length_m > limit]
    over.sort(key=lambda s: s.length_m, reverse=True)
    return over


def scan_layers(cable_layers, pole_layer, limit_m=DEFAULT_LIMIT_M, project=None,
                tol_m=DEFAULT_POLE_TOL_M, include_ends=True):
    """Pole-to-pole spans over the limit across several cable layers.

    One PoleIndex is built per distinct cable CRS and reused.
    """
    from qgis.core import QgsProject
    project = project or QgsProject.instance()
    out = []
    cache = {}
    for lyr in cable_layers or []:
        try:
            authid = lyr.crs().authid()
            if authid not in cache:
                cache[authid] = PoleIndex(pole_layer, lyr.crs(), project)
            out.extend(scan_layer(lyr, cache[authid], limit_m, project=project,
                                  tol_m=tol_m, include_ends=include_ends))
        except Exception:
            continue          # a bad layer must not kill the whole scan
    out.sort(key=lambda s: s.length_m, reverse=True)
    return out


def scan_all(cable_layers, pole_layer, project=None, tol_m=DEFAULT_POLE_TOL_M,
             include_ends=True):
    """EVERY pole-to-pole span across the cable layers, longest first.

    Measure once, filter many: callers that let the operator move a limit slider
    should call this ONCE and then use `over_limit()` per limit value. Re-measuring
    on every slider tick rebuilds the pole index each time — on a 4,800-pole project
    that is ~2 s a tick, which feels broken.
    """
    from qgis.core import QgsProject
    project = project or QgsProject.instance()
    out = []
    cache = {}
    for lyr in cable_layers or []:
        try:
            authid = lyr.crs().authid()
            if authid not in cache:
                cache[authid] = PoleIndex(pole_layer, lyr.crs(), project)
            out.extend(iter_spans(lyr, cache[authid], project=project,
                                  tol_m=tol_m, include_ends=include_ends))
        except Exception:
            continue
    out.sort(key=lambda s: s.length_m, reverse=True)
    return out


def over_limit(spans, limit_m=DEFAULT_LIMIT_M):
    """Filter an already-measured span list. Strictly greater than the limit."""
    limit = clamp_limit(limit_m)
    return [s for s in spans or [] if s.length_m > limit]


def count_spans(cable_layers, pole_layer, project=None, tol_m=DEFAULT_POLE_TOL_M,
                include_ends=True):
    """Total pole-to-pole spans found (any length) — the denominator for context."""
    from qgis.core import QgsProject
    project = project or QgsProject.instance()
    total = 0
    cache = {}
    for lyr in cable_layers or []:
        try:
            authid = lyr.crs().authid()
            if authid not in cache:
                cache[authid] = PoleIndex(pole_layer, lyr.crs(), project)
            total += sum(1 for _ in iter_spans(lyr, cache[authid], project=project,
                                               tol_m=tol_m,
                                               include_ends=include_ends))
        except Exception:
            continue
    return total


def summarise(spans):
    """(total, worst_length, {layer_name: count}) for the panel's result chip."""
    per = {}
    worst = 0.0
    for s in spans:
        per[s.layer_name] = per.get(s.layer_name, 0) + 1
        if s.length_m > worst:
            worst = s.length_m
    return len(spans), worst, per
