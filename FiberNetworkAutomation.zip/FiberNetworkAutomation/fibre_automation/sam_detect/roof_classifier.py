"""roof_classifier — self-contained MobileNetV3 building/non-building appearance
gate for the vacant-erf rescue path.

A point-prompt on a vacant stand returns *some* SAM mask (bare ground, a tree,
a shadow). The shape/area/spectral gates catch a lot, but NOT dry cleared
ground — and we must NOT filter by shape class, because real houses are often
irregular ("complex") and the operator wants those kept and tightly outlined.
So we judge by APPEARANCE: score a 64x64 roof patch with a small MobileNetV3
trained on SA building-vs-non-building patches. High recall (~0.90) → real roofs
(any shape) pass; a chunk of bare-ground/vegetation grabs are dropped.

Fully self-contained (erven_mcp is NOT bundled): inlines the same architecture
+ inference as erven_mcp/training/train_classifier.py. Degrades gracefully to
None (gate skipped) if torch/torchvision or the checkpoint are missing, so the
plugin never hard-depends on it.

Checkpoint: env VF_ROOF_CLASSIFIER, else the erven_mcp default
C:/Temp/building_classifier_v3.pt. Threshold: env VF_ROOF_CLF_THRESH (0.5).
"""
from __future__ import annotations

import os

_MEAN = [0.485, 0.456, 0.406]
_STD = [0.229, 0.224, 0.225]

_cache = {"tried": False, "model": None, "device": None, "tfm": None}


def _ckpt_path():
    env = os.environ.get("VF_ROOF_CLASSIFIER")
    if env:
        return env
    return "C:/Temp/building_classifier_v3.pt"


def threshold():
    try:
        return float(os.environ.get("VF_ROOF_CLF_THRESH", "0.5"))
    except ValueError:
        return 0.5


def _build_model():
    import torch.nn as nn
    from torchvision import models
    m = models.mobilenet_v3_small(weights=None)
    in_f = m.classifier[0].in_features
    m.classifier = nn.Sequential(
        nn.Linear(in_f, 128), nn.Hardswish(),
        nn.Dropout(p=0.3, inplace=True), nn.Linear(128, 1))
    return m


def get_classifier():
    """Return (model, device, transform) or None if unavailable (once-cached)."""
    if _cache["tried"]:
        return None if _cache["model"] is None else (
            _cache["model"], _cache["device"], _cache["tfm"])
    _cache["tried"] = True
    path = _ckpt_path()
    if not os.path.isfile(path):
        return None
    try:
        import torch
        from torchvision import transforms
        # Always CPU: the model is tiny (MobileNetV3-Small — scoring a few dozen
        # patches is instant on CPU) and the SAM worker forces CPU by hiding the
        # GPU (CUDA_VISIBLE_DEVICES=""), which leaves torch.cuda.is_available()
        # stale-True but device_count 0 → a CUDA map_location would crash the load.
        device = "cpu"
        ckpt = torch.load(path, map_location="cpu", weights_only=False)
        model = _build_model().to(device)
        model.load_state_dict(ckpt["model_state_dict"])
        model.eval()
        tfm = transforms.Compose([
            transforms.ToPILImage(), transforms.ToTensor(),
            transforms.Normalize(mean=_MEAN, std=_STD)])
        _cache.update(model=model, device=device, tfm=tfm)
        return model, device, tfm
    except Exception as _e:
        import sys as _s
        _s.stderr.write(f"[roof_classifier] load failed (gate skipped): "
                        f"{type(_e).__name__}: {_e}\n")
        return None


def score_patch(rgb_patch):
    """Building-likeness [0..1] for one 64x64x3 uint8 RGB patch (h-/v-flip TTA).
    Returns None if the classifier is unavailable."""
    clf = get_classifier()
    if clf is None:
        return None
    model, device, tfm = clf
    try:
        import cv2
        import torch
        p = rgb_patch
        if p.shape[0] != 64 or p.shape[1] != 64:
            p = cv2.resize(p, (64, 64), interpolation=cv2.INTER_LINEAR)
        t = tfm(p).unsqueeze(0).to(device)
        with torch.no_grad():
            logit = model(t)
            logit = (logit + model(t.flip(dims=[3]))
                     + model(t.flip(dims=[2]))) / 3.0
            return float(torch.sigmoid(logit).squeeze().item())
    except Exception:
        return None
