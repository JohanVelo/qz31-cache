"""dxf_export — contractor CAD drawing (DXF) of the network. Native QgsDxfExport, zero deps.

DXF is what civil/CAD contractors expect for trenching + as-builts. QGIS exports it
natively (QgsDxfExport), so no ezdxf/external library is needed — it ships in the team
plugin and runs in QGIS's bundled Python.

Read-only on the project. Exports in the layers' own (projected) CRS by default, which
is what CAD wants — metres, not degrees.

API:  build_dxf(layers, out_path, dest_crs=None, scale=1000) -> {"layers":n,"ok":bool,..}
"""
from qgis.core import (QgsDxfExport, QgsMapLayer, QgsWkbTypes, QgsProject,
                       QgsCoordinateReferenceSystem, QgsCoordinateTransform)
from qgis.PyQt.QtCore import QFile, QIODevice

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass


def _metric_crs_for(layers):
    """CAD wants metres. If the data is in a projected (metric) CRS, keep it; if it's
    geographic (degrees), auto-pick the right UTM zone from the data's centroid so the
    DXF comes out in metres instead of tiny degree values."""
    src = layers[0].crs()
    if src.isValid() and not src.isGeographic():
        return src
    wgs = QgsCoordinateReferenceSystem("EPSG:4326")
    try:
        # An empty layer yields a null extent whose .center() is (0,0), which would
        # silently pick UTM zone 31N — wrong by hundreds of km for SA. Use the first
        # layer that actually has features; if none do, fall through to src below.
        cands = [l for l in layers if not l.extent().isNull()]
        if not cands:
            return src
        xf = QgsCoordinateTransform(src, wgs, QgsProject.instance())
        c = xf.transform(cands[0].extent().center())
        lon, lat = c.x(), c.y()
        zone = int((lon + 180) / 6) % 60 + 1
        epsg = (32700 if lat < 0 else 32600) + zone        # WGS84 / UTM S or N
        utm = QgsCoordinateReferenceSystem(f"EPSG:{epsg}")
        if utm.isValid():
            return utm
    except Exception:
        _swallowed_note()
    return src


def _result_code(res):
    """QgsDxfExport.writeToFile()'s result -> plain int (0 == Success).

    On Qt6 it is a SCOPED enum (QgsDxfExport.ExportResult), and int() on that raises
    TypeError — which used to blow up *after* the .dxf had already been written
    correctly, so the operator saw "Export failed: int() argument must be…" next to a
    perfectly good file. On Qt5 it is already an int. Unknown types -> -1 (not 0), so
    an unrecognised result can never be mistaken for success.
    """
    if isinstance(res, int):
        return res
    val = getattr(res, "value", None)
    try:
        return int(val)
    except (TypeError, ValueError):
        return -1


def build_dxf(layers, out_path, dest_crs=None, scale=1000, encoding="CP1252"):
    layers = [l for l in layers
              if l is not None
              and l.type() == QgsMapLayer.LayerType.VectorLayer
              and l.geometryType() in (QgsWkbTypes.GeometryType.PointGeometry,
                                       QgsWkbTypes.GeometryType.LineGeometry,
                                       QgsWkbTypes.GeometryType.PolygonGeometry)]
    if not layers:
        return {"layers": 0, "path": out_path, "ok": False, "msg": "no vector layers"}

    dxf = QgsDxfExport()
    dxf.addLayers([QgsDxfExport.DxfLayer(l) for l in layers])
    dxf.setSymbologyScale(scale)
    dxf.setSymbologyExport(QgsDxfExport.SymbologyExport.FeatureSymbology)
    # CAD contractors want metres — keep a projected CRS, auto-UTM a geographic one
    crs = dest_crs or _metric_crs_for(layers)
    if isinstance(crs, str):
        crs = QgsCoordinateReferenceSystem(crs)
    if crs is not None and crs.isValid():
        dxf.setDestinationCrs(crs)

    if not out_path.lower().endswith(".dxf"):
        out_path += ".dxf"
    f = QFile(out_path)
    if not f.open(QIODevice.OpenModeFlag.WriteOnly | QIODevice.OpenModeFlag.Truncate):
        return {"layers": len(layers), "path": out_path, "ok": False, "msg": "cannot open file"}
    try:
        res = dxf.writeToFile(f, encoding)
    finally:
        f.close()
    code = _result_code(res)
    ok = code == 0              # QgsDxfExport.ExportResult.Success == 0
    return {"layers": len(layers), "path": out_path, "ok": ok, "result": code,
            "crs": crs.authid() if crs and crs.isValid() else None}
