"""Venv subprocess runner for the no-data OSM erven fallback (osmnx/geopandas
aren't in plain QGIS). Runs OUTSIDE the QGIS process.
Usage: python osm_blocks_runner.py xmin ymin xmax ymax out.geojson"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import osm_blocks

if __name__ == '__main__':
    xmin, ymin, xmax, ymax = (float(a) for a in sys.argv[1:5])
    out = sys.argv[5]
    gdf = osm_blocks.generate_nodata_erven(xmin, ymin, xmax, ymax)
    gdf.to_file(out, driver='GeoJSON')
    print(f'OSM erven written: {len(gdf)} -> {out}')
