"""Connectivity Check — the dialog. Ticket #140 (Luke, 2026-07-28).

# claude:boq-impact SPLIT, and the two halves are deliberately not the same tool.
# The POLES tab and the scan half of the HOMES tab are strictly READ-ONLY: they
# open layers, measure, and list. No BoQ line can move.
# The ATTACH button DOES change the BoQ — every drop cable it adds is a real drop
# on a real bill. So it is a separate, explicit press, behind a confirmation that
# states the count and the metres up front, behind a backup that must re-open, and
# it is never reached by simply scanning. Nothing here runs automatically.
#
# claude:intent MUTATE — user asked (ticket #140): "the green dot is a pole that
# has no geometry attached to it.. I would like a tool where you can highlight all
# the poles for me that have no other geometry attached to them ... and then the
# blue dots are demand points that should have drop cables going to them but in
# this case it looks to me that there are quite a few demand points with now
# drops", then "build everything, taste everything, do everything". Plan: one
# panel that answers both questions, shows its working (which cables it paired and
# how strongly), highlights the offenders on the map because that is what was
# actually asked for, and only then offers to attach.
#
# claude:approved-destructive — the attach is gated on the SAME backup contract the
# Merge and Reshape tools use: `pon_merge.backup_is_usable` must find the backup on
# disk AND re-open it as a readable dataset before one cable is written. Proven end
# to end on a throwaway copy of Luke's real project by
# research/connectivity_verify/check.py (41/41), including the refusal path.

Qt6-safe per the plugin's rules: imports through the ``qgis.PyQt`` shim, fully
scoped enums, ``WA_DeleteOnClose``, and no value read off a dead widget.
"""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QComboBox,
    QDialog,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from . import connectivity_scan as cs
from . import drop_attach as da
from . import pon_merge

_POLE_HEADERS = ["Pole", "Nearest cable"]
_HOME_HEADERS = ["Home", "Feeds from", "Drop length", "New label"]


class _MetreItem(QTableWidgetItem):
    """A "62.4 m" cell that sorts as a NUMBER.

    ``QTableWidgetItem`` compares its DisplayRole, so a plain text cell sorts
    "9.4 m" after "62.4 m" and buries the worst offender in the middle of the
    list — the same trap the Reshaper hit with percentages.
    """

    def __init__(self, metres):
        super().__init__(f"{float(metres):.1f} m")
        self._m = float(metres)
        self.setTextAlignment(int(Qt.AlignmentFlag.AlignRight
                                  | Qt.AlignmentFlag.AlignVCenter))

    def __lt__(self, other):
        if isinstance(other, _MetreItem):
            return self._m < other._m
        return super().__lt__(other)


def _unique_labels(rows):
    """``{fid: text}`` where a repeated label gains its feature id.

    Measured on JJ's live Matiko project: the demand layer carries no per-home
    label, so every one of the 247 unserved rows rendered as "PON 9" / "PON 8" —
    a list you cannot navigate. Only the ambiguous ones are suffixed, so a layer
    with real labels is left exactly as it reads in the attribute table.
    """
    seen = {}
    for fid, _pt, _d, label in rows:
        seen[str(label)] = seen.get(str(label), 0) + 1
    out = {}
    for fid, _pt, _d, label in rows:
        text = str(label)
        out[fid] = f"{text}  #{fid}" if seen.get(text, 0) > 1 else text
    return out


class ConnectivityDialog(QDialog):
    """Find poles with nothing attached, and homes with no drop cable."""

    def __init__(self, project, parent=None, iface=None):
        super().__init__(parent)
        self._project = project
        self._iface = iface
        self._pole_rows = []
        self._paired = []
        self._unserved = []
        self._proposals = []
        self._pstats = {}
        self.setWindowTitle("Connectivity Check")
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self.setMinimumSize(720, 600)
        self._build()
        self._refresh_layer_lists()

    # ── construction ────────────────────────────────────────────────────────
    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(10)

        self._tabs = QTabWidget()
        self._tabs.addTab(self._build_poles_tab(), "Poles with nothing on them")
        self._tabs.addTab(self._build_homes_tab(), "Homes with no drop")
        root.addWidget(self._tabs, 1)

        foot = QHBoxLayout()
        foot.addStretch(1)
        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.reject)
        foot.addWidget(btn_close)
        root.addLayout(foot)

    def _build_poles_tab(self):
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(8)

        intro = QLabel(
            "Finds poles with no cable attached to them &mdash; Luke&rsquo;s green "
            "dots.<br>Read-only: this tab never writes anything.")
        intro.setWordWrap(True)
        intro.setTextFormat(Qt.TextFormat.RichText)
        lay.addWidget(intro)

        grid = QGridLayout()
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(6)
        grid.addWidget(QLabel("Poles:"), 0, 0)
        self._cbo_poles = QComboBox()
        self._cbo_poles.currentIndexChanged.connect(self._invalidate_poles)
        grid.addWidget(self._cbo_poles, 0, 1)

        grid.addWidget(QLabel("Count as unattached when:"), 1, 0)
        self._cbo_band = QComboBox()
        for key, metres, label in cs.BANDS:
            self._cbo_band.addItem(f"{label} ({metres:g} m)", key)
        idx = self._cbo_band.findData(cs.DEFAULT_BAND)
        if idx >= 0:
            self._cbo_band.setCurrentIndex(idx)
        self._cbo_band.currentIndexChanged.connect(self._invalidate_poles)
        grid.addWidget(self._cbo_band, 1, 1)
        grid.setColumnStretch(1, 1)
        lay.addLayout(grid)

        row = QHBoxLayout()
        self._btn_scan_poles = QPushButton("Find them")
        self._btn_scan_poles.clicked.connect(self._on_scan_poles)
        row.addWidget(self._btn_scan_poles)
        self._btn_hl_poles = QPushButton("Highlight all on the map")
        self._btn_hl_poles.setEnabled(False)
        self._btn_hl_poles.clicked.connect(self._on_highlight_poles)
        row.addWidget(self._btn_hl_poles)
        row.addStretch(1)
        lay.addLayout(row)

        self._pole_table = self._make_table(_POLE_HEADERS)
        self._pole_table.itemSelectionChanged.connect(self._on_pole_row)
        lay.addWidget(self._pole_table, 1)

        self._pole_summary = QLabel("")
        self._pole_summary.setWordWrap(True)
        self._pole_summary.setTextFormat(Qt.TextFormat.RichText)
        lay.addWidget(self._pole_summary)
        return page

    def _build_homes_tab(self):
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(8)

        intro = QLabel(
            "Finds homes with no drop cable &mdash; Luke&rsquo;s blue dots &mdash; "
            "and can attach one to the nearest splitter with room.<br>"
            "<b>Attaching adds real drop cables and therefore changes the BoQ.</b> "
            "Nothing is written until you press <b>Attach</b>.")
        intro.setWordWrap(True)
        intro.setTextFormat(Qt.TextFormat.RichText)
        lay.addWidget(intro)

        grid = QGridLayout()
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(6)
        grid.addWidget(QLabel("Homes:"), 0, 0)
        self._cbo_demand = QComboBox()
        self._cbo_demand.currentIndexChanged.connect(self._invalidate_homes)
        grid.addWidget(self._cbo_demand, 0, 1)
        grid.addWidget(QLabel("Drop cables:"), 1, 0)
        self._cbo_drops = QComboBox()
        self._cbo_drops.currentIndexChanged.connect(self._invalidate_homes)
        grid.addWidget(self._cbo_drops, 1, 1)
        grid.addWidget(QLabel("Splitters:"), 2, 0)
        self._cbo_splitters = QComboBox()
        self._cbo_splitters.currentIndexChanged.connect(self._invalidate_homes)
        grid.addWidget(self._cbo_splitters, 2, 1)
        grid.setColumnStretch(1, 1)
        lay.addLayout(grid)

        row = QHBoxLayout()
        self._btn_scan_homes = QPushButton("Find them")
        self._btn_scan_homes.clicked.connect(self._on_scan_homes)
        row.addWidget(self._btn_scan_homes)
        self._btn_hl_homes = QPushButton("Highlight all on the map")
        self._btn_hl_homes.setEnabled(False)
        self._btn_hl_homes.clicked.connect(self._on_highlight_homes)
        row.addWidget(self._btn_hl_homes)
        self._btn_propose = QPushButton("Propose drop cables")
        self._btn_propose.setEnabled(False)
        self._btn_propose.clicked.connect(self._on_propose)
        row.addWidget(self._btn_propose)
        row.addStretch(1)
        lay.addLayout(row)

        self._home_table = self._make_table(_HOME_HEADERS)
        self._home_table.itemSelectionChanged.connect(self._on_home_row)
        lay.addWidget(self._home_table, 1)

        self._home_summary = QLabel("")
        self._home_summary.setWordWrap(True)
        self._home_summary.setTextFormat(Qt.TextFormat.RichText)
        lay.addWidget(self._home_summary)

        foot = QHBoxLayout()
        foot.addStretch(1)
        self._btn_attach = QPushButton("Attach")
        self._btn_attach.setEnabled(False)
        self._btn_attach.clicked.connect(self._on_attach)
        foot.addWidget(self._btn_attach)
        lay.addLayout(foot)
        return page

    @staticmethod
    def _make_table(headers):
        t = QTableWidget(0, len(headers))
        t.setHorizontalHeaderLabels(headers)
        t.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        t.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        t.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        t.setAlternatingRowColors(True)
        t.setSortingEnabled(True)
        head = t.horizontalHeader()
        head.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for c in range(1, len(headers)):
            head.setSectionResizeMode(c, QHeaderView.ResizeMode.ResizeToContents)
        return t

    # ── layer lists ─────────────────────────────────────────────────────────
    def _refresh_layer_lists(self):
        points = cs.point_layers(self._project)
        lines = cs.line_layers(self._project)
        self._fill(self._cbo_poles, points, cs.POLE_HINTS)
        # Homes and splitters must never fall back onto a POLE layer — that is a
        # wrong default that still reads like a considered one.
        self._fill(self._cbo_demand, points, cs.DEMAND_HINTS,
                   avoid=cs.POLE_HINTS)
        self._fill(self._cbo_splitters, points, cs.SPLITTER_HINTS,
                   avoid=cs.POLE_HINTS)
        self._fill(self._cbo_drops, lines, cs.DROP_HINTS, cs.CABLE_EXCLUDE)

        if not points or not lines:
            # Name what is missing. "Nothing found" with no reason sends the
            # planner hunting through the layer tree.
            missing = []
            if not points:
                missing.append("point layers (poles, homes, splitters)")
            if not lines:
                missing.append("line layers (cables)")
            msg = ("<b>Nothing to check.</b> This project has no "
                   + " and no ".join(missing) + ".")
            self._pole_summary.setText(msg)
            self._home_summary.setText(msg)
            self._btn_scan_poles.setEnabled(False)
            self._btn_scan_homes.setEnabled(False)

    @staticmethod
    def _fill(combo, layers, hints, exclude=(), avoid=()):
        combo.blockSignals(True)
        combo.clear()
        for lyr in layers:
            combo.addItem(lyr.name().strip(), lyr.id())
        pick = cs.default_index(layers, hints, exclude, avoid) if layers else 0
        if 0 <= pick < combo.count():
            combo.setCurrentIndex(pick)
        combo.blockSignals(False)

    def _layer(self, combo):
        lid = combo.currentData()
        if not lid:
            return None
        try:
            return self._project.mapLayer(lid)
        except Exception:
            return None

    # ── poles tab ───────────────────────────────────────────────────────────
    def _invalidate_poles(self, *_a):
        self._pole_rows = []
        self._paired = []
        self._pole_table.setRowCount(0)
        self._btn_hl_poles.setEnabled(False)

    def _on_scan_poles(self):
        poles = self._layer(self._cbo_poles)
        if poles is None:
            return
        band = self._cbo_band.currentData()
        failure = None
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            paired, report = cs.cables_for(self._project, poles)
            rows, stats = cs.scan_poles(poles, paired, band=band)
        except Exception as exc:
            failure = exc
        finally:
            QApplication.restoreOverrideCursor()
        if failure is not None:
            QMessageBox.critical(self, "Connectivity Check",
                                 f"The scan could not be run:\n{failure}")
            return

        self._pole_rows = rows
        self._paired = paired
        self._pole_table.setSortingEnabled(False)
        self._pole_table.setRowCount(len(rows))
        names = _unique_labels(rows)
        for r, (fid, _pt, dist, label) in enumerate(rows):
            item = QTableWidgetItem(names.get(fid, str(label)))
            item.setData(Qt.ItemDataRole.UserRole, fid)
            self._pole_table.setItem(r, 0, item)
            self._pole_table.setItem(r, 1, _MetreItem(dist))
        self._pole_table.setSortingEnabled(True)
        self._pole_table.sortItems(1, Qt.SortOrder.DescendingOrder)
        self._btn_hl_poles.setEnabled(bool(rows))

        if not paired:
            self._pole_summary.setText(
                "<span style='color:#b3352e;'><b>No cable layer belongs to these "
                "poles</b> &mdash; "
                + (stats.get("reason") or "nothing to check them against")
                + ".</span>")
            return

        # SHOW THE PAIRING. A pairing the operator cannot see is exactly the one
        # that read another town's cables, so the layers used and how strongly
        # they matched are on screen, not buried in a log.
        used = ", ".join(f"{n} {c:.0%}" for n, c in report
                         if c >= cs.PAIR_MIN_COVERAGE)
        counts = stats.get("counts") or {}
        band_m = stats.get("band_m", 0)
        parts = [f"<b>{len(rows)}</b> of {stats['poles']} poles have no cable "
                 f"within {band_m:g} m",
                 f"measured against: {used}"]
        others = [f"{m:g} m: {counts.get(k, 0)}" for k, m, _l in cs.BANDS]
        parts.append("at the other bands &mdash; " + ", ".join(others))
        if stats.get("skipped_nonfinite"):
            parts.append(f"<span style='color:#b06000;'>"
                         f"{stats['skipped_nonfinite']} skipped for unusable "
                         f"geometry</span>")
        self._pole_summary.setText(" &middot; ".join(parts) + ".")

    def _on_highlight_poles(self):
        self._highlight(self._layer(self._cbo_poles),
                        [r[0] for r in self._pole_rows])

    def _on_pole_row(self):
        self._zoom_to_selected_row(self._pole_table, self._layer(self._cbo_poles))

    # ── homes tab ───────────────────────────────────────────────────────────
    def _invalidate_homes(self, *_a):
        self._unserved = []
        self._proposals = []
        self._pstats = {}
        self._home_table.setRowCount(0)
        self._btn_hl_homes.setEnabled(False)
        self._btn_propose.setEnabled(False)
        self._btn_attach.setEnabled(False)

    def _on_scan_homes(self):
        demand = self._layer(self._cbo_demand)
        drops = self._layer(self._cbo_drops)
        if demand is None or drops is None:
            return
        failure = None
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            rows, stats = cs.scan_unserved(demand, drops)
        except Exception as exc:
            failure = exc
        finally:
            QApplication.restoreOverrideCursor()
        if failure is not None:
            QMessageBox.critical(self, "Connectivity Check",
                                 f"The scan could not be run:\n{failure}")
            return

        self._proposals = []
        self._btn_attach.setEnabled(False)
        self._unserved = rows
        self._home_table.setSortingEnabled(False)
        self._home_table.setRowCount(len(rows))
        names = _unique_labels(rows)
        for r, (fid, _pt, _d, label) in enumerate(rows):
            item = QTableWidgetItem(names.get(fid, str(label)))
            item.setData(Qt.ItemDataRole.UserRole, fid)
            self._home_table.setItem(r, 0, item)
            for c in range(1, len(_HOME_HEADERS)):
                self._home_table.setItem(r, c, QTableWidgetItem("—"))
        self._home_table.setSortingEnabled(True)
        self._btn_hl_homes.setEnabled(bool(rows))
        self._btn_propose.setEnabled(bool(rows))

        if not rows:
            self._home_summary.setText(
                f"<b>Every one of {stats['demand']} homes has a drop.</b> "
                + (stats.get("reason") or ""))
            return
        self._home_summary.setText(
            f"<b>{len(rows)}</b> of {stats['demand']} homes have no drop cable "
            f"ending on them &middot; measured against "
            f"{stats['drop_ends']} drop ends.")

    def _on_propose(self):
        demand = self._layer(self._cbo_demand)
        drops = self._layer(self._cbo_drops)
        splitters = self._layer(self._cbo_splitters)
        if demand is None or drops is None or splitters is None or not self._unserved:
            return
        failure = None
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            props, pstats = da.plan_attachments(demand, self._unserved,
                                                splitters, drops)
        except Exception as exc:
            failure = exc
        finally:
            QApplication.restoreOverrideCursor()
        if failure is not None:
            QMessageBox.critical(self, "Connectivity Check",
                                 f"The proposal could not be built:\n{failure}")
            return

        self._proposals, self._pstats = props, pstats
        if not props:
            self._btn_attach.setEnabled(False)
            self._home_summary.setText(
                "<span style='color:#b3352e;'>Nothing can be attached &mdash; "
                + (pstats.get("reason") or "no reason reported") + ".</span>")
            return

        by_fid = {p["demand_fid"]: p for p in props}
        sp_labels = self._labels_of(splitters)
        bold = QFont()
        bold.setBold(True)
        self._home_table.setSortingEnabled(False)
        self._home_table.setRowCount(len(self._unserved))
        names = _unique_labels(self._unserved)
        for r, (fid, _pt, _d, label) in enumerate(self._unserved):
            item = QTableWidgetItem(names.get(fid, str(label)))
            item.setData(Qt.ItemDataRole.UserRole, fid)
            self._home_table.setItem(r, 0, item)
            p = by_fid.get(fid)
            if p is None:
                # Say WHY this one gets nothing, on its own row. A home that
                # silently vanishes from the plan reads as "handled".
                out = QTableWidgetItem("out of reach")
                out.setForeground(QColor("#b3352e"))
                self._home_table.setItem(r, 1, out)
                self._home_table.setItem(r, 2, QTableWidgetItem("—"))
                self._home_table.setItem(r, 3, QTableWidgetItem("—"))
                continue
            self._home_table.setItem(
                r, 1, QTableWidgetItem(sp_labels.get(p["splitter_fid"],
                                                     f"#{p['splitter_fid']}")))
            metres = _MetreItem(p["length_m"])
            if p["length_m"] >= pstats.get("reach_m", 0) * 0.9:
                metres.setForeground(QColor("#b06000"))
                metres.setFont(bold)
            self._home_table.setItem(r, 2, metres)
            lab = p["attrs"].get("Name") or p["attrs"].get("name") \
                or p["attrs"].get("label") or p["attrs"].get("Label")
            self._home_table.setItem(
                r, 3, QTableWidgetItem(str(lab) if lab else "—"))
        self._home_table.setSortingEnabled(True)

        total_m = sum(p["length_m"] for p in props)
        parts = [f"<b>{pstats['proposed']}</b> drop cables proposed",
                 f"{total_m:,.0f} m of drop cable",
                 f"{pstats['splitters_touched']} splitters used",
                 f"reach {pstats.get('reach_m', 0):.0f} m "
                 f"(the layer&rsquo;s own p95)"]
        if pstats.get("no_splitter"):
            parts.append(f"<span style='color:#b3352e;'>{pstats['no_splitter']} "
                         "homes have no splitter with room in reach</span>")
        if pstats.get("unlabelled"):
            parts.append(f"<span style='color:#b06000;'>{pstats['unlabelled']} "
                         "could not be labelled from the layer&rsquo;s pattern"
                         "</span>")
        self._home_summary.setText(" &middot; ".join(parts) + ".")
        self._btn_attach.setEnabled(True)

    def _on_highlight_homes(self):
        self._highlight(self._layer(self._cbo_demand),
                        [r[0] for r in self._unserved])

    def _on_home_row(self):
        self._zoom_to_selected_row(self._home_table, self._layer(self._cbo_demand))

    # ── attach ──────────────────────────────────────────────────────────────
    def _take_backup(self, layer):
        """Snapshot the layer about to be written. ``(path, reason)``.

        Mirrors the Merge and Reshape tools, including returning the REASON — a
        deep project path once blew the Windows limit and the message named
        nothing.
        """
        try:
            parent = self.parent()
            writer = getattr(parent, "_pon_write_renumber_backup", None)
            if writer is None:
                return "", ("the Network Planner panel that owns the backup "
                            "writer is not available")
            ok, dest = writer([layer])
            return (dest, "") if ok else ("", str(dest))
        except Exception as exc:
            return "", f"{type(exc).__name__}: {exc}"

    def _on_attach(self):
        drops = self._layer(self._cbo_drops)
        splitters = self._layer(self._cbo_splitters)
        if drops is None or not self._proposals:
            return
        name = drops.name().strip()
        n = len(self._proposals)
        total_m = sum(p["length_m"] for p in self._proposals)

        # STATE THE BoQ IMPACT BEFORE THE PRESS, not after. Every one of these is
        # a real drop on a real bill; a planner who did not mean to change the
        # quantities must be able to stop here.
        if QMessageBox.question(
                self, "Connectivity Check",
                f"Attach <b>{n}</b> drop cables to <b>{name}</b>?<br><br>"
                f"<b>This changes the BoQ:</b> +{n} drop cables, "
                f"about {total_m:,.0f} m of drop cable.<br><br>"
                "A backup is taken and read back first.",
                QMessageBox.StandardButton.Yes
                | QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
            return

        # REFUSE WHILE THE LAYER IS BEING EDITED. addFeatures goes straight to the
        # provider, under the edit buffer, and the reload that follows would throw
        # away an operator's unsaved edits. Check before the write, never after.
        for lyr in (drops, splitters):
            if lyr is not None and lyr.isEditable():
                QMessageBox.warning(
                    self, "Connectivity Check",
                    f"<b>{lyr.name().strip()}</b> is open for editing, so nothing "
                    "was attached.<br><br>Save or discard your edits on that "
                    "layer first — attaching writes straight to the file, and "
                    "any unsaved edit would be lost.")
                return

        backup, why = self._take_backup(drops)
        if not backup:
            QMessageBox.critical(
                self, "Connectivity Check",
                "Nothing was attached — the backup could not be written, so the "
                f"attach was refused.\n\nReason: {why}")
            return
        ok_backup, backup_why = pon_merge.backup_is_usable(backup)
        if not ok_backup:
            QMessageBox.critical(
                self, "Connectivity Check",
                f"Nothing was attached — {backup_why}\n\n"
                "A backup that cannot be re-opened is not a backup.")
            return

        # ONE restore per set, and the modal raised AFTER it. Restoring inside
        # the except AND in the finally pops the cursor stack twice for a single
        # push, which steals whatever override another component had pushed; and
        # a message box shown before the finally runs sits there under a spinning
        # wait cursor.
        failure = None
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            ok, msg, astats = da.apply_attachments(drops, splitters,
                                                   self._proposals, backup)
        except Exception as exc:
            failure = exc
        finally:
            QApplication.restoreOverrideCursor()
        if failure is not None:
            QMessageBox.critical(
                self, "Connectivity Check",
                f"The attach failed and stopped:\n{failure}\n\nBackup: {backup}")
            return

        if not ok:
            QMessageBox.critical(self, "Connectivity Check",
                                 f"{msg}\n\nBackup: {backup}")
            return

        try:
            drops.triggerRepaint()
            if splitters is not None:
                splitters.triggerRepaint()
        except Exception:
            pass

        # PROVE IT. Re-scan off the layer rather than trusting the return code,
        # and report the number that came back from the re-read.
        written = astats.get("written", 0)
        verified = astats.get("verified", 0)
        # If the writer deduplicated anything, SAY so — otherwise the metres
        # quoted in the confirmation (summed from the proposals) would silently
        # disagree with the number of cables actually written.
        skipped = astats.get("duplicates_skipped", 0)
        dupe_line = (f"{skipped} duplicate proposal(s) for a home that already "
                     "had one were skipped.\n") if skipped else ""
        demand = self._layer(self._cbo_demand)
        left = "?"
        try:
            _rows, st = cs.scan_unserved(demand, drops)
            left = st["unserved"]
        except Exception:
            pass
        self._invalidate_homes()
        QMessageBox.information(
            self, "Connectivity Check",
            f"Attached {written} drop cables to {name}.\n\n"
            f"{verified} of {written} confirmed connected on re-read.\n"
            f"Homes still without a drop: {left}.\n\n"
            f"{dupe_line}"
            f"BoQ: +{written} drop cables, about {total_m:,.0f} m.\n"
            f"Backup: {backup}")
        self._on_scan_homes()

    # ── map ─────────────────────────────────────────────────────────────────
    @staticmethod
    def _labels_of(layer):
        out = {}
        if layer is None:
            return out
        try:
            for f in layer.getFeatures():
                out[f.id()] = cs._label_of(f, layer)
        except Exception:
            pass
        return out

    def _highlight(self, layer, fids):
        """Select every offender and zoom to them — Luke's actual request."""
        if layer is None or not fids:
            return
        try:
            layer.removeSelection()
            layer.selectByIds(list(fids))
            if self._iface is not None:
                self._iface.mapCanvas().zoomToSelected(layer)
                self._iface.mapCanvas().refresh()
        except Exception as exc:
            QMessageBox.warning(self, "Connectivity Check",
                                f"Could not highlight them on the map:\n{exc}")

    def _zoom_to_selected_row(self, table, layer):
        if layer is None:
            return
        items = table.selectedItems()
        if not items:
            return
        fid = table.item(items[0].row(), 0).data(Qt.ItemDataRole.UserRole)
        if fid is None:
            return
        try:
            layer.removeSelection()
            layer.selectByIds([int(fid)])
            if self._iface is not None:
                self._iface.mapCanvas().zoomToSelected(layer)
                self._iface.mapCanvas().refresh()
        except Exception:
            pass


def open_connectivity_check(project, parent=None, iface=None):
    """Open the check. Modeless so the planner can pan the map while it is up."""
    dlg = ConnectivityDialog(project, parent=parent, iface=iface)
    dlg.show()
    return dlg
