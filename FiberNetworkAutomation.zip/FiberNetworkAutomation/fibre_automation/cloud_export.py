"""cloud_export — GeoParquet + OFDS (Open Fibre Data Standard) exporters.

Cloud-native, standards-compliant deliverables. GeoParquet via GDAL's native
Parquet driver (NO pip — works on plain QGIS 3.28+/4.0 with GDAL 3.5+). OFDS is
plain JSON (stdlib). Both verified on QGIS 3.40 / GDAL 3.12.
"""
import json
import os


def parquet_supported():
    try:
        from osgeo import ogr
        return ogr.GetDriverByName('Parquet') is not None
    except Exception:
        return False


# ── GeoParquet ───────────────────────────────────────────────────────────────
def export_layer_to_geoparquet(layer, out_path, compression='ZSTD'):
    """Write a vector layer to GeoParquet. Returns (ok: bool, message: str)."""
    from qgis.core import QgsVectorFileWriter, QgsCoordinateTransformContext
    if not parquet_supported():
        return False, "GDAL Parquet driver not available (needs GDAL 3.5+)."
    try:
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = 'Parquet'
        opts.layerOptions = [f'COMPRESSION={compression}',
                             'GEOMETRY_ENCODING=GEOARROW']
        res = QgsVectorFileWriter.writeAsVectorFormatV3(
            layer, out_path, QgsCoordinateTransformContext(), opts)
        if int(res[0]) != 0:                      # 0 == NoError (version-safe)
            return False, f"write failed: {res[1] if len(res) > 1 else res[0]}"
        return True, out_path
    except Exception as e:
        return False, str(e)


def export_project_to_geoparquet(out_dir, layers=None):
    """Export each vector layer to <out_dir>/<name>.parquet. Returns a summary list."""
    from qgis.core import QgsProject, QgsMapLayer
    os.makedirs(out_dir, exist_ok=True)
    if layers is None:
        layers = [lyr for lyr in QgsProject.instance().mapLayers().values()
                  if lyr.type() == QgsMapLayer.LayerType.VectorLayer
                  and lyr.featureCount() > 0]
    out = []
    for lyr in layers:
        safe = "".join(c if (c.isalnum() or c in " _-") else "_" for c in lyr.name())
        p = os.path.join(out_dir, safe + ".parquet")
        ok, msg = export_layer_to_geoparquet(lyr, p)
        out.append({"layer": lyr.name(), "ok": ok,
                    "path": p if ok else None, "msg": msg})
    return out


# ── OFDS (Open Fibre Data Standard, v0.3 subset) ─────────────────────────────
def _pt(geom):
    p = geom.asPoint() if not geom.isMultipart() else geom.asMultiPoint()[0]
    return [round(p.x(), 7), round(p.y(), 7)]


def _line(geom):
    pts = geom.asPolyline() if not geom.isMultipart() else geom.asMultiPolyline()[0]
    return [[round(p.x(), 7), round(p.y(), 7)] for p in pts]


def export_ofds(out_path, network_name="Velocity Nexus FTTH"):
    """Minimal OFDS export: point assets→nodes, cable lines→spans. (ok, msg)."""
    from qgis.core import QgsProject, QgsMapLayer, QgsWkbTypes
    nodes, spans = [], []
    NODE_HINTS = ('pole', 'splitter', 'enclosure', 'ont', 'fts', 'sts', 'pop',
                  'home connection')
    SPAN_HINTS = ('cable', 'feeder', 'drop', 'distribution', 'secondary',
                  'primary')

    def _label(feat, fallback):
        names = [fld.name() for fld in feat.fields()]
        for cand in ('label', 'label_1', 'name'):
            if cand in names and feat[cand]:
                return str(feat[cand])
        return fallback

    for lyr in QgsProject.instance().mapLayers().values():
        if lyr.type() != QgsMapLayer.LayerType.VectorLayer:
            continue
        nm = lyr.name().lower()
        try:
            gt = lyr.geometryType()
            if (gt == QgsWkbTypes.GeometryType.PointGeometry
                    and any(h in nm for h in NODE_HINTS)):
                for f in lyr.getFeatures():
                    g = f.geometry()
                    if not g or g.isEmpty():
                        continue
                    nodes.append({
                        "id": f"{lyr.name()}:{f.id()}",
                        "name": _label(f, f"{lyr.name()}-{f.id()}"),
                        "location": {"type": "Point", "coordinates": _pt(g)},
                        "assetType": lyr.name(),
                    })
            elif (gt == QgsWkbTypes.GeometryType.LineGeometry
                  and any(h in nm for h in SPAN_HINTS)):
                for f in lyr.getFeatures():
                    g = f.geometry()
                    if not g or g.isEmpty():
                        continue
                    spans.append({
                        "id": f"{lyr.name()}:{f.id()}",
                        "name": _label(f, f"{lyr.name()}-{f.id()}"),
                        "route": {"type": "LineString", "coordinates": _line(g)},
                        "fibreType": "single-mode",
                        "assetType": lyr.name(),
                    })
        except Exception:
            continue

    doc = {
        "id": "velocity-nexus-network",
        "name": network_name,
        "nodes": nodes,
        "spans": spans,
        "phases": [],
        "_meta": {"generator": "Velocity Nexus", "spec": "OFDS-0.3-subset",
                  "nodeCount": len(nodes), "spanCount": len(spans)},
    }
    try:
        with open(out_path, 'w', encoding='utf-8') as fh:
            json.dump(doc, fh, indent=2)
        return True, f"{len(nodes)} nodes, {len(spans)} spans → {out_path}"
    except Exception as e:
        return False, str(e)
