# -*- coding: utf-8 -*-
"""Shared dock opener — every plugin panel opens FULLY docked, not half-floating.

Several tools historically popped as a fixed-size floating window (a QTimer
"win the dock-restore race" trick that called setFloating(True) + resize), which
opened half-way and needed a manual re-snap.  dock_fully() keeps the deferred
settle (so the panel reliably appears) but settles to a proper DOCKED state:
full side height, a sensible width, raised + focused.

Qt6/Qt5-safe: Qt via the qgis.PyQt shim, fully-scoped enums, no QGIS work at
import time (everything is inside the function).
"""

__all__ = ["dock_fully"]


def dock_fully(iface, dock, area=None, width=440, prefer_float=False):
    """Open a QDockWidget FULLY and correctly — docked on a side at full height
    with a sensible width, raised + focused; never a half floating window that
    needs a manual re-snap.

    iface        : QgisInterface (its mainWindow hosts the dock).
    dock         : the QDockWidget to open.
    area         : Qt.DockWidgetArea; defaults to the right edge.
    width        : docked width hint (metres of pixels); full height is automatic
                   for a side dock.
    prefer_float : True keeps the old floating-window behaviour for the rare
                   panel that genuinely wants to float.

    The settle is deferred one event-loop tick to win QGIS's dock-restore race
    (QGIS may otherwise restore the dock collapsed/hidden on add).  Returns the
    dock so callers can keep chaining.
    """
    from qgis.PyQt.QtCore import Qt, QTimer
    if area is None:
        area = Qt.DockWidgetArea.RightDockWidgetArea
    try:
        iface.addDockWidget(area, dock)
    except Exception:
        return dock

    def _settle(d=dock, area=area, width=width, prefer_float=prefer_float):
        # the dock may have been CLOSED/destroyed before this deferred tick
        # (WA_DeleteOnClose editors) — touching a freed C++ dock is a hard
        # crash (access violation), so bail if it's gone or already hidden.
        try:
            from qgis.PyQt import sip
            if sip.isdeleted(d):
                return
        except Exception:
            pass
        try:
            if not d.isVisible():
                return
        except Exception:
            return
        try:
            d.setFloating(bool(prefer_float))
            if not prefer_float:
                # side docks size by WIDTH (full height is automatic); top/bottom
                # docks size by HEIGHT — pick the orientation that matters.
                horiz = area not in (Qt.DockWidgetArea.TopDockWidgetArea,
                                     Qt.DockWidgetArea.BottomDockWidgetArea)
                orient = (Qt.Orientation.Horizontal if horiz
                          else Qt.Orientation.Vertical)
                try:
                    mw = iface.mainWindow()
                    if mw is not None:
                        mw.resizeDocks([d], [max(int(width), 360)], orient)
                except Exception:
                    pass
            d.show()
            d.raise_()
            d.activateWindow()
        except Exception:
            pass

    QTimer.singleShot(0, _settle)
    return dock
