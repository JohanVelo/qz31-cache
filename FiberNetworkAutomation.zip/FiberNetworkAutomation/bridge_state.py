"""bridge_state — what the bridge indicator should say, as a pure function.

No Qt, no sockets, no I/O: callers gather the facts, this decides the state.
That keeps the four states unit-testable, and keeps the decision in one place
instead of spread across a timer callback.

Why the indicator needed this at all
------------------------------------
The home panel used to be told ``set_bridge(True, port)`` exactly once, at
startup, with a hardcoded ``True`` and a port read from ``C:/Temp/bridge_port.txt``
-- a file shared by every QGIS process on the machine. So it claimed "online"
without ever checking, never updated, and with two QGIS open it showed whichever
port was written last. Every one of those is a way to be confidently wrong.

Two different questions, deliberately kept apart
------------------------------------------------
* **Which bridge is THIS window running?** Answered in-process from the bridge
  plugin's own server object. It is the only instance-specific truth available;
  a shared file cannot distinguish two processes.
* **Which bridge is Claude pointed at?** That is ``bridge_port.txt``, a machine-
  wide pointer. It may legitimately name a *different* window.

Conflating them is what made the old indicator lie, so ``describe()`` reports
both and the UI shows both whenever they differ.

Never probe this QGIS's own ``/status`` over HTTP to find out
-------------------------------------------------------------
The bridge answers ``/status`` by queueing work onto the Qt main thread. A
synchronous request issued *from* that same thread waits for a reply that cannot
be produced until the thread is free -- a deadlock until timeout. The in-process
check below has no such hazard.
"""

# Ports the bridge may bind. ONE definition: the scan and the switcher must
# agree, or a port offered by the switcher can sit outside the scanned range and
# read as permanently offline.
PORT_MIN = 8765
PORT_MAX = 8775
PORT_RANGE = range(PORT_MIN, PORT_MAX + 1)

# States
CONNECTING = "connecting"      # nothing polled yet -- never assume good news
CONNECTED = "connected"        # this window's bridge is bound and serving
DEGRADED = "degraded"          # the bridge is there but not actually serving
OFFLINE = "offline"            # no bridge in this window

#: consecutive bad polls before a healthy indicator is allowed to go red, so a
#: single slow scan does not flicker the UI.
FAIL_STREAK_TO_RED = 2


def classify(polled, plugin_loaded, server_port, server_alive, listening_ports):
    """Return one of the four states for THIS QGIS instance.

    polled          -- has at least one poll completed? False on the very first
                       paint, which must render as CONNECTING, never as green.
    plugin_loaded   -- is the bridge plugin loaded in this QGIS?
    server_port     -- the port its server object says it bound, or None
    server_alive    -- is its serving thread actually running? (None = unknown)
    listening_ports -- ports found accepting connections on this machine
    """
    if not polled:
        return CONNECTING
    if not plugin_loaded or server_port is None:
        return OFFLINE
    if server_alive is False:
        # Plugin present, server object present, serving thread dead. Distinct
        # from OFFLINE: there IS a bridge here, it just is not answering.
        return DEGRADED
    if listening_ports is not None and server_port not in listening_ports:
        # It believes it owns a port that nothing is listening on.
        return DEGRADED
    return CONNECTED


def apply_debounce(state, previous_state, fail_streak):
    """Hold a previously-CONNECTED indicator for one bad poll before going red.

    Only ever downgrades *later*, never upgrades early: a state that is not
    CONNECTED can never be shown as CONNECTED by this function. Degradation is
    delayed; good news is never invented.
    """
    if state == CONNECTED or previous_state != CONNECTED:
        return state
    if state == CONNECTING:
        return state
    if fail_streak < FAIL_STREAK_TO_RED:
        return CONNECTED
    return state


def describe(state, own_port, claude_port=None):
    """(text, tooltip_line) for the indicator.

    When Claude is pointed at a different window's bridge, say so on the face of
    the label -- that mismatch is the single most confusing thing about running
    two QGIS at once, and it used to be invisible.
    """
    if state == CONNECTING:
        return "Bridge: checking…", "Waiting for the first bridge poll."
    if state == OFFLINE:
        return "Bridge offline", ("No bridge is running in this QGIS window "
                                  "(the plugin is not loaded, or it never bound "
                                  "a port).")
    if state == DEGRADED:
        return (f"Bridge not responding · {own_port}",
                (f"The bridge plugin is loaded and claims port {own_port}, but "
                 f"nothing is serving there. Try restarting it from the bridge "
                 f"dock."))
    text = f"Bridge online · {own_port}"
    tip = f"This window's bridge is serving on port {own_port}."
    if claude_port is not None and own_port is not None \
            and int(claude_port) != int(own_port):
        text += f"  ·  Claude → {claude_port}"
        tip += (f" Claude is currently pointed at port {claude_port}, which is a "
                f"different QGIS window.")
    return text, tip


def is_healthy(state):
    return state == CONNECTED


# ── telling a bridge from anything else answering on the same range ─────────

#: Keys a genuine bridge /status payload always carries.
_BRIDGE_STATUS_KEYS = ("status", "project_name")


def is_bridge_status(payload):
    """True only if `payload` is a QGIS bridge's /status response.

    "Something accepted a TCP connection on 8765-8775" does NOT mean "a bridge
    lives there". The canvas mirror listens on 8767 and answers /status quite
    happily with ``{"ok": true, "port": 8767, "bridge": "...:8765"}`` -- offering
    that as a bridge to switch to would point Claude at a server that cannot run
    PyQGIS. A real bridge replies with a `status` and a `project_name`.

    Anything that is not a dict with those keys is rejected: an unknown server
    must never be presented as a usable bridge.
    """
    if not isinstance(payload, dict):
        return False
    return all(k in payload for k in _BRIDGE_STATUS_KEYS)


def describe_candidate(port, payload, is_self=False):
    """One line for the port picker: what is actually behind this port."""
    tag = "  (this window)" if is_self else ""
    if payload is None:
        return f"{port} — checking…{tag}"
    if not is_bridge_status(payload):
        return f"{port} — not a QGIS bridge (something else is listening)"
    name = payload.get("project_name") or "no project open"
    return f"{port} — {name}{tag}"
