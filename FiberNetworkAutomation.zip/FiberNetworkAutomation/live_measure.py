# -*- coding: utf-8 -*-
"""Velocity live tools - Live Measure, Group counter, Drop counter, Drop lengths, PON groups.

Read-only tools. Nothing here writes to a layer, style, label, renderer, project
setting or file. Options are stored under QgsSettings 'VelocityFibre/live_measure/';
on/off is never saved (every tool starts off).

Entry points: install(iface, toolbar_parent=None) and uninstall().
Kill switch: QgsSettings 'VelocityFibre/live_measure/disabled' = true, or env
VF_NO_LIVE_MEASURE=1 -> install() returns None and the Span Inspector shows no live section.
"""

import functools
import math
import os
import time
import traceback

from qgis.core import (
    Qgis,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeatureRequest,
    QgsGeometry,
    QgsMessageLog,
    QgsPoint,
    QgsPointXY,
    QgsRectangle,
    QgsProject,
    QgsSettings,
    QgsVectorLayer,
)
from qgis.gui import QgsMapCanvasItem, QgsMapTool, QgsMapToolAdvancedDigitizing, QgsMapToolCapture
from qgis.PyQt import sip
from qgis.PyQt.QtCore import QEvent, QObject, QPoint, QPointF, QRectF, Qt, QTimer, pyqtSignal
from qgis.PyQt.QtGui import QAction, QColor, QFont, QFontMetricsF, QImage, QPainter, QPen, QPolygonF
from qgis.PyQt.QtWidgets import QApplication, QLabel

try:  # plugin package or plain module (tests)
    from . import live_measure_core as core
except ImportError:  # pragma: no cover
    import live_measure_core as core

SETTINGS_PREFIX = "VelocityFibre/live_measure/"
TOOLBAR_NAME = "VelocityMeasureToolbar"
LOG_TAG = "Velocity Measure"

# readout chip palette: light verdict colours on a dark console chip (>= 4.5:1 on the chip)
COLOURS = {
    core.GREEN: "#4ADE80",
    core.AMBER: "#FBBF24",
    core.AMBER_LOW: "#FBBF24",
    core.RED: "#FF6B6B",
    core.NEUTRAL: "#EAF3FF",
}
CHIP_TEXT = "#EAF3FF"
CHIP_MUTED = "#C8D3E2"

# ── test seams ───────────────────────────────────────────────────────────
_INJECT = set()          # handler names that raise on entry (AC10 fault injection)
_CAP_OVERRIDE = None     # None = detect; True/False = force the QGIS 4 capability switch


def has_transient():
    """T1/T4 need QgsMapToolCapture.transientGeometryChanged (QGIS >= 4.0)."""
    if _CAP_OVERRIDE is not None:
        return bool(_CAP_OVERRIDE)
    return hasattr(QgsMapToolCapture, "transientGeometryChanged")


def kill_switch_on():
    if os.environ.get("VF_NO_LIVE_MEASURE", "").strip() == "1":
        return True
    v = QgsSettings().value(SETTINGS_PREFIX + "disabled", False)
    return str(v).strip().lower() in ("1", "true", "yes")


_SETTINGS_CACHE = {}   # options are read on every mouse move; QgsSettings() costs ~1 ms each


def _setting(key, default):
    if key not in _SETTINGS_CACHE:
        _SETTINGS_CACHE[key] = QgsSettings().value(SETTINGS_PREFIX + key, default)
    v = _SETTINGS_CACHE[key]
    return default if v is None else v


def _set_setting(key, value):
    QgsSettings().setValue(SETTINGS_PREFIX + key, value)
    _SETTINGS_CACHE[key] = value


def _float(v, default):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _log_quiet(text):
    """Log from a Qt callback's except-branch; even a failing logger must not raise into Qt."""
    try:
        QgsMessageLog.logMessage(text, LOG_TAG, Qgis.MessageLevel.Warning)
    except Exception:  # noqa: BLE001
        pass


def _best_effort(*fns):
    """Run each callable; log any exception and carry on with the next (teardown paths)."""
    for fn in fns:
        try:
            fn()
        except Exception:  # noqa: BLE001
            QgsMessageLog.logMessage(traceback.format_exc(), LOG_TAG, Qgis.MessageLevel.Critical)


def host_safe(fn):
    """Menu / toolbar slots on the host: log + one message bar line, never raise into Qt."""
    @functools.wraps(fn)
    def wrapper(self, *args):
        try:
            if "host." + fn.__name__ in _INJECT:
                raise RuntimeError("injected fault: host." + fn.__name__)
            return fn(self, *args)
        except Exception:  # noqa: BLE001
            QgsMessageLog.logMessage(traceback.format_exc(), LOG_TAG, Qgis.MessageLevel.Warning)
            self.message("That action failed. Details are in the Log Messages panel.")
            return None
    return wrapper


def guarded(name, default=None):
    """HR3: every Qt-called handler goes through this. The first exception marks
    the tool broken, logs it, shows ONE message bar and switches the tool off on
    the next event-loop turn; the handler returns `default` so events pass on."""
    def deco(fn):
        @functools.wraps(fn)
        def wrapper(self, *args):
            where = name.replace("{key}", self.key)
            if self.broken:
                return default
            try:
                if where in _INJECT:
                    raise RuntimeError("injected fault: " + where)
                return fn(self, *args)
            except Exception:  # noqa: BLE001 - HR3: never let a handler throw into Qt
                self._fault(where)
                return default
        return wrapper
    return deco


# ── shared base ──────────────────────────────────────────────────────────
class _Tool(QObject):
    title = "tool"
    key = "tool"

    def __init__(self, host):
        super().__init__()
        self.host = host
        self.canvas = host.canvas
        self.active = False
        self.broken = False
        self.action = None
        self._conns = []
        self.stats = {"connects": 0, "disconnects": 0, "faults": 0, "messages": 0,
                      "calls_while_off": 0}

    # connections ------------------------------------------------------
    def _connect(self, owner, signal_name, slot):
        getattr(owner, signal_name).connect(slot)
        self._conns.append((owner, signal_name, slot))
        self.stats["connects"] += 1

    def _disconnect_owner(self, owner):
        keep = []
        for o, s, slot in self._conns:
            if o is owner:
                self._disconnect_one(o, s, slot)
            else:
                keep.append((o, s, slot))
        self._conns = keep

    def _disconnect_one(self, owner, signal_name, slot):
        try:
            if not sip.isdeleted(owner):
                getattr(owner, signal_name).disconnect(slot)
        except (TypeError, RuntimeError):
            pass
        self.stats["disconnects"] += 1

    def _disconnect_all(self):
        conns, self._conns = self._conns, []
        for o, s, slot in conns:
            self._disconnect_one(o, s, slot)

    # faults -----------------------------------------------------------
    def _fault(self, where):
        self.stats["faults"] += 1
        if self.broken:
            return
        self.broken = True
        try:
            QgsMessageLog.logMessage("%s fault in %s:\n%s" % (self.title, where, traceback.format_exc()),
                                     LOG_TAG, Qgis.MessageLevel.Critical)
            self.stats["messages"] += 1
            self.host.message("%s stopped after an error (%s). Details are in the Log Messages panel."
                              % (self.title, where))
        finally:
            QTimer.singleShot(0, self._off_after_fault)

    def _off_after_fault(self):
        # a QTimer.singleShot callback: nothing may escape into Qt
        _best_effort(self.switch_off, self._uncheck)

    def _uncheck(self):
        if self.action is not None and not sip.isdeleted(self.action):
            self.action.blockSignals(True)
            try:
                self.action.setChecked(False)
            finally:
                self.action.blockSignals(False)
        notify = getattr(self.host, "notify", None)
        if notify is not None:
            notify(self)   # the panel switch follows the automatic off path too

    # on/off -----------------------------------------------------------
    def switch_on(self):
        if self.active:
            return
        self.broken = False
        self.active = True
        try:
            self._on()
        except Exception:  # noqa: BLE001
            self._fault("switch_on")

    def switch_off(self):
        if not self.active:
            return
        self.active = False
        # every resource is released on its own, so one failure cannot strand the others
        _best_effort(self._off, self._disconnect_all)

    def _on(self):
        raise NotImplementedError

    def _off(self):
        raise NotImplementedError


class _ReadoutLabel(QLabel):
    """The on-map readout: a dark console chip; an optional thin bar along the bottom shows
    the value against its limit (tick at 95 percent of the limit)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.bar = None   # (fraction 0..1, colour, tick fraction or None)

    def paintEvent(self, event):  # noqa: N802 - Qt name
        super().paintEvent(event)
        try:
            if not self.bar:
                return
            frac, colour, tick = self.bar
            p = QPainter(self)
            try:
                p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
                x0, w = 9.0, max(10.0, self.width() - 18.0)
                y = self.height() - 7.0
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QColor("#22314A"))
                p.drawRoundedRect(QRectF(x0, y, w, 3.0), 1.5, 1.5)
                p.setBrush(QColor(colour))
                p.drawRoundedRect(QRectF(x0, y, w * max(0.0, min(1.0, frac)), 3.0), 1.5, 1.5)
                if tick is not None:
                    p.setBrush(QColor(CHIP_TEXT))
                    p.drawRect(QRectF(x0 + w * tick - 0.75, y - 2.0, 1.5, 7.0))
            finally:
                p.end()
        except Exception:  # noqa: BLE001 - never raise into Qt from paint
            _log_quiet(traceback.format_exc())


def _make_label(parent):
    lab = _ReadoutLabel(parent)
    lab.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
    lab.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
    lab.setTextFormat(Qt.TextFormat.RichText)
    lab.hide()
    return lab


def _style_label(lab, colour_key):
    edge = COLOURS.get(colour_key, COLOURS[core.NEUTRAL])
    # explicit foreground AND background: readable in light and dark themes and over imagery
    lab.setStyleSheet(
        "QLabel { background-color: rgba(7,11,18,236); color: %s;"
        " border: 1px solid #20304A; border-left: 4px solid %s; border-radius: 6px;"
        " padding: 5px 9px 11px 9px; font-family: 'Consolas','JetBrains Mono',monospace;"
        " font-size: 12px; font-weight: 600; }" % (CHIP_TEXT, edge))


class _MeasureLineItem(QgsMapCanvasItem):
    """The line being measured, drawn clearly over any imagery: dark halo, verdict-coloured
    line, a dot on every clicked vertex and a ring on the moving end. Points are copies in the
    canvas CRS; drawing happens in view pixels, so rotation and pans need nothing extra."""

    def __init__(self, canvas):
        super().__init__(canvas)
        self._canvas = canvas
        self.pts, self.closed, self.colour = [], False, QColor(CHIP_TEXT)
        self._r = QRectF()
        self.setZValue(1000)   # under drop numbers (1010) and PON tiles (1005), over drop lengths

    def updatePosition(self):
        try:
            self.setPos(0, 0)
        except Exception:  # noqa: BLE001 - never raise into Qt
            pass

    def set_line(self, pts, closed, colour):
        vp = self._canvas.viewport()
        r = QRectF(0, 0, vp.width(), vp.height()) if pts else QRectF()
        if r != self._r:
            self.prepareGeometryChange()
            self._r = r
        self.pts, self.closed, self.colour = list(pts), bool(closed), QColor(colour)
        self.update()

    def boundingRect(self):
        try:
            return QRectF(self._r)
        except Exception:  # noqa: BLE001 - never raise into Qt
            return QRectF()

    def paint(self, painter, option=None, widget=None):
        try:
            if len(self.pts) < 2:
                return
            ct = self._canvas.getCoordinateTransform()
            poly = QPolygonF([QPointF(ct.transform(p).x(), ct.transform(p).y()) for p in self.pts])
            if self.closed:
                poly.append(poly[0])
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            # white outer + dark inner casing: unlike any drop line (those have a dark casing only)
            painter.setPen(QPen(QColor(255, 255, 255, 235), 8.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap,
                                Qt.PenJoinStyle.RoundJoin))
            painter.drawPolyline(poly)
            painter.setPen(QPen(QColor(7, 11, 18, 220), 5.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap,
                                Qt.PenJoinStyle.RoundJoin))
            painter.drawPolyline(poly)
            painter.setPen(QPen(self.colour, 3.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap,
                                Qt.PenJoinStyle.RoundJoin))
            painter.drawPolyline(poly)
            n_fixed = len(self.pts) - 1
            painter.setPen(QPen(QColor(7, 11, 18), 1.5))
            painter.setBrush(self.colour)
            for i in range(n_fixed):
                painter.drawEllipse(poly[i], 4.0, 4.0)
            end = poly[len(self.pts) - 1]
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.setPen(QPen(QColor(7, 11, 18, 200), 4.5))
            painter.drawEllipse(end, 6.5, 6.5)
            painter.setPen(QPen(self.colour, 2.0))
            painter.drawEllipse(end, 6.5, 6.5)
        except Exception:  # noqa: BLE001 - never raise into Qt from paint
            _log_quiet(traceback.format_exc())


class _CaptureWatcher(_Tool):
    """Common part of T1 and T4: follow canvas.mapToolSet, hook the capture tool's
    transientGeometryChanged, copy the geometry INSIDE the slot, track the cursor."""

    LABEL_OFFSET = QPoint(18, 18)

    def __init__(self, host):
        super().__init__(host)
        self.label = None
        self.line_item = None
        self._tool = None
        self._cursor = None
        self._anchor = None   # (point, crs) QGIS will place; used when no cursor position is known
        self._das = {}
        self.last = None   # last computed readout (tests)

    def _on(self):
        vp = self.canvas.viewport()
        if self.label is None or sip.isdeleted(self.label):
            self.label = _make_label(vp)
            self.label.setObjectName("vm_label_" + self.key)
        vp.installEventFilter(self)
        self._filter_on = True
        self._connect(self.canvas, "mapToolSet", self._on_tool_set)
        self._attach(self.canvas.mapTool())

    def _off(self):
        def unfilter():
            vp = self.canvas.viewport()
            if getattr(self, "_filter_on", False) and not sip.isdeleted(vp):
                vp.removeEventFilter(self)
            self._filter_on = False

        def hide():
            self._tool = None
            if self.label is not None and not sip.isdeleted(self.label):
                self.label.hide()

        def drop_line():
            item, self.line_item = self.line_item, None
            if item is not None:
                sc = item.scene()
                if sc is not None:
                    sc.removeItem(item)
        _best_effort(unfilter, hide, drop_line)

    def destroy(self):
        self.switch_off()
        if self.label is not None and not sip.isdeleted(self.label):
            self.label.deleteLater()
        self.label = None

    def _attach(self, tool):
        if self._tool is not None:
            self._disconnect_owner(self._tool)
            self._tool = None
        self._hide()
        if tool is not None and not sip.isdeleted(tool) and isinstance(tool, QgsMapToolCapture):
            self._tool = tool
            self._connect(tool, "transientGeometryChanged", self._on_transient_slot)

    def _hide(self):
        self._avoid = None
        if self.label is not None and not sip.isdeleted(self.label):
            self.label.hide()
        if self.line_item is not None:
            self.line_item.set_line([], False, CHIP_TEXT)

    def _show_line(self, pts, crs, closed, colour):
        """Draw the measured shape (copies of the points, in the canvas CRS)."""
        if closed and len(pts) > 2 and pts[0] == pts[-1]:
            pts = pts[:-1]   # the ring repeats its first vertex; the item closes it itself
        dest = self.canvas.mapSettings().destinationCrs()
        if crs.isValid() and crs != dest:
            xf = QgsCoordinateTransform(crs, dest, QgsProject.instance())
            pts = [xf.transform(p) for p in pts]
        if self.line_item is None:
            self.line_item = _MeasureLineItem(self.canvas)
        self.line_item.set_line([QgsPointXY(p) for p in pts], closed, colour)

    def _da(self, crs):
        key = crs.authid() or crs.toWkt()
        da = self._das.get(key)
        if da is None:
            da = core.make_distance_area(crs)
            self._das[key] = da
        return da

    def _place(self):
        lab = self.label
        if lab is None or sip.isdeleted(lab):
            return
        cur = self._cursor if self._cursor is not None else self._anchor_px()
        if cur is None:
            return
        lab.adjustSize()
        vp = self.canvas.viewport()
        p = cur + self.LABEL_OFFSET + getattr(self, "STACK", QPoint(0, 0))
        avoid = getattr(self, "_avoid", None)
        obstacles = self.host.obstacle_rects() if hasattr(self.host, "obstacle_rects") else []
        if obstacles and (avoid is None or avoid.width() <= 0):
            w, h, o = lab.width(), lab.height(), self.LABEL_OFFSET
            best = None
            for dx, dy in ((o.x(), o.y()), (o.x(), -h - o.y()), (-w - o.x(), o.y()), (-w - o.x(), -h - o.y())):
                r = QRectF(cur.x() + dx, cur.y() + dy, w, h)
                grown = [q.adjusted(-6, -6, 6, 6) for q in obstacles]
                cover = sum((r & q).width() * (r & q).height() for q in grown if r.intersects(q))
                if best is None or cover < best[0]:
                    best = (cover, QPoint(int(r.x()), int(r.y())))
                if cover == 0:
                    break
            p = best[1]
        if avoid is not None and avoid.width() > 0:
            # keep the readout off the shape being counted: above or below it, left- or right-aligned,
            # whichever spot covers the fewest numbers / tags (6 px margin) and stays on screen
            w, h = lab.width(), lab.height()
            grown = [q.adjusted(-6, -6, 6, 6) for q in obstacles]
            best = None
            for x0, y0 in ((avoid.left(), avoid.top() - h - 12), (avoid.right() - w, avoid.top() - h - 12),
                           (avoid.left(), avoid.bottom() + 12), (avoid.right() - w, avoid.bottom() + 12)):
                r = QRectF(x0, y0, w, h)
                off = r.top() < 0 or r.bottom() > vp.height() or r.left() < 0 or r.right() > vp.width()
                cover = sum((r & q).width() * (r & q).height() for q in grown if r.intersects(q))
                key = (off, cover)
                if best is None or key < best[0]:
                    best = (key, QPoint(int(x0), int(y0)))
            p = best[1]
        x = min(max(0, p.x()), max(0, vp.width() - lab.width()))
        y = min(max(0, p.y()), max(0, vp.height() - lab.height()))
        lab.move(x, y)
        lab.show()
        lab.raise_()

    def _view_bbox(self, geom, crs):
        """The drawn shape's bounding box in view pixels (rotation included)."""
        dest = self.canvas.mapSettings().destinationCrs()
        xf = QgsCoordinateTransform(crs, dest, QgsProject.instance()) if crs.isValid() and crs != dest else None
        ct = self.canvas.getCoordinateTransform()
        pts = [ct.transform(xf.transform(QgsPointXY(v)) if xf else QgsPointXY(v)) for v in geom.vertices()]
        if not pts:
            return None
        xs, ys = [q.x() for q in pts], [q.y() for q in pts]
        return QRectF(min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys))

    def _anchor_px(self):
        if self._anchor is None:
            return None
        pt, crs = self._anchor
        dest = self.canvas.mapSettings().destinationCrs()
        if crs != dest:
            pt = QgsCoordinateTransform(crs, dest, QgsProject.instance()).transform(pt)
        px = self.canvas.getCoordinateTransform().transform(pt)
        return QPoint(int(px.x()), int(px.y()))

    def _show(self, html, colour_key):
        if self.label is None or sip.isdeleted(self.label):
            return
        if self.label.property("vm_colour") != colour_key:   # restyling is slow: only on change
            _style_label(self.label, colour_key)
            self.label.setProperty("vm_colour", colour_key)
        self.label.setText(html)
        self._place()
        self.host.notify(self)

    # Qt entry points -------------------------------------------------
    @guarded("{key}.eventFilter", False)
    def eventFilter(self, obj, event):  # noqa: N802 - Qt name
        if event.type() == QEvent.Type.MouseMove:
            self._cursor = event.position().toPoint() if hasattr(event, "position") else event.pos()
            if self.label is not None and not sip.isdeleted(self.label) and self.label.isVisible():
                self._place()
        elif event.type() == QEvent.Type.Leave:
            self._hide()
        return False

    @guarded("{key}.toolset")
    def _on_tool_set(self, new_tool, *args):
        self._attach(new_tool)

    @guarded("{key}.transient")
    def _on_transient_slot(self, geom):
        # HR7: never keep the argument - copy geometry and CRS here, use the copies only.
        if not self.active:
            self.stats["calls_while_off"] += 1
            return
        g = QgsGeometry(geom)
        crs = QgsCoordinateReferenceSystem(geom.crs())
        self._transient(g, crs)


class LiveMeasureTool(_CaptureWatcher):
    """T1: segment m, total m and bearing beside the cursor while a QGIS capture tool draws."""

    title = "Live Measure"
    key = "t1"

    def limit_for(self, layer):
        ov = _setting("span_limit", "auto")
        ov = None if str(ov) == "auto" else _float(ov, None)
        return core.limit_for_layer(layer.name() if layer is not None else "", ov)

    def _transient(self, geom, crs):
        if geom.isNull() or geom.isEmpty():
            self.last = None
            self._hide()
            return
        layer = self._tool.layer() if self._tool is not None and not sip.isdeleted(self._tool) else None
        is_poly = geom.type() == Qgis.GeometryType.Polygon
        pts = [QgsPointXY(v) for v in geom.vertices()]
        r = core.segment_and_total(pts, is_poly)
        if r is None:
            self.last = None
            self._hide()
            return
        a, b, path = r
        self._anchor = (b, crs)
        da = self._da(crs)
        seg = da.measureLine(a, b)
        total = core.path_length(da, path)
        brg = core.bearing_deg(da, a, b) if seg > 0 else 0.0
        if is_poly or not isinstance(layer, QgsVectorLayer) or layer.geometryType() != Qgis.GeometryType.Line:
            colour, limit, basis = core.NEUTRAL, None, None
        else:
            limit = self.limit_for(layer)
            if core.is_drop_layer(layer.name()):
                basis = "total"
                colour = core.span_colour(total, limit)
            else:
                basis = "segment"
                colour = core.span_colour(seg, limit)
        self.last = {"segment": seg, "total": total, "bearing": brg, "colour": colour,
                     "limit": limit, "basis": basis, "a": a, "b": b}
        self._show_line(pts, crs, is_poly, COLOURS[colour])
        shown = total if basis == "total" else seg
        if self.label is not None and not sip.isdeleted(self.label):
            self.label.bar = None if limit is None else (min(shown / limit, 1.25) / 1.25, COLOURS[colour], 0.95 / 1.25)
        if limit is None:
            lim = ""
        else:
            room = limit - shown
            lim = ("<span style='color:%s'> &nbsp;limit %g m · </span><span style='color:%s'>%s</span>"
                   % (CHIP_MUTED, limit, COLOURS[colour],
                      ("%.1f m left" % room) if room >= 0 else ("%.1f m over" % -room)))
        tot = "" if abs(total - seg) < 0.05 else "total %.1f m &nbsp;" % total   # one segment: no repeat
        html = ("<span style='color:%s;font-size:15px'>%.1f m</span>"
                "<span style='color:%s'> &nbsp;%s%03.0f°</span>%s"
                % (COLOURS[colour], seg, CHIP_MUTED, tot, brg, lim))
        self._show(html, colour)


class GroupCounterTool(_CaptureWatcher):
    """T4: count of points inside the polygon being drawn, plus its area."""

    title = "Group counter"
    key = "t4"
    STACK = QPoint(0, 30)
    CAP = 2000

    def __init__(self, host):
        super().__init__(host)
        self._index = None
        self._index_layer = None
        self._dirty = True
        self.index_builds = 0

    def mode(self):
        m = str(_setting("mode", core.STS))
        return m if m in (core.PON, core.STS, core.FTS) else core.STS

    def bands(self):
        d = core.DEFAULT_BANDS
        return {
            "pon_low": int(_float(_setting("pon_low", d["pon_low"]), d["pon_low"])),
            "pon_high": int(_float(_setting("pon_high", d["pon_high"]), d["pon_high"])),
            "pon_cap": int(_float(_setting("pon_cap", d["pon_cap"]), d["pon_cap"])),
            "sts_max": int(_float(_setting("sts_max", d["sts_max"]), d["sts_max"])),
            "sts_guide": d["sts_guide"],
            "fts_max": int(_float(_setting("fts_max", d["fts_max"]), d["fts_max"])),
        }

    def point_layer(self):
        proj = QgsProject.instance()
        key = "sts_layer_id" if self.mode() == core.FTS else "point_layer_id"
        lid = str(_setting(key, "") or "")
        lyr = proj.mapLayer(lid) if lid else None
        if isinstance(lyr, QgsVectorLayer) and lyr.geometryType() == Qgis.GeometryType.Point:
            return lyr
        if self.mode() == core.FTS:
            return None
        for name in ("demand points", "centroids"):
            for lyr in proj.mapLayers().values():
                if (isinstance(lyr, QgsVectorLayer) and lyr.geometryType() == Qgis.GeometryType.Point
                        and name in lyr.name().lower()):
                    return lyr
        return None

    def _on(self):
        super()._on()
        self._connect(QgsProject.instance(), "layersWillBeRemoved", self._on_layers_removed_slot)

    def _off(self):
        super()._off()
        self._drop_index()

    def _drop_index(self):
        if self._index_layer is not None:
            self._disconnect_owner(self._index_layer)
        self._index = self._index_layer = None
        self._dirty = True

    def _on_layers_removed_slot(self, ids):
        self._layers_removed(ids)

    @guarded("{key}.layersRemoved")
    def _layers_removed(self, ids):
        if self._index_layer is not None and self._index_layer.id() in set(ids):
            self._drop_index()
            self._hide()

    def _on_point_layer_changed(self, *args):
        self._invalidate()

    @guarded("{key}.invalidate")
    def _invalidate(self):
        self._dirty = True

    @guarded("{key}.index")
    def _ensure_index(self, layer):
        if layer is not self._index_layer:
            self._drop_index()
        if self._index is not None and not self._dirty:
            return True
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            pts = core.PointSet(layer)
        finally:
            QApplication.restoreOverrideCursor()
        self._index, self._dirty = pts, False
        self.index_builds += 1
        if self._index_layer is not layer:
            self._index_layer = layer
            for sig in ("featureAdded", "featureDeleted", "geometryChanged"):
                self._connect(layer, sig, self._on_point_layer_changed)
        return True

    def _transient(self, geom, crs):
        if geom.isNull() or geom.isEmpty() or geom.type() != Qgis.GeometryType.Polygon:
            self.last = None
            self._hide()
            return
        layer = self.point_layer()
        mode = self.mode()
        if layer is None:
            self.last = {"error": "no point layer"}
            self._show("Group counter: %s" % ("no STS point layer chosen" if mode == core.FTS
                                              else "no Demand points layer"), core.NEUTRAL)
            return
        if not self._ensure_index(layer):
            return
        poly = QgsGeometry(geom)
        if layer.crs() != crs:
            poly.transform(QgsCoordinateTransform(crs, layer.crs(), QgsProject.instance()))
        area = self._da(crs).measureArea(geom)
        b = self.bands()
        try:
            n = core.count_points_in(poly, self._index, self.CAP)
        except core.AreaTooLarge:
            self.last = {"count": None, "area": area, "too_large": True}
            self._show("Group counter: area too large (more than %d points to test)" % self.CAP,
                       core.NEUTRAL)
            return
        colour = core.band_classify(mode, n, b)
        if mode == core.PON:
            what, ref = "homes", "PON %d-%d, cap %d" % (b["pon_low"], b["pon_high"], b["pon_cap"])
        elif mode == core.STS:
            what, ref = "homes", "max %d per STS (aim %s)" % (b["sts_max"], str(b["sts_guide"]).replace("-", "\u2013"))
        else:
            what, ref = "STS", "FTS max %d" % b["fts_max"]
        self.last = {"count": n, "area": area, "colour": colour, "mode": mode, "too_large": False}
        self._show_line([QgsPointXY(v) for v in geom.vertices()], crs, True, COLOURS[colour])
        self._avoid = self._view_bbox(geom, crs)
        top = {core.PON: b["pon_cap"], core.STS: b["sts_max"], core.FTS: b["fts_max"]}[mode]
        tick = (b["pon_high"] / float(top)) if mode == core.PON else None
        if self.label is not None and not sip.isdeleted(self.label):
            self.label.bar = (min(n / float(top), 1.0) if top else 0.0, COLOURS[colour], tick)
        lim_n = {core.PON: b["pon_high"], core.STS: b["sts_max"], core.FTS: b["fts_max"]}[mode]
        room = ("%d too many" % (n - lim_n)) if n > lim_n else ("%d left" % (lim_n - n))
        html = ("<span style='color:%s;font-size:17px'>%d</span><span style='color:%s'> %s</span>"
                "<span style='color:%s'> &nbsp;%s</span><span style='color:%s'> &nbsp;%s &nbsp;%s m² · %.2f ha</span>"
                % (COLOURS[colour], n, CHIP_TEXT, what, COLOURS[colour], room, CHIP_MUTED, ref,
                   "{:,.0f}".format(area), area / 10000.0))
        self._show(html, colour)


# ── Shared drop engine + drop views ──────────────────────────────────────
LARGE_LAYER = 20000
MAX_PENDING = 200
DEBOUNCE_MS = 200
MPP_GATE = 1.0
NUMBER_RED = "#B00000"
PON_BLUE = "#1E6FD9"
LENGTH_COLOURS = {core.GREEN: "#1FA34A", core.AMBER: "#F08A00", core.RED: "#E01E1E"}
DROP_MAX_DEFAULT = 8            # D22 (JJ 2026-10-05): poles with more than 8 drops go red
PON_GROUP_LIMIT_DEFAULT = 16    # D22: 16 x 1:8 per PON
# line width by band as well as colour: the three classes stay apart without colour vision
LENGTH_WIDTHS = {"green": 2.0, "amber": 3.2, "red": 4.8}
SELECTED_YELLOW = "#FFE600"
# JJ 2026-10-05: while a QGIS edit tool (vertex tool, add / move / reshape ...) is active, the overlays
# step back under QGIS's own editing graphics (snap box, vertex markers, selection bands are at z=0)
EDIT_Z = {"lengths": -4, "pons": -3, "drops": -2}   # above the map (-10), below QGIS edit graphics (0)
EDIT_OPACITY = 0.45
EDIT_CLEAR_PX = 40          # pole numbers / PON tiles this close to the cursor hide while editing
EDIT_STYLES = ("fade", "hide", "top")   # JJ 2026-10-05: selected drops show yellow over the length colours
SEL = "selected"
MAX_GREEN_DRAWN = 1500   # more green drops than this on screen -> draw only orange + red
CASING_MAX = 600         # dark casing under the coloured lines only up to this many drops on screen
CHIP_BG = QColor(7, 11, 18, 230)
CHIP_FG = "#EAF3FF"
_ASK_LARGE = None        # test seam: callable(n_drops) -> bool; None = ask JJ with a question box

try:
    import numpy as _np
except ImportError:  # pragma: no cover - QGIS ships numpy
    _np = None


def _batch_transform(xf, pts):
    """Transform a list of QgsPointXY in one C++ call (order and duplicates kept)."""
    if not pts:
        return []
    g = QgsGeometry.fromMultiPointXY(pts)
    g.transform(xf)
    return g.asMultiPoint()


def _affine(ct):
    """The map->pixel affine of a QgsMapToPixel (rotation included) as (a, b, c, d, e, f):
    px = a*x + b*y + c ; py = d*x + e*y + f."""
    o = ct.transform(0.0, 0.0)
    ex = ct.transform(1.0, 0.0)
    ey = ct.transform(0.0, 1.0)
    return (ex.x() - o.x(), ey.x() - o.x(), o.x(), ex.y() - o.y(), ey.y() - o.y(), o.y())


def _chip_rect(painter, text, x, y, fg=CHIP_FG, edge=None, bold=True):
    """A small dark console chip with one line of text (on-map legends and notes)."""
    f = QFont()
    f.setBold(bold)
    f.setPointSizeF(9.0)
    painter.setFont(f)
    fm = QFontMetricsF(f)
    w, h = fm.horizontalAdvance(text) + 16, fm.height() + 8
    r = QRectF(x, y, w, h)
    painter.setPen(QPen(QColor(edge or "#20304A"), 1.0))
    painter.setBrush(CHIP_BG)
    painter.drawRoundedRect(r, 5, 5)
    painter.setPen(QColor(fg))
    painter.drawText(r, int(Qt.AlignmentFlag.AlignCenter), text)
    return r


def _along(xs, ys, frac):
    """The point frac of the way along a pixel polyline."""
    segs = [math.hypot(xs[i + 1] - xs[i], ys[i + 1] - ys[i]) for i in range(len(xs) - 1)]
    want = sum(segs) * frac
    for i, d in enumerate(segs):
        if want <= d and d > 0:
            t = want / d
            return QPointF(xs[i] + (xs[i + 1] - xs[i]) * t, ys[i] + (ys[i + 1] - ys[i]) * t)
        want -= d
    return QPointF(xs[-1], ys[-1])


def _legend_chip(painter, x, y, items):
    """Dark legend chip. items: (colour, text, width) for a line swatch drawn at the map's own
    width, or (symbol, text, None) with symbol "disc", "disc_over", "tile" or "tile_over"."""
    f = QFont()
    f.setBold(True)
    f.setPointSizeF(9.0)
    painter.setFont(f)
    fm = QFontMetricsF(f)
    sw, gap, pad = 14.0, 6.0, 9.0
    w = pad * 2 + sum(sw + gap + fm.horizontalAdvance(it[1]) for it in items) + 12.0 * (len(items) - 1)
    h = fm.height() + 8
    r = QRectF(x, y, w, h)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    painter.setPen(QPen(QColor("#20304A"), 1.0))
    painter.setBrush(CHIP_BG)
    painter.drawRoundedRect(r, 5, 5)
    cx, cy = x + pad, r.center().y()
    for colour, text, lw in items:
        if lw is not None:
            painter.setPen(QPen(QColor(colour), lw, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            painter.drawLine(QPointF(cx, cy), QPointF(cx + sw, cy))
        else:
            box = QRectF(cx + 1, cy - 6, 12, 12)
            if colour == "disc":
                painter.setPen(QPen(QColor(NUMBER_RED), 2.0))
                painter.setBrush(QColor("#FFFFFF"))
                painter.drawEllipse(box)
            elif colour == "disc_over":
                painter.setPen(QPen(QColor("#FFFFFF"), 1.5))
                painter.setBrush(QColor(NUMBER_RED))
                painter.drawEllipse(box)
            elif colour == "tile":
                painter.setPen(QPen(QColor(PON_BLUE), 2.0))
                painter.setBrush(QColor("#FFFFFF"))
                painter.drawRoundedRect(box, 3, 3)
            else:
                painter.setPen(QPen(QColor("#FFFFFF"), 1.5))
                painter.setBrush(QColor(NUMBER_RED))
                painter.drawRoundedRect(box, 3, 3)
        cx += sw + gap
        tw = fm.horizontalAdvance(text)
        painter.setPen(QColor(CHIP_FG))
        painter.drawText(QRectF(cx, r.top(), tw + 1, h), int(Qt.AlignmentFlag.AlignVCenter), text)
        cx += tw + 12.0
    return r


class _HubItem(QgsMapCanvasItem):
    """The ONE canvas item of an overlay tool. paint() only blits pre-rendered images."""

    def __init__(self, canvas, owner):
        super().__init__(canvas)
        self._owner = owner
        self._brect = QRectF()   # changed ONLY through set_brect (prepareGeometryChange first)
        self.setZValue(1000)

    def updatePosition(self):
        # Drawing is in view pixels, so the item stays at the view origin. (Tying it to the
        # map extent's corner put everything off-screen on a rotated canvas.)
        self.setPos(0, 0)

    def set_brect(self, r):
        if r != self._brect:
            self.prepareGeometryChange()
            self._brect = QRectF(r)

    def paint(self, painter, option=None, widget=None):
        o = self._owner
        if o is not None:
            o._paint(painter)

    def boundingRect(self):
        o = self._owner
        if o is not None:
            o._bounding_rect()   # HR3 fault hook only; the value comes from the cache
        return self._brect


def _best_editable(lyr):
    """True if the layer is in an edit session (False if it is gone or deleted)."""
    try:
        return (not sip.isdeleted(lyr)) and lyr.isEditable()
    except Exception:
        return False


class DropEngine(_Tool):
    """One read of the drop layer(s) for every drop view: hubs (both drop ends clustered)
    and per-drop true lengths + vertices. Views attach/detach; the engine runs while any
    view is attached. One set of layer connections, one debounce, one feature pass."""

    title = "Drop tools"
    key = "eng"
    changed = pyqtSignal()

    def __init__(self, host):
        super().__init__(host)
        self.subs = []
        self.layers = []
        self._xf, self._to_main, self._da = [], [], []
        self._pending = set()
        self._full_pending = False
        self._timer = None
        self.hubs = core.HubIndex(0.5)
        self.lengths = {}       # (li, fid) -> (metres, [numpy (n, 2) vertex arrays in the main layer CRS])
        self.full_recounts = 0
        self.incremental_updates = 0
        self.passes = 0
        self.skipped = 0
        self.n_drops = 0
        self.stale = False
        self._have_hubs = self._have_lengths = False
        self._ids_dirty = False     # a drop was added / deleted since the last full count (fids change on save)
        self._quiet_until = 0.0     # dataChanged right after a geometry-only save needs no recount
        self.skipped_full = 0

    # subscriptions ------------------------------------------------------
    def need_hubs(self):
        return any(getattr(s, "uses_hubs", False) for s in self.subs)

    def need_lengths(self):
        return any(getattr(s, "uses_lengths", False) for s in self.subs)

    def attach(self, view):
        if view not in self.subs:
            self.subs.append(view)
        if not self.active:
            self.switch_on()
        elif (self.need_hubs() and not self._have_hubs) or (self.need_lengths() and not self._have_lengths):
            self._request_full()
        else:
            QTimer.singleShot(0, self._emit_changed)

    def detach(self, view):
        if view in self.subs:
            self.subs.remove(view)
        if not self.subs:
            self.switch_off()

    def _emit_changed(self):
        try:
            if self.active:
                self.changed.emit()
        except Exception:
            QgsMessageLog.logMessage(traceback.format_exc(), LOG_TAG, Qgis.MessageLevel.Warning)

    def _off_after_fault(self):
        # an engine fault stops every drop view quietly (the engine already showed ONE message)
        for s in list(self.subs):
            _best_effort(s.switch_off, s._uncheck)
        self.subs = []
        super()._off_after_fault()

    # options ------------------------------------------------------------
    def radius(self):
        return min(5.0, max(0.1, _float(_setting("join_radius", 0.5), 0.5)))

    def drop_layers(self):
        proj = QgsProject.instance()
        lines = [lyr for lyr in proj.mapLayers().values()
                 if isinstance(lyr, QgsVectorLayer) and lyr.geometryType() == Qgis.GeometryType.Line]
        lid = str(_setting("drop_layer_id", "") or "")
        main = proj.mapLayer(lid) if lid else None
        if main not in lines:
            cands = [lyr for lyr in lines if "drop" in lyr.name().lower() and "spare" not in lyr.name().lower()]
            main = max(cands, key=lambda lyr: lyr.featureCount()) if cands else None
        out = [main] if main is not None else []
        if main is not None and str(_setting("include_spare", "false")).lower() in ("true", "1"):
            sp = [lyr for lyr in lines if lyr is not main and "drop" in lyr.name().lower()
                  and "spare" in lyr.name().lower()]
            if sp:
                out.append(max(sp, key=lambda lyr: lyr.featureCount()))
        return out

    # on / off -----------------------------------------------------------
    def _on(self):
        self.layers = self.drop_layers()
        self._timer = QTimer()
        self._timer.setSingleShot(True)
        self._timer.setInterval(DEBOUNCE_MS)
        self._connect(self._timer, "timeout", self._on_timer)
        self._connect(QgsProject.instance(), "layersWillBeRemoved", self._on_layers_removed)
        for li, lyr in enumerate(self.layers):
            for sig in ("geometryChanged", "featureAdded", "featureDeleted"):
                self._connect(lyr, sig, functools.partial(self._on_edit_signal, li, sig))
            for sig in ("afterCommitChanges", "afterRollBack", "editingStopped", "dataChanged"):
                self._connect(lyr, sig, functools.partial(self._on_full_signal, sig))
        n = sum(lyr.featureCount() for lyr in self.layers)
        if n > LARGE_LAYER and not self._ask_large(n):
            QTimer.singleShot(0, self._refuse_large)
            return
        self._request_full()

    def _refuse_large(self):
        for s in list(self.subs):
            _best_effort(s.switch_off, s._uncheck)
        self.subs = []
        _best_effort(self.switch_off)

    def _ask_large(self, n):
        if _ASK_LARGE is not None:
            return bool(_ASK_LARGE(n))
        from qgis.PyQt.QtWidgets import QMessageBox
        r = QMessageBox.question(self.host.iface.mainWindow(), "Drop tools",
                                 "Count %s drops? QGIS pauses for a few seconds while it counts. Saving "
                                 "will NOT recount; use Recount now in the Span Inspector." % format(n, ","))
        return r == QMessageBox.StandardButton.Yes

    def _off(self):
        def stop_timer():
            t, self._timer = self._timer, None
            if t is not None and not sip.isdeleted(t):
                t.stop()

        def clear():
            self._pending.clear()
            self._full_pending = False
            self.layers = []
            self._have_hubs = self._have_lengths = False
        _best_effort(stop_timer, clear)

    def destroy(self):
        self.subs = []
        self.switch_off()

    # signals ------------------------------------------------------------
    def _on_edit_signal(self, li, sig, fid, *rest):
        self._edit(li, sig, fid)

    @guarded("{key}.edit")
    def _edit(self, li, sig, fid):
        if not self.active:
            self.stats["calls_while_off"] += 1
            return
        if self.key + "." + sig in _INJECT:
            raise RuntimeError("injected fault: " + self.key + "." + sig)
        if sig in ("featureAdded", "featureDeleted"):
            self._ids_dirty = True
        self._pending.add((li, int(fid)))
        self._timer.start()

    def _on_full_signal(self, sig, *args):
        self._full(sig)

    @guarded("{key}.full")
    def _full(self, sig):
        if not self.active:
            self.stats["calls_while_off"] += 1
            return
        if self.key + "." + sig in _INJECT:
            raise RuntimeError("injected fault: " + self.key + "." + sig)
        # JJ 2026-10-06 "every time I move something it loads": a move already arrives as geometryChanged and
        # is applied incrementally, so the dataChanged that QGIS fires with every edit must not recount all drops.
        if sig == "dataChanged" and (any(_best_editable(lyr) for lyr in self.layers)
                                     or time.monotonic() < self._quiet_until):
            self.skipped_full += 1
            return
        if self.n_drops > LARGE_LAYER:
            self.stale = True   # big layers recount on switch-on / Recount only: no freeze on save
            self._emit_changed()
            return
        if sig in ("afterCommitChanges", "editingStopped") and not self._ids_dirty and not self._full_pending:
            self._quiet_until = time.monotonic() + 2.0     # only geometry moved: fids are stable, index is right
            self.skipped_full += 1
            return
        self._request_full()

    def _request_full(self):
        self._full_pending = True
        if self._timer is not None:
            self._timer.start()

    def recount_now(self):
        if self.active:
            self._request_full()

    @guarded("{key}.debounce")
    def _on_timer(self):
        if self._full_pending or len(self._pending) > MAX_PENDING:
            self._full_recount()
        elif self._pending:
            self._apply_pending()

    @guarded("{key}.layersWillBeRemoved")
    def _on_layers_removed(self, ids):
        ids = set(ids)
        if any(lyr.id() in ids for lyr in self.layers):
            for lyr in self.layers:
                self._disconnect_owner(lyr)
            self.layers = []
            self.hubs = core.HubIndex(self.radius())
            self.lengths = {}
            self._pending.clear()
            self.n_drops = 0
            self._emit_changed()

    # counting -----------------------------------------------------------
    def _transforms(self):
        self._xf, self._to_main, self._da = [], [], []
        if not self.layers:
            return None
        main = self.layers[0]
        utm = core.utm_crs_for_extent(main.extent(), main.crs())
        if utm is None:
            return None
        ctx = QgsProject.instance().transformContext()
        for lyr in self.layers:
            self._xf.append(QgsCoordinateTransform(lyr.crs(), utm, ctx))
            self._to_main.append(None if lyr.crs() == main.crs()
                                 else QgsCoordinateTransform(lyr.crs(), main.crs(), ctx))
            self._da.append(core.make_distance_area(lyr.crs()))
        return utm

    def _ends(self, li, geom):
        e = core.drop_end_points(geom)
        if e is None:
            return None
        xf, tm = self._xf[li], self._to_main[li]
        out = []
        for p in e:
            u = xf.transform(p)
            out.append((u.x(), u.y(), tm.transform(p) if tm is not None else p))
        return out

    def _length_entry(self, li, geom):
        """(metres, [vertex arrays in the main CRS]) or None for a null / empty drop."""
        if geom is None or geom.isNull() or geom.isEmpty():
            return None
        m = self._da[li].measureLength(geom)
        g = geom
        tm = self._to_main[li]
        if tm is not None:
            g = QgsGeometry(geom)
            g.transform(tm)
        parts = []
        for part in g.constParts():
            pts = [(v.x(), v.y()) for v in part.vertices()]
            if len(pts) >= 2:
                parts.append(_np.array(pts, dtype=float) if _np is not None else pts)
        return (m, parts) if parts else None

    @guarded("{key}.recount")
    def _full_recount(self):
        if self._timer is not None:
            self._timer.stop()
        self._pending.clear()
        self._full_pending = False
        need_h, need_l = self.need_hubs(), self.need_lengths()
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            utm = self._transforms()
            drops, lengths, skipped, n = [], {}, 0, 0
            if utm is not None:
                req = QgsFeatureRequest().setNoAttributes()
                for li, lyr in enumerate(self.layers):
                    ids, pts = [], []
                    for f in lyr.getFeatures(req):   # the ONE feature pass for every view
                        n += 1
                        g = f.geometry()
                        if need_h:
                            e = core.drop_end_points(g)
                            if e is None:
                                skipped += 1
                            else:
                                ids.append(f.id())
                                pts.extend(e)
                        if need_l:
                            le = self._length_entry(li, g)
                            if le is not None:
                                lengths[(li, f.id())] = le
                            elif not need_h:
                                skipped += 1
                    if need_h:
                        utm_pts = _batch_transform(self._xf[li], pts)
                        lay_pts = pts if self._to_main[li] is None else _batch_transform(self._to_main[li], pts)
                        for i, fid in enumerate(ids):
                            a, b = utm_pts[2 * i], utm_pts[2 * i + 1]
                            drops.append(((li, fid), (a.x(), a.y(), lay_pts[2 * i]),
                                          (b.x(), b.y(), lay_pts[2 * i + 1])))
            self.passes += 1
            self.hubs = core.HubIndex(self.radius())
            if need_h:
                self.hubs.rebuild(drops)
            self.lengths = lengths
            self._have_hubs, self._have_lengths = need_h, need_l
            self.skipped, self.n_drops, self.stale = skipped, n, False
            self._ids_dirty = False
            self.full_recounts += 1
        finally:
            QApplication.restoreOverrideCursor()
        self._emit_changed()

    def _apply_pending(self):
        pend, self._pending = self._pending, set()
        need_h, need_l = self._have_hubs, self._have_lengths
        for li, fid in pend:
            if li >= len(self.layers):
                continue
            f = self.layers[li].getFeature(fid)
            g = f.geometry() if f.isValid() else None
            if need_h:
                e = self._ends(li, g) if g is not None else None
                if e is None:
                    self.hubs.update_drop((li, fid))
                else:
                    self.hubs.update_drop((li, fid), e[0], e[1])
            if need_l:
                le = self._length_entry(li, g) if g is not None else None
                if le is None:
                    self.lengths.pop((li, fid), None)
                else:
                    self.lengths[(li, fid)] = le
        self.incremental_updates += 1
        self._emit_changed()


class _DropView(_Tool):
    """Common part of the views that draw from the DropEngine: one canvas item, redraw on
    pan / zoom / rotation / CRS change and whenever the engine reports a change."""

    uses_hubs = False
    uses_lengths = False
    z_value = 1000   # stacking: drop lengths 990 < PON groups 1005 < drop counter 1010 (JJ: numbers on top)

    def __init__(self, host):
        super().__init__(host)
        self.item = None
        self._img_cache = {}
        self._view_xf = None
        self._chip = None
        self.view = {}

    # engine passthroughs (tests and the panel read these on the view)
    @property
    def engine(self):
        return self.host.engine

    @property
    def layers(self):
        return self.engine.layers

    @property
    def full_recounts(self):
        return self.engine.full_recounts

    @property
    def incremental_updates(self):
        return self.engine.incremental_updates

    @property
    def skipped(self):
        return self.engine.skipped

    @property
    def n_drops(self):
        return self.engine.n_drops

    @property
    def stale(self):
        return self.engine.stale

    @property
    def _pending(self):
        return self.engine._pending

    @property
    def _timer(self):
        return self.engine._timer

    @_timer.setter
    def _timer(self, value):
        self.engine._timer = value

    def _full_recount(self):
        self.engine._full_recount()

    def _on_timer(self):
        self.engine._on_timer()

    def _ends(self, li, geom):
        return self.engine._ends(li, geom)

    def recount_now(self):
        self.engine.recount_now()

    def _on_full_signal(self, sig, *args):
        self.engine._on_full_signal(sig, *args)

    # on / off -----------------------------------------------------------
    def _on(self):
        self._img_cache.clear()
        self._view_xf = None
        if self.item is None:
            self.item = _HubItem(self.canvas, self)
            self.item.setZValue(self.z_value)
        self._connect(self.canvas, "extentsChanged", self._on_extent)
        self._connect(self.canvas, "rotationChanged", self._on_extent)
        self._connect(self.canvas, "destinationCrsChanged", self._on_crs)
        self._connect(self.engine, "changed", self._on_engine_changed)
        self.engine.attach(self)
        if not self.engine.active and self.active:
            raise RuntimeError("drop engine did not start")

    def _off(self):
        def detach():
            self.engine.detach(self)

        def drop_item():
            item, self.item = self.item, None
            if item is not None:
                try:
                    sc = item.scene()
                    if sc is not None:
                        sc.removeItem(item)      # while its bounding rect is still the indexed one
                finally:
                    item._owner = None

        def clear():
            self._chip = None
            self._clear_view()
        _best_effort(detach, drop_item, clear)
        self.host.notify(self)

    def _clear_view(self):
        pass

    def destroy(self):
        self.switch_off()

    @guarded("{key}.engineChanged")
    def _on_engine_changed(self, *args):
        self._view_xf = None if not self.layers else self._view_xf
        self._recompute_view()

    @guarded("{key}.extentsChanged")
    def _on_extent(self, *args):
        self._recompute_view()

    @guarded("{key}.destinationCrsChanged")
    def _on_crs(self, *args):
        self._view_xf = None
        self._recompute_view()

    def _main_to_view(self):
        dest = self.canvas.mapSettings().destinationCrs()
        main_crs = self.layers[0].crs()
        if self._view_xf is None or (self._view_xf is not False and self._view_xf.destinationCrs() != dest):
            self._view_xf = (False if main_crs == dest else
                             QgsCoordinateTransform(main_crs, dest, QgsProject.instance()))
        return self._view_xf

    def _visible_extent_main(self):
        e = self.canvas.extent()
        e.scale(1.1)
        xf = self._main_to_view()
        if xf:
            try:
                e = xf.transformBoundingBox(e, Qgis.TransformDirection.Reverse)
            except Exception:
                return None
        return e

    def _mpp(self):
        """Geodesic metres per pixel along the canvas's own pixel axis (works when rotated)."""
        ms = self.canvas.mapSettings()
        w, h = ms.outputSize().width(), ms.outputSize().height()
        if w <= 0:
            return 0.0
        ct = self.canvas.getCoordinateTransform()
        a, b = ct.toMapCoordinates(0, h // 2), ct.toMapCoordinates(w, h // 2)
        return core.make_distance_area(ms.destinationCrs()).measureLine(a, b) / float(w)

    def _prep_item(self):
        self.item.setPos(0, 0)
        apply = getattr(self.host, "style_item", None)
        if apply is not None:
            apply(self)
        vpw = self.canvas.viewport()
        self.item.set_brect(QRectF(-50, -50, vpw.width() + 100, vpw.height() + 100))

    @guarded("{key}.boundingRect")
    def _bounding_rect(self):
        return True

    def _paint_chip(self, painter, y=10):
        """Hint chips are drawn by the controller's HUD (one stacked column, no overlaps)."""
        return None

    # panel hooks --------------------------------------------------------
    def status_text(self):
        return ""

    def next_targets(self):
        """[(label, QgsRectangle in the main layer CRS)] of current problems, worst first."""
        return []


class DropCounterTool(_DropView):
    """T5: the number of drops meeting at every pole (2+), as round badges."""

    title = "Drop counter"
    key = "t5"
    uses_hubs = True
    z_value = 1010

    def __init__(self, host):
        super().__init__(host)
        self._draw = []

    @property
    def hubs(self):
        return self.engine.hubs

    def sts_max(self):
        """Max drops per pole for the drop counter (D22: 8 = one 1:8 per pole). Its own setting,
        separate from the Group counter's STS max."""
        return max(1, int(_float(_setting("drop_max", DROP_MAX_DEFAULT), DROP_MAX_DEFAULT)))

    def _clear_view(self):
        self._draw = []

    def _image(self, n, over, dpr):
        """Round badge: white disc + dark-red ring (solid dark-red disc when over the drops-per-pole max)."""
        k = (n, over, dpr)
        img = self._img_cache.get(k)
        if img is not None:
            return img
        font = QFont()
        font.setBold(True)
        font.setPointSizeF(9.5)
        fm = QFontMetricsF(font)
        text = str(n)
        d = max(fm.height() + 6.0, fm.horizontalAdvance(text) + 10.0)
        size = d + 4.0
        img = QImage(int(math.ceil(size * dpr)), int(math.ceil(size * dpr)), QImage.Format.Format_ARGB32_Premultiplied)
        img.setDevicePixelRatio(dpr)
        img.fill(Qt.GlobalColor.transparent)
        p = QPainter(img)
        try:
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
            r = QRectF(2, 2, d, d)
            if over:
                p.setPen(QPen(QColor("#FFFFFF"), 1.5))
                p.setBrush(QColor(NUMBER_RED))
                p.drawEllipse(r)
                p.setPen(QColor("#FFFFFF"))
            else:
                p.setPen(QPen(QColor(NUMBER_RED), 2.2))
                p.setBrush(QColor("#FFFFFF"))
                p.drawEllipse(r)
                p.setPen(QColor(NUMBER_RED))
            p.setFont(font)
            p.drawText(r, int(Qt.AlignmentFlag.AlignCenter), text)
        finally:
            p.end()
        self._img_cache[k] = img
        return img

    @guarded("{key}.view")
    def _recompute_view(self):
        if self.item is None:
            return
        self._prep_item()
        self._draw, self._chip = [], None
        mx = self.sts_max()
        hubs = self.hubs.hubs(2)
        over_n = sum(1 for _p, c in hubs if c > mx)
        vp = self.canvas.viewport()
        W, H = vp.width(), vp.height()
        self.view = {"hubs": len(hubs), "over": over_n, "visible": 0, "mpp": 0.0, "drawn": 0}
        if not self.layers or self.n_drops == 0:
            self._chip = "Drop counter: no drops" if self.layers else "Drop counter: no drop layer"
        else:
            mpp = self._mpp()
            self.view["mpp"] = mpp
            if self.stale:
                self._chip = "Drop counts may be stale · Recount now in the Span Inspector"
            if mpp > MPP_GATE:
                self._chip = "Zoom in to see drop counts · %d pole%s over %d drops per pole" % (
                    over_n, "" if over_n == 1 else "s", mx)
            else:
                xf = self._main_to_view()
                ct = self.canvas.getCoordinateTransform()
                origin = self.item.pos()
                dpr = vp.devicePixelRatioF() or 1.0
                vis_ext = self._visible_extent_main()
                if vis_ext is not None:
                    x0, x1, y0, y1 = vis_ext.xMinimum(), vis_ext.xMaximum(), vis_ext.yMinimum(), vis_ext.yMaximum()
                    hubs_in = [h for h in hubs if x0 <= h[0].x() <= x1 and y0 <= h[0].y() <= y1]
                else:
                    hubs_in = hubs
                occupied = {}   # 32 px grid cell -> placed rects (greedy cull without O(n^2))
                vis = 0
                for pt, c in sorted(hubs_in, key=lambda h: (h[1] <= mx, -h[1])):  # over-max first
                    q = xf.transform(pt) if xf else pt
                    px = ct.transform(q)
                    x, y = px.x(), px.y()
                    if x < -40 or y < -40 or x > W + 40 or y > H + 40:
                        continue
                    vis += 1
                    over = c > mx
                    img = self._image(c, over, dpr)
                    iw, ih = img.width() / dpr, img.height() / dpr
                    r = QRectF(x - iw / 2, y - ih / 2, iw, ih)   # centred on the pole, over the lines
                    if r.left() < 0 or r.top() < 0 or r.right() > W or r.bottom() > H:
                        continue   # never draw a number cut in half by the canvas edge
                    cells = [(cx, cy) for cx in range(int(r.left() // 32), int(r.right() // 32) + 1)
                             for cy in range(int(r.top() // 32), int(r.bottom() // 32) + 1)]
                    if not over and any(r.intersects(o) for cell in cells for o in occupied.get(cell, ())):
                        continue   # greedy overlap cull; over-max badges are never culled
                    for cell in cells:
                        occupied.setdefault(cell, []).append(r)
                    self._draw.append((QPointF(r.x() - origin.x(), r.y() - origin.y()), img, c, x, y))
                self.view["visible"] = vis
                self.view["drawn"] = len(self._draw)
        self._update_tooltip(hubs)
        self.item.update()
        self.host.notify(self)

    def _update_tooltip(self, hubs):
        if self.action is None or sip.isdeleted(self.action):
            return
        counts = [c for _p, c in hubs]
        mean = (sum(counts) / float(len(counts))) if counts else 0.0
        self.action.setToolTip(
            "Drop counter: number of drops meeting at each pole (2 or more).\n"
            "Poles with counts: %d   visible: %d   mean per pole: %.1f (guide 12-13)   max: %d\n"
            "Red disc = more than %d drops on the pole. Skipped drops (empty / multipart): %d%s"
            % (len(counts), self.view.get("visible", 0), mean, max(counts) if counts else 0, self.sts_max(),
               self.skipped, "\nCounts may be stale - use Recount now." if self.stale else ""))

    @guarded("{key}.paint")
    def _paint(self, painter):
        near = self.host.cursor_clear() if hasattr(self.host, "cursor_clear") else None
        for p, img, _c, x, y in self._draw:
            if near is not None and abs(x - near[0]) < EDIT_CLEAR_PX and abs(y - near[1]) < EDIT_CLEAR_PX:
                continue   # never a number where the user is about to snap
            painter.drawImage(p, img)
        self._paint_chip(painter)

    def status_text(self):
        if not self.active:
            return "Drops meeting at each pole"
        if not self.layers:
            return "No drop layer in this project"
        hubs = self.hubs.hubs(2)
        counts = [c for _p, c in hubs]
        mx = self.sts_max()
        over = sum(1 for c in counts if c > mx)
        mean = (sum(counts) / float(len(counts))) if counts else 0.0
        return "%s poles · mean %.1f · %d poles over %d" % (format(len(counts), ","), mean, over, mx)

    def next_targets(self):
        mx = self.sts_max()
        out = []
        for pt, c in sorted(self.hubs.hubs(2), key=lambda h: -h[1]):
            if c > mx:
                out.append(("%d drops" % c, QgsRectangle(pt.x(), pt.y(), pt.x(), pt.y())))
        return out


class DropLengthTool(_DropView):
    """T6: every drop drawn over the map in green / orange / red by its true (WGS84) length."""

    title = "Drop lengths"
    key = "t6"
    uses_lengths = True
    z_value = 990

    def __init__(self, host):
        super().__init__(host)
        self.counts = {core.GREEN: 0, core.AMBER: 0, core.RED: 0}
        self._img = None
        self._labels = []
        self._label_rects = []
        self._tags = []   # (QRectF, text) red length tags, drawn by the controller's HUD
        self._drops_cache = None
        self._paths = {}
        self._arr = None
        self._arr_key = None

    def _selected_keys(self):
        """(layer index, fid) of every selected drop on the drop layer(s) - read-only."""
        out = set()
        for li, lyr in enumerate(self.layers):
            if lyr is not None and not sip.isdeleted(lyr):
                for fid in lyr.selectedFeatureIds():
                    out.add((li, fid))
        return out

    def _on(self):
        super()._on()
        self._sel_layers = []
        self._wire_selection()

    def _wire_selection(self):
        """Follow the drop layers' selection (re-wired when the engine's layer set changes)."""
        cur = [lyr for lyr in self.layers if lyr is not None and not sip.isdeleted(lyr)]
        old = getattr(self, "_sel_layers", [])
        if [id(x) for x in cur] == [id(x) for x in old]:
            return
        for lyr in old:
            self._disconnect_owner(lyr)
        for lyr in cur:   # selection changes redraw the yellow at once
            self._connect(lyr, "selectionChanged", self._on_selection)
        self._sel_layers = cur

    @guarded("{key}.selectionChanged")
    def _on_selection(self, *args):
        self._recompute_view()

    def thresholds(self):
        o = _float(_setting("len_orange", core.LEN_ORANGE_M), core.LEN_ORANGE_M)
        r = _float(_setting("len_red", core.LEN_RED_M), core.LEN_RED_M)
        return o, r

    @property
    def drops(self):
        """(li, fid) -> (metres, band, vertex arrays). Cached until the engine or the thresholds change."""
        if self._drops_cache is None:
            o, r = self.thresholds()
            self._drops_cache = {k: (m, core.length_band(m, o, r), parts)
                                 for k, (m, parts) in self.engine.lengths.items()}
            c = {core.GREEN: 0, core.AMBER: 0, core.RED: 0}
            for _m, band, _p in self._drops_cache.values():
                c[band] += 1
            self.counts = c
        return self._drops_cache

    def invalidate_bands(self):
        self._drops_cache = None

    def band_of(self, li, fid):
        v = self.drops.get((li, fid))
        return v[1] if v else None

    def _clear_view(self):
        self._img = None
        self._labels = []
        self._paths = {}

    @guarded("{key}.engineChanged")
    def _on_engine_changed(self, *args):
        self._drops_cache = None
        self._wire_selection()
        self._recompute_view()

    def _geom_arrays(self, xf):
        """Flat vertex arrays for every drop part, cached per engine state + view CRS:
        verts (M, 2) in the VIEW CRS, offs (P+1), owner (P) -> drop index, part bbox (P, 4),
        and per-drop metres / band arrays aligned with self._keys."""
        key = (id(self.engine.lengths), len(self.engine.lengths), self.engine.full_recounts,
               self.engine.incremental_updates, self.thresholds(),
               None if not xf else xf.destinationCrs().authid())
        if getattr(self, "_arr_key", None) == key and self._arr is not None:
            return self._arr
        drops = self.drops
        keys = list(drops.keys())
        parts, owner, lens, bands = [], [], [], []
        for i, k in enumerate(keys):
            m, band, prts = drops[k]
            lens.append(m)
            bands.append(band)
            for p in prts:
                parts.append(_np.asarray(p, dtype=float))
                owner.append(i)
        if not parts:
            self._arr = None
            self._arr_key = key
            return None
        sizes = _np.array([len(p) for p in parts])
        offs = _np.concatenate([[0], _np.cumsum(sizes)])
        verts = _np.concatenate(parts)
        if xf:
            pts = [QgsPointXY(float(x), float(y)) for x, y in verts.tolist()]
            out = _batch_transform(xf, pts)
            verts = _np.array([(q.x(), q.y()) for q in out], dtype=float)
        starts = offs[:-1]
        bbox = _np.stack([_np.minimum.reduceat(verts[:, 0], starts), _np.minimum.reduceat(verts[:, 1], starts),
                          _np.maximum.reduceat(verts[:, 0], starts), _np.maximum.reduceat(verts[:, 1], starts)], axis=1)
        self._arr = {"keys": keys, "verts": verts, "offs": offs, "owner": _np.array(owner), "bbox": bbox,
                     "lens": _np.array(lens), "bands": bands}
        self._arr_key = key
        return self._arr

    @guarded("{key}.view")
    def _recompute_view(self):
        if self.item is None:
            return
        self._prep_item()
        self._img, self._labels, self._chip = None, [], None
        self.view = {"visible": 0, "drawn": 0, "green_hidden": False}
        if not self.layers or self.n_drops == 0:
            self._chip = "Drop lengths: no drops" if self.layers else "Drop lengths: no drop layer"
        elif _np is None:
            self._recompute_view_slow()
            return
        else:
            if self.stale:
                self._chip = "Drop colours may be stale - Recount now in the Span Inspector"
            xf = self._main_to_view()
            arr = self._geom_arrays(xf)
            if arr is not None:
                ext = self.canvas.extent()
                ext.scale(1.1)
                bb = arr["bbox"]
                vis = ~((bb[:, 2] < ext.xMinimum()) | (bb[:, 0] > ext.xMaximum()) |
                        (bb[:, 3] < ext.yMinimum()) | (bb[:, 1] > ext.yMaximum()))
                vis_parts = _np.nonzero(vis)[0]
                owners = arr["owner"][vis_parts]
                bands = arr["bands"]
                vis_drops = set(owners.tolist())
                n_green = sum(1 for i in vis_drops if bands[i] == core.GREEN)
                skip_green = n_green > MAX_GREEN_DRAWN
                if skip_green:
                    self._chip = "Zoom in to see green drops (%d orange, %d red shown)" % (
                        sum(1 for i in vis_drops if bands[i] == core.AMBER),
                        sum(1 for i in vis_drops if bands[i] == core.RED))
                ct = self.canvas.getCoordinateTransform()
                a, b, c, d, e, f = _affine(ct)
                V = arr["verts"]
                pxs = (a * V[:, 0] + b * V[:, 1] + c).tolist()
                pys = (d * V[:, 0] + e * V[:, 1] + f).tolist()
                offs = arr["offs"].tolist()
                mpp = self._mpp()
                label_red = mpp <= MPP_GATE
                polys = {core.GREEN: [], core.AMBER: [], core.RED: [], SEL: []}
                sel = self._selected_keys()
                keys = arr["keys"]
                drawn_drops = set()
                ends = {}
                if label_red:   # how many drawn drops end at each 3 px cell: the busiest end is the pole
                    for j in vis_parts.tolist():
                        for k in (offs[j], offs[j + 1] - 1):
                            cell = (int(pxs[k] // 3), int(pys[k] // 3))
                            ends[cell] = ends.get(cell, 0) + 1
                for j, i in zip(vis_parts.tolist(), owners.tolist()):
                    band = bands[i]
                    selected = bool(sel) and keys[i] in sel
                    if skip_green and band == core.GREEN and not selected:
                        continue
                    s0, s1 = offs[j], offs[j + 1]
                    poly = QPolygonF([QPointF(x, y) for x, y in zip(pxs[s0:s1], pys[s0:s1])])
                    polys[SEL if selected else band].append(poly)
                    drawn_drops.add(i)
                    if band == core.RED and label_red and s1 - s0 >= 2:
                        xs, ys = pxs[s0:s1], pys[s0:s1]
                        n0 = ends.get((int(xs[0] // 3), int(ys[0] // 3)), 0)
                        n1 = ends.get((int(xs[-1] // 3), int(ys[-1] // 3)), 0)
                        if n1 > n0:
                            xs, ys = xs[::-1], ys[::-1]
                        dx, dy = xs[-1] - xs[-2], ys[-1] - ys[-2]
                        dl = math.hypot(dx, dy) or 1.0
                        self._labels.append((QPointF(xs[-1], ys[-1]), "%.1f m" % float(arr["lens"][i]),
                                             (dx / dl, dy / dl)))
                self.view = {"visible": len(vis_drops), "drawn": len(drawn_drops), "green_hidden": skip_green,
                             "mpp": mpp}
                self._render_cache(polys)
        self._update_tooltip(None)
        self.item.update()
        self.host.notify(self)

    def _recompute_view_slow(self):
        """numpy-free fallback: same picture, per-drop Python maths."""
        drops = self.drops
        xf = self._main_to_view()
        ct = self.canvas.getCoordinateTransform()
        a, b, c, d, e, f = _affine(ct)
        polys = {core.GREEN: [], core.AMBER: [], core.RED: [], SEL: []}
        sel = self._selected_keys()
        for k, (m, band, parts) in drops.items():
            for part in parts:
                pts = self._to_view_crs(part, xf) if xf else part
                polys[SEL if k in sel else band].append(
                    QPolygonF([QPointF(a * x + b * y + c, d * x + e * y + f) for x, y in pts]))
        self.view = {"visible": len(drops), "drawn": len(drops), "green_hidden": False}
        self._render_cache(polys)
        self._update_tooltip(None)
        self.item.update()
        self.host.notify(self)

    @staticmethod
    def _to_view_crs(part, xf):
        pts = [QgsPointXY(float(x), float(y)) for x, y in (part.tolist() if hasattr(part, "tolist") else part)]
        out = _batch_transform(xf, pts)
        return [(p.x(), p.y()) for p in out]

    def _render_cache(self, polys):
        """Cased coloured lines + red length labels, drawn once per pan / zoom into an image."""
        self._img = None
        if not any(polys.values()):
            return
        vpw = self.canvas.viewport()
        dpr = vpw.devicePixelRatioF()
        w, h = vpw.width() + 100, vpw.height() + 100
        img = QImage(int(w * dpr), int(h * dpr), QImage.Format.Format_ARGB32_Premultiplied)
        img.setDevicePixelRatio(dpr)
        img.fill(Qt.GlobalColor.transparent)
        p = QPainter(img)
        try:
            p.translate(50, 50)   # the item's bounding rect starts at (-50, -50)
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            p.setBrush(Qt.BrushStyle.NoBrush)
            n_lines = sum(len(v) for v in polys.values())
            mpp = self._mpp()
            zk = 1.0 if mpp <= 0.35 else max(0.45, 0.35 / mpp)   # width scale when zoomed out
            for band in (core.GREEN, core.AMBER, core.RED):   # red last = on top
                pl = polys.get(band) or []
                if not pl:
                    continue
                lw = max(1.2, LENGTH_WIDTHS.get(band, 3.0) * zk)
                fade = getattr(self, "_edit_fade", False)
                if n_lines <= CASING_MAX and mpp <= MPP_GATE and not fade:   # zoomed in: casing keeps colours readable
                    p.setPen(QPen(QColor(11, 16, 24, 150), lw + 2.4, Qt.PenStyle.SolidLine,
                                  Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
                    for poly in pl:
                        p.drawPolyline(poly)
                col = QColor(LENGTH_COLOURS[band])
                if fade:
                    col.setAlpha(int(255 * EDIT_OPACITY))   # editing: colours step back
                if mpp > MPP_GATE and band != core.RED:
                    lw = max(1.2, lw * 0.6)   # town zoom: green / orange step back (thinner), red stays bold
                elif band == core.RED:
                    lw = max(2.5, lw)
                p.setPen(QPen(col, lw, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
                for poly in pl:
                    p.drawPolyline(poly)
            selp = polys.get(SEL) or []
            if selp:   # selected drops: yellow over everything the tool draws (QGIS's own yellow is under it)
                lw = max(3.0, LENGTH_WIDTHS[core.RED] * zk)
                p.setPen(QPen(QColor(11, 16, 24, 200), lw + 3.0, Qt.PenStyle.SolidLine,
                              Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
                for poly in selp:
                    p.drawPolyline(poly)
                p.setPen(QPen(QColor(SELECTED_YELLOW), lw, Qt.PenStyle.SolidLine,
                              Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
                for poly in selp:
                    p.drawPolyline(poly)
            if self._labels:
                font = QFont()
                font.setBold(True)
                font.setPointSizeF(9.5)
                p.setFont(font)
                fm = QFontMetricsF(font)
                tags = []
                placed = list(self.host.reserved_rects()) if hasattr(self.host, "reserved_rects") else []
                n_reserved = len(placed)
                W, H = self.canvas.viewport().width(), self.canvas.viewport().height()
                # longest first. Each tag sits just past the FAR end of its own drop, pushed out
                # along the line (so a fan of red drops gets a fan of tags, one per line); then the
                # four corners around that end; skipped only if all collide (still red + in Next)
                for end, text, (ux, uy) in sorted(self._labels, key=lambda lt: -float(lt[1].split()[0])):
                    tw, th = fm.horizontalAdvance(text) + 10, fm.height() + 3
                    gap = 7.0 + 0.5 * abs(ux) * tw + 0.5 * abs(uy) * th
                    cx, cy = end.x() + ux * gap, end.y() + uy * gap
                    r = None
                    for ox, oy in ((-tw / 2, -th / 2), (6, -th - 6), (6, 6), (-tw - 6, -th - 6), (-tw - 6, 6)):
                        base = (cx, cy) if (ox, oy) == (-tw / 2, -th / 2) else (end.x(), end.y())
                        cand = QRectF(base[0] + ox, base[1] + oy, tw, th)
                        if cand.left() < 4 or cand.top() < 4 or cand.right() > W - 4 or cand.bottom() > H - 4:
                            continue   # a tag is never cut by the canvas edge
                        if not any(cand.adjusted(-2, -2, 2, 2).intersects(q) for q in placed):
                            r = cand
                            break
                    if r is None:
                        continue
                    placed.append(r)
                    tags.append((r, text))
            self._label_rects = list(placed[n_reserved:]) if self._labels else []
            self._tags = tags if self._labels else []
        finally:
            p.end()
        self._img = img

    def _update_tooltip(self, _hubs):
        if self.action is None or sip.isdeleted(self.action):
            return
        o, r = self.thresholds()
        longest = max((v[0] for v in self.drops.values()), default=0.0)
        self.action.setToolTip(
            "Drop lengths: every drop coloured by its true length.\n"
            "Green under %g m: %d   Orange %g-%g m: %d   Red over %g m: %d   Longest: %.1f m\n"
            "Skipped (empty geometry): %d%s"
            % (o, self.counts[core.GREEN], o, r, self.counts[core.AMBER], r, self.counts[core.RED], longest,
               self.skipped, "\nColours may be stale - use Recount now." if self.stale else ""))

    @guarded("{key}.paint")
    def _paint(self, painter):
        if self._img is not None:
            painter.drawImage(QPointF(-50, -50), self._img)
        self._paint_chip(painter)   # legend + hints: controller HUD

    def status_text(self):
        if not self.active:
            return "Every drop coloured by its true length"
        if not self.layers:
            return "No drop layer in this project"
        self.drops
        c = self.counts
        return "%s red · %s orange · %s green" % (format(c[core.RED], ","), format(c[core.AMBER], ","),
                                                  format(c[core.GREEN], ","))

    def next_targets(self):
        out = []
        for (li, fid), (m, band, parts) in sorted(self.drops.items(), key=lambda kv: -kv[1][0]):
            if band != core.RED:
                continue
            p = parts[0]
            if _np is not None:
                rect = QgsRectangle(float(p[:, 0].min()), float(p[:, 1].min()), float(p[:, 0].max()), float(p[:, 1].max()))
            else:
                xs, ys = [q[0] for q in p], [q[1] for q in p]
                rect = QgsRectangle(min(xs), min(ys), max(xs), max(ys))
            out.append(("%.1f m" % m, rect))
        return out


class PonGroupsTool(_DropView):
    """T7 (D19): a blue number in the middle of every PON = the drop groups (hubs of 2+ drops,
    the same hubs the Drop counter numbers) inside it. Over the per-PON limit: red ring."""

    title = "PON groups"
    key = "t7"
    uses_hubs = True
    z_value = 1005

    def __init__(self, host):
        super().__init__(host)
        self.pon_layer = None
        self._pons = []          # [(fid, QgsGeometry in the PON crs, prepared engine, QgsPointXY label, bbox)]
        self.counts = {}         # fid -> groups
        self.outside = 0
        self._draw = []
        self._pon_timer = None
        self._pon_xf = None      # drop main CRS -> PON CRS
        self.pon_recomputes = 0

    @property
    def hubs(self):
        return self.engine.hubs

    def limit(self):
        return max(1, int(_float(_setting("pon_group_limit", PON_GROUP_LIMIT_DEFAULT), PON_GROUP_LIMIT_DEFAULT)))

    def find_pon_layer(self):
        proj = QgsProject.instance()
        lid = str(_setting("pon_layer_id", "") or "")
        lyr = proj.mapLayer(lid) if lid else None
        if isinstance(lyr, QgsVectorLayer) and lyr.geometryType() == Qgis.GeometryType.Polygon:
            return lyr
        cands = [x for x in proj.mapLayers().values()
                 if isinstance(x, QgsVectorLayer) and x.geometryType() == Qgis.GeometryType.Polygon
                 and "pon" in x.name().lower()]
        return max(cands, key=lambda x: x.featureCount()) if cands else None

    def _on(self):
        self.pon_layer = self.find_pon_layer()
        self._pon_timer = QTimer()
        self._pon_timer.setSingleShot(True)
        self._pon_timer.setInterval(DEBOUNCE_MS)
        self._connect(self._pon_timer, "timeout", self._on_pon_timer)
        if self.pon_layer is not None:
            for sig in ("geometryChanged", "featureAdded", "featureDeleted", "afterCommitChanges",
                        "afterRollBack", "dataChanged"):
                self._connect(self.pon_layer, sig, self._on_pon_edit)
            self._connect(QgsProject.instance(), "layersWillBeRemoved", self._on_layers_removed_pon)
        self._load_pons()
        super()._on()

    def _off(self):
        def stop():
            t, self._pon_timer = self._pon_timer, None
            if t is not None and not sip.isdeleted(t):
                t.stop()
        _best_effort(stop)
        super()._off()

    def _clear_view(self):
        self._draw = []

    def _on_pon_edit(self, *args):
        self._pon_edited()

    @guarded("{key}.ponEdit")
    def _pon_edited(self):
        if self._pon_timer is not None:
            self._pon_timer.start()

    @guarded("{key}.ponDebounce")
    def _on_pon_timer(self):
        self._load_pons()
        self._recompute_view()

    @guarded("{key}.layersWillBeRemoved")
    def _on_layers_removed_pon(self, ids):
        if self.pon_layer is not None and self.pon_layer.id() in set(ids):
            self._disconnect_owner(self.pon_layer)
            self.pon_layer = None
            self._pons = []
            self.counts = {}
            self._recompute_view()

    def _load_pons(self):
        self._pons = []
        self._pon_xf = None
        lyr = self.pon_layer
        if lyr is None:
            return
        req = QgsFeatureRequest().setNoAttributes()
        for f in lyr.getFeatures(req):
            g = f.geometry()
            if g is None or g.isNull() or g.isEmpty():
                continue
            g = QgsGeometry(g)
            eng = QgsGeometry.createGeometryEngine(g.constGet())
            eng.prepareGeometry()
            parts = g.asGeometryCollection() if g.isMultipart() else [g]
            big = max(parts, key=lambda pg: pg.area()) if parts else g
            lab = big.poleOfInaccessibility(max(big.boundingBox().width(), big.boundingBox().height()) / 200.0)
            lab = lab[0] if isinstance(lab, tuple) else lab
            self._pons.append((f.id(), g, eng, lab.asPoint(), g.boundingBox()))
        self._pons.sort(key=lambda t: t[0])
        self.pon_recomputes += 1

    def _assign(self):
        """groups per PON: each hub counts for the first PON (by fid) that contains its point."""
        self.counts = {t[0]: 0 for t in self._pons}
        self.outside = 0
        if not self._pons or not self.layers:
            return
        hubs = self.hubs.hubs(2)
        if not hubs:
            return
        if self._pon_xf is None:
            main = self.layers[0].crs()
            pc = self.pon_layer.crs()
            self._pon_xf = False if main == pc else QgsCoordinateTransform(main, pc, QgsProject.instance())
        pts = [pt for pt, _c in hubs]
        if self._pon_xf:
            pts = _batch_transform(self._pon_xf, pts)
        for pt in pts:
            x, y = pt.x(), pt.y()
            hit = None
            for fid, _g, eng, _lab, bb in self._pons:
                if bb.xMinimum() <= x <= bb.xMaximum() and bb.yMinimum() <= y <= bb.yMaximum():
                    if eng.intersects(QgsPoint(x, y)):
                        hit = fid
                        break
            if hit is None:
                self.outside += 1
            else:
                self.counts[hit] += 1

    def _image(self, n, over, dpr, scale=1.0):
        """Blue number on a white rounded tile (white number on a red tile when over the limit)."""
        k = (n, over, dpr, scale)
        img = self._img_cache.get(k)
        if img is not None:
            return img
        font = QFont()
        font.setBold(True)
        font.setPointSizeF(14.0 * scale)
        fm = QFontMetricsF(font)
        text = str(n)
        d = max(fm.height() + 10.0 * scale, fm.horizontalAdvance(text) + 18.0 * scale)
        size = d + 6.0
        img = QImage(int(math.ceil(size * dpr)), int(math.ceil(size * dpr)), QImage.Format.Format_ARGB32_Premultiplied)
        img.setDevicePixelRatio(dpr)
        img.fill(Qt.GlobalColor.transparent)
        p = QPainter(img)
        try:
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
            r = QRectF(3, 3, d, d)
            # square tile: PON groups (circles are drop counts). Over the limit the whole tile turns
            # red with a white number - a change of fill and lightness, not just of edge colour
            p.setPen(QPen(QColor("#FFFFFF") if over else QColor(PON_BLUE), 2.6))
            p.setBrush(QColor(NUMBER_RED) if over else QColor("#FFFFFF"))
            p.drawRoundedRect(r, d * 0.28, d * 0.28)
            p.setPen(QColor("#FFFFFF") if over else QColor(PON_BLUE))
            p.setFont(font)
            p.drawText(r, int(Qt.AlignmentFlag.AlignCenter), text)
        finally:
            p.end()
        self._img_cache[k] = img
        return img

    @guarded("{key}.view")
    def _recompute_view(self):
        if self.item is None:
            return
        self._prep_item()
        self._draw, self._chip = [], None
        self._assign()
        lim = self.limit()
        self.view = {"pons": len(self._pons), "over": sum(1 for n in self.counts.values() if n > lim),
                     "outside": self.outside, "drawn": 0}
        if self.pon_layer is None:
            self._chip = "PON groups: no PON layer"
        elif not self.layers:
            self._chip = "PON groups: no drop layer"
        else:
            dest = self.canvas.mapSettings().destinationCrs()
            xf = None if self.pon_layer.crs() == dest else QgsCoordinateTransform(
                self.pon_layer.crs(), dest, QgsProject.instance())
            ct = self.canvas.getCoordinateTransform()
            vp = self.canvas.viewport()
            W, H = vp.width(), vp.height()
            dpr = vp.devicePixelRatioF() or 1.0
            cands = []
            for fid, _g, _eng, lab, _bb in self._pons:
                n = self.counts.get(fid, 0)
                q = xf.transform(lab) if xf is not None else lab
                px = ct.transform(q)
                x, y = px.x(), px.y()
                if x < 0 or y < 0 or x > W or y > H:
                    continue   # the PON's middle is off screen
                cands.append((n > lim, n, x, y))
            placed, hidden = list(self.host.reserved_rects()), 0
            # over-limit first, then most groups: those win the space when PONs crowd together
            for over, n, x, y in sorted(cands, key=lambda c: (not c[0], -c[1])):
                spot = None
                img = self._image(n, over, dpr)
                iw, ih = img.width() / dpr, img.height() / dpr
                sx, sy = iw * 0.6 + 2, ih * 0.6 + 2
                for dx, dy in ((0, 0), (0, sy), (0, -sy), (sx, 0), (-sx, 0),
                               (sx, sy), (-sx, sy), (sx, -sy), (-sx, -sy),
                               (0, -2 * sy), (0, 2 * sy), (2 * sx, 0), (-2 * sx, 0)):
                    # clamp inside the view: a tile is never cut by the canvas edge
                    rx = min(max(x - iw / 2 + dx, 2.0), W - iw - 2.0)
                    ry = min(max(y - ih / 2 + dy, 2.0), H - ih - 2.0)
                    r = QRectF(rx, ry, iw, ih)
                    if not any(r.adjusted(-2, -2, 2, 2).intersects(o) for o in placed):
                        spot = (r, img)
                        break
                if spot is None:
                    hidden += 1   # no free room at this zoom; zoom in (or Next PON over limit)
                    continue
                placed.append(spot[0])
                self._draw.append((spot[0].topLeft(), spot[1], n, x, y))
            self.view["drawn"] = len(self._draw)
            self.view["hidden"] = hidden
            if hidden:
                self._chip = "%d PON number%s hidden in this view (no room) · zoom in" % (hidden, "" if hidden == 1 else "s")
        if self.action is not None and not sip.isdeleted(self.action):
            self.action.setToolTip("PON groups: drop groups (poles where 2+ drops meet) inside each PON.\n"
                                   "Red ring = more than %d groups. Groups outside any PON: %d" % (lim, self.outside))
        self.item.update()
        self.host.notify(self)

    @guarded("{key}.paint")
    def _paint(self, painter):
        near = self.host.cursor_clear() if hasattr(self.host, "cursor_clear") else None
        for p, img, _n, x, y in self._draw:
            if near is not None and abs(x - near[0]) < EDIT_CLEAR_PX and abs(y - near[1]) < EDIT_CLEAR_PX:
                continue
            painter.drawImage(p, img)
        self._paint_chip(painter)

    def status_text(self):
        if not self.active:
            return "Drop groups inside each PON (limit %d)" % self.limit()
        if self.pon_layer is None:
            return "No PON layer found · pick one in Settings"
        lim = self.limit()
        over = sum(1 for n in self.counts.values() if n > lim)
        return "%d PONs · %d PONs over %d groups · %d drop groups outside any PON" % (
            len(self._pons), over, lim, self.outside)

    def next_targets(self):
        lim = self.limit()
        out = []
        geoms = {t[0]: t[4] for t in self._pons}
        for fid, n in sorted(self.counts.items(), key=lambda kv: -kv[1]):
            if n > lim:
                out.append(("%d groups" % n, QgsRectangle(geoms[fid])))
        return out


class _HudItem(QgsMapCanvasItem):
    """Top-left column: one legend per live overlay, then each overlay's hint, stacked so they
    never cover each other. Drawn above every overlay."""

    def __init__(self, canvas, host):
        super().__init__(canvas)
        self._canvas, self._host = canvas, host
        self._r = QRectF()
        self.setZValue(1100)

    def updatePosition(self):
        try:
            self.setPos(0, 0)
        except Exception:  # noqa: BLE001 - never raise into Qt
            pass

    def refresh(self):
        vp = self._canvas.viewport()
        r = QRectF(0, 0, vp.width(), vp.height())
        if r != self._r:
            self.prepareGeometryChange()
            self._r = r
        self.update()

    def boundingRect(self):
        try:
            return QRectF(self._r)
        except Exception:  # noqa: BLE001 - never raise into Qt
            return QRectF()

    def paint(self, painter, option=None, widget=None):
        try:
            self._host._paint_hud(painter)
        except Exception:  # noqa: BLE001 - never raise into Qt from paint
            _log_quiet(traceback.format_exc())


class _LiveChipItem(QgsMapCanvasItem):
    """'Live tools on' chip, shown while any tool is on and the Span Inspector is hidden (D19 Q3)."""

    def __init__(self, canvas):
        super().__init__(canvas)
        self._canvas = canvas   # QgsMapCanvasItem has no public mapCanvas() in PyQGIS
        self.text = ""
        self._r = QRectF(0, 0, 1, 1)
        self.setZValue(1100)   # above every overlay

    def updatePosition(self):
        try:
            self.setPos(0, 0)
        except Exception:  # noqa: BLE001 - never raise into Qt
            pass

    def set_text(self, text):
        self.prepareGeometryChange()
        self.text = text
        f = QFont()
        f.setBold(True)
        f.setPointSizeF(9.0)
        fm = QFontMetricsF(f)
        c = self._canvas
        vp = c.viewport() if c is not None and not sip.isdeleted(c) else None
        h = vp.height() if vp is not None else 400
        self._r = QRectF(10, h - fm.height() - 22, fm.horizontalAdvance(text) + 20, fm.height() + 10)
        self.update()

    def boundingRect(self):
        try:
            return QRectF(self._r)
        except Exception:  # noqa: BLE001 - never raise into Qt
            return QRectF()

    def paint(self, painter, option=None, widget=None):
        try:
            if self.text:
                _chip_rect(painter, self.text, self._r.x(), self._r.y(), edge="#1AE5FF")
        except Exception:
            QgsMessageLog.logMessage(traceback.format_exc(), LOG_TAG, Qgis.MessageLevel.Warning)


class _VertexItem(QgsMapCanvasItem):
    """Vertex measure graphics (canvas CRS points, drawn in view px): the two vertices of the segment,
    ticks every step metres from the previous vertex, the snapped mouse point, and while a vertex is
    dragged a ring at step metres round the previous vertex."""

    def __init__(self, canvas):
        super().__init__(canvas)
        self._canvas = canvas
        self.prev = self.nxt = self.snap = None
        self.ticks = []          # [(QgsPointXY, metres, is_next)]
        self.ring = None         # (centre QgsPointXY, radius px)
        self.ray = False         # draw prev -> nxt as a dashed guide (forward from the selected vertex)
        self.ring_m = 0.0        # the ring's radius in metres (for its label)
        self.colour = QColor(CHIP_TEXT)
        self._r = QRectF()
        self.setZValue(1020)     # over every live overlay: this is what the hand is doing

    def updatePosition(self):
        try:
            self.setPos(0, 0)
        except Exception:  # noqa: BLE001 - never raise into Qt
            pass

    def set_state(self, prev, nxt, snap, ticks, ring, colour, ray=False, ring_m=0.0):
        vp = self._canvas.viewport()
        r = QRectF(0, 0, vp.width(), vp.height()) if snap is not None else QRectF()
        if r != self._r:
            self.prepareGeometryChange()
            self._r = r
        self.prev, self.nxt, self.snap, self.ticks, self.ring = prev, nxt, snap, list(ticks), ring
        self.ray = bool(ray)
        self.ring_m = ring_m
        self.colour = QColor(colour)
        self.update()

    def boundingRect(self):
        try:
            return QRectF(self._r)
        except Exception:  # noqa: BLE001 - never raise into Qt
            return QRectF()

    def paint(self, painter, option=None, widget=None):
        try:
            if self.snap is None:
                return
            ct = self._canvas.getCoordinateTransform()

            def px(p):
                q = ct.transform(p)
                return QPointF(q.x(), q.y())
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            dark = QColor(7, 11, 18, 225)
            mark, on = QColor(VM_MARK), QColor(VM_ON)
            if self.ring is not None:
                c, rad = self.ring
                cc = px(c)
                fill = QColor(VM_MARK)
                fill.setAlpha(12)
                painter.setBrush(fill)
                painter.setPen(QPen(dark, 3.5, Qt.PenStyle.DashLine))
                painter.drawEllipse(cc, rad, rad)
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.setPen(QPen(mark, 1.6, Qt.PenStyle.DashLine))
                painter.drawEllipse(cc, rad, rad)
                if rad > 28:
                    _vm_pill(painter, "%g m" % self.ring_m, QPointF(cc.x(), cc.y() - rad), VM_MARK, small=True)
            if self.prev is not None and self.nxt is not None:
                a, b = px(self.prev), px(self.nxt)
                dx, dy = b.x() - a.x(), b.y() - a.y()
                n = math.hypot(dx, dy) or 1.0
                ux, uy = -dy / n, dx / n          # unit normal in view px
                if self.ray:
                    painter.setPen(QPen(dark, 3.5, Qt.PenStyle.DashLine, Qt.PenCapStyle.RoundCap))
                    painter.drawLine(a, b)
                    painter.setPen(QPen(QColor(CHIP_TEXT), 1.6, Qt.PenStyle.DashLine, Qt.PenCapStyle.RoundCap))
                    painter.drawLine(a, b)
                for p, m, is_next, is_on in self.ticks:
                    c = px(p)
                    col = on if is_on else (mark if is_next else QColor(CHIP_TEXT))
                    half = 12.0 if (is_next or is_on) else 7.0
                    p1 = QPointF(c.x() - ux * half, c.y() - uy * half)
                    p2 = QPointF(c.x() + ux * half, c.y() + uy * half)
                    if is_next or is_on:                          # soft glow behind the mark to aim for
                        glow = QColor(col)
                        glow.setAlpha(70)
                        painter.setPen(QPen(glow, 11.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
                        painter.drawLine(p1, p2)
                    painter.setPen(QPen(dark, 5.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
                    painter.drawLine(p1, p2)
                    painter.setPen(QPen(col, 2.6, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
                    painter.drawLine(p1, p2)
                    if is_on:
                        painter.setPen(QPen(dark, 1.5))
                        painter.setBrush(on)
                        painter.drawEllipse(c, 4.5, 4.5)
                        painter.setBrush(Qt.BrushStyle.NoBrush)
                    side = 1.0 if uy <= 0 else -1.0               # put labels on the upper side of the line
                    lp = QPointF(c.x() + ux * (half + 13) * side, c.y() + uy * (half + 13) * side)
                    _vm_pill(painter, "%g m" % round(m), lp, VM_ON if is_on else (VM_MARK if is_next else None),
                             small=not (is_next or is_on))
                painter.setPen(QPen(dark, 1.5))
                painter.setBrush(QColor(CHIP_TEXT))
                for v in ((a,) if self.ray else (a, b)):
                    painter.drawRect(QRectF(v.x() - 4, v.y() - 4, 8, 8))     # vertices as squares, like QGIS
            s_ = px(self.snap)
            painter.setBrush(QColor(255, 255, 255, 235))
            painter.setPen(QPen(dark, 1.5))
            painter.drawEllipse(s_, 3.0, 3.0)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.setPen(QPen(dark, 4.5))
            painter.drawEllipse(s_, 8.0, 8.0)
            painter.setPen(QPen(self.colour, 2.2))
            painter.drawEllipse(s_, 8.0, 8.0)
        except Exception:  # noqa: BLE001 - never raise into Qt from paint
            _log_quiet(traceback.format_exc())


VM_MARK = "#FFD60A"      # the next mark to aim for
VM_ON = "#4ADE80"        # the mouse is on a mark: click here
VM_ON_M = 1.0            # within this many metres of a mark counts as "on it"


def _vm_pill(painter, text, centre, colour=None, small=False):
    """A rounded dark pill with a coloured edge, centred on a view point (tick and ring labels)."""
    f = QFont("Consolas")
    f.setFamilies(["Consolas", "JetBrains Mono", "DejaVu Sans Mono", "Courier New"])
    f.setBold(True)
    f.setPointSizeF(7.5 if small else 8.5)
    painter.setFont(f)
    fm = QFontMetricsF(f)
    w, h = fm.horizontalAdvance(text) + 14, fm.height() + 4
    r = QRectF(centre.x() - w / 2, centre.y() - h / 2, w, h)
    edge = QColor(colour) if colour else QColor("#33445E")
    painter.setPen(QPen(edge, 1.4 if colour else 1.0))
    painter.setBrush(QColor(7, 11, 18, 230))
    painter.drawRoundedRect(r, h / 2, h / 2)
    painter.setPen(QColor(colour) if colour else QColor(CHIP_MUTED))
    painter.drawText(r, int(Qt.AlignmentFlag.AlignCenter), text)


class VertexMeasureTool(_Tool):
    """T8 (JJ 2026-10-06): while the QGIS Vertex tool is active, the metres from the previous vertex to
    the mouse (snapped onto the active line layer) and on to the next vertex, with ticks every <step> m
    from the previous vertex so a vertex can be dropped at exactly 50 / 70 m. While a vertex is dragged:
    metres to both neighbours and a ring at <step> m round the previous one. Read-only."""

    title = "Vertex measure"
    key = "t8"
    SNAP_PX = 14

    def __init__(self, host):
        super().__init__(host)
        self.label = None
        self.item = None
        self._das = {}
        self._drag = None        # (layer id, prev QgsPointXY|None, next QgsPointXY|None) in layer CRS
        self._anchor = None      # (layer id, vertex QgsPointXY) - the vertex last clicked (QGIS keeps it selected)
        self._cursor = None
        self.last = None         # last readout (tests)

    # options -------------------------------------------------------------
    def step(self):
        return min(1000.0, max(1.0, _float(_setting("vertex_step", 50.0), 50.0)))

    def limit_for(self, layer):
        ov = _setting("span_limit", "auto")
        ov = None if str(ov) == "auto" else _float(ov, None)
        return core.limit_for_layer(layer.name() if layer is not None else "", ov)

    @staticmethod
    def is_vertex_tool(iface, tool):
        if tool is None or sip.isdeleted(tool):
            return False
        try:
            for name in ("actionVertexTool", "actionVertexToolActiveLayer"):
                act = getattr(iface, name, lambda: None)()
                if act is not None and tool.action() is act:
                    return True
        except Exception:  # noqa: BLE001
            pass
        try:
            return (isinstance(tool, QgsMapToolAdvancedDigitizing) and not isinstance(tool, QgsMapToolCapture)
                    and "vertex" in (tool.toolName() or "").lower())
        except Exception:  # noqa: BLE001
            return False

    # on / off ------------------------------------------------------------
    def _on(self):
        vp = self.canvas.viewport()
        if self.label is None or sip.isdeleted(self.label):
            self.label = _make_label(vp)
            self.label.setObjectName("vm_label_" + self.key)
        vp.installEventFilter(self)
        self._filter_on = True
        self._connect(self.canvas, "mapToolSet", self._on_tool_set)

    def _off(self):
        def unfilter():
            vp = self.canvas.viewport()
            if getattr(self, "_filter_on", False) and not sip.isdeleted(vp):
                vp.removeEventFilter(self)
            self._filter_on = False

        def drop_item():
            item, self.item = self.item, None
            if item is not None:
                sc = item.scene()
                if sc is not None:
                    sc.removeItem(item)
        _best_effort(unfilter, self._hide, drop_item)

    def destroy(self):
        self.switch_off()
        if self.label is not None and not sip.isdeleted(self.label):
            self.label.deleteLater()
        self.label = None

    def _hide(self, keep_anchor=False):
        self._drag = None
        if not keep_anchor:
            self._anchor = None
        self.last = None
        if self.label is not None and not sip.isdeleted(self.label):
            self.label.hide()
        if self.item is not None:
            self.item.set_state(None, None, None, [], None, CHIP_TEXT)

    # helpers ---------------------------------------------------------------
    def _da(self, crs):
        key = crs.authid() or crs.toWkt()
        da = self._das.get(key)
        if da is None:
            da = core.make_distance_area(crs)
            self._das[key] = da
        return da

    def _layer(self):
        lyr = self.host.iface.activeLayer()
        if isinstance(lyr, QgsVectorLayer) and lyr.isValid() and lyr.geometryType() == Qgis.GeometryType.Line:
            return lyr
        return None

    def _xforms(self, lyr):
        dest = self.canvas.mapSettings().destinationCrs()
        if lyr.crs() == dest:
            return None, None
        return (QgsCoordinateTransform(dest, lyr.crs(), QgsProject.instance()),
                QgsCoordinateTransform(lyr.crs(), dest, QgsProject.instance()))

    def _map_pt(self, pos):
        return self.canvas.getCoordinateTransform().toMapCoordinates(int(pos.x()), int(pos.y()))

    def _search(self, lyr, pos):
        """Search rectangle (layer CRS) round the mouse, the mouse point (layer CRS) and the tolerance."""
        to_l, _back = self._xforms(lyr)
        p_map = self._map_pt(pos)
        tol = self.SNAP_PX * self.canvas.mapUnitsPerPixel()
        rect = QgsRectangle(p_map.x() - tol, p_map.y() - tol, p_map.x() + tol, p_map.y() + tol)
        if to_l is not None:
            rect = to_l.transformBoundingBox(rect)
        p = to_l.transform(p_map) if to_l is not None else QgsPointXY(p_map)
        return rect, p, max(rect.width(), rect.height()) / 2.0

    # Qt entry points -------------------------------------------------------
    @guarded("{key}.toolset")
    def _on_tool_set(self, new_tool, *args):
        self._hide()

    @guarded("{key}.eventFilter", False)
    def eventFilter(self, obj, event):  # noqa: N802 - Qt name
        et = event.type()
        if et == QEvent.Type.KeyPress and event.key() == Qt.Key.Key_Escape:
            self._hide()            # Esc: forget the selected vertex, like QGIS does
            return False
        if et in (QEvent.Type.MouseMove, QEvent.Type.MouseButtonPress, QEvent.Type.MouseButtonRelease):
            pos = event.position() if hasattr(event, "position") else QPointF(event.pos())
            self._cursor = QPoint(int(pos.x()), int(pos.y()))
            if not self.is_vertex_tool(self.host.iface, self.canvas.mapTool()):
                if self.last is not None:
                    self._hide()
                return False
            if et == QEvent.Type.MouseButtonPress and event.button() == Qt.MouseButton.LeftButton:
                self._pick_drag(pos)
            elif et == QEvent.Type.MouseButtonRelease:
                self._drag = None
            self._update(pos)
        elif et == QEvent.Type.Leave:
            self._hide(keep_anchor=True)
        return False

    # measuring -------------------------------------------------------------
    def _pick_drag(self, pos):
        """Mouse down on a vertex: remember its neighbours (the Vertex tool is about to drag it)."""
        self._drag = None
        lyr = self._layer()
        if lyr is None:
            return
        rect, p, tol_l = self._search(lyr, pos)
        best = None
        req = QgsFeatureRequest().setFilterRect(rect).setNoAttributes().setLimit(50)
        for f in lyr.getFeatures(req):
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            _vpt, at, before, after, d2 = g.closestVertex(p)
            if at >= 0 and d2 <= tol_l * tol_l and (best is None or d2 < best[0]):
                prev = QgsPointXY(g.vertexAt(before)) if before >= 0 else None
                nxt = QgsPointXY(g.vertexAt(after)) if after >= 0 else None
                best = (d2, prev, nxt, QgsPointXY(g.vertexAt(at)))
        if best is not None:
            self._drag = (lyr.id(), best[1], best[2])
            self._anchor = (lyr.id(), best[3])      # stays after release: measure forward from it
        else:
            self._anchor = None                     # clicked away from any vertex

    def _update(self, pos):
        lyr = self._layer()
        if lyr is None:
            self._hide()
            return
        _to_l, back = self._xforms(lyr)
        da = self._da(lyr.crs())
        step = self.step()
        limit = self.limit_for(lyr)
        rect, p, tol_l = self._search(lyr, pos)

        def to_c(q):
            return back.transform(q) if back is not None else QgsPointXY(q)

        if self._drag is not None and self._drag[0] == lyr.id():
            _lid, prev, nxt = self._drag
            d_prev = da.measureLine(prev, p) if prev is not None else None
            d_next = da.measureLine(p, nxt) if nxt is not None else None
            ring = None
            if prev is not None and d_prev:
                pp = self.canvas.getCoordinateTransform().transform(to_c(prev))
                px_per_m = math.hypot(pos.x() - pp.x(), pos.y() - pp.y()) / d_prev
                ring = (to_c(prev), step * px_per_m)
            shown = d_prev if d_prev is not None else d_next
            colour = core.span_colour(shown, limit) if shown is not None else core.NEUTRAL
            self._draw(to_c(prev) if prev else None, to_c(nxt) if nxt else None, to_c(p), [], ring, colour,
                       ring_m=step)
            self._readout(d_prev, d_next, step, limit, colour, dragging=True)
            return

        best = None
        req = QgsFeatureRequest().setFilterRect(rect).setNoAttributes().setLimit(50)
        for f in lyr.getFeatures(req):
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            d2, snap, after, _side = g.closestSegmentWithContext(p)
            if after > 0 and d2 <= tol_l * tol_l and (best is None or d2 < best[0]):
                best = (d2, QgsPointXY(snap), QgsPointXY(g.vertexAt(after - 1)), QgsPointXY(g.vertexAt(after)))
        anc = self._anchor if (self._anchor is not None and self._anchor[0] == lyr.id()) else None
        if best is not None and anc is not None and best[1].distance(anc[1]) <= tol_l and p.distance(anc[1]) > tol_l:
            best = None      # sitting on the selected vertex and moving off it: measure forward, not along
        if best is None:
            if anc is not None:
                self._forward(anc[1], da, step, limit, p, to_c)
                return
            if self.last is not None:
                self._hide(keep_anchor=True)
            return
        _d2, snap, prev, nxt = best
        d_prev, d_next = da.measureLine(prev, snap), da.measureLine(snap, nxt)
        seg = d_prev + d_next
        ticks = []
        k = 1
        while k * step < seg - 0.01 and k <= 200:
            fr = (k * step) / seg
            q = QgsPointXY(prev.x() + (nxt.x() - prev.x()) * fr, prev.y() + (nxt.y() - prev.y()) * fr)
            ticks.append((to_c(q), k * step, (k - 1) * step <= d_prev + VM_ON_M < k * step,
                          abs(d_prev - k * step) <= VM_ON_M))
            k += 1
        colour = core.span_colour(d_prev, limit)
        self._draw(to_c(prev), to_c(nxt), to_c(snap), ticks, None, colour)
        self._readout(d_prev, d_next, step, limit, colour, dragging=False)

    def _forward(self, a, da, step, limit, p, to_c):
        """From the selected vertex a towards the mouse p: metres so far, ticks every step m along that
        direction (one beyond the mouse), and a ring at step m round the vertex."""
        d = da.measureLine(a, p)
        if d <= 0.05:
            self._hide(keep_anchor=True)
            return
        ticks = []
        k = 1
        while k <= 200 and k * step <= d + step:
            fr = (k * step) / d
            q = QgsPointXY(a.x() + (p.x() - a.x()) * fr, a.y() + (p.y() - a.y()) * fr)
            ticks.append((to_c(q), k * step, (k - 1) * step <= d + VM_ON_M < k * step, abs(d - k * step) <= VM_ON_M))
            k += 1
        far = ticks[-1][0] if ticks else to_c(p)
        ct = self.canvas.getCoordinateTransform()
        pa, pp = ct.transform(to_c(a)), ct.transform(to_c(p))
        ring = (to_c(a), step * math.hypot(pp.x() - pa.x(), pp.y() - pa.y()) / d)
        colour = core.span_colour(d, limit)
        self._draw(to_c(a), far, to_c(p), ticks, ring, colour, ray=True, ring_m=step)
        self.last = {"from_prev": None, "from_selected": d, "to_next": None, "step": step, "limit": limit,
                     "colour": colour, "dragging": False, "forward": True}
        self._card(d, "from selected vertex", None, step, limit, colour)

    def _label(self, html, colour):
        if self.label is None or sip.isdeleted(self.label):
            return
        if self.label.property("vm_colour") != colour:
            if colour == "on":
                _style_label(self.label, core.GREEN)
            else:
                _style_label(self.label, colour)
            self.label.setProperty("vm_colour", colour)
        self.label.setText(html)
        self.label.adjustSize()
        vp = self.canvas.viewport()
        cur = self._cursor or QPoint(0, 0)
        w, h = self.label.width(), self.label.height()
        # keep the card off the marks, the vertices and the guide line: try the four corners round the
        # mouse and take the one covering the fewest of them (then the one nearest the usual spot)
        ct = self.canvas.getCoordinateTransform()
        keep = []
        it = self.item
        if it is not None:
            for q in [tk[0] for tk in it.ticks] + [v for v in (it.prev, it.nxt) if v is not None]:
                v = ct.transform(q)
                keep.append(QRectF(v.x() - 34, v.y() - 30, 68, 60))
            if it.ring is not None:
                rc = ct.transform(it.ring[0])
                keep.append(QRectF(rc.x() - 40, rc.y() - it.ring[1] - 16, 80, 32))     # the ring's label
            if it.prev is not None and it.nxt is not None:
                a_, b_ = ct.transform(it.prev), ct.transform(it.nxt)
                for i in range(1, 12):
                    keep.append(QRectF(a_.x() + (b_.x() - a_.x()) * i / 12.0 - 6, a_.y() + (b_.y() - a_.y()) * i / 12.0 - 6,
                                       12, 12))
        best = None
        for n, (dx, dy) in enumerate(((22, 22), (22, -h - 22), (-w - 22, 22), (-w - 22, -h - 22))):
            x = min(max(0, cur.x() + dx), max(0, vp.width() - w))
            y = min(max(0, cur.y() + dy), max(0, vp.height() - h))
            r = QRectF(x, y, w, h)
            cover = sum((r & q).width() * (r & q).height() for q in keep if r.intersects(q))
            if best is None or (cover, n) < best[0]:
                best = ((cover, n), x, y)
        self.label.move(int(best[1]), int(best[2]))
        self.label.show()
        self.label.raise_()
        self.host.notify(self)

    def _draw(self, prev, nxt, snap, ticks, ring, colour, ray=False, ring_m=0.0):
        if self.item is None:
            self.item = _VertexItem(self.canvas)
        self.item.set_state(prev, nxt, snap, ticks, ring, COLOURS[colour], ray, ring_m)

    def _readout(self, d_prev, d_next, step, limit, colour, dragging):
        self.last = {"from_prev": d_prev, "to_next": d_next, "step": step, "limit": limit, "colour": colour,
                     "dragging": dragging}
        if d_prev is None and d_next is None:
            if self.label is not None and not sip.isdeleted(self.label):
                self.label.hide()
            return
        if d_prev is None:
            self._card(d_next, "to next vertex", None, step, limit, colour, marks=False)
        else:
            self._card(d_prev, "dragged vertex · from previous" if dragging else "along the line · from previous vertex",
                       d_next, step, limit, colour, marks=not dragging)

    def _card(self, d, caption, d_next, step, limit, colour, marks=True):
        """Two-line readout card: the number big, what it is measured from, then the next mark / limit."""
        on_mark = marks and abs(d - round(d / step) * step) <= VM_ON_M and round(d / step) >= 1
        big = VM_ON if on_mark else COLOURS[colour]
        head = ("<span style='color:%s;font-size:16px'>%.1f m</span>&nbsp;&nbsp;"
                "<span style='color:%s;font-size:10px;letter-spacing:1px'>%s</span>"
                % (big, d, CHIP_MUTED, caption.upper()))
        bits = []
        if on_mark:
            bits.append("<span style='color:%s'>ON THE %g m MARK - place the vertex here</span>"
                        % (VM_ON, round(d / step) * step))
        elif marks:
            nxt = math.floor((d + VM_ON_M) / step + 1) * step
            bits.append("<span style='color:%s'>next mark %g m</span> in %.1f m" % (VM_MARK, nxt, nxt - d))
        if d_next is not None:
            bits.append("%.1f m to next vertex" % d_next)
        if limit is not None:
            room = limit - d
            bits.append("<span style='color:%s'>%s</span>" % (
                COLOURS[colour], ("limit %g m · %.1f m left" % (limit, room)) if room >= 0
                else ("limit %g m · %.1f m OVER" % (limit, -room))))
        html = head + "<br><span style='color:%s;font-size:11px'>%s</span>" % (CHIP_MUTED, " &nbsp;·&nbsp; ".join(bits))
        if self.label is not None and not sip.isdeleted(self.label):
            if marks:          # progress to the next mark (green when on it)
                frac = 1.0 if on_mark else ((d % step) / step)
                self.label.bar = (frac, VM_ON if on_mark else VM_MARK, None)
            elif limit is not None:
                self.label.bar = (min(d / limit, 1.25) / 1.25, COLOURS[colour], 1.0 / 1.25)
            else:
                self.label.bar = None
        if self.last is not None:
            self.last["on_mark"] = on_mark
        self._label(html, "on" if on_mark else colour)

    def status_text(self):
        if not self.active:
            return "Marks every %g m while you use the Vertex tool" % self.step()
        last = self.last or {}
        if last.get("from_selected") is not None:
            return "%.1f m from selected vertex · marks every %g m" % (last["from_selected"], last["step"])
        if last.get("from_prev") is not None:
            return "%.1f m from previous vertex · marks every %g m" % (last["from_prev"], last["step"])
        return "Vertex tool: hover a line, or click a vertex and move off it (marks every %g m)" % self.step()


# ── controller (driven by the Span Inspector) ────────────────────────────
TOOL_KEYS = ("live", "group", "drops", "lengths", "pons", "vertex")
TOOL_NAMES = {"live": "Live Measure", "group": "Group counter", "drops": "Drop counter",
              "lengths": "Drop lengths", "pons": "PON groups", "vertex": "Vertex measure"}


class LiveTools(QObject):
    """No toolbar: one controller the Span Inspector drives. Each tool keeps one checkable
    QAction (the single source of truth for on/off); statusChanged(key) fires whenever a
    tool's numbers or state change."""

    statusChanged = pyqtSignal(str)

    def __init__(self, iface, toolbar_parent=None):
        super().__init__()
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.tools = {}
        self.actions = {}
        self.engine = None
        self.panel_visible = True
        self._chip = None
        self._hud = None
        self._hud_rects = []
        self._edit = False       # a QGIS edit tool is active
        self._cursor = None      # view px while editing (for the clearance around the cursor)
        self._watching = False
        self._next_idx = {}

    # compatibility alias for older tests
    @property
    def buttons(self):
        return self.actions

    def message(self, text):
        try:
            self.iface.messageBar().pushMessage(LOG_TAG, text, Qgis.MessageLevel.Warning, 10)
        except Exception:
            QgsMessageLog.logMessage(text, LOG_TAG, Qgis.MessageLevel.Warning)

    def build(self):
        cap = has_transient()
        self.engine = DropEngine(self)
        self.tools["live"] = LiveMeasureTool(self)
        self.tools["group"] = GroupCounterTool(self)
        self.tools["drops"] = DropCounterTool(self)
        self.tools["lengths"] = DropLengthTool(self)
        self.tools["pons"] = PonGroupsTool(self)
        self.tools["vertex"] = VertexMeasureTool(self)
        tips = {
            "live": ("Live Measure: segment and total metres while you draw. Colour = this segment vs the span "
                     "limit. Vertices are not poles - the colour is a span verdict only if you click once per "
                     "pole. In a 4326 project QGIS's d box is not true metres; this readout is."),
            "group": ("Group counter: points inside the polygon you are drawing, plus its area. Press Esc to "
                      "cancel - finishing the polygon adds a feature to the layer you are drawing on."),
            "drops": "Drop counter: number of drops meeting at each pole (2 or more).",
            "lengths": "Drop lengths: every drop coloured by its true length.",
            "pons": "PON groups: drop groups (poles where 2+ drops meet) inside each PON.",
            "vertex": ("Vertex measure: with the Vertex tool, metres from the previous vertex to the mouse "
                       "(snapped onto the active line layer) and to the next one, plus a tick every 50 m "
                       "(set the spacing) so you can drop a vertex exactly on it. Dragging a vertex shows a "
                       "ring at the spacing."),
        }
        for key in TOOL_KEYS:
            tool = self.tools[key]
            act = QAction(TOOL_NAMES[key], self)
            act.setCheckable(True)
            act.setChecked(False)
            act.setObjectName("vm_" + key)
            tip = tips[key]
            if key in ("live", "group") and not cap:
                act.setEnabled(False)
                tip = "Needs QGIS 4.0 or newer (QgsMapToolCapture.transientGeometryChanged).\n\n" + tip
            act.setToolTip(tip)
            act.toggled.connect(functools.partial(self._on_toggled, key))
            tool.action = act
            tool.ctrl_key = key
            self.actions[key] = act
        self._watching = True   # set first: teardown undoes whatever part of the hookup happened
        self.canvas.mapToolSet.connect(self._on_map_tool)
        self.canvas.viewport().installEventFilter(self)
        self._edit = self.is_edit_tool(self.canvas.mapTool())
        return self

    # editing: the overlays step back under QGIS's own edit graphics -------------
    @staticmethod
    def is_edit_tool(tool):
        """Vertex tool, add / move / rotate / reshape / split ... (QGIS marks them EditTool)."""
        if tool is None or sip.isdeleted(tool):
            return False
        try:
            if isinstance(tool, QgsMapToolAdvancedDigitizing):
                return True
            return bool(tool.flags() & QgsMapTool.Flag.EditTool)
        except Exception:  # noqa: BLE001
            return False

    def edit_style(self):
        v = str(_setting("edit_mode", "fade"))
        return v if v in EDIT_STYLES else "fade"

    def editing(self):
        """True while an edit tool is active and the style is not 'keep on top'."""
        return self._edit and self.edit_style() != "top"

    def cursor_clear(self):
        """(x, y) in view px to keep clear of numbers, or None."""
        if self.editing() and self.edit_style() == "fade" and self._cursor is not None:
            return self._cursor
        return None

    def style_item(self, view):
        """Apply the edit style to one overlay's canvas item (cheap; called on every recompute)."""
        item = getattr(view, "item", None)
        if item is None:
            return
        key = getattr(view, "ctrl_key", None)
        on, style = self.editing(), self.edit_style()
        item.setVisible(not (on and style == "hide"))
        if on and style == "fade":
            item.setZValue(EDIT_Z.get(key, -1))
            item.setOpacity(1.0 if key == "lengths" else EDIT_OPACITY)
        else:
            item.setZValue(view.z_value)
            item.setOpacity(1.0)

    def apply_edit_style(self):
        for key in ("drops", "lengths", "pons"):
            t = self.tools.get(key)
            if t is None:
                continue
            fade = self.editing() and self.edit_style() == "fade"
            changed = getattr(t, "_edit_fade", False) != fade
            t._edit_fade = fade
            if t.active and t.item is not None:
                self.style_item(t)
                if key == "lengths" and changed:
                    t._recompute_view()
                t.item.update()
        self._update_hud()
        if self._hud is not None:
            self._hud.update()

    @host_safe
    def _on_map_tool(self, new_tool, *args):
        self._edit = self.is_edit_tool(new_tool)
        if not self._edit:
            self._cursor = None
        self.apply_edit_style()

    def eventFilter(self, obj, event):  # noqa: N802 - Qt name
        try:
            if self._edit and event.type() == QEvent.Type.MouseMove:
                pos = event.position() if hasattr(event, "position") else event.pos()
                self._cursor = (pos.x(), pos.y())
                for key in ("drops", "pons"):
                    t = self.tools.get(key)
                    if t is not None and t.active and t.item is not None:
                        t.item.update()
            elif event.type() == QEvent.Type.Leave:
                self._cursor = None
        except Exception:  # noqa: BLE001 - never raise into Qt; never eat the event
            _log_quiet(traceback.format_exc())
        return False

    def notify(self, view):
        try:
            key = getattr(view, "ctrl_key", None)
            if key:
                self.statusChanged.emit(key)
            self._update_chip()
            self._update_hud()
        except Exception:
            QgsMessageLog.logMessage(traceback.format_exc(), LOG_TAG, Qgis.MessageLevel.Warning)

    def _on_toggled(self, key, on):
        tool = self.tools.get(key)
        if tool is None:
            return
        try:
            if "toggle." + tool.key in _INJECT:
                raise RuntimeError("injected fault: toggle." + tool.key)
            if on:
                tool.switch_on()
            else:
                tool.switch_off()
        except Exception:
            tool._fault("toggle")
        self.notify(tool)

    # panel API ------------------------------------------------------------
    def is_on(self, key):
        t = self.tools.get(key)
        return bool(t is not None and t.active)

    def set_on(self, key, on):
        a = self.actions.get(key)
        if a is not None and a.isEnabled() and a.isChecked() != bool(on):
            a.setChecked(bool(on))

    def status_text(self, key):
        t = self.tools.get(key)
        if t is None:
            return ""
        try:
            if key == "live":
                if not t.active:
                    return "Draw a line to see metres"
                last = t.last or {}
                if "segment" in last:
                    return "%.1f m · total %.1f m · %03.0f°" % (last["segment"], last["total"], last["bearing"])
                return "On - start drawing on an editable line layer"
            if key == "group":
                mode = t.mode()
                b = t.bands()
                ref = {"pon": "PON %d-%d" % (b["pon_low"], b["pon_high"]), "sts": "max %d per STS" % b["sts_max"],
                       "fts": "FTS max %d" % b["fts_max"]}[mode]
                last = t.last or {}
                if t.active and last.get("count") is not None:
                    return "%d inside · %s" % (last["count"], ref)
                return ("Draw an area to count homes · " if not t.active else "On · draw a polygon · ") + ref
            return t.status_text()
        except Exception:
            return ""

    def option(self, key, default=None):
        return _setting(key, default)

    @host_safe
    def set_option(self, key, value):
        _set_setting(key, value)
        if key in ("drop_layer_id", "include_spare", "join_radius"):
            self._relink_drops()
        elif key in ("len_orange", "len_red"):
            t = self.tools["lengths"]
            t.invalidate_bands()
            if t.active:
                t._recompute_view()
        elif key in ("mode", "point_layer_id", "sts_layer_id"):
            t = self.tools["group"]   # the counted layer is indexed at switch-on
            if t.active:
                t.switch_off()
                t.switch_on()
        elif key in ("pon_layer_id",):
            t = self.tools["pons"]
            if t.active:
                t.switch_off()
                t.switch_on()
        elif key in ("pon_group_limit",):
            t = self.tools["pons"]
            if t.active:
                t._recompute_view()
        elif key in ("edit_mode",):
            self.apply_edit_style()
        elif key in ("drop_max",):
            for k in ("drops", "pons"):
                if self.tools[k].active:
                    self.tools[k]._recompute_view()
        for k in TOOL_KEYS:
            self.notify(self.tools[k])

    def _set_choice(self, key, value, *args):
        try:
            if "menu.choice" in _INJECT:
                raise RuntimeError("injected fault: menu.choice")
            _set_setting(key, value)
        except Exception:
            QgsMessageLog.logMessage(traceback.format_exc(), LOG_TAG, Qgis.MessageLevel.Warning)
            self.message("That option could not be saved. Details are in the Log Messages panel.")

    def _relink_drops(self):
        on = [k for k in ("drops", "lengths", "pons") if self.tools[k].active]
        for k in on:
            self.tools[k].switch_off()
        for k in on:
            self.tools[k].switch_on()

    @host_safe
    def _recount(self, *args):
        if self.engine is not None:
            self.engine.recount_now()

    @host_safe
    def next_problem(self, key):
        """Zoom to the next problem of a tool. Returns (i, n) or (0, 0) when there is none."""
        t = self.tools.get(key)
        if t is None or not t.active:
            return (0, 0)
        targets = t.next_targets()
        n = len(targets)
        if n == 0:
            self._next_idx.pop(key, None)
            return (0, 0)
        # follow the last target by identity, not position: if it was fixed or deleted since the
        # last press, the next one has slid into its place and must not be skipped
        idents, seen = [], {}
        for lab, r in targets:   # (label, rect, occurrence): identical targets stay distinct
            k = (lab, r.toString(9))
            seen[k] = seen.get(k, 0) + 1
            idents.append(k + (seen[k],))
        last_i, last_id = self._next_idx.get(key, (-1, None))
        if last_id is not None and last_id in idents:
            i = (idents.index(last_id) + 1) % n
        elif last_id is not None:
            i = max(last_i, 0) % n
        else:
            i = 0
        self._next_idx[key] = (i, idents[i])
        _label, rect = targets[i]
        crs = t.pon_layer.crs() if key == "pons" and t.pon_layer is not None else t.layers[0].crs()
        dest = self.canvas.mapSettings().destinationCrs()
        r = QgsRectangle(rect)
        if crs != dest:
            r = QgsCoordinateTransform(crs, dest, QgsProject.instance()).transformBoundingBox(r)
        c = r.center()
        span = max(r.width(), r.height())
        if span <= 0:
            span = 0.0006 if dest.isGeographic() else 60.0
        half = span * (0.8 if key == "pons" else 1.6)
        self.canvas.setExtent(QgsRectangle(c.x() - half, c.y() - half, c.x() + half, c.y() + half))
        self.canvas.refresh()
        return (i + 1, n)

    def reset_next(self, key):
        self._next_idx.pop(key, None)

    # hidden-panel chip ----------------------------------------------------
    def set_panel_visible(self, visible):
        self.panel_visible = bool(visible)
        self._update_chip()

    def _update_chip(self):
        on = [TOOL_NAMES[k] for k in TOOL_KEYS if self.is_on(k)]
        want = bool(on) and not self.panel_visible
        if want:
            if self._chip is None:
                self._chip = _LiveChipItem(self.canvas)
                self.canvas.extentsChanged.connect(self._reflow_chip)   # resize -> stay bottom-left
            self._chip.set_text("Live tools on: %s  ·  open the Span Inspector to stop" % ", ".join(on))
        elif self._chip is not None:
            chip, self._chip = self._chip, None
            if not sip.isdeleted(self.canvas):
                try:
                    self.canvas.extentsChanged.disconnect(self._reflow_chip)
                except (TypeError, RuntimeError):
                    pass
            sc = chip.scene()
            if sc is not None:
                sc.removeItem(chip)

    def _update_hud(self):
        want = not getattr(self, "_torn", False) and any(self.is_on(k) for k in ("drops", "lengths", "pons"))
        if want:
            if self._hud is None:
                self._hud = _HudItem(self.canvas, self)
            self._hud.refresh()
        elif self._hud is not None:
            hud, self._hud = self._hud, None
            sc = hud.scene()
            if sc is not None:
                sc.removeItem(hud)

    def reserved_rects(self):
        """Screen areas overlays keep clear of: the HUD column and the 'Live tools on' chip."""
        out = list(getattr(self, "_hud_rects", []))
        if self._chip is not None and not sip.isdeleted(self._chip):
            out.append(self._chip.boundingRect())
        return out

    def obstacle_rects(self):
        """What the readout should not cover: drop numbers, PON tiles, red length tags."""
        out = []
        for k in ("drops", "pons"):
            t = self.tools.get(k)
            if t is not None and t.active:
                for pos, img, *_r in getattr(t, "_draw", []):
                    dpr = img.devicePixelRatio() or 1.0
                    out.append(QRectF(pos.x(), pos.y(), img.width() / dpr, img.height() / dpr))
        t6 = self.tools.get("lengths")
        if t6 is not None and t6.active:
            out += list(getattr(t6, "_label_rects", []))
        return out

    def _paint_hud(self, p):
        y = 10.0
        rects = []
        t6 = self.tools.get("lengths")
        if t6 is not None and t6.active and t6._img is not None and not self.editing():
            f = QFont()
            f.setBold(True)
            f.setPointSizeF(9.5)
            p.setFont(f)
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            for r, text in getattr(t6, "_tags", []):
                p.setPen(QPen(QColor("#FFFFFF"), 1.0))
                p.setBrush(QColor(NUMBER_RED))
                p.drawRoundedRect(r, 3, 3)
                p.setPen(QColor("#FFFFFF"))
                p.drawText(r, int(Qt.AlignmentFlag.AlignCenter), text)
        t5, t6, t7 = self.tools.get("drops"), self.tools.get("lengths"), self.tools.get("pons")
        if t6 is not None and t6.active and t6.layers and t6.n_drops:
            o, r = t6.thresholds()
            y = _legend_chip(p, 10, y, [(LENGTH_COLOURS[core.GREEN], "< %g m" % o, LENGTH_WIDTHS[core.GREEN]),
                                        (LENGTH_COLOURS[core.AMBER], "%g–%g m" % (o, r), LENGTH_WIDTHS[core.AMBER]),
                                        (LENGTH_COLOURS[core.RED], "> %g m" % r, LENGTH_WIDTHS[core.RED])]).bottom() + 6
        if t5 is not None and t5.active and t5.layers and t5._draw:   # only while the numbers show
            y = _legend_chip(p, 10, y, [("disc", "drops on a pole", None),
                                        ("disc_over", "more than %d" % t5.sts_max(), None)]).bottom() + 6
        if t7 is not None and t7.active and t7.pon_layer is not None:
            y = _legend_chip(p, 10, y, [("tile", "PON groups (drop groups in the PON)", None),
                                        ("tile_over", "more than %d" % t7.limit(), None)]).bottom() + 6
        for t in (t5, t6, t7):
            if t is not None and t.active and t._chip:
                rr = _chip_rect(p, t._chip, 10, y)
                rects.append(rr)
                y = rr.bottom() + 6
        rects.append(QRectF(0, 0, 330, y))
        self._hud_rects = rects

    @host_safe
    def _reflow_chip(self, *args):
        if self._chip is not None:
            self._chip.set_text(self._chip.text)

    # teardown -------------------------------------------------------------
    def teardown(self):
        for key in TOOL_KEYS:
            t = self.tools.get(key)
            if t is not None:
                _best_effort(t.destroy)
        if self.engine is not None:
            _best_effort(self.engine.destroy)
        self.panel_visible = True
        self._torn = True

        def unhook():
            if self._watching and not sip.isdeleted(self.canvas):
                try:
                    self.canvas.mapToolSet.disconnect(self._on_map_tool)
                except (TypeError, RuntimeError):
                    pass
                vp = self.canvas.viewport()
                if vp is not None and not sip.isdeleted(vp):
                    vp.removeEventFilter(self)
            self._watching = False
        _best_effort(unhook, self._update_chip, self._update_hud, self._sweep_items)
        self.tools.clear()
        self.actions.clear()

    def _sweep_items(self):
        """Belt and braces after teardown: remove any canvas item of this module still on the
        canvas (a destroy that failed half way must not leave an overlay behind)."""
        sc = self.canvas.scene() if not sip.isdeleted(self.canvas) else None
        if sc is None:
            return
        kinds = (_HubItem, _LiveChipItem, _HudItem, _MeasureLineItem)
        for item in list(sc.items()):
            if isinstance(item, kinds) and (getattr(item, "_host", self) is self):
                sc.removeItem(item)


_HOST = None


def install(iface, toolbar_parent=None):
    """Create the live tools controller (once). Returns it, or None when the kill switch is on.
    Nothing is added to the QGIS window: the Span Inspector shows the controls."""
    global _HOST
    if kill_switch_on():
        return None
    _SETTINGS_CACHE.clear()
    if _HOST is not None:
        uninstall()
    host = LiveTools(iface)
    try:
        host.build()
    except Exception:
        host.teardown()
        raise
    _HOST = host
    return host


def uninstall():
    global _HOST
    host, _HOST = _HOST, None
    if host is not None:
        host.teardown()


def current_host():
    return _HOST
