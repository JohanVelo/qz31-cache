import sys, os
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')

# ============================================================
# PON V1 — FULL ATTRIBUTE POPULATION
# Project: Potch - Mohadin PH2
# Reference: PONS sheet from poles_potch_csv.xlsx
# Fields populated:
#   type, subtyp, spec — static
#   status, cmpownr — static
#   subplace, mainplce, mun, stackref, crtdby — static
#   units — count of Home Connection v1 inside each PON
#   zone_no — spatial join from Zones v1
#   lat, lon — centroid of each PON polygon
# Fields left NULL (match reference):
#   dim1, dim2, cblcpty, conntr, strtfeat, endfeat
#   sg21, sg26, address, datecrtd, date_edt, editby, comments
# ============================================================

PON_LAYER = 'PON v1'
HOME_LAYER = 'Home Connection v1'
ZONE_LAYER = 'Zones v1'

# Static values — Phase 2
STATIC = {
    'type': 'PON',
    'subtyp': 'GPON',
    'spec': 'Maximum 102 Units',
    'status': 'In Planning',
    'cmpownr': 'VelocityFibre',
    'subplace': '676007',
    'mainplce': '676007',
    'mun': 'JB Marks Local Municipality',
    'stackref': 'MOA',
    'crtdby': 'Johan Scholtz',
}

# --- GET LAYERS ---
pon_layer = None
home_layer = None
zone_layer = None

for lyr in QgsProject.instance().mapLayers().values():
    n = lyr.name()
    if n == PON_LAYER: pon_layer = lyr
    if n == HOME_LAYER: home_layer = lyr
    if n == ZONE_LAYER: zone_layer = lyr

missing = []
if not pon_layer: missing.append(PON_LAYER)
if not home_layer: missing.append(HOME_LAYER)
if not zone_layer: missing.append(ZONE_LAYER)

if missing:
    print(f"ERROR: Missing layers: {missing}")
else:
    print(f"PON layer:  {PON_LAYER} ({pon_layer.featureCount()} features)")
    print(f"Home layer: {HOME_LAYER} ({home_layer.featureCount()} features)")
    print(f"Zone layer: {ZONE_LAYER} ({zone_layer.featureCount()} features)")

    from qgis.core import QgsSpatialIndex

    # --- BUILD SPATIAL INDEX FOR HOME CONNECTIONS ---
    home_index = QgsSpatialIndex(home_layer.getFeatures())
    home_feats = {f.id(): f for f in home_layer.getFeatures()}

    # --- BUILD SPATIAL INDEX FOR ZONES ---
    zone_index = QgsSpatialIndex(zone_layer.getFeatures())
    zone_feats = {f.id(): f for f in zone_layer.getFeatures()}

    def fidx(lyr, name):
        return lyr.fields().indexOf(name)

    pon_layer.startEditing()

    total = 0
    zone_matched = 0
    zone_unmatched = 0

    for pon in pon_layer.getFeatures():
        pon_geom = pon.geometry()
        total += 1

        # --- STATIC FIELDS ---
        for field, val in STATIC.items():
            idx = fidx(pon_layer, field)
            if idx != -1:
                pon_layer.changeAttributeValue(pon.id(), idx, val)

        # --- LAT / LON from centroid ---
        if pon_geom and not pon_geom.isNull():
            pt = pon_geom.centroid().asPoint()
            lat_idx = fidx(pon_layer, 'lat')
            lon_idx = fidx(pon_layer, 'lon')
            if lat_idx != -1:
                pon_layer.changeAttributeValue(pon.id(), lat_idx, round(pt.y(), 6))
            if lon_idx != -1:
                pon_layer.changeAttributeValue(pon.id(), lon_idx, round(pt.x(), 7))

        # --- UNITS — count home connections inside PON ---
        units = 0
        if pon_geom and not pon_geom.isNull():
            candidates = home_index.intersects(pon_geom.boundingBox())
            for hfid in candidates:
                hfeat = home_feats[hfid]
                if pon_geom.contains(hfeat.geometry()):
                    units += 1
        units_idx = fidx(pon_layer, 'units')
        if units_idx != -1:
            pon_layer.changeAttributeValue(pon.id(), units_idx, units)

        # --- ZONE_NO — spatial join from Zones v1 ---
        zone_no = None
        if pon_geom and not pon_geom.isNull():
            candidates = zone_index.intersects(pon_geom.boundingBox())
            for zfid in candidates:
                zfeat = zone_feats[zfid]
                if zfeat.geometry().intersects(pon_geom):
                    zone_no = zfeat['zone_no']
                    break
        zone_idx = fidx(pon_layer, 'zone_no')
        if zone_idx != -1 and zone_no is not None:
            pon_layer.changeAttributeValue(pon.id(), zone_idx, zone_no)
            zone_matched += 1
        else:
            zone_unmatched += 1

    pon_layer.commitChanges()

    # --- SUMMARY ---
    print("=" * 50)
    print(f"  PON V1 POPULATION COMPLETE")
    print(f"  Total PONs processed: {total}")
    print(f"  zone_no matched: {zone_matched}")
    print(f"  zone_no unmatched: {zone_unmatched}")
    print("=" * 50)
    print("\nSample — first 5 PONs:")
    for pon in pon_layer.getFeatures():
        print(f"  {pon['label']} | type={pon['type']} | units={pon['units']} | zone_no={pon['zone_no']} | lat={pon['lat']}")
        total -= 1
        if total <= pon_layer.featureCount() - 5:
            break
