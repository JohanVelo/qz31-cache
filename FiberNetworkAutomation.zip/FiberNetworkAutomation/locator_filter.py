"""Velocity Nexus — native QGIS Locator filter.

Lets the operator press Ctrl+K (the QGIS locator) and type::

    vf F446        → jump to pole P.F446
    vf 241         → jump to PON 241 / any feature labelled 241
    vf DR1876498   → jump to that drop / ONT

It searches the label-style text fields of every vector layer in the
project (project-agnostic — works for Vuma, Fibertime and HeroTel layer
sets) and zooms + flashes the chosen feature.

Thread-safety: QGIS calls ``prepare()`` on the main thread and
``fetchResults()`` on a worker thread. All layer/feature access therefore
happens in ``prepare()`` and the results are cached; ``fetchResults()`` only
re-emits the cached list. ``triggerResult()`` runs on the main thread.
"""

from qgis.core import (
    QgsLocatorFilter,
    QgsLocatorResult,
    QgsProject,
    QgsFeatureRequest,
    QgsMapLayer,
    QgsWkbTypes,
)

# Field names (case-insensitive) worth searching — the label-ish columns.
_LABEL_FIELDS = (
    'label', 'label_1', 'name', 'pon_no', 'pon', 'dr', 'dr_num',
    'ref', 'strtfeat', 'endfeat', 'spec_1', 'type_1',
)
_MAX_PER_LAYER = 6      # cap matches per layer so one big layer can't flood
_MAX_TOTAL = 30         # overall cap


class VelocityLocatorFilter(QgsLocatorFilter):
    """`vf <text>` → search fiber feature labels and zoom to the match."""

    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self._cached = []   # list of (display, layer_id, feature_id)

    # QgsLocatorFilter requires a fresh clone per search thread.
    def clone(self):
        return VelocityLocatorFilter(self.iface)

    def name(self):
        return 'velocity_nexus'

    def displayName(self):
        return 'Velocity Nexus features'

    def prefix(self):
        return 'vf'

    def priority(self):
        from qgis.core import QgsLocatorFilter as _F
        return _F.Priority.High

    # ── main thread: gather matches ──────────────────────────────────────
    def prepare(self, string, context):
        self._cached = []
        q = (string or '').strip()
        if len(q) < 2:
            return
        qlow = q.lower()
        proj = QgsProject.instance()
        total = 0
        for lyr in proj.mapLayers().values():
            if total >= _MAX_TOTAL:
                break
            try:
                if lyr.type() != QgsMapLayer.LayerType.VectorLayer:
                    continue
                if lyr.geometryType() == QgsWkbTypes.GeometryType.NullGeometry:
                    continue
                field_names = [f.name() for f in lyr.fields()]
                search_fields = [fn for fn in field_names
                                 if fn.lower() in _LABEL_FIELDS]
                if not search_fields:
                    continue
                # Push the match down to the provider with an ILIKE OR-expr.
                esc = q.replace("'", "''")
                expr = ' OR '.join(
                    f'"{fn}" ILIKE \'%{esc}%\'' for fn in search_fields)
                req = QgsFeatureRequest().setFilterExpression(expr)
                req.setLimit(_MAX_PER_LAYER)
                hits = 0
                for feat in lyr.getFeatures(req):
                    geom = feat.geometry()
                    if geom is None or geom.isEmpty():
                        continue
                    # best label value to show
                    val = None
                    for fn in search_fields:
                        v = feat[fn]
                        if v not in (None, '') and qlow in str(v).lower():
                            val = v
                            break
                    if val is None:
                        val = feat[search_fields[0]]
                    self._cached.append(
                        (f'{val}  ·  {lyr.name()}', lyr.id(), feat.id()))
                    hits += 1
                    total += 1
                    if hits >= _MAX_PER_LAYER or total >= _MAX_TOTAL:
                        break
            except Exception:
                continue  # never let one bad layer break the locator

    # ── worker thread: just emit cached results ──────────────────────────
    def fetchResults(self, string, context, feedback):
        for display, layer_id, fid in self._cached:
            res = QgsLocatorResult()
            res.filter = self
            res.displayString = display
            res.userData = (layer_id, fid)
            self.resultFetched.emit(res)

    # ── main thread: zoom + flash the chosen feature ─────────────────────
    def triggerResult(self, result):
        try:
            layer_id, fid = result.userData
            lyr = QgsProject.instance().mapLayer(layer_id)
            if lyr is None:
                return
            feat = lyr.getFeature(fid)
            geom = feat.geometry()
            if geom is None or geom.isEmpty():
                return
            canvas = self.iface.mapCanvas()
            # transform feature bbox into canvas CRS
            from qgis.core import QgsCoordinateTransform
            xform = QgsCoordinateTransform(
                lyr.crs(), canvas.mapSettings().destinationCrs(),
                QgsProject.instance())
            bbox = xform.transformBoundingBox(geom.boundingBox())
            if bbox.isEmpty():               # point geometry → buffer a little
                c = bbox.center()
                canvas.setCenter(c)
                canvas.zoomScale(1000)
            else:
                bbox.scale(1.4)
                canvas.setExtent(bbox)
            canvas.refresh()
            lyr.removeSelection()
            lyr.select(fid)
            try:
                canvas.flashFeatureIds(lyr, [fid])
            except Exception:
                pass
        except Exception:
            pass
