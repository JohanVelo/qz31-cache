"""nexus_eggs — per-theme Easter-egg animations for the Velocity Nexus panel.

Triggered by 5 fast clicks on the knight logo. Each theme plays a distinct,
transient overlay effect (glitch, matrix rain, shimmer sweep, glow heartbeat,
emoji drift, sparkle burst). Pure PyQt (QPainter + QTimer/QPropertyAnimation),
Qt5/6-safe (scoped enums via qgis.PyQt), parented to a host widget, auto-cleans
in ≤3s, wrapped so a failure can NEVER crash QGIS.

Public API:  play(host_widget, theme_slug)
"""
import math
import random

from qgis.PyQt.QtCore import (Qt, QTimer, QPropertyAnimation,
                              QSequentialAnimationGroup, QEasingCurve,
                              pyqtProperty)
from qgis.PyQt.QtGui import QColor, QPainter, QFont, QBrush
from qgis.PyQt.QtWidgets import QWidget

# scoped-enum aliases (work on PyQt5.15+ and PyQt6)
_WA_CLICK = Qt.WidgetAttribute.WA_TransparentForMouseEvents
_WA_NOBG = Qt.WidgetAttribute.WA_NoSystemBackground
_AA = QPainter.RenderHint.Antialiasing
_EASE = QEasingCurve.Type.InOutQuad
_BOLD = QFont.Weight.Bold


class _Overlay(QWidget):
    """Transparent, click-through overlay sized to its host. Subclasses paint."""
    def __init__(self, host):
        super().__init__(host)
        self.setAttribute(_WA_CLICK, True)
        self.setAttribute(_WA_NOBG, True)
        self.setStyleSheet("background:transparent;")
        self.setGeometry(host.rect())
        self.raise_()


class GlowPulse(_Overlay):
    """A coloured glow swells from the top then fades — a heartbeat."""
    def __init__(self, host, color, dur=1700):
        super().__init__(host)
        self._c = QColor(color)
        self._v = 0.0
        up = QPropertyAnimation(self, b"v", self)
        up.setStartValue(0.0); up.setEndValue(1.0)
        up.setDuration(dur // 2); up.setEasingCurve(_EASE)
        dn = QPropertyAnimation(self, b"v", self)
        dn.setStartValue(1.0); dn.setEndValue(0.0)
        dn.setDuration(dur // 2); dn.setEasingCurve(_EASE)
        self._seq = QSequentialAnimationGroup(self)
        self._seq.addAnimation(up); self._seq.addAnimation(dn)
        self._seq.finished.connect(self.deleteLater)

    def _get_v(self):
        return self._v

    def _set_v(self, val):
        self._v = val
        self.update()
    v = pyqtProperty(float, _get_v, _set_v)

    def paintEvent(self, _e):
        if self._v <= 0:
            return
        p = QPainter(self)
        c = QColor(self._c)
        c.setAlpha(int(150 * self._v))
        h = int(self.height() * 0.5 * self._v)
        p.fillRect(0, 0, self.width(), max(2, h), QBrush(c))
        p.end()

    def start(self):
        self.show(); self._seq.start()


class ShimmerSweep(_Overlay):
    """A soft highlight bar sweeps across, twice."""
    def __init__(self, host, color, dur=900, repeats=2):
        super().__init__(host)
        self._c = QColor(color)
        self._p = 0.0
        self._left = repeats
        self._anim = QPropertyAnimation(self, b"p", self)
        self._anim.setStartValue(0.0); self._anim.setEndValue(1.0)
        self._anim.setDuration(dur); self._anim.setEasingCurve(_EASE)
        self._anim.finished.connect(self._next)

    def _next(self):
        self._left -= 1
        if self._left > 0:
            self._anim.start()
        else:
            self.deleteLater()

    def _get_p(self):
        return self._p

    def _set_p(self, val):
        self._p = val
        self.update()
    p = pyqtProperty(float, _get_p, _set_p)

    def paintEvent(self, _e):
        p = QPainter(self)
        x = int(self.width() * self._p)
        for i, a in ((0, 40), (1, 110), (2, 40)):
            c = QColor(self._c); c.setAlpha(a)
            p.fillRect(x - 9 + i * 9, 0, 9, self.height(), QBrush(c))
        p.end()

    def start(self):
        self.show(); self._anim.start()


class FallingGlyphs(_Overlay):
    """Glyphs stream down and fade — matrix rain / snow."""
    def __init__(self, host, color, glyphs="01", dur=2400, cols=22):
        super().__init__(host)
        self._c = QColor(color)
        self._frame = 0
        self._max = max(30, dur // 33)
        w = max(40, host.width())
        self._cols = [{"x": random.randint(4, w - 8),
                       "g": random.choice(glyphs),
                       "s": random.randint(0, self._max // 2),
                       "sp": random.uniform(0.7, 1.4)} for _ in range(cols)]
        self._t = QTimer(self)
        self._t.timeout.connect(self._tick)

    def _tick(self):
        self._frame += 1
        if self._frame >= self._max:
            self._t.stop(); self.deleteLater(); return
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        # Segoe UI Symbol covers snow ❄ / stars ✦★ AND geometric ●◆▪ — Consolas
        # lacks the snow/star glyphs so they'd draw blank.
        p.setFont(QFont("Segoe UI Symbol", 17, _BOLD))
        h = self.height()
        for col in self._cols:
            if self._frame < col["s"]:
                continue
            prog = (self._frame - col["s"]) / float(self._max - col["s"]) * col["sp"]
            if prog > 1.15:
                continue
            y = int(h * prog)
            fade = 1.0 if prog <= 1.0 else max(0.0, 1.0 - (prog - 1.0) / 0.15)
            # a short trailing comet of glyphs above the head (matrix look)
            for t in range(4):
                gy = y - t * 19
                if gy < -12:
                    continue
                c = QColor(self._c)
                c.setAlpha(int(230 * fade * (1.0 - t * 0.22)))
                p.setPen(c)
                p.drawText(col["x"], gy, col["g"])
        p.end()

    def start(self):
        self.show(); self._t.start(33)


class EmojiDrift(_Overlay):
    """An emoji glides across the panel with a fade in/out."""
    def __init__(self, host, emoji="✦", dur=1900, size=44):
        super().__init__(host)
        self._e = emoji
        self._size = size
        self._p = 0.0
        self._y = random.uniform(0.3, 0.6)
        self._anim = QPropertyAnimation(self, b"p", self)
        self._anim.setStartValue(0.0); self._anim.setEndValue(1.0)
        self._anim.setDuration(dur); self._anim.setEasingCurve(_EASE)
        self._anim.finished.connect(self.deleteLater)

    def _get_p(self):
        return self._p

    def _set_p(self, val):
        self._p = val
        self.update()
    p = pyqtProperty(float, _get_p, _set_p)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(_AA, True)
        p.setFont(QFont("Segoe UI Emoji", self._size))
        x = int(self.width() * self._p) - self._size // 2
        y = int(self.height() * self._y)
        op = 1.0
        if self._p < 0.12:
            op = self._p / 0.12
        elif self._p > 0.88:
            op = (1 - self._p) / 0.12
        c = QColor("#FFFFFF"); c.setAlpha(int(255 * max(0, op)))
        p.setPen(c)
        p.drawText(x, y, self._e)
        p.end()

    def start(self):
        self.show(); self._anim.start()


class GlitchFlicker(_Overlay):
    """Brief RGB-split jitter banner — cyberpunk glitch."""
    def __init__(self, host, color, text="SYSTEM.BREACH", dur=900):
        super().__init__(host)
        self._c = QColor(color)
        self._text = text
        self._frame = 0
        self._max = max(15, dur // 33)
        self._t = QTimer(self)
        self._t.timeout.connect(self._tick)

    def _tick(self):
        self._frame += 1
        if self._frame >= self._max:
            self._t.stop(); self.deleteLater(); return
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setFont(QFont("Consolas", 15, _BOLD))
        cy = self.height() // 2
        for col, dx in ((QColor("#FF2E63"), -2), (QColor("#19E5FF"), 2),
                        (self._c, 0)):
            col.setAlpha(190)
            p.setPen(col)
            p.drawText(14 + dx + random.randint(-2, 2),
                       cy + random.randint(-2, 2), self._text)
        p.end()

    def start(self):
        self.show(); self._t.start(33)


class SparkleBurst(_Overlay):
    """Themed particles burst from the top and arc with gravity, fading."""
    def __init__(self, host, color, dur=1600, n=18):
        super().__init__(host)
        self._c = QColor(color)
        self._frame = 0
        self._max = max(36, dur // 25)
        cx = host.width() / 2.0
        self._ps = []
        for i in range(n):
            ang = math.radians(360.0 / n * i)
            sp = random.uniform(2.2, 5.0)
            self._ps.append({"x": cx, "y": 24.0,
                             "vx": sp * math.cos(ang),
                             "vy": sp * math.sin(ang) - 2.4})
        self._t = QTimer(self)
        self._t.timeout.connect(self._tick)

    def _tick(self):
        self._frame += 1
        for q in self._ps:
            q["x"] += q["vx"]; q["y"] += q["vy"]; q["vy"] += 0.16
        if self._frame >= self._max:
            self._t.stop(); self.deleteLater(); return
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        life = max(0.0, 1.0 - self._frame / float(self._max))
        c = QColor(self._c); c.setAlpha(int(230 * life))
        for q in self._ps:
            p.fillRect(int(q["x"]), int(q["y"]), 7, 7, QBrush(c))
        p.end()

    def start(self):
        self.show(); self._t.start(25)


# theme slug → effect config (one place; theme dicts stay clean)
EGGS = {
    "velocity":  {"fx": "sparkle", "color": "#1AE5FF"},
    "fibertime": {"fx": "pulse",   "color": "#FFD400"},
    "cyberpunk": {"fx": "glitch",  "color": "#FF2E63", "text": "SYSTEM.BREACH"},
    "synthwave": {"fx": "shimmer", "color": "#FF2975"},
    "matrix":    {"fx": "rain",    "color": "#00FF41", "glyphs": "01●◆▪▮▰"},
    "vaporwave": {"fx": "drift",   "emoji": "🌴"},
    "dracula":   {"fx": "drift",   "emoji": "🦇"},
    "nord":      {"fx": "shimmer", "color": "#88c0d0"},
    "solarized": {"fx": "sparkle", "color": "#2aa198"},
    "royalgold": {"fx": "shimmer", "color": "#FFD700"},
    "crimson":   {"fx": "pulse",   "color": "#DC143C"},
    "arctic":    {"fx": "rain",    "color": "#A5F2F3", "glyphs": "❄✦★·"},
}


def play(host, slug):
    """Play the Easter-egg effect for `slug` on `host`. Never raises. A hard
    backstop timer force-deletes the overlay after 4s so it can never linger
    even if its own finish signal misfires."""
    try:
        cfg = EGGS.get(slug, {"fx": "sparkle", "color": "#1AE5FF"})
        fx = cfg.get("fx", "sparkle")
        color = cfg.get("color", "#1AE5FF")
        if fx == "glitch":
            ov = GlitchFlicker(host, color, cfg.get("text", "NEXUS"))
        elif fx == "rain":
            ov = FallingGlyphs(host, color, cfg.get("glyphs", "01"))
        elif fx == "shimmer":
            ov = ShimmerSweep(host, color)
        elif fx == "pulse":
            ov = GlowPulse(host, color)
        elif fx == "drift":
            ov = EmojiDrift(host, cfg.get("emoji", "✦"))
        else:
            ov = SparkleBurst(host, color)
        ov.start()
        QTimer.singleShot(4000, ov.deleteLater)   # guaranteed cleanup
    except Exception:
        pass
