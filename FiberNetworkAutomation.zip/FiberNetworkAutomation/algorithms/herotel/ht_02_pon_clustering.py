# HeroTel: HT 2 — PON Clustering from the span (wayleave)
#
# Groups demand points into PONs by walking the drawn fibre route, so every PON
# is one continuous run of span and a boundary never cuts across one. The
# grouping engine is pure Python in ``fibre_automation.pon_wayleave``; the
# BOUNDARIES come from ``network_planner.pon_tiles`` + ``pon_merge.shrink``,
# which already shipped and carry the house style (straight edges, 4 m gap
# measured off Malmesbury V4). One implementation of what a PON looks like.


from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsFeatureSink,
    QgsField,
    QgsFields,
    QgsPointXY,
    QgsProcessing,
    QgsProcessingException,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber,
    QgsProcessingParameterString,
    QgsProcessingParameterVectorLayer,
    QgsProject,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import QMetaType

from .ht_base_algorithm import HeroTelBaseAlgorithm

#: Gap between neighbouring PONs, metres. Measured off the Malmesbury V4 `Pons`
#: layer: 4.00 m on 148 of 151 adjacent pairs, zero touching, zero overlap.
DEFAULT_GAP_M = 4.0


class HT02PonClusteringAlgorithm(HeroTelBaseAlgorithm):
    """HT 2 — PON Clustering from the span.

    Assigns every demand point to a PON that follows the fibre route, then
    builds straight-edged boundaries with a gap between them.
    """

    INPUT_DEMAND = 'INPUT_DEMAND'
    INPUT_SPAN = 'INPUT_SPAN'
    INPUT_DC = 'INPUT_DC'
    TARGET = 'TARGET'
    MAX_STANDS = 'MAX_STANDS'
    GAP_M = 'GAP_M'
    BALANCE = 'BALANCE'
    AOI_NAME = 'AOI_NAME'
    WRITE_BACK = 'WRITE_BACK'
    OUTPUT = 'OUTPUT'

    def name(self):
        return 'ht_02_pon_clustering'

    def displayName(self):
        return 'HT 2 — PON Clustering (from span)'

    def shortHelpString(self):
        return """
        <p><b>HT 2 — PON Clustering from the span</b></p>
        <p>Groups demand points into PONs by following the fibre route, then draws
        straight-edged PON boundaries with a gap between them.</p>

        <h4>What it guarantees</h4>
        <ul>
          <li>No PON holds more than <b>Max stands</b> (default 120).</li>
          <li>Each PON's span is <b>one continuous run</b> — a boundary never cuts
              across a span, so you never break off a span to feed the next PON.</li>
          <li>PON 1 is nearest the DC and numbers increase outward, per the
              2026 OPL FTTH labelling standard.</li>
          <li>Boundaries are straight and sit <b>4 m apart</b>, matching the
              Malmesbury reference layer.</li>
        </ul>

        <h4>You only need to press Run</h4>
        <p>Every input is picked up from the project when it can be. Change
        <b>Target stands</b> if this client wants PONs a different size.</p>

        <p><i>PONs smaller than the target are expected — once the full ones are
        packed, whatever is left over forms the last PON.</i></p>

        <h4>Evening out the PON sizes</h4>
        <p>Left to itself the grouping packs PONs to the cap and leaves the
        remainder in a runt — measured on Ventersdorp, a <b>26-home</b> PON next
        to a 116-home one. With <b>Even out the PON sizes</b> ticked the runs are
        redistributed between neighbouring PONs and the PONs are then renumbered
        outward from the DC again.</p>
        <table border="1" cellpadding="3" cellspacing="0">
          <tr><th>Measured 2026-09-07</th><th>Off</th><th>On</th></tr>
          <tr><td>Ventersdorp, PONs in the 80–102 band</td>
              <td>32.5%</td><td><b>62.2%</b></td></tr>
          <tr><td>Ventersdorp, smallest PON</td><td>26</td><td><b>55</b></td></tr>
          <tr><td>Malmesbury, PONs in the 80–102 band</td>
              <td>33.3%</td><td><b>81.2%</b></td></tr>
          <tr><td>Malmesbury, smallest PON</td><td>47</td><td><b>64</b></td></tr>
        </table>
        <p>Untick it to get exactly the behaviour of earlier versions.</p>

        <h4>One known limitation</h4>
        <p>A short tail of drawn cable can end up sitting inside a neighbouring
        PON’s polygon, because the boundaries are tiled around the homes while
        the grouping follows the cable, so the two disagree at the very edge.
        Every <b>home</b> is still in the right PON, and no PON’s size, splitter
        or BOQ changes. Measured on Malmesbury with this version: 3.19% of cable
        more than 5 m inside a neighbour, against 5.95% for the same town’s
        hand-drawn PONs.</p>
        """

    def initAlgorithm(self, configuration=None):
        proj = QgsProject.instance()

        def pick(*names):
            for n in names:
                found = proj.mapLayersByName(n)
                if found:
                    return found[0]
            return None

        self.addParameter(QgsProcessingParameterVectorLayer(
            self.INPUT_DEMAND, 'Demand points (one per home)',
            [QgsProcessing.SourceType.TypeVectorPoint],
            defaultValue=pick('Demand Points', 'ONT v1', 'Demand Points - Groups of 8'),
        ))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.INPUT_SPAN, 'Span (the fibre route)',
            [QgsProcessing.SourceType.TypeVectorLine],
            defaultValue=pick('Span', 'Wayleave', 'Span v1'),
        ))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.INPUT_DC, 'DC / POP location (optional)',
            [QgsProcessing.SourceType.TypeVectorPoint],
            defaultValue=pick('POP', 'DC Location', 'DC'), optional=True,
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.TARGET, 'Target stands per PON',
            type=QgsProcessingParameterNumber.Type.Integer,
            minValue=8, maxValue=512, defaultValue=96,
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.MAX_STANDS, 'Maximum stands per PON (never exceeded)',
            type=QgsProcessingParameterNumber.Type.Integer,
            minValue=8, maxValue=512, defaultValue=120,
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.GAP_M, 'Gap between PON boundaries (m)',
            type=QgsProcessingParameterNumber.Type.Double,
            minValue=0.0, maxValue=50.0, defaultValue=DEFAULT_GAP_M,
        ))
        self.addParameter(QgsProcessingParameterBoolean(
            self.BALANCE, 'Even out the PON sizes (recommended)',
            defaultValue=True,
        ))
        self.addParameter(QgsProcessingParameterString(
            self.AOI_NAME, 'Area name used in the PON label',
            defaultValue='', optional=True,
        ))
        # Defaults OFF. This writes through the PROVIDER: it adds two columns
        # and overwrites pon_num immediately, with no edit session and no undo
        # entry, on whatever layer the dropdown above resolved to. That is not a
        # thing to do to an operator's layer unless they asked for it.
        self.addParameter(QgsProcessingParameterBoolean(
            self.WRITE_BACK, 'Also write pon_num onto the demand layer '
                             '(overwrites it — no undo)',
            defaultValue=False,
        ))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, 'PON Zones',
            QgsProcessing.SourceType.TypeVectorPolygon,
        ))

    # ── run ────────────────────────────────────────────────────────────────

    def processAlgorithm(self, parameters, context, feedback):
        try:
            from ...fibre_automation.pon_wayleave import (
                PonWayleaveError, balanced_grouping, check_zone_fit, utm_epsg_for,
            )
        except ImportError as exc:                       # pragma: no cover
            raise QgsProcessingException(
                f"The PON clustering engine could not be loaded ({exc}). "
                "Reinstall or update the plugin."
            ) from exc

        demand = self.parameterAsVectorLayer(parameters, self.INPUT_DEMAND, context)
        span = self.parameterAsVectorLayer(parameters, self.INPUT_SPAN, context)
        dc_layer = self.parameterAsVectorLayer(parameters, self.INPUT_DC, context)
        target = self.parameterAsInt(parameters, self.TARGET, context)
        max_stands = self.parameterAsInt(parameters, self.MAX_STANDS, context)
        gap_m = self.parameterAsDouble(parameters, self.GAP_M, context)
        aoi_name = (self.parameterAsString(parameters, self.AOI_NAME, context) or '').strip()
        write_back = self.parameterAsBoolean(parameters, self.WRITE_BACK, context)
        balance = self.parameterAsBoolean(parameters, self.BALANCE, context)

        if demand is None:
            raise QgsProcessingException("Choose the demand-point layer.")
        if span is None:
            raise QgsProcessingException("Choose the span layer.")
        if max_stands < target:
            raise QgsProcessingException(
                f"Maximum ({max_stands}) cannot be below the target ({target})."
            )
        if demand.featureCount() == 0:
            raise QgsProcessingException(
                f"'{demand.name()}' has no features. Check it is not filtered."
            )
        if write_back:
            frozen = self._frozen_reason(demand)
            if frozen:
                raise QgsProcessingException(
                    f"Refusing to write onto '{demand.name()}': {frozen}\n\n"
                    "That layer belongs to a delivered project whose BOQ is "
                    "approved, and this would overwrite pon_num on it with no "
                    "undo. Untick 'Also write pon_num onto the demand layer' to "
                    "produce the zones without touching it, or run against a "
                    "copy."
                )
        if not aoi_name:
            aoi_name = QgsProject.instance().baseName() or 'PON'

        # ── work out the metric CRS from the DATA, never a fixed zone ──────
        wgs84 = QgsCoordinateReferenceSystem('EPSG:4326')
        to_wgs = QgsCoordinateTransform(
            demand.crs(), wgs84, QgsProject.instance().transformContext())
        ext = demand.extent()
        try:
            ll = to_wgs.transform(ext.center())
        except Exception as exc:
            raise QgsProcessingException(
                f"Could not work out where '{demand.name()}' is on the globe "
                f"({exc}). Check the layer has a valid CRS."
            ) from exc
        try:
            epsg = utm_epsg_for(ll.x(), ll.y())
        except PonWayleaveError as exc:
            raise QgsProcessingException(str(exc)) from exc
        # The zone came from the extent CENTRE. Prove the whole extent belongs
        # in it: a project straddling a zone boundary, or one stray feature on
        # another continent, reprojects *successfully* and silently corrupts
        # every distance -- and metres are what caps a PON at MAX_STANDS.
        try:
            corners = [to_wgs.transform(QgsPointXY(x, y))
                       for x, y in ((ext.xMinimum(), ext.yMinimum()),
                                    (ext.xMinimum(), ext.yMaximum()),
                                    (ext.xMaximum(), ext.yMinimum()),
                                    (ext.xMaximum(), ext.yMaximum()))]
        except Exception as exc:
            raise QgsProcessingException(
                f"Could not project the extent of '{demand.name()}' to WGS84 "
                f"({exc}). Check the layer has a valid CRS."
            ) from exc
        try:
            check_zone_fit([p.x() for p in corners], [p.y() for p in corners], epsg)
        except PonWayleaveError as exc:
            raise QgsProcessingException(str(exc)) from exc

        metric = QgsCoordinateReferenceSystem.fromEpsgId(epsg)
        feedback.pushInfo(f"Working in EPSG:{epsg}, derived from the data.")

        tf_demand = QgsCoordinateTransform(
            demand.crs(), metric, QgsProject.instance().transformContext())
        tf_span = QgsCoordinateTransform(
            span.crs(), metric, QgsProject.instance().transformContext())

        # ── gather geometry ────────────────────────────────────────────────
        from shapely import wkt as shp_wkt

        dem_feats, dxy = [], []
        for f in demand.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsFeature(f).geometry()
            gg = g.constGet().clone()
            gg.transform(tf_demand)
            p = gg.centroid() if gg.wkbType() != QgsWkbTypes.Point else gg
            dem_feats.append(f)
            dxy.append((p.x(), p.y()))
        if not dxy:
            raise QgsProcessingException("No usable demand-point geometry.")

        span_lines = []
        for f in span.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g2 = QgsFeature(f).geometry()
            g2.transform(tf_span)
            try:
                shp = shp_wkt.loads(g2.asWkt())
            except Exception:
                continue
            if shp.geom_type == 'MultiLineString':
                span_lines.extend([p for p in shp.geoms if p.length > 0])
            elif shp.geom_type == 'LineString' and shp.length > 0:
                span_lines.append(shp)
        if not span_lines:
            raise QgsProcessingException(
                f"'{span.name()}' has no line geometry to follow."
            )

        dc_xy = None
        if dc_layer is not None and dc_layer.featureCount():
            tf_dc = QgsCoordinateTransform(
                dc_layer.crs(), metric, QgsProject.instance().transformContext())
            for f in dc_layer.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g2 = QgsFeature(f).geometry()
                g2.transform(tf_dc)
                pt = g2.centroid().asPoint()
                dc_xy = (pt.x(), pt.y())
                break
        if dc_xy is None:
            feedback.pushWarning(
                "No DC/POP point found — PONs will be numbered outward from the "
                "middle of the route instead of from the DC."
            )

        # ── group ──────────────────────────────────────────────────────────
        def _progress(pct, msg):
            feedback.setProgress(int(pct * 0.75))
            feedback.pushInfo(msg)

        try:
            grouped = balanced_grouping(
                span_lines, dxy, dc_xy=dc_xy,
                target=target, max_stands=max_stands, balance=balance,
                progress=_progress, is_cancelled=feedback.isCanceled,
            )
        except PonWayleaveError as exc:
            raise QgsProcessingException(str(exc)) from exc
        result = grouped.grouping
        pon_of_stand = grouped.pon_of_stand
        if any(p is None for p in pon_of_stand):
            missing = sum(1 for p in pon_of_stand if p is None)
            raise QgsProcessingException(
                f"{missing:,} demand point(s) were left without a PON. Nothing "
                "was written. This usually means the span does not reach them — "
                "check the route covers the whole area."
            )
        pon_of_stand = [int(p) for p in pon_of_stand]

        for w in grouped.warnings:
            feedback.pushWarning(w)

        from collections import Counter
        sizes = Counter(pon_of_stand)
        vals = sorted(sizes.values())
        in_band = sum(1 for v in vals if 80 <= v <= 102)
        feedback.pushInfo(
            f"{len(vals)} PONs — stands per PON min {vals[0]}, "
            f"median {vals[len(vals) // 2]}, max {vals[-1]} "
            f"(maximum {max_stands}); {in_band}/{len(vals)} inside the 80–102 band."
        )
        if vals[-1] > max_stands:                         # pragma: no cover
            raise QgsProcessingException(
                f"A PON came out at {vals[-1]} stands, over the maximum of "
                f"{max_stands} — this is a bug, please report it. Nothing was "
                "written."
            )
        if balance:
            feedback.pushInfo(
                "PON sizes evened out and renumbered outward from the DC.")

        # ── boundaries: reuse the shipped tiler + shrink ────────────────────
        feedback.setProgress(80)
        feedback.pushInfo("Drawing straight-edged boundaries")
        geoms = self._boundaries(demand, dem_feats, pon_of_stand,
                                 gap_m, feedback)

        # ── write ──────────────────────────────────────────────────────────
        fields = QgsFields()
        fields.append(QgsField('pon_num', QMetaType.Type.Int))
        fields.append(QgsField('label', QMetaType.Type.QString))
        fields.append(QgsField('units', QMetaType.Type.Int))
        fields.append(QgsField('span_m', QMetaType.Type.Int))

        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT, context, fields,
            QgsWkbTypes.MultiPolygon, demand.crs(),
        )
        if sink is None:                                  # pragma: no cover
            raise QgsProcessingException("Could not create the PON Zones output.")

        span_m = {}
        for r, p in grouped.pon_of_run.items():
            span_m[p] = span_m.get(p, 0.0) + result.graph.runs[r].length

        written = 0
        for pon in sorted(geoms):
            g = geoms[pon]
            if g is None or g.isEmpty():
                continue
            out = QgsFeature(fields)
            out.setGeometry(g)
            out.setAttribute('pon_num', int(pon))
            out.setAttribute('label', f"{aoi_name} PON{int(pon)}")
            out.setAttribute('units', int(sizes.get(int(pon), 0)))
            out.setAttribute('span_m', int(round(span_m.get(pon, 0.0))))
            sink.addFeature(out, QgsFeatureSink.Flag.FastInsert)
            written += 1

        if write_back:
            self._write_back(demand, dem_feats, pon_of_stand,
                             aoi_name, feedback)
        else:
            feedback.pushInfo(
                "The demand layer was not modified. Tick 'Also write pon_num "
                "onto the demand layer' if you want pon_num written onto it.")

        feedback.setProgress(100)
        feedback.pushInfo(f"Wrote {written} PON zones.")
        return {self.OUTPUT: dest_id}

    # ── helpers ────────────────────────────────────────────────────────────

    #: Layer names and path fragments that mark a delivered, frozen project.
    #: The ' v1' suffix is the Phase 2 convention and the delivery folder is
    #: read-only by policy; a run against either would overwrite an approved BOQ.
    FROZEN_NAME_HINTS = (' v1',)
    FROZEN_PATH_HINTS = ('potch - mohadin ph2', 'fibertime planning',
                         'baseline maps')

    def _frozen_reason(self, layer):
        """Why this layer must not be written to, or None if it is fair game.

        Checked on the SOURCE PATH as well as the name: a layer renamed in the
        project tree still points at the delivered shapefile underneath.
        """
        try:
            name = (layer.name() or '').lower()
            source = (layer.source() or '').lower().replace('\\', '/')
        except Exception:                                  # pragma: no cover
            return None
        for hint in self.FROZEN_NAME_HINTS:
            if name.endswith(hint) or f'{hint} ' in name:
                return (f"its name ends in '{hint.strip()}', the naming "
                        "convention of the delivered Phase 2 layers")
        for hint in self.FROZEN_PATH_HINTS:
            if hint in source:
                return f"it is loaded from the delivery folder ('{hint}')"
        return None


    def _boundaries(self, demand, dem_feats, labels, gap_m, feedback):
        """Straight tiles from the shipped tiler, then the 4 m shrink."""
        from ...network_planner import pon_merge, pon_tiles

        by_zone = {}
        for feat, pon in zip(dem_feats, labels):
            by_zone.setdefault(int(pon), []).append(feat)

        # 12 m, not the module default of 40 m. Measured on Ventersdorp: 40 m
        # leaves 67 homes inside a NEIGHBOURING PON's polygon, 12 m leaves none
        # while still giving ~23 vertices per PON.
        tiles = pon_tiles.voronoi_zone_polygons(demand, by_zone, simplify_m=12.0)
        if not tiles:
            raise QgsProcessingException(
                "The boundary tiler could not run on this data, so no PON "
                "polygons were produced. The grouping itself succeeded — check "
                "the demand layer has valid point geometry."
            )

        out, shrunk = {}, 0
        for pon, geom in tiles.items():
            if geom is None or geom.isEmpty():
                continue
            if gap_m > 0:
                pulled, ok = pon_merge.shrink(geom, demand, gap_m=gap_m)
                if ok:
                    geom = pulled
                    shrunk += 1
            out[int(pon)] = geom
        feedback.pushInfo(
            f"{len(out)} boundaries, {shrunk} pulled in by {gap_m:.1f} m "
            f"so neighbours do not touch."
        )
        return out

    def _write_back(self, demand, dem_feats, labels, aoi_name, feedback):
        """Put pon_num / pon_label on the demand layer, bulk, never per-feature."""
        provider = demand.dataProvider()
        names = [f.name() for f in demand.fields()]
        to_add = []
        if 'pon_num' not in names:
            to_add.append(QgsField('pon_num', QMetaType.Type.Int))
        if 'pon_label' not in names:
            to_add.append(QgsField('pon_label', QMetaType.Type.QString))
        if to_add:
            if not provider.addAttributes(to_add):
                feedback.pushWarning(
                    "Could not add pon_num / pon_label to the demand layer — "
                    "the zones were still created."
                )
                return
            demand.updateFields()

        idx_num = demand.fields().indexOf('pon_num')
        idx_lab = demand.fields().indexOf('pon_label')
        if idx_num < 0:
            return
        attr_map = {}
        for feat, pon in zip(dem_feats, labels):
            vals = {idx_num: int(pon)}
            if idx_lab >= 0:
                vals[idx_lab] = f"{aoi_name} PON{int(pon)}"
            attr_map[feat.id()] = vals
        if attr_map and provider.changeAttributeValues(attr_map):
            demand.triggerRepaint()
            feedback.pushInfo(f"pon_num written onto {len(attr_map):,} demand points.")
        else:
            feedback.pushWarning("Could not write pon_num onto the demand layer.")
