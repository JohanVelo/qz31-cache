"""nexus_profile — Velocity Nexus per-user profiles, telemetry, team monitor.

v2.4.0. Each operator sets up a username + personal password once; the plugin
greets them personally; usage/errors/presence stream to a small Supabase
backend; the owner (JJ only) sees a live Team Monitor.

Design rules (see guides/BUILD_PROMPT_velocity_nexus_user_profiles.md):
- Plain-QGIS safe: QGIS-bundled + qgis.PyQt + stdlib ONLY (no pip).
- Offline-first, fail-silent: no network call ever blocks the UI; events queue
  to a local JSONL spool and flush later.
- All names are the SIGNED-IN username — never hardcoded.
- Identity is ours (install_id / username), not Supabase Auth. Anon key is
  insert-only (RLS); the owner read-key never ships.

Modules:
  config       — backend URL + anon key + team-code hash (filled at Phase 1)
  backend      — the ONE network client (QgsNetworkAccessManager); dry-run aware
  identity     — install_id, session_id, breadcrumb ring buffer (pure Python)
  hashing      — PBKDF2 password hashing (stdlib)
  profile      — first-run wizard, sign-in/out, local profile store
  telemetry    — heartbeat + event batching + spool flush + choke wrappers
"""
