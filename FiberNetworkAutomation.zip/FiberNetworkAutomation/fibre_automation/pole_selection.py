"""Pure pole-selection model for Label My Network.

No Qt, no QGIS, no I/O — feed it plain dicts. That keeps the selection rules
testable in milliseconds and keeps the identity logic out of the map tool.

WHY GEOMETRY AND NOT FID
------------------------
OGR renumbers feature ids on commit. A selection keyed on fid silently starts
addressing DIFFERENT poles after any edit — the exact class of defect that
made Delete+Renumber wrong while passing compile, ruff, qt6 and 300+ property
tests. So identity here is the rounded point, and a fid is carried only as a
fast-path hint that is re-checked before it is believed.

PRECISION IS BENCHMARKED, NOT GUESSED
-------------------------------------
Measured 2026-08-03 on the file the PH2 TEST project ACTUALLY loads —
Mohadin_PH2_SANDBOX/poles.shp, 1,916 poles, EPSG:4326:

    closest genuine pole pair   0.89 m
    round to 4 dp (~11 m)       52 collisions   <- too coarse, merges poles
    round to 5/6/7/8 dp         0 collisions

so 6 dp (~11 cm) sits safely between the two failure modes: fine enough never
to merge two real poles, coarse enough to absorb float jitter.

PROVENANCE WARNING — READ BEFORE TRUSTING ANY POLE COUNT
--------------------------------------------------------
The PH2 TEST project folder contains a sibling file, "poles v1.shp"
(1,924 poles), which the project DOES NOT LOAD. Its layer named "poles v1"
reads Mohadin_PH2_SANDBOX/poles.shp (1,916 poles) — the same count live MOA
reports. An earlier benchmark in this build measured the sibling by mistake.
Resolve pole layers by LAYER ID and check .source(); never assume the file
beside the .qgz is the file in use.

THE DUPLICATE-GEOMETRY PROBLEM IS REAL, JUST NOT IN THIS LAYER
---------------------------------------------------------------
The sibling file holds 5 locations with more than one pole (11 poles: four
pairs and one triple) where the poles agree on type_1, status and pon_no and
differ ONLY by Label — the field a renumber rewrites. The layer actually in
use is clean (1,916 distinct locations, zero stacked), but the hazard is real
data, so this module refuses to guess: a key matching several poles resolves
to AMBIGUOUS and hands back the candidates for a human decision. The captured
label is kept for the message only, never for resolution.
"""

import hashlib

__all__ = [
    "ADD",
    "AMBIGUOUS",
    "DEFAULT_PRECISION",
    "INTERSECT",
    "MISSING",
    "REMOVE",
    "REPLACE",
    "RESOLVED",
    "PoleSelection",
    "ResolveReport",
    "ambiguous_locations",
    "capture_order",
    "pole_key",
    "renumber_block_reason",
    "select_mode_for_modifiers",
    "selection_counts",
    "witness",
]

DEFAULT_PRECISION = 6

# Drag modes, named for what the operator did rather than for Qt.
REPLACE = "replace"
ADD = "add"
REMOVE = "remove"
INTERSECT = "intersect"

RESOLVED = "resolved"
MISSING = "missing"
AMBIGUOUS = "ambiguous"

# Attributes that may take part in identity. Deliberately excludes every
# label-ish field: those are the thing a renumber rewrites, so trusting them
# would make identity depend on the operation being performed.
_LABEL_FIELDS = frozenset({
    "label", "label_1", "name", "pnum", "polename", "pole_name", "fid",
})


def _norm(value):
    """Stable text for one attribute value. 23.0 and 23 must agree."""
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    return str(value).strip()


def pole_key(x, y, precision=DEFAULT_PRECISION):
    """Identity of a pole: its rounded position. Never its fid.

    round() is applied to floats, so -0.0 and 0.0 collapse to the same key.
    """
    return (round(float(x), precision) + 0.0,
            round(float(y), precision) + 0.0)


def witness(attrs, fields=None):
    """Short digest of the STABLE attributes at capture time.

    Used only to break a tie when one location holds several poles. Label-ish
    fields are excluded (see _LABEL_FIELDS) because a renumber changes them.
    An empty/absent attribute set digests to "" — an empty witness never
    disambiguates anything, which is the safe direction.
    """
    attrs = attrs or {}
    if fields is None:
        fields = [k for k in attrs if k.lower() not in _LABEL_FIELDS]
    pairs = []
    for key in sorted(fields):
        val = _norm(attrs.get(key))
        if val:
            pairs.append("%s=%s" % (key, val))
    if not pairs:
        return ""
    return hashlib.sha1("|".join(pairs).encode("utf-8")).hexdigest()[:16]


def capture_order(items):
    """Deterministic order WITHIN one rectangle drag: top-to-bottom, then
    left-to-right (JJ, 2026-08-03). Ties break on the witness so two poles at
    one location still order identically on every run — never on dict order,
    never on fid, never on insertion luck.
    """
    return sorted(
        items,
        key=lambda it: (-float(it["y"]), float(it["x"]),
                        it.get("witness") or "", _norm(it.get("label"))),
    )


class ResolveReport(object):
    """Outcome of binding a stored selection back to live features."""

    def __init__(self, resolved=None, missing=None, ambiguous=None):
        self.resolved = list(resolved or ())     # [{entry, feature}]
        self.missing = list(missing or ())       # [entry]
        self.ambiguous = list(ambiguous or ())   # [{entry, candidates}]

    @property
    def ok(self):
        return not self.missing and not self.ambiguous

    def counts(self):
        return {RESOLVED: len(self.resolved), MISSING: len(self.missing),
                AMBIGUOUS: len(self.ambiguous)}

    def __repr__(self):
        return "ResolveReport(%s)" % self.counts()


class PoleSelection(object):
    """An ordered, geometry-keyed set of poles.

    Order is capture order across rectangles: each batch appends, and within a
    batch poles sort top-to-bottom then left-to-right. A pole already present
    keeps its original position — re-dragging over it never reshuffles the
    list underneath the operator.
    """

    def __init__(self, precision=DEFAULT_PRECISION):
        self.precision = int(precision)
        self._entries = []          # ordered list of entry dicts
        self._pos = {}              # key -> index into _entries

    # -- construction --------------------------------------------------
    @staticmethod
    def _witness_of(entry):
        """Witness for an entry, computed ONCE and cached on first use.

        witness() sha1-digests every stable attribute; on the real pole layer
        that is 78 fields per pole, and computing it eagerly for a whole-layer
        selection cost 29 ms of a 121 ms refresh. It is only ever READ to tell
        two poles apart at one location — and most layers have no stacked poles
        at all — so it is computed lazily here instead.

        Same value, same behaviour; it is just not paid for until needed.
        """
        got = entry.get("witness")
        if got is None:
            got = witness(entry.get("_attrs"))
            entry["witness"] = got
        return got

    def _entry(self, item):
        key = pole_key(item["x"], item["y"], self.precision)
        return {
            "key": key,
            # deferred — see _witness_of(). None means "not computed yet",
            # which is distinct from "" (computed, and empty).
            "witness": None,
            # SNAPSHOT, not a reference. The eager version digested at capture
            # time; a lazy digest over the caller's live dict would silently
            # become an at-first-read digest if that dict were mutated in
            # between, and the witness is documented as capture-time.
            "_attrs": dict(item.get("attrs") or {}),
            # capture-time label: for MESSAGES only. Never used to resolve,
            # because a renumber is free to change it.
            "label": _norm(item.get("attrs", {}).get("Label")
                           or item.get("label")),
            "fid_hint": item.get("fid"),
            "x": float(item["x"]),
            "y": float(item["y"]),
        }

    def _prepare(self, items):
        prepared = [self._entry(it) for it in (items or ())]
        # de-duplicate WITHIN the batch, keeping the first occurrence
        seen, unique = set(), []
        for entry in prepared:
            if entry["key"] in seen:
                continue
            seen.add(entry["key"])
            unique.append(entry)
        return capture_order(unique)

    # -- selection semantics -------------------------------------------
    def replace(self, items):
        """Plain drag: this batch becomes the whole selection."""
        self._entries = []
        self._pos = {}
        return self.add(items)

    def add(self, items):
        """Shift-drag: append poles not already selected. Existing poles keep
        their position — returns how many were actually new."""
        added = 0
        for entry in self._prepare(items):
            if entry["key"] in self._pos:
                continue
            self._pos[entry["key"]] = len(self._entries)
            self._entries.append(entry)
            added += 1
        return added

    def remove(self, items):
        """Ctrl-drag: drop these poles, preserving the order of the rest."""
        drop = {pole_key(it["x"], it["y"], self.precision)
                for it in (items or ())}
        if not drop:
            return 0
        before = len(self._entries)
        self._entries = [e for e in self._entries if e["key"] not in drop]
        self._reindex()
        return before - len(self._entries)

    def intersect(self, items):
        """Shift+Ctrl drag: keep ONLY poles in both the selection and the drag.

        Matches Qgis.SelectBehavior.IntersectSelection. Survivors keep their
        existing capture order — intersect NARROWS a selection, it never
        reorders one. An empty result is legal and simply empties the
        selection; it is not an error and not a no-op.

        Returns how many entries were dropped.
        """
        keep = {pole_key(it["x"], it["y"], self.precision)
                for it in (items or ())}
        before = len(self._entries)
        self._entries = [e for e in self._entries if e["key"] in keep]
        self._reindex()
        return before - len(self._entries)

    def clear(self):
        n = len(self._entries)
        self._entries = []
        self._pos = {}
        return n

    def _reindex(self):
        self._pos = {e["key"]: i for i, e in enumerate(self._entries)}

    # -- manual reordering ---------------------------------------------
    def move(self, from_index, to_index):
        """Drag a row in the ordered list. Out-of-range is a no-op, never a
        crash and never a silent reshuffle."""
        n = len(self._entries)
        if not (0 <= from_index < n) or not (0 <= to_index < n):
            return False
        entry = self._entries.pop(from_index)
        self._entries.insert(to_index, entry)
        self._reindex()
        return True

    # -- inspection ----------------------------------------------------
    def __len__(self):
        return len(self._entries)

    def __contains__(self, key):
        return key in self._pos

    def keys(self):
        return [e["key"] for e in self._entries]

    def labels(self):
        return [e["label"] for e in self._entries]

    def entries(self):
        return [{k: v for k, v in e.items() if k != "_attrs"}
                for e in self._entries]

    def to_list(self):
        """Serialisable form — no fid is ever the identity, only a hint."""
        return [
            {"key": list(e["key"]), "witness": self._witness_of(e),
             "label": e["label"], "fid_hint": e["fid_hint"]}
            for e in self._entries
        ]

    # -- rebinding after a reload --------------------------------------
    def resolve(self, features):
        """Bind the stored selection back to live features BY GEOMETRY.

        features: iterable of {"fid","x","y","attrs"}.

        A key matching nothing is MISSING. A key matching several poles is
        disambiguated by the stable-attribute witness; if that still leaves
        more than one (as it does for the 11 real duplicate-geometry poles in
        PH2, which differ only by Label) the entry is AMBIGUOUS and the
        candidates are handed back. Nothing is ever guessed.
        """
        buckets = {}
        for feat in (features or ()):
            key = pole_key(feat["x"], feat["y"], self.precision)
            buckets.setdefault(key, []).append(feat)

        resolved, missing, ambiguous = [], [], []
        for entry in self._entries:
            candidates = buckets.get(entry["key"], [])
            if not candidates:
                missing.append(dict(entry))
                continue
            if len(candidates) == 1:
                resolved.append({"entry": dict(entry),
                                 "feature": candidates[0]})
                continue
            # only NOW is a witness needed — this is the sole reader, and it
            # runs only for a location holding more than one pole.
            want = self._witness_of(entry)
            narrowed = [c for c in candidates
                        if want and witness(c.get("attrs")) == want]
            if len(narrowed) == 1:
                resolved.append({"entry": dict(entry),
                                 "feature": narrowed[0]})
            else:
                ambiguous.append({"entry": dict(entry),
                                  "candidates": list(narrowed or candidates)})
        return ResolveReport(resolved, missing, ambiguous)


# ---------------------------------------------------------------------------
# map-tool facing helpers (pure, so the drag semantics are testable without Qt)
# ---------------------------------------------------------------------------

def select_mode_for_modifiers(shift, ctrl):
    """QGIS's own Select-by-Rectangle convention.

    plain        -> REPLACE    (Qgis.SelectBehavior.SetSelection)
    Shift        -> ADD        (AddToSelection)
    Ctrl         -> REMOVE     (RemoveFromSelection)
    Shift+Ctrl   -> INTERSECT  (IntersectSelection)

    HONEST LIMIT: the four SelectBehavior values were confirmed present in
    QGIS 4.0.3's Python bindings, but the modifier->behaviour mapping itself
    lives in C++ (qgsmaptoolselect.cpp) and is not reachable from Python, so
    it could not be OBSERVED headlessly — only matched to the documented
    convention. Needs one hands-on confirmation on the canvas.
    """
    if shift and ctrl:
        return INTERSECT
    if shift:
        return ADD
    if ctrl:
        return REMOVE
    return REPLACE


def selection_counts(selection, features):
    """What the operator must be told about a selection.

    A pole is identified by WHERE IT IS, so several poles stacked on one spot
    are one selectable entry. Reporting only the entry count would quietly
    under-report how many poles are really involved, so both numbers are
    surfaced: entries (distinct locations) and poles (rows behind them).
    """
    buckets = {}
    for feat in (features or ()):
        key = pole_key(feat["x"], feat["y"], selection.precision)
        buckets.setdefault(key, []).append(feat)
    entries = len(selection)
    poles = 0
    stacked = 0
    for key in selection.keys():
        n = len(buckets.get(key, ()))
        poles += n
        if n > 1:
            stacked += 1
    return {
        "entries": entries,          # distinct locations held
        "poles": poles,              # pole rows those locations contain
        "stacked_locations": stacked,        # locations holding >1 pole
        "collapsed": max(poles - entries, 0),  # rows hidden by stacking
    }


def ambiguous_locations(report):
    """The entries a human must resolve before anything may be renumbered."""
    return [
        {
            "key": item["entry"]["key"],
            "captured_label": item["entry"]["label"],
            "candidates": [
                _norm((c.get("attrs") or {}).get("Label"))
                for c in item["candidates"]
            ],
        }
        for item in (report.ambiguous or ())
    ]


def renumber_block_reason(report):
    """None when a renumber may proceed, else why it must not.

    Ambiguous entries BLOCK: the tool cannot tell which physical pole the
    operator picked, and picking one by label, fid or attribute coincidence
    would renumber the wrong pole while reporting success. Missing entries
    block too — they no longer exist to renumber.
    """
    if report is None:
        return None
    bits = []
    if report.ambiguous:
        n = len(report.ambiguous)
        poles = sum(len(i["candidates"]) for i in report.ambiguous)
        bits.append(
            "%d selected location%s hold%s %d poles that cannot be told apart "
            "(same position, and they differ only by a label a renumber would "
            "rewrite)" % (n, "" if n == 1 else "s", "s" if n == 1 else "",
                          poles))
    if report.missing:
        n = len(report.missing)
        bits.append("%d selected pole%s no longer in the layer"
                    % (n, "" if n == 1 else "s"))
    if not bits:
        return None
    return (
        "RENUMBER BLOCKED - " + "; ".join(bits) + ". Resolve these separately: "
        "move or delete the stacked poles, or deselect them. Nothing is "
        "renumbered while any selected pole is unresolved."
    )
