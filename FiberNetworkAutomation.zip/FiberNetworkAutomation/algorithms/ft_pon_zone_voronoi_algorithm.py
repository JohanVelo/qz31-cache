# Fibertime: Generate PON Zone Polygons (Voronoi) from clustered ONT points
# Reads pon_no from ONT v1, computes one centroid per PON cluster, generates
# a Voronoi diagram clipped to the AOI, then writes results to PON v1.

from collections import defaultdict

from qgis.core import (
    QgsProcessingParameterVectorLayer,
    QgsProcessing,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsSpatialIndex,
    QgsProject,
    NULL,
)

from .base_algorithm import BaseFiberAlgorithm


class FTPonZoneVoronoiAlgorithm(BaseFiberAlgorithm):
    """Generate PON zone boundary polygons from clustered ONT points using
    Voronoi regionalization.

    Reads pon_no (and zone_no) from the INPUT ONT layer, computes one
    geometric centroid per PON cluster, builds a Voronoi diagram over
    those centroids, clips each Voronoi cell to the AOI polygon, then
    bulk-inserts the resulting polygons into the 'PON v1' layer found
    in the current QGIS project.

    Each output feature carries: pon_no, zone_no, ont_count.
    """

    INPUT = 'INPUT'
    AOI   = 'AOI'

    # ------------------------------------------------------------------
    # Algorithm identity
    # ------------------------------------------------------------------

    def name(self):
        return 'ft_pon_zone_voronoi'

    def displayName(self):
        return 'FT 9. Generate PON Zone Polygons (Voronoi)'

    def group(self):
        return 'Fibertime Network Labeling'

    def groupId(self):
        return 'fibertimenetworklabeling'

    def createInstance(self):
        return FTPonZoneVoronoiAlgorithm()

    def shortHelpString(self):
        return """
        Generate PON zone boundary polygons from clustered ONT points using Voronoi
        regionalization.

        Reads pon_no (and zone_no) from the INPUT ONT v1 layer, computes one
        centroid per PON cluster, builds a Voronoi diagram over those centroids,
        clips each Voronoi cell to the AOI polygon, then bulk-inserts the results
        into the 'PON v1' layer found in the current QGIS project.

        Each output feature has: pon_no, zone_no, ont_count populated.

        Requirements:
        - shapely must be available in the QGIS Python environment (pip install shapely)
        - The current QGIS project must contain a layer named 'PON v1'
        - INPUT layer must have a populated 'pon_no' field (integer)
        - INPUT layer may optionally have a 'zone_no' field
        - AOI layer must be a single polygon (or multipolygon — first feature used)
        """

    # ------------------------------------------------------------------
    # Parameters
    # ------------------------------------------------------------------

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.INPUT,
            'ONT v1 (point layer with pon_no populated)',
            [QgsProcessing.SourceType.TypeVectorPoint]
        ))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.AOI,
            'AOI (polygon layer — clips Voronoi cells)',
            [QgsProcessing.SourceType.TypeVectorPolygon]
        ))

    # ------------------------------------------------------------------
    # Main processing
    # ------------------------------------------------------------------

    def processAlgorithm(self, parameters, context, feedback):
        # --- Import shapely (optional dep — fail clearly if missing) ---
        try:
            from shapely.ops import voronoi_diagram
            from shapely.geometry import MultiPoint, mapping
        except ImportError:
            feedback.reportError(
                "shapely is required for this algorithm but is not installed.\n"
                "Install it into the QGIS Python environment:\n"
                "    pip install shapely\n"
                "Then restart QGIS and try again.",
                fatalError=True,
            )
            return {}

        # --- Resolve input layers ---
        ont_layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        aoi_layer = self.parameterAsVectorLayer(parameters, self.AOI, context)

        if ont_layer is None:
            feedback.reportError("ONT layer not found.", fatalError=True)
            return {}
        if aoi_layer is None:
            feedback.reportError("AOI layer not found.", fatalError=True)
            return {}

        # --- Find PON v1 layer in current project ---
        pon_layer = self._find_pon_layer(feedback)
        if pon_layer is None:
            return {}

        # --- Resolve AOI geometry (first feature, union if multi) ---
        aoi_geom_qgs = self._load_aoi(aoi_layer, feedback)
        if aoi_geom_qgs is None:
            return {}

        # Convert AOI to shapely for Voronoi operations
        aoi_shapely = self._qgs_to_shapely(aoi_geom_qgs)

        # --- Read ONT points, group by pon_no ---
        feedback.pushInfo("Reading ONT points and grouping by pon_no...")
        clusters = self._load_ont_clusters(ont_layer, feedback)
        if not clusters:
            feedback.reportError("No valid ONT features with pon_no found.")
            return {}

        n_pons = len(clusters)
        feedback.pushInfo(f"Found {n_pons} distinct PON clusters across "
                          f"{sum(v['count'] for v in clusters.values())} ONTs.")

        if n_pons < 2:
            feedback.reportError(
                f"Voronoi requires at least 2 distinct PON clusters; found {n_pons}. "
                f"For a single PON, the whole AOI is the zone polygon — handle manually.",
                fatalError=True,
            )
            return {}

        if feedback.isCanceled():
            return {}

        # --- Compute one centroid per PON cluster ---
        feedback.pushInfo("Computing PON centroids...")
        centroids = {}  # pon_no -> {'x': float, 'y': float, 'zone_no': int, 'count': int}
        for pon_no, data in clusters.items():
            pts = data['pts']
            cx = sum(x for x, y in pts) / len(pts)
            cy = sum(y for x, y in pts) / len(pts)
            centroids[pon_no] = {
                'x': cx,
                'y': cy,
                'zone_no': data['zone_no'],
                'count': data['count'],
            }

        if feedback.isCanceled():
            return {}

        # --- Build Voronoi diagram using shapely ---
        feedback.pushInfo("Generating Voronoi diagram...")

        # Envelope for Voronoi: buffer the AOI proportionally to its own size so
        # it scales with the CRS units (a fixed 100 = 100 degrees in EPSG:4326,
        # which would blow the envelope up to most of the globe). Cells are clipped
        # back to the AOI below, so a larger-than-needed envelope is harmless.
        bounds = aoi_shapely.bounds  # (minx, miny, maxx, maxy)
        max_dim = max(bounds[2] - bounds[0], bounds[3] - bounds[1])
        envelope = aoi_shapely.buffer(max_dim * 0.5 if max_dim > 0 else 100)
        shapely_pts = [
            (info['x'], info['y']) for info in centroids.values()
        ]
        multipoint = MultiPoint(shapely_pts)

        try:
            diagram = voronoi_diagram(multipoint, envelope=envelope)
        except Exception as exc:
            feedback.reportError(f"Voronoi generation failed: {exc}", fatalError=True)
            return {}

        voronoi_polys = list(diagram.geoms)  # shapely Polygon list
        feedback.pushInfo(f"Generated {len(voronoi_polys)} Voronoi cells.")

        if feedback.isCanceled():
            return {}

        # --- Match each Voronoi cell to its PON centroid via spatial index ---
        # Build a QgsSpatialIndex over the centroids for fast nearest-neighbour
        centroid_index = QgsSpatialIndex()
        fid_to_pon = {}  # synthetic fid -> pon_no
        for fid, (pon_no, info) in enumerate(centroids.items()):
            feat = QgsFeature(fid)
            feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(info['x'], info['y'])))
            centroid_index.addFeature(feat)
            fid_to_pon[fid] = pon_no

        if feedback.isCanceled():
            return {}

        # --- Build output features for PON v1 ---
        feedback.pushInfo("Matching Voronoi cells to PON clusters and clipping to AOI...")
        pon_layer_fields = pon_layer.fields()

        # Identify target field indices (may not exist — warn and skip)
        pon_no_idx   = pon_layer_fields.indexOf('pon_no')
        zone_no_idx  = pon_layer_fields.indexOf('zone_no')
        ont_cnt_idx  = pon_layer_fields.indexOf('ont_count')

        new_features = []
        unmatched = 0

        for cell_idx, voronoi_poly in enumerate(voronoi_polys):
            if feedback.isCanceled():
                return {}

            feedback.setProgress(int(cell_idx / max(len(voronoi_polys), 1) * 90))

            # Find the centroid nearest to this cell's interior point
            try:
                rep_pt = voronoi_poly.representative_point()
            except Exception:
                rep_pt = voronoi_poly.centroid

            search_pt = QgsPointXY(rep_pt.x, rep_pt.y)
            nearest_fids = centroid_index.nearestNeighbor(search_pt, 1)
            if not nearest_fids:
                unmatched += 1
                continue

            pon_no = fid_to_pon[nearest_fids[0]]
            info   = centroids[pon_no]

            # Clip cell to AOI
            try:
                clipped = voronoi_poly.intersection(aoi_shapely)
            except Exception as exc:
                feedback.pushWarning(f"  PON {pon_no}: intersection failed ({exc}) — using unclipped cell")
                clipped = voronoi_poly

            if clipped is None or clipped.is_empty:
                feedback.pushWarning(f"  PON {pon_no}: clipped cell is empty — skipping")
                continue

            # Convert shapely geometry to QGIS
            try:
                cell_geom = QgsGeometry.fromWkt(clipped.wkt)
            except Exception as exc:
                feedback.pushWarning(f"  PON {pon_no}: WKT conversion failed ({exc}) — skipping")
                continue

            if not cell_geom or cell_geom.isEmpty():
                feedback.pushWarning(f"  PON {pon_no}: resulting QGIS geometry is empty — skipping")
                continue

            # Build the feature with PON v1's full field schema
            feat = QgsFeature(pon_layer_fields)
            feat.setGeometry(cell_geom)

            # Populate the three target fields if they exist
            attr_updates = {}
            if pon_no_idx != -1:
                attr_updates[pon_no_idx] = int(pon_no)
            if zone_no_idx != -1:
                # zone_no is deterministic from pon_no per the Phase 2 spec
                # (zone = (pon_no - 235) // 16 + 17). If the ONT layer carried no
                # zone_no value, derive it rather than writing NULL.
                if info['zone_no'] is not None:
                    attr_updates[zone_no_idx] = int(info['zone_no'])
                else:
                    attr_updates[zone_no_idx] = (int(pon_no) - 235) // 16 + 17
            if ont_cnt_idx != -1:
                attr_updates[ont_cnt_idx] = int(info['count'])

            # Apply the field values; everything else stays NULL/default
            for idx, val in attr_updates.items():
                feat.setAttribute(idx, val)

            new_features.append(feat)

        if feedback.isCanceled():
            return {}

        # --- Bulk insert into PON v1 ---
        feedback.pushInfo(f"Writing {len(new_features)} PON zone polygons to 'PON v1'...")
        ok, added = pon_layer.dataProvider().addFeatures(new_features)

        feedback.setProgress(100)

        if ok:
            pon_layer.updateExtents()
            feedback.pushInfo(
                f"[OK] Added {len(added)} PON zone polygons to 'PON v1'. "
                f"Run 'Refresh' on the layer to see results."
            )
        else:
            feedback.reportError(
                f"dataProvider().addFeatures() returned False. "
                f"{len(added)} features may still have been added."
            )

        if unmatched:
            feedback.pushWarning(f"{unmatched} Voronoi cells could not be matched to a PON centroid.")

        return {}

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _find_pon_layer(self, feedback):
        """Find the 'PON v1' layer in the current QGIS project."""
        for layer in QgsProject.instance().mapLayers().values():
            if layer.name() == 'PON v1':
                return layer
        feedback.reportError(
            "No layer named 'PON v1' found in the current QGIS project. "
            "Create the layer first (via the New Project wizard or manually) "
            "then re-run this algorithm.",
            fatalError=True,
        )
        return None

    def _load_aoi(self, aoi_layer, feedback):
        """Return the union geometry of all features in the AOI layer."""
        geoms = []
        for feat in aoi_layer.getFeatures():
            g = feat.geometry()
            if g and not g.isEmpty():
                geoms.append(g)

        if not geoms:
            feedback.reportError("AOI layer has no valid geometries.", fatalError=True)
            return None

        if len(geoms) == 1:
            return geoms[0]

        # Union all AOI features
        union = geoms[0]
        for g in geoms[1:]:
            union = union.combine(g)
        return union

    def _qgs_to_shapely(self, qgs_geom):
        """Convert a QgsGeometry to a shapely geometry via WKT."""
        try:
            from shapely.wkt import loads as shapely_loads
            return shapely_loads(qgs_geom.asWkt())
        except Exception as exc:
            raise RuntimeError(f"Failed to convert AOI geometry to shapely: {exc}") from exc

    def _load_ont_clusters(self, ont_layer, feedback):
        """
        Read all ONT features and group by pon_no.

        Returns:
            dict: {pon_no: {'pts': [(x, y), ...], 'zone_no': int|None, 'count': int}}
            Returns empty dict if no valid features found.
        """
        fields = ont_layer.fields()
        has_pon_no  = fields.indexOf('pon_no')  != -1
        has_zone_no = fields.indexOf('zone_no') != -1

        if not has_pon_no:
            feedback.reportError(
                "INPUT layer does not have a 'pon_no' field. "
                "Run FT 6 (Apply PON Order) first to populate pon_no.",
                fatalError=True,
            )
            return {}

        clusters = defaultdict(lambda: {'pts': [], 'zone_no': None, 'count': 0})

        total = ont_layer.featureCount()
        skipped_null_geom = 0
        skipped_null_pon  = 0

        for current, feat in enumerate(ont_layer.getFeatures()):
            if feedback.isCanceled():
                return {}

            if current % 500 == 0 and total > 0:
                feedback.setProgress(int(current / total * 10))  # 0-10% for reading

            # Skip null geometry
            g = feat.geometry()
            if not g or g.isEmpty():
                skipped_null_geom += 1
                continue

            # Skip null pon_no
            pon_no = feat['pon_no']
            if pon_no is None or pon_no == NULL:
                skipped_null_pon += 1
                continue

            pt = g.asPoint()
            clusters[pon_no]['pts'].append((pt.x(), pt.y()))
            clusters[pon_no]['count'] += 1

            if has_zone_no and clusters[pon_no]['zone_no'] is None:
                zn = feat['zone_no']
                if zn is not None and zn != NULL:
                    clusters[pon_no]['zone_no'] = zn

        if skipped_null_geom:
            feedback.pushWarning(f"Skipped {skipped_null_geom} ONT features with null geometry.")
        if skipped_null_pon:
            feedback.pushWarning(f"Skipped {skipped_null_pon} ONT features with null pon_no.")

        return dict(clusters)
