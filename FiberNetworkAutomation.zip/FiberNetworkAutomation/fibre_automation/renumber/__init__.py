"""renumber — delete features and renumber the survivors, order preserved.

`scan` finds the numbering systems, `plan` works out the change (read-only),
`apply` is the only writer.
"""
