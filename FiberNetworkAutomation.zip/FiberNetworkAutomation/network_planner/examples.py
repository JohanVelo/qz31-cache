"""Example script demonstrating how to use the FTTH routing core."""

from .core import NetworkGraph, build_network_from_files


def example_1_basic_routing():
    """Example 1: Basic routing with GeoJSON files."""
    print("=" * 60)
    print("Example 1: Basic Routing from GeoJSON Files")
    print("=" * 60)
    
    # Build network from sample data
    nodes_file = 'sample_data/nodes.geojson'
    ducts_file = 'sample_data/ducts.geojson'
    
    network = build_network_from_files(nodes_file, ducts_file)
    
    # Display graph info
    info = network.get_graph_info()
    print("\nNetwork Graph Info:")
    print(f"  Nodes: {info['nodes']}")
    print(f"  Edges: {info['edges']}")
    print(f"  Connected: {info['connected']}")
    
    # Calculate shortest path
    source = (-0.1, 51.5)     # Node A
    target = (-0.12, 51.51)   # Node D
    
    print(f"\nCalculating route from {source} to {target}...")
    path = network.shortest_path(source, target)
    
    print(f"Route found with {len(path)} waypoints:")
    for i, coord in enumerate(path):
        print(f"  {i+1}. {coord}")


def example_2_programmatic_graph():
    """Example 2: Building a graph programmatically."""
    print("\n" + "=" * 60)
    print("Example 2: Building Graph Programmatically")
    print("=" * 60)
    
    network = NetworkGraph()
    
    # Add nodes manually
    print("\nAdding nodes...")
    nodes = [
        ('A', (-0.1, 51.5)),
        ('B', (-0.105, 51.505)),
        ('C', (-0.115, 51.508)),
        ('D', (-0.12, 51.51))
    ]
    
    for node_id, coord in nodes:
        network.G.add_node(node_id, coord=coord, name=f"Node {node_id}")
        print(f"  Added node {node_id} at {coord}")
    
    # Add edges manually
    print("\nAdding edges...")
    edges = [
        ('A', 'B', 100),
        ('B', 'C', 150),
        ('C', 'D', 120),
        ('B', 'D', 200)  # Alternative route
    ]
    
    for u, v, length in edges:
        u_coord = network.G.nodes[u]['coord']
        v_coord = network.G.nodes[v]['coord']
        network.G.add_edge(u, v, length=length, weight=length)
        print(f"  Added edge {u}-{v} (length: {length})")
    
    # Find nearest nodes and calculate path
    print("\nFinding route...")
    source_coord = (-0.1, 51.5)
    target_coord = (-0.12, 51.51)
    
    path = network.shortest_path(source_coord, target_coord)
    print(f"Route: {' -> '.join([str(p) for p in path])}")


def example_3_analyze_network():
    """Example 3: Network analysis."""
    print("\n" + "=" * 60)
    print("Example 3: Network Analysis")
    print("=" * 60)
    
    # Build network
    network = build_network_from_files('sample_data/nodes.geojson', 'sample_data/ducts.geojson')
    
    # Get all nodes
    print("\nAll nodes in network:")
    for node_id, data in network.G.nodes(data=True):
        coord = data.get('coord', 'N/A')
        print(f"  {node_id}: {coord}")
    
    # Get all edges
    print("\nAll edges in network:")
    for u, v, data in network.G.edges(data=True):
        length = data.get('length', 0)
        print(f"  {u} -> {v}: {length:.2f}")
    
    # Calculate degree centrality
    print("\nNode connections:")
    for node_id in network.G.nodes():
        degree = network.G.degree(node_id)
        print(f"  {node_id}: {degree} connection(s)")


def example_4_multiple_routes():
    """Example 4: Calculate multiple routes."""
    print("\n" + "=" * 60)
    print("Example 4: Multiple Route Calculations")
    print("=" * 60)
    
    network = build_network_from_files('sample_data/nodes.geojson', 'sample_data/ducts.geojson')
    
    # Define multiple origin-destination pairs
    routes = [
        ((-0.1, 51.5), (-0.12, 51.51), "A to D"),
        ((-0.1, 51.5), (-0.115, 51.508), "A to C"),
        ((-0.105, 51.505), (-0.12, 51.51), "B to D"),
    ]
    
    print("\nCalculating multiple routes...\n")
    for source, target, description in routes:
        try:
            path = network.shortest_path(source, target)
            print(f"{description}:")
            print(f"  From: {source}")
            print(f"  To: {target}")
            print(f"  Waypoints: {len(path)}")
            print()
        except Exception as e:
            print(f"{description}: ERROR - {e}\n")


if __name__ == '__main__':
    # Run all examples
    example_1_basic_routing()
    example_2_programmatic_graph()
    example_3_analyze_network()
    example_4_multiple_routes()
    
    print("\n" + "=" * 60)
    print("All examples completed!")
    print("=" * 60)
