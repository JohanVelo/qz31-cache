"""defensive.py — small, dependency-free safety + UX helpers for shipped code.

Shippable: imports ONLY stdlib + native QGIS/Qt + sip (no third-party deps), so
it runs on every teammate's stock QGIS. Adds the patterns the 2026-06-19
reliability research flagged as missing:

  - safe_slot      : guard a bound-method Qt slot against a deleted C++ object
  - get_layer_safe : resolve a layer by name without IndexError; prefer a group
  - guard_geometry : validate/repair a geometry (buffer(0)); None if unusable
  - freeze_canvas  : context manager that suspends canvas redraws for bulk ops
  - fast_request   : build an optimised QgsFeatureRequest (NoGeometry/subset/bbox)
  - toast/info/warn/error/success : non-blocking QgsMessageBar messages
"""
from contextlib import contextmanager

try:
    from qgis.PyQt import sip
except Exception:  # pragma: no cover
    sip = None


def _is_deleted(obj):
    try:
        return sip is not None and sip.isdeleted(obj)
    except Exception:
        return False


def safe_slot(func):
    """Decorator for a bound-method Qt slot: no-op if `self` (a C++ wrapper) was
    already deleted, turning a hard segfault into a silent return."""
    def wrapper(self, *args, **kwargs):
        if _is_deleted(self):
            return None
        try:
            return func(self, *args, **kwargs)
        except RuntimeError as e:
            if "has been deleted" in str(e):
                return None
            raise
    wrapper.__name__ = getattr(func, "__name__", "slot")
    wrapper.__doc__ = func.__doc__
    return wrapper


def get_layer_safe(name, project=None, group=None, geom_type=None):
    """Resolve ONE vector layer by name without IndexError. If several share the
    name, optionally prefer one inside `group` (layer-tree group name) and/or of a
    given geometry type. Returns the layer or None."""
    from qgis.core import QgsProject
    project = project or QgsProject.instance()
    matches = list(project.mapLayersByName(name)) if name else []
    if not matches:
        return None
    if group:
        root = project.layerTreeRoot()

        def _in_group(layer):
            node = root.findLayer(layer.id())
            p = node.parent() if node else None
            while p is not None and p is not root:
                if p.name() == group:
                    return True
                p = p.parent()
            return False

        g = [l for l in matches if _in_group(l)]
        if g:
            matches = g
    if geom_type is not None:
        gt = [l for l in matches
              if getattr(l, "geometryType", lambda: None)() == geom_type]
        if gt:
            matches = gt
    return matches[0]


def guard_geometry(geom):
    """Return a usable geometry: None if empty/None; the geom if valid; else a
    buffer(0)-repaired copy if that yields a valid geometry; else None."""
    if geom is None or geom.isEmpty():
        return None
    try:
        if geom.isGeosValid():
            return geom
        fixed = geom.buffer(0, 1)
        if fixed and not fixed.isEmpty() and fixed.isGeosValid():
            return fixed
        return None
    except Exception:
        return None


@contextmanager
def freeze_canvas(iface=None):
    """Suspend map-canvas redraws for the duration of a bulk operation, then
    refresh once. Cuts N intermediate repaints to 1 (5-20x on large batches)."""
    canvas = None
    try:
        if iface is None:
            from qgis.utils import iface as _iface
            iface = _iface
        canvas = iface.mapCanvas() if iface else None
    except Exception:
        canvas = None
    if canvas is not None:
        try:
            canvas.freeze(True)
        except Exception:
            canvas = None
    try:
        yield
    finally:
        if canvas is not None:
            try:
                canvas.freeze(False)
                canvas.refresh()
            except Exception:
                pass


def fast_request(bbox=None, attributes=None, no_geometry=False,
                 expression=None, layer=None):
    """Build an optimised QgsFeatureRequest so iteration fetches only what's
    needed. bbox=QgsRectangle -> spatial filter; no_geometry=True -> skip geometry
    parsing; expression=str -> attribute filter; attributes=[names] (with layer)
    or [indexes] -> subset of attributes."""
    from qgis.core import QgsFeatureRequest
    req = QgsFeatureRequest()
    if bbox is not None:
        req.setFilterRect(bbox)
    if no_geometry:
        req.setFlags(QgsFeatureRequest.NoGeometry)
    if expression:
        req.setFilterExpression(expression)
    if attributes is not None:
        if layer is not None:
            idxs = [layer.fields().indexFromName(a) for a in attributes]
            idxs = [i for i in idxs if i >= 0]
            if idxs:
                req.setSubsetOfAttributes(idxs)
        else:
            req.setSubsetOfAttributes(attributes)
    return req


def toast(message, level="info", duration=5, title="Velocity Nexus", iface=None):
    """Non-blocking QgsMessageBar message (native; no third-party deps)."""
    try:
        from qgis.core import Qgis
        if iface is None:
            from qgis.utils import iface as _iface
            iface = _iface
        lv = {"info": Qgis.Info, "warn": Qgis.Warning, "warning": Qgis.Warning,
              "error": Qgis.Critical, "critical": Qgis.Critical,
              "success": Qgis.Success}.get(str(level).lower(), Qgis.Info)
        iface.messageBar().pushMessage(title, message, level=lv, duration=duration)
    except Exception:
        pass


def info(msg, **kw):
    toast(msg, "info", **kw)


def warn(msg, **kw):
    toast(msg, "warn", **kw)


def error(msg, **kw):
    toast(msg, "error", **kw)


def success(msg, **kw):
    toast(msg, "success", **kw)
