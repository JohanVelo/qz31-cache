"""runner — orchestrates Detect Buildings (local SAM) inside QGIS.

Fully generic: resolves the AOI, basemap, footprint boxes and (optional)
erven layer from WHATEVER the current project contains — no hardcoded
project names. Works for any area of interest.

Flow:
  1. resolve layers (AOI / basemap / buildings boxes / optional erven)
  2. if no footprint layer -> offer to download GOB/Overture for the AOI
  3. check the AI deps (torch+sam2) in the worker python; degrade gracefully
  4. render tiles (cancelable progress)
  5. run worker.py as a QProcess (SAM, per-erf union, regularize, classify)
  6. load the result styled by shape class + save a GPKG next to the project

No API keys or subscriptions: Meta SAM2 weights (Apache-2.0, auto-downloaded
once), Google Open Buildings / Overture (open data).
"""
from __future__ import annotations

import glob
import json
import os

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform, QgsFillSymbol, QgsProject, QgsRasterLayer,
    QgsRuleBasedRenderer, QgsVectorFileWriter, QgsVectorLayer, QgsWkbTypes,
    QgsCoordinateTransformContext,
)
from qgis.PyQt.QtCore import QProcess, Qt
from qgis.PyQt.QtWidgets import QApplication, QMessageBox, QProgressDialog

from .progress import DETECT_STAGES, ProgressDialog


try:
    from ..shared.vf_paths import data_file, project_output_dir, python_exe
except ImportError:
    from fibre_automation.shared.vf_paths import (
        data_file, project_output_dir, python_exe)

HERE = os.path.dirname(os.path.abspath(__file__))

SHAPE_STYLE = {
    "square":    ("46,204,113,160", "Square"),
    "rectangle": ("52,152,219,160", "Rectangle"),
    "L-shape":   ("243,156,18,170", "L-shape"),
    "complex":   ("155,89,182,170", "Complex"),
    "shack":     ("231,76,60,180",  "Shack (<35m²)"),
}
RESULT_LAYER = "Detected Buildings (SAM)"


def _clear_tiles(tiles_dir):
    """Remove only OUR scratch tile artifacts (never the whole directory)."""
    for pat in ("tile_*.png", "job_*.json", "parts_*.json", "manifest.json"):
        for p in glob.glob(os.path.join(tiles_dir, pat)):
            try:
                os.remove(p)
            except OSError:
                pass


def _polygon_layers():
    return [l for l in QgsProject.instance().mapLayers().values()
            if isinstance(l, QgsVectorLayer)
            and l.geometryType() == QgsWkbTypes.GeometryType.PolygonGeometry]


def _find_layer(name_parts, exclude=()):
    """First polygon layer whose name contains any of name_parts (ci)."""
    for l in _polygon_layers():
        n = l.name().lower()
        if any(x in n for x in exclude):
            continue
        if any(p in n for p in name_parts):
            return l
    return None


def _find_basemap():
    """Prefer a visible imagery raster; fall back to any raster layer."""
    proj = QgsProject.instance()
    root = proj.layerTreeRoot()
    rasters = [l for l in proj.mapLayers().values()
               if isinstance(l, QgsRasterLayer)]
    imagery = [l for l in rasters if any(
        k in l.name().lower()
        for k in ("satellite", "google", "bing", "esri", "imagery",
                  "aerial", "ortho"))]

    def visible(l):
        node = root.findLayer(l.id())
        return bool(node and node.isVisible())

    for pool in (imagery, rasters):
        vis = [l for l in pool if visible(l)]
        if vis:
            return vis[0]
        if pool:
            return pool[0]
    return None


class SamDetectRunner:
    """One instance per plugin; call run() from the menu action."""

    def __init__(self, iface, fallback=None):
        self.iface = iface
        self.fallback = fallback        # old GOB-only detection callable
        self.proc = None
        self.progress = None
        self._busy = False
        self._user_cancelled = False
        self._buf = ""                  # unterminated stdout tail
        self.tiles_dir = data_file("sam_detect_tiles")
        self.out_geojson = data_file("sam_detect_result.geojson")

    @staticmethod
    def _ckpt_path():
        """SAM checkpoint in a purge-safe location. %TEMP% gets cleaned by
        Windows Storage Sense -> repeated 150 MB downloads; ~/.velocityfibre
        survives. An existing copy in the data dir (dev machine) is reused."""
        legacy = data_file("sam2.1_hiera_tiny.pt")
        if os.path.isfile(legacy):
            return legacy
        return os.path.join(os.path.expanduser("~"), ".velocityfibre",
                            "sam2.1_hiera_tiny.pt")

    # ── resolution ──────────────────────────────────────────────────────────
    def _resolve(self):
        mw = self.iface.mainWindow()
        basemap = _find_basemap()
        if basemap is None:
            QMessageBox.warning(
                mw, "Detect Buildings",
                "No raster basemap found.\n\nAdd a satellite layer first "
                "(e.g. an XYZ 'Google Satellite' layer) — SAM reads the "
                "imagery from it.")
            return None

        erven = _find_layer(("erven", "erf", "parcel", "cadast", "stand"),
                            exclude=("erven sam", "erf house"))
        buildings = _find_layer(
            ("building", "gob", "footprint", "overture", "structure"),
            exclude=("sam", "detected"))

        aoi_layer = _find_layer(("aoi", "area of interest", "boundary"))
        c4 = QgsCoordinateReferenceSystem("EPSG:4326")
        proj = QgsProject.instance()
        if aoi_layer is not None:
            tr = QgsCoordinateTransform(aoi_layer.crs(), c4, proj)
            aoi = tr.transformBoundingBox(aoi_layer.extent())
            aoi_src = f"layer '{aoi_layer.name()}'"
        elif erven is not None:
            tr = QgsCoordinateTransform(erven.crs(), c4, proj)
            aoi = tr.transformBoundingBox(erven.extent())
            aoi_src = f"extent of '{erven.name()}'"
        else:
            canvas = self.iface.mapCanvas()
            tr = QgsCoordinateTransform(
                proj.crs() if proj.crs().isValid() else c4, c4, proj)
            aoi = tr.transformBoundingBox(canvas.extent())
            aoi_src = "current canvas view"
        return {"basemap": basemap, "erven": erven, "buildings": buildings,
                "aoi": aoi, "aoi_src": aoi_src}

    # ── footprint download (when the project has none) ──────────────────────
    def _fetch_footprints(self, aoi):
        """Download GOB/Overture footprints for the AOI via the bundled CLI."""
        mw = self.iface.mainWindow()
        out = data_file("sam_detect_footprints.geojson")
        script = os.path.normpath(os.path.join(HERE, "..", "detect_buildings.py"))
        args = [script, "--bbox",
                str(aoi.xMinimum()), str(aoi.yMinimum()),
                str(aoi.xMaximum()), str(aoi.yMaximum()), "--out", out]
        dlg = QProgressDialog("Downloading building footprints "
                              "(Google Open Buildings / Overture)…",
                              "Cancel", 0, 0, mw)
        dlg.setWindowTitle("Detect Buildings")
        dlg.setWindowModality(Qt.WindowModality.WindowModal)
        dlg.show()
        QApplication.processEvents()
        p = QProcess(mw)
        p.setWorkingDirectory(os.path.dirname(script))
        p.start(python_exe(), args)
        while not p.waitForFinished(200):
            QApplication.processEvents()
            if dlg.wasCanceled():
                p.kill()
                p.waitForFinished(3000)
                dlg.close()
                return None
        dlg.close()
        if p.exitCode() != 0 or not os.path.isfile(out):
            # the CLI prints its diagnostics to stdout — capture both streams
            detail = (bytes(p.readAllStandardError()).decode("utf-8", "replace")
                      + "\n"
                      + bytes(p.readAllStandardOutput()).decode("utf-8",
                                                                "replace"))
            detail = detail.strip()[-700:]
            try:
                try:
                    from ... import error_reporter
                except ImportError:
                    import error_reporter
                error_reporter.log_error(
                    "Detect Buildings footprint download",
                    RuntimeError(detail or f"exit {p.exitCode()}"))
            except Exception:
                pass
            QMessageBox.warning(
                mw, "Detect Buildings",
                "Footprint download failed (internet needed for open "
                "data).\n\n" + (detail or "no detail — see error log") +
                "\n\nLogged — Velocity Nexus menu → Report a Problem.")
            return None
        vl = QgsVectorLayer(out, "Building footprints (open data)", "ogr")
        if not vl.isValid() or vl.featureCount() == 0:
            QMessageBox.warning(mw, "Detect Buildings",
                                "No footprints found for this AOI.")
            return None
        QgsProject.instance().addMapLayer(vl)
        return vl

    # ── deps ─────────────────────────────────────────────────────────────────
    def _check_ai_deps(self):
        """Import-test the worker python. Pumps events while waiting — a cold
        torch import can take 10-20 s on a laptop and must not freeze QGIS."""
        p = QProcess()
        p.start(python_exe(),
                ["-c", "import torch, sam2, rasterio, shapely, scipy, PIL, "
                       "geopandas"])
        waited = 0
        while not p.waitForFinished(200) and waited < 60000:
            waited += 200
            QApplication.processEvents()
        if p.state() != QProcess.ProcessState.NotRunning:
            # timed out (cold torch import on a slow machine) — don't leave a
            # runaway child behind that would be killed later when p is GC'd
            p.kill()
            p.waitForFinished(2000)
        return p.exitCode() == 0 and p.state() == QProcess.ProcessState.NotRunning

    # ── main entry ───────────────────────────────────────────────────────────
    def run(self):
        mw = self.iface.mainWindow()
        if self._busy or (self.proc is not None
                          and self.proc.state() != QProcess.ProcessState.NotRunning):
            QMessageBox.information(mw, "Detect Buildings",
                                    "A detection run is already in progress.")
            return
        self._busy = True
        try:
            self._run_inner(mw)
        except Exception:
            self._busy = False
            raise
        if self.proc is None:
            self._busy = False      # finished synchronously (no worker phase)

    def _run_inner(self, mw):
        ctx = self._resolve()
        if ctx is None:
            return

        # sanity: a huge AOI usually means no AOI layer was found and the
        # canvas was zoomed out — tiling/downloading the world helps nobody
        import math
        a = ctx["aoi"]
        km2 = (abs(a.width()) * 111.32
               * abs(a.height()) * 111.32
               * abs(math.cos(math.radians(a.center().y()))))
        if km2 > 1500:
            QMessageBox.warning(
                mw, "Detect Buildings",
                f"The area of interest works out to ~{km2:,.0f} km² "
                f"(source: {ctx['aoi_src']}) — that is far too large for a "
                "detection run.\n\nAdd an AOI polygon layer to the project "
                "(name containing 'AOI'), or zoom the canvas to the project "
                "area first.")
            return

        bld_txt = (f"'{ctx['buildings'].name()}'" if ctx["buildings"]
                   else "none — will download open-data footprints")
        erf_txt = (f"'{ctx['erven'].name()}' → one house per erf"
                   if ctx["erven"] else "none — one polygon per building")
        msg = ("Detect buildings with local AI (SAM2 — no subscription "
               "needed)?\n\n"
               f"AOI:        {ctx['aoi_src']}\n"
               f"Basemap:    '{ctx['basemap'].name()}'\n"
               f"Footprints: {bld_txt}\n"
               f"Erven:      {erf_txt}\n\n"
               "Output: shape-classified building polygons "
               "(square / rectangle / L-shape / complex / shack).")
        if QMessageBox.question(mw, "Detect Buildings (AI)", msg,
                                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                QMessageBox.StandardButton.Yes) != QMessageBox.StandardButton.Yes:
            return

        # deps BEFORE the footprint fetch — the fetch itself needs geopandas,
        # so on a fresh machine the install offer must come first
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            ai_ok = self._check_ai_deps()
        finally:
            QApplication.restoreOverrideCursor()
        if not ai_ok:
            box = QMessageBox(mw)
            box.setWindowTitle("Detect Buildings")
            box.setIcon(QMessageBox.Icon.Question)
            box.setText(
                "The AI components (PyTorch + SAM2) are not installed on "
                "this machine yet.\n\n"
                "Install them now? One-time, ~400 MB download, no admin "
                "rights or subscriptions needed — QGIS stays usable while "
                "it runs. When it finishes, click Detect Buildings again.")
            install_btn = box.addButton("Install now (recommended)",
                                        QMessageBox.ButtonRole.AcceptRole)
            raw_btn = box.addButton("Use raw footprints only",
                                    QMessageBox.ButtonRole.DestructiveRole)
            box.addButton(QMessageBox.StandardButton.Cancel)
            box.exec()
            clicked = box.clickedButton()
            if clicked is install_btn:
                from .installer import get_installer
                get_installer(self.iface).run()
            elif clicked is raw_btn and self.fallback:
                self.fallback()
            return

        if ctx["buildings"] is None:
            ctx["buildings"] = self._fetch_footprints(ctx["aoi"])
            if ctx["buildings"] is None:
                return

        # ── tiling (with resume: skip when the previous run matches) ─────────
        os.makedirs(self.tiles_dir, exist_ok=True)
        a = ctx["aoi"]
        manifest = {
            "aoi": [round(a.xMinimum(), 6), round(a.yMinimum(), 6),
                    round(a.xMaximum(), 6), round(a.yMaximum(), 6)],
            "basemap": ctx["basemap"].name() + "|" + ctx["basemap"].source(),
            "buildings": (ctx["buildings"].name() + "|"
                          + ctx["buildings"].source()),
            "bcount": int(ctx["buildings"].featureCount()),
            "erven": (ctx["erven"].name() + "|" + ctx["erven"].source()
                      if ctx["erven"] else None),
            "ecount": (int(ctx["erven"].featureCount())
                       if ctx["erven"] else None),
        }
        mpath = os.path.join(self.tiles_dir, "manifest.json")
        resume = False
        try:
            if os.path.isfile(mpath):
                with open(mpath, encoding="utf-8") as f:
                    old = json.load(f)
                n_jobs = len(glob.glob(os.path.join(self.tiles_dir,
                                                    "job_*.json")))
                n_parts = len(glob.glob(os.path.join(self.tiles_dir,
                                                     "parts_*.json")))
                if (old == manifest and n_jobs > 0 and n_parts > 0
                        and QMessageBox.question(
                            mw, "Detect Buildings",
                            f"A previous run for this same AOI left "
                            f"{n_parts}/{n_jobs} tiles of finished AI work.\n\n"
                            "Reuse it (much faster) instead of starting "
                            "fresh?",
                            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                            QMessageBox.StandardButton.Yes) == QMessageBox.StandardButton.Yes):
                    resume = True
        except Exception:
            resume = False

        if resume:
            info = {"total": len(glob.glob(os.path.join(
                self.tiles_dir, "job_*.json"))), "boxes": -1}
            if info["total"] == 0:          # nothing to resume — don't launch on empty
                QMessageBox.warning(
                    mw, "Detect Buildings",
                    "No tile jobs were found to resume. Run detection fresh.")
                return
        else:
            _clear_tiles(self.tiles_dir)
            from . import tiler
            # One accurate bar for the whole run (tiles -> AI -> polygons).
            self.progress = ProgressDialog(mw, "Detect Buildings", DETECT_STAGES)
            self.progress.set_stage("tiles", "starting…")
            self.progress.show()
            _p = self.progress

            def cb(i, total):
                _p.set_sub("tiles", i + 1, total,
                           detail=f"tile {i + 1}/{total}")
                return not _p.wasCanceled()

            info = tiler.render_tiles(ctx["basemap"], ctx["buildings"],
                                      ctx["erven"], ctx["aoi"], self.tiles_dir,
                                      progress_cb=cb)
            if info.get("cancelled"):
                if self.progress is not None:
                    self.progress.close()
                    self.progress = None
                self.iface.messageBar().pushInfo("Detect Buildings",
                                                 "Cancelled.")
                return
            if info["boxes"] == 0:
                self._close_progress()
                QMessageBox.warning(
                    mw, "Detect Buildings",
                    "No building footprints fall inside the AOI — nothing to "
                    "detect. Check the AOI and footprint layer.")
                return
            if info.get("blank_tiles"):
                if QMessageBox.question(
                        mw, "Detect Buildings",
                        f"{info['blank_tiles']} of {info['total']} imagery "
                        "tiles came back EMPTY (satellite imagery did not "
                        "download in time) — houses there would be missed.\n\n"
                        "Tip: pan/zoom across the area once so QGIS caches "
                        "the imagery, or add a local orthophoto (GeoTIFF) to "
                        "the project, then run again.\n\n"
                        "Continue anyway with the gaps?",
                        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                        QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
                    self._close_progress()
                    return
            try:
                with open(mpath, "w", encoding="utf-8") as f:
                    json.dump(manifest, f)
            except OSError:
                pass

        # ── SAM worker (async QProcess) ──────────────────────────────────────
        self._n_tiles = info["total"]
        self._result = None
        if self.progress is None:           # resume path skipped the tiling bar
            self.progress = ProgressDialog(mw, "Detect Buildings", DETECT_STAGES)
            self.progress.show()
        self.progress.set_stage("ai", f"0/{info['total']} tiles")
        try:
            self.progress._cancel.clicked.connect(self._cancel_worker)
        except Exception:
            pass

        if os.path.isfile(self.out_geojson):
            try:
                os.remove(self.out_geojson)
            except OSError:
                pass
        self._user_cancelled = False
        self._buf = ""
        self.proc = QProcess(mw)
        self.proc.setWorkingDirectory(HERE)
        self.proc.readyReadStandardOutput.connect(self._on_stdout)
        self.proc.finished.connect(self._on_finished)
        self.proc.errorOccurred.connect(self._on_proc_error)
        self.proc.start(python_exe(),
                        [os.path.join(HERE, "worker.py"),
                         self.tiles_dir, self.out_geojson, self._ckpt_path()])

    # ── worker callbacks ─────────────────────────────────────────────────────
    def _close_progress(self):
        if self.progress is not None:
            try:
                self.progress.close()
            except Exception:
                pass
            self.progress = None

    def _cancel_worker(self):
        if self.proc is not None and self.proc.state() != QProcess.ProcessState.NotRunning:
            self._user_cancelled = True
            self.proc.kill()

    def _on_proc_error(self, error):
        """FailedToStart etc. — 'finished' never fires, so clean up here."""
        if error != QProcess.ProcessError.FailedToStart:
            return                      # crashes still emit finished()
        if self.progress is not None:
            self.progress.close()
            self.progress = None
        self.proc = None
        self._busy = False
        QMessageBox.warning(
            self.iface.mainWindow(), "Detect Buildings",
            f"Could not start the worker Python:\n{python_exe()}\n\n"
            "Check that Python is installed for the plugin (see Team guide).")

    def _parse_stdout(self, data):
        self._buf += data
        lines = self._buf.split("\n")
        self._buf = lines.pop()         # keep unterminated tail for next chunk
        for line in lines:
            line = line.strip()
            if line.startswith("PROG ") and self.progress is not None:
                rest = line[5:]
                if rest.startswith("download"):
                    self.progress.set_stage(
                        "ai", "Downloading SAM2 model (~150 MB, one-time)…")
                elif rest.startswith("regularize"):
                    self.progress.set_stage(
                        "finish", "Regularizing + classifying shapes…")
                elif "/" in rest:
                    try:
                        i = int(rest.split("/")[0].split()[-1])
                        self.progress.set_sub("ai", i, self._n_tiles,
                                              detail=f"tile {rest}")
                    except (ValueError, IndexError):
                        pass
            elif line.startswith("RESULT "):
                try:
                    self._result = json.loads(line[7:])
                except ValueError:
                    pass

    def _on_stdout(self):
        if self.proc is None:
            return
        self._parse_stdout(
            bytes(self.proc.readAllStandardOutput()).decode("utf-8", "replace"))

    def _on_finished(self, code, _status):
        if self.proc is not None:       # drain any final RESULT line
            self._parse_stdout(
                bytes(self.proc.readAllStandardOutput())
                .decode("utf-8", "replace") + "\n")
        if self.progress is not None:
            self.progress.close()
            self.progress = None
        self._busy = False
        if self._user_cancelled:
            self.proc = None
            self.iface.messageBar().pushInfo("Detect Buildings", "Cancelled.")
            return
        if code != 0:
            # self.proc is always live here (the cancel branch above returns),
            # so read stderr unconditionally before clearing it.
            err = bytes(self.proc.readAllStandardError())\
                .decode("utf-8", "replace")[-800:]
            self.proc = None
            QMessageBox.warning(
                self.iface.mainWindow(), "Detect Buildings",
                f"AI detection failed (exit {code}).\n\n{err}")
            return
        self.proc = None
        self._load_result()

    # ── result ───────────────────────────────────────────────────────────────
    def _load_result(self):
        mw = self.iface.mainWindow()
        if not os.path.isfile(self.out_geojson):
            QMessageBox.warning(mw, "Detect Buildings",
                                "Worker finished but produced no output.")
            return
        proj = QgsProject.instance()

        # drop the previous result layer FIRST — it holds the GPKG open,
        # and an open GPKG cannot be overwritten on Windows
        for l in list(proj.mapLayers().values()):
            if l.name() == RESULT_LAYER:
                proj.removeMapLayer(l.id())

        # GPKG beside the project (fall back to geojson if locked)
        out_dir = project_output_dir()
        gpkg = os.path.join(out_dir, "Detected_Buildings_SAM.gpkg")
        src = QgsVectorLayer(self.out_geojson, "tmp", "ogr")
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = "GPKG"
        opts.layerName = "detected_buildings_sam"
        opts.actionOnExistingFile = QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteFile
        err = QgsVectorFileWriter.writeAsVectorFormatV3(
            src, gpkg, QgsCoordinateTransformContext(), opts)
        gpkg_ok = err[0] == QgsVectorFileWriter.WriterError.NoError
        uri = self.out_geojson
        if gpkg_ok:
            uri = f"{gpkg}|layername=detected_buildings_sam"

        vl = QgsVectorLayer(uri, RESULT_LAYER, "ogr")
        if not vl.isValid():
            vl = QgsVectorLayer(self.out_geojson, RESULT_LAYER, "ogr")
        if not vl.isValid():
            QMessageBox.warning(mw, "Detect Buildings",
                                "Could not load the result layer.")
            return
        # Rule-based: review-flagged features (circles / merges / rescues the
        # cleanup couldn't confirm) render as a HOLLOW orange ⚠ outline so they
        # recede on the canvas and read as "check me" — never as a solid
        # confirmed building. Everything else keeps its shape-class colour.
        root = QgsRuleBasedRenderer.Rule(None)
        rev = QgsFillSymbol.createSimple(
            {"color": "0,0,0,0", "style": "no", "outline_color": "255,140,0",
             "outline_width": "0.6", "outline_style": "dash"})
        root.appendChild(QgsRuleBasedRenderer.Rule(
            rev, filterExp='coalesce("flag_for_review",0) = 1',
            label="⚠ Review (uncertain — circle / merge / rescue)"))
        for key, (rgba, label) in SHAPE_STYLE.items():
            sym = QgsFillSymbol.createSimple(
                {"color": rgba, "outline_color": "255,255,255,200",
                 "outline_width": "0.2"})
            root.appendChild(QgsRuleBasedRenderer.Rule(
                sym, filterExp=f"\"shape\" = '{key}' AND coalesce(\"flag_for_review\",0) = 0",
                label=label))
        vac = QgsFillSymbol.createSimple(
            {"color": "0,0,0,0", "outline_color": "0,230,230",
             "outline_width": "0.35", "style": "no"})
        root.appendChild(QgsRuleBasedRenderer.Rule(
            vac, filterExp="\"shape\" = 'vacant'", label="Vacant erf"))
        # catch-all "else" so any unexpected value still renders (never vanishes)
        other = QgsFillSymbol.createSimple(
            {"color": "200,200,200,140", "outline_color": "120,120,120",
             "outline_width": "0.2"})
        else_rule = QgsRuleBasedRenderer.Rule(other, label="Other")
        else_rule.setActive(True)
        try:
            else_rule.setIsElse(True)
        except Exception:
            pass
        root.appendChild(else_rule)
        vl.setRenderer(QgsRuleBasedRenderer(root))
        proj.addMapLayer(vl)

        res = self._result or {}
        shapes = res.get("shapes", {})
        summary = ", ".join(f"{v} {k}" for k, v in sorted(
            shapes.items(), key=lambda kv: -kv[1]) if k != "vacant")
        n_dedup = res.get("deduped", 0)
        if n_dedup:
            # overlapping duplicates removed by the global cleanup pass
            summary += f" · −{n_dedup} duplicates removed"
        n_resc = res.get("rescued", 0)
        if n_resc:
            # candidates recovered on stands the footprint source (GOB/Overture)
            # missed — flagged for REVIEW (filter flag_for_review=1 / source=
            # 'rescue') so you confirm/delete before they count as homes
            summary += (f" · +{n_resc} to REVIEW (footprint-missed — filter "
                        f"flag_for_review=1)")
        saved = (f"Saved: {gpkg}" if gpkg_ok
                 else "GPKG could not be written (file in use) — layer "
                      "loaded from the working GeoJSON instead.")
        self.iface.messageBar().pushSuccess(
            "Detect Buildings",
            f"{vl.featureCount()} features loaded ({summary}). {saved}")
