"""dialog — the "Delete + Renumber" UI. All the Qt lives here; the dock gets one button.

Three questions, in the order you'd ask them out loud:
  1. which PONs are going?
  2. what inside them goes with them?
  3. which numbers close up afterwards?

Then Preview (read-only) → Back up + Apply.

The renumber tick-boxes default to PON + SP only, and DR/DC/DJ show their own
"N gaps already exist → ~X labels" count. That is not timidity: compacting drops
on Malmsbury rewrites ~2,853 labels from gaps that were there before you deleted
anything, and those labels are on field records and BOQs already sent. The
capability is all there — it just doesn't get switched on behind your back.
"""
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QFont
from qgis.PyQt.QtWidgets import (QAbstractItemView, QApplication, QCheckBox,
                                 QDialog, QFrame, QGridLayout, QHBoxLayout,
                                 QHeaderView, QLabel, QListWidget,
                                 QListWidgetItem, QMessageBox, QPushButton,
                                 QScrollArea, QTableWidget, QTableWidgetItem,
                                 QVBoxLayout, QWidget)

try:
    from . import apply as _apply
    from . import plan as _plan
    from . import scan as _scan
except ImportError:                                    # pragma: no cover
    import apply as _apply
    import plan as _plan
    import scan as _scan


# Layers a PON OWNS — remove the PON and these go with it. Auto-ticked.
_PON_OWNED_HINTS = ("splitter", "dome joint", "feeder joint", "drop",
                    "demand", "distribution")

# Everything else (Erven, poles, AOI, Phases, the feeder trunk, manholes,
# trenching, core) is SHARED or base data: an erf exists whether or not fibre is
# built there, and a pole inside PON 32 may carry the feeder that serves PON 33.
# Those are listed with their live count but never auto-ticked — deleting them is
# a decision, not a default.
def _is_pon_owned(layer_name):
    n = (layer_name or "").lower()
    return any(h in n for h in _PON_OWNED_HINTS)


def _theme_colors(widget=None):
    """theme_safe.colors() with layered imports (see zone_tag_dialog for the why)."""
    for imp in ("grandparent", "absolute", "parent", "flat"):
        try:
            if imp == "grandparent":
                from ... import theme_safe
            elif imp == "absolute":
                from FiberNetworkAutomation import theme_safe
            elif imp == "parent":
                from .. import theme_safe
            else:
                import theme_safe
            return theme_safe.colors(widget)
        except Exception:
            continue
    return {"bg": "#ffffff", "ink": "#000000", "muted": "#444444",
            "accent": "#006688", "warn": "#885500", "ok": "#116633",
            "bad": "#aa2222"}


_BTN = ("QPushButton {{ background-color: {bg}; color: white; font-weight: bold; "
        "padding: 7px 18px; border-radius: 5px; }}"
        "QPushButton:hover {{ background-color: {hov}; }}"
        "QPushButton:disabled {{ background-color: #777; color: #ddd; }}")


def _hline(c):
    f = QFrame()
    f.setFrameShape(QFrame.Shape.HLine)
    f.setStyleSheet(f"color:{c['muted']};")
    return f


def _section(text, c):
    lbl = QLabel(text)
    lbl.setStyleSheet(f"color:{c['muted']};font-size:9pt;font-weight:bold;"
                      "letter-spacing:1px;")
    return lbl


class DeleteRenumberDialog(QDialog):
    def __init__(self, project, parent=None):
        super().__init__(parent)
        self.project = project
        self._c = _theme_colors(self)
        self._pon_rows = []       # (number, QCheckBox)
        self._cascade_rows = []   # (layer_id, QCheckBox)
        self._sys_rows = []       # (system_name, QCheckBox)
        self._user_touched = set()   # cascade rows JJ set himself — never auto-override
        # QListWidgetItem.setText/setFlags/setCheckState ALL emit itemChanged —
        # the same signal a real click emits. Without this guard my own refresh
        # marks every row as "user touched" and the auto-tick never fires.
        self._refreshing = False

        self.setWindowTitle("Delete + Renumber  (BETA)")
        self.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
            Qt.WindowType.WindowCloseButtonHint |
            Qt.WindowType.CustomizeWindowHint |
            Qt.WindowType.WindowMaximizeButtonHint)
        self.setMinimumSize(820, 720)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            self.scans = _scan.scan_project(project)
            # one containment pass up front → ticking a PON is then instant
            self._contain, self._per_pon = self._build_containment()
        finally:
            QApplication.restoreOverrideCursor()
        self._build()

    # ── build ────────────────────────────────────────────────────────────────
    def _build(self):
        c = self._c
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(8)

        title = QLabel("🔢  Delete + Renumber")
        f = QFont()
        f.setBold(True)
        f.setPointSize(14)
        title.setFont(f)
        title.setStyleSheet(f"color:{c['accent']};")
        lay.addWidget(title)

        beta = QLabel(
            "⚠ BETA — this deletes features and rewrites labels. Run it on a COPY "
            "of the project until you're happy with it. A backup is written before "
            "anything changes; if the backup fails, nothing is touched.")
        beta.setWordWrap(True)
        beta.setStyleSheet(
            f"QLabel {{ background-color:#2a1e08; color:{c['warn']}; "
            "border:1px solid #6b5320; border-left:4px solid #e0a33a; "
            "border-radius:4px; padding:5px 7px; font-size:9pt; }}")
        lay.addWidget(beta)

        probs = _scan.validate(self.scans)
        if probs:
            box = QLabel("⚠  " + "\n⚠  ".join(probs))
            box.setWordWrap(True)
            box.setStyleSheet(f"color:{c['warn']};font-size:8.5pt;")
            lay.addWidget(box)

        lay.addWidget(_hline(c))

        # ── 1. PONs to remove
        lay.addWidget(_section("// 1 · REMOVE THESE PONs", c))
        lay.addWidget(self._pon_list(), 2)

        # ── 2. cascade (fills itself in from the PONs picked above)
        lay.addWidget(_section("// 2 · CASCADE INTO  (found automatically)", c))
        lay.addWidget(self._cascade_list(), 2)
        self._cascade_hint = QLabel("tick a PON above and this fills in by itself")
        self._cascade_hint.setStyleSheet(f"color:{c['muted']};font-size:8.5pt;")
        lay.addWidget(self._cascade_hint)

        # ── 3. renumber
        lay.addWidget(_section("// 3 · RENUMBER  (close the gaps)", c))
        lay.addWidget(self._systems_grid(), 1)

        lay.addWidget(_hline(c))
        btns = QHBoxLayout()
        cancel = QPushButton("Cancel")
        cancel.setStyleSheet(_BTN.format(bg="#6b5320", hov="#8a6c2a"))
        cancel.clicked.connect(self.reject)
        self._preview_btn = QPushButton("Preview ▸")
        self._preview_btn.setStyleSheet(_BTN.format(bg="#1a6b3c", hov="#238a4f"))
        self._preview_btn.setDefault(True)
        self._preview_btn.clicked.connect(self._on_preview)
        btns.addWidget(cancel)
        btns.addStretch(1)
        btns.addWidget(self._preview_btn)
        lay.addLayout(btns)
        self._refresh()

    def _build_containment(self):
        """What belongs to every PON — computed ONCE, then filtered per tick.

        Delegates to plan.build_containment so the count shown here IS the count
        the planner deletes — one implementation, they cannot drift apart.
        "Belongs" = inside the polygon OR naming the PON (`_SP32`), because PON
        32's feeder joint sits just outside P032 and would otherwise be missed.
        """
        return _plan.build_containment(self.project, self.scans)

    def _inside_count(self, lid, doomed):
        """How many features in `lid` go if `doomed` is removed.

        A feature only goes if EVERY PON it belongs to is being removed — a cable
        crossing a surviving PON still serves it. Same rule as the planner, so
        this count IS the delete count.
        """
        if not doomed:
            return 0
        return sum(1 for pons in self._contain.get(lid, {}).values()
                   if _plan.belongs_wholly_to(pons, doomed))

    def _pon_list(self):
        """Every PON with what sits inside it, so the cost is visible up front."""
        lst = QListWidget()
        lst.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        sc = self.scans.get("PON")
        for n in (sc.distinct if sc else []):
            inside = self._per_pon.get(n, {})
            bits = "  ·  ".join(f"{v:,} {k}" for k, v in sorted(inside.items()) if v)
            it = QListWidgetItem(f"P{n:03d}      {bits or '—'}")
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(Qt.CheckState.Unchecked)
            it.setData(Qt.ItemDataRole.UserRole, n)
            lst.addItem(it)
        lst.itemChanged.connect(lambda _i: self._refresh())
        self._pon_list_w = lst
        return lst

    def _cascade_list(self):
        """Auto-ticks itself from the PONs you pick — no hunting.

        Counts are LIVE ("16 inside"), not the layer total, and only the PON's own
        gear is auto-ticked. Anything you click yourself is remembered and never
        auto-overridden again.
        """
        try:
            from ..tagging import zone_tag
        except ImportError:                       # pragma: no cover
            from fibre_automation.tagging import zone_tag
        lst = QListWidget()
        lst.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        sc = self.scans.get("PON")
        poly_id = sc.occurrences[0].layer_id if (sc and sc.occurrences) else None
        self._cascade_items = []
        self._cascade_names = {}
        for lyr in zone_tag.target_layers(self.project):
            if lyr.id() == poly_id:
                continue
            it = QListWidgetItem(f"{lyr.name()}     ·  —")
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(Qt.CheckState.Unchecked)
            it.setData(Qt.ItemDataRole.UserRole, lyr.id())
            lst.addItem(it)
            self._cascade_items.append((lyr.id(), it))
            self._cascade_names[lyr.id()] = lyr.name()
        lst.itemChanged.connect(self._on_cascade_toggled)
        self._cascade_w = lst
        return lst

    def _on_cascade_toggled(self, item):
        """A row JJ clicked himself is his — never auto-change it again.

        Ignored while _refresh is running: setText/setFlags emit this same signal,
        so without the guard our own repaint would look like a user click and
        freeze every row at whatever it happened to be.
        """
        if self._refreshing:
            return
        lid = item.data(Qt.ItemDataRole.UserRole)
        if lid is not None:
            self._user_touched.add(lid)
        self._update_preview_btn()

    def _systems_grid(self):
        """Per-system tick + its honest blast radius."""
        c = self._c
        host = QWidget()
        grid = QGridLayout(host)
        grid.setContentsMargins(2, 2, 2, 2)
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(4)
        for col, t in enumerate(("", "System", "Now", "If you tick it")):
            h = QLabel(t)
            h.setStyleSheet(f"color:{c['muted']};font-size:8.5pt;font-weight:bold;")
            grid.addWidget(h, 0, col)

        row = 1
        # The id columns are one system PER LAYER, but nobody wants ten tick-boxes
        # for "the row numbers" — they're one idea. Collapse them into a single
        # row whose count is the total across every table.
        id_names = [n for n in self.scans if n.startswith(_scan.ID_PREFIX)]
        if id_names:
            cb = QCheckBox()
            cb.setChecked(True)          # JJ: "no gaps ... in all of the attribute tables"
            cb.stateChanged.connect(lambda _s: self._refresh())
            lbl = QLabel("ID — the id column in every attribute table")
            n_gap = sum(len(self.scans[n].gaps) for n in id_names)
            n_tot = sum(self.scans[n].count for n in id_names)
            now = QLabel(f"{n_tot:,} row(s)"
                         + (f", {n_gap} gap(s)" if n_gap else ", no gaps"))
            now.setStyleSheet(f"color:{c['muted']};font-size:8.5pt;")
            cost = QLabel("closes every gap")
            cost.setStyleSheet(f"color:{c['ok']};font-size:8.5pt;")
            cost.setToolTip("Deleting features leaves holes in the id column "
                            "(id 273 then 286). This renumbers the rows that "
                            "remain 1..N in each table, keeping their order.")
            for col, w in enumerate((cb, lbl, now, cost)):
                grid.addWidget(w, row, col)
            self._id_cb = cb
            self._id_names = id_names
            row += 1

        for name, sc in self.scans.items():
            if name.startswith(_scan.ID_PREFIX):
                continue             # folded into the single ID row above
            spec = sc.spec
            cb = QCheckBox()
            if spec.is_reference:
                # SP is not optional: it follows PON, and unticking it would leave
                # every joint pointing at the wrong PON. Shown, locked on.
                cb.setChecked(True)
                cb.setEnabled(False)
                cb.setToolTip("PON references always follow the PON renumber — "
                              "leaving them behind would point every joint at the "
                              "wrong PON.")
            else:
                cb.setChecked(name == "PON")
            cb.stateChanged.connect(lambda _s: self._refresh())

            lbl = QLabel(f"{name} — {spec.label}"
                         + ("  (follows PON)" if spec.is_reference else ""))
            now = QLabel(f"{len(sc.distinct):,} number(s)"
                         + (f", {len(sc.gaps)} gap(s)" if sc.gaps else ", no gaps"))
            now.setStyleSheet(f"color:{c['muted']};font-size:8.5pt;")

            if spec.is_reference:
                cost = QLabel("follows PON")
                cost.setStyleSheet(f"color:{c['muted']};font-size:8.5pt;")
            else:
                n = sc.blast_radius()
                if n:
                    cost = QLabel(f"~{n:,} label(s) rewritten")
                    cost.setStyleSheet(f"color:{c['warn']};font-size:8.5pt;"
                                       "font-weight:bold;")
                    cost.setToolTip(
                        f"{len(sc.gaps)} gap(s) already exist in {name}, so "
                        f"compacting rewrites ~{n:,} label(s) even before you "
                        f"delete anything.")
                else:
                    cost = QLabel("nothing to close")
                    cost.setStyleSheet(f"color:{c['ok']};font-size:8.5pt;")
            for col, w in enumerate((cb, lbl, now, cost)):
                grid.addWidget(w, row, col)
            self._sys_rows.append((name, cb))
            row += 1
        grid.setColumnStretch(1, 1)
        grid.setRowStretch(row, 1)
        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setWidget(host)
        area.setMaximumHeight(190)
        return area

    # ── state ────────────────────────────────────────────────────────────────
    def _checked_pons(self):
        out = []
        for i in range(self._pon_list_w.count()):
            it = self._pon_list_w.item(i)
            if it.checkState() == Qt.CheckState.Checked:
                out.append(it.data(Qt.ItemDataRole.UserRole))
        return out

    def _checked_cascade(self):
        out = []
        for i in range(self._cascade_w.count()):
            it = self._cascade_w.item(i)
            if it.checkState() == Qt.CheckState.Checked:
                out.append(it.data(Qt.ItemDataRole.UserRole))
        return out

    def _checked_systems(self):
        out = [n for n, cb in self._sys_rows if cb.isChecked()]
        # the single ID tick stands for every per-layer id system
        if getattr(self, "_id_cb", None) is not None and self._id_cb.isChecked():
            out.extend(self._id_names)
        return out

    def _update_preview_btn(self):
        self._preview_btn.setEnabled(
            bool(self._checked_pons() or self._checked_systems()))

    def _refresh(self):
        """Tick a PON → everything inside it is found and ticked for you.

        Auto-ticks only the PON's OWN gear. Shared/base layers (Erven, poles,
        the feeder trunk, AOI…) show their count but stay off: an erf exists
        whether or not fibre is built on it, and a pole inside this PON may carry
        the feeder that serves the next one. Any row JJ clicks himself is left
        alone from then on.
        """
        doomed = set(self._checked_pons())
        auto_n = 0
        self._refreshing = True
        try:
            for lid, item in self._cascade_items:
                name = self._cascade_names.get(lid, "")
                n = self._inside_count(lid, doomed)
                owned = _is_pon_owned(name)
                if n:
                    tail = f"{n:,} inside" + ("" if owned
                                              else "   ·  shared — tick to remove")
                else:
                    tail = "—"
                item.setText(f"{name}     ·  {tail}")
                if lid in self._user_touched:
                    want = item.checkState()      # his call, not mine
                else:
                    want = (Qt.CheckState.Checked if (n and owned)
                            else Qt.CheckState.Unchecked)
                if want == Qt.CheckState.Checked and n:
                    auto_n += 1
                if item.checkState() != want:
                    item.setCheckState(want)
                f = item.flags()
                item.setFlags(f | Qt.ItemFlag.ItemIsEnabled if n
                              else f & ~Qt.ItemFlag.ItemIsEnabled)
            total = sum(self._inside_count(lid, doomed)
                        for lid, it in self._cascade_items
                        if it.checkState() == Qt.CheckState.Checked)
        finally:
            self._refreshing = False
        if doomed:
            self._cascade_hint.setText(
                f"auto-selected {auto_n} layer(s) inside {len(doomed)} PON(s) — "
                f"{total:,} feature(s) will be removed with them")
        else:
            self._cascade_hint.setText("tick a PON above and this fills in by itself")
        self._update_preview_btn()

    # ── preview ──────────────────────────────────────────────────────────────
    def _on_preview(self):
        pons = self._checked_pons()          # capture BEFORE any modal
        cascade = self._checked_cascade()
        systems = self._checked_systems()

        # The window is non-modal, so the project can be swapped underneath it.
        # Acting on a closed project would target layers that no longer exist —
        # re-check rather than trust what we scanned at open time.
        from qgis.core import QgsProject
        if QgsProject.instance() is not self.project or not self.project.mapLayers():
            QMessageBox.warning(
                self, "Delete + Renumber",
                "The project changed since this window was opened, so what it is "
                "showing is out of date.\n\nClose it and open it again.")
            return

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            plan = _plan.build_plan(self.project, pons, cascade, systems,
                                    scans=self.scans)
        except Exception as exc:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "Delete + Renumber",
                                 f"Could not work out the change:\n{exc}")
            return
        QApplication.restoreOverrideCursor()
        dlg = PreviewDialog(self.project, plan, parent=self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.accept()


class PreviewDialog(QDialog):
    def __init__(self, project, plan, parent=None):
        super().__init__(parent)
        self.project = project
        self.plan = plan
        self._c = _theme_colors(self)
        self.setWindowTitle("Delete + Renumber — preview")
        self.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
            Qt.WindowType.WindowCloseButtonHint |
            Qt.WindowType.CustomizeWindowHint |
            Qt.WindowType.WindowMaximizeButtonHint)
        # WindowModal, not the default application-modal: this blocks only the
        # picker that opened it, so QGIS itself stays live and JJ can pan/zoom
        # the map while reading what is about to change.
        self.setWindowModality(Qt.WindowModality.WindowModal)
        self.setMinimumSize(900, 660)
        self._build()

    def _build(self):
        c = self._c
        p = self.plan
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(8)

        title = QLabel("PREVIEW — nothing has been written yet")
        f = QFont()
        f.setBold(True)
        f.setPointSize(13)
        title.setFont(f)
        title.setStyleSheet(f"color:{c['accent']};")
        lay.addWidget(title)

        head = QLabel(f"delete <b>{p.total_deleted:,}</b> feature(s)   ·   "
                      f"rewrite <b>{p.total_edits:,}</b> label(s)")
        head.setStyleSheet(f"color:{c['ink']};font-size:10pt;")
        lay.addWidget(head)

        for line in p.summary_lines():
            lbl = QLabel("  •  " + line)
            lbl.setStyleSheet(f"color:{c['ink']};font-size:9pt;")
            lay.addWidget(lbl)
        for w in p.warnings:
            lbl = QLabel("⚠  " + w)
            lbl.setWordWrap(True)
            lbl.setStyleSheet(f"color:{c['warn']};font-size:9pt;")
            lay.addWidget(lbl)
        for b in p.blocked:
            lbl = QLabel("⛔  " + b)
            lbl.setWordWrap(True)
            lbl.setStyleSheet(f"color:{c['bad']};font-size:9pt;font-weight:bold;")
            lay.addWidget(lbl)

        lay.addWidget(_hline(c))
        lay.addWidget(self._table(), 1)

        cap = QLabel(f"Showing up to {p.SAMPLE_CAP} of {p.total_edits:,} label "
                     f"change(s). A backup is written before anything is touched.")
        cap.setStyleSheet(f"color:{c['muted']};font-size:8.5pt;")
        lay.addWidget(cap)

        btns = QHBoxLayout()
        back = QPushButton("Cancel")
        back.setStyleSheet(_BTN.format(bg="#6b5320", hov="#8a6c2a"))
        back.clicked.connect(self.reject)
        self._apply_btn = QPushButton("✔  Back up + Apply")
        self._apply_btn.setStyleSheet(_BTN.format(bg="#8a2a2a", hov="#a83a3a"))
        self._apply_btn.setEnabled(p.ok and bool(p.edits or p.deletions))
        if not p.ok:
            self._apply_btn.setToolTip("Blocked — see the ⛔ lines above.")
        self._apply_btn.clicked.connect(self._on_apply)
        btns.addWidget(back)
        btns.addStretch(1)
        btns.addWidget(self._apply_btn)
        lay.addLayout(btns)

    def _table(self):
        p = self.plan
        rows = p.samples()
        tbl = QTableWidget(len(rows), 4)
        tbl.setHorizontalHeaderLabels(["Layer", "Field", "Before", "After"])
        tbl.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        tbl.verticalHeader().setVisible(False)
        for r, e in enumerate(rows):
            for col, v in enumerate((e.layer_name, e.field, e.old, e.new)):
                tbl.setItem(r, col, QTableWidgetItem(str(v)))
        for col in (0, 1):
            tbl.horizontalHeader().setSectionResizeMode(
                col, QHeaderView.ResizeMode.ResizeToContents)
        for col in (2, 3):
            tbl.horizontalHeader().setSectionResizeMode(
                col, QHeaderView.ResizeMode.Stretch)
        return tbl

    def _on_apply(self):
        p = self.plan
        ok = QMessageBox.question(
            self, "Back up + Apply?",
            f"This will:\n\n"
            f"    • delete {p.total_deleted:,} feature(s)\n"
            f"    • rewrite {p.total_edits:,} label(s)\n\n"
            f"A backup of every layer is written first — if it fails, nothing is "
            f"touched. Deleted features can only be recovered from that backup.\n\n"
            f"Continue?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Cancel)
        if ok != QMessageBox.StandardButton.Yes:
            return
        self._apply_btn.setEnabled(False)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            res = _apply.apply_plan(self.project, p)
        except Exception as exc:
            QApplication.restoreOverrideCursor()
            self._apply_btn.setEnabled(True)
            QMessageBox.critical(self, "Delete + Renumber", f"Failed:\n{exc}")
            return
        QApplication.restoreOverrideCursor()
        body = "\n".join("  • " + s for s in res.summary_lines())
        if res.ok:
            QMessageBox.information(
                self, "Delete + Renumber",
                f"✔  Done.\n\n{body}\n\nKeep that backup until you've checked "
                f"the result.")
            self.accept()
        else:
            QMessageBox.warning(self, "Delete + Renumber",
                                "\n".join(res.errors) + ("\n\n" + body if body else ""))


_OPEN = None      # module-level ref: a non-modal dialog with no reference is GC'd


def _clear_open():
    global _OPEN
    _OPEN = None


def open_dialog(parent=None, project=None):
    """Open NON-MODAL so QGIS stays usable — pan/zoom the map with it open.

    show() not exec(): exec() blocks the whole app, so you couldn't look at the
    PONs on the map while choosing them. Parented to the QGIS main window so it
    floats above and can't get lost behind it, WA_DeleteOnClose so it doesn't
    leak, and held in a module-level ref because a non-modal dialog with no
    Python reference is garbage-collected the moment this function returns.
    """
    global _OPEN
    from qgis.PyQt import sip
    from qgis.core import QgsProject
    project = project or QgsProject.instance()

    # The MOA / PH2 lock, at the door. The planner blocks it too (belt and
    # braces), but refusing here means the window never even opens on a project
    # it must not touch — no ticking PONs and then being told no.
    lock = _plan.moa_lock_reason(project)
    if lock:
        QMessageBox.critical(
            parent, "Delete + Renumber — not on this project",
            f"⛔  {lock}\n\n"
            "The live Mohadin / PH2 network must never be renumbered — its "
            "labels are on built infrastructure, splice plans and as-builts "
            "that are already in the field.\n\n"
            "This tool is for Malmesbury / HeroTel and other planning projects. "
            "Open one of those and try again.\n\n"
            "(To work on a Mohadin COPY, put 'backup', 'copy' or 'sandbox' in "
            "the project name.)")
        return None

    if _OPEN is not None:
        try:
            if not sip.isdeleted(_OPEN):
                _OPEN.show()
                _OPEN.raise_()
                _OPEN.activateWindow()
                return _OPEN
        except (RuntimeError, AttributeError):
            pass
        _OPEN = None

    if parent is None:
        try:
            from qgis.utils import iface
            parent = iface.mainWindow() if iface else None
        except Exception:
            parent = None

    dlg = DeleteRenumberDialog(project, parent=parent)
    dlg.setModal(False)
    dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
    dlg.destroyed.connect(lambda *_a: _clear_open())
    _OPEN = dlg
    dlg.show()
    dlg.raise_()
    dlg.activateWindow()
    return dlg
