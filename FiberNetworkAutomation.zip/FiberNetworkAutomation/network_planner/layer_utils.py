"""Utility functions for working with QGIS layers and features."""

from typing import List, Optional, Tuple
from qgis.core import (
    QgsVectorLayer,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsWkbTypes,
    QgsField
)
from qgis.PyQt.QtCore import QVariant


def get_layer_by_name(layer_name: str) -> Optional[QgsVectorLayer]:
    """Get a layer from the current project by name.
    
    Args:
        layer_name: Name of the layer to find
        
    Returns:
        QgsVectorLayer if found, None otherwise
    """
    layers = QgsProject.instance().mapLayersByName(layer_name)
    return layers[0] if layers else None


def get_all_vector_layers() -> List[QgsVectorLayer]:
    """Get all vector layers in the current project.
    
    Returns:
        List of QgsVectorLayer objects
    """
    return [layer for layer in QgsProject.instance().mapLayers().values()
            if isinstance(layer, QgsVectorLayer)]


def get_layer_features(layer: QgsVectorLayer) -> List[QgsFeature]:
    """Get all features from a layer.
    
    Args:
        layer: Vector layer to query
        
    Returns:
        List of features
    """
    return list(layer.getFeatures())


def get_point_coordinates(feature: QgsFeature) -> Optional[Tuple[float, float]]:
    """Extract X, Y coordinates from a point feature.
    
    Args:
        feature: Point feature
        
    Returns:
        Tuple of (x, y) coordinates or None if not a point
    """
    geom = feature.geometry()
    if geom is None or geom.isEmpty():
        return None
    if geom.type() == QgsWkbTypes.GeometryType.PointGeometry:
        point = geom.asPoint()
        return (point.x(), point.y())
    return None


def get_linestring_coordinates(feature: QgsFeature) -> Optional[List[Tuple[float, float]]]:
    """Extract coordinates from a linestring feature.
    
    Args:
        feature: LineString feature
        
    Returns:
        List of (x, y) coordinate tuples or None if not a linestring
    """
    geom = feature.geometry()
    if geom is None or geom.isEmpty():
        return None
    if geom.type() == QgsWkbTypes.GeometryType.LineGeometry:
        # A MultiLineString returns [] from asPolyline() — use the first part so a
        # multipart-stored line isn't silently dropped from the routing graph.
        if geom.isMultipart():
            parts = geom.asMultiPolyline()
            line = parts[0] if parts else []
        else:
            line = geom.asPolyline()
        return [(pt.x(), pt.y()) for pt in line]
    return None


def create_memory_layer(layer_name: str, geometry_type: str, crs: str = "EPSG:4326") -> QgsVectorLayer:
    """Create a new memory (temporary) vector layer.
    
    Args:
        layer_name: Name for the new layer
        geometry_type: 'Point', 'LineString', or 'Polygon'
        crs: Coordinate reference system (default WGS84)
        
    Returns:
        New QgsVectorLayer
    """
    uri = f"{geometry_type}?crs={crs}"
    layer = QgsVectorLayer(uri, layer_name, "memory")
    return layer


def add_fields_to_layer(layer: QgsVectorLayer, fields: List[Tuple[str, type, str]]) -> bool:
    """Add fields to a layer.
    
    Args:
        layer: Layer to modify
        fields: List of (field_name, python_type, type_name) tuples
                e.g., [('id', int, 'Integer'), ('name', str, 'String')]
        
    Returns:
        True if successful
    """
    provider = layer.dataProvider()
    qgs_fields = []
    
    type_map = {
        int: QVariant.Int,
        float: QVariant.Double,
        str: QVariant.String,
        bool: QVariant.Bool
    }
    
    for field_name, py_type, type_name in fields:
        qgs_fields.append(QgsField(field_name, type_map.get(py_type, QVariant.String)))
    
    return provider.addAttributes(qgs_fields)


def add_point_feature(layer: QgsVectorLayer, x: float, y: float, attributes: dict) -> bool:
    """Add a point feature to a layer.
    
    Args:
        layer: Layer to add feature to
        x: X coordinate
        y: Y coordinate
        attributes: Dictionary of field_name: value pairs
        
    Returns:
        True if successful
    """
    feature = QgsFeature()
    feature.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
    
    # Set attributes if layer has fields
    if layer.fields().count() > 0:
        feature.setFields(layer.fields())
        for field_name, value in attributes.items():
            if feature.fields().indexFromName(field_name) >= 0:
                feature.setAttribute(field_name, value)
    
    provider = layer.dataProvider()
    return provider.addFeature(feature)


def add_line_feature(layer: QgsVectorLayer, points: List[Tuple[float, float]], attributes: dict) -> bool:
    """Add a linestring feature to a layer.
    
    Args:
        layer: Layer to add feature to
        points: List of (x, y) coordinate tuples
        attributes: Dictionary of field_name: value pairs
        
    Returns:
        True if successful
    """
    feature = QgsFeature()
    qgs_points = [QgsPointXY(x, y) for x, y in points]
    feature.setGeometry(QgsGeometry.fromPolylineXY(qgs_points))
    
    # Set attributes if layer has fields
    if layer.fields().count() > 0:
        feature.setFields(layer.fields())
        for field_name, value in attributes.items():
            if feature.fields().indexFromName(field_name) >= 0:
                feature.setAttribute(field_name, value)
    
    provider = layer.dataProvider()
    return provider.addFeature(feature)


def get_selected_features(layer: QgsVectorLayer) -> List[QgsFeature]:
    """Get currently selected features from a layer.
    
    Args:
        layer: Layer to query
        
    Returns:
        List of selected features
    """
    return layer.selectedFeatures()


def get_feature_attribute(feature: QgsFeature, field_name: str):
    """Get attribute value from a feature.
    
    Args:
        feature: Feature to query
        field_name: Name of the field
        
    Returns:
        Attribute value or None if field doesn't exist
    """
    return feature.attribute(field_name)


def count_features_by_geometry_type(layer: QgsVectorLayer) -> dict:
    """Count features by their geometry type.
    
    Args:
        layer: Layer to analyze
        
    Returns:
        Dictionary with geometry type counts
    """
    counts = {
        'Point': 0,
        'LineString': 0,
        'Polygon': 0,
        'Unknown': 0
    }
    
    for feature in layer.getFeatures():
        geom = feature.geometry()
        if geom is None or geom.isEmpty():
            counts['Unknown'] += 1
            continue
        geom_type = geom.type()
        
        if geom_type == QgsWkbTypes.GeometryType.PointGeometry:
            counts['Point'] += 1
        elif geom_type == QgsWkbTypes.GeometryType.LineGeometry:
            counts['LineString'] += 1
        elif geom_type == QgsWkbTypes.GeometryType.PolygonGeometry:
            counts['Polygon'] += 1
        else:
            counts['Unknown'] += 1
    
    return counts


def get_layer_extent(layer: QgsVectorLayer) -> dict:
    """Get the spatial extent of a layer.
    
    Args:
        layer: Layer to analyze
        
    Returns:
        Dictionary with xMin, yMin, xMax, yMax
    """
    extent = layer.extent()
    return {
        'xMin': extent.xMinimum(),
        'yMin': extent.yMinimum(),
        'xMax': extent.xMaximum(),
        'yMax': extent.yMaximum()
    }
