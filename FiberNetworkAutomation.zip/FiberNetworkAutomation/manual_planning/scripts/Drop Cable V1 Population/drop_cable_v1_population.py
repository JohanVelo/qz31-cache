import sys, os
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')

# ============================================================
# DROP CABLE V1 — SEQUENTIAL LABEL POPULATION
# Project: Potch - Mohadin PH2
# DR numbers are independent sequential — not linked to homes
# Phase 1 ended at DR1875439, Phase 2 starts at DR1875440
# ============================================================

CABLE_LAYER = 'Drop Cable v1'
PON_LAYER = 'PON v1'
ZONE_LAYER = 'Zones v1'

DR_START = 1875440  # Phase 1 ended at DR1875439

STATIC = {
    'type': 'Cable',
    'subtyp': 'Drop',
    'spec': 'SM/G657A2',
    'dim1': '3,0mm',
    'cblcpty': '1F',
    'conntr': 'LC/APC-SC/APC',
    'ntwrkptn': 'Drop',
    'cmpownr': 'VelocityFibre',
    'subplace': '676007',
    'mainplce': '676007',
    'mun': 'JB Marks Local Municipality',
    'stackref': 'MOA',
    'crtdby': 'Johan Scholtz',
}

cable_layer = pon_layer = zone_layer = None
for lyr in QgsProject.instance().mapLayers().values():
    n = lyr.name()
    if n == CABLE_LAYER: cable_layer = lyr
    if n == PON_LAYER: pon_layer = lyr
    if n == ZONE_LAYER: zone_layer = lyr

missing = [n for n, l in [(CABLE_LAYER, cable_layer), (PON_LAYER, pon_layer), (ZONE_LAYER, zone_layer)] if not l]
if missing:
    print(f"ERROR: Missing layers: {missing}")
else:
    print(f"Cable layer: {cable_layer.featureCount()} features")

    from qgis.core import QgsSpatialIndex, QgsDistanceArea, QgsProject

    d = QgsDistanceArea()
    d.setSourceCrs(cable_layer.crs(), QgsProject.instance().transformContext())
    d.setEllipsoid(QgsProject.instance().ellipsoid())

    pon_index = QgsSpatialIndex(pon_layer.getFeatures())
    pon_feats = {f.id(): f for f in pon_layer.getFeatures()}
    zone_index = QgsSpatialIndex(zone_layer.getFeatures())
    zone_feats = {f.id(): f for f in zone_layer.getFeatures()}

    fields = cable_layer.fields()
    fidx = {fields.field(i).name(): i for i in range(fields.count())}
    static_indexed = {fidx[k]: v for k, v in STATIC.items() if k in fidx}

    iface.mapCanvas().setRenderFlag(False)

    changes = {}
    features = sorted(cable_layer.getFeatures(), key=lambda f: f.id())
    no_geom = 0
    i = 0
    sample = []

    for feat in features:
        geom = feat.geometry()
        if geom is None or geom.isNull() or geom.isEmpty():
            no_geom += 1
            continue

        vertices = list(geom.vertices())
        if len(vertices) < 2:
            no_geom += 1
            continue

        # Sequential DR label
        dr_num = DR_START + i
        label = f'DR{dr_num}'
        i += 1

        # Cable length
        length_m = d.measureLength(geom)
        dim2 = str(round(length_m, 4))

        # PON_NO from midpoint
        from qgis.core import QgsPointXY, QgsGeometry
        mid_idx = len(vertices) // 2
        mid_pt = QgsPointXY(vertices[mid_idx].x(), vertices[mid_idx].y())
        mid_geom = QgsGeometry.fromPointXY(mid_pt)

        pon_no = None
        for fid in pon_index.intersects(mid_geom.boundingBox()):
            if pon_feats[fid].geometry().contains(mid_geom):
                pon_no = pon_feats[fid]['pon_no']
                break

        zone_no = None
        for fid in zone_index.intersects(mid_geom.boundingBox()):
            if zone_feats[fid].geometry().intersects(mid_geom):
                zone_no = zone_feats[fid]['zone_no']
                break

        feat_changes = dict(static_indexed)
        if 'label' in fidx: feat_changes[fidx['label']] = label
        if 'dim2' in fidx: feat_changes[fidx['dim2']] = dim2
        if 'pon_no' in fidx and pon_no: feat_changes[fidx['pon_no']] = pon_no
        if 'zone_no' in fidx and zone_no: feat_changes[fidx['zone_no']] = zone_no
        changes[feat.id()] = feat_changes

        if len(sample) < 5:
            sample.append(f"  {label} | dim2={dim2}m | pon={pon_no} | zone={zone_no}")

    cable_layer.dataProvider().changeAttributeValues(changes)
    cable_layer.reload()
    iface.mapCanvas().setRenderFlag(True)
    iface.mapCanvas().refresh()

    processed = len(changes)
    print("=" * 60)
    print(f"  DROP CABLE V1 COMPLETE")
    print(f"  Processed: {processed}")
    print(f"  Skipped (no geometry): {no_geom}")
    print(f"  DR range: DR{DR_START} → DR{DR_START + processed - 1}")
    print("=" * 60)
    print("\nSample — first 5:")
    for s in sample: print(s)

    # Verify no duplicates
    all_labels = [f['label'] for f in cable_layer.getFeatures() if f['label']]
    dupes = len(all_labels) - len(set(all_labels))
    print(f"\nDuplicate labels: {dupes}")
