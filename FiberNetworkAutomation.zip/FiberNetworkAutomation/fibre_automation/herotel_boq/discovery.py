"""Explainable BOQ proposals from complete snapshots, never fuzzy quantities.

Names locate candidates. Actual field values establish materials. Ambiguous
populations require a source choice; no source or unknown material is not zero.
"""
from dataclasses import dataclass
import re

from .mapping import Binding, normalise, number, splitter_count
from .model import INPUT_ROWS
from .profiles import (CABLE_AUTHORITY, cable_population, demand_point_authority, interpreted_height,
                       pole_height_authority, seal_authority)

ROLE_LABELS = {'demand': 'Homes', 'poles': 'Poles and hooks',
               'equipment': 'Enclosures and splitters', 'enclosures': 'Enclosures', 'splitters': 'Splitters', 'cables': 'Aerial cables',
               'quantities': 'Recorded BOQ quantities'}
HEIGHTS = ('Height', 'Hight', 'Pole Height', 'Pole_heigh', 'Pole Length', 'Pole Lengt', 'Type')
DIAMETERS = ('Pole Size', 'Pole Thick', 'pole_thick', 'Diameter')
POLE_ROWS = {(5.4, '100-120'): 17, (5.4, '120-140'): 18,
             (7.2, '120-140'): 19, (7.2, '140-160'): 20,
             (9.0, '120-140'): 21, (9.0, '140-160'): 22}
CABLE_ROWS = {12: 75, 24: 77, 48: 79, 72: 81, 96: 83, 144: 85}


def unique_field(fields, aliases):
    matches = [f for f in fields if normalise(f) in {normalise(a) for a in aliases}]
    return matches[0] if len(matches) == 1 else ''


def ambiguous_field(fields, aliases):
    return sum(normalise(f) in {normalise(a) for a in aliases} for f in fields) > 1


def candidate_roles(name, fields, geometry):
    """Cheap metadata filter only. geometry: point/line/polygon/other."""
    text = normalise(name)
    names = {normalise(f) for f in fields}
    roles = []
    if geometry == 'point':
        if any(word in text for word in ('demand', 'premise', 'household', 'ont')):
            roles.append('demand')
        if 'pole' in text or names & {'polesize', 'poleheight', 'polethick', '1way', '2way', '3way'}:
            roles.append('poles')
        if names & {'1224dead', '96dead'}:
            roles.append('hardware')
        if any(word in text for word in ('splitter', 'joint', 'enclosure')) or names & {'splitters', 'splitterratio', 'enclosuretype', 'model'}:
            roles.append('equipment')
    if geometry == 'line' and (names & {'cablesize', 'fibresize', 'fibrecount', 'fibersize', 'fibercount'} or 'cable' in text or 'feeder' in text):
        roles.append('cables')
    if any(normalise(f) == f'boq{row}' for f in fields for row in INPUT_ROWS):
        roles.append('quantities')
    return tuple(roles)


@dataclass(frozen=True)
class Discovery:
    bindings: tuple
    questions: tuple
    candidates: dict
    reasons: dict
    confirmations: dict
    observations: tuple = ()


def discover(snapshot, geometries, selections=None, confirmations=None):
    """Return proposals; selections are explicit role -> physical layer IDs.

    Selection establishes population intent only. It cannot approve malformed
    values, convert dimensions, or supply missing quantities.
    """
    snapshot.validate()
    selections = selections or {}
    confirmations = confirmations or {}
    requested_facts = {'one_home': [], 'metres': []}
    candidates = {role: [] for role in ROLE_LABELS if role != 'equipment'}
    observations = []
    auto_selected = {}
    selections = dict(selections)
    for layer in sorted(snapshot.layers, key=lambda x: x.identity):
        roles = candidate_roles(layer.name, layer.fields, geometries.get(layer.identity, 'other'))
        if roles and not layer.records:
            observations.append(f'{layer.name}: empty layer ignored; it does not establish a zero quantity.')
            continue
        for role in roles:
            if role == 'hardware':
                continue  # Captured as evidence, never a competing pole population.
            if role == 'equipment':
                kind_fields = ('Type', 'Enclosure Type', 'Model')
                ratio_fields = ('Splitters', 'Splitter Ratio', 'Ratio', 'Descriptio', 'Description')
                names = {normalise(f) for f in layer.fields}
                has_kind = bool(names & {normalise(f) for f in kind_fields})
                has_ratio = bool(names & {normalise(f) for f in ratio_fields})
                if has_kind or not has_ratio:
                    candidates['enclosures'].append(layer)
                if has_ratio or not has_kind:
                    candidates['splitters'].append(layer)
            else:
                candidates[role].append(layer)
        for field in layer.fields:
            if normalise(field) not in ('1224dead', '96dead'):
                continue
            subtotal, blanks, invalid = 0, 0, 0
            for record in layer.records:
                value = record.values.get(field)
                if value is None:
                    blanks += 1
                else:
                    try:
                        subtotal += number(value)
                    except ValueError:
                        invalid += 1
            observations.append(
                f'{layer.name} / {field}: recorded subtotal {subtotal:g}; {blanks} blank and '
                f'{invalid} invalid values. Fitting material and BOQ row still require verification; '
                'this subtotal is not a final BOQ quantity.')
    # Compatibility for saved diagnostic source choices, translated per family.
    if 'equipment' in selections:
        for role in ('enclosures', 'splitters'):
            selections.setdefault(role, [x.identity for x in candidates[role]
                                        if x.identity in selections['equipment']])
    bindings, questions, reasons = [], [], {}
    blocked = set()

    def compatible_equipment(role, layers):
        """Only disjoint, fully classified material sets may auto-combine."""
        seen_categories, seen_names = set(), set()
        aliases = (('Type', 'Enclosure Type', 'Model') if role == 'enclosures' else
                   ('Splitters', 'Splitter Ratio', 'Ratio', 'Descriptio', 'Description'))
        for source in layers:
            field = unique_field(source.fields, aliases)
            if not field:
                return False
            categories = set()
            asset_field = unique_field(source.fields, ('Name', 'Label'))
            local_names = set()
            for record in source.records:
                if role == 'enclosures':
                    value = normalise(record.values.get(field))
                    if value not in ('m8', 'm16', 'fd4'):
                        return False
                    categories.add(value)
                else:
                    try:
                        for size in (8, 16):
                            if splitter_count(record.values.get(field), size):
                                categories.add(size)
                    except ValueError:
                        return False
                if asset_field and record.values.get(asset_field):
                    name = str(record.values[asset_field])
                    if name in local_names:
                        return False
                    local_names.add(name)
            if categories & seen_categories or local_names & seen_names:
                return False
            seen_categories.update(categories)
            seen_names.update(local_names)
        return True

    def add(row, layer, operation='count', field='', **options):
        rationale = f'Automatic exact-field/value interpretation; selected population: {layer.name}'
        if row == 15 and operation == 'count' and demand_point_authority(snapshot, layer):
            rationale += '; ' + demand_point_authority(snapshot, layer)
        if row in range(17, 23):
            authority = pole_height_authority(snapshot, layer)
            if authority:
                rationale += '; ' + authority
        if row in (30, 31):
            authority = seal_authority(snapshot, layer)
            if authority:
                rationale += '; ' + authority
        if layer.identity in confirmations.get('one_home', ()) and row == 15:
            rationale += '; planner confirmed one home per feature for this snapshot'
        if layer.identity in confirmations.get('metres', ()) and row in CABLE_ROWS.values():
            rationale += '; planner confirmed recorded cable lengths are metres for this snapshot'
        bindings.append(Binding(row, layer.identity, operation, field,
                                reviewed=True, complete_scope=True, rationale=rationale, **options))
        reasons.setdefault(row, []).append(f'{layer.name}' + (f' · {field}' if field else ''))

    legacy_cables = cable_population(snapshot, candidates['cables'])
    for role, options in candidates.items():
        chosen = selections.get(role)
        if chosen is None:
            if role == 'cables' and legacy_cables is not None:
                chosen = [layer.identity for layer in options]
                auto_selected[role] = chosen
            elif len(options) == 1 and not re.search(r'backup|(?:^|[\W_])old(?:$|[\W_])|previous', options[0].name, re.I):
                chosen = [options[0].identity]
            elif options and role in ('enclosures', 'splitters') and not any(
                    re.search(r'backup|(?:^|[\W_])old(?:$|[\W_])|previous', x.name, re.I) for x in options
                    ) and compatible_equipment(role, options):
                chosen = [x.identity for x in options]
                auto_selected[role] = chosen
            elif options:
                questions.append(f'{ROLE_LABELS[role]}: choose the current source layer(s). Old and current versions must not be added together.')
                continue
            else:
                continue
        if not set(chosen) <= {layer.identity for layer in options}:
            raise ValueError('A selected source is no longer available')
        for layer in options:
            if layer.identity not in chosen:
                continue
            values = [record.values for record in layer.records]
            if not values:
                questions.append(f'{layer.name}: the source is empty; confirm the intended population before using zero.')
                blocked.update({'demand': (15,), 'poles': (*range(17, 23), 41, 42, 43),
                                'enclosures': (27, 28, 29), 'splitters': (33, 34), 'cables': tuple(CABLE_ROWS.values()),
                                'quantities': INPUT_ROWS}[role])
                continue
            if role == 'demand':
                if ambiguous_field(layer.fields, ('Premises Count', 'Dwelling Count', 'Homes Count', 'Demand Count')):
                    questions.append(f'{layer.name}: competing home-count fields must be resolved; a one-home confirmation cannot replace those quantities.')
                    blocked.add(15)
                    continue
                field = unique_field(layer.fields, ('Premises Count', 'Dwelling Count', 'Homes Count', 'Demand Count'))
                type_field = unique_field(layer.fields, ('Type', 'Premise Type', 'Dwelling Type'))
                if field:
                    add(15, layer, 'sum', field)
                elif demand_point_authority(snapshot, layer):
                    add(15, layer)
                elif (type_field and not re.search(r'group', layer.name, re.I) and
                      all(normalise(v.get(type_field)) in ('sdu', 'singledwellingunit') for v in values)) or (
                        layer.identity in confirmations.get('one_home', ())):
                    add(15, layer)
                else:
                    questions.append(f'{layer.name}: confirm how many homes each feature represents. If these are grouped homes, their quantities must be recorded; one point is not assumed to be one home.')
                    requested_facts['one_home'].append((layer.identity, layer.name))
                    blocked.add(15)
            elif role == 'poles':
                # Exact metadata names are candidates; every physical value must match.
                height = unique_field(layer.fields, HEIGHTS)
                diameter = unique_field(layer.fields, DIAMETERS)
                status = unique_field(layer.fields, ('Status', 'Pole Status', 'New Existing'))
                if 'existing' in normalise(layer.name) or ambiguous_field(layer.fields, ('Status', 'Pole Status', 'New Existing')) or (
                        status and any(normalise(v.get(status)) not in ('new', 'proposed') for v in values)):
                    questions.append(f'{layer.name}: separate existing and new poles before procurement quantities are calculated.')
                    blocked.update((*range(17, 23), 41, 42, 43))
                elif height and diameter:
                    categories = {}
                    bad = set()
                    for v in values:
                        raw_height, raw_diameter = v.get(height), v.get(diameter)
                        try:
                            h = interpreted_height(number(raw_height, unit='m'),
                                                   pole_height_authority(snapshot, layer))
                            d = re.sub(r'\s|mm', '', str(raw_diameter).lower()).replace('/', '-')
                            row = POLE_ROWS[h, d]
                            categories.setdefault(row, set()).add((str(raw_height), str(raw_diameter)))
                        except (ValueError, KeyError):
                            bad.add(f'{raw_height} / {raw_diameter}')
                    if bad:
                        questions.append(f'{layer.name}: pole sizes do not match the BOQ materials: '+', '.join(sorted(bad)[:6])+'. Confirm the actual material; no size substitution was made.')
                        blocked.update(range(17, 23))
                    else:
                        for row in range(17, 23):
                            pairs = categories.get(row, {('__absent_height__', '__absent_diameter__')})
                            for h, d in sorted(pairs):
                                add(row, layer, filters=((height, h), (diameter, d)), allow_empty_filter=True)
                else:
                    questions.append(f'{layer.name}: pole height and diameter are missing or ambiguous.')
                    blocked.update(range(17, 23))
                for row, ways in ((41, 3), (42, 2), (43, 1)):
                    field = unique_field(layer.fields, (f'{ways} Way', f'{ways} Hook', f'Hook {ways}', f'Hook.{ways}Way'))
                    if field:
                        add(row, layer, 'sum', field)
                    else:
                        blocked.add(row)
            elif role in ('enclosures', 'splitters'):
                kind = unique_field(layer.fields, ('Type', 'Enclosure Type', 'Model'))
                ratio = unique_field(layer.fields, ('Splitters', 'Splitter Ratio', 'Ratio', 'Descriptio', 'Description'))
                if role == 'enclosures' and kind:
                    raw_types = {str(v.get(kind)) for v in values}
                    if all(normalise(v) in ('m8', 'm16', 'fd4') for v in raw_types):
                        for row, code in ((27, 'm8'), (28, 'm16'), (29, 'fd4')):
                            matches = sorted(v for v in raw_types if normalise(v) == code) or ['__absent_enclosure__']
                            for raw in matches:
                                add(row, layer, filters=((kind, raw),), allow_empty_filter=True)
                                if row == 29 and seal_authority(snapshot, layer):
                                    for seal_row in (30, 31):
                                        add(seal_row, layer, filters=((kind, raw),), allow_empty_filter=True)
                    else:
                        questions.append(f'{layer.name}: enclosure models need clarification; a splitter ratio does not identify its enclosure.')
                        blocked.update((27, 28, 29))
                elif role == 'enclosures':
                    blocked.update((27, 28, 29))
                if role == 'splitters' and ratio:
                    try:
                        for v in values:
                            splitter_count(v.get(ratio), 8)
                        add(33, layer, 'splitter8', ratio)
                        add(34, layer, 'splitter16', ratio)
                    except ValueError:
                        questions.append(f'{layer.name}: some splitter ratios or quantities are missing or unrecognised.')
                        blocked.update((33, 34))
                elif role == 'splitters':
                    blocked.update((33, 34))
            elif role == 'cables':
                if legacy_cables is not None and set(chosen) == set(legacy_cables):
                    for size, row in CABLE_ROWS.items():
                        names = sorted(name for capacity, name in legacy_cables[layer.identity] if capacity == size)
                        for name in names or ['__absent_profile_capacity__']:
                            bindings.append(Binding(row, layer.identity, 'length', 'Tlenght',
                                slack_field='Slenght', filters=(('Name', name),), allow_empty_filter=True,
                                reviewed=True, complete_scope=True, rationale=CABLE_AUTHORITY))
                        reasons.setdefault(row, []).append(layer.name+' · Tlenght + Slenght')
                    continue
                if ambiguous_field(layer.fields, ('Cable Role', 'Network Role')):
                    questions.append(f'{layer.name}: competing cable-role fields prevent verified backhaul exclusion.')
                    blocked.update(CABLE_ROWS.values())
                    continue
                cable_role = unique_field(layer.fields, ('Cable Role', 'Network Role'))
                if cable_role:
                    allowed_roles = {'distribution', 'distributioncable', 'feeder', 'feedercable', 'link', 'linkcable', 'access', 'drop', 'dropcable', 'backhaul'}
                    if any(normalise(v.get(cable_role)) not in allowed_roles for v in values):
                        questions.append(f'{layer.name}: some cable roles are missing or ambiguous; backhaul exclusion cannot be verified.')
                        blocked.update(CABLE_ROWS.values())
                        continue
                    values = [v for v in values if normalise(v[cable_role]) != 'backhaul']
                    if not values:
                        continue  # Explicitly deferred population; no quantity invented.
                elif 'backhaul' in normalise(layer.name):
                    questions.append(f'{layer.name}: identify backhaul using Cable Role so only non-backhaul features contribute.')
                    blocked.update(CABLE_ROWS.values())
                    continue
                capacity = unique_field(layer.fields, ('Cable Size', 'Fibre Size', 'Fibre Count', 'Fiber Size', 'Fiber Count'))
                route = unique_field(layer.fields, ('Route Length m', 'Length m', 'Route Length', 'Length', 'Tlenght'))
                slack = unique_field(layer.fields, ('Slack m', 'Slack', 'Slenght'))
                total = unique_field(layer.fields, ('Installed Length m', 'Total Length', 'Total_Length'))
                length_alias_groups = (
                    ('Route Length m', 'Length m', 'Route Length', 'Length', 'Tlenght'),
                    ('Slack m', 'Slack', 'Slenght'),
                    ('Installed Length m', 'Total Length', 'Total_Length'))
                if any(ambiguous_field(layer.fields, group) for group in length_alias_groups):
                    questions.append(f'{layer.name}: competing length or slack fields must be resolved; no fallback total was used.')
                    blocked.update(CABLE_ROWS.values())
                    continue
                installation = unique_field(layer.fields, ('Installation', 'Installation Type', 'Cable Type'))
                name_field = unique_field(layer.fields, ('Name', 'Label'))
                aerial = (all(normalise(v.get(installation)) in ('aerial', 'overhead') for v in values) if installation else (
                    name_field and all(re.search(r'(?:^|[_\s-])aerial(?:$|[_\s-])', str(v.get(name_field)), re.I) for v in values)))
                if ambiguous_field(layer.fields, ('Installation', 'Installation Type', 'Cable Type')):
                    aerial = False
                if not aerial:
                    questions.append(f'{layer.name}: identify aerial cable features using an Installation field. Mixed, underground or backhaul routes are not assumed to be aerial.')
                    blocked.update(CABLE_ROWS.values())
                    continue
                if not capacity or not (total or (route and slack)):
                    questions.append(f'{layer.name}: cable size and installed metres (or route metres plus slack metres) are required.')
                    blocked.update(CABLE_ROWS.values())
                    continue
                unit = unique_field(layer.fields, ('Length Unit', 'Length Units'))
                if ambiguous_field(layer.fields, ('Length Unit', 'Length Units')):
                    questions.append(f'{layer.name}: competing length-unit fields must be resolved first.')
                    blocked.update(CABLE_ROWS.values())
                    continue
                known_metres = (unit and all(normalise(v.get(unit)) in ('m', 'metre', 'metres', 'meter', 'meters') for v in values)) or (
                    route and slack and normalise(route).endswith('m') and normalise(slack).endswith('m')) or (
                    total and normalise(total).endswith('m'))
                if unit and any(normalise(v.get(unit)) not in ('m', 'metre', 'metres', 'meter', 'meters') for v in values):
                    questions.append(f'{layer.name}: recorded length units are not consistently metres; resolve the source units first.')
                    blocked.update(CABLE_ROWS.values())
                    continue
                if not known_metres and layer.identity not in confirmations.get('metres', ()):
                    questions.append(f'{layer.name}: confirm that the recorded cable length and slack values are metres.')
                    requested_facts['metres'].append((layer.identity, layer.name))
                    blocked.update(CABLE_ROWS.values())
                    continue
                by_capacity = {}
                try:
                    for v in values:
                        raw = str(v.get(capacity))
                        match = re.fullmatch(r'(12|24|48|72|96|144)\s*(?:F|Fibre|Fibres)?', raw.strip(), re.I)
                        if not match:
                            raise ValueError()
                        by_capacity.setdefault(int(match[1]), set()).add((raw, str(v[cable_role]) if cable_role else ''))
                except ValueError:
                    questions.append(f'{layer.name}: missing or unsupported fibre sizes; this cable population was not partially counted.')
                    blocked.update(CABLE_ROWS.values())
                    continue
                for size, row in CABLE_ROWS.items():
                    for raw, purpose in sorted(by_capacity.get(size, {('__absent_capacity__', '__absent_role__')})):
                        filt = ((capacity, raw),) + (((cable_role, purpose),) if cable_role else ())
                        if route and (slack or total):
                            add(row, layer, 'length', route, slack_field=slack, total_field=total,
                                filters=filt, allow_empty_filter=True)
                        else:
                            add(row, layer, 'sum', total, filters=filt, allow_empty_filter=True)
            elif role == 'quantities':
                # Explicit BOQ row headers are self-describing. No inferred seals/ends.
                for row in INPUT_ROWS:
                    if ambiguous_field(layer.fields, (f'BOQ {row}',)):
                        blocked.add(row)
                        questions.append(f'{layer.name}: competing recorded quantities for BOQ item {row}.')
                        continue
                    field = unique_field(layer.fields, (f'BOQ {row}',))
                    if field:
                        add(row, layer, 'sum', field)

    # Two independent representations of the same item must not silently sum.
    for row in INPUT_ROWS:
        sources = {b.layer for b in bindings if b.row == row}
        if len(sources) > 1:
            explicit = any(set(sources) <= set(ids) for ids in (*selections.values(), *auto_selected.values()))
            if not explicit:
                bindings = [b for b in bindings if b.row != row]
                questions.append(f'BOQ item {row}: more than one source represents this quantity; select the intended population.')
    bindings = [b for b in bindings if b.row not in blocked]
    # A derived seal total is only as complete as its entire FD4 population.
    fd4_sources = {b.layer for b in bindings if b.row == 29}
    for row in (30, 31):
        derived = [b for b in bindings if b.row == row and 'F30:F31' in b.rationale]
        if derived and (not fd4_sources or {b.layer for b in derived} != fd4_sources):
            bindings = [b for b in bindings if b not in derived]
            questions.append('Mechanical seals: the complete FD4 enclosure population is unresolved.')
    reasons = {row: detail for row, detail in reasons.items() if any(b.row == row for b in bindings)}
    return Discovery(tuple(bindings), tuple(dict.fromkeys(questions)),
                     {k: tuple((v.identity, v.name) for v in vs) for k, vs in candidates.items() if vs}, reasons,
                     {k: tuple(v) for k, v in requested_facts.items() if v}, tuple(observations))
