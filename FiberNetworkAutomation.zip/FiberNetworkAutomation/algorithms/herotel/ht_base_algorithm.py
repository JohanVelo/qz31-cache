# Base Algorithm Class for HeroTel Group C Network Design
# claude:approved-destructive — stub base class, follows existing BaseFiberAlgorithm pattern

from qgis.core import QgsProcessingAlgorithm


class HeroTelBaseAlgorithm(QgsProcessingAlgorithm):
    """Base class for HeroTel network design algorithms (TSD standard)"""

    # Shared constants
    SNAP_DEG = 10.0 / 111320.0  # 10 m snap tolerance in degrees
    ONTS_PER_PON = 102  # Target ONTs per PON (GPON max 128, 20% spare)
    STS_CAPACITY = 16  # ONTs per STS (1:16 splitter)

    # Configurable defaults (TSD standard — NOT hardcoded like MOA)
    PON_START = 1
    ZONE_START = 1

    def createInstance(self):
        return self.__class__()

    def group(self):
        return 'HeroTel Network Design'

    def groupId(self):
        return 'herotelnetworklabeling'

    def size_secondary_cable(self, pon_count):
        """
        Determine secondary cable size based on PON count (2×PON rule for active + spare).

        Args:
            pon_count (int): Number of PONs served by this secondary cable.

        Returns:
            str: Cable capacity label ('24F', '48F', '96F', '144F', or None if invalid).
        """
        pairs_needed = pon_count * 2  # Active + spare
        # ht_05 spec: 24F=1-6, 48F=7-16, 96F=17-32, 144F=33-64 PONs
        # → with pairs_needed = pon_count*2 the cuts are 12 / 32 / 64 / 128 pairs
        if pairs_needed <= 12:
            return '24F'
        elif pairs_needed <= 32:
            return '48F'
        elif pairs_needed <= 64:
            return '96F'
        elif pairs_needed <= 128:
            return '144F'
        else:
            return None  # Exceeds 144F; split into multiple secondaries

    def bulk_set_static_fields(self, layer, field_values: dict, feedback=None,
                               overwrite_existing: bool = False):
        """
        Write static values to features for each named field.

        Args:
            layer:              Vector layer (must not be in an active edit session)
            field_values:       {field_name: value, ...}
            feedback:           Optional processing feedback
            overwrite_existing: If False (default), skip per-field write where
                                current value is already non-NULL/non-empty.
        """
        try:
            for field_name, value in field_values.items():
                field_idx = layer.fields().indexOf(field_name)
                if field_idx == -1:
                    if feedback:
                        feedback.pushWarning(f"Field '{field_name}' not found — skipping")
                    continue

                attr_map = {}
                for feature in layer.getFeatures():
                    fid = feature.id()
                    current_val = feature[field_idx]

                    # Skip if field already has a non-NULL value (unless overwrite_existing=True)
                    if not overwrite_existing and current_val is not None and current_val != '':
                        continue

                    attr_map[fid] = {field_idx: value}

                if attr_map:
                    layer.dataProvider().changeAttributeValues(attr_map)
                    if feedback:
                        feedback.pushInfo(f"[OK] {field_name} set ({len(attr_map)} features)")

        except Exception as e:
            if feedback:
                feedback.reportError(f"Error in bulk_set_static_fields: {e!s}")
