"""health_panel — a local System Health view (Green/Amber/Red).

Surfaces the safety nets that already run silently — Geometry Guardian, the UI
freeze watchdog, auto error-capture, and the offline outbox depth — so an
operator can SEE at a glance whether the system is healthy, degrading, or in
trouble BEFORE a silent failure bites. Purely local + read-only; never sends.

  compute_health()         → {'level': GREEN/AMBER/RED, 'signals': [...]}
  show_health_panel(iface) → open the dialog
"""
import os
import json
import time

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame,
)

_prev = [None]
_INCIDENTS = os.path.join(os.path.expanduser("~"), ".velocity_nexus",
                          "guardian_incidents.json")

_BG = "#0d0f12"
_INK = "#e6edf3"
_DIM = "#8b98a5"
_COLOR = {"GREEN": "#34d399", "AMBER": "#f59e0b", "RED": "#f43f5e"}
_RANK = {"GREEN": 0, "AMBER": 1, "RED": 2}
_MONO = "Consolas, 'JetBrains Mono', monospace"


def _plugin():
    try:
        from qgis.utils import plugins
        return plugins.get("FiberNetworkAutomation")
    except Exception:
        return None


def _incident_ages():
    """Return (total, count_last_hour, count_today) from the local incident log."""
    try:
        with open(_INCIDENTS, encoding="utf-8") as f:
            rows = json.load(f)
    except Exception:
        return 0, 0, 0
    if not isinstance(rows, list):
        return 0, 0, 0
    now = time.time()
    hour = today = 0
    from datetime import datetime
    for r in rows:
        ts = r.get("ts_iso", "")
        try:
            age = now - datetime.fromisoformat(ts).timestamp()
        except Exception:
            continue
        if age <= 3600:
            hour += 1
        if age <= 86400:
            today += 1
    return len(rows), hour, today


def compute_health():
    """Best-effort system health. Never raises."""
    sig = []

    def add(label, state, detail):
        sig.append({"label": label, "state": state, "detail": detail})

    p = _plugin()

    g = getattr(p, "_geometry_guardian", None) if p else None
    add("Geometry Guardian", "GREEN" if g is not None else "RED",
        "watching layers — mass-loss auto-restore active" if g is not None
        else "NOT running — auto-restore inactive")

    fw = getattr(p, "_freeze_watchdog", None) if p else None
    add("UI freeze watchdog", "GREEN" if fw is not None else "AMBER",
        "active" if fw is not None else "not running")

    inst = None
    try:
        from .fibre_automation.nexus_profile import error_capture
        inst = error_capture._state.get("installed")
    except Exception:
        try:
            from FiberNetworkAutomation.fibre_automation.nexus_profile import error_capture
            inst = error_capture._state.get("installed")
        except Exception:
            inst = None
    add("Auto error-capture → ticket", "GREEN" if inst else "AMBER",
        "installed — crashes auto-file tickets" if inst else "not installed")

    depth = None
    try:
        nx = getattr(p, "_nexus", None) if p else None
        backend = getattr(nx, "backend", None) if nx else None
        if backend is not None:
            try:
                from .fibre_automation.nexus_profile import spool
            except Exception:
                from FiberNetworkAutomation.fibre_automation.nexus_profile import spool
            depth = len(spool.read_all(backend.data_dir))
    except Exception:
        depth = None
    if depth is None:
        add("Outbox (offline queue)", "AMBER", "unknown")
    elif depth == 0:
        add("Outbox (offline queue)", "GREEN", "empty — tickets/errors all delivered")
    elif depth > 50:
        add("Outbox (offline queue)", "RED",
            f"{depth} records queued — not reaching the server (offline?)")
    else:
        add("Outbox (offline queue)", "AMBER",
            f"{depth} record(s) queued, will retry on reconnect")

    total, hour, today = _incident_ages()
    if hour > 0:
        add("Geometry incidents", "RED",
            f"{hour} mass-loss incident(s) in the last hour (auto-restored)")
    elif today > 0:
        add("Geometry incidents", "AMBER", f"{today} incident(s) today (auto-restored)")
    else:
        add("Geometry incidents", "GREEN",
            f"none recent ({total} total in the log)" if total else "none recorded")

    level = "GREEN"
    for s in sig:
        if _RANK[s["state"]] > _RANK[level]:
            level = s["state"]
    return {"level": level, "signals": sig}


class HealthPanel(QDialog):
    def __init__(self, iface=None, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self.setWindowTitle("Velocity Nexus — System Health")
        self.resize(620, 460)
        self.setStyleSheet(f"QDialog{{background:{_BG};}} QLabel{{color:{_INK};}}"
                           f"QPushButton{{background:#1b2128;color:{_INK};border:1px solid #2a323a;"
                           f"border-radius:7px;padding:6px 14px;font-weight:600;}}"
                           f"QPushButton:hover{{border-color:#22d3ee;color:#22d3ee;}}")
        self._build()
        self._reload()

    def _build(self):
        self._root = QVBoxLayout(self)
        self._root.setContentsMargins(16, 16, 16, 16)
        self._root.setSpacing(10)
        self._headline = QLabel("")
        self._headline.setStyleSheet(f"font-family:{_MONO}; font-size:18px; font-weight:800;")
        self._root.addWidget(self._headline)
        self._sub = QLabel("These run silently on every machine. This view makes them visible.")
        self._sub.setStyleSheet(f"color:{_DIM};")
        self._sub.setWordWrap(True)
        self._root.addWidget(self._sub)
        self._rows = QVBoxLayout()
        self._rows.setSpacing(6)
        self._root.addLayout(self._rows)
        self._root.addStretch(1)
        foot = QHBoxLayout()
        foot.addStretch(1)
        b = QPushButton("Refresh")
        b.clicked.connect(self._reload)
        foot.addWidget(b)
        c = QPushButton("Close")
        c.clicked.connect(self.close)
        foot.addWidget(c)
        self._root.addLayout(foot)

    def _reload(self):
        # clear rows
        while self._rows.count():
            it = self._rows.takeAt(0)
            w = it.widget()
            if w:
                w.deleteLater()
        h = compute_health()
        col = _COLOR[h["level"]]
        word = {"GREEN": "HEALTHY", "AMBER": "DEGRADED", "RED": "ATTENTION NEEDED"}[h["level"]]
        dot = {"GREEN": "\U0001f7e2", "AMBER": "\U0001f7e1", "RED": "\U0001f534"}[h["level"]]
        self._headline.setText(f"{dot}  SYSTEM {word}")
        self._headline.setStyleSheet(f"font-family:{_MONO}; font-size:18px; font-weight:800; color:{col};")
        for s in h["signals"]:
            row = QFrame()
            row.setStyleSheet("QFrame{background:#14181d;border:1px solid #232a31;border-radius:8px;}")
            lay = QHBoxLayout(row)
            lay.setContentsMargins(10, 7, 10, 7)
            sc = _COLOR[s["state"]]
            d = {"GREEN": "\U0001f7e2", "AMBER": "\U0001f7e1", "RED": "\U0001f534"}[s["state"]]
            lab = QLabel(f"{d}  {s['label']}")
            lab.setStyleSheet(f"color:{_INK}; font-family:{_MONO}; font-weight:700;")
            det = QLabel(s["detail"])
            det.setStyleSheet(f"color:{sc}; font-family:{_MONO};")
            det.setWordWrap(True)
            lay.addWidget(lab)
            lay.addStretch(1)
            lay.addWidget(det)
            self._rows.addWidget(row)


def show_health_panel(iface=None):
    try:
        if _prev[0] is not None:
            try:
                _prev[0].close()
            except Exception:
                pass
        parent = iface.mainWindow() if iface else None
        dlg = HealthPanel(iface, parent)
        _prev[0] = dlg
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()
        return dlg
    except Exception:
        return None
