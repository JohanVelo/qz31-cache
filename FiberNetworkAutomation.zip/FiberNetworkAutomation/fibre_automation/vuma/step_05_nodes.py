"""Vuma Step 5 — Place network nodes (Aggregation Joint, Dome Joint, Poles).

STATUS: [ ] STUB — requires road network layer
"""

from qgis.core import QgsProject


def _get(name):
    layers = QgsProject.instance().mapLayersByName(name)
    return layers[0] if layers else None


def vuma_step_05_nodes():
    """Place Aggregation Joints, Dome Joints, and Poles along road network.

    STATUS: [ ] STUB
    Requires:
      - 'Aggregation Polygon' layer (from Step 4)
      - 'Demand Points' layer (from Step 3)
      - Road network layer (OSM or custom)

    TODO:
      1. For each Aggregation Polygon centroid → place one Aggregation Joint
      2. For each PON cluster → place Dome Joint at geometric median of cluster
      3. Place Poles along cable routes at 40-60 m intervals + every junction
      4. Snap nodes to nearest road vertex within 15 m
    """
    print(f"\n{'═' * 50}")
    print("  VUMA STEP 5 — Node Placement")
    print(f"{'═' * 50}")
    print("  ⚠ Step 5 is a stub — road network integration not yet built.")
    print("  Manual placement required for Aggregation Joints, Dome Joints,")
    print("  and Poles until road routing is available.")
    print(f"{'═' * 50}\n")
