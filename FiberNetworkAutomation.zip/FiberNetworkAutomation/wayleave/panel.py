"""Wayleave panel: four steps from a hand-drawn wayleave to the PDF, written for a planner doing it the first time.

  1 Draw      the guide, what the project needs (live status), snapping, Span Inspector / Live Measure
  2 Check     Check My Wayleave: read-only; problems listed and marked on the map
  3 Generate  backup -> poles, vertices, Span, attributes, symbology, themes -> Keep or Undo
  4 Print     the Wayleave theme and the HLD Atlas PDF tool on its wayleave model

Opened from the WAYLEAVE group in Velocity Nexus Home. QGIS 3.38 - 4.2.
"""
# claude:intent MUTATE — user asked: "Make a Wayleave section ... Generate finished Wayleave ... then you're
# ready to print the Wayleave in the Atlas PDF tool" (JJ 2026-10-23). — plan: UI only; writes happen in
# qgis_io.apply() after a verified backup, into edit buffers the planner keeps or undoes.
# claude:approved-destructive — every write path runs qgis_io.backup() first and stays uncommitted until Keep.
import os
import traceback

from qgis.core import (Qgis, QgsApplication, QgsProject, QgsRectangle, QgsSnappingConfig, QgsTask,
                       QgsTolerance)
from qgis.PyQt import sip
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QDockWidget, QDoubleSpinBox,
                                 QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                                 QPushButton, QTabWidget, QTextBrowser, QTreeWidget, QTreeWidgetItem,
                                 QVBoxLayout, QWidget)

from . import qgis_io as io

try:
    from ..fibre_automation import wayleave_finish as wf
except ImportError:
    from fibre_automation import wayleave_finish as wf

_PANEL = None
GROUP_LABEL = {   # one line per kind of problem; expand the row to see each one and double-click to zoom
    'home_far': 'homes more than 60 m from a distribution cable',
    'close_vertices': 'places where two cables have vertices 0.5-3 m apart',
    'near_miss': 'cable ends that stop just short of another cable',
    'dc_start_gap': 'distribution cables that start a little off their 1:16',
    's16_unused': '1:16s that start no distribution cable',
    's16_off_cable': '1:16s not on a feeder or link cable',
    'pon_no_s16': 'PONs without a 1:16',
    'pon_two_s16': 'PONs with more than one 1:16',
    'pon_no_dc': 'PONs without a distribution cable',
    'pon_big': 'PONs with more than 112 homes',
    'link_loose': 'link cables not joined to a feeder or link',
    's16_not_connected': '1:16s on a cable that does not reach the POP',
    's16_two_pons': '1:16s that start distribution cables in two PONs',
    'feeder_far_pop': 'feeders that do not start at the POP',
    'empty_cable': 'cables with no length',
    'close_poles': 'places where two poles stand 0.5-3 m apart',
}
REFUSE = ('mohadin', 'chloorkop', 'potch')   # shipped / Fibertime projects: never generate there


def _n(k, word):
    return f"{k} {word}{'' if k == 1 else 's'}"


def _set_first(setter, candidates):
    """Call setter with the first enum value that exists: (owner, enum class name or None, member)."""
    for owner, enum_name, member in candidates:
        try:
            setter(getattr(getattr(owner, enum_name) if enum_name else owner, member))
            return True
        except Exception:
            continue
    return False


_VELOCITY = {   # the Velocity Nexus default theme, used if the Home panel's themes cannot be read
    'bg': '#05070C', 'accent': 'qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #1AE5FF, stop:1 #1AA6FF)',
    'word_top': '#EAF3FF', 'tagline': '#7E93B8', 'section': '#7E93B8', 'step_bg': '#0D1320', 'step_hover': '#131D2E',
    'step_border': '#1B2940', 'step_hi': '#1AE5FF', 'title': '#EAF3FF', 'sub': '#8AA0BE', 'tool_bg': '#0D1320',
    'tool_text': '#C9DDF2', 'tool_hover': '#131D2E', 'status_on': '#3DFF9A', 'status_off': '#FF4D5E', 'badge_text': '#04070D'}


def _theme():
    """The Nexus theme the planner picked for Home, so this panel looks like part of the same tool."""
    try:
        try:
            from ..velocity_home_panel import THEMES
        except ImportError:
            from velocity_home_panel import THEMES
        from qgis.core import QgsSettings
        name = QgsSettings().value('VelocityFibre/panel_theme', 'velocity')
        return dict(_VELOCITY, **THEMES.get(name, THEMES.get('velocity', {})))
    except Exception:
        return dict(_VELOCITY)


def _colors(w=None):
    t = _theme()
    return dict(ink=t['title'], muted=t['sub'], accent=t['step_hi'], warn='#FFB020', ok=t['status_on'],
                bad=t['status_off'], bg=t['step_bg'])


def _qss(t):
    return f"""
QWidget#wlRoot {{ background:{t['bg']}; }}
QWidget#wlRoot QLabel {{ color:{t['title']}; }}
QLabel#wlTitle {{ color:{t['word_top']}; font-size:20px; font-weight:800; letter-spacing:0.5px; }}
QLabel#wlTag {{ color:{t['tagline']}; font-size:11px; }}
QLabel#wlStep {{ color:{t['badge_text']}; background:{t['accent']}; border-radius:9px; padding:3px 9px; font-weight:800; font-size:11px; }}
QTabWidget::pane {{ border:1px solid {t['step_border']}; border-radius:10px; background:{t['step_bg']}; top:-1px; }}
QTabBar::tab {{ background:{t['tool_bg']}; color:{t['sub']}; border:1px solid {t['step_border']}; padding:7px 14px;
               margin-right:4px; border-top-left-radius:9px; border-top-right-radius:9px; font-weight:700; }}
QTabBar::tab:hover {{ background:{t['tool_hover']}; color:{t['title']}; }}
QTabBar::tab:selected {{ background:{t['accent']}; color:{t['badge_text']}; border-color:{t['step_hi']}; }}
QTextBrowser {{ background:{t['bg']}; color:{t['title']}; border:1px solid {t['step_border']}; border-radius:8px; padding:6px;
               selection-background-color:{t['step_hi']}; selection-color:{t['badge_text']}; }}
QPushButton {{ background:{t['tool_bg']}; color:{t['tool_text']}; border:1px solid {t['step_border']}; border-radius:8px;
              padding:7px 12px; font-weight:600; }}
QPushButton:hover {{ background:{t['tool_hover']}; border-color:{t['step_hi']}; color:{t['title']}; }}
QPushButton:disabled {{ color:{t['step_border']}; border-color:{t['step_border']}; }}
QPushButton#wlPrimary {{ background:{t['accent']}; color:{t['badge_text']}; border:none; padding:10px 14px; font-size:13px; font-weight:800; }}
QPushButton#wlPrimary:hover {{ border:1px solid #FFFFFF; }}
QPushButton#wlPrimary:disabled {{ background:{t['step_border']}; color:{t['sub']}; }}
QTreeWidget {{ background:{t['bg']}; color:{t['title']}; border:1px solid {t['step_border']}; border-radius:8px;
              alternate-background-color:{t['step_bg']}; selection-background-color:{t['step_hover']}; selection-color:{t['title']}; }}
QHeaderView::section {{ background:{t['step_bg']}; color:{t['sub']}; border:none; border-bottom:1px solid {t['step_border']};
                       padding:4px 6px; font-weight:700; }}
QLineEdit, QDoubleSpinBox, QComboBox {{ background:{t['bg']}; color:{t['title']}; border:1px solid {t['step_border']};
                                       border-radius:7px; padding:5px 8px; }}
QLineEdit:focus, QDoubleSpinBox:focus, QComboBox:focus {{ border:1px solid {t['step_hi']}; }}
QCheckBox {{ color:{t['title']}; spacing:8px; }}
QFrame#wlCard {{ background:{t['bg']}; border:1px solid {t['step_border']}; border-radius:8px; }}
QScrollBar:vertical {{ background:transparent; width:9px; margin:0; }}
QScrollBar::handle:vertical {{ background:{t['step_border']}; border-radius:4px; min-height:30px; }}
QScrollBar::handle:vertical:hover {{ background:{t['step_hi']}; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height:0; }}
"""


GUIDE_DRAW = """
<h3>Step 1 · Draw the wayleave</h3>
<p>You draw the <b>cables</b> and the <b>1:16 splitters</b>. You do <b>not</b> draw poles or the Span, and you do not
fill in attribute tables: Step 3 does all of that from your drawing.</p>

<h4>Before you start</h4>
<ol>
<li>Check the list below: every layer marked <i>needed</i> must be there.</li>
<li>Your AOI must be an editable layer (shapefile or GeoPackage). A KMZ cannot be edited: right-click it,
<i>Export &gt; Save Features As</i>, pick ESRI Shapefile.</li>
<li>Press <b>Turn on snapping</b>. Every cable end you draw must land exactly on a vertex.</li>
<li>Switch the Erven parcel numbers on (Step 3 does it too) so you can see the stands while you draw.</li>
</ol>

<h4>A · The POP</h4>
<p>One point, where the fibre enters town. Every feeder starts here.</p>

<h4>B · Feeder cables</h4>
<ul>
<li>Start at the POP. Draw <b>one continuous line per direction</b>. Never start a feeder off another feeder.</li>
<li>Run in the road reserve on <b>one side</b> of the road, about 5 m from the centre line, never over erven.</li>
<li>Keep runs straight. Cross a road only where you must, and cross it <b>square</b> (90°).</li>
<li>Put a vertex wherever a pole must stand: every corner, every turn, and <b>both sides</b> of a road crossing.
On long straight runs Step 3 adds the poles for you (at most 70 m apart).</li>
<li>Pass along the PON borders so the feeder can reach as many 1:16s as possible.</li>
</ul>

<h4>C · 1:16 splitters (one per PON)</h4>
<ul>
<li><b>Exactly one</b> in every PON, no more, no less. 80 PONs = 80 splitters.</li>
<li>Place it <b>on</b> the feeder or link cable, snapped to a vertex, at the edge of its PON.</li>
<li>That PON's distribution cable starts at exactly this point.</li>
</ul>

<h4>D · Link cables</h4>
<ul>
<li>Only where the feeder cannot reach a PON.</li>
<li>Start <b>on a vertex</b> of a feeder or another link; end <b>on a 1:16</b>. One link may pass several 1:16s.</li>
</ul>

<h4>E · Distribution cables</h4>
<ul>
<li>Start exactly <b>on the PON's 1:16</b>.</li>
<li>Run along the <b>rear lines</b> of the erven (the back boundary between two rows of stands), so every house's
drop is short. Use every block's rear line.</li>
<li>Put vertices on erf corners: that is where the poles go.</li>
<li>Branch a spur off at a <b>vertex</b> of the distribution cable, never in the middle of a span.</li>
<li>Every home must be within <b>60 m</b> of a distribution cable. Stay inside the PON. Never cross over houses.</li>
</ul>

<h4>F · While you draw</h4>
<ul>
<li><b>Live Measure</b> (in the Span Inspector) shows the length of what you are drawing.</li>
<li>After Step 3, open the <b>Span Inspector</b> at <b>70 m</b>: nothing should light up.</li>
<li>Save your edits (Ctrl+S on each layer), then go to <b>Step 2</b>.</li>
</ul>
"""

GUIDE_CHECK = """
<h3>Step 2 · Check my wayleave</h3>
<p>Reads your drawing and lists every problem. <b>It never changes your data</b>; it only adds a temporary
<i>Wayleave Check</i> marker layer that is not saved with the project.</p>
<ul>
<li><span style="color:{bad}"><b>Errors</b></span> stop Step 3: wrong number of 1:16s, a PON without one, a 1:16 off the
cable, a link not joined to the feeder, a PON with no distribution cable.</li>
<li><span style="color:{warn}"><b>Warnings</b></span> are for you to judge: homes over 60 m from a cable, cable ends a few
metres short of another cable, two vertices that would become poles side by side, PONs over 112 homes.</li>
<li>Double-click a line to zoom to it. Fix, save, and press Check again until there are no errors.</li>
</ul>
"""

GUIDE_GENERATE = """
<h3>Step 3 · Generate finished wayleave</h3>
<p>Turns your checked drawing into the finished wayleave:</p>
<ul>
<li>adds vertices where a cable end or 1:16 sits on another cable, and on every gap longer than the max span;</li>
<li>puts a pole on every vertex (HeroTel sizes: 7.2 m feeder and road-crossing poles, 5.4 m others;
120-140 mm on turns over 45°);</li>
<li>draws the <b>Span</b>: all cables as continuous lines, broken only at junctions;</li>
<li>fills every attribute table, numbered by walking out from the POP: PON 01, 02..., FC01, LC01, DC001,
poles 0001PL..., lengths and HeroTel slack (15/20 m start, 20 m per 1:16, 29 m per road crossing);</li>
<li>applies the wayleave symbology, the erf parcel numbers and the <i>Network</i> and <i>Wayleave</i> map themes.</li>
</ul>
<p><b>Your cables never move:</b> every vertex you drew stays exactly where it is. A backup of every layer it changes
is written first to the folder below. The changes stay unsaved until you press <b>Keep</b>; <b>Undo</b> puts
everything back.</p>
"""

GUIDE_PRINT = """
<h3>Step 4 · Print the wayleave</h3>
<ol>
<li>Press <b>Show the Wayleave theme</b>: red Span, poles, erven with parcel numbers, roads.</li>
<li>Press <b>Open the HLD Atlas PDF</b>. It opens on the <i>Wayleave</i> layout model (the numbered
775 × 550 m plotting grid).</li>
<li>Check the pages: every erf number readable, the Span unbroken, poles visible, title block filled in.</li>
<li>Export, then send the PDF with a KMZ (Velocity Nexus <i>Export KMZ</i>).</li>
</ol>
"""


class LayerPicker(QDialog):
    def __init__(self, found, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Wayleave layers')
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        lay = QFormLayout(self); self.combos = {}
        for role, (label, geom, _, req) in io.ROLES.items():
            cb = QComboBox(); cb.addItem('(none)', '')
            for lyr in io.vector_layers(geom):
                cb.addItem(lyr.name(), lyr.id())
            cur = found.get(role)
            if cur is not None:
                cb.setCurrentIndex(max(0, cb.findData(cur.id())))
            self.combos[role] = cb
            lay.addRow(f"{label}{' (needed)' if req else ''}:", cb)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject); lay.addRow(bb)

    def picks(self):
        proj = QgsProject.instance()
        return {r: (proj.mapLayer(cb.currentData()) if cb.currentData() else None) for r, cb in self.combos.items()}


class WayleavePanel(QDockWidget):
    def __init__(self, iface, owner=None):
        super().__init__('Final Wayleave', iface.mainWindow())
        self.setObjectName('VelocityWayleavePanel')
        self.iface = iface; self.owner = owner; self.task = None; self.issues = []; self.result = None
        self.found = io.find_layers()
        root = QWidget(); root.setObjectName('wlRoot'); v = QVBoxLayout(root)
        v.setContentsMargins(14, 12, 14, 12); v.setSpacing(10)
        head = QHBoxLayout(); col = QVBoxLayout(); col.setSpacing(1)
        title = QLabel('Final Wayleave'); title.setObjectName('wlTitle')
        tag = QLabel('From your drawing to the PDF in four steps · HeroTel · BETA'); tag.setObjectName('wlTag')
        col.addWidget(title); col.addWidget(tag); head.addLayout(col, 1)
        step = QLabel('STEP 8'); step.setObjectName('wlStep'); head.addWidget(step, 0, Qt.AlignmentFlag.AlignTop)
        v.addLayout(head)
        self.tabs = QTabWidget(); self.tabs.setDocumentMode(False); v.addWidget(self.tabs, 1)
        self.tabs.addTab(self._tab_draw(), '1  Draw')
        self.tabs.addTab(self._tab_check(), '2  Check')
        self.tabs.addTab(self._tab_generate(), '3  Generate')
        self.tabs.addTab(self._tab_print(), '4  Print')
        root.setStyleSheet(_qss(_theme()))
        self.setWidget(root)
        self.refresh_status()
        try:
            try:
                from ..nexus_dock import apply_dock_chrome
            except ImportError:
                from nexus_dock import apply_dock_chrome
            apply_dock_chrome(self)
        except Exception:
            pass

    # ── helpers ──
    def _browser(self, html):
        b = QTextBrowser(); b.setOpenExternalLinks(True)
        c = _colors(self)
        css = (f"<style>h3{{color:{c['accent']};font-size:15px;margin:2px 0 6px 0}} h4{{color:{c['ink']};margin:12px 0 4px 0}}"
               f" li{{margin-bottom:3px}} i{{color:{c['muted']}}}</style>")
        b.setHtml(css + f"<div style='color:{c['ink']}'>" + html.replace('{bad}', c['bad']).replace('{warn}', c['warn']) + '</div>')
        return b

    def _msg(self, text, level=Qgis.MessageLevel.Info, secs=8):
        try:
            self.iface.messageBar().pushMessage('Wayleave', text, level=level, duration=secs)
        except Exception:
            pass

    def _project_refused(self):
        name = (QgsProject.instance().fileName() or '').lower()
        return any(k in name for k in REFUSE)

    # ── step 1 ──
    def _tab_draw(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._browser(GUIDE_DRAW), 3)
        self.status = QLabel(); self.status.setWordWrap(True); self.status.setTextFormat(Qt.TextFormat.RichText)
        v.addWidget(self.status)
        row = QHBoxLayout()
        for text, fn in (('Choose layers…', self.choose_layers), ('Turn on snapping', self.snapping),
                         ('Span Inspector', self.open_span_inspector)):
            b = QPushButton(text); b.clicked.connect(fn); row.addWidget(b)
        v.addLayout(row)
        return w

    def refresh_status(self):
        c = _colors(self); rows = []
        for role, (label, _, _, req) in io.ROLES.items():
            lyr = self.found.get(role)
            if lyr is not None:
                rows.append(f"<span style='color:{c['ok']}'>✔</span> {label}: <i>{lyr.name()}</i> ({lyr.featureCount()})")
            elif req:
                rows.append(f"<span style='color:{c['bad']}'>✘</span> {label}: <b>needed</b>, not found")
            elif role in ('poles', 'span'):
                rows.append(f"<span style='color:{c['muted']}'>○</span> {label}: none yet, Step 3 creates it")
            else:
                rows.append(f"<span style='color:{c['muted']}'>○</span> {label}: not found (optional)")
        self.status.setText('<b>In this project</b><br>' + '<br>'.join(rows))

    def choose_layers(self):
        d = LayerPicker(self.found, self)
        if d.exec():
            self.found = d.picks(); io.save_layer_picks(self.found); self.refresh_status()

    def snapping(self):
        proj = QgsProject.instance(); cfg = proj.snappingConfig()
        cfg.setEnabled(True)
        # enum homes moved between QGIS 3.x and 4.x: try the new one, fall back to the old
        _set_first(cfg.setMode, [(Qgis, 'SnappingMode', 'AllLayers'), (QgsSnappingConfig, 'SnappingMode', 'AllLayers'),
                                 (QgsSnappingConfig, None, 'AllLayers')])
        try:
            cfg.setTypeFlag(Qgis.SnappingType.Vertex | Qgis.SnappingType.Segment)
        except Exception:
            pass
        cfg.setTolerance(12)
        _set_first(cfg.setUnits, [(Qgis, 'MapToolUnit', 'Pixels'), (QgsTolerance, 'UnitType', 'Pixels'), (QgsTolerance, None, 'Pixels')])
        proj.setSnappingConfig(cfg)
        self._msg('Snapping on: all layers, vertex + segment, 12 px. Cable ends will land exactly on vertices.')

    def open_span_inspector(self):
        try:
            try:
                from ..span_inspector import show_span_inspector
            except ImportError:
                from FiberNetworkAutomation.span_inspector import show_span_inspector
            show_span_inspector(self.iface)
        except Exception as e:
            self._msg(f'Could not open the Span Inspector: {e}', Qgis.MessageLevel.Warning)

    # ── step 2 ──
    def _tab_check(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._browser(GUIDE_CHECK), 1)
        b = QPushButton('Check my wayleave'); b.setObjectName('wlPrimary'); b.clicked.connect(self.run_check); v.addWidget(b)
        self.verdict = QLabel(''); self.verdict.setWordWrap(True); v.addWidget(self.verdict)
        self.tree = QTreeWidget(); self.tree.setHeaderLabels(['#', 'Level', 'What to fix']); self.tree.setRootIsDecorated(False); self.tree.setAlternatingRowColors(True)
        self.tree.itemDoubleClicked.connect(self._zoom_issue); v.addWidget(self.tree, 2)
        self.detail = QLabel('Click a line to read it in full; double-click to zoom to it on the map.')
        self.detail.setWordWrap(True); self.detail.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.tree.currentItemChanged.connect(lambda cur, _prev: self.detail.setText(cur.toolTip(2) if cur is not None and cur.toolTip(2) else self.detail.text()))
        v.addWidget(self.detail)
        return w

    def run_check(self):
        self.found = io.find_layers(); self.refresh_status()
        try:
            inp = io.read_inputs(self.found)
            self.issues = wf.check(inp, dict(max_span=self._max_span()))
        except io.WayleaveIOError as e:
            self.issues = [dict(level='error', code='layers', msg=str(e), at=None)]
        except Exception as e:
            self.issues = [dict(level='error', code='crash', msg=f'Check failed: {e}', at=None)]
            traceback.print_exc()
        if any(i.get('at') is not None for i in self.issues):
            io.put_markers(self.found, self.issues)
        self._show_issues()
        return self.issues

    def _show_issues(self):
        c = _colors(self); s = wf.summary(self.issues)
        self.tree.clear()
        order = {'error': 0, 'warn': 1, 'info': 2}
        level_name = {'error': 'Error', 'warn': 'Warning', 'info': 'Note'}
        groups = {}
        for i in sorted(self.issues, key=lambda i: (order.get(i['level'], 3), i.get('no') or 0)):
            groups.setdefault((i['level'], i['code']), []).append(i)
        for (level, code), items in sorted(groups.items(), key=lambda kv: (order.get(kv[0][0], 3), -len(kv[1]))):
            if len(items) == 1:
                i = items[0]
                it = QTreeWidgetItem([str(i.get('no', '')), level_name.get(level, level), i['msg']])
                it.setData(0, Qt.ItemDataRole.UserRole, i.get('at')); it.setToolTip(2, i['msg']); self.tree.addTopLevelItem(it)
                continue
            head = QTreeWidgetItem(['', level_name.get(level, level), f"{len(items)} × {GROUP_LABEL.get(code, items[0]['msg'])}"])
            for i in items:
                ch = QTreeWidgetItem([str(i.get('no', '')), '', i['msg']])
                ch.setData(0, Qt.ItemDataRole.UserRole, i.get('at')); ch.setToolTip(2, i['msg']); head.addChild(ch)
            head.setToolTip(2, f"{len(items)} × {GROUP_LABEL.get(code, items[0]['msg'])}. Expand to see each one.")
            self.tree.addTopLevelItem(head); head.setExpanded(level == 'error' and len(items) <= 5)
        self.tree.setRootIsDecorated(any(len(v) > 1 for v in groups.values()))
        self.tree.resizeColumnToContents(0); self.tree.resizeColumnToContents(1)
        if s['errors']:
            self.verdict.setText(f"<span style='color:{c['bad']}'><b>{s['errors']} errors</b></span> to fix before Step 3 · {_n(s['warnings'], 'warning')} · {_n(s['info'], 'note')}")
        else:
            self.verdict.setText(f"<span style='color:{c['ok']}'><b>Ready to generate.</b></span> 0 errors · {_n(s['warnings'], 'warning')} to look at · {_n(s['info'], 'note')}")

    def _zoom_issue(self, item, _col):
        at = item.data(0, Qt.ItemDataRole.UserRole)
        if not at or self.found.get('feeder') is None:
            return
        p = io.metric_to(self.found, self.iface.mapCanvas().mapSettings().destinationCrs())((at[0], at[1]))
        d = 60.0 if self.iface.mapCanvas().mapSettings().destinationCrs().isGeographic() is False else 0.0006
        self.iface.mapCanvas().setExtent(QgsRectangle(p.x() - d, p.y() - d, p.x() + d, p.y() + d)); self.iface.mapCanvas().refresh()

    # ── step 3 ──
    def _tab_generate(self):
        w = QWidget(); v = QVBoxLayout(w)
        guide = self._browser(GUIDE_GENERATE); guide.setMaximumHeight(330); v.addWidget(guide, 1)
        form = QFormLayout()
        self.town = QLineEdit(io.setting('town', io.town_default())); self.town.setMaxLength(6)
        self.town.setToolTip('Three-letter town code used in every name, e.g. DEN for Deneysville: HT_DEN_0001PL.')
        form.addRow('Town code:', self.town)
        self.span = QDoubleSpinBox(); self.span.setRange(30, 100); self.span.setSuffix(' m'); self.span.setDecimals(0)
        self.span.setValue(float(io.setting('max_span', 70)))
        self.span.setToolTip('Longest pole-to-pole gap. HeroTel: 60-70 m.')
        form.addRow('Max span:', self.span)
        self.folder = QLineEdit(io.setting('backup_folder', self._default_folder()))
        self.folder.setToolTip(self.folder.text()); self.folder.textChanged.connect(self.folder.setToolTip)
        fb = QPushButton('Browse…'); fb.clicked.connect(self._pick_folder)
        row = QHBoxLayout(); row.addWidget(self.folder); row.addWidget(fb); form.addRow('Backups and new layers go to:', row)
        self.chk_style = QCheckBox('Wayleave symbology + erf parcel numbers'); self.chk_style.setChecked(True)
        self.chk_theme = QCheckBox('Network and Wayleave map themes'); self.chk_theme.setChecked(True)
        form.addRow(self.chk_style); form.addRow(self.chk_theme)
        v.addLayout(form)
        self.btn_gen = QPushButton('Generate finished wayleave'); self.btn_gen.setObjectName('wlPrimary'); self.btn_gen.clicked.connect(self.generate); v.addWidget(self.btn_gen)
        self.gen_out = QLabel(''); self.gen_out.setWordWrap(True); self.gen_out.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        v.addWidget(self.gen_out)
        row = QHBoxLayout()
        self.btn_keep = QPushButton('Keep (save all)'); self.btn_keep.clicked.connect(self.keep)
        self.btn_undo = QPushButton('Undo (put everything back)'); self.btn_undo.clicked.connect(self.undo)
        for b in (self.btn_keep, self.btn_undo):
            b.setEnabled(False); row.addWidget(b)
        v.addLayout(row)
        return w

    def _max_span(self):
        try:
            return float(self.span.value())
        except Exception:
            return 70.0

    def _default_folder(self):
        pf = QgsProject.instance().fileName()
        return os.path.join(os.path.dirname(pf), 'Wayleave backups') if pf else os.path.expanduser('~')

    def _pick_folder(self):
        d = QFileDialog.getExistingDirectory(self, 'Where should backups and new layers go?', self.folder.text())
        if d:
            self.folder.setText(d)

    def generate(self):
        if self.task is not None:
            return
        if self._project_refused():
            QMessageBox.warning(self, 'Wayleave', 'This looks like a shipped Fibertime project (Mohadin / Chloorkop / Potch). Generate is HeroTel-only and will not run here.')
            return
        self.found = io.find_layers(); self.refresh_status()
        busy = [lyr.name() for lyr in {id(x): x for x in self.found.values() if x is not None}.values() if lyr.isEditable() and lyr.isModified()]
        if busy:
            QMessageBox.warning(self, 'Wayleave', 'Save or roll back your edits first. Unsaved edits in:\n' + '\n'.join(busy))
            return
        try:
            inp = io.read_inputs(self.found)
        except io.WayleaveIOError as e:
            QMessageBox.warning(self, 'Wayleave', str(e)); return
        opts = dict(town=(self.town.text().strip().upper() or 'XXX'), max_span=self._max_span())
        errs = [i for i in wf.check(inp, opts) if i['level'] == 'error']
        if errs:
            QMessageBox.warning(self, 'Wayleave', f'{len(errs)} errors must be fixed first. Opening Step 2.')
            self.tabs.setCurrentIndex(1); self.run_check(); return
        folder = self.folder.text().strip() or self._default_folder()
        io.set_setting('town', opts['town']); io.set_setting('max_span', opts['max_span']); io.set_setting('backup_folder', folder)
        n_poles = self.found['poles'].featureCount() if self.found.get('poles') is not None else 0
        if n_poles and QMessageBox.question(self, 'Wayleave', f'The Poles layer already has {n_poles} poles. Generate replaces them (a backup is taken first). Continue?') != QMessageBox.StandardButton.Yes:
            return
        try:
            self.backup_dir = io.backup(self.found, folder, ['feeder', 'link', 'dc', 's16', 'pons', 'dps', 'poles', 'span'])
        except Exception as e:
            QMessageBox.warning(self, 'Wayleave', f'Backup failed, nothing was changed:\n{e}'); return
        self.btn_gen.setEnabled(False); self.gen_out.setText('Working… (QGIS stays usable)')

        def work(task):
            return wf.finish(inp, opts, progress=lambda pct, msg: task.setProgress(pct))

        def finished(exc, res):
            self.task = None
            if sip.isdeleted(self):
                return
            self.btn_gen.setEnabled(True)
            if exc or res is None:
                self.gen_out.setText(f'Generate stopped, nothing was changed: {exc}'); return
            # the layers must still be there and untouched since Generate read them
            alive = [lyr for lyr in self.found.values() if lyr is not None]
            if any(sip.isdeleted(lyr) or QgsProject.instance().mapLayer(lyr.id()) is None for lyr in alive):
                self.gen_out.setText('A layer was removed while Generate was working. Nothing was changed; press Generate again.'); return
            touched = [lyr.name() for lyr in alive if lyr.isEditable() and lyr.isModified()]
            if touched:
                self.gen_out.setText('You edited ' + ', '.join(touched) + ' while Generate was working. Nothing was changed; '
                                     'save or roll back, then Generate again.'); return
            self._apply(res, folder)
        self.task = QgsTask.fromFunction('Generate finished wayleave', work, on_finished=finished)
        QgsApplication.taskManager().addTask(self.task)

    def _apply(self, res, folder):
        self._created = []; self._themes_before = io.themes_snapshot()
        try:
            crs = self.found['feeder'].crs()
            for role in ('poles', 'span'):
                if self.found.get(role) is None:
                    self.found[role] = io.create_layer(role, crs, folder); self._created.append(self.found[role])
            done = io.apply(self.found, res)
            styled = io.apply_styles(self.found) if self.chk_style.isChecked() else []
            themes = io.make_themes(self.found) if self.chk_theme.isChecked() else []
            io.save_layer_picks(self.found); self.refresh_status()
        except Exception as e:
            traceback.print_exc()
            self._full_undo()
            self.gen_out.setText(f'Generate failed and everything was put back: {e}'); return
        s = res['summary']; self.result = res
        warn = [i for i in res['issues'] if i['level'] != 'info']
        self.gen_out.setText(
            f"<b>Done, not saved yet.</b> {s['poles']} poles ({s['poles_transport']} feeder/link), {s['spans']} spans "
            f"({s['span_km']} km), longest pole-to-pole {s['pole_to_pole_max']} m. {s['pons']} PONs walked; "
            f"{s['distribution']} distribution + {s['spurs']} spurs. {len(warn)} spots to look at (listed in Step 2, marked on the map).<br>"
            f"Styled: {len(styled)} layers. Themes: {', '.join(themes) or 'none'}.<br>"
            f"Backup: <i>{self.backup_dir}</i><br>Look it over, then press <b>Keep</b> or <b>Undo</b>.")
        self.btn_keep.setEnabled(True); self.btn_undo.setEnabled(True)
        # what Generate found (two poles side by side, ...) goes on the map and into the Step 2 list
        found_after = [i for i in res['issues'] if i['level'] != 'info']
        if found_after:
            self.issues = found_after; io.put_markers(self.found, self.issues); self._show_issues()
            self.verdict.setText(f"After Generate: {len(found_after)} spots to look at (marked on the map). They do not stop you saving.")
        self._done = done

    def keep(self):
        bad = io.keep(self.found)
        if bad:
            # the layers that saved stay saved; the rest are still in edit mode, so Undo still covers them
            QMessageBox.warning(self, 'Wayleave', 'Some layers did not save:\n' + '\n'.join(bad)
                                + f'\n\nThe others are saved. Your backup is in:\n{getattr(self, "backup_dir", "")}')
            return
        self.btn_keep.setEnabled(False); self.btn_undo.setEnabled(False)
        self._msg('Wayleave saved. Next: Step 4, Print.', Qgis.MessageLevel.Success)
        self.tabs.setCurrentIndex(3)

    def _full_undo(self):
        created = getattr(self, '_created', [])
        io.undo(self.found, getattr(self, 'backup_dir', None), created, getattr(self, '_themes_before', None))
        for role in ('poles', 'span'):
            if self.found.get(role) in created:
                self.found[role] = None
        self.refresh_status()

    def undo(self):
        if QMessageBox.question(self, 'Wayleave', 'Undo puts every layer, style and theme back as it was before Generate. '
                                'Any edit you made to these layers since then is also undone. Continue?') != QMessageBox.StandardButton.Yes:
            return
        self._full_undo()
        self.btn_keep.setEnabled(False); self.btn_undo.setEnabled(False)
        self.gen_out.setText('Undone: layers, styles and themes are back as they were. The backup folder is kept.')

    # ── step 4 ──
    def _tab_print(self):
        w = QWidget(); v = QVBoxLayout(w)
        guide = self._browser(GUIDE_PRINT); guide.setMaximumHeight(260); v.addWidget(guide)
        for text, fn, primary in (('Show the Wayleave theme', self.show_theme, False), ('Open the HLD Atlas PDF (wayleave)', self.open_atlas, True)):
            b = QPushButton(text); b.clicked.connect(fn); v.addWidget(b)
            if primary:
                b.setObjectName('wlPrimary')
        v.addStretch(1)
        return w

    def show_theme(self):
        proj = QgsProject.instance(); col = proj.mapThemeCollection()
        if not col.hasMapTheme('Wayleave'):
            self._msg('No Wayleave theme yet: run Step 3 first.', Qgis.MessageLevel.Warning); return
        col.applyTheme('Wayleave', proj.layerTreeRoot(), self.iface.layerTreeView().layerTreeModel())
        self.iface.mapCanvas().refresh()

    def open_atlas(self):
        try:
            try:
                from ..hld_pdf import presets
                from ..hld_pdf import open_hld_pdf_dialog
            except ImportError:
                from hld_pdf import presets, open_hld_pdf_dialog
            from qgis.core import QgsSettings
            k = presets._meta_key(QgsProject.instance().fileName() or '')
            s = QgsSettings(); s.setValue(f'{k}/model', 'wayleave'); s.setValue(f'{k}/client', 'herotel')
            open_hld_pdf_dialog(self.iface)
        except Exception as e:
            self._msg(f'Could not open the HLD Atlas PDF tool: {e}', Qgis.MessageLevel.Warning)


def show_wayleave_panel(iface, owner=None, step=0):
    """Open (or re-show) the Wayleave panel on a step (0-3). Returns the dock."""
    global _PANEL
    if _PANEL is None or sip.isdeleted(_PANEL):
        _PANEL = WayleavePanel(iface, owner)
        try:
            try:
                from ..fibre_automation import dock_util
            except ImportError:
                from fibre_automation import dock_util
            dock_util.dock_fully(iface, _PANEL, width=460)
        except Exception:
            iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, _PANEL)
    _PANEL.found = io.find_layers(); _PANEL.refresh_status()
    _PANEL.tabs.setCurrentIndex(max(0, min(3, int(step))))
    _PANEL.show(); _PANEL.raise_()
    return _PANEL
