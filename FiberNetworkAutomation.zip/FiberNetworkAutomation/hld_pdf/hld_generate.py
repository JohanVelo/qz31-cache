# -*- coding: utf-8 -*-
# ============================================================================
# HLD Generate  (Phase 3 — combined headless generator behind the Nexus button)
# ----------------------------------------------------------------------------
# ONE separate QGIS process (no canvas -> can never freeze the live session) that:
#   builds the two layouts -> saves an editable "*_HLD.qgz" copy (+ .qpt template)
#   -> exports overview + atlas -> merges to ONE verified PDF -> optional email copy.
#
# Runs via: <QGIS>/bin/python-qgis.bat hld_generate.py <config.json>
# All machine-specific paths come from the config (the plugin fills them in), so
# this is portable across teammates' installs.
#
# Config JSON:
#   {
#     "project":        "C:/.../working.qgz",          # source (read-only)
#     "output":         "C:/.../<name> HLD.pdf",        # the deliverable PDF
#     "output_project": "C:/.../<name> HLD.qgz",        # editable copy (optional)
#     "qpt_out":        "C:/.../hld_frame.qpt",         # frame template (optional)
#     "hld_cfg":        { ... engine overrides ... },
#     "extra_layers":   [ {"path","name","fill"} ],     # e.g. greenfield boundary
#     "dpi": 150, "compress": true,
#     "qgis_prefix": "...", "gs": "...", "engine": "...",  # filled by the plugin
#     "result":         "C:/.../result.json"
#   }
# result.json: {ok, stage, message, pages, output, email, output_project, size_mb, log}
#
# Contract: callers trust result.json's `ok` flag. (Exit code is clean too, but the
# flag is the signal — headless QGIS teardown is unreliable, so we os._exit.)
# ============================================================================
import os
import sys
import json
import shutil
import datetime
import subprocess
import traceback

_HERE = os.path.dirname(os.path.abspath(__file__))
_APP = None   # keep QgsApplication alive past return; its destructor segfaults headless
FONTS = ("arial.ttf", "arialbd.ttf", "ariali.ttf", "arialbi.ttf")
MIN_FREE_MB = 500
MIN_PDF_MB = 0.3

LOG = []
def log(msg):
    LOG.append(str(msg)); print(msg, flush=True)


def _write_result(path, obj):
    obj.setdefault("log", LOG)
    if not path:
        return
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, indent=2)
    except Exception as e:
        log(f"could not write result.json: {e}")


def fail(result_path, stage, message):
    _write_result(result_path, {"ok": False, "stage": stage, "message": message})
    log(f"FAIL [{stage}]: {message}")
    return 1


def _count_pdf_pages(pdf_path, gs):
    """Robust page count: Ghostscript pdfpagecount (compression-proof), regex fallback."""
    if gs and os.path.exists(gs):
        try:
            ps = pdf_path.replace("\\", "/")
            r = subprocess.run([gs, "-q", "-dNODISPLAY", "-dNOSAFER", "-c",
                                f"({ps}) (r) file runpdfbegin pdfpagecount = quit"],
                               capture_output=True, text=True, timeout=60)
            for line in (r.stdout or "").splitlines():
                if line.strip().isdigit():
                    return int(line.strip())
        except Exception:
            pass
    try:
        with open(pdf_path, "rb") as f:
            data = f.read()
    except Exception:
        return -1
    import re
    counts = [int(m) for m in re.findall(rb"/Type\s*/Pages\b[^>]*?/Count\s+(\d+)", data)]
    if not counts:
        counts = [int(m) for m in re.findall(rb"/Count\s+(\d+)[^>]*?/Type\s*/Pages\b", data)]
    if counts:
        return max(counts)
    return len(re.findall(rb"/Type\s*/Page(?![s])", data))


def _gs_run(gs, args, label):
    if not gs or not os.path.exists(gs):
        raise RuntimeError(f"Ghostscript not found: {gs}")
    r = subprocess.run([gs] + args, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"Ghostscript {label} failed: {r.stderr[-400:]}")


def _backup(path, suffix):
    if not os.path.exists(path):
        return
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    bak = f"{os.path.splitext(path)[0]}.{stamp}.bak{suffix}"
    try:
        shutil.copy2(path, bak); log(f"backup: {bak}")
    except Exception as e:
        log(f"backup failed (continuing): {e}")


def main():
    if len(sys.argv) < 2:
        print("usage: hld_generate.py <config.json>", flush=True); return 2
    with open(sys.argv[1], encoding="utf-8") as f:
        cfg = json.load(f)

    project = cfg["project"]
    output = cfg["output"]
    output_project = cfg.get("output_project")
    hld_cfg = cfg.get("hld_cfg", {}) or {}
    extra_layers = cfg.get("extra_layers", []) or []
    dpi = int(cfg.get("dpi", 150))
    do_compress = bool(cfg.get("compress", False))
    result_path = cfg.get("result") or (os.path.splitext(output)[0] + ".result.json")
    tmp = cfg.get("tmp") or os.path.join(os.path.dirname(output) or ".", "_hld_tmp")
    os.makedirs(tmp, exist_ok=True)

    engine = cfg.get("engine") or os.path.join(_HERE, "hld_atlas_engine.py")
    qgis_prefix = cfg.get("qgis_prefix") or r"C:/Program Files/QGIS 4.0.3/apps/qgis"
    gs = cfg.get("gs") or r"C:/Program Files/QGIS 4.0.3/bin/gswin64c.exe"

    # ---- pre-flight (cheap) ----
    if not os.path.exists(project):
        return fail(result_path, "preflight", f"project not found: {project}")
    if not os.path.exists(engine):
        return fail(result_path, "preflight", f"engine not found: {engine}")
    if output_project and os.path.abspath(output_project) == os.path.abspath(project):
        return fail(result_path, "preflight", "output_project must differ from the source project")
    out_dir = os.path.dirname(output) or "."
    os.makedirs(out_dir, exist_ok=True)
    try:
        free_mb = shutil.disk_usage(out_dir).free / (1024 * 1024)
        if free_mb < MIN_FREE_MB:
            return fail(result_path, "preflight", f"low disk: {free_mb:.0f} MB free (< {MIN_FREE_MB})")
        log(f"disk free: {free_mb:.0f} MB")
    except Exception as e:
        log(f"disk check skipped: {e}")

    # ---- boot QGIS headless ----
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from qgis.core import (QgsApplication, QgsProject, QgsLayoutExporter,
                           QgsVectorLayer, QgsFillSymbol)
    from qgis.PyQt.QtGui import QFontDatabase

    global _APP
    QgsApplication.setPrefixPath(qgis_prefix, True)
    app = QgsApplication([], False)
    app.initQgis()
    _APP = app
    try:
        ids = [QFontDatabase.addApplicationFont(rf"C:/Windows/Fonts/{fn}") for fn in FONTS]
        if all(i < 0 for i in ids):
            log("WARNING: no Arial fonts registered -> text may be boxes")

        proj = QgsProject.instance()
        if not proj.read(project):
            return fail(result_path, "read", f"could not read project: {project}")
        log(f"project read: {len(proj.mapLayers())} layers")

        for el in extra_layers:
            vl = QgsVectorLayer(el["path"], el.get("name", os.path.basename(el["path"])), "ogr")
            if vl.isValid():
                if el.get("fill"):
                    try: vl.renderer().setSymbol(QgsFillSymbol.createSimple(el["fill"]))
                    except Exception as e: log(f"extra-layer style skipped: {e}")
                proj.addMapLayer(vl, el.get("add_to_tree", True))
                log(f"extra layer: {el.get('name')} ({vl.featureCount()})")
            else:
                log(f"WARNING: extra layer invalid: {el['path']}")

        # ---- build layouts via the engine ----
        ns = {"HLD_CFG": hld_cfg}
        try:
            with open(engine, encoding="utf-8") as f:
                exec(compile(f.read(), engine, "exec"), ns)
        except Exception as e:
            return fail(result_path, "build", f"engine raised: {e}\n{traceback.format_exc()[-800:]}")

        eff = ns.get("CFG", {})
        lm = proj.layoutManager()
        at_name = eff.get("layout_atlas", "MOA PH2 HLD Atlas")
        rep_name = eff.get("layout_report", "MOA PH2 HLD Book")
        atlas = lm.layoutByName(at_name)
        rep = lm.layoutByName(rep_name)
        atlas_ok = atlas is not None and getattr(atlas, "atlas", None) and atlas.atlas().enabled()
        if not atlas_ok and rep is None:
            return fail(result_path, "build", "no atlas/report produced by the engine")

        _role = ns.get("_role")
        cov = _role("coverage") if callable(_role) else None
        n_feat = cov.featureCount() if cov else 0
        if not cov or n_feat < 1:
            return fail(result_path, "preflight", f"coverage layer empty/unresolved (features={n_feat})")
        log(f"coverage: {cov.name()} ({n_feat} features)")

        # ---- save editable *_HLD.qgz copy (the layouts live in the project) ----
        if output_project:
            os.makedirs(os.path.dirname(output_project) or ".", exist_ok=True)
            _backup(output_project, ".qgz")
            if proj.write(output_project):
                log(f"editable project saved: {output_project}")
            else:
                log(f"WARNING: could not save editable project: {output_project}")
                output_project = None

        # ---- export to ONE PDF (overview page 1 + one page per feature) ----
        S = QgsLayoutExporter.PdfExportSettings(); S.dpi = dpi
        staged = os.path.join(tmp, "_book.pdf")
        if atlas_ok:
            r = QgsLayoutExporter(atlas).exportToPdf(atlas.atlas(), staged, S)   # unified atlas
            what = "atlas"
        else:
            r = QgsLayoutExporter.exportToPdf(rep, staged, S)                    # report
            what = "report"
        if int(r[0] if isinstance(r, tuple) else r) != 0:
            return fail(result_path, "export", f"{what} export failed (code {r})")
        log(f"exported {what} (overview + detail)")

    except Exception as e:
        return fail(result_path, "render", f"unexpected: {e}\n{traceback.format_exc()[-800:]}")
    # NOTE: no app.exitQgis() — segfaults headless; os._exit() handles teardown.

    # ---- verify -> swap ----
    pages = _count_pdf_pages(staged, gs)
    expected = 1 + n_feat
    if pages != expected:
        return fail(result_path, "verify", f"page count {pages} != expected {expected}")
    size_mb = os.path.getsize(staged) / (1024 * 1024)
    if size_mb < MIN_PDF_MB:
        return fail(result_path, "verify", f"output too small: {size_mb:.2f} MB")
    log(f"verify OK: {pages} pages, {size_mb:.1f} MB")

    if os.path.exists(output):
        try: shutil.copy2(output, output + ".bak")
        except Exception as e: log(f"prev-PDF backup skipped: {e}")
    os.replace(staged, output)
    log(f"written: {output}")

    email_path = None
    if do_compress:
        email_path = os.path.splitext(output)[0] + " (email).pdf"
        staged_email = os.path.join(tmp, "_email.pdf")
        try:
            _gs_run(gs, ["-dBATCH", "-dNOPAUSE", "-q", "-sDEVICE=pdfwrite",
                         "-dCompatibilityLevel=1.5", "-dPDFSETTINGS=/ebook",
                         "-dDownsampleColorImages=true", "-dColorImageResolution=90",
                         "-dDownsampleGrayImages=true", "-dGrayImageResolution=90",
                         f"-sOutputFile={staged_email}", output], "compress")
            os.replace(staged_email, email_path)
            log(f"email copy: {email_path} ({os.path.getsize(email_path)/(1024*1024):.1f} MB)")
        except Exception as e:
            log(f"compress skipped: {e}"); email_path = None

    _write_result(result_path, {"ok": True, "stage": "done", "message": "HLD PDF generated",
                                "pages": pages, "output": output, "email": email_path,
                                "output_project": output_project, "size_mb": round(size_mb, 1)})
    log("HLD GENERATE OK")
    return 0


if __name__ == "__main__":
    rc = 1
    try:
        rc = main()
    except Exception as e:
        print("FATAL:", e, flush=True); traceback.print_exc()
    sys.stdout.flush(); sys.stderr.flush()
    os._exit(rc)   # skip QGIS teardown segfault; result.json already written
