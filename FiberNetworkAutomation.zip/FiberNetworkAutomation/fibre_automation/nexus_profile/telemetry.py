"""telemetry — presence heartbeat, event capture, breadcrumbs, error reports.

One singleton per plugin. QTimer-driven (main thread), all network via the
dry-run-aware Backend (fire-and-forget). Wrap the action factory + error guard
ONCE to capture every tool without per-tool edits.
"""
import time

from . import config, identity


class Telemetry:
    def __init__(self, iface, backend, profile, data_dir,
                 qgis_version="", plugin_version=""):
        self.iface = iface
        self.backend = backend
        self.profile = profile
        self.data_dir = data_dir
        self.qgis_version = qgis_version
        self.plugin_version = plugin_version
        self.install_id = None
        self.session_id = identity.new_session_id()
        self.crumbs = identity.Breadcrumbs(config.BREADCRUMB_MAX)
        self._queue = []
        self._last_error_ts = 0.0
        self._hb_timer = None
        self._flush_timer = None
        self._active_tool = None

    # ── lifecycle ───────────────────────────────────────────────────────────
    def start(self):
        from .profile import Profile
        self.install_id = Profile.install_id()
        # open a session row
        self.backend.insert("sessions", {
            "session_id": self.session_id,
            "install_id": self.install_id,
            "username": self.profile.username,
            "qgis_version": self.qgis_version,
            "plugin_version": self.plugin_version,
            "project_name": self._project_name(),
        })
        self._heartbeat()
        try:
            from qgis.PyQt.QtCore import QTimer
            self._hb_timer = QTimer(self.iface.mainWindow())
            self._hb_timer.timeout.connect(self._heartbeat)
            self._hb_timer.start(config.HEARTBEAT_MS)
            self._flush_timer = QTimer(self.iface.mainWindow())
            self._flush_timer.timeout.connect(self._flush)
            self._flush_timer.start(config.EVENT_FLUSH_MS)
        except Exception:
            pass

    def stop(self):
        for t in (self._hb_timer, self._flush_timer):
            try:
                if t is not None:
                    t.stop()
                    t.deleteLater()
            except Exception:
                pass
        self._hb_timer = self._flush_timer = None
        self._flush()
        # best-effort offline mark
        try:
            self.backend.insert("heartbeats", {
                "install_id": self.install_id,
                "username": self.profile.username,
                "last_updated": "1970-01-01T00:00:00Z",
            }, upsert_on="install_id")
        except Exception:
            pass

    # ── capture (called from the choke-point wrappers) ──────────────────────
    def record_action(self, action_id, category="tool", message=""):
        self._active_tool = action_id
        self.crumbs.add(action_id, category, message, self.plugin_version)
        self._queue.append({
            "session_id": self.session_id,
            "install_id": self.install_id,
            "username": self.profile.username,
            "plugin_version": self.plugin_version,
            "action_id": action_id,
            "category": category,
            "project_name": self._project_name(),
        })
        if len(self._queue) >= config.EVENT_FLUSH_COUNT:
            self._flush()

    def record_error(self, where, exc, user_note=None):
        """Auto-capture AND Report-a-Problem land here. Rate-limited."""
        now = time.time()
        if now - self._last_error_ts < config.ERROR_MIN_INTERVAL_S and not user_note:
            return                      # crash-loop guard (user reports always go)
        self._last_error_ts = now
        import traceback
        tb = "".join(traceback.format_exception(type(exc), exc,
                                                exc.__traceback__))
        self.backend.insert("errors", {
            "session_id": self.session_id,
            "install_id": self.install_id,
            "username": self.profile.username,
            "plugin_version": self.plugin_version,
            "qgis_version": self.qgis_version,
            "project_name": self._project_name(),
            "action": str(where),
            "error_message": f"{type(exc).__name__}: {exc}",
            "error_traceback": tb[-4000:],
            "active_tool": self._active_tool,
            "breadcrumbs": self.crumbs.tail(20),
            "user_note": user_note,
        })

    # ── internals ───────────────────────────────────────────────────────────
    def _heartbeat(self):
        from datetime import datetime, timezone
        self.backend.insert("heartbeats", {
            "install_id": self.install_id,
            "username": self.profile.username,
            "project_name": self._project_name(),
            "active_tool": self._active_tool,
            "qgis_version": self.qgis_version,
            "plugin_version": self.plugin_version,
            "last_updated": datetime.now(timezone.utc).isoformat(),
        }, upsert_on="install_id")

    def _flush(self):
        q, self._queue = self._queue, []
        for ev in q:
            self.backend.insert("events", ev)
        self.backend.flush()

    def _project_name(self):
        try:
            from qgis.core import QgsProject
            return QgsProject.instance().baseName() or None
        except Exception:
            return None


def make_action_wrapper(telemetry):
    """Returns a decorator that records an event before running a callback —
    wrap the plugin's mk() callbacks once at the choke point."""
    def wrap(action_id, fn, category="tool"):
        def inner(*a, **k):
            try:
                if telemetry is not None:
                    telemetry.record_action(action_id, category)
            except Exception:
                pass
            return fn()
        return inner
    return wrap
