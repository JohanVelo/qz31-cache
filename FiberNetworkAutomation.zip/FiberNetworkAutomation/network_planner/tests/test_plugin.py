"""Unit tests for FTTH Plan Tool."""

import unittest
import os
import sys

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core import NetworkGraph, build_network_from_files


class TestNetworkGraph(unittest.TestCase):
    """Test cases for NetworkGraph class."""
    
    def test_empty_graph(self):
        """Test creation of empty graph."""
        network = NetworkGraph()
        self.assertEqual(network.G.number_of_nodes(), 0)
        self.assertEqual(network.G.number_of_edges(), 0)
    
    def test_add_node(self):
        """Test adding a single node."""
        network = NetworkGraph()
        network.G.add_node('test_node', coord=(0, 0))
        self.assertEqual(network.G.number_of_nodes(), 1)
        self.assertIn('test_node', network.G.nodes())
    
    def test_ensure_node(self):
        """Test _ensure_node creates or finds nodes."""
        network = NetworkGraph()
        coord = (1.0, 2.0)
        
        # First call should create node
        node_id_1 = network._ensure_node(coord)
        self.assertEqual(network.G.number_of_nodes(), 1)
        
        # Second call with same coord should return same node
        node_id_2 = network._ensure_node(coord)
        self.assertEqual(node_id_1, node_id_2)
        self.assertEqual(network.G.number_of_nodes(), 1)
    
    def test_nearest_node(self):
        """Test finding nearest node."""
        network = NetworkGraph()
        network.G.add_node('n1', coord=(0, 0))
        network.G.add_node('n2', coord=(1, 1))
        network.G.add_node('n3', coord=(2, 2))
        
        # Find nearest to origin
        nearest = network.nearest_node((0.1, 0.1))
        self.assertEqual(nearest, 'n1')
        
        # Find nearest to (2, 2)
        nearest = network.nearest_node((2.1, 2.1))
        self.assertEqual(nearest, 'n3')
    
    def test_shortest_path(self):
        """Test shortest path calculation."""
        network = NetworkGraph()
        
        # Create simple linear network
        network.G.add_node('A', coord=(0, 0))
        network.G.add_node('B', coord=(1, 0))
        network.G.add_node('C', coord=(2, 0))
        
        network.G.add_edge('A', 'B', weight=1)
        network.G.add_edge('B', 'C', weight=1)
        
        # Calculate path
        path = network.shortest_path((0, 0), (2, 0))
        self.assertEqual(len(path), 3)
        self.assertEqual(path[0], (0, 0))
        self.assertEqual(path[-1], (2, 0))
    
    def test_graph_info(self):
        """Test get_graph_info method."""
        network = NetworkGraph()
        network.G.add_node('A', coord=(0, 0))
        network.G.add_node('B', coord=(1, 0))
        network.G.add_edge('A', 'B', weight=1)
        
        info = network.get_graph_info()
        self.assertEqual(info['nodes'], 2)
        self.assertEqual(info['edges'], 1)
        self.assertTrue(info['connected'])


class TestSampleData(unittest.TestCase):
    """Test cases using sample data files."""
    
    @classmethod
    def setUpClass(cls):
        """Set up test fixtures."""
        _data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'sample_data')
        cls.nodes_file = os.path.join(_data_dir, 'nodes.geojson')
        cls.ducts_file = os.path.join(_data_dir, 'ducts.geojson')
        
        # Check if sample data exists
        if not os.path.exists(cls.nodes_file):
            raise unittest.SkipTest("Sample nodes.geojson not found")
        if not os.path.exists(cls.ducts_file):
            raise unittest.SkipTest("Sample ducts.geojson not found")
    
    def test_load_from_files(self):
        """Test loading network from GeoJSON files."""
        network = build_network_from_files(self.nodes_file, self.ducts_file)
        
        # Should have loaded nodes and edges
        self.assertGreater(network.G.number_of_nodes(), 0)
        self.assertGreater(network.G.number_of_edges(), 0)
    
    def test_route_calculation(self):
        """Test route calculation with sample data."""
        network = build_network_from_files(self.nodes_file, self.ducts_file)
        
        # Use coordinates from sample data
        source = (-0.1, 51.5)
        target = (-0.12, 51.51)
        
        path = network.shortest_path(source, target)
        
        # Path should have at least 2 points
        self.assertGreaterEqual(len(path), 2)
        
        # First and last points should be near source and target
        self.assertAlmostEqual(path[0][0], source[0], places=2)
        self.assertAlmostEqual(path[0][1], source[1], places=2)
        self.assertAlmostEqual(path[-1][0], target[0], places=2)
        self.assertAlmostEqual(path[-1][1], target[1], places=2)


if __name__ == '__main__':
    unittest.main()
