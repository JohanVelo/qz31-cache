import sys, os
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')

# ============================================================
# STS SPLITTERS V1 — FULL ATTRIBUTE POPULATION
# Project: Potch - Mohadin PH2
# Reference: STS splitters sheet from poles_potch_csv.xlsx
# Static fields populated + spatial joins for pon_no, zone_no
# lat/lon from feature geometry centroid
# ============================================================

STS_LAYER = 'STS Splitters v1'
PON_LAYER = 'PON v1'
ZONE_LAYER = 'Zones v1'

STATIC = {
    'type': 'Splitter',
    'subtyp': 'Splitter (Connectorised)',
    'spec': 'SM/G657A1',
    'dim1': 'L60*W7*H4mm',
    'dim2': '1m',
    'cblcpty': '1:8F',
    'conntr': 'LC/APC',
    'cmpownr': 'VelocityFibre',
    'subplace': '676007',
    'mainplce': '676007',
    'mun': 'JB Marks Local Municipality',
    'stackref': 'MOA',
    'crtdby': 'Johan Scholtz',
}

# --- GET LAYERS ---
sts_layer = None
pon_layer = None
zone_layer = None

for lyr in QgsProject.instance().mapLayers().values():
    n = lyr.name()
    if n == STS_LAYER: sts_layer = lyr
    if n == PON_LAYER: pon_layer = lyr
    if n == ZONE_LAYER: zone_layer = lyr

missing = []
if not sts_layer: missing.append(STS_LAYER)
if not pon_layer: missing.append(PON_LAYER)
if not zone_layer: missing.append(ZONE_LAYER)

if missing:
    print(f"ERROR: Missing layers: {missing}")
else:
    print(f"STS layer:  {STS_LAYER} ({sts_layer.featureCount()} features)")
    print(f"PON layer:  {PON_LAYER} ({pon_layer.featureCount()} features)")
    print(f"Zone layer: {ZONE_LAYER} ({zone_layer.featureCount()} features)")

    from qgis.core import QgsSpatialIndex

    # --- BUILD SPATIAL INDEXES ---
    pon_index = QgsSpatialIndex(pon_layer.getFeatures())
    pon_feats = {f.id(): f for f in pon_layer.getFeatures()}
    zone_index = QgsSpatialIndex(zone_layer.getFeatures())
    zone_feats = {f.id(): f for f in zone_layer.getFeatures()}

    def fidx(name):
        return sts_layer.fields().indexOf(name)

    sts_layer.startEditing()

    processed = 0
    pon_matched = 0
    pon_unmatched = 0
    zone_matched = 0
    zone_unmatched = 0
    sample = []

    for feat in sts_layer.getFeatures():
        geom = feat.geometry()

        if geom is None or geom.isNull():
            continue

        # --- STATIC FIELDS ---
        for field, val in STATIC.items():
            idx = fidx(field)
            if idx != -1:
                sts_layer.changeAttributeValue(feat.id(), idx, val)

        # --- LAT / LON ---
        pt = geom.asPoint()
        lat_idx = fidx('lat')
        lon_idx = fidx('lon')
        if lat_idx != -1:
            sts_layer.changeAttributeValue(feat.id(), lat_idx, str(round(pt.y(), 10)))
        if lon_idx != -1:
            sts_layer.changeAttributeValue(feat.id(), lon_idx, str(round(pt.x(), 10)))

        # --- PON_NO ---
        pon_no = None
        candidates = pon_index.intersects(geom.boundingBox())
        for fid in candidates:
            if pon_feats[fid].geometry().contains(geom):
                pon_no = pon_feats[fid]['pon_no']
                break
        pon_idx = fidx('pon_no')
        if pon_idx != -1 and pon_no is not None:
            sts_layer.changeAttributeValue(feat.id(), pon_idx, pon_no)
            pon_matched += 1
        else:
            pon_unmatched += 1

        # --- ZONE_NO ---
        zone_no = None
        candidates = zone_index.intersects(geom.boundingBox())
        for fid in candidates:
            if zone_feats[fid].geometry().intersects(geom):
                zone_no = zone_feats[fid]['zone_no']
                break
        zone_idx = fidx('zone_no')
        if zone_idx != -1 and zone_no is not None:
            sts_layer.changeAttributeValue(feat.id(), zone_idx, zone_no)
            zone_matched += 1
        else:
            zone_unmatched += 1

        processed += 1
        if len(sample) < 5:
            sample.append(f"  {feat['label']} | pon={pon_no} | zone={zone_no}")

    sts_layer.commitChanges()

    # --- SUMMARY ---
    print("=" * 55)
    print(f"  STS SPLITTERS V1 POPULATION COMPLETE")
    print(f"  Total processed: {processed}")
    print(f"  pon_no matched:  {pon_matched} | unmatched: {pon_unmatched}")
    print(f"  zone_no matched: {zone_matched} | unmatched: {zone_unmatched}")
    print("=" * 55)
    print("\nSample — first 5 STS:")
    for s in sample:
        print(s)

    # --- CHECK FOR PONS WITH MORE THAN 16 STS ---
    print("\n--- PONs with MORE than 16 STS ---")
    from collections import Counter
    counts = Counter([f['pon_no'] for f in sts_layer.getFeatures() if f['pon_no']])
    over = [(p, c) for p, c in sorted(counts.items()) if c > 16]
    if over:
        for p, c in over:
            print(f"  PON {p}: {c} STS  *** EXCEEDS 16 ***")
    else:
        print("  None — all PONs within 16 STS limit ✅")

    print("\n--- All STS counts per PON ---")
    for p, c in sorted(counts.items()):
        flag = " ***" if c > 16 else ""
        print(f"  PON {p}: {c} STS{flag}")
