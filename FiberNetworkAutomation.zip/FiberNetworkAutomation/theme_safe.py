# -*- coding: utf-8 -*-
# ============================================================================
# theme_safe — text colours that are ALWAYS readable, in any QGIS theme
# ----------------------------------------------------------------------------
# The bug this prevents: hard-coding a text colour (e.g. "color:#222") that
# assumes a light background. On a dark / custom theme it becomes unreadable.
#
# Instead, derive every text colour from the LIVE palette and guarantee a WCAG
# contrast ratio against the actual window background — so descriptions, labels
# and buttons stay legible in light mode, dark mode, or any coloured theme.
#
# Usage:
#     from . import theme_safe
#     c = theme_safe.colors(self)          # dict for the widget's current theme
#     label.setStyleSheet(f"color:{c['muted']};")
#   or, simplest of all, DON'T set a colour and let the palette drive it.
#
#     theme_safe.style_label(label, role="muted")   # convenience
# ============================================================================
from qgis.PyQt.QtGui import QColor

try:
    from qgis.PyQt.QtGui import QPalette
    _WINDOW = QPalette.ColorRole.Window
    _WINDOWTEXT = QPalette.ColorRole.WindowText
except AttributeError:                       # Qt5 fallback
    from qgis.PyQt.QtGui import QPalette
    _WINDOW = QPalette.Window
    _WINDOWTEXT = QPalette.WindowText


def _lin(x):
    x /= 255.0
    return x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4


def _luminance(c):
    return 0.2126 * _lin(c.red()) + 0.7152 * _lin(c.green()) + 0.0722 * _lin(c.blue())


def contrast_ratio(a, b):
    la, lb = _luminance(a), _luminance(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


def ensure_contrast(fg, bg, target=4.5):
    """Nudge fg's lightness (toward white on a dark bg, toward black on a light bg)
    until it meets the target contrast ratio against bg. Returns a QColor."""
    fg = QColor(fg); bg = QColor(bg)
    if contrast_ratio(fg, bg) >= target:
        return fg
    bg_is_dark = _luminance(bg) < 0.5
    c = QColor(fg)
    for _ in range(60):
        h, s, lightness, a = c.getHslF()
        lightness = min(1.0, lightness + 0.03) if bg_is_dark else max(0.0, lightness - 0.03)
        c.setHslF(h, max(0.0, min(1.0, s)), lightness, a)
        if contrast_ratio(c, bg) >= target:
            return c
    # couldn't reach target within range → fall back to pure white/black
    return QColor("#ffffff") if bg_is_dark else QColor("#000000")


def _palette(widget=None):
    if widget is not None:
        try:
            return widget.palette()
        except Exception:
            pass
    from qgis.PyQt.QtWidgets import QApplication
    return QApplication.palette()


def colors(widget=None):
    """Readable text colours for the widget's CURRENT theme. All contrast-checked
    against the real window background, so they work in light/dark/custom themes.
    Returns hex strings: ink (body), muted (secondary), accent, warn, ok, bad, bg."""
    pal = _palette(widget)
    bg = pal.color(_WINDOW)
    ink = ensure_contrast(pal.color(_WINDOWTEXT), bg, 4.5)
    # muted = halfway between ink and bg, but still ≥ 3:1 so it stays legible
    muted = ensure_contrast(QColor((ink.red() + bg.red()) // 2,
                                   (ink.green() + bg.green()) // 2,
                                   (ink.blue() + bg.blue()) // 2), bg, 3.0)
    return {
        "bg": bg.name(),
        "ink": ink.name(),
        "muted": muted.name(),
        "accent": ensure_contrast(QColor("#1f9ec4"), bg, 4.5).name(),   # teal
        "warn": ensure_contrast(QColor("#e0a020"), bg, 3.5).name(),     # amber
        "ok": ensure_contrast(QColor("#2ea043"), bg, 3.5).name(),       # green
        "bad": ensure_contrast(QColor("#e5534b"), bg, 3.5).name(),      # red
    }


def style_label(label, role="ink", bold=False, size=None):
    """Apply a theme-safe colour to a QLabel by role (ink/muted/accent/warn/ok/bad)."""
    c = colors(label)
    css = f"color:{c.get(role, c['ink'])};"
    if bold:
        css += "font-weight:bold;"
    if size:
        css += f"font-size:{size}px;"
    label.setStyleSheet(css)
    return label
