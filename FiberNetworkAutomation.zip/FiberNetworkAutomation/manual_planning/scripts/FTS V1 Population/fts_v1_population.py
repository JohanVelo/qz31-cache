import sys, os
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')

# ============================================================
# FTS SPLITTERS V1 — FULL ATTRIBUTE POPULATION
# Project: Potch - Mohadin PH2
# Reference: FTS s sheet from poles_potch_csv.xlsx
# Label format: MOA.FTS.16.AGG.DM.P.[NearestPole]-OLT.01.[PONLabel]
# Example: MOA.FTS.16.AGG.DM.P.H249-OLT.01.C15P11
# ============================================================

FTS_LAYER = 'FTS Splitters v1'
POLES_LAYER = 'poles v1'
PON_LAYER = 'PON v1'
ZONE_LAYER = 'Zones v1'

SR = 'MOA'
OLT = 'OLT.01'

STATIC = {
    'type': 'Splitter',
    'subtyp': 'Splitter (Bare Fiber)',
    'spec': 'SM/G657A1',
    'dim1': 'L60*W7*H4mm',
    'dim2': '1m',
    'cblcpty': '1:16F',
    'cmpownr': 'VelocityFibre',
    'subplace': '676007',
    'mainplce': '676007',
    'mun': 'JB Marks Local Municipality',
    'stackref': 'MOA',
    'crtdby': 'Johan Scholtz',
}

# --- GET LAYERS ---
fts_layer = None
poles_layer = None
pon_layer = None
zone_layer = None

for lyr in QgsProject.instance().mapLayers().values():
    n = lyr.name()
    if n == FTS_LAYER: fts_layer = lyr
    if n == POLES_LAYER: poles_layer = lyr
    if n == PON_LAYER: pon_layer = lyr
    if n == ZONE_LAYER: zone_layer = lyr

missing = []
if not fts_layer: missing.append(FTS_LAYER)
if not poles_layer: missing.append(POLES_LAYER)
if not pon_layer: missing.append(PON_LAYER)
if not zone_layer: missing.append(ZONE_LAYER)

if missing:
    print(f"ERROR: Missing layers: {missing}")
else:
    print(f"FTS layer:   {FTS_LAYER} ({fts_layer.featureCount()} features)")
    print(f"Poles layer: {POLES_LAYER} ({poles_layer.featureCount()} features)")
    print(f"PON layer:   {PON_LAYER} ({pon_layer.featureCount()} features)")

    from qgis.core import QgsSpatialIndex

    # --- BUILD SPATIAL INDEXES ---
    pole_index = QgsSpatialIndex(poles_layer.getFeatures())
    pole_feats = {f.id(): f for f in poles_layer.getFeatures()}

    pon_index = QgsSpatialIndex(pon_layer.getFeatures())
    pon_feats = {f.id(): f for f in pon_layer.getFeatures()}

    zone_index = QgsSpatialIndex(zone_layer.getFeatures())
    zone_feats = {f.id(): f for f in zone_layer.getFeatures()}

    # --- PON lookup by pon_no ---
    pon_by_no = {f['pon_no']: f for f in pon_layer.getFeatures()}

    def nearest_pole_label(point):
        candidates = pole_index.nearestNeighbor(point, 1)
        if candidates:
            feat = pole_feats[candidates[0]]
            label = str(feat['Label'])
            if '.' in label:
                return label.split('.')[-1]  # e.g. H249
        return None

    def fidx(name):
        return fts_layer.fields().indexOf(name)

    fts_layer.startEditing()

    processed = 0
    no_geom = 0
    sample = []

    for feat in fts_layer.getFeatures():
        geom = feat.geometry()

        if geom is None or geom.isNull() or geom.isEmpty():
            no_geom += 1
            continue

        pt = geom.asPoint()

        # --- STATIC FIELDS ---
        for field, val in STATIC.items():
            idx = fidx(field)
            if idx != -1:
                fts_layer.changeAttributeValue(feat.id(), idx, val)

        # --- LAT / LON ---
        lat_idx = fidx('lat')
        lon_idx = fidx('lon')
        if lat_idx != -1:
            fts_layer.changeAttributeValue(feat.id(), lat_idx, str(round(pt.y(), 10)))
        if lon_idx != -1:
            fts_layer.changeAttributeValue(feat.id(), lon_idx, str(round(pt.x(), 10)))

        # --- NEAREST POLE ---
        from qgis.core import QgsPointXY
        pole_label = nearest_pole_label(QgsPointXY(pt.x(), pt.y()))

        # --- PON_NO from spatial join ---
        pon_no = None
        pon_label = None
        candidates = pon_index.intersects(geom.boundingBox())
        for fid in candidates:
            if pon_feats[fid].geometry().contains(geom):
                pon_no = pon_feats[fid]['pon_no']
                pon_label = pon_feats[fid]['label']
                break

        pon_idx = fidx('pon_no')
        if pon_idx != -1 and pon_no is not None:
            fts_layer.changeAttributeValue(feat.id(), pon_idx, pon_no)

        # --- ZONE_NO ---
        zone_no = None
        candidates = zone_index.intersects(geom.boundingBox())
        for fid in candidates:
            if zone_feats[fid].geometry().intersects(geom):
                zone_no = zone_feats[fid]['zone_no']
                break
        zone_idx = fidx('zone_no')
        if zone_idx != -1 and zone_no is not None:
            fts_layer.changeAttributeValue(feat.id(), zone_idx, zone_no)

        # --- BUILD LABEL ---
        # Format: MOA.FTS.16.AGG.DM.P.H249-OLT.01.C15P11
        if pole_label and pon_label:
            label = f'{SR}.FTS.16.AGG.DM.P.{pole_label}-{OLT}.{pon_label}'
        else:
            label = None

        label_idx = fidx('label')
        if label_idx != -1 and label:
            fts_layer.changeAttributeValue(feat.id(), label_idx, label)

        processed += 1
        if len(sample) < 5:
            sample.append(f"  {label} | pon={pon_no} | zone={zone_no}")

    fts_layer.commitChanges()

    # --- SUMMARY ---
    print("=" * 60)
    print("  FTS SPLITTERS V1 POPULATION COMPLETE")
    print(f"  Processed: {processed}")
    print(f"  Skipped (no geometry): {no_geom}")
    print("=" * 60)
    print("\nSample — first 5 FTS:")
    for s in sample:
        print(s)
