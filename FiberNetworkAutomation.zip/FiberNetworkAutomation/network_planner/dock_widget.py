"""Dock widget for FTTH Plan Tool."""

import os
from qgis.PyQt import sip
from qgis.core import Qgis  # Qt6: messageBar/log levels are Qgis.MessageLevel enums
import time
import colorsys

from qgis.PyQt import QtWidgets, uic
from qgis.PyQt.QtCore import pyqtSignal, QMetaType, Qt
try:
    from .. import theme_safe
except ImportError:
    pass   # standalone fallback
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtWidgets import QApplication
from qgis.core import (
    QgsVectorLayer, QgsWkbTypes, QgsProject, QgsGeometry, QgsPointXY,
    QgsFeature, QgsField, QgsUnitTypes, QgsSpatialIndex, QgsRectangle,
    QgsFillSymbol, QgsMarkerSymbol, QgsSingleSymbolRenderer,
    QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsLineSymbol,
    QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
    QgsVectorLayerSimpleLabeling, QgsCoordinateTransform,
    QgsDistanceArea,
)
from qgis.gui import QgsMapLayerComboBox, QgsMapToolEmitPoint, QgsMapTool, QgsRubberBand

from .layer_utils import (
    get_layer_features,
    get_point_coordinates,
    get_linestring_coordinates,
    create_memory_layer,
    add_fields_to_layer,
    add_line_feature,
    count_features_by_geometry_type
)
from .core import NetworkGraph, _snap_coord
# Aliased to vf_fields, NOT field_names: 'field_names' is already used as a local
# variable/parameter name 34 times in this file and importing it plainly would
# shadow the module at those call sites.
from . import field_names as vf_fields
# ONE definition of what a PON is called, shared with the merge tool's name
# resync. Seven places in this file used to write the literal f"Zone {n}"
# straight into a feature attribute — those are DATA, not labels, and a blind
# find/replace on the word "Zone" would have changed stored values silently.
from .pon_merge import pon_name_for as vf_pon_name
from .erf_grouping import (
    get_batch_statistics,
    find_optimal_splitter_locations,
    cluster_tight_groups_of_8,
    group_zones_from_groups,
    SKLEARN_AVAILABLE,
    NUMPY_AVAILABLE
)

# Cable profile functions (embedded until cable_profiles.py can be created)
import math
import bisect
import re


def _safe_ellipsoid(project, crs=None):
    """The ellipsoid to really use — never 'NONE'.

    QgsProject.ellipsoid() returns the STRING 'NONE' when a project has no
    ellipsoid set (QGIS's default for a new project). 'NONE' is truthy, so
    `project.ellipsoid() or "WGS84"` does NOT fall back — it sets "NONE", and a
    geographic CRS then measures in DEGREES: a 1976 m cable measures 0.019, so
    every span/drop/feeder length here would be wrong by ~100000x, silently.
    Found 2026-07-15. See fibre_automation/shared/crs_utils.safe_ellipsoid.
    """
    try:
        from ..fibre_automation.shared.crs_utils import safe_ellipsoid
        return safe_ellipsoid(project, crs)
    except Exception:
        pass
    try:
        from fibre_automation.shared.crs_utils import safe_ellipsoid
        return safe_ellipsoid(project, crs)
    except Exception:
        pass
    for get in (lambda: project.ellipsoid(),
                (lambda: crs.ellipsoidAcronym()) if crs is not None else None):
        if get is None:
            continue
        try:
            v = (get() or "").strip()
        except Exception:
            continue
        if v and v.upper() != "NONE":
            return v
    return "WGS84"




def snap_point_to_project(canvas, pt):
    """Snap a map-CRS QgsPointXY to the project's active QGIS snapping (the native
    'Enable Snapping' toggle + snapping toolbar settings). Returns the snapped point
    when there's a valid match, otherwise the original point unchanged.

    Shared by every Velocity Nexus map tool (place splitter / demand point, draw span,
    move splitter, create enclosure, …) so that turning on QGIS snapping makes ALL of
    them snap — not just one tool. Fail-safe: any error → original point.
    """
    try:
        from qgis.core import QgsPointXY
        _m = canvas.snappingUtils().snapToMap(pt)
        if _m.isValid():
            _p = _m.point()
            return QgsPointXY(_p.x(), _p.y())
    except Exception:
        pass
    return pt

# #79: a demand point's group-link field must be detected by PATTERN, never a
# hardcoded size list. Groups are created as f'group_{target_size}' (dock ~2895),
# so HeroTel projects use group_32 / group_64 etc. The drop generators used to
# look only for ['group_8','group_16','group_128','group_100','batch_id'] — so on
# any other splitter size NO demand point matched, group_id came back None, and
# every drop was skipped ("drops don't generate to their dedicated splitter on
# all the buttons"). 'group_id' is the SPLITTER's field and is excluded here.
# Zone->PON rename (2026-07-23): size-keyed splitter columns are created as
# spl_<N> going forward (group_<N> historically) — see field_names.py for why the
# short prefix is mandatory rather than splitter_<N>. This pattern matches BOTH
# generations so a project written by either version still resolves its drops.
_DROP_GRP_RE = vf_fields.SIZE_FIELD_RE

# Beta-access list (usernames, lowercased) — who may use work-in-progress PON Tools
# (Inspector now; Renumber once its engine lands). Keeps WIP off the wider team.
# Add a tester here to unlock for them; empty = locked for everyone.
PON_BETA_USERS = {"luke", "johan", "jaun"}


def _demand_group_field(field_names):
    """Return the demand group-link field (group_<N> for ANY size, or batch_id),
    or None. Mirrors the #75 cascade detector so every drop path agrees."""
    return next((n for n in field_names
                 if _DROP_GRP_RE.fullmatch(n) or n == 'batch_id'), None)


def _categorized_with_catch_all(layer, attr, categories, default_color=None):
    """Categorized renderer that ALWAYS carries an 'all other values' catch-all.

    Audit Batch A (same class as #77/#78): a QgsCategorizedSymbolRenderer paints
    NOTHING for a feature whose value matches no category, and an EMPTY category
    list blanks the whole layer. The null-valued category appended here is QGIS's
    'all other values' bucket, so unexpected / null values (and an empty list)
    still render instead of silently vanishing.
    """
    from qgis.PyQt.QtCore import QVariant
    from qgis.core import (QgsRendererCategory,
                           QgsSymbol)
    from qgis.PyQt.QtGui import QColor
    cats = list(categories)
    sym = QgsSymbol.defaultSymbol(layer.geometryType())
    try:
        sym.setColor(QColor(default_color) if default_color else QColor(150, 150, 150))
    except Exception:
        pass
    cats.append(QgsRendererCategory(QVariant(), sym, "Other", True))
    return QgsCategorizedSymbolRenderer(attr, cats)

def _m_to_units(meters, layer):
    """Convert a metre distance to the layer's CRS units.

    Batch B: on a GEOGRAPHIC CRS returns degrees (≈ meters / (111320·cos lat)); on a
    projected/metric CRS returns meters unchanged. Stops metre thresholds being
    compared against degree coordinates (a 5 m tolerance was ~550 km on EPSG:4326).
    """
    try:
        crs = layer.crs()
        if crs.isValid() and crs.isGeographic():
            import math as _mu
            lat = layer.extent().center().y()
            return meters / (111320.0 * max(0.1, _mu.cos(_mu.radians(lat))))
    except Exception:
        pass
    return meters


def _coord_round(x, y):
    """Snap a coordinate to a node-merge grid whose precision matches the CRS units.

    Batch B: a fixed round(_, 4) is ~11 m in DEGREES (merges genuinely distinct graph
    nodes) and ~0.1 mm in METRES (fails to merge coincident endpoints that differ by
    sub-mm float drift → the routing graph fragments → via-span routing silently falls
    back to straight lines). Infer the units from magnitude — geographic coordinates
    are bounded by ±180/±90, projected metric coordinates are far larger — and pick a
    precision giving a ~0.1 m merge grid either way.
    """
    if abs(x) <= 180.0 and abs(y) <= 90.0:
        return (round(x, 6), round(y, 6))   # degrees → ~0.1 m grid
    return (round(x, 1), round(y, 1))       # metres  → 0.1 m grid


CABLE_PROFILES = [2, 4, 6, 12, 24, 36, 48, 72, 96, 144, 288]
PROFILE_TYPE_DEFAULT = 'default'
PROFILE_TYPE_POPC = 'popc'
PROFILE_TYPE_OPERATOR = 'operator'

def get_cable_profile(demand, profile_type=PROFILE_TYPE_DEFAULT, reserve_percent=0.0):
    """Select smallest cable profile that accommodates demand."""
    if demand <= 0:
        return CABLE_PROFILES[0]
    if profile_type == PROFILE_TYPE_POPC:
        effective_demand = math.ceil(demand * 1.30)
    elif profile_type == PROFILE_TYPE_OPERATOR:
        return _get_operator_profile(demand)
    else:
        if reserve_percent > 0:
            effective_demand = math.ceil(demand * (1 + reserve_percent / 100))
        else:
            effective_demand = demand
    return _select_profile(effective_demand)

def _select_profile(demand):
    """Select smallest cable profile >= demand."""
    if demand <= 0:
        return CABLE_PROFILES[0]
    if demand in CABLE_PROFILES:
        return demand
    idx = bisect.bisect_right(CABLE_PROFILES, demand)
    if idx < len(CABLE_PROFILES):
        return CABLE_PROFILES[idx]
    else:
        return CABLE_PROFILES[-1]

def _get_operator_profile(demand):
    """Operator-specific cable thresholds."""
    if demand <= 9:
        return 12
    elif demand <= 20:
        return 24
    elif demand <= 40:
        return 48
    elif demand <= 60:
        return 72
    elif demand <= 80:
        return 96
    elif demand <= 120:
        return 144
    elif demand <= 180:
        return 216
    else:
        return 288

def format_cable_profile(profile):
    """Format cable profile as '48F', '144F', etc."""
    return f"{profile}F"


# ---------------------------------------------------------------------------
# Client profiles — network design parameters per operator
# ---------------------------------------------------------------------------
CLIENT_PROFILES = {
    "Herotel": {
        "max_pon_size": 128,
        "target_pon_size": 96,
        "splitter_ratio_feeder": "1:16",
        "splitter_ratio_dist": "1:8",
        "max_feeder_cable_fibres": 144,
        "feeder_pole_height_m": 7,
        "dist_pole_height_m": 6,
        "max_span_m": 70,
        "max_drop_length_m": 150,
        "description": "Herotel GPON — high-density, cascaded 1:16×1:8 split",
    },
    "Vuma": {
        "max_pon_size": 64,
        "target_pon_size": 48,
        "splitter_ratio_feeder": "1:32",
        "splitter_ratio_dist": "1:4",
        "max_feeder_cable_fibres": 96,
        "feeder_pole_height_m": 7,
        "dist_pole_height_m": 5,
        "max_span_m": 60,
        "max_drop_length_m": 100,
        "description": "Vuma FTTH — standard 1:32 split, 64-unit PON",
    },
    "Fibertime": {
        "max_pon_size": 96,
        "target_pon_size": 72,
        "splitter_ratio_feeder": "1:16",
        "splitter_ratio_dist": "1:4",
        "max_feeder_cable_fibres": 96,
        "feeder_pole_height_m": 7,
        "dist_pole_height_m": 5,
        "max_span_m": 70,
        "max_drop_length_m": 120,
        "description": "Fibertime GPON — balanced 1:16×1:4 split, 96-unit PON",
    },
}


FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'forms', 'dockwidget_base.ui'))


# ---------------------------------------------------------------------------
# Span-network routing helpers (used by Generate Drop Cables)
# ---------------------------------------------------------------------------

def _find_seg_index(pts, snap_pt):
    """Return (i, t) — index of sub-segment and fractional position along it
    where snap_pt is closest to the polyline defined by *pts*.
    """
    import math
    min_d = float('inf')
    best_i, best_t = 0, 0.0
    for i in range(len(pts) - 1):
        ax, ay = pts[i].x(), pts[i].y()
        bx, by = pts[i + 1].x(), pts[i + 1].y()
        dx, dy = bx - ax, by - ay
        seg_sq = dx * dx + dy * dy
        if seg_sq > 1e-20:
            t = max(0.0, min(1.0,
                ((snap_pt.x() - ax) * dx + (snap_pt.y() - ay) * dy) / seg_sq))
        else:
            t = 0.0
        cx, cy = ax + t * dx, ay + t * dy
        d = math.sqrt((snap_pt.x() - cx) ** 2 + (snap_pt.y() - cy) ** 2)
        if d < min_d:
            min_d, best_i, best_t = d, i, t
    return best_i, best_t


def _build_span_routing_graph(span_feats):
    """Build a NetworkX graph of the span network.

    Nodes  : _coord_round(x, y) tuples for segment endpoints — 6 d.p. for
             geographic CRS, 1 d.p. for projected metric CRS.
    Edges  : one per span feature, carrying *pts* (vertex list) and *weight* (length).
    Returns: (G, seg_ep) where seg_ep[fid] = (start_node, end_node, [QgsPointXY …]).
    """
    import networkx as nx
    from qgis.core import QgsPointXY

    G = nx.Graph()
    seg_ep = {}
    for fid, feat in span_feats.items():
        geom = feat.geometry()
        if not geom or geom.isEmpty():
            continue
        pts = [QgsPointXY(v.x(), v.y()) for v in geom.vertices()]
        if len(pts) < 2:
            continue
        n_s = _coord_round(pts[0].x(), pts[0].y())
        n_e = _coord_round(pts[-1].x(), pts[-1].y())
        length = geom.length()
        if not G.has_edge(n_s, n_e) or G[n_s][n_e]['weight'] > length:
            G.add_edge(n_s, n_e, weight=length, fid=fid, pts=pts)
        seg_ep[fid] = (n_s, n_e, pts)
    return G, seg_ep


def _span_route_pts(snap_a, fid_a, snap_b, fid_b, G, seg_ep):
    """Return [QgsPointXY, …] following the span network from *snap_a* to *snap_b*.

    The list includes *snap_a* and *snap_b*.  Returns *None* if no path exists.
    """
    import networkx as nx
    import math

    n_sa, n_ea, pts_a = seg_ep[fid_a]
    n_sb, n_eb, pts_b = seg_ep[fid_b]
    i_a, _ = _find_seg_index(pts_a, snap_a)
    i_b, _ = _find_seg_index(pts_b, snap_b)

    # ---- Same segment: extract the portion between the two snap points -----
    if fid_a == fid_b:
        # Determine which snap is earlier along the segment
        def _along(pts, idx):
            return sum(math.dist((pts[j].x(), pts[j].y()),
                                 (pts[j + 1].x(), pts[j + 1].y()))
                       for j in range(idx))
        if _along(pts_a, i_a) <= _along(pts_a, i_b):
            return [snap_a] + pts_a[i_a + 1:i_b + 1] + [snap_b]
        else:
            return [snap_a] + list(reversed(pts_a[i_b + 1:i_a + 1])) + [snap_b]

    # ---- Different segments: route via endpoint graph ----------------------
    best_path, best_cost = None, float('inf')
    for da in [n_sa, n_ea]:
        for db in [n_sb, n_eb]:
            try:
                plen = nx.shortest_path_length(G, da, db, weight='weight')
                pnodes = nx.shortest_path(G, da, db, weight='weight')
            except Exception:
                continue
            cost = (plen
                    + math.dist(da, (snap_a.x(), snap_a.y()))
                    + math.dist(db, (snap_b.x(), snap_b.y())))
            if cost < best_cost:
                best_cost, best_path = cost, (pnodes, da, db)

    if best_path is None:
        return None

    pnodes, da, db = best_path
    result = [snap_a]

    # Part 1: snap_a → da along segment A
    if da == n_ea:
        result.extend(pts_a[i_a + 1:])               # forward to end
    else:
        result.extend(reversed(pts_a[:i_a + 1]))     # backward to start

    # Part 2: traverse path_nodes da → … → db
    for k in range(len(pnodes) - 1):
        n1, n2 = pnodes[k], pnodes[k + 1]
        ed = G[n1][n2]
        eps = ed['pts']
        en_s = _coord_round(eps[0].x(), eps[0].y())
        if n1 == en_s:
            result.extend(eps[1:])           # forward  — skip eps[0] (= n1, already added)
        else:
            result.extend(reversed(eps[:-1]))  # backward — skip eps[-1] (= n1, already added)

    # Part 3: db → snap_b along segment B  (db is already the last element)
    if db == n_sb:
        result.extend(pts_b[1:i_b + 1])              # forward from start
    else:
        result.extend(reversed(pts_b[i_b + 1:-1]))   # backward from end
    result.append(snap_b)

    return result

# ---------------------------------------------------------------------------


def _safe_commit(layer, log=None):
    """Commit a layer's edit buffer, RELIABLY.

    `QgsVectorLayer.commitChanges()` returns False (it does NOT raise) when a
    commit fails — locked GeoPackage, a constraint, a provider hiccup — leaving the
    edits silently unsaved while the caller happily reports success. Worse, the edit
    buffer is left open, so the next startEditing() piles onto it. This helper makes
    every commit fail-safe: on failure it rolls the buffer back and reports, so the
    layer is never left in a half-edited state and the user isn't told a save worked
    when it didn't. Returns True only on a real, persisted commit. Behaviour on the
    SUCCESS path is identical to a bare commitChanges() (just returns the bool)."""
    try:
        if layer is not None and layer.commitChanges():
            return True
    except Exception:
        pass
    # Failure (or exception) — roll the buffer back so it can't linger / corrupt.
    try:
        if layer is not None and layer.isEditable():
            layer.rollBack()
    except Exception:
        pass
    if log is not None:
        try:
            log("⚠ Save failed — changes were rolled back (layer may be locked or "
                "read-only). Nothing was persisted.")
        except Exception:
            pass
    return False


class AutoNetProgressDialog(QtWidgets.QDialog):
    """Modal progress dialog shown while AutoNet pipeline runs.

    Displays a scrolling log, per-step progress bar, elapsed timer and a
    Close button that is only enabled once the pipeline finishes.
    """

    STEP_LABELS = [
        "Detecting layers…",
        "Step 1/5 — Generate PON Groups",
        "Step 2/5 — Generate Demand Points",
        "Step 3/5 — Generate Splitter Boundaries",
        "Step 4/5 — Generate Splitter Points",
        "Step 5/5 — Generate Drops PTP",
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        # parented to the dock; without this the C++ QDialog lingers as a hidden
        # child for the dock's whole lifetime on every AutoNet run (leak)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.setWindowTitle("⚡ AutoNet — Pipeline Progress")
        self.setMinimumWidth(560)
        self.setMinimumHeight(420)
        self.setModal(True)

        from qgis.PyQt.QtWidgets import (
            QVBoxLayout, QHBoxLayout, QLabel, QTextEdit,
            QProgressBar, QPushButton, QSizePolicy,
        )
        from qgis.PyQt.QtGui import QFont

        root = QVBoxLayout(self)
        root.setSpacing(6)
        root.setContentsMargins(10, 10, 10, 10)

        # ── Step label ────────────────────────────────────────────────
        self._step_lbl = QLabel("Initialising…")
        self._step_lbl.setStyleSheet(f'font-weight:bold;color:{theme_safe.colors()["accent"]};font-size:11px;')
        root.addWidget(self._step_lbl)

        # ── Progress bar ──────────────────────────────────────────────
        self._prog = QProgressBar()
        self._prog.setRange(0, 100)
        self._prog.setValue(0)
        self._prog.setTextVisible(True)
        self._prog.setFixedHeight(18)
        self._prog.setStyleSheet(
            "QProgressBar{border:1px solid #aaa;border-radius:4px;background:#f0f0f0;}"
            "QProgressBar::chunk{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,"
            "stop:0 #2196F3,stop:1 #21CBF3);border-radius:3px;}"
        )
        root.addWidget(self._prog)

        # ── Timer row ─────────────────────────────────────────────────
        timer_row = QHBoxLayout()
        self._timer_lbl = QLabel("⏱ 0s")
        self._timer_lbl.setStyleSheet(f'color:{theme_safe.colors()["muted"]};font-size:10px;')
        timer_row.addWidget(self._timer_lbl)
        timer_row.addStretch()
        root.addLayout(timer_row)

        # ── Log / terminal output ─────────────────────────────────────
        self._log = QTextEdit()
        self._log.setReadOnly(True)
        self._log.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)  # #130: fully-scoped enum (Qt6-safe; unscoped QTextEdit.NoWrap AttributeErrors on Qt6)
        font = QFont("Consolas", 9)
        if not font.exactMatch():
            font = QFont("Courier New", 9)
        self._log.setFont(font)
        self._log.setStyleSheet(
            "QTextEdit{background:#1e1e1e; color:#d4d4d4; border:1px solid #333;}"
        )
        self._log.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        root.addWidget(self._log, 1)

        # ── Close button (disabled until done) ───────────────────────
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        self._close_btn = QPushButton("Close")
        self._close_btn.setEnabled(False)
        self._close_btn.setFixedWidth(100)
        self._close_btn.setStyleSheet(
            "QPushButton{background:#2196F3;color:white;border-radius:4px;padding:4px 12px;}"
            "QPushButton:disabled{background:#aaa;color:#ddd;}"
            "QPushButton:hover:!disabled{background:#1565C0;}"
        )
        self._close_btn.clicked.connect(self.accept)
        btn_row.addWidget(self._close_btn)
        root.addLayout(btn_row)

        # ── Internal timer ────────────────────────────────────────────
        from qgis.PyQt.QtCore import QTimer
        self._t0 = time.time()
        self._tick_timer = QTimer(self)
        self._tick_timer.setInterval(500)
        self._tick_timer.timeout.connect(self._on_tick)
        self._tick_timer.start()

    # ------------------------------------------------------------------
    def _on_tick(self):
        elapsed = time.time() - self._t0
        if elapsed >= 3600:
            s = f"{int(elapsed // 3600)}h {int((elapsed % 3600) // 60)}m"
        elif elapsed >= 60:
            s = f"{int(elapsed // 60)}m {int(elapsed % 60)}s"
        else:
            s = f"{elapsed:.1f}s"
        pct = self._prog.value()
        if pct > 0:
            eta = elapsed * (100 - pct) / pct
            if eta >= 60:
                eta_s = f" | ETA ~{int(eta // 60)}m {int(eta % 60)}s"
            else:
                eta_s = f" | ETA ~{eta:.0f}s"
        else:
            eta_s = ""
        self._timer_lbl.setText(f"⏱ {s}{eta_s}")

    def set_step(self, step: int, label: str = ""):
        """Update step label and progress bar (step 0..5, TOTAL_STEPS=5)."""
        TOTAL = 5
        pct = int(step / TOTAL * 100) if step <= TOTAL else 100
        self._prog.setValue(pct)
        text = label or (self.STEP_LABELS[step] if step < len(self.STEP_LABELS) else "")
        self._step_lbl.setText(text)
        QApplication.processEvents()

    def append_log(self, message: str):
        """Append a line to the log area and auto-scroll."""
        self._log.append(message)
        sb = self._log.verticalScrollBar()
        sb.setValue(sb.maximum())
        QApplication.processEvents()

    def mark_complete(self, success: bool = True):
        """Called when the pipeline finishes."""
        self._tick_timer.stop()
        self._on_tick()  # final time update
        if success:
            elapsed = time.time() - self._t0
            self._step_lbl.setText(f"⚡ AutoNet Complete ✓  ({self._timer_lbl.text().replace('⏱ ', '')})")
            self._step_lbl.setStyleSheet(f'font-weight:bold;color:{theme_safe.colors()["ok"]};font-size:11px;')
            self._prog.setValue(100)
        else:
            self._step_lbl.setText("⚠ AutoNet encountered errors — see log")
            self._step_lbl.setStyleSheet(f'font-weight:bold;color:{theme_safe.colors()["bad"]};font-size:11px;')
        self._close_btn.setEnabled(True)
        self._close_btn.setFocus()
        QApplication.processEvents()

    def mark_error(self, msg: str = ""):
        self._tick_timer.stop()
        self._step_lbl.setText(f"❌ Error: {msg}")
        self._step_lbl.setStyleSheet(f'font-weight:bold;color:{theme_safe.colors()["bad"]};font-size:11px;')
        self._close_btn.setEnabled(True)
        self._close_btn.setFocus()
        QApplication.processEvents()


class ZonePickTool(QgsMapTool):
    """Click a zone polygon on the canvas → emit its id. Used by the manual
    'renumber by clicking zones in order' flow. Read-only; never edits."""

    zone_clicked = pyqtSignal(str)   # the clicked zone's id (as string)

    def __init__(self, canvas, zone_layer, zone_field):
        super().__init__(canvas)
        self._lyr = zone_layer
        self._field = zone_field

    def canvasReleaseEvent(self, e):
        from qgis.core import (QgsGeometry, QgsPointXY, QgsCoordinateTransform,
                               QgsProject)
        try:
            pt = self.toMapCoordinates(e.pos())   # project/canvas CRS
            p = QgsPointXY(pt)
            src = QgsProject.instance().crs()
            dst = self._lyr.crs()
            if src.isValid() and dst.isValid() and src != dst:
                p = QgsCoordinateTransform(src, dst, QgsProject.instance()).transform(p)
            pg = QgsGeometry.fromPointXY(p)
            hit = None
            for f in self._lyr.getFeatures():
                g = f.geometry()
                if g and not g.isEmpty() and g.contains(pg):
                    hit = f
                    break
            if hit is not None:
                self.zone_clicked.emit(str(hit[self._field]))
        except Exception:
            pass


class PonPolygonSelectTool(QgsMapTool):
    """Rubber-band polygon map tool for PON-per-PON dual-layer selection.

    Left-click  → add vertex to polygon.
    Right-click → complete polygon and select intersecting features on both layers.
    Escape      → cancel.
    """

    selection_complete = pyqtSignal(object, object)  # (demand_layer, span_layer)
    cancelled = pyqtSignal()

    def __init__(self, canvas, demand_lyr, span_lyr):
        super().__init__(canvas)
        self._demand_lyr = demand_lyr
        self._span_lyr = span_lyr
        self._points = []

        self._rb = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PolygonGeometry)
        self._rb.setColor(QColor(255, 165, 0, 90))
        self._rb.setStrokeColor(QColor(200, 120, 0, 220))
        self._rb.setWidth(2)

    # ------------------------------------------------------------------ events
    def canvasPressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            pt = self.toMapCoordinates(event.pos())
            self._points.append(pt)
            self._rb.addPoint(pt, True)
        elif event.button() == Qt.MouseButton.RightButton:
            self._finish()

    def canvasMoveEvent(self, event):
        if self._points:
            pt = self.toMapCoordinates(event.pos())
            self._rb.movePoint(pt)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self._reset()
            self.cancelled.emit()

    # ------------------------------------------------------------------ logic
    def _finish(self):
        if len(self._points) < 3:
            self._reset()
            self.cancelled.emit()
            return

        poly_geom = QgsGeometry.fromPolygonXY([self._points])
        self._reset()

        # #7 CRS-safe: the polygon vertices come from toMapCoordinates → the CANVAS
        # (project) CRS. Testing them against layer geometries in a DIFFERENT CRS (e.g.
        # a metre-projected layer under a 4326 canvas, or vice-versa) selects nothing or
        # nonsense. Transform the polygon into each layer's own CRS before testing, and
        # use a bbox prefilter so only candidates are geometry-tested. Same-CRS projects
        # (the common 4326 case) transform to a no-op → identical selection, just faster.
        from qgis.core import (QgsCoordinateTransform, QgsProject as _QP,
                               QgsFeatureRequest)
        try:
            _canvas_crs = self.canvas().mapSettings().destinationCrs()
        except Exception:
            _canvas_crs = None

        for lyr in (self._demand_lyr, self._span_lyr):
            if not lyr:
                continue
            _pg = QgsGeometry(poly_geom)   # per-layer copy so transforms don't stack
            try:
                if (_canvas_crs is not None and _canvas_crs.isValid()
                        and lyr.crs().isValid() and _canvas_crs != lyr.crs()):
                    _pg.transform(QgsCoordinateTransform(_canvas_crs, lyr.crs(), _QP.instance()))
            except Exception:
                _pg = QgsGeometry(poly_geom)   # untransformed fallback on error
            lyr.removeSelection()
            _req = QgsFeatureRequest().setFilterRect(_pg.boundingBox())
            ids = [f.id() for f in lyr.getFeatures(_req)
                   if f.geometry() and f.geometry().intersects(_pg)]
            lyr.selectByIds(ids)

        self.selection_complete.emit(self._demand_lyr, self._span_lyr)

    def _reset(self):
        self._rb.reset(QgsWkbTypes.GeometryType.PolygonGeometry)
        self._points = []

    def deactivate(self):
        self._reset()
        super().deactivate()


class FTTHPlanToolDockWidget(QtWidgets.QDockWidget, FORM_CLASS):
    """Dock widget for the FTTH Plan Tool plugin."""

    closingPlugin = pyqtSignal()

    def __init__(self, iface, parent=None):
        """Constructor.
        
        Args:
            iface: QGIS interface instance
            parent: Parent widget
        """
        super(FTTHPlanToolDockWidget, self).__init__(parent)
        self.setupUi(self)
        # Make the whole dock vertically scrollable so the bottom sections
        # (Feeder Route Generation + any loading/progress states) are always
        # reachable when the panel is taller than the screen. setupUi sets
        # dockWidgetContents as the dock widget; re-parent it into a QScrollArea.
        _scroll = QtWidgets.QScrollArea(self)
        _scroll.setObjectName("npScrollArea")
        _scroll.setWidgetResizable(True)             # content fills width, grows vertically
        _scroll.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)
        _scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        _scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        _scroll.setWidget(self.dockWidgetContents)   # re-parents the existing content
        self.setWidget(_scroll)
        self._np_scroll = _scroll
        # Header (ticket #50): plain "Network Planner" — no "Velocity", no version.
        self.setWindowTitle("Network Planner")
        self.iface = iface
        self.network_graph = None
        self.result_layer = None
        self.grouped_layer = None
        self.demand_points_layer = None
        self.splitter_points_layer = None
        self.zone_boundaries_layer = None  # step 3 output — stored for PON-per-PON merge
        self.drop_ptp_layer = None          # step 5 output — stored for PON-per-PON merge
        self._op_last_pct = -1
        self._strip_gen = 0
        self.active_client = None
        self._cancel_requested = False  # set to True by Kill button to abort running operations
        # PON-per-PON state: tracks run count and cumulative zone/group offsets
        self._pon_batch_count   = 0   # increments each completed PON-per-PON run
        self._pon_zone_offset   = 0   # running max zone_id across all runs
        self._pon_group_offset  = 0   # running max group_id across all runs
        self._current_batch_label = None  # set during autonet run, used by steps 4 & 5
        self._pon_full_span_layer = None  # full (unfiltered) span layer preserved for splitter snapping
        self._pon_color_offset = 0.0  # hue offset for zone polygon colors (rotates per batch)
        # PON-per-PON persistent accumulator layers (append-only across batches)
        self._pon_accum_groups    = None  # "PON Groups" — all grouped demand points
        self._pon_accum_zones     = None  # "PON Zone Boundaries" — all zone polygons
        self._pon_accum_splitters = None  # "PON Splitter Points" — all splitters
        self._pon_accum_drops     = None  # "PON Drop Cables" — all drop lines
        # When True, the NEXT PON-per-PON run will start a fresh session (new layers,
        # counters reset to 1).  Accumulators are NOT nulled on cancel so that Manual
        # Override can continue editing the existing layers after the button is closed.
        self._pon_new_session_needed = False

        # Persist-through-updates: a plugin reload (one-click update) builds a FRESH
        # dock, so every layer handle above resets to None and the user's splitters/
        # zones/groups appear "dead". Restore those handles + the Properties picks
        # from the PROJECT (custom properties survive a reload) once the event loop
        # turns (so setupUi's combos exist). See _session_save/_session_restore.
        from qgis.PyQt.QtCore import QTimer as _QTm0
        _QTm0.singleShot(0, self._session_restore)

        # --- Progress strip (inserted above textEdit_output) ---
        from qgis.PyQt.QtWidgets import QWidget as _QW, QHBoxLayout as _QHL, QProgressBar as _QPB, QLabel as _QL, QPushButton as _QPBS
        from qgis.PyQt.QtCore import QTimer as _QTm
        self._prog_strip = _QW()
        self._prog_strip.setFixedHeight(30)
        _ps_lay = _QHL(self._prog_strip)
        _ps_lay.setContentsMargins(4, 3, 4, 3)
        _ps_lay.setSpacing(6)
        self._prog_op_lbl = _QL("Processing...")
        self._prog_op_lbl.setStyleSheet(f'font-weight:bold;color:{theme_safe.colors()["accent"]};')
        _ps_lay.addWidget(self._prog_op_lbl)
        self._prog_bar = _QPB()
        self._prog_bar.setRange(0, 100)
        self._prog_bar.setValue(0)
        self._prog_bar.setTextVisible(False)
        self._prog_bar.setFixedHeight(14)
        self._prog_bar.setStyleSheet(
            "QProgressBar{border:1px solid #bbb;border-radius:4px;background:#f0f0f0;}"
            "QProgressBar::chunk{background:#2a6ebb;border-radius:3px;}"
        )
        _ps_lay.addWidget(self._prog_bar, 1)
        self._prog_time_lbl = _QL("0s")
        self._prog_time_lbl.setMinimumWidth(140)
        self._prog_time_lbl.setStyleSheet(f'color:{theme_safe.colors()["muted"]};font-size:9pt;')
        _ps_lay.addWidget(self._prog_time_lbl)
        # Kill / cancel button — stops any running operation
        self._prog_kill_btn = _QPBS("✕ Kill")
        self._prog_kill_btn.setFixedHeight(22)
        self._prog_kill_btn.setStyleSheet(
            "QPushButton{background:#c0392b;color:white;font-weight:bold;"
            "border-radius:3px;padding:0 8px;font-size:9pt;}"
            "QPushButton:hover{background:#e74c3c;}"
        )
        self._prog_kill_btn.setToolTip("Cancel the current operation")
        self._prog_kill_btn.clicked.connect(self._on_kill_clicked)
        _ps_lay.addWidget(self._prog_kill_btn)
        self._prog_strip.setVisible(False)
        _main_lay = self.dockWidgetContents.layout()
        for _i in range(_main_lay.count()):
            _item = _main_lay.itemAt(_i)
            if _item and _item.widget() is self.textEdit_output:
                _main_lay.insertWidget(_i, self._prog_strip)
                break

        # Hide the terminal log panel — output is shown in the AutoNet popup dialog
        self.textEdit_output.setVisible(False)
        self.textEdit_output.setMaximumHeight(0)
        self._prog_timer = _QTm(self)
        self._prog_timer.setInterval(500)
        self._prog_timer.timeout.connect(self._op_tick)
        self.active_client_profile = None

        # Connect client profile button
        self.pushButton_set_client.clicked.connect(self.on_set_client_clicked)
        self.pushButton_calculate.clicked.connect(self.on_calculate_clicked)
        self.pushButton_clear.clicked.connect(self.on_clear_clicked)
        self.pushButton_build_graph.clicked.connect(self.on_build_graph_clicked)
        self.pushButton_analyze.clicked.connect(self.on_analyze_clicked)
        self.pushButton_group_erven.clicked.connect(self.on_cluster_erven_clicked)
        self.pushButton_generate_demand_points.clicked.connect(self.on_generate_demand_points_clicked)
        self.pushButton_show_batch_stats.clicked.connect(self.on_show_batch_stats_clicked)
        self.pushButton_generate_boundaries.clicked.connect(self.on_generate_boundaries_clicked)
        self.pushButton_generate_splitters.clicked.connect(self.on_generate_splitters_clicked)
        self.pushButton_generate_drop_lashed.clicked.connect(self.on_generate_drop_lashed_clicked)
        self.pushButton_generate_drop_ptp.clicked.connect(self.on_generate_drop_ptp_clicked)
        self.pushButton_generate_aggregation_points.clicked.connect(self.on_generate_aggregation_points_clicked)
        # ONE Manual Override (JJ 2026-06-25): the single button always opens the layer
        # picker (smart, field-aware defaults) then the editor — works even when several
        # splitter/demand layers exist. The separate "Manual Override Final" is removed.
        self.pushButton_manual_override.clicked.connect(self.on_manual_override_final_clicked)
        self.pushButton_validate_span_network.clicked.connect(self.on_validate_span_network_clicked)
        self.pushButton_generate_feeder_routes.clicked.connect(self.on_generate_feeder_routes_clicked)
        self.pushButton_generate_poles.clicked.connect(self.on_generate_poles_clicked)
        self.pushButton_span_evaluate.clicked.connect(self.on_span_evaluate_clicked)
        self.pushButton_span_evaluate.setStyleSheet(
            "QPushButton { background-color: #2e4057; color: white; font-weight: bold; "
            "border-radius: 3px; padding: 3px; }"
            "QPushButton:hover { background-color: #3d5270; }"
            "QPushButton:pressed { background-color: #1e2d3e; }"
        )
        self.pushButton_restore_span_backup.clicked.connect(self.on_restore_span_backup_clicked)
        self.pushButton_restore_span_backup.setStyleSheet(
            "QPushButton { background-color: #7a3b2e; color: white; font-weight: bold; "
            "border-radius: 3px; padding: 3px; }"
            "QPushButton:hover { background-color: #9c4c3b; }"
            "QPushButton:pressed { background-color: #5c2c22; }"
            "QPushButton:disabled { background-color: #cccccc; color: #888888; }"
        )
        self.pushButton_explode_span.clicked.connect(self.on_explode_span_clicked)
        self.pushButton_explode_span.setStyleSheet(
            "QPushButton { background-color: #4a3060; color: white; font-weight: bold; "
            "border-radius: 3px; padding: 3px; }"
            "QPushButton:hover { background-color: #5e3d7a; }"
            "QPushButton:pressed { background-color: #36224a; }"
        )
        self._span_snap_backup = None   # {layer_id, layer_name, features: {fid: wkt}}

        # Hide buttons not needed at this stage
        self.pushButton_validate_span_network.setVisible(False)
        self.pushButton_show_batch_stats.setVisible(False)

        # ── Reorganize Generate PON groupbox layout ──────────────────────────
        # Final order:  [AutoNet] [ManualNet] [Manual Override] [_manual_section (hidden)]
        # _manual_section contains: form rows + all step buttons (shown on ManualNet toggle)
        from qgis.PyQt.QtWidgets import QPushButton as _QPB2, QWidget as _QW2, QVBoxLayout as _QVB2

        gb_layout = self.groupBox_4.layout()   # QVBoxLayout from UI file

        # 1. Drain ALL existing items from the groupBox layout (keeps widgets alive via parent)
        _gb_items = []
        while gb_layout.count():
            _item = gb_layout.takeAt(0)
            _w = _item.widget()
            _l = _item.layout()
            if _w:
                _gb_items.append(('widget', _w))
            elif _l:
                _gb_items.append(('layout', _l))

        # 2. Build _manual_section container for all items EXCEPT Manual Override
        self._manual_section = _QW2()
        self._manual_section.setObjectName("manualSection")
        _ms_lay = _QVB2(self._manual_section)
        _ms_lay.setContentsMargins(0, 0, 0, 0)
        _ms_lay.setSpacing(gb_layout.spacing())

        for _kind, _item in _gb_items:
            if _kind == 'widget' and _item is self.pushButton_manual_override:
                continue  # placed separately below
            if _kind == 'layout':
                _ms_lay.addLayout(_item)
            else:
                _ms_lay.addWidget(_item)

        # Extract ONLY the property fields (Demand / Method / Route / Road / Span
        # Corridor = formLayout_2) into a separate collapsible section that opens &
        # closes directly UNDER the 🔧 Properties button (ticket #38). The rest of
        # the manual section (Refresh Layers, Individual Steps, Sum buttons) stays
        # where it is and remains always visible.
        self._props_section = _QW2()
        self._props_section.setObjectName("propsSection")
        _ps_lay = _QVB2(self._props_section)
        _ps_lay.setContentsMargins(0, 0, 0, 0)
        _ps_lay.setSpacing(gb_layout.spacing())
        _ms_lay.removeItem(self.formLayout_2)     # take the 5 fields out of the manual block
        _ps_lay.addLayout(self.formLayout_2)      # …and into the Properties dropdown
        self._props_section.setVisible(False)     # collapsed by default (Properties off)
        self._manual_section.setVisible(True)     # the rest stays visible

        # ── 🔄 Refresh button (top of Properties) — re-detect project layers ──
        self._btn_refresh_props = _QPB2("🔄 Reload Layers")
        self._btn_refresh_props.setToolTip(
            "Re-scan the project and auto-detect the demand / route / road layers "
            "into the dropdowns — use after you add, rename or reload layers.")
        self._btn_refresh_props.setStyleSheet(
            "QPushButton { background-color: #0e7490; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #0891b2; }"
            "QPushButton:pressed { background-color: #155e75; }")
        self._btn_refresh_props.clicked.connect(self._refresh_properties)
        _ms_lay.insertWidget(0, self._btn_refresh_props)

        # ── "Sum Span Distance" button — added at the bottom of the manual section
        self._btn_sum_span = _QPB2("📏 Sum Span Distance")
        self._btn_sum_span.setToolTip(
            "Calculate the total length of all features in the selected Span (Route) layer.")
        self._btn_sum_span.setStyleSheet(
            "QPushButton { background-color: #5d4e8c; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #7060a8; }"
            "QPushButton:pressed { background-color: #46387a; }"
        )
        self._btn_sum_span.clicked.connect(self.on_sum_span_distance_clicked)
        _ms_lay.addWidget(self._btn_sum_span)

        # ── "Sum Pole Numbers" button
        self._btn_sum_poles = _QPB2("🔢 Sum Pole Numbers")
        self._btn_sum_poles.setToolTip(
            "Count the total number of poles across all Poles layers in the project.")
        self._btn_sum_poles.setStyleSheet(
            "QPushButton { background-color: #7a4a1e; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #9a5e28; }"
            "QPushButton:pressed { background-color: #5c3716; }"
        )
        self._btn_sum_poles.clicked.connect(self.on_sum_pole_numbers_clicked)
        _ms_lay.addWidget(self._btn_sum_poles)

        # ── "Sum Demand Points" button
        self._btn_sum_demand = _QPB2("🏠 Sum Demand Points")
        self._btn_sum_demand.setToolTip(
            "Count the total number of demand points in the Demand Points layer.")
        self._btn_sum_demand.setStyleSheet(
            "QPushButton { background-color: #1a5276; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #2471a3; }"
            "QPushButton:pressed { background-color: #154360; }"
        )
        self._btn_sum_demand.clicked.connect(self.on_sum_demand_points_clicked)
        _ms_lay.addWidget(self._btn_sum_demand)

        # ── "AutoSum" button
        self._btn_autosum = _QPB2("🧮 Auto-Sum")
        self._btn_autosum.setToolTip(
            "Calculate Span Distance + Pole Count + Demand Point Count and show all results in one window.")
        self._btn_autosum.setStyleSheet(
            "QPushButton { background-color: #4a235a; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #6c3483; }"
            "QPushButton:pressed { background-color: #381748; }"
        )
        self._btn_autosum.clicked.connect(self.on_auto_sum_clicked)
        _ms_lay.addWidget(self._btn_autosum)

        # ── "BOQ Take-off" button — geometry quantity breakdown per PON & Zone
        self._btn_boq_takeoff = _QPB2("🧾 BOQ Take-off")
        self._btn_boq_takeoff.setToolTip(
            "Geometry quantity take-off for the whole project, broken down per PON "
            "and per Zone:\n"
            "• poles (count + size + length)\n"
            "• pole hardware (hooks / tangents / dead-ends, where derivable)\n"
            "• cable lengths by type (metres)\n"
            "• trenching / drilling (where those layers/attributes exist)\n"
            "Auto-detects the PON grouping field; read-only; exports to CSV/Excel.")
        self._btn_boq_takeoff.setStyleSheet(
            "QPushButton { background-color: #7a5a1e; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #9a7328; }"
            "QPushButton:pressed { background-color: #5c4316; }"
        )
        self._btn_boq_takeoff.clicked.connect(self.on_boq_takeoff_clicked)
        _ms_lay.addWidget(self._btn_boq_takeoff)

        # ── "Tag by PON / Phase" button — which area does each feature fall in?
        self._btn_zone_tag = _QPB2("🏷 Tag by PON / Phase")
        self._btn_zone_tag.setToolTip(
            "Add a column to any layer saying which PON / Phase (or any polygon "
            "layer) each feature falls in:\n"
            "• pick the polygon layers to tag with + the field holding the value\n"
            "• pick the layers that get the new column\n"
            "• points get the one area they sit in; cables list every area they "
            "cross\n"
            "Previews everything first — nothing is written until you press Apply.")
        self._btn_zone_tag.setStyleSheet(
            "QPushButton { background-color: #1e5f7a; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #2879a0; }"
            "QPushButton:pressed { background-color: #16465a; }"
        )
        self._btn_zone_tag.clicked.connect(self.on_zone_tag_clicked)
        _ms_lay.addWidget(self._btn_zone_tag)

        self._btn_autonet = _QPB2("⚡ AutoNet")
        self._btn_autonet.setToolTip(
            "Auto-detect layers and run the full pipeline:\n"
            "Generate PON Groups → Demand Points → Group Boundaries → Splitter Points → Drops PTP"
        )
        self._btn_autonet.setStyleSheet(
            "QPushButton { background-color: #1a6b3c; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #238a4f; }"
            "QPushButton:pressed { background-color: #145230; }"
        )
        self._btn_autonet.clicked.connect(self.on_autonet_clicked)

        # 4. ManualNet toggle button
        self._btn_manualnet = _QPB2("🔧 Properties")
        self._btn_manualnet.setCheckable(True)
        self._btn_manualnet.setChecked(False)
        self._btn_manualnet.setToolTip("Show / hide manual step controls")
        self._btn_manualnet.setStyleSheet(
            "QPushButton { background-color: #2a5b8a; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #336fa5; }"
            "QPushButton:pressed { background-color: #1f4468; }"
            "QPushButton:checked { background-color: #1f4468; }"
        )
        self._btn_manualnet.toggled.connect(
            lambda checked: self._props_section.setVisible(checked)
        )

        # 5. Output GeoPackage row (always visible — path stored inside the .qgz project file)
        from qgis.PyQt.QtWidgets import (QWidget as _QW3, QHBoxLayout as _QHL3,
                                         QLabel as _QL3, QLineEdit as _QLE3,
                                         QToolButton as _QTB3)
        from qgis.PyQt.QtCore import QSize as _QSz3

        _gpkg_row = _QW3()
        _gpkg_hl = _QHL3(_gpkg_row)
        _gpkg_hl.setContentsMargins(2, 2, 2, 2)
        _gpkg_hl.setSpacing(4)
        _gpkg_lbl = _QL3("Output GPKG:")
        _gpkg_lbl.setStyleSheet(f'font-size:8pt;color:{theme_safe.colors()["muted"]};')
        _gpkg_hl.addWidget(_gpkg_lbl)
        self._output_gpkg_edit = _QLE3()
        self._output_gpkg_edit.setPlaceholderText("(scratch — set file to persist layers)")
        self._output_gpkg_edit.setToolTip(
            "GeoPackage where ALL output layers are saved.\n"
            "Set once per project — layers reload automatically when project is reopened.")
        self._output_gpkg_edit.setStyleSheet("font-size: 8pt;")
        _gpkg_hl.addWidget(self._output_gpkg_edit, 1)
        _gpkg_btn = _QTB3()
        _gpkg_btn.setText("📁")
        _gpkg_btn.setFixedSize(_QSz3(26, 22))
        _gpkg_btn.setToolTip("Browse for output GeoPackage file")
        _gpkg_hl.addWidget(_gpkg_btn)

        _gpkg_btn.clicked.connect(self._browse_gpkg_path)

        # textChanged fires on every keystroke AND after setText — use it to always persist
        self._output_gpkg_edit.textChanged.connect(self._save_gpkg_path)

        # Load path whenever a project is opened or created
        from qgis.core import QgsProject as _QP4
        _QP4.instance().readProject.connect(self._reload_gpkg_path)
        _QP4.instance().cleared.connect(self._clear_gpkg_path)

        # ── "PON per PON Manual" button ────────────────────────────────
        # Base label kept in one place so the toggle states stay consistent.
        self._PON_PER_PON_LABEL = "🎯 PON per PON Manual  ·BETA"
        self._btn_pon_per_pon = _QPB2(self._PON_PER_PON_LABEL)
        self._btn_pon_per_pon.setToolTip(
            "Select a subset of Span features and Demand Points on the map,\n"
            "then run the full AutoNet pipeline on only those selected features.\n"
            "Repeat for each PON area individually."
        )
        self._btn_pon_per_pon.setStyleSheet(
            "QPushButton { background-color: #7d4e00; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #a06300; }"
            "QPushButton:pressed { background-color: #5a3800; }"
            "QPushButton:checked { background-color: #5a3800; }"
        )
        self._btn_pon_per_pon.setCheckable(True)
        self._btn_pon_per_pon.clicked.connect(self.on_pon_per_pon_clicked)
        self._pon_per_pon_active = False   # track whether we're in selection mode

        # 6. Rebuild layout: GPKG row → Properties (top, per request) → AutoNet → PON per PON → Manual Override → Create Enclosure → collapsible section
        gb_layout.addWidget(_gpkg_row)
        gb_layout.addWidget(self._btn_manualnet)        # 🔧 Properties — moved to top
        gb_layout.addWidget(self._props_section)        # 5 config fields collapse right under Properties
        gb_layout.addWidget(self._btn_autonet)
        gb_layout.addWidget(self._btn_pon_per_pon)

        # ── PON Tools (BETA) — gated to beta testers; safe on permanent data ──
        # PON per PON Manual above generates pons (everyone). The PON Inspector is
        # READ-ONLY (cannot change data). Renumber is still being built and stays
        # LOCKED until its engine lands. Both are unlocked only for beta testers
        # (see _pon_is_beta_user) so work-in-progress can't reach the wider team.
        from qgis.PyQt.QtWidgets import QLabel as _QLbeta
        _is_beta = self._pon_is_beta_user()
        _term = self._pon_term()   # 'Zone' (zone polygon IS the PON) or 'PON'
        _banner_txt = (
            "ℹ️ Renumber previews the full change first, then renumbers every zone in "
            "feeder-route order. A backup is taken automatically before it writes — if "
            "the backup fails, nothing is renumbered. Use ↩ Undo last Renumber to roll "
            "it back.")
        self._pon_beta_banner = _QLbeta(_banner_txt)
        self._pon_beta_banner.setWordWrap(True)
        self._pon_beta_banner.setStyleSheet(
            "QLabel { background-color: #0e2233; color: #7fb2e5; border: 1px solid #2f5f88; "
            "border-left: 4px solid #2f5f88; border-radius: 4px; padding: 5px 7px; "
            "font-size: 8.5pt; }")
        gb_layout.addWidget(self._pon_beta_banner)

        # (🔍 Inspect {term}s removed at JJ's request, 2026-06-25 — Renumber is the keeper.)

        # 📊 Unit counts — "just show us the numbers of units in that PON"
        # (JJ 2026-07-23). READ-ONLY: counts demand points per PON straight from
        # the layers every time it opens. Deliberately makes no judgement about
        # which PONs should merge — the planner decides that.
        self._btn_pon_counts = _QPB2(f"⇔ Merge {_term}s")
        self._btn_pon_counts.setToolTip(
            f"Show every {_term} with its unit (demand point) and splitter count, "
            f"then merge the ones you pick.\n"
            "Counts are read live from the layers — never from a cached value.\n"
            "Opens read-only: nothing changes until you press Merge, and a "
            "backup is taken first.")
        self._btn_pon_counts.setStyleSheet(
            "QPushButton { background-color: #1c2f3f; color: #9fd0f5; font-weight: bold; "
            "border: 1px solid #35617f; border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #24405a; }")
        self._btn_pon_counts.clicked.connect(self._open_pon_unit_counts)
        gb_layout.addWidget(self._btn_pon_counts)

        # 🔢 Renumber PONs — feeder-route renumber. Unlocked for beta testers and
        # ONLY runnable on a sandbox/test project (hard guard inside). Locked for team.
        self._btn_pon_renumber = _QPB2(f"🔢 Renumber {_term}s")
        self._btn_pon_renumber.setToolTip(
            "Renumber PONs/Zones in feeder-route order. Runs on any project — previews the "
            "full change first. Use the 💾 Backup button first if you want a safety copy.")
        self._btn_pon_renumber.setStyleSheet(
            "QPushButton { background-color: #1d3a2a; color: #8fe6b8; font-weight: bold; "
            "border: 1px solid #2f8860; border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #254a35; }")
        self._btn_pon_renumber.clicked.connect(
            self._open_zone_renumber if _is_beta else self._on_pon_renumber_locked)
        gb_layout.addWidget(self._btn_pon_renumber)

        # ↩ Undo last renumber — the other half of the backup. _pon_restore_zone_backup
        # existed but nothing called it (and nothing wrote its backups), so a renumber
        # was one-way. Both halves are live again as of 2026-07-15.
        self._btn_pon_restore = _QPB2("↩ Undo last Renumber")
        self._btn_pon_restore.setToolTip(
            "Roll every layer back to the snapshot taken before the LAST renumber.\n"
            "Restores the attribute tables exactly as they were, matched feature by "
            "feature.\nA backup is written automatically before every renumber — if "
            "it can't be written, the renumber is refused.")
        self._btn_pon_restore.setStyleSheet(
            "QPushButton { background-color: #6b5320; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #8a6c2a; }"
            "QPushButton:pressed { background-color: #4d3b17; }"
        )
        self._btn_pon_restore.clicked.connect(self._pon_restore_zone_backup)
        gb_layout.addWidget(self._btn_pon_restore)

        # 🔢 Delete + Renumber — remove PONs and close the gaps they leave
        self._btn_del_renum = _QPB2("🗑 Delete + Renumber  ·BETA")
        self._btn_del_renum.setToolTip(
            "Remove PONs (and, if you tick them, the drops / joints / splitters "
            "inside them), then renumber the survivors so there are no gaps —\n"
            "delete PON 15 and 16 becomes 15, 17 becomes 16, keeping the order "
            "they flow in now.\n"
            "Everything referencing a PON (the _SP tokens in the joint names) "
            "follows automatically.\n"
            "Previews the whole change first; backs up before it writes, and "
            "refuses to write if the backup fails.")
        self._btn_del_renum.setStyleSheet(
            "QPushButton { background-color: #7a2e2e; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #9c3d3d; }"
            "QPushButton:pressed { background-color: #5c2222; }"
        )
        self._btn_del_renum.clicked.connect(self.on_delete_renumber_clicked)
        gb_layout.addWidget(self._btn_del_renum)

        # Ticket #42 — all override buttons light blue (shared style)
        _OVERRIDE_BTN_QSS = (
            "QPushButton { background-color: #4FC3F7; color: #06283D; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover   { background-color: #81D4FA; }"
            "QPushButton:pressed { background-color: #29B6F6; }"
        )
        self.pushButton_manual_override.setStyleSheet(_OVERRIDE_BTN_QSS)
        gb_layout.addWidget(self.pushButton_manual_override)


        self._btn_create_enclosure = _QPB2("📍 Create Enclosure")
        self._btn_create_enclosure.setToolTip("Manually place a Feeder Splice or First Tier Splitter Splice enclosure on the map")
        self._btn_create_enclosure.setStyleSheet(
            "QPushButton { background-color: #2d6e2d; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #3d8f3d; }"
            "QPushButton:pressed { background-color: #1f4f1f; }"
            "QPushButton:checked { background-color: #1f4f1f; border: 2px solid #90ee90; }"
        )
        self._btn_create_enclosure.setCheckable(True)
        self._btn_create_enclosure.clicked.connect(self.on_create_enclosure_clicked)
        self._create_enclosure_tool = None   # holds active map tool
        self._create_enclosure_type = None   # 'FS' or 'FTS'
        gb_layout.addWidget(self._btn_create_enclosure)

        # ── "Create Span" manual line drawing button ──────────────────────
        self._btn_create_span = _QPB2("📐 Create Span")
        self._btn_create_span.setToolTip("Manually draw Feeder, Distribution, or other span cables on the map")
        self._btn_create_span.setStyleSheet(
            "QPushButton { background-color: #3d5a7a; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #4d7a9a; }"
            "QPushButton:pressed { background-color: #2d3a5a; }"
            "QPushButton:checked { background-color: #2d3a5a; border: 2px solid #87ceeb; }"
        )
        self._btn_create_span.setCheckable(True)
        self._btn_create_span.clicked.connect(self.on_create_span_clicked)
        self._create_span_tool = None   # holds active map tool
        self._create_span_type = None   # 'Feeder', 'Second Feeder', etc.
        # Ticket #51 — Create Span (Generate Span Lines) + Generate Poles to the TOP
        # of the menu (index 1/2, right under the GPKG output row).
        gb_layout.insertWidget(1, self._btn_create_span)
        gb_layout.insertWidget(2, self.pushButton_generate_poles)

        gb_layout.addWidget(self._manual_section)
        
        # Connect collapsible group boxes
        self.groupBox_4.toggled.connect(lambda checked: self.toggle_groupbox(self.groupBox_4, checked))
        self.groupBox_feeder_routes.toggled.connect(lambda checked: self.toggle_groupbox(self.groupBox_feeder_routes, checked))
        self.groupBox_individual_steps.toggled.connect(
            lambda checked: self.toggle_groupbox(self.groupBox_individual_steps, checked)
        )

        # Style the individual steps groupbox as a collapsible section
        self.groupBox_individual_steps.setStyleSheet(
            "QGroupBox {"
            f"  font-weight: bold; font-size: 9pt; color: {theme_safe.colors()['accent']};"
            "  border: 1px solid #7090b0; border-radius: 4px;"
            "  margin-top: 6px; padding-top: 6px;"
            "}"
            "QGroupBox::title {"
            "  subcontrol-origin: margin; subcontrol-position: top left;"
            "  padding: 0 4px; left: 6px;"
            "}"
            "QGroupBox::indicator { width: 14px; height: 14px; }"
        )

        # Initialize collapsed state for groups that start collapsed
        self.toggle_groupbox(self.groupBox_feeder_routes, False)
        self.toggle_groupbox(self.groupBox_individual_steps, False)
        
        # Connect layer type combo box to update label
        self.comboBox_clustering_method.currentIndexChanged.connect(self.on_clustering_method_changed)
        
        # Check if advanced libraries are available
        if not SKLEARN_AVAILABLE or not NUMPY_AVAILABLE:
            self.log_message("NOTE: Advanced clustering (DBSCAN, K-Means) requires scikit-learn and numpy.")
            self.log_message("Install with: pip install scikit-learn numpy")

        # Lock all planning sections until a client profile is loaded
        self._set_planning_sections_enabled(False)

        self.log_message("Velocity Network Planner initialized. Select a Client Profile to begin.")

    def on_clustering_method_changed(self, index):
        """Update UI elements based on selected clustering method."""
        # Only "Tight Groups of 8" method remains, no UI updates needed

    def on_layer_type_changed(self, index):
        """Layer type is fixed to Demand Points."""

    def on_set_client_clicked(self):
        """Load the selected client profile and unlock planning tools."""
        client_name = self.comboBox_client.currentText()
        if client_name == "-- Select Client --":
            self.log_message("ERROR: Please select a client from the dropdown before loading a profile.")
            return

        self.active_client = client_name
        self.active_client_profile = CLIENT_PROFILES[client_name]
        profile = self.active_client_profile

        # Update status label
        self.label_active_client.setText(client_name)
        self.label_active_client.setStyleSheet("color: green; font-weight: bold;")

        # Unlock planning sections
        self._set_planning_sections_enabled(True)

        self.log_message(f"--- Client Profile Loaded: {client_name} ---")
        self.log_message(f"  {profile['description']}")
        self.log_message(f"  Max PON size: {profile['max_pon_size']}  |  Target: {profile['target_pon_size']}")
        self.log_message(f"  Split ratio: Feeder {profile['splitter_ratio_feeder']}  |  Dist {profile['splitter_ratio_dist']}")
        self.log_message(f"  Max feeder cable: {profile['max_feeder_cable_fibres']}F  |  Max span: {profile['max_span_m']}m")
        self.log_message(f"  Pole heights: Feeder {profile['feeder_pole_height_m']}m  |  Dist {profile['dist_pole_height_m']}m")
        self.log_message("Planning tools are now unlocked.")

    def _set_planning_sections_enabled(self, enabled: bool):
        """Enable or disable all planning group boxes."""
        for gb in (self.groupBox_4, self.groupBox_feeder_routes, self.groupBox_individual_steps):
            gb.setEnabled(enabled)

    def toggle_groupbox(self, groupbox, checked):
        """Toggle visibility of groupbox contents for collapsible behavior."""
        # Get the layout inside the groupbox
        layout = groupbox.layout()
        if layout:
            # Show/hide all widgets in the layout
            for i in range(layout.count()):
                item = layout.itemAt(i)
                widget = item.widget()
                if widget:
                    widget.setVisible(checked)
                # Handle nested layouts
                nested_layout = item.layout()
                if nested_layout:
                    for j in range(nested_layout.count()):
                        nested_item = nested_layout.itemAt(j)
                        nested_widget = nested_item.widget()
                        if nested_widget:
                            nested_widget.setVisible(checked)

    # ── Persist the Network Planner session across plugin reloads (updates) ──────
    def _session_layer_map(self):
        """attr-name -> live layer handle, for the refs that must survive a reload."""
        return {
            "grouped_layer":          getattr(self, "grouped_layer", None),
            "splitter_points_layer":  getattr(self, "splitter_points_layer", None),
            "zone_boundaries_layer":  getattr(self, "zone_boundaries_layer", None),
            "drop_ptp_layer":         getattr(self, "drop_ptp_layer", None),
            "demand_points_layer":    getattr(self, "demand_points_layer", None),
            "_pon_accum_groups":      getattr(self, "_pon_accum_groups", None),
            "_pon_accum_zones":       getattr(self, "_pon_accum_zones", None),
            "_pon_accum_splitters":   getattr(self, "_pon_accum_splitters", None),
            "_pon_accum_drops":       getattr(self, "_pon_accum_drops", None),
        }

    def _session_save(self):
        """Snapshot the active layer handles + Properties picks to the PROJECT (custom
        property). The layers themselves live in the project and survive a plugin
        reload; only the dock's in-memory handles are lost — this lets the fresh dock
        re-bind them so splitters/zones/groups stay live through a one-click update."""
        try:
            import json
            from qgis.PyQt import sip as _sip_s
            from qgis.core import QgsProject
            data = {"layers": {}, "combos": {}}
            for name, ref in self._session_layer_map().items():
                try:
                    if ref is not None and not _sip_s.isdeleted(ref):
                        data["layers"][name] = ref.id()
                except Exception:
                    pass
            for ckey, attr in (("demand", "comboBox_erf"),
                               ("route", "comboBox_span_layer"),
                               ("road", "comboBox_road_layer")):
                cb = getattr(self, attr, None)
                try:
                    lyr = cb.currentLayer() if cb is not None else None
                    if lyr is not None:
                        data["combos"][ckey] = lyr.id()
                except Exception:
                    pass
            proj = QgsProject.instance()
            # writeEntry() marks the project DIRTY — but stashing our session is not a
            # user edit, so don't trigger a spurious "Save changes?" prompt. Preserve
            # whatever dirty state the project already had.
            _was_dirty = proj.isDirty()
            proj.writeEntry("velocity", "np_session", json.dumps(data))
            if not _was_dirty:
                proj.setDirty(False)
        except Exception:
            pass

    def _session_restore(self):
        """Rebind the dock's layer handles + Properties picks from the saved session,
        binding only to layers that still exist. No-op if there's no saved session
        (fresh project). Name-resolution (#60/#67) still backstops anything missed."""
        try:
            import json
            from qgis.core import QgsProject
            proj = QgsProject.instance()
            raw, ok = proj.readEntry("velocity", "np_session", "")
            if not ok or not raw:
                return
            data = json.loads(raw)
            rebound = 0
            for name, lid in (data.get("layers") or {}).items():
                lyr = proj.mapLayer(lid)
                if lyr is not None:
                    setattr(self, name, lyr)
                    rebound += 1
            for ckey, attr in (("demand", "comboBox_erf"),
                               ("route", "comboBox_span_layer"),
                               ("road", "comboBox_road_layer")):
                lid = (data.get("combos") or {}).get(ckey)
                cb = getattr(self, attr, None)
                if lid and cb is not None:
                    lyr = proj.mapLayer(lid)
                    if lyr is not None:
                        try:
                            cb.setLayer(lyr)
                        except Exception:
                            pass
            if rebound:
                self.log_message(
                    f"  ↺ Restored {rebound} Network Planner layer(s) after update — "
                    f"your splitters / zones / groups are still live.")
        except Exception:
            pass

    def _refresh_canvas_now(self):
        """Force an IMMEDIATE canvas redraw. `layer.triggerRepaint()` only QUEUES a
        repaint, which then waits behind the heavy drop-regen on the main thread —
        that's the 'takes a second to show on the canvas' lag when reassigning demand
        points / moving splitters. mapCanvas().refresh() renders as soon as the edit
        handler returns instead of on some later, unrelated repaint event."""
        try:
            self.iface.mapCanvas().refresh()
        except Exception:
            pass

    def log_message(self, message: str):
        """Add a message to the output text area.

        Args:
            message: Message to display
        """
        # Ticket #100 (#65 class): the dock's QTextEdit can be deleted out from under
        # us — a plugin reload/unload while a map tool is still active fires a canvas
        # callback that logs into the now-deleted C++ widget, raising
        # "RuntimeError: wrapped C/C++ object of type QTextEdit has been deleted" and
        # crashing the plugin. Logging must NEVER crash, so guard the append with both
        # a sip.isdeleted check and a RuntimeError catch (sip can lag a frame).
        try:
            if not sip.isdeleted(self.textEdit_output):
                self.textEdit_output.append(message)
        except RuntimeError:
            pass   # QTextEdit already torn down — nothing to log into
        except Exception:
            pass
        # Feed the Geometry Guardian's black-box breadcrumb so that, if geometry
        # mass-vanishes, the incident report shows what the plugin was doing.
        try:
            from ..geometry_guardian import record_activity
            record_activity(message)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Timer / progress helpers
    # ------------------------------------------------------------------
    def _fmt_time(self, secs: float) -> str:
        """Format seconds into human-readable string."""
        if secs >= 3600:
            return f"{int(secs // 3600)}h {int((secs % 3600) // 60)}m"
        elif secs >= 60:
            return f"{int(secs // 60)}m {int(secs % 60)}s"
        else:
            return f"{secs:.1f}s"

    def _op_tick(self):
        """Called every 500 ms by _prog_timer to update the elapsed/ETA display."""
        import time
        if self._op_t0 is None:
            return
        secs = time.time() - self._op_t0
        elapsed_str = self._fmt_time(secs)
        pct = self._prog_bar.value()
        if pct > 0:
            eta_secs = secs * (100 - pct) / pct
            eta_str = f" | ETA: ~{self._fmt_time(eta_secs)}"
        else:
            eta_str = ""
        self._prog_time_lbl.setText(f"\u23f1 {elapsed_str}{eta_str}")

    def _start_timer(self):
        """Record the start time and show the progress strip."""
        import time
        self._op_t0 = time.time()
        self._op_last_pct = -1
        self._strip_gen += 1
        self._prog_bar.setValue(0)
        self._prog_time_lbl.setText("0s")
        self._prog_op_lbl.setText("Processing\u2026")
        self._prog_strip.setVisible(True)
        self._prog_timer.start()

    def _hide_prog_strip(self, gen: int):
        """Hide the progress strip only if no newer operation has started since gen."""
        if self._strip_gen == gen:
            self._prog_strip.setVisible(False)

    def _elapsed(self, label: str = ''):
        """Log time elapsed since _start_timer() was called, then finalise the strip."""
        import time
        from qgis.PyQt.QtCore import QTimer as _QT
        from qgis.PyQt.QtWidgets import QApplication as _QApp
        if self._op_t0 is None:
            return
        secs = time.time() - self._op_t0
        t_str = self._fmt_time(secs)
        prefix = f"{label} \u2014 " if label else ''
        self.log_message(f"  \u23f1 {prefix}{t_str}")
        # Finalise the strip
        self._prog_timer.stop()
        self._prog_bar.setValue(100)
        self._prog_op_lbl.setText(f"\u2713 {label}" if label else "\u2713 Done")
        self._prog_time_lbl.setText(f"\u23f1 {t_str}")
        _QApp.processEvents()
        _gen = self._strip_gen
        _QT.singleShot(3000, lambda: self._hide_prog_strip(_gen))
        self._op_t0 = None

    def _progress(self, done: int, total: int, label: str = ''):
        """Update progress bar and log at 25 % milestones; flush Qt event queue."""
        from qgis.PyQt.QtWidgets import QApplication
        import time
        if total > 0:
            pct = done * 100 // total
            self._prog_bar.setValue(pct)
            if label:
                self._prog_op_lbl.setText(label)
            milestone = (pct // 25) * 25
            if milestone > 0 and milestone != self._op_last_pct:
                self._op_last_pct = milestone
                elapsed = (time.time() - self._op_t0) if self._op_t0 is not None else 0.0
                tag = f"{label}: " if label else ''
                self.log_message(
                    f"  {tag}{milestone}%  ({done}/{total})  [{elapsed:.1f}s]"
                )
        QApplication.processEvents()

    def _on_kill_clicked(self):
        """Set the cancel flag so any running loop can detect and abort."""
        self._cancel_requested = True
        self._prog_op_lbl.setText("⛔ Cancelled — stopping…")
        self.log_message("⛔ CANCELLED by user — operation stopped.")

    def _cancel_check(self) -> bool:
        """Return True (and reset flag) if the user pressed Kill. Callers should return early."""
        if self._cancel_requested:
            self._cancel_requested = False
            return True
        return False

    def _start_operation(self, label: str = "Processing…"):
        """Reset cancel flag and start the progress strip."""
        self._cancel_requested = False
        self._start_timer()
        self._prog_op_lbl.setText(label)
    # keeps a strong reference and the signal connections stay alive)
    # ------------------------------------------------------------------
    def _save_gpkg_path(self, text: str):
        """Write the GPKG path into the current project's custom properties."""
        from qgis.core import QgsProject
        QgsProject.instance().writeEntry("FTTHPlanTool", "output_gpkg", text.strip())

    def _reload_gpkg_path(self):
        """Read back the GPKG path from the project and populate the field."""
        from qgis.core import QgsProject
        path = QgsProject.instance().readEntry("FTTHPlanTool", "output_gpkg", "")[0]
        self._output_gpkg_edit.blockSignals(True)
        self._output_gpkg_edit.setText(path)
        self._output_gpkg_edit.blockSignals(False)

    def _clear_gpkg_path(self):
        """Clear the GPKG field when a new/empty project is created."""
        self._output_gpkg_edit.blockSignals(True)
        self._output_gpkg_edit.clear()
        self._output_gpkg_edit.blockSignals(False)

    def _browse_gpkg_path(self):
        """Open file browser, set the GPKG path field, and immediately persist it."""
        from qgis.core import QgsProject
        from qgis.PyQt.QtWidgets import QFileDialog
        start = self._output_gpkg_edit.text() or QgsProject.instance().homePath() or ''
        path, _ = QFileDialog.getSaveFileName(self, "Select Output GeoPackage", start,
                                              "GeoPackage (*.gpkg)")
        if path:
            if not path.lower().endswith('.gpkg'):
                path += '.gpkg'
            self._output_gpkg_edit.setText(path)   # triggers textChanged → _save_gpkg_path

    # ------------------------------------------------------------------
    # Output layer persistence
    # ------------------------------------------------------------------
    def _add_layer_on_top(self, layer):
        """Add a layer to the project ABOVE the existing layers.

        Audit Batch A: every generated output (poles/drops/splitters/zones/…) used
        a bare `addMapLayer(layer)`, which lets QGIS drop the new layer wherever the
        current tree selection points — frequently UNDER the opaque satellite
        basemap, so the operator gets a 'Created N …' log but a blank canvas. Adding
        with addToLegend=False then inserting the tree node at index 0 guarantees the
        output sits on top and is visible + toggleable. Best-effort: on any failure
        fall back to the plain add so a layer is never lost.
        """
        from qgis.core import QgsProject, QgsLayerTreeLayer
        proj = QgsProject.instance()
        try:
            proj.addMapLayer(layer, False)
            proj.layerTreeRoot().insertChildNode(0, QgsLayerTreeLayer(layer))
        except Exception:
            try:
                proj.addMapLayer(layer)
            except Exception:
                pass
        return layer

    def _add_output_layer(self, mem_layer: 'QgsVectorLayer') -> 'QgsVectorLayer':
        """Write a memory layer to the configured output GeoPackage and add to project.

        If no GeoPackage path is configured, falls back to adding the memory
        (scratch) layer directly.  Returns the layer that was added to the project
        (file-based if GPKG was used, otherwise the original memory layer).
        """
        import os
        from qgis.core import QgsVectorFileWriter, QgsProject

        gpkg_path = self._output_gpkg_edit.text().strip()

        if not gpkg_path:
            self._add_layer_on_top(mem_layer)
            return mem_layer

        # Sanitize layer name → GPKG table name
        layer_name = mem_layer.name()
        table_name = re.sub(r'[^a-zA-Z0-9]', '_', layer_name).strip('_') or 'ftth_layer'

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        options.layerName = table_name
        # If the GPKG file doesn't exist yet use CreateOrOverwriteFile (creates the file).
        # If it does exist use CreateOrOverwriteLayer (adds/replaces just this table).
        if os.path.exists(gpkg_path):
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
        else:
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile

        self.log_message(f"  💾 Writing '{layer_name}' → {os.path.basename(gpkg_path)} …")

        try:
            error, msg, _, _ = QgsVectorFileWriter.writeAsVectorFormatV3(
                mem_layer, gpkg_path, QgsProject.instance().transformContext(), options)
        except Exception as exc:
            self.log_message(f"  ❌ GPKG write exception: {exc}")
            self.log_message("  Layer added as temporary scratch layer instead.")
            self._add_layer_on_top(mem_layer)
            return mem_layer

        if error != QgsVectorFileWriter.NoError:
            self.log_message(f"  ❌ GPKG write failed (code {error}): {msg}")
            self.log_message("  Layer added as temporary scratch layer instead.")
            self._add_layer_on_top(mem_layer)
            return mem_layer

        # Reload from GPKG as a persistent file-based layer
        uri = f"{gpkg_path}|layername={table_name}"
        file_layer = QgsVectorLayer(uri, layer_name, "ogr")
        if not file_layer.isValid():
            self.log_message(f"  ❌ Saved OK but reload failed for '{layer_name}' — using scratch.")
            self._add_layer_on_top(mem_layer)
            return mem_layer

        # Transfer renderer and labeling from the memory layer
        if mem_layer.renderer():
            file_layer.setRenderer(mem_layer.renderer().clone())
        if mem_layer.labeling():
            file_layer.setLabeling(mem_layer.labeling().clone())
            file_layer.setLabelsEnabled(mem_layer.labelsEnabled())

        self._add_layer_on_top(file_layer)
        self.log_message(f"  ✅ Saved [{table_name}]")
        return file_layer


    def on_build_graph_clicked(self):
        """Build network graph from selected layers."""
        nodes_layer = self.comboBox_nodes.currentLayer()
        ducts_layer = self.comboBox_ducts.currentLayer()
        
        if not ducts_layer:
            self.log_message("ERROR: Please select a ducts layer.")
            return
        
        self._start_timer()
        try:
            self.log_message("Building network graph...")
            # CRS-aware metre-distance so edge lengths / optical loss / the
            # total-length figure are in real metres, not decimal degrees,
            # when the ducts layer is in a geographic CRS (e.g. EPSG:4326).
            self.network_graph = NetworkGraph(
                dist_func=self._make_metre_dist_func(ducts_layer)
            )

            # Add named nodes if a nodes layer is selected
            if nodes_layer:
                self.log_message(f"Loading nodes from '{nodes_layer.name()}'...")
                node_count = 0
                for feature in get_layer_features(nodes_layer):
                    coords = get_point_coordinates(feature)
                    if coords:
                        self.network_graph.add_node_from_qgis(
                            f"node_{feature.id()}",
                            coords,
                            properties=feature.attributeMap(),
                        )
                        node_count += 1
                self.log_message(f"  Added {node_count} nodes")

            # Add edges from ducts (intermediate vertices included)
            self.log_message(f"Loading ducts from '{ducts_layer.name()}'...")
            duct_count = 0
            for feature in get_layer_features(ducts_layer):
                coords = get_linestring_coordinates(feature)
                if coords and len(coords) >= 2:
                    self.network_graph.add_edge_from_qgis(
                        coords,
                        properties=feature.attributeMap(),
                    )
                    duct_count += 1
            self.log_message(f"  Processed {duct_count} duct features")

            # Display graph info
            info = self.network_graph.get_graph_info()
            self.log_message("\nGraph built successfully:")
            self.log_message(f"  Total nodes  : {info['nodes']}")
            self.log_message(f"  Total edges  : {info['edges']}")
            self.log_message(f"  Total length : {info.get('total_length', 0):.2f}")
            self.log_message(f"  Connected    : {info['connected']}")
            if info['components'] > 1:
                self.log_message(
                    f"  WARNING: {info['components']} isolated network islands detected. "
                    f"Sizes: {info['component_sizes']}"
                )
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR building graph: {e!s}")

    def _make_metre_dist_func(self, layer):
        """Return an ``f((x,y),(x,y)) -> metres`` for *layer*'s CRS.

        Uses ``QgsDistanceArea`` configured with the layer CRS + the project
        ellipsoid so distances are real metres even for a geographic CRS
        (EPSG:4326).  Falls back to plain Euclidean if the layer/CRS is
        unavailable (correct only when the CRS is already projected metres).
        """
        try:
            crs = layer.crs() if layer else None
            if crs is None or not crs.isValid():
                return None
            da = QgsDistanceArea()
            da.setSourceCrs(crs, QgsProject.instance().transformContext())
            da.setEllipsoid(_safe_ellipsoid(QgsProject.instance(), crs))

            def _dist_m(a, b):
                return da.measureLine(
                    QgsPointXY(a[0], a[1]), QgsPointXY(b[0], b[1])
                )

            return _dist_m
        except Exception:
            return None

    def on_calculate_clicked(self):
        """Calculate shortest path between two points."""
        if not self.network_graph or self.network_graph.G.number_of_nodes() == 0:
            self.log_message("ERROR: Please build the network graph first.")
            return
        
        ducts_layer = self.comboBox_ducts.currentLayer()
        if not ducts_layer:
            self.log_message("ERROR: No ducts layer selected.")
            return
        
        # Use first and last node coordinates as example
        nodes = list(self.network_graph.G.nodes(data=True))
        if len(nodes) < 2:
            self.log_message("ERROR: Need at least 2 nodes for routing.")
            return
        
        source_coord = nodes[0][1]['coord']
        target_coord = nodes[-1][1]['coord']
        
        self.log_message("\nCalculating route...")
        self.log_message(f"  From: {source_coord}")
        self.log_message(f"  To: {target_coord}")
        self._start_timer()
        try:
            path_coords, total_length = self.network_graph.shortest_path_with_cost(
                source_coord, target_coord
            )
            self.log_message(f"  Route found with {len(path_coords)} vertices")
            self.log_message(f"  Total length : {total_length:.2f}")
            self.log_message(f"  Optical loss : {self._path_loss_db(path_coords):.3f} dB")

            # Create result layer
            self.create_result_layer(path_coords, total_length)
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR calculating route: {e!s}")

    def create_result_layer(self, path_coords, total_length):
        """Create a layer to display the routing result.
        
        Args:
            path_coords: List of (x, y) coordinate tuples
            total_length: Total path length
        """
        # Remove old result layer if exists
        if self.result_layer:
            QgsProject.instance().removeMapLayer(self.result_layer.id())
        
        # Get CRS from ducts layer
        ducts_layer = self.comboBox_ducts.currentLayer()
        crs = ducts_layer.crs().authid() if ducts_layer else "EPSG:4326"
        
        # Create new result layer
        self.result_layer = create_memory_layer("FTTH Route Result", "LineString", crs)
        
        # Add fields
        add_fields_to_layer(self.result_layer, [
            ('route_id', int, 'Integer'),
            ('length', float, 'Double'),
            ('num_points', int, 'Integer')
        ])
        self.result_layer.updateFields()
        
        # Add the route as a line feature
        attributes = {
            'route_id': 1,
            'length': total_length,
            'num_points': len(path_coords)
        }
        add_line_feature(self.result_layer, path_coords, attributes)
        
        # Update layer extent and add to map
        self.result_layer.updateExtents()
        QgsProject.instance().addMapLayer(self.result_layer)
        
        self.log_message("  Result layer added to map.")

    def _path_loss_db(self, path_coords: list) -> float:
        """Sum optical loss_db across graph edges that form *path_coords*.

        Walks consecutive coordinate pairs and looks up the edge in the graph.
        Coordinates are snapped via the graph's own precision before lookup.
        """
        if not self.network_graph:
            return 0.0
        ng = self.network_graph
        total = 0.0
        for raw_u, raw_v in zip(path_coords[:-1], path_coords[1:]):
            su = _snap_coord(raw_u, ng.snap_precision)
            sv = _snap_coord(raw_v, ng.snap_precision)
            nu = ng._coord_index.get(su)
            nv = ng._coord_index.get(sv)
            if nu and nv and ng.G.has_edge(nu, nv):
                total += ng.G.edges[nu, nv].get('loss_db', 0.0)
        return total

    def on_analyze_clicked(self):
        """Analyze selected layers and display statistics."""
        nodes_layer = self.comboBox_nodes.currentLayer()
        ducts_layer = self.comboBox_ducts.currentLayer()
        
        self.log_message("\n=== Layer Analysis ===")
        self._start_timer()
        if nodes_layer:
            self.log_message(f"\nNodes Layer: '{nodes_layer.name()}'")
            self.log_message(f"  Feature count: {nodes_layer.featureCount()}")
            self.log_message(f"  CRS: {nodes_layer.crs().authid()}")
            counts = count_features_by_geometry_type(nodes_layer)
            for geom_type, count in counts.items():
                if count > 0:
                    self.log_message(f"  {geom_type}: {count}")
            
            # List fields
            fields = nodes_layer.fields()
            field_names = [field.name() for field in fields]
            self.log_message(f"  Fields: {', '.join(field_names)}")
        
        if ducts_layer:
            self.log_message(f"\nDucts Layer: '{ducts_layer.name()}'")
            self.log_message(f"  Feature count: {ducts_layer.featureCount()}")
            self.log_message(f"  CRS: {ducts_layer.crs().authid()}")
            counts = count_features_by_geometry_type(ducts_layer)
            for geom_type, count in counts.items():
                if count > 0:
                    self.log_message(f"  {geom_type}: {count}")
            
            # List fields
            fields = ducts_layer.fields()
            field_names = [field.name() for field in fields]
            self.log_message(f"  Fields: {', '.join(field_names)}")
            
            # Calculate total length in metres using QgsDistanceArea (handles geographic/projected CRS)
            from qgis.core import QgsDistanceArea
            da = QgsDistanceArea()
            da.setSourceCrs(ducts_layer.crs(), QgsProject.instance().transformContext())
            da.setEllipsoid(_safe_ellipsoid(QgsProject.instance(), ducts_layer.crs()))
            total_length = 0
            for feature in get_layer_features(ducts_layer):
                geom = feature.geometry()
                if geom and not geom.isEmpty():
                    total_length += da.measureLength(geom)
            self.log_message(f"  Total length: {total_length:.2f} m")
        self._elapsed("Total time")

    def on_clear_clicked(self):
        """Clear output and remove result layer."""
        self.textEdit_output.clear()
        
        if self.result_layer:
            QgsProject.instance().removeMapLayer(self.result_layer.id())
            self.result_layer = None

    def _refresh_properties(self):
        """🔄 Re-scan the project and auto-detect the demand / route / road layers
        into the dropdowns — so newly added, renamed or reloaded layers are picked
        up without re-running AutoNet. Purely re-selects layers; changes no data."""
        try:
            from qgis.core import QgsProject, QgsMapLayer, QgsWkbTypes
            G = QgsWkbTypes.GeometryType
            vlayers = [lyr for lyr in QgsProject.instance().mapLayers().values()
                       if lyr.type() == QgsMapLayer.LayerType.VectorLayer]

            def pick(combo, keywords, geoms):
                if combo is None:
                    return None
                cands = [lyr for lyr in vlayers if lyr.geometryType() in geoms]
                for kw in keywords:
                    for lyr in cands:
                        if kw in lyr.name().lower():
                            combo.setLayer(lyr)
                            return lyr.name()
                return None

            picked = {
                "demand": pick(getattr(self, "comboBox_erf", None),
                               ("demand", "parcel", "erf", "erven", "building",
                                "stand", "subscriber", "home", "ont"),
                               (G.PolygonGeometry, G.PointGeometry)),
                "route": pick(getattr(self, "comboBox_span_layer", None),
                              ("span", "route", "fibre", "fiber", "cable", "duct",
                               "trunk", "backbone"), (G.LineGeometry,)),
                "road": pick(getattr(self, "comboBox_road_layer", None),
                             ("road", "street", "highway", "lane", "avenue"),
                             (G.LineGeometry,)),
            }
            hits = ", ".join(f"{k}={v}" for k, v in picked.items() if v) or "no matches"
            try:
                self.log_message(f"🔄 Layers refreshed — {hits}")
            except Exception:
                pass
            try:
                self.iface.messageBar().pushSuccess(
                    "Network Planner", f"Layers refreshed ({hits}).")
            except Exception:
                pass
        except Exception as e:
            try:
                self.log_message(f"Refresh failed: {e}")
            except Exception:
                pass

    def on_autonet_clicked(self, _zone_offset=0, _group_offset=0, _batch_label=None):
        """AutoNet: auto-detect layers and run the full PON pipeline in one click.
        Steps: 1. PON Groups  2. Demand Points  3. Group Boundaries
               4. Splitter Points  5. Drops PTP
        Shows a floating progress dialog with scrolling log and elapsed timer.

        _zone_offset / _group_offset / _batch_label — forwarded to Step 1 so that
        PON-per-PON runs produce globally sequential zone and group IDs.
        """
        from qgis.core import QgsProject, QgsVectorLayer

        # ── Create and show progress dialog ───────────────────────────
        dlg = AutoNetProgressDialog(self)
        dlg.show()
        QApplication.processEvents()

        # Helper: write to BOTH the dock log AND the popup dialog
        def _log(msg):
            self.log_message(msg)
            dlg.append_log(msg)

        def _autonet_progress(step, label):
            pct = int((step - 1) / 5 * 100)
            self._prog_bar.setValue(pct)
            self._prog_op_lbl.setText(f"AutoNet {step}/5: {label}")
            self._prog_strip.setVisible(True)
            dlg.set_step(step, f"Step {step}/5 — {label}")
            QApplication.processEvents()

        _log("\n══════════════════════════════════════════")
        _log("  ⚡ AutoNet — Full Pipeline Started")
        _log("══════════════════════════════════════════")
        self._prog_strip.setVisible(True)
        self._prog_bar.setValue(0)
        self._prog_op_lbl.setText("AutoNet — detecting layers…")
        dlg.set_step(0, "Detecting layers…")
        QApplication.processEvents()

        # ── Layer auto-detection ───────────────────────────────────────
        _excl_fragments = (
            'groups of', 'group of', 'demand points -', 'splitter point',
            'drop cable', 'drop_cable', 'pon zone', 'pon boundary',
            'zone boundary', 'group boundary', 'aggregation point',
            'feeder route', 'poles_', 'autonet', 'shortest', 'routing',
        )
        _generic_exact = {'aoi', 'extent', 'bbox', 'boundary', 'mask',
                          'study area', 'project area', 'area of interest',
                          'shortest path', 'shortest_path', 'routing result'}

        def _is_output_layer(name_lower):
            if name_lower in _generic_exact:
                return True
            return any(frag in name_lower for frag in _excl_fragments)

        def _find_layer(keywords, geom_type=None):
            for lyr in QgsProject.instance().mapLayers().values():
                if not isinstance(lyr, QgsVectorLayer):
                    continue
                if geom_type is not None and lyr.geometryType() != geom_type:
                    continue
                ln = lyr.name().lower()
                if _is_output_layer(ln):
                    continue
                if any(kw in ln for kw in keywords):
                    return lyr
            return None

        def _resolve_layer(combo, keywords, geom_type=None, fallback_geom=None):
            current = combo.currentLayer()
            # #5: in a PON-per-PON BATCH, trust the combo verbatim — the batch pipeline
            # deliberately set it to the polygon-filtered tmp copy (named like the
            # original). The _is_output_layer name check below could otherwise reject
            # that copy (e.g. an original named 'Demand Points - MOA' matches the
            # 'demand points -' fragment) and keyword-hunt a DIFFERENT full-project
            # layer — clustering the ENTIRE project instead of the selection.
            if _batch_label is not None and current and isinstance(current, QgsVectorLayer):
                return current
            if current and isinstance(current, QgsVectorLayer):
                if not _is_output_layer(current.name().lower()):
                    return current
            lyr = _find_layer(keywords, geom_type)
            if not lyr and fallback_geom is not None:
                lyr = _find_layer(keywords, fallback_geom)
            if not lyr:
                lyr = _find_layer(keywords)
            return lyr

        demand_kw = ('erf', 'parcel', 'stand', 'plot', 'property', 'premise',
                     'demand', 'subscriber', 'home', 'household')
        demand_lyr = _resolve_layer(self.comboBox_erf, demand_kw,
                                    geom_type=2, fallback_geom=0)

        span_kw = ('span', 'route', 'fibre', 'fiber', 'cable', 'duct',
                   'network', 'trunk', 'backbone')
        span_lyr = _resolve_layer(self.comboBox_span_layer, span_kw, geom_type=1)

        road_kw = ('road', 'street', 'highway', 'lane', 'avenue')
        road_lyr = _resolve_layer(self.comboBox_road_layer, road_kw, geom_type=1)

        # ── Validate ──────────────────────────────────────────────────
        if not demand_lyr:
            _log("ERROR: AutoNet could not identify a demand/parcel layer.")
            _log("  Please set the Demand Layer combo manually and retry.")
            self._prog_strip.setVisible(False)
            dlg.mark_error("No demand layer found")
            return
        if not span_lyr:
            _log("ERROR: AutoNet could not identify a span/route layer.")
            _log("  Please set the Route Layer combo manually and retry.")
            self._prog_strip.setVisible(False)
            dlg.mark_error("No span/route layer found")
            return
        if not road_lyr:
            _log("WARNING: No road layer found — road-crossing rule will be skipped.")

        # ── Apply combos ──────────────────────────────────────────────
        self.comboBox_erf.setLayer(demand_lyr)
        self.comboBox_span_layer.setLayer(span_lyr)
        if road_lyr:
            self.comboBox_road_layer.setLayer(road_lyr)

        for i in range(self.comboBox_clustering_method.count()):
            if 'tight' in self.comboBox_clustering_method.itemText(i).lower():
                self.comboBox_clustering_method.setCurrentIndex(i)
                break

        _log(f"  Demand layer : {demand_lyr.name()}")
        _log(f"  Route layer  : {span_lyr.name()}")
        _log(f"  Road layer   : {road_lyr.name() if road_lyr else '(none)'}")
        _log(f"  Method       : {self.comboBox_clustering_method.currentText()}")
        QApplication.processEvents()

        # INPUT GUARD: catch the "wrong layer" footgun BEFORE grouping. A run whose
        # Demand, Route and Road all point at the same layer — or a Route that isn't
        # lines, or a Demand that isn't points/erven — snaps splitters to the wrong
        # geometry (they float among poles, disconnected from homes). Fail LOUD with a
        # fix hint instead of silently building garbage. Correct runs (points demand +
        # line route, distinct layers) pass untouched.
        _gt_name = {0: 'points', 1: 'lines', 2: 'polygons'}
        _problems = []
        try:
            if demand_lyr.geometryType() not in (0, 2):
                _problems.append(
                    f"Demand layer '{demand_lyr.name()}' is {_gt_name.get(demand_lyr.geometryType(), '?')}, "
                    f"not homes/erven — pick the ONT/home points (or erven polygons).")
            if span_lyr.geometryType() != 1:
                _problems.append(
                    f"Route layer '{span_lyr.name()}' is {_gt_name.get(span_lyr.geometryType(), '?')}, "
                    f"not lines — splitters snap to it, so it must be the Distribution cable.")
            if span_lyr.id() == demand_lyr.id():
                _problems.append("Demand and Route are the SAME layer.")
            if road_lyr is not None and road_lyr.id() in (demand_lyr.id(), span_lyr.id()):
                _problems.append("Road is the same layer as Demand or Route.")
        except Exception:
            pass
        if _problems:
            _log("⛔ AutoNet aborted — the layer selection looks wrong:")
            for _p in _problems:
                _log("   • " + _p)
            _log("   Fix: Demand = homes/ONTs (points), Route = Distribution cable (lines), "
                 "Road = roads (lines) — three DIFFERENT layers. Then retry.")
            self._prog_strip.setVisible(False)
            dlg.mark_error("Bad layer selection — see log")
            return

        # Store batch label so steps 4 & 5 can name their output layers accordingly
        self._current_batch_label = _batch_label

        # ── Step 1: Generate PON Groups ───────────────────────────────
        _autonet_progress(1, "Generate PON Groups")
        _log("\n── Step 1/5: Generate PON Groups ──")
        self.on_cluster_erven_clicked(
            _zone_offset=_zone_offset,
            _group_offset=_group_offset,
            _batch_label=_batch_label,
        )
        QApplication.processEvents()

        # #4 fail-fast: if Step 1 produced no grouped layer (grouping failed for this
        # selection), abort instead of running Steps 2-5 against stale / project-wide
        # layers — that is how splitters ended up scattered off the selection polygon.
        if not getattr(self, 'grouped_layer', None):
            _log("⛔ AutoNet aborted: Step 1 produced no PON groups — check the demand "
                 "selection. Steps 2-5 skipped (nothing to build on).")
            self._prog_strip.setVisible(False)
            dlg.mark_error("Step 1 produced no groups")
            return

        # ── Step 2: Generate Demand Points ───────────────────────────
        _autonet_progress(2, "Generate Demand Points")
        _log("\n── Step 2/5: Generate Demand Points ──")
        self.on_generate_demand_points_clicked()
        QApplication.processEvents()

        # ── Step 3: Generate Group Boundaries ────────────────────────
        _autonet_progress(3, "Generate Group Boundaries")
        _log("\n── Step 3/5: Generate Group Boundaries ──")
        self.on_generate_boundaries_clicked()
        QApplication.processEvents()

        # ── Step 4: Generate Splitter Points ─────────────────────────
        _autonet_progress(4, "Generate Splitter Points")
        _log("\n── Step 4/5: Generate Splitter Points ──")
        self.on_generate_splitters_clicked()
        QApplication.processEvents()

        # ── Step 5: Generate Drops PTP ───────────────────────────────
        _autonet_progress(5, "Generate Drops PTP")
        _log("\n── Step 5/5: Generate Drops PTP ──")
        self.on_generate_drop_ptp_clicked()
        QApplication.processEvents()

        # ── Done ─────────────────────────────────────────────────────
        self._prog_bar.setValue(100)
        self._prog_op_lbl.setText("⚡ AutoNet Complete ✓")
        from qgis.PyQt.QtCore import QTimer as _QT2
        _gen = self._strip_gen
        _QT2.singleShot(4000, lambda: self._hide_prog_strip(_gen))
        _log("")
        _log("══════════════════════════════════════════")
        _log("  ⚡ AutoNet — Pipeline Complete ✓")
        _log("══════════════════════════════════════════")
        dlg.mark_complete(success=True)

    # ------------------------------------------------------------------
    # PON Tools (BETA) — beta-access gate + read-only Inspector + locked Renumber
    # ------------------------------------------------------------------
    def _pon_is_beta_user(self):
        """Renumber {Zone}s is OPEN TO EVERYONE now (JJ 2026-06-25) but stays BETA:
        the button keeps its ·BETA badge + warning banner, and Finalize still backs up
        first and is sandbox-guarded. (Was limited to PON_BETA_USERS.)"""
        return True

    def _on_pon_feature_locked(self):
        """Generic 'locked for the team' message for non-beta users."""
        from qgis.PyQt.QtWidgets import QMessageBox
        QMessageBox.information(
            self, "PON Tools — BETA",
            "🧪 These PON tools are in BETA and currently limited to testers.\n\n"
            "• You CAN use 🎯 PON per PON Manual to generate PONs now.\n"
            "• Renumber will open up to everyone once testing is done.")

    # ------------------------------------------------------------------
    # PON Renumber by feeder route (BETA) — sandbox-guarded, preview-first.
    # ------------------------------------------------------------------
    def _pon_project_is_sandbox(self):
        """GRADUATED (JJ 2026-07-03): Renumber is out of BETA and runs on ANY project.
        The sandbox-only restriction is lifted — the safety net is now the preview-first
        flow plus the automatic project backup taken before any write. Returns True so
        the guard call-sites allow the renumber to proceed on real projects too."""
        return True

    def _feeder_trunk_geoms(self, lyr):
        """Return ([geometries], capacity_field, capacity_value) for the FEEDER TRUNK:
        the highest-capacity class only (e.g. 144F), not every capacity mixed. A feeder
        layer typically carries 144F + 48F + 24F; only the 144F line is the continuous
        trunk to follow. Falls back to all features when no capacity field is found."""

        def cap_num(v):
            m = re.search(r"\d+", str(v) if v is not None else "")
            return int(m.group()) if m else None

        # prefer the categorized renderer's class field (what the legend groups by)
        field = None
        try:
            from qgis.core import QgsCategorizedSymbolRenderer
            r = lyr.renderer()
            if isinstance(r, QgsCategorizedSymbolRenderer):
                field = r.classAttribute()
        except Exception:
            field = None
        names = {f.name().lower(): f.name() for f in lyr.fields()}
        all_names = {f.name() for f in lyr.fields()}
        if not field or field not in all_names:
            field = None
            for cand in ("capacity", "cable_size", "cable", "size", "fibre",
                         "fiber", "cores", "core", "fibre_coun", "cap", "count"):
                if cand in names:
                    field = names[cand]
                    break
        if field:
            buckets = {}
            for ft in lyr.getFeatures():
                try:
                    n = cap_num(ft[field])
                except Exception:
                    n = None
                if n is not None:
                    buckets.setdefault(n, []).append(ft)
            if buckets:
                top = max(buckets.keys())  # highest capacity = the trunk
                geoms = [ft.geometry() for ft in buckets[top]
                         if ft.geometry() and not ft.geometry().isEmpty()]
                if geoms:
                    return geoms, field, top
        # fallback — no capacity field: use every feature
        geoms = [f.geometry() for f in lyr.getFeatures()
                 if f.geometry() and not f.geometry().isEmpty()]
        return geoms, None, None

    def _pon_renumber_fields(self):
        """Decide which field IS the PON across this project, ONCE (field names are
        consistent project-wide). Returns (pon_field, zone_field, zone_name_field,
        is_real_pon):
          • pon_no/pon present → that is the PON; zone_id is a SEPARATE parent zone to
            derive (is_real_pon=True). (finished HLD, e.g. Mohadin)
          • else zone_id/zone_no/zone → the zone polygon IS the PON; no separate zone
            (is_real_pon=False). (network-planner / sandbox, e.g. Matiko)
        group_id is deliberately ignored — those are splitters, not PONs."""
        from qgis.core import QgsProject, QgsVectorLayer
        have = {}
        for lyr in QgsProject.instance().mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
                continue
            for f in lyr.fields():
                k = f.name().lower()
                if k in ("pon_no", "pon", "zone_id", "zone_no", "zone", "zone_name") \
                        and k not in have:
                    have[k] = f.name()
        pon_field, is_real = None, False
        for k in ("pon_no", "pon"):
            if k in have:
                pon_field, is_real = have[k], True
                break
        if not pon_field:
            for k in ("zone_id", "zone_no", "zone"):
                if k in have:
                    pon_field = have[k]
                    break
        zone_field = None
        if is_real:
            for k in ("zone_id", "zone_no", "zone"):
                if k in have and have[k] != pon_field:
                    zone_field = have[k]
                    break
        return pon_field, zone_field, have.get("zone_name"), is_real

    def _pon_min_id(self):
        """Lowest existing PON-id value in the project (int), or None — used to default
        the 'first PON #' so a renumber preserves the project's numbering base."""
        from qgis.core import QgsProject, QgsVectorLayer
        pon_field, _zf, _znf, _ir = self._pon_renumber_fields()
        if not pon_field:
            return None
        pk = pon_field.lower()
        vals = []
        for lyr in QgsProject.instance().mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
                continue
            fn = {f.name().lower(): f.name() for f in lyr.fields()}
            if pk not in fn:
                continue
            for ft in lyr.getFeatures():
                try:
                    vals.append(int(float(ft[fn[pk]])))
                except Exception:
                    pass
            if vals:
                break
        return min(vals) if vals else None

    def _pon_term(self):
        """The word for the unit the planner works in. Always 'PON'.

        It used to return 'Zone' whenever the zone polygon WAS the PON — which is
        the common case in the Network Planner, so most people only ever saw the
        word "Zone". JJ 2026-07-23: "zones are actually PONs at the current
        moment, but they don't want to see it that way, and it confuses a lot of
        people." So there is one word now, and it is the correct one.

        UI ONLY. Verified before changing: every call site puts this into a button
        label, a dialog title or a message — none of it reaches an attribute
        write, so no stored data changes and no existing project is affected.
        """
        return "PON"

    def _open_pon_unit_counts(self):
        """Open the read-only unit-count list for every PON.

        Wrapped end-to-end: a broken layer in someone's project must not take
        the whole dock down, so any failure becomes a message, never a crash.
        """
        try:
            from qgis.core import QgsProject

            from .pon_merge_dialog import open_pon_list
            open_pon_list(QgsProject.instance(), parent=self,
                          term=self._pon_term())
        except Exception as exc:
            try:
                from qgis.PyQt.QtWidgets import QMessageBox
                QMessageBox.warning(self, "Unit counts",
                                    f"Could not open the unit counts:\n{exc}")
            except Exception:
                pass

    def _pon_zone_polys(self, pon_field):
        """{pon_id_str: QgsGeometry} of the zone/PON BOUNDARY polygons (the 'big
        blobs') so the animation can flash each one as the walker dives in."""
        from qgis.core import QgsProject, QgsVectorLayer
        out = {}
        pk = (pon_field or "").lower()
        best = None
        for lyr in QgsProject.instance().mapLayers().values():
            if (isinstance(lyr, QgsVectorLayer) and lyr.isValid()
                    and lyr.geometryType() == 2
                    and pk in {f.name().lower(): 1 for f in lyr.fields()}):
                nl = lyr.name().lower()
                if best is None or ("zone" in nl or "pon" in nl):
                    best = lyr
        if not best:
            return out
        fn = {f.name().lower(): f.name() for f in best.fields()}
        for ft in best.getFeatures():
            try:
                v = ft[fn[pk]]
            except Exception:
                v = None
            if v in (None, "") or str(v) in out:
                continue
            g = ft.geometry()
            if g and not g.isEmpty():
                out[str(v)] = QgsGeometry(g)
        return out

    def _pon_zone_distribution(self, zone_polys, feeder_geom):
        """For each zone, the REAL distribution cable to dive along: the cable inside the
        zone polygon whose end is nearest the feeder, oriented entry(near feeder)→into
        the zone. Returns {zone_id_str: [QgsPointXY,...]}. Spatial — needs no zone tag."""
        from qgis.core import (QgsProject, QgsVectorLayer, QgsSpatialIndex,
                               QgsGeometry, QgsPointXY)
        dls = [l for l in QgsProject.instance().mapLayers().values()
               if isinstance(l, QgsVectorLayer) and l.isValid()
               and l.geometryType() == 1 and "distribution" in l.name().lower()]
        if not dls:
            return {}
        dl = dls[0]
        feats = {}
        idx = QgsSpatialIndex()
        for ft in dl.getFeatures():
            g = ft.geometry()
            if g and not g.isEmpty():
                feats[ft.id()] = g
                idx.insertFeature(ft)

        def _line(g):
            if g.isMultipart():
                parts = g.asMultiPolyline()
                return max(parts, key=len) if parts else []
            return g.asPolyline()

        out = {}
        for z, poly in zone_polys.items():
            inside = [feats[fid] for fid in idx.intersects(poly.boundingBox())
                      if fid in feats and poly.intersects(feats[fid])]
            best, best_d = None, 1e18
            for g in inside:
                ln = _line(g)
                if len(ln) < 2:
                    continue
                d0 = feeder_geom.distance(QgsGeometry.fromPointXY(QgsPointXY(ln[0])))
                d1 = feeder_geom.distance(QgsGeometry.fromPointXY(QgsPointXY(ln[-1])))
                dmin = min(d0, d1)
                if dmin < best_d:
                    best_d = dmin
                    best = [QgsPointXY(p) for p in (ln if d0 <= d1 else list(reversed(ln)))]
            if best:
                out[str(z)] = best
        return out

    def _pon_anim_cleanup(self):
        """Stop + remove the running renumber animation (its own rubber bands + timer)."""
        a = getattr(self, "_pon_anim", None)
        if not a:
            return
        try:
            if a.get("timer"):
                a["timer"].stop()
        except Exception:
            pass
        for k in ("path", "walker", "dive"):
            try:
                if a.get(k):
                    a[k].reset()
            except Exception:
                pass
        self._pon_anim = None

    def _pon_clear_display(self):
        """Wipe everything the renumber drew: the walk overlays + the 'Renumber Flow'
        and 'PON Renumber Path' display layers. Touches no real data."""
        self._pon_anim_cleanup()
        try:
            from qgis.core import QgsProject, QgsVectorLayer
            for l in list(QgsProject.instance().mapLayers().values()):
                if isinstance(l, QgsVectorLayer) and (
                        l.name() == "PON Renumber Path"
                        or l.name().startswith("Renumber Flow")):
                    QgsProject.instance().removeMapLayer(l.id())
            self.iface.mapCanvas().refresh()
        except Exception:
            pass

    def _pon_animate_trace(self, feeder_layer, mapping, rep, term, start_spec=None,
                           on_done=None):
        """Animate the renumber walk like the HTML mockup: the marker flows FORWARD
        along the feeder from the start point, and at each zone (the first in line, then
        the next) dives along that zone's distribution cable into the blob, numbers it,
        and climbs back — monotonic, never running the whole feeder and back. Visual
        only. mapping = [(old, new, zone)] in feeder order, rep = {old: centroid}."""
        from qgis.PyQt.QtCore import QTimer, QMetaType
        from qgis.PyQt.QtGui import QColor
        from qgis.gui import QgsRubberBand
        from qgis.core import (QgsWkbTypes, QgsGeometry, QgsPointXY, QgsProject,
                               QgsVectorLayer, QgsField, QgsFeature,
                               QgsPalLayerSettings, QgsTextFormat,
                               QgsVectorLayerSimpleLabeling)
        canvas = self.iface.mapCanvas()
        self._pon_anim_cleanup()
        pon_field = self._pon_renumber_fields()[0]
        zpoly = self._pon_zone_polys(pon_field)
        # ── Build the WALK: flow along the feeder, then DIVE each zone's real
        # distribution cable into the blob, number it, climb back — feeder order. ──
        geoms, _cf, _cv = self._feeder_trunk_geoms(feeder_layer)
        fg = geoms[0] if geoms else None
        for g in (geoms[1:] if geoms else []):
            fg = fg.combine(g)
        try:
            mm = fg.mergeLines() if fg else None
            if mm and not mm.isEmpty():
                fg = mm
        except Exception:
            pass
        zone_dc = self._pon_zone_distribution(zpoly, fg) if fg else {}
        total = (fg.length() if fg else 0) or 1.0
        # Resolve the start position s0 + walk direction along the feeder, exactly like
        # the renumber order — so the walk is FORWARD from the start (rel distance),
        # never the raw geometry distance that wraps and runs to the end + back.
        s0, forward = 0.0, True
        try:
            mode, start_pt = (start_spec if isinstance(start_spec, (tuple, list))
                              else ("endA", None))
            if mode == "endB":
                s0, forward = total, False
            elif mode == "point" and start_pt is not None:
                from qgis.core import QgsCoordinateTransform
                p = QgsPointXY(start_pt)
                src = QgsProject.instance().crs()
                dst = feeder_layer.crs()
                if src.isValid() and dst.isValid() and src != dst:
                    p = QgsCoordinateTransform(src, dst, QgsProject.instance()).transform(p)
                s0 = fg.lineLocatePoint(QgsGeometry.fromPointXY(p)) if fg else 0.0
        except Exception:
            s0, forward = 0.0, True

        def _feeder_at(rel):
            dd = ((s0 + rel) if forward else (s0 - rel)) % total
            return QgsPointXY(fg.interpolate(dd).asPoint())

        WP = []   # (QgsPointXY, kind, new_pon, old)  kind ∈ feeder|dive|arrive
        prev_rel = 0.0   # start AT the start point and only ever move forward
        for old, new_pon, _z in mapping:
            cent = rep.get(str(old))
            if cent is None:
                continue
            try:
                d = fg.lineLocatePoint(QgsGeometry.fromPointXY(QgsPointXY(cent))) if fg else 0.0
            except Exception:
                d = 0.0
            rel = ((d - s0) if forward else (s0 - d)) % total   # forward dist from start
            # flow forward along the feeder from the previous zone's branch to this one
            seg = rel - prev_rel
            if seg < 0:          # safety: never walk backwards
                seg = 0
            nstep = max(1, int(seg / (total / 80.0)))
            for s in range(1, nstep + 1):
                try:
                    WP.append((_feeder_at(prev_rel + seg * s / nstep), "feeder", None, None))
                except Exception:
                    pass
            try:
                branch = _feeder_at(rel)
            except Exception:
                branch = QgsPointXY(cent)
            WP.append((branch, "feeder", None, None))
            # dive along the zone's real distribution cable (down-sampled for speed)
            dive = zone_dc.get(str(old)) or [QgsPointXY(cent)]
            if len(dive) > 6:
                stepf = len(dive) / 6.0
                dive = [dive[int(j * stepf)] for j in range(6)] + [dive[-1]]
            for p in dive:
                WP.append((QgsPointXY(p), "dive", None, None))
            WP.append((QgsPointXY(dive[-1]), "arrive", new_pon, str(old)))
            for p in reversed(dive[:-1]):
                WP.append((QgsPointXY(p), "dive", None, None))
            WP.append((branch, "feeder", None, None))
            prev_rel = rel

        feeder_trail = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.LineGeometry)
        feeder_trail.setColor(QColor(90, 200, 255))   # cyan: the feeder route, persisted
        feeder_trail.setWidth(3)
        dive_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.LineGeometry)
        dive_band.setColor(QColor(255, 255, 255))     # white: the CURRENT dive, transient
        dive_band.setWidth(2)
        walker = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PointGeometry)
        walker.setColor(QColor(255, 80, 0))
        try:
            walker.setIconSize(22)
            walker.setIcon(QgsRubberBand.ICON_CIRCLE)
        except Exception:
            pass
        crs = feeder_layer.crs().authid()
        flow = QgsVectorLayer(f"Point?crs={crs}", f"Renumber Flow ({term} order)", "memory")
        # claude:intent MUTATE — user asked to "watch it go ... flow on the feeder line and
        # go into the distribution". Plan: in-MEMORY display-only point layer that fills
        # with the new numbers as the walk arrives at each zone. No source data touched.
        flow.dataProvider().addAttributes([QgsField("n", QMetaType.Type.Int)])
        flow.updateFields()
        ls = QgsPalLayerSettings()
        ls.fieldName = "n"
        ls.enabled = True
        tf = QgsTextFormat()
        tf.setSize(13)
        tf.setColor(QColor(255, 255, 0))
        ls.setFormat(tf)
        flow.setLabeling(QgsVectorLayerSimpleLabeling(ls))
        flow.setLabelsEnabled(True)
        for lyr in list(QgsProject.instance().mapLayers().values()):
            if isinstance(lyr, QgsVectorLayer) and lyr.name().startswith("Renumber Flow"):
                QgsProject.instance().removeMapLayer(lyr.id())
        QgsProject.instance().addMapLayer(flow)

        # Slow + deliberate so the order can be double-checked: ~4 fps base glide, with a
        # PAUSE at each zone arrival so you can read every number as it drops.
        GLIDE = getattr(self, "_pon_anim_glide", 6)
        ARRIVE_PAUSE = 9   # frames the walker holds on each zone after numbering it
        timer = QTimer(self)   # parent to the DOCK so it dies on reload (no orphans)
        timer.setInterval(getattr(self, "_pon_anim_interval", 38))
        self._pon_anim = {"path": feeder_trail, "dive": dive_band, "walker": walker,
                          "flow": flow, "timer": timer, "zpoly": zpoly, "wp": WP,
                          "i": 0, "t": 0.0, "prev": None, "pause": 0}

        def _finish(a):
            a["timer"].stop()
            try:
                a["walker"].reset()
                a["dive"].reset()
            except Exception:
                pass
            if on_done:
                on_done()

        def _step():
            try:
                _step_inner()
            except Exception:
                # Never let the timer spam the Python-error banner — log once + stop.
                try:
                    import traceback
                    with open("C:/Temp/renumber_anim_err.log", "w", encoding="utf-8") as fh:
                        fh.write(traceback.format_exc())
                except Exception:
                    pass
                a = getattr(self, "_pon_anim", None)
                if a and a.get("timer"):
                    a["timer"].stop()
                self._pon_anim = None

        def _step_inner():
            a = self._pon_anim
            if not a:
                return
            WPl = a["wp"]
            if not WPl or a["i"] >= len(WPl):
                _finish(a)
                return
            if a["prev"] is None:
                a["prev"] = WPl[0][0]
                a["path"].addPoint(WPl[0][0])
                a["i"] = 1
                return
            # hold on the current zone so each number is readable
            if a["pause"] > 0:
                a["pause"] -= 1
                return
            i = a["i"]
            prev = a["prev"]
            target, kind, new_pon, old = WPl[i]
            a["t"] += 1.0 / GLIDE
            if a["t"] >= 1.0:
                wpos = target
                if kind == "feeder":
                    a["path"].addPoint(target)   # persist ONLY the feeder route (clean)
                    a["dive"].reset()            # clear the dive line back on the feeder
                elif kind == "dive":
                    a["dive"].addPoint(target)   # draw the current dive into the zone
                elif kind == "arrive":
                    a["dive"].addPoint(target)
                    fg_flash = a["zpoly"].get(old) or QgsGeometry.fromPointXY(target)
                    try:
                        canvas.flashGeometries([fg_flash], feeder_layer.crs())
                    except Exception:
                        pass
                    f = QgsFeature(a["flow"].fields())
                    f.setAttribute("n", new_pon)
                    f.setGeometry(QgsGeometry.fromPointXY(target))
                    a["flow"].dataProvider().addFeature(f)
                    a["flow"].triggerRepaint()
                    a["pause"] = ARRIVE_PAUSE   # hold so you can read the number
                a["prev"] = target
                a["i"] = i + 1
                a["t"] = 0.0
            else:
                k = a["t"]
                wpos = QgsPointXY(prev.x() + (target.x() - prev.x()) * k,
                                  prev.y() + (target.y() - prev.y()) * k)
            try:
                a["walker"].reset(QgsWkbTypes.GeometryType.PointGeometry)
                a["walker"].addPoint(wpos)
            except Exception:
                pass

        timer.timeout.connect(_step)
        timer.start()

    def _pon_renumber_collect(self, feeder_layer, start_spec, first_pon):
        """Compute the feeder-route order. start_spec = ('endA'|'endB'|'point', pt).
        Returns (mapping, rep_points, traced_ok).
        mapping = [(old_pon, new_pon, new_zone)] sorted by feeder distance then spur.
        traced_ok = False when the feeder couldn't be traced into a coherent route
        (disconnected segments / degenerate geom) → caller must NOT allow Apply.
        Pure read — no writes."""
        from qgis.core import QgsProject, QgsVectorLayer, QgsGeometry, QgsPointXY
        # Follow ONLY the highest-capacity line (the 144F trunk), not every capacity
        # class mixed together — mixing 144F/48F/24F gives "too many segments" and the
        # route can't be traced (JJ 2026-06-24). _feeder_trunk_geoms picks the top one.
        geoms, _capfield, cap_used = self._feeder_trunk_geoms(feeder_layer)
        if not geoms:
            return [], {}, False, None, {"reason": "no feeder geometry"}
        n_seg = len(geoms)
        feeder_geom = geoms[0]
        for g in geoms[1:]:
            feeder_geom = feeder_geom.combine(g)
        # Stitch connected segments into a proper route so lineLocatePoint measures
        # real along-feeder distance (combine() alone leaves an unordered multipart).
        try:
            merged = feeder_geom.mergeLines()
            if merged and not merged.isEmpty():
                feeder_geom = merged
        except Exception:
            pass
        total_len = feeder_geom.length() or 1.0
        # Resolve the start position (s0) along the feeder + the walk direction.
        # endA = route start, forward; endB = route end, walk backward; point =
        # the clicked location snapped onto the feeder, walk forward from there.
        mode, start_pt = (start_spec if isinstance(start_spec, (tuple, list))
                          else ("endA", None))
        forward = True
        s0 = 0.0
        if mode == "endB":
            s0, forward = total_len, False
        elif mode == "point" and start_pt is not None:
            try:
                from qgis.core import QgsCoordinateTransform
                p = QgsPointXY(start_pt)
                src = QgsProject.instance().crs()
                dst = feeder_layer.crs()
                if src.isValid() and dst.isValid() and src != dst:
                    p = QgsCoordinateTransform(src, dst, QgsProject.instance()).transform(p)
                s0 = feeder_geom.lineLocatePoint(QgsGeometry.fromPointXY(p))
            except Exception:
                s0 = 0.0
            forward = True
        # The PON identifier for THIS project: pon_no on a finished HLD; else zone_id —
        # here a "zone" polygon IS a PON (JJ #107). group_id = splitters, NEVER the PON.
        pon_field, zone_field, zone_name_field, is_real = self._pon_renumber_fields()
        if not pon_field:
            return [], {}, False, cap_used, {"reason": "no pon_no/zone field found"}
        pkey = pon_field.lower()
        rep = {}
        cand = []
        for lyr in QgsProject.instance().mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
                continue
            fn = {f.name().lower(): f.name() for f in lyr.fields()}
            if pkey not in fn:
                continue
            gt = lyr.geometryType()
            if gt not in (0, 2):   # point or polygon — one representative point per PON
                continue
            nl = lyr.name().lower()
            score = (4 if (gt == 2 and ("zone" in nl or "pon" in nl)) else  # PON polygon
                     3 if gt == 2 else
                     2 if "splitter" in nl else
                     1 if ("pon" in nl or "zone" in nl) else 0)
            cand.append((score, lyr, fn[pkey]))
        cand.sort(key=lambda t: t[0], reverse=True)
        for _score, lyr, pf in cand:
            for feat in lyr.getFeatures():
                try:
                    pon = feat[pf]
                except Exception:
                    pon = None
                if pon in (None, "") or str(pon).upper() == "NULL":
                    continue
                key = str(pon)
                if key in rep:
                    continue
                g = feat.geometry()
                if not g or g.isEmpty():
                    continue
                rep[key] = g.asPoint() if g.type() == 0 else g.centroid().asPoint()
            if rep:
                break
        order = []
        for pon, pt in rep.items():
            pg = QgsGeometry.fromPointXY(QgsPointXY(pt))
            try:
                d_along = feeder_geom.lineLocatePoint(pg)
            except Exception:
                d_along = 0.0
            spur = feeder_geom.distance(pg)
            # distance walked FROM the start, wrapping around the route so a start
            # placed mid-feeder numbers outward from there, then wraps to the rest.
            rel = ((d_along - s0) if forward else (s0 - d_along)) % total_len
            order.append((rel, spur, pon))
        order.sort(key=lambda t: (t[0], t[1]))
        # traced_ok: the route must spread the PONs along it. A degenerate combine of
        # disconnected segments (or a feeder the PONs don't run along) collapses every
        # distance to ~one position → refuse. Lenient (≥10%, min 3 distinct) so a real
        # feeder where PONs cluster at junctions is NOT false-refused.
        distinct = len({round(o[0], 6) for o in order})
        traced_ok = (total_len > 1e-9 and len(order) > 1
                     and distinct >= max(3, len(order) // 10))
        mapping = []
        for i, (_d, _s, pon) in enumerate(order):
            new_pon = first_pon + i
            # Derive a SEPARATE zone only when pon_no is the real id (zone is its parent).
            # When the PON *is* the zone (Matiko), there is no separate zone to derive.
            new_zone = ((new_pon - first_pon) // 16 + 17) if is_real else None
            mapping.append((pon, new_pon, new_zone))
        diag = {"pons": len(order), "segments": n_seg, "route_len": total_len,
                "distinct": distinct, "cap": cap_used,
                "pon_field": pon_field, "zone_field": zone_field,
                "zone_name_field": zone_name_field, "is_real": is_real,
                "reason": ("ok" if traced_ok else
                           ("no PONs found" if not order else
                            "feeder doesn't spread the PONs (segments/CRS?)"))}
        return mapping, rep, traced_ok, cap_used, diag

    def _pon_autowalk_order(self, zlyr, zfield, start=None):
        """READ-ONLY: compute the PON order by walking the cable hierarchy
        (144F -> 24F/48F link -> distribution dip -> zone). Returns
        (order_list, walk_pts_wgs84, pen_flags, message). `start` (optional
        [lon,lat] in WGS84) overrides the POP as the walk start point. Never
        raises out. The validated engine lives in network_planner/feeder_walk.py."""
        from qgis.core import (QgsProject, QgsVectorLayer, QgsGeometry,
                               QgsCoordinateReferenceSystem, QgsCoordinateTransform)
        try:
            from . import feeder_walk
        except Exception:
            try:
                import feeder_walk
            except Exception as e:
                return [], [], [], f"feeder_walk engine not found: {e}"
        try:
            proj = QgsProject.instance()
            wgs = QgsCoordinateReferenceSystem("EPSG:4326")

            def to_wgs(geom, src):
                if geom is None or geom.isEmpty():
                    return geom
                if src.isValid() and src != wgs:
                    g = QgsGeometry(geom)
                    g.transform(QgsCoordinateTransform(src, wgs, proj))
                    return g
                return geom

            def parts_line(lyr):
                out = []
                for ft in lyr.getFeatures():
                    g = to_wgs(ft.geometry(), lyr.crs())
                    if not g or g.isEmpty():
                        continue
                    ps = g.asMultiPolyline() if g.isMultipart() else (
                        [g.asPolyline()] if g.asPolyline() else [])
                    for part in ps:
                        if part:
                            out.append([[p.x(), p.y()] for p in part])
                return out

            feeder_lyr = dist_lyr = pop_lyr = None
            for l in proj.mapLayers().values():
                if not isinstance(l, QgsVectorLayer) or not l.isValid():
                    continue
                nm = l.name().lower()
                if l.geometryType() == 1 and "feeder" in nm and feeder_lyr is None:
                    feeder_lyr = l
                if l.geometryType() == 1 and "distribution" in nm and dist_lyr is None:
                    dist_lyr = l
                if l.geometryType() == 0 and "pop" in nm and pop_lyr is None:
                    pop_lyr = l
            if feeder_lyr is None:
                return [], [], [], ("No Feeder cable layer found (need a line layer "
                                    "named '…Feeder…').")
            sf = {f.name().lower(): f.name() for f in feeder_lyr.fields()}.get("size")
            feeder = []
            for ft in feeder_lyr.getFeatures():
                g = to_wgs(ft.geometry(), feeder_lyr.crs())
                if not g or g.isEmpty():
                    continue
                m = re.search(r"\d+", str(ft[sf]) if sf else "")
                sz = int(m.group()) if m else 0
                ps = g.asMultiPolyline() if g.isMultipart() else (
                    [g.asPolyline()] if g.asPolyline() else [])
                for part in ps:
                    if part:
                        feeder.append({'pts': [[p.x(), p.y()] for p in part], 'size': sz})
            dist = parts_line(dist_lyr) if dist_lyr else []
            zones = []
            for ft in zlyr.getFeatures():
                g = to_wgs(ft.geometry(), zlyr.crs())
                if not g or g.isEmpty():
                    continue
                rings = []
                if g.isMultipart():
                    for poly in g.asMultiPolygon():
                        if poly:
                            rings.append([[p.x(), p.y()] for p in poly[0]])
                else:
                    poly = g.asPolygon()
                    if poly:
                        rings.append([[p.x(), p.y()] for p in poly[0]])
                c = g.centroid().asPoint()
                zones.append({'id': str(ft[zfield]), 'rings': rings,
                              'c': [c.x(), c.y()]})
            pop = None
            if pop_lyr:
                for ft in pop_lyr.getFeatures():
                    g = to_wgs(ft.geometry(), pop_lyr.crs())
                    if g and not g.isEmpty():
                        pt = g.asPoint()
                        pop = [pt.x(), pt.y()]
                        break
            if start is not None and len(start) >= 2:
                pop = [float(start[0]), float(start[1])]
            elif pop is None and feeder:
                pop = feeder[0]['pts'][0]
            res = feeder_walk.compute(feeder, dist, zones, pop)
            order = res.get('order', [])
            walk = res.get('walk', [])
            pen = res.get('pen', [])
            if not order:
                return [], [], [], ("Auto-walk produced no order — check the Feeder has "
                                    "a Size field (144/48/24) and the cables connect.")
            where = "your chosen start point" if start is not None else "the POP"
            return order, walk, pen, (
                f"Auto-walk ordered {len(order)} of {len(zones)} zones, walking the feeder "
                f"hierarchy from {where}. Review, then Finalize.")
        except Exception as e:
            return [], [], [], f"Auto-walk failed: {e}"

    def _open_zone_renumber(self):
        """Manual renumber: click the zones on the canvas in the order you want them,
        adjust freely (re-click removes, Undo, Clear), then Finalize — which renumbers
        the zone id + label + every splitter/feature inside each zone, project-wide.
        Sandbox-guarded, backs up first. This is JJ's reliable click-zones flow."""
        import os as _os
        from qgis.PyQt.QtWidgets import (
            QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QSpinBox,
            QTableWidget, QTableWidgetItem, QMessageBox, QWidget, QFrame,
            QSizePolicy)
        from qgis.PyQt.QtCore import Qt, QMetaType, QRect, QPoint
        from qgis.PyQt.QtGui import (QColor, QPainter, QPen, QFont, QFontDatabase)
        from qgis.core import (QgsProject, QgsVectorLayer, QgsField, QgsFeature,
                               QgsGeometry, QgsPalLayerSettings, QgsTextFormat,
                               QgsVectorLayerSimpleLabeling)

        # Bundle the brand fonts (Chakra Petch display + JetBrains Mono data) so the
        # Cable-Rail dialog looks the same on every machine; harmless if missing.
        try:
            _fdir = _os.path.join(_os.path.dirname(__file__), "fonts")
            if not getattr(self, "_brand_fonts_loaded", False) and _os.path.isdir(_fdir):
                for _fn in _os.listdir(_fdir):
                    if _fn.lower().endswith((".ttf", ".otf")):
                        QFontDatabase.addApplicationFont(_os.path.join(_fdir, _fn))
                self._brand_fonts_loaded = True
        except Exception:
            pass

        class RailNode(QWidget):
            """The numbered cable-rail node: a cyan vertical line + a numbered circle
            (filled when 'done'). Drawn so consecutive nodes' lines join into one rail."""

            def __init__(self, label, done=False, first=False, last=False):
                super().__init__()
                self._label, self._done = label, done
                self._first, self._last = first, last
                self.setFixedWidth(34)
                self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)

            def paintEvent(self, _e):
                p = QPainter(self)
                p.setRenderHint(QPainter.RenderHint.Antialiasing)
                cx, cy, r = 17, 14, 10
                cyan = QColor("#22d3ee")
                pen = QPen(cyan)
                pen.setWidth(2)
                p.setPen(pen)
                top = (cy + r) if self._first else 0
                bot = cy if self._last else self.height()
                if bot > top:
                    p.drawLine(cx, top, cx, bot)
                if self._done:
                    p.setBrush(cyan)
                    p.setPen(QPen(cyan, 2))
                else:
                    p.setBrush(QColor("#11141a"))
                    p.setPen(QPen(cyan, 2))
                p.drawEllipse(QPoint(cx, cy), r, r)
                p.setPen(QColor("#062229") if self._done else cyan)
                _f = QFont("JetBrains Mono")
                _f.setPointSize(8)
                _f.setBold(True)
                p.setFont(_f)
                p.drawText(QRect(cx - r, cy - r, 2 * r, 2 * r),
                           int(Qt.AlignmentFlag.AlignCenter), self._label)

        if not self._pon_project_is_sandbox():
            QMessageBox.warning(
                self, "Renumber Zones — BETA",
                "🔒 Renumber only runs on a SANDBOX / TEST project, to protect permanent "
                "data. Open a sandbox copy to renumber.")
            return
        term = self._pon_term()
        pon_field, zone_field, zone_name_field, is_real = self._pon_renumber_fields()
        # label_mode = (prefix, pad) when the PON lives in a TEXT label instead of
        # a numeric field (projects not built by the Network Planner, e.g. HeroTel
        # Malmesbury "Malmesbury Pon 07").  Then Renumber still works: click the PON
        # polygons in order and it rewrites the label + any '_SP<n>' references.
        label_mode = None
        if not pon_field:
            lm = self._pon_label_layer()
            if lm is None:
                QMessageBox.warning(
                    self, f"Renumber {term}s",
                    "No PON/Zone to renumber — need either a pon_no/zone field, or "
                    "a polygon layer whose label looks like 'Name 07'.")
                return
            zlyr, zfield, _pre, _pad = lm
            label_mode = (_pre, _pad)
            pon_field = zfield
            term = "PON"
        else:
            pkey = pon_field.lower()
            zlyr = None
            for l in QgsProject.instance().mapLayers().values():
                if (isinstance(l, QgsVectorLayer) and l.isValid()
                        and l.geometryType() == 2
                        and pkey in {f.name().lower(): 1 for f in l.fields()}):
                    nl = l.name().lower()
                    if zlyr is None or ("zone" in nl or "pon" in nl):
                        zlyr = l
            if zlyr is None:
                QMessageBox.warning(self, f"Renumber {term}s",
                                    f"No {term} polygon layer found to click.")
                return
            zfield = {f.name().lower(): f.name() for f in zlyr.fields()}[pkey]

        dlg = QDialog(self)
        dlg.setWindowTitle(f"Renumber {term}s")
        dlg.resize(412, 720)
        dlg.setMinimumWidth(404)
        dlg.setStyleSheet("""
            QDialog { background:#171b21; }
            QLabel { color:#e8ecf1; font-size:12px; }
            QFrame#head { background:#0e1116; border-bottom:1px solid #2a313b; }
            QLabel#title { color:#e8ecf1; font-family:'Chakra Petch','Segoe UI';
                           font-size:16px; font-weight:bold; }
            QLabel#pill { background:#f5b53d; color:#1a1400; border-radius:9px;
                          padding:2px 9px; font-family:'JetBrains Mono','Consolas';
                          font-weight:bold; font-size:10px; }
            QLabel#warnband { background:#0e2233; color:#7fb2e5; border:1px solid #2f5f88;
                              border-left:3px solid #2f5f88; border-radius:7px;
                              padding:9px 11px; }
            QLabel#cap { color:#22d3ee; font-family:'JetBrains Mono','Consolas';
                         font-size:10px; font-weight:bold; letter-spacing:1px; }
            QFrame#hero { border-radius:9px; background:qlineargradient(x1:0,y1:0,x2:1,y2:1,
                          stop:0 #67e8f9, stop:0.5 #22d3ee, stop:1 #0e9bb8); }
            QLabel#heroTitle { color:#062229; font-family:'Chakra Petch','Segoe UI';
                               font-size:15px; font-weight:bold; background:transparent; }
            QLabel#heroSub { color:#063340; font-size:11px; background:transparent; }
            QLabel#play { background:#06303a; color:#67e8f9; border-radius:13px;
                          min-width:26px; max-width:26px; min-height:26px; max-height:26px;
                          font-size:12px; }
            QLabel#runline { background:#0d1217; border:1px solid #2a313b; border-radius:7px;
                             padding:7px 10px; font-family:'JetBrains Mono','Consolas';
                             font-size:11px; color:#9aa4b2; }
            QLabel#ordiv { color:#5f6b78; font-family:'JetBrains Mono','Consolas'; font-size:10px; }
            QPushButton { background:#2f353e; color:#e8ecf1; border:1px solid #3a414c;
                          border-radius:8px; padding:9px 12px; font-size:12px; text-align:left; }
            QPushButton:hover { border-color:#0e7490; }
            QPushButton:pressed { background:#222831; }
            QPushButton:checked { background:#0e7490; border-color:#22d3ee; color:#ffffff;
                                  font-weight:bold; }
            QPushButton#ghost { background:transparent; border:1px solid #3a414c;
                                color:#9aa4b2; text-align:center; padding:8px; }
            QPushButton#ghost:hover { border-color:#0e7490; color:#e8ecf1; }
            QPushButton#ghost:checked { background:#0e7490; border-color:#22d3ee;
                                        color:#ffffff; font-weight:bold; }
            QPushButton#apply { background:qlineargradient(x1:0,y1:0,x2:1,y2:0,
                                stop:0 #56d364, stop:1 #2ea043); color:#06210f; border:none;
                                border-radius:8px; text-align:center; font-weight:bold;
                                font-family:'Chakra Petch','Segoe UI'; font-size:14px; padding:12px; }
            QPushButton#apply:hover { background:qlineargradient(x1:0,y1:0,x2:1,y2:0,
                                      stop:0 #4bc759, stop:1 #279339); }
            QTableWidget { background:#11141a; color:#9aa4b2; border:1px solid #3a414c;
                           border-radius:8px; gridline-color:#20262e;
                           font-family:'JetBrains Mono','Consolas'; }
            QHeaderView::section { background:#0d1015; color:#6b7480; border:none;
                                   padding:6px; font-family:'JetBrains Mono','Consolas';
                                   font-weight:bold; }
            QSpinBox { background:#0e1116; color:#e8ecf1; border:1px solid #3a414c;
                       border-radius:7px; padding:5px 6px; font-family:'JetBrains Mono','Consolas';
                       font-size:14px; font-weight:bold; }
            QSpinBox::up-button, QSpinBox::down-button { width:18px; background:#1b2026; border:none; }
        """)
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        # in-dialog dark header (title + BETA pill)
        head = QFrame()
        head.setObjectName("head")
        hh = QHBoxLayout(head)
        hh.setContentsMargins(14, 11, 14, 11)
        _title = QLabel(f"Renumber {term}s")
        _title.setObjectName("title")
        hh.addWidget(_title)
        hh.addStretch(1)
        lay.addWidget(head)
        # sandbox warning band
        _warnWrap = QWidget()
        _wwl = QVBoxLayout(_warnWrap)
        _wwl.setContentsMargins(14, 12, 14, 2)
        warn = QLabel(
            f"ℹ️ Finalize renumbers every {term} and all its splitters / contents in the "
            f"order you set. It previews first, so nothing changes until you confirm. Use "
            f"the 💾 Backup button first if you want a safety copy.")
        warn.setObjectName("warnband")
        warn.setWordWrap(True)
        _wwl.addWidget(warn)
        lay.addWidget(_warnWrap)

        # start-number setting (applies to BOTH ordering methods)
        first_spin = QSpinBox()
        first_spin.setRange(1, 99999)
        _minid = self._pon_min_id()
        first_spin.setValue(_minid if _minid is not None else 1)
        numrow = QHBoxLayout()
        numrow.addWidget(QLabel(f"Start numbering the first {term} at:"))
        numrow.addWidget(first_spin)
        numrow.addStretch(1)

        # manual ordering toggle (one of the two methods)
        pick_btn = QPushButton(f"✋  Click the {term}s myself — in order")
        pick_btn.setCheckable(True)
        # (controls are assembled into the stepped layout at the end)

        table = QTableWidget(0, 2)
        table.setHorizontalHeaderLabels([f"old {term}", f"new {term}"])
        table.horizontalHeader().setStretchLastSection(True)

        state = {"order": [], "full": []}
        crs = zlyr.crs().authid()
        for old in list(QgsProject.instance().mapLayers().values()):
            if isinstance(old, QgsVectorLayer) and old.name() == "Renumber Picks":
                QgsProject.instance().removeMapLayer(old.id())
        picks = QgsVectorLayer(f"Point?crs={crs}", "Renumber Picks", "memory")
        # claude:intent MUTATE — user asked for a click-zones renumber that shows the new
        # numbers as you click. Plan: an in-MEMORY display-only point layer labelled with
        # the new number at each picked zone. No source/project data touched here.
        picks.dataProvider().addAttributes([QgsField("n", QMetaType.Type.Int)])
        picks.updateFields()
        _ls = QgsPalLayerSettings()
        _ls.fieldName = "n"
        _ls.enabled = True
        # KEEP the real PON labels; drop the pick number JUST BELOW the point so
        # both stay readable (screen-space quadrant = same gap at any zoom).
        try:
            _ls.placement = QgsPalLayerSettings.Placement.OverPoint
            _ls.quadOffset = QgsPalLayerSettings.QuadrantPosition.QuadrantBelow
            _ls.dist = 3.0
        except Exception:
            pass
        _tf = QgsTextFormat()
        _tf.setSize(12)
        _tf.setColor(QColor(255, 255, 0))
        try:                                    # dark halo so it reads over the label
            from qgis.core import QgsTextBufferSettings
            _buf = QgsTextBufferSettings()
            _buf.setEnabled(True)
            _buf.setSize(1.0)
            _buf.setColor(QColor(0, 0, 0))
            _tf.setBuffer(_buf)
        except Exception:
            pass
        _ls.setFormat(_tf)
        picks.setLabeling(QgsVectorLayerSimpleLabeling(_ls))
        picks.setLabelsEnabled(True)
        QgsProject.instance().addMapLayer(picks)
        cent = {}
        for f in zlyr.getFeatures():
            g = f.geometry()
            if g and not g.isEmpty():
                # pointOnSurface (not centroid) is GUARANTEED inside the polygon —
                # a concave PON's centroid can land in a NEIGHBOUR, putting the pick
                # number in the wrong PON.  This keeps every pick in its own PON.
                cent[str(f[zfield])] = g.pointOnSurface().asPoint()

        def refresh():
            from qgis.PyQt import sip as _sip
            # #109: a click can fire refresh after the dialog / picks layer were
            # destroyed (dialog closed, plugin reloaded, or the user removed the
            # "Renumber Picks" layer). Touching a deleted C/C++ object raises
            # RuntimeError — bail safely instead of crashing.
            for _o in (dlg, picks, table, first_spin):
                if _sip.isdeleted(_o):
                    return
            if QgsProject.instance().mapLayer(picks.id()) is None:
                return
            try:
                base = first_spin.value()
                table.setRowCount(0)
                for i, old in enumerate(state["order"]):
                    r = table.rowCount()
                    table.insertRow(r)
                    table.setItem(r, 0, QTableWidgetItem(str(old)))
                    table.setItem(r, 1, QTableWidgetItem(str(base + i)))
                ids = [f.id() for f in picks.getFeatures()]
                if ids:
                    # claude:intent MUTATE — user asked: "look at the two Plastic Relay
                    # tickets ... fix them" (#109 RuntimeError in refresh). Plan: guard
                    # refresh against deleted C/C++ objects. This deleteFeatures only
                    # clears the in-MEMORY "Renumber Picks" DISPLAY layer (no source /
                    # project data); it is rebuilt from state["order"] right below.
                    # claude:approved-destructive
                    picks.dataProvider().deleteFeatures(ids)
                feats = []
                for i, old in enumerate(state["order"]):
                    c = cent.get(str(old))
                    if c:
                        ft = QgsFeature(picks.fields())
                        ft.setAttribute("n", base + i)
                        ft.setGeometry(QgsGeometry.fromPointXY(c))
                        feats.append(ft)
                if feats:
                    picks.dataProvider().addFeatures(feats)
                picks.triggerRepaint()
                self.iface.mapCanvas().refresh()
            except RuntimeError:
                return
            except Exception:
                pass

        def on_zone(zid):
            zid = str(zid)
            if zid in state["order"]:
                state["order"].remove(zid)
            else:
                state["order"].append(zid)
            refresh()

        tool = ZonePickTool(self.iface.mapCanvas(), zlyr, zfield)
        tool.zone_clicked.connect(on_zone)
        self._zr_tool = tool

        def toggle_pick(on):
            canvas = self.iface.mapCanvas()
            if on:
                self._zr_prev_tool = canvas.mapTool()
                canvas.setMapTool(tool)
                pick_btn.setText(f"✋  Picking… click {term}s on the map in order")
            else:
                # revert by UNSETTING our tool (safe) rather than re-activating a stored
                # tool that may have been deleted — that crashed Qt6.
                try:
                    from qgis.PyQt import sip as _sip
                    if not _sip.isdeleted(tool):
                        canvas.unsetMapTool(tool)
                    prev = getattr(self, "_zr_prev_tool", None)
                    if prev is not None and not _sip.isdeleted(prev):
                        canvas.setMapTool(prev)
                except Exception:
                    pass
                pick_btn.setText(f"✋  Click the {term}s myself — in order")
        pick_btn.toggled.connect(toggle_pick)
        first_spin.valueChanged.connect(lambda _v: refresh())

        def _undo():
            if state["order"]:
                state["order"].pop()
                refresh()

        def _clear():
            state["order"] = []
            refresh()

        def _finalize():
            if not state["order"]:
                QMessageBox.information(dlg, "Nothing to do",
                                        f"Click some {term}s on the map first.")
                return
            if not self._pon_project_is_sandbox():
                QMessageBox.warning(dlg, "Blocked", "Project is not a sandbox — aborted.")
                return
            base = first_spin.value()
            # ── VALIDATION ── check the resulting numbering before writing.
            #   • DUPLICATES  -> hard block (never write a clash)
            #   • GAPS        -> warn (a missing number in the run)
            #   • UNSELECTED  -> warn (you didn't click one/some PONs, so they
            #                    keep their old number)
            # A subset-renumber is the usual cause: clicked PONs get new numbers
            # while un-clicked ones keep their old numbers.
            import re as _re
            from collections import Counter as _Counter

            def _as_num(v):
                mm = _re.search(r"\d+", str(v))
                return int(mm.group()) if mm else None
            clicked_new = {str(o): base + i
                           for i, o in enumerate(state["order"])}
            zone_vals = [str(_f[zfield]) for _f in zlyr.getFeatures()]
            result = []
            for _cur in zone_vals:
                result.append(clicked_new[_cur] if _cur in clicked_new
                              else _as_num(_cur))
            result = [r for r in result if r is not None]
            # DUPLICATES → hard block
            _dups = sorted({v for v, k in _Counter(result).items() if k > 1})
            if _dups:
                QMessageBox.warning(
                    dlg, f"Duplicate {term}s — blocked",
                    f"This would create DUPLICATE {term} number(s): "
                    f"{', '.join(str(d) for d in _dups)}.\n\nEvery {term} must be "
                    f"unique.  Click ALL the {term}s in the order you want (so "
                    f"none keep an old number that clashes), then Finalize.\n\n"
                    f"Nothing was written.")
                return
            # GAPS + UNSELECTED → warn (embedded in the finalize confirm)
            _notes = []
            _unclicked = [v for v in zone_vals if v not in clicked_new]
            if _unclicked:
                _un = sorted({_as_num(v) for v in _unclicked
                              if _as_num(v) is not None})
                _notes.append(
                    "• You didn't click %d %s(s) — they keep their old number: %s"
                    % (len(_unclicked), term, ", ".join(str(u) for u in _un)))
            if result:
                _lo, _hi = min(result), max(result)
                _present = set(result)
                _gaps = [n for n in range(_lo, _hi + 1) if n not in _present]
                if _gaps:
                    _notes.append("• Gap(s) — these %s numbers would be missing: %s"
                                  % (term, ", ".join(str(g) for g in _gaps)))
            _warn = ("\n\n⚠  HEADS UP:\n" + "\n".join(_notes)) if _notes else ""
            if QMessageBox.question(
                    dlg, "Finalize renumber?",
                    f"Renumber {len(state['order'])} {term}(s) — and every splitter / "
                    f"feature that references them — on this project?" + _warn +
                    "\n\nTip: use the 💾 Backup button first if you want a safety "
                    "copy.\n\nProceed?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                    ) != QMessageBox.StandardButton.Yes:
                return
            if label_mode is not None:
                ok, msg = self._pon_renumber_apply_label(
                    state["order"], base, zlyr, zfield,
                    label_mode[0], label_mode[1])
            else:
                mapping = {str(old): (base + i, None)
                           for i, old in enumerate(state["order"])}
                ok, msg = self._pon_renumber_apply(
                    mapping, pon_field, zone_field, zone_name_field, is_real)
            (QMessageBox.information if ok else QMessageBox.warning)(
                dlg, "Renumber " + ("done" if ok else "failed"), msg)
            if ok:
                dlg.accept()


        ub = QPushButton("↶  Undo")
        ub.setObjectName("ghost")
        ub.clicked.connect(_undo)
        cb = QPushButton("🧹  Clear")
        cb.setObjectName("ghost")
        cb.clicked.connect(_clear)
        fb = QPushButton("✓  Finalize  ·  renumber everything")
        fb.setObjectName("apply")
        fb.clicked.connect(_finalize)
        closeb = QPushButton("Close")
        closeb.setObjectName("ghost")
        closeb.clicked.connect(dlg.reject)

        # ── assemble the Cable Rail: a numbered cable on the left, content on the right ──
        TU = term.upper()
        bodyWrap = QWidget()
        bodyV = QVBoxLayout(bodyWrap)
        bodyV.setContentsMargins(14, 6, 16, 8)
        bodyV.setSpacing(0)

        def _content(items):
            w = QWidget()
            v = QVBoxLayout(w)
            v.setContentsMargins(0, 0, 0, 0)
            v.setSpacing(7)
            for it in items:
                if isinstance(it, (QHBoxLayout, QVBoxLayout)):
                    v.addLayout(it)
                else:
                    v.addWidget(it)
            return w

        def _railstep(label, cap, content, first=False, last=False, done=False):
            row = QWidget()
            h = QHBoxLayout(row)
            h.setContentsMargins(0, 0, 0, 0)
            h.setSpacing(9)
            h.addWidget(RailNode(label, done=done, first=first, last=last))
            col = QWidget()
            cv = QVBoxLayout(col)
            cv.setContentsMargins(0, 10, 0, 14)
            cv.setSpacing(7)
            _cap = QLabel(cap)
            _cap.setObjectName("cap")
            cv.addWidget(_cap)
            cv.addWidget(content)
            h.addWidget(col, 1)
            bodyV.addWidget(row)

        table.setMinimumHeight(116)
        table.setMaximumHeight(210)
        _editrow = QHBoxLayout()
        _editrow.setSpacing(7)
        for _b in (ub, cb):
            _editrow.addWidget(_b)

        _railstep("1", f"FIRST {TU} GETS NUMBER", _content([numrow]),
                  first=True, done=True)
        _railstep("2", f"ORDER THE {TU}S",
                  _content([pick_btn]))
        _railstep("3", "PREVIEW  ·  OLD → NEW", _content([table]))
        _railstep("✓", f"APPLY TO EVERY {TU}", _content([fb, _editrow]), last=True)

        lay.addWidget(bodyWrap)
        _closeWrap = QWidget()
        _cwl = QVBoxLayout(_closeWrap)
        _cwl.setContentsMargins(16, 0, 16, 14)
        _cwl.addWidget(closeb)
        lay.addWidget(_closeWrap)

        def _on_close(_r):
            try:
                from qgis.PyQt import sip as _sip
                if pick_btn.isChecked():
                    pick_btn.setChecked(False)
                canvas = self.iface.mapCanvas()
                # Unset OUR tool so the canvas safely reverts — NEVER re-activate a stored
                # tool that may have been deleted (re-activating a dangling map tool
                # crashed Qt6 with an access violation). sip-guard everything.
                for _t in (getattr(self, "_zr_tool", None),):
                    if _t is not None and not _sip.isdeleted(_t):
                        try:
                            canvas.unsetMapTool(_t)
                        except Exception:
                            pass
                prev = getattr(self, "_zr_prev_tool", None)
                if prev is not None and not _sip.isdeleted(prev):
                    try:
                        canvas.setMapTool(prev)
                    except Exception:
                        pass
                self._zr_tool = None
                self._zr_prev_tool = None
            except Exception:
                pass
        dlg.finished.connect(_on_close)
        dlg.setModal(False)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, False)
        self._zone_renum_dlg = dlg
        # Do NOT auto-start pick mode — the user explicitly chooses Auto-walk or
        # click-myself in Step 2, so the dialog opens in a neutral, un-confusing state.
        dlg.show()
        dlg.raise_()

    def _open_pon_renumber(self):
        """Feeder-route renumber (graduated 2026-07-03: any project, preview-first, no
        forced backup — use the 💾 Backup button). Renumbers pon_no + zone field across
        every layer that carries pon_no, in the order you walk the feeder."""
        from qgis.PyQt.QtWidgets import (
            QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox,
            QSpinBox, QTableWidget, QTableWidgetItem, QMessageBox)
        from qgis.core import QgsProject, QgsVectorLayer

        if not self._pon_project_is_sandbox():
            QMessageBox.warning(
                self, "Renumber PONs — BETA",
                "🔒 Renumber only runs on a SANDBOX / TEST project, to protect permanent "
                "data.\n\nThis project's name/path has no 'sandbox' or 'test', so it is "
                "treated as permanent and blocked. Open a sandbox copy to test renumbering.")
            return

        term = self._pon_term()   # 'Zone' here (zone polygon IS the PON) or 'PON'
        proj = QgsProject.instance()
        line_layers = [l for l in proj.mapLayers().values()
                       if isinstance(l, QgsVectorLayer) and l.isValid()
                       and l.geometryType() == 1]
        if not line_layers:
            QMessageBox.warning(self, f"Renumber {term}s",
                                "No line layers found — need a Feeder cable layer.")
            return

        dlg = QDialog(self)
        dlg.setWindowTitle(f"Renumber {term}s by feeder route")
        dlg.resize(560, 520)
        lay = QVBoxLayout(dlg)
        warn = QLabel(f"ℹ️ Previews first. Walks the feeder and renumbers every {term} in "
                      f"feeder-route order across all its layers. ▶ Trace order to watch it.")
        warn.setWordWrap(True)
        warn.setStyleSheet("background:#0e2233;color:#7fb2e5;border:1px solid #2f5f88;"
                           "border-radius:4px;padding:6px;")
        lay.addWidget(warn)

        row = QHBoxLayout()
        row.addWidget(QLabel("Feeder layer:"))
        feeder_cmb = QComboBox()
        for l in line_layers:
            feeder_cmb.addItem(l.name(), l.id())
        for i, l in enumerate(line_layers):
            if "feeder" in l.name().lower():
                feeder_cmb.setCurrentIndex(i)
                break
        row.addWidget(feeder_cmb, 1)
        lay.addLayout(row)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Start from:"))
        start_cmb = QComboBox()
        start_cmb.addItem("Feeder end A (route start)", "endA")
        start_cmb.addItem("Feeder end B (route end)", "endB")
        row2.addWidget(start_cmb, 1)
        row2.addWidget(QLabel(f"First {term} #:"))
        first_spin = QSpinBox()
        first_spin.setRange(1, 99999)
        # Default to the project's current lowest PON id so a renumber keeps the same base
        # (sandbox is usually 1-based; a finished HLD is 235-based).
        _minid = self._pon_min_id()
        first_spin.setValue(_minid if _minid is not None else 235)
        row2.addWidget(first_spin)
        row2.addWidget(QLabel("Speed:"))
        speed_cmb = QComboBox()
        # (label, glide-frames, interval-ms) — bigger = slower
        for lbl, gl, iv in (("🐢 Slow", 12, 55), ("Normal", 6, 38), ("⚡ Fast", 3, 20)):
            speed_cmb.addItem(lbl, (gl, iv))
        speed_cmb.setCurrentIndex(0)   # default Slow so the order can be double-checked
        self._pon_anim_glide, self._pon_anim_interval = 12, 55

        def _on_speed(_i):
            gl, iv = speed_cmb.currentData()
            self._pon_anim_glide, self._pon_anim_interval = gl, iv
            a = getattr(self, "_pon_anim", None)
            if a and a.get("timer"):
                a["timer"].setInterval(iv)
        speed_cmb.currentIndexChanged.connect(_on_speed)
        row2.addWidget(speed_cmb)
        lay.addLayout(row2)

        # Place-a-start-point-on-the-map row (Luke #107: needs to click a start point).
        row3 = QHBoxLayout()
        pick_btn = QPushButton("📍 Pick start point on map")
        start_lbl = QLabel("start: Feeder end A")
        start_lbl.setStyleSheet("color:#22d3ee;")
        row3.addWidget(pick_btn)
        row3.addWidget(start_lbl, 1)
        lay.addLayout(row3)

        table = QTableWidget(0, 2)
        table.setHorizontalHeaderLabels([f"old {term}", f"new {term}"])
        table.horizontalHeader().setStretchLastSection(True)
        lay.addWidget(table, 1)

        # start = ('endA'|'endB'|'point', QgsPointXY|None). Dropdown sets end A/B;
        # the Pick button sets a clicked point on the feeder.
        state = {"mapping": None, "start": ("endA", None)}

        def _on_start_cmb(_i):
            state["start"] = (start_cmb.currentData(), None)
            start_lbl.setText("start: " + start_cmb.currentText())
            _preview(quiet=True)   # auto-refresh the table so it's never empty
        start_cmb.currentIndexChanged.connect(_on_start_cmb)

        def _pick_start():
            from qgis.gui import QgsMapToolEmitPoint
            from qgis.core import (QgsProject, QgsSnappingConfig, QgsTolerance,
                                   QgsPointXY, QgsGeometry)
            canvas = self.iface.mapCanvas()
            self._renum_prev_tool = canvas.mapTool()
            # Turn on QGIS snapping (vertex + segment, all layers) so the click snaps
            # exactly onto the feeder line — and save the user's config to restore it.
            try:
                self._renum_prev_snap = QgsSnappingConfig(QgsProject.instance().snappingConfig())
                cfg = QgsProject.instance().snappingConfig()
                cfg.setEnabled(True)
                try:
                    cfg.setMode(QgsSnappingConfig.SnappingMode.AllLayers)
                    cfg.setTypeFlag(QgsSnappingConfig.SnappingTypes.VertexFlag
                                    | QgsSnappingConfig.SnappingTypes.SegmentFlag)
                except Exception:
                    pass
                cfg.setTolerance(16)
                try:
                    cfg.setUnits(QgsTolerance.UnitType.Pixels)
                except Exception:
                    pass
                QgsProject.instance().setSnappingConfig(cfg)
            except Exception:
                self._renum_prev_snap = None

            def _clicked(pt, _btn=None):
                # The dialog (and its labels) may have been closed/reloaded while this
                # pick tool is still armed — touching a deleted QLabel here crashes
                # (#108). Bail safely if anything we need is gone.
                from qgis.PyQt import sip as _sip
                if _sip.isdeleted(dlg) or _sip.isdeleted(start_lbl):
                    try:
                        canvas.setMapTool(self._renum_prev_tool)
                    except Exception:
                        pass
                    try:
                        if getattr(self, "_renum_prev_snap", None) is not None:
                            QgsProject.instance().setSnappingConfig(self._renum_prev_snap)
                    except Exception:
                        pass
                    self._renum_tool = None
                    return
                snapped = QgsPointXY(pt)
                # 1) QGIS snapping indicator → exact vertex/edge on a layer
                try:
                    mm = canvas.snappingUtils().snapToMap(QgsPointXY(pt))
                    if mm.isValid():
                        snapped = mm.point()
                except Exception:
                    pass
                # 2) guarantee it lands ON the feeder line — project onto the trunk
                try:
                    flyr = proj.mapLayer(feeder_cmb.currentData())
                    tg, _c, _v = self._feeder_trunk_geoms(flyr)
                    fg2 = tg[0] if tg else None
                    for g in (tg[1:] if tg else []):
                        fg2 = fg2.combine(g)
                    if fg2:
                        np = fg2.nearestPoint(QgsGeometry.fromPointXY(snapped))
                        if np and not np.isEmpty():
                            snapped = np.asPoint()
                except Exception:
                    pass
                state["start"] = ("point", snapped)
                start_lbl.setText(f"start: 📍 ({snapped.x():.5f}, {snapped.y():.5f})")
                # restore the user's snapping config
                try:
                    if getattr(self, "_renum_prev_snap", None) is not None:
                        QgsProject.instance().setSnappingConfig(self._renum_prev_snap)
                except Exception:
                    pass
                try:
                    canvas.setMapTool(self._renum_prev_tool)
                except Exception:
                    pass
                self._renum_tool = None
                try:
                    self.iface.messageBar().clearWidgets()
                except Exception:
                    pass
                dlg.showNormal()
                dlg.raise_()
                dlg.activateWindow()
                _preview(quiet=True)   # auto-refresh the table for the new start point

            tool = QgsMapToolEmitPoint(canvas)
            tool.canvasClicked.connect(_clicked)
            self._renum_tool = tool
            canvas.setMapTool(tool)
            dlg.showMinimized()
            try:
                self.iface.messageBar().pushMessage(
                    "Renumber", "Click your START point on the feeder line "
                    "(the dialog is minimised — it returns after you click).",
                    level=Qgis.MessageLevel.Info, duration=0)
            except Exception:
                pass
        pick_btn.clicked.connect(_pick_start)

        def _preview(quiet=False):
            lyr = proj.mapLayer(feeder_cmb.currentData())
            if not lyr:
                return
            mapping, rep, traced_ok, cap_used, diag = self._pon_renumber_collect(
                lyr, state["start"], first_spin.value())
            # Never hard-block on a sandbox — show the order, let the user judge it. The
            # backup + sandbox guard + preview table are the safety net; refusing outright
            # just leaves the user stuck (Luke #107).
            state["mapping"] = mapping or None
            state["rep"] = rep
            state["traced_ok"] = traced_ok
            state["fields"] = (diag.get("pon_field"), diag.get("zone_field"),
                               diag.get("zone_name_field"), diag.get("is_real"))
            # On an explicit Trace (not the silent auto-refresh), play the HTML-style
            # walk: a marker walks the feeder, dives each zone blob, numbers it in order.
            if not quiet and mapping:
                self._pon_animate_trace(lyr, mapping, rep, term, state["start"])
            table.setRowCount(0)
            for old_pon, new_pon, _new_zone in mapping:
                r = table.rowCount()
                table.insertRow(r)
                table.setItem(r, 0, QTableWidgetItem(str(old_pon)))
                table.setItem(r, 1, QTableWidgetItem(str(new_pon)))
            self._pon_draw_renumber_path(lyr)
            cap_txt = f"{cap_used}F trunk" if cap_used else "feeder (no capacity field)"
            diag_txt = (f"feeder: {cap_txt} · {diag.get('segments')} segment(s) · "
                        f"{diag.get('pons')} PONs · {diag.get('distinct')} distinct positions")
            if not mapping:
                apply_btn.setEnabled(False)
                if not quiet:
                    QMessageBox.warning(dlg, "Nothing to renumber",
                                        f"No PONs found to order.\n\n{diag_txt}")
                return
            changed = sum(1 for o, n, _z in mapping if str(o) != str(n))
            apply_btn.setEnabled(True)
            if not traced_ok:
                if not quiet:
                    QMessageBox.warning(
                        dlg, "Preview — check the order!",
                        f"⚠ The feeder didn't trace cleanly, so this order MAY be wrong — "
                        f"please eyeball the table + the 'PON Renumber Path' layer before "
                        f"applying.\n\n{diag_txt}\n\nApply is still allowed (you're on a sandbox "
                        f"and a backup is written first). If the order looks wrong, try the "
                        f"other feeder layer or a different start point.")
            elif not quiet:
                QMessageBox.information(
                    dlg, "Preview",
                    f"{len(mapping)} PONs ordered · following {cap_txt} · {changed} would "
                    f"change number.\nDrew 'PON Renumber Path' (the cables it follows).\n\n"
                    f"{diag_txt}\n\nReview the table, then Apply (a backup is made first).")

        def _apply():
            if not state["mapping"]:
                return
            if not self._pon_project_is_sandbox():
                QMessageBox.warning(dlg, "Blocked", "Project is not a sandbox — aborted.")
                return
            changed = [(o, n, z) for o, n, z in state["mapping"] if str(o) != str(n)]
            if not changed:
                QMessageBox.information(dlg, "Nothing to do",
                                        "Every PON already has its feeder-route number.")
                return
            if QMessageBox.question(
                    dlg, "Apply renumber?",
                    f"Renumber {len(changed)} PON(s) across all PON layers on this project?\n\n"
                    "Tip: use the 💾 Backup button first if you want a safety copy.",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                    ) != QMessageBox.StandardButton.Yes:
                return
            pf, zf, znf, isr = state.get("fields", (None, None, None, False))
            ok, msg = self._pon_renumber_apply(
                dict((str(o), (n, z)) for o, n, z in state["mapping"]), pf, zf, znf, isr)
            (QMessageBox.information if ok else QMessageBox.warning)(
                dlg, "Renumber " + ("done" if ok else "failed"), msg)
            if ok:
                dlg.accept()

        btns = QHBoxLayout()
        prev_btn = QPushButton("▶ Trace order (watch it)")
        prev_btn.clicked.connect(_preview)
        btns.addWidget(prev_btn)
        apply_btn = QPushButton("✓ Apply renumber")
        apply_btn.setEnabled(False)
        apply_btn.clicked.connect(_apply)
        btns.addWidget(apply_btn)
        clear_btn = QPushButton("🧹 Clear")
        clear_btn.setToolTip("Remove the walk overlays + the 'Renumber Flow' / "
                             "'PON Renumber Path' layers from the canvas.")
        clear_btn.clicked.connect(self._pon_clear_display)
        btns.addWidget(clear_btn)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(dlg.reject)
        btns.addWidget(close_btn)
        lay.addLayout(btns)
        # Changing the first PON # re-orders too — keep the table live.
        first_spin.valueChanged.connect(lambda _v: _preview(quiet=True))
        # Non-modal so the user can click a start point on the canvas (#107). Hold a
        # reference so it isn't garbage-collected the moment this method returns.
        dlg.setModal(False)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, False)
        # Clean up the walk overlays (rubber bands) when the dialog closes, so they can
        # never orphan on the canvas (JJ: "where can I delete these white lines").
        def _on_renum_close(_r):
            # stop the walk overlays AND disarm the start-pick map tool, so a late
            # canvas click can't touch the now-closed dialog (#108).
            self._pon_anim_cleanup()
            try:
                if getattr(self, "_renum_tool", None) is not None:
                    self.iface.mapCanvas().setMapTool(
                        getattr(self, "_renum_prev_tool", None) or self.iface.mapCanvas().mapTool())
                    self._renum_tool = None
            except Exception:
                pass
        dlg.finished.connect(_on_renum_close)
        self._pon_renum_dlg = dlg
        # Auto-preview on open so the table is NEVER empty and Apply is ready when the
        # order looks right — no hidden "click Preview first" step (JJ #107 confusion).
        _preview(quiet=True)
        dlg.show()
        dlg.raise_()

    def _pon_draw_renumber_path(self, feeder_layer):
        """Draw a 'PON Renumber Path' layer = a copy of the feeder (+distribution)
        cable geometry, so it FOLLOWS the cables exactly (no diagonal short-cuts)."""
        from qgis.core import QgsProject, QgsVectorLayer, QgsFeature
        try:
            crs = feeder_layer.crs().authid()
            for l in list(QgsProject.instance().mapLayers().values()):
                if isinstance(l, QgsVectorLayer) and l.name() == "PON Renumber Path":
                    QgsProject.instance().removeMapLayer(l.id())
            path = QgsVectorLayer(f"LineString?crs={crs}", "PON Renumber Path", "memory")
            feats = []
            # ONLY the feeder trunk (highest-capacity line) — the clean route the walk
            # follows. NOT the distribution cables (those radiate from the POP and make
            # a scrambled spiderweb). JJ #107.
            trunk_geoms, _cf, _cv = self._feeder_trunk_geoms(feeder_layer)
            for g in trunk_geoms:
                nf = QgsFeature()
                nf.setGeometry(g)
                feats.append(nf)
            # claude:intent MUTATE — user asked: "make sure the line that follows the
            # feeder is also visually available in qgis" + "this is all scrambled".
            # Plan: write an in-MEMORY display-only line layer holding ONLY the feeder
            # trunk geometry (clean route reference). No project/source data touched.
            path.dataProvider().addFeatures(feats)
            path.updateExtents()
            try:
                path.renderer().symbol().setColor(QColor(34, 211, 238))
                path.renderer().symbol().setWidth(0.8)
            except Exception:
                pass
            QgsProject.instance().addMapLayer(path)
        except Exception:
            pass

    def _pon_label_layer(self):
        """(layer, label_field, prefix, pad) for a POLYGON layer whose label reads
        like '<prefix><number>' — e.g. Malmesbury 'Pons.Label.' = 'Malmesbury Pon 07'.
        This is how Renumber Zones works on projects that were NOT built by the
        Network Planner (no numeric pon_no/zone_id field — the PON lives in a text
        label).  None when there is no such label-based PON.  Prefers a layer named
        like a pon/zone."""
        from qgis.core import QgsProject, QgsVectorLayer
        numre = re.compile(r"(\d+)\s*$")
        best, best_score = None, 0
        for lyr in QgsProject.instance().mapLayers().values():
            if (not isinstance(lyr, QgsVectorLayer) or not lyr.isValid()
                    or lyr.geometryType() != 2):
                continue
            nl = lyr.name().lower()
            for f in lyr.fields():
                fn = f.name()
                prefixes, widths, hits, n = {}, {}, 0, 0
                for ft in lyr.getFeatures():
                    v = ft[fn]
                    if isinstance(v, str):
                        m = numre.search(v)
                        if m:
                            hits += 1
                            pre = v[:m.start(1)]
                            prefixes[pre] = prefixes.get(pre, 0) + 1
                            widths[len(m.group(1))] = widths.get(len(m.group(1)), 0) + 1
                    n += 1
                    if n >= 400:
                        break
                if hits < 2 or not prefixes:
                    continue
                prefix = max(prefixes, key=prefixes.get)
                if not prefix.strip():           # pure numbers — that's the numeric path
                    continue
                score = hits
                if "pon" in prefix.lower():
                    score += 1000
                if "pon" in nl or "zone" in nl:
                    score += 500
                if score > best_score:
                    pad = max(widths, key=widths.get)
                    best, best_score = (lyr, fn, prefix, pad), score
        return best

    # ------------------------------------------------------------------
    # Renumber backup — re-instated 2026-07-15 (JJ: "fix it")
    # ------------------------------------------------------------------
    # The auto-backup was removed 2026-07-03, which left _pon_restore_zone_backup()
    # reading a _renumber_backup/ folder that NOTHING wrote any more — a restore
    # button that could never restore, and a renumber that rewrote labels across
    # every layer with no way back. A renumber can undo days of work; the write is
    # now gated on a snapshot succeeding.
    def _pon_snapshot_to_gpkg(self, lyr, path, layer_name):
        """Copy `lyr` to a GPKG carrying an explicit `_vf_fid` = the LIVE feature id.

        Why not just write the layer straight out: GPKG assigns its own `fid`
        starting at 1, while a shapefile's feature ids start at 0. A restore that
        matched on the GPKG `fid` would therefore write every feature's attributes
        onto the NEXT feature — verified 2026-07-15 on `feeder`: 8/8 wrong, shifted
        by one. So the live id is stored as a real column and matched on explicitly.
        Returns (ok, msg).
        """
        # claude:intent MUTATE FiberNetworkAutomation/network_planner/dock_widget.py
        #   The addFeatures() below writes ONLY to a throwaway in-process `memory`
        #   layer used to stage the snapshot; the live layer is read-only here.
        #   This is the BACKUP path — it exists to protect data, not change it.
        #   approved-destructive
        from qgis.PyQt.QtCore import QMetaType
        from qgis.core import (QgsCoordinateTransformContext, QgsFeature,
                               QgsField, QgsVectorFileWriter, QgsVectorLayer,
                               QgsWkbTypes)
        crs = lyr.crs().authid() or lyr.crs().toWkt()
        gt = QgsWkbTypes.displayString(lyr.wkbType())
        mem = QgsVectorLayer(f"{gt}?crs={crs}", layer_name, "memory")
        if not mem.isValid():
            return False, f"could not build a snapshot layer ({gt} / {crs})"
        mdp = mem.dataProvider()
        src_fields = list(lyr.fields())
        if not mdp.addAttributes(
                src_fields + [QgsField("_vf_fid", QMetaType.Type.LongLong)]):
            return False, "could not add the snapshot fields"
        mem.updateFields()
        feats = []
        for f in lyr.getFeatures():
            nf = QgsFeature(mem.fields())
            nf.setAttributes(list(f.attributes()) + [int(f.id())])
            nf.setGeometry(f.geometry())
            feats.append(nf)
        if feats and not mdp.addFeatures(feats):
            return False, "could not fill the snapshot"
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = "GPKG"
        opts.layerName = layer_name
        try:
            res = QgsVectorFileWriter.writeAsVectorFormatV3(
                mem, path, QgsCoordinateTransformContext(), opts)
        except Exception as e:
            return False, str(e)
        if int(res[0]) != 0:                    # 0 == NoError (version-safe)
            return False, str(res[1] if len(res) > 1 else res[0])
        return True, ""

    def _pon_write_renumber_backup(self, layers):
        """Snapshot every layer a renumber is about to touch → (ok, dest_or_msg).

        Writes _renumber_backup/<ts>/<safe>.gpkg + manifest.json — exactly the
        layout _pon_restore_zone_backup() reads. Callers MUST abort on ok=False:
        no backup, no write.
        """
        import json as _json
        import os
        from datetime import datetime
        from qgis.core import QgsProject
        proj = QgsProject.instance()
        proj_dir = os.path.dirname(proj.fileName() or "")
        if not proj_dir or not os.path.isdir(proj_dir):
            return False, ("the project has not been saved to disk, so there is "
                           "nowhere to put the backup — save the project first")
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        dest = os.path.join(proj_dir, "_renumber_backup", ts)
        try:
            os.makedirs(dest, exist_ok=True)
        except OSError as e:
            return False, f"could not create the backup folder: {e}"
        name_map = {}
        for lyr in layers:
            safe = "".join(c if c.isalnum() else "_" for c in lyr.name())
            ok, msg = self._pon_snapshot_to_gpkg(
                lyr, os.path.join(dest, safe + ".gpkg"), safe)
            if not ok:
                return False, f"backing up '{lyr.name()}' failed: {msg}"
            name_map[safe] = lyr.name()
        if not name_map:
            return False, "there was nothing to back up"
        try:
            with open(os.path.join(dest, "manifest.json"), "w",
                      encoding="utf-8") as fh:
                _json.dump({"layers": name_map, "when": ts}, fh, indent=1)
        except OSError as e:
            return False, f"could not write the backup manifest: {e}"
        return True, dest

    def _pon_renumber_apply_label(self, order, base, layer, label_field,
                                  prefix, pad):
        """Renumber a LABEL-based PON ('Malmesbury Pon 07') in click order, AND
        cascade every OTHER layer that references the PON as an '_SP<n>' token
        (Feeder Joints, Dome Joints).  order = clicked label strings; new number =
        base + click-index.  Never raises out → (ok, message)."""
        from qgis.core import QgsProject, QgsVectorLayer
        try:
            numre = re.compile(r"(\d+)\s*$")
            sp_re = re.compile(r"SP(\d+)", re.I)
            proj = QgsProject.instance()
            idx = layer.fields().indexOf(label_field)
            if idx < 0:
                return False, "Label field not found."
            # remap {old_pon_num: new_pon_num} from the click order
            remap = {}
            old_label_to_new = {}
            for i, old_label in enumerate(order):
                m = numre.search(str(old_label))
                if not m:
                    continue
                old_num = int(m.group(1))
                new_num = base + i
                remap[old_num] = new_num
                old_label_to_new[str(old_label)] = prefix + str(new_num).zfill(pad)
            # every PON number in the project (to spot _SP-linked fields)
            all_pon = set()
            for f in layer.getFeatures():
                m = numre.search(str(f[label_field] or ""))
                if m:
                    all_pon.add(int(m.group(1)))

            def _remap_sp(text):
                def repl(mm):
                    old = int(mm.group(1))
                    if old in remap:
                        head = mm.group(0)[:len(mm.group(0)) - len(mm.group(1))]
                        return head + str(remap[old]).zfill(len(mm.group(1)))
                    return mm.group(0)
                return sp_re.sub(repl, text)

            # claude:intent MUTATE — user asked (verbatim): "make it so that the
            # network planners re-number ... work for anything" + "it should also
            # ... renumber [PON references in other layers] as well". Plan: rewrite
            # the PON label in click order, then remap the _SP<n> token in every
            # linked layer. Preview-first, and now BACKUP-GATED (2026-07-15).
            # claude:approved-destructive
            #
            # Computed in full BEFORE anything is written, so the backup can cover
            # every layer we are about to touch (the cascade discovers its targets)
            # and so a failure part-way cannot leave a half-renumbered project.
            # Output-neutral: each layer's changes depend only on `remap`, never on
            # another layer's write.

            # 1) work out the PON label changes
            changes = {}
            for f in layer.getFeatures():
                lab = f[label_field]
                if (isinstance(lab, str) and lab in old_label_to_new
                        and old_label_to_new[lab] != lab):
                    changes[f.id()] = {idx: old_label_to_new[lab]}

            # 2) work out the _SP<n> cascade for every OTHER layer whose SP tokens
            #    are PON-range
            pending = []                         # [(layer, field_name, lchg)]
            for lyr in proj.mapLayers().values():
                if (not isinstance(lyr, QgsVectorLayer) or not lyr.isValid()
                        or lyr.id() == layer.id()):
                    continue
                for fld in lyr.fields().names():
                    fidx = lyr.fields().indexOf(fld)
                    hits = inr = n = 0
                    for ft in lyr.getFeatures():
                        v = ft[fld]
                        if isinstance(v, str):
                            for mm in sp_re.finditer(v):
                                hits += 1
                                if int(mm.group(1)) in all_pon:
                                    inr += 1
                        n += 1
                        if n >= 300:
                            break
                    if hits < 3 or inr < hits * 0.5:
                        continue
                    lchg = {}
                    for ft in lyr.getFeatures():
                        old = ft[fld]
                        if isinstance(old, str):
                            new = _remap_sp(old)
                            if new != old:
                                lchg[ft.id()] = {fidx: new}
                    if lchg:
                        pending.append((lyr, fld, lchg))
                    break                       # one field per layer is enough

            # 3) BACKUP OR ABORT — everything we are about to touch
            touch = ([layer] if changes else []) + [l for l, _f, _c in pending]
            if touch:
                ok, dest = self._pon_write_renumber_backup(touch)
                if not ok:
                    return False, ("Nothing was renumbered — the backup failed, so "
                                   "the write was not attempted: %s" % dest)

            # 4) WRITE
            total = 0
            if changes:
                layer.dataProvider().changeAttributeValues(changes)
                layer.triggerRepaint()
                total = len(changes)
            casc, casc_layers = 0, []
            for lyr, fld, lchg in pending:
                lyr.dataProvider().changeAttributeValues(lchg)
                lyr.triggerRepaint()
                casc += len(lchg)
                casc_layers.append("%s.%s" % (lyr.name(), fld))
            try:
                self.iface.mapCanvas().refreshAllLayers()
            except Exception:
                pass
            msg = "Renumbered %d PON label(s)" % total
            if casc:
                msg += " + %d linked _SP label(s) (%s)" % (casc,
                                                           ", ".join(casc_layers))
            return True, msg + "."
        except Exception as e:
            return False, "Renumber failed: %s" % e

    def _pon_renumber_apply(self, mapping, pon_field, zone_field, zone_name_field, is_real):
        """Backup → renumber the PON id (pon_field = pon_no or zone_id) + its parent zone
        + the zone label across every layer that carries the PON id → (ok, message).
        mapping = {old_pon_str: (new_pon, new_zone_or_None)}. SANDBOX-guarded by the
        caller. Never raises out.

        The backup is a hard gate (re-instated 2026-07-15): if the snapshot cannot be
        written, nothing is renumbered. Undo it with `↩ Undo last Renumber`."""
        from qgis.core import (QgsProject, QgsVectorLayer)
        try:
            proj = QgsProject.instance()
            pkey = (pon_field or "").lower()
            zkey = (zone_field or "").lower()
            znkey = (zone_name_field or "").lower()
            if not pkey:
                return False, "No PON id field to renumber."
            # affected = every layer carrying the PON id (its zone + zone label ride along)
            affected = []
            for lyr in proj.mapLayers().values():
                if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
                    continue
                fn = {f.name().lower(): f.name() for f in lyr.fields()}
                if pkey in fn:
                    affected.append((lyr, fn))
            if not affected:
                return False, "No PON layers found to renumber."
            # BACKUP OR ABORT (re-instated 2026-07-15). A renumber rewrites labels
            # across every layer carrying the PON — days of work ride on it.
            ok, dest = self._pon_write_renumber_backup([l for l, _fn in affected])
            if not ok:
                return False, (f"Nothing was renumbered — the backup failed, so the "
                               f"write was not attempted: {dest}")
            # WRITE per layer (bulk, type-preserving). Remap keyed on the PON id.
            def _typed(layer, idx, val):
                tn = layer.fields()[idx].typeName().lower()
                return str(val) if tn in ("string", "text") else val
            total = 0
            for lyr, fn in affected:
                flds = lyr.fields()
                p_idx = flds.indexOf(fn[pkey])
                z_idx = flds.indexOf(fn[zkey]) if (zkey and zkey in fn) else -1
                zn_idx = flds.indexOf(fn[znkey]) if (znkey and znkey in fn) else -1
                changes = {}
                for feat in lyr.getFeatures():
                    try:
                        cur = feat[flds[p_idx].name()]
                    except Exception:
                        continue
                    if cur in (None, ""):
                        continue
                    m = mapping.get(str(cur))
                    if not m:
                        continue
                    new_pon, new_zone = m
                    # label number follows the zone (which equals the pon when pon IS zone)
                    label_num = new_zone if (is_real and new_zone is not None) else new_pon
                    fld = {p_idx: _typed(lyr, p_idx, new_pon)}
                    if z_idx >= 0:
                        zval = new_zone if (is_real and new_zone is not None) else new_pon
                        fld[z_idx] = _typed(lyr, z_idx, zval)
                    if zn_idx >= 0:
                        cur_zn = feat[flds[zn_idx].name()]
                        if cur_zn not in (None, "") and re.search(r"\d", str(cur_zn)):
                            fld[zn_idx] = re.sub(r"\d+", str(label_num), str(cur_zn), count=1)
                        else:
                            fld[zn_idx] = vf_pon_name(label_num)
                    changes[feat.id()] = fld
                if changes:
                    # claude:intent MUTATE — user asked to renumber PONs/zones in feeder
                    # order (and, 2026-07-03, to drop the forced auto-backup + sandbox
                    # limit so it runs on any project). Plan: remap the PON id (pon_no or
                    # zone_id) + parent zone + zone label in feeder order; preview-gated;
                    # bulk changeAttributeValues. Backup is now the user's 💾 button.
                    lyr.dataProvider().changeAttributeValues(changes)
                    lyr.triggerRepaint()
                    total += len(changes)
            try:
                self.iface.mapCanvas().refreshAllLayers()
            except Exception:
                pass
            return True, (f"Renumbered {total} feature(s) across {len(affected)} layer(s) "
                          f"by feeder route.")
        except Exception as e:
            return False, (f"Renumber failed: {e}")

    def _pon_restore_zone_backup(self):
        """Full UNDO: roll every layer back to the MOST RECENT renumber backup.
        Matches by fid so every attribute reverts exactly. Sandbox-guarded, confirms
        first, never raises out. This is the safety net JJ asked for — if a renumber
        ever breaks real work, one click gets it back."""
        import os, json as _json
        from qgis.PyQt.QtWidgets import QMessageBox
        from qgis.core import QgsProject, QgsVectorLayer
        try:
            if not self._pon_project_is_sandbox():
                QMessageBox.warning(self, "Restore",
                                    "Restore only runs on a SANDBOX/test project.")
                return
            proj = QgsProject.instance()
            proj_dir = os.path.dirname(proj.fileName() or "") or os.path.expanduser("~")
            root = os.path.join(proj_dir, "_renumber_backup")
            if not os.path.isdir(root):
                QMessageBox.information(self, "Restore", "No renumber backups found yet.")
                return
            subs = sorted([d for d in os.listdir(root)
                           if os.path.isdir(os.path.join(root, d))], reverse=True)
            if not subs:
                QMessageBox.information(self, "Restore", "No renumber backups found yet.")
                return
            latest = os.path.join(root, subs[0])
            name_map = {}
            mpath = os.path.join(latest, "manifest.json")
            if os.path.exists(mpath):
                try:
                    name_map = _json.load(open(mpath, encoding="utf-8")).get("layers", {})
                except Exception:
                    name_map = {}
            gpkgs = [f for f in os.listdir(latest) if f.lower().endswith(".gpkg")]
            if not gpkgs:
                QMessageBox.information(self, "Restore", "Backup folder has no layers.")
                return
            if QMessageBox.question(
                    self, "Restore last renumber?",
                    f"Roll every layer back to the backup from {subs[0]} "
                    f"({len(gpkgs)} layer(s))?\n\nThis reverts the attribute tables to "
                    f"exactly before the last renumber.",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                    ) != QMessageBox.StandardButton.Yes:
                return
            live_by_name = {l.name(): l for l in proj.mapLayers().values()
                            if isinstance(l, QgsVectorLayer) and l.isValid()}
            total, done, skipped = 0, 0, []
            for gp in gpkgs:
                safe = gp[:-5]
                lname = name_map.get(safe)
                live = live_by_name.get(lname) if lname else None
                if live is None:
                    for nm, l in live_by_name.items():
                        if "".join(c if c.isalnum() else "_" for c in nm) == safe:
                            live = l
                            break
                if live is None:
                    continue
                blyr = QgsVectorLayer(os.path.join(latest, gp), "_b", "ogr")
                if not blyr.isValid():
                    continue
                # Match on the explicit _vf_fid column written by
                # _pon_snapshot_to_gpkg — NOT on the GPKG's own `fid`. GPKG numbers
                # its fid from 1 while a shapefile's ids start at 0, so matching on
                # `fid` restores every feature's attributes onto the NEXT feature
                # (verified 2026-07-15 on `feeder`: 8/8 wrong). A backup that
                # silently corrupts on restore is worse than no backup at all.
                bnames = [f.name() for f in blyr.fields()]
                fidname = next((n for n in bnames if n.lower() == "_vf_fid"), None)
                if fidname is None:
                    skipped.append(f"{live.name()} (backup predates the "
                                   f"_vf_fid fix — cannot be matched safely)")
                    continue
                drop = {"_vf_fid", "fid"}
                bmap = {}
                for bf in blyr.getFeatures():
                    k = bf[fidname]
                    if k is None:
                        continue
                    bmap[int(k)] = {n: bf[n] for n in bnames
                                    if n.lower() not in drop}
                lfields = live.fields()
                lidx = {lfields.at(i).name(): i for i in range(lfields.count())}
                changes = {}
                for lf in live.getFeatures():
                    src = bmap.get(int(lf.id()))
                    if not src:
                        continue
                    fld = {lidx[n]: v for n, v in src.items() if n in lidx}
                    if fld:
                        changes[lf.id()] = fld
                if changes:
                    # claude:intent MUTATE — user asked: "make sure the backups can be
                    # gotten back ... if we break someone's work that's days of redoing".
                    # Plan: write the backed-up attribute values back onto the live layer,
                    # matched by fid (full undo). Sandbox-guarded + confirmed above.
                    # claude:approved-destructive
                    live.dataProvider().changeAttributeValues(changes)
                    live.triggerRepaint()
                    total += len(changes)
                    done += 1
            try:
                self.iface.mapCanvas().refreshAllLayers()
            except Exception:
                pass
            note = ""
            if skipped:
                note = "\n\nSKIPPED (nothing was changed on these):\n  • " + \
                       "\n  • ".join(skipped)
            QMessageBox.information(
                self, "Restore done",
                f"Restored {total} feature(s) across {done} layer(s) from:\n"
                f"{latest}{note}")
        except Exception as e:
            QMessageBox.warning(self, "Restore failed",
                                f"Could not restore: {e}\n\nThe backup files are safe in "
                                f"the _renumber_backup folder.")

    # ------------------------------------------------------------------
    # PON Renumber (BETA, locked) — intentionally inert: no data path.
    # ------------------------------------------------------------------
    def _on_pon_renumber_locked(self):
        """BETA placeholder. Renumber-by-feeder-route is still in development and is
        HARD-LOCKED: it reads nothing, writes nothing, and cannot lose data. It only
        tells the operator the feature is not ready. JJ unlocks it once it's final."""
        from qgis.PyQt.QtWidgets import QMessageBox
        QMessageBox.information(
            self, "Renumber PONs — BETA (locked)",
            "🔢 Renumber PONs is still being built and is locked.\n\n"
            "• You CAN use 🎯 PON per PON Manual to generate PONs now.\n"
            "• Renumbering is NOT enabled yet — it will not run, so it cannot change "
            "or lose any data.\n\n"
            "⚠ When it is unlocked it must only ever be tested on a sandbox/copy, "
            "never on permanent/production data.")

    # PON per PON Manual
    # ------------------------------------------------------------------
    def on_pon_per_pon_clicked(self):
        """Toggle PON-per-PON selection mode.

        First click  → prompt user to select features on map, then run pipeline.
        Second click → cancel / exit selection mode.
        """
        if not self._btn_pon_per_pon.isChecked():
            # Button was unchecked — cancel any pending selection mode
            self._pon_per_pon_cancel()
            return
        self._pon_per_pon_start()

    def _pon_per_pon_cancel(self):
        """Exit PON-per-PON mode without running the pipeline."""
        canvas = self.iface.mapCanvas()
        if hasattr(self, '_pon_select_tool') and self._pon_select_tool:
            if hasattr(self, '_prev_map_tool') and self._prev_map_tool:
                canvas.setMapTool(self._prev_map_tool)
            self._pon_select_tool = None
        self.iface.messageBar().clearWidgets()
        self._btn_pon_per_pon.setChecked(False)
        self._btn_pon_per_pon.setText(getattr(self, "_PON_PER_PON_LABEL", "🎯 PON per PON Manual  ·BETA"))
        self._pon_per_pon_active = False
        # Signal that the NEXT PON-per-PON run should start a fresh session.
        # We deliberately do NOT null the accumulator refs here so that Manual
        # Override can continue editing the existing layers after this button is
        # closed.  The accumulators will be nulled at the start of the next run.
        self._pon_new_session_needed = True
        # NOTE: _pon_batch_count / _pon_zone_offset / _pon_group_offset are
        # intentionally NOT reset here — they will be reset in _pon_per_pon_run
        # when _pon_new_session_needed is True.


    def _pon_per_pon_start(self):
        """Install the rubber-band polygon map tool for dual-layer PON selection."""
        from qgis.PyQt.QtWidgets import QMessageBox

        self._btn_pon_per_pon.setText("✏ Drawing selection — Right-click to finish")
        self._pon_per_pon_active = True

        demand_lyr = self.comboBox_erf.currentLayer()
        span_lyr = self.comboBox_span_layer.currentLayer()

        if not demand_lyr or not span_lyr:
            QMessageBox.warning(
                self, "PON per PON",
                "Please set the Demand Layer and Route Layer combos before using PON per PON Manual."
            )
            self._pon_per_pon_cancel()
            return

        canvas = self.iface.mapCanvas()

        # Store the previous map tool so we can restore it on cancel
        self._prev_map_tool = canvas.mapTool()

        tool = PonPolygonSelectTool(canvas, demand_lyr, span_lyr)
        tool.selection_complete.connect(self._pon_per_pon_polygon_done)
        tool.cancelled.connect(self._pon_per_pon_cancel)
        self._pon_select_tool = tool
        canvas.setMapTool(tool)

        # Show a non-modal floating hint
        self.iface.messageBar().pushMessage(
            "PON per PON",
            "Left-click to draw polygon vertices. Right-click to complete selection. Esc to cancel.",
            level=Qgis.MessageLevel.Info,   # Qgis.Info
            duration=0
        )

    def _pon_per_pon_polygon_done(self, demand_lyr, span_lyr):
        """Called when the rubber-band polygon is complete; restore map tool then review."""
        canvas = self.iface.mapCanvas()

        # Restore previous map tool
        if hasattr(self, '_prev_map_tool') and self._prev_map_tool:
            canvas.setMapTool(self._prev_map_tool)
        self._pon_select_tool = None

        # Clear message bar hint
        self.iface.messageBar().clearWidgets()

        self._btn_pon_per_pon.setText(getattr(self, "_PON_PER_PON_LABEL", "🎯 PON per PON Manual  ·BETA"))
        self._pon_per_pon_review(demand_lyr, span_lyr)

    def _pon_per_pon_review(self, demand_lyr, span_lyr):
        """Show count of selected features and ask user to confirm or reselect."""
        from qgis.PyQt.QtWidgets import QMessageBox, QDialog, QVBoxLayout, QLabel, QPushButton, QHBoxLayout
        from qgis.PyQt.QtCore import Qt

        n_demand = demand_lyr.selectedFeatureCount()
        n_span = span_lyr.selectedFeatureCount()

        if n_demand == 0 and n_span == 0:
            btn = QMessageBox.question(
                self, "PON per PON — No Selection",
                "No features are currently selected on either layer.\n\n"
                "Would you like to go back and select features?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if btn == QMessageBox.StandardButton.Yes:
                self._pon_per_pon_start()
            else:
                self._pon_per_pon_cancel()
            return

        # Build confirmation dialog
        dlg = QDialog(self)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        dlg.setWindowTitle("PON per PON — Confirm Selection")
        dlg.setMinimumWidth(380)
        lay = QVBoxLayout(dlg)
        lay.setSpacing(10)
        lay.setContentsMargins(16, 16, 16, 16)

        title_lbl = QLabel("<b>Selection Summary</b>")
        title_lbl.setStyleSheet(f'font-size:11px;color:{theme_safe.colors()["accent"]};')
        lay.addWidget(title_lbl)

        import math as _math
        n_groups = _math.ceil(n_demand / 8) if n_demand > 0 else 0

        summary = (
            f"<table cellspacing='6'>"
            f"<tr><td>🏠 Demand points selected:</td><td><b>{n_demand}</b></td></tr>"
            f"<tr><td>📡 Span features selected:</td><td><b>{n_span}</b></td></tr>"
            f"<tr><td>🔀 Splitter groups (est.):</td><td><b>{n_groups}</b></td></tr>"
            f"</table>"
        )
        if n_demand == 0:
            summary += "<br><span style='color:#c0392b;'>⚠ No demand points selected — pipeline will have nothing to group.</span>"
        elif n_demand < 4:
            summary += f"<br><span style='color:#d35400;'>⚠ Only {n_demand} demand point(s) selected — very small PON.</span>"
        else:
            pct = min(100, int(n_demand / 96 * 100))
            summary += f"<br><span style='color:#1e8449;'>✓ ~{pct}% of a full 96-unit PON capacity.</span>"

        sum_lbl = QLabel(summary)
        sum_lbl.setTextFormat(Qt.TextFormat.RichText)
        sum_lbl.setWordWrap(True)
        lay.addWidget(sum_lbl)

        btn_row = QHBoxLayout()
        btn_run = QPushButton("▶ Run AutoNet on Selection")
        btn_run.setStyleSheet(
            "QPushButton{background:#1a6b3c;color:white;font-weight:bold;"
            "border-radius:4px;padding:5px 12px;}"
            "QPushButton:hover{background:#238a4f;}"
        )
        btn_reselect = QPushButton("↩ Reselect")
        btn_reselect.setStyleSheet(
            "QPushButton{background:#7d4e00;color:white;font-weight:bold;"
            "border-radius:4px;padding:5px 12px;}"
            "QPushButton:hover{background:#a06300;}"
        )
        btn_cancel = QPushButton("✕ Cancel")
        btn_cancel.setStyleSheet(
            "QPushButton{background:#922b21;color:white;font-weight:bold;"
            "border-radius:4px;padding:5px 12px;}"
            "QPushButton:hover{background:#b03a2e;}"
        )
        btn_row.addWidget(btn_run)
        btn_row.addWidget(btn_reselect)
        btn_row.addWidget(btn_cancel)
        lay.addLayout(btn_row)

        dlg._choice = 'cancel'
        btn_run.clicked.connect(lambda: (setattr(dlg, '_choice', 'run'), dlg.accept()))
        btn_reselect.clicked.connect(lambda: (setattr(dlg, '_choice', 'reselect'), dlg.accept()))
        btn_cancel.clicked.connect(lambda: (setattr(dlg, '_choice', 'cancel'), dlg.accept()))

        dlg.exec()

        if dlg._choice == 'reselect':
            self._pon_per_pon_start()
        elif dlg._choice == 'run':
            self._pon_per_pon_run(demand_lyr, span_lyr)
        else:
            self._pon_per_pon_cancel()

    def _pon_is_accum_valid(self, layer_ref):
        """Return True if an accumulator layer reference is still alive in the project."""
        from qgis.PyQt import sip as _s
        try:
            if layer_ref is None or _s.isdeleted(layer_ref):
                return False
            from qgis.core import QgsProject
            return layer_ref.id() in QgsProject.instance().mapLayers()
        except Exception:
            return False

    # geom_str → QgsVectorLayer.geometryType() int (0=Point, 1=Line, 2=Polygon)
    _PON_GEOM_INT = {'Point': 0, 'LineString': 1, 'Polygon': 2}

    def _pon_find_existing_accum(self, accum_name, geom_str):
        """Find an existing project layer that an accumulator should reuse.

        Ticket #60: when the PON-per-PON button is toggled off and back on (or the
        project is re-opened), the in-memory accumulator reference is gone — but the
        actual "PON Groups" / "PON Zone Boundaries" / etc. layers are still in the
        project. Re-binding to them makes the next batch APPEND into the existing
        layers instead of spawning duplicate layers. Matches by exact name + geometry
        type; if several match (a project that already accumulated duplicates), reuse
        the one with the most features so we keep extending the real accumulator."""
        from qgis.core import QgsProject, QgsVectorLayer
        want_geom = self._PON_GEOM_INT.get(geom_str)
        best = None
        best_n = -1
        for lyr in QgsProject.instance().mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer):
                continue
            if lyr.name() != accum_name:
                continue
            if want_geom is not None and lyr.geometryType() != want_geom:
                continue
            n = lyr.featureCount()
            if n > best_n:
                best, best_n = lyr, n
        return best

    def _crash_safe_remove_layers(self, layer_ids):
        """Remove map layers crash-safely (Pattern C hardening).

        Removing a layer while an in-flight canvas render job still references it is
        a classic Qt5 sip double-free / segfault on older QGIS — the exact class
        behind "QGIS crashed and my basemaps/project were lost". Freeze the canvas
        first so no render job is running, remove each id (sip-guarded), then
        unfreeze + refresh ONCE. Behaviour-neutral: the same layers are removed,
        just without the mid-removal repaint that can re-enter and crash."""
        from qgis.core import QgsProject
        ids = [i for i in (layer_ids or []) if i]
        if not ids:
            return
        proj = QgsProject.instance()
        canvas = None
        try:
            canvas = self.iface.mapCanvas()
        except Exception:
            canvas = None
        if canvas is not None:
            try:
                canvas.freeze(True)
            except Exception:
                canvas = None
        try:
            for lid in ids:
                try:
                    proj.removeMapLayer(lid)
                except Exception:
                    pass
        finally:
            if canvas is not None:
                try:
                    canvas.freeze(False)
                    canvas.refresh()
                except Exception:
                    pass

    def _pon_merge_batch_into_accumulators(self):
        """After a batch run, merge the batch-specific layers into the 4 persistent
        accumulator layers using direct stored references (not name searching).

        Accumulator layers created (first batch) or appended to (subsequent batches):
          • PON Groups          — grouped demand points (self.grouped_layer)
          • PON Zone Boundaries — zone polygon boundaries (self.zone_boundaries_layer)
          • PON Splitter Points — splitter points (self.splitter_points_layer)
          • PON Drop Cables     — drop cables PTP (self.drop_ptp_layer)
        """
        from qgis.PyQt import sip as _sip_m
        from qgis.core import QgsProject, QgsVectorLayer, QgsFeature

        batch_label = getattr(self, '_current_batch_label', None) or 'unknown batch'

        # Map: (source ref attr, accumulator attr, accumulator name, geom_type str)
        ACCUM_MAP = [
            ('grouped_layer',          '_pon_accum_groups',    'PON Groups',          'Point'),
            ('zone_boundaries_layer',  '_pon_accum_zones',     'PON Zone Boundaries', 'Polygon'),
            ('splitter_points_layer',  '_pon_accum_splitters', 'PON Splitter Points', 'Point'),
            ('drop_ptp_layer',         '_pon_accum_drops',     'PON Drop Cables',     'LineString'),
        ]

        merged_count = 0
        _pending_removals = []   # batch intermediates → removed together, canvas-frozen
        for src_attr, accum_attr, accum_name, geom_str in ACCUM_MAP:
            # Get the batch layer from the stored reference
            batch_layer = getattr(self, src_attr, None)
            if batch_layer is None:
                self.log_message(f"  ⚠ Merge: '{accum_name}' — no source layer (self.{src_attr} is None)")
                continue
            try:
                if _sip_m.isdeleted(batch_layer):
                    self.log_message(f"  ⚠ Merge: '{accum_name}' — source layer was deleted")
                    continue
            except Exception:
                self.log_message(f"  ⚠ Merge: '{accum_name}' — source layer reference invalid")
                continue

            # Get or create the accumulator layer
            accum = getattr(self, accum_attr, None)
            if not self._pon_is_accum_valid(accum):
                # Ticket #60: the in-memory ref is gone (button toggled off/on, or
                # project re-opened). Re-bind to the EXISTING accumulator layer in the
                # project so this batch APPENDS into it instead of creating a duplicate.
                existing = self._pon_find_existing_accum(accum_name, geom_str)
                if existing is not None:
                    accum = existing
                    setattr(self, accum_attr, accum)
                    self.log_message(
                        f"  ✦ Reusing existing accumulator: '{accum_name}' "
                        f"({accum.featureCount()} features) — appending into it")
                else:
                    crs = batch_layer.crs().authid()
                    accum = QgsVectorLayer(f"{geom_str}?crs={crs}", accum_name, "memory")
                    accum.dataProvider().addAttributes(batch_layer.fields().toList())
                    accum.updateFields()
                    if batch_layer.renderer():
                        accum.setRenderer(batch_layer.renderer().clone())
                    if batch_layer.labeling():
                        accum.setLabeling(batch_layer.labeling().clone())
                        accum.setLabelsEnabled(batch_layer.labelsEnabled())
                    QgsProject.instance().addMapLayer(accum)
                    setattr(self, accum_attr, accum)
                    self.log_message(f"  ✦ Created accumulator: '{accum_name}'")

            # Append features from batch layer into accumulator
            feats = [QgsFeature(f) for f in batch_layer.getFeatures()]
            accum.dataProvider().addFeatures(feats)
            accum.updateExtents()
            accum.triggerRepaint()
            self.log_message(f"  ✦ '{accum_name}': +{len(feats)} → {accum.featureCount()} total")
            merged_count += 1

            # Defer removal: collect now, remove all batch intermediates together
            # with the canvas frozen once the merge loop is done (Qt5 crash-safe).
            _pending_removals.append(batch_layer.id())

        if merged_count == 0:
            self.log_message(f"  ⚠ No layers merged for {batch_label} — check pipeline completed all 5 steps")
        else:
            self.log_message(f"  ✓ Merge complete: {merged_count}/4 layers merged for {batch_label}")

        # Also remove the Step 2 demand points layer (intermediate layer, data lives in PON Groups)
        dp_layer = getattr(self, 'demand_points_layer', None)
        if dp_layer is not None:
            try:
                if not _sip_m.isdeleted(dp_layer):
                    _pending_removals.append(dp_layer.id())
                    self.log_message("  ✦ Removed intermediate demand points layer")
            except Exception:
                pass

        # Remove every batch intermediate in ONE canvas-frozen pass — no render job
        # is ever left holding a just-removed layer (the Qt5 segfault path).
        self._crash_safe_remove_layers(_pending_removals)

        # Refresh all accumulator renderers so new zone categories are visible
        self._pon_refresh_accum_renderers()

        # Force the map canvas to actually redraw — triggerRepaint only queues a redraw
        try:
            from qgis.PyQt.QtWidgets import QApplication as _QApp
            self.iface.mapCanvas().refresh()
            _QApp.processEvents()
        except Exception:
            pass

        # Persist the new accumulator handles so they survive a plugin reload (update).
        self._session_save()

    def _pon_refresh_accum_renderers(self):
        """Rebuild the categorized renderer on each accumulator layer so that all
        zone/group values added from the latest batch appear with correct colours.
        Called after every merge."""
        import colorsys
        from qgis.PyQt.QtGui import QColor
        from qgis.PyQt.QtCore import QVariant
        from qgis.core import (QgsRendererCategory,
                               QgsFillSymbol)

        def _categorized_with_catch_all(attr, categories, default_sym):
            """Build a categorized renderer that ALWAYS includes an 'all other
            values' catch-all, so no feature is ever silently invisible.

            Ticket #76/#77: a categorized renderer with no catch-all draws NOTHING
            for a feature whose value matches no category — and if the value list
            comes back empty (e.g. every zone_id is null/-1 mid-edit) it builds a
            zero-category renderer that hides the ENTIRE layer. That looked exactly
            like 'all my drop cables were deleted' when the data was still there.
            The null-valued category below is QGIS's 'all other values' bucket, so
            unmatched / null / -1 features (and an empty category list) still paint."""
            cats = list(categories)
            cats.append(QgsRendererCategory(QVariant(), default_sym, "Other", True))
            return QgsCategorizedSymbolRenderer(attr, cats)

        # ── Zone Boundaries: categorized by zone_name, distinct hue per zone ──
        zones_accum = getattr(self, '_pon_accum_zones', None)
        if self._pon_is_accum_valid(zones_accum):
            try:
                unique_zones = sorted(set(
                    str(f['zone_name']) for f in zones_accum.getFeatures()
                    if f['zone_name'] is not None
                ))
                n = max(len(unique_zones), 1)
                categories = []
                for i, z_name in enumerate(unique_zones):
                    hue = (i / n) % 1.0
                    r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.65, 0.88)]
                    fill_col    = QColor(r, g, b, 70)
                    outline_col = QColor(r, g, b, 230)
                    sym = QgsFillSymbol.createSimple({
                        'color':         fill_col.name(QColor.NameFormat.HexArgb),
                        'outline_color': outline_col.name(),
                        'outline_width': '1.2',
                        'outline_style': 'solid',
                    })
                    categories.append(QgsRendererCategory(z_name, sym, z_name))
                _zone_other = QgsFillSymbol.createSimple({
                    'color': '#28808080', 'outline_color': '#808080',
                    'outline_width': '0.8', 'outline_style': 'solid',
                })
                zones_accum.setRenderer(
                    _categorized_with_catch_all('zone_name', categories, _zone_other))
                zones_accum.triggerRepaint()
            except Exception as _e:
                self.log_message(f"  ⚠ Zone boundary renderer refresh failed: {_e}")

        # ── PON Groups: categorized by zone_id, distinct hue per zone ──
        groups_accum = getattr(self, '_pon_accum_groups', None)
        if self._pon_is_accum_valid(groups_accum):
            try:
                unique_zones = sorted(set(
                    f['zone_id'] for f in groups_accum.getFeatures()
                    if f['zone_id'] is not None
                ))
                n = max(len(unique_zones), 1)
                categories = []
                for i, z_id in enumerate(unique_zones):
                    hue = (i / n) % 1.0
                    r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.7, 0.9)]
                    sym = QgsMarkerSymbol.createSimple({
                        'name': 'circle', 'color': QColor(r, g, b).name(),
                        'size': '2.5', 'outline_style': 'no'
                    })
                    categories.append(QgsRendererCategory(z_id, sym, vf_pon_name(z_id)))
                _grp_other = QgsMarkerSymbol.createSimple({
                    'name': 'circle', 'color': '#808080',
                    'size': '2.5', 'outline_style': 'no'
                })
                groups_accum.setRenderer(
                    _categorized_with_catch_all('zone_id', categories, _grp_other))
                groups_accum.triggerRepaint()
            except Exception as _e:
                self.log_message(f"  ⚠ Groups renderer refresh failed: {_e}")

        # ── Splitters: categorized by zone_id ──
        splitters_accum = getattr(self, '_pon_accum_splitters', None)
        if self._pon_is_accum_valid(splitters_accum):
            try:
                unique_zones = sorted(set(
                    f['zone_id'] for f in splitters_accum.getFeatures()
                    if f['zone_id'] is not None
                ))
                n = max(len(unique_zones), 1)
                categories = []
                for i, z_id in enumerate(unique_zones):
                    hue = (i / n) % 1.0
                    r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.8, 0.85)]
                    sym = QgsMarkerSymbol.createSimple({
                        'name': 'circle', 'color': QColor(r, g, b).name(),
                        'size': '4', 'outline_color': 'black', 'outline_width': '0.5'
                    })
                    categories.append(QgsRendererCategory(z_id, sym, vf_pon_name(z_id)))
                _sp_other = QgsMarkerSymbol.createSimple({
                    'name': 'circle', 'color': '#808080',
                    'size': '4', 'outline_color': 'black', 'outline_width': '0.5'
                })
                splitters_accum.setRenderer(
                    _categorized_with_catch_all('zone_id', categories, _sp_other))
                splitters_accum.triggerRepaint()
            except Exception as _e:
                self.log_message(f"  ⚠ Splitters renderer refresh failed: {_e}")

        # ── Drop Cables: categorized by zone_id, colour-coded lines ──
        drops_accum = getattr(self, '_pon_accum_drops', None)
        if self._pon_is_accum_valid(drops_accum):
            try:
                unique_zones = sorted(set(
                    f['zone_id'] for f in drops_accum.getFeatures()
                    if f['zone_id'] is not None
                ))
                n = max(len(unique_zones), 1)
                categories = []
                for i, z_id in enumerate(unique_zones):
                    hue = (i / n) % 1.0
                    r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.9, 0.85)]
                    sym = QgsLineSymbol.createSimple({
                        'color': QColor(r, g, b).name(), 'width': '0.4'
                    })
                    categories.append(QgsRendererCategory(z_id, sym, vf_pon_name(z_id)))
                # Drops MUST never vanish: unmatched / null / -1 zone_id (the
                # regen default) paints as a plain black drop line, not nothing.
                _drop_other = QgsLineSymbol.createSimple({
                    'color': '0,0,0', 'width': '0.4', 'line_style': 'solid'
                })
                drops_accum.setRenderer(
                    _categorized_with_catch_all('zone_id', categories, _drop_other))
                drops_accum.triggerRepaint()
            except Exception as _e:
                self.log_message(f"  ⚠ Drop cables renderer refresh failed: {_e}")

        # ── PON detail counts: keep zone labels (units + splitters) current ──
        self._pon_refresh_zone_counts()

    def _pon_refresh_zone_counts(self):
        """Recompute unit_count + splitter_count on each PON Zone Boundary feature
        from the LIVE splitter + groups accumulators, so the zone labels stay
        correct after a splitter or demand point is added/deleted in Manual
        Override (ticket #37 — counts must update on changes). No-op if there is
        no zone-boundary layer or it has neither count field."""
        from qgis.PyQt import sip
        zones = getattr(self, '_pon_accum_zones', None)
        try:
            if not zones or sip.isdeleted(zones):
                return
        except Exception:
            return
        zfields = [f.name() for f in zones.fields()]
        # Resolve the count field NAMES robustly. Shapefiles truncate DBF field names
        # to 10 chars, so 'splitter_count' becomes 'splitter_c' — matching the literal
        # 'splitter_count' silently missed it and the splitter count never refreshed on
        # shapefile-backed zone layers. Match the full name first, then by prefix.
        sc_name = ('splitter_count' if 'splitter_count' in zfields
                   else next((n for n in zfields if n.lower().startswith('splitter_c')), None))
        uc_name = ('unit_count' if 'unit_count' in zfields
                   else next((n for n in zfields if n.lower().startswith('unit_c')), None))
        has_sc = sc_name is not None
        has_uc = uc_name is not None
        if not (has_sc or has_uc) or 'zone_id' not in zfields:
            return

        def _alive(lyr):
            try:
                return lyr is not None and not sip.isdeleted(lyr)
            except Exception:
                return lyr is not None

        def _count_by_zone(layer):
            out = {}
            if not _alive(layer):
                return out
            _has_zone_id = 'zone_id' in [fld.name() for fld in layer.fields()]
            for f in layer.getFeatures():
                z = f['zone_id'] if _has_zone_id else None
                if z is None:
                    continue
                try:
                    z = int(z)
                except (TypeError, ValueError):
                    continue
                out[z] = out.get(z, 0) + 1
            return out

        def _sum_by_zone(layer, field):
            out = {}
            if not _alive(layer):
                return out
            _fn = [fld.name() for fld in layer.fields()]
            if 'zone_id' not in _fn or field not in _fn:
                return out
            for f in layer.getFeatures():
                z = f['zone_id']
                if z is None:
                    continue
                try:
                    z = int(z)
                except (TypeError, ValueError):
                    continue
                try:
                    v = int(f[field] or 0)
                except (TypeError, ValueError):
                    v = 0
                out[z] = out.get(z, 0) + v
            return out

        # Splitters in a zone = splitter features by zone_id, EXCLUDING empty
        # (drop_count == 0) residue splitters that serve no homes. UNITS in a zone =
        # the GREATER of (a) the demand points assigned to that zone and (b) the sum of
        # the splitter drop_counts. Taking the max means neither a group left without a
        # splitter (drop_count misses its homes) nor a demand point with a NULL zone_id
        # (home count misses it) can undercount the units label — whichever source has
        # the fuller picture wins.
        _sp_acc = getattr(self, '_pon_accum_splitters', None)
        _grp_acc = getattr(self, '_pon_accum_groups', None)

        def _count_splitters_by_zone(layer):
            out = {}
            if not _alive(layer):
                return out
            _fn = [fld.name() for fld in layer.fields()]
            _has_z = 'zone_id' in _fn
            _has_dc = 'drop_count' in _fn
            for f in layer.getFeatures():
                z = f['zone_id'] if _has_z else None
                if z is None:
                    continue
                if _has_dc:
                    _dcv = f['drop_count']
                    # Skip ONLY splitters with an explicit drop_count of 0 (empty residue
                    # that serves no homes). A NULL/unknown drop_count is kept as a real
                    # splitter so a legit-but-unpopulated count is never silently dropped.
                    try:
                        if _dcv is not None and int(_dcv) == 0:
                            continue
                    except (TypeError, ValueError):
                        pass
                try:
                    z = int(z)
                except (TypeError, ValueError):
                    continue
                out[z] = out.get(z, 0) + 1
            return out

        sp_by_zone = _count_splitters_by_zone(_sp_acc)
        _dc_by_zone = _sum_by_zone(_sp_acc, 'drop_count')
        _homes_by_zone = _count_by_zone(_grp_acc)   # demand points assigned to each zone
        uc_by_zone = {z: max(_homes_by_zone.get(z, 0), _dc_by_zone.get(z, 0))
                      for z in set(_homes_by_zone) | set(_dc_by_zone)}

        sc_idx = zones.fields().indexFromName(sc_name) if has_sc else -1
        uc_idx = zones.fields().indexFromName(uc_name) if has_uc else -1
        attr_map = {}
        for f in zones.getFeatures():
            z = f['zone_id']
            try:
                z = int(z)
            except (TypeError, ValueError):
                continue
            upd = {}
            if has_sc:
                upd[sc_idx] = sp_by_zone.get(z, 0)
            if has_uc:
                # write 0 (not skip) when a zone has lost all its demand points,
                # otherwise the stale non-zero unit_count label persists
                upd[uc_idx] = uc_by_zone.get(z, 0)
            if upd:
                attr_map[f.id()] = upd
        if attr_map:
            try:
                zones.dataProvider().changeAttributeValues(attr_map)
                zones.updateExtents()
                zones.triggerRepaint()
                self.log_message(
                    f"  ✦ PON Zone counts refreshed ({len(attr_map)} zones: "
                    f"units + splitters)")
            except Exception as _e:
                self.log_message(f"  ⚠ Zone count refresh failed: {_e}")

    def _pon_existing_offsets(self):
        """Highest zone_id and group_id already present in the project's PON
        layers, so a resumed / re-opened PON-per-PON session CONTINUES numbering
        instead of restarting at Zone 1. Reads from the SAVED layers via the
        provider's maximumValue (cheap), so it survives a project re-open even
        though the in-memory accumulators are gone. Returns (max_zone, max_group)."""
        from qgis.core import QgsProject, QgsVectorLayer
        max_zone = 0
        max_group = 0
        for lyr in QgsProject.instance().mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer):
                continue
            fnames = [f.name() for f in lyr.fields()]
            if 'zone_id' in fnames:
                try:
                    v = lyr.maximumValue(lyr.fields().indexFromName('zone_id'))
                    if v is not None:
                        max_zone = max(max_zone, int(v))
                except Exception:
                    pass
            # Ticket #69: consider EVERY group-like field on the layer (a splitter
            # layer carries group_id, a grouped-demand layer group_8/…); taking the
            # max across all of them avoids reading a stale lower field and reusing
            # group numbers in the next batch.
            for gf in [n for n in fnames
                       if n == 'group_id' or _DROP_GRP_RE.fullmatch(n)]:  # #79: any group_<N>
                # gf is drawn from fnames, so no membership re-check is needed.
                try:
                    v = lyr.maximumValue(lyr.fields().indexFromName(gf))
                    if v is not None:
                        max_group = max(max_group, int(v))
                except Exception:
                    pass
        return max_zone, max_group

    def _pon_per_pon_run(self, demand_lyr, span_lyr):
        """Run the full AutoNet pipeline (all 5 steps) on only the polygon-selected features."""
        from qgis.PyQt.QtWidgets import QMessageBox
        from qgis.core import QgsVectorLayer, QgsFeatureRequest, QgsProject, QgsWkbTypes

        demand_ids = list(demand_lyr.selectedFeatureIds())
        span_ids   = list(span_lyr.selectedFeatureIds())

        if not demand_ids:
            QMessageBox.warning(self, "PON per PON", "No demand points selected — aborting.")
            self._pon_per_pon_cancel()
            return

        # Build an in-memory copy containing only the selected features
        def _filtered_layer(source_lyr, sel_ids, name):
            wkb = source_lyr.wkbType()
            geom_str = QgsWkbTypes.displayString(wkb)
            crs_str  = source_lyr.crs().authid()
            tmp = QgsVectorLayer(f"{geom_str}?crs={crs_str}", name, "memory")
            tmp.dataProvider().addAttributes(source_lyr.fields().toList())
            tmp.updateFields()
            feats = list(source_lyr.getFeatures(QgsFeatureRequest().setFilterFids(sel_ids)))
            tmp.dataProvider().addFeatures(feats)
            return tmp

        # Name the temp layers identically to the originals so on_autonet_clicked
        # layer-detection resolves them via the combo (not by name-search fallback)
        tmp_demand = _filtered_layer(demand_lyr, demand_ids, demand_lyr.name())
        tmp_span   = _filtered_layer(span_lyr, span_ids, span_lyr.name()) if span_ids else None

        _orig_demand = self.comboBox_erf.currentLayer()
        _orig_span   = self.comboBox_span_layer.currentLayer()
        _orig_road   = self.comboBox_road_layer.currentLayer()

        tmp_demand_id = None
        tmp_span_id   = None

        try:
            # Add WITH legend visibility so QgsMapLayerComboBox can reference them
            QgsProject.instance().addMapLayer(tmp_demand, True)
            tmp_demand_id = tmp_demand.id()
            self.comboBox_erf.setLayer(tmp_demand)

            if tmp_span:
                QgsProject.instance().addMapLayer(tmp_span, True)
                tmp_span_id = tmp_span.id()
                self.comboBox_span_layer.setLayer(tmp_span)

            # Ensure Tight PON of 96 clustering method is active
            for i in range(self.comboBox_clustering_method.count()):
                if 'tight' in self.comboBox_clustering_method.itemText(i).lower():
                    self.comboBox_clustering_method.setCurrentIndex(i)
                    break

            # Preserve the full (unfiltered) span layer so splitter snapping
            # can use all Distribution spans — not just those inside the polygon
            self._pon_full_span_layer = span_lyr

            # BUGFIX: Reset ALL layer references before each batch so that if any step
            # fails silently, subsequent steps won't use previous batch's stale layers.
            # Previously only grouped_layer was reset; demand_points_layer and
            # splitter_points_layer stale references caused missing drops on some zones.
            self.grouped_layer = None
            self.demand_points_layer = None
            self.splitter_points_layer = None
            self.zone_boundaries_layer = None
            self.drop_ptp_layer = None

            # If the previous session was closed (button toggled off), start fresh:
            # null the old accumulators so the merge step creates new ones, and reset
            # zone/group counters so numbering starts from 1 again.
            # Also treat truly first-ever run (all None) as a fresh session.
            _accum_fresh = (
                getattr(self, '_pon_new_session_needed', False) or
                (getattr(self, '_pon_accum_groups',    None) is None and
                 getattr(self, '_pon_accum_splitters', None) is None)
            )
            if _accum_fresh:
                self._pon_accum_groups    = None
                self._pon_accum_zones     = None
                self._pon_accum_splitters = None
                self._pon_accum_drops     = None
                self._pon_batch_count  = 0
                # Persistent numbering: continue from the highest zone/group that
                # already exists in the project's SAVED PON layers, so a planner
                # who stops & resumes (or re-opens the project) keeps counting up
                # instead of restarting at Zone 1.
                _ez, _eg = self._pon_existing_offsets()
                self._pon_zone_offset  = _ez
                self._pon_group_offset = _eg
                self._pon_new_session_needed = False
                if _ez or _eg:
                    self.log_message(
                        f"  [PON per PON] Resuming — continuing numbering from "
                        f"zone {_ez + 1} / group {_eg + 1} (existing PON layers found)")
                else:
                    self.log_message("  [PON per PON] Fresh project — zone/group numbering starts at 1")

            # Advance the batch counter BEFORE running so the label is correct
            self._pon_batch_count += 1
            batch_label = f"PON Batch {self._pon_batch_count}"

            # Rotate zone polygon colors per batch (golden angle ~137.5° for max separation)
            self._pon_color_offset = (self._pon_batch_count * 0.382) % 1.0

            # Ticket #69 + #70: derive the offsets from the ACTUAL groups/zones still
            # in the project (accumulators are merged after every batch). This makes
            # numbering follow reality in BOTH directions: it advances above existing
            # numbers so two batches never duplicate (#69), AND it drops back down
            # when the planner deletes a bad batch's layers so a new batch continues
            # from the real remaining count instead of "what would have been" (#70).
            _ez_now, _eg_now = self._pon_existing_offsets()
            self._pon_group_offset = _eg_now
            self._pon_zone_offset  = _ez_now

            # Run the full 5-step pipeline with sequential offsets
            self.on_autonet_clicked(
                _zone_offset=self._pon_zone_offset,
                _group_offset=self._pon_group_offset,
                _batch_label=batch_label,
            )

            # Advance offsets for the next run using the max IDs written this run
            self._pon_group_offset = getattr(self, '_last_max_group', self._pon_group_offset)
            self._pon_zone_offset  = getattr(self, '_last_max_zone',  self._pon_zone_offset)

            # Merge batch-specific layers into persistent accumulators
            self.log_message("\n── Merging batch layers into persistent accumulators ──")
            self._pon_merge_batch_into_accumulators()

            # CRITICAL: clear the batch label NOW so that Manual Override drop regen
            # (which calls on_generate_drop_ptp_clicked) does NOT think it is inside a
            # batch run and correctly targets the accumulator instead of creating a new layer.
            self._current_batch_label = None

        finally:
            # #8: also clear the batch label HERE (not only in the try above). An
            # exception mid-batch must not leave the dock stuck in "batch mode", or the
            # next Manual Override drop regen creates a stray '- PON Batch N' layer
            # instead of updating the accumulator. (The early clear in the try still
            # stands — it must precede any post-merge regen.)
            self._current_batch_label = None
            # Clear the full-span override and color offset now that the pipeline is done
            self._pon_full_span_layer = None
            self._pon_color_offset = 0.0

            # Restore original combo selections
            self.comboBox_erf.setLayer(_orig_demand)
            self.comboBox_span_layer.setLayer(_orig_span)
            if _orig_road:
                self.comboBox_road_layer.setLayer(_orig_road)

            # Remove the temporary filtered layers from the project. These were
            # added with legend visibility + set on the layer combos, so they are
            # the most likely to be held by an in-flight render job — remove them
            # canvas-frozen (Qt5 crash-safe). Combos were already restored above.
            self._crash_safe_remove_layers([tmp_demand_id, tmp_span_id])

            demand_lyr.removeSelection()
            span_lyr.removeSelection()

        # Stay in PON-per-PON mode so user can immediately select the next batch
        self._btn_pon_per_pon.setChecked(True)
        self._btn_pon_per_pon.setText(getattr(self, "_PON_PER_PON_LABEL", "🎯 PON per PON Manual  ·BETA"))

        btn = QMessageBox.question(
            self, "PON per PON — Continue?",
            "PON pipeline complete for this batch.\n\n"
            "Would you like to select and run the next PON batch?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if btn == QMessageBox.StandardButton.Yes:
            self._pon_per_pon_start()
        else:
            self._pon_per_pon_cancel()

    def on_generate_demand_points_clicked(self):
        """Generate demand points from grouped parcels at their centroids."""
        # Use the most recently generated grouped layer
        selected_layer = self.grouped_layer

        # sip guard: a stored handle to a since-deleted layer is still truthy but its
        # C++ object is gone — `.name()`/`.getFeatures()` would raise RuntimeError.
        if not selected_layer or sip.isdeleted(selected_layer):
            self.log_message("ERROR: Please generate grouped parcels first.")
            return
        
        self.log_message("\n=== Generating Demand Points ===")
        self.log_message(f"Source Layer: '{selected_layer.name()}'")
        
        try:
            from qgis.core import QgsVectorLayer, QgsFeature
            
            # Get features from source layer
            features = list(selected_layer.getFeatures())
            
            if len(features) == 0:
                self.log_message("ERROR: Layer has no features.")
                return
            
            # Create new point layer with same CRS
            crs = selected_layer.crs().authid()
            demand_layer = QgsVectorLayer(f"Point?crs={crs}", 
                                         f"{selected_layer.name()} - Demand Points", 
                                         "memory")
            provider = demand_layer.dataProvider()
            
            # Copy all fields from source layer
            provider.addAttributes(selected_layer.fields().toList())
            demand_layer.updateFields()
            
            # Create demand point for each parcel at its centroid
            total_src = len(features)
            self.log_message(f"Processing {total_src} features...")
            self._start_timer()
            demand_features = []
            for idx, feature in enumerate(features):
                self._progress(idx + 1, total_src, 'Demand pts')
                geom = feature.geometry()
                if geom and not geom.isEmpty():
                    # Get centroid
                    centroid = geom.centroid()
                    
                    # Create new point feature
                    demand_feature = QgsFeature(demand_layer.fields())
                    demand_feature.setGeometry(centroid)
                    
                    # Copy all attributes from source feature
                    for field in selected_layer.fields():
                        demand_feature[field.name()] = feature[field.name()]
                    
                    demand_features.append(demand_feature)
            
            # Add features to layer
            provider.addFeatures(demand_features)
            demand_layer.updateExtents()
            
            # Add layer to project
            demand_layer = self._add_output_layer(demand_layer)
            
            # Store reference for drop cable generation
            self.demand_points_layer = demand_layer
            
            self.log_message(f"\nCreated {len(demand_features)} demand points")
            self._elapsed("Total time")
            self.log_message(f"New layer: '{demand_layer.name()}'")
            self.log_message("All attributes copied from source parcels")
            
        except Exception as e:
            self.log_message(f"ERROR: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def apply_batch_symbology(self, layer: QgsVectorLayer, field_name: str = 'batch_id'):
        """Apply categorized symbology to show different batches/clusters in different colors.
        
        Args:
            layer: Layer with grouping field
            field_name: Name of the field to use for symbology
        """
        try:
            from qgis.core import (
                QgsRendererCategory,
                QgsSymbol
            )
            from qgis.PyQt.QtGui import QColor
            import random
            
            field_idx = layer.fields().indexOf(field_name)
            
            if field_idx < 0:
                return
            
            # Get unique values
            unique_values = set()
            for feature in layer.getFeatures():
                value = feature.attribute(field_name)
                if value is not None:
                    unique_values.add(value)
            
            # Create categories
            categories = []
            for value in sorted(unique_values):
                # Generate a color for each group
                random.seed(value)  # Consistent colors for same value
                color = QColor(
                    random.randint(100, 255),
                    random.randint(100, 255),
                    random.randint(100, 255),
                    180  # Some transparency
                )
                
                symbol = QgsSymbol.defaultSymbol(layer.geometryType())
                symbol.setColor(color)
                
                # Determine label — for zone_name the stored value IS already
                # the human-readable label ("Zone 1", "Zone 2", …)
                if field_name == 'zone_name':
                    label = str(value)
                elif 'batch' in field_name.lower():
                    label = f"Batch {value}"
                elif 'cluster' in field_name.lower():
                    label = f"Cluster {value}"
                elif 'pon' in field_name.lower():
                    label = f"PON {value}"
                elif 'zone' in field_name.lower():
                    label = vf_pon_name(value)   # a zone IS a PON
                else:
                    label = f"Splitter {value}"
                
                category = QgsRendererCategory(
                    value,
                    symbol,
                    label
                )
                categories.append(category)
            
            # Apply renderer (Batch A: with 'all other values' catch-all so null/
            # unexpected values never make a feature — or the whole layer — vanish)
            renderer = _categorized_with_catch_all(layer, field_name, categories)
            layer.setRenderer(renderer)
            layer.triggerRepaint()

            self.log_message("  Applied color-coded symbology.")
            
        except Exception as e:
            # If symbology fails, just log it but don't fail the whole operation
            self.log_message(f"  (Could not apply symbology: {e!s})")

    def on_find_splitters_clicked(self):
        """Find and display optimal splitter locations."""
        selected_layer = self.comboBox_erf.currentLayer()
        
        if not selected_layer:
            self.log_message("ERROR: Please select a layer.")
            return
        
        if not SKLEARN_AVAILABLE or not NUMPY_AVAILABLE:
            self.log_message("ERROR: Splitter optimization requires scikit-learn and numpy.")
            self.log_message("Install with: pip install scikit-learn numpy")
            return
        
        num_splitters = 10  # Default number of splitters
        
        self.log_message("\n=== Finding Optimal Splitter Locations ===")
        self.log_message(f"Layer: '{selected_layer.name()}'")
        self.log_message(f"Number of splitters: {num_splitters}")
        
        try:
            # Get features
            features = list(selected_layer.getFeatures())
            
            if len(features) == 0:
                self.log_message("ERROR: Layer has no features.")
                return
            
            # Find optimal locations
            self._start_timer()
            splitter_locations = find_optimal_splitter_locations(features, num_splitters)
            
            # Create a memory layer for splitter points
            from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject, QgsField
            from qgis.PyQt.QtCore import QMetaType
            
            # Get CRS from source layer
            crs = selected_layer.crs().authid()
            splitter_layer = QgsVectorLayer(f"Point?crs={crs}", "Optimal Splitter Locations", "memory")
            provider = splitter_layer.dataProvider()
            
            # Add fields
            provider.addAttributes([
                QgsField("splitter_id", QMetaType.Type.Int),
                QgsField("x_coord", QMetaType.Type.Double),
                QgsField("y_coord", QMetaType.Type.Double)
            ])
            splitter_layer.updateFields()
            
            # Add splitter points
            splitter_features = []
            for idx, location in enumerate(splitter_locations):
                feat = QgsFeature()
                feat.setGeometry(QgsGeometry.fromPointXY(location))
                feat.setAttributes([idx + 1, location.x(), location.y()])
                splitter_features.append(feat)
            
            provider.addFeatures(splitter_features)
            splitter_layer.updateExtents()
            
            # Style the splitter layer
            from qgis.core import QgsMarkerSymbol, QgsSingleSymbolRenderer
            
            symbol = QgsMarkerSymbol.createSimple({
                'name': 'star',
                'color': 'red',
                'size': '4',
                'outline_color': 'white',
                'outline_width': '0.5'
            })
            renderer = QgsSingleSymbolRenderer(symbol)
            splitter_layer.setRenderer(renderer)
            
            # Add layer to project
            QgsProject.instance().addMapLayer(splitter_layer)
            
            self.log_message(f"\nCreated {len(splitter_locations)} optimal splitter locations.")
            self.log_message("Splitter layer added to map.")
            self.log_message("Locations minimize average distance to parcels/points.")
            self._elapsed("Total time")
            
        except Exception as e:
            self.log_message(f"ERROR: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_cluster_erven_clicked(self, _zone_offset=0, _group_offset=0, _batch_label=None):
        """Generate PON groups using Tight PON of 96 (groups of 8) along Distribution spans.

        _zone_offset  – add this to every zone_id so runs don't clash (PON-per-PON mode).
        _group_offset – add this to every group_id so runs don't clash.
        _batch_label  – suffix appended to output layer names (e.g. "PON Batch 2").
        """
        from qgis.core import QgsVectorLayer, QgsFeature, QgsField
        from qgis.PyQt.QtCore import QMetaType

        selected_layer = self.comboBox_erf.currentLayer()
        if not selected_layer:
            self.log_message("ERROR: Please select a layer.")
            return

        layer_type_name = "Demand Points"
        target_size = 8
        continuous_mode = False

        self.log_message(f"\n=== Grouping {layer_type_name} ===")
        self.log_message(f"Layer: '{selected_layer.name()}' ({selected_layer.featureCount()} features)")

        _input_fields = [f.name() for f in selected_layer.fields()]
        if 'zone_name' in _input_fields or _demand_group_field(_input_fields):  # #79: any group_<N>
            self.log_message(
                "⚠ WARNING: The selected layer already has 'zone_name'/'group_<N>' fields — "
                "it appears to be a previously grouped layer, NOT the original demand points. "
                "Please select the ORIGINAL demand points layer in the dropdown above."
            )
        _subset = selected_layer.subsetString()
        if _subset:
            self.log_message(
                f"⚠ WARNING: Layer has an active filter: {_subset!r}. "
                "Only filtered features will be grouped."
            )

        try:
            features = list(selected_layer.getFeatures())
            total_features = len(features)

            if total_features == 0:
                self.log_message("ERROR: Layer has no features.")
                return

            route_layer = self.comboBox_span_layer.currentLayer()
            road_layer  = self.comboBox_road_layer.currentLayer()
            if road_layer:
                self.log_message(f"Road barrier layer: '{road_layer.name()}'")

            try:
                network_coverage = self.doubleSpinBox_span_corridor.value()
            except AttributeError:
                network_coverage = 150.0
            group_cohesion = 120
            gap_tolerance  = 3

            geom_type     = selected_layer.geometryType()
            is_point_layer = (geom_type == 0)

            if route_layer:
                self.log_message(f"Grouping along route: '{route_layer.name()}'")
                route_field_names = [f.name() for f in route_layer.fields()]
                if 'Cable Type' in route_field_names:
                    self.log_message("🎯 FILTERING: Only Distribution spans (Cable Type = 'Distribution')")
                else:
                    self.log_message("⚠ WARNING: Span layer has no 'Cable Type' field — using ALL spans")
                self.log_message(f"Span corridor: {network_coverage:.0f} m")
            else:
                self.log_message("Grouping without route — detecting block boundaries...")

            self.log_message(f"Clustering {total_features} features into groups of {target_size}...")
            self._start_operation("Generating PON Groups…")
            QApplication.processEvents()

            feature_to_group = cluster_tight_groups_of_8(
                features,
                route_layer=route_layer,
                target_size=target_size,
                span_proximity_limit=network_coverage,
                adjacency_distance=group_cohesion,
                gap_tolerance_multiplier=gap_tolerance,
                progress_callback=lambda done, total, lbl='Clustering': self._progress(done, total, lbl),
                road_layer=road_layer,
                demand_crs=selected_layer.crs(),
            )

            if not feature_to_group:
                self.log_message("ERROR: No features could be grouped.")
                return

            import time as _time
            self.log_message(f"  ⏱ Clustering — {self._fmt_time(_time.time() - self._op_t0)}")

            crs = selected_layer.crs().authid()
            geom_name = {0: "Point", 1: "LineString", 2: "Polygon"}.get(geom_type, "Polygon")
            _lyr_suffix = f" - {_batch_label}" if _batch_label else f" - Groups of {target_size}"
            new_layer = QgsVectorLayer(
                f"{geom_name}?crs={crs}",
                f"{selected_layer.name()}{_lyr_suffix}",
                "memory"
            )
            provider = new_layer.dataProvider()
            provider.addAttributes(selected_layer.fields().toList())
            field_name = f'group_{target_size}'
            provider.addAttributes([QgsField(field_name, QMetaType.Type.Int)])
            zone_field_name  = 'zone_id'
            zone_name_field  = 'zone_name'
            local_field_name = 'group_local'   # per-zone rank 1..N (DISPLAY-only)
            provider.addAttributes([
                QgsField(zone_field_name,  QMetaType.Type.Int),
                QgsField(zone_name_field,  QMetaType.Type.QString),
                # group_local = the group's rank WITHIN its zone (1..N). group_id stays
                # globally-unique (routing + Manual Override untouched); this is the
                # per-zone number crews read on the label. The splitter copies it verbatim
                # so the two always agree (#114/#126 mismatch guard).
                QgsField(local_field_name, QMetaType.Type.Int),
            ])
            new_layer.updateFields()

            feature_positions = {}
            for feat in features:
                geom = feat.geometry()
                if geom and not geom.isEmpty():
                    c = geom.centroid().asPoint()
                    feature_positions[feat.id()] = (c.x(), c.y())

            # In PON-per-PON mode the whole selection IS one zone — no 96-unit cap.
            # In normal AutoNet mode keep the 96-unit cap.
            zone_max_size = total_features if _batch_label else 96
            olt_layer = self.comboBox_olt_layer.currentLayer()
            feature_to_zone = group_zones_from_groups(
                feature_to_group,
                max_zone_size=zone_max_size,
                feature_positions=feature_positions,
                route_layer=route_layer,
                pop_layer=olt_layer,
            )

            _no_group = sum(1 for f in features if feature_to_group.get(f.id()) is None)
            self.log_message(
                f"Grouped: {len(feature_to_group)} / {total_features} features "
                f"({_no_group} skipped)"
            )

            # DISPLAY-ONLY per-zone numbering: rank each group WITHIN its zone (1..N).
            # Keyed on the pre-offset (zone, group) — the rank is independent of the
            # global offset, so it's the clean "Grp 1..N per zone" crews want, while the
            # stored group_id remains globally-unique for routing. Sorting the distinct
            # group_ids per zone makes the rank deterministic + stable across re-runs.
            _groups_per_zone = {}
            for _fid_r, _gid_r in feature_to_group.items():
                if _gid_r is None:
                    continue
                _zz_r = feature_to_zone.get(_fid_r)
                if _zz_r is None:
                    continue
                _groups_per_zone.setdefault(_zz_r, set()).add(_gid_r)
            _local_rank = {}   # (zone_id, group_id) -> per-zone rank 1..N
            for _zz_r, _gids_r in _groups_per_zone.items():
                for _rnk, _gid_r in enumerate(sorted(_gids_r), start=1):
                    _local_rank[(_zz_r, _gid_r)] = _rnk

            self.log_message("Building output layer...")
            new_features = []
            _ungrouped_count = 0
            for idx, feat in enumerate(features):
                self._progress(idx + 1, total_features, 'Output')
                group_id = feature_to_group.get(feat.id())
                z_id = feature_to_zone.get(feat.id()) if group_id is not None else None
                if group_id is None:
                    _ungrouped_count += 1

                # Apply offsets so each PON-per-PON batch has globally unique IDs
                g_out = (group_id + _group_offset) if group_id is not None else None
                z_out = (z_id    + _zone_offset)   if z_id    is not None else None
                # per-zone rank (display-only) — keyed on the PRE-offset (zone, group)
                local_out = _local_rank.get((z_id, group_id)) if (
                    group_id is not None and z_id is not None) else None

                new_feat = QgsFeature(new_layer.fields())
                new_feat.setGeometry(feat.geometry())
                for field in selected_layer.fields():
                    new_feat[field.name()] = feat[field.name()]
                new_feat[field_name]        = g_out
                new_feat[zone_field_name]   = z_out
                new_feat[zone_name_field]   = vf_pon_name(z_out) if z_out is not None else None
                new_feat[local_field_name]  = local_out
                new_features.append(new_feat)

            if _ungrouped_count:
                self.log_message(
                    f"WARNING: {_ungrouped_count} features had no group assignment"
                )

            provider.addFeatures(new_features)
            new_layer.updateExtents()
            new_layer = self._add_output_layer(new_layer)

            self.grouped_layer = new_layer

            total_clusters = len(set(v for v in feature_to_group.values() if v is not None))
            total_zones    = len(set(v for v in feature_to_zone.values()  if v is not None)) if feature_to_zone else 0

            # Compute the true max output IDs (with offset applied) for the caller
            max_group_out = (max((v for v in feature_to_group.values() if v is not None), default=0)
                             + _group_offset)
            max_zone_out  = (max((v for v in feature_to_zone.values()  if v is not None), default=0)
                             + _zone_offset) if feature_to_zone else _zone_offset

            self.apply_batch_symbology(new_layer, zone_name_field)

            self.log_message(
                f"\nCreated {total_clusters} groups → {total_zones} zones "
                f"(max {zone_max_size} units/zone)"
            )
            if _zone_offset:
                self.log_message(f"  Zone IDs: {_zone_offset + 1} – {max_zone_out}")
            self.log_message("\nGrouping completed successfully!")
            self._elapsed("Total time")
            self.log_message(f"  New layer: '{new_layer.name()}'")

            # Expose the max IDs so _pon_per_pon_run can advance the offsets
            self._last_max_group = max_group_out
            self._last_max_zone  = max_zone_out
        except Exception as e:
            self.log_message(f"ERROR: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def _apply_cluster_symbology(self, layer: QgsVectorLayer):
        """Apply categorized symbology to show different clusters in different colors.
        
        Args:
            layer: Layer with cluster_id field
        """
        try:
            from qgis.core import (
                QgsRendererCategory,
                QgsSymbol
            )
            from qgis.PyQt.QtGui import QColor
            import random
            
            field_name = 'cluster_id'
            field_idx = layer.fields().indexOf(field_name)
            
            if field_idx < 0:
                return
            
            # Get unique cluster values
            unique_values = set()
            for feature in layer.getFeatures():
                cluster_id = feature.attribute(field_name)
                if cluster_id is not None:
                    unique_values.add(cluster_id)
            
            # Create categories
            categories = []
            for cluster_id in sorted(unique_values):
                # Generate a color for each cluster
                random.seed(cluster_id)  # Consistent colors for same cluster
                color = QColor(
                    random.randint(100, 255),
                    random.randint(100, 255),
                    random.randint(100, 255),
                    200  # Some transparency
                )
                
                symbol = QgsSymbol.defaultSymbol(layer.geometryType())
                symbol.setColor(color)
                
                category = QgsRendererCategory(
                    cluster_id,
                    symbol,
                    f"Cluster {cluster_id}"
                )
                categories.append(category)
            
            # Create and set the renderer (Batch A: catch-all so null/unexpected
            # cluster_id never hides a feature or the whole layer)
            renderer = _categorized_with_catch_all(layer, field_name, categories)
            layer.setRenderer(renderer)
            layer.triggerRepaint()

        except Exception as e:
            # If symbology fails, just log it but don't fail the whole operation
            self.log_message(f"  (Could not apply cluster symbology: {e!s})")

    def on_show_batch_stats_clicked(self):
        """Show statistics about batch assignments."""
        erf_layer = self.comboBox_erf.currentLayer()
        
        if not erf_layer:
            self.log_message("ERROR: Please select an ERF layer.")
            return
        
        field_idx = erf_layer.fields().indexOf('batch_id')
        if field_idx < 0:
            self.log_message("ERROR: Layer has no 'batch_id' field. Please group ERF parcels first.")
            return
        
        self.log_message("\n=== Batch Statistics ===")
        self.log_message(f"Layer: '{erf_layer.name()}'")
        
        try:
            stats = get_batch_statistics(erf_layer)
            self._start_timer()
            if not stats:
                self.log_message("No batch data found.")
                return
            
            self.log_message(f"\nTotal batches: {stats['total_batches']}")
            self.log_message(f"Average batch size: {stats['avg_batch_size']:.1f}")
            
            # Show details for each batch
            self.log_message("\nBatch Details:")
            for batch_id in sorted(stats['batch_counts'].keys()):
                count = stats['batch_counts'][batch_id]
                extent = stats['batch_extents'].get(batch_id)
                
                if extent:
                    extent_str = f"({extent.xMinimum():.2f}, {extent.yMinimum():.2f}) to ({extent.xMaximum():.2f}, {extent.yMaximum():.2f})"
                else:
                    extent_str = "N/A"
                
                self.log_message(f"  Batch {batch_id}: {count} parcels")
                self.log_message(f"    Extent: {extent_str}")
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR getting batch statistics: {e!s}")

    # ------------------------------------------------------------------
    # PON boundary from an edit — a TILE, not a bubble.
    #
    # Measured on a live PON (2026-07-23): the buffer path below produces a
    # 985-vertex union of circles, against 40 for the tile Generate makes, and
    # it covers only 82% of the tile's area because a circle-union loses the
    # land between the houses. Tidying that up afterwards only gets to 362
    # vertices — still nine times a real tile. So the fix is to not build a
    # bubble at all: tile the coverage the same way Generate does.
    #
    # Every Manual Override edit goes through here, which is why the whole
    # "blobs instead of neat PONs" complaint traces back to this one function.
    # ------------------------------------------------------------------
    _TILE_CACHE_KEY = None
    _TILE_CACHE_VAL = None

    def _tile_zone_polygon(self, grouped_layer, zone_feats, zone_key=None):
        """A straight-edged tile for ``zone_feats``, or None to fall back.

        The tiler works on the WHOLE coverage, so the other PONs are read off
        the layer as they currently stand and the features being edited are
        placed in their own bucket. That way the new tile is shaped correctly
        against its real neighbours instead of being grown in isolation.

        Returns None on anything unexpected — the caller then uses the original
        buffer path, so this can only improve the result, never break it.
        """
        try:
            from qgis.core import QgsGeometry
            if not zone_feats:
                return None
            fld = vf_fields.resolve(grouped_layer, vf_fields.PON_NAME) \
                or vf_fields.resolve(grouped_layer, vf_fields.PON_NUM)
            if not fld:
                return None
            key = zone_key or "__EDITED__"
            moving = {f.id() for f in zone_feats}

            by_zone = {}
            for f in grouped_layer.getFeatures():
                if f.id() in moving:
                    continue                     # counted under the edited key
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                z = f[fld]
                if z is None or str(z).strip() == "":
                    continue
                by_zone.setdefault(str(z), []).append(f)
            by_zone[key] = list(zone_feats)
            if len(by_zone) < 2:
                return None                      # nothing to tile against

            # Re-tiling costs ~1.5-2 s on 5,000 homes and a single Manual
            # Override edit calls this up to three times. Cache on the exact
            # membership so those repeats are free; any real change misses.
            sig = (id(grouped_layer), fld,
                   tuple(sorted((z, len(v)) for z, v in by_zone.items())),
                   tuple(sorted(moving)))
            if type(self)._TILE_CACHE_KEY == sig:
                tiles = type(self)._TILE_CACHE_VAL
            else:
                tiles = self._voronoi_zone_polygons(grouped_layer, by_zone)
                type(self)._TILE_CACHE_KEY = sig
                type(self)._TILE_CACHE_VAL = tiles
            if not tiles:
                return None
            geom = tiles.get(key)
            if geom is None or geom.isEmpty() or not geom.isGeosValid():
                return None

            # Pull it in so it does not touch its neighbours — the 4 m corridor
            # measured off the Malmesbury reference design.
            try:
                from . import pon_merge as _pm
                pulled, ok = _pm.shrink(geom, grouped_layer)
                if ok:
                    geom = pulled
            except Exception:
                pass
            return geom if isinstance(geom, QgsGeometry) else None
        except Exception:
            return None

    def _build_zone_polygon(self, grouped_layer, zone_feats, zone_key=None):
        """Return a QgsGeometry zone polygon for a list of demand features.

        Prefers a straight-edged TILE (see _tile_zone_polygon). Falls back to
        the original buffer + morphological-closing algorithm only when tiling
        is not possible, so behaviour degrades to exactly what it was before
        rather than failing."""
        _tile = self._tile_zone_polygon(grouped_layer, zone_feats, zone_key)
        if _tile is not None and not _tile.isEmpty():
            return _tile
        # MO audit 2026-06-18: (a) GUARD null geometries — the project ships null-geom
        # features and `f.geometry().isEmpty()` on a None geometry crashed every
        # zone-affecting edit (apply_change / reassign / edit-splitter, none wrapped in
        # try/except). (b) NEVER convex-hull — a hull balloons the zone across the map
        # (the #63 failure); bridge multipart results with thin corridors via
        # _snap_parts_together, exactly like _rebuild_zone_boundary.
        from qgis.core import QgsGeometry, QgsUnitTypes
        is_point_layer = grouped_layer.geometryType() == 0
        geoms = [f.geometry() for f in zone_feats
                 if f.geometry() and not f.geometry().isEmpty()]
        if not geoms:
            return QgsGeometry()
        if is_point_layer:
            unit_type = grouped_layer.crs().mapUnits()
            if unit_type == QgsUnitTypes.DistanceUnit.DistanceDegrees:
                min_r, max_r = 0.00005, 0.00025
            else:
                min_r, max_r = 5.0, 30.0
            coords = [g.asPoint() for g in geoms]
            if len(coords) <= 1:
                radius = max_r
            else:
                nn_sum, nn_count = 0.0, 0
                for i, pt in enumerate(coords):
                    best = float('inf')
                    for j, other in enumerate(coords):
                        if i == j:
                            continue
                        d = ((pt.x() - other.x()) ** 2 +
                             (pt.y() - other.y()) ** 2) ** 0.5
                        if d < best:
                            best = d
                    if best < float('inf'):
                        nn_sum += best
                        nn_count += 1
                mean_nn = nn_sum / nn_count if nn_count else max_r
                radius = max(min(mean_nn * 0.55, max_r), min_r)
            zone_geom = geoms[0].buffer(radius, 8)
            for g in geoms[1:]:
                zone_geom = zone_geom.combine(g.buffer(radius, 8))
            gap_r = radius * 2.5
            zone_geom = zone_geom.buffer(gap_r, 6).buffer(-gap_r * 0.92, 6)
            if not zone_geom.isEmpty():
                if zone_geom.isMultipart():
                    zone_geom = self._snap_parts_together(zone_geom, radius)
                else:
                    poly = zone_geom.asPolygon()
                    if poly:
                        zone_geom = QgsGeometry.fromPolygonXY([poly[0]])
        else:
            merged = geoms[0]
            for g in geoms[1:]:
                merged = merged.combine(g)
            if merged.isMultipart():
                _bb = merged.boundingBox()
                _r = (max(_bb.width(), _bb.height()) * 0.02) or 1.0
                zone_geom = self._snap_parts_together(merged, _r)
            else:
                zone_geom = merged
        return zone_geom

    def _voronoi_zone_polygons(self, grouped_layer, features_by_zone):
        """③ Clean Voronoi-tiled zone boundaries (JJ 2026-06-25, HTML-approved option ③).

        Returns {zone_name: QgsGeometry} in the grouped_layer CRS — one straight-edged,
        gap-free, NON-overlapping tile per zone, instead of the rounded buffer blobs.
        Method: Voronoi over ALL demand points → each cell labelled by its point's zone →
        cells dissolved per zone → clipped to a concave settlement hull → Douglas-Peucker
        simplified (~10 m). Membership is taken straight from features_by_zone (identical to
        what the buffer path used), so NO home changes PON. Returns {} on any problem, so the
        caller transparently falls back to the old buffer boundaries.
        """
        import math
        from qgis.core import QgsGeometry
        try:
            import numpy as np
            from scipy.spatial import Voronoi
            import shapely
            from shapely.geometry import MultiPoint, Polygon, MultiPolygon
            from shapely.ops import unary_union, transform as shp_tf
        except Exception:
            return {}

        rows = []
        for zname, feats in features_by_zone.items():
            for f in feats:
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                p = g.asPoint()
                rows.append((p.x(), p.y(), zname))
        if len(rows) < 8:
            return {}

        lon0 = sum(r[0] for r in rows) / len(rows)
        lat0 = sum(r[1] for r in rows) / len(rows)
        if grouped_layer.crs().isGeographic():
            kx = 111320.0 * math.cos(math.radians(lat0))
            ky = 110540.0
        else:
            kx = ky = 1.0

        def inv(x, y, z=None):                       # metric → layer CRS
            return (lon0 + x / kx, lat0 + y / ky)

        P = np.array([((r[0] - lon0) * kx, (r[1] - lat0) * ky) for r in rows])
        labels = [r[2] for r in rows]
        if len({tuple(v) for v in np.round(P, 3)}) < 4:
            return {}

        mp = MultiPoint([tuple(xy) for xy in P])
        try:
            hull = shapely.concave_hull(mp, ratio=0.35)
            if hull.is_empty or hull.geom_type not in ("Polygon", "MultiPolygon"):
                raise ValueError
        except Exception:
            hull = mp.convex_hull
        span = float(max(P.max(0) - P.min(0)))
        hbuf = max(span * 0.01, 20.0)
        hull = hull.buffer(hbuf).buffer(-hbuf * 0.3)

        def finite_polys(vor, radius):
            regions, vertices = [], vor.vertices.tolist()
            center = vor.points.mean(axis=0)
            ridges = {}
            for (p1, p2), (v1, v2) in zip(vor.ridge_points, vor.ridge_vertices):
                ridges.setdefault(p1, []).append((p2, v1, v2))
                ridges.setdefault(p2, []).append((p1, v1, v2))
            for p1, region in enumerate(vor.point_region):
                verts = vor.regions[region]
                if all(v >= 0 for v in verts):
                    regions.append(verts)
                    continue
                nr = [v for v in verts if v >= 0]
                for p2, v1, v2 in ridges.get(p1, []):
                    if v2 < 0:
                        v1, v2 = v2, v1
                    if v1 >= 0:
                        continue
                    t = vor.points[p2] - vor.points[p1]
                    nn = np.linalg.norm(t)
                    if nn == 0:
                        continue
                    t = t / nn
                    nrm = np.array([-t[1], t[0]])
                    mid = vor.points[[p1, p2]].mean(axis=0)
                    direction = np.sign(np.dot(mid - center, nrm)) * nrm
                    nr.append(len(vertices))
                    vertices.append((vor.vertices[v2] + direction * radius).tolist())
                vs = np.asarray([vertices[v] for v in nr])
                c = vs.mean(axis=0)
                ang = np.arctan2(vs[:, 1] - c[1], vs[:, 0] - c[0])
                regions.append(np.array(nr)[np.argsort(ang)].tolist())
            return regions, np.asarray(vertices)

        try:
            vor = Voronoi(P)
        except Exception:
            return {}
        radius = span * 2 if span > 0 else 1000.0
        regions, verts = finite_polys(vor, radius)

        tiles = {}
        for zname in features_by_zone:
            cells = []
            for i, lab in enumerate(labels):
                if lab != zname:
                    continue
                try:
                    poly = Polygon(verts[regions[i]])
                    if poly.is_valid and not poly.is_empty:
                        cells.append(poly)
                except Exception:
                    continue
            if not cells:
                continue
            try:
                merged = unary_union(cells).intersection(hull)
            except Exception:
                continue
            if (not merged.is_empty) and isinstance(merged, (Polygon, MultiPolygon)):
                tiles[zname] = merged
        if not tiles:
            return {}

        # ③ Simplify the SHARED coverage edges CONSISTENTLY (topology-aware): adjacent tiles
        # stay gap-free AND overlap-free. Independent per-polygon simplify would slip the
        # shared edge and leave slivers (66 overlapping pairs in testing). coverage_simplify
        # (shapely 2.1) ~halves the vertex count for clean, straighter edges, zero overlap.
        # Falls back to the raw (already zero-overlap) Voronoi tiles if unavailable.
        znames = list(tiles.keys())
        geoms = [tiles[z] for z in znames]
        try:
            geoms = list(shapely.coverage_simplify(geoms, 40.0, simplify_boundary=True))
        except Exception:
            geoms = [tiles[z] for z in znames]

        out = {}
        for zname, g in zip(znames, geoms):
            try:
                if g is None or g.is_empty:
                    continue
                qg = QgsGeometry.fromWkt(shp_tf(inv, g).wkt)
                if qg and not qg.isEmpty():
                    out[zname] = qg
            except Exception:
                continue
        return out

    # ── Boundary-generation helpers (class-level so they aren't recreated ──
    # ── on every button click)                                            ──

    @staticmethod
    def _snap_parts_together(geom, bridge_r):
        """Connect all multipart fragments by bridging nearest-point pairs."""
        if not geom.isMultipart():
            return geom
        parts = list(geom.asGeometryCollection())
        while len(parts) > 1:
            min_d = float('inf')
            bi, bj = 0, 1
            bp1 = bp2 = None
            for ii in range(len(parts)):
                for jj in range(ii + 1, len(parts)):
                    d = parts[ii].distance(parts[jj])
                    if d < min_d:
                        min_d = d
                        bi, bj = ii, jj
                        bp1 = parts[ii].nearestPoint(parts[jj]).asPoint()
                        bp2 = parts[jj].nearestPoint(parts[ii]).asPoint()
            if bp1 is None or bp2 is None:
                break
            bridge = QgsGeometry.fromPolylineXY([
                QgsPointXY(bp1.x(), bp1.y()),
                QgsPointXY(bp2.x(), bp2.y()),
            ]).buffer(bridge_r, 4)
            merged_part = parts[bi].combine(parts[bj]).combine(bridge)
            parts = [parts[k] for k in range(len(parts)) if k != bi and k != bj]
            parts.append(merged_part)
        return parts[0] if parts else geom

    @staticmethod
    def _centroid_xy(pts):
        """Return (mean_x, mean_y) of a list of QgsPointXY."""
        if not pts:
            return (0, 0)
        return (sum(p.x() for p in pts) / len(pts),
                sum(p.y() for p in pts) / len(pts))

    @staticmethod
    def _force_single(geom, z_n, zone_build_params):
        """Rebuild a multipart geometry into one solid polygon."""
        if not geom.isMultipart():
            return geom
        zp = zone_build_params.get(z_n, {})
        radius_z = zp.get('radius', 5.0)
        result = FTTHPlanToolDockWidget._snap_parts_together(geom, radius_z)
        if not result.isMultipart():
            return result
        # NEVER convex-hull — a hull balloons the zone across the map (the #63 failure).
        # If parts still won't snap together, keep the largest single part instead.
        coll = result.asGeometryCollection()
        if coll:
            return max(coll, key=lambda g: g.area())
        return result

    @staticmethod
    def _make_combo_searchable(combo, max_visible=15):
        """Ticket #61: make a long splitter/group combo (a) type-to-search — the
        planner can type the splitter/group number instead of scrolling — and
        (b) show a real scrollbar in the drop-down popup. Safe on any QComboBox:
        the placeholder + index-based logic still work because we use NoInsert and
        a contains-filter completer, so picking a match still sets currentIndex."""
        from qgis.PyQt.QtWidgets import QComboBox, QCompleter
        from qgis.PyQt.QtCore import Qt
        try:
            combo.setEditable(True)
            combo.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
            combo.setMaxVisibleItems(max_visible)
            # combobox-popup:0 forces a scrollable QListView popup (with scrollbar)
            # instead of the native menu that only scrolls via edge arrows.
            combo.setStyleSheet(
                (combo.styleSheet() or "") + "\nQComboBox { combobox-popup: 0; }")
            comp = QCompleter(combo.model(), combo)
            comp.setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
            comp.setFilterMode(Qt.MatchFlag.MatchContains)
            comp.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
            combo.setCompleter(comp)
            _le = combo.lineEdit()
            if _le is not None:
                _le.setPlaceholderText("Type a number to search…")
            # Ticket #64 (CRITICAL): on an editable combo, picking a match from the
            # completer only sets the line-edit TEXT — currentIndex() stays stale, so
            # any handler that reads currentIndex()/currentData() (splitter delete,
            # add-demand) targets the WRONG row. Re-sync the index whenever the text
            # resolves to a real item, so currentIndex/currentData stay correct.
            def _sync_index(_txt=None):
                t = combo.currentText()
                i = combo.findText(t)
                if i >= 0 and i != combo.currentIndex():
                    combo.setCurrentIndex(i)
            comp.textActivated.connect(_sync_index)
            if _le is not None:
                _le.editingFinished.connect(_sync_index)
        except Exception:
            pass

    def on_generate_boundaries_clicked(self):
        """Generate one polygon boundary per PON zone from the grouped demand points layer."""
        # Prefer the stored reference; fall back to searching project layers by field
        grouped_layer = self.grouped_layer
        if not grouped_layer:
            # Pick the grouped layer with the MOST features to avoid stale partial layers
            _best_layer = None
            _best_count = -1
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    if 'zone_name' in [f.name() for f in layer.fields()]:
                        _fc = layer.featureCount()
                        if _fc > _best_count:
                            _best_count = _fc
                            _best_layer = layer
            grouped_layer = _best_layer

        if not grouped_layer:
            self.log_message("ERROR: No grouped PON layer found. Run 'Generate PON Groups' first.")
            return

        field_names = [f.name() for f in grouped_layer.fields()]
        if 'zone_name' not in field_names:
            self.log_message("ERROR: Layer has no 'zone_name' field. Run 'Generate PON Groups' first.")
            return

        has_zone_id = 'zone_id' in field_names
        is_point_layer = grouped_layer.geometryType() == 0

        self.log_message("\n=== Generating PON Zone Boundaries ===")
        self.log_message(f"Source layer: '{grouped_layer.name()}' ({grouped_layer.featureCount()} features)")
        if not self.grouped_layer:
            self.log_message("  (using project layer — if incomplete, re-run 'Generate PON Groups' first)")

        try:
            crs = grouped_layer.crs().authid()

            polygon_layer = QgsVectorLayer(
                f"Polygon?crs={crs}",
                f"{grouped_layer.name()} - PON Zones",
                "memory"
            )
            poly_provider = polygon_layer.dataProvider()
            poly_provider.addAttributes([
                QgsField('zone_name', QMetaType.Type.QString),
                QgsField('zone_id', QMetaType.Type.Int),
                QgsField('unit_count', QMetaType.Type.Int),
                QgsField('splitter_count', QMetaType.Type.Int),
            ])
            polygon_layer.updateFields()

            # Group field on the source layer — one PON group == one STS splitter,
            # so the number of distinct groups in a zone IS its splitter count
            # (used for the zone-boundary label, per the planner request).
            _grp_field = next(
                (fn for fn in field_names
                 if fn == 'group_id' or _DROP_GRP_RE.fullmatch(fn) or fn == 'batch_id'),
                None)  # #79: any group_<N> size, plus the splitter's group_id

            # Collect features per zone
            features_by_zone = {}
            zone_id_map = {}
            _total_feats = 0
            _null_zone_feats = 0
            _null_zone_list = []
            for feat in grouped_layer.getFeatures():
                _total_feats += 1
                z_name = feat['zone_name']
                if not z_name:
                    _null_zone_feats += 1
                    _null_zone_list.append(feat)
                    continue
                if z_name not in features_by_zone:
                    features_by_zone[z_name] = []
                    zone_id_map[z_name] = feat['zone_id'] if has_zone_id else 0
                features_by_zone[z_name].append(feat)
            self.log_message(f"Layer features: {_total_feats} total, "
                             f"{_total_feats - _null_zone_feats} with zone, "
                             f"{_null_zone_feats} with NULL zone_name (assigning to nearest zone)")

            # Assign NULL-zone features to the geographically nearest zone
            if _null_zone_list and features_by_zone:
                # Build one centroid per zone from its members
                _zone_cx = {}
                _zone_cy = {}
                for _zn, _zfeats in features_by_zone.items():
                    _gz = [_zf.geometry() for _zf in _zfeats]
                    _xs = [_g.centroid().asPoint().x()
                           for _g in _gz if _g and not _g.isEmpty()]
                    _ys = [_g.centroid().asPoint().y()
                           for _g in _gz if _g and not _g.isEmpty()]
                    if _xs:
                        _zone_cx[_zn] = sum(_xs) / len(_xs)
                        _zone_cy[_zn] = sum(_ys) / len(_ys)
                _zone_names_sorted = list(_zone_cx.keys())
                for _nf in (_null_zone_list if _zone_names_sorted else []):
                    _nf_geom = _nf.geometry()
                    if not _nf_geom or _nf_geom.isEmpty():
                        continue
                    _pt = _nf_geom.centroid().asPoint()
                    _best_z = min(
                        _zone_names_sorted,
                        key=lambda _zn: (_pt.x() - _zone_cx[_zn]) ** 2
                                       + (_pt.y() - _zone_cy[_zn]) ** 2
                    )
                    features_by_zone[_best_z].append(_nf)

            # ③ Voronoi-tiled boundaries (JJ 2026-06-25, HTML-approved): clean, straight-edged,
            # gap-free, non-overlapping zone tiles instead of rounded buffer blobs. Membership
            # is unchanged (uses each point's zone_name). Falls back to the buffer path per zone
            # if Voronoi can't be built for it.
            _voro = {}
            if is_point_layer:
                try:
                    _voro = self._voronoi_zone_polygons(grouped_layer, features_by_zone)
                    if _voro:
                        self.log_message(f"  Voronoi tiles: built {len(_voro)} clean zone polygons")
                except Exception as _ve:
                    self.log_message(f"  ⚠ Voronoi boundaries failed ({_ve}); using buffer fallback")
                    _voro = {}

            # Build one polygon per zone
            zone_polygons = []
            zone_build_params = {}   # z_name → {radius, mean_nn, coords}
            _total_zones = len(features_by_zone)

            self._start_timer()
            _QApp = QApplication
            _QApp.processEvents()
            for _bz_idx, (z_name, zone_feats) in enumerate(sorted(
                    features_by_zone.items(),
                    key=lambda kv: zone_id_map.get(kv[0], 0))):
                self._progress(_bz_idx + 1, _total_zones, 'Boundaries')

                geoms = [f.geometry() for f in zone_feats
                         if f.geometry() and not f.geometry().isEmpty()]
                if not geoms:
                    continue

                z_id = zone_id_map.get(z_name, 0)
                count = len(zone_feats)
                # splitter count = distinct groups in this zone (1 STS per group)
                if _grp_field:
                    splitter_count = len({_zf[_grp_field] for _zf in zone_feats
                                          if _zf[_grp_field] is not None})
                else:
                    splitter_count = 0

                if is_point_layer:
                    unit_type = grouped_layer.crs().mapUnits()
                    if unit_type == QgsUnitTypes.DistanceUnit.DistanceDegrees:
                        min_r, max_r = 0.00004, 0.00025   # ~4 m – 28 m at equator
                    else:
                        min_r, max_r = 4.0, 30.0           # metres

                    coords = [f.geometry().asPoint()
                              for f in zone_feats
                              if f.geometry() and not f.geometry().isEmpty()]

                    if len(coords) <= 1:
                        radius = max_r
                        mean_nn = max_r
                    else:
                        nn_sum, nn_count = 0.0, 0
                        for i, pt in enumerate(coords):
                            best = float('inf')
                            for j, other in enumerate(coords):
                                if i == j:
                                    continue
                                d = ((pt.x()-other.x())**2 +
                                     (pt.y()-other.y())**2) ** 0.5
                                if d < best:
                                    best = d
                            if best < float('inf'):
                                nn_sum += best
                                nn_count += 1
                        mean_nn = nn_sum / nn_count if nn_count else max_r
                        radius = max(min(mean_nn * 0.55, max_r), min_r)

                    # Buffer every point and union
                    merged = geoms[0].buffer(radius, 12)
                    for g in geoms[1:]:
                        merged = merged.combine(g.buffer(radius, 12))

                    # First: light morphological close to merge same-side gaps
                    close_r = radius * 0.5
                    candidate = merged.buffer(close_r, 8).buffer(-close_r, 8)
                    zone_geom = candidate if not candidate.isEmpty() else merged

                    # Second: if still multipart, directly snap parts together
                    if zone_geom.isMultipart():
                        zone_geom = self._snap_parts_together(zone_geom, radius)

                    # Last resort: convex hull (always single polygon)
                    if zone_geom.isMultipart():
                        zone_geom = zone_geom.convexHull()

                    # Store params for post-overlap consolidation
                    zone_build_params[z_name] = {
                        'radius': radius, 'mean_nn': mean_nn, 'coords': coords
                    }

                else:
                    # Dissolve parcel polygons then convex hull for a clean outer envelope
                    merged = geoms[0]
                    for g in geoms[1:]:
                        merged = merged.combine(g)
                    zone_geom = merged.convexHull()

                _vg = _voro.get(z_name)
                if _vg is not None and not _vg.isEmpty():
                    zone_geom = _vg     # ③ use the clean Voronoi tile for this zone

                poly_feat = QgsFeature(polygon_layer.fields())
                poly_feat.setGeometry(zone_geom)
                poly_feat.setAttributes([z_name, z_id, count, splitter_count])
                zone_polygons.append(poly_feat)

            # ── Remove overlaps between zone polygons ─────────────────────────
            # For any area where two zones overlap, assign it to whichever zone
            # has a demand point closer to that overlap region. (Voronoi tiles are
            # already disjoint, so this step is skipped when ③ Voronoi was used.)
            if not _voro and len(zone_polygons) > 1:
                # Build working list
                zone_data = []
                for pf in zone_polygons:
                    z = pf.attribute('zone_name')
                    pts = [f.geometry().asPoint()
                           for f in features_by_zone.get(z, [])
                           if f.geometry() and not f.geometry().isEmpty()]
                    zone_data.append([pf.geometry(), pts, pf])

                # Subtract overlaps: zone that owns an overlap area keeps it
                clipped_geoms = []
                for i, (g_i, pts_i, feat_i) in enumerate(zone_data):
                    clipped = g_i
                    z_name_i = feat_i.attribute('zone_name')
                    cx_i, cy_i = self._centroid_xy(pts_i)
                    for j, (g_j, pts_j, feat_j) in enumerate(zone_data):
                        if i == j:
                            continue
                        inter = clipped.intersection(g_j)
                        if inter.isEmpty():
                            continue
                        oc = inter.centroid().asPoint()
                        cx_j, cy_j = self._centroid_xy(pts_j)
                        di = (oc.x()-cx_i)**2 + (oc.y()-cy_i)**2
                        dj = (oc.x()-cx_j)**2 + (oc.y()-cy_j)**2
                        if dj < di:
                            diff = clipped.difference(inter)
                            if not diff.isEmpty():
                                clipped = diff
                            # If the difference fragmented the polygon, immediately
                            # consolidate back to a single polygon.
                            if clipped.isMultipart():
                                clipped = self._force_single(clipped, z_name_i, zone_build_params)
                    clipped_geoms.append(clipped)

                # Re-add any demand point that fell outside its clipped polygon
                unit_type = grouped_layer.crs().mapUnits()
                for i in range(len(clipped_geoms)):
                    z_n = zone_polygons[i].attribute('zone_name')
                    pts_i = zone_data[i][1]
                    if not pts_i:
                        continue
                    pad_r = zone_build_params.get(z_n, {}).get(
                        'radius',
                        0.000009 if unit_type == QgsUnitTypes.DistanceUnit.DistanceDegrees else 5.0
                    )
                    clipped = clipped_geoms[i]
                    for _pt in pts_i:
                        pt_geom = QgsGeometry.fromPointXY(_pt)
                        if not clipped.contains(pt_geom):
                            clipped = clipped.combine(pt_geom.buffer(pad_r, 8))
                    clipped_geoms[i] = clipped

                # Final pass: guarantee every zone is a single solid polygon
                for i in range(len(clipped_geoms)):
                    if clipped_geoms[i].isMultipart():
                        z_n = zone_polygons[i].attribute('zone_name')
                        clipped_geoms[i] = self._force_single(clipped_geoms[i], z_n, zone_build_params)

                for i, pf in enumerate(zone_polygons):
                    pf.setGeometry(clipped_geoms[i])

            poly_provider.addFeatures(zone_polygons)
            polygon_layer.updateExtents()

            # Categorised renderer — distinct colour per zone
            # For PON-per-PON batches, rotate hue by _pon_color_offset for visual separation
            _hue_base = getattr(self, '_pon_color_offset', 0.0)
            n = max(len(zone_polygons), 1)
            categories = []
            for i, pf in enumerate(zone_polygons):
                z_name = pf.attribute('zone_name')
                hue = (_hue_base + (i / n)) % 1.0
                r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.65, 0.88)]
                fill_col    = QColor(r, g, b, 70)
                outline_col = QColor(r, g, b, 230)
                sym = QgsFillSymbol.createSimple({
                    'color':         fill_col.name(QColor.NameFormat.HexArgb),
                    'outline_color': outline_col.name(),
                    'outline_width': '1.2',
                    'outline_style': 'solid',
                })
                categories.append(QgsRendererCategory(z_name, sym, z_name))

            polygon_layer.setRenderer(
                _categorized_with_catch_all(polygon_layer, 'zone_name', categories))

            # Labels — zone name + unit count + splitter count
            label_settings = QgsPalLayerSettings()
            label_settings.fieldName = (
                "zone_name || '\n' || unit_count || ' units' || "
                "'\n' || splitter_count || ' splitters'")
            label_settings.isExpression = True
            label_settings.enabled = True

            text_fmt = QgsTextFormat()
            text_fmt.setFont(QFont('Arial', 9, QFont.Weight.Bold))
            text_fmt.setSize(9)
            text_fmt.setColor(QColor('#1a1a1a'))

            buf = QgsTextBufferSettings()
            buf.setEnabled(True)
            buf.setSize(1.0)
            buf.setColor(QColor('white'))
            text_fmt.setBuffer(buf)
            label_settings.setFormat(text_fmt)

            # Ticket #52 — flag the zone label BRIGHT RED when a PON exceeds 16 splitters
            # (16 is the max; >16 is over capacity). Data-defined text colour.
            try:
                from qgis.core import QgsProperty
                label_settings.dataDefinedProperties().setProperty(
                    QgsPalLayerSettings.Color,
                    QgsProperty.fromExpression(
                        "CASE WHEN \"splitter_count\" > 16 THEN '#ff0000' ELSE '#1a1a1a' END"))
            except Exception as _e:
                self.log_message(f"  ⚠ splitter-overflow label colour skipped: {_e}")

            polygon_layer.setLabeling(QgsVectorLayerSimpleLabeling(label_settings))
            polygon_layer.setLabelsEnabled(True)

            polygon_layer = self._add_output_layer(polygon_layer)
            self.zone_boundaries_layer = polygon_layer  # store for PON-per-PON merge
            self.log_message(f"Layer: '{polygon_layer.name()}'")
            for pf in zone_polygons:
                self.log_message(
                    f"  {pf.attribute('zone_name')}: {pf.attribute('unit_count')} units")
            self._elapsed("Total time")

        except Exception as e:
            self.log_message(f"ERROR generating PON zone boundaries: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_generate_splitters_clicked(self):
        """Generate splitter points on span line for each group."""
        from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject, QgsField, QgsPointXY
        from qgis.PyQt.QtCore import QMetaType
        import math
        
        # Find the grouped layer — prefer the instance reference set by Step 1
        grouped_layer = None
        try:
            from qgis.PyQt import sip as _sip
            if self.grouped_layer and not _sip.isdeleted(self.grouped_layer):
                grouped_layer = self.grouped_layer
        except Exception:
            pass
        if not grouped_layer:
            # #4 anti-scatter: in a PON-per-PON BATCH the grouped layer MUST be the
            # batch's own layer (set by step 1). The name-search fallback below would
            # grab a stale full-project 'Groups of 8' layer left by an earlier standard
            # run and place splitters for the WHOLE project — scattering them far
            # outside the selection polygon. So in batch mode, refuse to guess.
            if getattr(self, '_current_batch_label', None):
                self.log_message(
                    "⛔ ERROR: PON-per-PON batch has no grouped layer from step 1 "
                    "(grouping failed for this batch) — splitters SKIPPED to avoid "
                    "placing them from a stale project-wide layer.")
                return
            # Fallback: find the most recently added grouped layer (highest feature count as tie-breaker)
            _best_layer = None
            _best_count = -1
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    layer_name = layer.name().lower()
                    if (('groups of 8' in layer_name or 'group of 8' in layer_name or
                         'groups of 16' in layer_name or 'group of 16' in layer_name or
                         'groups of 128' in layer_name or 'group of 128' in layer_name or
                         'groups of 100' in layer_name or 'group of 100' in layer_name) and
                       'boundary' not in layer_name and
                       'splitter' not in layer_name):
                        _fc = layer.featureCount()
                        if _fc > _best_count:
                            _best_count = _fc
                            _best_layer = layer
            if _best_layer:
                self.log_message(f"⚠ WARNING: self.grouped_layer was None — using fallback layer '{_best_layer.name()}' "
                                 f"({_best_count} features). Check if step 1 ran correctly for this batch.")
                grouped_layer = _best_layer
        
        if not grouped_layer:
            self.log_message("ERROR: Could not find grouped layer.")
            self.log_message("Please run 'Group Parcels/Points' first.")
            return
        
        # Get span layer — for PON-per-PON use the full (unfiltered) span so all
        # Distribution spans are available for snapping, not just those inside the polygon
        _full_span = getattr(self, '_pon_full_span_layer', None)
        if _full_span is not None:
            try:
                from qgis.PyQt import sip as _sip_fs
                if _sip_fs.isdeleted(_full_span):
                    _full_span = None
            except Exception:
                _full_span = None
        span_layer = _full_span or self.comboBox_span_layer.currentLayer()
        if not span_layer:
            self.log_message("ERROR: Please select a Route/Span layer.")
            return
        
        # Check for group field — #79: detect any group_<N> size (incl. HeroTel
        # group_32/64) or batch_id, not a fixed list.
        src_field_names = [f.name() for f in grouped_layer.fields()]
        group_field = _demand_group_field(src_field_names)
        if not group_field:
            self.log_message("ERROR: Layer must have a group_<N> (e.g. group_8/16/32/128) or batch_id field.")
            return

        # Detect aggregation zone field so each splitter records which zone it belongs to
        zone_field_src = None
        if 'zone_id' in src_field_names:
            zone_field_src = 'zone_id'
        elif 'group_100' in src_field_names:
            zone_field_src = 'group_100'
        # DISPLAY-ONLY per-zone numbering: the demand layer may carry group_local (the
        # per-zone rank 1..N). If present, the splitter copies it so its label shows the
        # same per-zone number the crews read on the demand (else falls back to group_id).
        local_field_src = 'group_local' if 'group_local' in src_field_names else None

        self.log_message("\n=== Generating Splitter Points ===")
        self.log_message(f"Source layer: '{grouped_layer.name()}'")
        self.log_message(f"Source layer feature count: {grouped_layer.featureCount()}")
        self.log_message(f"Source layer fields: {src_field_names}")
        self.log_message(f"Span layer: '{span_layer.name()}'")
        self.log_message(f"Group field detected: '{group_field}'")
        # Check if span layer has Cable Type field for filtering Distribution spans
        span_field_names = [f.name() for f in span_layer.fields()]
        has_cable_type = 'Cable Type' in span_field_names
        if has_cable_type:
            self.log_message("🎯 FILTERING: Splitters will ONLY snap to Distribution spans (Cable Type = 'Distribution')")
            self.log_message("   Feeder and other span types will be IGNORED for splitter placement.")
            # Check all unique Cable Type values and count Distribution spans
            cable_types_found = set()
            dist_count = 0
            for _sf in span_layer.getFeatures():
                ct = str(_sf['Cable Type'] or '').strip()
                cable_types_found.add(ct)
                if ct.lower() == 'distribution':
                    dist_count += 1
            self.log_message(f"   Cable Type values in span layer: {sorted(cable_types_found)}")
            self.log_message(f"   Found {dist_count} Distribution span features")
            if dist_count == 0:
                self.log_message(
                    "⚠ WARNING: No Distribution spans found — falling back to ALL spans for splitter placement."
                )
                has_cable_type = False  # disable filter so all spans are used
        else:
            self.log_message("⚠ WARNING: Span layer has no 'Cable Type' field — using ALL spans for splitter placement")
        
        try:
            crs = grouped_layer.crs().authid()
            
            # Build layer name — include batch label when running PON-per-PON
            _splitter_layer_name = "Splitter Points"
            if getattr(self, '_current_batch_label', None):
                _splitter_layer_name = f"Splitter Points - {self._current_batch_label}"

            # Create splitter points layer
            splitter_layer = QgsVectorLayer(f"Point?crs={crs}",
                                           _splitter_layer_name,
                                           "memory")
            provider = splitter_layer.dataProvider()
            
            # Add fields
            provider.addAttributes([
                QgsField('fid', QMetaType.Type.Int),
                QgsField('ID', QMetaType.Type.QString),
                QgsField('group_id', QMetaType.Type.Int),
                QgsField('zone_id', QMetaType.Type.Int),    # aggregation zone membership
                QgsField('drop_count', QMetaType.Type.Int),   # number of demand points in this group
                # group_local = the group's per-zone RANK (1..N within its zone). This is
                # a DISPLAY-ONLY companion to group_id (which stays globally-unique so all
                # drop routing + Manual Override are untouched). It is copied verbatim from
                # the demand layer's own group_local so the splitter label ALWAYS matches
                # the number crews read on the demand (guards the #114/#126 mismatch). Left
                # NULL when the demand has no group_local (old data) → label falls back to
                # group_id, exactly the #126 behaviour.
                QgsField('group_local', QMetaType.Type.Int),
                # Diagnostics (appended at the END so existing field indices are
                # unchanged and every downstream reader — all of which use field
                # NAMES — is unaffected): serve_m = median distance from the splitter
                # to the houses it serves; own_run = the span feature id it snapped
                # onto. Any future "weird spot" is now explainable from the table.
                QgsField('serve_m', QMetaType.Type.Double),
                QgsField('own_run', QMetaType.Type.Int),
            ])
            splitter_layer.updateFields()
            
            # --- Locate poles layer for snapping (optional) ---
            # The old detector ONLY matched a layer literally named 'poles_*' WITH a
            # 'pole_type' field — so real pole layers ("Poles v1", "Distribution
            # Poles", "Feeder Poles") were never found and splitters snapped to the
            # bare span line, never to a pole. Broaden it: a point layer is a pole
            # layer if its name reads as poles (and isn't a splitter/enclosure/
            # junction) OR it carries a pole-identifying field. Prefer a
            # distribution / v1 pole layer, then the most-populated (main network
            # poles), so STS splitters snap to the poles on their Distribution route.
            from qgis.core import QgsSpatialIndex
            poles_layer = None
            _pole_cands = []
            for lyr in QgsProject.instance().mapLayers().values():
                if not (isinstance(lyr, QgsVectorLayer) and lyr.geometryType() == 0):  # Point only
                    continue
                _pnm = lyr.name().lower()
                _pfields = {f.name().lower() for f in lyr.fields()}
                _name_is_pole = ('pole' in _pnm and not any(
                    x in _pnm for x in ('splitter', 'enclosure', 'junction', 'closure')))
                _field_is_pole = bool(_pfields & {'pole_id', 'pole_type', 'pole_thick', 'pole size', 'pole type'})
                if _name_is_pole or _field_is_pole:
                    _pole_cands.append(lyr)
            if _pole_cands:
                def _pole_rank(l):
                    n = l.name().lower()
                    # distribution/v1 poles first (the STS route), then feature count
                    return (('distribution' in n) or (' v1' in n) or n.endswith('v1'),
                            l.featureCount())
                poles_layer = max(_pole_cands, key=_pole_rank)
                self.log_message(
                    f"Pole layer for snapping: '{poles_layer.name()}' "
                    f"({poles_layer.featureCount()} poles; "
                    f"{len(_pole_cands)} pole layer(s) seen)")

            # Build spatial index + coordinate lookup for poles on DISTRIBUTION spans only
            pole_coords = {}   # feature_id -> QgsPointXY
            pole_index = None
            if poles_layer:
                # PRE-FILTER: Only include poles that are on Distribution spans
                # For each pole, check if it's within snap distance of a Distribution span
                distribution_pole_ids = set()
                pole_snap_tolerance = 5.0  # meters - poles within 5m of a Distribution span
                # Batch B: on a GEOGRAPHIC CRS the coords are degrees, so 5.0 was
                # ~550 km → every pole counted as "on a Distribution span". Convert
                # metres→degrees (projected CRS unchanged).
                try:
                    _pcrs = poles_layer.crs()
                    if _pcrs.isValid() and _pcrs.isGeographic():
                        import math as _mb1
                        _plat = poles_layer.extent().center().y()
                        pole_snap_tolerance = 5.0 / (111320.0 * max(0.1, _mb1.cos(_mb1.radians(_plat))))
                except Exception:
                    pass
                
                if has_cable_type:
                    # Build spatial index of Distribution spans
                    dist_span_index = QgsSpatialIndex()
                    dist_span_geoms = {}
                    for span_feat in span_layer.getFeatures():
                        if str(span_feat['Cable Type'] or '').strip().lower() == 'distribution':
                            dist_span_index.insertFeature(span_feat)
                            dist_span_geoms[span_feat.id()] = span_feat.geometry()
                    
                    # Check each pole against Distribution spans
                    for pf in poles_layer.getFeatures():
                        # Batch C: skip null/empty pole geometry (known null-geom
                        # poles exist) — asPoint() on null yields NaN that poisons
                        # the spatial index + nearest-pole snap.
                        _pg = pf.geometry()
                        if not _pg or _pg.isEmpty():
                            continue
                        pole_pt = _pg.asPoint()
                        pole_bbox = QgsRectangle(
                            pole_pt.x() - pole_snap_tolerance,
                            pole_pt.y() - pole_snap_tolerance,
                            pole_pt.x() + pole_snap_tolerance,
                            pole_pt.y() + pole_snap_tolerance
                        )
                        nearby_spans = dist_span_index.intersects(pole_bbox)
                        # If pole is near ANY Distribution span, include it
                        for span_id in nearby_spans:
                            span_geom = dist_span_geoms.get(span_id)
                            if span_geom and not span_geom.isEmpty():
                                pole_geom = QgsGeometry.fromPointXY(pole_pt)
                                dist = pole_geom.distance(span_geom)
                                if dist <= pole_snap_tolerance:
                                    distribution_pole_ids.add(pf.id())
                                    break
                    
                    self.log_message(f"Filtered poles: {len(distribution_pole_ids)} of {poles_layer.featureCount()} poles are on Distribution spans")
                else:
                    # No Cable Type field - use all poles
                    distribution_pole_ids = {pf.id() for pf in poles_layer.getFeatures()}
                
                # Build index only for Distribution poles
                if distribution_pole_ids:
                    pole_index = QgsSpatialIndex()
                    for pf in poles_layer.getFeatures():
                        if pf.id() in distribution_pole_ids:
                            _pg = pf.geometry()
                            if not _pg or _pg.isEmpty():
                                continue
                            pole_index.insertFeature(pf)
                            pole_coords[pf.id()] = _pg.asPoint()
                    self.log_message(f"Snapping splitters to nearest Distribution pole ('{poles_layer.name()}')")
                else:
                    self.log_message("No poles on Distribution spans — snapping splitters to span line directly")
            else:
                self.log_message("No poles layer found — snapping splitters to nearest span line point")

            # Group features by group_id (skip ungrouped features where group_id is None)
            features_by_group = {}
            _ungrouped_sp = 0
            for feat in grouped_layer.getFeatures():
                group_id = feat[group_field]
                # NULL group_id must be treated as ungrouped. On Qt5 a NULL is QVariant(NULL)
                # (has .isNull()), not None — it slipped this check, became a dict key, and
                # then aborted the WHOLE run at the sorted() log line below. Catch both forms.
                if group_id is None or (hasattr(group_id, 'isNull') and group_id.isNull()):
                    _ungrouped_sp += 1
                    continue
                if group_id not in features_by_group:
                    features_by_group[group_id] = []
                features_by_group[group_id].append(feat)
            if _ungrouped_sp:
                self.log_message(f"Skipping {_ungrouped_sp} ungrouped feature(s) (no group_id)")
            self.log_message(f"Groups found: {len(features_by_group)} (group IDs: {sorted(list(features_by_group.keys()))[:10]})")

            # BUGFIX: Guard against empty group dict — means step 1 produced no valid groups
            if not features_by_group:
                self.log_message("⛔ ERROR: No groups with valid group_id found in grouped layer.")
                self.log_message(f"   Layer: '{grouped_layer.name()}' has {grouped_layer.featureCount()} features but all have NULL group_id.")
                self.log_message("   This usually means step 1 (Group PON) failed or used the wrong layer.")
                self.log_message("   Re-draw the polygon selection and try again.")
                return

            # ----------------------------------------------------------------
            # Build spatial index of span geometries ONCE (fast per-group lookup)
            # ----------------------------------------------------------------
            from qgis.core import QgsSpatialIndex as _QSI2, QgsRectangle as _QRect2
            _snap_geoms = {}   # fid -> QgsGeometry
            _snap_index = _QSI2()
            _snap_count = 0
            for _sf in span_layer.getFeatures():
                if has_cable_type:
                    _ct = str(_sf['Cable Type'] or '').strip().lower()
                    if _ct != 'distribution':
                        continue
                _sg = _sf.geometry()
                if _sg and not _sg.isEmpty():
                    _snap_geoms[_sf.id()] = _sg
                    _snap_index.addFeature(_sf)
                    _snap_count += 1
            if _snap_count == 0 and has_cable_type:
                self.log_message("⚠ No Distribution spans indexed — falling back to all spans")
                for _sf in span_layer.getFeatures():
                    _sg = _sf.geometry()
                    if _sg and not _sg.isEmpty():
                        _snap_geoms[_sf.id()] = _sg
                        _snap_index.addFeature(_sf)
                        _snap_count += 1
            self.log_message(f"Span snap index: {_snap_count} feature(s) indexed")

            # Search radius for nearest-span lookup (expand if needed).
            # _SNAP_RADIUS = bbox half-size in LAYER UNITS (spatial-index prefilter only).
            # The real bound is a METRES cap (_SNAP_CAP_M) applied to the snap distance
            # below — the bbox is deliberately loose; the metres cap stops teleporting.
            _SNAP_RADIUS = 500.0
            _SNAP_CAP_M = 500.0            # accept only within this many METRES; one doubling → ~1 km hard cap
            _is_geo = False
            try:
                _scrs = span_layer.crs()
                if _scrs.isValid() and _scrs.isGeographic():
                    _is_geo = True
                    import math as _mb2
                    _slat = span_layer.extent().center().y()
                    _SNAP_RADIUS = 500.0 / (111320.0 * max(0.1, _mb2.cos(_mb2.radians(_slat))))
            except Exception:
                pass

            # Create splitter point for each group
            splitter_features = []
            total_groups_sp = len(features_by_group)
            _groups_skipped_error = 0
            _groups_no_span = 0   # groups with no Distribution span within a sane radius
            self.log_message(f"Processing {total_groups_sp} groups...")
            self._start_operation("Generating Splitter Points…")
            for sp_idx, (group_id, group_features) in enumerate(features_by_group.items()):
                self._progress(sp_idx + 1, total_groups_sp, 'Splitters')
                if self._cancel_check():
                    self.log_message("⛔ Splitter generation cancelled.")
                    return
                if not group_features:
                    continue

                try:
                    # Calculate centroid of all features in group
                    all_points = []
                    for feat in group_features:
                        geom = feat.geometry()
                        if geom and not geom.isEmpty():
                            centroid = geom.centroid().asPoint()
                            all_points.append(centroid)

                    if not all_points:
                        continue

                    # ANCHOR = MEDOID of the group's houses (the house with the smallest
                    # summed distance to the rest) — NOT the arithmetic mean. The mean of a
                    # scattered / L-shaped group lands in an empty gap and then snaps to a
                    # parallel span on the wrong street; the medoid always sits on a real
                    # house, so the nearest span is the one that actually serves the group.
                    # Distance in METRES on both CRS types, so the bounded-radius and
                    # pole-snap thresholds below compare directly in metres (no unit drift).
                    # Geographic: scale lon by cos(lat), then both axes by ~111.32 km/deg.
                    # Projected (metre units): plain Euclidean — do NOT apply cos(lat); its
                    # y is a northing, not a latitude, and cos(northing) corrupted every dist.
                    if _is_geo:
                        _coslat = math.cos(math.radians(all_points[0].y())) or 1.0

                        def _md(a, b, _c=_coslat):
                            return math.sqrt(((a.x() - b.x()) * _c) ** 2
                                             + (a.y() - b.y()) ** 2) * 111320.0
                    else:
                        def _md(a, b):
                            return math.sqrt((a.x() - b.x()) ** 2 + (a.y() - b.y()) ** 2)

                    if len(all_points) <= 2:
                        anchor = all_points[0]
                    else:
                        anchor = min(all_points,
                                     key=lambda p: sum(_md(p, q) for q in all_points))

                    # Snap the anchor to the nearest Distribution span — BOUNDED by a METRES
                    # cap. The bbox (layer units) is only a spatial-index prefilter: a long
                    # span can clip the box while its nearest point sits far outside it, so
                    # every candidate is ALSO checked against cap_m in metres and REJECTED if
                    # beyond it (that check is what stops teleporting — the bbox alone can't).
                    # Try base cap, then ONE doubling (~1 km); if still nothing within the
                    # cap, SKIP + flag the group instead of teleporting onto a far span.
                    best_dist_point = None
                    min_distance = float('inf')
                    _best_fid = None
                    radius = _SNAP_RADIUS      # bbox half-size, LAYER UNITS
                    cap_m = _SNAP_CAP_M        # accept cap, METRES
                    for _try in range(2):      # base then ONE doubling — never 4 km
                        bbox = _QRect2(
                            anchor.x() - radius, anchor.y() - radius,
                            anchor.x() + radius, anchor.y() + radius,
                        )
                        _anchor_geom = QgsGeometry.fromPointXY(anchor)
                        for fid in _snap_index.intersects(bbox):
                            _sg = _snap_geoms[fid]
                            nearest = _sg.nearestPoint(_anchor_geom)
                            if nearest.isEmpty():
                                continue
                            np_pt = nearest.asPoint()
                            d = _md(anchor, np_pt)   # METRES
                            if d > cap_m + 1e-6:
                                continue             # beyond the searched radius — never teleport
                            # strict improvement, or exact tie broken by lowest fid → stable
                            if d < min_distance - 1e-9 or (
                                    abs(d - min_distance) <= 1e-9
                                    and (_best_fid is None or fid < _best_fid)):
                                min_distance = d
                                best_dist_point = np_pt
                                _best_fid = fid
                        if best_dist_point is not None:
                            break
                        if _try == 0:     # expand once for the final try; don't inflate the reported cap after it
                            radius *= 2   # bbox (layer units)
                            cap_m *= 2    # accept cap (metres) in lockstep

                    if best_dist_point is None:
                        self.log_message(
                            f"   ⚠ Group {group_id}: no Distribution span within "
                            f"~{cap_m:.0f} m of its houses — splitter SKIPPED (review this group)")
                        _groups_no_span += 1
                        continue

                    # OWN-ROUTE GUARD (PON-per-PON fix): the medoid's nearest span is not
                    # always the run the GROUP is strung along — a polygon-edge group can
                    # snap onto a NEIGHBOURING street's cable that is nearer the medoid but
                    # far from most of the group's houses (the reported "wrong street"
                    # splitter). If the chosen span serves the houses poorly (large median
                    # house→span distance), re-pick the candidate span that best SERVES the
                    # houses and snap there instead. On dense standard groups the medoid-
                    # nearest span already IS the best-serving one, so the cheap median
                    # check passes (< floor) and this block does nothing.
                    try:
                        def _med_house_dist(_fid):
                            _g = _snap_geoms.get(_fid)
                            if _g is None:
                                return float('inf')
                            _dd = sorted(
                                _md(p, _g.nearestPoint(QgsGeometry.fromPointXY(p)).asPoint())
                                for p in all_points)
                            return _dd[len(_dd) // 2] if _dd else float('inf')
                        _chosen_med = _med_house_dist(_best_fid)
                        # Only investigate when the chosen span looks off for the houses
                        # (median house distance beyond a normal drop) — keeps the common
                        # good case cheap (no per-candidate rescan on standard runs).
                        if _chosen_med > 40.0:
                            _alt_fid, _alt_med = _best_fid, _chosen_med
                            _bbox2 = _QRect2(anchor.x() - radius, anchor.y() - radius,
                                             anchor.x() + radius, anchor.y() + radius)
                            for _cfid in _snap_index.intersects(_bbox2):
                                if _cfid == _best_fid:
                                    continue
                                _cm = _med_house_dist(_cfid)
                                if _cm < _alt_med - 1e-9 or (
                                        abs(_cm - _alt_med) <= 1e-9 and _cfid < _alt_fid):
                                    _alt_med, _alt_fid = _cm, _cfid
                            # override ONLY for a meaningfully better-serving span (≥30%)
                            if _alt_fid != _best_fid and _alt_med < _chosen_med * 0.7:
                                _alt_np = _snap_geoms[_alt_fid].nearestPoint(
                                    QgsGeometry.fromPointXY(anchor))
                                if _alt_np and not _alt_np.isEmpty():
                                    best_dist_point = _alt_np.asPoint()
                                    _best_fid = _alt_fid
                                    self.log_message(
                                        f"   ↪ Group {group_id}: medoid-nearest span served its "
                                        f"houses poorly (~{_chosen_med:.0f} m); snapped to its own "
                                        f"run instead (~{_alt_med:.0f} m)")
                    except Exception:
                        pass

                    # Pole snap: land the splitter ON a pole rather than floating mid-span.
                    # Poles are 40-60 m apart, so the old 10 m tolerance almost never fired;
                    # ~30 m (≈ half a span) snaps it to the nearest pole on the route.
                    # _md is METRES on both CRS types, so compare to 30.0 m directly.
                    nearest_point = best_dist_point
                    if pole_index and pole_coords:
                        _pole_cands = pole_index.nearestNeighbor(
                            QgsPointXY(best_dist_point.x(), best_dist_point.y()), 1)
                        if _pole_cands:
                            _pp = pole_coords[_pole_cands[0]]
                            _pd = _md(QgsPointXY(best_dist_point.x(), best_dist_point.y()), _pp)
                            if _pd <= 30.0:
                                nearest_point = _pp

                    # Create splitter point feature
                    splitter_feat = QgsFeature(splitter_layer.fields())
                    splitter_feat.setGeometry(QgsGeometry.fromPointXY(nearest_point))

                    drop_count = len(group_features)
                    # Robust against a NULL / typed-null zone: on Qt5 a NULL comes back as
                    # QVariant(NULL), which passes an `is not None` check and then throws on
                    # int() — dropping the WHOLE group's splitter (crews get no STS). Mirror
                    # the local_val guard below: try int(), fall back to the -1 sentinel.
                    zone_int = -1
                    if zone_field_src:
                        _zv = group_features[0][zone_field_src]
                        if _zv is not None:
                            try:
                                zone_int = int(_zv)
                            except (TypeError, ValueError):
                                zone_int = -1
                    # Copy the demand's per-zone rank verbatim so the splitter label
                    # matches what crews read on the demand (NULL when absent → #126).
                    local_val = None
                    if local_field_src:
                        _lv = group_features[0][local_field_src]
                        if _lv is not None:
                            try:
                                local_val = int(_lv)
                            except (TypeError, ValueError):
                                local_val = None
                    # Diagnostics: median distance from this splitter to the houses it
                    # serves + the span fid it sits on (see field defs above).
                    try:
                        _sv = sorted(_md(nearest_point, p) for p in all_points)
                        _serve_m = float(round(_sv[len(_sv) // 2], 1)) if _sv else -1.0
                    except Exception:
                        _serve_m = -1.0
                    # SANITY GATE: never ship a splitter absurdly far from the homes it
                    # serves (a symptom of bad input or a pathological group). 250 m is
                    # far beyond any real drop, so a good run never trips it; a garbage
                    # placement is skipped + flagged rather than shipped.
                    if 0 <= _serve_m > 250.0:
                        self.log_message(
                            f"   ⚠ Group {group_id}: splitter would sit ~{_serve_m:.0f} m from "
                            f"its own houses (absurd — check input layers) — SKIPPED.")
                        continue
                    _own_run = int(_best_fid) if _best_fid is not None else -1
                    splitter_feat.setAttributes([
                        int(group_id),  # fid
                        str(group_id),  # ID
                        int(group_id),  # group_id
                        zone_int,       # zone_id
                        drop_count,     # drop_count
                        local_val,      # group_local (per-zone rank, display-only)
                        _serve_m,       # serve_m (median house→splitter distance, m)
                        _own_run,       # own_run (span fid the splitter sits on)
                    ])
                    splitter_features.append(splitter_feat)

                except Exception as _grp_err:
                    _groups_skipped_error += 1
                    self.log_message(f"   ⚠ Group {group_id}: Exception — {_grp_err} (skipping this group, continuing)")

            if _groups_skipped_error:
                self.log_message(f"⚠ {_groups_skipped_error} group(s) skipped due to errors (see above)")
            if _groups_no_span:
                self.log_message(
                    f"⚠ {_groups_no_span} group(s) had NO Distribution span nearby — no splitter "
                    f"placed for them (review these; they'd have been teleported to a far span before).")
            if not splitter_features:
                self.log_message("⛔ ERROR: No splitter points generated for this batch — "
                                 "check span layer has Distribution features near demand points.")
                return
            
            # Add features to layer
            provider.addFeatures(splitter_features)
            splitter_layer.updateExtents()
            
            # Apply symbology - green circles
            symbol = QgsMarkerSymbol.createSimple({
                'name': 'circle',
                'color': '0,255,0',
                'outline_color': 'black',
                'outline_width': '0.5',
                'size': '4'
            })
            renderer = QgsSingleSymbolRenderer(symbol)
            splitter_layer.setRenderer(renderer)
            
            # Add labels showing drop count
            from qgis.core import QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings, QgsVectorLayerSimpleLabeling
            from qgis.PyQt.QtGui import QFont, QColor
            
            label_settings = QgsPalLayerSettings()
            # Label: "Grp <n> | Z<zone_id> [<drop_count>]"
            # <n> is the DISPLAY per-zone rank (group_local) when the demand carries it,
            # else the raw group_id. The #114/#126 rule still holds: the splitter shows the
            # SAME number the crews read on the demand — because group_local was copied
            # verbatim from the demand. coalesce() per-feature falls back to group_id for
            # any group with no local rank, so a mixed/old layer never shows a blank label.
            _grp_expr = 'coalesce("group_local", "group_id")' if local_field_src else '"group_id"'
            if zone_field_src:
                label_settings.fieldName = (
                    "'Grp ' || " + _grp_expr + " || ' | Z' || \"zone_id\" "
                    "|| ' [' || \"drop_count\" || ']'"
                )
                label_settings.isExpression = True
            else:
                label_settings.fieldName = "'Grp ' || " + _grp_expr + " || ' [' || \"drop_count\" || ']'"
                label_settings.isExpression = True
            label_settings.enabled = True
            label_settings.placement = QgsPalLayerSettings.AroundPoint
            
            text_format = QgsTextFormat()
            text_format.setFont(QFont('Arial', 8))
            text_format.setSize(8)
            text_format.setColor(QColor('black'))
            
            buffer_settings = QgsTextBufferSettings()
            buffer_settings.setEnabled(True)
            buffer_settings.setSize(1.0)
            buffer_settings.setColor(QColor('white'))
            text_format.setBuffer(buffer_settings)
            
            label_settings.setFormat(text_format)
            
            labeling = QgsVectorLayerSimpleLabeling(label_settings)
            splitter_layer.setLabeling(labeling)
            splitter_layer.setLabelsEnabled(True)
            
            # Add layer to project
            splitter_layer = self._add_output_layer(splitter_layer)
            
            # Store reference for drop cable generation
            self.splitter_points_layer = splitter_layer
            
            # Calculate statistics
            total_drops = sum(f['drop_count'] for f in splitter_features)
            max_drops = max((f['drop_count'] for f in splitter_features), default=0)
            min_drops = min((f['drop_count'] for f in splitter_features), default=0)
            
            self.log_message(f"\nCreated {len(splitter_features)} splitter points")
            self._elapsed("Total time")
            self.log_message(f"  Total demand points: {total_drops}")
            self.log_message(f"  Max drops per splitter: {max_drops}")
            self.log_message(f"  Min drops per splitter: {min_drops}")
            self.log_message(f"Layer: '{splitter_layer.name()}'")
            if zone_field_src:
                self.log_message(f"PON membership sourced from field '{zone_field_src}'")
                self.log_message("Label shows: Zone ID [drop count]")
            else:
                self.log_message("No zone field found — zone_id set to -1; label shows drop count only")
            self.log_message("Splitters placed on span line for each group")
            
        except Exception as e:
            self.log_message(f"ERROR generating splitters: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def _build_road_crossing_checker(self, demand_crs=None):
        """Return a callable _crosses_road(x1,y1,x2,y2)->bool using the current road layer.

        Returns a no-op function (always False) if no road layer is selected.
        Handles CRS mismatch between demand layer and road layer.
        """
        from qgis.core import QgsGeometry, QgsPointXY, QgsProject
        road_layer = self.comboBox_road_layer.currentLayer() if hasattr(self, 'comboBox_road_layer') else None
        if road_layer is None:
            return lambda x1, y1, x2, y2: False

        road_geom_by_id = {}
        road_index = QgsSpatialIndex()
        _road_transform = None
        try:
            road_crs = road_layer.crs()
            if demand_crs is not None and demand_crs.isValid() and road_crs.isValid() and demand_crs != road_crs:
                _road_transform = QgsCoordinateTransform(demand_crs, road_crs, QgsProject.instance())
            for rf in road_layer.getFeatures():
                rg = rf.geometry()
                if rg and not rg.isEmpty():
                    road_geom_by_id[rf.id()] = rg
                    road_index.addFeature(rf)
        except Exception:
            return lambda x1, y1, x2, y2: False

        def _crosses_road(x1, y1, x2, y2):
            if not road_geom_by_id:
                return False
            if _road_transform is not None:
                try:
                    p1 = _road_transform.transform(QgsPointXY(x1, y1))
                    p2 = _road_transform.transform(QgsPointXY(x2, y2))
                except Exception:
                    p1, p2 = QgsPointXY(x1, y1), QgsPointXY(x2, y2)
            else:
                p1, p2 = QgsPointXY(x1, y1), QgsPointXY(x2, y2)
            line = QgsGeometry.fromPolylineXY([p1, p2])
            bbox = line.boundingBox()
            bbox.grow(max(abs(p2.x() - p1.x()), abs(p2.y() - p1.y())) * 0.05 + 1e-9)
            for fid in road_index.intersects(bbox):
                rg = road_geom_by_id.get(fid)
                if rg and line.intersects(rg) and not line.touches(rg):
                    return True
            return False

        return _crosses_road

    # ---- Tickets #111/#112: persistent manual road-cross approvals --------------
    def _force_cross_key(self, layer):
        """(scope, key) under which a demand layer's manual road-cross approvals live."""
        import re as _re_fc
        lid = "none"
        try:
            if layer is not None:
                lid = _re_fc.sub(r'[^A-Za-z0-9_]', '_', layer.id())
        except Exception:
            lid = "none"
        return ("VelocityFibre", "NetworkPlanner/force_cross/" + lid)

    def _load_force_cross(self, layer):
        """Demand-point FIDs the planner manually approved to route across a road, read
        back from the project. Persisting this set (tickets #111/#112) is what makes a
        manual drop reassignment survive a dialog close / zone revisit / Regenerate
        Drops / project reload — otherwise every regen re-applies the road barrier and
        the planner's manually-routed drops are skipped and silently deleted."""
        from qgis.core import QgsProject
        if layer is None:
            return set()
        try:
            scope, key = self._force_cross_key(layer)
            raw, ok = QgsProject.instance().readEntry(scope, key, "")
            if ok and raw:
                out = set()
                for tok in raw.split(","):
                    try:
                        out.add(int(tok.strip()))
                    except (TypeError, ValueError):
                        continue
                return out
        except Exception:
            pass
        return set()

    def _save_force_cross(self, layer, fids):
        """Persist the manual road-cross approval set on the project (see _load_force_cross).
        Monotonic: only ever adds, never clears, so a stray empty call can't wipe approvals."""
        from qgis.core import QgsProject
        if layer is None or not fids:
            return
        try:
            scope, key = self._force_cross_key(layer)
            QgsProject.instance().writeEntry(
                scope, key, ",".join(str(int(x)) for x in sorted(fids)))
        except Exception:
            pass

    # ---- Ticket #113: "show all drops" — draw every drop even across a road --------
    def _show_all_drops(self):
        """True when the planner chose to draw EVERY drop, ignoring the road barrier
        (ticket #113 — Luke wanted visual proof of all connections). Persisted on the
        project so it survives reload. OFF by default so the road barrier still applies
        for planners (e.g. Rico, #68) who rely on road-crossing drops being skipped."""
        from qgis.core import QgsProject
        try:
            raw, ok = QgsProject.instance().readEntry("VelocityFibre", "NetworkPlanner/show_all_drops", "0")
            return bool(ok and str(raw).strip() in ("1", "true", "True"))
        except Exception:
            return False

    def _set_show_all_drops(self, on):
        from qgis.core import QgsProject
        try:
            QgsProject.instance().writeEntry(
                "VelocityFibre", "NetworkPlanner/show_all_drops", "1" if on else "0")
        except Exception:
            pass

    def on_generate_drop_lashed_clicked(self, force_cross_fids=None):
        """Generate drop cables that follow the span network for drops >50 m (aerial lashed).

        force_cross_fids: demand FIDs the planner MANUALLY assigned (Manual Override) —
        their drops are allowed to cross a road even though the auto road-barrier would
        skip them (ticket #94, mirrors on_generate_drop_ptp_clicked). A bool from a
        button's clicked signal is treated as 'no overrides'."""
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject,
                               QgsField, QgsPointXY,
                               QgsUnitTypes,
                               QgsRuleBasedRenderer)
        from qgis.PyQt.QtCore import QMetaType
        import math
        
        # Try to use stored layer references first, then search if needed
        demand_points_layer = None
        splitter_points_layer = None
        
        # Check if stored references are valid
        try:
            if self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                demand_points_layer = self.demand_points_layer
                self.log_message(f"Using stored demand points layer: '{demand_points_layer.name()}'")
        except Exception:            pass
        
        try:
            if self.splitter_points_layer and not sip.isdeleted(self.splitter_points_layer):
                splitter_points_layer = self.splitter_points_layer
                self.log_message(f"Using stored splitter points layer: '{splitter_points_layer.name()}'")
        except Exception:            pass
        
        # Find demand points layer if not stored — prefer point geometry over polygon
        if not demand_points_layer:
            _dm_candidates = []
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    layer_name = layer.name().lower()
                    if 'demand points' in layer_name or 'demand_points' in layer_name:
                        _dm_candidates.append(layer)
            # Prefer point (geometryType 0) layers; fall back to first match
            _pt_layers = [l for l in _dm_candidates if l.geometryType() == 0]
            if _pt_layers:
                demand_points_layer = _pt_layers[0]
            elif _dm_candidates:
                demand_points_layer = _dm_candidates[0]
            if demand_points_layer:
                self.log_message(f"Found demand points layer: '{demand_points_layer.name()}'")

        if not demand_points_layer:
            self.log_message("ERROR: Could not find demand points layer.")
            self.log_message("Please generate demand points first.")
            return
        
        # Find splitter points layer if not stored
        if not splitter_points_layer:
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    layer_name = layer.name().lower()
                    if 'splitter' in layer_name and layer.geometryType() == 0:  # Point layer
                        splitter_points_layer = layer
                        self.log_message(f"Found splitter points layer: '{splitter_points_layer.name()}'")
                        break
        
        if not splitter_points_layer:
            self.log_message("ERROR: Could not find splitter points layer.")
            self.log_message("Please generate splitter points first.")
            return
        
        self.log_message("\n=== Generating Drop Cables Lashed ===")
        self.log_message(f"Demand points: '{demand_points_layer.name()}'")
        self.log_message(f"Splitters: '{splitter_points_layer.name()}'")
        
        try:
            crs = demand_points_layer.crs().authid()
            
            # Build layer name — batch-specific to preserve previous PON-per-PON runs
            _lashed_layer_name = "Drop Cables Lashed"
            if getattr(self, '_current_batch_label', None):
                _lashed_layer_name = f"Drop Cables Lashed - {self._current_batch_label}"

            # Remove existing layer of the SAME name only (don't touch other batches)
            for layer in list(QgsProject.instance().mapLayers().values()):
                if isinstance(layer, QgsVectorLayer) and layer.name() == _lashed_layer_name:
                    self.log_message(f"Updating existing {_lashed_layer_name} layer...")
                    QgsProject.instance().removeMapLayer(layer.id())
                    break

            # Create drop cables layer
            drop_cable_layer = QgsVectorLayer(f"LineString?crs={crs}",
                                             _lashed_layer_name,
                                             "memory")
            provider = drop_cable_layer.dataProvider()
            
            # Add fields - including fiber count from cable profile system
            provider.addAttributes([
                QgsField('cable_id', QMetaType.Type.Int),
                QgsField('group_id', QMetaType.Type.Int),
                QgsField('demand_id', QMetaType.Type.Int),
                QgsField('fiber_count', QMetaType.Type.Int),
                QgsField('fiber_size', QMetaType.Type.QString),
                QgsField('via_span', QMetaType.Type.Int),      # 1 = routed via span; 0 = direct
                QgsField('cable_length', QMetaType.Type.Double),   # length in METRES (QgsDistanceArea)
                QgsField('zone_id', QMetaType.Type.Int),      # aggregation zone membership
            ])
            drop_cable_layer.updateFields()
            
            # Add virtual field for length using $length expression
            from qgis.core import QgsField
            length_field = QgsField('length', QMetaType.Type.Double)
            length_field.setLength(10)
            length_field.setPrecision(2)
            drop_cable_layer.addExpressionField('$length', length_field)
            
            # Drop cables typically use smallest profile (1-2 fibers per customer)
            drop_fiber_count = get_cable_profile(1, PROFILE_TYPE_DEFAULT)  # 2F minimum
            drop_fiber_size = format_cable_profile(drop_fiber_count)
            self.log_message(f"Drop cable profile: {drop_fiber_size} (1 fiber per customer + spare)")
            
            # Get splitters indexed by group_id; also build zone lookup (group_id -> zone_id)
            splitters_by_group = {}
            zone_by_group = {}
            _sp_has_zone = 'zone_id' in [f.name() for f in splitter_points_layer.fields()]
            # Experiment-found bug: transform splitter points into the demand CRS when the
            # two layers differ (mixed import) so drops don't shoot off the map.
            _sp_xform = None
            try:
                from qgis.core import QgsCoordinateTransform
                _scrs = splitter_points_layer.crs(); _dcrs = demand_points_layer.crs()
                if _scrs.isValid() and _dcrs.isValid() and _scrs != _dcrs:
                    _sp_xform = QgsCoordinateTransform(_scrs, _dcrs, QgsProject.instance())
            except Exception:
                _sp_xform = None
            for _sp in splitter_points_layer.getFeatures():
                # Batch D: normalise the key to int (mirror the PTP path). Keying by
                # the raw QVariant let an int-vs-QVariant/str mismatch silently miss
                # every demand point of a group → whole groups of drops skipped.
                _sgid = _sp['group_id']
                if _sgid is None:
                    continue
                try:
                    _sgid = int(_sgid)
                except (TypeError, ValueError):
                    continue
                _sgeom = _sp.geometry()
                if _sgeom and not _sgeom.isEmpty():
                    # Experiment-found bug: a dict overwrite sent ALL of a group's drops
                    # to the LAST splitter sharing that group_id (often a far one). Keep
                    # every splitter per group and connect each demand to the NEAREST.
                    _spt = _sgeom.asPoint()
                    if _sp_xform is not None:
                        try:
                            _spt = _sp_xform.transform(_spt)
                        except Exception:
                            pass
                    splitters_by_group.setdefault(_sgid, []).append(_spt)
                if _sp_has_zone:
                    _zv = _sp['zone_id']
                    zone_by_group[_sgid] = int(_zv) if _zv is not None else -1

            self.log_message(f"Found {len(splitters_by_group)} splitter groups: {sorted(splitters_by_group.keys())}")

            # ---- Via-span routing setup ----------------------------------------
            # Drop cables longer than VIA_SPAN_THRESHOLD are routed to the nearest
            # point on the span line first, then onward to the splitter.
            # For PON-per-PON use the full span layer so routing covers the whole network
            _full_span_l = getattr(self, '_pon_full_span_layer', None)
            if _full_span_l is not None:
                try:
                    from qgis.PyQt import sip as _sip_fl
                    if _sip_fl.isdeleted(_full_span_l):
                        _full_span_l = None
                except Exception:
                    _full_span_l = None
            span_layer = _full_span_l or self.comboBox_span_layer.currentLayer()
            span_feats = {}
            span_index = None
            crs_units = demand_points_layer.crs().mapUnits()
            is_geographic = (crs_units == QgsUnitTypes.DistanceUnit.DistanceDegrees)
            # VIA_SPAN_THRESHOLD is in CRS units — it is compared against the
            # Cartesian `direct_dist` (also CRS units) to decide via-span routing,
            # so it must stay in degrees on a geographic CRS to match.
            VIA_SPAN_THRESHOLD = 0.00045 if is_geographic else 50.0  # ~50 m
            # cable_length is stored in true METRES via QgsDistanceArea so the
            # attribute table, the renderer (>50 m) and the warning label all agree
            # regardless of input CRS (spec: distances in projected metres).
            from qgis.core import QgsDistanceArea
            _drop_da = QgsDistanceArea()
            _drop_da.setSourceCrs(demand_points_layer.crs(), QgsProject.instance().transformContext())
            _drop_da.setEllipsoid(_safe_ellipsoid(QgsProject.instance(), demand_points_layer.crs()))
            DROP_WARN_M = 50.0  # spec: drop cables <=50 m (hard)
            if span_layer:
                span_feats = {f.id(): f for f in span_layer.getFeatures()}
                span_index = QgsSpatialIndex(span_layer.getFeatures())
                self.log_message(
                    f"Span layer: '{span_layer.name()}' ({len(span_feats)} segments)"
                    f" — cables >{VIA_SPAN_THRESHOLD:.0f} map units will follow span network")
            else:
                self.log_message("No span layer selected — all drop cables will be direct")

            # Build routing graph and pre-compute splitter snap points
            span_graph = None
            seg_ep = {}
            splitter_snaps = {}  # group_id -> (snap_pt, snap_fid)
            if span_feats:
                span_graph, seg_ep = _build_span_routing_graph(span_feats)
                self.log_message(
                    f"Routing graph: {span_graph.number_of_nodes()} nodes, "
                    f"{span_graph.number_of_edges()} edges")
                for _gid, _spts in splitters_by_group.items():
                    _spt = _spts[0] if _spts else None   # values are now lists (dup-group fix)
                    if _spt is None:
                        continue
                    _nearest = span_index.nearestNeighbor(_spt, 5)
                    _best_snap, _best_fid, _best_d = None, None, float('inf')
                    for _fid in _nearest:
                        _sg = span_feats[_fid].geometry()
                        _near = _sg.nearestPoint(QgsGeometry.fromPointXY(_spt))
                        if _near.isEmpty():
                            continue
                        _np = _near.asPoint()
                        _d = math.sqrt((_spt.x() - _np.x()) ** 2 + (_spt.y() - _np.y()) ** 2)
                        if _d < _best_d:
                            _best_d = _d
                            _best_snap = QgsPointXY(_np.x(), _np.y())
                            _best_fid = _fid
                    splitter_snaps[_gid] = (_best_snap, _best_fid)
            # -------------------------------------------------------------------

            # Check what fields exist in demand points
            demand_fields = [f.name() for f in demand_points_layer.fields()]
            self.log_message(f"Demand points fields: {demand_fields}")
            # #79: the group-link field is a layer CONSTANT — resolve it ONCE here
            # instead of rescanning demand_fields for every demand point in the loop.
            _drop_grp_field = next((fn for fn in demand_fields
                                    if _DROP_GRP_RE.fullmatch(fn) or fn == 'batch_id'), None)

            # Road crossing check — skip drops whose direct demand→splitter line crosses a road
            _crosses_road_lashed = self._build_road_crossing_checker(demand_points_layer.crs())
            # manually-assigned drops (Manual Override) allowed to cross a road (ticket #94).
            # A bool (from a button's clicked signal) means "no overrides".
            _fcl = force_cross_fids if isinstance(force_cross_fids, (set, frozenset, list, tuple)) else set()
            _fcl = set(_fcl)
            _show_all_l = self._show_all_drops()   # ticket #113: draw every drop, ignore road barrier
            _road_lyr = self.comboBox_road_layer.currentLayer() if hasattr(self, 'comboBox_road_layer') else None
            if _road_lyr and _show_all_l:
                self.log_message(f"Show all drops ON (#113) — road barrier '{_road_lyr.name()}' "
                                 "IGNORED; every drop drawn (incl. road crossings).")
            elif _road_lyr:
                _ovl = f" ({len(_fcl)} manually-assigned drop(s) allowed to cross)" if _fcl else ""
                self.log_message(f"Road barrier active: '{_road_lyr.name()}' — drops crossing roads will be skipped{_ovl}")

            # Create drop cable for each demand point to its group's splitter
            cable_features = []
            cable_id = 1
            skipped_no_group = 0
            skipped_no_splitter = 0
            skipped_road_cross = 0
            groups_found = set()
            connections_by_group = {}
            total_demand = demand_points_layer.featureCount()
            self.log_message(f"Connecting {total_demand} demand points to splitters...")
            self._start_operation("Generating Drop Cables Lashed…")
            for dc_idx, demand_point in enumerate(demand_points_layer.getFeatures()):
                self._progress(dc_idx + 1, total_demand, 'Drop cables')
                if self._cancel_check():
                    self.log_message("⛔ Drop cables (lashed) generation cancelled.")
                    return
                demand_geom = demand_point.geometry()
                if not demand_geom or demand_geom.isEmpty():
                    continue
                # Use centroid for polygon/line layers so non-point sources work correctly
                if demand_geom.type() == 0:  # Point
                    demand_pt = demand_geom.asPoint()
                else:
                    demand_pt = demand_geom.centroid().asPoint()
                
                # #79: match the demand group-link field by PATTERN (group_<N> any
                # size, incl. HeroTel group_32/group_64, or batch_id) — a hardcoded
                # list silently skipped sizes it didn't name, so drops never linked
                # to their dedicated splitter on those projects.
                # Batch D: normalise to int so the splitters_by_group lookup below
                # can't miss on an int-vs-QVariant type mismatch.
                group_id = None
                if _drop_grp_field is not None:
                    _raw = demand_point[_drop_grp_field]
                    if _raw is not None:
                        try:
                            group_id = int(_raw)
                        except (TypeError, ValueError):
                            group_id = None
                    if group_id is not None:
                        groups_found.add(group_id)

                if group_id is None:
                    skipped_no_group += 1
                    continue
                
                # Get splitter for this group (each demand point connects to splitter with matching group_id)
                if group_id not in splitters_by_group:
                    skipped_no_splitter += 1
                    continue
                
                _sp_cands = splitters_by_group[group_id]
                splitter_pt = (_sp_cands[0] if len(_sp_cands) == 1 else
                               min(_sp_cands, key=lambda _c: (_c.x()-demand_pt.x())**2
                                   + (_c.y()-demand_pt.y())**2))

                # Straight-line distance from demand point to splitter
                direct_dist = math.sqrt(
                    (demand_pt.x() - splitter_pt.x()) ** 2 +
                    (demand_pt.y() - splitter_pt.y()) ** 2
                )

                # Via-span routing: cables beyond threshold follow the span network
                # path: demand_pt → snap_on_span → [span] → snap_on_span → splitter_pt
                via_span_used = 0
                if span_index and span_feats and direct_dist > VIA_SPAN_THRESHOLD:
                    # Find nearest point on span for this demand point
                    snap_d, snap_d_fid, min_snap_d = None, None, float('inf')
                    for fid in span_index.nearestNeighbor(demand_pt, 5):
                        sg = span_feats[fid].geometry()
                        if not sg or sg.isEmpty():
                            continue
                        near_geom = sg.nearestPoint(QgsGeometry.fromPointXY(demand_pt))
                        if near_geom.isEmpty():
                            continue
                        np_pt = near_geom.asPoint()
                        d = math.sqrt((demand_pt.x() - np_pt.x()) ** 2 +
                                      (demand_pt.y() - np_pt.y()) ** 2)
                        if d < min_snap_d:
                            min_snap_d = d
                            snap_d = QgsPointXY(np_pt.x(), np_pt.y())
                            snap_d_fid = fid

                    snap_s, snap_s_fid = splitter_snaps.get(group_id, (None, None))

                    if snap_d and snap_s and span_graph:
                        span_pts = _span_route_pts(
                            snap_d, snap_d_fid, snap_s, snap_s_fid, span_graph, seg_ep)
                        if span_pts:
                            line_geom = QgsGeometry.fromPolylineXY(
                                [demand_pt] + span_pts + [splitter_pt])
                            via_span_used = 1
                        else:
                            # No graph path — fall back to simple 3-point line
                            line_geom = QgsGeometry.fromPolylineXY(
                                [demand_pt, snap_d, snap_s, splitter_pt])
                            via_span_used = 1
                    elif snap_d:
                        line_geom = QgsGeometry.fromPolylineXY(
                            [demand_pt, snap_d, splitter_pt])
                        via_span_used = 1
                    else:
                        line_geom = QgsGeometry.fromPolylineXY([demand_pt, splitter_pt])
                else:
                    line_geom = QgsGeometry.fromPolylineXY([demand_pt, splitter_pt])

                # Create feature (length auto-calculated by virtual field)
                # Skip drop if the direct demand→splitter line crosses a road — UNLESS
                # the planner manually assigned this demand point (its FID in _fcl), in
                # which case the planner's choice is honoured and the drop is forced
                # across the road (ticket #94).
                if (not _show_all_l) and (demand_point.id() not in _fcl) and _crosses_road_lashed(
                        demand_pt.x(), demand_pt.y(),
                        splitter_pt.x(), splitter_pt.y()):
                    skipped_road_cross += 1
                    continue

                cable_feat = QgsFeature(drop_cable_layer.fields())
                cable_feat.setGeometry(line_geom)
                cable_feat.setAttributes([
                    cable_id,
                    int(group_id),
                    int(demand_point.id()),
                    drop_fiber_count,
                    drop_fiber_size,
                    via_span_used,
                    round(_drop_da.measureLength(line_geom), 2),  # METRES — used by renderer
                    zone_by_group.get(int(group_id), -1),  # zone_id
                ])
                
                cable_features.append(cable_feat)
                
                # Track connections per group
                if group_id not in connections_by_group:
                    connections_by_group[group_id] = 0
                connections_by_group[group_id] += 1
                
                cable_id += 1
            
            self.log_message(f"Demand point groups found: {sorted(groups_found)}")
            self.log_message(f"Connections per group: {dict(sorted(connections_by_group.items()))}")
            if skipped_no_group > 0:
                self.log_message(f"Warning: {skipped_no_group} demand points had no group_id field")
            if skipped_no_splitter > 0:
                self.log_message(f"Warning: {skipped_no_splitter} demand points had no matching splitter")
                self.log_message(f"  Splitter groups: {sorted(splitters_by_group.keys())}")
                self.log_message(f"  Demand groups:   {sorted(groups_found)}")
            if skipped_road_cross > 0:
                self.log_message(f"🚫 Road barrier: {skipped_road_cross} drop(s) crossed a road — skipped")
            
            if len(cable_features) == 0:
                self.log_message("ERROR: No drop cables were created!")
                self.log_message("Please check that:")
                self.log_message("  1. Demand points have group_8, group_16, group_128, or group_100 field")
                self.log_message("  2. Splitters have matching group_id values")
                return
            
            # Add features to layer
            provider.addFeatures(cable_features)
            drop_cable_layer.updateExtents()
            
            # Apply rule-based symbology using stored cable_length field (METRES):
            #   cable_length > DROP_WARN_M (50 m)  → neon orange solid (warning)
            #   cable_length <= DROP_WARN_M (50 m) → red dashed (normal)
            # Use cookbook-style construction: renderer from default sym, then replace rules
            renderer = QgsRuleBasedRenderer(
                QgsLineSymbol.createSimple({'color': '220,0,0', 'width': '0.5', 'line_style': 'dash'}))
            root_rule = renderer.rootRule()
            for _r in root_rule.children()[:]:
                root_rule.removeChild(_r)
            rule_warn = QgsRuleBasedRenderer.Rule(
                QgsLineSymbol.createSimple({'color': '255,140,0', 'width': '0.8', 'line_style': 'solid'}))
            rule_warn.setFilterExpression(f'"cable_length" > {DROP_WARN_M}')
            rule_warn.setLabel('Drop >50 m (WARNING)')
            root_rule.appendChild(rule_warn)
            rule_normal = QgsRuleBasedRenderer.Rule(
                QgsLineSymbol.createSimple({'color': '220,0,0', 'width': '0.5', 'line_style': 'dash'}))
            # Batch A: ELSE catch-all — a drop with NULL/absent cable_length fails
            # BOTH "> threshold" and "<= threshold" (NULL comparisons are NULL), so
            # without an ELSE it would paint nothing. ELSE catches everything the
            # warn rule didn't.
            rule_normal.setFilterExpression('ELSE')
            rule_normal.setLabel('Drop ≤50 m')
            root_rule.appendChild(rule_normal)
            drop_cable_layer.setRenderer(renderer)
            
            # Add layer to project
            drop_cable_layer = self._add_output_layer(drop_cable_layer)
            
            # Calculate total length from the added features (virtual field will be populated)
            total_length = 0
            over_warn = 0
            for feat in drop_cable_layer.getFeatures():
                # cable_length is now in true METRES (QgsDistanceArea)
                fl = feat['cable_length'] if feat['cable_length'] else 0
                total_length += fl
                if fl > DROP_WARN_M:
                    over_warn += 1

            avg_length = total_length / len(cable_features) if len(cable_features) > 0 else 0

            via_span_count = sum(
                1 for f in drop_cable_layer.getFeatures() if f['via_span'] == 1)
            direct_count = len(cable_features) - via_span_count

            self.log_message(f"\nCreated {len(cable_features)} drop cables")
            self._elapsed("Total time")
            self.log_message(f"Layer: '{drop_cable_layer.name()}'")
            self.log_message(f"Total cable length: {total_length:.2f} m")
            self.log_message(f"Average cable length: {avg_length:.2f} m")
            self.log_message(
                f"Direct: {direct_count}  Via-span: {via_span_count}")
            if over_warn > 0:
                self.log_message(
                    f"WARNING: {over_warn} cable(s) exceed {DROP_WARN_M:.0f} m "
                    f"— shown in neon orange on map")
            self.log_message("Length field uses $length expression (auto-updates with geometry)")
            
        except Exception as e:
            self.log_message(f"ERROR generating drop cables: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_generate_drop_ptp_clicked(self, silent=False, demand_layer=None,
                                     splitter_layer=None, drop_layer=None,
                                     force_cross_fids=None, only_groups=None):
        """Generate straight-line (point-to-point) drop cables from each demand point directly to its splitter.

        Args:
            silent: If True, suppress the main dock progress bar (used when called from Manual Override).
            demand_layer / splitter_layer / drop_layer: when supplied (e.g. from the
                Manual Override dialog), regenerate against THESE exact layers instead
                of re-resolving via accumulators / name-search. This guarantees that
                EVERY edit operation (reassign demand, move/delete splitter, add/delete
                demand point, the Regenerate-Drops button, …) rebuilds drops on the same
                layers the dialog is editing — no silent layer mismatch. When None, fall
                back to the accumulator → single-run-ref → name-search resolution.
        """
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject,
                               QgsField, QgsUnitTypes)
        from qgis.PyQt.QtCore import QMetaType

        # During a PON per PON batch run, use the batch-specific layers (set by pipeline steps).
        # Only use accumulators when called from Manual Override (regen after edit).
        _in_batch = bool(getattr(self, '_current_batch_label', None))

        def _alive(_lyr):
            if _lyr is None:
                return False
            try:
                return not sip.isdeleted(_lyr)
            except Exception:
                return True

        # Locate demand points layer — an explicit layer passed by the caller
        # (Manual Override) always wins over re-resolution.
        demand_points_layer = demand_layer if _alive(demand_layer) else None
        if not demand_points_layer and not _in_batch:
            try:
                _accum_grp = getattr(self, '_pon_accum_groups', None)
                if _accum_grp and not sip.isdeleted(_accum_grp) and _accum_grp.featureCount() > 0:
                    demand_points_layer = _accum_grp
            except Exception:
                pass
        try:
            if not demand_points_layer and self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                demand_points_layer = self.demand_points_layer
        except Exception:            pass
        if not demand_points_layer:
            _dm_candidates = []
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    ln = layer.name().lower()
                    if 'demand points' in ln or 'demand_points' in ln:
                        _dm_candidates.append(layer)
            # Prefer point geometry layers; fall back to first match
            _pt_layers = [l for l in _dm_candidates if l.geometryType() == 0]
            if _pt_layers:
                demand_points_layer = _pt_layers[0]
            elif _dm_candidates:
                demand_points_layer = _dm_candidates[0]
        if not demand_points_layer:
            self.log_message("ERROR: Could not find demand points layer. Generate demand points first.")
            return

        # Locate splitter points layer — explicit caller layer wins.
        splitter_points_layer = splitter_layer if _alive(splitter_layer) else None
        if not splitter_points_layer and not _in_batch:
            try:
                _accum_sp = getattr(self, '_pon_accum_splitters', None)
                if _accum_sp and not sip.isdeleted(_accum_sp) and _accum_sp.featureCount() > 0:
                    splitter_points_layer = _accum_sp
            except Exception:
                pass
        try:
            if not splitter_points_layer and self.splitter_points_layer and not sip.isdeleted(self.splitter_points_layer):
                splitter_points_layer = self.splitter_points_layer
        except Exception:            pass
        if not splitter_points_layer:
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    if 'splitter' in layer.name().lower() and layer.geometryType() == 0:
                        splitter_points_layer = layer
                        break
        if not splitter_points_layer:
            self.log_message("ERROR: Could not find splitter points layer. Generate splitter points first.")
            return

        self.log_message("\n=== Generating Drop Cables PTP ===")
        self.log_message(f"Demand points: '{demand_points_layer.name()}'")
        self.log_message(f"Splitters:     '{splitter_points_layer.name()}'")

        try:
            crs = demand_points_layer.crs().authid()

            # Use the PON Drop Cables accumulator only when called from Manual Override
            # (i.e. regen after edit) — NOT during a PON per PON batch run, because the
            # batch layer must be created fresh so the merge step can append it correctly.
            _in_pon_batch = bool(getattr(self, '_current_batch_label', None))
            # An explicit drop_layer from the caller (Manual Override) is the target
            # to regenerate into; otherwise use the PON drops accumulator.
            _accum_drops = drop_layer if _alive(drop_layer) else getattr(self, '_pon_accum_drops', None)
            _use_accum = False
            if not _in_pon_batch:
                try:
                    if _accum_drops and not sip.isdeleted(_accum_drops):
                        _use_accum = True
                except Exception:
                    pass

            if _use_accum:
                drop_ptp_layer = _accum_drops
                provider = drop_ptp_layer.dataProvider()
                # Do NOT wipe existing drops yet. The old behaviour cleared the
                # accumulator here, then returned early when the rebuild produced
                # zero cables (e.g. a transient group/splitter mismatch after a
                # demand reassignment, or a mid-rebuild exception) — which silently
                # deleted EVERY drop cable on the whole project. Defer the wipe
                # until we know the rebuild succeeded, so a zero-result regen is a
                # no-op instead of data loss.
                # Incremental regen: when only_groups is set, replace ONLY those
                # groups' drops (delete just theirs below), leaving every other
                # group's drops untouched — identical result to a full rebuild for
                # the affected groups. Full rebuild (only_groups None) deletes all.
                if only_groups is not None:
                    _gi = provider.fields().indexFromName('group_id')
                    _existing_ids = []
                    if _gi >= 0:
                        for _ef in drop_ptp_layer.getFeatures():
                            try:
                                if int(_ef['group_id']) in only_groups:
                                    _existing_ids.append(_ef.id())
                            except (TypeError, ValueError):
                                continue
                else:
                    _existing_ids = list(drop_ptp_layer.allFeatureIds())
                # For accumulator use a plain QgsFields from the provider (no virtual fields)
                _accum_fields = provider.fields()
                self.log_message(f"  [Regen] Accumulator '{drop_ptp_layer.name()}': {len(_existing_ids)} existing features (wipe deferred until rebuild succeeds), fields: {[f.name() for f in _accum_fields]}")
            else:
                # Build layer name — batch-specific to preserve previous PON-per-PON runs
                _ptp_layer_name = "Drop Cables PTP"
                if getattr(self, '_current_batch_label', None):
                    _ptp_layer_name = f"Drop Cables PTP - {self._current_batch_label}"

                # Removal of the existing same-name layer is deferred until after
                # we confirm the rebuild produced features (see below) — so a
                # zero-result regen leaves the existing drop layer intact instead
                # of wiping it.
                # Create layer
                drop_ptp_layer = QgsVectorLayer(f"LineString?crs={crs}", _ptp_layer_name, "memory")
                provider = drop_ptp_layer.dataProvider()
                provider.addAttributes([
                    QgsField('cable_id', QMetaType.Type.Int),
                    QgsField('group_id', QMetaType.Type.Int),
                    QgsField('demand_id', QMetaType.Type.Int),
                    QgsField('fiber_count', QMetaType.Type.Int),
                    QgsField('fiber_size', QMetaType.Type.QString),
                    QgsField('via_span', QMetaType.Type.Int),      # always 0 for PTP
                    QgsField('cable_length', QMetaType.Type.Double),   # Cartesian CRS-unit length
                    QgsField('zone_id', QMetaType.Type.Int),      # aggregation zone membership
                ])
                drop_ptp_layer.updateFields()

                # Virtual length field
                vf = QgsField('length', QMetaType.Type.Double)
                vf.setLength(10)
                vf.setPrecision(2)
                drop_ptp_layer.addExpressionField('$length', vf)
                # For non-accum path, use layer fields (which includes virtual 'length')
                # but we set attributes by name so it's safe
                _accum_fields = drop_ptp_layer.dataProvider().fields()

            drop_fiber_count = get_cable_profile(1, PROFILE_TYPE_DEFAULT)
            drop_fiber_size = format_cable_profile(drop_fiber_count)
            self.log_message(f"Drop cable profile: {drop_fiber_size}")

            # Index splitters by group_id; also build zone lookup (group_id -> zone_id)
            # Normalise ALL keys to int to avoid type-mismatch misses (QVariant vs int)
            splitters_by_group = {}
            zone_by_group = {}
            _ptp_sp_has_zone = 'zone_id' in [f.name() for f in splitter_points_layer.fields()]
            # Experiment-found bug: if the splitter layer is in a DIFFERENT CRS than the
            # demand layer (mixed import / Manual Override Final picking layers from
            # different sources), mixing their raw coords builds drops that shoot off the
            # map. Transform splitter points into the demand CRS first.
            _sp_xform = None
            try:
                from qgis.core import QgsCoordinateTransform
                _scrs = splitter_points_layer.crs(); _dcrs = demand_points_layer.crs()
                if _scrs.isValid() and _dcrs.isValid() and _scrs != _dcrs:
                    _sp_xform = QgsCoordinateTransform(_scrs, _dcrs, QgsProject.instance())
            except Exception:
                _sp_xform = None
            for sp in splitter_points_layer.getFeatures():
                gid = sp['group_id']
                if gid is None:
                    continue
                try:
                    gid = int(gid)
                except (TypeError, ValueError):
                    continue
                sg = sp.geometry()
                if sg and not sg.isEmpty():
                    # Experiment-found bug: a dict overwrite sent ALL of a group's drops
                    # to the LAST splitter sharing that group_id (often a far one). Keep
                    # every splitter per group and connect each demand to the NEAREST.
                    _spt = sg.asPoint()
                    if _sp_xform is not None:
                        try:
                            _spt = _sp_xform.transform(_spt)
                        except Exception:
                            pass
                    splitters_by_group.setdefault(gid, []).append(_spt)
                if _ptp_sp_has_zone:
                    _zv = sp['zone_id']
                    zone_by_group[gid] = int(_zv) if _zv is not None else -1

            # Threshold for colour warning (same units logic as lashed)
            crs_units = demand_points_layer.crs().mapUnits()
            is_geographic = (crs_units == QgsUnitTypes.DistanceUnit.DistanceDegrees)
            PTP_WARN_THRESHOLD = 0.00045 if is_geographic else 50.0

            demand_fields = [f.name() for f in demand_points_layer.fields()]
            # #79: group-link field is a layer constant — resolve once (not per point).
            _drop_grp_field = next((fn for fn in demand_fields
                                    if _DROP_GRP_RE.fullmatch(fn) or fn == 'batch_id'), None)

            # Road crossing check — skip drops whose demand→splitter line crosses a road.
            # Ticket #68: drops for demand points the planner MANUALLY assigned to a
            # splitter (their FIDs in force_cross_fids) are allowed to cross — only
            # those, not a global toggle.
            # Tickets #111/#112: the manual "allow this drop across a road" decision is
            # PERSISTED on the project, so it survives a dialog close / zone revisit /
            # Regenerate Drops / reload. Seed the allowed-cross set from BOTH this call's
            # explicit fids AND the persisted set — otherwise every regen re-applies the
            # road barrier and silently deletes the planner's manually-routed drops.
            _fcf = set(force_cross_fids or set()) | self._load_force_cross(demand_points_layer)
            _show_all = self._show_all_drops()   # ticket #113: draw every drop, ignore road barrier
            _crosses_road_ptp = self._build_road_crossing_checker(demand_points_layer.crs())
            _road_lyr_ptp = self.comboBox_road_layer.currentLayer() if hasattr(self, 'comboBox_road_layer') else None
            if _road_lyr_ptp and _show_all:
                self.log_message(f"Show all drops ON (#113) — road barrier '{_road_lyr_ptp.name()}' "
                                 "IGNORED; every drop drawn (incl. road crossings).")
            elif _road_lyr_ptp:
                _ov = f" ({len(_fcf)} manually-assigned drop(s) allowed to cross)" if _fcf else ""
                self.log_message(f"Road barrier active: '{_road_lyr_ptp.name()}' — crossing drops skipped{_ov}")
                # Tickets #111/#112 (self-heal for drops placed BEFORE this fix shipped):
                # an EXISTING drop that crosses a road can only be one the planner forced
                # (auto drops are always skipped), so re-approve its demand point before we
                # rebuild — else an incremental regen deletes it and never recreates it.
                # Bounded to the affected group's existing drops (cheap, index-backed); a
                # full rebuild over a huge layer skips the scan to avoid a main-thread stall.
                if _use_accum and _existing_ids and (
                        only_groups is not None or len(_existing_ids) <= 600):
                    try:
                        from qgis.core import QgsFeatureRequest as _QFReq_fc
                        _did_i_fc = drop_ptp_layer.fields().indexFromName('demand_id')
                        _newly_fc = set()
                        if _did_i_fc >= 0:
                            _req_fc = _QFReq_fc().setFilterFids(list(_existing_ids))
                            for _edf in drop_ptp_layer.getFeatures(_req_fc):
                                _eg = _edf.geometry()
                                if not _eg or _eg.isEmpty():
                                    continue
                                _pts = _eg.asPolyline()
                                if len(_pts) < 2:
                                    continue
                                if _crosses_road_ptp(_pts[0].x(), _pts[0].y(),
                                                     _pts[-1].x(), _pts[-1].y()):
                                    try:
                                        _newly_fc.add(int(_edf['demand_id']))
                                    except (TypeError, ValueError):
                                        continue
                        if _newly_fc:
                            _fcf |= _newly_fc
                            self._save_force_cross(demand_points_layer, _fcf)
                            self.log_message(
                                f"  ✦ Preserved {len(_newly_fc)} existing road-crossing "
                                f"drop(s) the planner had manually routed.")
                    except Exception:
                        pass

            cable_features = []
            cable_id = 1
            skipped_no_group = 0
            skipped_no_splitter = 0
            skipped_road_cross = 0
            groups_found = set()
            connections_by_group = {}
            total_demand = demand_points_layer.featureCount()
            self.log_message(f"Connecting {total_demand} demand points (straight line)...")
            if not silent:
                self._start_operation("Generating Drop Cables PTP…")

            for idx, demand_point in enumerate(demand_points_layer.getFeatures()):
                if not silent:
                    self._progress(idx + 1, total_demand, 'PTP drops')
                if not silent and self._cancel_check():
                    self.log_message("⛔ Drop cables (PTP) generation cancelled.")
                    return
                dg = demand_point.geometry()
                if not dg or dg.isEmpty():
                    continue
                # Use centroid for polygon/line sources so non-point layers work correctly
                if dg.type() == 0:  # Point
                    demand_pt = dg.asPoint()
                else:
                    demand_pt = dg.centroid().asPoint()

                # Resolve group_id — match the group-link field by PATTERN (#79:
                # group_<N> any size incl. HeroTel group_32/64, or batch_id) and
                # normalise to int to match splitters_by_group keys.
                group_id = None
                if _drop_grp_field is not None:
                    _raw = demand_point[_drop_grp_field]
                    if _raw is not None:
                        try:
                            group_id = int(_raw)
                        except (TypeError, ValueError):
                            group_id = None
                if group_id is None:
                    skipped_no_group += 1
                    continue
                if group_id not in splitters_by_group:
                    skipped_no_splitter += 1
                    continue

                _sp_cands = splitters_by_group[group_id]
                splitter_pt = (_sp_cands[0] if len(_sp_cands) == 1 else
                               min(_sp_cands, key=lambda _c: (_c.x()-demand_pt.x())**2
                                   + (_c.y()-demand_pt.y())**2))
                line_geom = QgsGeometry.fromPolylineXY([demand_pt, splitter_pt])

                # Batch D incremental regen: when only specific groups are being
                # regenerated, skip demand points outside them so untouched groups'
                # drops are left exactly as-is (fast path for single-edit Manual
                # Override — avoids re-routing the whole layer on every click).
                if only_groups is not None and int(group_id) not in only_groups:
                    continue

                # Skip drop if it crosses a road — UNLESS this specific demand point
                # was MANUALLY assigned to its splitter (ticket #68: only the drops
                # the planner deliberately assigned across a road are forced through).
                if (not _show_all) and (demand_point.id() not in _fcf) and _crosses_road_ptp(
                        demand_pt.x(), demand_pt.y(),
                        splitter_pt.x(), splitter_pt.y()):
                    skipped_road_cross += 1
                    continue

                feat = QgsFeature(_accum_fields if _use_accum else drop_ptp_layer.fields())
                feat.setGeometry(line_geom)
                # Build attribute list matching provider fields only (no virtual expression fields)
                _attr_map = {
                    'cable_id':    cable_id,
                    'group_id':    int(group_id),
                    'demand_id':   int(demand_point.id()),
                    'fiber_count': drop_fiber_count,
                    'fiber_size':  drop_fiber_size,
                    'via_span':    0,
                    'cable_length': line_geom.length(),
                    'zone_id':     zone_by_group.get(int(group_id), -1),
                }
                _flds = _accum_fields if _use_accum else drop_ptp_layer.fields()
                feat.setAttributes([_attr_map.get(f.name(), None) for f in _flds])
                cable_features.append(feat)
                connections_by_group[group_id] = connections_by_group.get(group_id, 0) + 1
                cable_id += 1

            if skipped_no_group:
                self.log_message(f"Warning: {skipped_no_group} demand points had no group_id field")
            if skipped_no_splitter:
                self.log_message(f"Warning: {skipped_no_splitter} demand points had no matching splitter")
            if skipped_road_cross:
                self.log_message(f"🚫 Road barrier: {skipped_road_cross} drop(s) crossed a road — skipped")

            if not cable_features:
                # MO audit: for INCREMENTAL regen (only_groups set), zero cables means the
                # affected group(s) legitimately have no drops now (last demand point
                # deleted) → DELETE their stale old drops instead of leaving an orphan
                # line on the canvas. For a FULL rebuild, zero matches signals a transient
                # mismatch → keep everything (the data-loss guard).
                if only_groups is not None and _use_accum and _existing_ids:
                    provider.deleteFeatures(_existing_ids)
                    drop_ptp_layer.updateExtents()
                    drop_ptp_layer.triggerRepaint()
                    try:
                        self._refresh_canvas_now()
                    except Exception:
                        pass
                    self.log_message(
                        f"  [Regen] affected group(s) now empty — removed "
                        f"{len(_existing_ids)} stale drop(s).")
                    return
                self.log_message(
                    "⚠ No PTP drop cables produced — group_id/splitter alignment "
                    "yielded zero matches. Existing drop cables were LEFT UNTOUCHED "
                    "(regen aborted, nothing deleted).")
                return

            # Write features to layer
            if _use_accum:
                # SAFE ORDERING — add the NEW drops first, confirm they actually
                # landed, and only THEN delete the OLD ones. The previous order
                # (delete-then-add) could wipe the whole layer if the add failed —
                # e.g. a read-only or schema-mismatched disk layer (GPKG/shapefile),
                # which is exactly how a saved drop-cable layer lost all its data.
                # If the write fails we roll back the partial insert and abort with
                # the existing drops untouched.
                _before = drop_ptp_layer.featureCount()
                _res = provider.addFeatures(cable_features)
                _ok  = _res[0] if isinstance(_res, tuple) else bool(_res)
                _added = _res[1] if (isinstance(_res, tuple) and len(_res) > 1) else []
                _after = drop_ptp_layer.featureCount()
                if not _ok or _after <= _before:
                    # Write failed — undo any partial insert, keep the old drops.
                    try:
                        if _added:
                            provider.deleteFeatures([f.id() for f in _added])
                    except Exception:
                        pass
                    self.log_message(
                        f"  ⚠ Drop write FAILED on '{drop_ptp_layer.name()}' "
                        "(layer not editable or schema mismatch). Existing drop "
                        "cables were LEFT INTACT — nothing was deleted.")
                    return
                # Write succeeded — now remove the OLD features (captured up-front).
                if _existing_ids:
                    provider.deleteFeatures(_existing_ids)
                drop_ptp_layer.updateExtents()
                self.log_message(f"  [Regen] wrote {len(cable_features)} drop cables → '{drop_ptp_layer.name()}' (total={drop_ptp_layer.featureCount()})")
            else:
                provider.addFeatures(cable_features)
            drop_ptp_layer.updateExtents()

            # Simple black renderer — no expressions, no crash risk
            drop_ptp_layer.setRenderer(
                QgsSingleSymbolRenderer(
                    QgsLineSymbol.createSimple({'color': '0,0,0', 'width': '0.4', 'line_style': 'solid'})
                )
            )

            if _use_accum:
                drop_ptp_layer.triggerRepaint()
                # Force an immediate canvas redraw so the new drops show at once
                # instead of after a queued repaint (the reassign/move render lag).
                self._refresh_canvas_now()
            else:
                # Now that we have features, remove the previous same-name layer
                # (deferred from above) and add the freshly built one.
                for _old in list(QgsProject.instance().mapLayers().values()):
                    if isinstance(_old, QgsVectorLayer) and _old.name() == _ptp_layer_name:
                        QgsProject.instance().removeMapLayer(_old.id())
                        break
                drop_ptp_layer = self._add_output_layer(drop_ptp_layer)
            self.drop_ptp_layer = drop_ptp_layer

            self.log_message(f"\nCreated {len(cable_features)} PTP drop cables")
            if not silent:
                self._elapsed("Total time")
            self.log_message(f"Layer: '{drop_ptp_layer.name()}'")
            avg_length = sum(f['cable_length'] or 0 for f in cable_features) / len(cable_features) if cable_features else 0
            self.log_message(f"Average cable length: {avg_length:.2f} units")
            self.log_message(f"Connections per group: {dict(sorted(connections_by_group.items()))}")

        except Exception as e:
            self.log_message(f"ERROR generating PTP drop cables: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_manual_override_clicked(self):
        """Open Manual Override dialog — reassign splitter zones or demand point group/zone."""
        from qgis.PyQt.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel,
                                          QListWidget, QAbstractItemView,
                                          QSpinBox, QPushButton, QComboBox,
                                          QGroupBox, QFormLayout, QFrame,
                                          QTabWidget, QWidget)
        from qgis.PyQt.QtCore import Qt
        from qgis.core import QgsProject, QgsVectorLayer
        from qgis.PyQt import sip
        import math

        # ---- Locate Splitter Points layer ----
        # Priority: PON accumulator → batch ref → name search
        splitter_layer = None
        try:
            _accum_sp = getattr(self, '_pon_accum_splitters', None)
            if _accum_sp and not sip.isdeleted(_accum_sp) and _accum_sp.featureCount() > 0:
                splitter_layer = _accum_sp
        except Exception:
            pass
        if not splitter_layer:
            try:
                if self.splitter_points_layer and not sip.isdeleted(self.splitter_points_layer):
                    splitter_layer = self.splitter_points_layer
            except Exception:
                pass
        if not splitter_layer:
            for _lyr in QgsProject.instance().mapLayers().values():
                if isinstance(_lyr, QgsVectorLayer) and 'splitter' in _lyr.name().lower() and _lyr.geometryType() == 0:
                    splitter_layer = _lyr
                    break
        if not splitter_layer:
            self.log_message("ERROR: No Splitter Points layer found. Generate splitter points first.")
            return

        sp_field_names = [f.name() for f in splitter_layer.fields()]
        if 'zone_id' not in sp_field_names:
            self.log_message("WARNING: Splitter layer has no 'zone_id' field. Re-generate splitter points first.")
            return
        # group_id is read unguarded in the splitter-data loop below and in the apply
        # handlers. Manual Override Final lets the planner proceed with a chosen layer
        # that may lack it (the picker only warns) — without this guard that becomes a
        # KeyError crash before the dialog opens. Fail safe with a clear message instead.
        if 'group_id' not in sp_field_names:
            self.log_message("WARNING: Splitter layer has no 'group_id' field — cannot reassign groups/zones. "
                             "Pick a splitter layer generated by the planner, or re-generate splitter points.")
            return

        def _to_int(v, default=0):
            """Safely convert QVariant/None/str/int to int."""
            if v is None:
                return default
            try:
                from qgis.PyQt.QtCore import QVariant as _QV
                if isinstance(v, _QV):
                    return default if v.isNull() else int(v.value())
            except Exception:
                pass
            try:
                return int(v)
            except (TypeError, ValueError):
                return default

        # ---- Build splitter data list ----
        splitter_data = []
        for _feat in splitter_layer.getFeatures():
            _gid = _feat['group_id']
            _zid = _feat['zone_id']
            _dc  = _feat['drop_count'] if 'drop_count' in sp_field_names else 0
            _pt  = _feat.geometry().asPoint() if (_feat.geometry() and not _feat.geometry().isEmpty()) else None
            splitter_data.append({
                'fid':        _feat.id(),
                'group_id':   _to_int(_gid, 0),
                'zone_id':    _to_int(_zid, -1),
                'drop_count': _to_int(_dc,  0),
                'x':          _pt.x()  if _pt  else 0.0,
                'y':          _pt.y()  if _pt  else 0.0,
            })
        if not splitter_data:
            self.log_message("ERROR: Splitter Points layer is empty.")
            return

        # ---- Locate Demand Points layer + build demand_data ----
        # Priority: PON Groups accumulator → batch ref → name search
        _dem_layer = None
        _dp_link = None   # group link field (e.g. group_8)
        _dp_zi   = -1     # zone_id field index
        _dp_zni  = -1     # zone_name field index
        try:
            _accum_grp = getattr(self, '_pon_accum_groups', None)
            if _accum_grp and not sip.isdeleted(_accum_grp) and _accum_grp.featureCount() > 0:
                _dem_layer = _accum_grp
        except Exception:
            pass
        if not _dem_layer:
            try:
                if self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                    _dem_layer = self.demand_points_layer
            except Exception:
                pass
        if not _dem_layer:
            # Ticket #67: after an update/restart the in-memory refs are gone, so we
            # must find the GROUPED demand layer from the project. A name-only match
            # could grab the RAW demand layer (no group field) → empty list, which is
            # exactly why it only worked after re-running PON-per-PON. Instead pick a
            # point layer that actually HAS a group-link field, preferring
            # demand/groups-named ones and the most-populated.
            # #79: detect the group-link field by PATTERN so HeroTel group_32/64
            # demand layers qualify too (not only the old hardcoded sizes).
            _best = None
            _best_score = -1
            for _lyr in QgsProject.instance().mapLayers().values():
                if not isinstance(_lyr, QgsVectorLayer) or _lyr.geometryType() != 0:
                    continue
                _fn = [f.name() for f in _lyr.fields()]
                if _demand_group_field(_fn) is None:
                    continue  # not a grouped demand layer
                _ln = _lyr.name().lower()
                _fc = _lyr.featureCount()
                # A POPULATED layer must always beat an empty one (the empty grouped
                # layer is useless for Manual Override); then prefer demand/groups
                # names; then more features.
                _score = _fc
                if _fc > 0:
                    _score += 10_000_000
                if 'demand' in _ln or 'pon group' in _ln or 'groups of' in _ln:
                    _score += 1_000_000
                if _score > _best_score:
                    _best_score = _score
                    _best = _lyr
            _dem_layer = _best
        demand_data = []
        if _dem_layer:
            _dfnames = [f.name() for f in _dem_layer.fields()]
            _dp_link = _demand_group_field(_dfnames)  # #79: any group_<N> size
            _dp_zi   = _dem_layer.fields().indexFromName('zone_id')   if 'zone_id'   in _dfnames else -1
            _dp_zni  = _dem_layer.fields().indexFromName('zone_name') if 'zone_name' in _dfnames else -1
            if _dp_link:
                for _f in _dem_layer.getFeatures():
                    _gid = _f[_dp_link]
                    _zid = _f['zone_id'] if _dp_zi >= 0 else None
                    _pt  = _f.geometry().asPoint() if (_f.geometry() and not _f.geometry().isEmpty()) else None
                    demand_data.append({
                        'fid':      _f.id(),
                        'group_id': _to_int(_gid, 0),
                        'zone_id':  _to_int(_zid, -1),
                        'x':        _pt.x() if _pt else 0.0,
                        'y':        _pt.y() if _pt else 0.0,
                    })

        # Ticket #96/#97 (Lodewijk/Luke): the displayed "N drops" must match what the
        # planner can actually count on the canvas. drop_count was seeded above from the
        # splitter layer's STORED attribute, which can be stale (set in a prior session,
        # or never refreshed after demand edits — Luke saw a combo say "5 drops" while
        # the splitter attribute said 4). Re-seed it from the ACTUAL demand points on the
        # canvas (demand_data, one entry per real demand feature).
        #
        # #97: JJ approved persisting the canvas-true count BACK to the splitter layer's
        # drop_count attribute so the attribute table, on-map labels and the Edit form
        # all agree with the dialog — one source of truth everywhere. Only rows that
        # differ are written (bulk dataProvider write).
        #
        # SAFETY: only trust the demand→group mapping when it actually overlaps the
        # splitters' group_ids. If a mis-resolved group field made every demand point
        # collapse to one group, the overlap check fails and we leave the stored
        # attribute untouched (no zeroing of every count).
        if _dp_link and demand_data:
            _truth_dc = {}
            for _dd in demand_data:
                _g = _dd.get('group_id')
                if _g is None:
                    continue
                _truth_dc[_g] = _truth_dc.get(_g, 0) + 1
            _known_groups = {_sd['group_id'] for _sd in splitter_data}
            if _truth_dc and (_known_groups & set(_truth_dc)):
                for _sd in splitter_data:
                    _sd['drop_count'] = _truth_dc.get(_sd['group_id'], 0)
                # #97: persist truth to the splitter layer attribute (only changed rows).
                if 'drop_count' in sp_field_names:
                    _dc_i = splitter_layer.fields().indexFromName('drop_count')
                    _truth_by_fid = {_sd['fid']: _sd['drop_count'] for _sd in splitter_data}
                    _pending = {}
                    for _spf in splitter_layer.getFeatures():
                        _want = _truth_by_fid.get(_spf.id())
                        if _want is not None and (_spf['drop_count'] or 0) != _want:
                            _pending[_spf.id()] = {_dc_i: _want}
                    if _pending:
                        # claude:approved-destructive (JJ OK'd #97 attribute persist;
                        # bulk attr-only write via dataProvider + _safe_commit, no geometry)
                        splitter_layer.startEditing()
                        splitter_layer.dataProvider().changeAttributeValues(_pending)
                        _safe_commit(splitter_layer)
                        _accum_sp_seed = getattr(self, '_pon_accum_splitters', None)
                        try:
                            from qgis.PyQt import sip as _sip_seed
                            if (_accum_sp_seed and not _sip_seed.isdeleted(_accum_sp_seed)
                                    and splitter_layer is _accum_sp_seed):
                                self._pon_refresh_accum_renderers()
                            else:
                                splitter_layer.triggerRepaint()
                        except Exception:
                            splitter_layer.triggerRepaint()
                        self.log_message(
                            f"[Manual Override #97] corrected {len(_pending)} stale "
                            f"drop_count attribute(s) to match canvas demand points")

        # ---- Resolve the Drop Cables layer this dialog regenerates into ----
        # Every regen call below passes this so drops are always rebuilt on the
        # SAME layer the dialog targets (Manual Override Final's picked drops layer
        # → PON drops accumulator → single-run ref → name search). Resolved ONCE
        # here so all edit operations stay consistent.
        # Ticket #76: a stored ref (accumulator / single-run) can be ALIVE in C++
        # (sip.isdeleted False) yet no longer be ON the canvas — an old in-memory
        # "Drop Cables PTP" left over from a prior auto-run. Regenerating into it
        # writes valid drops to a layer the planner can't see → "success but
        # nothing shows". Require the candidate to still be registered in the
        # project; otherwise fall through to the name search, which only iterates
        # real project layers and finds the visible Drop Cables layer.
        # MO audit: honor an explicit "skip this layer" choice from Manual Override
        # Final (consume-once) — don't re-resolve a layer the planner left blank.
        _skip_drops = bool(getattr(self, '_mo_final_skip_drops', False))
        _skip_zones = bool(getattr(self, '_mo_final_skip_zones', False))
        self._mo_final_skip_drops = False
        self._mo_final_skip_zones = False
        _proj_ids = set(QgsProject.instance().mapLayers().keys())
        _drop_layer = None
        for _cand in (getattr(self, '_pon_accum_drops', None),
                      getattr(self, 'drop_ptp_layer', None)):
            try:
                if (_cand is not None and not sip.isdeleted(_cand)
                        and _cand.id() in _proj_ids):
                    _drop_layer = _cand
                    break
            except Exception:
                pass
        if _drop_layer is None:
            for _lyr in QgsProject.instance().mapLayers().values():
                if isinstance(_lyr, QgsVectorLayer) and _lyr.geometryType() == 1:
                    _ln = _lyr.name().lower()
                    if 'drop cables ptp' in _ln or _ln == 'drops' or 'drop cable' in _ln:
                        _drop_layer = _lyr
                        break
        if _skip_drops:
            _drop_layer = None  # MO audit: planner chose to leave drops untouched
        # Zone-boundary polygon layer (ticket #62): so adding/moving a demand
        # point can grow the zone boundary to enclose it. Prefer the stored
        # accumulator/step-3 refs, then fall back to a name search.
        _zones_layer = None
        for _cand in (getattr(self, '_pon_accum_zones', None),
                      getattr(self, 'zone_boundaries_layer', None)):
            try:
                # Ticket #76: same off-canvas-ref guard as drops — never rebuild a
                # zone boundary into a layer that's no longer on the map.
                if (_cand is not None and not sip.isdeleted(_cand)
                        and _cand.id() in _proj_ids):
                    _zones_layer = _cand
                    break
            except Exception:
                pass
        if _zones_layer is None:
            for _lyr in QgsProject.instance().mapLayers().values():
                if isinstance(_lyr, QgsVectorLayer) and _lyr.geometryType() == 2:
                    _ln = _lyr.name().lower()
                    if ('zone' in _ln and 'boundar' in _ln) or 'pon zone' in _ln:
                        _zones_layer = _lyr
                        break
        if _skip_zones:
            _zones_layer = None  # MO audit: planner chose to leave zones untouched

        self.log_message(
            f"[Manual Override] Editing — Splitters: '{splitter_layer.name()}', "
            f"Demand: '{_dem_layer.name() if _dem_layer else 'none'}', "
            f"Drops: '{_drop_layer.name() if _drop_layer else '(auto/new)'}', "
            f"PONs: '{_zones_layer.name() if _zones_layer else 'none'}'")

        # Ticket #68: demand points the planner MANUALLY assigns/adds to a splitter
        # (their FIDs collected here) are the ONLY drops allowed to cross a road.
        # Auto-generated drops still respect the road barrier. (Replaces the #66
        # global "allow cross" checkbox, which Rico asked to remove.)
        # Tickets #111/#112: seed from the PERSISTED approvals for this demand layer so
        # reopening Manual Override (or revisiting a zone) keeps every drop the planner
        # has already routed across a road — they no longer vanish on the next regen.
        _force_cross = self._load_force_cross(_dem_layer)

        # Single helper so every edit operation regenerates drops against the
        # exact layers this dialog is editing (no independent re-resolution).
        def _regen_drops(only_groups=None):
            # Manual Override edits an EXISTING network. If no drop-cable layer resolved
            # (Manual Override Final with no Drops layer picked, or none in the project),
            # do NOT let on_generate_drop_ptp_clicked spin up a throwaway new layer every
            # edit — skip with a clear message and leave the user's layers untouched.
            #
            # Batch D: pass only_groups to regenerate just the touched group(s) instead
            # of re-routing the ENTIRE drop layer on every edit (the per-click freeze).
            # Callers pass it ONLY when the full affected-group set is known and
            # unambiguous (single-group add/delete); multi-group reassigns still pass
            # None = safe full rebuild.
            if _drop_layer is None or sip.isdeleted(_drop_layer):
                self.log_message("No drop-cable layer to regenerate into — drop regen skipped. "
                                 "Pick a Drop Cables layer (Manual Override Final) to enable it.")
                return
            self.on_generate_drop_ptp_clicked(
                silent=True, demand_layer=_dem_layer,
                splitter_layer=splitter_layer, drop_layer=_drop_layer,
                force_cross_fids=_force_cross, only_groups=only_groups)

        def _rebuild_zone_boundary(zone_name, zone_id):
            """Ticket #62/#63: rebuild ONLY the affected zone's boundary polygon
            from that zone's OWN demand points (the just-added point included),
            using the same tight buffer→close→snap method as the generator —
            NEVER a convex hull. This is what fixes #63: convex-hulling a tight
            existing polygon out to a far/new point ballooned the boundary across
            the whole map. Rebuilding from points keeps it local — a new/sparse
            zone gets a small boundary, a dense zone a tight one, and far parts are
            joined by thin corridors (_snap_parts_together), not a giant triangle.
            Updates the matching zone feature in place, or adds one if the zone had
            no boundary yet. Best-effort: returns False (no-op) on any problem."""
            try:
                if _zones_layer is None or sip.isdeleted(_zones_layer):
                    return False
                if _dem_layer is None or sip.isdeleted(_dem_layer):
                    return False
                from qgis.core import QgsUnitTypes, QgsFeature as _QF
                dnames = [f.name() for f in _dem_layer.fields()]

                def _zmatch(feat):
                    if 'zone_id' in dnames and zone_id is not None:
                        try:
                            if int(feat['zone_id']) == int(zone_id):
                                return True
                        except (TypeError, ValueError):
                            pass
                    if 'zone_name' in dnames and zone_name:
                        return str(feat['zone_name']) == str(zone_name)
                    return False

                coords = []
                for f in _dem_layer.getFeatures():
                    gg = f.geometry()
                    if not gg or gg.isEmpty():
                        continue
                    if _zmatch(f):
                        coords.append(gg.centroid().asPoint())
                if not coords:
                    return False

                # Radius from mean nearest-neighbour spacing, CAPPED (mirror the
                # generator) so a single point gives a small disc, never a fill.
                if (_zones_layer.crs().mapUnits() ==
                        QgsUnitTypes.DistanceUnit.DistanceDegrees):
                    min_r, max_r = 0.00004, 0.00025
                else:
                    min_r, max_r = 4.0, 30.0
                if len(coords) <= 1:
                    radius = max_r
                else:
                    nn_sum, nn_count = 0.0, 0
                    for i, pt in enumerate(coords):
                        best = float('inf')
                        for j, other in enumerate(coords):
                            if i == j:
                                continue
                            d = ((pt.x() - other.x()) ** 2 +
                                 (pt.y() - other.y()) ** 2) ** 0.5
                            if d < best:
                                best = d
                        if best < float('inf'):
                            nn_sum += best
                            nn_count += 1
                    mean_nn = nn_sum / nn_count if nn_count else max_r
                    radius = max(min(mean_nn * 0.55, max_r), min_r)

                merged = QgsGeometry.fromPointXY(coords[0]).buffer(radius, 12)
                for pt in coords[1:]:
                    merged = merged.combine(
                        QgsGeometry.fromPointXY(pt).buffer(radius, 12))
                close_r = radius * 0.5
                cand = merged.buffer(close_r, 8).buffer(-close_r, 8)
                zone_geom = cand if not cand.isEmpty() else merged
                # Single solid polygon WITHOUT convex hull: bridge any leftover
                # fragments with thin corridors only.
                if zone_geom.isMultipart():
                    zone_geom = FTTHPlanToolDockWidget._snap_parts_together(
                        zone_geom, radius)
                if zone_geom is None or zone_geom.isEmpty():
                    return False

                znames = [f.name() for f in _zones_layer.fields()]
                target = None
                if 'zone_name' in znames and zone_name:
                    for f in _zones_layer.getFeatures():
                        if str(f['zone_name']) == str(zone_name):
                            target = f
                            break
                if target is None and 'zone_id' in znames and zone_id is not None:
                    for f in _zones_layer.getFeatures():
                        try:
                            if int(f['zone_id']) == int(zone_id):
                                target = f
                                break
                        except (TypeError, ValueError):
                            pass

                # ── Ticket #65: de-clash so zones never OVERLAP ──────────────
                # Mirror the generator's overlap arbitration locally: any area the
                # rebuilt zone shares with a neighbour goes to whichever zone has a
                # demand point CLOSER to that overlap. The other zone yields it.
                def _largest(g):
                    if g is None or g.isEmpty():
                        return g
                    if not g.isMultipart():
                        return g
                    parts = [p for p in g.asGeometryCollection() if not p.isEmpty()]
                    return max(parts, key=lambda p: p.area()) if parts else g

                # demand-point centroid per zone (id first, then name)
                _zsum = {}
                for f in _dem_layer.getFeatures():
                    gg = f.geometry()
                    if not gg or gg.isEmpty():
                        continue
                    k = None
                    if 'zone_id' in dnames:
                        try:
                            k = ('id', int(f['zone_id']))
                        except (TypeError, ValueError):
                            k = None
                    if k is None and 'zone_name' in dnames and f['zone_name']:
                        k = ('name', str(f['zone_name']))
                    if k is None:
                        continue
                    p = gg.centroid().asPoint()
                    s = _zsum.setdefault(k, [0.0, 0.0, 0])
                    s[0] += p.x(); s[1] += p.y(); s[2] += 1

                def _zcent(zid, zname):
                    for k in ((('id', int(zid)) if zid is not None else None),
                              (('name', str(zname)) if zname else None)):
                        try:
                            if k and k in _zsum and _zsum[k][2]:
                                s = _zsum[k]
                                return (s[0] / s[2], s[1] / s[2])
                        except (TypeError, ValueError):
                            pass
                    return None

                cx_z = sum(p.x() for p in coords) / len(coords)
                cy_z = sum(p.y() for p in coords) / len(coords)
                _neighbor_updates = {}
                target_fid = target.id() if target is not None else None
                for of in _zones_layer.getFeatures():
                    if target_fid is not None and of.id() == target_fid:
                        continue
                    og = of.geometry()
                    if og is None or og.isEmpty():
                        continue
                    inter = zone_geom.intersection(og)
                    if inter is None or inter.isEmpty():
                        continue
                    oc = inter.centroid().asPoint()
                    o_cent = None
                    try:
                        o_cent = _zcent(of['zone_id'] if 'zone_id' in znames else None,
                                        of['zone_name'] if 'zone_name' in znames else None)
                    except Exception:
                        o_cent = None
                    dz = (oc.x() - cx_z) ** 2 + (oc.y() - cy_z) ** 2
                    do = ((oc.x() - o_cent[0]) ** 2 + (oc.y() - o_cent[1]) ** 2
                          if o_cent else float('inf'))
                    if do < dz:
                        # neighbour is closer → the rebuilt zone yields this overlap
                        diff = zone_geom.difference(inter)
                        if diff is not None and not diff.isEmpty():
                            zone_geom = _largest(diff)
                    else:
                        # rebuilt zone is closer → neighbour yields this overlap
                        odiff = og.difference(inter)
                        if odiff is not None and not odiff.isEmpty():
                            _neighbor_updates[of.id()] = _largest(odiff)

                if zone_geom is None or zone_geom.isEmpty():
                    return False

                # claude:approved-destructive — rebuilds ONE zone-boundary polygon
                # from its own demand points + trims overlaps; never poles/cables.
                if target is not None:
                    _neighbor_updates[target.id()] = zone_geom
                    _zones_layer.dataProvider().changeGeometryValues(_neighbor_updates)
                else:
                    if _neighbor_updates:
                        _zones_layer.dataProvider().changeGeometryValues(_neighbor_updates)
                    nf = _QF(_zones_layer.fields())
                    nf.setGeometry(zone_geom)
                    try:
                        if 'zone_name' in znames:
                            nf['zone_name'] = zone_name
                        if 'zone_id' in znames and zone_id is not None:
                            nf['zone_id'] = zone_id
                    except Exception:
                        pass
                    _zones_layer.dataProvider().addFeatures([nf])
                _zones_layer.updateExtents()
                _zones_layer.triggerRepaint()
                return True
            except Exception as _ze:
                self.log_message(f"  ⚠ zone boundary rebuild skipped: {_ze}")
                return False

        # ---- Prevent second instance ----
        _prev_dlg = getattr(self, '_override_dlg', None)
        if _prev_dlg and not sip.isdeleted(_prev_dlg) and _prev_dlg.isVisible():
            _prev_dlg.raise_()
            _prev_dlg.activateWindow()
            return

        # ================================================================
        # Build panel — hosted in a dockable _PanelDock (dock to any edge,
        # float, MINIMISE, close) so Manual Override behaves like the other
        # editors (JJ 2026-07-01). Already non-modal (map picking); only
        # close/show/raise/activateWindow are used — all QDockWidget-native.
        # ================================================================
        from qgis.PyQt.QtWidgets import QScrollArea
        try:
            from ..fiber_network_plugin import _PanelDock
        except Exception:
            from fiber_network_plugin import _PanelDock
        dlg = _PanelDock("Manual Override", self.iface)
        dlg.setObjectName("vfManualOverrideDock")
        # WA_DeleteOnClose: without it the closed panel lingers as a hidden
        # child all session; the sip.isdeleted guard above keeps the reuse
        # check safe after the C++ object is destroyed.
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self._override_dlg = dlg
        # Ticket #65: shared "dialog closed" flag. Several map tools and signal
        # handlers below capture the panel's widgets (status label, combos); after
        # it closes those widgets are deleted, and a stray canvas event then
        # crashed with "QLabel/QComboBox has been deleted". Every such handler bails
        # when this is set true (in _on_dialog_close).
        _dlg_closed = [False]
        # Also flip the flag on destruction (fires even when the panel dies WITHOUT
        # a normal close — e.g. a plugin update/reload while it's open), so every
        # _dlg_closed guard stays reliable and stray map-tool signals can't touch
        # deleted widgets (the recurring "QPushButton/QComboBox/QLabel deleted" crash).
        try:
            dlg.destroyed.connect(lambda *_a: _dlg_closed.__setitem__(0, True))
        except Exception:
            pass
        dlg.setMinimumWidth(500)
        # Host the content in a scroll area so the 3 tabs never look cramped or
        # run off-screen once docked to a narrow edge.
        _mo_content = QWidget()
        _mo_scroll = QScrollArea()
        _mo_scroll.setWidgetResizable(True)
        _mo_scroll.setWidget(_mo_content)
        dlg.setWidget(_mo_scroll)
        layout = QVBoxLayout(_mo_content)
        layout.setSpacing(6)

        # Shared map-pick toggle (top of dialog)
        pick_row = QHBoxLayout()
        btn_pick = QPushButton("Map Picking: ON")
        btn_pick.setCheckable(True)
        btn_pick.setChecked(True)
        btn_pick.setStyleSheet(
            "QPushButton:checked  { background-color: #4CAF50; color: white; font-weight: bold; }"
            "QPushButton:!checked { background-color: #f0ad4e; color: black; }")
        btn_pick.setToolTip("Click on the map to select the nearest feature on the active tab.")
        pick_row.addStretch()
        pick_row.addWidget(btn_pick)
        layout.addLayout(pick_row)

        # Tab widget
        tab_widget = QTabWidget()
        layout.addWidget(tab_widget)

        # ----------------------------------------------------------------
        # TAB 0 — Splitter Zones
        # ----------------------------------------------------------------
        tab_sp = QWidget()
        sp_layout = QVBoxLayout(tab_sp)
        sp_layout.setSpacing(6)

        sp_layout.addWidget(QLabel("<b>Select splitters and reassign them to a new PON zone.</b>"))
        sp_layout.addWidget(QLabel("Click splitters on the map or use Ctrl/Shift+click on the list."))

        # Ticket #96 (Lodewijk): show the total splitter count for spot checks.
        lbl_total_sp = QLabel()
        lbl_total_sp.setStyleSheet("font-weight: bold;")
        sp_layout.addWidget(lbl_total_sp)

        list_widget = QListWidget()
        list_widget.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        list_widget.setMinimumHeight(160)

        # Ticket #98 (Luke): max 16 groups per zone (spec). Show a "groups in zone"
        # column on every row, and flag any zone that exceeds 16 in red + bold so the
        # planner spots an over-packed zone instantly. Rendered through this helper so
        # the column + highlight stay live after every add/delete/reassign edit.
        _MAX_GROUPS_PER_ZONE = 16

        def _render_splitter_list(*_a):
            try:
                _zgc = {}
                for _sd in splitter_data:
                    _zgc[_sd['zone_id']] = _zgc.get(_sd['zone_id'], 0) + 1
                _def_fg = list_widget.palette().text().color()
                for _i, _sd in enumerate(splitter_data):
                    if _i >= list_widget.count():
                        break
                    _zg = _zgc.get(_sd['zone_id'], 0)
                    _it = list_widget.item(_i)
                    _it.setText(
                        f"Splitter {_sd['group_id']}   |   PON {_sd['zone_id']}   |   "
                        f"{_sd['drop_count']} drops   |   {_zg} groups in zone")
                    _over = _zg > _MAX_GROUPS_PER_ZONE
                    _f = _it.font()
                    _f.setBold(_over)
                    _it.setFont(_f)
                    _it.setForeground(QColor('#d62728') if _over else _def_fg)
            except Exception:
                pass

        for sd in splitter_data:
            list_widget.addItem("")
        _render_splitter_list()
        sp_layout.addWidget(list_widget)

        # Keep the total in sync no matter how the list changes (add / delete
        # splitter, zone edits that rebuild the list) — driven off the list model
        # so it never goes stale, rather than only being set at dialog-open.
        def _update_total_splitters(*_a):
            try:
                lbl_total_sp.setText(f"Total Splitters: {list_widget.count()}")
            except Exception:
                pass
        _update_total_splitters()
        list_widget.model().rowsInserted.connect(_update_total_splitters)
        list_widget.model().rowsRemoved.connect(_update_total_splitters)

        # Ticket #96 (JJ): ONE authoritative refresh for every "N drops" display so
        # the counts can NEVER drift out of sync with splitter_data (the in-memory
        # source of truth each edit handler maintains). Call this at the end of any
        # handler that changes a drop_count. It re-renders the Splitter Zones list
        # (1:1 by position) and matches each combo item by its "Group <id>  |" prefix,
        # so it is safe regardless of placeholder rows or combo ordering. Text-only +
        # fully guarded → output-neutral, can only correct a stale number.
        def _sync_count_labels(*_a):
            try:
                # List rows (with the #98 groups-per-zone column + >16 highlight).
                _render_splitter_list()
                for _combo in (combo_target, combo_del_sp, combo_add_dp_grp):
                    if not _combo:
                        continue
                    for _ci in range(_combo.count()):
                        _txt = _combo.itemText(_ci)
                        for _sd in splitter_data:
                            if _txt.startswith(f"Splitter {_sd['group_id']}  |"):
                                _combo.setItemText(_ci,
                                    f"Splitter {_sd['group_id']}  |  PON {_sd['zone_id']}  |  {_sd['drop_count']} drops")
                                break
            except Exception:
                pass

        sp_sel_row = QHBoxLayout()
        btn_select_all = QPushButton("Select All")
        btn_clear_sel  = QPushButton("Clear Selection")
        btn_zoom_sel   = QPushButton("Zoom to Selected")
        btn_zoom_sel.setToolTip("Zoom the map canvas to the selected splitters")
        sp_sel_row.addWidget(btn_select_all)
        sp_sel_row.addWidget(btn_clear_sel)
        sp_sel_row.addWidget(btn_zoom_sel)
        sp_sel_row.addStretch()
        sp_layout.addLayout(sp_sel_row)

        summary_box = QGroupBox("Selection Summary")
        form = QFormLayout(summary_box)
        lbl_sel_count = QLabel("0")
        lbl_sel_zones = QLabel("—")
        lbl_sel_drops = QLabel("0")
        form.addRow("Selected:",      lbl_sel_count)
        form.addRow("Current Zones:", lbl_sel_zones)
        form.addRow("Total Drops:",   lbl_sel_drops)
        sp_layout.addWidget(summary_box)

        nz_box = QGroupBox("New Zone Assignment")
        nz_row = QHBoxLayout(nz_box)
        nz_row.addWidget(QLabel("New Zone ID:"))
        spin = QSpinBox()
        spin.setMinimum(0)
        spin.setMaximum(9999)
        nz_row.addWidget(spin)
        nz_row.addStretch()
        btn_apply_sp = QPushButton("Apply Zone Change")
        btn_apply_sp.setDefault(True)
        btn_undo_sp = QPushButton("↩ Undo")
        btn_undo_sp.setEnabled(False)
        btn_undo_sp.setToolTip("Undo the last applied change")
        nz_row.addWidget(btn_apply_sp)
        nz_row.addWidget(btn_undo_sp)
        sp_layout.addWidget(nz_box)

        tab_widget.addTab(tab_sp, "Splitter Zones")

        # ----------------------------------------------------------------
        # TAB 1 — Demand Points
        # ----------------------------------------------------------------
        tab_dp = QWidget()
        dp_layout = QVBoxLayout(tab_dp)
        dp_layout.setSpacing(6)

        # State for add-new-demand-point mode (shared with map tool section)
        _dp_new_point = [None]   # [QgsPointXY or None]
        _dp_add_mode  = [False]  # True while "Place on Map" is active

        if demand_data:
            dp_layout.addWidget(QLabel("<b>Select demand points and reassign them to a different splitter.</b>"))
            dp_layout.addWidget(QLabel(
                "Draw a polygon on the map (left-click to add vertices, right-click to finish and select) "
                "or use Ctrl/Shift+click on the list."))

            dem_list = QListWidget()
            dem_list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
            dem_list.setMinimumHeight(160)
            for dd in demand_data:
                dem_list.addItem(f"DP {dd['fid']}   |   Group {dd['group_id']}   |   Zone {dd['zone_id']}")
            dp_layout.addWidget(dem_list)

            dp_sel_row = QHBoxLayout()
            btn_dp_select_all = QPushButton("Select All")
            btn_dp_clear_sel  = QPushButton("Clear Selection")
            dp_sel_row.addWidget(btn_dp_select_all)
            dp_sel_row.addWidget(btn_dp_clear_sel)
            dp_sel_row.addStretch()
            dp_layout.addLayout(dp_sel_row)

            dp_info_box = QGroupBox("Selection Info")
            dp_form = QFormLayout(dp_info_box)
            lbl_dp_count = QLabel("0")
            lbl_dp_groups = QLabel("—")
            dp_form.addRow("Selected:",        lbl_dp_count)
            dp_form.addRow("Current Groups:",  lbl_dp_groups)
            dp_layout.addWidget(dp_info_box)

            tgt_box = QGroupBox("Target Splitter")
            tgt_form = QFormLayout(tgt_box)

            # Manual group ID entry
            from qgis.PyQt.QtWidgets import QSpinBox
            spin_grp = QSpinBox()
            spin_grp.setMinimum(1)
            spin_grp.setMaximum(99999)
            spin_grp.setValue(splitter_data[0]['group_id'] if splitter_data else 1)
            spin_grp.setToolTip("Type or select the target Splitter ID directly")
            tgt_form.addRow("Group ID (manual):", spin_grp)

            combo_target = QComboBox()
            combo_target.setMinimumWidth(300)
            for sd in splitter_data:
                combo_target.addItem(f"Splitter {sd['group_id']}  |  PON {sd['zone_id']}  |  {sd['drop_count']} drops")
            tgt_form.addRow("Or pick from list:", combo_target)

            # Sync spin_grp ↔ combo_target
            def _combo_to_spin(idx):
                if 0 <= idx < len(splitter_data):
                    spin_grp.blockSignals(True)
                    spin_grp.setValue(splitter_data[idx]['group_id'])
                    spin_grp.blockSignals(False)

            def _spin_to_combo():
                gid = spin_grp.value()
                for i, sd in enumerate(splitter_data):
                    if sd['group_id'] == gid:
                        combo_target.blockSignals(True)
                        combo_target.setCurrentIndex(i)
                        combo_target.blockSignals(False)
                        return

            combo_target.currentIndexChanged.connect(_combo_to_spin)
            spin_grp.valueChanged.connect(_spin_to_combo)
            dp_layout.addWidget(tgt_box)

            dp_btn_row = QHBoxLayout()
            btn_apply_dp = QPushButton("Apply Demand Reassignment")
            btn_undo_dp  = QPushButton("↩ Undo")
            btn_undo_dp.setEnabled(False)
            btn_undo_dp.setToolTip("Undo the last applied change")
            btn_regen_drops_dp = QPushButton("🔄 Regenerate Drops")
            btn_regen_drops_dp.setStyleSheet(
                "QPushButton { background-color: #d9534f; color: white; font-weight: bold; }")
            btn_regen_drops_dp.setToolTip(
                "Manually regenerate drop cables after reassigning demand points or moving splitters.")
            dp_btn_row.addWidget(btn_apply_dp)
            dp_btn_row.addWidget(btn_undo_dp)
            dp_btn_row.addWidget(btn_regen_drops_dp)
            dp_btn_row.addStretch()
            dp_layout.addLayout(dp_btn_row)

            # Ticket #113 (Luke): project-wide "draw every drop, even across a road" toggle.
            # OFF (default) keeps the per-drop road barrier (#68 — road crossings skipped
            # unless manually assigned). ON draws ALL drops so the planner gets visual proof
            # of connectivity. Persisted on the project (survives reload); toggling it
            # regenerates drops immediately so the change is visible at once.
            from qgis.PyQt.QtWidgets import QCheckBox as _QCB113
            chk_show_all_drops = _QCB113("Show all drops (even those crossing a road)")
            chk_show_all_drops.setChecked(self._show_all_drops())
            chk_show_all_drops.setToolTip(
                "ON: every drop cable is drawn, including ones that cross a road — visual "
                "confirmation of all connections.\nOFF: drops that cross a road are skipped "
                "unless you manually assign that demand point to its splitter.")

            def _on_show_all_drops_toggled(_state=None):
                _on = chk_show_all_drops.isChecked()
                self._set_show_all_drops(_on)
                self.log_message(
                    f"[Manual Override] Show all drops {'ON' if _on else 'OFF'} (#113) — regenerating drops…")
                try:
                    _regen_drops(only_groups=None)
                except Exception as _e113:
                    self.log_message(f"  drop regen after show-all toggle failed: {_e113}")
            chk_show_all_drops.toggled.connect(_on_show_all_drops_toggled)
            dp_layout.addWidget(chk_show_all_drops)

            # Ticket #68: the #66 "Allow drop cables to cross roads" checkbox was
            # removed. Road crossing is now per-drop — only demand points the planner
            # reassigns/adds to a splitter (collected in _force_cross) cross a road.

            # ---- Add New Demand Point section --------------------------------
            add_dp_box = QGroupBox("Add New Demand Point")
            add_dp_vbox = QVBoxLayout(add_dp_box)
            add_dp_vbox.setSpacing(4)

            add_dp_vbox.addWidget(QLabel(
                "Click <b>📍 Place on Map</b>, then click the map to capture coordinates.\n"
                "The PON is auto-detected. Assign a splitter before adding."))

            # Captured location
            add_dp_loc_box = QGroupBox("Captured Location")
            add_dp_loc_form = QFormLayout(add_dp_loc_box)
            lbl_new_dp_x = QLabel("—")
            lbl_new_dp_y = QLabel("—")
            add_dp_loc_form.addRow("X (Easting):",  lbl_new_dp_x)
            add_dp_loc_form.addRow("Y (Northing):", lbl_new_dp_y)
            add_dp_vbox.addWidget(add_dp_loc_box)

            # Attributes
            add_dp_attr_box = QGroupBox("Demand Point Attributes")
            add_dp_attr_form = QFormLayout(add_dp_attr_box)

            from qgis.PyQt.QtWidgets import QSpinBox as _DPSpinBox
            spin_dp_zone = _DPSpinBox()
            spin_dp_zone.setMinimum(0)
            spin_dp_zone.setMaximum(99999)
            spin_dp_zone.setValue(0)
            spin_dp_zone.setToolTip("Auto-detected from the PON polygon; editable")

            combo_add_dp_grp = QComboBox()
            combo_add_dp_grp.setMinimumWidth(280)
            combo_add_dp_grp.addItem("— Select splitter —")
            for _sd in splitter_data:
                combo_add_dp_grp.addItem(
                    f"Splitter {_sd['group_id']}  |  PON {_sd['zone_id']}  |  {_sd['drop_count']} drops")
            # Ticket #61: type-to-search + scrollable popup for the splitter list.
            self._make_combo_searchable(combo_add_dp_grp)

            add_dp_attr_form.addRow("PON (auto):",    spin_dp_zone)
            add_dp_attr_form.addRow("Assign to Splitter:", combo_add_dp_grp)
            add_dp_vbox.addWidget(add_dp_attr_box)

            add_dp_btn_row = QHBoxLayout()
            btn_place_dp = QPushButton("📍 Place on Map")
            btn_place_dp.setCheckable(True)
            btn_place_dp.setStyleSheet(
                "QPushButton:checked  { background-color: #9b59b6; color: white; font-weight: bold; }"
                "QPushButton:!checked { background-color: #ecf0f1; color: black; }")
            btn_place_dp.setToolTip("Enable then click the map to capture location for the new demand point.")

            btn_add_dp = QPushButton("Add Demand Point")
            btn_add_dp.setEnabled(False)
            btn_add_dp.setStyleSheet(
                "QPushButton:enabled  { background-color: #4CAF50; color: white; font-weight: bold; }"
                "QPushButton:disabled { background-color: #cccccc; color: #888; }")
            btn_add_dp.setToolTip("Disabled until a location is captured AND a splitter is selected.")

            btn_clear_new_dp = QPushButton("Clear")
            add_dp_btn_row.addWidget(btn_place_dp)
            add_dp_btn_row.addWidget(btn_add_dp)
            add_dp_btn_row.addWidget(btn_clear_new_dp)
            add_dp_btn_row.addStretch()
            add_dp_vbox.addLayout(add_dp_btn_row)
            dp_layout.addWidget(add_dp_box)

            # ---- Delete Demand Point section ---------------------------------
            del_dp_box = QGroupBox("Delete Demand Point")
            del_dp_vbox = QVBoxLayout(del_dp_box)
            del_dp_vbox.setSpacing(4)
            del_dp_vbox.addWidget(QLabel(
                "Select demand points in the list above, then click Delete to remove them from the layer."))
            del_dp_btn_row = QHBoxLayout()
            btn_delete_dp = QPushButton("🗑 Delete Selected Demand Points")
            btn_delete_dp.setStyleSheet(
                "QPushButton { background-color: #c0392b; color: white; font-weight: bold; }")
            btn_delete_dp.setToolTip("Permanently deletes the selected demand points from the layer.")
            del_dp_btn_row.addWidget(btn_delete_dp)
            # Ticket #99 (Lodewijk): a dedicated Undo right next to Delete so a
            # mistaken deletion can be reversed without hunting for it. Shares the
            # same undo stack as the other Undo buttons (re-adds the deleted points,
            # restores counts, regenerates drops).
            btn_undo_del_dp = QPushButton("↩ Undo Delete")
            btn_undo_del_dp.setEnabled(False)
            btn_undo_del_dp.setToolTip("Undo the last delete (restores the deleted demand points).")
            del_dp_btn_row.addWidget(btn_undo_del_dp)
            del_dp_btn_row.addStretch()
            del_dp_vbox.addLayout(del_dp_btn_row)
            dp_layout.addWidget(del_dp_box)

            # helper: re-evaluate Add button state
            def _refresh_add_dp_btn():
                _has_pt  = _dp_new_point[0] is not None
                _has_grp = combo_add_dp_grp.currentIndex() > 0   # index 0 is "— Select splitter —"
                btn_add_dp.setEnabled(_has_pt and _has_grp)

            combo_add_dp_grp.currentIndexChanged.connect(lambda _: _refresh_add_dp_btn())

            def _clear_new_dp():
                _dp_new_point[0] = None
                lbl_new_dp_x.setText("—")
                lbl_new_dp_y.setText("—")
                spin_dp_zone.setValue(0)
                combo_add_dp_grp.setCurrentIndex(0)
                btn_place_dp.setChecked(False)
                btn_add_dp.setEnabled(False)

            btn_clear_new_dp.clicked.connect(_clear_new_dp)

        else:
            dp_layout.addWidget(QLabel("No Demand Points layer found.\nGenerate demand points first."))
            dem_list         = None
            combo_target     = None
            btn_apply_dp     = None
            btn_undo_dp      = None
            btn_undo_del_dp  = None
            btn_regen_drops_dp = None
            btn_place_dp     = None
            btn_add_dp       = None
            btn_delete_dp    = None
            combo_add_dp_grp = None
            spin_dp_zone     = None
            lbl_new_dp_x     = None
            lbl_new_dp_y     = None

        tab_widget.addTab(tab_dp, "Demand Points")

        # ----------------------------------------------------------------
        # TAB 2 — Add Splitter Point
        # ----------------------------------------------------------------
        tab_ns = QWidget()
        ns_layout = QVBoxLayout(tab_ns)
        ns_layout.setSpacing(6)

        ns_layout.addWidget(QLabel("<b>Manually place a new splitter point on the map.</b>"))
        ns_layout.addWidget(QLabel(
            "Click on the map to capture coordinates, then confirm attributes and click Add."))

        # Captured location display
        ns_loc_box = QGroupBox("Captured Location")
        ns_loc_form = QFormLayout(ns_loc_box)
        lbl_ns_x = QLabel("—")
        lbl_ns_y = QLabel("—")
        ns_loc_form.addRow("X (Easting):", lbl_ns_x)
        ns_loc_form.addRow("Y (Northing):", lbl_ns_y)
        ns_layout.addWidget(ns_loc_box)

        # Auto-detected / editable attributes
        ns_attr_box = QGroupBox("Splitter Attributes")
        ns_attr_form = QFormLayout(ns_attr_box)

        _max_grp = max((sd['group_id'] for sd in splitter_data), default=0)
        from qgis.PyQt.QtWidgets import QSpinBox as _NSSpinBox
        spin_ns_zone = _NSSpinBox()
        spin_ns_zone.setMinimum(0)
        spin_ns_zone.setMaximum(99999)
        spin_ns_zone.setValue(0)
        spin_ns_zone.setToolTip("Auto-detected from the PON polygon; editable")

        spin_ns_group = _NSSpinBox()
        spin_ns_group.setMinimum(1)
        spin_ns_group.setMaximum(999999)
        spin_ns_group.setValue(_max_grp + 1)
        spin_ns_group.setToolTip("Suggested next group ID; editable")

        spin_ns_drops = _NSSpinBox()
        spin_ns_drops.setMinimum(0)
        spin_ns_drops.setMaximum(9999)
        spin_ns_drops.setValue(0)
        spin_ns_drops.setToolTip("Number of drop cables (demand points) for this splitter")

        ns_attr_form.addRow("PON (auto):", spin_ns_zone)
        ns_attr_form.addRow("Group ID:",       spin_ns_group)
        ns_attr_form.addRow("Drop Count:",     spin_ns_drops)
        ns_layout.addWidget(ns_attr_box)

        ns_btn_row = QHBoxLayout()
        btn_add_sp  = QPushButton("Add Splitter Point")
        btn_add_sp.setEnabled(False)
        btn_add_sp.setStyleSheet(
            "QPushButton:enabled  { background-color: #4CAF50; color: white; font-weight: bold; }"
            "QPushButton:disabled { background-color: #cccccc; color: #888; }")
        btn_clear_ns = QPushButton("Clear")
        ns_btn_row.addWidget(btn_add_sp)
        ns_btn_row.addWidget(btn_clear_ns)
        ns_btn_row.addStretch()
        ns_layout.addLayout(ns_btn_row)
        ns_layout.addStretch()

        # Container for the pending point coords
        _ns_point = [None]   # [QgsPointXY or None]

        def _clear_ns():
            _ns_point[0] = None
            lbl_ns_x.setText("—")
            lbl_ns_y.setText("—")
            btn_add_sp.setEnabled(False)
            spin_ns_zone.setValue(0)
            spin_ns_group.setValue(max((sd['group_id'] for sd in splitter_data), default=0) + 1)
            spin_ns_drops.setValue(0)

        btn_clear_ns.clicked.connect(_clear_ns)

        def _do_add_splitter():
            if not _ns_point[0]:
                status_lbl.setText("<font color='red'>No point captured. Click the map first.</font>")
                return
            from qgis.core import QgsFeature, QgsGeometry, QgsPointXY
            _pt = _ns_point[0]
            _gid  = spin_ns_group.value()
            _zid  = spin_ns_zone.value()
            _dcnt = spin_ns_drops.value()

            # Guard: duplicate group_id
            if any(sd['group_id'] == _gid for sd in splitter_data):
                status_lbl.setText(
                    f"<font color='red'>Group ID {_gid} already exists. Choose a different Group ID.</font>")
                return

            new_feat = QgsFeature(splitter_layer.fields())
            new_feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(_pt.x(), _pt.y())))
            # Write by FIELD NAME, never by position — the splitter layer is
            # resolved dynamically (PON accumulator / name search), so its column
            # order isn't guaranteed; a positional write would land values in the
            # wrong columns and corrupt the new splitter.
            _sf = splitter_layer.fields()
            def _set_sp(_name, _val):
                _i = _sf.indexFromName(_name)
                if _i >= 0:
                    new_feat.setAttribute(_i, _val)
            _set_sp('fid', _gid)
            _set_sp('ID', str(_gid))
            _set_sp('group_id', _gid)
            _set_sp('zone_id', _zid)
            _set_sp('drop_count', _dcnt)

            splitter_layer.startEditing()
            # gate success on BOTH the buffer insert AND the commit — a failed
            # commit (locked/read-only layer) would otherwise leave in-memory UI
            # state referencing a group_id that never landed in the layer
            ok = splitter_layer.addFeature(new_feat) and _safe_commit(splitter_layer)

            # If writing to the PON accumulator, rebuild the renderer so the
            # new zone_id gets a colour category and the point becomes visible.
            _accum_sp = getattr(self, '_pon_accum_splitters', None)
            try:
                from qgis.PyQt import sip as _sip2
                if _accum_sp and not _sip2.isdeleted(_accum_sp) and splitter_layer is _accum_sp:
                    self._pon_refresh_accum_renderers()
                else:
                    splitter_layer.triggerRepaint()
            except Exception:
                splitter_layer.triggerRepaint()

            if ok:
                # Update in-memory list so tab 0 reflects the new splitter
                _new_fid = new_feat.id()
                # On disk-backed layers the committed FID differs from the
                # pre-commit id; re-fetch by the (unique, just-guarded) group_id
                # so a later edit/delete acts on the right feature, not a stale id.
                try:
                    if _sf.indexFromName('group_id') >= 0:
                        for _ff in splitter_layer.getFeatures():
                            if _ff['group_id'] == _gid:
                                _new_fid = _ff.id()
                                break
                except Exception:
                    pass
                splitter_data.append({
                    'fid':        _new_fid,
                    'group_id':   _gid,
                    'zone_id':    _zid,
                    'drop_count': _dcnt,
                    'x':          _pt.x(),
                    'y':          _pt.y(),
                })
                list_widget.addItem("")  # text+style set by _sync_count_labels() below
                # Update combo in demand tab
                if demand_data:
                    combo_target.addItem(
                        f"Splitter {_gid}  |  PON {_zid}  |  {_dcnt} drops")
                # Keep the Delete-Splitter and Assign-to-Splitter dropdowns in
                # sync — both map their index back into splitter_data by
                # position, so the just-appended splitter must be appended here
                # too or it can't be selected for deletion / demand assignment.
                combo_del_sp.addItem(
                    f"Splitter {_gid}  |  PON {_zid}  |  {_dcnt} drops")
                if combo_add_dp_grp is not None:
                    combo_add_dp_grp.addItem(
                        f"Splitter {_gid}  |  PON {_zid}  |  {_dcnt} drops")

                status_lbl.setText(
                    f"<font color='green'><b>✓ Splitter added:</b> "
                    f"Splitter {_gid} | PON {_zid} | {_dcnt} drops at "
                    f"({_pt.x():.1f}, {_pt.y():.1f})</font>")
                self.log_message(
                    f"Manual Override — new splitter: Group {_gid}, Zone {_zid}, "
                    f"drops={_dcnt}, pos=({_pt.x():.2f}, {_pt.y():.2f})")
                # Re-render so the new row gets the #98 column/highlight and every
                # other row in this zone updates its groups-in-zone count.
                _sync_count_labels()
                _clear_ns()
            else:
                status_lbl.setText("<font color='red'>Failed to add splitter feature to layer.</font>")

        btn_add_sp.clicked.connect(_do_add_splitter)

        # ---- Move / Edit / Regenerate buttons ----
        action_btn_row = QHBoxLayout()
        btn_move_sp = QPushButton("Move Splitter")
        btn_move_sp.setCheckable(True)
        btn_move_sp.setStyleSheet(
            "QPushButton:checked  { background-color: #e67e22; color: white; font-weight: bold; }"
            "QPushButton:!checked { background-color: #ecf0f1; color: black; }")
        btn_move_sp.setToolTip(
            "Click to enable: then click a splitter on the map to select it, "
            "then click the new location to move it there.")

        btn_edit_sp = QPushButton("Edit Splitter")
        btn_edit_sp.setCheckable(True)
        btn_edit_sp.setStyleSheet(
            "QPushButton:checked  { background-color: #2980b9; color: white; font-weight: bold; }"
            "QPushButton:!checked { background-color: #ecf0f1; color: black; }")
        btn_edit_sp.setToolTip(
            "Click to enable: then click a splitter on the map to load its attributes, "
            "edit the values above, then click Apply Edit to save.")

        btn_regen_drops_sp = QPushButton("Regenerate Drops")
        btn_regen_drops_sp.setStyleSheet(
            "QPushButton { background-color: #d9534f; color: white; font-weight: bold; }")
        btn_regen_drops_sp.setToolTip("Re-run Generate Drops PTP to update drop cables from splitters to demand points.")

        action_btn_row.addWidget(btn_move_sp)
        action_btn_row.addWidget(btn_edit_sp)
        action_btn_row.addWidget(btn_regen_drops_sp)
        action_btn_row.addStretch()
        ns_layout.addLayout(action_btn_row)

        # Apply Edit button (hidden until edit mode is active)
        edit_apply_row = QHBoxLayout()
        btn_apply_edit_sp = QPushButton("Apply Edit")
        btn_apply_edit_sp.setEnabled(False)
        btn_apply_edit_sp.setStyleSheet(
            "QPushButton:enabled  { background-color: #27ae60; color: white; font-weight: bold; }"
            "QPushButton:disabled { background-color: #cccccc; color: #888; }")
        btn_apply_edit_sp.setToolTip("Save the edited attributes back to the selected splitter.")
        edit_apply_row.addWidget(btn_apply_edit_sp)
        edit_apply_row.addStretch()
        ns_layout.addLayout(edit_apply_row)

        _edit_state = {"fid": None}   # fid of splitter being edited

        def _apply_splitter_edit():
            fid = _edit_state["fid"]
            if fid is None:
                return
            new_zid  = spin_ns_zone.value()
            new_gid  = spin_ns_group.value()
            new_dcnt = spin_ns_drops.value()

            # Read old values before editing so we can detect zone changes
            fnames = [f.name() for f in splitter_layer.fields()]
            old_feat = splitter_layer.getFeature(fid)
            if not old_feat.isValid():
                # MO audit: the picked splitter was deleted/recommitted since selection →
                # getFeature returns an invalid feature and reading a field would KeyError.
                # Bail cleanly instead of crashing mid-edit.
                status_lbl.setText("<font color='red'>That splitter no longer exists — re-select it.</font>")
                _edit_state["fid"] = None
                return
            old_zid  = int(old_feat["zone_id"]  or 0) if "zone_id"  in fnames else new_zid
            try:
                old_gid = int(old_feat["group_id"]) if "group_id" in fnames else new_gid
            except (TypeError, ValueError):
                old_gid = new_gid

            # Batch D: reject a duplicate group_id. Both drop generators key
            # splitters_by_group by group_id, so two splitters sharing one makes one
            # OVERWRITE the other → every demand point in that group collapses onto a
            # single (often far) splitter = long mis-routed drops. The Add path guards
            # this; the Edit path didn't.
            if "group_id" in fnames and new_gid != old_gid:
                _dupe = False
                for _osf in splitter_layer.getFeatures():
                    if _osf.id() == fid:
                        continue
                    try:
                        if int(_osf["group_id"]) == new_gid:
                            _dupe = True
                            break
                    except (TypeError, ValueError):
                        continue
                if _dupe:
                    from qgis.PyQt.QtWidgets import QMessageBox as _QMB
                    _QMB.warning(self, "Duplicate Group ID",
                                 f"Group ID {new_gid} is already used by another splitter.\n\n"
                                 "Two splitters can't share a group — drops would collapse onto "
                                 "one. Pick a different Group ID.")
                    return

            splitter_layer.startEditing()  # claude:approved-destructive (single-feature attr edit via _safe_commit)
            if "zone_id"    in fnames: splitter_layer.changeAttributeValue(fid, fnames.index("zone_id"),    new_zid)
            if "group_id"   in fnames: splitter_layer.changeAttributeValue(fid, fnames.index("group_id"),   new_gid)
            if "drop_count" in fnames: splitter_layer.changeAttributeValue(fid, fnames.index("drop_count"), new_dcnt)
            _safe_commit(splitter_layer)
            splitter_layer.removeSelection()
            # Rebuild renderer if editing accumulator so zone colour stays correct
            _accum_sp_e = getattr(self, '_pon_accum_splitters', None)
            try:
                from qgis.PyQt import sip as _sip3
                if _accum_sp_e and not _sip3.isdeleted(_accum_sp_e) and splitter_layer is _accum_sp_e:
                    self._pon_refresh_accum_renderers()
                else:
                    splitter_layer.triggerRepaint()
            except Exception:
                splitter_layer.triggerRepaint()

            # --- Cascade group_id change to demand points --------------------
            # If group_id was changed, update all demand points that referenced the
            # old group_id so their physical splitter connection is preserved.
            if old_gid != new_gid and _dem_layer and _dp_link:
                _dp_grp_idx_ed = _dem_layer.fields().indexFromName(_dp_link)
                if _dp_grp_idx_ed >= 0:
                    # bulk write via the data provider — never per-feature
                    # changeAttributeValue() inside startEditing() over the whole
                    # demand layer (main-thread freeze on large layers)
                    _dp_attr_map = {}
                    for _ef in _dem_layer.getFeatures():
                        try:
                            _ef_gid = int(_ef[_dp_link])
                        except (TypeError, ValueError):
                            continue
                        if _ef_gid == old_gid:
                            _dp_attr_map[_ef.id()] = {_dp_grp_idx_ed: new_gid}
                    if _dp_attr_map:
                        _dem_layer.dataProvider().changeAttributeValues(_dp_attr_map)
                    _dem_layer.triggerRepaint()
                # Update in-memory demand_data too
                for _de in demand_data:
                    if _de['group_id'] == old_gid:
                        _de['group_id'] = new_gid
                self.log_message(
                    f"[Edit Splitter] group_id cascade: {old_gid} → {new_gid} on demand layer '{_dem_layer.name()}'")

            # --- Cascade zone change to PON Zone boundary polygon -----------
            # Only needed when zone_id actually changed.
            if old_zid != new_zid:
                # Determine which group_id to look up demand points for.
                # Use new_gid (just edited) which is the authoritative group link.
                _edit_grp = new_gid

                # Locate demand / grouped layer and its group link field
                _el = None
                _el_link = None
                from qgis.PyQt import sip as _sip2
                # MO audit: prefer the demand layer the dialog is actually editing
                # (_dem_layer) so the zone cascade can't land on a different
                # name-matched layer than the group cascade did.
                for _cand in (_dem_layer, self.demand_points_layer):
                    try:
                        if _cand and not _sip2.isdeleted(_cand):
                            _el = _cand
                            break
                    except Exception:
                        pass
                if not _el:
                    for _lx in QgsProject.instance().mapLayers().values():
                        if isinstance(_lx, QgsVectorLayer):
                            _ln = _lx.name().lower()
                            if 'demand points' in _ln or 'demand_points' in _ln:
                                _el = _lx
                                break
                if _el:
                    _efnames = [f.name() for f in _el.fields()]
                    _el_link = _demand_group_field(_efnames)  # #79: any group_<N> size
                    # Also update zone_id on demand points for this group
                    _el_zi = _el.fields().indexFromName('zone_id') if 'zone_id' in _efnames else -1
                    _el_zni = _el.fields().indexFromName('zone_name') if 'zone_name' in _efnames else -1
                    if _el_link and _el_zi >= 0:
                        # bulk write via the data provider — never per-feature
                        # changeAttributeValue() inside startEditing() over the
                        # whole demand layer (main-thread freeze on large layers)
                        _el_attr_map = {}
                        for _ef in _el.getFeatures():
                            try:
                                _efg = int(_ef[_el_link])
                            except (TypeError, ValueError):
                                continue
                            if _efg == int(_edit_grp):  # MO audit: int-normalize match
                                _vals = {_el_zi: new_zid}
                                if _el_zni >= 0:
                                    _vals[_el_zni] = vf_pon_name(new_zid)
                                _el_attr_map[_ef.id()] = _vals
                        if _el_attr_map:
                            _el.dataProvider().changeAttributeValues(_el_attr_map)
                        _el.triggerRepaint()

                # Rebuild PON Zone boundary polygons for old_zid and new_zid
                _src_lyr  = _el if (_el and _el_link) else None
                _src_link = _el_link

                # If demand layer not usable, fall back to grouped_layer
                if not _src_lyr:
                    _gl = getattr(self, 'grouped_layer', None)
                    try:
                        if _gl and not _sip2.isdeleted(_gl):
                            _gfn = [f.name() for f in _gl.fields()]
                            _gl_link = _demand_group_field(_gfn)  # #79: any group_<N> size
                            if _gl_link:
                                _src_lyr  = _gl
                                _src_link = _gl_link
                    except Exception:
                        pass

                if _src_lyr and _src_link:
                    # Build zone→groups mapping from the full splitter layer (post-edit)
                    _z2g_edit: dict = {}
                    for _sf2 in splitter_layer.getFeatures():
                        _z = int(_sf2["zone_id"] or 0) if "zone_id" in fnames else -1
                        _g = _sf2["group_id"] if "group_id" in fnames else None
                        if _g is not None:
                            _z2g_edit.setdefault(_z, set()).add(_g)

                    for _pon_lyr in QgsProject.instance().mapLayers().values():
                        if not (isinstance(_pon_lyr, QgsVectorLayer) and 'PON Zones' in _pon_lyr.name()):
                            continue
                        _pf = [f.name() for f in _pon_lyr.fields()]
                        if 'zone_id' not in _pf or 'unit_count' not in _pf:
                            continue
                        _uc_idx = _pon_lyr.fields().indexFromName('unit_count')
                        _pon_lyr.startEditing()
                        _old_found = False
                        _new_found = False
                        _del_fids  = []
                        for _pf2 in _pon_lyr.getFeatures():
                            _pzid = int(_pf2['zone_id'] or 0)
                            if _pzid == old_zid:
                                _old_found = True
                                _rem_grps = _z2g_edit.get(old_zid, set())
                                _rem_feats = [_ff for _ff in _src_lyr.getFeatures()
                                              if _ff[_src_link] in _rem_grps]
                                if _rem_feats:
                                    _oz_geom = self._build_zone_polygon(_src_lyr, _rem_feats)
                                    if not _oz_geom.isEmpty():
                                        _pon_lyr.changeGeometry(_pf2.id(), _oz_geom)
                                    new_uc = sum(1 for _ in _rem_feats)
                                    _pon_lyr.changeAttributeValue(_pf2.id(), _uc_idx, new_uc)
                                else:
                                    _del_fids.append(_pf2.id())
                            elif _pzid == new_zid:
                                _new_found = True
                                _new_grps = _z2g_edit.get(new_zid, set())
                                _nz_feats = [_ff for _ff in _src_lyr.getFeatures()
                                             if _ff[_src_link] in _new_grps]
                                if _nz_feats:
                                    _nz_geom = self._build_zone_polygon(_src_lyr, _nz_feats)
                                    if not _nz_geom.isEmpty():
                                        _pon_lyr.changeGeometry(_pf2.id(), _nz_geom)
                                    new_uc = sum(1 for _ in _nz_feats)
                                    _pon_lyr.changeAttributeValue(_pf2.id(), _uc_idx, new_uc)
                        if _del_fids:
                            _pon_lyr.deleteFeatures(_del_fids)
                        # Create new polygon if new zone has no existing polygon
                        if not _new_found:
                            _new_grps = _z2g_edit.get(new_zid, set())
                            _nz_feats = [_ff for _ff in _src_lyr.getFeatures()
                                         if _ff[_src_link] in _new_grps]
                            if _nz_feats:
                                from qgis.core import QgsFeature as _QFe
                                _nz_geom = self._build_zone_polygon(_src_lyr, _nz_feats)
                                if not _nz_geom.isEmpty():
                                    _nf = _QFe(_pon_lyr.fields())
                                    _nf.setGeometry(_nz_geom)
                                    _nf['zone_id']    = new_zid
                                    _nf['zone_name']  = vf_pon_name(new_zid)
                                    _nf['unit_count'] = sum(1 for _ in _nz_feats)
                                    _pon_lyr.addFeature(_nf)
                        _safe_commit(_pon_lyr)
                        _pon_lyr.triggerRepaint()
                        break

            status_lbl.setText(
                f"<font color='green'><b>✓ Splitter FID {fid} updated:</b> "
                f"PON {new_zid} | Splitter {new_gid} | Drops {new_dcnt} — regenerating drop cables…</font>")
            _edit_state["fid"] = None
            # Ticket #96: sync the in-memory splitter_data with the just-saved edit and
            # re-render every count display. The edit path previously wrote only to the
            # layer, so the Splitter Zones list / Total Drops summary / combos showed a
            # stale zone/group/drop_count until the dialog was reopened.
            for _sd in splitter_data:
                if _sd.get('fid') == fid:
                    _sd['zone_id']    = new_zid
                    _sd['group_id']   = new_gid
                    _sd['drop_count'] = new_dcnt
                    break
            _sync_count_labels()
            btn_apply_edit_sp.setEnabled(False)
            btn_edit_sp.setChecked(False)
            _clear_ns()
            # Regenerate drop cables so lines reflect any position or attribute changes
            _regen_drops()
            status_lbl.setText(
                f"<font color='green'><b>✓ Splitter FID {fid} updated</b> — drops regenerated.</font>")

        btn_apply_edit_sp.clicked.connect(_apply_splitter_edit)

        def _do_regen_drops():
            status_lbl.setText("<font color='orange'>Regenerating drop cables…</font>")
            try:
                _regen_drops()
                # Ticket #97 (Luke): live-refresh every count display after a move /
                # regenerate so the list, combos and Total Drops are guaranteed current
                # the instant a splitter is moved (this is also the move tool's callback).
                _sync_count_labels()
                _dr = _drop_layer if (_drop_layer is not None and not sip.isdeleted(_drop_layer)) \
                    else getattr(self, 'drop_ptp_layer', None)
                _lyr_name = _dr.name() if _dr else "Drop Cables PTP"
                _cnt = _dr.featureCount() if _dr else 0
                status_lbl.setText(
                    f"<font color='green'><b>✓ Drop cables regenerated</b> — "
                    f"{_cnt} cables in '{_lyr_name}'</font>")
            except Exception as _regen_err:
                status_lbl.setText(
                    f"<font color='red'>⚠ Drop regen failed: {_regen_err}</font>")
                self.log_message(f"[Manual Override] Drop regen error: {_regen_err}")

        btn_regen_drops_sp.clicked.connect(_do_regen_drops)

        # State for two-click move: [selected_fid, selected_geom]
        _move_state = [None, None]   # [fid, QgsGeometry snapshot]

        from qgis.gui import QgsMapToolEmitPoint as _QMTEP

        class _MoveSplitterTool(_QMTEP):
            def __init__(self, canvas, state, layer, status, btn, prev_tool, regen_cb=None):
                super().__init__(canvas)
                self._state    = state
                self._layer    = layer
                self._status   = status
                self._btn      = btn
                self._prev     = prev_tool
                self._regen_cb = regen_cb  # called after a successful move to regenerate drops

            def canvasReleaseEvent(self, e):
                # ticket #65 / MO12: bail if the dialog is gone OR its widgets were
                # already destroyed (plugin reload can delete them before the
                # destroyed-flag fires) — never touch a deleted C++ widget.
                from qgis.PyQt import sip as _sipm
                if (_dlg_closed[0] or _sipm.isdeleted(self._status)
                        or _sipm.isdeleted(self._btn)):
                    return
                from qgis.core import QgsGeometry, QgsRectangle
                pt = self.toMapCoordinates(e.pos())
                if self._state[0] is None:
                    # Phase 1: find nearest splitter within a tolerance
                    tol = self.canvas().extent().width() * 0.01
                    rect = QgsRectangle(pt.x()-tol, pt.y()-tol, pt.x()+tol, pt.y()+tol)
                    best_fid, best_dist = None, float("inf")
                    for feat in self._layer.getFeatures():
                        g = feat.geometry()
                        if g and not g.isEmpty():
                            d = g.distance(QgsGeometry.fromPointXY(pt))
                            if d < best_dist:
                                best_dist, best_fid = d, feat.id()
                    # MO audit: gate on the tolerance (was dead code) so a far misclick
                    # can't grab — and then teleport — a splitter across the map.
                    if best_fid is not None and best_dist <= tol:
                        self._state[0] = best_fid
                        self._state[1] = QgsGeometry(self._layer.getFeature(best_fid).geometry())
                        self._layer.selectByIds([best_fid])
                        self._status.setText(
                            f"<font color='orange'>Splitter FID {best_fid} selected — "
                            f"now click the new location.</font>")
                    else:
                        self._status.setText(
                            "<font color='red'>No splitter found near click. Try again.</font>")
                else:
                    # Phase 2: move selected splitter to new location.
                    # claude:intent MUTATE — user asked: "make sure you can use [qgis
                    # snapping] for everything on the velocity nexus". Plan: snap the
                    # drop location; the move write below is the tool's existing,
                    # operator-driven move. claude:approved-destructive — moves one
                    # splitter to the (snapped) clicked point, as before.
                    pt = snap_point_to_project(self.canvas(), pt)
                    fid = self._state[0]
                    self._layer.startEditing()
                    self._layer.changeGeometry(fid, QgsGeometry.fromPointXY(pt))
                    _safe_commit(self._layer)
                    self._layer.removeSelection()
                    self._layer.triggerRepaint()
                    # Show the moved splitter on the canvas IMMEDIATELY (before the
                    # drop-regen), so it doesn't appear to lag a second behind the click.
                    try:
                        self.canvas().refresh()
                    except Exception:
                        pass
                    self._status.setText(
                        f"<font color='green'><b>✓ Splitter moved</b> to "
                        f"({pt.x():.1f}, {pt.y():.1f}) — regenerating drop cables…</font>")
                    self._state[0] = None
                    self._state[1] = None
                    # Deactivate move mode before regen so button state is correct
                    self._btn.setChecked(False)
                    self.canvas().setMapTool(self._prev)
                    # Regenerate drop cables so lines track the new splitter position
                    if self._regen_cb:
                        self._regen_cb()

        _mv_prev = {"tool": None}

        def _toggle_move(checked):
            if checked:
                _mv_prev["tool"] = self.iface.mapCanvas().mapTool()
                tool = _MoveSplitterTool(
                    self.iface.mapCanvas(),
                    _move_state,
                    splitter_layer,
                    status_lbl,
                    btn_move_sp,
                    _mv_prev["tool"],
                    regen_cb=_do_regen_drops)
                self.iface.mapCanvas().setMapTool(tool)
                # store so we can clean up on dialog close
                dlg._move_tool = tool
                status_lbl.setText(
                    "<font color='orange'>Move mode ON — click a splitter to select it.</font>")
            else:
                _move_state[0] = None
                _move_state[1] = None
                splitter_layer.removeSelection()
                if _mv_prev["tool"]:
                    self.iface.mapCanvas().setMapTool(_mv_prev["tool"])
                status_lbl.setText("Move mode OFF.")

        btn_move_sp.toggled.connect(_toggle_move)

        # ---- Edit Splitter map tool ----
        class _EditSplitterTool(_QMTEP):
            def __init__(self, canvas, edit_state, layer, status, btn,
                         spin_zone, spin_group, spin_drops, btn_apply, prev_tool):
                super().__init__(canvas)
                self._edit_state = edit_state
                self._layer      = layer
                self._status     = status
                self._btn        = btn
                self._spin_zone  = spin_zone
                self._spin_group = spin_group
                self._spin_drops = spin_drops
                self._btn_apply  = btn_apply
                self._prev       = prev_tool

            def canvasReleaseEvent(self, e):
                # ticket #65 / MO12: bail if the dialog is gone OR its widgets were
                # already destroyed — never touch a deleted C++ widget.
                from qgis.PyQt import sip as _sipe
                if (_dlg_closed[0] or _sipe.isdeleted(self._status)
                        or _sipe.isdeleted(self._btn) or _sipe.isdeleted(self._btn_apply)):
                    return
                from qgis.core import QgsGeometry
                pt = self.toMapCoordinates(e.pos())
                # Find nearest splitter WITHIN a tolerance (MO10: a far misclick must
                # not silently load+arm-Apply on a distant splitter, mirroring the
                # move tool's tolerance gate).
                tol = self.canvas().extent().width() * 0.01
                best_fid, best_dist = None, float("inf")
                for feat in self._layer.getFeatures():
                    g = feat.geometry()
                    if g and not g.isEmpty():
                        d = g.distance(QgsGeometry.fromPointXY(pt))
                        if d < best_dist:
                            best_dist, best_fid = d, feat.id()
                if best_fid is None or best_dist > tol:
                    self._status.setText("<font color='red'>No splitter found near click.</font>")
                    return
                feat = self._layer.getFeature(best_fid)
                fnames = [f.name() for f in self._layer.fields()]
                self._edit_state["fid"] = best_fid
                self._layer.selectByIds([best_fid])
                if "zone_id"    in fnames: self._spin_zone.setValue(int(feat["zone_id"]  or 0))
                if "group_id"   in fnames: self._spin_group.setValue(int(feat["group_id"] or 0))
                if "drop_count" in fnames: self._spin_drops.setValue(int(feat["drop_count"] or 0))
                self._btn_apply.setEnabled(True)
                self._status.setText(
                    f"<font color='blue'><b>Splitter FID {best_fid} loaded</b> — "
                    f"edit values above then click Apply Edit.</font>")
                # Return to previous tool after selection
                self.canvas().setMapTool(self._prev)
                self._btn.setChecked(False)

        _edit_prev = {"tool": None}

        def _toggle_edit(checked):
            if checked:
                # Ensure move mode is off
                if btn_move_sp.isChecked():
                    btn_move_sp.setChecked(False)
                _edit_prev["tool"] = self.iface.mapCanvas().mapTool()
                tool = _EditSplitterTool(
                    self.iface.mapCanvas(),
                    _edit_state,
                    splitter_layer,
                    status_lbl,
                    btn_edit_sp,
                    spin_ns_zone,
                    spin_ns_group,
                    spin_ns_drops,
                    btn_apply_edit_sp,
                    _edit_prev["tool"])
                self.iface.mapCanvas().setMapTool(tool)
                dlg._edit_tool = tool
                status_lbl.setText(
                    "<font color='blue'>Edit mode ON — click a splitter to load its attributes.</font>")
            else:
                if _edit_prev["tool"]:
                    self.iface.mapCanvas().setMapTool(_edit_prev["tool"])
                status_lbl.setText("Edit mode OFF.")

        btn_edit_sp.toggled.connect(_toggle_edit)

        # Cancel all modes when dialog closes
        _orig_close = dlg.closeEvent if hasattr(dlg, "closeEvent") else None
        def _dlg_close(ev):
            if btn_move_sp.isChecked():
                btn_move_sp.setChecked(False)
            if btn_edit_sp.isChecked():
                btn_edit_sp.setChecked(False)
            if _orig_close:
                _orig_close(ev)
            else:
                ev.accept()
        dlg.closeEvent = _dlg_close

        # ---- Delete Splitter section ----------------------------------------
        del_sp_box = QGroupBox("Delete Splitter")
        del_sp_vbox = QVBoxLayout(del_sp_box)
        del_sp_vbox.setSpacing(4)
        del_sp_vbox.addWidget(QLabel(
            "Choose a splitter to delete. All its demand points will be <b>unlinked</b> "
            "(group set to 0). Drops are regenerated automatically."))

        del_sp_form = QFormLayout()
        combo_del_sp = QComboBox()
        combo_del_sp.setMinimumWidth(300)
        combo_del_sp.addItem("— Select splitter to delete —")
        for _sd in splitter_data:
            combo_del_sp.addItem(
                f"Splitter {_sd['group_id']}  |  PON {_sd['zone_id']}  |  {_sd['drop_count']} drops")
            # Ticket #64: stash the exact FID so deletion targets THIS splitter
            # regardless of combo index/text quirks.
            combo_del_sp.setItemData(combo_del_sp.count() - 1, _sd['fid'])
        # Ticket #61: type-to-search + scrollable popup for the splitter list.
        self._make_combo_searchable(combo_del_sp)
        del_sp_form.addRow("Splitter:", combo_del_sp)

        from qgis.PyQt.QtWidgets import QCheckBox as _QCB
        chk_renumber = _QCB("Renumber all remaining splitters sequentially after deletion")
        # Ticket #80: default OFF. Renumbering remaps group_ids across all remaining
        # splitters; if the cascade to demand points half-applies (e.g. a stale fid),
        # demand↔splitter desyncs and drops snap to wrong/far splitters. Luke wants a
        # delete to NOT massively re-route — so renumbering is now opt-in.
        chk_renumber.setChecked(False)
        chk_renumber.setToolTip(
            "When checked, group IDs of all remaining splitters (and their demand points) "
            "are renumbered 1, 2, 3… to fill the gap left by the deleted splitter.")
        del_sp_form.addRow("", chk_renumber)
        del_sp_vbox.addLayout(del_sp_form)

        del_sp_btn_row = QHBoxLayout()
        btn_delete_sp = QPushButton("🗑 Delete Splitter")
        btn_delete_sp.setEnabled(False)
        btn_delete_sp.setStyleSheet(
            "QPushButton:enabled  { background-color: #c0392b; color: white; font-weight: bold; }"
            "QPushButton:disabled { background-color: #cccccc; color: #888; }")
        btn_delete_sp.setToolTip("Permanently delete the selected splitter from the layer.")
        del_sp_btn_row.addWidget(btn_delete_sp)
        # Ticket #99 (Lodewijk): Undo right next to Delete Splitter — his headline
        # case ("quicker to undo than to hunt for where a splitter was incorrectly
        # removed"). Re-adds the splitter, reverses the demand re-home + any
        # renumber, and regenerates drops.
        btn_undo_del_sp = QPushButton("↩ Undo Delete")
        btn_undo_del_sp.setEnabled(False)
        btn_undo_del_sp.setToolTip("Undo the last delete (restores the deleted splitter and its links).")
        del_sp_btn_row.addWidget(btn_undo_del_sp)
        del_sp_btn_row.addStretch()
        del_sp_vbox.addLayout(del_sp_btn_row)
        ns_layout.addWidget(del_sp_box)

        combo_del_sp.currentIndexChanged.connect(
            lambda idx: btn_delete_sp.setEnabled(idx > 0))

        # Auto-populate combo when a splitter is selected on the map
        def _on_splitter_selection_changed():
            # Ticket #65 (recurring crash): this stays connected to the splitter
            # layer's selectionChanged after the dialog closes; selecting a splitter
            # on the map then crashed with "QComboBox has been deleted". Bail out if
            # the dialog's widgets are gone.
            from qgis.PyQt import sip as _sip_sel
            try:
                if _sip_sel.isdeleted(combo_del_sp) or _sip_sel.isdeleted(dlg):
                    return
            except Exception:
                return
            if not splitter_layer:
                return
            _sel = splitter_layer.selectedFeatures()
            # #99 (JJ): always highlight whatever splitter(s) are selected on the map,
            # and drop a single pick straight into the Delete box (no typing) — a map
            # selection is an explicit choice, so it now updates the box even if it
            # already held something.
            try:
                _hl_show(splitter_layer, [f.id() for f in _sel])
            except Exception:
                pass
            if len(_sel) == 1:
                _sel_feat = _sel[0]
                try:
                    _sel_gid = _sel_feat['group_id']
                except Exception:
                    _sel_gid = None
                if _sel_gid is not None:
                    # Find matching index in combo
                    for _i, _sd in enumerate(splitter_data):
                        if _sd['group_id'] == _sel_gid:
                            combo_del_sp.setCurrentIndex(_i + 1)  # +1 for placeholder
                            status_lbl.setText(
                                f"<font color='blue'>Splitter Group {_sel_gid} selected & "
                                f"highlighted — it's in the Delete box; click Delete Splitter.</font>")
                            break
        
        splitter_layer.selectionChanged.connect(_on_splitter_selection_changed)

        def _do_delete_splitter():
            # Ticket #64: resolve the victim by the "Group N" actually SHOWN in the
            # box first (that's what the user picked/typed), then by the item's FID
            # data — NEVER by the bare combo index, which an editable/search combo
            # leaves stale and pointing at a still-valid but WRONG item (that deleted
            # the manually placed/moved splitters). Text wins over a stale index's
            # data precisely because currentData() follows the stale index.
            import re as _re_del
            _victim = None
            _m = _re_del.search(r'Group\s+(\d+)', combo_del_sp.currentText() or '')
            if _m:
                _gid_pick = int(_m.group(1))
                _victim = next(
                    (s for s in splitter_data
                     if int(s['group_id']) == _gid_pick), None)
            if _victim is None:
                _fid_data = combo_del_sp.currentData()
                if _fid_data is not None:
                    _victim = next(
                        (s for s in splitter_data if s['fid'] == _fid_data), None)
            if _victim is None:
                status_lbl.setText(
                    "<font color='red'>Select a valid splitter to delete "
                    "(pick one from the list).</font>")
                return
            _idx = splitter_data.index(_victim)
            _victim_gid = _victim['group_id']
            _victim_fid = _victim['fid']

            # ---- Ticket #99 (Lodewijk, headline case): snapshot BEFORE the delete +
            # its cascade so the whole thing is undoable. Capture an independent copy
            # of the splitter feature (re-added on undo) + its splitter_data dict +
            # original index. The re-home (#80) and renumber (#71) inverses are recorded
            # into attr_ops/mem_ops as those steps run; a post closure re-adds the
            # splitter (new fid), re-inserts it into splitter_data, rebuilds the
            # lists/combos and regenerates drops.
            # claude:intent MUTATE — user asked: "check what lodewijk asked for and test
            # it" (#99). Plan: record inverse-state for undo; the delete below is the
            # handler's pre-existing operator delete, unchanged.
            _snap99sp = {
                'desc': f"Delete splitter Group {_victim_gid}",
                'attr_ops': [], 'geom_ops': [], 'del_feats': [], 'add_zone_ids': [],
                'pon_lyr': None, 'mem_ops': [], 'list_ops': [], 'combo_ops': [],
            }
            _victim_feat99 = QgsFeature(splitter_layer.getFeature(_victim_fid))
            _victim_dict99 = dict(_victim)
            _victim_idx99 = _idx
            # demand_data dicts that belong to the victim NOW (before re-home mutates
            # them in place) — post restores their group_id authoritatively, last.
            _victim_dem_dicts99 = [_de for _de in demand_data
                                   if str(_de.get('group_id')) == str(_victim_gid)]
            _rehomed_fids99 = set()   # victim's demand fids on the layer (set in re-home)
            _dp_grp_idx99 = -1        # demand group-link field index (set in re-home)

            # --- 1. Delete feature from splitter layer ----------------------
            # claude:approved-destructive — handler's existing operator-initiated
            # splitter delete, now made undoable.
            splitter_layer.startEditing()
            if not splitter_layer.deleteFeature(_victim_fid):
                splitter_layer.rollBack()
                status_lbl.setText(
                    f"<font color='red'>Failed to delete splitter FID {_victim_fid}.</font>")
                return
            _safe_commit(splitter_layer)

            # Remove from in-memory list
            splitter_data.pop(_idx)

            # --- 2. Re-home the deleted splitter's demand points (ticket #80) -----
            # Luke: deleting a splitter must NOT massively re-route the network. Each
            # demand point that belonged to it is re-snapped to the NEAREST REMAINING
            # splitter, but ONLY if that splitter is within 40 m of the demand point;
            # otherwise the point is unlinked (group 0) so its drop simply falls off
            # rather than snapping to a far, nonsensical splitter across the map.
            _RESNAP_M = 40.0
            _upd80 = {}  # fid -> {idx: new_group}; stays empty if no demand layer/field
            if _dem_layer and _dp_link:
                _dp_grp_idx = _dem_layer.fields().indexFromName(_dp_link)
                if _dp_grp_idx >= 0:
                    _resnap_units = _m_to_units(_RESNAP_M, _dem_layer)
                    # MO audit: read LIVE splitter positions from the layer (the deleted
                    # one is already gone) — not splitter_data's x/y, which goes stale
                    # after a same-session move, so a move-then-delete re-snapped to the
                    # old coordinate.
                    _remaining = []
                    for _sf in splitter_layer.getFeatures():
                        _sgg = _sf.geometry()
                        if not _sgg or _sgg.isEmpty():
                            continue
                        try:
                            _rg = int(_sf['group_id'])
                        except (TypeError, ValueError):
                            continue
                        _rp = _sgg.centroid().asPoint()
                        _remaining.append((_rg, _rp.x(), _rp.y()))
                    _upd80 = {}
                    _re_n, _orphan_n = 0, 0
                    for _df in _dem_layer.getFeatures():
                        try:
                            if int(_df[_dp_link]) != int(_victim_gid):
                                continue
                        except (TypeError, ValueError):
                            continue
                        _g = _df.geometry()
                        if not _g or _g.isEmpty():
                            continue
                        _c = _g.centroid().asPoint()
                        _best_g, _best_d = None, float('inf')
                        for _sg, _sx, _sy in _remaining:
                            _d = ((_c.x() - _sx) ** 2 + (_c.y() - _sy) ** 2) ** 0.5
                            if _d < _best_d:
                                _best_d, _best_g = _d, _sg
                        if _best_g is not None and _best_d <= _resnap_units:
                            _upd80[_df.id()] = {_dp_grp_idx: int(_best_g)}
                            _re_n += 1
                        else:
                            _upd80[_df.id()] = {_dp_grp_idx: 0}
                            _orphan_n += 1
                    if _upd80:
                        # #99: every re-homed point belonged to the victim group — record
                        # the inverse so undo puts them back. claude:intent MUTATE — user
                        # asked: "check what lodewijk asked for and test it" (#99);
                        # claude:approved-destructive — existing #80 re-home write.
                        for _fid80 in _upd80:
                            _snap99sp['attr_ops'].append(
                                (_dem_layer, _fid80, _dp_grp_idx, int(_victim_gid)))
                        # claude:intent MUTATE — user asked: "check what lodewijk asked
                        # for and test it" (#99); existing #80 re-home write, unchanged.
                        _dem_layer.dataProvider().changeAttributeValues(_upd80)
                        _dem_layer.triggerRepaint()
                    # #99: remember the victim's demand fids + field index so post can
                    # authoritatively put them back on the victim group (last word).
                    _rehomed_fids99 = set(_upd80)
                    _dp_grp_idx99 = _dp_grp_idx
                    self.log_message(
                        f"  ✦ Deleted splitter Group {_victim_gid}: {_re_n} demand point(s) "
                        f"re-snapped to nearest splitter (≤{_RESNAP_M:.0f} m), {_orphan_n} unlinked.")
                # In-memory demand_data: MIRROR the actual re-snap (fid → new group) so a
                # subsequent same-session edit acts on the correct group, not a stale 0.
                # MO audit: previously this blanket-zeroed the victim group, desyncing
                # demand_data from the layer (a later incremental regen then missed the
                # re-snapped group).
                _fid2grp = {fid: next(iter(ops.values())) for fid, ops in _upd80.items()}
                for _de in demand_data:
                    # #99: capture the in-memory group_id before it changes so undo restores it.
                    if _de.get('fid') in _fid2grp or _de.get('group_id') == _victim_gid:
                        _snap99sp['mem_ops'].append((_de, 'group_id', _de.get('group_id')))
                    if _de.get('fid') in _fid2grp:
                        _de['group_id'] = _fid2grp[_de['fid']]
                    elif _de['group_id'] == _victim_gid:
                        _de['group_id'] = 0

            # --- 3. Optional renumber ----------------------------------------
            _old_to_new = {}   # old group_id → new group_id
            if chk_renumber.isChecked() and splitter_data:
                # Sort by current group_id so order is preserved
                splitter_data.sort(key=lambda s: s['group_id'])
                _sp_fnames = [f.name() for f in splitter_layer.fields()]
                splitter_layer.startEditing()
                for _new_num, _sd in enumerate(splitter_data, start=1):
                    _old_gid = _sd['group_id']
                    if _old_gid == _new_num:
                        continue  # no change needed
                    # Ticket #80: skip a stale fid (was throwing "Feature N for attribute
                    # update not found" and leaving the renumber half-applied → desync).
                    if not splitter_layer.getFeature(_sd['fid']).isValid():
                        continue
                    _old_to_new[_old_gid] = _new_num
                    # #99: record the real pre-renumber attribute values so undo can put
                    # every splitter's group_id/ID/fid attr back. claude:intent MUTATE —
                    # user asked: "check what lodewijk asked for and test it" (#99);
                    # claude:approved-destructive — existing #71 renumber write.
                    _sf_now99 = splitter_layer.getFeature(_sd['fid'])
                    if 'fid'      in _sp_fnames:
                        _snap99sp['attr_ops'].append(
                            (splitter_layer, _sd['fid'], _sp_fnames.index('fid'), _sf_now99['fid']))
                        splitter_layer.changeAttributeValue(
                            _sd['fid'], _sp_fnames.index('fid'), _new_num)
                    if 'ID'       in _sp_fnames:
                        _snap99sp['attr_ops'].append(
                            (splitter_layer, _sd['fid'], _sp_fnames.index('ID'), _sf_now99['ID']))
                        splitter_layer.changeAttributeValue(
                            _sd['fid'], _sp_fnames.index('ID'), str(_new_num))
                    if 'group_id' in _sp_fnames:
                        _snap99sp['attr_ops'].append(
                            (splitter_layer, _sd['fid'], _sp_fnames.index('group_id'), _sf_now99['group_id']))
                        splitter_layer.changeAttributeValue(
                            _sd['fid'], _sp_fnames.index('group_id'), _new_num)
                    _snap99sp['mem_ops'].append((_sd, 'group_id', _old_gid))
                    _sd['group_id'] = _new_num
                _safe_commit(splitter_layer)

                # Cascade renumber to demand points — Ticket #71: update EVERY
                # grouped demand layer in the project (not just the one resolved for
                # this dialog), so a demand point can never keep a stale group that
                # now points at a different splitter. Splitter layers carry group_id
                # and were already renumbered above; keying on the DEMAND group fields
                # (group_8/16/128/100) automatically skips them. Bulk-write per layer.
                if _old_to_new:
                    # Detect the demand group-link field on EACH layer by pattern instead
                    # of a fixed list, so any 'group_<N>' size (group_8/16/64/128/100/…) or
                    # 'batch_id' cascades — a hardcoded list silently skipped a layer whose
                    # field it didn't name, leaving those points on their old group so the
                    # drop regen reconnected them to the WRONG renumbered splitter (#75).
                    # 'group_id' is intentionally NOT matched (that's the splitter's field).
                    import re as _re_g

                    def _dem_grp_field(field_names):
                        return next((n for n in field_names
                                     if _re_g.fullmatch(r'group_\d+', n) or n == 'batch_id'), None)
                    _cascaded = 0
                    for _lyr in QgsProject.instance().mapLayers().values():
                        if not isinstance(_lyr, QgsVectorLayer) or _lyr.geometryType() != 0:
                            continue
                        _lfn = [f.name() for f in _lyr.fields()]
                        _lf = _dem_grp_field(_lfn)
                        if _lf is None:
                            continue
                        _li = _lyr.fields().indexFromName(_lf)
                        _upd = {}
                        for _df in _lyr.getFeatures():
                            try:
                                _og = int(_df[_lf])
                            except (TypeError, ValueError):
                                continue
                            if _og in _old_to_new:
                                _upd[_df.id()] = {_li: _old_to_new[_og]}
                                # #99: inverse — put this point's group field back to _og.
                                _snap99sp['attr_ops'].append((_lyr, _df.id(), _li, _og))
                        if _upd:
                            # claude:intent MUTATE — user asked: "check what lodewijk asked
                            # for and test it" (#99); recording inverse for undo. The write
                            # below is the handler's pre-existing #71 cascade, unchanged.
                            # claude:approved-destructive — renumbers demand-point group
                            # values to match the renumbered splitters; never poles/cables.
                            _lyr.dataProvider().changeAttributeValues(_upd)
                            _lyr.triggerRepaint()
                            _cascaded += len(_upd)
                    self.log_message(
                        f"  ✦ Renumber cascaded to {_cascaded} demand point(s) across "
                        f"all grouped layers (ticket #71)")
                    # Update in-memory demand_data
                    for _de in demand_data:
                        if _de['group_id'] in _old_to_new:
                            # #99: capture old group_id before renumber so undo restores it.
                            _snap99sp['mem_ops'].append((_de, 'group_id', _de['group_id']))
                            _de['group_id'] = _old_to_new[_de['group_id']]

            # Refresh accumulator renderer after delete/renumber
            _accum_sp_d = getattr(self, '_pon_accum_splitters', None)
            try:
                from qgis.PyQt import sip as _sip4
                if _accum_sp_d and not _sip4.isdeleted(_accum_sp_d) and splitter_layer is _accum_sp_d:
                    self._pon_refresh_accum_renderers()
                else:
                    splitter_layer.triggerRepaint()
                    if _dem_layer:
                        _dem_layer.triggerRepaint()
            except Exception:
                splitter_layer.triggerRepaint()
                if _dem_layer:
                    _dem_layer.triggerRepaint()

            # --- 4. Rebuild UI lists / combos ---------------------------------
            # list_widget (Tab 0)
            list_widget.clear()
            for _sd in splitter_data:
                list_widget.addItem("")
            # Apply the #98 groups-per-zone column + >16 highlight to the rebuilt rows.
            _render_splitter_list()

            # combo_target (Demand Points tab)
            if combo_target:
                combo_target.clear()
                for _sd in splitter_data:
                    combo_target.addItem(
                        f"Splitter {_sd['group_id']}  |  PON {_sd['zone_id']}  |  {_sd['drop_count']} drops")

            # combo_add_dp_grp (Add New Demand Point)
            if combo_add_dp_grp:
                combo_add_dp_grp.clear()
                combo_add_dp_grp.addItem("— Select splitter —")
                for _sd in splitter_data:
                    combo_add_dp_grp.addItem(
                        f"Splitter {_sd['group_id']}  |  PON {_sd['zone_id']}  |  {_sd['drop_count']} drops")

            # dem_list (Demand Points tab)
            if dem_list:
                dem_list.clear()
                for _de in demand_data:
                    dem_list.addItem(
                        f"DP {_de['fid']}   |   Splitter {_de['group_id']}   |   PON {_de['zone_id']}")

            # Rebuild this combo too
            combo_del_sp.blockSignals(True)
            combo_del_sp.clear()
            combo_del_sp.addItem("— Select splitter to delete —")
            for _sd in splitter_data:
                combo_del_sp.addItem(
                    f"Splitter {_sd['group_id']}  |  PON {_sd['zone_id']}  |  {_sd['drop_count']} drops")
                combo_del_sp.setItemData(combo_del_sp.count() - 1, _sd['fid'])
            combo_del_sp.setCurrentIndex(0)
            if combo_del_sp.lineEdit() is not None:
                combo_del_sp.lineEdit().clear()
            combo_del_sp.blockSignals(False)
            btn_delete_sp.setEnabled(False)

            _rn_msg = " All splitters renumbered." if chk_renumber.isChecked() and _old_to_new else ""
            status_lbl.setText(
                f"<font color='green'><b>✓ Splitter Group {_victim_gid} deleted.</b>"
                f"{_rn_msg} Regenerating drops…</font>")
            _regen_drops()
            status_lbl.setText(
                f"<font color='green'>Splitter Group {_victim_gid} deleted and drops regenerated.</font>")

            # ---- Ticket #99: register the undo for this splitter delete ----
            # claude:intent MUTATE — user asked: "check what lodewijk asked for and test
            # it" (#99, headline case). Plan: undo re-adds the deleted splitter, puts its
            # demand points back on it, and (with undo_last's attr/mem ops) reverses the
            # re-home + renumber — restoring exactly what the operator had. An explicit
            # user-driven restore. claude:approved-destructive — re-adds the captured
            # splitter + re-points its own demand points only.
            def _undo_del_sp(_snap, _vfeat=_victim_feat99, _vdict=_victim_dict99,
                             _vidx=_victim_idx99, _vgid=_victim_gid,
                             _vdem=_victim_dem_dicts99, _rfids=_rehomed_fids99,
                             _gidx=_dp_grp_idx99):
                """Restore a deleted splitter + its links (runs after undo_last's attr/mem
                ops have reversed the re-home + renumber on the OTHER features)."""
                # 1. Re-add the splitter feature; the provider assigns a fresh fid.
                _okr, _added = splitter_layer.dataProvider().addFeatures([QgsFeature(_vfeat)])
                splitter_layer.updateExtents()
                _new_fid = _added[0].id() if _added else _vdict.get('fid')
                _rdict = dict(_vdict)
                _rdict['fid'] = _new_fid
                splitter_data.insert(min(_vidx, len(splitter_data)), _rdict)
                splitter_data.sort(key=lambda s: s['group_id'])
                # 2. Authoritatively put the victim's demand points back on its group
                #    (last word — overrides any renumber-inverse that touched them).
                if _rfids and _dem_layer is not None and _gidx is not None and _gidx >= 0:
                    _restore = {fid: {_gidx: int(_vgid)} for fid in _rfids}
                    if _restore:
                        _dem_layer.dataProvider().changeAttributeValues(_restore)
                    _dem_layer.triggerRepaint()
                for _de in _vdem:
                    _de['group_id'] = _vgid
                splitter_layer.triggerRepaint()
                # 3. Rebuild lists/combos so the restored splitter reappears (the
                #    refreshers only update existing rows, they don't add one).
                list_widget.clear()
                for _sd in splitter_data:
                    list_widget.addItem("")
                _render_splitter_list()
                if combo_target:
                    combo_target.clear()
                    for _sd in splitter_data:
                        combo_target.addItem(
                            f"Splitter {_sd['group_id']}  |  PON {_sd['zone_id']}  |  {_sd['drop_count']} drops")
                if combo_add_dp_grp:
                    combo_add_dp_grp.clear()
                    combo_add_dp_grp.addItem("— Select splitter —")
                    for _sd in splitter_data:
                        combo_add_dp_grp.addItem(
                            f"Splitter {_sd['group_id']}  |  PON {_sd['zone_id']}  |  {_sd['drop_count']} drops")
                if dem_list:
                    dem_list.clear()
                    for _de in demand_data:
                        dem_list.addItem(
                            f"DP {_de['fid']}   |   Splitter {_de['group_id']}   |   PON {_de['zone_id']}")
                combo_del_sp.blockSignals(True)
                combo_del_sp.clear()
                combo_del_sp.addItem("— Select splitter to delete —")
                for _sd in splitter_data:
                    combo_del_sp.addItem(
                        f"Splitter {_sd['group_id']}  |  PON {_sd['zone_id']}  |  {_sd['drop_count']} drops")
                    combo_del_sp.setItemData(combo_del_sp.count() - 1, _sd['fid'])
                combo_del_sp.setCurrentIndex(0)
                combo_del_sp.blockSignals(False)
                # 4. Regenerate drops for the restored network.
                _regen_drops()
            _snap99sp['post'] = _undo_del_sp
            if len(_undo_stack) >= 10:
                _undo_stack.pop(0)
            _undo_stack.append(_snap99sp)
            _enable_undo()

        btn_delete_sp.clicked.connect(_do_delete_splitter)

        tab_widget.addTab(tab_ns, "Splitters")

        # ----------------------------------------------------------------
        # Polygon-select map tool — used on the Demand Points tab
        # ----------------------------------------------------------------
        from qgis.gui import QgsMapTool as _QMTBase
        from qgis.core import QgsWkbTypes as _WKB
        from qgis.PyQt.QtCore import Qt as _Qt3

        class _PolySelectDemandTool(_QMTBase):
            """Left-click to add polygon vertices; right-click to close and select
            all demand points that fall inside the drawn polygon."""

            def __init__(self, canvas, demand_data, dem_list, status_lbl, layer_crs):
                super().__init__(canvas)
                self._demand_data = demand_data
                self._dem_list    = dem_list
                self._status      = status_lbl
                self._layer_crs   = layer_crs
                self._vertices    = []   # confirmed vertices in layer CRS
                from qgis.gui import QgsRubberBand
                from qgis.PyQt.QtGui import QColor
                self._rb = QgsRubberBand(canvas, _WKB.PolygonGeometry)
                self._rb.setColor(QColor(0, 120, 215, 200))
                self._rb.setFillColor(QColor(0, 120, 215, 40))
                self._rb.setWidth(2)

            def canvasPressEvent(self, e):
                if _dlg_closed[0]:
                    return  # ticket #65: dialog gone — don't touch deleted widgets
                from qgis.core import QgsCoordinateTransform, QgsProject
                if e.button() == _Qt3.MouseButton.LeftButton:
                    canvas_pt = self.toMapCoordinates(e.pos())
                    xform = QgsCoordinateTransform(
                        QgsProject.instance().crs(), self._layer_crs, QgsProject.instance())
                    try:
                        layer_pt = xform.transform(canvas_pt)
                    except Exception:
                        layer_pt = canvas_pt
                    self._vertices.append(layer_pt)
                    if len(self._vertices) == 1:
                        # First vertex: add a confirmed point + a live "preview" duplicate
                        self._rb.addPoint(canvas_pt)
                        self._rb.addPoint(canvas_pt)
                    else:
                        # Confirm the live point, then start a new live point at same position
                        self._rb.movePoint(canvas_pt)
                        self._rb.addPoint(canvas_pt)
                    n = len(self._vertices)
                    self._status.setText(
                        f"<font color='blue'>Polygon: {n} vertex/vertices — "
                        f"left-click to add more, right-click to finish.</font>")
                elif e.button() == _Qt3.MouseButton.RightButton:
                    self._finish_selection()

            def canvasMoveEvent(self, e):
                if _dlg_closed[0] or not self._vertices:
                    return
                # Move the live "preview" point to track the cursor
                self._rb.movePoint(self.toMapCoordinates(e.pos()))

            def _finish_selection(self):
                from qgis.core import QgsGeometry, QgsPointXY
                if len(self._vertices) < 3:
                    self._status.setText(
                        "<font color='red'>Need at least 3 vertices to close the polygon. "
                        "Keep left-clicking to add more points.</font>")
                    return
                poly = QgsGeometry.fromPolygonXY([self._vertices + [self._vertices[0]]])
                matched = []
                for i, dd in enumerate(self._demand_data):
                    pt_geom = QgsGeometry.fromPointXY(QgsPointXY(dd['x'], dd['y']))
                    if poly.contains(pt_geom):
                        matched.append(i)
                for i in matched:
                    self._dem_list.item(i).setSelected(True)
                n_sel = len(self._dem_list.selectedItems())
                self._status.setText(
                    f"<font color='green'><b>{len(matched)} demand point(s) added to selection</b> "
                    f"({n_sel} total selected). "
                    f"Draw another polygon or click Apply to reassign.</font>")
                self._reset()

            def _reset(self):
                self._vertices.clear()
                self._rb.reset(_WKB.PolygonGeometry)

            def deactivate(self):
                self._reset()
                super().deactivate()

        class _PolySelectSplitterTool(_QMTBase):
            """Ticket #99 (JJ): select splitters like demand points. Left-click adds
            polygon vertices, right-click finishes: >=3 vertices selects every splitter
            inside the polygon; a single left-click then right-click picks the nearest
            splitter. Selection drives the list_widget, which highlights the splitters
            gold and drops a single pick into the Delete Splitter box."""

            def __init__(self, canvas, layer_crs):
                super().__init__(canvas)
                self._layer_crs = layer_crs
                self._vertices = []
                from qgis.gui import QgsRubberBand
                from qgis.PyQt.QtGui import QColor
                self._rb = QgsRubberBand(canvas, _WKB.PolygonGeometry)
                self._rb.setColor(QColor(255, 196, 0, 220))
                self._rb.setFillColor(QColor(255, 196, 0, 50))
                self._rb.setWidth(2)

            def canvasPressEvent(self, e):
                if _dlg_closed[0]:
                    return
                from qgis.core import QgsCoordinateTransform, QgsProject
                if e.button() == _Qt3.MouseButton.LeftButton:
                    canvas_pt = self.toMapCoordinates(e.pos())
                    xform = QgsCoordinateTransform(
                        QgsProject.instance().crs(), self._layer_crs, QgsProject.instance())
                    try:
                        layer_pt = xform.transform(canvas_pt)
                    except Exception:
                        layer_pt = canvas_pt
                    self._vertices.append(layer_pt)
                    if len(self._vertices) == 1:
                        self._rb.addPoint(canvas_pt)
                        self._rb.addPoint(canvas_pt)
                    else:
                        self._rb.movePoint(canvas_pt)
                        self._rb.addPoint(canvas_pt)
                    status_lbl.setText(
                        f"<font color='blue'>Splitter select: {len(self._vertices)} point(s) — "
                        f"left-click to build a polygon, right-click to finish "
                        f"(1 point = nearest splitter).</font>")
                elif e.button() == _Qt3.MouseButton.RightButton:
                    self._finish()

            def canvasMoveEvent(self, e):
                if _dlg_closed[0] or not self._vertices:
                    return
                self._rb.movePoint(self.toMapCoordinates(e.pos()))

            def _finish(self):
                from qgis.core import QgsGeometry, QgsPointXY
                if not self._vertices:
                    return
                _matched = []
                if len(self._vertices) >= 3:
                    _poly = QgsGeometry.fromPolygonXY([self._vertices + [self._vertices[0]]])
                    for _i, _sd in enumerate(splitter_data):
                        if _poly.contains(QgsGeometry.fromPointXY(QgsPointXY(_sd['x'], _sd['y']))):
                            _matched.append(_i)
                else:
                    _lp = self._vertices[-1]
                    _best_i, _best_d = None, float('inf')
                    for _i, _sd in enumerate(splitter_data):
                        _d = (_sd['x'] - _lp.x()) ** 2 + (_sd['y'] - _lp.y()) ** 2
                        if _d < _best_d:
                            _best_d, _best_i = _d, _i
                    if _best_i is not None:
                        _matched.append(_best_i)
                # Drive the list selection once → triggers the gold highlight + Delete-box fill.
                list_widget.blockSignals(True)
                list_widget.clearSelection()
                for _i in _matched:
                    if _i < list_widget.count():
                        list_widget.item(_i).setSelected(True)
                list_widget.blockSignals(False)
                _hl_on_splitter_sel()
                if not _matched:
                    status_lbl.setText("<font color='orange'>No splitter inside the polygon.</font>")
                self._reset()

            def _reset(self):
                self._vertices.clear()
                self._rb.reset(_WKB.PolygonGeometry)

            def deactivate(self):
                self._reset()
                super().deactivate()

        # ----------------------------------------------------------------
        # Shared status + close
        # ----------------------------------------------------------------
        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setFrameShadow(QFrame.Shadow.Sunken)
        layout.addWidget(sep)

        status_lbl = QLabel("Switch tabs to work with splitters or demand points.")
        status_lbl.setWordWrap(True)
        # Ticket #99 (JJ): the status line was dark blue/green/purple text on the dark
        # theme background — unreadable. Give it a fixed light "console" panel so every
        # coloured message (the <font color=…> ones below) reads with strong contrast
        # no matter the QGIS theme, and pad it so it's easy to spot.
        status_lbl.setTextFormat(Qt.TextFormat.RichText)
        status_lbl.setStyleSheet(
            "QLabel { background:#f6f7f9; color:#15233b; border:1px solid #9aa4b2; "
            "border-radius:5px; padding:7px 9px; font-size:12px; }")
        status_lbl.setMinimumHeight(34)
        layout.addWidget(status_lbl)

        btn_close = QPushButton("Close")
        layout.addWidget(btn_close)

        # ================================================================
        # Undo stack
        # ================================================================
        _undo_stack = []   # max 10 entries; each is a snapshot dict

        def _enable_undo():
            btn_undo_sp.setEnabled(True)
            if btn_undo_dp:
                btn_undo_dp.setEnabled(True)
            # Ticket #99: keep the delete-adjacent Undo buttons in lock-step.
            if btn_undo_del_dp:
                btn_undo_del_dp.setEnabled(True)
            if btn_undo_del_sp:
                btn_undo_del_sp.setEnabled(True)

        def _disable_undo():
            btn_undo_sp.setEnabled(False)
            if btn_undo_dp:
                btn_undo_dp.setEnabled(False)
            if btn_undo_del_dp:
                btn_undo_del_dp.setEnabled(False)
            if btn_undo_del_sp:
                btn_undo_del_sp.setEnabled(False)

        def undo_last():
            if not _undo_stack:
                return
            snap = _undo_stack.pop()

            # 1. Restore attributes — group ops by layer to batch editing sessions
            _by_lyr = {}
            for (lyr, fid, fidx, oval) in snap.get('attr_ops', []):
                _lid = id(lyr)
                if _lid not in _by_lyr:
                    _by_lyr[_lid] = (lyr, [])
                _by_lyr[_lid][1].append((fid, fidx, oval))
            for _lid, (lyr, ops) in _by_lyr.items():
                # bulk write via the data provider — never per-feature
                # changeAttributeValue() inside startEditing() (main-thread
                # freeze on large demand layers)
                _inv_map = {}
                for fid, fidx, oval in ops:
                    _inv_map.setdefault(fid, {})[fidx] = oval
                if _inv_map:
                    lyr.dataProvider().changeAttributeValues(_inv_map)
                lyr.triggerRepaint()

            # 2. Restore geometries
            _by_lyr_g = {}
            for (lyr, fid, ogeom) in snap.get('geom_ops', []):
                _lid = id(lyr)
                if _lid not in _by_lyr_g:
                    _by_lyr_g[_lid] = (lyr, [])
                _by_lyr_g[_lid][1].append((fid, ogeom))
            for _lid, (lyr, ops) in _by_lyr_g.items():
                lyr.startEditing()
                for fid, ogeom in ops:
                    lyr.changeGeometry(fid, ogeom)
                _safe_commit(lyr)
                lyr.triggerRepaint()

            # 3. Re-add features that were deleted by apply (e.g. empty PON zone polygons)
            for (lyr, feats) in snap.get('del_feats', []):
                lyr.startEditing()
                lyr.addFeatures(feats)
                _safe_commit(lyr)
                lyr.triggerRepaint()

            # 4. Delete PON zone polygons that were newly created by apply
            _pon_lyr = snap.get('pon_lyr')
            for _nzid in snap.get('add_zone_ids', []):
                if _pon_lyr:
                    _fids_del = [_f.id() for _f in _pon_lyr.getFeatures()
                                 if _f['zone_id'] == _nzid]
                    if _fids_del:
                        _pon_lyr.startEditing()
                        _pon_lyr.deleteFeatures(_fids_del)
                        _safe_commit(_pon_lyr)
                        _pon_lyr.triggerRepaint()

            # 5. Restore in-memory data dicts
            for (d, key, oval) in snap.get('mem_ops', []):
                d[key] = oval

            # 6. Restore list widget labels
            for (lw, idx, otxt) in snap.get('list_ops', []):
                # the list may have been rebuilt/shrunk since the snapshot —
                # item(idx) returns None for an out-of-range row
                _it = lw.item(idx)
                if _it is not None:
                    _it.setText(otxt)

            # 7. Restore combo labels
            for (cb, idx, otxt) in snap.get('combo_ops', []):
                cb.setItemText(idx, otxt)

            # 8. Ticket #99 (Lodewijk): delete-undo restore. A delete (demand point
            # or splitter) removes features and cascades (re-home / renumber / regen),
            # which the data-driven ops above cannot fully reverse — re-added features
            # come back with NEW fids and the UI lists/combos were rebuilt. The delete
            # handler captures a closure that re-adds the features, remaps the in-memory
            # data to the new fids, rebuilds the lists/combos and regenerates drops.
            _post = snap.get('post')
            if callable(_post):
                try:
                    _post(snap)
                except Exception as _pe:
                    self.log_message(f"Undo post-restore error: {_pe}")

            # Re-render from the restored splitter_data so the #98 groups-per-zone
            # column + >16 highlight (and every count) are guaranteed consistent
            # after an undo, not left styled from the pre-undo state.
            _sync_count_labels()

            if not _undo_stack:
                _disable_undo()

            status_lbl.setText(
                f"<font color='orange'><b>Undone:</b> {snap['desc']}</font>")
            self.log_message(f"Undo: {snap['desc']}")

        # ================================================================
        # Splitter tab helpers
        # ================================================================
        def refresh_summary():
            sel_rows = [list_widget.row(it) for it in list_widget.selectedItems()]
            if not sel_rows:
                lbl_sel_count.setText("0")
                lbl_sel_zones.setText("—")
                lbl_sel_drops.setText("0")
                return
            zones = sorted({splitter_data[i]['zone_id'] for i in sel_rows})
            total_drops = sum(splitter_data[i]['drop_count'] for i in sel_rows)
            lbl_sel_count.setText(str(len(sel_rows)))
            lbl_sel_zones.setText(", ".join(str(z) for z in zones))
            lbl_sel_drops.setText(str(total_drops))
            if len(zones) == 1:
                spin.setValue(zones[0])

        list_widget.itemSelectionChanged.connect(refresh_summary)
        btn_select_all.clicked.connect(list_widget.selectAll)
        btn_clear_sel.clicked.connect(list_widget.clearSelection)

        def _zoom_to_selected_splitters():
            sel_rows = [list_widget.row(it) for it in list_widget.selectedItems()]
            if not sel_rows:
                return
            sel_fids = [splitter_data[i]['fid'] for i in sel_rows]
            from qgis.core import QgsRectangle, QgsCoordinateTransform, QgsProject, QgsPointXY
            canvas = self.iface.mapCanvas()
            canvas_crs = canvas.mapSettings().destinationCrs()
            layer_crs = splitter_layer.crs()
            xform = QgsCoordinateTransform(layer_crs, canvas_crs, QgsProject.instance())

            # Collect splitter points + their group_ids
            sel_group_ids = []
            pts = []
            for feat in splitter_layer.getFeatures():
                if feat.id() not in sel_fids:
                    continue
                g = feat.geometry()
                if g and not g.isEmpty():
                    g_clone = QgsGeometry(g)
                    g_clone.transform(xform)
                    pts.append(g_clone.centroid().asPoint())
                gid = feat['group_id']
                if gid is not None:
                    sel_group_ids.append(int(gid))

            if not pts:
                return

            # Highlight splitter points
            splitter_layer.selectByIds(sel_fids)

            # Highlight matching drop cables in any drop layer
            for lyr in QgsProject.instance().mapLayers().values():
                from qgis.core import QgsVectorLayer
                if not isinstance(lyr, QgsVectorLayer):
                    continue
                lname = lyr.name().lower()
                if 'drop cable' not in lname and 'drop_cable' not in lname:
                    continue
                if 'group_id' not in [f.name() for f in lyr.fields()]:
                    continue
                drop_fids = [
                    f.id() for f in lyr.getFeatures()
                    if f['group_id'] is not None and int(f['group_id']) in sel_group_ids
                ]
                lyr.selectByIds(drop_fids)

            # Zoom to centroid of all selected points at a fixed 1:1000 scale
            cx = sum(p.x() for p in pts) / len(pts)
            cy = sum(p.y() for p in pts) / len(pts)
            canvas.zoomByFactor(1.0)  # no-op, just ensures renderer is ready
            # If multiple splitters span a wide area, fit them all; otherwise use 1:1000
            bbox = QgsRectangle(pts[0].x(), pts[0].y(), pts[0].x(), pts[0].y())
            for p in pts[1:]:
                bbox.combineExtentWith(QgsRectangle(p.x(), p.y(), p.x(), p.y()))
            span = max(bbox.width(), bbox.height())
            if span > 0:
                # Multiple spread-out points — fit with 30% margin
                bbox.grow(span * 0.3)
                canvas.setExtent(bbox)
            else:
                # Single point (or all same location) — centre and set 1:1000 scale
                canvas.setCenter(QgsPointXY(cx, cy))
                canvas.zoomScale(1000)
            canvas.refresh()

        btn_zoom_sel.clicked.connect(_zoom_to_selected_splitters)

        # ================================================================
        # Demand tab helpers
        # ================================================================
        if demand_data and dem_list:
            def refresh_dp_summary():
                sel_rows = [dem_list.row(it) for it in dem_list.selectedItems()]
                if not sel_rows:
                    lbl_dp_count.setText("0")
                    lbl_dp_groups.setText("—")
                    return
                groups = sorted({demand_data[i]['group_id'] for i in sel_rows})
                lbl_dp_count.setText(str(len(sel_rows)))
                lbl_dp_groups.setText(", ".join(str(g) for g in groups))

            dem_list.itemSelectionChanged.connect(refresh_dp_summary)
            btn_dp_select_all.clicked.connect(dem_list.selectAll)
            btn_dp_clear_sel.clicked.connect(dem_list.clearSelection)

        # ---- Apply change (batch over all selected splitters) ----
        def apply_change():
            sel_rows = [list_widget.row(it) for it in list_widget.selectedItems()]
            if not sel_rows:
                status_lbl.setText("No splitters selected.")
                return

            new_zone  = spin.value()
            to_change = [splitter_data[i] for i in sel_rows
                         if splitter_data[i]['zone_id'] != new_zone]
            if not to_change:
                status_lbl.setText("No change — all selected splitters are already in that zone.")
                return

            # Net drops leaving each old zone (may span multiple old zones)
            old_zones_delta = {}   # {old_zone_id: total drops moving out}
            for sd in to_change:
                oz = sd['zone_id']
                old_zones_delta[oz] = old_zones_delta.get(oz, 0) + sd['drop_count']
            new_zone_gain = sum(sd['drop_count'] for sd in to_change)
            changing_groups = {sd['group_id'] for sd in to_change}
            # MO audit: include string forms so membership matches whether the demand/
            # drop layer stores the group field as int or as text (shapefiles/user-picked
            # Final layers are often String) — otherwise the cascade silently no-ops.
            changing_groups |= {str(g) for g in list(changing_groups)}

            # ---- Snapshot for undo ----
            _snap = {
                'desc':         f"{len(to_change)} splitter(s) → Zone {new_zone}",
                'attr_ops':     [],
                'geom_ops':     [],
                'del_feats':    [],
                'add_zone_ids': [],
                'pon_lyr':      None,
                'mem_ops':      [],
                'list_ops':     [],
                'combo_ops':    [],
            }
            # Batch C: splitter_layer is user/dynamic — without a zone_id field the
            # _sf['zone_id'] read below KeyErrors and changeAttributeValue(fid, -1, …)
            # would write to the wrong column. Abort cleanly instead of crashing/corrupting.
            if 'zone_id' not in [f.name() for f in splitter_layer.fields()]:
                self.log_message("Change Splitter Zone aborted: splitter layer has no 'zone_id' field.")
                return
            # Splitter attributes
            _zi_s = splitter_layer.fields().indexFromName('zone_id')
            for _sf in splitter_layer.getFeatures():
                if _sf['group_id'] in changing_groups:
                    _snap['attr_ops'].append((splitter_layer, _sf.id(), _zi_s, _sf['zone_id']))
            # In-memory splitter_data + list labels
            for sd in to_change:
                _si = splitter_data.index(sd)
                _snap['mem_ops'].append((sd, 'zone_id', sd['zone_id']))
                _snap['list_ops'].append((list_widget, _si, list_widget.item(_si).text()))
            # Limit stack depth
            if len(_undo_stack) >= 10:
                _undo_stack.pop(0)

            results = []
            _link = None   # group link field name on demand / grouped layer

            # 1. Update splitter points — bulk write via the data provider,
            # never per-feature changeAttributeValue() inside startEditing()
            _zi = splitter_layer.fields().indexFromName('zone_id')
            if _zi >= 0:
                _sp_attr_map = {sd['fid']: {_zi: new_zone} for sd in to_change}
                if _sp_attr_map:
                    splitter_layer.dataProvider().changeAttributeValues(_sp_attr_map)
            # Rebuild accumulator renderer if needed, else just repaint
            _accum_sp_z = getattr(self, '_pon_accum_splitters', None)
            try:
                from qgis.PyQt import sip as _sip5
                if _accum_sp_z and not _sip5.isdeleted(_accum_sp_z) and splitter_layer is _accum_sp_z:
                    self._pon_refresh_accum_renderers()
                else:
                    splitter_layer.triggerRepaint()
            except Exception:
                splitter_layer.triggerRepaint()
            results.append(f"Splitter Points — {len(to_change)} splitter(s)")

            # 2. Update demand points
            _dem_layer = None
            _zone_fld = None   # kept in outer scope for step 4
            try:
                if self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                    _dem_layer = self.demand_points_layer
            except Exception:
                pass
            if not _dem_layer:
                for _lyr in QgsProject.instance().mapLayers().values():
                    if isinstance(_lyr, QgsVectorLayer):
                        _ln = _lyr.name().lower()
                        if 'demand points' in _ln or 'demand_points' in _ln:
                            _dem_layer = _lyr
                            break
            if _dem_layer:
                _dfnames = [f.name() for f in _dem_layer.fields()]
                _link = _demand_group_field(_dfnames)  # #79: any group_<N> size
                # MO audit: ONLY 'zone_id' is a real zone field. The old fallback to
                # 'group_100' wrote the zone number into the grouping field, corrupting
                # group assignments on 1:100 designs. If there's no zone_id, skip the
                # demand zone write (zones live on the splitter + PON polygon).
                _zone_fld = 'zone_id' if 'zone_id' in _dfnames else None
                if _link and _zone_fld:
                    _dzi = _dem_layer.fields().indexFromName(_zone_fld)
                    _zni = _dem_layer.fields().indexFromName('zone_name') if 'zone_name' in _dfnames else -1
                    # Snapshot demand points before editing
                    for _f in _dem_layer.getFeatures():
                        if _f[_link] in changing_groups:
                            _snap['attr_ops'].append((_dem_layer, _f.id(), _dzi, _f[_zone_fld]))
                            if _zni >= 0:
                                _snap['attr_ops'].append((_dem_layer, _f.id(), _zni, _f['zone_name']))
                    # bulk write (was per-feature changeAttributeValue inside startEditing
                    # over the whole demand layer → main-thread freeze on large layers)
                    _attr = {}
                    for _f in _dem_layer.getFeatures():
                        if _f[_link] in changing_groups:
                            _ops = {_dzi: new_zone}
                            if _zni >= 0:
                                _ops[_zni] = f"Zone {new_zone}"
                            _attr[_f.id()] = _ops
                    _upd = len(_attr)
                    if _attr:
                        _dem_layer.dataProvider().changeAttributeValues(_attr)
                    _dem_layer.triggerRepaint()
                    results.append(f"Demand Points — {_upd} feature(s)")

            # 2b. Keep grouped_layer (parcels) in sync — it's a separate layer from demand_points_layer
            _grp_lyr = getattr(self, 'grouped_layer', None)
            try:
                _grp_deleted = sip.isdeleted(_grp_lyr) if _grp_lyr else True
            except Exception:
                _grp_deleted = True
            if _grp_lyr and not _grp_deleted and _grp_lyr != _dem_layer:
                _grp_fnames = [f.name() for f in _grp_lyr.fields()]
                _grp_link = _demand_group_field(_grp_fnames)  # #79: any group_<N> size
                _grp_zi  = _grp_lyr.fields().indexFromName('zone_id')  if 'zone_id'   in _grp_fnames else -1
                _grp_zni = _grp_lyr.fields().indexFromName('zone_name') if 'zone_name' in _grp_fnames else -1
                if _grp_link and _grp_zi >= 0:
                    # Snapshot grouped layer before editing
                    for _f in _grp_lyr.getFeatures():
                        if _f[_grp_link] in changing_groups:
                            _snap['attr_ops'].append((_grp_lyr, _f.id(), _grp_zi, _f['zone_id']))
                            if _grp_zni >= 0:
                                _snap['attr_ops'].append((_grp_lyr, _f.id(), _grp_zni, _f['zone_name']))
                    _grp_attr = {}
                    for _f in _grp_lyr.getFeatures():
                        if _f[_grp_link] in changing_groups:
                            _ops = {_grp_zi: new_zone}
                            if _grp_zni >= 0:
                                _ops[_grp_zni] = f"Zone {new_zone}"
                            _grp_attr[_f.id()] = _ops
                    _grp_upd = len(_grp_attr)
                    if _grp_attr:
                        _grp_lyr.dataProvider().changeAttributeValues(_grp_attr)
                    _grp_lyr.triggerRepaint()
                    if _grp_upd:
                        results.append(f"Grouped Layer — {_grp_upd} feature(s)")

            # 3. Update drop cable layers
            for _dc_name in ("Drop Cables Lashed", "Drop Cables PTP"):
                for _lyr in QgsProject.instance().mapLayers().values():
                    if isinstance(_lyr, QgsVectorLayer) and _lyr.name() == _dc_name:
                        _dc_fnames = [f.name() for f in _lyr.fields()]
                        if 'zone_id' in _dc_fnames and 'group_id' in _dc_fnames:
                            _dczi = _lyr.fields().indexFromName('zone_id')
                            # Snapshot drop cables before editing
                            for _f in _lyr.getFeatures():
                                if _f['group_id'] in changing_groups:
                                    _snap['attr_ops'].append((_lyr, _f.id(), _dczi, _f['zone_id']))
                            _dc_attr = {}
                            for _f in _lyr.getFeatures():
                                if _f['group_id'] in changing_groups:
                                    _dc_attr[_f.id()] = {_dczi: new_zone}
                            _upd_dc = len(_dc_attr)
                            if _dc_attr:
                                _lyr.dataProvider().changeAttributeValues(_dc_attr)
                            _lyr.triggerRepaint()
                            if _upd_dc:
                                results.append(f"{_dc_name} — {_upd_dc} cable(s)")
                        break

            # 4. Update PON Zone boundaries — unit_count + regenerate polygon geometry
            # Use group link field + splitter_data zone mapping to find demand features per zone.
            # This avoids relying on zone_id field being present or type-consistent on the demand layer.
            _src_lyr  = None   # source point layer for polygon building
            _src_link = None   # group link field name on _src_lyr
            if _dem_layer and _link:
                _src_lyr  = _dem_layer
                _src_link = _link
            else:
                _grp_cand = getattr(self, 'grouped_layer', None)
                try:
                    if _grp_cand and not sip.isdeleted(_grp_cand):
                        _gcnames = [f.name() for f in _grp_cand.fields()]
                        _src_link = _demand_group_field(_gcnames)  # #79: any group_<N> size
                        if _src_link:
                            _src_lyr = _grp_cand
                except Exception:
                    pass

            # Zone → set-of-group_ids mapping from splitter_data (PRE-move state)
            _z2g = {}
            for _sd in splitter_data:
                _z2g.setdefault(int(_sd['zone_id']), set()).add(_sd['group_id'])

            for _lyr in QgsProject.instance().mapLayers().values():
                _lname_zs = _lyr.name() if hasattr(_lyr, 'name') else ''
                if isinstance(_lyr, QgsVectorLayer) and (
                        'PON Zone Boundaries' in _lname_zs or 'PON Zones' in _lname_zs):
                    _b_fnames = [f.name() for f in _lyr.fields()]
                    if 'zone_id' in _b_fnames and 'unit_count' in _b_fnames:
                        _snap['pon_lyr'] = _lyr
                        _uc_idx = _lyr.fields().indexFromName('unit_count')
                        # Snapshot PON zone features BEFORE editing
                        for _f in _lyr.getFeatures():
                            _fzid = int(_f['zone_id']) if _f['zone_id'] is not None else -1
                            if _fzid in old_zones_delta:
                                _n_out = old_zones_delta[_fzid]
                                _will_empty = max(0, (_f['unit_count'] or 0) - _n_out) == 0
                                if _will_empty:
                                    # Will be deleted — save full copy to restore on undo
                                    from qgis.core import QgsFeature as _QFsnap
                                    _snap['del_feats'].append((_lyr, [_QFsnap(_f)]))
                                else:
                                    _snap['attr_ops'].append((_lyr, _f.id(), _uc_idx, _f['unit_count']))
                                    _snap['geom_ops'].append((_lyr, _f.id(), QgsGeometry(_f.geometry())))
                            elif _fzid == new_zone:
                                _snap['attr_ops'].append((_lyr, _f.id(), _uc_idx, _f['unit_count']))
                                _snap['geom_ops'].append((_lyr, _f.id(), QgsGeometry(_f.geometry())))
                        _lyr.startEditing()
                        _b_upd = []
                        _new_zone_found = False
                        _fids_to_delete = []
                        for _f in _lyr.getFeatures():
                            _fzid = int(_f['zone_id']) if _f['zone_id'] is not None else -1
                            if _fzid in old_zones_delta:
                                _n_out = old_zones_delta[_fzid]
                                _new_uc = max(0, (_f['unit_count'] or 0) - _n_out)
                                _b_upd.append(f"PON {_fzid}: {(_f['unit_count'] or 0)} → {_new_uc}")
                                if _new_uc == 0:
                                    # Zone is now empty — delete the polygon
                                    _fids_to_delete.append(_f.id())
                                else:
                                    _lyr.changeAttributeValue(_f.id(), _uc_idx, _new_uc)
                                    if _src_lyr and _src_link:
                                        # Remaining groups in old zone = zone's groups minus those moving out
                                        _rem_grps = _z2g.get(int(_fzid), set()) - changing_groups
                                        _oz_feats = [_ff for _ff in _src_lyr.getFeatures()
                                                     if _ff[_src_link] in _rem_grps]
                                        if _oz_feats:
                                            _oz_geom = self._build_zone_polygon(_src_lyr, _oz_feats)
                                            if not _oz_geom.isEmpty():
                                                _lyr.changeGeometry(_f.id(), _oz_geom)
                            elif int(_fzid) == new_zone:
                                _new_zone_found = True
                                _new_uc = (_f['unit_count'] or 0) + new_zone_gain
                                _lyr.changeAttributeValue(_f.id(), _uc_idx, _new_uc)
                                _b_upd.append(f"PON {new_zone}: {(_f['unit_count'] or 0)} → {_new_uc}")
                                if _src_lyr and _src_link:
                                    # New zone groups = original new zone groups + moving groups
                                    _new_grps = _z2g.get(new_zone, set()) | changing_groups
                                    _nz_feats = [_ff for _ff in _src_lyr.getFeatures()
                                                 if _ff[_src_link] in _new_grps]
                                    if _nz_feats:
                                        _nz_geom = self._build_zone_polygon(_src_lyr, _nz_feats)
                                        if not _nz_geom.isEmpty():
                                            _lyr.changeGeometry(_f.id(), _nz_geom)
                        if _fids_to_delete:
                            _lyr.deleteFeatures(_fids_to_delete)
                            _b_upd.append(f"Removed {len(_fids_to_delete)} empty zone polygon(s)")
                        # Create a new boundary polygon if new_zone has no existing feature
                        if not _new_zone_found and _src_lyr and _src_link:
                            _new_grps = _z2g.get(new_zone, set()) | changing_groups
                            _nz_feats = [_ff for _ff in _src_lyr.getFeatures()
                                         if _ff[_src_link] in _new_grps]
                            if _nz_feats:
                                _nz_geom = self._build_zone_polygon(_src_lyr, _nz_feats)
                                if not _nz_geom.isEmpty():
                                    from qgis.core import QgsFeature as _QF
                                    _new_feat = _QF(_lyr.fields())
                                    _new_feat.setGeometry(_nz_geom)
                                    _new_feat['zone_id']    = new_zone
                                    _new_feat['zone_name']  = vf_pon_name(new_zone)
                                    _new_feat['unit_count'] = new_zone_gain
                                    _lyr.addFeature(_new_feat)
                                    _snap['add_zone_ids'].append(new_zone)
                                    _b_upd.append(f"PON {new_zone}: (new) {new_zone_gain}")
                        _safe_commit(_lyr)
                        _lyr.triggerRepaint()
                        if _b_upd:
                            results.append(f"PON Zone Boundaries — {'; '.join(_b_upd)}")
                    break

            # Update local splitter_data; re-render the list so the #98 groups-per-zone
            # column + >16 highlight reflect the moved splitters (both the old and new
            # zones' group counts changed).
            for sd in to_change:
                sd['zone_id'] = new_zone
            _sync_count_labels()
            # Auto-deselect after successful apply
            list_widget.clearSelection()
            refresh_summary()

            # Push snapshot to undo stack
            _undo_stack.append(_snap)
            _enable_undo()

            _old_str = ", ".join(vf_pon_name(z) for z in sorted(old_zones_delta))
            _summary = "<br>".join(results)
            status_lbl.setText(
                f"<font color='green'><b>Done:</b> {len(to_change)} splitter(s): "
                f"{_old_str} → Zone {new_zone}<br>{_summary}<br>Regenerating drop cables…</font>")
            self.log_message(f"Manual Override: {len(to_change)} splitter(s) → Zone {new_zone}")
            for _r in results:
                self.log_message(f"  {_r}")
            # Regenerate drop cables so zone_id on cables matches the new assignment.
            # Incremental: only the reassigned groups changed (positions unchanged) →
            # route just their drops instead of the whole layer (kills the per-click freeze).
            _regen_drops(only_groups=set(int(_g) for _g in changing_groups) if changing_groups else None)
            status_lbl.setText(
                f"<font color='green'><b>Done:</b> {len(to_change)} splitter(s): "
                f"{_old_str} → Zone {new_zone} — drops regenerated.</font>")

        # ================================================================
        # Demand reassignment apply
        # ================================================================
        def apply_demand_change():
            if not (demand_data and dem_list and combo_target):
                return
            sel_rows = [dem_list.row(it) for it in dem_list.selectedItems()]
            if not sel_rows:
                status_lbl.setText("No demand points selected.")
                return

            # Resolve target: spin_grp takes priority if it matches a known splitter,
            # otherwise fall back to combo selection.
            _manual_gid = spin_grp.value()
            tgt_sd = next((sd for sd in splitter_data
                           if int(sd['group_id']) == int(_manual_gid)), None)
            if tgt_sd is None:
                # MO audit: resolve the target by the "Group N" actually SHOWN in the
                # combo, never a bare index — an editable/rebuilt combo's index points at
                # the wrong splitter (the #64 class), which silently reassigned demand +
                # re-routed drops to the wrong group.
                import re as _re_tg
                _mt = _re_tg.search(r'Group\s+(\d+)', combo_target.currentText() or '')
                if _mt:
                    _gp = int(_mt.group(1))
                    tgt_sd = next((sd for sd in splitter_data
                                   if int(sd['group_id']) == _gp), None)
            if tgt_sd is None:
                status_lbl.setText("Pick a valid target splitter (Group ID not found).")
                return
            new_grp  = tgt_sd['group_id']
            new_zone = tgt_sd['zone_id']

            # Collect only those that actually change
            moves = [(demand_data[r], demand_data[r]['group_id'], demand_data[r]['zone_id'], r)
                     for r in sel_rows if demand_data[r]['group_id'] != new_grp]
            if not moves:
                status_lbl.setText("No change — all selected demand points are already in that group.")
                dem_list.clearSelection()
                return

            # _dem_layer may have been removed/invalidated since the panel opened;
            # guard before the first dereference (was crashing at _dem_layer.fields()
            # below, well before the late guard).
            if not _dem_layer or sip.isdeleted(_dem_layer):
                status_lbl.setText("ERROR: Demand Points layer not accessible.")
                return

            # ---- Snapshot for undo ----
            _snap_dp = {
                'desc':         f"{len(moves)} demand point(s) → Group {new_grp} / Zone {new_zone}",
                'attr_ops':     [],
                'geom_ops':     [],
                'del_feats':    [],
                'add_zone_ids': [],
                'pon_lyr':      None,
                'mem_ops':      [],
                'list_ops':     [],
                'combo_ops':    [],
            }
            # Demand point attributes
            _link_idx_s = _dem_layer.fields().indexFromName(_dp_link)
            for dd, old_g, old_z, row in moves:
                _snap_dp['attr_ops'].append((_dem_layer, dd['fid'], _link_idx_s, old_g))
                if _dp_zi >= 0:
                    _snap_dp['attr_ops'].append((_dem_layer, dd['fid'], _dp_zi, old_z))
                if _dp_zni >= 0:
                    _f_tmp = next((_ff for _ff in _dem_layer.getFeatures()
                                   if _ff.id() == dd['fid']), None)
                    if _f_tmp:
                        _snap_dp['attr_ops'].append((_dem_layer, dd['fid'], _dp_zni,
                                                     _f_tmp['zone_name']))
                _snap_dp['mem_ops'].append((dd, 'group_id', dd['group_id']))
                _snap_dp['mem_ops'].append((dd, 'zone_id',  dd['zone_id']))
                _snap_dp['list_ops'].append((dem_list, row, dem_list.item(row).text()))
            # Splitter drop_count
            _old_grps_dp = {dd['group_id'] for dd, _, _, _ in moves}
            _old_grps_dp |= {str(g) for g in list(_old_grps_dp)}  # MO audit: int|str match
            _dc_idx_s = splitter_layer.fields().indexFromName('drop_count') \
                if 'drop_count' in sp_field_names else -1
            if _dc_idx_s >= 0:
                for _spf in splitter_layer.getFeatures():
                    _sgid = _spf['group_id']
                    if _sgid in _old_grps_dp or _sgid == new_grp:
                        _snap_dp['attr_ops'].append((splitter_layer, _spf.id(), _dc_idx_s,
                                                     _spf['drop_count'] or 0))
                        for sd in splitter_data:
                            if sd['group_id'] == _sgid:
                                _si = splitter_data.index(sd)
                                _snap_dp['mem_ops'].append((sd, 'drop_count', sd['drop_count']))
                                _snap_dp['list_ops'].append((list_widget, _si,
                                                             list_widget.item(_si).text()))
                                _snap_dp['combo_ops'].append((combo_target, _si,
                                                              combo_target.itemText(_si)))
            # Limit stack depth
            if len(_undo_stack) >= 10:
                _undo_stack.pop(0)

            results_dp = []

            # 1. Update demand point attributes
            if not _dem_layer:
                status_lbl.setText("ERROR: Demand Points layer not accessible.")
                return
            _link_idx = _dem_layer.fields().indexFromName(_dp_link)
            _dem_layer.startEditing()
            for dd, old_g, old_z, row in moves:
                _dem_layer.changeAttributeValue(dd['fid'], _link_idx, new_grp)
                if _dp_zi >= 0:
                    _dem_layer.changeAttributeValue(dd['fid'], _dp_zi, new_zone)
                if _dp_zni >= 0:
                    _dem_layer.changeAttributeValue(dd['fid'], _dp_zni, f"Zone {new_zone}")
                # Ticket #68: this demand point was MANUALLY assigned to its splitter,
                # so allow its drop to cross a road if it must reach that splitter.
                _force_cross.add(dd['fid'])
            _safe_commit(_dem_layer)
            # Tickets #111/#112: persist the approvals so these moved drops survive a
            # later regen / zone revisit / reload instead of being dropped again.
            self._save_force_cross(_dem_layer, _force_cross)
            # Rebuild accumulator renderer if demand layer is PON Groups accum
            _accum_grp_r = getattr(self, '_pon_accum_groups', None)
            try:
                from qgis.PyQt import sip as _sip_dm
                if _accum_grp_r and not _sip_dm.isdeleted(_accum_grp_r) and _dem_layer is _accum_grp_r:
                    self._pon_refresh_accum_renderers()
                else:
                    _dem_layer.triggerRepaint()
            except Exception:
                _dem_layer.triggerRepaint()
            results_dp.append(f"Demand Points — {len(moves)} updated")

            # 2. Update splitter drop_counts
            old_grp_delta = {}   # {old_group: count of points leaving}
            for dd, old_g, old_z, row in moves:
                old_grp_delta[old_g] = old_grp_delta.get(old_g, 0) + 1
            _dc_idx = splitter_layer.fields().indexFromName('drop_count') if 'drop_count' in sp_field_names else -1
            if _dc_idx >= 0:
                splitter_layer.startEditing()
                for _spf in splitter_layer.getFeatures():
                    _sgid = _spf['group_id']
                    if _sgid in old_grp_delta:
                        _new_dc = max(0, (_spf['drop_count'] or 0) - old_grp_delta[_sgid])
                        splitter_layer.changeAttributeValue(_spf.id(), _dc_idx, _new_dc)
                        for sd in splitter_data:
                            if sd['group_id'] == _sgid:
                                sd['drop_count'] = _new_dc
                    elif _sgid == new_grp:
                        _new_dc = (_spf['drop_count'] or 0) + len(moves)
                        splitter_layer.changeAttributeValue(_spf.id(), _dc_idx, _new_dc)
                        for sd in splitter_data:
                            if sd['group_id'] == new_grp:
                                sd['drop_count'] = _new_dc
                _safe_commit(splitter_layer)
                # Rebuild accumulator renderer if splitter layer is PON Splitter Points accum
                _accum_sp_r = getattr(self, '_pon_accum_splitters', None)
                try:
                    from qgis.PyQt import sip as _sip_sp
                    if _accum_sp_r and not _sip_sp.isdeleted(_accum_sp_r) and splitter_layer is _accum_sp_r:
                        self._pon_refresh_accum_renderers()
                    else:
                        splitter_layer.triggerRepaint()
                except Exception:
                    splitter_layer.triggerRepaint()
                results_dp.append("Splitter drop counts updated")
                # Ticket #96: refresh EVERY count display (list + all combos) from the
                # now-updated splitter_data, not just the list + target combo, so the
                # delete/add-demand dropdowns can't show a stale count after a reassign.
                _sync_count_labels()

            # 3. Update drop cable group_id + zone_id for moved demand points
            # demand_id field exists but is unpopulated; match by group_id only.
            # Match both single-run names and the PON accumulator "PON Drop Cables".
            _old_grps_moved = {dd['group_id'] for dd, _, _, _ in moves}
            _old_grps_moved |= {str(g) for g in list(_old_grps_moved)}  # MO audit: int|str match
            _drop_lyrs_done = set()
            for _lyr in QgsProject.instance().mapLayers().values():
                if not isinstance(_lyr, QgsVectorLayer):
                    continue
                _lname = _lyr.name()
                if _lname in _drop_lyrs_done:
                    continue
                _is_drop = (_lname in ("Drop Cables Lashed", "Drop Cables PTP", "PON Drop Cables")
                            or 'drop cable' in _lname.lower())
                if not _is_drop:
                    continue
                _dc_fnames = [f.name() for f in _lyr.fields()]
                if 'zone_id' not in _dc_fnames or 'group_id' not in _dc_fnames:
                    continue
                _drop_lyrs_done.add(_lname)
                _dczi2 = _lyr.fields().indexFromName('zone_id')
                _dcgi2 = _lyr.fields().indexFromName('group_id')
                _lyr.startEditing()
                _upd_dc2 = 0
                for _f in _lyr.getFeatures():
                    if _f['group_id'] in _old_grps_moved:
                        _lyr.changeAttributeValue(_f.id(), _dcgi2, new_grp)
                        _lyr.changeAttributeValue(_f.id(), _dczi2, new_zone)
                        _upd_dc2 += 1
                _safe_commit(_lyr)
                # Rebuild renderer if this is the drop cable accumulator
                _accum_dr = getattr(self, '_pon_accum_drops', None)
                try:
                    from qgis.PyQt import sip as _sip_dc
                    if _accum_dr and not _sip_dc.isdeleted(_accum_dr) and _lyr is _accum_dr:
                        self._pon_refresh_accum_renderers()
                    else:
                        _lyr.triggerRepaint()
                except Exception:
                    _lyr.triggerRepaint()
                if _upd_dc2:
                    results_dp.append(f"{_lname} — {_upd_dc2} cable(s) updated")

            # 4. Update PON Zone boundaries using group link field + splitter_data zone mapping.
            # Works even if demand points have no zone_id field.
            affected_old_zones = {int(old_z) for _, _, old_z, _ in moves
                                  if old_z is not None and int(old_z) != new_zone}
            moved_fids = {dd['fid'] for dd, _, _, _ in moves}
            # Build zone → group_ids mapping from splitter_data (zone assignments unchanged by this op)
            _z2g_dp = {}
            for _sd in splitter_data:
                _z2g_dp.setdefault(int(_sd['zone_id']), set()).add(_sd['group_id'])

            for _lyr in QgsProject.instance().mapLayers().values():
                _lname_zdp = _lyr.name() if hasattr(_lyr, 'name') else ''
                if isinstance(_lyr, QgsVectorLayer) and (
                        'PON Zone Boundaries' in _lname_zdp or 'PON Zones' in _lname_zdp):
                    _b_fnames = [f.name() for f in _lyr.fields()]
                    if 'zone_id' in _b_fnames and 'unit_count' in _b_fnames:
                        _uc_idx2 = _lyr.fields().indexFromName('unit_count')
                        # Snapshot PON zones BEFORE editing
                        _snap_dp['pon_lyr'] = _lyr
                        for _f in _lyr.getFeatures():
                            _fzid2 = int(_f['zone_id']) if _f['zone_id'] is not None else -1
                            if _fzid2 in affected_old_zones:
                                # Check if zone will be empty after moves
                                _rem_grps2 = _z2g_dp.get(_fzid2, set())
                                _rem_feats_chk = [_ff for _ff in _dem_layer.getFeatures()
                                                  if _ff[_dp_link] in _rem_grps2
                                                  and _ff.id() not in moved_fids]
                                if len(_rem_feats_chk) == 0:
                                    from qgis.core import QgsFeature as _QFsnap2
                                    _snap_dp['del_feats'].append((_lyr, [_QFsnap2(_f)]))
                                else:
                                    _snap_dp['attr_ops'].append((_lyr, _f.id(), _uc_idx2,
                                                                 _f['unit_count'] or 0))
                                    _snap_dp['geom_ops'].append((_lyr, _f.id(),
                                                                 QgsGeometry(_f.geometry())))
                            elif _fzid2 == new_zone:
                                _snap_dp['attr_ops'].append((_lyr, _f.id(), _uc_idx2,
                                                             _f['unit_count'] or 0))
                                _snap_dp['geom_ops'].append((_lyr, _f.id(),
                                                             QgsGeometry(_f.geometry())))
                        _lyr.startEditing()
                        _new_zone_found2 = False
                        _fids_del2 = []
                        for _f in _lyr.getFeatures():
                            _fzid2 = int(_f['zone_id']) if _f['zone_id'] is not None else -1
                            if _fzid2 in affected_old_zones:
                                # Remaining demand: in this zone's groups, excluding moved fids
                                _rem_grps2 = _z2g_dp.get(_fzid2, set())
                                _rem_feats = [_ff for _ff in _dem_layer.getFeatures()
                                              if _ff[_dp_link] in _rem_grps2
                                              and _ff.id() not in moved_fids]
                                _new_uc = len(_rem_feats)
                                if _new_uc == 0:
                                    _fids_del2.append(_f.id())
                                else:
                                    _lyr.changeAttributeValue(_f.id(), _uc_idx2, _new_uc)
                                    _oz_geom = self._build_zone_polygon(_dem_layer, _rem_feats)
                                    if not _oz_geom.isEmpty():
                                        _lyr.changeGeometry(_f.id(), _oz_geom)
                            elif _fzid2 == new_zone:
                                _new_zone_found2 = True
                                # All demand in new zone's groups + moved demand points
                                _nz_grps2 = _z2g_dp.get(new_zone, set())
                                _nz_feats = [_ff for _ff in _dem_layer.getFeatures()
                                             if _ff[_dp_link] in _nz_grps2
                                             or _ff.id() in moved_fids]
                                _lyr.changeAttributeValue(_f.id(), _uc_idx2, len(_nz_feats))
                                _nz_geom = self._build_zone_polygon(_dem_layer, _nz_feats)
                                if not _nz_geom.isEmpty():
                                    _lyr.changeGeometry(_f.id(), _nz_geom)
                        if _fids_del2:
                            _lyr.deleteFeatures(_fids_del2)
                        if not _new_zone_found2:
                            _nz_grps2 = _z2g_dp.get(new_zone, set())
                            _nz_feats = [_ff for _ff in _dem_layer.getFeatures()
                                         if _ff[_dp_link] in _nz_grps2
                                         or _ff.id() in moved_fids]
                            if _nz_feats:
                                from qgis.core import QgsFeature as _QF2
                                _nf = _QF2(_lyr.fields())
                                _nf['zone_id']    = new_zone
                                _nf['zone_name']  = vf_pon_name(new_zone)
                                _nf['unit_count'] = len(_nz_feats)
                                _nz_geom = self._build_zone_polygon(_dem_layer, _nz_feats)
                                if not _nz_geom.isEmpty():
                                    _nf.setGeometry(_nz_geom)
                                _lyr.addFeature(_nf)
                                _snap_dp['add_zone_ids'].append(new_zone)
                        _safe_commit(_lyr)
                        # Rebuild renderer if zone boundaries layer is the accumulator
                        _accum_zn = getattr(self, '_pon_accum_zones', None)
                        try:
                            from qgis.PyQt import sip as _sip_zn
                            if _accum_zn and not _sip_zn.isdeleted(_accum_zn) and _lyr is _accum_zn:
                                self._pon_refresh_accum_renderers()
                            else:
                                _lyr.triggerRepaint()
                        except Exception:
                            _lyr.triggerRepaint()
                        results_dp.append("PON Zone Boundaries updated")
                    break

            # Update in-memory demand_data + list labels, then auto-deselect
            for dd, old_g, old_z, row in moves:
                dd['group_id'] = new_grp
                dd['zone_id']  = new_zone
                dem_list.item(row).setText(
                    f"DP {dd['fid']}   |   Group {new_grp}   |   Zone {new_zone}")
            dem_list.clearSelection()

            # Push snapshot to undo stack
            _undo_stack.append(_snap_dp)
            _enable_undo()

            status_lbl.setText(
                f"<font color='green'><b>Done:</b> {len(moves)} demand point(s) → "
                f"Group {new_grp} / Zone {new_zone}<br>"
                + "<br>".join(results_dp)
                + "<br>Regenerating drop cables…</font>")
            self.log_message(f"Demand Override: {len(moves)} point(s) → Group {new_grp} / Zone {new_zone}")

            # Auto-regenerate drops so cable geometry reflects the new assignments.
            # Incremental: only the source + destination groups changed.
            _regen_aff = {int(new_grp)} | set(int(m[1]) for m in moves if m[1] is not None)
            _regen_drops(only_groups=_regen_aff or None)
            status_lbl.setText(
                f"<font color='green'><b>Done:</b> {len(moves)} demand point(s) → "
                f"Group {new_grp} / Zone {new_zone} — drops regenerated.</font>")

        # ================================================================
        # Map tool — tab-aware picking
        # ================================================================
        from qgis.core import QgsCoordinateTransform, QgsProject as _QP

        _canvas    = self.iface.mapCanvas()
        _prev_tool = _canvas.mapTool()
        _map_tool  = QgsMapToolEmitPoint(_canvas)
        _picking   = [True]

        # ---- Ticket #99 (JJ): make EVERYTHING you select/reference visible -----------
        # A gold rubber-band highlight that tracks the current selection/reference so a
        # picked splitter, a selected demand point, or a "Group N" chosen in a combo is
        # obvious on the canvas (the default layer selection colour was easy to miss in
        # this dense network). Cleared + hidden when the dialog closes.
        from qgis.core import QgsWkbTypes as _HLWKB, QgsFeatureRequest as _HLReq
        _hl_pt = QgsRubberBand(_canvas, _HLWKB.GeometryType.PointGeometry)
        _hl_pt.setColor(QColor(255, 196, 0))
        _hl_pt.setWidth(3)
        try:
            _hl_pt.setIcon(QgsRubberBand.ICON_CIRCLE)
            _hl_pt.setIconSize(20)
        except Exception:
            pass
        _hl_ln = QgsRubberBand(_canvas, _HLWKB.GeometryType.LineGeometry)
        _hl_ln.setColor(QColor(255, 196, 0))
        _hl_ln.setWidth(4)

        def _hl_clear():
            try:
                _hl_pt.reset(_HLWKB.GeometryType.PointGeometry)
            except Exception:
                pass
            try:
                _hl_ln.reset(_HLWKB.GeometryType.LineGeometry)
            except Exception:
                pass

        def _hl_show(layer, fids):
            """Highlight the given feature ids on `layer` (CRS handled by addGeometry)."""
            _hl_clear()
            if not layer or not fids:
                return
            try:
                _seen = False
                for _hf in layer.getFeatures(_HLReq().setFilterFids(list(fids))):
                    _hg = _hf.geometry()
                    if not _hg or _hg.isEmpty():
                        continue
                    if _hg.type() == _HLWKB.GeometryType.LineGeometry:
                        _hl_ln.addGeometry(_hg, layer)
                    else:
                        _hl_pt.addGeometry(_hg, layer)
                    _seen = True
                if _seen:
                    _hl_pt.show()
                    _hl_ln.show()
            except Exception as _he:
                self.log_message(f"highlight error: {_he}")

        def _hl_group(gid):
            """Highlight the splitter for a referenced group id."""
            try:
                _sd = next((s for s in splitter_data if str(s['group_id']) == str(gid)), None)
                if _sd is not None:
                    _hl_show(splitter_layer, [_sd['fid']])
            except Exception:
                pass

        # Wire the highlight to every select/reference surface.
        def _fill_delete_box_from_rows(_rows):
            """#99 (JJ): whatever splitter(s) you pick land in the Delete Splitter box
            so you can confirm before deleting — no typing. One selected → set the box;
            many → tell you to narrow to one."""
            try:
                if len(_rows) == 1 and _rows[0] < len(splitter_data):
                    _sd = splitter_data[_rows[0]]
                    for _ci in range(combo_del_sp.count()):
                        if (combo_del_sp.itemData(_ci) == _sd['fid'] or
                                combo_del_sp.itemText(_ci).startswith(f"Splitter {_sd['group_id']}  |")):
                            combo_del_sp.setCurrentIndex(_ci)
                            break
                    btn_delete_sp.setEnabled(True)
                    status_lbl.setText(
                        f"<font color='blue'>Splitter Group {_sd['group_id']} selected & "
                        f"highlighted — it's in the Delete box; click Delete Splitter.</font>")
                elif len(_rows) > 1:
                    status_lbl.setText(
                        f"<font color='blue'>{len(_rows)} splitters selected & highlighted. "
                        f"Select a single one to fill the Delete box, or reassign their zone.</font>")
            except Exception:
                pass

        def _hl_on_splitter_sel(*_a):
            _rows = [list_widget.row(it) for it in list_widget.selectedItems()]
            _fids = [splitter_data[r]['fid'] for r in _rows if r < len(splitter_data)]
            _hl_show(splitter_layer, _fids) if _fids else _hl_clear()
            _fill_delete_box_from_rows(_rows)
        list_widget.itemSelectionChanged.connect(_hl_on_splitter_sel)
        if dem_list and _dem_layer:
            def _hl_on_demand_sel(*_a):
                _rows = [dem_list.row(it) for it in dem_list.selectedItems()]
                _fids = [demand_data[r]['fid'] for r in _rows if r < len(demand_data)]
                _hl_show(_dem_layer, _fids) if _fids else _hl_clear()
            dem_list.itemSelectionChanged.connect(_hl_on_demand_sel)
        import re as _hlre

        def _hl_on_combo(_txt):
            # Matches BOTH spellings. These combo entries were relabelled from
            # "Group N" to "Splitter N" (2026-07-23) and this parser reads them
            # back to drive the map highlight — leaving it on "Group" alone
            # would have silently killed the highlight, with nothing to see in
            # any log. Accepting both also keeps it working if a stale widget
            # from before the rename is still around.
            _m = _hlre.search(r'(?:Group|Splitter)\s+(\d+)', _txt or '')
            if _m:
                _hl_group(int(_m.group(1)))
        combo_del_sp.currentTextChanged.connect(_hl_on_combo)
        if combo_target:
            combo_target.currentTextChanged.connect(_hl_on_combo)
        if combo_add_dp_grp:
            combo_add_dp_grp.currentTextChanged.connect(_hl_on_combo)

        # Polygon-select tool for the Demand Points tab
        _poly_tool = _PolySelectDemandTool(
            _canvas,
            demand_data,
            dem_list if demand_data else None,
            None,   # status_lbl placeholder — set below after status_lbl is defined
            splitter_layer.crs()) if demand_data else None

        # #99 (JJ): polygon/nearest splitter picker for the Splitter Zones tab.
        _poly_tool_sp = _PolySelectSplitterTool(_canvas, splitter_layer.crs())

        def _on_canvas_click(point, _button):
            if _dlg_closed[0] or not _picking[0]:
                return
            # Honour QGIS native snapping for new-splitter placement (JJ: snapping
            # everywhere) — snaps the click to a vertex/segment when snapping is on.
            point = snap_point_to_project(_canvas, point)
            _xform = QgsCoordinateTransform(
                _QP.instance().crs(), splitter_layer.crs(), _QP.instance())
            try:
                _lp = _xform.transform(point)
            except Exception:
                _lp = point

            if tab_widget.currentIndex() == 0:
                # Splitter picking
                _best_idx, _best_d = 0, float('inf')
                for _i, _sd in enumerate(splitter_data):
                    _d = math.sqrt((_sd['x'] - _lp.x()) ** 2 + (_sd['y'] - _lp.y()) ** 2)
                    if _d < _best_d:
                        _best_d = _d
                        _best_idx = _i
                _item = list_widget.item(_best_idx)
                _item.setSelected(not _item.isSelected())
                _n = len(list_widget.selectedItems())
                _word = "selected" if _item.isSelected() else "deselected"
                status_lbl.setText(
                    f"<font color='blue'>Group {splitter_data[_best_idx]['group_id']} {_word} "
                    f"— {_n} splitter(s) selected.</font>")

            else:
                # Tab 2 — capture coordinate for new splitter
                from qgis.core import QgsGeometry, QgsPointXY as _PXY, QgsVectorLayer as _VL
                _ns_point[0] = _lp
                lbl_ns_x.setText(f"{_lp.x():.4f}")
                lbl_ns_y.setText(f"{_lp.y():.4f}")
                btn_add_sp.setEnabled(True)

                # Auto-detect zone from PON Zone polygon layer
                _auto_zone = 0
                for _lyr in _QP.instance().mapLayers().values():
                    if not isinstance(_lyr, _VL) or _lyr.geometryType() != 2:
                        continue
                    _ln = _lyr.name().lower()
                    if ('pon' in _ln or 'zone' in _ln) and ('zone' in _ln or 'boundar' in _ln):
                        _pt_geom = QgsGeometry.fromPointXY(_PXY(_lp.x(), _lp.y()))
                        for _zf in _lyr.getFeatures():
                            _zfg = _zf.geometry()
                            if _zfg and not _zfg.isEmpty() and _pt_geom.within(_zfg):
                                _zval = _zf['zone_id'] if 'zone_id' in [_fd.name() for _fd in _lyr.fields()] else None
                                if _zval is not None:
                                    try:
                                        _auto_zone = int(_zval)
                                    except (TypeError, ValueError):
                                        pass
                                break
                        break
                spin_ns_zone.setValue(_auto_zone)
                status_lbl.setText(
                    f"<font color='blue'>Point captured at ({_lp.x():.2f}, {_lp.y():.2f}) "
                    f"— PON auto-detected: {_auto_zone}. "
                    f"Adjust attributes and click <b>Add Splitter Point</b>.</font>")

        def _on_tool_deactivate():
            # Ticket #65/#70-followup: the map tool's `deactivated` signal can fire
            # AFTER the dialog's widgets are gone — and the `_dlg_closed` flag is only
            # set when the dialog closes normally; a plugin update/reload while the
            # dialog is open destroys the widgets WITHOUT running the close handler.
            # So guard on the actual widget (sip.isdeleted), not just the flag, to
            # avoid "QPushButton has been deleted".
            from qgis.PyQt import sip as _sip_td
            try:
                if _dlg_closed[0] or _sip_td.isdeleted(btn_pick) or _sip_td.isdeleted(dlg):
                    return
            except Exception:
                return
            if _picking[0]:
                _picking[0] = False
                try:
                    btn_pick.setChecked(False)
                    btn_pick.setText("Map Picking: OFF")
                    status_lbl.setText(
                        "Map picking paused — another tool was activated. "
                        "Click 'Map Picking: OFF' to resume.")
                except RuntimeError:
                    return  # widgets vanished mid-call — nothing to update

        _map_tool.canvasClicked.connect(_on_canvas_click)
        _map_tool.deactivated.connect(_on_tool_deactivate)

        # Wire status_lbl into the poly-select tool now that it exists
        if _poly_tool:
            _poly_tool._status = status_lbl
            _poly_tool.deactivated.connect(_on_tool_deactivate)
        # #99: same pause-on-deactivate wiring for the splitter polygon picker.
        try:
            _poly_tool_sp.deactivated.connect(_on_tool_deactivate)
        except Exception:
            pass

        # Add-new-demand-point placement tool
        _dp_add_tool = QgsMapToolEmitPoint(_canvas) if demand_data else None

        def _on_dp_place_click(_pt, _btn):
            """Capture a map click as the location for the new demand point."""
            if _dlg_closed[0] or not _dp_add_mode[0]:
                return
            from qgis.core import QgsGeometry, QgsPointXY as _PXY, QgsVectorLayer as _VL
            # Honour QGIS native snapping for new-demand-point placement (JJ).
            _pt = snap_point_to_project(_canvas, _pt)
            _dp_new_point[0] = _pt
            if lbl_new_dp_x and lbl_new_dp_y:
                lbl_new_dp_x.setText(f"{_pt.x():.4f}")
                lbl_new_dp_y.setText(f"{_pt.y():.4f}")

            # Auto-detect zone from PON Zone polygon layer (same logic as splitter tab)
            _auto_zone = 0
            for _lyr in _QP.instance().mapLayers().values():
                if not isinstance(_lyr, _VL) or _lyr.geometryType() != 2:
                    continue
                _ln = _lyr.name().lower()
                if ('pon' in _ln or 'zone' in _ln) and ('zone' in _ln or 'boundar' in _ln):
                    _pt_geom = QgsGeometry.fromPointXY(_PXY(_pt.x(), _pt.y()))
                    for _zf in _lyr.getFeatures():
                        _zfg = _zf.geometry()
                        if _zfg and not _zfg.isEmpty() and _pt_geom.within(_zfg):
                            _zval = _zf['zone_id'] if 'zone_id' in [_fd.name() for _fd in _lyr.fields()] else None
                            if _zval is not None:
                                try:
                                    _auto_zone = int(_zval)
                                except (TypeError, ValueError):
                                    pass
                            break
                    break
            if spin_dp_zone:
                spin_dp_zone.setValue(_auto_zone)

            # Refresh Add button — still needs splitter selection
            _has_grp = combo_add_dp_grp is not None and combo_add_dp_grp.currentIndex() > 0
            if btn_add_dp:
                btn_add_dp.setEnabled(_has_grp)
            status_lbl.setText(
                f"<font color='purple'>Location captured at ({_pt.x():.2f}, {_pt.y():.2f}) "
                f"— PON auto-detected: {_auto_zone}. "
                f"{'Select a splitter then click <b>Add Demand Point</b>.' if not _has_grp else 'Click <b>Add Demand Point</b> to confirm.'}</font>")

        def _do_add_demand_point():
            """Create a new demand point feature on the demand layer."""
            _pt = _dp_new_point[0]
            if _pt is None:
                status_lbl.setText("<font color='red'>No location captured. Click 📍 Place on Map first.</font>")
                return
            if not demand_data:
                return
            # Index 0 is the placeholder "— Select splitter —"
            # MO audit: resolve the target splitter by the "Group N" SHOWN in the combo,
            # not a bare index — the searchable combo's index desyncs and would add the
            # demand point (and its drop) to the WRONG group. Index is only a fallback.
            import re as _re_ad
            _target_sp = None
            _mt = (_re_ad.search(r'Group\s+(\d+)', combo_add_dp_grp.currentText() or '')
                   if combo_add_dp_grp else None)
            if _mt:
                _gp = int(_mt.group(1))
                _target_sp = next((sd for sd in splitter_data
                                   if int(sd['group_id']) == _gp), None)
            if _target_sp is None:
                _idx_combo = (combo_add_dp_grp.currentIndex() - 1) if combo_add_dp_grp else -1
                if 0 <= _idx_combo < len(splitter_data):
                    _target_sp = splitter_data[_idx_combo]
            if _target_sp is None:
                status_lbl.setText("<font color='red'>Select a splitter from the list before adding.</font>")
                return
            # zone 0 = "outside any PON polygon" (auto-detect missed) → inherit the
            # chosen splitter's zone instead of writing a phantom "Zone 0"
            _zid = (spin_dp_zone.value() if spin_dp_zone else 0) or _target_sp['zone_id']

            _new_feat = QgsFeature(_dem_layer.fields())
            _new_feat.setGeometry(QgsGeometry.fromPointXY(_pt))
            try:
                _new_feat[_dp_link] = _target_sp['group_id']
            except Exception:
                pass
            try:
                _new_feat['zone_id'] = _zid
            except Exception:
                pass
            try:
                # splitter_data has no 'zone_name' key — use the canonical
                # "Zone N" convention so the new point isn't left blank/desynced
                # from its siblings (matches the label logic used everywhere else).
                _new_feat['zone_name'] = _target_sp.get('zone_name') or vf_pon_name(_zid)
            except Exception:
                pass

            # Snapshot committed fids BEFORE the add so we can recover the new
            # feature's REAL (post-commit) id below — the edit buffer's temporary
            # (negative) id won't match what the drop regen iterates (ticket #74).
            _existing_fids = {f.id() for f in _dem_layer.getFeatures()}

            # MO audit: add via the DATA PROVIDER (immediate) instead of an edit-buffer
            # commit. With startEditing()+addFeature()+commit the new point was NOT yet
            # visible to the very next incremental drop-regen in the same call, so the
            # added house got NO drop cable (the #74 "no line for new demand point"
            # class). A provider add is visible immediately, so the fast only_groups
            # regen below now includes it — and we keep the per-click speed (no full
            # re-route).
            _res_add = _dem_layer.dataProvider().addFeatures([_new_feat])
            _ok = _res_add[0] if isinstance(_res_add, tuple) else bool(_res_add)
            if _ok:
                _dem_layer.updateExtents()
                # Rebuild accumulator renderer if demand layer is the PON Groups accum
                _accum_grp_dp = getattr(self, '_pon_accum_groups', None)
                try:
                    from qgis.PyQt import sip as _sip6
                    if _accum_grp_dp and not _sip6.isdeleted(_accum_grp_dp) and _dem_layer is _accum_grp_dp:
                        self._pon_refresh_accum_renderers()
                    else:
                        _dem_layer.triggerRepaint()
                except Exception:
                    _dem_layer.triggerRepaint()
                # The edit buffer gives a new feature a temporary (often negative) id;
                # after commit the provider assigns the real id. Using the temp id for
                # force-cross never matched the committed id the drop regen iterates, so a
                # manually-added point whose straight drop crosses a road was wrongly
                # skipped → dot but no line (ticket #74). Recover the REAL committed id.
                _added_fids = {f.id() for f in _dem_layer.getFeatures()} - _existing_fids
                _new_fid = next(iter(_added_fids)) if _added_fids else _new_feat.id()
                # Ticket #68: a manually-added demand point was deliberately assigned
                # to this splitter — allow its drop to cross a road if needed.
                _force_cross.add(_new_fid)
                # Tickets #111/#112: persist so this added drop's road crossing survives regen.
                self._save_force_cross(_dem_layer, _force_cross)
                _entry = {
                    'fid':      _new_fid,
                    'group_id': _target_sp['group_id'],
                    'zone_id':  _zid,
                    'x':        _pt.x(),
                    'y':        _pt.y(),
                }
                demand_data.append(_entry)
                if dem_list:
                    dem_list.addItem(
                        f"DP {_new_fid}   |   Group {_entry['group_id']}   |   Zone {_entry['zone_id']}")
                # Update drop count on target splitter
                _target_sp['drop_count'] = _target_sp.get('drop_count', 0) + 1
                # Ticket #97: persist the new count to the splitter layer attribute too
                # (bulk provider write, no edit session) so the attribute table + on-map
                # labels stay in sync with the dialog — the other edit paths (delete /
                # reassign / edit-splitter) already write it; add-demand previously didn't.
                if 'drop_count' in sp_field_names and _target_sp.get('fid') is not None:
                    _dc_i_add = splitter_layer.fields().indexFromName('drop_count')
                    if _dc_i_add >= 0:
                        splitter_layer.dataProvider().changeAttributeValues(
                            {_target_sp['fid']: {_dc_i_add: _target_sp['drop_count']}})
                        try:
                            _acc_add = getattr(self, '_pon_accum_splitters', None)
                            from qgis.PyQt import sip as _sip_add
                            if (_acc_add and not _sip_add.isdeleted(_acc_add)
                                    and splitter_layer is _acc_add):
                                self._pon_refresh_accum_renderers()
                            else:
                                splitter_layer.triggerRepaint()
                        except Exception:
                            splitter_layer.triggerRepaint()
                # Ticket #96: refresh ALL count displays from splitter_data — the old
                # path updated only the two combos and left the Splitter Zones list
                # (and combo_del_sp) showing a stale, too-low count after an add.
                _sync_count_labels()
                # Reset
                _dp_new_point[0] = None
                if lbl_new_dp_x and lbl_new_dp_y:
                    lbl_new_dp_x.setText("—")
                    lbl_new_dp_y.setText("—")
                if spin_dp_zone:
                    spin_dp_zone.setValue(0)
                if combo_add_dp_grp:
                    combo_add_dp_grp.setCurrentIndex(0)
                if btn_place_dp:
                    btn_place_dp.setChecked(False)
                if btn_add_dp:
                    btn_add_dp.setEnabled(False)
                self.log_message(
                    f"Manual Override — new demand point: Group {_target_sp['group_id']}, "
                    f"PON {_zid}, pos=({_pt.x():.2f}, {_pt.y():.2f})")
                status_lbl.setText(
                    f"<font color='green'><b>✓ Demand point added:</b> "
                    f"Group {_target_sp['group_id']} | Zone {_zid} at "
                    f"({_pt.x():.1f}, {_pt.y():.1f}). Updating zone & drops…</font>")
                # Ticket #62/#63: rebuild only THIS zone's boundary from its own
                # demand points (tight, local — never a map-spanning hull), then
                # refresh the zone labels.
                # MO audit: the zone-boundary rebuild + count refresh must NEVER block
                # the drop regen. They previously ran unguarded BEFORE the regen, so a
                # zone-rebuild exception aborted the whole handler and the freshly-added
                # demand point got NO drop cable (the #74 "no line for new point" class).
                # Wrap them so the cable regen below always runs.
                try:
                    _grew = _rebuild_zone_boundary(_target_sp.get('zone_name', ''), _zid)
                except Exception as _zbe:
                    _grew = False
                    self.log_message(f"  (zone boundary rebuild skipped: {_zbe})")
                try:
                    self._pon_refresh_zone_counts()
                except Exception:
                    pass
                # Batch D: only this new point's group changed → fast incremental regen.
                _ng = _target_sp.get('group_id')
                _regen_drops(only_groups={int(_ng)} if _ng is not None else None)
                status_lbl.setText(
                    "<font color='green'>Demand point added"
                    + (", zone boundary updated" if _grew else "")
                    + " and drops regenerated.</font>")
            else:
                status_lbl.setText("<font color='red'>Failed to add demand point to layer.</font>")

        def _do_delete_demand_points():
            """Delete selected demand points from the layer and refresh UI."""
            if not dem_list:
                return
            _sel_rows = sorted([dem_list.row(it) for it in dem_list.selectedItems()], reverse=True)
            if not _sel_rows:
                status_lbl.setText("<font color='orange'>No demand points selected for deletion.</font>")
                return
            _fids_to_del = [demand_data[r]['fid'] for r in _sel_rows if r < len(demand_data)]
            # Geometry Guardian: this is an INTENTIONAL operator delete — whitelist it
            # so the guardian doesn't mistake the drop for a bug + auto-restore it.
            try:
                from ..geometry_guardian import note_operator_delete as _gg_note
                _gg_note(_dem_layer.id(), len(_fids_to_del))
            except Exception:
                pass
            # Batch D: capture affected groups BEFORE deletion so we can incrementally
            # regen only those groups' drops (a deleted point's drop just isn't rebuilt).
            # Any oddity → None = safe full rebuild.
            try:
                _affected_grps = {int(demand_data[r]['group_id']) for r in _sel_rows
                                  if r < len(demand_data) and demand_data[r].get('group_id') is not None}
            except (TypeError, ValueError):
                _affected_grps = None
            # Ticket #96 (JJ): keep splitter drop_counts accurate. Deleting demand
            # points must DECREMENT the owning splitter's drop_count — add-demand
            # increments it (and reassign adjusts both sides) but delete previously
            # left the count stale (too high) in the list/combos. Tally per-group
            # how many points are being removed, BEFORE the rows are popped.
            _del_grp_delta = {}
            for r in _sel_rows:
                if r < len(demand_data):
                    _g = demand_data[r].get('group_id')
                    if _g is not None:
                        try:
                            _g = int(_g)
                        except (TypeError, ValueError):
                            continue
                        _del_grp_delta[_g] = _del_grp_delta.get(_g, 0) + 1
            # claude:intent MUTATE — user asked: "check what lodewijk asked for and
            # test it" (ticket #99 Undo Button). Plan: edit this handler's SOURCE to
            # snapshot the deleted demand points BEFORE the existing delete so Undo can
            # restore them. claude:approved-destructive — the .startEditing()/delete
            # below is the handler's own pre-existing operator-driven delete, unchanged.
            # ---- Ticket #99 (Lodewijk): snapshot BEFORE mutation so the delete is
            # undoable. Independent copies of the features being deleted (geom + attrs)
            # paired with their demand_data dict + original list row, in deletion order.
            _snap99 = {
                'desc': f"Delete {len(_fids_to_del)} demand point(s)",
                'attr_ops': [], 'geom_ops': [], 'del_feats': [], 'add_zone_ids': [],
                'pon_lyr': None, 'mem_ops': [], 'list_ops': [], 'combo_ops': [],
            }
            _deleted99 = []
            for r in _sel_rows:
                if r < len(demand_data):
                    _ddict99 = dict(demand_data[r])
                    _feat99 = _dem_layer.getFeature(_ddict99['fid'])
                    if _feat99.isValid():
                        _deleted99.append((r, _ddict99, QgsFeature(_feat99)))
            _dem_layer.startEditing()
            _ok = _dem_layer.deleteFeatures(_fids_to_del)
            if _ok:
                _safe_commit(_dem_layer)
                _dem_layer.triggerRepaint()
                for r in _sel_rows:
                    if r < len(demand_data):
                        demand_data.pop(r)
                    dem_list.takeItem(r)
                # Decrement the owning splitters' drop_count (layer attr + in-memory
                # splitter_data) so every count display stays accurate after a delete,
                # mirroring the reassign-demand maintenance above (ticket #96).
                # claude:approved-destructive (same _safe_commit pattern as reassign;
                # only updates the drop_count attribute, no geometry/feature deletion)
                if _del_grp_delta:
                    _dc_idx_del = (splitter_layer.fields().indexFromName('drop_count')
                                   if 'drop_count' in sp_field_names else -1)
                    if _dc_idx_del >= 0:
                        splitter_layer.startEditing()
                        for _spf in splitter_layer.getFeatures():
                            try:
                                _sgid = int(_spf['group_id'])
                            except (TypeError, ValueError):
                                continue
                            if _sgid in _del_grp_delta:
                                # claude:intent MUTATE — user asked: "check what lodewijk
                                # asked for and test it" (#99). Plan: record old drop_count
                                # for undo; the changeAttributeValue below is the handler's
                                # pre-existing #96 count maintenance, unchanged.
                                _snap99['attr_ops'].append(
                                    (splitter_layer, _spf.id(), _dc_idx_del, _spf['drop_count'] or 0))
                                _new_dc = max(0, (_spf['drop_count'] or 0) - _del_grp_delta[_sgid])
                                splitter_layer.changeAttributeValue(_spf.id(), _dc_idx_del, _new_dc)
                                for sd in splitter_data:
                                    if sd['group_id'] == _sgid:
                                        _snap99['mem_ops'].append((sd, 'drop_count', sd['drop_count']))
                                        sd['drop_count'] = _new_dc
                        _safe_commit(splitter_layer)
                        _accum_sp_d = getattr(self, '_pon_accum_splitters', None)
                        try:
                            from qgis.PyQt import sip as _sip_d
                            if _accum_sp_d and not _sip_d.isdeleted(_accum_sp_d) and splitter_layer is _accum_sp_d:
                                self._pon_refresh_accum_renderers()
                            else:
                                splitter_layer.triggerRepaint()
                        except Exception:
                            splitter_layer.triggerRepaint()
                        # Re-render every count display from the now-accurate splitter_data.
                        _sync_count_labels()
                status_lbl.setText(
                    f"<font color='green'>Deleted {len(_fids_to_del)} demand point(s). Regenerating drops…</font>")
                _regen_drops(only_groups=_affected_grps or None)
                status_lbl.setText(
                    f"<font color='green'>Deleted {len(_fids_to_del)} demand point(s) and drops regenerated.</font>")

                # ---- Ticket #99: register the undo for this delete ----
                # claude:intent MUTATE — user asked: "check what lodewijk asked for and
                # test it" (#99 Undo Button). Plan: undo re-adds the just-deleted demand
                # points (restoring what an operator removed by mistake) — an explicit,
                # user-driven restore. claude:approved-destructive — the dataProvider
                # write only re-inserts the features we captured before deletion.
                def _undo_del_dp(_snap, _deleted=_deleted99, _grps=_affected_grps):
                    """Restore demand points removed by this delete (runs via undo_last
                    after its attr/mem ops have restored the splitter drop_counts)."""
                    if not _deleted:
                        return
                    # re-add independent copies; the provider assigns fresh fids and
                    # returns the added features in the SAME order we passed them.
                    _copies = [QgsFeature(_f) for (_r, _dd, _f) in _deleted]
                    _added_ok, _added = _dem_layer.dataProvider().addFeatures(_copies)
                    _dem_layer.updateExtents()
                    _dem_layer.triggerRepaint()
                    # pair each restored dict with its new feature, re-insert ascending
                    # by original row so positions line up with the rebuilt list.
                    _pairs = []
                    for (_r, _dd, _orig), _nf in zip(_deleted, _added):
                        _ndd = dict(_dd)
                        _ndd['fid'] = _nf.id()
                        _pairs.append((_r, _ndd))
                    for _r, _ndd in sorted(_pairs, key=lambda t: t[0]):
                        _ins = min(_r, len(demand_data))
                        demand_data.insert(_ins, _ndd)
                        if dem_list:
                            dem_list.insertItem(
                                _ins,
                                f"DP {_ndd['fid']}   |   Group {_ndd['group_id']}   |   Zone {_ndd['zone_id']}")
                    _regen_drops(only_groups=_grps or None)
                _snap99['post'] = _undo_del_dp
                if len(_undo_stack) >= 10:
                    _undo_stack.pop(0)
                _undo_stack.append(_snap99)
                _enable_undo()
            else:
                _dem_layer.rollBack()
                status_lbl.setText("<font color='red'>Failed to delete demand points.</font>")

        def _toggle_place_dp(checked):
            """Toggle 'Place on Map' mode for adding a new demand point."""
            _dp_add_mode[0] = checked
            if checked:
                if not _picking[0]:
                    _picking[0] = True
                    btn_pick.setChecked(True)
                    btn_pick.setText("Map Picking: ON")
                _canvas.setMapTool(_dp_add_tool)
                status_lbl.setText(
                    "<font color='purple'>Click on the map to place the new demand point location.</font>")
            else:
                if _picking[0]:
                    _canvas.setMapTool(_poly_tool if _poly_tool else _map_tool)
                status_lbl.setText("Place on Map cancelled.")

        if _dp_add_tool:
            _dp_add_tool.canvasClicked.connect(_on_dp_place_click)

        def _start_picking():
            _picking[0] = True
            _idx = tab_widget.currentIndex()
            if _idx == 1 and _poly_tool:
                _canvas.setMapTool(_poly_tool)
            elif _idx == 0:
                _canvas.setMapTool(_poly_tool_sp)   # #99: splitter polygon/nearest picker
            else:
                _canvas.setMapTool(_map_tool)
            btn_pick.setChecked(True)
            btn_pick.setText("Map Picking: ON")

        def _stop_picking(restore_tool=True):
            _picking[0] = False
            if restore_tool:
                _canvas.setMapTool(_prev_tool)
            btn_pick.setChecked(False)
            btn_pick.setText("Map Picking: OFF")

        def _on_pick_toggle(checked):
            if checked:
                _start_picking()
                _idx = tab_widget.currentIndex()
                if _idx == 0:
                    status_lbl.setText(
                        "Map picking ON — click a splitter (or left-click a polygon, right-click "
                        "to finish) to select + highlight it and fill the Delete box.")
                elif _idx == 1:
                    status_lbl.setText(
                        "Map picking ON — left-click to draw a polygon, right-click to finish and select demand points.")
                else:
                    status_lbl.setText("Map picking ON — click the map to place a new splitter point.")
            else:
                _stop_picking()
                status_lbl.setText("Map picking paused — use the list for selection.")

        def _on_tab_changed(_idx):
            if _picking[0]:
                if _idx == 1:
                    if _dp_add_mode[0] and _dp_add_tool:
                        _canvas.setMapTool(_dp_add_tool)
                        status_lbl.setText(
                            "<font color='purple'>Click on the map to place the new demand point location.</font>")
                    elif _poly_tool:
                        _canvas.setMapTool(_poly_tool)
                        status_lbl.setText(
                            "Map picking ON — left-click to draw a polygon, right-click to finish and select demand points.")
                elif _idx == 0:
                    _canvas.setMapTool(_poly_tool_sp)   # #99: splitter polygon/nearest picker
                    status_lbl.setText(
                        "Map picking ON — click a splitter (or draw a polygon) to select + "
                        "highlight it and fill the Delete box.")
                else:
                    _canvas.setMapTool(_map_tool)
                    status_lbl.setText("Map picking ON — click the map to place a new splitter point.")

        def _on_dialog_close():
            _dlg_closed[0] = True   # ticket #65: stop stray canvas events touching deleted widgets
            _picking[0] = False
            _dp_add_mode[0] = False
            try:
                _map_tool.canvasClicked.disconnect(_on_canvas_click)
            except Exception:
                pass
            try:
                _map_tool.deactivated.disconnect(_on_tool_deactivate)
            except Exception:
                pass
            if _poly_tool:
                try:
                    _poly_tool.deactivated.disconnect(_on_tool_deactivate)
                except Exception:
                    pass
                try:
                    _poly_tool.deactivate()
                except Exception:
                    pass
            # #99: tidy the splitter polygon picker's rubber band on close.
            try:
                _poly_tool_sp.deactivate()
            except Exception:
                pass
            if _dp_add_tool:
                try:
                    _dp_add_tool.canvasClicked.disconnect(_on_dp_place_click)
                except Exception:
                    pass
            # Ticket #65: drop the splitter-layer selection hook so it can't fire
            # into this dialog's deleted widgets after close (QComboBox-deleted crash).
            try:
                splitter_layer.selectionChanged.disconnect(_on_splitter_selection_changed)
            except Exception:
                pass
            # #99: clear + detach the highlight rubber bands so nothing is left painted
            # on the canvas and no stray event touches them after close (ticket #65 class).
            try:
                _hl_clear()
                _hl_pt.hide()
                _hl_ln.hide()
                _canvas.scene().removeItem(_hl_pt)
                _canvas.scene().removeItem(_hl_ln)
            except Exception:
                pass
            _canvas.setMapTool(_prev_tool)

        btn_pick.toggled.connect(_on_pick_toggle)
        tab_widget.currentChanged.connect(_on_tab_changed)
        # _PanelDock (QDockWidget) has NO QDialog `finished` signal — run the
        # map-tool / rubber-band teardown via the dock's on_close hook instead.
        # _PanelDock.closeEvent calls self._on_close(); _dlg_close (above) chains
        # that closeEvent, so this fires on every normal close (matches the old
        # finished-based cleanup, without the AttributeError crash — ticket #128).
        dlg._on_close = _on_dialog_close
        btn_apply_sp.clicked.connect(apply_change)
        btn_undo_sp.clicked.connect(undo_last)
        if demand_data and btn_apply_dp:
            btn_apply_dp.clicked.connect(apply_demand_change)
        if btn_undo_dp:
            btn_undo_dp.clicked.connect(undo_last)
        # Ticket #99: the delete-adjacent Undo buttons share the one undo stack.
        if btn_undo_del_dp:
            btn_undo_del_dp.clicked.connect(undo_last)
        if btn_undo_del_sp:
            btn_undo_del_sp.clicked.connect(undo_last)
        if btn_regen_drops_dp is not None:
            def _do_regen_drops_dp():
                status_lbl.setText("<font color='orange'>Regenerating drop cables…</font>")
                _regen_drops()
                _dr2 = _drop_layer if (_drop_layer is not None and not sip.isdeleted(_drop_layer)) \
                    else getattr(self, 'drop_ptp_layer', None)
                _lyr_name2 = _dr2.name() if _dr2 else "Drop Cables PTP"
                status_lbl.setText(
                    f"<font color='green'><b>✓ Drop cables regenerated</b> — layer: {_lyr_name2}</font>")
            btn_regen_drops_dp.clicked.connect(_do_regen_drops_dp)
        if btn_place_dp:
            btn_place_dp.toggled.connect(_toggle_place_dp)
        if btn_add_dp:
            btn_add_dp.clicked.connect(_do_add_demand_point)
        if btn_delete_dp:
            btn_delete_dp.clicked.connect(_do_delete_demand_points)
        btn_close.clicked.connect(dlg.close)

        _start_picking()
        status_lbl.setText("Map picking ON — click splitters on the map.")
        # Open it FULLY docked (full height, raised) via the shared helper — not
        # a half floating window that needs a re-snap.
        try:
            try:
                from ..fibre_automation import dock_util as _du
            except ImportError:
                from fibre_automation import dock_util as _du
        except Exception:
            _du = None
        if _du is not None:
            _du.dock_fully(self.iface, dlg, width=560)
        else:
            self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dlg)
            dlg.show()
            dlg.raise_()
            dlg.activateWindow()

    # ================================================================
    def on_manual_override_final_clicked(self):
        """Open layer-picker then launch Manual Override on any existing saved layers.

        Works independently of whether a PON per PON session was ever run.
        The user selects which project layers represent splitters, demand points,
        zone boundaries and drop cables, then the full Manual Override dialog opens
        pointed at those layers.
        """
        from qgis.PyQt.QtWidgets import (
            QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
            QComboBox, QFrame, QFormLayout, QMessageBox)
        from qgis.PyQt.QtCore import Qt
        from qgis.core import QgsProject, QgsVectorLayer

        proj_layers = {
            lyr.name(): lyr
            for lyr in QgsProject.instance().mapLayers().values()
            if isinstance(lyr, QgsVectorLayer)
        }
        if not proj_layers:
            QMessageBox.warning(self, "No Layers", "No vector layers found in the current project.")
            return

        # ── Auto-detect layers by name patterns ──────────────────────────
        def _best(patterns, geom_type=None):
            """Return the best-matching layer name, or '' if none found."""
            for lyr_name, lyr in proj_layers.items():
                n = lyr_name.lower()
                if geom_type is not None and lyr.geometryType() != geom_type:
                    continue
                if any(p in n for p in patterns):
                    return lyr_name
            return ''

        def_splitters = _best(['splitter'], geom_type=0)
        # Prefer a splitter layer that actually carries group_id+zone_id — a project can
        # have several 'splitter' layers and only the planner's has the fields (JJ 2026-06-25).
        for _sn, _sl in proj_layers.items():
            if _sl.geometryType() == 0 and 'splitter' in _sn.lower():
                _sfn = [f.name() for f in _sl.fields()]
                if 'group_id' in _sfn and 'zone_id' in _sfn:
                    def_splitters = _sn
                    break
        def_demand    = _best(['demand', 'groups of'], geom_type=0)
        # Prefer a demand layer that actually carries a group-link field (group_<N>/
        # batch_id). The planner's PON output ('PON Groups') has it; the raw imported
        # 'Demand Points' does not — and auto-detect used to grab 'Demand Points', so
        # zone/group reassignment silently no-op'd (the "Layers may not be ready" warning).
        for _dn, _dl in proj_layers.items():
            if _dl.geometryType() == 0 and any(
                    p in _dn.lower() for p in ('demand', 'group', 'pon')):
                if _demand_group_field([f.name() for f in _dl.fields()]):
                    def_demand = _dn
                    break
        def_zones     = _best(['zone', 'boundar'], geom_type=2)
        def_drops     = _best(['drop', 'cable'], geom_type=1)

        # ── Layer-picker dialog ───────────────────────────────────────────
        picker = QDialog(self)
        picker.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        picker.setWindowTitle("Manual Override — Select Layers")
        picker.setMinimumWidth(480)
        picker.setModal(True)
        picker.setWindowFlags(picker.windowFlags() | Qt.WindowType.WindowStaysOnTopHint)
        pl = QVBoxLayout(picker)
        pl.setSpacing(8)

        info = QLabel(
            "<b>Select the layers to edit.</b><br>"
            "Splitters and Demand Points are required.<br>"
            "PON Boundaries and Drop Cables are optional but enable PON updates and drop regeneration."
        )
        info.setWordWrap(True)
        pl.addWidget(info)

        sep = QFrame(); sep.setFrameShape(QFrame.Shape.HLine); sep.setFrameShadow(QFrame.Shadow.Sunken)
        pl.addWidget(sep)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        all_names = [''] + list(proj_layers.keys())

        def _combo(default_name, geom_type=None):
            cb = QComboBox()
            filtered = [''] + [n for n, lyr in proj_layers.items()
                               if geom_type is None or lyr.geometryType() == geom_type]
            cb.addItems(filtered)
            if default_name in filtered:
                cb.setCurrentText(default_name)
            return cb

        # Recall the planner's last Manual Override Final layer choice so re-opening
        # the picker keeps the chosen working set (ticket #73 — "layers chosen before
        # starting the edits"). Falls back to name auto-detect when unset/stale.
        from qgis.core import QgsSettings as _QSet
        _ovset = _QSet()

        def _recall(key, auto):
            v = _ovset.value(f"VelocityFibre/override_final/{key}", "") or ""
            return v if v in proj_layers else auto

        cb_sp  = _combo(_recall('splitters', def_splitters), geom_type=0)
        cb_dem = _combo(_recall('demand',    def_demand),    geom_type=0)
        cb_zon = _combo(_recall('zones',     def_zones),     geom_type=2)
        cb_drp = _combo(_recall('drops',     def_drops),     geom_type=1)

        form.addRow("🔴 Splitters layer (required):", cb_sp)
        form.addRow("🔵 Demand Points layer (required):", cb_dem)
        form.addRow("🟩 PON Boundaries layer (optional):", cb_zon)
        form.addRow("⬛ Drop Cables layer (optional):", cb_drp)
        pl.addLayout(form)

        btns = QHBoxLayout()
        btn_ok     = QPushButton("Open Manual Override")
        btn_cancel = QPushButton("Cancel")
        btn_ok.setStyleSheet(
            "QPushButton { background-color: #1a3a5c; color: white; font-weight: bold; "
            "border-radius: 3px; padding: 4px 12px; }")
        btns.addStretch()
        btns.addWidget(btn_cancel)
        btns.addWidget(btn_ok)
        pl.addLayout(btns)

        btn_cancel.clicked.connect(picker.reject)
        # #101/#102 class (audit): picker is WA_DeleteOnClose, so reading the combos
        # AFTER picker.exec() can crash ("QComboBox has been deleted"). Capture the
        # chosen layer names up-front in the accept handler, while the widgets are alive.
        _pick_vals = {}

        def _picker_accept():
            try:
                _pick_vals['sp'] = cb_sp.currentText()
                _pick_vals['dem'] = cb_dem.currentText()
                _pick_vals['zon'] = cb_zon.currentText()
                _pick_vals['drp'] = cb_drp.currentText()
            except RuntimeError:
                pass
            picker.accept()

        btn_ok.clicked.connect(_picker_accept)

        if picker.exec() != QDialog.DialogCode.Accepted:
            return

        # ── Validate ─────────────────────────────────────────────────────
        sp_name  = _pick_vals.get('sp', '')
        dem_name = _pick_vals.get('dem', '')
        zon_name = _pick_vals.get('zon', '')
        drp_name = _pick_vals.get('drp', '')

        if not sp_name:
            QMessageBox.warning(self, "Missing Layer", "Please select a Splitters layer.")
            return
        if not dem_name:
            QMessageBox.warning(self, "Missing Layer", "Please select a Demand Points layer.")
            return

        # ── Verify the chosen layers carry the fields the Manual Override +
        # PON-per-PON features need (ticket #73/#67). Without group_id/zone_id on
        # splitters or a group-link field on demand, zone/group reassignment silently
        # does nothing — the exact "only works after re-running PON-per-PON" failure.
        # Warn with specifics but let the planner proceed (some flows are geometry-only).
        _sp_fields  = [f.name() for f in proj_layers[sp_name].fields()]
        _dem_fields = [f.name() for f in proj_layers[dem_name].fields()]
        _grp_link = _demand_group_field(_dem_fields)  # #79: pattern, not fixed sizes
        _missing = []
        if 'group_id' not in _sp_fields or 'zone_id' not in _sp_fields:
            _missing.append(f"• Splitters '{sp_name}' is missing group_id / zone_id")
        if not _grp_link:
            _missing.append(f"• Demand '{dem_name}' has no group link field (group_8/16/128/100)")
        if _missing:
            if QMessageBox.question(
                self, "Layers may not be ready",
                "These features need fields that aren't present on the chosen layers:\n\n"
                + "\n".join(_missing)
                + "\n\nZone / group reassignment may not apply. Continue anyway?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            ) != QMessageBox.StandardButton.Yes:
                return

        # Remember this working set for next time.
        for _k, _v in (('splitters', sp_name), ('demand', dem_name),
                       ('zones', zon_name), ('drops', drp_name)):
            _ovset.setValue(f"VelocityFibre/override_final/{_k}", _v)

        # ── Wire accumulators to selected layers ─────────────────────────
        self._pon_accum_splitters = proj_layers[sp_name]
        self._pon_accum_groups    = proj_layers[dem_name]
        self._pon_accum_zones     = proj_layers[zon_name]  if zon_name else None
        self._pon_accum_drops     = proj_layers[drp_name]  if drp_name else None
        # MO audit: record an EXPLICIT skip when the planner left a layer blank, so the
        # engine honors "leave this layer alone" instead of re-resolving a stale or
        # name-matched layer. Consumed (reset) by on_manual_override_clicked.
        self._mo_final_skip_zones = (not zon_name)
        self._mo_final_skip_drops = (not drp_name)

        # Prevent _pon_per_pon_run from nulling these on next run
        self._pon_new_session_needed = False

        # Also mirror to the standard single-run layer refs used by drop regen
        self.splitter_points_layer = self._pon_accum_splitters
        self.demand_points_layer   = self._pon_accum_groups
        if self._pon_accum_zones:
            self.zone_boundaries_layer = self._pon_accum_zones
        if self._pon_accum_drops:
            self.drop_ptp_layer = self._pon_accum_drops

        self.log_message(
            f"[Manual Override] Layers linked — "
            f"Splitters: '{sp_name}', Demand: '{dem_name}', "
            f"PONs: '{zon_name or 'none'}', Drops: '{drp_name or 'none'}'"
        )

        # ── Open the standard Manual Override dialog ──────────────────────
        self.on_manual_override_clicked()

    def on_create_enclosure_clicked(self):
        """Open enclosure type chooser, then let user click map to place enclosure point."""
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                          QPushButton)
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsField, QgsProject, QgsMarkerSymbol, QgsSingleSymbolRenderer,
                                QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                                QgsVectorLayerSimpleLabeling)
        from qgis.PyQt.QtCore import QMetaType
        from qgis.PyQt.QtGui import QColor, QFont

        # If button is unchecked, cancel any active placement
        if not self._btn_create_enclosure.isChecked():
            if self._create_enclosure_tool:
                self.iface.mapCanvas().unsetMapTool(self._create_enclosure_tool)
                self._create_enclosure_tool = None
            self._create_enclosure_type = None
            self.log_message("Create Enclosure: placement cancelled.")
            return

        # ── Step 1: Ask user what type of enclosure ──────────────────────────
        dlg = QDialog(self.iface.mainWindow())
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)   # don't leak hidden windows
        dlg.setWindowTitle("Create Enclosure — Select Type")
        dlg.setMinimumWidth(320)
        layout = QVBoxLayout(dlg)

        lbl = QLabel("Select the enclosure type to place on the map:")
        lbl.setWordWrap(True)
        layout.addWidget(lbl)

        btn_fs = QPushButton("📦  Feeder Splice  (FS)")
        btn_fs.setStyleSheet(
            "QPushButton { background-color: #1a5276; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #2471a3; }"
        )
        btn_fts = QPushButton("📦  First Tier Splitter Splice  (FTS)")
        btn_fts.setStyleSheet(
            "QPushButton { background-color: #145a32; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #1e8449; }"
        )
        btn_cancel = QPushButton("Cancel")

        layout.addWidget(btn_fs)
        layout.addWidget(btn_fts)
        layout.addSpacing(6)
        layout.addWidget(btn_cancel)

        chosen_type = [None]

        def _pick(enc_type):
            chosen_type[0] = enc_type
            dlg.accept()

        btn_fs.clicked.connect(lambda: _pick('FS'))
        btn_fts.clicked.connect(lambda: _pick('FTS'))
        btn_cancel.clicked.connect(dlg.reject)

        if dlg.exec() != QDialog.DialogCode.Accepted or not chosen_type[0]:
            self._btn_create_enclosure.setChecked(False)
            return

        enc_type = chosen_type[0]
        self._create_enclosure_type = enc_type
        self.log_message(f"Create Enclosure: type={enc_type} — click on the map to place. Right-click to finish.")

        # ── Step 2: Activate map click tool ──────────────────────────────────
        canvas = self.iface.mapCanvas()
        crs = canvas.mapSettings().destinationCrs().authid()
        layer_name = f"Manual Enclosures ({enc_type})"

        # Get or create the enclosure layer for this type
        enc_layer = None
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name() == layer_name:
                enc_layer = lyr
                break

        if enc_layer is None:
            color = '30,82,172,255' if enc_type == 'FS' else '21,128,50,255'
            enc_layer = QgsVectorLayer(f"Point?crs={crs}", layer_name, "memory")
            provider = enc_layer.dataProvider()
            provider.addAttributes([
                QgsField('enclosure_id', QMetaType.Type.Int),
                QgsField('enclosure_name', QMetaType.Type.QString),
                QgsField('enclosure_type', QMetaType.Type.QString),
            ])
            enc_layer.updateFields()

            symbol = QgsMarkerSymbol.createSimple({
                'name': 'square',
                'color': color,
                'outline_color': '255,255,255,255',
                'outline_width': '0.6',
                'size': '7',
            })
            enc_layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            # Labels
            lbl_s = QgsPalLayerSettings()
            lbl_s.fieldName = 'enclosure_name'
            lbl_s.enabled = True
            fmt = QgsTextFormat()
            fmt.setFont(QFont("Arial", 7))
            fmt.setColor(QColor(255, 255, 255))
            buf = QgsTextBufferSettings()
            buf.setEnabled(True)
            buf.setSize(1.0)
            buf.setColor(QColor(0, 0, 0))
            fmt.setBuffer(buf)
            lbl_s.setFormat(fmt)
            enc_layer.setLabeling(QgsVectorLayerSimpleLabeling(lbl_s))
            enc_layer.setLabelsEnabled(True)

            QgsProject.instance().addMapLayer(enc_layer)
            self.log_message(f"  Created new layer: '{layer_name}'")

        # Track next ID for this layer
        existing_ids = [f['enclosure_id'] for f in enc_layer.getFeatures() if f['enclosure_id']]
        next_id = [max(existing_ids) + 1 if existing_ids else 1]

        # ── Snap-to-cable placement tool (JJ, live request): the enclosure must land
        # ON the cable, not floating beside it. As the cursor moves we snap to the
        # nearest cable (feeder / distribution / span — never roads/boundaries) and show
        # a live marker; the click places the enclosure exactly on that snapped point.
        from qgis.gui import QgsMapTool as _EncMapTool, QgsVertexMarker
        from qgis.core import (QgsSpatialIndex, QgsCoordinateTransform,
                               QgsPointXY as _EncPXY, QgsVectorLayer as _EncVL)

        _enc_root = QgsProject.instance().layerTreeRoot()

        def _is_cable_lyr(_l):
            try:
                if not isinstance(_l, _EncVL) or _l.geometryType() != 1:  # 1 = line
                    return False
                if _l.featureCount() == 0:
                    return False
            except Exception:
                return False
            _n = _l.name().lower()
            # Backbone cables only — NEVER snap enclosures to drops, scratch/temp/sandbox
            # layers, roads, boundaries or non-cable layers.
            if any(_k in _n for _k in
                   ('road', 'erven', 'erf', 'zone', 'boundary', 'aoi', 'pon ', 'demand',
                    'drop', 'spare', 'temp', 'exp_', 'core', 'ont', 'splitter', 'pole')):
                return False
            if not any(_k in _n for _k in
                       ('feeder', 'distribution', 'primary', 'secondary', 'span',
                        'spur', 'link', 'cable', 'adss', 'blown', 'mini',
                        '144f', '48f', '24f', '12f')):
                return False
            # Only snap to cables the user can actually SEE (checked in the layer tree),
            # so the enclosure lands on a visible line, not a hidden sandbox duplicate.
            try:
                _node = _enc_root.findLayer(_l.id())
                if _node is not None and not _node.itemVisibilityChecked():
                    return False
            except Exception:
                pass
            return True

        _cable_layers = [l for l in QgsProject.instance().mapLayers().values() if _is_cable_lyr(l)]
        _enc_canvas_crs = canvas.mapSettings().destinationCrs()
        self.log_message(f"  Snapping enclosures to {len(_cable_layers)} cable layer(s): "
                         f"{', '.join(l.name() for l in _cable_layers) or '(none found)'}")

        def _do_place(_pt):
            # claude:intent MUTATE — user asked (live): enclosure "just needs to snap on
            # the cables". Plan: place the manual enclosure on the snapped-to-cable point.
            # claude:approved-destructive — adds one point to the manual-enclosures memory
            # layer (the same write the original tool performed, now snapped).
            if sip.isdeleted(enc_layer):
                return
            feat = QgsFeature(enc_layer.fields())
            feat.setGeometry(QgsGeometry.fromPointXY(_EncPXY(_pt.x(), _pt.y())))
            enc_name = f"{enc_type}_{next_id[0]:03d}"
            feat.setAttributes([next_id[0], enc_name, enc_type])
            enc_layer.dataProvider().addFeatures([feat])
            enc_layer.updateExtents()
            enc_layer.triggerRepaint()
            self.log_message(f"  Placed: {enc_name} at ({_pt.x():.5f}, {_pt.y():.5f}) [snapped to cable]")
            next_id[0] += 1

        def _finish_placement():
            try:
                canvas.unsetMapTool(self._create_enclosure_tool)
            except Exception:
                pass
            self._btn_create_enclosure.setChecked(False)
            self._create_enclosure_tool = None
            self.log_message(f"Create Enclosure: placement finished. {next_id[0]-1} enclosure(s) placed.")
            if not sip.isdeleted(enc_layer):
                enc_layer.triggerRepaint()

        class _EncSnapTool(_EncMapTool):
            def __init__(self, cvs):
                super().__init__(cvs)
                self._cvs = cvs
                self._proj = QgsProject.instance()
                # We do NOT change the project/canvas snapping config. Instead _snap()
                # reads the global "Enable Snapping (S)" flag and only snaps when it is
                # ON — so the S button is a true whole-plugin on/off. When ON we snap via
                # the native engine (your targets) and, failing that, to the nearest
                # backbone cable so an enclosure still lands on a cable.
                # Geometric fallback index so it snaps to a cable even past the native radius.
                self._idx = []
                for _l in _cable_layers:
                    try:
                        _xf = QgsCoordinateTransform(_enc_canvas_crs, _l.crs(), QgsProject.instance())
                        _bxf = QgsCoordinateTransform(_l.crs(), _enc_canvas_crs, QgsProject.instance())
                        self._idx.append((_l, QgsSpatialIndex(_l.getFeatures()), _xf, _bxf))
                    except Exception:
                        pass
                self._mk = QgsVertexMarker(cvs)
                self._mk.setColor(QColor(255, 60, 0))
                self._mk.setIconType(QgsVertexMarker.ICON_CIRCLE)
                self._mk.setPenWidth(3)
                self._mk.setIconSize(16)
                self._mk.hide()
                self._snapped = None

            def _native_snap(self, map_pt):
                try:
                    _m = self._cvs.snappingUtils().snapToMap(map_pt)
                    if _m.isValid():
                        _p = _m.point()
                        return _EncPXY(_p.x(), _p.y())
                except Exception:
                    pass
                return None

            def _geom_snap(self, map_pt):
                best_pt, best_d = None, float('inf')
                for _l, _ix, _xf, _bxf in self._idx:
                    try:
                        _lp = _xf.transform(map_pt)
                    except Exception:
                        _lp = map_pt
                    try:
                        _near = _ix.nearestNeighbor(_lp, 3)
                    except Exception:
                        _near = []
                    for _fid in _near:
                        try:
                            _g = _l.getFeature(_fid).geometry()
                        except Exception:
                            continue
                        if not _g or _g.isEmpty():
                            continue
                        try:
                            _res = _g.closestSegmentWithContext(_lp)
                            _sq, _cp = _res[0], _res[1]
                        except Exception:
                            continue
                        if _sq < best_d:
                            best_d = _sq
                            try:
                                best_pt = _bxf.transform(_EncPXY(_cp))
                            except Exception:
                                best_pt = _EncPXY(_cp)
                return best_pt

            def _snap(self, map_pt):
                # Respect the global Enable Snapping (S) toggle: snapping OFF → no snap
                # anywhere (raw placement). Snapping ON → native engine first, then the
                # geometric nearest backbone cable so the enclosure still lands on a cable.
                try:
                    if not self._proj.snappingConfig().enabled():
                        return None
                except Exception:
                    pass
                return self._native_snap(map_pt) or self._geom_snap(map_pt)

            def canvasMoveEvent(self, e):
                # #100 (#65 class): bail if the layer OR the marker was torn down (a
                # reload while the tool is active still delivers canvas events to a dead
                # tool) — touching a deleted C/C++ object would crash.
                try:
                    if sip.isdeleted(enc_layer) or sip.isdeleted(self._mk):
                        return
                except Exception:
                    return
                _mp = self.toMapCoordinates(e.pos())
                _pt = self._snap(_mp)
                try:
                    if _pt is not None:
                        self._snapped = _pt
                        self._mk.setCenter(_pt)
                        self._mk.show()
                    else:
                        self._snapped = None
                        self._mk.hide()
                except RuntimeError:
                    pass

            def canvasReleaseEvent(self, e):
                from qgis.PyQt.QtCore import Qt as _Qt
                if sip.isdeleted(enc_layer):
                    _finish_placement()
                    return
                if e.button() == _Qt.MouseButton.RightButton:   # Qt6: fully-scoped enum (#110)
                    _finish_placement()
                    return
                _mp = self.toMapCoordinates(e.pos())
                _place_pt = self._snapped if self._snapped is not None else (self._snap(_mp) or _mp)
                _do_place(_place_pt)

            def deactivate(self):
                try:
                    self._mk.hide()
                    self._cvs.scene().removeItem(self._mk)
                except Exception:
                    pass
                super().deactivate()

        map_tool = _EncSnapTool(canvas)
        self._create_enclosure_tool = map_tool
        canvas.setMapTool(map_tool)
        self.log_message("  With Enable Snapping (S) ON, move over a cable — the enclosure "
                         "snaps onto it (red marker). With snapping OFF it places at the "
                         "click. Click to place, right-click when done.")

    def on_create_span_clicked(self):
        """Open span type chooser, then let user draw lines on the map."""
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                          QPushButton)
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY, QgsField, QgsProject, QgsLineSymbol, QgsSingleSymbolRenderer)
        from qgis.PyQt.QtCore import QMetaType
        from qgis.PyQt.QtGui import QColor

        # If button is unchecked, cancel any active drawing
        if not self._btn_create_span.isChecked():
            if self._create_span_tool:
                self.iface.mapCanvas().unsetMapTool(self._create_span_tool)
                self._create_span_tool = None
            self._create_span_type = None
            self.log_message("Create Span: drawing cancelled.")
            return

        # ── Step 1: Ask user what type of span ─────────────────────────────
        dlg = QDialog(self.iface.mainWindow())
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)   # don't leak hidden windows
        dlg.setWindowTitle("Create Span — Select Type")
        dlg.setMinimumWidth(340)
        layout = QVBoxLayout(dlg)

        lbl = QLabel("Select the span cable type to draw on the map:")
        lbl.setWordWrap(True)
        layout.addWidget(lbl)

        # Create buttons for each span type
        btn_feeder = QPushButton("🔴  Feeder")
        btn_feeder.setStyleSheet(
            "QPushButton { background-color: #8B0000; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #B22222; }"
        )
        
        btn_second = QPushButton("🟣  Second Feeder")
        btn_second.setStyleSheet(
            "QPushButton { background-color: #8B008B; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #BA55D3; }"
        )
        
        btn_third = QPushButton("🔵  Third Feeder")
        btn_third.setStyleSheet(
            "QPushButton { background-color: #00008B; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #0000FF; }"
        )
        
        btn_dist1 = QPushButton("🟢  Distribution 1")
        btn_dist1.setStyleSheet(
            "QPushButton { background-color: #008000; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #00FF00; color: #111; }"
        )

        btn_dist2 = QPushButton("🔷  Distribution 2")
        btn_dist2.setStyleSheet(
            "QPushButton { background-color: #008080; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #00FFFF; color: #111; }"
        )

        btn_dist3 = QPushButton("🟡  Distribution 3")
        btn_dist3.setStyleSheet(
            "QPushButton { background-color: #808000; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #FFFF00; color: #111; }"
        )
        
        btn_cancel = QPushButton("Cancel")

        layout.addWidget(btn_feeder)
        layout.addWidget(btn_second)
        layout.addWidget(btn_third)
        layout.addWidget(btn_dist1)
        layout.addWidget(btn_dist2)
        layout.addWidget(btn_dist3)
        layout.addSpacing(6)
        layout.addWidget(btn_cancel)

        chosen_type = [None]

        def _pick(span_type):
            chosen_type[0] = span_type
            dlg.accept()

        btn_feeder.clicked.connect(lambda: _pick('Feeder'))
        btn_second.clicked.connect(lambda: _pick('Second Feeder'))
        btn_third.clicked.connect(lambda: _pick('Third Feeder'))
        btn_dist1.clicked.connect(lambda: _pick('Distribution 1'))
        btn_dist2.clicked.connect(lambda: _pick('Distribution 2'))
        btn_dist3.clicked.connect(lambda: _pick('Distribution 3'))
        btn_cancel.clicked.connect(dlg.reject)

        if dlg.exec() != QDialog.DialogCode.Accepted or not chosen_type[0]:
            self._btn_create_span.setChecked(False)
            return

        span_type = chosen_type[0]
        self._create_span_type = span_type
        self.log_message(f"Create Span: type={span_type} — click on the map to draw vertices. Right-click to finish.")

        # ── Step 2: Activate map tool ────────────────────────────────────────
        canvas = self.iface.mapCanvas()
        crs = canvas.mapSettings().destinationCrs().authid()
        layer_name = f"Manual Spans ({span_type})"

        # Span type colors and cable type
        span_colors = {
            'Feeder': ('#FF0000', 'Feeder'),
            'Second Feeder': ('#FF00FF', 'Second Feeder'),
            'Third Feeder': ('#0000FF', 'Third Feeder'),
            'Distribution 1': ('#00FF00', 'Distribution'),
            'Distribution 2': ('#00FFFF', 'Distribution'),
            'Distribution 3': ('#FFFF00', 'Distribution'),
        }
        color_hex, cable_type = span_colors.get(span_type, ('#000000', 'Unknown'))

        # Get or create the span layer for this type
        span_layer = None
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name() == layer_name:
                span_layer = lyr
                break

        if span_layer is None:
            span_layer = QgsVectorLayer(f"LineString?crs={crs}", layer_name, "memory")
            provider = span_layer.dataProvider()
            provider.addAttributes([
                QgsField('span_id', QMetaType.Type.Int),
                QgsField('span_name', QMetaType.Type.QString),
                QgsField('span_type', QMetaType.Type.QString),
                QgsField('Cable Type', QMetaType.Type.QString),
                QgsField('length_m', QMetaType.Type.Double),  # Length in meters
            ])
            span_layer.updateFields()

            # Convert hex color to RGB
            r = int(color_hex[1:3], 16)
            g = int(color_hex[3:5], 16)
            b = int(color_hex[5:7], 16)

            symbol = QgsLineSymbol.createSimple({
                'line_color': f'{r},{g},{b}',
                'line_width': '1.86',
                'line_width_unit': 'mm',
                'line_style': 'solid',
            })
            span_layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            QgsProject.instance().addMapLayer(span_layer)
            self.log_message(f"  Created new layer: '{layer_name}'")

        # Ensure length_m field exists on any pre-existing layer
        if span_layer.fields().indexOf('length_m') < 0:
            span_layer.dataProvider().addAttributes([QgsField('length_m', QMetaType.Type.Double)])
            span_layer.updateFields()

        # Track next ID and current line vertices
        existing_ids = [f['span_id'] for f in span_layer.getFeatures() if f['span_id']]
        next_id = [max(existing_ids) + 1 if existing_ids else 1]
        vertices = [[]]  # list of vertex lists per line being drawn

        # ── Create rubber band for preview line trace ────────────────────────
        from qgis.gui import QgsRubberBand
        from qgis.core import QgsWkbTypes
        rubber_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.LineGeometry)
        # Convert hex color to bright RGB for visibility
        r = int(color_hex[1:3], 16)
        g = int(color_hex[3:5], 16)
        b = int(color_hex[5:7], 16)
        # Boost saturation for preview visibility
        preview_color = QColor(r, g, b, 200)  # 200 alpha for semi-transparency
        rubber_band.setColor(preview_color)
        rubber_band.setWidth(3)  # Thicker for visibility during drawing

        # Map click tool
        map_tool = QgsMapToolEmitPoint(canvas)

        def _on_map_click(point, button):
            from qgis.PyQt.QtCore import Qt as _Qt
            if button == _Qt.MouseButton.RightButton:   # Qt6: fully-scoped enum (#110)
                # Right-click to finish current line
                if vertices[-1]:
                    line_pts = [QgsPointXY(v.x(), v.y()) for v in vertices[-1]]
                    geom = QgsGeometry.fromPolylineXY(line_pts)
                    
                    # Calculate length in meters using QgsDistanceArea (handles geographic/projected CRS)
                    from qgis.core import QgsDistanceArea
                    da = QgsDistanceArea()
                    da.setSourceCrs(span_layer.crs(), QgsProject.instance().transformContext())
                    da.setEllipsoid(_safe_ellipsoid(QgsProject.instance(), span_layer.crs()))
                    line_length = round(da.measureLength(geom), 2)  # Meters, 2 decimal places
                    
                    feat = QgsFeature(span_layer.fields())
                    feat.setGeometry(geom)
                    span_name = f"{span_type.replace(' ', '_')}_{next_id[0]:03d}"
                    feat.setAttributes([next_id[0], span_name, span_type, cable_type, line_length])
                    span_layer.dataProvider().addFeatures([feat])
                    span_layer.updateExtents()
                    span_layer.triggerRepaint()
                    self.log_message(f"  Completed: {span_name} ({len(vertices[-1])} vertices, {line_length:.2f} m)")
                    next_id[0] += 1
                    vertices.append([])  # start fresh for next line
                    
                    # Clear rubber band for next line
                    rubber_band.reset(QgsWkbTypes.GeometryType.LineGeometry)
                else:
                    # No vertices on current line — just finish
                    rubber_band.reset()
                    canvas.unsetMapTool(map_tool)
                    self._btn_create_span.setChecked(False)
                    self._create_span_tool = None
                    self.log_message(f"Create Span: drawing finished. {next_id[0]-1} span(s) created.")
                    return
            else:
                # Left-click: add vertex (honour QGIS native snapping so span vertices
                # land on cables/poles/vertices when snapping is on — JJ).
                point = snap_point_to_project(canvas, point)
                vertices[-1].append(QgsPointXY(point.x(), point.y()))

                # Update rubber band with new point
                rubber_band.addPoint(QgsPointXY(point.x(), point.y()))

                self.log_message(f"  Vertex added: ({point.x():.2f}, {point.y():.2f})")

        map_tool.canvasClicked.connect(_on_map_click)
        self._create_span_tool = map_tool
        canvas.setMapTool(map_tool)
        self.log_message("  Click on the map to add vertices. Right-click to finish the current line.")

    def on_generate_aggregation_points_clicked(self):
        """Generate Enclosure points where 2+ Feeder/Second/Third Feeder cables converge (at any point, including mid-path)."""
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject, QgsField,
                                QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                                QgsVectorLayerSimpleLabeling)
        from qgis.PyQt.QtCore import QMetaType
        from qgis.PyQt.QtGui import QColor, QFont

        # ── 1. Get the Span layer ──────────────────────────────────────────────
        span_layer = self.comboBox_span_layer.currentLayer()
        if span_layer is None:
            self.log_message("ERROR: Please select a Span (Route) layer first.")
            return

        if span_layer.geometryType() != 1:   # 1 = Line
            self.log_message(f"ERROR: '{span_layer.name()}' is not a line layer.")
            return

        self.log_message("\n=== Generating Feeder Enclosure Points ===")
        self.log_message(f"Source layer: '{span_layer.name()}'")
        self.log_message(f"Feature count: {span_layer.featureCount()}")

        # ── 2. Identify feeder-class cables ────────────────────────────────────
        _span_field_names = [f.name() for f in span_layer.fields()]
        has_cable_type = 'Cable Type' in _span_field_names
        _has_name = 'Name' in _span_field_names   # hoisted: was rebuilt per feature
        feeder_cables = []

        for feat in span_layer.getFeatures():
            geom = feat.geometry()
            if geom is None or geom.isEmpty():
                continue

            # Filter to feeder-class cables
            cable_type_str = ''
            if has_cable_type:
                cable_type_str = str(feat['Cable Type'] or '').strip().lower()

            cable_lower = str(feat['Name'] or '').lower() if _has_name else ''
            is_feeder_class = (
                ('feeder' in cable_lower or 'second' in cable_lower or 'third' in cable_lower)
                and 'distribution' not in cable_lower
            ) or cable_type_str in ['feeder', 'second feeder', 'third feeder']

            if is_feeder_class:
                feat_id = feat.id()
                feeder_cables.append((feat_id, geom, feat))

        if not feeder_cables:
            self.log_message("⚠ No Feeder-class cables found.")
            return

        self.log_message(f"Found {len(feeder_cables)} feeder-class cables")

        # ── 3. Collect convergence points: Method 1 (vertex-based) ─────────────
        processed_locations = set()
        convergence_points = {}  # {rounded_key: {"count": N, "geoms": [list], "exact_pts": [list]}}

        for feat_id, geom, feat in feeder_cables:
            # Collect all vertices along the cable
            all_points = []
            if geom.wkbType() in [2, 1002]:  # LineString
                pts = geom.asPolyline()
            elif geom.wkbType() in [5, 1005]:  # MultiLineString
                pts = []
                for part in geom.asMultiPolyline():
                    pts.extend(part)
            else:
                continue

            for pt in pts:
                # Round for deduplication
                key = (round(pt.x(), 2), round(pt.y(), 2))
                if key not in processed_locations:
                    all_points.append((key, pt))
                    processed_locations.add(key)

            # Collect all unique points for this cable
            for rounded_key, exact_pt in all_points:
                if rounded_key not in convergence_points:
                    convergence_points[rounded_key] = {"count": 0, "geoms": [], "exact_pts": []}
                convergence_points[rounded_key]["count"] += 1
                convergence_points[rounded_key]["geoms"].append(feat_id)
                convergence_points[rounded_key]["exact_pts"].append(exact_pt)

        # ── 4. Method 2: Geometry intersection detection ────────────────────────
        for i, (feat_id_1, geom_1, _) in enumerate(feeder_cables):
            for feat_id_2, geom_2, _ in feeder_cables[i+1:]:
                if geom_1.intersects(geom_2):
                    # Use centroid as intersection point
                    int_geom = geom_1.intersection(geom_2)
                    if int_geom and not int_geom.isEmpty():
                        if int_geom.type() == 0:  # Point geometry
                            # Two cables can intersect at MULTIPLE points → MultiPoint;
                            # .asPoint() raises on a multipart, so take the first part.
                            pt = (int_geom.asMultiPoint()[0] if int_geom.isMultipart()
                                  else int_geom.asPoint())
                        elif int_geom.type() == 1:  # Line
                            pt = int_geom.centroid().asPoint()
                        else:
                            continue

                        key = (round(pt.x(), 2), round(pt.y(), 2))
                        if key not in processed_locations:
                            if key not in convergence_points:
                                convergence_points[key] = {"count": 0, "geoms": [], "exact_pts": []}
                            convergence_points[key]["count"] += 1
                            convergence_points[key]["geoms"].extend([feat_id_1, feat_id_2])
                            convergence_points[key]["exact_pts"].append(pt)
                            processed_locations.add(key)

        # ── 5. Filter: only points where 2+ cables meet ─────────────────────────
        enclosure_locations = {}
        for rounded_key, data in convergence_points.items():
            if len(set(data["geoms"])) >= 2:  # At least 2 distinct cables
                # Use the first exact point (they're all very close)
                exact_pt = data["exact_pts"][0]
                enclosure_locations[rounded_key] = exact_pt

        if not enclosure_locations:
            self.log_message("⚠ No convergence points found.")
            return

        self.log_message(f"Found {len(enclosure_locations)} convergence points")

        # ── 6. Create or find Enclosure layer ──────────────────────────────────
        enclosure_layer_name = "Feeder Enclosures"
        enclosure_layer = None

        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name() == enclosure_layer_name:
                enclosure_layer = lyr
                break

        if enclosure_layer is None:
            crs = span_layer.crs().authid()
            enclosure_layer = QgsVectorLayer(f"Point?crs={crs}", enclosure_layer_name, "memory")
            provider = enclosure_layer.dataProvider()
            provider.addAttributes([
                QgsField('enclosure_id', QMetaType.Type.Int),
                QgsField('enclosure_name', QMetaType.Type.QString),
                QgsField('converging_cables', QMetaType.Type.Int),
            ])
            enclosure_layer.updateFields()

            # Apply symbology - cyan/teal squares
            symbol = QgsMarkerSymbol.createSimple({
                'name': 'square',
                'color': '0,200,200,255',
                'outline_color': '0,0,0,255',
                'outline_width': '0.5',
                'size': '5',
            })
            enclosure_layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            # Labels
            lbl_settings = QgsPalLayerSettings()
            lbl_settings.fieldName = 'enclosure_name'
            lbl_settings.enabled = True
            fmt = QgsTextFormat()
            fmt.setFont(QFont("Arial", 7))
            fmt.setColor(QColor(0, 0, 0))
            buf = QgsTextBufferSettings()
            buf.setEnabled(True)
            buf.setSize(1.0)
            buf.setColor(QColor(255, 255, 255))
            fmt.setBuffer(buf)
            lbl_settings.setFormat(fmt)
            enclosure_layer.setLabeling(QgsVectorLayerSimpleLabeling(lbl_settings))
            enclosure_layer.setLabelsEnabled(True)

            QgsProject.instance().addMapLayer(enclosure_layer)
            self.log_message(f"  Created layer: '{enclosure_layer_name}'")

        # ── 7. Add features ────────────────────────────────────────────────────
        existing_ids = [f['enclosure_id'] for f in enclosure_layer.getFeatures() if f['enclosure_id']]
        next_id = max(existing_ids) + 1 if existing_ids else 1

        provider = enclosure_layer.dataProvider()
        features = []

        for rounded_key, exact_pt in enclosure_locations.items():
            feat = QgsFeature(enclosure_layer.fields())
            feat.setGeometry(QgsGeometry.fromPointXY(exact_pt))
            feat.setAttributes([
                next_id,
                f"Encl_{next_id:03d}",
                convergence_points[rounded_key]["count"],
            ])
            features.append(feat)
            next_id += 1

        provider.addFeatures(features)
        enclosure_layer.updateExtents()
        enclosure_layer.triggerRepaint()

        self.log_message(f"✓ Created {len(features)} enclosure point(s)")
        return   # ── canonical implementation ends here ──
        # Everything below to the end of this method (the old `agg_*`/`feeder_count`
        # block) is a SUPERSEDED DUPLICATE left by a refactor. It used to run a SECOND
        # time right after the block above (no return), creating duplicate enclosures.
        # Now unreachable. Slated for physical deletion (manifest 3a-bis).
        # ---------------------------------------------------------------------------


    def on_sum_span_distance_clicked(self):
        """Calculate total length of the selected Span layer and show a persistent result dialog."""
        from qgis.core import QgsUnitTypes
        from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton
        from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
        from qgis.PyQt.QtGui import QFont

        span_layer = self.comboBox_span_layer.currentLayer()
        if span_layer is None:
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.warning(None, "No Span Layer",
                                "Please select a Span (Route) layer first.")
            return

        if span_layer.geometryType() != 1:   # 1 = Line
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.warning(None, "Wrong Layer Type",
                                f"'{span_layer.name()}' is not a line layer.")
            return

        layer_name = span_layer.name()
        feature_count = span_layer.featureCount()

        # ── Worker thread ────────────────────────────────────────────────────
        class _Worker(QThread):
            finished = pyqtSignal(float, int)   # total_m, feature_count
            error    = pyqtSignal(str)

            def __init__(self, geoms, crs, tctx, ellipsoid):
                super().__init__()
                self._geoms = geoms        # pre-extracted on the main thread
                self._crs = crs
                self._tctx = tctx
                self._ellipsoid = ellipsoid

            def run(self):
                try:
                    da = QgsDistanceArea()
                    da.setSourceCrs(self._crs, self._tctx)
                    da.setEllipsoid(self._ellipsoid)
                    total = 0.0
                    count = 0
                    for geom in self._geoms:
                        total += da.measureLength(geom)
                        count += 1
                    # Convert to metres
                    total_m = da.convertLengthMeasurement(
                        total, QgsUnitTypes.DistanceUnit.DistanceMeters)
                    self.finished.emit(total_m, count)
                except Exception as exc:
                    self.error.emit(str(exc))

        # ── Progress / waiting dialog (non-blocking) ─────────────────────────
        wait_dlg = QDialog(None)
        wait_dlg.setWindowTitle("Calculating…")
        wait_dlg.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint | Qt.WindowType.CustomizeWindowHint)
        wait_dlg.setFixedWidth(300)
        wait_lay = QVBoxLayout(wait_dlg)
        wait_lbl = QLabel(
            f"<b>Summing span distances…</b><br>"
            f"Layer: <i>{layer_name}</i><br>"
            f"{feature_count} features")
        wait_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wait_lay.addWidget(wait_lbl)
        wait_dlg.show()
        QApplication.processEvents()

        # ── Result dialog builder ─────────────────────────────────────────────
        def _show_result(total_m, counted):
            from qgis.PyQt import sip as _sipw
            wait_dlg.close()   # always dismiss the orphan, even if the dock is gone
            if _sipw.isdeleted(self):
                return   # dock closed while the worker ran — don't touch dead widgets

            from qgis.PyQt.QtWidgets import (QFrame, QHBoxLayout, QDoubleSpinBox,
                                             QLabel as _QL)

            res_dlg = QDialog(None)
            res_dlg.setWindowTitle("Span Layer — Total Distance")
            res_dlg.setWindowFlags(
                Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
            res_dlg.setMinimumWidth(380)
            res_lay = QVBoxLayout(res_dlg)
            res_lay.setSpacing(10)
            res_lay.setContentsMargins(18, 18, 18, 18)

            title_lbl = QLabel("📏  Span Layer — Total Distance")
            title_fnt = QFont()
            title_fnt.setBold(True)
            title_fnt.setPointSize(11)
            title_lbl.setFont(title_fnt)
            title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            res_lay.addWidget(title_lbl)

            # ── Base distance display ─────────────────────────────────────
            km = total_m / 1000.0
            base_lbl = QLabel(
                f"<table cellspacing='6'>"
                f"<tr><td><b>Layer:</b></td><td>{layer_name}</td></tr>"
                f"<tr><td><b>Features measured:</b></td><td>{counted:,}</td></tr>"
                f"<tr><td><b>Raw total distance:</b></td>"
                f"<td><span style='font-size:12pt; color:#555;'>"
                f"<b>{total_m:,.1f} m</b></span></td></tr>"
                f"<tr><td></td>"
                f"<td><span style='font-size:9pt; color:#888;'>"
                f"({km:,.3f} km)</span></td></tr>"
                f"</table>")
            base_lbl.setAlignment(Qt.AlignmentFlag.AlignLeft)
            res_lay.addWidget(base_lbl)

            # ── Divider ───────────────────────────────────────────────────
            div = QFrame()
            div.setFrameShape(QFrame.Shape.HLine)
            div.setStyleSheet("color: #ccc;")
            res_lay.addWidget(div)

            # ── Slack / Sag % row ─────────────────────────────────────────
            pct_row = QHBoxLayout()
            pct_lbl = _QL("Slack & Sag allowance:")
            pct_lbl.setToolTip(
                "Extra cable percentage added for slack, sag, splices and\n"
                "vertical drops on HLD cable quantity estimations.")
            pct_spin = QDoubleSpinBox()
            pct_spin.setRange(0.0, 100.0)
            pct_spin.setDecimals(1)
            pct_spin.setSingleStep(0.5)
            pct_spin.setSuffix(" %")
            pct_spin.setValue(22.0)
            pct_spin.setFixedWidth(90)
            pct_spin.setToolTip("Default 22 % — edit as required")
            pct_row.addWidget(pct_lbl)
            pct_row.addStretch()
            pct_row.addWidget(pct_spin)
            res_lay.addLayout(pct_row)

            # ── Adjusted distance display (updates live) ──────────────────
            adj_lbl = QLabel()
            adj_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            adj_lbl.setStyleSheet(
                "background: #eaf4ea; border: 1px solid #a8d5a8; "
                "border-radius: 5px; padding: 8px;")
            res_lay.addWidget(adj_lbl)

            def _update_adjusted():
                pct = pct_spin.value()
                adj_m  = total_m * (1.0 + pct / 100.0)
                adj_km = adj_m / 1000.0
                extra_m = adj_m - total_m
                adj_lbl.setText(
                    f"<div style='text-align:center;'>"
                    f"<span style='font-size:9pt; color:#555;'>Adjusted total (+{pct:.1f}%)</span><br>"
                    f"<span style='font-size:14pt; color:#1a6b3c; font-weight:bold;'>"
                    f"{adj_m:,.1f} m</span>"
                    f"<span style='font-size:9pt; color:#555;'>  ({adj_km:,.3f} km)</span><br>"
                    f"<span style='font-size:8pt; color:#888;'>"
                    f"+{extra_m:,.1f} m slack/sag allowance</span>"
                    f"</div>")

            pct_spin.valueChanged.connect(_update_adjusted)
            _update_adjusted()   # populate on open

            # ── Close button ──────────────────────────────────────────────
            close_btn = QPushButton("Close")
            close_btn.setStyleSheet(
                "QPushButton { background-color: #2a5b8a; color: white; "
                "font-weight: bold; padding: 5px 20px; border-radius: 4px; }"
                "QPushButton:hover { background-color: #336fa5; }")
            close_btn.clicked.connect(res_dlg.accept)
            res_lay.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)

            res_dlg.exec()   # modal — stays open until user clicks Close

        def _show_error(msg):
            from qgis.PyQt import sip as _sipw
            wait_dlg.close()   # always dismiss the orphan, even if the dock is gone
            if _sipw.isdeleted(self):
                return
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.critical(None, "Error Calculating Span Distance",
                                 f"An error occurred:\n{msg}")

        # Extract geometries on the MAIN thread — QgsVectorLayer.getFeatures() is NOT
        # thread-safe; only the pure measureLength math runs in the worker.
        _crs = span_layer.crs()
        _tctx = QgsProject.instance().transformContext()
        _ellipsoid = QgsProject.instance().ellipsoid()
        _geoms = [QgsGeometry(f.geometry()) for f in span_layer.getFeatures()
                  if f.geometry() and not f.geometry().isEmpty()]
        worker = _Worker(_geoms, _crs, _tctx, _ellipsoid)
        worker.finished.connect(_show_result)
        worker.error.connect(_show_error)
        # Keep reference so GC doesn't destroy it
        self._span_dist_worker = worker
        worker.start()

    def on_sum_pole_numbers_clicked(self):
        """Count total poles across all Poles layers and show a persistent result dialog."""
        from qgis.core import QgsProject, QgsVectorLayer
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                         QPushButton, QMessageBox)
        from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
        from qgis.PyQt.QtGui import QFont

        # Find all poles layers (name starts with 'Poles_' and has pole_type field)
        pole_layers = []
        for lyr in QgsProject.instance().mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer):
                continue
            if lyr.geometryType() != 0:   # Point only
                continue
            ln = lyr.name().lower()
            fnames = [f.name() for f in lyr.fields()]
            if ln.startswith('poles_') and 'pole_type' in fnames:
                pole_layers.append(lyr)

        if not pole_layers:
            QMessageBox.warning(None, "No Poles Layer Found",
                                "No Poles layer was found in the project.\n"
                                "Run Generate Poles first.")
            return

        # ── Worker thread ──────────────────────────────────────────────────
        class _PoleWorker(QThread):
            # emits list of (layer_name, count) and grand total
            finished = pyqtSignal(list, int)
            error    = pyqtSignal(str)

            def __init__(self, results):
                super().__init__()
                self._results = results   # [(name, count)] read on the main thread

            def run(self):
                try:
                    total = sum(c for _, c in self._results)
                    self.finished.emit(self._results, total)
                except Exception as exc:
                    self.error.emit(str(exc))

        # ── Waiting dialog ─────────────────────────────────────────────────
        wait_dlg = QDialog(None)
        wait_dlg.setWindowTitle("Counting…")
        wait_dlg.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint | Qt.WindowType.CustomizeWindowHint)
        wait_dlg.setFixedWidth(280)
        wait_lay = QVBoxLayout(wait_dlg)
        wait_lbl = QLabel(
            f"<b>Counting poles…</b><br>"
            f"{len(pole_layers)} Poles layer(s) found")
        wait_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wait_lay.addWidget(wait_lbl)
        wait_dlg.show()
        QApplication.processEvents()

        def _show_result(results, total):
            from qgis.PyQt import sip as _sipw
            wait_dlg.close()   # always dismiss the orphan, even if the dock is gone
            if _sipw.isdeleted(self):
                return

            res_dlg = QDialog(None)
            res_dlg.setWindowTitle("Poles — Total Count")
            res_dlg.setWindowFlags(
                Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
            res_dlg.setMinimumWidth(340)
            res_lay = QVBoxLayout(res_dlg)
            res_lay.setSpacing(10)
            res_lay.setContentsMargins(18, 18, 18, 18)

            title_lbl = QLabel("🔢  Poles — Total Count")
            title_fnt = QFont()
            title_fnt.setBold(True)
            title_fnt.setPointSize(11)
            title_lbl.setFont(title_fnt)
            title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            res_lay.addWidget(title_lbl)

            # Build per-layer rows
            rows_html = "".join(
                f"<tr><td>&nbsp;&nbsp;{name}:</td>"
                f"<td align='right'><b>{cnt:,}</b></td></tr>"
                for name, cnt in results)
            info_lbl = QLabel(
                f"<table cellspacing='6'>"
                f"{rows_html}"
                f"<tr><td colspan='2'><hr/></td></tr>"
                f"<tr><td><b>Total Poles:</b></td>"
                f"<td align='right'><span style='font-size:13pt; color:#7a4a1e;'>"
                f"<b>{total:,}</b></span></td></tr>"
                f"</table>")
            info_lbl.setAlignment(Qt.AlignmentFlag.AlignLeft)
            res_lay.addWidget(info_lbl)

            close_btn = QPushButton("Close")
            close_btn.setStyleSheet(
                "QPushButton { background-color: #7a4a1e; color: white; "
                "font-weight: bold; padding: 5px 20px; border-radius: 4px; }"
                "QPushButton:hover { background-color: #9a5e28; }")
            close_btn.clicked.connect(res_dlg.accept)
            res_lay.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)

            res_dlg.exec()   # modal — stays open until user clicks Close

        def _show_error(msg):
            from qgis.PyQt import sip as _sipw
            wait_dlg.close()   # always dismiss the orphan, even if the dock is gone
            if _sipw.isdeleted(self):
                return
            QMessageBox.critical(None, "Error Counting Poles",
                                 f"An error occurred:\n{msg}")

        # featureCount()/name() read on the MAIN thread (provider access is not
        # thread-safe); the worker only sums the pre-computed counts.
        _pole_results = [(lyr.name(), lyr.featureCount()) for lyr in pole_layers]
        worker = _PoleWorker(_pole_results)
        worker.finished.connect(_show_result)
        worker.error.connect(_show_error)
        self._pole_count_worker = worker
        worker.start()

    # ── Delete + Renumber ────────────────────────────────────────────────────
    def on_delete_renumber_clicked(self):
        """Remove PONs and close the numbering gaps they leave behind.

        The dock stays thin: everything lives in fibre_automation/renumber/.
        """
        from qgis.PyQt import sip
        from qgis.PyQt.QtWidgets import QMessageBox
        from qgis.core import QgsProject

        if sip.isdeleted(self):
            return
        try:
            try:
                from ..fibre_automation.renumber import dialog as _rn_dialog
            except ImportError:
                from fibre_automation.renumber import dialog as _rn_dialog
        except Exception as exc:   # pragma: no cover - import guard
            QMessageBox.critical(None, "Delete + Renumber",
                                 f"Could not load the renumber module:\n{exc}")
            return
        try:
            _rn_dialog.open_dialog(parent=None, project=QgsProject.instance())
        except Exception as exc:
            if not sip.isdeleted(self):
                QMessageBox.critical(None, "Delete + Renumber",
                                     f"An error occurred:\n{exc}")

    # ── Tag by PON / Phase ───────────────────────────────────────────────────
    def on_zone_tag_clicked(self):
        """Add a 'which PON / Phase am I in?' column to the chosen layers.

        The dock stays thin: everything lives in fibre_automation/tagging/.
        """
        from qgis.PyQt import sip
        from qgis.PyQt.QtWidgets import QMessageBox
        from qgis.core import QgsProject

        if sip.isdeleted(self):
            return
        try:
            try:
                from ..fibre_automation.tagging import zone_tag_dialog
            except ImportError:
                from fibre_automation.tagging import zone_tag_dialog
        except Exception as exc:   # pragma: no cover - import guard
            QMessageBox.critical(None, "Tag by PON / Phase",
                                 f"Could not load the tagging module:\n{exc}")
            return

        try:
            zone_tag_dialog.open_dialog(parent=None, project=QgsProject.instance())
        except Exception as exc:
            if not sip.isdeleted(self):
                QMessageBox.critical(None, "Tag by PON / Phase",
                                     f"An error occurred:\n{exc}")

    # ── BOQ Take-off ─────────────────────────────────────────────────────────
    def on_boq_takeoff_clicked(self):
        """Geometry quantity take-off (per PON + per Zone) → tabbed dialog + export."""
        from qgis.PyQt import sip
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtGui import QFont
        from qgis.PyQt.QtWidgets import (QApplication, QDialog, QVBoxLayout,
                                         QHBoxLayout, QLabel, QPushButton,
                                         QTabWidget, QFrame)
        from qgis.core import QgsProject
        try:
            from .. import theme_safe
        except ImportError:
            from FiberNetworkAutomation import theme_safe

        if sip.isdeleted(self):
            return
        try:
            try:
                from ..fibre_automation.boq import takeoff as _takeoff
            except ImportError:
                from fibre_automation.boq import takeoff as _takeoff
        except Exception as exc:   # pragma: no cover - import guard
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.critical(None, "BOQ Take-off",
                                 f"Could not load the take-off module:\n{exc}")
            return

        # lightweight "computing" cue — run_takeoff iterates all features on the
        # main thread (provider access must be main-thread), so no worker here.
        wait = QDialog(None)
        wait.setWindowTitle("BOQ Take-off")
        wait.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.CustomizeWindowHint |
                            Qt.WindowType.WindowTitleHint)
        _wl = QVBoxLayout(wait)
        _wl.setContentsMargins(26, 22, 26, 22)
        _wm = QLabel("⏳  <b>Computing geometry take-off…</b><br>"
                     "<span style='font-size:9pt;'>reading every layer, grouping "
                     "per PON &amp; Zone</span>")
        _wm.setAlignment(Qt.AlignmentFlag.AlignCenter)
        _wl.addWidget(_wm)
        wait.show()
        QApplication.processEvents()

        try:
            res = _takeoff.run_takeoff(QgsProject.instance())
        except Exception as exc:
            wait.close()
            if not sip.isdeleted(self):
                from qgis.PyQt.QtWidgets import QMessageBox
                QMessageBox.critical(None, "BOQ Take-off",
                                     f"An error occurred:\n{exc}")
            return
        wait.close()
        if sip.isdeleted(self):
            return

        c = theme_safe.colors(self)
        cols = self._boq_active_cols(res, _takeoff)

        dlg = QDialog(None)
        dlg.setWindowTitle(f"BOQ Take-off — {res.project}")
        dlg.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
            Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint |
            Qt.WindowType.WindowMaximizeButtonHint)
        dlg.setMinimumSize(860, 620)
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(10)

        # ── header (title + subtitle) ──
        title = QLabel("🧾  BOQ Take-off")
        tf = QFont()
        tf.setBold(True)
        tf.setPointSize(14)
        title.setFont(tf)
        title.setStyleSheet(f"color:{c['accent']};")
        lay.addWidget(title)
        pon_n = len([g for g in res.pon_groups if g != "(ungrouped)"])
        zone_n = len([g for g in res.zone_groups if g != "(ungrouped)"])
        sub = QLabel(f"{res.project}  ·  {pon_n} PON  ·  {zone_n} Zones  ·  "
                     f"read-only, nothing in the project is changed")
        sub.setStyleSheet(f"color:{c['muted']};font-size:9pt;")
        lay.addWidget(sub)

        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet(f"color:{c['muted']};")
        lay.addWidget(line)

        # ── tabs ──
        tabs = QTabWidget()
        tabs.addTab(self._boq_summary_tab(res, cols, c), "📊  Summary")
        if cols:
            tabs.addTab(self._boq_group_tab(res, cols, res.pon_groups,
                        res.per_pon, "PON", c), "🔢  Per PON")
            tabs.addTab(self._boq_group_tab(res, cols, res.zone_groups,
                        res.per_zone, "Zone", c), "🗺  Per PON")
        if res.pole_by_size or res.pole_by_length:
            tabs.addTab(self._boq_poles_tab(res, c), "🪵  Poles")
        tabs.addTab(self._boq_layers_tab(res, c), "🗂  Layers")
        lay.addWidget(tabs, 1)

        # ── buttons ──
        btn_row = QHBoxLayout()
        export_btn = QPushButton("⬇  Export to Excel / CSV")
        export_btn.setStyleSheet(
            "QPushButton { background-color: #1a6b3c; color: white; font-weight: bold; "
            "padding: 7px 18px; border-radius: 5px; }"
            "QPushButton:hover { background-color: #238a4f; }"
            "QPushButton:pressed { background-color: #145230; }")
        export_btn.clicked.connect(lambda: self._boq_export(res))
        close_btn = QPushButton("Close")
        close_btn.setStyleSheet(
            "QPushButton { background-color: #6b5320; color: white; font-weight: bold; "
            "padding: 7px 22px; border-radius: 5px; }"
            "QPushButton:hover { background-color: #8a6c2a; }")
        close_btn.clicked.connect(dlg.accept)
        btn_row.addWidget(export_btn)
        btn_row.addStretch(1)
        btn_row.addWidget(close_btn)
        lay.addLayout(btn_row)

        dlg.exec()

    _BOQ_ROW_CAP = 400   # cap on-screen group rows; full data always in the export

    def _boq_fmt(self, key, val):
        try:
            if key.endswith("_m"):
                return f"{float(val):,.1f}"
            return f"{int(val):,}"
        except (TypeError, ValueError):
            return str(val)

    def _boq_active_cols(self, res, takeoff):
        return [(k, lbl) for k, lbl in takeoff.METRIC_COLUMNS if res.totals.get(k)]

    # ── tab builders ─────────────────────────────────────────────────────────
    def _boq_tile(self, number, label, c):
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtGui import QFont
        from qgis.PyQt.QtWidgets import QFrame, QVBoxLayout, QLabel
        f = QFrame()
        f.setFrameShape(QFrame.Shape.StyledPanel)
        f.setStyleSheet(f"QFrame {{ border:1px solid {c['muted']}; border-radius:8px; }}")
        v = QVBoxLayout(f)
        v.setContentsMargins(14, 10, 14, 10)
        v.setSpacing(1)
        n = QLabel(number)
        nf = QFont()
        nf.setBold(True)
        nf.setPointSize(19)
        n.setFont(nf)
        n.setStyleSheet(f"color:{c['accent']}; border:none;")
        n.setAlignment(Qt.AlignmentFlag.AlignLeft)
        lb = QLabel(label)
        lb.setStyleSheet(f"color:{c['muted']}; border:none; font-size:9pt;")
        v.addWidget(n)
        v.addWidget(lb)
        return f

    def _boq_summary_tab(self, res, cols, c):
        from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QGridLayout, QLabel,
                                         QScrollArea)
        w = QWidget()
        outer = QVBoxLayout(w)
        outer.setContentsMargins(6, 10, 6, 6)
        outer.setSpacing(12)

        if not cols:
            msg = QLabel("No countable or measurable features were found in this "
                         "project.")
            msg.setStyleSheet(f"color:{c['warn']};")
            outer.addWidget(msg)
            outer.addStretch(1)
            return w

        t = res.totals
        cable_km = sum(t.get(k, 0) for k in
                       ("primary_m", "secondary_m", "distribution_m",
                        "drop_m", "feeder_m")) / 1000.0
        hardware = sum(t.get(k, 0) for k in ("hooks", "tangents", "deadends"))
        tiles = [
            (f"{int(t.get('poles', 0)):,}", "Poles"),
            (f"{int(t.get('ont', 0)):,}", "ONTs"),
            (f"{cable_km:,.1f}", "Cable (km)"),
            (f"{int(hardware):,}", "Pole hardware"),
            (f"{int(t.get('deadends', 0)):,}", "Dead-ends"),
            (f"{t.get('spare_drop_m', 0):,.0f}", "Spare drop (m)"),
        ]
        grid = QGridLayout()
        grid.setSpacing(10)
        for i, (num, lbl) in enumerate(tiles):
            grid.addWidget(self._boq_tile(num, lbl, c), i // 3, i % 3)
        outer.addLayout(grid)

        # notes
        if res.notes:
            head = QLabel("Notes")
            hf = head.font()
            hf.setBold(True)
            head.setFont(hf)
            outer.addWidget(head)
            note_html = "<ul style='margin-left:-18px;'>" + "".join(
                f"<li style='margin-bottom:4px;'>{n}</li>" for n in res.notes) + "</ul>"
            notes = QLabel(note_html)
            notes.setWordWrap(True)
            notes.setStyleSheet(f"color:{c['muted']};")
            sa = QScrollArea()
            sa.setWidgetResizable(True)
            sa.setWidget(notes)
            outer.addWidget(sa, 1)
        else:
            outer.addStretch(1)
        return w

    def _boq_group_tab(self, res, cols, groups, bucket, kind, c):
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QLabel, QTableWidget,
                                         QTableWidgetItem, QAbstractItemView)
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(4, 8, 4, 4)
        v.setSpacing(6)

        # total strip (stays visible; the table below is pure sortable per-group data)
        tot = "  ·  ".join(f"{lbl} <b>{self._boq_fmt(k, res.totals.get(k, 0))}</b>"
                           for k, lbl in cols)
        strip = QLabel(f"TOTAL —  {tot}")
        strip.setWordWrap(True)
        strip.setStyleSheet(f"color:{c['ink']}; padding:2px 2px 4px 2px;")
        v.addWidget(strip)

        headers = [kind] + [lbl for _, lbl in cols]
        tbl = QTableWidget()
        tbl.setColumnCount(len(headers))
        tbl.setHorizontalHeaderLabels(headers)
        tbl.verticalHeader().setVisible(False)
        tbl.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        tbl.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        tbl.setAlternatingRowColors(True)
        tbl.setShowGrid(False)
        tbl.horizontalHeader().setStretchLastSection(True)

        shown = groups[: self._BOQ_ROW_CAP]
        tbl.setRowCount(len(shown))
        for r, g in enumerate(shown):
            row = bucket.get(g, {})
            gi = QTableWidgetItem(str(g))
            if g == "(ungrouped)":
                gi.setForeground(_boq_qcolor(c["warn"]))
            tbl.setItem(r, 0, gi)
            for ci, (k, _) in enumerate(cols, start=1):
                val = row.get(k, 0)
                it = _BoqNumItem(self._boq_fmt(k, val))
                it.setData(Qt.ItemDataRole.UserRole, float(val) if val else 0.0)
                it.setTextAlignment(Qt.AlignmentFlag.AlignRight |
                                    Qt.AlignmentFlag.AlignVCenter)
                tbl.setItem(r, ci, it)
        tbl.setSortingEnabled(True)
        tbl.resizeColumnsToContents()
        v.addWidget(tbl, 1)

        if len(groups) > len(shown):
            more = QLabel(f"…(+{len(groups) - len(shown)} more {kind} rows — full "
                          f"detail in the export)")
            more.setStyleSheet(f"color:{c['warn']}; font-size:9pt;")
            v.addWidget(more)
        return w

    def _boq_poles_tab(self, res, c):
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                                         QTableWidget, QTableWidgetItem,
                                         QAbstractItemView)
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(4, 8, 4, 4)
        h.setSpacing(14)

        def mini(headtext, data):
            col = QWidget()
            cv = QVBoxLayout(col)
            cv.setContentsMargins(0, 0, 0, 0)
            cv.setSpacing(4)
            lbl = QLabel(headtext)
            lf = lbl.font()
            lf.setBold(True)
            lbl.setFont(lf)
            cv.addWidget(lbl)
            t = QTableWidget()
            t.setColumnCount(2)
            t.setHorizontalHeaderLabels(["Band", "Count"])
            t.verticalHeader().setVisible(False)
            t.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
            t.setAlternatingRowColors(True)
            t.setShowGrid(False)
            t.horizontalHeader().setStretchLastSection(True)
            items = sorted(data.items())
            t.setRowCount(len(items))
            for r, (b, cnt) in enumerate(items):
                t.setItem(r, 0, QTableWidgetItem(str(b)))
                it = _BoqNumItem(f"{cnt:,}")
                it.setData(Qt.ItemDataRole.UserRole, float(cnt))
                it.setTextAlignment(Qt.AlignmentFlag.AlignRight |
                                    Qt.AlignmentFlag.AlignVCenter)
                t.setItem(r, 1, it)
            t.setSortingEnabled(True)
            t.resizeColumnsToContents()
            cv.addWidget(t, 1)
            return col

        if res.pole_by_size:
            h.addWidget(mini("Poles by size (thickness)", res.pole_by_size), 1)
        if res.pole_by_length:
            h.addWidget(mini("Poles by length (height)", res.pole_by_length), 1)
        return w

    def _boq_layers_tab(self, res, c):
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QLabel, QTableWidget,
                                         QTableWidgetItem, QAbstractItemView,
                                         QHeaderView)
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(4, 8, 4, 4)
        v.setSpacing(6)
        hint = QLabel("Every layer and its feature count. ✓ = included in the "
                      "per-PON / per-Zone rollup (canonical); blank = decoy / "
                      "non-v1 layer, shown for reference only.")
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color:{c['muted']}; font-size:9pt;")
        v.addWidget(hint)

        tbl = QTableWidget()
        tbl.setColumnCount(4)
        tbl.setHorizontalHeaderLabels(["Layer", "Role", "In rollup", "Features"])
        tbl.verticalHeader().setVisible(False)
        tbl.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        tbl.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        tbl.setAlternatingRowColors(True)
        tbl.setShowGrid(False)
        rows = res.layer_counts
        tbl.setRowCount(len(rows))
        for r, lc in enumerate(rows):
            tbl.setItem(r, 0, QTableWidgetItem(str(lc["layer"])))
            tbl.setItem(r, 1, QTableWidgetItem(str(lc["role"])))
            chk = QTableWidgetItem("✓" if lc.get("in_rollup") else "")
            chk.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            if lc.get("in_rollup"):
                chk.setForeground(_boq_qcolor(c["ok"]))
            tbl.setItem(r, 2, chk)
            it = _BoqNumItem(f"{lc['count']:,}")
            it.setData(Qt.ItemDataRole.UserRole, float(lc["count"]))
            it.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            tbl.setItem(r, 3, it)
        tbl.setSortingEnabled(True)
        tbl.resizeColumnsToContents()
        tbl.horizontalHeader().setStretchLastSection(False)
        tbl.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        v.addWidget(tbl, 1)
        return w

    def _boq_export(self, res):
        """Write the take-off to an .xlsx (multi-sheet) — CSV fallback if openpyxl absent."""
        from qgis.PyQt import sip
        from qgis.PyQt.QtWidgets import QFileDialog, QMessageBox
        from qgis.core import QgsProject
        import os
        try:
            from ..fibre_automation.boq import takeoff as _takeoff
        except ImportError:
            from fibre_automation.boq import takeoff as _takeoff

        base = (res.project or "project").replace(" ", "_")
        home = QgsProject.instance().homePath() or os.path.expanduser("~")
        default = os.path.join(home, f"BOQ_Takeoff_{base}.xlsx")
        path, _ = QFileDialog.getSaveFileName(
            None, "Export BOQ Take-off", default,
            "Excel workbook (*.xlsx);;CSV file (*.csv)")
        if not path:
            return
        cols = self._boq_active_cols(res, _takeoff)
        try:
            if path.lower().endswith(".csv"):
                self._boq_write_csv(res, cols, path)
            else:
                self._boq_write_xlsx(res, cols, path)
        except Exception as exc:
            if not sip.isdeleted(self):
                QMessageBox.critical(None, "BOQ Export", f"Export failed:\n{exc}")
            return
        if not sip.isdeleted(self):
            QMessageBox.information(None, "BOQ Export", f"Saved:\n{path}")

    def _boq_write_csv(self, res, cols, path):
        import csv
        with open(path, "w", newline="", encoding="utf-8-sig") as fh:
            w = csv.writer(fh)
            for kind, groups, bucket in (("PON", res.pon_groups, res.per_pon),
                                         ("Zone", res.zone_groups, res.per_zone)):
                w.writerow([kind] + [lbl for _, lbl in cols])
                for g in groups:
                    row = bucket.get(g, {})
                    w.writerow([g] + [row.get(k, 0) for k, _ in cols])
                w.writerow(["TOTAL"] + [res.totals.get(k, 0) for k, _ in cols])
                w.writerow([])

    def _boq_write_xlsx(self, res, cols, path):
        from openpyxl import Workbook
        from openpyxl.styles import Font
        wb = Workbook()
        bold = Font(bold=True)

        def group_sheet(ws, kind, groups, bucket):
            ws.append([kind] + [lbl for _, lbl in cols])
            for c in ws[1]:
                c.font = bold
            for g in groups:
                row = bucket.get(g, {})
                ws.append([g] + [row.get(k, 0) for k, _ in cols])
            trow = ["TOTAL"] + [res.totals.get(k, 0) for k, _ in cols]
            ws.append(trow)
            for c in ws[ws.max_row]:
                c.font = bold

        ws1 = wb.active
        ws1.title = "Per PON"
        group_sheet(ws1, "PON", res.pon_groups, res.per_pon)
        group_sheet(wb.create_sheet("Per Zone"), "Zone", res.zone_groups, res.per_zone)

        wsp = wb.create_sheet("Poles")
        wsp.append(["Thickness", "Count"])
        for b, c in sorted(res.pole_by_size.items()):
            wsp.append([b, c])
        wsp.append([])
        wsp.append(["Length", "Count"])
        for b, c in sorted(res.pole_by_length.items()):
            wsp.append([b, c])

        wsl = wb.create_sheet("Layers")
        wsl.append(["Layer", "Role", "Features"])
        for lc in res.layer_counts:
            wsl.append([lc["layer"], lc["role"], lc["count"]])

        if res.notes:
            wsn = wb.create_sheet("Notes")
            for n in res.notes:
                wsn.append([n])
        wb.save(path)

    def on_sum_demand_points_clicked(self):
        """Count total demand points in the Demand Points layer and show a persistent result dialog."""
        from qgis.PyQt import sip
        from qgis.core import QgsProject, QgsVectorLayer
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                         QPushButton, QMessageBox)
        from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
        from qgis.PyQt.QtGui import QFont

        # Resolve demand points layer — prefer stored reference, then search by name
        dp_layer = None
        try:
            if self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                dp_layer = self.demand_points_layer
        except Exception:
            pass

        if not dp_layer:
            for lyr in QgsProject.instance().mapLayers().values():
                if not isinstance(lyr, QgsVectorLayer):
                    continue
                if lyr.geometryType() != 0:   # Point only
                    continue
                ln = lyr.name().lower()
                if 'demand points' in ln or 'demand_points' in ln:
                    dp_layer = lyr
                    break

        if not dp_layer:
            QMessageBox.warning(None, "No Demand Points Layer Found",
                                "No Demand Points layer was found in the project.\n"
                                "Please generate demand points first.")
            return

        # ── Worker thread ──────────────────────────────────────────────────
        class _DPWorker(QThread):
            finished = pyqtSignal(str, int)
            error    = pyqtSignal(str)

            def __init__(self, name, count):
                super().__init__()
                self._name = name        # read on the main thread
                self._count = count

            def run(self):
                try:
                    self.finished.emit(self._name, self._count)
                except Exception as exc:
                    self.error.emit(str(exc))

        # ── Waiting dialog ─────────────────────────────────────────────────
        wait_dlg = QDialog(None)
        wait_dlg.setWindowTitle("Counting…")
        wait_dlg.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint | Qt.WindowType.CustomizeWindowHint)
        wait_dlg.setFixedWidth(280)
        wait_lay = QVBoxLayout(wait_dlg)
        wait_lbl = QLabel(f"<b>Counting demand points…</b><br>{dp_layer.name()}")
        wait_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wait_lay.addWidget(wait_lbl)
        wait_dlg.show()
        QApplication.processEvents()

        def _show_result(layer_name, total):
            wait_dlg.close()   # always dismiss the orphan, even if the dock is gone
            if sip.isdeleted(self):
                return

            res_dlg = QDialog(None)
            res_dlg.setWindowTitle("Demand Points — Total Count")
            res_dlg.setWindowFlags(
                Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
            res_dlg.setMinimumWidth(340)
            res_lay = QVBoxLayout(res_dlg)
            res_lay.setSpacing(10)
            res_lay.setContentsMargins(18, 18, 18, 18)

            title_lbl = QLabel("🏠  Demand Points — Total Count")
            title_fnt = QFont()
            title_fnt.setBold(True)
            title_fnt.setPointSize(11)
            title_lbl.setFont(title_fnt)
            title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            res_lay.addWidget(title_lbl)

            info_lbl = QLabel(
                f"<table cellspacing='6'>"
                f"<tr><td>Layer:</td><td><b>{layer_name}</b></td></tr>"
                f"<tr><td colspan='2'><hr/></td></tr>"
                f"<tr><td><b>Total Demand Points:</b></td>"
                f"<td align='right'><span style='font-size:13pt; color:#1a5276;'>"
                f"<b>{total:,}</b></span></td></tr>"
                f"</table>")
            info_lbl.setAlignment(Qt.AlignmentFlag.AlignLeft)
            res_lay.addWidget(info_lbl)

            close_btn = QPushButton("Close")
            close_btn.setStyleSheet(
                "QPushButton { background-color: #1a5276; color: white; "
                "font-weight: bold; padding: 5px 20px; border-radius: 4px; }"
                "QPushButton:hover { background-color: #2471a3; }")
            close_btn.clicked.connect(res_dlg.accept)
            res_lay.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)

            res_dlg.exec()   # stays open until user clicks Close

        def _show_error(msg):
            wait_dlg.close()   # always dismiss the orphan, even if the dock is gone
            if sip.isdeleted(self):
                return
            QMessageBox.critical(None, "Error Counting Demand Points",
                                 f"An error occurred:\n{msg}")

        # featureCount()/name() read on the MAIN thread (provider access is not
        # thread-safe); the worker just relays the pre-read values.
        _dp_name, _dp_count = dp_layer.name(), dp_layer.featureCount()
        worker = _DPWorker(_dp_name, _dp_count)
        worker.finished.connect(_show_result)
        worker.error.connect(_show_error)
        self._dp_count_worker = worker
        worker.start()

    def on_auto_sum_clicked(self):
        """Run Span Distance + Pole Count + Demand Count in one thread and show combined result."""
        from qgis.PyQt import sip
        from qgis.core import (QgsProject, QgsVectorLayer,
                               QgsUnitTypes)
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                         QPushButton, QMessageBox)
        from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
        from qgis.PyQt.QtGui import QFont

        # ── Resolve span layer ────────────────────────────────────────────
        span_layer = self.comboBox_span_layer.currentLayer()
        span_ok = span_layer is not None and span_layer.geometryType() == 1

        # ── Resolve pole layers ───────────────────────────────────────────
        pole_layers = []
        for lyr in QgsProject.instance().mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer):
                continue
            if lyr.geometryType() != 0:
                continue
            ln = lyr.name().lower()
            fnames = [f.name() for f in lyr.fields()]
            if ln.startswith('poles_') and 'pole_type' in fnames:
                pole_layers.append(lyr)

        # ── Resolve demand points layer ───────────────────────────────────
        dp_layer = None
        try:
            if self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                dp_layer = self.demand_points_layer
        except Exception:
            pass
        if not dp_layer:
            for lyr in QgsProject.instance().mapLayers().values():
                if not isinstance(lyr, QgsVectorLayer):
                    continue
                if lyr.geometryType() != 0:
                    continue
                ln = lyr.name().lower()
                if 'demand points' in ln or 'demand_points' in ln:
                    dp_layer = lyr
                    break

        if not span_ok and not pole_layers and not dp_layer:
            QMessageBox.warning(None, "AutoSum",
                                "No Span layer, Poles layers, or Demand Points layer found.\n"
                                "Please generate network layers first.")
            return

        # ── Single worker thread ──────────────────────────────────────────
        class _AutoSumWorker(QThread):
            # span_m, span_name, span_feat_count, pole_results, pole_total, dp_name, dp_count
            finished = pyqtSignal(float, str, int, list, int, str, int)
            error    = pyqtSignal(str)

            def __init__(self, span_geoms, crs, tctx, ellipsoid, span_name,
                         pole_results, dp_name, dp_count):
                super().__init__()
                # everything below is plain data read on the MAIN thread
                self._span_geoms = span_geoms
                self._crs = crs
                self._tctx = tctx
                self._ellipsoid = ellipsoid
                self._span_name = span_name
                self._pole_results = pole_results
                self._dp_name = dp_name
                self._dp_count = dp_count

            def run(self):
                try:
                    # Span distance (pure math over pre-extracted geometries)
                    span_m, span_cnt = 0.0, 0
                    if self._span_geoms is not None:
                        da = QgsDistanceArea()
                        da.setSourceCrs(self._crs, self._tctx)
                        da.setEllipsoid(self._ellipsoid)
                        for geom in self._span_geoms:
                            span_m += da.measureLength(geom)
                            span_cnt += 1
                        span_m = da.convertLengthMeasurement(
                            span_m, QgsUnitTypes.DistanceUnit.DistanceMeters)

                    pole_total = sum(c for _, c in self._pole_results)

                    self.finished.emit(
                        span_m, self._span_name, span_cnt,
                        self._pole_results, pole_total,
                        self._dp_name, self._dp_count)
                except Exception as exc:
                    self.error.emit(str(exc))

        # ── Waiting dialog ────────────────────────────────────────────────
        wait_dlg = QDialog(None)
        wait_dlg.setWindowTitle("AutoSum — Calculating…")
        wait_dlg.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint | Qt.WindowType.CustomizeWindowHint)
        wait_dlg.setFixedWidth(320)
        wait_lay = QVBoxLayout(wait_dlg)
        wait_lbl = QLabel(
            "<b>AutoSum running…</b><br>"
            "Calculating Span Distance, Poles &amp; Demand Points.")
        wait_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wait_lay.addWidget(wait_lbl)
        wait_dlg.show()
        QApplication.processEvents()

        # ── Result dialog ─────────────────────────────────────────────────
        def _show_result(span_m, span_name, span_cnt,
                         pole_results, pole_total, dp_name, dp_count):
            wait_dlg.close()   # always dismiss the orphan, even if the dock is gone
            if sip.isdeleted(self):
                return

            res_dlg = QDialog(None)
            res_dlg.setWindowTitle("AutoSum — Network Summary")
            res_dlg.setWindowFlags(
                Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
            res_dlg.setMinimumWidth(380)
            res_lay = QVBoxLayout(res_dlg)
            res_lay.setSpacing(12)
            res_lay.setContentsMargins(20, 20, 20, 20)

            # Title
            title_lbl = QLabel("🧮  AutoSum — Network Summary")
            title_fnt = QFont()
            title_fnt.setBold(True)
            title_fnt.setPointSize(11)
            title_lbl.setFont(title_fnt)
            title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            res_lay.addWidget(title_lbl)

            # ── Span Distance section ─────────────────────────────────────
            span_header = QLabel("📏  Span Distance")
            span_hfnt = QFont()
            span_hfnt.setBold(True)
            span_hfnt.setPointSize(9)
            span_header.setFont(span_hfnt)
            span_header.setStyleSheet(f'color:{theme_safe.colors()["ok"]};')
            res_lay.addWidget(span_header)

            if span_name:
                km = span_m / 1000.0
                span_html = (
                    f"<table cellspacing='4'>"
                    f"<tr><td>Layer:</td><td><b>{span_name}</b></td></tr>"
                    f"<tr><td>Features:</td><td>{span_cnt:,}</td></tr>"
                    f"<tr><td>Total:</td>"
                    f"<td><b><span style='color:#1a6b3c; font-size:12pt;'>"
                    f"{span_m:,.1f} m</span></b>"
                    f"&nbsp;&nbsp;<span style='color:#555;'>({km:,.3f} km)</span></td></tr>"
                    f"</table>")
            else:
                span_html = "<i style='color:#888;'>No span layer selected.</i>"
            span_lbl = QLabel(span_html)
            res_lay.addWidget(span_lbl)

            # ── Pole Count section ────────────────────────────────────────
            pole_header = QLabel("🔢  Pole Count")
            pole_hfnt = QFont()
            pole_hfnt.setBold(True)
            pole_hfnt.setPointSize(9)
            pole_header.setFont(pole_hfnt)
            pole_header.setStyleSheet(f'color:{theme_safe.colors()["warn"]};')
            res_lay.addWidget(pole_header)

            if pole_results:
                rows = "".join(
                    f"<tr><td>&nbsp;&nbsp;{n}:</td>"
                    f"<td align='right'><b>{c:,}</b></td></tr>"
                    for n, c in pole_results)
                pole_html = (
                    f"<table cellspacing='4'>{rows}"
                    f"<tr><td colspan='2'><hr/></td></tr>"
                    f"<tr><td><b>Total:</b></td>"
                    f"<td align='right'><b><span style='color:#7a4a1e; font-size:12pt;'>"
                    f"{pole_total:,}</span></b></td></tr>"
                    f"</table>")
            else:
                pole_html = "<i style='color:#888;'>No Poles layers found.</i>"
            pole_lbl = QLabel(pole_html)
            res_lay.addWidget(pole_lbl)

            # ── Demand Points section ─────────────────────────────────────
            dp_header = QLabel("🏠  Demand Points")
            dp_hfnt = QFont()
            dp_hfnt.setBold(True)
            dp_hfnt.setPointSize(9)
            dp_header.setFont(dp_hfnt)
            dp_header.setStyleSheet(f'color:{theme_safe.colors()["accent"]};')
            res_lay.addWidget(dp_header)

            if dp_name:
                dp_html = (
                    f"<table cellspacing='4'>"
                    f"<tr><td>Layer:</td><td><b>{dp_name}</b></td></tr>"
                    f"<tr><td><b>Total:</b></td>"
                    f"<td><b><span style='color:#1a5276; font-size:12pt;'>"
                    f"{dp_count:,}</span></b></td></tr>"
                    f"</table>")
            else:
                dp_html = "<i style='color:#888;'>No Demand Points layer found.</i>"
            dp_lbl = QLabel(dp_html)
            res_lay.addWidget(dp_lbl)

            # ── Close button ──────────────────────────────────────────────
            close_btn = QPushButton("Close")
            close_btn.setStyleSheet(
                "QPushButton { background-color: #4a235a; color: white; "
                "font-weight: bold; padding: 5px 20px; border-radius: 4px; }"
                "QPushButton:hover { background-color: #6c3483; }")
            close_btn.clicked.connect(res_dlg.accept)
            res_lay.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)

            res_dlg.exec()   # stays open until user clicks Close

        def _show_error(msg):
            wait_dlg.close()   # always dismiss the orphan, even if the dock is gone
            if sip.isdeleted(self):
                return
            QMessageBox.critical(None, "AutoSum Error",
                                 f"An error occurred:\n{msg}")

        # Read ALL layer data on the MAIN thread (getFeatures/featureCount are not
        # thread-safe); the worker does only the measureLength math + summation.
        _crs = _tctx = _ellipsoid = None
        _span_geoms = None
        _span_name = ''
        if span_ok:
            _crs = span_layer.crs()
            _tctx = QgsProject.instance().transformContext()
            _ellipsoid = QgsProject.instance().ellipsoid()
            _span_geoms = [QgsGeometry(f.geometry()) for f in span_layer.getFeatures()
                           if f.geometry() and not f.geometry().isEmpty()]
            _span_name = span_layer.name()
        _pole_results = [(lyr.name(), lyr.featureCount()) for lyr in pole_layers]
        _dp_name, _dp_count = (dp_layer.name(), dp_layer.featureCount()) if dp_layer else ('', 0)
        worker = _AutoSumWorker(_span_geoms, _crs, _tctx, _ellipsoid, _span_name,
                                _pole_results, _dp_name, _dp_count)
        worker.finished.connect(_show_result)
        worker.error.connect(_show_error)
        self._autosum_worker = worker
        worker.start()

    def on_span_evaluate_clicked(self):
        """Snap and merge span lines within a tolerance to form one continuous network.

        Strategy:
          1. For every line endpoint within `snap_radius` of another endpoint (but
             not the same feature) → move both to their midpoint (snap together).
          2. For overlapping / nearly-overlapping lines → dissolve/merge them into
             a single continuous polyline where possible.
          3. All edits are made in-place on the selected span layer.
          4. A full report is shown on completion.
        """
        from qgis.core import (QgsGeometry,
                               QgsPointXY, QgsFeature)
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout,
                                         QFormLayout, QLabel, QPushButton,
                                         QDoubleSpinBox, QCheckBox,
                                         QMessageBox, QTextEdit)
        from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
        from qgis.PyQt.QtGui import QFont

        span_layer = self.comboBox_span_layer.currentLayer()
        if span_layer is None:
            QMessageBox.warning(None, "Span Evaluate & Snap",
                                "Please select a Span (Route) layer first.")
            return
        if span_layer.geometryType() != 1:
            QMessageBox.warning(None, "Span Evaluate & Snap",
                                f"'{span_layer.name()}' is not a line layer.")
            return

        # ── Settings dialog ───────────────────────────────────────────────
        dlg = QDialog(None)
        dlg.setWindowTitle("Span Evaluate & Snap — Settings")
        dlg.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                           Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
        dlg.setMinimumWidth(380)
        lay = QVBoxLayout(dlg)
        lay.setSpacing(10)
        lay.setContentsMargins(18, 18, 18, 18)

        hdr = QLabel("🔗  Span Evaluate & Snap")
        hf = QFont(); hf.setBold(True); hf.setPointSize(10)
        hdr.setFont(hf); hdr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(hdr)

        desc = QLabel(
            "Snaps line endpoints that are within the snap radius to each\n"
            "other, and merges lines that share endpoints into a single\n"
            "continuous network. Edits the layer in-place.")
        desc.setWordWrap(True)
        lay.addWidget(desc)

        form = QFormLayout()
        radius_spin = QDoubleSpinBox()
        radius_spin.setRange(0.1, 100.0)
        radius_spin.setDecimals(1)
        radius_spin.setValue(4.0)
        radius_spin.setSuffix(" m")
        radius_spin.setToolTip("Endpoints within this distance will be snapped together.")
        form.addRow("Snap radius (m):", radius_spin)

        dry_chk = QCheckBox("Dry run — report only, do not modify layer")
        dry_chk.setChecked(False)
        lay.addLayout(form)
        lay.addWidget(dry_chk)

        btn_row = QHBoxLayout()
        run_btn = QPushButton("Run")
        run_btn.setStyleSheet(
            "QPushButton { background-color: #2e4057; color: white; font-weight: bold; "
            "padding: 5px 18px; border-radius: 4px; }"
            "QPushButton:hover { background-color: #3d5270; }")
        cancel_btn = QPushButton("Cancel")
        btn_row.addWidget(run_btn); btn_row.addWidget(cancel_btn)
        lay.addLayout(btn_row)
        run_btn.clicked.connect(dlg.accept)
        cancel_btn.clicked.connect(dlg.reject)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        # Batch B: radius_spin is in METRES; on a geographic CRS the worker compares it
        # against degree coordinates (a 4 m radius = ~440 km → the whole net snaps into
        # one blob). Convert to the span layer's units before handing it to the worker.
        snap_radius_m = radius_spin.value()           # original metres (for honest reporting)
        snap_radius = _m_to_units(snap_radius_m, span_layer)  # CRS units used for snapping
        _span_is_geo = span_layer.crs().isValid() and span_layer.crs().isGeographic()
        dry_run = dry_chk.isChecked()

        # ── Worker ────────────────────────────────────────────────────────
        class _SnapWorker(QThread):
            finished = pyqtSignal(int, int, list, dict)   # snaps, merges, report_lines, backup
            error    = pyqtSignal(str)

            def __init__(self, layer, radius, dry, radius_m=None, is_geo=False):
                super().__init__()
                self._layer    = layer
                self._radius   = radius
                self._radius_m = radius_m if radius_m is not None else radius
                self._is_geo   = is_geo
                self._dry      = dry

            def run(self):
                try:
                    import math
                    layer    = self._layer
                    radius   = self._radius
                    radius_m = self._radius_m
                    is_geo   = self._is_geo
                    dry      = self._dry
                    report = []

                    # ----------------------------------------------------------
                    # STEP 1: Collect all endpoints
                    # endpoint_map: {fake_id: (fid, 'start'|'end', QgsPointXY)}
                    # ----------------------------------------------------------
                    endpoint_map = {}
                    fid_geoms = {}   # fid -> list of vertex QgsPointXY
                    eid = 0
                    for feat in layer.getFeatures():
                        geom = feat.geometry()
                        if not geom or geom.isEmpty():
                            continue
                        if geom.isMultipart():
                            parts = geom.asMultiPolyline()
                        else:
                            parts = [geom.asPolyline()]
                        fid_geoms[feat.id()] = parts
                        for part in parts:
                            if len(part) >= 2:
                                endpoint_map[eid] = (feat.id(), 'start', part[0])
                                eid += 1
                                endpoint_map[eid] = (feat.id(), 'end', part[-1])
                                eid += 1

                    total_endpoints = len(endpoint_map)
                    report.append(f"Layer: {layer.name()}")
                    report.append(f"Features: {layer.featureCount()}")
                    report.append(f"Endpoints collected: {total_endpoints}")
                    if is_geo:
                        report.append(f"Snap radius: {radius_m:.1f} m ({radius:.6f} CRS units)")
                    else:
                        report.append(f"Snap radius: {radius_m:.1f} m")
                    report.append("")

                    if total_endpoints == 0:
                        report.append("No endpoints found — check layer geometry.")
                        self.finished.emit(0, 0, report, {})
                        return

                    # ----------------------------------------------------------
                    # STEP 2: Build spatial index over endpoint points
                    # ----------------------------------------------------------
                    idx = QgsSpatialIndex()
                    for eid2, (fid, role, pt) in endpoint_map.items():
                        f = QgsFeature()
                        f.setId(eid2)
                        f.setGeometry(QgsGeometry.fromPointXY(pt))
                        idx.insertFeature(f)

                    # ----------------------------------------------------------
                    # STEP 2b: Identify eligible (non-terminal) endpoints
                    # An endpoint is eligible for snapping ONLY if the OTHER end
                    # of its own feature is already connected to the network
                    # (i.e., touches another feature within connect_threshold).
                    # This prevents true dead-end branch tips from being snapped.
                    # ----------------------------------------------------------
                    from qgis.core import QgsRectangle
                    connect_threshold = min(0.5, radius / 4.0)

                    # Build fid → {role: eid} lookup
                    fid_to_eids = {}
                    for eid2, (fid2, role2, pt2) in endpoint_map.items():
                        fid_to_eids.setdefault(fid2, {})[role2] = eid2

                    def _is_connected(pt, own_fid):
                        """True if pt touches any endpoint from a different feature."""
                        nearby = idx.intersects(QgsRectangle(
                            pt.x()-connect_threshold, pt.y()-connect_threshold,
                            pt.x()+connect_threshold, pt.y()+connect_threshold))
                        for nid in nearby:
                            nfid, _, npt = endpoint_map[nid]
                            if nfid == own_fid:
                                continue
                            if math.sqrt((pt.x()-npt.x())**2 +
                                         (pt.y()-npt.y())**2) <= connect_threshold:
                                return True
                        return False

                    # An endpoint is eligible if the OTHER end of its feature is connected
                    eligible_eids = set()
                    for fid2, roles in fid_to_eids.items():
                        s_eid = roles.get('start')
                        e_eid = roles.get('end')
                        if s_eid is None or e_eid is None:
                            continue
                        _, _, s_pt = endpoint_map[s_eid]
                        _, _, e_pt = endpoint_map[e_eid]
                        if _is_connected(e_pt, fid2):
                            eligible_eids.add(s_eid)   # start is eligible (end is anchored)
                        if _is_connected(s_pt, fid2):
                            eligible_eids.add(e_eid)   # end is eligible (start is anchored)

                    report.append(f"Eligible (non-terminal) endpoints: {len(eligible_eids)}")

                    # ----------------------------------------------------------
                    # STEP 3: Find dangling endpoints (no neighbour within radius
                    #         from a DIFFERENT feature) — terminals excluded
                    # ----------------------------------------------------------
                    # We'll build a list of snap pairs (each endpoint used once)
                    snap_pairs = []   # [(eid_a, eid_b, midpoint)]
                    used = set()

                    for eid_a, (fid_a, role_a, pt_a) in endpoint_map.items():
                        if eid_a in used:
                            continue
                        # Skip true terminal ends — only snap network-interior gaps
                        if eid_a not in eligible_eids:
                            continue
                        nearby_ids = idx.intersects(QgsRectangle(
                            pt_a.x()-radius, pt_a.y()-radius,
                            pt_a.x()+radius, pt_a.y()+radius))

                        best_dist = radius + 1.0
                        best_eid  = None
                        for eid_b in nearby_ids:
                            if eid_b == eid_a or eid_b in used:
                                continue
                            if eid_b not in eligible_eids:
                                continue   # also skip terminal partner endpoints
                            fid_b, role_b, pt_b = endpoint_map[eid_b]
                            if fid_b == fid_a:
                                continue   # same feature — skip
                            dist = math.sqrt((pt_a.x()-pt_b.x())**2 +
                                             (pt_a.y()-pt_b.y())**2)
                            if dist <= radius and dist < best_dist:
                                best_dist = dist
                                best_eid  = eid_b

                        if best_eid is not None:
                            fid_b, role_b, pt_b = endpoint_map[best_eid]
                            mid = QgsPointXY(
                                (pt_a.x()+pt_b.x())/2.0,
                                (pt_a.y()+pt_b.y())/2.0)
                            snap_pairs.append((eid_a, fid_a, role_a, pt_a,
                                               best_eid, fid_b, role_b, pt_b,
                                               mid, best_dist))
                            used.add(eid_a)
                            used.add(best_eid)

                    report.append(f"Snap pairs found: {len(snap_pairs)}")

                    # How many endpoints are still dangling (no partner found)?
                    paired_eids = used
                    dangling = [eid2 for eid2, (fid2, r2, pt2) in endpoint_map.items()
                                if eid2 not in paired_eids]
                    report.append(f"Still-dangling endpoints after snap: {len(dangling)}")
                    report.append("")

                    if dry or not snap_pairs:
                        for sp in snap_pairs:
                            eid_a2, fid_a2, role_a2, pt_a2, eid_b2, fid_b2, role_b2, pt_b2, mid2, dist2 = sp
                            report.append(
                                f"  SNAP fid={fid_a2}({role_a2}) ↔ fid={fid_b2}({role_b2})  "
                                f"dist={dist2:.3f}m → midpoint({mid2.x():.2f},{mid2.y():.2f})")
                        if not snap_pairs:
                            report.append(
                                f"  No snap pairs found within {radius} m.\n"
                                f"  The network may already be connected, or try increasing the radius.")
                        self.finished.emit(0, 0, report, {})
                        return

                    # ----------------------------------------------------------
                    # BACKUP: Capture all geometries before any edits
                    # ----------------------------------------------------------
                    backup_geoms = {}
                    backup_full = []   # [(wkt_or_None, [attr values])] — faithful,
                                       # MERGE-PROOF rebuild (FIDs change after dissolve)
                    for feat in layer.getFeatures():
                        g = feat.geometry()
                        _wkt = g.asWkt() if g and not g.isEmpty() else None
                        backup_geoms[feat.id()] = _wkt
                        backup_full.append((_wkt, list(feat.attributes())))
                    backup = {
                        'layer_id':   layer.id(),
                        'layer_name': layer.name(),
                        'features':   backup_geoms,
                        'full':       backup_full,
                    }

                    # ----------------------------------------------------------
                    # STEP 4: Apply snaps — move endpoints to midpoints
                    # Build a dict of {fid: {'start': new_pt, 'end': new_pt}}
                    # ----------------------------------------------------------
                    snap_updates = {}   # fid -> {role: new QgsPointXY}
                    for sp in snap_pairs:
                        eid_a2, fid_a2, role_a2, pt_a2, eid_b2, fid_b2, role_b2, pt_b2, mid2, dist2 = sp
                        snap_updates.setdefault(fid_a2, {})[role_a2] = mid2
                        snap_updates.setdefault(fid_b2, {})[role_b2] = mid2

                    layer.startEditing()
                    snaps_applied = 0
                    for fid_edit, roles in snap_updates.items():
                        feat = layer.getFeature(fid_edit)
                        geom = feat.geometry()
                        if not geom or geom.isEmpty():
                            continue
                        if geom.isMultipart():
                            parts = geom.asMultiPolyline()
                            changed = False
                            new_parts = []
                            for part in parts:
                                if len(part) < 2:
                                    new_parts.append(part)
                                    continue
                                pl = list(part)
                                if 'start' in roles:
                                    pl[0] = roles['start']
                                    changed = True
                                if 'end' in roles:
                                    pl[-1] = roles['end']
                                    changed = True
                                new_parts.append(pl)
                            if changed:
                                new_geom = QgsGeometry.fromMultiPolylineXY(new_parts)
                                layer.changeGeometry(fid_edit, new_geom)
                                snaps_applied += 1
                        else:
                            pts = list(geom.asPolyline())
                            if len(pts) < 2:
                                continue
                            changed = False
                            if 'start' in roles:
                                pts[0] = roles['start']
                                changed = True
                            if 'end' in roles:
                                pts[-1] = roles['end']
                                changed = True
                            if changed:
                                new_geom = QgsGeometry.fromPolylineXY(pts)
                                layer.changeGeometry(fid_edit, new_geom)
                                snaps_applied += 1

                    _safe_commit(layer)
                    layer.triggerRepaint()

                    report.append(f"✅ Snaps applied: {snaps_applied} feature(s) updated.")
                    report.append("")

                    # ----------------------------------------------------------
                    # STEP 5: Merge connected lines using QGIS dissolve
                    # After snapping, features whose endpoints now touch can be
                    # dissolved into single polylines using the processing framework
                    # ----------------------------------------------------------
                    merges = 0
                    try:
                        import processing
                        result = processing.run("native:dissolve", {
                            'INPUT': layer,
                            'FIELD': [],
                            'SEPARATE_DISJOINT': False,
                            'OUTPUT': 'TEMPORARY_OUTPUT'
                        })
                        merged_layer = result['OUTPUT']
                        orig_count = layer.featureCount()
                        merged_count = merged_layer.featureCount()
                        merges = orig_count - merged_count

                        if merges > 0:
                            report.append(
                                f"🔗 Merge: {orig_count} lines → {merged_count} "
                                f"(reduced by {merges})")
                            # Replace features with the merged result — Batch C:
                            # ADD-verify-THEN-delete. The old order (delete-all then
                            # provider add with the return ignored) WIPED the layer if
                            # the add failed on a disk-backed/schema-mismatched span
                            # layer. Now we add first, confirm it landed, and only then
                            # remove the originals; on failure we roll back and keep
                            # the data intact (recoverable via Restore Span Backup too).
                            _prov = layer.dataProvider()
                            _old_ids = layer.allFeatureIds()
                            merged_feats = [f for f in merged_layer.getFeatures()]
                            _before = layer.featureCount()
                            _res = _prov.addFeatures(merged_feats)
                            _ok = _res[0] if isinstance(_res, tuple) else bool(_res)
                            _added = _res[1] if (isinstance(_res, tuple) and len(_res) > 1) else []
                            if not _ok or layer.featureCount() <= _before:
                                try:
                                    if _added:
                                        _prov.deleteFeatures([f.id() for f in _added])
                                except Exception:
                                    pass
                                report.append("⚠ Merge write FAILED — layer left INTACT (nothing deleted).")
                            else:
                                _prov.deleteFeatures(_old_ids)
                                layer.triggerRepaint()
                                report.append("✅ Merged features written back to layer.")
                        else:
                            report.append(
                                "ℹ️  No further line merges possible after snapping.")
                    except Exception as me:
                        report.append(f"ℹ️  Merge step skipped: {me}")

                    report.append("")
                    report.append("Done. Reload the layer in QGIS if display looks stale.")
                    self.finished.emit(snaps_applied, merges, report, backup)

                except Exception as exc:
                    import traceback
                    self.error.emit(str(exc) + "\n" + traceback.format_exc())

        # ── Wait dialog ───────────────────────────────────────────────────
        wait_dlg = QDialog(None)
        wait_dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        wait_dlg.setWindowTitle("Span Evaluate — Running…")
        wait_dlg.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint | Qt.WindowType.CustomizeWindowHint)
        wait_dlg.setFixedWidth(340)
        wl = QVBoxLayout(wait_dlg)
        wl.addWidget(QLabel(
            f"<b>Evaluating span layer…</b><br>"
            f"Layer: <i>{span_layer.name()}</i><br>"
            f"Snap radius: {snap_radius_m:.1f} m"))
        wait_dlg.show()
        QApplication.processEvents()

        def _show_result(snaps, merges, report, backup):
            wait_dlg.close()
            # Store backup on widget so the restore button can use it
            if backup and snaps > 0:
                self._span_snap_backup = backup
                self.pushButton_restore_span_backup.setEnabled(True)
                self.pushButton_restore_span_backup.setToolTip(
                    f"Restore '{backup.get('layer_name', '')}' to its state before the last snap "
                    f"({len(backup.get('features', {}))} features backed up)")
            res_dlg = QDialog(None)
            res_dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
            title = ("Span Evaluate — Dry Run" if dry_run else
                     f"Span Evaluate — {snaps} snap(s), {merges} merge(s)")
            res_dlg.setWindowTitle(title)
            res_dlg.setWindowFlags(
                Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
            res_dlg.setMinimumWidth(500)
            res_dlg.setMinimumHeight(360)
            r_lay = QVBoxLayout(res_dlg)
            r_lay.setContentsMargins(18, 18, 18, 18)

            hdr2 = QLabel(f"🔗  {title}")
            hf2 = QFont(); hf2.setBold(True); hf2.setPointSize(10)
            hdr2.setFont(hf2); hdr2.setAlignment(Qt.AlignmentFlag.AlignCenter)
            r_lay.addWidget(hdr2)

            if backup and snaps > 0:
                note = QLabel("💾  A backup of the original layer was saved.\n"
                              "    Use '↩ Restore Span Backup' to undo these changes.")
                note.setStyleSheet(f'color:{theme_safe.colors()["muted"]};font-style:italic;')
                r_lay.addWidget(note)

            txt = QTextEdit()
            txt.setReadOnly(True)
            txt.setPlainText("\n".join(report))
            txt.setStyleSheet("font-family: monospace; font-size: 9pt;")
            r_lay.addWidget(txt)

            close_btn = QPushButton("Close")
            close_btn.setStyleSheet(
                "QPushButton { background-color: #2e4057; color: white; "
                "font-weight: bold; padding: 5px 20px; border-radius: 4px; }"
                "QPushButton:hover { background-color: #3d5270; }")
            close_btn.clicked.connect(res_dlg.accept)
            r_lay.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)
            res_dlg.exec()

        def _show_error(msg):
            wait_dlg.close()
            QMessageBox.critical(None, "Span Evaluate Error",
                                 f"An error occurred:\n{msg}")

        worker = _SnapWorker(span_layer, snap_radius, dry_run,
                             radius_m=snap_radius_m, is_geo=_span_is_geo)
        worker.finished.connect(_show_result)
        worker.error.connect(_show_error)
        self._snap_worker = worker
        # Run SYNCHRONOUSLY on the main thread (run(), not start()): this op reads
        # getFeatures(), edits the layer (startEditing/changeGeometry/commitChanges)
        # and calls processing.run() — none of which are thread-safe off the GUI
        # thread (intermittent crash / edit-buffer corruption). The brief UI block is
        # behind the "Running…" dialog; finished/error fire to the same-thread
        # callbacks exactly as before, so behaviour is identical. (A future
        # responsiveness upgrade = split compute-plan/apply; not needed for safety.)
        worker.run()

    def on_restore_span_backup_clicked(self):
        """Restore the span layer to the geometry state captured before the last Span Evaluate & Snap."""
        from qgis.core import QgsProject, QgsGeometry
        from qgis.PyQt.QtWidgets import QMessageBox

        backup = getattr(self, '_span_snap_backup', None)
        if not backup:
            QMessageBox.information(None, "Restore Span Backup",
                                    "No backup available.\n\n"
                                    "Run Span Evaluate & Snap first (not dry run) to create a backup.")
            return

        layer_id   = backup.get('layer_id')
        layer_name = backup.get('layer_name', 'unknown')
        features   = backup.get('features', {})

        # Resolve layer
        layer = QgsProject.instance().mapLayer(layer_id)
        if layer is None:
            QMessageBox.warning(None, "Restore Span Backup",
                                f"Layer '{layer_name}' (id: {layer_id}) is no longer in the project.\n"
                                "Cannot restore.")
            return

        reply = QMessageBox.question(
            None, "Restore Span Backup",
            f"This will restore <b>{layer_name}</b> to its state before the last snap.<br><br>"
            f"<b>{len(features)}</b> feature geometry/geometries will be reverted.<br><br>"
            "Are you sure?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return

        full = backup.get('full')
        restored = 0
        errors = 0
        _restore_ok = True
        if full:
            # MERGE-PROOF restore: the merge step (dissolve) deletes + re-adds
            # features with NEW FIDs, so a per-FID changeGeometry silently misses.
            # Replace ALL features with the backed-up geometry + attributes instead.
            # Mirrors the merge write-back pattern used in on_span_evaluate_clicked.
            # Operates on a backup captured before any edit → safe.
            from qgis.core import QgsFeature
            new_feats = []
            for wkt, attrs in full:
                nf = QgsFeature(layer.fields())
                if attrs:
                    nf.setAttributes(list(attrs))
                if wkt:
                    g = QgsGeometry.fromWkt(wkt)
                    if g and not g.isEmpty():
                        nf.setGeometry(g)
                new_feats.append(nf)
            # Batch C: ADD-verify-THEN-delete. This is the RECOVERY path, so a failed
            # add must NEVER destroy the only remaining copy. Add first, confirm it
            # landed, then drop the originals; on failure roll back + keep the backup.
            _prov = layer.dataProvider()  # claude:approved-destructive (restore from pre-snap backup)
            _old_ids = layer.allFeatureIds()
            _before = layer.featureCount()
            _res = _prov.addFeatures(new_feats)
            _ok = _res[0] if isinstance(_res, tuple) else bool(_res)
            _added = _res[1] if (isinstance(_res, tuple) and len(_res) > 1) else []
            if _ok and layer.featureCount() > _before:
                _prov.deleteFeatures(_old_ids)
                restored = len(new_feats)
            else:
                try:
                    if _added:
                        _prov.deleteFeatures([f.id() for f in _added])
                except Exception:
                    pass
                _restore_ok = False
        else:
            # Legacy backups (geometry-only, no merge had run): per-FID restore.
            layer.startEditing()  # claude:approved-destructive (restore from pre-snap backup)
            for fid, wkt in features.items():
                if wkt is None:
                    continue
                geom = QgsGeometry.fromWkt(wkt)
                if geom and not geom.isEmpty():
                    if layer.changeGeometry(fid, geom):
                        restored += 1
                    else:
                        errors += 1
            _safe_commit(layer)
        layer.triggerRepaint()

        # Clear backup so the restore button can't be used again for the same snap —
        # Batch C: ONLY when the restore actually succeeded, so a failed write never
        # discards the user's last recovery copy.
        if _restore_ok:
            self._span_snap_backup = None
            self.pushButton_restore_span_backup.setEnabled(False)
        else:
            QMessageBox.warning(None, "Restore Span Backup",
                                "Restore write FAILED — your backup was KEPT so you can retry.")
        self.pushButton_restore_span_backup.setToolTip(
            "Restore the span layer to the state before the last Span Evaluate & Snap was applied")

        msg = (f"✅ Restore complete.\n\n"
               f"Layer: {layer_name}\n"
               f"Features restored: {restored}")
        if errors:
            msg += f"\nErrors: {errors} (feature IDs may have changed after merge step)"
        QMessageBox.information(None, "Restore Span Backup", msg)

    def on_explode_span_clicked(self):
        """Explode the span layer into individual 2-point segments.

        Each polyline (or multipart polyline) is broken into its constituent
        straight-line segments, one segment per feature.  This is the reverse
        of a dissolve/merge and restores the layer to separate line segments.
        """
        from qgis.core import QgsGeometry, QgsFeature
        from qgis.PyQt.QtWidgets import QMessageBox, QApplication
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtGui import QCursor

        span_layer = self.comboBox_span_layer.currentLayer()
        if span_layer is None:
            QMessageBox.warning(None, "Explode to Segments",
                                "Please select a Span (Route) layer first.")
            return
        if span_layer.geometryType() != 1:
            QMessageBox.warning(None, "Explode to Segments",
                                f"'{span_layer.name()}' is not a line layer.")
            return

        feat_count = span_layer.featureCount()
        reply = QMessageBox.question(
            None, "Explode to Segments",
            f"Break all lines in <b>{span_layer.name()}</b> into individual 2-point segments?<br><br>"
            f"Current feature count: <b>{feat_count}</b><br>"
            "Each polyline with N vertices will become N–1 separate features.<br><br>"
            "This cannot be undone automatically — save a backup first if needed.<br>"
            "Continue?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return

        QApplication.setOverrideCursor(QCursor(Qt.CursorShape.WaitCursor))
        QApplication.processEvents()

        try:
            # Collect all existing features and their attribute data
            all_feats = list(span_layer.getFeatures())
            fields = span_layer.fields()

            # Build new segment features
            new_segments = []
            for feat in all_feats:
                geom = feat.geometry()
                if not geom or geom.isEmpty():
                    continue
                if geom.isMultipart():
                    parts = geom.asMultiPolyline()
                else:
                    parts = [geom.asPolyline()]

                attrs = feat.attributes()
                for part in parts:
                    for i in range(len(part) - 1):
                        seg = QgsFeature(fields)
                        seg.setAttributes(attrs)
                        seg.setGeometry(QgsGeometry.fromPolylineXY([part[i], part[i+1]]))
                        new_segments.append(seg)

            if not new_segments:
                QApplication.restoreOverrideCursor()
                QMessageBox.information(None, "Explode to Segments",
                                        "No segments could be extracted from the layer.")
                return

            # Replace layer contents — Batch C: ADD-verify-THEN-delete so a failed
            # add (read-only/locked/schema issue on a disk span layer) can't wipe the
            # layer with nothing written back. On failure originals are left intact.
            _prov = span_layer.dataProvider()
            _old_ids = span_layer.allFeatureIds()
            _before = span_layer.featureCount()
            _res = _prov.addFeatures(new_segments)
            _ok = _res[0] if isinstance(_res, tuple) else bool(_res)
            _added = _res[1] if (isinstance(_res, tuple) and len(_res) > 1) else []
            if not _ok or span_layer.featureCount() <= _before:
                try:
                    if _added:
                        _prov.deleteFeatures([f.id() for f in _added])
                except Exception:
                    pass
                QApplication.restoreOverrideCursor()
                QMessageBox.warning(
                    None, "Explode to Segments — Aborted",
                    "Could not write the new segments — the layer was left UNCHANGED "
                    "(nothing deleted). It may be read-only or locked.")
                return
            _prov.deleteFeatures(_old_ids)
            span_layer.triggerRepaint()

            QApplication.restoreOverrideCursor()
            QMessageBox.information(
                None, "Explode to Segments — Done",
                f"✅ Explode complete.\n\n"
                f"Layer: {span_layer.name()}\n"
                f"Original features: {feat_count}\n"
                f"Segments created: {len(new_segments)}")

        except Exception as exc:
            QApplication.restoreOverrideCursor()
            import traceback
            QMessageBox.critical(None, "Explode to Segments — Error",
                                 f"An error occurred:\n{exc}\n\n{traceback.format_exc()}")

    def on_validate_span_network_clicked(self):
        """Validate span network topology and identify connectivity issues."""
        from qgis.core import QgsVectorLayer, QgsProject, QgsGeometry, QgsPointXY, QgsFeature
        from qgis.PyQt.QtCore import QMetaType
        import math
        
        self.log_message("="*60)
        self.log_message("VALIDATING SPAN NETWORK TOPOLOGY")
        self.log_message("="*60)
        self._start_timer()
        span_layer = self.comboBox_span_layer.currentLayer()
        if not span_layer:
            self.log_message("ERROR: No span layer selected")
            return
        
        # Validate geometry type
        geom_type = span_layer.geometryType()
        if geom_type != 1:  # LineString
            self.log_message(f"ERROR: Span layer must contain LineString geometry (found type {geom_type})")
            return
        
        self.log_message(f"Analyzing span layer: {span_layer.name()}")
        self.log_message(f"Total features: {span_layer.featureCount()}")
        
        # Build endpoint catalog
        endpoints = {}  # {(x, y): [feature_ids]}
        segment_endpoints = {}  # {feature_id: [(x1, y1), (x2, y2)]}
        valid_segments = 0
        
        for feat in span_layer.getFeatures():
            geom = feat.geometry()
            if geom and not geom.isEmpty():
                if geom.wkbType() in [2, 5, 1002, 1005]:  # (Multi)LineString incl. 25D/Z
                    if geom.isMultipart():
                        lines = geom.asMultiPolyline()
                        if lines:
                            points = lines[0]
                        else:
                            continue
                    else:
                        points = geom.asPolyline()
                    
                    if len(points) >= 2:
                        valid_segments += 1
                        start = _coord_round(points[0].x(), points[0].y())
                        end = _coord_round(points[-1].x(), points[-1].y())
                        
                        segment_endpoints[feat.id()] = (start, end)
                        
                        # Track which segments connect to each endpoint
                        if start not in endpoints:
                            endpoints[start] = []
                        endpoints[start].append(feat.id())
                        
                        if end not in endpoints:
                            endpoints[end] = []
                        endpoints[end].append(feat.id())
        
        self.log_message(f"Valid line segments: {valid_segments}")
        self.log_message(f"Unique endpoints: {len(endpoints)}")
        
        # Analyze connectivity
        dead_ends = []  # Endpoints with only 1 connection
        junctions = []  # Endpoints with 3+ connections
        
        for coord, feature_ids in endpoints.items():
            connection_count = len(feature_ids)
            if connection_count == 1:
                dead_ends.append((coord, feature_ids[0]))
            elif connection_count >= 3:
                junctions.append((coord, connection_count))
        
        self.log_message("\nCONNECTIVITY ANALYSIS:")
        self.log_message(f"  Dead ends (dangling nodes): {len(dead_ends)}")
        self.log_message(f"  Junctions (3+ connections): {len(junctions)}")
        self.log_message(f"  Normal connections (2 segments): {len(endpoints) - len(dead_ends) - len(junctions)}")
        
        # Find disconnected components using flood-fill
        visited = set()
        components = []
        
        def flood_fill(start_coord):
            """Find all connected endpoints from starting point."""
            component = set()
            stack = [start_coord]
            
            while stack:
                coord = stack.pop()
                if coord in visited:
                    continue
                
                visited.add(coord)
                component.add(coord)
                
                # Find all segments connected to this endpoint
                if coord in endpoints:
                    for fid in endpoints[coord]:
                        if fid in segment_endpoints:
                            start, end = segment_endpoints[fid]
                            if start not in visited:
                                stack.append(start)
                            if end not in visited:
                                stack.append(end)
            
            return component
        
        # Find all connected components
        for coord in endpoints:
            if coord not in visited:
                component = flood_fill(coord)
                if component:
                    components.append(component)
        
        self.log_message("\nCOMPONENT ANALYSIS:")
        self.log_message(f"  Number of disconnected components: {len(components)}")
        
        for i, component in enumerate(components, 1):
            segment_count = sum(1 for fid, (s, e) in segment_endpoints.items() if s in component or e in component)
            self.log_message(f"  Component {i}: {len(component)} endpoints, {segment_count} segments")
        
        # Check aggregation points connectivity (if they exist)
        agg_layer = None
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer):
                if 'aggregation' in layer.name().lower() and 'point' in layer.name().lower():
                    agg_layer = layer
                    break
        
        if agg_layer and len(components) > 1:
            self.log_message("\nAGGREGATION POINTS ANALYSIS:")
            
            # Map each agg point to nearest component
            agg_to_component = {}
            # 'group_100' is not a field on aggregation-point layers (which carry
            # enclosure_id/_name/converging_cables); reading it raised KeyError.
            _agg_has_g100 = agg_layer.fields().lookupField('group_100') >= 0

            for agg_feat in agg_layer.getFeatures():
                agg_geom = agg_feat.geometry()
                if agg_geom and not agg_geom.isEmpty():
                    agg_point = agg_geom.asPoint()
                    agg_coord = (agg_point.x(), agg_point.y())
                    
                    # Find nearest endpoint in any component
                    min_dist = float('inf')
                    nearest_component = None
                    
                    for comp_idx, component in enumerate(components):
                        for endpoint in component:
                            dist = math.sqrt((agg_coord[0] - endpoint[0])**2 + 
                                           (agg_coord[1] - endpoint[1])**2)
                            if dist < min_dist:
                                min_dist = dist
                                nearest_component = comp_idx
                    
                    if nearest_component is not None:
                        if nearest_component not in agg_to_component:
                            agg_to_component[nearest_component] = []
                        agg_to_component[nearest_component].append(
                            agg_feat['group_100'] if _agg_has_g100 else agg_feat.id())
            
            # Report distribution
            for comp_idx in range(len(components)):
                agg_groups = agg_to_component.get(comp_idx, [])
                self.log_message(f"  Component {comp_idx + 1} has {len(agg_groups)} aggregation points")
                if agg_groups and len(agg_groups) <= 5:
                    self.log_message(f"    Groups: {', '.join(map(str, agg_groups))}")
        
        # Create visualization layer for problem areas
        if dead_ends or len(components) > 1:
            self.log_message("\nCREATING VISUALIZATION LAYER...")
            
            # Create problem points layer
            problem_layer = QgsVectorLayer(
                "Point?crs=" + span_layer.crs().authid(),
                "Span Network Issues",
                "memory"
            )
            
            provider = problem_layer.dataProvider()
            provider.addAttributes([
                QgsField("issue_type", QMetaType.Type.QString),
                QgsField("description", QMetaType.Type.QString),
                QgsField("component", QMetaType.Type.Int)
            ])
            problem_layer.updateFields()
            
            features = []
            
            # Add dead ends
            for coord, fid in dead_ends:
                feat = QgsFeature(problem_layer.fields())
                feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(coord[0], coord[1])))
                feat['issue_type'] = 'Dead End'
                feat['description'] = f'Segment {fid} has dangling endpoint'
                feat['component'] = -1
                features.append(feat)
            
            # Add component markers (first endpoint of each component)
            for comp_idx, component in enumerate(components):
                if component:
                    coord = next(iter(component))
                    feat = QgsFeature(problem_layer.fields())
                    feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(coord[0], coord[1])))
                    feat['issue_type'] = 'Component'
                    feat['description'] = f'Component {comp_idx + 1} ({len(component)} endpoints)'
                    feat['component'] = comp_idx + 1
                    features.append(feat)
            
            provider.addFeatures(features)
            
            # Style the layer
            symbol = QgsMarkerSymbol.createSimple({
                'name': 'triangle',
                'color': 'red',
                'size': '4',
                'outline_color': 'black',
                'outline_width': '0.5'
            })
            problem_layer.setRenderer(QgsSingleSymbolRenderer(symbol))
            
            QgsProject.instance().addMapLayer(problem_layer)
            self.log_message(f"Created layer 'Span Network Issues' with {len(features)} problem points")
        
        # Provide recommendations
        self.log_message("\n" + "="*60)
        self.log_message("RECOMMENDATIONS:")
        
        if len(components) > 1:
            self.log_message(f"  ⚠ CRITICAL: Network has {len(components)} disconnected components")
            self.log_message("  → Use Vector → Geometry Tools → Snap Geometries (tolerance: 0.0001)")
            self.log_message("  → Or use Processing → GRASS → v.clean (tools: break,snap,rmdupl)")
        
        if len(dead_ends) > 10:
            self.log_message(f"  ⚠ WARNING: {len(dead_ends)} dead ends found")
            self.log_message("  → Check if these are intentional network endpoints")
            self.log_message("  → Use Topology Checker to find gaps")
        
        if len(components) == 1 and len(dead_ends) <= 10:
            self.log_message("  ✓ Network appears well-connected!")
            self.log_message("  ✓ Ready for feeder route generation")
        
        self.log_message("="*60)
        self._elapsed("Validation")
        return   # ── validation ends here ──
        # Everything below to the end of this method is a SUPERSEDED feeder-route
        # generator that fell through with no return — clicking "Validate" used to
        # ALSO run feeder generation (incl. the recursive get_edge_level that can
        # RecursionError on a large network). The LIVE generator is the separate
        # on_generate_feeder_routes_clicked. Now unreachable. Slated for deletion.
        # ---------------------------------------------------------------------------

    # ── PHASE 1: POLE SPECIFICATION HELPERS (Herotel FTTH Standards) ──
    def _detect_span_type(self, layer_name: str) -> str:
        """Auto-detect span type from layer name.
        Returns 'feeder' if 'feeder' in name (case-insensitive), else 'distribution'."""
        if not layer_name:
            return "distribution"
        return "feeder" if "feeder" in layer_name.lower() else "distribution"

    def _get_pole_height(self, pole_role: str, is_crossing: bool = False) -> float:
        """Get pole height per Herotel spec.
        Feeder: 7m | Distribution midblock: 5.4m | Distribution crossing: 7m"""
        if pole_role == "feeder":
            return 7.0
        if pole_role == "distribution":
            return 7.0 if is_crossing else 5.4
        if pole_role == "support":
            return 5.4
        return 5.4

    def _get_pole_thickness(self, pole_role: str, is_corner: bool = False) -> str:
        """Get pole thickness per Herotel spec (mm).
        Standard: 100/120 | Corner (>15°): 120/140"""
        return "120/140" if (is_corner or pole_role in ["terminal", "support"]) else "100/120"

    def _get_installation_notes(self, pole_role: str, pole_type: str,
                                 pole_height: float, pole_thickness: str) -> str:
        """Generate SANS 754 H4 compliant installation notes."""
        notes = [
            "SANS 754 (63 MPa H4 treated)",
            f"Diameter: {pole_thickness}mm | Height: {pole_height}m",
            f"Depth: {'1.0' if pole_height != 9.0 else '1.2'}m hole | 300x300mm top, taper to 200x200mm bottom",
            "Backfill: 200mm soil + 2x 200mm Soil Crete + compacted fill",
        ]
        if pole_role == "feeder":
            notes.append("FEEDER: 70m max span, double+ capacity, hook @ 5.5m")
        elif pole_role == "distribution":
            notes.append("DISTRIBUTION: 8 homes per pole (4 direct + 4 via tangent)")
        if pole_type in ["start", "end"]:
            notes.append("TERMINAL: Verify cable slack")
        if pole_type == "kink":
            notes.append("KINK: Direction change — check support requirements")
        return " | ".join(notes)

    def _resolve_span_type_field(self, lyr):
        """Find the field holding the span TYPE (primary/secondary feeder,
        distribution, …). Span layers name this field many different ways, so the
        old hard-coded case-sensitive 'Type' lookup found nothing on most real
        layers (e.g. 'type', 'Span Type', 'Classification') and the Generate-Poles
        'Filter by Type' dropdown showed only 'All spans'. Match common names
        case-insensitively first, then fall back to scanning text fields for
        span-type-like values. Returns the field index, or -1 if none looks like
        a type field."""
        if not lyr:
            return -1
        flds = lyr.fields()
        # 1) common explicit names — lookupField is case-INSENSITIVE
        for cand in ('Type', 'span_type', 'spantype', 'SpanType', 'cable_type',
                     'cabletype', 'Cable Type', 'span_role', 'SpanRole', 'role',
                     'category', 'class', 'classification', 'Classification'):
            idx = flds.lookupField(cand)
            if idx >= 0:
                return idx
        # 2) fallback: single pass over text fields, pick the one whose values look
        #    most like span types (small category set + type keywords).
        _kw = ('feeder', 'distribution', 'primary', 'secondary', 'spur',
               'drop', 'trunk', 'backbone', 'link')
        str_idxs = []
        for i, f in enumerate(flds):
            try:
                tn = f.typeName().lower()
            except Exception:
                tn = ''
            if 'char' in tn or 'string' in tn or 'text' in tn:
                str_idxs.append(i)
        if not str_idxs:
            return -1
        vals = {i: set() for i in str_idxs}
        hits = {i: 0 for i in str_idxs}
        n = 0
        for ft in lyr.getFeatures():
            n += 1
            for i in str_idxs:
                v = ft[i]
                if v:
                    s = str(v).lower()
                    if len(vals[i]) <= 40:
                        vals[i].add(s)
                    if any(k in s for k in _kw):
                        hits[i] += 1
            if n >= 5000:          # cap the scan on very large layers
                break
        best_idx, best_hits = -1, 0
        for i in str_idxs:
            if hits[i] > best_hits and 1 <= len(vals[i]) <= 40:
                best_idx, best_hits = i, hits[i]
        return best_idx

    def on_generate_poles_clicked(self):
        """Generate pole points along span layer at specified intervals — PHASE 1: Enhanced attributes per Herotel spec."""
        from qgis.core import QgsWkbTypes, QgsPointXY
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
                                         QLabel, QPushButton, QComboBox, QSpinBox)
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtGui import QFont
        from qgis.core import QgsMapLayerProxyModel
        import math

        # ── Settings popup ────────────────────────────────────────────────
        dlg = QDialog(None)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        dlg.setWindowTitle("Generate Poles — PHASE 1 (Enhanced Herotel Specs)")
        dlg.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                           Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
        dlg.setMinimumWidth(380)
        lay = QVBoxLayout(dlg)
        lay.setSpacing(10)
        lay.setContentsMargins(18, 18, 18, 18)

        hdr = QLabel("🪧  Generate Poles — V105.1")
        hf = QFont(); hf.setBold(True); hf.setPointSize(10)
        hdr.setFont(hf); hdr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(hdr)

        info = QLabel("Choose Span Role: Feeder (7m) or Distribution (5.4-7m)\nRun separately for each span layer type")
        info.setAlignment(Qt.AlignmentFlag.AlignCenter)
        info.setStyleSheet(f'color:{theme_safe.colors()["muted"]};font-size:9pt;')
        lay.addWidget(info)

        form = QFormLayout()
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.DontWrapRows)

        span_combo = QgsMapLayerComboBox()
        span_combo.setFilters(QgsMapLayerProxyModel.LineLayer)
        current_span = self.comboBox_span_layer.currentLayer()
        if current_span:
            span_combo.setLayer(current_span)
        form.addRow("Span Layer:", span_combo)

        # NEW: Type filter (filter spans by their TYPE attribute before generation)
        # Resolver is an instance method (_resolve_span_type_field) so the dropdown
        # population and the generation-time filter use the EXACT same field.
        _resolve_type_field = self._resolve_span_type_field

        type_filter_combo = QComboBox()
        type_filter_combo.addItem("All spans")

        def _on_span_layer_change(lyr):
            """Update Type filter options when span layer changes."""
            type_filter_combo.blockSignals(True)
            type_filter_combo.clear()
            type_filter_combo.addItem("All spans")

            if lyr and lyr.geometryType() == 1:  # LineGeometry
                try:
                    type_idx = _resolve_type_field(lyr)
                    if type_idx >= 0:
                        unique_types = set()
                        for feat in lyr.getFeatures():
                            val = feat[type_idx]
                            if val is not None and str(val).strip():
                                unique_types.add(str(val))
                        for t in sorted(unique_types):
                            type_filter_combo.addItem(t)
                        self.log_message(
                            f"[Generate Poles] Type filter field: "
                            f"'{lyr.fields()[type_idx].name()}' "
                            f"({len(unique_types)} types)")
                except Exception:
                    pass
            type_filter_combo.blockSignals(False)

        span_combo.layerChanged.connect(_on_span_layer_change)
        _on_span_layer_change(current_span)
        form.addRow("Filter by Type:", type_filter_combo)

        # NEW: Explicit span role selector (override auto-detect)
        span_role_combo = QComboBox()
        span_role_combo.addItem("Auto-detect (from layer name)")
        span_role_combo.addItem("Feeder")
        span_role_combo.addItem("Distribution")
        span_role_combo.setCurrentIndex(0)
        form.addRow("Assign Pole Role:", span_role_combo)

        dist_combo = QComboBox()
        for v in [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]:
            dist_combo.addItem(str(v))
        dist_combo.addItem("Custom…")
        dist_combo.setCurrentIndex(4)   # default 50 m

        custom_spin = QSpinBox()
        custom_spin.setRange(1, 500)
        custom_spin.setValue(50)
        custom_spin.setEnabled(False)
        custom_spin.setSuffix(" m")

        def _on_dist_change(text):
            custom_spin.setEnabled(text == "Custom…")
        dist_combo.currentTextChanged.connect(_on_dist_change)

        form.addRow("Distance (m):", dist_combo)
        form.addRow("Custom value:", custom_spin)
        lay.addLayout(form)

        btn_row = QHBoxLayout()
        run_btn = QPushButton("Generate")
        run_btn.setStyleSheet("QPushButton { background-color: #2e4057; color: white; font-weight: bold; "
                              "padding: 5px 18px; border-radius: 4px; } QPushButton:hover { background-color: #3d5270; }")
        cancel_btn = QPushButton("Cancel")
        btn_row.addWidget(run_btn)
        btn_row.addWidget(cancel_btn)
        lay.addLayout(btn_row)

        # #101/#102 (#65 class): WA_DeleteOnClose tears the dialog's widgets down when it
        # closes, so reading span_combo / type_filter_combo / dist_combo / spin / role
        # AFTER dlg.exec() returns crashed with "QgsMapLayerComboBox has been deleted"
        # for multiple teammates (timing/Qt-version dependent). Capture EVERY value
        # up-front in the accept handler — while the widgets are still alive — and read
        # only from this dict afterwards.
        _vals = {}

        def _capture_and_accept():
            try:
                _vals['span_layer'] = span_combo.currentLayer()
                _vals['dist_text'] = dist_combo.currentText()
                _vals['custom'] = custom_spin.value()
                _vals['type_filter'] = type_filter_combo.currentText()
                _vals['span_role'] = span_role_combo.currentText()
            except RuntimeError:
                pass
            dlg.accept()

        run_btn.clicked.connect(_capture_and_accept)
        cancel_btn.clicked.connect(dlg.reject)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        span_layer = _vals.get('span_layer')
        if not span_layer:
            self.log_message("ERROR: Please select a span layer for pole generation.")
            return
        if span_layer.geometryType() != QgsWkbTypes.GeometryType.LineGeometry:
            self.log_message("ERROR: Span layer must be a line layer.")
            return

        dist_text = _vals.get('dist_text', '50')
        distance_meters = _vals.get('custom', 50) if dist_text == "Custom…" else int(dist_text)

        # Get Type filter selection (V105.1 feature)
        type_filter_value = _vals.get('type_filter', 'All spans')
        type_filter_enabled = (type_filter_value != "All spans")

        # Get explicit span role selection (V105.1 feature)
        span_role_selection = _vals.get('span_role', 'Auto-detect (from layer name)')
        if span_role_selection == "Auto-detect (from layer name)":
            span_type = self._detect_span_type(span_layer.name())
            self.log_message("\n=== Generating Poles — PHASE 1.1 (Enhanced, V105.1) ===")
            self.log_message(f"Span layer: '{span_layer.name()}'")
            self.log_message(f"Span role: Auto-detected as {span_type.upper()}")
        else:
            span_type = span_role_selection.lower()
            self.log_message("\n=== Generating Poles — PHASE 1.1 (Enhanced, V105.1) ===")
            self.log_message(f"Span layer: '{span_layer.name()}'")
            self.log_message(f"Span role: Explicitly set to {span_type.upper()}")
        
        if type_filter_enabled:
            self.log_message(f"Type filter: '{type_filter_value}'")
        self.log_message(f"Distance between poles: {distance_meters}m")

        try:
            from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry, QgsField
            from qgis.PyQt.QtCore import QMetaType
            from qgis.core import QgsMarkerSymbol, QgsRendererCategory

            self._start_timer()

            # CRS handling
            crs = span_layer.crs()
            is_geographic = crs.isGeographic()
            
            if is_geographic:
                extent = span_layer.extent()
                center_lat = (extent.yMinimum() + extent.yMaximum()) / 2
                meters_per_degree = 111320 * math.cos(math.radians(center_lat))
                distance_units = distance_meters / meters_per_degree
                self.log_message(f"Geographic CRS: converting {distance_meters}m to ~{distance_units:.6f}°")
            else:
                distance_units = distance_meters
                meters_per_degree = 1.0
                self.log_message(f"Projected CRS: using {distance_meters}m directly")
            
            # Create output pole layer with PHASE 1 schema
            pole_layer = QgsVectorLayer(f"Point?crs={crs.authid()}", 
                                       f"Poles_{distance_meters}m_{span_type}", 
                                       "memory")
            provider = pole_layer.dataProvider()
            
            # PHASE 1: Enhanced attribute schema
            provider.addAttributes([
                QgsField('pole_id', QMetaType.Type.Int),
                QgsField('span_id', QMetaType.Type.Int),
                QgsField('distance_along', QMetaType.Type.Double),
                QgsField('pole_type', QMetaType.Type.QString),     # start, intermediate, end, kink
                QgsField('pole_role', QMetaType.Type.QString),     # NEW: feeder, distribution, support
                QgsField('pole_height', QMetaType.Type.Double),    # NEW: meters (7.0, 5.4, etc)
                QgsField('pole_thickness', QMetaType.Type.QString),# NEW: "100/120" or "120/140"
                QgsField('installation_notes', QMetaType.Type.QString)  # NEW: SANS 754 specs
            ])
            pole_layer.updateFields()
            
            pole_features = []
            pole_id = 1
            total_poles = 0
            global_placed_coords = set()
            
            # Get Type field index for filtering (if enabled) — use the SAME
            # resolver that populated the dropdown so we filter on the right field.
            type_field_idx = -1
            if type_filter_enabled:
                type_field_idx = _resolve_type_field(span_layer)
                if type_field_idx < 0:
                    self.log_message("WARNING: span type field not found. Filtering disabled.")
                    type_filter_enabled = False
            
            # Process each span segment
            for span_feat in span_layer.getFeatures():
                geom = span_feat.geometry()
                if not geom or geom.isEmpty():
                    continue
                
                # NEW: Apply Type filter
                if type_filter_enabled:
                    feat_type = span_feat[type_field_idx]
                    if str(feat_type) != type_filter_value:
                        continue  # Skip this feature, doesn't match filter
                
                span_id = span_feat.id()
                
                if geom.isMultipart():
                    lines = geom.asMultiPolyline()
                else:
                    lines = [geom.asPolyline()]
                
                for line in lines:
                    if len(line) < 2:
                        continue
                    
                    cumulative = 0.0

                    for i, vertex in enumerate(line):
                        if i == 0:
                            vtype = 'start'
                        elif i == len(line) - 1:
                            vtype = 'end'
                        else:
                            vtype = 'kink'

                        key = _coord_round(vertex.x(), vertex.y())
                        if key not in global_placed_coords:
                            global_placed_coords.add(key)
                            dist_out = cumulative if not is_geographic else cumulative * meters_per_degree
                            
                            # PHASE 1: Assign pole attributes
                            pole_role = span_type if vtype == 'start' else 'distribution'
                            pole_height = self._get_pole_height(pole_role)
                            pole_thickness = self._get_pole_thickness(pole_role, is_corner=(vtype == 'kink'))
                            install_notes = self._get_installation_notes(pole_role, vtype, pole_height, pole_thickness)
                            
                            pole_feat = QgsFeature(pole_layer.fields())
                            pole_feat.setGeometry(QgsGeometry.fromPointXY(vertex))
                            pole_feat.setAttributes([
                                pole_id, span_id, round(dist_out, 2), vtype,
                                pole_role, pole_height, pole_thickness, install_notes
                            ])
                            pole_features.append(pole_feat)
                            pole_id += 1
                            total_poles += 1

                        # Fill segment with intermediate poles
                        if i < len(line) - 1:
                            nv = line[i + 1]
                            dx = nv.x() - vertex.x()
                            dy = nv.y() - vertex.y()
                            seg_len = math.sqrt(dx * dx + dy * dy)

                            if seg_len > distance_units:
                                n_steps = int(seg_len / distance_units)
                                for k in range(1, n_steps + 1):
                                    frac = (k * distance_units) / seg_len
                                    if frac >= 0.999:
                                        break
                                    ix = vertex.x() + frac * dx
                                    iy = vertex.y() + frac * dy
                                    ikey = _coord_round(ix, iy)
                                    if ikey not in global_placed_coords:
                                        global_placed_coords.add(ikey)
                                        int_dist = cumulative + k * distance_units
                                        dist_out = int_dist if not is_geographic else int_dist * meters_per_degree
                                        
                                        # PHASE 1: Intermediate poles
                                        pole_role = 'distribution'
                                        pole_height = self._get_pole_height(pole_role)
                                        pole_thickness = self._get_pole_thickness(pole_role)
                                        install_notes = self._get_installation_notes(pole_role, 'intermediate', pole_height, pole_thickness)
                                        
                                        pole_feat = QgsFeature(pole_layer.fields())
                                        pole_feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(ix, iy)))
                                        pole_feat.setAttributes([
                                            pole_id, span_id, round(dist_out, 2), 'intermediate',
                                            pole_role, pole_height, pole_thickness, install_notes
                                        ])
                                        pole_features.append(pole_feat)
                                        pole_id += 1
                                        total_poles += 1

                            cumulative += seg_len
            
            if len(pole_features) == 0:
                self.log_message("WARNING: No poles were generated. Check span layer geometry.")
                return
            
            # Add features to layer
            provider.addFeatures(pole_features)
            pole_layer.updateExtents()
            
            # Apply symbology
            categories = []
            pole_styles = {
                'start': ('0,200,0', 4.0),        # Bright green
                'intermediate': ('100,149,237', 3.0),  # Cornflower blue
                'kink': ('255,140,0', 4.0),      # Dark orange
                'end': ('220,20,60', 4.0)        # Crimson red
            }
            
            for pole_type, (color, size) in pole_styles.items():
                symbol = QgsMarkerSymbol.createSimple({
                    'name': 'circle',
                    'color': color,
                    'size': str(size),
                    'outline_color': 'black',
                    'outline_width': '0.8'
                })
                category = QgsRendererCategory(pole_type, symbol, pole_type.capitalize())
                categories.append(category)
            
            renderer = _categorized_with_catch_all(pole_layer, 'pole_type', categories)
            pole_layer.setRenderer(renderer)
            
            # Add layer to project
            pole_layer = self._add_output_layer(pole_layer)
            
            # Summary statistics
            feeder_count = sum(1 for f in pole_features if f['pole_role'] == 'feeder')
            distribution_count = sum(1 for f in pole_features if f['pole_role'] == 'distribution')
            start_count = sum(1 for f in pole_features if f['pole_type'] == 'start')
            intermediate_count = sum(1 for f in pole_features if f['pole_type'] == 'intermediate')
            kink_count = sum(1 for f in pole_features if f['pole_type'] == 'kink')
            end_count = sum(1 for f in pole_features if f['pole_type'] == 'end')
            
            self.log_message(f"\n✓ PHASE 1: Generated {total_poles} poles with enhanced attributes")
            self.log_message(f"  Feeder poles: {feeder_count} @ 7.0m")
            self.log_message(f"  Distribution poles: {distribution_count} @ 5.4-7.0m")
            self.log_message(f"  By type: {start_count} start (green) | {intermediate_count} intermediate (blue) | "
                            f"{kink_count} kink (orange) | {end_count} end (red)")
            self.log_message("  All poles: SANS 754 H4 treated with FTTH spec details in attributes")
            self.log_message(f"Layer: '{pole_layer.name()}'")
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR generating poles: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_generate_feeder_routes_clicked(self):
        """Generate fiber feeder routes from OLT to aggregation points along routing layer."""
        from qgis.core import (
            QgsVectorLayer, QgsFeature, QgsGeometry, QgsWkbTypes, QgsField
        )
        from qgis.PyQt.QtCore import QMetaType
        from qgis.PyQt.QtGui import QColor

        olt_layer = self.comboBox_olt_layer.currentLayer()
        agg_layer = self.comboBox_aggregation_layer.currentLayer()
        routing_layer = self.comboBox_routing_layer.currentLayer()

        if not olt_layer:
            self.log_message("ERROR: Please select an OLT layer.")
            return
        if not agg_layer:
            self.log_message("ERROR: Please select an Aggregation Points layer.")
            return

        self.log_message("\n=== Generating Feeder Routes ===")
        self._start_timer()  # _start_timer takes no args (matches all other call sites)
        from qgis.PyQt.QtWidgets import QApplication
        QApplication.processEvents()

        try:
            # Get OLT point (use first feature)
            olt_features = list(olt_layer.getFeatures())
            if not olt_features:
                self.log_message("ERROR: OLT layer has no features.")
                return
            olt_geom = olt_features[0].geometry()
            if not olt_geom or olt_geom.isEmpty():
                self.log_message("ERROR: OLT feature has no geometry.")
                return
            olt_point = olt_geom.asPoint() if olt_geom.type() == QgsWkbTypes.GeometryType.PointGeometry else olt_geom.centroid().asPoint()

            # Collect aggregation points
            agg_points = []
            _agg_has_zone_name = 'zone_name' in [f.name() for f in agg_layer.fields()]
            for feat in agg_layer.getFeatures():
                geom = feat.geometry()
                if geom and not geom.isEmpty():
                    pt = geom.asPoint() if geom.type() == QgsWkbTypes.GeometryType.PointGeometry else geom.centroid().asPoint()
                    zone_name = feat['zone_name'] if _agg_has_zone_name else str(feat.id())
                    agg_points.append((pt, zone_name, feat.id()))

            if not agg_points:
                self.log_message("ERROR: No aggregation points found.")
                return

            self.log_message(f"OLT point: ({olt_point.x():.1f}, {olt_point.y():.1f})")
            self.log_message(f"Aggregation points: {len(agg_points)}")

            # Build routing graph from span layer if available
            route_segments = []
            if routing_layer and routing_layer.geometryType() == QgsWkbTypes.GeometryType.LineGeometry:
                self.log_message(f"Routing layer: '{routing_layer.name()}'")
                for feat in routing_layer.getFeatures():
                    geom = feat.geometry()
                    if geom and not geom.isEmpty():
                        route_segments.append(geom)

            # Create feeder routes layer
            crs_str = agg_layer.crs().authid()
            feeder_layer = QgsVectorLayer(f"LineString?crs={crs_str}", "Feeder Routes", "memory")
            provider = feeder_layer.dataProvider()
            provider.addAttributes([
                QgsField('route_id', QMetaType.Type.Int),
                QgsField('zone_name', QMetaType.Type.QString),
                QgsField('agg_point_id', QMetaType.Type.Int),
                QgsField('length_m', QMetaType.Type.Double),
            ])
            feeder_layer.updateFields()

            from qgis.core import QgsDistanceArea
            _da_feeder = QgsDistanceArea()
            _da_feeder.setSourceCrs(agg_layer.crs(), QgsProject.instance().transformContext())
            _da_feeder.setEllipsoid(_safe_ellipsoid(QgsProject.instance(), agg_layer.crs()))

            route_id = 1
            feeder_layer.startEditing()

            for pt, zone_name, agg_id in agg_points:
                self._progress(route_id - 1, len(agg_points), f"Routing to {zone_name}")
                QApplication.processEvents()

                if route_segments:
                    # Snap OLT and target to nearest point on routing network, then connect via straight line
                    # Simple approach: find nearest route segment endpoints and connect
                    best_line = self._route_along_network(olt_point, pt, route_segments)
                else:
                    # Straight-line feeder
                    best_line = QgsGeometry.fromPolylineXY([olt_point, pt])

                feat = QgsFeature(feeder_layer.fields())
                feat.setGeometry(best_line)
                feat['route_id'] = route_id
                feat['zone_name'] = zone_name
                feat['agg_point_id'] = agg_id
                feat['length_m'] = round(_da_feeder.measureLength(best_line), 2)  # metres, not CRS degrees
                feeder_layer.addFeature(feat)
                route_id += 1

            _safe_commit(feeder_layer)

            # Style: dark blue line, width 0.8
            from qgis.core import QgsSimpleLineSymbolLayer, QgsSingleSymbolRenderer, QgsSymbol
            symbol = QgsSymbol.defaultSymbol(QgsWkbTypes.GeometryType.LineGeometry)
            sym_layer = QgsSimpleLineSymbolLayer()
            sym_layer.setColor(QColor('#003399'))
            sym_layer.setWidth(0.8)
            symbol.changeSymbolLayer(0, sym_layer)
            feeder_layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            feeder_layer = self._add_output_layer(feeder_layer)
            self.log_message(f"Generated {route_id - 1} feeder routes.")
            self._elapsed("Total time")

        except Exception as e:
            self.log_message(f"ERROR generating feeder routes: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def _route_along_network(self, start_pt, end_pt, route_segments):
        """Find a path along route segments from start to end using nearest-segment snapping.
        Falls back to straight line if no path found."""
        from qgis.core import QgsGeometry, QgsPointXY
        import math

        def dist(p1, p2):
            return math.sqrt((p1.x() - p2.x()) ** 2 + (p1.y() - p2.y()) ** 2)

        def nearest_point_on_segment(px, py, ax, ay, bx, by):
            dx, dy = bx - ax, by - ay
            if dx == 0 and dy == 0:
                return QgsPointXY(ax, ay)
            t = max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)))
            return QgsPointXY(ax + t * dx, ay + t * dy)

        # Find closest point on network to start and end
        best_start, best_end = None, None
        best_sd, best_ed = float('inf'), float('inf')

        for seg_geom in route_segments:
            pts = seg_geom.asPolyline() if seg_geom.isMultipart() is False else []
            if not pts:
                try:
                    for part in seg_geom.asMultiPolyline():
                        pts.extend(part)
                except Exception:
                    continue
            for i in range(len(pts) - 1):
                snap_s = nearest_point_on_segment(start_pt.x(), start_pt.y(), pts[i].x(), pts[i].y(), pts[i+1].x(), pts[i+1].y())
                snap_e = nearest_point_on_segment(end_pt.x(), end_pt.y(), pts[i].x(), pts[i].y(), pts[i+1].x(), pts[i+1].y())
                ds = dist(start_pt, snap_s)
                de = dist(end_pt, snap_e)
                if ds < best_sd:
                    best_sd, best_start = ds, snap_s
                if de < best_ed:
                    best_ed, best_end = de, snap_e

        if best_start and best_end:
            return QgsGeometry.fromPolylineXY([start_pt, best_start, best_end, end_pt])
        return QgsGeometry.fromPolylineXY([start_pt, end_pt])

    def on_clear_output_clicked(self):
        """Clear the output text."""
        self.textEdit_output.clear()
        self.log_message("Output cleared.")

    def closeEvent(self, event):
        """Handle the close event."""
        # Disconnect the QgsProject singleton signals wired in __init__ — otherwise a
        # one-click reload builds a fresh dock and the OLD (deleted) dock's slots stay
        # connected, so the next project open/clear fires into a deleted C++ widget
        # ("wrapped C/C++ object has been deleted"). Guarded: harmless if already gone.
        try:
            from qgis.core import QgsProject as _QPc
            try:
                _QPc.instance().readProject.disconnect(self._reload_gpkg_path)
            except (TypeError, RuntimeError):
                pass
            try:
                _QPc.instance().cleared.disconnect(self._clear_gpkg_path)
            except (TypeError, RuntimeError):
                pass
        except Exception:
            pass
        self.closingPlugin.emit()
        event.accept()


# ── BOQ Take-off helpers (module level) ─────────────────────────────────────
def _boq_qcolor(name):
    from qgis.PyQt.QtGui import QColor
    return QColor(name)


from qgis.PyQt.QtCore import Qt as _BOQ_QT
from qgis.PyQt.QtWidgets import QTableWidgetItem as _BOQ_TWI


class _BoqNumItem(_BOQ_TWI):
    """A table cell that sorts by its numeric UserRole value, not its text —
    so '1,916' sorts after '512', not lexically before it."""

    def __lt__(self, other):
        try:
            return (float(self.data(_BOQ_QT.ItemDataRole.UserRole)) <
                    float(other.data(_BOQ_QT.ItemDataRole.UserRole)))
        except (TypeError, ValueError):
            return super().__lt__(other)
