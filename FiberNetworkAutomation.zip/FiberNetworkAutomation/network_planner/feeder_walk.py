"""Feeder-walk PON ordering — the cable-hierarchy walk JJ confirmed by recording
his manual walk (2026-06-24). Pure Python (math only), no QGIS imports, so it is
trivially testable.

walk_order(feeder, dist, zones, pop) -> [zone_id, ...]

Rule: walk the 144F from the POP; descend each spur in position order along the
parent (bigger LINK first when two spur at ~the same point); along a link, dip a
LITTLE way into each distribution -> that zone's number; a sub-link tapping right
at the entry junction is DEFERRED until after the cable's own distributions;
dedup by zone. See memory: project_feeder_walk_auto_renumber_2026-06-24.

Inputs (all coords [lon, lat] in degrees — the metric helper assumes WGS84):
  feeder : [{'pts': [[lon,lat],...], 'size': 144|48|24}, ...]
  dist   : [[[lon,lat],...], ...]
  zones  : [{'id': str, 'rings': [[[lon,lat],...], ...], 'c': [lon,lat]}, ...]
  pop    : [lon, lat]
"""
import math

STUB_M = 16.0     # how far the dip reaches into a distribution (a little bit)
TOL = 4.0         # metres: a spur endpoint this close to a cable LINE taps it
START = 25.0      # a sub-link tapping within this of the entry junction is deferred


def _md(a, b):
    dy = (a[1] - b[1]) * 110540.0
    dx = (a[0] - b[0]) * 111320.0 * math.cos(math.radians(a[1]))
    return math.hypot(dx, dy)


def _proj(P, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    l2 = dx * dx + dy * dy
    t = 0.0 if l2 == 0 else max(0.0, min(1.0, ((P[0] - a[0]) * dx + (P[1] - a[1]) * dy) / l2))
    return _md(P, [a[0] + t * dx, a[1] + t * dy]), [a[0] + t * dx, a[1] + t * dy]


def _proj_cum(pts, P):
    best = (1e18, 0.0, pts[0])
    acc = 0.0
    for i in range(1, len(pts)):
        d, q = _proj(P, pts[i - 1], pts[i])
        if d < best[0]:
            best = (d, acc + _md(pts[i - 1], q), q)
        acc += _md(pts[i - 1], pts[i])
    return best


def _point_along(pts, dist_m):
    acc = 0.0
    for i in range(1, len(pts)):
        seg = _md(pts[i - 1], pts[i])
        if acc + seg >= dist_m:
            t = (dist_m - acc) / seg if seg > 0 else 0.0
            return [pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * t,
                    pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * t]
        acc += seg
    return pts[-1]


def _pip(lon, lat, ring):
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i]
        xj, yj = ring[j]
        if ((yi > lat) != (yj > lat)) and \
           (lon < (xj - xi) * (lat - yi) / ((yj - yi) or 1e-12) + xi):
            inside = not inside
        j = i
    return inside


def walk_order(feeder, dist, zones, pop):
    """Return the zone ids in feeder-walk order. Never raises on empty inputs."""
    cables = [{'pts': f['pts'], 'size': f.get('size') or 0}
              for f in feeder if len(f.get('pts', [])) >= 2]
    for ln in dist:
        if len(ln) >= 2:
            cables.append({'pts': ln, 'size': 1})
    if not cables or not zones:
        return []
    idx144 = max(range(len(cables)), key=lambda i: cables[i]['size'])

    def zone_of(P):
        for z in zones:
            for ring in z.get('rings', []):
                if len(ring) >= 3 and _pip(P[0], P[1], ring):
                    return z['id']
        return None

    def nearest_zone(P):
        return min(zones, key=lambda z: _md(P, z['c']))['id']

    # orient each cable from its entry; find its (bigger) parent + tap end
    orient = [None] * len(cables)
    parent = [None] * len(cables)
    tap_end = [None] * len(cables)
    a0, a1 = cables[idx144]['pts'][0], cables[idx144]['pts'][-1]
    orient[idx144] = cables[idx144]['pts'][:] if _md(a0, pop) <= _md(a1, pop) \
        else cables[idx144]['pts'][::-1]
    for ci, c in enumerate(cables):
        if ci == idx144:
            continue
        best = None
        for end in (c['pts'][0], c['pts'][-1]):
            for ti, tg in enumerate(cables):
                if ti == ci or tg['size'] <= c['size']:
                    continue
                d, _cum, _q = _proj_cum(tg['pts'], end)
                if d <= TOL:
                    cand = (d, -tg['size'], ti, end)
                    if best is None or cand[:2] < best[:2]:
                        best = cand
        if best is None:
            continue
        parent[ci], tap_end[ci] = best[2], best[3]
        orient[ci] = c['pts'][:] if best[3] == c['pts'][0] else c['pts'][::-1]

    children = [[] for _ in cables]
    for ci in range(len(cables)):
        if parent[ci] is None or orient[parent[ci]] is None:
            continue
        cum = _proj_cum(orient[parent[ci]], tap_end[ci])[1]
        children[parent[ci]].append((cum, ci))

    order = []
    seen = set()
    visited = set()

    def dip(ci):
        pts = orient[ci]
        if not pts:
            return
        inside = _point_along(pts, STUB_M)
        zid = (zone_of(inside) or zone_of(_point_along(pts, STUB_M * 2))
               or zone_of(pts[-1]) or nearest_zone(inside))
        if zid is not None and zid not in seen:
            seen.add(zid)
            order.append(zid)

    def process(ci, depth=0):
        if ci in visited or depth > 5000:
            return
        visited.add(ci)
        kids = children[ci]
        deferred = [(c, k) for c, k in kids if cables[k]['size'] > 1 and c < START]
        inline = sorted([(c, k) for c, k in kids
                         if not (cables[k]['size'] > 1 and c < START)],
                        key=lambda x: (round(x[0], 1), -cables[x[1]]['size']))
        for _cum, k in inline:
            if k in visited:
                continue
            if cables[k]['size'] == 1:
                visited.add(k)
                dip(k)
            else:
                process(k, depth + 1)
        for _cum, k in sorted(deferred, key=lambda x: (round(x[0], 1), -cables[x[1]]['size'])):
            if k in visited:
                continue
            process(k, depth + 1)

    process(idx144)
    return order
