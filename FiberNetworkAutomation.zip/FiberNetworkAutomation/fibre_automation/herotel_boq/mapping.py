"""Explicit mappings: name similarity may suggest, never approve quantities."""
from dataclasses import asdict, dataclass
import math
import re
import unicodedata

from .model import INPUT_ROWS


def normalise(value):
    return re.sub(r'[^a-z0-9]', '', unicodedata.normalize('NFKC', str(value)).lower())


def field_candidates(fields, aliases):
    return tuple(field for field in fields if normalise(field) in {normalise(a) for a in aliases})


def number(value, *, unit='count'):
    if value is None or isinstance(value, bool):
        raise ValueError('Missing or invalid quantity')
    text = str(value).strip()
    if unit == 'm':
        text = re.sub(r'\s*m$', '', text, flags=re.I)
    if not re.fullmatch(r'\d+(?:\.\d+)?', text):
        raise ValueError(f'Unknown {unit} quantity: {value!r}')
    result = float(text)
    if not math.isfinite(result) or result < 0 or result > 2**53-1 or (unit == 'count' and not result.is_integer()):
        raise ValueError('Quantity must be finite, nonnegative and integral for counts')
    return result


def splitter_count(value, capacity):
    if value is None or isinstance(value, bool):
        raise ValueError('Missing splitter ratio')
    text = re.sub(r'\s+', '', str(value)).lower().replace('×', 'x')
    if text in ('nosplitter', '0'):
        return 0
    match = re.fullmatch(r'(?:(\d+)x)?1:(8|16)(?:x(\d+))?', text)
    if not match or (match[1] and match[3]):
        raise ValueError('Unrecognised splitter ratio/multiplicity')
    return int(match[1] or match[3] or 1) if int(match[2]) == capacity else 0


@dataclass(frozen=True)
class Binding:
    row: int
    layer: str
    operation: str = 'count'
    field: str = ''
    slack_field: str = ''
    total_field: str = ''
    filters: tuple = ()  # Exact (field,value) pairs: no heuristic material aliases.
    phase_field: str = ''
    phase_constant: str = ''
    reviewed: bool = False
    complete_scope: bool = False
    rationale: str = ''
    identity_field: str = ''
    allow_empty_filter: bool = False

    def validate(self, layer):
        if any(type(value) is not bool for value in (self.reviewed, self.complete_scope, self.allow_empty_filter)):
            raise ValueError('Review and zero-scope flags must be boolean')
        if self.row not in INPUT_ROWS or self.operation not in ('count', 'sum', 'length', 'splitter8', 'splitter16'):
            raise ValueError('Unsupported BOQ row/operation')
        if not self.reviewed or not self.complete_scope or not self.rationale.strip():
            raise ValueError('Mapping needs explicit review, complete-scope confirmation and rationale')
        names = [f for f in (self.field, self.slack_field, self.total_field, self.phase_field, self.identity_field) if f]
        names += [f for f, _ in self.filters]
        if any(f not in layer.fields for f in names):
            raise ValueError('Mapped field does not exist')
        if self.operation != 'count' and not self.field:
            raise ValueError('Quantity field required')
        if self.operation == 'length' and not (self.slack_field or self.total_field):
            raise ValueError('Explicit slack or installed-total field required')
        if self.phase_field and self.phase_constant:
            raise ValueError('Use either phase field or explicit layer phase')

    def payload(self):
        return asdict(self)
