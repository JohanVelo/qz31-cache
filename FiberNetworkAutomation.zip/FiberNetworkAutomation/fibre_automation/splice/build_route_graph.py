"""
MOA Phase 2 Splice Plan — Route Graph + Cross-Connect PoC
=========================================================
Implements the deep-research recommendation (research_splice_plan_autogen_standards_2026-05-29):
  - networkx graph: nodes = poles, edges = cables (strtfeat -> endfeat)
  - BFS from POP outward
  - per-closure cross-connect table (2-column In Fiber# -> Out Fiber#)
  - sequential fibre assignment (round-robin reserved for multi-splitter domes)
  - express / pass-through fibre identification
  - TIA-598-C tube/fibre colour + tray#/pos# assignment

Reads:  C:/Temp/splice_data.json   (extracted 2026-05-21 from the MOA HLD project)
Writes: C:/Temp/splice_poc_crossconnect.json
        C:/Temp/moa_route_graph.graphml

Standards applied (verified): TIA-598-C colour, TIA-568.3-D (splice 0.1dB work / 0.3dB max,
ORL>26dB), ISO/IEC 14763-3:2024 Ed 3.0 bi-directional. NOT the SKA/DFA strict numbers (refuted).
This is a FIRST-PASS PoC — exact tray rules await the Fibertime template.
"""
import json
import networkx as nx

import os
_HERE = os.path.dirname(os.path.abspath(__file__))
_OUT_DIR = os.environ.get("VELOPLAN_OUT") or os.path.join(_HERE, "output")
os.makedirs(_OUT_DIR, exist_ok=True)
DATA = os.environ.get("VELOPLAN_DATA") or os.path.join(_HERE, "splice_data.json")
OUT_XC = os.path.join(_OUT_DIR, "splice_poc_crossconnect.json")
OUT_GRAPHML = os.path.join(_OUT_DIR, "moa_route_graph.graphml")

# TIA-598-C 12-fibre colour code (verified 3-0 in deep research)
TIA598C = ["Blue", "Orange", "Green", "Brown", "Slate", "White",
           "Red", "Black", "Yellow", "Violet", "Rose", "Aqua"]


def fibre_id(n):
    """1-based fibre number -> (tube#, tube_colour, fibre_colour, pos_in_tube)."""
    idx = n - 1
    tube = idx // 12 + 1
    pos = idx % 12
    return tube, TIA598C[(tube - 1) % 12], TIA598C[pos], pos + 1


def cap_to_int(cblcpty):
    """'48F' -> 48 ; '1:8F' -> 8 (splitter output legs) ; '24F' -> 24."""
    if not cblcpty:
        return 0
    s = str(cblcpty).upper().replace("F", "")
    if ":" in s:                       # splitter ratio e.g. 1:8 -> 8 legs
        return int(s.split(":")[1])
    try:
        return int(float(s))
    except ValueError:
        return 0


def main():
    d = json.load(open(DATA))
    cables = d["primary"] + d["secondary"] + d["distribution"]

    # ---- 1. Build the route graph (poles = nodes, cables = edges) ----
    G = nx.MultiGraph()
    for c in cables:
        a, b = c.get("strtfeat"), c.get("endfeat")
        if not a or not b:
            continue
        G.add_node(a, kind="pole")
        G.add_node(b, kind="pole")
        G.add_edge(a, b,
                   label=c["label"], fibers=cap_to_int(c["cblcpty"]),
                   ntype=c.get("ntwrkptn"), pon=c.get("pon_no"),
                   length=c.get("dim2"))

    print("=" * 64)
    print("ROUTE GRAPH")
    print("=" * 64)
    print(f"  nodes (poles)      : {G.number_of_nodes()}")
    print(f"  edges (cables)     : {G.number_of_edges()}")
    comps = list(nx.connected_components(G))
    print(f"  connected components: {len(comps)}  (sizes: "
          f"{sorted((len(c) for c in comps), reverse=True)[:8]})")

    # ---- 2. Infer POP root = endpoint of the highest-capacity primary feeder ----
    prim = sorted(d["primary"], key=lambda c: cap_to_int(c["cblcpty"]), reverse=True)
    pop_candidates = [c["strtfeat"] for c in prim] + [c["endfeat"] for c in prim]
    # the pole with highest degree among primary endpoints is the most likely POP/trunk node
    root = max(pop_candidates, key=lambda n: G.degree(n) if n in G else 0)
    print(f"  inferred POP/root  : {root}  (degree {G.degree(root)})")

    # ---- 3. Map domes + splitters to their poles ----
    agg_by_pole = {}
    for a in d["agg_domes"]:
        agg_by_pole.setdefault(a["strtfeat"], []).append(a)
    fts_by_pole = {}
    for f in d["fts"]:
        fts_by_pole.setdefault(f["strtfeat"], []).append(f)

    print(f"\n  AGG domes          : {len(d['agg_domes'])}  on {len(agg_by_pole)} poles")
    print(f"  FTS splitters      : {len(d['fts'])}  on {len(fts_by_pole)} poles")
    print(f"  DIS domes          : {len(d['dis_domes'])}")
    print(f"  STS splitters      : {len(d['sts'])}")

    # ---- 4. Pick ONE AGG dome that sits on a graph pole with incident cables ----
    demo = None
    for pole, aggs in agg_by_pole.items():
        if pole in G and G.degree(pole) >= 1:
            demo = (pole, aggs[0])
            break
    if demo is None:
        print("\n[!] No AGG dome pole found on the cable graph — check strtfeat mapping.")
        return

    pole, agg = demo
    incident = [(u, v, data) for u, v, data in G.edges(pole, data=True)]

    # split incident cables into upstream (toward root) vs downstream (away)
    try:
        dist_root = nx.shortest_path_length(G, root, pole)
    except (nx.NetworkXNoPath, nx.NodeNotFound):
        dist_root = None
    up, down = [], []
    for u, v, data in incident:
        other = v if u == pole else u
        try:
            do = nx.shortest_path_length(G, root, other)
            (up if do < (dist_root or 1e9) else down).append((other, data))
        except Exception:
            down.append((other, data))

    print("\n" + "=" * 64)
    print(f"CROSS-CONNECT (first-pass)  —  AGG dome {agg['label_1']}")
    print("=" * 64)
    print(f"  at pole {pole}  |  dome capacity {agg['cblcpty1']}  |  spec {agg['spec_1']}  "
          f"|  PON {agg['pon_no']}  zone {agg['zone_no']}")
    print(f"  GPS {agg['lat']}, {agg['lon']}")
    in_cable = up[0][1] if up else (incident[0][2] if incident else None)
    out_cables = [c for _, c in down] or [c[2] for c in incident[1:]]
    print(f"  IN  feeder : {in_cable['label'] if in_cable else 'n/a'} "
          f"({in_cable['fibers'] if in_cable else 0}F)")
    for oc in out_cables:
        print(f"  OUT dist   : {oc['label']} ({oc['fibers']}F)")
    ftss = fts_by_pole.get(pole, [])
    print(f"  FTS at dome: {[f['label'] for f in ftss] or 'none mapped to this pole'}")

    # ---- 5. Build the cross-connect rows ----
    # Model: feeder fibre 1 -> FTS 1:8 input ; FTS legs 1..8 -> first 8 fibres of out dist cable.
    #        remaining feeder fibres -> EXPRESS pass-through to the out feeder (documented uncut).
    rows = []
    tray = 1
    pos = 0
    in_fibers = in_cable["fibers"] if in_cable else 0
    legs = cap_to_int(ftss[0]["cblcpty"]) if ftss else 8     # 1:8 FTS
    out0 = out_cables[0] if out_cables else None

    def add_row(rtype, inc, infib, outc, outfib, note=""):
        nonlocal tray, pos
        pos += 1
        if pos > 24:                 # 24-position tray standard
            tray += 1
            pos = 1
        _, itc, ifc, _ = fibre_id(infib) if infib else (None, None, None, None)
        _, otc, ofc, _ = fibre_id(outfib) if outfib else (None, None, None, None)
        rows.append({
            "tray": tray, "pos": pos, "type": rtype,
            "in_cable": inc, "in_fiber": infib, "in_tube_col": itc, "in_fiber_col": ifc,
            "out_cable": outc, "out_fiber": outfib, "out_tube_col": otc, "out_fiber_col": ofc,
            "splice": "fusion", "loss_dB_max": 0.30, "loss_dB_target": 0.10,
            "note": note,
        })

    if in_cable and ftss:
        # feeder fibre 1 -> FTS input (fusion)
        add_row("feeder->FTS", in_cable["label"], 1, ftss[0]["label"], None,
                "feeder fibre 1 spliced to FTS 1:%d input" % legs)
        # FTS legs -> distribution fibres (sequential)
        if out0:
            for leg in range(1, legs + 1):
                add_row("FTS->dist", ftss[0]["label"], None, out0["label"], leg,
                        "FTS output leg %d" % leg)
        # express / pass-through: remaining feeder fibres continue uncut to next feeder
        express = max(0, in_fibers - 1)
        if express and out_cables:
            for f in range(2, 2 + min(express, 6)):   # document first 6 for the PoC
                add_row("EXPRESS", in_cable["label"], f, in_cable["label"], f,
                        "pass-through — no splice required")
            note_extra = "" if express <= 6 else f" (+{express-6} more express fibres)"
            print(f"  express fibres : {express} pass-through{note_extra}")

    print(f"\n  {'TRAY':>4} {'POS':>3} {'TYPE':<12} {'IN CABLE':<28} {'IN#':>3} "
          f"{'OUT CABLE':<28} {'OUT#':>4} {'COLOUR':<8}")
    for r in rows[:20]:
        print(f"  {r['tray']:>4} {r['pos']:>3} {r['type']:<12} "
              f"{(r['in_cable'] or '')[:28]:<28} {r['in_fiber'] or ''!s:>3} "
              f"{(r['out_cable'] or '')[:28]:<28} {r['out_fiber'] or ''!s:>4} "
              f"{(r['out_fiber_col'] or r['in_fiber_col'] or ''):<8}")
    if len(rows) > 20:
        print(f"  ... {len(rows)-20} more rows")

    # ---- 6. Persist ----
    nx.write_graphml(G, OUT_GRAPHML)
    json.dump({
        "agg_dome": agg["label_1"], "pole": pole,
        "in_cable": in_cable["label"] if in_cable else None,
        "out_cables": [c["label"] for c in out_cables],
        "fts": [f["label"] for f in ftss],
        "rows": rows,
        "graph_stats": {"nodes": G.number_of_nodes(), "edges": G.number_of_edges(),
                        "components": len(comps)},
    }, open(OUT_XC, "w"), indent=2)
    print(f"\n  saved cross-connect -> {OUT_XC}")
    print(f"  saved route graph   -> {OUT_GRAPHML}")
    print("\n[PoC complete]  Sequential assignment used; round-robin reserved for")
    print("multi-splitter domes. Confirm tray rules vs Fibertime template before v3.")


if __name__ == "__main__":
    main()
