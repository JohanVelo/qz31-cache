"""Optical power-budget model (ITU-T G.984 GPON) — the competitive moat.

Pure, dependency-free functions so they're trivially testable and robust
across QGIS versions. The QGIS-facing menu action lives in
fiber_network_plugin.py (`_run_power_budget_check`) and calls into here.

GPON Class B+ reference (ITU-T G.984.2):
  - OLT launch power (downstream 1490 nm): +1.5 … +5 dBm
  - ONT receiver sensitivity:              -28 dBm
  - => loss budget ~= 28 dB (we use 28.0 dB as the Class B+ budget)

Per-element insertion losses (industry-standard worst-case):
  fiber  0.35 dB/km (1310 nm upstream — the worse direction)
  splice 0.10 dB each
  conn   0.50 dB each
  1:2  ~3.5  | 1:4  ~7.0  | 1:8  ~10.5 | 1:16 ~13.5 | 1:32 ~17.5 | 1:64 ~21.0 dB
"""

# ── reference constants ──────────────────────────────────────────────────────
# GPON optical-budget classes (ITU-T G.984.2 + G.984.2 Amd). A 1:128 split
# (Combo 1 = 1:8 × 1:16) burns ~24 dB in splitters alone, so it CANNOT run on
# Class B+ (28 dB) over any real distance — it needs Class C+ (32 dB) optics.
# We therefore default the budget to C+; expose the others for completeness.
BUDGET_CLASS = {'B+': 28.0, 'C+': 32.0, 'N1': 33.0, 'N2': 35.0, 'E1': 38.0}
BUDGET_DB = BUDGET_CLASS['C+']   # default — the class a 1:128 design requires
FIBER_DB_PER_KM = 0.35
SPLICE_DB = 0.10
CONNECTOR_DB = 0.50
ROUTE_FACTOR = 1.30        # routed cable is ~1.3× the straight-line distance

# Splitter insertion loss by split ratio (dB), incl. excess loss.
SPLITTER_DB = {2: 3.5, 4: 7.0, 8: 10.5, 16: 13.5, 32: 17.5, 64: 21.0}

# Velocity "Combo 1" for informal settlements: 1×1:8 FTS + 8×1:16 STS.
COMBO1_SPLITTERS = (8, 16)


def splitter_loss(ratios):
    """Total dB for a chain of split ratios, e.g. (8, 16) → 24.0 dB."""
    return sum(SPLITTER_DB.get(int(r), 0.0) for r in ratios)


def path_loss(fiber_km, splitters=COMBO1_SPLITTERS, connectors=4, splices=4):
    """Total optical loss (dB) for one ONT path.

    fiber_km   : routed fibre length POP→ONT (km)
    splitters  : iterable of split ratios in the path (FTS then STS)
    connectors : mated connector pairs (OLT, splitter in/out, ONT) ~4
    splices    : fusion splices along the path
    """
    return (
        fiber_km * FIBER_DB_PER_KM
        + splitter_loss(splitters)
        + connectors * CONNECTOR_DB
        + splices * SPLICE_DB
    )


def margin(loss_db, budget_db=BUDGET_DB):
    """Remaining margin (dB). Positive = link closes with headroom."""
    return budget_db - loss_db


def classify(margin_db):
    """green = healthy (>3 dB), amber = tight (0–3 dB), red = fails (<0)."""
    if margin_db < 0:
        return 'red'
    if margin_db < 3.0:
        return 'amber'
    return 'green'


def budget_for_ont(straight_km, splitters=COMBO1_SPLITTERS,
                   connectors=4, splices=4, route_factor=ROUTE_FACTOR):
    """Convenience: from straight-line POP→ONT km, return (loss, margin, class).

    Applies the routing factor to approximate true cable length when only the
    straight-line distance is known.
    """
    fiber_km = straight_km * route_factor
    loss = path_loss(fiber_km, splitters, connectors, splices)
    m = margin(loss)
    return loss, m, classify(m)


def max_reach_km(splitters=COMBO1_SPLITTERS, connectors=4, splices=4,
                 budget_db=BUDGET_DB):
    """Longest routed fibre (km) that still closes the link for this design."""
    fixed = splitter_loss(splitters) + connectors * CONNECTOR_DB + splices * SPLICE_DB
    return max(0.0, (budget_db - fixed) / FIBER_DB_PER_KM)
