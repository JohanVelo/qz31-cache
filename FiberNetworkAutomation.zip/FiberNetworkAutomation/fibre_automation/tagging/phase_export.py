"""phase_export — write the Combined + Phase N shapefile folders for a phase split.

    <out>/Combined/<layer name>.shp        every feature of every chosen layer
    <out>/Phase 1/<short name> PH1.shp     only the features whose Phase is Phase 1
    <out>/Phase 1/Phase 1.shp              that phase's polygon
    <out>/Phase split report.csv           layer × phase counts + every flagged feature

Layout and names copy the hand-made Lulekani split (JJ, 2026-10-27): the town prefix
is dropped inside the phase folders ("Lulekanie Poles" → "Poles PH1").

Grouping reads the Phase value ACTUALLY ON DISK after tagging, so the folders always
match the attribute table — including a hand-set value the user chose to keep.

Safety:
  * refuses to write a file that is loaded in the open project (Windows locks it and a
    half-written .shp corrupts the live layer);
  * an existing Combined / Phase N folder is MOVED to ``_previous/<stamp>/``, never deleted;
  * every written file is re-opened and counted; the sums must equal Combined.
"""
import csv
import os
import re
import time

try:
    from . import phase_split as ps
except ImportError:                                    # flat / path import
    import phase_split as ps

COMBINED = "Combined"
PREVIOUS = "_previous"
REPORT = "Phase split report.csv"
_BAD_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]+')


def safe_name(name):
    s = _BAD_CHARS.sub("_", str(name or "")).strip().strip(".")
    return (s or "layer")[:120]


def common_prefix_token(names):
    """The town word most layer names start with ("Lulekanie", "Mahikeng"), else ''.

    Only stripped when at least 3 layers and 60% of them share it, and it is a word
    rather than a number, so "16 Way Splitter" never loses its "16".
    """
    firsts = {}
    for n in names:
        parts = str(n).split(None, 1)
        if len(parts) == 2 and not parts[0].isdigit() and len(parts[0]) >= 3:
            firsts[parts[0]] = firsts.get(parts[0], 0) + 1
    if not firsts:
        return ""
    tok, n = max(firsts.items(), key=lambda kv: kv[1])
    if n >= 3 and n >= 0.6 * len(names):
        return tok
    return ""


def short_name(name, prefix):
    if prefix and str(name).startswith(prefix + " "):
        rest = str(name)[len(prefix) + 1:].strip()
        if rest:
            return rest
    return str(name)


def phase_suffix(phase):
    n = ps.phase_number(phase)
    return "PH%d" % n if n is not None else safe_name(phase)


def folder_name(phase):
    return safe_name(phase)


class ExportItem:
    """One layer: where its Combined file goes and which features go to which phase."""

    def __init__(self, layer_id, name):
        self.layer_id = layer_id
        self.name = name
        self.combined_path = ""
        self.total = 0
        self.by_phase = {}          # phase label → [fid, …]
        self.phase_paths = {}       # phase label → path
        self.blank = []             # fids with no Phase value (Combined only)
        self.raw_by_phase = {}      # phase label → exact stored values (for tree filters)
        self.field = None           # field the phase is read from on this layer
        self.is_source = False
        self.in_place = False       # its live file already IS <out>/Combined/<name>.shp


class ExportPlan:
    def __init__(self, out_dir):
        self.out_dir = out_dir
        self.items = []             # ExportItem, in layer order
        self.phases = []            # folder phases, natural order
        self.existing = []          # existing folders that will be moved aside
        self.existing_files = []    # single files moved aside (folder holds live data)
        self.errors = []
        self.warnings = []

    def files_to_write(self):
        out = []
        for it in self.items:
            if not it.in_place:
                out.append(it.combined_path)
            out.extend(it.phase_paths.values())
        return out


def plan_export(project, plan, layer_ids, out_dir):
    """Decide every output path and the features each holds. Writes NOTHING.

    ``plan`` is the PhasePlan (gives the phases and the phase-polygon source);
    ``layer_ids`` are the layers to export, in the order they should be listed.
    Grouping reads each layer's Phase field as it is NOW, so call this after Apply.
    """
    from qgis.core import QgsVectorLayer
    ep = ExportPlan(os.path.normpath(out_dir))
    if not out_dir:
        ep.errors.append("Choose a folder to write the phase folders into.")
        return ep
    keymap = {ps.phase_key(p): p for p in plan.phases}
    found_extra = {}
    layers = []
    for lid in layer_ids:
        lyr = project.mapLayer(lid)
        if isinstance(lyr, QgsVectorLayer) and lyr.isValid():
            layers.append(lyr)
    prefix = common_prefix_token([lyr.name() for lyr in layers])
    used_combined, used_phase = {}, {}
    src_ids = set(plan.source_layer_ids)
    # A layer whose file already lives in <out>/Combined (Lulekani keeps its live data
    # there) is updated IN PLACE: tagging already wrote its Phase column, so Combined
    # is not rewritten and that folder is never moved.
    comb_dir = os.path.normcase(os.path.join(ep.out_dir, COMBINED))
    live_comb = {}
    for lyr in layers:
        lf = ps.layer_file(lyr)
        if (lf and lf.lower().endswith(".shp") and not (lyr.subsetString() or "").strip()
                and os.path.normcase(os.path.dirname(lf)) == comb_dir):
            live_comb[lyr.id()] = lf
            used_combined[os.path.splitext(os.path.basename(lf))[0].lower()] = True
    for lyr in layers:
        it = ExportItem(lyr.id(), lyr.name())
        it.is_source = lyr.id() in src_ids
        cname = safe_name(lyr.name())
        if lyr.id() in live_comb:
            it.in_place = True
            cname = os.path.splitext(os.path.basename(live_comb[lyr.id()]))[0]
        elif cname.lower() in used_combined:
            grp = _parent_group_name(project, lyr)
            cname = safe_name("%s (%s)" % (lyr.name(), grp)) if grp else cname
            k = 2
            base = cname
            while cname.lower() in used_combined:
                cname = "%s (%d)" % (base, k)
                k += 1
        used_combined[cname.lower()] = True
        it.combined_path = (live_comb[lyr.id()] if it.in_place
                            else os.path.join(ep.out_dir, COMBINED, cname + ".shp"))
        it.total = lyr.featureCount()
        if it.is_source:
            it.field = ps._field_lookup(lyr, plan.source.field) if plan.source.kind == "field" else None
            for (slid, label), fids in plan.source_fids.items():
                if slid == lyr.id():
                    it.by_phase.setdefault(label, []).extend(fids)
                    if it.field is not None:
                        from qgis.core import QgsFeatureRequest
                        for f in lyr.getFeatures(QgsFeatureRequest().setFilterFids(fids)):
                            it.raw_by_phase.setdefault(label, set()).add(f[it.field])
            # polygons with no phase value (Mahikeng has a blank one) are Combined-only
            placed = {fid for fids in it.by_phase.values() for fid in fids}
            it.blank = [f.id() for f in lyr.getFeatures() if f.id() not in placed]
        else:
            real = ps._field_lookup(lyr, ps.OUT_FIELD)
            if real is None:
                ep.warnings.append("'%s' has no Phase field — it goes to Combined only."
                                   % lyr.name())
            from qgis.core import QgsFeatureRequest
            req = QgsFeatureRequest().setFlags(QgsFeatureRequest.Flag.NoGeometry)
            if real is not None:
                req.setSubsetOfAttributes([real], lyr.fields())
            n = 0
            for f in lyr.getFeatures(req):
                n += 1
                raw = ps.norm_text(f[real]) if real is not None else None
                if raw is None:
                    it.blank.append(f.id())
                    continue
                key = ps.phase_key(raw)
                label = keymap.get(key)
                if label is None:
                    label = found_extra.setdefault(key, raw)
                it.by_phase.setdefault(label, []).append(f.id())
                it.raw_by_phase.setdefault(label, set()).add(f[real])
            it.total = n
            it.field = real
        short = short_name(lyr.name(), prefix)
        for label in it.by_phase:
            if it.is_source:
                fname = safe_name(label)
            else:
                fname = safe_name("%s %s" % (short, phase_suffix(label)))
            key = (label, fname.lower())
            if key in used_phase:
                fname = safe_name("%s %s" % (cname, phase_suffix(label)))
            used_phase[(label, fname.lower())] = True
            it.phase_paths[label] = os.path.join(ep.out_dir, folder_name(label), fname + ".shp")
        ep.items.append(it)
    if found_extra:
        ep.warnings.append(
            "Phase values with no phase polygon: %s — they still get their own folder."
            % ", ".join(sorted(found_extra.values(), key=ps.natural_key)))
    phases = set()
    for it in ep.items:
        phases.update(it.by_phase)
    ep.phases = sorted(phases, key=ps.natural_key)

    # refuse to write over anything loaded in the open project
    loaded = {}
    for lyr in project.mapLayers().values():
        if isinstance(lyr, QgsVectorLayer):
            p = ps.layer_file(lyr)
            if p:
                loaded[os.path.normcase(p)] = lyr.name()
    open_in = {}
    for p, name in loaded.items():
        open_in.setdefault(os.path.dirname(p), []).append(name)
    clash_dirs = []
    for path in ep.files_to_write():
        hit = loaded.get(os.path.normcase(os.path.normpath(path)))
        if not hit:
            continue
        d = os.path.dirname(os.path.normpath(path))
        if os.path.basename(d) == COMBINED:
            ep.errors.append("'%s' is open in this project and would be overwritten (%s). "
                             "Choose another folder." % (hit, path))
        elif d not in clash_dirs:
            clash_dirs.append(d)
    for d in clash_dirs:
        ep.errors.append(_open_folder_msg(os.path.basename(d),
                                          open_in.get(os.path.normcase(d), [])))
    if any(ep.errors):
        return ep
    # Folders already holding files are moved aside, never deleted. A folder holding a
    # file that is OPEN in this project is never moved (that would pull the data out
    # from under the project): in Combined only the files being replaced move aside;
    # a Phase folder with open layers is refused with a clear way out.
    for sub in [COMBINED] + [folder_name(p) for p in ep.phases]:
        d = os.path.join(ep.out_dir, sub)
        if not (os.path.isdir(d) and os.listdir(d)):
            continue
        names = open_in.get(os.path.normcase(os.path.normpath(d)))
        if not names:
            ep.existing.append(d)
        elif sub == COMBINED:
            ep.existing_files.extend(it.combined_path for it in ep.items
                                     if not it.in_place and os.path.exists(it.combined_path))
        else:
            ep.errors.append(_open_folder_msg(sub, names))
    return ep


def _open_folder_msg(sub, names):
    names = sorted(names)
    return ("The '%s' folder holds layers that are open in this project (%s). Remove "
            "those layers from the project — the new Phases group replaces them — or "
            "choose another folder." % (sub, ", ".join(names[:4]) + (" …" if len(names) > 4 else "")))


def _parent_group_name(project, layer):
    try:
        node = project.layerTreeRoot().findLayer(layer.id())
        parent = node.parent() if node else None
        return parent.name() if parent is not None and parent.name() else ""
    except Exception:
        return ""


# ── write ────────────────────────────────────────────────────────────────────
class ExportResult:
    def __init__(self):
        self.written = []           # (path, features)
        self.moved = []             # (old folder, new place)
        self.errors = []
        self.checks = []            # (layer, combined, sum of phases + blanks, ok)
        self.report_path = ""
        self.elapsed_s = 0.0

    @property
    def ok(self):
        return not self.errors and all(c[3] for c in self.checks)


def _write_layer(layer, it, ctx):
    """Write Combined + every phase file of one layer in ONE pass over its features.

    Returns {path: error message} for files that failed (empty dict = all written).
    One read per layer, not one per file: about 5x faster on a town with 9 phases.
    """
    from qgis.core import QgsVectorFileWriter
    opts = QgsVectorFileWriter.SaveVectorOptions()
    opts.driverName = "ESRI Shapefile"
    opts.fileEncoding = "UTF-8"
    no_error = getattr(getattr(QgsVectorFileWriter, "WriterError", QgsVectorFileWriter),
                       "NoError", 0)
    paths = {} if it.in_place else {None: it.combined_path}
    paths.update(it.phase_paths)
    writers, failed = {}, {}
    for label, path in paths.items():
        os.makedirs(os.path.dirname(path), exist_ok=True)
        w = QgsVectorFileWriter.create(path, layer.fields(), layer.wkbType(), layer.crs(),
                                       ctx, opts)
        if w is None or w.hasError() != no_error:
            failed[path] = (w.errorMessage() if w is not None else "") or "could not create"
            continue
        writers[label] = w
    phase_of = {}
    for label, fids in it.by_phase.items():
        for fid in fids:
            phase_of[fid] = label
    comb = writers.get(None)
    for f in layer.getFeatures():
        if comb is not None and not comb.addFeature(f):
            failed.setdefault(it.combined_path, "a feature was refused")
        label = phase_of.get(f.id())
        w = writers.get(label) if label is not None else None
        if w is not None and not w.addFeature(f):
            failed.setdefault(paths[label], "a feature was refused")
    comb = w = None                           # drop loop references so files can close
    for label in list(writers):
        w = writers.pop(label)
        try:
            w.flushBuffer()
        except Exception:
            failed.setdefault(paths[label], "could not flush")
        del w                                 # closes the file before it is re-opened
    return failed


def _count(path):
    from qgis.core import QgsVectorLayer
    lyr = QgsVectorLayer(path, "check", "ogr")
    return lyr.featureCount() if lyr.isValid() else -1


def run_export(project, ep, progress=None, plan=None):
    """Write every file in ``ep`` and verify it. ``progress(done, total, text)`` → False cancels.

    ``plan`` (the PhasePlan) adds the flagged-feature rows to the report.
    """
    t0 = time.time()
    res = ExportResult()
    if ep.errors:
        res.errors.extend(ep.errors)
        return res
    stamp = time.strftime("%Y-%m-%d %H%M%S")
    for d in ep.existing:
        dest = os.path.join(ep.out_dir, PREVIOUS, stamp, os.path.basename(d))
        try:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            os.rename(d, dest)
            res.moved.append((d, dest))
        except Exception as exc:
            res.errors.append("Could not move the old '%s' folder aside (%s). Close any "
                              "program using it and run again." % (os.path.basename(d), exc))
            return res
    for path in ep.existing_files:
        base = os.path.splitext(path)[0]
        dest_dir = os.path.join(ep.out_dir, PREVIOUS, stamp, COMBINED)
        os.makedirs(dest_dir, exist_ok=True)
        for side in ps._SIDECARS:
            if os.path.exists(base + side):
                try:
                    os.rename(base + side, os.path.join(dest_dir, os.path.basename(base + side)))
                except Exception as exc:
                    res.errors.append("Could not move the old %s aside (%s)."
                                      % (os.path.basename(base + side), exc))
                    return res
        res.moved.append((path, dest_dir))
    ctx = project.transformContext()
    for i, it in enumerate(ep.items):
        if progress is not None and progress(i, len(ep.items), it.name) is False:
            res.errors.append("Cancelled — %d of %d layers written." % (i, len(ep.items)))
            break
        lyr = project.mapLayer(it.layer_id)
        if lyr is None:
            res.errors.append("'%s' left the project during the export." % it.name)
            continue
        failed = _write_layer(lyr, it, ctx)
        for path, msg in failed.items():
            res.errors.append("'%s' → %s: %s" % (it.name, os.path.basename(path), msg))
        for label, path in [(None, it.combined_path)] + list(it.phase_paths.items()):
            if path in failed:
                continue
            n = _count(path)
            want = it.total if label is None else len(it.by_phase.get(label, []))
            res.written.append((path, n))
            if n != want:
                res.errors.append("%s holds %d features, expected %d." % (path, n, want))
    # every feature lands in exactly one phase file or is a listed blank
    for it in ep.items:
        comb = dict(res.written).get(it.combined_path, -1)
        parts = sum(dict(res.written).get(p, 0) for p in it.phase_paths.values())
        total = parts + len(it.blank)
        res.checks.append((it.name, comb, total, comb == total == it.total))
    if progress is not None:
        progress(len(ep.items), len(ep.items), "report")
    res.report_path = write_report(ep, res, plan)
    res.elapsed_s = time.time() - t0
    return res


def write_report(ep, res, plan=None):
    """CSV: per-layer counts per phase, then every flagged feature."""
    path = os.path.join(ep.out_dir, REPORT)
    try:
        os.makedirs(ep.out_dir, exist_ok=True)
        with open(path, "w", newline="", encoding="utf-8-sig") as fh:
            w = csv.writer(fh)
            w.writerow(["Layer", "Combined"] + ep.phases + ["No phase", "Check"])
            checks = {c[0]: c for c in res.checks}
            for it in ep.items:
                c = checks.get(it.name)
                w.writerow([it.name, it.total]
                           + [len(it.by_phase.get(p, [])) for p in ep.phases]
                           + [len(it.blank), "OK" if (c and c[3]) else "MISMATCH"])
            if plan is not None:
                w.writerow([])
                w.writerow(["Flagged features", "Feature", "Phase given", "Why", "Detail"])
                for lp in plan.layers.values():
                    for fid, how in lp.how.items():
                        if how in (ps.HOW_NEAREST, ps.HOW_TIE, ps.HOW_NONE) or fid in lp.conflicts:
                            detail = ""
                            if how == ps.HOW_NEAREST and fid in lp.dist:
                                detail = "%.0f m outside" % lp.dist[fid]
                            if fid in lp.conflicts:
                                detail = "kept '%s' (polygon says '%s')" % lp.conflicts[fid]
                            w.writerow([lp.name, lp.labels.get(fid, fid),
                                        lp.assign.get(fid) or "", how, detail])
            if res.moved:
                w.writerow([])
                for old, new in res.moved:
                    w.writerow(["Moved aside", old, new])
        return path
    except Exception as exc:
        res.errors.append("Could not write the report: %s" % exc)
        return ""
