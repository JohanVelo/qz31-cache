"""Fetch REAL surveyed erven from the SA Chief Surveyor-General cadastre.

Verified 2026-06-14: returns the exact "blue" erven (IoU 1.00 vs the real
layer for Mohadin). This REPLACES building-anchored generation wherever CSG
has coverage. Free ArcGIS REST service, no API key. Pure requests + shapely;
runs offline in the erven_studio venv (NOT on the QGIS main thread).
"""
import requests
from shapely.geometry import Polygon, MultiPolygon

CSG_URL = ('https://dffeportal.environment.gov.za/hosting/rest/services/'
           'CSG_Cadaster/CSG_Cadastral_Data/MapServer/2/query')
PAGE = 1000   # server maxRecordCount


def _query(bbox, offset):
    params = {
        'geometry': '{},{},{},{}'.format(*bbox),
        'geometryType': 'esriGeometryEnvelope', 'inSR': '4326', 'outSR': '4326',
        'spatialRel': 'esriSpatialRelIntersects',
        'outFields': 'PRCL_KEY,PRCL_TYPE,GEOM_AREA',
        'returnGeometry': 'true', 'resultOffset': offset,
        'resultRecordCount': PAGE, 'f': 'json',
    }
    return requests.get(CSG_URL, params=params, timeout=60).json()


def _poly(rings):
    """esriJSON rings -> shapely Polygon/MultiPolygon (rings can hold holes)."""
    if not rings:
        return None
    # ArcGIS: clockwise = outer, counter-clockwise = hole. Use first as outer,
    # the rest as holes if they fall inside; good enough for erven (rarely holed).
    outer = Polygon(rings[0])
    holes = [r for r in rings[1:]]
    try:
        p = Polygon(rings[0], holes) if holes else outer
        return p if p.is_valid else p.buffer(0)
    except Exception:
        return outer if outer.is_valid else outer.buffer(0)


def fetch_erven(bbox, max_pages=50):
    """Fetch all CSG parcels intersecting bbox=(xmin,ymin,xmax,ymax) in EPSG:4326.
    Returns list of dicts: {geometry: shapely(4326), prcl_key, prcl_type, area}.
    Paginates past the 1000-record cap."""
    out, offset = [], 0
    for _ in range(max_pages):
        j = _query(bbox, offset)
        feats = j.get('features', [])
        if not feats:
            break
        for f in feats:
            g = _poly(f.get('geometry', {}).get('rings'))
            if g is None or g.is_empty:
                continue
            a = f.get('attributes', {})
            out.append({'geometry': g, 'prcl_key': a.get('PRCL_KEY'),
                        'prcl_type': a.get('PRCL_TYPE'), 'area': a.get('GEOM_AREA')})
        if not j.get('exceededTransferLimit') and len(feats) < PAGE:
            break
        offset += PAGE
    return out


def fetch_as_geojson(bbox, max_pages=50):
    """Same, as a GeoJSON FeatureCollection (EPSG:4326) for loading into QGIS."""
    feats = fetch_erven(bbox, max_pages)
    return {'type': 'FeatureCollection', 'features': [
        {'type': 'Feature', 'properties': {k: v for k, v in f.items() if k != 'geometry'},
         'geometry': _to_geojson(f['geometry'])} for f in feats]}


def _to_geojson(geom):
    if isinstance(geom, MultiPolygon):
        return {'type': 'MultiPolygon',
                'coordinates': [[list(p.exterior.coords)] for p in geom.geoms]}
    return {'type': 'Polygon', 'coordinates': [list(geom.exterior.coords)]}


if __name__ == '__main__':
    import sys
    bbox = tuple(float(x) for x in sys.argv[1].split(',')) if len(sys.argv) > 1 \
        else (27.02, -26.74, 27.08, -26.70)
    erven = fetch_erven(bbox)
    print(f'fetched {len(erven)} CSG erven for {bbox}')
    if erven:
        areas = sorted(e['area'] or e['geometry'].area for e in erven)
        print('area median:', round(areas[len(areas) // 2], 1),
              '| types:', set(e['prcl_type'] for e in erven if e['prcl_type']))
