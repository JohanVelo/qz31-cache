"""Fibre Time Step 1c — Place ONT + Home Connection centroids from buildings.

Runs automatically at the end of Step 1b when the project is FibreTime.
Also callable standalone after Step 1b has populated Buildings + Erven.

STATUS: [x] BUILT
"""

from qgis.core import (
    QgsCoordinateTransform,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsSpatialIndex,
)


try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass


def _get(name):
    layers = QgsProject.instance().mapLayersByName(name)
    return layers[0] if layers else None


def _refuse(text):
    """Say why the step stopped: in the log and, when QGIS is there, on the message bar."""
    print("  ✗ " + text)
    try:
        from qgis.core import Qgis
        from qgis.utils import iface
        if iface is not None:
            iface.messageBar().pushMessage("Velocity Nexus", text, level=Qgis.MessageLevel.Warning, duration=0)
    except Exception:
        _swallowed_note()


def _crs_name(crs):
    return crs.authid() or crs.description() or "an unnamed CRS"


def _same_crs(crs_a, crs_b, probe):
    """Do the two CRSs put a point at the same coordinates?  Equal CRS objects do; so do two
    descriptions of one CRS (EPSG:2052 from a GeoPackage and the same CRS read back from a shapefile's
    .prj are different objects) - tested by converting one point (probe) and seeing it stay put."""
    if crs_a == crs_b:
        return True
    try:
        moved = QgsCoordinateTransform(crs_a, crs_b, QgsProject.instance()).transform(probe)
        return abs(moved.x() - probe.x()) <= 1e-6 and abs(moved.y() - probe.y()) <= 1e-6
    except Exception:
        _swallowed_note()
        return False


def ft_step_01c_ont():
    """Place one ONT + Home Connection centroid per primary building.

    Safe to re-run: an erf whose polygon already holds an ONT or a Home Connection
    point - wherever on the erf it sits - gets nothing more.
    Uses pointOnSurface() so the point always lands inside the footprint.
    Erven fallback: any erf with no Overture building still gets a centroid. An erf
    counts as served by its own polygon, never by its Label (labels repeat, or are empty).
    Stops with a message when the layers it reads and writes are not all in one CRS.
    """
    print(f"\n{'═' * 55}")
    print("  FT STEP 1c — ONT / Home Connection Centroids")
    print(f"{'═' * 55}")

    bld_lyr   = _get("Buildings")
    ont_lyr   = _get("ONT v1")
    hc_lyr    = _get("Home Connection v1")
    erven_lyr = _get("Erven")

    if bld_lyr is None:
        print("  ✗ 'Buildings' layer not found — run Step 1 first.")
        return
    if ont_lyr is None:
        print("  ✗ 'ONT v1' layer not found — run Step 1 first.")
        return
    has_buildings = bld_lyr.featureCount() > 0
    has_erven     = erven_lyr is not None and erven_lyr.featureCount() > 0
    if not has_buildings and not has_erven:
        print("  ✗ No buildings or erven yet — run Step 1b first.")
        return
    if not has_buildings:
        print("  ℹ  No Overture buildings — using erven centroids as fallback.")

    try:
        from fibre_automation.startup import SESSION
        area = SESSION.get("area_code") or "ONT"
    except Exception:
        area = "ONT"

    # One CRS for everything (2.5.379): this step copies building / erf coordinates straight into
    # ONT v1 and Home Connection v1 and tests points against erven without converting, so layers in
    # different CRSs gave points in the wrong place. It stops instead.
    taking_part = [("ONT v1", ont_lyr)]
    if hc_lyr is not None:
        taking_part.append(("Home Connection v1", hc_lyr))
    if has_buildings:
        taking_part.append(("Buildings", bld_lyr))
    if has_erven:
        taking_part.append(("Erven", erven_lyr))
    known = [(name, lyr.crs()) for name, lyr in taking_part if lyr.crs().isValid()]
    probe = (erven_lyr if has_erven else bld_lyr).extent().center()
    if any(not _same_crs(known[0][1], crs, probe) for _name, crs in known[1:]):
        _refuse("ONT / Home Connection points were NOT placed: these layers are not in the same CRS ("
                + ", ".join("%s %s" % (name, _crs_name(crs)) for name, crs in known)
                + "). Put them in one CRS, then run this step again. Nothing was added.")
        print(f"{'═' * 55}\n")
        return

    prim_idx = bld_lyr.fields().indexOf("is_primary")

    # Build spatial index on erven
    erven_by_fid    = {}
    erven_index     = None
    erven_label_idx = -1
    if erven_lyr and erven_lyr.featureCount() > 0:
        erven_label_idx = erven_lyr.fields().indexOf("Label")
        erven_by_fid    = {f.id(): f for f in erven_lyr.getFeatures()}
        erven_index     = QgsSpatialIndex()
        for f in erven_by_fid.values():
            erven_index.addFeature(f)

    def _erven_holding(point_geom):
        """Every erf whose polygon contains this point (parcels can overlap, so there may be two)."""
        if erven_index is None:
            return []
        return [fid for fid in erven_index.intersects(point_geom.boundingBox())
                if erven_by_fid[fid].geometry().contains(point_geom)]

    # Build set of positions already in ONT v1 (re-run guard)
    existing_pts: set = set()
    ont_lat_idx = ont_lyr.fields().indexOf("lat")
    ont_lon_idx = ont_lyr.fields().indexOf("lon")
    for feat in ont_lyr.getFeatures():
        lat = feat[ont_lat_idx] if ont_lat_idx >= 0 else None
        lon = feat[ont_lon_idx] if ont_lon_idx >= 0 else None
        if lat is not None and lon is not None:
            try:
                existing_pts.add((round(float(lon), 5), round(float(lat), 5)))
            except (TypeError, ValueError):
                pass
    # ... the positions of the points themselves (lat/lon above are stored rounded to 8 places, and
    # rounding THAT to 5 does not always give what rounding the real coordinate to 5 gives) ...
    # ... and, the rule that matters (2.5.379, review #572): an erf whose polygon CONTAINS an ONT or a
    # Home Connection point is served - by a building ONT, an erf-centre ONT, or one the planner
    # moved or drew by hand. Nothing more is added on a served erf.
    served_erven: set = set()
    for placed_lyr in (ont_lyr, hc_lyr):
        if placed_lyr is None:
            continue
        for feat in placed_lyr.getFeatures():
            if not feat.hasGeometry():
                continue
            placed = feat.geometry()           # held in a name while its vertices are read
            for vertex in placed.vertices():
                existing_pts.add((round(vertex.x(), 5), round(vertex.y(), 5)))
            served_erven.update(_erven_holding(placed))

    # Collect building centroids not yet placed
    to_add = []  # list of (QgsPointXY, erf_label_or_None)
    covered_erven: set = set()      # erven that get a building point in THIS run (by polygon, not label)
    for feat in bld_lyr.getFeatures():
        if not feat.hasGeometry():
            continue
        if prim_idx >= 0 and feat[prim_idx] != 1:
            continue
        pt  = feat.geometry().pointOnSurface().asPoint()
        key = (round(pt.x(), 5), round(pt.y(), 5))
        if key in existing_pts:
            continue

        homes = _erven_holding(QgsGeometry.fromPointXY(pt))
        if any(fid in served_erven for fid in homes):
            continue                # its erf already holds an ONT / Home Connection somewhere

        erf_label = None
        if homes:
            raw = erven_by_fid[homes[0]][erven_label_idx] if erven_label_idx >= 0 else None
            erf_label = str(raw) if raw is not None else None

        to_add.append((pt, erf_label))
        covered_erven.update(homes)

    # Erven fallback: any erf with no Overture building gets a centroid
    if erven_lyr and erven_index is not None:
        for fid, erf_feat in erven_by_fid.items():
            if not erf_feat.hasGeometry():
                continue
            if fid in served_erven or fid in covered_erven:
                continue
            raw_label = erf_feat[erven_label_idx] if erven_label_idx >= 0 else None
            erf_label = str(raw_label) if raw_label is not None else None
            pt  = erf_feat.geometry().pointOnSurface().asPoint()
            key = (round(pt.x(), 5), round(pt.y(), 5))
            if key in existing_pts:
                continue
            to_add.append((pt, erf_label))

    if not to_add:
        n = ont_lyr.featureCount()
        print(f"  (all {n:,} ONT centroids already placed — nothing to do)")
        print(f"{'═' * 55}\n")
        return

    # Sort north → south for deterministic output order
    to_add.sort(key=lambda x: (-x[0].y(), x[0].x()))

    # Derive next sequence from the highest existing label suffix, not the
    # feature count — count underestimates the max when ONTs have been deleted,
    # which would otherwise re-issue label strings that collide with survivors.
    ont_label_idx = ont_lyr.fields().indexOf("label")
    existing_seqs = []
    if ont_label_idx >= 0:
        for feat in ont_lyr.getFeatures():
            raw = feat[ont_label_idx]
            if raw is None:
                continue
            try:
                existing_seqs.append(int(str(raw).rsplit(".", 1)[-1]))
            except (ValueError, IndexError):
                continue
    next_seq = max(existing_seqs, default=ont_lyr.featureCount()) + 1

    def _make_feat(lyr, pt, label):
        nf = QgsFeature(lyr.fields())
        nf.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(pt.x(), pt.y())))
        fields = lyr.fields()

        def _set(name, val):
            idx = fields.indexOf(name)
            if idx >= 0:
                nf.setAttribute(idx, val)

        _set("label",   label)
        _set("type",    "Home Connection")
        _set("subtyp",  "ONT")
        _set("spec",    "Nokia ONT G-2425G-A")
        _set("lat",     round(pt.y(), 8))
        _set("lon",     round(pt.x(), 8))
        _set("status",  "planned")
        return nf

    ont_feats = []
    hc_feats  = []

    for pt, erf_label in to_add:
        label = f"{area}.ONT.{next_seq:05d}"
        next_seq += 1
        ont_feats.append(_make_feat(ont_lyr, pt, label))
        if hc_lyr is not None:
            hc_feats.append(_make_feat(hc_lyr, pt, label))

    BATCH = 2000
    for i in range(0, len(ont_feats), BATCH):
        ont_lyr.dataProvider().addFeatures(ont_feats[i:i + BATCH])
    ont_lyr.updateExtents()
    ont_lyr.triggerRepaint()

    if hc_lyr is not None and hc_feats:
        for i in range(0, len(hc_feats), BATCH):
            hc_lyr.dataProvider().addFeatures(hc_feats[i:i + BATCH])
        hc_lyr.updateExtents()
        hc_lyr.triggerRepaint()

    print("\n  ══ ONT CENTROIDS ══")
    print(f"  ONT v1 added:              {len(ont_feats):,}")
    if hc_lyr is not None:
        print(f"  Home Connection v1 added:  {len(hc_feats):,}")
    print(f"  Total ONT v1:              {ont_lyr.featureCount():,}")
    print(f"{'═' * 55}\n")
