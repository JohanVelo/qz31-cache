"""login — one-time per-user sign-in so the plugin holds a server-verified token.

The plugin historically authenticated its my_* reads with a spoofable username
param. This dialog asks the operator for their password ONCE, exchanges it for an
HMAC token at the edge fn (/plugin-login), and stores it (backend.set_user_token).
After that the notifications / resolved-ticket reads are identity-verified.

Non-intrusive: maybe_prompt_login() asks at most once (a QgsSettings flag), offers
'Later', and never blocks startup. If the user declines, the anon fallback keeps
working — nothing breaks; they just aren't upgraded yet.
"""
from . import backend as _backend
from . import config


_ASKED_KEY = "nexus/loginPrompted"   # one-shot flag so we never nag


def _qsettings():
    from qgis.core import QgsSettings
    return QgsSettings()


def has_token():
    return bool(_backend.get_user_token())


def show_login_dialog(parent, backend, username, display_name=None):
    """Modal: ask for the password, exchange it for a token. Returns True on
    success. Safe to call anytime; no-op-ish if the user cancels."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (
        QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QHBoxLayout)

    dlg = QDialog(parent)
    dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
    dlg.setWindowTitle("Velocity Nexus — Secure sign-in")
    dlg.setMinimumWidth(360)
    v = QVBoxLayout(dlg)
    v.addWidget(QLabel(
        f"<b>Secure your account</b><br>Signing in as "
        f"<b>{display_name or username}</b>. Enter your Velocity Nexus password "
        f"once so your notifications are verified as yours."))
    pw = QLineEdit()
    pw.setEchoMode(QLineEdit.EchoMode.Password)
    pw.setPlaceholderText("password")
    v.addWidget(pw)
    msg = QLabel("")
    msg.setWordWrap(True)
    v.addWidget(msg)
    row = QHBoxLayout()
    btn_login = QPushButton("Sign in")
    btn_cancel = QPushButton("Later")
    row.addStretch(1)
    row.addWidget(btn_cancel)
    row.addWidget(btn_login)
    v.addLayout(row)

    state = {"ok": False}

    def _attempt():
        p = pw.text()
        if not p:
            msg.setText("Enter your password.")
            return
        btn_login.setEnabled(False)
        msg.setText("Signing in…")

        def _cb(ok, disp):
            try:
                if ok:
                    state["ok"] = True
                    dlg.accept()
                else:
                    msg.setText("Sign-in failed — wrong password, or account not "
                                "active. You can try again or tap Later.")
                    btn_login.setEnabled(True)
            except Exception:
                pass

        try:
            backend.plugin_login(username, p, _cb)
        except Exception:
            msg.setText("Could not reach the server — try again later.")
            btn_login.setEnabled(True)

    btn_login.clicked.connect(_attempt)
    btn_cancel.clicked.connect(dlg.reject)
    pw.returnPressed.connect(_attempt)
    dlg.exec()
    return state["ok"]


def maybe_prompt_login(parent, backend, username, display_name=None):
    """Ask ONCE (per machine) to sign in, unless already done. Returns True if a
    token now exists. Never raises; declining is fine (anon fallback continues)."""
    try:
        if not username or has_token():
            return has_token()
        s = _qsettings()
        if s.value(f"{config.SETTINGS_NS}/{_ASKED_KEY}", "", type=str) == "1":
            return False
        from qgis.PyQt.QtWidgets import QMessageBox
        s.setValue(f"{config.SETTINGS_NS}/{_ASKED_KEY}", "1")   # mark asked first
        r = QMessageBox.question(
            parent, "Velocity Nexus — secure sign-in",
            "Sign in once to verify your notifications are yours?\n\n"
            "(Optional — your ticket replies already work; this just secures them.)",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if r == QMessageBox.StandardButton.Yes:
            return show_login_dialog(parent, backend, username, display_name)
        return False
    except Exception:
        return False
