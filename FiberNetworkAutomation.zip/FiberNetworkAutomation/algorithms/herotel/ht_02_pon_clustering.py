# HeroTel: HT 2 — PON Clustering from the span (wayleave)
#
# Groups demand points into PONs by walking the drawn fibre route, so every PON
# is one continuous run of span and a boundary never cuts across one. The
# grouping engine is pure Python in ``fibre_automation.pon_wayleave``; the
# BOUNDARIES come from ``network_planner.pon_tiles`` + ``pon_merge.shrink``,
# which already shipped and carry the house style (straight edges, 4 m gap
# measured off Malmesbury V4). One implementation of what a PON looks like.


from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsFeatureSink,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsPointXY,
    QgsProcessing,
    QgsProcessingException,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber,
    QgsProcessingParameterString,
    QgsProcessingParameterVectorLayer,
    QgsProject,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import QMetaType

from .ht_base_algorithm import HeroTelBaseAlgorithm

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

#: Gap between neighbouring PONs, metres. Measured off the Malmesbury V4 `Pons`
#: layer: 4.00 m on 148 of 151 adjacent pairs, zero touching, zero overlap.
#:
#: The delivered HeroTel archive does NOT agree with this: across four client
#: packages the median gap is 1.45 m and 48% of PONs touch their neighbour
#: outright (Botchabelo 73%, Barberton 48%, Middelburg 49%, Cradock 0%).
#: JJ was shown that on 2026-09-11 and chose to keep 4.00 m for every client,
#: so this stays one number and is not preset-scoped.
DEFAULT_GAP_M = 4.0

#: Stands per PON. ⚠ MEASURED 2026-09-11 across four delivered HeroTel client
#: packages -- Middelburg 107, Botchabelo 108, Barberton 102, Cradock 91, with
#: the largest PON in each at 128/127/126/113. HeroTel plans to the 128-client
#: GPON ceiling; only 34% of their PONs land in the 80-102 band this tool used
#: to aim for. These are the HeroTel numbers and this is the HeroTel algorithm.
#: Fibertime and MOA work keeps 96/120 through its own tools.
DEFAULT_TARGET = 104
DEFAULT_MAX_STANDS = 128

#: Printed in the run log next to the gap figure. The vertex limits themselves
#: live in ``pon_wayleave.boundaries`` next to the measurement they came from,
#: so there is one place to change them rather than two that can disagree.
GAP_TOLERANCE_TEXT = '1 m'


class HT02PonClusteringAlgorithm(HeroTelBaseAlgorithm):
    """HT 2 — PON Clustering from the span.

    Assigns every demand point to a PON that follows the fibre route, then
    builds straight-edged boundaries with a gap between them.
    """

    INPUT_DEMAND = 'INPUT_DEMAND'
    INPUT_SPAN = 'INPUT_SPAN'
    INPUT_DC = 'INPUT_DC'
    INPUT_ROADS = 'INPUT_ROADS'
    INPUT_AOI = 'INPUT_AOI'
    TARGET = 'TARGET'
    MAX_STANDS = 'MAX_STANDS'
    GAP_M = 'GAP_M'
    BALANCE = 'BALANCE'
    AOI_NAME = 'AOI_NAME'
    WRITE_BACK = 'WRITE_BACK'
    OUTPUT = 'OUTPUT'

    def name(self):
        return 'ht_02_pon_clustering'

    def displayName(self):
        return 'HT 2 — PON Clustering (from span)'

    def shortHelpString(self):
        return """
        <p><b>HT 2 — PON Clustering from the span</b></p>
        <p>Groups demand points into PONs by following the fibre route, then draws
        straight-edged PON boundaries with a gap between them.</p>

        <h4>What it guarantees</h4>
        <ul>
          <li>No PON holds more than <b>Max stands</b> (default 120).</li>
          <li>Each PON's span is <b>one continuous run</b> — a boundary never cuts
              across a span, so you never break off a span to feed the next PON.</li>
          <li>PON 1 is nearest the DC and numbers increase outward, per the
              2026 OPL FTTH labelling standard.</li>
          <li>Boundaries are straight and sit <b>4 m apart</b>, matching the
              Malmesbury reference layer.</li>
        </ul>

        <h4>You only need to press Run</h4>
        <p>Every input is picked up from the project when it can be. Change
        <b>Target stands</b> if this client wants PONs a different size.</p>

        <p><i>PONs smaller than the target are expected — once the full ones are
        packed, whatever is left over forms the last PON.</i></p>

        <h4>Evening out the PON sizes</h4>
        <p>Left to itself the grouping packs PONs to the cap and leaves the
        remainder in a runt — measured on Ventersdorp, a <b>26-home</b> PON next
        to a 116-home one. With <b>Even out the PON sizes</b> ticked the runs are
        redistributed between neighbouring PONs and the PONs are then renumbered
        outward from the DC again.</p>
        <table border="1" cellpadding="3" cellspacing="0">
          <tr><th>Measured 2026-09-07</th><th>Off</th><th>On</th></tr>
          <tr><td>Ventersdorp, PONs in the 80–102 band</td>
              <td>32.5%</td><td><b>62.2%</b></td></tr>
          <tr><td>Ventersdorp, smallest PON</td><td>26</td><td><b>55</b></td></tr>
          <tr><td>Malmesbury, PONs in the 80–102 band</td>
              <td>33.3%</td><td><b>81.2%</b></td></tr>
          <tr><td>Malmesbury, smallest PON</td><td>47</td><td><b>64</b></td></tr>
        </table>
        <p>Untick it to get exactly the behaviour of earlier versions.</p>

        <h4>One known limitation</h4>
        <p>A short tail of drawn cable can end up sitting inside a neighbouring
        PON’s polygon, because the boundaries are tiled around the homes while
        the grouping follows the cable, so the two disagree at the very edge.
        Every <b>home</b> is still in the right PON, and no PON’s size, splitter
        or BOQ changes. Measured on Malmesbury with this version: 3.19% of cable
        more than 5 m inside a neighbour, against 5.95% for the same town’s
        hand-drawn PONs.</p>
        """

    def initAlgorithm(self, configuration=None):
        proj = QgsProject.instance()

        def pick(*names):
            for n in names:
                found = proj.mapLayersByName(n)
                if found:
                    return found[0]
            return None

        self.addParameter(QgsProcessingParameterVectorLayer(
            self.INPUT_DEMAND, 'Demand points (one per home)',
            [QgsProcessing.SourceType.TypeVectorPoint],
            defaultValue=pick('Demand Points', 'ONT v1', 'Demand Points - Groups of 8'),
        ))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.INPUT_SPAN, 'Span (the fibre route)',
            [QgsProcessing.SourceType.TypeVectorLine],
            defaultValue=pick('Span', 'Wayleave', 'Span v1'),
        ))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.INPUT_DC, 'DC / POP location (optional)',
            [QgsProcessing.SourceType.TypeVectorPoint],
            defaultValue=pick('POP', 'DC Location', 'DC'), optional=True,
        ))
        # Roads + AOI turn the boundaries from tiles round the houses into
        # polygons drawn on the streets. Optional: without both, the tiler runs
        # exactly as before.
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.INPUT_ROADS, 'Roads — boundaries follow the streets (optional)',
            [QgsProcessing.SourceType.TypeVectorLine],
            defaultValue=pick('road', 'Roads', 'Road', 'Streets', 'roads'),
            optional=True,
        ))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.INPUT_AOI, 'AOI — needed with the roads (optional)',
            [QgsProcessing.SourceType.TypeVectorPolygon],
            defaultValue=pick('AOI', 'Area of Interest', 'Boundary'),
            optional=True,
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.TARGET, 'Target stands per PON',
            type=QgsProcessingParameterNumber.Type.Integer,
            minValue=8, maxValue=512, defaultValue=DEFAULT_TARGET,
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.MAX_STANDS, 'Maximum stands per PON (never exceeded)',
            type=QgsProcessingParameterNumber.Type.Integer,
            minValue=8, maxValue=512, defaultValue=DEFAULT_MAX_STANDS,
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.GAP_M, 'Gap between PON boundaries (m)',
            type=QgsProcessingParameterNumber.Type.Double,
            minValue=0.0, maxValue=50.0, defaultValue=DEFAULT_GAP_M,
        ))
        self.addParameter(QgsProcessingParameterBoolean(
            self.BALANCE, 'Even out the PON sizes (recommended)',
            defaultValue=True,
        ))
        self.addParameter(QgsProcessingParameterString(
            self.AOI_NAME, 'Area name used in the PON label',
            defaultValue='', optional=True,
        ))
        # Defaults OFF. This writes through the PROVIDER: it adds two columns
        # and overwrites pon_num immediately, with no edit session and no undo
        # entry, on whatever layer the dropdown above resolved to. That is not a
        # thing to do to an operator's layer unless they asked for it.
        self.addParameter(QgsProcessingParameterBoolean(
            self.WRITE_BACK, 'Also write pon_num onto the demand layer '
                             '(overwrites it — no undo)',
            defaultValue=False,
        ))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, 'PON Zones',
            QgsProcessing.SourceType.TypeVectorPolygon,
        ))

    # ── run ────────────────────────────────────────────────────────────────

    def processAlgorithm(self, parameters, context, feedback):
        # An AVAILABILITY PROBE, not a working import: most of these names are
        # re-imported where they are used, in _block_boundaries. They are named
        # here so a half-installed engine fails once, immediately, with the
        # message below -- rather than as a bare NameError deep inside a run
        # that has already spent two minutes clustering. Do not trim this list
        # to the names this method happens to use.
        try:
            from ...fibre_automation.pon_wayleave import (  # noqa: F401
                PonWayleaveError, balanced_grouping, blocks_of_stands,
                build_boundaries, check_zone_fit, street_blocks,
                subdivide_blocks, utm_epsg_for, validate_boundaries,
                SUBDIVIDE_MAX,
            )
        except ImportError as exc:                       # pragma: no cover
            raise QgsProcessingException(
                f"The PON clustering engine could not be loaded ({exc}). "
                "Reinstall or update the plugin."
            ) from exc

        demand = self.parameterAsVectorLayer(parameters, self.INPUT_DEMAND, context)
        span = self.parameterAsVectorLayer(parameters, self.INPUT_SPAN, context)
        dc_layer = self.parameterAsVectorLayer(parameters, self.INPUT_DC, context)
        roads_layer = self.parameterAsVectorLayer(parameters, self.INPUT_ROADS, context)
        aoi_layer = self.parameterAsVectorLayer(parameters, self.INPUT_AOI, context)
        target = self.parameterAsInt(parameters, self.TARGET, context)
        max_stands = self.parameterAsInt(parameters, self.MAX_STANDS, context)
        gap_m = self.parameterAsDouble(parameters, self.GAP_M, context)
        aoi_name = (self.parameterAsString(parameters, self.AOI_NAME, context) or '').strip()
        write_back = self.parameterAsBoolean(parameters, self.WRITE_BACK, context)
        balance = self.parameterAsBoolean(parameters, self.BALANCE, context)

        if demand is None:
            raise QgsProcessingException("Choose the demand-point layer.")
        if span is None:
            raise QgsProcessingException("Choose the span layer.")
        if max_stands < target:
            raise QgsProcessingException(
                f"Maximum ({max_stands}) cannot be below the target ({target})."
            )
        if demand.featureCount() == 0:
            raise QgsProcessingException(
                f"'{demand.name()}' has no features. Check it is not filtered."
            )
        if write_back:
            frozen = self._frozen_reason(demand)
            if frozen:
                raise QgsProcessingException(
                    f"Refusing to write onto '{demand.name()}': {frozen}\n\n"
                    "That layer belongs to a delivered project whose BOQ is "
                    "approved, and this would overwrite pon_num on it with no "
                    "undo. Untick 'Also write pon_num onto the demand layer' to "
                    "produce the zones without touching it, or run against a "
                    "copy."
                )
        if not aoi_name:
            aoi_name = QgsProject.instance().baseName() or 'PON'

        # ── work out the metric CRS from the DATA, never a fixed zone ──────
        wgs84 = QgsCoordinateReferenceSystem('EPSG:4326')
        to_wgs = QgsCoordinateTransform(
            demand.crs(), wgs84, QgsProject.instance().transformContext())
        ext = demand.extent()
        try:
            ll = to_wgs.transform(ext.center())
        except Exception as exc:
            raise QgsProcessingException(
                f"Could not work out where '{demand.name()}' is on the globe "
                f"({exc}). Check the layer has a valid CRS."
            ) from exc
        try:
            epsg = utm_epsg_for(ll.x(), ll.y())
        except PonWayleaveError as exc:
            raise QgsProcessingException(str(exc)) from exc
        # The zone came from the extent CENTRE. Prove the whole extent belongs
        # in it: a project straddling a zone boundary, or one stray feature on
        # another continent, reprojects *successfully* and silently corrupts
        # every distance -- and metres are what caps a PON at MAX_STANDS.
        try:
            corners = [to_wgs.transform(QgsPointXY(x, y))
                       for x, y in ((ext.xMinimum(), ext.yMinimum()),
                                    (ext.xMinimum(), ext.yMaximum()),
                                    (ext.xMaximum(), ext.yMinimum()),
                                    (ext.xMaximum(), ext.yMaximum()))]
        except Exception as exc:
            raise QgsProcessingException(
                f"Could not project the extent of '{demand.name()}' to WGS84 "
                f"({exc}). Check the layer has a valid CRS."
            ) from exc
        try:
            check_zone_fit([p.x() for p in corners], [p.y() for p in corners], epsg)
        except PonWayleaveError as exc:
            raise QgsProcessingException(str(exc)) from exc

        metric = QgsCoordinateReferenceSystem.fromEpsgId(epsg)
        feedback.pushInfo(f"Working in EPSG:{epsg}, derived from the data.")

        tf_demand = QgsCoordinateTransform(
            demand.crs(), metric, QgsProject.instance().transformContext())
        tf_span = QgsCoordinateTransform(
            span.crs(), metric, QgsProject.instance().transformContext())

        # ── gather geometry ────────────────────────────────────────────────
        from shapely import wkt as shp_wkt

        dem_feats, dxy = [], []
        for f in demand.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsFeature(f).geometry()
            gg = g.constGet().clone()
            gg.transform(tf_demand)
            p = gg.centroid() if gg.wkbType() != QgsWkbTypes.Point else gg
            dem_feats.append(f)
            dxy.append((p.x(), p.y()))
        if not dxy:
            raise QgsProcessingException("No usable demand-point geometry.")

        span_lines = []
        for f in span.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g2 = QgsFeature(f).geometry()
            g2.transform(tf_span)
            try:
                shp = shp_wkt.loads(g2.asWkt())
            except Exception:
                _swallowed_note(); continue
            if shp.geom_type == 'MultiLineString':
                span_lines.extend([p for p in shp.geoms if p.length > 0])
            elif shp.geom_type == 'LineString' and shp.length > 0:
                span_lines.append(shp)
        if not span_lines:
            raise QgsProcessingException(
                f"'{span.name()}' has no line geometry to follow."
            )

        dc_xy = None
        if dc_layer is not None and dc_layer.featureCount():
            tf_dc = QgsCoordinateTransform(
                dc_layer.crs(), metric, QgsProject.instance().transformContext())
            for f in dc_layer.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g2 = QgsFeature(f).geometry()
                g2.transform(tf_dc)
                pt = g2.centroid().asPoint()
                dc_xy = (pt.x(), pt.y())
                break
        if dc_xy is None:
            feedback.pushWarning(
                "No DC/POP point found — PONs will be numbered outward from the "
                "middle of the route instead of from the DC."
            )

        # ── group ──────────────────────────────────────────────────────────
        def _progress(pct, msg):
            feedback.setProgress(int(pct * 0.75))
            feedback.pushInfo(msg)

        try:
            grouped = balanced_grouping(
                span_lines, dxy, dc_xy=dc_xy,
                target=target, max_stands=max_stands, balance=balance,
                progress=_progress, is_cancelled=feedback.isCanceled,
            )
        except PonWayleaveError as exc:
            raise QgsProcessingException(str(exc)) from exc
        result = grouped.grouping
        pon_of_stand = grouped.pon_of_stand
        if any(p is None for p in pon_of_stand):
            missing = sum(1 for p in pon_of_stand if p is None)
            raise QgsProcessingException(
                f"{missing:,} demand point(s) were left without a PON. Nothing "
                "was written. This usually means the span does not reach them — "
                "check the route covers the whole area."
            )
        pon_of_stand = [int(p) for p in pon_of_stand]

        for w in grouped.warnings:
            feedback.pushWarning(w)

        from collections import Counter
        sizes = Counter(pon_of_stand)
        vals = sorted(sizes.values())
        in_band = sum(1 for v in vals if 80 <= v <= 102)
        feedback.pushInfo(
            f"{len(vals)} PONs — stands per PON min {vals[0]}, "
            f"median {vals[len(vals) // 2]}, max {vals[-1]} "
            f"(maximum {max_stands}); {in_band}/{len(vals)} inside the 80–102 band."
        )
        if vals[-1] > max_stands:                         # pragma: no cover
            raise QgsProcessingException(
                f"A PON came out at {vals[-1]} stands, over the maximum of "
                f"{max_stands} — this is a bug, please report it. Nothing was "
                "written."
            )
        if balance:
            feedback.pushInfo(
                "PON sizes evened out and renumbered outward from the DC.")

        # ── boundaries ─────────────────────────────────────────────────────
        # Two ways to draw them, and the run picks whichever comes out clean.
        # Blocks first when the roads and the AOI are both there: measured on
        # Ventersdorp, block-drawn edges sit on a street 79% of the time
        # against the tiler's 57%, which is what makes them read as drawn
        # rather than tiled. If the block result fails its own check the tiler
        # runs instead and the reason is printed -- so this can never ship a
        # worse polygon than the previous version did.
        feedback.setProgress(80)
        drawn_on = 'tiles around the homes'
        geoms = None
        if roads_layer is not None and aoi_layer is not None:
            feedback.pushInfo("Drawing boundaries on the street blocks")
            try:
                geoms, pon_of_stand, note = self._block_boundaries(
                    demand, dem_feats, pon_of_stand, roads_layer, aoi_layer,
                    metric, gap_m, max_stands, feedback)
            except Exception as exc:                      # pragma: no cover
                feedback.pushWarning(
                    f"The block boundaries could not be built ({exc}). "
                    "Falling back to tiles around the homes.")
                geoms = None
            else:
                if geoms is None:
                    feedback.pushWarning(
                        f"Block boundaries rejected: {note} Falling back to "
                        "tiles around the homes.")
                else:
                    drawn_on = 'street blocks'
                    feedback.pushInfo(note)
        elif roads_layer is not None or aoi_layer is not None:
            feedback.pushInfo(
                "Both a road layer AND an AOI are needed to draw on street "
                "blocks — only one was given, so the boundaries are tiled "
                "around the homes instead.")

        if geoms is None:
            feedback.pushInfo("Drawing straight-edged boundaries")
            geoms = self._boundaries(demand, dem_feats, pon_of_stand,
                                     gap_m, feedback)

        # The block builder hands a lobe's homes to a neighbour, so the sizes
        # move. Recount from the mapping that was actually used, never from the
        # count taken before the boundaries were drawn.
        sizes = Counter(int(p) for p in pon_of_stand)
        vals = sorted(sizes.values())
        if vals[-1] > max_stands:
            raise QgsProcessingException(
                f"After drawing the boundaries a PON holds {vals[-1]} stands, "
                f"over the maximum of {max_stands}. Nothing was written.")
        feedback.pushInfo(
            f"Boundaries drawn on {drawn_on}: {len(geoms)} PONs, "
            f"stands per PON min {vals[0]}, median {vals[len(vals) // 2]}, "
            f"max {vals[-1]}.")

        # ── write ──────────────────────────────────────────────────────────
        fields = QgsFields()
        fields.append(QgsField('pon_num', QMetaType.Type.Int))
        # 'Name' with a three-digit pad is the delivered HeroTel form: measured
        # 2026-09-11, Middelburg, Barberton and Palm Ridge all ship
        # 'PON 001'..'PON 0nn' in a field called Name. 'label' keeps the older
        # '<area> PON1' text so nothing downstream that reads it breaks.
        fields.append(QgsField('Name', QMetaType.Type.QString))
        fields.append(QgsField('label', QMetaType.Type.QString))
        fields.append(QgsField('units', QMetaType.Type.Int))
        fields.append(QgsField('span_m', QMetaType.Type.Int))

        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT, context, fields,
            QgsWkbTypes.MultiPolygon, demand.crs(),
        )
        if sink is None:                                  # pragma: no cover
            raise QgsProcessingException("Could not create the PON Zones output.")

        span_m = {}
        for r, p in grouped.pon_of_run.items():
            span_m[p] = span_m.get(p, 0.0) + result.graph.runs[r].length

        written = 0
        for pon in sorted(geoms):
            g = geoms[pon]
            if g is None or g.isEmpty():
                continue
            out = QgsFeature(fields)
            out.setGeometry(g)
            out.setAttribute('pon_num', int(pon))
            out.setAttribute('Name', f"PON {int(pon):03d}")
            out.setAttribute('label', f"{aoi_name} PON{int(pon)}")
            out.setAttribute('units', int(sizes.get(int(pon), 0)))
            out.setAttribute('span_m', int(round(span_m.get(pon, 0.0))))
            sink.addFeature(out, QgsFeatureSink.Flag.FastInsert)
            written += 1

        if write_back:
            self._write_back(demand, dem_feats, pon_of_stand,
                             aoi_name, feedback)
        else:
            feedback.pushInfo(
                "The demand layer was not modified. Tick 'Also write pon_num "
                "onto the demand layer' if you want pon_num written onto it.")

        feedback.setProgress(100)
        feedback.pushInfo(f"Wrote {written} PON zones.")
        return {self.OUTPUT: dest_id}

    # ── helpers ────────────────────────────────────────────────────────────

    #: Layer names and path fragments that mark a delivered, frozen project.
    #: The ' v1' suffix is the Phase 2 convention and the delivery folder is
    #: read-only by policy; a run against either would overwrite an approved BOQ.
    FROZEN_NAME_HINTS = (' v1',)
    FROZEN_PATH_HINTS = ('potch - mohadin ph2', 'fibertime planning',
                         'baseline maps')

    def _frozen_reason(self, layer):
        """Why this layer must not be written to, or None if it is fair game.

        Checked on the SOURCE PATH as well as the name: a layer renamed in the
        project tree still points at the delivered shapefile underneath.
        """
        try:
            name = (layer.name() or '').lower()
            source = (layer.source() or '').lower().replace('\\', '/')
        except Exception:                                  # pragma: no cover
            return None
        for hint in self.FROZEN_NAME_HINTS:
            if name.endswith(hint) or f'{hint} ' in name:
                return (f"its name ends in '{hint.strip()}', the naming "
                        "convention of the delivered Phase 2 layers")
        for hint in self.FROZEN_PATH_HINTS:
            if hint in source:
                return f"it is loaded from the delivery folder ('{hint}')"
        return None


    def _block_boundaries(self, demand, dem_feats, labels, roads_layer,
                          aoi_layer, metric, gap_m, max_stands, feedback):
        """PON polygons drawn on the street blocks, or ``None`` if they fail.

        Returns ``(geoms, pon_of_stand, note)``. ``geoms`` is ``None`` when the
        result did not pass :func:`validate_boundaries`, and ``note`` then says
        which check it failed so the operator can see why the tiler ran.

        The homes mapping comes BACK CHANGED: a lobe severed by the gap cut has
        its homes handed to a neighbour with room, which is the only way to
        remove an island without taking a bite out of somebody else. The caller
        must use the returned mapping -- the PON sizes move.
        """
        from shapely import wkt as shp_wkt
        from shapely.ops import unary_union

        from ...fibre_automation.pon_wayleave import (
            SUBDIVIDE_MAX, blocks_of_stands, build_boundaries, street_blocks,
            subdivide_blocks, validate_boundaries,
        )

        proj = QgsProject.instance()

        def _to_metric(layer, want_line):
            """Shapely geometry from a layer, in the metric CRS."""
            tf = QgsCoordinateTransform(layer.crs(), metric,
                                        proj.transformContext())
            out = []
            for f in layer.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g2 = QgsFeature(f).geometry()
                g2.transform(tf)
                try:
                    shp = shp_wkt.loads(g2.asWkt())
                except Exception:
                    continue
                if shp is None or shp.is_empty:
                    continue
                if want_line and shp.geom_type in ("Polygon", "MultiPolygon"):
                    shp = shp.boundary
                if want_line:
                    if shp.geom_type == "MultiLineString":
                        out.extend([x for x in shp.geoms if x.length > 0])
                    elif shp.geom_type == "LineString" and shp.length > 0:
                        out.append(shp)
                else:
                    out.append(shp)
            return out

        roads = _to_metric(roads_layer, True)
        if not roads:
            return None, labels, "the road layer has no line geometry."
        aoi_parts = _to_metric(aoi_layer, False)
        if not aoi_parts:
            return None, labels, "the AOI layer has no polygon geometry."
        aoi = unary_union(aoi_parts)

        # A cached roads file from another town returns blocks for the wrong
        # place, silently. The question is whether the ROADS COVER THE AOI --
        # ``bbox_overlaps`` reports the fraction of its FIRST argument, so the
        # AOI goes first. Passing the roads first asks "is a quarter of the road
        # network inside the AOI", which is false for every town-wide road layer
        # and rejected Ventersdorp's own roads (8.1% of a 20,021 ha roads bbox
        # against 98.8% of the 1,632 ha AOI bbox).
        from ...fibre_automation.pon_wayleave import bbox_overlaps
        rb = unary_union(roads).bounds
        if not bbox_overlaps(aoi.bounds, rb):
            return None, labels, (
                "the roads do not cover the AOI — the road layer looks like it "
                "belongs to a different town.")

        tf_dem = QgsCoordinateTransform(demand.crs(), metric,
                                        proj.transformContext())
        stand_xy = []
        for f in dem_feats:
            g = QgsFeature(f).geometry()
            g.transform(tf_dem)
            pt = g.centroid().asPoint()
            stand_xy.append((pt.x(), pt.y()))

        blocks = street_blocks(roads, aoi)
        if not blocks:
            return None, labels, (
                "the roads and the AOI produced no street blocks.")
        block_of_stand = blocks_of_stands(blocks, stand_xy)
        placed = sum(1 for b in block_of_stand if b is not None)
        if placed < 0.9 * len(stand_xy):
            return None, labels, (
                f"only {placed:,} of {len(stand_xy):,} homes fell inside a "
                "street block, so the blocks do not describe this town.")
        blocks, block_of_stand = subdivide_blocks(
            blocks, stand_xy, block_of_stand, max_homes=SUBDIVIDE_MAX)
        feedback.pushInfo(f"{len(blocks)} street blocks, {placed:,} homes placed")

        polys, pon_of_stand, info = build_boundaries(
            [int(p) for p in labels], stand_xy, blocks, block_of_stand,
            cap=max_stands)

        ok, problems, stats = validate_boundaries(
            polys, stand_xy, pon_of_stand, gap_m=gap_m)
        if not ok:
            return None, labels, " ".join(problems)
        for w in stats.get("warnings", ()):
            feedback.pushWarning("Block boundaries: " + w)

        # metric shapely -> the demand layer's CRS, which the sink writes in
        back = QgsCoordinateTransform(metric, demand.crs(),
                                      proj.transformContext())
        geoms = {}
        for pon, shp in sorted(polys.items()):
            if shp is None or shp.is_empty:
                continue
            g = QgsGeometry.fromWkt(shp.wkt)
            if g is None or g.isEmpty():
                continue
            g.transform(back)
            geoms[int(pon)] = g
        if not geoms:
            return None, labels, "no usable polygon came back from the blocks."

        note = (
            f"Drawn on street blocks — {stats['pons']} PONs, "
            f"{stats['median_vertices']} vertices in the typical PON, "
            f"{stats['gap_in_band_share'] * 100:.0f}% of "
            f"{stats['shared_edges']} shared edges within "
            f"{GAP_TOLERANCE_TEXT} of {gap_m:.1f} m, no holes, no islands, "
            f"no overlap. {info['homes_absorbed']:,} home(s) moved to keep "
            f"every PON in one piece."
        )
        return geoms, pon_of_stand, note

    def _boundaries(self, demand, dem_feats, labels, gap_m, feedback):
        """Straight tiles from the shipped tiler, then the 4 m shrink."""
        from ...network_planner import pon_merge, pon_tiles

        by_zone = {}
        for feat, pon in zip(dem_feats, labels):
            by_zone.setdefault(int(pon), []).append(feat)

        # 12 m, not the module default of 40 m. Measured on Ventersdorp: 40 m
        # leaves 67 homes inside a NEIGHBOURING PON's polygon, 12 m leaves none
        # while still giving ~23 vertices per PON.
        tiles = pon_tiles.voronoi_zone_polygons(demand, by_zone, simplify_m=12.0)
        if not tiles:
            raise QgsProcessingException(
                "The boundary tiler could not run on this data, so no PON "
                "polygons were produced. The grouping itself succeeded — check "
                "the demand layer has valid point geometry."
            )

        out, shrunk = {}, 0
        for pon, geom in tiles.items():
            if geom is None or geom.isEmpty():
                continue
            if gap_m > 0:
                pulled, ok = pon_merge.shrink(geom, demand, gap_m=gap_m)
                if ok:
                    geom = pulled
                    shrunk += 1
            out[int(pon)] = geom
        feedback.pushInfo(
            f"{len(out)} boundaries, {shrunk} pulled in by {gap_m:.1f} m "
            f"so neighbours do not touch."
        )
        return out

    def _write_back(self, demand, dem_feats, labels, aoi_name, feedback):
        """Put pon_num / pon_label on the demand layer, bulk, never per-feature."""
        provider = demand.dataProvider()
        names = [f.name() for f in demand.fields()]
        to_add = []
        if 'pon_num' not in names:
            to_add.append(QgsField('pon_num', QMetaType.Type.Int))
        if 'pon_label' not in names:
            to_add.append(QgsField('pon_label', QMetaType.Type.QString))
        if to_add:
            if not provider.addAttributes(to_add):
                feedback.pushWarning(
                    "Could not add pon_num / pon_label to the demand layer — "
                    "the zones were still created."
                )
                return
            demand.updateFields()

        idx_num = demand.fields().indexOf('pon_num')
        idx_lab = demand.fields().indexOf('pon_label')
        if idx_num < 0:
            return
        attr_map = {}
        for feat, pon in zip(dem_feats, labels):
            vals = {idx_num: int(pon)}
            if idx_lab >= 0:
                vals[idx_lab] = f"{aoi_name} PON{int(pon)}"
            attr_map[feat.id()] = vals
        if attr_map and provider.changeAttributeValues(attr_map):
            demand.triggerRepaint()
            feedback.pushInfo(f"pon_num written onto {len(attr_map):,} demand points.")
        else:
            feedback.pushWarning("Could not write pon_num onto the demand layer.")
