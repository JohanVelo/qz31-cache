"""Find what is NOT connected — poles with nothing on them, homes with no drop.

Ticket #140 (Luke, 2026-07-28):

    "the green dot is a pole that has no geometry attached to it.. I would like a
    tool where you can highlight all the poles for me that have no other geometry
    attached to them ... and then the blue dots are demand points that should have
    drop cables going to them but in this case it looks to me that there are quite
    a few demand points with now drops."

Read-only. Nothing in this module writes; the attach step lives in
``drop_attach.py`` so the finding and the fix cannot be confused for each other.

TWO QUESTIONS, TWO DIFFERENT SHAPES OF ANSWER
---------------------------------------------
Measured on a copy of Luke's real project (Benfarm / Lulekani / Makhushane):

**Homes without a drop is a clean cliff.** A demand point either has a drop end
sitting exactly on it or it has nothing — the count does not move at all between
0.01 m and 10 m of tolerance:

    network   homes   drops   served   NO DROP
    BF         6049    5906     5905      144
    LK         5338    5226     5226      112
    MK         4989    4978     4978       11

So the threshold is derived from the data, not chosen, and 267 is not a tolerance
artefact.

**Poles are a continuum, and pretending otherwise would be inventing the rule.**
Distance from each pole to the nearest cable vertex, cumulative (re-derived
2026-07-28 against two independent implementations — an earlier reading of these
same three rows was wrong in both wide bands while its ``<=0.01m`` column was
exactly right, so trust nothing here that has not been re-measured):

    BF_Poles Length   n=3247   <=0.01m:2331  <=10m:2474  <=25m:3182
    LK_Distribution   n=2514   <=0.01m:1678  <=10m:1740  <=25m:2422
    MK_Distribution   n=2226   <=0.01m:1520  <=10m:1615  <=25m:2135

There is no cliff to snap to. Both readings are real and they answer different
questions — "nothing is snapped to this pole" (strict) versus "nothing runs
anywhere near this pole" (the green dot Luke circled). So :data:`BANDS` exposes the
choice instead of burying one threshold in the code, and the dialog lets the
planner move it.

DISTANCE IS TO A CABLE *VERTEX*, NOT TO THE CABLE LINE
------------------------------------------------------
Measured on Benfarm: 61 poles sit within 25 m of a drawn cable while being more
than 25 m from any of its vertices, and 43 of those 61 sit at 0.0 m — the cable
is drawn straight through the pole with no vertex on it. Reading distance to the
line instead of to a vertex collapses the flagged count from 65 to 5 and would
call every one of those poles connected. A cable passing over a pole is not
attached to it; an attachment is a vertex. That is Luke's green dot.

PAIRING IS MEASURED, NEVER NAMED
--------------------------------
Which cables belong to a pole layer is decided by how many of its poles have a
cable vertex within :data:`NEAR_PAIR_M`. Measured across all 54 pole/cable
combinations in that project: a layer's OWN cables cover 53.7-100% of its poles,
and every cross-network pair scores 16.0% or less. A 37-point gap, so
:data:`PAIR_MIN_COVERAGE` sits at 50% with room on both sides.

This matters because name-matching is exactly how v2.5.312 rebuilt Benfarm's
boundaries out of Lulekani's points: three networks, one project, all EPSG:4326
neighbours, and every cheap check passed.

WHICH POINTS ARE POLES IS THE OPERATOR'S CALL
---------------------------------------------
There is no attribute that reliably says "this is a pole" across clients, so the
layer is picked by the planner. Names are used only to pre-select a sensible
default — a hint the operator can see and override, never an authority.
"""

import math

from . import field_names as vf_fields

#: Probe radius for deciding whether a cable layer belongs to a pole layer.
NEAR_PAIR_M = 200.0

#: Minimum share of poles that must have a cable nearby before that cable layer is
#: treated as belonging to them. Measured: own 53.7-100%, cross-network <=16.0%.
PAIR_MIN_COVERAGE = 0.50

#: How many nearest candidates to measure properly. The spatial index ranks by
#: PLANAR distance in layer units, and in a geographic CRS a degree of longitude
#: is shorter than a degree of latitude (101.7 km vs 110.5 km at Phalaborwa), so
#: the planar-nearest is not always the truly-nearest. Measuring the best few
#: ellipsoidally removes that anisotropy — the same class of error that once put
#: the wrong pole name into 145 drop labels.
NEAREST_K = 8

#: The distance bands the pole scan offers, loosest last.
#: (key, metres, label)
BANDS = (
    ("snapped", 0.01, "nothing snapped onto it"),
    ("close", 10.0, "nothing within 10 m"),
    ("clear", 25.0, "nothing within 25 m"),
)
DEFAULT_BAND = "clear"

#: Name hints used ONLY to pre-select a default in a combo box.
POLE_HINTS = ("pole",)
CABLE_HINTS = ("cable", "feeder", "distribution", "drop", "spur", "link",
               "backhaul")
#: ``group`` is here because HeroTel names its demand points ``PON Groups Final``
#: — no "demand", no "home". Without it the combo fell back to entry 0 and
#: pre-selected DISTRIBUTION POLES as the homes layer on JJ's live Matiko
#: project, which is nonsense an operator could easily miss.
DEMAND_HINTS = ("demand", "home", "ont", "unit", "premise", "group")
DROP_HINTS = ("drop",)
SPLITTER_HINTS = ("splitter", "sts", "fts", "spl")

#: A Vuma midblock routing spine is not a connection cable and legitimately does
#: not terminate on a pole.
CABLE_EXCLUDE = ("span",)

#: Layers that are ROADS, not cables. Measuring cannot separate these: on Luke's
#: live Matiko project ``Matiko Roads Final`` scored **100%** against the
#: Distribution Poles, identically to the three real cable layers, because poles
#: are planted along roads. Keeping it would have made every pole standing beside
#: a road look "attached" and hidden the very orphans this tool exists to find —
#: a false negative, which is the dangerous direction here.
#:
#: This is the one place a NAME is allowed to overrule a measurement, and it is
#: deliberately narrow: a road hint only excludes a layer when nothing in the
#: name says "cable". So ``Matiko Roads Final`` goes, while a genuine
#: ``Road Crossing Cable`` stays.
ROAD_HINTS = ("road", "street", "centreline", "centerline")


# ── layer discovery ──────────────────────────────────────────────────────────

def _vector_layers(project, geom_type):
    out = []
    try:
        from qgis.core import QgsVectorLayer
    except Exception:
        return out
    try:
        layers = list(project.mapLayers().values())
    except Exception:
        return out
    for lyr in layers:
        try:
            if (isinstance(lyr, QgsVectorLayer) and lyr.isValid()
                    and int(lyr.geometryType()) == geom_type
                    and lyr.featureCount() > 0):
                out.append(lyr)
        except Exception:
            continue
    return out


def point_layers(project):
    return _vector_layers(project, 0)


def line_layers(project):
    return _vector_layers(project, 1)


def default_index(layers, hints, exclude=(), avoid=()):
    """Index of the first layer whose NAME matches a hint, else a safe fallback.

    A hint, not a decision: it only pre-selects a combo entry the operator can see
    and change. Every consequential pairing in this module is measured.

    ``avoid`` names a layer KIND this combo must not fall back onto. Falling back
    to entry 0 blindly is how the homes combo pre-selected ``Distribution Poles``
    on a project whose demand layer is called ``PON Groups Final`` — a wrong
    default that still looks like a considered choice.
    """
    for i, lyr in enumerate(layers):
        name = lyr.name().lower()
        if any(x in name for x in exclude):
            continue
        if any(h in name for h in hints):
            return i
    if avoid:
        for i, lyr in enumerate(layers):
            name = lyr.name().lower()
            if any(x in name for x in exclude):
                continue
            if not any(a in name for a in avoid):
                return i
    return 0


# ── geometry helpers ─────────────────────────────────────────────────────────

def _finite(x, y):
    return math.isfinite(x) and math.isfinite(y)


def vertices_of(layer, limit=None):
    """Every finite vertex of a layer as QgsPointXY, plus the count skipped.

    Non-finite coordinates are COUNTED, not silently dropped: 12 poles in the
    Makhushane network carry NaN coordinates, they render nowhere, and they would
    otherwise vanish from a spatial check without anyone noticing.
    """
    from qgis.core import QgsPointXY
    pts, skipped = [], 0
    try:
        for f in layer.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            for v in g.vertices():
                if _finite(v.x(), v.y()):
                    pts.append(QgsPointXY(v.x(), v.y()))
                else:
                    skipped += 1
            if limit and len(pts) >= limit:
                break
    except Exception:
        pass
    return pts, skipped


def line_endpoints(layer):
    """First and last vertex of every line part — where a cable actually ENDS."""
    from qgis.core import QgsPointXY
    pts, skipped = [], 0
    try:
        for f in layer.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            try:
                parts = g.asMultiPolyline() or [g.asPolyline()]
            except Exception:
                continue
            for line in parts:
                if len(line) < 2:
                    continue
                for end in (line[0], line[-1]):
                    if _finite(end.x(), end.y()):
                        pts.append(QgsPointXY(end))
                    else:
                        skipped += 1
    except Exception:
        pass
    return pts, skipped


def _measurer(layer):
    """A QgsDistanceArea that returns true metres for this layer's CRS.

    A bare QgsDistanceArea reports ellipsoid 'NONE' and then every "metre" it
    returns is a degree — the trap that has produced whole reports of 0.0 m gaps.
    """
    from qgis.core import QgsCoordinateTransformContext, QgsDistanceArea
    da = QgsDistanceArea()
    try:
        da.setSourceCrs(layer.crs(), QgsCoordinateTransformContext())
        da.setEllipsoid(layer.crs().ellipsoidAcronym() or "WGS84")
    except Exception:
        try:
            da.setEllipsoid("WGS84")
        except Exception:
            pass
    return da


def _index_of(points):
    from qgis.core import QgsFeature, QgsGeometry, QgsSpatialIndex
    idx = QgsSpatialIndex()
    for i, p in enumerate(points):
        ft = QgsFeature(i)
        ft.setGeometry(QgsGeometry.fromPointXY(p))
        idx.addFeature(ft)
    return idx


def nearest_metres(point, points, idx, da):
    """True metres from ``point`` to the nearest of ``points``. inf if none.

    Takes the K planar-nearest candidates and measures each properly, because the
    index ranks in degrees and a degree of longitude is not a degree of latitude.
    """
    if not points:
        return float("inf")
    try:
        ids = idx.nearestNeighbor(point, NEAREST_K)
    except Exception:
        ids = []
    best = float("inf")
    for i in ids:
        try:
            d = da.measureLine(point, points[i])
        except Exception:
            continue
        if d < best:
            best = d
    return best


# ── pairing ──────────────────────────────────────────────────────────────────

def _share_near(subject, reference, da, sample=400):
    """Share of ``subject`` points within :data:`NEAR_PAIR_M` of ``reference``."""
    if not subject or not reference:
        return 0.0
    idx = _index_of(reference)
    take = subject[:sample]
    hit = sum(1 for p in take
              if nearest_metres(p, reference, idx, da) <= NEAR_PAIR_M)
    return hit / float(len(take))


def coverage(pole_layer, cable_layer, sample=400):
    """How strongly a cable layer belongs to a pole layer, 0..1.

    MEASURED IN BOTH DIRECTIONS, and taking the better of the two. One direction
    alone is not enough, and this was caught by a disagreement between two
    independent implementations rather than by reasoning:

    * *poles covered by cable* answers "do these cables serve these poles" — but a
      SPARSE layer can never score high. ``BF_Backhaul Fibre`` is a single feature;
      it passes near ~20 of Benfarm's 3,247 poles, so it scored under 1% and was
      thrown away, which then wrongly reported those 20 poles as having nothing
      attached.
    * *cable vertices near a pole* answers "do these cables live among these
      poles", which is what actually decides whether they are the same network. The
      backhaul scores ~100% on that.

    Measured across all 54 pole/cable combinations in Luke's three-network project:

        direction                     own network      any foreign network
        poles covered by cable        53.7 - 100%           <= 16.0%
        cable vertices near poles     60.9 - 100%           <= 14.6%

    Taking the maximum keeps every genuine layer (worst own case 53.7%) and still
    rejects every foreign one (best foreign case 16.0%), so
    :data:`PAIR_MIN_COVERAGE` at 50% has a 37-point margin on both sides.
    """
    cab, _ = vertices_of(cable_layer)
    poles, _ = vertices_of(pole_layer, limit=sample)
    if not cab or not poles:
        return 0.0
    da = _measurer(pole_layer)
    return max(_share_near(poles, cab, da, sample),
               _share_near(cab, poles, da, sample))


def is_road_layer(name):
    """True when a layer name says ROAD and does not also say cable.

    See :data:`ROAD_HINTS`. Measurement cannot tell a road from a cable when both
    follow the same poles, so the name breaks the tie — but only in the direction
    that is safe to get wrong: dropping a road costs nothing, while keeping one
    hides real orphan poles.
    """
    low = (name or "").lower()
    if not any(h in low for h in ROAD_HINTS):
        return False
    return not any(h in low for h in CABLE_HINTS)


def cables_for(project, pole_layer, candidates=None):
    """``([layer, ...], [(name, coverage), ...])`` — the cables that belong here.

    Every line layer is measured and the ones that clear
    :data:`PAIR_MIN_COVERAGE` are kept, so a project holding three towns cannot
    leak one network's cables into another's pole scan.
    """
    scored = []
    for lyr in (candidates if candidates is not None else line_layers(project)):
        name = lyr.name().lower()
        if any(x in name for x in CABLE_EXCLUDE):
            continue
        if is_road_layer(name):
            continue
        if lyr.id() == pole_layer.id():
            continue
        try:
            cov = coverage(pole_layer, lyr)
        except Exception:
            cov = 0.0
        scored.append((lyr, cov))
    keep = [lyr for lyr, cov in scored if cov >= PAIR_MIN_COVERAGE]
    report = [(lyr.name().strip(), cov) for lyr, cov in
              sorted(scored, key=lambda t: t[1], reverse=True)]
    return keep, report


# ── the two scans ────────────────────────────────────────────────────────────

def band_metres(key):
    for k, m, _label in BANDS:
        if k == key:
            return m
    return dict((k, m) for k, m, _l in BANDS).get(DEFAULT_BAND, 25.0)


def scan_poles(pole_layer, cable_layers, band=DEFAULT_BAND):
    """Poles with nothing attached. ``(rows, stats)`` — writes nothing.

    ``rows`` is ``[(fid, QgsPointXY, distance_m, label)]`` for the poles that FAIL
    the chosen band, worst (furthest from any cable) first.
    """
    stats = {"poles": 0, "flagged": 0, "skipped_nonfinite": 0, "cable_vertices": 0,
             "band": band, "band_m": band_metres(band), "reason": "",
             "counts": {}}
    if pole_layer is None or not cable_layers:
        stats["reason"] = ("no cable layer belongs to this pole layer, so there is "
                           "nothing to check them against")
        return [], stats

    cab, cab_skipped = [], 0
    for lyr in cable_layers:
        pts, sk = vertices_of(lyr)
        cab += pts
        cab_skipped += sk
    stats["cable_vertices"] = len(cab)
    if not cab:
        stats["reason"] = "those cable layers hold no usable vertices"
        return [], stats

    idx = _index_of(cab)
    da = _measurer(pole_layer)
    limit = band_metres(band)

    rows = []
    tally = {k: 0 for k, _m, _l in BANDS}
    try:
        feats = list(pole_layer.getFeatures())
    except Exception as exc:
        stats["reason"] = f"could not read the pole layer: {exc}"
        return [], stats

    from qgis.core import QgsPointXY
    for f in feats:
        g = f.geometry()
        if not g or g.isEmpty():
            stats["skipped_nonfinite"] += 1
            continue
        try:
            p = g.asPoint() if not g.isMultipart() else g.centroid().asPoint()
        except Exception:
            try:
                p = g.centroid().asPoint()
            except Exception:
                stats["skipped_nonfinite"] += 1
                continue
        if not _finite(p.x(), p.y()):
            stats["skipped_nonfinite"] += 1
            continue
        stats["poles"] += 1
        d = nearest_metres(QgsPointXY(p), cab, idx, da)
        for k, m, _l in BANDS:
            if d > m:
                tally[k] += 1
        if d > limit:
            rows.append((f.id(), QgsPointXY(p), d, _label_of(f, pole_layer)))

    rows.sort(key=lambda r: r[2], reverse=True)
    stats["flagged"] = len(rows)
    stats["counts"] = tally
    stats["skipped_nonfinite"] += cab_skipped
    return rows, stats


def scan_unserved(demand_layer, drop_layer, tolerance_m=1.0):
    """Demand points with no drop-cable END on them. ``(rows, stats)``.

    ``rows`` is ``[(fid, QgsPointXY, distance_m, label)]``, furthest first.

    The default tolerance is 1 m rather than 0 because a drop end is either
    coincident or absent — measured, the served count is identical anywhere from
    0.01 m to 10 m, so any value in that range gives the same answer and 1 m is
    simply the least surprising one to read.
    """
    stats = {"demand": 0, "unserved": 0, "drop_ends": 0, "reason": "",
             "skipped_nonfinite": 0, "tolerance_m": tolerance_m}
    if demand_layer is None or drop_layer is None:
        stats["reason"] = "pick both a demand-point layer and a drop-cable layer"
        return [], stats

    ends, sk = line_endpoints(drop_layer)
    stats["drop_ends"] = len(ends)
    stats["skipped_nonfinite"] += sk
    if not ends:
        stats["reason"] = (f"{drop_layer.name().strip()} holds no drop-cable "
                           "endpoints")
        return [], stats

    idx = _index_of(ends)
    da = _measurer(demand_layer)

    from qgis.core import QgsPointXY
    rows = []
    try:
        feats = list(demand_layer.getFeatures())
    except Exception as exc:
        stats["reason"] = f"could not read the demand layer: {exc}"
        return [], stats
    for f in feats:
        g = f.geometry()
        if not g or g.isEmpty():
            stats["skipped_nonfinite"] += 1
            continue
        try:
            p = g.asPoint() if not g.isMultipart() else g.centroid().asPoint()
        except Exception:
            stats["skipped_nonfinite"] += 1
            continue
        if not _finite(p.x(), p.y()):
            stats["skipped_nonfinite"] += 1
            continue
        stats["demand"] += 1
        d = nearest_metres(QgsPointXY(p), ends, idx, da)
        if d > tolerance_m:
            rows.append((f.id(), QgsPointXY(p), d, _label_of(f, demand_layer)))
    rows.sort(key=lambda r: r[2], reverse=True)
    stats["unserved"] = len(rows)
    return rows, stats


def _label_of(feature, layer):
    """Something human to show in a list — a label field, else the PON, else fid."""
    for role in (vf_fields.PON_NAME,):
        name = vf_fields.resolve(layer, role)
        if name:
            try:
                v = feature[name]
                if v not in (None, ""):
                    return str(v)
            except Exception:
                pass
    for cand in ("label", "Label", "name", "Name", "id", "ID", "pole_id",
                 "cable_id", "Pole Number"):
        try:
            if layer.fields().indexOf(cand) >= 0:
                v = feature[cand]
                if v not in (None, ""):
                    return str(v)
        except Exception:
            continue
    pon = vf_fields.resolve(layer, vf_fields.PON_NUM)
    if pon:
        try:
            v = feature[pon]
            if v not in (None, ""):
                return f"PON {v}"
        except Exception:
            pass
    return f"#{feature.id()}"
