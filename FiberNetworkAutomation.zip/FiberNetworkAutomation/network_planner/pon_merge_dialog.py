"""The PON list — how many units are in each PON, so the planner can decide.

Deliberately opinion-free. It shows counts and nothing else: no "too small"
badge, no suggested merge, no capacity rule. JJ was explicit — "people will
automatically calculate the amount of units they should be inside of a PON and
whether the PON should merge or not. Just show us the numbers of units."

Qt6-safe per the plugin's rules: imports go through the ``qgis.PyQt`` shim,
enums are fully scoped, and the dialog is ``WA_DeleteOnClose`` with every value
read BEFORE ``exec()``.
"""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from . import field_names as vf_fields
from . import pon_merge, pon_merge_ux, pon_stats

_HEADERS = ["", "PON", "Units", "Splitters", "Name"]
_COL_TICK, _COL_PON, _COL_UNITS = 0, 1, 2


class PonListDialog(QDialog):
    """Read-only table of every PON with its counted unit total."""

    def __init__(self, project, parent=None, term="PON"):
        super().__init__(parent)
        self._project = project
        self._term = term or "PON"
        # Set only by the operator answering the "remove the empty PONs?" prompt
        # inside _on_merge. Never sticky: it resets before every merge so one
        # yes can never silently authorise the next merge's deletions.
        self._delete_empty = False
        self.setWindowTitle(f"Merge {self._term}s")
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self.setMinimumSize(620, 540)
        self._rows = []
        self._build()
        self.reload()

    # ── construction ────────────────────────────────────────────────────────
    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(10)

        self._summary = QLabel("…")
        self._summary.setWordWrap(True)
        self._summary.setStyleSheet(
            "QLabel { background-color: #0e2233; color: #7fb2e5; "
            "border: 1px solid #2f5f88; border-left: 4px solid #2f5f88; "
            "border-radius: 4px; padding: 6px 8px; font-size: 9pt; }")
        root.addWidget(self._summary)

        # ── which layers this merge is about ────────────────────────────
        # Auto-discovery takes the FIRST layer of each shape that carries a PON
        # column, walking registry order (not the Layers panel). Luke's
        # Phalaborwa project holds three networks side by side — Benfarm,
        # Lulekani, Makgale — all numbering their PONs 1..N, so it paired
        # Benfarm's demand points with LULEKANI's boundaries. The target PON did
        # not exist over there, so every boundary step was skipped and the merge
        # "did nothing" while still reassigning 42 demand points.
        #
        # The guess is still the default, so a single-area project behaves
        # exactly as before. What changed is that the operator can SEE which
        # layers are about to be written, and correct them.
        picks = QGridLayout()
        picks.setContentsMargins(0, 0, 0, 0)
        picks.setHorizontalSpacing(8)
        picks.setVerticalSpacing(4)
        self._cbo_boundary = QComboBox()
        self._cbo_demand = QComboBox()
        self._cbo_splitter = QComboBox()
        rows = (
            (f"{self._term} boundaries:", self._cbo_boundary,
             f"The polygon layer holding one shape per {self._term}. This is the "
             f"layer that gets fused and trimmed."),
            ("Demand points:", self._cbo_demand,
             "The layer the unit counts are counted FROM — one point per home."),
            ("Splitters:", self._cbo_splitter,
             "The splitter point layer. Choose “none” if your splitters carry no "
             f"{self._term} column — the count is then left alone rather than guessed."),
        )
        for r, (text, combo, tip) in enumerate(rows):
            lab = QLabel(text)
            lab.setToolTip(tip)
            combo.setToolTip(tip)
            combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
            combo.currentIndexChanged.connect(self._on_layers_changed)
            picks.addWidget(lab, r, 0)
            picks.addWidget(combo, r, 1)
        picks.setColumnStretch(1, 1)
        root.addLayout(picks)

        self._table = QTableWidget(0, len(_HEADERS), self)
        self._table.setHorizontalHeaderLabels(_HEADERS)
        self._table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers)
        self._table.setAlternatingRowColors(True)
        self._table.setSortingEnabled(True)
        self._table.verticalHeader().setVisible(False)
        hh = self._table.horizontalHeader()
        for col in range(len(_HEADERS) - 1):
            hh.setSectionResizeMode(col, QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(len(_HEADERS) - 1, QHeaderView.ResizeMode.Stretch)
        root.addWidget(self._table, 1)

        # ── merge controls ──────────────────────────────────────────────
        pick = QHBoxLayout()
        pick.addWidget(QLabel("Tick the ones to merge, then merge them into:"))
        self._target = QComboBox()
        self._target.setMinimumWidth(110)
        self._target.setToolTip(
            f"The {self._term} that keeps its number. Everything ticked is "
            f"absorbed into it.")
        pick.addWidget(self._target)
        pick.addStretch(1)
        root.addLayout(pick)

        self._preview = QLabel("")
        self._preview.setWordWrap(True)
        self._preview.setVisible(False)
        self._preview.setStyleSheet(
            "QLabel { background-color: #1d2b1f; color: #a9dcb4; "
            "border: 1px solid #3c7a4c; border-left: 4px solid #3c7a4c; "
            "border-radius: 4px; padding: 6px 8px; font-size: 9pt; }")
        root.addWidget(self._preview)

        row = QHBoxLayout()
        self._btn_reload = QPushButton("↻ Refresh")
        self._btn_reload.setToolTip(
            "Re-count from the layers. The counts are read fresh every time — "
            "they are never taken from a cached value.")
        self._btn_reload.clicked.connect(self.reload)
        row.addWidget(self._btn_reload)

        self._btn_preview = QPushButton("👁 Preview merge")
        self._btn_preview.setToolTip(
            "Work out exactly what would change — without changing anything.")
        self._btn_preview.clicked.connect(self._on_preview)
        row.addWidget(self._btn_preview)

        self._btn_merge = QPushButton("⇔ Merge")
        self._btn_merge.setToolTip(
            "Reassign the ticked PONs into the target, fuse their boundaries, "
            "square the result and close the numbering gap.\n"
            "A backup is taken first — if it fails, nothing is written.")
        self._btn_merge.setStyleSheet(
            "QPushButton { background-color: #6b3a1c; color: #ffd9b8; "
            "font-weight: bold; border: 1px solid #a05a2c; border-radius: 4px; "
            "padding: 5px 10px; }"
            "QPushButton:hover { background-color: #8a4b24; }")
        self._btn_merge.clicked.connect(self._on_merge)
        row.addWidget(self._btn_merge)

        row.addStretch(1)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.rejected.connect(self.reject)
        row.addWidget(buttons)
        root.addLayout(row)

        self._fill_layer_pickers()

    # ── layer choice ────────────────────────────────────────────────────────
    def _layer_candidates(self):
        """(boundary_polygons, demand_points, splitter_points) to offer.

        Boundary and demand layers MUST carry a PON column — that is how a
        feature is moved from one PON to another, so a layer without it can never
        take part and listing it would only produce an empty table.

        Splitter layers must NOT be filtered that way. They are only ever
        COUNTED, never rewritten, and counting works from geometry alone — which
        matters because real splitter layers often have no PON column at all
        (Luke's is ``fid, ID, drop_count, Decription, Cross``). Filtering them out
        is what left the splitter counts stale and wrong.
        """
        from qgis.core import QgsVectorLayer
        polys, demand, splitters = [], [], []
        try:
            layers = list(self._project.mapLayers().values())
        except Exception:
            return polys, demand, splitters
        for lyr in layers:
            try:
                if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
                    continue
                gt = int(lyr.geometryType())
            except Exception:
                continue
            has_pon = vf_fields.has(lyr, vf_fields.PON_NUM)
            if gt == 2 and has_pon:
                polys.append(lyr)
            elif gt == 0:
                if has_pon:
                    demand.append(lyr)
                splitters.append(lyr)
        for seq in (polys, demand, splitters):
            seq.sort(key=lambda x: x.name().strip().lower())
        return polys, demand, splitters

    def _fill_layer_pickers(self):
        """Populate the three dropdowns, pre-selecting the auto-guess.

        Layer IDs are stored rather than the layer objects: a project can drop a
        layer while this dialog is open, and holding the object would leave a
        dangling C++ pointer behind the combo entry.
        """
        polys, demand_opts, splitter_opts = self._layer_candidates()
        try:
            guess_b, guess_d, guess_s = pon_stats.find_layers(self._project)
        except Exception:
            guess_b = guess_d = guess_s = None
        # The splitter guess must belong to the SAME area. Measured on Luke's
        # project the auto-guess was Lulekani's splitter layer, whose PONs run
        # 1..85 against Benfarm's 1..71 — the list opened showing 85 PONs, 14 of
        # them phantoms from another town, with Lulekani's splitter counts
        # printed beside Benfarm's units.
        #
        # Two ways to belong: the PON numbers are a subset of the boundary's, or
        # — for the many layers with no PON column — the points physically sit
        # inside these boundaries.
        if not self._same_area(guess_b, guess_s):
            guess_s = None
        if guess_s is None and guess_b is not None:
            guess_s = self._splitter_by_geometry(guess_b, splitter_opts)
        for combo, options, guess in ((self._cbo_boundary, polys, guess_b),
                                      (self._cbo_demand, demand_opts, guess_d),
                                      (self._cbo_splitter, splitter_opts, guess_s)):
            combo.blockSignals(True)
            combo.clear()
            combo.addItem("— none —", None)
            for lyr in options:
                combo.addItem(lyr.name().strip(), lyr.id())
            if guess is not None:
                i = combo.findData(guess.id())
                if i >= 0:
                    combo.setCurrentIndex(i)
            combo.blockSignals(False)

    def _same_area(self, boundary, other):
        """Do ``other``'s PON numbers all exist in ``boundary``?

        A cheap, data-derived test for "these two layers describe the same
        network". Deliberately NOT based on layer names or extents: the three
        areas in Luke's project are neighbouring suburbs whose bounding boxes
        all intersect, so extents cannot tell them apart.
        """
        if boundary is None or other is None:
            return False
        try:
            b = set(pon_stats._tally_by_pon(boundary))
            o = set(pon_stats._tally_by_pon(other))
        except Exception:
            return False
        return bool(o) and bool(b) and o.issubset(b)

    def _splitter_by_geometry(self, boundary, candidates):
        """The splitter layer whose points actually sit in these boundaries.

        Used when no candidate carries a PON column. Prefers a layer that looks
        like splitters by name, but the DECISION is the containment fraction —
        a name is a hint, geometry is the evidence.
        """
        best, best_frac = None, 0.0
        for lyr in candidates:
            try:
                counts, unplaced = pon_merge.tally_by_containment(boundary, lyr)
            except Exception:
                continue
            if not counts:
                continue
            inside = sum(counts.values())
            total = inside + unplaced
            if not total:
                continue
            frac = inside / float(total)
            if "splitter" in lyr.name().lower():
                frac += 0.001                     # tie-break only
            if frac > best_frac:
                best, best_frac = lyr, frac
        return best if best_frac >= 0.9 else None

    def _picked(self, combo):
        """The layer a dropdown points at, or None. Never raises."""
        lid = combo.currentData()
        if not lid:
            return None
        try:
            return self._project.mapLayer(lid)
        except Exception:
            return None

    def chosen_layers(self):
        """(boundary, demand, splitter) as picked — any may be None."""
        return (self._picked(self._cbo_boundary),
                self._picked(self._cbo_demand),
                self._picked(self._cbo_splitter))

    def _on_layers_changed(self, _index=None):
        """A different layer means a different set of PONs — recount."""
        self.reload()

    # ── selection ───────────────────────────────────────────────────────────
    def _ticked_pons(self):
        """PONs the operator ticked, read off the table."""
        out = []
        for r in range(self._table.rowCount()):
            cell = self._table.item(r, _COL_TICK)
            if cell is None:
                continue
            if cell.checkState() == Qt.CheckState.Checked:
                pon_cell = self._table.item(r, _COL_PON)
                if pon_cell is not None:
                    out.append(pon_cell.data(Qt.ItemDataRole.DisplayRole))
        return out

    def _current_target(self):
        return self._target.currentData()

    def _build_plan(self):
        """(plan, error) for the current selection. Never raises."""
        sources = self._ticked_pons()
        target = self._current_target()
        if target is None:
            return None, f"Pick the {self._term} to merge into."
        sources = [s for s in sources if s != target]
        if not sources:
            return None, (f"Tick at least one {self._term} to merge — and it "
                          f"must be different from the target.")
        boundary, demand, splitter = self.chosen_layers()
        scope = [x for x in (boundary, demand, splitter) if x is not None]
        if not scope:
            # An empty scope would mean "reach across the whole project", which
            # is the behaviour this dialog exists to stop. Refuse instead.
            return None, ("Choose the layers this merge applies to first — the "
                          "boundary layer and the demand-point layer.")
        try:
            return pon_merge.plan(self._project, target, sources,
                                  boundary=boundary, demand=demand,
                                  splitter=splitter, scope=scope,
                                  delete_empty=self._delete_empty), None
        except Exception as exc:
            return None, f"Could not work out the merge: {exc}"

    def _on_preview(self):
        plan_obj, err = self._build_plan()
        if err:
            self._preview.setVisible(True)
            self._preview.setText(err)
            return
        self._preview.setVisible(True)
        try:
            self._preview.setText(
                pon_merge_ux.merge_preview_html(
                    pon_merge_ux.facts_from_plan(plan_obj)))
        except Exception:
            # a formatting slip must never hide the preview — fall back to plain text
            self._preview.setText(plan_obj.describe().replace("\n", "<br>"))

    def _on_merge(self):
        self._delete_empty = False           # never carry a previous yes forward
        plan_obj, err = self._build_plan()
        if err:
            QMessageBox.information(self, f"Merge {self._term}s", err)
            return

        # Empty husks — ask, every time, before anything is written. JJ
        # 2026-07-27: "delete, but ask me each time". Answering yes rebuilds the
        # plan so the compacting renumber closes THEIR gaps too; a plan built
        # without them would renumber around rows that are about to disappear.
        if plan_obj.empty_pons:
            listed = ", ".join(str(x) for x in plan_obj.empty_pons[:10])
            more = (f" (+{len(plan_obj.empty_pons) - 10} more)"
                    if len(plan_obj.empty_pons) > 10 else "")
            ans = QMessageBox.question(
                self, f"Merge {self._term}s",
                f"{self._term} {listed}{more} hold <b>no homes and no "
                f"splitters</b>.<br><br>They are left over from an earlier merge "
                f"and sit inside their neighbour's area on the map.<br><br>"
                f"Remove their boundaries as part of this merge?<br>"
                f"<i>No</i> keeps them exactly as they are.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No)
            if ans == QMessageBox.StandardButton.Yes:
                self._delete_empty = True
                plan_obj, err = self._build_plan()
                if err:
                    QMessageBox.information(self, f"Merge {self._term}s", err)
                    return

        # Show exactly what will happen and make them confirm it. Everything the
        # dialog needs is read BEFORE any modal opens (WA_DeleteOnClose rule).
        try:
            detail = pon_merge_ux.merge_preview_html(
                pon_merge_ux.facts_from_plan(plan_obj))
        except Exception:
            detail = plan_obj.describe().replace("\n", "<br>")
        ans = QMessageBox.question(
            self, f"Merge {self._term}s",
            f"{detail}<br><br>A backup is taken first. Go ahead?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if ans != QMessageBox.StandardButton.Yes:
            return

        backup = self._take_backup()
        if not backup:
            QMessageBox.warning(
                self, f"Merge {self._term}s",
                "Nothing was merged — the backup could not be written, so the "
                "write was not attempted.")
            return

        log = []
        try:
            ok, msg = pon_merge.apply_plan(plan_obj, backup, feedback=log.append)
        except Exception as exc:
            QMessageBox.critical(
                self, f"Merge {self._term}s",
                f"The merge failed and stopped:\n{exc}\n\nBackup: {backup}")
            return

        if not ok:
            QMessageBox.warning(
                self, f"Merge {self._term}s",
                f"{msg}\n\nBackup: {backup}")
            return

        self.reload()
        QMessageBox.information(
            self, f"Merge {self._term}s",
            f"{msg}\n\n" + "\n".join(log) + f"\n\nBackup: {backup}")

    def _take_backup(self):
        """Snapshot every PON-carrying layer. Returns a path, or '' on failure.

        The merge refuses to run without this, so a silent failure here is a
        refusal to write — never a write without a net.
        """
        try:
            parent = self.parent()
            writer = getattr(parent, "_pon_write_renumber_backup", None)
            if writer is None:
                return ""
            # Back up exactly what the merge may write — the chosen layers — so
            # the snapshot and the blast radius are the same set by construction.
            boundary, demand, splitter = self.chosen_layers()
            scope = [x for x in (boundary, demand, splitter) if x is not None]
            layers = [lyr for lyr, _f in
                      pon_merge._pon_layers(self._project, scope=scope or None)]
            for extra in scope:                      # a picked layer with no PON
                if extra not in layers:              # column still holds counts
                    layers.append(extra)
            if not layers:
                return ""
            ok, dest = writer(layers)
            return dest if ok else ""
        except Exception:
            return ""

    # ── data ────────────────────────────────────────────────────────────────
    def _num_item(self, value):
        """Right-aligned cell that sorts NUMERICALLY, not as text.

        Without the numeric role a click on 'Units' orders 100 before 99.
        """
        item = QTableWidgetItem()
        item.setData(Qt.ItemDataRole.DisplayRole, value)
        item.setTextAlignment(int(Qt.AlignmentFlag.AlignRight
                                 | Qt.AlignmentFlag.AlignVCenter))
        return item

    def reload(self):
        boundary, demand, splitter = self.chosen_layers()

        # NO SILENT FALLBACK. pon_stats.collect() auto-discovers when all three
        # are None, and that auto-discovery is exactly the bug this dialog now
        # exists to prevent — so an empty choice must ask, never guess.
        if boundary is None and demand is None:
            self._summary.setText(
                f"Choose the {self._term} boundary layer and the demand-point "
                f"layer above. Nothing is counted until you do — the tool no "
                f"longer guesses, because on a project holding more than one "
                f"area it guessed wrong.")
            self._table.setRowCount(0)
            self._target.blockSignals(True)
            self._target.clear()
            self._target.blockSignals(False)
            self._preview.setVisible(False)
            return

        try:
            rows = pon_stats.collect(self._project, boundary=boundary,
                                     demand=demand, splitter=splitter)
        except Exception as exc:                       # never take the dock down
            self._summary.setText(f"Could not read the PONs: {exc}")
            self._table.setRowCount(0)
            return

        summary = pon_stats.summarise(rows)
        term = self._term
        text = (f"<b>{summary['pons']}</b> {term}s &nbsp;·&nbsp; "
                f"<b>{summary['units']}</b> units &nbsp;·&nbsp; "
                f"<b>{summary['splitters']}</b> splitters &nbsp;·&nbsp; "
                f"smallest <b>{summary['smallest']}</b>, "
                f"largest <b>{summary['largest']}</b>")
        # Say out loud which layers these numbers came from. The whole defect was
        # that nobody could tell the tool was reading another area's layers.
        text += (f"<br><span style='color:#9fb6c9;font-size:8.5pt'>counted from "
                 f"{demand.name().strip() if demand else '(no demand layer)'} "
                 f"against "
                 f"{boundary.name().strip() if boundary else '(no boundary layer)'}"
                 f"</span>")
        # A PON that the demand/splitter layer knows about but the boundary layer
        # has never heard of is the fingerprint of a mismatched pick — it is how
        # Lulekani's PONs 72..85 appeared in a Benfarm list.
        orphans = [r.pon for r in rows if r.fid is None]
        if orphans and boundary is not None:
            shown = ", ".join(str(o) for o in orphans[:8])
            more = f" (+{len(orphans) - 8} more)" if len(orphans) > 8 else ""
            text += (f"<br><span style='color:#e0a458'>{len(orphans)} {term}(s) "
                     f"— {shown}{more} — appear in the point layers but have no "
                     f"shape in {boundary.name().strip()}. If that is a surprise, "
                     f"one of the layers above belongs to a different area.</span>")
        if summary["stale"]:
            text += (f"<br><span style='color:#e0a458'>"
                     f"{summary['stale']} {term}(s) have a stale stored count — "
                     f"the numbers shown are counted live and are the correct "
                     f"ones.</span>")
        self._summary.setText(text)

        # Sorting must be off while filling or Qt re-sorts mid-insert and the
        # cells land in the wrong rows.
        self._table.setSortingEnabled(False)
        self._table.setRowCount(len(rows))
        stale_bg = QColor("#3a2d12")
        bold = QFont()
        bold.setBold(True)
        for r, row in enumerate(rows):
            tick = QTableWidgetItem()
            tick.setFlags(Qt.ItemFlag.ItemIsUserCheckable
                          | Qt.ItemFlag.ItemIsEnabled
                          | Qt.ItemFlag.ItemIsSelectable)
            tick.setCheckState(Qt.CheckState.Unchecked)
            tick.setToolTip(f"Tick to merge {self._term} {row.pon} into the target")
            self._table.setItem(r, _COL_TICK, tick)

            pon_item = QTableWidgetItem()
            pon_item.setData(Qt.ItemDataRole.DisplayRole, row.pon)
            pon_item.setFont(bold)
            self._table.setItem(r, _COL_PON, pon_item)
            self._table.setItem(r, _COL_UNITS, self._num_item(row.units))
            self._table.setItem(r, _COL_UNITS + 1, self._num_item(row.splitters))
            name_item = QTableWidgetItem(str(row.name) if row.name else "")
            self._table.setItem(r, _COL_UNITS + 2, name_item)
            if row.units_are_stale:
                tip = (f"Stored count says {row.stored_units}, actual is "
                       f"{row.units}. The actual number is shown.")
                for c in range(len(_HEADERS)):
                    cell = self._table.item(r, c)
                    cell.setBackground(stale_bg)
                    cell.setToolTip(tip)
        self._table.setSortingEnabled(True)
        # Re-enabling sorting makes Qt apply whatever sort indicator it already
        # had, which opened the list backwards (55, 54, 53...). Ask for PON
        # ascending explicitly so it always opens in the order people expect;
        # clicking a header still re-sorts normally afterwards.
        self._table.sortItems(_COL_PON, Qt.SortOrder.AscendingOrder)

        # Target dropdown — keep the operator's choice across a refresh.
        previous = self._target.currentData()
        self._target.blockSignals(True)
        self._target.clear()
        for row in rows:
            self._target.addItem(f"{self._term} {row.pon}  ({row.units} units)",
                                 row.pon)
        if previous is not None:
            i = self._target.findData(previous)
            if i >= 0:
                self._target.setCurrentIndex(i)
        self._target.blockSignals(False)
        self._preview.setVisible(False)


def open_pon_list(project, parent=None, term="PON"):
    """Show the PON list and merge tool."""
    dlg = PonListDialog(project, parent=parent, term=term)
    dlg.exec()
    return None
