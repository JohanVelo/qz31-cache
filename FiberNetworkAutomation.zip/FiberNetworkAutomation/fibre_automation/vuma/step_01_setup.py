"""Vuma Step 1 — Create all project layers, groups, and apply styles."""

from qgis.PyQt.QtCore import QMetaType
from qgis.core import QgsCoordinateReferenceSystem, QgsProject, QgsWkbTypes
from qgis.PyQt.QtCore import QVariant

from fibre_automation.startup import SESSION
from fibre_automation.shared.layer_utils import (
    apply_label,
    apply_vuma_style,
    create_shapefile,
    get_or_create_group,
    load_or_create_layer,
)

S = QMetaType.Type.QString
D = QMetaType.Type.Double
I = QMetaType.Type.Int
L = QMetaType.Type.LongLong

# ── Canonical Vuma layer definitions (Malmsbury V1.1 schema) ────────────────
# (layer_name, WKB type, [(field_name, QVariant_type), ...], sub-group)

VUMA_LAYER_DEFS = [
    # ── Polygon layers ────────────────────────────────────────────────────
    (
        "Erven",
        QgsWkbTypes.Type.Polygon,
        [("Label", S), ("Area", D), ("PRCL_KEY", S), ("LSTATUS", S), ("WSTATUS", S)],
        "Boundaries",
    ),
    (
        "Aggregation Polygon",
        QgsWkbTypes.Type.Polygon,
        [("Discriptio", S), ("Label.", S), ("fid", L)],
        "Boundaries",
    ),
    (
        "Block",
        QgsWkbTypes.Type.Polygon,
        [("Label.", S), ("Discriptio", S), ("fid", L)],
        "Boundaries",
    ),
    (
        "P2 AOI Poly",
        QgsWkbTypes.Type.Polygon,
        [("id", S), ("Name", S), ("Discriptio", S)],
        "Boundaries",
    ),
    # ── Point layers ──────────────────────────────────────────────────────
    (
        "Poles",
        QgsWkbTypes.Type.Point,
        [
            ("id", L),
            ("Name", S),
            ("Pole Size", S),
            ("AG", S),
            ("Block", S),
            ("Y", D),
            ("X", D),
            ("Type", S),
            ("fid", L),
        ],
        "Infrastructure",
    ),
    (
        "Dome Joint",
        QgsWkbTypes.Type.Point,
        [
            ("id", L),
            ("Name", S),
            ("Block", S),
            ("AG", S),
            ("x", D),
            ("y", D),
            ("Descriptio", S),
            ("fid", L),
        ],
        "Infrastructure",
    ),
    (
        "Spur Joints",
        QgsWkbTypes.Type.Point,
        [
            ("id", L),
            ("Name", S),
            ("Block", S),
            ("AG", S),
            ("x", D),
            ("y", D),
            ("Descriptio", S),
            ("fid", L),
        ],
        "Infrastructure",
    ),
    (
        "Feeder Joints",
        QgsWkbTypes.Type.Point,
        [("Label", S), ("Splitters", S), ("Discriptio", S), ("fid", L)],
        "Infrastructure",
    ),
    (
        "Link Joints",
        QgsWkbTypes.Type.Point,
        [("id", L), ("Discriptio", S), ("Label", S), ("fid", L)],
        "Infrastructure",
    ),
    (
        "4 Way Splitters",
        QgsWkbTypes.Type.Point,
        [("id", L), ("1-4 Splitt", S), ("AG", S), ("Block", S)],
        "Infrastructure",
    ),
    (
        "Demand Points",
        QgsWkbTypes.Type.Point,
        [
            ("Name", S),
            ("Block", S),
            ("Allowed Pr", S),
            ("Inst Type", S),
            ("Geo Str Nu", S),
            ("Geo Str Na", S),
            ("Geocode", S),
            ("Dist Joint", S),
            ("Geo Suburb", S),
            ("Geo Erf Nu", S),
            ("Geolocatio", S),
            ("Geo Latitu", D),
            ("Geo Longit", D),
            ("Geo Postal", L),
            ("Geo Munici", S),
            ("Geo Provin", S),
            ("Geo Countr", S),
            ("Status", S),
            ("Type", S),
            ("Network Ty", S),
            ("Build Meth", S),
            ("Premises T", S),
            ("Zone", I),
            ("Connectabl", S),
            ("AG Name", S),
            ("Block Name", S),
        ],
        "Infrastructure",
    ),
    (
        "Node",
        QgsWkbTypes.Type.Point,
        [("id", L)],
        "Infrastructure",
    ),
    (
        "Aggregation Joint",
        QgsWkbTypes.Type.Point,
        [("id", L)],
        "Infrastructure",
    ),
    # ── Line layers ───────────────────────────────────────────────────────
    (
        "Feeder",
        QgsWkbTypes.Type.LineString,
        [
            ("Feeder Cab", S),
            ("To From fr", S),
            ("Tlenght", D),
            ("Slenght", D),
            ("Cable Size", S),
            ("Discriptio", S),
            ("Name", S),
            ("fid", L),
        ],
        "Cables",
    ),
    (
        "Link Cable",
        QgsWkbTypes.Type.LineString,
        [
            ("Tlenght", D),
            ("Slenght", D),
            ("Cable Size", S),
            ("To from fr", S),
            ("Name", S),
            ("Feeder Cab", S),
            ("descriptio", S),
            ("fid", L),
        ],
        "Cables",
    ),
    (
        "Distribution Cable",
        QgsWkbTypes.Type.LineString,
        [
            ("Tlenght", D),
            ("Slenght", D),
            ("Cable Size", S),
            ("Feeder Cab", S),
            ("Dist Cable", S),
            ("To from fr", S),
            ("Discriptio", S),
            ("Name", S),
            ("AG", S),
            ("fid", L),
        ],
        "Cables",
    ),
    (
        "Spur Cable",
        QgsWkbTypes.Type.LineString,
        [
            ("Tlenght", D),
            ("Slenght", D),
            ("Cable Size", S),
            ("Discriptio", S),
            ("Name", S),
            ("AG", S),
            ("Spur Cab", S),
            ("fid", L),
        ],
        "Cables",
    ),
    (
        "Drops",
        QgsWkbTypes.Type.LineString,
        [("id", L), ("Lenght", D), ("Block", S), ("AG", S)],
        "Cables",
    ),
    (
        "Road Crossing Underground",
        QgsWkbTypes.Type.LineString,
        [("id", L), ("Lenght", L), ("up & down", L)],
        "Cables",
    ),
    (
        "Core",
        QgsWkbTypes.Type.LineString,
        [("id", L), ("Lenght", D), ("Cable Size", S), ("Name", S)],
        "Cables",
    ),
    # ── Extra polygon for buildings ───────────────────────────────────────
    (
        "Buildings",
        QgsWkbTypes.Type.Polygon,
        [
            ("id", S),
            ("Name", S),
            ("Discriptio", S),
            ("building_t", S),
            ("area_m2", D),
            ("is_primary", I),
        ],
        "Boundaries",
    ),
]


def _copy_aoi_into_layer(src_layer_id_or_name):
    """Copy polygons from the AOI source into P2 AOI Poly, replacing any existing AOI.

    src_layer_id_or_name may be a QGIS layer ID (preferred — avoids name collisions
    when the source file has the same name as the newly created P2 AOI Poly layer)
    or a layer name (legacy fallback).
    """
    # claude:approved-destructive  (only clears P2 AOI Poly to prevent duplicates on re-run)
    from qgis.core import QgsCoordinateTransform, QgsFeature
    proj = QgsProject.instance()
    # Look up source by ID first — much more reliable than name when the
    # setup just created a new layer with the same name as the source file.
    src = proj.mapLayer(src_layer_id_or_name)
    if src is None:
        src_lyrs = proj.mapLayersByName(src_layer_id_or_name)
        src = src_lyrs[0] if src_lyrs else None
    dst_lyrs = proj.mapLayersByName("P2 AOI Poly")
    # If multiple layers named P2 AOI Poly exist, pick the one that isn't src
    dst = None
    for lyr in dst_lyrs:
        if lyr is not src:
            dst = lyr
            break
    if src is None or dst is None:
        print(f"  ! AOI copy skipped — layer not found: {src_layer_id_or_name}")
        return
    existing = list(dst.allFeatureIds())
    if existing:
        dst.dataProvider().deleteFeatures(existing)  # claude:approved-destructive
    xform = QgsCoordinateTransform(src.crs(), dst.crs(), proj)
    new_feats = []
    for feat in src.getFeatures():
        geom = feat.geometry()
        if not geom or geom.isEmpty():
            continue
        geom.transform(xform)
        nf = QgsFeature(dst.fields())
        nf.setGeometry(geom)
        if dst.fields().indexOf("Name") >= 0:
            nf["Name"] = src.name()
        new_feats.append(nf)
    if new_feats:
        dst.dataProvider().addFeatures(new_feats)
        dst.triggerRepaint()
        print(f"  ✓ AOI copied: {len(new_feats)} polygon(s) from '{src.name()}'")
        src_id = src.id()
        proj.removeMapLayer(src_id)
        print("  ✓ Source AOI layer removed — P2 AOI Poly is the only AOI")
    else:
        print(f"  ✗ AOI copy failed — no valid geometries in '{src.name()}'; source layer kept")


def _add_ngi_basemap(proj):
    """Add NGI 25cm aerial XYZ tile layer at the bottom of the layer tree.

    Safe to call on every run — skips if a layer named 'Google Satellite' or
    'NGI Aerial' is already present.
    """
    existing_names = {l.name() for l in proj.mapLayers().values()}
    if any(n in existing_names for n in ("NGI Aerial", "Google Satellite")):
        return
    try:
        from qgis.core import QgsRasterLayer
        url = (
            "type=xyz"
            "&url=https://aerial.openstreetmap.org.za/layer/ngi-aerial/%7Bz%7D/%7Bx%7D/%7By%7D.jpg"
            "&zmax=20&zmin=0"
        )
        lyr = QgsRasterLayer(url, "NGI Aerial", "wms")
        if not lyr.isValid():
            print("  ⚠ NGI basemap layer invalid — skipping")
            return
        # addMapLayer with addToLegend=True puts it at top — we want bottom
        # Safe pattern: add to project registry only, then insert node at index -1
        proj.addMapLayer(lyr, False)
        root = proj.layerTreeRoot()
        # Insert at position len(children) → appended at the very bottom of root
        from qgis.core import QgsLayerTreeLayer
        node = QgsLayerTreeLayer(lyr)
        root.insertChildNode(-1, node)
        print("  ✓ NGI 25cm aerial basemap added")
    except Exception as e:
        print(f"  ⚠ Basemap add failed: {e}")


def vuma_step_01_setup():
    """Create all Vuma layers, groups, fields, and symbology.

    STATUS: [x] BUILT
    Safe to re-run — skips layers that already exist.
    """
    area = SESSION.get("area_code")
    if not area:
        print("✗ No project active — use the New Project wizard first.")
        return
    zone = SESSION.get("zone_code") or "Z1"
    crs = SESSION.get("crs")
    crs_authid = crs.authid() if crs else "EPSG:4326"

    # Ask for folder path if not in SESSION
    folder_path = SESSION.get("project_folder")
    if not folder_path:
        from qgis.PyQt.QtWidgets import QFileDialog

        folder_path = QFileDialog.getExistingDirectory(
            None,
            f"Select folder to save {area} shapefiles",
        )
        if not folder_path:
            print("✗ No folder selected — setup cancelled.")
            return
        SESSION["project_folder"] = folder_path

    print(f"\n{'═' * 55}")
    print("  VUMA STEP 1 — Layer Setup")
    print(f"  Area: {area}  |  Zone: {zone}  |  CRS: {crs_authid}")
    print(f"  Folder: {folder_path}")
    print(f"{'═' * 55}")

    group_name = f"Vuma — {area}"
    root_group = get_or_create_group(group_name)

    sub_groups = {}
    for sub in ("Boundaries", "Infrastructure", "Cables"):
        sub_groups[sub] = get_or_create_group(sub, parent=root_group)

    created = []
    skipped = []
    errors = []

    for layer_name, wkb_type, field_defs, sub_group_name in VUMA_LAYER_DEFS:
        try:
            was_new = not QgsProject.instance().mapLayersByName(layer_name)
            shp_path = create_shapefile(
                layer_name,
                wkb_type,
                field_defs,
                folder_path,
                crs_authid=crs_authid,
                overwrite=False,
            )
            lyr = load_or_create_layer(
                layer_name,
                shp_path,
                sub_groups[sub_group_name],
            )
            if lyr:
                apply_vuma_style(lyr)
                # Demand Points: labels off by default — too cluttered at full density
                name_field = "Name" if lyr.fields().indexOf("Name") >= 0 else None
                if name_field and layer_name != "Demand Points":
                    apply_label(lyr, name_field)
                (created if was_new else skipped).append(layer_name)
        except Exception as exc:
            errors.append(layer_name)
            print(f"  ✗ ERROR creating {layer_name}: {exc}")

    # Set project CRS to match if unset
    proj = QgsProject.instance()
    if not proj.crs().isValid():
        proj.setCrs(QgsCoordinateReferenceSystem(crs_authid))

    # Add NGI 25cm aerial basemap if not already present
    _add_ngi_basemap(proj)

    from qgis.utils import iface
    iface.mapCanvas().refresh()

    print(f"\n  ✓ Created: {len(created)}  |  ⊘ Exists: {len(skipped)}  |  ✗ Errors: {len(errors)}")
    if errors:
        for e in errors:
            print(f"    ✗ {e}")
    print(f"{'═' * 55}\n")

    # ── Copy AOI source into P2 AOI Poly if user selected one ────────────────
    aoi_source = SESSION.get("aoi_source")
    if aoi_source:
        _copy_aoi_into_layer(aoi_source)

    # Auto-fetch cadastral + buildings if AOI polygon is already present
    from fibre_automation.vuma.step_01b_fetch import vuma_step_01b_fetch
    vuma_step_01b_fetch(silent_if_no_aoi=True)
