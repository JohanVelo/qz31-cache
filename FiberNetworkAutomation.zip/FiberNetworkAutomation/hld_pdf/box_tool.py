# -*- coding: utf-8 -*-
# Drag-a-box map tool: the operator drags a rectangle on the QGIS canvas to SET how big
# each grid page will be. Returns the box size in real metres. Used by the HLD PDF dialog
# so "Grid over AOI" pages are as big as the box you drew (WYSIWYG map size).
from qgis.PyQt.QtCore import QEventLoop
from qgis.PyQt.QtGui import QColor
from qgis.gui import QgsMapTool, QgsRubberBand
from qgis.core import (QgsWkbTypes, QgsRectangle, QgsGeometry, QgsPointXY,
                       QgsDistanceArea, QgsProject)


def _poly_geom():
    try:
        return QgsWkbTypes.GeometryType.PolygonGeometry
    except AttributeError:
        return QgsWkbTypes.PolygonGeometry


class DragBoxTool(QgsMapTool):
    """Press-drag-release to rubber-band a rectangle; calls on_done(QgsRectangle in map CRS)."""

    def __init__(self, canvas, on_done):
        super().__init__(canvas)
        self._canvas = canvas
        self._on_done = on_done
        self._start = None
        self._rb = QgsRubberBand(canvas, _poly_geom())
        self._rb.setColor(QColor(0, 160, 255, 70))
        self._rb.setStrokeColor(QColor(0, 130, 255))
        self._rb.setWidth(2)

    def canvasPressEvent(self, e):
        self._start = self.toMapCoordinates(e.pos())
        self._rb.reset(_poly_geom())

    def canvasMoveEvent(self, e):
        if self._start is None:
            return
        rect = QgsRectangle(self._start, self.toMapCoordinates(e.pos()))
        self._rb.setToGeometry(QgsGeometry.fromRect(rect), None)

    def canvasReleaseEvent(self, e):
        if self._start is None:
            return
        rect = QgsRectangle(self._start, self.toMapCoordinates(e.pos()))
        self._start = None
        # keep the box drawn so the operator can see the page size; cleared on deactivate
        if self._on_done:
            self._on_done(rect)

    def keyPressEvent(self, e):
        from qgis.PyQt.QtCore import Qt
        esc = getattr(getattr(Qt, "Key", Qt), "Key_Escape", None)
        if esc is not None and e.key() == esc:
            self._start = None
            if self._on_done:
                self._on_done(None)

    def deactivate(self):
        try:
            self._rb.reset(_poly_geom())
        except Exception:
            pass
        super().deactivate()


def box_metres(rect, canvas):
    """Width, height of a map-CRS rectangle in real metres (ellipsoidal)."""
    da = QgsDistanceArea()
    try:
        da.setSourceCrs(canvas.mapSettings().destinationCrs(),
                        QgsProject.instance().transformContext())
        da.setEllipsoid("WGS84")
    except Exception:
        pass
    cy = (rect.yMinimum() + rect.yMaximum()) / 2.0
    cx = (rect.xMinimum() + rect.xMaximum()) / 2.0
    try:
        w = da.measureLine(QgsPointXY(rect.xMinimum(), cy), QgsPointXY(rect.xMaximum(), cy))
        h = da.measureLine(QgsPointXY(cx, rect.yMinimum()), QgsPointXY(cx, rect.yMaximum()))
    except Exception:
        w = rect.width(); h = rect.height()
    return abs(w), abs(h)


def draw_box(iface):
    """Blocking: let the operator drag a box on the canvas; returns (width_m, height_m) or None.
    Uses a nested event loop so the canvas stays interactive while we wait (the caller's
    dialog is closed during this). Restores the previous map tool afterwards."""
    canvas = iface.mapCanvas()
    prev = canvas.mapTool()
    holder = {}
    loop = QEventLoop()

    def on_done(rect):
        holder["rect"] = rect
        loop.quit()

    tool = DragBoxTool(canvas, on_done)
    canvas.setMapTool(tool)
    iface.messageBar().pushInfo(
        "Draw map size", "Drag a box on the map — that's how big each grid page will be. "
        "Release to set (Esc to cancel).")
    try:
        loop.exec()
    finally:
        canvas.unsetMapTool(tool)
        if prev is not None:
            canvas.setMapTool(prev)
        iface.messageBar().clearWidgets()
    rect = holder.get("rect")
    if rect is None or rect.width() <= 0 or rect.height() <= 0:
        return None
    return box_metres(rect, canvas)
