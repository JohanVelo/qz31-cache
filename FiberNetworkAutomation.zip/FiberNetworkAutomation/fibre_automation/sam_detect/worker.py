#!/usr/bin/env python3
"""SAM detect worker — runs in a Python with torch+sam2 (OUTSIDE QGIS).

Reads every <tiles_dir>/job_*.json written by tiler.py, runs SAM 2.1
box-prompted on each building box (tuned gates from the Mohadin sweep:
NO roof-colour gate, raw mask polygons, area 6-2500 m2), then:

  - boxes WITH an erf tag  -> union per erf, clip to the erf boundary,
    regularize, keep the LARGEST part as THE house (one polygon per stand)
  - boxes WITHOUT an erf   -> watershed split of merged roofs, IoU-NMS,
    regularize, one polygon per building (works with no cadastre at all)

Every output polygon gets a shape class: shack/square/rectangle/L-shape/complex.
Vacant erven are emitted as outlines (has_building=0, shape='vacant').

Progress lines on stdout:  PROG <tile>/<total> roofs=<n>
Final line on stdout:      RESULT {json}

  python worker.py <tiles_dir> <out_geojson> [ckpt_path]

The SAM 2.1 tiny checkpoint (~150 MB, Meta, Apache-2.0, free) is downloaded
automatically next to <ckpt_path> if missing. No API keys, ever.
"""
from __future__ import annotations

import glob
import json
import math
import os
import sys
from collections import defaultdict

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sam_helpers as sw

CKPT_URL = ("https://dl.fbaipublicfiles.com/segment_anything_2/092824/"
            "sam2.1_hiera_tiny.pt")
SAM_CFG = "configs/sam2.1/sam2.1_hiera_t.yaml"

# tuned gates — Mohadin full-AOI sweep 2026-06-11 (F1 0.973 vs reference)
AREA_MIN_M2 = 6.0
AREA_MAX_M2 = 2500.0
MIN_AREA_PX = 50
SIMPLIFY_M = 0.3
NOERF_NMS_IOU = 0.3
NOERF_CONF_MIN = 0.5


def log(m):
    sys.stderr.write(f"[worker] {m}\n")
    sys.stderr.flush()


def progress(msg):
    print(msg, flush=True)


def ensure_checkpoint(path):
    if os.path.isfile(path) and os.path.getsize(path) > 100_000_000:
        return path
    log("checkpoint missing -> downloading SAM2.1 tiny (~150 MB, one-time)")
    progress("PROG download checkpoint")
    import urllib.request
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".part"
    urllib.request.urlretrieve(CKPT_URL, tmp)
    os.replace(tmp, path)
    log(f"checkpoint saved: {path}")
    return path


def geom_iou(a, b):
    try:
        if not a.intersects(b):
            return 0.0
        inter = a.intersection(b).area
        u = a.area + b.area - inter
        return inter / u if u > 0 else 0.0
    except Exception:
        return 0.0


def regularize_parts(rows):
    """rows: list of dicts with 'geometry'. Returns same-length geometries,
    orthogonalized via buildingregulariser; originals if the lib is missing."""
    if not rows:
        return []
    try:
        import geopandas as gpd
        from buildingregulariser import regularize_geodataframe
        gdf = gpd.GeoDataFrame(rows, crs="EPSG:3857")
        reg = regularize_geodataframe(gdf, simplify_tolerance=1.2)
        out = list(reg.geometry)
        if len(out) == len(rows):
            return out
        log("regulariser changed row count — keeping originals")
    except Exception as e:
        log(f"regularize skipped ({type(e).__name__}: {e})")
    return [r["geometry"] for r in rows]


def main():
    if len(sys.argv) < 3:
        log("usage: worker.py <tiles_dir> <out_geojson> [ckpt]")
        return 2
    tiles_dir, out_path = sys.argv[1], sys.argv[2]
    ckpt = sys.argv[3] if len(sys.argv) > 3 else os.path.join(
        os.path.expanduser("~"), ".velocityfibre", "sam2.1_hiera_tiny.pt")

    jobs = sorted(glob.glob(os.path.join(tiles_dir, "job_*.json")),
                  key=lambda p: int(os.path.basename(p)[4:-5]))
    if not jobs:
        log("no job files found")
        return 1
    log(f"{len(jobs)} tiles")

    from shapely.wkt import loads as wkt_loads
    from shapely.ops import unary_union
    from shapely.geometry import mapping
    from rasterio.transform import from_bounds

    ensure_checkpoint(ckpt)
    device = sw.resolve_device("auto")
    import torch
    from sam2.build_sam import build_sam2
    from sam2.sam2_image_predictor import SAM2ImagePredictor
    torch.set_num_threads(os.cpu_count() or 4)
    log(f"loading SAM2.1 tiny on {device}")
    model = build_sam2(SAM_CFG, ckpt, device=device, mode="eval")
    predictor = SAM2ImagePredictor(model)

    erven_geom = {}
    erven_prcl = {}
    by_erf = defaultdict(list)          # erf -> [shapely roof polys]
    noerf = []                          # [(geom, score)] outside the cadastre
    lat0 = None
    total_boxes = roofs = 0

    with torch.inference_mode(), sw.autocast_ctx(device):
        for ti, jp in enumerate(jobs):
            with open(jp, encoding="utf-8") as f:
                job = json.load(f)
            if lat0 is None:
                lat0 = float(job.get("lat_deg", 0.0))
            for e in job.get("erven", []):
                erf = e["erf"]
                if erf not in erven_geom:
                    try:
                        g = wkt_loads(e["wkt"])
                        if not g.is_valid:
                            g = g.buffer(0)
                        erven_geom[erf] = g
                        erven_prcl[erf] = e.get("prcl", "")
                    except Exception:
                        pass
            boxes = job.get("boxes", [])
            if not boxes:
                progress(f"PROG {ti + 1}/{len(jobs)} roofs={roofs}")
                continue
            img = sw.load_image(job["image_path"])
            img = sw.clahe_enhance(img)
            h, w = img.shape[:2]
            transform = from_bounds(job["bbox"][0], job["bbox"][1],
                                    job["bbox"][2], job["bbox"][3], w, h)
            gsd = (job["bbox"][2] - job["bbox"][0]) / w
            af = math.cos(math.radians(lat0)) ** 2 if lat0 else 1.0
            predictor.set_image(img)
            total_boxes += len(boxes)
            for b in boxes:
                x0, y0, x1, y1 = b["box"]
                x0 = max(0.0, min(x0, w - 1)); x1 = max(0.0, min(x1, w - 1))
                y0 = max(0.0, min(y0, h - 1)); y1 = max(0.0, min(y1, h - 1))
                if x1 - x0 < 2 or y1 - y0 < 2:
                    continue
                try:
                    masks, scores, _ = predictor.predict(
                        box=np.array([x0, y0, x1, y1]), multimask_output=True)
                except Exception as exc:
                    log(f"box {b.get('fid')} failed: {exc}")
                    continue
                best = int(np.argmax(scores))
                score = float(scores[best])
                erf = b.get("erf")
                if erf is not None and erf in erven_geom:
                    mask = sw.refine_mask(masks[best], True, MIN_AREA_PX)
                    if mask.sum() == 0:
                        continue
                    poly = sw.mask_to_polygon(mask, transform, SIMPLIFY_M)
                    if poly is None:
                        continue
                    area = poly.area * af
                    if area < AREA_MIN_M2 or area > AREA_MAX_M2:
                        continue
                    poly = poly.intersection(erven_geom[erf])
                    if not poly.is_empty:
                        by_erf[erf].append(poly)
                        roofs += 1
                else:
                    if score < NOERF_CONF_MIN:
                        continue
                    mask = sw.refine_mask(masks[best], True, MIN_AREA_PX)
                    if mask.sum() == 0:
                        continue
                    for comp in sw.split_touching_roofs(mask, gsd=gsd):
                        comp = sw.refine_mask(comp, True, MIN_AREA_PX)
                        if comp.sum() == 0:
                            continue
                        poly = sw.mask_to_polygon(comp, transform, SIMPLIFY_M)
                        if poly is None:
                            continue
                        area = poly.area * af
                        if AREA_MIN_M2 <= area <= AREA_MAX_M2:
                            noerf.append((poly, score))
                            roofs += 1
            progress(f"PROG {ti + 1}/{len(jobs)} roofs={roofs}")

    af = math.cos(math.radians(lat0)) ** 2 if lat0 else 1.0

    # ── per-erf: union, explode, regularize, keep largest part ──────────────
    erf_rows = []
    for erf, geoms in by_erf.items():
        u = unary_union(geoms)
        if not u.is_valid:
            u = u.buffer(0)
        if u.is_empty:
            continue
        parts = list(u.geoms) if u.geom_type == "MultiPolygon" else [u]
        parts = [p for p in parts if p.area * af >= AREA_MIN_M2]
        for p in parts:
            erf_rows.append({"erf": erf, "n_parts": len(parts), "geometry": p})
    log(f"{len(erf_rows)} erf building parts; {len(noerf)} no-erf candidates")
    progress("PROG regularize")
    erf_regs = regularize_parts(erf_rows)

    best_per_erf = {}
    for row, g in zip(erf_rows, erf_regs):
        if g is None or g.is_empty:
            g = row["geometry"]
        if g.geom_type == "MultiPolygon":
            g = max(g.geoms, key=lambda p: p.area)
        cur = best_per_erf.get(row["erf"])
        if cur is None or g.area > cur[0].area:
            best_per_erf[row["erf"]] = (g, row["n_parts"])

    # ── no-erf: IoU-NMS then regularize ──────────────────────────────────────
    noerf.sort(key=lambda t: t[1], reverse=True)
    kept = []
    for g, s in noerf:
        if any(geom_iou(g, k) > NOERF_NMS_IOU for k, _ in kept):
            continue
        kept.append((g, s))
    noerf_rows = [{"geometry": g, "score": s} for g, s in kept]
    noerf_regs = regularize_parts(noerf_rows)

    # ── features ─────────────────────────────────────────────────────────────
    feats = []
    for erf, (g, n_parts) in best_per_erf.items():
        area = round(g.area * af, 1)
        cat, rr, asp, corners = sw.classify_shape(g, area)
        feats.append({"type": "Feature", "geometry": mapping(g),
                      "properties": {"erf": erf, "prcl": erven_prcl.get(erf, ""),
                                     "has_building": 1, "n_build": n_parts,
                                     "area_m2": area, "shape": cat,
                                     "rect_ratio": rr, "aspect": asp,
                                     "corners": corners, "source": "erf"}})
    n_vac = 0
    for erf, g in erven_geom.items():
        if erf in best_per_erf or g.is_empty:
            continue
        n_vac += 1
        feats.append({"type": "Feature", "geometry": mapping(g),
                      "properties": {"erf": erf, "prcl": erven_prcl.get(erf, ""),
                                     "has_building": 0, "n_build": 0,
                                     "area_m2": 0.0, "shape": "vacant",
                                     "rect_ratio": None, "aspect": None,
                                     "corners": None, "source": "erf"}})
    for row, g in zip(noerf_rows, noerf_regs):
        if g is None or g.is_empty:
            g = row["geometry"]
        if g.geom_type == "MultiPolygon":
            g = max(g.geoms, key=lambda p: p.area)
        area = round(g.area * af, 1)
        cat, rr, asp, corners = sw.classify_shape(g, area)
        feats.append({"type": "Feature", "geometry": mapping(g),
                      "properties": {"erf": None, "prcl": "",
                                     "has_building": 1, "n_build": 1,
                                     "area_m2": area, "shape": cat,
                                     "rect_ratio": rr, "aspect": asp,
                                     "corners": corners, "source": "standalone"}})

    fc = {"type": "FeatureCollection",
          "crs": {"type": "name", "properties": {"name": "EPSG:3857"}},
          "features": feats}
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(fc, f)

    from collections import Counter
    cnt = Counter(ft["properties"]["shape"] for ft in feats)
    res = {"features": len(feats), "occupied_erven": len(best_per_erf),
           "vacant_erven": n_vac, "standalone": len(noerf_rows),
           "boxes": total_boxes, "shapes": dict(cnt), "out": out_path}
    log(f"DONE {json.dumps(res)}")
    progress("RESULT " + json.dumps(res))
    return 0


if __name__ == "__main__":
    sys.exit(main())
