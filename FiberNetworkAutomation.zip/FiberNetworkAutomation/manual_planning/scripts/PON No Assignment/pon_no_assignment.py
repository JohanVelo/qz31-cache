import sys, os, re
if sys.stderr is None: sys.stderr = open(os.devnull, 'w')
if sys.stdout is None: sys.stdout = open(os.devnull, 'w')

# ============================================================
# PON NO ASSIGNMENT
# Project: Fibre Time (all projects)
# Assigns sequential integer pon_no to each PON.
# Order follows the C{n}P{n} labels created in Step 9.
# Enter the starting number to continue from a previous phase
# (e.g. Phase 1 ended at PON 180 → enter 181 here).
# Field updated: 'pon_no'
# ============================================================

PON_LAYER   = 'PON v1'
STARTING_NO = 1   # default — overridden by dialog below

from qgis.PyQt.QtWidgets import QInputDialog

start, ok = QInputDialog.getInt(
    None,
    'PON Number Assignment',
    'Enter starting PON number:\n'
    '  • 1 for a new standalone project\n'
    '  • (last PH1 PON + 1) to continue a phased project\n'
    '    e.g. Phase 1 ended at 180 → enter 181',
    STARTING_NO, 1, 9999, 1
)

if not ok:
    print("Cancelled.")
else:
    pon_layer = None
    for lyr in QgsProject.instance().mapLayers().values():
        if lyr.name() == PON_LAYER:
            pon_layer = lyr
            break

    if not pon_layer:
        print(f"ERROR: Layer '{PON_LAYER}' not found.")
    else:
        print(f"PON layer: {PON_LAYER} ({pon_layer.featureCount()} features)")
        print(f"Starting number: {start}")

        # Sort PONs by their C{n}P{n} label so numbering follows geographic order
        def label_key(f):
            lbl = str(f['label'] or '')
            m = re.match(r'C(\d+)P(\d+)', lbl)
            return (int(m.group(1)), int(m.group(2))) if m else (9999, 9999)

        features = sorted(pon_layer.getFeatures(), key=label_key)

        pon_no_idx = pon_layer.fields().indexOf('pon_no')
        if pon_no_idx == -1:
            print("ERROR: 'pon_no' field not found in PON layer.")
        else:
            pon_layer.startEditing()
            for i, f in enumerate(features):
                pon_layer.changeAttributeValue(f.id(), pon_no_idx, start + i)
            pon_layer.commitChanges()

            n = len(features)
            print("=" * 50)
            print(f"  PON NO ASSIGNMENT COMPLETE")
            print(f"  Total PONs: {n}")
            print(f"  Range:      {start} — {start + n - 1}")
            print("=" * 50)
            print("Sample — first 5:")
            for i, f in enumerate(pon_layer.getFeatures()):
                if i >= 5:
                    break
                print(f"  {f['label']} → pon_no = {f['pon_no']}")
            print("\nNow run Step 11 (Populate PON Attributes) to fill the rest of the PON fields.")
