# Fibertime: Label Secondary Cable Algorithm (MOA standard)

from qgis.core import (
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterField,
    QgsProcessing,
    QgsSpatialIndex,
    QgsPointXY
)

from .base_algorithm import BaseFiberAlgorithm

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

SLACK_FORMULA = """CASE
    WHEN $length <= 50 THEN 15
    WHEN $length <= 100 THEN 30
    WHEN $length <= 200 THEN 40
    ELSE 50
END"""


class FTSecondaryCableAlgorithm(BaseFiberAlgorithm):
    """Populate Fibertime Secondary Cable v1 — label + static fields (MOA standard)."""

    POLES_LAYER = 'POLES_LAYER'
    POLE_LABEL_FIELD = 'POLE_LABEL_FIELD'
    CABLE_LABEL_FIELD = 'CABLE_LABEL_FIELD'

    def name(self):
        return 'ft_label_secondary_cable'

    def displayName(self):
        return 'FT 3. Label Secondary Cable'

    def group(self):
        return 'Fibertime Network Labeling'

    def groupId(self):
        return 'fibertimenetworklabeling'

    def shortHelpString(self):
        return """
        Populate Fibertime Secondary Cable v1 fields.

        Requires Poles v1 as a reference layer to resolve start/end pole
        identifiers from cable endpoints (spatial nearest-neighbour lookup).

        Label format: MOA.SF.24F.P.[Start]-P.[End]
        Example:      MOA.SF.24F.P.H276-P.F461

        Fields updated:
        - [label field]: MOA.SF.24F.P.[Start]-P.[End]
        - subtyp: Mini-ADSS
        - spec: SM/G657A1
        - dim1: 5,6mm
        - cblcpty: 24F
        - ntwrkptn: Secondary
        - tlenght: cable length (m)
        - slenght: slack length
        - companyown / cmpownr: VelocityFibre
        - createdby / crtdby: Johan Scholtz
        - municipal / mun: JB Marks LM
        - subplace / mainplace / mainplce: 676007
        - stack / stackref: MOA

        Note: 'status' is deliberately not written (manually managed).

        ⚠️ Poles v1 label field must be populated first!
        """

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT,
                'Secondary Cable v1',
                [QgsProcessing.SourceType.TypeVectorLine]
            )
        )
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.POLES_LAYER,
                'Poles v1 (for endpoint lookup)',
                [QgsProcessing.SourceType.TypeVectorPoint]
            )
        )
        self.addParameter(
            QgsProcessingParameterField(
                self.POLE_LABEL_FIELD,
                'Pole label field (e.g. "label")',
                parentLayerParameterName=self.POLES_LAYER,
                defaultValue='label',
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterField(
                self.CABLE_LABEL_FIELD,
                'Cable label field to populate (e.g. "label")',
                parentLayerParameterName=self.INPUT,
                defaultValue='label',
                optional=True
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        from qgis.core import QgsDistanceArea, QgsProject
        try:
            from qgis.core import NULL
        except Exception:
            NULL = None

        cable_layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        poles_layer = self.parameterAsVectorLayer(parameters, self.POLES_LAYER, context)
        pole_label_field = self.parameterAsString(parameters, self.POLE_LABEL_FIELD, context) or 'label'
        cable_label_field = self.parameterAsString(parameters, self.CABLE_LABEL_FIELD, context) or 'label'

        # Defaults — verified against Master Material List 2026-04-28
        # Master cables tab row 23: Mini-ADSS / 24F → dim1 = 5,6mm
        DEFAULTS = {
            'type':     'Cable',
            'subtyp':   'Mini-ADSS',
            'spec':     'SM/G657A1',
            'dim1':     '5,6mm',
            'cblcpty':  '24F',
            'conntr':   '-',
            'ntwrkptn': 'Secondary',
            'cmpownr':  'VelocityFibre',
            'companyown':'VelocityFibre',
            'crtdby':   'Johan Scholtz',
            'createdby':'Johan Scholtz',
            'mun':      'JB Marks LM',
            'municipal':'JB Marks LM',
            'subplace': '676007',
            'mainplce': '676007',
            'mainplace':'676007',
            'stackref': 'MOA',
            'stack':    'MOA',
        }
        # NOTE: 'status' deliberately not in DEFAULTS — manually managed.
        SNAP_M = 5.0

        def _is_blank(v):
            if v is None: return True
            if NULL is not None:
                try:
                    if v == NULL: return True
                except Exception: _swallowed_note()
            if isinstance(v, str) and v.strip() in ('', 'NULL', 'null', 'None'):
                return True
            return False

        feedback.pushInfo(f"Building spatial index from {poles_layer.name()}...")
        index = QgsSpatialIndex(poles_layer.getFeatures())
        pole_labels = {}; pole_pts = {}
        for feat in poles_layer.getFeatures():
            raw = feat[pole_label_field]
            pole_labels[feat.id()] = str(raw).replace('MOA.P.', '') if raw else 'UNKNOWN'
            g = feat.geometry()
            if g and not g.isEmpty():
                pole_pts[feat.id()] = g.asPoint()
        feedback.pushInfo(f"Indexed {len(pole_labels)} poles.")

        # B4 fix 2026-04-28: read CRS from layer rather than hardcoding EPSG:4326
        da = QgsDistanceArea(); da.setEllipsoid('WGS84')
        da.setSourceCrs(cable_layer.crs(),
                        QgsProject.instance().transformContext())

        def _nearest_pole(pt):
            ids = index.nearestNeighbor(pt, 1)
            if not ids: return None, None
            pid = ids[0]; ppt = pole_pts.get(pid)
            if not ppt: return None, None
            d = da.measureLine([pt, ppt])
            if d > SNAP_M: return None, d
            return pole_labels.get(pid, 'UNKNOWN'), d

        flds = cable_layer.fields()
        idx = {n: flds.indexOf(n) for n in (
            cable_label_field, 'strtfeat', 'endfeat', 'tlenght', 'slenght', 'dim2',
            *DEFAULTS.keys()
        )}
        cable_label_idx = idx.get(cable_label_field, -1)

        total = cable_layer.featureCount()
        attr_map = {}
        for i, feat in enumerate(cable_layer.getFeatures()):
            if feedback.isCanceled(): return {}
            geom = feat.geometry()
            if not geom or geom.isEmpty(): continue
            vertices = list(geom.vertices())
            if len(vertices) < 2: continue

            row = {}
            for k, v in DEFAULTS.items():
                fidx = idx.get(k, -1)
                if fidx < 0: continue
                if _is_blank(feat[k]):
                    row[fidx] = v

            geo_len = round(da.measureLength(geom), 2)
            for tlen_field in ('tlenght', 'dim2'):
                tidx = idx.get(tlen_field, -1)
                if tidx < 0: continue
                cur = feat[tlen_field]
                if _is_blank(cur):
                    row[tidx] = geo_len
                else:
                    try:
                        if abs(float(str(cur).replace(',', '.')) - geo_len) > 1.0:
                            row[tidx] = geo_len
                    except Exception:
                        _swallowed_note()

            sidx = idx.get('slenght', -1)
            if sidx >= 0 and _is_blank(feat['slenght']):
                from qgis.core import QgsExpression, QgsExpressionContext, QgsExpressionContextUtils
                expr = QgsExpression(SLACK_FORMULA)
                ec = QgsExpressionContext()
                ec.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(cable_layer))
                ec.setFeature(feat)
                val = expr.evaluate(ec)
                if val is not None and not expr.hasEvalError():
                    row[sidx] = val

            start_label, _ = _nearest_pole(QgsPointXY(vertices[0]))
            end_label,   _ = _nearest_pole(QgsPointXY(vertices[-1]))

            if cable_label_idx >= 0 and _is_blank(feat[cable_label_field]):
                if start_label and end_label:
                    row[cable_label_idx] = f'MOA.SF.24F.P.{start_label}-P.{end_label}'

            sf_idx = idx.get('strtfeat', -1)
            ef_idx = idx.get('endfeat', -1)
            if sf_idx >= 0 and start_label and _is_blank(feat['strtfeat']):
                row[sf_idx] = f'MOA.P.{start_label}'
            if ef_idx >= 0 and end_label and _is_blank(feat['endfeat']):
                row[ef_idx] = f'MOA.P.{end_label}'

            if row:
                attr_map[feat.id()] = row
            if total > 0:
                feedback.setProgress(int(i / total * 100))

        if attr_map:
            cable_layer.dataProvider().changeAttributeValues(attr_map)
        cable_layer.triggerRepaint()
        feedback.pushInfo(f"✅ Secondary Cable: updated {len(attr_map)} features (fill-null-only).")
        return {self.INPUT: cable_layer.id()}

    def createInstance(self):
        return FTSecondaryCableAlgorithm()
