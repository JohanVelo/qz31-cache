"""Config-driven hierarchical numbering for the Labeling Wizard (Structure mode).

Consumes the (walks, anomalies) output of structure_graph.traverse and turns
it into labels.  Pure Python stdlib only — no QGIS / Qt / shapely / networkx /
numpy — importable identically inside QGIS 4.0.3 python and plain Python 3.12,
Hypothesis-property-testable (tests/property/test_numbering.py).

THE central abstraction is HierarchyConfig: the labeling structure is FULLY
customizable per project — there is no fixed hierarchy.  Nothing here
hardcodes any client tier names; herotel_pon_config() is merely a convenience
preset.  Each Level chooses:

  * an arbitrary name + the data cls/role it matches (any number of tiers);
  * a NUMBERING MODE   — "walk_order" (chainage-ordered preorder counter,
                          the default), "sequential" (plain counter, default
                          scope global), "spatial_polygon" (point-in-polygon:
                          counter restarts per containing zone polygon and
                          {zone} resolves to that polygon id), "keep" (leave
                          the existing label untouched);
  * a restart SCOPE    — "parent" | "root" | "zone" | "global";
  * a LABEL TEMPLATE   — str with substitution tokens resolved from the
                          parent label, the feature's attrs, the containing
                          zone and config-level constants, e.g.
                          "{owner}{proj}{zone}{parent}{sep}{n:0{pad}d}"
                          — or a callable for anything fancier.

HierarchyConfig serializes: to_dict() / from_dict() round-trip (JSON-safe),
so a config can be saved as a named preset per client + project and reused.

Deterministic: preorder walk items are numbered with a counter stack keyed by
(level, restart-scope); the same walk always yields identical labels.

API:
    Level, HierarchyConfig, herotel_pon_config()
    assign_labels(walk, config, anomalies=None, existing=None, zones=None)
        -> {feature_id: label | None}
        walk may be one walk dict, a list of walks, or the (walks, anomalies)
        tuple straight from traverse.  Fatally-flagged / unreachable /
        off-network features -> None (never a wrong number); children of an
        unlabeled parent -> None.  Merged-run member segments all receive the
        run's ONE label.  existing feeds mode="keep"; zones feeds
        mode="spatial_polygon" ([{"id":..., "rings":[[(x,y),...],...]}]).
    zone_of(pon, base, per_zone, zone_base)  — generalized zone/OLT rule,
        fully parameterized (nothing baked in).
    dry_run_summary(labels, existing) -> {changes, duplicates, gaps,
        collisions}  — pure preview helper.  NOTE: member segments of a
        merged run intentionally share the run's label, so they appear under
        "duplicates"; pass canonical-feature labels only if that is unwanted.
"""
from dataclasses import dataclass, field

_MODES = ("walk_order", "sequential", "spatial_polygon", "keep")
_RESTARTS = ("parent", "root", "zone", "global")


# ---------------------------------------------------------------------------
# hierarchy config
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Level:
    """One tier of the hierarchy — every knob is per-level.

    name        : level identifier, unique in the config (any string).
    cls_or_role : the Segment cls (cable level) or Point role (point level)
                  this tier matches in the data.
    parent      : name of the parent level, or None for a root level, or a
                  tuple/list of names for a level that may hang off ANY of
                  several parents.  A level MAY list its OWN name as a parent
                  ("self-branch") — e.g. a distribution run that branches into
                  more distribution runs (trunk -> sub-trunk).  The label uses
                  whichever parent was actually walked; pick restart="root" or
                  "zone" so a branching level numbers flat across the subtree.
    kind        : "point" | "cable" | "auto" (auto = inferred from the data).
    mode        : numbering strategy — one of "walk_order" (default),
                  "sequential", "spatial_polygon", "keep".
    restart     : counter scope — "parent" (default; "sequential" defaults to
                  "global", "spatial_polygon" to "zone"), "root", "zone",
                  "global".
    sep / pad   : used by the default label format.
    fmt         : None -> default "{parent}{sep}{n:0{pad}d}" (root levels
                  without a parent label default to "{level}{n:0{pad}d}");
                  a str is .format()-ed with tokens parent, sep, n, pad,
                  level, zone, plus the feature's attrs and the config's
                  constants; a callable is called with the same kwargs
                  (attrs/constants passed via **tokens).
    """
    name: str
    cls_or_role: str
    parent: object = None
    kind: str = "auto"
    mode: str = "walk_order"
    restart: str = ""
    sep: str = "."
    pad: int = 2
    fmt: object = None

    def __post_init__(self):
        if isinstance(self.parent, list):     # normalize list -> tuple so a
            object.__setattr__(self, "parent", tuple(self.parent))  # config
        if self.mode not in _MODES:           # round-trips + compares by value
            raise ValueError("level %r: unknown mode %r (want one of %s)"
                             % (self.name, self.mode, list(_MODES)))
        if self.restart and self.restart not in _RESTARTS:
            raise ValueError("level %r: unknown restart %r (want one of %s)"
                             % (self.name, self.restart, list(_RESTARTS)))

    def parent_names(self):
        """Parent level names as a tuple (() for a root level)."""
        p = self.parent
        if p is None:
            return ()
        if isinstance(p, (list, tuple)):
            return tuple(p)
        return (p,)

    @property
    def effective_restart(self):
        if self.restart:
            return self.restart
        if self.mode == "sequential":
            return "global"
        if self.mode == "spatial_polygon":
            return "zone"
        return "parent"


@dataclass(frozen=True)
class HierarchyConfig:
    """Ordered set of Levels forming a tree (validated on construction).

    name      : optional preset name (e.g. "HeroTel PON v1" / a project id).
    constants : substitution tokens available to every level's fmt
                (e.g. {"owner": "VF", "proj": "MOA"}).
    """
    levels: tuple
    name: str = ""
    constants: dict = field(default_factory=dict)

    def __post_init__(self):
        object.__setattr__(self, "levels", tuple(self.levels))
        object.__setattr__(self, "constants", dict(self.constants))
        names = [lv.name for lv in self.levels]
        if len(set(names)) != len(names):
            raise ValueError("duplicate level names: %r" % (names,))
        if not self.levels:
            raise ValueError("config needs at least one level")
        by_name = {lv.name: lv for lv in self.levels}
        roots = 0
        for lv in self.levels:
            pnames = lv.parent_names()
            if not pnames:
                roots += 1
            for pn in pnames:
                if pn not in by_name:
                    raise ValueError("level %r has unknown parent %r"
                                     % (lv.name, pn))
        # Cycle check among DISTINCT levels — a level naming itself as a parent
        # (self-branch, e.g. distribution -> sub-distribution) is allowed and
        # skipped here; a mutual A->B->A between different levels is rejected.
        _white, _grey, _black = 0, 1, 2
        color = {lv.name: _white for lv in self.levels}

        def _dfs(node):
            color[node] = _grey
            for pn in by_name[node].parent_names():
                if pn == node:
                    continue                  # self-branch is legal
                if color[pn] == _grey:
                    raise ValueError("cycle in level parents at %r" % pn)
                if color[pn] == _white:
                    _dfs(pn)
            color[node] = _black

        for lv in self.levels:
            if color[lv.name] == _white:
                _dfs(lv.name)
        if roots == 0:
            raise ValueError("config needs at least one root level "
                             "(parent=None)")

    def level(self, name):
        for lv in self.levels:
            if lv.name == name:
                return lv
        raise KeyError(name)

    def children_of(self, name):
        return tuple(lv for lv in self.levels if name in lv.parent_names())

    def roots(self):
        return tuple(lv for lv in self.levels if not lv.parent_names())

    # -- serialization (JSON-safe) — saved presets per client + project -----

    def to_dict(self):
        """JSON-safe dict.  Callable fmt cannot serialize -> ValueError."""
        levels = []
        for lv in self.levels:
            if callable(lv.fmt):
                raise ValueError("level %r has a callable fmt — not "
                                 "serializable; use a token template string"
                                 % lv.name)
            parent = list(lv.parent) if isinstance(lv.parent, tuple) \
                else lv.parent
            levels.append({"name": lv.name, "cls_or_role": lv.cls_or_role,
                           "parent": parent, "kind": lv.kind,
                           "mode": lv.mode, "restart": lv.restart,
                           "sep": lv.sep, "pad": lv.pad, "fmt": lv.fmt})
        return {"name": self.name, "constants": dict(self.constants),
                "levels": levels}

    @classmethod
    def from_dict(cls, d):
        levels = tuple(
            Level(name=e["name"], cls_or_role=e["cls_or_role"],
                  parent=e.get("parent"), kind=e.get("kind", "auto"),
                  mode=e.get("mode", "walk_order"),
                  restart=e.get("restart", ""), sep=e.get("sep", "."),
                  pad=int(e.get("pad", 2)), fmt=e.get("fmt"))
            for e in d.get("levels", ()))
        return cls(levels=levels, name=d.get("name", ""),
                   constants=dict(d.get("constants") or {}))

    def __eq__(self, other):
        if not isinstance(other, HierarchyConfig):
            return NotImplemented
        return (self.name == other.name
                and self.constants == other.constants
                and self.levels == other.levels)

    __hash__ = None  # mutable constants dict — configs compare by value


def herotel_pon_config():
    """Convenience preset: a HeroTel-style per-zone PON hierarchy.

    FTS (root, one per zone) -> DISTRIBUTION runs (tap multiple STS mid-span)
    -> STS -> DROP -> DEMAND.  Purely an example input — the engine treats it
    like any other HierarchyConfig; build your own per project (any tier
    names, any depth, e.g. a PRIMARY/POP level above) without code changes.
    """
    return HierarchyConfig(name="herotel_pon", levels=(
        Level("FTS", "FTS", None, kind="point", fmt="FTS{n:02d}"),
        # DIST hangs off the FTS OR off another DIST (a trunk branching into
        # sub-trunks); restart="root" numbers every distribution run in the
        # subtree with one flat counter (DC01, DC02, ... per FTS).
        Level("DIST", "DISTRIBUTION", ("FTS", "DIST"), kind="cable",
              restart="root"),
        Level("STS", "STS", "DIST", kind="point"),
        Level("DROP", "DROP", "STS", kind="cable"),
        Level("DEMAND", "DEMAND", "DROP", kind="point"),
    ))


# ---------------------------------------------------------------------------
# label assignment
# ---------------------------------------------------------------------------

def _pip(x, y, ring):
    """Point-in-polygon (ray cast) — same approach as feeder_walk._pip."""
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if ((yi > y) != (yj > y)) and \
                (x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-12) + xi):
            inside = not inside
        j = i
    return inside


def _zone_of_xy(xy, zones):
    """Id of the first zone polygon (sorted by str(id)) containing xy."""
    if xy is None or not zones:
        return None
    for z in sorted(zones, key=lambda z: str(z.get("id"))):
        for ring in z.get("rings", ()):
            if len(ring) >= 3 and _pip(xy[0], xy[1], ring):
                return z.get("id")
    return None


def _format_label(level, parent_label, n, tokens):
    fmt = level.fmt
    ctx = dict(tokens)
    ctx.update(parent=parent_label or "", n=n, level=level.name,
               sep=level.sep, pad=level.pad)
    ctx.setdefault("zone", "")
    if callable(fmt):
        return fmt(**ctx)
    if isinstance(fmt, str):
        return fmt.format(**ctx)
    if parent_label:
        return "{parent}{sep}{n:0{pad}d}".format(
            parent=parent_label, sep=level.sep, n=n, pad=level.pad)
    return "{level}{n:0{pad}d}".format(level=level.name, n=n, pad=level.pad)


def _normalize_walks(walk, anomalies):
    if isinstance(walk, tuple) and len(walk) == 2 \
            and isinstance(walk[0], (list, tuple)):
        walks, anoms = list(walk[0]), list(walk[1])
    elif isinstance(walk, dict):
        walks, anoms = [walk], []
    else:
        walks, anoms = list(walk or []), []
    if anomalies:
        anoms.extend(anomalies)
    return walks, anoms


# anomaly codes that must NULL a label (mirrors structure_graph.FATAL_CODES —
# kept literal here so this module stays import-independent of it)
_FATAL_CODES = frozenset({
    "point_off_network", "unreachable", "loop_closed", "zone_mismatch",
})


def assign_labels(walk, config, anomalies=None, existing=None, zones=None):
    """Number every walk item; return {feature_id: label or None}.

    Counter stack keyed by (level, restart scope): the child index restarts
    per parent label / per root / per zone / never, per the level config.
    Preorder guarantees every parent is labeled before its children.
    Flagged items, children of unlabeled parents, and unreachable /
    off-network features from the anomaly list -> None.

    existing : {feature_id: current label} — consumed by mode="keep" levels.
    zones    : zone polygons for mode="spatial_polygon" / restart="zone"
               ([{"id":..., "rings": [[(x,y),...], ...]}]); items may also
               carry an explicit "zone" value (traverse provides one), which
               is used when no polygon matches.
    """
    walks, anoms = _normalize_walks(walk, anomalies)
    existing = existing or {}
    by_name = {lv.name: lv for lv in config.levels}
    labels = {}
    counters = {}
    for w in walks:
        root_id = w.get("root")
        for it in w.get("items", ()):
            fid = it.get("feature_id")
            lv = by_name.get(it.get("level"))
            members = it.get("members") or ()
            if lv is None or it.get("flagged"):
                labels[fid] = None
                for m in members:
                    labels.setdefault(m, None)
                continue
            parent_id = it.get("parent_id")
            if parent_id is None:
                parent_label = ""
            else:
                parent_label = labels.get(parent_id)
                if parent_label is None:      # parent NULLed -> child NULLed
                    labels[fid] = None
                    for m in members:
                        labels.setdefault(m, None)
                    continue
            if lv.mode == "keep":             # leave existing label untouched
                lab = existing.get(fid)
                labels[fid] = lab
                for m in members:
                    if m != fid:
                        labels.setdefault(m, existing.get(m, lab))
                continue
            zone = None
            if lv.mode == "spatial_polygon" or lv.effective_restart == "zone":
                zone = _zone_of_xy(it.get("xy"), zones)
                if zone is None:
                    zone = it.get("zone")
            restart = lv.effective_restart
            if restart == "global":
                key = (lv.name,)
            elif restart == "root":
                key = (lv.name, str(root_id))
            elif restart == "zone":
                key = (lv.name, str(zone))
            else:
                key = (lv.name, parent_label)
            n = counters.get(key, 0) + 1
            counters[key] = n
            tokens = dict(config.constants)
            tokens.update(it.get("attrs") or {})
            if zone is None:
                zone = it.get("zone")
            if zone is not None:
                tokens["zone"] = zone
            lab = _format_label(lv, parent_label, n, tokens)
            labels[fid] = lab
            for m in members:
                if m != fid:
                    labels.setdefault(m, lab)
    for a in anoms:
        if a.get("code") in _FATAL_CODES and a.get("feature_id") is not None:
            labels.setdefault(a["feature_id"], None)
    return labels


# ---------------------------------------------------------------------------
# generalized zone rule + dry-run preview
# ---------------------------------------------------------------------------

def zone_of(pon, base, per_zone, zone_base):
    """Generalized FTTH zone/OLT rule: (pon - base) // per_zone + zone_base.

    Fully parameterized — nothing baked in (a Potch-MOA caller would pass
    base=235, per_zone=16, zone_base=17; other projects pass their own).
    """
    per_zone = int(per_zone)
    if per_zone <= 0:
        raise ValueError("per_zone must be a positive integer")
    return (int(pon) - int(base)) // per_zone + int(zone_base)


def _split_trailing_int(label):
    """Split 'FTS01.03' -> ('FTS01.', 3); None if no trailing digits."""
    i = len(label)
    while i and label[i - 1].isdigit():
        i -= 1
    if i == len(label):
        return None
    return label[:i], int(label[i:])


def dry_run_summary(labels, existing):
    """Preview a relabel without touching anything.

    labels   : {feature_id: new label or None}  (from assign_labels)
    existing : {feature_id: current label or None}
    Returns {"changes": [{feature_id, old, new}, ...],
             "duplicates": {label: [feature_ids]},       (new labels used >1x)
             "gaps": {scope_prefix: [missing ints]},     (per restart scope)
             "collisions": [{feature_id, label, existing_feature}, ...]}
    A collision = a new label equals a DIFFERENT feature's existing label
    while that other feature is being renumbered away from it; if the other
    feature keeps the same label they intentionally share (merged-run
    members) and show under "duplicates" instead.
    """
    existing = existing or {}
    all_fids = sorted(set(labels) | set(existing), key=str)
    changes = [{"feature_id": f, "old": existing.get(f), "new": labels.get(f)}
               for f in all_fids if existing.get(f) != labels.get(f)]

    by_label = {}
    for f in sorted(labels, key=str):
        lab = labels[f]
        if lab is None:
            continue
        by_label.setdefault(lab, []).append(f)
    duplicates = {lab: fids for lab, fids in sorted(by_label.items())
                  if len(fids) > 1}

    scopes = {}
    for lab in by_label:
        sp = _split_trailing_int(lab)
        if sp is None:
            continue
        scopes.setdefault(sp[0], set()).add(sp[1])
    gaps = {}
    for prefix in sorted(scopes):
        nums = scopes[prefix]
        missing = sorted(set(range(min(nums), max(nums) + 1)) - nums)
        if missing:
            gaps[prefix] = missing

    ex_by_label = {}
    for f in sorted(existing, key=str):
        if existing[f] is not None:
            ex_by_label.setdefault(existing[f], []).append(f)
    collisions = []
    for f in sorted(labels, key=str):
        lab = labels[f]
        if lab is None:
            continue
        for other in ex_by_label.get(lab, ()):
            if other != f and labels.get(other) != lab:
                collisions.append({"feature_id": f, "label": lab,
                                   "existing_feature": other})
    return {"changes": changes, "duplicates": duplicates, "gaps": gaps,
            "collisions": collisions}
