"""BoQ engine constants + per-layer measurement rules (pure data)."""
from dataclasses import dataclass, field

# Projected CRS for length measurement. UTM 35S covers Potch/Mohadin (MOA PH2).
# The whole reliability story: ALWAYS measure in metres in a projected CRS,
# NEVER in EPSG:4326 degrees (the ~111x phantom-length bug in the old tool).
MOA_UTM = "EPSG:32735"

SECTION_CABLE = "CABLE"
SECTION_EQUIP = "EQUIPMENT"
SECTION_POLE = "POLE"
SECTION_ONT = "ONT"


@dataclass
class MeasurementRule:
    key: str                       # stable id + rate_key default
    layer_tokens: list             # ALL must appear (lowercased) in the layer name
    measure: str                   # 'length' | 'count'
    section: str
    group_by: str = None           # attribute to split rows (e.g. 'cable_size')
    dedup_by: str = "label"        # group features by this attr, sum length ONCE (trunk dedup)
    unit: str = "m"
    spool_size_m: float = None     # report spools = ceil(ordered / spool_size_m)
    slack_pct: float = 0.0         # field-routing wiggle, applied as x(1+slack)
    sag_pct: float = 0.0           # aerial ADSS catenary, separate from slack
    rate_key: str = ""
    exclude_tokens: list = field(default_factory=lambda: ["spare", "backup",
                                                          "old", "v0", "proposed", "draft"])

    def rkey(self):
        return self.rate_key or self.key


# Order = display order. Tokens are matched case-insensitively, ALL required.
DEFAULT_RULES = [
    MeasurementRule("primary_144F", ["primary"], "length", SECTION_CABLE,
                    group_by=None, spool_size_m=4000.0, slack_pct=0.05,
                    sag_pct=0.012, rate_key="primary_144F"),
    MeasurementRule("secondary", ["secondary"], "length", SECTION_CABLE,
                    group_by=None, spool_size_m=4000.0, slack_pct=0.07,
                    sag_pct=0.015, rate_key="secondary"),
    MeasurementRule("distribution_24F", ["distribution"], "length", SECTION_CABLE,
                    group_by=None, spool_size_m=4000.0, slack_pct=0.08,
                    sag_pct=0.015, rate_key="distribution_24F"),
    MeasurementRule("drop_1F", ["drop"], "length", SECTION_CABLE,
                    group_by=None, spool_size_m=500.0, slack_pct=0.10,
                    rate_key="drop_1F"),
    MeasurementRule("splitter_fts", ["fts"], "count", SECTION_EQUIP,
                    group_by=None, rate_key="splitter_fts_1x8"),
    MeasurementRule("splitter_sts", ["sts"], "count", SECTION_EQUIP,
                    group_by=None, rate_key="splitter_sts_1x16"),
    MeasurementRule("enclosure_splice", ["enclosure", "splice"], "count", SECTION_EQUIP,
                    group_by=None, rate_key="enclosure_dis"),
    MeasurementRule("enclosure_conn", ["enclosure", "connector"], "count", SECTION_EQUIP,
                    group_by=None, rate_key="enclosure_agg"),
    MeasurementRule("pole", ["pole"], "count", SECTION_POLE,
                    group_by=None, rate_key="pole_intermediate_120_140"),
    MeasurementRule("ont", ["ont"], "count", SECTION_ONT,
                    group_by=None, rate_key="ont"),
]

# m-of-cable per ONT sanity band (catches a phantom-length / double-count blowout).
# Lower bound 12 m suits DENSE informal settlements (very short drops, ~14 m avg);
# upper bound 300 m covers sparse rural. Outside this → likely CRS/double-count bug.
SANE_M_PER_ONT = (12.0, 300.0)
