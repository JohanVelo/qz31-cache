"""kmz_export — turn the designed network into a KMZ for Google Earth / field phones.

ZERO external dependencies: KML is plain XML, KMZ is a zip, and everything else is
PyQGIS core (coordinate transform to WGS84). So it ships in the team plugin and runs
inside QGIS's bundled Python — no duckdb/simplekml/geopandas needed.

Read-only on the project: it never edits a layer. Exports the *visible* vector layers
(what the planner sees on the canvas), each as a KML Folder with a sensible colour by
name, point/line/polygon Placemarks, and the feature's label as the Placemark name so
a field tech can tap a pole/home and read its number in Google Earth.

API:  build_kmz(layers, out_path, feedback=None) -> {"layers":n, "features":n, "path":..}
"""
import os
import zipfile
from xml.sax.saxutils import escape

from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform,
                       QgsProject, QgsGeometry, QgsWkbTypes)

# RGB by name keyword (first match wins). KML wants aabbggrr, converted below.
_PALETTE = [
    (("ont", "home"),                 "FFE100"),   # homes — yellow
    (("pole",),                       "FF8C00"),   # poles — orange
    (("fts",),                        "FF2D55"),   # FTS splitter — red
    (("sts",),                        "FF2DD4"),   # STS splitter — magenta
    (("splitter", "enclosure"),       "2DD4FF"),   # other splitters/domes — cyan
    (("drop",),                       "3DFF9A"),   # drop cable — green
    (("distribution",),               "2D7DFF"),   # distribution — blue
    (("secondary",),                  "9A4DFF"),   # secondary — purple
    (("primary", "feeder", "trunk"),  "FF4D2D"),   # primary/feeder — red-orange
    (("span", "cable"),               "7DC8FF"),   # generic cable — light blue
    (("pon",),                        "2DD4BF"),   # PON polygons — teal
    (("zone",),                       "FFD24D"),   # zones — amber
    (("erf", "erven", "stand"),       "B0B8C4"),   # erven — grey
    (("aoi", "boundary"),             "FF3B30"),   # AOI — red
]
_DEFAULT_RGB = "F2F7FF"          # off-white for anything unmatched


def _rgb_for(layer_name):
    nl = (layer_name or "").lower()
    for keys, rgb in _PALETTE:
        if any(k in nl for k in keys):
            return rgb
    return _DEFAULT_RGB


def _symbol_style(layer):
    """Pull (rgb_hex, line_width_px_or_None) from the layer's LIVE renderer symbol,
    so whatever styling the user sets in QGIS carries into the KMZ. Falls back to the
    by-name palette + default width if the renderer can't be read (e.g. rule-based)."""
    try:
        from qgis.core import QgsRenderContext
        r = layer.renderer()
        sym = None
        if r is not None and hasattr(r, "symbol") and r.symbol() is not None:
            sym = r.symbol()                      # single-symbol renderer
        elif r is not None and hasattr(r, "symbols"):
            syms = r.symbols(QgsRenderContext())  # categorized/graduated -> first symbol
            sym = syms[0] if syms else None
        if sym is not None:
            c = sym.color()
            rgb = f"{c.red():02X}{c.green():02X}{c.blue():02X}"
            width = None
            try:
                w = sym.width()                    # QgsLineSymbol width (mm)
                if w and w > 0:
                    width = max(1.0, round(w * 3.0, 1))
            except Exception:
                pass
            return rgb, width
    except Exception:
        pass
    return _rgb_for(layer.name()), None


def _kml_colour(rgb, alpha="ff"):
    """RRGGBB (web) -> aabbggrr (KML's byte order)."""
    rgb = rgb.lstrip("#")
    rr, gg, bb = rgb[0:2], rgb[2:4], rgb[4:6]
    return f"{alpha}{bb}{gg}{rr}".lower()


def _name_field(layer):
    fields = [f.name() for f in layer.fields()]
    for cand in ("label", "label_1", "name", "Name", "pon_no", "id"):
        for f in fields:
            if f.lower() == cand.lower():
                return f
    return None


def _coords(pts):
    """list[QgsPointXY] -> KML 'lon,lat,0 lon,lat,0 ...' (KML is lon,lat order)."""
    return " ".join(f"{p.x():.7f},{p.y():.7f},0" for p in pts)


def _placemarks(geom, gtype, style_id, label):
    """Yield Placemark XML strings for one (already WGS84) geometry."""
    nm = f"<name>{escape(str(label))}</name>" if label not in (None, "") else ""
    head = f'<Placemark>{nm}<styleUrl>#{style_id}</styleUrl>'
    if gtype == QgsWkbTypes.GeometryType.PointGeometry:
        pts = geom.asMultiPoint() if geom.isMultipart() else [geom.asPoint()]
        for p in pts:
            yield f'{head}<Point><coordinates>{p.x():.7f},{p.y():.7f},0</coordinates></Point></Placemark>'
    elif gtype == QgsWkbTypes.GeometryType.LineGeometry:
        lines = geom.asMultiPolyline() if geom.isMultipart() else [geom.asPolyline()]
        for ln in lines:
            if len(ln) >= 2:
                yield (f'{head}<LineString><tessellate>1</tessellate>'
                       f'<coordinates>{_coords(ln)}</coordinates></LineString></Placemark>')
    elif gtype == QgsWkbTypes.GeometryType.PolygonGeometry:
        polys = geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]
        for poly in polys:
            if not poly:
                continue
            rings = [f'<outerBoundaryIs><LinearRing><coordinates>{_coords(poly[0])}'
                     f'</coordinates></LinearRing></outerBoundaryIs>']
            for hole in poly[1:]:
                rings.append(f'<innerBoundaryIs><LinearRing><coordinates>{_coords(hole)}'
                             f'</coordinates></LinearRing></innerBoundaryIs>')
            yield f'{head}<Polygon>{"".join(rings)}</Polygon></Placemark>'


def build_kmz(layers, out_path, feedback=None, max_features=300000):
    """Write a KMZ of the given vector layers to out_path. Returns a summary dict.

    feedback: optional object with .setProgress(0-100)/.pushInfo(str) (QgsProcessingFeedback
    or a shim) — best-effort, all calls guarded.
    """
    wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
    styles, folders = [], []
    total_feats = 0
    layers = [l for l in layers if l is not None]

    for li, layer in enumerate(layers):
        try:
            if layer.type() != layer.type().__class__.VectorLayer:  # vector only
                continue
        except Exception:
            pass
        gtype = layer.geometryType()
        if gtype not in (QgsWkbTypes.GeometryType.PointGeometry,
                         QgsWkbTypes.GeometryType.LineGeometry,
                         QgsWkbTypes.GeometryType.PolygonGeometry):
            continue
        rgb, sym_width = _symbol_style(layer)   # live QGIS styling -> KMZ
        line_w = sym_width if sym_width else 2.4
        def _mk_style(sid_, rgb_, width_):
            if gtype == QgsWkbTypes.GeometryType.PointGeometry:
                return (f'<Style id="{sid_}"><IconStyle><color>{_kml_colour(rgb_)}</color>'
                        f'<scale>0.9</scale><Icon><href>http://maps.google.com/mapfiles/kml/'
                        f'shapes/placemark_circle.png</href></Icon></IconStyle>'
                        f'<LabelStyle><scale>0.7</scale></LabelStyle></Style>')
            if gtype == QgsWkbTypes.GeometryType.LineGeometry:
                return (f'<Style id="{sid_}"><LineStyle><color>{_kml_colour(rgb_)}</color>'
                        f'<width>{width_ or line_w}</width></LineStyle></Style>')
            return (f'<Style id="{sid_}"><LineStyle><color>{_kml_colour(rgb_)}</color>'
                    f'<width>1.6</width></LineStyle><PolyStyle>'
                    f'<color>{_kml_colour(rgb_, "44")}</color></PolyStyle></Style>')

        # Categorized renderers -> one KML style per category (matches QGIS exactly,
        # e.g. poles 5m vs 7m in different colours); everything else -> single style.
        cat_field, style_map, default_sid = None, {}, f"s{li}"
        try:
            from qgis.core import QgsCategorizedSymbolRenderer
            rnd = layer.renderer()
            if isinstance(rnd, QgsCategorizedSymbolRenderer):
                cat_field = rnd.classAttribute()
                for ci, cat in enumerate(rnd.categories()):
                    sym = cat.symbol()
                    col = sym.color() if sym else None
                    crgb = f"{col.red():02X}{col.green():02X}{col.blue():02X}" if col else rgb
                    cw = None
                    try:
                        w = sym.width()
                        if w and w > 0:
                            cw = max(1.0, round(w * 3.0, 1))
                    except Exception:
                        pass
                    csid = f"s{li}_{ci}"
                    styles.append(_mk_style(csid, crgb, cw))
                    style_map[str(cat.value())] = csid
                if style_map:
                    default_sid = next(iter(style_map.values()))
        except Exception:
            cat_field, style_map = None, {}
        if not style_map:
            styles.append(_mk_style(default_sid, rgb, sym_width))

        nf = _name_field(layer)
        xform = QgsCoordinateTransform(layer.crs(), wgs84, QgsProject.instance())
        marks, n = [], 0
        for ft in layer.getFeatures():
            if total_feats + n >= max_features:
                break
            g = ft.geometry()
            if not g or g.isEmpty():
                continue
            gg = QgsGeometry(g)
            try:
                if gg.transform(xform) != 0:
                    continue
            except Exception:
                continue
            style_id = default_sid
            if cat_field:
                style_id = style_map.get(str(ft[cat_field]), default_sid)
            label = ft[nf] if nf else None
            for pm in _placemarks(gg, gtype, style_id, label):
                marks.append(pm)
            n += 1
        total_feats += n
        folders.append(f'<Folder><name>{escape(layer.name())}</name>'
                       f'<open>0</open>{"".join(marks)}</Folder>')
        if feedback is not None:
            try:
                feedback.setProgress(int((li + 1) / max(len(layers), 1) * 100))
                feedback.pushInfo(f"{layer.name()}: {n} features")
            except Exception:
                pass

    doc = (f'<?xml version="1.0" encoding="UTF-8"?>'
           f'<kml xmlns="http://www.opengis.net/kml/2.2"><Document>'
           f'<name>{escape(os.path.splitext(os.path.basename(out_path))[0])}</name>'
           f'{"".join(styles)}{"".join(folders)}</Document></kml>')

    if not out_path.lower().endswith(".kmz"):
        out_path += ".kmz"
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("doc.kml", doc)
    return {"layers": len(folders), "features": total_feats, "path": out_path}
