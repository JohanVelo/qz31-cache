# claude:approved-destructive - handlers moved verbatim from dock_widget.py; writes only on explicit UI actions
"""RenumberMixin: the Network Planner Zone and PON renumber dialogs.

Moved verbatim out of dock_widget.py (2026-09-22) - FTTHPlanToolDockWidget inherits it, so
every call and signal connection resolves as before. Import only via dock_widget."""
from qgis.core import Qgis  # Qt6: messageBar/log levels are Qgis.MessageLevel enums
from qgis.PyQt.QtCore import Qt
try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass
try:
    from fibre_automation.shared.vf_paths import MAXPATH_BUDGET as _BACKUP_PATH_BUDGET
    from fibre_automation.shared.vf_paths import spill_root as _vf_shared_spill_root
except Exception:                                    # pragma: no cover
    _BACKUP_PATH_BUDGET = 245
    _vf_shared_spill_root = None
from .dock_widget import (  # noqa: E402 - defined before dock_widget imports this module
    ZonePickTool,
)



class RenumberMixin:
    """Methods of FTTHPlanToolDockWidget; relies on its attributes, never instantiated alone."""

    def _open_zone_renumber(self):
        """Manual renumber: click the zones on the canvas in the order you want them,
        adjust freely (re-click removes, Undo, Clear), then Finalize — which renumbers
        the zone id + label + every splitter/feature inside each zone, project-wide.
        Sandbox-guarded, backs up first. This is JJ's reliable click-zones flow."""
        import os as _os
        from qgis.PyQt.QtWidgets import (
            QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QSpinBox,
            QTableWidget, QTableWidgetItem, QMessageBox, QWidget, QFrame,
            QSizePolicy)
        from qgis.PyQt.QtCore import Qt, QMetaType, QRect, QPoint
        from qgis.PyQt.QtGui import (QColor, QPainter, QPen, QFont, QFontDatabase)
        from qgis.core import (QgsProject, QgsVectorLayer, QgsField, QgsFeature,
                               QgsGeometry, QgsPalLayerSettings, QgsTextFormat,
                               QgsVectorLayerSimpleLabeling)

        # Bundle the brand fonts (Chakra Petch display + JetBrains Mono data) so the
        # Cable-Rail dialog looks the same on every machine; harmless if missing.
        try:
            _fdir = _os.path.join(_os.path.dirname(__file__), "fonts")
            if not getattr(self, "_brand_fonts_loaded", False) and _os.path.isdir(_fdir):
                for _fn in _os.listdir(_fdir):
                    if _fn.lower().endswith((".ttf", ".otf")):
                        QFontDatabase.addApplicationFont(_os.path.join(_fdir, _fn))
                self._brand_fonts_loaded = True
        except Exception:
            _swallowed_note()

        class RailNode(QWidget):
            """The numbered cable-rail node: a cyan vertical line + a numbered circle
            (filled when 'done'). Drawn so consecutive nodes' lines join into one rail."""

            def __init__(self, label, done=False, first=False, last=False):
                super().__init__()
                self._label, self._done = label, done
                self._first, self._last = first, last
                self.setFixedWidth(34)
                self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)

            def paintEvent(self, _e):
                p = QPainter(self)
                p.setRenderHint(QPainter.RenderHint.Antialiasing)
                cx, cy, r = 17, 14, 10
                cyan = QColor("#22d3ee")
                pen = QPen(cyan)
                pen.setWidth(2)
                p.setPen(pen)
                top = (cy + r) if self._first else 0
                bot = cy if self._last else self.height()
                if bot > top:
                    p.drawLine(cx, top, cx, bot)
                if self._done:
                    p.setBrush(cyan)
                    p.setPen(QPen(cyan, 2))
                else:
                    p.setBrush(QColor("#11141a"))
                    p.setPen(QPen(cyan, 2))
                p.drawEllipse(QPoint(cx, cy), r, r)
                p.setPen(QColor("#062229") if self._done else cyan)
                _f = QFont("JetBrains Mono")
                _f.setPointSize(8)
                _f.setBold(True)
                p.setFont(_f)
                p.drawText(QRect(cx - r, cy - r, 2 * r, 2 * r),
                           int(Qt.AlignmentFlag.AlignCenter), self._label)

        if not self._pon_project_is_sandbox():
            QMessageBox.warning(
                self, "Renumber Zones — BETA",
                "🔒 Renumber only runs on a SANDBOX / TEST project, to protect permanent "
                "data. Open a sandbox copy to renumber.")
            return
        term = self._pon_term()
        pon_field, zone_field, zone_name_field, is_real = self._pon_renumber_fields()
        # label_mode = (prefix, pad) when the PON lives in a TEXT label instead of
        # a numeric field (projects not built by the Network Planner, e.g. HeroTel
        # Malmesbury "Malmesbury Pon 07").  Then Renumber still works: click the PON
        # polygons in order and it rewrites the label + any '_SP<n>' references.
        label_mode = None
        if not pon_field:
            lm = self._pon_label_layer()
            if lm is None:
                QMessageBox.warning(
                    self, f"Renumber {term}s",
                    "No PON/Zone to renumber — need either a pon_no/zone field, or "
                    "a polygon layer whose label looks like 'Name 07'.")
                return
            zlyr, zfield, _pre, _pad = lm
            label_mode = (_pre, _pad)
            pon_field = zfield
            term = "PON"
        else:
            pkey = pon_field.lower()
            zlyr = None
            for l in QgsProject.instance().mapLayers().values():
                if (isinstance(l, QgsVectorLayer) and l.isValid()
                        and l.geometryType() == 2
                        and pkey in {f.name().lower(): 1 for f in l.fields()}):
                    nl = l.name().lower()
                    if zlyr is None or ("zone" in nl or "pon" in nl):
                        zlyr = l
            if zlyr is None:
                QMessageBox.warning(self, f"Renumber {term}s",
                                    f"No {term} polygon layer found to click.")
                return
            zfield = {f.name().lower(): f.name() for f in zlyr.fields()}[pkey]

        dlg = QDialog(self)
        dlg.setWindowTitle(f"Renumber {term}s")
        dlg.resize(412, 720)
        dlg.setMinimumWidth(404)
        dlg.setStyleSheet("""
            QDialog { background:#171b21; }
            QLabel { color:#e8ecf1; font-size:12px; }
            QFrame#head { background:#0e1116; border-bottom:1px solid #2a313b; }
            QLabel#title { color:#e8ecf1; font-family:'Chakra Petch','Segoe UI';
                           font-size:16px; font-weight:bold; }
            QLabel#pill { background:#f5b53d; color:#1a1400; border-radius:9px;
                          padding:2px 9px; font-family:'JetBrains Mono','Consolas';
                          font-weight:bold; font-size:10px; }
            QLabel#warnband { background:#0e2233; color:#7fb2e5; border:1px solid #2f5f88;
                              border-left:3px solid #2f5f88; border-radius:7px;
                              padding:9px 11px; }
            QLabel#cap { color:#22d3ee; font-family:'JetBrains Mono','Consolas';
                         font-size:10px; font-weight:bold; letter-spacing:1px; }
            QFrame#hero { border-radius:9px; background:qlineargradient(x1:0,y1:0,x2:1,y2:1,
                          stop:0 #67e8f9, stop:0.5 #22d3ee, stop:1 #0e9bb8); }
            QLabel#heroTitle { color:#062229; font-family:'Chakra Petch','Segoe UI';
                               font-size:15px; font-weight:bold; background:transparent; }
            QLabel#heroSub { color:#063340; font-size:11px; background:transparent; }
            QLabel#play { background:#06303a; color:#67e8f9; border-radius:13px;
                          min-width:26px; max-width:26px; min-height:26px; max-height:26px;
                          font-size:12px; }
            QLabel#runline { background:#0d1217; border:1px solid #2a313b; border-radius:7px;
                             padding:7px 10px; font-family:'JetBrains Mono','Consolas';
                             font-size:11px; color:#9aa4b2; }
            QLabel#ordiv { color:#5f6b78; font-family:'JetBrains Mono','Consolas'; font-size:10px; }
            QPushButton { background:#2f353e; color:#e8ecf1; border:1px solid #3a414c;
                          border-radius:8px; padding:9px 12px; font-size:12px; text-align:left; }
            QPushButton:hover { border-color:#0e7490; }
            QPushButton:pressed { background:#222831; }
            QPushButton:checked { background:#0e7490; border-color:#22d3ee; color:#ffffff;
                                  font-weight:bold; }
            QPushButton#ghost { background:transparent; border:1px solid #3a414c;
                                color:#9aa4b2; text-align:center; padding:8px; }
            QPushButton#ghost:hover { border-color:#0e7490; color:#e8ecf1; }
            QPushButton#ghost:checked { background:#0e7490; border-color:#22d3ee;
                                        color:#ffffff; font-weight:bold; }
            QPushButton#apply { background:qlineargradient(x1:0,y1:0,x2:1,y2:0,
                                stop:0 #56d364, stop:1 #2ea043); color:#06210f; border:none;
                                border-radius:8px; text-align:center; font-weight:bold;
                                font-family:'Chakra Petch','Segoe UI'; font-size:14px; padding:12px; }
            QPushButton#apply:hover { background:qlineargradient(x1:0,y1:0,x2:1,y2:0,
                                      stop:0 #4bc759, stop:1 #279339); }
            QTableWidget { background:#11141a; color:#9aa4b2; border:1px solid #3a414c;
                           border-radius:8px; gridline-color:#20262e;
                           font-family:'JetBrains Mono','Consolas'; }
            QHeaderView::section { background:#0d1015; color:#6b7480; border:none;
                                   padding:6px; font-family:'JetBrains Mono','Consolas';
                                   font-weight:bold; }
            QSpinBox { background:#0e1116; color:#e8ecf1; border:1px solid #3a414c;
                       border-radius:7px; padding:5px 6px; font-family:'JetBrains Mono','Consolas';
                       font-size:14px; font-weight:bold; }
            QSpinBox::up-button, QSpinBox::down-button { width:18px; background:#1b2026; border:none; }
        """)
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        # in-dialog dark header (title + BETA pill)
        head = QFrame()
        head.setObjectName("head")
        hh = QHBoxLayout(head)
        hh.setContentsMargins(14, 11, 14, 11)
        _title = QLabel(f"Renumber {term}s")
        _title.setObjectName("title")
        hh.addWidget(_title)
        hh.addStretch(1)
        lay.addWidget(head)
        # sandbox warning band
        _warnWrap = QWidget()
        _wwl = QVBoxLayout(_warnWrap)
        _wwl.setContentsMargins(14, 12, 14, 2)
        warn = QLabel(
            f"ℹ️ Finalize renumbers every {term} and all its splitters / contents in the "
            f"order you set. It previews first, so nothing changes until you confirm. Use "
            f"the 💾 Backup button first if you want a safety copy.")
        warn.setObjectName("warnband")
        warn.setWordWrap(True)
        _wwl.addWidget(warn)
        lay.addWidget(_warnWrap)

        # start-number setting (applies to BOTH ordering methods)
        first_spin = QSpinBox()
        first_spin.setRange(1, 99999)
        _minid = self._pon_min_id()
        first_spin.setValue(_minid if _minid is not None else 1)
        numrow = QHBoxLayout()
        numrow.addWidget(QLabel(f"Start numbering the first {term} at:"))
        numrow.addWidget(first_spin)
        numrow.addStretch(1)

        # manual ordering toggle (one of the two methods)
        pick_btn = QPushButton(f"✋  Click the {term}s myself — in order")
        pick_btn.setCheckable(True)
        # (controls are assembled into the stepped layout at the end)

        table = QTableWidget(0, 2)
        table.setHorizontalHeaderLabels([f"old {term}", f"new {term}"])
        table.horizontalHeader().setStretchLastSection(True)

        # Pass 6b: live validation panel under the OLD→NEW table — surfaces the SAME
        # duplicate / gap / unclicked facts Finalize checks, but as you click (not only
        # in the confirm). Finalize stays the authority; this is advisory.
        rn_status = QLabel("<b>Renumber preview</b><br>Click PONs on the map in the "
                           "order you want them numbered.")
        rn_status.setWordWrap(True)
        rn_status.setStyleSheet(
            "QLabel { background-color: #12261a; color: #a9dcb4; "
            "border: 1px solid #3c7a4c; border-radius: 4px; padding: 5px 8px; }")

        state = {"order": [], "full": []}
        crs = zlyr.crs().authid()
        for old in list(QgsProject.instance().mapLayers().values()):
            if isinstance(old, QgsVectorLayer) and old.name() == "Renumber Picks":
                QgsProject.instance().removeMapLayer(old.id())
        picks = QgsVectorLayer(f"Point?crs={crs}", "Renumber Picks", "memory")
        # claude:intent MUTATE — user asked for a click-zones renumber that shows the new
        # numbers as you click. Plan: an in-MEMORY display-only point layer labelled with
        # the new number at each picked zone. No source/project data touched here.
        picks.dataProvider().addAttributes([QgsField("n", QMetaType.Type.Int)])
        picks.updateFields()
        _ls = QgsPalLayerSettings()
        _ls.fieldName = "n"
        _ls.enabled = True
        # KEEP the real PON labels; drop the pick number JUST BELOW the point so
        # both stay readable (screen-space quadrant = same gap at any zoom).
        try:
            _ls.placement = QgsPalLayerSettings.Placement.OverPoint
            _ls.quadOffset = QgsPalLayerSettings.QuadrantPosition.QuadrantBelow
            _ls.dist = 3.0
        except Exception:
            _swallowed_note()
        _tf = QgsTextFormat()
        _tf.setSize(12)
        _tf.setColor(QColor(255, 255, 0))
        try:                                    # dark halo so it reads over the label
            from qgis.core import QgsTextBufferSettings
            _buf = QgsTextBufferSettings()
            _buf.setEnabled(True)
            _buf.setSize(1.0)
            _buf.setColor(QColor(0, 0, 0))
            _tf.setBuffer(_buf)
        except Exception:
            _swallowed_note()
        _ls.setFormat(_tf)
        picks.setLabeling(QgsVectorLayerSimpleLabeling(_ls))
        picks.setLabelsEnabled(True)
        QgsProject.instance().addMapLayer(picks)
        cent = {}
        for f in zlyr.getFeatures():
            g = f.geometry()
            if g and not g.isEmpty():
                # pointOnSurface (not centroid) is GUARANTEED inside the polygon —
                # a concave PON's centroid can land in a NEIGHBOUR, putting the pick
                # number in the wrong PON.  This keeps every pick in its own PON.
                cent[str(f[zfield])] = g.pointOnSurface().asPoint()
        # Every PON value (incl. null-geom features) — the live panel validates against
        # the same set Finalize does. Read once; a renumber session doesn't add PONs.
        _all_pons_rn = [str(_pf[zfield]) for _pf in zlyr.getFeatures()]

        def refresh():
            from qgis.PyQt import sip as _sip
            # #109: a click can fire refresh after the dialog / picks layer were
            # destroyed (dialog closed, plugin reloaded, or the user removed the
            # "Renumber Picks" layer). Touching a deleted C/C++ object raises
            # RuntimeError — bail safely instead of crashing.
            for _o in (dlg, picks, table, first_spin, rn_status):
                if _sip.isdeleted(_o):
                    return
            if QgsProject.instance().mapLayer(picks.id()) is None:
                return
            try:
                base = first_spin.value()
                try:
                    from .pon_renumber_ux import (renumber_facts,
                                                  renumber_status_html)
                    rn_status.setText(renumber_status_html(
                        renumber_facts(state["order"], base, _all_pons_rn)))
                except Exception:
                    _swallowed_note()
                table.setRowCount(0)
                for i, old in enumerate(state["order"]):
                    r = table.rowCount()
                    table.insertRow(r)
                    table.setItem(r, 0, QTableWidgetItem(str(old)))
                    table.setItem(r, 1, QTableWidgetItem(str(base + i)))
                ids = [f.id() for f in picks.getFeatures()]
                if ids:
                    # claude:intent MUTATE — user asked: "look at the two Plastic Relay
                    # tickets ... fix them" (#109 RuntimeError in refresh). Plan: guard
                    # refresh against deleted C/C++ objects. This deleteFeatures only
                    # clears the in-MEMORY "Renumber Picks" DISPLAY layer (no source /
                    # project data); it is rebuilt from state["order"] right below.
                    # claude:approved-destructive
                    picks.dataProvider().deleteFeatures(ids)
                feats = []
                for i, old in enumerate(state["order"]):
                    c = cent.get(str(old))
                    if c:
                        ft = QgsFeature(picks.fields())
                        ft.setAttribute("n", base + i)
                        ft.setGeometry(QgsGeometry.fromPointXY(c))
                        feats.append(ft)
                if feats:
                    picks.dataProvider().addFeatures(feats)
                picks.triggerRepaint()
                self.iface.mapCanvas().refresh()
            except RuntimeError:
                return
            except Exception:
                _swallowed_note()

        def on_zone(zid):
            zid = str(zid)
            if zid in state["order"]:
                state["order"].remove(zid)
            else:
                state["order"].append(zid)
            refresh()

        tool = ZonePickTool(self.iface.mapCanvas(), zlyr, zfield)
        tool.zone_clicked.connect(on_zone)
        self._zr_tool = tool

        def toggle_pick(on):
            canvas = self.iface.mapCanvas()
            if on:
                self._zr_prev_tool = canvas.mapTool()
                canvas.setMapTool(tool)
                pick_btn.setText(f"✋  Picking… click {term}s on the map in order")
            else:
                # revert by UNSETTING our tool (safe) rather than re-activating a stored
                # tool that may have been deleted — that crashed Qt6.
                try:
                    from qgis.PyQt import sip as _sip
                    if not _sip.isdeleted(tool):
                        canvas.unsetMapTool(tool)
                    prev = getattr(self, "_zr_prev_tool", None)
                    if prev is not None and not _sip.isdeleted(prev):
                        canvas.setMapTool(prev)
                except Exception:
                    _swallowed_note()
                pick_btn.setText(f"✋  Click the {term}s myself — in order")
        pick_btn.toggled.connect(toggle_pick)
        first_spin.valueChanged.connect(lambda _v: refresh())

        def _undo():
            if state["order"]:
                state["order"].pop()
                refresh()

        def _clear():
            state["order"] = []
            refresh()

        def _finalize():
            if not state["order"]:
                QMessageBox.information(dlg, "Nothing to do",
                                        f"Click some {term}s on the map first.")
                return
            if not self._pon_project_is_sandbox():
                QMessageBox.warning(dlg, "Blocked", "Project is not a sandbox — aborted.")
                return
            base = first_spin.value()
            # ── VALIDATION ── check the resulting numbering before writing.
            #   • DUPLICATES  -> hard block (never write a clash)
            #   • GAPS        -> warn (a missing number in the run)
            #   • UNSELECTED  -> warn (you didn't click one/some PONs, so they
            #                    keep their old number)
            # A subset-renumber is the usual cause: clicked PONs get new numbers
            # while un-clicked ones keep their old numbers.
            import re as _re
            from collections import Counter as _Counter

            def _as_num(v):
                mm = _re.search(r"\d+", str(v))
                return int(mm.group()) if mm else None
            clicked_new = {str(o): base + i
                           for i, o in enumerate(state["order"])}
            zone_vals = [str(_f[zfield]) for _f in zlyr.getFeatures()]
            result = []
            for _cur in zone_vals:
                result.append(clicked_new[_cur] if _cur in clicked_new
                              else _as_num(_cur))
            result = [r for r in result if r is not None]
            # DUPLICATES → hard block
            _dups = sorted({v for v, k in _Counter(result).items() if k > 1})
            if _dups:
                QMessageBox.warning(
                    dlg, f"Duplicate {term}s — blocked",
                    f"This would create DUPLICATE {term} number(s): "
                    f"{', '.join(str(d) for d in _dups)}.\n\nEvery {term} must be "
                    f"unique.  Click ALL the {term}s in the order you want (so "
                    f"none keep an old number that clashes), then Finalize.\n\n"
                    f"Nothing was written.")
                return
            # GAPS + UNSELECTED → warn (embedded in the finalize confirm)
            _notes = []
            _unclicked = [v for v in zone_vals if v not in clicked_new]
            if _unclicked:
                _un = sorted({_as_num(v) for v in _unclicked
                              if _as_num(v) is not None})
                _notes.append(
                    "• You didn't click %d %s(s) — they keep their old number: %s"
                    % (len(_unclicked), term, ", ".join(str(u) for u in _un)))
            if result:
                _lo, _hi = min(result), max(result)
                _present = set(result)
                _gaps = [n for n in range(_lo, _hi + 1) if n not in _present]
                if _gaps:
                    _notes.append("• Gap(s) — these %s numbers would be missing: %s"
                                  % (term, ", ".join(str(g) for g in _gaps)))
            _warn = ("\n\n⚠  HEADS UP:\n" + "\n".join(_notes)) if _notes else ""
            if QMessageBox.question(
                    dlg, "Finalize renumber?",
                    f"Renumber {len(state['order'])} {term}(s) — and every splitter / "
                    f"feature that references them — on this project?" + _warn +
                    "\n\nTip: use the 💾 Backup button first if you want a safety "
                    "copy.\n\nProceed?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                    ) != QMessageBox.StandardButton.Yes:
                return
            if label_mode is not None:
                ok, msg = self._pon_renumber_apply_label(
                    state["order"], base, zlyr, zfield,
                    label_mode[0], label_mode[1])
            else:
                mapping = {str(old): (base + i, None)
                           for i, old in enumerate(state["order"])}
                ok, msg = self._pon_renumber_apply(
                    mapping, pon_field, zone_field, zone_name_field, is_real)
            (QMessageBox.information if ok else QMessageBox.warning)(
                dlg, "Renumber " + ("done" if ok else "failed"), msg)
            if ok:
                dlg.accept()


        ub = QPushButton("↶  Undo")
        ub.setObjectName("ghost")
        ub.clicked.connect(_undo)
        cb = QPushButton("🧹  Clear")
        cb.setObjectName("ghost")
        cb.clicked.connect(_clear)
        fb = QPushButton("✓  Finalize  ·  renumber everything")
        fb.setObjectName("apply")
        fb.clicked.connect(_finalize)
        closeb = QPushButton("Close")
        closeb.setObjectName("ghost")
        closeb.clicked.connect(dlg.reject)

        # ── assemble the Cable Rail: a numbered cable on the left, content on the right ──
        TU = term.upper()
        bodyWrap = QWidget()
        bodyV = QVBoxLayout(bodyWrap)
        bodyV.setContentsMargins(14, 6, 16, 8)
        bodyV.setSpacing(0)

        def _content(items):
            w = QWidget()
            v = QVBoxLayout(w)
            v.setContentsMargins(0, 0, 0, 0)
            v.setSpacing(7)
            for it in items:
                if isinstance(it, (QHBoxLayout, QVBoxLayout)):
                    v.addLayout(it)
                else:
                    v.addWidget(it)
            return w

        def _railstep(label, cap, content, first=False, last=False, done=False):
            row = QWidget()
            h = QHBoxLayout(row)
            h.setContentsMargins(0, 0, 0, 0)
            h.setSpacing(9)
            h.addWidget(RailNode(label, done=done, first=first, last=last))
            col = QWidget()
            cv = QVBoxLayout(col)
            cv.setContentsMargins(0, 10, 0, 14)
            cv.setSpacing(7)
            _cap = QLabel(cap)
            _cap.setObjectName("cap")
            cv.addWidget(_cap)
            cv.addWidget(content)
            h.addWidget(col, 1)
            bodyV.addWidget(row)

        table.setMinimumHeight(116)
        table.setMaximumHeight(210)
        _editrow = QHBoxLayout()
        _editrow.setSpacing(7)
        for _b in (ub, cb):
            _editrow.addWidget(_b)

        _railstep("1", f"FIRST {TU} GETS NUMBER", _content([numrow]),
                  first=True, done=True)
        _railstep("2", f"ORDER THE {TU}S",
                  _content([pick_btn]))
        _railstep("3", "PREVIEW  ·  OLD → NEW", _content([table, rn_status]))
        _railstep("✓", f"APPLY TO EVERY {TU}", _content([fb, _editrow]), last=True)

        lay.addWidget(bodyWrap)
        _closeWrap = QWidget()
        _cwl = QVBoxLayout(_closeWrap)
        _cwl.setContentsMargins(16, 0, 16, 14)
        _cwl.addWidget(closeb)
        lay.addWidget(_closeWrap)

        def _on_close(_r):
            try:
                from qgis.PyQt import sip as _sip
                if pick_btn.isChecked():
                    pick_btn.setChecked(False)
                canvas = self.iface.mapCanvas()
                # Unset OUR tool so the canvas safely reverts — NEVER re-activate a stored
                # tool that may have been deleted (re-activating a dangling map tool
                # crashed Qt6 with an access violation). sip-guard everything.
                for _t in (getattr(self, "_zr_tool", None),):
                    if _t is not None and not _sip.isdeleted(_t):
                        try:
                            canvas.unsetMapTool(_t)
                        except Exception:
                            _swallowed_note()
                prev = getattr(self, "_zr_prev_tool", None)
                if prev is not None and not _sip.isdeleted(prev):
                    try:
                        canvas.setMapTool(prev)
                    except Exception:
                        _swallowed_note()
                self._zr_tool = None
                self._zr_prev_tool = None
            except Exception:
                _swallowed_note()
        dlg.finished.connect(_on_close)
        dlg.setModal(False)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, False)
        self._zone_renum_dlg = dlg
        # Do NOT auto-start pick mode — the user explicitly chooses Auto-walk or
        # click-myself in Step 2, so the dialog opens in a neutral, un-confusing state.
        dlg.show()
        dlg.raise_()

    def _open_pon_renumber(self):
        """Feeder-route renumber (graduated 2026-07-03: any project, preview-first, no
        forced backup — use the 💾 Backup button). Renumbers pon_no + zone field across
        every layer that carries pon_no, in the order you walk the feeder."""
        from qgis.PyQt.QtWidgets import (
            QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox,
            QSpinBox, QTableWidget, QTableWidgetItem, QMessageBox)
        from qgis.core import QgsProject, QgsVectorLayer

        if not self._pon_project_is_sandbox():
            QMessageBox.warning(
                self, "Renumber PONs — BETA",
                "🔒 Renumber only runs on a SANDBOX / TEST project, to protect permanent "
                "data.\n\nThis project's name/path has no 'sandbox' or 'test', so it is "
                "treated as permanent and blocked. Open a sandbox copy to test renumbering.")
            return

        term = self._pon_term()   # 'Zone' here (zone polygon IS the PON) or 'PON'
        proj = QgsProject.instance()
        line_layers = [l for l in proj.mapLayers().values()
                       if isinstance(l, QgsVectorLayer) and l.isValid()
                       and l.geometryType() == 1]
        if not line_layers:
            QMessageBox.warning(self, f"Renumber {term}s",
                                "No line layers found — need a Feeder cable layer.")
            return

        dlg = QDialog(self)
        dlg.setWindowTitle(f"Renumber {term}s by feeder route")
        dlg.resize(560, 520)
        lay = QVBoxLayout(dlg)
        warn = QLabel(f"ℹ️ Previews first. Walks the feeder and renumbers every {term} in "
                      f"feeder-route order across all its layers. ▶ Trace order to watch it.")
        warn.setWordWrap(True)
        warn.setStyleSheet("background:#0e2233;color:#7fb2e5;border:1px solid #2f5f88;"
                           "border-radius:4px;padding:6px;")
        lay.addWidget(warn)

        row = QHBoxLayout()
        row.addWidget(QLabel("Feeder layer:"))
        feeder_cmb = QComboBox()
        for l in line_layers:
            feeder_cmb.addItem(l.name(), l.id())
        for i, l in enumerate(line_layers):
            if "feeder" in l.name().lower():
                feeder_cmb.setCurrentIndex(i)
                break
        row.addWidget(feeder_cmb, 1)
        lay.addLayout(row)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Start from:"))
        start_cmb = QComboBox()
        start_cmb.addItem("Feeder end A (route start)", "endA")
        start_cmb.addItem("Feeder end B (route end)", "endB")
        row2.addWidget(start_cmb, 1)
        row2.addWidget(QLabel(f"First {term} #:"))
        first_spin = QSpinBox()
        first_spin.setRange(1, 99999)
        # Default to the project's current lowest PON id so a renumber keeps the same base
        # (sandbox is usually 1-based; a finished HLD is 235-based).
        _minid = self._pon_min_id()
        first_spin.setValue(_minid if _minid is not None else 235)
        row2.addWidget(first_spin)
        row2.addWidget(QLabel("Speed:"))
        speed_cmb = QComboBox()
        # (label, glide-frames, interval-ms) — bigger = slower
        for lbl, gl, iv in (("🐢 Slow", 12, 55), ("Normal", 6, 38), ("⚡ Fast", 3, 20)):
            speed_cmb.addItem(lbl, (gl, iv))
        speed_cmb.setCurrentIndex(0)   # default Slow so the order can be double-checked
        self._pon_anim_glide, self._pon_anim_interval = 12, 55

        def _on_speed(_i):
            gl, iv = speed_cmb.currentData()
            self._pon_anim_glide, self._pon_anim_interval = gl, iv
            a = getattr(self, "_pon_anim", None)
            if a and a.get("timer"):
                a["timer"].setInterval(iv)
        speed_cmb.currentIndexChanged.connect(_on_speed)
        row2.addWidget(speed_cmb)
        lay.addLayout(row2)

        # Place-a-start-point-on-the-map row (Luke #107: needs to click a start point).
        row3 = QHBoxLayout()
        pick_btn = QPushButton("📍 Pick start point on map")
        start_lbl = QLabel("start: Feeder end A")
        start_lbl.setStyleSheet("color:#22d3ee;")  # dual-theme-ok: dark #0e2233 panel / decorative divider
        row3.addWidget(pick_btn)
        row3.addWidget(start_lbl, 1)
        lay.addLayout(row3)

        table = QTableWidget(0, 2)
        table.setHorizontalHeaderLabels([f"old {term}", f"new {term}"])
        table.horizontalHeader().setStretchLastSection(True)
        lay.addWidget(table, 1)

        # start = ('endA'|'endB'|'point', QgsPointXY|None). Dropdown sets end A/B;
        # the Pick button sets a clicked point on the feeder.
        state = {"mapping": None, "start": ("endA", None)}

        def _on_start_cmb(_i):
            state["start"] = (start_cmb.currentData(), None)
            start_lbl.setText("start: " + start_cmb.currentText())
            _preview(quiet=True)   # auto-refresh the table so it's never empty
        start_cmb.currentIndexChanged.connect(_on_start_cmb)

        def _pick_start():
            from qgis.gui import QgsMapToolEmitPoint
            from qgis.core import (QgsProject, QgsSnappingConfig, QgsTolerance,
                                   QgsPointXY, QgsGeometry)
            canvas = self.iface.mapCanvas()
            self._renum_prev_tool = canvas.mapTool()
            # Turn on QGIS snapping (vertex + segment, all layers) so the click snaps
            # exactly onto the feeder line — and save the user's config to restore it.
            try:
                self._renum_prev_snap = QgsSnappingConfig(QgsProject.instance().snappingConfig())
                cfg = QgsProject.instance().snappingConfig()
                cfg.setEnabled(True)
                try:
                    cfg.setMode(QgsSnappingConfig.SnappingMode.AllLayers)
                    cfg.setTypeFlag(QgsSnappingConfig.SnappingTypes.VertexFlag
                                    | QgsSnappingConfig.SnappingTypes.SegmentFlag)
                except Exception:
                    _swallowed_note()
                cfg.setTolerance(16)
                try:
                    cfg.setUnits(QgsTolerance.UnitType.Pixels)
                except Exception:
                    _swallowed_note()
                QgsProject.instance().setSnappingConfig(cfg)
            except Exception:
                self._renum_prev_snap = None

            def _clicked(pt, _btn=None):
                # The dialog (and its labels) may have been closed/reloaded while this
                # pick tool is still armed — touching a deleted QLabel here crashes
                # (#108). Bail safely if anything we need is gone.
                from qgis.PyQt import sip as _sip
                if _sip.isdeleted(dlg) or _sip.isdeleted(start_lbl):
                    try:
                        canvas.setMapTool(self._renum_prev_tool)
                    except Exception:
                        _swallowed_note()
                    try:
                        if getattr(self, "_renum_prev_snap", None) is not None:
                            QgsProject.instance().setSnappingConfig(self._renum_prev_snap)
                    except Exception:
                        _swallowed_note()
                    self._renum_tool = None
                    return
                snapped = QgsPointXY(pt)
                # 1) QGIS snapping indicator → exact vertex/edge on a layer
                try:
                    mm = canvas.snappingUtils().snapToMap(QgsPointXY(pt))
                    if mm.isValid():
                        snapped = mm.point()
                except Exception:
                    _swallowed_note()
                # 2) guarantee it lands ON the feeder line — project onto the trunk
                try:
                    flyr = proj.mapLayer(feeder_cmb.currentData())
                    tg, _c, _v = self._feeder_trunk_geoms(flyr)
                    fg2 = tg[0] if tg else None
                    for g in (tg[1:] if tg else []):
                        fg2 = fg2.combine(g)
                    if fg2:
                        np = fg2.nearestPoint(QgsGeometry.fromPointXY(snapped))
                        if np and not np.isEmpty():
                            snapped = np.asPoint()
                except Exception:
                    _swallowed_note()
                state["start"] = ("point", snapped)
                start_lbl.setText(f"start: 📍 ({snapped.x():.5f}, {snapped.y():.5f})")
                # restore the user's snapping config
                try:
                    if getattr(self, "_renum_prev_snap", None) is not None:
                        QgsProject.instance().setSnappingConfig(self._renum_prev_snap)
                except Exception:
                    _swallowed_note()
                try:
                    canvas.setMapTool(self._renum_prev_tool)
                except Exception:
                    _swallowed_note()
                self._renum_tool = None
                try:
                    self.iface.messageBar().clearWidgets()
                except Exception:
                    _swallowed_note()
                dlg.showNormal()
                dlg.raise_()
                dlg.activateWindow()
                _preview(quiet=True)   # auto-refresh the table for the new start point

            tool = QgsMapToolEmitPoint(canvas)
            tool.canvasClicked.connect(_clicked)
            self._renum_tool = tool
            canvas.setMapTool(tool)
            dlg.showMinimized()
            try:
                self.iface.messageBar().pushMessage(
                    "Renumber", "Click your START point on the feeder line "
                    "(the dialog is minimised — it returns after you click).",
                    level=Qgis.MessageLevel.Info, duration=0)
            except Exception:
                _swallowed_note()
        pick_btn.clicked.connect(_pick_start)

        def _preview(quiet=False):
            lyr = proj.mapLayer(feeder_cmb.currentData())
            if not lyr:
                return
            mapping, rep, traced_ok, cap_used, diag = self._pon_renumber_collect(
                lyr, state["start"], first_spin.value())
            # Never hard-block on a sandbox — show the order, let the user judge it. The
            # backup + sandbox guard + preview table are the safety net; refusing outright
            # just leaves the user stuck (Luke #107).
            state["mapping"] = mapping or None
            state["rep"] = rep
            state["traced_ok"] = traced_ok
            state["fields"] = (diag.get("pon_field"), diag.get("zone_field"),
                               diag.get("zone_name_field"), diag.get("is_real"))
            # On an explicit Trace (not the silent auto-refresh), play the HTML-style
            # walk: a marker walks the feeder, dives each zone blob, numbers it in order.
            if not quiet and mapping:
                self._pon_animate_trace(lyr, mapping, rep, term, state["start"])
            table.setRowCount(0)
            for old_pon, new_pon, _new_zone in mapping:
                r = table.rowCount()
                table.insertRow(r)
                table.setItem(r, 0, QTableWidgetItem(str(old_pon)))
                table.setItem(r, 1, QTableWidgetItem(str(new_pon)))
            self._pon_draw_renumber_path(lyr)
            cap_txt = f"{cap_used}F trunk" if cap_used else "feeder (no capacity field)"
            diag_txt = (f"feeder: {cap_txt} · {diag.get('segments')} segment(s) · "
                        f"{diag.get('pons')} PONs · {diag.get('distinct')} distinct positions")
            if not mapping:
                apply_btn.setEnabled(False)
                if not quiet:
                    QMessageBox.warning(dlg, "Nothing to renumber",
                                        f"No PONs found to order.\n\n{diag_txt}")
                return
            changed = sum(1 for o, n, _z in mapping if str(o) != str(n))
            apply_btn.setEnabled(True)
            if not traced_ok:
                if not quiet:
                    QMessageBox.warning(
                        dlg, "Preview — check the order!",
                        f"⚠ The feeder didn't trace cleanly, so this order MAY be wrong — "
                        f"please eyeball the table + the 'PON Renumber Path' layer before "
                        f"applying.\n\n{diag_txt}\n\nApply is still allowed (you're on a sandbox "
                        f"and a backup is written first). If the order looks wrong, try the "
                        f"other feeder layer or a different start point.")
            elif not quiet:
                QMessageBox.information(
                    dlg, "Preview",
                    f"{len(mapping)} PONs ordered · following {cap_txt} · {changed} would "
                    f"change number.\nDrew 'PON Renumber Path' (the cables it follows).\n\n"
                    f"{diag_txt}\n\nReview the table, then Apply (a backup is made first).")

        def _apply():
            if not state["mapping"]:
                return
            if not self._pon_project_is_sandbox():
                QMessageBox.warning(dlg, "Blocked", "Project is not a sandbox — aborted.")
                return
            changed = [(o, n, z) for o, n, z in state["mapping"] if str(o) != str(n)]
            if not changed:
                QMessageBox.information(dlg, "Nothing to do",
                                        "Every PON already has its feeder-route number.")
                return
            if QMessageBox.question(
                    dlg, "Apply renumber?",
                    f"Renumber {len(changed)} PON(s) across all PON layers on this project?\n\n"
                    "Tip: use the 💾 Backup button first if you want a safety copy.",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                    ) != QMessageBox.StandardButton.Yes:
                return
            pf, zf, znf, isr = state.get("fields", (None, None, None, False))
            ok, msg = self._pon_renumber_apply(
                dict((str(o), (n, z)) for o, n, z in state["mapping"]), pf, zf, znf, isr)
            (QMessageBox.information if ok else QMessageBox.warning)(
                dlg, "Renumber " + ("done" if ok else "failed"), msg)
            if ok:
                dlg.accept()

        btns = QHBoxLayout()
        prev_btn = QPushButton("▶ Trace order (watch it)")
        prev_btn.clicked.connect(_preview)
        btns.addWidget(prev_btn)
        apply_btn = QPushButton("✓ Apply renumber")
        apply_btn.setEnabled(False)
        apply_btn.clicked.connect(_apply)
        btns.addWidget(apply_btn)
        clear_btn = QPushButton("🧹 Clear")
        clear_btn.setToolTip("Remove the walk overlays + the 'Renumber Flow' / "
                             "'PON Renumber Path' layers from the canvas.")
        clear_btn.clicked.connect(self._pon_clear_display)
        btns.addWidget(clear_btn)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(dlg.reject)
        btns.addWidget(close_btn)
        lay.addLayout(btns)
        # Changing the first PON # re-orders too — keep the table live.
        first_spin.valueChanged.connect(lambda _v: _preview(quiet=True))
        # Non-modal so the user can click a start point on the canvas (#107). Hold a
        # reference so it isn't garbage-collected the moment this method returns.
        dlg.setModal(False)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, False)
        # Clean up the walk overlays (rubber bands) when the dialog closes, so they can
        # never orphan on the canvas (JJ: "where can I delete these white lines").
        def _on_renum_close(_r):
            # stop the walk overlays AND disarm the start-pick map tool, so a late
            # canvas click can't touch the now-closed dialog (#108).
            self._pon_anim_cleanup()
            try:
                if getattr(self, "_renum_tool", None) is not None:
                    self.iface.mapCanvas().setMapTool(
                        getattr(self, "_renum_prev_tool", None) or self.iface.mapCanvas().mapTool())
                    self._renum_tool = None
            except Exception:
                _swallowed_note()
        dlg.finished.connect(_on_renum_close)
        self._pon_renum_dlg = dlg
        # Auto-preview on open so the table is NEVER empty and Apply is ready when the
        # order looks right — no hidden "click Preview first" step (JJ #107 confusion).
        _preview(quiet=True)
        dlg.show()
        dlg.raise_()
