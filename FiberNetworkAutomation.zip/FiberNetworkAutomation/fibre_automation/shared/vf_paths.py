"""vf_paths — portable path resolution so the plugin runs on ANY machine.

Teammates have plain QGIS: no C:\\Temp, no .qgis-venv, no fixed user folder.
Everything that needs a scratch/data location goes through here.

    from fibre_automation.shared.vf_paths import data_dir, data_file, python_exe, roads_json
"""
import os
import sys
import tempfile
from pathlib import Path


def data_dir() -> str:
    """Writable scratch/data folder, created if missing.

    Order: $VF_DATA_DIR  ->  C:\\Temp (if it already exists)  ->  %TEMP%\\VelocityFibre.
    Always returns a path that exists and is writable.
    """
    env = os.environ.get('VF_DATA_DIR')
    if env:
        try:
            os.makedirs(env, exist_ok=True)
            return env
        except OSError:
            pass
    legacy = 'C:/Temp'
    if os.path.isdir(legacy):
        return legacy
    fallback = os.path.join(tempfile.gettempdir(), 'VelocityFibre')
    os.makedirs(fallback, exist_ok=True)
    return fallback


def data_file(name: str) -> str:
    """Absolute path to <name> inside the portable data dir."""
    return os.path.join(data_dir(), name)


def roads_json() -> str:
    """Path to roads.json (OSM road data for FT7/FT8). May not exist yet."""
    return data_file('roads.json')


def python_exe() -> str:
    """Best Python for subprocess helpers that need geopandas/overturemaps etc.

    Prefers the dev venv if present (JJ's machine), else QGIS's bundled
    python.exe. Inside QGIS on Windows, sys.executable is qgis-bin.exe —
    launching THAT as a subprocess would open a whole new QGIS window, so we
    must resolve the real interpreter under apps\\PythonXX instead.
    """
    venv = Path.home() / '.qgis-venv' / 'Scripts' / 'python.exe'
    if venv.exists():
        return str(venv)
    if os.name == 'nt' and not sys.executable.lower().endswith('python.exe'):
        cand = os.path.join(sys.exec_prefix, 'python.exe')
        if os.path.isfile(cand):
            return cand
    return sys.executable


def project_output_dir() -> str:
    """Where to write user-facing outputs (splice xlsx, BOM csv, flow PDFs).

    Prefers the current QGIS project's folder (so deliverables sit beside the
    project), else the portable data dir.
    """
    try:
        from qgis.core import QgsProject
        p = QgsProject.instance().homePath()
        if p and os.path.isdir(p):
            out = os.path.join(p, 'Velocity Fibre Output')
            os.makedirs(out, exist_ok=True)
            return out
    except Exception:
        pass
    return data_dir()
