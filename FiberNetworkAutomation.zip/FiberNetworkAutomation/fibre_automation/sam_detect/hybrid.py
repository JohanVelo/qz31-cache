"""
Fusion for Hybrid Detect Buildings (Phase 2).

Merge the trusted Overture footprints with the AI gap-fill polygons into one
clean building set. The one rule that matters: **Overture always wins** — a
gap-fill polygon is kept only where Overture has nothing, so a house is never
counted twice. Ports the proven `_fuse_boxprompt_gap` logic from
erven_detection into a pure, testable helper.

Pure shapely + stdlib — no QGIS, no network, deterministic — so it runs inside
the subprocess worker and is covered by property tests in the venv.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from shapely.geometry import mapping, shape
from shapely.strtree import STRtree

# a gap-fill poly overlapping an Overture footprint by >= this fraction of its
# OWN area is considered a duplicate and dropped (Overture wins).
MAX_OVERLAP_FRAC = 0.10

M_PER_DEG_LAT = 111320.0


def _clean(geom):
    if geom is None or geom.is_empty:
        return None
    if not geom.is_valid:
        geom = geom.buffer(0)
    if geom.is_empty or geom.geom_type not in ("Polygon", "MultiPolygon"):
        return None
    return geom


def _as_geom(g):
    if g is None:
        return None
    if isinstance(g, dict):
        g = shape(g.get("geometry", g)) if "geometry" in g else shape(g)
    return _clean(g)


@dataclass
class FuseResult:
    overture: list = field(default_factory=list)   # kept Overture geoms
    gapfill: list = field(default_factory=list)     # kept AI gap-fill geoms
    stats: dict = field(default_factory=dict)


def fuse(overture, gapfill, *, max_overlap_frac: float = MAX_OVERLAP_FRAC) -> FuseResult:
    """Fuse trusted Overture footprints with AI gap-fill polygons.

    Every valid Overture footprint is kept. A gap-fill polygon is DROPPED when
    it meaningfully overlaps, contains, or sits inside any Overture footprint —
    otherwise it is kept (it fills a real hole). Deterministic; input order of
    the kept lists is preserved.
    """
    over = [g for g in (_as_geom(o) for o in (overture or [])) if g is not None]
    gaps_in = [g for g in (_as_geom(g) for g in (gapfill or [])) if g is not None]

    tree = STRtree(over) if over else None
    kept_gap = []
    dropped = 0
    for g in gaps_in:
        if tree is not None and _overlaps_any(g, over, tree, max_overlap_frac):
            dropped += 1
            continue
        kept_gap.append(g)

    stats = {
        "n_overture": len(over),
        "n_gapfill_in": len(gaps_in),
        "n_gapfill_kept": len(kept_gap),
        "n_gapfill_dropped": dropped,
        "n_total": len(over) + len(kept_gap),
        "max_overlap_frac": max_overlap_frac,
    }
    return FuseResult(overture=over, gapfill=kept_gap, stats=stats)


def _overlaps_any(g, over, tree, max_overlap_frac) -> bool:
    """True if gap-fill geom g duplicates any nearby Overture footprint."""
    ga = g.area
    try:
        cand = tree.query(g)  # shapely 2.x → positional indices
    except Exception:
        cand = range(len(over))
    for i in cand:
        o = over[int(i)]
        if not g.intersects(o):
            continue
        inter = g.intersection(o)
        if inter.is_empty:
            continue
        if ga > 0 and (inter.area / ga) >= max_overlap_frac:
            return True
        # containment either way = same building
        if o.contains(g.representative_point()) or g.contains(o.representative_point()):
            return True
    return False


def _metric_area_m2(geom, lat0):
    """Area in m² via a local cos-lat frame (no CRS lib)."""
    mlon = max(1e-6, M_PER_DEG_LAT * math.cos(math.radians(lat0)))
    return abs(geom.area) * (M_PER_DEG_LAT * mlon)


def build_featurecollection(result: FuseResult, *, overture_props=None) -> dict:
    """Canonical `Buildings` FeatureCollection (EPSG:4326).

    One layer, a `source` column, `flag_for_review` set on AI rows so they can
    be styled amber and reviewed before they become ONTs. `overture_props` (an
    optional list aligned to result.overture) can carry the original Overture
    `building_t` / `area_m2` so we don't recompute what Overture already gave.
    """
    feats = []
    lat0 = _centroid_lat(result)
    i = 0
    for k, g in enumerate(result.overture):
        props = (overture_props or [{}] * len(result.overture))[k] or {}
        i += 1
        feats.append(_feature(g, {
            "id": str(i),
            "building_t": props.get("building_t", "SDU"),
            "area_m2": props.get("area_m2") if props.get("area_m2") is not None
            else round(_metric_area_m2(g, lat0), 2),
            "is_primary": int(props.get("is_primary", 1)),
            "source": "overture",
            "flag_for_review": 0,
            "confidence": None,
        }))
    for g in result.gapfill:
        i += 1
        conf = getattr(g, "_vf_conf", None)
        feats.append(_feature(g, {
            "id": str(i),
            "building_t": "SDU",
            "area_m2": round(_metric_area_m2(g, lat0), 2),
            "is_primary": 1,
            "source": "ai_gapfill",
            "flag_for_review": 1,
            "confidence": conf,
        }))
    return {"type": "FeatureCollection", "features": feats}


def _centroid_lat(result: FuseResult) -> float:
    geoms = result.overture or result.gapfill
    if not geoms:
        return -26.7  # South Africa fallback
    ys = [g.centroid.y for g in geoms]
    return sum(ys) / len(ys)


def _feature(geom, props) -> dict:
    return {"type": "Feature", "geometry": mapping(geom), "properties": props}
