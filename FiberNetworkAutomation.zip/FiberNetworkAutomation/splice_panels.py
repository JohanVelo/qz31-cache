# claude:approved-destructive — EnclosureEditorPanel writes only on explicit UI button clicks
"""Panels split out of fiber_network_plugin.py (2026-09-22, code moved verbatim):
Splice Route Viewer, Pole Editor, Enclosure Editor, their helper widgets and the
shared panel style constants. fiber_network_plugin re-exports every name here."""
from collections import OrderedDict
from qgis.core import QgsProject, QgsWkbTypes
from qgis.PyQt.QtWidgets import QApplication, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QFrame, QWidget, QDockWidget
from qgis.PyQt.QtCore import Qt, QTimer, QEvent
from qgis.PyQt.QtGui import QColor, QPen, QPainter
from qgis.PyQt.QtCore import QPointF
from qgis.gui import QgsRubberBand, QgsMapCanvasItem
try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

# ── Bridge colour palette (mirrors bridge_dock.py) ────────────────────────────
_BG      = "#0f1117"
_PANEL   = "#1a1d2e"
_ACCENT  = "#00d4ff"
_VIOLET  = "#7c3aed"
_BLUE    = "#2563eb"
_GREEN   = "#22c55e"
_RED     = "#ef4444"
# Amber = the bridge is present but not serving — a third state that used to be
# painted the same red as "there is no bridge here".
_AMBER   = "#f59e0b"
_TEXT    = "#e2e8f0"
_DIM     = "#64748b"
_BORDER  = "#2d3148"

_DIALOG_BG = f"QDialog {{ background: {_BG}; }}"

_SECTION_LBL = (f"QLabel {{ color: {_DIM}; font-family: 'Segoe UI'; font-size: 9px; "
                f"font-weight: 700; letter-spacing: 1px; }}")

_SUBTITLE_LBL = (f"QLabel {{ color: {_TEXT}; font-family: 'Segoe UI'; font-size: 10px; }}")

_STATUS_LBL = (f"QLabel {{ color: {_DIM}; font-family: Consolas; font-size: 10px; "
               f"padding: 2px; }}")

_HINT_LBL = (f"QLabel {{ color: {_DIM}; font-family: 'Segoe UI'; font-size: 9px; "
             f"border-top: 1px solid {_BORDER}; padding-top: 6px; }}")

_DIVIDER = f"QFrame {{ color: {_BORDER}; }}"

def _btn(bg, hover, pressed, text_col="white"):
    return (f"QPushButton {{ background: {bg}; color: {text_col}; border: none; "
            f"border-radius: 4px; padding: 5px 10px; font-family: 'Segoe UI'; "
            f"font-size: 11px; font-weight: 700; letter-spacing: 0.5px; min-height: 32px; }}"
            f"QPushButton:hover {{ background: {hover}; }}"
            f"QPushButton:pressed {{ background: {pressed}; }}")

_BTN_GREEN   = _btn(_GREEN,   "#16a34a", "#15803d")
_BTN_RED     = _btn(_RED,     "#dc2626", "#991b1b")
_BTN_GRADIENT = (
    f"QPushButton {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
    f"stop:0 {_VIOLET},stop:1 {_BLUE}); color: white; border: none; "
    f"border-radius: 4px; padding: 5px 10px; font-family: 'Segoe UI'; "
    f"font-size: 11px; font-weight: 700; letter-spacing: 0.5px; min-height: 32px; }}"
    f"QPushButton:hover {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
    f"stop:0 #9333ea,stop:1 #3b82f6); }}"
    f"QPushButton:pressed {{ background: {_VIOLET}; }}"
)
_BTN_CLEAR = (
    f"QPushButton {{ background: transparent; color: {_DIM}; "
    f"border: 1px solid {_BORDER}; border-radius: 4px; padding: 5px 10px; "
    f"font-family: 'Segoe UI'; font-size: 11px; min-height: 32px; }}"
    f"QPushButton:hover {{ color: {_TEXT}; border-color: {_ACCENT}; }}"
    f"QPushButton:pressed {{ color: {_ACCENT}; }}"
)
# S5 Slack Bracket — amber/gold gradient so it's visually distinct from the
# violet/blue Thick button. Matches the canvas legend "violet ring = S5" only
# at the outline; the fill is a warm gold to mean "optional manual kit".
_BTN_S5 = (
    "QPushButton { background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
    "stop:0 #f59e0b,stop:1 #d97706); color: white; border: none; "
    "border-radius: 4px; padding: 5px 10px; font-family: 'Segoe UI'; "
    "font-size: 11px; font-weight: 700; letter-spacing: 0.5px; min-height: 32px; }"
    "QPushButton:hover { background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
    "stop:0 #fbbf24,stop:1 #ea580c); }"
    "QPushButton:pressed { background: #d97706; }"
)
_BTN_ORANGE = _btn("#ea7320", "#c2601a", "#a05015")
_BTN_PURPLE = _btn("#9333ea", "#7e22ce", "#6b21a8")
_BTN_CYAN   = _btn("#0891b2", "#0e7490", "#155e75")
_BTN_TEAL   = _btn("#059669", "#047857", "#065f46")

# ── Animated dashed-ring overlay (marching ants around each pole) ─────────────

class _SpinRing(QgsMapCanvasItem):
    """Draws dashed circles at a set of map points with an animated dash
    offset so the dashes appear to travel around the ring (marching ants)."""

    def __init__(self, canvas, color, radius_px, width_px, dash_pattern, tick_ms=80):
        super().__init__(canvas)
        self._canvas = canvas
        self._color = color
        self._radius = float(radius_px)
        self._width = float(width_px)
        self._pattern = list(dash_pattern)
        self._phase = 0.0
        self._points = []
        # Animation timer exists for API compatibility but is NOT started —
        # static dashed rings keep the visual distinction without the per-frame
        # repaint cost.
        self._timer = QTimer()
        self._timer.timeout.connect(self._tick)
        self.setZValue(100)

    def _tick(self):
        pass  # no-op — spin disabled for performance

    def setPoints(self, pts):
        self.prepareGeometryChange()
        self._points = list(pts)
        self.update()

    def setTickInterval(self, ms):
        ms = int(ms)
        if self._timer.interval() != ms:
            self._timer.setInterval(ms)

    def clear(self):
        self.setPoints([])

    def stop(self):
        self._timer.stop()

    def boundingRect(self):
        return self._canvas.sceneRect()

    def paint(self, painter, option=None, widget=None):
        if not self._points:
            return
        pen = QPen(self._color)
        pen.setWidthF(self._width)
        pen.setStyle(Qt.PenStyle.SolidLine)
        pen.setCapStyle(Qt.PenCapStyle.FlatCap)
        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        m2p = self._canvas.mapSettings().mapToPixel()
        for p in self._points:
            sp = m2p.transform(p.x(), p.y())
            painter.drawEllipse(QPointF(sp.x(), sp.y()), self._radius, self._radius)


class _NullRing:
    """Stub that accepts the ring API but draws nothing and uses no CPU."""
    def setPoints(self, pts): pass
    def setTickInterval(self, ms): pass
    def clear(self): pass
    def stop(self): pass


class _SpinRingPreview(QLabel):
    """Small animated dashed-ring widget for the panel legend so the preview
    visually matches the canvas overlay (same colour, dash rhythm, and spin)."""

    def __init__(self, color, dash_pattern, diameter_px=22, width_px=2.0, tick_ms=80):
        super().__init__()
        self._color = color
        self._pattern = list(dash_pattern)
        self._diameter = int(diameter_px)
        self._width = float(width_px)
        self._phase = 0.0
        self.setFixedSize(self._diameter + 4, self._diameter + 4)
        self.setStyleSheet('background: transparent;')
        # Spin disabled — static dashed ring in the legend.

    def _tick(self):
        pass

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        pen = QPen(self._color)
        pen.setWidthF(self._width)
        pen.setStyle(Qt.PenStyle.SolidLine)
        pen.setCapStyle(Qt.PenCapStyle.FlatCap)
        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        cx = self.width() / 2.0
        cy = self.height() / 2.0
        r = self._diameter / 2.0
        painter.drawEllipse(QPointF(cx, cy), r, r)


# ── Splice Route Viewer panel ─────────────────────────────────────────────────
# Colour-codes every fibre hop of a chosen PON on the canvas so the Excel splice
# plan can be cross-checked against the physical layers at a glance. Each row in a
# per-PON sheet (OLT port → feeder → AGG dome → FTS → distribution → DIS dome →
# STS → drop → ONT) maps to features here via shared label fields.

_HOP_COLOURS = OrderedDict([
    ('feeder', QColor(239,  68,  68, 255)),   # red    — feeder cable (secondary/primary)
    ('dist',   QColor(234, 115,  32, 255)),   # orange — distribution cable
    ('drop',   QColor(250, 204,  21, 235)),   # yellow — drop cables
    ('agg',    QColor( 34, 211, 238, 255)),   # cyan   — AGG dome (FTS / fusion)
    ('dis',    QColor( 59, 130, 246, 255)),   # blue   — DIS dome (STS / connectorised)
    ('fts',    QColor(217,  70, 239, 255)),   # magenta— FTS splitter (1:16)
    ('sts',    QColor( 34, 197,  94, 255)),   # green  — STS splitter (1:8)
    ('ont',    QColor(248, 250, 252, 235)),   # white  — ONT / home
])

_HOP_TITLES = {
    'feeder': 'FEEDER', 'dist': 'DISTRIBUTION', 'drop': 'DROPS',
    'agg': 'AGG DOME', 'dis': 'DIS DOMES', 'fts': 'FTS 1:16',
    'sts': 'STS 1:8', 'ont': 'ONTs',
}


class _RouteLabels(QgsMapCanvasItem):
    """Canvas overlay that draws small text pills at map points — used by the
    Route Viewer to label the splitters / legs / domes / cables of the shown route
    (QgsRubberBand can't render text)."""

    def __init__(self, canvas):
        super().__init__(canvas)
        self._canvas = canvas
        self._items = []          # list of (QgsPointXY, text, QColor)
        self.setZValue(130)

    def set_items(self, items):
        self.prepareGeometryChange()
        self._items = list(items)
        self.update()

    def clear(self):
        self.set_items([])

    def boundingRect(self):
        return self._canvas.sceneRect()

    def paint(self, painter, option=None, widget=None):
        if not self._items:
            return
        from qgis.PyQt.QtGui import QFont, QFontMetrics
        from qgis.PyQt.QtCore import QRectF
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        m2p = self._canvas.mapSettings().mapToPixel()
        for item in self._items:
            pt, text, col = item[0], item[1], item[2]
            sz = item[3] if len(item) > 3 else 9          # optional per-label size
            font = QFont('Segoe UI', sz); font.setBold(True)
            painter.setFont(font)
            fm = QFontMetrics(font)
            sp = m2p.transform(pt.x(), pt.y())
            w = fm.horizontalAdvance(text) + 10
            h = fm.height() + 4
            rect = QRectF(sp.x() + 8, sp.y() - h / 2.0, w, h)
            painter.setPen(QPen(QColor(0, 0, 0, 160)))     # thin dark outline pill
            painter.setBrush(QColor(8, 10, 18, 225))
            painter.drawRoundedRect(rect, 4, 4)
            painter.setPen(QPen(col))
            painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, text)


class _ClickFrame(QFrame):
    """A QFrame that runs a callback when clicked — used for the route-diagram hop
    cards (click a hop → isolate it on the canvas). Crash-proof: a raising callback
    is swallowed so a bad click can never take QGIS down."""

    def __init__(self, on_click, parent=None):
        super().__init__(parent)
        self._on_click = on_click
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def mousePressEvent(self, e):
        try:
            if self._on_click is not None:
                self._on_click()
        except Exception:
            _swallowed_note()
        super().mousePressEvent(e)


class _PanelDock(QDockWidget):
    """QGIS dock that hosts a plugin tool panel so it behaves exactly like the
    native attribute-table dock: dockable to ANY edge (left/right/top/bottom),
    floatable, freely resizable (drag to any size, up to full screen), closable,
    and — because its content sits in a QScrollArea — it never runs off-screen.
    Pass on_close to run teardown when the dock is destroyed."""

    def __init__(self, title, iface, on_close=None):
        super().__init__(title, iface.mainWindow())
        self._on_close = on_close
        self.setAllowedAreas(Qt.DockWidgetArea.AllDockWidgetAreas)
        self.setFeatures(QDockWidget.DockWidgetFeature.DockWidgetClosable
                         | QDockWidget.DockWidgetFeature.DockWidgetMovable
                         | QDockWidget.DockWidgetFeature.DockWidgetFloatable)
        # Flat Velocity title bar (minimise · maximise · close) when docked; a real OS
        # window frame (min/max/close + resize + taskbar) when floating. Both the flat
        # bar AND the float-frame swap are owned by apply_dock_chrome now, so there is
        # no local topLevelChanged handler here (it would double-fire). Fail-open so a
        # styling hiccup never blocks a tool panel opening.
        try:
            from .nexus_dock import apply_dock_chrome
            apply_dock_chrome(self)
        except Exception:
            _swallowed_note()

    def closeEvent(self, e):
        # the dock's X just hides it (Qt default) so re-opening keeps the panel
        # alive; on_close (when set by the caller) runs teardown on real destroy.
        try:
            if callable(self._on_close):
                self._on_close()
        except Exception:
            _swallowed_note()
        super().closeEvent(e)


class SpliceRouteViewerPanel(QWidget):
    """Dockable panel: pick an OLT port (PON) and light up its whole fibre route
    on the canvas, colour-coded by hop, with a label read-out to tick against the
    Excel splice plan. Optionally narrows to a single STS leg."""

    PORT_OFFSET = {15: 224, 16: 240, 17: 256, 18: 272, 19: 288}

    def __init__(self, iface, parent=None):
        super().__init__(parent)                 # hosted in a _PanelDock (dockable)
        self.setObjectName('vfRouteViewerPanel')
        self.iface  = iface
        self.canvas = iface.mapCanvas()
        self.setWindowTitle('🔦 Splice Route Viewer')
        self.setMinimumWidth(360)

        self._bands = {}
        self._build_bands()
        self._layers = {}
        self._idx    = None          # built lazily on first show / index build
        self._solo_saved = None       # {layer_id: original_opacity} when solo active
        self._programmatic_select = False   # True while WE drive layer selection
        self._walk_timer = None       # short-lived QTimer for "walk the route"
        self._build_index()
        self._build_ui()

    # ── port ↔ pon helpers ──────────────────────────────────────────────────
    @classmethod
    def _port_to_pon(cls, port):
        try:
            card = int(port[1:3]); p = int(port[4:6])
            return cls.PORT_OFFSET[card] + p
        except Exception:
            return None

    @staticmethod
    def _pon_to_zone(pon):
        try:
            return (int(pon) - 235) // 16 + 17
        except Exception:
            return None

    @classmethod
    def _pon_to_port(cls, pon):
        try:
            pon = int(pon)
            for card, off in cls.PORT_OFFSET.items():
                p = pon - off
                if 1 <= p <= 16:
                    return f"C{card}P{p:02d}"
        except Exception:
            _swallowed_note()
        return None

    def _feature_info(self, layer, feat):
        """Identify a clicked feature → which PON sheet it belongs to. Returns a
        dict {label, lname, pon, zone, sheet, in_plan, note, extra}."""
        import re
        lname = layer.name()
        lab = self._label_of(feat) or '(no label)'
        # PON: pon_no field first, else OLT port in the label (splitters)
        pon = None
        for fld in ('pon_no', 'PON_no', 'pon'):
            i = feat.fields().indexOf(fld)
            if i >= 0 and feat[i] not in (None, ''):
                try:
                    pon = int(feat[i]); break
                except Exception:
                    _swallowed_note()
        if pon is None:
            m = re.search(r'C\d\dP\d\d', lab)
            if m:
                pon = self._port_to_pon(m.group(0))
        low = lname.lower()
        spare = 'spare' in low
        info = {'label': lab, 'lname': lname, 'pon': pon,
                'zone': self._pon_to_zone(pon) if pon else None,
                'sheet': self._pon_to_port(pon) if pon else None,
                'in_plan': not spare, 'note': '', 'extra': ''}
        # which section of the sheet this feature lives in
        if spare:
            info['note'] = 'SPARE capacity — NOT in the splice plan'
        elif 'distribution' in low:
            info['note'] = 'DISTRIBUTION section'
        elif 'secondary' in low or 'primary' in low:
            info['note'] = 'FEEDER row'
        elif 'fts' in low:
            info['note'] = 'FTS 1:16 (sheet header + feeder row)'
        elif 'sts' in low:
            info['note'] = 'STS 1:8 (one leg block)'
        elif 'drop' in low:
            info['note'] = 'DROP rows (DR number)'
        elif 'ont' in low or 'home' in low:
            info['note'] = 'DR rows (one home)'
        elif 'splice' in low:
            info['note'] = 'AGG dome (FTS fusion)'
        elif 'connectorised' in low:
            info['note'] = 'DIS dome (STS connector)'
        cc = feat.fields().indexOf('cblcpty')
        if cc >= 0 and feat[cc] not in (None, ''):
            info['extra'] = str(feat[cc])
        return info

    # ── layer / rubber-band setup ───────────────────────────────────────────
    def _lyr(self, *names):
        proj = QgsProject.instance()
        lays = list(proj.mapLayers().values())
        # Exact name match. When a project carries BOTH a bare layer and its
        # canonical "… v1" HLD deliverable (e.g. a raw/stale import shadowing the
        # real layer — bare 'Drop Cable' with null strtfeat vs 'Drop Cable v1'),
        # prefer the "v1" layer so the viewer always reads the splice-plan data.
        exact = [l for n in names for l in lays if l.name().lower() == n.lower()]
        if exact:
            return next((l for l in exact if l.name().lower().endswith(' v1')), exact[0])
        for n in names:                                   # fuzzy contains (fallback)
            for l in lays:
                if n.lower() in l.name().lower():
                    return l
        return None

    @staticmethod
    def _label_of(feat):
        for c in ('label', 'label_1', 'Label', 'LABEL', 'name'):
            i = feat.fields().indexOf(c)
            if i >= 0 and feat[i] not in (None, ''):
                return str(feat[i])
        return None

    @staticmethod
    def _field_val(feat, *names):
        for n in names:
            i = feat.fields().indexOf(n)
            if i >= 0 and feat[i] not in (None, ''):
                return str(feat[i])
        return None

    @staticmethod
    def _line_far_end(line_geom, ref_geom):
        """The line's endpoint FARTHEST from ref_geom, as a point QgsGeometry — i.e.
        a drop cable's HOME end (the STS/DIS is the near end). None if unusable."""
        from qgis.core import QgsGeometry, QgsPointXY
        try:
            if line_geom is None or line_geom.isEmpty():
                return None
            if line_geom.isMultipart():
                pts = [p for pl in line_geom.asMultiPolyline() for p in pl]
            else:
                pts = line_geom.asPolyline()
            if len(pts) < 2:
                return None
            ends = [pts[0], pts[-1]]
            if ref_geom is not None and not ref_geom.isEmpty():
                rc = ref_geom.centroid().asPoint()
                far = max(ends, key=lambda q: (q.x() - rc.x()) ** 2 + (q.y() - rc.y()) ** 2)
            else:
                far = pts[-1]
            return QgsGeometry.fromPointXY(QgsPointXY(far))
        except Exception:
            return None

    def _build_bands(self):
        line_hops = [('feeder', 7), ('dist', 5), ('drop', 3)]
        for hop, w in line_hops:
            b = QgsRubberBand(self.canvas, QgsWkbTypes.GeometryType.LineGeometry)
            b.setColor(_HOP_COLOURS[hop]); b.setWidth(w)
            self._bands[hop] = b
        pt_hops = [
            ('agg', QgsRubberBand.IconType.ICON_FULL_DIAMOND, 26),
            ('dis', QgsRubberBand.IconType.ICON_CIRCLE,       16),
            ('fts', QgsRubberBand.IconType.ICON_FULL_DIAMOND, 30),
            ('sts', QgsRubberBand.IconType.ICON_BOX,          20),
            ('ont', QgsRubberBand.IconType.ICON_CIRCLE,        9),
        ]
        for hop, icon, size in pt_hops:
            b = QgsRubberBand(self.canvas, QgsWkbTypes.GeometryType.PointGeometry)
            b.setColor(_HOP_COLOURS[hop]); b.setIcon(icon)
            b.setIconSize(size); b.setWidth(3)
            b.setSecondaryStrokeColor(QColor(10, 12, 20, 220))
            self._bands[hop] = b
        # POP marker — only lit when the POP hop card is clicked (it sits ~km from
        # the cluster, so it never joins the default whole-route extent).
        pb = QgsRubberBand(self.canvas, QgsWkbTypes.GeometryType.PointGeometry)
        pb.setColor(QColor(_ACCENT)); pb.setIcon(QgsRubberBand.IconType.ICON_FULL_DIAMOND)
        pb.setIconSize(34); pb.setWidth(3)
        pb.setSecondaryStrokeColor(QColor(10, 12, 20, 220))
        self._bands['pop'] = pb
        # flow arrows: a soft cyan GLOW band underneath + a crisp head on top, for a
        # neon look that reads on any basemap. Both marched by _tick_arrows.
        ag = QgsRubberBand(self.canvas, QgsWkbTypes.GeometryType.PolygonGeometry)
        ag.setColor(QColor(0, 231, 255, 55))         # soft halo edge
        ag.setFillColor(QColor(0, 231, 255, 60))     # soft cyan glow
        ag.setWidth(3)
        self._bands['arrow_glow'] = ag
        ab = QgsRubberBand(self.canvas, QgsWkbTypes.GeometryType.PolygonGeometry)
        ab.setColor(QColor(8, 20, 34, 235))          # crisp dark edge
        ab.setFillColor(QColor(120, 244, 255, 250))  # bright cyan-white core
        ab.setWidth(1)
        self._bands['arrow'] = ab
        # bright halo ring around whatever is SELECTED on the Excel sheet (or the
        # scope-combo STS) so the picked splitter/home is unmistakable
        halo = QgsRubberBand(self.canvas, QgsWkbTypes.GeometryType.PointGeometry)
        halo.setColor(QColor(255, 235, 0, 255))           # vivid yellow
        halo.setIcon(QgsRubberBand.IconType.ICON_CIRCLE)
        halo.setIconSize(44); halo.setWidth(5)
        halo.setSecondaryStrokeColor(QColor(0, 0, 0, 200))
        self._bands['halo'] = halo
        # text-label overlay (splitters / legs / domes / cables)
        self._labels = _RouteLabels(self.canvas)

    def _build_index(self):
        """Read the splice layers once into light lookup tables keyed for fast
        per-port route resolution. Stores feature ids so we can also select the
        features in their layers (drives the attribute table for cross-check)."""
        import re
        from qgis.core import QgsGeometry
        L = self._layers = {
            'fts':  self._lyr('FTS Splitters', 'FTS Splitters v1'),
            'sts':  self._lyr('STS Splitters', 'STS Splitters v1'),
            'agg':  self._lyr('Enclosures Splice', 'Enclosures Splice v1'),
            'dis':  self._lyr('Enclosures Connectorised', 'Enclosures Connectorised v1'),
            'dist': self._lyr('Distribution Cable', 'Distribution Cable v1'),
            'drop': self._lyr('Drop Cable', 'Drop Cable v1'),
            'ont':  self._lyr('ONT', 'ONT v1'),
            'sec':  self._lyr('Secondary Cable', 'Secondary Cable v1'),
            'pri':  self._lyr('Primary Cable', 'Primary Cable v1'),
            'spare': self._lyr('Spare Drop Cable', 'Spare Drop Cable v1'),
            'pop':  self._lyr('POP', 'POP'),
        }
        PORT = re.compile(r'C\d\dP\d\d')
        # The AGG/DIS dome token is embedded INSIDE the splitter label after a
        # prefix (e.g. "MOA.STS.16.DIS.DM.P.F726.C15P11.L1"), so match the bare
        # "AGG.DM.P.x" / "DIS.DM.P.x" token and rebuild the dome label "MOA.<tok>"
        # to match the dome layer's label_1 and the drop strtfeat values.
        AGG  = re.compile(r'AGG\.DM\.P\.\w+')
        DIS  = re.compile(r'DIS\.DM\.P\.\w+')
        LEG  = re.compile(r'\.(L\d+)')

        idx = {
            'fts_by_port':  {},     # port -> {fid, geom, label, agg}
            'sts_by_port':  {},     # port -> [ {fid, geom, label, dis, leg} ]
            'agg_by_label': {},     # label_1 -> {fid, geom}
            'dis_by_label': {},     # label_1 -> {fid, geom}
            'drops_by_dis': {},     # dis label -> [ {fid, geom, label, ont} ]
            'ont_by_label': {},     # ont label -> {fid, geom}
            'dist_by_pon':  {},     # pon -> [ {fid, geom, label} ]
            'feed_by_pon':  {},     # pon -> [ {fid, geom, label, kind} ]  (fallback)
            'feed_by_label': {},    # cable label -> {fid, geom, strt, end, kind}
            'feed_by_endfeat': {},  # endfeat pole -> [cable label]  (upstream trace)
            'ports':        [],     # sorted port list
        }

        if L['fts']:
            for f in L['fts'].getFeatures():
                lab = self._label_of(f)
                if not lab:
                    continue
                m = PORT.search(lab)
                if not m or m.group(0) in idx['fts_by_port']:
                    continue
                a = AGG.search(lab)
                idx['fts_by_port'][m.group(0)] = {
                    'fid': f.id(), 'geom': QgsGeometry(f.geometry()),
                    'label': lab, 'agg': ('MOA.' + a.group(0)) if a else None,
                    'strtfeat': self._field_val(f, 'strtfeat')}
        if L['sts']:
            for f in L['sts'].getFeatures():
                lab = self._label_of(f)
                if not lab:
                    continue
                m = PORT.search(lab)
                if not m:
                    continue
                d = DIS.search(lab); lg = LEG.search(lab)
                idx['sts_by_port'].setdefault(m.group(0), []).append({
                    'fid': f.id(), 'geom': QgsGeometry(f.geometry()),
                    'label': lab, 'dis': ('MOA.' + d.group(0)) if d else None,
                    'leg': lg.group(1) if lg else None})
        for key, lyr in (('agg_by_label', L['agg']), ('dis_by_label', L['dis'])):
            if not lyr:
                continue
            for f in lyr.getFeatures():
                lab = self._label_of(f)
                if lab and lab not in idx[key]:
                    idx[key][lab] = {'fid': f.id(), 'geom': QgsGeometry(f.geometry())}
        if L['drop']:
            for f in L['drop'].getFeatures():
                lab = self._label_of(f)
                strt = self._field_val(f, 'strtfeat')
                ont  = self._field_val(f, 'endfeat')
                if strt is None:
                    continue
                idx['drops_by_dis'].setdefault(strt, []).append({
                    'fid': f.id(), 'geom': QgsGeometry(f.geometry()),
                    'label': lab, 'ont': ont})
        if L['ont']:
            for f in L['ont'].getFeatures():
                lab = self._label_of(f)
                if lab and lab not in idx['ont_by_label']:
                    idx['ont_by_label'][lab] = {'fid': f.id(), 'geom': QgsGeometry(f.geometry())}
        # POP — the single aggregation point (lives in the PH1/POP layer, ~km from
        # the PON cluster). Indexed so the POP hop card can light it on demand.
        idx['pop'] = None
        if L.get('pop'):
            for f in L['pop'].getFeatures():
                g = QgsGeometry(f.geometry())
                if g and not g.isEmpty():
                    idx['pop'] = {'fid': f.id(), 'geom': g,
                                  'label': self._label_of(f) or 'POP'}
                    break
        if L['dist']:
            for f in L['dist'].getFeatures():
                pon = self._field_val(f, 'pon_no')
                if pon is None:
                    continue
                idx['dist_by_pon'].setdefault(pon, []).append({
                    'fid': f.id(), 'geom': QgsGeometry(f.geometry()),
                    'label': self._label_of(f)})
        for kind, lyr in (('Secondary', L['sec']), ('Primary', L['pri'])):
            if not lyr:
                continue
            for f in lyr.getFeatures():
                lab  = self._label_of(f)
                geom = QgsGeometry(f.geometry())
                strt = self._field_val(f, 'strtfeat')
                end  = self._field_val(f, 'endfeat')
                pon  = self._field_val(f, 'pon_no')
                if pon is not None:
                    idx['feed_by_pon'].setdefault(pon, []).append(
                        {'fid': f.id(), 'geom': geom, 'label': lab, 'kind': kind})
                if lab:
                    idx['feed_by_label'][lab] = {'fid': f.id(), 'geom': geom,
                                                 'strt': strt, 'end': end, 'kind': kind}
                if end:
                    idx['feed_by_endfeat'].setdefault(end, []).append(lab)
        # The generator picks the feeder by WHICH cable the FTS physically sits on
        # (vertex analysis in fts_cable_map.json), then traces upstream — NOT by
        # pon_no (feeders are shared trunks). Load that map so the highlighted
        # feeder matches the Excel feeder row exactly.
        idx['fts_cable_map'] = {}
        try:
            import json as _json, os as _os
            _p = r'C:/Temp/fts_cable_map.json'
            if _os.path.exists(_p):
                with open(_p, encoding='utf-8') as _f:
                    idx['fts_cable_map'] = _json.loads(_f.read())
        except Exception:
            idx['fts_cable_map'] = {}
        # Corrected feeder path per PON — the SAME geometry-rooted POP->AGG route the
        # Excel splice plan consumes (feeder_routes.json from feeder_fix_fable.py).
        # Aligns the viewer's feeder hop with the Excel; absent -> legacy trace.
        idx['feeder_routes'] = {}
        try:
            import json as _jf, os as _osf
            _fp = _osf.environ.get('VF_FEEDER_ROUTES', r'C:/Temp/feeder_routes.json')
            if _osf.path.exists(_fp):
                with open(_fp, encoding='utf-8') as _ff:
                    _routes = _jf.loads(_ff.read()).get('routes', {})
                for _rpon, _rt in _routes.items():
                    _cables = [h.get('cable') for h in (_rt.get('hops') or []) if h.get('cable')]
                    if _cables:
                        idx['feeder_routes'][str(_rpon)] = _cables
        except Exception:
            idx['feeder_routes'] = {}
        # Resolve each FTS to its real AGG dome FEATURE by GEOMETRY — the FTS lives
        # inside its AGG dome, so the nearest Enclosures-Splice dome IS the
        # aggregation point. The AGG name embedded in the FTS label is drifted
        # (matches a dome for only ~5/66, those 0.6-2.4 km off), so we do NOT trust
        # it — same nearest-dome resolution the splice plan uses (JJ 2026-06-30).
        # Label is a last resort only when no dome geometry exists.
        agg_items = [(lab, e['fid'], e['geom'])
                     for lab, e in idx['agg_by_label'].items()
                     if e['geom'] is not None and not e['geom'].isEmpty()]
        for fts in idx['fts_by_port'].values():
            fg = fts['geom']
            best = None
            if fg is not None and not fg.isEmpty() and agg_items:
                fc = fg.centroid()
                best = min(agg_items, key=lambda it: it[2].centroid().distance(fc))
            if best:
                fts.update(agg_fid=best[1], agg_geom=best[2],
                           agg_label=best[0], agg_matched='nearest')
            else:
                hit = idx['agg_by_label'].get(fts['agg'])
                if hit:
                    fts.update(agg_fid=hit['fid'], agg_geom=hit['geom'],
                               agg_label=fts['agg'], agg_matched='label')
                else:
                    fts.update(agg_fid=None, agg_geom=None,
                               agg_label=fts['agg'], agg_matched='none')

        # Resolve each STS to the DIS dome FEATURE it physically sits on (nearest).
        # The STS's label-dome is a clean 1:1 reference, but the dome POINT layer
        # wasn't snapped with the STS, so the label-point is often stray (250-530m
        # away). Draw the marker at the co-located dome instead, keeping the plan
        # label. Zero data change — display only.
        from qgis.core import QgsSpatialIndex
        dis_lyr = L['dis']
        if dis_lyr is not None:
            si = QgsSpatialIndex()
            di_geom = {}
            for f in dis_lyr.getFeatures():
                g = f.geometry()
                if g and not g.isEmpty():
                    si.insertFeature(f)
                    di_geom[f.id()] = QgsGeometry(g)
            for lst in idx['sts_by_port'].values():
                for s in lst:
                    g = s.get('geom')
                    s['dis_geom'] = None; s['dis_fid'] = None
                    if g is None or g.isEmpty():
                        continue
                    try:
                        nb = si.nearestNeighbor(g.centroid().asPoint(), 1)
                    except Exception:
                        nb = []
                    if nb:
                        s['dis_fid'] = nb[0]
                        s['dis_geom'] = di_geom.get(nb[0])

        # Spatial index of distribution cables so we can draw the cable each dome
        # PHYSICALLY sits on, regardless of pon_no tag — distribution cables are
        # shared trunks tagged to one PON, like the feeder. pon_no filtering alone
        # leaves most of the route undrawn.
        idx['dist_index'] = None
        idx['dist_feats'] = {}
        if L['dist'] is not None:
            dsi = QgsSpatialIndex()
            for f in L['dist'].getFeatures():
                g = f.geometry()
                if g and not g.isEmpty():
                    dsi.insertFeature(f)
                    idx['dist_feats'][f.id()] = {
                        'fid': f.id(), 'geom': QgsGeometry(g),
                        'label': self._label_of(f)}
            idx['dist_index'] = dsi

        idx['ports'] = sorted(idx['fts_by_port'].keys())
        self._idx = idx

    def _resolve_distribution(self, dome_geoms, agg_geom, pon):
        """Distribution cables that PHYSICALLY serve this PON — the cable each of
        its domes (and the AGG dome) sits on — unioned with the pon_no-tagged ones.
        Cables are shared trunks, so the tag alone misses most of the route."""
        si = self._idx.get('dist_index')
        feats = self._idx.get('dist_feats') or {}
        out = {}
        if si is not None:
            pts = list(dome_geoms)
            if agg_geom is not None and not agg_geom.isEmpty():
                pts.append(agg_geom)
            for g in pts:
                if g is None or g.isEmpty():
                    continue
                try:
                    cand = si.nearestNeighbor(g.centroid().asPoint(), 3)
                except Exception:
                    cand = []
                best, bestd = None, 1e18
                for fid in cand:
                    fe = feats.get(fid)
                    if fe and g.distance(fe['geom']) < bestd:
                        bestd = g.distance(fe['geom']); best = fid
                if best is not None and bestd * 111320 < 30:   # dome sits on this cable
                    out[best] = feats[best]
        for dc in self._idx['dist_by_pon'].get(pon, []):
            if dc.get('fid') is not None:
                out.setdefault(dc['fid'], dc)
        return list(out.values())

    # ── UI ──────────────────────────────────────────────────────────────────
    def _build_ui(self):
        from qgis.PyQt.QtWidgets import QComboBox, QListWidget
        self.setStyleSheet(f"QWidget#vfRouteViewerPanel {{ background: {_BG}; }}")
        layout = QVBoxLayout(self)
        layout.setSpacing(6); layout.setContentsMargins(12, 12, 12, 10)

        subtitle = QLabel('Pick an OLT port (PON) → light up its fibre route on the canvas.')
        subtitle.setWordWrap(True); subtitle.setStyleSheet(_SUBTITLE_LBL)
        layout.addWidget(subtitle)

        if not self._idx['ports']:
            warn = QLabel('⚠ No FTS Splitters layer found in this project.\n'
                          'Open the splice project (with FTS/STS/dome layers) and reopen.')
            warn.setWordWrap(True); warn.setStyleSheet(_STATUS_LBL)
            layout.addWidget(warn)
            return

        # ── Find box: type any DR / dome / STS / cable / port → jump + highlight
        from qgis.PyQt.QtWidgets import QLineEdit
        find_lbl = QLabel('FIND  (DR · dome · STS · cable · port)')
        find_lbl.setStyleSheet(_SECTION_LBL); layout.addWidget(find_lbl)
        self.find_edit = QLineEdit()
        self.find_edit.setPlaceholderText('e.g. DR1876230, F726, C16P04, DF.24F…')
        self.find_edit.setStyleSheet(
            f"QLineEdit {{ background:#11131f; color:{_TEXT}; border:1px solid {_BORDER};"
            f" border-radius:4px; padding:6px 8px; font-family:Consolas; font-size:11px; }}"
            f"QLineEdit:focus {{ border-color:{_ACCENT}; }}")
        self.find_edit.returnPressed.connect(self._find)
        layout.addWidget(self.find_edit)

        sel_lbl = QLabel('OLT PORT  ·  PON')
        sel_lbl.setStyleSheet(_SECTION_LBL); layout.addWidget(sel_lbl)

        self.port_combo = QComboBox()
        self.port_combo.setStyleSheet(_COMBO_CSS)
        for port in self._idx['ports']:
            pon = self._port_to_pon(port); zone = self._pon_to_zone(pon)
            homes = self._home_count(port)
            self.port_combo.addItem(
                f'{port}    PON {pon} · Zone {zone}    ({homes} homes)', port)
        self.port_combo.currentIndexChanged.connect(self._on_port_changed)
        layout.addWidget(self.port_combo)

        nav = QHBoxLayout(); nav.setSpacing(8)
        btn_prev = QPushButton('◀  Prev'); btn_prev.setStyleSheet(_BTN_CLEAR)
        btn_prev.clicked.connect(lambda: self._step(-1)); nav.addWidget(btn_prev)
        btn_next = QPushButton('Next  ▶'); btn_next.setStyleSheet(_BTN_CLEAR)
        btn_next.clicked.connect(lambda: self._step(1)); nav.addWidget(btn_next)
        layout.addLayout(nav)

        # health card: homes · fill% · loss-margin (green/amber/red at a glance)
        self._health_box = QFrame()
        self._health_layout = QHBoxLayout(self._health_box)
        self._health_layout.setContentsMargins(0, 4, 0, 0)
        self._health_layout.setSpacing(8)
        layout.addWidget(self._health_box)

        sts_lbl = QLabel('SCOPE  (narrow to one STS leg)')
        sts_lbl.setStyleSheet(_SECTION_LBL); layout.addWidget(sts_lbl)
        self.sts_combo = QComboBox(); self.sts_combo.setStyleSheet(_COMBO_CSS)
        layout.addWidget(self.sts_combo)

        act = QHBoxLayout(); act.setSpacing(8)
        btn_show = QPushButton('🔦  Show on Canvas'); btn_show.setStyleSheet(_BTN_GREEN)
        btn_show.clicked.connect(self._show_route); act.addWidget(btn_show)
        btn_clear = QPushButton('Clear'); btn_clear.setStyleSheet(_BTN_CLEAR)
        btn_clear.clicked.connect(self._clear); act.addWidget(btn_clear)
        layout.addLayout(act)

        act2 = QHBoxLayout(); act2.setSpacing(8)
        btn_walk = QPushButton('▶  Walk the route'); btn_walk.setStyleSheet(_BTN_GRADIENT)
        btn_walk.clicked.connect(self._walk_route); act2.addWidget(btn_walk)
        btn_zoom = QPushButton('🔍 Zoom'); btn_zoom.setStyleSheet(_BTN_CLEAR)
        btn_zoom.clicked.connect(self._zoom_route); act2.addWidget(btn_zoom)
        btn_card = QPushButton('🖨 Route card'); btn_card.setStyleSheet(_BTN_CLEAR)
        btn_card.clicked.connect(self._route_card); act2.addWidget(btn_card)
        layout.addLayout(act2)

        # ── THE ROUTE — visual hop chain POP -> home (the headline view) ──────
        diag_lbl = QLabel('THE ROUTE  ·  POP → home   (click a hop to isolate it)')
        diag_lbl.setStyleSheet(_SECTION_LBL); layout.addWidget(diag_lbl)
        # plain container — the whole panel scrolls inside its dock, so the diagram
        # shows all 9 hops inline (no nested scroll area).
        diagram_box = QFrame()
        diagram_box.setObjectName('vfDiagramBox')
        diagram_box.setStyleSheet(
            f"QFrame#vfDiagramBox {{ background:#0a111d; border:1px solid {_BORDER};"
            f" border-radius:8px; }}")
        self._diagram_layout = QVBoxLayout(diagram_box)
        self._diagram_layout.setContentsMargins(10, 10, 10, 10)
        self._diagram_layout.setSpacing(0)
        self._hop_cards = {}
        self._isolated_hop = None
        layout.addWidget(diagram_box)

        # plain-English "how this PON runs" — no fibre background needed to read it
        self._why_box = QFrame()
        self._why_box.setObjectName('vfWhyBox')
        self._why_box.setStyleSheet(
            "QFrame#vfWhyBox { background:rgba(34,197,94,0.06);"
            " border:1px solid #1c3a30; border-radius:8px; }")
        why_lay = QVBoxLayout(self._why_box)
        why_lay.setContentsMargins(11, 9, 11, 10); why_lay.setSpacing(4)
        why_hdr = QLabel('HOW THIS PON RUNS')
        why_hdr.setStyleSheet(  # dual-theme-ok: inside the dark PON-route panel
            "color:#3DFF9A; font-family:Consolas; font-size:9px;"
            " font-weight:700; letter-spacing:1px; background:transparent; border:none;")
        why_lay.addWidget(why_hdr)
        self._why_lbl = QLabel('—'); self._why_lbl.setWordWrap(True)
        self._why_lbl.setStyleSheet(  # dual-theme-ok: inside the dark PON-route panel
            "color:#cfe0f5; font-family:'Segoe UI'; font-size:11px;"
            " background:transparent; border:none;")
        why_lay.addWidget(self._why_lbl)
        layout.addWidget(self._why_box)

        # ⚠ flags — dome-with-no-STS / stranded homes / unresolved hop (hidden when clean)
        self._flags_lbl = QLabel(''); self._flags_lbl.setWordWrap(True)
        self._flags_lbl.setVisible(False)
        self._flags_lbl.setStyleSheet(
            "QLabel { background:rgba(245,166,35,0.08); color:#f1d9a8;"
            " border:1px solid #5a4520; border-radius:8px; padding:7px 9px;"
            " font-family:Consolas; font-size:9px; }")
        layout.addWidget(self._flags_lbl)

        from qgis.PyQt.QtWidgets import QCheckBox
        _chk_css = f"QCheckBox {{ color:{_TEXT}; font-family:'Segoe UI'; font-size:10px; }}"
        self.solo_chk = QCheckBox('Solo — dim every other layer so only this route shows')
        self.solo_chk.setChecked(True); self.solo_chk.setStyleSheet(_chk_css)
        self.solo_chk.toggled.connect(self._on_solo_toggled)
        layout.addWidget(self.solo_chk)

        # last-mile drop cables fan out 1:8 from every STS — off by default so the
        # canvas shows the clean trunk (feeder -> FTS -> distribution -> STS) flow.
        self.drops_chk = QCheckBox('Show drop cables (last-mile — busy)')
        self.drops_chk.setChecked(False); self.drops_chk.setStyleSheet(_chk_css)
        self.drops_chk.toggled.connect(lambda *_: self._show_route())
        layout.addWidget(self.drops_chk)

        # on-canvas labels: FTS, each STS leg, domes, distribution + feeder cables
        self.labels_chk = QCheckBox('Show labels (splitters · legs · domes · cables)')
        self.labels_chk.setChecked(True); self.labels_chk.setStyleSheet(_chk_css)
        self.labels_chk.toggled.connect(lambda *_: self._show_route())
        layout.addWidget(self.labels_chk)

        # animated flow-direction arrows (POP → homes) on the trunk + drops
        self.arrows_chk = QCheckBox('Flow arrows on the selected drop (animated)')
        self.arrows_chk.setChecked(True); self.arrows_chk.setStyleSheet(_chk_css)
        self.arrows_chk.toggled.connect(lambda *_: self._show_route())
        layout.addWidget(self.arrows_chk)

        # follow the live Excel sheet + cell selection (via excel_watch.py)
        self.excel_chk = QCheckBox('Follow Excel selection (sheet + selected rows)')
        self.excel_chk.setChecked(True); self.excel_chk.setStyleSheet(_chk_css)
        layout.addWidget(self.excel_chk)

        # ── STS-leg list (collapsible): L1..L16 → DIS dome + homes, click to isolate ─
        from qgis.PyQt.QtWidgets import QToolButton
        legs_wrap = QFrame(); legs_wrap.setObjectName('vfLegsWrap')
        legs_wrap.setStyleSheet(
            f"QFrame#vfLegsWrap {{ background:#0a111d; border:1px solid {_BORDER};"
            f" border-radius:8px; }}")
        lw = QVBoxLayout(legs_wrap); lw.setContentsMargins(0, 0, 0, 0); lw.setSpacing(0)
        self._legs_toggle = QToolButton(); self._legs_toggle.setText('▾  STS legs')
        self._legs_toggle.setCheckable(True); self._legs_toggle.setChecked(True)
        self._legs_toggle.setStyleSheet(
            f"QToolButton {{ color:{_TEXT}; background:transparent; border:none;"
            f" padding:7px 10px; font-family:Consolas; font-size:10px; text-align:left; }}"
            f"QToolButton:hover {{ color:{_ACCENT}; }}")
        self._legs_toggle.clicked.connect(self._toggle_legs)
        lw.addWidget(self._legs_toggle)
        self._legs_box = QFrame()
        self._legs_layout = QVBoxLayout(self._legs_box)
        self._legs_layout.setContentsMargins(0, 0, 0, 4); self._legs_layout.setSpacing(0)
        lw.addWidget(self._legs_box)
        layout.addWidget(legs_wrap)

        line = QFrame(); line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet(_DIVIDER); layout.addWidget(line)

        # IDENTIFY — click any cable / splitter / dome on the map → which PON sheet
        id_lbl = QLabel('IDENTIFY  (click a feature on the map)')
        id_lbl.setStyleSheet(_SECTION_LBL); layout.addWidget(id_lbl)
        self._id_lbl = QLabel('Select a feature on the canvas…')
        self._id_lbl.setWordWrap(True)
        self._id_lbl.setStyleSheet(
            f"QLabel {{ background:#11131f; color:{_TEXT}; border:1px solid {_BORDER};"
            f" border-radius:4px; padding:6px 8px; font-family:Consolas; font-size:10px; }}")
        layout.addWidget(self._id_lbl)
        id_row = QHBoxLayout(); id_row.setSpacing(8)
        self._id_open_btn = QPushButton('↪  Open that PON')
        self._id_open_btn.setStyleSheet(_BTN_GRADIENT); self._id_open_btn.setEnabled(False)
        self._id_open_btn.clicked.connect(self._open_identified_pon)
        id_row.addWidget(self._id_open_btn)
        self.idjump_chk = QCheckBox('auto-jump')
        self.idjump_chk.setChecked(False); self.idjump_chk.setStyleSheet(_chk_css)
        id_row.addWidget(self.idjump_chk)
        layout.addLayout(id_row)
        self._id_target_port = None

        line2 = QFrame(); line2.setFrameShape(QFrame.Shape.HLine)
        line2.setStyleSheet(_DIVIDER); layout.addWidget(line2)

        ro_row = QHBoxLayout(); ro_row.setSpacing(8)
        ro_lbl = QLabel('ROUTE  (tick against the Excel sheet)')
        ro_lbl.setStyleSheet(_SECTION_LBL); ro_row.addWidget(ro_lbl, 1)
        btn_copy = QPushButton('📋 Copy')
        btn_copy.setStyleSheet(_BTN_CLEAR)
        btn_copy.setMaximumWidth(80)
        btn_copy.clicked.connect(self._copy_route)
        ro_row.addWidget(btn_copy)
        layout.addLayout(ro_row)
        self.readout = QListWidget()
        self.readout.setStyleSheet(
            f"QListWidget {{ background:#11131f; color:{_TEXT}; border:1px solid {_BORDER};"
            f" border-radius:4px; font-family:Consolas; font-size:10px; }}"
            f"QListWidget::item {{ padding:2px 6px; }}")
        self.readout.setMinimumHeight(150)
        self.readout.setMaximumHeight(260)
        layout.addWidget(self.readout)

        self._status_lbl = QLabel(''); self._status_lbl.setWordWrap(True)
        self._status_lbl.setStyleSheet(_STATUS_LBL); layout.addWidget(self._status_lbl)

        # legend
        legend = QLabel(
            '🟥 feeder  🟧 distribution  🟨 drops   '
            '🔷 AGG dome  🔵 DIS dome   🟪 FTS  🟩 STS  ⚪ ONT')
        legend.setWordWrap(True); legend.setStyleSheet(_HINT_LBL)
        layout.addWidget(legend)

        self._on_port_changed()          # populate STS combo for first port

        # populate the hop diagram for the opening port WITHOUT drawing on the
        # canvas (resolve is side-effect-free) so the panel reads useful at a glance
        try:
            r0 = self._resolve_route(None)
            if r0:
                self._route = r0
                self._refresh_panel(r0)
        except Exception:
            _swallowed_note()

        # live poll: re-show automatically when the Excel sheet/selection changes
        self._xl_last_key = None
        self._xl_timer = QTimer(self)
        self._xl_timer.setInterval(1200)
        self._xl_timer.timeout.connect(self._poll_excel)
        self._xl_timer.start()

        # flow-arrow animation: a bounded timer that marches the arrowheads while
        # the viewer is visible AND the arrows checkbox is on (stops otherwise).
        self._arrow_phase = 0.0
        self._arrow_geoms = None
        self._arrow_dome = None
        self._arrow_timer = QTimer(self)
        self._arrow_timer.setInterval(45)
        self._arrow_timer.timeout.connect(self._tick_arrows)

        # IDENTIFY: react when the user clicks/selects a feature on any route layer
        for lyr in self._layers.values():
            if lyr is not None:
                try:
                    lyr.selectionChanged.connect(self._on_user_select)
                except Exception:
                    _swallowed_note()

    # ── identify clicked feature -> PON sheet ────────────────────────────────
    def _on_user_select(self, selected=None, deselected=None, clearAndSelect=None):
        if getattr(self, '_programmatic_select', False):
            return                                  # ignore our own route selection
        lyr = self.sender()
        if lyr is None:
            return
        try:
            # identify the NEWLY-selected feature (the user's click) — not the whole
            # selection, so it still works when the route viewer leaves features
            # selected. selectionChanged passes the new-selection delta.
            ids = list(selected) if selected else []
            if not ids:
                if lyr.selectedFeatureCount() == 1:
                    ids = [next(lyr.getSelectedFeatures()).id()]
                else:
                    return
            if len(ids) > 12:                        # huge select -> not a click
                return
            feat = lyr.getFeature(ids[-1])           # the last one the user added
        except Exception:
            return
        info = self._feature_info(lyr, feat)
        self._show_identify(info)

    def _show_identify(self, info):
        lab, lname = info['label'], info['lname']
        cap = f'  ·  {info["extra"]}' if info['extra'] else ''
        if info['pon'] and info['sheet']:
            head = (f'<b>{lab}</b>{cap}<br>{lname}<br>'
                    f'➜ <b>PON {info["pon"]}</b> · Zone {info["zone"]} · sheet '
                    f'<b>{info["sheet"]}</b>')
            body = (f'<br><span style="color:#f59e0b">{info["note"]}</span>'
                    if not info['in_plan']
                    else f'<br><span style="color:#22c55e">in plan → {info["note"]}</span>')
            self._id_lbl.setText(head + body)
            self._id_target_port = info['sheet']
            self._id_open_btn.setEnabled(True)
            self._id_open_btn.setText(f'↪  Open {info["sheet"]} (PON {info["pon"]})')
            if getattr(self, 'idjump_chk', None) and self.idjump_chk.isChecked():
                self._open_identified_pon()
        else:
            self._id_lbl.setText(f'<b>{lab}</b>{cap}<br>{lname}<br>'
                                 f'<span style="color:#94a3b8">no PON tag on this feature</span>')
            self._id_target_port = None
            self._id_open_btn.setEnabled(False)
            self._id_open_btn.setText('↪  Open that PON')

    def _open_identified_pon(self):
        port = getattr(self, '_id_target_port', None)
        if not port:
            return
        i = self.port_combo.findData(port)
        if i < 0:
            return
        # opening a neighbour PON: stop following Excel so it doesn't snap back
        if getattr(self, 'excel_chk', None) and self.excel_chk.isChecked():
            self.excel_chk.setChecked(False)
        self.port_combo.setCurrentIndex(i)
        self._on_port_changed()
        self._show_route()

    def _poll_excel(self):
        if not self.isVisible():
            return
        xl = self._read_excel_sel()
        if not xl:
            return
        key = (xl.get('sheet'), xl.get('selection'),
               tuple(xl.get('sts', [])), tuple(xl.get('drs', [])))
        if key != self._xl_last_key:
            self._xl_last_key = key
            self._show_route()

    def _home_count(self, port):
        n = 0
        for s in self._idx['sts_by_port'].get(port, []):
            n += len(self._idx['drops_by_dis'].get(s['dis'], []))
        return n

    def _loss_budget(self, fts, sts_list, feeder_lbls, dist_cables):
        """Estimate worst-case optical loss POP→ONT vs GPON Class B+ (28 dB).
        Cascaded splitters dominate: 1:16 FTS ≈13.5 + 1:8 STS ≈10.5 = 24 dB;
        + 3 connectors (0.30) + 4 splices (0.10) + fibre 0.35 dB/km. Returns
        (loss_db, margin_db, status, fibre_km)."""
        def km(g):
            try:
                return g.length() * 111.32        # degrees → km (approx at this lat)
            except Exception:
                return 0.0
        feeder_km = sum(km(self._idx['feed_by_label'][fl]['geom'])
                        for fl in (feeder_lbls or [])
                        if fl in self._idx['feed_by_label'])
        dist_km = max([km(dc.get('geom')) for dc in (dist_cables or [])] or [0.0])
        drop_km = 0.0
        for s in sts_list:
            for dr in self._idx['drops_by_dis'].get(s['dis'], []):
                drop_km = max(drop_km, km(dr.get('geom')))
        fibre_km = feeder_km + dist_km + drop_km
        loss = 10.5 + 13.5 + 3 * 0.30 + 4 * 0.10 + fibre_km * 0.35
        margin = 28.0 - loss
        status = 'PASS' if margin >= 3 else ('MARGINAL' if margin >= 1 else 'FAIL')
        return round(loss, 1), round(margin, 1), status, round(fibre_km, 2)

    def _feeder_route_labels(self, pon):
        """Corrected feeder path for this PON — ordered cable labels from
        feeder_routes.json (the SAME geometry-rooted POP->AGG route the Excel
        splice plan uses). Empty when the route file is absent, so teammates
        without it fall back to the legacy upstream-endfeat trace."""
        return list(self._idx.get('feeder_routes', {}).get(str(pon), []))

    def _resolve_feeders(self, fts):
        """Mirror the generator's feeder_hops: find the feeder cable the FTS
        physically sits on (fts_cable_map keyed by the FTS pole, else the AGG-dome
        pole), then trace upstream via endfeat. Returns [cable_label, ...] in the
        same set the Excel feeder row lists. Empty list -> caller falls back to
        the pon_no-tagged feeder."""
        import re
        cmap = self._idx.get('fts_cable_map') or {}
        if not cmap:
            return []
        pole = fts.get('strtfeat')
        hit = cmap.get(pole)
        # fall back to the AGG dome's pole — use the GEOMETRY-resolved dome label
        # (the real co-located dome) so the feeder traces from the cluster, not the
        # drifted FTS-embedded name. MOA.AGG.DM.P.G586 -> MOA.P.G586.
        if not hit:
            agg_lbl = fts.get('agg_label') or fts.get('agg') or ''
            if agg_lbl:
                hit = cmap.get(re.sub(r'AGG\.DM\.', '', agg_lbl))
        if not hit:
            return []
        out = []
        seen = set()
        lbl = hit.get('cable')
        while lbl and lbl not in seen:
            seen.add(lbl); out.append(lbl)
            cab = self._idx['feed_by_label'].get(lbl)
            if not cab or not cab.get('strt'):
                break
            ups = self._idx['feed_by_endfeat'].get(cab['strt'], [])
            lbl = ups[0] if ups else None
        return out

    def _on_port_changed(self):
        port = self.port_combo.currentData()
        self.sts_combo.blockSignals(True)
        self.sts_combo.clear()
        self.sts_combo.addItem('All STS in PON', None)
        for s in sorted(self._idx['sts_by_port'].get(port, []),
                        key=lambda x: (x['leg'] or '')):
            n = len(self._idx['drops_by_dis'].get(s['dis'], []))
            self.sts_combo.addItem(f"{s['leg'] or '—'}  {s['dis']}  ({n})", s['label'])
        self.sts_combo.blockSignals(False)

    def _step(self, delta):
        i = self.port_combo.currentIndex() + delta
        if 0 <= i < self.port_combo.count():
            self.port_combo.setCurrentIndex(i)
            self._show_route()

    def _jump_to(self, port, sts_label=None):
        """Switch the viewer to *port* (and optionally narrow to one STS) and show
        it. Turns off Excel-follow so the jump sticks."""
        i = self.port_combo.findData(port)
        if i < 0:
            return False
        if getattr(self, 'excel_chk', None) and self.excel_chk.isChecked():
            self.excel_chk.setChecked(False)
        self.port_combo.setCurrentIndex(i)
        self._on_port_changed()
        if sts_label:
            for j in range(self.sts_combo.count()):
                if self.sts_combo.itemData(j) == sts_label:
                    self.sts_combo.setCurrentIndex(j); break
        else:
            self.sts_combo.setCurrentIndex(0)
        self._show_route()
        return True

    def _find(self):
        """Resolve the Find text (DR / dome / STS / cable / port) to a PON and jump
        there, narrowing to the matching STS when relevant."""
        import re
        q = self.find_edit.text().strip()
        if not q:
            return
        idx = self._idx
        # 1. DR number -> the STS/dome that serves it
        m = re.search(r'DR\s*0*(\d+)', q, re.I)
        if m:
            dr = 'DR' + m.group(1)
            for port, lst in idx['sts_by_port'].items():
                for s in lst:
                    for drp in idx['drops_by_dis'].get(s['dis'], []):
                        if dr in ((drp.get('label') or '') + ' ' + (drp.get('ont') or '')):
                            self._jump_to(port, sts_label=s['label'])
                            self._set_status(f'Found {dr} → {s["leg"]} · {s["dis"].split(".")[-1]}',
                                             colour=_GREEN)
                            return
        # 2. explicit OLT port
        mp = re.search(r'C\d\dP\d\d', q, re.I)
        if mp and mp.group(0).upper() in idx['fts_by_port']:
            self._jump_to(mp.group(0).upper()); return
        # 3. DIS dome
        md = re.search(r'(?:DIS\.DM\.P\.)?([A-Z]?\d{3,})', q, re.I)
        token = md.group(1).upper() if md else None
        if token:
            for port, lst in idx['sts_by_port'].items():
                for s in lst:
                    if s.get('dis') and s['dis'].endswith('.' + token):
                        self._jump_to(port, sts_label=s['label'])
                        self._set_status(f'Found dome {token} → {port}', colour=_GREEN)
                        return
            # 4. AGG dome
            for port, fts in idx['fts_by_port'].items():
                if fts.get('agg') and fts['agg'].endswith('.' + token):
                    self._jump_to(port); self._set_status(f'Found AGG {token} → {port}', colour=_GREEN)
                    return
        # 5. cable label substring (distribution / feeder)
        ql = q.lower()
        for fid, fe in (idx.get('dist_feats') or {}).items():
            if fe.get('label') and ql in fe['label'].lower():
                # find pon via the route resolution: jump to the cable's pon_no tag
                for pon, cs in idx['dist_by_pon'].items():
                    if any(c.get('fid') == fid for c in cs):
                        port = self._pon_to_port(pon)
                        if port and self._jump_to(port):
                            self._set_status(f'Found cable {fe["label"].split(".P.")[-1]} → {port}',
                                             colour=_GREEN)
                            return
        self._set_status(f'"{q}" not found', colour=_RED)

    def _read_excel_sel(self):
        """Read C:/Temp/excel_selection.json (written by excel_watch.py) — the live
        active splice sheet + selected STS/DR. Returns None if disabled, stale
        (watcher not running), or the active sheet isn't a known PON."""
        if not getattr(self, 'excel_chk', None) or not self.excel_chk.isChecked():
            return None
        import json, os, time
        p = r'C:/Temp/excel_selection.json'
        try:
            if not os.path.exists(p) or (time.time() - os.path.getmtime(p)) > 8:
                return None
            with open(p) as _f:
                d = json.load(_f)
        except Exception:
            return None
        if not d.get('valid') or d.get('sheet') not in self._idx['fts_by_port']:
            return None
        return d

    # ── route resolution + draw ─────────────────────────────────────────────
    def _show_route(self):
        # follow the live Excel sheet + selection if enabled
        xl = self._read_excel_sel()
        if xl:
            i = self.port_combo.findData(xl['sheet'])
            if i >= 0 and i != self.port_combo.currentIndex():
                self.port_combo.blockSignals(True)
                self.port_combo.setCurrentIndex(i)
                self.port_combo.blockSignals(False)
                self._on_port_changed()
        route = self._resolve_route(xl)
        if route is None:
            return
        self._route = route                  # remember for isolate / walk / card
        self._isolated_hop = None
        self._draw_route(route)
        self._fill_route_readout(route)
        self._refresh_panel(route)

    def _resolve_route(self, xl):
        """Resolve the whole PON route into a structured dict WITHOUT touching the
        canvas, so the rubber-band draw AND the on-panel hop diagram are driven by
        the SAME pass. Returns None when no port is selected."""
        port = self.port_combo.currentData()
        if not port:
            return None
        pon  = str(self._port_to_pon(port))
        only_sts = self.sts_combo.currentData()       # None = whole PON

        # Excel-driven filter: restrict to the STS / DR rows selected on the sheet
        xl_sts = set(xl['sts']) if (xl and not xl.get('whole') and xl.get('sts')) else None
        xl_drs = set(xl['drs']) if (xl and not xl.get('whole') and xl.get('drs')) else None

        sel = {}                                       # layer -> set(fid)
        geoms = {hop: [] for hop in _HOP_COLOURS}
        labels = OrderedDict((hop, []) for hop in _HOP_COLOURS)

        def add(hop, lyr_key, entry):
            if not entry:
                return
            if entry.get('geom') is not None and not entry['geom'].isEmpty():
                geoms[hop].append(entry['geom'])
            if entry.get('label'):
                labels[hop].append(entry['label'])
            lyr = self._layers.get(lyr_key)
            if lyr is not None and entry.get('fid') is not None:
                sel.setdefault(lyr.id(), (lyr, set()))[1].add(entry['fid'])

        # FTS + AGG dome (the head of the PON). Show the CANONICAL AGG label from
        # the FTS (matches the Excel sheet) for the read-out; light the dome at the
        # nearest physical Enclosures-Splice feature (the FTS label only matches the
        # layer's label_1 for 9/66 — known quirk), noting the feature label.
        fts = self._idx['fts_by_port'].get(port)
        add('fts', 'fts', fts)
        agg_disp = None
        if fts and fts.get('agg_geom') is not None:
            canon = fts.get('agg')                         # name embedded in the FTS label (drifted)
            feat_lab = fts.get('agg_label')                # the real co-located dome's label_1
            if fts.get('agg_matched') == 'nearest' and feat_lab and feat_lab != canon:
                # show the REAL co-located dome (matches the splice plan); note the
                # drifted FTS-embedded name in parens so the cross-check is still clear.
                lab = f'{feat_lab}   (FTS label: {canon.split(".")[-1]})'
            else:
                lab = canon
            agg_disp = lab
            add('agg', 'agg', {'fid': fts.get('agg_fid'),
                               'geom': fts['agg_geom'], 'label': lab})
        elif fts and fts.get('agg'):
            agg_disp = fts['agg'] + '  (no dome feature)'
            labels['agg'].append(agg_disp)

        # feeder: prefer the geometry-corrected POP->AGG route (feeder_routes.json,
        # identical to the Excel feeder row); fall back to the legacy upstream trace,
        # then to the pon_no-tagged feeder. Keeps viewer + Excel feeders in lock-step.
        feeder_lbls = self._feeder_route_labels(pon) or (self._resolve_feeders(fts) if fts else [])
        if feeder_lbls:
            for fl in feeder_lbls:
                cab = self._idx['feed_by_label'].get(fl)
                if cab:
                    add('feeder', 'sec' if cab['kind'] == 'Secondary' else 'pri',
                        {'fid': cab['fid'], 'geom': cab['geom'], 'label': fl})
        else:
            for fc in self._idx['feed_by_pon'].get(pon, []):
                add('feeder', 'sec' if fc['kind'] == 'Secondary' else 'pri', fc)

        # STS → DIS dome → drops → ONTs, restricted by the active filter:
        #   Excel-selected STS  >  the scope combo's single STS  >  all STS
        import re as _re
        sts_all = self._idx['sts_by_port'].get(port, [])
        sts_list = sts_all
        if xl_sts is not None:
            sts_list = [s for s in sts_all if s['label'] in xl_sts]
        elif only_sts:
            sts_list = [s for s in sts_all if s['label'] == only_sts]
        legs = []
        for s in sts_list:
            add('sts', 'sts', s)
            legs.append({'leg': s.get('leg'), 'dis': s.get('dis'),
                         'sts_label': s.get('label'),
                         'homes': (len(self._idx['drops_by_dis'].get(s['dis'], []))
                                   if s.get('dis') else 0)})
            if s.get('dis'):
                # draw the DIS dome at the co-located feature (nearest to the STS),
                # not the stray label-point; keep the plan label
                if s.get('dis_geom') is not None:
                    add('dis', 'dis', {'fid': s.get('dis_fid'),
                                       'geom': s['dis_geom'], 'label': s['dis']})
                else:
                    dis = self._idx['dis_by_label'].get(s['dis'])
                    if dis:
                        add('dis', 'dis', {**dis, 'label': s['dis']})
                for dr in self._idx['drops_by_dis'].get(s['dis'], []):
                    if xl_drs is not None:                 # only the selected DR rows
                        m = _re.search(r'DR\d+', dr.get('ont') or dr.get('label') or '')
                        if not m or m.group(0) not in xl_drs:
                            continue
                    add('drop', 'drop', dr)
                    if dr.get('ont'):
                        # Anchor the ONT/home marker to the DROP's home end, not the
                        # ONT-feature lookup: the DR number drifts between the Drop and
                        # ONT layers, so ~21/99 ONT features resolve hundreds–thousands
                        # of m away (the white stragglers JJ flagged). The drop's far
                        # endpoint IS the home. Use the ONT feature only when it's truly
                        # co-located (<80 m) — then it also selects for the attr table;
                        # otherwise draw at the drop end and DON'T select the stray feature.
                        ref = s.get('dis_geom') or s.get('geom')
                        home = self._line_far_end(dr.get('geom'), ref)
                        ont = self._idx['ont_by_label'].get(dr['ont'])
                        og = ont.get('geom') if ont else None
                        near = (home is not None and og is not None and not og.isEmpty()
                                and og.distance(home) * 111320 < 80)
                        if near:
                            add('ont', 'ont', {**ont, 'label': dr['ont']})
                        elif home is not None:
                            add('ont', 'ont', {'geom': home, 'label': dr['ont']})
                        elif ont:
                            add('ont', 'ont', {**ont, 'label': dr['ont']})

        # distribution: every cable the route's domes physically sit on (shared
        # trunks tagged to other PONs included), so the WHOLE route shows — not
        # just the 2-3 cables that happen to carry this PON's tag. CLIP each cable
        # to the cluster vicinity so a long shared trunk doesn't shoot a tail
        # across the map (deviation).
        from qgis.core import QgsRectangle, QgsGeometry
        agg_g = fts.get('agg_geom') if fts else None
        dist_cables = self._resolve_distribution(geoms['dis'], agg_g, pon)
        crect = None
        for hop in ('dis', 'sts', 'ont', 'drop'):
            for g in geoms[hop]:
                bb = g.boundingBox()
                if not bb.isEmpty():
                    crect = QgsRectangle(bb) if crect is None else (crect.combineExtentWith(bb) or crect)
        clip = None
        if crect is not None and not crect.isEmpty():
            buf = 0.0014                      # ~150 m around the cluster
            clip = QgsGeometry.fromRect(QgsRectangle(
                crect.xMinimum()-buf, crect.yMinimum()-buf,
                crect.xMaximum()+buf, crect.yMaximum()+buf))
        clipped = []
        for dc in dist_cables:
            g = dc.get('geom')
            if g is None:
                continue
            if clip is not None:
                gi = g.intersection(clip)
                if gi is None or gi.isEmpty():
                    continue
                dc = {**dc, 'geom': gi}
            clipped.append(dc)
            add('dist', 'dist', dc)
        dist_cables = clipped

        # the 100 last-mile drop lines fan out from each STS into a starburst —
        # only draw them when the user asks (checkbox); the read-out always counts
        # them. Default view = clean trunk: feeder -> FTS -> distribution -> STS.
        show_drops = bool(getattr(self, 'drops_chk', None) and self.drops_chk.isChecked())
        draw_geoms = dict(geoms)
        if not show_drops:
            draw_geoms['drop'] = []

        # flow radiates from the AGG dome (PON source) — keep its point for arrows
        dome_pt = None
        if fts and fts.get('agg_geom') is not None and not fts['agg_geom'].isEmpty():
            dome_pt = fts['agg_geom'].centroid().asPoint()
        # halo only when narrowed to a specific STS / DR (Excel or scope combo)
        filtered = (xl_sts is not None) or (xl_drs is not None) or bool(only_sts)

        # counts + worst-case optical loss budget (POP->ONT vs GPON Class B+ 28 dB)
        nhomes = len(labels['drop']); nsts = len(labels['sts'])
        cap = nsts * 8                                 # each 1:8 STS = 8 ports
        spare = cap - nhomes
        fill = round(nhomes / cap * 100) if cap else 0
        loss = self._loss_budget(fts, sts_list, feeder_lbls, dist_cables)

        return {
            'port': port, 'pon': pon, 'zone': self._pon_to_zone(pon),
            'only_sts': only_sts, 'xl': xl, 'xl_sts': xl_sts, 'xl_drs': xl_drs,
            'filtered': filtered, 'fts': fts, 'agg_disp': agg_disp,
            'feeder_lbls': feeder_lbls, 'sts_all': sts_all, 'sts_list': sts_list,
            'legs': legs, 'dist_cables': dist_cables,
            'geoms': geoms, 'draw_geoms': draw_geoms, 'labels': labels, 'sel': sel,
            'show_drops': show_drops, 'dome_pt': dome_pt,
            'counts': {'nhomes': nhomes, 'nsts': nsts, 'cap': cap,
                       'spare': spare, 'fill': fill},
            'loss': loss,
            'pop_geom': (self._idx['pop']['geom'] if self._idx.get('pop') else None),
            'pop_label': (self._idx['pop']['label'] if self._idx.get('pop') else None),
            'flags': self._route_flags(port, fts, sts_all, legs, feeder_lbls),
        }

    def _draw_route(self, route):
        """Render the resolved route on the canvas — rubber bands, halo, flow
        arrows, text labels, layer selection, solo + zoom. Pure side effects, so
        the diagram-hop isolate / walk can re-draw any subset without re-resolving."""
        self._clear(keep_status=True)
        # rubber bands (drops only when the user asked — read-out still counts them)
        for hop, glist in route['draw_geoms'].items():
            band = self._bands[hop]
            gt = (QgsWkbTypes.GeometryType.LineGeometry if hop in ('feeder', 'dist', 'drop')
                  else QgsWkbTypes.GeometryType.PointGeometry)
            band.reset(gt)
            for g in glist:
                band.addGeometry(g, None)
        # bright halo around the SELECTED splitters + homes (Excel / scope combo)
        halo = self._bands['halo']
        halo.reset(QgsWkbTypes.GeometryType.PointGeometry)
        if route['filtered']:
            for g in route['geoms']['sts'] + route['geoms']['ont']:
                halo.addGeometry(g, None)
        # flow arrows trace ONLY the selected drop/STS path (feeder → its dist leg →
        # the drop). No selection = no arrows, so the whole PON isn't flooded.
        self._arrow_dome = route['dome_pt']
        if (getattr(self, 'arrows_chk', None) and self.arrows_chk.isChecked()
                and route.get('filtered')):
            self._arrow_geoms = self._selected_path_geoms(route)
            self._draw_arrows(self._arrow_geoms, self._arrow_dome,
                              getattr(self, '_arrow_phase', 0.0))
            self._start_arrow_anim()
        else:
            self._arrow_geoms = None
            self._stop_arrow_anim()
            for _bk in ('arrow', 'arrow_glow'):
                _ab = self._bands.get(_bk)
                if _ab is not None:
                    _ab.reset(QgsWkbTypes.GeometryType.PolygonGeometry)
        # on-canvas text labels: FTS, each STS leg, AGG/DIS domes, dist + feeder
        self._draw_labels(route['port'], route['fts'], route['sts_list'], route['pon'],
                          route['feeder_lbls'], route['show_drops'], route['filtered'],
                          route['dist_cables'])
        # select features in their layers (feeds the attribute table). Flag it so
        # the IDENTIFY handler ignores our own selection (only user clicks count).
        self._programmatic_select = True
        try:
            for lyr, fids in route['sel'].values():
                try:
                    lyr.selectByIds(list(fids))
                except Exception:
                    _swallowed_note()
        finally:
            self._programmatic_select = False
        # solo: dim every other layer so only this route stands out
        if getattr(self, 'solo_chk', None) and self.solo_chk.isChecked():
            self._apply_solo()
        else:
            self._restore_solo()
        self._zoom_to(route['geoms'])
        self.canvas.refresh()

    def _fill_route_readout(self, route):
        """Tick-list read-out (per-label, against the Excel sheet) + loss line +
        status bar — all from the resolved route dict."""
        self._fill_readout(route['port'], route['pon'], route['only_sts'], route['labels'])
        c = route['counts']; xl = route['xl']
        if route['xl_sts'] is not None or route['xl_drs'] is not None:
            tag = f'  ◀ Excel selection ({xl.get("selection","")})'
        elif xl:
            tag = '  ◀ following Excel sheet'
        else:
            tag = ''
        self._set_status(
            f'PON {route["pon"]} · {route["port"]} — {c["nsts"]} STS · {c["nhomes"]} homes · '
            f'{c["spare"]} spare · {c["cap"]} ports · {c["fill"]}% fill{tag}',
            colour=_GREEN)

    # ── visual hop-chain diagram ─────────────────────────────────────────────
    @staticmethod
    def _short_cable(l):
        """MOA.SF.48F.P.H161-P.H130 -> H161-H130 (compact for a diagram sub-label)."""
        import re
        if not l:
            return '—'
        return re.sub(r'^MOA\.\w+\.\d+F\.P\.', '', l).replace('-P.', '-')

    @staticmethod
    def _legnum(lg):
        """Natural leg order: L1, L2 … L10 (not the string sort L1, L10, L2)."""
        s = ''.join(ch for ch in (lg.get('leg') or '') if ch.isdigit())
        return int(s) if s else 0

    def _diagram_items(self, route):
        """Build the ordered POP -> ONT hop list the diagram renders. Each item:
        {hop, name, count, sub, color}. 'pop' is synthetic (no rubber band)."""
        c = route['counts']; lbl = route['labels']
        port = route['port']; pon = route['pon']
        fts = route['fts']
        card = port[:3]; pp = port[3:]
        feeder_lbl = (route['feeder_lbls'][0] if route['feeder_lbls']
                      else (lbl['feeder'][0] if lbl['feeder'] else None))
        agg_n = len(lbl['agg']) or (1 if (fts and fts.get('agg')) else 0)
        return [
            {'hop': 'pop', 'name': f'POP · OLT {port}', 'count': 'port',
             'sub': f'card {card} · port {pp} → PON {pon}', 'color': QColor(_ACCENT)},
            {'hop': 'feeder', 'name': 'Feeder', 'count': len(lbl['feeder']),
             'sub': self._short_cable(feeder_lbl), 'color': _HOP_COLOURS['feeder']},
            {'hop': 'agg', 'name': 'AGG dome', 'count': agg_n,
             'sub': route.get('agg_disp') or '—', 'color': _HOP_COLOURS['agg']},
            {'hop': 'fts', 'name': 'FTS splitter', 'count': '1:16',
             'sub': (fts.get('label') if fts else None) or '—',
             'color': _HOP_COLOURS['fts']},
            {'hop': 'dist', 'name': 'Distribution', 'count': len(route['dist_cables']),
             'sub': '24F Mini-ADSS legs → DIS domes', 'color': _HOP_COLOURS['dist']},
            {'hop': 'dis', 'name': 'DIS domes', 'count': len(lbl['dis']),
             'sub': 'one per STS · tap points', 'color': _HOP_COLOURS['dis']},
            {'hop': 'sts', 'name': 'STS splitters', 'count': c['nsts'],
             'sub': f"{c['nsts']} legs · 1:8 each", 'color': _HOP_COLOURS['sts']},
            {'hop': 'drop', 'name': 'Drops', 'count': c['nhomes'],
             'sub': '1F drop per home (≤55 m)', 'color': _HOP_COLOURS['drop']},
            {'hop': 'ont', 'name': 'ONT · homes', 'count': len(lbl['ont']) or c['nhomes'],
             'sub': f"{c['nhomes']} live homes · {c['spare']} ports spare",
             'color': _HOP_COLOURS['ont']},
        ]

    def _render_diagram(self, route):
        """(Re)build the vertical hop-chain cards from the resolved route. Cheap —
        ~9 cards — so just rebuild on every show."""
        lay = getattr(self, '_diagram_layout', None)
        if lay is None:
            return
        while lay.count():
            it = lay.takeAt(0)
            w = it.widget()
            if w is not None:
                w.setParent(None)
        self._hop_cards = {}
        items = self._diagram_items(route)
        for i, item in enumerate(items):
            lay.addWidget(self._build_diagram_card(item, is_last=(i == len(items) - 1)))
        lay.addStretch(1)
        self._highlight_diagram_hop(getattr(self, '_isolated_hop', None))

    # ── health card + plain-English explainer ────────────────────────────────
    def _hcell(self, k, v, vcolor, u, badge=None, gauge_pct=None, gauge_col=None):
        """One health-card cell: KEY · big value · unit, with an optional fill gauge
        or a status badge."""
        cell = QFrame()
        cell.setStyleSheet(f"QFrame {{ background:#0b1220; border:1px solid {_BORDER};"
                           f" border-radius:8px; }}")
        cl = QVBoxLayout(cell); cl.setContentsMargins(7, 7, 7, 7); cl.setSpacing(2)
        for text, css in (
            (k, "color:#6680a6; font-size:8px; letter-spacing:1px;"),
            (str(v), f"color:{vcolor}; font-size:17px; font-weight:700;"),
            (u, "color:#8fa6c6; font-size:8px;")):
            w = QLabel(text); w.setAlignment(Qt.AlignmentFlag.AlignHCenter)
            w.setStyleSheet(f"{css} font-family:Consolas; background:transparent; border:none;")
            cl.addWidget(w)
        if gauge_pct is not None:
            from qgis.PyQt.QtWidgets import QProgressBar
            g = QProgressBar(); g.setRange(0, 100)
            g.setValue(max(0, min(100, int(gauge_pct))))
            g.setTextVisible(False); g.setFixedHeight(5)
            g.setStyleSheet(
                f"QProgressBar {{ background:#16263a; border:none; border-radius:3px; }}"
                f"QProgressBar::chunk {{ background:{gauge_col or _ACCENT}; border-radius:3px; }}")
            cl.addWidget(g)
        if badge is not None:
            btxt, bcol = badge
            bl = QLabel(btxt); bl.setAlignment(Qt.AlignmentFlag.AlignHCenter)
            bl.setStyleSheet(f"color:{bcol}; font-family:Consolas; font-size:8px;"
                             f" font-weight:700; letter-spacing:1px;"
                             f" background:transparent; border:none;")
            cl.addWidget(bl)
        return cell

    def _render_health(self, route):
        """Homes / fill% / loss-margin cells — green/amber/red read at a glance."""
        lay = getattr(self, '_health_layout', None)
        if lay is None:
            return
        while lay.count():
            it = lay.takeAt(0); w = it.widget()
            if w is not None:
                w.setParent(None)
        c = route['counts']
        fill = c['fill']
        fcol = (_RED if fill > 100 else ('#f59e0b' if fill > 90 else _GREEN))
        lay.addWidget(self._hcell('HOMES', c['nhomes'], _ACCENT,
                                  f"of {c['cap']} ports", gauge_pct=fill, gauge_col=_ACCENT))
        lay.addWidget(self._hcell('FILL', f"{fill}%", fcol,
                                  f"{c['spare']} spare", gauge_pct=fill, gauge_col=fcol))

    def _render_explainer(self, route):
        """Write 'how this PON runs' in plain English from the resolved route."""
        lbl = getattr(self, '_why_lbl', None)
        if lbl is None:
            return
        import re
        c = route['counts']; fts = route['fts']
        port = route['port']; pon = route['pon']
        feeder_lbl = (route['feeder_lbls'][0] if route['feeder_lbls']
                      else (route['labels']['feeder'][0] if route['labels']['feeder'] else None))
        m = re.search(r'(\d+F)', feeder_lbl or '')
        fspec = m.group(1) if m else 'feeder'
        ftail = self._short_cable(feeder_lbl) if feeder_lbl else '—'
        agg = route.get('agg_disp') or ''
        am = re.search(r'\.P\.([A-Za-z]?\d+)', agg)
        agg_tail = am.group(1) if am else (agg.split('.')[-1] if agg else '—')
        ndist = len(route['dist_cables']); nsts = c['nsts']
        if fts:
            txt = (
                f"OLT port <b>{port}</b> (PON {pon}) feeds a <b>{fspec}</b> feeder "
                f"(<b>{ftail}</b>) to the AGG dome at <b>{agg_tail}</b>, where a "
                f"<b>1:16 splitter</b> fans out to <b>{ndist}</b> distribution "
                f"leg{'s' if ndist != 1 else ''}. Each ends at a DIS dome with a "
                f"<b>1:8 splitter</b>. Together the <b>{nsts} STS</b> serve "
                f"<b>{c['nhomes']} homes</b> ({c['spare']} ports spare).")
        else:
            txt = (f"No FTS splitter resolves for <b>{port}</b> — open the splice "
                   f"project (with the FTS / STS / dome layers).")
        lbl.setText(txt)

    def _refresh_panel(self, route):
        """Rebuild every on-panel readout from one resolved route (diagram, health,
        explainer, leg list, flags). The canvas draw is separate (_draw_route)."""
        self._render_diagram(route)
        self._render_health(route)
        self._render_explainer(route)
        self._render_legs(route)
        self._render_flags(route)

    def _toggle_legs(self):
        on = self._legs_toggle.isChecked()
        self._legs_box.setVisible(on)
        cur = self._legs_toggle.text()
        self._legs_toggle.setText(('▾' if on else '▸') + cur[1:])

    def _render_legs(self, route):
        """List every STS leg (L1..Ln → DIS dome + home count). Click a leg to
        narrow the canvas to just that STS (reuses the scope-combo path)."""
        lay = getattr(self, '_legs_layout', None)
        if lay is None:
            return
        while lay.count():
            it = lay.takeAt(0); w = it.widget()
            if w is not None:
                w.setParent(None)
        import re
        legs = route.get('legs') or []
        on = self._legs_toggle.isChecked()
        self._legs_toggle.setText(
            ('▾' if on else '▸')
            + f"  {len(legs)} STS legs   ·  click a leg to isolate it")
        for lg in sorted(legs, key=self._legnum):
            tail = re.sub(r'.*\.P\.', '', lg.get('dis') or '') or '—'
            row = _ClickFrame(lambda s=lg.get('sts_label'): self._isolate_leg(s))
            row.setObjectName('legrow')
            row.setStyleSheet(
                "QFrame#legrow { background:transparent; border:none;"
                " border-top:1px solid #101c2c; }"
                "QFrame#legrow:hover { background:#0e1830; }")
            rl = QHBoxLayout(row); rl.setContentsMargins(10, 5, 10, 5); rl.setSpacing(8)
            lgl = QLabel(lg.get('leg') or '—'); lgl.setFixedWidth(34)
            lgl.setStyleSheet(f"color:{_GREEN}; font-family:Consolas; font-weight:700;"
                              f" font-size:10px; background:transparent; border:none;")
            dml = QLabel(tail)
            dml.setStyleSheet("color:#90a6c6; font-family:Consolas; font-size:10px;"  # dual-theme-ok: inside the dark PON-route panel
                              " background:transparent; border:none;")
            hml = QLabel(f"{lg.get('homes', 0)} homes")
            hml.setStyleSheet(f"color:{_ACCENT}; font-family:Consolas; font-size:10px;"
                              f" background:transparent; border:none;")
            rl.addWidget(lgl); rl.addWidget(dml, 1); rl.addWidget(hml)
            lay.addWidget(row)

    def _isolate_leg(self, sts_label):
        """Narrow the route to one STS leg via the scope combo, then redraw."""
        if not sts_label:
            return
        if getattr(self, 'excel_chk', None) and self.excel_chk.isChecked():
            self.excel_chk.setChecked(False)     # so the narrow sticks
        for j in range(self.sts_combo.count()):
            if self.sts_combo.itemData(j) == sts_label:
                self.sts_combo.setCurrentIndex(j)
                break
        self._show_route()

    def _render_flags(self, route):
        """Show route sanity flags (red/amber); hide the banner when clean."""
        lbl = getattr(self, '_flags_lbl', None)
        if lbl is None:
            return
        flags = route.get('flags') or []
        if not flags:
            lbl.setVisible(False); lbl.setText('')
            return
        rows = []
        for sev, text in flags[:8]:
            colr = '#FF5C6C' if sev == 'red' else '#F5A623'
            rows.append(f"<span style='color:{colr}'>⚠ {text}</span>")
        if len(flags) > 8:
            rows.append(f"… +{len(flags) - 8} more")
        lbl.setText('<br>'.join(rows))
        lbl.setVisible(True)

    # ── walk-the-route · zoom · route card ───────────────────────────────────
    def _zoom_route(self):
        route = getattr(self, '_route', None)
        if route:
            self._zoom_to(route['geoms']); self.canvas.refresh()

    def _draw_single_hop(self, hop):
        """Light ONLY one hop's band (used by isolate + walk). No selection/solo."""
        route = getattr(self, '_route', None)
        if not route:
            return
        for h, band in self._bands.items():
            gt = (QgsWkbTypes.GeometryType.LineGeometry
                  if h in ('feeder', 'dist', 'drop', 'arrow')
                  else QgsWkbTypes.GeometryType.PointGeometry)
            band.reset(gt)
        band = self._bands.get(hop)
        if band is not None:
            for g in route['geoms'].get(hop, []):
                band.addGeometry(g, None)
        self.canvas.refresh()

    def _walk_route(self):
        """Guided tour: step POP→home lighting each hop in turn. Click again to stop."""
        if getattr(self, '_walk_timer', None) is not None:
            self._stop_walk(); return
        route = getattr(self, '_route', None)
        if not route or not any(route['geoms'].get(h) for h in _HOP_COLOURS):
            self._show_route(); route = getattr(self, '_route', None)
        if not route:
            return
        order = ['feeder', 'agg', 'fts', 'dist', 'dis', 'sts', 'drop', 'ont']
        self._walk_hops = [h for h in order if route['geoms'].get(h)]
        if not self._walk_hops:
            return
        self._walk_idx = 0
        self._walk_timer = QTimer(self)
        self._walk_timer.setInterval(850)
        self._walk_timer.timeout.connect(self._walk_step)
        self._walk_step()                 # light the first hop immediately
        self._walk_timer.start()

    def _walk_step(self):
        hops = getattr(self, '_walk_hops', [])
        i = getattr(self, '_walk_idx', 0)
        if i >= len(hops):
            self._stop_walk(); return
        hop = hops[i]; self._walk_idx = i + 1
        self._draw_single_hop(hop)
        self._highlight_diagram_hop(hop)
        self._set_status(
            f'Walking… {i + 1}/{len(hops)}: {_HOP_TITLES.get(hop, hop.upper())}',
            colour=_HOP_COLOURS[hop].name() if hop in _HOP_COLOURS else _ACCENT)

    def _stop_walk(self):
        t = getattr(self, '_walk_timer', None)
        if t is not None:
            try:
                t.stop(); t.deleteLater()
            except Exception:
                _swallowed_note()
        self._walk_timer = None
        route = getattr(self, '_route', None)
        if route:
            self._isolated_hop = None
            self._draw_route(route)
            self._highlight_diagram_hop(None)
            self._set_status(f'Walk done — whole PON {route["pon"]}', colour=_GREEN)

    def _route_card(self):
        """Export a one-PON A4 route card (HTML) and open it for printing."""
        route = getattr(self, '_route', None)
        if not route:
            self._show_route(); route = getattr(self, '_route', None)
        if not route:
            return
        try:
            import os, tempfile
            html = self._route_card_html(route)
            outdir = r'C:/Users/jjsch/OneDrive/ON LAPTOP FIBRE/QGIS test'
            if not os.path.isdir(outdir):
                outdir = tempfile.gettempdir()
            path = os.path.join(outdir, f"Route_Card_{route['port']}_PON{route['pon']}.html")
            with open(path, 'w', encoding='utf-8') as f:
                f.write(html)
            from qgis.PyQt.QtGui import QDesktopServices
            from qgis.PyQt.QtCore import QUrl
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))
            self._set_status(
                f'Route card → {os.path.basename(path)} (print A4 from the browser)',
                colour=_ACCENT)
        except Exception as e:
            self._set_status(f'Route card failed: {e}', colour=_RED)

    def _route_card_html(self, route):
        import re, html as _h
        c = route['counts']
        items = self._diagram_items(route)
        why = self._why_lbl.text() if getattr(self, '_why_lbl', None) else ''
        legs = sorted(route.get('legs') or [], key=self._legnum)
        hop_rows = ''
        for it in items:
            hop_rows += (
                f"<tr><td class='dot'><span style='background:{it['color'].name()}'></span></td>"
                f"<td class='nm'>{_h.escape(str(it['name']))}</td>"
                f"<td class='ct'>{_h.escape(str(it['count']))}</td>"
                f"<td class='sb'>{_h.escape(str(it.get('sub') or ''))}</td></tr>")
        leg_rows = ''
        for lg in legs:
            tail = re.sub(r'.*\.P\.', '', lg.get('dis') or '') or '—'
            leg_rows += (f"<tr><td>{_h.escape(lg.get('leg') or '—')}</td>"
                         f"<td>{_h.escape(tail)}</td><td>{lg.get('homes', 0)} homes</td></tr>")
        flags = route.get('flags') or []
        flag_html = ''
        if flags:
            fl = ''.join(f"<li>{_h.escape(t)}</li>" for _s, t in flags)
            flag_html = f"<h2>⚠ Flags</h2><ul class='flags'>{fl}</ul>"
        return (
            "<!DOCTYPE html><html><head><meta charset='utf-8'><style>"
            "@page{size:A4;margin:16mm} body{font-family:'Segoe UI',Arial,sans-serif;color:#13202e}"
            "h1{font-size:20px;margin:0 0 2px} h2{font-size:13px;margin:14px 0 4px}"
            ".sub{color:#5a6b80;font-size:12px;margin-bottom:14px}"
            ".cards{display:flex;gap:10px;margin:10px 0 6px}"
            ".card{flex:1;border:1px solid #cfd8e3;border-radius:8px;padding:8px 10px}"
            ".card .k{font-size:9px;letter-spacing:1px;color:#6b7c90}"
            ".card .v{font-size:20px;font-weight:700}"
            "table{width:100%;border-collapse:collapse;font-size:11px}"
            "td,th{text-align:left;padding:4px 6px;border-bottom:1px solid #e6ecf3}"
            "td.dot{width:14px} td.dot span{display:inline-block;width:11px;height:11px;border-radius:50%}"
            ".nm{font-weight:700} .ct{color:#5a6b80} .sb{color:#5a6b80;font-family:Consolas}"
            ".why{background:#f3f8f4;border:1px solid #cfe3d4;border-radius:8px;padding:10px 12px;"
            "font-size:12px;line-height:1.5;margin-top:8px} .flags{color:#b9770a;font-size:11px}"
            "</style></head><body>"
            f"<h1>Splice Route Card — {_h.escape(route['port'])}</h1>"
            f"<div class='sub'>PON {route['pon']} · Zone {route['zone']} · "
            f"{c['nhomes']} homes · {c['nsts']} STS · {c['spare']} ports spare · Velocity Fibre</div>"
            "<div class='cards'>"
            f"<div class='card'><div class='k'>HOMES</div><div class='v'>{c['nhomes']}</div>"
            f"<div>of {c['cap']} ports</div></div>"
            f"<div class='card'><div class='k'>FILL</div><div class='v'>{c['fill']}%</div>"
            f"<div>{c['spare']} spare</div></div></div>"
            "<h2>Route — POP → home</h2>"
            f"<table>{hop_rows}</table>"
            f"<div class='why'>{why}</div>"
            f"<h2>STS legs ({len(legs)})</h2>"
            f"<table><tr><th>Leg</th><th>DIS dome</th><th>Homes</th></tr>{leg_rows}</table>"
            f"{flag_html}</body></html>")

    def _build_diagram_card(self, item, is_last=False):
        from qgis.PyQt.QtWidgets import QSizePolicy
        hop = item['hop']; hexc = item['color'].name()
        row = QWidget()
        h = QHBoxLayout(row); h.setContentsMargins(0, 0, 0, 0); h.setSpacing(8)
        # rail: colour dot + connecting line down to the next hop
        rail = QWidget(); rail.setFixedWidth(18)
        rv = QVBoxLayout(rail); rv.setContentsMargins(0, 4, 0, 0); rv.setSpacing(0)
        dot = QLabel(); dot.setFixedSize(13, 13)
        dot.setStyleSheet(f"background:{hexc}; border-radius:6px; border:none;")
        rv.addWidget(dot, 0, Qt.AlignmentFlag.AlignHCenter)
        if not is_last:
            line = QFrame(); line.setFixedWidth(2)
            line.setStyleSheet("background:#26405e; border:none;")
            line.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
            rv.addWidget(line, 1, Qt.AlignmentFlag.AlignHCenter)
        h.addWidget(rail)
        # card body
        card = _ClickFrame(lambda hp=hop: self._isolate_hop(hp))
        card.setObjectName('hopcard')
        card.setStyleSheet(
            f"QFrame#hopcard {{ background:#0b1322; border:1px solid {_BORDER};"
            f" border-radius:6px; }}"
            f"QFrame#hopcard:hover {{ border-color:{hexc}; background:#0e1830; }}")
        cv = QVBoxLayout(card); cv.setContentsMargins(9, 6, 9, 6); cv.setSpacing(2)
        top = QHBoxLayout(); top.setSpacing(6)
        nm = QLabel(item['name'])
        nm.setStyleSheet(f"color:{hexc}; font-family:'Segoe UI'; font-weight:700;"
                         f" font-size:11px; background:transparent; border:none;")
        top.addWidget(nm); top.addStretch(1)
        badge = QLabel(str(item['count']))
        badge.setStyleSheet(f"background:{hexc}; color:#04070d; border-radius:8px;"
                            f" padding:1px 8px; font-family:Consolas; font-weight:700;"
                            f" font-size:9px;")
        top.addWidget(badge)
        cv.addLayout(top)
        sub = item.get('sub')
        if sub:
            sl = QLabel(sub); sl.setWordWrap(True)
            sl.setStyleSheet("color:#90a6c6; font-family:Consolas; font-size:9px;"  # dual-theme-ok: inside the dark PON-route panel
                             " background:transparent; border:none;")
            cv.addWidget(sl)
        h.addWidget(card, 1)
        self._hop_cards[hop] = card
        return row

    def _highlight_diagram_hop(self, hop):
        """Outline the active hop card; restore the rest to their resting style."""
        for hp, card in getattr(self, '_hop_cards', {}).items():
            qcol = QColor(_ACCENT) if hp == 'pop' else _HOP_COLOURS.get(hp, QColor(_ACCENT))
            hexc = qcol.name()
            if hp == hop:
                card.setStyleSheet(
                    f"QFrame#hopcard {{ background:#0e1830; border:2px solid {hexc};"
                    f" border-radius:6px; }}")
            else:
                card.setStyleSheet(
                    f"QFrame#hopcard {{ background:#0b1322; border:1px solid {_BORDER};"
                    f" border-radius:6px; }}"
                    f"QFrame#hopcard:hover {{ border-color:{hexc}; background:#0e1830; }}")

    def _isolate_hop(self, hop):
        """Click a diagram hop → light ONLY that hop on the canvas (toggle: click
        again, or a hop with no geometry, restores the whole route)."""
        route = getattr(self, '_route', None)
        if not route:
            return
        # POP: light the single aggregation point (it lives ~km from the cluster,
        # so it's only drawn when its card is clicked). Toggle off like any hop.
        if hop == 'pop':
            pg = route.get('pop_geom')
            if pg is None or pg.isEmpty():
                self._set_status('POP feature not found in the project', colour=_RED)
                return
            if getattr(self, '_isolated_hop', None) == 'pop':
                self._isolated_hop = None
                self._draw_route(route)
                self._highlight_diagram_hop(None)
                self._set_status(f'Showing whole PON {route["pon"]}', colour=_ACCENT)
                return
            self._isolated_hop = 'pop'
            for h, band in self._bands.items():
                gt = (QgsWkbTypes.GeometryType.LineGeometry
                      if h in ('feeder', 'dist', 'drop', 'arrow')
                      else QgsWkbTypes.GeometryType.PointGeometry)
                band.reset(gt)
            pb = self._bands.get('pop')
            if pb is not None:
                pb.addGeometry(pg, None)
            # select the POP feature so its attributes show for cross-check
            lyr = self._layers.get('pop')
            if lyr is not None and self._idx.get('pop'):
                self._programmatic_select = True
                try:
                    lyr.selectByIds([self._idx['pop']['fid']])
                except Exception:
                    _swallowed_note()
                finally:
                    self._programmatic_select = False
            self._zoom_to({'pop': [pg]})
            self.canvas.refresh()
            self._highlight_diagram_hop('pop')
            self._set_status(f'POP · {route.get("pop_label") or "aggregation point"}',
                             colour=_ACCENT)
            return
        glist = route['geoms'].get(hop, [])
        if not glist or getattr(self, '_isolated_hop', None) == hop:
            self._isolated_hop = None
            self._draw_route(route)
            self._highlight_diagram_hop(None)
            self._set_status(f'Showing whole PON {route["pon"]}', colour=_ACCENT)
            return
        self._isolated_hop = hop
        for h, band in self._bands.items():
            gt = (QgsWkbTypes.GeometryType.LineGeometry
                  if h in ('feeder', 'dist', 'drop', 'arrow')
                  else QgsWkbTypes.GeometryType.PointGeometry)
            band.reset(gt)
        band = self._bands.get(hop)
        if band is not None:
            for g in glist:
                band.addGeometry(g, None)
        self._zoom_to({hop: glist})
        self.canvas.refresh()
        self._highlight_diagram_hop(hop)
        self._set_status(
            f'Isolated {_HOP_TITLES.get(hop, hop.upper())} ({len(glist)}) — '
            f'click it again to show the whole route',
            colour=_HOP_COLOURS[hop].name() if hop in _HOP_COLOURS else _ACCENT)

    def _route_flags(self, port, fts, sts_all, legs, feeder_lbls=None):
        """Cheap sanity flags surfaced beside the route (expanded in a later step):
        an unresolved feeder cable, no FTS, no resolvable AGG dome feature, or a
        leg whose dome has 0 homes."""
        flags = []
        # A cached feeder label that no longer matches a live cable is DROPPED
        # silently by _resolve_route (and excluded from _loss_budget), so the route
        # looks complete while a hop is missing and the loss is understated. That
        # bit us on 2026-07-15 (G997) and again on 2026-07-27 (G901 -> H022) after
        # a live rename. Say so instead of hiding it. Checked BEFORE the no-FTS
        # early return so it is never swallowed.
        #
        # Only pole-to-pole CABLES are expected to resolve. The POP->manhole duct
        # hop (MOA.AGG.POP.01-MH.A001/A002) lives in the Ducts layer, which we do
        # not index, and is legitimately absent on every route -- flagging it would
        # fire on all 66 PONs and bury the real hit. Measured on live PH2:
        # 30/30 feeder cables contain '-P.', 0/2 duct hops do. Unknown naming on
        # another client simply stays quiet (fails safe, no false alarm).
        # isinstance guard: the labels come from a JSON cache, so a malformed file
        # could hand us a non-string -- `'-P.' in fl` would raise where the old
        # dict .get() never did. Never let a warning break the route it warns about.
        for fl in (feeder_lbls or []):
            if (isinstance(fl, str) and '-P.' in fl
                    and fl not in self._idx.get('feed_by_label', {})):
                flags.append(('amber',
                              f'Feeder cable not found live: {fl} '
                              '- hop not drawn, loss understated (stale cache?)'))
        if not fts:
            flags.append(('red', f'No FTS splitter resolves for {port}'))
            return flags
        if fts.get('agg_geom') is None:
            flags.append(('amber', 'FTS has no AGG dome feature on the map'))
        for lg in legs:
            if lg.get('homes', 0) == 0 and lg.get('dis'):
                tail = (lg.get('dis') or '').split('.')[-1]
                flags.append(('amber',
                              f"{lg.get('leg') or 'STS'} · {tail}: dome serves 0 homes"))
        return flags

    def _copy_route(self):
        """Copy the read-out (the full route breakdown) to the clipboard."""
        lines = [self.readout.item(i).text() for i in range(self.readout.count())]
        if not lines:
            return
        try:
            QApplication.clipboard().setText('\n'.join(lines))
            self._set_status(f'Copied {len(lines)} route lines to clipboard', colour=_ACCENT)
        except Exception:
            _swallowed_note()

    def _selected_path_geoms(self, route):
        """Arrow geoms for JUST the current selection's path: the feeder trunk +
        the distribution leg(s) that reach the selected DIS dome(s) + the selected
        drop(s). Everything else in the PON is left un-arrowed."""
        g = route['geoms']
        dis_geoms = [dm for dm in g.get('dis', []) if dm is not None and not dm.isEmpty()]
        th = 25 / 111320.0                      # ~25 m in degrees
        dist = []
        for dc in route.get('dist_cables', []):
            dgm = dc.get('geom')
            if dgm is None or dgm.isEmpty():
                continue
            if any(dgm.distance(dm) <= th for dm in dis_geoms):
                dist.append(dgm)
        # ONE clean POP -> ONT flow: trace a single drop (the selected DR, or the
        # first of a leg), not the whole STS drop-fan.
        return {
            'feeder': list(g.get('feeder', [])),
            'dist':   dist,
            'drop':   list(g.get('drop', []))[:1],
            'sts': [], 'dis': [], 'agg': [],
        }

    def _tick_arrows(self):
        """March the flow arrows one step. Bounded — self-stops when the viewer is
        hidden or the arrows checkbox is off (no always-on loop)."""
        if (not self.isVisible()
                or not (getattr(self, 'arrows_chk', None) and self.arrows_chk.isChecked())
                or not self._arrow_geoms):
            self._stop_arrow_anim()
            return
        self._arrow_phase = (self._arrow_phase + 0.005) % 1.0
        try:
            self._draw_arrows(self._arrow_geoms, self._arrow_dome, self._arrow_phase)
        except Exception:
            self._stop_arrow_anim()

    def _start_arrow_anim(self):
        t = getattr(self, '_arrow_timer', None)
        if t is not None and not t.isActive():
            t.start()

    def _stop_arrow_anim(self):
        t = getattr(self, '_arrow_timer', None)
        if t is not None and t.isActive():
            t.stop()

    def _draw_arrows(self, geoms, dome_pt, phase=0.0):
        """Draw filled flow-direction arrowheads along the feeder/dist/drop lines.
        Flow radiates from the AGG dome (the PON source): the feeder flows INTO
        the dome (from the POP), distribution + drops flow OUTWARD to the homes.
        `phase` (0..1) marches the heads along each line for the flow animation."""
        import math
        from qgis.core import QgsGeometry, QgsPointXY
        band = self._bands.get('arrow')
        glow = self._bands.get('arrow_glow')
        if band is None:
            return
        band.reset(QgsWkbTypes.GeometryType.PolygonGeometry)
        if glow is not None:
            glow.reset(QgsWkbTypes.GeometryType.PolygonGeometry)
        if dome_pt is None:
            return
        dx0, dy0 = dome_pt.x(), dome_pt.y()
        def dist2(p): return (p.x() - dx0) ** 2 + (p.y() - dy0) ** 2

        def polylines(geom):
            try:
                if geom.isMultipart():
                    return [pl for pl in geom.asMultiPolyline() if len(pl) >= 2]
                pl = geom.asPolyline()
                return [pl] if len(pl) >= 2 else []
            except Exception:
                return []

        # arrowhead size from the route's OWN cluster extent (deterministic — the
        # canvas may still be mid-zoom when this runs)
        from qgis.core import QgsRectangle
        rect = None
        for hop in ('dist', 'drop', 'sts', 'dis', 'agg', 'feeder'):
            for g in geoms.get(hop, []):
                bb = g.boundingBox()
                if not bb.isEmpty():
                    rect = QgsRectangle(bb) if rect is None else (rect.combineExtentWith(bb) or rect)
        span = max(rect.width(), rect.height()) if rect else 0.005
        SIZE = min(max(span * 0.018, 2e-5), 1.2e-4)

        glow_polys, crisp_polys = [], []
        def _tri(store, p, ux, uy, sz, wide):
            # collect a solid triangle ring (tip + two swept-back wings) — added to
            # its band in ONE multipolygon at the end (one repaint = smooth).
            bx, by = -ux * sz, -uy * sz                    # back along flow
            px, py = -uy * sz * wide, ux * sz * wide       # perpendicular half-width
            wl  = QgsPointXY(p.x() + bx + px, p.y() + by + py)
            wr  = QgsPointXY(p.x() + bx - px, p.y() + by - py)
            store.append([QgsPointXY(p.x(), p.y()), wl, wr, QgsPointXY(p.x(), p.y())])

        def add_head(p, ux, uy, sz):
            # a soft cyan halo under a crisp, sleeker head — a neon flow arrow
            if glow is not None:
                _tri(glow_polys, p, ux, uy, sz * 1.7, 0.62)
            _tri(crisp_polys, p, ux, uy, sz, 0.5)

        # trunk arrows (feeder/dist) large & prominent; drop arrows small & subtle
        HOP_SZ = {'feeder': SIZE * 1.4, 'dist': SIZE * 1.3, 'drop': SIZE * 0.55}
        for hop in ('feeder', 'dist', 'drop'):
            outward = hop != 'feeder'               # feeder flows toward the dome
            sz = HOP_SZ[hop]
            for g in geoms.get(hop, []):
                for pl in polylines(g):
                    # orient vertex list upstream -> downstream
                    if outward:
                        if dist2(pl[0]) > dist2(pl[-1]):
                            pl = pl[::-1]            # ensure increasing dist (outward)
                    else:
                        if dist2(pl[0]) < dist2(pl[-1]):
                            pl = pl[::-1]            # ensure decreasing dist (toward dome)
                    # total length + sample points
                    segs = [(pl[i], pl[i + 1]) for i in range(len(pl) - 1)]
                    seglen = [math.hypot(b.x() - a.x(), b.y() - a.y()) for a, b in segs]
                    total = sum(seglen)
                    if total <= 0:
                        continue
                    # number of arrowheads: drops 1, trunk lines scale with length
                    n = 1 if hop == 'drop' else min(4, max(1, int(total / (SIZE * 6))))
                    for k in range(n):
                        # marching offset: heads slide along the flow as phase 0->1
                        frac = ((k + 1) / (n + 1) + phase) % 1.0
                        target = total * frac
                        acc = 0.0
                        for (a, b), L in zip(segs, seglen):
                            if acc + L >= target and L > 0:
                                t = (target - acc) / L
                                px = a.x() + (b.x() - a.x()) * t
                                py = a.y() + (b.y() - a.y()) * t
                                ux, uy = (b.x() - a.x()) / L, (b.y() - a.y()) / L
                                # gentle size pulse travelling with the march
                                hz = sz * (0.82 + 0.30 * (0.5 + 0.5 * math.sin(2 * math.pi * frac)))
                                add_head(QgsPointXY(px, py), ux, uy, hz)
                                break
                            acc += L
        # flush each band as ONE multipolygon -> a single repaint per frame (smooth)
        if glow is not None and glow_polys:
            glow.addGeometry(QgsGeometry.fromMultiPolygonXY([[r] for r in glow_polys]), None)
        if crisp_polys:
            band.addGeometry(QgsGeometry.fromMultiPolygonXY([[r] for r in crisp_polys]), None)

    def _draw_labels(self, port, fts, sts_list, pon, feeder_lbls, show_drops,
                     emphasize=False, dist_cables=None):
        """Populate the text-label overlay: FTS, each STS leg + its DIS dome, the
        AGG dome, and the distribution + feeder cable IDs. When *emphasize* (a
        specific STS/DR is selected) the STS labels are drawn larger."""
        if not getattr(self, 'labels_chk', None) or not self.labels_chk.isChecked():
            self._labels.clear()
            return
        import re
        def sd(l):   # dome/pole tail: MOA.DIS.DM.P.F726 -> F726
            return re.sub(r'.*\.P\.', '', l or '')
        def sc(l):   # cable: MOA.DF.24F.P.F409-P.H263 -> F409-H263
            if not l:
                return ''
            return re.sub(r'^MOA\.\w+\.\d+F\.P\.', '', l).replace('-P.', '-')
        def ctr(g):
            try:
                return g.centroid().asPoint()
            except Exception:
                return None

        sts_sz = 14 if emphasize else 9       # selected splitter labels pop bigger
        items = []
        if fts and fts.get('geom') is not None and not fts['geom'].isEmpty():
            p = ctr(fts['geom'])
            if p: items.append((p, f'FTS 1:16 · {port}', QColor(245, 170, 255), 10))
        if fts and fts.get('agg_geom') is not None and not fts['agg_geom'].isEmpty():
            p = ctr(fts['agg_geom'])
            if p: items.append((p, 'AGG ' + sd(fts.get('agg')), QColor(120, 225, 245), 10))
        for s in sts_list:
            g = s.get('geom')
            if g is not None and not g.isEmpty():
                p = ctr(g)
                if p:
                    items.append((p, f"{s.get('leg') or 'STS'} · {sd(s.get('dis'))}",
                                  QColor(150, 245, 165), sts_sz))
        for dc in (dist_cables if dist_cables is not None
                   else self._idx['dist_by_pon'].get(str(pon), [])):
            g = dc.get('geom')
            if g is not None and not g.isEmpty():
                p = ctr(g)
                if p: items.append((p, sc(dc.get('label')), QColor(250, 180, 110), 9))
        for fl in (feeder_lbls or []):
            cab = self._idx['feed_by_label'].get(fl)
            if cab and cab.get('geom') is not None and not cab['geom'].isEmpty():
                p = ctr(cab['geom'])
                if p: items.append((p, 'feeder ' + sc(fl), QColor(255, 150, 150), 9))
        self._labels.set_items(items)

    def _zoom_to(self, geoms):
        from qgis.core import QgsRectangle
        rect = None
        # Frame the PON access cluster — the homes and their splitters/domes.
        # The feeder runs back to the POP and the distribution can fan out, so
        # zoom to drops/ONTs/STS/DIS first (the splice detail JJ checks); only
        # broaden to the other hops if that cluster is empty.
        cluster = ['drop', 'ont', 'sts', 'dis']
        broad   = ['agg', 'dist', 'fts', 'feeder']
        use = [h for h in cluster if geoms.get(h)]
        if not use:
            use = [h for h in (cluster + broad) if geoms.get(h)] or list(geoms.keys())
        for hop in use:
            for g in geoms.get(hop, []):
                bb = g.boundingBox()
                if bb.isEmpty():
                    continue
                rect = QgsRectangle(bb) if rect is None else (rect.combineExtentWith(bb) or rect)
        if rect is None or rect.isEmpty():
            return
        # buffer 12 %
        dx = rect.width() * 0.12 or 0.0005
        dy = rect.height() * 0.12 or 0.0005
        rect = QgsRectangle(rect.xMinimum() - dx, rect.yMinimum() - dy,
                            rect.xMaximum() + dx, rect.yMaximum() + dy)
        self.canvas.setExtent(rect)

    def _fill_readout(self, port, pon, only_sts, labels):
        from qgis.PyQt.QtWidgets import QListWidgetItem
        self.readout.clear()
        head = QListWidgetItem(
            f'━━ PON {pon} · Zone {self._pon_to_zone(pon)} · {port}'
            + (f'  ·  STS {only_sts.split(".")[-1]}' if only_sts else '  ·  WHOLE PON')
            + ' ━━')
        head.setForeground(QColor(_ACCENT)); self.readout.addItem(head)
        order = ['feeder', 'fts', 'agg', 'dist', 'sts', 'dis', 'drop', 'ont']
        for hop in order:
            vals = labels[hop]
            if not vals:
                continue
            hdr = QListWidgetItem(f'{_HOP_TITLES[hop]}  ({len(vals)})')
            hdr.setForeground(_HOP_COLOURS[hop]); self.readout.addItem(hdr)
            shown = vals if len(vals) <= 30 else vals[:30]
            for v in shown:
                self.readout.addItem(QListWidgetItem('   ' + str(v)))
            if len(vals) > 30:
                self.readout.addItem(QListWidgetItem(f'   … +{len(vals) - 30} more'))

    # ── solo (dim other layers) ──────────────────────────────────────────────
    def _apply_solo(self):
        """Fade every VECTOR layer to 15 % so only the bright route rubber bands
        (and the satellite basemap) stand out. Stores originals for restore."""
        from qgis.core import QgsVectorLayer
        if self._solo_saved is None:
            self._solo_saved = {}
            for l in QgsProject.instance().mapLayers().values():
                if isinstance(l, QgsVectorLayer):
                    try:
                        self._solo_saved[l.id()] = l.opacity()
                    except Exception:
                        _swallowed_note()
        # Persist the originals to the project so a CRASH/hide (where _restore_solo
        # never runs) can't strand the whole project at 15 % — heal_stranded_solo()
        # restores them on next plugin start. See ticket: recurring "greyed out" bug.
        try:
            import json as _json
            QgsProject.instance().writeEntry('SpliceViewer', 'soloSaved',
                                             _json.dumps(self._solo_saved))
        except Exception:
            _swallowed_note()
        for lid in list(self._solo_saved):
            l = QgsProject.instance().mapLayer(lid)
            if l:
                try:
                    l.setOpacity(0.15); l.triggerRepaint()
                except Exception:
                    _swallowed_note()

    def _restore_solo(self):
        # always clear the persisted safety copy — solo is (being) turned off
        try:
            QgsProject.instance().removeEntry('SpliceViewer', 'soloSaved')
        except Exception:
            _swallowed_note()
        if not self._solo_saved:
            self._solo_saved = None
            return
        for lid, op in self._solo_saved.items():
            l = QgsProject.instance().mapLayer(lid)
            if l:
                try:
                    l.setOpacity(op); l.triggerRepaint()
                except Exception:
                    _swallowed_note()
        self._solo_saved = None

    def _on_solo_toggled(self, on):
        # live toggle while a route is shown
        if on:
            if self.port_combo.currentData():
                self._apply_solo(); self.canvas.refresh()
        else:
            self._restore_solo(); self.canvas.refresh()

    def _set_status(self, msg, colour=_DIM):
        self._status_lbl.setText(msg)
        self._status_lbl.setStyleSheet(
            f"QLabel {{ color: {colour}; font-family: Consolas; font-size: 10px;"
            f" padding: 2px; }}")

    def _clear(self, keep_status=False):
        for hop, band in self._bands.items():
            gt = (QgsWkbTypes.GeometryType.LineGeometry if hop in ('feeder', 'dist', 'drop', 'arrow')
                  else QgsWkbTypes.GeometryType.PointGeometry)
            band.reset(gt)
        self._programmatic_select = True
        try:
            for lyr in self._layers.values():
                if lyr is not None:
                    try:
                        lyr.removeSelection()
                    except Exception:
                        _swallowed_note()
        finally:
            self._programmatic_select = False
        if getattr(self, '_labels', None) is not None:
            self._labels.clear()
        self._restore_solo()
        self.canvas.refresh()
        if not keep_status and hasattr(self, '_status_lbl'):
            self._set_status('Cleared.')

    def cleanup(self):
        """Stop the Excel poll timer, drop the per-layer selection handlers, and
        clear the canvas overlays. Called when the host dock is destroyed (or on
        plugin unload) — NOT on a plain hide, so a re-opened dock keeps working."""
        from qgis.PyQt import sip
        # CRITICAL: if 'solo' (dim-others) mode is still active, restore layer
        # opacity BEFORE we tear down — otherwise every vector layer is stranded at
        # 15 % (the whole project goes grey / invisible, and can get saved that way).
        try:
            self._restore_solo()
        except Exception:
            _swallowed_note()
        try:
            if getattr(self, '_xl_timer', None) is not None:
                self._xl_timer.stop()
        except Exception:
            _swallowed_note()
        try:
            if getattr(self, '_arrow_timer', None) is not None:
                self._arrow_timer.stop()
        except Exception:
            _swallowed_note()
        try:
            if getattr(self, '_walk_timer', None) is not None:
                self._walk_timer.stop()
            self._walk_timer = None
        except Exception:
            _swallowed_note()
        # guard each disconnect with sip.isdeleted: on app exit the C++ layer may
        # already be gone, and disconnecting a dead sender is an access violation.
        for lyr in self._layers.values():
            if lyr is not None and not sip.isdeleted(lyr):
                try:
                    lyr.selectionChanged.disconnect(self._on_user_select)
                except Exception:
                    _swallowed_note()
        try:
            self._clear()
        except Exception:
            _swallowed_note()

    def closeEvent(self, e):
        self.cleanup()
        super().closeEvent(e)


# combo styling reused by the route viewer
_COMBO_CSS = (
    f"QComboBox {{ background:#11131f; color:{_TEXT}; border:1px solid {_BORDER};"
    f" border-radius:4px; padding:5px 8px; font-family:Consolas; font-size:11px; }}"
    f"QComboBox:hover {{ border-color:{_ACCENT}; }}"
    f"QComboBox QAbstractItemView {{ background:#11131f; color:{_TEXT};"
    f" selection-background-color:{_VIOLET}; font-family:Consolas; font-size:11px; }}")


# ── Merged Pole Editor panel ──────────────────────────────────────────────────

class PoleEditorPanel(QWidget):

    def __init__(self, iface, lyr, parent=None):
        super().__init__(parent)                 # hosted in a _PanelDock (dockable)
        self.setObjectName('vfPoleEditorPanel')
        self.iface        = iface
        self.lyr          = lyr
        # Resolve thickness reason field name. Shapefile truncates to 10
        # chars ('thickness_'); GPKG keeps the full 'thickness_reason'.
        self.ti_thickness = lyr.fields().indexOf('thickness_')
        if self.ti_thickness < 0:
            self.ti_thickness = lyr.fields().indexOf('thickness_reason')
        if self.ti_thickness < 0:
            iface.messageBar().pushWarning(
                'Pole Editor',
                f"'{lyr.name()}' has no thickness_/thickness_reason field — "
                "RC and thickness buttons will be disabled."
            )
        self.ti_dim2      = lyr.fields().indexOf('dim2')
        # S5 Slack Bracket slot — note field name is 'subtype5' (NO underscore)
        self.ti_t5        = lyr.fields().indexOf('type_5')
        self.ti_st5       = lyr.fields().indexOf('subtype5')
        self.ti_sp5       = lyr.fields().indexOf('spec_5')
        self.ti_d5        = lyr.fields().indexOf('dim1_5')
        self.ti_d5_2      = lyr.fields().indexOf('dim2_5')
        self.setWindowTitle('Pole Editor')
        self.setMinimumWidth(360)

        # Static dashed rings — no animation, just visual markers.
        self._not_rc_geoms = {}
        self._blue_band = _SpinRing(
            iface.mapCanvas(), QColor(0, 170, 255, 255),          # electric blue
            radius_px=14, width_px=3.0, dash_pattern=[6, 3])
        self._yellow_band = _SpinRing(
            iface.mapCanvas(), QColor(0, 230, 80, 255),           # vivid lime
            radius_px=9, width_px=3.0, dash_pattern=[2, 2])
        self._red_band = _SpinRing(
            iface.mapCanvas(), QColor(255, 40, 80, 255),          # vivid red
            radius_px=11, width_px=3.0, dash_pattern=[1, 2])

        # Green diamonds — FTS splitters (reference overlay)
        self._fts_band = QgsRubberBand(iface.mapCanvas(), QgsWkbTypes.GeometryType.PointGeometry)
        self._fts_band.setColor(QColor(34, 197, 94, 255))           # bright green fill
        self._fts_band.setIcon(QgsRubberBand.IconType.ICON_FULL_DIAMOND)
        self._fts_band.setIconSize(26)
        self._fts_band.setWidth(3)                                    # outline stroke
        self._fts_band.setSecondaryStrokeColor(QColor(0, 80, 0, 220))  # dark green border

        # S5 band kept as a dummy so legacy callbacks don't AttributeError
        self._s5_band = QgsRubberBand(iface.mapCanvas(), QgsWkbTypes.GeometryType.PointGeometry)
        self._s5_band.setWidth(0)

        self._redraw_bands()

        # Keep the panel pinned to the canvas top-left corner
        canvas = iface.mapCanvas()
        canvas.installEventFilter(self)
        canvas.viewport().installEventFilter(self)

        # ── Layout ────────────────────────────────────────────────────────────
        self.setStyleSheet(f"QWidget#vfPoleEditorPanel {{ background: {_BG}; }}")
        layout = QVBoxLayout(self)
        layout.setSpacing(6)
        layout.setContentsMargins(12, 12, 12, 10)

        subtitle = QLabel('Click a pole on the map to select it, then:')
        subtitle.setStyleSheet(_SUBTITLE_LBL)
        layout.addWidget(subtitle)

        # Road crossing section
        rc_label = QLabel('ROAD CROSSING')
        rc_label.setStyleSheet(_SECTION_LBL)
        layout.addWidget(rc_label)

        rc_row = QHBoxLayout()
        rc_row.setSpacing(8)

        btn_mark_rc = QPushButton('🟢  Mark Road Crossing')
        btn_mark_rc.setStyleSheet(_BTN_GREEN)
        btn_mark_rc.clicked.connect(self._mark_rc)
        rc_row.addWidget(btn_mark_rc)

        btn_unmark_rc = QPushButton('🔴  Not Road Crossing')
        btn_unmark_rc.setStyleSheet(_BTN_RED)
        btn_unmark_rc.clicked.connect(self._unmark_rc)
        rc_row.addWidget(btn_unmark_rc)

        layout.addLayout(rc_row)

        # Divider
        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet(_DIVIDER)
        layout.addWidget(line)

        # Thickness section
        th_label = QLabel('POLE THICKNESS')
        th_label.setStyleSheet(_SECTION_LBL)
        layout.addWidget(th_label)

        th_row = QHBoxLayout()
        th_row.setSpacing(8)

        btn_thick = QPushButton('🔵  140-160mm  (Thick)')
        btn_thick.setStyleSheet(_BTN_GRADIENT)
        btn_thick.clicked.connect(self._make_thick)
        th_row.addWidget(btn_thick)

        btn_thin = QPushButton('⚪  120-140mm  (Thin)')
        btn_thin.setStyleSheet(_BTN_CLEAR)
        btn_thin.clicked.connect(self._make_thin)
        th_row.addWidget(btn_thin)

        layout.addLayout(th_row)

        # Slack Bracket (S5) — manual-only per project_s5_slack_bracket_decision.md
        s5_label = QLabel('SLACK BRACKET (S5 · MANUAL)')
        s5_label.setStyleSheet(_SECTION_LBL)
        layout.addWidget(s5_label)

        s5_row = QHBoxLayout(); s5_row.setSpacing(8)
        btn_s5_add = QPushButton('🟣  Add Slack Bracket')
        btn_s5_add.setStyleSheet(_BTN_S5)
        btn_s5_add.clicked.connect(self._mark_s5)
        s5_row.addWidget(btn_s5_add)

        btn_s5_rm = QPushButton('🚫  Remove Slack Bracket')
        btn_s5_rm.setStyleSheet(_BTN_CLEAR)
        btn_s5_rm.clicked.connect(self._unmark_s5)
        s5_row.addWidget(btn_s5_rm)
        layout.addLayout(s5_row)

        # Status
        self._status_lbl = QLabel('')
        self._status_lbl.setWordWrap(True)
        self._status_lbl.setStyleSheet(_STATUS_LBL)
        layout.addWidget(self._status_lbl)

        # Legend — static dashed-ring previews that match the canvas overlays
        legend_frame = QFrame()
        legend_frame.setStyleSheet('background: transparent;')
        lg = QVBoxLayout(legend_frame)
        lg.setContentsMargins(0, 0, 0, 0)
        lg.setSpacing(4)
        for hex6, pattern, label in (
            ('#00aaff', [], '  large blue ring  =  140-160mm thick pole'),
            ('#00e650', [], '  medium green ring  =  road crossing'),
            ('#ff2850', [], '  small red ring  =  NOT a road crossing'),
        ):
            row = QHBoxLayout()
            row.setSpacing(6)
            ring = _SpinRingPreview(QColor(hex6), pattern, diameter_px=22, width_px=2.2)
            row.addWidget(ring)
            lbl = QLabel(label)
            lbl.setStyleSheet(_HINT_LBL)
            row.addWidget(lbl, 1)
            lg.addLayout(row)
        fts_lbl = QLabel('🟢 green diamond = FTS splitter (main cable origin)')
        fts_lbl.setStyleSheet(_HINT_LBL)
        lg.addWidget(fts_lbl)
        layout.addWidget(legend_frame)

        click_hint = QLabel('Click to select · Shift+click to add · Edits auto-fill attrs')
        click_hint.setWordWrap(True)
        click_hint.setStyleSheet(_HINT_LBL)
        layout.addWidget(click_hint)

    # ── Internals ─────────────────────────────────────────────────────────────

    def _set_status(self, msg, colour=_TEXT):
        self._status_lbl.setText(msg)
        self._status_lbl.setStyleSheet(
            f"QLabel {{ color: {colour}; font-family: Consolas; "
            f"font-size: 10px; padding: 2px; }}"
        )

    def _redraw_bands(self):
        blue_pts = []
        green_pts = []
        red_pts = []
        for f in self.lyr.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            pt = g.asPoint()
            if str(f['dim2']) == '140-160mm':
                blue_pts.append(pt)
            # Use the resolved thickness-reason index (shapefile 'thickness_' vs
            # GPKG 'thickness_reason') so the green RC overlay works on both.
            ti = getattr(self, 'ti_thickness', -1)
            tval = f.attribute(ti) if ti is not None and ti >= 0 else None
            if tval is not None and 'road crossing' in str(tval).lower():
                green_pts.append(pt)
        for geom in self._not_rc_geoms.values():
            if geom and not geom.isEmpty():
                red_pts.append(geom.asPoint())
        self._blue_band.setPoints(blue_pts)
        self._yellow_band.setPoints(green_pts)
        self._red_band.setPoints(red_pts)
        # FTS splitters — yellow diamonds (rubber band, not animated)
        self._fts_band.reset(QgsWkbTypes.GeometryType.PointGeometry)
        proj = QgsProject.instance()
        candidates = [l for l in proj.mapLayers().values()
                      if 'fts' in l.name().lower() and 'splitter' in l.name().lower()]
        fts_lyr = next((l for l in candidates if 'v1' in l.name().lower()), None) \
                  or (candidates[0] if candidates else None)
        if fts_lyr:
            for f in fts_lyr.getFeatures():
                g = f.geometry()
                if g and not g.isEmpty():
                    self._fts_band.addGeometry(g, None)

    def _write_attrs(self, attr_map):
        """Write attribute changes through the edit buffer when the layer is
        editable, otherwise via the data provider. Returns True on success."""
        if not attr_map:
            return True
        if self.lyr.isEditable():
            ok = True
            for fid, kv in attr_map.items():
                for idx, val in kv.items():
                    if not self.lyr.changeAttributeValue(fid, idx, val):
                        ok = False
            return ok
        return self.lyr.dataProvider().changeAttributeValues(attr_map)

    def _auto_populate_new(self, fids):
        """For any pole in *fids* that still has a null Label / Pole Type /
        hardware / lat / lon / dim2, compute and fill in the canonical PH2
        attribute set (H-sequence label, Pole Type from nearest cable, way
        count, Dead-End hardware default (Tangent is set later by FT8, the road
        crossing update, per the Fibertime AOI rule), Slot 4 Hook, Slot 6/7
        BandIt, dim2 default 140-160mm, lat/lon from geometry). Silent no-op
        for poles that already have everything filled in."""
        import math, re
        from qgis.core import QgsProject

        lyr = self.lyr
        flds = lyr.fields()
        def fi(n): return flds.indexOf(n)
        F_LBL=fi("Label"); F_PT=fi("Pole Type")
        F_T2=fi("type_2"); F_ST2=fi("subtype_2"); F_D2=fi("dim1_2"); F_SP2=fi("spec_2"); F_FN1=fi("featno1")
        F_T3=fi("type_3")   # read only - slot 3 (Tangent) is written by FT8
        F_T4=fi("type_4"); F_ST4=fi("subtype4"); F_SP4=fi("spec_4"); F_D4=fi("dim1_4"); F_FN3=fi("featno3"); F_FN4=fi("featno4")
        F_T6=fi("type_6"); F_ST6=fi("subtype_6"); F_SP6=fi("spec_6"); F_DM6=fi("dim1_6"); F_FN5=fi("featno5")
        F_T7=fi("type_7"); F_ST7=fi("subtype7");  F_SP7=fi("spec_7"); F_DM7=fi("dim1_7"); F_FN6=fi("featno6")
        F_LAT=fi("lat"); F_LON=fi("lon"); F_DIM2=fi("dim2")

        def is_null(v): return v is None or str(v).strip() in ("", "NULL", "None")

        needs = []
        for fid in fids:
            f = lyr.getFeature(fid)
            if (is_null(f.attribute(F_LBL)) or is_null(f.attribute(F_PT)) or
                (is_null(f.attribute(F_T2)) and is_null(f.attribute(F_T3))) or
                is_null(f.attribute(F_DIM2)) or is_null(f.attribute(F_LAT)) or
                is_null(f.attribute(F_LON)) or is_null(f.attribute(F_SP4)) or
                is_null(f.attribute(F_SP6))):
                needs.append(fid)
        if not needs:
            return

        target_geoms = {}
        for fid in needs:
            g = lyr.getFeature(fid).geometry()
            if g and not g.isEmpty():
                target_geoms[fid] = g.asPoint()
        if not target_geoms:
            return

        SNAP_M = 3.0
        SNAP_DEG = SNAP_M / 111320.0

        CABLE_LAYERS = [
            ("Primary Cable v1",    "Primary Feeder",   3),
            ("Secondary Cable v1",  "Secondary Feeder", 2),
            ("Distribution Cable v1","Distribution",    1),
            ("Drop Cable v1",       "Drop",             0),
        ]
        proj = QgsProject.instance()
        hits = {fid: [] for fid in target_geoms}
        for lname, ptype, rank in CABLE_LAYERS:
            clyr = next((l for l in proj.mapLayers().values()
                         if l.name().lower() == lname.lower()), None)
            if not clyr:
                continue
            for feat in clyr.getFeatures():
                g = feat.geometry()
                if not g or g.isEmpty():
                    continue
                cbb = g.boundingBox()
                relevant = [(fid, pt) for fid, pt in target_geoms.items()
                            if cbb.xMinimum() - SNAP_DEG <= pt.x() <= cbb.xMaximum() + SNAP_DEG
                            and cbb.yMinimum() - SNAP_DEG <= pt.y() <= cbb.yMaximum() + SNAP_DEG]
                if not relevant:
                    continue
                lines = [g.asPolyline()] if not g.isMultipart() else g.asMultiPolyline()
                for line in lines:
                    if len(line) < 2:
                        continue
                    for i, v in enumerate(line):
                        for fid, pt in relevant:
                            dx = v.x() - pt.x(); dy = v.y() - pt.y()
                            if (dx*dx + dy*dy) ** 0.5 > SNAP_DEG:
                                continue
                            neighbours = []
                            if i > 0:
                                for j in range(i - 1, -1, -1):
                                    nv = line[j]
                                    if ((nv.x() - pt.x())**2 + (nv.y() - pt.y())**2) ** 0.5 > SNAP_DEG:
                                        neighbours.append(nv); break
                            if i < len(line) - 1:
                                for j in range(i + 1, len(line)):
                                    nv = line[j]
                                    if ((nv.x() - pt.x())**2 + (nv.y() - pt.y())**2) ** 0.5 > SNAP_DEG:
                                        neighbours.append(nv); break
                            for nv in neighbours:
                                bin_ = round(math.degrees(math.atan2(nv.y() - pt.y(),
                                                                      nv.x() - pt.x())) / 15) * 15
                                hits[fid].append((bin_, rank, ptype))

        max_h = 0
        for f in lyr.getFeatures():
            m = re.search(r"\.H(\d+)$", str(f.attribute(F_LBL) or ""))
            if m:
                max_h = max(max_h, int(m.group(1)))

        null_lbl_fids = [fid for fid in needs
                         if is_null(lyr.getFeature(fid).attribute(F_LBL))]
        null_lbl_fids.sort()
        label_assign = {fid: f"MOA.P.H{max_h + 1 + i}"
                        for i, fid in enumerate(null_lbl_fids)}

        updates = {}
        for fid, pt in target_geoms.items():
            f = lyr.getFeature(fid)
            upd = updates.setdefault(fid, {})

            def fill(idx, val):
                # Only write if the cell is currently null — never clobber
                # a value the user set.
                if idx >= 0 and is_null(f.attribute(idx)):
                    upd[idx] = val

            if fid in label_assign:
                fill(F_LBL, label_assign[fid])

            h = hits.get(fid, [])
            non_drop_dirs = {x[0] for x in h if x[1] > 0}
            way_count = max(1, len(non_drop_dirs))

            cur_pt = str(f.attribute(F_PT))
            new_pt = None
            non_drop = [x for x in h if x[1] > 0]
            if non_drop:
                new_pt = max(non_drop, key=lambda x: x[1])[2]
            elif h:
                new_pt = "Drop"
            if is_null(cur_pt) and new_pt:
                fill(F_PT, new_pt)
                cur_pt = new_pt

            cur_t2 = str(f.attribute(F_T2))
            cur_t3 = str(f.attribute(F_T3))

            # Only write hardware slots if BOTH t2 and t3 are currently null
            # (i.e. the pole has never been classified). Never overwrite an
            # existing Tangent/Dead-End choice — that includes manual exceptions.
            if is_null(cur_t2) and is_null(cur_t3):
                cable_dim = "10,54-11,65mm" if cur_pt == "Primary Feeder" else "9,40-10,50mm"
                fill(F_T2, "Dead-End"); fill(F_ST2, "ADSS")
                fill(F_SP2, "Galvanised Steel Wire/Steel Thimble")
                fill(F_D2, cable_dim)
                fill(F_FN1, way_count)

            # Slot 4 Hook — fill only if null
            fill(F_T4, "Hook"); fill(F_ST4, "Offset Bracket")
            fill(F_SP4, f"{way_count}Way")
            fill(F_D4, f"(R19*W12,50mm)*{way_count}")
            fill(F_FN3, way_count)
            fill(F_FN4, 1)
            # Slot 6 / 7 BandIt — fill only if null
            fill(F_T6, "Attachment"); fill(F_ST6, "Strapping")
            fill(F_SP6, "Grade304 BandIt"); fill(F_DM6, "19*0,5mm"); fill(F_FN5, 4)
            fill(F_T7, "Attachment"); fill(F_ST7, "Buckle")
            fill(F_SP7, "Grade304 BandIt"); fill(F_DM7, "19mm"); fill(F_FN6, 2)

            # dim2 default — only if still null (never overwrites a manual 120/140)
            fill(F_DIM2, "140-160mm")
            # lat/lon — only if null
            if is_null(f.attribute(F_LAT)):
                fill(F_LAT, round(pt.y(), 6))
            if is_null(f.attribute(F_LON)):
                fill(F_LON, round(pt.x(), 6))

        # Drop empty update dicts
        updates = {k: v for k, v in updates.items() if v}
        if updates:
            self._write_attrs(updates)

    def _mark_rc(self):
        feats = self.lyr.selectedFeatures()
        if not feats:
            self._set_status('No poles selected — click a pole first.', '#f59e0b')
            return
        attr_map = {}
        skipped = 0
        for f in feats:
            cur = str(f[self.ti_thickness]).strip()
            self._not_rc_geoms.pop(f.id(), None)
            if 'road crossing' in cur.lower():
                skipped += 1
                continue
            new_val = (cur + '; road crossing') if cur not in ('', 'NULL', 'None') else 'road crossing'
            attr_map[f.id()] = {self.ti_thickness: new_val}
        if attr_map:
            self._write_attrs(attr_map)
            self._auto_populate_new([f.id() for f in feats])
            self.lyr.triggerRepaint()
        self._redraw_bands()
        msg = f'Marked {len(attr_map)} as road crossing'
        if skipped:
            msg += f'  ({skipped} already flagged)'
        self._set_status(msg, '#22c55e')

    def _unmark_rc(self):
        feats = self.lyr.selectedFeatures()
        if not feats:
            self._set_status('No poles selected — click a pole first.', '#f59e0b')
            return
        attr_map = {}
        skipped = 0
        for f in feats:
            cur = str(f[self.ti_thickness]).strip()
            if 'road crossing' not in cur.lower():
                skipped += 1
                continue
            new_val = (cur
                       .replace('; road crossing', '')
                       .replace('road crossing; ', '')
                       .replace('road crossing', '')
                       .strip().strip(';').strip())
            attr_map[f.id()] = {self.ti_thickness: new_val if new_val.lower() not in ('', 'null', 'none') else None}
            if f.geometry() and not f.geometry().isEmpty():
                self._not_rc_geoms[f.id()] = f.geometry()
        if attr_map:
            self._write_attrs(attr_map)
            self._auto_populate_new([f.id() for f in feats])
            self.lyr.triggerRepaint()
        self._redraw_bands()
        msg = f'Removed road crossing from {len(attr_map)} poles'
        if skipped:
            msg += f'  ({skipped} not flagged)'
        self._set_status(msg, '#ef4444')

    def _ensure_committed(self):
        """If the layer is in an edit session with pending changes, ask the
        user before committing. dataProvider().changeAttributeValues can't see
        uncommitted features (negative fids) so we need them flushed first."""
        if not self.lyr.isEditable():
            return True
        buf = self.lyr.editBuffer()
        if buf is None:
            # Editable but nothing pending — safe to leave as-is
            return True
        pending_add = len(buf.addedFeatures()) if hasattr(buf, "addedFeatures") else 0
        pending_chg = len(buf.changedAttributeValues()) if hasattr(buf, "changedAttributeValues") else 0
        pending_geo = len(buf.changedGeometries()) if hasattr(buf, "changedGeometries") else 0
        pending_del = len(buf.deletedFeatureIds()) if hasattr(buf, "deletedFeatureIds") else 0
        total = pending_add + pending_chg + pending_geo + pending_del
        if total == 0:
            return True

        from qgis.PyQt.QtWidgets import QMessageBox
        reply = QMessageBox.question(
            self, "Commit pending edits?",
            f"The poles layer has unsaved edits:\n"
            f"  • {pending_add} new pole(s)\n"
            f"  • {pending_chg} attribute change(s)\n"
            f"  • {pending_geo} geometry change(s)\n"
            f"  • {pending_del} deletion(s)\n\n"
            "The Pole Editor needs these saved before it can tag the new\n"
            "pole(s). Commit now and continue?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.Yes)
        if reply != QMessageBox.StandardButton.Yes:
            self._set_status("Cancelled — commit your edits first.", "#f59e0b")
            return False
        ok = self.lyr.commitChanges()
        if not ok:
            err = "; ".join(self.lyr.commitErrors()[:3])
            self._set_status(f"Commit failed: {err}", "#ef4444")
            return False
        # Reopen edit session so user can keep drawing without losing mode
        self.lyr.startEditing()
        return True

    def _make_thick(self):
        feats = self.lyr.selectedFeatures()
        if not feats:
            self._set_status('No poles selected — click a pole first.', '#f59e0b')
            return
        attr_map = {}
        skipped = 0
        for f in feats:
            if str(f['dim2']) == '140-160mm':
                skipped += 1
                continue
            cur = str(f[self.ti_thickness]).strip()
            new_thick = (cur + '; manual override') if cur not in ('', 'NULL', 'None') else 'manual override'
            attr_map[f.id()] = {self.ti_dim2: '140-160mm', self.ti_thickness: new_thick}
        if attr_map:
            self._write_attrs(attr_map)
            self._auto_populate_new([f.id() for f in feats])
            self.lyr.triggerRepaint()
        self._redraw_bands()
        msg = f'Upgraded {len(attr_map)} to 140-160mm'
        if skipped:
            msg += f'  ({skipped} already thick)'
        self._set_status(msg, '#3b82f6')

    def _make_thin(self):
        feats = self.lyr.selectedFeatures()
        if not feats:
            self._set_status('No poles selected — click a pole first.', '#f59e0b')
            return
        attr_map = {}
        skipped = 0
        for f in feats:
            if str(f['dim2']) == '120-140mm':
                skipped += 1
                continue
            cur = str(f[self.ti_thickness]).strip()
            new_thick = (cur + '; manual override') if cur not in ('', 'NULL', 'None') else 'manual override'
            attr_map[f.id()] = {self.ti_dim2: '120-140mm', self.ti_thickness: new_thick}
        if attr_map:
            self._write_attrs(attr_map)
            self._auto_populate_new([f.id() for f in feats])
            self.lyr.triggerRepaint()
        self._redraw_bands()
        msg = f'Downgraded {len(attr_map)} to 120-140mm'
        if skipped:
            msg += f'  ({skipped} already thin)'
        self._set_status(msg, '#94a3b8')

    def _mark_s5(self):
        """Write canonical S5 Slack Bracket values to selected poles.
        Canonical values from PH2 live scan 2026-04-17: see
        project_s5_slack_bracket_decision.md."""
        feats = self.lyr.selectedFeatures()
        if not feats:
            self._set_status('No poles selected — click a pole first.', '#f59e0b')
            return
        if min(self.ti_t5, self.ti_st5, self.ti_sp5, self.ti_d5) < 0:
            self._set_status(
                'S5 fields missing (type_5 / subtype5 / spec_5 / dim1_5). '
                'Cannot write.', '#ef4444')
            return
        attr_map = {}
        skipped = 0
        for f in feats:
            if str(f['type_5']).strip() == 'Slack Bracket':
                skipped += 1
                continue
            row = {
                self.ti_t5:  'Slack Bracket',
                self.ti_st5: 'Bracket',
                self.ti_sp5: 'Extreme Slack',
                self.ti_d5:  'D620',
            }
            # dim2_5 'D516' confirmed against PH1 (4633 live examples, 2026-04-28)
            if self.ti_d5_2 >= 0:
                row[self.ti_d5_2] = 'D516'
            attr_map[f.id()] = row
        if attr_map:
            self._write_attrs(attr_map)
            self.lyr.triggerRepaint()
        self._redraw_bands()
        msg = f'Added Slack Bracket (S5) to {len(attr_map)} poles'
        if skipped:
            msg += f'  ({skipped} already had S5)'
        self._set_status(msg, '#7c3aed')

    def _unmark_s5(self):
        feats = self.lyr.selectedFeatures()
        if not feats:
            self._set_status('No poles selected — click a pole first.', '#f59e0b')
            return
        if min(self.ti_t5, self.ti_st5, self.ti_sp5, self.ti_d5) < 0:
            self._set_status(
                'S5 fields missing (type_5 / subtype5 / spec_5 / dim1_5). '
                'Cannot write.', '#ef4444')
            return
        attr_map = {}
        skipped = 0
        for f in feats:
            if str(f['type_5']).strip() != 'Slack Bracket':
                skipped += 1
                continue
            row = {
                self.ti_t5:  None,
                self.ti_st5: None,
                self.ti_sp5: None,
                self.ti_d5:  None,
            }
            if self.ti_d5_2 >= 0:
                row[self.ti_d5_2] = None
            attr_map[f.id()] = row
        if attr_map:
            self._write_attrs(attr_map)
            self.lyr.triggerRepaint()
        self._redraw_bands()
        msg = f'Removed Slack Bracket (S5) from {len(attr_map)} poles'
        if skipped:
            msg += f'  ({skipped} had no S5)'
        self._set_status(msg, '#94a3b8')

    def _snap_to_canvas_topleft(self):
        canvas = self.iface.mapCanvas()
        top_left = canvas.viewport().mapToGlobal(canvas.viewport().rect().topLeft())
        self.move(top_left.x() + 8, top_left.y() + 8)

    def _refresh_all_incomplete(self):
        """Auto-populate all poles that still have null Label / Pole Type /
        hardware / dim2 / lat / lon. Never overrides existing non-null values,
        so manual marks (road crossing, thick, thin, Tangent exceptions, S5)
        stay untouched."""
        try:
            fids = [f.id() for f in self.lyr.getFeatures()]
            self._auto_populate_new(fids)
        except Exception as e:
            print(f"[PoleEditor] auto-refresh skipped: {e}")

    def showEvent(self, event):
        super().showEvent(event)
        QTimer.singleShot(0, self._snap_to_canvas_topleft)
        # Fill in attrs on any new/incomplete poles when the panel opens
        QTimer.singleShot(50, self._refresh_all_incomplete)

    def eventFilter(self, obj, event):
        if event.type() in (QEvent.Type.Resize, QEvent.Type.Move, QEvent.Type.Show):
            QTimer.singleShot(0, self._snap_to_canvas_topleft)
        return super().eventFilter(obj, event)

    def _teardown(self):
        """Finalize + clean up: run a last auto-populate pass, drop the canvas event
        filters, and stop/remove the rings + bands. Called when the host dock closes
        (or on unload). Idempotent + sip-guarded so it's safe to call more than once."""
        if getattr(self, '_torn_down', False):
            return
        self._torn_down = True
        from qgis.PyQt import sip
        try:
            self._refresh_all_incomplete()       # final auto-populate of marked poles
        except Exception:
            _swallowed_note()
        try:
            canvas = self.iface.mapCanvas()
            if sip.isdeleted(canvas):
                return
            canvas.removeEventFilter(self)
            canvas.viewport().removeEventFilter(self)
            scene = canvas.scene()
            for ring in (self._blue_band, self._yellow_band, self._red_band):
                ring.stop(); ring.clear()
                if scene is not None and isinstance(ring, QgsMapCanvasItem):
                    scene.removeItem(ring)
            self._fts_band.reset()
            self._s5_band.reset()
        except Exception:
            _swallowed_note()

    def closeEvent(self, event):
        self._teardown()
        super().closeEvent(event)


# ── Enclosure Editor panel ────────────────────────────────────────────────────
# claude:approved-destructive — writes only on explicit user button clicks; no bulk auto-run

class EnclosureEditorPanel(QWidget):
    """Floating panel for reclassifying enclosures on the canvas.

    Reads selected features from:
      - Enclosures Connectorised v1  (Distribution vs Spur Route)
      - Enclosures Splice v1         (UMJ/72F vs CMJ/144F)

    Use QGIS Select Features tool (S key) to click enclosures on the map,
    then click a type button to apply the canonical spec values.
    """

    _CONN_SPECS = {
        'distribution': {'spec_1': 'ODCFD0',       'cblcpty1': '24F', 'dim1': 'L220*W120*H73mm'},
        'spur':         {'spec_1': 'M16 Microloop', 'cblcpty1': '48F', 'dim1': 'H275*W160*D96mm'},
    }
    _SPLICE_SPECS = {
        'umj': {'spec_1': 'UMJ', 'cblcpty1': '72F',  'dim1': 'L250*W231*D164mm'},
        'cmj': {'spec_1': 'CMJ', 'cblcpty1': '144F', 'dim1': 'L290*W231*D164mm'},
    }

    def __init__(self, iface, parent=None):
        super().__init__(parent)                 # hosted in a _PanelDock (dockable)
        self.setObjectName('vfEncEditorPanel')
        self.iface = iface
        self.setWindowTitle('Enclosure Editor')
        self.setMinimumWidth(380)

        canvas = iface.mapCanvas()
        self._dist_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PointGeometry)
        self._dist_band.setColor(QColor(234, 115, 32, 210))
        self._dist_band.setIcon(QgsRubberBand.IconType.ICON_FULL_DIAMOND)
        self._dist_band.setIconSize(11)

        self._spur_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PointGeometry)
        self._spur_band.setColor(QColor(147, 51, 234, 210))
        self._spur_band.setIcon(QgsRubberBand.IconType.ICON_BOX)
        self._spur_band.setIconSize(13)

        self._umj_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PointGeometry)
        self._umj_band.setColor(QColor(8, 145, 178, 210))
        self._umj_band.setIcon(QgsRubberBand.IconType.ICON_CIRCLE)
        self._umj_band.setIconSize(11)

        self._cmj_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PointGeometry)
        self._cmj_band.setColor(QColor(34, 197, 94, 210))
        self._cmj_band.setIcon(QgsRubberBand.IconType.ICON_CIRCLE)
        self._cmj_band.setIconSize(13)

        # Cable route highlights — line rubber bands over Distribution Cable v1
        self._main_cable_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.LineGeometry)
        self._main_cable_band.setColor(QColor(56, 189, 248, 170))   # sky blue
        self._main_cable_band.setWidth(4)

        self._spur_cable_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.LineGeometry)
        self._spur_cable_band.setColor(QColor(234, 115, 32, 220))    # orange
        self._spur_cable_band.setWidth(4)

        # FTS splitter locations — large bright green diamonds
        self._fts_enc_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PointGeometry)
        self._fts_enc_band.setColor(QColor(34, 197, 94, 240))       # bright green fill
        self._fts_enc_band.setIcon(QgsRubberBand.IconType.ICON_FULL_DIAMOND)
        self._fts_enc_band.setIconSize(20)
        self._fts_enc_band.setWidth(4)                               # outline width
        self._fts_enc_band.setSecondaryStrokeColor(QColor(0, 60, 0, 255))  # dark border

        self._redraw_bands()
        self._redraw_cable_bands()

        canvas.installEventFilter(self)
        canvas.viewport().installEventFilter(self)

        self.setStyleSheet(f"QWidget#vfEncEditorPanel {{ background: {_BG}; }}")
        layout = QVBoxLayout(self)
        layout.setSpacing(8)
        layout.setContentsMargins(12, 12, 12, 12)

        # ── How to use ─────────────────────────────────────────────────────
        steps_frame = QFrame()
        steps_frame.setStyleSheet(
            f"QFrame {{ background: {_PANEL}; border-radius: 6px;"
            f" border: 1px solid {_BORDER}; }}")
        sl = QVBoxLayout(steps_frame)
        sl.setContentsMargins(10, 8, 10, 8)
        sl.setSpacing(3)
        how_lbl = QLabel("HOW TO USE")
        how_lbl.setStyleSheet(_SECTION_LBL)
        sl.addWidget(how_lbl)
        _step_ss = (f"QLabel {{ color: {_TEXT}; font-family: 'Segoe UI';"
                    f" font-size: 10px; }}")
        for step in (
            "1  Press S key, then click an enclosure on the map",
            "2  Shift+click to add more enclosures to the selection",
            "3  Click the correct type button below",
        ):
            lbl = QLabel(step)
            lbl.setStyleSheet(_step_ss)
            sl.addWidget(lbl)

        div = QFrame()
        div.setFrameShape(QFrame.Shape.HLine)
        div.setStyleSheet(f"QFrame {{ color: {_BORDER}; margin-top: 4px; }}")
        sl.addWidget(div)

        ovr_hdr = QLabel("CANVAS OVERLAY — Distribution cables")
        ovr_hdr.setStyleSheet(_SECTION_LBL)
        sl.addWidget(ovr_hdr)
        _ovr_ss = (f"QLabel {{ color: {_TEXT}; font-family: 'Segoe UI'; font-size: 9px; }}")
        for col, sym, desc in (
            ("#38bdf8", "━━━", "Main distribution route"),
            ("#ea7320", "━━━", "Spur cable (branches off main)"),
        ):
            row_lbl = QLabel(
                f'<span style="color:{col}; font-weight:900; font-size:13px">{sym}</span>'
                f'  {desc}')
            row_lbl.setStyleSheet(_ovr_ss)
            sl.addWidget(row_lbl)
        layout.addWidget(steps_frame)

        # ── Connectorised section ───────────────────────────────────────────
        _hdr_ss = (f"QLabel {{ color: {_TEXT}; font-family: 'Segoe UI';"
                   f" font-size: 10px; font-weight: 700; padding-top: 4px; }}")
        conn_hdr = QLabel(
            '<span style="color:#ea7320">◆</span>'
            ' <span style="color:#9333ea">■</span>'
            '  CONNECTORISED  —  Enclosures Connectorised v1')
        conn_hdr.setStyleSheet(_hdr_ss)
        layout.addWidget(conn_hdr)

        conn_leg = QLabel(
            '<span style="color:#ea7320">◆ orange diamond</span>'
            '  = Distribution   '
            '<span style="color:#9333ea">■ purple square</span>'
            '  = Spur Route')
        conn_leg.setStyleSheet(
            f"QLabel {{ color: {_DIM}; font-family: 'Segoe UI'; font-size: 9px; }}")
        layout.addWidget(conn_leg)

        def _tall_btn(base, extra=''):
            return (base.replace('min-height: 32px', 'min-height: 60px')
                       .replace('font-size: 11px', 'font-size: 10px') + extra)

        conn_row = QHBoxLayout()
        conn_row.setSpacing(8)
        btn_dist = QPushButton(
            '◆  DISTRIBUTION\nODCFD0  ·  24F  ·  6-8 drops\nAlong main distribution route')
        btn_dist.setStyleSheet(_tall_btn(_BTN_ORANGE))
        btn_dist.clicked.connect(self._set_distribution)
        conn_row.addWidget(btn_dist)
        btn_spur = QPushButton(
            '■  SPUR ROUTE\nM16 Microloop  ·  48F  ·  16 drops\nAt cable branch-off point only')
        btn_spur.setStyleSheet(_tall_btn(_BTN_PURPLE))
        btn_spur.clicked.connect(self._set_spur)
        conn_row.addWidget(btn_spur)
        layout.addLayout(conn_row)

        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet(_DIVIDER)
        layout.addWidget(line)

        # ── Splice section ──────────────────────────────────────────────────
        splice_hdr = QLabel(
            '<span style="color:#0891b2">●</span>'
            ' <span style="color:#22c55e">●</span>'
            '  SPLICE  —  Enclosures Splice v1  (feeder domes)')
        splice_hdr.setStyleSheet(_hdr_ss)
        layout.addWidget(splice_hdr)

        splice_leg = QLabel(
            '<span style="color:#0891b2">● cyan circle</span>'
            '  = Secondary feeder   '
            '<span style="color:#22c55e">● green circle</span>'
            '  = Primary feeder')
        splice_leg.setStyleSheet(
            f"QLabel {{ color: {_DIM}; font-family: 'Segoe UI'; font-size: 9px; }}")
        layout.addWidget(splice_leg)

        splice_row = QHBoxLayout()
        splice_row.setSpacing(8)
        btn_umj = QPushButton(
            '●  UMJ\n72F  ·  Secondary feeder\nAt secondary cable splice points')
        btn_umj.setStyleSheet(_tall_btn(_BTN_CYAN))
        btn_umj.clicked.connect(self._set_umj)
        splice_row.addWidget(btn_umj)
        btn_cmj = QPushButton(
            '●  CMJ\n144F  ·  Primary feeder\nAt primary cable splice points')
        btn_cmj.setStyleSheet(_tall_btn(_BTN_TEAL))
        btn_cmj.clicked.connect(self._set_cmj)
        splice_row.addWidget(btn_cmj)
        layout.addLayout(splice_row)

        # ── Summary + status ────────────────────────────────────────────────
        self._status_lbl = QLabel('')
        self._status_lbl.setWordWrap(True)
        self._status_lbl.setStyleSheet(_STATUS_LBL)
        layout.addWidget(self._status_lbl)

        self._summary_lbl = QLabel('')
        self._summary_lbl.setStyleSheet(_HINT_LBL)
        layout.addWidget(self._summary_lbl)

        self._update_summary()

    def _get_conn_lyr(self):
        return next((l for l in QgsProject.instance().mapLayers().values()
                     if l.name() == 'Enclosures Connectorised v1'), None)

    def _get_splice_lyr(self):
        return next((l for l in QgsProject.instance().mapLayers().values()
                     if l.name() == 'Enclosures Splice v1'), None)

    def _redraw_bands(self):
        conn_lyr   = self._get_conn_lyr()
        splice_lyr = self._get_splice_lyr()
        for band in (self._dist_band, self._spur_band,
                     self._umj_band, self._cmj_band,
                     self._fts_enc_band):
            band.reset(QgsWkbTypes.GeometryType.PointGeometry)
        fts_lyr = next((l for l in QgsProject.instance().mapLayers().values()
                        if l.name() == 'FTS Splitters v1'), None)
        if fts_lyr:
            for f in fts_lyr.getFeatures():
                g = f.geometry()
                if g and not g.isEmpty():
                    self._fts_enc_band.addGeometry(g, None)
        if conn_lyr:
            for f in conn_lyr.getFeatures():
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                if str(f['spec_1']) == 'M16 Microloop':
                    self._spur_band.addGeometry(g, None)
                else:
                    self._dist_band.addGeometry(g, None)
        if splice_lyr:
            for f in splice_lyr.getFeatures():
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                if str(f['spec_1']) == 'CMJ':
                    self._cmj_band.addGeometry(g, None)
                else:
                    self._umj_band.addGeometry(g, None)

    def _set_status(self, msg, colour='#e2e8f0'):
        self._status_lbl.setText(msg)
        self._status_lbl.setStyleSheet(
            f"QLabel {{ color: {colour}; font-family: Consolas; "
            f"font-size: 10px; padding: 2px; }}"
        )

    def _update_summary(self):
        parts = []
        conn_lyr = self._get_conn_lyr()
        if conn_lyr:
            feats  = list(conn_lyr.getFeatures())
            n_spur = sum(1 for f in feats if str(f['spec_1']) == 'M16 Microloop')
            parts.append(f'Conn: {len(feats) - n_spur} dist  {n_spur} spur')
        splice_lyr = self._get_splice_lyr()
        if splice_lyr:
            feats = list(splice_lyr.getFeatures())
            n_cmj = sum(1 for f in feats if str(f['spec_1']) == 'CMJ')
            parts.append(f'Splice: {len(feats) - n_cmj} UMJ  {n_cmj} CMJ')
        self._summary_lbl.setText('  |  '.join(parts))

    def _write_attrs(self, lyr, spec_vals):
        """Bulk-write spec_vals to all selected features in lyr."""
        if not lyr:
            return 0
        feats = lyr.selectedFeatures()
        if not feats:
            return 0
        flds    = lyr.fields()
        indices = {k: flds.indexOf(k) for k in spec_vals}
        writes  = {}
        for f in feats:
            row = {indices[k]: v for k, v in spec_vals.items() if indices[k] >= 0}
            if row:
                writes[f.id()] = row
        if writes:
            lyr.dataProvider().changeAttributeValues(writes)
            lyr.triggerRepaint()
        return len(writes)

    def _set_distribution(self):
        n = self._write_attrs(self._get_conn_lyr(), self._CONN_SPECS['distribution'])
        if n:
            self._redraw_bands(); self._update_summary()
            self._set_status(f'Changed {n}  Distribution (ODCFD0 / 24F)', '#ea7320')
        else:
            self._set_status(
                'No Connectorised enclosures selected.\n'
                'Use S key + click an orange/purple dot.', '#f59e0b')

    def _set_spur(self):
        n = self._write_attrs(self._get_conn_lyr(), self._CONN_SPECS['spur'])
        if n:
            self._redraw_bands(); self._update_summary()
            self._set_status(
                f'Changed {n}  Spur Route (M16 Microloop / 48F)', '#9333ea')
        else:
            self._set_status(
                'No Connectorised enclosures selected.\n'
                'Use S key + click an orange/purple dot.', '#f59e0b')

    def _set_umj(self):
        n = self._write_attrs(self._get_splice_lyr(), self._SPLICE_SPECS['umj'])
        if n:
            self._redraw_bands(); self._update_summary()
            self._set_status(f'Changed {n}  UMJ / 72F  (Secondary feeder)', '#0891b2')
        else:
            self._set_status(
                'No Splice enclosures selected.\n'
                'Use S key + click a cyan/green dot.', '#f59e0b')

    def _set_cmj(self):
        n = self._write_attrs(self._get_splice_lyr(), self._SPLICE_SPECS['cmj'])
        if n:
            self._redraw_bands(); self._update_summary()
            self._set_status(f'Changed {n}  CMJ / 144F  (Primary feeder)', '#22c55e')
        else:
            self._set_status(
                'No Splice enclosures selected.\n'
                'Use S key + click a cyan/green dot.', '#f59e0b')

    def _snap_to_canvas_topleft(self):
        canvas = self.iface.mapCanvas()
        tl = canvas.viewport().mapToGlobal(canvas.viewport().rect().topLeft())
        self.move(tl.x() + 8, tl.y() + 8)

    def showEvent(self, event):
        super().showEvent(event)
        QTimer.singleShot(0, self._snap_to_canvas_topleft)

    def eventFilter(self, obj, event):
        if event.type() in (QEvent.Type.Resize, QEvent.Type.Move, QEvent.Type.Show):
            QTimer.singleShot(0, self._snap_to_canvas_topleft)
        return super().eventFilter(obj, event)

    def _get_dist_lyr(self):
        return next((l for l in QgsProject.instance().mapLayers().values()
                     if l.name() == 'Distribution Cable v1'), None)

    def _classify_cables(self):
        """Return (main_fids, spur_fids) for Distribution Cable v1.

        Algorithm:
          1. Seed: cables whose endpoint is within FTS_SNAP of an FTS Splitter v1
          2. Network BFS: expand through connected cables (endpoints within VERTEX_SNAP)
             - Only propagate along a cable if its far end has degree >= 2 (not a dead-end)
             - If both ends of a cable are already visited (loop), always add as main
          3. Main = everything reachable; Spur = unreachable dead-end branches
        """
        from qgis.core import QgsPointXY, QgsGeometry
        dist_lyr = self._get_dist_lyr()
        fts_lyr  = next((l for l in QgsProject.instance().mapLayers().values()
                         if l.name() == 'FTS Splitters v1'), None)
        if not dist_lyr:
            return set(), set()

        FTS_SNAP    = 12.0 / 111320.0  # 12 m — cable endpoint at FTS pole
        VERTEX_SNAP = 6.0  / 111320.0  # 6 m  — shared cable endpoint (connected)

        # --- collect cable endpoints ---
        cable_pts = {}   # fid -> (start_QgsPointXY, end_QgsPointXY)
        for cable in dist_lyr.getFeatures():
            g = cable.geometry()
            if not g or g.isEmpty():
                continue
            verts = (g.asPolyline() if not g.isMultipart()
                     else [v for part in g.asMultiPolyline() for v in part])
            if len(verts) < 2:
                continue
            cable_pts[cable.id()] = (QgsPointXY(verts[0]), QgsPointXY(verts[-1]))

        # No FTS Splitters layer → we have no seed for the backbone walk. Without
        # this guard near_fts() is always False, no cable is seeded, and EVERY
        # cable would be mis-classified as a spur. Safe fallback: treat all as main.
        if fts_lyr is None:
            return set(cable_pts.keys()), set()

        # --- quantize endpoints into node keys ---
        def node_key(pt):
            return (round(pt.x() / VERTEX_SNAP), round(pt.y() / VERTEX_SNAP))

        node_cables = {}   # node_key -> set of fids touching that node
        cable_nodes = {}   # fid -> (node_start, node_end)
        for fid, (s, e) in cable_pts.items():
            ns, ne = node_key(s), node_key(e)
            cable_nodes[fid] = (ns, ne)
            node_cables.setdefault(ns, set()).add(fid)
            node_cables.setdefault(ne, set()).add(fid)

        # --- find FTS-attached nodes ---
        fts_geoms = []
        if fts_lyr:
            for f in fts_lyr.getFeatures():
                if f.hasGeometry():
                    fts_geoms.append(f.geometry())

        def near_fts(pt):
            g = QgsGeometry.fromPointXY(pt)
            return any(g.distance(fg) <= FTS_SNAP for fg in fts_geoms)

        fts_nodes = set()
        for fid, (s, e) in cable_pts.items():
            ns, ne = cable_nodes[fid]
            if near_fts(s):
                fts_nodes.add(ns)
            if near_fts(e):
                fts_nodes.add(ne)

        # --- seed: cables with an endpoint at an FTS node ---
        main_fids = set()
        visited_nodes = set(fts_nodes)
        for fid, (ns, ne) in cable_nodes.items():
            if ns in fts_nodes or ne in fts_nodes:
                main_fids.add(fid)
                visited_nodes.add(ns)
                visited_nodes.add(ne)

        # --- BFS: propagate main status through the backbone ---
        changed = True
        while changed:
            changed = False
            for fid, (ns, ne) in cable_nodes.items():
                if fid in main_fids:
                    continue
                s_vis = ns in visited_nodes
                e_vis = ne in visited_nodes
                if not s_vis and not e_vis:
                    continue
                if s_vis and e_vis:
                    # Cable connects two already-visited nodes (closes a loop) → main
                    main_fids.add(fid)
                    changed = True
                    continue
                # One end visited, one end not: only extend if far end is not a dead-end
                far_node = ne if s_vis else ns
                if len(node_cables.get(far_node, set())) >= 2:
                    main_fids.add(fid)
                    visited_nodes.add(far_node)
                    changed = True

        spur_fids = set(cable_pts.keys()) - main_fids
        return main_fids, spur_fids

    def _redraw_cable_bands(self):
        self._main_cable_band.reset(QgsWkbTypes.GeometryType.LineGeometry)
        self._spur_cable_band.reset(QgsWkbTypes.GeometryType.LineGeometry)
        dist_lyr = self._get_dist_lyr()
        if not dist_lyr:
            return
        main_fids, spur_fids = self._classify_cables()
        crs = dist_lyr.crs()
        for cable in dist_lyr.getFeatures():
            g = cable.geometry()
            if not g or g.isEmpty():
                continue
            if cable.id() in spur_fids:
                self._spur_cable_band.addGeometry(g, crs)
            else:
                self._main_cable_band.addGeometry(g, crs)

    def _teardown(self):
        """Drop the canvas event filters + reset/remove all rubber bands. Called when
        the host dock closes (or on unload). Idempotent + sip-guarded."""
        if getattr(self, '_torn_down', False):
            return
        self._torn_down = True
        from qgis.PyQt import sip
        try:
            canvas = self.iface.mapCanvas()
            if sip.isdeleted(canvas):
                return
            canvas.removeEventFilter(self)
            canvas.viewport().removeEventFilter(self)
            scene = canvas.scene()
            for band in (self._dist_band, self._spur_band,
                         self._umj_band, self._cmj_band,
                         self._main_cable_band, self._spur_cable_band,
                         self._fts_enc_band):
                band.reset()
                try:
                    scene.removeItem(band)
                except Exception:
                    _swallowed_note()
            # Clear any lingering q.py test rubber bands on the iface namespace
            for b in getattr(self.iface, '_spur_check_bands', []):
                try:
                    b.reset(); scene.removeItem(b)
                except Exception:
                    _swallowed_note()
            self.iface._spur_check_bands = []
            canvas.refresh()
        except Exception:
            _swallowed_note()

    def closeEvent(self, event):
        self._teardown()
        super().closeEvent(event)
