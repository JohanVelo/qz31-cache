"""team_monitor — JJ-only dock: who's installed / online / doing what / errors.

Opens only when admin.is_admin(profile) is True (admin username + admin key).
Reads via Admin (owner key, async). Auto-refreshes every 30 s. Tabs:
  Online · Activity · Errors · Installs · Users
Owner actions: deactivate user, issue reset token, mark error resolved,
broadcast announcement.
"""
import time

from qgis.PyQt.QtCore import QTimer, Qt
from qgis.PyQt.QtWidgets import (QDockWidget, QFrame, QHBoxLayout, QInputDialog,
                                 QLabel, QMessageBox, QPushButton, QTableWidget,
                                 QTableWidgetItem, QTabWidget, QVBoxLayout,
                                 QWidget)

from . import admin as admin_mod


# The counting rules live in monitor_model — no Qt in there, so the invariant
# 'every number shown is len() of the list it sits beside' can be unit-tested
# without building a dock (real widgets under the dev venv mix PyQt5 against
# QGIS's Qt6 and can hang the run behind a hidden modal).
from .monitor_model import (Fetch, count_open_errors, errors_card, group_errors,
                            is_open_ticket, online_users, open_tickets)
from .monitor_model import age as _age

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass


class TeamMonitorDock(QDockWidget):
    def __init__(self, iface, backend):
        super().__init__("🛰  Team Monitor", iface.mainWindow())
        self.setObjectName("VelocityNexusTeamMonitor")
        self.iface = iface
        self.admin = admin_mod.Admin(backend)
        self.dry_run = backend.dry_run
        self._build()
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.refresh)
        self._timer.start(30_000)
        self.refresh()

    # ── UI ──────────────────────────────────────────────────────────────────
    def _build(self):
        root = QWidget()
        root.setStyleSheet(
            "QWidget{background:#0F1A30;color:#EAF0FF;}"
            "QTabWidget::pane{border:1px solid #243352;}"
            "QTabBar::tab{background:#141E36;color:#9FB4C8;padding:6px 12px;"
            "border:1px solid #243352;}"
            "QTabBar::tab:selected{background:#1F2C4C;color:#fff;}"
            "QTableWidget{background:#0F1A30;gridline-color:#243352;"
            "color:#EAF0FF;}"
            "QHeaderView::section{background:#141E36;color:#9FB4C8;"
            "border:0;padding:4px;}"
            "QPushButton{background:#2ec4f1;color:#06121c;border:none;"
            "border-radius:6px;padding:6px 12px;font-weight:700;}"
            "QPushButton:hover{background:#5fd6ff;}"
            "QLabel#status{color:#9FB4C8;font-size:10px;}"
            "QLabel#kpi{background:#141E36;border:1px solid #243352;"
            "border-radius:7px;padding:8px 11px;font-size:12px;}"
            # hero health banner — border colour tracks state
            "QFrame#healthBanner{background:#141E36;border:2px solid #2ABFCC;"
            "border-radius:8px;}"
            "QFrame#healthBanner[state=\"warn\"]{border:2px solid #E0B23B;}"
            "QFrame#healthBanner[state=\"error\"]{border:2px solid #E0607A;}"
            "QLabel#healthTitle{font-size:13px;font-weight:800;color:#EAF0FF;}"
            "QLabel#healthDetail{font-size:10px;color:#9FB4C8;}"
            # 4-card KPI strip
            "QFrame#kpiCard{background:#141E36;border:1px solid #243352;"
            "border-radius:7px;}"
            "QFrame#kpiCard:hover{border:1px solid #2EC4F1;}"
            "QLabel#kpiCap{font-size:9px;font-weight:700;color:#6E7FA6;}")
        v = QVBoxLayout(root)
        v.setContentsMargins(8, 8, 8, 8)
        v.setSpacing(6)

        topbar = QHBoxLayout()
        self._status = QLabel("…")
        self._status.setObjectName("status")
        topbar.addWidget(self._status)
        topbar.addStretch(1)
        announce = QPushButton("📢  Announce")
        announce.clicked.connect(self._announce)
        topbar.addWidget(announce)
        refresh = QPushButton("⟳")
        refresh.setFixedWidth(34)
        refresh.clicked.connect(self.refresh)
        topbar.addWidget(refresh)
        v.addLayout(topbar)

        # Hero health banner + 4-card KPI strip — scannable at a glance
        self._banner = _HealthBanner()
        v.addWidget(self._banner)

        kpi_row = QHBoxLayout()
        kpi_row.setSpacing(8)
        self._kpi_online   = _KPICard("ONLINE")
        self._kpi_machines = _KPICard("MACHINES")
        self._kpi_errors   = _KPICard("OPEN ERRORS")
        self._kpi_latest   = _KPICard("LATEST")
        for c in (self._kpi_online, self._kpi_machines,
                  self._kpi_errors, self._kpi_latest):
            kpi_row.addWidget(c)
        v.addLayout(kpi_row)
        # errors_ok starts False: nothing has loaded yet, and "no data yet" must
        # not render as "all good". errors_total stays None until the server
        # tells us — None means unknown and is displayed as unknown.
        self._kpi = {"online": 0, "installs": 0, "errors_open": 0,
                     "latest": None, "stale": 0, "errors_ok": False,
                     "errors_total": None, "errors_window": 0}
        self._closeable = []

        self.tabs = QTabWidget()
        self.t_online = self._table(["", "User", "Project", "Tool", "Seen"])
        self.t_activity = self._table(["Time", "User", "Action", "Project"])
        self.t_errors = self._table(["Last seen", "Error", "×", "Who", ""])
        self.t_installs = self._table(["User", "Current version", "QGIS",
                                       "Installed"])
        self.t_users = self._table(["User", "Active", "Since", ""])
        self.t_tickets = self._table(["When", "Type", "Title", "Who", ""])
        # wrap the tickets table with a one-click "Clear resolved" declutter bar
        self._tickets_tab = QWidget()
        _ttl = QVBoxLayout(self._tickets_tab)
        _ttl.setContentsMargins(0, 0, 0, 0)
        _ttl.setSpacing(4)
        _ttbar = QHBoxLayout()
        _ttbar.addStretch(1)
        self._clear_resolved_btn = QPushButton("Clear resolved")
        self._clear_resolved_btn.setToolTip(
            "Archive every resolved ticket — hidden from the list, kept in the DB.")
        self._clear_resolved_btn.clicked.connect(self._clear_resolved)
        _ttbar.addWidget(self._clear_resolved_btn)
        _ttl.addLayout(_ttbar)
        _ttl.addWidget(self.t_tickets)
        self.tabs.addTab(self.t_online, "● Online")
        self.tabs.addTab(self.t_activity, "Activity")
        self.tabs.addTab(self._tickets_tab, "Tickets")
        self.tabs.addTab(self.t_errors, "Errors")
        self.tabs.addTab(self.t_installs, "Installs")
        self.tabs.addTab(self.t_users, "Users")
        v.addWidget(self.tabs)
        self.setWidget(root)

    def _table(self, headers):
        t = QTableWidget(0, len(headers))
        t.setHorizontalHeaderLabels(headers)
        t.verticalHeader().setVisible(False)
        t.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        t.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        t.horizontalHeader().setStretchLastSection(True)
        return t

    # ── refresh ─────────────────────────────────────────────────────────────
    def refresh(self):
        if self.dry_run:
            self._status.setText(
                "Dry-run mode — backend not configured yet. Live data appears "
                "once Supabase is connected.")
            return
        self._status.setText("Refreshing…")
        # housekeeping: prune aged presence heartbeats (throttled to ~5 min) so
        # the events table stays small under the free tier.
        now = time.time()
        if now - getattr(self, "_last_prune", 0) > 300:
            self._last_prune = now
            self.admin.prune_heartbeats()
        # events first → cache latest action per user → then online (so the
        # Online tab can show each person's current project/tool from events).
        self.admin.recent_events(self._on_events)
        self.admin.recent_errors(self._fill_errors)
        self.admin.installs(self._fill_installs)
        self.admin.users(self._fill_users)
        self.admin.tickets(self._fill_tickets)

    def _on_events(self, rows):
        rows = rows or []
        self._fill_activity(rows)
        latest = {}
        for r in rows:                      # rows are inserted_at desc → 1st wins
            u = r.get("username")
            if u and u not in latest:
                latest[u] = r
        self._latest_by_user = latest
        self.admin.online_now(self._fill_online)

    def _notice(self, table, text, colour):
        """One full-width message row (empty state or failure) — never a blank
        panel, which reads as 'nothing wrong' when it may mean 'never loaded'."""
        table.insertRow(0)
        it = QTableWidgetItem(text)
        it.setForeground(_qcolor(colour))
        table.setItem(0, 0, it)
        table.setSpan(0, 0, 1, table.columnCount())

    def _set_rows(self, table, fetch, render, empty_msg=None):
        """Render `fetch` and RETURN how many data rows were actually drawn.

        Every count the panel displays is taken from this return value, so a
        counter can never disagree with the list beside it — that was the whole
        bug: the KPI strip and the tabs were fed by different queries and were
        free to tell different stories.

        Three distinct outcomes, three distinct renderings:
          failed  -> a red row saying why (returns 0, but the tab shows "—")
          empty   -> the caller's empty message
          loaded  -> the rows
        """
        table.setRowCount(0)
        if not isinstance(fetch, Fetch):        # tolerate a bare list
            fetch = Fetch.of(fetch)
        if not fetch.ok:
            self._notice(table, "⚠  " + (fetch.reason or "Could not load."),
                         "#E0607A")
            return 0
        if not fetch.rows:
            if empty_msg:
                self._notice(table, "   " + empty_msg, "#6E7FA6")
            return 0
        for r in fetch.rows:
            i = table.rowCount()
            table.insertRow(i)
            render(table, i, r)
        return table.rowCount()

    def _set_tab_count(self, widget, base, n, ok=True, suffix=""):
        """Label a tab with the number of rows RENDERED in it (or '—' when the
        fetch failed, so a load failure never reads as a real zero)."""
        try:
            idx = self.tabs.indexOf(widget)
            if idx < 0:
                return
            if not ok:
                self.tabs.setTabText(idx, f"{base} (—)")
            elif suffix:
                self.tabs.setTabText(idx, f"{base} ({suffix})")
            else:
                self.tabs.setTabText(idx, f"{base} ({n})" if n else base)
        except RuntimeError:
            pass

    def _update_summary(self):
        """Drive the hero banner + 4 KPI cards from the latest fetched counts."""
        k = self._kpi
        errs_known = k.get("errors_ok", False)
        # Hero banner — worst-state-wins. "Could not load" outranks everything:
        # an unreachable backend must never be summarised as "All good".
        if not errs_known:
            self._banner.set_state(
                "warn", "Can't reach the team database",
                f"Showing nothing rather than guessing · "
                f"last tried {time.strftime('%H:%M')}")
        elif k["errors_open"] > 0:
            self._banner.set_state(
                "error", "Needs attention",
                f"{k['errors_open']} open error"
                f"{'s' if k['errors_open'] != 1 else ''} "
                f"in the newest {k.get('errors_window', 0)} · "
                f"updated {time.strftime('%H:%M')}")
        elif k["stale"] > 0:
            self._banner.set_state(
                "warn", "Needs a look",
                f"{k['stale']} machine{'s' if k['stale'] != 1 else ''} on an "
                f"old version · updated {time.strftime('%H:%M')}")
        else:
            self._banner.set_state(
                "ok", "All good",
                f"No open errors · all up to date · "
                f"updated {time.strftime('%H:%M')}")
        # KPI cards — colour tracks state so the row reads at a glance
        self._kpi_online.set_value(
            k["online"], "#2ABFCC" if k["online"] else "#6E7FA6",
            hint=None if k["online"] else
            "Nobody is running the plugin right now — this counts live "
            "heartbeats, so it is 0 outside working hours.")
        self._kpi_machines.set_value(
            k["installs"], "#EAF0FF",
            hint=None if k["installs"] else
            "No machine has checked in yet — a teammate installing the plugin "
            "registers here automatically.")
        # OPEN ERRORS is a WINDOW, not a total — say so on the card. It used to
        # print the count of a list capped at the fetch limit, so it read a flat
        # "40" while the table actually held 6,906 rows and could never change.
        text, known = errors_card(k)
        n = k["errors_open"]
        self._kpi_errors.set_value(
            text,
            "#6E7FA6" if not known else
            "#E0607A" if n >= 5 else "#E0B23B" if n else "#2ABFCC")
        self._kpi_latest.set_value(
            f"v{k['latest']}" if k["latest"] else "—",
            "#E0B23B" if k["stale"] else "#2ABFCC",
            hint=None if k["latest"] else
            "No version seen yet — this reports the newest plugin version any "
            "teammate is actually running, so it fills in once someone is online.")

    def _fill_online(self, rows):
        latest = getattr(self, "_latest_by_user", {})
        res = Fetch.of(rows)
        online = online_users(res.rows) if res.ok else []
        self._status.setText(
            f"⚠ Could not reach the team database · last tried "
            f"{time.strftime('%H:%M')}" if not res.ok else
            f"{len(online)} online · updated {time.strftime('%H:%M')}")

        def _vt(v):
            try:
                return tuple(int(x) for x in str(v).split("."))
            except Exception:
                return ()
        vers = [r.get("plugin_version") for r in online if r.get("plugin_version")]
        lat = max(vers, key=_vt) if vers else self._kpi.get("latest")
        if lat:
            self._kpi["latest"] = lat
            self._kpi["stale"] = sum(1 for v in vers if _vt(v) < _vt(lat))
        # NOTE: the ONLINE count is set AFTER rendering, from the row count the
        # table actually drew — see below. Setting it here from a separate list
        # is how the card and the list were free to disagree.

        def render(t, i, r):
            u = r.get("username", "")
            ev = latest.get(u, {})
            dot = QTableWidgetItem("●")
            dot.setForeground(_qcolor("#2ABFCC"))
            t.setItem(i, 0, dot)
            t.setItem(i, 1, QTableWidgetItem(u))
            t.setItem(i, 2, QTableWidgetItem(
                ev.get("project_name") or r.get("project_name") or "—"))
            t.setItem(i, 3, QTableWidgetItem(ev.get("action_id") or "—"))
            t.setItem(i, 4, QTableWidgetItem(_age(r.get("inserted_at", ""))))
        # The ONLINE card and this list are now the same list, counted once.
        n = self._set_rows(self.t_online, res.replace(online), render,
                           empty_msg="No one is online right now.")
        self._kpi["online"] = n
        self._set_tab_count(self.t_online, "● Online", n, res.ok)
        self._update_summary()

    def _fill_activity(self, rows):
        res = Fetch.of(rows)

        def render(t, i, r):
            t.setItem(i, 0, QTableWidgetItem(_age(r.get("inserted_at", ""))))
            t.setItem(i, 1, QTableWidgetItem(r.get("username", "")))
            t.setItem(i, 2, QTableWidgetItem(r.get("action_id", "")))
            t.setItem(i, 3, QTableWidgetItem(r.get("project_name") or "—"))
        n = self._set_rows(self.t_activity, res, render,
                           empty_msg="No tool activity recorded yet.")
        self._set_tab_count(self.t_activity, "Activity", n, res.ok)

    def _fill_errors(self, rows):
        res = Fetch.of(rows)
        # Group identical messages → signal, not a flat wall of repeats.
        ordered = group_errors(res.rows) if res.ok else []
        # The card counts UNRESOLVED errors inside the fetched window; the table
        # draws one row per distinct message. Those are different questions, so
        # the card states its window ("N / total") instead of implying a total.
        self._kpi["errors_ok"] = res.ok
        self._kpi["errors_open"] = count_open_errors(res.rows)
        self._kpi["errors_window"] = len(res.rows)

        def render(t, i, g):
            latest = g["rows"][0]
            t.setItem(i, 0, QTableWidgetItem(_age(latest.get("inserted_at", ""))))
            msg = QTableWidgetItem(latest.get("error_message", ""))
            if all(rr.get("resolved") for rr in g["rows"]):
                msg.setForeground(_qcolor("#5E6E92"))
            t.setItem(i, 1, msg)
            t.setItem(i, 2, QTableWidgetItem(str(len(g["rows"]))))
            t.setItem(i, 3, QTableWidgetItem(", ".join(sorted(g["users"])) or "—"))
            btn = QPushButton("Details")
            btn.clicked.connect(lambda _=False, row=latest: self._error_detail(row))
            t.setCellWidget(i, 4, btn)
        n = self._set_rows(self.t_errors, res.replace(ordered), render,
                           empty_msg="No errors reported 🎉")
        self._set_tab_count(self.t_errors, "Errors", n, res.ok)
        self._update_summary()
        # Ask the server for the TRUE unresolved total (same predicate as the
        # card) so a capped window can never pose as a total.
        if res.ok:
            self.admin.open_errors_total(self._on_errors_total)

    def _on_errors_total(self, total):
        """total is None when unknown — keep it None so the card says so."""
        self._kpi["errors_total"] = total
        self._update_summary()

    def _fill_installs(self, rows):
        res = Fetch.of(rows)

        def render(t, i, r):
            t.setItem(i, 0, QTableWidgetItem(r.get("username") or "—"))
            t.setItem(i, 1, QTableWidgetItem("v" + str(r.get("plugin_version", ""))))
            t.setItem(i, 2, QTableWidgetItem(r.get("qgis_version") or "—"))
            t.setItem(i, 3, QTableWidgetItem(_age(r.get("created_at", ""))))
        n = self._set_rows(self.t_installs, res, render,
                           empty_msg="No machines have checked in yet.")
        self._kpi["installs"] = n
        self._set_tab_count(self.t_installs, "Installs", n, res.ok)
        self._update_summary()

    def _fill_users(self, rows):
        res = Fetch.of(rows)

        def render(t, i, r):
            t.setItem(i, 0, QTableWidgetItem(r.get("username", "")))
            act = QTableWidgetItem("yes" if r.get("is_active") else "NO")
            act.setForeground(_qcolor("#2ABFCC" if r.get("is_active")
                                      else "#E0607A"))
            t.setItem(i, 1, act)
            t.setItem(i, 2, QTableWidgetItem(_age(r.get("created_at", ""))))
            w = QWidget()
            h = QHBoxLayout(w)
            h.setContentsMargins(0, 0, 0, 0)
            tok = QPushButton("Reset token")
            tok.clicked.connect(lambda _=False, u=r.get("username"):
                                self._reset_token(u))
            deact = QPushButton("Deactivate" if r.get("is_active") else "Enable")
            deact.clicked.connect(
                lambda _=False, u=r.get("username"), a=r.get("is_active"):
                self._toggle_active(u, not a))
            h.addWidget(tok)
            h.addWidget(deact)
            t.setCellWidget(i, 3, w)
        n = self._set_rows(self.t_users, res, render,
                           empty_msg="No teammates registered yet — share the "
                                     "repo link + team code so they can sign in.")
        self._set_tab_count(self.t_users, "Users", n, res.ok)

    def _fill_tickets(self, rows):
        res = Fetch.of(rows)
        # Both numbers come from the SAME list the table renders. `open` used to
        # mean "status != done", which quietly counted 'resolved' and
        # 'duplicate' tickets as open forever — see config.CLOSED_TICKET_STATUSES.
        n_open = len(open_tickets(res.rows))
        self._closeable = [r for r in res.rows if not is_open_ticket(r)]
        try:
            self._clear_resolved_btn.setEnabled(bool(self._closeable))
        except RuntimeError:
            pass

        def render(t, i, r):
            done = not is_open_ticket(r)
            is_bug = (r.get("kind") == "bug")
            # colour-code at a glance: 🐞 bug = red, 💡 feature = green;
            # resolved/handled tickets are dimmed (no tint) so NEW ones pop.
            if done:
                kind_fg = _qcolor("#5E6E92")
                row_bg = None
            elif is_bug:
                kind_fg = _qcolor("#F87171")          # red — a problem to fix
                row_bg = _qcolor("#2A1418")           # faint red wash
            else:
                kind_fg = _qcolor("#34D399")          # green — a feature to build
                row_bg = _qcolor("#10261C")           # faint green wash
            t.setItem(i, 0, QTableWidgetItem(_age(r.get("created_at", ""))))
            type_item = QTableWidgetItem("🐞 Bug" if is_bug else "💡 Feature")
            type_item.setForeground(kind_fg)
            t.setItem(i, 1, type_item)
            title = QTableWidgetItem(r.get("title", ""))
            title.setForeground(_qcolor("#5E6E92") if done else kind_fg)
            t.setItem(i, 2, title)
            t.setItem(i, 3, QTableWidgetItem(
                r.get("display_name") or r.get("username") or "—"))
            if row_bg is not None:                # tint the row by kind
                for _c in range(4):
                    _it = t.item(i, _c)
                    if _it is not None:
                        _it.setBackground(row_bg)
            w = QWidget()
            h = QHBoxLayout(w)
            h.setContentsMargins(0, 0, 0, 0)
            view = QPushButton("View")
            view.clicked.connect(lambda _=False, row=r: self._ticket_detail(row))
            h.addWidget(view)
            if not done:
                dn = QPushButton("Resolve")
                dn.setToolTip("Mark fixed in the current version — the person who "
                              "logged it is notified to update (or that it's fixed).")
                dn.clicked.connect(lambda _=False, tid=r.get("id"):
                                   self._ticket_resolve(tid))
                h.addWidget(dn)
            arch = QPushButton("✕")
            arch.setToolTip("Archive this ticket (hide it — kept in the DB)")
            arch.setFixedWidth(28)
            arch.clicked.connect(lambda _=False, tid=r.get("id"):
                                 self._archive_ticket(tid))
            h.addWidget(arch)
            t.setCellWidget(i, 4, w)
        n = self._set_rows(self.t_tickets, res, render,
                           empty_msg="No tickets yet — teammates' bug reports & "
                                     "feature requests (red 🎫 button) appear here.")
        # When the list holds closed tickets too, say BOTH numbers rather than
        # showing an open-count next to a longer list.
        self._set_tab_count(
            self._tickets_tab, "Tickets", n, res.ok,
            suffix=("" if n_open == n else f"{n_open} open / {n}"))

    def _ticket_detail(self, r):
        kind = "Bug report" if r.get("kind") == "bug" else "Feature request"
        shots = r.get("screenshots") or []
        text = (f"{kind}\n\nTitle: {r.get('title')}\n\n"
                f"{r.get('body') or '(no details given)'}\n\n"
                f"From: {r.get('display_name') or r.get('username') or '—'}\n"
                f"When: {r.get('created_at')}\n"
                f"Plugin v{r.get('plugin_version')} · QGIS {r.get('qgis_version')}\n"
                f"Project: {r.get('project_name') or '—'}")
        if shots:
            text += f"\n\nScreenshots ({len(shots)}):\n" + "\n".join(shots)
        if r.get("body_doc_url"):
            text += f"\n\nFull-error PDF: {r.get('body_doc_url')}"

        # Scrollable, selectable detail view — a long traceback no longer grows
        # the box past the screen bottom (which hid the buttons). The button bar
        # is a fixed footer, so Resolve / Copy / etc. are always reachable.
        from qgis.PyQt.QtWidgets import QDialog, QTextEdit
        dlg = QDialog(self)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        dlg.setWindowTitle("Ticket")
        dlg.setMinimumSize(560, 470)
        dlg.setStyleSheet(
            "QDialog{background:#070E18;}"
            "QTextEdit{background:#0B1622;color:#EAF6FB;border:1px solid #16344A;"
            "border-radius:8px;font-family:Consolas,'Courier New',monospace;font-size:11px;}"
            "QPushButton{background:#142036;color:#DDEFF5;border:1px solid #2A3A52;"
            "border-radius:7px;padding:7px 11px;font-weight:600;}"
            "QPushButton:hover{border:1px solid #22D3EE;color:#FFFFFF;}")
        v = QVBoxLayout(dlg)
        v.setContentsMargins(14, 14, 14, 12)
        v.setSpacing(10)
        te = QTextEdit()
        te.setReadOnly(True)
        te.setPlainText(text)
        v.addWidget(te, 1)

        result = {"action": None}

        def _mk(label, action):
            b = QPushButton(label)
            b.clicked.connect(
                lambda _=False, a=action: (result.__setitem__("action", a),
                                           dlg.accept()))
            return b

        row = QHBoxLayout()
        row.setSpacing(6)
        if r.get("status") != "done":
            row.addWidget(_mk("Resolve (fixed)", "resolve"))
        row.addWidget(_mk("📋 Copy for Claude", "copy"))
        row.addStretch(1)
        row.addWidget(_mk("Archive", "archive"))
        row.addWidget(_mk("Delete", "delete"))
        close = QPushButton("Close")
        close.clicked.connect(dlg.reject)
        row.addWidget(close)
        v.addLayout(row)

        dlg.exec()
        action = result["action"]
        tid = r.get("id")
        if action == "resolve" and tid:
            self._ticket_resolve(tid)
        elif action == "copy":
            self._copy_ticket_for_claude(r)
        elif action == "archive" and tid:
            self._archive_ticket(tid)
        elif action == "delete" and tid:
            self._delete_ticket(tid)

    def _ticket_done(self, ticket_id):
        if ticket_id is not None:
            self.admin.mark_ticket_done(ticket_id, True, lambda ok: self.refresh())

    def _ticket_resolve(self, ticket_id):
        """Resolve + tag the current plugin version → notifies the reporter."""
        if ticket_id is None:
            return
        ver = getattr(getattr(self.admin, "backend", None), "version", None) or "?"
        self.admin.resolve_ticket(ticket_id, ver, lambda ok: self.refresh())

    def _archive_ticket(self, ticket_id):
        """Hide a single ticket from the list (kept in the DB)."""
        if ticket_id is not None:
            self.admin.archive_ticket(ticket_id, lambda ok: self.refresh())

    def _clear_resolved(self):
        """Archive every CLOSED ticket at once — declutter the list.

        This is a bulk PATCH over live rows that overwrites each ticket's
        terminal status with 'archived', so the done/resolved/duplicate
        distinction is lost. It now (a) says exactly what it will touch, and
        (b) writes a restore file first — the reverse PATCH is a one-liner from
        that JSON if it ever needs undoing."""
        rows = list(getattr(self, "_closeable", []) or [])
        if not rows:
            QMessageBox.information(self, "Clear resolved",
                                    "Nothing to clear — no closed tickets.")
            return
        from collections import Counter
        breakdown = ", ".join(
            f"{n}× {s}" for s, n in
            sorted(Counter(r.get("status") for r in rows).items()))
        snap = self._snapshot_tickets(rows)
        if QMessageBox.question(
                self, "Clear resolved",
                f"Archive {len(rows)} closed ticket(s)?\n\n{breakdown}\n\n"
                f"They stay in the database but lose their current status.\n"
                f"Restore file: {snap or '(could not be written)'}",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No) \
                != QMessageBox.StandardButton.Yes:
            return
        self.admin.archive_resolved(lambda ok: self.refresh())

    def _snapshot_tickets(self, rows):
        """Write id+status for `rows` to a timestamped JSON next to the profile.
        Returns the path, or None if it could not be written (in which case the
        caller still shows the prompt — and says the snapshot failed)."""
        try:
            import json
            import os
            from qgis.core import QgsApplication
            d = os.path.join(QgsApplication.qgisSettingsDirPath(),
                             "velocity_nexus")
            os.makedirs(d, exist_ok=True)
            p = os.path.join(
                d, f"tickets_before_archive_{time.strftime('%Y%m%d_%H%M%S')}.json")
            with open(p, "w", encoding="utf-8") as f:
                json.dump([{"id": r.get("id"), "status": r.get("status")}
                           for r in rows], f, indent=1)
            return p
        except Exception:
            return None

    def _delete_ticket(self, ticket_id):
        """Permanently delete (with confirm) — unlike Archive, it's gone."""
        if ticket_id is None:
            return
        if QMessageBox.question(
                self, "Delete ticket",
                "Permanently delete this ticket? This cannot be undone.\n"
                "(Use Archive instead to just hide it.)") \
                != QMessageBox.StandardButton.Yes:
            return
        self.admin.delete_ticket(ticket_id, lambda ok: self.refresh())

    def _copy_ticket_for_claude(self, r):
        """Copy the ticket as a ready-to-paste prompt for the Claude terminal."""
        from qgis.PyQt.QtWidgets import QApplication
        shots = r.get("screenshots") or []
        kind = "bug" if r.get("kind") == "bug" else "feature request"
        lines = [
            f"Ticket #{r.get('id')} ({kind}) from "
            f"{r.get('display_name') or r.get('username') or 'someone'} "
            f"(plugin v{r.get('plugin_version')}, QGIS {r.get('qgis_version')}):",
            f"Title: {r.get('title')}",
            f"Details: {r.get('body') or '(none given)'}",
        ]
        if r.get("project_name"):
            lines.append(f"Project: {r.get('project_name')}")
        if shots:
            lines.append("Screenshots:")
            lines += [f"  {u}" for u in shots]
        QApplication.clipboard().setText("\n".join(lines))
        QMessageBox.information(
            self, "Copied",
            "Ticket copied to the clipboard — paste it into the Claude terminal.")

    # ── owner actions ───────────────────────────────────────────────────────
    def _error_detail(self, r):
        bc = r.get("breadcrumbs") or []
        trail = "\n".join(f"  • {c.get('action_id')} "
                          f"({c.get('category')})" for c in bc) or "  (none)"
        text = (f"User: {r.get('username')}\n"
                f"When: {r.get('inserted_at')}\n"
                f"Project: {r.get('project_name') or '—'}\n"
                f"Tool: {r.get('active_tool') or '—'}\n"
                f"Plugin v{r.get('plugin_version')} · QGIS "
                f"{r.get('qgis_version')}\n\n"
                f"Error: {r.get('error_message')}\n\n"
                f"What they were doing (breadcrumbs):\n{trail}\n\n"
                f"Note from user: {r.get('user_note') or '—'}\n\n"
                f"--- traceback ---\n{r.get('error_traceback') or ''}")
        box = QMessageBox(self)
        box.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        box.setWindowTitle("Error details")
        box.setText(text)
        resolve = box.addButton("Mark resolved", QMessageBox.ButtonRole.AcceptRole)
        box.addButton(QMessageBox.StandardButton.Close)
        box.exec()
        if box.clickedButton() is resolve and r.get("error_id"):
            self.admin.mark_error_resolved(
                r["error_id"], True, lambda ok: self.refresh())

    def _reset_token(self, username):
        def done(token):
            if token:
                QMessageBox.information(
                    self, "Reset token",
                    f"Give {username} this one-time code (valid 1 hour):\n\n"
                    f"    {token}\n\nThey enter it with a new password to "
                    "regain access.")
            else:
                QMessageBox.warning(self, "Reset token",
                                    "Could not issue a token (offline?).")
        self.admin.issue_reset_token(username, cb=done)

    def _toggle_active(self, username, active):
        verb = "enable" if active else "deactivate"
        if QMessageBox.question(
                self, "Confirm",
                f"{verb.capitalize()} {username}?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
            return
        self.admin.deactivate(username, active, lambda ok: self.refresh())

    def _announce(self):
        title, ok = QInputDialog.getText(self, "Announce", "Title:")
        if not ok or not title.strip():
            return
        msg, ok = QInputDialog.getText(self, "Announce", "Message:")
        if not ok or not msg.strip():
            return
        self.admin.announce(
            title.strip(), msg.strip(),
            cb=lambda ok2: QMessageBox.information(
                self, "Announce",
                "Sent to everyone." if ok2 else "Failed (offline?)."))

    def closeEvent(self, event):
        try:
            self._timer.stop()
            self._timer.deleteLater()
        except Exception:
            _swallowed_note()
        super().closeEvent(event)


def _qcolor(hexv):
    from qgis.PyQt.QtGui import QColor
    return QColor(hexv)


class _KPICard(QFrame):
    """Compact metric tile: big value over a small caption. Colour is set
    dynamically per state by set_value()."""

    def __init__(self, caption, parent=None):
        super().__init__(parent)
        self.setObjectName("kpiCard")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 9, 12, 9)
        lay.setSpacing(2)
        self._val = QLabel("—")
        self._val.setStyleSheet("font-size:22px;font-weight:800;color:#2ABFCC;")  # dual-theme-ok: Team Monitor root paints #0F1A30
        cap = QLabel(caption)
        cap.setObjectName("kpiCap")
        lay.addWidget(self._val)
        lay.addWidget(cap)

    def set_value(self, val, colour="#2ABFCC", hint=None):
        """Set the metric. nexus_ui rule 4: a value that renders as a bare 0 or
        dash is a dead end — it reads as broken rather than as "nothing yet".
        The number stays truthful; an empty one is dimmed and carries a tooltip
        saying what would fill it, so a real 7 and a not-yet 0 stop shouting
        equally loudly.
        """
        self._val.setText(str(val))
        empty = str(val).strip() in ("", "-", "--", "—", "0", "None", "n/a")
        self._val.setStyleSheet(
            "font-size:22px;font-weight:800;color:%s;"
            % ("#6E7FA6" if empty else colour))
        self.setToolTip(hint or "")


class _HealthBanner(QFrame):
    """Hero strip: an at-a-glance team-health verdict. Border colour tracks
    the state property (ok=cyan / warn=amber / error=red) via the dock QSS."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("healthBanner")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 8, 14, 8)
        lay.setSpacing(1)
        self._title = QLabel("Loading…")
        self._title.setObjectName("healthTitle")
        self._detail = QLabel("")
        self._detail.setObjectName("healthDetail")
        lay.addWidget(self._title)
        lay.addWidget(self._detail)

    def set_state(self, state, title, detail):
        icon = {"ok": "✅", "warn": "⚠", "error": "⛔"}.get(state, "")
        self._title.setText(f"{icon}  {title}")
        self._detail.setText(detail)
        self.setProperty("state", state)
        # re-evaluate the property-based QSS selector
        self.style().unpolish(self)
        self.style().polish(self)
