"""boq — reliable FTTH Bill-of-Quantities engine.

Measure (UTM metres, never degrees) → wastage → rates → validate → Excel.

  from .boq import run_boq
  result = run_boq("C:/path/out.xlsx")   # against the live QGIS project
"""
from . import engine as _engine  # noqa: F401
from .engine import BoQResult, load_rates, run  # noqa: F401


def run_boq(out_path=None, project=None, rates=None):
    """Run the BoQ pipeline and (optionally) write the .xlsx. Returns the BoQResult
    (with .verdict, .lines, .audit, .blocked, .missing)."""
    result = run(project=project, rates=rates)
    if out_path:
        from .excel import write_boq
        write_boq(result, out_path)
        result.meta["out_path"] = out_path
    return result
