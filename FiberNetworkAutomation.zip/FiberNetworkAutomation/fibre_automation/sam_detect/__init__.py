"""sam_detect — local SAM2 building detection for ANY project AOI.

Pipeline (all local, no API keys / subscriptions):
  footprint boxes (GOB/Overture or an existing Buildings layer)
  -> tile render of the basemap (in QGIS)
  -> SAM 2.1 box-prompted roof masks (venv subprocess, Meta Apache-2.0 weights)
  -> per-erf union + clip (when an erven/cadastral layer exists)
  -> orthogonal regularization (buildingregulariser)
  -> shape classification (shack / square / rectangle / L-shape / complex)
  -> styled layer, one colour per shape class

Entry point: runner.SamDetectRunner(iface).run()
"""
