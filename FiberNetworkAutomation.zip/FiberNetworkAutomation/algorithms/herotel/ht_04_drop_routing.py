# HeroTel: Drop Cable Routing Algorithm (TSD standard)

from qgis.core import (
    QgsProcessingParameterVectorLayer,
    QgsProcessing,
)

from .ht_base_algorithm import HeroTelBaseAlgorithm


class HT04DropRoutingAlgorithm(HeroTelBaseAlgorithm):
    """
    HT 4 — Drop Cable Routing (ONT → STS) — TSD standard.

    Routes aerial drop cables from each ONT to its assigned STS.
    HeroTel drop cable: A-BB13-B00 (4F SM dual drop, max 75m aerial span).

    PENDING: HeroTel TSD specification document from JJ.
    This is a stub algorithm. Full implementation will:
      1. For each ONT, identify assigned STS (from ht_03 sts_id attribute)
      2. Route drop cable along road verge (not straight-line across yards)
         using road network graph (osmnx shortest path)
      3. Enforce 75m max span constraint (HeroTel SSA aerial drop limit)
         Flag any ONTs that cannot be served within 75m for manual review
      4. Label drop cables as {PROJECT}.DR.{num} (Hilbert curve ordering within STS cluster)
      5. Populate attributes: strtfeat (ONT label), endfeat (STS label),
         cblcpty1='4F', cable_type='Drop', spec_1='A-BB13-B00', length_m

    Drop cable spec: A-BB13-B00 MEGAnet Cs CABLE SM DUAL DROP
    Max span: 75m (HeroTel SSA) — compare Vuma Reach 50m limit.
    Fibre count: 4F (NOT 1F like Vuma G.657 butterfly).

    Run AFTER: HT 3 (Splitter Placement)
    Run BEFORE: HT 5 (Feeder Routing)
    Requires: ONT v1 (pon_no + sts_id), Splitter STS v1, road network
    Produces: Drop Cable v1
    """

    INPUT_ONT = 'INPUT_ONT'
    INPUT_STS = 'INPUT_STS'

    def name(self):
        return 'ht_04_drop_routing'

    def displayName(self):
        return 'HT 4 — Drop Cable Routing (ONT → STS)'

    def shortHelpString(self):
        return """
        <p><b>HT 4 — Drop Cable Routing (ONT → STS)</b></p>

        <p>Routes aerial drop cables from each ONT to its assigned STS along the road network.</p>

        <h4>Drop cable spec (HeroTel)</h4>
        <ul>
          <li>SKU: A-BB13-B00 (MEGAnet Cs CABLE SM DUAL DROP)</li>
          <li>Fibre count: 4F (SM dual drop) — NOT 1F like Vuma Reach</li>
          <li>Max span: 75m aerial (HeroTel SSA — Short Span ADSS)</li>
        </ul>

        <h4>Routing</h4>
        <p>Routes follow road verge using osmnx shortest path. Unserviceable ONTs
        (&gt;75m) are flagged in the feedback log for manual review.</p>

        <h4>Labels</h4>
        <p>Drop cables labelled {PROJECT}.DR.{num} using Hilbert curve ordering
        within each STS cluster for spatially stable DR numbers.</p>

        <p><b>⚠️ PENDING:</b> HeroTel TSD specification from JJ. Full implementation awaiting PDF.</p>
        """

    def initAlgorithm(self, config=None):
        from qgis.core import QgsProject
        proj = QgsProject.instance()
        ont_layers = proj.mapLayersByName('ONT v1') or proj.mapLayersByName('Demand Points')
        sts_layers = proj.mapLayersByName('Splitter STS v1')

        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT_ONT,
                'ONT v1 point layer (with sts_id populated)',
                [QgsProcessing.SourceType.TypeVectorPoint],
                defaultValue=ont_layers[0] if ont_layers else None,
            )
        )
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT_STS,
                'Splitter STS v1 layer',
                [QgsProcessing.SourceType.TypeVectorPoint],
                defaultValue=sts_layers[0] if sts_layers else None,
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """Algorithm entry point — STUB pending TSD specification"""
        raise NotImplementedError(
            '\n'.join([
                'HT 4 — Drop Cable Routing is not yet implemented.',
                '',
                'PENDING: HeroTel TSD (Telecommunications System Design) specification from JJ.',
                '',
                'Key design decisions confirmed:',
                '  • Drop cable: A-BB13-B00 (4F SM dual drop) — NOT 1F like Vuma Reach',
                '  • Max span: 75m (HeroTel SSA aerial drop limit)',
                '  • Routing: road verge via osmnx shortest path (not straight-line)',
                '  • DR numbering: Hilbert curve within each STS cluster',
                '  • Unserviceable ONTs (>75m): flag in feedback, do NOT skip silently',
                '',
                'Requires: C:/Temp/lulekani_roads.graphml (osmnx 2.1.0)',
                '          pip install hilbertcurve (in .qgis-venv)',
                'Contact: ai@velocityfibre.co.za',
            ])
        )

    def postProcessAlgorithm(self, context, feedback):
        return {}
