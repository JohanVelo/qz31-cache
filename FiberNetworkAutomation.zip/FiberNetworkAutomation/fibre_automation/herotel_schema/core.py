# The canonical HeroTel schema checks. ONE copy, two front ends.
#
# The checks here know nothing about GDAL or QGIS. They take LayerView objects -
# a name, a field list, a feature count and a way to sample values - so the same
# code runs against a GeoPackage on disk (the CLI, via OGR) and against the
# layers open in JJ's QGIS project (the HT 6 algorithm, via QgsVectorLayer).
#
# ⛔ That is deliberate and it is the point. This repo has been bitten by three
# copies of `pon_wayleave` drifting apart, and by two hand-maintained rule sets
# disagreeing within a week. A check that exists twice is a check that will
# eventually disagree with itself, and then neither answer can be trusted.
#
# Read-only by construction: a LayerView cannot write, so no front end can turn
# a check into an edit.

from __future__ import annotations

import re
import unicodedata
from pathlib import Path

ERROR, WARN, INFO = "ERROR", "WARN", "INFO"

# How many features to read when collecting a value vocabulary. Delivered towns
# run to 13,570 features and every distinct value appears long before then; a
# full scan turns a 3-second check into a minute for no extra finding.
VALUE_SAMPLE = 4000

SCHEMA_PATH = Path(__file__).with_name("schema.yaml")
# GENERATED from the 50-town census. schema.yaml holds the decisions; this holds
# the measurements. Absent is survivable - the checks simply lose profile gating.
EVIDENCE_PATH = Path(__file__).with_name("evidence.yaml")


class Finding:
    """One thing wrong, with enough context to act on it without re-running."""

    __slots__ = ("code", "detail", "layer", "severity")

    def __init__(self, severity, code, layer, detail):
        self.severity, self.code, self.layer, self.detail = severity, code, layer, detail

    def as_dict(self):
        return {"severity": self.severity, "code": self.code,
                "layer": self.layer, "detail": self.detail}

    def __repr__(self):
        return f"<{self.severity} {self.code} {self.layer}>"


class LayerView:
    """What a check needs to know about a layer. Implemented per front end.

    Subclasses supply `fields`, `feature_count` and `sample_values`. Nothing
    here can mutate anything, which is how "the validator never writes" is
    enforced by shape rather than by discipline.
    """

    name = ""

    @property
    def fields(self) -> list[str]:
        raise NotImplementedError

    @property
    def feature_count(self) -> int:
        raise NotImplementedError

    def sample_values(self, fields: list[str], limit: int = VALUE_SAMPLE) -> dict:
        """{field: set(distinct non-empty values as str)} over the first `limit`."""
        raise NotImplementedError


# ------------------------------------------------------------------- schema
def load_schema(path=None) -> dict:
    """Read schema.yaml and flatten its field groups.

    `fields_from` is resolved here so no check has to know that field groups
    exist, and `vocabulary_overrides` is applied so a layer-specific vocabulary
    (DC Joints are 1:8, Feeder Joints are 1:16) lands on the field itself.
    """
    import yaml
    p = Path(path) if path else SCHEMA_PATH
    s = yaml.safe_load(p.read_text(encoding="utf-8"))
    groups = s.get("field_groups") or {}
    for lyr in s["layers"]:
        if lyr.get("fields_from"):
            omit = set(lyr.get("fields_omit") or [])
            fields = [dict(f) for f in groups[lyr["fields_from"]]
                      if f["name"] not in omit]
            fields += [dict(f) for f in (lyr.get("fields_extra") or [])]
            lyr["fields"] = fields + [dict(f) for f in (lyr.get("fields") or [])]
        for f in lyr.get("fields") or []:
            ov = (lyr.get("vocabulary_overrides") or {}).get(f["name"])
            if ov:
                f["vocabulary"] = ov
    return s


def load_evidence(path=None) -> dict:
    """The generated census. Returns {} if absent - never a hard failure.

    Losing evidence.yaml costs profile gating and nothing else; the schema's own
    rules still apply. A missing measurement file must not stop a check running,
    or the check stops being run.
    """
    import yaml
    p = Path(path) if path else EVIDENCE_PATH
    if not p.exists():
        return {}
    try:
        return yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except Exception:
        return {}


def town_profile(evidence: dict, town: str | None) -> str:
    """aerial / mixed / underground / unknown for a town, from the census."""
    if not (evidence and town):
        return "unknown"
    return (evidence.get("profiles") or {}).get(town, "unknown")


def applies_to_profile(spec: dict, profile: str) -> bool:
    """Does this canonical layer apply to a town of this profile?

    ⚠ `unknown` is treated as APPLICABLE, so an unknown-profile town is still
    told a required layer is missing. That is the conservative direction: 35 of
    the 50 censused towns are aerial, and a town reads `unknown` only when it
    holds too few layers to signal either way - which usually means a stub
    project that genuinely is missing everything. The cost is noise on stubs;
    the alternative cost is silence on a real gap, which is worse.
    """
    wanted = spec.get("profiles")
    if not wanted or profile == "unknown":
        return True
    return profile in wanted


def fold_equivalents(voc: dict) -> dict:
    """{written form -> canonical form} for one vocabulary.

    The census found two pole products written eight ways. Folding them is how
    a BOQ stops billing eight line items for two products - but the folding is
    declared in schema.yaml, per value, never inferred from similarity.
    """
    out = {}
    for canon, variants in (voc.get("equivalents") or {}).items():
        for v in variants:
            out[v] = canon
    return out


def normalise_name(n: str) -> str:
    """For MATCHING only, never for writing. Case and spacing vary wildly -
    `Erven` in 38 towns, `erven` in 11, and they are the same layer."""
    return re.sub(r"[^a-z0-9]", "", str(n).lower())


def normalise_value(v) -> str:
    """Fold the Unicode variants that make one value look like several.

    Middelburg writes the doubled feeder splitter as "1:16×2" with a Unicode
    multiplication sign; Botchabelo and Barberton write ASCII "1:16*2". Raw
    string comparison counts them as different products, which is how a BOQ
    grows a phantom line item.
    """
    v = unicodedata.normalize("NFKC", str(v)).strip()
    for ch in ("×", "✕", "✖", "⨯"):        # × ✕ ✖ ⨯
        v = v.replace(ch, "*")
    return re.sub(r"\s+", " ", v)


# ------------------------------------------------------------------- checks
def check(views, schema, *, town=None, evidence=None) -> list[Finding]:
    """Every canonical check, against any front end's layer views.

    `town` + `evidence` enable PROFILE GATING: an aerial-only layer is not
    required of a trenched town. Pass neither and every layer is required, which
    is the old behaviour and is what produced 27 false errors on Malmesbury.
    """
    out: list[Finding] = []
    present = {v.name: v for v in views}
    by_norm = {normalise_name(n): n for n in present}
    if evidence is None:
        evidence = load_evidence()
    profile = town_profile(evidence, town)

    cruft = {f: fam for fam, fs in (schema.get("drop_fields") or {}).items() for f in fs}
    trunc = schema.get("truncation_aliases") or {}
    vocabs = schema.get("vocabularies") or {}

    # ---- 1. per-PON / per-Phase fragmentation (D3) --------------------------
    for spec in schema["layers"]:
        pat = spec.get("replaces_pattern")
        if not pat:
            continue
        frag = [n for n in present if re.fullmatch(pat, n)]
        if not frag:
            continue
        out.append(Finding(
            ERROR, "fragmented-layer", spec["name"],
            f"{len(frag)} separate layers matching /{pat}/ "
            f"(e.g. {', '.join(sorted(frag)[:3])}). D3: fold into one "
            f"'{spec['name']}' layer with a '{spec['fields'][0]['name']}' "
            f"attribute, FILL it, then categorise."))
        counts = {len(present[n].fields) for n in frag}
        if len(counts) > 1:
            # This is the damage the fragmentation does, and the reason D3
            # exists: the attribute tables drift inside a single town.
            out.append(Finding(
                ERROR, "fragment-schema-drift", spec["name"],
                f"the {len(frag)} fragments do not share one attribute table: "
                f"field counts {sorted(counts)} inside a single town."))

    # ---- 2. layers present / missing / misnamed ----------------------------
    for spec in schema["layers"]:
        name = spec["name"]
        if spec.get("replaces_pattern") and name not in present:
            continue                          # covered by the fragmentation check
        actual = None
        if name in present:
            actual = name
        else:
            for alias in [name] + (spec.get("aliases") or []):
                hit = by_norm.get(normalise_name(alias))
                if hit:
                    actual = hit
                    out.append(Finding(WARN, "layer-misnamed", name,
                                       f"found as '{hit}' - rename to '{name}'."))
                    break
        if actual is None:
            if not spec.get("required"):
                continue
            if not applies_to_profile(spec, profile):
                # Not a defect. An aerial pole layer is meaningless on a
                # trenched build, and reporting it as missing is how a gate
                # produces 27 findings that a human correctly ignores - after
                # which they ignore the real ones too.
                out.append(Finding(
                    INFO, "layer-not-in-profile", name,
                    f"absent, and not required for a '{profile}' build."))
                continue
            out.append(Finding(ERROR, "layer-missing", name,
                               "required canonical layer is absent."))
            continue

        view = present[actual]
        n_feat = view.feature_count
        if n_feat == 0 and not spec.get("allow_empty"):
            out.append(Finding(WARN, "layer-empty", name,
                               "present but holds 0 features."))

        # ---- 3. fields -----------------------------------------------------
        have = list(view.fields)
        have_norm = {normalise_name(h): h for h in have}
        for f in spec.get("fields") or []:
            fname = f["name"]
            if fname in have:
                continue
            hit = have_norm.get(normalise_name(fname))
            if hit:
                out.append(Finding(WARN, "field-misnamed", name,
                                   f"'{fname}' found as '{hit}'."))
                continue
            t = next((x for x in trunc.get(fname, []) if x in have), None)
            if t:
                # Its own finding: shapefile did this silently on write, and
                # GeoPackage never would. Naming it points at the real fix.
                out.append(Finding(
                    WARN, "field-truncated", name,
                    f"'{fname}' arrived as '{t}' - a 10-char shapefile "
                    f"truncation. D2: work in GeoPackage and this stops."))
                continue
            if f.get("required"):
                out.append(Finding(ERROR, "field-missing", name,
                                   f"required field '{fname}' is absent."))

        # One finding per LAYER, not per field: twelve KML columns across twelve
        # layers is 144 lines that bury the three findings that matter, and a
        # report nobody reads to the end is a report that failed.
        by_family: dict[str, list[str]] = {}
        for h in have:
            if h in cruft:
                by_family.setdefault(cruft[h], []).append(h)
        for family, fs in sorted(by_family.items()):
            out.append(Finding(INFO, "field-cruft", name,
                               f"{len(fs)} {family} field(s) to drop: "
                               f"{', '.join(sorted(fs))}."))

        # ---- 4. value vocabularies -----------------------------------------
        checked = [f for f in (spec.get("fields") or [])
                   if f.get("vocabulary") and f["name"] in have]
        if not (checked and n_feat):
            continue
        seen = view.sample_values([f["name"] for f in checked])
        for f in checked:
            voc = vocabs[f["vocabulary"]]
            allowed = {normalise_value(x) for x in voc["values"]}
            equiv = fold_equivalents(voc)
            equiv_norm = {normalise_value(k): v for k, v in equiv.items()}
            raw = seen.get(f["name"], set())

            # A DECLARED equivalent is the same product written another way -
            # "100/120mm" is "100-120mm". Report it so it gets normalised, but
            # never as "outside the vocabulary": it is not an unknown product.
            written_other_way = sorted({v for v in raw
                                        if normalise_value(v) in equiv_norm})
            if written_other_way:
                out.append(Finding(
                    WARN, "value-equivalent-spelling", name,
                    f"{f['name']}: {written_other_way[:6]} are the same "
                    f"product(s) as "
                    f"{sorted({equiv_norm[normalise_value(v)] for v in written_other_way})} "
                    f"written differently - a BOQ grouping on the raw string "
                    f"bills them separately."))
                raw = {v for v in raw if normalise_value(v) not in equiv_norm}

            # ⛔ A value on `not_a_diameter` is a POLE HEIGHT sitting in a field
            # meant for diameter. That is a semantic collision, not a spelling
            # one - it must never be folded onto a diameter, because 5.4m is not
            # a width and no amount of normalising makes it one.
            wrong_kind = sorted({v for v in raw
                                 if v in set(voc.get("not_a_diameter") or [])})
            if wrong_kind:
                out.append(Finding(
                    ERROR, "value-wrong-quantity", name,
                    f"{f['name']}: {wrong_kind} are pole HEIGHTS in a field "
                    f"that holds a diameter elsewhere. Two different quantities "
                    f"share one column - split them, do not normalise them."))
                raw = {v for v in raw if v not in set(voc.get("not_a_diameter") or [])}

            folded: dict[str, set] = {}
            for v in raw:
                folded.setdefault(normalise_value(v), set()).add(v)
            for variants in folded.values():
                if len(variants) > 1:
                    out.append(Finding(
                        ERROR, "value-variant-spellings", name,
                        f"{f['name']}: {len(variants)} spellings of one value "
                        f"{sorted(variants)} - a BOQ grouping on this string "
                        f"counts them as different products."))

            # A value that matches ONLY after folding is written the wrong way,
            # even though nothing inside this town contradicts it. Middelburg's
            # Unicode "1:16×2" is invisible to every within-town check and fatal
            # to a cross-town roll-up. Without this the vocabulary check passes
            # it silently, which is worse than not checking at all.
            literal = set(voc["values"])
            off = sorted({v for v in raw
                          if v not in literal and normalise_value(v) in allowed})
            if off:
                out.append(Finding(
                    ERROR, "value-noncanonical-spelling", name,
                    f"{f['name']}: {off} matches the vocabulary only after "
                    f"Unicode folding - rewrite as "
                    f"{[normalise_value(v) for v in off]}."))

            bad = sorted({v for v in raw if normalise_value(v) not in allowed})
            if bad and voc.get("strict"):
                out.append(Finding(
                    ERROR, "value-outside-vocabulary", name,
                    f"{f['name']}: {bad[:6]} not in {voc['values']}."))
            elif bad:
                out.append(Finding(
                    WARN, "value-unlisted", name,
                    f"{f['name']}: {bad[:6]} not in the recorded vocabulary "
                    f"{voc['values']} (non-strict)."))
    return out


#: Columns every GeoPackage layer carries that are not part of any standard.
_STANDARD_IGNORED = {"fid", "ogc_fid"}


def check_standard(views, spec) -> list[Finding]:
    """Check layers against the VN 1 standard (the Lulekani layer set).

    `spec` is the herotel_layers gold spec: {"layers": {name: {"fields": [...]}}}.
    Every standard layer must be present by name, carry every standard column,
    and keep them in the standard order. Project layers that are not in the
    standard are not this check's business and are ignored.

    This is a second yardstick, not a replacement for check(): check() measures
    against the delivered client packages (Demand Units, Drop Fibre, ...), which
    use different layer names from the ones VN 1 builds.
    """
    out = []
    by_name = {}
    for v in views:
        by_name.setdefault(normalise_name(v.name), v)
    for name, layer_spec in spec["layers"].items():
        view = by_name.get(normalise_name(name))
        if view is None:
            out.append(Finding(ERROR, "layer-missing", name,
                               "standard layer is absent."))
            continue
        if view.name != name:
            out.append(Finding(WARN, "layer-name", name,
                               f"present as '{view.name}'; the standard spells it '{name}'."))
        want = [f["name"] for f in layer_spec["fields"]]
        have = [f for f in view.fields if f.lower() not in _STANDARD_IGNORED]
        missing = [f for f in want if f not in have]
        for f in missing:
            out.append(Finding(ERROR, "field-missing", name,
                               f"standard column '{f}' is absent."))
        extra = [f for f in have if f not in want]
        if extra:
            out.append(Finding(INFO, "field-extra", name,
                               f"{len(extra)} column(s) not in the standard: {', '.join(extra)}."))
        if not missing and [f for f in have if f in want] != want:
            out.append(Finding(WARN, "field-order", name,
                               f"columns are not in the standard order ({', '.join(want)})."))
    return out


def summarise(findings) -> dict:
    return {s: sum(1 for f in findings if f.severity == s)
            for s in (ERROR, WARN, INFO)}
