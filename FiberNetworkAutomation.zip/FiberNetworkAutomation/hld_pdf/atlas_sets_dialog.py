# -*- coding: utf-8 -*-
# claude:intent MUTATE - user asked (JJ 2026-10-26): "I want the layer selection to look like this [HLD Book
#   pages screenshot] so I can add pages and select what I want ... at the top next to page pictures" -
#   plan Atlas Page Sets rev 3, steps 3 + 4. The window edits a set list; atlas_sets_qgis writes it.
# claude:boq-impact none - presentation only
"""The "Pages…" window for the HLD Network Atlas: page sets (e.g. Underground) after the Network
pages, each with its own ticked layers and labels. Looks like the HLD Book pages window."""
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem,
                                 QPushButton, QLabel, QLineEdit, QTreeWidget, QTreeWidgetItem,
                                 QDialogButtonBox, QMessageBox, QSplitter, QWidget, QFormLayout, QHeaderView)

from . import atlas_sets as AS

TITLE = "HLD Network Atlas — pages"


def switched_off():
    """vf/hld/atlas_sets_off: the button is hidden and Rebuild ignores stored sets (plan F5)."""
    try:
        from qgis.core import QgsSettings
        return str(QgsSettings().value(AS.SETTING_OFF, "false")).lower() in ("true", "1", "on", "yes")
    except Exception:
        return False


def offered_layers(project):
    """[(id, name)] vector layers in Layers-panel order; never the atlas's own or a set's copies."""
    from qgis.core import QgsVectorLayer
    out = []
    for node in project.layerTreeRoot().findLayers():
        l = node.layer()
        if (isinstance(l, QgsVectorLayer) and not l.customProperty("vf_hld_role")
                and not l.customProperty(AS.PROP_OWNER) and not l.name().startswith(AS.NAME_PREFIX)):
            out.append((l.id(), l.name()))
    return out


class PageSetsDialog(QDialog):
    """Network first and locked; added sets editable: title, note, which layers show, which
    get labels. The result goes into `holder["sets"]` from accept(), BEFORE the window closes."""

    ROLE_ID = Qt.ItemDataRole.UserRole

    def __init__(self, parent, project, sets, holder):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self.setWindowTitle(TITLE)
        self.setMinimumSize(820, 560)
        self._p = project
        self._holder = holder
        self._sets = AS.normalise(sets)
        self._cur = None
        self._layers = offered_layers(project)
        # a ticked layer deleted since: listed (ticked) so the operator can untick it - the export
        # gate's "untick it in Pages…" must be something this window can do
        live = {lid for lid, _n in self._layers}
        for x in self._sets["sets"]:
            for l_ in x["layers"]:
                lid = l_["id"]
                if lid not in live and project.mapLayer(lid) is None:
                    live.add(lid)
                    self._layers.append((lid, "⚠ %s (deleted - untick to drop it)" % AS.name_from_layer_id(lid)))
        root = QVBoxLayout(self)
        tip = QLabel("Network pages print as they are now. Each page set you add prints after them: "
                     "its own overview with the grid, then every grid block at the same zoom, drawing only "
                     "the layers you tick. The aerial photo is always underneath.")
        tip.setWordWrap(True)
        root.addWidget(tip)
        split = QSplitter(Qt.Orientation.Horizontal)
        left = QWidget(); lv = QVBoxLayout(left); lv.setContentsMargins(0, 0, 0, 0)
        self.pages = QListWidget()
        lv.addWidget(self.pages)
        row = QHBoxLayout()
        self.b_add, self.b_remove = QPushButton("Add page"), QPushButton("Remove")
        self.b_up, self.b_down = QPushButton("▲"), QPushButton("▼")
        self.b_add.clicked.connect(self._add)
        self.b_remove.clicked.connect(self._remove)
        self.b_up.clicked.connect(lambda: self._move(-1))
        self.b_down.clicked.connect(lambda: self._move(1))
        for b in (self.b_add, self.b_remove, self.b_up, self.b_down):
            row.addWidget(b)
        lv.addLayout(row)
        self.b_clear = QPushButton("Remove all page sets")
        self.b_clear.clicked.connect(self._clear)
        lv.addWidget(self.b_clear)
        split.addWidget(left)
        right = QWidget(); rv = QVBoxLayout(right); rv.setContentsMargins(0, 0, 0, 0)
        form = QFormLayout()
        self.title = QLineEdit()
        self.title.textEdited.connect(self._title_edited)
        form.addRow("Page title:", self.title)
        self.note = QLineEdit()
        self.note.setPlaceholderText("Kept with this page set")
        form.addRow("Note:", self.note)
        rv.addLayout(form)
        self.layers = QTreeWidget()
        self.layers.setColumnCount(3)
        self.layers.setHeaderLabels(["Layer", "Show", "Labels"])
        self.layers.setRootIsDecorated(False)
        hdr = self.layers.header()
        hdr.setStretchLastSection(False)
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for c in (1, 2):
            hdr.setSectionResizeMode(c, QHeaderView.ResizeMode.Fixed)
            self.layers.setColumnWidth(c, 64)
        for lid, name in self._layers:
            it = QTreeWidgetItem([name, "", ""])
            it.setData(0, self.ROLE_ID, lid)
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(1, Qt.CheckState.Unchecked)
            it.setCheckState(2, Qt.CheckState.Unchecked)
            self.layers.addTopLevelItem(it)
        rv.addWidget(self.layers)
        allrow = QHBoxLayout()
        self.b_all, self.b_none = QPushButton("Show all"), QPushButton("Show none")
        self.b_all.clicked.connect(lambda: self._tick_all(True))
        self.b_none.clicked.connect(lambda: self._tick_all(False))
        allrow.addWidget(self.b_all); allrow.addWidget(self.b_none); allrow.addStretch(1)
        rv.addLayout(allrow)
        self.locked = QLabel("The Network pages print exactly as the atlas was built. "
                             "Add a page set to choose other layers.")
        self.locked.setWordWrap(True)
        rv.addWidget(self.locked)
        split.addWidget(right)
        split.setStretchFactor(1, 3)
        root.addWidget(split, 1)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        root.addWidget(bb)
        self._fill()
        self.pages.currentRowChanged.connect(self._on_row)
        self.pages.setCurrentRow(1 if self._sets["sets"] else 0)
        self._on_row(self.pages.currentRow())

    # list: row 0 = Network (locked), row k = set k
    def _fill(self):
        self.pages.blockSignals(True)
        self.pages.clear()
        it = QListWidgetItem("🔒 Network (as built)")
        self.pages.addItem(it)
        for k, x in enumerate(self._sets["sets"], start=1):
            self.pages.addItem(QListWidgetItem("%d · %s" % (k, x["title"])))
        self.pages.blockSignals(False)

    def _set(self, row=None):
        r = self.pages.currentRow() if row is None else row
        return (r - 1, self._sets["sets"][r - 1]) if 1 <= r <= len(self._sets["sets"]) else (None, None)

    def _store(self):
        if self._cur is None:
            return
        _i, x = self._cur
        if x is None:
            return
        offered = {lid for lid, _n in self._layers}
        keep = [l_ for l_ in x["layers"] if l_["id"] not in offered]     # deleted layers stay listed
        ticked = []
        for i in range(self.layers.topLevelItemCount()):
            it = self.layers.topLevelItem(i)
            if it.checkState(1) == Qt.CheckState.Checked:
                ticked.append({"id": it.data(0, self.ROLE_ID), "labels": it.checkState(2) == Qt.CheckState.Checked})
        x["layers"] = keep + ticked
        x["note"] = self.note.text()
        x["title"] = self.title.text().strip() or x["title"]

    def _on_row(self, row):
        self._store()
        i, x = self._set(row)
        self._cur = (i, x)
        editable = x is not None
        for w in (self.title, self.note, self.layers, self.b_all, self.b_none, self.b_remove, self.b_up, self.b_down):
            w.setEnabled(editable)
        self.locked.setVisible(not editable)
        self.title.setText(x["title"] if editable else "Network")
        self.note.setText(x["note"] if editable else "")
        ticks = {l_["id"]: l_["labels"] for l_ in (x["layers"] if editable else [])}
        for j in range(self.layers.topLevelItemCount()):
            it = self.layers.topLevelItem(j)
            lid = it.data(0, self.ROLE_ID)
            it.setCheckState(1, Qt.CheckState.Checked if lid in ticks else Qt.CheckState.Unchecked)
            it.setCheckState(2, Qt.CheckState.Checked if ticks.get(lid) else Qt.CheckState.Unchecked)

    def _title_edited(self, txt):
        i, _x = self._cur or (None, None)
        if i is not None:
            it = self.pages.currentItem()
            if it is not None:
                it.setText("%d · %s" % (i + 1, txt))

    def _tick_all(self, on):
        st = Qt.CheckState.Checked if on else Qt.CheckState.Unchecked
        for j in range(self.layers.topLevelItemCount()):
            self.layers.topLevelItem(j).setCheckState(1, st)
            if not on:
                self.layers.topLevelItem(j).setCheckState(2, st)

    def _add(self):
        self._store()
        n = len(self._sets["sets"])
        title = AS.unique_titles([x["title"] for x in self._sets["sets"]] + ["Page set %d" % (n + 1)])[-1]
        self._sets["sets"].append(AS.make_set(title))
        self._cur = None
        self._fill()
        self.pages.setCurrentRow(n + 1)

    def _remove(self):
        i, x = self._set()
        if x is None:
            return
        self._sets["sets"].pop(i)
        self._cur = None
        self._fill()
        self.pages.setCurrentRow(min(i + 1, self.pages.count() - 1))

    def _clear(self):
        self._sets["sets"] = []
        self._cur = None
        self._fill()
        self.pages.setCurrentRow(0)

    def _move(self, d):
        i, x = self._set()
        if x is None or not (0 <= i + d < len(self._sets["sets"])):
            return
        self._store()
        s = self._sets["sets"]
        s[i], s[i + d] = s[i + d], s[i]
        self._cur = None
        self._fill()
        self.pages.setCurrentRow(i + d + 1)

    def result_sets(self):
        self._store()
        return AS.normalise(self._sets)

    def accept(self):
        sets = self.result_sets()
        names = {lid: l.name() for lid, l in self._p.mapLayers().items()}
        errors, warnings, missing = AS.validate(sets, names)
        if errors:
            QMessageBox.warning(self, TITLE, "Fix these first:\n• " + "\n• ".join(errors))
            return
        self._holder["sets"] = sets                 # captured BEFORE close (WA_DeleteOnClose)
        self._holder["warnings"] = warnings
        self._holder["missing"] = missing
        super().accept()


# ── designer button ────────────────────────────────────────────────────────────────────
def _say(win, text, warn=False):
    try:
        (QMessageBox.warning if warn else QMessageBox.information)(win, TITLE, text)
    except Exception:
        print(TITLE + ": " + text)


def open_for_window(win):
    """The toolbar action: open the window for this designer's layout and write the result."""
    from qgis.core import QgsProject
    from .page_pictures import _layout_for_window
    from . import atlas_sets_qgis as ASQ
    layout = _layout_for_window(win)
    if layout is None:
        return
    p = QgsProject.instance()
    why = ASQ.check_layout(p, layout)
    if why:
        _say(win, why, warn=True)
        return
    sets, msg = ASQ.read_sets(p, layout)
    if msg:
        _say(win, "The stored page sets could not be read (%s). Starting from Network only." % msg, warn=True)
    holder = {}
    PageSetsDialog(win, p, sets, holder).exec()
    new = holder.get("sets")
    if new is None:
        return
    if p.isDirty():
        b = QMessageBox.question(win, TITLE, "Save the project before the pages are changed?",
                                 QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Cancel,
                                 QMessageBox.StandardButton.Save)
        if b != QMessageBox.StandardButton.Save or not p.write():
            _say(win, "Nothing changed: the project was not saved.", warn=True)
            return
    try:
        out = ASQ.apply_sets(p, layout, new)
    except ASQ.SetsRefused as e:
        _say(win, str(e), warn=True)
        return
    except Exception as e:
        _say(win, "Nothing changed: %s" % e, warn=True)
        return
    lines = ["The atlas now has %d pages." % out["pages"]]
    lines += out["warnings"]
    lines += [AS.missing_layer_message(t, AS.name_from_layer_id(lid), [x["title"] for x in new["sets"]].index(t) + 1,
                                       ASQ.page_count(layout) // (len(new["sets"]) + 1) - 1)
              for t, lid in out["missing"]]
    _say(win, "\n".join(lines))
