"""Build empty HeroTel standard layers (VN 1).

The layer set, columns and styles are frozen in gold_spec.json and styles/*.qml
by research/vn1_builder/freeze_gold.py; spec_hash.py guards them.
"""
