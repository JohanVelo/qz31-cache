"""apply — the ONLY thing in this package that writes. Backup-gated.

Order matters and is not negotiable:

    1. refuse if the plan is blocked          (duplicates / a broken remap)
    2. BACK UP, or abort                      (no backup -> no write, ever)
    3. renumber the survivors                 (bulk, verified)
    4. delete                                 (last: a failed write leaves the
                                               features still there to retry)
    5. return an undo map

Why renumber BEFORE delete: if the renumber fails half-way we have changed some
labels but destroyed nothing, and the backup restores it. Delete first and a
failed renumber leaves you with missing features AND stale numbers — the worst
of both. `plan.py` already strips edits that target doomed features, so the two
steps never fight.

The backup gate is the lesson from the 🔢 Renumber PONs regression (auto-backup
removed 2026-07-03, leaving a restore button that read a folder nothing wrote).
A renumber can undo days of work; it does not get to run unprotected.
"""


class ApplyResult:
    def __init__(self):
        self.backup_path = ""
        self.renumbered = {}       # layer_id -> features written
        self.deleted = {}          # layer_id -> features removed
        self.errors = []
        self.notes = []            # things that WORKED but the operator must know
        self.layer_names = {}
        self.undo = {}             # layer_id -> {fid: {field_name: old_value}}

    @property
    def ok(self):
        return not self.errors

    @property
    def total_renumbered(self):
        return sum(self.renumbered.values())

    @property
    def total_deleted(self):
        return sum(self.deleted.values())

    def summary_lines(self):
        out = []
        if self.backup_path:
            out.append(f"backup: {self.backup_path}")
        out.extend(self.notes)          # e.g. "the backup went elsewhere, because…"
        for lid, n in self.renumbered.items():
            out.append(f"renumbered {n:,} label(s) in '{self.layer_names.get(lid, lid)}'")
        for lid, n in self.deleted.items():
            out.append(f"deleted {n:,} feature(s) from '{self.layer_names.get(lid, lid)}'")
        return out


def default_backup_path(project):
    """Where the delete/renumber backup zip goes → (path, reason).

    path is '' on failure and `reason` then says WHY, in the operator's words.

    It used to return a bare '' for every failure, and both call sites turned
    that into "the project has not been saved to disk". On the Phalaborwa Benfarm
    project (2026-07-28) that was simply untrue: the project was saved, its folder
    was 232 characters deep, and `<proj>/_renumber_backup/<ts>_delete_renumber.zip`
    reached 285 — past the Windows 260 limit. The operator was sent looking for a
    save problem that did not exist. Same root cause as the Merge PONs backup
    failure fixed the same day; the budget and the fallback location are shared
    with it via fibre_automation.shared.vf_paths so they cannot drift apart.
    """
    import os
    from datetime import datetime

    try:
        from ..shared.vf_paths import choose_backup_root
    except ImportError:                                # pragma: no cover
        from fibre_automation.shared.vf_paths import choose_backup_root

    proj_path = project.fileName() or ""
    d = os.path.dirname(proj_path)
    if not d or not os.path.isdir(d):
        return "", ("the project has not been saved to disk, so there is nowhere "
                    "to put the backup — save the project first")

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    leaf = os.path.join("_renumber_backup", f"{ts}_delete_renumber.zip")
    base, spilled, longest = choose_backup_root(proj_path, [leaf])
    if not base:
        return "", ("the project has not been saved to disk, so there is nowhere "
                    "to put the backup — save the project first")

    root = os.path.join(base, "_renumber_backup")
    try:
        os.makedirs(root, exist_ok=True)
    except OSError as exc:
        hint = ""
        if not spilled and longest > 245:
            hint = (f" — the path would be {longest} characters and Windows "
                    f"allows about 260")
        return "", f"the backup folder could not be created{hint}: {exc}"

    path = os.path.join(root, f"{ts}_delete_renumber.zip")
    if spilled:
        # Say it out loud — a backup that quietly moved is one nobody can find.
        # And be precise about the number: `longest` is the length of the PATH we
        # would have written, not the depth of the project folder. Reporting it as
        # a folder depth sends the operator to measure the wrong thing.
        return path, (f"NOTE: the backup could not be written next to the project "
                      f"— that path would be {longest} characters and Windows "
                      f"allows about 260. It was written to {path} instead.")
    return path, ""


def _field_index(layer, name):
    fields = layer.dataProvider().fields()
    i = fields.indexOf(name)
    if i >= 0:
        return i
    want = str(name).strip().lower()
    for j in range(fields.count()):
        if fields.at(j).name().strip().lower() == want:
            return j
    return -1


_INT_TYPES = ("int", "integer", "integer64", "longlong", "long")
_REAL_TYPES = ("real", "double", "float", "numeric", "decimal")


def _typed(layer, idx, value):
    """Coerce to the column's real type before writing.

    The `id` column is Integer64 — pushing the string "274" into it is not the
    same as writing 274, and depending on the provider it either silently coerces
    or quietly fails. Every edit is computed as text (the number is usually
    embedded in a label), so numeric columns must be converted back on the way in.
    """
    try:
        tn = (layer.dataProvider().fields().at(idx).typeName() or "").lower()
    except Exception:
        return value
    s = str(value).strip()
    try:
        if any(t in tn for t in _INT_TYPES):
            return int(s)
        if any(t in tn for t in _REAL_TYPES):
            return float(s)
    except (TypeError, ValueError):
        return value            # not a bare number — leave it as written
    return value


# claude:intent MUTATE fibre_automation/renumber/apply.py
#   User asked (verbatim, 2026-07-15): "it should do everything because the whole
#   structure is gonna change if we have pon 13,14,15,16 but if we delete 15 then
#   it should renumber it so there is no gaps and a diffrent pon then becomes pon
#   15 understand, and everything refrancing the pon then changes aswell".
#   Plan: delete the ticked PONs (+ whatever the user ticked to cascade into),
#   then rewrite every label whose number moved, so the survivors are 1..N with no
#   gaps and every _SP reference follows its PON. Runs ONLY from an explicit
#   "Back up + Apply" click on a preview the user has already read, and only after
#   a project backup has been written successfully.
#   approved-destructive
def apply_plan(project, plan, backup_path=None, make_backup=True):
    """Write `plan`. Returns ApplyResult. Never raises out."""
    from qgis.core import QgsProject
    try:
        from ..project_backup import backup_project
    except ImportError:                       # pragma: no cover - flat import
        from fibre_automation.project_backup import backup_project
    try:
        from ..safety.safe_writes import safe_bulk_edit, safe_delete
    except ImportError:                       # pragma: no cover
        from fibre_automation.safety.safe_writes import safe_bulk_edit, safe_delete

    project = project or QgsProject.instance()
    res = ApplyResult()

    # ── 1. a blocked plan is not a plan
    if not plan.ok:
        res.errors.append("Nothing was changed — the plan is blocked:\n  • "
                          + "\n  • ".join(plan.blocked))
        return res
    if not plan.edits and not plan.deletions:
        res.errors.append("Nothing to do.")
        return res

    # ── 2. BACK UP OR ABORT
    if make_backup:
        why = ""
        path = backup_path
        if not path:
            path, why = default_backup_path(project)
        if not path:
            # Quote the REASON. Do not assume it is an unsaved project — it may be
            # a path Windows will not accept, which is a different fix entirely.
            res.errors.append(f"Nothing was changed — no backup could be made: {why}")
            return res
        if why.startswith("NOTE:"):
            res.notes.append(why)
        try:
            bk = backup_project(project, path)
        except Exception as exc:
            res.errors.append(f"Nothing was changed — the backup failed: {exc}")
            return res
        if not bk.get("ok"):
            res.errors.append("Nothing was changed — the backup failed, so the "
                              f"write was not attempted: {bk.get('msg', '?')}")
            return res
        res.backup_path = bk.get("path", path)

    # ── 3. RENUMBER (bulk per layer, verified by safe_bulk_edit)
    for lid, edits in plan.edits_by_layer().items():
        lyr = project.mapLayer(lid)
        if lyr is None or not lyr.isValid():
            res.errors.append(f"'{plan.layer_names.get(lid, lid)}' is no longer in "
                              f"the project — its labels were not renumbered.")
            continue
        res.layer_names[lid] = lyr.name()
        attr_map, undo = {}, {}
        bad_field = None
        for e in edits:
            idx = _field_index(lyr, e.field)
            if idx < 0:
                bad_field = e.field
                break
            attr_map.setdefault(e.fid, {})[idx] = _typed(lyr, idx, e.new)
            undo.setdefault(e.fid, {})[e.field] = _typed(lyr, idx, e.old)
        if bad_field is not None:
            res.errors.append(f"'{lyr.name()}': field '{bad_field}' is missing — "
                              f"that layer was left unchanged.")
            continue
        try:
            n = safe_bulk_edit(lyr, attr_map, on_error="abort")
        except Exception as exc:
            res.errors.append(f"'{lyr.name()}': the renumber write failed ({exc}). "
                              f"Restore from the backup before retrying.")
            continue
        res.renumbered[lid] = n
        res.undo[lid] = undo
        try:
            lyr.triggerRepaint()
        except Exception:
            pass

    # a failed renumber must not be followed by a delete — stop while the data is
    # still whole and the backup still matches what is on disk
    if res.errors:
        res.errors.append("The delete was skipped because the renumber did not "
                          "complete cleanly.")
        return res

    # ── 4. DELETE (last)
    for d in plan.deletions:
        lyr = project.mapLayer(d.layer_id)
        if lyr is None or not lyr.isValid():
            res.errors.append(f"'{d.layer_name}' is no longer in the project — "
                              f"nothing was deleted from it.")
            continue
        res.layer_names[d.layer_id] = lyr.name()
        _note_operator_delete(lyr, len(d))
        try:
            n = safe_delete(lyr, d.fids, on_error="abort")
        except Exception as exc:
            res.errors.append(f"'{lyr.name()}': the delete failed ({exc}).")
            continue
        res.deleted[d.layer_id] = n

    return res


def _note_operator_delete(layer, n):
    """Tell the Geometry Guardian this delete is intentional.

    Without it the guardian sees a mass feature loss and tries to auto-restore
    the very features the user just asked to remove. NB the signature is
    note_operator_delete(LAYER_ID, n) — it takes the id string, not the layer.
    """
    try:
        lid = layer.id()
    except Exception:
        return
    for mod in ("FiberNetworkAutomation.geometry_guardian", "geometry_guardian"):
        try:
            g = __import__(mod, fromlist=["note_operator_delete"])
            fn = getattr(g, "note_operator_delete", None)
            if fn:
                fn(lid, n)
                return
        except Exception:
            continue


def undo_plan(project, result):
    """Put back what `apply_plan` renumbered (attributes only). → (ok, msg).

    REFUSES once anything was deleted. The undo map is keyed on feature ids
    captured BEFORE the delete, and an OGR/shapefile delete renumbers the ids —
    so replaying those attributes afterwards would write every value onto the
    WRONG feature. Same class of bug as the GPKG-fid restore (8/8 shifted by one).
    Deletions are what the backup zip is for; a half-undo that corrupts is worse
    than an honest "use the backup".
    """
    from qgis.core import QgsProject
    try:
        from ..safety.safe_writes import safe_bulk_edit
    except ImportError:                       # pragma: no cover
        from fibre_automation.safety.safe_writes import safe_bulk_edit
    project = project or QgsProject.instance()

    if result.deleted:
        return False, (
            f"In-session undo is not safe here — {result.total_deleted:,} "
            f"feature(s) were deleted, and deleting renumbers the remaining "
            f"feature ids, so putting the old labels back would land them on the "
            f"wrong features.\n\nRestore from the backup instead:\n"
            f"{result.backup_path}")

    n_total, errs = 0, []
    for lid, undo in (result.undo or {}).items():
        lyr = project.mapLayer(lid)
        if lyr is None or not lyr.isValid():
            errs.append(f"'{result.layer_names.get(lid, lid)}' is gone.")
            continue
        attr_map = {}
        for fid, fields in undo.items():
            for fname, old in fields.items():
                idx = _field_index(lyr, fname)
                if idx >= 0:
                    attr_map.setdefault(fid, {})[idx] = old
        try:
            n_total += safe_bulk_edit(lyr, attr_map, on_error="abort")
            lyr.triggerRepaint()
        except Exception as exc:
            errs.append(f"'{lyr.name()}': {exc}")
    if errs:
        return False, ("Undo was incomplete — restore from the backup zip:\n  • "
                       + "\n  • ".join(errs))
    if result.deleted:
        return True, (f"Put back {n_total:,} label(s). NOTE: the "
                      f"{result.total_deleted:,} deleted feature(s) were NOT "
                      f"restored — use the backup zip for those:\n"
                      f"{result.backup_path}")
    return True, f"Put back {n_total:,} label(s)."
