"""Rewrite a project's layers onto the canonical names — into a NEW GeoPackage.

Phase 1 only (JJ's decision V3, 2026-09-11):

    renames layers to the canonical name for their role
    renames fields to the canonical spelling, recovering truncations
    carries every other column through untouched
    writes NOTHING into any value, removes NO column
    never edits a source file — output is always a new GeoPackage

Phase 2 — adding missing fields, dropping tooling residue, folding value
spellings, merging the FS/FTS enclosure layers — is a separate, separately
approved pass. Renaming is reversible and mechanical; changing data is neither,
and smuggling the second in behind the first is how an approved change becomes
an incident.

Plan and apply are separate on purpose
--------------------------------------
``plan()`` returns exactly what ``apply()`` will do, as data. The button shows
the plan, JJ approves the plan, and the same object is executed. A preview
computed by different code from the thing that runs is a preview that can
disagree with reality, and the whole point of the gate is that it cannot.

    plans  = plan(views, schema, town="Lulekani")
    report = apply(plans, sources, "out.gpkg")

Verification is by GEOMETRY, never by fid — OGR renumbers fids on write, so a
fid-matched comparison certifies nothing. ``verify()`` compares a multiset of
per-feature WKB digests, which is also order-independent.
"""
from __future__ import annotations

# ⛔ osgeo FIRST. Importing hashlib before it breaks the GDAL DLL load with
# "No module named '_gdal'", which looks exactly like a broken install.
from osgeo import ogr, osr

import hashlib

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

ogr.UseExceptions()

#: Phase 1 touches names only. Anything that would alter a VALUE or remove a
#: COLUMN belongs to phase 2 and is listed in the plan as deferred, so the
#: preview shows what is NOT being done as well as what is.
PHASE_1 = 1

#: Column names a GeoPackage reserves for itself. `fid` IS the primary key, so
#: CreateField("fid") is refused and the column vanishes on write.
#:
#: Phase 1 promises to remove no column, and this is the one honest exception:
#: it is storage plumbing, not design data, and it cannot be carried into a new
#: GeoPackage by any means. What matters is that the loss is DECLARED - it shows
#: up in the plan and in the report - rather than discovered later by someone
#: wondering where a column went. Found by verify() on real Lulekani data, where
#: it silently failed the field check.
RESERVED_FIELDS = frozenset({"fid", "ogc_fid", "geom", "geometry"})


def _resolver():
    try:
        from ..network_planner import layer_names
    except (ImportError, ValueError):
        try:
            from FiberNetworkAutomation.network_planner import layer_names
        except ImportError:
            import layer_names
    return layer_names


def _norm(name):
    return " ".join(str(name or "").split()).strip().lower()


def _alias_map(schema):
    """{alias -> canonical field name}. Mirrors validate._alias_map exactly.

    ⛔ `pole_height_alias_watch` maps to pole_height, NOT pole_thickness. Its
    members hold a pole HEIGHT ("7m") while a neighbouring `Pole Thick` holds
    the diameter. Mapping them onto thickness would silently turn a height into
    a diameter in the BOQ.
    """
    out = {}
    for canon, aliases in (schema.get("truncation_aliases") or {}).items():
        for a in aliases:
            out[_norm(a)] = canon
    for canon, aliases in (schema.get("spelling_aliases") or {}).items():
        target = "pole_height" if canon == "pole_height_alias_watch" else canon
        for a in aliases:
            out[_norm(a)] = target
    return out


#: Roles whose two canonical names are KNOWN to differ, as measured 2026-09-12.
#: left = schema.yaml (wins, derived by measurement across six projects)
#: right = layer_names.NEW_NAMES (the plugin's own v1 emission)
#: ⛔ This is a RECORD OF A DISAGREEMENT, not an approval of it. Which family is
#: canonical is JJ's naming call. Pinning it here means a NEW divergence, or a
#: change to one of these, fails a test instead of quietly shipping.
KNOWN_NAME_DIVERGENCE = {
    "distribution_cable": ("Distribution Cables", "Distribution Cable"),
    "drop_cable": ("PON Drop Cables", "Drop Cable"),
    "feeder_cable": ("Feeder Cables", "Feeder Cable"),
    "feeder_joint": ("Feeder Enclosures", "Feeder Joints"),
    "fts_splitter": ("First Tier Splitters", "FTS Splitters"),
    "pon": ("PON Zone Boundaries", "PON"),
    "splitter_point": ("PON Splitter Points", "Splitter Points"),
}


def name_table_divergence(schema):
    """{role: (schema name, resolver name)} for every role the two tables
    describe differently. Empty means they agree everywhere."""
    ln = _resolver()
    out = {}
    for spec in schema.get("layers") or []:
        role, schema_name = spec.get("role"), spec.get("name")
        other = getattr(ln, "NEW_NAMES", {}).get(role)
        if other and schema_name and other != schema_name:
            out[role] = (schema_name, other)
    return out


def assert_name_tables_agree(schema):
    """Raise if the schema and the resolver disagree in a way nobody recorded.

    Two tables of canonical names is the exact hazard schema.yaml's own header
    calls out. They cannot be merged without a naming decision, so the next best
    thing is that the disagreement is pinned: an unrecorded one is a failure.
    """
    found = name_table_divergence(schema)
    problems = []
    for role, pair in sorted(found.items()):
        known = KNOWN_NAME_DIVERGENCE.get(role)
        if known is None:
            problems.append("NEW divergence for %r: schema %r vs resolver %r"
                            % (role, pair[0], pair[1]))
        elif tuple(known) != tuple(pair):
            problems.append("divergence for %r CHANGED: was %r, now %r"
                            % (role, known, pair))
    for role in sorted(set(KNOWN_NAME_DIVERGENCE) - set(found)):
        problems.append("%r no longer diverges — delete it from "
                        "KNOWN_NAME_DIVERGENCE" % role)
    if problems:
        raise AssertionError("canonical name tables are unsafe:\n  "
                             + "\n  ".join(problems))
    return True


def canonical_name(role, spec=None):
    """The name a layer of ``role`` must be written under.

    Two tables can answer this, and they do not agree:

      * `schema.yaml` names 15 roles, derived by measurement across six projects;
      * `layer_names.NEW_NAMES` names all 43, the plugin's own v1 emission.

    Taking only the schema meant just 15 of 43 roles could ever be renamed —
    poles, manholes, ducts, spans and ONT were carried through untouched — even
    though `layer_names` names them perfectly well. And the two had already
    drifted apart for 7 roles, which is exactly the "two alias tables disagree
    within a week" that schema.yaml's own header warns about.

    ⛔ PRECEDENCE IS DELIBERATE AND IT IS NOT THE OBVIOUS ONE. schema.yaml's
    header says identity does not live there, which argues for the resolver
    winning — but it does NOT win here. The schema entry wins where it exists
    and the resolver only fills the gap. Those 15 schema names
    were derived by measurement across six projects, and re-pointing them at
    `layer_names` would silently rename `PON Zone Boundaries` back to `PON` for
    every role the benchmark had already settled — a naming change dressed up as
    a coverage fix.

    So this closes the coverage hole ONLY: the 28 roles the schema never
    described can now be renamed, and not one of the 15 it did describe moves.
    ⚠ The two tables genuinely disagree for 7 roles (`drop_cable` is
    `Drop Cable` here and `PON Drop Cables` there). That is a naming POLICY
    question for JJ, reported not decided, and `assert_name_tables_agree()`
    pins the current divergence so it cannot widen unnoticed.
    """
    if spec and spec.get("name"):
        return spec["name"]
    ln = _resolver()
    try:
        if role in getattr(ln, "NEW_NAMES", {}):
            return ln.new_layer_name(role)
    except Exception:
        _swallowed_note()
    return None


def plan(views, schema, town=None, phase=PHASE_1):
    """What the rewrite WOULD do, as data. Reads nothing but the views.

    One entry per layer that resolves to a role. A layer with no role is not
    planned at all — it is carried through untouched and reported, never
    renamed on a guess.

    A role the resolver knows but the schema does not is still RENAMED: its
    identity is known even when its content is not. Only the field work needs
    a schema entry.
    """
    ln = _resolver()
    aliases = _alias_map(schema)
    by_role = {}
    for spec in schema.get("layers") or []:
        by_role[spec["role"]] = spec

    seen_role = {}
    plans = []
    for view in views:
        role = ln.role_of(view.name, town)
        spec = by_role.get(role) if role else None
        dst = canonical_name(role, spec) if role else None
        if dst is None:
            plans.append({
                "src": view.name, "role": role, "dst": view.name,
                "action": "carry-through",
                "why": ("no role — left exactly as it is" if role is None
                        else "role %r has no canonical name" % role),
                "fields": {}, "deferred": [], "blocked": None,
            })
            continue

        # Two layers for one role: renaming both onto one name would silently
        # overwrite one with the other inside the destination GeoPackage.
        first = seen_role.get(role)
        seen_role.setdefault(role, view.name)

        renames, deferred = {}, []
        if spec is None:
            # Known identity, unknown content. Rename it and say plainly that
            # nothing was checked inside it — silence would read as "clean".
            plans.append({
                "src": view.name, "role": role, "dst": dst,
                # ⛔ Compare the RAW name, not the stripped one. A live layer
                # really is called 'Trenching ' with a trailing space; `apply`
                # writes it as 'Trenching' either way, so calling that
                # "unchanged" told the operator the opposite of the truth.
                "action": "rename" if view.name != dst else "unchanged",
                "why": "role %r has no schema entry — renamed only, fields "
                       "not inspected" % role,
                "fields": {}, "deferred": [], "field_clashes": {},
                "reserved_dropped": [],
                "blocked": ("role %r already claimed by %r" % (role, first)
                            if first else None),
            })
            continue
        reserved = [f for f in view.fields if _norm(f) in RESERVED_FIELDS]
        canon_by_field = {}
        for f in view.fields:
            if _norm(f) in RESERVED_FIELDS:
                continue
            canon = aliases.get(_norm(f))
            if canon and canon != f:
                renames[f] = canon
            canon_by_field[canon or f] = f

        for fspec in spec.get("fields") or []:
            if fspec["name"] not in canon_by_field:
                deferred.append("phase 2: add missing field %r" % fspec["name"])
        drop = set()
        for group in (schema.get("drop_fields") or {}).values():
            drop |= {_norm(x) for x in group}
        residue = [f for f in view.fields if _norm(f) in drop]
        if residue:
            deferred.append("phase 2: drop %d tooling field(s): %s"
                            % (len(residue), ", ".join(residue[:6])))

        # A rename that lands on a column the layer already has would destroy
        # one of them. Report it and rename neither.
        existing = {_norm(f) for f in view.fields}
        clashes = {old: new for old, new in renames.items()
                   if _norm(new) in existing and _norm(new) != _norm(old)}
        for old in clashes:
            renames.pop(old)

        plans.append({
            "src": view.name,
            "role": role,
            "dst": dst,
            "action": "rename" if (view.name != dst or renames)
                      else "unchanged",
            "why": None,
            "fields": renames,
            "deferred": deferred,
            "blocked": ("role %r already claimed by %r" % (role, first)
                        if first else None),
            "field_clashes": clashes,
            "reserved_dropped": reserved,
        })
    return plans


def _digest(geom):
    """A stable digest of one geometry. None-safe; null geometry is its own key."""
    if geom is None:
        return "null"
    try:
        return hashlib.sha256(bytes(geom.ExportToWkb())).hexdigest()
    except Exception:
        return "unhashable"


def geometry_multiset(layer):
    """{geometry digest: count} for a layer.

    A multiset, not a list: it is order-independent, so a writer that reorders
    features still compares equal, and it is keyed by GEOMETRY rather than fid,
    which OGR renumbers on write.
    """
    out = {}
    layer.ResetReading()
    for feat in layer:
        d = _digest(feat.GetGeometryRef())
        out[d] = out.get(d, 0) + 1
    layer.ResetReading()
    return out


def apply(plans, open_source, dst_path, schema=None, progress=None):
    """Execute `plans` into a NEW GeoPackage at `dst_path`.

    `open_source(src_name)` returns an open OGR layer for that source layer, or
    None. Injected rather than assumed so this is testable without a project.

    Returns a report carrying, per layer, the source and destination feature
    counts and whether the geometry multiset survived — never a bare boolean.
    """
    drv = ogr.GetDriverByName("GPKG")
    ds = drv.CreateDataSource(dst_path)
    if ds is None:
        return {"ok": False, "layers": [], "msg": "could not create %s" % dst_path}

    out, failed = [], []
    taken = set()
    for i, p in enumerate(plans):
        # ⛔ A BLOCKED LAYER IS CARRIED, NEVER DROPPED. It used to be skipped
        # outright, and the sandbox run on real Malmsbury data showed what that
        # costs: `Muncipality vaults` (10 features) and `HDD Drills` (106) both
        # lose a race for their role and vanished from the output entirely —
        # 116 features destroyed by a NAMING conflict. Leaving a layer's name
        # unstandardised is a cosmetic problem; deleting its data is not.
        # It is copied VERBATIM under its original name: its identity is the
        # thing in dispute, so nothing about it is standardised.
        blocked = p.get("blocked")
        dst_name = p["src"] if blocked else p["dst"]
        renames = {} if blocked else p["fields"]
        if dst_name in taken:
            # Two layers cannot share a name inside one GeoPackage. Suffixing
            # keeps the data; the report says exactly what happened.
            base, k = dst_name, 2
            while dst_name in taken:
                dst_name = "%s (%d)" % (base, k)
                k += 1
        taken.add(dst_name)
        src = None
        try:
            src = open_source(p["src"])
        except Exception as exc:
            failed.append("%s (%s)" % (p["src"], type(exc).__name__))
        if src is None:
            out.append({"src": p["src"], "dst": None, "written": 0,
                        "skipped": "source could not be opened"})
            continue

        src_defn = src.GetLayerDefn()
        srs = src.GetSpatialRef()
        if srs is None:
            srs = osr.SpatialReference()
            srs.ImportFromEPSG(4326)
        dst = ds.CreateLayer(dst_name, srs, src.GetGeomType())

        names = []
        for j in range(src_defn.GetFieldCount()):
            fd = src_defn.GetFieldDefn(j)
            old = fd.GetName()
            if _norm(old) in RESERVED_FIELDS:
                continue          # see RESERVED_FIELDS - declared in the plan
            new = renames.get(old, old)
            nd = ogr.FieldDefn(new, fd.GetType())
            nd.SetWidth(fd.GetWidth())
            nd.SetPrecision(fd.GetPrecision())
            dst.CreateField(nd)
            names.append((old, new))

        dst_defn = dst.GetLayerDefn()
        src.ResetReading()
        n = 0
        dst.StartTransaction()
        for feat in src:
            nf = ogr.Feature(dst_defn)
            g = feat.GetGeometryRef()
            # Clone: the source geometry belongs to the source feature, and
            # handing the pointer over has segfaulted this codebase before.
            nf.SetGeometry(g.Clone() if g is not None else None)
            for old, new in names:
                nf.SetField(new, feat.GetField(old))
            dst.CreateFeature(nf)
            nf = None
            n += 1
        dst.CommitTransaction()

        rec = {"src": p["src"], "dst": dst_name, "written": n,
               "src_count": src.GetFeatureCount(),
               "renamed_fields": dict(renames)}
        if blocked:
            rec["carried_unstandardised"] = blocked
        out.append(rec)
        if progress is not None:
            try:
                progress.setProgress(int((i + 1) / max(1, len(plans)) * 100))
            except Exception:
                _swallowed_note()

    ds = None
    written = [o for o in out if o["dst"]]
    return {"ok": bool(written) and not failed, "layers": out,
            "path": dst_path, "failed": failed,
            "msg": None if not failed else
            "mapping INCOMPLETE — %d layer(s) failed: %s"
            % (len(failed), ", ".join(failed[:5]))}


def verify(plans, open_source, dst_path):
    """Prove the rewrite changed names and NOTHING else.

    Three claims, each reported separately so a pass cannot hide a gap:

        counts      every layer has the same number of features
        geometry    the multiset of per-feature geometry digests is identical
        fields      every source column is present under its planned name

    ⛔ Geometry is compared by DIGEST, never by fid. OGR renumbers fids on
    write; a fid-matched comparison here has certified a wrong result before.
    """
    ds = ogr.Open(dst_path)
    if ds is None:
        return {"ok": False, "msg": "cannot open %s" % dst_path, "layers": []}

    rows, bad = [], []
    for p in plans:
        if p.get("blocked") or p["action"] == "carry-through":
            continue
        dst = ds.GetLayerByName(p["dst"])
        src = open_source(p["src"])
        if dst is None or src is None:
            bad.append("%s: missing after write" % p["src"])
            continue

        sc, dc = src.GetFeatureCount(), dst.GetFeatureCount()
        sg, dg = geometry_multiset(src), geometry_multiset(dst)

        want = set()
        for i in range(src.GetLayerDefn().GetFieldCount()):
            nm = src.GetLayerDefn().GetFieldDefn(i).GetName()
            if _norm(nm) in RESERVED_FIELDS:
                continue          # declared in the plan, never silently lost
            want.add(p["fields"].get(nm, nm))
        have = {dst.GetLayerDefn().GetFieldDefn(i).GetName()
                for i in range(dst.GetLayerDefn().GetFieldCount())}
        missing = sorted(want - have)

        row = {"src": p["src"], "dst": p["dst"],
               "count_ok": sc == dc, "src_count": sc, "dst_count": dc,
               "geometry_ok": sg == dg, "fields_ok": not missing,
               "missing_fields": missing}
        rows.append(row)
        if not (row["count_ok"] and row["geometry_ok"] and row["fields_ok"]):
            bad.append("%s -> %s: %s" % (
                p["src"], p["dst"],
                ", ".join(k for k in ("count_ok", "geometry_ok", "fields_ok")
                          if not row[k])))
    ds = None
    return {"ok": not bad and bool(rows), "layers": rows, "problems": bad,
            "msg": None if not bad else
            "verification FAILED on %d layer(s): %s" % (len(bad), "; ".join(bad[:4]))}


def describe(plans):
    """The plan as lines a human can read before approving it."""
    lines = []
    for p in plans:
        if p.get("blocked"):
            # Not "SKIP" any more — the layer IS written, under its own name.
            # Saying skipped would read as "your data was dropped", which is
            # precisely what this no longer does.
            lines.append("KEPT AS-IS %-32s %s" % (p["src"], p["blocked"]))
            continue
        if p["action"] == "carry-through":
            lines.append("keep     %-34s %s" % (p["src"], p["why"]))
            continue
        # Exact compare, matching `plan`'s own action. Stripping here said
        # "already canonical" about 'Trenching ' while apply was renaming it.
        if p["src"] != p["dst"]:
            lines.append("RENAME   %-34s -> %s" % (p["src"], p["dst"]))
        else:
            lines.append("keep     %-34s (already canonical)" % p["src"])
        for old, new in sorted(p["fields"].items()):
            lines.append("   field %-28s -> %s" % (old, new))
        for old, new in sorted((p.get("field_clashes") or {}).items()):
            lines.append("   ⛔ NOT renaming %r -> %r: the layer already has a "
                         "column by that name" % (old, new))
        for r in p.get("reserved_dropped") or []:
            lines.append("   drop  %-28s GeoPackage reserves this name; it is "
                         "the primary key, not data" % r)
        for d in p["deferred"]:
            lines.append("   defer %s" % d)
    return lines
