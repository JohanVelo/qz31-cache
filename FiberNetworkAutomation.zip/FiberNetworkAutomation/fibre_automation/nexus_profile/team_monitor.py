"""team_monitor — JJ-only dock: who's installed / online / doing what / errors.

Opens only when admin.is_admin(profile) is True (admin username + admin key).
Reads via Admin (owner key, async). Auto-refreshes every 30 s. Tabs:
  Online · Activity · Errors · Installs · Users
Owner actions: deactivate user, issue reset token, mark error resolved,
broadcast announcement.
"""
import time

from qgis.PyQt.QtCore import QTimer
from qgis.PyQt.QtWidgets import (QDockWidget, QHBoxLayout, QInputDialog, QLabel,
                                 QMessageBox, QPushButton, QTableWidget,
                                 QTableWidgetItem, QTabWidget, QVBoxLayout,
                                 QWidget)

from . import admin as admin_mod
from . import config


def _age(iso):
    """Human 'x min ago' from an ISO timestamp."""
    try:
        import datetime
        dt = datetime.datetime.fromisoformat(iso.replace("Z", "+00:00"))
        secs = time.time() - dt.timestamp()
        if secs < 90:
            return "just now"
        if secs < 3600:
            return f"{int(secs // 60)} min ago"
        if secs < 86400:
            return f"{int(secs // 3600)} h ago"
        return f"{int(secs // 86400)} d ago"
    except Exception:
        return "?"


def _is_online(iso):
    try:
        import datetime
        dt = datetime.datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return (time.time() - dt.timestamp()) < config.ONLINE_WINDOW_S
    except Exception:
        return False


class TeamMonitorDock(QDockWidget):
    def __init__(self, iface, backend):
        super().__init__("🛰  Team Monitor", iface.mainWindow())
        self.setObjectName("VelocityNexusTeamMonitor")
        self.iface = iface
        self.admin = admin_mod.Admin(backend)
        self.dry_run = backend.dry_run
        self._build()
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.refresh)
        self._timer.start(30_000)
        self.refresh()

    # ── UI ──────────────────────────────────────────────────────────────────
    def _build(self):
        root = QWidget()
        root.setStyleSheet(
            "QWidget{background:#0F1A30;color:#EAF0FF;}"
            "QTabWidget::pane{border:1px solid #243352;}"
            "QTabBar::tab{background:#141E36;color:#9FB4C8;padding:6px 12px;"
            "border:1px solid #243352;}"
            "QTabBar::tab:selected{background:#1F2C4C;color:#fff;}"
            "QTableWidget{background:#0F1A30;gridline-color:#243352;"
            "color:#EAF0FF;}"
            "QHeaderView::section{background:#141E36;color:#9FB4C8;"
            "border:0;padding:4px;}"
            "QPushButton{background:#2ec4f1;color:#06121c;border:none;"
            "border-radius:6px;padding:6px 12px;font-weight:700;}"
            "QPushButton:hover{background:#5fd6ff;}"
            "QLabel#status{color:#9FB4C8;font-size:10px;}")
        v = QVBoxLayout(root)
        v.setContentsMargins(8, 8, 8, 8)
        v.setSpacing(6)

        topbar = QHBoxLayout()
        self._status = QLabel("…")
        self._status.setObjectName("status")
        topbar.addWidget(self._status)
        topbar.addStretch(1)
        announce = QPushButton("📢  Announce")
        announce.clicked.connect(self._announce)
        topbar.addWidget(announce)
        refresh = QPushButton("⟳")
        refresh.setFixedWidth(34)
        refresh.clicked.connect(self.refresh)
        topbar.addWidget(refresh)
        v.addLayout(topbar)

        self.tabs = QTabWidget()
        self.t_online = self._table(["", "User", "Project", "Tool", "Seen"])
        self.t_activity = self._table(["Time", "User", "Action", "Project"])
        self.t_errors = self._table(["Time", "User", "Error", "Tool", ""])
        self.t_installs = self._table(["User", "Version", "QGIS", "Last seen"])
        self.t_users = self._table(["User", "Active", "Since", ""])
        self.tabs.addTab(self.t_online, "● Online")
        self.tabs.addTab(self.t_activity, "Activity")
        self.tabs.addTab(self.t_errors, "Errors")
        self.tabs.addTab(self.t_installs, "Installs")
        self.tabs.addTab(self.t_users, "Users")
        v.addWidget(self.tabs)
        self.setWidget(root)

    def _table(self, headers):
        t = QTableWidget(0, len(headers))
        t.setHorizontalHeaderLabels(headers)
        t.verticalHeader().setVisible(False)
        t.setEditTriggers(QTableWidget.NoEditTriggers)
        t.setSelectionBehavior(QTableWidget.SelectRows)
        t.horizontalHeader().setStretchLastSection(True)
        return t

    # ── refresh ─────────────────────────────────────────────────────────────
    def refresh(self):
        if self.dry_run:
            self._status.setText(
                "Dry-run mode — backend not configured yet. Live data appears "
                "once Supabase is connected.")
            return
        self._status.setText("Refreshing…")
        # events first → cache latest action per user → then online (so the
        # Online tab can show each person's current project/tool from events).
        self.admin.recent_events(self._on_events)
        self.admin.recent_errors(self._fill_errors)
        self.admin.installs(self._fill_installs)
        self.admin.users(self._fill_users)

    def _on_events(self, rows):
        rows = rows or []
        self._fill_activity(rows)
        latest = {}
        for r in rows:                      # rows are inserted_at desc → 1st wins
            u = r.get("username")
            if u and u not in latest:
                latest[u] = r
        self._latest_by_user = latest
        self.admin.online_now(self._fill_online)

    def _set_rows(self, table, rows, render):
        table.setRowCount(0)
        for r in rows or []:
            i = table.rowCount()
            table.insertRow(i)
            render(table, i, r)

    def _fill_online(self, rows):
        latest = getattr(self, "_latest_by_user", {})
        rows = [r for r in (rows or [])
                if _is_online(r.get("last_heartbeat", ""))]
        self._status.setText(
            f"{len(rows)} online · updated {time.strftime('%H:%M')}")

        def render(t, i, r):
            u = r.get("username", "")
            ev = latest.get(u, {})
            dot = QTableWidgetItem("●")
            dot.setForeground(_qcolor("#2ABFCC"))
            t.setItem(i, 0, dot)
            t.setItem(i, 1, QTableWidgetItem(u))
            t.setItem(i, 2, QTableWidgetItem(ev.get("project_name") or "—"))
            t.setItem(i, 3, QTableWidgetItem(ev.get("action_id") or "—"))
            t.setItem(i, 4, QTableWidgetItem(_age(r.get("last_heartbeat", ""))))
        self._set_rows(self.t_online, rows, render)

    def _fill_activity(self, rows):
        def render(t, i, r):
            t.setItem(i, 0, QTableWidgetItem(_age(r.get("inserted_at", ""))))
            t.setItem(i, 1, QTableWidgetItem(r.get("username", "")))
            t.setItem(i, 2, QTableWidgetItem(r.get("action_id", "")))
            t.setItem(i, 3, QTableWidgetItem(r.get("project_name") or "—"))
        self._set_rows(self.t_activity, rows, render)

    def _fill_errors(self, rows):
        def render(t, i, r):
            t.setItem(i, 0, QTableWidgetItem(_age(r.get("inserted_at", ""))))
            t.setItem(i, 1, QTableWidgetItem(r.get("username", "")))
            msg = QTableWidgetItem(r.get("error_message", ""))
            if r.get("resolved"):
                msg.setForeground(_qcolor("#5E6E92"))
            t.setItem(i, 2, msg)
            t.setItem(i, 3, QTableWidgetItem(r.get("active_tool") or "—"))
            btn = QPushButton("Details")
            btn.clicked.connect(lambda _=False, row=r: self._error_detail(row))
            t.setCellWidget(i, 4, btn)
        self._set_rows(self.t_errors, rows, render)

    def _fill_installs(self, rows):
        def render(t, i, r):
            t.setItem(i, 0, QTableWidgetItem(r.get("username") or "—"))
            t.setItem(i, 1, QTableWidgetItem("v" + str(r.get("plugin_version", ""))))
            t.setItem(i, 2, QTableWidgetItem(r.get("qgis_version") or "—"))
            t.setItem(i, 3, QTableWidgetItem(_age(r.get("last_heartbeat", ""))))
        self._set_rows(self.t_installs, rows, render)

    def _fill_users(self, rows):
        def render(t, i, r):
            t.setItem(i, 0, QTableWidgetItem(r.get("username", "")))
            act = QTableWidgetItem("yes" if r.get("is_active") else "NO")
            act.setForeground(_qcolor("#2ABFCC" if r.get("is_active")
                                      else "#E0607A"))
            t.setItem(i, 1, act)
            t.setItem(i, 2, QTableWidgetItem(_age(r.get("created_at", ""))))
            w = QWidget()
            h = QHBoxLayout(w)
            h.setContentsMargins(0, 0, 0, 0)
            tok = QPushButton("Reset token")
            tok.clicked.connect(lambda _=False, u=r.get("username"):
                                self._reset_token(u))
            deact = QPushButton("Deactivate" if r.get("is_active") else "Enable")
            deact.clicked.connect(
                lambda _=False, u=r.get("username"), a=r.get("is_active"):
                self._toggle_active(u, not a))
            h.addWidget(tok)
            h.addWidget(deact)
            t.setCellWidget(i, 3, w)
        self._set_rows(self.t_users, rows, render)

    # ── owner actions ───────────────────────────────────────────────────────
    def _error_detail(self, r):
        bc = r.get("breadcrumbs") or []
        trail = "\n".join(f"  • {c.get('action_id')} "
                          f"({c.get('category')})" for c in bc) or "  (none)"
        text = (f"User: {r.get('username')}\n"
                f"When: {r.get('inserted_at')}\n"
                f"Project: {r.get('project_name') or '—'}\n"
                f"Tool: {r.get('active_tool') or '—'}\n"
                f"Plugin v{r.get('plugin_version')} · QGIS "
                f"{r.get('qgis_version')}\n\n"
                f"Error: {r.get('error_message')}\n\n"
                f"What they were doing (breadcrumbs):\n{trail}\n\n"
                f"Note from user: {r.get('user_note') or '—'}\n\n"
                f"--- traceback ---\n{r.get('error_traceback') or ''}")
        box = QMessageBox(self)
        box.setWindowTitle("Error details")
        box.setText(text)
        resolve = box.addButton("Mark resolved", QMessageBox.AcceptRole)
        box.addButton(QMessageBox.Close)
        box.exec()
        if box.clickedButton() is resolve and r.get("error_id"):
            self.admin.mark_error_resolved(
                r["error_id"], True, lambda ok: self.refresh())

    def _reset_token(self, username):
        def done(token):
            if token:
                QMessageBox.information(
                    self, "Reset token",
                    f"Give {username} this one-time code (valid 1 hour):\n\n"
                    f"    {token}\n\nThey enter it with a new password to "
                    "regain access.")
            else:
                QMessageBox.warning(self, "Reset token",
                                    "Could not issue a token (offline?).")
        self.admin.issue_reset_token(username, cb=done)

    def _toggle_active(self, username, active):
        verb = "enable" if active else "deactivate"
        if QMessageBox.question(
                self, "Confirm",
                f"{verb.capitalize()} {username}?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No) != QMessageBox.Yes:
            return
        self.admin.deactivate(username, active, lambda ok: self.refresh())

    def _announce(self):
        title, ok = QInputDialog.getText(self, "Announce", "Title:")
        if not ok or not title.strip():
            return
        msg, ok = QInputDialog.getText(self, "Announce", "Message:")
        if not ok or not msg.strip():
            return
        self.admin.announce(
            title.strip(), msg.strip(),
            cb=lambda ok2: QMessageBox.information(
                self, "Announce",
                "Sent to everyone." if ok2 else "Failed (offline?)."))

    def closeEvent(self, event):
        try:
            self._timer.stop()
            self._timer.deleteLater()
        except Exception:
            pass
        super().closeEvent(event)


def _qcolor(hexv):
    from qgis.PyQt.QtGui import QColor
    return QColor(hexv)
