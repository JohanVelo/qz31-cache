"""engine — the reliable BoQ pipeline: discover → measure(UTM) → wastage → rate → validate.

The reliability core is measure_length_m(): it ALWAYS reprojects to a projected
CRS (UTM) before QgsDistanceArea.measureLength, so a length is never read in
EPSG:4326 degrees. Plus null-geom skipping (never counted as 0), cross-layer
duplicate-label detection, and domain cross-checks (drop≈ONT, m/ONT sanity).
"""


def _safe_ellipsoid(project, crs=None):
    """Never 'NONE' — see fibre_automation/shared/crs_utils.safe_ellipsoid.

    QgsProject.ellipsoid() returns the STRING 'NONE' for a project with no
    ellipsoid (QGIS's default for a new project). 'NONE' is truthy, so
    `project.ellipsoid() or "WGS84"` did NOT fall back and lengths came back in
    DEGREES — a 1976 m cable measuring 0.019. Found 2026-07-15.
    """
    try:
        from fibre_automation.shared.crs_utils import safe_ellipsoid
        return safe_ellipsoid(project, crs)
    except Exception:
        pass
    for get in (lambda: project.ellipsoid(),
                (lambda: crs.ellipsoidAcronym()) if crs is not None else None):
        if get is None:
            continue
        try:
            v = (get() or "").strip()
        except Exception:
            continue
        if v and v.upper() != "NONE":
            return v
    return "WGS84"
import json
import math
import os

from .constants import (DEFAULT_RULES, MOA_UTM, SANE_M_PER_ONT,
                        SECTION_CABLE, SECTION_ONT)

_HERE = os.path.dirname(os.path.abspath(__file__))
_USER_RATES = os.path.join(os.path.expanduser("~"), ".velocity_nexus", "boq_rates.json")
_DEFAULT_RATES = os.path.join(_HERE, "boq_rates_default.json")


class BoQResult:
    def __init__(self):
        self.lines = []          # priced line items
        self.audit = []          # {check, status(OK/WARN/GATE/BLOCK), detail}
        self.blocked = []        # null/invalid geometries (layer, fid)
        self.missing = []        # required layers not found
        self.meta = {}
        self.verdict = "OK"      # OK | REVIEW | FAIL

    def add_audit(self, check, status, detail):
        self.audit.append({"check": check, "status": status, "detail": detail})


# ── rates ───────────────────────────────────────────────────────────────────
def load_rates():
    """User rates if present, else bundled default. Never raises."""
    for p in (_USER_RATES, _DEFAULT_RATES):
        try:
            with open(p, encoding="utf-8") as f:
                d = json.load(f)
            d["_path"] = p
            return d
        except FileNotFoundError:
            continue                      # expected when no user override exists
        except Exception as e:
            # a present-but-malformed rates file should NOT silently vanish
            try:
                print(f"[BoQ] rates file '{p}' is invalid ({e}); using the next source")
            except Exception:
                pass
            continue
    return {"MATERIALS": {}, "LABOUR": {}, "_path": "(none)"}


def _rate_for(rates, rate_key):
    for sect in ("MATERIALS", "LABOUR"):
        r = (rates.get(sect) or {}).get(rate_key)
        if r and r.get("rate") is not None:
            return r.get("rate"), r.get("source", sect)
    return None, None


# ── measurement (the reliability primitive) ───────────────────────────────────
def _utm_measurer(project):
    from qgis.core import QgsCoordinateReferenceSystem, QgsDistanceArea, QgsUnitTypes
    da = QgsDistanceArea()
    utm = QgsCoordinateReferenceSystem(MOA_UTM)
    da.setSourceCrs(utm, project.transformContext())
    try:
        da.setEllipsoid(_safe_ellipsoid(project, utm))
    except Exception:
        da.setEllipsoid("WGS84")
    return da, utm, QgsUnitTypes


def _measure_length_m(geom, layer_crs, utm, project):
    """Geodesic (ellipsoidal) length in metres on the layer's OWN CRS.

    None for null/empty/non-finite (caller records it as blocked).

    Was: reproject into a hardcoded UTM 35S (MOA_UTM) and measure PLANAR — the
    QgsDistanceArea built here never got an ellipsoid, so the properly-configured
    one from _utm_measurer was silently discarded. UTM 35S covers 24-30°E: right
    for Mohadin (27°E), WRONG for Malmsbury (18.7°E = zone 34S). Measuring ~8°
    outside the zone, the transverse-Mercator scale factor stretches distances and
    the PRICED BoQ over-measured Malmsbury cable by +192 m (+0.697%) on feeder +
    distribution alone — money, on every non-35S (Western Cape) project.

    Ellipsoidal measurement is zone-independent and matched the surveyed `Tlenght`
    recorded in the data to +0.000% over 27.5 km — the same path the take-off has
    always used, which is why the take-off was exact and the priced engine was not.

    `utm` stays in the signature (callers/tests pass it); it is no longer used.
    JJ approved this output-changing fix 2026-07-16. See research/boq_verify/.
    """
    if geom is None or geom.isEmpty():
        return None
    try:
        from fibre_automation.shared.crs_utils import metre_measurer
        da = metre_measurer(layer_crs, project)
    except Exception:
        from qgis.core import QgsDistanceArea
        da = QgsDistanceArea()
        da.setSourceCrs(layer_crs, project.transformContext())
        try:
            da.setEllipsoid(_safe_ellipsoid(project, layer_crs))
        except Exception:
            da.setEllipsoid("WGS84")
    v = da.measureLength(geom)
    if v is None or not math.isfinite(v) or v < 0:
        return None
    return v


def _find_layer(project, tokens, exclude):
    from qgis.core import QgsVectorLayer
    toks = [t.lower() for t in tokens]
    exc = [e.lower() for e in exclude]
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
            continue
        name = lyr.name().lower()
        if all(t in name for t in toks) and not any(e in name for e in exc):
            return lyr
    return None


def _attr(feat, name):
    try:
        v = feat[name]
        if v is None:
            return None
        return v
    except Exception:
        return None


# ── pipeline ──────────────────────────────────────────────────────────────────
def run(project=None, rules=None, rates=None, aoi=None):
    """Run the BoQ pipeline against the live QGIS project. Returns a BoQResult."""
    from qgis.core import QgsProject
    project = project or QgsProject.instance()
    rules = rules or DEFAULT_RULES
    rates = rates or load_rates()
    res = BoQResult()
    res.meta = {
        "project": project.baseName() or "(unsaved)",
        # lengths are measured ellipsoidally on each layer's own CRS (zone-independent);
        # this is NOT MOA_UTM any more — see _measure_length_m
        "crs_measure": "ellipsoidal (geodesic, per-layer CRS)",
        "rates_path": rates.get("_path"),
        "rates_supplier": (rates.get("meta") or {}).get("supplier"),
    }

    da, utm, _ = _utm_measurer(project)
    seen_cable_labels = {}      # label -> layer (cross-layer double-count guard)
    ont_count = 0
    drop_count = 0
    total_cable_measured = 0.0

    for rule in rules:
        lyr = _find_layer(project, rule.layer_tokens, rule.exclude_tokens)
        if lyr is None:
            res.missing.append(rule.key)
            continue

        if lyr.crs().isGeographic():
            res.add_audit(f"CRS::{rule.key}", "OK",
                          f"{lyr.name()} is {lyr.crs().authid()} (geographic) → "
                          f"measured ellipsoidally (geodesic metres, zone-independent)")

        # one-shot WARN if a configured group_by/dedup_by field is missing here
        lyr_field_names = {f.name() for f in lyr.fields()}
        if rule.group_by and rule.group_by not in lyr_field_names:
            res.add_audit(f"field::{rule.key}", "WARN",
                          f"group_by field '{rule.group_by}' missing on "
                          f"'{lyr.name()}' — grouping disabled (all rows '(unset)')")
        if (rule.measure == "length" and rule.dedup_by
                and rule.dedup_by not in lyr_field_names):
            res.add_audit(f"field::{rule.key}", "WARN",
                          f"dedup_by field '{rule.dedup_by}' missing on "
                          f"'{lyr.name()}' — double-count guard disabled")

        # group_value -> {count, measured_m, fids:[]}
        groups = {}
        layer_labels = {}      # label -> fid (within-layer double-draw guard)
        for feat in lyr.getFeatures():
            geom = feat.geometry()
            gv = _attr(feat, rule.group_by) if rule.group_by else "(all)"
            gv = "(unset)" if gv is None else str(gv)
            g = groups.setdefault(gv, {"count": 0, "measured_m": 0.0, "fids": []})
            if rule.measure == "length":
                m = _measure_length_m(geom, lyr.crs(), utm, project)
                if m is None:
                    res.blocked.append({"layer": lyr.name(), "fid": feat.id(),
                                        "reason": "null/empty geometry",
                                        "section": rule.section})
                    continue
                g["measured_m"] += m
                g["count"] += 1
                g["fids"].append(feat.id())
                # duplicate-label guard (within-layer double-draw + cross-layer)
                lbl = _attr(feat, rule.dedup_by) if rule.dedup_by else None
                if lbl is not None:
                    skey = str(lbl)
                    if skey in layer_labels:
                        res.add_audit("dedup", "GATE",
                                      f"label '{lbl}' appears on multiple features in "
                                      f"'{lyr.name()}' (fids {layer_labels[skey]} & "
                                      f"{feat.id()}) — length double-counted")
                    else:
                        layer_labels[skey] = feat.id()
                    prev = seen_cable_labels.get(skey)
                    if prev and prev != lyr.name():
                        res.add_audit("dedup", "GATE",
                                      f"label '{lbl}' appears in BOTH '{prev}' and "
                                      f"'{lyr.name()}' — possible double-count")
                    seen_cable_labels[skey] = lyr.name()
            else:  # count
                if geom is None or geom.isEmpty():
                    res.blocked.append({"layer": lyr.name(), "fid": feat.id(),
                                        "reason": "null/empty geometry",
                                        "section": rule.section})
                    # still count it (a splitter/pole with no geom is still bought) but flag
                g["count"] += 1
                g["fids"].append(feat.id())

        # build priced lines per group
        for gv, g in sorted(groups.items()):
            rate, src = _rate_for(rates, rule.rkey())
            if rule.measure == "length":
                measured = round(g["measured_m"], 1)
                installed = measured * (1.0 + rule.sag_pct)
                ordered = round(installed * (1.0 + rule.slack_pct), 1)
                spools = (math.ceil(ordered / rule.spool_size_m)
                          if rule.spool_size_m else None)
                total_cable_measured += measured
                if rule.key == "drop_1F":
                    drop_count += g["count"]
                res.lines.append({
                    "section": rule.section, "key": rule.key, "group": gv,
                    "desc": f"{lyr.name()} [{gv}]",
                    "unit": "m", "count": g["count"],
                    "measured_m": measured,
                    "installed_m": round(installed, 1),
                    "ordered_m": ordered,
                    "spools": spools,
                    "qty": ordered, "rate": rate, "rate_source": src,
                    "amount": (round(ordered * rate, 2) if rate is not None else None),
                    "fids": g["fids"],
                })
            else:
                if rule.section == SECTION_ONT:
                    ont_count += g["count"]
                res.lines.append({
                    "section": rule.section, "key": rule.key, "group": gv,
                    "desc": f"{lyr.name()} [{gv}]",
                    "unit": "ea", "count": g["count"],
                    "qty": g["count"], "rate": rate, "rate_source": src,
                    "amount": (round(g["count"] * rate, 2) if rate is not None else None),
                    "fids": g["fids"],
                })

    _validate(res, ont_count, drop_count, total_cable_measured)
    return res


def _validate(res, ont_count, drop_count, total_cable_m):
    # missing required layers
    if res.missing:
        res.add_audit("layers", "WARN",
                      f"layers not found (skipped): {', '.join(res.missing)}")
    # null/invalid geometries — null geom in a final CABLE layer cannot be
    # measured, so the BoQ length is understated: that is a hard FAIL (BLOCK).
    # Null geom on a counted item (splitter/pole) is still purchased → GATE only.
    if res.blocked:
        cable_blocked = [b for b in res.blocked if b.get("section") == SECTION_CABLE]
        if cable_blocked:
            res.add_audit("null_geom", "BLOCK",
                          f"{len(cable_blocked)} cable feature(s) with null/empty "
                          f"geometry — length cannot be measured; BoQ understated. "
                          f"e.g. {cable_blocked[:3]}")
        else:
            res.add_audit("null_geom", "GATE",
                          f"{len(res.blocked)} feature(s) with null/empty geometry — "
                          f"e.g. {res.blocked[:3]}")
    else:
        res.add_audit("null_geom", "OK", "no null/empty geometries")
    # missing rates
    tbd = [l["key"] for l in res.lines if l.get("rate") is None]
    if tbd:
        res.add_audit("rates", "WARN",
                      f"{len(tbd)} line(s) have no rate (shown as TBD): {sorted(set(tbd))}")
    # drop ≈ ONT
    if ont_count and drop_count:
        ratio = drop_count / ont_count
        st = "OK" if 0.9 <= ratio <= 1.1 else "GATE"
        res.add_audit("drop_vs_ont", st,
                      f"drops={drop_count} vs ONTs={ont_count} (ratio {ratio:.2f}; "
                      f"expect ~1.0)")
    elif ont_count and not drop_count:
        res.add_audit("drop_vs_ont", "WARN", f"{ont_count} ONTs but no drop cables found")
    # m-of-cable per ONT sanity (catches phantom-length / double-count blowout)
    if ont_count and total_cable_m:
        mpo = total_cable_m / ont_count
        lo, hi = SANE_M_PER_ONT
        # >10x the upper bound is not a borderline design — it is the EPSG:4326
        # degree blowout (~111x) or a gross double-count: hard FAIL (BLOCK).
        if mpo > hi * 10:
            res.add_audit("m_per_ont", "BLOCK",
                          f"{mpo:.0f} m cable / ONT (sane band {lo:.0f}-{hi:.0f}) — "
                          f"more than 10x out of range: almost certainly a "
                          f"degree-vs-metre (EPSG:4326) length bug or a double-count")
        else:
            st = "OK" if lo <= mpo <= hi else "GATE"
            res.add_audit("m_per_ont", st,
                          f"{mpo:.0f} m cable / ONT (sane band {lo:.0f}-{hi:.0f}) — "
                          f"{'OK' if st == 'OK' else 'OUT OF RANGE: check CRS/double-count'}")
    elif ont_count and not total_cable_m:
        # ONTs present but zero measured cable: every cable layer was null/empty,
        # mis-CRS'd, or unmatched — the degenerate case this net exists to catch.
        res.add_audit("m_per_ont", "GATE",
                      f"{ont_count} ONTs present but zero cable measured — "
                      f"check cable layers / CRS / null-geom")
    # verdict
    sevs = {a["status"] for a in res.audit}
    if "BLOCK" in sevs:
        res.verdict = "FAIL"
    elif "GATE" in sevs:
        res.verdict = "REVIEW"
    else:
        res.verdict = "OK"
