# -*- coding: utf-8 -*-
# "Generate HLD PDF" (BETA) — settings dialog + background run + PASS/FAIL report.
# The dialog is modal and short-lived (just collects settings). The heavy render runs
# in a separate QGIS process via a QgsTask, so the live session never freezes.
import os
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QLineEdit,
    QSpinBox, QCheckBox, QPushButton, QFileDialog, QMessageBox, QWidget, QComboBox,
    QListWidget, QListWidgetItem, QScrollArea,
)
from qgis.PyQt.QtCore import Qt
from qgis.core import QgsApplication, QgsProject
from .presets import LOCKED_GRID_W_M, LOCKED_GRID_H_M


def _downloads():
    d = os.path.join(os.path.expanduser("~"), "Downloads")
    return d if os.path.isdir(d) else os.path.expanduser("~")


GRID_COV = "__grid__"
# "one BOOK per phase" — not one page per phase. Picking this builds a separate map book
# for every phase: a shared overview page showing all the phases, then that phase's PONs.
PHASE_COV = "__phases__"


class HldPdfDialog(QDialog):
    DRAW_CODE = 100   # exec() return: the operator asked to draw the grid box on the canvas

    def __init__(self, parent, default_dir, meta, coverage_names, default_coverage,
                 coverage_layers=None, models=None, default_model="hld_atlas",
                 clients=None, default_client="fibertime", count_tables=None,
                 iface=None, cell_w_m=0.0, cell_h_m=0.0, project_layers=None,
                 phase_options=None):
        super().__init__(parent)
        self.setWindowTitle("HLD Map Book  →  Print Layout")
        self.setMinimumWidth(600)
        self._iface = iface
        self._dir = default_dir
        self._title = meta.get("title", "HLD")
        self._cov_by_name = {l.name(): l for l in (coverage_layers or [])}
        self._count_tables = count_tables or []
        self._mode = "layout"     # HLDs now export ONLY via the Print Layout (headless removed)
        self._cell_w_m = float(cell_w_m or 0.0)
        self._cell_h_m = float(cell_h_m or 0.0)

        c = _theme()
        # Resizable dialog: all the settings live in a SCROLL AREA so the window can be any
        # size (drag the edges / the corner grip) and the buttons stay reachable at the bottom
        # even on a short screen. `root` still collects the sections (now inside the scroll).
        self.setSizeGripEnabled(True)
        _outer = QVBoxLayout(self)
        _scroll = QScrollArea()
        _scroll.setWidgetResizable(True)
        _scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        _content = QWidget()
        root = QVBoxLayout(_content)
        _scroll.setWidget(_content)
        _outer.addWidget(_scroll, 1)

        # BETA badge + explainer — colours derived from the live theme, never hardcoded
        badge = QLabel("● BETA")
        badge.setStyleSheet((f"color:{c['warn']};" if c["warn"] else "") + "font-weight:bold;")
        root.addWidget(badge)
        info = QLabel(
            "Builds an A3 map-book — an overview page plus one detail page per unit — "
            "with legend, north arrow, logo and title block.  Choose what each page covers, "
            "the look, and the title block below."
        )
        info.setWordWrap(True)
        if c["ink"]:
            info.setStyleSheet(f"color:{c['ink']};")   # body text: full contrast on any theme
        root.addWidget(info)

        # ── ① WHAT TO MAP (coverage — the per-page driver) ──
        root.addWidget(_section("① WHAT TO MAP  ·  one page per…"))
        covf = QFormLayout()
        self._phase_options = list(phase_options or [])
        self.cov_combo = QComboBox()
        if self._phase_options:
            # first, because it is the whole-deliverable choice: a separate book per phase
            self.cov_combo.addItem(
                f"🗂  One BOOK per PHASE  ({len(self._phase_options)} separate PDFs)", PHASE_COV)
        self.cov_combo.addItem(
            f"▦  Grid over the AOI  ({LOCKED_GRID_W_M:.0f} × {LOCKED_GRID_H_M:.0f} m tiles)", GRID_COV)
        for n in coverage_names:
            self.cov_combo.addItem(n, n)
        # default selection: remembered layer, else grid if a size was captured, else first layer
        if default_coverage == GRID_COV or (self._cell_w_m > 0 and not default_coverage):
            self.cov_combo.setCurrentIndex(self.cov_combo.findData(GRID_COV))
        elif default_coverage and self.cov_combo.findData(default_coverage) >= 0:
            self.cov_combo.setCurrentIndex(self.cov_combo.findData(default_coverage))
        elif coverage_names:
            self.cov_combo.setCurrentIndex(self.cov_combo.findData(coverage_names[0]))
        covf.addRow("Each page shows:", self.cov_combo)

        # grid: FIXED plotting-grid tile size (locked — no longer operator-drawn).
        self.grid_size_lbl = QLabel(
            f"🔒  {LOCKED_GRID_W_M:.0f} × {LOCKED_GRID_H_M:.0f} m  (fixed — standard plotting grid)")
        self.grid_size_lbl.setStyleSheet((f"color:{c['ink']};" if c["ink"] else "") + "font-size:11px;")
        covf.addRow("Grid tile size:", self.grid_size_lbl)
        # phase picker — only meaningful in "one book per phase" mode
        self.phase_list = QListWidget()
        self.phase_list.setMaximumHeight(150)
        self.phase_list.setStyleSheet(
            "QListWidget{font-size:13px;} QListWidget::item{padding:4px 4px;} "
            "QListWidget::indicator{width:16px;height:16px;}")
        for ph in self._phase_options:
            it = QListWidgetItem("Phase %d  —  %s  (%d PONs)"
                                 % (ph["phase_no"], ph["coverage_name"], ph["pon_count"]))
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(Qt.CheckState.Checked)
            it.setData(Qt.ItemDataRole.UserRole, ph["phase_no"])
            self.phase_list.addItem(it)
        self.phase_list.itemChanged.connect(lambda *_: self._on_coverage_changed())
        self.phase_row_label = QLabel("Phases:")
        covf.addRow(self.phase_row_label, self.phase_list)

        self.cov_preview = QLabel("")
        self.cov_preview.setWordWrap(True)
        self.cov_preview.setStyleSheet((f"color:{c['accent']};" if c["accent"] else "") + "font-size:11px;")
        covf.addRow("", self.cov_preview)
        root.addLayout(covf)
        self.cov_combo.currentIndexChanged.connect(self._on_coverage_changed)

        # ── ①½ LAYERS TO SHOW (pick from THIS project; legend built from their symbology) ──
        root.addWidget(_section("① LAYERS  ·  tick what goes in the HLD (legend uses their symbology)"))
        self.layers_list = QListWidget()
        self.layers_list.setMinimumHeight(260)
        self.layers_list.setMaximumHeight(460)
        # bigger, easier-to-tick rows (roomy checkboxes + readable text)
        self.layers_list.setStyleSheet(
            "QListWidget{font-size:13px;} "
            "QListWidget::item{padding:6px 4px;} "
            "QListWidget::indicator{width:18px;height:18px;}")
        for name, visible in (project_layers or []):
            it = QListWidgetItem(name)
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(Qt.CheckState.Checked if visible else Qt.CheckState.Unchecked)
            self.layers_list.addItem(it)
        root.addWidget(self.layers_list)
        lbtns = QHBoxLayout()
        _all = QPushButton("All"); _all.clicked.connect(lambda: self._check_all(True))
        _none = QPushButton("None"); _none.clicked.connect(lambda: self._check_all(False))
        lhint = QLabel("Ticked layers go in the HLD; the legend is built from their symbology.")
        if c["muted"]:
            lhint.setStyleSheet(f"color:{c['muted']};font-size:10px;")
        lbtns.addWidget(_all); lbtns.addWidget(_none); lbtns.addStretch(1); lbtns.addWidget(lhint)
        root.addLayout(lbtns)

        # ── ② LOOK (layout model + client branding) ──
        root.addWidget(_section("② LOOK  ·  layout + branding"))
        mform = QFormLayout()
        self.model_combo = QComboBox()
        for mid, disp, _u in (models or [("hld_atlas", "HLD Network Atlas", False)]):
            self.model_combo.addItem(disp, mid)
        _mi = self.model_combo.findData(default_model)
        if _mi >= 0:
            self.model_combo.setCurrentIndex(_mi)
        mform.addRow("Layout model:", self.model_combo)

        self.client_combo = QComboBox()
        for cid, disp, _u in (clients or [("fibertime", "Fibertime", False)]):
            self.client_combo.addItem(disp, cid)
        _ci = self.client_combo.findData(default_client)
        if _ci >= 0:
            self.client_combo.setCurrentIndex(_ci)
        mform.addRow("Client (branding):", self.client_combo)

        # count-tables editor — only relevant to models that use them (commercial)
        self.counts_btn = QPushButton("Edit count tables…")
        self.counts_btn.clicked.connect(self._edit_counts)
        mform.addRow("Count tables:", self.counts_btn)
        # OFF by default: ticking this lets the engine overwrite the symbology and
        # labelling on the project's own layers with the HLD house style. Untouched,
        # the atlas renders the layers exactly as they are configured right now.
        self.restyle_chk = QCheckBox("Apply the HLD house style to my layers")
        self.restyle_chk.setChecked(False)
        self.restyle_chk.setToolTip(
            "OFF (recommended): the atlas renders your layers exactly as you have "
            "styled and labelled them. ON: the build OVERWRITES the symbology and "
            "labels on your live layers with the standard HLD look — close the "
            "project without saving to undo that.")
        mform.addRow("Layer styling:", self.restyle_chk)
        # One PON per page: QGIS atlas clipping cuts everything outside the page's PON
        # polygon; feeder/primary cables, the basemap and the AOI stay for context.
        self.isolate_chk = QCheckBox("Isolate the PON on each page")
        self.isolate_chk.setChecked(False)
        self.isolate_chk.setToolTip(
            "ON: each detail page shows only its own PON — poles, joints, distribution and "
            "drop cables, erven and neighbouring PONs are clipped at the PON boundary. "
            "Feeder / primary cables, the basemap and the AOI stay whole for context.\n"
            "OFF: pages render everything in view, as before.")
        mform.addRow("Page content:", self.isolate_chk)
        root.addLayout(mform)
        self.model_combo.currentIndexChanged.connect(self._on_model_changed)

        # ── ③ TITLE BLOCK (per-project; auto-filled, editable, remembered) ──
        root.addWidget(_section("③ TITLE BLOCK"))
        form = QFormLayout()
        self.title_edit = QLineEdit(meta.get("title", ""))
        form.addRow("Project title:", self.title_edit)
        self.designer_edit = QLineEdit(meta.get("designer", ""))
        form.addRow("Designer:", self.designer_edit)
        self.company_edit = QLineEdit(meta.get("company", "Velocity Fibre"))
        form.addRow("Company:", self.company_edit)
        self.revision_edit = QLineEdit(str(meta.get("revision", "1")))
        form.addRow("Revision:", self.revision_edit)
        root.addLayout(form)

        # ── ④ EXPORT ── (headless "Generate PDF" removed — HLDs now export from the Print
        # Layout so the operator can fine-tune before exporting, and the PDF never clips.)
        root.addWidget(_section("④ EXPORT"))
        _note = QLabel(
            "Click <b>Open in Print Layout →</b> below. The map book opens in QGIS's Layout "
            "designer where you can fine-tune anything. When you're happy, click the green "
            "<b>📄 Export Atlas as PDF</b> button at the top of the designer to save the PDF.")
        _note.setWordWrap(True)
        try:
            _note.setStyleSheet("padding:4px 2px;")
        except Exception:
            pass
        root.addWidget(_note)
        # Output widgets are kept alive (values() still reads them) but HIDDEN — export now
        # happens via the layout designer's button, not a headless folder/DPI here.
        self.dir_edit = QLineEdit(default_dir)
        self.name_edit = QLineEdit(f"{self._title} HLD")
        self.dpi_spin = QSpinBox(); self.dpi_spin.setRange(72, 400); self.dpi_spin.setValue(150)
        self.vector_chk = QCheckBox(); self.vector_chk.setChecked(False)
        self.compress_chk = QCheckBox(); self.compress_chk.setChecked(False)
        self.editable_chk = QCheckBox(); self.editable_chk.setChecked(False)
        for _w in (self.dir_edit, self.name_edit, self.dpi_spin,
                   self.vector_chk, self.compress_chk, self.editable_chk):
            _w.setVisible(False)

        # keep the file name following the title until the user edits it themselves
        self._name_touched = False
        self.name_edit.textEdited.connect(lambda *_: setattr(self, "_name_touched", True))
        self.title_edit.textChanged.connect(self._sync_name)
        self._on_model_changed()      # set counts-button state for the initial model
        self._on_coverage_changed()   # grid controls + preview for the initial coverage

        # buttons
        btns = QHBoxLayout(); btns.addStretch(1)
        cancel = QPushButton("Cancel"); cancel.clicked.connect(self.reject)
        self.layout_btn = QPushButton("Open in Print Layout  →")
        self.layout_btn.setDefault(True)
        self.layout_btn.setToolTip(
            "Build the map-book layouts in THIS project's Print Layout so you can fine-tune "
            "them by hand, then click the green “📄 Export Atlas as PDF” button up top when "
            "you're happy. Nothing is saved until you save.")
        self.layout_btn.clicked.connect(self._accept_layout)
        btns.addWidget(cancel); btns.addWidget(self.layout_btn)
        # buttons live OUTSIDE the scroll area -> always visible, never pushed off-screen
        _outer.addLayout(btns)

        # sensible default size that fits the screen; user can drag bigger/smaller
        try:
            from qgis.PyQt.QtWidgets import QApplication
            _avail = QApplication.primaryScreen().availableGeometry()
            self.resize(660, min(920, int(_avail.height() * 0.9)))
        except Exception:
            self.resize(660, 820)

    def _accept_layout(self):
        self._mode = "layout"
        self.accept()

    def _is_commercial(self):
        return self.model_combo.currentData() == "commercial_grid"

    def _is_wayleave(self):
        return self.model_combo.currentData() == "wayleave"

    def _model_requires_restyle(self):
        """Does the selected model prescribe its own look? (models/<id>.json)"""
        try:
            from .presets import load_model
            return bool(load_model(self.model_combo.currentData() or "")
                        .get("requires_restyle"))
        except Exception:
            return False

    def _on_model_changed(self, *_):
        # A prescribed drawing (wayleave) IS its house style — pink span, red poles,
        # outline-only erven, invisible AOI. Leaving that to a checkbox the operator has
        # never seen meant two people could build the same wayleave and get two different
        # sheets. Tick it, lock it, and say why, so what they get is what everyone gets.
        forced = self._model_requires_restyle()
        if forced:
            self.restyle_chk.setChecked(True)
            self.restyle_chk.setToolTip(
                "Required by this drawing: it is defined by its own symbology (pink "
                "span, red poles, outline-only erven), so the build always applies it. "
                "Your layers are changed for this QGIS session only — close the project "
                "without saving to undo it.")
        elif not self.restyle_chk.isEnabled():
            # coming back off a prescribed model — hand the choice back
            self.restyle_chk.setChecked(False)
            self.restyle_chk.setToolTip(
                "OFF (recommended): the atlas renders your layers exactly as you have "
                "styled and labelled them. ON: the build OVERWRITES the symbology and "
                "labels on your live layers with the standard HLD look — close the "
                "project without saving to undo that.")
        self.restyle_chk.setEnabled(not forced)
        # count tables only apply to the commercial model; coverage picker is HLD-centric
        comm = self._is_commercial()
        self.counts_btn.setEnabled(comm)
        self.counts_btn.setText("Edit count tables…" if comm
                                else "Edit count tables…  (commercial model only)")
        # A wayleave sheet is ALWAYS the numbered 775 x 550 m plotting grid — one tile per
        # page — so pick that coverage for the operator instead of letting them ship a
        # wayleave framed on PONs, which is not what the client signs.
        if self._is_wayleave() and not self._is_grid():
            i = self.cov_combo.findData(GRID_COV)
            if i >= 0:
                self.cov_combo.setCurrentIndex(i)

    def _edit_counts(self):
        dlg = CountsDialog(self, self._count_tables)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self._count_tables = dlg.result_tables()

    def _sync_name(self, txt):
        if not self._name_touched:
            self.name_edit.setText(f"{txt.strip()} HLD" if txt.strip() else "HLD")

    def _check_all(self, on):
        st = Qt.CheckState.Checked if on else Qt.CheckState.Unchecked
        for i in range(self.layers_list.count()):
            self.layers_list.item(i).setCheckState(st)

    def _picked_layers(self):
        out = []
        for i in range(self.layers_list.count()):
            it = self.layers_list.item(i)
            if it.checkState() == Qt.CheckState.Checked:
                out.append(it.text())
        return out

    def _is_grid(self):
        return self.cov_combo.currentData() == GRID_COV

    def _is_phase_mode(self):
        return self.cov_combo.currentData() == PHASE_COV

    def _picked_phases(self):
        """Phase numbers the operator left ticked, in order."""
        out = []
        for i in range(self.phase_list.count()):
            it = self.phase_list.item(i)
            if it.checkState() == Qt.CheckState.Checked:
                out.append(int(it.data(Qt.ItemDataRole.UserRole)))
        return out

    def _on_coverage_changed(self, *_):
        """Show the fixed grid-size readout only for the grid option; update the preview."""
        grid = self._is_grid()
        phase = self._is_phase_mode()
        self.grid_size_lbl.setVisible(grid)
        self.phase_list.setVisible(phase)
        self.phase_row_label.setVisible(phase)
        # the layer picker and the PON-isolate toggle are driven by the phase set instead
        self.layers_list.setEnabled(not phase)
        if phase:
            nos = set(self._picked_phases())
            picked = [p for p in self._phase_options if p["phase_no"] in nos]
            pons = sum(p["pon_count"] for p in picked)
            if not picked:
                self.cov_preview.setText("→ tick at least one phase.")
            else:
                self.cov_preview.setText(
                    "→ %d books · %d pages · %d PDFs.  Each book: page 1 = every phase "
                    "boundary (the whole-town overview), then one page per PON in that "
                    "phase.  Phase boundaries are switched OFF on the detail pages so the "
                    "PON zones and the buildings show through."
                    % (len(picked), len(picked) + pons, len(picked)))
            return
        if grid:
            self.cov_preview.setText(
                f"→ the AOI is tiled into fixed {LOCKED_GRID_W_M:.0f} × {LOCKED_GRID_H_M:.0f} m "
                "pages; one page per grid cell.")
            return
        # a real polygon layer: describe the per-page unit
        lyr = self._cov_by_name.get(self.cov_combo.currentData())
        if lyr is None:
            self.cov_preview.setText("")
            return
        try:
            from .presets import coverage_descriptor
            unit, id_field, _sort = coverage_descriptor(lyr)
            n = lyr.featureCount()
            self.cov_preview.setText(f"→ {n} pages: one per {unit}  (heading “{unit} …”, by {id_field})")
        except Exception:
            self.cov_preview.setText("")

    def _draw_box_clicked(self):
        """Close the dialog with DRAW_CODE so the caller can run the canvas box tool
        (a modal dialog can't hand mouse events to the canvas)."""
        self.done(self.DRAW_CODE)

    def _pick_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Output folder", self.dir_edit.text() or self._dir)
        if d:
            self.dir_edit.setText(d)

    def values(self):
        name = (self.name_edit.text() or f"{self._title} HLD").strip()
        if name.lower().endswith(".pdf"):
            name = name[:-4]
        grid = self._is_grid()
        phase_mode = self._is_phase_mode()
        cov = "" if (grid or phase_mode) else (self.cov_combo.currentData() or "")
        return {
            "phase_mode": phase_mode,
            "phases": self._picked_phases() if phase_mode else [],
            "dir": self.dir_edit.text().strip() or self._dir,
            "name": name,
            "dpi": self.dpi_spin.value(),
            "compress": self.compress_chk.isChecked(),
            "force_vector": self.vector_chk.isChecked(),
            "editable": self.editable_chk.isChecked(),
            "title": self.title_edit.text().strip(),
            "designer": self.designer_edit.text().strip(),
            "company": self.company_edit.text().strip(),
            "revision": self.revision_edit.text().strip() or "1",
            "coverage": cov,
            "grid": grid,
            "layers": self._picked_layers(),
            # grid tile size is LOCKED — always the standard plotting grid (no operator draw)
            "cell_w_m": LOCKED_GRID_W_M,
            "cell_h_m": LOCKED_GRID_H_M,
            "model": self.model_combo.currentData(),
            "client": self.client_combo.currentData(),
            "count_tables": self._count_tables,
            "restyle_layers": self.restyle_chk.isChecked(),
            "isolate_pon": self.isolate_chk.isChecked(),
            "mode": self._mode,
        }


DEFAULT_COUNT_TABLES = [
    {"title": "Commercial HP Counts", "headers": ["Zoning", "Informal", "Formal", "Total HPs"],
     "rows": [["Residential", "", "", ""], ["Business", "", "", ""], ["Special", "", "", ""],
              ["Industrial", "", "", ""], ["MDU", "", "", ""], ["Grand Total", "", "", ""]]},
    {"title": "Commercial Erf Counts", "headers": ["Zoning", "Informal", "Formal", "Total Erf"],
     "rows": [["Residential", "", "", ""], ["Business", "", "", ""], ["Special", "", "", ""],
              ["Industrial", "", "", ""], ["MDU", "", "", ""], ["Grand Total", "", "", ""]]},
]


class CountsDialog(QDialog):
    """Manual count-table entry (HP + Erf), saved with the project. No numbers are
    computed/guessed — these are exactly what you type."""
    def __init__(self, parent, tables):
        super().__init__(parent)
        from qgis.PyQt.QtWidgets import QTableWidget, QTableWidgetItem
        self.setWindowTitle("Commercial count tables")
        self.setMinimumWidth(460)
        c = _theme()
        root = QVBoxLayout(self)
        hint = QLabel("Type the counts exactly as they should appear. Saved with the project "
                      "and reused each render. Leave blank to omit a cell.")
        hint.setWordWrap(True)
        if c["ink"]:
            hint.setStyleSheet(f"color:{c['ink']};")
        root.addWidget(hint)
        self._widgets = []
        src = tables if tables else DEFAULT_COUNT_TABLES
        for t in src:
            root.addWidget(_section(t.get("title", "")))
            headers = t.get("headers", ["Zoning", "Informal", "Formal", "Total"])
            rows = t.get("rows", [])
            tw = QTableWidget(len(rows), len(headers))
            tw.setHorizontalHeaderLabels(headers)
            for r, row in enumerate(rows):
                for col in range(len(headers)):
                    val = row[col] if col < len(row) else ""
                    tw.setItem(r, col, QTableWidgetItem(str(val)))
            tw.resizeColumnsToContents()
            root.addWidget(tw)
            self._widgets.append((t.get("title", ""), headers, tw))
        btns = QHBoxLayout(); btns.addStretch(1)
        cancel = QPushButton("Cancel"); cancel.clicked.connect(self.reject)
        ok = QPushButton("Save"); ok.setDefault(True); ok.clicked.connect(self.accept)
        btns.addWidget(cancel); btns.addWidget(ok)
        root.addLayout(btns)

    def result_tables(self):
        out = []
        for title, headers, tw in self._widgets:
            rows = []
            for r in range(tw.rowCount()):
                row = []
                for col in range(tw.columnCount()):
                    it = tw.item(r, col)
                    row.append(it.text().strip() if it else "")
                if any(row):
                    rows.append(row)
            out.append({"title": title, "headers": headers, "rows": rows})
        return out


def _theme():
    """Readable colours for the CURRENT QGIS theme (light/dark/custom)."""
    try:
        try:
            from .. import theme_safe
        except ImportError:
            import theme_safe
        return theme_safe.colors()
    except Exception:
        # never let a colour helper break the dialog — fall back to palette default
        return {"ink": "", "muted": "", "accent": "", "warn": "", "ok": "", "bad": ""}


def _section(text):
    c = _theme()
    lbl = QLabel(f"// {text}")
    css = "font-weight:bold;font-size:11px;margin-top:6px;"
    if c["accent"]:
        css = f"color:{c['accent']};" + css
    lbl.setStyleSheet(css)
    return lbl


def _ensure_saved_for_headless(mw, proj):
    """The headless render reads the SAVED .qgz, so it must exist + be current.
    (The 'Open in Print Layout' path uses the live in-memory project instead, so it
    does NOT need this — unsaved edits are exactly what you want to see there.)"""
    project_path = proj.fileName()
    if not project_path or not os.path.exists(project_path):
        QMessageBox.warning(mw, "Save project first",
                            "Please save your QGIS project (.qgz) first — the PDF is rendered "
                            "from the saved project in a separate process.\n\n"
                            "(Or use “Open in Print Layout”, which works on the live project.)")
        return None
    if proj.isDirty():
        r = QMessageBox.question(
            mw, "Unsaved changes",
            "The project has unsaved changes. The PDF is rendered from the SAVED file, so recent "
            "edits won't appear.\n\nSave now and continue?",
            QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Cancel)
        if r == QMessageBox.StandardButton.Cancel:
            return None
        if not proj.write():
            QMessageBox.critical(mw, "Save failed", "Could not save the project. Aborting.")
            return None
    return project_path


def open_hld_pdf_dialog(iface):
    """Entry point wired to the Nexus menu. Collects settings then either launches the
    background render (Generate PDF) or builds the layouts in the live Print Layout."""
    mw = iface.mainWindow()
    proj = QgsProject.instance()
    project_path = proj.fileName() or ""

    # inspect the OPEN project so the dialog auto-fills for ANY project
    from . import presets
    from .presets import (build_config, find_python_qgis, polygon_layers,
                          best_coverage_layer, coverage_descriptor,
                          load_project_meta, save_project_meta, derive_hld_cfg,
                          derive_aoi_cfg, list_models, list_clients, load_model,
                          load_client, deep_merge)
    import json
    from qgis.core import QgsSettings
    cov_layers = polygon_layers(proj)
    cov_names = [l.name() for l in cov_layers]
    best_cov = best_coverage_layer(proj)
    default_cov = best_cov.name() if best_cov else ""
    meta = load_project_meta(project_path)

    # all project layers (top-first) + their current visibility -> the HLD layer picker
    project_layers = []
    try:
        for node in proj.layerTreeRoot().findLayers():
            lyr = node.layer()
            if lyr is not None:
                project_layers.append((lyr.name(), node.isVisible()))
    except Exception:
        project_layers = []

    # phase groups in THIS project -> the "one book per phase" option. Empty on a project
    # with no phase groups, and then the option simply never appears.
    try:
        from . import phases as PH
        _detected_phases = PH.detect_phases(proj)
    except Exception as e:
        print("HLD phase detection skipped:", e)
        _detected_phases = []
    phase_options = [{"phase_no": ph["phase_no"],
                      "coverage_name": ph["coverage"].name() if ph["coverage"] else "no coverage",
                      "pon_count": ph["pon_count"]}
                     for ph in _detected_phases if ph.get("coverage") is not None]

    # persisted model/client/counts for this project
    s = QgsSettings()
    mkey = presets._meta_key(project_path)
    def_model = s.value(f"{mkey}/model", "hld_atlas")
    def_client = s.value(f"{mkey}/client", "fibertime")
    # a teammate may still have a retired preset id remembered for this project
    def_model = presets.RETIRED_PRESETS["models"].get(def_model, def_model)
    def_client = presets.RETIRED_PRESETS["clients"].get(def_client, def_client)
    try:
        saved_counts = json.loads(s.value(f"{mkey}/counts", "") or "[]")
    except Exception:
        saved_counts = []

    # remembered coverage choice (grid vs a layer) + the last grid page size
    def_cov = s.value(f"{mkey}/coverage", default_cov)
    try:
        cell_w = float(s.value(f"{mkey}/cell_w_m", 0) or 0)
        cell_h = float(s.value(f"{mkey}/cell_h_m", 0) or 0)
    except Exception:
        cell_w = cell_h = 0.0

    # Loop so "📐 Draw map size" can close the dialog, let the operator drag a box on the
    # canvas (a modal dialog can't), then re-open with the captured size pre-filled.
    while True:
        dlg = HldPdfDialog(mw, _downloads(), meta, cov_names, def_cov, cov_layers,
                           models=list_models(), default_model=def_model,
                           clients=list_clients(), default_client=def_client,
                           count_tables=saved_counts, iface=iface,
                           cell_w_m=cell_w, cell_h_m=cell_h, project_layers=project_layers,
                           phase_options=phase_options)
        code = dlg.exec()
        # preserve whatever the operator typed, so re-opening doesn't lose edits
        meta = {"title": dlg.title_edit.text(), "designer": dlg.designer_edit.text(),
                "company": dlg.company_edit.text(), "revision": dlg.revision_edit.text()}
        def_model = dlg.model_combo.currentData()
        def_client = dlg.client_combo.currentData()
        saved_counts = dlg._count_tables
        def_cov = (PHASE_COV if dlg._is_phase_mode()
                   else "__grid__" if dlg._is_grid()
                   else (dlg.cov_combo.currentData() or default_cov))
        if code == HldPdfDialog.DRAW_CODE:
            try:
                from .box_tool import draw_box
                size = draw_box(iface)
            except Exception as e:
                QMessageBox.warning(mw, "Draw map size", f"Could not draw on the canvas:\n{e}")
                size = None
            if size:
                cell_w, cell_h = size
            continue
        if code != QDialog.DialogCode.Accepted:
            return
        break
    v = dlg.values()

    if v.get("grid") and (v["cell_w_m"] <= 0 or v["cell_h_m"] <= 0):
        QMessageBox.warning(mw, "Draw the map size first",
                            "For a grid book, click “📐 Draw map size on the canvas” and drag a "
                            "box on the map so I know how big each page should be.")
        return

    # remember for next time (title block + model/client/counts)
    save_project_meta(project_path, {"title": v["title"], "designer": v["designer"],
                                     "company": v["company"], "revision": v["revision"]})
    s.setValue(f"{mkey}/model", v["model"])
    s.setValue(f"{mkey}/client", v["client"])
    s.setValue(f"{mkey}/counts", json.dumps(v["count_tables"]))
    s.setValue(f"{mkey}/coverage", "__grid__" if v.get("grid") else v["coverage"])
    if v.get("grid"):
        s.setValue(f"{mkey}/cell_w_m", v["cell_w_m"])
        s.setValue(f"{mkey}/cell_h_m", v["cell_h_m"])

    # ── compose HLD_CFG: client branding < model structure < project text (project wins) ──
    model = load_model(v["model"]) or {"hld_cfg": {}}
    client = load_client(v["client"]) or {"hld_cfg": {}}
    hld_cfg = deep_merge(client["hld_cfg"], model["hld_cfg"])   # model structure wins over client
    brand = {}
    if v["title"]:
        brand["project_name"] = v["title"]
        # per-project layout names so a Malmesbury book isn't labelled "MOA PH2 …"
        brand["layout_overview"] = f"{v['title']} HLD Overview"
        brand["layout_atlas"] = f"{v['title']} HLD Atlas"
        brand["layout_report"] = f"{v['title']} HLD Book"
    if v["designer"]:
        brand["designer"] = v["designer"]
    if v["company"]:
        brand["company"] = v["company"]
    if v["revision"]:
        brand["revision"] = str(v["revision"])
    import datetime as _dt
    brand["date_str"] = _dt.date.today().strftime("%d-%m-%Y")
    hld_cfg = deep_merge(hld_cfg, brand)

    # frame the atlas to THIS project's own AOI/boundary (not a hardcoded Mohadin one)
    hld_cfg = deep_merge(hld_cfg, derive_aoi_cfg(proj))

    # operator-picked HLD layers -> use exactly those + build the legend from their symbology.
    # OPT-IN: only override when the ticks DIFFER from the visible-layer default, so a plain
    # "accept the defaults" run keeps the proven curated/fixed legend. Skip for commercial
    # (it drives its own explicit layer/legend sets).
    picked = v.get("layers") or []
    # turn ON any picked layer that's currently OFF in the Layers panel, so it renders
    # (and the panel reflects what you chose) — JJ's rule.
    if picked:
        try:
            _root = proj.layerTreeRoot()
            for _nm in picked:
                for _ly in proj.mapLayersByName(_nm):
                    _node = _root.findLayer(_ly.id())
                    if _node is not None and not _node.itemVisibilityChecked():
                        _node.setItemVisibilityChecked(True)
        except Exception:
            pass
    default_visible = {name for name, vis in (project_layers or []) if vis}
    if picked and v.get("model") != "commercial_grid" and set(picked) != default_visible:
        hld_cfg["hld_layers"] = picked
        hld_cfg["legend_from_symbology"] = True

    if v.get("phase_mode"):
        # coverage, layer sets and per-page headings are derived PER PHASE in
        # live_build.phase_book_cfg — nothing project-wide to resolve here.
        pass
    elif v["model"] == "commercial_grid":
        hld_cfg["count_tables"] = v["count_tables"]
    elif v.get("grid"):
        # GRID book: engine auto-tiles the AOI at the drawn page size (coverage = grid).
        hld_cfg["grid_cell_w_m"] = float(v["cell_w_m"])
        hld_cfg["grid_cell_h_m"] = float(v["cell_h_m"])
    else:
        # per-layer HLD: coverage + per-page heading come from the dropdown + title
        cov_layer = next((l for l in cov_layers if l.name() == v["coverage"]), None)
        descriptor = coverage_descriptor(cov_layer) if cov_layer else None
        cov_cfg = derive_hld_cfg(v["title"], "", "", "", v["coverage"], descriptor)
        hld_cfg = deep_merge(hld_cfg, cov_cfg)

    # Live-layer safety: only restyle when the operator explicitly ticked it — OR when the
    # chosen model declares its look IS the deliverable (models/<id>.json requires_restyle).
    # Set last, after every deep_merge above, so no client BRAND can turn it on by itself;
    # the model's own declaration is the single exception, and the dialog shows it ticked
    # and locked so nothing happens to the operator's layers unannounced.
    hld_cfg["restyle_layers"] = bool(v.get("restyle_layers")) or bool(
        model.get("requires_restyle"))
    hld_cfg["atlas_clip"] = bool(v.get("isolate_pon"))

    # ── "One book per PHASE": build a separate atlas per phase, then one batch export ──
    if v.get("phase_mode"):
        if not v.get("phases"):
            QMessageBox.warning(mw, "Pick at least one phase",
                                "Tick the phases you want a PDF for.")
            return
        from .live_build import build_phase_books_in_project
        # the backhaul / POP layers frame the overview alongside the phase boundaries
        extra_ov = [n for n, _vis in (project_layers or [])
                    if any(k in n.lower() for k in ("pop", "backhaul", "mh"))]
        try:
            ok, msg, _books = build_phase_books_in_project(
                iface, hld_cfg, v["phases"], extra_overview=extra_ov)
        except Exception as e:
            ok, msg = False, f"Unexpected error: {e}"
        if ok:
            iface.messageBar().pushSuccess("HLD Phase Books", msg)
        else:
            QMessageBox.critical(mw, "HLD — phase books failed", msg)
        return

    # ── "Open in Print Layout": build in the LIVE project, hand off to the designer ──
    if v.get("mode") == "layout":
        from .presets import default_extra_layers
        from .live_build import build_in_project
        try:
            ok, msg, _ov, _at = build_in_project(iface, hld_cfg, default_extra_layers())
        except Exception as e:
            ok, msg = False, f"Unexpected error: {e}"
        if ok:
            # the atlas already opened on top — just a brief, non-blocking note (no popup)
            iface.messageBar().pushSuccess(
                "HLD Atlas", msg + "  Page 1 = overview; flip ▶ with the Atlas Toolbar arrows.")
        else:
            QMessageBox.critical(mw, "HLD — Print Layout failed", msg)
        return

    # ── "Generate PDF" (headless): renders from the SAVED project in a separate process ──
    project_path = _ensure_saved_for_headless(mw, proj)
    if not project_path:
        return

    out_dir = v["dir"]
    try:
        os.makedirs(out_dir, exist_ok=True)
    except Exception as e:
        QMessageBox.critical(mw, "Bad folder", f"Cannot use that output folder:\n{e}")
        return

    out_pdf = os.path.join(out_dir, v["name"] + ".pdf")
    out_project = os.path.join(out_dir, v["name"] + ".qgz") if v["editable"] else None
    work = os.path.join(out_dir, "_hld_work")
    os.makedirs(work, exist_ok=True)
    cfg_path = os.path.join(work, "config.json")
    result_path = os.path.join(work, "result.json")
    tmp = os.path.join(work, "_tmp")

    if not find_python_qgis():
        QMessageBox.critical(mw, "QGIS launcher missing",
                             "Could not find python-qgis.bat next to your QGIS install — cannot "
                             "start the background render.")
        return

    import json
    cfg = build_config(project_path, out_pdf, out_project, v["dpi"], v["compress"],
                       tmp, result_path, hld_cfg=hld_cfg, force_vector=v.get("force_vector", False))
    with open(cfg_path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
    # clear any stale result so we never read a previous run's outcome
    try:
        if os.path.exists(result_path):
            os.remove(result_path)
    except Exception:
        pass

    bar = iface.messageBar()
    bar.pushInfo("HLD PDF", "Generating in the background — QGIS stays usable. This takes a few minutes…")

    def on_done(result, error):
        if result and result.get("ok"):
            pages = result.get("pages", "?")
            size = result.get("size_mb", "?")
            the_pdf = result.get("output") or out_pdf
            # AUTO-OPEN the finished PDF (no popup to click through), + a brief note in the bar
            try:
                if os.path.exists(the_pdf):
                    os.startfile(the_pdf)  # noqa: S606 - open the exact PDF just written
            except Exception:
                pass
            b = iface.messageBar()
            try:
                from qgis.core import Qgis
                from qgis.PyQt.QtWidgets import QPushButton
                widget = b.createMessage("HLD PDF",
                                         f"✅ {pages} pages · {size} MB — opened.  {the_pdf}")
                btn = QPushButton("Open folder")
                btn.clicked.connect(lambda: os.startfile(out_dir))  # noqa: S606
                widget.layout().addWidget(btn)
                b.pushWidget(widget, Qgis.MessageLevel.Success, 10)
            except Exception:
                b.pushSuccess("HLD PDF", f"✅ {pages} pages · {size} MB — opened.  {the_pdf}")
        else:
            detail = (result or {}).get("message") or error or "unknown error"
            stage = (result or {}).get("stage", "?")
            QMessageBox.critical(mw, "HLD PDF — Failed",
                                 f"Could not generate the PDF.\n\nStage: {stage}\n{detail}\n\n"
                                 f"Log/config: {work}")

    from .runner import HldGenerateTask
    task = HldGenerateTask(cfg_path, result_path, on_done, timeout=1800)
    # keep a reference so the task isn't garbage-collected mid-run
    global _ACTIVE_TASK
    _ACTIVE_TASK = task
    QgsApplication.taskManager().addTask(task)


_ACTIVE_TASK = None
