# HeroTel: Feeder Cable Routing Algorithm (TSD standard)

from qgis.core import (
    QgsProcessingParameterVectorLayer,
    QgsProcessing,
)

from .ht_base_algorithm import HeroTelBaseAlgorithm


class HT05FeederRoutingAlgorithm(HeroTelBaseAlgorithm):
    """
    HT 5 — Feeder Cable Routing (STS → FTS → POP) — TSD standard.

    Routes distribution and feeder cables from STS → FTS → secondary → primary → POP.
    Uses Steiner tree approximation (networkx Mehlhorn) on the OSM road graph.

    PENDING: HeroTel TSD specification document from JJ.
    This is a stub algorithm. Full implementation will:
      1. Distribution cables (STS → FTS):
         - Build Steiner tree connecting all STS within a PON to the PON's FTS
         - Cable sizing: main=48F always; spur=ceil(sts_count×1.15)→{24,48}F min 24F
         - Walk Steiner tree edges → one LineString per segment
         - Snap endpoints to pole positions (at junctions/bends)
      2. Secondary feeder (FTS → trunk):
         - DFS postorder on Steiner tree: compute downstream PON count per edge
         - Cable sizing: 2×downstream_pon_count → {24F,48F,96F,144F}
         - Route: 24F=1-6 PONs, 48F=7-16, 96F=17-32, 144F=33-64 downstream
      3. Primary feeder (trunk → POP):
         - Single trunk route from first junction to POP along main road
         - Cable: 144F MEGAnet SSA (A-BB13-C02350 or larger — pending CFS SKUs)
      4. Pole placement: every 50m + mandatory at every bend ≥15°, FTS, STS, junction
      5. Populate all cable attributes: strtfeat, endfeat, cblcpty1, length_m, datecrtd

    Cable hierarchy (HeroTel):
      ONT → Drop 4F → STS (1:16) → Dist 24F/48F → FTS (1:8) → Sec 48-144F → Primary 144F → POP

    Run AFTER: HT 4 (Drop Routing)
    Run BEFORE: HT 6 (BOM Export — not yet defined)
    Requires: Splitter FTS v1, Splitter STS v1, road network, POP location
    Produces: Distribution Cable v1, Secondary Cable v1, Primary Cable v1, Poles v1
    """

    INPUT_FTS = 'INPUT_FTS'
    INPUT_STS = 'INPUT_STS'

    def name(self):
        return 'ht_05_feeder_routing'

    def displayName(self):
        return 'HT 5 — Feeder Cable Routing (STS → FTS → POP)'

    def shortHelpString(self):
        return """
        <p><b>HT 5 — Feeder Cable Routing (STS → FTS → POP)</b></p>

        <p>Routes all feeder cables from STS through FTS to the POP using Steiner tree
        approximation on the OSM road graph. Places poles at regular intervals.</p>

        <h4>Cable hierarchy (HeroTel)</h4>
        <p>ONT → Drop 4F → STS (1:16) → Distribution 24/48F → FTS (1:8) →
        Secondary 48–144F → Primary 144F → POP</p>

        <h4>Distribution cable sizing</h4>
        <ul>
          <li>Main trunk: 48F always</li>
          <li>Spur: ceil(sts_count × 1.15) → nearest {24F, 48F}, min 24F</li>
        </ul>

        <h4>Secondary cable sizing</h4>
        <p>DFS postorder traversal on Steiner tree. Formula: 2 × downstream_pon_count
        → {24F=1-6 PONs, 48F=7-16, 96F=17-32, 144F=33-64}</p>

        <h4>Pole placement</h4>
        <p>Every 50m along cable routes + mandatory at bends ≥15°, every FTS/STS junction,
        and every cable branch point. Deduplication within 2m.</p>

        <h4>MEGAnet cable SKUs</h4>
        <ul>
          <li>24F distribution: A-BB13-C02350</li>
          <li>48F/96F/144F: PENDING — contact info@cfsafrica.com</li>
        </ul>

        <p><b>⚠️ PENDING:</b> HeroTel TSD specification from JJ. Full implementation awaiting PDF.</p>
        """

    def initAlgorithm(self, config=None):
        from qgis.core import QgsProject
        proj = QgsProject.instance()
        fts_layers = proj.mapLayersByName('Splitter FTS v1')
        sts_layers = proj.mapLayersByName('Splitter STS v1')

        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT_FTS,
                'Splitter FTS v1 layer',
                [QgsProcessing.TypeVectorPoint],
                defaultValue=fts_layers[0] if fts_layers else None,
            )
        )
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT_STS,
                'Splitter STS v1 layer',
                [QgsProcessing.TypeVectorPoint],
                defaultValue=sts_layers[0] if sts_layers else None,
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """Algorithm entry point — STUB pending TSD specification"""
        raise NotImplementedError(
            '\n'.join([
                'HT 5 — Feeder Cable Routing is not yet implemented.',
                '',
                'PENDING: HeroTel TSD (Telecommunications System Design) specification from JJ.',
                '',
                'Key design decisions confirmed:',
                '  • Steiner tree: networkx approximation.steiner_tree() (Mehlhorn)',
                '  • Distribution: main=48F, spur=ceil(sts×1.15)→{24F,48F} min 24F',
                '  • Secondary: DFS postorder, 2×downstream_pon_count→{24F,48F,96F,144F}',
                '  • Primary: 144F trunk POP→first junction along main road',
                '  • Poles: every 50m + mandatory at bends≥15°/FTS/STS/branch points',
                '  • Cable SKUs: 24F=A-BB13-C02350; 48F/96F/144F PENDING from CFS Africa',
                '',
                'Requires: C:/Temp/lulekani_roads.graphml (osmnx 2.1.0)',
                '          pip install networkx (already in .qgis-venv)',
                'Contact: ai@velocityfibre.co.za | info@cfsafrica.com (for cable SKUs)',
            ])
        )

    def postProcessAlgorithm(self, context, feedback):
        return {}
