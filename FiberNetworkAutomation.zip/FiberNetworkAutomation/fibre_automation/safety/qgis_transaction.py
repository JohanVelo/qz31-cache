# claude:approved-destructive — this module DEFINES the atomic-write wrapper; the
# startEditing/commit/rollback calls are the wrapper body, not a live run.
"""qgis_transaction — atomic multi-layer writes (bundled; stdlib + native QGIS).

Kills the silent-corruption class (duplicate FIDs, mid-commit partial writes that
leave a layer half-updated): wrap a batch of edits so it ALL commits or ALL rolls
back. On a transactional backend (GeoPackage/PostGIS) it uses a real DB
transaction; on a non-transactional one (shapefile, memory) it falls back to
per-layer edit sessions with rollback-on-exception (same all-or-nothing promise
per layer). Never raises out of the rollback path.

    from fibre_automation.safety.qgis_transaction import safe_transaction
    with safe_transaction([poles, drops]) as txn:
        poles.dataProvider().changeAttributeValues(...)
        drops.dataProvider().addFeatures(...)
    # exits → commit; any exception inside → rollback, then re-raise
"""
from contextlib import contextmanager


def _supports_transaction(layer):
    """True if the layer's provider can take part in a QgsTransaction (DB-backed)."""
    try:
        from qgis.core import QgsVectorLayer
        if not isinstance(layer, QgsVectorLayer):
            return False
        # GeoPackage/SpatiaLite/PostGIS support transactions; shapefile/memory don't.
        if layer.dataProvider().transaction() is not None:
            return True
        return layer.dataProvider().name() in ("ogr", "postgres", "spatialite") and \
            layer.storageType() in ("GPKG", "PostgreSQL database with PostGIS extension",
                                    "SQLite database with SpatiaLite extension")
    except Exception:
        return False


def _breadcrumb(msg):
    try:
        from ..geometry_guardian import record_activity
        record_activity(str(msg)[:240])
    except Exception:
        try:
            from FiberNetworkAutomation.geometry_guardian import record_activity
            record_activity(str(msg)[:240])
        except Exception:
            pass


@contextmanager
def safe_transaction(layers, project=None):
    """All-or-nothing edit across `layers`. Commits on clean exit; rolls back +
    re-raises on any exception. Uses a real QgsTransaction where supported, else
    per-layer edit sessions. `layers` = one QgsVectorLayer or a list of them."""
    from qgis.core import QgsTransaction
    if not isinstance(layers, (list, tuple)):
        layers = [layers]
    layers = [lyr for lyr in layers if lyr is not None]

    txn = None
    started = []
    use_txn = bool(layers) and all(_supports_transaction(lyr) for lyr in layers)
    if use_txn:
        try:
            txn = QgsTransaction.create(layers)
            if txn is not None and not txn.begin():
                txn = None
        except Exception:
            txn = None

    try:
        if txn is None:
            # fallback: per-layer edit sessions (all-or-nothing per layer)
            for lyr in layers:
                try:
                    if not lyr.isEditable():
                        lyr.startEditing()
                        started.append(lyr)
                except Exception:
                    pass
        yield txn
        # ── commit ──
        if txn is not None:
            if not txn.commit():
                err = txn.lastError()
                txn.rollback()
                txn = None  # already rolled back; skip the outer except's second rollback
                msg = f"transaction commit failed: {err}"
                _breadcrumb("[safe_transaction] " + msg)
                raise IOError(msg)
        else:
            for lyr in started:
                if not lyr.commitChanges():
                    errs = lyr.commitErrors()
                    try:
                        lyr.rollBack()
                    except Exception:
                        pass
                    msg = f"commit failed on '{lyr.name()}': {errs}"
                    _breadcrumb("[safe_transaction] " + msg)
                    raise IOError(msg)
    except Exception:
        # ── rollback everything ──
        if txn is not None:
            try:
                txn.rollback()
            except Exception:
                pass
        else:
            for lyr in started:
                try:
                    if lyr.isEditable():
                        lyr.rollBack()
                except Exception:
                    pass
        _breadcrumb("[safe_transaction] rolled back on exception")
        raise
