"""login — MANDATORY per-user sign-in so the plugin holds a server-verified token.

The plugin historically authenticated its my_* reads with a spoofable username
param. This dialog asks the operator for their password, exchanges it for an HMAC
token at the edge fn (/plugin-login), and stores it (backend.set_user_token).
After that the notifications / resolved-ticket reads are identity-verified.

maybe_prompt_login() now prompts at EVERY startup until the operator signs in (no
one-time opt-out), driving ~100% token adoption so the anon RPCs can be locked.
Safe by design: declining only defers THIS session (re-asks next launch), an
unreachable server lets them defer, and core FTTH work is never blocked — this
gates only the secure notifications/resolved path (anon fallback covers the gap
until they sign in).
"""
from . import backend as _backend


def has_token():
    return bool(_backend.get_user_token())


def show_login_dialog(parent, backend, username, display_name=None, mandatory=False):
    """Modal: ask for the password, exchange it for a token. Returns True on
    success. When mandatory, the dialog says sign-in is required and the defer
    button reads 'Not now' (it re-prompts next launch); declining never bricks the
    plugin or blocks core work."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (
        QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QHBoxLayout)

    dlg = QDialog(parent)
    dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
    dlg.setWindowTitle("Velocity Nexus — Secure sign-in")
    dlg.setMinimumWidth(360)
    v = QVBoxLayout(dlg)
    _hdr = ("<b>Sign-in required</b>" if mandatory else "<b>Secure your account</b>")
    _tail = ("once so your notifications are verified as yours."
             if not mandatory else
             "once so your notifications are verified as yours. (Sign-in is now "
             "required; you can defer this session but you'll be asked again.)")
    v.addWidget(QLabel(
        f"{_hdr}<br>Signing in as <b>{display_name or username}</b>. Enter your "
        f"Velocity Nexus password {_tail}"))
    pw = QLineEdit()
    pw.setEchoMode(QLineEdit.EchoMode.Password)
    pw.setPlaceholderText("password")
    v.addWidget(pw)
    msg = QLabel("")
    msg.setWordWrap(True)
    v.addWidget(msg)
    row = QHBoxLayout()
    btn_login = QPushButton("Sign in")
    btn_cancel = QPushButton("Not now" if mandatory else "Later")
    row.addStretch(1)
    row.addWidget(btn_cancel)
    row.addWidget(btn_login)
    v.addLayout(row)

    state = {"ok": False}
    # Liveness flag: the async login callback can fire AFTER the user clicked
    # 'Not now' (WA_DeleteOnClose already destroyed the C++ dialog). Touching the
    # dead widget would raise; guard so we never do. The token is still stored by
    # the backend on success, so has_token() skips the prompt next launch.
    alive = {"v": True}
    dlg.destroyed.connect(lambda *_: alive.__setitem__("v", False))

    def _attempt():
        p = pw.text()
        if not p:
            msg.setText("Enter your password.")
            return
        btn_login.setEnabled(False)
        msg.setText("Signing in…")

        def _cb(ok, disp):
            if not alive["v"]:
                return                       # dialog already closed/destroyed
            try:
                if ok:
                    state["ok"] = True
                    dlg.accept()
                else:
                    msg.setText("Sign-in failed — wrong password, or account not "
                                "active. You can try again or tap 'Not now'.")
                    btn_login.setEnabled(True)
            except Exception:
                import traceback
                traceback.print_exc()

        try:
            backend.plugin_login(username, p, _cb)
        except Exception:
            msg.setText("Could not reach the server — try again later.")
            btn_login.setEnabled(True)

    btn_login.clicked.connect(_attempt)
    btn_cancel.clicked.connect(dlg.reject)
    pw.returnPressed.connect(_attempt)
    dlg.exec()
    return state["ok"]


def maybe_prompt_login(parent, backend, username, display_name=None):
    """MANDATORY sign-in: if there is no token, prompt at EVERY startup until the
    operator signs in (no one-time opt-out). Safe by design — it never bricks the
    plugin: declining only defers THIS session (it re-asks next launch), the
    server being unreachable lets them defer, and core FTTH work is never blocked
    (this gates only the secure notifications/resolved path). Returns True once a
    token exists. This drives ~100% token adoption so the anon RPCs can be locked."""
    try:
        if not username or has_token():
            return has_token()
        return show_login_dialog(parent, backend, username, display_name,
                                 mandatory=True)
    except Exception:
        return False
