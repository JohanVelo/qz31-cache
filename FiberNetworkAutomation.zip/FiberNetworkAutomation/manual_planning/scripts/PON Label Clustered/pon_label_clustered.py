import sys, os, math, random
if sys.stderr is None: sys.stderr = open(os.devnull, 'w')
if sys.stdout is None: sys.stdout = open(os.devnull, 'w')

# ============================================================
# PON LABEL CLUSTERING
# Project: Fibre Time (all projects)
# Groups PONs into cabinets using K-Means geographic clustering.
# Assigns labels: C{cabinet}P{pon_within_cabinet}
# Cabinet order: west → east (by centroid X)
# PON order within cabinet: north → south (descending Y)
# PONS_PER_CABINET should match OLT card capacity (16 GPON ports)
# ============================================================

PON_LAYER        = 'PON v1'
PONS_PER_CABINET = 16  # 1 OLT card = 16 GPON ports = 16 PONs

# --- GET LAYER ---
pon_layer = None
for lyr in QgsProject.instance().mapLayers().values():
    if lyr.name() == PON_LAYER:
        pon_layer = lyr
        break

if not pon_layer:
    print(f"ERROR: Layer '{PON_LAYER}' not found.")
else:
    features = list(pon_layer.getFeatures())
    total    = len(features)
    print(f"PON layer: {PON_LAYER} ({total} features)")

    if total == 0:
        print("ERROR: No features in PON layer.")
    else:
        # --- Collect centroids ---
        pts = []  # [(x, y, fid), ...]
        for f in features:
            geom = f.geometry()
            if geom and not geom.isNull() and not geom.isEmpty():
                pt = geom.centroid().asPoint()
                pts.append((pt.x(), pt.y(), f.id()))
            else:
                print(f"WARNING: skipping feature {f.id()} — null/empty geometry")

        # Recount on valid points only — null-geometry features must not
        # inflate the cabinet count or pull cluster centroids to (0,0).
        total = len(pts)
        if total == 0:
            print("ERROR: No features with valid geometry in PON layer.")
            raise SystemExit

        n_cabinets = math.ceil(total / PONS_PER_CABINET)
        print(f"Cabinets to create: {n_cabinets} ({PONS_PER_CABINET} PONs per cabinet)")

        # --- K-Means clustering ---
        random.seed(42)
        # Seed initial centers evenly spaced by northing (north to south)
        sorted_by_y = sorted(pts, key=lambda p: p[1], reverse=True)
        step    = max(1, total // n_cabinets)
        centers = [
            (sorted_by_y[min(i * step, total - 1)][0],
             sorted_by_y[min(i * step, total - 1)][1])
            for i in range(n_cabinets)
        ]

        def d2(ax, ay, bx, by):
            return (ax - bx) ** 2 + (ay - by) ** 2

        clusters = [0] * total
        for iteration in range(100):
            changed = False
            for i, (x, y, fid) in enumerate(pts):
                nearest = min(range(n_cabinets),
                              key=lambda k: d2(x, y, centers[k][0], centers[k][1]))
                if clusters[i] != nearest:
                    clusters[i] = nearest
                    changed = True
            if not changed:
                print(f"  K-Means converged after {iteration + 1} iterations.")
                break
            for k in range(n_cabinets):
                members = [(pts[i][0], pts[i][1]) for i in range(total) if clusters[i] == k]
                if members:
                    centers[k] = (
                        sum(m[0] for m in members) / len(members),
                        sum(m[1] for m in members) / len(members),
                    )

        # --- Build cabinet groups ---
        groups = {}  # k → [(y, fid), ...]
        for i, (x, y, fid) in enumerate(pts):
            groups.setdefault(clusters[i], []).append((y, fid))

        # Sort cabinets west → east by centroid X
        cab_order = sorted(groups.keys(), key=lambda k: centers[k][0])

        # Assign C{n}P{n} labels
        label_map = {}  # fid → label
        for cab_num, k in enumerate(cab_order, start=1):
            pons_in_cab = sorted(groups[k], key=lambda t: t[0], reverse=True)  # N→S
            for pon_num, (y, fid) in enumerate(pons_in_cab, start=1):
                label_map[fid] = f'C{cab_num}P{pon_num}'

        # --- Write labels ---
        label_idx = pon_layer.fields().indexOf('label')
        if label_idx == -1:
            print("ERROR: 'label' field not found in PON layer.")
        else:
            attr_map = {fid: {label_idx: lbl} for fid, lbl in label_map.items()}
            pon_layer.dataProvider().changeAttributeValues(attr_map)
            pon_layer.updateFields()
            pon_layer.triggerRepaint()

            print("=" * 50)
            print("  PON LABEL CLUSTERING COMPLETE")
            print(f"  Total PONs:        {total}")
            print(f"  Cabinets created:  {n_cabinets}")
            print(f"  Labels assigned:   {len(label_map)}")
            print("=" * 50)
            print("Sample — first 10 labels (by feature order):")
            for i, f in enumerate(pon_layer.getFeatures()):
                if i >= 10:
                    break
                print(f"  {f['label']}")
            print("\nNow run Step 10 (PON No Assignment) to assign sequential integers.")
