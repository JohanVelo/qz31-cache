"""
FT 6 — Apply Feeder-Path PON Order

Reads pon_feeder_order.txt (recorded via the 'Record PON' toolbar button)
and applies the correct feeder-path OLT port sequence to all Phase 2 layers:
  - FTS Splitters v1: label, pon_no, zone_no
  - PON v1:           label, pon_no, zone_no
  - All other layers: pon_no, zone_no (spatial join from updated PON polygons)
"""
import os
import re
import shutil
import datetime

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterString,
    QgsProcessingParameterBoolean,
    QgsProcessingOutputString,
    QgsVectorLayer,
    QgsSpatialIndex,
    QgsGeometry,
    QgsPointXY,
)


# Defaults below are for the original machine; override on another machine with the
# MOA_PH2_DIR / MOA_PON_ORDER_FILE environment variables (these are also overridable
# as algorithm parameters at run time).
PH2_DEFAULT = os.environ.get(
    'MOA_PH2_DIR',
    'C:/Users/jjsch/blitzfibre.com/Velocity_Manco - Velocity_Manco_Planning'
    '/Baseline Maps/FiberTime Planning/Potch - Mohadin PH2')
ORDER_FILE_DEFAULT = os.environ.get(
    'MOA_PON_ORDER_FILE',
    'C:/Users/jjsch/OneDrive - blitzfibre.com/Documents/Workspace/QGIS'
    '/pon_feeder_order.txt')


def pos_to_olt(pos):
    """
    Map feeder-order position (1-based) to OLT card/port.
    Zones 17-20 = cards 15-18 (16 ports each from port 11→16, then 1→10).
    Zone 21    = card 19 (PON 299, 300) — deliberate per project_ph2_zone_21_deliberate.md.
    Total entries: up to 66 (64 base + 2 zone-21).
    """
    if pos <= 6:                     # zone 17 head — PONs 235-240
        card, port = 15, pos + 10
    elif pos <= 22:                  # zone 17 tail + zone 18 head — PONs 241-256
        card, port = 16, pos - 6
    elif pos <= 38:                  # zone 18 tail + zone 19 head — PONs 257-272
        card, port = 17, pos - 22
    elif pos <= 54:                  # zone 19 tail + zone 20 head — PONs 273-288
        card, port = 18, pos - 38
    elif pos <= 64:                  # zone 20 tail — PONs 289-298 (card 19 ports 1-10)
        card, port = 19, pos - 54
    elif pos <= 66:                  # zone 21 — PONs 299-300 (card 19 ports 11-12)
        card, port = 19, pos - 54
    else:
        raise ValueError(f"pos {pos} out of range (max 66)")
    new_pon  = (card - 1) * 16 + port
    new_zone = (new_pon - 235) // 16 + 17
    return card, port, new_pon, new_zone


def relabel(old_label, new_zone, new_olt):
    lbl = re.sub(r'^(MOA\.\w+\.)(\d+)(\.)',
                 lambda m: f'{m.group(1)}{new_zone}{m.group(3)}', old_label)
    lbl = re.sub(r'C\d+P\d+', new_olt, lbl)
    return lbl


class FTApplyPonOrderAlgorithm(QgsProcessingAlgorithm):

    ORDER_FILE = 'ORDER_FILE'
    PH2_PATH   = 'PH2_PATH'
    DRY_RUN    = 'DRY_RUN'
    RESULT     = 'RESULT'

    def name(self):
        return 'ft_apply_pon_order'

    def displayName(self):
        return 'FT 6: Apply Feeder-Path PON Order'

    def group(self):
        return 'Fibertime Network Labeling'

    def groupId(self):
        return 'fibertimenetworklabeling'

    def shortHelpString(self):
        return (
            'Reads the PON feeder-path order file recorded via the "Record PON" toolbar button '
            'and relabels FTS Splitters v1 and PON v1 with the correct OLT port sequence '
            '(C15P11 → C19P10). Then propagates the updated pon_no and zone_no to all other '
            'Phase 2 layers via spatial join.\n\n'
            'Run the "Record PON" button 64 times (once per PON polygon in feeder order) '
            'before running this algorithm.'
        )

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFile(
            self.ORDER_FILE, 'PON feeder order file',
            defaultValue=ORDER_FILE_DEFAULT,
        ))
        self.addParameter(QgsProcessingParameterString(
            self.PH2_PATH, 'Phase 2 shapefile folder',
            defaultValue=PH2_DEFAULT,
        ))
        self.addParameter(QgsProcessingParameterBoolean(
            self.DRY_RUN, 'Dry run (print mapping only, no changes)',
            defaultValue=False,
        ))
        self.addOutput(QgsProcessingOutputString(self.RESULT, 'Result summary'))

    def processAlgorithm(self, parameters, context, feedback):
        order_file = self.parameterAsFile(parameters, self.ORDER_FILE, context)
        ph2        = self.parameterAsString(parameters, self.PH2_PATH, context).rstrip('/')
        dry_run    = self.parameterAsBoolean(parameters, self.DRY_RUN, context)

        # ── Validate order file ───────────────────────────────────────────────
        if not os.path.exists(order_file):
            raise Exception(f'Order file not found: {order_file}')

        with open(order_file) as f:
            lines = [l.strip() for l in f if l.strip()]

        # Accept 64 (zones 17-20 only) or 66 (zones 17-21 incl. PON 299-300).
        # Zone 21 is deliberate per project_ph2_zone_21_deliberate.md.
        if len(lines) not in (64, 66):
            raise Exception(f'Expected 64 or 66 entries in order file, got {len(lines)}')

        feedback.pushInfo(f'Order file: {len(lines)} entries ✅')

        order_rows = []
        for line in lines:
            parts   = line.split(',', 2)
            pos     = int(parts[0])
            old_pon = int(parts[2].strip())
            order_rows.append((pos, old_pon))

        # ── Build mapping ─────────────────────────────────────────────────────
        pon_map = {}
        for pos, old_pon in order_rows:
            card, port, new_pon, new_zone = pos_to_olt(pos)
            pon_map[old_pon] = {
                'new_pon':  new_pon,
                'new_zone': new_zone,
                'new_olt':  f'C{card}P{port:02d}',
            }
            feedback.pushInfo(f'  pos={pos:>3}  old={old_pon}  →  C{card}P{port}  pon={new_pon}  zone={new_zone}')

        new_pons = [v['new_pon'] for v in pon_map.values()]
        if len(set(new_pons)) != len(order_rows):
            dups = [p for p in set(new_pons) if new_pons.count(p) > 1]
            raise Exception(f'Duplicate new_pon values {dups} — check order file')

        if dry_run:
            feedback.pushInfo('Dry run complete — no changes made')
            return {self.RESULT: 'Dry run OK'}

        # ── Backup ────────────────────────────────────────────────────────────
        ts  = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        bak = f'{ph2}/_BACKUP/{ts}_apply_pon_order'
        os.makedirs(bak, exist_ok=True)
        for fname in ['FTS Splitters v1', 'PON v1', 'STS Splitters v1',
                      'poles v1', 'Enclosure v1', 'Secondary Cable v1',
                      'Distribution Cable v1', 'Drop Cable v1', 'ONT v1', 'Zones v1']:
            for ext in ['.shp', '.dbf', '.shx', '.prj', '.cpg']:
                src = f'{ph2}/{fname}{ext}'
                if os.path.exists(src):
                    shutil.copy2(src, f'{bak}/{fname}{ext}')
        feedback.pushInfo(f'Backup → {bak}')

        # ── FTS Splitters v1 ──────────────────────────────────────────────────
        feedback.pushInfo('Updating FTS Splitters v1 …')
        fts = QgsVectorLayer(ph2 + '/FTS Splitters v1.shp', 'fts', 'ogr')
        fts_lbl  = fts.fields().indexOf('label')
        fts_pon  = fts.fields().indexOf('pon_no')
        fts_zone = fts.fields().indexOf('zone_no')
        fts_map = {}
        for feat in fts.getFeatures():
            pv = str(feat['pon_no']).strip()
            if not pv.isdigit() or int(pv) not in pon_map:
                continue
            m = pon_map[int(pv)]
            fts_map[feat.id()] = {
                fts_lbl:  relabel(str(feat['label']), m['new_zone'], m['new_olt']),
                fts_pon:  m['new_pon'],
                fts_zone: m['new_zone'],
            }
        fts.dataProvider().changeAttributeValues(fts_map)
        feedback.pushInfo(f'  FTS: {len(fts_map)} updated')

        # ── PON v1 ────────────────────────────────────────────────────────────
        feedback.pushInfo('Updating PON v1 …')
        pon = QgsVectorLayer(ph2 + '/PON v1.shp', 'pon', 'ogr')
        pon_lbl  = pon.fields().indexOf('label')
        pon_pon  = pon.fields().indexOf('pon_no')
        pon_zone = pon.fields().indexOf('zone_no')
        pon_map2 = {}
        for feat in pon.getFeatures():
            pv = str(feat['pon_no']).strip()
            if not pv.isdigit() or int(pv) not in pon_map:
                continue
            m = pon_map[int(pv)]
            pon_map2[feat.id()] = {
                pon_lbl:  relabel(str(feat['label']), m['new_zone'], m['new_olt']),
                pon_pon:  m['new_pon'],
                pon_zone: m['new_zone'],
            }
        pon.dataProvider().changeAttributeValues(pon_map2)
        feedback.pushInfo(f'  PON: {len(pon_map2)} updated')

        # ── Rebuild PON spatial index ─────────────────────────────────────────
        feedback.pushInfo('Rebuilding PON spatial index …')
        pon2 = QgsVectorLayer(ph2 + '/PON v1.shp', 'pon2', 'ogr')
        pon_data  = {feat.id(): {'pon_no': int(feat['pon_no']), 'zone_no': int(feat['zone_no']),
                                 'geom': feat.geometry()} for feat in pon2.getFeatures()}
        pon_index = QgsSpatialIndex(pon2.getFeatures())

        def get_pon_zone(pt):
            """Return (pon_no, zone_no).
            Strategy:
              1. Direct CONTAINS — best case
              2. B3 fix 2026-04-28: small-buffer tolerance (~5m) for boundary cases
              3. None,None if still no match — caller treats as 'leave alone'
            (Distance fallback to nearest-polygon was removed earlier today —
             it clobbered correct manual pon_no values on features genuinely
             near a zone boundary. The buffer tolerance only helps features
             that are SUPPOSED to be inside but sit a few cm outside the polygon.)
            """
            pt_geom    = QgsGeometry.fromPointXY(QgsPointXY(pt))
            candidates = pon_index.intersects(pt_geom.boundingBox())
            for fid in candidates:
                if pon_data[fid]['geom'].contains(pt_geom):
                    return pon_data[fid]['pon_no'], pon_data[fid]['zone_no']
            # Tolerance: 5m at MOA latitude in degrees ≈ 5/111320
            buf = pt_geom.buffer(5.0 / 111320.0, 4)
            for fid in pon_index.intersects(buf.boundingBox()):
                if pon_data[fid]['geom'].intersects(buf):
                    return pon_data[fid]['pon_no'], pon_data[fid]['zone_no']
            return (None, None)

        # ── Propagate to point layers ─────────────────────────────────────────
        def propagate_points(fname, label):
            lyr = QgsVectorLayer(ph2 + '/' + fname, label, 'ogr')
            pi  = lyr.fields().indexOf('pon_no')
            zi  = lyr.fields().indexOf('zone_no')
            attr_map = {}
            for feat in lyr.getFeatures():
                if feedback.isCanceled():
                    return
                geom = feat.geometry()
                if not geom or geom.isEmpty():
                    continue
                np_, nz = get_pon_zone(geom.asPoint())
                pv = str(feat['pon_no']).strip(); zv = str(feat['zone_no']).strip()
                cur_p = int(pv) if pv.isdigit() else 0
                cur_z = int(zv) if zv.isdigit() else 0
                if np_ and (cur_p != np_ or cur_z != nz):
                    attr_map[feat.id()] = {pi: np_, zi: nz}
            if attr_map:
                lyr.dataProvider().changeAttributeValues(attr_map)
            feedback.pushInfo(f'  {label}: {len(attr_map)} updated')

        def propagate_lines(fname, label, end_idx=None):
            """Propagate pon_no/zone_no for line features.
            end_idx: -1 = use last vertex (drop ONT-end), 0 = use first vertex,
                     None = midpoint (least reliable; only when both ends ambiguous).
            For drops/spare drops the ONT endpoint (last vertex) is canonical;
            midpoint can land in a neighbouring PON near boundaries and clobber.
            """
            lyr = QgsVectorLayer(ph2 + '/' + fname, label, 'ogr')
            pi  = lyr.fields().indexOf('pon_no')
            zi  = lyr.fields().indexOf('zone_no')
            attr_map = {}
            for feat in lyr.getFeatures():
                if feedback.isCanceled():
                    return
                geom = feat.geometry()
                if not geom or geom.isEmpty():
                    continue
                if end_idx is None:
                    mid = geom.interpolate(geom.length() / 2.0)
                    pt  = (mid if not mid.isEmpty() else geom.centroid()).asPoint()
                else:
                    verts = list(geom.vertices())
                    if not verts: continue
                    pt = QgsPointXY(verts[end_idx])
                np_, nz = get_pon_zone(pt)
                pv = str(feat['pon_no']).strip(); zv = str(feat['zone_no']).strip()
                cur_p = int(pv) if pv.isdigit() else 0
                cur_z = int(zv) if zv.isdigit() else 0
                # Only write if we got a definitive PON-contains answer AND values differ
                if np_ and (cur_p != np_ or cur_z != nz):
                    attr_map[feat.id()] = {pi: np_, zi: nz}
            if attr_map:
                lyr.dataProvider().changeAttributeValues(attr_map)
            feedback.pushInfo(f'  {label}: {len(attr_map)} updated')

        feedback.pushInfo('Propagating to all layers …')
        propagate_points('poles v1.shp',                  'Poles v1')
        propagate_points('Enclosure v1.shp',              'Enclosure v1')
        propagate_points('Enclosures Connectorised v1.shp','Enclosures Connectorised v1')
        propagate_points('Enclosures Splice v1.shp',      'Enclosures Splice v1')
        propagate_points('STS Splitters v1.shp',          'STS Splitters v1')
        propagate_points('ONT v1.shp',                    'ONT v1')
        propagate_points('Home Connection v1.shp',        'Home Connection v1')
        # Drops: ONT endpoint (last vertex) is canonical
        propagate_lines('Drop Cable v1.shp',          'Drop Cable v1',          end_idx=-1)
        propagate_lines('Spare Drop Cable v1.shp',    'Spare Drop Cable v1',    end_idx=-1)
        # Feeders: midpoint is acceptable since they cross a PON polygon
        propagate_lines('Secondary Cable v1.shp',    'Secondary Cable v1')
        propagate_lines('Distribution Cable v1.shp', 'Distribution Cable v1')

        # ── Zones v1 ─────────────────────────────────────────────────────────
        feedback.pushInfo('Updating Zones v1 …')
        # Zone 21 (PON 299, 300) included — deliberate per project_ph2_zone_21_deliberate.md
        zone_first = {17: 235, 18: 251, 19: 267, 20: 283, 21: 299}
        zones  = QgsVectorLayer(ph2 + '/Zones v1.shp', 'zones', 'ogr')
        zl_idx = zones.fields().indexOf('label')
        zp_idx = zones.fields().indexOf('pon_no')
        zz_idx = zones.fields().indexOf('zone_no')
        # B6 fix 2026-04-28: guard against missing fields — changeAttributeValues
        # with {-1: val} would raise.
        zones_map = {}
        if zl_idx < 0 or zz_idx < 0:
            feedback.pushWarning(
                f'Zones v1 missing required fields '
                f'(label={zl_idx}, zone_no={zz_idx}) — skipping Zones update'
            )
            zones_features = []  # empty so the loop below is a no-op
        else:
            zones_features = list(zones.getFeatures())
        for feat in zones_features:
            pv = str(feat['pon_no']).strip()
            if not pv.isdigit():
                continue
            new_zone = (int(pv) - 235) // 16 + 17
            new_pon  = zone_first.get(new_zone)
            new_lbl  = re.sub(r'^(MOA\.\w+\.)(\d+)(\.)',
                              lambda m: f'{m.group(1)}{new_zone}{m.group(3)}', str(feat['label']))
            if new_pon:
                fc = (new_pon - 1) // 16 + 1
                fp = new_pon - (fc - 1) * 16
                new_lbl = re.sub(r'C\d+P\d+', f'C{fc}P{fp:02d}', new_lbl)
            row = {zz_idx: new_zone, zl_idx: new_lbl}
            if new_pon:
                row[zp_idx] = new_pon
            zones_map[feat.id()] = row
        if zones_map:
            zones.dataProvider().changeAttributeValues(zones_map)

        # ── Validate ─────────────────────────────────────────────────────────
        fts2   = QgsVectorLayer(ph2 + '/FTS Splitters v1.shp', 'v', 'ogr')
        wrong  = sum(1 for f in fts2.getFeatures()
                     if str(f['pon_no']).strip().isdigit() and str(f['zone_no']).strip().isdigit()
                     and int(str(f['zone_no']).strip()) != (int(str(f['pon_no']).strip()) - 235) // 16 + 17)
        pon3   = QgsVectorLayer(ph2 + '/PON v1.shp', 'v', 'ogr')
        pvals  = sorted(int(str(f['pon_no']).strip()) for f in pon3.getFeatures()
                        if str(f['pon_no']).strip().isdigit())
        # Validate full PH2 PON range 235-300 (Zone 21 includes 299, 300)
        upper = max(pvals) + 1 if pvals else 299
        upper = max(upper, 301)  # always check at least up to 300
        missing = [p for p in range(235, upper) if p not in pvals and p <= 300]
        dupes   = [p for p in set(pvals) if pvals.count(p) > 1]

        summary = (f'FTS mismatches={wrong}  PON range={min(pvals)}-{max(pvals)}'
                   f'  missing={missing}  dupes={dupes}')
        feedback.pushInfo(f'Validation: {summary}')
        if wrong == 0 and not missing and not dupes:
            feedback.pushInfo('✅ All checks passed')

        return {self.RESULT: summary}

    def createInstance(self):
        return FTApplyPonOrderAlgorithm()
