# -*- coding: utf-8 -*-
# "Generate HLD PDF" (BETA) — settings dialog + background run + PASS/FAIL report.
# The dialog is modal and short-lived (just collects settings). The heavy render runs
# in a separate QGIS process via a QgsTask, so the live session never freezes.
import os
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QLineEdit,
    QSpinBox, QCheckBox, QPushButton, QFileDialog, QMessageBox, QWidget, QComboBox,
)
from qgis.core import QgsApplication, QgsProject


def _downloads():
    d = os.path.join(os.path.expanduser("~"), "Downloads")
    return d if os.path.isdir(d) else os.path.expanduser("~")


class HldPdfDialog(QDialog):
    def __init__(self, parent, default_dir, meta, coverage_names, default_coverage,
                 coverage_layers=None, models=None, default_model="hld_atlas",
                 clients=None, default_client="fibertime", count_tables=None):
        super().__init__(parent)
        self.setWindowTitle("Generate HLD PDF  —  BETA")
        self.setMinimumWidth(580)
        self._dir = default_dir
        self._title = meta.get("title", "HLD")
        self._cov_by_name = {l.name(): l for l in (coverage_layers or [])}
        self._count_tables = count_tables or []

        c = _theme()
        root = QVBoxLayout(self)

        # BETA badge + explainer — colours derived from the live theme, never hardcoded
        badge = QLabel("● BETA")
        badge.setStyleSheet((f"color:{c['warn']};" if c["warn"] else "") + "font-weight:bold;")
        root.addWidget(badge)
        info = QLabel(
            "Builds an A3 PDF map-book — an overview page plus one detail page per unit — "
            "with legend, logo and title block.\n\n"
            "Runs in a separate process, so QGIS stays responsive and cannot freeze. It writes "
            "a NEW PDF and a NEW editable “… .qgz” copy; your working project is NOT modified."
        )
        info.setWordWrap(True)
        if c["ink"]:
            info.setStyleSheet(f"color:{c['ink']};")   # body text: full contrast on any theme
        root.addWidget(info)

        # ── Layout model + client (structure + branding) ──
        root.addWidget(_section("LAYOUT & CLIENT"))
        mform = QFormLayout()
        self.model_combo = QComboBox()
        for mid, disp, _u in (models or [("hld_atlas", "HLD Network Atlas", False)]):
            self.model_combo.addItem(disp, mid)
        _mi = self.model_combo.findData(default_model)
        if _mi >= 0:
            self.model_combo.setCurrentIndex(_mi)
        mform.addRow("Layout model:", self.model_combo)

        self.client_combo = QComboBox()
        for cid, disp, _u in (clients or [("fibertime", "Fibertime", False)]):
            self.client_combo.addItem(disp, cid)
        _ci = self.client_combo.findData(default_client)
        if _ci >= 0:
            self.client_combo.setCurrentIndex(_ci)
        mform.addRow("Client (branding):", self.client_combo)

        # count-tables editor — only relevant to models that use them (commercial)
        self.counts_btn = QPushButton("Edit count tables…")
        self.counts_btn.clicked.connect(self._edit_counts)
        mform.addRow("Count tables:", self.counts_btn)
        root.addLayout(mform)
        self.model_combo.currentIndexChanged.connect(self._on_model_changed)

        # ── Title block (per-project; auto-filled, editable, remembered) ──
        root.addWidget(_section("TITLE BLOCK"))
        form = QFormLayout()
        self.title_edit = QLineEdit(meta.get("title", ""))
        form.addRow("Project title:", self.title_edit)
        self.designer_edit = QLineEdit(meta.get("designer", ""))
        form.addRow("Designer:", self.designer_edit)
        self.company_edit = QLineEdit(meta.get("company", "Velocity Fibre"))
        form.addRow("Company:", self.company_edit)
        self.revision_edit = QLineEdit(str(meta.get("revision", "1")))
        form.addRow("Revision:", self.revision_edit)

        # coverage layer (the per-page driver, auto-detected)
        self.cov_combo = QComboBox()
        for n in coverage_names:
            self.cov_combo.addItem(n)
        if default_coverage and default_coverage in coverage_names:
            self.cov_combo.setCurrentText(default_coverage)
        form.addRow("One page per (coverage):", self.cov_combo)
        self.cov_preview = QLabel("")
        self.cov_preview.setStyleSheet((f"color:{c['accent']};" if c["accent"] else "") + "font-size:11px;")
        form.addRow("", self.cov_preview)
        if not coverage_names:
            self.cov_combo.addItem("— no polygon layers found —")
            self.cov_combo.setEnabled(False)
        self.cov_combo.currentTextChanged.connect(self._update_cov_preview)
        self._update_cov_preview(self.cov_combo.currentText())
        root.addLayout(form)

        # ── Output ──
        root.addWidget(_section("OUTPUT"))
        form2 = QFormLayout()
        self.dir_edit = QLineEdit(default_dir)
        browse = QPushButton("Browse…"); browse.clicked.connect(self._pick_dir)
        row = QHBoxLayout(); row.addWidget(self.dir_edit); row.addWidget(browse)
        rw = QWidget(); rw.setLayout(row)
        form2.addRow("Output folder:", rw)
        self.name_edit = QLineEdit(f"{self._title} HLD")
        form2.addRow("File name:", self.name_edit)
        self.dpi_spin = QSpinBox(); self.dpi_spin.setRange(72, 400); self.dpi_spin.setValue(150)
        form2.addRow("Resolution (DPI):", self.dpi_spin)
        self.compress_chk = QCheckBox("Also make a smaller emailable copy  (… (email).pdf)")
        self.compress_chk.setChecked(True)
        form2.addRow("", self.compress_chk)
        self.editable_chk = QCheckBox("Also save an editable “… HLD.qgz” copy")
        self.editable_chk.setChecked(True)
        form2.addRow("", self.editable_chk)
        root.addLayout(form2)

        # keep the file name following the title until the user edits it themselves
        self._name_touched = False
        self.name_edit.textEdited.connect(lambda *_: setattr(self, "_name_touched", True))
        self.title_edit.textChanged.connect(self._sync_name)
        self._on_model_changed()   # set counts-button state for the initial model

        # buttons
        btns = QHBoxLayout(); btns.addStretch(1)
        cancel = QPushButton("Cancel"); cancel.clicked.connect(self.reject)
        self.gen_btn = QPushButton("Generate PDF"); self.gen_btn.setDefault(True)
        self.gen_btn.clicked.connect(self.accept)
        btns.addWidget(cancel); btns.addWidget(self.gen_btn)
        root.addLayout(btns)

    def _is_commercial(self):
        return self.model_combo.currentData() == "commercial_grid"

    def _on_model_changed(self, *_):
        # count tables only apply to the commercial model; coverage picker is HLD-centric
        comm = self._is_commercial()
        self.counts_btn.setEnabled(comm)
        self.counts_btn.setText("Edit count tables…" if comm
                                else "Edit count tables…  (commercial model only)")

    def _edit_counts(self):
        dlg = CountsDialog(self, self._count_tables)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self._count_tables = dlg.result_tables()

    def _sync_name(self, txt):
        if not self._name_touched:
            self.name_edit.setText(f"{txt.strip()} HLD" if txt.strip() else "HLD")

    def _update_cov_preview(self, name):
        """Show exactly what one page will be, so the choice is unambiguous."""
        lyr = self._cov_by_name.get(name)
        if lyr is None:
            self.cov_preview.setText("")
            return
        try:
            from .presets import coverage_descriptor
            unit, id_field, _sort = coverage_descriptor(lyr)
            n = lyr.featureCount()
            self.cov_preview.setText(f"→ {n} pages: one per {unit}  (heading “{unit} …”, by {id_field})")
        except Exception:
            self.cov_preview.setText("")

    def _pick_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Output folder", self.dir_edit.text() or self._dir)
        if d:
            self.dir_edit.setText(d)

    def values(self):
        name = (self.name_edit.text() or f"{self._title} HLD").strip()
        if name.lower().endswith(".pdf"):
            name = name[:-4]
        cov = self.cov_combo.currentText() if self.cov_combo.isEnabled() else ""
        return {
            "dir": self.dir_edit.text().strip() or self._dir,
            "name": name,
            "dpi": self.dpi_spin.value(),
            "compress": self.compress_chk.isChecked(),
            "editable": self.editable_chk.isChecked(),
            "title": self.title_edit.text().strip(),
            "designer": self.designer_edit.text().strip(),
            "company": self.company_edit.text().strip(),
            "revision": self.revision_edit.text().strip() or "1",
            "coverage": cov,
            "model": self.model_combo.currentData(),
            "client": self.client_combo.currentData(),
            "count_tables": self._count_tables,
        }


DEFAULT_COUNT_TABLES = [
    {"title": "Commercial HP Counts", "headers": ["Zoning", "Informal", "Formal", "Total HPs"],
     "rows": [["Residential", "", "", ""], ["Business", "", "", ""], ["Special", "", "", ""],
              ["Industrial", "", "", ""], ["MDU", "", "", ""], ["Grand Total", "", "", ""]]},
    {"title": "Commercial Erf Counts", "headers": ["Zoning", "Informal", "Formal", "Total Erf"],
     "rows": [["Residential", "", "", ""], ["Business", "", "", ""], ["Special", "", "", ""],
              ["Industrial", "", "", ""], ["MDU", "", "", ""], ["Grand Total", "", "", ""]]},
]


class CountsDialog(QDialog):
    """Manual count-table entry (HP + Erf), saved with the project. No numbers are
    computed/guessed — these are exactly what you type."""
    def __init__(self, parent, tables):
        super().__init__(parent)
        from qgis.PyQt.QtWidgets import QTableWidget, QTableWidgetItem
        self.setWindowTitle("Commercial count tables")
        self.setMinimumWidth(460)
        c = _theme()
        root = QVBoxLayout(self)
        hint = QLabel("Type the counts exactly as they should appear. Saved with the project "
                      "and reused each render. Leave blank to omit a cell.")
        hint.setWordWrap(True)
        if c["ink"]:
            hint.setStyleSheet(f"color:{c['ink']};")
        root.addWidget(hint)
        self._widgets = []
        src = tables if tables else DEFAULT_COUNT_TABLES
        for t in src:
            root.addWidget(_section(t.get("title", "")))
            headers = t.get("headers", ["Zoning", "Informal", "Formal", "Total"])
            rows = t.get("rows", [])
            tw = QTableWidget(len(rows), len(headers))
            tw.setHorizontalHeaderLabels(headers)
            for r, row in enumerate(rows):
                for col in range(len(headers)):
                    val = row[col] if col < len(row) else ""
                    tw.setItem(r, col, QTableWidgetItem(str(val)))
            tw.resizeColumnsToContents()
            root.addWidget(tw)
            self._widgets.append((t.get("title", ""), headers, tw))
        btns = QHBoxLayout(); btns.addStretch(1)
        cancel = QPushButton("Cancel"); cancel.clicked.connect(self.reject)
        ok = QPushButton("Save"); ok.setDefault(True); ok.clicked.connect(self.accept)
        btns.addWidget(cancel); btns.addWidget(ok)
        root.addLayout(btns)

    def result_tables(self):
        out = []
        for title, headers, tw in self._widgets:
            rows = []
            for r in range(tw.rowCount()):
                row = []
                for col in range(tw.columnCount()):
                    it = tw.item(r, col)
                    row.append(it.text().strip() if it else "")
                if any(row):
                    rows.append(row)
            out.append({"title": title, "headers": headers, "rows": rows})
        return out


def _theme():
    """Readable colours for the CURRENT QGIS theme (light/dark/custom)."""
    try:
        try:
            from .. import theme_safe
        except ImportError:
            import theme_safe
        return theme_safe.colors()
    except Exception:
        # never let a colour helper break the dialog — fall back to palette default
        return {"ink": "", "muted": "", "accent": "", "warn": "", "ok": "", "bad": ""}


def _section(text):
    c = _theme()
    lbl = QLabel(f"// {text}")
    css = "font-weight:bold;font-size:11px;margin-top:6px;"
    if c["accent"]:
        css = f"color:{c['accent']};" + css
    lbl.setStyleSheet(css)
    return lbl


def open_hld_pdf_dialog(iface):
    """Entry point wired to the Nexus menu. Collects settings then launches the background render."""
    mw = iface.mainWindow()
    proj = QgsProject.instance()
    project_path = proj.fileName()
    if not project_path or not os.path.exists(project_path):
        QMessageBox.warning(mw, "Save project first",
                            "Please save your QGIS project (.qgz) first — the HLD PDF is rendered "
                            "from the saved project in a separate process.")
        return
    if proj.isDirty():
        r = QMessageBox.question(
            mw, "Unsaved changes",
            "The project has unsaved changes. The PDF is rendered from the SAVED file, so recent "
            "edits won't appear.\n\nSave now and continue?",
            QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Cancel)
        if r == QMessageBox.StandardButton.Cancel:
            return
        if not proj.write():
            QMessageBox.critical(mw, "Save failed", "Could not save the project. Aborting.")
            return

    # inspect the OPEN project so the dialog auto-fills for ANY project
    from . import presets
    from .presets import (build_config, find_python_qgis, polygon_layers,
                          best_coverage_layer, coverage_descriptor,
                          load_project_meta, save_project_meta, derive_hld_cfg,
                          list_models, list_clients, load_model, load_client, deep_merge)
    import json
    from qgis.core import QgsSettings
    cov_layers = polygon_layers(proj)
    cov_names = [l.name() for l in cov_layers]
    best_cov = best_coverage_layer(proj)
    default_cov = best_cov.name() if best_cov else ""
    meta = load_project_meta(project_path)

    # persisted model/client/counts for this project
    s = QgsSettings()
    mkey = presets._meta_key(project_path)
    def_model = s.value(f"{mkey}/model", "hld_atlas")
    def_client = s.value(f"{mkey}/client", "fibertime")
    try:
        saved_counts = json.loads(s.value(f"{mkey}/counts", "") or "[]")
    except Exception:
        saved_counts = []

    dlg = HldPdfDialog(mw, _downloads(), meta, cov_names, default_cov, cov_layers,
                       models=list_models(), default_model=def_model,
                       clients=list_clients(), default_client=def_client,
                       count_tables=saved_counts)
    if dlg.exec() != QDialog.DialogCode.Accepted:
        return
    v = dlg.values()

    # remember for next time (title block + model/client/counts)
    save_project_meta(project_path, {"title": v["title"], "designer": v["designer"],
                                     "company": v["company"], "revision": v["revision"]})
    s.setValue(f"{mkey}/model", v["model"])
    s.setValue(f"{mkey}/client", v["client"])
    s.setValue(f"{mkey}/counts", json.dumps(v["count_tables"]))

    # ── compose HLD_CFG: client branding < model structure < project text (project wins) ──
    model = load_model(v["model"]) or {"hld_cfg": {}}
    client = load_client(v["client"]) or {"hld_cfg": {}}
    hld_cfg = deep_merge(client["hld_cfg"], model["hld_cfg"])   # model structure wins over client
    brand = {}
    if v["title"]:
        brand["project_name"] = v["title"]
    if v["designer"]:
        brand["designer"] = v["designer"]
    if v["company"]:
        brand["company"] = v["company"]
    if v["revision"]:
        brand["revision"] = str(v["revision"])
    import datetime as _dt
    brand["date_str"] = _dt.date.today().strftime("%d-%m-%Y")
    hld_cfg = deep_merge(hld_cfg, brand)

    if v["model"] == "commercial_grid":
        hld_cfg["count_tables"] = v["count_tables"]
    else:
        # HLD model: coverage + per-page heading come from the dropdown + title
        cov_layer = next((l for l in cov_layers if l.name() == v["coverage"]), None)
        descriptor = coverage_descriptor(cov_layer) if cov_layer else None
        cov_cfg = derive_hld_cfg(v["title"], "", "", "", v["coverage"], descriptor)
        hld_cfg = deep_merge(hld_cfg, cov_cfg)

    out_dir = v["dir"]
    try:
        os.makedirs(out_dir, exist_ok=True)
    except Exception as e:
        QMessageBox.critical(mw, "Bad folder", f"Cannot use that output folder:\n{e}")
        return

    out_pdf = os.path.join(out_dir, v["name"] + ".pdf")
    out_project = os.path.join(out_dir, v["name"] + ".qgz") if v["editable"] else None
    work = os.path.join(out_dir, "_hld_work")
    os.makedirs(work, exist_ok=True)
    cfg_path = os.path.join(work, "config.json")
    result_path = os.path.join(work, "result.json")
    tmp = os.path.join(work, "_tmp")

    if not find_python_qgis():
        QMessageBox.critical(mw, "QGIS launcher missing",
                             "Could not find python-qgis.bat next to your QGIS install — cannot "
                             "start the background render.")
        return

    import json
    cfg = build_config(project_path, out_pdf, out_project, v["dpi"], v["compress"],
                       tmp, result_path, hld_cfg=hld_cfg)
    with open(cfg_path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
    # clear any stale result so we never read a previous run's outcome
    try:
        if os.path.exists(result_path):
            os.remove(result_path)
    except Exception:
        pass

    bar = iface.messageBar()
    bar.pushInfo("HLD PDF", "Generating in the background — QGIS stays usable. This takes a few minutes…")

    def on_done(result, error):
        if result and result.get("ok"):
            pages = result.get("pages", "?")
            size = result.get("size_mb", "?")
            email = result.get("email")
            proj_copy = result.get("output_project")
            the_pdf = result.get("output") or out_pdf
            msg = [f"✅ HLD PDF generated — {pages} pages, {size} MB.",
                   "", f"PDF:\n{the_pdf}"]
            if email:
                msg += ["", f"Emailable copy:\n{email}"]
            if proj_copy:
                msg += ["", f"Editable project (open in QGIS to tweak layouts):\n{proj_copy}"]
            box = QMessageBox(mw)
            box.setIcon(QMessageBox.Icon.Information)
            box.setWindowTitle("HLD PDF — Done")
            box.setText("\n".join(msg))
            # Open the EXACT PDF (default) so a stale look-alike in the folder can't be
            # opened by mistake — that was the "it ignored my choice" confusion.
            open_pdf_btn = box.addButton("Open PDF", QMessageBox.ButtonRole.AcceptRole)
            open_dir_btn = box.addButton("Open folder", QMessageBox.ButtonRole.ActionRole)
            box.addButton("Close", QMessageBox.ButtonRole.RejectRole)
            box.setDefaultButton(open_pdf_btn)
            box.exec()
            clicked = box.clickedButton()
            try:
                if clicked is open_pdf_btn and os.path.exists(the_pdf):
                    os.startfile(the_pdf)  # noqa: S606 - open the exact PDF just written
                elif clicked is open_dir_btn:
                    os.startfile(out_dir)  # noqa: S606
            except Exception:
                pass
        else:
            detail = (result or {}).get("message") or error or "unknown error"
            stage = (result or {}).get("stage", "?")
            QMessageBox.critical(mw, "HLD PDF — Failed",
                                 f"Could not generate the PDF.\n\nStage: {stage}\n{detail}\n\n"
                                 f"Log/config: {work}")

    from .runner import HldGenerateTask
    task = HldGenerateTask(cfg_path, result_path, on_done, timeout=1800)
    # keep a reference so the task isn't garbage-collected mid-run
    global _ACTIVE_TASK
    _ACTIVE_TASK = task
    QgsApplication.taskManager().addTask(task)


_ACTIVE_TASK = None
