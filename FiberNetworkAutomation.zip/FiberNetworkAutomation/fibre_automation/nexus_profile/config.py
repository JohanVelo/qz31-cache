"""config — Velocity Nexus backend connection + feature constants.

The SUPABASE_URL and SUPABASE_ANON_KEY are PUBLIC by design (anon key is
insert-only via RLS — see supabase/schema.sql). They are filled in once the
Supabase project exists (Phase 1). TEAM_CODE_HASH is the SHA-256 of the team
code (= the activation password); the plaintext NEVER ships.

The owner's admin READ key is NOT here — it lives only in JJ's QgsSettings
(key VelocityFibre/nexus/adminKey) and is read at runtime by the Team Monitor.
"""

# ── backend (Velocity Nexus Supabase project, eu-west-1) ─────────────────────
SUPABASE_URL = "https://hrrdohlrfrficrtphcet.supabase.co"
# Publishable key — safe to ship; insert-only via RLS (NOT the secret key).
SUPABASE_ANON_KEY = "sb_publishable_LLMH2UZAmWGRws9j-aIWRQ_wVJ9qeOF"
# Relay edge function base (per-user auth: /plugin-login, /my-notifications, /my-resolved).
FUNCTIONS_URL = SUPABASE_URL + "/functions/v1/velocity-relay"

# SHA-256 hex of the team code (= the activation password).
# Plaintext never ships; only this hash does.
TEAM_CODE_HASH = "955e37ef84ac1c0836b54ec4144237b7a56185a1f2a77c2c7687788b7cbb753a"

# ── behaviour ────────────────────────────────────────────────────────────────
# Live now that the backend is configured. (Still auto-falls-back to the spool
# whenever offline.) Set True to develop without writing to the live DB.
DRY_RUN_DEFAULT = False

HEARTBEAT_MS = 60_000          # presence ping cadence
EVENT_FLUSH_MS = 30_000        # batch flush cadence
EVENT_FLUSH_COUNT = 10         # ...or flush when this many queued
BREADCRUMB_MAX = 100           # rolling action buffer per session
ERROR_MIN_INTERVAL_S = 60      # rate-limit error POSTs (crash-loop guard)
SPOOL_MAX_BYTES = 10 * 1024 * 1024   # 10 MB cap; drop oldest beyond this
ONLINE_WINDOW_S = 600          # "online now" = heartbeat within 10 min

SCHEMA_VERSION = 1
CONSENT_VERSION = "1.0"

# QgsSettings keys (under the existing VelocityFibre/* namespace — DO NOT rename,
# they carry identity/activation across versions)
SETTINGS_NS = "VelocityFibre"
KEY_INSTALL_ID = "nexus/installId"
KEY_USERNAME = "nexus/username"
KEY_PROFILE = "nexus/profile"          # JSON blob (display name, theme, etc.)
KEY_WHATS_NEW = "whatsNewVersion"
KEY_ADMIN_READ = "nexus/adminKey"      # owner-only; never shipped
KEY_TELEMETRY_ENABLED = "nexus/telemetryEnabled"
KEY_CONSENT = "nexus/consentVersion"
KEY_USER_TOKEN = "nexus/userToken"     # per-user HMAC token from /plugin-login (closes my_* spoofing)

# The single admin username allowed to open the Team Monitor (JJ). The monitor
# ALSO requires the admin read-key to be present, so this is belt-and-braces.
ADMIN_USERNAME = "jj"          # set to JJ's chosen username at Phase 3


def is_backend_configured():
    return bool(SUPABASE_URL and SUPABASE_ANON_KEY)
