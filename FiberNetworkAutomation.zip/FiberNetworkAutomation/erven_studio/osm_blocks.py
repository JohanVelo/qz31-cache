"""No-data erven fallback: where the CSG cadastre has NO coverage, GENERATE
regular rectangular stands from the OSM road network.

Pipeline (offline, erven_studio venv — never on the QGIS main thread):
  1. fetch the OSM street network for the AOI (OSMnx),
  2. polygonize the edges into road-bounded BLOCK polygons,
  3. subdivide each block into regular ~14x22 m stands (erven_obb) — building-
     anchored if building centroids are supplied, else a uniform grid.

NEVER Voronoi. Decision ladder: try CSG first (csg_erven.py); only fall back
to this for genuinely uncadastred informal land. See guides/NODATA_CADASTRE_PLAN.
"""
import osmnx as ox
import geopandas as gpd
from shapely.geometry import box
from shapely.ops import polygonize, unary_union
import erven_obb as e

METRIC = 'EPSG:32735'   # UTM 35S (Mohadin); swap per AOI if needed


def blocks_from_osm(xmin, ymin, xmax, ymax, min_area_m2=400, max_area_m2=80000):
    """Road-bounded block polygons (in METRIC crs) for the lon/lat bbox."""
    aoi = box(xmin, ymin, xmax, ymax)
    G = ox.graph_from_polygon(aoi, network_type='all', simplify=True,
                              retain_all=True, truncate_by_edge=True)
    edges = ox.graph_to_gdfs(G, nodes=False, edges=True)
    merged = unary_union(list(edges.geometry))           # noded line network
    raw = [p for p in polygonize(merged)]
    if not raw:
        return []
    g = gpd.GeoDataFrame(geometry=raw, crs='EPSG:4326').to_crs(METRIC)
    g = g[g.geometry.is_valid & ~g.geometry.is_empty]
    g['a'] = g.geometry.area
    g = g[(g.a >= min_area_m2) & (g.a <= max_area_m2)]   # drop slivers + the AOI-hull
    return list(g.geometry)


def generate_nodata_erven(xmin, ymin, xmax, ymax, building_pts_lonlat=None):
    """Generate regular erven for an uncadastred AOI. building_pts_lonlat =
    optional [(lon,lat),...] to anchor stands on real structures; else uniform.
    Returns erven as a GeoDataFrame in EPSG:4326."""
    blocks = blocks_from_osm(xmin, ymin, xmax, ymax)
    if not blocks:
        return gpd.GeoDataFrame(geometry=[], crs='EPSG:4326')

    seeds_m = []
    if building_pts_lonlat:
        bp = gpd.GeoSeries(gpd.points_from_xy(*zip(*building_pts_lonlat)),
                           crs='EPSG:4326').to_crs(METRIC)
        seeds_m = [(p.x, p.y) for p in bp]

    erven = []
    for blk in blocks:
        in_seeds = [s for s in seeds_m if blk.buffer(1).contains(__import__('shapely').geometry.Point(s))]
        if in_seeds:
            ang = e.block_angle([blk]) if hasattr(e, 'block_angle') else None
            erven += e.subdivide_grid_by_buildings(
                blk.minimum_rotated_rectangle, in_seeds,
                depth_d=e.REF_DEPTH_M, min_w=10, max_w=18, angle=ang)
        else:
            erven += e.subdivide_block(blk, e.REF_FRONTAGE_M, e.REF_DEPTH_M)
    if not erven:
        return gpd.GeoDataFrame(geometry=[], crs='EPSG:4326')
    return gpd.GeoDataFrame(geometry=erven, crs=METRIC).to_crs('EPSG:4326')


if __name__ == '__main__':
    import sys
    bb = [float(x) for x in (sys.argv[1].split(',') if len(sys.argv) > 1
                             else '27.045,-26.728,27.052,-26.722'.split(','))]
    blks = blocks_from_osm(*bb)
    print(f'blocks from OSM: {len(blks)} (areas '
          f'{min((b.area for b in blks), default=0):.0f}-{max((b.area for b in blks), default=0):.0f} m2)')
    erv = generate_nodata_erven(*bb)
    print(f'generated erven: {len(erv)}'
          + (f', median area {erv.to_crs(METRIC).geometry.area.median():.0f} m2' if len(erv) else ''))
