"""Regular rectangular erf subdivision — OBB grid method (NEVER Voronoi).

Hard rule (JJ, repeated): erven must be REGULAR rectangular road-aligned
stands, not wiggly tessellation cells. This module subdivides a block polygon
(the area enclosed by roads) into a uniform grid of stands aligned to the
block's dominant axis:

  1. Compute the block's oriented bounding box → dominant orientation angle.
  2. Rotate the block to axis-aligned space.
  3. Lay a regular W (frontage) × D (depth) grid over its bbox.
  4. Keep cells whose centroid falls inside the block (clip partials to it).
  5. Rotate the stands back to world space.

Pure shapely (lives in the erven_studio venv, NOT the teammate QGIS plugin —
plain QGIS may lack shapely). Deterministic and unit-testable.
"""

import math
from shapely.geometry import box
from shapely import affinity

# Measured from JJ's REAL "Erven" layer (Potch–Mohadin PH2, 9,231 clean of
# 9,292, reprojected to UTM 35S) — this is the ground-truth to match, NOT the
# old 18×27 guess that made the previous attempt too big:
#   frontage median 14.1 m (p25 12.5 / p75 15.7)   ← varies; depth is tighter
#   depth    median 21.7 m (p25 20.9 / p75 23.0)
#   area     median 320 m2 (p25 264 / p75 360)
REF_FRONTAGE_M = 14.0
REF_DEPTH_M = 22.0
REF_AREA_M2 = 320.0


def obb_angle(polygon):
    """Dominant orientation (degrees) of the polygon's min rotated rectangle."""
    mrr = polygon.minimum_rotated_rectangle
    xs, ys = mrr.exterior.coords.xy
    # longest edge of the rectangle defines the dominant axis
    best_len, best_ang = -1.0, 0.0
    for i in range(len(xs) - 1):
        dx, dy = xs[i + 1] - xs[i], ys[i + 1] - ys[i]
        d = math.hypot(dx, dy)
        if d > best_len:
            best_len, best_ang = d, math.degrees(math.atan2(dy, dx))
    return best_ang


def subdivide_block(block, frontage_w, depth_d, min_area_frac=0.5,
                    keep_partial=True):
    """Subdivide *block* (shapely Polygon) into regular W×D stands aligned to
    its dominant axis.

    frontage_w : stand width along the road (m, in the layer's CRS units)
    depth_d    : stand depth (m)
    min_area_frac : drop stands smaller than this fraction of W*D after clipping
    keep_partial  : clip edge stands to the block (True) or drop them (False)

    Returns a list of shapely Polygons (world space).
    """
    if block.is_empty or block.area <= 0:
        return []
    ang = obb_angle(block)
    cx, cy = block.centroid.x, block.centroid.y
    # rotate block so its dominant axis is horizontal
    aligned = affinity.rotate(block, -ang, origin=(cx, cy))
    minx, miny, maxx, maxy = aligned.bounds
    full = frontage_w * depth_d
    stands = []
    y = miny
    while y < maxy:
        x = minx
        while x < maxx:
            cell = box(x, y, x + frontage_w, y + depth_d)
            piece = cell.intersection(aligned)
            if not piece.is_empty and piece.geom_type in ('Polygon',):
                if piece.area >= min_area_frac * full:
                    stands.append(cell if not keep_partial else piece)
                elif keep_partial and piece.area > 0 and \
                        piece.area >= 0.15 * full:
                    stands.append(piece)
            x += frontage_w
        y += depth_d
    # rotate stands back to world space
    return [affinity.rotate(s, ang, origin=(cx, cy)) for s in stands]


def subdivide_grid_by_buildings(block, building_points, depth_d=22.0,
                                min_w=10.0, max_w=18.0, group_radius=8.0,
                                angle=None):
    """Building-anchored erven with FIXED-DEPTH ROWS — matches real double-
    loaded blocks (two ~22 m-deep rows back-to-back) instead of giving each erf
    the full block depth (which doubled the area). Steps, in OBB-aligned space:
      1. band the block into rows of depth_d along the depth axis,
      2. within each row, take the buildings whose centroid is in that row,
      3. merge co-erf buildings (main house + outbuilding) within group_radius,
      4. partition the row's frontage at midpoints between the merged seeds,
         clamped to [min_w, max_w] → one regular rectangular erf per seed.
    Returns world-space shapely Polygons. Never Voronoi.
    """
    if block.is_empty or not building_points:
        return []
    from shapely.geometry import Point
    # street orientation: caller can pass the median building angle (robust);
    # else fall back to the block's oriented-bbox angle.
    ang = obb_angle(block) if angle is None else angle
    cx, cy = block.centroid.x, block.centroid.y
    aligned = affinity.rotate(block, -ang, origin=(cx, cy))
    minx, miny, maxx, maxy = aligned.bounds
    seeds = []
    for (x, y) in building_points:
        q = affinity.rotate(Point(x, y), -ang, origin=(cx, cy))
        if aligned.buffer(1e-9).contains(q):
            seeds.append((q.x, q.y))
    if not seeds:
        return []

    # PHASE the depth bands so their CENTRES land on the building rows (real
    # erven are centred on rows). Slide the fixed-width grid over [0, depth_d)
    # and pick the offset that puts seeds closest to band centres.
    ys = [s[1] for s in seeds]
    best_off, best_score = 0.0, -1e18
    off = 0.0
    while off < depth_d:
        score = 0.0
        for y in ys:
            rel = (y - (miny + off)) % depth_d
            score += depth_d / 2 - abs(rel - depth_d / 2)   # higher = nearer centre
        if score > best_score:
            best_score, best_off = score, off
        off += 2.0
    start = miny + best_off - depth_d        # may start below miny so row 0 is centred

    stands = []
    y0 = start
    while y0 < maxy - 1e-6:
        y1 = min(y0 + depth_d, maxy)
        if y1 <= miny:
            y0 = y1
            continue
        row = [s for s in seeds if y0 <= s[1] < y1]
        if row:
            row.sort()
            xs = [s[0] for s in row]
            # group co-erf buildings (close in frontage) into one seed
            grouped = []
            i = 0
            while i < len(xs):
                cluster = [xs[i]]
                j = i + 1
                while j < len(xs) and xs[j] - xs[j - 1] <= group_radius:
                    cluster.append(xs[j]); j += 1
                grouped.append(sum(cluster) / len(cluster)); i = j
            cuts = [minx] + [(grouped[k] + grouped[k + 1]) / 2.0
                             for k in range(len(grouped) - 1)] + [maxx]
            for k in range(len(cuts) - 1):
                left, right = cuts[k], cuts[k + 1]
                w = right - left
                if w > max_w:
                    left, right = grouped[k] - max_w / 2.0, grouped[k] + max_w / 2.0
                elif w < min_w:
                    c = (left + right) / 2.0
                    left, right = c - min_w / 2.0, c + min_w / 2.0
                cell = box(left, y0, right, y1).intersection(aligned)
                if not cell.is_empty and cell.geom_type == 'Polygon' and cell.area > 0:
                    stands.append(affinity.rotate(cell, ang, origin=(cx, cy)))
        y0 = y1
    return stands


def subdivide_block_by_buildings(block, building_points,
                                 min_w=10.0, max_w=18.0):
    """Building-ANCHORED erf generation — one neat rectangular erf per detected
    building, frontage width following the real building spacing (so erven are
    NOT a rigid uniform grid). Single-frontage version: splits the block into
    road-aligned strips at the midpoints between adjacent buildings projected
    onto the frontage axis. Each strip spans the block depth and is clipped to
    the block → regular rectangle, never Voronoi.

    block            : shapely Polygon (road-bounded block)
    building_points  : list of (x, y) building centroids (world coords)
    min_w / max_w    : clamp frontage width to keep erven neat/consistent

    Returns a list of shapely Polygons (one per building, world space).
    NOTE: double-loaded blocks (buildings facing two opposite roads) need a
    front/back split first — that refinement is pending the research round.
    """
    if block.is_empty or not building_points:
        return []
    ang = obb_angle(block)
    cx, cy = block.centroid.x, block.centroid.y
    aligned = affinity.rotate(block, -ang, origin=(cx, cy))
    minx, miny, maxx, maxy = aligned.bounds

    # project building centroids into aligned space, keep those inside, sort by x
    from shapely.geometry import Point
    proj = []
    for (x, y) in building_points:
        p = affinity.rotate(Point(x, y), -ang, origin=(cx, cy))
        if aligned.buffer(1e-9).contains(p):
            proj.append(p.x)
    if not proj:
        return []
    proj.sort()

    # cut lines at midpoints between adjacent buildings, clamped to [min,max]
    cuts = [minx]
    for i in range(len(proj) - 1):
        cuts.append((proj[i] + proj[i + 1]) / 2.0)
    cuts.append(maxx)

    stands = []
    for i in range(len(cuts) - 1):
        left, right = cuts[i], cuts[i + 1]
        w = right - left
        # clamp width around the building centre to keep erven neat
        if w > max_w:
            c = proj[i]
            left, right = c - max_w / 2.0, c + max_w / 2.0
        elif w < min_w:
            c = (left + right) / 2.0
            left, right = c - min_w / 2.0, c + min_w / 2.0
        cell = box(left, miny, right, maxy)
        piece = cell.intersection(aligned)
        if not piece.is_empty and piece.geom_type == 'Polygon' and piece.area > 0:
            stands.append(affinity.rotate(piece, ang, origin=(cx, cy)))
    return stands
