"""Phase 2 — teach buildings by example ("find similar").

Given one or a few example building masks, return the candidate buildings most similar in
appearance + shape. Dependency-light: SAM2 auto-masks as candidates (Phase 0/1 engine) + a
colour(LAB)+shape descriptor + z-scored nearest-to-example matching. A 'strictness' slider
controls how many are kept. Changing the example changes the result = example-driven selection.
"""
import numpy as np
import cv2
import geopandas as gpd
import torch
from rasterio.transform import Affine
from shapely.geometry import Polygon

from buildings import _sam2  # reuse cached SAM2 + constant


def candidate_masks(img, iou=0.66, stability=0.88, points_per_side=24, min_px=120):
    from sam2.automatic_mask_generator import SAM2AutomaticMaskGenerator
    model, dev = _sam2()
    gen = SAM2AutomaticMaskGenerator(model, points_per_side=points_per_side,
                                     pred_iou_thresh=iou, stability_score_thresh=stability,
                                     min_mask_region_area=min_px)
    autocast = (torch.autocast("cuda", dtype=torch.bfloat16) if dev == "cuda"
                else torch.autocast("cpu", dtype=torch.bfloat16))
    with torch.inference_mode(), autocast:
        masks = gen.generate(np.ascontiguousarray(img))
    return [m["segmentation"].astype(bool) for m in masks if m["segmentation"].sum() >= min_px]


def descriptor(img, mask):
    """[L, a, b (mean colour), log-area, aspect, solidity] — appearance + shape."""
    px = img[mask]
    lab = cv2.cvtColor(px.reshape(-1, 1, 3), cv2.COLOR_RGB2LAB).reshape(-1, 3).mean(0)
    cnts, _ = cv2.findContours(mask.astype("uint8"), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    ct = max(cnts, key=cv2.contourArea) if cnts else None
    area = float(mask.sum())
    if ct is not None and len(ct) >= 3:
        (_, _), (w, h), _ = cv2.minAreaRect(ct)
        aspect = (max(w, h) / max(min(w, h), 1e-3))
        hull = cv2.contourArea(cv2.convexHull(ct))
        solidity = area / hull if hull > 0 else 1.0
    else:
        aspect, solidity = 1.0, 1.0
    return np.array([lab[0], lab[1], lab[2], np.log1p(area), min(aspect, 6.0), solidity], float)


def find_similar(img, transform_6, example_masks, params=None, candidates=None):
    p = {"strictness": 0.5, "iou": 0.66, "stability": 0.88, "points_per_side": 24, **(params or {})}
    a, b, c, d, e, f = transform_6
    tr = Affine(a, b, c, d, e, f)
    cands = candidates if candidates is not None else candidate_masks(
        img, p["iou"], p["stability"], int(p["points_per_side"]))
    if not cands or not example_masks:
        return gpd.GeoDataFrame(geometry=[], crs=3857), cands

    cdesc = np.array([descriptor(img, m) for m in cands])
    mu, sd = cdesc.mean(0), cdesc.std(0) + 1e-6
    cz = (cdesc - mu) / sd
    ez = (np.array([descriptor(img, m) for m in example_masks]) - mu) / sd
    dist = np.min(np.linalg.norm(cz[:, None, :] - ez[None, :, :], axis=2), axis=1)  # nearest example
    cutoff = np.quantile(dist, np.clip(p["strictness"], 0.05, 0.95))                # slider
    keep = np.where(dist <= cutoff)[0]

    geoms = []
    for i in keep:
        cnts, _ = cv2.findContours(cands[i].astype("uint8"), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            continue
        ct = max(cnts, key=cv2.contourArea)
        if len(ct) < 3:
            continue
        poly = Polygon([tr * (float(x) + 0.5, float(y) + 0.5) for x, y in ct.reshape(-1, 2)]).buffer(0)
        if not poly.is_empty:
            geoms.append(poly)
    return gpd.GeoDataFrame(geometry=geoms, crs=3857), cands
