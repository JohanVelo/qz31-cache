"""Fibre Time master pipeline — thin wrappers over FT 1–8 algorithms.

Steps 1–8 delegate to the existing FiberNetworkAutomation processing algorithms.
Steps 9–10 are QA and output stubs.
"""



def _run_algorithm(algorithm_id: str, parameters: dict = None):
    """Run a FiberNetworkAutomation processing algorithm via the registry."""
    import processing
    params = parameters or {}
    try:
        result = processing.run(algorithm_id, params)
        return result
    except Exception as exc:
        print(f"  ✗ Algorithm '{algorithm_id}' failed: {exc}")
        return None


def ft_step_01_poles():
    """FT Step 1 — Label Poles (delegates to fibernetwork:ft_label_poles)."""
    print(f"\n{'═' * 50}")
    print("  FT STEP 1 — Label Poles")
    print(f"{'═' * 50}")
    _run_algorithm("fibernetwork:ft_label_poles")


def ft_step_02_distribution():
    """FT Step 2 — Distribution Cable (delegates to fibernetwork:ft_distribution_cable)."""
    print(f"\n{'═' * 50}")
    print("  FT STEP 2 — Distribution Cable")
    print(f"{'═' * 50}")
    _run_algorithm("fibernetwork:ft_label_distribution_cable")


def ft_step_03_secondary():
    """FT Step 3 — Secondary Cable (delegates to fibernetwork:ft_secondary_cable)."""
    print(f"\n{'═' * 50}")
    print("  FT STEP 3 — Secondary Cable")
    print(f"{'═' * 50}")
    _run_algorithm("fibernetwork:ft_label_secondary_cable")


def ft_step_04_enclosure():
    """FT Step 4 — Enclosure (delegates to fibernetwork:ft_enclosure)."""
    print(f"\n{'═' * 50}")
    print("  FT STEP 4 — Enclosure")
    print(f"{'═' * 50}")
    _run_algorithm("fibernetwork:ft_label_enclosure")


def ft_step_05_pon():
    """FT Step 5 — PON Zones (delegates to fibernetwork:ft_pon_zone)."""
    print(f"\n{'═' * 50}")
    print("  FT STEP 5 — PON Zones")
    print(f"{'═' * 50}")
    _run_algorithm("fibernetwork:ft_generate_pon_zones")


def ft_step_06_pon_order():
    """FT Step 6 — Apply PON Order (delegates to fibernetwork:ft_apply_pon_order)."""
    print(f"\n{'═' * 50}")
    print("  FT STEP 6 — Apply PON Order")
    print(f"{'═' * 50}")
    _run_algorithm("fibernetwork:ft_apply_pon_order")


def ft_step_07_thickness():
    """FT Step 7 — Pole Thickness (delegates to fibernetwork:ft_pole_thickness)."""
    print(f"\n{'═' * 50}")
    print("  FT STEP 7 — Pole Thickness")
    print(f"{'═' * 50}")
    _run_algorithm("fibernetwork:ft_pole_thickness")


def ft_step_08_rc_update():
    """FT Step 8 — Road Crossing Update (delegates to fibernetwork:ft_road_crossing_update)."""
    print(f"\n{'═' * 50}")
    print("  FT STEP 8 — Road Crossing Update")
    print(f"{'═' * 50}")
    _run_algorithm("fibernetwork:ft_road_crossing_update")


def ft_step_09_qa():
    """FT Step 9 — QA checks (delegates to audit_all_ph2.py)."""
    print(f"\n{'═' * 50}")
    print("  FT STEP 9 — QA Report")
    print(f"{'═' * 50}")
    import os
    from pathlib import Path
    audit_path = str(Path(__file__).parents[2] / "audit_all_ph2.py")
    if os.path.exists(audit_path):
        with open(audit_path) as _f:
            exec(_f.read(), {'__builtins__': __builtins__})
    else:
        print(f"  ✗ audit_all_ph2.py not found at: {audit_path}")


def ft_step_10_output():
    """FT Step 10 — Output / Export (stub)."""
    print(f"\n{'═' * 50}")
    print("  FT STEP 10 — Output / Export")
    print(f"{'═' * 50}")
    print("  ⚠ Step 10 is a stub — export not yet built.")
    print(f"{'═' * 50}\n")


FT_STEPS = {
    1: ft_step_01_poles,
    2: ft_step_02_distribution,
    3: ft_step_03_secondary,
    4: ft_step_04_enclosure,
    5: ft_step_05_pon,
    6: ft_step_06_pon_order,
    7: ft_step_07_thickness,
    8: ft_step_08_rc_update,
    9: ft_step_09_qa,
    10: ft_step_10_output,
}


def ft_run_step(n: int):
    """Run a single Fibre Time step by number (1–10)."""
    fn = FT_STEPS.get(n)
    if fn is None:
        print(f"  ✗ No Fibre Time step {n} (valid: 1–10)")
        return
    fn()


def ft_run_all():
    """Run all 10 Fibre Time steps in order."""
    print(f"\n{'═' * 55}")
    print("  FIBRE TIME FULL PIPELINE — Steps 1–10")
    print(f"{'═' * 55}\n")
    for n in range(1, 11):
        ft_run_step(n)
    print(f"\n{'═' * 55}")
    print("  FIBRE TIME PIPELINE COMPLETE")
    print(f"{'═' * 55}\n")
