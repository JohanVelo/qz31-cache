"""
Full audit of all Phase 2 v1 layers including ONT v1 and Drop Cable v1.

NOTE: this is the BUNDLED copy, run by FT Step 9 (fibre_automation/fibretime/pipeline.py).
The repo-root audit_all_ph2.py is a separate, larger file that the toolbar button runs.
The two have already drifted; keep the rule constants below in step with it.
"""
import os
import sys
from qgis.core import QgsVectorLayer

# Force UTF-8: this prints box-drawing characters and dies with UnicodeEncodeError on a
# cp1252 console, which is what it gets when FT Step 9 runs it through subprocess.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding='utf-8')
    except (AttributeError, ValueError):
        pass

# Phase 2 PON range, measured live 2026-08-12: 66 PONs spanning 235-300 inclusive.
# Read 298 here, which flagged every PON 299/300 feature as out of range. See
# projects/moa-ph2/known-issues.md — PON 299/300 and Zone 21 are design facts.
PON_MIN = 235
PON_MAX = 300

# Folder holding the Phase 2 shapefiles. Defaults to the original machine's path;
# on another machine set the MOA_PH2_DIR environment variable to your own folder.
PH2 = os.environ.get(
    'MOA_PH2_DIR',
    'C:/Users/jjsch/blitzfibre.com/Velocity_Manco - Velocity_Manco_Planning/Baseline Maps/FiberTime Planning/Potch - Mohadin PH2')

EXPECTED_STATIC = {
    'stackref': 'MOA',
    'mun':      'JB Marks LM',
    'cmpownr':  'VelocityFibre',
    'crtdby':   'Johan Scholtz',
}

def bad_val(v):
    return not v or str(v).strip() in ('NULL', '', 'None', 'None\\', 'null')

def bad_date(v):
    s = str(v).strip()
    return s in ('0', '**********', 'None', 'NULL', '', 'None\\') or s == '----------'


def _layer(name):
    """Audit against the layer OPEN IN THE PROJECT first (works on any
    machine); fall back to the dev shapefile folder only if absent."""
    try:
        from qgis.core import QgsProject
        proj = QgsProject.instance()
        hits = proj.mapLayersByName(name)
        if hits:
            return hits[0]
        # Case-insensitive fallback: mapLayersByName is case-sensitive, so a
        # project layer named 'Poles v1' would be missed by a 'poles v1' lookup.
        target = name.lower()
        for lyr in proj.mapLayers().values():
            if lyr.name().lower() == target:
                return lyr
    except Exception:
        pass
    return QgsVectorLayer(PH2 + '/' + name + '.shp', name, 'ogr')

def _safe_polyline(geom):
    """Return a flat list of vertices for single- OR multi-part line geometry
    (asPolyline() raises on MultiLineString)."""
    try:
        if geom.isMultipart():
            parts = geom.asMultiPolyline()
            return [p for part in parts for p in part]
        return geom.asPolyline()
    except Exception:
        return []

def check_island_splitters(feedback=None):
    """
    Detect FTS/STS splitters not connected to main network.
    Island FTS: no Secondary/Primary cable endpoint within 10m
    Island STS: no Distribution cable endpoint within 10m

    Returns: {'pass': bool, 'count': int, 'examples': [list of str]}
    """

    result = {'pass': True, 'count': 0, 'examples': []}

    fts_layer   = _layer('FTS Splitters v1')
    sts_layer   = _layer('STS Splitters v1')
    primary_layer   = _layer('Primary Cable v1')
    secondary_layer = _layer('Secondary Cable v1')
    dist_layer  = _layer('Distribution Cable v1')

    islands = []
    SNAP_M = 10.0 / 111320.0  # ~10 m in degrees (EPSG:4326), matches check_drops_per_sts

    # === Check FTS islands ===
    if fts_layer.isValid() and (primary_layer.isValid() or secondary_layer.isValid()):
        cable_endpoints = []
        if secondary_layer.isValid():
            for feat in secondary_layer.getFeatures():
                geom = feat.geometry()
                if geom and not geom.isEmpty():
                    poly = _safe_polyline(geom)
                    if len(poly) >= 2:
                        cable_endpoints.append(poly[0])
                        cable_endpoints.append(poly[-1])
        if primary_layer.isValid():
            for feat in primary_layer.getFeatures():
                geom = feat.geometry()
                if geom and not geom.isEmpty():
                    poly = _safe_polyline(geom)
                    if len(poly) >= 2:
                        cable_endpoints.append(poly[0])
                        cable_endpoints.append(poly[-1])
        _fts_has_lbl = fts_layer.fields().indexOf('label') >= 0
        for feat in fts_layer.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue
            pt = geom.asPoint()
            found_nearby = any(pt.distance(ep) <= SNAP_M for ep in cable_endpoints)
            if not found_nearby:
                lbl = feat['label'] if (_fts_has_lbl and feat['label']) else f'ID {feat.id()}'
                islands.append(('FTS', lbl, pt.x(), pt.y()))

    # === Check STS islands ===
    if sts_layer.isValid() and dist_layer.isValid():
        dist_endpoints = []
        for feat in dist_layer.getFeatures():
            geom = feat.geometry()
            if geom and not geom.isEmpty():
                poly = _safe_polyline(geom)
                if len(poly) >= 2:
                    dist_endpoints.append(poly[0])
                    dist_endpoints.append(poly[-1])
        _sts_has_lbl = sts_layer.fields().indexOf('label') >= 0
        for feat in sts_layer.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue
            pt = geom.asPoint()
            found_nearby = any(pt.distance(ep) <= SNAP_M for ep in dist_endpoints)
            if not found_nearby:
                lbl = feat['label'] if (_sts_has_lbl and feat['label']) else f'ID {feat.id()}'
                islands.append(('STS', lbl, pt.x(), pt.y()))

    if islands:
        result['pass'] = False
        result['count'] = len(islands)
        result['examples'] = [
            f"{isl[0]} island: {isl[1]} @ ({isl[2]:.5f}, {isl[3]:.5f})"
            for isl in islands[:10]
        ]
    return result


def check_enclosure_spec1(feedback=None):
    """
    Check that all enclosures have spec_1 field populated.
    Spec_1 should be set by FT4 (Enclosure Selection algorithm).

    Returns: {'pass': bool, 'count': int, 'examples': [list of str]}
    """

    result = {'pass': True, 'count': 0, 'examples': []}

    enc_layer      = _layer('Enclosure v1')
    enc_conn_layer = _layer('Enclosures Connectorised v1')

    missing = []
    for layer_name, layer in [('Enclosure v1', enc_layer), ('Enclosures Connectorised v1', enc_conn_layer)]:
        if not layer.isValid():
            continue
        field_names = [f.name() for f in layer.fields()]
        if 'spec_1' not in field_names:
            continue  # Field not yet added — skip gracefully
        for feat in layer.getFeatures():
            spec_val = feat['spec_1']
            if not spec_val or str(spec_val).strip() in ('NULL', '', 'None', 'None\\', 'null'):
                label = feat['label_1'] if 'label_1' in field_names else feat.get('label', 'UNKNOWN')
                missing.append((layer_name, label))

    if missing:
        result['pass'] = False
        result['count'] = len(missing)
        result['examples'] = [f"{m[0]}: {m[1]}" for m in missing[:10]]
    return result


def check_drops_per_sts(feedback=None):
    """
    Drop count per STS dome (merged from the fibretime_tools HLD audit, Phase 1).
    Counts drop-cable endpoints within ~10m of each STS splitter:
      ≤8 ok · 9–16 WARN · >16 FAIL (1:16 connectorised STS, 8-drop design target).
    Returns: {'pass': bool, 'count': int, 'examples': [str], optional 'skipped': bool}
    """
    from qgis.core import QgsSpatialIndex, QgsRectangle

    result = {'pass': True, 'count': 0, 'examples': []}
    sts_layer  = _layer('STS Splitters v1')
    drop_layer = _layer('Drop Cable v1')
    if not sts_layer.isValid() or not drop_layer.isValid():
        result['skipped'] = True
        return result

    # Index STS positions; each drop is assigned to the ONE nearest STS (within snap)
    # of its two endpoints — the STS-side end matches, the ONT-side end won't steal
    # counts from a neighbouring dome.
    sts_index = QgsSpatialIndex()
    sts_pts, sts_labels = {}, {}
    for sf in sts_layer.getFeatures():
        g = sf.geometry()
        if g and not g.isEmpty():
            sts_index.addFeature(sf)
            sts_pts[sf.id()] = g.asPoint()
            sts_labels[sf.id()] = (sf['label'] if sf.fields().indexOf('label') >= 0 and sf['label'] else f'ID {sf.id()}')

    SNAP = 10.0 / 111320.0  # ~10 m in degrees
    counts = {}
    for df in drop_layer.getFeatures():
        geom = df.geometry()
        if not geom or geom.isEmpty():
            continue
        poly = _safe_polyline(geom)
        if len(poly) < 2:
            continue
        best_fid, best_d = None, SNAP
        for pt in (poly[0], poly[-1]):
            rect = QgsRectangle(pt.x() - SNAP, pt.y() - SNAP, pt.x() + SNAP, pt.y() + SNAP)
            for fid in sts_index.intersects(rect):
                d = pt.distance(sts_pts[fid])
                if d < best_d:
                    best_d, best_fid = d, fid
        if best_fid is not None:
            counts[best_fid] = counts.get(best_fid, 0) + 1

    over_8, over_16 = [], []
    for fid, cnt in sorted(counts.items(), key=lambda kv: -kv[1]):
        if cnt > 16:
            over_16.append(f'{sts_labels[fid]}: {cnt} drops (>16 — FAIL)')
        elif cnt > 8:
            over_8.append(f'{sts_labels[fid]}: {cnt} drops (9–16 — warn)')

    if over_16:
        result['pass'] = False
    result['count'] = len(over_16) + len(over_8)
    result['examples'] = (over_16 + over_8)[:10]
    return result


def check_pop_ont_distance(feedback=None, max_km=8.0):
    """
    Max POP-to-ONT distance ≤ 8 km (merged from the fibretime_tools HLD audit, Phase 1).
    GPON optical budget rule: every ONT must be within 8 km of the POP.
    Returns: {'pass': bool, 'count': int, 'examples': [str], optional 'skipped': bool}
    """
    from qgis.core import QgsDistanceArea

    result = {'pass': True, 'count': 0, 'examples': []}
    pop_layer = _layer('POP v1')
    ont_layer = _layer('ONT v1')
    if not pop_layer.isValid() or not ont_layer.isValid() or pop_layer.featureCount() == 0:
        result['skipped'] = True
        return result

    pop_feat = next(pop_layer.getFeatures(), None)
    if pop_feat is None:
        result['skipped'] = True
        return result
    pop_geom = pop_feat.geometry()
    if not pop_geom or pop_geom.isEmpty():
        result['skipped'] = True
        return result
    pop_pt = pop_geom.centroid().asPoint()
    da = QgsDistanceArea()
    da.setEllipsoid('WGS84')

    worst = 0.0
    over = []
    for f in ont_layer.getFeatures():
        g = f.geometry()
        if not g or g.isEmpty():
            continue
        d = da.measureLine(pop_pt, g.asPoint())
        if d > worst:
            worst = d
        if d > max_km * 1000:
            label = f['label_1'] if f.fields().indexOf('label_1') >= 0 and f['label_1'] else f'ID {f.id()}'
            over.append((label, d))

    result['worst_km'] = round(worst / 1000, 2)
    if over:
        result['pass'] = False
        result['count'] = len(over)
        over.sort(key=lambda x: -x[1])
        result['examples'] = [f'{lbl}: {d/1000:.2f} km from POP' for lbl, d in over[:10]]
    return result


def check_span_violations_by_type(feedback=None, project_type='MOA'):
    """
    Check cable span violations using cable-type-specific thresholds.
    Spans are measured pole-to-pole (per ADSS hop), NOT whole-route.
    - Drop cables: 50m (MOA) or 75m (VUMA/HEROTEL)
    - Distribution cables: 70m
    - Secondary cables: 70m
    - Primary cables: 70m (per-span ADSS limit applies to every pole-to-pole hop)

    Returns: {'pass': bool, 'count': int, 'examples': [list of str], optional 'skipped': bool}
    """
    from qgis.core import QgsDistanceArea

    result = {'pass': True, 'count': 0, 'examples': []}

    drop_max = 75.0 if project_type.upper() in ('VUMA', 'HEROTEL') else 50.0
    dist_max = 70.0
    sec_max  = 70.0
    prim_max = 70.0

    cable_specs = [
        ('Drop Cable v1.shp',         'Drop Cable v1',         drop_max),
        ('Distribution Cable v1.shp', 'Distribution Cable v1', dist_max),
        ('Secondary Cable v1.shp',    'Secondary Cable v1',    sec_max),
        ('Primary Cable v1.shp',      'Primary Cable v1',      prim_max),
    ]

    poles_layer = _layer('Poles v1')
    if not poles_layer.isValid():
        poles_layer = _layer('poles v1')  # case-insensitive fallback
    if not poles_layer.isValid():
        result['skipped'] = True
        return result

    _has_label = poles_layer.fields().indexOf('Label') >= 0
    pole_idx = {}
    for feat in poles_layer.getFeatures():
        geom = feat.geometry()
        if geom and not geom.isEmpty():
            pt = geom.asPoint()
            pole_idx[feat.id()] = (pt, feat['Label'] if _has_label else '')

    da = QgsDistanceArea()
    da.setEllipsoid('WGS84')

    SNAP15 = 15.0 / 111320.0  # ~15 m pole-snap tolerance in degrees (EPSG:4326)

    violations = []
    for fname, layer_name, max_span in cable_specs:
        cable_layer = _layer(layer_name)
        if not cable_layer.isValid():
            continue
        _has_lbl = cable_layer.fields().indexOf('label') >= 0
        for feat in cable_layer.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue
            poly = _safe_polyline(geom)
            if len(poly) < 2:
                continue
            start_pt = poly[0]
            end_pt   = poly[-1]
            start_pole = end_pole = None
            start_label = end_label = None
            min_s = min_e = float('inf')
            for pole_fid, (pole_pt, pole_label) in pole_idx.items():
                ds = start_pt.distance(pole_pt)
                de = end_pt.distance(pole_pt)
                if ds < min_s and ds <= SNAP15:
                    min_s = ds; start_pole = pole_pt; start_label = pole_label
                if de < min_e and de <= SNAP15:
                    min_e = de; end_pole = pole_pt; end_label = pole_label
            if start_pole and end_pole:
                span_m = da.measureLine(start_pole, end_pole)
                if span_m > max_span:
                    label = feat['label'] if (_has_lbl and feat['label']) else f"ID {feat.id()}"
                    violations.append((layer_name, label, round(span_m, 1), start_label, end_label, max_span))

    if violations:
        result['pass'] = False
        result['count'] = len(violations)
        result['examples'] = [
            f"{v[0]}: {v[1]} ({v[2]:.1f}m > {v[5]}m) {v[3]}→{v[4]}"
            for v in violations[:10]
        ]
    return result


# (name, file, geotype, check_pon, check_latlon, label_field, required_struct)
# required_struct: dict of field→expected value that must NOT be NULL
LAYERS = [
    ('Poles v1',              'poles v1.shp',              'point', True,  True,  'Label',   {}),
    ('Enclosure v1',          'Enclosure v1.shp',           'point', True,  True,  'label_1', {'cmpownr':'VelocityFibre'}),
    # FTS is the 1:16 stage, STS is the 1:8 stage. These were transposed, failing 66/66
    # FTS and 945/945 STS — 100% of two healthy layers. The labels settle it
    # (MOA.FTS.16.…, MOA.STS.8.…). Corrected 2026-08-12.
    ('FTS Splitters v1',      'FTS Splitters v1.shp',       'point', True,  True,  'label',   {'type':'Splitter','subtyp':'Splitter (Bare Fiber)','cblcpty':'1:16F'}),
    ('STS Splitters v1',      'STS Splitters v1.shp',       'point', True,  True,  'label',   {'type':'Splitter','subtyp':'Splitter (Connectorised)','cblcpty':'1:8F'}),
    ('ONT v1',                'ONT v1.shp',                 'point', True,  False, 'label_1', {}),
    ('Primary Cable v1',      'Primary Cable v1.shp',       'line',  True,  False, 'label',   {'type':'Cable'}),
    ('Secondary Cable v1',    'Secondary Cable v1.shp',     'line',  True,  False, 'label',   {'type':'Cable','subtyp':'Mini-ADSS','cblcpty':'48F'}),
    ('Distribution Cable v1', 'Distribution Cable v1.shp',  'line',  True,  False, 'label',   {'type':'Cable','subtyp':'Mini-ADSS','cblcpty':'24F'}),
    ('Drop Cable v1',         'Drop Cable v1.shp',          'line',  True,  False, 'label',   {'type':'Cable','subtyp':'Drop','cblcpty':'1F'}),
    ('PON v1',                'PON v1.shp',                 'poly',  False, False, 'label',   {'type':'PON','subtyp':'GPON'}),
    ('Zones v1',              'Zones v1.shp',               'poly',  False, False, 'label',   {'type':'Zone','subtyp':'Area','spec':'16 PONs'}),
]

TOTAL = 0

for (name, fname, geotype, check_pon, check_latlon, lbl_field, required_struct) in LAYERS:
    lyr = _layer(name)
    if not lyr.isValid():
        print(f'\n❌ {name}: INVALID (not in project; disk fallback missing)')
        continue

    fields = [f.name() for f in lyr.fields()]
    null_label = null_pon = null_zone = bad_date_c = null_lat = null_lon = 0
    bad_strt = bad_end = wrong_static = pon_range_bad = zone_wrong = wrong_struct = 0
    null_geom = 0

    for feat in lyr.getFeatures():
        if not feat.geometry() or feat.geometry().isEmpty():
            null_geom += 1
        if lbl_field in fields and bad_val(feat[lbl_field]):
            null_label += 1

        for field, expected in required_struct.items():
            if field in fields and str(feat[field]).strip() != expected:
                wrong_struct += 1

        if check_pon and 'pon_no' in fields:
            pv = str(feat['pon_no']).strip()
            if bad_val(feat['pon_no']):
                null_pon += 1
            elif pv.isdigit():
                p = int(pv)
                if not (PON_MIN <= p <= PON_MAX):
                    pon_range_bad += 1
                else:
                    exp_z = (p - 235) // 16 + 17
                    if 'zone_no' in fields and str(feat['zone_no']).strip() != str(exp_z):
                        zone_wrong += 1

        if check_pon and 'zone_no' in fields:
            zv = str(feat['zone_no']).strip()
            if bad_val(feat['zone_no']):
                null_zone += 1

        if 'datecrtd' in fields and bad_date(feat['datecrtd']):
            bad_date_c += 1

        if check_latlon:
            if 'lat' in fields and bad_val(feat['lat']): null_lat += 1
            if 'lon' in fields and bad_val(feat['lon']): null_lon += 1

        if geotype in ('line',):
            if 'strtfeat' in fields and bad_val(feat['strtfeat']): bad_strt += 1
            if 'endfeat'  in fields and bad_val(feat['endfeat']):  bad_end  += 1

        for field, expected in EXPECTED_STATIC.items():
            if field in fields and str(feat[field]).strip() != expected:
                wrong_static += 1
        for field in ('subplace', 'mainplce'):
            if field in fields and str(feat[field]).strip() != '676007':
                wrong_static += 1

    layer_issues = (null_label + null_pon + pon_range_bad + null_zone + zone_wrong +
                    bad_date_c + null_lat + null_lon + bad_strt + bad_end + wrong_static + wrong_struct + null_geom)
    TOTAL += layer_issues

    n = lyr.featureCount()
    print(f'\n── {name} ({n}) ──')
    if null_geom:     print(f'  ⚠️  null geometry:       {null_geom}')
    if null_label:    print(f'  ⚠️  null label:          {null_label}')
    if wrong_struct:  print(f'  ⚠️  struct field wrong:  {wrong_struct}')
    if null_pon:      print(f'  ⚠️  null pon_no:         {null_pon}')
    if pon_range_bad: print(f'  ⚠️  pon out of 235-298:  {pon_range_bad}')
    if null_zone:     print(f'  ⚠️  null zone_no:         {null_zone}')
    if zone_wrong:    print(f'  ⚠️  zone/pon mismatch:    {zone_wrong}')
    if bad_date_c:    print(f'  ⚠️  bad datecrtd:         {bad_date_c}')
    if null_lat:      print(f'  ⚠️  null lat:             {null_lat}')
    if null_lon:      print(f'  ⚠️  null lon:             {null_lon}')
    if bad_strt:      print(f'  ⚠️  null strtfeat:        {bad_strt}')
    if bad_end:       print(f'  ⚠️  null endfeat:         {bad_end}')
    if wrong_static:  print(f'  ⚠️  static field issues:  {wrong_static}')
    if layer_issues == 0:
        print('  ✅ All checks passed')

print(f'\n══ TOTAL ISSUES (CORE): {TOTAL} ══')

# ── Extended QA Checks ────────────────────────────────────────────────────────
print('\n\n╔════════════════════════════════════════╗')
print('║  EXTENDED QA CHECKS                   ║')
print('╚════════════════════════════════════════╝')

# Check: Island splitters (FTS/STS not connected to cable network)
islands_result = check_island_splitters()
if islands_result['count'] > 0:
    print(f'\n⚠️  Island Splitters: {islands_result["count"]} disconnected')
    for ex in islands_result['examples']:
        print(f'  {ex}')
    TOTAL += islands_result['count']
else:
    print('\n✅ Island Splitters: None found')

# Check: Enclosure spec_1 completeness
spec1_result = check_enclosure_spec1()
if spec1_result['count'] > 0:
    print(f'\n⚠️  Enclosure spec_1 Missing: {spec1_result["count"]} incomplete')
    for ex in spec1_result['examples']:
        print(f'  {ex}')
    TOTAL += spec1_result['count']
else:
    print('\n✅ Enclosure spec_1: All populated')

# Check: Span violations by cable type
spans_result = check_span_violations_by_type(project_type='MOA')
if spans_result.get('skipped'):
    print('\n⊘ Span Violations: Poles layer not found (skipped)')
elif spans_result['count'] > 0:
    print(f'\n⚠️  Span Violations: {spans_result["count"]} found')
    for ex in spans_result['examples']:
        print(f'  {ex}')
    TOTAL += spans_result['count']
else:
    print('\n✅ Span Violations: None (within thresholds)')

# Check: Drop count per STS dome (merged from fibretime_tools HLD audit)
sts_result = check_drops_per_sts()
if sts_result.get('skipped'):
    print('\n⊘ Drops per STS: STS/Drop layer not found (skipped)')
elif sts_result['count'] > 0:
    lvl = '⚠️ ' if sts_result['pass'] else '❌'
    print(f'\n{lvl} Drops per STS: {sts_result["count"]} dome(s) over 8 drops')
    for ex in sts_result['examples']:
        print(f'  {ex}')
    TOTAL += sts_result['count']
else:
    print('\n✅ Drops per STS: all domes ≤ 8 drops')

# Check: POP-to-ONT distance ≤ 8 km (merged from fibretime_tools HLD audit)
pop_result = check_pop_ont_distance()
if pop_result.get('skipped'):
    print('\n⊘ POP→ONT distance: POP/ONT layer not found (skipped)')
elif pop_result['count'] > 0:
    print(f'\n❌ POP→ONT distance: {pop_result["count"]} ONT(s) beyond 8 km')
    for ex in pop_result['examples']:
        print(f'  {ex}')
    TOTAL += pop_result['count']
else:
    print(f'\n✅ POP→ONT distance: all within 8 km (furthest {pop_result.get("worst_km", "?")} km)')

print(f'\n══ TOTAL ISSUES (ALL CHECKS): {TOTAL} ══')
