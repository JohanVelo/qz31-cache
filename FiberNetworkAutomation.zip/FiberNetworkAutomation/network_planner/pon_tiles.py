try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

"""Straight-edged PON boundary tiles — the one implementation.

This is JJ's HTML-approved option ③ from 2026-06-25: instead of buffering a
circle around every home and unioning the result (which produces the rounded
"bubble" boundaries), tile the settlement with a Voronoi diagram over the demand
points, label each cell by its point's PON, dissolve per PON, clip to a concave
hull of the settlement and simplify the shared coverage edges together.

Measured on Luke's Phalaborwa Benfarm layer, 71 PONs / 6,034 homes:

    boundary style          vertices per PON (median)   overlapping pairs
    buffer union ("blob")            381                       51
    blob, then polished               97                       23
    THESE TILES                       12                        0

Why it lives here and not in ``dock_widget``
--------------------------------------------
It was written as a method on the dock, but it never touched ``self`` — so the
Merge tool could not reach it without importing 16,000 lines of Qt. Lifting it
out verbatim lets both callers share ONE implementation. ``dock_widget`` now
delegates here, so the Generate path and the Merge path can never drift apart.

Deliberately dependency-guarded: numpy, scipy and shapely are imported inside the
function and ANY failure returns ``{}``, so a caller transparently falls back to
whatever boundaries it already had rather than blowing up or, worse, writing
empty geometries. Verified present in QGIS 4.0.3: numpy 2.4.6, scipy 1.17.1,
shapely 2.1.2.

Note for anyone reading the guardrails: the hard "never use Voronoi" rule is
about **Erven** boundaries, which follow the CSG-first cadastral model. PON zone
boundaries are a different layer with a different rule, and have used this
tiling since it was approved.
"""

#: Douglas-Peucker tolerance (metres) for the shared-coverage simplify pass.
#:
#: ⚠ MEASURED 2026-09-04, Ventersdorp, 7,554 homes / 82 PONs: this tolerance
#: trades correctness for looks, and how much was never measured before.
#:
#:      tolerance   homes left in the WRONG PON   vertices per PON
#:            0 m                             0                 94
#:           10 m                             0                 27
#:           20 m                            14                 15
#:           40 m                            67                 10   <- this default
#:
#: 40 m sweeps a shared boundary clean across a home, so the home ends up inside
#: a neighbouring PON's polygon while still being counted in its own. Callers who
#: care about that (HT 2 does) pass ``simplify_m=10``. The default is left at 40
#: so existing Network Planner output does not shift underneath anyone.
COVERAGE_SIMPLIFY_M = 40.0

#: A Voronoi diagram needs a real point cloud; below this it is meaningless.
MIN_POINTS = 8


def voronoi_zone_polygons(grouped_layer, features_by_zone, simplify_m=None):
    """Straight-edged, gap-free, non-overlapping tile per PON.

    ``features_by_zone`` is ``{pon_key: [feature, ...]}`` of DEMAND POINTS.
    Returns ``{pon_key: QgsGeometry}`` in ``grouped_layer``'s CRS, or ``{}`` if
    the tiling cannot be done — membership comes straight from the caller, so no
    home ever changes PON as a side effect of retiling.

    ``simplify_m`` overrides :data:`COVERAGE_SIMPLIFY_M` for this call. Pass a
    smaller value when a home must never fall inside a neighbour's polygon; see
    the measured table on that constant.
    """
    import math

    from qgis.core import QgsGeometry
    try:
        import numpy as np
        import shapely
        from scipy.spatial import Voronoi
        from shapely.geometry import MultiPoint, MultiPolygon, Polygon
        from shapely.ops import transform as shp_tf
        from shapely.ops import unary_union
    except Exception:
        return {}

    rows = []
    for zname, feats in features_by_zone.items():
        for f in feats:
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            p = g.asPoint()
            rows.append((p.x(), p.y(), zname))
    if len(rows) < MIN_POINTS:
        return {}

    lon0 = sum(r[0] for r in rows) / len(rows)
    lat0 = sum(r[1] for r in rows) / len(rows)
    if grouped_layer.crs().isGeographic():
        # Local metric frame. Buffering in degrees is the trap that has bitten
        # this codebase repeatedly — everything below is in metres.
        kx = 111320.0 * math.cos(math.radians(lat0))
        ky = 110540.0
    else:
        kx = ky = 1.0

    def inv(x, y, z=None):                       # metric → layer CRS
        return (lon0 + x / kx, lat0 + y / ky)

    P = np.array([((r[0] - lon0) * kx, (r[1] - lat0) * ky) for r in rows])
    labels = [r[2] for r in rows]
    if len({tuple(v) for v in np.round(P, 3)}) < 4:
        return {}

    mp = MultiPoint([tuple(xy) for xy in P])
    try:
        hull = shapely.concave_hull(mp, ratio=0.35)
        if hull.is_empty or hull.geom_type not in ("Polygon", "MultiPolygon"):
            raise ValueError
    except Exception:
        hull = mp.convex_hull
    span = float(max(P.max(0) - P.min(0)))
    hbuf = max(span * 0.01, 20.0)
    hull = hull.buffer(hbuf).buffer(-hbuf * 0.3)

    def finite_polys(vor, radius):
        """Voronoi regions with the infinite ones closed off at ``radius``."""
        regions, vertices = [], vor.vertices.tolist()
        center = vor.points.mean(axis=0)
        ridges = {}
        for (p1, p2), (v1, v2) in zip(vor.ridge_points, vor.ridge_vertices):
            ridges.setdefault(p1, []).append((p2, v1, v2))
            ridges.setdefault(p2, []).append((p1, v1, v2))
        for p1, region in enumerate(vor.point_region):
            verts = vor.regions[region]
            if all(v >= 0 for v in verts):
                regions.append(verts)
                continue
            nr = [v for v in verts if v >= 0]
            for p2, v1, v2 in ridges.get(p1, []):
                if v2 < 0:
                    v1, v2 = v2, v1
                if v1 >= 0:
                    continue
                t = vor.points[p2] - vor.points[p1]
                nn = np.linalg.norm(t)
                if nn == 0:
                    continue
                t = t / nn
                nrm = np.array([-t[1], t[0]])
                mid = vor.points[[p1, p2]].mean(axis=0)
                direction = np.sign(np.dot(mid - center, nrm)) * nrm
                nr.append(len(vertices))
                vertices.append((vor.vertices[v2] + direction * radius).tolist())
            vs = np.asarray([vertices[v] for v in nr])
            c = vs.mean(axis=0)
            ang = np.arctan2(vs[:, 1] - c[1], vs[:, 0] - c[0])
            regions.append(np.array(nr)[np.argsort(ang)].tolist())
        return regions, np.asarray(vertices)

    try:
        vor = Voronoi(P)
    except Exception:
        return {}
    radius = span * 2 if span > 0 else 1000.0
    regions, verts = finite_polys(vor, radius)

    tiles = {}
    for zname in features_by_zone:
        cells = []
        for i, lab in enumerate(labels):
            if lab != zname:
                continue
            try:
                poly = Polygon(verts[regions[i]])
                if poly.is_valid and not poly.is_empty:
                    cells.append(poly)
            except Exception:
                _swallowed_note(); continue
        if not cells:
            continue
        try:
            merged = unary_union(cells).intersection(hull)
        except Exception:
            _swallowed_note(); continue
        if (not merged.is_empty) and isinstance(merged, (Polygon, MultiPolygon)):
            tiles[zname] = merged
    if not tiles:
        return {}

    # Simplify the SHARED coverage edges together (topology-aware) so adjacent
    # tiles stay both gap-free AND overlap-free. Simplifying each polygon on its
    # own slips the shared edge and leaves slivers — 66 overlapping pairs in
    # testing. Falls back to the raw (already zero-overlap) tiles if the shapely
    # build has no coverage_simplify.
    znames = list(tiles.keys())
    geoms = [tiles[z] for z in znames]
    try:
        tol = COVERAGE_SIMPLIFY_M if simplify_m is None else float(simplify_m)
        geoms = list(shapely.coverage_simplify(geoms, tol,
                                               simplify_boundary=True))
    except Exception:
        geoms = [tiles[z] for z in znames]

    out = {}
    for zname, g in zip(znames, geoms):
        try:
            if g is None or g.is_empty:
                continue
            qg = QgsGeometry.fromWkt(shp_tf(inv, g).wkt)
            if qg and not qg.isEmpty():
                out[zname] = qg
        except Exception:
            _swallowed_note(); continue
    return out
