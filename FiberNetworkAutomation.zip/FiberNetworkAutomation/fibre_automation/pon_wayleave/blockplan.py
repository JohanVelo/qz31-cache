"""Assign whole street blocks to PONs, so an island cannot be drawn.

This replaces a repair with a guarantee.

The earlier design split a shared block by a Voronoi of its homes, so a PON
owned *slices*. Slices need not connect even when every block touches: measured
on Ventersdorp, block membership said all 82 PONs were connected while 8 owned
their area in two or three disjoint pieces, one pair 49 m apart. Repairing that
afterwards oscillates -- absorbing a stray into a neighbour splits the
neighbour -- and the outcome swung between 0 and 2 islands on nothing more than
how many optimiser seeds were used. That is luck, not a guarantee.

Here a **block is an atom**. A PON is a set of blocks that are connected in the
block-adjacency graph, so its polygon is a union of whole, touching blocks:

    connected block set  ->  single polygon.  Always.

Empty blocks are assigned too. They are the open ground *inside* a township --
a school field, a park -- and leaving them out punches holes and can separate
the blocks around them. The Malmesbury reference does the same thing: only
74.4% of its PON area is erven, so a quarter of it is open ground enclosed by
the boundary.

The move is ReCom, as in :mod:`balance`: merge two adjacent PONs, spanning-tree
the union, cut one edge. Both halves stay connected by construction.
"""

from __future__ import annotations

import random
from collections import defaultdict, deque

import networkx as nx

from .balance import BAND_HI, BAND_LO, HARD_MAX, SEEDS, _cost, band_stats

__all__ = ["balance_blocks", "block_graph", "pon_of_stands", "seed_from_stands"]


#: Two blocks must share at least this much FRONTAGE to count as neighbours.
#: Corner-touching blocks -- diagonal across a crossroads -- share a single
#: point, so their union pinches to nothing and ANY gap cut severs it. Treating
#: a corner as a connection is what left 3 islands even though every PON's
#: block set was "connected".
MIN_SHARED_EDGE_M = 1.0


def block_graph(blocks, min_shared_m=MIN_SHARED_EDGE_M):
    """Blocks as a graph, edges where polygons share real FRONTAGE.

    Measured on the geometry, not on a buffered overlap: a buffer links blocks
    that merely lie near each other, and a graph claiming a connection the
    polygons do not have is exactly how an island survives a connectivity check.
    """
    g = nx.Graph()
    g.add_nodes_from(range(len(blocks)))
    try:
        from shapely import STRtree
        tree = STRtree(blocks)
    except Exception:                                       # pragma: no cover
        tree = None

    def near(i):
        if tree is None:
            return range(len(blocks))
        return [int(k) for k in tree.query(blocks[i].buffer(1.0))]

    for i in range(len(blocks)):
        bi = blocks[i].boundary
        for k in near(i):
            if k <= i:
                continue
            if blocks[i].distance(blocks[k]) > 0.01:
                continue
            shared = bi.intersection(blocks[k].boundary)
            if not shared.is_empty and shared.length >= min_shared_m:
                g.add_edge(i, k)
    return g


def seed_from_stands(block_of_stand, pon_of_stand):
    """Starting block->PON map: each block takes the PON most of its homes are in.

    Ties break on the lowest PON number so a rebuild reproduces the same plan.
    Blocks holding no home are left unassigned here and filled in afterwards.
    """
    votes = defaultdict(lambda: defaultdict(int))
    for i, b in enumerate(block_of_stand):
        p = pon_of_stand[i]
        if b is None or p is None:
            continue
        votes[int(b)][p] += 1
    out = {}
    for b in sorted(votes):
        v = votes[b]
        out[b] = min(sorted(v), key=lambda p: (-v[p], p))
    return out


def _fill_empty(g, assign):
    """Give every remaining block to an adjacent PON, nearest-first by hops.

    Empty blocks are the open ground between the built ones. Assigning them
    keeps a PON's block set contiguous; leaving them out is what lets a park
    separate two halves of the same PON.
    """
    assign = dict(assign)
    frontier = deque(sorted(assign))
    while frontier:
        b = frontier.popleft()
        for nb in sorted(g[b]):
            if nb in assign:
                continue
            assign[nb] = assign[b]
            frontier.append(nb)
    # anything still unassigned sits in its own disconnected component
    for b in sorted(g.nodes):
        if b not in assign:
            comp = nx.node_connected_component(g, b)
            near = [assign[x] for x in sorted(comp) if x in assign]
            assign[b] = near[0] if near else (max(assign.values(), default=0) + 1)
    return assign


def _loads(assign, homes):
    out = defaultdict(int)
    for b, p in assign.items():
        out[p] += homes.get(b, 0)
    return dict(out)


def _subtree(tree, root):
    parent = {root: None}
    order = []
    seen = {root}
    dq = deque([root])
    while dq:
        n = dq.popleft()
        order.append(n)
        for m in sorted(tree[n]):
            if m not in seen:
                seen.add(m)
                parent[m] = n
                dq.append(m)
    return order, parent


def _cut(g, nodes, homes, rng, lo, hi, cap, tries=12):
    sub = g.subgraph(nodes)
    if not nx.is_connected(sub):
        return None
    total = sum(homes.get(n, 0) for n in nodes)
    if total < 2 * lo or total > 2 * cap:
        return None
    for _ in range(tries):
        for u, v in sorted(sub.edges()):
            sub.edges[u, v]["r"] = rng.random()
        tree = nx.minimum_spanning_tree(sub, weight="r")
        root = min(tree.nodes)
        order, parent = _subtree(tree, root)
        sw = {n: homes.get(n, 0) for n in order}
        for n in reversed(order):
            if parent[n] is not None:
                sw[parent[n]] += sw[n]
        cands = [n for n in sorted(tree.nodes)
                 if parent[n] is not None
                 and lo <= sw[n] <= cap and lo <= total - sw[n] <= cap]
        if not cands:
            continue
        cands.sort(key=lambda n: (_cost(sw[n], lo, hi) + _cost(total - sw[n], lo, hi), n))
        n = cands[0]
        side = set()
        dq = deque([n])
        seen = {n}
        while dq:
            x = dq.popleft()
            side.add(x)
            for y in sorted(tree[x]):
                if y not in seen and parent[y] == x:
                    seen.add(y)
                    dq.append(y)
        other = set(nodes) - side
        if side and other:
            return side, other, sw[n], total - sw[n]
    return None


def _carve(g, nodes, homes, rng, lo, cap, tries=14):
    """Cut a piece of [lo, cap] homes off a set, leaving BOTH sides connected.

    ``_cut`` needs both halves legal, so it cannot touch a 316-home PON: no
    single split of 316 puts both sides under the cap. This carves one legal
    piece off and leaves the remainder to be carved again.
    """
    sub = g.subgraph(nodes)
    if not nx.is_connected(sub):
        return None
    for _ in range(tries):
        for u, v in sorted(sub.edges()):
            sub.edges[u, v]["r"] = rng.random()
        tree = nx.minimum_spanning_tree(sub, weight="r")
        root = min(tree.nodes)
        order, parent = _subtree(tree, root)
        sw = {n: homes.get(n, 0) for n in order}
        for n in reversed(order):
            if parent[n] is not None:
                sw[parent[n]] += sw[n]
        cands = [n for n in sorted(tree.nodes)
                 if parent[n] is not None and lo <= sw[n] <= cap]
        if not cands:
            continue
        # prefer a piece near the middle of the band
        mid = (lo + cap) / 2.0
        cands.sort(key=lambda n: (abs(sw[n] - mid), n))
        n = cands[0]
        side = set()
        dq = deque([n])
        seen = {n}
        while dq:
            x = dq.popleft()
            side.add(x)
            for y in sorted(tree[x]):
                if y not in seen and parent[y] == x:
                    seen.add(y)
                    dq.append(y)
        other = set(nodes) - side
        if side and other and nx.is_connected(g.subgraph(other)):
            return side, other
    return None


def _enforce_cap(g, homes, assign, lo, cap, seed=0, rounds=200):
    """No PON may exceed the cap. Carve pieces off until none does."""
    rng = random.Random(seed)
    assign = dict(assign)
    for _ in range(rounds):
        by = defaultdict(set)
        for b, p in sorted(assign.items()):
            by[p].add(b)
        loads = _loads(assign, homes)
        over = sorted(p for p in by if loads[p] > cap)
        if not over:
            break
        p = over[0]
        out = _carve(g, by[p], homes, rng, lo, cap)
        if out is None:
            break                       # cannot be carved legally -- report it
        side, _rest = out
        new_id = max(assign.values()) + 1
        for b in sorted(side):
            assign[b] = new_id
    return assign


def _one_pass(g, homes, assign, lo, hi, cap, seed, iters, patience=1200):
    rng = random.Random(seed)
    assign = dict(assign)
    by = defaultdict(set)
    for b, p in sorted(assign.items()):
        by[p].add(b)
    loads = _loads(assign, homes)
    idle = 0
    for _ in range(iters):
        if idle >= patience:
            break
        idle += 1
        off = sorted(p for p in by if _cost(loads[p], lo, hi) > 0)
        if not off:
            break
        p = min(off, key=lambda q: loads[q]) if rng.random() < 0.6 else rng.choice(off)
        nb = set()
        for b in sorted(by[p]):
            for m in sorted(g[b]):
                q = assign.get(m)
                if q is not None and q != p:
                    nb.add(q)
        if not nb:
            continue
        q = rng.choice(sorted(nb))
        roll = rng.random()

        if roll < 0.35 and loads[p] + loads[q] <= cap:
            if (_cost(loads[p] + loads[q], lo, hi)
                    < _cost(loads[p], lo, hi) + _cost(loads[q], lo, hi)
                    and nx.is_connected(g.subgraph(by[p] | by[q]))):
                for b in sorted(by[q]):
                    assign[b] = p
                by[p] |= by[q]
                loads[p] += loads[q]
                del by[q], loads[q]
                idle = 0
                continue

        if roll < 0.70:
            out = _cut(g, by[p] | by[q], homes, rng, lo, hi, cap)
            if out is None:
                continue
            side, other, a, b_ = out
            if (_cost(a, lo, hi) + _cost(b_, lo, hi)
                    >= _cost(loads[p], lo, hi) + _cost(loads[q], lo, hi)):
                continue
            for x in sorted(side):
                assign[x] = p
            for x in sorted(other):
                assign[x] = q
            by[p], by[q] = side, other
            loads[p], loads[q] = a, b_
            idle = 0
            continue

        edge = sorted(b for b in by[q] if any(m in by[p] for m in g[b]))
        if not edge:
            continue
        b = rng.choice(edge)
        w = homes.get(b, 0)
        if loads[p] + w > cap or len(by[q]) <= 1:
            continue
        if (_cost(loads[p] + w, lo, hi) + _cost(loads[q] - w, lo, hi)
                >= _cost(loads[p], lo, hi) + _cost(loads[q], lo, hi)):
            continue
        if not nx.is_connected(g.subgraph(by[q] - {b})):
            continue
        if not nx.is_connected(g.subgraph(by[p] | {b})):
            continue
        by[q].discard(b)
        by[p].add(b)
        assign[b] = p
        loads[q] -= w
        loads[p] += w
        idle = 0
    return assign, loads


def balance_blocks(blocks, block_of_stand, pon_of_stand, homes_per_block=None,
                   lo=BAND_LO, hi=BAND_HI, cap=HARD_MAX, seeds=SEEDS,
                   iters=40000, graph=None, progress=None):
    """Whole-block PON plan. Returns ``(block_to_pon, loads, stats, graph)``.

    Every PON comes out as a CONNECTED set of whole blocks, so the polygon is a
    single piece by construction -- there is no island to repair afterwards.
    """
    progress = progress or (lambda *_a, **_k: None)
    g = graph if graph is not None else block_graph(blocks)
    if homes_per_block is None:
        homes_per_block = defaultdict(int)
        for b in block_of_stand:
            if b is not None:
                homes_per_block[int(b)] += 1
        homes_per_block = dict(homes_per_block)

    seed_assign = seed_from_stands(block_of_stand, pon_of_stand)
    assign = _fill_empty(g, seed_assign)

    # a seeded PON can start disconnected; hand each stray component to a
    # neighbour before optimising, or ReCom's connectivity checks reject
    # every move around it
    for _ in range(20):
        by = defaultdict(set)
        for b, p in sorted(assign.items()):
            by[p].add(b)
        fixed = False
        for p in sorted(by):
            comps = sorted(nx.connected_components(g.subgraph(by[p])),
                           key=lambda c: (-sum(homes_per_block.get(x, 0) for x in c),
                                          min(c)))
            for stray in comps[1:]:
                votes = defaultdict(int)
                for b in sorted(stray):
                    for m in sorted(g[b]):
                        q = assign.get(m)
                        if q is not None and q != p:
                            votes[q] += 1
                if not votes:
                    continue
                tgt = min(sorted(votes), key=lambda q: (-votes[q], q))
                for b in sorted(stray):
                    assign[b] = tgt
                fixed = True
        if not fixed:
            break

    if not seeds:
        loads = _loads(assign, homes_per_block)
        return assign, loads, band_stats(loads, lo, hi, cap), g
    assign = _enforce_cap(g, homes_per_block, assign, lo, cap)

    best = None
    for i, seed in enumerate(seeds):
        a, loads = _one_pass(g, homes_per_block, assign, lo, hi, cap, seed, iters)
        a = _enforce_cap(g, homes_per_block, a, lo, cap, seed=seed)
        loads = _loads(a, homes_per_block)
        s = band_stats(loads, lo, hi, cap)
        progress(100.0 * (i + 1) / len(seeds),
                 f"blocks seed {seed}: {s['under']} under target, "
                 f"{s['in_band']}/{s['pons']} in band")
        key = (s["under"], s["cost"], seed)
        if best is None or key < best[0]:
            best = (key, a, loads, s)
    _, assign, loads, stats = best
    return assign, loads, stats, g


def pon_of_stands(block_of_stand, block_to_pon):
    """Membership follows the block: a home belongs to the PON owning its block."""
    return [None if b is None else block_to_pon.get(int(b)) for b in block_of_stand]
