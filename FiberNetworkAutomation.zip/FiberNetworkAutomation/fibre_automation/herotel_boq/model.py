"""Versioned interface for independently developed schema standardisers."""
from dataclasses import dataclass
import hashlib
import json
from types import MappingProxyType

MAX_FEATURES = 100_000
MAX_BYTES = 128 * 1024 * 1024
MAX_LAYERS = 200
MAX_PHASES = 64
INPUT_ROWS = (15, *range(17, 23), *range(27, 32), 33, 34, 41, 42, 43,
              64, 65, 66, 67, 75, 77, 79, 81, 83, 85)
DEFERRED_ROWS = tuple(range(4, 15))


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    allow_nan=False, separators=(',', ':')).encode()).hexdigest()


@dataclass(frozen=True)
class Record:
    fid: str
    values: object

    def __post_init__(self):
        import math
        values = dict(self.values)
        values = {key: None if isinstance(value, float) and math.isnan(value) else value
                  for key, value in values.items()}
        if any(not isinstance(v, (str, int, float, bool, type(None))) for v in values.values()):
            raise ValueError('Snapshot attributes must be scalar values')
        fingerprint(values)  # Reject NaN/infinity before export.
        object.__setattr__(self, 'values', MappingProxyType(values))


@dataclass(frozen=True)
class Layer:
    identity: str
    source: str
    name: str
    fields: tuple
    records: tuple
    source_hash: str

    def __post_init__(self):
        # A credential-bearing descriptor must never reach a receipt or workbook.
        import re
        if not self.identity or len(set(self.fields)) != len(self.fields):
            raise ValueError('Source identity and unique field names required')
        if re.search(r'://|password\s*=|token\s*=|user\s*=|authcfg\s*=', self.source, re.I):
            raise ValueError('Only local, credential-free source descriptors are supported')
        object.__setattr__(self, 'fields', tuple(self.fields))
        object.__setattr__(self, 'records', tuple(self.records))

    def payload(self):
        return dict(identity=self.identity, source=self.source, name=self.name,
                    fields=list(self.fields), source_hash=self.source_hash,
                    records=[dict(fid=r.fid, values=dict(r.values)) for r in self.records])


@dataclass(frozen=True)
class Snapshot:
    project: str
    layers: tuple
    schema_name: str = 'reviewed-explicit-mapping'
    schema_version: str = '1'
    contract_version: int = 1

    def __post_init__(self):
        object.__setattr__(self, 'layers', tuple(self.layers))

    def validate(self):
        if self.contract_version != 1:
            raise ValueError('Unsupported BOQ snapshot contract version')
        if not self.schema_name or not self.schema_version:
            raise ValueError('Schema identity/version required')
        if len(self.layers) > MAX_LAYERS:
            raise ValueError('More than 200 layers')
        if len({layer.identity for layer in self.layers}) != len(self.layers):
            raise ValueError('Duplicate physical source layer binding')
        if sum(len(layer.records) for layer in self.layers) > MAX_FEATURES:
            raise ValueError('More than 100000 features')
        for layer in self.layers:
            if len({r.fid for r in layer.records}) != len(layer.records):
                raise ValueError('Duplicate feature identity')
        if len(json.dumps(self.payload(), ensure_ascii=False, allow_nan=False).encode()) > MAX_BYTES:
            raise ValueError('Snapshot exceeds 128 MiB')

    def payload(self):
        return dict(project=self.project, schema_name=self.schema_name,
                    schema_version=self.schema_version, contract_version=self.contract_version,
                    layers=[layer.payload() for layer in self.layers])
