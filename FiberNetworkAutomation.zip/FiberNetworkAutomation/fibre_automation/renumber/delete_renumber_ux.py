"""Pass 6c — pure, unit-testable helper that turns a RenumberPlan's already-computed
PON remap into the preview's PON-NUMBERING block.

The delete/renumber ENGINE (plan.py / apply.py / scan.py / autofix.py) is NOT touched —
this only reads ``plan.doomed_pons`` and ``plan.remaps["PON"]`` (both read-only) and
formats them, so the preview finally says WHICH PON becomes which, not just how many
move. ``movers`` mirrors the engine's own ``plan.movers`` (old != new). No QGIS objects.
"""


def _as_int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def remap_facts(doomed, pon_remap):
    """doomed: PON numbers being deleted. pon_remap: {old: new} for the survivors
    (the PON identity system; None/empty when nothing renumbers). Returns the facts
    the block needs. Never raises."""
    deleted = sorted({_as_int(d) for d in (doomed or [])} - {None})
    pairs = []
    for old, new in (pon_remap or {}).items():
        oi, ni = _as_int(old), _as_int(new)
        if oi is not None and ni is not None and oi != ni:
            pairs.append((oi, ni))
    pairs.sort()
    return {
        "deleted": deleted,
        "movers": pairs,
        "moved_count": len(pairs),
        "kept_count": len(pon_remap or {}),
    }


def _short_pairs(pairs, cap=8):
    """'16→15, 17→16, …' truncated so a long remap doesn't fill the panel."""
    shown = ", ".join(f"{o}&rarr;{n}" for o, n in pairs[:cap])
    if len(pairs) > cap:
        shown += f", <span style='opacity:.6'>… +{len(pairs) - cap} more</span>"
    return shown


def _short_nums(nums, cap=14):
    shown = ", ".join(str(n) for n in nums[:cap])
    if len(nums) > cap:
        shown += f", … +{len(nums) - cap} more"
    return shown


def remap_html(facts, accent="#7fe0ec", bad="#ff8b82", dim="#6b8494"):
    """The PON-NUMBERING block, as rich text for a QLabel. Colours are passed in so the
    caller can match the dialog theme; they only affect appearance."""
    deleted = facts.get("deleted", [])
    movers = facts.get("movers", [])
    lines = [f"<span style='color:{dim};font-weight:bold'>// PON NUMBERING</span>"]
    if deleted:
        lines.append(f"<span style='color:{bad};font-weight:bold'>Deleted:</span> "
                     + ", ".join(f"PON {d}" for d in _deleted_display(deleted)))
    else:
        lines.append(f"<span style='color:{dim}'>Deleted: none</span>")
    if movers:
        lines.append(f"<span style='color:{accent};font-weight:bold'>Renumber:</span> "
                     + _short_pairs(movers))
    else:
        lines.append(f"<span style='color:{dim}'>Renumber: no numbers move — "
                     f"nothing to close</span>")
    lines.append(f"<span style='color:{dim}'>{facts.get('kept_count', 0)} PON(s) kept · "
                 f"{facts.get('moved_count', 0)} number(s) move</span>")
    return "<br>".join(lines)


def _deleted_display(deleted):
    """Deleted PONs, truncated for display but count-accurate."""
    if len(deleted) <= 14:
        return [str(d) for d in deleted]
    head = [str(d) for d in deleted[:14]]
    head.append(f"… +{len(deleted) - 14} more")
    return head
