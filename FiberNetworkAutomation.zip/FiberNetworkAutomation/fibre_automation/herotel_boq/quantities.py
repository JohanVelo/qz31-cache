"""Deterministic quantities; unresolved inputs cannot masquerade as zero."""
from collections import defaultdict
from dataclasses import dataclass
import math

from .mapping import number, splitter_count
from .model import DEFERRED_ROWS, INPUT_ROWS, MAX_PHASES, fingerprint


@dataclass(frozen=True)
class Result:
    phases: tuple
    cells: dict
    issues: tuple
    trace: dict
    snapshot_hash: str
    mapping_hash: str


def calculate(snapshot, bindings, phases=('All selected data',), *, aggregate=True):
    snapshot.validate()
    phases = tuple(phases)
    if not phases or len(phases) > MAX_PHASES or len(set(phases)) != len(phases):
        raise ValueError('Require 1–64 unique phases')
    if aggregate and len(phases) != 1:
        raise ValueError('Aggregate mode has exactly one scope')
    layers = {layer.identity: layer for layer in snapshot.layers}
    cells = {(p, row): None for p in phases for row in (*DEFERRED_ROWS, *INPUT_ROWS)}
    trace, issues = {}, []
    by_row = defaultdict(list)
    seen = set()
    for binding in bindings:
        if binding.layer not in layers:
            raise ValueError('Missing mapped layer')
        binding.validate(layers[binding.layer])
        key = fingerprint(binding.payload())
        if key in seen:
            raise ValueError('Duplicate quantity binding')
        seen.add(key)
        by_row[binding.row].append(binding)
    for row in INPUT_ROWS:
        if row not in by_row:
            issues.append(f'Row {row}: no verified source coverage')
            continue
        refs = {p: [] for p in phases}
        failed = False
        consumed = set()
        for binding in by_row[row]:
            layer = layers[binding.layer]
            binding_hash = fingerprint(binding.payload())
            matched = 0
            for record in layer.records:
                values = record.values
                try:
                    if any(field not in values or values[field] is None for field, _ in binding.filters):
                        raise ValueError('Missing classification value')
                    if any(str(values[field]) != str(expected) for field, expected in binding.filters):
                        continue
                    matched += 1
                    business_id = values.get(binding.identity_field) if binding.identity_field else None
                    if binding.identity_field and business_id in (None, ''):
                        raise ValueError('Missing physical asset identity')
                    key = ('asset', str(business_id)) if binding.identity_field else (layer.identity, record.fid)
                    if key in consumed:
                        raise ValueError('Overlapping bindings count a feature twice')
                    consumed.add(key)
                    phase = phases[0] if aggregate else str(values.get(binding.phase_field) if binding.phase_field else binding.phase_constant)
                    if phase not in phases:
                        raise ValueError('Missing or unregistered phase')
                    if values.get('__phase_issue__') and not aggregate:
                        raise ValueError(str(values['__phase_issue__']))
                    operation = binding.operation
                    if operation == 'count':
                        value = 1
                    elif operation.startswith('splitter'):
                        value = splitter_count(values.get(binding.field), int(operation[8:]))
                    elif operation == 'length':
                        route = number(values.get(binding.field), unit='m')
                        slack = number(values.get(binding.slack_field), unit='m') if binding.slack_field else None
                        total = number(values.get(binding.total_field), unit='m') if binding.total_field else None
                        if total is not None and slack is not None and abs(total - route - slack) > 0.01:
                            raise ValueError('Total differs from route + slack')
                        if total is not None and total < route:
                            raise ValueError('Installed total shorter than route')
                        value = total if total is not None else route + slack
                    else:
                        value = number(values.get(binding.field), unit='m' if row >= 75 else 'count')
                    refs[phase].append(dict(layer=layer.identity, fid=record.fid, value=value,
                                            operation=operation, field=binding.field,
                                            binding_hash=binding_hash))
                except ValueError as exc:
                    failed = True
                    issues.append(f'Row {row}, {layer.name}, feature {record.fid}: {exc}')
            if binding.filters and layer.records and not matched and not binding.allow_empty_filter:
                failed = True
                issues.append(f'Row {row}, {layer.name}: filter matched no features; confirm an actual zero or correct the filter')
        for phase in phases:
            total = math.fsum(ref['value'] for ref in refs[phase])
            if total > 2**53-1:
                issues.append(f'Row {row}, {phase}: total exceeds exact numeric capacity')
            cells[phase, row] = None if failed or total > 2**53-1 else total
            trace[phase, row] = refs[phase]
    return Result(phases, cells, tuple(issues), trace, fingerprint(snapshot.payload()),
                  fingerprint([b.payload() for b in bindings]))
