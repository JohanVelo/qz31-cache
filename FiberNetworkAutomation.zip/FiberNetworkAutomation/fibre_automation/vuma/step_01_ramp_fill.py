"""
Step 01 RAMP Gap Filler

Runs building_detect.onnx on low-density GOB grid cells (gap cells).
For each gap cell: fetch NGI aerial tile at zoom 18, run ONNX inference,
extract building centroids from probability mask, skip any within 8m of
an existing GOB point.

Inputs:
  ONNX_PATH  — building_detect.onnx (RAMP TF2.8 model, 256x256 input)
  GAP_PATH   — density_gap.geojson (from step_01_gob_density.py)
  GOB_PATH   — gob_filtered.geojson (from step_01_gob_density.py)

Outputs:
  ramp_new_centroids.geojson  — net-new RAMP detections (not in GOB)
  ramp_merged_all.geojson     — GOB + RAMP merged centroid set

Run in qgis-venv:
  python step_01_ramp_fill.py
"""



def main():
    # Heavy deps (onnxruntime, scipy, PIL) live in the qgis-venv only —
    # everything stays inside main() so importing this module never fails.
    import json
    import io
    import math
    import time
    import numpy as np
    import requests
    from PIL import Image
    import onnxruntime as ort
    from scipy import ndimage

    # ── Config ────────────────────────────────────────────────────────────────────
    ONNX_PATH  = "C:/Temp/building_detect.onnx"
    GAP_PATH   = "C:/Temp/density_gap.geojson"
    GOB_PATH   = "C:/Temp/gob_filtered.geojson"
    OUT_DIR    = "C:/Temp"

    # NGI aerial tiles — 25cm resolution, public XYZ, ~0.52m/px at zoom 18
    TILE_URL    = "https://aerial.openstreetmap.org.za/layer/ngi-aerial/{z}/{x}/{y}.jpg"
    ZOOM        = 18
    MODEL_PX    = 256
    MASK_THRESH = 0.45    # probability threshold for building pixel
    MIN_BLOB_PX = 12      # minimum blob size in pixels
    MERGE_M     = 8.0     # skip RAMP centroid if within 8m of existing GOB point
    # ─────────────────────────────────────────────────────────────────────────────

    # ── Tile helpers ──────────────────────────────────────────────────────────────
    def latlon_to_tile(lat, lon, zoom):
        n = 2 ** zoom
        x = int((lon + 180) / 360 * n)
        lat_r = math.radians(lat)
        y = int((1 - math.log(math.tan(lat_r) + 1/math.cos(lat_r)) / math.pi) / 2 * n)
        return x, y

    def tile_to_latlon_nw(tx, ty, zoom):
        n = 2 ** zoom
        lon = tx / n * 360 - 180
        lat_r = math.atan(math.sinh(math.pi * (1 - 2 * ty / n)))
        return math.degrees(lat_r), lon

    def fetch_tile(tx, ty, zoom, retries=3):
        url = TILE_URL.format(z=zoom, x=tx, y=ty)
        for _ in range(retries):
            try:
                r = requests.get(url, timeout=10,
                    headers={"User-Agent": "BlitzFibre-QGIS-RAMP/1.0"})
                if r.status_code == 200:
                    return Image.open(io.BytesIO(r.content)).convert("RGB")
            except Exception:
                time.sleep(1)
        return None

    def get_tile_world_coords(tx, ty, zoom):
        lat_n, lon_w = tile_to_latlon_nw(tx,   ty,   zoom)
        lat_s, lon_e = tile_to_latlon_nw(tx+1, ty+1, zoom)
        return lat_n, lon_w, lat_s, lon_e

    def pixel_to_latlon(px, py, tw, th, lat_n, lon_w, lat_s, lon_e):
        lon = lon_w + (px / tw) * (lon_e - lon_w)
        lat = lat_n + (py / th) * (lat_s - lat_n)
        return lat, lon
    # ─────────────────────────────────────────────────────────────────────────────

    # ── Metre distance helper ─────────────────────────────────────────────────────
    DEG_M = 111320.0

    def nearest_gob_dist(lon, lat, gob_coords):
        if len(gob_coords) == 0:
            return 9999.0
        dlat = (gob_coords[:, 1] - lat) * DEG_M
        dlon = (gob_coords[:, 0] - lon) * DEG_M * math.cos(math.radians(lat))
        return float(np.sqrt(dlat**2 + dlon**2).min())
    # ─────────────────────────────────────────────────────────────────────────────

    print("Loading ONNX model...")
    sess = ort.InferenceSession(ONNX_PATH, providers=['CPUExecutionProvider'])
    inp_name = sess.get_inputs()[0].name
    out_name = sess.get_outputs()[0].name
    print(f"  Input:  {inp_name} {sess.get_inputs()[0].shape}")
    print(f"  Output: {out_name} {sess.get_outputs()[0].shape}")

    with open(GAP_PATH) as f:
        gap_cells = json.load(f)['features']
    print(f"Gap cells to process: {len(gap_cells)}")

    with open(GOB_PATH) as f:
        gob_data = json.load(f)
    gob_coords = np.array([
        feat['geometry']['coordinates'] for feat in gob_data['features']
    ])
    print(f"Existing GOB centroids: {len(gob_coords)}")

    new_centroids = []
    stats = {"cells": 0, "tiles_ok": 0, "tiles_fail": 0,
             "blobs_raw": 0, "new": 0, "dup": 0}

    for i, cell in enumerate(gap_cells):
        props = cell['properties']
        cx, cy = props['cx'], props['cy']
        count  = props['count']
        pct    = props.get('pct_of_median', 0)

        tx, ty = latlon_to_tile(cy, cx, ZOOM)
        tile_img = fetch_tile(tx, ty, ZOOM)
        stats['cells'] += 1

        if tile_img is None:
            print(f"  [{i+1:3d}/{len(gap_cells)}] TILE FAIL  ({cx:.4f},{cy:.4f})")
            stats['tiles_fail'] += 1
            continue

        tw, th = tile_img.size
        lat_n, lon_w, lat_s, lon_e = get_tile_world_coords(tx, ty, ZOOM)

        cx_px = int((cx - lon_w) / (lon_e - lon_w) * tw)
        cy_px = int((cy - lat_n) / (lat_s - lat_n) * th)
        half = MODEL_PX // 2
        x0 = max(0, cx_px - half);  x1 = x0 + MODEL_PX
        y0 = max(0, cy_px - half);  y1 = y0 + MODEL_PX
        if x1 > tw: x0 = tw - MODEL_PX; x1 = tw
        if y1 > th: y0 = th - MODEL_PX; y1 = th
        crop = tile_img.crop((x0, y0, x1, y1)).resize((MODEL_PX, MODEL_PX))

        arr = np.array(crop, dtype=np.float32)[np.newaxis] / 255.0
        mask = sess.run([out_name], {inp_name: arr})[0][0, :, :, 0]

        binary = (mask >= MASK_THRESH).astype(np.uint8)
        labeled, n_blobs = ndimage.label(binary)

        blobs_found = 0
        for blob_id in range(1, n_blobs + 1):
            blob_px = np.where(labeled == blob_id)
            if len(blob_px[0]) < MIN_BLOB_PX:
                continue
            blobs_found += 1
            py_c = float(np.mean(blob_px[0]))
            px_c = float(np.mean(blob_px[1]))
            abs_px = x0 + px_c
            abs_py = y0 + py_c
            blat, blon = pixel_to_latlon(abs_px, abs_py, tw, th, lat_n, lon_w, lat_s, lon_e)
            d = nearest_gob_dist(blon, blat, gob_coords)
            if d < MERGE_M:
                stats['dup'] += 1
                continue
            new_centroids.append({
                "type": "Feature",
                "geometry": {"type": "Point",
                             "coordinates": [round(blon, 7), round(blat, 7)]},
                "properties": {
                    "source": "RAMP",
                    "blob_px": len(blob_px[0]),
                    "mask_conf": round(float(mask[blob_px].mean()), 3),
                    "nearest_gob_m": round(d, 1)
                }
            })
            stats['new'] += 1

        stats['tiles_ok'] += 1
        stats['blobs_raw'] += blobs_found
        print(f"  [{i+1:3d}/{len(gap_cells)}] cell ({cx:.4f},{cy:.4f}) "
              f"GOB={count} ({pct:.0f}%)  "
              f"tile={tx},{ty}  blobs={blobs_found}  new={stats['new']}")

    # ── Save outputs ──────────────────────────────────────────────────────────────
    out_new  = f"{OUT_DIR}/ramp_new_centroids.geojson"
    out_all  = f"{OUT_DIR}/ramp_merged_all.geojson"

    with open(out_new, 'w') as f:
        json.dump({"type": "FeatureCollection", "features": new_centroids}, f)

    for feat in gob_data['features']:
        feat['properties']['source'] = 'GOB'
    all_feats = gob_data['features'] + new_centroids
    with open(out_all, 'w') as f:
        json.dump({"type": "FeatureCollection", "features": all_feats}, f)

    print(f"""
    === RAMP SUMMARY ===
      Gap cells processed : {stats['cells']}
      Tiles fetched OK    : {stats['tiles_ok']}
      Tiles failed        : {stats['tiles_fail']}
      Blobs detected      : {stats['blobs_raw']}
      Skipped (dup GOB)   : {stats['dup']}
      NEW centroids added : {stats['new']}
      GOB original        : {len(gob_coords)}
      TOTAL after merge   : {len(gob_coords) + stats['new']}

      -> {out_new}
      -> {out_all}
    """)


if __name__ == '__main__':
    main()
