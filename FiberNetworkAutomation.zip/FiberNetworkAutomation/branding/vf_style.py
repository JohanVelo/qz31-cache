"""vf_style — Velocity Nexus palette, dialog QSS, drawn logo, and apply helpers."""

# ── Palette ──────────────────────────────────────────────────────────────────
# Brand (from velocity_logo.jpg / the V-mark gradient)
NAVY        = '#1A2050'   # wordmark navy
CRIMSON     = '#8B2450'   # V-mark gradient end
BLUE        = '#3D5CB8'   # V-mark gradient start
# UI surfaces (established Home-panel dark theme)
BG          = '#24253A'   # window background
PANEL       = '#2E3047'   # cards / group boxes
BORDER      = '#3A3D5C'
BORDER_HI   = '#474B6E'
TEXT        = '#E6E8F0'
TEXT_MUTED  = '#A0A4BC'
TEXT_DIM    = '#6E7392'
# Accents
PRIMARY     = '#6E56CF'   # violet — primary buttons
PRIMARY_HI  = '#8067D8'
PRIMARY_LO  = '#5A45B0'
CYAN        = '#2ABFCC'   # fibertime cyan
YELLOW      = '#FFE619'   # fibertime yellow
GREEN       = '#22C55E'
AMBER       = '#F59E0B'
RED         = '#DC2626'

DIALOG_QSS = f"""
QDialog, QWizard {{
    background: {BG};
    color: {TEXT};
}}
QDockWidget {{ background: {BG}; color: {TEXT}; }}
QDockWidget::title {{ background: {PANEL}; color: {TEXT}; padding: 5px 8px; }}
QDockWidget > QWidget, QScrollArea, QScrollArea > QWidget > QWidget {{ background: {BG}; }}
QLabel {{ color: {TEXT}; background: transparent; }}
QGroupBox {{
    background: {PANEL};
    border: 1px solid {BORDER};
    border-radius: 6px;
    margin-top: 14px;
    padding: 10px 8px 8px 8px;
    color: {TEXT};
    font-weight: 600;
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 4px;
    color: {CYAN};
}}
QPushButton {{
    background: {PRIMARY};
    color: white;
    border: none;
    border-radius: 5px;
    padding: 7px 18px;
    font-weight: 600;
}}
QPushButton:hover {{ background: {PRIMARY_HI}; }}
QPushButton:pressed {{ background: {PRIMARY_LO}; }}
QPushButton:disabled {{ background: {BORDER}; color: {TEXT_DIM}; }}
QPushButton[vfSecondary="true"] {{
    background: transparent;
    color: {TEXT_MUTED};
    border: 1px solid {BORDER_HI};
}}
QPushButton[vfSecondary="true"]:hover {{ color: {TEXT}; border-color: {PRIMARY_HI}; }}
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QTextEdit, QPlainTextEdit {{
    background: {PANEL};
    color: {TEXT};
    border: 1px solid {BORDER_HI};
    border-radius: 4px;
    padding: 5px 8px;
    selection-background-color: {PRIMARY};
}}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus {{
    border-color: {PRIMARY_HI};
}}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox QAbstractItemView {{
    background: {PANEL}; color: {TEXT};
    selection-background-color: {PRIMARY};
    border: 1px solid {BORDER_HI};
}}
QCheckBox, QRadioButton {{ color: {TEXT}; spacing: 7px; }}
QCheckBox::indicator, QRadioButton::indicator {{
    width: 15px; height: 15px;
    border: 1px solid {BORDER_HI}; border-radius: 3px;
    background: {PANEL};
}}
QCheckBox::indicator:checked, QRadioButton::indicator:checked {{
    background: {PRIMARY}; border-color: {PRIMARY_HI};
}}
QProgressBar {{
    background: {PANEL};
    border: 1px solid {BORDER};
    border-radius: 4px;
    color: {TEXT};
    text-align: center;
    height: 16px;
}}
QProgressBar::chunk {{ background: {CYAN}; border-radius: 3px; }}
QTabWidget::pane {{ border: 1px solid {BORDER}; background: {PANEL}; }}
QTabBar::tab {{
    background: {BG}; color: {TEXT_MUTED};
    padding: 6px 14px; border: 1px solid {BORDER}; border-bottom: none;
    border-top-left-radius: 4px; border-top-right-radius: 4px;
}}
QTabBar::tab:selected {{ background: {PANEL}; color: {TEXT}; }}
QScrollBar:vertical {{ background: {BG}; width: 11px; }}
QScrollBar::handle:vertical {{ background: {BORDER_HI}; border-radius: 5px; min-height: 24px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}
QToolTip {{ background: {NAVY}; color: {TEXT}; border: 1px solid {PRIMARY}; }}
"""


def make_logo_pixmap(width=170, height=36, dark_bg=True):
    """Draw the V-mark + 'Velocity Nexus' wordmark (vector, no jpg — crisp on dark)."""
    from qgis.PyQt.QtCore import Qt, QPointF
    from qgis.PyQt.QtGui import (QPixmap, QPainter, QColor, QPainterPath,
                                 QLinearGradient, QBrush, QFont)
    pix = QPixmap(width, height)
    pix.fill(Qt.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.Antialiasing)

    IW, IH = 26, 30
    IX, IY = 2, (height - IH) / 2
    grad = QLinearGradient(IX + IW * 0.2, IY, IX + IW * 0.6, IY + IH)
    grad.setColorAt(0.0, QColor(BLUE))
    grad.setColorAt(1.0, QColor(CRIMSON))
    cx, tip, top = IX + IW / 2, IY + IH, IY + 7
    path = QPainterPath()
    path.moveTo(IX, top)
    path.cubicTo(IX, top + 5, cx - 3.5, tip - 6, cx, tip)
    path.cubicTo(cx + 3.5, tip - 6, IX + IW, top + 5, IX + IW, top)
    path.cubicTo(IX + IW - 1, top + 3, cx + 2, tip - 10, cx, tip - 5)
    path.cubicTo(cx - 2, tip - 10, IX + 1, top + 3, IX, top)
    path.closeSubpath()
    p.setPen(Qt.NoPen)
    p.fillPath(path, QBrush(grad))
    p.setBrush(QBrush(QColor(BLUE)))
    p.drawEllipse(QPointF(IX + IW - 2, IY + 2.5), 3.5, 3.5)

    TX, mid = IX + IW + 8, height // 2
    p.setFont(QFont('Segoe UI', 10, QFont.Bold))
    p.setPen(QColor(TEXT if dark_bg else NAVY))
    p.drawText(TX, mid + 5, 'Velocity')
    vel_w = p.fontMetrics().horizontalAdvance('Velocity')
    p.setFont(QFont('Segoe UI', 10, QFont.Normal))
    p.setPen(QColor(TEXT_MUTED if dark_bg else '#7A86A0'))
    p.drawText(TX + vel_w + 4, mid + 5, 'Nexus')
    p.end()
    return pix


def make_header(title, parent=None):
    """Branded header bar: V-mark wordmark left, dialog title right, crimson rule below."""
    from qgis.PyQt.QtWidgets import QWidget, QHBoxLayout, QLabel, QVBoxLayout, QFrame
    head = QWidget(parent)
    v = QVBoxLayout(head)
    v.setContentsMargins(0, 0, 0, 4)
    v.setSpacing(6)
    row = QHBoxLayout()
    logo = QLabel()
    logo.setPixmap(make_logo_pixmap())
    row.addWidget(logo)
    row.addStretch(1)
    t = QLabel(title or '')
    t.setStyleSheet(f'color: {CYAN}; font-size: 13px; font-weight: 600; background: transparent;')
    row.addWidget(t)
    v.addLayout(row)
    rule = QFrame()
    rule.setFixedHeight(2)
    rule.setStyleSheet(f'background: qlineargradient(x1:0, y1:0, x2:1, y2:0, '
                       f'stop:0 {BLUE}, stop:0.6 {CRIMSON}, stop:1 transparent); border: none;')
    v.addWidget(rule)
    return head


def apply_vf_style(widget, title=None, header=True):
    """Apply the Velocity Nexus theme to a dialog/dock.

    QSS always; if `header` and the widget has a QVBoxLayout, a branded header bar
    (logo + title + crimson rule) is inserted at the top. Safe to call twice."""
    from qgis.PyQt.QtWidgets import QVBoxLayout
    widget.setStyleSheet(DIALOG_QSS)
    if header and not getattr(widget, '_vf_header_done', False):
        lay = widget.layout()
        if isinstance(lay, QVBoxLayout):
            lay.insertWidget(0, make_header(title or widget.windowTitle(), widget))
            widget._vf_header_done = True
    return widget


def mark_secondary(button):
    """Style a button as the quiet/secondary variant (Cancel, Close…)."""
    button.setProperty('vfSecondary', True)
    button.style().unpolish(button)
    button.style().polish(button)
    return button
