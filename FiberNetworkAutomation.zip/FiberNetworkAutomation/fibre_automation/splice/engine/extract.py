# -*- coding: utf-8 -*-
"""Read-only extraction of a fibre network into one normalised snapshot.

Two backends, ONE output shape, so everything downstream is identical whether the
data came from a running QGIS or from shapefiles on disk:

    shapefile  geopandas — the sandbox, CI, and any headless run
    qgis       PyQGIS in-process — what the Velocity Nexus button uses

WHY THE SNAPSHOT IS A SEPARATE STAGE
  `from osgeo import ogr` and `openpyxl` in one process throw
  `ModuleNotFoundError: No module named '_gdal'` under the qgis-venv (measured; see
  projects/moa-ph2/splice-plan.md). Extraction therefore writes JSON and the renderer
  reads JSON — the process boundary is a hard requirement, not tidiness.

PROVENANCE IS PART OF THE OUTPUT
  The snapshot records, per role: the layer name ASKED for, the layer name RESOLVED,
  the source path and the feature count. A silent ' v1' fallback once made the BOQ read
  3,374 Phase-1 domes instead of PH2's 1,011. Here a fallback is recorded and flagged,
  so it can never be mistaken for a clean read.

⛔ READ-ONLY. Nothing in this module opens a data source for writing.
"""
from __future__ import annotations

import json
import os
import time

# ── geometry helpers ─────────────────────────────────────────────────────────


def _line_points(geom):
    """Vertex list of a LineString / first part of a MultiLineString."""
    gt = geom.geom_type
    if gt == "LineString":
        return [(float(x), float(y)) for x, y in geom.coords]
    if gt == "MultiLineString":
        pts = []
        for part in geom.geoms:
            pts.extend((float(x), float(y)) for x, y in part.coords)
        return pts
    return []


def _point_xy(geom):
    gt = geom.geom_type
    if gt == "Point":
        return (float(geom.x), float(geom.y))
    c = geom.centroid
    return (float(c.x), float(c.y))


# ── shapefile backend ────────────────────────────────────────────────────────

def _geo_bootstrap():
    """Make pyproj usable from a bare python.exe on a QGIS-based venv.

    Without this, `to_crs` runs, raises nothing, and returns the coordinates UNCHANGED
    — still degrees. Every distance in the walk is then ~0.00001, every cable measures
    0.0 m, and every dome looks like it sits on every cable. Measured 2026-08-19: it
    silently produced a model in which one spur passed all 16 domes of its PON.

    Two things must both be true and each alone still fails:
      1. QGIS's `bin` must be a DLL search directory, or pyproj's `_context` will not load
      2. pyproj must be imported BEFORE geopandas, which caches HAS_PYPROJ on first failure
    """
    import glob
    import os as _os
    import sys as _sys
    if _os.name != "nt":
        return
    root = _os.environ.get("VF_QGIS_ROOT")
    if not root or not _os.path.isdir(root):
        cands = [p for pat in (r"C:/Program Files/QGIS *", r"C:/Program Files/QGIS")
                 for p in glob.glob(pat) if _os.path.isdir(p)]
        root = sorted(cands)[-1] if cands else None
    if not root:
        return
    for sub in ("bin", "apps/qgis/bin", "apps/Qt6/bin"):
        d = _os.path.join(root, sub).replace("\\", "/")
        if _os.path.isdir(d):
            try:
                _os.add_dll_directory(d)
            except (OSError, AttributeError):
                pass
            _os.environ["PATH"] = d + _os.pathsep + _os.environ.get("PATH", "")
    for var, sub in (("PROJ_DATA", "share/proj"), ("PROJ_LIB", "share/proj"),
                     ("GDAL_DATA", "share/gdal")):
        d = _os.path.join(root, sub)
        if _os.path.isdir(d) and not _os.environ.get(var):
            _os.environ[var] = d
    try:
        import pyproj
        pyproj.datadir.set_data_dir(_os.environ.get("PROJ_DATA", ""))
    except Exception:
        pass
    _sys.modules.pop("geopandas", None)


class CrsError(RuntimeError):
    """The reprojection did not happen. Never a warning — every downstream metre is wrong."""


def _assert_metric(gdf, layer, epsg):
    """Prove the coordinates really are metres before anything measures with them."""
    if gdf.empty:
        return
    minx, miny, maxx, maxy = gdf.total_bounds
    if max(abs(minx), abs(maxx)) < 1000 and max(abs(miny), abs(maxy)) < 1000:
        raise CrsError(
            f"{layer}: coordinates are still degrees after to_crs(epsg={epsg}) "
            f"(bounds {minx:.4f},{miny:.4f} .. {maxx:.4f},{maxy:.4f}). PROJ data is "
            f"missing, so the reprojection was a silent no-op. Set VF_QGIS_ROOT or "
            f"PROJ_DATA. Refusing to build a model in which every distance is ~0.")


def _read_shapefiles(profile, root):
    """Read every profile layer from a folder of `<name>/<name>.shp` directories."""
    _geo_bootstrap()
    import geopandas as gpd  # imported here so the module loads without geo deps

    label_fields = profile.data.get("label_fields", {})
    resolved, frames = {}, {}
    for role, layer in profile.layers.items():
        d = os.path.join(root, layer)
        shp = os.path.join(d, layer + ".shp")
        used, fallback = layer, None
        if not os.path.exists(shp):
            # A missing layer is reported, never silently swapped for a similar name.
            alts = [x for x in sorted(os.listdir(root))
                    if x.lower().startswith(layer.lower().split(" v")[0])] if os.path.isdir(root) else []
            raise FileNotFoundError(
                f"layer {layer!r} (role {role!r}) not found at {shp}. "
                f"similar names present: {alts}")
        gdf = gpd.read_file(shp)
        if profile.metric_epsg and gdf.crs is not None:
            try:
                if gdf.crs.to_epsg() != profile.metric_epsg:
                    gdf = gdf.to_crs(epsg=profile.metric_epsg)
            except Exception:
                gdf = gdf.to_crs(epsg=profile.metric_epsg)
        _assert_metric(gdf, layer, profile.metric_epsg)
        frames[role] = (gdf, label_fields.get(role, "label"))
        resolved[role] = {"asked": layer, "resolved": used, "source": shp,
                          "count": len(gdf), "fallback": fallback}
    return frames, resolved


# ── qgis backend ─────────────────────────────────────────────────────────────

def _read_qgis(profile):
    """Read from the running QGIS project. Same return shape as _read_shapefiles."""
    from qgis.core import QgsProject, QgsVectorLayer, QgsCoordinateReferenceSystem
    from qgis.core import QgsCoordinateTransform, QgsWkbTypes

    label_fields = profile.data.get("label_fields", {})
    proj = QgsProject.instance()
    dest = QgsCoordinateReferenceSystem.fromEpsgId(profile.metric_epsg)

    def find(name):
        exact = [x for x in proj.mapLayers().values() if x.name() == name]
        if exact:
            return exact[0], None
        loose = [x for x in proj.mapLayers().values()
                 if x.name().strip().lower() == name.strip().lower()]
        if loose:
            return loose[0], f"case-insensitive match: {loose[0].name()!r}"
        return None, None

    frames, resolved = {}, {}
    for role, name in profile.layers.items():
        lyr, fallback = find(name)
        if lyr is None or not isinstance(lyr, QgsVectorLayer):
            raise RuntimeError(
                f"layer {name!r} (role {role!r}) is not in the open project. "
                f"open the right project, or point the profile at the right name.")
        xform = QgsCoordinateTransform(lyr.crs(), dest, proj)
        rows = []
        fields = [f.name() for f in lyr.fields()]
        for feat in lyr.getFeatures():
            g = feat.geometry()
            if g is None or g.isEmpty():
                pts = []
            elif QgsWkbTypes.geometryType(g.wkbType()) == QgsWkbTypes.PointGeometry:
                p = g.asPoint() if not g.isMultipart() else g.asMultiPoint()[0]
                p = xform.transform(p)
                pts = [(p.x(), p.y())]
            else:
                line = g.asPolyline() if not g.isMultipart() else (
                    [p for part in g.asMultiPolyline() for p in part])
                pts = [(lambda q: (q.x(), q.y()))(xform.transform(p)) for p in line]
            attrs = {f: feat[f] for f in fields}
            rows.append((attrs, pts))
        frames[role] = (rows, label_fields.get(role, "label"))
        resolved[role] = {"asked": name, "resolved": lyr.name(),
                          "source": lyr.source(), "count": int(lyr.featureCount()),
                          "fallback": fallback}
    return frames, resolved


# ── normalisation, shared by both backends ───────────────────────────────────

def _iter(frames, role):
    """Yield (attrs dict, points list) for a role, whichever backend produced it."""
    obj, labfield = frames[role]
    if isinstance(obj, list):                       # qgis backend
        for attrs, pts in obj:
            yield attrs, pts, labfield
        return
    for _, row in obj.iterrows():                   # geopandas backend
        geom = row.geometry
        if geom is None or geom.is_empty:
            pts = []
        elif geom.geom_type == "Point":
            pts = [_point_xy(geom)]
        else:
            pts = _line_points(geom)
        attrs = {k: row[k] for k in obj.columns if k != "geometry"}
        yield attrs, pts, labfield


def _s(v):
    """Attribute -> clean string or None. NULL, NaN and blanks all collapse to None."""
    if v is None:
        return None
    s = str(v).strip()
    if s in ("", "NULL", "None", "nan", "NaN", "<NULL>"):
        return None
    return s


def _pon(v):
    """pon_no is a STRING on FTS Splitters and an INT on STS/Distribution. Joining the
    two without normalising makes every FTS look orphaned and the walk covers nothing —
    with no error at all. Normalise every read through here."""
    s = _s(v)
    if s is None:
        return None
    try:
        return int(float(s))
    except (TypeError, ValueError):
        return None


def build_snapshot(profile, backend="shapefile", root=None):
    """Return the normalised snapshot dict. Read-only."""
    t0 = time.time()
    if backend == "shapefile":
        frames, resolved = _read_shapefiles(profile, root)
    elif backend == "qgis":
        frames, resolved = _read_qgis(profile)
    else:
        raise ValueError(f"unknown backend {backend!r}")

    warn = []

    # poles ------------------------------------------------------------------
    poles = []
    for attrs, pts, lf in _iter(frames, "poles"):
        lab = _s(attrs.get(lf))
        if not lab or not pts:
            continue
        p = profile.parse("pole", lab)
        poles.append({"label": lab, "code": p["code"] if p else lab,
                      "x": pts[0][0], "y": pts[0][1],
                      "pon": _pon(attrs.get("pon_no"))})

    # domes ------------------------------------------------------------------
    domes = []
    for attrs, pts, lf in _iter(frames, "agg_dome"):
        lab = _s(attrs.get(lf))
        if not lab or not pts:
            continue
        agg = profile.parse("agg_dome", lab)
        dis = profile.parse("dis_dome", lab)
        if agg:
            kind, pole = "AGG", agg["pole"]
        elif dis:
            kind, pole = "DIS", dis["pole"]
        else:
            continue
        domes.append({"label": lab, "kind": kind, "pole": pole,
                      "x": pts[0][0], "y": pts[0][1],
                      "spec": _s(attrs.get("spec_1")),
                      "pon": _pon(attrs.get("pon_no"))})

    # splitters --------------------------------------------------------------
    fts = []
    for attrs, pts, lf in _iter(frames, "fts"):
        lab = _s(attrs.get(lf))
        p = profile.parse("fts", lab)
        if not p:
            if lab:
                warn.append(f"FTS label does not match the profile grammar: {lab}")
            continue
        fts.append({"label": lab, "pole": p["pole"], "ratio": int(p["ratio"]),
                    "olt": p["olt"], "card": int(p["card"]), "port": int(p["port"]),
                    "pon_attr": _pon(attrs.get("pon_no")),
                    "x": pts[0][0] if pts else None, "y": pts[0][1] if pts else None,
                    "agg_dome": f"{profile.prefix}.AGG.DM.P.{p['pole']}"})

    sts = []
    for attrs, pts, lf in _iter(frames, "sts"):
        lab = _s(attrs.get(lf))
        p = profile.parse("sts", lab)
        if not p:
            if lab:
                warn.append(f"STS label does not match the profile grammar: {lab}")
            continue
        sts.append({"label": lab, "pole": p["pole"], "ratio": int(p["ratio"]),
                    "olt": p["olt"], "card": int(p["card"]), "port": int(p["port"]),
                    "leg": int(p["leg"]), "pon_attr": _pon(attrs.get("pon_no")),
                    "x": pts[0][0] if pts else None, "y": pts[0][1] if pts else None,
                    "dis_dome": f"{profile.prefix}.DIS.DM.P.{p['pole']}"})

    # cables -----------------------------------------------------------------
    cables = []
    for role in ("distribution", "secondary", "primary"):
        for attrs, pts, lf in _iter(frames, role):
            lab = _s(attrs.get(lf))
            if not lab:
                continue
            p = profile.parse("cable", lab)
            cables.append({
                "label": lab, "role": role,
                "kind": p["kind"] if p else None,
                "cap": int(p["cap"]) if p else None,
                "start_raw": p["start"] if p else None,
                "end_code": p["end"] if p else None,
                "pon": _pon(attrs.get("pon_no")),
                "cblcpty": _s(attrs.get("cblcpty")),
                "strtfeat": _s(attrs.get("strtfeat")),
                "endfeat": _s(attrs.get("endfeat")),
                "pts": [[round(x, 3), round(y, 3)] for x, y in pts],
            })
            if not p:
                warn.append(f"cable label does not match the profile grammar: {lab}")

    # drops ------------------------------------------------------------------
    drops = []
    for role, spare in (("drop", False), ("spare_drop", True)):
        for attrs, pts, lf in _iter(frames, role):
            lab = _s(attrs.get(lf))
            if not lab or len(pts) < 2:
                continue
            drops.append({"label": lab, "spare": spare,
                          "pon": _pon(attrs.get("pon_no")),
                          "a": [round(pts[0][0], 3), round(pts[0][1], 3)],
                          "b": [round(pts[-1][0], 3), round(pts[-1][1], 3)],
                          "strtfeat": _s(attrs.get("strtfeat")),
                          "endfeat": _s(attrs.get("endfeat"))})

    # onts, pons -------------------------------------------------------------
    onts = []
    for attrs, pts, lf in _iter(frames, "ont"):
        lab = _s(attrs.get(lf))
        if not lab:
            continue
        p = profile.parse("ont", lab)
        onts.append({"label": lab, "dr": p["dr"] if p else None,
                     "pon": _pon(attrs.get("pon_no")),
                     "x": pts[0][0] if pts else None, "y": pts[0][1] if pts else None})

    pons = []
    for attrs, pts, lf in _iter(frames, "pon"):
        n = _pon(attrs.get("pon_no")) or _pon(attrs.get(lf))
        if n is None:
            continue
        pons.append({"pon": n, "zone": _pon(attrs.get("zone_no")),
                     "label": _s(attrs.get(lf))})

    snap = {
        "meta": {
            "profile": profile.name,
            "prefix": profile.prefix,
            "backend": backend,
            "metric_epsg": profile.metric_epsg,
            "generated": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "root": root,
            "elapsed_s": round(time.time() - t0, 2),
            "layers": resolved,
            "warnings": warn[:200],
            "warning_count": len(warn),
        },
        "poles": poles, "domes": domes, "fts": fts, "sts": sts,
        "cables": cables, "drops": drops, "onts": onts, "pons": pons,
    }
    snap["meta"]["counts"] = {k: len(v) for k, v in snap.items() if isinstance(v, list)}
    return snap


def write_snapshot(snap, path):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".part"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(snap, fh, separators=(",", ":"))
    os.replace(tmp, path)          # atomic: a reader never sees a half-written snapshot
    return path


def load_snapshot(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


if __name__ == "__main__":
    import argparse
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import project_profile as profile_mod

    ap = argparse.ArgumentParser(description="Extract a splice snapshot (read-only).")
    ap.add_argument("--profile", default="moa_ph2")
    ap.add_argument("--backend", default="shapefile", choices=("shapefile", "qgis"))
    ap.add_argument("--root", default="C:/Temp/splice_sandbox/data")
    ap.add_argument("--out", default="C:/Temp/splice_sandbox/snapshot.json")
    a = ap.parse_args()

    prof = profile_mod.load(a.profile)
    s = build_snapshot(prof, backend=a.backend, root=a.root)
    write_snapshot(s, a.out)
    print("profile  ", prof.name)
    print("counts   ", s["meta"]["counts"])
    print("warnings ", s["meta"]["warning_count"])
    for role, r in s["meta"]["layers"].items():
        flag = "  <- FALLBACK" if r["fallback"] else ""
        print(f"  {role:<13} {r['resolved']:<32} n={r['count']}{flag}")
    print("wrote    ", a.out, f"({os.path.getsize(a.out):,} bytes)")
