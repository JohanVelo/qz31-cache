"""Vuma Step 7 — Auto-name all infrastructure layers.

STATUS: [x] BUILT
"""

# claude:approved-destructive


import re

from qgis.core import QgsProject

from fibre_automation.startup import SESSION


def _get(name):
    layers = QgsProject.instance().mapLayersByName(name)
    return layers[0] if layers else None


def _bulk_write_names(layer, name_field: str, new_names: dict):
    """Write {fid: name_str} to layer name field in one bulk call."""
    idx = layer.fields().indexOf(name_field)
    if idx < 0:
        return 0
    attr_map = {fid: {idx: name} for fid, name in new_names.items()}
    layer.dataProvider().changeAttributeValues(attr_map)  # claude:approved-destructive
    return len(attr_map)


def _name_sequential(layer, name_field: str, prefix_fn, skip_existing: bool = True) -> int:
    """Assign sequential names to features that don't already have one.

    prefix_fn(n) → label string, called with 1-based counter.
    """
    idx = layer.fields().indexOf(name_field)
    if idx < 0:
        return 0

    # Find max existing sequence number to avoid gaps
    existing_nums = set()
    for feat in layer.getFeatures():
        val = str(feat[idx] or "").strip()
        if val:
            try:
                # Extract trailing digits only (ignore digits in area/zone prefix)
                m = re.search(r"(\d+)$", val)
                if m:
                    existing_nums.add(int(m.group(1)))
            except ValueError:
                pass

    counter = (max(existing_nums) + 1) if existing_nums else 1
    new_names = {}

    for feat in layer.getFeatures():
        if skip_existing:
            val = str(feat[idx] or "").strip()
            if val:
                continue
        new_names[feat.id()] = prefix_fn(counter)
        counter += 1

    if new_names:
        _bulk_write_names(layer, name_field, new_names)
    return len(new_names)


def vuma_step_07_naming():
    """Apply auto-naming to all Vuma infrastructure layers.

    STATUS: [x] BUILT
    Safe to re-run — skips features that already have a Name value.

    Naming conventions (Malmsbury V1.1 schema):
      Poles            AREA-Zn-P0001
      Dome Joint       AREA-Zn-DJ0001
      Spur Joints      AREA-Zn-SJ0001
      Feeder Joints    AREA-Zn-FJ0001
      Link Joints      AREA-Zn-LJ0001
      4 Way Splitters  AREA-Zn-SP0001
      Aggregation Joint  AREA-Zn-AJ0001
      Node             AREA-Zn-ND01
      Feeder           AREA-Zn-FC001
      Link Cable       AREA-Zn-LC001
      Distribution Cable  AREA-Zn-DC001
      Spur Cable       AREA-Zn-SC001
      Drops            (named via Demand Point DR number)
    """
    print(f"\n{'═' * 50}")
    print("  VUMA STEP 7 — Auto-Naming")
    print(f"{'═' * 50}")

    area = SESSION.get("area_code") or "AREA"
    zone = SESSION.get("zone_code") or "Z1"

    naming_targets = [
        # (layer_name, name_field, type_code, zero_pad)
        ("Poles",              "Name",   "P",  4),
        ("Dome Joint",         "Name",   "DJ", 4),
        ("Spur Joints",        "Name",   "SJ", 4),
        ("Feeder Joints",      "Label",  "FJ", 4),
        ("Link Joints",        "Label",  "LJ",    4),
        ("4 Way Splitters",    "Name",   "SP", 4),
        ("Aggregation Joint",  "Name",   "AJ", 4),
        ("Node",               "Name",   "ND", 2),
        ("Feeder",             "Name",   "FC", 3),
        ("Link Cable",         "Name",   "LC", 3),
        ("Distribution Cable", "Name",   "DC", 3),
        ("Spur Cable",         "Name",   "SC", 3),
    ]

    total_named = 0
    for layer_name, field, type_code, pad in naming_targets:
        lyr = _get(layer_name)
        if lyr is None:
            continue
        prefix = f"{area}-{zone}-{type_code}"
        fmt = f"{{:0{pad}d}}"

        def make_fn(p, f):
            def fn(n):
                return p + f.format(n)
            return fn

        n = _name_sequential(lyr, field, make_fn(prefix, fmt))
        if n:
            print(f"  ✓ {layer_name:<25} {n:>5,} named")
            total_named += n
        else:
            count = lyr.featureCount()
            if count > 0:
                print(f"  ⊘ {layer_name:<25} already named ({count:,} features)")

    print(f"\n  Total features named this run: {total_named:,}")
    print(f"{'═' * 50}\n")
