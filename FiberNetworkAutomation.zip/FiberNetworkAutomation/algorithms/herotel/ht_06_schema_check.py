# HeroTel: Schema Check (read-only) — HT 6
# claude:intent READ-ONLY — opens no edit session, writes no layer, only reports.

from qgis.core import (
    QgsProcessingParameterBoolean,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterString,
)

from .ht_base_algorithm import HeroTelBaseAlgorithm


class HT06SchemaCheckAlgorithm(HeroTelBaseAlgorithm):
    """
    HT 6 — Schema Check. Reports how far this project is from the canonical
    HeroTel layer + attribute schema. It never changes anything.

    The schema is not invented: it is derived from the three delivered towns
    HeroTel accepted (Middelburg Rev1.4, Botchabelo Rev1.3, Barberton Rev1.0),
    which share an identical 16-layer core. HeroTel has never supplied a layer
    or attribute schema of their own — their spec set has a governing LABELLING
    standard and nothing else.

    ⛔ The checks live in `fibre_automation/herotel_schema/core.py`, shared with
    the command-line validator. One copy, two front ends — a check that exists
    twice eventually disagrees with itself.

    Run it: any time, on anything. It is safe on a shipped project, which is the
    point — a shipped project is where you want a finding and never an edit.
    """

    STRICT = 'STRICT'
    REPORT = 'REPORT'
    TOWN = 'TOWN'
    STANDARD = 'STANDARD'

    #: Which yardstick to measure against. Index 0 is the long-standing default.
    STANDARDS = [
        'Delivered client packages (Middelburg, Barberton, Botshabelo)',
        'VN 1 standard (the layers VN 1 builds)',
    ]

    def name(self):
        return 'ht_06_schema_check'

    def displayName(self):
        return 'HT 6 — Schema Check (read-only)'

    def shortHelpString(self):
        return """
        <p><b>HT 6 — Schema Check</b> — compares the layers open in this project
        against the canonical HeroTel schema and reports the gaps. <b>It writes
        nothing.</b></p>

        <h4>What it checks</h4>
        <ul>
          <li><b>Layers</b> — which canonical layers are missing, and which
              arrived under a different name (<code>Demand Points</code> instead
              of <code>Demand Units</code>).</li>
          <li><b>Fields</b> — required fields that are absent, renamed, or
              truncated to 10 characters by a shapefile round-trip
              (<code>pole_thickness</code> → <code>pole_thick</code>).</li>
          <li><b>Values</b> — values outside the vocabulary the delivered towns
              use, and values that match only after Unicode folding
              (Middelburg writes <code>1:16×2</code> where everyone else writes
              <code>1:16*2</code>).</li>
          <li><b>Fragmentation</b> — one layer per PON instead of one PON layer
              with a <code>pon</code> attribute, and the attribute-table drift
              that causes.</li>
        </ul>

        <h4>Severity</h4>
        <ul>
          <li><b>ERROR</b> — will break a BOQ or a splice plan downstream.</li>
          <li><b>WARN</b> — wrong but survivable; usually a rename.</li>
          <li><b>INFO</b> — tooling residue (KML/CAD columns) worth dropping.</li>
        </ul>

        <h4>Standard</h4>
        <p>By default the project is measured against the delivered client
        packages. Choose <b>VN 1 standard</b> to measure it against the layers
        VN 1 builds instead: every VN 1 layer present, with all its columns, in
        the same order. The two use different layer names, so a VN 1 project
        checked against the client packages reports many missing layers.</p>

        <p><b>Fail on errors</b> is off by default. Turn it on to make this a
        hard gate once the project is expected to be clean.</p>
        """

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterEnum(
                self.STANDARD,
                'Check against',
                options=self.STANDARDS,
                defaultValue=0,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.STRICT,
                'Fail on errors (otherwise report and succeed)',
                defaultValue=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.TOWN,
                'Town name (blank = infer from the project name)',
                defaultValue='',
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.REPORT,
                'Findings report (JSON, optional)',
                fileFilter='JSON files (*.json)',
                optional=True,
                createByDefault=False,
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        import json

        from qgis.core import QgsProcessingException, QgsProject

        from fibre_automation.herotel_schema import (ERROR, INFO, WARN, check,
                                                     from_qgis, load_schema,
                                                     summarise)
        from fibre_automation.herotel_schema.core import (load_evidence,
                                                          town_profile)

        strict = self.parameterAsBool(parameters, self.STRICT, context)
        vn1 = self.parameterAsEnum(parameters, self.STANDARD, context) == 1
        report_path = self.parameterAsFileOutput(parameters, self.REPORT, context)
        town = (self.parameterAsString(parameters, self.TOWN, context) or '').strip()

        schema = load_schema()
        views = from_qgis(QgsProject.instance())

        # The town decides which rules apply. An aerial-only pole layer is not
        # required of a trenched build - without this, Malmesbury reports 27
        # errors and none of them are errors. The VN 1 standard has no town
        # profiles, so it skips the 400 KB evidence file.
        evidence, profile = {}, 'vn1'
        if not vn1:
            evidence = load_evidence()
            if not town:
                town = self._infer_town(QgsProject.instance().baseName(), evidence)
            profile = town_profile(evidence, town)
        if not views:
            raise QgsProcessingException(
                'No vector layers in this project — nothing to check.')

        if vn1:
            feedback.pushInfo(f'Checking {len(views)} vector layer(s) against the VN 1 standard…')
        else:
            feedback.pushInfo(f'Checking {len(views)} vector layer(s) against '
                              f'canonical schema v{schema["version"]}…')
            feedback.pushInfo(f'Town: {town or "(not matched)"}   '
                              f'deployment profile: {profile}')
        if profile == 'unknown' and not vn1:
            feedback.pushWarning(
                'No deployment profile for this town — every canonical layer is '
                'treated as required. If this is a trenched build, expect aerial '
                'pole layers to be reported missing when they should not be.')
        if vn1:
            from fibre_automation.herotel_layers import build
            from fibre_automation.herotel_schema.core import check_standard
            findings = check_standard(views, build.load_spec())
        else:
            findings = check(views, schema, town=town, evidence=evidence)
        counts = summarise(findings)

        # Errors first: the report is read from the top and usually not to the
        # bottom, so the thing that breaks a BOQ must not sit under 27 lines of
        # KML residue.
        for sev, push in ((ERROR, feedback.reportError),
                          (WARN, feedback.pushWarning),
                          (INFO, feedback.pushInfo)):
            for f in findings:
                if f.severity == sev:
                    push(f'{sev}  {f.code}  [{f.layer}]  {f.detail}')

        feedback.pushInfo('')
        feedback.pushInfo(f'{counts[ERROR]} error   {counts[WARN]} warn   '
                          f'{counts[INFO]} info')
        if not findings:
            feedback.pushInfo('Clean — this project matches the VN 1 standard.' if vn1 else
                              'Clean — this project matches the canonical schema.')

        if report_path:
            payload = {'schema_version': schema['version'],
                       'standard': 'vn1' if vn1 else 'delivered',
                       'project': QgsProject.instance().baseName(),
                       'town': town, 'profile': profile,
                       'layers_checked': len(views),
                       'counts': counts,
                       'findings': [f.as_dict() for f in findings]}
            with open(report_path, 'w', encoding='utf-8') as fh:
                json.dump(payload, fh, indent=2)
            feedback.pushInfo(f'Report written to {report_path}')

        if strict and counts[ERROR]:
            raise QgsProcessingException(
                f'{counts[ERROR]} schema error(s) — see the log above.')

        return {'ERRORS': counts[ERROR], 'WARNINGS': counts[WARN],
                'INFO': counts[INFO], self.REPORT: report_path or ''}

    # ⚠ The archive and the project files disagree on how some towns are spelt.
    # These are the splits CLAUDE.md records; a substring match alone misses all
    # of them, which is how "Malmsbury Herotel V4" matched nothing and Malmesbury
    # was scored as an unknown profile - producing 27 errors that were not errors.
    SPELLING_VARIANTS = {
        "malmesbury": ("malmsbury",),
        "botchabelo": ("botshabelo",),
        "phalaborwa": ("palaborwa",),
    }

    @classmethod
    def _infer_town(cls, project_name, evidence):
        """Match a project name to a censused town.

        Three passes, cheapest and most certain first:
          1. substring either way, longest match wins - "Middelburg EC Rev1.4"
          2. the recorded spelling variants above
          3. fuzzy, at a deliberately high cutoff

        Returns '' when nothing is confident enough. An empty town means the
        profile is `unknown`, which is loud rather than silent: the algorithm
        warns that every layer is being treated as required.
        """
        import difflib
        import re

        def norm(s):
            return re.sub(r"[^a-z0-9]", "", str(s).lower())

        proj = norm(project_name)
        if not proj:
            return ""
        towns = list((evidence.get("profiles") or {}).keys())

        # 1. direct containment, longest wins so a short town name cannot beat a
        #    longer one that also matches.
        best = ""
        for town in towns:
            t = norm(town)
            if t and (t in proj or proj in t) and len(t) > len(norm(best)):
                best = town
        if best:
            return best

        # 2. the known spelling splits.
        for town in towns:
            t = norm(town)
            for variant in cls.SPELLING_VARIANTS.get(t, ()):
                if variant in proj:
                    return town

        # 3. fuzzy, on the leading word of the project name only - project names
        #    carry trailing noise ("Herotel V4") that drags every ratio down.
        head = re.split(r"[^A-Za-z]+", str(project_name).strip())
        head = norm(head[0]) if head and head[0] else proj
        hit = difflib.get_close_matches(head, [norm(t) for t in towns],
                                        n=1, cutoff=0.85)
        if hit:
            for town in towns:
                if norm(town) == hit[0]:
                    return town
        return ""

    def postProcessAlgorithm(self, context, feedback):
        return {}
