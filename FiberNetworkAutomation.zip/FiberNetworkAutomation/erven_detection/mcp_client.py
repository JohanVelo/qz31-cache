"""
HTTP client for the Erven MCP Server API (port 8780).

This runs inside QGIS's Python — uses ONLY stdlib (urllib, json).
NO torch, NO samgeo, NO httpx, NO requests.

The MCP server must be running separately:
    erven-mcp --http   (or --both for stdio + http simultaneously)
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request

MCP_API_HOST = "127.0.0.1"
MCP_API_PORT = 8780
_BASE_URL = f"http://{MCP_API_HOST}:{MCP_API_PORT}"
_TIMEOUT = 10  # seconds for short requests


class MCPClient:
    """Minimal HTTP client for the Erven MCP server API.

    Uses only Python stdlib — safe to run inside QGIS.
    """

    def __init__(self, base_url: str = _BASE_URL) -> None:
        self._base = base_url.rstrip("/")

    # ── Core helpers ──────────────────────────────────────────────────────

    def _get(self, path: str, timeout: int = _TIMEOUT) -> dict:
        url = f"{self._base}{path}"
        try:
            with urllib.request.urlopen(url, timeout=timeout) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.URLError as exc:
            return {"error": str(exc)}
        except Exception as exc:
            return {"error": str(exc)}

    def _post(self, path: str, data: dict, timeout: int = _TIMEOUT) -> dict:
        url = f"{self._base}{path}"
        body = json.dumps(data).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.URLError as exc:
            return {"error": str(exc)}
        except Exception as exc:
            return {"error": str(exc)}

    # ── Public API ────────────────────────────────────────────────────────

    def is_connected(self) -> bool:
        """Return True if the MCP server is reachable."""
        result = self._get("/health", timeout=3)
        return "error" not in result and result.get("status") == "ok"

    def get_status(self) -> dict:
        """Check backend readiness (SAM loaded, bridge connected)."""
        return self._get("/status")

    def get_progress(self) -> dict:
        """Poll current pipeline progress. Returns fraction 0–1 and message."""
        return self._get("/progress", timeout=5)

    def get_session(self) -> dict:
        """Return current session state (output paths, AOI, etc.)."""
        return self._get("/session")

    def run_pipeline(self, config: dict) -> dict:
        """Start the full detection pipeline (returns immediately).

        Config keys: source, preset, box_threshold, text_threshold,
                     buffer_m, run_ftth, pon_group_size, output_dir.

        Returns {"started": True} on success.
        Poll get_progress() for updates.
        """
        return self._post("/pipeline/run", config, timeout=10)

    def cancel_pipeline(self) -> dict:
        """Request the pipeline to stop at the next checkpoint."""
        return self._post("/pipeline/cancel", {})

    def get_pipeline_result(self) -> dict:
        """Return the result dict from the last completed pipeline run."""
        return self._get("/pipeline/result")
