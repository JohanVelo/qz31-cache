"""team_monitor — JJ-only dock: who's installed / online / doing what / errors.

Opens only when admin.is_admin(profile) is True (admin username + admin key).
Reads via Admin (owner key, async). Auto-refreshes every 30 s. Tabs:
  Online · Activity · Errors · Installs · Users
Owner actions: deactivate user, issue reset token, mark error resolved,
broadcast announcement.
"""
import time

from qgis.PyQt.QtCore import QTimer
from qgis.PyQt.QtWidgets import (QDockWidget, QFrame, QHBoxLayout, QInputDialog,
                                 QLabel, QMessageBox, QPushButton, QTableWidget,
                                 QTableWidgetItem, QTabWidget, QVBoxLayout,
                                 QWidget)

from . import admin as admin_mod
from . import config


def _age(iso):
    """Human 'x min ago' from an ISO timestamp."""
    try:
        import datetime
        dt = datetime.datetime.fromisoformat(iso.replace("Z", "+00:00"))
        secs = time.time() - dt.timestamp()
        if secs < 90:
            return "just now"
        if secs < 3600:
            return f"{int(secs // 60)} min ago"
        if secs < 86400:
            return f"{int(secs // 3600)} h ago"
        return f"{int(secs // 86400)} d ago"
    except Exception:
        return "?"


def _is_online(iso):
    try:
        import datetime
        dt = datetime.datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return (time.time() - dt.timestamp()) < config.ONLINE_WINDOW_S
    except Exception:
        return False


class TeamMonitorDock(QDockWidget):
    def __init__(self, iface, backend):
        super().__init__("🛰  Team Monitor", iface.mainWindow())
        self.setObjectName("VelocityNexusTeamMonitor")
        self.iface = iface
        self.admin = admin_mod.Admin(backend)
        self.dry_run = backend.dry_run
        self._build()
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.refresh)
        self._timer.start(30_000)
        self.refresh()

    # ── UI ──────────────────────────────────────────────────────────────────
    def _build(self):
        root = QWidget()
        root.setStyleSheet(
            "QWidget{background:#0F1A30;color:#EAF0FF;}"
            "QTabWidget::pane{border:1px solid #243352;}"
            "QTabBar::tab{background:#141E36;color:#9FB4C8;padding:6px 12px;"
            "border:1px solid #243352;}"
            "QTabBar::tab:selected{background:#1F2C4C;color:#fff;}"
            "QTableWidget{background:#0F1A30;gridline-color:#243352;"
            "color:#EAF0FF;}"
            "QHeaderView::section{background:#141E36;color:#9FB4C8;"
            "border:0;padding:4px;}"
            "QPushButton{background:#2ec4f1;color:#06121c;border:none;"
            "border-radius:6px;padding:6px 12px;font-weight:700;}"
            "QPushButton:hover{background:#5fd6ff;}"
            "QLabel#status{color:#9FB4C8;font-size:10px;}"
            "QLabel#kpi{background:#141E36;border:1px solid #243352;"
            "border-radius:7px;padding:8px 11px;font-size:12px;}"
            # hero health banner — border colour tracks state
            "QFrame#healthBanner{background:#141E36;border:2px solid #2ABFCC;"
            "border-radius:8px;}"
            "QFrame#healthBanner[state=\"warn\"]{border:2px solid #E0B23B;}"
            "QFrame#healthBanner[state=\"error\"]{border:2px solid #E0607A;}"
            "QLabel#healthTitle{font-size:13px;font-weight:800;color:#EAF0FF;}"
            "QLabel#healthDetail{font-size:10px;color:#9FB4C8;}"
            # 4-card KPI strip
            "QFrame#kpiCard{background:#141E36;border:1px solid #243352;"
            "border-radius:7px;}"
            "QFrame#kpiCard:hover{border:1px solid #2EC4F1;}"
            "QLabel#kpiCap{font-size:9px;font-weight:700;color:#6E7FA6;}")
        v = QVBoxLayout(root)
        v.setContentsMargins(8, 8, 8, 8)
        v.setSpacing(6)

        topbar = QHBoxLayout()
        self._status = QLabel("…")
        self._status.setObjectName("status")
        topbar.addWidget(self._status)
        topbar.addStretch(1)
        announce = QPushButton("📢  Announce")
        announce.clicked.connect(self._announce)
        topbar.addWidget(announce)
        refresh = QPushButton("⟳")
        refresh.setFixedWidth(34)
        refresh.clicked.connect(self.refresh)
        topbar.addWidget(refresh)
        v.addLayout(topbar)

        # Hero health banner + 4-card KPI strip — scannable at a glance
        self._banner = _HealthBanner()
        v.addWidget(self._banner)

        kpi_row = QHBoxLayout()
        kpi_row.setSpacing(8)
        self._kpi_online   = _KPICard("ONLINE")
        self._kpi_machines = _KPICard("MACHINES")
        self._kpi_errors   = _KPICard("OPEN ERRORS")
        self._kpi_latest   = _KPICard("LATEST")
        for c in (self._kpi_online, self._kpi_machines,
                  self._kpi_errors, self._kpi_latest):
            kpi_row.addWidget(c)
        v.addLayout(kpi_row)
        self._kpi = {"online": 0, "installs": 0, "errors_open": 0,
                     "latest": None, "stale": 0}

        self.tabs = QTabWidget()
        self.t_online = self._table(["", "User", "Project", "Tool", "Seen"])
        self.t_activity = self._table(["Time", "User", "Action", "Project"])
        self.t_errors = self._table(["Last seen", "Error", "×", "Who", ""])
        self.t_installs = self._table(["User", "First version", "QGIS",
                                       "Installed"])
        self.t_users = self._table(["User", "Active", "Since", ""])
        self.t_tickets = self._table(["When", "Type", "Title", "Who", ""])
        self.tabs.addTab(self.t_online, "● Online")
        self.tabs.addTab(self.t_activity, "Activity")
        self.tabs.addTab(self.t_tickets, "Tickets")
        self.tabs.addTab(self.t_errors, "Errors")
        self.tabs.addTab(self.t_installs, "Installs")
        self.tabs.addTab(self.t_users, "Users")
        v.addWidget(self.tabs)
        self.setWidget(root)

    def _table(self, headers):
        t = QTableWidget(0, len(headers))
        t.setHorizontalHeaderLabels(headers)
        t.verticalHeader().setVisible(False)
        t.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        t.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        t.horizontalHeader().setStretchLastSection(True)
        return t

    # ── refresh ─────────────────────────────────────────────────────────────
    def refresh(self):
        if self.dry_run:
            self._status.setText(
                "Dry-run mode — backend not configured yet. Live data appears "
                "once Supabase is connected.")
            return
        self._status.setText("Refreshing…")
        # housekeeping: prune aged presence heartbeats (throttled to ~5 min) so
        # the events table stays small under the free tier.
        now = time.time()
        if now - getattr(self, "_last_prune", 0) > 300:
            self._last_prune = now
            self.admin.prune_heartbeats()
        # events first → cache latest action per user → then online (so the
        # Online tab can show each person's current project/tool from events).
        self.admin.recent_events(self._on_events)
        self.admin.recent_errors(self._fill_errors)
        self.admin.installs(self._fill_installs)
        self.admin.users(self._fill_users)
        self.admin.tickets(self._fill_tickets)

    def _on_events(self, rows):
        rows = rows or []
        self._fill_activity(rows)
        latest = {}
        for r in rows:                      # rows are inserted_at desc → 1st wins
            u = r.get("username")
            if u and u not in latest:
                latest[u] = r
        self._latest_by_user = latest
        self.admin.online_now(self._fill_online)

    def _set_rows(self, table, rows, render, empty_msg=None):
        table.setRowCount(0)
        rows = rows or []
        if not rows and empty_msg:
            table.insertRow(0)
            it = QTableWidgetItem("   " + empty_msg)
            it.setForeground(_qcolor("#6E7FA6"))
            table.setItem(0, 0, it)
            table.setSpan(0, 0, 1, table.columnCount())
            return
        for r in rows:
            i = table.rowCount()
            table.insertRow(i)
            render(table, i, r)

    def _update_summary(self):
        """Drive the hero banner + 4 KPI cards from the latest fetched counts."""
        k = self._kpi
        # Hero banner — overall team health, worst-state-wins
        if k["errors_open"] > 0:
            self._banner.set_state(
                "error", "Needs attention",
                f"{k['errors_open']} open error"
                f"{'s' if k['errors_open'] != 1 else ''} · "
                f"updated {time.strftime('%H:%M')}")
        elif k["stale"] > 0:
            self._banner.set_state(
                "warn", "Needs a look",
                f"{k['stale']} machine{'s' if k['stale'] != 1 else ''} on an "
                f"old version · updated {time.strftime('%H:%M')}")
        else:
            self._banner.set_state(
                "ok", "All good",
                f"No open errors · all up to date · "
                f"updated {time.strftime('%H:%M')}")
        # KPI cards — colour tracks state so the row reads at a glance
        self._kpi_online.set_value(
            k["online"], "#2ABFCC" if k["online"] else "#6E7FA6")
        self._kpi_machines.set_value(k["installs"], "#EAF0FF")
        self._kpi_errors.set_value(
            k["errors_open"],
            "#E0607A" if k["errors_open"] >= 5 else
            "#E0B23B" if k["errors_open"] else "#2ABFCC")
        self._kpi_latest.set_value(
            f"v{k['latest']}" if k["latest"] else "—",
            "#E0B23B" if k["stale"] else "#2ABFCC")

    def _fill_online(self, rows):
        latest = getattr(self, "_latest_by_user", {})
        # rows = '__heartbeat__' events (inserted_at desc) → first per user = newest
        seen = {}
        for r in (rows or []):
            u = r.get("username")
            if u and u not in seen:
                seen[u] = r
        online = [r for r in seen.values()
                  if _is_online(r.get("inserted_at", ""))]
        self._status.setText(
            f"{len(online)} online · updated {time.strftime('%H:%M')}")

        def _vt(v):
            try:
                return tuple(int(x) for x in str(v).split("."))
            except Exception:
                return ()
        vers = [r.get("plugin_version") for r in online if r.get("plugin_version")]
        lat = max(vers, key=_vt) if vers else self._kpi.get("latest")
        self._kpi["online"] = len(online)
        if lat:
            self._kpi["latest"] = lat
            self._kpi["stale"] = sum(1 for v in vers if _vt(v) < _vt(lat))
        self._update_summary()

        def render(t, i, r):
            u = r.get("username", "")
            ev = latest.get(u, {})
            dot = QTableWidgetItem("●")
            dot.setForeground(_qcolor("#2ABFCC"))
            t.setItem(i, 0, dot)
            t.setItem(i, 1, QTableWidgetItem(u))
            t.setItem(i, 2, QTableWidgetItem(
                ev.get("project_name") or r.get("project_name") or "—"))
            t.setItem(i, 3, QTableWidgetItem(ev.get("action_id") or "—"))
            t.setItem(i, 4, QTableWidgetItem(_age(r.get("inserted_at", ""))))
        self._set_rows(self.t_online, online, render,
                       empty_msg="No one is online right now.")

    def _fill_activity(self, rows):
        def render(t, i, r):
            t.setItem(i, 0, QTableWidgetItem(_age(r.get("inserted_at", ""))))
            t.setItem(i, 1, QTableWidgetItem(r.get("username", "")))
            t.setItem(i, 2, QTableWidgetItem(r.get("action_id", "")))
            t.setItem(i, 3, QTableWidgetItem(r.get("project_name") or "—"))
        self._set_rows(self.t_activity, rows, render,
                       empty_msg="No tool activity recorded yet.")

    def _fill_errors(self, rows):
        rows = rows or []
        self._kpi["errors_open"] = sum(1 for r in rows if not r.get("resolved"))
        self._update_summary()
        # Group identical messages → signal, not a flat wall of repeats.
        groups = {}
        for r in rows:                       # rows are inserted_at desc
            key = (r.get("error_message") or "")[:160]
            g = groups.setdefault(key, {"rows": [], "users": set()})
            g["rows"].append(r)
            if r.get("username"):
                g["users"].add(r.get("username"))
        ordered = list(groups.values())

        def render(t, i, g):
            latest = g["rows"][0]
            t.setItem(i, 0, QTableWidgetItem(_age(latest.get("inserted_at", ""))))
            msg = QTableWidgetItem(latest.get("error_message", ""))
            if all(rr.get("resolved") for rr in g["rows"]):
                msg.setForeground(_qcolor("#5E6E92"))
            t.setItem(i, 1, msg)
            t.setItem(i, 2, QTableWidgetItem(str(len(g["rows"]))))
            t.setItem(i, 3, QTableWidgetItem(", ".join(sorted(g["users"])) or "—"))
            btn = QPushButton("Details")
            btn.clicked.connect(lambda _=False, row=latest: self._error_detail(row))
            t.setCellWidget(i, 4, btn)
        self._set_rows(self.t_errors, ordered, render,
                       empty_msg="No errors reported 🎉")

    def _fill_installs(self, rows):
        rows = rows or []
        self._kpi["installs"] = len(rows)
        self._update_summary()

        def render(t, i, r):
            t.setItem(i, 0, QTableWidgetItem(r.get("username") or "—"))
            t.setItem(i, 1, QTableWidgetItem("v" + str(r.get("plugin_version", ""))))
            t.setItem(i, 2, QTableWidgetItem(r.get("qgis_version") or "—"))
            t.setItem(i, 3, QTableWidgetItem(_age(r.get("created_at", ""))))
        self._set_rows(self.t_installs, rows, render,
                       empty_msg="No machines have checked in yet.")

    def _fill_users(self, rows):
        def render(t, i, r):
            t.setItem(i, 0, QTableWidgetItem(r.get("username", "")))
            act = QTableWidgetItem("yes" if r.get("is_active") else "NO")
            act.setForeground(_qcolor("#2ABFCC" if r.get("is_active")
                                      else "#E0607A"))
            t.setItem(i, 1, act)
            t.setItem(i, 2, QTableWidgetItem(_age(r.get("created_at", ""))))
            w = QWidget()
            h = QHBoxLayout(w)
            h.setContentsMargins(0, 0, 0, 0)
            tok = QPushButton("Reset token")
            tok.clicked.connect(lambda _=False, u=r.get("username"):
                                self._reset_token(u))
            deact = QPushButton("Deactivate" if r.get("is_active") else "Enable")
            deact.clicked.connect(
                lambda _=False, u=r.get("username"), a=r.get("is_active"):
                self._toggle_active(u, not a))
            h.addWidget(tok)
            h.addWidget(deact)
            t.setCellWidget(i, 3, w)
        self._set_rows(self.t_users, rows, render,
                       empty_msg="No teammates registered yet — share the "
                                 "repo link + team code so they can sign in.")

    def _fill_tickets(self, rows):
        rows = rows or []
        open_n = sum(1 for r in rows if r.get("status") != "done")
        try:
            idx = self.tabs.indexOf(self.t_tickets)
            self.tabs.setTabText(idx, f"Tickets ({open_n})" if open_n else "Tickets")
        except Exception:
            pass

        def render(t, i, r):
            done = (r.get("status") == "done")
            t.setItem(i, 0, QTableWidgetItem(_age(r.get("created_at", ""))))
            t.setItem(i, 1, QTableWidgetItem("🐞 Bug" if r.get("kind") == "bug"
                                             else "💡 Feature"))
            title = QTableWidgetItem(r.get("title", ""))
            if done:
                title.setForeground(_qcolor("#5E6E92"))
            t.setItem(i, 2, title)
            t.setItem(i, 3, QTableWidgetItem(
                r.get("display_name") or r.get("username") or "—"))
            w = QWidget()
            h = QHBoxLayout(w)
            h.setContentsMargins(0, 0, 0, 0)
            view = QPushButton("View")
            view.clicked.connect(lambda _=False, row=r: self._ticket_detail(row))
            h.addWidget(view)
            if not done:
                dn = QPushButton("Resolve")
                dn.setToolTip("Mark fixed in the current version — the person who "
                              "logged it is notified to update (or that it's fixed).")
                dn.clicked.connect(lambda _=False, tid=r.get("id"):
                                   self._ticket_resolve(tid))
                h.addWidget(dn)
            t.setCellWidget(i, 4, w)
        self._set_rows(self.t_tickets, rows, render,
                       empty_msg="No tickets yet — teammates' bug reports & feature "
                                 "requests (red 🎫 button) will appear here.")

    def _ticket_detail(self, r):
        kind = "Bug report" if r.get("kind") == "bug" else "Feature request"
        text = (f"{kind}\n\nTitle: {r.get('title')}\n\n"
                f"{r.get('body') or '(no details given)'}\n\n"
                f"From: {r.get('display_name') or r.get('username') or '—'}\n"
                f"When: {r.get('created_at')}\n"
                f"Plugin v{r.get('plugin_version')} · QGIS {r.get('qgis_version')}\n"
                f"Project: {r.get('project_name') or '—'}")
        box = QMessageBox(self)
        box.setWindowTitle("Ticket")
        box.setText(text)
        done_btn = (box.addButton("Resolve (fixed)", QMessageBox.ButtonRole.AcceptRole)
                    if r.get("status") != "done" else None)
        box.addButton(QMessageBox.StandardButton.Close)
        box.exec()
        if done_btn is not None and box.clickedButton() is done_btn and r.get("id"):
            self._ticket_resolve(r["id"])

    def _ticket_done(self, ticket_id):
        if ticket_id is not None:
            self.admin.mark_ticket_done(ticket_id, True, lambda ok: self.refresh())

    def _ticket_resolve(self, ticket_id):
        """Resolve + tag the current plugin version → notifies the reporter."""
        if ticket_id is None:
            return
        ver = getattr(getattr(self.admin, "backend", None), "version", None) or "?"
        self.admin.resolve_ticket(ticket_id, ver, lambda ok: self.refresh())

    # ── owner actions ───────────────────────────────────────────────────────
    def _error_detail(self, r):
        bc = r.get("breadcrumbs") or []
        trail = "\n".join(f"  • {c.get('action_id')} "
                          f"({c.get('category')})" for c in bc) or "  (none)"
        text = (f"User: {r.get('username')}\n"
                f"When: {r.get('inserted_at')}\n"
                f"Project: {r.get('project_name') or '—'}\n"
                f"Tool: {r.get('active_tool') or '—'}\n"
                f"Plugin v{r.get('plugin_version')} · QGIS "
                f"{r.get('qgis_version')}\n\n"
                f"Error: {r.get('error_message')}\n\n"
                f"What they were doing (breadcrumbs):\n{trail}\n\n"
                f"Note from user: {r.get('user_note') or '—'}\n\n"
                f"--- traceback ---\n{r.get('error_traceback') or ''}")
        box = QMessageBox(self)
        box.setWindowTitle("Error details")
        box.setText(text)
        resolve = box.addButton("Mark resolved", QMessageBox.ButtonRole.AcceptRole)
        box.addButton(QMessageBox.StandardButton.Close)
        box.exec()
        if box.clickedButton() is resolve and r.get("error_id"):
            self.admin.mark_error_resolved(
                r["error_id"], True, lambda ok: self.refresh())

    def _reset_token(self, username):
        def done(token):
            if token:
                QMessageBox.information(
                    self, "Reset token",
                    f"Give {username} this one-time code (valid 1 hour):\n\n"
                    f"    {token}\n\nThey enter it with a new password to "
                    "regain access.")
            else:
                QMessageBox.warning(self, "Reset token",
                                    "Could not issue a token (offline?).")
        self.admin.issue_reset_token(username, cb=done)

    def _toggle_active(self, username, active):
        verb = "enable" if active else "deactivate"
        if QMessageBox.question(
                self, "Confirm",
                f"{verb.capitalize()} {username}?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
            return
        self.admin.deactivate(username, active, lambda ok: self.refresh())

    def _announce(self):
        title, ok = QInputDialog.getText(self, "Announce", "Title:")
        if not ok or not title.strip():
            return
        msg, ok = QInputDialog.getText(self, "Announce", "Message:")
        if not ok or not msg.strip():
            return
        self.admin.announce(
            title.strip(), msg.strip(),
            cb=lambda ok2: QMessageBox.information(
                self, "Announce",
                "Sent to everyone." if ok2 else "Failed (offline?)."))

    def closeEvent(self, event):
        try:
            self._timer.stop()
            self._timer.deleteLater()
        except Exception:
            pass
        super().closeEvent(event)


def _qcolor(hexv):
    from qgis.PyQt.QtGui import QColor
    return QColor(hexv)


class _KPICard(QFrame):
    """Compact metric tile: big value over a small caption. Colour is set
    dynamically per state by set_value()."""

    def __init__(self, caption, parent=None):
        super().__init__(parent)
        self.setObjectName("kpiCard")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 9, 12, 9)
        lay.setSpacing(2)
        self._val = QLabel("—")
        self._val.setStyleSheet("font-size:22px;font-weight:800;color:#2ABFCC;")
        cap = QLabel(caption)
        cap.setObjectName("kpiCap")
        lay.addWidget(self._val)
        lay.addWidget(cap)

    def set_value(self, val, colour="#2ABFCC"):
        self._val.setText(str(val))
        self._val.setStyleSheet(
            f"font-size:22px;font-weight:800;color:{colour};")


class _HealthBanner(QFrame):
    """Hero strip: an at-a-glance team-health verdict. Border colour tracks
    the state property (ok=cyan / warn=amber / error=red) via the dock QSS."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("healthBanner")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 8, 14, 8)
        lay.setSpacing(1)
        self._title = QLabel("Loading…")
        self._title.setObjectName("healthTitle")
        self._detail = QLabel("")
        self._detail.setObjectName("healthDetail")
        lay.addWidget(self._title)
        lay.addWidget(self._detail)

    def set_state(self, state, title, detail):
        icon = {"ok": "✅", "warn": "⚠", "error": "⛔"}.get(state, "")
        self._title.setText(f"{icon}  {title}")
        self._detail.setText(detail)
        self.setProperty("state", state)
        # re-evaluate the property-based QSS selector
        self.style().unpolish(self)
        self.style().polish(self)
