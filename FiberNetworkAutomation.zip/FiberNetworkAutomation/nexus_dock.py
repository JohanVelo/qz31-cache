"""nexus_dock — IDE-style dockable Velocity Nexus tools (pyqtgraph.dockarea, MIT).

Replaces the rejected in-panel reorder. Each tool group becomes a floatable / tabbable
/ re-dockable ``Dock`` inside a ``DockArea``; the layout saves to QgsSettings and
restores across restarts. Qt6-safe (qgis.PyQt shim, scoped enums, no ``.exec_()``).

Fail-open by contract: the caller wraps ``build_dockarea`` in try/except and falls back
to today's static panel if anything here raises (flag ``VF_NO_DOCK=1`` forces the
fallback). Nothing here changes any tool's behaviour — it only re-hosts the widgets.
"""
from qgis.PyQt.QtCore import QByteArray
from qgis.PyQt.QtWidgets import QWidget

try:                                    # bundled: relative inside the plugin package
    from .vendor.dockarea import DockArea, Dock
except ImportError:                     # headless / test: plugin dir on sys.path
    from vendor.dockarea import DockArea, Dock

_SETTINGS_KEY = "VelocityNexus/dock_layout_v1"


def build_dockarea(groups, first_edge="left"):
    """Build a DockArea from ``groups`` = [(title, content_widget), ...].

    Each group's ``content_widget`` is placed in its own Dock. The first Dock docks to
    ``first_edge``; each subsequent Dock stacks BELOW the previous (a vertical tool
    column by default — the operator then drags to float/tab/redock). Returns
    (area, {title: dock}). Never raises on an individual group — a bad group is skipped.
    """
    area = DockArea()
    docks = {}
    prev = None
    for title, widget in groups:
        try:
            # autoOrientation=False → title bars stay HORIZONTAL (card headers on top),
            # not the rotated side-labels pyqtgraph uses for tall docks.
            d = Dock(title, closable=True, autoOrientation=False)
            if widget is not None:
                d.addWidget(widget)
            if prev is None:
                area.addDock(d, first_edge)
            else:
                area.addDock(d, "bottom", prev)
            docks[title] = d
            prev = d
        except Exception:
            continue
    return area, docks


# Velocity Nexus design tokens (the 'velocity' theme from velocity_home_panel).
THEME = {
    "bg": "#05070C", "cell": "#0D1320", "cell_hover": "#131D2E",
    "cell_press": "#0A1622", "hairline": "#1B2940", "cyan": "#1AE5FF",
    "text": "#C9DDF2", "text_hi": "#EAF3FF", "muted": "#7E93B8",
}

# One cascading stylesheet on the DockArea → styles the whole tool surface to match
# the Velocity Nexus console (near-black body, console-cell buttons, cyan hover,
# hairline borders, muted section labels). The DockLabel title bars are styled
# separately in the vendored updateStyle (they set their own sheet). objectNames:
# body = NexusDockBody · buttons = NexusTool · group caption = NexusGroupTitle.
NEXUS_QSS = """
DockArea, Container {{ background: {bg}; }}
QSplitter::handle {{ background: {bg}; }}
QSplitter::handle:hover {{ background: {cyan}; }}
QSplitter::handle:horizontal {{ width: 6px; }}
QSplitter::handle:vertical {{ height: 6px; }}
QWidget#NexusDockBody {{ background: {bg}; }}
QLabel#NexusGroupTitle {{
    color: {muted}; font-family: 'Chakra Petch','Segoe UI',sans-serif;
    font-size: 10px; font-weight: bold; letter-spacing: 1px;
    padding: 2px 2px 6px 2px;
}}
QPushButton#NexusTool {{
    background: {cell}; color: {text};
    border: 1px solid {hairline}; border-radius: 6px;
    padding: 9px 12px; font-family: 'Chakra Petch','Segoe UI',sans-serif;
    font-size: 12px; text-align: center;
}}
QPushButton#NexusTool:hover {{
    background: {cell_hover}; border: 1px solid {cyan}; color: {text_hi};
}}
QPushButton#NexusTool:pressed {{ background: {cell_press}; }}
QToolButton#WinClose, QPushButton#WinClose {{
    background: transparent; border: none; color: {muted};
    font-size: 13px; font-weight: bold; padding: 2px 9px;
}}
QToolButton#WinClose:hover, QPushButton#WinClose:hover {{
    background: #E81123; color: #ffffff;
}}
QToolButton#WinClose:pressed, QPushButton#WinClose:pressed {{
    background: #C50F1F; color: #ffffff;
}}
""".format(**THEME)


def style_windows_close(btn, on_close=None, tooltip="Close"):
    """Make any button behave + look like the Windows title-bar close button:
    a crisp ✕ that turns a red block with a white ✕ on hover, 'Close' tooltip, and
    closes on click. Reusable across the whole Nexus plugin. Fail-open — a styling
    hiccup never breaks the button. ``on_close`` is optional (dock close buttons are
    already wired to close themselves; pass it for plain buttons that aren't)."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtGui import QIcon
    try:
        btn.setObjectName("WinClose")
        btn.setToolTip(tooltip)
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        if hasattr(btn, "setToolButtonStyle"):
            btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
        btn.setIcon(QIcon())          # drop the stock grey glyph → crisp themed ✕
        btn.setText("✕")
        # SELF-CONTAINED stylesheet so the button looks right in ANY panel/dialog
        # regardless of its ancestor QSS (transparent → red block + white ✕ on hover).
        btn.setStyleSheet(
            "QToolButton, QPushButton {"
            " background: transparent; border: none; color: #8AA0BE;"
            " font-size: 15px; font-weight: bold; padding: 2px 8px; border-radius: 3px; }"
            "QToolButton:hover, QPushButton:hover { background: #E81123; color: #ffffff; }"
            "QToolButton:pressed, QPushButton:pressed { background: #C50F1F; color: #ffffff; }")
        if on_close is not None:
            btn.clicked.connect(on_close)
    except Exception:
        pass
    return btn


# Velocity Nexus chrome for a QDockWidget: a CUSTOM title bar (setTitleBarWidget) that
# gives every dock the clean, flat Windows/QGIS window controls — minimise · maximise ·
# close — instead of the native dock's float/close pair (which can't show a minimise).
# When the panel is DOCKED it wears this flat bar; when it FLOATS it gets a real OS
# window frame (native min/max/close + resize + taskbar), which is exactly the QGIS
# application look. One reusable bar; painted onto every dock via ``apply_dock_chrome``.
def _titlebar_qss():
    return """
QWidget#VfDockTitle {{
    background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #0B1019, stop:1 #070A11);
    border-bottom: 2px solid {cyan};
}}
QLabel#VfDockTitleText {{
    color: {text_hi}; font-family: 'Chakra Petch','Segoe UI',sans-serif;
    font-size: 12px; font-weight: bold; padding-left: 10px; background: transparent;
}}
QToolButton#VfCap, QToolButton#VfCapClose {{
    background: transparent; border: none; color: {muted};
    font-family: 'Segoe UI','Chakra Petch',sans-serif;
    font-size: 14px; font-weight: bold; padding: 0; margin: 0;
}}
QToolButton#VfCap:hover {{ background: {cell_hover}; color: {text_hi}; }}
QToolButton#VfCap:pressed {{ background: {cell_press}; }}
QToolButton#VfCapClose:hover {{ background: #E81123; color: #ffffff; }}
QToolButton#VfCapClose:pressed {{ background: #C50F1F; color: #ffffff; }}
""".format(**THEME)


def _widget_size_max():
    """Qt's 'no maximum' sentinel — used to release a rolled-up dock's height cap."""
    try:
        from qgis.PyQt.QtWidgets import QWIDGETSIZE_MAX
        return QWIDGETSIZE_MAX
    except Exception:
        return 16777215


class _VelocityDockTitleBar(QWidget):
    """Flat, Windows-style title bar for a QDockWidget — heading + minimise · maximise ·
    close caption buttons (thin grey glyphs; close turns a red block on hover, just like
    the OS caption bar).

    Behaviour (JJ's pick, 2026-07-22 — 'roll-up + fill screen'):
      • minimise — docked: roll the panel up to just this bar (click again restores);
                   floating: the real OS frame handles minimise-to-taskbar.
      • maximise — docked: float the panel and fill the screen; floating: toggle
                   maximise / restore.
      • close    — close the dock.
    Draggable to tear the panel off into a floating window; double-click toggles
    float/dock. Fail-open, Qt6-safe, idempotent."""

    def __init__(self, dock):
        from qgis.PyQt.QtWidgets import QHBoxLayout, QLabel
        super().__init__(dock)
        self._dock = dock
        self._rolled = False
        self._roll_max = None
        self._drag_from = None
        self.setObjectName("VfDockTitle")
        self.setFixedHeight(30)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        self._title = QLabel(dock.windowTitle() or "Velocity Nexus")
        self._title.setObjectName("VfDockTitleText")
        lay.addWidget(self._title)
        lay.addStretch(1)
        self._btn_min = self._cap("–", "VfCap", self._on_min, "Minimise")
        self._btn_max = self._cap("□", "VfCap", self._on_max, "Maximise")
        self._btn_close = self._cap("✕", "VfCapClose", self._on_close, "Close")
        for b in (self._btn_min, self._btn_max, self._btn_close):
            lay.addWidget(b)
        self.setStyleSheet(_titlebar_qss())
        try:                                    # keep the heading live if renamed
            dock.windowTitleChanged.connect(self._title.setText)
        except Exception:
            pass

    def _cap(self, glyph, oname, slot, tip):
        from qgis.PyQt.QtWidgets import QToolButton
        from qgis.PyQt.QtCore import Qt
        b = QToolButton(self)
        b.setObjectName(oname)
        b.setText(glyph)
        b.setToolTip(tip)
        b.setFixedSize(42, 28)
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.clicked.connect(slot)
        return b

    # ── caption actions ──────────────────────────────────────────────────────
    def _on_close(self):
        try:
            self._dock.close()
        except Exception:
            pass

    def _on_max(self):
        d = self._dock
        try:
            if d.isFloating():
                (d.showNormal if d.isMaximized() else d.showMaximized)()
            else:
                d.setFloating(True)                 # → OS frame via topLevelChanged
                from qgis.PyQt.QtCore import QTimer  # let the float settle, then fill
                QTimer.singleShot(0, self._safe_maximize)
        except Exception:
            pass

    def _safe_maximize(self):
        try:
            from qgis.PyQt import sip
            if not sip.isdeleted(self._dock) and self._dock.isFloating():
                self._dock.showMaximized()
        except Exception:
            pass

    def _on_min(self):
        d = self._dock
        try:
            if d.isFloating():
                d.showMinimized()
            else:
                self._toggle_rollup()
        except Exception:
            pass

    def _toggle_rollup(self):
        d = self._dock
        w = d.widget()
        if self._rolled:
            if w is not None:
                w.setVisible(True)
            d.setMaximumHeight(self._roll_max or _widget_size_max())
            self._rolled = False
            self._btn_min.setToolTip("Minimise")
        else:
            self._roll_max = d.maximumHeight()
            if w is not None:
                w.setVisible(False)
            d.setMaximumHeight(self.height())
            self._rolled = True
            self._btn_min.setToolTip("Restore")

    # ── drag to tear off / double-click to toggle dock ───────────────────────
    def mousePressEvent(self, e):
        from qgis.PyQt.QtCore import Qt
        try:
            if e.button() == Qt.MouseButton.LeftButton:
                self._drag_from = e.globalPosition().toPoint()
        except Exception:
            self._drag_from = None
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        from qgis.PyQt.QtCore import Qt
        try:
            if (self._drag_from is not None
                    and (e.buttons() & Qt.MouseButton.LeftButton)
                    and not self._dock.isFloating()):
                now = e.globalPosition().toPoint()
                if (now - self._drag_from).manhattanLength() > 12:
                    self._drag_from = None
                    self._dock.setFloating(True)
        except Exception:
            pass
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        self._drag_from = None
        super().mouseReleaseEvent(e)

    def mouseDoubleClickEvent(self, e):
        try:
            self._dock.setFloating(not self._dock.isFloating())
        except Exception:
            pass
        super().mouseDoubleClickEvent(e)


def _apply_os_frame(dock, floating):
    """Give a FLOATING dock a real OS window frame (native minimise / maximise / close +
    resize + taskbar) — the QGIS-application look. No-op when docked."""
    if not floating:
        return
    try:
        from qgis.PyQt import sip
        from qgis.PyQt.QtCore import Qt
        if dock is None or sip.isdeleted(dock):
            return
        if getattr(dock, "_vf_os_frame_active", False):
            return
        dock._vf_os_frame_active = True
        dock.setWindowFlags(Qt.WindowType.Window
                            | Qt.WindowType.WindowMinimizeButtonHint
                            | Qt.WindowType.WindowMaximizeButtonHint
                            | Qt.WindowType.WindowCloseButtonHint)
        dock.show()                     # changing flags hides a top-level → re-show
        dock._vf_os_frame_applied = True
    except Exception:
        pass
    finally:
        try:
            if dock is not None:
                dock._vf_os_frame_active = False
        except Exception:
            pass


def _schedule_os_frame(dock, floating):
    """Apply the native frame after the float event has unwound.

    The timer belongs to the dock, so deleting the dock during hot reload also
    cancels the callback.
    """
    if not floating:
        return
    try:
        from qgis.PyQt import sip
        from qgis.PyQt.QtCore import QTimer
        if dock is None or sip.isdeleted(dock):
            return
        if getattr(dock, "_vf_os_frame_applied", False):
            return
        timer = getattr(dock, "_vf_os_frame_timer", None)
        if timer is None or sip.isdeleted(timer):
            timer = QTimer(dock)
            timer.setSingleShot(True)
            timer.timeout.connect(lambda d=dock: _apply_os_frame(d, True))
            dock._vf_os_frame_timer = timer
        timer.start(0)
    except Exception:
        pass


def _on_dock_toplevel(dock, floating):
    """Swap chrome on float/dock: docked wears the flat Velocity bar; floating wears the
    native OS frame (so it never shows two title bars)."""
    try:
        from qgis.PyQt import sip
        bar = getattr(dock, "_vf_titlebar", None)
        if floating:
            dock.setTitleBarWidget(None)        # OS frame supplies the caption buttons
            _schedule_os_frame(dock, True)
        elif bar is not None and not sip.isdeleted(bar):
            dock._vf_os_frame_applied = False
            dock.setTitleBarWidget(bar)         # flat Velocity bar back on re-dock
    except Exception:
        pass


_DOCK_WHITELIST = ("velocity", "nexus", "erven", "team monitor", "teammonitor",
                   "label", "splice", "pole editor", "enclosure", "bridge", "velogis",
                   "ftth", "network planner", "planner")


def _is_velocity_dock(d):
    s = ((d.objectName() or "") + " " + (d.windowTitle() or "") + " "
         + d.__class__.__name__).lower()
    return any(k in s for k in _DOCK_WHITELIST)


def chrome_all_velocity_docks(main_window):
    """Chrome EVERY Velocity dock currently in the main window (idempotent, fail-open).
    Skips QGIS's own docks via the whitelist."""
    try:
        from qgis.PyQt.QtWidgets import QDockWidget
        for d in main_window.findChildren(QDockWidget):
            if _is_velocity_dock(d):
                apply_dock_chrome(d)
    except Exception:
        pass


def uninstall_dock_chrome_watcher(main_window, watcher=None):
    """Remove all Velocity dock watchers, including leaked older instances."""
    try:
        from qgis.PyQt import sip
        from qgis.PyQt.QtCore import QObject
        candidates = []
        for obj in (watcher, getattr(main_window, "_vf_dock_chrome_watcher", None)):
            if obj is not None:
                candidates.append(obj)
        candidates.extend(
            obj for obj in main_window.findChildren(QObject)
            if obj.__class__.__name__ == "_DockWatcher")
        seen = set()
        for obj in candidates:
            if id(obj) in seen or sip.isdeleted(obj):
                continue
            seen.add(id(obj))
            try:
                if hasattr(obj, "shutdown"):
                    obj.shutdown()
                else:
                    main_window.removeEventFilter(obj)
            except Exception:
                pass
            try:
                obj.deleteLater()
            except Exception:
                pass
        main_window._vf_dock_chrome_watcher = None
        return len(seen)
    except Exception:
        return 0


def install_dock_chrome_watcher(main_window):
    """Persistently chrome every Velocity dock — now AND whenever one opens later —
    so a dock class we didn't individually edit still gets the bright ✕/float title.

    Lightweight: only reacts to a QDockWidget being ADDED (rare), never a general
    loop. Filters to Velocity docks so QGIS's own panels are untouched. Idempotent +
    fail-open. Returns the watcher (keep a ref so it isn't GC'd)."""
    try:
        from qgis.PyQt import sip
        from qgis.PyQt.QtCore import QObject, QEvent, QTimer

        existing = getattr(main_window, "_vf_dock_chrome_watcher", None)
        if (existing is not None and not sip.isdeleted(existing)
                and hasattr(existing, "schedule")):
            existing.schedule(0)
            return existing

        uninstall_dock_chrome_watcher(main_window)

        class _DockWatcher(QObject):
            def __init__(self, parent):
                super().__init__(parent)
                self._main_window = parent
                self._timer = QTimer(self)
                self._timer.setSingleShot(True)
                self._timer.timeout.connect(self.sweep)
                parent.installEventFilter(self)

            def schedule(self, delay=60):
                if not self._timer.isActive() or delay == 0:
                    self._timer.start(max(0, int(delay)))

            def sweep(self):
                try:
                    if not sip.isdeleted(self._main_window):
                        chrome_all_velocity_docks(self._main_window)
                except Exception:
                    pass

            def shutdown(self):
                try:
                    self._timer.stop()
                    self._timer.timeout.disconnect(self.sweep)
                except Exception:
                    pass
                try:
                    if not sip.isdeleted(self._main_window):
                        self._main_window.removeEventFilter(self)
                except Exception:
                    pass

            def eventFilter(self, obj, ev):
                try:
                    # a dock/toolbar/etc. was added to the main window → after it's
                    # built, sweep + chrome any Velocity dock (idempotent + cheap, so
                    # re-running is free; a full sweep is far more reliable than trying
                    # to target the specific child, which can be an intermediate).
                    if ev.type() == QEvent.Type.ChildAdded:
                        c = ev.child()
                        if c is not None and getattr(c, "isWidgetType", lambda: False)():
                            self.schedule(60)
                except Exception:
                    pass
                return False

        w = _DockWatcher(main_window)
        main_window._vf_dock_chrome_watcher = w
        w.sweep()                                   # catch everything already open
        return w
    except Exception:
        return None


def apply_dock_chrome(dock):
    """Give a QDockWidget the flat Velocity title bar with Windows/QGIS-style window
    controls — minimise · maximise · close (see ``_VelocityDockTitleBar``). Docked =
    flat bar; floating = real OS frame. Keeps native float/resize. Idempotent (a dock
    is chromed once, guarded by ``_vf_titlebar``). Fail-open. Returns the dock."""
    try:
        from qgis.PyQt.QtWidgets import QDockWidget as _QDW
        dock.setFeatures(_QDW.DockWidgetFeature.DockWidgetClosable
                         | _QDW.DockWidgetFeature.DockWidgetMovable
                         | _QDW.DockWidgetFeature.DockWidgetFloatable)
    except Exception:
        pass
    try:
        if getattr(dock, "_vf_titlebar", None) is not None:   # already chromed
            return dock
        bar = _VelocityDockTitleBar(dock)
        dock._vf_titlebar = bar
        if dock.isFloating():
            # Startup discovery must not recreate a native Windows window.
            # A later real float transition goes through _on_dock_toplevel.
            dock.setTitleBarWidget(None)
        else:
            dock.setTitleBarWidget(bar)           # docked → flat bar
        dock.topLevelChanged.connect(lambda floating, d=dock: _on_dock_toplevel(d, floating))
    except Exception:
        pass
    return dock


# ── in-panel section headings (the "// WORKFLOW" style) ───────────────────────
SECTION_HEADING_QSS = (
    "color: {muted}; font-family: 'Chakra Petch','Segoe UI',sans-serif;"
    " font-size: 11px; font-weight: bold; letter-spacing: 1.5px;"
    " padding: 2px 0 4px 0;"
).format(**THEME)


def style_section_heading(label, text=None):
    """Style a QLabel as a Velocity section heading: muted, upper, spaced, with the
    '// ' console prefix (matches the panel's '// WORKFLOW'). Fail-open."""
    try:
        if text is not None or label.text():
            t = (text if text is not None else label.text()).strip().lstrip("/ ").upper()
            label.setText("// " + t)
        label.setStyleSheet(SECTION_HEADING_QSS)
    except Exception:
        pass
    return label


def _make_drag_filter():
    """Factory for a QObject event-filter that lets a frameless dialog be dragged by
    its title bar (defined lazily so QtCore is only imported at call time)."""
    from qgis.PyQt.QtCore import QObject, QEvent, Qt

    class _Filter(QObject):
        def __init__(self, dlg):
            super().__init__(dlg)
            self._dlg = dlg
            self._pos = None

        def eventFilter(self, obj, ev):
            try:
                t = ev.type()
                if t == QEvent.Type.MouseButtonPress and ev.button() == Qt.MouseButton.LeftButton:
                    self._pos = (ev.globalPosition().toPoint()
                                 - self._dlg.frameGeometry().topLeft())
                elif (t == QEvent.Type.MouseMove and self._pos is not None
                      and (ev.buttons() & Qt.MouseButton.LeftButton)):
                    self._dlg.move(ev.globalPosition().toPoint() - self._pos)
                elif t == QEvent.Type.MouseButtonRelease:
                    self._pos = None
            except Exception:
                self._pos = None
            return False
    return _Filter


def chrome_dialog(dlg, title=None):
    """Reshape a QDialog to the Velocity look: FRAMELESS with a custom dark title bar
    (cyan accent + a Windows-red ✕ that calls reject), draggable by the title bar.

    SAFE + fail-open: only proceeds when the dialog's top layout is a box layout we can
    insert a title bar into; otherwise the dialog is left exactly as it was (native
    frame, still fully working) — never raises, never crashes. Idempotent. MUST be
    called BEFORE the dialog is shown/exec'd (changing window flags hides a live one)."""
    try:
        from qgis.PyQt.QtWidgets import (QWidget, QHBoxLayout, QLabel, QToolButton,
                                         QBoxLayout)
        from qgis.PyQt.QtCore import Qt
        if getattr(dlg, "_vf_chromed", False):
            return dlg
        lay = dlg.layout()
        if not isinstance(lay, QBoxLayout):
            return dlg                      # can't safely insert a title bar → leave framed
        ttl = title or dlg.windowTitle() or "Velocity Nexus"
        dlg.setWindowFlags(dlg.windowFlags() | Qt.WindowType.FramelessWindowHint)
        bar = QWidget(dlg)
        bar.setObjectName("NexusDlgTitle")
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(12, 7, 6, 6)
        bl.setSpacing(6)
        tl = QLabel(ttl)
        tl.setObjectName("NexusDlgTitleText")
        bl.addWidget(tl)
        bl.addStretch(1)
        x = QToolButton()
        x.setFixedSize(28, 24)
        style_windows_close(x, dlg.reject)
        bl.addWidget(x, 0, Qt.AlignmentFlag.AlignTop)
        bar.setStyleSheet(
            "#NexusDlgTitle{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,"
            "stop:0 #0B1019,stop:1 #070A11);border-bottom:2px solid #1AE5FF;}"
            "#NexusDlgTitleText{color:#EAF3FF;font-family:'Chakra Petch','Segoe UI',"
            "sans-serif;font-size:13px;font-weight:bold;}")
        lay.insertWidget(0, bar)
        filt = _make_drag_filter()(dlg)
        bar.installEventFilter(filt)
        tl.installEventFilter(filt)
        dlg._vf_drag_filter = filt          # keep a ref so it isn't GC'd
        dlg._vf_chromed = True
    except Exception:
        pass
    return dlg


def make_tool_button(label, on_click=None):
    """A Velocity-Nexus-styled tool button (objectName NexusTool → themed by QSS)."""
    from qgis.PyQt.QtWidgets import QPushButton
    b = QPushButton(label)
    b.setObjectName("NexusTool")
    b.setMinimumHeight(32)
    b.setCursor(_pointing_cursor())
    if on_click is not None:
        b.clicked.connect(on_click)
    return b


def make_group_body(title, buttons, columns=2):
    """A themed dock body: the given tool buttons laid out in a ``columns``-wide grid
    on the near-black console background (2-col keeps long tool lists compact). The
    group name is the Dock's own (draggable) title bar, so no redundant caption.
    ``buttons`` = list of QWidgets."""
    from qgis.PyQt.QtWidgets import QWidget, QVBoxLayout, QGridLayout, QSizePolicy
    w = QWidget()
    w.setObjectName("NexusDockBody")
    lay = QVBoxLayout(w)
    lay.setContentsMargins(10, 10, 10, 10)
    lay.setSpacing(7)
    grid = QGridLayout()
    grid.setSpacing(6)
    cols = max(1, int(columns))
    for c in range(cols):
        grid.setColumnStretch(c, 1)
    for i, b in enumerate(buttons):
        try:
            b.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        except Exception:
            pass
        grid.addWidget(b, i // cols, i % cols)
    lay.addLayout(grid)
    lay.addStretch(1)
    return w


def _pointing_cursor():
    from qgis.PyQt.QtCore import Qt
    return Qt.CursorShape.PointingHandCursor


def apply_polish(area, docks):
    """Apply the Velocity Nexus theme + smoothness to a built DockArea (no behaviour
    change): near-black body, console-cell buttons + cyan hover, wider hover-cyan
    splitter handles, and an open-hand grab cursor on every title bar. All external
    styling (the label title bars are themed in the vendored updateStyle). Fail-open."""
    from qgis.PyQt.QtCore import Qt
    try:
        area.setStyleSheet(NEXUS_QSS)
    except Exception:
        pass
    for d in (docks or {}).values():
        try:
            lbl = getattr(d, "label", None)
            if lbl is not None:
                lbl.setCursor(Qt.CursorShape.OpenHandCursor)
                lbl.fontSize = "13px"          # prominent card-header title
                lbl.updateStyle()
                cb = getattr(lbl, "closeButton", None)
                if cb is not None:             # Windows-style red close (already wired
                    style_windows_close(cb)    # to close the dock via sigCloseClicked)
        except Exception:
            continue


def save_layout(area, settings=None):
    """Persist the DockArea layout to QgsSettings (global). Returns True on success."""
    try:
        from qgis.core import QgsSettings
        st = area.saveState()
        (settings or QgsSettings()).setValue(_SETTINGS_KEY, repr(st))
        return True
    except Exception:
        return False


def restore_layout(area, settings=None):
    """Restore a previously-saved layout onto ``area``. Returns True if one was applied.

    Safe: a missing / unparseable / stale layout (docks that no longer exist) is
    swallowed and the freshly-built default layout stays."""
    try:
        from qgis.core import QgsSettings
        import ast
        raw = (settings or QgsSettings()).value(_SETTINGS_KEY, None)
        if not raw:
            return False
        state = ast.literal_eval(raw) if isinstance(raw, str) else raw
        area.restoreState(state)
        return True
    except Exception:
        return False


def clear_layout(settings=None):
    """'Reset layout' — drop the saved state so the next open uses the default."""
    try:
        from qgis.core import QgsSettings
        (settings or QgsSettings()).remove(_SETTINGS_KEY)
        return True
    except Exception:
        return False


# keep the import used (QByteArray may back saveState in some builds) discoverable
__all__ = [
    "Dock",
    "DockArea",
    "QByteArray",
    "build_dockarea",
    "clear_layout",
    "restore_layout",
    "save_layout",
]
