try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

"""ux — shared UX helpers: step progress dialog + What's-New-on-upgrade popup.

Deliberately uses a modal QProgressDialog driven on the main thread with
processEvents() between steps — NOT a background QgsTask. Processing algorithms
here mutate layer data providers; keeping them on the main thread avoids the
threading hazards (and the access-violation class) while still giving the user
clear "step 3 of 8" feedback and a Cancel button. QGIS never looks frozen.
"""


def _vf_style():
    try:
        from .branding import vf_style
        return vf_style
    except ImportError:
        try:
            from branding import vf_style
            return vf_style
        except Exception:
            return None


class StepProgress:
    """Context manager: a themed, cancelable progress dialog over N named steps.

        with StepProgress(iface, 'Run All FT', steps) as prog:
            for name, fn in steps_with_fns:
                if prog.canceled: break
                prog.step(name)
                fn()
    """

    def __init__(self, iface, title, step_names):
        self.iface = iface
        self.title = title
        self.steps = list(step_names)
        self.dlg = None
        self._i = 0
        self.canceled = False

    def __enter__(self):
        from qgis.PyQt.QtWidgets import QProgressDialog
        from qgis.PyQt.QtCore import Qt
        self.dlg = QProgressDialog(self.iface.mainWindow())
        self.dlg.setWindowTitle('Velocity Nexus')
        self.dlg.setLabelText(f'{self.title}…')
        self.dlg.setRange(0, len(self.steps))
        self.dlg.setWindowModality(Qt.WindowModality.WindowModal)
        self.dlg.setMinimumWidth(420)
        self.dlg.setAutoClose(False)
        self.dlg.setAutoReset(False)
        st = _vf_style()
        if st:
            try:
                self.dlg.setStyleSheet(st.DIALOG_QSS)
            except Exception:
                _swallowed_note()
        try:
            from .nexus_dock import chrome_dialog
            chrome_dialog(self.dlg)
        except Exception:
            _swallowed_note()
        self.dlg.show()
        from qgis.PyQt.QtWidgets import QApplication
        QApplication.processEvents()
        return self

    def step(self, name):
        from qgis.PyQt.QtWidgets import QApplication
        self._i += 1
        if self.dlg is not None:
            self.dlg.setValue(self._i - 1)
            self.dlg.setLabelText(f'[{self._i}/{len(self.steps)}]  {name} …')
            if self.dlg.wasCanceled():
                self.canceled = True
        QApplication.processEvents()

    def done(self):
        if self.dlg is not None:
            self.dlg.setValue(len(self.steps))

    def __exit__(self, *exc):
        try:
            if self.dlg is not None:
                self.dlg.close()
                self.dlg.deleteLater()
        except Exception:
            _swallowed_note()
        return False


def _changelog_entries(plugin_dir):
    """Parse metadata.txt changelog into [(version, text), ...] newest first."""
    import os
    import re
    try:
        with open(os.path.join(plugin_dir, 'metadata.txt'), encoding='utf-8') as _f:
            txt = _f.read()
    except Exception:
        return []
    m = re.search(r'changelog=(.*?)(?:\n\w+=|\Z)', txt, re.S)
    if not m:
        return []
    out = []
    for blk in re.split(r'\n(?=\s*\d+\.\d+\.\d+\s*-)', m.group(1).strip()):
        mm = re.match(r'\s*(\d+\.\d+\.\d+)\s*-\s*(.*)', blk, re.S)
        if mm:
            out.append((mm.group(1), ' '.join(mm.group(2).split())))
    return out


def _ver_t(s):
    import re
    try:
        return tuple(int(x) for x in re.findall(r'\d+', str(s))[:4])
    except Exception:
        return (0,)


class ConfettiOverlay:
    """Confetti burst painted over a dialog — QTimer + paintEvent only,
    transparent to the mouse, self-stops after ~3.5 s."""

    COLOURS = ['#2ec4f1', '#a05cf0', '#ff5da2', '#ffd166', '#06d6a0',
               '#ff8c42', '#f9f9f9']

    def __init__(self, parent):
        import random
        from qgis.PyQt.QtCore import Qt, QTimer
        from qgis.PyQt.QtWidgets import QWidget
        outer = self

        class _W(QWidget):
            def paintEvent(self, _ev):
                outer._paint(self)

        self.w = _W(parent)
        self.w.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.w.setGeometry(parent.rect())
        self._rng = random.Random()
        self.parts = []
        self._ticks = 0
        self.timer = QTimer(self.w)
        self.timer.timeout.connect(self._tick)

    def start(self):
        try:
            self.w.setGeometry(self.w.parentWidget().rect())
            self.seed()
            self.w.show()
            self.w.raise_()
            self.timer.start(16)
        except RuntimeError:
            pass    # dialog already closed before the kick-off timer fired

    def seed(self, n=90):
        rng = self._rng
        wdt = max(self.w.width(), 200)
        self.parts = []
        for _ in range(n):
            self.parts.append({
                'x': rng.uniform(0, wdt),
                'y': rng.uniform(-160, -8),
                'vx': rng.uniform(-1.4, 1.4),
                'vy': rng.uniform(1.6, 4.6),
                'rot': rng.uniform(0, 360),
                'vr': rng.uniform(-9, 9),
                'sz': rng.uniform(5, 11),
                'c': rng.choice(self.COLOURS),
                'shape': rng.choice(['rect', 'rect', 'circle']),
            })

    def _tick(self):
        self._ticks += 1
        h = self.w.height()
        alive = False
        for p in self.parts:
            p['x'] += p['vx']
            p['y'] += p['vy']
            p['vy'] += 0.05
            p['rot'] += p['vr']
            if p['y'] < h + 20:
                alive = True
        if not alive or self._ticks > 220:
            self.timer.stop()
            self.w.hide()
            return
        self.w.update()

    def _paint(self, widget):
        from qgis.PyQt.QtCore import QRectF, Qt
        from qgis.PyQt.QtGui import QColor, QPainter
        pt = QPainter(widget)
        pt.setRenderHint(QPainter.RenderHint.Antialiasing)
        pt.setPen(Qt.PenStyle.NoPen)
        for p in self.parts:
            if p['y'] > widget.height() + 20:
                continue
            pt.save()
            pt.translate(p['x'], p['y'])
            pt.rotate(p['rot'])
            pt.setBrush(QColor(p['c']))
            s = p['sz']
            if p['shape'] == 'circle':
                pt.drawEllipse(QRectF(-s / 2, -s / 2, s, s))
            else:
                pt.drawRect(QRectF(-s / 2, -s / 4, s, s / 2))
            pt.restore()
        pt.end()


def maybe_show_whats_new(iface, plugin_dir, version):
    """Show a 'What's New' popup once per new version (after an upgrade).
    Stored in QgsSettings so it fires exactly once per version per machine."""
    from qgis.core import QgsSettings
    s = QgsSettings()
    seen = s.value('VelocityFibre/whatsNewVersion', '')
    if seen == version:
        return
    s.setValue('VelocityFibre/whatsNewVersion', version)
    if not seen:
        return  # first ever install — the welcome screen covers this, skip
    from qgis.PyQt.QtCore import Qt, QTimer
    from qgis.PyQt.QtWidgets import (QDialog, QHBoxLayout, QLabel,
                                     QPushButton, QScrollArea, QVBoxLayout,
                                     QWidget)

    # everything the operator gained since the version they last saw
    entries = [(v, t) for v, t in _changelog_entries(plugin_dir)
               if _ver_t(seen) < _ver_t(v) <= _ver_t(version)][:8]

    dlg = QDialog(iface.mainWindow())
    dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)   # don't linger as a hidden window
    dlg.setWindowTitle('Velocity Nexus — What’s New')
    dlg.setMinimumWidth(520)
    lay = QVBoxLayout(dlg)
    lay.setContentsMargins(18, 14, 18, 14)
    lay.setSpacing(10)
    head = QLabel(
        f'<div style="font-size:18px;font-weight:800;">'
        f'🎉 Updated to v{version}!</div>'
        f'<div style="font-size:11px;color:#9fb4c8;margin-top:2px;">'
        f'Here is everything new since v{seen} — enjoy 🚀</div>')
    head.setTextFormat(Qt.TextFormat.RichText)
    lay.addWidget(head)

    html = []
    for i, (v, txt) in enumerate(entries):
        chip = ('NEW in this update' if i == 0 else f'v{v}')
        html.append(
            f'<div style="margin-bottom:11px;">'
            f'<span style="background:#2ec4f1;color:#06121c;font-weight:700;'
            f'font-size:10px;border-radius:4px;padding:1px 7px;">'
            f'✨ {chip}</span>'
            f'<div style="margin-top:3px;font-size:12px;line-height:1.45;">'
            f'{txt}</div></div>')
    if not html:
        html = ['<div style="font-size:12px;">Fresh tools and fixes — '
                'explore the Velocity Nexus menu!</div>']
    body = QLabel(''.join(html))
    body.setTextFormat(Qt.TextFormat.RichText)
    body.setWordWrap(True)
    body.setStyleSheet('background:transparent;')
    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setFrameShape(QScrollArea.NoFrame)
    inner = QWidget()
    iv = QVBoxLayout(inner)
    iv.setContentsMargins(0, 0, 0, 0)
    iv.addWidget(body)
    iv.addStretch(1)
    scroll.setWidget(inner)
    scroll.setMinimumHeight(min(110 + 64 * len(entries), 340))
    lay.addWidget(scroll)

    row = QHBoxLayout()
    row.addStretch(1)
    ok = QPushButton('Got it  🎊')
    row.addWidget(ok)
    lay.addLayout(row)
    ok.clicked.connect(dlg.accept)
    dlg.finished.connect(dlg.deleteLater)   # window disappears on Got it / X
    st = _vf_style()
    if st:
        try:
            st.apply_vf_style(dlg, title=f'Version {version}')
        except Exception:
            _swallowed_note()
    try:
        from .nexus_dock import chrome_dialog
        chrome_dialog(dlg)
    except Exception:
        _swallowed_note()
    dlg.show()
    dlg.raise_()
    # confetti pop once the dialog is on screen. The kick-off timer is
    # PARENTED to the dialog so closing it instantly can never leave a
    # pending shot aimed at a deleted widget.
    confetti = ConfettiOverlay(dlg)
    dlg._vf_confetti = confetti             # keep alive with the dialog
    kick = QTimer(dlg)
    kick.setSingleShot(True)
    kick.timeout.connect(confetti.start)
    kick.start(120)
    return dlg
