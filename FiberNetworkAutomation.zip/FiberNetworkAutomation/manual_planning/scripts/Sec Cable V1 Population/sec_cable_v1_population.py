import sys, os
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')

# ============================================================
# SECONDARY CABLE V1 — FULL ATTRIBUTE POPULATION
# Project: Potch - Mohadin PH2
# Reference: Secondary Cable sheet from poles_potch_csv.xlsx
# Label format: MOA.SF.48F.P.[StartPole]-P.[EndPole]
# dim2: cable length in metres from geometry
# ============================================================

CABLE_LAYER = 'Secondary Cable v1'
POLES_LAYER = 'poles v1'
PON_LAYER = 'PON v1'
ZONE_LAYER = 'Zones v1'

SR = 'MOA'

# Static values from reference
STATIC = {
    'type': 'Cable',
    'subtyp': 'Mini-ADSS',
    'spec': 'SM/G657A1',
    'dim1': '5,6mm',
    'cblcpty': '48F',
    'ntwrkptn': 'Secondary',
    'cmpownr': 'VelocityFibre',
    'subplace': '676007',
    'mainplce': '676007',
    'mun': 'JB Marks Local Municipality',
    'stackref': 'MOA',
    'crtdby': 'Johan Scholtz',
}

# --- GET LAYERS ---
cable_layer = None
poles_layer = None
pon_layer = None
zone_layer = None

for lyr in QgsProject.instance().mapLayers().values():
    n = lyr.name()
    if n == CABLE_LAYER: cable_layer = lyr
    if n == POLES_LAYER: poles_layer = lyr
    if n == PON_LAYER: pon_layer = lyr
    if n == ZONE_LAYER: zone_layer = lyr

missing = []
if not cable_layer: missing.append(CABLE_LAYER)
if not poles_layer: missing.append(POLES_LAYER)
if not pon_layer: missing.append(PON_LAYER)
if not zone_layer: missing.append(ZONE_LAYER)

if missing:
    print(f"ERROR: Missing layers: {missing}")
else:
    print(f"Cable layer: {CABLE_LAYER} ({cable_layer.featureCount()} features)")
    print(f"Poles layer: {POLES_LAYER} ({poles_layer.featureCount()} features)")

    from qgis.core import QgsSpatialIndex, QgsGeometry, QgsPointXY, QgsDistanceArea
    from qgis.core import QgsProject

    # --- DISTANCE CALCULATOR ---
    d = QgsDistanceArea()
    d.setSourceCrs(cable_layer.crs(), QgsProject.instance().transformContext())
    d.setEllipsoid(QgsProject.instance().ellipsoid())

    # --- BUILD SPATIAL INDEX FOR POLES ---
    pole_index = QgsSpatialIndex(poles_layer.getFeatures())
    pole_feats = {f.id(): f for f in poles_layer.getFeatures()}

    # --- BUILD SPATIAL INDEX FOR PON AND ZONE ---
    pon_index = QgsSpatialIndex(pon_layer.getFeatures())
    pon_feats = {f.id(): f for f in pon_layer.getFeatures()}
    zone_index = QgsSpatialIndex(zone_layer.getFeatures())
    zone_feats = {f.id(): f for f in zone_layer.getFeatures()}

    def nearest_pole_label(point):
        candidates = pole_index.nearestNeighbor(point, 1)
        if candidates:
            feat = pole_feats[candidates[0]]
            label = str(feat['Label'])
            if '.' in label:
                parts = label.split('.')
                return parts[-1]
        return None

    def fidx(name):
        return cable_layer.fields().indexOf(name)

    if not cable_layer.startEditing():  # claude:approved-destructive
        raise RuntimeError('Cannot start editing on cable layer — check if it is read-only or already locked')

    processed = 0
    no_geom = 0
    sample = []

    for cable in cable_layer.getFeatures():
        geom = cable.geometry()

        if geom is None or geom.isNull() or geom.isEmpty():
            no_geom += 1
            continue

        vertices = list(geom.vertices())
        if len(vertices) < 2:
            no_geom += 1
            continue

        start_pt = QgsPointXY(vertices[0].x(), vertices[0].y())
        end_pt = QgsPointXY(vertices[-1].x(), vertices[-1].y())

        # --- FIND NEAREST POLES ---
        start_pole = nearest_pole_label(start_pt)
        end_pole = nearest_pole_label(end_pt)

        # --- BUILD LABEL ---
        if start_pole and end_pole:
            label = f'{SR}.SF.48F.P.{start_pole}-P.{end_pole}'
            strtfeat = f'{SR}.P.{start_pole}'
            endfeat = f'{SR}.P.{end_pole}'
        else:
            label = None
            strtfeat = None
            endfeat = None

        # --- DIM2 — cable length in metres ---
        length_m = d.measureLength(geom)
        dim2 = str(round(length_m, 4))

        # --- ASSIGN STATIC FIELDS ---
        for field, val in STATIC.items():
            idx = fidx(field)
            if idx != -1:
                cable_layer.changeAttributeValue(cable.id(), idx, val)

        # --- ASSIGN LABEL, STRTFEAT, ENDFEAT, DIM2 ---
        if label:
            cable_layer.changeAttributeValue(cable.id(), fidx('label'), label)
        if strtfeat:
            cable_layer.changeAttributeValue(cable.id(), fidx('strtfeat'), strtfeat)
        if endfeat:
            cable_layer.changeAttributeValue(cable.id(), fidx('endfeat'), endfeat)
        dim2_idx = fidx('dim2')
        if dim2_idx != -1:
            cable_layer.changeAttributeValue(cable.id(), dim2_idx, dim2)

        # --- PON_NO — from midpoint ---
        mid_idx = len(vertices) // 2
        mid_pt = QgsPointXY(vertices[mid_idx].x(), vertices[mid_idx].y())
        mid_geom = QgsGeometry.fromPointXY(mid_pt)

        pon_no = None
        candidates = pon_index.intersects(mid_geom.boundingBox())
        for fid in candidates:
            if pon_feats[fid].geometry().contains(mid_geom):
                pon_no = pon_feats[fid]['pon_no']
                break
        if pon_no:
            cable_layer.changeAttributeValue(cable.id(), fidx('pon_no'), pon_no)

        # --- ZONE_NO --- from midpoint ---
        zone_no = None
        candidates = zone_index.intersects(mid_geom.boundingBox())
        for fid in candidates:
            if zone_feats[fid].geometry().intersects(mid_geom):
                zone_no = zone_feats[fid]['zone_no']
                break
        if zone_no:
            cable_layer.changeAttributeValue(cable.id(), fidx('zone_no'), zone_no)

        processed += 1
        if len(sample) < 5 and label:
            sample.append(f"  {label} | dim2={dim2}m | pon={pon_no} | zone={zone_no}")

    if not cable_layer.commitChanges():
        cable_layer.rollbackChanges()
        raise RuntimeError('commitChanges() failed — no attributes were written')

    # --- SUMMARY ---
    print("=" * 55)
    print("  SECONDARY CABLE V1 POPULATION COMPLETE")
    print(f"  Processed: {processed}")
    print(f"  Skipped (no geometry): {no_geom}")
    print("=" * 55)
    print("\nSample — first 5 cables:")
    for s in sample:
        print(s)
