"""bridge_switcher — dev-only picker for which bridge Claude talks to.

OFF BY DEFAULT. Everything here is gated behind a single QgsSettings flag that
defaults to False, so for the team the bridge line stays exactly what it is
today: a read-only label with no click behaviour. Nothing in this module runs,
and nothing is wired up, unless the flag is explicitly turned on.

What it changes, and what it deliberately does not
--------------------------------------------------
Two different questions were conflated for a long time, which is what made the
old indicator lie:

* **Which bridge is THIS window running?** Resolved in-process from the bridge
  plugin's own server object. This picker NEVER changes it -- a QGIS process
  binds its own port at startup and cannot be moved by writing a file.
* **Which bridge does Claude talk to?** A machine-wide pointer in
  ``C:/Temp/bridge_port.txt``. That is the only thing this picker writes.

So switching here retargets Claude; the indicator keeps reporting this window's
own port truthfully, and the label calls out the mismatch when the two differ.

Threading
---------
Every probe is asynchronous, via QgsNetworkAccessManager. A synchronous request
to our OWN bridge would deadlock: the bridge answers /status by queueing work
onto the Qt main thread, so a blocking call made from that thread waits forever
for a reply it is itself preventing. Our own row is therefore filled in from
in-process state and never probed over HTTP at all.
"""
import json

from qgis.PyQt.QtCore import Qt, QTimer
from qgis.PyQt.QtWidgets import (QDialog, QHBoxLayout, QLabel, QLineEdit,
                                 QListWidget, QListWidgetItem, QPushButton,
                                 QVBoxLayout)

from . import bridge_state as _bs

#: Global-scope QgsSettings keys. Machine-local and user-scoped: never written
#: into a .qgz/.qgs, so switching project does not carry a port with it.
SETTINGS_ENABLED = "velocity_nexus/dev/bridge_switcher_enabled"
SETTINGS_PORT = "velocity_nexus/dev/bridge_selected_port"

PORT_FILE = "C:/Temp/bridge_port.txt"

#: A bridge that has not answered within this many ms is treated as not there.
PROBE_TIMEOUT_MS = 1500


def is_enabled():
    """False unless the dev flag is explicitly on. Any error -> False.

    Fails closed on purpose: an unreadable setting must leave teammates with
    today's read-only indicator, never switch a feature on by accident.
    """
    try:
        from qgis.core import QgsSettings
        v = QgsSettings().value(SETTINGS_ENABLED, False)
    except Exception:
        return False
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() in ("1", "true", "yes")


def selected_port():
    """The port last chosen here, or None. Global scope, survives restarts."""
    try:
        from qgis.core import QgsSettings
        v = QgsSettings().value(SETTINGS_PORT, None)
        if v in (None, ""):
            return None
        p = int(v)
        return p if p in _bs.PORT_RANGE else None
    except Exception:
        return None


def _remember_port(port):
    try:
        from qgis.core import QgsSettings
        QgsSettings().setValue(SETTINGS_PORT, int(port))
    except Exception:
        pass


def _write_port_file(port):
    """Point Claude at `port`. Returns True on success — the caller must not
    report a switch that did not actually land."""
    try:
        with open(PORT_FILE, "w", encoding="utf-8") as f:
            f.write(str(int(port)))
        return True
    except Exception:
        return False


def current_claude_port():
    try:
        with open(PORT_FILE, encoding="utf-8") as f:
            return int(f.read().strip())
    except Exception:
        return None


def probe(port, callback):
    """GET http://127.0.0.1:<port>/status asynchronously; callback(payload|None).

    payload is the decoded JSON, or None if nothing answered / it was not JSON.
    Callers must still run it through bridge_state.is_bridge_status() — plenty
    of things answer on this port range without being a bridge.
    """
    try:
        from qgis.core import QgsNetworkAccessManager
        from qgis.PyQt.QtCore import QUrl
        from qgis.PyQt.QtNetwork import QNetworkRequest
    except Exception:
        callback(None)
        return
    try:
        req = QNetworkRequest(QUrl(f"http://127.0.0.1:{int(port)}/status"))
        reply = QgsNetworkAccessManager.instance().get(req)
    except Exception:
        callback(None)
        return

    done = {"fired": False}

    def _finish(payload):
        # Guard: timeout and finished can both arrive; the callback must run once.
        if done["fired"]:
            return
        done["fired"] = True
        callback(payload)

    def _on_finished(r=reply):
        payload = None
        try:
            from .fibre_automation.nexus_profile.backend import _net_ok
            if _net_ok(r):
                payload = json.loads(
                    bytes(r.readAll()).decode("utf-8", "replace"))
        except Exception:
            payload = None
        _finish(payload)
        try:
            r.deleteLater()
        except Exception:
            pass

    reply.finished.connect(_on_finished)
    # A port that is filtered rather than closed can hang; bound the wait so the
    # picker always finishes populating.
    QTimer.singleShot(PROBE_TIMEOUT_MS, lambda: _finish(None))


def open_ports():
    """Ports in the range currently accepting a connection.

    Non-blocking connects plus ONE bounded select — the same shape as the
    poller. Sequential blocking connects here would stack timeouts into a
    multi-second UI freeze, which is the exact bug that was fixed in the poller.
    """
    import select
    import socket
    found, pending = [], {}
    for p in _bs.PORT_RANGE:
        s = None
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setblocking(False)
            rc = s.connect_ex(("127.0.0.1", p))
        except Exception:
            if s is not None:
                try:
                    s.close()
                except Exception:
                    pass
            continue
        if rc == 0:
            found.append(p)
            s.close()
        else:
            pending[s] = p
    if pending:
        try:
            _, writable, _ = select.select([], list(pending), list(pending), 0.3)
        except Exception:
            writable = []
        for s in writable:
            try:
                if s.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR) == 0:
                    found.append(pending[s])
            except Exception:
                pass
        for s in pending:
            try:
                s.close()
            except Exception:
                pass
    return sorted(found)


class BridgeSwitcherDialog(QDialog):
    """Pick which bridge Claude talks to. Dev-only; see is_enabled()."""

    def __init__(self, parent=None, own_port=None, own_project=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.setWindowTitle("Which bridge should Claude use?")
        self.setMinimumWidth(430)
        self._own_port = own_port
        self._own_project = own_project
        self._payloads = {}
        self._chosen = None

        v = QVBoxLayout(self)
        v.setContentsMargins(14, 14, 14, 12)
        v.setSpacing(9)

        head = QLabel(
            f"This window runs its own bridge on port "
            f"<b>{own_port if own_port is not None else '—'}</b> and that never "
            f"changes.<br>Choosing here only points <b>Claude</b> at a bridge — "
            f"which may be another QGIS window.")
        head.setWordWrap(True)
        head.setTextFormat(Qt.TextFormat.RichText)
        v.addWidget(head)

        self._list = QListWidget()
        self._list.itemDoubleClicked.connect(lambda _i: self._apply())
        v.addWidget(self._list, 1)

        manual_row = QHBoxLayout()
        manual_row.addWidget(QLabel("Or a port directly:"))
        self._manual = QLineEdit()
        self._manual.setPlaceholderText(
            f"{_bs.PORT_MIN}–{_bs.PORT_MAX}")
        self._manual.setFixedWidth(90)
        manual_row.addWidget(self._manual)
        manual_row.addStretch(1)
        v.addLayout(manual_row)

        self._msg = QLabel("")
        self._msg.setWordWrap(True)
        v.addWidget(self._msg)

        btns = QHBoxLayout()
        btns.addStretch(1)
        self._use = QPushButton("Use this bridge")
        self._use.clicked.connect(self._apply)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        btns.addWidget(self._use)
        btns.addWidget(cancel)
        v.addLayout(btns)

        self._populate()

    # ── discovery ───────────────────────────────────────────────────────────
    def _populate(self):
        self._list.clear()
        ports = open_ports()
        # Our own port belongs in the list even if the scan raced and missed it.
        if self._own_port is not None and self._own_port not in ports:
            ports = sorted(set(ports) | {self._own_port})
        if not ports:
            self._note("No ports are answering in "
                       f"{_bs.PORT_MIN}–{_bs.PORT_MAX}. Is any QGIS running?",
                       warn=True)
        current = current_claude_port()
        for p in ports:
            item = QListWidgetItem(_bs.describe_candidate(p, None,
                                                          p == self._own_port))
            item.setData(Qt.ItemDataRole.UserRole, p)
            self._list.addItem(item)
            if p == current:
                self._list.setCurrentItem(item)
            if p == self._own_port:
                # In-process truth — never probe our own bridge over HTTP.
                self._payloads[p] = {"status": "running",
                                     "project_name": self._own_project or ""}
                self._refresh_row(p)
            else:
                probe(p, lambda payload, _p=p: self._on_probe(_p, payload))

    def _on_probe(self, port, payload):
        self._payloads[port] = payload if payload is not None else False
        self._refresh_row(port)

    def _refresh_row(self, port):
        from qgis.PyQt import sip
        if sip.isdeleted(self):
            return
        payload = self._payloads.get(port)
        for i in range(self._list.count()):
            it = self._list.item(i)
            if it.data(Qt.ItemDataRole.UserRole) != port:
                continue
            it.setText(_bs.describe_candidate(
                port, None if payload is None else (payload or {}),
                port == self._own_port))
            usable = _bs.is_bridge_status(payload or {})
            if payload is not None and not usable:
                it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEnabled)
            return

    def _note(self, text, warn=False):
        self._msg.setText(text)
        self._msg.setStyleSheet(
            "color:#d97706;" if warn else "color:#6b7280;")

    # ── apply ───────────────────────────────────────────────────────────────
    def _selected_port(self):
        raw = self._manual.text().strip()
        if raw:
            if not raw.isdigit():
                self._note("That is not a port number.", warn=True)
                return None
            p = int(raw)
            if p not in _bs.PORT_RANGE:
                self._note(f"Port must be between {_bs.PORT_MIN} and "
                           f"{_bs.PORT_MAX}.", warn=True)
                return None
            return p
        it = self._list.currentItem()
        if it is None:
            self._note("Pick a bridge, or type a port.", warn=True)
            return None
        return it.data(Qt.ItemDataRole.UserRole)

    def _apply(self):
        port = self._selected_port()
        if port is None:
            return
        previous = current_claude_port()
        self._note(f"Checking port {port}…")
        self._use.setEnabled(False)

        def _decided(payload):
            from qgis.PyQt import sip
            if sip.isdeleted(self):
                return
            self._use.setEnabled(True)
            # Verify BEFORE switching: a port that answers but is not a bridge
            # (the canvas mirror does exactly this) must not be adopted, and the
            # previous choice must survive untouched.
            if not _bs.is_bridge_status(payload or {}):
                what = ("nothing answered" if not payload
                        else "something is listening, but it is not a QGIS bridge")
                self._note(
                    f"Not switching: on port {port}, {what}. "
                    f"Claude is still pointed at "
                    f"{previous if previous is not None else 'nothing'}.",
                    warn=True)
                return
            if not _write_port_file(port):
                self._note(f"Could not write {PORT_FILE}. Claude is still "
                           f"pointed at "
                           f"{previous if previous is not None else 'nothing'}.",
                           warn=True)
                return
            _remember_port(port)
            self._chosen = port
            self.accept()

        if port == self._own_port:
            _decided({"status": "running",
                      "project_name": self._own_project or ""})
        else:
            probe(port, _decided)

    def chosen_port(self):
        return self._chosen
