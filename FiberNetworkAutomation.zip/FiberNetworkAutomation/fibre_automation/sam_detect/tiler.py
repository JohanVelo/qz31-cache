"""tiler — render the AOI as overlapping basemap tiles + export box prompts.

Runs INSIDE QGIS (main thread). For each tile writes <tiles_dir>/job_<i>.json:
png path + bbox (EPSG:3857) + building boxes (pixel coords, tagged with the
erf that contains the centroid) + erven WKT intersecting the tile.

Fully generic: any AOI rect, any buildings layer (the box prompts), any
optional erven layer, any raster basemap. Nothing project-specific.
"""
from __future__ import annotations

import json
import math
import os

from qgis.core import (
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsDistanceArea,
    QgsFeatureRequest, QgsGeometry, QgsMapRendererParallelJob, QgsMapSettings,
    QgsProject, QgsRectangle, QgsSpatialIndex,
)
from qgis.PyQt.QtCore import QEventLoop, QSize, QTimer
from qgis.PyQt.QtGui import QColor

DEFAULTS = {
    "tile_core_m": 220.0,
    "overlap_m": 30.0,
    "target_mpp": 0.25,
    "max_px": 1400,
}

BLANK_RETRY_ROUNDS = 3
BLANK_RETRY_WAIT_MS = 2500


def _is_blank(img):
    """True when a rendered tile is (near-)uniform — the signature of an XYZ
    basemap whose web tiles had not downloaded when the render job finished.
    Real aerial imagery always has texture."""
    s = img.scaled(8, 8)
    colours = set()
    for y in range(s.height()):
        for x in range(s.width()):
            colours.add(s.pixel(x, y) & 0xFFFFFF)
            if len(colours) > 3:
                return False
    return True


def _pump_events(ms):
    """Let the Qt event loop run so pending basemap tile downloads complete."""
    loop = QEventLoop()
    QTimer.singleShot(ms, loop.quit)
    loop.exec()


def _render(basemap, rect3857, width, height, crs3857):
    ms = QgsMapSettings()
    ms.setOutputSize(QSize(width, height))
    ms.setDestinationCrs(crs3857)
    ms.setExtent(rect3857)
    ms.setLayers([basemap])
    ms.setBackgroundColor(QColor(0, 0, 0))
    job = QgsMapRendererParallelJob(ms)
    job.start()
    job.waitForFinished()
    return job.renderedImage()


def _erf_key_field(erven):
    """Best-guess parcel-key field on the erven layer (generic)."""
    names = [f.name() for f in erven.fields()]
    for cand in ("PRCL_KEY", "prcl_key", "PARCEL", "erf", "ERF", "erf_no",
                 "stand_no", "key"):
        if cand in names:
            return cand
    return None


def render_tiles(basemap, buildings, erven, aoi_rect_4326, tiles_dir,
                 params=None, progress_cb=None):
    """Render all tiles for the AOI. Returns dict(total=, boxes=, erven=).

    basemap   QgsRasterLayer (satellite imagery)
    buildings QgsVectorLayer with footprint polygons (box prompts)
    erven     QgsVectorLayer with cadastral polygons, or None
    aoi_rect_4326  QgsRectangle in EPSG:4326
    progress_cb(i, total) -> return False to cancel
    """
    P = dict(DEFAULTS)
    if params:
        P.update(params)
    os.makedirs(tiles_dir, exist_ok=True)

    proj = QgsProject.instance()
    c4 = QgsCoordinateReferenceSystem("EPSG:4326")
    c3 = QgsCoordinateReferenceSystem("EPSG:3857")
    to3857 = QgsCoordinateTransform(c4, c3, proj)
    bld_to3857 = QgsCoordinateTransform(buildings.crs(), c3, proj)
    bld_to4 = QgsCoordinateTransform(buildings.crs(), c4, proj)

    erven_to3857 = key_field = bld_to_erven = None
    if erven is not None:
        erven_to3857 = QgsCoordinateTransform(erven.crs(), c3, proj)
        bld_to_erven = QgsCoordinateTransform(buildings.crs(), erven.crs(), proj)
        key_field = _erf_key_field(erven)

    aoi3857 = to3857.transformBoundingBox(aoi_rect_4326)
    core = float(P["tile_core_m"])
    ov = float(P["overlap_m"])
    mpp = float(P["target_mpp"])
    AX0, AY0 = aoi3857.xMinimum(), aoi3857.yMinimum()
    AX1, AY1 = aoi3857.xMaximum(), aoi3857.yMaximum()
    ncols = max(1, math.ceil((AX1 - AX0) / core))
    nrows = max(1, math.ceil((AY1 - AY0) / core))
    tiles = [(r, c) for r in range(nrows) for c in range(ncols)]
    total = len(tiles)

    da = QgsDistanceArea()
    da.setEllipsoid("WGS84")
    da.setSourceCrs(buildings.crs(), proj.transformContext())

    n_boxes = 0
    erven_seen = set()
    blanks = []      # XYZ tiles that rendered before their imagery downloaded
    for idx, (r, cc) in enumerate(tiles):
        if progress_cb and progress_cb(idx, total) is False:
            return {"total": total, "boxes": n_boxes,
                    "erven": len(erven_seen), "cancelled": True}
        # idempotent: a tile rendered by a previous (interrupted) pass is
        # reused — counts come from its job file
        jp_existing = os.path.join(tiles_dir, f"job_{idx}.json")
        if (os.path.isfile(jp_existing)
                and os.path.isfile(os.path.join(tiles_dir,
                                                f"tile_{idx}.png"))):
            try:
                with open(jp_existing, encoding="utf-8") as f:
                    jd = json.load(f)
                n_boxes += len(jd.get("boxes", []))
                for e in jd.get("erven", []):
                    erven_seen.add(e["erf"])
                continue
            except Exception:
                pass                    # unreadable -> re-render
        cx0 = AX0 + cc * core
        cy1 = AY1 - r * core
        cx1 = cx0 + core
        cy0 = cy1 - core
        rx0 = max(AX0, cx0 - ov); rx1 = min(AX1, cx1 + ov)
        ry0 = max(AY0, cy0 - ov); ry1 = min(AY1, cy1 + ov)
        rect3857 = QgsRectangle(rx0, ry0, rx1, ry1)
        core_rect = QgsRectangle(cx0, cy0, cx1, cy1)
        w_m, h_m = rx1 - rx0, ry1 - ry0
        if w_m < 1 or h_m < 1:
            continue
        width = max(min(int(w_m / mpp), int(P["max_px"])), 64)
        height = max(min(int(h_m / mpp), int(P["max_px"])), 64)

        img = _render(basemap, rect3857, width, height, c3)
        png = os.path.join(tiles_dir, f"tile_{idx}.png")
        img.save(png)
        if _is_blank(img):
            blanks.append((idx, rect3857, width, height, png))
        width, height = img.width(), img.height()

        def px_x(mx, _x0=rx0, _w=w_m, _W=width):
            return (mx - _x0) / _w * _W

        def px_y(my, _y1=ry1, _h=h_m, _H=height):
            return (_y1 - my) / _h * _H

        rect4 = QgsCoordinateTransform(c3, c4, proj).transformBoundingBox(rect3857)

        # erven intersecting the render rect
        erf_geom = {}
        eidx = QgsSpatialIndex()
        erven_out = []
        if erven is not None:
            rect_native = QgsCoordinateTransform(c4, erven.crs(), proj)\
                .transformBoundingBox(rect4)
            rect3857_geom = QgsGeometry.fromRect(rect3857)
            for f in erven.getFeatures(QgsFeatureRequest().setFilterRect(rect_native)):
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                g3 = QgsGeometry(g)
                g3.transform(erven_to3857)
                if not g3.intersects(rect3857_geom):
                    continue
                fid = f.id()
                erf_geom[fid] = g
                eidx.insertFeature(f)
                erven_seen.add(fid)
                prcl = str(f[key_field]) if key_field else str(fid)
                erven_out.append({"erf": int(fid), "prcl": prcl,
                                  "wkt": g3.asWkt()})

        # buildings whose centroid is in the tile CORE (processed exactly once)
        rect_b = QgsCoordinateTransform(c4, buildings.crs(), proj)\
            .transformBoundingBox(rect4)
        boxes = []
        for f in buildings.getFeatures(QgsFeatureRequest().setFilterRect(rect_b)):
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            cen = g.centroid().asPoint()
            cen3 = to3857.transform(bld_to4.transform(cen))
            if not core_rect.contains(cen3):
                continue
            erf = None
            if erven is not None:
                cen_nat = QgsGeometry.fromPointXY(bld_to_erven.transform(cen))
                for cand in eidx.intersects(cen_nat.boundingBox()):
                    if erf_geom.get(cand) and erf_geom[cand].contains(cen_nat):
                        erf = int(cand)
                        break
            bb3 = bld_to3857.transformBoundingBox(g.boundingBox())
            boxes.append({"box": [px_x(bb3.xMinimum()), px_y(bb3.yMaximum()),
                                  px_x(bb3.xMaximum()), px_y(bb3.yMinimum())],
                          "fid": int(f.id()), "erf": erf,
                          "area": round(float(da.measureArea(g)), 2)})
        n_boxes += len(boxes)

        with open(os.path.join(tiles_dir, f"job_{idx}.json"), "w",
                  encoding="utf-8") as fp:
            json.dump({"image_path": png,
                       "bbox": [rx0, ry0, rx1, ry1], "crs": "EPSG:3857",
                       "lat_deg": (rect4.yMinimum() + rect4.yMaximum()) / 2.0,
                       "boxes": boxes, "erven": erven_out}, fp)

    # ── blank-tile recovery ───────────────────────────────────────────────
    # The first render of a never-viewed web-basemap area can finish before
    # the imagery downloads (black tile = silent detection hole). The render
    # itself queued the downloads, so wait for the event loop, re-render.
    cancelled = False
    for _round in range(BLANK_RETRY_ROUNDS):
        if not blanks:
            break
        _pump_events(BLANK_RETRY_WAIT_MS)
        still = []
        for idx, rect3857, width, height, png in blanks:
            if progress_cb and progress_cb(total - 1, total) is False:
                cancelled = True
                break
            img = _render(basemap, rect3857, width, height, c3)
            if _is_blank(img):
                still.append((idx, rect3857, width, height, png))
            else:
                img.save(png)
        blanks = still
        if cancelled:
            break

    return {"total": total, "boxes": n_boxes, "erven": len(erven_seen),
            "blank_tiles": len(blanks), "cancelled": cancelled}
