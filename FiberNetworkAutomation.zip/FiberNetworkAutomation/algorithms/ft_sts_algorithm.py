# Fibertime: Label STS Splitters Algorithm (MOA standard)

from collections import defaultdict

from qgis.core import (
    QgsProcessingParameterVectorLayer,
    QgsProcessing,
)

from .base_algorithm import BaseFiberAlgorithm


class FTSTSAlgorithm(BaseFiberAlgorithm):
    """
    Populate Fibertime STS Splitters v1 — label + static fields (MOA standard).

    Label format: MOA.STS.16.DIS.DM.P.{pole}.{C#P##}.L{leg}
    Example:      MOA.STS.16.DIS.DM.P.F447.C16P02.L1

    Where:
      - pole    = start_feature pole ID with 'MOA.P.' stripped
      - {C#P##} = OLT port inherited from the parent FTS label for this PON
      - leg     = sequential leg number within each PON (sorted by strtfeat)

    Requires pon_no and strtfeat to be populated (run FT 5 + FT 6 first).
    Also requires FTS Splitters v1 to be labeled (run FT 6 first).
    """

    def name(self):
        return 'ft_label_sts_splitters'

    def displayName(self):
        return 'FT 4b. Label STS Splitters'

    def group(self):
        return 'Fibertime Network Labeling'

    def groupId(self):
        return 'fibertimenetworklabeling'

    def shortHelpString(self):
        return """
        Populate Fibertime STS Splitters v1 fields.

        Label format: MOA.STS.16.DIS.DM.P.{pole}.{C#P##}.L{leg}
        Example:      MOA.STS.16.DIS.DM.P.F447.C16P02.L1

        Fields updated:
        - label: MOA.STS.16.DIS.DM.P.{pole}-PON{pon}.L{leg}
        - type: Splitter
        - subtyp: Splitter (Connectorised)
        - spec: SM/G657A1
        - dim1: L60*W12*H4mm  (1:16F connectorised per master spec)
        - dim2: 1m
        - cblcpty: 1:16F
        - conntr: LC/APC
        - cmpownr: VelocityFibre
        - mun: JB Marks LM
        - subplace / mainplce: 676007
        - stackref: MOA

        ⚠️ Run FT 5 (PON Zones) and FT 6 (Apply PON Order) first so that
        pon_no and strtfeat are populated on STS Splitters v1.
        """

    FTS_LAYER = 'FTS_LAYER'

    def initAlgorithm(self, config=None):
        from qgis.core import QgsProject
        proj = QgsProject.instance()
        sts_layers = proj.mapLayersByName('STS Splitters v1')
        fts_layers = proj.mapLayersByName('FTS Splitters v1')

        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT,
                'STS Splitters v1',
                [QgsProcessing.TypeVectorPoint],
                defaultValue=sts_layers[0] if sts_layers else None,
            )
        )
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.FTS_LAYER,
                'FTS Splitters v1 (for OLT port lookup)',
                [QgsProcessing.TypeVectorPoint],
                defaultValue=fts_layers[0] if fts_layers else None,
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        layer     = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        fts_layer = self.parameterAsVectorLayer(parameters, self.FTS_LAYER, context)
        feedback.pushInfo(f"Labeling STS Splitters v1 — {layer.featureCount()} features...")

        import re as _re
        # Build FTS OLT port lookup: str(pon_no) -> 'C16P02'
        # FTS label format: MOA.FTS.17.AGG.DM.P.F461-OLT.01.C16P02
        # We extract just the port code (C##P##) from the label
        fts_olt = {}
        for feat in fts_layer.getFeatures():
            lbl = str(feat['label'])
            pon = str(feat['pon_no'])
            m = _re.search(r'(C\d+P\d+)$', lbl)
            if m:
                fts_olt[pon] = m.group(1)
        feedback.pushInfo(f"FTS OLT ports loaded: {len(fts_olt)}")

        # Fallback: use PON v1 labels for any PONs missing an FTS
        from qgis.core import QgsProject as _QgsProject
        pon_layer = _QgsProject.instance().mapLayersByName('PON v1')
        pon_to_port = {}
        if pon_layer:
            for feat in pon_layer[0].getFeatures():
                lbl = str(feat['label'])
                pon = str(feat['pon_no'])
                if lbl not in ('NULL', 'None', ''):
                    pon_to_port[pon] = lbl

        flds = layer.fields()
        i_label   = flds.indexOf('label')
        i_type    = flds.indexOf('type')
        i_subtyp  = flds.indexOf('subtyp')
        i_spec    = flds.indexOf('spec')
        i_dim1    = flds.indexOf('dim1')
        i_dim2    = flds.indexOf('dim2')
        i_cblcpty = flds.indexOf('cblcpty')
        i_conntr  = flds.indexOf('conntr')
        i_cmpownr = flds.indexOf('cmpownr')
        i_mun     = flds.indexOf('mun')
        i_sub     = flds.indexOf('subplace')
        i_main    = flds.indexOf('mainplce')
        i_stack   = flds.indexOf('stackref')

        # Check required fields
        if flds.indexOf('pon_no') < 0 or flds.indexOf('strtfeat') < 0:
            raise Exception("STS Splitters v1 must have 'pon_no' and 'strtfeat' fields. "
                            "Run FT 5 and FT 6 first.")

        try:
            from qgis.core import NULL
        except Exception:
            NULL = None

        def _is_blank(v):
            if v is None: return True
            if NULL is not None:
                try:
                    if v == NULL: return True
                except Exception: pass
            if isinstance(v, str) and v.strip() in ('', 'NULL', 'null', 'None'):
                return True
            return False

        # Group by pon_no, sort by strtfeat within each PON for consistent leg numbering.
        # Skip features with NULL pon_no or NULL strtfeat — they'd produce poison labels.
        by_pon = defaultdict(list)
        skipped_null = 0
        for feat in layer.getFeatures():
            if _is_blank(feat['pon_no']) or _is_blank(feat['strtfeat']):
                skipped_null += 1
                continue
            by_pon[str(feat['pon_no']).strip()].append(feat)

        STATIC = {
            i_type:    'Splitter',
            i_subtyp:  'Splitter (Connectorised)',
            i_spec:    'SM/G657A1',
            i_dim1:    'L60*W12*H4mm',
            i_dim2:    '1m',
            i_cblcpty: '1:16F',
            i_conntr:  'LC/APC',
            i_cmpownr: 'VelocityFibre',
            i_mun:     'JB Marks LM',
            i_sub:     '676007',
            i_main:    '676007',
            i_stack:   'MOA',
        }

        attr_map = {}
        missing_fts = set()
        skipped_no_olt = 0

        for pon, feats in by_pon.items():
            olt = fts_olt.get(pon)
            if not olt:
                missing_fts.add(pon)
                olt = pon_to_port.get(pon)
                if not olt:
                    # Don't poison the label with 'C??P??'. Skip; warn.
                    skipped_no_olt += len(feats)
                    continue
            feats_sorted = sorted(feats, key=lambda f: str(f['strtfeat']))
            for leg, feat in enumerate(feats_sorted, start=1):
                pole = str(feat['strtfeat']).replace('MOA.P.', '')
                new_label = f"MOA.STS.16.DIS.DM.P.{pole}.{olt}.L{leg}"

                row = {}
                # Label: only write if NULL or differs (preserve manual)
                if i_label >= 0:
                    cur = feat['label']
                    if _is_blank(cur):
                        row[i_label] = new_label
                    elif str(cur) != new_label:
                        # Existing label disagrees — overwrite (FT4b owns this).
                        row[i_label] = new_label
                # Static defaults: fill-null-only
                for fidx, val in STATIC.items():
                    if fidx < 0: continue
                    fname = feat.fields().at(fidx).name()
                    if _is_blank(feat[fname]):
                        row[fidx] = val
                if row:
                    attr_map[feat.id()] = row

        if attr_map:
            layer.dataProvider().changeAttributeValues(attr_map)
        layer.triggerRepaint()

        if missing_fts:
            feedback.pushWarning(f"No FTS found for PONs: {sorted(missing_fts)} — used PON v1 port as fallback. "
                                 "Add FTS Splitters v1 for these PONs then re-run FT 4b.")
        if skipped_no_olt:
            feedback.pushWarning(f"{skipped_no_olt} STS features skipped (no FTS and no PON v1 fallback) — "
                                 "no 'C??P??' poison written.")
        if skipped_null:
            feedback.pushWarning(f"{skipped_null} STS features skipped (NULL pon_no or strtfeat).")
        feedback.pushInfo(f"[OK] STS Splitters: {len(attr_map)} rows touched (fill-null + label refresh).")
        return {self.INPUT: layer.id()}

    def createInstance(self):
        return FTSTSAlgorithm()
