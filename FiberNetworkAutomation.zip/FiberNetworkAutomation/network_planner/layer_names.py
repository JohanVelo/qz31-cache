"""Layer-name resolver — one place that knows what a LAYER is called.

Why this exists
---------------
``field_names.py`` solves this problem one level down: code asks for a ROLE
("the PON id") and gets back whatever that particular layer calls the column.
Its docstring says why a find-and-replace was not an option — those names are
written into data already on disk, and renaming would strand all of it.

Exactly the same is true of LAYER names, and worse. A cross-check on
2026-09-11 read six of our own projects — Lulekani, Matiko, Ventersdorp,
Malmesbury, Mohadin PH2 and fibre_template — and found **189 distinct layer
names for about twenty things**, in three unrelated conventions:

    Lulekani / Matiko      PON Drop Cables, PON Splitter Points, PON Groups
    Template / Mohadin     Drop Cable v1, Poles, PON v1, Zones v1
    Ventersdorp            Drops  7,554  (159,598 m)   <- the COUNT, in the name

Matched by name, 9 of 15 canonical layers had only two towns behind them.
Matched by ROLE, 8 of 10 concepts were present in all six. Nothing about the
data changed; only what was compared. So, per JJ's decision of 2026-09-11, we
do not pick a winning name. Every name becomes an alias of a role.

    lyr  = find_layer(project, DROP_CABLE)      # read: any convention
    name = new_layer_name(DROP_CABLE)           # write: one convention

How matching works, and why it is boring on purpose
---------------------------------------------------
Two stages, and NEITHER of them is a fuzzy pattern:

1. ``normalise()`` strips the decorations that turn out to explain nearly all
   the drift, and which are purely mechanical: a ``(sb)`` sandbox marker, a
   ``v1`` suffix, a stage word (``Final``/``P``/``Perm``), a town prefix, and
   Ventersdorp's baked-in counts and colour keys.
2. the normalised string is looked up in an EXACT alias table.

A regex like ``/distribution/`` would be shorter and would happily return
``Distribution Poles`` when asked for ``Distribution Cable``. ``field_names.py``
records what that class of bug costs: ``BF_PON's`` failed to resolve, the merge
tool fell through to the next polygon layer carrying a PON column, and that was
A DIFFERENT TOWN'S BOUNDARIES. Silently returning the wrong layer is far worse
than returning nothing, so:

**An unknown name resolves to None, and an ambiguous role returns nothing.**
``unresolved()`` lists what did not match, so a layer we have never seen is
visible rather than absorbed.

Pure Python: no QGIS imports, so this is testable headless. Anything exposing
``.mapLayers()`` — or a plain list of names — can be passed in.
"""

import re

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

# ── Roles ────────────────────────────────────────────────────────────────────
# Stable identifiers. The strings are arbitrary keys and are NEVER written to
# data or shown to a user.
#
# These are deliberately FINE-GRAINED. The tempting coarse bucket "cable" would
# merge four tiers that cost different money and splice differently, and "pole"
# would merge feeder and distribution poles, which are different products. Where
# the data distinguishes two things, so does this table.
ERVEN = "erven"
AOI = "aoi"
ROADS = "roads"
POP = "pop"

DEMAND_POINT = "demand_point"
ONT = "ont"
HOME_CONNECTION = "home_connection"

POLE = "pole"                          # an undifferentiated pole layer
DISTRIBUTION_POLE = "distribution_pole"
FEEDER_POLE = "feeder_pole"

DROP_CABLE = "drop_cable"
SPARE_DROP_CABLE = "spare_drop_cable"  # ⛔ NOT a drop: a spare goes nowhere
DISTRIBUTION_CABLE = "distribution_cable"
FEEDER_CABLE = "feeder_cable"
PRIMARY_CABLE = "primary_cable"
SECONDARY_CABLE = "secondary_cable"
LINK_CABLE = "link_cable"
SPUR_CABLE = "spur_cable"
SPAN = "span"

PON = "pon"                            # the PON zone polygons
PON_GROUP = "pon_group"                # groups of 8 within a PON
SPLITTER_POINT = "splitter_point"
STS_SPLITTER = "sts_splitter"
FTS_SPLITTER = "fts_splitter"

BUILDING = "building"
DUCT = "duct"
MANHOLE = "manhole"
TRENCHING = "trenching"
ROAD_CROSSING = "road_crossing"
AGGREGATION_JOINT = "aggregation_joint"
AGGREGATION_POLYGON = "aggregation_polygon"
SPUR_JOINT = "spur_joint"
NODE = "node"
CORE = "core"
BLOCK = "block"
MDU = "mdu"
OVERBUILD = "overbuild"

ENCLOSURE = "enclosure"
ENCLOSURE_SPLICE = "enclosure_splice"
ENCLOSURE_CONNECTORISED = "enclosure_connectorised"
DOME_JOINT = "dome_joint"
FEEDER_JOINT = "feeder_joint"
LINK_JOINT = "link_joint"

# ── Decoration stripping ─────────────────────────────────────────────────────
# Every pattern here was derived from a real name in the six-project census. A
# decoration is something that does not change WHAT THE LAYER IS.

#: "(sb)" sandbox marker — 15 layers in Mohadin PH2.
_SANDBOX = re.compile(r"\s*\(sb\)\s*$", re.I)

#: A trailing version suffix. 37 layers across Template and Mohadin PH2 carry
#: " v1", and there has never been a v2 anywhere to say what it counts.
_VERSION = re.compile(r"\s+v\d+\s*$", re.I)

#: Stage words a layer picks up on its way through a project. "P" is Lulekani's
#: marker for the exported (permanent) copy of a memory layer.
_STAGE = re.compile(r"\s+(final|perm|permanent|p)\s*$", re.I)

#: Ventersdorp writes the feature COUNT and often a length into the layer name:
#:   "Drops  7,554  (159,598 m)"   "1:8 splitters  1,289"   "Road crossings  469"
#: Every one of those numbers is wrong the moment anyone edits the layer.
_COUNT_TAIL = re.compile(r"\s{2,}[\d][\d,\. ]*\s*$")

#: A trailing parenthetical NOTE: "(network origin)", "(operator's wayleave)",
#: "(orange = feeder 7 m, red = distribution)", "(CSG cadastre)", "(studio)".
#:
#: ⛔ NOT every parenthetical is a note. "Manual Enclosures (FS)" and "Manual
#: Enclosures (FTS)" differ ONLY inside the brackets, and stripping it would
#: collapse two different splitter tiers onto one name — the exact silent
#: mis-resolution this module exists to prevent. So an all-caps acronym of 2-5
#: letters is treated as part of the name and kept; anything else is a note.
_PAREN_TAIL = re.compile(r"\s*\((?![A-Z]{2,5}\)\s*$)[^()]*\)\s*$")

#: A leading town name. Passed in rather than hardcoded — "Lulekani Distribution"
#: and "Matiko Distribution Final" are the same layer, and the only thing that
#: makes that knowable is knowing the town.
def _strip_town(name, town):
    if not town:
        return name
    for t in (town, town.replace(" ", "")):
        if not t:
            continue
        rx = re.compile(r"^\s*%s[\s\-_]+" % re.escape(t), re.I)
        stripped = rx.sub("", name)
        if stripped != name:
            return stripped
    return name


def normalise(name, town=None):
    """Strip mechanical decoration from a layer name, leaving the concept.

        "Drop Cable (sb)"            -> "drop cable"
        "PON Drop Cables P"          -> "pon drop cables"
        "Drops  7,554  (159,598 m)"  -> "drops"
        "Lulekani Distribution"      -> "distribution"      (town="Lulekani")

    Applied repeatedly until nothing more comes off, because real names stack
    them: "Poles  3,612  (orange = feeder 7 m, red = distribution)" carries a
    count AND a parenthetical, and Matiko's whole tree also has trailing spaces.
    """
    # ⛔ Whitespace is NOT collapsed until the very end. The double space in
    # "Drops  7,554" is the only thing separating a decoration from a name that
    # legitimately contains a number, and collapsing first silently disarmed
    # _COUNT_TAIL — it matched nothing and every Ventersdorp layer kept its
    # stale count.
    out = str(name or "").strip()
    out = _strip_town(out, town)
    for _ in range(6):                       # bounded; 3 is the deepest seen
        before = out
        for rx in (_SANDBOX, _PAREN_TAIL, _COUNT_TAIL, _VERSION, _STAGE):
            out = rx.sub("", out).strip()
        if out == before:
            break
    return " ".join(out.split()).lower()


#: role -> accepted layer names, MOST PREFERRED FIRST. Compared AFTER
#: normalise(), so no entry needs its own "(sb)"/" v1"/" Final" variants.
#:
#: Every name below was observed in at least one of the six projects. Nothing is
#: invented: a name nobody has ever produced would make `unresolved()` quieter
#: without making anything more correct.
ALIASES = {
    ERVEN:            ("erven",),
    AOI:              ("aoi", "p2 aoi poly", "gob_fullaoi"),
    ROADS:            ("roads", "road", "osm roads", "highway"),
    POP:              ("pop",),

    DEMAND_POINT:     ("demand points", "demand point", "demand", "centroids",
                       "ai centroids"),
    ONT:              ("ont",),
    HOME_CONNECTION:  ("home connection",),

    # ⛔ "poles" undifferentiated must come LAST in any caller's preference, but
    # it is its own role here: Malmesbury and Template really do carry a single
    # mixed pole layer, and pretending it is one tier would be a guess.
    POLE:             ("poles", "pole", "poles_40m"),
    DISTRIBUTION_POLE: ("distribution poles",),
    FEEDER_POLE:      ("feeder poles",),

    DROP_CABLE:       ("drop cable", "drop cables", "drops", "drop_cables",
                       "pon drop cable", "pon drop cables"),
    # ⛔ A spare drop is NOT a drop. It terminates nowhere and is counted
    # separately in the BOQ; folding it into DROP_CABLE would double-count homes.
    SPARE_DROP_CABLE: ("spare drop cable", "spare drop cables"),
    DISTRIBUTION_CABLE: ("distribution cable", "distribution cables",
                         "distribution"),
    FEEDER_CABLE:     ("feeder cable", "feeder cables", "feeder"),
    PRIMARY_CABLE:    ("primary cable", "primary cables"),
    SECONDARY_CABLE:  ("secondary cable", "secondary cables"),
    LINK_CABLE:       ("link cable", "link cables"),
    SPUR_CABLE:       ("spur cable", "spur cables"),
    SPAN:             ("span",),

    PON:              ("pon", "pons", "zones", "pon zones", "pon boundaries",
                       "pon zone boundaries"),
    PON_GROUP:        ("pon groups", "pon group"),
    SPLITTER_POINT:   ("splitter points", "splitter_points",
                       "pon splitter points", "collection points"),
    STS_SPLITTER:     ("sts splitters", "sts splitter"),
    FTS_SPLITTER:     ("fts splitters", "fts splitter",
                       "first tier splitters", "manual enclosures (fts)"),

    ENCLOSURE:        ("enclosure", "enclosures"),
    ENCLOSURE_SPLICE: ("enclosures splice", "enclosure splice"),
    ENCLOSURE_CONNECTORISED: ("enclosures connectorised",
                              "enclosure connectorised"),
    DOME_JOINT:       ("dome joint", "dome joints"),
    FEEDER_JOINT:     ("feeder joints", "feeder joint",
                       "feeder enclosures", "manual enclosures (fs)"),
    LINK_JOINT:       ("link joints", "link joint"),
    SPUR_JOINT:       ("spur joints", "spur joint"),
    AGGREGATION_JOINT: ("aggregation joint", "aggregation joints",
                        "aggregation_points"),
    AGGREGATION_POLYGON: ("aggregation polygon", "aggregation polygons"),

    BUILDING:         ("buildings", "building", "greenfield buildings",
                       "overbuild buildings"),
    DUCT:             ("ducts", "duct"),
    # "Muncipality vaults" is Malmesbury's spelling, typo and all. Recording the
    # typo is the whole point of an alias table.
    MANHOLE:          ("manholes", "manhole", "access chamber",
                       "muncipality vaults", "municipality vaults"),
    TRENCHING:        ("trenching", "hdd drills"),
    ROAD_CROSSING:    ("road crossings", "road crossing",
                       "road crossing underground"),
    NODE:             ("node", "nodes"),
    CORE:             ("core",),
    BLOCK:            ("block", "blocks"),
    MDU:              ("mdu's", "mdus", "mdu"),
    # Greenfield vs overbuild footprint. A real planning input - it decides
    # which homes are new build and which already have a service - so it is a
    # role, not furniture. `Overbuild Buildings` is deliberately NOT here: that
    # one is a building layer and belongs to BUILDING.
    OVERBUILD:        ("overbuild", "overbuild poly", "overbuild area",
                       "greenfield and overbuild poly"),
}

#: role -> the name to use when CREATING a layer.
#:
#: These follow the family the plugin's own source already emits — 53 references
#: to "PON", 38 to "ONT", 24 to "Poles" — MINUS the " v1" suffix, which is a
#: version number inside a layer name with no v2 anywhere to give it meaning.
#: Per JJ's decision this is a changeable default, not a migration: changing an
#: entry here changes what NEW layers are called and strands nothing, because
#: everything old still resolves through ALIASES.
NEW_NAMES = {
    ERVEN: "Erven",
    AOI: "AOI",
    ROADS: "Roads",
    POP: "POP",
    DEMAND_POINT: "Demand Points",
    ONT: "ONT",
    HOME_CONNECTION: "Home Connection",
    POLE: "Poles",
    DISTRIBUTION_POLE: "Distribution Poles",
    FEEDER_POLE: "Feeder Poles",
    DROP_CABLE: "Drop Cable",
    SPARE_DROP_CABLE: "Spare Drop Cable",
    DISTRIBUTION_CABLE: "Distribution Cable",
    FEEDER_CABLE: "Feeder Cable",
    PRIMARY_CABLE: "Primary Cable",
    SECONDARY_CABLE: "Secondary Cable",
    LINK_CABLE: "Link Cable",
    SPUR_CABLE: "Spur Cable",
    SPAN: "Span",
    PON: "PON",
    PON_GROUP: "PON Groups",
    SPLITTER_POINT: "Splitter Points",
    STS_SPLITTER: "STS Splitters",
    FTS_SPLITTER: "FTS Splitters",
    ENCLOSURE: "Enclosure",
    ENCLOSURE_SPLICE: "Enclosures Splice",
    ENCLOSURE_CONNECTORISED: "Enclosures Connectorised",
    DOME_JOINT: "Dome Joints",
    FEEDER_JOINT: "Feeder Joints",
    LINK_JOINT: "Link Joints",
    SPUR_JOINT: "Spur Joints",
    AGGREGATION_JOINT: "Aggregation Joint",
    AGGREGATION_POLYGON: "Aggregation Polygon",
    BUILDING: "Buildings",
    DUCT: "Ducts",
    MANHOLE: "Manholes",
    TRENCHING: "Trenching",
    ROAD_CROSSING: "Road Crossings",
    NODE: "Node",
    CORE: "Core",
    BLOCK: "Block",
    MDU: "MDUs",
    OVERBUILD: "Overbuild",
}

# Built once. A name claimed by two roles is a bug in the table above, not a
# runtime condition to handle, so it is caught by assert_no_alias_collision().
_NAME_TO_ROLE = {}
for _role, _names in ALIASES.items():
    for _n in _names:
        _NAME_TO_ROLE.setdefault(_n, _role)


# ── Not network data ─────────────────────────────────────────────────────────
# Some layers in a project are not design output and never want a canonical
# name: QGIS group-tree nodes, scratch QA layers, cartography furniture. They
# are classified rather than left in `unresolved()`, because a report that lists
# thirty things nobody will ever act on stops being read.
#
# ⛔ This list does NOT contain anything we merely failed to classify. A layer we
# do not understand must stay visible; burying it here to make a number look
# better is how a resolver starts lying.

#: The Network Planner builds a layer GROUP per splitter grouping, and the group
#: nodes read back as names: "Demand Points - Groups of 8 - PON Zones". They are
#: containers, not layers.
_GROUP_NODE = re.compile(r"groups?[ _]+of[ _]+\d+", re.I)

#: Cartography and QA furniture — a grid to plot on, a page index, a progress
#: overlay, a zoning backdrop. Real layers, no network asset behind them.
_FURNITURE = frozenset({
    "anomalies", "exclude", "phases", "pon progress",
    "hld grid", "hld book pages", "plotting grid",
    "grid_ok", "grid_gap", "ramp_new",
    # Scratch QA layers. Lulekani's `issues` holds 0 features and is where
    # someone was going to record problems; it is not design output.
    "issues", "issue", "anomaly", "exclude zone",
    "business zoning", "industrial zoning", "residential zoning",
    "special zoning",
})

#: Scratch: an experiment, an export, a demo. `temp_`/`exp_` prefixes and an
#: explicit "(build demo)" marker.
_SCRATCH = re.compile(r"^(?:temp|tmp|exp|scratch|test)[_\- ]|\(build demo\)|"
                      r"^_|\(sam\)$|\(studio\)$", re.I)


def is_out_of_scope(name, town=None):
    """True for a layer that is not network design output.

    Checked against the RAW name as well as the normalised one, because the
    markers that identify furniture — a leading underscore, a "(build demo)"
    suffix — are themselves the kind of thing normalise() strips.
    """
    raw = " ".join(str(name or "").split())
    norm = normalise(name, town)
    if _GROUP_NODE.search(raw) or _GROUP_NODE.search(norm):
        return True
    if _SCRATCH.search(raw):
        return True
    return norm in _FURNITURE


def layer_names(project):
    """Layer names for a QgsProject, a list of layers, or a list of strings.

    Duck-typed for the same reason field_names() is: so the resolver can be
    tested with a list of strings and no QGIS in the process.
    """
    if project is None:
        return []
    getter = getattr(project, "mapLayers", None)
    if callable(getter):
        try:
            return [lyr.name() for lyr in getter().values()]
        except Exception:
            _swallowed_note()
    out = []
    try:
        for item in project:
            out.append(item.name() if hasattr(item, "name") else str(item))
    except TypeError:
        return []
    return out


def role_of(name, town=None):
    """The role this layer name denotes, or None if we have never seen it.

    None is a real answer and callers must handle it. Guessing is how a resolver
    hands back another town's boundaries.
    """
    return _NAME_TO_ROLE.get(normalise(name, town))


def roles_in(project, town=None):
    """{role: [layer names]} for everything in the project we recognise."""
    found = {}
    for name in layer_names(project):
        role = role_of(name, town)
        if role is not None:
            found.setdefault(role, []).append(name)
    return found


def unresolved(project, town=None):
    """Layer names that match no role AND are not classifiable as non-data.

    The point of the module. A layer nobody has taught the table about is
    reported here rather than quietly skipped, so the gap is visible the first
    time it appears instead of the first time it costs something.
    """
    return [n for n in layer_names(project)
            if role_of(n, town) is None and not is_out_of_scope(n, town)]


def out_of_scope(project, town=None):
    """Layer names deliberately classified as not network data."""
    return [n for n in layer_names(project) if is_out_of_scope(n, town)]


def find_layer(project, role, town=None):
    """The ONE layer for ``role``, or None if there is not exactly one.

    Ambiguity returns None on purpose. Two layers claiming a role means the
    project has a copy, a leftover or a rename half-done, and picking one of
    them silently is the failure this module exists to prevent — use
    find_layers() when you want to see them all.
    """
    hits = find_layers(project, role, town=town)
    return hits[0] if len(hits) == 1 else None


def find_layers(project, role, town=None):
    """Every layer matching ``role``, in project order."""
    getter = getattr(project, "mapLayers", None)
    if callable(getter):
        try:
            return [lyr for lyr in getter().values()
                    if role_of(lyr.name(), town) == role]
        except Exception:
            _swallowed_note()
    return [n for n in layer_names(project) if role_of(n, town) == role]


def new_layer_name(role):
    """The layer name to CREATE for ``role``."""
    return NEW_NAMES[role]


# ── Safety net ───────────────────────────────────────────────────────────────

def assert_no_alias_collision():
    """Raise if one alias is claimed by two roles, or a role cannot be written.

    The first is the dangerous one: a colliding alias makes role_of() depend on
    dict ordering, so the resolver would return a different layer depending on
    how the table happened to be written. Called by the test suite.
    """
    seen, clashes = {}, []
    for role, names in ALIASES.items():
        for n in names:
            if n in seen and seen[n] != role:
                clashes.append("%r claimed by both %r and %r" % (n, seen[n], role))
            seen[n] = role
    missing = sorted(set(ALIASES) - set(NEW_NAMES))
    if missing:
        clashes.append("roles with no NEW_NAMES entry: %s" % ", ".join(missing))
    extra = sorted(set(NEW_NAMES) - set(ALIASES))
    if extra:
        clashes.append("roles with no ALIASES entry: %s" % ", ".join(extra))
    # Every canonical write name must itself resolve back to its own role,
    # or the button would rename a layer into something it can no longer find.
    for role, written in NEW_NAMES.items():
        back = role_of(written)
        if back != role:
            clashes.append("NEW_NAME %r for %r resolves back to %r"
                           % (written, role, back))
    if clashes:
        raise AssertionError("layer_names alias table is unsafe:\n  "
                             + "\n  ".join(clashes))
    return True
