"""Starter labeling presets + on-disk preset registry for the Labeling
Wizard.

The labeling structure is FULLY customizable per client + per project —
nothing here is fixed.  STARTER_PRESETS merely ships sensible, editable
defaults (one or more per client) expressed as numbering.HierarchyConfig
objects; a user edits/saves their own variants through PresetStore, which
persists them as JSON (HierarchyConfig.to_dict()/from_dict()) in the QGIS
settings dir.  resolve() overlays user presets on the starters — the user
always wins.

Pure Python stdlib at import time — QGIS is only touched lazily (and
optionally) to locate the default presets file, so this module imports
identically inside QGIS 4.0.3 python and plain Python 3.12 for tests.

FTTH NAMING GRAMMAR (reference — encoded in ELEMENT_CODES below)
----------------------------------------------------------------
Universal label pattern seen across SA FTTH clients:

    [OWNER_]PROJECT[_ZONE].[CODE][SEQ][_QUALIFIERS]

  e.g.  MOA.P.H123        (project MOA, pole, walk-order seq 123)
        PRAK-Z03-P0042    (project PRAK, zone 3, pole 42)
        Z17_DC03.S02      (zone 17, distribution run 3, STS 2)
        DR1853300         (bare drop number)

Element codes:  PL/P = pole · DR = drop · DJ = dome (splice joint) ·
SP = splitter · AG = aggregation · FC/SC = feeder (primary/secondary) ·
DC = distribution · ONT = optical network terminal · POP = point of
presence · FTS = fibre terminal splitter · STS = subscriber terminal
splitter.

API:
    ELEMENT_CODES, element_code(role)
    STARTER_PRESETS                    {client: {preset_name: HierarchyConfig}}
    starter_preset(client, name)       fresh (mutation-safe) copy of a starter
    PresetStore(path=None)             .list_presets() .get() .save()
                                       .delete() .resolve()
"""
import json
import os

try:                                   # package import (FiberNetworkAutomation
    from .numbering import HierarchyConfig, Level   # .network_planner.presets)
except ImportError:                    # flat import (root fibre_automation)
    from numbering import HierarchyConfig, Level


# ---------------------------------------------------------------------------
# FTTH element-code reference
# ---------------------------------------------------------------------------

#: Canonical element code per network role — the CODE part of the universal
#: "[OWNER_]PROJECT[_ZONE].[CODE][SEQ][_QUALIFIERS]" grammar.  Synonyms map
#: to the same code; this is a *reference*, not an enforced vocabulary.
ELEMENT_CODES = {
    "pole": "PL",
    "p": "P",                          # short pole form (e.g. MOA.P.H123)
    "drop": "DR",
    "dome": "DJ",                      # splice/joint dome
    "joint": "DJ",
    "splitter": "SP",
    "aggregation": "AG",
    "agg": "AG",
    "feeder": "FC",
    "primary_feeder": "FC",
    "secondary_feeder": "SC",
    "distribution": "DC",
    "ont": "ONT",
    "pop": "POP",
    "fts": "FTS",                      # fibre terminal splitter (1 per PON)
    "sts": "STS",                      # subscriber terminal splitter
    "demand": "DP",                    # demand point / home
}


def element_code(role):
    """Canonical element code for a role name (case/space-insensitive).

    >>> element_code("Pole")
    'PL'
    Unknown roles return the role upper-cased so a custom tier still gets a
    usable code instead of raising.
    """
    key = str(role).strip().lower().replace(" ", "_").replace("-", "_")
    return ELEMENT_CODES.get(key, str(role).strip().upper())


# ---------------------------------------------------------------------------
# starter presets — EXAMPLES ONLY, every knob is editable per project
# ---------------------------------------------------------------------------

def _herotel_pon_per_zone():
    """HeroTel-style per-zone PON hierarchy (the proven Matiko structure).

    FTS (root, one per zone) -> DISTRIBUTION runs (may branch into further
    DISTRIBUTION runs — trunk -> sub-trunk — numbered flat per FTS via
    restart="root") -> STS -> DROP -> DEMAND.
    """
    return HierarchyConfig(name="HeroTel PON per Zone", levels=(
        Level("FTS", "FTS", None, kind="point", fmt="FTS{n:02d}"),
        Level("DIST", "DISTRIBUTION", ("FTS", "DIST"), kind="cable",
              restart="root", fmt="Z{zone}_DC{n:02d}"),
        Level("STS", "STS", "DIST", kind="point", fmt="{parent}.S{n:02d}"),
        Level("DROP", "DROP", "STS", kind="cable"),
        Level("DEMAND", "DEMAND", "DROP", kind="point"),
    ))


def _fibertime_pole_drop_ont():
    """Fibertime-style pole/drop/ONT hierarchy.

    Poles are numbered in feeder-walk order ("{proj}.P.H{n}"); drops get a
    bare global sequence ("DR{n}"); the ONT re-uses its drop's label
    ("{proj}.ONT.{parent}" -> e.g. MOA.ONT.DR123).  The project code lives
    in constants — change it there, not in the templates.
    """
    return HierarchyConfig(
        name="Fibertime Pole/Drop/ONT",
        constants={"proj": "MOA"},     # editable default, NOT fixed
        levels=(
            Level("POLE", "POLE", None, kind="point", mode="walk_order",
                  fmt="{proj}.P.H{n}"),
            Level("DROP", "DROP", "POLE", kind="cable", mode="sequential",
                  fmt="DR{n}"),
            Level("ONT", "ONT", "DROP", kind="point",
                  fmt="{proj}.ONT.{parent}"),
        ))


def _vuma_zone_pole_dome():
    """Vuma-style zoned pole numbering with splice domes.

    Poles restart per containing zone polygon ("{proj}-Z{zone:02d}-P{n:04d}"
    — needs zone polygons with integer ids); domes ride a plain global
    sequence ("DJ{n:03d}").  proj is an editable constant.
    """
    return HierarchyConfig(
        name="Vuma Zone/Pole/Dome",
        constants={"proj": "PRAK"},    # editable default, NOT fixed
        levels=(
            Level("POLE", "POLE", None, kind="point", mode="spatial_polygon",
                  fmt="{proj}-Z{zone:02d}-P{n:04d}"),
            Level("DOME", "DOME", "POLE", kind="point", mode="sequential",
                  fmt="DJ{n:03d}"),
        ))


def _generic_pole_drop():
    """Plain 2-level pole -> drop example (drop uses the default
    "{parent}{sep}{n:0{pad}d}" template)."""
    return HierarchyConfig(name="Generic Pole/Drop", levels=(
        Level("POLE", "POLE", None, kind="point", fmt="P{n:03d}"),
        Level("DROP", "DROP", "POLE", kind="cable"),
    ))


#: Shipped defaults: {client: {preset_name: HierarchyConfig}}.  These are
#: STARTING POINTS — the wizard copies one, the user edits every level, and
#: PresetStore.save() persists the result (which then shadows the starter).
STARTER_PRESETS = {
    "HeroTel": {"PON per Zone": _herotel_pon_per_zone()},
    "Fibertime": {"Pole/Drop/ONT": _fibertime_pole_drop_ont()},
    "Vuma": {"Zone/Pole/Dome": _vuma_zone_pole_dome()},
    "Generic": {"Pole/Drop": _generic_pole_drop()},
}


def _copy_config(config):
    """Fresh, mutation-safe copy (starters must never be edited in place)."""
    return HierarchyConfig.from_dict(config.to_dict())


def starter_preset(client, name):
    """Fresh copy of a shipped starter preset (KeyError if unknown)."""
    return _copy_config(STARTER_PRESETS[client][name])


# ---------------------------------------------------------------------------
# preset store — user presets on disk, merged over the starters
# ---------------------------------------------------------------------------

_STORE_SUBPATH = ("velocity_nexus", "label_presets.json")
_STORE_VERSION = 1


def _default_store_path():
    """Presets file inside the active QGIS profile, or None w/o QGIS.

    Lazy + optional QGIS import so this module (and PresetStore with an
    explicit path) works in plain Python for tests.
    """
    try:
        from qgis.core import QgsApplication
        base = QgsApplication.qgisSettingsDirPath()
    except Exception:                  # no QGIS in this interpreter
        return None
    if not base:
        return None
    return os.path.join(base, *_STORE_SUBPATH)


class PresetStore:
    """Save/load user labeling presets per client (JSON on disk).

    File layout: {"version": 1,
                  "presets": {client: {name: HierarchyConfig.to_dict()}}}

    User presets OVERLAY the shipped STARTER_PRESETS: resolve()/get()/
    list_presets() see the merged view (user wins on a client+name clash);
    save()/delete() touch only the user file.  Deleting a user preset that
    shadows a starter simply reverts to the starter.
    """

    def __init__(self, path=None, starters=None):
        if path is None:
            path = _default_store_path()
        if not path:
            raise ValueError(
                "PresetStore: QGIS is not importable here — pass an explicit "
                "JSON file path (e.g. PresetStore(path='...'))")
        self.path = str(path)
        self.starters = STARTER_PRESETS if starters is None else starters
        self.last_error = None         # last load/parse problem, if any

    # -- disk I/O -----------------------------------------------------------

    def _load_raw(self):
        """{client: {name: config_dict}} from disk ({} if absent/corrupt)."""
        self.last_error = None
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except FileNotFoundError:
            return {}
        except (OSError, ValueError) as exc:  # unreadable / corrupt JSON —
            self.last_error = str(exc)        # fail soft, keep starters
            return {}
        presets = data.get("presets") if isinstance(data, dict) else None
        return presets if isinstance(presets, dict) else {}

    def _save_raw(self, presets):
        """Atomic write (tmp file + os.replace) so a crash can't corrupt."""
        directory = os.path.dirname(self.path)
        if directory:
            os.makedirs(directory, exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump({"version": _STORE_VERSION, "presets": presets},
                      fh, indent=2, sort_keys=True)
        os.replace(tmp, self.path)

    # -- merged view --------------------------------------------------------

    def resolve(self):
        """Merged {client: {name: HierarchyConfig}} — user overrides win.

        Every returned config is a fresh copy: editing it never mutates a
        starter or the store; call save() to persist an edit.  A stored
        preset that no longer parses is skipped (recorded in last_error)
        rather than sinking the whole registry.
        """
        merged = {}
        for client, named in self.starters.items():
            merged[client] = {name: _copy_config(cfg)
                              for name, cfg in named.items()}
        for client, named in self._load_raw().items():
            if not isinstance(named, dict):
                continue
            bucket = merged.setdefault(client, {})
            for name, d in named.items():
                try:
                    bucket[name] = HierarchyConfig.from_dict(d)
                except (KeyError, TypeError, ValueError) as exc:
                    self.last_error = "preset %r/%r: %s" % (client, name, exc)
        return merged

    def list_presets(self, client=None):
        """Sorted preset names for one client, or {client: [names]} for all
        (starters + user presets merged)."""
        merged = self.resolve()
        if client is not None:
            return sorted(merged.get(client, {}))
        return {c: sorted(named) for c, named in sorted(merged.items())}

    def get(self, client, name):
        """The merged preset (fresh copy) — KeyError if it doesn't exist."""
        merged = self.resolve()
        try:
            return merged[client][name]
        except KeyError:
            raise KeyError("no preset %r for client %r (have: %s)"
                           % (name, client,
                              sorted(merged.get(client, {})) or "none"))

    # -- user-preset mutation -----------------------------------------------

    def save(self, client, name, config):
        """Persist a user preset (overwrites same client+name; shadows any
        starter of that name).  config must be a HierarchyConfig with
        JSON-safe (non-callable) fmt templates."""
        if not isinstance(config, HierarchyConfig):
            raise TypeError("save() wants a HierarchyConfig, got %r"
                            % type(config).__name__)
        presets = self._load_raw()
        presets.setdefault(str(client), {})[str(name)] = config.to_dict()
        self._save_raw(presets)

    def delete(self, client, name):
        """Remove a USER preset; True if one was removed.  Starters cannot
        be deleted — deleting a user override reverts to the starter."""
        presets = self._load_raw()
        named = presets.get(client)
        if not named or name not in named:
            return False
        del named[name]
        if not named:
            del presets[client]
        self._save_raw(presets)
        return True


# ---------------------------------------------------------------------------
# self-test (plain python — no QGIS)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import tempfile

    # every starter must round-trip to_dict/from_dict losslessly
    for _client, _named in STARTER_PRESETS.items():
        for _name, _cfg in _named.items():
            _again = HierarchyConfig.from_dict(_cfg.to_dict())
            assert _again == _cfg, "round-trip failed: %s/%s" % (_client,
                                                                 _name)

    # element codes
    assert element_code("Pole") == "PL"
    assert element_code("distribution") == "DC"
    assert element_code("My Custom Tier") == "MY CUSTOM TIER"

    # store: save / get / list / delete / resolve with user-wins overlay
    with tempfile.TemporaryDirectory() as _tmp:
        _store = PresetStore(path=os.path.join(_tmp, "presets.json"))
        _mine = starter_preset("Generic", "Pole/Drop")
        _mine = HierarchyConfig(levels=_mine.levels, name="my tweak",
                                constants={"proj": "TEST"})
        _store.save("Generic", "Pole/Drop", _mine)        # shadow a starter
        _store.save("Acme", "Site A", _mine)              # brand-new client
        assert _store.get("Generic", "Pole/Drop") == _mine    # user wins
        assert _store.get("Acme", "Site A") == _mine
        assert "Acme" in _store.list_presets()
        assert _store.list_presets("HeroTel") == ["PON per Zone"]
        assert _store.delete("Generic", "Pole/Drop") is True  # revert...
        assert _store.get("Generic", "Pole/Drop") == \
            STARTER_PRESETS["Generic"]["Pole/Drop"]           # ...to starter
        assert _store.delete("Generic", "Pole/Drop") is False
        # returned configs are copies — mutating one never leaks back
        _got = _store.get("Fibertime", "Pole/Drop/ONT")
        _got.constants["proj"] = "XXX"
        assert STARTER_PRESETS["Fibertime"]["Pole/Drop/ONT"] \
            .constants["proj"] == "MOA"

    print("presets OK")
