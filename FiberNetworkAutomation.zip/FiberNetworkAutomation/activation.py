"""activation — company password gate for Velocity Nexus.

Design (build prompt §5):
- Verification = SHA256(SALT + entered) compared against the embedded digest.
  The plaintext password NEVER ships — only this salt + digest pair.
- On success a machine-local token (hash of digest + machine id) is stored in
  QgsSettings 'VelocityFibre/activation'; the plaintext is never stored either.
  The token survives plugin upgrades (settings live outside the plugin folder).
- 5 wrong attempts → 60 s lockout.

Honest threat model: this gate deters outsiders and casual sharing of the zip.
A determined reader of this Python file can bypass it (as can the Processing
Toolbox). That is accepted — it is a deterrent, not a vault.
"""
import hashlib
import os
import platform
import time

_SALT = 'vf-a8Qz31x-moa'
_DIGEST = 'cc3fe39b5f7e1c5168f0ec4052a99c8b900a095ba5d420e662246780b7566bd2'
_SETTINGS_KEY = 'VelocityFibre/activation'
_MAX_ATTEMPTS = 5
_LOCKOUT_S = 60

_attempts = 0
_locked_until = 0.0


def _machine_id() -> str:
    user = os.environ.get('USERNAME') or os.environ.get('USER') or ''
    return platform.node() + '|' + user


def _machine_token() -> str:
    return hashlib.sha256((_DIGEST + _machine_id()).encode()).hexdigest()


def is_activated() -> bool:
    from qgis.core import QgsSettings
    return QgsSettings().value(_SETTINGS_KEY, '') == _machine_token()


def deactivate():
    from qgis.core import QgsSettings
    QgsSettings().remove(_SETTINGS_KEY)


def seconds_locked() -> int:
    return max(0, int(_locked_until - time.time()))


def try_activate(password: str) -> bool:
    """Returns True and stores the machine token on success. Counts failures;
    after 5 wrong attempts callers must wait out seconds_locked()."""
    global _attempts, _locked_until
    if seconds_locked() > 0:
        return False
    if hashlib.sha256((_SALT + password).encode()).hexdigest() == _DIGEST:
        from qgis.core import QgsSettings
        QgsSettings().setValue(_SETTINGS_KEY, _machine_token())
        _attempts = 0
        return True
    _attempts += 1
    if _attempts >= _MAX_ATTEMPTS:
        _locked_until = time.time() + _LOCKOUT_S
        _attempts = 0
    return False


class ActivationDialog:
    """Branded activation dialog. Use ActivationDialog(iface).exec() → bool activated."""

    def __init__(self, iface):
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel, QLineEdit,
                                         QPushButton, QHBoxLayout)
        from qgis.PyQt.QtCore import QTimer

        self.iface = iface
        self.dlg = QDialog(iface.mainWindow())
        self.dlg.setWindowTitle('Velocity Nexus — Activation')
        self.dlg.setMinimumWidth(420)
        lay = QVBoxLayout(self.dlg)
        lay.setContentsMargins(18, 14, 18, 14)
        lay.setSpacing(10)

        lay.addWidget(QLabel('Enter the company password to unlock all tools on this machine.\n'
                             'You only need to do this once — it survives updates.'))
        self.edit = QLineEdit()
        self.edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.edit.setPlaceholderText('Company password')
        lay.addWidget(self.edit)
        self.status = QLabel('')
        self.status.setStyleSheet('color:#8b2450')
        lay.addWidget(self.status)

        row = QHBoxLayout()
        ok = QPushButton('Activate')
        ok.setDefault(True)
        cancel = QPushButton('Cancel')
        row.addStretch(1)
        row.addWidget(ok)
        row.addWidget(cancel)
        lay.addLayout(row)

        ok.clicked.connect(self._on_ok)
        cancel.clicked.connect(self.dlg.reject)
        self.edit.returnPressed.connect(self._on_ok)

        # Velocity Nexus theme (branding/ — Phase 2)
        try:
            try:
                from .branding import vf_style
            except ImportError:
                from branding import vf_style
            vf_style.apply_vf_style(self.dlg, title='Activation')
            vf_style.mark_secondary(cancel)
        except Exception as e:  # never let theming break activation
            print(f'[FiberNet] activation theming failed: {e}')
        self._timer = QTimer(self.dlg)
        self._timer.setInterval(1000)
        self._timer.timeout.connect(self._tick)

    def _tick(self):
        s = seconds_locked()
        if s > 0:
            self.status.setText(f'Too many attempts — locked for {s}s')
        else:
            self._timer.stop()
            self.status.setText('You can try again now.')

    def _on_ok(self):
        s = seconds_locked()
        if s > 0:
            self.status.setText(f'Too many attempts — locked for {s}s')
            self._timer.start()
            return
        if try_activate(self.edit.text()):
            self.dlg.accept()
        else:
            if seconds_locked() > 0:
                self._timer.start()
                self._tick()
            else:
                self.status.setText('Wrong password.')
            self.edit.selectAll()

    def exec(self) -> bool:
        self.dlg.exec()
        return is_activated()

    # Back-compat alias (older callers used .exec_()); the Qt6 migration moved
    # call-sites to .exec().
    exec_ = exec


def show_welcome(iface, version=''):
    """Branded welcome splash shown right after a successful activation."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel, QPushButton,
                                     QHBoxLayout)
    dlg = QDialog(iface.mainWindow())
    dlg.setWindowTitle('Velocity Nexus')
    dlg.setMinimumWidth(480)
    lay = QVBoxLayout(dlg)
    lay.setContentsMargins(18, 14, 18, 16)
    lay.setSpacing(10)

    big = QLabel(f'<div style="font-size:17px; font-weight:700;">Welcome aboard! 🎉</div>'
                 f'<div style="font-size:12px; margin-top:4px;">This machine is now activated'
                 f'{(" — " + version) if version else ""}.</div>')
    big.setTextFormat(Qt.TextFormat.RichText)
    lay.addWidget(big)
    body = QLabel(
        'Everything lives under the <b>Velocity Nexus</b> menu:<br>'
        '&nbsp;&nbsp;🆕 New Project — Vuma / Fibertime / HeroTel wizard<br>'
        '&nbsp;&nbsp;🤖 AI Mapping — buildings, erven &amp; demand detection<br>'
        '&nbsp;&nbsp;✏️ Manual Planning — poles, cables, PONs, drops<br>'
        '&nbsp;&nbsp;🔌 FT Pipeline / 🏢 HeroTel — full design runs<br>'
        '&nbsp;&nbsp;✅ QA &amp; Output — audit, spans, splice plans, BOM<br><br>'
        'Lost? <b>🗺 Tool Map</b> at the bottom of the menu lists every tool.')
    body.setTextFormat(Qt.TextFormat.RichText)
    body.setWordWrap(True)
    lay.addWidget(body)

    row = QHBoxLayout()
    row.addStretch(1)
    tm = QPushButton('🗺  Open Tool Map')
    go = QPushButton("Let's plan")
    row.addWidget(tm)
    row.addWidget(go)
    lay.addLayout(row)
    go.clicked.connect(dlg.accept)

    def _tool_map():
        dlg.accept()
        try:
            import qgis.utils as _qu
            _qu.plugins['FiberNetworkAutomation']._open_tool_map()
        except Exception:
            pass
    tm.clicked.connect(_tool_map)

    try:
        try:
            from .branding import vf_style
        except ImportError:
            from branding import vf_style
        vf_style.apply_vf_style(dlg, title='Activated ✓')
        vf_style.mark_secondary(tm)
    except Exception as e:
        print(f'[FiberNet] welcome theming skipped: {e}')
    dlg.show()
    dlg.raise_()
    return dlg
