# HeroTel: HT 1 — Demand Points from Erven
# claude:intent READS the erven layer, WRITES only its own new output layer.

from collections import Counter

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsFeatureSink,
    QgsProcessing,
    QgsProcessingException,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterField,
    QgsProcessingParameterVectorLayer,
    QgsProject,
    QgsWkbTypes,
)

from .ht_base_algorithm import HeroTelBaseAlgorithm


class HT01OntPlacementAlgorithm(HeroTelBaseAlgorithm):
    """HT 1 — Demand Points: one HeroTel demand point per erf.

    The rules are measured from the delivered towns (see
    fibre_automation/herotel_layers/demand_points.py); the output columns are the
    HeroTel 'Demand Points' columns that VN 1 builds.
    """

    ERVEN = 'ERVEN'
    TYPE_FIELD = 'TYPE_FIELD'
    OUTPUT = 'OUTPUT'

    def name(self):
        return 'ht_01_ont_placement'

    def displayName(self):
        return 'HT 1 — Demand Points (from Erven)'

    def shortHelpString(self):
        return """
        <p><b>HT 1 — Demand Points.</b> Places one demand point on every erf,
        vacant stands included, the way the delivered HeroTel towns are drawn.</p>
        <ul>
          <li>The point goes on the erf's centre. If the centre falls outside the
              erf (an L-shaped or split erf), it goes just inside instead.</li>
          <li><b>Type</b> comes from the erf's <b>Key</b> column: Vacant, School,
              Church, FTTB SDU or Cell Tower when written there, otherwise SDU.
              Any other value also gives SDU, and is listed in the log.</li>
          <li><b>Count</b> is 1. <b>x</b> / <b>y</b> are longitude / latitude.</li>
          <li><b>PON</b>, <b>Phase</b> and <b>DJ Num</b> stay empty: HT 2 and HT 3
              fill them.</li>
        </ul>
        <p>The erven layer is only read. The result is a new layer with the
        HeroTel Demand Points columns.</p>
        """

    def initAlgorithm(self, config=None):
        erven = QgsProject.instance().mapLayersByName('Erven')
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.ERVEN, 'Erven',
            [QgsProcessing.SourceType.TypeVectorPolygon],
            defaultValue=erven[0] if erven else None,
        ))
        self.addParameter(QgsProcessingParameterField(
            self.TYPE_FIELD, 'Column that holds Vacant / School (optional)',
            parentLayerParameterName=self.ERVEN, defaultValue='Key', optional=True,
        ))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, 'Demand Points', QgsProcessing.SourceType.TypeVectorPoint,
        ))

    def processAlgorithm(self, parameters, context, feedback):
        from fibre_automation.herotel_layers import build, demand_points

        erven = self.parameterAsVectorLayer(parameters, self.ERVEN, context)
        if erven is None:
            raise QgsProcessingException("Choose the Erven layer.")
        if erven.featureCount() == 0:
            raise QgsProcessingException(
                f"'{erven.name()}' has no features. Check it is not filtered.")
        type_field = self.parameterAsString(parameters, self.TYPE_FIELD, context) or ''
        type_idx = erven.fields().indexOf(type_field) if type_field else -1
        if type_field and type_idx == -1:
            raise QgsProcessingException(
                f"'{erven.name()}' has no column '{type_field}'. Pick the column that "
                "holds Vacant / School, or leave it empty to make every point an SDU.")

        fields = build.layer_fields(build.load_spec()['layers']['Demand Points'])
        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT, context, fields,
            QgsWkbTypes.Type.Point, erven.crs())
        if sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))

        to_wgs = QgsCoordinateTransform(
            erven.crs(), QgsCoordinateReferenceSystem('EPSG:4326'), context.transformContext())
        total = erven.featureCount()
        types = Counter()
        unknown = Counter()
        skipped = moved = 0
        for n, erf in enumerate(erven.getFeatures()):
            if feedback.isCanceled():
                break
            geom = erf.geometry()
            if not geom or geom.isEmpty():
                skipped += 1
                continue
            point, was_moved = demand_points.point_for(geom)
            if point.isNull() or point.isEmpty():
                skipped += 1
                continue
            moved += was_moved
            key = erf[type_idx] if type_idx != -1 else None
            kind = demand_points.service_type(key)
            types[kind] += 1
            odd = demand_points.unrecognised(key)
            if odd:
                unknown[odd] += 1
            lonlat = to_wgs.transform(point.asPoint())
            out = QgsFeature(fields)
            out.setGeometry(point)
            out['Count'] = '1'
            out['Type'] = kind
            out['x'] = round(lonlat.x(), 10)
            out['y'] = round(lonlat.y(), 10)
            sink.addFeature(out, QgsFeatureSink.Flag.FastInsert)
            feedback.setProgress(100.0 * (n + 1) / total)

        made = sum(types.values())
        feedback.pushInfo(
            f"{made} demand points from {total} erven: "
            + ", ".join(f"{k} {v}" for k, v in types.most_common()))
        if moved:
            feedback.pushInfo(
                f"{moved} erven have their centre outside the erf; their point was put "
                "just inside instead.")
        if skipped:
            feedback.pushWarning(f"{skipped} erven have no shape and were skipped.")
        if unknown:
            feedback.pushWarning(
                "These Key values are not in the HeroTel list, so those erven were "
                "made SDU: " + ", ".join(f"'{k}' ({v})" for k, v in unknown.most_common()))
        if not type_field:
            feedback.pushWarning("No type column chosen: every point is an SDU.")
        return {self.OUTPUT: dest_id}
