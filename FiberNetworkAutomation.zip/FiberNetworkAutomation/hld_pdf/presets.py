# -*- coding: utf-8 -*-
# Config assembly + QGIS install discovery for the HLD PDF generator.
import os
import json
import shutil
import datetime
from qgis.core import (QgsApplication, QgsProject, QgsVectorLayer,
                       QgsWkbTypes, QgsSettings)

_HERE = os.path.dirname(os.path.abspath(__file__))

# Mohadin greenfield boundary is not saved inside the project -> load it if present.
# (Generic projects simply won't have this file; the generator then frames off the PONs.)
MOHADIN_GREENFIELD = (r"C:/Users/jjsch/blitzfibre.com/Velocity_Manco - Velocity_Manco_Planning/"
                      r"Baseline Maps/FiberTime Planning/Potch - Mohadin PH2/"
                      r"Potch - Mohadin PH2/Greenfield & Overbuild Poly.shp")


def _bin_dir():
    """QGIS bin dir (holds python-qgis.bat + gswin64c.exe). prefixPath() = .../apps/qgis."""
    prefix = QgsApplication.prefixPath()
    return os.path.normpath(os.path.join(prefix, "..", "..", "bin"))


def find_python_qgis():
    b = _bin_dir()
    for name in ("python-qgis.bat", "python-qgis-ltr.bat"):
        p = os.path.join(b, name)
        if os.path.exists(p):
            return p
    return None


def find_gs():
    b = _bin_dir()
    for name in ("gswin64c.exe", "gswin32c.exe"):
        p = os.path.join(b, name)
        if os.path.exists(p):
            return p
    return None


def default_extra_layers():
    out = []
    if os.path.exists(MOHADIN_GREENFIELD):
        out.append({"path": MOHADIN_GREENFIELD, "name": "greenfield and overbuild poly",
                    "fill": {"color": "0,0,0,0", "outline_color": "0,220,0", "outline_width": "0.8"}})
    return out


def build_config(project_path, out_pdf, out_project, dpi, compress, tmp, result_path, hld_cfg=None):
    """Assemble the JSON config hld_generate.py consumes. Fills machine-specific paths."""
    here = os.path.dirname(os.path.abspath(__file__))
    out_dir = os.path.dirname(out_pdf) or "."
    return {
        "project": project_path,
        "output": out_pdf,
        "output_project": out_project,
        "qpt_out": os.path.join(out_dir, "hld_frame.qpt"),
        "hld_cfg": hld_cfg or {},
        "extra_layers": default_extra_layers(),
        "dpi": int(dpi),
        "compress": bool(compress),
        "tmp": tmp,
        "result": result_path,
        # machine-specific paths (so the bundled script is portable)
        "engine": os.path.join(here, "hld_atlas_engine.py"),
        "qgis_prefix": QgsApplication.prefixPath(),
        "gs": find_gs() or "",
    }


# ── project inspection: make the button work on ANY project ──────────────────
def polygon_layers(project=None):
    """All polygon vector layers in the project (candidate atlas-coverage layers)."""
    p = project or QgsProject.instance()
    out = []
    for l in p.mapLayers().values():
        if isinstance(l, QgsVectorLayer):
            try:
                if QgsWkbTypes.geometryType(l.wkbType()) == QgsWkbTypes.GeometryType.PolygonGeometry:
                    out.append(l)
            except AttributeError:
                if QgsWkbTypes.geometryType(l.wkbType()) == QgsWkbTypes.PolygonGeometry:
                    out.append(l)
            except Exception:
                pass
    return out


def best_coverage_layer(project=None):
    """Auto-pick the atlas-coverage (per-page) layer: a PON-type polygon layer.
    Prefers a name containing 'pon', then any polygon carrying a pon* field."""
    polys = polygon_layers(project)
    for l in polys:                                   # 1) name says PON
        if "pon" in l.name().lower():
            return l
    for l in polys:                                   # 2) has a pon* field
        if any("pon" in f.name().lower() for f in l.fields()):
            return l
    return polys[0] if polys else None                # 3) any polygon


def coverage_descriptor(layer):
    """How to label + order the atlas pages for a chosen coverage layer.
    Returns (unit_word, id_field, sort_field):
      unit_word  — the noun in the page heading ("PON", "Zone", …), NOT hardcoded
      id_field   — the attribute shown after the unit word (per-page number)
      sort_field — the attribute pages are ordered + named by
    A Zones layer carries BOTH a pon_no and a zone_no, so field choice must follow
    the layer's PURPOSE (its name), not just 'first pon* field wins'."""
    if layer is None:
        return ("PON", "pon_no", "label")
    names = [f.name() for f in layer.fields()]

    def pick(*cands):
        for c in cands:
            if c in names:
                return c
        return None

    lname = layer.name().lower()
    if "zone" in lname:
        idf = pick("zone_no", "zone", "label", "Label") or (names[0] if names else "zone_no")
        return ("Zone", idf, pick("zone_no", "label") or idf)
    if "pon" in lname:
        idf = pick("pon_no", "pon", "label", "Label") or (names[0] if names else "pon_no")
        return ("PON", idf, pick("label", "pon_no") or idf)
    # generic polygon: unit = first word of the layer name; id = a label-ish field
    unit = (layer.name().split() or ["Page"])[0]
    idf = pick("label", "Label", "name", "Name", "id") or (names[0] if names else "id")
    return (unit, idf, idf)


# ── per-project metadata persistence (remember what you typed) ───────────────
def _meta_key(project_path):
    base = os.path.splitext(os.path.basename(project_path or "default"))[0]
    return f"VelocityFibre/hldPdf/{base}"


def load_project_meta(project_path):
    """Persisted title-block details for this project (falls back to sensible defaults)."""
    s = QgsSettings()
    k = _meta_key(project_path)
    base = os.path.splitext(os.path.basename(project_path))[0] if project_path else "HLD"
    return {
        "title":    s.value(f"{k}/title", base),
        "designer": s.value(f"{k}/designer", s.value("VelocityFibre/hldPdf/lastDesigner", "")),
        "company":  s.value(f"{k}/company", s.value("VelocityFibre/hldPdf/lastCompany", "Velocity Fibre")),
        "revision": s.value(f"{k}/revision", "1"),
    }


def save_project_meta(project_path, meta):
    s = QgsSettings()
    k = _meta_key(project_path)
    s.setValue(f"{k}/title", meta.get("title", ""))
    s.setValue(f"{k}/designer", meta.get("designer", ""))
    s.setValue(f"{k}/company", meta.get("company", ""))
    s.setValue(f"{k}/revision", meta.get("revision", "1"))
    # remember last designer/company globally so a new project pre-fills them
    s.setValue("VelocityFibre/hldPdf/lastDesigner", meta.get("designer", ""))
    s.setValue("VelocityFibre/hldPdf/lastCompany", meta.get("company", ""))


def derive_hld_cfg(title, designer, company, revision, coverage_layer_name, descriptor):
    """Turn the dialog's per-project details into an engine HLD_CFG override.
    `descriptor` = (unit_word, id_field, sort_field) from coverage_descriptor().
    Empty/None values are omitted so the engine keeps its defaults."""
    unit, id_field, sort_field = descriptor or ("PON", "pon_no", "label")
    cfg = {}
    if title:
        cfg["project_name"] = title
        cfg["title_overview"] = f"{title} Overview"
        # unit word follows the coverage layer (PON / Zone / …), NOT hardcoded
        cfg["title_atlas_expr"] = f'{title} - {unit} [% "{id_field}" %]'
    if designer:
        cfg["designer"] = designer
    if company:
        cfg["company"] = company
    if revision:
        cfg["revision"] = str(revision)
    cfg["date_str"] = datetime.date.today().strftime("%d-%m-%Y")
    if coverage_layer_name:
        # first-in-list wins in the engine's role resolver
        cfg["roles"] = {"coverage": [coverage_layer_name]}
        cfg["coverage_sort_field"] = sort_field
        cfg["atlas_filename_expr"] = f'"{sort_field}"'
    return cfg


# ── deep merge (mirrors the engine's, so dialog can pre-compose overrides) ────
def deep_merge(base, over):
    out = dict(base or {})
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


# ── preset stores: client (branding) + model (layout structure) ──────────────
def _bundled_dir(kind):
    return os.path.join(_HERE, kind)            # hld_pdf/clients or hld_pdf/models


def _user_dir(kind):
    """Writable preset dir under the QGIS profile — survives plugin updates."""
    d = os.path.join(QgsApplication.qgisSettingsDirPath(), "hld_pdf", kind)
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def _assets_dir():
    return os.path.join(_HERE, "assets")


def _list_presets(kind):
    """(id, display_name, is_user) for every JSON preset in bundled + user dirs.
    A user preset with the same id shadows the bundled one."""
    found = {}
    for is_user, d in ((False, _bundled_dir(kind)), (True, _user_dir(kind))):
        if not os.path.isdir(d):
            continue
        for fn in sorted(os.listdir(d)):
            if not fn.lower().endswith(".json"):
                continue
            pid = os.path.splitext(fn)[0]
            try:
                with open(os.path.join(d, fn), encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                continue
            found[pid] = (pid, data.get("display_name", pid), is_user)
    return list(found.values())


def _read_preset(kind, pid):
    """Load a preset dict; user dir wins over bundled."""
    for d in (_user_dir(kind), _bundled_dir(kind)):
        fp = os.path.join(d, pid + ".json")
        if os.path.exists(fp):
            try:
                with open(fp, encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return None
    return None


def _resolve_logo(data):
    """Turn a preset's logo_asset (bundled) into an absolute logo_path in hld_cfg."""
    cfg = dict(data.get("hld_cfg") or {})
    la = data.get("logo_asset")
    if la and "logo_path" not in cfg:
        cfg["logo_path"] = os.path.normpath(os.path.join(_assets_dir(), la))
    return cfg


# clients (branding)
def list_clients():
    return _list_presets("clients")


def load_client(client_id):
    data = _read_preset("clients", client_id)
    if not data:
        return None
    return {"id": client_id, "display_name": data.get("display_name", client_id),
            "hld_cfg": _resolve_logo(data)}


def save_client(client_id, display_name, hld_cfg, logo_src=None):
    """Persist a user client preset (+ copy its logo into the user assets dir)."""
    cfg = dict(hld_cfg or {})
    data = {"display_name": display_name, "hld_cfg": cfg}
    if logo_src and os.path.exists(logo_src):
        dest_dir = os.path.join(_user_dir("clients"), "assets")
        os.makedirs(dest_dir, exist_ok=True)
        ext = os.path.splitext(logo_src)[1] or ".png"
        dest = os.path.join(dest_dir, f"{client_id}_logo{ext}")
        try:
            shutil.copy2(logo_src, dest)
            cfg["logo_path"] = dest
        except Exception:
            pass
    fp = os.path.join(_user_dir("clients"), client_id + ".json")
    with open(fp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    return fp


# models (layout structure)
def list_models():
    ms = _list_presets("models")
    return ms if ms else [("hld_atlas", "HLD Network Atlas", False)]


def load_model(model_id):
    data = _read_preset("models", model_id)
    if not data:
        return {"id": model_id, "display_name": model_id, "hld_cfg": {}}
    return {"id": model_id, "display_name": data.get("display_name", model_id),
            "hld_cfg": _resolve_logo(data)}
