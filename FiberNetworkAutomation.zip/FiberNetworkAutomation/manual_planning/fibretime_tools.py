import os, sys, subprocess, math, json, re

class _NullWriter:
    """Drop-in replacement for sys.stderr/stdout when QGIS sets them to None."""
    def write(self, *a): pass
    def flush(self): pass
    def fileno(self): raise OSError('NullWriter has no fileno')

if sys.stderr is None: sys.stderr = _NullWriter()
if sys.stdout is None: sys.stdout = _NullWriter()
from qgis.PyQt.QtWidgets import (
    QAction, QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QLineEdit, QPushButton, QProgressDialog, QSpinBox,
    QMessageBox, QApplication, QFileDialog, QWidget, QCheckBox,
    QScrollArea, QFrame, QGroupBox,
    QToolButton, QMenu,
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal, QPointF
from qgis.PyQt.QtGui import QPixmap, QPainter, QColor, QPainterPath, QLinearGradient, QBrush, QFont
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsRasterLayer, QgsFeature,
    QgsGeometry, QgsPointXY, QgsField, QgsFields, QgsApplication,
    QgsVectorFileWriter, QgsCoordinateReferenceSystem, QgsWkbTypes,
    QgsRectangle, QgsFillSymbol, QgsSingleSymbolRenderer,
    QgsSpatialIndex, QgsUnitTypes, QgsMapSettings, QgsMapRendererParallelJob
)
from qgis.gui import QgsMapTool, QgsRubberBand, QgsVertexMarker
from PyQt5.QtCore import QVariant

# Team-safe resolution: env override → original dev path → sensible fallback.
import shutil as _shutil
import tempfile as _tempfile
SCRIPTS_BASE = os.environ.get(
    'VF_SCRIPTS_BASE', r'C:\Users\jjsch\OneDrive - blitzfibre.com\Documents\CLAUDE')
OV_EXE = os.environ.get('VF_OVERTUREMAPS_EXE') or next(
    (p for p in (
        r'C:\Users\jjsch\AppData\Local\Programs\OSGeo4W\apps\Python312\Scripts\overturemaps.exe',
        _shutil.which('overturemaps'),
        os.path.expanduser(r'~\.qgis-venv\Scripts\overturemaps.exe'),
    ) if p and os.path.exists(p)),
    'overturemaps')  # last resort: rely on PATH at call time
OV_OUT_DIR = os.environ.get('VF_DATA_DIR', r'C:\GIS\Data')
if not os.path.isdir(OV_OUT_DIR):
    try:
        os.makedirs(OV_OUT_DIR, exist_ok=True)
    except OSError:
        OV_OUT_DIR = os.path.join(_tempfile.gettempdir(), 'vf_data')
        os.makedirs(OV_OUT_DIR, exist_ok=True)


# ── Velocity Fibre theme (Phase 2, JJ-approved) ──────────────────────────────
# Every dialog class below subclasses THIS QDialog, so all of them pick up the
# branded style + header automatically on first show. Theming must never break
# a tool, hence the broad except.
_QDialogStock = QDialog


class QDialog(_QDialogStock):
    def showEvent(self, event):
        if not getattr(self, '_vf_styled', False):
            self._vf_styled = True
            try:
                from ..branding import vf_style
                vf_style.apply_vf_style(self, header=True)
            except Exception as _e:
                try:
                    from branding import vf_style
                    vf_style.apply_vf_style(self, header=True)
                except Exception:
                    print(f'[FiberNet] manual_planning theming skipped: {_e}')
        super().showEvent(event)


class HomeConnectionsDialog(QDialog):
    def __init__(self, parent=None, detected_sr=''):
        super().__init__(parent)
        self.setWindowTitle('Home Connections — Fibertime')
        self.setMinimumWidth(380)
        self.sr_code = ''
        self.accepted_run = False
        self._detected_sr = detected_sr
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout()

        layout.addWidget(QLabel('<b>Home Connections Automation</b>'))
        layout.addWidget(QLabel(
            'Automatically places one centroid per erf using:\n'
            '  1. Google Open Buildings (primary)\n'
            '  2. Erf centroid fallback\n'
        ))

        sr_row = QHBoxLayout()
        sr_row.addWidget(QLabel('Area code (SR):'))
        self.sr_input = QLineEdit()
        self.sr_input.setPlaceholderText('e.g. MOA, PRK, KYA')
        self.sr_input.setMaxLength(5)
        if self._detected_sr:
            self.sr_input.setText(self._detected_sr)
        sr_row.addWidget(self.sr_input)
        layout.addLayout(sr_row)

        if self._detected_sr:
            self.sr_detect_label = QLabel(f'<i style="color:green;">✔ Auto-detected: {self._detected_sr}</i>')
        else:
            self.sr_detect_label = QLabel('<i style="color:gray;">Could not auto-detect — please enter manually.</i>')
        layout.addWidget(self.sr_detect_label)

        layout.addWidget(QLabel(
            '\nDetects layers automatically by name.\n'
            'Requires: Erven layer + Home Connections layer.'
        ))

        btn_row = QHBoxLayout()
        run_btn = QPushButton('▶  Run')
        run_btn.setDefault(True)
        run_btn.clicked.connect(self._on_run)
        cancel_btn = QPushButton('Cancel')
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(run_btn)
        btn_row.addWidget(cancel_btn)
        layout.addLayout(btn_row)

        self.setLayout(layout)

    def _on_run(self):
        sr = self.sr_input.text().strip().upper()
        if not sr:
            QMessageBox.warning(self, 'Missing', 'Please enter an area code (SR).')
            return
        self.sr_code = sr
        self.accepted_run = True
        self.accept()


class CentroidWorker(QThread):
    """Runs centroid matching in a background thread using plain Python data only."""
    progress = pyqtSignal(int, int)           # done, total
    finished = pyqtSignal(list, int, int)     # results, google_n, erf_n

    def __init__(self, erven_data, bldg_data):
        super().__init__()
        # erven_data: [{bbox, poly, centroid, label, easting, northing}, ...]
        # bldg_data:  [{bbox, centroid, area, conf}, ...]
        self.erven_data = erven_data
        self.bldg_data  = bldg_data
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    @staticmethod
    def _point_in_poly(px, py, poly):
        """Ray-casting point-in-polygon test. poly is a list of (x, y) tuples."""
        n = len(poly)
        inside = False
        j = n - 1
        for i in range(n):
            xi, yi = poly[i]
            xj, yj = poly[j]
            if ((yi > py) != (yj > py)) and (px < (xj - xi) * (py - yi) / (yj - yi) + xi):
                inside = not inside
            j = i
        return inside

    def run(self):
        CELL = 0.005  # ~500m grid cells
        grid = {}
        for bi, b in enumerate(self.bldg_data):
            x0,y0,x1,y1 = b['bbox']
            # Use math.floor so negative coords (Southern Hemisphere) bucket correctly
            for cx in range(math.floor(x0/CELL), math.floor(x1/CELL)+1):
                for cy in range(math.floor(y0/CELL), math.floor(y1/CELL)+1):
                    grid.setdefault((cx,cy), []).append(bi)

        results = []; google_n = erf_n = 0
        total = len(self.erven_data)
        pip = self._point_in_poly

        for i, erf in enumerate(self.erven_data):
            if self._cancelled:
                self.finished.emit([], 0, 0)
                return
            if i % 10 == 0:
                self.progress.emit(i, total)
            ex0,ey0,ex1,ey1 = erf['bbox']
            poly = erf.get('poly', [])

            # Candidate buildings from grid
            cands = set()
            for cx in range(math.floor(ex0/CELL), math.floor(ex1/CELL)+1):
                for cy in range(math.floor(ey0/CELL), math.floor(ey1/CELL)+1):
                    cands.update(grid.get((cx,cy), []))

            best_pt = None; best_area = -1.0
            for bi in cands:
                b = self.bldg_data[bi]
                blon, blat = b['centroid']
                # Precise containment: use polygon if available, bbox as fallback
                if poly:
                    if not pip(blon, blat, poly):
                        continue
                else:
                    if not (ex0 <= blon <= ex1 and ey0 <= blat <= ey1):
                        continue
                # Pick the largest building — biggest footprint = main dwelling
                if b['area'] > best_area:
                    best_area = b['area']; best_pt = (blon, blat)

            if best_pt:
                lon, lat = best_pt; google_n += 1
            else:
                e, n = erf.get('easting'), erf.get('northing')
                if e is not None and n is not None and -180 <= e <= 180 and -90 <= n <= 90:
                    lon, lat = e, n
                else:
                    lon, lat = erf['centroid']
                erf_n += 1

            results.append((lon, lat, erf['label'], i + 1))

        self.progress.emit(total, total)
        self.finished.emit(results, google_n, erf_n)


class CreateLayersDialog(QDialog):
    def __init__(self, parent=None, detected_sr='', detected_folder=''):
        super().__init__(parent)
        self.setWindowTitle('Create Fibertime Layers')
        self.setMinimumWidth(480)
        self.sr_code = ''; self.mun = ''; self.subplace = ''; self.folder_path = ''
        self.accepted_run = False
        self._detected_sr = detected_sr
        self._detected_folder = detected_folder
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout()
        layout.addWidget(QLabel('<b>Create All Standard Fibertime Layers</b>'))
        layout.addWidget(QLabel(
            'Creates individual shapefiles for all standard Fibertime layers\n'
            'with the correct attribute schemas, saved in the project folder.'
        ))

        form = QFormLayout()
        self.sr_input = QLineEdit(self._detected_sr)
        self.sr_input.setPlaceholderText('e.g. MOA, PRK, KYA')
        self.sr_input.setMaxLength(5)
        form.addRow('Area code (SR):', self.sr_input)

        self.mun_input = QLineEdit()
        self.mun_input.setPlaceholderText('e.g. JB Marks Local Municipality')
        form.addRow('Municipality:', self.mun_input)

        self.sub_input = QLineEdit()
        self.sub_input.setPlaceholderText('e.g. 676007')
        form.addRow('Subplace code:', self.sub_input)

        path_row = QHBoxLayout()
        self.path_input = QLineEdit(self._detected_folder)
        self.path_input.setPlaceholderText('Select project folder…')
        browse_btn = QPushButton('Browse…')
        browse_btn.clicked.connect(self._browse)
        path_row.addWidget(self.path_input)
        path_row.addWidget(browse_btn)
        form.addRow('Project folder:', path_row)

        layout.addLayout(form)

        btn_row = QHBoxLayout()
        run_btn = QPushButton('▶  Create Layers')
        run_btn.setDefault(True)
        run_btn.clicked.connect(self._on_run)
        cancel_btn = QPushButton('Cancel')
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(run_btn)
        btn_row.addWidget(cancel_btn)
        layout.addLayout(btn_row)
        self.setLayout(layout)

    def _browse(self):
        folder = QFileDialog.getExistingDirectory(
            self, 'Select Project Folder', self.path_input.text() or ''
        )
        if folder:
            self.path_input.setText(folder)

    def _on_run(self):
        sr = self.sr_input.text().strip().upper()
        mun = self.mun_input.text().strip()
        sub = self.sub_input.text().strip()
        folder = self.path_input.text().strip()
        if not sr:
            QMessageBox.warning(self, 'Missing', 'Please enter an area code.')
            return
        if not folder or not os.path.isdir(folder):
            QMessageBox.warning(self, 'Missing', 'Please select a valid project folder.')
            return
        self.sr_code = sr; self.mun = mun; self.subplace = sub; self.folder_path = folder
        self.accepted_run = True
        self.accept()


class CreateErvenDialog(QDialog):
    def __init__(self, parent=None, detected_sr=''):
        super().__init__(parent)
        self.setWindowTitle('Create Erven — Fibertime')
        self.setMinimumWidth(460)
        self.sr_code = ''; self.offset_x = 0.0; self.offset_y = 0.0
        self.accepted_run = False
        self._detected_sr = detected_sr
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout()
        layout.addWidget(QLabel('<b>Create Erven Polygons</b>'))
        layout.addWidget(QLabel(
            'Fetches real SA cadastral erf boundaries from the\n'
            'DRDLR Surveyor-General REST API (official cadastral)\n'
            'and clips them to your project AOI.\n\n'
            'AOI layer is detected automatically.'
        ))

        form = QFormLayout()
        self.sr_input = QLineEdit(self._detected_sr)
        self.sr_input.setPlaceholderText('e.g. MOA, PRK, KYA')
        self.sr_input.setMaxLength(5)
        form.addRow('Area code (SR):', self.sr_input)

        # Optional offset correction — useful when satellite basemap has a positional shift
        offset_row = QHBoxLayout()
        self.offset_x_input = QLineEdit('0')
        self.offset_x_input.setPlaceholderText('0')
        self.offset_x_input.setMaximumWidth(70)
        self.offset_y_input = QLineEdit('0')
        self.offset_y_input.setPlaceholderText('0')
        self.offset_y_input.setMaximumWidth(70)
        offset_row.addWidget(QLabel('X:'))
        offset_row.addWidget(self.offset_x_input)
        offset_row.addWidget(QLabel('  Y:'))
        offset_row.addWidget(self.offset_y_input)
        offset_row.addWidget(QLabel('  (degrees — leave 0 if aligned)'))
        offset_row.addStretch()
        form.addRow('Position offset:', offset_row)

        layout.addLayout(form)

        if self._detected_sr:
            layout.addWidget(QLabel(f'<i style="color:green;">✔ Auto-detected SR: {self._detected_sr}</i>'))

        btn_row = QHBoxLayout()
        run_btn = QPushButton('▶  Create Erven')
        run_btn.setDefault(True)
        run_btn.clicked.connect(self._on_run)
        cancel_btn = QPushButton('Cancel')
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(run_btn)
        btn_row.addWidget(cancel_btn)
        layout.addLayout(btn_row)
        self.setLayout(layout)

    def _on_run(self):
        sr = self.sr_input.text().strip().upper()
        if not sr:
            QMessageBox.warning(self, 'Missing', 'Please enter an area code (SR).')
            return
        try:
            self.offset_x = float(self.offset_x_input.text() or '0')
            self.offset_y = float(self.offset_y_input.text() or '0')
        except ValueError:
            QMessageBox.warning(self, 'Invalid', 'Offset values must be numbers (e.g. 0.00005).')
            return
        self.sr_code = sr
        self.accepted_run = True
        self.accept()


class SetupProjectDialog(QDialog):
    """Single dialog for the full project setup: create layers + erfs + home connections."""
    def __init__(self, parent=None, detected_sr='', detected_folder=''):
        super().__init__(parent)
        self.setWindowTitle('Setup Project')
        self.setMinimumWidth(500)
        self.sr_code = ''; self.mun = ''; self.subplace = ''
        self.folder_path = detected_folder
        self.offset_x = 0.0; self.offset_y = 0.0
        self.do_layers = True; self.do_erven = True; self.do_hc = True
        self.client = 'FIBRETIME'
        self.accepted_run = False
        self._detected_sr = detected_sr
        self._detected_folder = detected_folder
        self._build_ui()

    def _build_ui(self):
        from qgis.PyQt.QtWidgets import QRadioButton, QButtonGroup
        layout = QVBoxLayout()
        layout.addWidget(QLabel('<b>Setup Project</b>'))

        # ── Client selector ────────────────────────────────────
        client_box = QGroupBox('Client')
        client_row = QHBoxLayout()
        self.radio_ft   = QRadioButton('Fibre Time')
        self.radio_vuma = QRadioButton('Vuma (Britelink/VTC)')
        self.radio_ft.setChecked(True)
        self._client_group = QButtonGroup()
        self._client_group.addButton(self.radio_ft,   1)
        self._client_group.addButton(self.radio_vuma, 2)
        client_row.addWidget(self.radio_ft)
        client_row.addWidget(self.radio_vuma)
        client_row.addStretch()
        client_box.setLayout(client_row)
        layout.addWidget(client_box)

        layout.addWidget(QLabel(
            'Runs the full project setup in one click:\n'
            '  1. Create all standard layers with correct styles & schemas\n'
            '  2. Fetch cadastral erf boundaries (DRDLR)\n'
            '  3. Auto-place Home Connections'
        ))

        form = QFormLayout()
        self.sr_input = QLineEdit(self._detected_sr)
        self.sr_input.setPlaceholderText('e.g. MOA, PRK, KYA')
        self.sr_input.setMaxLength(5)
        form.addRow('Area code (SR):', self.sr_input)

        self.mun_input = QLineEdit()
        self.mun_input.setPlaceholderText('e.g. JB Marks Local Municipality')
        form.addRow('Municipality:', self.mun_input)

        self.sub_input = QLineEdit()
        self.sub_input.setPlaceholderText('e.g. 676007')
        form.addRow('Subplace code:', self.sub_input)

        path_row = QHBoxLayout()
        self.path_input = QLineEdit(self._detected_folder)
        self.path_input.setPlaceholderText('Select project folder…')
        browse_btn = QPushButton('Browse…')
        browse_btn.clicked.connect(self._browse)
        path_row.addWidget(self.path_input)
        path_row.addWidget(browse_btn)
        form.addRow('Project folder:', path_row)

        offset_row = QHBoxLayout()
        self.offset_x_input = QLineEdit('0')
        self.offset_x_input.setMaximumWidth(70)
        self.offset_y_input = QLineEdit('0')
        self.offset_y_input.setMaximumWidth(70)
        offset_row.addWidget(QLabel('X:'))
        offset_row.addWidget(self.offset_x_input)
        offset_row.addWidget(QLabel('  Y:'))
        offset_row.addWidget(self.offset_y_input)
        offset_row.addWidget(QLabel('  (degrees, leave 0 if aligned)'))
        offset_row.addStretch()
        form.addRow('Erf position offset:', offset_row)

        layout.addLayout(form)
        layout.addWidget(QLabel('<b>Steps to run:</b>'))

        self.chk_layers = QCheckBox('Create Layers')
        self.chk_layers.setChecked(True)
        self.chk_erven  = QCheckBox('Fetch Erf Boundaries')
        self.chk_erven.setChecked(True)
        self.chk_hc     = QCheckBox('Place Home Connections')
        self.chk_hc.setChecked(True)
        layout.addWidget(self.chk_layers)
        layout.addWidget(self.chk_erven)
        layout.addWidget(self.chk_hc)

        btn_row = QHBoxLayout()
        run_btn = QPushButton('▶  Run Setup')
        run_btn.setDefault(True)
        run_btn.clicked.connect(self._on_run)
        cancel_btn = QPushButton('Cancel')
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(run_btn)
        btn_row.addWidget(cancel_btn)
        layout.addLayout(btn_row)
        self.setLayout(layout)

    def _browse(self):
        folder = QFileDialog.getExistingDirectory(
            self, 'Select Project Folder', self.path_input.text() or '')
        if folder:
            self.path_input.setText(folder)

    def _on_run(self):
        sr = self.sr_input.text().strip().upper()
        folder = self.path_input.text().strip()
        if not sr:
            QMessageBox.warning(self, 'Missing', 'Please enter an area code.')
            return
        if self.chk_layers.isChecked() and (not folder or not os.path.isdir(folder)):
            QMessageBox.warning(self, 'Missing', 'Please select a valid project folder.')
            return
        try:
            self.offset_x = float(self.offset_x_input.text() or '0')
            self.offset_y = float(self.offset_y_input.text() or '0')
        except ValueError:
            QMessageBox.warning(self, 'Invalid', 'Offset values must be numbers.')
            return
        self.sr_code = sr
        self.mun = self.mun_input.text().strip()
        self.subplace = self.sub_input.text().strip()
        self.folder_path = folder
        self.client = 'VUMA' if self.radio_vuma.isChecked() else 'FIBRETIME'
        self.do_layers = self.chk_layers.isChecked()
        self.do_erven  = self.chk_erven.isChecked()
        self.do_hc     = self.chk_hc.isChecked()
        self.accepted_run = True
        self.accept()


class PlanBlockDialog(QDialog):
    """Parameters for the Plan Block from Route Line tool."""
    def __init__(self, parent=None, detected_sr=''):
        super().__init__(parent)
        self.setWindowTitle('Plan Block — Fibertime')
        self.setMinimumWidth(360)
        self.sr_code        = detected_sr
        self.search_radius  = 80
        self.max_per_side   = 4
        self.accepted_run   = False
        self._detected_sr   = detected_sr
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout()
        layout.addWidget(QLabel('<b>Plan Block from Route Line</b>'))
        layout.addWidget(QLabel(
            'Draw a midblock centre line on the map.\n'
            'The tool will:\n'
            '  • Find home connections within reach of the line\n'
            '  • Group them 4 per side → one pole per group\n'
            '  • Place poles + STS splitters at each group midpoint\n'
            '  • Create a distribution cable along the line\n\n'
            'Run ⚡ Label All Network Layers afterwards to label everything.'
        ))
        form = QFormLayout()

        self.sr_input = QLineEdit(self._detected_sr)
        self.sr_input.setPlaceholderText('e.g. MOA')
        form.addRow('Area code (SR):', self.sr_input)

        self.radius_spin = QSpinBox()
        self.radius_spin.setRange(20, 300)
        self.radius_spin.setValue(80)
        self.radius_spin.setSuffix(' m')
        form.addRow('Search radius:', self.radius_spin)

        self.per_side_spin = QSpinBox()
        self.per_side_spin.setRange(1, 8)
        self.per_side_spin.setValue(4)
        form.addRow('Max HCs per side:', self.per_side_spin)

        layout.addLayout(form)
        layout.addWidget(QLabel(
            '<i>Click OK then draw your midblock line on the map.<br>'
            'Single-click to add vertices. Double-click to finish.</i>'
        ))

        btn_row = QHBoxLayout()
        ok_btn = QPushButton('OK — Draw Line')
        ok_btn.setDefault(True)
        ok_btn.clicked.connect(self._on_ok)
        cancel_btn = QPushButton('Cancel')
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(ok_btn)
        btn_row.addWidget(cancel_btn)
        layout.addLayout(btn_row)
        self.setLayout(layout)

    def _on_ok(self):
        sr = self.sr_input.text().strip().upper()
        if not sr:
            QMessageBox.warning(self, 'Missing', 'Please enter an area code.')
            return
        self.sr_code       = sr
        self.search_radius = self.radius_spin.value()
        self.max_per_side  = self.per_side_spin.value()
        self.accepted_run  = True
        self.accept()


class PrimaryFeederDialog(QDialog):
    """Dialog for the Primary Feeder cable automation tool."""

    # Cable capacity options — Fibre Time standard sizes
    CAPACITIES = ['Auto-detect', '48F', '72F', '96F', '144F', '288F']

    def __init__(self, parent=None, detected_sr=''):
        super().__init__(parent)
        self.setWindowTitle('Primary Feeder Automation')
        self.setMinimumWidth(380)
        self.sr_code      = detected_sr
        self.pole_spacing = 40
        self.capacity     = 'Auto-detect'
        self.accepted_run = False
        self._detected_sr = detected_sr
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout()
        layout.addWidget(QLabel('<b>Primary Feeder Cable Automation</b>'))
        layout.addWidget(QLabel(
            'Draw the primary feeder route on the map.\n'
            'The tool will:\n'
            '  • Place poles at regular intervals along the route\n'
            '  • Snap poles to bends in the drawn line\n'
            '  • Create a Primary Feeder cable (Blue ADSS) along the route\n'
            '  • Name the cable per Fibre Time convention\n\n'
            'Run ⚡ Label All Network Layers afterwards to assign labels.\n'
            'Cable colour: Blue #0000FF  |  Style: Solid ADSS'
        ))

        form = QFormLayout()

        self.sr_input = QLineEdit(self._detected_sr)
        self.sr_input.setPlaceholderText('e.g. MOA')
        form.addRow('Area code (SR):', self.sr_input)

        self.spacing_spin = QSpinBox()
        self.spacing_spin.setRange(20, 100)
        self.spacing_spin.setValue(40)
        self.spacing_spin.setSuffix(' m')
        form.addRow('Pole spacing:', self.spacing_spin)

        from qgis.PyQt.QtWidgets import QComboBox
        self.cap_combo = QComboBox()
        self.cap_combo.addItems(self.CAPACITIES)
        self.cap_combo.setToolTip(
            'Auto-detect: counts existing AGG Domes/PONs and applies double-up rule\n'
            '(num_pons × 1) × 2 → next cable size up'
        )
        form.addRow('Cable capacity:', self.cap_combo)

        layout.addLayout(form)

        if self._detected_sr:
            layout.addWidget(QLabel(f'<i style="color:green;">✔ Auto-detected SR: {self._detected_sr}</i>'))

        layout.addWidget(QLabel(
            '<i>Click OK then draw your feeder route on the map.<br>'
            'Single-click to add vertices. Double-click or right-click to finish.</i>'
        ))

        btn_row = QHBoxLayout()
        ok_btn = QPushButton('OK — Draw Route')
        ok_btn.setDefault(True)
        ok_btn.clicked.connect(self._on_ok)
        cancel_btn = QPushButton('Cancel')
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(ok_btn)
        btn_row.addWidget(cancel_btn)
        layout.addLayout(btn_row)
        self.setLayout(layout)

    def _on_ok(self):
        sr = self.sr_input.text().strip().upper()
        if not sr:
            QMessageBox.warning(self, 'Missing', 'Please enter an area code.')
            return
        self.sr_code      = sr
        self.pole_spacing = self.spacing_spin.value()
        self.capacity     = self.cap_combo.currentText()
        self.accepted_run = True
        self.accept()


class SecondaryFeederDialog(QDialog):
    """Dialog for the Secondary Feeder cable automation tool."""

    CAPACITIES = ['24F', '48F', '72F', '96F', '144F', 'Auto-detect']

    def __init__(self, parent=None, detected_sr=''):
        super().__init__(parent)
        self.setWindowTitle('Secondary Feeder Automation')
        self.setMinimumWidth(380)
        self.sr_code      = detected_sr
        self.pole_spacing = 40
        self.capacity     = '24F'
        self.accepted_run = False
        self._detected_sr = detected_sr
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout()
        layout.addWidget(QLabel('<b>Secondary Feeder Cable Automation</b>'))
        layout.addWidget(QLabel(
            'Draw the secondary feeder route on the map.\n'
            'The tool will:\n'
            '  • Place poles at regular intervals along the route\n'
            '  • Snap poles to bends in the drawn line\n'
            '  • Create a Secondary Feeder cable (Blue ADSS) along the route\n'
            '  • Name: AREA.SF.CAPACITY.P.AXXX-P.AXXX\n\n'
            'Run ⚡ Label All Network Layers afterwards.\n'
            'Cable colour: Blue #0000FF  |  Style: Solid ADSS'
        ))
        form = QFormLayout()
        self.sr_input = QLineEdit(self._detected_sr)
        self.sr_input.setPlaceholderText('e.g. MOA')
        form.addRow('Area code (SR):', self.sr_input)
        self.spacing_spin = QSpinBox()
        self.spacing_spin.setRange(20, 100)
        self.spacing_spin.setValue(40)
        self.spacing_spin.setSuffix(' m')
        form.addRow('Pole spacing:', self.spacing_spin)
        from qgis.PyQt.QtWidgets import QComboBox
        self.cap_combo = QComboBox()
        self.cap_combo.addItems(self.CAPACITIES)
        form.addRow('Cable capacity:', self.cap_combo)
        layout.addLayout(form)
        if self._detected_sr:
            layout.addWidget(QLabel(f'<i style="color:green;">✔ Auto-detected SR: {self._detected_sr}</i>'))
        layout.addWidget(QLabel(
            '<i>Click OK then draw your secondary feeder route on the map.<br>'
            'Single-click to add vertices. Double-click or right-click to finish.</i>'
        ))
        btn_row = QHBoxLayout()
        ok_btn = QPushButton('OK — Draw Route')
        ok_btn.setDefault(True)
        ok_btn.clicked.connect(self._on_ok)
        cancel_btn = QPushButton('Cancel')
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(ok_btn)
        btn_row.addWidget(cancel_btn)
        layout.addLayout(btn_row)
        self.setLayout(layout)

    def _on_ok(self):
        sr = self.sr_input.text().strip().upper()
        if not sr:
            QMessageBox.warning(self, 'Missing', 'Please enter an area code.')
            return
        self.sr_code      = sr
        self.pole_spacing = self.spacing_spin.value()
        self.capacity     = self.cap_combo.currentText()
        self.accepted_run = True
        self.accept()


class ClickMapTool(QgsMapTool):
    """Single-click map tool. Calls callback(QgsPointXY) on each left-click.
    Press Escape or right-click to exit."""

    def __init__(self, canvas, callback, icon_color='#00b4ff', multi=False):
        super().__init__(canvas)
        self._canvas   = canvas
        self._callback = callback
        self._multi    = multi   # True = stay active after each click
        self._prev_snap = False

        self._snap_marker = QgsVertexMarker(canvas)
        self._snap_marker.setIconType(QgsVertexMarker.ICON_CROSS)
        self._snap_marker.setColor(QColor(icon_color))
        self._snap_marker.setFillColor(QColor(icon_color))
        self._snap_marker.setIconSize(14)
        self._snap_marker.setPenWidth(2)
        self._snap_marker.hide()

    def activate(self):
        super().activate()
        cfg = QgsProject.instance().snappingConfig()
        self._prev_snap = cfg.enabled()
        cfg.setEnabled(True)
        QgsProject.instance().setSnappingConfig(cfg)

    def canvasMoveEvent(self, event):
        match = self._canvas.snappingUtils().snapToMap(event.pos())
        if match.isValid():
            pt = match.point()
            self._snap_marker.setCenter(QgsPointXY(pt.x(), pt.y()))
            self._snap_marker.show()
        else:
            self._snap_marker.hide()

    def canvasReleaseEvent(self, event):
        if event.button() == Qt.RightButton:
            self._canvas.unsetMapTool(self)
            return
        if event.button() == Qt.LeftButton:
            match = self._canvas.snappingUtils().snapToMap(event.pos())
            pt = QgsPointXY(match.point().x(), match.point().y()) if match.isValid() \
                 else QgsPointXY(self.toMapCoordinates(event.pos()))
            self._callback(pt)
            if not self._multi:
                self._canvas.unsetMapTool(self)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self._canvas.unsetMapTool(self)

    def deactivate(self):
        cfg = QgsProject.instance().snappingConfig()
        cfg.setEnabled(self._prev_snap)
        QgsProject.instance().setSnappingConfig(cfg)
        self._snap_marker.hide()
        self._canvas.scene().removeItem(self._snap_marker)
        super().deactivate()


class PonRecorderMapTool(QgsMapTool):
    """Click a PON v1 polygon on the map to record it in feeder order.
    Right-click or Escape to stop early."""

    def __init__(self, canvas, iface, order_file, action=None):
        super().__init__(canvas)
        self._canvas     = canvas
        self._iface      = iface
        self._order_file = order_file
        self._action     = action

    def deactivate(self):
        super().deactivate()
        if self._action:
            self._action.setText('🔴  Record PON Order')

    def _current_pos(self):
        if os.path.exists(self._order_file):
            with open(self._order_file) as f:
                lines = [l for l in f if l.strip()]
            return len(lines) + 1
        return 1

    def canvasReleaseEvent(self, event):
        if event.button() == Qt.RightButton:
            self._canvas.unsetMapTool(self)
            return
        if event.button() != Qt.LeftButton:
            return

        pos = self._current_pos()
        if pos > 64:
            self._iface.messageBar().pushMessage(
                'PON Order', 'Already have 64 entries — done!', level=0, duration=4)
            self._canvas.unsetMapTool(self)
            return

        lyr = next((l for l in QgsProject.instance().mapLayers().values()
                    if 'PON v1' in l.name()), None)
        if not lyr:
            self._iface.messageBar().pushMessage(
                'PON Order', 'ERROR: PON v1 layer not found', level=2, duration=5)
            self._canvas.unsetMapTool(self)
            return

        map_pt = QgsPointXY(self.toMapCoordinates(event.pos()))
        click_geom = QgsGeometry.fromPointXY(map_pt)

        # Find which PON polygon was clicked
        feat = None
        for f in lyr.getFeatures():
            if f.geometry() and f.geometry().contains(click_geom):
                feat = f
                break

        if feat is None:
            self._iface.messageBar().pushMessage(
                'PON Order', 'Click landed outside all PON polygons — try again', level=1, duration=3)
            return

        label  = str(feat['label'])
        pon_no = feat['pon_no']

        with open(self._order_file, 'a') as f:
            f.write(f'{pos},{label},{pon_no}\n')

        if self._action:
            self._action.setText(f'🔴  {pos}/64 recorded')

        msg = f'Position {pos}/64: {label}  (pon_no={pon_no})'
        self._iface.messageBar().pushMessage('✅ PON Recorded', msg, level=0, duration=4)

        if pos == 64:
            self._canvas.unsetMapTool(self)
            self._iface.messageBar().pushMessage(
                '🎉 Running FT 6…',
                'All 64 PONs recorded — applying feeder-path PON order now',
                level=0, duration=6)
            import processing
            try:
                result = processing.run('fibernetwork:ft_apply_pon_order', {})
                summary = result.get('RESULT', 'done')
                self._iface.messageBar().pushMessage('✅ FT 6 Complete', str(summary), level=0, duration=10)
            except Exception as e:
                self._iface.messageBar().pushMessage('❌ FT 6 Error', str(e), level=2, duration=10)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self._canvas.unsetMapTool(self)


class PlanBlockMapTool(QgsMapTool):
    """Rubber-band polyline drawing tool for the midblock route.
    Shows a live preview segment from the last committed point to the cursor.
    Enables QGIS snapping while active so the user can snap to existing features."""

    def __init__(self, canvas, callback):
        super().__init__(canvas)
        self._canvas      = canvas
        self._callback    = callback
        self._points      = []
        self._dbl_flag    = False
        self._prev_snap   = False  # previous snapping enabled state

        # Committed line (solid orange)
        self._rb = QgsRubberBand(canvas, QgsWkbTypes.LineGeometry)
        self._rb.setColor(QColor('#ff6600'))
        self._rb.setWidth(2)

        # Preview segment (dashed red — stands out clearly)
        self._rb_preview = QgsRubberBand(canvas, QgsWkbTypes.LineGeometry)
        self._rb_preview.setColor(QColor(220, 20, 20, 220))
        self._rb_preview.setWidth(2)
        self._rb_preview.setLineStyle(Qt.DashLine)

        # Snap indicator: purple circle at the snapped point
        self._snap_marker = QgsVertexMarker(canvas)
        self._snap_marker.setIconType(QgsVertexMarker.ICON_CIRCLE)
        self._snap_marker.setColor(QColor(140, 0, 200))
        self._snap_marker.setFillColor(QColor(180, 60, 255, 100))
        self._snap_marker.setIconSize(10)
        self._snap_marker.setPenWidth(2)
        self._snap_marker.hide()

    def activate(self):
        super().activate()
        # Enable QGIS snapping while this tool is active
        cfg = QgsProject.instance().snappingConfig()
        self._prev_snap = cfg.enabled()
        cfg.setEnabled(True)
        QgsProject.instance().setSnappingConfig(cfg)

    def _snapped_point(self, pos):
        """Return map coordinates for a canvas pixel position, snapped if possible."""
        match = self._canvas.snappingUtils().snapToMap(pos)
        if match.isValid():
            return match.point()
        return self.toMapCoordinates(pos)

    def canvasMoveEvent(self, event):
        # Update snap marker regardless of whether a line is being drawn
        match = self._canvas.snappingUtils().snapToMap(event.pos())
        if match.isValid():
            pt = match.point()
            self._snap_marker.setCenter(QgsPointXY(pt.x(), pt.y()))
            self._snap_marker.show()
        else:
            self._snap_marker.hide()

        if not self._points:
            return
        cur = QgsPointXY(match.point().x(), match.point().y()) if match.isValid() \
              else QgsPointXY(self.toMapCoordinates(event.pos()))
        self._rb_preview.reset(QgsWkbTypes.LineGeometry)
        self._rb_preview.addPoint(self._points[-1])
        self._rb_preview.addPoint(cur)

    def canvasReleaseEvent(self, event):
        if self._dbl_flag:
            self._dbl_flag = False
            return
        if event.button() == Qt.RightButton:
            # Right-click: confirm and finish the line
            self._rb_preview.reset(QgsWkbTypes.LineGeometry)
            if len(self._points) >= 2:
                geom = QgsGeometry.fromPolylineXY(self._points)
                self._rb.reset()
                self._points = []
                self._callback(geom)
            else:
                self._rb.reset()
                self._points = []
            return
        if event.button() == Qt.LeftButton:
            pt = self._snapped_point(event.pos())
            new_pt = QgsPointXY(pt.x(), pt.y())
            # Span warning: check if last segment exceeds 70m
            if self._points:
                from qgis.core import QgsDistanceArea, QgsCoordinateTransformContext
                _da = QgsDistanceArea()
                _da.setEllipsoid('WGS84')
                _da.setSourceCrs(
                    QgsProject.instance().crs(), QgsCoordinateTransformContext()
                )
                span_m = _da.measureLine(self._points[-1], new_pt)
                if span_m > 70:
                    from qgis.core import Qgis
                    self._canvas.scene().views()[0].window().findChild(
                        __import__('qgis.gui', fromlist=['QgisInterface']).QgisInterface
                        if False else type(None)
                    )
                    # Push via QGIS message bar directly
                    try:
                        from qgis.utils import iface as _iface
                        _iface.messageBar().pushMessage(
                            '⚠️ Span Warning',
                            f'Last segment is {span_m:.1f} m — max allowed is 70 m',
                            level=Qgis.Warning, duration=4
                        )
                    except Exception:
                        pass
            self._points.append(new_pt)
            self._rb.addPoint(pt)
            self._rb_preview.reset(QgsWkbTypes.LineGeometry)

    def canvasDoubleClickEvent(self, event):
        self._dbl_flag = True
        self._rb_preview.reset(QgsWkbTypes.LineGeometry)
        if len(self._points) >= 2:
            geom = QgsGeometry.fromPolylineXY(self._points)
            self._rb.reset()
            self._points = []
            self._callback(geom)
        else:
            self._rb.reset()
            self._points = []

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self._rb.reset()
            self._rb_preview.reset(QgsWkbTypes.LineGeometry)
            self._points = []
            self._canvas.unsetMapTool(self)

    def deactivate(self):
        # Restore previous snapping state
        cfg = QgsProject.instance().snappingConfig()
        cfg.setEnabled(self._prev_snap)
        QgsProject.instance().setSnappingConfig(cfg)
        self._rb.reset()
        self._rb_preview.reset(QgsWkbTypes.LineGeometry)
        self._snap_marker.hide()
        self._canvas.scene().removeItem(self._snap_marker)
        super().deactivate()


class PolygonMapTool(QgsMapTool):
    """Click to add vertices, right-click or double-click to finish polygon."""

    def __init__(self, canvas, callback):
        super().__init__(canvas)
        self._canvas   = canvas
        self._callback = callback
        self._points   = []
        self._dbl_flag = False

        self._rb = QgsRubberBand(canvas, QgsWkbTypes.PolygonGeometry)
        self._rb.setColor(QColor(255, 165, 0, 120))
        self._rb.setStrokeColor(QColor(255, 120, 0))
        self._rb.setWidth(2)

        self._rb_preview = QgsRubberBand(canvas, QgsWkbTypes.LineGeometry)
        self._rb_preview.setColor(QColor(255, 120, 0, 180))
        self._rb_preview.setWidth(1)

    def canvasMoveEvent(self, event):
        if not self._points:
            return
        cur = QgsPointXY(self._canvas.getCoordinateTransform().toMapCoordinates(event.pos()))
        self._rb_preview.reset(QgsWkbTypes.LineGeometry)
        self._rb_preview.addPoint(self._points[-1])
        self._rb_preview.addPoint(cur)

    def canvasPressEvent(self, event):
        if self._dbl_flag:
            self._dbl_flag = False
            return
        if event.button() == Qt.RightButton:
            self._finish()
            return
        pt = QgsPointXY(self._canvas.getCoordinateTransform().toMapCoordinates(event.pos()))
        self._points.append(pt)
        self._rb.addPoint(pt)

    def canvasDoubleClickEvent(self, event):
        self._dbl_flag = True
        self._finish()

    def _finish(self):
        self._rb.reset()
        self._rb_preview.reset(QgsWkbTypes.LineGeometry)
        pts = self._points[:]
        self._points = []
        if len(pts) >= 3:
            self._callback(QgsGeometry.fromPolygonXY([pts]))
        self._canvas.unsetMapTool(self)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self._rb.reset()
            self._rb_preview.reset(QgsWkbTypes.LineGeometry)
            self._points = []
            self._canvas.unsetMapTool(self)

    def deactivate(self):
        self._rb.reset()
        self._rb_preview.reset(QgsWkbTypes.LineGeometry)
        super().deactivate()


class PipelineDialog(QDialog):
    """Dialog for running the full fibre network automation pipeline."""

    STEPS = [
        ('1 — Create Layers',             'create_layers'),
        ('2 — Clean Buildings',           'clean_buildings'),
        ('3 — PON Boundaries',            'create_pon_boundaries'),
        ('4 — Place Poles',               'place_poles'),
        ('5 — Place AGG Nodes',           'place_nodes'),
        ('6 — Place DIS Nodes',           'place_dis_nodes'),
        ('7 — Route Distribution',        'route_distribution'),
        ('7b — Route Primary Feeder',     'route_primary_feeder'),
        ('8 — Generate Drops',            'generate_drops'),
        ('9 — Auto-Name Features',        'name_all_features'),
        ('10 — Populate Attributes',      'populate_attributes'),
        ('11 — QA Check',                 'run_qa'),
    ]

    def __init__(self, plugin, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.setWindowTitle('Fibre Network Pipeline')
        self.setMinimumWidth(360)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout()
        layout.addWidget(QLabel('<b>Fibre Network Automation Pipeline</b>'))
        layout.addWidget(QLabel(
            'Full pipeline from raw data to designed network.\n'
            'Supports Vuma (Britelink/VTC) and Fibre Time.\n'
            'Check the QGIS Python Console for progress output.'
        ))

        full_btn = QPushButton('▶  Run Full Pipeline  (Steps 1 – 11)')
        full_btn.setDefault(True)
        full_btn.setStyleSheet('font-weight: bold; padding: 6px;')
        full_btn.clicked.connect(lambda: self._run('run_full_pipeline', setup_first=False))
        layout.addWidget(full_btn)

        sep = QLabel('──────  Individual Steps  ──────')
        sep.setAlignment(Qt.AlignCenter)
        layout.addWidget(sep)

        for label, fn_name in self.STEPS:
            btn = QPushButton(f'Step {label}')
            btn.clicked.connect(
                lambda checked=False, fn=fn_name: self._run(fn, setup_first=True)
            )
            layout.addWidget(btn)

        close_btn = QPushButton('Close')
        close_btn.clicked.connect(self.reject)
        layout.addWidget(close_btn)
        self.setLayout(layout)

    def _run(self, fn_name, setup_first=True):
        import traceback
        ns = self.plugin._get_pipeline_ns()
        if ns is None:
            return
        fn = ns.get(fn_name)
        if not fn:
            QMessageBox.critical(self, 'Error', f'Function "{fn_name}" not found in pipeline script.')
            return
        try:
            if setup_first:
                setup_fn = ns.get('setup')
                if setup_fn and not setup_fn():
                    return
            fn()
        except Exception as e:
            QMessageBox.critical(
                self, 'Pipeline Error',
                f'{fn_name} failed:\n{e!s}\n\n{traceback.format_exc()[:600]}'
            )


class PopulatePipelineDialog(QDialog):
    """Dialog to run attribute population scripts — Steps 9–24 of the Fibre Time workflow."""

    STEPS = [
        # (section, color, steps[])
        ('PON', '#2c5f8a', [
            ('9',   'Cluster & Label PONs (K-Means)',       'PON Label Clustered',              'pon_label_clustered.py'),
            ('10',  'Assign PON Numbers',                   'PON No Assignment',                'pon_no_assignment.py'),
            ('11',  'Populate PON Attributes',              'PON V1 Population',                'pon_v1_population.py'),
        ]),
        ('Poles', '#5a3e8a', [
            ('12a', 'Assign Pole Types',                    'Pole Type assignment',             'pole_type_assignment.py'),
            ('12b', 'Audit Poles',                          'poles v1 Audit',                  'poles_v1_audit.py'),
            ('13',  'Populate Null / Late-Added Poles',     'Null Label Poles Population',      'null_label_poles_population.py'),
        ]),
        ('Splitters', '#8a5a00', [
            ('14',  'Populate FTS Splitters',               'FTS V1 Population',                'fts_v1_population.py'),
            ('15a', 'Populate STS Splitters',               'STS V1 Population',                'sts_v1_population.py'),
            ('15b', 'Label STS Splitters',                  'STS V1 Labels',                   'sts_v1_labels.py'),
            ('16',  'STS Redistribution Check',             'STS Redistribution Check',         'sts_redistribution_buffered.py'),
        ]),
        ('Cables', '#1a6b3c', [
            ('17',  'Populate Distribution Cables',         'Dist Cable V1 Population',         'dist_cable_v1_population.py'),
            ('18',  'Populate Secondary Cables',            'Sec Cable V1 Population',          'sec_cable_v1_population.py'),
            ('19',  'Populate Primary Cables',              'Primary Cable V1 Population',      'primary_cable_v1_population.py'),
        ]),
        ('Homes & Drops', '#7a1a1a', [
            ('20',  'Populate Home Connections',            'Home Connections V1 Population',   'home_connections_v1_population.py'),
            ('21',  'Populate Drop Cables',                 'Drop Cable V1 Population',         'drop_cable_v1_population.py'),
            ('22',  'Populate Spare Drop Cables',           'Spare Drop Cable V1 Population',   'spare_drop_cable_v1_population.py'),
        ]),
        ('Enclosures & QA', '#3a3a3a', [
            ('23',  'Populate Enclosures',                  'Enclosure V1 Population',          'enclosure_v1_population.py'),
            ('24',  'QA: Check Splitter / Poles / Enc',     'Check Splitter Poles Enclosures',  'check_splitter_poles_enclosures.py'),
        ]),
    ]

    def __init__(self, plugin, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.setWindowTitle('Populate Attributes')
        self.setMinimumWidth(420)
        self._build_ui()

    def _build_ui(self):
        outer = QVBoxLayout()
        outer.setSpacing(10)
        outer.setContentsMargins(12, 12, 12, 12)

        # Header
        title = QLabel('Populate Attributes')
        title.setStyleSheet('font-size: 14px; font-weight: bold; color: #222;')
        outer.addWidget(title)

        subtitle = QLabel('Run these steps in order once your network is drawn. Check the Python Console for output after each step.')
        subtitle.setStyleSheet('color: #555; font-size: 11px;')
        subtitle.setWordWrap(True)
        outer.addWidget(subtitle)

        # Sections
        for section_name, color, steps in self.STEPS:
            # Section header
            header = QLabel(f'  {section_name}')
            header.setStyleSheet(
                f'background-color: {color}; color: white; font-weight: bold; '
                f'font-size: 11px; padding: 4px 6px; border-radius: 3px;'
            )
            outer.addWidget(header)

            # Buttons for this section
            for step, label, folder, script in steps:
                btn = QPushButton(f'  {step}   {label}')
                btn.setStyleSheet(
                    'text-align: left; padding: 5px 10px; '
                    'border: 1px solid #ccc; border-radius: 3px; '
                    'background: #f9f9f9; color: #222;'
                )
                btn.clicked.connect(
                    lambda checked=False, f=folder, s=script: self._run_script(f, s)
                )
                outer.addWidget(btn)

        # Close button
        outer.addSpacing(4)
        close_btn = QPushButton('Close')
        close_btn.setStyleSheet(
            'padding: 6px; background: #555; color: white; '
            'border-radius: 3px; font-weight: bold;'
        )
        close_btn.clicked.connect(self.reject)
        outer.addWidget(close_btn)
        self.setLayout(outer)

    # Maps script variable names → fuzzy keywords for auto-detecting actual layer names
    _LAYER_VARS = {
        'PON_LAYER':              (['pon'],                         ['zone']),
        'POLES_LAYER':            (['pole'],                        []),
        'POLES_LAYER_NAME':       (['pole'],                        []),
        'ZONE_LAYER':             (['zone'],                        ['pon']),
        'HOME_LAYER':             (['home', 'connect'],             []),
        'FTS_LAYER':              (['fts'],                         []),
        'STS_LAYER':              (['sts'],                         []),
        'CABLE_LAYER':            (['distribution', 'cable'],       ['spare', 'drop', 'secondary', 'primary']),
        'PRIMARY_LAYER_NAME':     (['primary'],                     ['secondary']),
        'SECONDARY_LAYER_NAME':   (['secondary'],                   []),
        'DISTRIB_LAYER_NAME':     (['distribution'],                ['drop', 'spare', 'secondary', 'primary']),
        'PRIM_LAYER':             (['primary'],                     ['secondary']),
        'SEC_LAYER':              (['secondary'],                   []),
        'DROP_LAYER':             (['drop', 'cable'],               ['spare']),
        'SPARE_LAYER':            (['spare', 'drop'],               []),
        'ENC_LAYER':              (['enclosure'],                   ['connectoris', 'splice', 'connec']),
        'CON_LAYER':              (['enclosure', 'connectoris'],    []),
        'SPL_LAYER':              (['enclosure', 'splice'],         []),
    }

    def _run_script(self, folder, filename):
        script = os.path.join(SCRIPTS_BASE, folder, filename)
        if not os.path.exists(script):
            QMessageBox.warning(self, 'Script not found',
                                f'Could not find:\n{script}\n\n'
                                f'Check that the script exists in the CLAUDE folder.')
            return
        try:
            with open(script, 'r') as f:
                code = f.read()
            # Patch hardcoded layer name variables to match actual loaded layers,
            # so scripts work regardless of whether layers have 'v1' suffix or not.
            for var, (keywords, exclude) in self._LAYER_VARS.items():
                lyr = self.plugin._find_layer(keywords, exclude=exclude or None)
                if lyr:
                    code = re.sub(
                        rf"^({var}\s*=\s*)['\"].*?['\"]",
                        rf"\g<1>'{lyr.name().replace(chr(39), chr(92)+chr(39))}'",
                        code, flags=re.MULTILINE
                    )
            exec(code, {'iface': self.plugin.iface, 'QgsProject': QgsProject})
        except Exception as e:
            import traceback as _tb
            QMessageBox.critical(
                self, 'Script Error',
                f'{filename} failed:\n{e!s}\n\n{_tb.format_exc()[:800]}'
            )


class HLDAuditDialog(QDialog):
    """Runs all automatable HLD evaluation checks and shows Pass/Fail for each item."""

    PASS    = ('✅', '#1a6b3c', '#e8f5ee')
    FAIL    = ('❌', '#7a1a1a', '#fdecea')
    WARN    = ('⚠️',  '#7a5a00', '#fff8e1')
    SKIP    = ('➖', '#555',    '#f5f5f5')

    def __init__(self, plugin, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.setWindowTitle('HLD Compliance Audit')
        self.setMinimumWidth(620)
        self.setMinimumHeight(700)
        self._build_ui()

    def _build_ui(self):
        outer = QVBoxLayout()
        outer.setSpacing(8)
        outer.setContentsMargins(12, 12, 12, 12)

        # Header
        hdr = QLabel('Fibertime HLD Compliance Audit')
        hdr.setStyleSheet('font-size: 15px; font-weight: bold; color: #1a2050;')
        outer.addWidget(hdr)

        sub = QLabel('Checks all automatable items from the Final HLD Evaluation checklist. Run after your network is drawn.')
        sub.setStyleSheet('color: #555; font-size: 11px;')
        sub.setWordWrap(True)
        outer.addWidget(sub)

        # SR row
        sr_row = QHBoxLayout()
        sr_row.addWidget(QLabel('Area code (SR):'))
        self._sr_input = QLineEdit()
        self._sr_input.setPlaceholderText('e.g. MOA, PRK')
        self._sr_input.setMaxLength(5)
        self._sr_input.setFixedWidth(80)
        sr_row.addWidget(self._sr_input)
        sr_row.addStretch()
        self._run_btn = QPushButton('▶  Run Audit')
        self._run_btn.setStyleSheet(
            'background: #1a2050; color: white; font-weight: bold; '
            'padding: 6px 18px; border-radius: 3px;'
        )
        self._run_btn.clicked.connect(self._run)
        sr_row.addWidget(self._run_btn)
        outer.addLayout(sr_row)

        # Score banner
        self._score_lbl = QLabel('')
        self._score_lbl.setStyleSheet(
            'font-size: 13px; font-weight: bold; padding: 6px 10px; '
            'border-radius: 4px; background: #eee; color: #333;'
        )
        self._score_lbl.hide()
        outer.addWidget(self._score_lbl)

        # Results scroll area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        self._results_widget = QWidget()
        self._results_layout = QVBoxLayout(self._results_widget)
        self._results_layout.setSpacing(3)
        self._results_layout.setContentsMargins(0, 0, 0, 0)
        self._results_layout.addStretch()
        scroll.setWidget(self._results_widget)
        outer.addWidget(scroll, 1)

        # Export + Close
        btn_row = QHBoxLayout()
        self._export_btn = QPushButton('💾  Export Report')
        self._export_btn.setEnabled(False)
        self._export_btn.clicked.connect(self._export)
        btn_row.addWidget(self._export_btn)
        btn_row.addStretch()
        close_btn = QPushButton('Close')
        close_btn.setStyleSheet('padding: 6px 16px;')
        close_btn.clicked.connect(self.reject)
        btn_row.addWidget(close_btn)
        outer.addLayout(btn_row)

        self.setLayout(outer)
        self._report_lines = []

    # ── check helpers ──────────────────────────────────────────────────────

    def _find(self, keywords, exclude=None):
        return FibretimeTools._find_layer(keywords, exclude)

    def _add_section(self, title):
        lbl = QLabel(f'  {title}')
        lbl.setStyleSheet(
            'background: #1a2050; color: white; font-weight: bold; '
            'font-size: 11px; padding: 4px 8px; border-radius: 3px; margin-top: 4px;'
        )
        # Insert before the trailing stretch
        idx = self._results_layout.count() - 1
        self._results_layout.insertWidget(idx, lbl)
        self._report_lines.append(f'\n=== {title} ===')

    def _add_row(self, hld_num, description, status, detail=''):
        icon, fg, bg = status
        row = QWidget()
        row.setStyleSheet(f'background: {bg}; border-radius: 2px;')
        h = QHBoxLayout(row)
        h.setContentsMargins(6, 3, 6, 3)
        h.setSpacing(8)

        num_lbl = QLabel(f'#{hld_num}')
        num_lbl.setStyleSheet('color: #888; font-size: 10px; min-width: 28px;')
        h.addWidget(num_lbl)

        icon_lbl = QLabel(icon)
        icon_lbl.setFixedWidth(20)
        h.addWidget(icon_lbl)

        desc_lbl = QLabel(description)
        desc_lbl.setStyleSheet(f'color: {fg}; font-size: 11px;')
        h.addWidget(desc_lbl, 1)

        if detail:
            det_lbl = QLabel(detail)
            det_lbl.setStyleSheet('color: #666; font-size: 10px;')
            det_lbl.setWordWrap(True)
            h.addWidget(det_lbl)

        idx = self._results_layout.count() - 1
        self._results_layout.insertWidget(idx, row)

        stat_word = {self.PASS: 'PASS', self.FAIL: 'FAIL', self.WARN: 'WARN', self.SKIP: 'N/A'}[status]
        self._report_lines.append(f'  [{stat_word}] #{hld_num} {description}  {detail}')
        return status

    # ── main audit ────────────────────────────────────────────────────────

    def _run(self):
        SR = self._sr_input.text().strip().upper()
        if not SR:
            SR = self.plugin._detect_sr_code()
            self._sr_input.setText(SR)
        if not SR:
            QMessageBox.warning(self, 'Missing', 'Enter an area code (SR) first.')
            return

        # Clear previous results
        while self._results_layout.count() > 1:
            item = self._results_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self._report_lines = [f'HLD Audit — SR: {SR}', '=' * 50]
        self._export_btn.setEnabled(False)
        self._score_lbl.hide()

        passes = fails = warns = 0

        def add(n, desc, status, detail=''):
            nonlocal passes, fails, warns
            self._add_row(n, desc, status, detail)
            if status == self.PASS:   passes += 1
            elif status == self.FAIL: fails  += 1
            elif status == self.WARN: warns  += 1

        # ── layers ─────────────────────────────────────────────────────────
        pop_layer  = self._find(['pop'])
        pon_layer  = self._find(['pon'], exclude=['zone'])
        zone_layer = self._find(['zone'], exclude=['pon'])
        pole_layer = self._find(['pole'])
        hc_layer   = self._find(['home', 'connect']) or self._find(['home'])
        fts_layer  = self._find(['fts'])
        sts_layer  = self._find(['sts'])
        drop_layer = self._find(['drop', 'cable'], exclude=['spare'])
        dist_layer = self._find(['distribution', 'cable']) or self._find(['dist', 'cable'])
        pf_layer   = self._find(['primary', 'cable']) or self._find(['primary', 'feeder'])
        enc_splice = self._find(['enclosure', 'splice']) or self._find(['enclosures', 'splice'])
        enc_conn   = self._find(['enclosure', 'connectoris']) or self._find(['enclosures', 'connectoris'])

        import re
        from qgis.core import (QgsDistanceArea, QgsCoordinateTransformContext, QgsSpatialIndex, QgsGeometry, QgsRectangle)

        da = QgsDistanceArea()
        da.setEllipsoid('WGS84')
        if pole_layer:
            da.setSourceCrs(pole_layer.crs(), QgsCoordinateTransformContext())

        # ── Helper: measure pole-to-pole spans along a cable layer ──────────
        def _pole_spans(cable_lyr, limit_m=70, snap_m=8):
            """Return (over_limit_count, worst_m, details[:5]) using real pole positions."""
            if not pole_layer or not cable_lyr:
                return None, None, []
            snap_deg = snap_m / 99000.0
            # Build pole index once per call
            pidx = QgsSpatialIndex()
            ppts = {}
            for pf in pole_layer.getFeatures():
                if pf.geometry() and not pf.geometry().isNull():
                    pidx.addFeature(pf)
                    ppts[pf.id()] = pf.geometry().asPoint()
            over, details = [], []
            for feat in cable_lyr.getFeatures():
                g = feat.geometry()
                if not g or g.isNull(): continue
                bb = g.boundingBox(); bb.grow(snap_deg)
                on_cable = []
                for pid in pidx.intersects(bb):
                    pt = ppts[pid]
                    pt_g = QgsGeometry.fromPointXY(pt)
                    if g.distance(pt_g) <= snap_deg:
                        on_cable.append((g.lineLocatePoint(pt_g), pt))
                if len(on_cable) < 2: continue
                on_cable.sort(key=lambda x: x[0])
                for i in range(len(on_cable) - 1):
                    seg = QgsGeometry.fromPolylineXY([on_cable[i][1], on_cable[i+1][1]])
                    span_m = da.measureLength(seg)
                    if span_m > limit_m:
                        over.append(round(span_m, 1))
                        if len(details) < 5:
                            lbl = str(feat['label'] or '')
                            details.append(f'{round(span_m,1)}m on {lbl[:35]}')
            over.sort(reverse=True)
            return len(over), (max(over) if over else 0), details

        # ── 1.1 POP ────────────────────────────────────────────────────────
        self._add_section('1.1  POP (Point of Presence)')
        if pop_layer and pop_layer.featureCount() > 0:
            add(1, 'POP exists', self.PASS, f'{pop_layer.featureCount()} feature(s)')
        else:
            add(1, 'POP layer missing or empty', self.FAIL, 'Create a POP polygon near the transmission link')

        if hc_layer and pop_layer and pop_layer.featureCount() > 0:
            total_units = hc_layer.featureCount()
            if 10000 <= total_units <= 25000:
                add(3, 'Units per POP', self.PASS, f'{total_units:,} units')
            elif total_units < 10000:
                add(3, 'Units per POP below minimum', self.WARN, f'{total_units:,} (target 10,000–25,000)')
            else:
                add(3, 'Units per POP above maximum', self.WARN, f'{total_units:,} (target 10,000–25,000)')
        else:
            add(3, 'Units per POP', self.SKIP, 'No POP or Home Connections layer')

        # ── 1.2 PONs & Zones ───────────────────────────────────────────────
        self._add_section('1.2  PONs & Zones')
        if pon_layer and pon_layer.featureCount() > 0:
            add(4, 'PON boundary polygons exist', self.PASS, f'{pon_layer.featureCount()} PONs')
            # Check unit counts per PON
            if hc_layer:
                over = under = ok = 0
                worst_over = worst_under = 0
                for pon in pon_layer.getFeatures():
                    if not pon.geometry() or pon.geometry().isNull():
                        continue
                    cnt = sum(1 for hc in hc_layer.getFeatures()
                              if hc.geometry() and not hc.geometry().isNull()
                              and pon.geometry().contains(hc.geometry()))
                    if cnt < 94:
                        under += 1; worst_under = max(worst_under, 94 - cnt)
                    elif cnt > 102:
                        over += 1; worst_over = max(worst_over, cnt - 102)
                    else:
                        ok += 1
                if over == 0 and under == 0:
                    add(8, 'Units per PON (94–102)', self.PASS, f'All {ok} PONs in range')
                else:
                    msgs = []
                    if over:  msgs.append(f'{over} PON(s) over 102 (worst +{worst_over})')
                    if under: msgs.append(f'{under} PON(s) under 94 (worst -{worst_under})')
                    add(8, 'Units per PON (94–102)', self.FAIL, ' | '.join(msgs))
            else:
                add(8, 'Units per PON', self.SKIP, 'No Home Connections layer')
        else:
            add(4, 'PON boundary polygons missing', self.FAIL, 'Draw PON boundaries first')
            add(8, 'Units per PON', self.SKIP, 'No PON layer')

        if zone_layer and zone_layer.featureCount() > 0:
            add(5, 'Zone boundary polygons exist', self.PASS, f'{zone_layer.featureCount()} Zone(s)')
        else:
            add(5, 'Zone boundary polygons missing', self.WARN, 'Draw zone boundaries')

        # Label format checks for PONs/Zones
        if pon_layer:
            bad = [f[lf] for f in pon_layer.getFeatures()
                   for lf in ('label', 'name', 'Label', 'Name')
                   if lf in [fld.name() for fld in pon_layer.fields()]
                   and f[lf] and not str(f[lf]).startswith(SR + '.PON.')][:3]
            add(6, 'PON label format', self.SKIP if not pon_layer else (self.PASS if not bad else self.WARN),
                f'{len(bad)} label(s) not matching {SR}.PON.### format' if bad else '')

        # ── 1.3 Feeder Network ──────────────────────────────────────────────
        self._add_section('1.3  Feeder Network')
        sf_layer = self._find(['secondary', 'cable'])

        if pf_layer and pf_layer.featureCount() > 0:
            add(9, 'Primary feeder cable exists', self.PASS, f'{pf_layer.featureCount()} segment(s)')
            n_over, worst, dets = _pole_spans(pf_layer, limit_m=70)
            if n_over is None:
                add(15, 'Feeder span check', self.SKIP, 'No poles layer found')
            elif n_over == 0:
                add(15, 'Feeder pole spans all ≤ 70m', self.PASS)
            else:
                add(15, 'Feeder pole span max 70m', self.FAIL,
                    f'{n_over} span(s) over 70m — worst {worst}m | {"; ".join(dets[:3])}')
        else:
            add(9, 'Primary feeder cable missing', self.WARN, 'Route primary feeder from POP')
            add(15, 'Feeder pole spans', self.SKIP, 'No primary feeder cable')

        if sf_layer and sf_layer.featureCount() > 0:
            add(10, 'Secondary feeder cable exists', self.PASS, f'{sf_layer.featureCount()} segment(s)')
            n_over, worst, dets = _pole_spans(sf_layer, limit_m=70)
            if n_over is None:
                add(16, 'Secondary span check', self.SKIP, 'No poles layer found')
            elif n_over == 0:
                add(16, 'Secondary pole spans all ≤ 70m', self.PASS)
            else:
                add(16, 'Secondary pole span max 70m', self.FAIL,
                    f'{n_over} span(s) over 70m — worst {worst}m | {"; ".join(dets[:3])}')
        else:
            add(10, 'Secondary feeder cable', self.SKIP, 'None found (optional)')
            add(15, 'Feeder span check', self.SKIP, 'No feeder layer')

        # ── 1.4 Distribution Network ────────────────────────────────────────
        self._add_section('1.4  Distribution Network')
        if dist_layer and dist_layer.featureCount() > 0:
            add(17, 'Distribution cables exist', self.PASS, f'{dist_layer.featureCount()} segment(s)')
            n_over, worst, dets = _pole_spans(dist_layer, limit_m=70)
            if n_over is None:
                add(19, 'Distribution span check', self.SKIP, 'No poles layer found')
            elif n_over == 0:
                add(19, 'Distribution pole spans all ≤ 70m', self.PASS)
            else:
                add(19, 'Distribution pole span max 70m', self.FAIL,
                    f'{n_over} span(s) over 70m — worst {worst}m | {"; ".join(dets[:3])}')
        else:
            add(17, 'Distribution cables missing', self.WARN)
            add(19, 'Distribution span check', self.SKIP)

        # 8km distance check
        if pop_layer and pop_layer.featureCount() > 0 and hc_layer and hc_layer.featureCount() > 0:
            pop_pt = next(pop_layer.getFeatures()).geometry().centroid().asPoint()
            max_dist = 0
            for hc in hc_layer.getFeatures():
                g = hc.geometry()
                if g and not g.isNull():
                    d = da.measureLine([pop_pt, g.asPoint()])
                    if d > max_dist:
                        max_dist = d
            if max_dist <= 8000:
                add(20, 'Max POP-to-ONT distance ≤ 8km', self.PASS, f'Furthest: {max_dist/1000:.2f}km')
            else:
                add(20, 'Max POP-to-ONT distance > 8km', self.FAIL, f'Furthest: {max_dist/1000:.2f}km — reduce coverage area')
        else:
            add(20, 'POP-to-ONT distance check', self.SKIP, 'Needs POP + Home Connections layers')

        # ── 1.5 Last Mile Drops ─────────────────────────────────────────────
        self._add_section('1.5  Last-Mile Drops')
        if drop_layer and drop_layer.featureCount() > 0:
            add(21, 'Drop cables exist', self.PASS, f'{drop_layer.featureCount()} drops')
            # Check DR label format
            bad_labels = []
            for f in drop_layer.getFeatures():
                lbl = ''
                for fn in ('label', 'Label', 'name', 'Name'):
                    try:
                        v = f[fn]
                        if v: lbl = str(v); break
                    except: pass
                if lbl and not re.match(r'^DR\d{6,}$', lbl):
                    bad_labels.append(lbl)
            if bad_labels:
                add(52, 'Drop cable DR label format', self.WARN,
                    f'{len(bad_labels)} label(s) not matching DR###### (e.g. {bad_labels[0]})')
            else:
                add(52, 'Drop cable DR label format', self.PASS)

            # Check sequential DR numbers
            dr_nums = []
            for f in drop_layer.getFeatures():
                for fn in ('label', 'Label', 'name', 'Name'):
                    try:
                        v = f[fn]
                        if v:
                            m = re.search(r'DR(\d+)', str(v))
                            if m: dr_nums.append(int(m.group(1))); break
                    except: pass
            if dr_nums:
                dr_nums.sort()
                gaps = [dr_nums[i+1] - dr_nums[i] for i in range(len(dr_nums)-1) if dr_nums[i+1] - dr_nums[i] > 1]
                if gaps:
                    add(24, 'DR numbers sequential', self.WARN, f'{len(gaps)} gap(s) in DR sequence')
                else:
                    add(24, 'DR numbers sequential', self.PASS, f'DR{dr_nums[0]:06d}–DR{dr_nums[-1]:06d}')

            # Check drop spans ≤ 50m
            long_drops = []
            for feat in drop_layer.getFeatures():
                g = feat.geometry()
                if not g or g.isNull(): continue
                length = da.measureLength(g)
                if length > 50:
                    long_drops.append(round(length, 1))
            if long_drops:
                add(25, 'Drop spans max 50m', self.FAIL,
                    f'{len(long_drops)} drop(s) over 50m (worst: {max(long_drops)}m)')
            else:
                add(25, 'Drop spans all ≤ 50m', self.PASS)
        else:
            add(21, 'Drop cables missing', self.WARN)
            add(24, 'DR number check', self.SKIP)
            add(25, 'Drop span check', self.SKIP)

        # Drop count per STS dome
        if sts_layer and drop_layer and sts_layer.featureCount() > 0:
            drop_index = QgsSpatialIndex()
            drop_feats = {}
            for df in drop_layer.getFeatures():
                if df.geometry() and not df.geometry().isNull():
                    drop_index.insertFeature(df)
                    drop_feats[df.id()] = df
            over_8 = over_16 = ok = 0
            snap_r = 5.0 / 99000.0
            for sts in sts_layer.getFeatures():
                g = sts.geometry()
                if not g or g.isNull(): continue
                pt = g.asPoint()
                rect = QgsRectangle(pt.x()-snap_r*10, pt.y()-snap_r*10, pt.x()+snap_r*10, pt.y()+snap_r*10)
                cnt = len(drop_index.intersects(rect))
                if cnt > 16: over_16 += 1
                elif cnt > 8: over_8  += 1
                else: ok += 1
            if over_16 == 0 and over_8 == 0:
                add(21, 'Drop count per STS dome', self.PASS, f'All {ok} STS domes ≤ 8 drops')
            elif over_16 > 0:
                add(21, 'Drop count per STS dome', self.FAIL, f'{over_16} STS dome(s) over 16 drops')
            else:
                add(21, 'Drop count per STS dome', self.WARN, f'{over_8} STS dome(s) between 9-16 drops')

        # ── 1.7 Splitters ───────────────────────────────────────────────────
        self._add_section('1.7  Splitters')
        if fts_layer and fts_layer.featureCount() > 0:
            add(32, 'FTS splitters exist', self.PASS, f'{fts_layer.featureCount()} FTS')
        else:
            add(32, 'FTS splitters missing', self.WARN)
        if sts_layer and sts_layer.featureCount() > 0:
            add(34, 'STS splitters exist', self.PASS, f'{sts_layer.featureCount()} STS')
        else:
            add(34, 'STS splitters missing', self.WARN)

        # ── 1.8 Poles ───────────────────────────────────────────────────────
        self._add_section('1.8  Poles')
        if pole_layer and pole_layer.featureCount() > 0:
            add(35, 'Poles exist', self.PASS, f'{pole_layer.featureCount()} poles')
            # Check for NULL labels
            null_lbl = 0
            for f in pole_layer.getFeatures():
                lbl = ''
                for fn in ('Name', 'name', 'Name.', 'label', 'Label'):
                    try:
                        v = f[fn]
                        if v and str(v).strip(): lbl = str(v); break
                    except: pass
                if not lbl:
                    null_lbl += 1
            if null_lbl:
                add(55, 'Pole labels', self.WARN, f'{null_lbl} pole(s) with no label')
            else:
                add(55, 'Pole labels', self.PASS)

            # Check label format
            bad_fmt = []
            for f in pole_layer.getFeatures():
                for fn in ('Name', 'name', 'Name.'):
                    try:
                        v = f[fn]
                        if v and str(v).strip():
                            if not re.match(rf'^{re.escape(SR)}\.P\.[A-Z]\d{{3}}', str(v)):
                                bad_fmt.append(str(v))
                            break
                    except: pass
            bad_fmt = bad_fmt[:5]
            if bad_fmt:
                add(55, f'Pole label format ({SR}.P.A001)', self.WARN,
                    f'{len(bad_fmt)} label(s) not matching (e.g. {bad_fmt[0]})')
        else:
            add(35, 'Poles missing', self.FAIL)

        # ── 1.12 Labels ─────────────────────────────────────────────────────
        self._add_section('1.12  Labels & Attributes')

        # Attribute completeness — check for all-NULL features per layer
        layer_checks = [
            (pole_layer,  'Poles',                ['Name', 'name', 'Name.']),
            (sts_layer,   'STS Splitters',         ['label', 'Label', 'name']),
            (fts_layer,   'FTS Splitters',         ['label', 'Label', 'name']),
            (dist_layer,  'Distribution Cable',    ['label', 'Label', 'name']),
            (drop_layer,  'Drop Cable',            ['label', 'Label', 'name']),
            (enc_splice,  'Enclosures Splice',     ['label', 'Label', 'label_1']),
            (enc_conn,    'Enclosures Connectorised', ['label', 'Label', 'label_1']),
        ]
        for lyr, lyr_name, label_fields in layer_checks:
            if not lyr or lyr.featureCount() == 0:
                continue
            null_cnt = 0
            fld_names = [f.name() for f in lyr.fields()]
            check_fields = [fn for fn in label_fields if fn in fld_names]
            if not check_fields:
                continue
            for f in lyr.getFeatures():
                has_val = any(f[fn] and str(f[fn]).strip() for fn in check_fields)
                if not has_val:
                    null_cnt += 1
            pct = null_cnt * 100 // lyr.featureCount()
            if null_cnt == 0:
                add(64, f'{lyr_name} — all labels populated', self.PASS)
            elif pct > 50:
                add(64, f'{lyr_name} — labels mostly empty', self.FAIL, f'{null_cnt}/{lyr.featureCount()} NULL')
            else:
                add(64, f'{lyr_name} — some labels missing', self.WARN, f'{null_cnt}/{lyr.featureCount()} NULL')

        # ── 1.13 Symbology ──────────────────────────────────────────────────
        self._add_section('1.13  Symbology & Duplicates')

        # Duplicate detection (features at exact same coordinate)
        for lyr, lyr_name in [(pole_layer, 'Poles'), (sts_layer, 'STS'), (fts_layer, 'FTS')]:
            if not lyr or lyr.featureCount() == 0:
                continue
            coords = {}
            for f in lyr.getFeatures():
                g = f.geometry()
                if not g or g.isNull(): continue
                pt = g.asPoint()
                key = (round(pt.x(), 6), round(pt.y(), 6))
                coords[key] = coords.get(key, 0) + 1
            dups = sum(1 for v in coords.values() if v > 1)
            if dups:
                add(64, f'{lyr_name} duplicates', self.FAIL, f'{dups} location(s) with stacked features')
            else:
                add(64, f'{lyr_name} no duplicates', self.PASS)

        # Score
        total = passes + fails + warns
        pct = int(passes * 100 / total) if total else 0
        color = '#1a6b3c' if pct >= 80 else ('#7a5a00' if pct >= 60 else '#7a1a1a')
        bg    = '#e8f5ee'  if pct >= 80 else ('#fff8e1'  if pct >= 60 else '#fdecea')
        self._score_lbl.setText(
            f'  Score: {passes}/{total} passed  ({pct}%)    '
            f'✅ {passes}  ❌ {fails}  ⚠️ {warns}'
        )
        self._score_lbl.setStyleSheet(
            f'font-size: 13px; font-weight: bold; padding: 6px 10px; '
            f'border-radius: 4px; background: {bg}; color: {color};'
        )
        self._score_lbl.show()
        self._export_btn.setEnabled(True)
        QApplication.processEvents()

    def _export(self):
        path, _ = QFileDialog.getSaveFileName(
            self, 'Save Audit Report', '', 'Text Files (*.txt)'
        )
        if path:
            with open(path, 'w', encoding='utf-8') as f:
                f.write('\n'.join(self._report_lines))
            self._push_message(f'Report saved: {path}', 'info')

    def _push_message(self, msg, level='info'):
        from qgis.core import Qgis
        lvl = {'info': Qgis.Info, 'warning': Qgis.Warning}.get(level, Qgis.Info)
        self.plugin.iface.messageBar().pushMessage('HLD Audit', msg, level=lvl, duration=4)


class _PhaseMarker(QWidget):
    """Thin toolbar widget that shows a phase number at the top and a vertical divider below.
    Used as a visual separator between workflow phase groups in the toolbar."""

    def __init__(self, num, parent=None):
        super().__init__(parent)
        self.setFixedWidth(22)
        self.setMinimumHeight(36)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 3, 0, 3)
        layout.setSpacing(0)

        lbl = QLabel(str(num))
        lbl.setAlignment(Qt.AlignHCenter | Qt.AlignTop)
        lbl.setStyleSheet(
            'font-size: 8px; color: #aaa; font-weight: bold; '
            'font-family: monospace; background: transparent;'
        )
        lbl.setFixedHeight(11)
        layout.addWidget(lbl)

        # 1 px vertical line, centred horizontally
        line_row = QHBoxLayout()
        line_row.setContentsMargins(0, 0, 0, 0)
        line_row.setSpacing(0)
        line = QWidget()
        line.setFixedWidth(1)
        line.setStyleSheet('background-color: #ccc;')
        line_row.addStretch()
        line_row.addWidget(line)
        line_row.addStretch()
        layout.addLayout(line_row, 1)


class FibretimeTools:
    def __init__(self, iface):
        self.iface            = iface
        self.logo_toolbar     = None
        self.toolbar          = None
        self._pipeline_ns     = None   # loaded on first use
        self._sf_params       = {}
        self._qp_sr           = ''
        self._qsts_sr         = ''
        self._qsts_pole_index = None
        self._qsts_poles_feats = {}
        self.actions          = []
        self._centroid_worker = None
        # Roads cache — built once per SR, reused across all Plan Block calls
        self._road_index      = None   # QgsSpatialIndex
        self._road_geoms      = {}     # {fid: QgsGeometry}
        self._road_sr         = None   # SR string the cache was built for
        self._qagg_sr         = ''
        self._qagg_pole_index = None
        self._qagg_poles_feats = {}
        self._qpon_sr         = ''
        self._qzone_sr        = ''
        self._qdist_sr          = ''
        self._qdist_first_pt    = None   # first pole click for dist cable tool
        self._qdist_pole_index  = None
        self._qdist_poles_feats = {}
        self._backed_up_layers  = set()  # layer IDs backed up this session
        self._flash_timer       = None   # repeating timer for span flash

    # ── Logo widget ────────────────────────────────────────
    def _make_logo_widget(self):
        """Draws the VelocityFibre V mark + 'Velocity Fibre' text."""
        W, H = 148, 32
        pix = QPixmap(W, H)
        pix.fill(Qt.transparent)

        p = QPainter(pix)
        p.setRenderHint(QPainter.Antialiasing)

        # ── V icon (24×28, vertically centred) ──────────────────
        IW, IH = 24, 28
        IX = 2
        IY = (H - IH) / 2

        grad = QLinearGradient(IX + IW * 0.2, IY, IX + IW * 0.6, IY + IH)
        grad.setColorAt(0.0, QColor('#3d5cb8'))   # navy blue
        grad.setColorAt(1.0, QColor('#8b2450'))   # deep crimson

        cx  = IX + IW / 2
        tip = IY + IH
        top = IY + 7   # below the dot

        path = QPainterPath()
        # outer left → tip
        path.moveTo(IX, top)
        path.cubicTo(IX,          top + 5,  cx - 3.5, tip - 6,  cx,      tip)
        # tip → outer right
        path.cubicTo(cx + 3.5,    tip - 6,  IX + IW,  top + 5,  IX + IW, top)
        # inner right → near tip
        path.cubicTo(IX + IW - 1, top + 3,  cx + 2,   tip - 10, cx,      tip - 5)
        # near tip → inner left
        path.cubicTo(cx - 2,      tip - 10, IX + 1,   top + 3,  IX,      top)
        path.closeSubpath()

        p.setPen(Qt.NoPen)
        p.fillPath(path, QBrush(grad))

        # dot above right arm tip
        p.setBrush(QBrush(QColor('#2d4aaa')))
        p.drawEllipse(QPointF(IX + IW - 2, IY + 2.5), 3.5, 3.5)

        # ── Text ─────────────────────────────────────────────────
        TX = IX + IW + 6
        mid = H // 2

        font_v = QFont('Segoe UI', 9, QFont.Bold)
        p.setFont(font_v)
        p.setPen(QColor('#1a2050'))
        p.drawText(TX, mid + 4, 'Velocity')

        # measure 'Velocity' width to position 'Fibre' right after
        fm = p.fontMetrics()
        vel_w = fm.horizontalAdvance('Velocity')

        font_f = QFont('Segoe UI', 9, QFont.Normal)
        p.setFont(font_f)
        p.setPen(QColor('#7a86a0'))
        p.drawText(TX + vel_w + 3, mid + 4, 'Fibre')

        p.end()

        label = QLabel()
        label.setPixmap(pix)
        label.setFixedSize(W, H)
        label.setContentsMargins(4, 0, 8, 0)
        label.setToolTip('VelocityFibre — Fibertime™ Network Planning Tools')
        return label

    def initGui(self):
        # ── Logo toolbar ──────────────────────────────────────────
        self.logo_toolbar = self.iface.addToolBar('VelocityFibre')
        self.logo_toolbar.setObjectName('VelocityFibreLogoBar')
        self.logo_toolbar.setMovable(True)
        self.logo_toolbar.addWidget(self._make_logo_widget())

        # ── Main toolbar ──────────────────────────────────────────
        self.toolbar = self.iface.addToolBar('Fibertime Tools')
        self.toolbar.setObjectName('FibretimeToolbar')
        self.toolbar.setMovable(True)

        # ── NEW PROJECT setup dropdown ────────────────────────────
        setup_btn = QToolButton()
        setup_btn.setText('🆕  New Project')
        setup_btn.setToolTip('Set up a brand-new project area from scratch')
        setup_btn.setPopupMode(QToolButton.InstantPopup)
        setup_menu = QMenu(setup_btn)
        setup_menu.addAction('🏗️  Setup Project', self.run_setup_project).setToolTip(
            'Run once at the start of every new project area.\n'
            '  1. Creates all standard Fibertime layers\n'
            '  2. Downloads cadastral erf boundaries (DRDLR)\n'
            '  3. Auto-places Home Connections from Overture buildings\n'
            'Checkboxes let you skip steps already done.')
        setup_menu.addSeparator()
        setup_menu.addAction('🏠  Place Home Connections', self.run_hc_from_erven).setToolTip(
            'Bulk-place Home Connection points from erven centroids.\n'
            'Places 1 HC per erf, skips erven that already have one nearby.')
        setup_menu.addSeparator()
        setup_menu.addAction('⚡  Auto PON Boundaries', self.run_generate_pons).setToolTip(
            'Auto-generate PON boundaries from the Erven layer.\n'
            'Morton Z-order clustering, target 96 units per PON.')
        setup_menu.addAction('✏️  Draw PON', self.run_quick_pon).setToolTip(
            'Manually draw a single PON boundary polygon.\n'
            'Target: 94–102 homes per PON.')
        setup_menu.addSeparator()
        setup_menu.addAction('⚡  Auto Zone Boundaries', self.run_generate_zones).setToolTip(
            'Auto-generate Zone boundaries from existing PON boundaries.\n'
            '1 Zone = 1 OLT card = up to 16 PONs.')
        setup_menu.addAction('✏️  Draw Zone', self.run_quick_zone).setToolTip(
            'Manually draw a single Zone boundary polygon.')
        setup_btn.setMenu(setup_menu)
        self.actions.append(self.toolbar.addWidget(setup_btn))

        self.toolbar.addSeparator()

        # ── PLACE NODES dropdown ──────────────────────────────────
        nodes_btn = QToolButton()
        nodes_btn.setText('🏗️  Place Nodes')
        nodes_btn.setToolTip('Place poles, splice enclosures, and splitters on the map')
        nodes_btn.setPopupMode(QToolButton.InstantPopup)
        nodes_menu = QMenu(nodes_btn)
        nodes_menu.addAction('🪧  Place Pole', self.run_quick_pole).setToolTip(
            'Click on the map to place a single distribution pole.\n'
            'Fills all standard Fibertime pole attributes automatically.\n'
            'Right-click or Esc to stop.')
        nodes_menu.addSeparator()
        nodes_menu.addAction('🟡  Place AGG Dome', self.run_quick_agg_dome).setToolTip(
            'Click near a feeder pole to place a CMJ 144F AGG splice enclosure.\n'
            'Snaps within 30 m. FTS + SS splitters live inside AGG Domes.\n'
            'Run Auto FTS+SS Splitters after placing all AGG Domes.')
        nodes_menu.addAction('⚡  Auto FTS+SS Splitters', self.run_auto_fts).setToolTip(
            'Batch-place bare 1:16 FTS + spare 1:16 SS at every AGG Dome.\n'
            'Skips domes that already have an FTS/SS within 2 m.')
        nodes_menu.addSeparator()
        nodes_menu.addAction('🔵  Place STS Dome', self.run_quick_sts).setToolTip(
            'Click near a distribution pole to place a connectorised 1:8 STS splitter.\n'
            'Snaps within 30 m. Drop cables from homes connect to STS domes.')
        nodes_menu.addAction('⚡  Auto STS Splitters', self.run_auto_sts).setToolTip(
            'Batch-place connectorised 1:8 LC/APC STS at every DIS Dome.\n'
            'Skips domes that already have an STS within 2 m.')
        nodes_btn.setMenu(nodes_menu)
        self.actions.append(self.toolbar.addWidget(nodes_btn))

        # ── DRAW CABLES dropdown ──────────────────────────────────
        cables_btn = QToolButton()
        cables_btn.setText('〰️  Draw Cables')
        cables_btn.setToolTip('Draw distribution and feeder cables between poles')
        cables_btn.setPopupMode(QToolButton.InstantPopup)
        cables_menu = QMenu(cables_btn)
        cables_menu.addAction('〰️  Draw Distribution Cable', self.run_quick_dist_cable).setToolTip(
            'Click start pole, then end pole — draws a 24F Mini-ADSS distribution cable.\n'
            'Runs midblock between distribution poles (cyan on map).')
        cables_menu.addAction('🤖  Auto-Plan Street Block', self.run_plan_block).setToolTip(
            'Draw a midblock centre line — auto-places poles + STS + 24F cable.\n'
            'Groups homes into sets of 4 per side (8 drops per pole).\n'
            'Fastest way to plan a full street block in one draw.')
        cables_menu.addSeparator()
        cables_menu.addAction('🔵  Draw Primary Feeder', self.run_primary_feeder).setToolTip(
            'Draw the primary feeder route (POP → AGG Domes).\n'
            'Auto-places feeder poles every ~40 m and auto-sizes cable capacity.')
        cables_menu.addAction('🟠  Draw Secondary Feeder', self.run_secondary_feeder).setToolTip(
            'Draw a secondary feeder branch off the primary.\n'
            'Auto-places feeder poles at same spacing. Double-up sizing rule applies.')
        cables_btn.setMenu(cables_menu)
        self.actions.append(self.toolbar.addWidget(cables_btn))

        # ── CONNECT DROPS ─────────────────────────────────────────
        self._add_btn(
            text='🔗  Connect Drops',
            tooltip=(
                'Auto-connect unlinked home connections to the nearest STS dome.\n\n'
                '  • Finds every STS dome with fewer than 8 connected drops\n'
                '  • Connects the nearest unconnected home connections\n'
                '  • Creates 1F green drop cables with sequential DR numbers\n\n'
                'Max 8 drops per STS dome. Run Label Network afterwards.'
            ),
            callback=self.run_auto_drops
        )

        self.toolbar.addSeparator()

        # ── FINALISE (direct buttons — used frequently) ───────────
        self._add_btn(
            text='⚙️  Populate Attributes',
            tooltip=(
                'Fill all layer attributes from the drawn network.\n\n'
                'Step-by-step dialog: PON → Poles → Splitters → Cables\n'
                '→ Homes/Drops → Enclosures → QA\n\n'
                'Check the Python Console for output after each step.'
            ),
            callback=self.run_populate_pipeline
        )
        self._add_btn(
            text='🏷️  Label Network',
            tooltip=(
                'Fill all NULL labels across every network layer.\n\n'
                'Safe to run at any time — does not overwrite existing labels.\n'
                'Run after adding new features or after Populate Attributes.'
            ),
            callback=self.run_master_update
        )
        self._add_btn(
            text='✅  HLD Compliance Audit',
            tooltip=(
                'Run the Fibertime HLD compliance checklist.\n\n'
                '  • PON sizes (94–102 units each)\n'
                '  • Span lengths (max 70 m feeder/dist, max 50 m drops)\n'
                '  • DR number format and sequential order\n'
                '  • Attribute completeness (no NULL labels)\n'
                '  • Drop count per STS dome (max 8)\n'
                '  • 8 km max POP-to-ONT distance\n\n'
                'Shows Pass / Fail / Warning. Export report for submission.'
            ),
            callback=self.run_hld_audit
        )
        self._add_btn(
            text='📏  Check Long Spans',
            tooltip=(
                'Highlight all cable spans exceeding the 70 m Fibertime limit.\n\n'
                'Scans Primary, Secondary and Distribution cables using real pole\n'
                'positions. Creates a "Long Spans" layer on the map.\n'
                'Click again to clear and stop the highlight.'
            ),
            callback=self.run_show_spans
        )
        self._add_btn(
            text='📑  Bill of Materials',
            tooltip=(
                'Generate Bill of Materials CSV for HLD submission.\n\n'
                '  • Hook type per pole (1-Way, 2-Way, 3-Way Offset)\n'
                '  • Dead-end and tangent counts per pole\n'
                '  • Slack bracket locations (at splice enclosures)\n'
                '  • Pigtail screws per pole\n\n'
                'Exports a CSV with per-pole breakdown + totals row.\n'
                'Required for HLD checklist items 43–50.'
            ),
            callback=self.run_bom_generator
        )
        self._add_btn(
            text='💾  Export OES CSV',
            tooltip=(
                'Export OES (ONT Easy Start) provisioning file for the OLT.\n\n'
                '  • UUID = DR number\n'
                '  • Service template: Final_L2_Service_Template\n'
                '  • Sequential activation codes\n'
                '  • Link budget values (enter OLT RX and ONT RX)\n\n'
                'Export per 1,000 drops. Submit with HLD package.'
            ),
            callback=self.run_oes_export
        )

        self.toolbar.addSeparator()

        # ── RECORD PON FEEDER ORDER ───────────────────────────────
        self._pon_record_action = QAction('🔴  Record PON Order', self.iface.mainWindow())
        self._pon_record_action.setToolTip(
            'Record the physical feeder order of PON polygons.\n\n'
            '  1. Click this button to activate the map tool\n'
            '  2. Click each PON v1 polygon in physical feeder order\n'
            '  3. Click the button again, or right-click / Escape to stop\n\n'
            'Order saved to: pon_feeder_order.txt\n'
            'Run FT 6 (Apply Feeder-Path PON Order) when all 64 are recorded.'
        )
        self._pon_record_action.triggered.connect(self._toggle_pon_recorder)
        self.toolbar.addAction(self._pon_record_action)
        self.actions.append(self._pon_record_action)
        self._pon_map_tool = None


    # Same env override as fibernetwork:ft_apply_pon_order; literal is the dev fallback.
    _PON_ORDER_FILE = os.environ.get(
        'MOA_PON_ORDER_FILE',
        'C:/Users/jjsch/OneDrive - blitzfibre.com/Documents/Workspace/QGIS'
        '/pon_feeder_order.txt'
    )

    def _toggle_pon_recorder(self):
        """Activate / deactivate the PON click-recorder map tool."""
        canvas = self.iface.mapCanvas()

        # If tool already active — deactivate
        if self._pon_map_tool and canvas.mapTool() is self._pon_map_tool:
            canvas.unsetMapTool(self._pon_map_tool)
            self._pon_map_tool = None
            self.iface.messageBar().pushMessage('PON Recorder', 'Stopped.', level=0, duration=3)
            return

        order_file = self._PON_ORDER_FILE
        if os.path.exists(order_file):
            with open(order_file) as f:
                count = sum(1 for l in f if l.strip())
        else:
            count = 0

        # If entries exist, ask whether to reset or continue
        if 0 < count < 64:
            reply = QMessageBox.question(
                self.iface.mainWindow(),
                'PON Order',
                f'{count}/64 PONs already recorded.\n\nReset and start over from position 1?',
                QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel,
            )
            if reply == QMessageBox.Cancel:
                return
            if reply == QMessageBox.Yes:
                open(order_file, 'w').close()
                count = 0
            # No = continue from where we left off

        if count >= 64:
            reply = QMessageBox.question(
                self.iface.mainWindow(),
                'PON Order',
                'All 64 PONs already recorded.\n\nReset and start over?',
                QMessageBox.Yes | QMessageBox.No,
            )
            if reply != QMessageBox.Yes:
                return
            open(order_file, 'w').close()
            count = 0

        self._pon_map_tool = PonRecorderMapTool(
            canvas, self.iface, order_file, action=self._pon_record_action)
        self._pon_record_action.setText(f'🔴  {count}/64 recorded')
        canvas.setMapTool(self._pon_map_tool)

        remaining = 64 - count
        self.iface.messageBar().pushMessage(
            '🔴 PON Recorder ACTIVE',
            f'Click PON polygons in feeder order. {remaining} remaining. Click button again or Esc to stop.',
            level=0, duration=8)

    def _add_btn(self, text, tooltip, callback):
        action = QAction(text, self.iface.mainWindow())
        action.setToolTip(tooltip)
        action.triggered.connect(callback)
        self.toolbar.addAction(action)
        self.actions.append(action)

    def _add_phase_sep(self, num):
        """Add a phase-number marker + vertical divider between toolbar groups."""
        marker = _PhaseMarker(num)
        action = self.toolbar.addWidget(marker)
        self.actions.append(action)

    def unload(self):
        # Stop background thread if running
        if self._centroid_worker and self._centroid_worker.isRunning():
            self._centroid_worker.cancel()
            self._centroid_worker.quit()
            self._centroid_worker.wait(3000)
        self._centroid_worker = None

        # Unset any active map tool so rubber bands / snap markers are cleaned up
        canvas = self.iface.mapCanvas()
        if canvas.mapTool():
            canvas.unsetMapTool(canvas.mapTool())

        # Clear road cache
        self._road_index = None
        self._road_geoms = {}

        for action in self.actions:
            self.toolbar.removeAction(action)
        for tb in [self.toolbar, self.logo_toolbar]:
            if tb:
                self.iface.mainWindow().removeToolBar(tb)
                tb.deleteLater()
        self.toolbar = None
        self.logo_toolbar = None

    # ── PIPELINE ──────────────────────────────────────────
    def _get_pipeline_ns(self):
        """Load fibre_automation.py into a persistent namespace (once per session)."""
        if self._pipeline_ns is not None:
            return self._pipeline_ns
        script = os.path.join(os.path.dirname(__file__), 'fibre_automation.py')
        if not os.path.exists(script):
            QMessageBox.critical(None, 'Not found', f'Pipeline script not found:\n{script}')
            return None
        try:
            ns = {'iface': self.iface, 'QgsProject': QgsProject}
            with open(script, 'r') as f:
                exec(f.read(), ns)
            self._pipeline_ns = ns
            return ns
        except Exception as e:
            QMessageBox.critical(None, 'Load Error', f'Failed to load pipeline script:\n{e!s}')
            return None

    def run_pipeline_dialog(self):
        dlg = PipelineDialog(self, self.iface.mainWindow())
        dlg.exec_()

    # ── MASTER UPDATE ─────────────────────────────────────
    def run_master_update(self):
        script = os.path.join(SCRIPTS_BASE, 'Master Update V1', 'master_update_v1.py')
        if not os.path.exists(script):
            QMessageBox.warning(None, 'Not found', f'Script not found:\n{script}')
            return

        # Auto-detect actual layer names using fuzzy matching so the script
        # works regardless of whether layers have ' v1' suffix or not
        def _lname(keywords, exclude=None):
            lyr = self._find_layer(keywords, exclude=exclude)
            return lyr.name() if lyr else ''

        # Read project metadata stored by Setup Project
        _pvars   = QgsProject.instance().customVariables()
        mun      = _pvars.get('ft_mun',      '')
        subplace = _pvars.get('ft_subplace', '')

        # Auto-detect SR and prev_last in a single pass over the poles layer
        sr = _pvars.get('ft_sr', '') or self._detect_sr_code() or 'FT'
        prev_last = 'A000'
        poles_lyr = self._find_layer(['pole'])
        if poles_lyr:
            label_idx = poles_lyr.fields().indexOf('Label')
            if label_idx != -1:
                for f in poles_lyr.getFeatures():
                    lbl = str(f.attributes()[label_idx])
                    if lbl and lbl not in ('NULL', 'None', '') and '.' in lbl:
                        if not _pvars.get('ft_sr'):
                            sr = lbl.split('.')[0]
                        prev_last = lbl.split('.')[-1]
                        break  # first labeled pole is enough for SR + non-A000 sentinel

        overrides = {
            'SR':            sr,
            'PREV_LAST_POLE': prev_last,
            'POLES_LAYER':   _lname(['pole']),
            'ENC_LAYER':     _lname(['enclosure'], exclude=['connectoris', 'splice', 'connec']),
            'CON_LAYER':     _lname(['enclosure', 'connectoris']),
            'SPL_LAYER':     _lname(['enclosure', 'splice']),
            'DIST_LAYER':    _lname(['distribution', 'cable']),
            'SPAN_LAYER':    _lname(['span']),
            'ONT_LAYER':     _lname(['ont']),
            'HC_LAYER':      _lname(['home', 'connect']),
            'PON_LAYER':     _lname(['pon']),
            'ZONE_LAYER':    _lname(['zones']),
            'PRIM_LAYER':    _lname(['primary', 'cable']),
            'SEC_LAYER':     _lname(['secondary', 'cable']),
            'DROP_LAYER':    _lname(['drop', 'cable'], exclude=['spare']),
            'SPARE_LAYER':   _lname(['spare', 'drop']),
            'FTS_LAYER':     _lname(['fts']),
            'STS_LAYER':     _lname(['sts']),
        }
        # Remove empty-string entries — missing layers stay at script defaults (already handled)
        overrides = {k: v for k, v in overrides.items() if v != ''}

        # Commit any pending edits first — the script uses dataProvider which
        # cannot see features still sitting in the edit buffer (negative FIDs)
        for lyr in QgsProject.instance().mapLayers().values():
            if hasattr(lyr, 'isEditable') and lyr.isEditable():
                lyr.commitChanges()

        try:
            with open(script, 'r') as f:
                code = f.read()
            # Patch the hardcoded config lines in-place before running so our
            # detected values win even though the script reassigns them
            def _sq(v):
                """Escape single quotes so the patched Python string stays valid."""
                return str(v).replace("'", "\\'")
            for var, val in overrides.items():
                code = re.sub(
                    rf"^({var}\s*=\s*)['\"].*?['\"]",
                    rf"\g<1>'{_sq(val)}'",
                    code,
                    flags=re.MULTILINE
                )
            # Patch STATIC dict — municipality, subplace, stackref
            if mun:
                code = re.sub(r"('mun'\s*:\s*)'[^']*'",      rf"\g<1>'{_sq(mun)}'",      code)
            if subplace:
                code = re.sub(r"('subplace'\s*:\s*)'[^']*'",  rf"\g<1>'{_sq(subplace)}'", code)
                code = re.sub(r"('mainplce'\s*:\s*)'[^']*'",  rf"\g<1>'{_sq(subplace)}'", code)
            code = re.sub(r"('stackref'\s*:\s*)'[^']*'",      rf"\g<1>'{_sq(sr)}'",       code)
            # Patch hardcoded values in the poles section si() calls
            if mun:
                code = re.sub(r"(si\(mun_idx\s*,\s*)'[^']*'",      rf"\g<1>'{_sq(mun)}'",      code)
            if subplace:
                code = re.sub(r"(si\(mainpl_idx\s*,\s*)'[^']*'",   rf"\g<1>'{_sq(subplace)}'", code)
                code = re.sub(r"(si\(subplace_idx\s*,\s*)'[^']*'", rf"\g<1>'{_sq(subplace)}'", code)
            code = re.sub(r"(si\(stack_idx\s*,\s*)'[^']*'",        rf"\g<1>'{_sq(sr)}'",       code)
            exec(code, {'iface': self.iface, 'QgsProject': QgsProject})
        except Exception as e:
            QMessageBox.critical(None, 'Error', str(e))
            return

        # ── Post-script: force-update admin fields on ALL features ─
        # The main script's polish step only fills NULLs — existing features
        # labeled in a previous run keep stale municipality/subplace/stackref.
        # Force-overwrite these three fields across every Fibertime layer.
        if mun or subplace or sr:
            self._force_update_admin(sr, mun, subplace)

        # ── Post-script: label NULL STS splitters ──────────────
        # The master update script only RE-labels STS (updates OLT port).
        # It has no step to assign initial labels to brand-new NULL STS.
        # Format: {SR}.STS.8.DIS.DM.P.{nearest_pole}
        self._label_null_sts(sr)

    def _label_null_sts(self, sr):
        sts_lyr   = self._find_layer(['sts'])
        poles_lyr = self._find_layer(['pole'])
        if not sts_lyr or not poles_lyr:
            return

        # Build pole spatial index
        pole_index = QgsSpatialIndex(poles_lyr.getFeatures())
        pole_feats = {f.id(): f for f in poles_lyr.getFeatures()}

        label_idx = sts_lyr.fields().indexOf('label')
        if label_idx == -1:
            return

        changes = {}
        for feat in sts_lyr.getFeatures():
            lbl = feat.attributes()[label_idx]
            if lbl and str(lbl).strip() not in ('', 'NULL', 'None'):
                continue  # already labeled
            geom = feat.geometry()
            if not geom or geom.isNull():
                continue
            pt = geom.asPoint()
            nearest = pole_index.nearestNeighbor(QgsPointXY(pt.x(), pt.y()), 1)
            if not nearest:
                continue
            pole_lbl = str(pole_feats[nearest[0]]['Label'])
            if not pole_lbl or pole_lbl in ('NULL', 'None'):
                continue
            alphanum = pole_lbl.split('.')[-1]
            new_lbl = f'{sr}.STS.8.DIS.DM.P.{alphanum}'
            changes[feat.id()] = {label_idx: new_lbl}

        if changes:
            sts_lyr.dataProvider().changeAttributeValues(changes)
            sts_lyr.reload()

    def _force_update_admin(self, sr, mun, subplace):
        """Force-overwrite municipality/subplace/stackref on ALL labeled features.
        Every layer has slightly different field names — map them all."""
        # (field_name_in_layer, value_to_set)
        FIELD_MAP = [
            ('mun',       mun),       # STS, FTS, cables, enclosures
            ('municipal', mun),       # poles
            ('mainplce',  subplace),  # most layers
            ('mainplace', subplace),  # poles
            ('subplace',  subplace),  # all layers
            ('stackref',  sr),        # most layers
            ('stack',     sr),        # poles
        ]
        # Fibertime layers always have 'stackref' OR 'stack' field
        FT_FIELDS = {'stackref', 'stack', 'mun', 'municipal', 'mainplce', 'mainplace', 'subplace'}
        for lyr in QgsProject.instance().mapLayers().values():
            if not hasattr(lyr, 'featureCount') or lyr.featureCount() == 0:
                continue
            # Only update layers that have at least one Fibertime admin field
            lyr_field_names = {f.name().lower() for f in lyr.fields()}
            if not FT_FIELDS.intersection(lyr_field_names):
                continue
            # Build index of which fields exist in this layer
            field_updates = {}
            for fname, val in FIELD_MAP:
                idx = lyr.fields().indexOf(fname)
                if idx != -1 and val:
                    field_updates[idx] = val
            if not field_updates:
                continue
            changes = {}
            for feat in lyr.getFeatures():
                row = {idx: val for idx, val in field_updates.items()}
                changes[feat.id()] = row
            if changes:
                lyr.dataProvider().changeAttributeValues(changes)
                lyr.reload()

    # ── POPULATE PIPELINE ─────────────────────────────────
    def run_populate_pipeline(self):
        dlg = PopulatePipelineDialog(self, self.iface.mainWindow())
        dlg.exec_()

    def run_hld_audit(self):
        dlg = HLDAuditDialog(self, self.iface.mainWindow())
        dlg.exec_()

    # ── SHOW / STOP LONG SPANS ────────────────────────────
    def run_stop_flash(self):
        """Stop all flash animations — cleans up timer, rubber bands and QVariantAnimations."""
        from qgis.PyQt.QtCore import QVariantAnimation, QTimer
        from qgis.gui import QgsRubberBand
        import gc

        # Stop our own stored timer
        if self._flash_timer is not None:
            self._flash_timer.stop()
            self._flash_timer = None

        # Sweep gc for any orphaned QTimers at 2 s interval (the flash timer interval)
        for obj in gc.get_objects():
            try:
                if isinstance(obj, QTimer) and obj.isActive() and obj.interval() == 2000:
                    obj.stop()
            except Exception:
                pass

        # Kill QVariantAnimations and rubber bands on the canvas
        canvas = self.iface.mapCanvas()
        for child in list(canvas.children()):
            if isinstance(child, QVariantAnimation):
                child.stop()
                child.setParent(None)
                child.deleteLater()
        for item in list(canvas.scene().items()):
            if isinstance(item, QgsRubberBand):
                item.setOpacity(0)
                canvas.scene().removeItem(item)
        canvas.scene().update()
        canvas.refresh()

    def run_show_spans(self):
        """Create a Long Spans layer and flash violations on the canvas."""
        from qgis.core import (QgsDistanceArea, QgsSpatialIndex, QgsGeometry,
                               QgsVectorLayer, QgsField, QgsFeature)
        from qgis.PyQt.QtCore import QVariant, QTimer

        # Stop any existing flash first
        self.run_stop_flash()

        proj = QgsProject.instance()
        da = QgsDistanceArea()
        da.setSourceCrs(proj.crs(), proj.transformContext())
        da.setEllipsoid('WGS84')

        snap_deg = 8 / 99000.0
        limit_m = 70

        pole_layer = self._find(['pole'])
        if not pole_layer:
            QMessageBox.warning(None, 'Show Spans', 'No poles layer found.')
            return

        # Build pole index
        pidx = QgsSpatialIndex()
        ppts, plabels = {}, {}
        for pf in pole_layer.getFeatures():
            if pf.geometry() and not pf.geometry().isNull():
                pidx.addFeature(pf)
                ppts[pf.id()] = pf.geometry().asPoint()
                plabels[pf.id()] = pf['Label'] if 'Label' in pole_layer.fields().names() else str(pf.id())

        # Remove old Long Spans layer if present
        for lyr in list(proj.mapLayers().values()):
            if 'long span' in lyr.name().lower():
                proj.removeMapLayer(lyr.id())

        # Create result layer
        mem_lyr = QgsVectorLayer('LineString?crs=EPSG:4326', f'Long Spans (>{limit_m}m)', 'memory')
        pr = mem_lyr.dataProvider()
        pr.addAttributes([
            QgsField('span_m',  QVariant.Double),
            QgsField('pole_a',  QVariant.String),
            QgsField('pole_b',  QVariant.String),
            QgsField('cable',   QVariant.String),
            QgsField('layer',   QVariant.String),
        ])
        mem_lyr.updateFields()

        cable_layers = [self._find(['primary', 'cable']),
                        self._find(['secondary', 'cable']),
                        self._find(['distribution', 'cable'])]

        bad_fids = []
        feats_to_add = []
        for cable_lyr in cable_layers:
            if not cable_lyr:
                continue
            fn = cable_lyr.fields().names()
            name_field = 'name' if 'name' in fn else 'label' if 'label' in fn else None
            for feat in cable_lyr.getFeatures():
                g = feat.geometry()
                if not g or g.isNull():
                    continue
                bb = g.boundingBox()
                bb.grow(snap_deg)
                on_cable = []
                for pid in pidx.intersects(bb):
                    pt_g = QgsGeometry.fromPointXY(ppts[pid])
                    if 0 <= g.distance(pt_g) <= snap_deg:
                        on_cable.append((g.lineLocatePoint(pt_g), ppts[pid], plabels[pid]))
                if len(on_cable) < 2:
                    continue
                on_cable.sort(key=lambda x: x[0])
                fname = feat[name_field] if name_field else str(feat.id())
                for i in range(len(on_cable) - 1):
                    seg = QgsGeometry.fromPolylineXY([on_cable[i][1], on_cable[i+1][1]])
                    span_m = da.measureLength(seg)
                    if span_m > limit_m:
                        bad_fids.append((cable_lyr, feat.id()))
                        f = QgsFeature()
                        f.setGeometry(seg)
                        f.setAttributes([round(span_m, 1), str(on_cable[i][2]),
                                         str(on_cable[i+1][2]), str(fname), cable_lyr.name()])
                        feats_to_add.append(f)

        pr.addFeatures(feats_to_add)

        # Style: thick red line
        mem_lyr.renderer().symbol().setColor(Qt.red)
        mem_lyr.renderer().symbol().setWidth(1.0)
        proj.addMapLayer(mem_lyr)

        n = len(feats_to_add)
        if n == 0:
            self.iface.messageBar().pushMessage('Show Spans', 'No spans over 70 m found.', duration=4)
            return

        self.iface.messageBar().pushMessage('Show Spans', f'{n} span(s) over {limit_m}m — flashing on map', duration=5)

        # Flash the violations
        canvas = self.iface.mapCanvas()
        span_fids = [f.id() for f in mem_lyr.getFeatures()]

        def _do_flash():
            try:
                canvas.flashFeatureIds(mem_lyr, span_fids,
                                       startColor=Qt.red, endColor=Qt.transparent,
                                       flashes=3, duration=500)
            except Exception:
                canvas.flashFeatureIds(mem_lyr, span_fids)

        self._flash_timer = QTimer()
        self._flash_timer.setInterval(2000)
        self._flash_timer.timeout.connect(_do_flash)
        self._flash_timer.start()
        _do_flash()

    # ── CHECK PROJECT LAYERS ──────────────────────────────
    def run_check_layers(self):
        script = os.path.join(SCRIPTS_BASE, 'Home Connections Automation', 'check_project_layers.py')
        if not os.path.exists(script):
            QMessageBox.warning(None, 'Not found', f'Script not found:\n{script}')
            return
        try:
            with open(script, 'r') as f: code = f.read()
            exec(code, {'iface': self.iface, 'QgsProject': QgsProject})
        except Exception as e:
            QMessageBox.critical(None, 'Error', str(e))

    # ── SR AUTO-DETECT ────────────────────────────────────
    def _detect_sr_code(self):
        import re
        pattern = re.compile(r'^([A-Z]{2,5})\.')
        counts = {}
        # Fields likely to contain SR-prefixed codes
        check_fields = {'label', 'label_1', 'stackref', 'zone_no', 'pon_no', 'cmpref'}
        for lyr in QgsProject.instance().mapLayers().values():
            if not hasattr(lyr, 'fields'): continue
            lyr_fields = {f.name().lower() for f in lyr.fields()}
            scan = check_fields & lyr_fields
            if not scan: continue
            # Only sample up to 20 features per layer to keep it fast
            for i, feat in enumerate(lyr.getFeatures()):
                if i >= 20: break
                for fname in scan:
                    val = feat[fname]
                    if not val: continue
                    m = pattern.match(str(val).strip().upper())
                    if m:
                        sr = m.group(1)
                        counts[sr] = counts.get(sr, 0) + 1
        if not counts:
            return ''
        return max(counts, key=counts.get)

    # ── HOME CONNECTIONS ──────────────────────────────────
    def run_home_connections(self, SR=None):
        if SR is None:
            detected = self._detect_sr_code()
            dlg = HomeConnectionsDialog(self.iface.mainWindow(), detected_sr=detected)
            if not dlg.exec_() or not dlg.accepted_run:
                return
            SR = dlg.sr_code

        # Find layers
        layers = {l.name(): l for l in QgsProject.instance().mapLayers().values()}

        erven_lyr = self._find_layer(['erven'])
        hc_lyr    = self._find_layer(['home', 'connect'])
        zone_lyr  = self._find_layer(['zone'], exclude=['zones', 'erven'])

        # Collect existing HC points so we can skip erven that are already covered
        existing_hc_pts = []  # [(x, y), ...]
        if hc_lyr:
            for f in hc_lyr.getFeatures():
                g = f.geometry()
                if g and not g.isNull():
                    pt = g.asPoint()
                    existing_hc_pts.append((pt.x(), pt.y()))

        # Determine bounding box — prefer AOI layer, then erven, then any layer
        aoi_lyr  = self._find_aoi_layer()
        ref_lyr  = aoi_lyr or erven_lyr or zone_lyr or next(iter(layers.values()), None)
        if not ref_lyr:
            QMessageBox.critical(None, 'Error', 'No layers found in project.')
            return

        ext  = ref_lyr.extent()
        xmin, ymin = ext.xMinimum(), ext.yMinimum()
        xmax, ymax = ext.xMaximum(), ext.yMaximum()

        # Serialize AOI exterior ring for point-in-AOI filtering
        # Uses vertices() iterator — works for Polygon, MultiPolygon, PolygonZ, MultiPolygonZ
        aoi_poly = []
        if aoi_lyr:
            for feat in aoi_lyr.getFeatures():
                geom = feat.geometry()
                if not geom or geom.isNull(): continue
                try:
                    # Force to 2D single-ring representation via exterior ring of first part
                    abstract = geom.constGet()
                    # Navigate into multi/single geometry to get first exterior ring
                    part = abstract
                    if hasattr(abstract, 'numGeometries'):      # Multi*
                        part = abstract.geometryN(0)
                    if hasattr(part, 'exteriorRing'):           # Polygon / CurvePolygon
                        ring = part.exteriorRing()
                        aoi_poly = [(ring.xAt(i), ring.yAt(i))
                                    for i in range(ring.numPoints())]
                except Exception:
                    pass
                if aoi_poly:
                    break

        # ── STEP 1: Download Google Open Buildings ────────
        ov_path = os.path.join(OV_OUT_DIR, f'{SR.lower()}_overture_buildings.geojson')
        if os.path.exists(ov_path):
            self._push_message('Step 1/3 — Using cached buildings file…')
        else:
            self._push_message('Step 1/3 — Downloading Google Open Buildings...')
            QApplication.processEvents()
            try:
                result = subprocess.run([
                    OV_EXE, 'download',
                    f'--bbox={xmin},{ymin},{xmax},{ymax}',
                    '-f', 'geojson', '--type=building',
                    '-o', ov_path
                ], capture_output=True, text=True, timeout=120)
                if result.returncode != 0:
                    raise RuntimeError(result.stderr or f'overturemaps exited with code {result.returncode}')
                if not os.path.exists(ov_path):
                    raise RuntimeError(result.stderr or 'Download produced no output file')
            except subprocess.TimeoutExpired:
                QMessageBox.critical(None, 'Timeout', 'Google Buildings download timed out.')
                return
            except Exception as e:
                QMessageBox.critical(None, 'Download Error', str(e))
                return

        ov_lyr = QgsVectorLayer(ov_path, f'Overture Buildings — {SR}', 'ogr')
        if not ov_lyr.isValid():
            QMessageBox.critical(None, 'Error', f'Could not load {ov_path}')
            return

        # Clip raw buildings to AOI polygon — bbox download pulls in corners outside the AOI
        if aoi_lyr:
            try:
                import processing as _proc
                clip_res = _proc.run('native:clip', {
                    'INPUT':   ov_lyr,
                    'OVERLAY': aoi_lyr,
                    'OUTPUT':  'memory:'
                })
                clipped_ov = clip_res['OUTPUT']
                clipped_ov.setName(f'Overture Buildings — {SR}')
                ov_lyr = clipped_ov
            except Exception:
                pass  # if clip fails, use unclipped — better than crashing

        QgsProject.instance().addMapLayer(ov_lyr)

        # ── STEP 2: Serialize QGIS data → plain Python (main thread) ──────
        self._push_message('Step 2/3 — Preparing data...')
        QApplication.processEvents()

        if not erven_lyr:
            QMessageBox.critical(None, 'Error', 'No Erven layer found in project.')
            return

        # Erven data — case-insensitive field lookup
        erven_data = []
        erf_field_map = {f.name().lower(): f.name() for f in erven_lyr.fields()}
        easting_field  = erf_field_map.get('easting')
        northing_field = erf_field_map.get('northing')
        label_field_erf = erf_field_map.get('label') or erf_field_map.get('label_1')

        for feat in erven_lyr.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isNull(): continue
            bb = geom.boundingBox()
            c  = geom.centroid().asPoint()
            # Skip erven whose centroid falls outside the AOI
            if aoi_poly and not CentroidWorker._point_in_poly(c.x(), c.y(), aoi_poly):
                continue
            try:
                east = float(feat[easting_field]) if easting_field else None
            except Exception:
                east = None
            try:
                nrth = float(feat[northing_field]) if northing_field else None
            except Exception:
                nrth = None
            label = str(feat[label_field_erf]) if label_field_erf else str(feat.id())
            # Serialize polygon exterior ring — handles Polygon/MultiPolygon/Z variants
            poly_pts = []
            try:
                abstract = geom.constGet()
                part = abstract
                if hasattr(abstract, 'numGeometries'):
                    part = abstract.geometryN(0)
                if hasattr(part, 'exteriorRing'):
                    ring = part.exteriorRing()
                    poly_pts = [(ring.xAt(i), ring.yAt(i)) for i in range(ring.numPoints())]
            except Exception:
                poly_pts = []
            # Skip erven that already have an HC centroid inside them
            if poly_pts and existing_hc_pts:
                bb_cur = (bb.xMinimum(), bb.yMinimum(), bb.xMaximum(), bb.yMaximum())
                already_covered = any(
                    bb_cur[0] <= hx <= bb_cur[2] and bb_cur[1] <= hy <= bb_cur[3]
                    and CentroidWorker._point_in_poly(hx, hy, poly_pts)
                    for hx, hy in existing_hc_pts
                )
                if already_covered:
                    continue
            erven_data.append({
                'bbox':     (bb.xMinimum(), bb.yMinimum(), bb.xMaximum(), bb.yMaximum()),
                'centroid': (c.x(), c.y()),
                'label':    label,
                'easting':  east,
                'northing': nrth,
                'poly':     poly_pts,
            })

        # Buildings data — use top-level confidence field
        bldg_data = []
        for feat in ov_lyr.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isNull(): continue
            bb = geom.boundingBox()
            c  = geom.centroid().asPoint()
            conf = 0.5
            try:
                # Overture schema: top-level 'confidence' field
                raw = feat['confidence']
                if raw is not None:
                    conf = float(raw)
            except Exception:
                pass
            bldg_data.append({
                'bbox':     (bb.xMinimum(), bb.yMinimum(), bb.xMaximum(), bb.yMaximum()),
                'centroid': (c.x(), c.y()),
                'area':     geom.area(),   # planar area — largest value = biggest building
                'conf':     conf,
            })

        # ── VLM fallback: no Overture buildings → detect from NGI aerial ──────
        if not bldg_data and erven_data:
            answer = QMessageBox.question(
                self.iface.mainWindow(),
                'No Buildings Found',
                'No Overture/Google buildings were found in this area.\n\n'
                'Run AI aerial detection using NGI 25cm imagery?\n'
                '(Claude vision model scans the aerial photo in a 4×3 tile grid.)\n\n'
                'Takes ~1–3 minutes. Requires ANTHROPIC_API_KEY in environment.',
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.Yes
            )
            if answer == QMessageBox.Yes:
                self._push_message(
                    'No Overture buildings — running Claude VLM detection on NGI 25cm aerial...')
                QApplication.processEvents()
                bldg_data = self._detect_buildings_vlm(xmin, ymin, xmax, ymax)
                if bldg_data:
                    self._push_message(
                        f'VLM detected {len(bldg_data)} buildings — continuing with HC placement.',
                        'success')
                else:
                    self._push_message(
                        'VLM detection returned no buildings — using erf centroids as fallback.',
                        'warning')

        # HC label start number — resolved in main thread before worker starts (no race)
        hc_label_field = self._find_label_field(hc_lyr) if hc_lyr else None
        used_nums = set()
        if hc_lyr and hc_label_field:
            for feat in hc_lyr.getFeatures():
                lbl = feat[hc_label_field]
                if lbl and str(lbl).startswith(f'{SR}.HC.'):
                    try: used_nums.add(int(str(lbl).split('.')[-1]))
                    except Exception: pass
        hc_start_num = max(used_nums, default=0) + 1

        # ── STEP 3: Run centroid matching in background thread ──────────
        prog = QProgressDialog(
            f'Step 3/3 — Matching {len(erven_data)} erven to buildings...',
            'Cancel', 0, len(erven_data), self.iface.mainWindow()
        )
        prog.setWindowModality(Qt.WindowModal)
        prog.show()
        QApplication.processEvents()

        # Cancel button wires to worker
        self._centroid_worker = CentroidWorker(erven_data, bldg_data)
        prog.canceled.connect(self._centroid_worker.cancel)

        self._centroid_worker.progress.connect(
            lambda done, tot: (prog.setValue(done), QApplication.processEvents())
        )
        # Pass hc_start_num and aoi_poly as captured values (no race condition)
        self._centroid_worker.finished.connect(
            lambda results, google_n, erf_n, _start=hc_start_num, _aoi=aoi_poly: self._on_centroids_done(
                prog, SR, hc_lyr, hc_label_field, results, google_n, erf_n, _start, _aoi
            )
        )
        self._centroid_worker.start()

    def _find_label_field(self, lyr):
        """Return the first label-like field name on a layer, case-insensitive."""
        for f in lyr.fields():
            if f.name().lower() in ('label', 'label_1'):
                return f.name()
        return None

    # ── VLM BUILDING DETECTION (NGI 25cm + Claude vision) ────────────────────

    def _detect_buildings_vlm(self, xmin, ymin, xmax, ymax):
        """Detect building centroids from NGI 25cm aerial via Claude vision API.

        Called when Overture/Google returns no buildings for an area.
        Returns a list of {bbox, centroid, area, conf} dicts (same format as bldg_data).
        Requires ANTHROPIC_API_KEY in the environment (or will prompt once).
        """
        import base64, tempfile

        # ── Check anthropic is available ──────────────────────────────────────
        try:
            import anthropic
        except ImportError:
            QMessageBox.warning(
                None, 'VLM Detection — Package Missing',
                'The anthropic Python package is not installed.\n\n'
                'Install it with:\n'
                '  pip install anthropic\n\n'
                'in the QGIS Python environment (or .qgis-venv), then reload the plugin.')
            return []

        # ── API key ──────────────────────────────────────────────────────────
        api_key = os.environ.get('ANTHROPIC_API_KEY', '')
        if not api_key:
            from qgis.PyQt.QtWidgets import QInputDialog, QLineEdit
            api_key, ok = QInputDialog.getText(
                self.iface.mainWindow(), 'Anthropic API Key',
                'Enter your Anthropic API key\n(will not be saved):', QLineEdit.Password)
            if not ok or not api_key.strip():
                return []
        client = anthropic.Anthropic(api_key=api_key.strip())

        # ── Find or add NGI 25cm aerial layer ────────────────────────────────
        ngi_lyr = None
        for lyr in QgsProject.instance().mapLayers().values():
            n = lyr.name().lower()
            if 'ngi' in n or ('aerial' in n and 'overture' not in n):
                ngi_lyr = lyr
                break
        if ngi_lyr is None:
            uri = ('type=xyz&url=https://aerial.openstreetmap.org.za/'
                   'layer/ngi-aerial/%7Bz%7D/%7Bx%7D/%7By%7D.jpg&zmax=20&zmin=0')
            ngi_lyr = QgsRasterLayer(uri, 'NGI 25cm Aerial', 'wms')
            if ngi_lyr.isValid():
                QgsProject.instance().addMapLayer(ngi_lyr, False)
        if ngi_lyr is None or not ngi_lyr.isValid():
            QMessageBox.warning(
                None, 'VLM Detection', 'Could not load NGI 25cm aerial layer.')
            return []

        # ── Tile grid: 4 × 3 with 40 % overlap ───────────────────────────────
        COLS, ROWS, OVERLAP, IMG_PX = 4, 3, 0.40, 512
        w = xmax - xmin
        h = ymax - ymin
        step_w = w / (COLS - OVERLAP * (COLS - 1))
        step_h = h / (ROWS - OVERLAP * (ROWS - 1))
        tile_w  = step_w / (1.0 - OVERLAP)
        tile_h  = step_h / (1.0 - OVERLAP)

        tiles = []
        for row in range(ROWS):
            for col in range(COLS):
                tx = xmin + col * step_w
                ty = ymin + row * step_h
                tiles.append(QgsRectangle(tx, ty,
                                          min(tx + tile_w, xmax),
                                          min(ty + tile_h, ymax)))

        tmp_dir = tempfile.mkdtemp(prefix='vlm_bldg_')
        raw_pts = []   # (lon, lat, conf) before dedup

        prog = QProgressDialog(
            f'VLM Detection — tile 0/{len(tiles)}',
            'Cancel', 0, len(tiles), self.iface.mainWindow())
        prog.setWindowModality(Qt.WindowModal)
        prog.show()

        for ti, rect in enumerate(tiles):
            if prog.wasCanceled():
                break
            prog.setValue(ti)
            prog.setLabelText(f'VLM Detection — tile {ti + 1}/{len(tiles)} ...')
            QApplication.processEvents()

            # Render tile
            img = self._render_extent_to_image(ngi_lyr, rect, IMG_PX, IMG_PX)
            if img is None or img.isNull():
                continue
            img_path = os.path.join(tmp_dir, f'tile_{ti:02d}.jpg')
            img.save(img_path, 'JPEG', 90)

            # VLM call
            with open(img_path, 'rb') as fh:
                img_b64 = base64.b64encode(fh.read()).decode()
            pts = self._vlm_call_claude(client, img_b64, rect, IMG_PX)
            raw_pts.extend(pts)

        prog.close()

        if not raw_pts:
            return []

        # ── DBSCAN dedup (eps = 8 m) ─────────────────────────────────────────
        deduped = self._dbscan_dedup_pts(raw_pts, eps_m=8.0)

        # Convert to bldg_data format
        tiny = 1e-5
        return [
            {'bbox':     (lon - tiny, lat - tiny, lon + tiny, lat + tiny),
             'centroid': (lon, lat),
             'area':     50.0,
             'conf':     conf}
            for lon, lat, conf in deduped
        ]

    def _render_extent_to_image(self, layer, extent, width_px, height_px):
        """Render a single QGIS layer over an extent to a QImage."""
        from PyQt5.QtCore import QSize
        from PyQt5.QtGui import QColor

        settings = QgsMapSettings()
        settings.setLayers([layer])
        settings.setExtent(extent)
        settings.setOutputSize(QSize(width_px, height_px))
        settings.setBackgroundColor(QColor(255, 255, 255))
        settings.setFlag(QgsMapSettings.Antialiasing, True)

        job = QgsMapRendererParallelJob(settings)
        job.start()
        job.waitForFinished()
        return job.renderedImage()

    def _vlm_call_claude(self, client, img_b64, extent, img_px):
        """Send one tile to Claude vision and return [(lon, lat, conf), ...].

        Uses claude-haiku for speed; confidence calibrated from VLM output.
        Pixel (0,0) = top-left = geographic (xmin, ymax).
        """
        x0, y0 = extent.xMinimum(), extent.yMinimum()
        x1, y1 = extent.xMaximum(), extent.yMaximum()
        w = x1 - x0
        h = y1 - y0

        prompt = (
            'This is a 25 cm resolution aerial photo of a South African residential area.\n'
            f'Image size: {img_px}×{img_px} px. Pixel (0,0) = top-left.\n\n'
            'Identify every residential building (house, RDP house, informal dwelling/shack).\n'
            'For each, output the roof centre pixel as {"px": <col>, "py": <row>, "conf": <0-1>}.\n'
            'Reply ONLY with a JSON array — no explanation:\n'
            '[{"px": 120, "py": 80, "conf": 0.9}, ...]\n'
            'If no buildings are visible reply with: []'
        )
        try:
            resp = client.messages.create(
                model='claude-haiku-4-5-20251001',
                max_tokens=2048,
                messages=[{
                    'role': 'user',
                    'content': [
                        {'type': 'image',
                         'source': {'type': 'base64',
                                    'media_type': 'image/jpeg',
                                    'data': img_b64}},
                        {'type': 'text', 'text': prompt}
                    ]
                }],
            )
            text = resp.content[0].text.strip()
            m = re.search(r'\[.*?\]', text, re.DOTALL)
            if not m:
                return []
            pts = json.loads(m.group(0))
            results = []
            for p in pts:
                px = float(p.get('px', 0))
                py = float(p.get('py', 0))
                conf = float(p.get('conf', 0.5))
                lon = x0 + (px / img_px) * w
                lat = y1 - (py / img_px) * h   # py=0 → top → ymax
                results.append((lon, lat, conf))
            return results
        except Exception:
            return []

    def _dbscan_dedup_pts(self, points, eps_m=8.0):
        """Single-pass DBSCAN-style dedup of (lon, lat, conf) detections.

        Returns cluster centroids weighted by confidence.
        """
        eps = eps_m / 111320.0
        remaining = list(points)
        clusters = []
        while remaining:
            seed = remaining.pop(0)
            cluster = [seed]
            i = 0
            while i < len(remaining):
                p = remaining[i]
                if math.hypot(p[0] - seed[0], p[1] - seed[1]) < eps:
                    cluster.append(remaining.pop(i))
                else:
                    i += 1
            total_w = sum(c[2] for c in cluster) or 1.0
            lon_c = sum(c[0] * c[2] for c in cluster) / total_w
            lat_c = sum(c[1] * c[2] for c in cluster) / total_w
            conf_c = max(c[2] for c in cluster)
            clusters.append((lon_c, lat_c, conf_c))
        return clusters

    # ─────────────────────────────────────────────────────────────────────────

    def _on_centroids_done(self, prog, SR, hc_lyr, hc_label_field, results, google_n, erf_n, hc_start_num, aoi_poly=None):
        prog.close()

        # Clean up worker
        if self._centroid_worker:
            self._centroid_worker.deleteLater()
            self._centroid_worker = None

        # Cancelled
        if not results:
            self._push_message('Home Connections cancelled.', level='warning')
            return

        # Re-number from the reserved start
        numbered = []
        for i, (lon, lat, erf_lbl, _seq) in enumerate(results):
            numbered.append((lon, lat, erf_lbl, hc_start_num + i))

        if hc_lyr:
            self._write_to_hc_layer(hc_lyr, numbered, SR, hc_label_field)
        else:
            self._create_new_layer(numbered, SR, google_n, erf_n)

        # Delete all HC features (including pre-existing) outside the AOI
        out_lyr = hc_lyr or next(
            (l for l in QgsProject.instance().mapLayers().values()
             if f'Home Centroids — {SR}' == l.name()), None
        )
        purged = 0
        if aoi_poly and out_lyr:
            ids_outside = []
            for f in out_lyr.getFeatures():
                g = f.geometry()
                if not g or g.isNull(): continue
                pt = g.asPoint()
                if not CentroidWorker._point_in_poly(pt.x(), pt.y(), aoi_poly):
                    ids_outside.append(f.id())
            if ids_outside:
                out_lyr.startEditing()
                out_lyr.deleteFeatures(ids_outside)
                out_lyr.commitChanges()
                purged = len(ids_outside)

        self.iface.mapCanvas().refresh()
        total = len(numbered)
        purge_line = f'\nPurged outside AOI: {purged}' if purged else ''
        QMessageBox.information(None, '✅ Done',
            f'Home Connections complete!\n\n'
            f'Total added:      {total}\n'
            f'Google OB:        {google_n} ({google_n/max(total,1)*100:.1f}%)\n'
            f'Erf centroid:     {erf_n} ({erf_n/max(total,1)*100:.1f}%)'
            f'{purge_line}'
        )

    def _write_to_hc_layer(self, hc_lyr, results, SR, label_field):
        # results: [(lon, lat, erf_lbl, num), ...]
        fi = hc_lyr.fields().indexOf
        field_map = {f.name().lower(): f.name() for f in hc_lyr.fields()}
        def fidx(n):
            idx = fi(n)
            if idx != -1: return idx
            actual = field_map.get(n.lower())
            return fi(actual) if actual else -1

        hc_lyr.startEditing()
        new_feats = []
        for (lon, lat, erf_lbl, num) in results:
            f = QgsFeature(hc_lyr.fields())
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
            def sf(name, val, _f=f):
                idx = fidx(name)
                if idx != -1 and val is not None: _f.setAttribute(idx, val)
            sf(label_field or 'label', f'{SR}.HC.{num:05d}')
            sf('lat',      round(lat, 6))
            sf('lon',      round(lon, 7))
            sf('cmpownr',  'VelocityFibre')
            sf('stackref', SR)
            sf('crtdby',   QgsApplication.userFullName().strip() or os.getenv('USERNAME', 'VelocityFibre'))
            new_feats.append(f)
        hc_lyr.addFeatures(new_feats)
        hc_lyr.commitChanges()

    def _create_new_layer(self, results, SR, google_n, erf_n):
        # results: [(lon, lat, erf_lbl, num), ...]
        for l in list(QgsProject.instance().mapLayers().values()):
            if l.name() == f'Home Centroids — {SR}':
                QgsProject.instance().removeMapLayer(l.id())
        fields = QgsFields()
        for fn, ft in [('id', QVariant.Int), ('label', QVariant.String),
                       ('erf_label', QVariant.String),
                       ('lon', QVariant.Double), ('lat', QVariant.Double)]:
            fields.append(QgsField(fn, ft))
        out = QgsVectorLayer('Point?crs=EPSG:4326', f'Home Centroids — {SR}', 'memory')
        out.dataProvider().addAttributes(fields)
        out.updateFields()
        feats = []
        for i, (lon, lat, erf_lbl, num) in enumerate(results):
            f = QgsFeature(out.fields())
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
            f.setAttributes([i + 1, f'{SR}.HC.{num:05d}', erf_lbl,
                             round(lon, 7), round(lat, 6)])
            feats.append(f)
        out.dataProvider().addFeatures(feats)
        QgsProject.instance().addMapLayer(out)

    # ── CREATE ERVEN ──────────────────────────────────────────
    def run_create_erven(self):
        try:
            self._run_create_erven_impl()
        except Exception:
            import traceback
            QMessageBox.critical(None, 'Create Erven — Unexpected Error', traceback.format_exc())

    def _run_create_erven_impl(self, SR=None, offset_x=0.0, offset_y=0.0):
        if SR is None:
            detected = self._detect_sr_code()
            dlg = CreateErvenDialog(self.iface.mainWindow(), detected_sr=detected)
            dlg.raise_()
            dlg.activateWindow()
            if not dlg.exec_() or not dlg.accepted_run:
                return
            SR       = dlg.sr_code
            offset_x = dlg.offset_x
            offset_y = dlg.offset_y

        # ── Find AOI layer ────────────────────────────────────
        aoi_lyr = self._find_aoi_layer()
        if not aoi_lyr:
            QMessageBox.critical(None, 'No AOI found',
                'Could not find an AOI/boundary layer.\n\n'
                'Load a polygon layer named "Areas", "AOI", "Boundary", or "Zone".')
            return

        ext  = aoi_lyr.extent()
        xmin, ymin = ext.xMinimum(), ext.yMinimum()
        xmax, ymax = ext.xMaximum(), ext.yMaximum()

        # ── Step 1: SA Cadastral REST API ────────────────────
        prog = QProgressDialog(
            'Fetching cadastral data from DRDLR REST API…\n'
            '(this takes 15–30 seconds)',
            None, 0, 0, self.iface.mainWindow()
        )
        prog.setWindowTitle('Create Erven')
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumWidth(380)
        prog.show()
        QApplication.processEvents()

        try:
            raw_lyr, src_name = self._fetch_cadastral_rest(xmin, ymin, xmax, ymax)
        except Exception:
            import traceback
            prog.close()
            QMessageBox.critical(None, 'Fetch Error', traceback.format_exc())
            return
        prog.close()

        if raw_lyr:
            self._push_message(
                f'Clipping {raw_lyr.featureCount()} parcels to AOI ({src_name})...')
            QApplication.processEvents()
            try:
                erven_lyr = self._cadastral_to_erven(SR, raw_lyr, aoi_lyr)
                # Apply position offset correction if user specified one
                if offset_x != 0.0 or offset_y != 0.0:
                    import processing as _proc
                    shifted = _proc.run('native:translategeom', {
                        'INPUT':   erven_lyr,
                        'DELTA_X': offset_x,
                        'DELTA_Y': offset_y,
                        'OUTPUT':  'memory:'
                    })['OUTPUT']
                    shifted.setName(erven_lyr.name())
                    shifted.setCrs(erven_lyr.crs())
                    erven_lyr = shifted
                source_desc = (f'{src_name} '
                               f'({raw_lyr.featureCount()} raw → {erven_lyr.featureCount()} in AOI)')
            except Exception:
                import traceback
                QMessageBox.critical(None, 'Error clipping cadastral data', traceback.format_exc())
                return
        else:
            # ── Fallback chain: Overture → OSM → give up ──────
            bldg_features = []
            source_desc_fallback = ''

            # Fallback 1: Overture buildings
            self._push_message('DRDLR unavailable — trying Overture buildings...')
            QApplication.processEvents()
            bldg_path = os.path.join(OV_OUT_DIR, f'{SR.lower()}_overture_buildings.geojson')
            try:
                result = subprocess.run([
                    OV_EXE, 'download',
                    f'--bbox={xmin},{ymin},{xmax},{ymax}',
                    '-f', 'geojson', '--type=building',
                    '-o', bldg_path
                ], capture_output=True, text=True, timeout=180)
                if result.returncode != 0:
                    raise RuntimeError(result.stderr or f'overturemaps exited {result.returncode}')
                with open(bldg_path, 'r', encoding='utf-8') as fh:
                    bldg_features = json.load(fh).get('features', [])
                source_desc_fallback = 'Voronoi from Overture buildings (fallback)'
            except Exception:
                bldg_features = []

            # Fallback 2: OSM Overpass buildings
            if not bldg_features:
                self._push_message('Overture unavailable — trying OpenStreetMap buildings...')
                QApplication.processEvents()
                try:
                    bldg_features = self._fetch_osm_buildings(xmin, ymin, xmax, ymax)
                    source_desc_fallback = 'Voronoi from OSM buildings (fallback)'
                except Exception:
                    bldg_features = []

            if not bldg_features:
                QMessageBox.critical(None, 'No data',
                    'Could not fetch erven data from any source:\n'
                    '  • DRDLR CSG REST API — failed\n'
                    '  • Overture Maps buildings — failed\n'
                    '  • OpenStreetMap buildings — failed\n\n'
                    'Check your internet connection and try again.')
                return

            stand_points = self._deduplicate_buildings_to_centroids(bldg_features)
            if not stand_points:
                QMessageBox.warning(None, 'No data', 'No buildings found in this area.')
                return
            self._push_message(f'Building Voronoi for {len(stand_points)} stands...')
            QApplication.processEvents()
            try:
                erven_lyr = self._voronoi_erven(SR, stand_points, xmin, ymin, xmax, ymax)
                source_desc = source_desc_fallback
            except Exception:
                import traceback
                QMessageBox.critical(None, 'Error building Voronoi', traceback.format_exc())
                return

        # Gap-fill: find buildings outside any registered parcel and add as
        # approximate erfs so home connections can be placed on them too.
        self._push_message('Gap-filling unregistered buildings from OSM...')
        QApplication.processEvents()
        gap_count = 0
        try:
            erven_lyr, gap_count = self._gap_fill_erven(
                SR, erven_lyr, xmin, ymin, xmax, ymax, aoi_lyr)
        except Exception:
            pass  # gap-fill is best-effort; don't block on failure

        count = erven_lyr.featureCount()
        self._style_erven_layer(erven_lyr)
        QgsProject.instance().addMapLayer(erven_lyr)
        self.iface.setActiveLayer(erven_lyr)
        self.iface.zoomToActiveLayer()
        self.iface.mapCanvas().refresh()
        QMessageBox.information(None, '✅ Done',
            f'Created Erven layer: {erven_lyr.name()}\n\n'
            f'  Registered parcels:  {count - gap_count}\n'
            f'  Gap-filled (OSM):    {gap_count}\n'
            f'  Total:               {count}\n'
            f'  Source:              {source_desc}\n\n'
            f'Labels: {SR}.ERF.00001 → {SR}.ERF.{count:05d}'
        )

    @staticmethod
    def _style_erven_layer(lyr):
        """
        Apply cadastral styling.  Looks for erven_style.qml in the project
        folder first — allows visual tweaking without touching Python code.
        Falls back to the hardcoded double-stroke halo if no .qml found.
        """
        from qgis.core import QgsSimpleFillSymbolLayer

        # ── Try loading .qml from project folder ──────────────────────────
        qml_path = os.path.join(QgsProject.instance().homePath(), 'erven_style.qml')
        if os.path.exists(qml_path):
            msg, ok = lyr.loadNamedStyle(qml_path)
            if ok:
                lyr.triggerRepaint()
                return   # .qml applied — done

        # ── Fallback: solid black outline, no fill ────────────────────────────
        sym = QgsSimpleFillSymbolLayer()
        sym.setBrushStyle(0)                               # no fill
        sym.setStrokeColor(QColor(0, 0, 0, 255))          # solid black
        sym.setStrokeWidth(0.4)
        sym.setStrokeWidthUnit(QgsUnitTypes.RenderMillimeters)

        symbol = QgsFillSymbol()
        symbol.changeSymbolLayer(0, sym)

        lyr.setRenderer(QgsSingleSymbolRenderer(symbol))

        # Hide when zoomed out past 1:20000
        lyr.setScaleBasedVisibility(True)
        lyr.setMinimumScale(20000)
        lyr.setMaximumScale(0)

    def _gap_fill_erven(self, SR, erven_lyr, xmin, ymin, xmax, ymax, aoi_lyr):
        """
        Fetch OSM building footprints and add approximate erf polygons for any
        building whose centroid falls outside every registered DRDLR parcel.
        Returns (updated_erven_lyr, gap_count).
        """
        # Fetch OSM buildings
        bldg_features = self._fetch_osm_buildings(xmin, ymin, xmax, ymax)
        if not bldg_features:
            return erven_lyr, 0

        # Build spatial index over existing erven
        erven_index = QgsSpatialIndex(erven_lyr.getFeatures())
        erven_feats  = {f.id(): f for f in erven_lyr.getFeatures()}

        # AOI geometry for containment check
        aoi_geom = None
        if aoi_lyr:
            af = next(aoi_lyr.getFeatures(), None)
            if af:
                aoi_geom = af.geometry()

        fi       = erven_lyr.fields().indexOf
        erf_num  = erven_lyr.featureCount() + 1
        gap_feats = []

        for bldg in bldg_features:
            gd = bldg.get('geometry', {})
            if gd.get('type') != 'Polygon':
                continue
            coords = gd.get('coordinates', [])
            if not coords:
                continue
            ring = coords[0]
            if len(ring) < 3:
                continue

            pts      = [QgsPointXY(p[0], p[1]) for p in ring]
            bldg_geom = QgsGeometry.fromPolygonXY([pts])
            if not bldg_geom or bldg_geom.isNull():
                continue

            # Skip tiny slivers (< 15 m² — not a real building)
            bldg_m2 = bldg_geom.area() * 1.23e10
            if bldg_m2 < 15:
                continue

            centroid   = bldg_geom.centroid()
            centroid_pt = centroid.asPoint()

            # Skip if outside AOI
            if aoi_geom and not aoi_geom.contains(centroid):
                continue

            # Check if centroid already covered by a registered parcel
            covered = False
            for fid in erven_index.intersects(bldg_geom.boundingBox()):
                if erven_feats[fid].geometry().contains(centroid):
                    covered = True
                    break
            if covered:
                continue

            # Not covered — buffer building footprint by ~8 m as approximate erf
            buf_deg  = 8.0 / 110000
            erf_geom = bldg_geom.buffer(buf_deg, 4)

            # Clip back to AOI — prevents buffered buildings from spilling outside the zone
            if aoi_geom:
                erf_geom = erf_geom.intersection(aoi_geom)
                if not erf_geom or erf_geom.isNull():
                    continue

            f = QgsFeature(erven_lyr.fields())
            f.setGeometry(erf_geom)
            c = erf_geom.centroid().asPoint()

            lbl = f'{SR}.ERF.GAP.{erf_num:05d}'
            if fi('Label')    != -1: f.setAttribute(fi('Label'),    lbl)
            if fi('Easting')  != -1: f.setAttribute(fi('Easting'),  round(c.x(), 7))
            if fi('Northing') != -1: f.setAttribute(fi('Northing'), round(c.y(), 6))
            if fi('GEOM_AREA')!= -1: f.setAttribute(fi('GEOM_AREA'),
                                         round(erf_geom.area() * 1.23e10, 1))

            gap_feats.append(f)
            erf_num += 1

        if gap_feats:
            erven_lyr.dataProvider().addFeatures(gap_feats)
            erven_lyr.updateExtents()

        return erven_lyr, len(gap_feats)

    @staticmethod
    def _esri_to_geojson_geom(esri_geom, geom_type):
        """Convert Esri JSON geometry to GeoJSON geometry dict."""
        if not esri_geom:
            return None
        if geom_type == 'esriGeometryPolygon':
            rings = esri_geom.get('rings', [])
            if not rings:
                return None
            return {'type': 'Polygon', 'coordinates': rings}
        if geom_type == 'esriGeometryMultiPolygon':
            rings = esri_geom.get('rings', [])
            return {'type': 'MultiPolygon',
                    'coordinates': [[[r]] for r in rings]}
        return None

    def _fetch_cadastral_rest(self, xmin, ymin, xmax, ymax):
        """
        Fetch SA cadastral erf polygons from the DRDLR Surveyor-General REST API.
        Uses Esri JSON format (f=json) since f=geojson is unsupported by this service.
        Paginates with resultOffset; omits resultRecordCount (server default = 1000).
        Returns (QgsVectorLayer, source_name) or (None, '').
        """
        import urllib.request, urllib.parse, tempfile, ssl

        # DRDLR server has a certificate that Python's default SSL rejects —
        # disable verification so the connection succeeds.
        _ssl_ctx = ssl.create_default_context()
        _ssl_ctx.check_hostname = False
        _ssl_ctx.verify_mode    = ssl.CERT_NONE

        ENDPOINT = ('https://csggis.drdlr.gov.za/server/rest/services/'
                    'CSGSearch/MapServer/2/query')
        SRC_NAME  = 'DRDLR CSG'

        bbox_str = f'{xmin},{ymin},{xmax},{ymax}'
        BASE_PARAMS = {
            'where': "LSTATUS IN ('R','S')",   # Registered + Surveyed only; exclude cancelled
            'geometry': bbox_str,
            'geometryType': 'esriGeometryEnvelope',
            'inSR': '4326',
            'outSR': '32735',   # UTM Zone 35S — server does the transform (more accurate than
                                # reprojecting from 3857 on the client side)
            'spatialRel': 'esriSpatialRelIntersects',
            'outFields': 'PRCL_KEY,LSTATUS,WSTATUS,GEOM_AREA,TAG_VALUE,TAG_X,TAG_Y,ID,PROVINCE,SS_NAME,FARM_NAME',
            'f': 'json',
        }

        all_geojson_features = []
        offset = 0
        max_pages = 10  # safety cap — 10 × 1000 = 10 000 parcels max
        data = {}  # ensure defined even if loop body never executes

        for _ in range(max_pages):
            params = dict(BASE_PARAMS)
            params['resultOffset'] = str(offset)
            url = ENDPOINT + '?' + urllib.parse.urlencode(params)
            try:
                req = urllib.request.Request(
                    url, headers={'User-Agent': 'QGIS/3 FibretimeTools'})
                with urllib.request.urlopen(req, timeout=30, context=_ssl_ctx) as resp:
                    data = json.loads(resp.read().decode('utf-8'))
            except Exception:
                break

            esri_feats = data.get('features', [])
            geom_type  = data.get('geometryType', 'esriGeometryPolygon')

            for ef in esri_feats:
                geom = self._esri_to_geojson_geom(ef.get('geometry'), geom_type)
                if geom is None:
                    continue
                all_geojson_features.append({
                    'type': 'Feature',
                    'geometry': geom,
                    'properties': ef.get('attributes', {}),
                })

            if not data.get('exceededTransferLimit'):
                break  # last page
            offset += len(esri_feats)

        if not all_geojson_features:
            return None, ''

        # Determine CRS from last response spatial reference
        sref = data.get('spatialReference', {})
        native_wkid = sref.get('latestWkid') or sref.get('wkid') or 4148
        native_crs = QgsCoordinateReferenceSystem(f'EPSG:{native_wkid}')
        if not native_crs.isValid():
            native_crs = QgsCoordinateReferenceSystem('EPSG:4148')

        fc = {'type': 'FeatureCollection', 'features': all_geojson_features}
        tmp = tempfile.NamedTemporaryFile(
            suffix='.geojson', delete=False, mode='w', encoding='utf-8')
        json.dump(fc, tmp)
        tmp.close()

        lyr = QgsVectorLayer(tmp.name, 'cadastral_rest_tmp', 'ogr')
        try:
            if lyr.isValid() and lyr.featureCount() > 0:
                lyr.setCrs(native_crs)
                # Reproject to EPSG:4326 so all downstream processing uses consistent degree coordinates
                if native_crs.authid() != 'EPSG:4326':
                    import processing as _proc
                    reproj = _proc.run('native:reprojectlayer', {
                        'INPUT':      lyr,
                        'TARGET_CRS': 'EPSG:4326',
                        'OUTPUT':     'memory:'
                    })
                    lyr = reproj['OUTPUT']
                return lyr, SRC_NAME
        finally:
            # Clean up temp file — QGIS has already read the data into memory
            try:
                os.unlink(tmp.name)
            except Exception:
                pass

        return None, ''

    def _find_aoi_layer(self):
        """Find the AOI/boundary polygon layer by name heuristic."""
        AOI_NAMES = {'areas', 'aoi', 'boundary', 'zone', 'extent', 'perimeter', 'area'}
        layers = list(QgsProject.instance().mapLayers().values())
        # Exact/contains match on lowercased name, polygon geometry only
        for lyr in layers:
            if not hasattr(lyr, 'geometryType') or lyr.geometryType() != 2:
                continue
            name_low = lyr.name().lower()
            # Strip the long Fibertime prefix (everything after ' — ')
            short = name_low.split(' \u2014 ')[-1].strip()
            if any(short == n or short.startswith(n) for n in AOI_NAMES):
                return lyr
        # Fallback: polygon layers with exactly 1 feature (AOI is always a single polygon)
        # Exclude layers that are clearly infrastructure/cadastral data by keyword
        EXCLUDE_WORDS = {'erf', 'erven', 'enclosure', 'connectoris', 'splice',
                         'cable', 'span', 'ont', 'home', 'connection', 'drop',
                         'splitter', 'pon', 'pop', 'poles', 'building', 'overture'}
        single_feat = [
            l for l in layers
            if hasattr(l, 'geometryType') and l.geometryType() == 2
            and l.featureCount() == 1
            and not any(w in l.name().lower() for w in EXCLUDE_WORDS)
        ]
        if single_feat:
            return single_feat[0]
        # Do NOT fall back to the smallest polygon layer — too likely to be wrong
        return None

    def _cadastral_to_erven(self, SR, wfs_lyr, aoi_lyr):
        """
        Clip WFS cadastral parcels to AOI and produce a labelled Erven polygon layer.
        Preserves original cadastral fields + adds Label, lat, lon, GEOM_AREA.
        """
        import processing

        # Fix any invalid geometries before clipping
        fix_result = processing.run('native:fixgeometries', {
            'INPUT':  wfs_lyr,
            'OUTPUT': 'memory:'
        })
        fixed_lyr = fix_result['OUTPUT']

        # Clip to AOI
        clip_result = processing.run('native:clip', {
            'INPUT':   fixed_lyr,
            'OVERLAY': aoi_lyr,
            'OUTPUT':  'memory:'
        })
        clipped = clip_result['OUTPUT']

        # Snap clipped parcel edges to the AOI boundary (1 feature — fast).
        # Cleans jagged edges where clip cut through parcels at the AOI border.
        try:
            snap_result = processing.run('native:snapgeometries', {
                'INPUT':           clipped,
                'REFERENCE_LAYER': aoi_lyr,
                'TOLERANCE':       0.00001,  # ≈1 m in EPSG:4326 — tight snap at AOI edge only
                'BEHAVIOR':        1,     # prefer nodes
                'OUTPUT':          'memory:'
            })
            clipped = snap_result['OUTPUT']
        except Exception:
            pass  # fall back to unsnapped on failure

        # Detect which field to use as the erf label
        # Prefer: TAG_VALUE (erf number from CSG REST) > Label > PRCL_KEY > ID
        field_names = {f.name().lower(): f.name() for f in clipped.fields()}
        label_src = (field_names.get('tag_value') or field_names.get('label')
                     or field_names.get('prcl_key') or field_names.get('id') or None)

        S = QVariant.String; D = QVariant.Double
        out_fields = QgsFields()
        # Copy all original fields from the WFS layer
        for f in clipped.fields():
            out_fields.append(f)
        # Add Fibertime standard fields if not already present
        extra = []
        for fname, ftype in [('Label', S), ('Easting', D), ('Northing', D), ('GEOM_AREA', D)]:
            if fname.lower() not in field_names:
                out_fields.append(QgsField(fname, ftype))
                extra.append(fname)

        out_lyr = QgsVectorLayer('Polygon?crs=EPSG:4326', f'Erven — {SR}', 'memory')
        out_lyr.dataProvider().addAttributes(out_fields)
        out_lyr.updateFields()

        # Check whether TAG_X/TAG_Y (official SG centroid) are available
        has_tag_xy = 'tag_x' in field_names and 'tag_y' in field_names

        # GEOM_AREA from DRDLR is in native UTM 35S units (m²) — use it to filter
        # non-residential parcels (parks, schools, road reserves, open spaces).
        # Residential township erfs: ~300–1000 m². Threshold is generous to keep
        # large corner plots, double plots, smallholdings within the project area.
        MAX_PARCEL_M2 = 5000
        _geom_area_fld = field_names.get('geom_area')

        out_feats = []
        fi = out_lyr.fields().indexOf
        for i, feat in enumerate(clipped.getFeatures()):
            geom = feat.geometry()
            if not geom or geom.isNull():
                continue
            c = geom.centroid().asPoint()
            area_m2 = geom.area() * 1.23e10  # approx m² at 26°S

            # Skip clearly non-residential parcels
            parcel_m2 = area_m2
            if _geom_area_fld:
                try:
                    parcel_m2 = float(feat[_geom_area_fld])
                except Exception:
                    pass
            if parcel_m2 > MAX_PARCEL_M2:
                continue

            # Skip extremely elongated parcels (road reserves, utility strips)
            # Compactness = (4π × area) / perimeter² — circle=1, thin strip→0
            perim_m = geom.length() * 110000
            if perim_m > 0:
                compactness = (4 * math.pi * area_m2) / (perim_m ** 2)
                if compactness < 0.04:
                    continue

            # Prefer official SG centroid (TAG_X/TAG_Y) for Easting/Northing
            try:
                easting  = float(feat[field_names['tag_x']]) if has_tag_xy else c.x()
                northing = float(feat[field_names['tag_y']]) if has_tag_xy else c.y()
                if easting == 0 or northing == 0:
                    easting, northing = c.x(), c.y()
            except Exception:
                easting, northing = c.x(), c.y()

            f = QgsFeature(out_lyr.fields())
            f.setGeometry(geom)
            # Copy original attributes
            for fld in clipped.fields():
                idx = fi(fld.name())
                if idx != -1:
                    f.setAttribute(idx, feat[fld.name()])

            # Build label: prefer erf number from TAG_VALUE, else sequential
            if label_src and str(feat[label_src]) not in ('NULL', 'None', ''):
                raw = str(feat[label_src])
                lbl = f'{SR}.ERF.{raw}' if not raw.startswith(SR) else raw
            else:
                lbl = f'{SR}.ERF.{i+1:05d}'

            for fname in extra:
                idx = fi(fname)
                if idx == -1: continue
                if fname == 'Label':      f.setAttribute(idx, lbl)
                elif fname == 'Easting':  f.setAttribute(idx, round(easting, 7))
                elif fname == 'Northing': f.setAttribute(idx, round(northing, 6))
                elif fname == 'GEOM_AREA':f.setAttribute(idx, round(area_m2, 1))
            # Overwrite Label even if it existed — use our formatted version
            if 'Label' not in extra and fi('Label') != -1:
                f.setAttribute(fi('Label'), lbl)

            out_feats.append(f)

        # Deduplicate: keep one polygon per ERF label (the one containing the
        # centroid of all its polygons merged). Removes duplicate records that
        # the DRDLR API sometimes returns for the same stand number.
        out_feats = self._deduplicate_erven_features(out_feats, out_lyr.fields())

        out_lyr.dataProvider().addFeatures(out_feats)
        out_lyr.updateExtents()

        # Auto-label the layer using the Label field
        from qgis.core import QgsPalLayerSettings, QgsVectorLayerSimpleLabeling
        pal = QgsPalLayerSettings()
        pal.fieldName = 'Label'
        pal.enabled = True
        out_lyr.setLabeling(QgsVectorLayerSimpleLabeling(pal))
        out_lyr.setLabelsEnabled(False)  # off by default — user can toggle on

        return out_lyr

    @staticmethod
    def _deduplicate_erven_features(feats, fields):
        """
        Given a list of QgsFeatures from _cadastral_to_erven, return one feature
        per unique Label value.  When multiple polygons share the same label (same
        ERF number from DRDLR), merge all their geometries, compute the centroid of
        the merged shape, and keep only the polygon that contains that centroid.
        If no single polygon contains it (e.g. centroid falls in a gap), keep the
        largest polygon instead.  Single-polygon erfs pass through unchanged.
        """
        from collections import defaultdict

        lbl_idx = fields.indexOf('Label')
        if lbl_idx == -1:
            return feats  # no Label field — nothing to deduplicate

        groups = defaultdict(list)
        for f in feats:
            lbl = f.attribute(lbl_idx)
            groups[str(lbl) if lbl not in (None, '') else f'__nolabel_{id(f)}'].append(f)

        result = []
        for lbl, group in groups.items():
            if len(group) == 1:
                result.append(group[0])
                continue

            # Merge all polygons for this erf to find the true centroid
            merged = QgsGeometry.unaryUnion([f.geometry() for f in group if not f.geometry().isNull()])
            if merged and not merged.isNull():
                centroid_geom = merged.centroid()
                if centroid_geom and not centroid_geom.isNull():
                    # Keep the polygon that contains the merged centroid
                    for f in group:
                        if f.geometry().contains(centroid_geom):
                            result.append(f)
                            break
                    else:
                        # Centroid in a gap between polygons — keep largest
                        result.append(max(group, key=lambda f: f.geometry().area()))
                    continue

            # Fallback: keep largest polygon
            result.append(max(group, key=lambda f: f.geometry().area()))

        return result

    def _fetch_osm_buildings(self, xmin, ymin, xmax, ymax):
        """
        Fetch building footprints from OpenStreetMap via Overpass API.
        Returns a list of GeoJSON-style feature dicts compatible with
        _deduplicate_buildings_to_centroids.
        """
        import urllib.request, urllib.parse

        # Overpass QL — fetch all ways and relations tagged building=*
        query = (
            f'[out:json][timeout:60][bbox:{ymin},{xmin},{ymax},{xmax}];'
            f'(way["building"];relation["building"];);'
            f'out geom;'
        )
        url = 'https://overpass-api.de/api/interpreter'
        data = urllib.parse.urlencode({'data': query}).encode('utf-8')
        req = urllib.request.Request(
            url, data=data,
            headers={'User-Agent': 'QGIS/3 FibretimeTools',
                     'Content-Type': 'application/x-www-form-urlencoded'})
        with urllib.request.urlopen(req, timeout=60) as resp:
            result = json.loads(resp.read().decode('utf-8'))

        features = []
        for el in result.get('elements', []):
            geom_nodes = el.get('geometry', [])
            if not geom_nodes:
                # relation — collect from members
                geom_nodes = []
                for member in el.get('members', []):
                    geom_nodes.extend(member.get('geometry', []))
            if len(geom_nodes) < 3:
                continue
            # OSM geometry: [{lat, lon}, ...] → GeoJSON [lon, lat]
            ring = [[n['lon'], n['lat']] for n in geom_nodes]
            if ring[0] != ring[-1]:
                ring.append(ring[0])  # close the ring
            features.append({
                'type': 'Feature',
                'geometry': {'type': 'Polygon', 'coordinates': [ring]},
                'properties': el.get('tags', {})
            })
        return features

    def _deduplicate_buildings_to_centroids(self, bldg_features):
        """
        Return list of (lon, lat, area_deg2) — one entry per ~20m grid cell,
        keeping the largest building footprint in each cell.
        """
        CELL = 0.0002  # ~20 m
        seen = {}
        for feat in bldg_features:
            geom_d = feat.get('geometry')
            if not geom_d:
                continue
            coords_all = []
            def _collect(obj, _acc=coords_all):
                t = obj.get('type', '')
                c = obj.get('coordinates', [])
                if t == 'Point':
                    _acc.append(c)
                elif t in ('LineString', 'MultiPoint'):
                    _acc.extend(c)
                elif t in ('Polygon', 'MultiLineString'):
                    for ring in c: _acc.extend(ring)
                elif t == 'MultiPolygon':
                    for poly in c:
                        for ring in poly: _acc.extend(ring)
            _collect(geom_d)
            if not coords_all:
                continue
            xs = [p[0] for p in coords_all]
            ys = [p[1] for p in coords_all]
            cx = sum(xs) / len(xs)
            cy = sum(ys) / len(ys)
            area = (max(xs) - min(xs)) * (max(ys) - min(ys))
            cell = (math.floor(cx / CELL), math.floor(cy / CELL))
            if cell not in seen or area > seen[cell][2]:
                seen[cell] = (cx, cy, area)
        return list(seen.values())

    def _voronoi_erven(self, SR, stand_points, xmin, ymin, xmax, ymax):
        """
        Build a Polygon Erven layer using QGIS Voronoi algorithm.
        stand_points: [(lon, lat, area), ...]
        Returns a labeled memory layer.
        """
        import processing
        from qgis.core import QgsRectangle

        # Build input points layer
        pt_lyr = QgsVectorLayer('Point?crs=EPSG:4326', '_erven_pts_tmp', 'memory')
        pt_fields = QgsFields()
        pt_fields.append(QgsField('area', QVariant.Double))
        pt_lyr.dataProvider().addAttributes(pt_fields)
        pt_lyr.updateFields()
        pt_feats = []
        for lon, lat, area in stand_points:
            f = QgsFeature(pt_lyr.fields())
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
            f.setAttribute(0, area)
            pt_feats.append(f)
        pt_lyr.dataProvider().addFeatures(pt_feats)
        pt_lyr.updateExtents()

        # Voronoi with 5% buffer so edge cells aren't clipped too tightly
        voronoi_result = processing.run('qgis:voronoipolygons', {
            'INPUT':  pt_lyr,
            'BUFFER': 5,
            'OUTPUT': 'memory:'
        })
        voronoi_lyr = voronoi_result['OUTPUT']

        # Build clip mask as a temporary layer with one feature
        clip_geom = QgsGeometry.fromRect(QgsRectangle(xmin, ymin, xmax, ymax))
        mask_lyr = QgsVectorLayer('Polygon?crs=EPSG:4326', '_clip_mask', 'memory')
        mask_lyr.dataProvider().addFeatures([
            (lambda f: (f.setGeometry(clip_geom), f)[1])(QgsFeature())
        ])

        clip_result = processing.run('native:clip', {
            'INPUT':   voronoi_lyr,
            'OVERLAY': mask_lyr,
            'OUTPUT':  'memory:'
        })
        clipped_lyr = clip_result['OUTPUT']

        # Build output layer with Fibertime erf attribute schema
        S = QVariant.String; D = QVariant.Double
        out_fields = QgsFields()
        for fname, ftype in [
            ('Label',    S), ('lat',      D), ('lon',      D),
            ('Easting',  D), ('Northing', D), ('GEOM_AREA', D),
            ('stackref', S), ('crtdby',   S),
        ]:
            out_fields.append(QgsField(fname, ftype))

        out_lyr = QgsVectorLayer('Polygon?crs=EPSG:4326', f'Erven — {SR}', 'memory')
        out_lyr.dataProvider().addAttributes(out_fields)
        out_lyr.updateFields()

        out_feats = []
        for i, feat in enumerate(clipped_lyr.getFeatures()):
            geom = feat.geometry()
            if not geom or geom.isNull():
                continue
            c = geom.centroid().asPoint()
            lon, lat = c.x(), c.y()
            # area in m² (approximate: 1 deg² ≈ 1.23e10 m² at 26°S)
            area_m2 = geom.area() * 1.23e10
            f = QgsFeature(out_lyr.fields())
            f.setGeometry(geom)
            f.setAttributes([
                f'{SR}.ERF.{i+1:05d}',
                round(lat, 6), round(lon, 7),
                round(lon, 7), round(lat, 6),
                round(area_m2, 1),
                SR, QgsApplication.userFullName().strip() or os.getenv('USERNAME', 'VelocityFibre'),
            ])
            out_feats.append(f)

        out_lyr.dataProvider().addFeatures(out_feats)
        out_lyr.updateExtents()
        return out_lyr

    # ── LAYER STYLING ─────────────────────────────────────────
    @staticmethod
    def _apply_layer_style(lyr):
        """Apply QML style to a layer by matching its base name.
        Looks in the plugin's styles/ folder for e.g. 'poles.qml' for 'poles v1'."""
        styles_dir = os.path.join(
            os.path.dirname(__file__), 'styles')
        # Try exact name first, then strip ' v1' suffix
        candidates = [lyr.name(), lyr.name().replace(' v1', '')]
        for candidate in candidates:
            qml = os.path.join(styles_dir, f'{candidate}.qml')
            if os.path.exists(qml):
                lyr.loadNamedStyle(qml)
                lyr.triggerRepaint()
                return

    # ── SETUP PROJECT ─────────────────────────────────────────
    def run_setup_project(self):
        detected_sr     = self._detect_sr_code()
        detected_folder = QgsProject.instance().homePath() or ''
        dlg = SetupProjectDialog(self.iface.mainWindow(),
                                 detected_sr=detected_sr,
                                 detected_folder=detected_folder)
        if not dlg.exec_() or not dlg.accepted_run:
            return

        SR = dlg.sr_code
        errors = []

        # Persist project metadata in QGIS project variables so Label All
        # can read them later without requiring another dialog
        _vars = QgsProject.instance().customVariables()
        _vars['ft_sr']       = SR
        _vars['ft_mun']      = dlg.mun or ''
        _vars['ft_subplace'] = dlg.subplace or ''
        QgsProject.instance().setCustomVariables(_vars)

        # Step 1: Create layers
        if dlg.do_layers:
            self._push_message('Setting up layers…')
            QApplication.processEvents()
            try:
                client = dlg.client
                if client == 'VUMA':
                    created    = self._build_vuma_layers(SR, dlg.mun, dlg.subplace, dlg.folder_path)
                    group_name = f'Vuma — {SR}'
                else:
                    created    = self._build_fibertime_layers(SR, dlg.mun, dlg.subplace, dlg.folder_path)
                    group_name = f'Fibertime — {SR}'
                root  = QgsProject.instance().layerTreeRoot()
                group = root.insertGroup(0, group_name)
                for lyr_name, shp_path in created:
                    lyr = QgsVectorLayer(shp_path, lyr_name, 'ogr')
                    if lyr.isValid():
                        if client == 'VUMA':
                            self._apply_vuma_style(lyr)
                        else:
                            self._apply_layer_style(lyr)
                        QgsProject.instance().addMapLayer(lyr, False)
                        group.addLayer(lyr)
                self._push_message(f'Layers created: {len(created)}')
            except Exception as e:
                errors.append(f'Create layers: {e}')

        # Step 2: Fetch erven
        if dlg.do_erven:
            self._push_message('Fetching erf boundaries…')
            QApplication.processEvents()
            try:
                self._run_create_erven_impl(SR=SR, offset_x=dlg.offset_x, offset_y=dlg.offset_y)
            except Exception as e:
                errors.append(f'Fetch erven: {e}')

        # Step 3: Place home connections
        if dlg.do_hc:
            self._push_message('Placing home connections…')
            QApplication.processEvents()
            try:
                self.run_home_connections(SR=SR)
            except Exception as e:
                errors.append(f'Home connections: {e}')

        # Always add Google basemaps at the bottom
        self._add_basemaps()

        if errors:
            QMessageBox.warning(None, 'Setup completed with errors',
                '\n'.join(errors))

    # ── CREATE LAYERS ─────────────────────────────────────────
    def run_create_layers(self):
        detected_sr     = self._detect_sr_code()
        detected_folder = QgsProject.instance().homePath() or ''
        dlg = CreateLayersDialog(self.iface.mainWindow(),
                                 detected_sr=detected_sr,
                                 detected_folder=detected_folder)
        if not dlg.exec_() or not dlg.accepted_run:
            return
        SR     = dlg.sr_code
        MUN    = dlg.mun or 'Unknown Municipality'
        SUB    = dlg.subplace or ''
        FOLDER = dlg.folder_path

        try:
            created = self._build_fibertime_layers(SR, MUN, SUB, FOLDER)
        except Exception:
            import traceback
            QMessageBox.critical(None, 'Error creating layers', traceback.format_exc())
            return

        # Load all layers into QGIS under a named group
        root  = QgsProject.instance().layerTreeRoot()
        group = root.insertGroup(0, f'Fibertime — {SR}')

        for lyr_name, shp_path in created:
            lyr = QgsVectorLayer(shp_path, lyr_name, 'ogr')
            if lyr.isValid():
                self._apply_layer_style(lyr)
                QgsProject.instance().addMapLayer(lyr, False)
                group.addLayer(lyr)

        self.iface.mapCanvas().refresh()
        QMessageBox.information(None, '✅ Done',
            f'Created {len(created)} shapefiles in:\n{FOLDER}\n\n'
            + '\n'.join(f'  • {n}' for n, _ in created)
        )

    # ── BASEMAPS ──────────────────────────────────────────────
    @staticmethod
    def _add_basemaps():
        """Add Google Satellite and Google Hybrid XYZ basemaps at the bottom of the layer tree.
        Skips any basemap that is already present in the project."""
        from qgis.core import QgsRasterLayer

        BASEMAPS = [
            ('Google Hybrid',
             'type=xyz'
             '&url=https://mt1.google.com/vt/lyrs%3Dy%26x%3D%7Bx%7D%26y%3D%7By%7D%26z%3D%7Bz%7D'
             '&zmax=19&zmin=0'),
            ('Google Satellite',
             'type=xyz'
             '&url=https://mt1.google.com/vt/lyrs%3Ds%26x%3D%7Bx%7D%26y%3D%7By%7D%26z%3D%7Bz%7D'
             '&zmax=19&zmin=0'),
        ]

        root     = QgsProject.instance().layerTreeRoot()
        existing = {l.name() for l in QgsProject.instance().mapLayers().values()}

        for name, uri in BASEMAPS:
            if name in existing:
                continue
            lyr = QgsRasterLayer(uri, name, 'wms')
            if lyr.isValid():
                QgsProject.instance().addMapLayer(lyr, False)
                root.addLayer(lyr)   # addLayer appends at the end = bottom of panel

    # ── VUMA STYLE ────────────────────────────────────────────
    @staticmethod
    def _apply_vuma_style(lyr):
        """Apply exact Malmsbury Vuma styles extracted from the live project."""
        from qgis.core import (
            QgsSingleSymbolRenderer,
            QgsFillSymbol, QgsLineSymbol, QgsMarkerSymbol,
        )

        name_lc = lyr.name().lower()
        geom    = lyr.geometryType()   # 0=Point, 1=Line, 2=Polygon
        sym     = None

        if geom == 0:   # ── Points ────────────────────────────
            # (fill_rgba, outline_hex, outline_width, size)
            # Ordered most-specific first to avoid false substring matches.
            POINT_STYLES = [
                ('aggregation joint',   '0,180,0,60',     '#008000', '0.6', '5.0'),
                ('feeder joints',       '0,255,36,255',   '#232323', '0',   '6.1'),
                ('link joints',         '35,35,240,255',  '#232323', '0',   '5.5'),
                ('spur joints',         '255,26,243,255', '#232323', '0',   '3.8'),
                ('dome joint',          '255,0,0,255',    '#232323', '0',   '3.8'),
                ('4 way splitters',     '255,0,0,255',    '#000000', '0.5', '2.6'),
                ('demand points',        '222,33,175,180', '#b40000', '0.15','1.5'),
                ('node',                '255,0,0,255',    '#8b0000', '0.4', '3.0'),
                ('poles',               '255,242,0,255',  '#232323', '0',   '1.4'),
            ]
            for key, color, outline, ow, size in POINT_STYLES:
                if key in name_lc:
                    sym = QgsMarkerSymbol.createSimple({
                        'name': 'circle', 'color': color,
                        'outline_color': outline, 'outline_width': ow, 'size': size,
                    })
                    break

        elif geom == 1:   # ── Lines ─────────────────────────────
            # (key, color_hex, width)
            LINE_STYLES = [
                ('road crossing underground', '#c8a214', '2.1'),
                ('distribution cable',        '#d30000', '0.46'),
                ('link cable',                '#2323d5', '0.86'),
                ('spur cable',                '#f831de', '0.66'),
                ('feeder',                    '#00ff24', '0.66'),
                ('drops',                     '#30ecdd', '0.26'),
                ('core',                      '#ff00ff', '0.8'),
            ]
            for key, color, width in LINE_STYLES:
                if key in name_lc:
                    sym = QgsLineSymbol.createSimple({'color': color, 'width': width})
                    break

        elif geom == 2:   # ── Polygons ─────────────────────────
            # (key, fill_rgba, outline_hex, outline_width, outline_style)
            POLY_STYLES = [
                ('aggregation polygon', '255,178,35,60',  '#000000', '0.9',  'solid'),
                ('block',               '37,171,0,60',    '#000000', '0.86', 'solid'),
                ('p2 aoi',              '0,0,0,0',        '#000000', '0.8',  'dash dot'),
                ('buildings',           '0,200,200,100',  '#007878', '0.15', 'solid'),
                ('erven',               '0,0,0,0',        '#000000', '0.4',  'solid'),
            ]
            for key, fill, outline, ow, ostyle in POLY_STYLES:
                if key in name_lc:
                    sym = QgsFillSymbol.createSimple({
                        'color': fill, 'outline_color': outline,
                        'outline_width': ow, 'outline_style': ostyle,
                    })
                    break

        if sym:
            lyr.setRenderer(QgsSingleSymbolRenderer(sym))
            lyr.triggerRepaint()

    # ── VUMA LAYERS ───────────────────────────────────────────
    def _build_vuma_layers(self, SR, MUN, SUB, folder_path):
        """Create Vuma layer shapefiles with exact field schemas from Malmsbury V1.1."""
        S  = QVariant.String
        D  = QVariant.Double
        I  = QVariant.Int
        L  = QVariant.LongLong   # Integer64
        crs = QgsCoordinateReferenceSystem('EPSG:4326')
        ctx = QgsProject.instance().transformContext()

        DEFS = [
            # ── Point layers ──────────────────────────────────
            ('poles', QgsWkbTypes.Point, [
                ('id', L), ('Name', L), ('Pole Size', S),
                ('X', D), ('AG', S), ('Block', S), ('Type', S), ('NameLabel', S), ('Y', D),
            ]),
            ('4 Way splitters', QgsWkbTypes.Point, [
                ('id', L), ('1-4 Split', S), ('AG', S), ('Block', S),
            ]),
            ('Dome Joint', QgsWkbTypes.Point, [
                ('id', L), ('Name', S), ('Block', S), ('AG', S),
                ('x', D), ('y', D), ('Descriptio', S),
            ]),
            ('Spur Joints', QgsWkbTypes.Point, [
                ('id', L), ('Name', S), ('Block', S), ('AG', S),
                ('x', D), ('y', D), ('Descriptio', S),
            ]),
            ('Feeder Joints', QgsWkbTypes.Point, [
                ('Label', S), ('Splitters', S), ('Descriptio', S),
            ]),
            ('Link Joints', QgsWkbTypes.Point, [
                ('id', L), ('Descriptio', S), ('Label', S),
            ]),
            ('Demand points', QgsWkbTypes.Point, [
                ('Name', S), ('Block', S), ('Allowed Pr', S), ('Inst Type', S),
                ('Geo Str Nu', S), ('Geocode', S), ('Dist Joint', S),
                ('Geo Suburb', S), ('Geo Erf Nu', S), ('Geolocatio', S),
                ('Geo Latitu', D), ('Geo Longit', D), ('Geo Postal', L),
                ('Geo Munici', S), ('Geo Provin', S), ('Geo Countr', S),
                ('Status', S), ('Type', S),
            ]),
            ('Node', QgsWkbTypes.Point, [
                ('id', L),
            ]),
            ('Aggregation Joint', QgsWkbTypes.Point, [
                ('id', L),
            ]),
            # ── Line layers ───────────────────────────────────
            ('feeder', QgsWkbTypes.LineString, [
                ('Feeder Cab', S), ('To From fr', S),
                ('T_Length',   D), ('S_Length',   D),
                ('Cable Size', S), ('Descriptio', S), ('Name', S),
            ]),
            ('Link Cable', QgsWkbTypes.LineString, [
                ('T_Length', D), ('S_Length', D), ('Cable Size', S),
                ('To from fr', S), ('Name', S), ('Feeder Cab', S), ('Descriptio', S),
            ]),
            ('Distribution Cable', QgsWkbTypes.LineString, [
                ('T_Length', D), ('S_Length', D), ('Cable Size', S),
                ('Feeder Cab', S), ('To from fr', S), ('Descriptio', S), ('Name', S),
            ]),
            ('Spur Cable', QgsWkbTypes.LineString, [
                ('T_Length', D), ('S_Length', D), ('Cable Size', S),
                ('Descriptio', S), ('Name', S), ('AG', S), ('Spur Cab', S),
            ]),
            ('drops', QgsWkbTypes.LineString, [
                ('id', L), ('Length', D), ('Block', S), ('AG', S),
            ]),
            ('Road Crossing Underground', QgsWkbTypes.LineString, [
                ('id', L), ('Length', L), ('up & down', L),
            ]),
            ('core', QgsWkbTypes.LineString, [
                ('id', L), ('Length', D),
            ]),
            # ── Polygon layers ────────────────────────────────
            ('Aggregation Polygon', QgsWkbTypes.Polygon, [
                ('Descriptio', S), ('Label', S),
            ]),
            ('Block', QgsWkbTypes.Polygon, [
                ('Label', S), ('Descriptio', S),
            ]),
            ('P2 AOI Poly', QgsWkbTypes.Polygon, [
                ('id', S), ('Name', S), ('Descriptio', S),
            ]),
            ('Malmesbury Buildings', QgsWkbTypes.Polygon, [
                ('id', S), ('Name', S), ('Descriptio', S),
            ]),
        ]

        created = []
        for lyr_name, wkb_type, field_defs in DEFS:
            file_name = f'{lyr_name}.shp'
            shp_path  = os.path.join(folder_path, file_name)

            fields = QgsFields()
            for fname, ftype in field_defs:
                fields.append(QgsField(fname, ftype))

            opts = QgsVectorFileWriter.SaveVectorOptions()
            opts.driverName = 'ESRI Shapefile'
            opts.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile

            writer = QgsVectorFileWriter.create(shp_path, fields, wkb_type, crs, ctx, opts)
            if writer.hasError() != QgsVectorFileWriter.NoError:
                raise RuntimeError(f'Failed to create "{file_name}": {writer.errorMessage()}')
            del writer

            created.append((lyr_name, shp_path))

        return created

    def _build_fibertime_layers(self, SR, MUN, SUB, folder_path):
        S = QVariant.String; D = QVariant.Double; I = QVariant.Int
        crs = QgsCoordinateReferenceSystem('EPSG:4326')
        ctx = QgsProject.instance().transformContext()

        # Common admin fields shared by most layers
        ADMIN = [
            ('cmpownr',  S), ('subplace', S), ('mainplce', S),
            ('mun',      S), ('stackref', S), ('crtdby',   S),
        ]
        # Common spatial ref fields
        LOC   = [('lat', D), ('lon', D), ('pon_no', S), ('zone_no', S)]
        # Cable routing fields
        ROUTE = [('strtfeat', S), ('endfeat', S)]

        # ── Layer definitions ─────────────────────────────────
        # (layer_name, WkbType, [(field_name, QVariant_type), ...])
        # layer_name is used as both the QGIS display name and the shapefile
        # base name (file will be saved as "[layer_name] v1.shp").
        DEFS = [
            # ── Point layers ──────────────────────────────────
            ('poles', QgsWkbTypes.Point, [
                ('Label', S), ('lat', D), ('lon', D),
                ('Pole Type', S), ('type_1', S), ('subtype_1', S),
                ('spec_1', S), ('dim1', S), ('dim2', S),
                ('spec_4', S), ('dim1_4', S),
                ('companyown', S), ('status', S),
                ('mainplace', S), ('municipal', S),
                ('stack', S), ('createdby', S),
                ('subplace', S), ('pon_no', S), ('zone_no', S),
            ]),
            ('FTS Splitters', QgsWkbTypes.Point,
                [('label', S)] + LOC +
                [('type', S), ('subtyp', S), ('spec', S),
                 ('dim1', S), ('dim2', S), ('cblcpty', S)] + ADMIN),
            ('STS Splitters', QgsWkbTypes.Point,
                [('label', S)] + LOC +
                [('type', S), ('subtyp', S), ('spec', S),
                 ('dim1', S), ('dim2', S), ('cblcpty', S), ('conntr', S)] + ADMIN),
            ('Enclosure', QgsWkbTypes.Point,
                [('label', S), ('label_1', S)] + LOC +
                [('type', S), ('subtyp', S), ('spec', S),
                 ('type_1', S), ('subtyp_1', S), ('spec_1', S),
                 ('dim1', S), ('cblcpty', S), ('cblcpty1', S),
                 ('conntr', S), ('conntr1', S)] + ADMIN),
            ('Enclosures Connectorised', QgsWkbTypes.Point,
                [('label', S), ('label_1', S)] + LOC +
                [('type', S), ('subtyp', S), ('spec', S),
                 ('dim1', S), ('cblcpty', S), ('conntr', S)] + ADMIN),
            ('Enclosures Splice', QgsWkbTypes.Point,
                [('label_1', S)] + LOC +
                [('type_1', S), ('subtyp_1', S), ('spec_1', S),
                 ('dim1', S), ('cblcpty1', S), ('conntr1', S)] + ADMIN),
            ('Home Connection', QgsWkbTypes.Point, [
                ('label_1', S), ('uuid', S), ('info', I),
                ('lat', D), ('lon', D), ('pon_no', S), ('zone_no', S),
                ('type_1', S), ('subtyp_1', S), ('spec_1', S),
                ('dim1', S), ('dim2', S), ('cblcpty1', S), ('conntr1', S),
                ('status', S), ('pswrd', S), ('olt_add', S),
                ('apctmpnm', S), ('apc_arg', S), ('srvc_nme', S),
                ('oltrx', S), ('ontrx', S),
                ('type_2', S), ('subtyp_2', S), ('spec_2', S), ('dim1_2', S),
            ] + ADMIN),
            ('ONT', QgsWkbTypes.Point, [
                ('label_1', S), ('uuid', S),
                ('lat', D), ('lon', D), ('pon_no', S), ('zone_no', S),
                ('type_1', S), ('subtyp_1', S), ('spec_1', S),
                ('dim1', S), ('dim2', S), ('cblcpty1', S), ('conntr1', S),
                ('olt_add', S), ('apctmpnm', S), ('apc_arg', S),
                ('srvc_nme', S), ('oltrx', S), ('ontrx', S),
            ] + ADMIN),
            # ── Line layers ───────────────────────────────────
            ('Primary Cable', QgsWkbTypes.LineString,
                [('label', S)] + ROUTE +
                [('type', S), ('subtyp', S), ('spec', S),
                 ('dim1', S), ('dim2', S), ('cblcpty', S), ('ntwrkptn', S),
                 ('pon_no', S), ('zone_no', S)] + ADMIN),
            ('Secondary Cable', QgsWkbTypes.LineString,
                [('label', S)] + ROUTE +
                [('type', S), ('subtyp', S), ('spec', S),
                 ('dim1', S), ('dim2', S), ('cblcpty', S), ('ntwrkptn', S),
                 ('pon_no', S), ('zone_no', S)] + ADMIN),
            ('Distribution Cable', QgsWkbTypes.LineString,
                [('label', S)] + ROUTE +
                [('type', S), ('subtyp', S), ('spec', S),
                 ('dim1', S), ('dim2', S), ('cblcpty', S), ('ntwrkptn', S),
                 ('pon_no', S), ('zone_no', S)] + ADMIN),
            ('Drop Cable', QgsWkbTypes.LineString,
                [('label', S), ('uuid', S)] + ROUTE +
                [('type', S), ('subtyp', S), ('spec', S),
                 ('dim1', S), ('dim2', S), ('cblcpty', S),
                 ('conntr', S), ('ntwrkptn', S),
                 ('pon_no', S), ('zone_no', S)] + ADMIN),
            ('Spare Drop Cable', QgsWkbTypes.LineString,
                [('label', S), ('uuid', S)] + ROUTE +
                [('type', S), ('subtyp', S), ('spec', S),
                 ('dim1', S), ('dim2', S), ('cblcpty', S),
                 ('conntr', S), ('ntwrkptn', S),
                 ('pon_no', S), ('zone_no', S)] + ADMIN),
            ('Span', QgsWkbTypes.LineString,
                [('label', S)] + ROUTE +
                [('type', S), ('subtyp', S), ('spec', S),
                 ('dim1', S), ('cblcpty', S), ('ntwrkptn', S),
                 ('pon_no', S), ('zone_no', S)] + ADMIN),
            # ── Polygon layers ────────────────────────────────
            ('PON Boundaries', QgsWkbTypes.Polygon, [
                ('pon_no',    I), ('zone_no',   I),
                ('label',     S), ('name',      S),
                ('units',     I), ('sdu',       I), ('sdu_count', I),
                ('stackref',  S), ('crtdby',    S), ('datecrtd',  S),
            ]),
            ('Zone Boundaries', QgsWkbTypes.Polygon, [
                ('zone_no',   I),
                ('label',     S), ('name',      S),
                ('pon_count', I),
                ('stackref',  S), ('crtdby',    S), ('datecrtd',  S),
            ]),
            ('POP', QgsWkbTypes.Polygon, [
                ('label',     S), ('name',      S), ('status',    S),
                ('lat',       D), ('lon',       D),
                ('mun',       S), ('subplace',  S),
                ('stackref',  S), ('crtdby',    S), ('datecrtd',  S),
            ]),
        ]

        created = []
        for lyr_name, wkb_type, field_defs in DEFS:
            file_name = f'{lyr_name}.shp'
            shp_path  = os.path.join(folder_path, file_name)

            fields = QgsFields()
            for fname, ftype in field_defs:
                fields.append(QgsField(fname, ftype))

            opts = QgsVectorFileWriter.SaveVectorOptions()
            opts.driverName = 'ESRI Shapefile'
            opts.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile

            writer = QgsVectorFileWriter.create(shp_path, fields, wkb_type, crs, ctx, opts)
            if writer.hasError() != QgsVectorFileWriter.NoError:
                raise RuntimeError(f'Failed to create "{file_name}": {writer.errorMessage()}')
            del writer  # flush & close

            created.append((lyr_name, shp_path))

        return created

    # ── PLAN BLOCK ────────────────────────────────────────────
    def run_plan_block(self):
        detected = self._detect_sr_code()
        dlg = PlanBlockDialog(self.iface.mainWindow(), detected_sr=detected)
        if not dlg.exec_() or not dlg.accepted_run:
            return
        self._plan_block_params = {
            'sr':            dlg.sr_code,
            'search_radius': dlg.search_radius,
            'max_per_side':  dlg.max_per_side,
        }
        tool = PlanBlockMapTool(self.iface.mapCanvas(), self._on_plan_block_line_drawn)
        self.iface.mapCanvas().setMapTool(tool)
        self._push_message('Draw midblock line — single-click vertices, double-click to finish. Esc to cancel.', 'info')

    def _on_plan_block_line_drawn(self, line_geom):
        p = self._plan_block_params
        self._process_plan_block(line_geom, p['sr'], p['search_radius'], p['max_per_side'])

    def _distance_along_line(self, line_geom, point_geom):
        """Return (dist_along_line, perp_dist) in map units for the nearest point on line."""
        verts = line_geom.asMultiPolyline()[0] if line_geom.isMultipart() else line_geom.asPolyline()
        pt    = point_geom.asPoint()
        min_perp    = float('inf')
        best_along  = 0.0
        running     = 0.0
        for i in range(len(verts) - 1):
            ax, ay = verts[i].x(),   verts[i].y()
            bx, by = verts[i+1].x(), verts[i+1].y()
            dx, dy = bx - ax, by - ay
            seg_len = math.sqrt(dx*dx + dy*dy)
            if seg_len == 0:
                continue
            t  = max(0.0, min(1.0, ((pt.x()-ax)*dx + (pt.y()-ay)*dy) / (seg_len*seg_len)))
            nx = ax + t*dx
            ny = ay + t*dy
            perp = math.sqrt((pt.x()-nx)**2 + (pt.y()-ny)**2)
            if perp < min_perp:
                min_perp   = perp
                best_along = running + t * seg_len
            running += seg_len
        return best_along, min_perp

    def _side_of_line(self, line_geom, point_geom):
        """Return 'left' or 'right' relative to the line direction."""
        verts = line_geom.asMultiPolyline()[0] if line_geom.isMultipart() else line_geom.asPolyline()
        pt    = point_geom.asPoint()
        min_perp   = float('inf')
        best_cross = 0.0
        for i in range(len(verts) - 1):
            ax, ay = verts[i].x(),   verts[i].y()
            bx, by = verts[i+1].x(), verts[i+1].y()
            dx, dy = bx - ax, by - ay
            seg_len = math.sqrt(dx*dx + dy*dy)
            if seg_len == 0:
                continue
            t    = max(0.0, min(1.0, ((pt.x()-ax)*dx + (pt.y()-ay)*dy) / (seg_len*seg_len)))
            perp = math.sqrt((pt.x()-(ax+t*dx))**2 + (pt.y()-(ay+t*dy))**2)
            if perp < min_perp:
                min_perp   = perp
                best_cross = (bx-ax)*(pt.y()-ay) - (by-ay)*(pt.x()-ax)
        return 'left' if best_cross > 0 else 'right'

    def _group_hcs_to_poles(self, hc_data, max_per_side):
        """
        Sort ALL HCs by position along line, then take consecutive chunks of
        (max_per_side * 2). Returns list of dicts: {hcs} — the pole position
        is computed in _process_plan_block by projecting the group centroid
        onto the midblock line (star-pattern pole placement).
        """
        sorted_hcs = sorted(hc_data, key=lambda x: x['dist_along'])
        chunk_size = max_per_side * 2
        groups = []
        for i in range(0, len(sorted_hcs), chunk_size):
            batch = sorted_hcs[i:i + chunk_size]
            groups.append({'hcs': [h['hc'] for h in batch]})
        return groups

    @staticmethod
    def _find_layer(keywords, exclude=None):
        """Find a loaded layer whose name contains ALL keywords (case-insensitive).
        Prefers: v1 layers first, then shortest name (avoids group sub-layers)."""
        candidates = []
        for lyr in QgsProject.instance().mapLayers().values():
            n = lyr.name().lower()
            if all(k.lower() in n for k in keywords):
                if exclude and any(e.lower() in n for e in exclude):
                    continue
                candidates.append(lyr)
        if not candidates:
            return None
        # Prefer exact Fibertime v1 layers (with suffix), then shortest name (new projects)
        candidates.sort(key=lambda l: (0 if l.name().lower().endswith(' v1') else 1, len(l.name())))
        return candidates[0]

    def _ensure_roads_loaded(self, SR):
        """Download (once per SR) and index road segments for drop-crossing checks.
        Results are cached on self._road_index / self._road_geoms — subsequent
        Plan Block calls in the same session reuse the in-memory index instantly."""
        if self._road_sr == SR and self._road_index is not None:
            return  # already loaded for this SR

        self._road_index = None
        self._road_geoms = {}
        self._road_sr    = SR

        _ROAD_CLASSES = {
            'motorway', 'trunk', 'primary', 'secondary', 'tertiary',
            'residential', 'unclassified', 'living_street', 'unknown',
            'track', 'path', 'service',   # include rural dirt tracks
        }

        # Prefer a roads layer already loaded in the project
        roads_lyr = self._find_layer(['road']) or self._find_layer(['street'])

        if not roads_lyr:
            # File is keyed by SR so the download only ever happens once per project
            road_cache = os.path.join(OV_OUT_DIR, f'roads_{SR}.geojson')
            if not os.path.exists(road_cache):
                # Determine download bbox from AOI (whole project area)
                aoi_lyr = self._find_aoi_layer()
                if aoi_lyr:
                    bb = aoi_lyr.extent()
                else:
                    bb = QgsRectangle()
                    for lyr in QgsProject.instance().mapLayers().values():
                        if hasattr(lyr, 'extent') and hasattr(lyr, 'featureCount') and lyr.featureCount() > 0:
                            try:
                                bb.combineExtentWith(lyr.extent())
                            except Exception:
                                pass
                if bb.isNull() or bb.isEmpty():
                    return  # no extent available — skip roads
                pad = 200.0 / 99000.0
                xmin_r = round(bb.xMinimum() - pad, 4)
                ymin_r = round(bb.yMinimum() - pad, 4)
                xmax_r = round(bb.xMaximum() + pad, 4)
                ymax_r = round(bb.yMaximum() + pad, 4)
                self._push_message(f'Downloading roads for {SR} AOI (one-time)…', 'info')
                QApplication.processEvents()
                try:
                    res = subprocess.run([
                        OV_EXE, 'download',
                        f'--bbox={xmin_r},{ymin_r},{xmax_r},{ymax_r}',
                        '-f', 'geojson', '--type=segment',
                        '-o', road_cache
                    ], capture_output=True, text=True, timeout=120)
                    if res.returncode != 0 or not os.path.exists(road_cache):
                        raise RuntimeError(res.stderr or 'no output')
                except Exception:
                    return  # roads unavailable — crossing check will be skipped silently

            if os.path.exists(road_cache):
                roads_lyr = QgsVectorLayer(road_cache, '_roads_tmp', 'ogr')
                if not roads_lyr.isValid():
                    roads_lyr = None

        if not roads_lyr:
            return

        # Build in-memory index — filter to real carriageways only
        fields = [f.name() for f in roads_lyr.fields()]
        road_geoms = {}
        for f in roads_lyr.getFeatures():
            g = f.geometry()
            if not g or g.isNull():
                continue
            if 'class' in fields:
                rc = str(f['class']).lower()
                if rc not in _ROAD_CLASSES:
                    continue
            road_geoms[f.id()] = g

        if not road_geoms:
            return

        road_index = QgsSpatialIndex()
        for fid, g in road_geoms.items():
            e = QgsFeature()
            e.setId(fid)
            e.setGeometry(g)
            road_index.addFeature(e)

        self._road_index = road_index
        self._road_geoms = road_geoms

    def _point_in_road(self, pt):
        """Return True if pt (QgsPointXY) falls within ~4 m of any road centreline."""
        if self._road_index is None or not self._road_geoms:
            return False
        buf_deg = 0.00004  # ~4 m at South Africa latitudes
        pt_buf  = QgsGeometry.fromPointXY(pt).buffer(buf_deg, 8)
        for fid in self._road_index.intersects(pt_buf.boundingBox()):
            rg = self._road_geoms.get(fid)
            if rg and not rg.isNull() and pt_buf.intersects(rg):
                return True
        return False

    def _process_plan_block(self, line_geom, SR, search_radius_m, max_per_side):
        hc_layer    = self._find_layer(['home', 'connect'])
        poles_layer = self._find_layer(['pole'])
        sts_layer   = self._find_layer(['sts'])  or self._find_layer(['splitter'], exclude=['fts'])
        dist_layer  = self._find_layer(['distribution', 'cable'])
        drop_layer  = self._find_layer(['drop', 'cable'], exclude=['spare'])

        missing = [n for n, l in [
            ('Home Connection (any layer with "home" + "connect")', hc_layer),
            ('Poles (any layer with "pole")',                        poles_layer),
            ('STS Splitters (any layer with "sts")',                 sts_layer),
            ('Distribution Cable (any layer with "distribution" + "cable")', dist_layer),
            ('Drop Cable (any layer with "drop" + "cable")',         drop_layer),
        ] if not l]
        if missing:
            QMessageBox.warning(None, 'Missing layers',
                'Cannot find required layers. Make sure you have created '
                'Fibertime layers first (🏗️ Create Fibertime Layers).\n\n'
                'Missing:\n' + '\n'.join(f'  • {m}' for m in missing))
            return

        # ── Roads: load once per SR, cache on instance ───────────────────
        self._ensure_roads_loaded(SR)
        road_index = self._road_index
        road_geoms = self._road_geoms

        # ── Bend vertices: snap poles onto sharp corners ──────────────────
        # At any vertex where the line changes direction by >= 60°, place the
        # pole exactly on the vertex rather than interpolating between groups.
        # This means a 90° corner needs no extra manual pole — it gets one free.
        _BEND_MIN_DEG  = 60.0   # capture ≥60° bends (catches ~90° corners)
        _BEND_SNAP_M   = 35.0   # snap pole here if computed pos is within 35 m
        _BEND_SNAP_DEG = _BEND_SNAP_M / 99000.0

        _verts = (line_geom.asMultiPolyline()[0] if line_geom.isMultipart()
                  else line_geom.asPolyline())
        bend_verts = []  # list of QgsPointXY at sharp bends
        for _i in range(1, len(_verts) - 1):
            _ax, _ay = _verts[_i-1].x(), _verts[_i-1].y()
            _bx, _by = _verts[_i  ].x(), _verts[_i  ].y()
            _cx, _cy = _verts[_i+1].x(), _verts[_i+1].y()
            _v1x, _v1y = _bx - _ax, _by - _ay   # incoming segment direction
            _v2x, _v2y = _cx - _bx, _cy - _by   # outgoing segment direction
            _m1 = math.sqrt(_v1x**2 + _v1y**2)
            _m2 = math.sqrt(_v2x**2 + _v2y**2)
            if _m1 == 0 or _m2 == 0:
                continue
            _cos = (_v1x*_v2x + _v1y*_v2y) / (_m1 * _m2)
            _cos = max(-1.0, min(1.0, _cos))
            _bend_deg = math.degrees(math.acos(_cos))  # 0°=straight, 90°=right angle
            if _bend_deg >= _BEND_MIN_DEG:
                bend_verts.append(QgsPointXY(_bx, _by))

        # Search radius: degrees (approx for South Africa ~26°S)
        search_deg  = search_radius_m / 99000.0
        line_buffer = line_geom.buffer(search_deg, 8)

        # ── Erven-block constraint ────────────────────────────────
        # Use a tight buffer (15 m) to find erven whose polygon boundary
        # intersects directly with the midblock line. These are the erven
        # that back onto this specific block. We then build their union and
        # use it as a strict spatial fence — only HCs inside those erven
        # are eligible, so drops from adjacent blocks (across the street)
        # are never included.
        block_geom = None
        erven_lyr  = self._find_layer(['erven'])
        if erven_lyr:
            tight_buf  = line_geom.buffer(15.0 / 99000.0, 8)
            erv_index  = QgsSpatialIndex(erven_lyr.getFeatures())
            erv_feats  = {f.id(): f for f in erven_lyr.getFeatures()}
            for fid in erv_index.intersects(tight_buf.boundingBox()):
                erf_geom = erv_feats[fid].geometry()
                if erf_geom and tight_buf.intersects(erf_geom):
                    block_geom = block_geom.combine(erf_geom) if block_geom else erf_geom

        # Build a set of HC positions that already have a drop cable (first vertex = HC end)
        # Skip those HCs so we don't double-up drops on already-served homes
        snap_deg = 2.0 / 99000.0  # ~2 m tolerance
        served_pts = set()
        for drop_f in drop_layer.getFeatures():
            dg = drop_f.geometry()
            if not dg or dg.isNull():
                continue
            # Handle both single and multi-linestring geometry
            if dg.isMultipart():
                lines = dg.asMultiPolyline()
                verts = lines[0] if lines else []
            else:
                verts = dg.asPolyline()
            if verts:
                p = verts[0]
                # quantise to ~2 m grid so floating-point noise doesn't break the match
                served_pts.add((round(p.x() / snap_deg), round(p.y() / snap_deg)))

        # Find HCs near line, then filter to block erven only
        hc_index = QgsSpatialIndex(hc_layer.getFeatures())
        hc_feats = {f.id(): f for f in hc_layer.getFeatures()}
        hcs_near = []
        for fid in hc_index.intersects(line_buffer.boundingBox()):
            feat = hc_feats[fid]
            g    = feat.geometry()
            if not g or g.isNull():
                continue
            if not line_buffer.contains(g):
                continue
            # If erven data available, constrain to this block only
            if block_geom and not block_geom.contains(g):
                continue
            # Skip HCs that already have a drop cable
            pt = g.asPoint()
            key = (round(pt.x() / snap_deg), round(pt.y() / snap_deg))
            if key in served_pts:
                continue
            hcs_near.append(feat)

        if not hcs_near:
            QMessageBox.warning(None, 'No home connections found',
                f'No home connections found within {search_radius_m} m of the drawn line.\n'
                'Try increasing the search radius.')
            return

        # Classify each HC: distance along line (for ordering)
        hc_data = []
        for hc in hcs_near:
            dist_along, _ = self._distance_along_line(line_geom, hc.geometry())
            hc_data.append({'hc': hc, 'dist_along': dist_along})

        groups = self._group_hcs_to_poles(hc_data, max_per_side)
        if not groups:
            QMessageBox.warning(None, 'Grouping failed',
                'Could not group home connections into pole assignments.')
            return

        import datetime as _dt
        today = _dt.date.today().isoformat()

        def _sa(feat, fname, val):
            """Set attribute only if the field exists in this layer."""
            idx = feat.fields().indexOf(fname)
            if idx != -1:
                feat.setAttribute(idx, val)

        # Dynamic username — reads from QGIS profile, falls back to OS login
        creator = (QgsApplication.userFullName().strip()
                   or os.getenv('USERNAME', '')
                   or os.getenv('USER', '')
                   or 'VelocityFibre')

        new_poles  = []
        new_sts    = []
        new_drops  = []
        road_skip_count = 0

        for grp in groups:
            # Centroid of HC cluster → project onto midblock line
            hc_pts = [h.geometry().asPoint() for h in grp['hcs'] if h.geometry() and not h.geometry().isNull()]
            if not hc_pts:
                continue
            cx = sum(p.x() for p in hc_pts) / len(hc_pts)
            cy = sum(p.y() for p in hc_pts) / len(hc_pts)
            centroid_geom = QgsGeometry.fromPointXY(QgsPointXY(cx, cy))
            pole_pt = line_geom.nearestPoint(centroid_geom)
            if not pole_pt or pole_pt.isNull():
                continue
            pt = pole_pt.asPoint()

            # Snap to bend vertex if one is within _BEND_SNAP_M metres
            for _bv in bend_verts:
                _dx_m = (_bv.x() - pt.x()) * 99000.0
                _dy_m = (_bv.y() - pt.y()) * 99000.0
                if math.sqrt(_dx_m**2 + _dy_m**2) <= _BEND_SNAP_M:
                    pt      = _bv
                    pole_pt = QgsGeometry.fromPointXY(_bv)
                    break

            # ── Road check: skip poles that land in a road ───────
            if self._point_in_road(pt):
                road_skip_count += 1
                continue

            # ── Pole ─────────────────────────────────────────────
            pole_feat = QgsFeature(poles_layer.fields())
            pole_feat.setGeometry(pole_pt)
            _sa(pole_feat, 'Pole Type',   'Distribution')
            _sa(pole_feat, 'type_1',      'Pole')
            _sa(pole_feat, 'subtype_1',   'Creosote')
            _sa(pole_feat, 'spec_1',      'H4SANS754')
            _sa(pole_feat, 'dim1',        '7m')
            _sa(pole_feat, 'dim2',        '120-140mm')
            _sa(pole_feat, 'spec_4',      '2Way')
            _sa(pole_feat, 'dim1_4',      '(R19*W12,50mm)*2')
            _sa(pole_feat, 'companyown',  'VelocityFibre')
            _sa(pole_feat, 'cmpownr',     'VelocityFibre')
            _sa(pole_feat, 'stack',       SR)
            _sa(pole_feat, 'stackref',    SR)
            _sa(pole_feat, 'createdby',   creator)
            _sa(pole_feat, 'crtdby',      creator)
            _sa(pole_feat, 'datecrtd',    today)
            _sa(pole_feat, 'lat',         round(pt.y(), 10))
            _sa(pole_feat, 'lon',         round(pt.x(), 10))
            new_poles.append(pole_feat)

            # ── STS Splitter (at same position as pole) ──────────
            sts_feat = QgsFeature(sts_layer.fields())
            sts_feat.setGeometry(QgsGeometry(pole_pt))
            _sa(sts_feat, 'type',       'Splitter')
            _sa(sts_feat, 'subtyp',     'Splitter (Connectorised)')
            _sa(sts_feat, 'spec',       'SM/G657A1')
            _sa(sts_feat, 'dim1',       'L60*W7*H4mm')
            _sa(sts_feat, 'dim2',       '1m')
            _sa(sts_feat, 'cblcpty',    '1:8F')
            _sa(sts_feat, 'conntr',     'LC/APC')
            _sa(sts_feat, 'cmpownr',    'VelocityFibre')
            _sa(sts_feat, 'companyown', 'VelocityFibre')
            _sa(sts_feat, 'stackref',   SR)
            _sa(sts_feat, 'stack',      SR)
            _sa(sts_feat, 'crtdby',     creator)
            _sa(sts_feat, 'createdby',  creator)
            _sa(sts_feat, 'datecrtd',   today)
            _sa(sts_feat, 'lat',        round(pt.y(), 10))
            _sa(sts_feat, 'lon',        round(pt.x(), 10))
            new_sts.append(sts_feat)

            # ── Drop cables: one per HC, from HC → pole ──────────
            for hc in grp['hcs']:
                hc_geom = hc.geometry()
                if not hc_geom or hc_geom.isNull():
                    continue
                hc_pt = hc_geom.asPoint()

                # Distance check
                dx_m   = (hc_pt.x() - pt.x()) * 99000.0
                dy_m   = (hc_pt.y() - pt.y()) * 99000.0
                drop_m = math.sqrt(dx_m * dx_m + dy_m * dy_m)
                if drop_m > 70.0:
                    continue  # beyond max drop length — skip

                drop_geom = QgsGeometry.fromPolylineXY([hc_pt, QgsPointXY(pt.x(), pt.y())])

                # Skip if drop crosses (or terminates on) a road.
                # Use intersects() on the full drop but exclude the case where
                # the HC endpoint itself is on the road — that is just a touch
                # (house sitting on road centreline), not a crossing.
                if road_index:
                    _hc_geom = QgsGeometry.fromPointXY(hc_pt)
                    crosses_road = False
                    for rfid in road_index.intersects(drop_geom.boundingBox()):
                        rg = road_geoms.get(rfid)
                        if rg and not rg.isNull() \
                                and drop_geom.intersects(rg) \
                                and not _hc_geom.intersects(rg):
                            crosses_road = True
                            break
                    if crosses_road:
                        continue

                feat = QgsFeature(drop_layer.fields())
                feat.setGeometry(drop_geom)
                _sa(feat, 'type',       'Cable')
                _sa(feat, 'subtyp',     'Drop')
                _sa(feat, 'spec',       'SM/G657A2')
                _sa(feat, 'dim1',       '3,0mm')
                _sa(feat, 'dim2',       str(round(drop_m, 2)))
                _sa(feat, 'cblcpty',    '1F')
                _sa(feat, 'conntr',     'LC/APC-SC/APC')
                _sa(feat, 'ntwrkptn',   'Drop')
                _sa(feat, 'cmpownr',    'VelocityFibre')
                _sa(feat, 'companyown', 'VelocityFibre')
                _sa(feat, 'stackref',   SR)
                _sa(feat, 'stack',      SR)
                _sa(feat, 'crtdby',     creator)
                _sa(feat, 'createdby',  creator)
                _sa(feat, 'datecrtd',   today)
                new_drops.append(feat)

        # ── Distribution cable ────────────────────────────────────
        dist_feat = QgsFeature(dist_layer.fields())
        dist_feat.setGeometry(line_geom)
        _sa(dist_feat, 'type',      'Cable')
        _sa(dist_feat, 'subtyp',    'Mini-ADSS')
        _sa(dist_feat, 'spec',      'SM/G657A1')
        _sa(dist_feat, 'dim1',      '5,6mm')
        _sa(dist_feat, 'cblcpty',   '24F')
        _sa(dist_feat, 'ntwrkptn',  'Distribution')
        _sa(dist_feat, 'stackref',  SR)
        _sa(dist_feat, 'stack',     SR)
        _sa(dist_feat, 'crtdby',    creator)
        _sa(dist_feat, 'createdby', creator)
        _sa(dist_feat, 'datecrtd',  today)

        # Write to layers via editing API so uncommitted edits in the buffer
        # are committed cleanly first — avoids "Feature not found" errors
        commit_errors = []
        def _commit_features(lyr, feats):
            if not feats:
                return
            was_editing = lyr.isEditable()
            if not was_editing:
                lyr.startEditing()
            for f in feats:
                lyr.addFeature(f)
            if not lyr.commitChanges():
                errs = lyr.commitErrors()
                commit_errors.append(f"{lyr.name()}: {'; '.join(errs)}")
                lyr.rollBack()
                return
            if was_editing:
                lyr.startEditing()

        _commit_features(poles_layer, new_poles)
        _commit_features(sts_layer,   new_sts)
        _commit_features(dist_layer,  [dist_feat])
        _commit_features(drop_layer,  new_drops)

        QgsProject.instance().write()
        self.iface.mapCanvas().refresh()

        if commit_errors:
            QMessageBox.warning(None, '⚠️ Partial Write',
                'Some features could not be saved:\n' +
                '\n'.join(f'  • {e}' for e in commit_errors))
            return

        road_note = (f'\n  ⛔ {road_skip_count} pole position(s) skipped — landed in a road.'
                     if road_skip_count else '')
        QMessageBox.information(None, '✅ Block Planned',
            f'Created along drawn line:\n'
            f'  • {len(new_poles)} poles\n'
            f'  • {len(new_sts)} STS splitters\n'
            f'  • {len(new_drops)} drop cables\n'
            f'  • 1 distribution cable\n'
            f'  • {len(hcs_near)} home connections in block'
            f'{road_note}\n\n'
            f'Now run ⚡ Label All Network Layers to assign all labels.'
        )

    # ── PRIMARY FEEDER AUTOMATION ─────────────────────────
    def run_primary_feeder(self):
        detected = self._detect_sr_code()
        dlg = PrimaryFeederDialog(self.iface.mainWindow(), detected_sr=detected)
        if not dlg.exec_() or not dlg.accepted_run:
            return
        self._pf_params = {
            'sr':           dlg.sr_code,
            'pole_spacing': dlg.pole_spacing,
            'capacity':     dlg.capacity,
        }
        tool = PlanBlockMapTool(self.iface.mapCanvas(), self._on_primary_feeder_line_drawn)
        self.iface.mapCanvas().setMapTool(tool)
        self._push_message(
            'Draw primary feeder route — single-click vertices, double-click/right-click to finish. Esc to cancel.',
            'info'
        )

    def _on_primary_feeder_line_drawn(self, line_geom):
        p = self._pf_params
        self._process_primary_feeder(line_geom, p['sr'], p['pole_spacing'], p['capacity'])

    def _process_primary_feeder(self, line_geom, SR, pole_spacing_m, capacity_choice):
        poles_layer = self._find_layer(['pole'])
        pf_layer    = self._find_layer(['primary', 'cable']) or self._find_layer(['primary', 'feeder'])

        # Ensure layers use the same CRS as the canvas (geometry is always in canvas CRS)
        canvas_crs = self.iface.mapCanvas().mapSettings().destinationCrs()
        for _lyr in [pf_layer, poles_layer]:
            if _lyr and _lyr.crs() != canvas_crs:
                _lyr.setCrs(canvas_crs)

        missing = [n for n, l in [
            ('Poles (any layer with "pole")',                        poles_layer),
            ('Primary Feeder/Cable (any layer with "primary")',      pf_layer),
        ] if not l]
        if missing:
            QMessageBox.warning(None, 'Missing layers',
                'Cannot find required layers. Make sure Fibertime layers exist '
                '(🏗️ Setup Project or Step 1 of 🌐 Pipeline).\n\nMissing:\n'
                + '\n'.join(f'  • {m}' for m in missing))
            return

        # ── Auto-detect cable capacity (double-up rule) ───────────────
        if capacity_choice == 'Auto-detect':
            # Count AGG Domes or PON Boundaries to determine feeder load
            agg_lyr = self._find_layer(['agg', 'dome']) or self._find_layer(['pon'])
            num_pons = agg_lyr.featureCount() if agg_lyr else 1
            ff = max(num_pons * 2, 2)           # double-up rule: (PONs × 1) × 2
            if   ff <= 48:  capacity_choice, ctype, fibre_int = '48F',  'Mini-ADSS', 48
            elif ff <= 72:  capacity_choice, ctype, fibre_int = '72F',  'ADSS',      72
            elif ff <= 96:  capacity_choice, ctype, fibre_int = '96F',  'ADSS',      96
            elif ff <= 144: capacity_choice, ctype, fibre_int = '144F', 'ADSS',     144
            else:           capacity_choice, ctype, fibre_int = '288F', 'ADSS',     288
        else:
            fibre_int = int(capacity_choice.replace('F', ''))
            ctype     = 'Mini-ADSS' if fibre_int <= 48 else 'ADSS'

        # ── Detect bends (snap poles to corners ≥60°) ────────────────
        _BEND_MIN_DEG = 60.0
        _BEND_SNAP_M  = 35.0
        _verts = (line_geom.asMultiPolyline()[0] if line_geom.isMultipart()
                  else line_geom.asPolyline())
        bend_verts = []
        for _i in range(1, len(_verts) - 1):
            _ax, _ay = _verts[_i-1].x(), _verts[_i-1].y()
            _bx, _by = _verts[_i  ].x(), _verts[_i  ].y()
            _cx, _cy = _verts[_i+1].x(), _verts[_i+1].y()
            _v1x, _v1y = _bx - _ax, _by - _ay
            _v2x, _v2y = _cx - _bx, _cy - _by
            _m1 = math.sqrt(_v1x**2 + _v1y**2)
            _m2 = math.sqrt(_v2x**2 + _v2y**2)
            if _m1 == 0 or _m2 == 0:
                continue
            _cos = max(-1.0, min(1.0, (_v1x*_v2x + _v1y*_v2y) / (_m1 * _m2)))
            if math.degrees(math.acos(_cos)) >= _BEND_MIN_DEG:
                bend_verts.append(QgsPointXY(_bx, _by))

        # ── Place poles at regular spacing along route ────────────────
        import datetime as _dt
        today   = _dt.date.today().isoformat()
        creator = (QgsApplication.userFullName().strip()
                   or os.getenv('USERNAME', '')
                   or os.getenv('USER', '')
                   or 'VelocityFibre')

        def _sa(feat, fname, val):
            idx = feat.fields().indexOf(fname)
            if idx != -1:
                feat.setAttribute(idx, val)

        spacing_deg  = pole_spacing_m / 99000.0
        total_length = line_geom.length()
        num_poles    = max(2, int(total_length / spacing_deg))
        new_poles    = []
        last_pole_pt = None

        for i in range(num_poles):
            fraction = i / (num_poles - 1) if num_poles > 1 else 0.0
            pt_geom  = line_geom.interpolate(fraction * total_length)
            pt       = pt_geom.asPoint()

            # Snap to bend vertex if within threshold
            for _bv in bend_verts:
                _dx_m = (_bv.x() - pt.x()) * 99000.0
                _dy_m = (_bv.y() - pt.y()) * 99000.0
                if math.sqrt(_dx_m**2 + _dy_m**2) <= _BEND_SNAP_M:
                    pt      = _bv
                    pt_geom = QgsGeometry.fromPointXY(_bv)
                    break

            pole_feat = QgsFeature(poles_layer.fields())
            pole_feat.setGeometry(pt_geom)
            _sa(pole_feat, 'Pole Type',   'Feeder')
            _sa(pole_feat, 'type_1',      'Pole')
            _sa(pole_feat, 'subtype_1',   'Creosote')
            _sa(pole_feat, 'spec_1',      'H4SANS754')
            _sa(pole_feat, 'dim1',        '9m')
            _sa(pole_feat, 'dim2',        '140-160mm')
            _sa(pole_feat, 'companyown',  'VelocityFibre')
            _sa(pole_feat, 'cmpownr',     'VelocityFibre')
            _sa(pole_feat, 'stack',       SR)
            _sa(pole_feat, 'stackref',    SR)
            _sa(pole_feat, 'createdby',   creator)
            _sa(pole_feat, 'crtdby',      creator)
            _sa(pole_feat, 'datecrtd',    today)
            _sa(pole_feat, 'lat',         round(pt.y(), 10))
            _sa(pole_feat, 'lon',         round(pt.x(), 10))
            new_poles.append(pole_feat)
            last_pole_pt = pt

        # ── Primary Feeder cable along the drawn route ────────────────
        # Name format: AREA.PF.CAPACITY.AGG.POP.01-P.AXXX
        # AXXX = alphanum of the last pole on the route (labeled later)
        cable_name = f'{SR}.PF.{capacity_choice}.AGG.POP.01-P.TBC'

        pf_feat = QgsFeature(pf_layer.fields())
        pf_feat.setGeometry(line_geom)
        _sa(pf_feat, 'label',       cable_name)
        _sa(pf_feat, 'name',        cable_name)
        _sa(pf_feat, 'type',        'Cable')
        _sa(pf_feat, 'subtyp',      ctype)
        _sa(pf_feat, 'spec',        'SM/G652D')
        _sa(pf_feat, 'dim1',        '9,0mm')
        _sa(pf_feat, 'cblcpty',     capacity_choice)
        _sa(pf_feat, 'conntr',      'FC/APC')
        _sa(pf_feat, 'ntwrkptn',    'Primary Feeder')
        _sa(pf_feat, 'from_node',   f'{SR}.AGG.POP.01')
        _sa(pf_feat, 'area',        SR)
        _sa(pf_feat, 'fibre_count', fibre_int)
        _sa(pf_feat, 'cable_type',  ctype)
        _sa(pf_feat, 'length_m',    round(line_geom.length() * 99000.0, 2))
        _sa(pf_feat, 'cmpownr',     'VelocityFibre')
        _sa(pf_feat, 'companyown',  'VelocityFibre')
        _sa(pf_feat, 'stackref',    SR)
        _sa(pf_feat, 'stack',       SR)
        _sa(pf_feat, 'crtdby',      creator)
        _sa(pf_feat, 'createdby',   creator)
        _sa(pf_feat, 'datecrtd',    today)

        # ── Commit to layers ──────────────────────────────────────────
        commit_errors = []
        def _commit(lyr, feats):
            if not feats:
                return
            was_editing = lyr.isEditable()
            if not was_editing:
                lyr.startEditing()
            for f in feats:
                lyr.addFeature(f)
            if not lyr.commitChanges():
                commit_errors.append(f"{lyr.name()}: {'; '.join(lyr.commitErrors())}")
                lyr.rollBack()
                return
            if was_editing:
                lyr.startEditing()

        _commit(poles_layer, new_poles)
        _commit(pf_layer,    [pf_feat])

        QgsProject.instance().write()
        self.iface.mapCanvas().refresh()

        if commit_errors:
            QMessageBox.warning(None, '⚠️ Partial Write',
                'Some features could not be saved:\n'
                + '\n'.join(f'  • {e}' for e in commit_errors))
            return

        QMessageBox.information(None, '✅ Primary Feeder Planned',
            f'Created along drawn route:\n'
            f'  • {len(new_poles)} feeder poles ({pole_spacing_m} m spacing)\n'
            f'  • 1 Primary Feeder cable ({capacity_choice} {ctype})\n\n'
            f'Now run ⚡ Label All Network Layers to assign all labels.\n'
            f'The cable name will update from ".PF.{capacity_choice}.AGG.POP.01-P.TBC"\n'
            f'to the correct pole alphanum after labeling.')

    # ── SECONDARY CABLE ───────────────────────────────────────────────────────

    def run_secondary_feeder(self):
        detected = self._detect_sr_code()
        dlg = SecondaryFeederDialog(self.iface.mainWindow(), detected_sr=detected)
        if not dlg.exec_() or not dlg.accepted_run:
            return
        self._sf_params = {
            'sr':           dlg.sr_code,
            'pole_spacing': dlg.pole_spacing,
            'capacity':     dlg.capacity,
        }
        tool = PlanBlockMapTool(self.iface.mapCanvas(), self._on_secondary_feeder_line_drawn)
        self.iface.mapCanvas().setMapTool(tool)
        self._push_message('Draw secondary feeder route — single-click vertices, double-click/right-click to finish.', 'info')

    def _on_secondary_feeder_line_drawn(self, line_geom):
        p = self._sf_params
        self._process_secondary_feeder(line_geom, p['sr'], p['pole_spacing'], p['capacity'])

    def _process_secondary_feeder(self, line_geom, SR, pole_spacing_m, capacity_choice):
        poles_layer = self._find_layer(['pole'])
        sf_layer    = self._find_layer(['secondary', 'cable']) or self._find_layer(['secondary', 'feeder'])

        missing = [n for n, l in [
            ('Poles',            poles_layer),
            ('Secondary Cable',  sf_layer),
        ] if not l]
        if missing:
            QMessageBox.warning(None, 'Missing layers',
                'Cannot find required layers.\n\nMissing:\n'
                + '\n'.join(f'  • {m}' for m in missing))
            return

        canvas_crs = self.iface.mapCanvas().mapSettings().destinationCrs()
        for _lyr in [sf_layer, poles_layer]:
            if _lyr and _lyr.crs() != canvas_crs:
                _lyr.setCrs(canvas_crs)

        # Auto-detect capacity (secondary = smaller than primary)
        if capacity_choice == 'Auto-detect':
            sf_existing = sf_layer.featureCount() + 1
            ff = sf_existing * 2
            if   ff <= 24:  capacity_choice, ctype, fibre_int = '24F',  'Mini-ADSS', 24
            elif ff <= 48:  capacity_choice, ctype, fibre_int = '48F',  'Mini-ADSS', 48
            elif ff <= 72:  capacity_choice, ctype, fibre_int = '72F',  'ADSS',      72
            elif ff <= 96:  capacity_choice, ctype, fibre_int = '96F',  'ADSS',      96
            else:           capacity_choice, ctype, fibre_int = '144F', 'ADSS',     144
        else:
            fibre_int = int(capacity_choice.replace('F', ''))
            ctype = 'Mini-ADSS' if fibre_int <= 48 else 'ADSS'

        import datetime as _dt
        today   = _dt.date.today().isoformat()
        creator = (QgsApplication.userFullName().strip() or os.getenv('USERNAME', '') or 'VelocityFibre')

        def _sa(feat, fname, val):
            idx = feat.fields().indexOf(fname)
            if idx != -1:
                feat.setAttribute(idx, val)

        # Detect bends
        _verts = line_geom.asMultiPolyline()[0] if line_geom.isMultipart() else line_geom.asPolyline()
        bend_verts = []
        for _i in range(1, len(_verts) - 1):
            _v1x = _verts[_i].x() - _verts[_i-1].x()
            _v1y = _verts[_i].y() - _verts[_i-1].y()
            _v2x = _verts[_i+1].x() - _verts[_i].x()
            _v2y = _verts[_i+1].y() - _verts[_i].y()
            _m1 = math.sqrt(_v1x**2 + _v1y**2)
            _m2 = math.sqrt(_v2x**2 + _v2y**2)
            if _m1 and _m2:
                _cos = max(-1.0, min(1.0, (_v1x*_v2x + _v1y*_v2y) / (_m1 * _m2)))
                if math.degrees(math.acos(_cos)) >= 60.0:
                    bend_verts.append(QgsPointXY(_verts[_i].x(), _verts[_i].y()))

        spacing_deg  = pole_spacing_m / 99000.0
        total_length = line_geom.length()
        num_poles    = max(2, int(total_length / spacing_deg))
        new_poles    = []

        for i in range(num_poles):
            fraction = i / (num_poles - 1) if num_poles > 1 else 0.0
            pt_geom  = line_geom.interpolate(fraction * total_length)
            pt       = pt_geom.asPoint()
            for _bv in bend_verts:
                if math.sqrt((_bv.x()-pt.x())**2 + (_bv.y()-pt.y())**2) * 99000.0 <= 35.0:
                    pt = _bv
                    pt_geom = QgsGeometry.fromPointXY(_bv)
                    break
            pole_feat = QgsFeature(poles_layer.fields())
            pole_feat.setGeometry(pt_geom)
            _sa(pole_feat, 'Pole Type',  'Secondary Feeder')
            _sa(pole_feat, 'type_1',     'Pole')
            _sa(pole_feat, 'subtype_1',  'Creosote')
            _sa(pole_feat, 'spec_1',     'H4SANS754')
            _sa(pole_feat, 'dim1',       '9m')
            _sa(pole_feat, 'dim2',       '120-140mm')
            _sa(pole_feat, 'cmpownr',    'VelocityFibre')
            _sa(pole_feat, 'companyown', 'VelocityFibre')
            _sa(pole_feat, 'stack',      SR)
            _sa(pole_feat, 'stackref',   SR)
            _sa(pole_feat, 'createdby',  creator)
            _sa(pole_feat, 'crtdby',     creator)
            _sa(pole_feat, 'datecrtd',   today)
            _sa(pole_feat, 'lat',        round(pt.y(), 10))
            _sa(pole_feat, 'lon',        round(pt.x(), 10))
            new_poles.append(pole_feat)

        cable_name = f'{SR}.SF.{capacity_choice}.P.TBC-P.TBC'
        sf_feat = QgsFeature(sf_layer.fields())
        sf_feat.setGeometry(line_geom)
        _sa(sf_feat, 'label',       cable_name)
        _sa(sf_feat, 'name',        cable_name)
        _sa(sf_feat, 'type',        'Cable')
        _sa(sf_feat, 'subtyp',      ctype)
        _sa(sf_feat, 'spec',        f'{capacity_choice} {ctype}')
        _sa(sf_feat, 'cblcpty',     capacity_choice)
        _sa(sf_feat, 'ntwrkptn',    'Secondary Feeder')
        _sa(sf_feat, 'area',        SR)
        _sa(sf_feat, 'fibre_count', fibre_int)
        _sa(sf_feat, 'length_m',    round(line_geom.length() * 99000.0, 2))
        _sa(sf_feat, 'cmpownr',     'VelocityFibre')
        _sa(sf_feat, 'companyown',  'VelocityFibre')
        _sa(sf_feat, 'stackref',    SR)
        _sa(sf_feat, 'stack',       SR)
        _sa(sf_feat, 'crtdby',      creator)
        _sa(sf_feat, 'createdby',   creator)
        _sa(sf_feat, 'datecrtd',    today)

        def _commit(lyr, feats):
            if not feats:
                return
            was_editing = lyr.isEditable()
            if not was_editing:
                lyr.startEditing()
            lyr.dataProvider().addFeatures(feats)
            lyr.commitChanges()
            lyr.triggerRepaint()
            if was_editing:
                lyr.startEditing()

        _commit(poles_layer, new_poles)
        _commit(sf_layer, [sf_feat])
        QgsProject.instance().write()
        self.iface.mapCanvas().refresh()
        QMessageBox.information(None, '✅ Secondary Feeder Planned',
            f'Created along drawn route:\n'
            f'  • {len(new_poles)} secondary feeder poles\n'
            f'  • 1 Secondary Feeder cable ({capacity_choice} {ctype})\n\n'
            f'Run ⚡ Label All Network Layers to assign pole references.')

    # ── QUICK POLE ────────────────────────────────────────────────────────────

    def run_quick_pole(self):
        detected = self._detect_sr_code()
        from qgis.PyQt.QtWidgets import QInputDialog
        sr, ok = QInputDialog.getText(
            self.iface.mainWindow(), 'Quick Pole',
            'Area code (SR):', text=detected
        )
        if not ok or not sr.strip():
            return
        self._qp_sr = sr.strip().upper()
        tool = ClickMapTool(
            self.iface.mapCanvas(),
            self._on_quick_pole_click,
            icon_color='#ff6600',
            multi=True
        )
        self.iface.mapCanvas().setMapTool(tool)
        self._push_message('Click to place poles. Right-click or Esc to stop.', 'info')

    def _on_quick_pole_click(self, pt):
        poles_layer = self._find_layer(['pole'])
        if not poles_layer:
            self._push_message('Poles layer not found.', 'warning')
            return
        self._backup_layer(poles_layer)

        canvas_crs = self.iface.mapCanvas().mapSettings().destinationCrs()
        if poles_layer.crs() != canvas_crs:
            poles_layer.setCrs(canvas_crs)

        import datetime as _dt
        today   = _dt.date.today().isoformat()
        creator = QgsApplication.userFullName().strip() or os.getenv('USERNAME', '') or 'VelocityFibre'
        SR      = self._qp_sr

        # ── Road check: poles must never be placed in roads ──────────────────
        self._ensure_roads_loaded(SR)
        if self._point_in_road(pt):
            self._push_message('⛔ Pole blocked — location is in a road. Move off the road and try again.', 'critical')
            return

        def _sa(feat, fname, val):
            idx = feat.fields().indexOf(fname)
            if idx != -1:
                feat.setAttribute(idx, val)

        feat = QgsFeature(poles_layer.fields())
        feat.setGeometry(QgsGeometry.fromPointXY(pt))
        _sa(feat, 'Pole Type',  'Distribution')
        _sa(feat, 'type_1',     'Pole')
        _sa(feat, 'subtype_1',  'Creosote')
        _sa(feat, 'spec_1',     'H4SANS754')
        _sa(feat, 'dim1',       '7m')
        _sa(feat, 'dim2',       '120-140mm')
        _sa(feat, 'cmpownr',    'VelocityFibre')
        _sa(feat, 'companyown', 'VelocityFibre')
        _sa(feat, 'stack',      SR)
        _sa(feat, 'stackref',   SR)
        _sa(feat, 'createdby',  creator)
        _sa(feat, 'crtdby',     creator)
        _sa(feat, 'datecrtd',   today)
        _sa(feat, 'lat',        round(pt.y(), 10))
        _sa(feat, 'lon',        round(pt.x(), 10))

        was_editing = poles_layer.isEditable()
        if not was_editing:
            poles_layer.startEditing()
        poles_layer.dataProvider().addFeatures([feat])
        poles_layer.commitChanges()
        poles_layer.triggerRepaint()
        if was_editing:
            poles_layer.startEditing()

    # ── QUICK STS ─────────────────────────────────────────────────────────────

    def run_quick_sts(self):
        detected = self._detect_sr_code()
        from qgis.PyQt.QtWidgets import QInputDialog
        sr, ok = QInputDialog.getText(
            self.iface.mainWindow(), 'Quick STS',
            'Area code (SR):', text=detected
        )
        if not ok or not sr.strip():
            return
        self._qsts_sr = sr.strip().upper()
        # Build pole index once
        self._qsts_pole_index = None
        self._qsts_poles_feats = {}
        poles_layer = self._find_layer(['pole'])
        if poles_layer:
            idx = QgsSpatialIndex()
            for f in poles_layer.getFeatures():
                if f.geometry() and not f.geometry().isNull():
                    idx.addFeature(f)
                    self._qsts_poles_feats[f.id()] = f
            self._qsts_pole_index = idx

        tool = ClickMapTool(
            self.iface.mapCanvas(),
            self._on_quick_sts_click,
            icon_color='#ff00ff',
            multi=True
        )
        self.iface.mapCanvas().setMapTool(tool)
        self._push_message('Click near a pole to place STS splitter. Right-click or Esc to stop.', 'info')

    def _on_quick_sts_click(self, pt):
        sts_layer = self._find_layer(['sts']) or self._find_layer(['splitter'], exclude=['fts'])
        if not sts_layer:
            self._push_message('STS Splitters layer not found.', 'warning')
            return
        self._backup_layer(sts_layer)

        canvas_crs = self.iface.mapCanvas().mapSettings().destinationCrs()
        if sts_layer.crs() != canvas_crs:
            sts_layer.setCrs(canvas_crs)

        # Snap to nearest pole within 30m
        place_pt = pt
        if self._qsts_pole_index and self._qsts_poles_feats:
            snap_r = 30.0 / 99000.0
            rect   = QgsRectangle(pt.x()-snap_r, pt.y()-snap_r, pt.x()+snap_r, pt.y()+snap_r)
            nearby = self._qsts_pole_index.intersects(rect)
            if nearby:
                best_fid  = min(nearby, key=lambda fid: self._qsts_poles_feats[fid].geometry().distance(QgsGeometry.fromPointXY(pt)))
                place_pt = self._qsts_poles_feats[best_fid].geometry().asPoint()

        import datetime as _dt
        today   = _dt.date.today().isoformat()
        creator = QgsApplication.userFullName().strip() or os.getenv('USERNAME', '') or 'VelocityFibre'
        SR      = self._qsts_sr
        sts_n   = sts_layer.featureCount() + 1

        def _sa(feat, fname, val):
            idx = feat.fields().indexOf(fname)
            if idx != -1:
                feat.setAttribute(idx, val)

        feat = QgsFeature(sts_layer.fields())
        feat.setGeometry(QgsGeometry.fromPointXY(place_pt))
        sts_label = f'{SR}.STS.8.DIS.DM.P.C{sts_n:03d}-OLT.01.C1P1.L1'
        _sa(feat, 'label',      sts_label)
        _sa(feat, 'name',       sts_label)
        _sa(feat, 'type',       'Splitter')
        _sa(feat, 'subtyp',     'Splitter (Connectorised)')
        _sa(feat, 'spec',       'SM/G657A1')
        _sa(feat, 'dim1',       'L60*W7*H4mm')
        _sa(feat, 'dim2',       '1m')
        _sa(feat, 'cblcpty',    '1:8F')
        _sa(feat, 'conntr',     'LC/APC')
        _sa(feat, 'cmpownr',    'VelocityFibre')
        _sa(feat, 'companyown', 'VelocityFibre')
        _sa(feat, 'stackref',   SR)
        _sa(feat, 'stack',      SR)
        _sa(feat, 'crtdby',     creator)
        _sa(feat, 'createdby',  creator)
        _sa(feat, 'datecrtd',   today)
        _sa(feat, 'lat',        round(place_pt.y(), 10))
        _sa(feat, 'lon',        round(place_pt.x(), 10))

        was_editing = sts_layer.isEditable()
        if not was_editing:
            sts_layer.startEditing()
        sts_layer.dataProvider().addFeatures([feat])
        sts_layer.commitChanges()
        sts_layer.triggerRepaint()
        if was_editing:
            sts_layer.startEditing()

    # ── QUICK AGG DOME ────────────────────────────────────────────────────────

    def run_quick_agg_dome(self):
        detected = self._detect_sr_code()
        from qgis.PyQt.QtWidgets import QInputDialog
        sr, ok = QInputDialog.getText(
            self.iface.mainWindow(), 'Quick AGG Dome', 'Area code (SR):', text=detected
        )
        if not ok or not sr.strip():
            return
        self._qagg_sr = sr.strip().upper()
        self._qagg_pole_index = None
        self._qagg_poles_feats = {}
        poles_layer = self._find_layer(['pole'])
        if poles_layer:
            idx = QgsSpatialIndex()
            for f in poles_layer.getFeatures():
                if f.geometry() and not f.geometry().isNull():
                    idx.addFeature(f)
                    self._qagg_poles_feats[f.id()] = f
            self._qagg_pole_index = idx
        tool = ClickMapTool(
            self.iface.mapCanvas(), self._on_quick_agg_click,
            icon_color='#ffff00', multi=True
        )
        self.iface.mapCanvas().setMapTool(tool)
        self._push_message('Click near a pole to place AGG Dome. Right-click or Esc to stop.', 'info')

    def _on_quick_agg_click(self, pt):
        agg_layer = self._find_layer(['enclosure', 'splice']) or self._find_layer(['agg', 'dome'])
        if not agg_layer:
            self._push_message('Enclosures Splice layer not found.', 'warning')
            return
        self._backup_layer(agg_layer)
        place_pt = pt
        if self._qagg_pole_index and self._qagg_poles_feats:
            snap_r = 30.0 / 99000.0
            rect = QgsRectangle(pt.x()-snap_r, pt.y()-snap_r, pt.x()+snap_r, pt.y()+snap_r)
            nearby = self._qagg_pole_index.intersects(rect)
            if nearby:
                best_fid = min(nearby, key=lambda fid: self._qagg_poles_feats[fid].geometry().distance(QgsGeometry.fromPointXY(pt)))
                place_pt = self._qagg_poles_feats[best_fid].geometry().asPoint()
        import datetime as _dt
        today   = _dt.date.today().isoformat()
        creator = QgsApplication.userFullName().strip() or os.getenv('USERNAME', '') or 'VelocityFibre'
        SR      = self._qagg_sr
        n       = agg_layer.featureCount() + 1

        def _sa(feat, fname, val):
            idx = feat.fields().indexOf(fname)
            if idx != -1:
                feat.setAttribute(idx, val)

        feat = QgsFeature(agg_layer.fields())
        feat.setGeometry(QgsGeometry.fromPointXY(place_pt))
        lbl = f'{SR}.AGG.DM.P.A{n:03d}'
        _sa(feat, 'label_1',    lbl)
        _sa(feat, 'label',      lbl)
        _sa(feat, 'name',       lbl)
        _sa(feat, 'type_1',     'Enclosure Splice')
        _sa(feat, 'spec_1',     'CMJ')
        _sa(feat, 'dim1',       'L290*W231*D164mm')
        _sa(feat, 'cblcpty1',   '144F')
        _sa(feat, 'cmpownr',    'VelocityFibre')
        _sa(feat, 'companyown', 'VelocityFibre')
        _sa(feat, 'stackref',   SR)
        _sa(feat, 'stack',      SR)
        _sa(feat, 'crtdby',     creator)
        _sa(feat, 'createdby',  creator)
        _sa(feat, 'datecrtd',   today)
        _sa(feat, 'lat',        round(place_pt.y(), 10))
        _sa(feat, 'lon',        round(place_pt.x(), 10))

        was_editing = agg_layer.isEditable()
        if not was_editing:
            agg_layer.startEditing()
        agg_layer.dataProvider().addFeatures([feat])
        agg_layer.commitChanges()
        agg_layer.triggerRepaint()
        if was_editing:
            agg_layer.startEditing()
        self._push_message(f'AGG Dome placed: {lbl}', 'info')

    # ── QUICK PON ─────────────────────────────────────────────────────────────

    def run_quick_pon(self):
        detected = self._detect_sr_code()
        from qgis.PyQt.QtWidgets import QInputDialog
        sr, ok = QInputDialog.getText(
            self.iface.mainWindow(), 'Quick PON', 'Area code (SR):', text=detected
        )
        if not ok or not sr.strip():
            return
        self._qpon_sr = sr.strip().upper()
        tool = PolygonMapTool(self.iface.mapCanvas(), self._on_pon_polygon_drawn)
        self.iface.mapCanvas().setMapTool(tool)
        self._push_message('Click to draw PON boundary. Right-click or double-click to finish.', 'info')

    def _on_pon_polygon_drawn(self, geom):
        pon_layer = self._find_layer(['pon'], exclude=['zone'])
        hc_layer  = self._find_layer(['home', 'connect'])
        if not pon_layer:
            self._push_message('PON layer not found.', 'warning')
            return
        self._backup_layer(pon_layer)

        # Count home connections inside polygon
        unit_count = 0
        if hc_layer:
            for f in hc_layer.getFeatures():
                if f.geometry() and geom.contains(f.geometry()):
                    unit_count += 1

        import datetime as _dt
        today   = _dt.date.today().isoformat()
        creator = QgsApplication.userFullName().strip() or os.getenv('USERNAME', '') or 'VelocityFibre'
        SR      = self._qpon_sr
        n       = pon_layer.featureCount() + 1

        def _sa(feat, fname, val):
            idx = feat.fields().indexOf(fname)
            if idx != -1:
                feat.setAttribute(idx, val)

        feat = QgsFeature(pon_layer.fields())
        feat.setGeometry(geom)
        _sa(feat, 'pon_no',     n)
        _sa(feat, 'zone_no',    0)
        _sa(feat, 'label',      f'{SR}.PON.{n:03d}')
        _sa(feat, 'name',       f'{SR}.PON.{n:03d}')
        _sa(feat, 'units',      unit_count)
        _sa(feat, 'sdu',        unit_count)
        _sa(feat, 'sdu_count',  unit_count)
        _sa(feat, 'stack',      SR)
        _sa(feat, 'stackref',   SR)
        _sa(feat, 'crtdby',     creator)
        _sa(feat, 'datecrtd',   today)

        was_editing = pon_layer.isEditable()
        if not was_editing:
            pon_layer.startEditing()
        pon_layer.dataProvider().addFeatures([feat])
        pon_layer.commitChanges()
        pon_layer.triggerRepaint()
        if was_editing:
            pon_layer.startEditing()
        self._push_message(f'PON {n} created — {unit_count} units inside.', 'info')

    # ── QUICK ZONE ────────────────────────────────────────────────────────────

    def run_quick_zone(self):
        detected = self._detect_sr_code()
        from qgis.PyQt.QtWidgets import QInputDialog
        sr, ok = QInputDialog.getText(
            self.iface.mainWindow(), 'Quick Zone', 'Area code (SR):', text=detected
        )
        if not ok or not sr.strip():
            return
        self._qzone_sr = sr.strip().upper()
        tool = PolygonMapTool(self.iface.mapCanvas(), self._on_zone_polygon_drawn)
        self.iface.mapCanvas().setMapTool(tool)
        self._push_message('Click to draw Zone boundary. Right-click or double-click to finish.', 'info')

    def _on_zone_polygon_drawn(self, geom):
        zone_layer = self._find_layer(['zone'], exclude=['pon'])
        pon_layer  = self._find_layer(['pon'], exclude=['zone'])
        if not zone_layer:
            self._push_message('Zones layer not found.', 'warning')
            return
        self._backup_layer(zone_layer)

        # Count PONs inside zone
        pon_count = 0
        if pon_layer:
            for f in pon_layer.getFeatures():
                if f.geometry() and geom.contains(f.geometry().centroid()):
                    pon_count += 1

        import datetime as _dt
        today   = _dt.date.today().isoformat()
        creator = QgsApplication.userFullName().strip() or os.getenv('USERNAME', '') or 'VelocityFibre'
        SR      = self._qzone_sr
        n       = zone_layer.featureCount() + 1

        def _sa(feat, fname, val):
            idx = feat.fields().indexOf(fname)
            if idx != -1:
                feat.setAttribute(idx, val)

        feat = QgsFeature(zone_layer.fields())
        feat.setGeometry(geom)
        _sa(feat, 'zone_no',    n)
        _sa(feat, 'label',      f'{SR}.ZONE.{n:02d}')
        _sa(feat, 'name',       f'{SR}.ZONE.{n:02d}')
        _sa(feat, 'pon_count',  pon_count)
        _sa(feat, 'stack',      SR)
        _sa(feat, 'stackref',   SR)
        _sa(feat, 'crtdby',     creator)
        _sa(feat, 'datecrtd',   today)

        was_editing = zone_layer.isEditable()
        if not was_editing:
            zone_layer.startEditing()
        zone_layer.dataProvider().addFeatures([feat])
        zone_layer.commitChanges()
        zone_layer.triggerRepaint()
        if was_editing:
            zone_layer.startEditing()
        self._push_message(f'Zone {n} created — {pon_count} PONs inside.', 'info')

    # ── AUTO GENERATE PONs FROM ERVEN ────────────────────────────────────────

    def run_generate_pons(self):
        """Generate PON boundary polygons from erven using Morton Z-order clustering.

        Algorithm:
          1. Collect all erven centroids from the Erven layer.
          2. Sort by Morton (Z-order) code — preserves 2-D spatial locality.
          3. Split into equal chunks of ~target units per PON.
          4. For each chunk: union the erven polygons and apply a tiny buffer
             to fill hair-line gaps between adjacent erven, giving a clean polygon
             that follows cadastral (road-edge) boundaries.
          5. Write each polygon as a feature in the PON Boundaries layer.
        """
        from qgis.PyQt.QtWidgets import QInputDialog
        import datetime as _dt

        # ── 1. Collect inputs ──────────────────────────────────────────────
        detected = self._detect_sr_code()
        sr, ok = QInputDialog.getText(
            self.iface.mainWindow(), 'Generate PONs from Erven',
            'Area code (SR):', text=detected
        )
        if not ok or not sr.strip():
            return
        SR = sr.strip().upper()

        target, ok = QInputDialog.getInt(
            self.iface.mainWindow(), 'Generate PONs from Erven',
            'Target units per PON (94–102):', 96, 90, 110, 1
        )
        if not ok:
            return

        erven_lyr = self._find_layer(['erven'])
        pon_lyr   = self._find_layer(['pon'], exclude=['zone'])

        if not erven_lyr:
            QMessageBox.critical(None, 'Error', 'No Erven layer found in project.\nLoad an Erven layer first.')
            return
        if not pon_lyr:
            QMessageBox.critical(None, 'Error',
                'No PON Boundaries layer found.\nRun "New Project" first to create project layers.')
            return

        # ── 2. Handle existing PON features ───────────────────────────────
        existing = pon_lyr.featureCount()
        if existing > 0:
            reply = QMessageBox.question(
                None, 'PON layer already has data',
                f'PON Boundaries layer has {existing} existing PON(s).\n'
                'Clear all and regenerate from scratch?',
                QMessageBox.Yes | QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return
            self._backup_layer(pon_lyr)
            pon_lyr.dataProvider().truncate()
            pon_lyr.triggerRepaint()

        # ── 3. Collect erven ───────────────────────────────────────────────
        self._push_message('Collecting erven data…', 'info')
        QApplication.processEvents()

        erven_items = []   # [(cx, cy, QgsGeometry), …]
        for feat in erven_lyr.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isNull():
                continue
            c = geom.centroid().asPoint()
            erven_items.append((c.x(), c.y(), QgsGeometry(geom)))

        if not erven_items:
            QMessageBox.critical(None, 'Error', 'Erven layer has no valid polygon features.')
            return

        n_erven = len(erven_items)
        self._push_message(f'{n_erven} erven found. Clustering…', 'info')
        QApplication.processEvents()

        # ── 4. Morton Z-order sort ─────────────────────────────────────────
        xs = [e[0] for e in erven_items]
        ys = [e[1] for e in erven_items]
        xmin, xmax = min(xs), max(xs)
        ymin, ymax = min(ys), max(ys)
        RES = 65535

        def _morton(x, y):
            def _spread(n):
                n = n & 0xFFFF
                n = (n | (n << 8)) & 0x00FF00FF
                n = (n | (n << 4)) & 0x0F0F0F0F
                n = (n | (n << 2)) & 0x33333333
                n = (n | (n << 1)) & 0x55555555
                return n
            ix = int((x - xmin) / (xmax - xmin) * RES) if xmax > xmin else 0
            iy = int((y - ymin) / (ymax - ymin) * RES) if ymax > ymin else 0
            return _spread(max(0, min(RES, ix))) | (_spread(max(0, min(RES, iy))) << 1)

        sorted_erven = sorted(erven_items, key=lambda e: _morton(e[0], e[1]))

        # ── 5. Split into equal-ish chunks ────────────────────────────────
        n_pons     = max(1, round(n_erven / target))
        chunk_size = n_erven / n_pons
        groups     = []
        for i in range(n_pons):
            s = int(round(i * chunk_size))
            e = int(round((i + 1) * chunk_size))
            chunk = sorted_erven[s:e]
            if chunk:
                groups.append(chunk)

        # Merge tiny last group into previous to avoid <50% PONs
        if len(groups) >= 2 and len(groups[-1]) < target * 0.5:
            groups[-2].extend(groups[-1])
            groups.pop()

        # ── 6. Build polygons ──────────────────────────────────────────────
        # Buffer ~1 m (in degrees for WGS84) to close hairline gaps between erven
        buf_deg = 0.000009   # ≈ 1 m at latitude −25°

        today   = _dt.date.today().isoformat()
        creator = QgsApplication.userFullName().strip() or os.getenv('USERNAME', '') or 'VelocityFibre'

        def _sa(feat, fname, val):
            idx = feat.fields().indexOf(fname)
            if idx != -1:
                feat.setAttribute(idx, val)

        new_feats = []
        for i, group in enumerate(groups):
            combined = None
            for _, _, geom in group:
                combined = geom if combined is None else combined.combine(geom)

            if combined is None or combined.isNull():
                continue

            poly_geom = combined.buffer(buf_deg, 4)

            pon_no = i + 1
            feat   = QgsFeature(pon_lyr.fields())
            feat.setGeometry(poly_geom)
            _sa(feat, 'pon_no',    pon_no)
            _sa(feat, 'zone_no',   0)
            _sa(feat, 'label',     f'{SR}.PON.{pon_no:03d}')
            _sa(feat, 'name',      f'{SR}.PON.{pon_no:03d}')
            _sa(feat, 'units',     len(group))
            _sa(feat, 'sdu',       len(group))
            _sa(feat, 'sdu_count', len(group))
            _sa(feat, 'stackref',  SR)
            _sa(feat, 'stack',     SR)
            _sa(feat, 'crtdby',    creator)
            _sa(feat, 'datecrtd',  today)
            new_feats.append(feat)

        # ── 7. Write to layer ──────────────────────────────────────────────
        pon_lyr.dataProvider().addFeatures(new_feats)
        pon_lyr.updateExtents()
        pon_lyr.triggerRepaint()

        counts   = [len(g) for g in groups]
        in_range = sum(1 for c in counts if 94 <= c <= 102)
        self._push_message(
            f'Done — {len(new_feats)} PONs created from {n_erven} erven. '
            f'{in_range}/{len(new_feats)} in 94–102 range. '
            f'Min={min(counts)}, Max={max(counts)}.',
            'success'
        )

    # ── AUTO GENERATE ZONES FROM PONs ────────────────────────────────────────

    def run_generate_zones(self):
        """Auto-group existing PON boundaries into Zone polygons (≤16 PONs per Zone)."""
        from qgis.PyQt.QtWidgets import QInputDialog
        import datetime as _dt

        detected = self._detect_sr_code()
        sr, ok = QInputDialog.getText(
            self.iface.mainWindow(), 'Generate Zones from PONs',
            'Area code (SR):', text=detected
        )
        if not ok or not sr.strip():
            return
        SR = sr.strip().upper()

        max_pons, ok = QInputDialog.getInt(
            self.iface.mainWindow(), 'Generate Zones from PONs',
            'Max PONs per Zone (1 OLT card = 16):', 16, 8, 24, 1
        )
        if not ok:
            return

        pon_lyr  = self._find_layer(['pon'],  exclude=['zone'])
        zone_lyr = self._find_layer(['zone'], exclude=['pon'])

        if not pon_lyr or pon_lyr.featureCount() == 0:
            QMessageBox.critical(None, 'Error', 'No PON Boundaries found. Run Auto PONs first.')
            return
        if not zone_lyr:
            QMessageBox.critical(None, 'Error',
                'No Zone Boundaries layer found. Run "New Project" first.')
            return

        existing = zone_lyr.featureCount()
        if existing > 0:
            reply = QMessageBox.question(
                None, 'Zone layer already has data',
                f'Zone Boundaries layer has {existing} existing zone(s).\n'
                'Clear and regenerate?',
                QMessageBox.Yes | QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return
            self._backup_layer(zone_lyr)
            zone_lyr.dataProvider().truncate()
            zone_lyr.triggerRepaint()

        # Collect PON centroids + geometries
        pon_items = []   # [(cx, cy, QgsGeometry, pon_feat), …]
        for feat in pon_lyr.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isNull():
                continue
            c = geom.centroid().asPoint()
            pon_items.append((c.x(), c.y(), QgsGeometry(geom), feat))

        n_pons = len(pon_items)
        if n_pons == 0:
            QMessageBox.critical(None, 'Error', 'No valid PON polygons found.')
            return

        # Morton sort → equal chunks of max_pons
        xs = [p[0] for p in pon_items]; ys = [p[1] for p in pon_items]
        xmin, xmax = min(xs), max(xs); ymin, ymax = min(ys), max(ys)
        RES = 65535

        def _morton(x, y):
            def _spread(n):
                n = n & 0xFFFF
                n = (n | (n << 8)) & 0x00FF00FF
                n = (n | (n << 4)) & 0x0F0F0F0F
                n = (n | (n << 2)) & 0x33333333
                n = (n | (n << 1)) & 0x55555555
                return n
            ix = int((x - xmin) / (xmax - xmin) * RES) if xmax > xmin else 0
            iy = int((y - ymin) / (ymax - ymin) * RES) if ymax > ymin else 0
            return _spread(max(0, min(RES, ix))) | (_spread(max(0, min(RES, iy))) << 1)

        sorted_pons = sorted(pon_items, key=lambda p: _morton(p[0], p[1]))
        n_zones   = max(1, math.ceil(n_pons / max_pons))
        chunk_sz  = n_pons / n_zones
        groups    = []
        for i in range(n_zones):
            s = int(round(i * chunk_sz))
            e = int(round((i + 1) * chunk_sz))
            chunk = sorted_pons[s:e]
            if chunk:
                groups.append(chunk)

        buf_deg = 0.000009
        today   = _dt.date.today().isoformat()
        creator = QgsApplication.userFullName().strip() or os.getenv('USERNAME', '') or 'VelocityFibre'

        def _sa(feat, fname, val):
            idx = feat.fields().indexOf(fname)
            if idx != -1:
                feat.setAttribute(idx, val)

        new_feats = []
        for i, group in enumerate(groups):
            combined = None
            for _, _, geom, _ in group:
                combined = geom if combined is None else combined.combine(geom)
            if combined is None or combined.isNull():
                continue
            poly_geom = combined.buffer(buf_deg, 4)
            zone_no   = i + 1
            feat = QgsFeature(zone_lyr.fields())
            feat.setGeometry(poly_geom)
            _sa(feat, 'zone_no',   zone_no)
            _sa(feat, 'label',     f'{SR}.ZONE.{zone_no:02d}')
            _sa(feat, 'name',      f'{SR}.ZONE.{zone_no:02d}')
            _sa(feat, 'pon_count', len(group))
            _sa(feat, 'stackref',  SR)
            _sa(feat, 'stack',     SR)
            _sa(feat, 'crtdby',    creator)
            _sa(feat, 'datecrtd',  today)
            new_feats.append(feat)

        zone_lyr.dataProvider().addFeatures(new_feats)
        zone_lyr.updateExtents()
        zone_lyr.triggerRepaint()

        # Also stamp zone_no onto each PON feature
        pon_lyr.startEditing()
        zone_idx = pon_lyr.fields().indexOf('zone_no')
        if zone_idx != -1:
            for i, group in enumerate(groups):
                for _, _, _, pon_feat in group:
                    pon_lyr.changeAttributeValue(pon_feat.id(), zone_idx, i + 1)
        pon_lyr.commitChanges()
        pon_lyr.triggerRepaint()

        self._push_message(
            f'Done — {len(new_feats)} zones created from {n_pons} PONs '
            f'({max_pons} PONs per zone). Zone numbers stamped on PON layer.',
            'success'
        )

    # ── HOME CONNECTIONS FROM ERVEN (SIMPLE CENTROID) ────────────────────────

    def run_hc_from_erven(self):
        """Bulk-create Home Connection points from erven centroids.

        Faster and more reliable than the Overture buildings approach.
        Transfers SG21 (ID field) and SG26 (PRCL_KEY field) from each erf.
        Skips erven that already have an HC inside them.
        """
        from qgis.PyQt.QtWidgets import QInputDialog
        import datetime as _dt

        detected = self._detect_sr_code()
        sr, ok = QInputDialog.getText(
            self.iface.mainWindow(), 'Home Connections from Erven',
            'Area code (SR):', text=detected
        )
        if not ok or not sr.strip():
            return
        SR = sr.strip().upper()

        erven_lyr = self._find_layer(['erven'])
        hc_lyr    = self._find_layer(['home', 'connect'])

        if not erven_lyr:
            QMessageBox.critical(None, 'Error', 'No Erven layer found.')
            return
        if not hc_lyr:
            QMessageBox.critical(None, 'Error',
                'No Home Connections layer found. Run "New Project" first.')
            return

        # Build spatial index of existing HC points
        hc_index = QgsSpatialIndex()
        hc_feats = {}
        for f in hc_lyr.getFeatures():
            if f.geometry() and not f.geometry().isNull():
                hc_index.addFeature(f)
                hc_feats[f.id()] = f

        # Field name maps (case-insensitive)
        erf_fields = {f.name().lower(): f.name() for f in erven_lyr.fields()}
        id_field      = erf_fields.get('id')           # SG21
        prcl_field    = erf_fields.get('prcl_key')     # SG26
        label_field_e = erf_fields.get('label') or erf_fields.get('label_1')
        east_field    = erf_fields.get('easting')
        nrth_field    = erf_fields.get('northing')

        # Determine starting HC number
        hc_label_field = self._find_label_field(hc_lyr)
        used_nums = set()
        if hc_label_field:
            for f in hc_lyr.getFeatures():
                lbl = f[hc_label_field]
                if lbl and str(lbl).startswith(f'{SR}.HC.'):
                    try:
                        used_nums.add(int(str(lbl).split('.')[-1]))
                    except Exception:
                        pass
        hc_num = max(used_nums, default=0) + 1

        today   = _dt.date.today().isoformat()
        creator = QgsApplication.userFullName().strip() or os.getenv('USERNAME', '') or 'VelocityFibre'
        snap_r  = 0.00005   # ~5m — skip erven already covered

        def _sa(feat, fname, val):
            idx = feat.fields().indexOf(fname)
            if idx != -1:
                feat.setAttribute(idx, val)

        new_feats = []
        skipped   = 0
        for erf in erven_lyr.getFeatures():
            geom = erf.geometry()
            if not geom or geom.isNull():
                continue
            c = geom.centroid().asPoint()

            # Skip if an HC already exists within snap radius
            rect    = QgsRectangle(c.x()-snap_r, c.y()-snap_r, c.x()+snap_r, c.y()+snap_r)
            nearby  = hc_index.intersects(rect)
            if nearby and any(hc_feats[fid].geometry().distance(QgsGeometry.fromPointXY(c)) < snap_r
                              for fid in nearby):
                skipped += 1
                continue

            lbl  = f'{SR}.HC.{hc_num:05d}'
            sg21 = str(erf[id_field])      if id_field    else ''
            sg26 = str(erf[prcl_field])    if prcl_field  else ''
            erf_lbl = str(erf[label_field_e]) if label_field_e else ''
            try:
                east = float(erf[east_field]) if east_field else round(c.x(), 10)
            except Exception:
                east = round(c.x(), 10)
            try:
                nrth = float(erf[nrth_field]) if nrth_field else round(c.y(), 10)
            except Exception:
                nrth = round(c.y(), 10)

            feat = QgsFeature(hc_lyr.fields())
            feat.setGeometry(QgsGeometry.fromPointXY(c))
            _sa(feat, 'label_1',   lbl)
            _sa(feat, 'label',     lbl)
            _sa(feat, 'apctmpnm',  sg21)   # SG21
            _sa(feat, 'apc_arg',   sg26)   # SG26
            _sa(feat, 'srvc_nme',  erf_lbl)
            _sa(feat, 'lat',       round(c.y(), 10))
            _sa(feat, 'lon',       round(c.x(), 10))
            _sa(feat, 'status',    'Not Installed')
            _sa(feat, 'stackref',  SR)
            _sa(feat, 'cmpownr',   'VelocityFibre')
            _sa(feat, 'crtdby',    creator)
            _sa(feat, 'datecrtd',  today)
            new_feats.append(feat)
            hc_num += 1

        if not new_feats:
            self._push_message(
                f'All {skipped} erven already have Home Connections — nothing to add.', 'info'
            )
            return

        hc_lyr.dataProvider().addFeatures(new_feats)
        hc_lyr.updateExtents()
        hc_lyr.triggerRepaint()
        self._push_message(
            f'Done — {len(new_feats)} Home Connections created from erven centroids'
            f'{f" ({skipped} already covered, skipped)" if skipped else ""}.',
            'success'
        )

    # ── AUTO FTS + SS SPLITTERS AT AGG DOMES ─────────────────────────────────

    def run_auto_fts(self):
        """Place FTS + SS splitters at every AGG dome that does not already have one."""
        from qgis.PyQt.QtWidgets import QInputDialog
        import datetime as _dt

        detected = self._detect_sr_code()
        sr, ok = QInputDialog.getText(
            self.iface.mainWindow(), 'Auto FTS + SS',
            'Area code (SR):', text=detected
        )
        if not ok or not sr.strip():
            return
        SR = sr.strip().upper()

        agg_lyr = self._find_layer(['enclosure', 'splice']) or self._find_layer(['agg', 'dome'])
        fts_lyr = self._find_layer(['fts'])

        if not agg_lyr or agg_lyr.featureCount() == 0:
            QMessageBox.critical(None, 'Error',
                'No AGG Domes (Enclosures Splice) found.\nPlace AGG domes first.')
            return
        if not fts_lyr:
            QMessageBox.critical(None, 'Error',
                'No FTS Splitters layer found. Run "New Project" first.')
            return

        # Spatial index of existing FTS/SS
        fts_index = QgsSpatialIndex()
        for f in fts_lyr.getFeatures():
            if f.geometry() and not f.geometry().isNull():
                fts_index.addFeature(f)

        snap_r  = 0.00002   # ~2m — treat as co-located
        today   = _dt.date.today().isoformat()
        creator = QgsApplication.userFullName().strip() or os.getenv('USERNAME', '') or 'VelocityFibre'

        # Read AGG dome labels to build FTS labels
        agg_label_field = None
        for fn in ('label_1', 'label', 'name', 'Name', 'Label'):
            if agg_lyr.fields().indexOf(fn) != -1:
                agg_label_field = fn
                break

        # Determine starting FTS number
        used_fts = set()
        for f in fts_lyr.getFeatures():
            for fn in ('label', 'label_1', 'name'):
                if fts_lyr.fields().indexOf(fn) != -1:
                    lbl = f[fn]
                    if lbl and f'{SR}.FTS.' in str(lbl):
                        try:
                            used_fts.add(int(str(lbl).split('.A')[-1].split('-')[0]))
                        except Exception:
                            pass
                    break
        fts_num = max(used_fts, default=0) + 1

        def _sa(feat, fname, val):
            idx = feat.fields().indexOf(fname)
            if idx != -1:
                feat.setAttribute(idx, val)

        new_feats = []
        skipped   = 0
        for agg in agg_lyr.getFeatures():
            geom = agg.geometry()
            if not geom or geom.isNull():
                continue
            pt = geom.asPoint()
            rect = QgsRectangle(pt.x()-snap_r, pt.y()-snap_r, pt.x()+snap_r, pt.y()+snap_r)
            if fts_index.intersects(rect):
                skipped += 1
                continue

            agg_lbl = str(agg[agg_label_field]) if agg_label_field else f'P.A{fts_num:03d}'
            # Extract Axxx from dome label (e.g. MOA.AGG.DM.P.A001 → A001)
            agg_ref = agg_lbl.split('.')[-1] if agg_label_field else f'A{fts_num:03d}'

            fts_lbl = f'{SR}.FTS.16.AGG.DM.P.{agg_ref}-OLT.01.C1P1'
            ss_lbl  = f'{SR}.SS.16.AGG.DM.P.{agg_ref}-OLT.01.C1P1'

            for lbl, subtyp in ((fts_lbl, 'FTS'), (ss_lbl, 'SS')):
                feat = QgsFeature(fts_lyr.fields())
                feat.setGeometry(QgsGeometry.fromPointXY(pt))
                _sa(feat, 'label',     lbl)
                _sa(feat, 'name',      lbl)
                _sa(feat, 'type',      'Splitter')
                _sa(feat, 'subtyp',    f'Splitter (Bare) — {subtyp}')
                _sa(feat, 'spec',      'SM/G657A1')
                _sa(feat, 'dim1',      'L60*W7*H4mm')
                _sa(feat, 'dim2',      '1m')
                _sa(feat, 'cblcpty',   '1:16F')
                _sa(feat, 'stackref',  SR)
                _sa(feat, 'stack',     SR)
                _sa(feat, 'cmpownr',   'VelocityFibre')
                _sa(feat, 'crtdby',    creator)
                _sa(feat, 'datecrtd',  today)
                _sa(feat, 'lat',       round(pt.y(), 10))
                _sa(feat, 'lon',       round(pt.x(), 10))
                new_feats.append(feat)
            fts_num += 1

        if not new_feats:
            self._push_message(
                f'All {skipped} AGG domes already have FTS splitters — nothing to add.', 'info'
            )
            return

        fts_lyr.dataProvider().addFeatures(new_feats)
        fts_lyr.updateExtents()
        fts_lyr.triggerRepaint()
        self._push_message(
            f'Done — placed FTS + SS at {len(new_feats)//2} AGG dome(s)'
            f'{f" ({skipped} already covered, skipped)" if skipped else ""}.',
            'success'
        )

    # ── AUTO STS SPLITTERS AT DIS DOMES ──────────────────────────────────────

    def run_auto_sts(self):
        """Place STS splitters at every DIS dome that does not already have one."""
        from qgis.PyQt.QtWidgets import QInputDialog
        import datetime as _dt

        detected = self._detect_sr_code()
        sr, ok = QInputDialog.getText(
            self.iface.mainWindow(), 'Auto STS',
            'Area code (SR):', text=detected
        )
        if not ok or not sr.strip():
            return
        SR = sr.strip().upper()

        dis_lyr = self._find_layer(['enclosure', 'connectoris']) or self._find_layer(['dis', 'dome'])
        sts_lyr = self._find_layer(['sts'])

        if not dis_lyr or dis_lyr.featureCount() == 0:
            QMessageBox.critical(None, 'Error',
                'No DIS Domes (Enclosures Connectorised) found.\nPlace DIS domes first.')
            return
        if not sts_lyr:
            QMessageBox.critical(None, 'Error',
                'No STS Splitters layer found. Run "New Project" first.')
            return

        # Spatial index of existing STS
        sts_index = QgsSpatialIndex()
        for f in sts_lyr.getFeatures():
            if f.geometry() and not f.geometry().isNull():
                sts_index.addFeature(f)

        snap_r  = 0.00002
        today   = _dt.date.today().isoformat()
        creator = QgsApplication.userFullName().strip() or os.getenv('USERNAME', '') or 'VelocityFibre'

        dis_label_field = None
        for fn in ('label', 'label_1', 'name', 'Name', 'Label'):
            if dis_lyr.fields().indexOf(fn) != -1:
                dis_label_field = fn
                break

        used_sts = set()
        for f in sts_lyr.getFeatures():
            for fn in ('label', 'label_1', 'name'):
                if sts_lyr.fields().indexOf(fn) != -1:
                    lbl = f[fn]
                    if lbl and f'{SR}.STS.' in str(lbl):
                        try:
                            used_sts.add(int(str(lbl).split('.C')[-1].split('-')[0]))
                        except Exception:
                            pass
                    break
        sts_num = max(used_sts, default=0) + 1

        def _sa(feat, fname, val):
            idx = feat.fields().indexOf(fname)
            if idx != -1:
                feat.setAttribute(idx, val)

        new_feats = []
        skipped   = 0
        for dis in dis_lyr.getFeatures():
            geom = dis.geometry()
            if not geom or geom.isNull():
                continue
            pt = geom.asPoint()
            rect = QgsRectangle(pt.x()-snap_r, pt.y()-snap_r, pt.x()+snap_r, pt.y()+snap_r)
            if sts_index.intersects(rect):
                skipped += 1
                continue

            dis_lbl = str(dis[dis_label_field]) if dis_label_field else f'P.C{sts_num:03d}'
            dis_ref = dis_lbl.split('.')[-1] if dis_label_field else f'C{sts_num:03d}'

            lbl = f'{SR}.STS.8.DIS.DM.P.{dis_ref}-OLT.01.C1P1.L1'
            feat = QgsFeature(sts_lyr.fields())
            feat.setGeometry(QgsGeometry.fromPointXY(pt))
            _sa(feat, 'label',     lbl)
            _sa(feat, 'name',      lbl)
            _sa(feat, 'type',      'Splitter')
            _sa(feat, 'subtyp',    'Splitter (Connectorised)')
            _sa(feat, 'spec',      'SM/G657A1')
            _sa(feat, 'dim1',      'L60*W7*H4mm')
            _sa(feat, 'dim2',      '1m')
            _sa(feat, 'cblcpty',   '1:8F')
            _sa(feat, 'conntr',    'LC/APC')
            _sa(feat, 'stackref',  SR)
            _sa(feat, 'stack',     SR)
            _sa(feat, 'cmpownr',   'VelocityFibre')
            _sa(feat, 'crtdby',    creator)
            _sa(feat, 'datecrtd',  today)
            _sa(feat, 'lat',       round(pt.y(), 10))
            _sa(feat, 'lon',       round(pt.x(), 10))
            new_feats.append(feat)
            sts_num += 1

        if not new_feats:
            self._push_message(
                f'All {skipped} DIS domes already have STS splitters — nothing to add.', 'info'
            )
            return

        sts_lyr.dataProvider().addFeatures(new_feats)
        sts_lyr.updateExtents()
        sts_lyr.triggerRepaint()
        self._push_message(
            f'Done — placed STS at {len(new_feats)} DIS dome(s)'
            f'{f" ({skipped} already covered, skipped)" if skipped else ""}.',
            'success'
        )

    # ── QUICK DISTRIBUTION CABLE ──────────────────────────────────────────────

    def run_quick_dist_cable(self):
        detected = self._detect_sr_code()
        from qgis.PyQt.QtWidgets import QInputDialog
        sr, ok = QInputDialog.getText(
            self.iface.mainWindow(), 'Quick Distribution Cable', 'Area code (SR):', text=detected
        )
        if not ok or not sr.strip():
            return
        self._qdist_sr = sr.strip().upper()
        self._qdist_first_pt = None

        # Build pole index
        self._qdist_pole_index = None
        self._qdist_poles_feats = {}
        poles_layer = self._find_layer(['pole'])
        if poles_layer:
            idx = QgsSpatialIndex()
            for f in poles_layer.getFeatures():
                if f.geometry() and not f.geometry().isNull():
                    idx.addFeature(f)
                    self._qdist_poles_feats[f.id()] = f
            self._qdist_pole_index = idx

        tool = ClickMapTool(
            self.iface.mapCanvas(), self._on_qdist_click,
            icon_color='#00ffff', multi=True
        )
        self.iface.mapCanvas().setMapTool(tool)
        self._push_message('Click start pole, then end pole to draw distribution cable.', 'info')

    def _snap_to_pole(self, pt, index, feats):
        snap_r = 30.0 / 99000.0
        rect = QgsRectangle(pt.x()-snap_r, pt.y()-snap_r, pt.x()+snap_r, pt.y()+snap_r)
        nearby = index.intersects(rect) if index else []
        if nearby:
            best = min(nearby, key=lambda fid: feats[fid].geometry().distance(QgsGeometry.fromPointXY(pt)))
            f = feats[best]
            # Try common pole name field variants
            lbl = ''
            for fname in ('Name.', 'name.', 'Name', 'name', 'Label', 'label', 'id'):
                try:
                    v = f[fname]
                    if v and str(v).strip():
                        lbl = str(v).strip()
                        break
                except (KeyError, Exception):
                    pass
            return f.geometry().asPoint(), lbl
        return pt, ''

    def _on_qdist_click(self, pt):
        snap_pt, pole_lbl = self._snap_to_pole(pt, self._qdist_pole_index, self._qdist_poles_feats)
        if self._qdist_first_pt is None:
            self._qdist_first_pt = (snap_pt, pole_lbl)
            self._push_message(f'Start pole: {pole_lbl}. Now click end pole.', 'info')
            return

        start_pt, start_lbl = self._qdist_first_pt
        end_pt,   end_lbl   = snap_pt, pole_lbl
        self._qdist_first_pt = None

        dist_layer = self._find_layer(['distribution', 'cable'], exclude=['spare', 'drop', 'secondary', 'primary'])
        if not dist_layer:
            self._push_message('Distribution Cable layer not found.', 'warning')
            return

        import datetime as _dt
        today   = _dt.date.today().isoformat()
        creator = QgsApplication.userFullName().strip() or os.getenv('USERNAME', '') or 'VelocityFibre'
        SR      = self._qdist_sr

        def _sa(feat, fname, val):
            idx = feat.fields().indexOf(fname)
            if idx != -1:
                feat.setAttribute(idx, val)

        lbl = f'{SR}.DF.24F.{start_lbl.split(".")[-1] if start_lbl else "P.A001"}-{end_lbl.split(".")[-1] if end_lbl else "P.A002"}'
        feat = QgsFeature(dist_layer.fields())
        feat.setGeometry(QgsGeometry.fromPolylineXY([start_pt, end_pt]))
        _sa(feat, 'label',      lbl)
        _sa(feat, 'name',       lbl)
        _sa(feat, 'type',       'Distribution Cable')
        _sa(feat, 'spec',       'Mini-ADSS')
        _sa(feat, 'cblcpty',    '24F')
        _sa(feat, 'cmpownr',    'VelocityFibre')
        _sa(feat, 'companyown', 'VelocityFibre')
        _sa(feat, 'stackref',   SR)
        _sa(feat, 'stack',      SR)
        _sa(feat, 'crtdby',     creator)
        _sa(feat, 'createdby',  creator)
        _sa(feat, 'datecrtd',   today)

        was_editing = dist_layer.isEditable()
        if not was_editing:
            dist_layer.startEditing()
        dist_layer.dataProvider().addFeatures([feat])
        dist_layer.commitChanges()
        dist_layer.triggerRepaint()
        if was_editing:
            dist_layer.startEditing()
        self._push_message(f'Distribution cable created: {lbl}', 'info')

    # ── AUTO DROP GENERATOR ───────────────────────────────────────────────────

    def run_auto_drops(self):
        from qgis.PyQt.QtWidgets import QInputDialog
        detected = self._detect_sr_code()
        sr, ok = QInputDialog.getText(
            self.iface.mainWindow(), 'Auto Drop Generator', 'Area code (SR):', text=detected
        )
        if not ok or not sr.strip():
            return
        SR = sr.strip().upper()

        sts_layer  = self._find_layer(['sts']) or self._find_layer(['splitter'], exclude=['fts'])
        hc_layer   = self._find_layer(['home', 'connect'])
        drop_layer = self._find_layer(['drop', 'cable'], exclude=['spare'])

        if not sts_layer:
            self._push_message('STS layer not found.', 'warning'); return
        if not hc_layer:
            self._push_message('Home Connections layer not found.', 'warning'); return
        if not drop_layer:
            self._push_message('Drop Cable layer not found.', 'warning'); return
        self._backup_layer(drop_layer)

        MAX_DROPS   = 8
        MAX_DIST_DEG = 60.0 / 99000.0  # ~60m in degrees

        import datetime as _dt
        today   = _dt.date.today().isoformat()
        creator = QgsApplication.userFullName().strip() or os.getenv('USERNAME', '') or 'VelocityFibre'

        # Build spatial index of home connections
        hc_index = QgsSpatialIndex()
        hc_feats = {}
        for f in hc_layer.getFeatures():
            if f.geometry() and not f.geometry().isNull():
                hc_index.insertFeature(f)
                hc_feats[f.id()] = f

        # Find which HCs already have a drop
        connected_hc_ids = set()
        for d in drop_layer.getFeatures():
            g = d.geometry()
            if not g or g.isNull():
                continue
            end_pt = g.asPolyline()[-1] if not g.isMultipart() else g.asMultiPolyline()[-1][-1]
            rect = QgsRectangle(end_pt.x()-0.0001, end_pt.y()-0.0001,
                                end_pt.x()+0.0001, end_pt.y()+0.0001)
            for fid in hc_index.intersects(rect):
                connected_hc_ids.add(fid)

        # Get max existing DR number
        max_dr = 0
        for d in drop_layer.getFeatures():
            lbl = (d['label'] if d.fields().indexOf('label') != -1 else None) or \
                  (d['name']  if d.fields().indexOf('name')  != -1 else None) or ''
            m = re.search(r'DR(\d+)', str(lbl))
            if m:
                max_dr = max(max_dr, int(m.group(1)))

        new_drops = []
        dr_counter = max_dr

        def _sa(feat, fname, val):
            idx = feat.fields().indexOf(fname)
            if idx != -1:
                feat.setAttribute(idx, val)

        for sts_f in sts_layer.getFeatures():
            sts_g = sts_f.geometry()
            if not sts_g or sts_g.isNull():
                continue
            sts_pt = sts_g.asPoint()

            # Count existing drops already connected to this STS
            rect = QgsRectangle(sts_pt.x()-MAX_DIST_DEG, sts_pt.y()-MAX_DIST_DEG,
                                sts_pt.x()+MAX_DIST_DEG, sts_pt.y()+MAX_DIST_DEG)
            existing_drops = 0
            for d in drop_layer.getFeatures(QgsRectangle(sts_pt.x()-0.001, sts_pt.y()-0.001,
                                                          sts_pt.x()+0.001, sts_pt.y()+0.001)):
                g = d.geometry()
                if g and not g.isNull():
                    existing_drops += 1
            slots = MAX_DROPS - existing_drops
            if slots <= 0:
                continue

            # Find nearest unconnected HCs within range
            nearby_hc = hc_index.intersects(rect)
            candidates = []
            for fid in nearby_hc:
                if fid in connected_hc_ids:
                    continue
                hc_pt = hc_feats[fid].geometry().asPoint()
                dist = sts_g.distance(QgsGeometry.fromPointXY(hc_pt))
                if dist <= MAX_DIST_DEG:
                    candidates.append((dist, fid, hc_pt))
            candidates.sort()

            for dist, hc_fid, hc_pt in candidates[:slots]:
                dr_counter += 1
                dr_lbl = f'DR{dr_counter:07d}'
                feat = QgsFeature(drop_layer.fields())
                feat.setGeometry(QgsGeometry.fromPolylineXY([sts_pt, hc_pt]))
                _sa(feat, 'label',      dr_lbl)
                _sa(feat, 'name',       dr_lbl)
                _sa(feat, 'type',       'Drop Cable')
                _sa(feat, 'spec',       'SM/G657A2')
                _sa(feat, 'cblcpty',    '1F')
                _sa(feat, 'conntr',     'LC/APC-SC/APC')
                _sa(feat, 'cmpownr',    'VelocityFibre')
                _sa(feat, 'companyown', 'VelocityFibre')
                _sa(feat, 'stackref',   SR)
                _sa(feat, 'stack',      SR)
                _sa(feat, 'crtdby',     creator)
                _sa(feat, 'createdby',  creator)
                _sa(feat, 'datecrtd',   today)
                new_drops.append(feat)
                connected_hc_ids.add(hc_fid)

        if not new_drops:
            self._push_message('No new drops to create — all STS domes are full or no nearby homes.', 'info')
            return

        was_editing = drop_layer.isEditable()
        if not was_editing:
            drop_layer.startEditing()
        drop_layer.dataProvider().addFeatures(new_drops)
        drop_layer.commitChanges()
        drop_layer.triggerRepaint()
        if was_editing:
            drop_layer.startEditing()
        self._push_message(f'Auto Drops: created {len(new_drops)} drop cables (DR{max_dr+1:07d} – DR{dr_counter:07d}).', 'info')

    def _push_message(self, msg, level='info'):
        """Push a message to the QGIS message bar."""
        from qgis.core import Qgis
        lvl_map = {'info': Qgis.Info, 'warning': Qgis.Warning, 'error': Qgis.Critical, 'critical': Qgis.Critical}
        self.iface.messageBar().pushMessage('Fibertime', msg, level=lvl_map.get(level, Qgis.Info), duration=5)
        QApplication.processEvents()

    # ── BACKUP ─────────────────────────────────────────────────────────────

    def _backup_layer(self, layer):
        """Copy all shapefile/gpkg components to a _BACKUP folder before first write.
        Only runs once per layer per plugin session. Returns True if backup succeeded."""
        import shutil, glob
        if not layer:
            return True
        lid = layer.id()
        if lid in self._backed_up_layers:
            return True   # already backed up this session
        src = layer.dataProvider().dataSourceUri().split('|')[0].strip()
        if not os.path.exists(src):
            return True   # memory layer or non-file source — skip
        backup_dir = os.path.join(os.path.dirname(src), '_BACKUP')
        os.makedirs(backup_dir, exist_ok=True)
        try:
            if src.lower().endswith('.gpkg'):
                shutil.copy2(src, backup_dir)
            else:
                base = os.path.splitext(src)[0]
                for f in glob.glob(base + '.*'):
                    shutil.copy2(f, backup_dir)
            self._backed_up_layers.add(lid)
            return True
        except Exception as e:
            self._push_message(f'Backup failed for {layer.name()}: {e}', 'warning')
            return False

    def _safe_write(self, layer, features):
        """Backup then write features. Returns True on success."""
        if not self._backup_layer(layer):
            return False
        was_editing = layer.isEditable()
        if not was_editing:
            layer.startEditing()
        ok, _ = layer.dataProvider().addFeatures(features)
        layer.commitChanges()
        layer.triggerRepaint()
        if was_editing:
            layer.startEditing()
        return ok

    # ── NON-SPATIAL BOM GENERATOR ─────────────────────────────────────────

    def run_bom_generator(self):
        """Calculate hooks, dead-ends, tangents, slack brackets per pole from network topology."""
        from qgis.core import QgsDistanceArea, QgsCoordinateTransformContext
        import csv, math

        pole_layer  = self._find_layer(['pole'])
        cable_layers = [l for l in [
            self._find_layer(['primary', 'cable']) or self._find_layer(['primary', 'feeder']),
            self._find_layer(['secondary', 'cable']) or self._find_layer(['secondary', 'feeder']),
            self._find_layer(['distribution', 'cable']),
            self._find_layer(['drop', 'cable'], exclude=['spare']),
        ] if l]
        enc_splice = self._find_layer(['enclosure', 'splice']) or self._find_layer(['enclosures', 'splice'])

        if not pole_layer:
            self._push_message('Poles layer not found.', 'warning'); return
        if not cable_layers:
            self._push_message('No cable layers found.', 'warning'); return

        SNAP_M = 8.0 / 99000.0   # ~8m in degrees
        ANGLE_THRESHOLD = 15.0   # degrees — corner if change > this

        da = QgsDistanceArea()
        da.setEllipsoid('WGS84')
        da.setSourceCrs(pole_layer.crs(), QgsCoordinateTransformContext())

        # Index splice enclosures (= slack bracket locations)
        splice_pts = set()
        if enc_splice:
            for f in enc_splice.getFeatures():
                g = f.geometry()
                if g and not g.isNull():
                    pt = g.asPoint()
                    splice_pts.add((round(pt.x(), 5), round(pt.y(), 5)))

        # For each cable, collect (pole_pt, prev_bearing, next_bearing) per pole hit
        # Map pole coordinate → list of cable directions at that pole
        pole_dirs = {}   # {(rx, ry): [bearing_in, bearing_out, ...]}

        for cable_lyr in cable_layers:
            for feat in cable_lyr.getFeatures():
                g = feat.geometry()
                if not g or g.isNull(): continue
                if g.isMultipart():
                    parts = g.asMultiPolyline()
                else:
                    parts = [g.asPolyline()]
                for part in parts:
                    if len(part) < 2: continue
                    # Find which vertices snap to poles using QgsSpatialIndex
                    for i, pt in enumerate(part):
                        rx, ry = round(pt.x(), 5), round(pt.y(), 5)
                        # Compute bearing from previous vertex and to next vertex
                        dirs = []
                        if i > 0:
                            prev = part[i-1]
                            dx, dy = pt.x()-prev.x(), pt.y()-prev.y()
                            dirs.append(math.degrees(math.atan2(dx, dy)) % 360)
                        if i < len(part) - 1:
                            nxt = part[i+1]
                            dx, dy = nxt.x()-pt.x(), nxt.y()-pt.y()
                            dirs.append(math.degrees(math.atan2(dx, dy)) % 360)
                        if dirs:
                            key = (rx, ry)
                            if key not in pole_dirs:
                                pole_dirs[key] = []
                            pole_dirs[key].extend(dirs)

        # Now classify each pole
        rows = []
        for feat in pole_layer.getFeatures():
            g = feat.geometry()
            if not g or g.isNull(): continue
            pt = g.asPoint()
            key = (round(pt.x(), 5), round(pt.y(), 5))

            pole_lbl = ''
            for fn in ('Name.', 'Name', 'name', 'label', 'Label'):
                try:
                    v = feat[fn]
                    if v and str(v).strip(): pole_lbl = str(v).strip(); break
                except: pass

            dirs = pole_dirs.get(key, [])
            n_cables = len(dirs)
            is_splice = key in splice_pts

            # Deduplicate similar directions (cables going same way)
            unique_dirs = []
            for d in sorted(dirs):
                if all(min((d - u) % 360, (u - d) % 360) > 10 for u in unique_dirs):
                    unique_dirs.append(d)

            n_dir = len(unique_dirs)

            # Classify
            if n_dir == 0:
                # Isolated pole — no cables
                hook_type   = 'None'
                dead_ends   = 0
                tangents    = 0
                slack_bracket = 'No'
            elif n_dir == 1:
                # End of run
                hook_type   = '1-Way Offset'
                dead_ends   = 1
                tangents    = 0
                slack_bracket = 'Yes' if is_splice else 'No'
            elif n_dir == 2:
                # Check if it's a corner or through
                a, b = sorted(unique_dirs)[:2]
                diff = min((b - a) % 360, (a - b) % 360)
                if diff > ANGLE_THRESHOLD:
                    hook_type = '2-Way Offset'
                    dead_ends = 2
                    tangents  = 0
                else:
                    hook_type = '2-Way Offset'
                    dead_ends = 0
                    tangents  = 1
                slack_bracket = 'Yes' if is_splice else 'No'
            else:
                # Junction / 3+ directions
                hook_type   = '3-Way Offset'
                dead_ends   = 1
                tangents    = 0
                slack_bracket = 'Yes' if is_splice else 'No'

            rows.append({
                'pole':          pole_lbl or f'(id={feat.id()})',
                'cable_dirs':    n_dir,
                'hook_type':     hook_type,
                'dead_ends':     dead_ends,
                'tangents':      tangents,
                'slack_bracket': slack_bracket,
                'pigtail_screws': 1 if n_dir > 0 else 0,
            })

        if not rows:
            self._push_message('No poles with cable connections found.', 'warning'); return

        # Summary totals
        total_hooks    = len([r for r in rows if r['hook_type'] != 'None'])
        total_de       = sum(r['dead_ends'] for r in rows)
        total_tang     = sum(r['tangents'] for r in rows)
        total_slack    = sum(1 for r in rows if r['slack_bracket'] == 'Yes')
        total_pigtail  = sum(r['pigtail_screws'] for r in rows)

        # Save CSV
        path, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 'Save BOM Table', '', 'CSV Files (*.csv)'
        )
        if not path:
            return
        with open(path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
            # Totals row
            writer.writerow({
                'pole': '=== TOTALS ===',
                'cable_dirs': '',
                'hook_type': f'{total_hooks} poles with hooks',
                'dead_ends': total_de,
                'tangents': total_tang,
                'slack_bracket': f'{total_slack} brackets',
                'pigtail_screws': total_pigtail,
            })

        self._push_message(
            f'BOM saved: {total_de} dead-ends | {total_tang} tangents | '
            f'{total_slack} slack brackets | {total_pigtail} pigtail screws', 'info'
        )

    # ── OES CSV EXPORT ────────────────────────────────────────────────────

    def run_oes_export(self):
        """Export OES (ONT Easy Start) CSV for ONT provisioning."""
        from qgis.PyQt.QtWidgets import QInputDialog
        import csv, re

        drop_layer = self._find_layer(['drop', 'cable'], exclude=['spare'])
        if not drop_layer:
            self._push_message('Drop Cable layer not found.', 'warning'); return

        detected = self._detect_sr_code()

        # Gather inputs via simple dialogs
        sr, ok = QInputDialog.getText(self.iface.mainWindow(), 'OES Export', 'Area code (SR):', text=detected)
        if not ok: return
        SR = sr.strip().upper()

        start_code, ok = QInputDialog.getInt(
            self.iface.mainWindow(), 'OES Export',
            'Starting activation code number:', value=1, min=1
        )
        if not ok: return

        rx_olt, ok = QInputDialog.getText(
            self.iface.mainWindow(), 'OES Export',
            'Link budget OLT RX (e.g. -27.2):', text='-27.2'
        )
        if not ok: return

        rx_ont, ok = QInputDialog.getText(
            self.iface.mainWindow(), 'OES Export',
            'Link budget ONT RX (e.g. -23.4):', text='-23.4'
        )
        if not ok: return

        path, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 'Save OES CSV', f'{SR}_OES.csv', 'CSV Files (*.csv)'
        )
        if not path: return

        # Collect DR numbers from drop layer
        dr_entries = []
        for f in drop_layer.getFeatures():
            lbl = ''
            for fn in ('label', 'Label', 'name', 'Name'):
                try:
                    v = f[fn]
                    if v and str(v).strip(): lbl = str(v).strip(); break
                except: pass
            m = re.search(r'DR(\d+)', lbl)
            if m:
                dr_entries.append((int(m.group(1)), lbl))
        dr_entries.sort()

        if not dr_entries:
            self._push_message('No DR-labelled drop cables found.', 'warning'); return

        # Write OES CSV
        fields = ['UUID', 'password', 'olt_address', 'apc_template_name',
                  'apc_arguments', 'service_name', 'info',
                  'linkbudget_oltrx', 'linkbudget_ontrx']

        with open(path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for i, (dr_num, dr_lbl) in enumerate(dr_entries):
                # Strip "DR" prefix for UUID (Fibre Time uses just the number string)
                uuid_val = f'DR{dr_num:06d}'
                writer.writerow({
                    'UUID':                uuid_val,
                    'password':            '',
                    'olt_address':         '-',
                    'apc_template_name':   '["Final_L2_Service_Template"]',
                    'apc_arguments':       '{}',
                    'service_name':        'Final_L2_Service_Template',
                    'info':                str(start_code + i),
                    'linkbudget_oltrx':    rx_olt.strip(),
                    'linkbudget_ontrx':    rx_ont.strip(),
                })

        self._push_message(
            f'OES exported: {len(dr_entries)} ONTs → {path}', 'info'
        )
