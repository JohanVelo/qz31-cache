"""Vuma Step 4 — Generate PON aggregation zones from demand points.

STATUS: [x] BUILT
"""

# claude:approved-destructive

import math

import processing

from qgis.core import (
    QgsFeature,
    QgsProject,
    QgsSingleSymbolRenderer,
    QgsSpatialIndex,
    QgsSymbol,
)
from qgis.PyQt.QtGui import QColor


MAX_SDU_PER_PON = 48

# Fill factor: fraction of grid cells expected to contain demand points.
# At 0.65 the grid is slightly denser than strictly needed, so edge cells
# that get clipped still contribute meaningful coverage.
_FILL_FACTOR = 0.65


def _get(name):
    layers = QgsProject.instance().mapLayersByName(name)
    return layers[0] if layers else None


def _apply_zone_symbology(layer):
    """Transparent fill, coloured border so underlying layers stay visible."""
    symbol = QgsSymbol.defaultSymbol(layer.geometryType())
    sl = symbol.symbolLayer(0)
    sl.setFillColor(QColor(0, 0, 0, 0))
    sl.setStrokeColor(QColor(255, 165, 0))
    sl.setStrokeWidth(0.5)
    layer.setRenderer(QgsSingleSymbolRenderer(symbol))
    layer.triggerRepaint()


def vuma_step_04_pon():
    """Partition demand points into rectangular PON zones.

    STATUS: [x] BUILT
    Safe to re-run — clears and repopulates the Aggregation Polygon layer.

    Method:
      1. Calculate a rectangular grid cell size so the expected homes per cell
         ≈ MAX_SDU_PER_PON (Vuma Key Config 5: 3 × 1:16 DJ = 48 homes/AG).
      2. Create grid over the AOI, clip to AOI boundary.
      3. Remove empty cells; label survivors PON001…PONnnn.
    """
    print(f"\n{'═' * 50}")
    print("  VUMA STEP 4 — PON Zones")
    print(f"{'═' * 50}")

    dp_layer  = _get("Demand Points")
    agg_layer = _get("Aggregation Polygon")
    aoi_layer = _get("P2 AOI Poly")

    if dp_layer is None:
        print("  ✗ 'Demand Points' layer not found — run Step 3 first.")
        return
    if agg_layer is None:
        print("  ✗ 'Aggregation Polygon' layer not found — run Step 1 first.")
        return
    if aoi_layer is None or aoi_layer.featureCount() == 0:
        print("  ✗ 'P2 AOI Poly' layer missing or empty.")
        return
    if dp_layer.featureCount() == 0:
        print("  ✗ No demand points found — run Step 3 first.")
        return

    dp_feats = [
        f for f in dp_layer.getFeatures()
        if f.hasGeometry() and not f.geometry().isEmpty()
    ]
    if not dp_feats:
        print("  ✗ No valid demand point geometries.")
        return

    n_dp = len(dp_feats)
    type_idx = dp_layer.fields().indexOf("Type")

    # ── Step 1: Calculate cell size ──────────────────────────────────────────
    ext = aoi_layer.extent()
    lat_mid = (ext.yMinimum() + ext.yMaximum()) / 2

    # Metres per degree at this latitude
    m_per_deg_lon = math.cos(math.radians(abs(lat_mid))) * 111_320
    m_per_deg_lat = 111_320

    aoi_w_m = ext.width()  * m_per_deg_lon
    aoi_h_m = ext.height() * m_per_deg_lat

    # Number of grid cells needed (allow for cells clipped away at the edge)
    n_cells_target = math.ceil(n_dp / MAX_SDU_PER_PON) / _FILL_FACTOR
    cell_side_m    = math.sqrt(aoi_w_m * aoi_h_m / n_cells_target)

    cell_w_deg = cell_side_m / m_per_deg_lon
    cell_h_deg = cell_side_m / m_per_deg_lat

    print(f"  {n_dp:,} demand points → ~{math.ceil(n_dp/MAX_SDU_PER_PON)} zones")
    print(f"  Grid cell: {cell_side_m:.0f} m × {cell_side_m:.0f} m")

    # ── Step 2: Create rectangular grid ──────────────────────────────────────
    grid_result = processing.run("native:creategrid", {
        "TYPE":      2,          # Rectangle (polygon)
        "EXTENT":    ext,
        "HSPACING":  cell_w_deg,
        "VSPACING":  cell_h_deg,
        "HOVERLAY":  0,
        "VOVERLAY":  0,
        "CRS":       agg_layer.crs(),
        "OUTPUT":    "memory:",
    })

    # Clip to AOI so edge cells follow the AOI boundary
    clip_result = processing.run("native:clip", {
        "INPUT":   grid_result["OUTPUT"],
        "OVERLAY": aoi_layer,
        "OUTPUT":  "memory:",
    })
    clipped_lyr = clip_result["OUTPUT"]

    # ── Step 3: Count demand points per cell ─────────────────────────────────
    dp_index  = QgsSpatialIndex()
    dp_fid_map = {}
    for feat in dp_feats:
        dp_index.insertFeature(feat)
        dp_fid_map[feat.id()] = feat

    agg_fields = agg_layer.fields()
    desc_idx   = agg_fields.indexOf("Discriptio")
    label_idx  = agg_fields.indexOf("Label.")

    new_features = []
    zone_num     = 1
    over_cap     = 0

    for cell_feat in clipped_lyr.getFeatures():
        cell_geom = cell_feat.geometry()
        if cell_geom is None or cell_geom.isEmpty():
            continue

        candidate_fids = dp_index.intersects(cell_geom.boundingBox())
        inside = [
            dp_fid_map[fid] for fid in candidate_fids
            if cell_geom.contains(dp_fid_map[fid].geometry())
        ]
        if not inside:
            continue

        sdu_n = sum(1 for f in inside if str(f[type_idx] or "SDU") != "MDU")
        mdu_n = len(inside) - sdu_n
        total = sdu_n + mdu_n * 3   # MDU counts as 3 SDU equivalents
        if total > MAX_SDU_PER_PON:
            over_cap += 1

        pon_label = f"PON{zone_num:03d}"
        nf = QgsFeature(agg_layer.fields())
        nf.setGeometry(cell_geom)
        if desc_idx >= 0:
            nf.setAttribute(desc_idx, f"{pon_label} | {sdu_n}xSDU {mdu_n}xMDU")
        if label_idx >= 0:
            nf.setAttribute(label_idx, pon_label)
        new_features.append(nf)
        zone_num += 1

    # ── Step 4: Write to layer ───────────────────────────────────────────────
    # claude:approved-destructive — clears Aggregation Polygon before repopulating
    agg_layer.dataProvider().truncate()
    if new_features:
        agg_layer.dataProvider().addFeatures(new_features)

    _apply_zone_symbology(agg_layer)
    agg_layer.triggerRepaint()

    print("\n  ══ PON ZONES ══")
    print(f"  Rectangular zones created: {len(new_features)}")
    if over_cap:
        print(f"  ⚠  {over_cap} zones exceed {MAX_SDU_PER_PON} cap — consider reducing cell size")
    else:
        print(f"  ✓ All zones within {MAX_SDU_PER_PON}-home capacity")
    print(f"{'═' * 50}\n")
