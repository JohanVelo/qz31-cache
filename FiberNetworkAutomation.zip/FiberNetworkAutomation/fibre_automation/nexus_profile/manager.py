"""manager — the single entry point the plugin talks to.

One NexusManager per plugin instance. It owns the Backend, the current
Profile, the Telemetry singleton, and lazily opens the profile card / first-run
dialog / Team Monitor. The plugin calls:
    mgr = NexusManager(iface); mgr.start()
    mgr.wrap(action_id, fn)          # choke-point telemetry on every tool
    mgr.report_error(where, exc, note)
    mgr.open_profile_card(anchor)    # from the header chip
    mgr.open_team_monitor()          # JJ only
    mgr.unload()
Everything is fail-silent and dry-run-safe.
"""
from . import admin as admin_mod
from . import backend as backend_mod
from . import config, themes
from . import profile as profile_mod
from . import telemetry as telemetry_mod


def _data_dir():
    try:
        from ..shared.vf_paths import data_dir
        return data_dir()
    except Exception:
        import tempfile
        return tempfile.gettempdir()


def _versions():
    qv = "?"
    try:
        from qgis.core import Qgis
        qv = Qgis.QGIS_VERSION
    except Exception:
        pass
    return qv, backend_mod._plugin_version()


class NexusManager:
    def __init__(self, iface):
        self.iface = iface
        self.backend = backend_mod.Backend(_data_dir())
        self.profile = None
        self.telemetry = None
        self._card = None
        self._monitor = None
        self.qgis_version, self.plugin_version = _versions()
        self.on_theme_changed = None     # plugin sets this to re-skin the panel

    # ── startup ─────────────────────────────────────────────────────────────
    def start(self):
        """Load the signed-in profile or run first-run. Returns True if a
        profile is active (plugin can proceed), False if the user cancelled."""
        try:
            self.profile = profile_mod.Profile.load_local()
            if self.profile is None:
                if not self._first_run():
                    return False
            self._start_telemetry()
            return True
        except Exception:
            return True       # never block plugin load on a profile hiccup

    def _first_run(self):
        try:
            from .first_run import FirstRunDialog
            pre_trusted = self._was_activated_before()
            dlg = FirstRunDialog(self.iface, self.backend,
                                 qgis_version=self.qgis_version,
                                 plugin_version=self.plugin_version,
                                 pre_trusted=pre_trusted)
            if dlg.exec() and dlg.profile is not None:
                self.profile = dlg.profile
                return True
            return False
        except Exception:
            return False

    def _was_activated_before(self):
        """A machine already activated with the old shared password is trusted
        — skip the team-code field on migration."""
        try:
            from qgis.core import QgsSettings
            s = QgsSettings()
            # old activation token under the same namespace
            return bool(s.value(f"{config.SETTINGS_NS}/activated")
                        or s.value(f"{config.SETTINGS_NS}/activationToken"))
        except Exception:
            return False

    def _start_telemetry(self):
        if self.profile is None:
            return
        self.telemetry = telemetry_mod.Telemetry(
            self.iface, self.backend, self.profile, _data_dir(),
            qgis_version=self.qgis_version, plugin_version=self.plugin_version)
        try:
            self.telemetry.start()
        except Exception:
            pass

    # ── choke-point telemetry ───────────────────────────────────────────────
    def wrap(self, action_id, fn, category="tool"):
        """Wrap a zero-arg callback so it records an event before running."""
        def inner(*a, **k):
            try:
                if self.telemetry is not None:
                    self.telemetry.record_action(action_id, category)
            except Exception:
                pass
            return fn()
        return inner

    def report_error(self, where, exc, note=None):
        try:
            if self.telemetry is not None:
                self.telemetry.record_error(where, exc, user_note=note)
        except Exception:
            pass

    # ── UI surfaces ─────────────────────────────────────────────────────────
    def signed_in_name(self):
        return self.profile.display_name if self.profile else None

    def avatar_color(self):
        return themes.avatar_color(self.profile.username) if self.profile \
            else "#3B6FE0"

    def current_accent(self):
        if not self.profile:
            return None
        if self.profile.accent:
            return self.profile.accent
        preset = themes.PRESETS.get(self.profile.theme)
        return preset["accent"] if preset else None

    def open_profile_card(self, anchor=None):
        if self.profile is None:
            return
        try:
            from .profile_card import ProfileCard
            self._card = ProfileCard(
                self.iface, self.profile, plugin_version=self.plugin_version,
                on_theme=self._apply_theme,
                on_sign_out=self._sign_out,
                on_my_data=self._show_my_data)
            if anchor is not None:
                from qgis.PyQt.QtCore import QPoint
                self._card.move(anchor.mapToGlobal(QPoint(0, anchor.height())))
            self._card.show()
            self._card.raise_()
        except Exception:
            pass

    def _apply_theme(self, theme_name, accent_hex):
        if callable(self.on_theme_changed):
            try:
                self.on_theme_changed(theme_name, accent_hex)
            except Exception:
                pass

    def _sign_out(self):
        profile_mod.Profile.sign_out()
        self.profile = None
        if self.telemetry:
            self.telemetry.stop()
            self.telemetry = None
        # re-run first-run / sign-in
        if self._first_run():
            self._start_telemetry()
            self._apply_theme(self.profile.theme, self.current_accent())

    def _show_my_data(self):
        from qgis.PyQt.QtWidgets import QMessageBox
        p = self.profile
        QMessageBox.information(
            self.iface.mainWindow(), "Your data",
            f"Signed in as: {p.display_name} (@{p.username})\n"
            f"Member since: {p.created_at or '—'}\n"
            f"Theme: {p.theme}\n\n"
            "Velocity Nexus stores your name, presence, the tools you run, and "
            "error reports — visible only to the planning office. It never "
            "reads your project files, screen, or keystrokes.")

    # ── Team Monitor (JJ only) ──────────────────────────────────────────────
    def is_admin(self):
        return admin_mod.is_admin(self.profile)

    def open_team_monitor(self):
        if not self.is_admin():
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.information(
                self.iface.mainWindow(), "Team Monitor",
                "The Team Monitor is available to the planning office only.")
            return
        try:
            from qgis.PyQt.QtCore import Qt
            from .team_monitor import TeamMonitorDock
            if self._monitor is not None:
                try:
                    self._monitor.show()
                    self._monitor.raise_()
                    return
                except RuntimeError:
                    self._monitor = None
            self._monitor = TeamMonitorDock(self.iface, self.backend)
            self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self._monitor)
            self._monitor.show()
            self._monitor.raise_()
        except Exception:
            pass

    # ── teardown ────────────────────────────────────────────────────────────
    def unload(self):
        try:
            if self.telemetry:
                self.telemetry.stop()
        except Exception:
            pass
        for w in (self._card, self._monitor):
            try:
                if w is not None:
                    w.close()
                    w.deleteLater()
            except Exception:
                pass
        self._card = self._monitor = None
