"""Name generators for both client naming conventions."""

import math


# ---------------------------------------------------------------------------
# Vuma: AREA_ZONE_TYPE_NUMBER  (underscore separator)
# ---------------------------------------------------------------------------

def vuma_prefix(area_code: str, zone_code: str) -> str:
    """Return base prefix like 'MALM-Z1' from area + zone."""
    z = zone_code.lstrip("Zz") if zone_code else "1"
    return f"{area_code}-Z{z}"


def vuma_name(area_code: str, zone_code: str, layer_type: str, n: int) -> str:
    """Generate a Vuma feature name.

    layer_type: 'AG' | 'DJ' | 'SJ' | 'FJ' | 'P' (pole) | 'FC' | 'DC' | 'SC' | 'LC' | 'MH'
    n: sequential number (1-based)
    """
    prefix = vuma_prefix(area_code, zone_code)
    formats = {
        "AG": f"{prefix}-AG{n:02d}",
        "DJ": f"{prefix}-DJ{n:04d}",
        "SJ": f"{prefix}-SJ{n:04d}",
        "FJ": f"{prefix}-FJ{n:02d}",
        "P":  f"{prefix}-P{n:04d}",
        "FC": f"FC{n:02d}",
        "DC": f"DC{n:03d}",
        "SC": f"SC{n:02d}",
        "LC": f"LC{n:02d}",
        "MH": f"{prefix}-MH{n:04d}",
    }
    if layer_type not in formats:
        raise ValueError(f"Unknown Vuma layer_type: {layer_type!r}")
    return formats[layer_type]


def vuma_cable_name(
    area_code: str,
    zone_code: str,
    cable_type: str,
    cable_no: str,
    fiber_size: str,
    length_m: float,
    from_ref: str = "",
    to_ref: str = "",
) -> str:
    """Generate a Vuma cable Name field value.

    cable_type: 'FC' | 'DC' | 'SC' | 'LC'
    cable_no:   'FC01' | 'DC003' etc.
    fiber_size: '24F' | '96F' etc.
    length_m:   base design length in metres
    """
    sag_len = sag_length(length_m)
    prefix = vuma_prefix(area_code, zone_code)

    if cable_type in ("FC", "LC"):
        from_to = f"_{from_ref}-{to_ref}" if from_ref else ""
        return (
            f"VTN_{area_code}_{prefix}_{cable_no}_{fiber_size}_ADSS_G.657.A1"
            f"{from_to}_({int(length_m):04d}m-{sag_len:04d}m)"
        )
    else:
        return (
            f"VTC_CPT_{area_code}_{prefix}_{cable_no}_{fiber_size}_ADSS_G6.657.A1"
            f"_({int(length_m):04d}m-{sag_len:04d}m)"
        )


# ---------------------------------------------------------------------------
# Fibre Time: AREA.TYPE.NUMBER  (dot separator)
# ---------------------------------------------------------------------------

def ft_name(area_code: str, layer_type: str, n: int, extra: str = "") -> str:
    """Generate a Fibre Time feature name.

    layer_type: 'POP' | 'P' | 'AGG.DM' | 'DIS.DM' | 'FTS' | 'STS' | 'SS'
              | 'PF' | 'SF' | 'DIST' | 'DR'
    """
    formats = {
        "POP":    f"{area_code}.POP.{n:02d}",
        "P":      f"{area_code}.P.{extra or n}",
        "AGG.DM": f"{area_code}.AGG.DM.P.{extra}",
        "DIS.DM": f"{area_code}.DIS.DM.P.{extra}",
        "FTS":    f"{area_code}.FTS.{extra}.AGG.DM.P.{extra}",
        "STS":    f"{area_code}.STS.{extra}.DIS.DM.P.{extra}",
        "SS":     f"{area_code}.SS.{n:02d}",
        "PF":     f"{area_code}.PF.{n:02d}",
        "SF":     f"{area_code}.SF.{n:02d}",
        "DIST":   f"{area_code}.DIST.{n:02d}",
        "DR":     f"{area_code}.DR.{n:04d}",
    }
    if layer_type not in formats:
        raise ValueError(f"Unknown FT layer_type: {layer_type!r}")
    return formats[layer_type]


# ---------------------------------------------------------------------------
# Slack length calculation (shared by both clients)
# ---------------------------------------------------------------------------

def slack_length(design_length_m: float) -> int:
    """Return slack allocation in metres based on cable run length."""
    if design_length_m <= 50:
        return 15
    if design_length_m <= 100:
        return 30
    if design_length_m <= 200:
        return 40
    return 50


def sag_length(design_length_m: float) -> int:
    """Return sag-adjusted procurement length (design × 1.04, rounded up)."""
    return math.ceil(design_length_m * 1.04)


def drum_count(total_length_m: float, drum_size_m: float = 3000) -> int:
    """Return number of cable drums needed."""
    return math.ceil(total_length_m / drum_size_m)
