"""Pass 6a (Merge PONs) — pure, unit-testable helpers that turn a MergePlan into a
clear before→after preview for the dialog.

The merge ENGINE (``pon_merge.plan`` / ``apply_plan``) is NOT touched — these helpers
only read the plan's already-computed facts and format them. ``facts_from_plan`` reads
a plan-like object (duck-typed, so a plain fake works in tests); ``merge_preview_html``
renders the facts as the HTML the dialog's preview/confirm shows. No QGIS objects.
"""


def facts_from_plan(plan):
    """Read a MergePlan's public attributes into a plain, JSON-ish dict.
    Every field is defended so a partial/odd plan never raises."""
    ub = dict(getattr(plan, "units_before", {}) or {})
    sources = list(getattr(plan, "sources", []) or [])
    target = getattr(plan, "target", None)
    delete = getattr(plan, "delete", []) or []
    label_rewrites = getattr(plan, "label_rewrites", []) or []
    moved = dict(getattr(plan, "moved", {}) or {})
    return {
        "target": target,
        "sources": sources,
        "units_before": ub,                     # {pon: units} incl. target
        "target_before": ub.get(target),
        "units_after": int(getattr(plan, "units_after", 0) or 0),
        "total_moved": int(getattr(plan, "total_moved", sum(moved.values())) or 0),
        "moved_layers": len(moved),
        "boundaries_absorbed": sum(len(f) for _l, f in delete),
        "renumber_count": len(getattr(plan, "renumber", {}) or {}),
        "labels_updated": sum(len(c) for _l, c, _m in label_rewrites),
        "squared": bool(getattr(plan, "squared", False)),
        "warnings": list(getattr(plan, "warnings", []) or []),
    }


def _src_fragment(facts):
    """'PON 7 (94) + PON 9 (116)' — each source with its unit count when known."""
    ub = facts.get("units_before", {})
    parts = []
    for s in facts.get("sources", []):
        u = ub.get(s)
        parts.append(f"PON {s} ({int(u)})" if u is not None else f"PON {s}")
    return " + ".join(parts) if parts else "(nothing ticked)"


def merge_preview_html(facts):
    """Structured before→after HTML for the dialog's preview label / confirm box."""
    tgt = facts.get("target")
    after = int(facts.get("units_after", 0) or 0)
    before = facts.get("target_before")
    was = f" (was {int(before)})" if before is not None else ""
    lines = [
        "<b>Merge preview</b>",
        f"{_src_fragment(facts)} &rarr; <b>PON {tgt}</b>",
        f"Result: <b>PON {tgt} = {after} units</b>{was}",
    ]
    bullets = []
    tm = int(facts.get("total_moved", 0) or 0)
    if tm:
        bullets.append(f"{tm} feature(s) reassigned across "
                       f"{int(facts.get('moved_layers', 0) or 0)} layer(s)")
    nb = int(facts.get("boundaries_absorbed", 0) or 0)
    if nb:
        bullets.append(f"{nb} boundary polygon(s) absorbed &rarr; 1")
    rn = int(facts.get("renumber_count", 0) or 0)
    if rn:
        bullets.append(f"{rn} PON(s) renumbered to close the gap")
    nl = int(facts.get("labels_updated", 0) or 0)
    if nl:
        bullets.append(f"{nl} joint label(s) updated (_SP references)")
    if facts.get("squared"):
        bullets.append("merged boundary squared off")
    for b in bullets:
        lines.append(f"&bull; {b}")
    for w in facts.get("warnings", []):
        lines.append(f"&#9888; {w}")
    return "<br>".join(lines)
