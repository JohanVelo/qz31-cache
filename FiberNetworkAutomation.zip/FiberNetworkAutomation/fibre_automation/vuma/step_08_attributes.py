"""Vuma Step 8 — Populate attributes on all infrastructure layers.

STATUS: [x] BUILT
"""

# claude:approved-destructive

from qgis.core import QgsProject

from fibre_automation.shared.geometry_utils import build_spatial_index, nearest_feature


def _get(name):
    layers = QgsProject.instance().mapLayersByName(name)
    return layers[0] if layers else None


def _bulk_set(layer, updates: dict):
    """Write {fid: {field_idx: value}} in one bulk call."""
    if updates:
        layer.dataProvider().changeAttributeValues(updates)  # claude:approved-destructive
        layer.triggerRepaint()


def _populate_poles(poles_layer, agg_layer, block_layer):
    """Set X, Y coords and AG/Block spatial lookups on Poles."""
    if poles_layer is None:
        return 0

    fields = poles_layer.fields()
    x_idx  = fields.indexOf("X")
    y_idx  = fields.indexOf("Y")
    ag_idx = fields.indexOf("AG")
    blk_idx = fields.indexOf("Block")

    agg_index = agg_feat_map = None
    if agg_layer:
        agg_index, agg_feat_map = build_spatial_index(agg_layer)
        agg_label_idx = agg_layer.fields().indexOf("Label.")

    blk_index = blk_feat_map = None
    if block_layer:
        blk_index, blk_feat_map = build_spatial_index(block_layer)
        blk_label_idx = block_layer.fields().indexOf("Label.")

    updates = {}
    for feat in poles_layer.getFeatures():
        if not feat.hasGeometry():
            continue
        pt = feat.geometry().asPoint()
        row = {}
        if x_idx >= 0:
            row[x_idx] = round(pt.x(), 8)
        if y_idx >= 0:
            row[y_idx] = round(pt.y(), 8)

        if agg_index and ag_idx >= 0:
            nearest = nearest_feature(feat.geometry(), agg_index, agg_feat_map)
            if nearest:
                row[ag_idx] = str(nearest[agg_label_idx] or "")

        if blk_index and blk_idx >= 0:
            nearest = nearest_feature(feat.geometry(), blk_index, blk_feat_map)
            if nearest:
                row[blk_idx] = str(nearest[blk_label_idx] or "")

        if row:
            updates[feat.id()] = row

    _bulk_set(poles_layer, updates)
    return len(updates)


def _populate_cables(layer, length_field: str = "Tlenght"):
    """Calculate and write cable lengths (in metres, 2 dp)."""
    if layer is None:
        return 0
    idx = layer.fields().indexOf(length_field)
    if idx < 0:
        return 0

    if layer.crs().isGeographic():
        from qgis.core import QgsDistanceArea, QgsProject
        da = QgsDistanceArea()
        da.setSourceCrs(layer.crs(), QgsProject.instance().transformContext())
        da.setEllipsoid(layer.crs().ellipsoidAcronym())
        get_len = lambda geom: da.measureLength(geom)
    else:
        get_len = lambda geom: geom.length()

    updates = {}
    for feat in layer.getFeatures():
        if feat.hasGeometry():
            updates[feat.id()] = {idx: round(get_len(feat.geometry()), 2)}

    _bulk_set(layer, updates)
    return len(updates)


def _populate_demand_points(dp_layer, agg_layer, block_layer):
    """Set AG Name and Block Name on Demand Points via spatial lookup."""
    if dp_layer is None:
        return 0

    fields = dp_layer.fields()
    ag_idx  = fields.indexOf("AG Name")
    blk_idx = fields.indexOf("Block Name")

    if ag_idx < 0 and blk_idx < 0:
        return 0

    agg_index = agg_feat_map = agg_label_idx = None
    if agg_layer and ag_idx >= 0:
        agg_index, agg_feat_map = build_spatial_index(agg_layer)
        agg_label_idx = agg_layer.fields().indexOf("Label.")

    blk_index = blk_feat_map = blk_label_idx = None
    if block_layer and blk_idx >= 0:
        blk_index, blk_feat_map = build_spatial_index(block_layer)
        blk_label_idx = block_layer.fields().indexOf("Label.")

    updates = {}
    for feat in dp_layer.getFeatures():
        if not feat.hasGeometry():
            continue
        row = {}
        if agg_index:
            nearest = nearest_feature(feat.geometry(), agg_index, agg_feat_map)
            if nearest:
                row[ag_idx] = str(nearest[agg_label_idx] or "")
        if blk_index:
            nearest = nearest_feature(feat.geometry(), blk_index, blk_feat_map)
            if nearest:
                row[blk_idx] = str(nearest[blk_label_idx] or "")
        if row:
            updates[feat.id()] = row

    _bulk_set(dp_layer, updates)
    return len(updates)


def vuma_step_08_attributes():
    """Populate spatial and derived attributes across all Vuma layers.

    STATUS: [x] BUILT
    Safe to re-run — overwrites X/Y/length/AG/Block fields with fresh values.

    Operations:
      - Poles:          X, Y coordinates; AG and Block from spatial lookup
      - Demand Points:  AG Name and Block Name from spatial lookup
      - All cable layers: Tlenght in metres
    """
    print(f"\n{'═' * 50}")
    print("  VUMA STEP 8 — Attribute Population")
    print(f"{'═' * 50}")

    agg_layer   = _get("Aggregation Polygon")
    block_layer = _get("Block")

    # Poles
    poles_layer = _get("Poles")
    n = _populate_poles(poles_layer, agg_layer, block_layer)
    if poles_layer:
        print(f"  Poles         X/Y + AG/Block: {n:,} updated")

    # Demand Points
    dp_layer = _get("Demand Points")
    n = _populate_demand_points(dp_layer, agg_layer, block_layer)
    if dp_layer:
        print(f"  Demand Points AG/Block names: {n:,} updated")

    # Cable lengths
    cable_layers = [
        ("Feeder",             "Tlenght"),
        ("Link Cable",         "Tlenght"),
        ("Distribution Cable", "Tlenght"),
        ("Spur Cable",         "Tlenght"),
        ("Drops",              "Lenght"),
        ("Core",               "Lenght"),
    ]
    for layer_name, length_field in cable_layers:
        lyr = _get(layer_name)
        if lyr and lyr.featureCount() > 0:
            n = _populate_cables(lyr, length_field)
            print(f"  {layer_name:<25} lengths: {n:,} updated")

    print(f"{'═' * 50}\n")
