"""erven_detection — Erven Detection panel (SAM 2 + Grounding DINO via local MCP server).

Ported from the standalone erven_qgis_plugin v0.1.0 (Phase 1 of the Velocity Fibre
Automation merge). The panel is fully offline-safe: the MCP server (erven-mcp --http,
localhost:8780) is only contacted when the user runs a detection; when it is down the
panel shows an offline notice and the Run button is disabled.
"""
