from qgis.core import QgsVectorLayer, QgsProject

target_layers = [
    'Primary Cable v1',
    'Secondary Cable v1',
    'Distribution Cable v1',
    'Drop Cable v1',
    'Enclosure v1',
    'Enclosures Connectorised v1',
    'Enclosures Splice v1',
    'Poles v1',
    'ONT v1',
    'Home Connection v1',
    'Splitter FTS v1',
    'Splitter STS v1',
]

for name in target_layers:
    matches = QgsProject.instance().mapLayersByName(name)
    if not matches:
        print(f"[MISSING] {name}")
        continue
    lyr = matches[0]
    if not isinstance(lyr, QgsVectorLayer):
        print(f"[RASTER]  {name}")
        continue
    fields = [f.name() for f in lyr.fields()]
    feat = next(lyr.getFeatures(), None)
    sample = {}
    if feat:
        for f in fields:
            val = feat[f]
            sample[f] = str(val)[:40] if val else None
    print(f"\n=== {name} ({lyr.featureCount()} feats) ===")
    print(f"Fields: {fields}")
    print(f"Sample: {sample}")
