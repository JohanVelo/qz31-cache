"""safety — bundled, dependency-free reliability helpers for layer writes.

Public API (from .safe_writes):
  validate_layer, safe_bulk_edit, safe_add_features, safe_delete, safe_edit,
  LayerValidationError.
"""
from .safe_writes import (  # noqa: F401
    LayerValidationError,
    safe_add_features,
    safe_bulk_edit,
    safe_delete,
    safe_edit,
    validate_layer,
)
from .optical_budget import (  # noqa: F401
    link_loss_db,
    validate_link,
    validate_links,
    worst_case_reach_m,
)
from . import invariants  # noqa: F401
from .qgis_transaction import safe_transaction  # noqa: F401
from . import root_cause  # noqa: F401
