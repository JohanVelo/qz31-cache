"""admin — owner-only read queries + owner actions for the Team Monitor.

Uses the admin READ key (never shipped; from JJ's QgsSettings). All reads are
async via Backend.admin_get; results come back through callbacks. Owner write
actions (deactivate / reset token / announce) also use the admin key.
"""
import uuid

from . import config


def _admin_key():
    try:
        from qgis.core import QgsSettings
        return QgsSettings().value(
            f"{config.SETTINGS_NS}/{config.KEY_ADMIN_READ}") or ""
    except Exception:
        return ""


def is_admin(profile):
    """Team Monitor opens only for the owner. The admin SECRET key never ships
    and only JJ has it — its presence on this machine IS proof of ownership.
    (A signed-in profile is also required so a name shows in the UI.)"""
    if profile is None:
        return False
    return bool(_admin_key())


class Admin:
    def __init__(self, backend):
        self.backend = backend
        self.key = _admin_key()

    # ── reads (callbacks get a list of dict rows, or None) ──────────────────
    def online_now(self, cb):
        # heartbeat within the online window; PostgREST gte on a computed time
        # is awkward, so fetch recent heartbeats ordered desc and filter client.
        self.backend.admin_get(
            "heartbeats?select=*&order=last_updated.desc&limit=50",
            self.key, cb)

    def installs(self, cb):
        self.backend.admin_get(
            "installs?select=install_id,username,plugin_version,qgis_version,"
            "created_at,last_heartbeat&order=last_heartbeat.desc",
            self.key, cb)

    def recent_events(self, cb, limit=60):
        self.backend.admin_get(
            f"events?select=username,action_id,category,project_name,"
            f"inserted_at&order=inserted_at.desc&limit={limit}",
            self.key, cb)

    def recent_errors(self, cb, limit=40):
        self.backend.admin_get(
            f"errors?select=*&order=inserted_at.desc&limit={limit}",
            self.key, cb)

    def users(self, cb):
        self.backend.admin_get(
            "users?select=username,display_name,is_active,created_at,"
            "plugin_version&order=created_at.desc",
            self.key, cb)

    # ── owner actions (write with admin key) ────────────────────────────────
    def deactivate(self, username, active=False, cb=None):
        self._patch(f"users?username=eq.{username}",
                    {"is_active": active}, cb)

    def mark_error_resolved(self, error_id, resolved=True, cb=None):
        self._patch(f"errors?error_id=eq.{error_id}",
                    {"resolved": resolved}, cb)

    def issue_reset_token(self, username, ttl_minutes=60, cb=None):
        """Owner generates a one-time reset token for a user."""
        token = uuid.uuid4().hex[:8].upper()
        from datetime import datetime, timedelta, timezone
        expires = (datetime.now(timezone.utc)
                   + timedelta(minutes=ttl_minutes)).isoformat()
        self._post("password_reset_tokens",
                   {"token": token, "username": username,
                    "expires_at": expires},
                   lambda ok, t=token: cb(t if ok else None) if cb else None)
        return token

    def announce(self, title, message, expires_at=None, cb=None):
        self._post("announcements",
                   {"title": title, "message": message,
                    "created_by": config.ADMIN_USERNAME,
                    "expires_at": expires_at}, cb)

    # ── low-level admin writes ──────────────────────────────────────────────
    def _post(self, table, payload, cb=None):
        self._req("POST", table, payload, cb)

    def _patch(self, query, payload, cb=None):
        self._req("PATCH", query, payload, cb)

    def _req(self, method, path, payload, cb):
        try:
            import json
            from qgis.core import QgsNetworkAccessManager
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtNetwork import QNetworkRequest
        except Exception:
            if cb:
                cb(False)
            return
        req = QNetworkRequest(QUrl(f"{config.SUPABASE_URL}/rest/v1/{path}"))
        req.setHeader(QNetworkRequest.ContentTypeHeader, "application/json")
        req.setRawHeader(b"apikey", self.key.encode())
        req.setRawHeader(b"Authorization", f"Bearer {self.key}".encode())
        req.setRawHeader(b"Prefer", b"return=minimal")
        body = json.dumps(payload).encode("utf-8")
        try:
            nam = QgsNetworkAccessManager.instance()
            if method == "POST":
                reply = nam.post(req, body)
            else:
                reply = nam.sendCustomRequest(req, b"PATCH", body)

            def _done(r=reply):
                ok = False
                try:
                    ok = int(r.error()) == 0
                except Exception:
                    pass
                if cb:
                    cb(ok)
                try:
                    r.deleteLater()
                except Exception:
                    pass

            reply.finished.connect(_done)
        except Exception:
            if cb:
                cb(False)
