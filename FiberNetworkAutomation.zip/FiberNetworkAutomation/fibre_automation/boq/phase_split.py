"""phase_split — assign HeroTel BoQ features to project PHASES (bundled, read-only).

Malmesbury (and the HeroTel projects generally) carry a ``Phases`` POLYGON layer
(field ``Phase Num`` = "Phase 1" / "Phase 2" / ...). Individual features (poles,
cables, joints, ...) have NO phase attribute, so a feature's phase is SPATIAL —
which polygon it sits in. This module turns that into:

  * point features  -> the one phase polygon that contains them (nearest on a tie
    or a boundary point), and
  * line features   -> the metres of the line INSIDE each phase (clip), so a cable
    crossing a boundary is split and the per-phase metres sum back to the whole
    (JJ's rule 2026-07-20: split by length).

Everything here is READ-ONLY and measures in true METRES via
shared.crs_utils.metre_measurer (never the degrees trap). A feature that falls
OUTSIDE every phase polygon is reported under the sentinel ``OUTSIDE`` — never
silently dropped, so the phase totals always reconcile to the whole.
"""

PHASE_LAYER = "Phases"
PHASE_FIELD = "Phase Num"
OUTSIDE = "(outside phases)"   # sentinel bucket for anything in no phase polygon


def _layer(project, name):
    """Loose lookup: exact (stripped, case-insensitive) then substring."""
    want = str(name).strip().lower()
    for lyr in project.mapLayers().values():
        if lyr.name().strip().lower() == want:
            return lyr
    for lyr in project.mapLayers().values():
        if want in lyr.name().strip().lower():
            return lyr
    return None


def _measurer(project, layer):
    try:
        from ..shared.crs_utils import metre_measurer
    except ImportError:
        from fibre_automation.shared.crs_utils import metre_measurer
    crs = layer.crs() if layer is not None else None
    return metre_measurer(crs=crs, project=project)


def load_phases(project):
    """Return the phase polygons as a list of dicts sorted by phase name:

        [{"name": "Phase 1", "geom": QgsGeometry, "id": fid}, ...]

    or ``[]`` when the project has no usable ``Phases`` layer. The geometries are
    kept (copied) so callers can test containment / clip against them.
    """
    lyr = _layer(project, PHASE_LAYER)
    if lyr is None:
        return []
    fld = [f.name() for f in lyr.fields()]
    name_f = PHASE_FIELD if PHASE_FIELD in fld else next(
        (f for f in fld if "phase" in f.lower()), None)
    out = []
    for feat in lyr.getFeatures():
        g = feat.geometry()
        if not g or g.isEmpty():
            continue
        nm = (str(feat[name_f]).strip() if name_f and feat[name_f] is not None
              else f"Phase {feat.id()}")
        from qgis.core import QgsGeometry
        out.append({"name": nm, "geom": QgsGeometry(g), "id": feat.id()})
    # order by the trailing number when present ("Phase 1" < "Phase 2" < ...)
    def _key(rec):
        digits = "".join(c for c in rec["name"] if c.isdigit())
        return (int(digits) if digits else 9999, rec["name"])
    out.sort(key=_key)
    return out


def phase_names(polys):
    """The ordered list of phase names (no OUTSIDE), for building tab order."""
    return [p["name"] for p in polys]


def _index(polys):
    """A QgsSpatialIndex over the phase polygons keyed by their list position."""
    from qgis.core import QgsSpatialIndex, QgsFeature
    idx = QgsSpatialIndex()
    for i, p in enumerate(polys):
        ft = QgsFeature(i)
        ft.setGeometry(p["geom"])
        idx.addFeature(ft)
    return idx


def spatial_index(polys):
    """Public: a QgsSpatialIndex over the phase polygons (build once, reuse).

    Pass the result as ``index=`` to point_phase / assign_points so a per-feature
    loop does not rebuild the index on every call."""
    return _index(polys)


def point_phase(point_geom, polys, index=None):
    """Phase name whose polygon contains the point; nearest polygon if the point
    lands on no polygon (boundary / just-outside); ``OUTSIDE`` only when there are
    no phases at all. Returns the phase name (str)."""
    if not polys:
        return OUTSIDE
    if not point_geom or point_geom.isEmpty():
        return OUTSIDE
    index = index or _index(polys)
    from qgis.core import QgsRectangle
    pt = point_geom.asPoint() if not point_geom.isMultipart() \
        else point_geom.asMultiPoint()[0]
    # exact containment first
    for i in index.intersects(QgsRectangle(pt.x(), pt.y(), pt.x(), pt.y())):
        if polys[i]["geom"].contains(point_geom):
            return polys[i]["name"]
    # else nearest polygon by distance (a point on a shared edge / tiny gap)
    best, best_d = None, None
    for p in polys:
        d = p["geom"].distance(point_geom)
        if best_d is None or d < best_d:
            best, best_d = p["name"], d
    return best if best is not None else OUTSIDE


def line_phase_lengths(line_geom, polys, da):
    """Metres of ``line_geom`` inside each phase, as {phase_name: metres}. Any part
    of the line covered by no phase polygon is bucketed under ``OUTSIDE``. The
    values always sum (within rounding) to the whole line length."""
    out = {}
    if not line_geom or line_geom.isEmpty() or not polys:
        return out
    total = da.measureLength(line_geom)
    covered = 0.0
    for p in polys:
        try:
            inter = line_geom.intersection(p["geom"])
        except Exception:
            inter = None
        if inter is None or inter.isEmpty():
            continue
        m = da.measureLength(inter)
        if m > 0:
            out[p["name"]] = out.get(p["name"], 0.0) + m
            covered += m
    remainder = total - covered
    if remainder > 0.5:   # >0.5 m of the line sits outside every phase
        out[OUTSIDE] = out.get(OUTSIDE, 0.0) + remainder
    return {k: round(v, 1) for k, v in out.items()}


def line_phase_fractions(line_geom, polys, da):
    """Fraction of ``line_geom`` inside each phase, as {phase_name: frac}.

    Like :func:`line_phase_lengths` but normalised so the values sum to 1.0 — the
    share of the line in each phase. Any part covered by no phase polygon lands in
    ``OUTSIDE``. Used to split an ATTRIBUTE quantity (a cable's Tlenght+Slenght buy,
    a trench's Lenght) across phases so the per-phase quantity sums back EXACTLY to
    the whole-feature quantity (JJ's reconciliation-is-law rule): buy_phase =
    buy * frac_phase, and Σ frac == 1.

    Returns ``{}`` for an empty/nil line or when there are no phases (the caller
    then keeps the whole quantity on the feature, unsplit).
    """
    if not line_geom or line_geom.isEmpty() or not polys:
        return {}
    total = da.measureLength(line_geom)
    if total <= 0:
        return {}
    lens = line_phase_lengths(line_geom, polys, da)   # absolute metres per phase
    if not lens:
        return {}
    # normalise by the SUM of the parts (not `total`) so the fractions always add
    # to exactly 1.0 even when clip metres drift a hair from the whole-line metre.
    denom = sum(lens.values())
    if denom <= 0:
        return {}
    return {k: v / denom for k, v in lens.items()}


def assign_points(layer, polys, index=None):
    """{fid: phase_name} for every feature in a point layer (read-only)."""
    if layer is None or not polys:
        return {}
    index = index or _index(polys)
    return {f.id(): point_phase(f.geometry(), polys, index)
            for f in layer.getFeatures()}


def assign_line_lengths(project, layer, polys):
    """{fid: {phase_name: metres}} for every feature in a line layer (read-only)."""
    if layer is None or not polys:
        return {}
    da = _measurer(project, layer)
    out = {}
    for f in layer.getFeatures():
        g = f.geometry()
        if not g or g.isEmpty():
            continue
        out[f.id()] = line_phase_lengths(g, polys, da)
    return out
