import sys, os
if sys.stderr is None: sys.stderr = open(os.devnull, 'w')
if sys.stdout is None: sys.stdout = open(os.devnull, 'w')

# ============================================================
# CHECK PROJECT LAYERS
# Run this on any new Fibertime project to see what layers
# are present and what needs to be created before running
# the home connections automation.
#
# exec(open(r'C:\Users\jjsch\OneDrive - blitzfibre.com\Documents\CLAUDE\Home Connections Automation\check_project_layers.py').read())
# ============================================================

# Standard v1 layer names expected in every Fibertime project
EXPECTED_LAYERS = [
    'poles',
    'Primary Cable',
    'Secondary Cable',
    'Distribution Cable',
    'FTS Splitters',
    'STS Splitters',
    'Enclosure',
    'Enclosures Connectorised',
    'Enclosures Splice',
    'Home Connections',
    'Drop Cable',
    'Spare Drop Cable',
    'Span',
    'ONT',
]

# Get all loaded layers
loaded = {l.name(): l for l in QgsProject.instance().mapLayers().values()}

print("=" * 65)
print(f"  PROJECT: {QgsProject.instance().baseName()}")
print(f"  Loaded layers: {len(loaded)}")
print("=" * 65)

print("\n── Standard v1 Layers ─────────────────────────────────")
missing = []
def _feat_count(lyr):
    return lyr.featureCount() if hasattr(lyr, 'featureCount') else '—'

for name in EXPECTED_LAYERS:
    if name in loaded:
        lyr = loaded[name]
        print(f"  ✅  {name} ({_feat_count(lyr)} features)")
    else:
        print(f"  ❌  {name} — MISSING")
        missing.append(name)

print("\n── All Loaded Layers ───────────────────────────────────")
for name, lyr in sorted(loaded.items()):
    marker = '  ✅' if name in EXPECTED_LAYERS else '    '
    print(f"{marker}  {name} ({_feat_count(lyr)} feat, {lyr.crs().authid()})")

if missing:
    print(f"\n⚠️  {len(missing)} expected layers missing:")
    for m in missing:
        print(f"    • {m}")
    print("\nCreate these layers before running the automation scripts.")
else:
    print("\n✅ All expected layers present — ready to automate.")

# Show project extent
from qgis.core import QgsRectangle
ext = QgsProject.instance().viewSettings().fullExtent() if hasattr(QgsProject.instance(), 'viewSettings') else None
if 'Zones v1' in loaded:
    e = loaded['Zones v1'].extent()
    print(f"\nProject extent (from Zones v1):")
    print(f"  {e.yMinimum():.5f},{e.xMinimum():.5f} → {e.yMaximum():.5f},{e.xMaximum():.5f}")
