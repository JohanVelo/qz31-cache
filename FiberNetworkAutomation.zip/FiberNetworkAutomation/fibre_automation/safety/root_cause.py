"""root_cause — structured crash breadcrumbs (bundled; stdlib only, zero deps).

Purely additive diagnostics: a small in-memory ring of "what the plugin was doing"
plus a @traced decorator you can put on crash-hot functions. When something blows
up, the breadcrumb trail (last N operations, with layer/fid/op context) is dumped
next to the error so a crash localizes to the exact step — turning "it just
crashed" into "it crashed in _regen_drops on layer 'Drop Cable v1', fid 412".

Transparent + fail-silent: @traced calls straight through and NEVER changes the
wrapped function's result or raises from its own logging. Safe to wrap anything.

  from fibre_automation.safety.root_cause import traced, breadcrumb, recent, dump
  @traced("regen drops")
  def _regen_drops(self, ...): ...
  breadcrumb("apply PON order", layer="Poles v1", n=5393)
  recent()           # -> list of last breadcrumbs (newest last)
  dump()             # -> formatted trail string for a crash report
"""
import functools
import time
from collections import deque

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

_RING = deque(maxlen=60)


def _guardian():
    """The Geometry Guardian module (it lives at the PLUGIN root, one level above
    fibre_automation). Try the absolute installed name first, then 3-dot relative."""
    try:
        from FiberNetworkAutomation import geometry_guardian as g
        return g
    except Exception:
        try:
            from ... import geometry_guardian as g
            return g
        except Exception:
            return None


def breadcrumb(op, **ctx):
    """Record one step. Never raises. ctx = free-form (layer, fid, n, ...)."""
    try:
        _RING.append((time.time(), str(op)[:120],
                      {k: str(v)[:80] for k, v in ctx.items()}))
        # mirror into the Geometry Guardian's activity trail (single source of
        # truth for "what was happening" in crash reports)
        g = _guardian()
        if g is not None:
            try:
                g.record_activity(op + (" " + repr(ctx) if ctx else ""))
            except Exception:
                _swallowed_note()
    except Exception:
        _swallowed_note()


def recent(n=20):
    """Last n breadcrumbs as [(ts, op, ctx), ...] (newest last). Never raises."""
    try:
        return list(_RING)[-n:]
    except Exception:
        return []


def dump(n=20):
    """Formatted breadcrumb trail for a crash report. Pulls from the Geometry
    Guardian's already-populated activity log (the plugin feeds it via log_message)
    plus any explicit @traced/breadcrumb entries. Never raises."""
    try:
        out = []
        # the populated trail: what the plugin logged it was doing
        try:
            g = _guardian()
            for t in (g.recent_activity(n=n, within_s=600) if g else []):
                out.append("  " + str(t))
        except Exception:
            _swallowed_note()
        # plus explicit @traced breadcrumbs recorded in this module's ring
        now = time.time()
        for ts, op, ctx in recent(n):
            ago = now - ts
            c = ("  " + " ".join(f"{k}={v}" for k, v in ctx.items())) if ctx else ""
            out.append(f"  -{ago:5.1f}s  {op}{c}")
        return "BREADCRUMB TRAIL (what the plugin was doing):\n" + "\n".join(out) if out else \
            "BREADCRUMB TRAIL: (empty)"
    except Exception:
        return "BREADCRUMB TRAIL: (unavailable)"


def traced(op=None, **static_ctx):
    """Decorator: record a breadcrumb on entry, and on exception re-record with the
    exception type before re-raising. Transparent — returns the wrapped result
    unchanged. `op` defaults to the function name."""
    def deco(fn):
        label = op or getattr(fn, "__name__", "op")

        @functools.wraps(fn)
        def wrap(*a, **k):
            breadcrumb(label, **static_ctx)
            try:
                return fn(*a, **k)
            except Exception as e:
                try:
                    breadcrumb(f"{label} RAISED {type(e).__name__}", **static_ctx)
                except Exception:
                    _swallowed_note()
                raise
        return wrap
    return deco
