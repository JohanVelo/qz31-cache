# Processing Provider for Fiber Network Automation

from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon

from .algorithms.label_aggregation_algorithm import LabelAggregationAlgorithm
from .algorithms.label_blocks_algorithm import LabelBlocksAlgorithm
from .algorithms.label_poles_algorithm import LabelPolesAlgorithm
from .algorithms.label_dome_joints_algorithm import LabelDomeJointsAlgorithm
from .algorithms.label_feeder_joints_algorithm import LabelFeederJointsAlgorithm
from .algorithms.label_demand_points_algorithm import LabelDemandPointsAlgorithm
from .algorithms.label_feeder_cables_algorithm import LabelFeederCablesAlgorithm
from .algorithms.label_distribution_cables_algorithm import LabelDistributionCablesAlgorithm
from .algorithms.clean_buildings_algorithm import CleanBuildingsAlgorithm

# Fibertime (MOA standard) algorithms
from .algorithms.ft_poles_algorithm import FTPolesAlgorithm
from .algorithms.ft_distribution_cable_algorithm import FTDistributionCableAlgorithm
from .algorithms.ft_secondary_cable_algorithm import FTSecondaryCableAlgorithm
from .algorithms.ft_enclosure_algorithm import FTEnclosureAlgorithm
from .algorithms.ft_pon_zone_algorithm import FTPonZoneAlgorithm
from .algorithms.ft_apply_pon_order_algorithm import FTApplyPonOrderAlgorithm
from .algorithms.ft_pole_thickness_algorithm import FTPoleThicknessAlgorithm
from .algorithms.classify_poles_algorithm import ClassifyPolesAlgorithm
from .algorithms.ft_road_crossing_update_algorithm import FTRoadCrossingUpdateAlgorithm
from .algorithms.ft_sts_algorithm import FTSTSAlgorithm
from .algorithms.ft_spur_enclosure_algorithm import FtSpurEnclosureAlgorithm
from .algorithms.ft_pon_zone_voronoi_algorithm import FTPonZoneVoronoiAlgorithm

# HeroTel (TSD standard) algorithms — Group C
from .algorithms.herotel.ht_01_ont_placement import HT01OntPlacementAlgorithm
from .algorithms.herotel.ht_02_pon_clustering import HT02PonClusteringAlgorithm
from .algorithms.herotel.ht_03_splitter_placement import HT03SplitterPlacementAlgorithm
from .algorithms.herotel.ht_04_drop_routing import HT04DropRoutingAlgorithm
from .algorithms.herotel.ht_05_feeder_routing import HT05FeederRoutingAlgorithm
from .algorithms.herotel.ht_06_schema_check import HT06SchemaCheckAlgorithm
from .algorithms.velocity.vn_01_standardise_layers import (
    VN01StandardiseLayersAlgorithm)


class FiberNetworkProvider(QgsProcessingProvider):
    """Processing Provider for Fiber Network Automation"""

    def __init__(self):
        super().__init__()

    def id(self):
        return 'fibernetwork'

    def name(self):
        return 'Fiber Network Automation'

    def icon(self):
        return QIcon()

    def loadAlgorithms(self):
        # Wrap each addAlgorithm so a bad import/constructor never raises into C++
        # (a Python exception propagating into QGIS's refreshAlgorithms leaves a
        # zombie "fibernetwork" entry in the C++ registry that survives until restart)
        for klass in (
            LabelAggregationAlgorithm, LabelBlocksAlgorithm, LabelPolesAlgorithm,
            LabelDomeJointsAlgorithm, LabelFeederJointsAlgorithm,
            LabelDemandPointsAlgorithm, LabelFeederCablesAlgorithm,
            LabelDistributionCablesAlgorithm, CleanBuildingsAlgorithm,
            FTPolesAlgorithm, FTDistributionCableAlgorithm, FTSecondaryCableAlgorithm,
            FTEnclosureAlgorithm, FTPonZoneAlgorithm, FTApplyPonOrderAlgorithm,
            FTPoleThicknessAlgorithm, ClassifyPolesAlgorithm,
            FTRoadCrossingUpdateAlgorithm,
            FTSTSAlgorithm, FtSpurEnclosureAlgorithm, FTPonZoneVoronoiAlgorithm,
            HT01OntPlacementAlgorithm,
            HT02PonClusteringAlgorithm,
            HT03SplitterPlacementAlgorithm,
            HT04DropRoutingAlgorithm,
            HT05FeederRoutingAlgorithm,
            HT06SchemaCheckAlgorithm,
            VN01StandardiseLayersAlgorithm,
        ):
            try:
                self.addAlgorithm(klass())
            except Exception as exc:
                print(f"[FiberNetwork] failed to load {klass.__name__}: {exc}")
