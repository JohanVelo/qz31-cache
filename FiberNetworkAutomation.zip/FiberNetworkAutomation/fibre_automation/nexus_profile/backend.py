"""backend — the ONE place that talks to Supabase (PostgREST).

QgsNetworkAccessManager + QNetworkRequest + JSON. No pip libraries. Every
write is fire-and-forget and NEVER blocks the UI. In dry-run mode (default
until the backend is configured) nothing is POSTed — records go to the spool.

Writes use the shipped ANON key: plain INSERT (insert-only RLS) + a filtered
PATCH for presence (update()). NO upsert — ON CONFLICT needs a SELECT grant
the anon role must not have. The admin SELECTs (Team Monitor) use the owner
read-key, passed in explicitly and never shipped.
"""
import json
import uuid

from . import config, spool


def _delivered(reply):
    """Classify a finished reply for spool purposes. True = stop retrying
    (the server gave a final answer: 2xx delivered, 3xx, or 4xx incl. 409
    duplicate). False = keep spooled (no response → offline, or 5xx transient).
    Status read cross-version-safely via the HTTP status attribute."""
    try:
        from qgis.PyQt.QtNetwork import QNetworkRequest
        code = reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute)
        if code is None:
            return False                 # transport failure (offline)
        return int(code) < 500           # 5xx → transient, keep for retry
    except Exception:
        return False


def _plugin_version():
    try:
        import os
        import re
        here = os.path.dirname(os.path.abspath(__file__))
        mp = os.path.normpath(os.path.join(here, "..", "..", "metadata.txt"))
        with open(mp, encoding="utf-8") as f:
            m = re.search(r"^version=(\S+)", f.read(), flags=re.M)
        return m.group(1) if m else "?"
    except Exception:
        return "?"


class Backend:
    """One instance, dependency-injected so dry-run is trivial.

    data_dir   : portable scratch dir (vf_paths.data_dir())
    dry_run    : when True, writes go to the spool only (no network)
    """

    def __init__(self, data_dir, dry_run=None):
        self.data_dir = data_dir
        if dry_run is None:
            dry_run = config.DRY_RUN_DEFAULT or not config.is_backend_configured()
        self.dry_run = dry_run
        self.version = _plugin_version()
        self._ua = f"VelocityNexus/{self.version} (QGIS)".encode()

    # ── writes (anon key) ───────────────────────────────────────────────────
    # NOTE: NO upsert. PostgREST upsert (ON CONFLICT) needs a SELECT grant the
    # anon role must NOT have (insert-only RLS is the whole security model), so
    # it fails with 42501. Presence is created once (insert) and refreshed with
    # update() (a plain filtered PATCH, which RLS allows).
    def insert(self, table, payload, spool_it=True):
        """Queue+send one plain INSERT. Returns the idempotency key. Never
        raises, never blocks. spool_it=False for best-effort 'ensure row'
        writes that needn't survive a restart (a re-insert just 409s)."""
        idem = str(uuid.uuid4())
        payload = dict(payload)
        if table in ("events", "errors"):
            payload.setdefault("idempotency_key", idem)
        prefer = "return=minimal"
        if spool_it:
            # spool first (crash-safe); the record is removed ONLY when the
            # server confirms delivery — so an offline send stays queued.
            spool.append(self.data_dir, table, payload, idem, prefer)
            spool.enforce_cap(self.data_dir, config.SPOOL_MAX_BYTES)
        if not self.dry_run:
            self._post(table, payload, prefer,
                       on_done=(lambda ok: self._on_sent(idem, ok))
                       if spool_it else None)
        return idem

    def _on_sent(self, idem, delivered):
        """Drop a spooled record only on confirmed delivery (keeps it for retry
        when offline / on a 5xx)."""
        if delivered and idem:
            try:
                spool.remove(self.data_dir, idem)
            except Exception:
                pass

    def update(self, table, match, payload):
        """Plain filtered PATCH (anon UPDATE policy allows it). Used to refresh
        presence (installs.last_heartbeat). Fire-and-forget; never spooled —
        presence is ephemeral, the next heartbeat supersedes a missed one."""
        if self.dry_run:
            return
        self._patch(f"{table}?{match}", payload)

    # ── flush the spool (called on a timer + on reconnect) ──────────────────
    def flush(self):
        if self.dry_run or not config.is_backend_configured():
            return
        # Re-send each spooled record; the per-record reply handler removes it
        # from the spool ONLY on confirmed delivery (idempotency_key dedupes a
        # resend server-side). Offline / 5xx → it stays queued for next time.
        for r in spool.read_all(self.data_dir):
            idem = r.get("idem")
            self._post(r["table"], r["payload"], r.get("prefer"),
                       on_done=(lambda ok, i=idem: self._on_sent(i, ok))
                       if idem else None)

    # ── low-level POST (async, fire-and-forget) ─────────────────────────────
    def _post(self, table, payload, prefer=None, on_done=None):
        """POST async. on_done(delivered: bool) fires when the reply finishes —
        delivered=True means 'stop retrying' (2xx/3xx/4xx incl. 409 dup);
        False means offline/transport-fail or 5xx (keep spooled)."""
        try:
            from qgis.core import QgsNetworkAccessManager
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtNetwork import QNetworkRequest
        except Exception:
            if on_done:
                on_done(False)
            return False
        url = f"{config.SUPABASE_URL}/rest/v1/{table}"
        req = QNetworkRequest(QUrl(url))
        try:
            req.setTransferTimeout(15000)   # Qt 5.15+: never hang on a dead socket
        except Exception:
            pass
        req.setHeader(QNetworkRequest.KnownHeaders.ContentTypeHeader, "application/json")
        req.setRawHeader(b"apikey", config.SUPABASE_ANON_KEY.encode())
        req.setRawHeader(b"Authorization",
                         f"Bearer {config.SUPABASE_ANON_KEY}".encode())
        req.setRawHeader(b"User-Agent", self._ua)
        if prefer:
            req.setRawHeader(b"Prefer", prefer.encode())
        body = json.dumps(payload).encode("utf-8")
        try:
            nam = QgsNetworkAccessManager.instance()
            try:
                nam.setAutoDeleteReplies(True)   # Qt 5.14+: clean reply lifecycle
            except Exception:
                pass
            reply = nam.post(req, body)

            def _finished(r=reply):
                try:
                    if on_done is not None:
                        on_done(_delivered(r))
                finally:
                    self._safe_delete(r)
            reply.finished.connect(_finished)
            return True
        except Exception:
            if on_done:
                on_done(False)
            return False        # network stack unavailable — keep in spool

    def _patch(self, path, payload):
        """Filtered PATCH (anon UPDATE). Async, fire-and-forget."""
        try:
            from qgis.core import QgsNetworkAccessManager
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtNetwork import QNetworkRequest
        except Exception:
            return
        req = QNetworkRequest(QUrl(f"{config.SUPABASE_URL}/rest/v1/{path}"))
        try:
            req.setTransferTimeout(15000)   # Qt 5.15+: never hang on a dead socket
        except Exception:
            pass
        req.setHeader(QNetworkRequest.KnownHeaders.ContentTypeHeader, "application/json")
        req.setRawHeader(b"apikey", config.SUPABASE_ANON_KEY.encode())
        req.setRawHeader(b"Authorization",
                         f"Bearer {config.SUPABASE_ANON_KEY}".encode())
        req.setRawHeader(b"User-Agent", self._ua)
        req.setRawHeader(b"Prefer", b"return=minimal")
        body = json.dumps(payload).encode("utf-8")
        try:
            nam = QgsNetworkAccessManager.instance()
            try:
                nam.setAutoDeleteReplies(True)
            except Exception:
                pass
            reply = nam.sendCustomRequest(req, b"PATCH", body)
            reply.finished.connect(lambda r=reply: self._safe_delete(r))
        except Exception:
            pass

    @staticmethod
    def _safe_delete(reply):
        try:
            reply.deleteLater()
        except Exception:
            pass

    def check_active(self, username, callback):
        """Ask the server if this account is still active (anon RPC
        is_user_active). callback(True/False) on a clear answer, callback(None)
        on offline/error (caller treats None as 'no change')."""
        if not username:
            callback(None)
            return
        try:
            from qgis.core import QgsNetworkAccessManager
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtNetwork import QNetworkRequest
        except Exception:
            callback(None)
            return
        req = QNetworkRequest(QUrl(f"{config.SUPABASE_URL}/rest/v1/rpc/is_user_active"))
        try:
            req.setTransferTimeout(15000)
        except Exception:
            pass
        req.setHeader(QNetworkRequest.KnownHeaders.ContentTypeHeader, "application/json")
        req.setRawHeader(b"apikey", config.SUPABASE_ANON_KEY.encode())
        req.setRawHeader(b"Authorization",
                         f"Bearer {config.SUPABASE_ANON_KEY}".encode())
        req.setRawHeader(b"User-Agent", self._ua)
        body = json.dumps({"u": username}).encode("utf-8")
        try:
            reply = QgsNetworkAccessManager.instance().post(req, body)

            def _done(r=reply):
                try:
                    if int(r.error()) != 0:
                        callback(None)
                    else:
                        txt = bytes(r.readAll()).decode("utf-8", "replace").strip()
                        callback(True if txt == "true"
                                 else False if txt == "false" else None)
                except Exception:
                    callback(None)
                finally:
                    self._safe_delete(r)

            reply.finished.connect(_done)
        except Exception:
            callback(None)

    def upload_screenshot(self, png_bytes, bucket="ticket-shots"):
        """Upload a PNG to a PUBLIC Storage bucket with the anon key and return
        its public URL (or None). Synchronous (small images, user-initiated) so
        the caller gets the URL to put on the ticket row before insert. Never
        raises. Dry-run / unconfigured → None."""
        if self.dry_run or not png_bytes:
            return None
        try:
            import urllib.request
            import uuid as _uuid
            path = f"tickets/{_uuid.uuid4().hex}.png"
            url = f"{config.SUPABASE_URL}/storage/v1/object/{bucket}/{path}"
            req = urllib.request.Request(url, data=bytes(png_bytes), method="POST")
            req.add_header("apikey", config.SUPABASE_ANON_KEY)
            req.add_header("Authorization", f"Bearer {config.SUPABASE_ANON_KEY}")
            req.add_header("Content-Type", "image/png")
            # NOTE: no x-upsert — upsert needs an UPDATE policy the anon role
            # lacks (→ 403 RLS). Each path is a fresh uuid, so a plain insert
            # never conflicts.
            with urllib.request.urlopen(req, timeout=20) as r:
                if 200 <= getattr(r, "status", r.getcode()) < 300:
                    return (f"{config.SUPABASE_URL}/storage/v1/object/public/"
                            f"{bucket}/{path}")
        except Exception:
            pass
        return None

    def my_resolved_tickets(self, username, callback):
        """Anon RPC: return THIS user's own resolved tickets (id/title/kind/
        resolved_in_version/created_at). callback(list) on success, callback([])
        on empty, callback(None) on error/offline. No data leak — the SECURITY
        DEFINER function filters by username server-side."""
        if not username:
            callback(None)
            return
        try:
            from qgis.core import QgsNetworkAccessManager
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtNetwork import QNetworkRequest
        except Exception:
            callback(None)
            return
        req = QNetworkRequest(
            QUrl(f"{config.SUPABASE_URL}/rest/v1/rpc/my_resolved_tickets"))
        try:
            req.setTransferTimeout(15000)
        except Exception:
            pass
        req.setHeader(QNetworkRequest.KnownHeaders.ContentTypeHeader,
                      "application/json")
        req.setRawHeader(b"apikey", config.SUPABASE_ANON_KEY.encode())
        req.setRawHeader(b"Authorization",
                         f"Bearer {config.SUPABASE_ANON_KEY}".encode())
        req.setRawHeader(b"User-Agent", self._ua)
        body = json.dumps({"u": username}).encode("utf-8")
        try:
            reply = QgsNetworkAccessManager.instance().post(req, body)

            def _done(r=reply):
                try:
                    if int(r.error()) != 0:
                        callback(None)
                    else:
                        txt = bytes(r.readAll()).decode("utf-8", "replace")
                        callback(json.loads(txt) if txt.strip() else [])
                except Exception:
                    callback(None)
                finally:
                    self._safe_delete(r)

            reply.finished.connect(_done)
        except Exception:
            callback(None)

    # ── admin reads (owner read-key; never shipped) ─────────────────────────
    def admin_get(self, query, admin_key, callback):
        """GET .../rest/v1/<query> with the owner key; callback(list|None).
        Used only by the Team Monitor on JJ's machine."""
        try:
            from qgis.core import QgsNetworkAccessManager
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtNetwork import QNetworkRequest
        except Exception:
            callback(None)
            return
        req = QNetworkRequest(QUrl(f"{config.SUPABASE_URL}/rest/v1/{query}"))
        req.setRawHeader(b"apikey", admin_key.encode())
        req.setRawHeader(b"Authorization", f"Bearer {admin_key}".encode())
        req.setRawHeader(b"User-Agent", self._ua)
        try:
            reply = QgsNetworkAccessManager.instance().get(req)

            def _done(r=reply):
                try:
                    if int(r.error()) != 0:
                        callback(None)
                    else:
                        callback(json.loads(
                            bytes(r.readAll()).decode("utf-8", "replace")))
                except Exception:
                    callback(None)
                finally:
                    self._safe_delete(r)

            reply.finished.connect(_done)
        except Exception:
            callback(None)
