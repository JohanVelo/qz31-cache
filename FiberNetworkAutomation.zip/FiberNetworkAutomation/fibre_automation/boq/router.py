"""router — one entry point for the Cost/BOQ button: client → the right builder.

The button asks WHICH client the bill is for, then calls ``run_client_boq(client,
out_path)``. Each client's builder returns a different native shape (the Fibertime
MML returns a dict; the generic engine returns a BoQResult object); this module
normalises them into ONE uniform dict so the button code is client-agnostic:

    {client, label, format, out_path, lines(int), verdict, findings[(status,msg)],
     diag{ont,poles,...}, stub(bool)}

Design rules (match the rest of boq/):
  * READ-ONLY — routes to read-only builders; never edits a layer.
  * HONEST — a client whose approved format is not built yet routes to the generic
    priced engine and is flagged ``stub=True`` with a clear finding, NEVER a silent
    Fibertime bill in another client's name.
  * ADDITIVE — the Fibertime route calls the exact same function with the exact
    same args as before, so its output is unchanged.
"""

# (key, label, one-line caption, filename suffix)  — display order = picker order.
CLIENTS = [
    ("fibertime", "Fibertime",
     "Approved Master Material List (per-SKU BOM Fibertime signs off).",
     "_Fibertime_BoQ.xlsx"),
    ("herotel", "HeroTel",
     "HeroTel bill of quantities (approved format).",
     "_HeroTel_BoQ.xlsx"),
    ("vuma", "Vuma",
     "Generic priced BoQ (Vuma-approved format not built yet).",
     "_Vuma_BoQ.xlsx"),
    ("generic", "Generic",
     "Client-neutral reliable priced BoQ (UTM metres, slack/sag, audit).",
     "_BoQ.xlsx"),
]
_LABEL = {k: lab for k, lab, _c, _s in CLIENTS}
_CAPTION = {k: c for k, _lab, c, _s in CLIENTS}
_SUFFIX = {k: s for k, _lab, _c, s in CLIENTS}
_VALID = {k for k, *_ in CLIENTS}


def client_label(key):
    return _LABEL.get(key, key)


def client_caption(key):
    return _CAPTION.get(key, "")


def filename_suffix(key):
    return _SUFFIX.get(key, "_BoQ.xlsx")


def default_client(project=None):
    """Best-effort client for the picker's default selection, from layer names."""
    try:
        from qgis.core import QgsProject
        project = project or QgsProject.instance()
        names = [lyr.name() for lyr in project.mapLayers().values()]
        # the project's own name is a strong brand signal ("Malmsbury Herotel V4")
        # — feed it into detection so a branded project with generically-named
        # layers still auto-detects (only ever a default; the picker overrides).
        bn = project.baseName()
        if bn:
            names = names + [bn]
    except Exception:
        names = []
    try:
        try:
            from ..kml_export import detect_client
        except ImportError:
            from fibre_automation.kml_export import detect_client
        key = detect_client(names)
        return key if key in _VALID else "fibertime"
    except Exception:
        return "fibertime"


# ── normalisers ──────────────────────────────────────────────────────────────
def _from_mml_dict(d, client):
    """Fibertime MML (and any future dict-returning builder) → uniform dict."""
    return {
        "client": client, "label": _LABEL.get(client, client),
        "format": "Fibertime Master Material List",
        "out_path": d.get("path"),
        "lines": d.get("lines", 0),
        "verdict": d.get("verdict", "OK"),
        "findings": list(d.get("findings", [])),
        "diag": d.get("diag", {}) or {},
        "stub": False,
    }


def _from_boqresult(res, client, fmt, stub, extra_findings=None):
    """Generic engine BoQResult → uniform dict (used for Vuma/Generic + HeroTel stub)."""
    diag = {}
    try:
        for ln in res.lines:
            if ln.get("key") == "ont":
                diag["ont"] = diag.get("ont", 0) + (ln.get("count") or 0)
            elif ln.get("key") == "pole":
                diag["poles"] = diag.get("poles", 0) + (ln.get("count") or 0)
    except Exception:
        pass
    findings = list(extra_findings or [])
    try:
        # surface only the audit rows that matter (non-OK) as (status, msg) pairs
        for a in res.audit:
            if a.get("status") not in (None, "OK"):
                findings.append((a["status"], f'{a["check"]}: {a["detail"]}'))
    except Exception:
        pass
    return {
        "client": client, "label": _LABEL.get(client, client),
        "format": fmt,
        "out_path": (res.meta or {}).get("out_path"),
        "lines": len(res.lines),
        "verdict": res.verdict,
        "findings": findings,
        "diag": diag,
        "stub": stub,
    }


# ── the single entry point ────────────────────────────────────────────────────
def run_client_boq(client, out_path=None, project=None):
    """Build the BoQ for `client`, write it to `out_path`, return the uniform dict.

    Raises only on a genuine builder failure (the caller keeps its own try/except
    fallback). A not-yet-built client format is NOT an error — it routes to the
    generic priced engine and is flagged stub=True.
    """
    client = client if client in _VALID else "fibertime"

    if client == "fibertime":
        try:
            from .fibertime_mml import run_fibertime_boq
        except ImportError:
            from fibre_automation.boq.fibertime_mml import run_fibertime_boq
        return _from_mml_dict(run_fibertime_boq(out_path=out_path, project=project), client)

    if client == "herotel":
        # Phase 2 drops in herotel_boq.py; until then, route to the generic engine
        # and say so plainly (never a silent Fibertime bill).
        try:
            try:
                from .herotel_boq import run_herotel_boq
            except ImportError:
                from fibre_automation.boq.herotel_boq import run_herotel_boq
        except ImportError:
            run_herotel_boq = None
        if run_herotel_boq is not None:
            r = run_herotel_boq(out_path=out_path, project=project)
            if isinstance(r, dict):
                out = _from_mml_dict(r, client)
                out["format"] = "HeroTel BoQ"
                return out
            return _from_boqresult(r, client, "HeroTel BoQ", stub=False)
        # stub fallback
        from . import run_boq
        res = run_boq(out_path=out_path, project=project)
        return _from_boqresult(
            res, client, "Generic priced BoQ (HeroTel approved format not built yet)",
            stub=True,
            extra_findings=[("WARN",
                             "HeroTel approved BoQ format is not built yet — this is the "
                             "generic priced BoQ. Provide the reference bill to build it.")])

    # vuma / generic → generic priced engine
    from . import run_boq
    res = run_boq(out_path=out_path, project=project)
    stub = (client == "vuma")
    fmt = ("Generic priced BoQ (Vuma approved format not built yet)"
           if stub else "Generic priced BoQ")
    extra = ([("WARN", "Vuma approved BoQ format is not built yet — this is the "
                       "generic priced BoQ.")] if stub else None)
    return _from_boqresult(res, client, fmt, stub=stub, extra_findings=extra)
