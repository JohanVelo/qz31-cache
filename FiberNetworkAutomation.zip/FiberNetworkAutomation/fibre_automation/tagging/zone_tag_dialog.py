"""zone_tag_dialog — the "Tag by PON / Phase" UI.

Kept OUT of network_planner/dock_widget.py (already ~15.7k lines) and out of
``zone_tag`` itself (which stays Qt-free + unit-testable). The dock owns one
button; everything else lives here.

Flow:  pick polygon layers + targets  →  Preview (read-only)  →  Apply.
Nothing is written until Apply — JJ's call 2026-07-15, because Apply adds a real
field to a real file on live client data. Ticked layers sharing a column name merge
into one column (plan e4e8f0bb, 2026-11-05).

Qt6 rules honoured throughout: qgis.PyQt shim only, fully-scoped enums,
``from qgis.PyQt import sip``, QMetaType for field types.
"""
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QFont
from qgis.PyQt.QtWidgets import (QAbstractItemView, QApplication, QCheckBox,
                                 QComboBox, QDialog, QFrame, QGridLayout,
                                 QHBoxLayout, QHeaderView, QLabel, QLineEdit,
                                 QListWidget, QListWidgetItem, QMessageBox,
                                 QPushButton, QScrollArea, QTableWidget,
                                 QTableWidgetItem, QVBoxLayout, QWidget)

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

try:
    from . import zone_tag
except ImportError:                                    # flat / path import
    import zone_tag


# ── theming (same layered pattern as labeling_wizard._theme_colors) ──────────
def _theme_colors(widget=None):
    """theme_safe.colors() with layered imports; palette fallback if absent.

    NB the dot-count: theme_safe lives in the FiberNetworkAutomation package and
    this module is TWO levels down (fibre_automation/tagging/), so the bundled
    path is ``...`` — not the ``..`` labeling_wizard.py uses from one level up.
    Getting this wrong doesn't crash, it silently drops to the crude fallback
    palette, which is exactly the kind of "looks fine to me" theming bug the
    light-mode readability rule exists to stop.
    """
    for imp in ("grandparent", "absolute", "parent", "flat"):
        try:
            if imp == "grandparent":
                from ... import theme_safe             # bundled: FNA/fibre_automation/tagging
            elif imp == "absolute":
                from FiberNetworkAutomation import theme_safe
            elif imp == "parent":
                from .. import theme_safe
            else:
                import theme_safe
            return theme_safe.colors(widget)
        except Exception:
            _swallowed_note(); continue
    return {"bg": "#ffffff", "ink": "#000000", "muted": "#444444",
            "accent": "#006688", "warn": "#885500", "ok": "#116633",
            "bad": "#aa2222"}


_BTN = ("QPushButton {{ background-color: {bg}; color: white; font-weight: bold; "
        "padding: 7px 18px; border-radius: 5px; }}"
        "QPushButton:hover {{ background-color: {hov}; }}"
        "QPushButton:disabled {{ background-color: #777; color: #ddd; }}")


def _geom_name(layer):
    from qgis.core import QgsWkbTypes
    try:
        return {QgsWkbTypes.PointGeometry: "Point",
                QgsWkbTypes.LineGeometry: "Line",
                QgsWkbTypes.PolygonGeometry: "Polygon"}.get(
                    QgsWkbTypes.geometryType(layer.wkbType()), "?")
    except Exception:
        return "?"


def _hline(colors):
    line = QFrame()
    line.setFrameShape(QFrame.Shape.HLine)
    line.setStyleSheet(f"color:{colors['muted']};")
    return line


def _section(text, colors):
    lbl = QLabel(text)
    lbl.setStyleSheet(f"color:{colors['muted']};font-size:9pt;font-weight:bold;"
                      "letter-spacing:1px;")
    return lbl


# Item data: target list rows keep their layer id and name.
NAME_ROLE = Qt.ItemDataRole.UserRole + 1
_SAMPLE_VALUES = 3
_SAMPLE_SCAN = 200


def _value_samples(layer, field):
    """A few distinct values of a field, so the planner sees what it holds."""
    if not field or layer.fields().indexOf(field) < 0:
        return "no values"
    seen = []
    for i, feat in enumerate(layer.getFeatures()):
        if i >= _SAMPLE_SCAN or len(seen) >= _SAMPLE_VALUES:
            break
        val = zone_tag._tag_value(feat[field])
        if val and val not in seen:
            seen.append(val)
    return ", ".join(seen) if seen else "all blank"


def _state_text(project, polys):
    """What to say when there is nothing to tag with. "" when all is well."""
    if polys:
        return ""
    n = len(project.mapLayers())
    if not n:
        return ("⚠ No project is open, or it has no layers. Open your project, "
                "then open this tool again.")
    return (f"⚠ This project has {n} layer{'' if n == 1 else 's'} but no polygon layers to take "
            f"values from. Add your PON or Phase polygons, then open this tool again.")


def confirm_text(plan):
    """The Apply question. States exactly what this plan does, per mode."""
    new, reused, filled, over = set(), set(), set(), []
    for lid, cols in plan.out_fields.items():
        for col in cols:
            info = plan.col_info[lid][col]
            action = info["action"]
            if action == "new":
                new.add(col)
            elif action == "reuse":
                reused.add(col)
            elif action == "fill":
                filled.add(col)
            elif action == "overwrite":
                over.append(f"{col} (old values kept in {info['old']})")
    names = ", ".join(plan.layer_names[lid] for lid in plan.rows)
    lines = []
    if new:
        lines.append("Add new column(s): " + ", ".join(sorted(new)))
    if reused:
        lines.append("Fill empty column(s): " + ", ".join(sorted(reused)))
    if filled:
        lines.append("Fill blanks in: " + ", ".join(sorted(filled)))
    if over:
        lines.append("OVERWRITE: " + ", ".join(sorted(set(over))))
    lines.append(f"On: {names}")
    lines.append(f"Features to fill: {plan.total_features:,}")
    lines.append("")
    lines.append("This saves to the layer files on disk, and QGIS Undo will not reverse it.")
    if over or filled:
        lines.append("Values in the columns named above change. Geometry and all other columns stay.")
    else:
        lines.append("Your existing columns and geometry are not touched.")
    lines.append("A new column can be removed under layer Properties > Fields.")
    lines.append("")
    lines.append("Continue?")
    return "\n".join(lines)


# ── main dialog ──────────────────────────────────────────────────────────────
class ZoneTagDialog(QDialog):
    """Pick polygon layers + targets → preview → apply."""

    def __init__(self, project, parent=None):
        super().__init__(parent)
        self.project = project
        self._c = _theme_colors(self)
        self._poly_rows = []      # (layer, QCheckBox, QComboBox, QLineEdit, sample QLabel)

        self.setWindowTitle("Tag by PON / Phase")
        self.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
            Qt.WindowType.WindowCloseButtonHint |
            Qt.WindowType.CustomizeWindowHint |
            Qt.WindowType.WindowMaximizeButtonHint)
        self.setMinimumSize(860, 640)
        self._build()

    # ── construction ─────────────────────────────────────────────────────────
    def _build(self):
        c = self._c
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(9)

        title = QLabel("🏷  Tag by PON / Phase")
        f = QFont()
        f.setBold(True)
        f.setPointSize(14)
        title.setFont(f)
        title.setStyleSheet(f"color:{c['accent']};")
        lay.addWidget(title)

        sub = QLabel("Adds a column to each layer you pick, saying which area every feature "
                     "falls in. Ticked layers with the same New column name merge into one "
                     "column. Cables list every zone they cross. Nothing is written until you "
                     "press Apply.")
        sub.setWordWrap(True)
        sub.setStyleSheet(f"color:{c['muted']};font-size:9pt;")
        lay.addWidget(sub)
        lay.addWidget(_hline(c))

        # ── TAG WITH (polygon layers) ──
        lay.addWidget(_section("// TAG WITH", c))
        polys = zone_tag.polygon_layers(self.project)
        self._state_label = QLabel(_state_text(self.project, polys))
        self._state_label.setWordWrap(True)
        self._state_label.setStyleSheet(f"color:{c['warn']};")
        self._state_label.setVisible(bool(self._state_label.text()))
        lay.addWidget(self._state_label)
        lay.addWidget(self._poly_area(polys), 1)

        # ── ADD THE FIELD TO (targets) ──
        lay.addWidget(_section("// ADD THE FIELD TO", c))
        self._targets = QListWidget()
        self._targets.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self._targets.itemChanged.connect(lambda _i: self._refresh_enabled())
        lay.addWidget(self._targets, 1)

        sel_row = QHBoxLayout()
        for text, state in (("Select all", Qt.CheckState.Checked),
                            ("None", Qt.CheckState.Unchecked)):
            b = QPushButton(text)
            b.setStyleSheet("QPushButton { padding: 3px 10px; }")
            b.clicked.connect(lambda _=False, s=state: self._set_all_targets(s))
            sel_row.addWidget(b)
        sel_row.addStretch(1)
        self._count_lbl = QLabel("")
        self._count_lbl.setStyleSheet(f"color:{c['muted']};font-size:9pt;")
        sel_row.addWidget(self._count_lbl)
        lay.addLayout(sel_row)

        conflict_row = QHBoxLayout()
        conflict_lbl = QLabel("If a layer already has that column with data in it:")
        conflict_lbl.setStyleSheet(f"color:{c['ink']};font-size:9pt;")
        self._conflict = QComboBox()
        self._conflict.addItem("Leave it alone, add a new column", "new")
        self._conflict.addItem("Fill only its blanks", "fill")
        self._conflict.addItem("Overwrite it (old values copied, file backed up)", "overwrite")
        conflict_row.addWidget(conflict_lbl)
        conflict_row.addWidget(self._conflict)
        conflict_row.addStretch(1)
        lay.addLayout(conflict_row)

        lay.addWidget(_hline(c))

        # ── buttons ──
        btns = QHBoxLayout()
        cancel = QPushButton("Cancel")
        cancel.setStyleSheet(_BTN.format(bg="#6b5320", hov="#8a6c2a"))
        cancel.clicked.connect(self.reject)
        self._hint = QLabel("")
        self._hint.setStyleSheet(f"color:{c['muted']};font-size:9pt;")
        self._preview_btn = QPushButton("Preview ▸")
        self._preview_btn.setStyleSheet(_BTN.format(bg="#1a6b3c", hov="#238a4f"))
        self._preview_btn.setDefault(True)
        self._preview_btn.clicked.connect(self._on_preview)
        btns.addWidget(cancel)
        btns.addStretch(1)
        btns.addWidget(self._hint)
        btns.addWidget(self._preview_btn)
        lay.addLayout(btns)

        self._rebuild_targets()

    def _poly_area(self, polys):
        """Scrollable grid: [x] Layer | value field | what it holds | new column."""
        c = self._c
        host = QWidget()
        grid = QGridLayout(host)
        grid.setContentsMargins(2, 2, 2, 2)
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(5)
        for col, text in enumerate(("", "Layer", "Value field", "Holds", "New column")):
            h = QLabel(text)
            h.setStyleSheet(f"color:{c['muted']};font-size:8.5pt;font-weight:bold;")
            grid.addWidget(h, 0, col)

        for row, (lyr, hinted) in enumerate(polys, start=1):
            cb = QCheckBox()
            cb.setChecked(bool(hinted))        # PONs / Phases that name their areas
            cb.stateChanged.connect(lambda _s: self._rebuild_targets())
            name = QLabel(f"{lyr.name()}   ({lyr.featureCount():,})")

            combo = QComboBox()
            for fld in lyr.fields():
                combo.addItem(fld.name())
            guess = zone_tag.guess_value_field(lyr)
            i = combo.findText(guess) if guess else -1
            if i >= 0:
                combo.setCurrentIndex(i)

            sample = QLabel(_value_samples(lyr, combo.currentText()))
            sample.setStyleSheet(f"color:{c['muted']};font-size:8.5pt;")
            sample.setMaximumWidth(220)
            sample.setWordWrap(True)

            shp = zone_tag.is_shapefile(lyr)
            edit = QLineEdit(zone_tag.guess_out_field(lyr, combo.currentText(), shapefile=shp))
            edit.setMaximumWidth(130)
            if shp:
                edit.setToolTip("This layer is a shapefile: column names are capped at 10 characters.")
            combo.currentTextChanged.connect(
                lambda txt, l=lyr, s=sample: s.setText(_value_samples(l, txt)))

            for col, w in enumerate((cb, name, combo, sample, edit)):
                grid.addWidget(w, row, col)
            self._poly_rows.append((lyr, cb, combo, edit, sample))

        grid.setColumnStretch(1, 1)
        grid.setRowStretch(len(polys) + 1, 1)

        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setWidget(host)
        area.setMaximumHeight(210)
        return area

    # ── state ────────────────────────────────────────────────────────────────
    def _rebuild_targets(self):
        """Every layer with geometry, minus the ones ticked as a source. Keeps ticks."""
        ticked = set(self._checked_target_ids())
        sources = {lyr.id() for lyr, cb, *_ in self._poly_rows if cb.isChecked()}
        self._targets.blockSignals(True)
        self._targets.clear()
        for lyr in zone_tag.target_layers(self.project):
            if lyr.id() in sources or not lyr.isSpatial():
                continue
            it = QListWidgetItem(f"{lyr.name()}     ·  {lyr.featureCount():,} "
                                 f"·  {_geom_name(lyr)}")
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(Qt.CheckState.Checked if lyr.id() in ticked else Qt.CheckState.Unchecked)
            it.setData(Qt.ItemDataRole.UserRole, lyr.id())
            it.setData(NAME_ROLE, lyr.name())
            self._targets.addItem(it)
        self._targets.blockSignals(False)
        self._refresh_enabled()

    def _set_all_targets(self, state):
        for i in range(self._targets.count()):
            self._targets.item(i).setCheckState(state)

    def _checked_target_ids(self):
        out = []
        for i in range(self._targets.count()):
            it = self._targets.item(i)
            if it.checkState() == Qt.CheckState.Checked:
                out.append(it.data(Qt.ItemDataRole.UserRole))
        return out

    def _specs(self):
        specs = []
        for lyr, cb, combo, edit, _sample in self._poly_rows:
            if cb.isChecked():
                specs.append(zone_tag.TagSpec(lyr.id(), combo.currentText(),
                                              edit.text().strip()))
        return specs

    def _refresh_enabled(self):
        n_t = len(self._checked_target_ids())
        n_p = sum(1 for _l, cb, *_ in self._poly_rows if cb.isChecked())
        self._count_lbl.setText(f"{n_t} layer{'' if n_t == 1 else 's'} selected")
        self._preview_btn.setEnabled(bool(n_t and n_p))
        if not n_p:
            self._hint.setText("Tick at least one polygon layer under Tag With.")
        elif not n_t:
            self._hint.setText("Tick at least one layer to add the column to.")
        else:
            self._hint.setText("")

    def _build_plan(self):
        return zone_tag.build_plan(self.project, self._specs(), self._checked_target_ids(),
                                   merged=True, on_conflict=self._conflict.currentData())

    # ── preview ──────────────────────────────────────────────────────────────
    def _on_preview(self):
        if not self._specs() or not self._checked_target_ids():
            return

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            plan = self._build_plan()
        except Exception as exc:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "Tag by PON / Phase",
                                 f"Could not work out the tags:\n{exc}")
            return
        QApplication.restoreOverrideCursor()

        if not plan.rows:
            notes = plan.errors + plan.warnings
            QMessageBox.warning(self, "Tag by PON / Phase",
                                "Nothing to do:\n\n• " + "\n• ".join(notes[:20]))
            return

        dlg = PreviewDialog(self.project, plan, parent=self)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.accept()          # applied → close the picker too


# ── preview ──────────────────────────────────────────────────────────────────
class PreviewDialog(QDialog):
    """Shows exactly what WOULD be written, then writes it on Apply."""

    def __init__(self, project, plan, parent=None):
        super().__init__(parent)
        self.project = project
        self.plan = plan
        self._c = _theme_colors(self)

        self.setWindowTitle("Tag by PON / Phase — preview")
        self.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
            Qt.WindowType.WindowCloseButtonHint |
            Qt.WindowType.CustomizeWindowHint |
            Qt.WindowType.WindowMaximizeButtonHint)
        self.setMinimumSize(880, 640)
        self._build()

    def _build(self):
        c = self._c
        plan = self.plan
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(9)

        title = QLabel("PREVIEW — nothing has been written yet")
        f = QFont()
        f.setBold(True)
        f.setPointSize(13)
        title.setFont(f)
        title.setStyleSheet(f"color:{c['accent']};")
        lay.addWidget(title)

        srcs = []
        for col, parts in plan.sources.items():
            shown = ", ".join(parts[:3]) + (f" and {len(parts) - 3} more" if len(parts) > 3 else "")
            srcs.append(f"{col} ← {shown}")
        took = ("instantly" if plan.elapsed_s < 0.05
                else f"in {plan.elapsed_s:.1f}s")
        sub = QLabel("   ·   ".join(srcs) + f"   ·   computed {took}")
        sub.setStyleSheet(f"color:{c['muted']};font-size:9pt;")
        sub.setWordWrap(True)
        lay.addWidget(sub)

        # One bounded list: a project with 80 layers must not push the table off screen.
        self._notes = QListWidget()
        self._notes.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self._notes.setMaximumHeight(210)
        self._note_lines(plan.errors, "✖  ", c["bad"])
        self._note_lines(plan.warnings, "⚠  ", c["warn"])
        self._note_lines(plan.summary_lines(), "•  ", c["ink"])
        self._note_lines(self._value_lines(), "    ", c["muted"])
        lay.addWidget(self._notes)

        lay.addWidget(_hline(c))
        lay.addWidget(self._table(), 1)

        cap = QLabel(f"Showing up to {plan.SAMPLE_CAP} rows per layer. "
                     f"Apply writes all {plan.total_features:,}.")
        cap.setStyleSheet(f"color:{c['muted']};font-size:8.5pt;")
        lay.addWidget(cap)

        self._backup = QCheckBox("Back up the layer's file first (saved beside it)")
        self._backup.setChecked(any(zone_tag._layer_file(self.project.mapLayer(lid))
                                    for lid in plan.rows if self.project.mapLayer(lid)))
        self._backup.setToolTip("Restoring a backup reverts every layer in that file.")
        lay.addWidget(self._backup)

        btns = QHBoxLayout()
        back = QPushButton("Cancel")
        back.setStyleSheet(_BTN.format(bg="#6b5320", hov="#8a6c2a"))
        back.clicked.connect(self.reject)
        btns.addWidget(back)
        btns.addStretch(1)
        self._add_action_buttons(btns)
        lay.addLayout(btns)

    def _note_lines(self, lines, mark, color):
        from qgis.PyQt.QtGui import QBrush, QColor
        for line in lines:
            it = QListWidgetItem(mark + line)
            it.setForeground(QBrush(QColor(color)))
            self._notes.addItem(it)

    def _value_lines(self):
        """Per layer and column: how many features took each value."""
        out = []
        for lid, per in self.plan.value_counts.items():
            for col, counts in per.items():
                if not counts:
                    continue
                ordered = sorted(counts, key=zone_tag._natural_key)
                shown = ", ".join(f"{v}: {counts[v]}" for v in ordered[:12])
                more = f" and {len(ordered) - 12} more" if len(ordered) > 12 else ""
                out.append(f"{self.plan.layer_names.get(lid, lid)}.{col}  {shown}{more}")
        return out

    def _add_action_buttons(self, btns):
        n_lyr = len(self.plan.rows)
        self._apply_btn = QPushButton(
            f"✔  Apply to {n_lyr} layer{'' if n_lyr == 1 else 's'}")
        self._apply_btn.setStyleSheet(_BTN.format(bg="#1a6b3c", hov="#238a4f"))
        self._apply_btn.setDefault(True)
        self._apply_btn.setEnabled(bool(self.plan.rows))
        self._apply_btn.clicked.connect(self._on_apply)
        btns.addWidget(self._apply_btn)

    # ── apply ────────────────────────────────────────────────────────────────
    def _on_apply(self):
        """Write the previewed plan. The only path in this feature that mutates."""
        plan = self.plan
        backup = self._backup.isChecked()      # capture before any modal (Qt6 lifetime rule)

        ok = QMessageBox.question(
            self, "Apply tags?", confirm_text(plan),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Cancel)
        if ok != QMessageBox.StandardButton.Yes:
            return

        self._apply_btn.setEnabled(False)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            res = zone_tag.apply_plan(self.project, plan, backup=backup)
        except Exception as exc:
            QApplication.restoreOverrideCursor()
            self._apply_btn.setEnabled(True)
            QMessageBox.critical(self, "Tag by PON / Phase",
                                 f"The write failed:\n{exc}")
            return
        QApplication.restoreOverrideCursor()

        msg = []
        if res.written:
            msg.append("Tagged " + " · ".join(
                f"{res.layer_names.get(lid, lid)} ({n:,})"
                for lid, n in res.written.items()))
        if res.fields_added:
            msg.append("Added: " + ", ".join(res.fields_added))
        for b in res.backups:
            msg.append("Backup: " + b)
        for s in res.skipped:
            msg.append("Skipped: " + s)
        for e in res.errors:
            msg.append("✖ " + e)

        if res.errors or res.skipped:
            title = "partly done" if res.written else "not done"
            QMessageBox.warning(self, f"Tag by PON / Phase — {title}", "\n\n".join(msg))
        else:
            QMessageBox.information(
                self, "Tag by PON / Phase",
                "✔  Done — " + f"{res.total_written:,} features tagged.\n\n"
                + "\n\n".join(msg)
                + "\n\nOpen the attribute table to see the new column.")
        self.accept()

    def _table(self):
        """One table, layers stacked, with a header row per layer."""
        plan = self.plan
        fields = []
        for lid in plan.rows:
            for f in plan.out_fields.get(lid, []):
                if f not in fields:
                    fields.append(f)

        rows = []
        for lid, samples in plan.samples.items():
            rows.append(("__header__", plan.layer_names.get(lid, ""), None))
            for s in samples:
                rows.append(("row", s, lid))

        tbl = QTableWidget(len(rows), 1 + len(fields))
        tbl.setHorizontalHeaderLabels(["Feature"] + fields)
        tbl.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        tbl.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        tbl.verticalHeader().setVisible(False)
        tbl.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.ResizeMode.ResizeToContents)

        for r, (kind, payload, _lid) in enumerate(rows):
            if kind == "__header__":
                it = QTableWidgetItem(f"▸ {payload}")
                fnt = it.font()
                fnt.setBold(True)
                it.setFont(fnt)
                tbl.setItem(r, 0, it)
                tbl.setSpan(r, 0, 1, 1 + len(fields))
                continue
            tbl.setItem(r, 0, QTableWidgetItem(str(payload.get("label") or "")))
            for col, fld in enumerate(fields, start=1):
                if fld not in payload:
                    it = QTableWidgetItem("—")
                    it.setForeground(_grey())
                else:
                    val = payload.get(fld)
                    it = QTableWidgetItem("(outside)" if val is None else str(val))
                    if val is None:
                        it.setForeground(_grey())
                tbl.setItem(r, col, it)
        for col in range(1, 1 + len(fields)):
            tbl.horizontalHeader().setSectionResizeMode(
                col, QHeaderView.ResizeMode.Stretch)
        return tbl


def _grey():
    from qgis.PyQt.QtGui import QBrush, QColor
    return QBrush(QColor("#888888"))


# ── entry point (what the dock button calls) ─────────────────────────────────
def open_dialog(parent=None, project=None):
    from qgis.core import QgsProject
    project = project or QgsProject.instance()
    dlg = ZoneTagDialog(project, parent=parent)
    dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
    dlg.exec()
