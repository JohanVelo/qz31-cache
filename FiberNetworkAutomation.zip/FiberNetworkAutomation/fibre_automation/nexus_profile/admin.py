"""admin — owner-only read queries + owner actions for the Team Monitor.

Uses the admin READ key (never shipped; from JJ's QgsSettings). All reads are
async via Backend.admin_get; results come back through callbacks. Owner write
actions (deactivate / reset token / announce) also use the admin key.
"""
import uuid

from . import config


def _admin_key():
    try:
        from qgis.core import QgsSettings
        return QgsSettings().value(
            f"{config.SETTINGS_NS}/{config.KEY_ADMIN_READ}") or ""
    except Exception:
        return ""


def is_admin(profile):
    """Team Monitor opens only for the owner. The admin SECRET key never ships
    and only JJ has it — its presence on this machine IS proof of ownership.
    (A signed-in profile is also required so a name shows in the UI.)"""
    if profile is None:
        return False
    return bool(_admin_key())


class Admin:
    def __init__(self, backend):
        self.backend = backend
        self.key = _admin_key()

    # ── reads (callbacks get a list of dict rows, or None) ──────────────────
    def online_now(self, cb):
        # Presence = '__heartbeat__' events (INSERT-based; anon UPDATE is a no-op
        # under insert-only RLS). The monitor keeps the latest per user within
        # the online window — that row also carries their current version.
        self.backend.admin_get(
            "events?action_id=eq.__heartbeat__&select=username,plugin_version,"
            "project_name,inserted_at&order=inserted_at.desc&limit=300",
            self.key, cb)

    def installs(self, cb):
        self.backend.admin_get(
            "installs?select=install_id,username,plugin_version,qgis_version,"
            "created_at,last_heartbeat&order=last_heartbeat.desc",
            self.key, cb)

    def recent_events(self, cb, limit=60):
        # Exclude '__heartbeat__' presence events from the Activity feed.
        self.backend.admin_get(
            f"events?action_id=neq.__heartbeat__&select=username,action_id,"
            f"category,project_name,inserted_at&order=inserted_at.desc"
            f"&limit={limit}",
            self.key, cb)

    def recent_errors(self, cb, limit=40):
        self.backend.admin_get(
            f"errors?select=*&order=inserted_at.desc&limit={limit}",
            self.key, cb)

    def users(self, cb):
        self.backend.admin_get(
            "users?select=username,display_name,is_active,created_at,"
            "plugin_version&order=created_at.desc",
            self.key, cb)

    # ── owner actions (write with admin key) ────────────────────────────────
    def deactivate(self, username, active=False, cb=None):
        self._patch(f"users?username=eq.{username}",
                    {"is_active": active}, cb)

    def mark_error_resolved(self, error_id, resolved=True, cb=None):
        self._patch(f"errors?error_id=eq.{error_id}",
                    {"resolved": resolved}, cb)

    def issue_reset_token(self, username, ttl_minutes=60, cb=None):
        """Owner generates a one-time reset token for a user."""
        token = uuid.uuid4().hex[:8].upper()
        from datetime import datetime, timedelta, timezone
        expires = (datetime.now(timezone.utc)
                   + timedelta(minutes=ttl_minutes)).isoformat()
        self._post("password_reset_tokens",
                   {"token": token, "username": username,
                    "expires_at": expires},
                   lambda ok, t=token: cb(t if ok else None) if cb else None)
        return token

    def announce(self, title, message, expires_at=None, cb=None):
        self._post("announcements",
                   {"title": title, "message": message,
                    "created_by": config.ADMIN_USERNAME,
                    "expires_at": expires_at}, cb)

    # ── low-level admin writes ──────────────────────────────────────────────
    def _post(self, table, payload, cb=None):
        self._req("POST", table, payload, cb)

    def _patch(self, query, payload, cb=None):
        self._req("PATCH", query, payload, cb)

    def prune_heartbeats(self, minutes=30):
        """Delete '__heartbeat__' presence events older than `minutes` — they
        have no value as history (presence only needs the online window), so
        this keeps the events table small under the free tier. Admin-only."""
        try:
            from datetime import datetime, timedelta, timezone
            cutoff = (datetime.now(timezone.utc)
                      - timedelta(minutes=minutes)).isoformat()
            self._req("DELETE",
                      f"events?action_id=eq.__heartbeat__&inserted_at=lt.{cutoff}",
                      None, None)
        except Exception:
            pass

    def _req(self, method, path, payload, cb):
        try:
            import json
            from qgis.core import QgsNetworkAccessManager
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtNetwork import QNetworkRequest
        except Exception:
            if cb:
                cb(False)
            return
        req = QNetworkRequest(QUrl(f"{config.SUPABASE_URL}/rest/v1/{path}"))
        req.setHeader(QNetworkRequest.KnownHeaders.ContentTypeHeader, "application/json")
        req.setRawHeader(b"apikey", self.key.encode())
        req.setRawHeader(b"Authorization", f"Bearer {self.key}".encode())
        req.setRawHeader(b"Prefer", b"return=minimal")
        body = json.dumps(payload).encode("utf-8") if payload is not None else b""
        try:
            nam = QgsNetworkAccessManager.instance()
            if method == "POST":
                reply = nam.post(req, body)
            else:
                reply = nam.sendCustomRequest(req, method.encode(), body)

            def _done(r=reply):
                ok = False
                try:
                    ok = int(r.error()) == 0
                except Exception:
                    pass
                if cb:
                    cb(ok)
                try:
                    r.deleteLater()
                except Exception:
                    pass

            reply.finished.connect(_done)
        except Exception:
            if cb:
                cb(False)
