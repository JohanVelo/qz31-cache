"""login — MANDATORY per-user sign-in + owner-mediated password reset.

The plugin historically authenticated its my_* reads with a spoofable username
param. This dialog asks the operator for their password, exchanges it for an HMAC
token at the edge fn (/plugin-login), and stores it (backend.set_user_token).
After that the notifications / resolved-ticket reads are identity-verified.

maybe_prompt_login() prompts at EVERY startup until the operator signs in (no
one-time opt-out), driving ~100% token adoption so the anon RPCs can be locked.
Safe: declining defers one session, an unreachable server lets them defer, and
core FTTH work is never blocked (anon fallback covers the gap until they sign in).

Forgot-password (owner-mediated — there is no email/SMS): the user requests a
reset (the owner is pinged on Telegram to issue an 8-char code from the Team
Monitor), then enters that code + a new password here. The new password is hashed
LOCALLY (hashing.py) so plaintext never leaves the laptop; the edge fn validates
the one-time code and stores the new hash, then signs the user straight in.
"""
from . import backend as _backend
from . import hashing

# House dark style — matches first_run.py / profile_card.py for a consistent look.
_QSS = """
QDialog { background:#0F1A30; }
QLabel { color:#EAF0FF; font-size:13px; }
QLabel#hdr { color:#FFFFFF; font-size:18px; font-weight:800; }
QLabel#sub { color:#9FB4C8; font-size:12px; }
QLabel#err { color:#E0607A; font-size:12px; }
QLabel#ok  { color:#36D399; font-size:13px; font-weight:700; }
QLineEdit { background:#141E36; color:#EAF0FF; border:1px solid #243352;
            border-radius:8px; padding:8px 10px; font-size:13px; }
QLineEdit:focus { border:1px solid #2ec4f1; }
QPushButton#primary { background:#2ec4f1; color:#06121C; border:none;
            border-radius:8px; padding:9px 16px; font-weight:800; }
QPushButton#primary:hover { background:#5FD6FF; }
QPushButton#primary:disabled { background:#1c4a59; color:#6b8a96; }
QToolButton#eye { background:#141E36; color:#9FB4C8; border:1px solid #243352;
            border-radius:8px; padding:6px 8px; }
QToolButton#eye:checked { color:#2ec4f1; }
QPushButton#link { background:transparent; color:#9FB4C8; border:none;
            text-decoration:underline; padding:4px; font-size:12px; }
QPushButton#link:hover { color:#2ec4f1; }
"""


def has_token():
    return bool(_backend.get_user_token())


def _pw_row(placeholder):
    """A password QLineEdit + an inline show/hide toggle. Returns (row, line)."""
    from qgis.PyQt.QtWidgets import QHBoxLayout, QLineEdit, QToolButton, QWidget
    row = QWidget()
    h = QHBoxLayout(row)
    h.setContentsMargins(0, 0, 0, 0)
    h.setSpacing(6)
    line = QLineEdit()
    line.setEchoMode(QLineEdit.EchoMode.Password)
    line.setPlaceholderText(placeholder)
    eye = QToolButton()
    eye.setObjectName("eye")
    eye.setCheckable(True)
    eye.setText("Show")
    eye.setToolTip("Show / hide password")

    def _toggle(on):
        line.setEchoMode(QLineEdit.EchoMode.Normal if on else QLineEdit.EchoMode.Password)
        eye.setText("Hide" if on else "Show")

    eye.toggled.connect(_toggle)
    h.addWidget(line, 1)
    h.addWidget(eye)
    return row, line


def show_login_dialog(parent, backend, username, display_name=None, mandatory=False):
    """Themed sign-in dialog with a forgot-password flow. Returns True once a
    token exists. Declining never bricks the plugin / blocks core work."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (
        QDialog, QVBoxLayout, QLabel, QPushButton, QHBoxLayout, QStackedWidget,
        QWidget, QLineEdit)

    dlg = QDialog(parent)
    dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
    dlg.setStyleSheet(_QSS)
    dlg.setWindowTitle("Velocity Nexus — Sign in")
    dlg.setMinimumWidth(420)
    outer = QVBoxLayout(dlg)
    outer.setContentsMargins(22, 20, 22, 18)
    outer.setSpacing(12)

    state = {"ok": False}
    alive = {"v": True}
    dlg.destroyed.connect(lambda *_: alive.__setitem__("v", False))

    stack = QStackedWidget()
    outer.addWidget(stack)

    # ── Page 0: sign in ──────────────────────────────────────────────────────
    pg_in = QWidget()
    vi = QVBoxLayout(pg_in)
    vi.setContentsMargins(0, 0, 0, 0)
    vi.setSpacing(10)
    hdr = QLabel("Sign in required" if mandatory else "Secure your account")
    hdr.setObjectName("hdr")
    vi.addWidget(hdr)
    sub = QLabel(f"Signing in as <b>{display_name or username}</b>. Enter your "
                 f"Velocity Nexus password so your notifications are verified as yours."
                 + ("<br><span style='color:#9FB4C8'>(Required — you can defer this "
                    "session; you'll be asked again.)</span>" if mandatory else ""))
    sub.setObjectName("sub")
    sub.setWordWrap(True)
    vi.addWidget(sub)
    pw_row, pw = _pw_row("password")
    vi.addWidget(pw_row)
    msg = QLabel("")
    msg.setObjectName("err")
    msg.setWordWrap(True)
    vi.addWidget(msg)
    forgot = QPushButton("Forgot my password?")
    forgot.setObjectName("link")
    forgot.setCursor(Qt.CursorShape.PointingHandCursor)
    fr = QHBoxLayout()
    fr.addWidget(forgot)
    fr.addStretch(1)
    vi.addLayout(fr)
    row1 = QHBoxLayout()
    btn_cancel = QPushButton("Not now" if mandatory else "Later")
    btn_login = QPushButton("Sign in")
    btn_login.setObjectName("primary")
    btn_login.setDefault(True)
    row1.addStretch(1)
    row1.addWidget(btn_cancel)
    row1.addWidget(btn_login)
    vi.addLayout(row1)
    stack.addWidget(pg_in)

    # ── Page 1: reset ────────────────────────────────────────────────────────
    pg_rs = QWidget()
    vr = QVBoxLayout(pg_rs)
    vr.setContentsMargins(0, 0, 0, 0)
    vr.setSpacing(10)
    rhdr = QLabel("Reset your password")
    rhdr.setObjectName("hdr")
    vr.addWidget(rhdr)
    rsub = QLabel("Tap <b>Request a code</b> — JJ is notified to issue you an "
                  "8-character reset code. Enter that code and a new password below.")
    rsub.setObjectName("sub")
    rsub.setWordWrap(True)
    vr.addWidget(rsub)
    btn_req = QPushButton("Request a code")
    btn_req.setObjectName("primary")
    vr.addWidget(btn_req)
    code = QLineEdit()
    code.setPlaceholderText("reset code (from JJ)")
    vr.addWidget(code)
    np_row, npw = _pw_row("new password")
    vr.addWidget(np_row)
    cp_row, cpw = _pw_row("confirm new password")
    vr.addWidget(cp_row)
    rmsg = QLabel("")
    rmsg.setObjectName("err")
    rmsg.setWordWrap(True)
    vr.addWidget(rmsg)
    row2 = QHBoxLayout()
    btn_back = QPushButton("Back to sign in")
    btn_back.setObjectName("link")
    btn_reset = QPushButton("Reset & sign in")
    btn_reset.setObjectName("primary")
    row2.addWidget(btn_back)
    row2.addStretch(1)
    row2.addWidget(btn_reset)
    vr.addLayout(row2)
    stack.addWidget(pg_rs)

    def _success(disp):
        # Brief green confirmation, then close as success.
        from qgis.PyQt.QtCore import QTimer
        state["ok"] = True
        msg.setObjectName("ok")
        msg.setStyleSheet("color:#36D399; font-weight:700;")
        msg.setText(f"✅ Success — signed in as {disp}.")
        try:
            # Guard: the user can still close the dialog within 700ms;
            # WA_DeleteOnClose would free the C++ object, so re-check liveness.
            QTimer.singleShot(700, lambda: dlg.accept() if alive["v"] else None)
        except Exception:
            try:
                dlg.accept()
            except Exception:
                pass

    # ── sign-in handler ──
    def _attempt():
        p = pw.text()
        if not p:
            msg.setText("Enter your password.")
            return
        btn_login.setEnabled(False)
        msg.setText("Signing in…")

        def _cb(ok, disp):
            if not alive["v"]:
                return
            try:
                if ok:
                    _success(disp)
                else:
                    msg.setText("Sign-in failed — wrong password, or account not "
                                "active. Try again, or reset your password.")
                    btn_login.setEnabled(True)
            except Exception:
                import traceback
                traceback.print_exc()

        try:
            backend.plugin_login(username, p, _cb)
        except Exception:
            msg.setText("Could not reach the server — try again later.")
            btn_login.setEnabled(True)

    # ── reset handlers ──
    def _request():
        btn_req.setEnabled(False)
        rmsg.setObjectName("sub")
        rmsg.setStyleSheet("color:#9FB4C8;")
        rmsg.setText("Requesting…")

        def _cb(message):
            if not alive["v"]:
                return
            rmsg.setText(message)
            btn_req.setEnabled(True)

        try:
            backend.request_reset(username, _cb)
        except Exception:
            rmsg.setText("Could not reach the server — try again later.")
            btn_req.setEnabled(True)

    def _do_reset():
        c = code.text().strip()
        n1, n2 = npw.text(), cpw.text()
        rmsg.setObjectName("err")
        rmsg.setStyleSheet("color:#E0607A;")
        if not c:
            rmsg.setText("Enter the reset code from JJ.")
            return
        if len(n1) < 4:
            rmsg.setText("New password must be at least 4 characters.")
            return
        if n1 != n2:
            rmsg.setText("The two new passwords don't match.")
            return
        try:
            pw_hash, pw_salt = hashing.hash_password(n1)   # hash LOCALLY
        except Exception:
            rmsg.setText("Could not process the password — try again.")
            return
        btn_reset.setEnabled(False)
        rmsg.setStyleSheet("color:#9FB4C8;")
        rmsg.setText("Resetting…")

        def _cb(ok, disp_or_err):
            if not alive["v"]:
                return
            try:
                if ok:
                    _success(disp_or_err)
                else:
                    rmsg.setStyleSheet("color:#E0607A;")
                    rmsg.setText(disp_or_err)
                    btn_reset.setEnabled(True)
            except Exception:
                import traceback
                traceback.print_exc()

        try:
            backend.redeem_reset(username, c, pw_hash, pw_salt, _cb)
        except Exception:
            rmsg.setStyleSheet("color:#E0607A;")
            rmsg.setText("Could not reach the server — try again later.")
            btn_reset.setEnabled(True)

    btn_login.clicked.connect(_attempt)
    pw.returnPressed.connect(_attempt)
    btn_cancel.clicked.connect(dlg.reject)
    forgot.clicked.connect(lambda: stack.setCurrentIndex(1))
    btn_back.clicked.connect(lambda: stack.setCurrentIndex(0))
    btn_req.clicked.connect(_request)
    btn_reset.clicked.connect(_do_reset)
    cpw.returnPressed.connect(_do_reset)

    dlg.exec()
    return state["ok"]


def maybe_prompt_login(parent, backend, username, display_name=None):
    """MANDATORY sign-in: prompt at every startup until a token exists. Never
    raises; declining defers this session (re-asks next launch)."""
    try:
        if not username or has_token():
            return has_token()
        return show_login_dialog(parent, backend, username, display_name,
                                 mandatory=True)
    except Exception:
        return False
