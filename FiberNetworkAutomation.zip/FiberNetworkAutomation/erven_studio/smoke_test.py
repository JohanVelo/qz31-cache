"""Phase 0 gate: prove SAM2.1 Hiera-Tiny does interactive point segmentation on the 4 GB RTX 3050.
GATE = segments a 512 px tile in < 5 s using < 3.5 GB VRAM (else fall back to CPU / smaller model)."""
import time
import numpy as np
import torch

CKPT = "C:/Temp/sam2.1_hiera_tiny.pt"
CFG = "configs/sam2.1/sam2.1_hiera_t.yaml"
TILE_NPZ = "C:/Temp/erven_work/bld_g/mosaic/mohadin.npz"


def get_tile():
    z = np.load(TILE_NPZ); mos = z["mos"]
    y, x = mos.shape[0] // 2, mos.shape[1] // 2          # centre 512 crop of the township
    return np.ascontiguousarray(mos[y:y + 512, x:x + 512])


def main():
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    img = get_tile()
    print(f"device={dev} tile={img.shape}")
    from sam2.build_sam import build_sam2
    from sam2.sam2_image_predictor import SAM2ImagePredictor

    t0 = time.time()
    sam2 = build_sam2(CFG, CKPT, device=dev)
    predictor = SAM2ImagePredictor(sam2)
    if dev == "cuda":
        torch.cuda.reset_peak_memory_stats()
    autocast = (torch.autocast("cuda", dtype=torch.bfloat16) if dev == "cuda"
                else torch.autocast("cpu", dtype=torch.bfloat16))
    t1 = time.time()
    with torch.inference_mode(), autocast:
        predictor.set_image(img)                          # encode once
        masks, scores, _ = predictor.predict(
            point_coords=np.array([[256, 256]]),          # one centre click
            point_labels=np.array([1]),
            multimask_output=True,
        )
    seg_s = time.time() - t1
    load_s = t1 - t0
    best = int(np.argmax(scores))
    vram = (torch.cuda.max_memory_allocated() / 1e9) if dev == "cuda" else 0.0
    cover = float(masks[best].mean())
    print(f"load={load_s:.1f}s  segment={seg_s:.1f}s  peak_VRAM={vram:.2f}GB  "
          f"best_score={scores[best]:.3f}  mask_cover={cover:.3f}")

    ok = (seg_s < 5.0) and (dev == "cpu" or vram < 3.5) and (0.001 < cover < 0.9)
    print("GATE:", "PASS" if ok else "FAIL",
          "(<5s segment, <3.5GB VRAM, sane mask)" if dev == "cuda" else "(CPU fallback)")
    # save a quick proof image
    import cv2
    ov = img.copy(); ov[masks[best] > 0] = (0, 255, 0)
    cv2.imwrite("C:/Temp/sam2_smoke.png", cv2.cvtColor(
        cv2.addWeighted(img, 0.6, ov, 0.4, 0), cv2.COLOR_RGB2BGR))
    print("wrote C:/Temp/sam2_smoke.png")


if __name__ == "__main__":
    main()
