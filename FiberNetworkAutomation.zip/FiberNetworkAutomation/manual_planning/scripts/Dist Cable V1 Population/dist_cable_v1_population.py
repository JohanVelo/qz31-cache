import sys, os
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')

# ============================================================
# DISTRIBUTION CABLE V1 — FULL ATTRIBUTE POPULATION
# Project: Potch - Mohadin PH2
# Reference: Distribution cable sheet from poles_potch_csv.xlsx
# Label format: MOA.DF.24F.P.[StartPole]-P.[EndPole]
# Method: For each cable line, find nearest pole to start
#         point and nearest pole to end point
# ============================================================

CABLE_LAYER = 'Distribution Cable v1'
POLES_LAYER = 'poles v1'
PON_LAYER = 'PON v1'
ZONE_LAYER = 'Zones v1'

SR = 'MOA'

# Static values from reference
STATIC = {
    'type': 'Cable',
    'subtyp': 'Mini-ADSS',
    'spec': 'SM/G657A1',
    'dim1': '5,6mm',
    'cblcpty': '24F',
    'ntwrkptn': 'Distribution',
    'cmpownr': 'VelocityFibre',
    'subplace': '676007',
    'mainplce': '676007',
    'mun': 'JB Marks Local Municipality',
    'stackref': 'MOA',
    'crtdby': 'Johan Scholtz',
}

# --- GET LAYERS ---
cable_layer = None
poles_layer = None
pon_layer = None
zone_layer = None

for lyr in QgsProject.instance().mapLayers().values():
    n = lyr.name()
    if n == CABLE_LAYER: cable_layer = lyr
    if n == POLES_LAYER: poles_layer = lyr
    if n == PON_LAYER: pon_layer = lyr
    if n == ZONE_LAYER: zone_layer = lyr

missing = []
if not cable_layer: missing.append(CABLE_LAYER)
if not poles_layer: missing.append(POLES_LAYER)
if not pon_layer: missing.append(PON_LAYER)
if not zone_layer: missing.append(ZONE_LAYER)

if missing:
    print(f"ERROR: Missing layers: {missing}")
else:
    print(f"Cable layer: {CABLE_LAYER} ({cable_layer.featureCount()} features)")
    print(f"Poles layer: {POLES_LAYER} ({poles_layer.featureCount()} features)")

    from qgis.core import QgsSpatialIndex, QgsGeometry, QgsPointXY

    # --- BUILD SPATIAL INDEX FOR POLES ---
    pole_index = QgsSpatialIndex(poles_layer.getFeatures())
    pole_feats = {f.id(): f for f in poles_layer.getFeatures()}

    # --- BUILD SPATIAL INDEX FOR PON AND ZONE ---
    pon_index = QgsSpatialIndex(pon_layer.getFeatures())
    pon_feats = {f.id(): f for f in pon_layer.getFeatures()}
    zone_index = QgsSpatialIndex(zone_layer.getFeatures())
    zone_feats = {f.id(): f for f in zone_layer.getFeatures()}

    def nearest_pole_label(point):
        candidates = pole_index.nearestNeighbor(point, 1)
        if candidates:
            feat = pole_feats[candidates[0]]
            label = str(feat['Label'])
            # Strip SR prefix: MOA.P.A423 → A423
            if '.' in label:
                parts = label.split('.')
                return parts[-1]  # e.g. A423
        return None

    def fidx(name):
        return cable_layer.fields().indexOf(name)

    # Accumulate all attribute writes into a single bulk-write map
    # (dataProvider().changeAttributeValues) instead of per-feature
    # changeAttributeValue() inside an edit session — far faster and does
    # not block the Qt main thread on large layers, and avoids silently
    # committing any pre-existing unsaved user edits.
    attr_map = {}

    processed = 0
    no_geom = 0
    sample = []

    for cable in cable_layer.getFeatures():
        geom = cable.geometry()

        if not geom or geom.isNull() or geom.isEmpty():
            no_geom += 1
            continue

        # --- GET START AND END POINTS ---
        # For a line, vertices() gives all points
        # First vertex = start, last vertex = end
        vertices = list(geom.vertices())
        if len(vertices) < 2:
            no_geom += 1
            continue

        start_pt = QgsPointXY(vertices[0].x(), vertices[0].y())
        end_pt = QgsPointXY(vertices[-1].x(), vertices[-1].y())

        # --- FIND NEAREST POLES ---
        start_pole = nearest_pole_label(start_pt)
        end_pole = nearest_pole_label(end_pt)

        # --- BUILD LABEL ---
        # Format: MOA.DF.24F.P.A423-P.A324
        if start_pole and end_pole:
            label = f'{SR}.DF.24F.P.{start_pole}-P.{end_pole}'
            strtfeat = f'{SR}.P.{start_pole}'
            endfeat = f'{SR}.P.{end_pole}'
        else:
            label = None
            strtfeat = None
            endfeat = None

        # --- ASSIGN STATIC FIELDS ---
        updates = {}
        for field, val in STATIC.items():
            idx = fidx(field)
            if idx != -1:
                updates[idx] = val

        # --- ASSIGN LABEL, STRTFEAT, ENDFEAT ---
        if label:
            updates[fidx('label')] = label
        if strtfeat:
            updates[fidx('strtfeat')] = strtfeat
        if endfeat:
            updates[fidx('endfeat')] = endfeat

        # --- PON_NO — from midpoint ---
        mid_idx = len(vertices) // 2
        mid_pt = QgsPointXY(vertices[mid_idx].x(), vertices[mid_idx].y())
        mid_geom = QgsGeometry.fromPointXY(mid_pt)

        pon_no = None
        candidates = pon_index.intersects(mid_geom.boundingBox())
        for fid in candidates:
            if pon_feats[fid].geometry().contains(mid_geom):
                pon_no = pon_feats[fid]['pon_no']
                break
        if pon_no:
            updates[fidx('pon_no')] = pon_no

        # --- ZONE_NO — from midpoint ---
        zone_no = None
        candidates = zone_index.intersects(mid_geom.boundingBox())
        for fid in candidates:
            if zone_feats[fid].geometry().intersects(mid_geom):
                zone_no = zone_feats[fid]['zone_no']
                break
        if zone_no:
            updates[fidx('zone_no')] = zone_no

        if updates:
            attr_map[cable.id()] = updates

        processed += 1
        if len(sample) < 5 and label:
            sample.append(f"  {label} | pon={pon_no} | zone={zone_no}")

    if attr_map:
        cable_layer.dataProvider().changeAttributeValues(attr_map)

    # --- SUMMARY ---
    print("=" * 55)
    print("  DISTRIBUTION CABLE V1 POPULATION COMPLETE")
    print(f"  Processed: {processed}")
    print(f"  Skipped (no geometry): {no_geom}")
    print("=" * 55)
    print("\nSample — first 5 cables:")
    for s in sample:
        print(s)
