"""Bold + marker — make the QGIS Vertex tool's midpoint "+" easy to see.

While the QGIS Vertex tool hovers a line it shows a small cross at the middle of the
segment: grey when the mouse is on the segment, red when it is close enough to grab and
add a vertex. Both colours and the 10 px size are fixed inside QGIS (qgsvertextool.cpp)
and the tool re-colours the marker on every mouse move. JJ (2026-10-29) wanted it bigger
and in colours he can see on busy imagery.

How: the marker is a QgsVertexMarker on the canvas scene, reachable from Python. While
the Vertex tool is the active map tool we listen to QgsMapCanvas.xyCoordinates, which
QGIS emits from mouseMoveEvent AFTER the map tool has handled the move, so our colour
lands before the next paint. The colour QGIS just set tells us the state (grey = near,
red = ready); we never apply exactly grey or red ourselves, so a grey/red reading always
means QGIS set it this move.

Which marker: exactly one visible QgsVertexMarker coloured QGIS grey/red whose drawn box
matches a stock QGIS cross on this screen (default 10 px, or scaleIconSize(10) - 11 px on
JJ's display; see _stock_shapes). None, or two or more, and nothing is touched.

READ-ONLY for data: no layer, feature or project is touched. Only that one canvas item's
colour/size/pen change, and they are put back (QGIS defaults) on untick, tool switch and
plugin unload.

Off switches: the "Bold + marker" tick (QgsSettings VelocityFibre/live_measure/vplus_on),
env VF_NO_VERTEX_PLUS=1, and the live tools' own kill switch (VF_NO_LIVE_MEASURE=1 or
VelocityFibre/live_measure/disabled).
"""

import math
import os
import time
import traceback

from qgis.core import Qgis, QgsMessageLog, QgsSettings
from qgis.gui import QgsMapToolAdvancedDigitizing, QgsMapToolCapture, QgsVertexMarker
from qgis.PyQt import sip
from qgis.PyQt.QtCore import QObject, Qt
from qgis.PyQt.QtGui import QColor, QFont, QFontMetrics
from qgis.PyQt.QtWidgets import QApplication

LOG_TAG = "Velocity Nexus"
PREFIX = "VelocityFibre/live_measure/"

QGIS_GREY = "#a0a0a4"   # Qt::gray, the "on the segment" colour
QGIS_RED = "#ff0000"    # Qt::red, the "ready to grab" colour
QGIS_SIZE = 10          # fallback only - the real default is measured per screen (_stock)
QGIS_PEN = 3            # ... and pen width (qgsvertextool.cpp)

DEFAULTS = {"vplus_on": "true", "vplus_near": "#ffd400", "vplus_ready": "#ff0000",
            "vplus_size": 18, "vplus_pen": 4}
SIZE_RANGE = (6, 40)
PEN_RANGE = (1, 10)
RESCAN_S = 0.1          # while no marker is adopted, scan the scene at most 10x a second

WAITING = "waiting"
ACTIVE = "active"
UNRECOGNISED = "unrecognised"
OFF = "off"


def _scale_icon_size(n):
    """Python copy of QgsGuiUtils::scaleIconSize (not exposed to PyQGIS):
    floor(max(UI_SCALE_FACTOR * font height * 1.1 * n / 24, n))."""
    try:
        f = float(getattr(Qgis, "UI_SCALE_FACTOR", 1.0))
        return int(math.floor(max(f * QFontMetrics(QFont()).height() * 1.1 * n / 24.0, n)))
    except Exception:
        return n


def _truthy(v):
    return str(v).strip().lower() in ("1", "true", "yes")


def _clamp_int(v, default, lo, hi):
    try:
        return max(lo, min(hi, int(round(float(v)))))
    except (TypeError, ValueError):
        return default


def _colour(v, default):
    c = QColor(str(v or ""))
    return c.name() if c.isValid() else default


def _safe_colour(name):
    """Never apply exactly QGIS grey/red: a grey/red reading must mean QGIS set it.
    Nudge the blue channel by one step - the eye cannot tell."""
    if name in (QGIS_GREY, QGIS_RED):
        c = QColor(name)
        c.setBlue(c.blue() + 1 if c.blue() < 255 else c.blue() - 1)
        return c.name()
    return name


def killed():
    if os.environ.get("VF_NO_VERTEX_PLUS", "").strip() == "1":
        return True
    if os.environ.get("VF_NO_LIVE_MEASURE", "").strip() == "1":
        return True
    return _truthy(QgsSettings().value(PREFIX + "disabled", False))


def read_settings():
    s = QgsSettings()
    g = lambda k: s.value(PREFIX + k, DEFAULTS[k])
    return {
        "on": _truthy(g("vplus_on")),
        "near": _colour(g("vplus_near"), DEFAULTS["vplus_near"]),
        "ready": _colour(g("vplus_ready"), DEFAULTS["vplus_ready"]),
        "size": _clamp_int(g("vplus_size"), DEFAULTS["vplus_size"], *SIZE_RANGE),
        "pen": _clamp_int(g("vplus_pen"), DEFAULTS["vplus_pen"], *PEN_RANGE),
    }


def write_setting(key, value):
    """The Span Inspector's setter: store, then re-read so the change shows at once."""
    QgsSettings().setValue(PREFIX + key, value)
    configure()


def is_vertex_tool(iface, tool):
    """Same test as live_measure.VertexMeasureTool.is_vertex_tool (kept here so the plugin
    does not import the live tools at start-up)."""
    if tool is None or sip.isdeleted(tool):
        return False
    try:
        for name in ("actionVertexTool", "actionVertexToolActiveLayer"):
            act = getattr(iface, name, lambda: None)()
            if act is not None and tool.action() is act:
                return True
    except Exception:
        pass
    try:
        return (isinstance(tool, QgsMapToolAdvancedDigitizing) and not isinstance(tool, QgsMapToolCapture)
                and "vertex" in (tool.toolName() or "").lower())
    except Exception:
        return False


class VertexPlus(QObject):
    """One per QGIS session. Listens only while the Vertex tool is active."""

    def __init__(self, iface, tool_check=None):
        super().__init__()
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.tool_check = tool_check or (lambda tool: is_vertex_tool(self.iface, tool))
        self.cfg = read_settings()
        self.marker = None          # the adopted QGIS marker
        self.state = None           # "near" / "ready" - the last state QGIS signalled
        self.status = WAITING
        self._listening = False
        self._hooked = False
        self._last_scan = 0.0
        self._shapes = None         # [(size, pen, box)] a stock QGIS cross can have on this screen
        self._matched = None        # the (size, box, pen) of the marker we adopted - put back on restore
        self._logged = False
        self.stats = {"moves": 0, "scans": 0, "styled": 0, "restores": 0, "errors": 0}
        self._buttons = QApplication.mouseButtons     # injectable for the headless tests

    # lifecycle ------------------------------------------------------------
    def start(self):
        self.canvas.mapToolSet.connect(self._on_tool_set)
        self._hooked = True
        self._sync()

    def stop(self):
        self._listen(False)
        self._restore()
        if self._hooked and not sip.isdeleted(self.canvas):
            try:
                self.canvas.mapToolSet.disconnect(self._on_tool_set)
            except (TypeError, RuntimeError):
                pass
        self._hooked = False

    def enabled(self):
        return self.cfg["on"] and not killed()

    def reconfigure(self):
        self.cfg = read_settings()
        if self.enabled() and self.marker is not None and self._alive(self.marker):
            self._apply_size(self.marker)
            self._apply_colour(self.marker)
        self._sync()

    def _sync(self):
        """Listen only while enabled AND the Vertex tool is active (checked now, not only on
        the next tool change, so a reload with the Vertex tool picked works at once)."""
        if sip.isdeleted(self.canvas):
            return
        want = self.enabled() and self.tool_check(self.canvas.mapTool())
        self._listen(want)
        if not want:
            self._restore()
            self.status = OFF if not self.enabled() else (ACTIVE if self.stats["styled"] else WAITING)

    def _listen(self, on):
        if on == self._listening:
            return
        if on:
            self._last_scan = 0.0       # look for the marker on the very first move
            self.canvas.xyCoordinates.connect(self._on_move)
        elif not sip.isdeleted(self.canvas):
            try:
                self.canvas.xyCoordinates.disconnect(self._on_move)
            except (TypeError, RuntimeError):
                pass
        self._listening = on

    def _on_tool_set(self, *args):
        try:
            self._sync()
        except Exception:
            self._error()

    # per move ---------------------------------------------------------------
    def _on_move(self, *args):
        try:
            self.stats["moves"] += 1
            if self._buttons() != Qt.MouseButton.NoButton:
                # A drag: QGIS hides the + and shows temporary red X drag markers (point features,
                # qgsvertextool.cpp) of the same size - never adopt or restyle those.
                return
            m = self.marker if (self.marker is not None and self._alive(self.marker)) else self._find()
            if m is None or not m.isVisible():
                return
            c = m.color().name()
            if c == QGIS_GREY:
                self.state = "near"
            elif c == QGIS_RED:
                self.state = "ready"
            elif self.state is None:
                return
            self._apply_colour(m)
        except Exception:
            self._error()

    def _alive(self, m):
        """True only while m is still an item of the canvas scene - checked by ADDRESS against
        the scene's live items, never by calling anything on m. QGIS deletes some of its markers
        in C++ (the drag markers when a drag ends, every marker when a Vertex tool is destroyed)
        and sip is not told, so sip.isdeleted() stays False and any call on the stale wrapper
        reads freed memory: QGIS crashed with an access violation in _alive (2026-11-02)."""
        if m is None or sip.isdeleted(self.canvas):
            return False
        sc = self.canvas.scene()
        if sc is None:
            return False
        try:
            addr = sip.unwrapinstance(m)     # the stored pointer; does not dereference it
        except (TypeError, RuntimeError):    # sip already knows it is gone
            return False
        for it in sc.items():
            if sip.unwrapinstance(it) == addr:
                return True
        return False

    def _find(self):
        self.marker = None
        now = time.monotonic()
        if now - self._last_scan < RESCAN_S:
            return None
        self._last_scan = now
        self.stats["scans"] += 1
        sc = self.canvas.scene()
        if sc is None:
            return None
        cands = [it for it in sc.items()
                 if isinstance(it, QgsVertexMarker) and it.isVisible()
                 and it.color().name() in (QGIS_GREY, QGIS_RED)]
        if len(cands) != 1:
            if len(cands) > 1:
                self._unrecognised("%d grey/red markers at once" % len(cands))
            return None
        m = cands[0]
        w = m.boundingRect().width()
        hit = [(size, box, pen) for size, pen, box in self._stock_shapes() if abs(w - box) <= 0.5]
        if not hit:
            self._unrecognised("marker box %.1f px, expected %s" % (
                w, "/".join("%.1f" % b for _s, _p, b in self._stock_shapes())))
            return None
        self._matched = hit[0]
        self.marker = m
        self._apply_size(m)
        self.status = ACTIVE
        return m

    def _stock(self):
        """(icon size, drawn box, pen) of the Vertex tool's marker: the shape we adopted, else the
        plain QgsVertexMarker default (first entry of _stock_shapes)."""
        if self._matched is not None:
            return self._matched
        size, pen, box = self._stock_shapes()[0]
        return (size, box, pen)

    def _stock_shapes(self):
        """Every (size, pen, box) a stock QGIS edge-centre cross can have on THIS screen.
        QGIS 4.2 (and 3.x) size it with QgsGuiUtils::scaleIconSize(10) - 11 px on JJ's display
        (UI scale 1.5, font height 16) - and some builds leave it at QgsVertexMarker's default
        (10 px offscreen). There is no size getter, so build a probe, measure the drawn box for
        each candidate size/pen, and accept any of them. Default first."""
        if self._shapes is None:
            probe = QgsVertexMarker(self.canvas)
            try:
                cross = getattr(getattr(QgsVertexMarker, "IconType", None), "ICON_CROSS", None)
                probe.setIconType(cross if cross is not None else QgsVertexMarker.ICON_CROSS)
                probe.setPenWidth(QGIS_PEN)
                box0 = probe.boundingRect().width()
                size0 = QGIS_SIZE
                for s in range(2, 65):
                    probe.setIconSize(s)
                    if abs(probe.boundingRect().width() - box0) < 0.01:
                        size0 = s
                        break
                shapes = [(size0, QGIS_PEN, box0)]
                for size in (size0, _scale_icon_size(QGIS_SIZE)):
                    for pen in (QGIS_PEN, _scale_icon_size(QGIS_PEN)):
                        probe.setIconSize(size)
                        probe.setPenWidth(pen)
                        shape = (size, pen, probe.boundingRect().width())
                        if shape not in shapes:
                            shapes.append(shape)
                self._shapes = shapes
            finally:
                sc = probe.scene()
                if sc is not None:
                    sc.removeItem(probe)
        return self._shapes

    def _apply_size(self, m):
        m.setIconSize(self.cfg["size"])
        m.setPenWidth(self.cfg["pen"])

    def _apply_colour(self, m):
        want = _safe_colour(self.cfg["ready"] if self.state == "ready" else self.cfg["near"])
        if m.color().name() != want:
            m.setColor(QColor(want))
            m.update()
        self.stats["styled"] += 1

    def _restore(self):
        m, self.marker = self.marker, None
        if m is None or not self._alive(m):
            return
        try:
            size, _box, pen = self._stock()
            m.setIconSize(size)
            m.setPenWidth(pen)
            m.setColor(QColor(QGIS_RED if self.state == "ready" else QGIS_GREY))
            m.update()
            self.stats["restores"] += 1
        except RuntimeError:
            pass

    def _unrecognised(self, why):
        if self.status != ACTIVE:
            self.status = UNRECOGNISED
        if not self._logged:
            self._logged = True
            self.stats["logs"] = self.stats.get("logs", 0) + 1
            QgsMessageLog.logMessage("Bold + marker: QGIS's Vertex marker not recognised (%s) - left as is." % why,
                                     LOG_TAG, Qgis.MessageLevel.Info)

    def _error(self):
        self.stats["errors"] += 1
        if self.stats["errors"] == 1:
            QgsMessageLog.logMessage("Bold + marker error:\n" + traceback.format_exc(), LOG_TAG,
                                     Qgis.MessageLevel.Warning)
        if self.stats["errors"] >= 3:   # something is badly off on this QGIS: stand down
            self._listen(False)
            self._restore()
            self.status = UNRECOGNISED

    def status_text(self):
        if self.status == OFF:
            return "Bold +: off"
        if self.status == ACTIVE:
            return "Bold +: on"
        if self.status == UNRECOGNISED:
            return "Bold +: QGIS's marker not recognised on this version - left as is"
        return "Bold +: ready - hover a line with the Vertex tool"


_HOST = None


def install(iface):
    """Called from the plugin's initGui. Safe to call twice."""
    global _HOST
    uninstall()
    host = VertexPlus(iface)
    host.start()
    _HOST = host
    return host


def uninstall():
    global _HOST
    host, _HOST = _HOST, None
    if host is not None:
        host.stop()


def configure():
    if _HOST is not None:
        _HOST.reconfigure()


def current():
    return _HOST


def status_text():
    if _HOST is None:
        return "Bold +: not running (reload the plugin)"
    return _HOST.status_text()


__all__ = [
    "VertexPlus",
    "configure",
    "current",
    "install",
    "read_settings",
    "status_text",
    "uninstall",
    "write_setting",
]
