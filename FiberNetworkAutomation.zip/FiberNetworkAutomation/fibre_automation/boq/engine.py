"""engine — the reliable BoQ pipeline: discover → measure(UTM) → wastage → rate → validate.

The reliability core is measure_length_m(): it ALWAYS reprojects to a projected
CRS (UTM) before QgsDistanceArea.measureLength, so a length is never read in
EPSG:4326 degrees. Plus null-geom skipping (never counted as 0), cross-layer
duplicate-label detection, and domain cross-checks (drop≈ONT, m/ONT sanity).
"""
import json
import math
import os

from .constants import (DEFAULT_RULES, MOA_UTM, SANE_M_PER_ONT, SECTION_ONT)

_HERE = os.path.dirname(os.path.abspath(__file__))
_USER_RATES = os.path.join(os.path.expanduser("~"), ".velocity_nexus", "boq_rates.json")
_DEFAULT_RATES = os.path.join(_HERE, "boq_rates_default.json")


class BoQResult:
    def __init__(self):
        self.lines = []          # priced line items
        self.audit = []          # {check, status(OK/WARN/GATE/BLOCK), detail}
        self.blocked = []        # null/invalid geometries (layer, fid)
        self.missing = []        # required layers not found
        self.meta = {}
        self.verdict = "OK"      # OK | REVIEW | FAIL

    def add_audit(self, check, status, detail):
        self.audit.append({"check": check, "status": status, "detail": detail})


# ── rates ───────────────────────────────────────────────────────────────────
def load_rates():
    """User rates if present, else bundled default. Never raises."""
    for p in (_USER_RATES, _DEFAULT_RATES):
        try:
            with open(p, encoding="utf-8") as f:
                d = json.load(f)
            d["_path"] = p
            return d
        except Exception:
            continue
    return {"MATERIALS": {}, "LABOUR": {}, "_path": "(none)"}


def _rate_for(rates, rate_key):
    for sect in ("MATERIALS", "LABOUR"):
        r = (rates.get(sect) or {}).get(rate_key)
        if r and r.get("rate") is not None:
            return r.get("rate"), r.get("source", sect)
    return None, None


# ── measurement (the reliability primitive) ───────────────────────────────────
def _utm_measurer(project):
    from qgis.core import QgsCoordinateReferenceSystem, QgsDistanceArea, QgsUnitTypes
    da = QgsDistanceArea()
    utm = QgsCoordinateReferenceSystem(MOA_UTM)
    da.setSourceCrs(utm, project.transformContext())
    try:
        da.setEllipsoid(project.ellipsoid() or "WGS84")
    except Exception:
        da.setEllipsoid("WGS84")
    return da, utm, QgsUnitTypes


def _measure_length_m(geom, layer_crs, utm, project):
    """Reproject to UTM then measure in metres. None for null/empty (caller skips)."""
    from qgis.core import QgsCoordinateTransform, QgsDistanceArea, QgsGeometry
    if geom is None or geom.isEmpty():
        return None
    if layer_crs != utm:
        g = QgsGeometry(geom)
        g.transform(QgsCoordinateTransform(layer_crs, utm, project))
        geom = g
    da = QgsDistanceArea()
    da.setSourceCrs(utm, project.transformContext())
    return da.measureLength(geom)


def _find_layer(project, tokens, exclude):
    from qgis.core import QgsVectorLayer
    toks = [t.lower() for t in tokens]
    exc = [e.lower() for e in exclude]
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
            continue
        name = lyr.name().lower()
        if all(t in name for t in toks) and not any(e in name for e in exc):
            return lyr
    return None


def _attr(feat, name):
    try:
        v = feat[name]
        if v is None:
            return None
        return v
    except Exception:
        return None


# ── pipeline ──────────────────────────────────────────────────────────────────
def run(project=None, rules=None, rates=None, aoi=None):
    """Run the BoQ pipeline against the live QGIS project. Returns a BoQResult."""
    from qgis.core import QgsProject
    project = project or QgsProject.instance()
    rules = rules or DEFAULT_RULES
    rates = rates or load_rates()
    res = BoQResult()
    res.meta = {
        "project": project.baseName() or "(unsaved)",
        "crs_measure": MOA_UTM,
        "rates_path": rates.get("_path"),
        "rates_supplier": (rates.get("meta") or {}).get("supplier"),
    }

    da, utm, _ = _utm_measurer(project)
    seen_cable_labels = {}      # label -> layer (cross-layer double-count guard)
    ont_count = 0
    drop_count = 0
    total_cable_measured = 0.0

    for rule in rules:
        lyr = _find_layer(project, rule.layer_tokens, rule.exclude_tokens)
        if lyr is None:
            res.missing.append(rule.key)
            continue

        if lyr.crs().isGeographic():
            res.add_audit(f"CRS::{rule.key}", "OK",
                          f"{lyr.name()} is {lyr.crs().authid()} (geographic) → "
                          f"reprojected to {MOA_UTM} for measurement")

        # group_value -> {count, measured_m, fids:[]}
        groups = {}
        for feat in lyr.getFeatures():
            geom = feat.geometry()
            gv = _attr(feat, rule.group_by) if rule.group_by else "(all)"
            gv = "(unset)" if gv is None else str(gv)
            g = groups.setdefault(gv, {"count": 0, "measured_m": 0.0, "fids": []})
            if rule.measure == "length":
                m = _measure_length_m(geom, lyr.crs(), utm, project)
                if m is None:
                    res.blocked.append({"layer": lyr.name(), "fid": feat.id(),
                                        "reason": "null/empty geometry"})
                    continue
                g["measured_m"] += m
                g["count"] += 1
                g["fids"].append(feat.id())
                # cross-layer duplicate-label guard
                lbl = _attr(feat, rule.dedup_by) if rule.dedup_by else None
                if lbl is not None:
                    prev = seen_cable_labels.get(str(lbl))
                    if prev and prev != lyr.name():
                        res.add_audit("dedup", "GATE",
                                      f"label '{lbl}' appears in BOTH '{prev}' and "
                                      f"'{lyr.name()}' — possible double-count")
                    seen_cable_labels[str(lbl)] = lyr.name()
            else:  # count
                if geom is None or geom.isEmpty():
                    res.blocked.append({"layer": lyr.name(), "fid": feat.id(),
                                        "reason": "null/empty geometry"})
                    # still count it (a splitter/pole with no geom is still bought) but flag
                g["count"] += 1
                g["fids"].append(feat.id())

        # build priced lines per group
        for gv, g in sorted(groups.items()):
            rate, src = _rate_for(rates, rule.rkey())
            if rule.measure == "length":
                measured = round(g["measured_m"], 1)
                installed = measured * (1.0 + rule.sag_pct)
                ordered = round(installed * (1.0 + rule.slack_pct), 1)
                spools = (math.ceil(ordered / rule.spool_size_m)
                          if rule.spool_size_m else None)
                total_cable_measured += measured
                if rule.key == "drop_1F":
                    drop_count += g["count"]
                res.lines.append({
                    "section": rule.section, "key": rule.key, "group": gv,
                    "desc": f"{lyr.name()} [{gv}]",
                    "unit": "m", "count": g["count"],
                    "measured_m": measured,
                    "installed_m": round(installed, 1),
                    "ordered_m": ordered,
                    "spools": spools,
                    "qty": ordered, "rate": rate, "rate_source": src,
                    "amount": (round(ordered * rate, 2) if rate is not None else None),
                    "fids": g["fids"],
                })
            else:
                if rule.section == SECTION_ONT:
                    ont_count += g["count"]
                res.lines.append({
                    "section": rule.section, "key": rule.key, "group": gv,
                    "desc": f"{lyr.name()} [{gv}]",
                    "unit": "ea", "count": g["count"],
                    "qty": g["count"], "rate": rate, "rate_source": src,
                    "amount": (round(g["count"] * rate, 2) if rate is not None else None),
                    "fids": g["fids"],
                })

    _validate(res, ont_count, drop_count, total_cable_measured)
    return res


def _validate(res, ont_count, drop_count, total_cable_m):
    # missing required layers
    if res.missing:
        res.add_audit("layers", "WARN",
                      f"layers not found (skipped): {', '.join(res.missing)}")
    # null/invalid geometries
    if res.blocked:
        res.add_audit("null_geom", "GATE",
                      f"{len(res.blocked)} feature(s) with null/empty geometry — "
                      f"e.g. {res.blocked[:3]}")
    else:
        res.add_audit("null_geom", "OK", "no null/empty geometries")
    # missing rates
    tbd = [l["key"] for l in res.lines if l.get("rate") is None]
    if tbd:
        res.add_audit("rates", "WARN",
                      f"{len(tbd)} line(s) have no rate (shown as TBD): {sorted(set(tbd))}")
    # drop ≈ ONT
    if ont_count and drop_count:
        ratio = drop_count / ont_count
        st = "OK" if 0.9 <= ratio <= 1.1 else "GATE"
        res.add_audit("drop_vs_ont", st,
                      f"drops={drop_count} vs ONTs={ont_count} (ratio {ratio:.2f}; "
                      f"expect ~1.0)")
    elif ont_count and not drop_count:
        res.add_audit("drop_vs_ont", "WARN", f"{ont_count} ONTs but no drop cables found")
    # m-of-cable per ONT sanity (catches phantom-length / double-count blowout)
    if ont_count and total_cable_m:
        mpo = total_cable_m / ont_count
        lo, hi = SANE_M_PER_ONT
        st = "OK" if lo <= mpo <= hi else "GATE"
        res.add_audit("m_per_ont", st,
                      f"{mpo:.0f} m cable / ONT (sane band {lo:.0f}-{hi:.0f}) — "
                      f"{'OK' if st == 'OK' else 'OUT OF RANGE: check CRS/double-count'}")
    # verdict
    sevs = {a["status"] for a in res.audit}
    if "BLOCK" in sevs:
        res.verdict = "FAIL"
    elif "GATE" in sevs:
        res.verdict = "REVIEW"
    else:
        res.verdict = "OK"
