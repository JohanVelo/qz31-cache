# -*- coding: utf-8 -*-
# claude:intent MUTATE — "Label My Network" recipe-per-layer labelling dock.
# The only data mutations (label_recipe.apply() on the LABEL EVERYTHING click
# + the one-click bulk-undo restore) run ONLY after a previewed dry run and a
# default-ON project backup.  Nothing is written until the user applies.
"""labeling_wizard — "Label My Network" (one recipe per layer) dock.

Replaces the old 5-step structure-walk wizard with ONE simple screen driven
by the reference-composition engine in label_recipe.py:

    HEADER            you've placed everything — cyan parts fill from the map
    PROJECT & PRESET  per-client constants strip + Fibertime / Vuma / HeroTel
                      presets — cards rebuild from whatever roles the preset
                      returns (poles, manholes, enclosures, cables, …)
    RECIPES           one card per detected layer: template as TOKEN CHIPS
                      (literal=grey, map-reference=cyan, feature-field=amber)
                      + a live example label + inline EDIT panel
    PREVIEW           dry run — segmented gauge, ready/flagged KPIs, first 40
                      changes, flags framed as "left blank for you to check"
    APPLY             backup-first (default ON) -> label_recipe.apply() ->
                      green toast with ONE-CLICK UNDO -> auto re-preview
    ADVANCED          host (pole/manhole) + polygon (PON/Zone) pickers,
                      field-dialect note — collapsed by default

Threading: QGIS layer reads happen on the MAIN thread under a wait cursor
(extraction into pure-python rows), then the heavy compose loop runs off the
UI thread via off_thread/QgsTask (sip.isdeleted guards on every callback).
The off-thread compose replicates label_recipe.dry_run() over the extracted
rows and returns the EXACT same result structure, so label_recipe.apply()
consumes it unchanged.  A staleness token fingerprints the configuration the
preview was made for — apply can never consume a preview made for different
recipes/constants/layers.

Qt6/Qt5-safe: all Qt via the qgis.PyQt shim, every enum fully scoped,
no box-shadow/transitions in QSS (glow = QGraphicsDropShadowEffect),
all QSS scoped to #vnRoot.  No QGIS call runs at import time; the engine
is imported lazily inside methods.
"""
import os
import re
import string
from datetime import datetime

from qgis.PyQt import QtWidgets, QtCore, QtGui

Qt = QtCore.Qt

__all__ = [
    "LabelMyNetworkDock",
    "LabelMyNetworkWidget",
    "RecipeCard",
    "open_labeling_wizard",
]

# ---------------------------------------------------------------------------
# palette (Mission-Control console — dark by design, every fg paired with bg)
# ---------------------------------------------------------------------------

_ACCENT = "#00e5ff"
_AMBER = "#ffb454"
_GREEN = "#3ddc84"
_MUTED = "#6b7b8a"
_BG = "#0a0e12"

_PREVIEW_ROW_LIMIT = 40                 # changed rows shown in the table
_FLAG_DETAIL_LIMIT = 15                 # example features per flag code
_GAUGE_CELLS = 36                       # segmented gauge cell count

# All QSS is scoped to #vnRoot; the panel commits to the dark console look,
# so every text colour below is paired with an explicit background — readable
# regardless of the QGIS theme.  NO box-shadow / transitions (Qt QSS crashes
# or ignores them) — the cyan glow is a QGraphicsDropShadowEffect instead.
_QSS = """
#vnRoot { background: #0a0e12; }
#vnRoot QWidget { font-family: 'Chakra Petch','Segoe UI',sans-serif; }
#vnRoot QLabel { color: #d5e2ec; background: transparent; }
#vnRoot QLabel[vnRole='muted'] { color: #7d8b99; }
#vnRoot QLabel[vnRole='title'] { color: #eaf3ff; font-size: 16px;
    font-weight: 700; letter-spacing: 2px; }
#vnRoot QLabel[vnRole='section'] { color: #00e5ff; font-size: 10px;
    font-weight: 700; letter-spacing: 2px;
    font-family: 'JetBrains Mono','Consolas',monospace; }
#vnRoot QLabel[vnRole='secno'] { color: #7d8b99; font-size: 10px;
    font-weight: 700; letter-spacing: 2px;
    font-family: 'JetBrains Mono','Consolas',monospace; }
#vnRoot QLabel[vnRole='mono'] { font-family: 'JetBrains Mono','Consolas',monospace; }
#vnRoot QLabel[vnRole='cardname'] { color: #eaf3ff; font-size: 13px;
    font-weight: 700; }
#vnRoot QLabel[vnRole='cardname-off'] { color: #55636f; font-size: 13px;
    font-weight: 700; }
#vnRoot QLabel[vnRole='example'] { color: #3ddc84;
    font-family: 'JetBrains Mono','Consolas',monospace; font-size: 11px; }
#vnRoot QLabel[vnKpi='green'] { color: #3ddc84; font-size: 22px;
    font-weight: 700; font-family: 'JetBrains Mono','Consolas',monospace; }
#vnRoot QLabel[vnKpi='amber'] { color: #ffb454; font-size: 22px;
    font-weight: 700; font-family: 'JetBrains Mono','Consolas',monospace; }
#vnRoot QLabel[vnChip='cyan'] { background: #0d262c; color: #00e5ff;
    border: 1px solid #00778a; border-radius: 3px; padding: 2px 8px;
    font-family: 'JetBrains Mono','Consolas',monospace; font-size: 10px; }
#vnRoot QLabel[vnChip='amber'] { background: #2e2310; color: #ffb454;
    border: 1px solid #a87524; border-radius: 3px; padding: 2px 8px;
    font-family: 'JetBrains Mono','Consolas',monospace; font-size: 10px; }
#vnRoot QLabel[vnChip='green'] { background: #0f2a1c; color: #3ddc84;
    border: 1px solid #1f7a4a; border-radius: 3px; padding: 2px 8px;
    font-family: 'JetBrains Mono','Consolas',monospace; font-size: 10px; }
#vnRoot QLabel[vnChip='grey'] { background: #161d24; color: #9fb0bf;
    border: 1px solid #263038; border-radius: 3px; padding: 2px 8px;
    font-family: 'JetBrains Mono','Consolas',monospace; font-size: 10px; }
#vnRoot QLabel[vnTok='ref'] { background: #00e5ff; color: #06131a;
    border: 1px solid #00e5ff; border-radius: 4px; padding: 2px 7px;
    font-weight: 700;
    font-family: 'JetBrains Mono','Consolas',monospace; font-size: 11px; }
#vnRoot QLabel[vnTok='field'] { background: #161009; color: #ffb454;
    border: 1px solid #3a2e1a; border-radius: 4px; padding: 2px 7px;
    font-family: 'JetBrains Mono','Consolas',monospace; font-size: 11px; }
#vnRoot QLabel[vnTok='lit'] { background: #0a1015; color: #93a4b3;
    border: 1px solid #1c2733; border-radius: 4px; padding: 2px 7px;
    font-family: 'JetBrains Mono','Consolas',monospace; font-size: 11px; }
#vnRoot QLabel[vnBanner='error'] { background: #2b1216; color: #ff9aa2;
    border: 1px solid #e5534b; border-radius: 3px; padding: 6px 10px; }
#vnRoot QLabel[vnBanner='warn'] { background: #2b2110; color: #ffb454;
    border: 1px solid #ffb454; border-radius: 3px; padding: 6px 10px; }
#vnRoot QLabel[vnBanner='ok'] { background: #0f2a1c; color: #3ddc84;
    border: 1px solid #3ddc84; border-radius: 3px; padding: 6px 10px; }
#vnRoot QFrame[vnPanel='true'] { background: #12171d;
    border: 1px solid #1c2630; border-radius: 4px; }
#vnRoot QFrame[vnCard='on'] { background: #111922;
    border: 1px solid #1c2733; border-radius: 6px; }
#vnRoot QFrame[vnCard='off'] { background: #0c1116;
    border: 1px solid #151d25; border-radius: 6px; }
#vnRoot QFrame[vnRule='true'] { background: #1c2630; border: 0;
    max-height: 1px; min-height: 1px; }
#vnRoot QPushButton { background: #12171d; color: #c9dcec;
    border: 1px solid #24303c; border-radius: 3px; padding: 5px 14px; }
#vnRoot QPushButton:hover { background: #1a2230; border-color: #00e5ff;
    color: #eaf6ff; }
#vnRoot QPushButton:disabled { color: #55636f; background: #0e1319;
    border-color: #1a222b; }
#vnRoot QPushButton[vnPrimary='true'] { background: #00e5ff; color: #04141a;
    font-weight: 700; border: 1px solid #00e5ff; padding: 7px 20px;
    letter-spacing: 1px; }
#vnRoot QPushButton[vnPrimary='true']:hover { background: #5df0ff; }
#vnRoot QPushButton[vnPrimary='true']:disabled { background: #113c45;
    color: #38626d; border-color: #113c45; }
#vnRoot QPushButton[vnApply='true'] { background: #00e5ff; color: #04121a;
    font-weight: 700; font-size: 15px; border: 1px solid #00e5ff;
    border-radius: 6px; padding: 12px 20px; letter-spacing: 1px; }
#vnRoot QPushButton[vnApply='true']:hover { background: #5df0ff; }
#vnRoot QPushButton[vnApply='true']:disabled { background: #113c45;
    color: #38626d; border-color: #113c45; }
#vnRoot QPushButton[vnPreset='true'] { background: #0d141b; color: #7d8b99;
    border: 1px solid #1c2733; border-radius: 6px; padding: 6px 13px;
    font-family: 'JetBrains Mono','Consolas',monospace; font-size: 11px; }
#vnRoot QPushButton[vnPreset='true']:checked { background: #0c1b21;
    color: #eaf6ff; border: 1px solid #00e5ff; }
#vnRoot QPushButton[vnEdit='true'] { background: transparent; color: #7d8b99;
    border: 1px solid #1c2733; border-radius: 5px; padding: 3px 9px;
    font-family: 'JetBrains Mono','Consolas',monospace; font-size: 10px; }
#vnRoot QPushButton[vnEdit='true']:checked { color: #00e5ff;
    border-color: #00778a; background: #0d262c; }
#vnRoot QToolButton { background: transparent; color: #7d8b99;
    border: 1px solid #1c2733; border-radius: 5px; padding: 5px 12px;
    font-family: 'JetBrains Mono','Consolas',monospace; font-size: 10px; }
#vnRoot QToolButton:hover { color: #c9dcec; border-color: #2b3a48; }
#vnRoot QComboBox, #vnRoot QLineEdit, #vnRoot QSpinBox,
#vnRoot QDoubleSpinBox {
    background: #0e1419; color: #d5e2ec; border: 1px solid #24303c;
    border-radius: 3px; padding: 3px 6px;
    selection-background-color: #00546b; selection-color: #eaf6ff; }
#vnRoot QComboBox:disabled, #vnRoot QLineEdit:disabled {
    color: #55636f; background: #0d1116; }
#vnRoot QComboBox QAbstractItemView { background: #12171d; color: #d5e2ec;
    border: 1px solid #24303c; selection-background-color: #00546b;
    selection-color: #eaf6ff; }
#vnRoot QTableWidget, #vnRoot QTreeWidget {
    background: #0e1419; color: #d5e2ec; border: 1px solid #1c2630;
    alternate-background-color: #111820; gridline-color: #1c2630;
    font-family: 'JetBrains Mono','Consolas',monospace; font-size: 11px; }
#vnRoot QTableWidget::item:selected, #vnRoot QTreeWidget::item:selected {
    background: #00546b; color: #eaf6ff; }
#vnRoot QHeaderView::section { background: #12171d; color: #7d8b99;
    border: 0; border-bottom: 1px solid #24303c; padding: 4px 6px;
    letter-spacing: 1px; font-family: 'Chakra Petch','Segoe UI',sans-serif; }
#vnRoot QCheckBox { color: #d5e2ec; spacing: 6px; }
#vnRoot QCheckBox:disabled { color: #55636f; }
#vnRoot QCheckBox::indicator { width: 14px; height: 14px;
    border: 1px solid #24303c; background: #0e1419; border-radius: 2px; }
#vnRoot QCheckBox::indicator:checked { background: #3ddc84;
    border-color: #3ddc84; }
#vnRoot QProgressBar { background: #0e1419; border: 1px solid #24303c;
    border-radius: 3px; max-height: 8px; }
#vnRoot QProgressBar::chunk { background: #00e5ff; }
#vnRoot QScrollArea { border: 0; background: transparent; }
#vnRoot QScrollArea > QWidget > QWidget { background: transparent; }
#vnRoot QGroupBox { color: #7d8b99; border: 1px solid #1c2630;
    border-radius: 4px; margin-top: 8px; padding-top: 8px; }
#vnRoot QGroupBox::title { subcontrol-origin: margin; left: 8px;
    padding: 0 4px; }
"""


# ---------------------------------------------------------------------------
# lazy engine import (label_recipe — QGIS-free at import, both package layouts)
# ---------------------------------------------------------------------------

_ENGINE = None


def _engine():
    """The label_recipe engine (package-relative or flat copy)."""
    global _ENGINE
    if _ENGINE is None:
        try:
            from . import label_recipe as eng
        except ImportError:             # pragma: no cover - flat copy
            import label_recipe as eng
        _ENGINE = eng
    return _ENGINE


_WALK = None


def _walk_adapter():
    """The structure_adapter (walk-order engine), or None if unavailable.
    Optional dependency — the tool works fine without it (walk order just
    can't be offered)."""
    global _WALK
    if _WALK is None:
        try:
            from . import structure_adapter as wa
        except ImportError:             # pragma: no cover - flat copy
            try:
                import structure_adapter as wa
            except ImportError:
                wa = False
        _WALK = wa
    return _WALK or None


# ---------------------------------------------------------------------------
# small guarded helpers
# ---------------------------------------------------------------------------

def _is_deleted(obj):
    """True if the sip/C++ object behind obj is gone (guarded)."""
    try:
        from qgis.PyQt import sip
        return sip.isdeleted(obj)
    except Exception:
        return False


def _repolish(widget):
    """Re-evaluate QSS after a dynamic property change."""
    try:
        widget.style().unpolish(widget)
        widget.style().polish(widget)
    except Exception:
        pass


def _glow(widget, alpha=80, blur=18):
    """Cyan Nexus glow — QGraphicsDropShadowEffect, never QSS box-shadow."""
    try:
        eff = QtWidgets.QGraphicsDropShadowEffect(widget)
        eff.setBlurRadius(blur)
        eff.setOffset(0, 0)
        eff.setColor(QtGui.QColor(0, 229, 255, alpha))
        widget.setGraphicsEffect(eff)
    except Exception:
        pass


def _mono_font(size=9):
    """JetBrains Mono if installed, else Consolas/monospace."""
    fam = "Consolas"
    try:
        try:
            families = QtGui.QFontDatabase.families()      # Qt6 static
        except TypeError:                                  # Qt5 instance API
            families = QtGui.QFontDatabase().families()
        if "JetBrains Mono" in families:
            fam = "JetBrains Mono"
    except Exception:
        pass
    f = QtGui.QFont(fam, size)
    try:
        f.setStyleHint(QtGui.QFont.StyleHint.Monospace)
    except AttributeError:
        pass
    return f


def _theme_colors(widget=None):
    """theme_safe.colors() with layered imports; palette fallback if absent.

    Used only for the QSS-failed fallback path — the QSS itself pairs every
    fg with an explicit bg so the dock reads in ANY QGIS theme."""
    for imp in ("from_parent", "flat"):
        try:
            if imp == "from_parent":
                from .. import theme_safe          # FiberNetworkAutomation pkg
            else:
                import theme_safe                  # flat / path import
            return theme_safe.colors(widget)
        except Exception:
            continue
    try:                                           # minimal palette fallback
        pal = (widget.palette() if widget is not None
               else QtWidgets.QApplication.palette())
        bg = pal.color(QtGui.QPalette.ColorRole.Window)
        ink = pal.color(QtGui.QPalette.ColorRole.WindowText)
        return {"bg": bg.name(), "ink": ink.name(), "muted": ink.name(),
                "accent": ink.name(), "warn": ink.name(), "ok": ink.name(),
                "bad": ink.name()}
    except Exception:
        return {"bg": "#ffffff", "ink": "#000000", "muted": "#444444",
                "accent": "#006688", "warn": "#885500", "ok": "#116633",
                "bad": "#882222"}


def _chip(text, color="grey", parent=None):
    lbl = QtWidgets.QLabel(text, parent)
    lbl.setProperty("vnChip", color)
    lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
    return lbl


def _set_chip(lbl, text, color):
    lbl.setText(text)
    if lbl.property("vnChip") != color:
        lbl.setProperty("vnChip", color)
        _repolish(lbl)


def _token_chip(text, kind, tooltip="", parent=None):
    """One template token chip: 'lit' grey / 'ref' cyan / 'field' amber."""
    lbl = QtWidgets.QLabel(text, parent)
    lbl.setProperty("vnTok", kind)
    lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
    if tooltip:
        lbl.setToolTip(tooltip)
    return lbl


def _section_row(number, text, parent=None):
    """'// 01 PROJECT & PRESET' section header row (Mission-Control style)."""
    w = QtWidgets.QWidget(parent)
    lay = QtWidgets.QHBoxLayout(w)
    lay.setContentsMargins(0, 6, 0, 2)
    lay.setSpacing(8)
    no = QtWidgets.QLabel("// %s" % number)
    no.setProperty("vnRole", "secno")
    lay.addWidget(no)
    lbl = QtWidgets.QLabel(str(text).upper())
    lbl.setProperty("vnRole", "section")
    lay.addWidget(lbl)
    rule = QtWidgets.QFrame()
    rule.setFrameShape(QtWidgets.QFrame.Shape.HLine)
    rule.setProperty("vnRule", True)
    lay.addWidget(rule, 1)
    return w


def _muted(text, parent=None):
    lbl = QtWidgets.QLabel(text, parent)
    lbl.setProperty("vnRole", "muted")
    lbl.setWordWrap(True)
    return lbl


def _rule(parent=None):
    fr = QtWidgets.QFrame(parent)
    fr.setFrameShape(QtWidgets.QFrame.Shape.HLine)
    fr.setProperty("vnRule", True)
    return fr


def _pyval(v):
    """Normalise a QGIS attribute value: QVariant NULL -> None."""
    if v is None:
        return None
    try:
        if hasattr(v, "isNull") and v.isNull():
            return None
    except Exception:
        pass
    return v


# ---------------------------------------------------------------------------
# settings persistence (tiny — remembers last choices across sessions)
# ---------------------------------------------------------------------------

_SETTINGS_NS = "velocity_nexus/label_my_network/"


def _setting(key, default=""):
    try:
        from qgis.core import QgsSettings
        v = QgsSettings().value(_SETTINGS_NS + key, default)
        return default if v is None else v
    except Exception:
        return default


def _set_setting(key, value):
    try:
        from qgis.core import QgsSettings
        QgsSettings().setValue(_SETTINGS_NS + key, value)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# off-thread runner (off_thread wrapper > QgsTask.fromFunction > sync)
# ---------------------------------------------------------------------------

_LIVE_TASKS = set()                     # strong refs — QgsTask GC mid-run = crash


def _import_off_thread():
    try:
        from . import off_thread
        return off_thread
    except Exception:
        pass
    try:
        from ..fibre_automation import off_thread
        return off_thread
    except Exception:
        pass
    try:
        import off_thread
        return off_thread
    except Exception:
        return None


def _run_async(work, on_done, on_error, description):
    """Run work() off the UI thread; callbacks fire on the main thread.
    Falls back to a synchronous call if no task manager exists (headless)."""
    off = _import_off_thread()
    if off is not None and hasattr(off, "run_off_thread"):
        try:
            off.run_off_thread(work, on_done=on_done, on_error=on_error,
                               description=description)
            return
        except Exception:
            pass
    try:
        from qgis.core import QgsApplication, QgsTask
        tm = QgsApplication.taskManager()
        if tm is not None:
            holder = {}

            def _fn(_task):
                return work()

            def _fin(exc, result=None):
                _LIVE_TASKS.discard(holder.get("task"))
                if exc is not None:
                    on_error(exc)
                else:
                    on_done(result)

            task = QgsTask.fromFunction(description, _fn, on_finished=_fin)
            holder["task"] = task
            _LIVE_TASKS.add(task)
            tm.addTask(task)
            return
    except Exception:
        pass
    try:                                # last resort — synchronous
        on_done(work())
    except Exception as exc:
        on_error(exc)


# ---------------------------------------------------------------------------
# backup helper (project_backup.create_backup — layered imports)
# ---------------------------------------------------------------------------

def _backup_module():
    try:
        from .. import project_backup            # FiberNetworkAutomation pkg
        return project_backup
    except Exception:
        pass
    try:
        from . import project_backup              # flat fibre_automation copy
        return project_backup
    except Exception:
        pass
    try:
        import project_backup
        return project_backup
    except Exception:
        return None


def _run_backup():
    """Back up the current project before writing.  Returns (ok, detail)."""
    try:
        from qgis.core import QgsProject
        proj = QgsProject.instance()
    except Exception as exc:
        return False, "QGIS project unavailable: %s" % exc
    mod = _backup_module()
    if mod is None:
        return False, "project_backup module not found"
    home = ""
    try:
        home = proj.absolutePath() or ""
    except Exception:
        pass
    if not home:
        home = os.path.expanduser("~")
    try:
        if hasattr(mod, "create_backup"):          # rich backup (gpkg + verify)
            dest_root = os.path.join(home, "_Label Backups")
            rep = mod.create_backup(proj, dest_root)
            ok = bool(rep.get("ok")) if isinstance(rep, dict) else bool(rep)
            detail = dest_root
            if isinstance(rep, dict) and rep.get("failed"):
                detail += " (failed: %s)" % ", ".join(
                    str(x) for x in rep["failed"][:3])
            return ok, detail
        if hasattr(mod, "backup_project"):         # zip backup fallback
            out = os.path.join(home, "label_backup_%s.zip"
                               % datetime.now().strftime("%Y%m%d_%H%M%S"))
            rep = mod.backup_project(proj, out)
            ok = bool(rep.get("ok")) if isinstance(rep, dict) else bool(rep)
            return ok, rep.get("path", out) if isinstance(rep, dict) else out
        return False, "no backup entry point in project_backup"
    except Exception as exc:
        return False, "%s: %s" % (type(exc).__name__, exc)


# ---------------------------------------------------------------------------
# layer helpers (guarded QGIS access — never at import time)
# ---------------------------------------------------------------------------

def _geom_kind(layer):
    """'point' | 'line' | 'polygon' | None — enum home moved across builds."""
    try:
        gt = layer.geometryType()
    except Exception:
        return None
    try:
        from qgis.core import Qgis
        gtenum = getattr(Qgis, "GeometryType", None)
        if gtenum is not None:
            for name, kind in (("Point", "point"), ("Line", "line"),
                               ("Polygon", "polygon")):
                val = getattr(gtenum, name, None)
                if val is not None and gt == val:
                    return kind
    except Exception:
        pass
    try:
        return {0: "point", 1: "line", 2: "polygon"}.get(int(gt))
    except (TypeError, ValueError):
        return None


def _project_layers():
    """All vector layers in the project (geometry kind resolvable)."""
    try:
        from qgis.core import QgsProject
        return [lyr for lyr in QgsProject.instance().mapLayers().values()
                if _geom_kind(lyr) is not None]
    except Exception:
        return []


def _field_names(layer):
    try:
        return [f.name() for f in layer.fields()]
    except Exception:
        return []


def _guess_field(names, *hints, contains=None):
    """Case-insensitive field guess (handles Label vs label dialects)."""
    low = {n.lower(): n for n in names}
    for h in hints:
        if h in low:
            return low[h]
    if contains:
        for n in names:
            if contains in n.lower():
                return n
    return None


def _feature_count(layer):
    try:
        n = layer.featureCount()
        return int(n) if n is not None and int(n) >= 0 else 0
    except Exception:
        return 0


def _first_attrs(layer):
    """First feature's attributes (NULL-normalised) — best-effort example."""
    try:
        for f in layer.getFeatures():
            return {k: _pyval(f[k]) for k in f.fields().names()}
    except Exception:
        pass
    return {}


def _line_coords(geom):
    try:
        if geom.isMultipart():
            pts = [q for part in geom.asMultiPolyline() for q in part]
        else:
            pts = geom.asPolyline()
        if len(pts) < 2:
            return None
        return [(p.x(), p.y()) for p in pts]
    except Exception:
        return None


def _point_xy(geom):
    try:
        pt = geom.asPoint()
        return (pt.x(), pt.y())
    except Exception:
        return None


def _fid_of(feat, id_field):
    return feat.id() if id_field in ("$id", None, "") else feat[id_field]


# -- layer combo (QgsMapLayerComboBox with guarded fallback) ------------------

def _layer_combo(kind=None, allow_empty=False):
    try:
        from qgis.gui import QgsMapLayerComboBox
        cb = QgsMapLayerComboBox()
        _apply_layer_filter(cb, kind)
        if allow_empty and hasattr(cb, "setAllowEmptyLayer"):
            try:
                cb.setAllowEmptyLayer(True)
                cb.setCurrentIndex(0)
            except Exception:
                pass
        return cb
    except Exception:
        cb = QtWidgets.QComboBox()
        try:
            if allow_empty:
                cb.addItem("(none)", None)
            for lyr in _project_layers():
                if kind in (None, _geom_kind(lyr)) or \
                        (kind == "cable" and _geom_kind(lyr) == "line"):
                    cb.addItem(lyr.name(), lyr)
        except Exception:
            pass
        return cb


def _apply_layer_filter(cb, kind):
    """Best-effort geometry filter — the enum's home moved across builds."""
    name = {"point": "PointLayer", "line": "LineLayer", "cable": "LineLayer",
            "polygon": "PolygonLayer"}.get(kind)
    if not name:
        return
    flt = None
    try:
        from qgis.core import QgsMapLayerProxyModel
        for owner in (getattr(QgsMapLayerProxyModel, "Filter", None),
                      QgsMapLayerProxyModel):
            flt = getattr(owner, name, None) if owner is not None else None
            if flt is not None:
                break
    except Exception:
        flt = None
    if flt is None:
        try:
            from qgis.core import Qgis
            flt = getattr(getattr(Qgis, "LayerFilter", None), name, None)
        except Exception:
            flt = None
    if flt is not None and hasattr(cb, "setFilters"):
        try:
            cb.setFilters(flt)
        except Exception:
            pass


def _current_layer(cb):
    if hasattr(cb, "currentLayer"):
        try:
            return cb.currentLayer()
        except Exception:
            return None
    try:
        return cb.currentData()
    except Exception:
        return None


def _set_combo_layer(cb, layer):
    try:
        if hasattr(cb, "setLayer"):
            cb.setLayer(layer)
            return
        for i in range(cb.count()):
            if cb.itemData(i) is layer:
                cb.setCurrentIndex(i)
                return
    except Exception:
        pass


def _on_layer_signal(cb, slot):
    """Connect 'layer changed' across both combo types (guarded)."""
    try:
        cb.layerChanged.connect(slot)
        return
    except Exception:
        pass
    try:
        cb.currentIndexChanged.connect(lambda *_: slot(None))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# recipe roles — icon, friendly name, layer-name hints, display order
# ---------------------------------------------------------------------------

_ROLE_META = {
    "DIST_CABLE": ("〰️", "Distribution Cable", ("distribution",)),
    "SEC_CABLE": ("〰️", "Secondary Feeder", ("secondary", "link")),
    "PRI_CABLE": ("〰️", "Primary Feeder", ("primary",)),
    "DROP_CABLE": ("↘️", "Drop Cable", ("drop cable", "drop")),
    "STS_SPLITTER": ("🔷", "STS Splitter", ("sts",)),
    "FTS_SPLITTER": ("🔶", "FTS Splitter", ("fts",)),
    "ENCL_SPLICE": ("🟪", "Enclosure (Splice)",
                    ("enclosures splice", "enclosure (splice)", "splice")),
    "ENCL_CONN": ("🟦", "Enclosure (Connectorised)",
                  ("connectoris", "connectorized")),
    "ONT": ("🏠", "ONT / Home Connection", ("home connection", "ont")),
    "POLE": ("📍", "Poles", ("poles", "pole")),
    "MANHOLE": ("⚫", "Manholes / Handholes", ("manhole", "handhole")),
    "POP": ("🏢", "POP", ("pop",)),
}

# PREFERRED display order only — the cards themselves are built from
# whatever roles the picked client preset returns; roles not listed here
# are appended after these.
_ROLE_ORDER = ("DIST_CABLE", "SEC_CABLE", "PRI_CABLE", "DROP_CABLE",
               "STS_SPLITTER", "FTS_SPLITTER", "ENCL_SPLICE", "ENCL_CONN",
               "POLE", "MANHOLE", "ONT", "POP")


def _role_meta(role):
    """(icon, friendly, layer-name hints) for a role — generated fallback for
    roles this UI has no hardcoded meta for (never crash on a new preset)."""
    meta = _ROLE_META.get(role)
    if meta is not None:
        return meta
    friendly = str(role).replace("_", " ").title()
    return ("▫", friendly, (friendly.split(" ")[0].lower(),))


# engine-derived tokens (resolved from geometry/pon like GEOM_REFS -> cyan)
_DERIVED_REFS = {"card", "port", "polenum", "chainage"}

# friendly phrases for the cyan map-reference chips
_TOKEN_PHRASES = {
    "start": "start pole", "end": "end pole",
    "start_full": "start pole (full)", "end_full": "end pole (full)",
    "host": "the pole it's on", "host_full": "the pole it's on (full)",
    "pon_no": "the PON it's in", "zone_no": "the Zone it's in",
    "zone": "the Zone it's in", "ag": "the AG it's in",
    "card": "OLT card #", "port": "OLT port #",
    "polenum": "host pole #", "chainage": "cable length",
}

_TOKEN_TIPS = {
    "start": "Nearest pole/manhole to the cable's start",
    "end": "Nearest pole/manhole to the cable's end",
    "start_full": "Full label of the start pole (with stack prefix)",
    "end_full": "Full label of the end pole (with stack prefix)",
    "host": "Nearest pole/manhole to this feature",
    "host_full": "Full label of the host pole (with stack prefix)",
    "pon_no": "The PON polygon this feature sits inside",
    "zone_no": "The Zone polygon this feature sits inside",
    "zone": "The zone polygon this feature sits inside",
    "ag": "The AG polygon this feature sits inside",
    "card": "OLT card number, derived from the PON number",
    "port": "OLT port number, derived from the PON number",
    "polenum": "The digits of the hosting pole's label",
    "chainage": "The cable's length window, measured from its geometry",
}

_PRESET_STACKS = {"Fibertime": "MOA", "Vuma": "LAW", "HeroTel": "MMB"}

# project-constants strip: (key, caption, placeholder, width) — which of
# these show depends on the picked client preset.
_CONST_DEFS = (
    ("stack", "STACK", "MOA", 64),
    ("olt", "OLT", "01", 44),
    ("owner", "OWNER", "VTC", 64),
    ("town", "TOWN", "MMB", 60),
    ("proj", "PROJ", "MALM", 64),
    ("zone", "ZONE", "1", 40),
    ("aoi", "AOI", "PABA2", 70),
    ("size", "SIZE", "24F", 52),
    ("mat", "MAT", "Aerial", 60),
)

_CLIENT_CONSTS = {
    "Fibertime": ("stack", "olt"),
    "Vuma": ("owner", "town", "proj", "zone"),
    "HeroTel": ("aoi", "zone", "size", "mat"),
    "Custom": tuple(k for k, _c, _p, _w in _CONST_DEFS),
}

_FMT = string.Formatter()


class _SafeDict(dict):
    def __missing__(self, key):
        return ""


def _ref_sample(name, stack):
    """Placeholder sample for a geometry/derived/polygon token (pre-preview)."""
    stack = stack or "MOA"
    base = {"start": "P.A423", "end": "P.B324", "host": "P.A384",
            "pon_no": "235", "zone_no": "17", "zone": "1", "ag": "AG1",
            "card": "15", "port": "11", "polenum": "0423",
            "chainage": "(0459m-0474m)"}
    if name in base:
        return base[name]
    if name.endswith("_full"):
        short = base.get(name[:-5])
        if short:
            return "%s.%s" % (stack, short)
    return "1"                    # custom polygon ref with no sample yet


def _seq_sample(spec):
    """'DC01'-style sample for an auto-number SequenceSpec (best-effort)."""
    try:
        pad = int(getattr(spec, "pad", 0) or 0)
        if getattr(spec, "letter_block", False):
            body = "A" + str(int(getattr(spec, "start", 1) or 1)).zfill(pad or 3)
        else:
            body = str(int(getattr(spec, "start", 1) or 1)).zfill(pad)
        return "%s%s" % (getattr(spec, "prefix", "") or "", body)
    except Exception:
        return "01"


def _match_layer(role, kind, layers):
    """Best fuzzy layer-name match for a recipe role (None if no score)."""
    hints = _role_meta(role)[2]
    want = "line" if kind == "cable" else "point"
    best, best_score = None, 0
    for lyr in layers:
        if _geom_kind(lyr) != want:
            continue
        try:
            lname = lyr.name().lower()
        except Exception:
            continue
        score = 0
        for h in hints:
            if h and h in lname:
                score = max(score, len(h) * 10)
        if not score:
            continue
        if "v1" in lname:
            score += 5
        if "spare" in lname:                # "Spare Drop Cable" never wins
            score -= 40
        if score > best_score:
            best, best_score = lyr, score
    return best if best_score > 0 else None


def _guess_named_layer(layers, kind, *hints, avoid=("spare",)):
    """Best point/polygon layer whose name contains a hint (hosts, PON, Zone)."""
    best, best_score = None, 0
    for lyr in layers:
        if _geom_kind(lyr) != kind:
            continue
        try:
            lname = lyr.name().lower()
        except Exception:
            continue
        score = 0
        for h in hints:
            if h and h in lname:
                score = max(score, len(h) * 10)
        if not score:
            continue
        if "v1" in lname:
            score += 5
        for a in avoid:
            if a in lname:
                score -= 40
        if score > best_score:
            best, best_score = lyr, score
    return best if best_score > 0 else None


def _detect_stack():
    """Most common stackref/stack value across project layers (best-effort)."""
    try:
        counts = {}
        for lyr in _project_layers()[:30]:
            names = _field_names(lyr)
            fld = _guess_field(names, "stackref", "stack")
            if not fld:
                continue
            try:
                for i, f in enumerate(lyr.getFeatures()):
                    v = _pyval(f[fld])
                    if v not in (None, ""):
                        s = str(v).strip()
                        if s:
                            counts[s] = counts.get(s, 0) + 1
                    if i >= 50:
                        break
            except Exception:
                continue
        if counts:
            return max(counts.items(), key=lambda kv: kv[1])[0]
    except Exception:
        pass
    return ""


def _detect_aoi():
    """Most common Name-prefix across layers ('HT_PABA2_…' / 'PABA2_…') —
    best-effort prefill for the HeroTel {aoi} constant."""
    counts = {}
    try:
        for lyr in _project_layers()[:30]:
            names = _field_names(lyr)
            fld = _guess_field(names, "name", "label", "label_1")
            if not fld:
                continue
            try:
                for i, f in enumerate(lyr.getFeatures()):
                    v = _pyval(f[fld])
                    if v not in (None, ""):
                        m = re.match(r"^(?:HT_)?([A-Za-z]{2,}\d*)_", str(v))
                        if m:
                            key = m.group(1)
                            counts[key] = counts.get(key, 0) + 1
                    if i >= 40:
                        break
            except Exception:
                continue
    except Exception:
        pass
    if counts:
        return max(counts.items(), key=lambda kv: kv[1])[0]
    return ""


# ---------------------------------------------------------------------------
# banner (inline error/warn/ok strip with an optional action button)
# ---------------------------------------------------------------------------

class _Banner(QtWidgets.QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QtWidgets.QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)
        self._lbl = QtWidgets.QLabel("")
        self._lbl.setWordWrap(True)
        self._btn = QtWidgets.QPushButton("")
        self._btn.hide()
        self._action = None
        self._btn.clicked.connect(self._fire)
        lay.addWidget(self._lbl, 1)
        lay.addWidget(self._btn, 0, Qt.AlignmentFlag.AlignTop)
        self.hide()

    def _fire(self):
        if self._action is not None:
            try:
                self._action()
            except Exception:
                pass

    def show_msg(self, kind, text, action_text=None, action=None):
        self._lbl.setProperty("vnBanner", kind)
        _repolish(self._lbl)
        self._lbl.setText(text)
        self._action = action
        if action_text and action is not None:
            self._btn.setText(action_text)
            self._btn.show()
        else:
            self._btn.hide()
        self.show()

    def clear(self):
        self._action = None
        self._btn.hide()
        self.hide()


# ---------------------------------------------------------------------------
# flow layout (token chips wrap in a narrow dock) — classic Qt pattern
# ---------------------------------------------------------------------------

class _FlowLayout(QtWidgets.QLayout):
    def __init__(self, parent=None, hspace=4, vspace=4):
        super().__init__(parent)
        self._items = []
        self._h = hspace
        self._v = vspace
        self.setContentsMargins(0, 0, 0, 0)

    def addItem(self, item):
        self._items.append(item)

    def count(self):
        return len(self._items)

    def itemAt(self, i):
        return self._items[i] if 0 <= i < len(self._items) else None

    def takeAt(self, i):
        return self._items.pop(i) if 0 <= i < len(self._items) else None

    def expandingDirections(self):
        for ctor in ("Orientations", "Orientation"):
            try:
                return getattr(QtCore.Qt, ctor)(0)
            except Exception:
                continue
        return super().expandingDirections()

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        return self._layout(QtCore.QRect(0, 0, width, 0), True)

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self._layout(rect, False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        size = QtCore.QSize()
        for it in self._items:
            size = size.expandedTo(it.minimumSize())
        m = self.contentsMargins()
        return size + QtCore.QSize(m.left() + m.right(),
                                   m.top() + m.bottom())

    def _layout(self, rect, test_only):
        x, y, line_h = rect.x(), rect.y(), 0
        for it in self._items:
            hint = it.sizeHint()
            w, h = hint.width(), hint.height()
            if x + w > rect.right() + 1 and line_h > 0:
                x = rect.x()
                y += line_h + self._v
                line_h = 0
            if not test_only:
                it.setGeometry(QtCore.QRect(QtCore.QPoint(x, y), hint))
            x += w + self._h
            line_h = max(line_h, h)
        return y + line_h - rect.y()


def _clear_layout(lay):
    while lay.count():
        item = lay.takeAt(0)
        w = item.widget()
        if w is not None:
            w.deleteLater()


# ---------------------------------------------------------------------------
# segmented gauge (ready = green cells, flagged = amber cells)
# ---------------------------------------------------------------------------

class _Gauge(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._ready = 0
        self._flagged = 0
        self.setFixedHeight(14)
        self.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding,
                           QtWidgets.QSizePolicy.Policy.Fixed)

    def set_values(self, ready, flagged):
        self._ready = max(int(ready), 0)
        self._flagged = max(int(flagged), 0)
        self.update()

    def paintEvent(self, event):
        try:
            p = QtGui.QPainter(self)
            w = self.width()
            h = self.height()
            n = _GAUGE_CELLS
            gap = 2
            cw = max((w - gap * (n - 1)) / float(n), 1.0)
            total = self._ready + self._flagged
            if total > 0:
                green_cells = int(round(n * self._ready / float(total)))
                if self._flagged and green_cells == n:
                    green_cells = n - 1     # flagged never invisible
                if self._ready and green_cells == 0:
                    green_cells = 1
            else:
                green_cells = 0
            dim = QtGui.QColor("#141b22")
            green = QtGui.QColor(_GREEN)
            amber = QtGui.QColor(_AMBER)
            for i in range(n):
                if total <= 0:
                    col = dim
                elif i < green_cells:
                    col = green
                else:
                    col = amber
                x = int(round(i * (cw + gap)))
                p.fillRect(QtCore.QRectF(x, 2, cw, h - 4), col)
            p.end()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# recipe card — one layer, one recipe: chips + example + inline editor
# ---------------------------------------------------------------------------

class RecipeCard(QtWidgets.QFrame):
    """One recipe row: icon + layer name + count, template as token chips,
    a live example label, and an inline EDIT panel that rebuilds the Recipe
    live — template / layer / write-to + id fields / host reach / per-token
    field map ("editable headings") / auto-number sequence.  Every rebuild
    is a Recipe.to_dict() merge, so engine knobs the editor doesn't surface
    (also_fill, poly_refs, chainage, card_per, constants, sequence prefix &
    scope) are never dropped."""

    changed = QtCore.pyqtSignal()

    def __init__(self, role, recipe, layer, constants, parent=None):
        super().__init__(parent)
        self.role = role
        self._recipe = recipe
        self._constants = dict(constants or {})
        self._first_attrs = None
        self._real_example = None
        self._error = None
        self._loading = False
        self._fmap_combos = {}
        icon, friendly, _hints = _role_meta(role)
        self._icon = icon
        self._friendly = friendly
        self.setProperty("vnCard", "on")
        self._build()
        self._sync_editor_from_recipe()
        self.set_layer(layer, emit=False)

    # -- ui -------------------------------------------------------------------

    def _build(self):
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(12, 10, 12, 10)
        lay.setSpacing(7)

        top = QtWidgets.QHBoxLayout()
        top.setSpacing(8)
        self.icon_lbl = QtWidgets.QLabel(self._icon)
        top.addWidget(self.icon_lbl)
        self.name_lbl = QtWidgets.QLabel(self._friendly)
        self.name_lbl.setProperty("vnRole", "cardname")
        top.addWidget(self.name_lbl)
        top.addStretch(1)
        self.count_lbl = QtWidgets.QLabel("")
        self.count_lbl.setProperty("vnRole", "muted")
        self.count_lbl.setFont(_mono_font())
        top.addWidget(self.count_lbl)
        self.status_chip = _chip("", "grey")
        self.status_chip.hide()
        top.addWidget(self.status_chip)
        self.edit_btn = QtWidgets.QPushButton("EDIT")
        self.edit_btn.setProperty("vnEdit", True)
        self.edit_btn.setCheckable(True)
        self.edit_btn.setCursor(QtGui.QCursor(Qt.CursorShape.PointingHandCursor))
        top.addWidget(self.edit_btn)
        lay.addLayout(top)

        chips_host = QtWidgets.QWidget()
        self.chips_lay = _FlowLayout(chips_host, hspace=4, vspace=4)
        lay.addWidget(chips_host)

        self.example_lbl = QtWidgets.QLabel("")
        self.example_lbl.setProperty("vnRole", "example")
        self.example_lbl.setFont(_mono_font(9))
        self.example_lbl.setWordWrap(True)
        lay.addWidget(self.example_lbl)

        self.err_lbl = QtWidgets.QLabel("")
        self.err_lbl.setProperty("vnBanner", "warn")
        self.err_lbl.setWordWrap(True)
        self.err_lbl.hide()
        lay.addWidget(self.err_lbl)

        # inline editor (hidden until EDIT)
        self.editor = QtWidgets.QFrame()
        self.editor.setProperty("vnPanel", True)
        g = QtWidgets.QGridLayout(self.editor)
        g.setContentsMargins(8, 8, 8, 8)
        g.setSpacing(6)
        g.addWidget(_muted("template"), 0, 0)
        self.template_edit = QtWidgets.QLineEdit(self._recipe.template)
        self.template_edit.setFont(_mono_font())
        g.addWidget(self.template_edit, 0, 1, 1, 3)
        g.addWidget(_muted("layer"), 1, 0)
        self.layer_cb = _layer_combo(
            "line" if self._recipe.kind == "cable" else "point",
            allow_empty=True)
        g.addWidget(self.layer_cb, 1, 1, 1, 3)
        g.addWidget(_muted("write label to"), 2, 0)
        self.label_field_cb = QtWidgets.QComboBox()
        self.label_field_cb.setEditable(True)      # headings may not exist yet
        self.label_field_cb.setInsertPolicy(
            QtWidgets.QComboBox.InsertPolicy.NoInsert)
        self.label_field_cb.setToolTip(
            "The attribute-table heading the label is written to — apply "
            "creates it if it doesn't exist yet (e.g. 'Name').")
        g.addWidget(self.label_field_cb, 2, 1)
        g.addWidget(_muted("id field"), 2, 2)
        self.id_field_cb = QtWidgets.QComboBox()
        g.addWidget(self.id_field_cb, 2, 3)
        g.addWidget(_muted("pole reach"), 3, 0)
        self.host_spin = QtWidgets.QDoubleSpinBox()
        self.host_spin.setRange(5.0, 1000.0)
        self.host_spin.setDecimals(0)
        self.host_spin.setSuffix(" m")
        self.host_spin.setValue(float(self._recipe.host_max_m or 60.0))
        g.addWidget(self.host_spin, 3, 1)

        # field map — bind each template {token} to an actual layer heading
        g.addWidget(_rule(), 4, 0, 1, 4)
        g.addWidget(_muted("columns — what each {token} reads from the "
                           "attribute table (blank = a constant or a field "
                           "named like the token)"), 5, 0, 1, 4)
        self.fmap_host = QtWidgets.QWidget()
        self.fmap_grid = QtWidgets.QGridLayout(self.fmap_host)
        self.fmap_grid.setContentsMargins(0, 0, 0, 0)
        self.fmap_grid.setSpacing(4)
        g.addWidget(self.fmap_host, 6, 0, 1, 4)

        # auto-number — OFF by default (use the existing numbers as-is)
        self.autonum_chk = QtWidgets.QCheckBox(
            "Auto-number — existing numbers kept, empties get the next one")
        g.addWidget(self.autonum_chk, 7, 0, 1, 4)
        self.seq_row = QtWidgets.QWidget()
        sq = QtWidgets.QHBoxLayout(self.seq_row)
        sq.setContentsMargins(0, 0, 0, 0)
        sq.setSpacing(6)
        sq.addWidget(_muted("token"))
        self.seq_token_cb = QtWidgets.QComboBox()
        sq.addWidget(self.seq_token_cb)
        sq.addWidget(_muted("start"))
        self.seq_start = QtWidgets.QSpinBox()
        self.seq_start.setRange(0, 999999)
        self.seq_start.setValue(1)
        sq.addWidget(self.seq_start)
        sq.addWidget(_muted("pad"))
        self.seq_pad = QtWidgets.QSpinBox()
        self.seq_pad.setRange(0, 8)
        sq.addWidget(self.seq_pad)
        sq.addWidget(_muted("order"))
        self.seq_order_cb = QtWidgets.QComboBox()
        for cap, val in (("existing field", "field"),
                         ("spatial chain", "spatial"),
                         ("west → east", "x"), ("south → north", "y")):
            self.seq_order_cb.addItem(cap, val)
        sq.addWidget(self.seq_order_cb)
        self.seq_field_cb = QtWidgets.QComboBox()
        self.seq_field_cb.hide()
        sq.addWidget(self.seq_field_cb)
        sq.addStretch(1)
        self.seq_row.hide()
        g.addWidget(self.seq_row, 8, 0, 1, 4)

        g.setColumnStretch(1, 1)
        g.setColumnStretch(3, 1)
        self.editor.hide()
        lay.addWidget(self.editor)

        self.edit_btn.toggled.connect(self.editor.setVisible)
        self.template_edit.textEdited.connect(self._rebuild_recipe)
        _on_layer_signal(self.layer_cb, self._on_layer_changed)
        self.label_field_cb.currentTextChanged.connect(
            lambda *_: self._rebuild_recipe())
        self.id_field_cb.currentTextChanged.connect(
            lambda *_: self._emit_changed())
        self.host_spin.valueChanged.connect(
            lambda *_: self._rebuild_recipe())
        self.autonum_chk.toggled.connect(self._on_autonum_toggled)
        self.seq_token_cb.currentTextChanged.connect(
            lambda *_: self._rebuild_recipe())
        self.seq_start.valueChanged.connect(
            lambda *_: self._rebuild_recipe())
        self.seq_pad.valueChanged.connect(
            lambda *_: self._rebuild_recipe())
        self.seq_order_cb.currentIndexChanged.connect(
            self._on_seq_order_changed)
        self.seq_field_cb.currentTextChanged.connect(
            lambda *_: self._rebuild_recipe())

    # -- accessors --------------------------------------------------------------

    def recipe(self):
        return self._recipe

    def layer(self):
        return _current_layer(self.layer_cb)

    def id_field(self):
        return self.id_field_cb.currentText().strip() or "$id"

    def error(self):
        if self.layer() is None:
            return None                  # inactive cards can't block
        return self._error

    def is_active(self):
        return self.layer() is not None and self._error is None

    # -- state ------------------------------------------------------------------

    def set_layer(self, layer, emit=True):
        self._loading = True
        try:
            _set_combo_layer(self.layer_cb, layer)
        finally:
            self._loading = False
        self._on_layer_changed(emit=emit)

    def set_recipe(self, recipe):
        """Replace the recipe (preset click / constants reseed) — keeps the
        layer assignment; the NEW recipe's knobs win over stale editor text."""
        if recipe is None:
            return
        self._recipe = recipe
        self._real_example = None
        self._error = None
        self.err_lbl.hide()
        self._sync_editor_from_recipe()
        self._emit_changed()

    def update_constants(self, constants):
        self._constants = dict(constants or {})
        self._real_example = None
        self._render()

    def set_status(self, ready, flagged):
        if ready is None:
            self.status_chip.hide()
            return
        color = "amber" if flagged else "green"
        _set_chip(self.status_chip, "%d ready · %d flagged"
                  % (int(ready), int(flagged)), color)
        self.status_chip.show()

    def set_real_example(self, label):
        self._real_example = label
        self._render_example()

    # -- internals ----------------------------------------------------------------

    def _emit_changed(self):
        if not self._loading:
            self.changed.emit()

    def _on_layer_changed(self, *_args, emit=True):
        if self._loading:
            return
        lyr = self.layer()
        self._first_attrs = None
        self._real_example = None
        if lyr is not None:
            try:
                self.name_lbl.setText("%s  ·  %s"
                                      % (self._friendly, lyr.name()))
            except Exception:
                self.name_lbl.setText(self._friendly)
            self.name_lbl.setProperty("vnRole", "cardname")
            self.count_lbl.setText("{:,}".format(_feature_count(lyr)))
        else:
            self.name_lbl.setText("%s  ·  no layer found" % self._friendly)
            self.name_lbl.setProperty("vnRole", "cardname-off")
            self.count_lbl.setText("")
        _repolish(self.name_lbl)
        self.setProperty("vnCard", "on" if lyr is not None else "off")
        _repolish(self)
        self._refresh_fields()
        self._rebuild_recipe(silent=True)
        if emit:
            self._emit_changed()

    def _sync_editor_from_recipe(self):
        """Push EVERY recipe knob into the editor widgets (signal-safe) —
        the reverse of _rebuild_recipe()."""
        rec = self._recipe
        was = self._loading
        self._loading = True
        try:
            self.template_edit.setText(rec.template)
            self.host_spin.setValue(float(rec.host_max_m or 60.0))
            self.autonum_chk.setChecked(
                bool(getattr(rec, "auto_number", False)))
            seq = getattr(rec, "sequence", None)
            self.seq_start.setValue(int(getattr(seq, "start", 1) or 1))
            self.seq_pad.setValue(int(getattr(seq, "pad", 0) or 0))
            ob = str(getattr(seq, "order_by", "y") or "y")
            key = "field" if ob.startswith("field:") else ob
            idx = self.seq_order_cb.findData(key)
            if idx < 0:
                idx = max(self.seq_order_cb.findData("y"), 0)
            self.seq_order_cb.setCurrentIndex(idx)
            self.seq_row.setVisible(self.autonum_chk.isChecked())
            self.seq_field_cb.setVisible(key == "field")
        finally:
            self._loading = was
        self._refresh_fields(prefer_recipe=True)
        self._render()

    def _refresh_fields(self, prefer_recipe=False):
        """Repopulate every field-driven combo (write-to, id, sequence,
        field-map rows) from the current layer's headings.  prefer_recipe
        makes the RECIPE's own picks win over the widgets' previous text
        (used when a preset replaces the recipe)."""
        lyr = self.layer()
        names = _field_names(lyr) if lyr is not None else []
        low = {n.lower(): n for n in names}
        rec = self._recipe
        was = self._loading
        self._loading = True
        try:
            prev_lab = self.label_field_cb.currentText().strip()
            want_lab = (rec.label_field if prefer_recipe or not prev_lab
                        else prev_lab) or rec.label_field
            if want_lab and want_lab not in names and \
                    want_lab.lower() in low:
                want_lab = low[want_lab.lower()]      # 'label' vs 'Label'
            self.label_field_cb.clear()
            self.label_field_cb.addItems(names)
            if want_lab and want_lab not in names:
                # heading doesn't exist yet — apply() auto-creates it
                self.label_field_cb.addItem(want_lab)
            if not want_lab:
                want_lab = _guess_field(names, "label", "label_1", "name",
                                        contains="label") or ""
            if want_lab:
                idx = self.label_field_cb.findText(want_lab)
                if idx >= 0:
                    self.label_field_cb.setCurrentIndex(idx)
                else:
                    self.label_field_cb.setEditText(want_lab)

            prev_id = self.id_field_cb.currentText()
            self.id_field_cb.clear()
            self.id_field_cb.addItem("$id")
            self.id_field_cb.addItems(names)
            idx = self.id_field_cb.findText(prev_id)
            self.id_field_cb.setCurrentIndex(idx if idx >= 0 else 0)

            # sequence token list follows the template's mappable tokens
            toks = self._mappable_tokens()
            seq = getattr(rec, "sequence", None)
            prev_tok = self.seq_token_cb.currentText().strip()
            want_tok = (getattr(seq, "token", None)
                        if prefer_recipe or not prev_tok else prev_tok) or \
                getattr(seq, "token", None) or ""
            self.seq_token_cb.clear()
            self.seq_token_cb.addItems(toks)
            if want_tok and want_tok not in toks:
                self.seq_token_cb.addItem(want_tok)
            if want_tok:
                idx = self.seq_token_cb.findText(want_tok)
                self.seq_token_cb.setCurrentIndex(max(idx, 0))

            ob = str(getattr(seq, "order_by", "") or "")
            prev_fld = self.seq_field_cb.currentText().strip()
            want_fld = (ob[6:] if ob.startswith("field:") else "") \
                if prefer_recipe or not prev_fld else prev_fld
            self.seq_field_cb.clear()
            self.seq_field_cb.addItems(names)
            if want_fld:
                idx = self.seq_field_cb.findText(want_fld)
                if idx >= 0:
                    self.seq_field_cb.setCurrentIndex(idx)

            self._rebuild_fmap_rows(names, prefer_recipe=prefer_recipe)
        finally:
            self._loading = was

    def _eff_consts(self):
        """Recipe default constants overlaid by NON-EMPTY session constants —
        the same precedence the engine's _effective_constants uses."""
        out = dict(getattr(self._recipe, "constants", {}) or {})
        for k, v in self._constants.items():
            if v not in (None, ""):
                out[k] = v
        return out

    def _mappable_tokens(self):
        """Template tokens that can bind to a layer heading — everything
        except map references, engine-derived tokens and polygon refs."""
        eng = _engine()
        skip = set(getattr(eng, "GEOM_REFS", ())) | _DERIVED_REFS | \
            set(getattr(self._recipe, "poly_refs", ()) or ())
        out = []
        try:
            for t in eng.template_tokens(self._recipe.template):
                if t and t not in skip and t not in out:
                    out.append(t)
        except Exception:
            pass
        return out

    def _rebuild_fmap_rows(self, names=None, prefer_recipe=False):
        """One editor row per mappable {token}: token -> layer heading combo.
        This is the operator's 'adjust every attribute-table heading' knob;
        the picks write Recipe.field_map."""
        if names is None:
            lyr = self.layer()
            names = _field_names(lyr) if lyr is not None else []
        was = self._loading
        self._loading = True
        try:
            prev = {t: cb.currentText().strip()
                    for t, cb in self._fmap_combos.items()}
            _clear_layout(self.fmap_grid)
            self._fmap_combos = {}
            fmap = dict(getattr(self._recipe, "field_map", {}) or {})
            low = {n.lower(): n for n in names}
            toks = self._mappable_tokens()
            for r, tok in enumerate(toks):
                lbl = QtWidgets.QLabel("{%s}" % tok)
                lbl.setProperty("vnRole", "mono")
                lbl.setFont(_mono_font())
                self.fmap_grid.addWidget(lbl, r, 0)
                self.fmap_grid.addWidget(_muted("reads"), r, 1)
                cb = QtWidgets.QComboBox()
                cb.setEditable(True)
                cb.setInsertPolicy(
                    QtWidgets.QComboBox.InsertPolicy.NoInsert)
                cb.addItem("")               # blank = constant / own field
                cb.addItems(names)
                want = fmap.get(tok, "") if prefer_recipe \
                    else (prev.get(tok, "") or fmap.get(tok, ""))
                if want and want not in names and want.lower() in low:
                    want = low[want.lower()]
                if want:
                    idx = cb.findText(want)
                    if idx >= 0:
                        cb.setCurrentIndex(idx)
                    else:
                        cb.setEditText(want)
                cb.setToolTip("The attribute-table heading {%s} reads — "
                              "blank means a constant, or a field literally "
                              "named '%s'." % (tok, tok))
                cb.currentTextChanged.connect(
                    lambda *_: self._rebuild_recipe())
                self.fmap_grid.addWidget(cb, r, 2)
                self._fmap_combos[tok] = cb
            self.fmap_grid.setColumnStretch(2, 1)
            self.fmap_host.setVisible(bool(toks))
        finally:
            self._loading = was

    def _fmap_from_widgets(self):
        out = {}
        for tok, cb in self._fmap_combos.items():
            v = cb.currentText().strip()
            if v:
                out[tok] = v
        return out

    def _sequence_dict(self, base):
        """Fold the sequence widgets over the recipe's existing sequence
        dict — prefix/scope/letter_block/block are preserved untouched."""
        d = dict(base or {})
        tok = self.seq_token_cb.currentText().strip() or d.get("token", "")
        if not tok:
            return d or None
        d["token"] = tok
        d["start"] = int(self.seq_start.value())
        d["pad"] = int(self.seq_pad.value())
        mode = self.seq_order_cb.currentData()
        if mode == "field":
            fld = self.seq_field_cb.currentText().strip()
            d["order_by"] = ("field:%s" % fld) if fld \
                else d.get("order_by", "y")
        elif mode:
            d["order_by"] = mode
        d.setdefault("scope", [])
        return d

    def _sync_token_widgets(self):
        """The template's token set changed — refresh the field-map rows and
        the sequence-token list without disturbing the user's other picks."""
        toks = self._mappable_tokens()
        if set(toks) != set(self._fmap_combos.keys()):
            self._rebuild_fmap_rows()
        was = self._loading
        self._loading = True
        try:
            cur = self.seq_token_cb.currentText().strip()
            items = [self.seq_token_cb.itemText(i)
                     for i in range(self.seq_token_cb.count())]
            if items != toks and set(items) != set(toks):
                self.seq_token_cb.clear()
                self.seq_token_cb.addItems(toks)
                if cur:
                    idx = self.seq_token_cb.findText(cur)
                    if idx < 0:
                        self.seq_token_cb.addItem(cur)
                        idx = self.seq_token_cb.findText(cur)
                    self.seq_token_cb.setCurrentIndex(max(idx, 0))
        finally:
            self._loading = was

    def _on_autonum_toggled(self, on):
        self.seq_row.setVisible(bool(on))
        self._on_seq_order_changed()

    def _on_seq_order_changed(self, *_):
        try:
            self.seq_field_cb.setVisible(
                self.seq_order_cb.currentData() == "field")
        except Exception:
            pass
        self._rebuild_recipe()

    def _rebuild_recipe(self, *_args, silent=False):
        """Fold the editor back into a Recipe via a to_dict() MERGE — carries
        every engine knob (field_map, auto_number, sequence, poly_refs,
        chainage, card_per, constants, also_fill), so nothing a preset
        configured is ever dropped by an edit."""
        if self._loading:
            return
        eng = _engine()
        tmpl = self.template_edit.text().strip() or self._recipe.template
        try:
            list(_FMT.parse(tmpl))                   # validates the template
            eng.template_tokens(tmpl)
        except Exception as exc:
            self._error = "template problem: %s" % exc
            self.err_lbl.setText("Template problem: %s" % exc)
            self.err_lbl.show()
            if not silent:
                self._emit_changed()
            return
        self._error = None
        self.err_lbl.hide()
        label_field = (self.label_field_cb.currentText().strip()
                       or self._recipe.label_field)
        try:
            d = self._recipe.to_dict()
        except Exception:
            d = {"layer_role": self.role, "template": tmpl,
                 "kind": getattr(self._recipe, "kind", "point")}
        d["template"] = tmpl
        d["label_field"] = label_field
        d["host_max_m"] = float(self.host_spin.value())
        fmap = {t: f for t, f in dict(d.get("field_map") or {}).items()
                if t not in self._fmap_combos}       # keep hidden mappings
        fmap.update(self._fmap_from_widgets())
        d["field_map"] = fmap
        d["auto_number"] = bool(self.autonum_chk.isChecked())
        d["sequence"] = self._sequence_dict(d.get("sequence"))
        if d["auto_number"] and not (d.get("sequence") or {}).get("token"):
            d["auto_number"] = False       # nothing to number — engine-safe
        try:
            self._recipe = eng.Recipe.from_dict(d)
        except Exception as exc:
            self._error = str(exc)
            self.err_lbl.setText("Recipe problem: %s" % exc)
            self.err_lbl.show()
        self._sync_token_widgets()
        self._real_example = None
        self._render()
        if not silent:
            self._emit_changed()

    # -- rendering -------------------------------------------------------------------

    def _render(self):
        self._render_chips()
        self._render_example()

    def _render_chips(self):
        """Template -> token chips, mirroring the ENGINE's resolution order
        (geom/derived/poly ref > auto-number > field_map > constant > own
        field).  Literal text + constant VALUES fuse into grey chips; map
        references become cyan chips with a friendly phrase; field-mapped /
        own-field tokens become amber chips showing the mapped heading and
        the first feature's sample value."""
        _clear_layout(self.chips_lay)
        eng = _engine()
        geom_refs = set(getattr(eng, "GEOM_REFS", ()))
        rec = self._recipe
        poly_refs = set(getattr(rec, "poly_refs", ()) or ())
        fmap = dict(getattr(rec, "field_map", {}) or {})
        seq = getattr(rec, "sequence", None)
        seq_tok = getattr(seq, "token", None) \
            if getattr(rec, "auto_number", False) else None
        consts = self._eff_consts()
        try:
            segments = list(_FMT.parse(rec.template))
        except Exception:
            self.chips_lay.addWidget(_token_chip(rec.template, "lit"))
            return
        if self._first_attrs is None:
            lyr = self.layer()
            self._first_attrs = _first_attrs(lyr) if lyr is not None else {}

        def _flush(buf):
            if buf:
                self.chips_lay.addWidget(_token_chip(buf, "lit"))
            return ""

        buf = ""
        for lit, fname, _spec, _conv in segments:
            buf += lit or ""
            if not fname:
                continue
            if fname in geom_refs or fname in _DERIVED_REFS \
                    or fname in poly_refs:
                buf = _flush(buf)
                phrase = _TOKEN_PHRASES.get(
                    fname, ("the %s it's in" % fname)
                    if fname in poly_refs else fname)
                self.chips_lay.addWidget(_token_chip(
                    phrase, "ref", _TOKEN_TIPS.get(fname,
                                                   "filled from the map")))
            elif seq_tok is not None and fname == seq_tok:
                buf = _flush(buf)
                self.chips_lay.addWidget(_token_chip(
                    "auto # (%s…)" % _seq_sample(seq), "ref",
                    "auto-numbered — existing values are kept, empty ones "
                    "get the next number"))
            elif fname in fmap:
                buf = _flush(buf)
                heading = fmap[fname]
                sample = self._first_attrs.get(heading)
                text = ("%s · %s" % (heading, sample)
                        if sample not in (None, "") else heading)
                self.chips_lay.addWidget(_token_chip(
                    text, "field",
                    "reads the '%s' column ({%s})" % (heading, fname)))
            elif fname in consts:
                buf += str(consts[fname])            # fuse constant value
            else:
                buf = _flush(buf)
                sample = self._first_attrs.get(fname)
                text = str(sample) if sample not in (None, "") else fname
                self.chips_lay.addWidget(_token_chip(
                    text, "field",
                    "from the feature's '%s' field" % fname))
        _flush(buf)

    def _render_example(self):
        if self._real_example:
            self.example_lbl.setText("e.g.  %s" % self._real_example)
            return
        self.example_lbl.setText(self._example_text())

    def _example_text(self):
        """Best-effort example from the FIRST feature: real constants +
        field-map-resolved feature fields, placeholder samples for the map /
        derived references and the auto-number sequence."""
        eng = _engine()
        geom_refs = set(getattr(eng, "GEOM_REFS", ()))
        rec = self._recipe
        consts = self._eff_consts()
        stack = str(consts.get("stack", "") or "")
        fmap = dict(getattr(rec, "field_map", {}) or {})
        poly_refs = set(getattr(rec, "poly_refs", ()) or ())
        seq = getattr(rec, "sequence", None)
        seq_tok = getattr(seq, "token", None) \
            if getattr(rec, "auto_number", False) else None
        try:
            if self._first_attrs is None:
                lyr = self.layer()
                self._first_attrs = (_first_attrs(lyr)
                                     if lyr is not None else {})
            ctx = {}
            for name in eng.template_tokens(rec.template):
                if name in geom_refs or name in _DERIVED_REFS \
                        or name in poly_refs:
                    ctx[name] = _ref_sample(name, stack)
                elif seq_tok is not None and name == seq_tok:
                    ctx[name] = _seq_sample(seq)
                elif name in fmap:
                    v = self._first_attrs.get(fmap[name])
                    ctx[name] = "" if v in (None, "") else v
                elif name in consts:
                    ctx[name] = consts[name]
                else:
                    v = self._first_attrs.get(name)
                    ctx[name] = "" if v in (None, "") else v
            return "e.g.  %s" % _FMT.vformat(rec.template, (),
                                             _SafeDict(ctx))
        except Exception:
            return ""


# ---------------------------------------------------------------------------
# pure compose loop (worker thread) — replicates label_recipe.dry_run() over
# rows extracted on the MAIN thread; returns the EXACT dry_run structure so
# label_recipe.apply() consumes it unchanged.
# ---------------------------------------------------------------------------

def _compose_dry(extracted, host_index, polygons, constants, walk=False):
    """Replicates label_recipe.dry_run() over the pre-extracted rows —
    INCLUDING the auto-number pre-pass (resolve refs for the whole layer,
    assign_sequence, then compose with the injected value) — and returns
    the exact same structure, so label_recipe.apply() consumes it as-is.

    walk=True: number in physical network-walk order. Each row already carries
    a "walk_order" index (injected during main-thread extraction); here we
    clone the recipe's sequence spec to order_by="walk" so assign_sequence uses
    that index instead of the spatial default. The recipe itself is untouched."""
    eng = _engine()

    def _eff(rec):
        fn = getattr(eng, "_effective_constants", None)
        if fn is not None:
            try:
                return fn(rec, constants)
            except Exception:
                pass
        out = dict(getattr(rec, "constants", {}) or {})
        for k, v in (constants or {}).items():
            if v not in (None, ""):
                out[k] = v
        return out

    result = {"_totals": {"ready": 0, "flagged": 0, "skipped": 0}}
    for role, pack in extracted.items():
        rec = pack["recipe"]
        changes = []
        labels = {}
        flags = []
        # geometry-skipped features are recorded during MAIN-thread extraction
        # (rows here are already geometry-filtered) — surface them so the async
        # preview total reconciles just like label_recipe.dry_run().
        skips = dict(pack.get("skips", {}))
        skipped = pack.get("skipped", len(skips))
        ready = flagged = 0
        feats = []
        for row in pack["rows"]:
            feat = {"attrs": row["attrs"]}
            if rec.kind == "cable":
                feat["coords"] = row["coords"]
            else:
                feat["xy"] = row["xy"]
            if walk and "walk_order" in row:
                feat["walk_order"] = row["walk_order"]
            feats.append(feat)
        resolved = None
        seq_vals = None
        if getattr(rec, "auto_number", False) and \
                getattr(rec, "sequence", None) is not None:
            consts_m = _eff(rec)
            spec = rec.sequence
            if walk:                     # order by the physical walk, not space
                spec = eng.SequenceSpec.from_dict(
                    {**spec.to_dict(), "order_by": "walk"})
            resolved = [eng.resolve_refs(ft, rec, host_index, polygons,
                                         consts_m) for ft in feats]
            seq_vals = eng.assign_sequence(
                feats, spec, constants=consts_m,
                refs_list=[rf for rf, _fl in resolved],
                field_map=getattr(rec, "field_map", None))
        for i, row in enumerate(pack["rows"]):
            label, fills, fl = eng.compose(
                feats[i], rec, host_index, polygons, constants,
                resolved=(resolved[i] if resolved is not None else None),
                seq_value=(seq_vals[i] if seq_vals is not None else None))
            fid = row["fid"]
            labels[fid] = (label, fills)
            if label is None:
                flagged += 1
                for x in fl:
                    flags.append({"fid": fid, **x})
            else:
                ready += 1
                if row["old"] != label:
                    changes.append({"fid": row["qfid"], "old": row["old"],
                                    "new": label, "fills": fills})
        result[role] = {"changes": changes, "ready": ready,
                        "flagged": flagged, "flags": flags, "labels": labels,
                        "skipped": skipped, "skips": skips,
                        "create_fields": list(pack.get("create_fields", ()))}
        result["_totals"]["ready"] += ready
        result["_totals"]["flagged"] += flagged
        result["_totals"]["skipped"] += skipped
    return result


# ---------------------------------------------------------------------------
# the ONE-screen dock widget
# ---------------------------------------------------------------------------

class LabelMyNetworkWidget(QtWidgets.QWidget):
    """Label My Network — recipe-per-layer labelling on one scrollable screen.

    Nothing is written until LABEL EVERYTHING; apply is guarded by a preview
    staleness token, a default-ON backup, and keeps a one-click undo map."""

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self._cards = []
        self._dry = None
        self._dry_token = ""
        self._undo = None
        self._undo_lrcs = None
        self._running = False
        self._walk_order = False
        self._loading = True
        self._ht_zoned = False        # HeroTel _Z{zone} template state
        self.setObjectName("vnRoot")
        try:
            self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        except Exception:
            pass
        try:
            self.setStyleSheet(_QSS)
        except Exception:
            # QSS failed — fall back to theme-safe palette text so the panel
            # stays readable on the native (light or dark) theme.
            c = _theme_colors(self)
            try:
                self.setStyleSheet("#vnRoot QLabel { color:%s; }" % c["ink"])
            except Exception:
                pass
        try:
            self._build()
        finally:
            self._loading = False

    # -- corner ticks + top scanline (Mission-Control frame) --------------------

    def paintEvent(self, event):
        try:
            opt = QtWidgets.QStyleOption()
            opt.initFrom(self)
            p = QtGui.QPainter(self)
            self.style().drawPrimitive(
                QtWidgets.QStyle.PrimitiveElement.PE_Widget, opt, p, self)
            w = self.width()
            grad = QtGui.QLinearGradient(0, 0, w, 0)
            grad.setColorAt(0.0, QtGui.QColor(0, 229, 255, 0))
            grad.setColorAt(0.5, QtGui.QColor(0, 229, 255, 170))
            grad.setColorAt(1.0, QtGui.QColor(0, 229, 255, 0))
            p.fillRect(QtCore.QRectF(0, 0, w, 2), QtGui.QBrush(grad))
            pen = QtGui.QPen(QtGui.QColor(0, 229, 255, 130))
            pen.setWidthF(1.5)
            p.setPen(pen)
            t = 10                       # corner tick size + inset
            p.drawLine(8, 8 + t, 8, 8)
            p.drawLine(8, 8, 8 + t, 8)
            p.drawLine(w - 8 - t, 8, w - 8, 8)
            p.drawLine(w - 8, 8, w - 8, 8 + t)
            p.end()
        except Exception:
            pass

    # -- build -------------------------------------------------------------------

    def _build(self):
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(12, 14, 12, 10)
        outer.setSpacing(8)

        head = QtWidgets.QHBoxLayout()
        head.setSpacing(8)
        title = QtWidgets.QLabel("🏷️ LABEL MY NETWORK")
        title.setProperty("vnRole", "title")
        _glow(title, alpha=60)
        head.addWidget(title)
        head.addWidget(_chip("BETA", "amber"))
        head.addStretch(1)
        outer.addLayout(head)
        outer.addWidget(_muted(
            "You've placed everything. Cyan parts fill from the map. "
            "Nothing changes until you press Label."))
        outer.addWidget(_rule())

        self.banner = _Banner()
        outer.addWidget(self.banner)

        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        content = QtWidgets.QWidget()
        lay = QtWidgets.QVBoxLayout(content)
        lay.setContentsMargins(2, 0, 8, 4)
        lay.setSpacing(8)
        scroll.setWidget(content)
        outer.addWidget(scroll, 1)

        self._build_project_section(lay)
        self._build_recipes_section(lay)
        self._build_preview_section(lay)
        self._build_apply_section(lay)
        self._build_advanced_section(lay)
        lay.addStretch(1)

        self._restore_session()
        self._autodetect()

    # -- 01 PROJECT & PRESET -------------------------------------------------------

    def _build_project_section(self, lay):
        lay.addWidget(_section_row("01", "project & preset"))

        prow = QtWidgets.QHBoxLayout()
        prow.setSpacing(8)
        self.preset_group = QtWidgets.QButtonGroup(self)
        self.preset_group.setExclusive(True)
        self.preset_btns = {}
        for name in ("Fibertime", "Vuma", "HeroTel", "Custom"):
            btn = QtWidgets.QPushButton(name if name != "Custom"
                                        else "＋ Custom")
            btn.setProperty("vnPreset", True)
            btn.setCheckable(True)
            btn.setCursor(QtGui.QCursor(Qt.CursorShape.PointingHandCursor))
            btn.clicked.connect(lambda _=False, n=name: self._on_preset(n))
            self.preset_group.addButton(btn)
            self.preset_btns[name] = btn
            prow.addWidget(btn)
        prow.addStretch(1)
        lay.addLayout(prow)

        # per-client constants strip — only the picked client's inputs show
        strip = QtWidgets.QWidget()
        flow = _FlowLayout(strip, hspace=10, vspace=4)
        self.const_edits = {}
        self._const_cells = {}
        for key, label, ph, width in _CONST_DEFS:
            cell = QtWidgets.QWidget()
            cl = QtWidgets.QHBoxLayout(cell)
            cl.setContentsMargins(0, 0, 0, 0)
            cl.setSpacing(4)
            cl.addWidget(_muted(label))
            ed = QtWidgets.QLineEdit()
            ed.setFont(_mono_font())
            ed.setFixedWidth(width)
            ed.setPlaceholderText(ph)
            ed.textEdited.connect(self._on_constants_edited)
            cl.addWidget(ed)
            flow.addWidget(cell)
            self.const_edits[key] = ed
            self._const_cells[key] = cell
        self.ht_chk = QtWidgets.QCheckBox("HT_ prefix")
        self.ht_chk.setChecked(True)
        self.ht_chk.setToolTip("Prepend HT_ to every HeroTel label — untick "
                               "for bare MMB-style names")
        self.ht_chk.toggled.connect(self._on_ht_toggled)
        self.ht_chk.hide()
        flow.addWidget(self.ht_chk)
        lay.addWidget(strip)

    # -- constants / client plumbing ---------------------------------------------

    def _client(self):
        for name, btn in self.preset_btns.items():
            if btn.isChecked():
                return name
        return "Custom"

    def _client_key(self):
        """Per-project 'last client' settings key."""
        base = ""
        try:
            from qgis.core import QgsProject
            base = QgsProject.instance().baseName() or ""
        except Exception:
            pass
        return ("client__%s" % base) if base else "client"

    def _sync_const_strip(self, client):
        keys = _CLIENT_CONSTS.get(client, _CLIENT_CONSTS["Custom"])
        for key, cell in self._const_cells.items():
            cell.setVisible(key in keys)
        self.ht_chk.setVisible(client in ("HeroTel", "Custom"))

    def _constants(self):
        """The session constants dict fed to the recipe cards AND to
        dry_run/apply — only the picked client's inputs, plus the HeroTel
        {ht} prefix knob."""
        client = self._client()
        keys = _CLIENT_CONSTS.get(client, _CLIENT_CONSTS["Custom"])
        out = {k: self.const_edits[k].text().strip()
               for k in keys if k in self.const_edits}
        if client in ("HeroTel", "Custom"):
            out["ht"] = "HT_" if self.ht_chk.isChecked() else ""
        return out

    def _preset_consts(self):
        """Constants passed to recipe_preset() — non-empty only, so an empty
        HeroTel zone doesn't force the _Z{zone} template ({ht} is meaningful
        even when empty: it switches the HT_ prefix off)."""
        consts = {k: v for k, v in self._constants().items() if v != ""}
        if self._client() == "HeroTel":
            consts["ht"] = "HT_" if self.ht_chk.isChecked() else ""
        return consts

    def _seed_recipes(self, client):
        """Fresh preset recipes seeded with the project constants.
        Auto-number ships OFF (use the existing numbers as-is) — each card's
        EDIT panel turns it on explicitly; the preset's SequenceSpec is kept
        on the recipe so the toggle just works."""
        eng = _engine()
        recs = eng.recipe_preset(client, **self._preset_consts())
        for r in recs.values():
            r.auto_number = False
        return recs

    def _rebuild_cards(self, recipes):
        """One card per role the PRESET returned — iterate its dict (there
        is no fixed role list); _ROLE_ORDER is only a display preference."""
        _clear_layout(self.cards_lay)
        self._cards = []
        self._dry = None
        self._undo = None
        self._undo_lrcs = None
        layers = _project_layers()
        consts = self._constants()
        order = [r for r in _ROLE_ORDER if r in recipes]
        order += [r for r in recipes if r not in order]
        for role in order:
            rec = recipes.get(role)
            if rec is None:
                continue
            try:
                lyr = _match_layer(role, rec.kind, layers)
                card = RecipeCard(role, rec, lyr, consts)
                card.changed.connect(self._mark_stale)
                self._cards.append(card)
                self.cards_lay.addWidget(card)
            except Exception:
                continue
        try:
            self.gauge.set_values(0, 0)
            self.kpi_ready.setText("—")
            self.kpi_flagged.setText("—")
            self._sync_apply()
        except Exception:
            pass

    def _reseed_recipes(self):
        """Re-seed every card's recipe from the preset with the CURRENT
        constants — keeps the layer assignments.  Used when a constant
        changes the preset's SHAPE (HeroTel zone/HT_ toggles)."""
        client = self._client()
        try:
            recs = self._seed_recipes(client)
        except Exception as exc:
            self.banner.show_msg("error",
                                 "Could not refresh the recipes: %s" % exc)
            return
        consts = self._constants()
        if {c.role for c in self._cards} != set(recs.keys()):
            self._rebuild_cards(recs)
        else:
            for card in self._cards:
                card.update_constants(consts)
                card.set_recipe(recs.get(card.role))
        self._sync_poly_rows()
        self._mark_stale()

    def _on_constants_edited(self, *_):
        if self._loading:
            return
        client = self._client()
        if client == "HeroTel":
            zoned = bool(self.const_edits["zone"].text().strip())
            if zoned != self._ht_zoned:   # _Z{zone} appears/disappears
                self._ht_zoned = zoned
                self._reseed_recipes()
                return
        consts = self._constants()
        for card in self._cards:
            card.update_constants(consts)
        self._mark_stale()

    def _on_ht_toggled(self, *_):
        if self._loading:
            return
        if self._client() == "HeroTel":
            self._reseed_recipes()        # ht="" must reach Recipe.constants
        else:
            self._on_constants_edited()

    def _on_preset(self, client):
        self._sync_const_strip(client)
        try:
            _set_setting(self._client_key(), client)
            _set_setting("client", client)
        except Exception:
            pass
        if client == "Custom":
            self._on_constants_edited()   # keep the recipes, widen the strip
            return
        stack_ed = self.const_edits.get("stack")
        if client == "Fibertime" and stack_ed is not None and \
                not stack_ed.text().strip():
            stack_ed.setText(_detect_stack()
                             or _PRESET_STACKS.get(client, ""))
        aoi_ed = self.const_edits.get("aoi")
        if client == "HeroTel" and aoi_ed is not None and \
                not aoi_ed.text().strip():
            aoi_ed.setText(_detect_aoi())
        if client == "HeroTel":
            self._ht_zoned = bool(self.const_edits["zone"].text().strip())
        try:
            recs = self._seed_recipes(client)
        except Exception as exc:
            self.banner.show_msg("error", "Could not load the %s preset: %s"
                                 % (client, exc))
            return
        self._rebuild_cards(recs)
        self._sync_poly_rows()
        self._mark_stale()

    # -- 02 RECIPES -----------------------------------------------------------------

    def _build_recipes_section(self, lay):
        row = QtWidgets.QHBoxLayout()
        row.setSpacing(8)
        sec = _section_row("02", "recipes · one per layer")
        row.addWidget(sec, 1)
        lay.addLayout(row)
        lay.addWidget(_muted(
            "Poles keep their existing labels — cables and gear reference "
            "the nearest pole. Grey chips are fixed text, cyan fills from "
            "the map, amber comes from the feature's own field."))
        self.cards_lay = QtWidgets.QVBoxLayout()
        self.cards_lay.setSpacing(8)
        lay.addLayout(self.cards_lay)

    def _autodetect(self):
        """Restore the last client for THIS project, seed its preset recipes
        (constants included) + fuzzy-match each returned role to a layer."""
        try:
            _engine()
        except Exception as exc:
            self.banner.show_msg("error",
                                 "Labelling engine unavailable: %s" % exc)
            return
        client = "Fibertime"
        try:
            saved = str(_setting(self._client_key(), "")
                        or _setting("client", "Fibertime"))
            if saved in self.preset_btns:
                client = saved
        except Exception:
            pass
        stack_ed = self.const_edits.get("stack")
        if stack_ed is not None and not stack_ed.text().strip():
            stack_ed.setText(_detect_stack() or str(_setting("stack", ""))
                             or _PRESET_STACKS.get(client, "MOA"))
        aoi_ed = self.const_edits.get("aoi")
        if client == "HeroTel" and aoi_ed is not None and \
                not aoi_ed.text().strip():
            aoi_ed.setText(_detect_aoi())
        btn = self.preset_btns.get(client)
        if btn is not None:
            btn.setChecked(True)
        self._sync_const_strip(client)
        try:
            self._ht_zoned = bool(self.const_edits["zone"].text().strip())
        except Exception:
            self._ht_zoned = False
        try:
            recipes = self._seed_recipes(client)
        except Exception as exc:
            self.banner.show_msg("error", "Could not load recipes: %s" % exc)
            return
        self._rebuild_cards(recipes)
        self._guess_hosts_and_polygons(_project_layers())
        self._sync_poly_rows()

    # -- 03 PREVIEW -------------------------------------------------------------------

    def _build_preview_section(self, lay):
        lay.addWidget(_section_row("03", "preview"))
        panel = QtWidgets.QFrame()
        panel.setProperty("vnPanel", True)
        pv = QtWidgets.QVBoxLayout(panel)
        pv.setContentsMargins(12, 10, 12, 10)
        pv.setSpacing(8)

        prow = QtWidgets.QHBoxLayout()
        prow.setSpacing(8)
        self.preview_btn = QtWidgets.QPushButton("PREVIEW")
        self.preview_btn.setProperty("vnPrimary", True)
        self.preview_btn.setCursor(
            QtGui.QCursor(Qt.CursorShape.PointingHandCursor))
        prow.addWidget(self.preview_btn)
        self.stale_lbl = _muted("")
        prow.addWidget(self.stale_lbl, 1)
        pv.addLayout(prow)

        self.progress = QtWidgets.QProgressBar()
        self.progress.setRange(0, 0)               # indeterminate spinner
        self.progress.setTextVisible(False)
        self.progress.hide()
        pv.addWidget(self.progress)

        self.gauge = _Gauge()
        pv.addWidget(self.gauge)

        stats = QtWidgets.QHBoxLayout()
        stats.setSpacing(26)
        ready_box = QtWidgets.QVBoxLayout()
        ready_box.setSpacing(1)
        self.kpi_ready = QtWidgets.QLabel("—")
        self.kpi_ready.setProperty("vnKpi", "green")
        ready_box.addWidget(self.kpi_ready)
        ready_box.addWidget(_muted("features ready"))
        stats.addLayout(ready_box)
        flag_box = QtWidgets.QVBoxLayout()
        flag_box.setSpacing(1)
        self.kpi_flagged = QtWidgets.QLabel("—")
        self.kpi_flagged.setProperty("vnKpi", "amber")
        flag_box.addWidget(self.kpi_flagged)
        flag_box.addWidget(_muted("need a pole nearby"))
        stats.addLayout(flag_box)
        stats.addStretch(1)
        pv.addLayout(stats)

        self.changes_caption = _muted("")
        pv.addWidget(self.changes_caption)
        self.changes_table = QtWidgets.QTableWidget(0, 3)
        self.changes_table.setHorizontalHeaderLabels(["LAYER", "OLD", "NEW"])
        self.changes_table.verticalHeader().setVisible(False)
        self.changes_table.setAlternatingRowColors(True)
        self.changes_table.setEditTriggers(
            QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        self.changes_table.setSelectionMode(
            QtWidgets.QAbstractItemView.SelectionMode.NoSelection)
        try:
            hdr = self.changes_table.horizontalHeader()
            hdr.setSectionResizeMode(
                QtWidgets.QHeaderView.ResizeMode.Stretch)
        except Exception:
            pass
        self.changes_table.setMinimumHeight(160)
        self.changes_table.setMaximumHeight(230)
        self.changes_table.hide()
        pv.addWidget(self.changes_table)

        self.flags_caption = _muted("")
        pv.addWidget(self.flags_caption)
        self.flags_tree = QtWidgets.QTreeWidget()
        self.flags_tree.setColumnCount(2)
        self.flags_tree.setHeaderLabels(["FEATURE", "WHY"])
        self.flags_tree.setAlternatingRowColors(True)
        try:
            self.flags_tree.header().setSectionResizeMode(
                0, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
            self.flags_tree.header().setSectionResizeMode(
                1, QtWidgets.QHeaderView.ResizeMode.Stretch)
        except Exception:
            pass
        self.flags_tree.setMinimumHeight(110)
        self.flags_tree.setMaximumHeight(180)
        self.flags_tree.hide()
        pv.addWidget(self.flags_tree)

        lay.addWidget(panel)
        self.preview_btn.clicked.connect(self.start_preview)

    # -- 04 APPLY ------------------------------------------------------------------------

    def _build_apply_section(self, lay):
        lay.addWidget(_section_row("04", "apply"))
        panel = QtWidgets.QFrame()
        panel.setProperty("vnPanel", True)
        av = QtWidgets.QVBoxLayout(panel)
        av.setContentsMargins(12, 10, 12, 10)
        av.setSpacing(8)

        self.apply_summary = QtWidgets.QLabel("Run a preview first.")
        self.apply_summary.setProperty("vnRole", "mono")
        self.apply_summary.setFont(_mono_font(10))
        self.apply_summary.setWordWrap(True)
        av.addWidget(self.apply_summary)

        self.backup_chk = QtWidgets.QCheckBox(
            "Back up the project first (recommended — BETA writes to "
            "permanent layers)")
        self.backup_chk.setChecked(True)
        av.addWidget(self.backup_chk)

        self.apply_btn = QtWidgets.QPushButton("LABEL EVERYTHING  →")
        self.apply_btn.setProperty("vnApply", True)
        self.apply_btn.setEnabled(False)
        self.apply_btn.setCursor(
            QtGui.QCursor(Qt.CursorShape.PointingHandCursor))
        _glow(self.apply_btn, alpha=110, blur=26)
        av.addWidget(self.apply_btn)
        av.addWidget(_muted("↩ one-click UNDO is available right after "
                            "apply — old values are kept in memory."))

        self.result = _Banner()
        av.addWidget(self.result)

        lay.addWidget(panel)
        self.apply_btn.clicked.connect(self._apply)

    # -- ADVANCED ------------------------------------------------------------------------

    def _on_walk_toggled(self, on):
        """Toggle physical walk-order numbering; re-preview so the change shows."""
        self._walk_order = bool(on)
        self._dry = None              # numbering changed -> previous preview stale
        if not getattr(self, "_loading", False):
            try:
                self.start_preview()
            except Exception:
                pass

    def _build_advanced_section(self, lay):
        box = None
        try:
            from qgis.gui import QgsCollapsibleGroupBox
            box = QgsCollapsibleGroupBox(
                "⚙ ADVANCED — hosts, polygons & field dialects")
            try:
                box.setCollapsed(True)
            except Exception:
                pass
            body = box
        except Exception:
            box = QtWidgets.QWidget()
            bv = QtWidgets.QVBoxLayout(box)
            bv.setContentsMargins(0, 0, 0, 0)
            bv.setSpacing(6)
            toggle = QtWidgets.QToolButton()
            toggle.setText("⚙ ADVANCED — HOSTS, POLYGONS & FIELD DIALECTS")
            toggle.setCheckable(True)
            toggle.setChecked(False)
            try:
                toggle.setToolButtonStyle(
                    Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
                toggle.setArrowType(Qt.ArrowType.RightArrow)
                toggle.toggled.connect(lambda on: toggle.setArrowType(
                    Qt.ArrowType.DownArrow if on
                    else Qt.ArrowType.RightArrow))
            except Exception:
                pass
            bv.addWidget(toggle)
            body = QtWidgets.QFrame()
            body.setProperty("vnPanel", True)
            body.setVisible(False)
            toggle.toggled.connect(body.setVisible)
            bv.addWidget(body)

        g = QtWidgets.QGridLayout(body)
        g.setContentsMargins(10, 10, 10, 10)
        g.setSpacing(6)
        r = 0
        num_lbl = QtWidgets.QLabel("NUMBERING")
        num_lbl.setProperty("vnRole", "section")
        g.addWidget(num_lbl, r, 0, 1, 4)
        r += 1
        self.walk_chk = QtWidgets.QCheckBox(
            "Number in walk order (follow the physical fibre path from the POP)")
        self.walk_chk.setChecked(bool(getattr(self, "_walk_order", False)))
        self.walk_chk.setToolTip(
            "When on, auto-numbers each layer in the order the network is "
            "walked from the POP outward (POP → Primary → … → STS → Drop → ONT) "
            "instead of spatial order. Uses the project's cable + splitter + "
            "POP layers; falls back to normal order if there is no POP/network.")
        self.walk_chk.toggled.connect(self._on_walk_toggled)
        g.addWidget(self.walk_chk, r, 0, 1, 4)
        r += 1
        hosts_lbl = QtWidgets.QLabel("HOSTS — POLES & MANHOLES")
        hosts_lbl.setProperty("vnRole", "section")
        g.addWidget(hosts_lbl, r, 0, 1, 4)
        r += 1
        g.addWidget(_muted("Cables and gear snap their labels to the "
                           "nearest host with a label in this field."),
                    r, 0, 1, 4)
        r += 1
        self.host_rows = []
        for cap in ("poles", "manholes"):
            g.addWidget(_muted(cap), r, 0)
            lyr_cb = _layer_combo("point", allow_empty=True)
            g.addWidget(lyr_cb, r, 1)
            g.addWidget(_muted("label field"), r, 2)
            fld_cb = QtWidgets.QComboBox()
            g.addWidget(fld_cb, r, 3)
            self.host_rows.append((lyr_cb, fld_cb))
            _on_layer_signal(lyr_cb,
                             lambda *_a, row=(lyr_cb, fld_cb):
                             self._refresh_host_fields(row))
            fld_cb.currentTextChanged.connect(lambda *_: self._mark_stale())
            r += 1

        poly_lbl = QtWidgets.QLabel("POLYGONS — PON / ZONE / CUSTOM REFS")
        poly_lbl.setProperty("vnRole", "section")
        g.addWidget(poly_lbl, r, 0, 1, 4)
        r += 1
        g.addWidget(_muted("Every polygon ref the recipes use ({pon_no}, "
                           "{zone}, {ag}, …) reads the containing polygon's "
                           "value field — rows appear per preset."),
                    r, 0, 1, 4)
        r += 1
        self._poly_grid = QtWidgets.QGridLayout()
        self._poly_grid.setSpacing(6)
        g.addLayout(self._poly_grid, r, 0, 1, 4)
        r += 1
        self.poly_rows = {}
        self._active_poly_refs = {"pon_no", "zone_no"}
        for ref in ("pon_no", "zone_no"):
            self._add_poly_row(ref)

        g.addWidget(_muted(
            "Field dialects differ per project — Mohadin poles use "
            "'Label'/'stack', Lawley uses 'label'/'stackref'. Remap the "
            "host label field above; each recipe card's EDIT panel remaps "
            "its own write-to and id fields."), r, 0, 1, 4)
        g.setColumnStretch(1, 2)
        g.setColumnStretch(3, 1)
        lay.addWidget(box)

    _POLY_CAPS = {"pon_no": "PON", "zone_no": "Zone", "zone": "Zone {zone}",
                  "ag": "AG"}
    _POLY_HINTS = {"pon_no": ("pon",), "zone_no": ("zone",),
                   "zone": ("zone", "pon"), "ag": ("ag", "aggregation")}

    def _add_poly_row(self, ref):
        """One polygon-ref picker row (layer + value field) in ADVANCED."""
        if ref in self.poly_rows:
            return
        row = self._poly_grid.rowCount()
        cap = _muted(self._POLY_CAPS.get(ref, ref))
        self._poly_grid.addWidget(cap, row, 0)
        lyr_cb = _layer_combo("polygon", allow_empty=True)
        self._poly_grid.addWidget(lyr_cb, row, 1)
        fcap = _muted("value field")
        self._poly_grid.addWidget(fcap, row, 2)
        fld_cb = QtWidgets.QComboBox()
        self._poly_grid.addWidget(fld_cb, row, 3)
        self._poly_grid.setColumnStretch(1, 2)
        self._poly_grid.setColumnStretch(3, 1)
        self.poly_rows[ref] = (lyr_cb, fld_cb, (cap, lyr_cb, fcap, fld_cb))
        _on_layer_signal(lyr_cb, lambda *_a, ref=ref:
                         self._refresh_poly_fields(ref))
        fld_cb.currentTextChanged.connect(lambda *_: self._mark_stale())

    def _sync_poly_rows(self):
        """A picker row (with a guessed layer) for every polygon ref the
        CURRENT recipes use — pon_no/zone_no always, plus each recipe's
        poly_refs names (e.g. HeroTel/Vuma 'zone', Vuma 'ag').  Rows for
        refs no preset uses any more are hidden, not destroyed."""
        refs = {"pon_no", "zone_no"}
        for card in self._cards:
            try:
                refs |= set(card.recipe().poly_refs or ())
            except Exception:
                pass
        layers = _project_layers()
        for ref in sorted(refs):
            if ref not in self.poly_rows:
                self._add_poly_row(ref)
                try:
                    if _current_layer(self.poly_rows[ref][0]) is None:
                        hint = self._POLY_HINTS.get(
                            ref, (ref.replace("_no", ""),))
                        lyr = _guess_named_layer(layers, "polygon", *hint)
                        if lyr is not None:
                            _set_combo_layer(self.poly_rows[ref][0], lyr)
                except Exception:
                    pass
                self._refresh_poly_fields(ref)
        self._active_poly_refs = refs
        for ref, rowdef in self.poly_rows.items():
            vis = ref in refs
            for w in rowdef[2]:
                try:
                    w.setVisible(vis)
                except Exception:
                    pass

    def _guess_hosts_and_polygons(self, layers):
        try:
            poles = _guess_named_layer(layers, "point", "poles", "pole")
            man = _guess_named_layer(layers, "point", "manhole")
            for row, lyr in ((self.host_rows[0], poles),
                             (self.host_rows[1], man)):
                if lyr is not None:
                    _set_combo_layer(row[0], lyr)
                self._refresh_host_fields(row)
            pon = _guess_named_layer(layers, "polygon", "pon")
            zone = _guess_named_layer(layers, "polygon", "zone")
            for ref, lyr in (("pon_no", pon), ("zone_no", zone)):
                if lyr is not None:
                    _set_combo_layer(self.poly_rows[ref][0], lyr)
                self._refresh_poly_fields(ref)
        except Exception:
            pass

    def _refresh_host_fields(self, row):
        lyr_cb, fld_cb = row
        lyr = _current_layer(lyr_cb)
        names = _field_names(lyr) if lyr is not None else []
        prev = fld_cb.currentText()
        fld_cb.blockSignals(True)
        try:
            fld_cb.clear()
            fld_cb.addItems(names)
            pick = prev if prev in names else (
                _guess_field(names, "label", "label_1", "name",
                             contains="label") or "")
            idx = fld_cb.findText(pick)
            fld_cb.setCurrentIndex(idx if idx >= 0 else (0 if names else -1))
        finally:
            fld_cb.blockSignals(False)
        self._mark_stale()

    def _refresh_poly_fields(self, ref):
        lyr_cb, fld_cb = self.poly_rows[ref][0], self.poly_rows[ref][1]
        lyr = _current_layer(lyr_cb)
        names = _field_names(lyr) if lyr is not None else []
        prev = fld_cb.currentText()
        fld_cb.blockSignals(True)
        try:
            fld_cb.clear()
            fld_cb.addItems(names)
            hint = ("pon" if "pon" in ref
                    else ("zone" if "zone" in ref else ref[:4].lower()))
            pick = prev if prev in names else (
                _guess_field(names, ref, "name", contains=hint) or "")
            idx = fld_cb.findText(pick)
            fld_cb.setCurrentIndex(idx if idx >= 0 else (0 if names else -1))
        finally:
            fld_cb.blockSignals(False)
        self._mark_stale()

    # -- config fingerprint / staleness -------------------------------------------------

    def _active_cards(self):
        return [c for c in self._cards if c.layer() is not None]

    def _host_layers(self):
        out = []
        for lyr_cb, fld_cb in self.host_rows:
            lyr = _current_layer(lyr_cb)
            fld = fld_cb.currentText().strip()
            if lyr is not None and fld:
                out.append((lyr, fld))
        return out

    def _polygon_cfg(self):
        out = {}
        for ref, rowdef in self.poly_rows.items():
            if ref not in self._active_poly_refs:
                continue                  # hidden row — preset doesn't use it
            lyr = _current_layer(rowdef[0])
            fld = rowdef[1].currentText().strip()
            if lyr is not None and fld:
                out[ref] = (lyr, fld)
        return out

    def _config_token(self):
        rows = []
        for card in self._active_cards():
            lyr = card.layer()
            try:
                lid = lyr.id()
            except Exception:
                lid = repr(lyr)
            try:
                rec = card.recipe().to_dict()
            except Exception:
                rec = repr(card.recipe())
            rows.append((card.role, lid, card.id_field(), rec))
        hosts = []
        for lyr, fld in self._host_layers():
            try:
                hosts.append((lyr.id(), fld))
            except Exception:
                hosts.append((repr(lyr), fld))
        polys = []
        for ref, (lyr, fld) in sorted(self._polygon_cfg().items()):
            try:
                polys.append((ref, lyr.id(), fld))
            except Exception:
                polys.append((ref, repr(lyr), fld))
        return repr((rows, hosts, polys,
                     sorted(self._constants().items())))

    def _mark_stale(self, *_):
        if self._loading:
            return
        if self._dry is not None and \
                self._dry_token != self._config_token():
            self.stale_lbl.setText("settings changed — press PREVIEW again")
            self.apply_btn.setEnabled(False)
        else:
            self.stale_lbl.setText("")
            if self._dry is not None:
                self._sync_apply()

    # -- preview -------------------------------------------------------------------------

    def start_preview(self):
        """Layer reads on the MAIN thread under a wait cursor, then the pure
        compose loop off the UI thread (sip.isdeleted-guarded callbacks)."""
        if self._running:
            return
        self.banner.clear()
        bad = [c for c in self._cards if c.error()]
        if bad:
            self.banner.show_msg(
                "warn", "Fix the template on: %s"
                % ", ".join(_role_meta(c.role)[1] for c in bad))
            return
        cards = self._active_cards()
        if not cards:
            self.banner.show_msg(
                "warn", "No layers matched — open a card's EDIT panel and "
                "pick the layer for each recipe.")
            return
        eng = _engine()
        host_toks = {"host", "host_full", "start", "end", "start_full",
                     "end_full", "polenum"}
        needs_host = False
        for card in cards:
            rec = card.recipe()
            toks = list(eng.template_tokens(rec.template))
            for v in rec.also_fill.values():
                toks += eng.template_tokens(v)
            if host_toks & set(toks):
                needs_host = True         # numbered cables (HeroTel/Vuma)
                # don't require a pole layer — only pole-referenced ones do
        hosts = self._host_layers()
        if needs_host and not hosts:
            self.banner.show_msg(
                "warn", "Pick your pole layer (and its label field) under "
                "ADVANCED — cables and gear name themselves after the "
                "nearest pole.")
            return
        constants = self._constants()
        token = self._config_token()

        # ---- MAIN-thread extraction (QGIS layer reads are not thread-safe)
        try:
            QtWidgets.QApplication.setOverrideCursor(
                QtGui.QCursor(Qt.CursorShape.WaitCursor))
            try:
                host_index = eng.build_host_index(hosts)
                polygons = eng.build_polygons(self._polygon_cfg())
                # Walk-order numbering: build the physical-path index once from
                # ALL tiers (POP outward). Empty if the walk engine is absent or
                # the project has no POP/network — then it silently no-ops.
                walk_idx = {}
                wa = _walk_adapter() if getattr(self, "_walk_order", False) else None
                if wa is not None:
                    try:
                        _segs, _pts, _roots = wa.extract()
                        walk_idx = wa.walk_order_index(
                            _segs, _pts, _roots, wa.fibertime_hierarchy())
                    except Exception:
                        walk_idx = {}
                extracted = {}
                for card in cards:
                    rec = card.recipe()
                    lyr = card.layer()
                    wtier = (wa.FIBERTIME_LAYER_TIERS.get(lyr.name(), (None, None))[0]
                             if (wa is not None and walk_idx) else None)
                    id_field = card.id_field()
                    names = _field_names(lyr)
                    fmap = dict(getattr(rec, "field_map", {}) or {})
                    toks = list(eng.template_tokens(rec.template))
                    for v in rec.also_fill.values():
                        toks += eng.template_tokens(v)
                    seq = getattr(rec, "sequence", None)
                    if getattr(rec, "auto_number", False) and seq is not None:
                        toks.append(seq.token)        # existing numbers
                        toks += list(seq.scope or ())
                        ob = str(seq.order_by or "")
                        if ob.startswith("field:"):
                            toks.append(ob[6:])       # order-by field
                    if {"card", "port"} & set(toks):
                        toks.append("pon_no")         # card/port fallback
                    needed = set()
                    for t in toks:
                        fld = fmap.get(t, t)          # editable headings
                        if fld in names:
                            needed.add(fld)
                    lf = rec.label_field
                    has_label = lf in names
                    targets = [lf] + [k for k in rec.also_fill if k != lf]
                    create_fields = [n for n in targets
                                     if n and n not in names]
                    rows = []
                    skips = {}
                    for f in lyr.getFeatures():
                        fid = _fid_of(f, id_field)
                        g = f.geometry()
                        if not g or g.isEmpty():
                            skips[fid] = "no geometry"
                            continue
                        if rec.kind == "cable":
                            co = _line_coords(g)
                            if co is None:
                                skips[fid] = "bad geometry"
                                continue
                            geom_part = {"coords": co, "xy": None}
                        else:
                            xy = _point_xy(g)
                            if xy is None:
                                skips[fid] = "bad geometry"
                                continue
                            geom_part = {"coords": None, "xy": xy}
                        rows.append({
                            "fid": fid,
                            "qfid": f.id(),
                            "coords": geom_part["coords"],
                            "xy": geom_part["xy"],
                            "attrs": {n: _pyval(f[n]) for n in needed},
                            "old": _pyval(f[lf]) if has_label else None,
                            "walk_order": (walk_idx.get("%s:%s" % (wtier, f.id()))
                                           if wtier else None),
                        })
                    extracted[rec.layer_role] = {
                        "recipe": rec, "rows": rows,
                        "create_fields": create_fields,
                        "skips": skips, "skipped": len(skips)}
            finally:
                QtWidgets.QApplication.restoreOverrideCursor()
        except Exception as exc:
            self.banner.show_msg("error", "Could not read the layers: %s: %s"
                                 % (type(exc).__name__, exc))
            return

        if needs_host and not getattr(host_index, "hosts", None):
            self.banner.show_msg(
                "warn", "Your pole layer has no labels in the chosen field "
                "— label the poles first (they are the reference points).")
            return

        self._running = True
        self.preview_btn.setEnabled(False)
        self.apply_btn.setEnabled(False)
        self.progress.show()
        self.stale_lbl.setText("")

        def work():                    # WORKER thread — pure python only
            return _compose_dry(extracted, host_index, polygons, constants,
                                walk=bool(walk_idx))

        def on_done(result):           # MAIN thread
            if _is_deleted(self):
                return
            self._running = False
            self.preview_btn.setEnabled(True)
            self.progress.hide()
            self._dry = result
            self._dry_token = token
            self._undo = None          # a new preview invalidates the undo
            self._render_preview()
            self._sync_apply()

        def on_error(exc):             # MAIN thread
            if _is_deleted(self):
                return
            self._running = False
            self.preview_btn.setEnabled(True)
            self.progress.hide()
            self.banner.show_msg("error", "Preview failed: %s: %s"
                                 % (type(exc).__name__, exc))

        _run_async(work, on_done, on_error, "Label My Network - dry run")

    def _render_preview(self):
        dry = self._dry
        if not dry:
            return
        totals = dry.get("_totals", {})
        ready = int(totals.get("ready", 0))
        flagged = int(totals.get("flagged", 0))
        self.gauge.set_values(ready, flagged)
        self.kpi_ready.setText("{:,}".format(ready))
        self.kpi_flagged.setText("{:,}".format(flagged))

        role_names = {}
        all_changes = []
        for card in self._cards:
            res = dry.get(card.role)
            if res is None:
                card.set_status(None, None)
                continue
            card.set_status(res.get("ready", 0), res.get("flagged", 0))
            lyr = card.layer()
            try:
                lname = lyr.name() if lyr is not None else card.role
            except Exception:
                lname = card.role
            role_names[card.role] = lname
            for ch in res.get("changes", ()):
                all_changes.append((lname, ch))
            for _fid, (label, _fills) in res.get("labels", {}).items():
                if label is not None:
                    card.set_real_example(label)
                    break

        shown = all_changes[:_PREVIEW_ROW_LIMIT]
        self.changes_caption.setText(
            "CHANGES — SHOWING %d OF %d" % (len(shown), len(all_changes)))
        self.changes_table.setRowCount(len(shown))
        mono = _mono_font()
        for r, (lname, ch) in enumerate(shown):
            old = ch.get("old")
            cells = (lname, "" if old in (None, "") else str(old),
                     str(ch.get("new", "")))
            for col, text in enumerate(cells):
                it = QtWidgets.QTableWidgetItem(text)
                it.setFont(mono)
                if col == 2:
                    it.setForeground(QtGui.QColor(_GREEN))
                self.changes_table.setItem(r, col, it)
        self.changes_table.setVisible(bool(shown))
        self.changes_caption.setVisible(True)

        grouped = {}
        for card in self._cards:
            res = dry.get(card.role)
            if not res:
                continue
            lname = role_names.get(card.role, card.role)
            for fl in res.get("flags", ()):
                grouped.setdefault(str(fl.get("code", "flag")),
                                   []).append((lname, fl))
        self.flags_tree.clear()
        code_phrase = {"no_host": "no pole/manhole nearby",
                       "no_pon": "no numeric PON number found",
                       "no_sequence": "number field is empty "
                                      "(turn Auto-number on to generate)",
                       "no_chainage": "chainage needs a line geometry"}
        for code in sorted(grouped):
            items = grouped[code]
            top = QtWidgets.QTreeWidgetItem(
                ["%s — %d" % (code_phrase.get(code, code), len(items)),
                 "left blank for you to check"])
            top.setForeground(0, QtGui.QColor(_AMBER))
            self.flags_tree.addTopLevelItem(top)
            for lname, fl in items[:_FLAG_DETAIL_LIMIT]:
                child = QtWidgets.QTreeWidgetItem(
                    ["%s · %s" % (lname, fl.get("fid")),
                     str(fl.get("detail", ""))])
                child.setFont(0, _mono_font())
                top.addChild(child)
            if len(items) > _FLAG_DETAIL_LIMIT:
                top.addChild(QtWidgets.QTreeWidgetItem(
                    ["… %d more" % (len(items) - _FLAG_DETAIL_LIMIT), ""]))
            top.setExpanded(False)
        n_flags = sum(len(v) for v in grouped.values())
        self.flags_caption.setText(
            "FLAGGED — LEFT BLANK FOR YOU TO CHECK (%d)" % n_flags
            if n_flags else "")
        self.flags_caption.setVisible(bool(n_flags))
        self.flags_tree.setVisible(bool(n_flags))

    def _writable_count(self):
        if not self._dry:
            return 0
        n = 0
        for card in self._active_cards():
            res = self._dry.get(card.role)
            if res:
                n += len(res.get("changes", ()))
        return n

    def _sync_apply(self):
        dry = self._dry
        if dry is None:
            self.apply_summary.setText("Run a preview first.")
            self.apply_btn.setEnabled(False)
            return
        stale = (self._dry_token != self._config_token())
        n = self._writable_count()
        flagged = int(dry.get("_totals", {}).get("flagged", 0))
        if stale:
            self.apply_summary.setText(
                "Settings changed since the preview — press PREVIEW again.")
            self.apply_btn.setEnabled(False)
            return
        if n == 0:
            self.apply_summary.setText(
                "Everything already matches — nothing to write."
                + ("  %d flagged." % flagged if flagged else ""))
            self.apply_btn.setEnabled(False)
            return
        adds = []
        for card in self._active_cards():
            res = dry.get(card.role)
            fields = list((res or {}).get("create_fields") or ())
            if fields:
                lyr = card.layer()
                try:
                    lname = lyr.name() if lyr is not None else card.role
                except Exception:
                    lname = card.role
                adds.append("%s (%s)" % (", ".join(fields), lname))
        note = ("\nWill add columns: %s" % " · ".join(adds)) if adds else ""
        self.apply_summary.setText(
            "%s will change · %s flagged (left blank)%s"
            % ("{:,}".format(n), "{:,}".format(flagged), note))
        self.apply_btn.setEnabled(not self._running)

    # -- apply ---------------------------------------------------------------------------

    def _apply(self):
        """Backup-first (default ON) -> label_recipe.apply() with the exact
        previewed dry-run -> green toast with one-click UNDO -> re-preview."""
        self.result.clear()
        dry = self._dry
        if dry is None or self._dry_token != self._config_token():
            self.result.show_msg("warn", "Preview is stale — press PREVIEW "
                                         "again first.")
            self._sync_apply()
            return
        self.apply_btn.setEnabled(False)
        try:
            if self.backup_chk.isChecked():
                QtWidgets.QApplication.setOverrideCursor(
                    QtGui.QCursor(Qt.CursorShape.WaitCursor))
                try:
                    ok, detail = _run_backup()
                finally:
                    QtWidgets.QApplication.restoreOverrideCursor()
                if not ok:
                    self.result.show_msg(
                        "error", "Backup failed — NOTHING was written. %s"
                        % detail)
                    return
            eng = _engine()
            lrcs = []
            try:
                for card in self._active_cards():
                    lrcs.append(eng.LayerRecipe(card.layer(), card.recipe(),
                                                id_field=card.id_field()))
                undo = eng.apply(lrcs, dry)
            except Exception as exc:
                self.result.show_msg("error", "Writing labels failed: %s: %s"
                                     % (type(exc).__name__, exc))
                return
            if undo:                   # a no-op apply must not clobber the
                self._undo = undo      # previous (real) undo map
                self._undo_lrcs = lrcs
            msg = ("Labelled — %s feature(s) updated."
                   % "{:,}".format(len(undo)) if undo
                   else "Nothing needed writing — labels already match.")
            self.result.show_msg(
                "ok", msg + "  Re-running the preview to confirm…",
                action_text="UNDO" if undo else None,
                action=self._do_undo if undo else None)
            try:
                if self.iface is not None:
                    self.iface.messageBar().pushSuccess("Label My Network",
                                                        msg)
            except Exception:
                pass
            self.start_preview()
        finally:
            self._sync_apply()

    # -- undo ----------------------------------------------------------------------------

    def _do_undo(self):
        """Bulk-restore old values from the in-memory undo map — one provider
        write per layer, matched by (role, fid) exactly as apply() keyed it."""
        undo = self._undo
        if not undo:
            return
        restored = 0
        try:
            for lrc in self._undo_lrcs or ():
                lyr = lrc.layer
                if lyr is None or _is_deleted(lyr):
                    continue
                role = lrc.recipe.layer_role
                idx = {n: lyr.fields().indexOf(n)
                       for n in lyr.fields().names()}
                changes = {}
                for f in lyr.getFeatures():
                    old = undo.get((role, _fid_of(f, lrc.id_field)))
                    if old is None:
                        continue
                    row = {idx[fld]: val for fld, val in old.items()
                           if fld in idx}
                    if row:
                        changes[f.id()] = row
                if changes:
                    lyr.dataProvider().changeAttributeValues(changes)
                    lyr.triggerRepaint()
                    restored += len(changes)
        except Exception as exc:
            self.result.show_msg("error", "Undo failed after %d restores: "
                                 "%s: %s" % (restored, type(exc).__name__,
                                             exc))
            return
        self._undo = None
        self._undo_lrcs = None
        self.result.show_msg("ok", "Undone — %s feature(s) restored."
                             % "{:,}".format(restored))
        self.start_preview()

    # -- session persistence ----------------------------------------------------------------

    def _restore_session(self):
        try:
            for key, ed in self.const_edits.items():
                if key == "stack":
                    continue              # stack prefers live detection
                v = str(_setting(key, ""))
                if v:
                    ed.setText(v)
            self.ht_chk.setChecked(
                str(_setting("ht_prefix", "true")).lower() != "false")
            self.backup_chk.setChecked(
                str(_setting("backup_first", "true")).lower() != "false")
        except Exception:
            pass

    def save_session(self):
        try:
            for key, ed in self.const_edits.items():
                _set_setting(key, ed.text().strip())
            for name, btn in self.preset_btns.items():
                if btn.isChecked():
                    _set_setting("client", name)
                    _set_setting(self._client_key(), name)
                    break
            _set_setting("ht_prefix",
                         "true" if self.ht_chk.isChecked() else "false")
            _set_setting("backup_first",
                         "true" if self.backup_chk.isChecked() else "false")
        except Exception:
            pass


# ---------------------------------------------------------------------------
# dock + singleton entry point (public name unchanged: open_labeling_wizard)
# ---------------------------------------------------------------------------

def _dock_base():
    try:
        from qgis.gui import QgsDockWidget
        return QgsDockWidget
    except Exception:
        return QtWidgets.QDockWidget


class LabelMyNetworkDock(_dock_base()):
    """Singleton dock hosting Label My Network.  WA_DeleteOnClose — session
    state (constants/preset/backup choice) is captured in closeEvent BEFORE
    the widget dies; the undo map intentionally lives only while open."""

    def __init__(self, iface, parent=None):
        super().__init__("Velocity Nexus — Label My Network",
                         parent or iface.mainWindow())
        self.setObjectName("VFLabelMyNetworkDock")
        self.setAllowedAreas(Qt.DockWidgetArea.RightDockWidgetArea
                             | Qt.DockWidgetArea.LeftDockWidgetArea)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self._panel = LabelMyNetworkWidget(iface, self)
        self.setWidget(self._panel)
        self.resize(560, 860)

    def closeEvent(self, event):
        try:                          # capture BEFORE WA_DeleteOnClose kills us
            if self._panel is not None and not _is_deleted(self._panel):
                self._panel.save_session()
        except Exception:
            pass
        try:
            super().closeEvent(event)
        except Exception:
            event.accept()


# back-compat aliases (old public names) — same dock, new UI
LabelingWizardDock = LabelMyNetworkDock
LabelingWizardWidget = LabelMyNetworkWidget

_DOCK = None


def _forget_dock(*_):
    global _DOCK
    _DOCK = None


def open_labeling_wizard(iface):
    """Create (or raise+focus) the singleton Label My Network dock."""
    global _DOCK
    if _DOCK is not None and not _is_deleted(_DOCK):
        _DOCK.show()
        _DOCK.raise_()
        try:
            _DOCK.activateWindow()
        except Exception:
            pass
        return _DOCK
    dock = LabelMyNetworkDock(iface)
    try:
        from ..fibre_automation import dock_util as _du
    except Exception:
        try:
            from . import dock_util as _du
        except Exception:
            try:
                from fibre_automation import dock_util as _du
            except Exception:
                _du = None
    try:
        if _du is not None:
            _du.dock_fully(iface, dock, width=560)   # FULLY docked, not half-float
        else:
            iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dock)
    except Exception:
        pass
    dock.show()
    try:
        dock.destroyed.connect(_forget_dock)
    except Exception:
        pass
    _DOCK = dock
    return dock
