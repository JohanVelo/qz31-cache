"""herotel_boq — the HeroTel Bill of Quantities builder (bundled, read-only).

Reads the live HeroTel layers and writes the HeroTel-approved workbook shape:
a main summary (item · uom · quantity · Comment) + a BOQ Check List, then one
full attribute-table tab per component. Returns the router's uniform dict so the
Cost/BOQ button is client-agnostic.

Design rules (match the rest of boq/):
  * READ-ONLY — never edits a layer or its geometry.
  * TRUE METRES — cable/geometry lengths use shared.crs_utils.metre_measurer, so a
    project left on ellipsoid 'NONE' can never measure in degrees.
  * HONEST BLANK — cable buy metres = Tlenght (true routed) + Slenght (the HeroTel
    slack, already written per JJ's confirmed rule). Ratio-rule items
    (straps/buckles/screws/cement) and a few backhaul SKUs are left blank and
    flagged, NEVER a guessed number, until JJ confirms the rules.

The workbook shape is a bundled port of research/herotel_boq/build_malmesbury_baseline.py
(JJ's validated baseline), driven from live layers instead of C:/Temp JSON dumps.
"""
import os
import tempfile
import zipfile
from collections import Counter, defaultdict

_HOOK_WAYS = ("1 Way", "2 Way", "3 Way")
_POLE_BANDS = ("5m (100-120)", "5m (120-140)", "7m (100-120)", "7m (120-140)")
# planning-boundary layers that must NOT get a BoQ full-table tab
_SKIP_TABLES = {"aoi", "exclude"}

# ── Mahikeng HeroTel line-item skeleton (JJ: replicate exactly) ───────────────
# Cable is billed BY FIBRE SIZE with the SSA-75m HEROTEL SKU names (feeder +
# distribution summed per size); sizes we don't carry stay blank. (size, SKU text)
_CABLE_SKU = [
    ("12F", "CABLE SM SSA 75m 12F-OD 9.2mm HEROTEL (2000 & 4000M lengths)"),
    ("18F", "CABLE SM SSA 75m 18F-OD 9.2mm HEROTEL (2000 & 4000M lengths)"),
    ("24F", "CABLE SM SSA 75m 24F-OD 9.2mm HEROTEL (2000 & 4000M lengths)"),
    ("36F", "CABLE SM SSA 75m 36F-OD 9.2mm HEROTEL (2000 & 4000M lengths)"),
    ("48F", "MEGAnet Cs CABLE SM SSA 75m 48F-OD 10.4mm(2000m&4000M)"),
    ("72F", "CABLE SM SSA 75m 72F-OD 11.2mm HEROTEL (2000 & 4000M lengths)"),
    ("96F", "CABLE SM SSA 75m 96F-OD 12.8mm HEROTEL(2000 & 4000M lengths)"),
    ("144F", "CABLE SM SSA 75m 144F-OD 15.8mm HEROTEL (2000 & 4000M lengths)"),
]
# Dead-End SKU rows (Mahikeng order; two 48F variants). dend_key = the D/END bin
# way_counter.by_size_to_sku produces; None = a variant we can't split (stays blank).
_DEND_ROWS = [
    ("18/24/36F", "MEGAnet Cs D/END FDE 9.20-9.50mm - 18/24/36F"),
    ("48F", "MEGAnet Cs D/END FDE 9.40-10.50mm - 48F"),
    ("72F", "MEGAnet Cs D/END FDE 10.54-11.65mm - 72F"),
    (None, "MEGAnet Cs D/END FDE 10.4-10.8mm - 48F"),
    ("96F", "MEGAnet Cs D/END FDE 11.70-12.90mm - 96F"),
    ("144F", "MEGAnet Cs D/END FDES 15.60-17.27mm - 144F"),
]
# Tangent SKU rows — present but blank (N/A for HeroTel), Mahikeng skeleton.
_TANGENT_ROWS = [
    "MEGAnet Cs TANGENT 9.20-9.50mm - 18/24/36F",
    "MEGAnet Cs TANGENT 10.10-10.80mm - 48F",
    "MEGAnet Cs TANGENT 10.80-11.55mm - 72F",
    "MEGAnet Cs TANGENT 12.50-13.30mm - 96F",
    "MEGAnet Cs TANGENT 15.11-16.00mm - 144F",
]


# ── layer / value helpers ─────────────────────────────────────────────────────
def _layer(project, name, aliases=(), want_geom=None):
    """Robust layer lookup via boq.layers.find_layer: exact -> alias -> substring ->
    fuzzy (case/space/punctuation-insensitive), so a differently-spelled layer on
    another machine still resolves. Exact/substring win first, so on a standard
    project the result is identical to the old inline exact+substring lookup."""
    try:
        from .layers import find_layer
    except ImportError:
        from fibre_automation.boq.layers import find_layer
    lyr, _matched, _method, _score = find_layer(
        project, name, aliases=aliases, want_geom=want_geom)
    return lyr


def _has(layer, field):
    return layer is not None and field in [f.name() for f in layer.fields()]


def _is_null(v):
    """True for a QGIS NULL / None / empty-string attribute value."""
    try:
        from qgis.core import NULL
        if v is NULL or v == NULL:
            return True
    except Exception:
        pass
    return v is None or (isinstance(v, str) and v.strip() == "")


def _fnum(v):
    """Best-effort float; tolerates '1,5' and blanks. None on failure."""
    if _is_null(v):
        return None
    try:
        return float(str(v).replace(",", "."))
    except (TypeError, ValueError):
        return None


def _measurer(project, layer):
    """A QgsDistanceArea that returns METRES for `layer` (never degrees)."""
    try:
        from ..shared.crs_utils import metre_measurer
    except ImportError:
        from fibre_automation.shared.crs_utils import metre_measurer
    crs = layer.crs() if layer is not None else None
    return metre_measurer(crs=crs, project=project)


def _geom_length_m(project, layer):
    """Sum ellipsoidal metres over a line layer's geometries (skips null geoms)."""
    if layer is None:
        return None
    da = _measurer(project, layer)
    total = 0.0
    for feat in layer.getFeatures():
        g = feat.geometry()
        if not g or g.isEmpty():
            continue
        try:
            total += da.measureLength(g)
        except Exception:
            pass
    return round(total, 1)


def _phase_split():
    """Lazy import of the sibling phase_split module (bundled + dev paths)."""
    try:
        from . import phase_split
    except ImportError:
        from fibre_automation.boq import phase_split
    return phase_split


def _feature_phase(geom, is_line, is_polygon, polys, index, da):
    """Best-effort phase name for one feature, for the detail-tab Phase column.

    Points → the containing phase; polygons → the phase of their surface point;
    lines → the phase holding the MOST of their length (dominant). Display-only —
    the billed per-phase quantities split lines by length, this column just labels
    each row with one phase for filtering."""
    ps = _phase_split()
    if not geom or geom.isEmpty():
        return ""
    # backhaul outside the AOI labels as Phase 1 (matches the billed fold)
    first = polys[0]["name"] if polys else ps.OUTSIDE

    def fold(n):
        return first if n == ps.OUTSIDE else n
    if is_line and da is not None:
        lens = ps.line_phase_lengths(geom, polys, da)
        return fold(max(lens, key=lens.get)) if lens else first
    pgeom = geom.pointOnSurface() if is_polygon else geom
    return fold(ps.point_phase(pgeom, polys, index))


# ── quantity extraction (all read-only) ───────────────────────────────────────
def _extract(project, polys=None):
    """Return (Q, tables, order, findings): derived quantities, full tables, warnings.

    When ``polys`` (the phase polygons) is given, each full table also carries a
    ``phase`` list aligned to its rows so the detail tab can show a Phase column."""
    findings = []
    Q = {"project": project.baseName()}

    # poles -----------------------------------------------------------------
    poles = _layer(project, "poles", want_geom="Point")
    by_band = Counter()
    hook_ways = {w: 0 for w in _HOOK_WAYS}
    if poles is not None:
        pl_ok = _has(poles, "Pole Lengh") and _has(poles, "Pole Size")
        for feat in poles.getFeatures():
            if pl_ok:
                lengh = str(feat["Pole Lengh"]).strip()
                size = str(feat["Pole Size"]).strip()
                by_band[f"{lengh} ({size})"] += 1
            for w in _HOOK_WAYS:
                if _has(poles, w):
                    iv = _fnum(feat[w])
                    hook_ways[w] += int(iv) if iv is not None else 0
        stray = sum(v for k, v in by_band.items() if k not in _POLE_BANDS)
        if stray:
            findings.append(("WARN", f"{stray} pole(s) fall outside the 4 known "
                                     "length/size bands — check Pole Lengh / Pole Size."))
    Q["poles"] = {
        "total": poles.featureCount() if poles is not None else 0,
        "by_band": {b: by_band.get(b, 0) for b in _POLE_BANDS},
        "hook_ways": hook_ways,
        "hook_total": sum(hook_ways.values()),
    }

    # cables (buy = Tlenght + Slenght) --------------------------------------
    def _cable_buy_by_size(layer_name):
        lyr = _layer(project, layer_name)
        out = defaultdict(lambda: {"n": 0, "t": 0.0, "s": 0.0})
        blank_s = 0
        if lyr is not None and _has(lyr, "Cable Size"):
            for feat in lyr.getFeatures():
                size = str(feat["Cable Size"]).strip()
                t = _fnum(feat["Tlenght"]) if _has(lyr, "Tlenght") else None
                s = _fnum(feat["Slenght"]) if _has(lyr, "Slenght") else None
                if s is None:
                    blank_s += 1
                rec = out[size]
                rec["n"] += 1
                rec["t"] += t or 0.0
                rec["s"] += s or 0.0
        return {k: {"n": v["n"], "Tlenght_sum": round(v["t"], 1),
                    "Slenght_sum": round(v["s"], 1),
                    "buy_sum": round(v["t"] + v["s"], 1)}
                for k, v in out.items()}, blank_s

    dist_by_size, dist_blank = _cable_buy_by_size("Distribution Cable")
    feed_by_size, feed_blank = _cable_buy_by_size("feeder")
    if dist_blank or feed_blank:
        findings.append(("WARN", f"{dist_blank + feed_blank} cable(s) have a blank "
                                 "Slenght — slack not applied. Run the HeroTel slack "
                                 "engine (/herotel-slack) first."))
    Q["cables"] = {
        "distribution": {"by_size": dist_by_size},
        "feeder": {"by_size": feed_by_size},
        "drops": {"count": (_layer(project, "drops", want_geom="Line").featureCount()
                            if _layer(project, "drops", want_geom="Line") is not None else 0),
                  "geom_m_total": _geom_length_m(project, _layer(project, "drops", want_geom="Line"))},
        "core": {"geom_m_total": _geom_length_m(project, _layer(project, "core", want_geom="Line"))},
    }

    # trenching by type / duct ---------------------------------------------
    tr = _layer(project, "Trenching", want_geom="Line")
    tr_by_type = Counter()
    tr_by_duct = Counter()
    tr_by_duct_m = Counter()
    if tr is not None:
        for feat in tr.getFeatures():
            if _has(tr, "Type") and _has(tr, "Lenght"):
                tr_by_type[str(feat["Type"]).strip()] += _fnum(feat["Lenght"]) or 0.0
            if _has(tr, "Ducts"):
                du = str(feat["Ducts"]).strip()
                tr_by_duct[du] += 1
                if _has(tr, "Lenght"):
                    tr_by_duct_m[du] += _fnum(feat["Lenght"]) or 0.0
    # manholes by size ------------------------------------------------------
    mh = _layer(project, "Manholes", want_geom="Point")
    mh_by_size = Counter()
    if mh is not None and _has(mh, "Manhole Si"):
        for feat in mh.getFeatures():
            mh_by_size[str(feat["Manhole Si"]).strip()] += 1
    # feeder joints by splitter ratio --------------------------------------
    fj = _layer(project, "Feeder Joints", want_geom="Point")
    fj_by_split = Counter()
    if fj is not None and _has(fj, "Splitters"):
        for feat in fj.getFeatures():
            fj_by_split[str(feat["Splitters"]).strip()] += 1

    Q["misc"] = {
        "trenching_by_type_m": {k: round(v, 1) for k, v in tr_by_type.items()},
        "trenching_by_duct": dict(tr_by_duct),
        "trenching_by_duct_m": {k: round(v, 1) for k, v in tr_by_duct_m.items()},
        "manholes_by_size": dict(mh_by_size),
        "feeder_joints_by_splitters": dict(fj_by_split),
    }
    _dp = _layer(project, "Demand points", aliases=("Demand Points", "Demand Point"), want_geom="Point")
    Q["counts"] = {
        "dome_joints": (_layer(project, "Dome Joints", want_geom="Point").featureCount()
                        if _layer(project, "Dome Joints", want_geom="Point") is not None else 0),
        "feeder_joints": fj.featureCount() if fj is not None else 0,
        "splitters_8way": (_layer(project, "8Way Splitters", want_geom="Point").featureCount()
                           if _layer(project, "8Way Splitters", want_geom="Point") is not None else 0),
        "manholes": mh.featureCount() if mh is not None else 0,
        "demand_points": _dp.featureCount() if _dp is not None else 0,
    }

    # full attribute tables — EVERY vector layer, all fields (JJ's request) --
    from qgis.core import QgsVectorLayer, QgsWkbTypes
    tables, order = {}, []
    p_index = _phase_split().spatial_index(polys) if polys else None
    phase_lyr_name = _phase_split().PHASE_LAYER.strip().lower()
    try:
        tree_layers = [n.layer() for n in project.layerTreeRoot().findLayers()]
    except Exception:
        tree_layers = list(project.mapLayers().values())
    seen = set()
    for lyr in tree_layers:
        if lyr is None or not isinstance(lyr, QgsVectorLayer) or lyr.id() in seen:
            continue
        seen.add(lyr.id())
        # AOI / Exclude are planning-boundary layers, not BoQ material — skip them.
        if lyr.name().strip().lower() in _SKIP_TABLES:
            continue
        if lyr.featureCount() <= 0:
            continue
        fnames = [f.name() for f in lyr.fields()]
        # tag each row with a phase (when we have phase polygons) — but not the
        # Phases layer itself, which defines the phases.
        want_phase = polys and lyr.name().strip().lower() != phase_lyr_name
        gtype = QgsWkbTypes.geometryType(lyr.wkbType()) if want_phase else None
        is_line = gtype == QgsWkbTypes.LineGeometry
        is_poly = gtype == QgsWkbTypes.PolygonGeometry
        da = _measurer(project, lyr) if (want_phase and is_line) else None
        rows, phases = [], []
        for feat in lyr.getFeatures():
            rows.append([(None if _is_null(feat[f]) else feat[f]) for f in fnames])
            if want_phase:
                phases.append(_feature_phase(feat.geometry(), is_line, is_poly,
                                             polys, p_index, da))
        tables[lyr.name()] = {"fields": fnames, "rows": rows}
        if phases:
            tables[lyr.name()]["phase"] = phases
        order.append(lyr.name())

    return Q, tables, order, findings


def _extract_phased(project, polys):
    """Per-phase billed quantities in ONE read-only pass, each feature bucketed by
    phase so the per-phase numbers sum back to the whole (reconciliation-is-law).

    Point features go to the phase polygon that contains them (nearest on a tie);
    line quantities (cable buy = Tlenght+Slenght, trench Lenght, drop/core metres)
    are split by the fraction of the line inside each phase, so Σ phases == whole
    feature exactly.

    Returns (buckets, order, findings) where
        buckets   = {phase_name: (Q, dend_by_sku)}  — Q in the _build_main shape,
        order     = phase names in display order, OUTSIDE appended if used.
    """
    ps = _phase_split()
    try:
        from . import way_counter
    except ImportError:
        from fibre_automation.boq import way_counter
    findings = []
    index = ps.spatial_index(polys)
    order = list(ps.phase_names(polys))
    # JJ 2026-07-21: the backhaul that runs OUTSIDE the AOI (in no phase polygon) is
    # billed under PHASE 1 — not a separate '(outside phases)' bucket. Fold OUTSIDE
    # into the first phase everywhere so Phase 1 absorbs it and P1+P2+P3 still == MAIN.
    first_phase = order[0] if order else ps.OUTSIDE

    def fold(name):
        return first_phase if name == ps.OUTSIDE else name

    def _new():
        return {
            "poles": {"by_band": {b: 0 for b in _POLE_BANDS},
                      "hook_ways": {w: 0 for w in _HOOK_WAYS}, "total": 0},
            "cables": {"distribution": {"by_size": {}},
                       "feeder": {"by_size": {}},
                       "drops": {"geom_m_total": 0.0, "count": 0},
                       "core": {"geom_m_total": 0.0}},
            "misc": {"trenching_by_type_m": {}, "trenching_by_duct_m": {},
                     "manholes_by_size": {}, "feeder_joints_by_splitters": {}},
            "counts": {"splitters_8way": 0, "feeder_joints": 0,
                       "dome_joints": 0, "manholes": 0, "demand_points": 0},
            "_dend_by_size": {},
        }

    buckets = {n: _new() for n in order}

    def B(name):
        if name not in buckets:
            buckets[name] = _new()
            order.append(name)
        return buckets[name]

    def pt_phase(geom):
        return B(fold(ps.point_phase(geom, polys, index)))

    def line_frac(geom, da):
        # a line partly/fully outside every phase polygon: its OUTSIDE share folds
        # into PHASE 1 (JJ's rule) so the whole line still reconciles to the total.
        fr = ps.line_phase_fractions(geom, polys, da)
        if not fr:
            return {first_phase: 1.0}
        if ps.OUTSIDE in fr:
            fr[first_phase] = fr.get(first_phase, 0.0) + fr.pop(ps.OUTSIDE)
        return fr

    # poles → bands + hooks, and remember each pole's phase for dead-end bucketing
    poles = _layer(project, "poles", want_geom="Point")
    pole_phase = {}
    if poles is not None:
        pl_ok = _has(poles, "Pole Lengh") and _has(poles, "Pole Size")
        ways_have = [w for w in _HOOK_WAYS if _has(poles, w)]
        for feat in poles.getFeatures():
            ph = fold(ps.point_phase(feat.geometry(), polys, index))
            pole_phase[feat.id()] = ph
            b = B(ph)
            b["poles"]["total"] += 1
            if pl_ok:
                band = (f'{str(feat["Pole Lengh"]).strip()} '
                        f'({str(feat["Pole Size"]).strip()})')
                b["poles"]["by_band"][band] = b["poles"]["by_band"].get(band, 0) + 1
            for w in ways_have:
                iv = _fnum(feat[w])
                b["poles"]["hook_ways"][w] += int(iv) if iv is not None else 0

    # dead-end arms per pole → bucket by that pole's phase (each pole one phase)
    for fid, sizes in way_counter.deadend_arms_per_pole(project).items():
        ph = pole_phase.get(fid)
        if ph is None:
            continue
        d = B(ph)["_dend_by_size"]
        for size, arms in sizes.items():
            d[size] = d.get(size, 0) + arms

    # cables (distribution + feeder): split buy = Tlenght+Slenght by length fraction
    for layer_name, kind in (("Distribution Cable", "distribution"),
                             ("feeder", "feeder")):
        lyr = _layer(project, layer_name)
        if lyr is None or not _has(lyr, "Cable Size"):
            continue
        da = _measurer(project, lyr)
        for feat in lyr.getFeatures():
            g = feat.geometry()
            if not g or g.isEmpty():
                continue
            size = str(feat["Cable Size"]).strip()
            t = (_fnum(feat["Tlenght"]) if _has(lyr, "Tlenght") else None) or 0.0
            s = (_fnum(feat["Slenght"]) if _has(lyr, "Slenght") else None) or 0.0
            for ph, f in line_frac(g, da).items():
                bs = B(ph)["cables"][kind]["by_size"].setdefault(
                    size, {"Tlenght_sum": 0.0, "Slenght_sum": 0.0, "n": 0})
                bs["Tlenght_sum"] += t * f
                bs["Slenght_sum"] += s * f

    # drop + core metres: split geometry length by fraction
    for layer_name, key in (("drops", "drops"), ("core", "core")):
        lyr = _layer(project, layer_name)
        if lyr is None:
            continue
        da = _measurer(project, lyr)
        for feat in lyr.getFeatures():
            g = feat.geometry()
            if not g or g.isEmpty():
                continue
            m = da.measureLength(g)
            for ph, f in line_frac(g, da).items():
                B(ph)["cables"][key]["geom_m_total"] += m * f

    # trenching by type: split the Lenght attribute by fraction
    tr = _layer(project, "Trenching", want_geom="Line")
    if tr is not None and _has(tr, "Type") and _has(tr, "Lenght"):
        da = _measurer(project, tr)
        has_duct = _has(tr, "Ducts")
        for feat in tr.getFeatures():
            g = feat.geometry()
            if not g or g.isEmpty():
                continue
            typ = str(feat["Type"]).strip()
            duct = str(feat["Ducts"]).strip() if has_duct else None
            L = _fnum(feat["Lenght"]) or 0.0
            for ph, f in line_frac(g, da).items():
                m = B(ph)["misc"]
                m["trenching_by_type_m"][typ] = \
                    m["trenching_by_type_m"].get(typ, 0.0) + L * f
                if duct is not None:
                    m["trenching_by_duct_m"][duct] = \
                        m["trenching_by_duct_m"].get(duct, 0.0) + L * f

    # point layers by containing phase
    mh = _layer(project, "Manholes", want_geom="Point")
    if mh is not None:
        has_sz = _has(mh, "Manhole Si")
        for feat in mh.getFeatures():
            b = pt_phase(feat.geometry())
            b["counts"]["manholes"] += 1
            if has_sz:
                sz = str(feat["Manhole Si"]).strip()
                b["misc"]["manholes_by_size"][sz] = \
                    b["misc"]["manholes_by_size"].get(sz, 0) + 1
    fj = _layer(project, "Feeder Joints", want_geom="Point")
    if fj is not None:
        has_sp = _has(fj, "Splitters")
        for feat in fj.getFeatures():
            b = pt_phase(feat.geometry())
            b["counts"]["feeder_joints"] += 1
            if has_sp:
                sp = str(feat["Splitters"]).strip()
                b["misc"]["feeder_joints_by_splitters"][sp] = \
                    b["misc"]["feeder_joints_by_splitters"].get(sp, 0) + 1
    dj = _layer(project, "Dome Joints", want_geom="Point")
    if dj is not None:
        for feat in dj.getFeatures():
            pt_phase(feat.geometry())["counts"]["dome_joints"] += 1
    sp8 = _layer(project, "8Way Splitters", want_geom="Point")
    if sp8 is not None:
        for feat in sp8.getFeatures():
            pt_phase(feat.geometry())["counts"]["splitters_8way"] += 1
    dp = _layer(project, "Demand points", aliases=("Demand Points", "Demand Point"), want_geom="Point")
    if dp is not None:
        for feat in dp.getFeatures():
            pt_phase(feat.geometry())["counts"]["demand_points"] += 1

    # finalise: round metres, fold dead-end sizes to SKU bins
    out = {}
    for name, b in buckets.items():
        for kind in ("distribution", "feeder"):
            for size, rec in b["cables"][kind]["by_size"].items():
                rec["Tlenght_sum"] = round(rec["Tlenght_sum"], 1)
                rec["Slenght_sum"] = round(rec["Slenght_sum"], 1)
                rec["buy_sum"] = round(rec["Tlenght_sum"] + rec["Slenght_sum"], 1)
        for key in ("drops", "core"):
            b["cables"][key]["geom_m_total"] = round(b["cables"][key]["geom_m_total"], 1)
        b["misc"]["trenching_by_type_m"] = {
            k: round(v, 1) for k, v in b["misc"]["trenching_by_type_m"].items()}
        b["misc"]["trenching_by_duct_m"] = {
            k: round(v, 1) for k, v in b["misc"]["trenching_by_duct_m"].items()}
        dend = way_counter.by_size_to_sku(b.pop("_dend_by_size"))
        out[name] = (b, dend)

    findings.append(("INFO", "Backhaul outside the AOI (no phase polygon) is included "
                             "in %s — no separate '(outside phases)' bucket "
                             "(JJ's rule 2026-07-21)." % first_phase))
    return out, order, findings


# billed line-items used for the phase Reconciliation tab (label, value, kind).
def _billed_lines(Q, de):
    """Flat [(label, value, kind)] of every reconcilable main-sheet quantity.

    kind is 'count' (integer, must tie exactly) or 'metres' (float, ties within
    rounding). Driven from the same Q/de a phase (or MAIN) sheet is built from, so
    the Reconciliation tab compares like with like."""
    hk = _q(Q, "poles", "hook_ways", default={})
    tr = _q(Q, "misc", "trenching_by_type_m", default={})
    duct_m = _q(Q, "misc", "trenching_by_duct_m", default={})
    mh = _q(Q, "misc", "manholes_by_size", default={})
    pb = _q(Q, "poles", "by_band", default={})
    fjs = _q(Q, "misc", "feeder_joints_by_splitters", default={})
    dend = (de or {}).get("by_dend_sku", {})
    cable = _cable_buy_by_fibre(Q)

    lines = []
    lines.append(("Demand Points", int(_q(Q, "counts", "demand_points", default=0) or 0),
                  "count"))
    for band in _POLE_BANDS:
        lines.append((f"Poles {band}", int(pb.get(band, 0)), "count"))
    lines.append(("Poles TOTAL", int(sum(pb.get(b, 0) for b in _POLE_BANDS)), "count"))
    lines.append(("Hook 1-Way", int(hk.get("1 Way", 0)), "count"))
    lines.append(("Hook 2-Way", int(hk.get("2 Way", 0)), "count"))
    lines.append(("Hook 3-Way", int(hk.get("3 Way", 0)), "count"))
    lines.append(("Enclosure/Splitter 1:8 (24F dome)",
                  int(_q(Q, "counts", "splitters_8way", default=0)), "count"))
    lines.append(("Enclosure/Splitter 1:16", int(fjs.get("1:16", 0)), "count"))
    lines.append(("Feeder dome (No Splitter)", int(fjs.get("No Splitter", 0)), "count"))
    lines.append(("Manhole 900mm", int(mh.get("900mm", 0)), "count"))
    lines.append(("Manhole 400mm", int(mh.get("400mm", 0)), "count"))
    lines.append(("Trench (m)", round(tr.get("Trench", 0.0) or 0.0, 1), "metres"))
    lines.append(("Drill (m)", round(tr.get("Drill", 0.0) or 0.0, 1), "metres"))
    lines.append(("50mm HDPE Water Pipe (m)",
                  round(duct_m.get("50mm HDPE", 0.0) or 0.0, 1), "metres"))
    for sku in ("18/24/36F", "48F", "72F", "96F", "144F"):
        lines.append((f"Dead-End {sku}", int(dend.get(sku, 0)), "count"))
    # Cable billed by fibre size (feeder + distribution combined)
    for sz in ("12F", "24F", "96F"):
        lines.append((f"Cable {sz} buy (m)", round(cable.get(sz, 0.0), 1), "metres"))
    return lines


# ── Excel writer (ported from the validated baseline shape) ────────────────────
def _styles():
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    return {
        "NAVY": PatternFill("solid", fgColor="1F3864"),
        "BLUE": PatternFill("solid", fgColor="2E5496"),
        "LGREY": PatternFill("solid", fgColor="D9E1F2"),
        "YELLOW": PatternFill("solid", fgColor="FFFF00"),   # still-unsure cell
        "GREEN": PatternFill("solid", fgColor="C6EFCE"),    # confirmed cell
        "WHITE_B": Font(bold=True, color="FFFFFF"),
        "BOLD": Font(bold=True),
        "MUT": Font(color="7F7F7F", italic=True, size=10),
        "CENTER": Alignment(horizontal="center", vertical="center"),
        "LEFT": Alignment(horizontal="left", vertical="center", wrap_text=True),
        "THIN": Border(*[Side(style="thin", color="BFBFBF")] * 4),
    }


def _q(d, *path, default=None):
    for k in path:
        if not isinstance(d, dict):
            return default
        d = d.get(k)
        if d is None:
            return default
    return d


def _cable_buy_by_fibre(Q):
    """Combined cable buy (Tlenght+Slenght) per FIBRE SIZE across distribution +
    feeder — the by-size total the Mahikeng Cable section bills. {size: metres}."""
    out = {}
    for kind in ("distribution", "feeder"):
        for size, rec in _q(Q, "cables", kind, "by_size", default={}).items():
            t = (rec or {}).get("Tlenght_sum") or 0
            s = (rec or {}).get("Slenght_sum") or 0
            out[size] = round(out.get(size, 0.0) + t + s, 1)
    return out


class _Sheet:
    """Row builder that tracks row numbers so Excel formulas can reference them.

    Ported from research/herotel_boq/build_herotel_boq_template.py so the bundled
    button emits the same formula-driven main sheet (cells recompute in Excel; the
    B/uom column carries the CEILING order-pack count for consumables).
    """
    def __init__(self, ws, S, title="Malmesbury Phase 1 BOQ"):
        self.ws, self.S, self.r, self.anchor, self.n_lines = ws, S, 1, {}, 0
        for c, t in ((1, title), (2, "uom"),
                     (3, "quantity"), (4, "Comment")):
            cell = ws.cell(1, c, t)
            cell.fill = S["NAVY"]
            cell.font = S["WHITE_B"]
            cell.alignment = S["CENTER"]
        self.r = 2

    def section(self, title):
        self.ws.cell(self.r, 1, title).font = self.S["WHITE_B"]
        for c in range(1, 5):
            self.ws.cell(self.r, c).fill = self.S["BLUE"]
        self.r += 1

    def line(self, item, uom, qty, comment="", color=None, anchor=None, fmt=None):
        ws, r, S = self.ws, self.r, self.S
        ws.cell(r, 1, item).alignment = S["LEFT"]
        ws.cell(r, 2, uom).alignment = S["CENTER"]
        qc = ws.cell(r, 3, qty)
        qc.alignment = S["CENTER"]
        if fmt:
            qc.number_format = fmt
        elif isinstance(qty, float):
            qc.number_format = "#,##0.0"
        elif isinstance(qty, int):
            qc.number_format = "#,##0"
        # a comment starting with '=' would be read as a FORMULA by Excel (#NAME?);
        # swap the leading '=' for 'Σ' so it stays literal text.
        cm = str(comment)
        if cm.startswith("="):
            cm = "Σ" + cm[1:]
        ws.cell(r, 4, cm).font = S["MUT"]
        for c in range(1, 5):
            ws.cell(r, c).border = S["THIN"]
        if color == "Y":
            for c in (2, 3):
                ws.cell(r, c).fill = S["YELLOW"]
        elif color == "G":
            ws.cell(r, 3).fill = S["GREEN"]
        if anchor:
            self.anchor[anchor] = r
        self.n_lines += 1
        self.r += 1
        return r

    def C(self, anchor):
        return f"C{self.anchor[anchor]}"


def _phase_suffix(names):
    """'phase 1,2 and 3' for the combined sheet, 'phase 1' for a single phase."""
    nums = []
    for n in names:
        d = "".join(c for c in str(n) if c.isdigit())
        nums.append(d if d else str(n))
    if not nums:
        return ""
    if len(nums) == 1:
        return "phase %s" % nums[0]
    return "phase %s and %s" % (",".join(nums[:-1]), nums[-1])


def _build_main(ws, Q, de, S, title="Malmesbury Phase 1 BOQ",
                civil_label="Backhaul Civil", material_label="Backhaul material"):
    """Main sheet — a faithful replica of the Mahikeng Phase 1 HeroTel BOQ skeleton
    (same sections, rows, SKU text and Excel formulas) driven by LIVE Malmesbury
    quantities (Q) + live dead-ends-by-size (de). The one deliberate deviation from
    Mahikeng is the Poles rows: JJ keeps Malmesbury's real 5m/7m bands (4 rows).

    The same builder renders the whole-project MAIN sheet and each per-phase sheet
    (different title + phase-restricted Q/de)."""
    s = _Sheet(ws, S, title=title)
    hk = _q(Q, "poles", "hook_ways", default={})
    tr = _q(Q, "misc", "trenching_by_type_m", default={})
    duct_m = _q(Q, "misc", "trenching_by_duct_m", default={})
    mh = _q(Q, "misc", "manholes_by_size", default={})
    pb = _q(Q, "poles", "by_band", default={})
    fjs = _q(Q, "misc", "feeder_joints_by_splitters", default={})
    dend = (de or {}).get("by_dend_sku", {})
    cable = _cable_buy_by_fibre(Q)

    dome18 = _q(Q, "counts", "splitters_8way")          # 1:8 splitter enclosures
    dome116 = fjs.get("1:16")                           # 1:16 splitter domes
    domefeed = fjs.get("No Splitter")                   # pure feeder-joint domes

    def packB(row, per):
        # B column = order-pack count. Mahikeng's B is CEILING(C, 1) where C already
        # holds the pack count; the one exception (enclosure buckles) leaves C as the
        # raw count and divides by 100 in B. per=1 → CEILING(C,1); per=100 → /100.
        div = "" if per == 1 else f"/{per}"
        ws.cell(row, 2).value = f"=CEILING(C{row}{div},1)"

    # ── Demand Points ──  (homes passed — total here; per-phase on each phase tab.
    # Universal: any HeroTel project with a Demand Points layer. The count on the
    # banner mirrors the Poles/Hooks header-total pattern.)
    dp_n = int(_q(Q, "counts", "demand_points", default=0) or 0)
    dhdr = s.r
    s.section("Demand Points")
    ws.cell(dhdr, 2).value = "no"
    ws.cell(dhdr, 2).font = S["WHITE_B"]
    ws.cell(dhdr, 3).value = dp_n or None
    ws.cell(dhdr, 3).font = S["WHITE_B"]
    ws.cell(dhdr, 3).number_format = "#,##0"

    # ── Civil ──  (Mahikeng: Trench 650mm + Drill only)
    s.section(civil_label)
    s.line("Trench 650mm", "m", tr.get("Trench"), "Trenching · Type=Trench")
    s.line("Drill", "m", tr.get("Drill"), "Trenching · Type=Drill")

    # ── Material ──  (SKUs owed — blank until JJ confirms, like Mahikeng)
    s.section(material_label)
    s.line("DUCT - MICRO 2 Way 14/10 2W 1000m HEROTEL - ORNGE", "m",
           duct_m.get("2Way 14/10"), "Trenching · Ducts=2Way 14/10")
    s.line("DUCT-MICRO 7 WAY 14/10 2W 1000m HEROTREL - ORANGE", "m", None,
           "backhaul duct — SKU/length pending")
    s.line("CABLE SM SSA 75m 12F-OD 9.2mm HEROTEL (2000 & 4000M lengths)", "m",
           tr.get("Backhaul"), "backhaul cable = Trenching · Type=Backhaul")
    s.line("50mm (HDPE Class 10 Water Pipe)", "m", duct_m.get("50mm HDPE"),
           "Trenching · Ducts=50mm HDPE")
    s.line("MANHOLE RN600 + ECC SPINDLE HEROTEL", "no", mh.get("900mm"), "Manholes · 900mm")
    s.line("MANHOLE RN400 + ECC SPINDLE HEROTEL", "no", mh.get("400mm"), "Manholes · 400mm")
    s.line("500m Roll of Caution/Danger tape", "m", tr.get("Trench"),
           "= trench length", color="G")

    # ── Poles ──  (JJ: Malmesbury's real 5m/7m bands; total in the "Poles" row)
    hdr = s.r
    s.section("Poles")
    pb1 = s.line("5m (100-120) CCA H4 SANS 754", "no", pb.get("5m (100-120)"))
    s.line("5m (120-140) CCA H4 SANS 754", "no", pb.get("5m (120-140)"))
    s.line("7m (100-120) CCA H4 SANS 754", "no", pb.get("7m (100-120)"))
    last_band = s.line("7m (120-140) CCA H4 SANS 754", "no", pb.get("7m (120-140)"))
    ws.cell(hdr, 3).value = f"=SUM(C{pb1}:C{last_band})"
    ws.cell(hdr, 3).font = S["WHITE_B"]
    # Cement: JJ's rule 2026-07-21 — 1 bag per 4 poles (=poles total / 4)
    rc = s.line("Cement Bag.50Kg", "no", None, "1 bag per 4 poles")
    ws.cell(rc, 3).value = f"=C{hdr}/4"
    packB(rc, 1)

    # ── Enclosures ──
    s.section("Enclosures")
    s.line("24F (LIGHT Speed FTTX Dome 5+1 MS - 1C 24F - MEGALSPDJ50[73])", "no",
           dome18, "for 1-8 Splitters", anchor="e18")
    s.line("MEGAnet (LIGHT Speed FTTX Dome) Cs OUTD DOME 3+1P HS (4C - 48F)", "no",
           dome116, "for 1-16 Splitters or just cables", anchor="e116")
    s.line("MEGAnet (LIGHT Speed FTTX Dome) Cs OUTD DOME 6+1P HS (6C - 144F)", "no",
           domefeed, "for Feeder Joints", anchor="efeed")

    # ── Splitters ──
    s.section("Splitters")
    s.line("MEGAnet Cs SPLITTER BARE SM 1-8", "no", dome18, "1-8 Splitter")
    s.line("MEGAnet Cs SPLITTER BARE SM 1-16", "no", dome116, "1-16 Splitter")

    enc = f"({s.C('e18')}+{s.C('e116')}+{s.C('efeed')})"
    # ── Buckles & Strapping for enclosures ──
    s.section("Buckles & Strapping for enclosures")
    r = s.line("LIGHTspeed S/STEEL Strapping 19mmx0.5mm (30m)", None, None,
               "3m per pole")
    ws.cell(r, 3).value = f"={enc}*3/30"
    packB(r, 1)
    r = s.line("LIGHTspeed S/STEEL Buckles 19mm (100)", None, None,
               "2 buckles per joint strap")
    ws.cell(r, 3).value = f"={enc}*2"
    packB(r, 100)

    # ── Hooks ──  (total lives in the "Hooks" section row = 3W+2W+1W)
    ht_row = s.r
    s.section("Hooks")
    r3 = s.line("Hook.3Way", "no", hk.get("3 Way"), "poles · 3 Way")
    r2 = s.line("Hook.2Way (Double)", "no", hk.get("2 Way"), "poles · 2 Way")
    r1 = s.line("Hook.1Way (Single)", "no", hk.get("1 Way"), "poles · 1 Way")
    ws.cell(ht_row, 3).value = f"=C{r3}+C{r2}+C{r1}"
    ws.cell(ht_row, 3).font = S["WHITE_B"]
    hooks3 = f"(C{r3}+C{r2}+C{r1})"
    r = s.line("Couch Screws (6 * 45mm) (100 Box)", None, None,
               "(hooks)*2/100", color="Y")
    ws.cell(r, 3).value = f"={hooks3}*2/100"
    packB(r, 1)

    # ── Strapping for Hooks ──
    s.section("Strapping for Hooks")
    r = s.line("LIGHTspeed S/STEEL Strapping 19mmx0.5mm (30m)", None, None,
               "hooks total * 3 / 30", color="Y")
    ws.cell(r, 3).value = f"=C{ht_row}*3/30"
    packB(r, 1)
    r = s.line("LIGHTspeed S/STEEL Buckles 19mm (100)", None, None,
               "(hooks)*2/100", color="Y")
    ws.cell(r, 3).value = f"={hooks3}*2/100"
    packB(r, 1)

    # ── Slack Brackets (Crosses) ──
    s.section("Slack Brackets")
    r_cr = s.line("Crosses", "no", None, "= all enclosures", anchor="crosses")
    ws.cell(r_cr, 3).value = f"={enc}"
    r = s.line("Couch Screws (6 * 45mm) (100 Box)", None, None, "crosses*2/100")
    ws.cell(r, 3).value = f"=C{r_cr}*2/100"
    packB(r, 1)

    # ── Buckles & Strapping for Crosses ──
    s.section("Buckles & Strapping for Crosses")
    r = s.line("LIGHTspeed S/STEEL Strapping 19mmx0.5mm (30m)", None, None, "crosses*3/30")
    ws.cell(r, 3).value = f"=C{r_cr}*3/30"
    packB(r, 1)
    r = s.line("LIGHTspeed S/STEEL Buckles 19mm (100)", None, None, "crosses*2/100")
    ws.cell(r, 3).value = f"=C{r_cr}*2/100"
    packB(r, 1)

    # ── Dead End ──  total = Σ by-size (each cable arm: terminating + 2·pass-through);
    #   per-size from live cable geometry. Six SKU rows (two 48F variants) mirror
    #   Mahikeng; sizes we don't carry stay blank and SUM ignores them.
    hdr = s.r
    s.section("Dead End")
    first_de = last_de = None
    for key, sku in _DEND_ROWS:
        val = dend.get(key) if key else None
        row = s.line(sku, "no", val, "")
        first_de = first_de or row
        last_de = row
    ws.cell(hdr, 3).value = f"=SUM(C{first_de}:C{last_de})"
    ws.cell(hdr, 3).font = S["WHITE_B"]

    # ── Tangents ──  (present but blank — N/A for HeroTel, Mahikeng skeleton)
    hdr = s.r
    s.section("Tangents")
    ws.cell(hdr, 3).value = "N/A"
    ws.cell(hdr, 3).font = S["WHITE_B"]
    for sku in _TANGENT_ROWS:
        s.line(sku, "no", None, "")

    # ── Cable ──  BY FIBRE SIZE (buy = Tlenght + slack), SSA-75m SKUs; sizes we
    #   don't carry stay blank (JJ: no separate drop-cable row — drops are
    #   connectorised, counted in Demand Points).
    s.section("Cable")
    for size, sku in _CABLE_SKU:
        val = cable.get(size)
        r = s.line(sku, None, (val if val else None),
                   "Tlenght + slack" if val else "", color=("Y" if val else None))
        if val:
            ws.cell(r, 2).value = f"=CEILING(C{r}/4000,1)"

    # ── BOQ Check List (G/H/I) ──
    checklist = [
        ("HDR", "BOQ Check List"),
        ("Backhaul Civil", "Y"), ("Backhaul Optical", "NA"),
        ("ISP Civil", "NA"), ("ISP Optical", "NA"),
        ("HDR", "FTTH"),
        ("Poles", "Y"), ("Cement for Poles", "N"),
        ("Enclosures", "Y"), ("Splitters", "Y"),
        ("Enclosure Straps", "Y"), ("Enclosure Buckles", "Y"),
        ("Hooks", "Y"), ("Hook Straps", "Y"), ("Hook Buckles", "Y"),
        ("Hook Screws", "N"), ("Slack Brackets", "Y"),
        ("Crosses", "Y"), ("Cross Straps", "Y"), ("Cross Screws", "Y"),
        ("Dead Ends", "Y"), ("Tangents", "NA"), ("Cable", "Y"),
    ]
    gr = 2
    for label, state in checklist:
        if label == "HDR":
            c = ws.cell(gr, 7, state)
            c.font = S["BOLD"]
            for cc in (7, 8, 9):
                ws.cell(gr, cc).fill = S["LGREY"]
            gr += 1
            continue
        ws.cell(gr, 7, label).alignment = S["LEFT"]
        ws.cell(gr, 8, "✓" if state == "Y" else "").alignment = S["CENTER"]
        ws.cell(gr, 9, "N/A" if state == "NA" else "").alignment = S["CENTER"]
        for c in (7, 8, 9):
            ws.cell(gr, c).border = S["THIN"]
        gr += 1

    for col, w in (("A", 62), ("B", 7), ("C", 11), ("D", 34),
                   ("E", 3), ("F", 3), ("G", 20), ("H", 6), ("I", 6)):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "A2"
    return s.n_lines


_INVALID_SHEET = ':\\/?*[]'


def _safe_title(name, used):
    """A unique, Excel-legal (<=31 char, no : \\ / ? * [ ]) sheet title."""
    t = "".join(" " if c in _INVALID_SHEET else c for c in str(name)).strip()[:31] or "Sheet"
    base, i = t, 2
    while t.lower() in used:
        suf = f" ({i})"
        t = base[:31 - len(suf)] + suf
        i += 1
    used.add(t.lower())
    return t


def _clean(v):
    """Make an attribute value Excel-safe: strip control chars from strings, and
    coerce Qt date/time (and any other non-primitive) to a string openpyxl accepts."""
    if v is None or isinstance(v, (int, float, bool)):
        return v
    if isinstance(v, str):
        try:
            from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
            return ILLEGAL_CHARACTERS_RE.sub("", v)
        except Exception:
            return v
    try:  # Qt date/time -> ISO-ish string (openpyxl can't take QDate/QDateTime/QTime)
        from qgis.PyQt.QtCore import QDate, QDateTime, QTime
        if isinstance(v, QDateTime):
            return v.toString("yyyy-MM-dd HH:mm:ss")
        if isinstance(v, QDate):
            return v.toString("yyyy-MM-dd")
        if isinstance(v, QTime):
            return v.toString("HH:mm:ss")
    except Exception:
        pass
    try:
        import datetime
        if isinstance(v, (datetime.datetime, datetime.date, datetime.time)):
            return v  # openpyxl handles python datetimes natively
    except Exception:
        pass
    return str(v)


def _full_table_sheet(wb, title, table, S, only_cols=None, total_cols=None,
                      note=None, phase=None):
    """One full attribute-table tab. When ``phase`` (a list aligned to table['rows'])
    is given, a trailing 'Phase' column labels each row with its phase (spatial)."""
    from openpyxl.utils import get_column_letter
    ws = wb.create_sheet(title[:31])
    fields = table.get("fields", [])
    if only_cols:
        idxs = [fields.index(c) for c in only_cols if c in fields]
    else:
        idxs = list(range(len(fields)))
    headers = [fields[i] for i in idxs]
    ncol = len(headers)
    phase_col = ncol + 1 if phase else None

    for i, h in enumerate(headers, 1):
        c = ws.cell(1, i, h)
        c.fill = S["NAVY"]
        c.font = S["WHITE_B"]
        c.alignment = S["CENTER"]
    if phase_col:
        c = ws.cell(1, phase_col, "Phase")
        c.fill = S["NAVY"]
        c.font = S["WHITE_B"]
        c.alignment = S["CENTER"]

    totals = {c: 0 for c in (total_cols or [])}
    r = 2
    for ri, row in enumerate(table.get("rows", [])):
        for i, src in enumerate(idxs, 1):
            v = _clean(row[src]) if src < len(row) else None
            cell = ws.cell(r, i, v)
            cell.border = S["THIN"]
            if isinstance(v, float):
                cell.number_format = "#,##0.###"
        if phase_col:
            pc = ws.cell(r, phase_col, phase[ri] if ri < len(phase) else "")
            pc.border = S["THIN"]
            pc.alignment = S["CENTER"]
        for c in (total_cols or []):
            if c in headers:
                iv = _fnum(row[fields.index(c)])
                totals[c] += int(iv) if iv is not None else 0
        r += 1

    if total_cols:
        ws.cell(r, 1, "TOTAL").font = S["BOLD"]
        for c in total_cols:
            if c in headers:
                tc = ws.cell(r, headers.index(c) + 1, totals[c])
                tc.font = S["BOLD"]
        r += 1
    if note:
        ws.cell(r + 1, 1, note).font = S["MUT"]

    for i, h in enumerate(headers, 1):
        ws.column_dimensions[get_column_letter(i)].width = max(10, min(28, len(str(h)) + 6))
    if phase_col:
        ws.column_dimensions[get_column_letter(phase_col)].width = 12
    ws.freeze_panes = "A2"
    return ws


def _build_details(wb, tables, order, S):
    """One tab per LIVE vector layer = its FULL attribute table, then the two
    derived tabs (Hooks focus + 16-Way Splitter). Every non-empty layer included."""
    names = list(order) + [n for n in tables if n not in order]
    used = {ws.title.lower() for ws in wb.worksheets}  # reserve the summary sheet

    for name in names:
        tbl = tables.get(name, {"fields": [], "rows": []})
        total = ["1 Way", "2 Way", "3 Way"] if name.strip().lower() == "poles" else None
        _full_table_sheet(wb, _safe_title(name, used), tbl, S, total_cols=total,
                          phase=tbl.get("phase"),
                          note=f"Full '{name}' attribute table — {len(tbl.get('rows', []))} features.")

    # derived: Hooks focus (poles subset + TOTAL — the BOQ Hooks source)
    poles = tables.get("poles", {"fields": [], "rows": []})
    _full_table_sheet(wb, _safe_title("Hooks", used), poles, S,
                      only_cols=["id", "Name.", "Pole Lengh", "Pole Size",
                                 "1 Way", "2 Way", "3 Way"],
                      total_cols=["1 Way", "2 Way", "3 Way"],
                      phase=poles.get("phase"),
                      note="Hooks = per-pole 1/2/3-Way counts. BOQ Hooks quantity = the TOTAL row.")

    # derived: 16 Way Splitter = Feeder Joints where Splitters == '1:16'
    fj = tables.get("Feeder Joints", {"fields": [], "rows": []})
    if "Splitters" in fj.get("fields", []):
        si = fj["fields"].index("Splitters")
        f16 = {"fields": fj["fields"],
               "rows": [r for r in fj["rows"] if str(r[si]).strip() == "1:16"]}
    else:
        f16 = fj
    _full_table_sheet(wb, _safe_title("16 Way Splitter", used), f16, S,
                      note="Feeder Joints where Splitters = 1:16.")


def _build_ways_qa(wb, qa, S):
    """QA tab: where the hand-filled hook ways disagree with the cable geometry.

    Read-only — driven by way_counter.qa_report(). The BOQ Hooks + Dead-End
    quantities come from the MANUAL ways (what JJ filled); this tab just flags the
    poles where the geometry would say something different, so a wrong hand-fill
    can be caught before the numbers are trusted.
    """
    ws = wb.create_sheet("Hook Ways QA"[:31])
    man = qa.get("manual_totals", (0, 0, 0))
    pred = qa.get("predicted_totals", (0, 0, 0))
    ws["A1"] = "Hook Ways QA — hand-fill vs cable geometry (read-only)"
    ws["A1"].font = S["WHITE_B"]
    ws["A1"].fill = S["NAVY"]
    summary = [
        ("Poles checked", qa.get("n_poles")),
        ("Agree with geometry", f"{qa.get('exact_match')} / {qa.get('n_poles')} "
                                f"({qa.get('exact_pct')}%)"),
        ("Manual totals (1/2/3-Way)", f"{man[0]} / {man[1]} / {man[2]}"),
        ("Geometry totals (1/2/3-Way)", f"{pred[0]} / {pred[1]} / {pred[2]}"),
        ("Blank ways", qa.get("n_blank")),
        ("Off-backbone poles", qa.get("n_no_backbone")),
        ("Blank AND on backbone (fillable)", qa.get("n_fillable")),
    ]
    r = 3
    for k, v in summary:
        ws.cell(r, 1, k).font = S["BOLD"]
        ws.cell(r, 3, v)
        r += 1

    r += 1
    headers = ["Pole", "Manual 1W", "2W", "3W", "Geom 1W", "2W", "3W",
               "term", "thru", "arms"]
    for i, h in enumerate(headers, 1):
        c = ws.cell(r, i, h)
        c.fill = S["NAVY"]
        c.font = S["WHITE_B"]
        c.alignment = S["CENTER"]
    r += 1
    for m in qa.get("mismatches", []):
        mm, pp, gg = m["manual"], m["predict"], m["geom"]
        vals = [m["name"], mm[0], mm[1], mm[2], pp[0], pp[1], pp[2],
                gg[0], gg[1], gg[2]]
        for i, v in enumerate(vals, 1):
            cell = ws.cell(r, i, v)
            cell.border = S["THIN"]
            if i > 1:
                cell.alignment = S["CENTER"]
        r += 1
    if not qa.get("mismatches"):
        ws.cell(r, 1, "No disagreements — every hand-filled pole matches the "
                      "geometry.").font = S["MUT"]

    ws.column_dimensions["A"].width = 16
    for col in "BCDEFGHIJ":
        ws.column_dimensions[col].width = 9
    ws.freeze_panes = "A2"
    return ws


def _build_reconciliation(wb, main_lines, phase_line_map, order, S):
    """Reconciliation tab — per billed line: MAIN vs each phase vs Σ phases + Δ +
    PASS/FAIL. Counts must tie EXACTLY; metres within 0.25 m (clip rounding). This is
    the hard guardrail: any line that does not sum across the phases is flagged red.

    Returns (all_ok, n_fail)."""
    ws = wb.create_sheet("Reconciliation")
    hdr = ["Line", "MAIN"] + list(order) + ["Σ phases", "Δ", "Status"]
    for i, h in enumerate(hdr, 1):
        c = ws.cell(1, i, h)
        c.fill = S["NAVY"]
        c.font = S["WHITE_B"]
        c.alignment = S["CENTER"]

    from openpyxl.utils import get_column_letter as _gcl
    nph = len(order)
    col_sum, col_delta, col_status = 3 + nph, 4 + nph, 5 + nph
    n_fail = 0
    r = 2
    for i, (label, mval, kind) in enumerate(main_lines):
        pvals = [phase_line_map[p][i][1] for p in order]
        sm = sum(pvals)
        delta = round(sm - mval, 2)
        tol = 0.0 if kind == "count" else 0.25
        ok = abs(delta) <= tol
        if not ok:
            n_fail += 1
        # static source values: Line, MAIN, each phase
        for j, v in enumerate([label, mval] + pvals, 1):
            cell = ws.cell(r, j, v)
            cell.border = S["THIN"]
            if j > 1:
                cell.alignment = S["CENTER"]
            if isinstance(v, float):
                cell.number_format = "#,##0.0"
        # LIVE formulas: Σ = SUM(phase cols) · Δ = Σ − MAIN · Status = IF(|Δ|≤tol,…)
        pcols = f"{_gcl(3)}{r}:{_gcl(2 + nph)}{r}"
        sc = ws.cell(r, col_sum, f"=SUM({pcols})")
        dc = ws.cell(r, col_delta, f"={_gcl(col_sum)}{r}-B{r}")
        st = ws.cell(r, col_status,
                     f'=IF(ABS({_gcl(col_delta)}{r})<={tol},"PASS","FAIL")')
        for c in (sc, dc, st):
            c.border = S["THIN"]
            c.alignment = S["CENTER"]
        sc.number_format = dc.number_format = "#,##0.0"
        st.fill = S["GREEN"] if ok else S["YELLOW"]
        st.font = S["BOLD"]
        r += 1

    r += 1
    verdict = ("ALL LINES RECONCILE — every phase sums to MAIN."
               if n_fail == 0 else
               f"{n_fail} LINE(S) DO NOT RECONCILE — investigate before billing.")
    vc = ws.cell(r, 1, verdict)
    vc.font = S["BOLD"]
    vc.fill = S["GREEN"] if n_fail == 0 else S["YELLOW"]

    ws.column_dimensions["A"].width = 34
    from openpyxl.utils import get_column_letter
    for j in range(2, len(hdr) + 1):
        ws.column_dimensions[get_column_letter(j)].width = 12
    ws.freeze_panes = "B2"
    return n_fail == 0, n_fail


def _save_clean(wb, path):
    """Save, then strip openpyxl's empty <definedNames/> (harmless 'Repaired' banner).

    Atomic: writes to temps and os.replace()s in — a locked target .xlsx is left
    untouched and raises a friendly error instead of truncating.
    """
    _dir = os.path.dirname(path) or "."
    os.makedirs(_dir, exist_ok=True)
    fd, raw = tempfile.mkstemp(suffix=".xlsx", dir=_dir)
    os.close(fd)
    fd, clean = tempfile.mkstemp(suffix=".xlsx", dir=_dir)
    os.close(fd)
    try:
        wb.save(raw)
        with zipfile.ZipFile(raw) as src:
            wbx = src.read("xl/workbook.xml").decode("utf-8")
            wbx = (wbx.replace("<definedNames/>", "")
                      .replace("<definedNames></definedNames>", ""))
            with zipfile.ZipFile(clean, "w", zipfile.ZIP_DEFLATED) as dst:
                for item in src.infolist():
                    data = (wbx.encode("utf-8") if item.filename == "xl/workbook.xml"
                            else src.read(item.filename))
                    dst.writestr(item, data)
        try:
            os.replace(clean, path)
        except PermissionError:
            raise RuntimeError(
                f"Cannot write the BoQ — close '{os.path.basename(path)}' in Excel "
                "and run it again.")
    finally:
        for t in (raw, clean):
            try:
                if os.path.exists(t):
                    os.remove(t)
            except OSError:
                pass


# ── the single entry point (router calls this) ────────────────────────────────
def run_herotel_boq(out_path=None, project=None):
    """Build the HeroTel BoQ from the live layers; write it; return the uniform dict.

    Returns a dict the router normalises: {path, lines, verdict, findings, diag}.
    Ratio-rule items are left blank + flagged (findings), never guessed.
    """
    from openpyxl import Workbook
    from qgis.core import QgsProject
    project = project or QgsProject.instance()

    ps = _phase_split()
    polys = ps.load_phases(project)

    Q, tables, order, findings = _extract(project, polys=polys or None)

    # Hook-ways QA (read-only): flag poles where the hand-filled ways disagree with
    # the cable geometry. The BOQ Hooks/Dead-End quantities still use the MANUAL
    # ways; this only surfaces mismatches so a bad hand-fill is caught.
    qa = None
    de = None
    try:
        try:
            from . import way_counter
        except ImportError:
            from fibre_automation.boq import way_counter
        qa = way_counter.qa_report(project)
        de = way_counter.deadends_by_sku(project)
        if qa.get("n_poles"):
            findings.append(("INFO",
                             f"Hook ways: {qa['exact_match']}/{qa['n_poles']} poles "
                             f"({qa['exact_pct']}%) match the cable geometry; "
                             f"{len(qa['mismatches'])} differ — see the 'Hook Ways QA' "
                             "tab before trusting the Hooks/Dead-End totals."))
    except Exception as e:
        findings.append(("WARN", f"Hook-ways QA / dead-ends skipped ({e!r})."))

    # Per-phase billed quantities (JJ: always include the phase tabs when a Phases
    # layer exists). Each feature is bucketed by phase so the phases sum to MAIN.
    phased = None
    if polys:
        try:
            buckets, ph_order, ph_findings = _extract_phased(project, polys)
            findings += ph_findings
            phased = (buckets, ph_order)
            findings.append(("INFO", f"Phased BOQ: {len(polys)} phase(s) "
                                     f"({', '.join(ps.phase_names(polys))}) — see the "
                                     "per-phase tabs + Reconciliation."))
        except Exception as e:
            findings.append(("WARN", f"Phased BOQ skipped ({e!r})."))
    else:
        findings.append(("INFO", "No 'Phases' layer found — whole-project BOQ only "
                                 "(no per-phase tabs)."))

    main_title = ("Malmesbury BOQ (All Phases)" if phased
                  else "Malmesbury Phase 1 BOQ")

    n_lines = 0
    if out_path:
        S = _styles()
        wb = Workbook()
        ws = wb.active
        ws.title = main_title[:31]
        if phased:
            _msuf = _phase_suffix(phased[1])
            main_civ, main_mat = "Civil " + _msuf, "Material " + _msuf
        else:
            main_civ, main_mat = "Backhaul Civil", "Backhaul material"
        n_lines = _build_main(ws, Q, de, S, title=main_title,
                              civil_label=main_civ, material_label=main_mat)

        # per-phase summary sheets + the hard Reconciliation guardrail
        if phased:
            buckets, ph_order = phased
            main_lines = _billed_lines(Q, de or {})
            phase_line_map = {}
            for name in ph_order:
                bq, bdend = buckets[name]
                bde = {"by_dend_sku": bdend}
                used = {w.title.lower() for w in wb.worksheets}
                pws = wb.create_sheet(_safe_title(name, used))
                _psuf = _phase_suffix([name])
                _build_main(pws, bq, bde, S, title=f"Malmesbury — {name} BOQ",
                            civil_label="Civil " + _psuf,
                            material_label="Material " + _psuf)
                phase_line_map[name] = _billed_lines(bq, bde)
            recon_ok, n_fail = _build_reconciliation(
                wb, main_lines, phase_line_map, ph_order, S)
            if not recon_ok:
                findings.append(("GATE", f"Reconciliation: {n_fail} line(s) do not sum "
                                         "across the phases — see the Reconciliation tab."))
            else:
                findings.append(("INFO", "Reconciliation: every billed line sums across "
                                         "the phases back to MAIN."))

        _build_details(wb, tables, order, S)
        if qa is not None:
            _build_ways_qa(wb, qa, S)
        _save_clean(wb, out_path)

    findings.append(("WARN", "The 7-Way backhaul micro-duct line is left blank until "
                             "its SKU/length is confirmed. Hook screws/straps/buckles "
                             "use the template's still-provisional (yellow) ratios — "
                             "verify before ordering."))
    verdict = "WARN" if any(s in ("GATE", "BLOCK") for s, _ in findings) else "OK"
    return {
        "path": out_path,
        "lines": n_lines,
        "verdict": verdict,
        "findings": findings,
        "diag": {
            "poles": _q(Q, "poles", "total"),
            "hooks": _q(Q, "poles", "hook_total"),
            "phases": (len(polys) if polys else 0),
        },
    }
