<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyDrawingHints="0" symbologyReferenceScale="-1" maxScale="0" hasScaleBasedVisibilityFlag="0" minScale="100000000" simplifyDrawingTol="1" simplifyLocal="1" styleCategories="AllStyleCategories" autoRefreshMode="Disabled" simplifyAlgorithm="0" version="3.44.4-Solothurn" readOnly="0" labelsEnabled="0" autoRefreshTime="0" simplifyMaxScale="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endField="" startExpression="" endExpression="" durationField="featno1" mode="0" limitMode="0" startField="datecreate" enabled="0" fixedDuration="0" durationUnit="min" accumulate="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation zoffset="0" extrusion="0" type="IndividualFeatures" zscale="1" clamping="Terrain" extrusionEnabled="0" binding="Centroid" customToleranceEnabled="0" showMarkerSymbolInSurfacePlots="0" symbology="Line" respectLayerSymbol="1">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol name="" clip_to_extent="1" type="line" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleLine" id="{42d0ce02-3b41-483b-a94a-adf60c7cde4b}" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="225,89,137,255,rgb:0.8823529,0.3490196,0.5372549,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol name="" clip_to_extent="1" type="fill" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleFill" id="{8033ef54-b6b5-4a72-98e4-22e37191f38b}" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="225,89,137,255,rgb:0.8823529,0.3490196,0.5372549,1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="161,64,98,255,rgb:0.6302434,0.2493019,0.3837797,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol name="" clip_to_extent="1" type="marker" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleMarker" id="{690218cc-3535-4cbe-824c-b229ee7a66dd}" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="225,89,137,255,rgb:0.8823529,0.3490196,0.5372549,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="diamond"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="161,64,98,255,rgb:0.6302434,0.2493019,0.3837797,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" type="singleSymbol" forceraster="0" referencescale="-1" symbollevels="0">
    <symbols>
      <symbol name="0" clip_to_extent="1" type="marker" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleMarker" id="{c65bb4d3-2698-4af1-9da2-5deb33f5ad25}" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="248,0,5,255,hsv:0.99633333333333329,1,0.97267109178301669,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="2"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol name="" clip_to_extent="1" type="marker" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleMarker" id="{81078f64-f732-4757-9a89-b773b560d24f}" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="255,0,0,255,rgb:1,0,0,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="2"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <customproperties>
    <Option type="Map">
      <Option name="dualview/previewExpressions" type="List">
        <Option type="QString" value="&quot;Label&quot;"/>
      </Option>
      <Option name="embeddedWidgets/count" type="int" value="0"/>
      <Option name="variableNames" type="invalid"/>
      <Option name="variableValues" type="invalid"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field name="dim1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="endfeat" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="lat" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="lon" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sg21" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sg26" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="address" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="pon_no" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="zone_no" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subplace" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="editby" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="comments" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Label" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Pole Type" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="type_1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subtype_1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="spec_1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cablecap1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="connect1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="status" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="companyown" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="type_2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subtype_2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="spec_2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim1_2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim2_2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cablecap2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="connect2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="featno1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="type_3" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subtype_3" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="spec_3" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim1_3" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim2_3" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cablecap3" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="connect3" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="featno2" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="type_4" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subtype4" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="spec_4" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim1_4" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim2_4" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cablecap4" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="connect4" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="featno3" configurationFlags="NoFlag">
      <editWidget type="CheckBox">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="type_5" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subtype5" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="spec_5" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim1_5" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim2_5" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cablecap5" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="connect5" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="featno4" configurationFlags="NoFlag">
      <editWidget type="CheckBox">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="type_6" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subtype_6" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="spec_6" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim1_6" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim2_6" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cablecap6" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="connect6" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="featno5" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="type_7" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subtype7" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="spec_7" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim1_7" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim2_7" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cablecap7" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="connect7" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="featno6" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="startfeat" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="mainplace" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="municipal" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="stack" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="createdby" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="date_edit" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" index="0" field="dim1"/>
    <alias name="" index="1" field="dim2"/>
    <alias name="" index="2" field="endfeat"/>
    <alias name="" index="3" field="lat"/>
    <alias name="" index="4" field="lon"/>
    <alias name="" index="5" field="sg21"/>
    <alias name="" index="6" field="sg26"/>
    <alias name="" index="7" field="address"/>
    <alias name="" index="8" field="pon_no"/>
    <alias name="" index="9" field="zone_no"/>
    <alias name="" index="10" field="subplace"/>
    <alias name="" index="11" field="editby"/>
    <alias name="" index="12" field="comments"/>
    <alias name="" index="13" field="Label"/>
    <alias name="" index="14" field="Pole Type"/>
    <alias name="" index="15" field="type_1"/>
    <alias name="" index="16" field="subtype_1"/>
    <alias name="" index="17" field="spec_1"/>
    <alias name="" index="18" field="cablecap1"/>
    <alias name="" index="19" field="connect1"/>
    <alias name="" index="20" field="status"/>
    <alias name="" index="21" field="companyown"/>
    <alias name="" index="22" field="type_2"/>
    <alias name="" index="23" field="subtype_2"/>
    <alias name="" index="24" field="spec_2"/>
    <alias name="" index="25" field="dim1_2"/>
    <alias name="" index="26" field="dim2_2"/>
    <alias name="" index="27" field="cablecap2"/>
    <alias name="" index="28" field="connect2"/>
    <alias name="" index="29" field="featno1"/>
    <alias name="" index="30" field="type_3"/>
    <alias name="" index="31" field="subtype_3"/>
    <alias name="" index="32" field="spec_3"/>
    <alias name="" index="33" field="dim1_3"/>
    <alias name="" index="34" field="dim2_3"/>
    <alias name="" index="35" field="cablecap3"/>
    <alias name="" index="36" field="connect3"/>
    <alias name="" index="37" field="featno2"/>
    <alias name="" index="38" field="type_4"/>
    <alias name="" index="39" field="subtype4"/>
    <alias name="" index="40" field="spec_4"/>
    <alias name="" index="41" field="dim1_4"/>
    <alias name="" index="42" field="dim2_4"/>
    <alias name="" index="43" field="cablecap4"/>
    <alias name="" index="44" field="connect4"/>
    <alias name="" index="45" field="featno3"/>
    <alias name="" index="46" field="type_5"/>
    <alias name="" index="47" field="subtype5"/>
    <alias name="" index="48" field="spec_5"/>
    <alias name="" index="49" field="dim1_5"/>
    <alias name="" index="50" field="dim2_5"/>
    <alias name="" index="51" field="cablecap5"/>
    <alias name="" index="52" field="connect5"/>
    <alias name="" index="53" field="featno4"/>
    <alias name="" index="54" field="type_6"/>
    <alias name="" index="55" field="subtype_6"/>
    <alias name="" index="56" field="spec_6"/>
    <alias name="" index="57" field="dim1_6"/>
    <alias name="" index="58" field="dim2_6"/>
    <alias name="" index="59" field="cablecap6"/>
    <alias name="" index="60" field="connect6"/>
    <alias name="" index="61" field="featno5"/>
    <alias name="" index="62" field="type_7"/>
    <alias name="" index="63" field="subtype7"/>
    <alias name="" index="64" field="spec_7"/>
    <alias name="" index="65" field="dim1_7"/>
    <alias name="" index="66" field="dim2_7"/>
    <alias name="" index="67" field="cablecap7"/>
    <alias name="" index="68" field="connect7"/>
    <alias name="" index="69" field="featno6"/>
    <alias name="" index="70" field="startfeat"/>
    <alias name="" index="71" field="mainplace"/>
    <alias name="" index="72" field="municipal"/>
    <alias name="" index="73" field="stack"/>
    <alias name="" index="74" field="createdby"/>
    <alias name="" index="75" field="date_edit"/>
  </aliases>
  <defaults>
    <default expression="" field="dim1" applyOnUpdate="0"/>
    <default expression="" field="dim2" applyOnUpdate="0"/>
    <default expression="" field="endfeat" applyOnUpdate="0"/>
    <default expression="" field="lat" applyOnUpdate="0"/>
    <default expression="" field="lon" applyOnUpdate="0"/>
    <default expression="" field="sg21" applyOnUpdate="0"/>
    <default expression="" field="sg26" applyOnUpdate="0"/>
    <default expression="" field="address" applyOnUpdate="0"/>
    <default expression="" field="pon_no" applyOnUpdate="0"/>
    <default expression="" field="zone_no" applyOnUpdate="0"/>
    <default expression="" field="subplace" applyOnUpdate="0"/>
    <default expression="" field="editby" applyOnUpdate="0"/>
    <default expression="" field="comments" applyOnUpdate="0"/>
    <default expression="" field="Label" applyOnUpdate="0"/>
    <default expression="" field="Pole Type" applyOnUpdate="0"/>
    <default expression="" field="type_1" applyOnUpdate="0"/>
    <default expression="" field="subtype_1" applyOnUpdate="0"/>
    <default expression="" field="spec_1" applyOnUpdate="0"/>
    <default expression="" field="cablecap1" applyOnUpdate="0"/>
    <default expression="" field="connect1" applyOnUpdate="0"/>
    <default expression="" field="status" applyOnUpdate="0"/>
    <default expression="" field="companyown" applyOnUpdate="0"/>
    <default expression="" field="type_2" applyOnUpdate="0"/>
    <default expression="" field="subtype_2" applyOnUpdate="0"/>
    <default expression="" field="spec_2" applyOnUpdate="0"/>
    <default expression="" field="dim1_2" applyOnUpdate="0"/>
    <default expression="" field="dim2_2" applyOnUpdate="0"/>
    <default expression="" field="cablecap2" applyOnUpdate="0"/>
    <default expression="" field="connect2" applyOnUpdate="0"/>
    <default expression="" field="featno1" applyOnUpdate="0"/>
    <default expression="" field="type_3" applyOnUpdate="0"/>
    <default expression="" field="subtype_3" applyOnUpdate="0"/>
    <default expression="" field="spec_3" applyOnUpdate="0"/>
    <default expression="" field="dim1_3" applyOnUpdate="0"/>
    <default expression="" field="dim2_3" applyOnUpdate="0"/>
    <default expression="" field="cablecap3" applyOnUpdate="0"/>
    <default expression="" field="connect3" applyOnUpdate="0"/>
    <default expression="" field="featno2" applyOnUpdate="0"/>
    <default expression="" field="type_4" applyOnUpdate="0"/>
    <default expression="" field="subtype4" applyOnUpdate="0"/>
    <default expression="" field="spec_4" applyOnUpdate="0"/>
    <default expression="" field="dim1_4" applyOnUpdate="0"/>
    <default expression="" field="dim2_4" applyOnUpdate="0"/>
    <default expression="" field="cablecap4" applyOnUpdate="0"/>
    <default expression="" field="connect4" applyOnUpdate="0"/>
    <default expression="" field="featno3" applyOnUpdate="0"/>
    <default expression="" field="type_5" applyOnUpdate="0"/>
    <default expression="" field="subtype5" applyOnUpdate="0"/>
    <default expression="" field="spec_5" applyOnUpdate="0"/>
    <default expression="" field="dim1_5" applyOnUpdate="0"/>
    <default expression="" field="dim2_5" applyOnUpdate="0"/>
    <default expression="" field="cablecap5" applyOnUpdate="0"/>
    <default expression="" field="connect5" applyOnUpdate="0"/>
    <default expression="" field="featno4" applyOnUpdate="0"/>
    <default expression="" field="type_6" applyOnUpdate="0"/>
    <default expression="" field="subtype_6" applyOnUpdate="0"/>
    <default expression="" field="spec_6" applyOnUpdate="0"/>
    <default expression="" field="dim1_6" applyOnUpdate="0"/>
    <default expression="" field="dim2_6" applyOnUpdate="0"/>
    <default expression="" field="cablecap6" applyOnUpdate="0"/>
    <default expression="" field="connect6" applyOnUpdate="0"/>
    <default expression="" field="featno5" applyOnUpdate="0"/>
    <default expression="" field="type_7" applyOnUpdate="0"/>
    <default expression="" field="subtype7" applyOnUpdate="0"/>
    <default expression="" field="spec_7" applyOnUpdate="0"/>
    <default expression="" field="dim1_7" applyOnUpdate="0"/>
    <default expression="" field="dim2_7" applyOnUpdate="0"/>
    <default expression="" field="cablecap7" applyOnUpdate="0"/>
    <default expression="" field="connect7" applyOnUpdate="0"/>
    <default expression="" field="featno6" applyOnUpdate="0"/>
    <default expression="" field="startfeat" applyOnUpdate="0"/>
    <default expression="" field="mainplace" applyOnUpdate="0"/>
    <default expression="" field="municipal" applyOnUpdate="0"/>
    <default expression="" field="stack" applyOnUpdate="0"/>
    <default expression="" field="createdby" applyOnUpdate="0"/>
    <default expression="" field="date_edit" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="endfeat"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="lat"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="lon"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="sg21"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="sg26"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="address"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="pon_no"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="zone_no"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subplace"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="editby"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="comments"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="Label"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="Pole Type"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="type_1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subtype_1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="spec_1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="cablecap1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="connect1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="status"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="companyown"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="type_2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subtype_2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="spec_2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim1_2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim2_2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="cablecap2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="connect2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="featno1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="type_3"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subtype_3"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="spec_3"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim1_3"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim2_3"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="cablecap3"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="connect3"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="featno2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="type_4"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subtype4"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="spec_4"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim1_4"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim2_4"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="cablecap4"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="connect4"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="featno3"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="type_5"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subtype5"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="spec_5"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim1_5"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim2_5"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="cablecap5"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="connect5"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="featno4"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="type_6"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subtype_6"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="spec_6"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim1_6"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim2_6"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="cablecap6"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="connect6"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="featno5"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="type_7"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subtype7"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="spec_7"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim1_7"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim2_7"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="cablecap7"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="connect7"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="featno6"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="startfeat"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="mainplace"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="municipal"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="stack"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="createdby"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="date_edit"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" field="dim1" desc=""/>
    <constraint exp="" field="dim2" desc=""/>
    <constraint exp="" field="endfeat" desc=""/>
    <constraint exp="" field="lat" desc=""/>
    <constraint exp="" field="lon" desc=""/>
    <constraint exp="" field="sg21" desc=""/>
    <constraint exp="" field="sg26" desc=""/>
    <constraint exp="" field="address" desc=""/>
    <constraint exp="" field="pon_no" desc=""/>
    <constraint exp="" field="zone_no" desc=""/>
    <constraint exp="" field="subplace" desc=""/>
    <constraint exp="" field="editby" desc=""/>
    <constraint exp="" field="comments" desc=""/>
    <constraint exp="" field="Label" desc=""/>
    <constraint exp="" field="Pole Type" desc=""/>
    <constraint exp="" field="type_1" desc=""/>
    <constraint exp="" field="subtype_1" desc=""/>
    <constraint exp="" field="spec_1" desc=""/>
    <constraint exp="" field="cablecap1" desc=""/>
    <constraint exp="" field="connect1" desc=""/>
    <constraint exp="" field="status" desc=""/>
    <constraint exp="" field="companyown" desc=""/>
    <constraint exp="" field="type_2" desc=""/>
    <constraint exp="" field="subtype_2" desc=""/>
    <constraint exp="" field="spec_2" desc=""/>
    <constraint exp="" field="dim1_2" desc=""/>
    <constraint exp="" field="dim2_2" desc=""/>
    <constraint exp="" field="cablecap2" desc=""/>
    <constraint exp="" field="connect2" desc=""/>
    <constraint exp="" field="featno1" desc=""/>
    <constraint exp="" field="type_3" desc=""/>
    <constraint exp="" field="subtype_3" desc=""/>
    <constraint exp="" field="spec_3" desc=""/>
    <constraint exp="" field="dim1_3" desc=""/>
    <constraint exp="" field="dim2_3" desc=""/>
    <constraint exp="" field="cablecap3" desc=""/>
    <constraint exp="" field="connect3" desc=""/>
    <constraint exp="" field="featno2" desc=""/>
    <constraint exp="" field="type_4" desc=""/>
    <constraint exp="" field="subtype4" desc=""/>
    <constraint exp="" field="spec_4" desc=""/>
    <constraint exp="" field="dim1_4" desc=""/>
    <constraint exp="" field="dim2_4" desc=""/>
    <constraint exp="" field="cablecap4" desc=""/>
    <constraint exp="" field="connect4" desc=""/>
    <constraint exp="" field="featno3" desc=""/>
    <constraint exp="" field="type_5" desc=""/>
    <constraint exp="" field="subtype5" desc=""/>
    <constraint exp="" field="spec_5" desc=""/>
    <constraint exp="" field="dim1_5" desc=""/>
    <constraint exp="" field="dim2_5" desc=""/>
    <constraint exp="" field="cablecap5" desc=""/>
    <constraint exp="" field="connect5" desc=""/>
    <constraint exp="" field="featno4" desc=""/>
    <constraint exp="" field="type_6" desc=""/>
    <constraint exp="" field="subtype_6" desc=""/>
    <constraint exp="" field="spec_6" desc=""/>
    <constraint exp="" field="dim1_6" desc=""/>
    <constraint exp="" field="dim2_6" desc=""/>
    <constraint exp="" field="cablecap6" desc=""/>
    <constraint exp="" field="connect6" desc=""/>
    <constraint exp="" field="featno5" desc=""/>
    <constraint exp="" field="type_7" desc=""/>
    <constraint exp="" field="subtype7" desc=""/>
    <constraint exp="" field="spec_7" desc=""/>
    <constraint exp="" field="dim1_7" desc=""/>
    <constraint exp="" field="dim2_7" desc=""/>
    <constraint exp="" field="cablecap7" desc=""/>
    <constraint exp="" field="connect7" desc=""/>
    <constraint exp="" field="featno6" desc=""/>
    <constraint exp="" field="startfeat" desc=""/>
    <constraint exp="" field="mainplace" desc=""/>
    <constraint exp="" field="municipal" desc=""/>
    <constraint exp="" field="stack" desc=""/>
    <constraint exp="" field="createdby" desc=""/>
    <constraint exp="" field="date_edit" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="&quot;Label&quot;" sortOrder="0">
    <columns>
      <column name="Label" type="field" width="-1" hidden="0"/>
      <column name="Pole Type" type="field" width="134" hidden="0"/>
      <column name="type_1" type="field" width="-1" hidden="0"/>
      <column name="subtype_1" type="field" width="-1" hidden="0"/>
      <column name="spec_1" type="field" width="-1" hidden="0"/>
      <column name="dim1" type="field" width="-1" hidden="0"/>
      <column name="dim2" type="field" width="-1" hidden="0"/>
      <column name="cablecap1" type="field" width="-1" hidden="0"/>
      <column name="connect1" type="field" width="-1" hidden="0"/>
      <column name="status" type="field" width="181" hidden="0"/>
      <column name="companyown" type="field" width="-1" hidden="0"/>
      <column name="type_2" type="field" width="-1" hidden="0"/>
      <column name="subtype_2" type="field" width="-1" hidden="0"/>
      <column name="spec_2" type="field" width="223" hidden="0"/>
      <column name="dim1_2" type="field" width="91" hidden="0"/>
      <column name="dim2_2" type="field" width="-1" hidden="0"/>
      <column name="cablecap2" type="field" width="-1" hidden="0"/>
      <column name="connect2" type="field" width="-1" hidden="0"/>
      <column name="featno1" type="field" width="-1" hidden="0"/>
      <column name="type_3" type="field" width="-1" hidden="0"/>
      <column name="subtype_3" type="field" width="-1" hidden="0"/>
      <column name="spec_3" type="field" width="215" hidden="0"/>
      <column name="dim1_3" type="field" width="-1" hidden="0"/>
      <column name="dim2_3" type="field" width="-1" hidden="0"/>
      <column name="cablecap3" type="field" width="-1" hidden="0"/>
      <column name="connect3" type="field" width="-1" hidden="0"/>
      <column name="featno2" type="field" width="-1" hidden="0"/>
      <column name="type_4" type="field" width="-1" hidden="0"/>
      <column name="subtype4" type="field" width="-1" hidden="0"/>
      <column name="spec_4" type="field" width="-1" hidden="0"/>
      <column name="dim1_4" type="field" width="191" hidden="0"/>
      <column name="dim2_4" type="field" width="-1" hidden="0"/>
      <column name="cablecap4" type="field" width="-1" hidden="0"/>
      <column name="connect4" type="field" width="-1" hidden="0"/>
      <column name="featno3" type="field" width="-1" hidden="0"/>
      <column name="type_5" type="field" width="-1" hidden="0"/>
      <column name="subtype5" type="field" width="-1" hidden="0"/>
      <column name="spec_5" type="field" width="-1" hidden="0"/>
      <column name="dim1_5" type="field" width="-1" hidden="0"/>
      <column name="dim2_5" type="field" width="-1" hidden="0"/>
      <column name="cablecap5" type="field" width="-1" hidden="0"/>
      <column name="connect5" type="field" width="-1" hidden="0"/>
      <column name="featno4" type="field" width="-1" hidden="0"/>
      <column name="type_6" type="field" width="-1" hidden="0"/>
      <column name="subtype_6" type="field" width="-1" hidden="0"/>
      <column name="spec_6" type="field" width="-1" hidden="0"/>
      <column name="dim1_6" type="field" width="-1" hidden="0"/>
      <column name="dim2_6" type="field" width="-1" hidden="0"/>
      <column name="cablecap6" type="field" width="-1" hidden="0"/>
      <column name="connect6" type="field" width="-1" hidden="0"/>
      <column name="featno5" type="field" width="-1" hidden="0"/>
      <column name="type_7" type="field" width="-1" hidden="0"/>
      <column name="subtype7" type="field" width="-1" hidden="0"/>
      <column name="spec_7" type="field" width="-1" hidden="0"/>
      <column name="dim1_7" type="field" width="-1" hidden="0"/>
      <column name="dim2_7" type="field" width="-1" hidden="0"/>
      <column name="cablecap7" type="field" width="-1" hidden="0"/>
      <column name="connect7" type="field" width="-1" hidden="0"/>
      <column name="featno6" type="field" width="-1" hidden="0"/>
      <column name="startfeat" type="field" width="-1" hidden="0"/>
      <column name="endfeat" type="field" width="-1" hidden="0"/>
      <column name="lat" type="field" width="-1" hidden="0"/>
      <column name="lon" type="field" width="-1" hidden="0"/>
      <column name="sg21" type="field" width="-1" hidden="0"/>
      <column name="sg26" type="field" width="-1" hidden="0"/>
      <column name="address" type="field" width="-1" hidden="0"/>
      <column name="pon_no" type="field" width="-1" hidden="0"/>
      <column name="zone_no" type="field" width="-1" hidden="0"/>
      <column name="subplace" type="field" width="-1" hidden="0"/>
      <column name="mainplace" type="field" width="-1" hidden="0"/>
      <column name="municipal" type="field" width="158" hidden="0"/>
      <column name="stack" type="field" width="-1" hidden="0"/>
      <column name="createdby" type="field" width="-1" hidden="0"/>
      <column name="date_edit" type="field" width="-1" hidden="0"/>
      <column name="editby" type="field" width="-1" hidden="0"/>
      <column name="comments" type="field" width="-1" hidden="0"/>
      <column type="actions" width="-1" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="Label" editable="1"/>
    <field name="Pole Type" editable="1"/>
    <field name="address" editable="1"/>
    <field name="cablecap1" editable="1"/>
    <field name="cablecap2" editable="1"/>
    <field name="cablecap3" editable="1"/>
    <field name="cablecap4" editable="1"/>
    <field name="cablecap5" editable="1"/>
    <field name="cablecap6" editable="1"/>
    <field name="cablecap7" editable="1"/>
    <field name="comments" editable="1"/>
    <field name="companyown" editable="1"/>
    <field name="connect1" editable="1"/>
    <field name="connect2" editable="1"/>
    <field name="connect3" editable="1"/>
    <field name="connect4" editable="1"/>
    <field name="connect5" editable="1"/>
    <field name="connect6" editable="1"/>
    <field name="connect7" editable="1"/>
    <field name="createdby" editable="1"/>
    <field name="date_edit" editable="1"/>
    <field name="datecreate" editable="1"/>
    <field name="dim1" editable="1"/>
    <field name="dim1_2" editable="1"/>
    <field name="dim1_3" editable="1"/>
    <field name="dim1_4" editable="1"/>
    <field name="dim1_5" editable="1"/>
    <field name="dim1_6" editable="1"/>
    <field name="dim1_7" editable="1"/>
    <field name="dim2" editable="1"/>
    <field name="dim2_2" editable="1"/>
    <field name="dim2_3" editable="1"/>
    <field name="dim2_4" editable="1"/>
    <field name="dim2_5" editable="1"/>
    <field name="dim2_6" editable="1"/>
    <field name="dim2_7" editable="1"/>
    <field name="editby" editable="1"/>
    <field name="endfeat" editable="1"/>
    <field name="featno1" editable="1"/>
    <field name="featno2" editable="1"/>
    <field name="featno3" editable="1"/>
    <field name="featno4" editable="1"/>
    <field name="featno5" editable="1"/>
    <field name="featno6" editable="1"/>
    <field name="lat" editable="1"/>
    <field name="lon" editable="1"/>
    <field name="mainplace" editable="1"/>
    <field name="municipal" editable="1"/>
    <field name="pon_no" editable="1"/>
    <field name="sg21" editable="1"/>
    <field name="sg26" editable="1"/>
    <field name="spec_1" editable="1"/>
    <field name="spec_2" editable="1"/>
    <field name="spec_3" editable="1"/>
    <field name="spec_4" editable="1"/>
    <field name="spec_5" editable="1"/>
    <field name="spec_6" editable="1"/>
    <field name="spec_7" editable="1"/>
    <field name="stack" editable="1"/>
    <field name="startfeat" editable="1"/>
    <field name="status" editable="1"/>
    <field name="subplace" editable="1"/>
    <field name="subtype4" editable="1"/>
    <field name="subtype5" editable="1"/>
    <field name="subtype7" editable="1"/>
    <field name="subtype_1" editable="1"/>
    <field name="subtype_2" editable="1"/>
    <field name="subtype_3" editable="1"/>
    <field name="subtype_6" editable="1"/>
    <field name="type_1" editable="1"/>
    <field name="type_2" editable="1"/>
    <field name="type_3" editable="1"/>
    <field name="type_4" editable="1"/>
    <field name="type_5" editable="1"/>
    <field name="type_6" editable="1"/>
    <field name="type_7" editable="1"/>
    <field name="zone_no" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="Label" labelOnTop="0"/>
    <field name="Pole Type" labelOnTop="0"/>
    <field name="address" labelOnTop="0"/>
    <field name="cablecap1" labelOnTop="0"/>
    <field name="cablecap2" labelOnTop="0"/>
    <field name="cablecap3" labelOnTop="0"/>
    <field name="cablecap4" labelOnTop="0"/>
    <field name="cablecap5" labelOnTop="0"/>
    <field name="cablecap6" labelOnTop="0"/>
    <field name="cablecap7" labelOnTop="0"/>
    <field name="comments" labelOnTop="0"/>
    <field name="companyown" labelOnTop="0"/>
    <field name="connect1" labelOnTop="0"/>
    <field name="connect2" labelOnTop="0"/>
    <field name="connect3" labelOnTop="0"/>
    <field name="connect4" labelOnTop="0"/>
    <field name="connect5" labelOnTop="0"/>
    <field name="connect6" labelOnTop="0"/>
    <field name="connect7" labelOnTop="0"/>
    <field name="createdby" labelOnTop="0"/>
    <field name="date_edit" labelOnTop="0"/>
    <field name="datecreate" labelOnTop="0"/>
    <field name="dim1" labelOnTop="0"/>
    <field name="dim1_2" labelOnTop="0"/>
    <field name="dim1_3" labelOnTop="0"/>
    <field name="dim1_4" labelOnTop="0"/>
    <field name="dim1_5" labelOnTop="0"/>
    <field name="dim1_6" labelOnTop="0"/>
    <field name="dim1_7" labelOnTop="0"/>
    <field name="dim2" labelOnTop="0"/>
    <field name="dim2_2" labelOnTop="0"/>
    <field name="dim2_3" labelOnTop="0"/>
    <field name="dim2_4" labelOnTop="0"/>
    <field name="dim2_5" labelOnTop="0"/>
    <field name="dim2_6" labelOnTop="0"/>
    <field name="dim2_7" labelOnTop="0"/>
    <field name="editby" labelOnTop="0"/>
    <field name="endfeat" labelOnTop="0"/>
    <field name="featno1" labelOnTop="0"/>
    <field name="featno2" labelOnTop="0"/>
    <field name="featno3" labelOnTop="0"/>
    <field name="featno4" labelOnTop="0"/>
    <field name="featno5" labelOnTop="0"/>
    <field name="featno6" labelOnTop="0"/>
    <field name="lat" labelOnTop="0"/>
    <field name="lon" labelOnTop="0"/>
    <field name="mainplace" labelOnTop="0"/>
    <field name="municipal" labelOnTop="0"/>
    <field name="pon_no" labelOnTop="0"/>
    <field name="sg21" labelOnTop="0"/>
    <field name="sg26" labelOnTop="0"/>
    <field name="spec_1" labelOnTop="0"/>
    <field name="spec_2" labelOnTop="0"/>
    <field name="spec_3" labelOnTop="0"/>
    <field name="spec_4" labelOnTop="0"/>
    <field name="spec_5" labelOnTop="0"/>
    <field name="spec_6" labelOnTop="0"/>
    <field name="spec_7" labelOnTop="0"/>
    <field name="stack" labelOnTop="0"/>
    <field name="startfeat" labelOnTop="0"/>
    <field name="status" labelOnTop="0"/>
    <field name="subplace" labelOnTop="0"/>
    <field name="subtype4" labelOnTop="0"/>
    <field name="subtype5" labelOnTop="0"/>
    <field name="subtype7" labelOnTop="0"/>
    <field name="subtype_1" labelOnTop="0"/>
    <field name="subtype_2" labelOnTop="0"/>
    <field name="subtype_3" labelOnTop="0"/>
    <field name="subtype_6" labelOnTop="0"/>
    <field name="type_1" labelOnTop="0"/>
    <field name="type_2" labelOnTop="0"/>
    <field name="type_3" labelOnTop="0"/>
    <field name="type_4" labelOnTop="0"/>
    <field name="type_5" labelOnTop="0"/>
    <field name="type_6" labelOnTop="0"/>
    <field name="type_7" labelOnTop="0"/>
    <field name="zone_no" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="Label" reuseLastValue="0"/>
    <field name="Pole Type" reuseLastValue="0"/>
    <field name="address" reuseLastValue="0"/>
    <field name="cablecap1" reuseLastValue="0"/>
    <field name="cablecap2" reuseLastValue="0"/>
    <field name="cablecap3" reuseLastValue="0"/>
    <field name="cablecap4" reuseLastValue="0"/>
    <field name="cablecap5" reuseLastValue="0"/>
    <field name="cablecap6" reuseLastValue="0"/>
    <field name="cablecap7" reuseLastValue="0"/>
    <field name="comments" reuseLastValue="0"/>
    <field name="companyown" reuseLastValue="0"/>
    <field name="connect1" reuseLastValue="0"/>
    <field name="connect2" reuseLastValue="0"/>
    <field name="connect3" reuseLastValue="0"/>
    <field name="connect4" reuseLastValue="0"/>
    <field name="connect5" reuseLastValue="0"/>
    <field name="connect6" reuseLastValue="0"/>
    <field name="connect7" reuseLastValue="0"/>
    <field name="createdby" reuseLastValue="0"/>
    <field name="date_edit" reuseLastValue="0"/>
    <field name="datecreate" reuseLastValue="0"/>
    <field name="dim1" reuseLastValue="0"/>
    <field name="dim1_2" reuseLastValue="0"/>
    <field name="dim1_3" reuseLastValue="0"/>
    <field name="dim1_4" reuseLastValue="0"/>
    <field name="dim1_5" reuseLastValue="0"/>
    <field name="dim1_6" reuseLastValue="0"/>
    <field name="dim1_7" reuseLastValue="0"/>
    <field name="dim2" reuseLastValue="0"/>
    <field name="dim2_2" reuseLastValue="0"/>
    <field name="dim2_3" reuseLastValue="0"/>
    <field name="dim2_4" reuseLastValue="0"/>
    <field name="dim2_5" reuseLastValue="0"/>
    <field name="dim2_6" reuseLastValue="0"/>
    <field name="dim2_7" reuseLastValue="0"/>
    <field name="editby" reuseLastValue="0"/>
    <field name="endfeat" reuseLastValue="0"/>
    <field name="featno1" reuseLastValue="0"/>
    <field name="featno2" reuseLastValue="0"/>
    <field name="featno3" reuseLastValue="0"/>
    <field name="featno4" reuseLastValue="0"/>
    <field name="featno5" reuseLastValue="0"/>
    <field name="featno6" reuseLastValue="0"/>
    <field name="lat" reuseLastValue="0"/>
    <field name="lon" reuseLastValue="0"/>
    <field name="mainplace" reuseLastValue="0"/>
    <field name="municipal" reuseLastValue="0"/>
    <field name="pon_no" reuseLastValue="0"/>
    <field name="sg21" reuseLastValue="0"/>
    <field name="sg26" reuseLastValue="0"/>
    <field name="spec_1" reuseLastValue="0"/>
    <field name="spec_2" reuseLastValue="0"/>
    <field name="spec_3" reuseLastValue="0"/>
    <field name="spec_4" reuseLastValue="0"/>
    <field name="spec_5" reuseLastValue="0"/>
    <field name="spec_6" reuseLastValue="0"/>
    <field name="spec_7" reuseLastValue="0"/>
    <field name="stack" reuseLastValue="0"/>
    <field name="startfeat" reuseLastValue="0"/>
    <field name="status" reuseLastValue="0"/>
    <field name="subplace" reuseLastValue="0"/>
    <field name="subtype4" reuseLastValue="0"/>
    <field name="subtype5" reuseLastValue="0"/>
    <field name="subtype7" reuseLastValue="0"/>
    <field name="subtype_1" reuseLastValue="0"/>
    <field name="subtype_2" reuseLastValue="0"/>
    <field name="subtype_3" reuseLastValue="0"/>
    <field name="subtype_6" reuseLastValue="0"/>
    <field name="type_1" reuseLastValue="0"/>
    <field name="type_2" reuseLastValue="0"/>
    <field name="type_3" reuseLastValue="0"/>
    <field name="type_4" reuseLastValue="0"/>
    <field name="type_5" reuseLastValue="0"/>
    <field name="type_6" reuseLastValue="0"/>
    <field name="type_7" reuseLastValue="0"/>
    <field name="zone_no" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"Label"</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
