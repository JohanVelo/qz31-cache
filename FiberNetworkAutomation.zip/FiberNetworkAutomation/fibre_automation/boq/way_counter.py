"""way_counter — HeroTel pole hook-way counter (bundled).

Counts the 1-Way / 2-Way / 3-Way hook fittings a pole needs from the backbone
cable topology, so the BOQ Hooks quantities can be QA'd (and, opt-in, auto-filled)
instead of relying only on JJ's hand-fill.

The rule (proven against Malmesbury's 798 hand-filled poles at 95.7% per-pole,
prototype `connectivity_probe2.py` + `analyze_conn2.py`):

  * BACKBONE ONLY — Distribution Cable + feeder. Drops are excluded on purpose
    (they'd swamp every pole).
  * A pole "lies on" a cable when it is within TOL (3 m) of the cable line — the
    pole sits ON the route, not merely near a vertex.
  * At each pole a cable is TERMINATING if the pole is within TOL of one of the
    cable's two end-vertices, else it is a PASS-THROUGH.
  * arms = 1·term + 2·thru.  arms 0 -> blank, 1 -> 1-Way (dead-end),
    3 -> 3-Way (T-junction, JJ's locked decision), else the through count is the
    2-Way count.

Two public surfaces:
  * qa_report(project)      -> READ-ONLY. Manual-vs-geometry diff + totals. The
                               checker JJ approved for now.
  * fill_blank_ways(project)-> OPT-IN writer, blank/new poles only, backup-first.
                               Built but must NOT be run until JJ approves and a
                               stress harness exists.

Design rules match boq/: read-only by default, loose layer lookup (stray
'Trenching ' spaces), NULL-safe numeric parsing, no degrees trap needed here
because the arm test is a pure geometric distance in the layer's own CRS.
"""
# claude:intent MUTATE-capable but NOT invoked here — user asked (verbatim): "go on
# the auto-way-counter". Per memory JJ approved building BOTH the read-only checker
# AND an opt-in fill. fill_blank_ways() below CONTAINS a provider write, but it is
# defined-not-called: it defaults to dry_run=True, is wired to no button, and must
# not run on live data until JJ signs off + research/way_counter_verify/ proves it.
# The engine + qa_report used now are strictly READ-ONLY.

# Backbone cable layers whose topology drives the ways. Drops deliberately excluded.
_BACKBONE = ("Distribution Cable", "feeder")
_WAYS = ("1 Way", "2 Way", "3 Way")

# 1 degree ~= 111320 m at the equator; Malmesbury layers are geographic (EPSG:4326),
# so a metre tolerance is expressed in degrees. _tol_for() adapts per CRS so a
# projected (metre) layer gets a plain-metre tolerance instead.
_DEG_PER_M = 1.0 / 111320.0
_TOL_M = 3.0


# ── layer / value helpers (mirror herotel_boq._layer / _fnum) ──────────────────
def _layer(project, name):
    """Loose lookup: exact (stripped, case-insensitive) then substring."""
    want = str(name).strip().lower()
    for lyr in project.mapLayers().values():
        if lyr.name().strip().lower() == want:
            return lyr
    for lyr in project.mapLayers().values():
        if want in lyr.name().strip().lower():
            return lyr
    return None


def _num(v):
    """Int from a possibly-NULL / ',' attribute; 0 on blank or failure."""
    try:
        from qgis.core import NULL
        if v is NULL or v == NULL:
            return 0
    except Exception:
        pass
    if v is None or (isinstance(v, str) and v.strip() == ""):
        return 0
    try:
        return int(float(str(v).replace(",", ".")))
    except (TypeError, ValueError):
        return 0


def _is_blank(v):
    """True when the attribute holds no value (NULL / None / '')."""
    try:
        from qgis.core import NULL
        if v is NULL or v == NULL:
            return True
    except Exception:
        pass
    return v is None or (isinstance(v, str) and v.strip() == "")


def _looks_geographic(layer):
    """CRS check with a safe default (Malmesbury is 4326 -> degrees)."""
    try:
        return layer is not None and layer.crs().isGeographic()
    except Exception:
        return True


def _tol_for(layer, tol_m=_TOL_M):
    """Tolerance in the layer's own map units: tol_m as degrees for a geographic
    CRS, else plain metres for a projected CRS."""
    return tol_m * _DEG_PER_M if _looks_geographic(layer) else tol_m


# ── the pure rule (byte-faithful to the validated prototype) ───────────────────
def _predict_ways(term, thru):
    """Predicted (1-Way, 2-Way, 3-Way) counts from arm topology.

    IDENTICAL to the prototype `predict()` that scored 95.7% — do not "improve" it
    or the validated agreement drifts:

        arms = term + 2*thru
        arms 0 -> (0,0,0)    nothing on the pole
        arms 1 -> (1,0,0)    dead-end            = one 1-Way
        arms 3 -> (0,0,1)    T-junction          = one 3-Way   (JJ: T = 3-Way)
        else   -> (0,thru,0) if any pass-through else (term,0,0)
    """
    term = max(0, int(term))
    thru = max(0, int(thru))
    arms = term + 2 * thru
    if arms == 0:
        return (0, 0, 0)
    if arms == 1:
        return (1, 0, 0)
    if arms == 3:
        return (0, 0, 1)
    return (0, thru, 0) if thru else (term, 0, 0)


# ── backbone spatial index ─────────────────────────────────────────────────────
def _backbone_cables(project):
    """Return (cables, index) where cables[i] = (line_geom, (end0_geom, end1_geom))
    for every backbone cable part, and index is a QgsSpatialIndex over them."""
    from qgis.core import QgsSpatialIndex, QgsFeature, QgsGeometry, QgsPointXY
    cables, index, cid = [], QgsSpatialIndex(), 0
    for lname in _BACKBONE:
        lyr = _layer(project, lname)
        if lyr is None:
            continue
        for feat in lyr.getFeatures():
            g = feat.geometry()
            if not g or g.isEmpty():
                continue
            parts = g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]
            for pr in parts:
                if len(pr) < 2:
                    continue
                geom = QgsGeometry.fromPolylineXY([QgsPointXY(v) for v in pr])
                ends = (QgsGeometry.fromPointXY(QgsPointXY(pr[0])),
                        QgsGeometry.fromPointXY(QgsPointXY(pr[-1])))
                ft = QgsFeature(cid)
                ft.setGeometry(geom)
                index.addFeature(ft)
                cables.append((geom, ends))
                cid += 1
    return cables, index


def _pole_arms(pole_geom, cables, index, tol):
    """(term, thru) for one pole: backbone cables it lies on, split end vs interior."""
    from qgis.core import QgsGeometry, QgsPointXY, QgsRectangle
    if not pole_geom or pole_geom.isEmpty():
        return 0, 0
    pt = (pole_geom.asPoint() if not pole_geom.isMultipart()
          else pole_geom.asMultiPoint()[0])
    pg = QgsGeometry.fromPointXY(QgsPointXY(pt))
    bb = QgsRectangle(pt.x() - tol, pt.y() - tol, pt.x() + tol, pt.y() + tol)
    term = thru = 0
    for cid in index.intersects(bb):
        geom, ends = cables[cid]
        if pg.distance(geom) > tol:
            continue
        if pg.distance(ends[0]) <= tol or pg.distance(ends[1]) <= tol:
            term += 1
        else:
            thru += 1
    return term, thru


# ── core read-only pass ────────────────────────────────────────────────────────
def count_pole_ways(project, tol_m=_TOL_M):
    """Read-only. One record per pole:

        {fid, name, manual:(m1,m2,m3), geom:(term,thru,arms),
         predict:(p1,p2,p3), match:bool, has_manual:bool, on_backbone:bool}
    """
    poles = _layer(project, "poles")
    if poles is None:
        return []
    fld = [f.name() for f in poles.fields()]
    ways = [w for w in _WAYS if w in fld]
    name_f = "Name." if "Name." in fld else ("Name" if "Name" in fld else None)

    cables, index = _backbone_cables(project)
    tol = _tol_for(poles, tol_m)

    out = []
    for feat in poles.getFeatures():
        term, thru = _pole_arms(feat.geometry(), cables, index, tol)
        p1, p2, p3 = _predict_ways(term, thru)
        if ways:
            m = [_num(feat[w]) for w in ways]
            has_manual = any(not _is_blank(feat[w]) for w in ways)
        else:
            m, has_manual = [0, 0, 0], False
        m1, m2, m3 = (m + [0, 0, 0])[:3]
        out.append({
            "fid": feat.id(),
            "name": (str(feat[name_f]) if name_f else str(feat.id())),
            "manual": (m1, m2, m3),
            "geom": (term, thru, term + 2 * thru),
            "predict": (p1, p2, p3),
            "match": (m1, m2, m3) == (p1, p2, p3),
            "has_manual": has_manual,
            "on_backbone": (term + thru) > 0,
        })
    return out


def qa_report(project, tol_m=_TOL_M):
    """Read-only checker. Manual-vs-geometry summary + the mismatching poles.

    Returns:
        {n_poles, ways_present, manual_totals, predicted_totals,
         exact_match, exact_pct, n_blank, n_no_backbone, n_fillable,
         mismatches:[{name, manual, predict, geom}], findings:[(sev,msg)]}
    """
    recs = count_pole_ways(project, tol_m=tol_m)
    n = len(recs)
    findings = []
    poles = _layer(project, "poles")
    ways_present = poles is not None and all(
        w in [f.name() for f in poles.fields()] for w in _WAYS)
    if poles is None:
        findings.append(("BLOCK", "No 'poles' layer found — nothing to check."))
    elif not ways_present:
        findings.append(("WARN", "poles layer is missing one of the "
                                 "1 Way / 2 Way / 3 Way fields."))

    man = tuple(sum(r["manual"][i] for r in recs) for i in range(3))
    pred = tuple(sum(r["predict"][i] for r in recs) for i in range(3))
    exact = sum(1 for r in recs if r["match"])
    n_blank = sum(1 for r in recs if not r["has_manual"])
    n_no_bb = sum(1 for r in recs if not r["on_backbone"])
    mism = [{"name": r["name"], "manual": r["manual"],
             "predict": r["predict"], "geom": r["geom"]}
            for r in recs if not r["match"]]

    if n and exact < n:
        findings.append(("INFO", f"{n - exact}/{n} poles differ between the "
                                 "hand-filled ways and the geometry — review the "
                                 "mismatch list before trusting the Hooks totals."))
    if man != pred:
        findings.append(("INFO",
                         f"Hooks totals: manual {man} vs geometry {pred}."))
    fillable = [r for r in recs if not r["has_manual"] and r["on_backbone"]]
    if fillable:
        findings.append(("INFO", f"{len(fillable)} pole(s) sit on backbone cable "
                                 "but have blank ways — candidates for auto-fill."))

    return {
        "n_poles": n,
        "ways_present": ways_present,
        "manual_totals": man,
        "predicted_totals": pred,
        "exact_match": exact,
        "exact_pct": round(100.0 * exact / n, 1) if n else 0.0,
        "n_blank": n_blank,
        "n_no_backbone": n_no_bb,
        "n_fillable": len(fillable),
        "mismatches": mism,
        "findings": findings,
    }


# ── dead-ends by cable size (read-only) ────────────────────────────────────────
# A D/END fitting is needed per cable arm at a pole (a terminating cable = 1 arm,
# a pass-through = 2), sized by that cable's fibre count. Bins mirror the HeroTel
# D/END SKU rows in the template.
_DEND_SKU = {"12F": "18/24/36F", "18F": "18/24/36F", "24F": "18/24/36F",
             "36F": "18/24/36F", "48F": "48F", "72F": "72F", "96F": "96F",
             "144F": "144F"}


def dend_sku_of(size):
    """The D/END SKU bin a cable size falls in (identity for an unknown size)."""
    s = str(size).strip()
    return _DEND_SKU.get(s, s)


def _size_backbone_index(project):
    """Build a size-aware spatial index over backbone cable parts.

    Returns (cables, index) where cables[i] = (line_geom, (end0, end1), size).
    Shared by deadend_arms_per_pole so the arm/size logic lives in one place.
    """
    from qgis.core import QgsSpatialIndex, QgsFeature, QgsGeometry, QgsPointXY
    cables, index, cid = [], QgsSpatialIndex(), 0
    for lname in _BACKBONE:
        lyr = _layer(project, lname)
        if lyr is None:
            continue
        has_size = "Cable Size" in [f.name() for f in lyr.fields()]
        for feat in lyr.getFeatures():
            g = feat.geometry()
            if not g or g.isEmpty():
                continue
            size = str(feat["Cable Size"]).strip() if has_size else "?"
            parts = g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]
            for pr in parts:
                if len(pr) < 2:
                    continue
                geom = QgsGeometry.fromPolylineXY([QgsPointXY(v) for v in pr])
                ends = (QgsGeometry.fromPointXY(QgsPointXY(pr[0])),
                        QgsGeometry.fromPointXY(QgsPointXY(pr[-1])))
                ft = QgsFeature(cid)
                ft.setGeometry(geom)
                index.addFeature(ft)
                cables.append((geom, ends, size))
                cid += 1
    return cables, index


def deadend_arms_per_pole(project, tol_m=_TOL_M):
    """Read-only. Dead-End arms per pole, keyed by cable size:

        {fid: {'24F': arms, '96F': arms, ...}, ...}

    A cable terminating at the pole contributes 1 arm; a pass-through contributes 2.
    Only poles that carry at least one backbone arm appear. This is the per-feature
    source the phased BOQ buckets by phase (each pole → exactly one phase, so the
    per-phase dead-ends sum back to the whole)."""
    from qgis.core import QgsGeometry, QgsPointXY, QgsRectangle
    poles = _layer(project, "poles")
    if poles is None:
        return {}
    cables, index = _size_backbone_index(project)
    tol = _tol_for(poles, tol_m)
    out = {}
    for feat in poles.getFeatures():
        pgm = feat.geometry()
        if not pgm or pgm.isEmpty():
            continue
        pt = pgm.asPoint() if not pgm.isMultipart() else pgm.asMultiPoint()[0]
        pg = QgsGeometry.fromPointXY(QgsPointXY(pt))
        bb = QgsRectangle(pt.x() - tol, pt.y() - tol, pt.x() + tol, pt.y() + tol)
        per_size = {}
        for i in index.intersects(bb):
            geom, ends, size = cables[i]
            if pg.distance(geom) > tol:
                continue
            is_end = (pg.distance(ends[0]) <= tol or pg.distance(ends[1]) <= tol)
            per_size[size] = per_size.get(size, 0) + (1 if is_end else 2)
        if per_size:
            out[feat.id()] = per_size
    return out


def by_size_to_sku(by_size):
    """Fold a {size: arms} map into {D/END SKU: arms} via dend_sku_of."""
    by_sku = {}
    for size, n in by_size.items():
        sku = dend_sku_of(size)
        by_sku[sku] = by_sku.get(sku, 0) + n
    return by_sku


def deadends_by_sku(project, tol_m=_TOL_M):
    """Read-only. Dead-End (D/END) counts per cable-size SKU from arm topology.

    Returns:
        {by_size:{'24F':n,...}, by_dend_sku:{'18/24/36F':n,...}, geometry_total,
         hook_formula_total, gap_vs_formula}
    geometry_total = Σ arms (term + 2·thru) over all poles.
    hook_formula_total = 1·Σ1W + 2·Σ2W + 3·Σ3W from the MANUAL hook fields (this is
    what the template's Dead-End total formula computes). gap = geometry - formula.

    Built on deadend_arms_per_pole so the per-pole (phase-bucketable) view and this
    project-wide aggregate can never diverge.
    """
    poles = _layer(project, "poles")
    if poles is None:
        return {"by_size": {}, "by_dend_sku": {}, "geometry_total": 0,
                "hook_formula_total": 0, "gap_vs_formula": 0}

    per_pole = deadend_arms_per_pole(project, tol_m=tol_m)
    by_size = {}
    for sizes in per_pole.values():
        for size, n in sizes.items():
            by_size[size] = by_size.get(size, 0) + n
    by_sku = by_size_to_sku(by_size)

    # manual hook-formula total (what the template's Dead-End total cell computes)
    fld = [f.name() for f in poles.fields()]
    ways = [w for w in _WAYS if w in fld]
    tot = {w: 0 for w in _WAYS}
    for feat in poles.getFeatures():
        for w in ways:
            tot[w] += _num(feat[w])
    formula = tot["1 Way"] * 1 + tot["2 Way"] * 2 + tot["3 Way"] * 3
    geom_total = sum(by_size.values())
    return {"by_size": by_size, "by_dend_sku": by_sku,
            "geometry_total": geom_total, "hook_formula_total": formula,
            "gap_vs_formula": geom_total - formula}


# ── OPT-IN writer — DO NOT RUN until JJ approves + a stress harness exists ──────
def fill_blank_ways(project, only_blank=True, backup=True, tol_m=_TOL_M,
                    dry_run=True):
    """OPT-IN. Write predicted ways into poles. Defaults are deliberately safe:
    only_blank=True writes ONLY poles whose ways are all blank; dry_run=True
    changes nothing and just reports what it *would* write.

    Uses the provider bulk-write API (never per-feature edits) per the algorithm
    rules. Backs up the current 1/2/3-Way values into a private '_vf_ways_bak'
    field first so an undo is always possible.

    Returns {changed, skipped, dry_run, backup_field}.
    NOT WIRED to any button. Must not be called on live data until JJ signs off
    and research/way_counter_verify/ proves it (see the Stress Gate).
    """
    poles = _layer(project, "poles")
    if poles is None:
        return {"changed": 0, "skipped": 0, "dry_run": dry_run,
                "error": "no poles layer"}
    fld = [f.name() for f in poles.fields()]
    ways = [w for w in _WAYS if w in fld]
    if len(ways) != 3:
        return {"changed": 0, "skipped": 0, "dry_run": dry_run,
                "error": "poles layer missing a ways field"}

    recs = {r["fid"]: r for r in count_pole_ways(project, tol_m=tol_m)}
    idx = {w: poles.fields().indexOf(w) for w in ways}

    changed = skipped = 0
    attr_map = {}
    for feat in poles.getFeatures():
        r = recs.get(feat.id())
        if r is None:
            continue
        if only_blank and r["has_manual"]:
            skipped += 1
            continue
        if r["predict"] == r["manual"]:
            skipped += 1
            continue
        attr_map[feat.id()] = {idx[w]: r["predict"][i] for i, w in enumerate(ways)}
        changed += 1

    if dry_run or not attr_map:
        return {"changed": changed, "skipped": skipped, "dry_run": dry_run,
                "backup_field": None}

    # real write path (only reached when a caller explicitly passes dry_run=False)
    backup_field = _ensure_backup_field(poles, recs) if backup else None
    ok = poles.dataProvider().changeAttributeValues(attr_map)
    if hasattr(poles, "triggerRepaint"):
        poles.triggerRepaint()
    return {"changed": changed if ok else 0, "skipped": skipped,
            "dry_run": False, "backup_field": backup_field, "ok": bool(ok)}


def _ensure_backup_field(poles, recs):
    """Stash 'm1|m2|m3' per pole into a private text field so a fill is undoable."""
    from qgis.core import QgsField
    from qgis.PyQt.QtCore import QMetaType
    fname = "_vf_ways_bak"
    if fname not in [f.name() for f in poles.fields()]:
        poles.dataProvider().addAttributes(
            [QgsField(fname, QMetaType.Type.QString)])
        poles.updateFields()
    fi = poles.fields().indexOf(fname)
    amap = {}
    for feat in poles.getFeatures():
        r = recs.get(feat.id())
        m = r["manual"] if r else (0, 0, 0)
        amap[feat.id()] = {fi: "|".join(str(x) for x in m)}
    poles.dataProvider().changeAttributeValues(amap)
    return fname
