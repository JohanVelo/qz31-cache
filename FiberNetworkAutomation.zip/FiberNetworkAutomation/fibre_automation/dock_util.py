try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

# -*- coding: utf-8 -*-
"""Shared dock opener — every plugin panel opens natively in QGIS.

QMainWindow owns the dock from the moment ``addDockWidget`` returns.  There is no
deferred callback and no programmatic float/re-show cycle, so plugin hot reload
cannot leave old code touching a deleted QDockWidget.

Qt6/Qt5-safe: Qt via the qgis.PyQt shim, fully-scoped enums, no QGIS work at
import time (everything is inside the function).
"""

__all__ = ["dock_fully"]


def dock_fully(iface, dock, area=None, width=440, prefer_float=False):
    """Register a QDockWidget with QGIS and give its docked edge a width hint.

    iface        : QgisInterface (its mainWindow hosts the dock).
    dock         : the QDockWidget to open.
    area         : Qt.DockWidgetArea; defaults to the right edge.
    width        : docked width hint (metres of pixels); full height is automatic
                   for a side dock.
    ``prefer_float`` remains in the public signature for old callers but is
    intentionally ignored. Floating is now an operator action through Qt's native
    title bar, never a startup side effect. Returns ``dock`` for chaining.
    """
    from qgis.PyQt.QtCore import Qt
    if area is None:
        area = Qt.DockWidgetArea.RightDockWidgetArea
    try:
        iface.addDockWidget(area, dock)
    except Exception:
        return dock
    # Side docks size by width (full height is automatic); top/bottom docks size
    # by height. This is synchronous and leaves floating/docking entirely to Qt.
    try:
        horizontal = area not in (
            Qt.DockWidgetArea.TopDockWidgetArea,
            Qt.DockWidgetArea.BottomDockWidgetArea,
        )
        orientation = (
            Qt.Orientation.Horizontal if horizontal else Qt.Orientation.Vertical
        )
        main_window = iface.mainWindow()
        if main_window is not None:
            main_window.resizeDocks(
                [dock], [max(int(width), 360)], orientation
            )
    except Exception:
        _swallowed_note()
    return dock
