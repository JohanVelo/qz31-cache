"""Evidence-bound legacy interpretations, never global material substitutions."""
from pathlib import PureWindowsPath
import re

from .model import INPUT_ROWS
from .mapping import normalise, number


MALMESBURY_PROJECTS = frozenset(('Malmsbury Herotel V4', 'Malmesbury Herotel V4'))
MALMESBURY_POLE_FIELDS = frozenset(('Type', 'Pole Size', '1 Way', '2 Way',
                                   '3 Way', '12/24 Dead', '96 Dead'))
HEIGHT_AUTHORITY = ('JJ confirmed 2026-09-12: Malmesbury 5m means BOQ 5.4m; '
                    '7m means BOQ 7.2m. Source attributes and diameter preserved.')
SEAL_AUTHORITY = ('Malmesbury reference workbook SHA256 '
                  '0ee4c744be5373c7c436bef01b22c9a13eaa0717a5eae31f08cefa534be8fc7f, '
                  'Malmesbury Master BOQ F30:F31: one of each mechanical seal per FD4.')
CABLE_AUTHORITY = ('Malmesbury V4 legacy cable profile: Tlenght route metres plus '
                   'Slenght slack metres; all 92 source routes independently measured '
                   '2026-09-12. Exact DC/FC/LC label and capacity checks; BH backhaul excluded. '
                   'Current source quantities, no reference-workbook adjustments.')
DEMAND_AUTHORITY = ('Malmesbury reference workbook SHA256 '
                    '0ee4c744be5373c7c436bef01b22c9a13eaa0717a5eae31f08cefa534be8fc7f, '
                    'Malmesbury Master BOQ A15/C15:E15: Demand Points, whole recorded '
                    'point population including non-SDU types; not an inferred household count.')


def pole_height_authority(snapshot, layer):
    """Require exact project, local container and legacy pole schema identity.

    The profile carries semantics, not historic quantities or customer paths.
    It does not authorize any diameter substitution or resolve missing hardware.
    """
    if snapshot.project not in MALMESBURY_PROJECTS or layer.name != 'poles':
        return ''
    source = PureWindowsPath(layer.source.split('|', 1)[0])
    if source.suffix.lower() != '.gpkg' or source.stem != snapshot.project:
        return ''
    if not MALMESBURY_POLE_FIELDS.issubset(layer.fields):
        return ''
    return HEIGHT_AUTHORITY


def interpreted_height(height, authority):
    return {5.0: 5.4, 7.0: 7.2}.get(height, height) if authority else height


def seal_authority(snapshot, layer):
    if snapshot.project not in MALMESBURY_PROJECTS or layer.name not in ('16 Way splitter', 'Dome Joints'):
        return ''
    source = PureWindowsPath(layer.source.split('|', 1)[0])
    if source.suffix.lower() != '.gpkg' or source.stem != snapshot.project:
        return ''
    required = {'Type', 'Splitters'} if layer.name == '16 Way splitter' else {'Type'}
    if not required.issubset(layer.fields):
        return ''
    return SEAL_AUTHORITY


def automatic_profile_supported(snapshot):
    """A title alone cannot bypass source review for an unrelated population."""
    if snapshot.project not in MALMESBURY_PROJECTS or not snapshot.layers:
        return False
    containers = {str(PureWindowsPath(layer.source.split('|', 1)[0])).casefold()
                  for layer in snapshot.layers}
    if len(containers) != 1:
        return False
    source = PureWindowsPath(snapshot.layers[0].source.split('|', 1)[0])
    if source.suffix.lower() != '.gpkg' or source.stem != snapshot.project:
        return False
    explicit = {f'BOQ {row}' for row in INPUT_ROWS}
    return any(pole_height_authority(snapshot, layer) or explicit.issubset(layer.fields)
               for layer in snapshot.layers)


def cable_population(snapshot, layers):
    """Return exact record classifications only for the complete legacy pair."""
    if snapshot.project not in MALMESBURY_PROJECTS or len(layers) != 2:
        return None
    if {layer.name for layer in layers} != {'Distribution Cable', 'feeder'}:
        return None
    sources = {str(PureWindowsPath(layer.source.split('|', 1)[0])).casefold() for layer in layers}
    if len(sources) != 1:
        return None
    result = {}
    for layer in layers:
        source = PureWindowsPath(layer.source.split('|', 1)[0])
        required = {'Name', 'Feeder Cab', 'Cable Size', 'Tlenght', 'Slenght'}
        if source.stem != snapshot.project or source.suffix.lower() != '.gpkg' or not required.issubset(layer.fields) or not layer.records:
            return None
        conflicting = {'routelengthm','lengthm','routelength','length','slackm','slack',
                       'installedlengthm','totallength','lengthunit','lengthunits',
                       'cablerole','networkrole','installation','installationtype','cabletype'}
        if {normalise(field) for field in layer.fields} & conflicting:
            return None  # Additional semantics require the normal ambiguity checks.
        classifications = set()
        for record in layer.records:
            values = record.values
            label = str(values.get('Name', ''))
            match = re.fullmatch(r'HT_MMB_(DC|FC|LC|BH)(\d{2})_(12|24|48|72|96|144)F(?:_(Aerial|Aeriel))?', label)
            if not match or values.get('Feeder Cab') != match[1]+match[2] or values.get('Cable Size') != match[3]+'F':
                return None
            if (layer.name == 'Distribution Cable' and (match[1] != 'DC' or match[3] != '24' or match[4] != 'Aerial')) or (
                    layer.name == 'feeder' and match[1] not in ('FC','LC','BH')):
                return None
            if match[1] == 'BH':
                continue
            if not match[4]:
                return None
            try:
                number(values.get('Tlenght'), unit='m')
                number(values.get('Slenght'), unit='m')
            except ValueError:
                return None
            classifications.add((int(match[3]), label))
        result[layer.identity] = classifications
    return result


def demand_point_authority(snapshot, layer):
    if snapshot.project not in MALMESBURY_PROJECTS or layer.name != 'Demand points':
        return ''
    source=PureWindowsPath(layer.source.split('|',1)[0])
    if source.stem != snapshot.project or source.suffix.lower() != '.gpkg' or 'Type' not in layer.fields:
        return ''
    known={'SDU','FTTB','Church','Non-Connectable','School'}
    if not layer.records or any(record.values.get('Type') not in known for record in layer.records):
        return ''
    return DEMAND_AUTHORITY
