﻿"""one_building_per_erf — reduce detected buildings to ONE per surveyed erf (the main/largest).

For each cadastral stand, keep only the largest building footprint; delete the rest. Buildings that
fall outside every stand (e.g. only inside a large RE/remainder parcel, or beyond cadastral coverage)
are kept as-is. Assignment uses the SMALLEST containing erf so nested RE-parcels don't swallow a block.

Usage (qgis-venv):
  python one_building_per_erf.py --buildings C:/Temp/detected_buildings.geojson \
      --erven "C:/Users/jjsch/OneDrive/ON LAPTOP FIBRE/QGIS test/Vuma_MOA_Test/Erven.shp" \
      --out C:/Temp/buildings_primary.geojson [--stand-max 2000] [--stand-min 20]
"""
import argparse
import sys

import geopandas as gpd
import pandas as pd

UTM = 32735  # UTM 35S — metric for SA


def cull_one_per_erf(buildings, erven, stand_min=20.0, stand_max=2000.0,
                     drop_standalone=False):
    """Reduce buildings to one (largest) per surveyed stand.

    buildings/erven : GeoDataFrame or path. Returns a GeoDataFrame (EPSG:4326).
    Buildings outside every stand are kept unless drop_standalone=True.
    """
    b = (gpd.read_file(buildings) if isinstance(buildings, str) else buildings.copy()).to_crs(UTM)
    e = (gpd.read_file(erven) if isinstance(erven, str) else erven.copy()).to_crs(UTM)
    b = b[b.geometry.notna() & ~b.geometry.is_empty].reset_index(drop=True)
    e = e[e.geometry.notna() & ~e.geometry.is_empty].copy()
    e["_erf_area"] = e.geometry.area
    print(f"[cull] {len(b)} buildings, {len(e)} erven")

    # only real residential STANDS get the one-per-erf rule
    stands = e[(e["_erf_area"] >= stand_min) & (e["_erf_area"] <= stand_max)].copy()
    stands = stands.reset_index(drop=True)
    stands["_stand_id"] = stands.index
    print(f"[cull] {len(stands)} stands in [{stand_min:.0f},{stand_max:.0f}] m^2")

    b["_bld_id"] = b.index
    b["_bld_area"] = b.geometry.area
    pts = b.copy()
    pts["geometry"] = b.geometry.representative_point()   # robust for odd footprints

    j = gpd.sjoin(pts[["_bld_id", "geometry"]], stands[["_stand_id", "_erf_area", "geometry"]],
                  how="left", predicate="within")
    # a point may fall in several nested erven -> keep the SMALLEST (the actual stand)
    j = j.sort_values("_erf_area").drop_duplicates("_bld_id", keep="first")
    b = b.merge(j[["_bld_id", "_stand_id"]], on="_bld_id", how="left")

    in_stand = b[b["_stand_id"].notna()].copy()
    no_stand = b[b["_stand_id"].isna()].copy()
    keep_idx = in_stand.loc[in_stand.groupby("_stand_id")["_bld_area"].idxmax(), "_bld_id"]
    primary_in = in_stand[in_stand["_bld_id"].isin(keep_idx)]
    print(f"[cull] in-stand: {len(in_stand)} -> {len(primary_in)} primaries  (dropped {len(in_stand)-len(primary_in)})")
    print(f"[cull] outside any stand: {len(no_stand)} ({'dropped' if drop_standalone else 'kept'})")

    parts = [primary_in] if drop_standalone else [primary_in, no_stand]
    out = pd.concat(parts, ignore_index=True)
    out = out.drop(columns=[c for c in ("_bld_id", "_bld_area", "_stand_id") if c in out.columns])
    out["is_primary"] = 1
    return out.set_geometry("geometry").to_crs(4326)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--buildings", required=True)
    ap.add_argument("--erven", required=True)
    ap.add_argument("--out", default="C:/Temp/buildings_primary.geojson")
    ap.add_argument("--stand-max", type=float, default=2000.0,
                    help="erf area (m^2) above this is a remainder/parent parcel, not a stand")
    ap.add_argument("--stand-min", type=float, default=20.0)
    ap.add_argument("--drop-standalone", action="store_true",
                    help="also drop buildings that fall outside every surveyed stand")
    args = ap.parse_args()

    out = cull_one_per_erf(args.buildings, args.erven, args.stand_min, args.stand_max,
                           args.drop_standalone)
    if len(out) == 0:
        print("[cull] nothing to write"); sys.exit(2)
    out.to_file(args.out, driver="GeoJSON")
    print(f"[cull] WROTE {args.out}  ({len(out)} buildings)")


if __name__ == "__main__":
    main()
