"""swallowed — make a deliberately-ignored exception visible without changing behaviour.

Call it as the body of a handler that used to be a bare `pass`:

    try:
        provider.changeAttributeValues(updates)
    except Exception:
        note()

The handler still swallows the error (the code path is unchanged), but the first
time each call site swallows something in a session, one Warning line naming the
site and the exception goes to the QGIS message log under 'Velocity Nexus'. Later
hits at the same site are only counted, so a per-feature loop cannot flood the log.

Deliberately NOT Critical and NOT sent anywhere: error_capture forwards Critical
log lines to the team errors table, and these are errors the code chose to ignore.
Never raises.
"""
import sys

_TAG = 'Velocity Nexus'
_counts = {}   # (filename, lineno) -> times swallowed this session


def note(context=''):
    """Record the exception currently being handled. Safe outside a handler."""
    try:
        exc = sys.exc_info()[1]
        frame = sys._getframe(1)
        site = (frame.f_code.co_filename, frame.f_lineno)
        n = _counts.get(site, 0) + 1
        _counts[site] = n
        if n != 1 or exc is None:
            return
        name = site[0].replace('\\', '/').rsplit('/', 1)[-1]
        msg = (f'swallowed at {name}:{site[1]} in {frame.f_code.co_name}(): '
               f'{type(exc).__name__}: {str(exc)[:200]}'
               + (f' [{context}]' if context else '')
               + ' (further hits at this line are counted, not logged)')
        try:
            from qgis.core import Qgis, QgsMessageLog
            QgsMessageLog.logMessage(msg, _TAG, Qgis.MessageLevel.Warning)
        except Exception:
            print('[Velocity Nexus] ' + msg)
    except Exception:
        pass


def counts():
    """{'file.py:line': times swallowed} for this session - for the health panel/tests."""
    return {f"{f.replace(chr(92), '/').rsplit('/', 1)[-1]}:{ln}": n for (f, ln), n in _counts.items()}
