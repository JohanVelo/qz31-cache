# -*- coding: utf-8 -*-
"""Route-order numbering for a plotting grid (FTTS model, 2026-10-28). Pure Python - no
QGIS imports - so the rule is testable with Hypothesis and provable against the two hand-
numbered FTTS books (Mafikeng 12 pages, Mkhulu 3).

The rule, as JJ numbers a book by hand:
  * build a graph from the network LINE layers the grid covers (lines join where an end
    touches another line - at its end, at a vertex, or part-way along a segment);
  * start at the westmost line end and walk the network depth-first;
  * at a fork, finish the shorter branch first (the branch whose reachable cable is
    shortest), then come back for the next;
  * a block is numbered the first time the walk enters it;
  * blocks no line touches go last, left to right (then top to bottom).

Only the ORDER of the cells changes. Which cells print is decided before this runs
(grid_skip_empty_cells, the export dialog), and the engine numbers them 1..N afterwards
exactly as it always has - so "rows" order (the default) is untouched by this module.
"""
import bisect
import math

ORDER_ROWS = "rows"      # today's behaviour: top row first, left to right
ORDER_ROUTE = "route"    # FTTS: follow the cable


def name_tokens(name):
    """Lower-case word tokens of a layer name: split on punctuation and camelCase.
    'Street Names' -> {street, names} · 'Mafikeng_Erven_Streets' -> {mafikeng, erven, streets}."""
    import re
    spaced = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", str(name or ""))
    return {t for t in re.split(r"[^A-Za-z0-9]+", spaced.lower()) if t}


def name_excluded(name, patterns):
    """Does the layer name carry one of the exclusion words (whole tokens, any case)?
    The same rule the engine applies to grid content and legend rows, so the export
    dialog and the build can never disagree about which layers count."""
    if not patterns:
        return False
    toks = name_tokens(name)
    return any(str(pat).strip().lower() in toks for pat in patterns if str(pat).strip())


# ── geometry helpers ─────────────────────────────────────────────────────────
def _dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def _poly_len(pts):
    return sum(_dist(pts[i], pts[i + 1]) for i in range(len(pts) - 1))


def _project(pt, a, b):
    """(t, distance) of the closest point on segment a-b to pt; t in [0, 1]."""
    ax, ay = a
    bx, by = b
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    if L2 <= 0.0:
        return 0.0, _dist(pt, a)
    t = ((pt[0] - ax) * dx + (pt[1] - ay) * dy) / L2
    t = 0.0 if t < 0.0 else (1.0 if t > 1.0 else t)
    return t, _dist(pt, (ax + t * dx, ay + t * dy))


def _clip_t(p, q, box):
    """Liang-Barsky: the parameter t in [0, 1] where segment p->q first enters the box
    (xmin, ymin, xmax, ymax), or None when it misses. Touching the box counts."""
    x0, y0 = p
    dx, dy = q[0] - x0, q[1] - y0
    t0, t1 = 0.0, 1.0
    for num, den in ((x0 - box[0], dx), (box[2] - x0, -dx),
                     (y0 - box[1], dy), (box[3] - y0, -dy)):
        # inside this half-plane when num + t*den >= 0
        if den == 0.0:
            if num < 0.0:
                return None
            continue
        t = -num / den
        if den > 0.0:                 # moving INTO the half-plane: a lower bound on t
            if t > t1:
                return None
            if t > t0:
                t0 = t
        else:                         # moving OUT of it: an upper bound on t
            if t < t0:
                return None
            if t < t1:
                t1 = t
    if t0 > t1:
        return None
    return t0


def _clean_lines(lines):
    """Drop empty parts and repeated consecutive vertices; keep parts with 2+ distinct points."""
    out = []
    for pts in lines or []:
        clean = []
        for pt in pts or []:
            xy = (float(pt[0]), float(pt[1]))
            if not (math.isfinite(xy[0]) and math.isfinite(xy[1])):
                continue
            if clean and clean[-1] == xy:
                continue
            clean.append(xy)
        if len(clean) >= 2:
            out.append(clean)
    return out


def _default_tol(cells):
    """Snap tolerance: 1% of the smallest cell side (7.75 m on the 775 x 550 m grid)."""
    best = None
    for c in cells:
        w, h = c[2] - c[0], c[3] - c[1]
        for v in (w, h):
            if v > 0 and (best is None or v < best):
                best = v
    return (best * 0.01) if best else 1e-9


# ── graph ────────────────────────────────────────────────────────────────────
class _Nodes(object):
    """Line ends clustered within tol, found through a hash of tol-sized buckets."""

    def __init__(self, tol):
        self.tol = max(float(tol), 1e-12)
        self.pts = []
        self._bucket = {}

    def _key(self, pt):
        return (int(math.floor(pt[0] / self.tol)), int(math.floor(pt[1] / self.tol)))

    def find(self, pt):
        kx, ky = self._key(pt)
        best, best_d = None, None
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for i in self._bucket.get((kx + dx, ky + dy), ()):
                    d = _dist(self.pts[i], pt)
                    if d <= self.tol and (best is None or d < best_d or (d == best_d and i < best)):
                        best, best_d = i, d
        return best

    def add(self, pt):
        i = self.find(pt)
        if i is not None:
            return i
        self.pts.append((float(pt[0]), float(pt[1])))
        i = len(self.pts) - 1
        self._bucket.setdefault(self._key(pt), []).append(i)
        return i


def _split_at_nodes(pts, nodes, tol, xs, xorder):
    """Split one polyline into parts at every node that lies on it (a line end touching
    this line at a vertex or part-way along a segment). Returns [(node_a, node_b, pts)]."""
    start, end = nodes.add(pts[0]), nodes.add(pts[-1])
    cuts = []
    last_seg = len(pts) - 2
    for i in range(len(pts) - 1):
        a, b = pts[i], pts[i + 1]
        lo = bisect.bisect_left(xs, min(a[0], b[0]) - tol)
        hi = bisect.bisect_right(xs, max(a[0], b[0]) + tol)
        for k in range(lo, hi):
            ni = xorder[k]
            t, d = _project(nodes.pts[ni], a, b)
            if d <= tol:
                cuts.append((i, t, ni))
    cuts.sort()
    parts = []
    cur = [pts[0]]
    cur_start = start
    ci = 0
    for i in range(len(pts) - 1):
        b = pts[i + 1]
        while ci < len(cuts) and cuts[ci][0] == i:
            _i, t, ni = cuts[ci]
            ci += 1
            n = nodes.pts[ni]
            if ni == cur_start and _poly_len(cur + [n]) <= tol:
                continue                      # the part's own start, seen again
            if ni == end and i == last_seg and t >= 1.0 - 1e-9:
                continue                      # the line's own end - closed below
            cur.append(n)
            parts.append((cur_start, ni, cur))
            cur = [n]
            cur_start = ni
        cur.append(b)
    if not (cur_start == end and _poly_len(cur) <= tol):
        parts.append((cur_start, end, cur))
    return parts


def _build_graph(lines, tol):
    """Nodes = line ends (clustered within tol); edges = the lines, split wherever a node
    lies on them. Returns (node points, [(a, b, pts, length)])."""
    nodes = _Nodes(tol)
    for pts in lines:
        nodes.add(pts[0])
        nodes.add(pts[-1])
    xorder = sorted(range(len(nodes.pts)), key=lambda i: nodes.pts[i][0])
    xs = [nodes.pts[i][0] for i in xorder]
    edges = []
    for pts in lines:
        n_before = len(edges)
        for a, b, part in _split_at_nodes(pts, nodes, tol, xs, xorder):
            L = _poly_len(part)
            if L > 0.0:
                edges.append((a, b, part, L))
        if len(edges) == n_before and _poly_len(pts) > 0.0:
            # a line shorter than tol collapses to one node; keep it as a loop so the
            # walk still enters the cells it lies in
            n = nodes.add(pts[0])
            edges.append((n, n, list(pts), _poly_len(pts)))
    return nodes.pts, edges


def _adjacency(n_nodes, edges):
    adj = {i: [] for i in range(n_nodes)}
    for ei, (a, b, _pts, _L) in enumerate(edges):
        adj[a].append(ei)
        if b != a:
            adj[b].append(ei)
    return adj


def _far(edge, node):
    return edge[1] if node == edge[0] else edge[0]


def _reach_len(start_edge, from_node, edges, adj, visited):
    """Cable length reachable through `start_edge` (its own length included) without
    using visited edges or coming back through the other edges at `from_node`."""
    blocked = set(visited)
    blocked.update(e for e in adj[from_node] if e != start_edge)
    seen = {start_edge}
    total = edges[start_edge][3]
    stack = [_far(edges[start_edge], from_node)]
    while stack:
        n = stack.pop()
        for e in adj[n]:
            if e in seen or e in blocked:
                continue
            seen.add(e)
            total += edges[e][3]
            stack.append(_far(edges[e], n))
    return total


# ── cells along an edge ──────────────────────────────────────────────────────
def _cells_along(pts, cells, enter):
    """Call enter(cell_index) for every cell the polyline passes through, in the order it
    first reaches them. Exact (segment-box clipping), no sampling."""
    for i in range(len(pts) - 1):
        a, b = pts[i], pts[i + 1]
        sx0, sx1 = min(a[0], b[0]), max(a[0], b[0])
        sy0, sy1 = min(a[1], b[1]), max(a[1], b[1])
        hits = []
        for ci, box in enumerate(cells):
            if sx1 < box[0] or sx0 > box[2] or sy1 < box[1] or sy0 > box[3]:
                continue
            t = _clip_t(a, b, box)
            if t is not None:
                hits.append((t, ci))
        hits.sort()
        for _t, ci in hits:
            enter(ci)


# ── the rule ─────────────────────────────────────────────────────────────────
def route_order(cells, lines, tol=None):
    """Order of `cells` along the network.

    cells: [(xmin, ymin, xmax, ymax), ...] in one CRS; lines: [[(x, y), ...], ...] polyline
    parts in the same CRS (a multipart line = several entries). tol: snap distance in CRS
    units (default 1% of the smallest cell side).

    Returns a list of cell indices (0-based), every cell exactly once: the cells the walk
    enters, in entry order, then every untouched cell left to right, top to bottom.
    """
    cells = [tuple(float(v) for v in c) for c in (cells or [])]
    if not cells:
        return []
    lines = _clean_lines(lines)
    if tol is None:
        tol = _default_tol(cells)
    order = []
    entered = set()

    def enter(ci):
        if ci not in entered:
            entered.add(ci)
            order.append(ci)

    if lines:
        nodes, edges = _build_graph(lines, tol)
        adj = _adjacency(len(nodes), edges)
        visited = set()

        def walk(node):
            # iterative DFS so a long trench chain cannot hit the recursion limit
            stack = [node]
            while stack:
                n = stack[-1]
                pending = [e for e in adj[n] if e not in visited]
                if not pending:
                    stack.pop()
                    continue
                pending.sort(key=lambda e: (_reach_len(e, n, edges, adj, visited),
                                            edges[e][3], e))
                e = pending[0]
                visited.add(e)
                pts = edges[e][2]
                if edges[e][0] != n:
                    pts = list(reversed(pts))
                _cells_along(pts, cells, enter)
                stack.append(_far(edges[e], n))

        while len(visited) < len(edges):
            # westmost end with cable still to walk (next component after the first)
            cand = [i for i in range(len(nodes)) if any(e not in visited for e in adj[i])]
            if not cand:
                break
            start = min(cand, key=lambda i: (nodes[i][0], -nodes[i][1], i))
            walk(start)

    rest = [i for i in range(len(cells)) if i not in entered]
    rest.sort(key=lambda i: ((cells[i][0] + cells[i][2]) / 2.0,
                             -(cells[i][1] + cells[i][3]) / 2.0, i))
    return order + rest


def order_cells(cells, lines, mode=ORDER_ROWS, tol=None):
    """Dispatcher the engine calls: `mode` "rows" returns the cells untouched (the indices
    0..N-1 in the order given), "route" applies route_order. Unknown modes fall back to
    rows so a typo in a model file can never drop a page."""
    n = len(cells or [])
    if mode == ORDER_ROUTE:
        return route_order(cells, lines, tol=tol)
    return list(range(n))
