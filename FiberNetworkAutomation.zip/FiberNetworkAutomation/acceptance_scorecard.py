"""acceptance_scorecard — one client-signable acceptance score for a completed
HLD, composed from the checks the plugin already trusts.

`build_scorecard()` reads the current QGIS project and returns a structured
dict (NO UI here — the plugin wires a dialog / PDF on top).

Design rules:
  • FREEZE-SAFE — every layer is read in a SINGLE pass; no nested O(n·m) loops.
    Safe to call from a quick bridge request or a QgsTask on Mohadin-size data.
  • GROUNDED — every sub-score is computed from real features / real spec
    constants. Nothing is fabricated. A dimension with no data to judge is
    reported as 'not assessed' and dropped from the weighting (never faked).
  • TUNABLE — WEIGHTS, TARGETS and the required-layer list live at the top so
    'acceptance' can be re-defined without touching logic.

Phase-2 spec constants come straight from CLAUDE.md / the master spec.
"""


import re

from qgis.core import QgsProject, QgsDistanceArea, QgsPointXY

# ── Tunables ────────────────────────────────────────────────────────────────
WEIGHTS = {
    "completeness": 0.20,   # all expected layers exist and carry features
    "consistency":  0.20,   # one CRS, no null/duplicate device labels
    "capacity":     0.25,   # ONTs/PON inside the 80–102 target band
    "spec":         0.20,   # PON / zone / DR numbering inside spec ranges
    "power":        0.15,   # Combo-1 optical budget closes across the AOI
}

PON_MIN, PON_MAX       = 235, 298       # Phase-2 PON range
PON_TARGET_LO, PON_HI  = 80, 102        # ONTs per PON (20% spare on 1:128)
PON_HARD_MAX           = 128            # splitter ceiling
DR_MIN, DR_MAX         = 1853300, 1886299
ZONE_BASE              = 17             # zone = (pon-235)//16 + 17

# Layers a finished Phase-2 HLD must contain (resolved by substring, v1-agnostic)
REQUIRED_LAYERS = [
    "Home Connection", "PON", "Zone", "Poles",
    "Drop Cable", "Distribution Cable", "Secondary", "Primary",
    "Splitter", "Enclosure",
]

GRADE_BANDS = [(90, "A"), (80, "B"), (70, "C"), (60, "D")]


# ── Layer helpers (freeze-safe) ──────────────────────────────────────────────
def _layer(*candidates):
    """First layer whose name exactly matches, else first substring match."""
    proj = QgsProject.instance()
    for name in candidates:
        m = proj.mapLayersByName(name)
        if m:
            return m[0]
    low = [c.lower() for c in candidates]
    for lyr in proj.mapLayers().values():
        nm = lyr.name().lower()
        if any(c in nm for c in low):
            return lyr
    return None


def _field(layer, *candidates):
    """Index of the first field whose name matches (case-insensitive), or -1."""
    if layer is None:
        return -1
    names = {f.name().lower(): i for i, f in enumerate(layer.fields())}
    for c in candidates:
        if c.lower() in names:
            return names[c.lower()]
    return -1


def _grade(score):
    for cutoff, letter in GRADE_BANDS:
        if score >= cutoff:
            return letter
    return "F"


def _dim(score, status, detail, issues=None):
    return {"score": round(score, 1), "status": status,
            "detail": detail, "issues": issues or []}


# ── Dimensions ───────────────────────────────────────────────────────────────
def _completeness():
    present, missing, empty = [], [], []
    for want in REQUIRED_LAYERS:
        lyr = _layer(want)
        if lyr is None:
            missing.append(want)
        elif lyr.featureCount() == 0:
            empty.append(want)
        else:
            present.append(want)
    total = len(REQUIRED_LAYERS)
    score = 100.0 * len(present) / total if total else 0.0
    issues = ([f"missing layer: {m}" for m in missing]
              + [f"empty layer: {e}" for e in empty])
    status = "pass" if not issues else ("warn" if score >= 80 else "fail")
    return _dim(score, status,
                f"{len(present)}/{total} required layers present & populated",
                issues)


def _consistency():
    # one CRS across the core layers
    core = [_layer(n) for n in ("Home Connection", "PON", "Poles", "Drop Cable")]
    core = [c for c in core if c]
    crs_bad = []
    crs_geographic = False
    if core:
        ref_crs = core[0].crs()
        if len(core) >= 2:
            ref = ref_crs.authid()
            crs_bad = [c.name() for c in core[1:] if c.crs().authid() != ref]
        # The working CRS must be projected metres — a geographic (degree) CRS
        # breaks every distance/area check, so flag it independently.
        crs_geographic = ref_crs.isGeographic()

    # null / duplicate device labels (single pass on the ONT layer)
    ont = _layer("Home Connection", "ONT")
    lbl = _field(ont, "label", "Name", "name")
    nulls = dups = counted = 0
    if ont is not None and lbl != -1:
        seen = {}
        for feat in ont.getFeatures():
            counted += 1
            v = feat[lbl]
            s = "" if v is None else str(v).strip()
            if not s:
                nulls += 1
            else:
                seen[s] = seen.get(s, 0) + 1
        dups = sum(1 for n in seen.values() if n > 1)

    issues = []
    if crs_bad:
        issues.append(f"CRS mismatch: {', '.join(crs_bad)}")
    if crs_geographic:
        issues.append("working CRS is geographic (degrees) — must be projected metres")
    if nulls:
        issues.append(f"{nulls} ONT(s) with no label")
    if dups:
        issues.append(f"{dups} duplicate ONT label(s)")
    # score: start at 100, dock per problem class, weighted by share of features
    penalty = 0.0
    penalty += 40.0 if crs_bad else 0.0
    penalty += 40.0 if crs_geographic else 0.0
    if counted:
        penalty += 30.0 * min(1.0, nulls / counted)
        penalty += 30.0 * min(1.0, dups / counted)
    score = max(0.0, 100.0 - penalty)
    status = "pass" if not issues else ("warn" if score >= 80 else "fail")
    return _dim(score, status,
                f"CRS + label integrity over {counted} ONTs", issues)


def _capacity():
    ont = _layer("Home Connection", "ONT")
    pon_idx = _field(ont, "pon_no", "pon", "pon_number")
    if ont is None or pon_idx == -1:
        return _dim(0.0, "n/a", "ONT layer or pon_no field not found — not assessed")
    counts = {}
    for feat in ont.getFeatures():                 # single pass
        v = feat[pon_idx]
        if v in (None, ""):
            continue
        try:
            p = int(v)
        except (TypeError, ValueError):
            continue
        counts[p] = counts.get(p, 0) + 1
    if not counts:
        return _dim(0.0, "n/a", "no ONTs carry a pon_no — not assessed")
    pons = len(counts)
    in_band = sum(1 for c in counts.values() if PON_TARGET_LO <= c <= PON_HI)
    over = sorted(p for p, c in counts.items() if c > PON_HARD_MAX)
    score = 100.0 * in_band / pons
    issues = []
    if over:
        issues.append(f"{len(over)} PON(s) over {PON_HARD_MAX} ONTs "
                      f"(e.g. {over[:3]})")
    low = [p for p, c in counts.items() if c < PON_TARGET_LO]
    if low:
        issues.append(f"{len(low)} PON(s) under {PON_TARGET_LO} ONTs")
    status = "pass" if score >= 90 and not over else (
        "warn" if score >= 70 and not over else "fail")
    return _dim(score, status,
                f"{in_band}/{pons} PONs in the {PON_TARGET_LO}–{PON_HI} band",
                issues)


def _spec():
    ont = _layer("Home Connection", "ONT")
    pon_idx = _field(ont, "pon_no", "pon", "pon_number")
    dr_idx  = _field(ont, "label", "dr", "drop_no")
    checks, issues = 0, []
    pon_ok = dr_ok = pon_seen = dr_seen = 0
    if ont is not None:
        for feat in ont.getFeatures():             # single pass
            if pon_idx != -1:
                v = feat[pon_idx]
                # A final HLD must have NO null/blank pon_no — count it as
                # seen-but-out-of-spec (not a silent skip) so missing numbering
                # lowers the score instead of vanishing from the ratio.
                pon_seen += 1
                try:
                    p = int(v)
                    if PON_MIN <= p <= PON_MAX:
                        pon_ok += 1
                except (TypeError, ValueError):
                    pass
            if dr_idx != -1:
                raw = "" if feat[dr_idx] is None else str(feat[dr_idx])
                # Match the DR number anchored to its DR prefix (e.g.
                # MOA.ONT.DR1853300) — never concatenate all digits and slice.
                m = re.search(r"DR(\d{7})", raw, re.IGNORECASE)
                if m:
                    dr_seen += 1
                    if DR_MIN <= int(m.group(1)) <= DR_MAX:
                        dr_ok += 1
    parts = []
    if pon_seen:
        checks += 1
        if pon_ok < pon_seen:
            issues.append(f"{pon_seen - pon_ok} ONT(s) outside PON "
                          f"{PON_MIN}–{PON_MAX}")
        parts.append(100.0 * pon_ok / pon_seen)
    if dr_seen:
        checks += 1
        if dr_ok < dr_seen:
            issues.append(f"{dr_seen - dr_ok} ONT(s) outside DR "
                          f"{DR_MIN}–{DR_MAX}")
        parts.append(100.0 * dr_ok / dr_seen)
    if not parts:
        return _dim(0.0, "n/a", "no PON/DR fields to check — not assessed")
    score = sum(parts) / len(parts)
    status = "pass" if score >= 99 else ("warn" if score >= 90 else "fail")
    return _dim(score, status,
                f"PON & DR numbering inside spec ({checks} field group(s))",
                issues)


def _power():
    """Does the Combo-1 (1×1:8 + 1×1:16) optical budget close across the whole
    AOI? Grounded: compares the model's max reach to the AOI bounding diagonal."""
    try:
        try:
            from . import power_budget as pb
        except ImportError:
            import power_budget as pb
    except Exception:
        return _dim(0.0, "n/a", "power_budget module unavailable — not assessed")

    aoi = _layer("AOI", "Area of Interest", "Boundary")
    if aoi is None:
        return _dim(0.0, "n/a", "AOI layer not found — not assessed")
    ext = aoi.extent()
    # AOI diagonal in real metres via QgsDistanceArea (CRS-agnostic: correct for
    # both projected-metre and geographic AOIs — NEVER raw extent units × 111.32)
    da = QgsDistanceArea()
    da.setSourceCrs(aoi.crs(), QgsProject.instance().transformContext())
    da.setEllipsoid("WGS84")
    diag_km = da.measureLine(
        QgsPointXY(ext.xMinimum(), ext.yMinimum()),
        QgsPointXY(ext.xMaximum(), ext.yMaximum()),
    ) / 1000.0
    try:
        reach = pb.max_reach_km()
    except Exception:
        return _dim(0.0, "n/a", "power_budget.max_reach_km unavailable")
    issues = []
    if diag_km <= 0:
        return _dim(0.0, "n/a", "AOI extent is empty — not assessed")
    ratio = reach / diag_km
    score = max(0.0, min(100.0, ratio * 50.0))   # reach == diag → 50; 2× → 100
    if reach < diag_km:
        issues.append(f"max reach {reach:.1f} km < AOI diagonal {diag_km:.1f} km")
    status = "pass" if reach >= diag_km else "fail"
    return _dim(score, status,
                f"Combo-1 reach {reach:.1f} km vs AOI {diag_km:.1f} km", issues)


# ── Public API ───────────────────────────────────────────────────────────────
def build_scorecard():
    """Compose all dimensions into one acceptance verdict. Returns a dict."""
    dims = {
        "completeness": _completeness(),
        "consistency":  _consistency(),
        "capacity":     _capacity(),
        "spec":         _spec(),
        "power":        _power(),
    }
    # weight only the dimensions that were actually assessed (n/a → excluded)
    num = den = 0.0
    for key, d in dims.items():
        if d["status"] == "n/a":
            continue
        w = WEIGHTS.get(key, 0.0)
        num += w * d["score"]
        den += w
    overall = round(num / den, 1) if den else 0.0
    any_fail = any(d["status"] == "fail" for d in dims.values())
    verdict = ("ACCEPTED" if overall >= 90 and not any_fail
               else "CONDITIONAL" if overall >= 75
               else "REJECTED")
    rows = []
    for key, d in dims.items():
        rows.append({"key": key, "label": key.capitalize(),
                     "weight": WEIGHTS.get(key, 0.0), **d})
    return {
        "project": QgsProject.instance().baseName(),
        "overall": overall,
        "grade":   _grade(overall),
        "verdict": verdict,
        "assessed_weight": round(den, 2),
        "dimensions": rows,
    }
