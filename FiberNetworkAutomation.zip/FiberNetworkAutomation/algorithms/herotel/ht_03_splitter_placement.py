# HeroTel: Splitter Placement Algorithm (TSD standard)

from qgis.core import (
    QgsProcessingParameterVectorLayer,
    QgsProcessing,
)

from .ht_base_algorithm import HeroTelBaseAlgorithm


class HT03SplitterPlacementAlgorithm(HeroTelBaseAlgorithm):
    """
    HT 3 — Splitter Placement (FTS + STS) — TSD standard.

    Places First-level Transmission Splitters (FTS, 1:8) and
    Second-level Transmission Splitters (STS, 1:16) in each PON cluster.

    PENDING: HeroTel TSD specification document from JJ.
    This is a stub algorithm. Full implementation will:
      1. For each PON, compute geometric median of its ONTs → FTS location
         (snap FTS to nearest road spine via OSM road graph)
      2. Sub-cluster ONTs within each PON into ≤ 16 groups → STS candidates
         (K-Means with target=16, fallback 12/8 for small clusters)
      3. Compute geometric median of each sub-cluster → STS location
         (snap STS to road within 50m drop constraint)
      4. Enforce hard constraints:
         - No ONT > 75m from its assigned STS (HeroTel SSA drop max)
         - No STS > MAX_DIST from its assigned FTS
      5. Write splitter locations to Splitter FTS v1 + Splitter STS v1 layers
      6. Assign spec_1='CMJ'/cblcpty1='144F' to FTS; STS uses MEGAnet dome SKUs

    HeroTel cascade: 1:8 FTS + 1:16 STS = 128 max ONTs per PON port.
    Drop cable: A-BB13-B00 (4F SM dual drop, max 75m aerial span).

    Run AFTER: HT 2 (PON Clustering)
    Run BEFORE: HT 4 (Drop Routing)
    Requires: ONT v1 (with pon_no), road network (C:/Temp/lulekani_roads.graphml)
    Produces: Splitter FTS v1, Splitter STS v1
    """

    INPUT = 'INPUT'

    def name(self):
        return 'ht_03_splitter_placement'

    def displayName(self):
        return 'HT 3 — Splitter Placement (FTS + STS)'

    def shortHelpString(self):
        return """
        <p><b>HT 3 — Splitter Placement (FTS + STS)</b></p>

        <p>Places FTS (1:8) and STS (1:16) splitters for each PON cluster.</p>

        <h4>HeroTel cascade</h4>
        <p>1:8 FTS + 1:16 STS = 128 max ONTs per PON port (target 60–102).</p>

        <h4>FTS placement</h4>
        <p>Geometric median of PON ONTs, snapped to nearest road node within 15m.</p>

        <h4>STS placement</h4>
        <p>K-Means sub-clustering (target 16 ONTs/STS). Geometric median snapped to road.
        Hard constraint: all ONTs within 75m of assigned STS.</p>

        <h4>MEGAnet dome SKUs</h4>
        <ul>
          <li>FTS enclosure: A-BB31-D00350 (144F MEGAnet dome)</li>
          <li>STS enclosure (24F dist): A-BB31-D00400 (24F MEGAnet dome)</li>
          <li>STS enclosure (48F dist): A-BB31-D00300 (48F MEGAnet dome)</li>
        </ul>

        <p><b>⚠️ PENDING:</b> HeroTel TSD specification from JJ. Full implementation awaiting PDF.</p>
        """

    def initAlgorithm(self, config=None):
        from qgis.core import QgsProject
        proj = QgsProject.instance()
        ont_layers = proj.mapLayersByName('ONT v1') or proj.mapLayersByName('Demand Points')

        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT,
                'ONT v1 point layer (with pon_no populated)',
                [QgsProcessing.SourceType.TypeVectorPoint],
                defaultValue=ont_layers[0] if ont_layers else None,
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """Algorithm entry point — STUB pending TSD specification"""
        raise NotImplementedError(
            '\n'.join([
                'HT 3 — Splitter Placement is not yet implemented.',
                '',
                'PENDING: HeroTel TSD (Telecommunications System Design) specification from JJ.',
                '',
                'Key design decisions confirmed:',
                '  • FTS: geometric median + road snap (see research_ftth_splitter_placement_algorithms)',
                '  • STS: K-Means sub-cluster (target 16) + road snap + 75m drop constraint',
                '  • 1:8 FTS + 1:16 STS cascade = 128 max ONTs/PON',
                '  • Drop cable: A-BB13-B00 4F SM dual drop (NOT 1F like Vuma Reach)',
                '  • FTS dome: A-BB31-D00350 (144F MEGAnet)',
                '  • STS dome: A-BB31-D00400 (24F) or A-BB31-D00300 (48F)',
                '',
                'Requires: C:/Temp/lulekani_roads.graphml (osmnx 2.1.0)',
                'Contact: ai@velocityfibre.co.za',
            ])
        )

    def postProcessAlgorithm(self, context, feedback):
        return {}
