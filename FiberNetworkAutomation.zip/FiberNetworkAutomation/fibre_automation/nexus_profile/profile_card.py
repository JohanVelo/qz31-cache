"""profile_card — the 👤 chip popover: identity + personalization.

Opened from the panel header chip. Shows the generated avatar, a time-of-day
greeting by name, member-since, a theme picker (6 presets) + accent colour
picker (live-applied via a callback into the panel), and Sign out.
"""
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QColorDialog, QDialog, QFrame, QGridLayout,
                                 QHBoxLayout, QLabel, QPushButton, QScrollArea,
                                 QVBoxLayout, QWidget)

from . import themes

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass


def greeting(name):
    import datetime
    try:
        h = datetime.datetime.now().hour
    except Exception:
        h = 12
    part = ("Good morning" if h < 12 else
            "Good afternoon" if h < 18 else "Good evening")
    return f"{part}, {name}"


class AvatarLabel(QLabel):
    """Initials in a coloured circle, generated from the username."""

    def __init__(self, username, size=44, parent=None):
        super().__init__(parent)
        self.setFixedSize(size, size)
        self._col = themes.avatar_color(username)
        self._txt = themes.initials(username)
        self._size = size

    def paintEvent(self, _e):
        from qgis.PyQt.QtCore import QRectF
        from qgis.PyQt.QtGui import QColor, QFont, QPainter
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(self._col))
        p.drawEllipse(QRectF(0, 0, self._size, self._size))
        p.setPen(QColor("#FFFFFF"))
        f = QFont()
        f.setBold(True)
        f.setPointSize(int(self._size * 0.34))
        p.setFont(f)
        p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self._txt)
        p.end()


class ProfileCard(QDialog):
    """on_theme(theme_name, accent_hex) — applied live by the panel.
    on_sign_out() — panel returns to the sign-in dialog.
    on_my_data()  — show the operator their own row (optional)."""

    def __init__(self, iface, profile, plugin_version="",
                 on_theme=None, on_sign_out=None, on_my_data=None,
                 on_account=None, parent=None):
        super().__init__(parent or iface.mainWindow())
        self.profile = profile
        self.plugin_version = plugin_version
        self.on_theme = on_theme
        self.on_sign_out = on_sign_out
        self.on_my_data = on_my_data
        self.on_account = on_account
        self.setWindowTitle("Your profile")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.Popup)
        self.setMinimumWidth(372)
        self.setStyleSheet(
            "QDialog{background:#0F1A30;}"
            "QLabel{color:#EAF0FF;}"
            "QLabel#name{font-size:15px;font-weight:800;}"
            "QLabel#meta{color:#9FB4C8;font-size:10px;}"
            "QLabel#sect{color:#5E6E92;font-size:10px;font-weight:700;}"
            "QPushButton{border-radius:7px;padding:6px 12px;font-size:11px;"
            "font-weight:700;background:#141E36;color:#B8C6E6;"
            "border:1px solid #243352;}"
            "QPushButton:hover{border:1px solid #2ec4f1;color:#fff;}"
            "QPushButton#out{color:#E0607A;}")
        self._build()

    def _build(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(10)

        top = QHBoxLayout()
        top.addWidget(AvatarLabel(self.profile.username))
        col = QVBoxLayout()
        col.setSpacing(1)
        nm = QLabel(greeting(self.profile.display_name))
        nm.setObjectName("name")
        col.addWidget(nm)
        meta = QLabel(self._meta_line())
        meta.setObjectName("meta")
        col.addWidget(meta)
        top.addLayout(col)
        top.addStretch(1)
        lay.addLayout(top)

        lay.addWidget(self._sect("THEME"))
        # The theme grid lives in a scroll area: with many themes (16) it would
        # otherwise overflow the popup and clip the right column + the buttons
        # below. ~3 rows show; the rest scroll. The Custom-accent + Sign-out row
        # stays OUTSIDE the scroll so it's always reachable.
        grid_host = QWidget()
        grid = QGridLayout(grid_host)
        grid.setSpacing(6)
        grid.setContentsMargins(0, 0, 0, 0)
        for i, (key, t) in enumerate(themes.PRESETS.items()):
            b = QPushButton(t["label"])
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setMinimumWidth(96)
            b.setStyleSheet(
                f"QPushButton{{background:{t['bg']};color:#EAF0FF;"
                f"border:1px solid {t['accent']};border-radius:7px;"
                f"padding:7px;font-size:11px;font-weight:700;}}"
                f"QPushButton:hover{{border:2px solid {t['accent']};}}")
            b.clicked.connect(lambda _=False, k=key: self._pick_theme(k, None))
            grid.addWidget(b, i // 3, i % 3)
        scroll = QScrollArea()
        scroll.setWidget(grid_host)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setMaximumHeight(190)
        scroll.setStyleSheet("QScrollArea{background:transparent;border:none;}")
        lay.addWidget(scroll)

        accent_row = QHBoxLayout()
        pick = QPushButton("🎨  Custom accent colour…")
        pick.setCursor(Qt.CursorShape.PointingHandCursor)
        pick.clicked.connect(self._pick_accent)
        accent_row.addWidget(pick)
        lay.addLayout(accent_row)

        lay.addSpacing(4)
        btns = QHBoxLayout()
        if self.on_my_data:
            data_btn = QPushButton("Your data")
            data_btn.clicked.connect(lambda: (self.close(), self.on_my_data()))
            btns.addWidget(data_btn)
        if self.on_account:
            acct_btn = QPushButton("Sign in / Reset password")
            acct_btn.setToolTip("Verify your notifications, or reset a forgotten password")
            acct_btn.clicked.connect(lambda: (self.close(), self.on_account()))
            btns.addWidget(acct_btn)
        btns.addStretch(1)
        out = QPushButton("Sign out")
        out.setObjectName("out")
        out.clicked.connect(self._sign_out)
        btns.addWidget(out)
        lay.addLayout(btns)

        # Size to content, but never taller than the screen (scroll handles the
        # theme overflow), so the popup always opens fully on-screen.
        try:
            self.adjustSize()
            avail = self.screen().availableGeometry().height() if self.screen() else 900
            self.resize(self.width(), min(self.sizeHint().height(), avail - 80))
        except Exception:
            _swallowed_note()

    def _sect(self, text):
        lbl = QLabel(text)
        lbl.setObjectName("sect")
        return lbl

    def _meta_line(self):
        bits = [f"@{self.profile.username}"]
        if self.profile.created_at:
            try:
                import datetime
                dt = datetime.datetime.fromisoformat(
                    self.profile.created_at.replace("Z", "+00:00"))
                bits.append("member since " + dt.strftime("%d %b %Y"))
            except Exception:
                _swallowed_note()
        bits.append(f"plugin v{self.plugin_version}")
        return "  ·  ".join(bits)

    def _pick_theme(self, key, accent):
        self.profile.theme = key
        self.profile.accent = None
        self.profile.save_local()
        if self.on_theme:
            # accent=None → a full-palette theme applies its OWN whole palette;
            # derived presets (graphite/violet/mono/forest) fall back to their
            # PRESETS accent inside apply_user_theme.
            self.on_theme(key, None)

    def _pick_accent(self):
        col = QColorDialog.getColor(parent=self)
        if not col.isValid():
            return
        hexv = col.name()
        if not themes.accent_ok_on_dark(hexv):
            from qgis.PyQt.QtWidgets import QMessageBox
            if QMessageBox.question(
                    self, "Low contrast",
                    "That colour may be hard to read on the dark panel. "
                    "Use it anyway?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
                return
        self.profile.accent = hexv
        self.profile.save_local()
        if self.on_theme:
            self.on_theme(self.profile.theme, hexv)

    def _sign_out(self):
        self.close()
        if self.on_sign_out:
            self.on_sign_out()
