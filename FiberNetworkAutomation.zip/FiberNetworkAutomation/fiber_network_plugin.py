# QGIS Plugin: Fiber Network Automation
# Main plugin class — config-driven toolbar
# claude:approved-destructive — EnclosureEditorPanel writes only on explicit UI button clicks

import os
from collections import OrderedDict
from qgis.core import QgsApplication, QgsProject, QgsWkbTypes
from qgis.PyQt.QtWidgets import (QAction, QApplication, QDialog, QVBoxLayout,
                                  QHBoxLayout, QPushButton, QLabel, QFrame,
                                  QToolButton, QMenu, QWidgetAction)
from qgis.PyQt.QtCore import Qt, QSize, QTimer, QEvent
from qgis.PyQt.QtGui import QColor, QIcon, QPen, QPainter
from qgis.PyQt.QtCore import QPointF
from qgis.gui import QgsRubberBand, QgsMapCanvasItem

from .fiber_processing_provider import FiberNetworkProvider


# ══════════════════════════════════════════════════════════════════════════════
# TOOLBAR_SPEC — the single source of truth for every button on the toolbar.
# Add a new automation = one dict entry. Flip enabled:False → True to activate.
# ══════════════════════════════════════════════════════════════════════════════

TOOLBAR_SPEC = [
    # ── Brand tile + quick action (inline) ────────────────────────────────────
    {"id": "brand",      "kind": "brand",  "group": "quick"},
    {"id": "run_q",      "kind": "action", "group": "quick", "client": "dev",
     "label": "⚙ Run q.py", "icon": "/mActionTerminal.svg",
     "tooltip": "Copy  exec(open('C:/Temp/q.py').read())  to clipboard.\nPaste into the QGIS Python Console to run the script.",
     "callback": "_run_q"},
    {"id": "ai_detect",  "kind": "callback", "group": "quick", "client": "dev",
     "label": "AI Detect", "icon": "/mActionPointLayer.svg",
     "callback": "_erven_detect_run",
     "tooltip": (
        "AI DETECT — SAM2 AutoMask building footprints.\n"
        "─────────────────────────────\n"
        "1. Zoom canvas to ≤300m wide (1:1500 or closer)\n"
        "2. Click — current canvas extent is used\n"
        "3. Wait ~3–7 min · BF16 autocast on RTX 3050\n"
        "4. Layer 'Buildings_detected' added with confidence QA\n"
        "─────────────────────────────\n"
        "Server: erven_mcp HTTP @ 127.0.0.1:8780\n"
        "Start: python -m erven_mcp.server --http  (erven_detection/src/)\n"
        "GPU: RTX 3050 CUDA · sam2-hiera-small · BF16 autocast")
     },
    {"id": "ai_erven",  "kind": "callback", "group": "quick", "client": "dev",
     "label": "AI Erven", "icon": "/mActionAddPolygon.svg",
     "callback": "_erven_erven_run",
     "tooltip": (
        "AI ERVEN — Buildings + property parcels (momepy tessellation).\n"
        "─────────────────────────────\n"
        "Runs AI Detect THEN generates Erven_detected parcels:\n"
        "each building gets a territory extending to the road\n"
        "edge and the midpoint between neighbouring buildings.\n"
        "─────────────────────────────\n"
        "Requires: C:/Temp/roads.json  (run /roads to refresh)\n"
        "          momepy 0.11.0+ installed in qgis-venv\n"
        "Output layers: Buildings_detected + Erven_detected\n"
        "Time: ~5–10 min (canvas tile + tessellation)")
     },
    {"id": "velo_detect", "kind": "callback", "group": "quick", "client": "dev",
     "label": "AutoDetect", "icon": "/mActionInOverview.svg",
     "callback": "_velo_detect_run",
     "tooltip": (
        "VELODECT — batch SAM2 building detection over the full AOI.\n"
        "─────────────────────────────\n"
        "Tiles the entire AOI at 0.3 m/px, sends each 512px chip\n"
        "to the SAM2 server, and places all buildings as\n"
        "'AI Centroids' + 'AI Buildings' memory layers.\n"
        "─────────────────────────────\n"
        "SAM2: http://192.168.1.150:8102/predict\n"
        "No clicking required — processes full AOI automatically.\n"
        "Start server: python C:/Temp/sam2_server.py")
     },
    {"id": "update_git", "kind": "callback", "group": "quick", "client": "dev",
     "label": "⬇ Update", "icon": "/mActionRefresh.svg",
     "callback": "_update_from_github",
     "tooltip": (
        "UPDATE FROM GITHUB — pull the latest code and reload this plugin.\n"
        "─────────────────────────────\n"
        "1. Runs  git pull  in your VeloPlan repo clone\n"
        "2. Copies the updated plugin files into QGIS\n"
        "3. Reloads FiberNetworkAutomation live (no QGIS restart)\n"
        "─────────────────────────────\n"
        "First use: you'll be asked to pick your VeloPlan repo folder\n"
        "(the clone that contains a .git folder). Needs Git installed.")
     },
    # New project is handled entirely by the welcome dialog (_show_welcome_dialog)
    # which fires automatically on File → New.  No toolbar buttons needed here.

    # ── Labelling — PRAK / MALM legacy (dropdown) ─────────────────────────────
    {"id": "lbl_aggregation", "kind": "algo", "group": "labelling",
     "label": "Label Aggregation Polygons", "icon": "/mActionCapturePolygon.svg",
     "algorithm": "fibernetwork:labelaggregation"},
    {"id": "lbl_blocks",      "kind": "algo", "group": "labelling",
     "label": "Label Blocks",               "icon": "/mActionCapturePolygon.svg",
     "algorithm": "fibernetwork:labelblocks"},
    {"id": "lbl_poles",       "kind": "algo", "group": "labelling",
     "label": "Label Poles",                "icon": "/mActionCapturePoint.svg",
     "algorithm": "fibernetwork:labelpoles"},
    {"id": "lbl_dome_joints", "kind": "algo", "group": "labelling",
     "label": "Label Dome Joints",          "icon": "/mActionCapturePoint.svg",
     "algorithm": "fibernetwork:labeldomejoints"},
    {"id": "lbl_feeder_joints","kind": "algo", "group": "labelling",
     "label": "Label Feeder Joints",        "icon": "/mActionCapturePoint.svg",
     "algorithm": "fibernetwork:labelfeederjoints"},
    {"id": "lbl_demand_pts",  "kind": "algo", "group": "labelling",
     "label": "Label Demand Points",        "icon": "/mActionCapturePoint.svg",
     "algorithm": "fibernetwork:labeldemandpoints"},
    {"id": "lbl_feeder_cables","kind": "algo", "group": "labelling",
     "label": "Label Feeder Cables",        "icon": "/mActionCaptureLine.svg",
     "algorithm": "fibernetwork:labelfeedercables"},
    {"id": "lbl_dist_cables", "kind": "algo", "group": "labelling",
     "label": "Label Distribution Cables",  "icon": "/mActionCaptureLine.svg",
     "algorithm": "fibernetwork:labeldistributioncables"},
    # ── Build FT 1-7 pipeline (dropdown with macro) ───────────────────────────
    {"id": "ft1", "kind": "algo", "group": "ft",
     "label": "FT1 · Label Poles",            "icon": "/mActionNewVectorLayer.svg",
     "algorithm": "fibernetwork:ft_label_poles",
     "tooltip": "Phase 2 / MOA — writes label, lat, lon to Poles v1"},
    {"id": "ft2", "kind": "algo", "group": "ft",
     "label": "FT2 · Label Distribution Cable","icon": "/mActionAddLineString.svg",
     "algorithm": "fibernetwork:ft_label_distribution_cable"},
    {"id": "ft3", "kind": "algo", "group": "ft",
     "label": "FT3 · Label Secondary Cable",   "icon": "/mActionAddLineString.svg",
     "algorithm": "fibernetwork:ft_label_secondary_cable"},
    {"id": "ft4", "kind": "algo", "group": "ft",
     "label": "FT4 · Label Enclosure",         "icon": "/mActionAddOgrLayer.svg",
     "algorithm": "fibernetwork:ft_label_enclosure"},
    {"id": "ft4b","kind": "algo", "group": "ft",
     "label": "FT4b · Label STS Splitters",    "icon": "/mActionCapturePoint.svg",
     "algorithm": "fibernetwork:ft_label_sts_splitters"},
    {"id": "ft5", "kind": "algo", "group": "ft",
     "label": "FT5 · Generate PON Zones",      "icon": "/mActionAddPolygon.svg",
     "algorithm": "fibernetwork:ft_generate_pon_zones"},
    {"id": "ft6", "kind": "algo", "group": "ft",
     "label": "FT6 · Apply PON Order",         "icon": "/mActionArrowDown.svg",
     "algorithm": "fibernetwork:ft_apply_pon_order"},
    {"id": "ft7", "kind": "algo", "group": "ft",
     "label": "FT7 · Pole Thickness",          "icon": "/mIconRulers.svg",
     "algorithm": "fibernetwork:ft_pole_thickness"},
    {"id": "ft_sep",    "kind": "separator", "group": "ft"},
    {"id": "ft_all",    "kind": "macro", "group": "ft",
     "label": "⚡ Run All (FT 1→7)", "icon": "/mActionStart.svg",
     "callback": "_run_ft_pipeline",
     "tooltip": "Runs FT1 → FT2 → FT3 → FT4 → FT5 → FT6 → FT7 sequentially."},

    # ── Audit & QA (dropdown) ────────────────────────────────────────────────
    {"id": "audit_hld",  "kind": "script", "group": "audit",
     "label": "HLD Audit",           "icon": "/mIconSuccess.svg",
     "script": r"C:/Users/jjsch/OneDrive - blitzfibre.com/Documents/Workspace/QGIS/audit_all_ph2.py",
     "tooltip": "Full Phase 2 HLD compliance audit — results in Python Console"},
    {"id": "span_check", "kind": "callback", "group": "audit",
     "label": "Check Spans",           "icon": "/mActionMeasure.svg",
     "callback": "_run_span_check",
     "tooltip": "Pole-to-pole span check. Drop>55m, Dist/Sec/Primary>70m.\nCreates a 'Span Violations' memory layer with each bad span as a red line."},
    {"id": "update_layers","kind": "callback", "group": "audit",
     "label": "Refresh Attributes",    "icon": "/mActionRefresh.svg",
     "callback": "_run_update_layers",
     "tooltip": "Re-run attribute refresh on Drop / Spare Drop / ONT / STS after edits"},

    # ── Automations menu removed — duplicated by fibretime_tools toolbar ──

    # ── Interactive tools (inline) ────────────────────────────────────────────
    {"id": "enc_editor", "kind": "callback", "group": "tools", "client": "both",
     "label": "Enclosures",           "icon": "/mActionAddOgrLayer.svg",
     "callback": "_open_enc_editor",
     "tooltip": (
        "ENCLOSURE EDITOR — inspect & reclassify enclosures on the canvas.\n"
        "─────────────────────────────\n"
        "Opens a floating panel. Use the Select Features tool (S key) to pick\n"
        "enclosures on the map, then click a type button to reclassify:\n"
        "  🟠 Distribution Joint (ODCFD0 / 24F)  — standard distribution dome\n"
        "  🟣 Spur Route (M16 Microloop / 48F)   — diverging-route dome\n"
        "  🔵 Feeder Splice UMJ / 72F            — secondary feeder joint\n"
        "  🟢 Feeder Splice CMJ / 144F           — primary feeder joint\n"
        "─────────────────────────────\n"
        "Canvas overlays:\n"
        "  🟠 orange diamond = Distribution (ODCFD0/24F)\n"
        "  🟣 purple square  = Spur Route (M16 Microloop/48F)\n"
        "  🔵 cyan circle    = Feeder UMJ/72F\n"
        "  🟢 green circle   = Feeder CMJ/144F")
     },
    {"id": "pole_editor","kind": "callback", "group": "tools", "client": "both",
     "label": "📍 Pole Editor",       "icon": "/mActionCapturePoint.svg",
     "callback": "_open_pole_editor",
     "tooltip": (
        "POLE EDITOR — inspect & correct individual poles on the canvas.\n"
        "─────────────────────────────\n"
        "Opens a floating panel. Click any pole on the map, then use buttons to:\n"
        "  🟢 Mark Road Crossing      — tag this pole as an RC (affects FT7 thickness)\n"
        "  🔴 Not Road Crossing       — revoke RC tag (auto-downgrade to 120-140mm)\n"
        "  🔵 140-160mm (Thick)        — force dim2=140-160mm (anchor/strain)\n"
        "  ⚪  120-140mm (Thin)        — force dim2=120-140mm (intermediate)\n"
        "─────────────────────────────\n"
        "Canvas legend (dots on poles):\n"
        "  🔵 Cyan   = 140-160mm thick pole\n"
        "  🟢 Green  = road crossing pole\n"
        "  🔴 Red    = confirmed NOT road crossing\n"
        "  🟡 Yellow = FTS splitter pole\n"
        "Tip: Shift+click to multi-select. Edits auto-refresh when the panel closes.")
     },
    {"id": "route_viewer","kind": "callback", "group": "tools", "client": "both",
     "label": "🔦 Splice Viewer",      "icon": "/mActionTracing.svg",
     "callback": "_open_route_viewer",
     "tooltip": (
        "SPLICE ROUTE VIEWER — cross-check the Excel splice plan on the canvas.\n"
        "─────────────────────────────\n"
        "Opens a floating panel. Pick an OLT port (= one PON sheet in the Excel)\n"
        "and the panel lights up that PON's entire fibre route on the map,\n"
        "colour-coded by hop, zooms to it, and selects the features (so the\n"
        "attribute table shows exactly what's lit).\n"
        "  OLT port → feeder → AGG dome → FTS → distribution → DIS dome →\n"
        "  STS → drop → ONT\n"
        "Narrow to a single STS leg to trace one branch. Prev/Next steps PONs.\n"
        "─────────────────────────────\n"
        "Canvas colours:\n"
        "  🟥 feeder cable   🟧 distribution cable   🟨 drop cables\n"
        "  🔷 AGG dome (FTS/fusion)   🔵 DIS dome (STS/connectorised)\n"
        "  🟪 FTS 1:8   🟩 STS 1:16   ⚪ ONT / home\n"
        "Read-out lists every label so you can tick it against the sheet.")
     },
    {"id": "canvas",     "kind": "callback", "group": "tools", "client": "dev",
     "label": "📸 Canvas",             "icon": "/mActionSaveMapAsImage.svg",
     "callback": "_snap_canvas",
     "tooltip": (
        "CANVAS SNAPSHOT — save current map view to disk for Claude.\n"
        "─────────────────────────────\n"
        "Writes the visible canvas (current extent + layer state) to\n"
        "  C:/Temp/canvas.png\n"
        "Then copies it to the clipboard so Claude can paste-receive it.\n"
        "Use for visual verification after edits or to share a view.")
     },
    # Erven Generator moved into Vuma ▼ dropdown as step 01c — not a standalone toolbar button.
]

GROUPS = OrderedDict([
    ("quick",     {"title": None,              "kind": "inline", "client": "both"}),
    ("labelling", {"title": "Label Layers",    "kind": "menu",  "client": "vuma",
                   "tooltip": (
                       "LABELLING (Group A) — legacy PRAK / MALM projects.\n"
                       "─────────────────────────\n"
                       "One algorithm per layer. Each takes a PROJECT enum\n"
                       "(PRAK or MALM) and writes the standard label fields:\n"
                       "  • Label Aggregation Polygons (Label, fid)\n"
                       "  • Label Blocks (Label., fid — trailing dot)\n"
                       "  • Label Poles (id, Name, X, Y, AG, Block, fid)\n"
                       "  • Label Dome Joints (id, Name, x, y, Block, AG)\n"
                       "  • Label Feeder Joints (Label, fid — AG prefix)\n"
                       "  • Label Demand Points (coords, AG, Block, Zone)\n"
                       "  • Label Feeder Cables (Feeder Cab, Tlenght, Slenght)\n"
                       "  • Label Distribution Cables (Dist Cable, AG, lengths)\n"
                       "Not for Phase 2 MOA. Use Build FT 1-7 for MOA.")}),
    ("ft",        {"title": "FT Pipeline",      "kind": "menu",  "client": "ft",
                   "tooltip": (
                       "BUILD FT 1-7 (Group B) — Fibertime MOA pipeline.\n"
                       "─────────────────────────\n"
                       "Run in order, or use ⚡ Run FT 1..7 to chain them all.\n"
                       "MOA-hardcoded — no PROJECT parameter.\n"
                       "  FT1 · Label Poles             — Label, lat, lon\n"
                       "  FT2 · Label Distribution Cable — pole-to-pole refs\n"
                       "  FT3 · Label Secondary Cable    — secondary feeder\n"
                       "  FT4 · Label Enclosure          — CMJ/UMJ splice domes\n"
                       "  FT4b · Label STS Splitters     — STS dome labels\n"
                       "  FT5 · Generate PON Zones       — PON polygons from ONT k-means\n"
                       "  FT6 · Apply PON Order          — feeder-path order → pon_no\n"
                       "  FT7 · Pole Thickness           — FOA 2015:35 (140-160 vs 120-140)\n"
                       "  ⚡  Run FT 1..7                 — runs all 7 in sequence.\n"
                       "FT6 needs pon_feeder_order.txt, FT7 needs C:/Temp/roads.json.")}),
    ("audit",     {"title": "✓ Compliance",     "kind": "menu",  "client": "ft",
                   "tooltip": (
                       "AUDIT & QA — compliance checks + maintenance.\n"
                       "─────────────────────────\n"
                       "  Run HLD Audit           — full Phase 2 audit_all_ph2.py\n"
                       "                            (null geoms, label, pon_no range,\n"
                       "                             zone/pon mismatch, datecrtd,\n"
                       "                             lat/lon, strtfeat/endfeat, etc.)\n"
                       "  Check Span Violations   — pole-to-pole geodesic spans.\n"
                       "                            Drop>55m, Dist/Sec/Primary>70m.\n"
                       "                            Creates 'Span Violations' memory\n"
                       "                            layer with each bad span as red line.\n"
                       "  Update Layer Attributes — re-run attribute refresh on Drop\n"
                       "                            Cable, Spare Drop, ONT, STS.\n"
                       "  Export HLD Package      — coming soon (QGZ + GPKG + BOM).")}),
    ("tools",     {"title": None,              "kind": "inline", "client": "both"}),
])


# ══════════════════════════════════════════════════════════════════════════════
# Stylesheet — applied once to the toolbar; children inherit.
# ══════════════════════════════════════════════════════════════════════════════
# Mirror eye QSS — three states (watching / idle / off)
_MIRROR_EYE_BASE = (
    "QPushButton#FNAMirrorEye {{"
    " background:{bg}; color:{fg};"
    " border:1px solid {border}; border-radius:6px;"
    " padding:4px 10px; margin:0 4px;"
    " font-family:'Segoe UI'; font-size:11px; font-weight:600;"
    " min-height:22px; }}"
    "QPushButton#FNAMirrorEye:hover {{ border:1px solid #8067D8; }}"
)
_MIRROR_EYE_WATCHING_QSS = _MIRROR_EYE_BASE.format(
    bg='#15803D', fg='#FFFFFF', border='#22C55E')
_MIRROR_EYE_IDLE_QSS = _MIRROR_EYE_BASE.format(
    bg='#92400E', fg='#FFFFFF', border='#F59E0B')
_MIRROR_EYE_OFF_QSS = _MIRROR_EYE_BASE.format(
    bg='#3A3D5C', fg='#A0A4BC', border='#5A5F88')

# Client-branded button QSS — Vuma = orange, Fibretime = teal
# Applied to group dropdown buttons and absorbed fibretime_tools buttons.
_VUMA_BTN_QSS = (
    'QToolButton { background: #FF0090; color: white; border: none;'
    ' border-radius: 4px; padding: 3px 10px;'
    ' font-family: "Segoe UI"; font-size: 11px; font-weight: 900; }'
    'QToolButton::menu-indicator { image: none; }'
    'QToolButton:hover { background: #FF33A8; }'
)
_FT_BTN_QSS = (
    'QToolButton { background: qlineargradient(x1:0,y1:0,x2:1,y2:0,'
    ' stop:0 #2ABFCC, stop:0.28 #2ABFCC,'
    ' stop:0.281 #FFE619, stop:0.719 #FFE619,'
    ' stop:0.72 #2ABFCC, stop:1 #2ABFCC);'
    ' color: #1A3040; border: none;'
    ' border-radius: 4px; padding: 3px 10px;'
    ' font-family: "Segoe UI"; font-size: 11px; font-weight: 800; }'
    'QToolButton::menu-indicator { image: none; }'
    'QToolButton:hover { background: #FFE619; color: #1A3040; }'
)
_HEROTEL_BTN_QSS = (
    'QToolButton { background: #FF4500; color: white; border: none;'
    ' border-radius: 4px; padding: 3px 10px;'
    ' font-family: "Segoe UI"; font-size: 11px; font-weight: 700; }'
    'QToolButton::menu-indicator { image: none; }'
    'QToolButton:hover { background: #FF6622; }'
)


_TOOLBAR_QSS_TEMPLATE = """
/* === FiberNetworkAutomation modern dark — scoped to plugin toolbar/menus ===
 * Material-3-derived tokens; does NOT touch QGIS chrome.
 * 2026-04-28 redesign per research_toolbar_ux_redesign_2026-04-28.md
 */
QToolBar#FiberNetworkAutomationToolbar {{
    background: #24253A; border: 0;
    border-bottom: 1px solid #3A3D5C;
    padding: 4px 6px; spacing: 4px;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton {{
    background: #2E3047; color: #E6E8F0;
    border: 1px solid transparent; border-radius: 6px;
    padding: 6px 10px; margin: 0 2px;
    font-family: 'Segoe UI'; font-size: 12px; font-weight: 500;
    min-height: 22px;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton:hover {{
    background: #3A3D5C; border: 1px solid #5A5F88;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton:pressed {{
    background: #474B6E;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton:checked {{
    background: #6E56CF; color: #FFFFFF; border: 1px solid #8067D8;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton:disabled {{
    color: #6E7392; background: #24253A;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton::menu-indicator {{
    subcontrol-position: right center; right: 4px;
    image: none; width: 8px;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton[popupMode="1"] {{
    padding-right: 16px;
}}

/* Brand tile — gradient + bridge state via dynamic property */
QToolBar#FiberNetworkAutomationToolbar QToolButton#FNABrandTile {{
    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                                stop:0 #6E56CF, stop:1 #8067D8);
    color: #FFFFFF; font-weight: 700;
    border: 1px solid #5A45B0; border-radius: 6px;
    padding: 6px 12px;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton#FNABrandTile:hover {{
    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                                stop:0 #8067D8, stop:1 #9A82E6);
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton#FNABrandTile[bridge="offline"] {{
    background: #DC2626; border-color: #991B1B;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton#FNABrandTile[bridge="online"] {{
    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                                stop:0 #16A34A, stop:1 #22C55E);
    border-color: #15803D;
}}

QToolBar#FiberNetworkAutomationToolbar::separator {{
    background: #3A3D5C; width: 1px; margin: 6px 6px;
}}

/* Dropdown menus opened from toolbar */
QToolBar#FiberNetworkAutomationToolbar QMenu {{
    background: #24253A; color: #E6E8F0;
    border: 1px solid #3A3D5C; border-radius: 6px;
    padding: 4px;
}}
QToolBar#FiberNetworkAutomationToolbar QMenu::item {{
    padding: 6px 14px 6px 28px; border-radius: 4px;
}}
QToolBar#FiberNetworkAutomationToolbar QMenu::item:selected {{
    background: #3A3D5C;
}}
QToolBar#FiberNetworkAutomationToolbar QMenu::separator {{
    height: 1px; background: #3A3D5C; margin: 4px 6px;
}}
"""


# ══════════════════════════════════════════════════════════════════════════════
# Plugin
# ══════════════════════════════════════════════════════════════════════════════

class FiberNetworkPlugin:
    """QGIS Plugin Implementation for Fiber Network Automation"""

    def __init__(self, iface):
        self.iface = iface
        self.provider = None
        self._toolbar = None
        self._pole_editor_panel = None
        self._home_panel = None
        self._np_dock = None
        self._enc_editor_panel  = None
        self._route_viewer_panel = None
        self._actions = {}         # id -> QAction for state management
        self._group_btns = {}      # group_id -> QToolButton (menu groups only)
        self._group_acts = {}      # group_id -> QWidgetAction from tb.addWidget(btn)
        self._brand_label = None   # VF badge QLabel
        self._brand_status = None  # "Bridge Online/Offline" status QLabel
        self._bridge_timer = None  # QTimer polling bridge_port.txt
        self._bridge_fail_streak = 0     # consecutive failed polls (debounce)
        self._bridge_last_shown_alive = None  # last rendered state
        self._automation_sep = None      # QAction separator before client dropdown
        self._automation_widget = None   # QToolButton (Vuma/FT steps dropdown)
        self._automation_action = None   # toolbar action wrapping the button
        self._absorbed_ft_widgets = []        # QToolButtons absorbed from fibretime_tools toolbar
        self._absorbed_ft_widget_acts = []   # QWidgetActions returned by addWidget() — use for visibility
        self._absorbed_ft_actions = []       # plain QActions absorbed from fibretime_tools toolbar

    # ── Setup ────────────────────────────────────────────────────────────────
    def initProcessing(self):
        reg = QgsApplication.processingRegistry()
        self.provider = FiberNetworkProvider()
        if not reg.addProvider(self.provider):
            # addProvider returned False → zombie "fibernetwork" key in the C++ map
            # (typically from a double-start or Plugin Reloader reload).
            # QGIS already deleted self.provider's C++ object; create a fresh probe
            # so removeProvider can look up and evict the zombie by ID.
            try:
                _probe = FiberNetworkProvider()
                reg.removeProvider(_probe)  # removes zombie by ID, NOT _probe itself
            except Exception:
                pass
            self.provider = FiberNetworkProvider()
            reg.addProvider(self.provider)

    def _erven_studio_dock_path(self):
        import os
        plugin_dir = os.path.dirname(__file__)
        cands = [
            os.path.join(plugin_dir, 'erven_studio', 'qgis_dock.py'),                   # bundled inside plugin
            os.path.join(os.path.dirname(plugin_dir), 'erven_studio', 'qgis_dock.py'),  # sibling
            r'C:/Users/jjsch/OneDrive - blitzfibre.com/Documents/Workspace/QGIS/erven_studio/qgis_dock.py',
        ]
        return next((p for p in cands if os.path.exists(p)), None)

    def _erven_studio_module(self):
        path = self._erven_studio_dock_path()
        if not path:
            self.iface.messageBar().pushWarning('Erven Studio', 'qgis_dock.py not found')
            return None
        import importlib.util
        spec = importlib.util.spec_from_file_location('erven_qgis_dock', path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod

    def _open_erven_studio(self):
        """Load erven_studio/qgis_dock.py and show the Erven Studio dock."""
        mod = self._erven_studio_module()
        if mod:
            mod.ErvenStudio.install()

    def _run_erven_now(self):
        """One-click: detect buildings → cadastral erven → demand points on the live AOI."""
        mod = self._erven_studio_module()
        if mod:
            mod.ErvenStudio.run_now()

    def _detect_buildings_now(self):
        """One-click building detection only (Google Open Buildings, no server)."""
        mod = self._erven_studio_module()
        if mod:
            mod.ErvenStudio.detect_now()

    def _install_ai_components(self):
        """One-time install of torch/sam2/geopandas etc. on plain QGIS so
        Detect Buildings works on a teammate's machine with zero setup."""
        try:
            from .fibre_automation.sam_detect.installer import AIComponentsInstaller
        except ImportError:
            from fibre_automation.sam_detect.installer import AIComponentsInstaller
        if getattr(self, '_ai_installer', None) is None:
            self._ai_installer = AIComponentsInstaller(self.iface)
        self._ai_installer.run()

    def _detect_buildings_sam(self):
        """Detect Buildings with local AI (SAM2) — works for ANY project AOI.

        Footprint boxes (GOB/Overture or an existing layer) -> SAM2 roof
        masks -> one house per erf (when a cadastre exists) -> regularized,
        shape-classified polygons. 100% local, no API keys/subscriptions.
        Degrades to the raw open-data footprints when the AI deps are absent.
        """
        runner = getattr(self, '_sam_detect_runner', None)
        if runner is None:
            try:
                from .fibre_automation.sam_detect.runner import SamDetectRunner
            except ImportError:
                from fibre_automation.sam_detect.runner import SamDetectRunner
            runner = SamDetectRunner(self.iface,
                                     fallback=self._detect_buildings_now)
            self._sam_detect_runner = runner
        runner.run()

    def _install_erven_studio_button(self):
        """Add an 'Erven Studio' toolbar button that opens the detect+tune dock."""
        from qgis.PyQt.QtWidgets import QAction
        if self._erven_studio_dock_path() is None:
            print('[FiberNet] Erven Studio: qgis_dock.py not found — button skipped')
            return
        act = QAction('Erven Studio', self.iface.mainWindow())
        act.setToolTip('Erven Studio — detect buildings + tune cadastral erven (sliders + Run)')
        act.triggered.connect(self._open_erven_studio)
        self._toolbar.addAction(act)
        self._actions['erven_studio'] = act
        self._erven_studio_action = act
        print('[FiberNet] Erven Studio button installed ✓')

    def _open_erven_detection(self):
        """Open the Erven Detection dock (SAM 2 + Grounding DINO via local MCP server).
        Lazy-loads erven_detection/ — works fully with the MCP server offline (the panel
        shows an offline notice and disables Run)."""
        from qgis.PyQt.QtCore import Qt
        panel = getattr(self, '_erven_detection_panel', None)
        if panel is not None:
            try:
                panel.show(); panel.raise_()
                return
            except RuntimeError:
                self._erven_detection_panel = None  # C++ object deleted — recreate
        try:
            from .erven_detection.erven_panel import ErvenPanel
        except ImportError:
            from erven_detection.erven_panel import ErvenPanel
        panel = ErvenPanel(self.iface, self.iface.mainWindow())
        self.iface.addDockWidget(Qt.RightDockWidgetArea, panel)
        panel.show(); panel.raise_()
        self._erven_detection_panel = panel

    def _run_splice_plan(self):
        """Step 5 — generate the splice plan (Excel workbook + A4 field cards) and open it.

        Runs the bundled fibre_automation/splice generators. They read the splice data
        JSON shipped alongside them and write to splice/output/. Falls back gracefully
        with a clear message if the Python deps (openpyxl/reportlab/networkx) are missing.
        """
        import os, sys, subprocess
        from qgis.PyQt.QtWidgets import QApplication
        plugin_dir = os.path.dirname(__file__)
        cands = [
            os.path.join(plugin_dir, 'fibre_automation', 'splice'),                   # ZIP install (team)
            os.path.join(os.path.dirname(plugin_dir), 'fibre_automation', 'splice'),  # plugins-dir sibling
            os.path.expanduser('~/OneDrive - blitzfibre.com/Documents/Workspace/QGIS/'
                               'fibre_automation/splice'),                            # dev workspace fallback
        ]
        splice = next((c for c in cands if os.path.exists(os.path.join(c, 'build_splice_v3.py'))), cands[0])
        gen = os.path.join(splice, 'build_splice_v3.py')
        cards = os.path.join(splice, 'build_field_cards.py')
        flow = os.path.join(splice, 'build_flow_diagrams.py')
        if not os.path.exists(gen):
            self.iface.messageBar().pushWarning('Splice Plan', 'Splice generator not found.')
            return
        # Prefer a Python that has the deps (dev venv), else QGIS's own Python.
        venv = os.path.expanduser('~/.qgis-venv/Scripts/python.exe')
        py = venv if os.path.exists(venv) else sys.executable
        # Outputs go to the project folder (portable), not a hardcoded dev path.
        env = dict(os.environ)
        try:
            from .fibre_automation.shared.vf_paths import project_output_dir
            outdir = project_output_dir()
        except Exception:
            outdir = os.path.join(splice, 'output')
        os.makedirs(outdir, exist_ok=True)
        env['VF_SPLICE_OUT'] = outdir
        self.iface.messageBar().pushInfo('Splice Plan', 'Generating Excel + field cards + flow diagrams…')
        QApplication.processEvents()
        try:
            r1 = subprocess.run([py, gen], capture_output=True, text=True, timeout=300, cwd=splice, env=env)
            r2 = subprocess.run([py, cards], capture_output=True, text=True, timeout=300, cwd=splice, env=env)
            r3 = (subprocess.run([py, flow], capture_output=True, text=True, timeout=300, cwd=splice, env=env)
                  if os.path.exists(flow) else None)
        except Exception as e:
            self.iface.messageBar().pushWarning('Splice Plan', str(e)[:200])
            return
        if r1.returncode == 0:
            extra = '' if r2.returncode == 0 else ' (field cards step needs reportlab/qrcode)'
            if r3 is not None and r3.returncode != 0:
                extra += ' (flow diagrams step needs matplotlib)'
            self.iface.messageBar().pushSuccess('Splice Plan', f'Done → {outdir}{extra}')
            try:
                os.startfile(outdir)  # noqa: open the output folder for the user
            except Exception:
                pass
        else:
            msg = (r1.stderr or r1.stdout or 'failed').strip()[-220:]
            self.iface.messageBar().pushWarning(
                'Splice Plan', f'Could not generate: {msg}  (needs openpyxl/networkx)')

    def _open_network_planner(self):
        """Open the bundled Velocity Network Planner (FTTHPlanTool) dock."""
        from qgis.PyQt.QtCore import Qt
        try:
            try:
                from .network_planner.dock_widget import FTTHPlanToolDockWidget
            except Exception:
                from network_planner.dock_widget import FTTHPlanToolDockWidget
            try:
                if self._np_dock is not None:
                    self._np_dock.show(); self._np_dock.raise_(); return
            except RuntimeError:
                self._np_dock = None  # underlying C++ dock was deleted
            self._np_dock = FTTHPlanToolDockWidget(self.iface)
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self._np_dock)
            # Tab it together with the Velocity Fibre Home panel so they share the
            # same area as tabs — opening the planner doesn't force Home to close.
            try:
                if self._home_panel is not None:
                    self.iface.mainWindow().tabifyDockWidget(self._home_panel, self._np_dock)
            except (RuntimeError, AttributeError):
                pass
            self._np_dock.show(); self._np_dock.raise_()
        except Exception as e:
            self.iface.messageBar().pushWarning(
                'Network Planner', f'Could not open: {str(e)[:200]}')

    def _install_home_panel(self):
        """Branded Velocity Fibre home dock — fronts the main tools in a friendly panel."""
        import os
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtWidgets import QAction
        try:
            from .velocity_home_panel import VelocityHomePanel
        except Exception:
            from velocity_home_panel import VelocityHomePanel

        def act(_id):
            a = self._actions.get(_id)
            if a:
                return lambda: a.trigger()
            return lambda: self.iface.messageBar().pushInfo(
                'Velocity Fibre', f'"{_id}" is not available in this mode.')

        steps = [
            ('Detect Buildings', 'Local AI (SAM2) — shape-classified, any AOI', self._detect_buildings_sam),
            ('Generate Erven',   'Cadastral erven + demand (no server)', self._run_erven_now),
            ('Network Planner',  'Route & group erven (planner)',     self._open_network_planner),
            ('Label Network',    'Run the FT 1–7 pipeline',           act('ft_all')),
            ('Check & Audit',    'HLD compliance + span check',       act('audit_hld')),
            ('Splice Plan',      'Excel workbook + A4 field cards',   self._run_splice_plan),
        ]
        tools = [
            ('📍 Poles',      act('pole_editor')),
            ('🔌 Enclosures', act('enc_editor')),
            ('⬇ Update',     act('update_git')),
        ]
        logo = os.path.join(os.path.dirname(__file__), 'logo.png')
        self._home_panel = VelocityHomePanel(self.iface, steps, tools, logo_path=logo)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self._home_panel)
        # auto-notify (panel banner + one-click update) when we publish
        try:
            try:
                from .update_check import UpdateChecker
            except ImportError:
                from update_check import UpdateChecker
            self._update_checker = UpdateChecker(
                self.iface, lambda: self._home_panel)
        except Exception as e:
            print(f'[FiberNet] update checker not started: {e}')
        # Wire the inline activation card (shown only while locked)
        try:
            try:
                from . import activation as _act
            except ImportError:
                import activation as _act
            self._home_panel.set_locked(not _act.is_activated(), self._panel_activate)
        except Exception as e:
            print(f'[FiberNet] home lock wiring failed: {e}')
        # Wire the ⚙ gear button → pops the full Velocity Fibre menu
        try:
            self._home_panel.set_settings_callback(self._open_velo_menu)
        except Exception as e:
            print(f'[FiberNet] settings button wiring failed: {e}')
        try:
            port = (open('C:/Temp/bridge_port.txt').read().strip()
                    if os.path.exists('C:/Temp/bridge_port.txt') else None)
            self._home_panel.set_bridge(True, port)
        except Exception:
            pass
        self._home_action = QAction('Velocity Fibre Home', self.iface.mainWindow())
        self._home_action.setToolTip('Open the Velocity Fibre home panel')
        self._home_action.triggered.connect(
            lambda: (self._home_panel.setVisible(True), self._home_panel.raise_()))
        self._toolbar.addAction(self._home_action)
        self._actions['home'] = self._home_action
        # Park the Splice Viewer button right next to Velocity Fibre Home
        rv = self._actions.get('route_viewer')
        if rv is not None:
            try:
                self._toolbar.removeAction(rv)
                self._toolbar.insertAction(self._home_action, rv)
                btn = self._toolbar.widgetForAction(rv)
                if btn is not None:
                    btn.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            except Exception:
                pass
        print('[FiberNet] Velocity Fibre home panel installed ✓')

    def _build_menu(self):
        """Build the single 'Velocity Fibre' menu — the JJ-approved Phase 1 unified tree.
        Replaces the old VeloPlan menu. Reuses toolbar QActions where they exist; AI Erven
        is RETIRED (tessellation violates the no-Voronoi erven rule) and deliberately absent."""
        from qgis.PyQt.QtWidgets import QMenu, QAction
        mw = self.iface.mainWindow()
        if getattr(self, '_velo_menu', None) is not None:
            try:
                mw.menuBar().removeAction(self._velo_menu.menuAction())
            except Exception:
                pass
        # The menu is now opened from the ⚙ button in the Velocity Fibre panel,
        # NOT from the menu bar (JJ: remove the top 'Velocity Fibre' menu). It is a
        # standalone QMenu parented to the main window and popped up by _open_velo_menu.
        self._velo_menu = QMenu('Velocity Fibre', mw)

        try:
            try:
                from . import error_reporter as _er
            except ImportError:
                import error_reporter as _er
        except Exception:
            _er = None

        def mk(label, cb, tip=None):
            a = QAction(label, mw)
            # Wrap every menu callback so a teammate gets a logged report, not a crash.
            a.triggered.connect(_er.guard(self.iface, label, cb) if _er else cb)
            if tip:
                a.setToolTip(tip)
            return a

        def alg(label, alg_id):
            import processing as _p
            return mk(label, lambda: _p.execAlgorithmDialog(alg_id, {}))

        dev = self._is_dev_mode()

        def add_ids(menu, ids):
            for _id in ids:
                # dev-only actions never reach a teammate's menu
                if _id in self._actions and not (
                        _id not in self._actions or
                        (not dev and any(e.get('id') == _id and e.get('client') == 'dev'
                                         for e in TOOLBAR_SPEC))):
                    menu.addAction(self._actions[_id])

        # ── top level ────────────────────────────────────────────────────────
        self._velo_menu.addAction(mk('🏠  Velocity Fibre Panel (home dashboard)', self._show_home_panel))
        self._velo_menu.addAction(mk('🆕  New Project…', self._show_welcome_dialog))
        self._velo_menu.addAction(mk('🧭  Workflow Guide (what to do next)…', self._open_workflow_dock))

        # ── 🤖 AI Mapping (ai_erven retired per Phase 0 sign-off) ────────────
        m_ai = self._velo_menu.addMenu('🤖  AI Mapping')
        m_ai.addAction(mk('🏠  Detect Buildings (AI — local SAM, any AOI)', self._detect_buildings_sam))
        m_ai.addAction(mk('🏘  Detect Buildings (quick — footprints only)', self._detect_buildings_now))
        add_ids(m_ai, ['ai_detect', 'velo_detect', 'erven_studio'])  # ai_detect/velo_detect dev-only
        m_ai.addAction(mk('🛖  Erven Detection (SAM2/MCP)…', self._open_erven_detection))
        if dev:
            m_ai.addAction(mk('▶  Run Erven + Demand (full AOI)', self._run_erven_now))

        # ── ✏️ Manual Planning (ported fibretime_tools toolkit) ──────────────
        _mp_tools = None
        try:
            try:
                from .manual_planning import install_menu as _mp_install, get_tools as _mp_get
            except ImportError:
                from manual_planning import install_menu as _mp_install, get_tools as _mp_get
            _mp_install(self.iface, self._velo_menu)
            _mp_tools = _mp_get(self.iface)
            print('[FiberNet] Manual Planning menu installed ✓')
        except Exception as e:
            print(f'[FiberNet] Manual Planning menu failed: {e}')

        # ── 🏷 Labelling (Group A, PRAK/MALM) ────────────────────────────────
        m_lab = self._velo_menu.addMenu('🏷  Labelling')
        add_ids(m_lab, [e['id'] for e in TOOLBAR_SPEC if e.get('group') == 'labelling'])

        # ── 🔌 FT Pipeline (Group B, MOA) ────────────────────────────────────
        m_ft = self._velo_menu.addMenu('🔌  FT Pipeline')
        add_ids(m_ft, [e['id'] for e in TOOLBAR_SPEC
                       if e.get('group') == 'ft' and e.get('kind') != 'separator'])
        m_ft.addSeparator()
        m_ft.addAction(alg('FT8 · Road Crossing Update', 'fibernetwork:ft_road_crossing_update'))
        m_ft.addAction(alg('FT9 · PON Zones (Voronoi)', 'fibernetwork:ft_generate_pon_zones_voronoi'))

        # ── 🏢 HeroTel (TSD) ─────────────────────────────────────────────────
        m_ht = self._velo_menu.addMenu('🏢  HeroTel')
        for n, lbl in [(1, 'ONT Placement'), (2, 'PON Clustering (SKATER)'),
                       (3, 'Splitter Placement'), (4, 'Drop Cable Routing'),
                       (5, 'Feeder Cable Routing')]:
            m_ht.addAction(alg(f'HT{n} · {lbl}', f'fibernetwork:ht_0{n}_{["ont_placement", "pon_clustering", "splitter_placement", "drop_routing", "feeder_routing"][n-1]}'))

        # ── ✅ QA & Output ────────────────────────────────────────────────────
        m_qa = self._velo_menu.addMenu('✅  QA & Output')
        add_ids(m_qa, [e['id'] for e in TOOLBAR_SPEC if e.get('group') == 'audit'])
        m_qa.addSeparator()
        m_qa.addAction(mk('🧵  Splice Plans', self._run_splice_plan))
        m_qa.addAction(mk('📄  Design Report (PDF map-book)', self._export_design_report))
        if _mp_tools is not None:
            m_qa.addAction(mk('📑  Bill of Materials', _mp_tools.run_bom_generator))
            m_qa.addAction(mk('💾  Export OES CSV', _mp_tools.run_oes_export))

        # ── 🛠 Tools (canvas/run_q/update_git are dev-only) ──────────────────
        m_tools = self._velo_menu.addMenu('🛠  Tools')
        add_ids(m_tools, ['pole_editor', 'enc_editor', 'route_viewer', 'canvas', 'run_q', 'update_git'])
        if _mp_tools is not None:
            rec = mk('🔴  Record PON Order', _mp_tools._toggle_pon_recorder,
                     'Click PON polygons in physical feeder order → pon_feeder_order.txt; then FT 6.')
            _mp_tools._pon_record_action = rec
            _mp_tools._pon_map_tool = None
            m_tools.addAction(rec)

        # ── ⚙ Settings & Help (footer submenu) ───────────────────────────────
        self._velo_menu.addSeparator()
        m_set = self._velo_menu.addMenu('⚙  Settings & Help')
        self._report_action = mk('🐞  Report a Problem…', self._open_problem_report)
        m_set.addAction(self._report_action)
        self._about_action = mk('ℹ️  About & Activation…', self._open_about_activation)
        m_set.addAction(self._about_action)
        m_set.addAction(mk('🔄  Check for updates…', self._check_for_updates))
        m_set.addAction(mk('🗺  Tool Map (what does what)', self._open_tool_map))
        m_set.addSeparator()
        m_set.addAction(mk('🧩  Install AI components (Detect Buildings)…',
                           self._install_ai_components))
        m_set.addAction(mk('🩺  Run health check', self._run_health_check))
        m_set.addAction(mk('📂  Open log / output folder', self._open_data_folder))
        m_set.addAction(mk('📋  Copy diagnostics', self._copy_diagnostics))
        m_set.addAction(mk('📖  Team guide', self._open_team_guide))
        self._apply_activation_gate()
        print('[FiberNet] Velocity Fibre menu built ✓')

    # ── ⚙ Settings menu popup (opened from the panel gear, not the menu bar) ──
    def _open_velo_menu(self, anchor=None):
        """Pop the full Velocity Fibre menu under the panel's ⚙ button."""
        from qgis.PyQt.QtCore import QPoint
        if getattr(self, '_velo_menu', None) is None:
            self._build_menu()
        try:
            if anchor is not None:
                self._velo_menu.popup(anchor.mapToGlobal(QPoint(0, anchor.height())))
            else:
                from qgis.PyQt.QtGui import QCursor
                self._velo_menu.popup(QCursor.pos())
        except Exception as e:
            self.iface.messageBar().pushWarning('Velocity Fibre', f'Menu error: {e}')

    def _run_health_check(self):
        """Quick self-check: bridge, roads data, PON order, activation, deps."""
        import os
        from qgis.PyQt.QtWidgets import QMessageBox
        rows = []
        try:
            from .fibre_automation.shared.vf_paths import roads_json, data_dir
        except ImportError:
            from fibre_automation.shared.vf_paths import roads_json, data_dir
        try:
            from . import activation as _a
        except ImportError:
            import activation as _a
        rows.append(('Activated', '✓' if _a.is_activated() else '✗ enter password'))
        rj = roads_json()
        rows.append(('Road data (FT7/FT8)', '✓ present' if os.path.exists(rj) else '— optional, not found'))
        rows.append(('Data/output folder', data_dir()))
        for pkg in ('geopandas', 'openpyxl', 'matplotlib'):
            try:
                __import__(pkg); rows.append((pkg, '✓'))
            except Exception:
                rows.append((pkg, '— installs on first use'))
        rows.append(('Plugin version', self._plugin_version()))
        QMessageBox.information(self.iface.mainWindow(), 'Velocity Fibre — Health check',
                               '\n'.join(f'{k}:  {v}' for k, v in rows))

    def _open_data_folder(self):
        from qgis.PyQt.QtCore import QUrl
        from qgis.PyQt.QtGui import QDesktopServices
        try:
            from .fibre_automation.shared.vf_paths import project_output_dir
        except ImportError:
            from fibre_automation.shared.vf_paths import project_output_dir
        try:
            QDesktopServices.openUrl(QUrl.fromLocalFile(project_output_dir()))
        except Exception as e:
            self.iface.messageBar().pushWarning('Velocity Fibre', str(e)[:160])

    def _copy_diagnostics(self):
        import platform
        from qgis.core import Qgis
        from qgis.PyQt.QtWidgets import QApplication
        try:
            from . import activation as _a
        except ImportError:
            import activation as _a
        txt = (f'Velocity Fibre Automation {self._plugin_version()}\n'
               f'QGIS {Qgis.QGIS_VERSION}\nPython {platform.python_version()}\n'
               f'OS {platform.system()} {platform.release()} · {platform.node()}\n'
               f'Activated: {_a.is_activated()}')
        QApplication.clipboard().setText(txt)
        self.iface.messageBar().pushInfo('Velocity Fibre', 'Diagnostics copied to clipboard.')

    def _open_team_guide(self):
        import os
        from qgis.PyQt.QtCore import QUrl
        from qgis.PyQt.QtGui import QDesktopServices
        # try a bundled guide, else the GitHub team guide
        cand = os.path.join(os.path.dirname(__file__), 'TEAM_GUIDE.md')
        url = (QUrl.fromLocalFile(cand) if os.path.exists(cand)
               else QUrl('https://github.com/JohanVelo/qz31-cache'))
        QDesktopServices.openUrl(url)

    # ── Activation gate (build prompt §5) ────────────────────────────────────
    def _apply_activation_gate(self):
        """No valid token → every menu + toolbar action greyed except About & Activation."""
        try:
            try:
                from . import activation
            except ImportError:
                import activation
            active = activation.is_activated()
        except Exception as e:
            print(f'[FiberNet] activation check failed (leaving unlocked): {e}')
            return

        always_on = {getattr(self, '_about_action', None),
                     getattr(self, '_report_action', None)}

        def set_menu(menu, enabled):
            for a in menu.actions():
                sub = a.menu()
                if sub is not None:
                    set_menu(sub, enabled)
                    a.setEnabled(enabled)
                elif a not in always_on:
                    a.setEnabled(enabled)

        if getattr(self, '_velo_menu', None) is not None:
            try:
                set_menu(self._velo_menu, active)
            except RuntimeError:
                pass
        try:
            for a in self._toolbar.actions():
                a.setEnabled(active)
        except (RuntimeError, AttributeError):
            pass
        # No password → NOTHING works (JJ: "you won't get in at all"):
        # the Processing provider is unregistered (no Toolbox access) and the
        # Home panel is disabled, on top of the greyed menu/toolbar/shortcuts.
        try:
            from qgis.core import QgsApplication
            reg = QgsApplication.processingRegistry()
            registered = reg.providerById('fibernetwork') is not None
            if active and not registered:
                self.initProcessing()
            elif not active and registered:
                reg.removeProvider(self.provider)
                self.provider = None
        except Exception as e:
            print(f'[FiberNet] provider gate failed: {e}')
        try:
            if self._home_panel is not None:
                # The panel itself stays enabled so the lock card is usable;
                # the card visibility tracks activation.
                self._home_panel.setEnabled(True)
                self._home_panel.set_locked(not active, self._panel_activate)
        except (RuntimeError, AttributeError):
            pass
        if not active:
            self.iface.messageBar().pushWarning(
                'Velocity Fibre Automation',
                'Locked — enter the company password in the Velocity Fibre panel (right) '
                'or via the popup to unlock all tools.')

    def _panel_activate(self, password):
        """Activation callback for the Home-panel lock card.
        Returns (ok, message). On success: unlock gate + welcome screen."""
        try:
            from . import activation
        except ImportError:
            import activation
        if activation.seconds_locked() > 0:
            return (False, f'Too many attempts — wait {activation.seconds_locked()}s.')
        if activation.try_activate(password):
            self._apply_activation_gate()
            try:
                self._welcome_splash = activation.show_welcome(self.iface, self._plugin_version())
            except Exception:
                pass
            return (True, '')
        if activation.seconds_locked() > 0:
            return (False, f'Too many attempts — wait {activation.seconds_locked()}s.')
        return (False, 'Wrong password. Please try again.')

    def _prompt_activation_if_locked(self):
        """On startup, if not activated, make it impossible to miss: pop the branded
        Activation dialog (non-blocking) AND show the Home-panel lock card."""
        try:
            from . import activation
        except ImportError:
            import activation
        try:
            if activation.is_activated():
                return
            if self._home_panel is not None:
                self._home_panel.set_locked(True, self._panel_activate)
                self._home_panel.setVisible(True)
                self._home_panel.raise_()
            # non-blocking modal dialog, centred — the first thing they see
            dlg = activation.ActivationDialog(self.iface)
            dlg.dlg.setModal(True)
            dlg.dlg.show()
            dlg.dlg.raise_()
            dlg.dlg.activateWindow()

            def _after():
                if activation.is_activated():
                    self._apply_activation_gate()
                    if self._home_panel is not None:
                        self._home_panel.set_locked(False)
                    try:
                        self._welcome_splash = activation.show_welcome(
                            self.iface, self._plugin_version())
                    except Exception:
                        pass
            dlg.dlg.finished.connect(lambda _=0: _after())
            self._activation_prompt = dlg
        except Exception as e:
            print(f'[FiberNet] activation prompt failed: {e}')

    def _open_about_activation(self):
        try:
            from . import activation
        except ImportError:
            import activation
        from qgis.PyQt.QtWidgets import QMessageBox
        if activation.is_activated():
            ret = QMessageBox.question(
                self.iface.mainWindow(), 'Velocity Fibre Automation',
                f'Velocity Fibre Automation {self._plugin_version()}\n'
                'Status: ACTIVATED on this machine ✓\n\n'
                'Deactivate this machine?',
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ret == QMessageBox.Yes:
                activation.deactivate()
                self._apply_activation_gate()
        else:
            if activation.ActivationDialog(self.iface).exec_():
                self._apply_activation_gate()
                self.iface.messageBar().pushSuccess(
                    'Velocity Fibre Automation', 'Activated — all tools unlocked ✓')
                try:
                    self._welcome_splash = activation.show_welcome(
                        self.iface, self._plugin_version())
                except Exception as e:
                    print(f'[FiberNet] welcome splash failed: {e}')

    def _export_design_report(self):
        """Generate the one-click Design Report PDF (Atlas map-book over PON/Zone)."""
        from qgis.PyQt.QtWidgets import QApplication
        from qgis.PyQt.QtCore import Qt
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            try:
                from . import report
            except ImportError:
                import report
            report.export_design_report(self.iface)
        except Exception as e:
            self.iface.messageBar().pushWarning('Velocity Fibre', f'Design Report: {e}')
        finally:
            QApplication.restoreOverrideCursor()

    def _show_home_panel(self):
        """Open / re-show the Velocity Fibre home dashboard panel.
        Re-creates it if it was closed (C++ object deleted)."""
        try:
            panel = getattr(self, '_home_panel', None)
            if panel is not None:
                try:
                    panel.setVisible(True)
                    panel.raise_()
                    return
                except RuntimeError:
                    self._home_panel = None  # deleted — rebuild below
            self._install_home_panel()
            if self._home_panel is not None:
                self._home_panel.setVisible(True)
                self._home_panel.raise_()
        except Exception as e:
            self.iface.messageBar().pushWarning('Velocity Fibre', f'Could not open the panel: {e}')

    def _open_workflow_dock(self):
        """Open the guided Workflow dock (checklist + validation)."""
        try:
            try:
                from . import workflow_dock
            except ImportError:
                import workflow_dock
            self._workflow_dock = workflow_dock.open_dock(self.iface)
        except Exception as e:
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.warning(self.iface.mainWindow(), 'Velocity Fibre',
                                f'Could not open the Workflow dock:\n{e}')

    def _maybe_whats_new(self):
        """Show the What's-New popup once after an upgrade (gated to activated machines)."""
        try:
            try:
                from . import activation, ux
            except ImportError:
                import activation, ux
            if not activation.is_activated():
                return
            self._whats_new_dlg = ux.maybe_show_whats_new(
                self.iface, os.path.dirname(__file__), self._plugin_version().lstrip('v'))
        except Exception as e:
            print(f'[FiberNet] whats-new failed: {e}')

    def _open_problem_report(self):
        """Open the Report a Problem dialog — teammates send their error log to JJ."""
        try:
            try:
                from . import error_reporter
            except ImportError:
                import error_reporter
            self._problem_dlg = error_reporter.ProblemReportDialog(self.iface)
            self._problem_dlg.show()
        except Exception as e:
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.warning(self.iface.mainWindow(), 'Velocity Fibre',
                                f'Could not open the report dialog:\n{e}')

    def _open_tool_map(self):
        """Generate + open the Admin/Tool Map page (JJ requirement, Phase 0 sign-off):
        a tidy HTML page of every menu action so you can always see what's where.
        Built from the LIVE menu, so it can never drift out of date."""
        import html as _html
        import tempfile
        from qgis.PyQt.QtCore import QUrl
        from qgis.PyQt.QtGui import QDesktopServices
        from qgis.core import QgsApplication

        def walk(menu, depth=0):
            rows = []
            for a in menu.actions():
                if a.isSeparator():
                    continue
                sub = a.menu()
                if sub is not None:
                    rows.append((depth, sub.title(), '', True))
                    rows.extend(walk(sub, depth + 1))
                elif a.text():
                    rows.append((depth, a.text(), a.toolTip() or '', False))
            return rows

        rows = walk(self._velo_menu)
        algs = sorted(a.id() + ' — ' + a.displayName()
                      for a in QgsApplication.processingRegistry().algorithms()
                      if a.id().startswith('fibernetwork:'))
        try:
            ver = self._plugin_version()
        except Exception:
            ver = ''
        body = ['<!DOCTYPE html><html><head><meta charset="utf-8"><title>Velocity Fibre — Tool Map</title>',
                '<style>body{font-family:Segoe UI,sans-serif;margin:2em auto;max-width:880px;color:#1a2050}',
                'h1{border-bottom:3px solid #8b2450}h2{color:#3d5cb8;margin-top:1.6em}',
                'table{border-collapse:collapse;width:100%}td{padding:5px 10px;border-bottom:1px solid #eee;vertical-align:top}',
                '.grp{font-weight:bold;background:#f4f6fb}.tip{color:#667;font-size:0.9em}</style></head><body>',
                f'<h1>Velocity Fibre — Tool Map</h1><p>Every tool in the plugin, where it lives, and what it does. '
                f'Generated live from the menu — always current. {_html.escape(ver)}</p><h2>Menu</h2><table>']
        for depth, text, tip, is_group in rows:
            ind = '&nbsp;' * 6 * depth
            cls = ' class="grp"' if is_group else ''
            body.append(f'<tr{cls}><td>{ind}{_html.escape(text)}</td>'
                        f'<td class="tip">{_html.escape(tip).replace(chr(10), "<br>")}</td></tr>')
        body.append('</table><h2>Processing algorithms (Toolbox)</h2><ul>')
        body += [f'<li><code>{_html.escape(s)}</code></li>' for s in algs]
        body.append('</ul></body></html>')

        out = os.path.join(tempfile.gettempdir(), 'velocity_fibre_tool_map.html')
        with open(out, 'w', encoding='utf-8') as f:
            f.write('\n'.join(body))
        QDesktopServices.openUrl(QUrl.fromLocalFile(out))

    def _plugin_version(self):
        import configparser
        cp = configparser.ConfigParser()
        cp.read(os.path.join(os.path.dirname(__file__), 'metadata.txt'), encoding='utf-8')
        return 'v' + cp.get('general', 'version', fallback='?')

    def _check_for_updates(self):
        """Fetch the distro plugins.xml and compare versions (deep-link to Plugin Manager)."""
        import re as _re
        import urllib.request
        from qgis.PyQt.QtWidgets import QMessageBox
        URL = ('https://raw.githubusercontent.com/JohanVelo/qz31-cache/main/plugins.xml')
        try:
            xml = urllib.request.urlopen(URL, timeout=8).read().decode('utf-8', 'replace')
            m = _re.search(r'version="([\d.]+)"', xml)
            remote = m.group(1) if m else '?'
            local = self._plugin_version().lstrip('v')
            if remote != '?' and tuple(remote.split('.')) > tuple(local.split('.')):
                QMessageBox.information(
                    self.iface.mainWindow(), 'Velocity Fibre — update available',
                    f'Version {remote} is available (you have {local}).\n\n'
                    'Open Plugins → Manage and Install Plugins → Upgradeable to update.')
            else:
                QMessageBox.information(
                    self.iface.mainWindow(), 'Velocity Fibre',
                    f'You are up to date (v{local}).')
        except Exception as e:
            QMessageBox.warning(self.iface.mainWindow(), 'Velocity Fibre',
                                f'Could not check for updates:\n{e}')

    def initGui(self):
        # Nuke any stale FiberNetworkAutomation toolbar left behind by a
        # previous init (happens if startPlugin ran twice without a clean unload).
        from qgis.PyQt.QtWidgets import QToolBar
        for tb in self.iface.mainWindow().findChildren(QToolBar):
            try:
                if tb.objectName() == 'FiberNetworkAutomationToolbar':
                    self.iface.mainWindow().removeToolBar(tb)
                    tb.deleteLater()
            except RuntimeError:
                pass

        self._toolbar = self.iface.mainWindow().addToolBar('FiberNetworkAutomation')
        self._toolbar.setObjectName('FiberNetworkAutomationToolbar')
        self._toolbar.setIconSize(QSize(22, 22))  # research-recommended size
        # New static QSS — no token substitution needed (tokens inlined per research)
        self._toolbar.setStyleSheet(_TOOLBAR_QSS_TEMPLATE.format())
        self._build_toolbar()
        # Bridge poller is a dev-only Claude channel — teammates have no bridge.
        if self._is_dev_mode():
            self._start_bridge_poller()
        # Live HLD score tile in QGIS status bar (research_toolbar_ux 2026-04-28)
        try:
            self._install_hld_score_tile()
        except Exception as e:
            print(f'[FiberNet] HLD score tile install failed: {e}')
        # Command palette — Ctrl+Shift+P fuzzy-finder for every plugin action
        try:
            self._install_command_palette()
        except Exception as e:
            print(f'[FiberNet] Command palette install failed: {e}')
        # Erven Studio — dock + button to detect buildings & tune cadastral erven (sliders + Run)
        try:
            self._install_erven_studio_button()
        except Exception as e:
            print(f'[FiberNet] Erven Studio button install failed: {e}')
        # Velocity Fibre branded home panel — friendly front-end for the main workflow
        try:
            self._install_home_panel()
        except Exception as e:
            print(f'[FiberNet] Home panel install failed: {e}')
        # VeloPlan menu — one menu fronting every tool. Deferred so it captures ALL toolbar actions
        # (fibre_automation pipeline + absorbed fibretime actions are added after this point in initGui).
        try:
            from qgis.PyQt.QtCore import QTimer as _QTimer
            _QTimer.singleShot(2500, self._build_menu)
        except Exception as e:
            print(f'[FiberNet] VeloPlan menu schedule failed: {e}')
        # Mirror eye is a Claude dev tool — not installed for planners
        # Wire fibre_automation pipeline steps into STEP_MAP.
        # fibre_automation lives either:
        #   a) inside this plugin's directory (ZIP install — all planners)
        #   b) in the dev workspace (JJ's machine only, as a sibling folder)
        try:
            import sys, os
            plugin_dir = os.path.dirname(__file__)
            # (a) ZIP install: fibre_automation is a sub-package of the plugin dir
            if plugin_dir not in sys.path:
                sys.path.insert(0, plugin_dir)
            # (b) Dev fallback: workspace sibling (only adds if it actually exists)
            _ws = os.path.join(os.path.dirname(plugin_dir))
            if os.path.isdir(os.path.join(_ws, 'fibre_automation')) and _ws not in sys.path:
                sys.path.insert(0, _ws)
            # Evict all fibre_automation modules from cache so disk is read fresh
            for _mod in list(sys.modules.keys()):
                if _mod.startswith('fibre_automation'):
                    del sys.modules[_mod]
            import fibre_automation.plugin_wiring  # noqa: F401
            print('[FiberNet] fibre_automation pipeline wired ✓')
        except Exception as e:
            print(f'[FiberNet] fibre_automation wiring failed: {e}')

        # Restore SESSION from project file on open; clear it on new project
        try:
            from qgis.core import QgsProject
            QgsProject.instance().readProject.connect(self._on_project_read)
            QgsProject.instance().cleared.connect(self._on_project_cleared)
            # Restore from the project that's already open when the plugin loads
            self._on_project_read()
        except Exception as e:
            print(f'[FiberNet] project signal wiring failed: {e}')
        from qgis.PyQt.QtCore import QTimer
        # iface.newProjectCreated fires once during QGIS startup for the initial
        # blank "Untitled Project", then again every time the user does File → New
        # or clicks "New Empty Project".  Skip the first (startup) firing; show the
        # welcome dialog for all subsequent ones.
        self._new_project_count = 0

        def _on_new_project_created():
            self._new_project_count += 1
            if self._new_project_count <= 1:
                return  # startup blank project — ignore
            QTimer.singleShot(300, self._show_welcome_dialog)

        self._on_new_project_created = _on_new_project_created
        try:
            self.iface.newProjectCreated.connect(self._on_new_project_created)
            print('[FiberNet] newProjectCreated wired ✓')
        except Exception as e:
            print(f'[FiberNet] newProjectCreated wiring failed: {e}')
        # Connect to bridge dock client_changed signal (retry if bridge not ready yet)
        if not self._connect_bridge_client_signal():
            QTimer.singleShot(2000, self._connect_bridge_client_signal)
        # fibretime_tools buttons are RETIRED — everything is in the published VeloPlan plugin now
        # (home panel + VeloPlan menu). Do NOT absorb the fibretime_tools toolbar; instead disable
        # that redundant plugin so its toolbar never appears. (JJ: remove those buttons permanently.)
        self._absorb_attempts = 0
        self._absorb_watchdog = None
        QTimer.singleShot(1200, self._retire_fibretime_tools)
        # "What's New" popup once per new version after an upgrade (not first install)
        QTimer.singleShot(3200, self._maybe_whats_new)
        # If locked, make activation impossible to miss: auto-popup + Home-panel card.
        # Deferred so the menu + home panel exist first.
        QTimer.singleShot(2900, self._prompt_activation_if_locked)
        # Register processing algorithms last so a crash above doesn't create a
        # zombie "fibernetwork" entry in the C++ registry (unload() can't remove
        # it once the C++ object is deleted by QGIS's exception-path cleanup).
        # Activation-gated: an unactivated machine gets NO algorithms either —
        # _apply_activation_gate registers the provider after a successful unlock.
        try:
            try:
                from . import activation as _act
            except ImportError:
                import activation as _act
            _gate_ok = _act.is_activated()
        except Exception:
            _gate_ok = True   # never let a gate bug brick the plugin for the team
        if _gate_ok:
            self.initProcessing()
        else:
            print('[FiberNet] not activated — processing provider withheld')

    # ── Dev vs team mode ─────────────────────────────────────────────────────
    def _is_dev_mode(self):
        """True only on JJ's machine. Dev-only buttons (Run q.py, AI server
        detect, git-pull Update, Canvas snapshot, Mirror Eye, Bridge status)
        are shown ONLY in dev mode; teammates never see them.

        Dev = the QGIS Bridge plugin is installed (Claude's control channel,
        which teammates don't have) OR the VF_DEV env var is set."""
        cached = getattr(self, '_dev_mode_cached', None)
        if cached is not None:
            return cached
        dev = bool(os.environ.get('VF_DEV'))
        if not dev:
            try:
                import qgis.utils as _qu
                dev = ('QGISBridgePlugin' in getattr(_qu, 'available_plugins', [])
                       or 'QGISBridgePlugin' in _qu.plugins)
            except Exception:
                dev = False
        self._dev_mode_cached = dev
        print(f"[FiberNet] mode: {'DEV (JJ)' if dev else 'TEAM'}")
        return dev

    # ── Toolbar builder ──────────────────────────────────────────────────────
    def _build_toolbar(self):
        tb = self._toolbar
        dev = self._is_dev_mode()
        # Group spec entries by group id, preserving spec order.
        # In team mode, drop every dev-only entry (client == "dev").
        groups = OrderedDict((g, []) for g in GROUPS)
        for entry in TOOLBAR_SPEC:
            if entry.get("client") == "dev" and not dev:
                continue
            groups[entry["group"]].append(entry)

        prev_kind = None
        for gid, entries in groups.items():
            meta = GROUPS[gid]
            if meta["kind"] == "menu":
                btn = QToolButton(tb)
                btn.setText(meta["title"])
                btn.setPopupMode(QToolButton.InstantPopup)
                btn.setToolButtonStyle(Qt.ToolButtonTextOnly)
                if meta.get("tooltip"):
                    btn.setToolTip(meta["tooltip"])
                menu = QMenu(btn)
                menu.setStyleSheet(
                    f"QMenu {{ background: {_PANEL}; color: {_TEXT};"
                    f" border: 1px solid {_BORDER}; padding: 4px; }}"
                    f"QMenu::item {{ padding: 5px 18px; border-radius: 3px; }}"
                    f"QMenu::item:selected {{ background: {_ACCENT}; color: {_BG}; }}"
                    f"QMenu::item:disabled {{ color: {_DIM}; background: transparent; }}"
                    f"QMenu::separator {{ height: 1px; background: {_BORDER}; margin: 4px 8px; }}"
                )
                for e in entries:
                    if e["kind"] == "separator":
                        menu.addSeparator()
                    elif e["kind"] == "header":
                        # Non-clickable header — styled as grey italic label
                        hdr = QAction(e["label"], menu)
                        hdr.setEnabled(False)
                        f = hdr.font()
                        f.setItalic(True); f.setBold(True); f.setPointSize(8)
                        hdr.setFont(f)
                        menu.addAction(hdr)
                    else:
                        menu.addAction(self._make_action(e))
                btn.setMenu(menu)
                grp_act = tb.addWidget(btn)
                self._group_btns[gid] = btn
                self._group_acts[gid] = grp_act
            else:  # inline
                for e in entries:
                    if e["kind"] == "brand":
                        if dev:
                            tb.addWidget(self._make_brand_tile())
                        else:
                            tb.addWidget(self._make_static_logo())
                    else:
                        act = self._make_action(e)
                        tb.addAction(act)
                        btn = tb.widgetForAction(act)
                        if btn is not None:
                            eid = e.get("id", "")
                            # Client-selector buttons: large, branded, text-beside-icon
                            if eid == 'select_vuma':
                                btn.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
                                btn.setStyleSheet(_VUMA_BTN_QSS)
                            elif eid == 'select_ft':
                                btn.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
                                btn.setStyleSheet(_FT_BTN_QSS)
                            # Other named tool buttons also get text beside icon
                            elif eid in ("enc_editor", "pole_editor", "canvas",
                                         "route_viewer"):
                                btn.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            prev_kind = meta["kind"]

        # Default state: no client chosen → show only brand + Setup Project
        self._update_toolbar_for_client(None)

    def _icon(self, path):
        return QgsApplication.getThemeIcon(path) if path else QIcon()

    def _make_action(self, e):
        act = QAction(self._icon(e.get("icon", "")), e["label"],
                      self.iface.mainWindow())
        if "tooltip" in e:
            act.setToolTip(e["tooltip"])
            act.setWhatsThis(e["tooltip"])
        act.setEnabled(e.get("enabled", True))
        # 2026-04-28: keyboard shortcuts per research_toolbar_ux_redesign_2026-04-28.md
        # (ft_all/Ctrl+Shift+F removed — redundant with the ⚡ Run FT 1..7 button
        #  in the Build FT 1-7 dropdown.)
        SHORTCUTS = {
            'ft1':           'Ctrl+1', 'ft2': 'Ctrl+2', 'ft3': 'Ctrl+3',
            'ft4':           'Ctrl+4', 'ft4b':'Ctrl+5', 'ft5': 'Ctrl+6',
            'ft6':           'Ctrl+7', 'ft7': 'Ctrl+8',
            'audit_hld':     'Ctrl+Shift+A',
            'span_check':    'Ctrl+Shift+S',
            'update_layers': 'Ctrl+Shift+U',
            'pole_editor':   'Ctrl+Shift+E',
            'run_q':         'Ctrl+Shift+Q',
            'canvas':        'Ctrl+Shift+C',
        }
        if e["id"] in SHORTCUTS:
            act.setShortcut(SHORTCUTS[e["id"]])
            act.setShortcutContext(Qt.ApplicationShortcut)
            # Annotate tooltip with the shortcut so the user discovers it
            cur = act.toolTip() or e.get("label", "")
            act.setToolTip(f"{cur}  ({SHORTCUTS[e['id']]})")

        kind = e["kind"]
        if kind == "callback":
            act.triggered.connect(getattr(self, e["callback"]))
        elif kind == "action":
            # plain action with optional callback (used for stubs)
            if "callback" in e:
                act.triggered.connect(getattr(self, e["callback"]))
        elif kind == "algo":
            algo_id = e["algorithm"]
            eid = e["id"]
            act.triggered.connect(
                lambda _=False, a=algo_id, i=eid: self._run_algo(a, i))
        elif kind == "script":
            spath = e["script"]
            eid = e["id"]
            act.triggered.connect(
                lambda _=False, s=spath, i=eid: self._run_script(s, i))
        elif kind == "macro":
            act.triggered.connect(getattr(self, e["callback"]))

        self._actions[e["id"]] = act
        return act

    def _make_static_logo(self):
        """Team-mode toolbar identity: the Velocity Fibre logo only — no bridge
        status, not clickable. Falls back to a text label if branding is absent."""
        from qgis.PyQt.QtWidgets import QLabel
        lbl = QLabel()
        try:
            try:
                from .branding import vf_style
            except ImportError:
                from branding import vf_style
            lbl.setPixmap(vf_style.make_logo_pixmap(width=150, height=30))
        except Exception:
            lbl.setText('  Velocity Fibre  ')
            lbl.setStyleSheet(f'color: {_TEXT}; font-weight: 600;')
        lbl.setContentsMargins(4, 0, 10, 0)
        lbl.setToolTip('Velocity Fibre Automation')
        return lbl

    def _make_brand_tile(self):
        """Clickable container: [VF badge] + [Bridge status label].
        Click → opens the VeloGIS Bridge dock widget."""
        from qgis.PyQt.QtWidgets import QWidget

        class ClickableBrand(QWidget):
            def __init__(self, plugin):
                super().__init__()
                self._plugin = plugin
                self.setCursor(Qt.PointingHandCursor)
            def mousePressEvent(self, ev):
                self._plugin._open_bridge_dock()
                super().mousePressEvent(ev)

        container = ClickableBrand(self)
        layout = QHBoxLayout(container)
        layout.setContentsMargins(2, 0, 6, 0)
        layout.setSpacing(6)

        badge = QLabel("VF")
        badge.setAlignment(Qt.AlignCenter)
        badge.setMinimumWidth(32)
        badge.setStyleSheet(
            f"QLabel {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:1,"
            f"stop:0 {_VIOLET}, stop:1 {_BLUE});"
            f" color: white; font-family:'Segoe UI'; font-weight:800;"
            f" font-size:11px; letter-spacing:1px;"
            f" border: 2px solid {_DIM}; border-radius: 4px;"
            f" padding: 3px 8px; }}")
        self._brand_label = badge

        status = QLabel("Bridge …")
        status.setStyleSheet(
            f"QLabel {{ color: {_DIM}; font-family:'Segoe UI';"
            f" font-size:10px; font-weight:600; padding: 2px 4px; }}")
        self._brand_status = status

        layout.addWidget(badge)
        layout.addWidget(status)
        container.setToolTip("VelocityFibre  •  Click to open Bridge dock")
        return container

    # ── HLD score tile (status-bar widget) ───────────────────────────────────
    def _install_hld_score_tile(self):
        """Permanent QStatusBar widget showing live HLD pre-flight score.
        Reads C:/Temp/hld_score.json (written by hld_audit_writer.py)."""
        from qgis.PyQt.QtWidgets import QPushButton
        from qgis.PyQt.QtCore import QTimer
        # Defensive cleanup: remove any orphan tiles left by an unclean prior
        # shutdown. Match by objectName OR by text starting with "HLD:" so we
        # catch tiles created before the objectName patch.
        # NO QApplication.processEvents() — that caused re-entrance / freeze
        # 2026-04-28. setParent(None) + hide() are synchronous enough.
        try:
            mw = self.iface.mainWindow()
            sb = mw.statusBar()
            victims = []
            for child in mw.findChildren(QPushButton):
                if child.objectName() == 'FNAHLDScoreTile' or \
                   (child.text() or '').startswith('HLD:'):
                    victims.append(child)
            for child in victims:
                try:
                    sb.removeWidget(child)
                except Exception:
                    pass
                try:
                    child.setParent(None)  # synchronous detach from layout
                except Exception:
                    pass
                try:
                    child.hide()
                except Exception:
                    pass
                child.deleteLater()
        except Exception:
            pass
        tile = QPushButton("HLD: —")
        tile.setObjectName('FNAHLDScoreTile')
        tile.setFlat(True)
        tile.setCursor(Qt.PointingHandCursor)
        tile.setStyleSheet(
            "QPushButton { color:#A0A4BC; padding:0 10px; font-weight:600;"
            " font-family:'Segoe UI'; font-size:11px; border:none; }"
            "QPushButton:hover { color:#E6E8F0; background:#3A3D5C; border-radius:4px; }"
        )
        tile.clicked.connect(self._refresh_hld_score)
        # First read
        self._hld_score_tile = tile
        self._refresh_hld_score_display()
        # Auto-refresh every 30s
        self._hld_timer = QTimer(self.iface.mainWindow())
        self._hld_timer.setInterval(30_000)
        self._hld_timer.timeout.connect(self._refresh_hld_score_display)
        self._hld_timer.start()
        # Add to status bar
        try:
            sb = self.iface.statusBarIface()
            sb.addPermanentWidget(tile, 0)
        except Exception:
            pass  # status bar API quirks — non-fatal

    def _refresh_hld_score_display(self):
        """Reads JSON, updates the tile label + colour. Does NOT run audit."""
        import json, os
        # Widget may have been deleted (deleteLater) between timer fire and
        # actual C++ destruction — catch the sip RuntimeError and self-clean.
        try:
            tile = self._hld_score_tile
            if tile is None:
                return
            path = 'C:/Temp/hld_score.json'
            if not os.path.exists(path):
                tile.setText("HLD: —")
                return
            try:
                with open(path, encoding='utf8') as f:
                    d = json.load(f)
            except Exception:
                return
            p = d.get('pass', 0); fa = d.get('fail', 0); n = d.get('note', 0)
            if fa == 0 and n == 0:
                color = "#16A34A"
            elif fa == 0:
                color = "#F59E0B"
            else:
                color = "#DC2626"
            tile.setText(f"HLD: {p}✓  {fa}✗  {n}!")
            tile.setStyleSheet(
                f"QPushButton {{ color:{color}; padding:0 10px; font-weight:700;"
                f" font-family:'Segoe UI'; font-size:11px; border:none; }}"
                f"QPushButton:hover {{ background:#3A3D5C; border-radius:4px; }}"
            )
            tile.setToolTip(
                f"Last audit: {d.get('ts','?')[:19]}\n"
                f"PASS: {p} · FAIL: {fa} · NOTE: {n}\n"
                "Click to re-run audit."
            )
        except RuntimeError:
            # C++ object already destroyed — stop the timer so it won't fire again
            try:
                if getattr(self, '_hld_timer', None):
                    self._hld_timer.stop()
            except RuntimeError:
                pass
            self._hld_score_tile = None

    def _refresh_hld_score(self):
        """Click handler — re-runs the audit script in-process.

        IMPORTANT: previously called the bridge via urllib.urlopen which
        deadlocked Qt main thread (bridge queue is processed on same
        thread → caused QGIS freeze + soft crash 2026-04-28).

        Now we just exec() the audit script directly since we're already
        inside QGIS. No HTTP, no thread, no deadlock.
        """
        from qgis.PyQt.QtWidgets import QApplication
        try:
            self.iface.messageBar().pushInfo("HLD score", "Refreshing…")
            QApplication.processEvents()
            with open('C:/Temp/hld_audit_writer.py', encoding='utf8') as f:
                code = f.read()
            # Run in a fresh namespace so we don't pollute plugin globals
            ns = {'__name__': '__hld_audit__'}
            exec(code, ns)
            self._refresh_hld_score_display()
            self.iface.messageBar().pushSuccess(
                "HLD score", "Audit refreshed — see status bar")
        except FileNotFoundError:
            self.iface.messageBar().pushWarning(
                "HLD score", "C:/Temp/hld_audit_writer.py not found")
        except Exception as e:
            self.iface.messageBar().pushWarning(
                "HLD score", f"refresh failed: {type(e).__name__}: {e}")

    # ── Command palette (Ctrl+Shift+P) ──────────────────────────────────────
    def _install_command_palette(self):
        """Bind Ctrl+Shift+P globally — fuzzy-finder for every plugin action."""
        from qgis.PyQt.QtWidgets import QShortcut
        from qgis.PyQt.QtGui import QKeySequence
        sc = QShortcut(QKeySequence("Ctrl+Shift+P"), self.iface.mainWindow())
        sc.setContext(Qt.ApplicationShortcut)
        sc.activated.connect(self._open_command_palette)
        self._cmd_palette_shortcut = sc

    # ── Mirror Eye indicator ──────────────────────────────────────────────────
    def _install_mirror_eye(self):
        """A small clickable eye on the toolbar that shows whether the Canvas
        Mirror server (port 8767) is actively watching JJ's screen.

        States (driven purely by file-mtime — NO HTTP from Qt main thread):
          - PNG age <5s   → 👁 Watching   (green, the eye is "open")
          - PNG age <30s  → 👁 Idle       (amber)
          - PNG age >30s  → 🚫 Off         (red, the eye is "closed")

        Click → opens http://127.0.0.1:8767/ in default browser.
        """
        from qgis.PyQt.QtWidgets import QPushButton
        from qgis.PyQt.QtCore import QTimer
        # Defensive cleanup — same lesson as HLD tile (don't leak on reload)
        try:
            for child in self._toolbar.findChildren(QPushButton):
                if child.objectName() == 'FNAMirrorEye':
                    child.setParent(None)
                    child.hide()
                    child.deleteLater()
        except Exception:
            pass

        eye = QPushButton('👁  …')
        eye.setObjectName('FNAMirrorEye')
        eye.setFlat(True)
        eye.setCursor(Qt.PointingHandCursor)
        eye.clicked.connect(self._open_mirror_viewer)
        eye.setToolTip(
            'Canvas Mirror — live screen capture of QGIS\n'
            'Click to open the viewer in your browser\n'
            'http://127.0.0.1:8767/'
        )
        self._mirror_eye = eye
        # Insert right after the brand tile, before any action
        self._toolbar.addWidget(eye)
        # Poll every 3s — file-mtime check only, no HTTP, no QGIS calls
        self._mirror_eye_timer = QTimer(self.iface.mainWindow())
        self._mirror_eye_timer.setInterval(3000)
        self._mirror_eye_timer.timeout.connect(self._refresh_mirror_eye)
        self._mirror_eye_timer.start()
        self._refresh_mirror_eye()  # initial state

    def _refresh_mirror_eye(self):
        """Update the eye state from PNG mtime. Pure file-stat — no I/O blocking."""
        import os
        import time
        if self._mirror_eye is None:
            return
        path = 'C:/Temp/canvas_mirror.png'
        try:
            if not os.path.exists(path):
                self._mirror_eye.setText('🚫  Mirror Off')
                self._mirror_eye.setStyleSheet(_MIRROR_EYE_OFF_QSS)
                return
            age = time.time() - os.path.getmtime(path)
            if age < 5:
                self._mirror_eye.setText(f'👁  Watching · {int(age)}s')
                self._mirror_eye.setStyleSheet(_MIRROR_EYE_WATCHING_QSS)
            elif age < 30:
                self._mirror_eye.setText(f'👁  Idle · {int(age)}s')
                self._mirror_eye.setStyleSheet(_MIRROR_EYE_IDLE_QSS)
            else:
                self._mirror_eye.setText('🚫  Mirror stale')
                self._mirror_eye.setStyleSheet(_MIRROR_EYE_OFF_QSS)
        except (OSError, RuntimeError):
            return  # widget was destroyed mid-tick; ignore

    def _open_mirror_viewer(self):
        """Click handler — opens the Canvas Mirror viewer in the user's default browser.
        Uses webbrowser stdlib (NOT urlopen — that would deadlock per
        feedback_never_http_to_self_from_qgis.md)."""
        import webbrowser
        webbrowser.open('http://127.0.0.1:8767/')

    def _open_command_palette(self):
        """Modal dialog with a single QLineEdit + filtered list of actions."""
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLineEdit,
                                          QListWidget, QListWidgetItem)
        dlg = QDialog(self.iface.mainWindow())
        dlg.setWindowTitle("FiberNet — Command Palette")
        dlg.setMinimumWidth(520)
        dlg.setStyleSheet(
            "QDialog { background:#1A1B26; }"
            "QLineEdit { background:#24253A; color:#E6E8F0; border:1px solid #3A3D5C;"
            "  border-radius:6px; padding:8px 12px; font-size:14px;"
            "  font-family:'Segoe UI'; }"
            "QLineEdit:focus { border:1px solid #6E56CF; }"
            "QListWidget { background:#1A1B26; color:#E6E8F0; border:none;"
            "  font-family:'Segoe UI'; font-size:12px; padding:4px; }"
            "QListWidget::item { padding:7px 10px; border-radius:4px; }"
            "QListWidget::item:selected { background:#6E56CF; color:#FFFFFF; }"
            "QListWidget::item:hover { background:#3A3D5C; }"
        )
        layout = QVBoxLayout(dlg)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        edit = QLineEdit()
        edit.setPlaceholderText("Type to search actions… (Enter to run, Esc to close)")
        layout.addWidget(edit)

        listw = QListWidget()
        listw.setMaximumHeight(360)
        layout.addWidget(listw)

        # Build action catalogue
        items = []
        for aid, act in self._actions.items():
            text = act.text().replace('&', '')
            tip = act.toolTip() or ''
            ks = act.shortcut().toString() if act.shortcut() else ''
            items.append((aid, act, text, tip, ks))

        def populate(query=''):
            listw.clear()
            q = query.lower().strip()
            scored = []
            for aid, act, text, tip, ks in items:
                hay = f'{aid} {text} {tip}'.lower()
                if not q or all(part in hay for part in q.split()):
                    scored.append((aid, act, text, ks))
            for aid, act, text, ks in scored[:30]:
                label = f'{text}   ⌨ {ks}' if ks else text
                item = QListWidgetItem(label)
                item.setData(Qt.UserRole, aid)
                listw.addItem(item)
            if listw.count() > 0:
                listw.setCurrentRow(0)

        populate()

        def trigger():
            cur = listw.currentItem()
            if cur:
                aid = cur.data(Qt.UserRole)
                dlg.accept()
                act = self._actions.get(aid)
                if act:
                    act.trigger()

        edit.textChanged.connect(populate)
        edit.returnPressed.connect(trigger)
        listw.itemActivated.connect(lambda _it: trigger())

        # Up/down arrow on the QLineEdit moves the list selection
        def edit_key(ev):
            if ev.key() == Qt.Key_Down:
                listw.setCurrentRow(min(listw.currentRow()+1, listw.count()-1))
                return
            if ev.key() == Qt.Key_Up:
                listw.setCurrentRow(max(listw.currentRow()-1, 0))
                return
            QLineEdit.keyPressEvent(edit, ev)
        edit.keyPressEvent = edit_key

        edit.setFocus()
        dlg.exec_()

    # ── Client selector (driven by VeloGIS Bridge dock) ──────────────────────

    def _get_bridge_dock(self):
        """Return the VeloGIS Bridge dock widget, or None if unavailable."""
        try:
            from qgis.utils import plugins as _plugins
            bp = _plugins.get('QGISBridgePlugin')
            if bp is None:
                return None
            for attr in ('_dock', 'dock', '_dock_widget', 'dock_widget'):
                dock = getattr(bp, attr, None)
                if dock is not None:
                    return dock
        except Exception:
            pass
        return None

    def _lock_dock_to_client(self, client: str):
        """Lock (or unlock) the bridge dock client buttons to match the project."""
        dock = self._get_bridge_dock()
        if dock is None:
            return
        try:
            if client:
                dock.set_client_locked(client.upper())
            else:
                dock.unlock_client()
        except AttributeError:
            pass  # older bridge plugin without locking support

    def _connect_bridge_client_signal(self) -> bool:
        """Connect to bridge dock client_changed signal. Returns True on success."""
        try:
            dock = self._get_bridge_dock()
            if dock is None:
                return False
            dock.client_changed.connect(self._rebuild_automation_group)
            print('[FiberNet] Bridge client_changed signal connected ✓')
            # Restore toolbar state from current dock selection
            current = getattr(dock, 'active_client', '')
            if current:
                self._rebuild_automation_group(current)
            return True
        except Exception as e:
            print(f'[FiberNet] Bridge signal connect failed: {e}')
            return False

    _VUMA_STEPS = [
        ('1 · Setup Layers',      'vuma_step_01'),
        ('1b · Fetch Data',       'vuma_step_01b'),
        ('1c · Erven Generator',  'vuma_step_01c'),
        ('2 · Tag Buildings',     'vuma_step_02'),
        ('3 · Demand Points',     'vuma_step_03'),
        ('4 · PON Zones',         'vuma_step_04'),
        ('5 · Place Nodes',       'vuma_step_05'),
        ('6 · Route Cables',      'vuma_step_06'),
        ('7 · Auto-Name',         'vuma_step_07'),
        ('8 · Attributes',        'vuma_step_08'),
        ('9 · QA Check',          'vuma_step_09'),
        ('10 · Export',           'vuma_step_10'),
    ]
    _FT_STEPS = [
        ('1 · Label Poles',       'ft_step_01'),
        ('2 · Distribution Cable','ft_step_02'),
        ('3 · Secondary Cable',   'ft_step_03'),
        ('4 · Enclosure',         'ft_step_04'),
        ('5 · PON Zones',         'ft_step_05'),
        ('6 · Apply PON Order',   'ft_step_06'),
        ('7 · Pole Thickness',    'ft_step_07'),
        ('8 · RC Update',         'ft_step_08'),
        ('9 · QA Report',         'ft_step_09'),
        ('10 · Export',           'ft_step_10'),
    ]
    _HEROTEL_STEPS = [
        ('1 · Setup Layers',      'herotel_step_01'),
        ('2 · Fetch Data',        'herotel_step_02'),
        ('3 · Place ONTs',        'herotel_step_03'),
        ('4 · Design Network',    'herotel_step_04'),
        ('5 · QA Check',          'herotel_step_05'),
        ('6 · Export',            'herotel_step_06'),
    ]

    def _update_toolbar_for_client(self, client):
        """Show/hide toolbar buttons based on selected client.

        client=None  → fresh project: show ONLY brand + Setup Project (clean UX for planners)
        client='vuma'→ show vuma + both; hide ft + dev
        client='ft'  → show ft + both; hide vuma + dev
        client='dev' → show everything (JJ's dev mode — not a real client value)
        """
        c = (client or '').lower()
        no_client = (c == '')

        # Menu-group dropdown buttons (Labelling, Build FT 1-7, Audit & QA)
        # Use the QWidgetAction (from tb.addWidget) for correct toolbar visibility
        for gid, meta in GROUPS.items():
            grp_client = meta.get('client', 'both')
            act = self._group_acts.get(gid)
            btn = self._group_btns.get(gid)
            if no_client:
                visible = False  # hide all groups until client is chosen
            else:
                visible = (grp_client == 'both' or grp_client == c)
            if act is not None:
                act.setVisible(visible)
            if btn is not None:
                btn.setVisible(visible)
                if visible and btn.styleSheet() == '':
                    # Apply client brand colour to this group button
                    if grp_client == 'vuma':
                        btn.setStyleSheet(_VUMA_BTN_QSS)
                    elif grp_client == 'ft':
                        btn.setStyleSheet(_FT_BTN_QSS)
                    elif grp_client == 'herotel':
                        btn.setStyleSheet(_HEROTEL_BTN_QSS)

        # Show/hide absorbed fibretime_tools buttons — they are FT-only
        ft_active = (c == 'ft')
        # QToolButton menus: must hide via the QWidgetAction returned by addWidget(),
        # not the button itself — toolbar visibility is controlled by the action wrapper.
        for act in getattr(self, '_absorbed_ft_widget_acts', []):
            try:
                act.setVisible(ft_active)
            except (RuntimeError, AttributeError):
                pass
        # Re-apply FT styling when shown
        if ft_active:
            for w in self._absorbed_ft_widgets:
                try:
                    if w.styleSheet() == '':
                        w.setStyleSheet(_FT_BTN_QSS)
                except (RuntimeError, AttributeError):
                    pass
        # Plain QActions — hide via the action itself (most reliable)
        for act in getattr(self, '_absorbed_ft_actions', []):
            try:
                act.setVisible(ft_active)
            except (RuntimeError, AttributeError):
                pass

        # All inline actions — apply per-item client visibility
        for entry in TOOLBAR_SPEC:
            item_client = entry.get('client', 'both')
            act = self._actions.get(entry['id'])
            if act is None:
                continue
            if item_client == 'dev':
                visible = False  # dev tools always hidden from planners
            elif item_client == 'both':
                visible = True   # always visible regardless of client selection
            elif item_client == 'none':
                # Client-selector buttons: show ONLY when no client is chosen
                visible = no_client
                # Apply brand styling while visible
                if visible and self._toolbar:
                    w = self._toolbar.widgetForAction(act)
                    if w:
                        qss = (_VUMA_BTN_QSS if entry['id'] == 'select_vuma'
                               else _FT_BTN_QSS)
                        try:
                            w.setStyleSheet(qss)
                        except (RuntimeError, AttributeError):
                            pass
            elif no_client:
                # Hide everything else on a fresh project (client selectors + New Project only)
                visible = False
            else:
                visible = (item_client == c)
            act.setVisible(visible)
            if self._toolbar:
                w = self._toolbar.widgetForAction(act)
                if w:
                    try:
                        w.setVisible(visible)
                    except (RuntimeError, AttributeError):
                        pass

    def _rebuild_automation_group(self, client: str):
        """Swap the automation toolbar section for the selected client."""
        from qgis.PyQt.QtWidgets import QToolButton, QMenu
        from qgis.PyQt.QtCore import Qt

        # Normalise client strings
        client = client.upper() if client else ''
        if client == 'FIBRETIME':
            client = 'FT'
        if client not in ('VUMA', 'FT', 'HEROTEL'):
            client = ''

        tb = self._toolbar

        # Show/hide fixed toolbar buttons for this client
        self._update_toolbar_for_client(client.lower() if client else '')

        # Remove previous automation widgets
        if self._automation_action is not None:
            tb.removeAction(self._automation_action)
            self._automation_action = None
        if self._automation_sep is not None:
            tb.removeAction(self._automation_sep)
            self._automation_sep = None
        if self._automation_widget is not None:
            self._automation_widget.deleteLater()
            self._automation_widget = None

        # Update SESSION
        try:
            from fibre_automation.startup import SESSION
            if client == 'VUMA':
                SESSION['client'] = 'VUMA'
            elif client == 'FT':
                SESSION['client'] = 'FT'
            elif client == 'HEROTEL':
                SESSION['client'] = 'HEROTEL'
            else:
                SESSION['client'] = None
        except Exception:
            pass

        if not client:
            return

        # Build step list + colours
        if client == 'VUMA':
            steps     = self._VUMA_STEPS
            btn_label = 'VUMA'
            run_key   = 'vuma_run_all'
            run_label = '⚡ Run All Steps'
            btn_qss   = _VUMA_BTN_QSS
        elif client == 'HEROTEL':
            steps     = self._HEROTEL_STEPS
            btn_label = 'herotel'
            run_key   = 'herotel_run_all'
            run_label = '⚡ Run All Steps'
            btn_qss   = _HEROTEL_BTN_QSS
        else:
            steps     = self._FT_STEPS
            btn_label = 'fibertime'
            run_key   = 'ft_run_all'
            run_label = '⚡ Run All Steps'
            btn_qss   = _FT_BTN_QSS

        # Dropdown button
        btn = QToolButton(tb)
        btn.setText(f'{btn_label} ▾')
        btn.setPopupMode(QToolButton.InstantPopup)
        btn.setToolButtonStyle(Qt.ToolButtonTextOnly)
        btn.setStyleSheet(btn_qss)

        menu = QMenu(btn)
        menu.setStyleSheet(
            f'QMenu {{ background: {_PANEL}; color: {_TEXT};'
            f' border: 1px solid {_BORDER}; padding: 4px; }}'
            f'QMenu::item {{ padding: 5px 18px; border-radius: 3px; }}'
            f'QMenu::item:selected {{ background: {_ACCENT}; color: {_BG}; }}'
            f'QMenu::separator {{ height: 1px; background: {_BORDER}; margin: 4px 8px; }}'
        )

        try:
            from fibre_automation.startup import STEP_MAP
        except Exception:
            STEP_MAP = {}

        for label, key in steps:
            action = menu.addAction(label)
            fn = STEP_MAP.get(key)
            if fn:
                action.triggered.connect(fn)
            else:
                action.setEnabled(False)

        menu.addSeparator()
        run_action = menu.addAction(run_label)
        run_fn = STEP_MAP.get(run_key)
        if run_fn:
            run_action.triggered.connect(run_fn)
        else:
            run_action.setEnabled(False)

        btn.setMenu(menu)
        self._automation_widget = btn

        # Insert BEFORE the erven_pipe action so it's always visible,
        # not buried after the absorbed fibretime_tools buttons.
        anchor = self._actions.get('erven_pipe')
        if anchor is not None:
            self._automation_action = tb.insertWidget(anchor, btn)
        else:
            self._automation_action = tb.addWidget(btn)

        btn.show()

    def _open_bridge_dock(self):
        """Find the VeloGIS Bridge QDockWidget and show/raise it.
        Falls back to searching by title if the plugin instance isn't reachable."""
        from qgis.PyQt.QtWidgets import QDockWidget
        try:
            # Try via plugin registry first
            from qgis.utils import plugins as _plugins
            bp = _plugins.get('QGISBridgePlugin')
            if bp is not None:
                # Bridge plugin may expose its dock as _dock / dock / _dock_widget
                for attr in ('_dock', 'dock', '_dock_widget', 'dock_widget'):
                    dock = getattr(bp, attr, None)
                    if dock is not None:
                        dock.setVisible(True)
                        dock.raise_()
                        return
        except Exception:
            pass
        # Fallback: search by title
        for dock in self.iface.mainWindow().findChildren(QDockWidget):
            title = dock.windowTitle() or ""
            if "VeloGIS" in title or "Bridge" in title:
                dock.setVisible(True)
                dock.raise_()
                return
        self.iface.messageBar().pushWarning(
            "Bridge", "VeloGIS Bridge dock not found — is QGISBridgePlugin loaded?")

    # ── Algorithm / script / macro runners ───────────────────────────────────
    def _log_and_push_critical(self, where, exc):
        """Log a failure to the error log AND surface it on the message bar
        with the Report-a-Problem pointer. Use in every except handler that
        a teammate can hit — a flashed message without a log entry is
        un-debuggable from their side."""
        try:
            try:
                from . import error_reporter
            except ImportError:
                import error_reporter
            error_reporter.log_error(where, exc)
        except Exception:
            pass
        self.iface.messageBar().pushCritical(
            where,
            f'{exc} — logged. Velocity Fibre menu → Report a Problem '
            'to send it to support.')

    def _run_algo(self, algo_id, entry_id):
        """Open the Processing dialog so user can tweak params."""
        import processing
        act = self._actions.get(entry_id)
        if act: act.setEnabled(False)
        self.iface.messageBar().pushMessage(
            entry_id, f"Running {algo_id} …", level=0, duration=0)
        QApplication.processEvents()
        try:
            processing.execAlgorithmDialog(algo_id, {})
            self.iface.messageBar().pushSuccess(entry_id, f"{algo_id} ✓")
        except Exception as e:
            self._log_and_push_critical(f'algorithm {algo_id}', e)
        finally:
            if act: act.setEnabled(True)

    def _run_script(self, script_path, entry_id):
        # Resolve robustly: the spec path is the dev location; on a team install fall back to the
        # copy bundled inside the plugin (same basename). Never fail with a cryptic file-not-found.
        if not os.path.exists(script_path):
            alt = os.path.join(os.path.dirname(__file__), os.path.basename(script_path))
            if os.path.exists(alt):
                script_path = alt
            else:
                self.iface.messageBar().pushWarning(
                    entry_id, f"{os.path.basename(script_path)} not found (not bundled).")
                return
        from qgis.PyQt.QtCore import Qt
        act = self._actions.get(entry_id)
        if act: act.setEnabled(False)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        self.iface.messageBar().pushMessage(
            entry_id, f"Running {os.path.basename(script_path)} …",
            level=0, duration=0)
        QApplication.processEvents()
        try:
            exec(open(script_path, encoding='utf-8').read(),
                 {'__name__': '__audit_script__'})
            self.iface.messageBar().pushSuccess(
                entry_id, f"{os.path.basename(script_path)} ✓ (Ctrl+Alt+P for output)")
        except Exception as e:
            self._log_and_push_critical(entry_id, e)
        finally:
            QApplication.restoreOverrideCursor()
            if act: act.setEnabled(True)

    def _run_clean_buildings(self, silent_if_missing=False):
        """Auto-discover Buildings + Erven layers and run cleanbuildings (1 building per erven).

        silent_if_missing: if True, return quietly when layers are absent or empty
                           (used for auto-fire at project startup for all 3 clients).
        """
        import processing
        from qgis.core import QgsProject, QgsWkbTypes, QgsProcessingFeedback
        from qgis.PyQt.QtWidgets import QProgressBar

        # --- Layer discovery: works for Vuma, Fibertime and HeroTel ---
        buildings_lyr = None
        erven_lyr = None
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                if lyr.geometryType() != QgsWkbTypes.PolygonGeometry:
                    continue
            except Exception:
                continue
            name_lower = lyr.name().lower()
            if 'building' in name_lower and buildings_lyr is None:
                buildings_lyr = lyr
            elif ('erven' in name_lower or name_lower.startswith('erven')) and erven_lyr is None:
                erven_lyr = lyr

        if buildings_lyr is None or erven_lyr is None:
            if not silent_if_missing:
                missing = []
                if buildings_lyr is None:
                    missing.append('Buildings')
                if erven_lyr is None:
                    missing.append('Erven')
                self.iface.messageBar().pushWarning(
                    'Clean Buildings',
                    f"Layer(s) not found: {', '.join(missing)}. Run Setup / Erven Generator first."
                )
            return

        total = buildings_lyr.featureCount()
        if total == 0:
            if not silent_if_missing:
                self.iface.messageBar().pushInfo(
                    'Clean Buildings', 'Buildings layer is empty — nothing to clean.'
                )
            return

        erven_count = erven_lyr.featureCount()

        # --- Embed a live progress bar in the message bar ---
        msg_item = self.iface.messageBar().createMessage(
            'Clean Buildings',
            f'Cleaning {total:,} buildings across {erven_count:,} erven…'
        )
        prog = QProgressBar()
        prog.setMinimum(0)
        prog.setMaximum(100)
        prog.setValue(0)
        prog.setFixedWidth(200)
        prog.setFormat('%p%')
        prog.setTextVisible(True)
        msg_item.layout().addWidget(prog)
        self.iface.messageBar().pushWidget(msg_item, level=0, duration=0)
        QApplication.processEvents()

        # --- Custom feedback wired to the progress bar ---
        class _ProgressFeedback(QgsProcessingFeedback):
            def setProgress(self, progress):
                super().setProgress(progress)
                prog.setValue(int(progress))
                QApplication.processEvents()

        feedback = _ProgressFeedback()

        try:
            processing.run('fibernetwork:cleanbuildings', {
                'BUILDINGS': buildings_lyr,
                'ERVENS':    erven_lyr,
            }, feedback=feedback)
            remaining = buildings_lyr.featureCount()
            removed = total - remaining
            self.iface.messageBar().clearWidgets()
            self.iface.messageBar().pushSuccess(
                'Clean Buildings',
                f'Done — {removed:,} duplicate(s) removed, {remaining:,} buildings kept (1 per erven).'
            )
        except Exception as exc:
            self.iface.messageBar().clearWidgets()
            self._log_and_push_critical('Clean Buildings', exc)

    def _run_ft_pipeline(self):
        """Run FT1..7 (incl. FT4b) sequentially."""
        import processing
        pipeline = [
            ("FT1 Label Poles",            "fibernetwork:ft_label_poles"),
            ("FT2 Distribution Cable",     "fibernetwork:ft_label_distribution_cable"),
            ("FT3 Secondary Cable",        "fibernetwork:ft_label_secondary_cable"),
            ("FT4 Enclosure",              "fibernetwork:ft_label_enclosure"),
            ("FT4b STS Splitters",         "fibernetwork:ft_label_sts_splitters"),
            ("FT5 Generate PON Zones",     "fibernetwork:ft_generate_pon_zones"),
            ("FT6 Apply PON Order",        "fibernetwork:ft_apply_pon_order"),
            ("FT7 Pole Thickness",         "fibernetwork:ft_pole_thickness"),
        ]
        from qgis.PyQt.QtCore import Qt
        try:
            try:
                from .ux import StepProgress
            except ImportError:
                from ux import StepProgress
        except Exception:
            StepProgress = None
        act = self._actions.get("ft_all")
        if act: act.setEnabled(False)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        ran = 0
        try:
            if StepProgress is not None:
                with StepProgress(self.iface, 'Run All FT 1→7',
                                  [n for n, _ in pipeline]) as prog:
                    for name, algo in pipeline:
                        if prog.canceled:
                            break
                        prog.step(name)
                        processing.run(algo, {})
                        ran += 1
                    prog.done()
            else:
                for name, algo in pipeline:
                    self.iface.messageBar().pushMessage(
                        "FT 1..7", f"{name} …", level=0, duration=0)
                    QApplication.processEvents()
                    processing.run(algo, {})
                    ran += 1
            if ran == len(pipeline):
                self.iface.messageBar().pushSuccess(
                    "FT 1..7", f"✓ Ran all {ran} algorithms successfully")
            else:
                self.iface.messageBar().pushWarning(
                    "FT 1..7", f"Stopped after {ran}/{len(pipeline)} (cancelled)")
        except Exception as e:
            self._log_and_push_critical(f"FT 1..7 (step {ran + 1})", e)
        finally:
            QApplication.restoreOverrideCursor()
            if act: act.setEnabled(True)

    def _run_span_check(self):
        """Pole-to-pole span checker (v6, 2026-04-20).

        Produces a 'Span Violations' memory layer with one pink line per
        offending span. Thresholds:
          Drop / Spare Drop: 55 m · Distribution / Secondary / Primary: 70 m

        How it works:
          - Walks each v1 cable segment-by-segment.
          - For each segment's straight line, finds every pole within 5 m.
            (Matches physical reality: a cable running A→B is clamped to any
            pole its line passes within 5 m of, even if no vertex is drawn
            at that pole.)
          - Concatenates hits in along-cable order; collapses adjacent dupes
            (same pid at seg boundary) while preserving zig-zag re-visits.
          - For each consecutive pair, measures TRUE GEODESIC (ellipsoidal)
            distance via QgsDistanceArea (WGS84) — matches QGIS Measure
            tool. Prior versions used planar 111320 m/°, which over-inflated
            longitude by ~12% at MOA latitude.
          - Cables with <2 poles detected fall back to straight-line distance
            between first and last cable vertex (method='straight-endpoints').
        """
        from qgis.core import (QgsSpatialIndex, QgsFeature, QgsGeometry,
                                QgsVectorLayer, QgsField, QgsLineSymbol,
                                QgsRectangle, QgsDistanceArea,
                                QgsCoordinateReferenceSystem)
        from qgis.PyQt.QtCore import QMetaType
        import math
        M_DEG = 111320.0   # rough latitude metres per degree (dy only)
        SNAP_M = 5.0
        SNAP_DEG = SNAP_M / M_DEG

        # v6 (2026-04-20): use ellipsoidal distance via QgsDistanceArea to match
        # what QGIS Measure tool reports. Prior versions treated longitude and
        # latitude as equal metres-per-degree which inflated spans ~12% at MOA
        # latitude (cos(-26.74°) ≈ 0.893). Fix: compute dx using cos(lat), or
        # use QgsDistanceArea for true geodesic distance.
        _da = QgsDistanceArea()
        _da.setEllipsoid("WGS84")
        _da.setSourceCrs(QgsCoordinateReferenceSystem("EPSG:4326"),
                         QgsProject.instance().transformContext())

        def _geodesic_m(pa, pb):
            """True ellipsoidal metres between two WGS84 points."""
            return _da.measureLine([pa, pb])

        def _seg_dist_m(pt_xy, a, b):
            """Perpendicular distance pt→segment(a,b) in metres (corrected)."""
            seg = QgsGeometry.fromPolylineXY([a, b])
            # For distance-to-segment we still use planar approx but with the
            # longitude correction applied. For short cable segments this is
            # accurate to better than 1 cm.
            d_deg = seg.distance(QgsGeometry.fromPointXY(pt_xy))
            cos_lat = math.cos(math.radians((a.y()+b.y())/2))
            # Planar distance mixes dx and dy; use geometric mean scale.
            return d_deg * M_DEG * cos_lat  # conservative: use lon scale
        def _seg_along_m(pt_xy, a, b):
            ax, ay = a.x(), a.y(); bx, by = b.x(), b.y()
            dx, dy = (bx-ax), (by-ay)
            seg_len2 = dx*dx + dy*dy
            if seg_len2 == 0: return 0.0
            t = max(0.0, min(1.0, ((pt_xy.x()-ax)*dx + (pt_xy.y()-ay)*dy) / seg_len2))
            return t * _geodesic_m(a, b)
        THRESH = {
            "drop cable v1":         55.0,
            "spare drop cable v1":   55.0,
            "distribution cable v1": 70.0,
            "secondary cable v1":    70.0,
            "primary cable v1":      70.0,
        }
        act = self._actions.get("span_check")
        if act: act.setEnabled(False)
        self.iface.messageBar().pushMessage(
            "Span Check", "Scanning pole-to-pole spans …", level=0, duration=0)
        QApplication.processEvents()
        try:
            proj = QgsProject.instance()
            pole_lyr = next((l for l in proj.mapLayers().values()
                             if l.name().lower() == "poles v1"), None)
            if not pole_lyr:
                self.iface.messageBar().pushCritical(
                    "Span Check", "Poles v1 layer not found.")
                return
            pole_index = QgsSpatialIndex()
            pole_pt = {}
            for f in pole_lyr.getFeatures():
                g = f.geometry()
                if not g or g.isEmpty(): continue
                pole_pt[f.id()] = (str(f["Label"] or "").strip(), g.asPoint())
                pf = QgsFeature(f.id())
                pf.setGeometry(g)
                pole_index.addFeature(pf)

            # remove existing violation layer
            for l in list(proj.mapLayers().values()):
                if l.name() == "Span Violations":
                    proj.removeMapLayer(l.id())

            crs = pole_lyr.crs().authid()
            mem = QgsVectorLayer(f"LineString?crs={crs}", "Span Violations", "memory")
            mp = mem.dataProvider()
            mp.addAttributes([
                QgsField("source",     QMetaType.Type.QString),
                QgsField("cable_lbl",  QMetaType.Type.QString),
                QgsField("pole_a",     QMetaType.Type.QString),
                QgsField("pole_b",     QMetaType.Type.QString),
                QgsField("span_m",     QMetaType.Type.Double),
                QgsField("threshold",  QMetaType.Type.Double),
                QgsField("excess_m",   QMetaType.Type.Double),
                QgsField("method",     QMetaType.Type.QString),
            ])
            mem.updateFields()

            feats = []
            per_layer = {}
            for lname, max_span in THRESH.items():
                lyr = next((l for l in proj.mapLayers().values()
                            if l.name().lower() == lname), None)
                if not lyr: continue
                n_viol = 0
                for f in lyr.getFeatures():
                    g = f.geometry()
                    if not g or g.isEmpty(): continue
                    try: cable_lbl = str(f["label"])
                    except (KeyError, IndexError): cable_lbl = f"fid={f.id()}"
                    lines = g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]
                    for line in lines:
                        if len(line) < 2: continue
                        # v5 (2026-04-20): per-segment-line detection.
                        # A pole is ATTACHED wherever it sits within SNAP_M of a
                        # cable SEGMENT LINE (not just at a drawn vertex). This
                        # matches physical reality: a cable running straight
                        # from A to B is clamped at every pole its line passes
                        # within arm's reach of — even if the drawing only has
                        # vertices at A and B. v4 was too strict (demanded
                        # vertex); v3 had wrong dedup on zigzag.
                        cable_poles = []
                        cum = 0.0
                        for i in range(len(line)-1):
                            a = line[i]; b = line[i+1]
                            seg_len_m = _geodesic_m(a, b)
                            bbox = QgsRectangle(
                                min(a.x(),b.x())-SNAP_DEG, min(a.y(),b.y())-SNAP_DEG,
                                max(a.x(),b.x())+SNAP_DEG, max(a.y(),b.y())+SNAP_DEG)
                            sp = []
                            for pid in pole_index.intersects(bbox):
                                lbl, ppt = pole_pt[pid]
                                if _seg_dist_m(ppt, a, b) < SNAP_M:
                                    sp.append((_seg_along_m(ppt, a, b), lbl, ppt, pid))
                            sp.sort()
                            for along, lbl, ppt, pid in sp:
                                cable_poles.append((cum + along, lbl, ppt, pid))
                            cum += seg_len_m

                        # Collapse IMMEDIATELY consecutive same-pid entries
                        # (same pole detected at seg boundary). Preserves
                        # re-visits on zigzag loops.
                        collapsed = []
                        for entry in cable_poles:
                            if collapsed and collapsed[-1][3] == entry[3]:
                                continue
                            collapsed.append(entry)

                        if len(collapsed) < 2:
                            pa = line[0]; pb = line[-1]
                            span = _geodesic_m(pa, pb)
                            if span > max_span:
                                nf = QgsFeature(mem.fields())
                                nf.setGeometry(QgsGeometry.fromPolylineXY([pa, pb]))
                                nf.setAttributes([lyr.name(), cable_lbl, "", "",
                                                  round(span,1), max_span,
                                                  round(span-max_span,1),
                                                  "straight-endpoints"])
                                feats.append(nf); n_viol += 1
                            continue
                        for j in range(len(collapsed)-1):
                            _, la, pa, _ = collapsed[j]
                            _, lb, pb, _ = collapsed[j+1]
                            span = _geodesic_m(pa, pb)
                            if span > max_span:
                                nf = QgsFeature(mem.fields())
                                nf.setGeometry(QgsGeometry.fromPolylineXY([pa, pb]))
                                nf.setAttributes([lyr.name(), cable_lbl, la, lb,
                                                  round(span,1), max_span,
                                                  round(span-max_span,1),
                                                  "pole-to-pole"])
                                feats.append(nf); n_viol += 1
                per_layer[lyr.name()] = n_viol

            mp.addFeatures(feats)
            mem.updateExtents()
            sym = QgsLineSymbol.createSimple({"color": "#ff0066", "width": "1.5",
                                              "capstyle": "round"})
            mem.renderer().setSymbol(sym)
            proj.addMapLayer(mem)
            if feats:
                self.iface.mapCanvas().setExtent(mem.extent().buffered(50 / M_DEG))
            self.iface.mapCanvas().refresh()

            summary = " · ".join(f"{k.replace(' v1','')}:{v}"
                                 for k, v in per_layer.items() if v > 0)
            self.iface.messageBar().pushSuccess(
                "Span Check", f"✓ {len(feats)} violations — {summary or 'none'}")
        except Exception as e:
            self._log_and_push_critical("Span Check", e)
        finally:
            if act: act.setEnabled(True)

    def _run_update_layers(self):
        """Run the post-edit attribute refresh pipeline."""
        act = self._actions.get("update_layers")
        if act: act.setEnabled(False)
        self.iface.messageBar().pushMessage(
            "Update Layers", "Running attribute refresh across layers …",
            level=0, duration=0)
        QApplication.processEvents()
        scripts = [
            "C:/Temp/prod_strtfeat_fix.py",
            "C:/Temp/drop_fix.py",
            "C:/Temp/sdrop_strtfeat_fix.py",
            "C:/Temp/ont_fix.py",
            "C:/Temp/sts_full_fix.py",
        ]
        try:
            ok = 0; failed = []; missing = []
            for s in scripts:
                if not os.path.exists(s):
                    missing.append(os.path.basename(s)); continue
                try:
                    exec(open(s, encoding='utf-8').read(), {'__name__': '__update__'})
                    ok += 1
                except Exception as e:
                    # Per-script try/except — one failing script shouldn't kill the chain
                    failed.append(f"{os.path.basename(s)}: {type(e).__name__}: {e}")
            if failed:
                self.iface.messageBar().pushWarning(
                    "Update Layers",
                    f"{ok}/{len(scripts)} OK · {len(failed)} failed · {len(missing)} missing — check Console")
                from qgis.core import QgsMessageLog
                for line in failed:
                    QgsMessageLog.logMessage(line, "Update Layers", level=2)
            else:
                self.iface.messageBar().pushSuccess(
                    "Update Layers",
                    f"✓ Refreshed {ok}/{len(scripts)} scripts" +
                    (f" ({len(missing)} missing)" if missing else ""))
        except Exception as e:
            self._log_and_push_critical("Update Layers", e)
        finally:
            if act: act.setEnabled(True)

    # ── Direct callbacks (used by tools + quick actions) ─────────────────────
    def _select_client_vuma(self):
        """Toolbar client-selector: set client to VUMA and trigger dock update."""
        dock = self._get_bridge_dock()
        if dock:
            try:
                dock._select_client('VUMA')
                return
            except Exception:
                pass
        # Fallback — no dock available, update toolbar directly
        self._rebuild_automation_group('VUMA')
        self._lock_dock_to_client('VUMA')

    def _select_client_ft(self):
        """Toolbar client-selector: set client to FT and trigger dock update."""
        dock = self._get_bridge_dock()
        if dock:
            try:
                dock._select_client('FT')
                return
            except Exception:
                pass
        self._rebuild_automation_group('FT')
        self._lock_dock_to_client('FT')

    def _run_q(self):
        QApplication.clipboard().setText("exec(open('C:/Temp/q.py').read())")
        self.iface.messageBar().pushMessage(
            '⚙️ Run q.py', 'Copied — paste in Python Console (Ctrl+V)',
            level=0, duration=3)

    def _update_from_github(self):
        """One-click 'git pull' on the VeloPlan repo clone + live plugin reload.

        Lets anyone (e.g. a colleague who just pulls) get the newest code from
        GitHub without touching a command line. The repo location is remembered
        in QSettings; first use prompts for it.
        """
        import os
        import shutil
        import subprocess
        from qgis.PyQt.QtCore import QSettings, QTimer
        from qgis.PyQt.QtWidgets import QMessageBox, QFileDialog

        mw = self.iface.mainWindow()
        s = QSettings()
        key = 'FiberNetworkAutomation/repo_path'
        repo = s.value(key, '', type=str)

        def _valid(p):
            return bool(p) and os.path.isdir(os.path.join(p, '.git')) \
                and os.path.isdir(os.path.join(p, 'FiberNetworkAutomation'))

        # First use (or stale path) → ask for the VeloPlan clone folder
        if not _valid(repo):
            picked = QFileDialog.getExistingDirectory(
                mw, 'Select your VeloPlan repo folder (the clone containing .git)')
            if not picked:
                return
            if not _valid(picked):
                QMessageBox.warning(
                    mw, 'Update from GitHub',
                    'That folder is not a VeloPlan git clone.\n'
                    'Pick the folder that contains a ".git" folder and a '
                    '"FiberNetworkAutomation" subfolder.')
                return
            repo = picked
            s.setValue(key, repo)

        # 1. git pull (fast-forward only — clean for pull-only users)
        try:
            res = subprocess.run(
                ['git', '-C', repo, 'pull', '--ff-only'],
                capture_output=True, text=True, timeout=180)
        except FileNotFoundError:
            QMessageBox.critical(mw, 'Update from GitHub',
                                 'Git is not installed / not on PATH.')
            return
        except Exception as e:
            QMessageBox.critical(mw, 'Update from GitHub', f'git pull failed:\n{e}')
            return
        if res.returncode != 0:
            QMessageBox.critical(mw, 'Update from GitHub',
                                 f'git pull failed:\n\n{res.stderr.strip()}')
            return
        pull_msg = (res.stdout.strip() or 'Already up to date.')

        # 2. Copy the updated plugin into the installed location (this folder),
        #    unless the plugin is already running from the clone itself.
        src = os.path.join(repo, 'FiberNetworkAutomation')
        dst = os.path.dirname(os.path.abspath(__file__))
        copied = False
        if os.path.normcase(os.path.normpath(src)) != \
           os.path.normcase(os.path.normpath(dst)):
            try:
                shutil.copytree(
                    src, dst, dirs_exist_ok=True,
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
                copied = True
            except Exception as e:
                QMessageBox.critical(mw, 'Update from GitHub',
                                     f'Pulled OK but copy failed:\n{e}')
                return

        # 3. Reload the plugin AFTER this handler returns (it is part of the
        #    plugin being unloaded), via the 3-step that re-registers the
        #    processing provider (reloadPlugin alone does not).
        def _do_reload():
            try:
                from qgis.utils import unloadPlugin, loadPlugin, startPlugin
                unloadPlugin('FiberNetworkAutomation')
                loadPlugin('FiberNetworkAutomation')
                startPlugin('FiberNetworkAutomation')
                self.iface.messageBar().pushMessage(
                    '⬇ Update', 'Reloaded with the latest code from GitHub.',
                    level=0, duration=4)
            except Exception as e:
                self.iface.messageBar().pushCritical('⬇ Update', f'Reload failed: {e}')

        QMessageBox.information(
            mw, 'Update from GitHub',
            f'{pull_msg}\n\n'
            + ('Plugin files updated. ' if copied else '')
            + 'Reloading FiberNetworkAutomation now…')
        QTimer.singleShot(300, _do_reload)

    def _exec_erven_pipeline(self, action):
        script = r"C:/Users/jjsch/OneDrive - blitzfibre.com/Documents/Workspace/QGIS/run_erven_pipeline.py"
        btn_ids = ("erven_pipe", "erven_continue")
        for bid in btn_ids:
            a = self._actions.get(bid)
            if a: a.setEnabled(False)
        QApplication.processEvents()
        try:
            exec(compile(open(script, encoding="utf-8").read(), script, "exec"),
                 {"__name__": "__main__", "ACTION": action})
        except Exception as e:
            self._log_and_push_critical('Erven Pipeline', e)
        finally:
            for bid in btn_ids:
                a = self._actions.get(bid)
                if a: a.setEnabled(True)

    def _run_erven_pipeline(self):
        self._exec_erven_pipeline("start")

    def _continue_erven_pipeline(self):
        self._exec_erven_pipeline("continue")

    def _open_pole_editor(self):
        if self._pole_editor_panel and self._pole_editor_panel.isVisible():
            self._pole_editor_panel.raise_()
            self._pole_editor_panel.activateWindow()
            return
        lyr = next(
            (l for l in QgsProject.instance().mapLayers().values()
             if 'poles v1' in l.name().lower()),
            None)
        if not lyr:
            self.iface.messageBar().pushWarning('Pole Editor', 'No "poles v1" layer found.')
            return
        self._pole_editor_panel = PoleEditorPanel(self.iface, lyr)
        self._pole_editor_panel.show()
        thick = sum(1 for f in lyr.getFeatures() if str(f['dim2']) == '140-160mm')
        rc    = sum(1 for f in lyr.getFeatures() if 'road crossing' in str(f['thickness_']).lower())
        self.iface.messageBar().pushMessage(
            '🔧 Pole Editor', f'{thick} thick (blue) · {rc} road crossings (green)',
            level=0, duration=4)

    def _open_route_viewer(self):
        if self._route_viewer_panel and self._route_viewer_panel.isVisible():
            self._route_viewer_panel.raise_()
            self._route_viewer_panel.activateWindow()
            return
        self._route_viewer_panel = SpliceRouteViewerPanel(self.iface)
        self._route_viewer_panel.show()
        n = len(self._route_viewer_panel._idx['ports'])
        if n:
            self.iface.messageBar().pushMessage(
                '🔦 Route Viewer',
                f'{n} OLT ports loaded — pick one to light its fibre route.',
                level=0, duration=4)
        else:
            self.iface.messageBar().pushWarning(
                '🔦 Route Viewer',
                'No FTS Splitters layer in this project — open the splice project.')

    def _open_enc_editor(self):
        if self._enc_editor_panel and self._enc_editor_panel.isVisible():
            self._enc_editor_panel.raise_()
            self._enc_editor_panel.activateWindow()
            return
        self._enc_editor_panel = EnclosureEditorPanel(self.iface)
        self._enc_editor_panel.show()
        conn = next((l for l in QgsProject.instance().mapLayers().values()
                     if l.name() == 'Enclosures Connectorised v1'), None)
        splice = next((l for l in QgsProject.instance().mapLayers().values()
                       if l.name() == 'Enclosures Splice v1'), None)
        if not conn and not splice:
            self.iface.messageBar().pushWarning(
                'Enclosure Editor', 'No Enclosure layers found.')
            return
        parts = []
        if conn:
            feats = list(conn.getFeatures())
            n_spur = sum(1 for f in feats if str(f['spec_1']) == 'M16 Microloop')
            parts.append(f'{len(feats) - n_spur} dist · {n_spur} spur')
        if splice:
            feats = list(splice.getFeatures())
            n_cmj = sum(1 for f in feats if str(f['spec_1']) == 'CMJ')
            parts.append(f'{len(feats) - n_cmj} UMJ · {n_cmj} CMJ')
        self.iface.messageBar().pushMessage(
            '🔲 Enclosure Editor', '  |  '.join(parts),
            level=0, duration=4)

    def _snap_canvas(self):
        import subprocess
        path = 'C:/Temp/canvas.png'
        win = self.iface.mainWindow()
        screen = QApplication.primaryScreen()
        pixmap = screen.grabWindow(win.winId())
        if pixmap.width() > 900:
            pixmap = pixmap.scaledToWidth(900, Qt.SmoothTransformation)
        pixmap.save(path, 'JPEG', 82)
        ps1 = r'C:\Temp\canvas_paste.ps1'
        if os.path.exists(ps1):
            subprocess.Popen(
                [r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                 '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ps1],
                creationflags=0x08000000)
        size = os.path.getsize(path)
        self.iface.messageBar().pushMessage(
            '📷 Canvas', f'Sent to Claude  ({size//1024} KB)',
            level=0, duration=3)

    # ── Bridge status poller (brand tile lamp) ───────────────────────────────
    def _start_bridge_poller(self):
        self._bridge_timer = QTimer(self.iface.mainWindow())
        self._bridge_timer.setInterval(3000)  # 3s
        self._bridge_timer.timeout.connect(self._bridge_tick)
        self._bridge_timer.start()
        self._bridge_tick()  # immediate first check

    def _bridge_tick(self):
        """Scan ports 8765-8769 for live bridges, then verify the CURRENT port
        (from bridge_port.txt) is among them.

        Green  = current port is in the list of open bridge ports AND QGISBridgePlugin is loaded.
        Red    = current port is NOT a working bridge, even if other ports are open.

        Tooltip lists all available ports so user can switch to one.

        Note: socket.connect_ex() is used because urllib to our own bridge
        would deadlock (HTTP handler needs main thread we're blocking).
        Debouncing: 2 fails before flipping red."""
        if not self._brand_label:
            return
        import socket
        from qgis.utils import plugins as _plugins

        # Current port: prefer the LOCAL bridge plugin's actual bound port (so
        # each QGIS instance shows its own port correctly — bridge_port.txt is
        # shared across processes and can't distinguish them).
        current_port = None
        try:
            bp = _plugins.get('QGISBridgePlugin')
            if bp is not None and getattr(bp, '_server', None) is not None:
                current_port = int(bp._server.port)
        except Exception:
            pass
        if current_port is None:
            try:
                with open('C:/Temp/bridge_port.txt', 'r') as f:
                    current_port = int(f.read().strip())
            except Exception:
                current_port = 8766

        # Scan 8765-8769 for open ports (TCP)
        available_ports = []
        for p in range(8765, 8770):
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(0.2)
                if s.connect_ex(('127.0.0.1', p)) == 0:
                    available_ports.append(p)
                s.close()
            except Exception:
                pass

        bridge_plugin_loaded = _plugins.get('QGISBridgePlugin') is not None
        current_is_valid = current_port in available_ports
        alive_now = current_is_valid and bridge_plugin_loaded

        # Debounce: 2 consecutive fails before flipping red
        if alive_now:
            self._bridge_fail_streak = 0
            display_alive = True
        else:
            self._bridge_fail_streak += 1
            if self._bridge_fail_streak < 2 and self._bridge_last_shown_alive is True:
                display_alive = True
            else:
                display_alive = False

        try:
            self._set_bridge_status(display_alive, current_port, available_ports)
            self._bridge_last_shown_alive = display_alive
        except RuntimeError:
            pass

    def _set_bridge_status(self, alive, port, available_ports=None):
        if not self._brand_label: return
        available_ports = available_ports or []
        colour = _GREEN if alive else _RED

        # Badge: VF gradient, border reflects status
        self._brand_label.setStyleSheet(
            f"QLabel {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:1,"
            f"stop:0 {_VIOLET}, stop:1 {_BLUE});"
            f" color: white; font-family:'Segoe UI'; font-weight:800;"
            f" font-size:11px; letter-spacing:1px;"
            f" border: 2px solid {colour}; border-radius: 4px;"
            f" padding: 3px 8px; }}")

        # Status label: text + colour
        if getattr(self, '_brand_status', None):
            txt = f"Bridge Online · {port}" if alive else f"Bridge Offline · {port}"
            self._brand_status.setText(txt)
            self._brand_status.setStyleSheet(
                f"QLabel {{ color: {colour}; font-family:'Segoe UI';"
                f" font-size:10px; font-weight:700; padding: 2px 4px; }}")

        # Tooltip on the container — lists available ports for easy switching
        parent = self._brand_label.parentWidget()
        if parent is not None:
            if available_ports:
                avail_str = ", ".join(str(p) for p in available_ports)
                tip = (f"VelocityFibre Bridge\n"
                       f"Current: port {port}  ({'Online ✓' if alive else 'Offline ✗'})\n"
                       f"Available ports: {avail_str}\n\n"
                       f"Click to open Bridge dock (switch ports)")
            else:
                tip = (f"VelocityFibre Bridge\n"
                       f"Current: port {port}  (Offline ✗)\n"
                       f"No open bridge ports found (scanned 8765-8769)\n\n"
                       f"Click to open Bridge dock")
            try: parent.setToolTip(tip)
            except RuntimeError: pass

    # ── Retire the redundant fibretime_tools plugin (its toolbar buttons) ────
    def _retire_fibretime_tools(self):
        """Permanently remove the separate fibretime_tools toolbar buttons: disable that plugin
        (won't load on restart), unload it now, and remove any leftover FibretimeToolbar.
        Everything those buttons did lives in the published VeloPlan plugin."""
        try:
            from qgis.core import QgsSettings
            from qgis.PyQt.QtWidgets import QToolBar
            import qgis.utils as U
            QgsSettings().setValue('PythonPlugins/fibretime_tools', False)
            if 'fibretime_tools' in U.plugins:
                try:
                    U.unloadPlugin('fibretime_tools')
                except Exception:
                    pass
            for tb in self.iface.mainWindow().findChildren(QToolBar):
                if tb.objectName() == 'FibretimeToolbar' or tb.windowTitle() == 'Fibertime Tools':
                    self.iface.mainWindow().removeToolBar(tb)
                    tb.setParent(None); tb.deleteLater()
            # erven_qgis_plugin is absorbed as erven_detection/ (Phase 1) — retire it too
            QgsSettings().setValue('PythonPlugins/erven_qgis_plugin', False)
            if 'erven_qgis_plugin' in U.plugins:
                try:
                    U.unloadPlugin('erven_qgis_plugin')
                except Exception:
                    pass
        except Exception as e:
            print(f'[FiberNet] retire fibretime_tools failed: {e}')

    # ── Watchdog — re-absorb if fibretime toolbar reappears ──────────────────
    def _watchdog_check(self):
        try:
            from qgis.PyQt.QtWidgets import QToolBar
            for tb in self.iface.mainWindow().findChildren(QToolBar):
                if tb.objectName() == "FibretimeToolbar" and tb.isVisible() and tb.actions():
                    # A fresh visible fibretime toolbar — re-absorb (idempotent)
                    self._fibretime_absorbed = False
                    self._absorb_attempts = 0
                    self._absorb_fibretime_toolbar()
                    return
        except RuntimeError:
            pass

    # ── Absorb fibretime_tools toolbar into ours ─────────────────────────────
    def _absorb_fibretime_toolbar(self):
        """Move actions from FibretimeToolbar + VelocityFibreLogoBar onto our
        toolbar so the user has a single, flowing bar. Hides the originals."""
        from qgis.PyQt.QtWidgets import QToolBar
        if not self._toolbar:
            return
        mw = self.iface.mainWindow()
        ft_bar = None
        logo_bar = None
        for tb in mw.findChildren(QToolBar):
            n = tb.objectName()
            if n == "FibretimeToolbar":
                ft_bar = tb
            elif n == "VelocityFibreLogoBar":
                logo_bar = tb
        if ft_bar is None:
            # fibretime_tools not yet loaded — retry up to 10 times at 1s intervals
            self._absorb_attempts += 1
            if self._absorb_attempts < 10:
                from qgis.PyQt.QtCore import QTimer
                QTimer.singleShot(1000, self._absorb_fibretime_toolbar)
            return
        # Guard — don't absorb twice
        if getattr(self, "_fibretime_absorbed", False):
            return
        self._fibretime_absorbed = True
        self._absorbed_from = (ft_bar, logo_bar)

        # Idempotent absorb: collect texts already present on our toolbar
        # so re-runs don't duplicate. Also skip fibretime duplicates we retire.
        from qgis.PyQt.QtWidgets import QToolButton
        from qgis.PyQt.QtCore import Qt as _Qt
        # Fibertime items retired in favour of FNA equivalents (stronger impl).
        RETIRED = {"📏  Check Long Spans", "New Project"}
        existing = set()
        for a in self._toolbar.actions():
            t = a.text()
            if not t:
                w = self._toolbar.widgetForAction(a)
                if w is not None and hasattr(w, "text"):
                    t = w.text()
            if t: existing.add(t.strip())

        self._absorbed_ft_widgets = []       # QToolButtons (for styling)
        self._absorbed_ft_widget_acts = []   # QWidgetActions from addWidget() — use for visibility
        self._absorbed_ft_actions = []       # plain QActions — hidden/shown via act.setVisible()
        added = False
        for act in list(ft_bar.actions()):
            if isinstance(act, QWidgetAction):
                w = act.defaultWidget()
                if isinstance(w, QToolButton) and w.menu() is not None:
                    label = (w.text() or "").strip()
                    if label in existing:
                        continue
                    added = True
                    new_btn = QToolButton(self._toolbar)
                    new_btn.setText(w.text())
                    new_btn.setIcon(w.icon())
                    new_btn.setToolTip(w.toolTip())
                    new_btn.setPopupMode(QToolButton.InstantPopup)
                    new_btn.setToolButtonStyle(_Qt.ToolButtonTextBesideIcon)
                    new_btn.setMenu(w.menu())
                    new_btn.setStyleSheet(_FT_BTN_QSS)
                    widget_act = self._toolbar.addWidget(new_btn)
                    self._absorbed_ft_widgets.append(new_btn)
                    self._absorbed_ft_widget_acts.append(widget_act)
                    existing.add(label)
            else:
                label = (act.text() or "").strip()
                if label in existing or label in RETIRED:
                    continue
                added = True
                self._toolbar.addAction(act)
                # Style the button if we can get a handle to it
                w = self._toolbar.widgetForAction(act)
                if w is not None and hasattr(w, "setToolButtonStyle"):
                    try:
                        w.setToolButtonStyle(_Qt.ToolButtonTextBesideIcon)
                        w.setStyleSheet(_FT_BTN_QSS)
                    except Exception:
                        pass
                # Always store the action — setVisible on the action is reliable
                self._absorbed_ft_actions.append(act)
                existing.add(label)

        # Fully remove the original toolbars — not just hide, so QGIS can't re-show
        mw = self.iface.mainWindow()
        try: mw.removeToolBar(ft_bar)
        except RuntimeError: pass
        try: ft_bar.hide()
        except RuntimeError: pass
        if logo_bar is not None:
            try: mw.removeToolBar(logo_bar)
            except RuntimeError: pass
            try: logo_bar.hide()
            except RuntimeError: pass

        # Re-apply current client visibility so absorbed buttons respect Vuma/FT/None
        try:
            from fibre_automation.startup import SESSION
            current_client = (SESSION.get('client') or '').lower()
            self._update_toolbar_for_client(current_client or None)
        except Exception:
            self._update_toolbar_for_client(None)

    # ── Project session persistence ───────────────────────────────────────────
    def _on_project_read(self, *_args):
        """Restore SESSION from the project that was just opened."""
        try:
            from fibre_automation.startup import load_session_from_project, SESSION
            if load_session_from_project():
                client = SESSION.get('client') or ''
                print(f"[FiberNet] Session restored: {client} / {SESSION.get('area_code')}")
                self._rebuild_automation_group(client)
                # Lock the bridge dock to this project's client
                self._lock_dock_to_client(client)
            else:
                # No stored session → collapse to Setup Project only
                self._update_toolbar_for_client(None)
                self._lock_dock_to_client('')
        except Exception as e:
            print(f'[FiberNet] session restore failed: {e}')

    def _on_project_cleared(self, *_args):
        """Clear SESSION when the project is cleared (startup or File → New).
        The welcome dialog is triggered separately by iface.newProjectCreated,
        which only fires on explicit user-initiated new project, not on startup.
        """
        try:
            from fibre_automation.startup import clear_session
            clear_session()
            print('[FiberNet] Session cleared (new project)')
        except Exception as e:
            print(f'[FiberNet] session clear failed: {e}')
        # Collapse toolbar to brand only
        try:
            self._update_toolbar_for_client(None)
            self._rebuild_automation_group('')
        except Exception:
            pass
        # Unlock the bridge dock so the user can pick a client for the new project
        self._lock_dock_to_client('')

    def _show_welcome_dialog(self):
        """Centered project-setup wizard — always shown on every new/blank project.

        Non-modal so the planner can drag-and-drop an AOI shapefile into the
        Layers panel while the dialog is open.  A blinking arrow to the left of
        the dialog points at the Layers panel with "Drag & drop AOI" text.
        When a polygon layer lands in the project the AOI combo is auto-filled
        and the arrow dismissed.  On "Start Project" the full step-01 pipeline
        (layers + basemap + Overture) is kicked off for the chosen client.
        """
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout,
                                          QPushButton, QLabel, QLineEdit,
                                          QComboBox, QFrame, QSizePolicy,
                                          QDockWidget)
        from qgis.PyQt.QtCore import Qt, QPoint, QTimer

        mw = self.iface.mainWindow()

        # ── Kill any existing welcome dialog + arrow (singleton pattern) ──────
        _prev = getattr(self, '_welcome_dlg', None)
        if _prev is not None:
            try:
                _prev.hide()
                _prev.close()
                _prev.deleteLater()
            except RuntimeError:
                pass
            self._welcome_dlg = None

        for _old in mw.findChildren(QLabel):
            if _old.objectName() == "FNAWelcomeArrow":
                try:
                    _old.hide()
                    _old.deleteLater()
                except RuntimeError:
                    pass
        from qgis.PyQt.QtGui import QFont
        from qgis.core import (QgsCoordinateReferenceSystem, QgsWkbTypes,
                                QgsProject)

        _VUMA_PROJECTS = [
            ("— select project —",         "",      ""),
            ("Malmesbury",                  "MALM",  "Z1"),
            ("Praktiseer",                  "PRAK",  "Z1"),
            ("Ipelegeng",                   "IPG",   "Z1"),
            ("Driekoppies",                 "DRIEK", "Z1"),
            ("Kamatsamo",                   "KAM",   "Z1"),
            ("Schweizer-Reneke",            "SCHW",  "Z1"),
            ("Mothibistad",                 "MOTH",  "Z1"),
            ("Kuruman",                     "KUR",   "Z1"),
            ("Wrenchville",                 "WREN",  "Z1"),
            ("Zastron",                     "ZAST",  "Z1"),
            ("Tonga",                       "TONG",  "Z1"),
            ("Other (enter code manually)", "",      ""),
        ]
        _CRS_OPTIONS = [
            ("EPSG:4326",  "WGS 84 — geographic (default)"),
            ("EPSG:32734", "UTM Zone 34S"),
            ("EPSG:32735", "UTM Zone 35S"),
            ("EPSG:2048",  "Hartbeesthoek94 / LO19"),
        ]

        _chosen = {"client": None}

        # ── Blinking arrow overlay (parented to main window, NOT the dialog) ─
        arrow = QLabel(mw)
        arrow.setObjectName("FNAWelcomeArrow")
        arrow.setText("◀\nDrag & drop\nyour AOI here")
        arrow.setAlignment(Qt.AlignCenter)
        arrow.setFont(QFont("Segoe UI", 12, QFont.Bold))
        arrow.setStyleSheet(
            "QLabel { background: rgba(0,0,0,210); color: #FFFFFF;"
            " border: 2px solid #FFFFFF; border-radius: 10px;"
            " padding: 12px 14px; }"
        )
        arrow.adjustSize()
        arrow.hide()  # positioned + shown after dialog is placed

        _blink_bright = [True]
        _blink_timer = QTimer(mw)
        _blink_timer.setInterval(550)

        def _arrow_blink():
            _blink_bright[0] = not _blink_bright[0]
            try:
                if _blink_bright[0]:
                    arrow.setStyleSheet(
                        "QLabel { background: rgba(0,0,0,210); color: #FFFFFF;"
                        " border: 2px solid #FFFFFF; border-radius: 10px;"
                        " padding: 12px 14px; }"
                    )
                else:
                    arrow.setStyleSheet(
                        "QLabel { background: rgba(40,40,60,160); color: #AAAAAA;"
                        " border: 2px solid #666688; border-radius: 10px;"
                        " padding: 12px 14px; }"
                    )
            except RuntimeError:
                _blink_timer.stop()

        _blink_timer.timeout.connect(_arrow_blink)

        def _stop_arrow():
            """Stop blinking; turn green with AOI-detected confirmation."""
            _blink_timer.stop()
            try:
                arrow.setText("✓  AOI detected")
                arrow.setFont(QFont("Segoe UI", 13, QFont.Bold))
                arrow.setStyleSheet(
                    "QLabel { background: #14532d; color: #86efac;"
                    " border: 2px solid #22c55e; border-radius: 10px;"
                    " padding: 14px 20px; }"
                )
                arrow.adjustSize()
                # Re-centre vertically in the gap after resize
                try:
                    arrow_local = arrow.pos()
                    arrow.move(arrow_local.x(), arrow_local.y())
                except Exception:
                    pass
            except RuntimeError:
                pass

        # ── Dialog (non-modal, always-on-top) ─────────────────────────────────
        dlg = QDialog(mw)
        dlg.setWindowTitle("VeloGIS — New Project")
        dlg.setWindowFlags(
            Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool
        )
        dlg.setModal(False)
        dlg.setMinimumWidth(560)
        self._welcome_dlg = dlg  # singleton ref — killed on next call

        _QSS = """
        QDialog {
            background: #0E1525;
            border: 1px solid #1A2840;
            border-radius: 20px;
        }
        QLabel { color: #E6E8F0; font-family: 'Segoe UI'; }
        QLabel#hdr {
            font-size: 22px; font-weight: 900; color: #FFFFFF;
            letter-spacing: 0.5px;
        }
        QLabel#sub  { font-size: 11px; color: #3E4A62; }
        QLabel#field_lbl {
            font-size: 10px; color: #3E4A62; font-weight: 700;
            letter-spacing: 1.5px;
        }
        QLabel#client_desc { font-size: 10px; color: #3E4A62; }
        QLabel#section_label {
            font-size: 9px; color: #2A3450; font-weight: 700;
            letter-spacing: 2px;
        }

        QLineEdit, QComboBox {
            background: #091220; color: #B0BAD0;
            border: 1px solid #1A2840; border-radius: 8px;
            padding: 8px 12px; font-family: 'Segoe UI'; font-size: 12px;
        }
        QLineEdit:focus, QComboBox:focus {
            border: 1.5px solid #6050CC;
            background: #0D1830;
        }
        QComboBox QAbstractItemView {
            background: #091220; color: #B0BAD0;
            border: 1px solid #1A2840;
            selection-background-color: #1A2840;
        }
        QComboBox::drop-down { border: none; }

        /* ── Client card wrappers ─────────────────────────── */
        QFrame#card_vuma {
            background: #141830;
            border: 1.5px solid #251535;
            border-radius: 14px;
        }
        QFrame#card_vuma[active="true"] {
            border: 2px solid #FF0090;
            background: #180F28;
        }
        QFrame#card_ft {
            background: #141830;
            border: 1.5px solid #122030;
            border-radius: 14px;
        }
        QFrame#card_ft[active="true"] {
            border: 2px solid #2ABFCC;
            background: #0C1C28;
        }
        QFrame#card_herotel {
            background: #141830;
            border: 1.5px solid #221410;
            border-radius: 14px;
        }
        QFrame#card_herotel[active="true"] {
            border: 2px solid #FF4500;
            background: #1C0E08;
        }

        /* ── VUMA  hot magenta ─────────────────────────────── */
        QPushButton#vuma_sel {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #FF1FA0, stop:1 #CC0072);
            color: white; border: none; border-radius: 10px;
            font-family: 'Segoe UI'; font-size: 17px; font-weight: 900;
            letter-spacing: 5px;
            padding: 22px 16px; min-width: 130px;
        }
        QPushButton#vuma_sel:hover {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #FF44B4, stop:1 #FF0090);
        }

        /* ── fibertime  yellow + cyan columns ─────────────── */
        QPushButton#ft_sel {
            background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0    #2ABFCC, stop:0.25 #2ABFCC,
                stop:0.251 #FFE619, stop:0.749 #FFE619,
                stop:0.75 #2ABFCC, stop:1    #2ABFCC);
            color: #1A3040; border: none; border-radius: 10px;
            font-family: 'Segoe UI'; font-size: 17px; font-weight: 800;
            padding: 22px 16px; min-width: 130px;
        }
        QPushButton#ft_sel:hover {
            background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0    #40D8E4, stop:0.25 #40D8E4,
                stop:0.251 #FFF040, stop:0.749 #FFF040,
                stop:0.75 #40D8E4, stop:1    #40D8E4);
        }

        /* ── herotel  bright orange ────────────────────────── */
        QPushButton#herotel_sel {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #FF5500, stop:1 #CC3A00);
            color: white; border: none; border-radius: 10px;
            font-family: 'Segoe UI'; font-size: 17px; font-weight: 700;
            padding: 22px 16px; min-width: 130px;
        }
        QPushButton#herotel_sel:hover {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #FF6E1F, stop:1 #FF4400);
        }

        /* ── form container ─────────────────────────────────── */
        QFrame#form_box {
            background: #0A1220;
            border: 1px solid #1A2840;
            border-radius: 12px;
        }

        /* ── action buttons ─────────────────────────────────── */
        QPushButton#start_btn {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #7E66D8, stop:1 #5A48C0);
            color: white; border: none; border-radius: 9px;
            font-family: 'Segoe UI'; font-size: 13px; font-weight: 700;
            padding: 12px 40px; min-width: 160px;
        }
        QPushButton#start_btn:hover {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #9278E0, stop:1 #7E66D8);
        }
        QPushButton#start_btn:disabled { background: #101828; color: #252B3A; }
        QPushButton#cancel_btn {
            background: transparent; color: #303850;
            border: 1px solid #1A2840; border-radius: 7px;
            font-family: 'Segoe UI'; font-size: 11px; padding: 8px 20px;
        }
        QPushButton#cancel_btn:hover { color: #6070A0; border-color: #304060; }

        QFrame#accent_bar {
            background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0 #FF0090, stop:0.33 #7060D8,
                stop:0.66 #FFE619, stop:1 #FF4500);
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
        }
        """
        dlg.setStyleSheet(_QSS)


        root = QVBoxLayout(dlg)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── 5px rainbow accent bar pinned to top ──────────────────────────────
        accent_bar = QFrame()
        accent_bar.setObjectName("accent_bar")
        accent_bar.setFixedHeight(5)
        root.addWidget(accent_bar)

        # ── Inner layout carries side + bottom margins ─────────────────────────
        inner = QVBoxLayout()
        inner.setContentsMargins(32, 20, 32, 28)
        inner.setSpacing(0)
        root.addLayout(inner)

        hdr = QLabel("New Project")
        hdr.setObjectName("hdr")
        hdr.setAlignment(Qt.AlignCenter)
        inner.addWidget(hdr)
        inner.addSpacing(5)

        sub = QLabel("Select your network client, then fill in the project details.")
        sub.setObjectName("sub")
        sub.setAlignment(Qt.AlignCenter)
        sub.setWordWrap(True)
        inner.addWidget(sub)
        inner.addSpacing(20)

        # ── Client card builder ───────────────────────────────────────────────
        def _make_shadow(blur=20, dy=5, alpha=130):
            from qgis.PyQt.QtWidgets import QGraphicsDropShadowEffect
            from qgis.PyQt.QtGui import QColor as _QColor
            sh = QGraphicsDropShadowEffect()
            sh.setBlurRadius(blur)
            sh.setOffset(0, dy)
            sh.setColor(_QColor(0, 0, 0, alpha))
            return sh

        sel_row = QHBoxLayout()
        sel_row.setSpacing(12)

        # VUMA card
        vuma_card = QFrame()
        vuma_card.setObjectName("card_vuma")
        vuma_card.setProperty("active", "false")
        vuma_card.setGraphicsEffect(_make_shadow())
        _vc = QVBoxLayout(vuma_card)
        _vc.setContentsMargins(8, 8, 8, 10)
        _vc.setSpacing(7)
        vuma_btn = QPushButton("VUMA")
        vuma_btn.setObjectName("vuma_sel")
        vuma_btn.setCursor(Qt.PointingHandCursor)
        vuma_sub = QLabel("GPON aerial · Britelink / VTC")
        vuma_sub.setObjectName("client_desc")
        vuma_sub.setAlignment(Qt.AlignCenter)
        _vc.addWidget(vuma_btn)
        _vc.addWidget(vuma_sub)
        sel_row.addWidget(vuma_card)

        # fibertime card
        ft_card = QFrame()
        ft_card.setObjectName("card_ft")
        ft_card.setProperty("active", "false")
        ft_card.setGraphicsEffect(_make_shadow())
        _fc = QVBoxLayout(ft_card)
        _fc.setContentsMargins(8, 8, 8, 10)
        _fc.setSpacing(7)
        ft_btn = QPushButton("fibertime")
        ft_btn.setObjectName("ft_sel")
        ft_btn.setCursor(Qt.PointingHandCursor)
        ft_sub = QLabel("Informal settlement · VelocityFibre")
        ft_sub.setObjectName("client_desc")
        ft_sub.setAlignment(Qt.AlignCenter)
        _fc.addWidget(ft_btn)
        _fc.addWidget(ft_sub)
        sel_row.addWidget(ft_card)

        # HeroTel card
        herotel_card = QFrame()
        herotel_card.setObjectName("card_herotel")
        herotel_card.setProperty("active", "false")
        herotel_card.setGraphicsEffect(_make_shadow())
        _hc = QVBoxLayout(herotel_card)
        _hc.setContentsMargins(8, 8, 8, 10)
        _hc.setSpacing(7)
        herotel_btn = QPushButton("herotel")
        herotel_btn.setObjectName("herotel_sel")
        herotel_btn.setCursor(Qt.PointingHandCursor)
        herotel_sub = QLabel("FTTH aerial · SDU & MDU")
        herotel_sub.setObjectName("client_desc")
        herotel_sub.setAlignment(Qt.AlignCenter)
        _hc.addWidget(herotel_btn)
        _hc.addWidget(herotel_sub)
        sel_row.addWidget(herotel_card)

        inner.addLayout(sel_row)
        inner.addSpacing(18)

        # ── Project details section label ─────────────────────────────────────
        sec_lbl = QLabel("PROJECT DETAILS")
        sec_lbl.setObjectName("section_label")
        inner.addWidget(sec_lbl)
        inner.addSpacing(6)

        # ── Glass form container ───────────────────────────────────────────────
        form_box = QFrame()
        form_box.setObjectName("form_box")
        form_inner = QVBoxLayout(form_box)
        form_inner.setContentsMargins(14, 12, 14, 12)
        form_inner.setSpacing(8)

        def _field_row(label_txt, widget):
            row = QHBoxLayout()
            lbl = QLabel(label_txt)
            lbl.setObjectName("field_lbl")
            lbl.setFixedWidth(90)
            row.addWidget(lbl)
            row.addWidget(widget)
            return row

        proj_combo = QComboBox()
        proj_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        for disp, _code, _zone in _VUMA_PROJECTS:
            proj_combo.addItem(disp)
        proj_row_widget = QFrame()
        proj_row_widget.setLayout(_field_row("Project:", proj_combo))
        proj_row_widget.setVisible(False)
        form_inner.addWidget(proj_row_widget)

        area_edit = QLineEdit()
        area_edit.setPlaceholderText("e.g. MALM, PRAK, MOA")
        area_edit.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        form_inner.addLayout(_field_row("Area Code:", area_edit))

        zone_edit = QLineEdit()
        zone_edit.setPlaceholderText("e.g. Z1, Z2  (Vuma only)")
        zone_edit.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        zone_row_frame = QFrame()
        zone_row_frame.setLayout(_field_row("Zone:", zone_edit))
        zone_row_frame.setVisible(False)
        form_inner.addWidget(zone_row_frame)

        crs_combo = QComboBox()
        crs_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        for authid, desc in _CRS_OPTIONS:
            crs_combo.addItem(f"{authid}  —  {desc}", userData=authid)
        form_inner.addLayout(_field_row("CRS:", crs_combo))

        # AOI layer picker — pre-populated + updated live when layers are dropped
        aoi_combo = QComboBox()
        aoi_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        aoi_combo.setToolTip(
            "Drag a shapefile into the Layers panel — it auto-fills here.\n"
            "An AOI must be selected before you can start the project."
        )
        aoi_combo.addItem("— drag & drop AOI shapefile —", userData=None)
        _sys_names = {
            "Erven", "Buildings", "P2 AOI Poly", "Aggregation Polygon", "Block",
            "Poles", "Dome Joint", "Spur Joints", "Feeder Joints", "Demand Points",
        }
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name() in _sys_names:
                continue
            try:
                gtype = lyr.geometryType()
            except Exception:
                continue
            if gtype == QgsWkbTypes.PolygonGeometry and lyr.featureCount() > 0:
                aoi_combo.addItem(
                    f"{lyr.name()}  ({lyr.featureCount()} features)",
                    userData=lyr.id(),
                )
        form_inner.addLayout(_field_row("AOI Layer:", aoi_combo))

        aoi_error_lbl = QLabel("⚠  AOI required — drag & drop a shapefile into the Layers panel")
        aoi_error_lbl.setStyleSheet(
            "QLabel { color: #EF4444; font-size: 11px; font-style: italic;"
            " padding-left: 96px; margin-top: 0px; }"
        )
        aoi_error_lbl.setVisible(False)
        form_inner.addWidget(aoi_error_lbl)

        # ── Project folder ────────────────────────────────────────────────────
        from qgis.PyQt.QtWidgets import QFileDialog
        folder_row = QHBoxLayout()
        folder_row.setSpacing(6)
        folder_lbl = QLabel("Save Folder:")
        folder_lbl.setObjectName("field_lbl")
        folder_lbl.setFixedWidth(90)
        folder_edit = QLineEdit()
        folder_edit.setPlaceholderText("Choose folder for shapefiles…")
        folder_edit.setReadOnly(True)
        folder_edit.setStyleSheet(
            "QLineEdit { background: #091220; color: #4A5570;"
            " border: 1px solid #1A2840; border-radius: 8px; padding: 8px 12px; }"
            "QLineEdit[populated='true'] { color: #B0BAD0; border-color: #22c55e; }"
        )
        browse_btn = QPushButton("Browse")
        browse_btn.setObjectName("cancel_btn")
        browse_btn.setFixedWidth(72)
        browse_btn.setCursor(Qt.PointingHandCursor)
        folder_row.addWidget(folder_lbl)
        folder_row.addWidget(folder_edit)
        folder_row.addWidget(browse_btn)
        form_inner.addLayout(folder_row)

        inner.addWidget(form_box)
        inner.addSpacing(18)

        def _browse_folder():
            path = QFileDialog.getExistingDirectory(
                dlg, "Select folder for shapefiles"
            )
            if path:
                folder_edit.setText(path)
                folder_edit.setProperty("populated", "true")
                folder_edit.style().unpolish(folder_edit)
                folder_edit.style().polish(folder_edit)

        browse_btn.clicked.connect(_browse_folder)

        act_row = QHBoxLayout()
        act_row.setSpacing(12)
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setObjectName("cancel_btn")
        start_btn = QPushButton("Start Project")
        start_btn.setObjectName("start_btn")
        start_btn.setEnabled(False)
        start_btn.setGraphicsEffect(_make_shadow(blur=14, dy=3, alpha=100))
        act_row.addStretch()
        act_row.addWidget(cancel_btn)
        act_row.addWidget(start_btn)
        inner.addLayout(act_row)

        # ── Logic ─────────────────────────────────────────────────────────────
        def _refresh_card(card, active):
            card.setProperty("active", "true" if active else "false")
            card.style().unpolish(card)
            card.style().polish(card)

        _ACCENT_STYLES = {
            "vuma":      ("stop:0 #FF1FA0, stop:0.5 #CC0072, stop:1 #FF1FA0",),
            "fibretime": ("stop:0 #2ABFCC, stop:0.4 #FFE619, stop:1 #2ABFCC",),
            "herotel":   ("stop:0 #FF5500, stop:0.5 #CC3A00, stop:1 #FF5500",),
        }

        def _on_proj_preset(idx):
            _disp, code, zone = _VUMA_PROJECTS[idx]
            if code:
                area_edit.setText(code)
                zone_edit.setText(zone)

        proj_combo.currentIndexChanged.connect(_on_proj_preset)

        def _select(client):
            _chosen["client"] = client
            is_vuma = client == "vuma"
            _refresh_card(vuma_card, is_vuma)
            _refresh_card(ft_card, client == "fibretime")
            _refresh_card(herotel_card, client == "herotel")
            # Dynamic accent bar — changes to selected client's brand color
            stops = _ACCENT_STYLES.get(client, ("stop:0 #7060D8, stop:1 #7060D8",))[0]
            accent_bar.setStyleSheet(
                f"QFrame#accent_bar {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
                f" {stops}); border-top-left-radius: 20px; border-top-right-radius: 20px; }}"
            )
            proj_row_widget.setVisible(is_vuma)
            zone_row_frame.setVisible(is_vuma)
            if is_vuma:
                area_edit.setPlaceholderText("e.g. MALM, PRAK, MOA")
            elif client == "herotel":
                area_edit.setPlaceholderText("e.g. HRT, KRN, BRK")
            else:
                area_edit.setPlaceholderText("e.g. MOA, VEL")
            _validate()

        # ── AOI validation — blocks Start until a real layer is chosen ──────────
        _AOI_COMBO_ERROR = (
            "QComboBox { background: #1A0808; color: #C0BAD0;"
            " border: 1.5px solid #EF4444; border-radius: 8px; padding: 6px 10px; }"
            "QComboBox::drop-down { border: none; width: 24px; }"
            "QComboBox QAbstractItemView { background: #0D1B2E; color: #B0BAD0;"
            " selection-background-color: #1A2840; }"
        )

        def _validate():
            client = _chosen.get("client")
            has_aoi = aoi_combo.currentData() is not None
            if not client:
                # No client chosen yet — neutral, button already disabled
                aoi_combo.setStyleSheet("")
                aoi_error_lbl.setVisible(False)
                start_btn.setEnabled(False)
            elif not has_aoi:
                # Client chosen but no AOI — show red + block
                aoi_combo.setStyleSheet(_AOI_COMBO_ERROR)
                aoi_error_lbl.setVisible(True)
                start_btn.setEnabled(False)
            else:
                # Both client + AOI — clear and enable
                aoi_combo.setStyleSheet("")
                aoi_error_lbl.setVisible(False)
                start_btn.setEnabled(True)
            _reposition()

        aoi_combo.currentIndexChanged.connect(_validate)

        vuma_btn.clicked.connect(lambda: _select("vuma"))
        ft_btn.clicked.connect(lambda: _select("fibretime"))
        herotel_btn.clicked.connect(lambda: _select("herotel"))

        # ── Live AOI detection — fires when planner drops a shapefile ─────────
        # Do NOT filter by _sys_names here — on a blank project the user's
        # shapefile IS the AOI, even if it happens to share a system name.
        def _on_layers_added(layers):
            for lyr in layers:
                try:
                    gtype = lyr.geometryType()
                except Exception:
                    continue
                if gtype == QgsWkbTypes.PolygonGeometry:
                    label = f"{lyr.name()}  ({lyr.featureCount()} features)"
                    # Avoid duplicates (keyed by layer ID)
                    existing = [aoi_combo.itemData(i) for i in range(aoi_combo.count())]
                    if lyr.id() not in existing:
                        aoi_combo.addItem(label, userData=lyr.id())
                    # Auto-select the newly dropped layer
                    idx = aoi_combo.findData(lyr.id())
                    if idx >= 0:
                        aoi_combo.setCurrentIndex(idx)
                    # Dismiss the blinking arrow — planner has loaded an AOI
                    _stop_arrow()

        QgsProject.instance().layersAdded.connect(_on_layers_added)

        # ── Start Project — save SESSION and kick off step 01 ─────────────────
        _cleaned_up = [False]

        def _cleanup():
            if _cleaned_up[0]:
                return
            _cleaned_up[0] = True
            # Clear singleton ref so next call starts fresh
            if getattr(self, '_welcome_dlg', None) is dlg:
                self._welcome_dlg = None
            _blink_timer.stop()
            try:
                arrow.hide()
                arrow.deleteLater()
            except RuntimeError:
                pass
            try:
                QgsProject.instance().layersAdded.disconnect(_on_layers_added)
            except Exception:
                pass

        def _on_start():
            client = _chosen["client"]
            if not client:
                return
            authid = crs_combo.currentData()
            folder = folder_edit.text().strip() or None

            # Save session if fibre_automation is installed — optional, never blocks dialog close
            try:
                from fibre_automation.startup import SESSION, save_session_to_project
                SESSION.update({
                    "client":         client,
                    "area_code":      area_edit.text().strip().upper() or None,
                    "zone_code":      zone_edit.text().strip() or None,
                    "crs":            QgsCoordinateReferenceSystem(authid),
                    "aoi_source":     aoi_combo.currentData(),
                    "project_folder": folder,
                })
                save_session_to_project()
            except ImportError:
                pass  # fibre_automation not installed — dialog still closes and toolbar rebuilds

            _cleanup()
            dlg.close()
            # Defer post-close work — calling QGIS setup directly from a
            # button click handler while the dialog is being destroyed can
            # cause a Qt access violation.
            _chosen_client = client

            def _post_start():
                try:
                    self._rebuild_automation_group(_chosen_client.upper())
                    self._lock_dock_to_client(_chosen_client.upper())
                except Exception as e:
                    self.iface.messageBar().pushWarning("New Project", f"Toolbar rebuild failed: {e}")
                try:
                    if _chosen_client in ("ft", "fibretime"):
                        from fibre_automation.fibretime.step_01_setup import ft_step_01_setup
                        ft_step_01_setup()
                    elif _chosen_client == "herotel":
                        from fibre_automation.herotel.step_01_setup import herotel_step_01_setup
                        herotel_step_01_setup()
                    else:
                        from fibre_automation.vuma.step_01_setup import vuma_step_01_setup
                        vuma_step_01_setup()
                except Exception as e:
                    self._log_and_push_critical("New Project (Step 01)", e)
                    import traceback
                    traceback.print_exc()

                # Always run clean buildings as the final startup step — silently
                # skips if Buildings / Erven layers are missing or empty.
                self._run_clean_buildings(silent_if_missing=True)

            QTimer.singleShot(50, _post_start)

        start_btn.clicked.connect(_on_start)

        cancel_btn.clicked.connect(lambda: (_cleanup(), dlg.close()))
        dlg.finished.connect(lambda _r: _cleanup())

        # ── Position dialog + arrow ───────────────────────────────────────────
        def _reposition():
            if _cleaned_up[0]:
                return
            dlg.adjustSize()
            # Centre over the map canvas widget, not the full main window
            canvas = self.iface.mapCanvas()
            canvas_tl = canvas.mapToGlobal(canvas.rect().topLeft())
            dlg_x = canvas_tl.x() + (canvas.width() - dlg.width()) // 2
            dlg_y = canvas_tl.y() + (canvas.height() - dlg.height()) // 2
            dlg.move(dlg_x, dlg_y)

            # Find right edge of the Layers dock to anchor the arrow
            mw_geo = mw.geometry()
            layers_right = mw_geo.x() + 230  # default fallback
            try:
                for dw in mw.findChildren(QDockWidget):
                    if "layer" in (dw.windowTitle() or "").lower():
                        pt = dw.mapToGlobal(QPoint(dw.width(), 0))
                        layers_right = pt.x()
                        break
            except Exception:
                pass

            gap_center_x = layers_right + (dlg_x - layers_right) // 2
            try:
                arrow_x = gap_center_x - arrow.width() // 2
                arrow_y = dlg_y + (dlg.height() - arrow.height()) // 2
                # Convert global → main-window-local coords
                arrow_local = mw.mapFromGlobal(QPoint(arrow_x, arrow_y))
                arrow.move(arrow_local)
                arrow.raise_()
                arrow.show()
            except RuntimeError:
                pass  # arrow already deleted after _cleanup()

        _reposition()
        _blink_timer.start()
        dlg.show()

    # ── Unload ────────────────────────────────────────────────────────────────
    def unload(self):
        """Idempotent: safe to call multiple times; swallows C++-deleted-object errors."""
        try:
            if getattr(self, '_update_checker', None) is not None:
                self._update_checker.stop()
                self._update_checker = None
        except Exception:
            pass
        # Disconnect project signals
        try:
            from qgis.core import QgsProject
            QgsProject.instance().readProject.disconnect(self._on_project_read)
            QgsProject.instance().cleared.disconnect(self._on_project_cleared)
        except Exception:
            pass
        try:
            self.iface.newProjectCreated.disconnect(self._on_new_project_created)
        except Exception:
            pass

        # VeloPlan menu
        try:
            if getattr(self, '_velo_menu', None) is not None:
                self.iface.mainWindow().menuBar().removeAction(self._velo_menu.menuAction())
                self._velo_menu.deleteLater()
        except (RuntimeError, AttributeError):
            pass
        self._velo_menu = None

        # Erven Detection dock (ported erven_qgis_plugin panel)
        try:
            if getattr(self, '_erven_detection_panel', None) is not None:
                self.iface.removeDockWidget(self._erven_detection_panel)
                self._erven_detection_panel.deleteLater()
        except (RuntimeError, AttributeError):
            pass
        self._erven_detection_panel = None

        # Timer first — prevent further _bridge_tick calls on deleted widgets
        try:
            if self._bridge_timer:
                self._bridge_timer.stop()
        except RuntimeError:
            pass
        self._bridge_timer = None
        try:
            if getattr(self, "_absorb_watchdog", None):
                self._absorb_watchdog.stop()
        except RuntimeError:
            pass
        self._absorb_watchdog = None

        # HLD tile + timer — every reload was leaking another tile (2026-04-28).
        try:
            if getattr(self, "_hld_timer", None):
                self._hld_timer.stop()
                self._hld_timer.timeout.disconnect()
        except RuntimeError:
            pass
        self._hld_timer = None
        try:
            tile = getattr(self, "_hld_score_tile", None)
            self._hld_score_tile = None   # null FIRST so queued callbacks see None
            if tile is not None:
                self.iface.statusBarIface().removeWidget(tile)
                tile.deleteLater()
        except (RuntimeError, AttributeError):
            self._hld_score_tile = None

        # Command palette shortcut
        try:
            sc = getattr(self, "_cmd_palette_shortcut", None)
            if sc is not None:
                sc.setEnabled(False)
                sc.deleteLater()
        except (RuntimeError, AttributeError):
            pass
        self._cmd_palette_shortcut = None

        # Mirror eye + its timer
        try:
            t = getattr(self, "_mirror_eye_timer", None)
            if t is not None:
                t.stop()
        except RuntimeError:
            pass
        self._mirror_eye_timer = None
        try:
            eye = getattr(self, "_mirror_eye", None)
            if eye is not None:
                eye.setParent(None)
                eye.hide()
                eye.deleteLater()
        except (RuntimeError, AttributeError):
            pass
        self._mirror_eye = None

        try:
            # Prefer the live registry entry over the potentially-dead Python wrapper.
            # If self.provider's C++ object was already deleted (e.g. addProvider failed
            # and QGIS cleaned it up), calling removeProvider(dead_ptr) silently no-ops
            # inside QGIS but leaves the "fibernetwork" key in the C++ map → zombie.
            reg = QgsApplication.processingRegistry()
            live = reg.providerById("fibernetwork")
            target = None
            try:
                if live and live.id() == "fibernetwork":
                    target = live
            except RuntimeError:
                pass
            if target is None and self.provider:
                try:
                    if self.provider.id() == "fibernetwork":
                        target = self.provider
                except RuntimeError:
                    pass
            if target is not None:
                reg.removeProvider(target)
        except Exception:
            pass
        self.provider = None

        # Restore fibretime toolbars we hid during absorb
        try:
            absorbed = getattr(self, "_absorbed_from", None)
            if absorbed:
                for tb in absorbed:
                    if tb is not None:
                        try: tb.show()
                        except RuntimeError: pass
        except Exception:
            pass
        self._absorbed_from = None
        self._fibretime_absorbed = False

        try:
            if self._toolbar:
                self._toolbar.clear()
                self.iface.mainWindow().removeToolBar(self._toolbar)
        except RuntimeError:
            pass
        self._toolbar = None

        try:
            if self._pole_editor_panel:
                self._pole_editor_panel.close()
        except RuntimeError:
            pass
        self._pole_editor_panel = None

        try:
            if self._route_viewer_panel:
                self._route_viewer_panel.close()
        except RuntimeError:
            pass
        self._route_viewer_panel = None

        try:
            if self._home_panel:
                self.iface.removeDockWidget(self._home_panel)
                self._home_panel.deleteLater()
        except RuntimeError:
            pass
        self._home_panel = None

        try:
            if self._np_dock:
                self.iface.removeDockWidget(self._np_dock)
                self._np_dock.deleteLater()
        except RuntimeError:
            pass
        self._np_dock = None

        try:
            if self._enc_editor_panel:
                self._enc_editor_panel.close()
        except RuntimeError:
            pass
        self._enc_editor_panel = None

        self._actions.clear()
        self._brand_label = None
        self._brand_status = None

    # ── Erven Detection (SAM2 + GroundingDINO via erven_mcp) ─────────────────

    def _erven_detect_run(self):
        """AI Detect button — SAM2 building footprints only (Buildings_detected)."""
        self._ai_detect_run(run_tessellation=False)

    def _erven_erven_run(self):
        """AI Erven button — buildings + momepy parcel tessellation (+ Erven_detected)."""
        self._ai_detect_run(run_tessellation=True)

    def _ai_detect_run(self, run_tessellation: bool = False):
        """Shared runner for AI Detect / AI Erven buttons.

        Posts to erven_mcp HTTP server on port 8780, polls progress every 2s,
        calls _erven_detect_on_complete() when done.

        Args:
            run_tessellation: If True, also generate Erven_detected property parcels
                              via momepy enclosed_tessellation (requires roads.json).
        """
        import json as _json
        import urllib.request

        from qgis.PyQt.QtCore import QTimer

        ERVEN_MCP_URL = "http://127.0.0.1:8780"
        iface = self.iface
        label = "AI Erven" if run_tessellation else "AI Detect"

        # ── Check server is up ───────────────────────────────────────────────
        try:
            with urllib.request.urlopen(f"{ERVEN_MCP_URL}/health", timeout=3) as r:
                pass
        except Exception:
            iface.messageBar().pushMessage(
                label,
                "❌ erven_mcp server not running on port 8780.  "
                "Start: cd erven_detection/src && python -m erven_mcp.server --http",
                level=2, duration=20,
            )
            return

        # ── POST /pipeline/run ───────────────────────────────────────────────
        config = {
            "source": "canvas",
            "preset": "sa_formal_low",
            "run_tessellation": run_tessellation,
            "roads_source": "roads_json",
            "roads_json_path": "C:/Temp/roads.json",
        }
        payload = _json.dumps(config).encode("utf-8")
        req = urllib.request.Request(
            f"{ERVEN_MCP_URL}/pipeline/run",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                start_data = _json.loads(resp.read().decode("utf-8"))
        except Exception as exc:
            iface.messageBar().pushMessage(
                label, f"Could not start pipeline: {exc}", level=2, duration=10,
            )
            return

        if not start_data.get("started"):
            msg = start_data.get("message", "Pipeline not started")
            iface.messageBar().pushMessage(label, msg, level=1, duration=8)
            return

        est = "~5–10 min (buildings + erven)" if run_tessellation else "~3–7 min"
        iface.messageBar().pushMessage(
            label,
            f"⏳ SAM2 running… ({est})  Polling every 2s…",
            level=0, duration=120,
        )

        # ── Poll /progress every 2 s ─────────────────────────────────────────
        poll_timer = QTimer()
        poll_timer.setInterval(2000)
        plugin_self = self

        def _poll():
            try:
                with urllib.request.urlopen(
                    f"{ERVEN_MCP_URL}/progress", timeout=3
                ) as r:
                    prog = _json.loads(r.read().decode("utf-8"))
            except Exception:
                return  # transient error — keep polling

            still_running = prog.get("pipeline_running", True)
            step    = prog.get("step", "")
            pct     = int(prog.get("progress", 0) * 100)
            message = prog.get("message", "")

            if still_running:
                iface.messageBar().pushMessage(
                    label,
                    f"[{pct}%] {step}: {message}",
                    level=0, duration=3,
                )
                return

            poll_timer.stop()
            plugin_self._erven_detect_poll_timer = None
            plugin_self._erven_detect_on_complete(run_tessellation=run_tessellation)

        poll_timer.timeout.connect(_poll)
        poll_timer.start()
        self._erven_detect_poll_timer = poll_timer
        self._erven_mcp_url = ERVEN_MCP_URL

    def _erven_detect_on_complete(self, run_tessellation: bool = False):
        """Fetch /pipeline/result and show summary in the status bar."""
        import json as _json
        import urllib.request

        iface = self.iface
        url   = getattr(self, "_erven_mcp_url", "http://127.0.0.1:8780")
        label = "AI Erven" if run_tessellation else "AI Detect"

        try:
            with urllib.request.urlopen(f"{url}/pipeline/result", timeout=5) as r:
                result = _json.loads(r.read().decode("utf-8"))
        except Exception as exc:
            iface.messageBar().pushMessage(
                label, f"Could not fetch result: {exc}", level=2, duration=10,
            )
            return

        error = result.get("error")
        if error:
            failed_step = result.get("failed_step", "unknown")
            iface.messageBar().pushMessage(
                label,
                f"❌ Failed at step '{failed_step}': {error}",
                level=2, duration=15,
            )
            return

        n_buildings = result.get("num_buildings", result.get("num_erven", 0))
        n_erven     = result.get("num_erven", 0)    # only set if tessellation ran
        elapsed     = result.get("elapsed_s", 0)
        summary     = result.get("summary", f"{n_buildings} buildings")

        # Pipeline already loaded layer(s) via the bridge — just refresh canvas
        iface.mapCanvas().refreshAllLayers()
        iface.mapCanvas().refresh()

        if run_tessellation and n_erven:
            layers_msg = f"'Buildings_detected' + 'Erven_detected' ({n_erven} parcels)"
        else:
            layers_msg = "'Buildings_detected'"

        iface.messageBar().pushMessage(
            label,
            f"✅ {summary}  — {layers_msg} added to canvas",
            level=3, duration=15,
        )

    # ──────────────────────────────────────────────────────────────────────────
    # VeloDetect — batch SAM2 building detection over full AOI
    # ──────────────────────────────────────────────────────────────────────────

    def _place_ai_results(self, results, iface_ref):
        """Create 'AI Buildings' polygon + 'AI Centroids' point memory layers.

        Used by VeloDetect (_velo_detect_run).
        results: list of (cx_lon, cx_lat, [(lon, lat), ...])
        """
        from qgis.core import (
            QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY,
            QgsProject, QgsField,
            QgsSingleSymbolRenderer, QgsFillSymbol, QgsMarkerSymbol,
        )
        from qgis.PyQt.QtCore import QVariant

        proj = QgsProject.instance()

        poly_vl = QgsVectorLayer("Polygon?crs=EPSG:4326", "AI Buildings", "memory")
        poly_pr = poly_vl.dataProvider()
        poly_pr.addAttributes([QgsField("idx", QVariant.Int)])
        poly_vl.updateFields()
        poly_feats = []
        for i, (cx, cy, poly_pts) in enumerate(results):
            f = QgsFeature()
            f.setGeometry(QgsGeometry.fromPolygonXY(
                [[QgsPointXY(lon, lat) for lon, lat in poly_pts]]))
            f.setAttributes([i + 1])
            poly_feats.append(f)
        poly_pr.addFeatures(poly_feats)
        poly_vl.updateExtents()
        poly_vl.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple({
            "color": "0,212,255,60", "outline_color": "0,212,255,255",
            "outline_width": "0.5", "outline_width_unit": "MM",
        })))

        pt_vl = QgsVectorLayer("Point?crs=EPSG:4326", "AI Centroids", "memory")
        pt_pr = pt_vl.dataProvider()
        pt_pr.addAttributes([
            QgsField("idx", QVariant.Int),
            QgsField("lon", QVariant.Double),
            QgsField("lat", QVariant.Double),
        ])
        pt_vl.updateFields()
        pt_feats = []
        for i, (cx, cy, _) in enumerate(results):
            f = QgsFeature()
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(cx, cy)))
            f.setAttributes([i + 1, round(cx, 6), round(cy, 6)])
            pt_feats.append(f)
        pt_pr.addFeatures(pt_feats)
        pt_vl.updateExtents()
        pt_vl.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple({
            "name": "circle", "color": "255,210,0,220",
            "size": "2", "size_unit": "MM", "outline_style": "no",
        })))

        for name in ("AI Buildings", "AI Centroids"):
            for old in proj.mapLayersByName(name):
                proj.removeMapLayer(old)
        proj.addMapLayer(poly_vl)
        proj.addMapLayer(pt_vl)

    def _velo_detect_run(self):
        """Tile the full AOI and send each chip to the SAM2 server.

        Renders 512×512 JPEG tiles at 0.3 m/px, POSTs to SAM2 at :8101,
        collects building polygons, deduplicates at tile borders, and places
        results as 'AI Buildings' + 'AI Centroids' memory layers.
        """
        import math
        import json
        import urllib.request
        from qgis.core import (
            QgsProject, QgsMapSettings, QgsMapRendererCustomPainterJob,
            QgsRectangle, QgsGeometry, QgsPointXY,
            QgsCoordinateTransform, QgsCoordinateReferenceSystem,
        )
        from qgis.PyQt.QtCore import QSize, QBuffer, Qt
        from qgis.PyQt.QtGui import QImage, QPainter, QColor
        from qgis.PyQt.QtWidgets import QProgressDialog, QApplication

        SAM2_URL = "http://127.0.0.1:8102/predict"
        GSD_M    = 0.3    # target ground sampling distance (m/pixel)
        TILE_PX  = 512
        MIN_AREA = 50     # min mask area in pixels² (≈15 m² at 0.3 m/px)

        canvas       = self.iface.mapCanvas()
        map_settings = canvas.mapSettings()
        dest_crs     = map_settings.destinationCrs()
        wgs84        = QgsCoordinateReferenceSystem("EPSG:4326")
        proj         = QgsProject.instance()

        # ── 1. Ping SAM2 server ───────────────────────────────────────────────
        try:
            with urllib.request.urlopen(
                    SAM2_URL.replace("/predict", "/health"), timeout=4) as r:
                health = json.loads(r.read())
            if not health.get("model_loaded", False):
                self.iface.messageBar().pushMessage(
                    "AutoDetect",
                    "SAM2 server is up but model not loaded — check server logs.",
                    level=2, duration=10)
                return
        except Exception as exc:
            self.iface.messageBar().pushMessage(
                "AutoDetect",
                f"SAM2 server unreachable at {SAM2_URL}. "
                f"Run: python C:/Temp/sam2_server.py on 192.168.1.150  ({exc})",
                level=2, duration=15)
            return

        # ── 2. Find AOI layer ─────────────────────────────────────────────────
        aoi_geom = None
        aoi_bbox = None
        for name in ("P2 AOI Poly", "AOI", "Mohadin AOI", "AOI Poly"):
            layers = proj.mapLayersByName(name)
            if layers:
                feats = list(layers[0].getFeatures())
                if feats:
                    aoi_geom = feats[0].geometry()
                    if layers[0].crs() != dest_crs:
                        xf = QgsCoordinateTransform(layers[0].crs(), dest_crs, proj)
                        aoi_geom.transform(xf)
                    aoi_bbox = aoi_geom.boundingBox()
                    break

        if aoi_bbox is None:
            # Fall back to current canvas extent
            aoi_bbox = canvas.extent()
            self.iface.messageBar().pushMessage(
                "AutoDetect",
                "No AOI layer found — using current canvas extent as AOI.",
                level=1, duration=6)

        # ── 3. Compute tile grid in CRS units ─────────────────────────────────
        cy = aoi_bbox.center().y()
        if dest_crs.isGeographic():
            m_per_lat = 110574.0
            m_per_lon = 111320.0 * math.cos(math.radians(cy))
            tile_w = (GSD_M * TILE_PX) / m_per_lon
            tile_h = (GSD_M * TILE_PX) / m_per_lat
        else:
            tile_w = tile_h = GSD_M * TILE_PX

        tiles = []
        y = aoi_bbox.yMinimum()
        while y < aoi_bbox.yMaximum():
            x = aoi_bbox.xMinimum()
            while x < aoi_bbox.xMaximum():
                tile_ext = QgsRectangle(x, y, x + tile_w, y + tile_h)
                if aoi_geom is None or aoi_geom.intersects(
                        QgsGeometry.fromRect(tile_ext)):
                    tiles.append(tile_ext)
                x += tile_w
            y += tile_h

        if not tiles:
            self.iface.messageBar().pushMessage(
                "AutoDetect", "No tiles generated — check AOI layer.", level=2, duration=8)
            return

        to_wgs84 = QgsCoordinateTransform(dest_crs, wgs84, proj)

        def _px2geo(px_x, px_y, tile_ext):
            mx = tile_ext.xMinimum() + (px_x / TILE_PX) * tile_ext.width()
            my = tile_ext.yMaximum() - (px_y / TILE_PX) * tile_ext.height()
            try:
                pt = to_wgs84.transform(QgsPointXY(mx, my))
                return (pt.x(), pt.y())
            except Exception:
                return (mx, my)

        # ── 4. Progress dialog ────────────────────────────────────────────────
        prog = QProgressDialog(
            f"AutoDetect — 0 / {len(tiles)} tiles", "Cancel", 0, len(tiles))
        prog.setWindowTitle("VeloDetect — Batch SAM2 Building Detection")
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(0)
        prog.setValue(0)

        # ── 5. Tile → render → POST → collect ────────────────────────────────
        all_results = []
        errors      = 0

        for i, tile_ext in enumerate(tiles):
            QApplication.processEvents()
            if prog.wasCanceled():
                break

            prog.setLabelText(
                f"AutoDetect — {i}/{len(tiles)} tiles  "
                f"({len(all_results)} buildings so far)")

            # Render tile on main thread
            ts = QgsMapSettings()
            ts.setLayers(map_settings.layers())
            ts.setDestinationCrs(dest_crs)
            ts.setExtent(tile_ext)
            ts.setOutputSize(QSize(TILE_PX, TILE_PX))
            ts.setBackgroundColor(map_settings.backgroundColor())
            img = QImage(QSize(TILE_PX, TILE_PX), QImage.Format_ARGB32)
            img.fill(QColor(255, 255, 255))
            painter = QPainter(img)
            job = QgsMapRendererCustomPainterJob(ts, painter)
            job.start()
            job.waitForFinished()
            painter.end()
            buf = QBuffer()
            buf.open(QBuffer.WriteOnly)
            img.save(buf, "JPEG", 85)
            jpg_bytes = bytes(buf.data())
            buf.close()

            # POST to SAM2 (synchronous, main thread — ~200-500 ms on GPU)
            try:
                boundary = b"VeloDetectBoundary7x3"
                body = (
                    b"--" + boundary + b"\r\n"
                    b'Content-Disposition: form-data; name="file"; filename="tile.jpg"\r\n'
                    b"Content-Type: image/jpeg\r\n\r\n"
                    + jpg_bytes
                    + b"\r\n--" + boundary + b"--\r\n"
                )
                req = urllib.request.Request(
                    SAM2_URL, data=body,
                    headers={"Content-Type":
                             f"multipart/form-data; boundary={boundary.decode()}"},
                    method="POST")
                with urllib.request.urlopen(req, timeout=60) as resp:
                    data = json.loads(resp.read())

                for bldg in data.get("buildings", []):
                    if bldg.get("area_px", 0) < MIN_AREA:
                        continue
                    cx_lon, cx_lat = _px2geo(bldg["cx_px"], bldg["cy_px"], tile_ext)
                    poly_pts = [_px2geo(p[0], p[1], tile_ext)
                                for p in bldg.get("polygon_px", [])]
                    if len(poly_pts) < 3:
                        poly_pts = [  # fallback bounding box
                            _px2geo(bldg["cx_px"]-10, bldg["cy_px"]-10, tile_ext),
                            _px2geo(bldg["cx_px"]+10, bldg["cy_px"]-10, tile_ext),
                            _px2geo(bldg["cx_px"]+10, bldg["cy_px"]+10, tile_ext),
                            _px2geo(bldg["cx_px"]-10, bldg["cy_px"]+10, tile_ext),
                        ]
                    all_results.append((cx_lon, cx_lat, poly_pts))

            except Exception as exc:
                errors += 1
                if errors <= 5:
                    print(f"[VeloDetect] tile {i} error: {exc}")

            prog.setValue(i + 1)

        prog.close()

        if not all_results:
            self.iface.messageBar().pushMessage(
                "AutoDetect",
                f"No buildings detected across {len(tiles)} tiles "
                f"({errors} tile errors).",
                level=2, duration=15)
            return

        # ── 6. Deduplicate cross-tile duplicates (5 m grid hash) ─────────────
        kept = []
        seen_cells = set()
        # cell size ≈ 5 m in degrees at Mohadin latitude
        cell_lat = 5.0 / 110574.0
        cell_lon = 5.0 / (111320.0 * math.cos(math.radians(cy)))
        for cx, cl, poly in all_results:
            cell = (int(cx / cell_lon), int(cl / cell_lat))
            if cell not in seen_cells:
                seen_cells.add(cell)
                kept.append((cx, cl, poly))

        # ── 7. Place on canvas ────────────────────────────────────────────────
        self._place_ai_results(kept, self.iface)
        self.iface.messageBar().pushMessage(
            "AutoDetect",
            f"{len(kept)} buildings detected in {len(tiles)} tiles "
            f"({errors} errors). "
            f"Layers: 'AI Buildings' (cyan) · 'AI Centroids' (gold dots).",
            level=3, duration=20)


# ── Bridge colour palette (mirrors bridge_dock.py) ────────────────────────────
_BG      = "#0f1117"
_PANEL   = "#1a1d2e"
_ACCENT  = "#00d4ff"
_VIOLET  = "#7c3aed"
_BLUE    = "#2563eb"
_GREEN   = "#22c55e"
_RED     = "#ef4444"
_TEXT    = "#e2e8f0"
_DIM     = "#64748b"
_BORDER  = "#2d3148"

_DIALOG_BG = f"QDialog {{ background: {_BG}; }}"

_SECTION_LBL = (f"QLabel {{ color: {_DIM}; font-family: 'Segoe UI'; font-size: 9px; "
                f"font-weight: 700; letter-spacing: 1px; }}")

_SUBTITLE_LBL = (f"QLabel {{ color: {_TEXT}; font-family: 'Segoe UI'; font-size: 10px; }}")

_STATUS_LBL = (f"QLabel {{ color: {_DIM}; font-family: Consolas; font-size: 10px; "
               f"padding: 2px; }}")

_HINT_LBL = (f"QLabel {{ color: {_DIM}; font-family: 'Segoe UI'; font-size: 9px; "
             f"border-top: 1px solid {_BORDER}; padding-top: 6px; }}")

_DIVIDER = f"QFrame {{ color: {_BORDER}; }}"

def _btn(bg, hover, pressed, text_col="white"):
    return (f"QPushButton {{ background: {bg}; color: {text_col}; border: none; "
            f"border-radius: 4px; padding: 5px 10px; font-family: 'Segoe UI'; "
            f"font-size: 11px; font-weight: 700; letter-spacing: 0.5px; min-height: 32px; }}"
            f"QPushButton:hover {{ background: {hover}; }}"
            f"QPushButton:pressed {{ background: {pressed}; }}")

_BTN_GREEN   = _btn(_GREEN,   "#16a34a", "#15803d")
_BTN_RED     = _btn(_RED,     "#dc2626", "#991b1b")
_BTN_GRADIENT = (
    f"QPushButton {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
    f"stop:0 {_VIOLET},stop:1 {_BLUE}); color: white; border: none; "
    f"border-radius: 4px; padding: 5px 10px; font-family: 'Segoe UI'; "
    f"font-size: 11px; font-weight: 700; letter-spacing: 0.5px; min-height: 32px; }}"
    f"QPushButton:hover {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
    f"stop:0 #9333ea,stop:1 #3b82f6); }}"
    f"QPushButton:pressed {{ background: {_VIOLET}; }}"
)
_BTN_CLEAR = (
    f"QPushButton {{ background: transparent; color: {_DIM}; "
    f"border: 1px solid {_BORDER}; border-radius: 4px; padding: 5px 10px; "
    f"font-family: 'Segoe UI'; font-size: 11px; min-height: 32px; }}"
    f"QPushButton:hover {{ color: {_TEXT}; border-color: {_ACCENT}; }}"
    f"QPushButton:pressed {{ color: {_ACCENT}; }}"
)
# S5 Slack Bracket — amber/gold gradient so it's visually distinct from the
# violet/blue Thick button. Matches the canvas legend "violet ring = S5" only
# at the outline; the fill is a warm gold to mean "optional manual kit".
_BTN_S5 = (
    "QPushButton { background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
    "stop:0 #f59e0b,stop:1 #d97706); color: white; border: none; "
    "border-radius: 4px; padding: 5px 10px; font-family: 'Segoe UI'; "
    "font-size: 11px; font-weight: 700; letter-spacing: 0.5px; min-height: 32px; }"
    "QPushButton:hover { background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
    "stop:0 #fbbf24,stop:1 #ea580c); }"
    "QPushButton:pressed { background: #d97706; }"
)
_BTN_ORANGE = _btn("#ea7320", "#c2601a", "#a05015")
_BTN_PURPLE = _btn("#9333ea", "#7e22ce", "#6b21a8")
_BTN_CYAN   = _btn("#0891b2", "#0e7490", "#155e75")
_BTN_TEAL   = _btn("#059669", "#047857", "#065f46")

# ── Animated dashed-ring overlay (marching ants around each pole) ─────────────

class _SpinRing(QgsMapCanvasItem):
    """Draws dashed circles at a set of map points with an animated dash
    offset so the dashes appear to travel around the ring (marching ants)."""

    def __init__(self, canvas, color, radius_px, width_px, dash_pattern, tick_ms=80):
        super().__init__(canvas)
        self._canvas = canvas
        self._color = color
        self._radius = float(radius_px)
        self._width = float(width_px)
        self._pattern = list(dash_pattern)
        self._phase = 0.0
        self._points = []
        # Animation timer exists for API compatibility but is NOT started —
        # static dashed rings keep the visual distinction without the per-frame
        # repaint cost.
        self._timer = QTimer()
        self._timer.timeout.connect(self._tick)
        self.setZValue(100)

    def _tick(self):
        pass  # no-op — spin disabled for performance

    def setPoints(self, pts):
        self.prepareGeometryChange()
        self._points = list(pts)
        self.update()

    def setTickInterval(self, ms):
        ms = int(ms)
        if self._timer.interval() != ms:
            self._timer.setInterval(ms)

    def clear(self):
        self.setPoints([])

    def stop(self):
        self._timer.stop()

    def boundingRect(self):
        return self._canvas.sceneRect()

    def paint(self, painter, option=None, widget=None):
        if not self._points:
            return
        pen = QPen(self._color)
        pen.setWidthF(self._width)
        pen.setStyle(Qt.SolidLine)
        pen.setCapStyle(Qt.FlatCap)
        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)
        painter.setRenderHint(QPainter.Antialiasing, True)
        m2p = self._canvas.mapSettings().mapToPixel()
        for p in self._points:
            sp = m2p.transform(p.x(), p.y())
            painter.drawEllipse(QPointF(sp.x(), sp.y()), self._radius, self._radius)


class _NullRing:
    """Stub that accepts the ring API but draws nothing and uses no CPU."""
    def setPoints(self, pts): pass
    def setTickInterval(self, ms): pass
    def clear(self): pass
    def stop(self): pass


class _SpinRingPreview(QLabel):
    """Small animated dashed-ring widget for the panel legend so the preview
    visually matches the canvas overlay (same colour, dash rhythm, and spin)."""

    def __init__(self, color, dash_pattern, diameter_px=22, width_px=2.0, tick_ms=80):
        super().__init__()
        self._color = color
        self._pattern = list(dash_pattern)
        self._diameter = int(diameter_px)
        self._width = float(width_px)
        self._phase = 0.0
        self.setFixedSize(self._diameter + 4, self._diameter + 4)
        self.setStyleSheet('background: transparent;')
        # Spin disabled — static dashed ring in the legend.

    def _tick(self):
        pass

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        pen = QPen(self._color)
        pen.setWidthF(self._width)
        pen.setStyle(Qt.SolidLine)
        pen.setCapStyle(Qt.FlatCap)
        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)
        cx = self.width() / 2.0
        cy = self.height() / 2.0
        r = self._diameter / 2.0
        painter.drawEllipse(QPointF(cx, cy), r, r)


# ── Splice Route Viewer panel ─────────────────────────────────────────────────
# Colour-codes every fibre hop of a chosen PON on the canvas so the Excel splice
# plan can be cross-checked against the physical layers at a glance. Each row in a
# per-PON sheet (OLT port → feeder → AGG dome → FTS → distribution → DIS dome →
# STS → drop → ONT) maps to features here via shared label fields.

_HOP_COLOURS = OrderedDict([
    ('feeder', QColor(239,  68,  68, 255)),   # red    — feeder cable (secondary/primary)
    ('dist',   QColor(234, 115,  32, 255)),   # orange — distribution cable
    ('drop',   QColor(250, 204,  21, 235)),   # yellow — drop cables
    ('agg',    QColor( 34, 211, 238, 255)),   # cyan   — AGG dome (FTS / fusion)
    ('dis',    QColor( 59, 130, 246, 255)),   # blue   — DIS dome (STS / connectorised)
    ('fts',    QColor(217,  70, 239, 255)),   # magenta— FTS splitter (1:8)
    ('sts',    QColor( 34, 197,  94, 255)),   # green  — STS splitter (1:16)
    ('ont',    QColor(248, 250, 252, 235)),   # white  — ONT / home
])

_HOP_TITLES = {
    'feeder': 'FEEDER', 'dist': 'DISTRIBUTION', 'drop': 'DROPS',
    'agg': 'AGG DOME', 'dis': 'DIS DOMES', 'fts': 'FTS 1:8',
    'sts': 'STS 1:16', 'ont': 'ONTs',
}


class _RouteLabels(QgsMapCanvasItem):
    """Canvas overlay that draws small text pills at map points — used by the
    Route Viewer to label the splitters / legs / domes / cables of the shown route
    (QgsRubberBand can't render text)."""

    def __init__(self, canvas):
        super().__init__(canvas)
        self._canvas = canvas
        self._items = []          # list of (QgsPointXY, text, QColor)
        self.setZValue(130)

    def set_items(self, items):
        self.prepareGeometryChange()
        self._items = list(items)
        self.update()

    def clear(self):
        self.set_items([])

    def boundingRect(self):
        return self._canvas.sceneRect()

    def paint(self, painter, option=None, widget=None):
        if not self._items:
            return
        from qgis.PyQt.QtGui import QFont, QFontMetrics
        from qgis.PyQt.QtCore import QRectF
        painter.setRenderHint(QPainter.Antialiasing, True)
        m2p = self._canvas.mapSettings().mapToPixel()
        for item in self._items:
            pt, text, col = item[0], item[1], item[2]
            sz = item[3] if len(item) > 3 else 9          # optional per-label size
            font = QFont('Segoe UI', sz); font.setBold(True)
            painter.setFont(font)
            fm = QFontMetrics(font)
            sp = m2p.transform(pt.x(), pt.y())
            w = fm.horizontalAdvance(text) + 10
            h = fm.height() + 4
            rect = QRectF(sp.x() + 8, sp.y() - h / 2.0, w, h)
            painter.setPen(QPen(QColor(0, 0, 0, 160)))     # thin dark outline pill
            painter.setBrush(QColor(8, 10, 18, 225))
            painter.drawRoundedRect(rect, 4, 4)
            painter.setPen(QPen(col))
            painter.drawText(rect, Qt.AlignCenter, text)


class SpliceRouteViewerPanel(QDialog):
    """Floating panel: pick an OLT port (PON) and light up its whole fibre route
    on the canvas, colour-coded by hop, with a label read-out to tick against the
    Excel splice plan. Optionally narrows to a single STS leg."""

    PORT_OFFSET = {15: 224, 16: 240, 17: 256, 18: 272, 19: 288}

    def __init__(self, iface, parent=None):
        super().__init__(iface.mainWindow(), Qt.Tool | Qt.WindowStaysOnTopHint)
        self.iface  = iface
        self.canvas = iface.mapCanvas()
        self.setWindowTitle('🔦 Splice Route Viewer')
        self.setMinimumWidth(400)

        self._bands = {}
        self._build_bands()
        self._layers = {}
        self._idx    = None          # built lazily on first show / index build
        self._solo_saved = None       # {layer_id: original_opacity} when solo active
        self._programmatic_select = False   # True while WE drive layer selection
        self._build_index()
        self._build_ui()

    # ── port ↔ pon helpers ──────────────────────────────────────────────────
    @classmethod
    def _port_to_pon(cls, port):
        try:
            card = int(port[1:3]); p = int(port[4:6])
            return cls.PORT_OFFSET[card] + p
        except Exception:
            return None

    @staticmethod
    def _pon_to_zone(pon):
        try:
            return (int(pon) - 235) // 16 + 17
        except Exception:
            return None

    @classmethod
    def _pon_to_port(cls, pon):
        try:
            pon = int(pon)
            for card, off in cls.PORT_OFFSET.items():
                p = pon - off
                if 1 <= p <= 16:
                    return f"C{card}P{p:02d}"
        except Exception:
            pass
        return None

    def _feature_info(self, layer, feat):
        """Identify a clicked feature → which PON sheet it belongs to. Returns a
        dict {label, lname, pon, zone, sheet, in_plan, note, extra}."""
        import re
        lname = layer.name()
        lab = self._label_of(feat) or '(no label)'
        # PON: pon_no field first, else OLT port in the label (splitters)
        pon = None
        for fld in ('pon_no', 'PON_no', 'pon'):
            i = feat.fields().indexOf(fld)
            if i >= 0 and feat[i] not in (None, ''):
                try:
                    pon = int(feat[i]); break
                except Exception:
                    pass
        if pon is None:
            m = re.search(r'C\d\dP\d\d', lab)
            if m:
                pon = self._port_to_pon(m.group(0))
        low = lname.lower()
        spare = 'spare' in low
        info = {'label': lab, 'lname': lname, 'pon': pon,
                'zone': self._pon_to_zone(pon) if pon else None,
                'sheet': self._pon_to_port(pon) if pon else None,
                'in_plan': not spare, 'note': '', 'extra': ''}
        # which section of the sheet this feature lives in
        if spare:
            info['note'] = 'SPARE capacity — NOT in the splice plan'
        elif 'distribution' in low:
            info['note'] = 'DISTRIBUTION section'
        elif 'secondary' in low or 'primary' in low:
            info['note'] = 'FEEDER row'
        elif 'fts' in low:
            info['note'] = 'FTS 1:8 (sheet header + feeder row)'
        elif 'sts' in low:
            info['note'] = 'STS 1:16 (one leg block)'
        elif 'drop' in low:
            info['note'] = 'DROP rows (DR number)'
        elif 'ont' in low or 'home' in low:
            info['note'] = 'DR rows (one home)'
        elif 'splice' in low:
            info['note'] = 'AGG dome (FTS fusion)'
        elif 'connectorised' in low:
            info['note'] = 'DIS dome (STS connector)'
        cc = feat.fields().indexOf('cblcpty')
        if cc >= 0 and feat[cc] not in (None, ''):
            info['extra'] = str(feat[cc])
        return info

    # ── layer / rubber-band setup ───────────────────────────────────────────
    def _lyr(self, *names):
        proj = QgsProject.instance()
        lays = list(proj.mapLayers().values())
        for n in names:                                   # exact name
            for l in lays:
                if l.name().lower() == n.lower():
                    return l
        for n in names:                                   # fuzzy contains
            for l in lays:
                if n.lower() in l.name().lower():
                    return l
        return None

    @staticmethod
    def _label_of(feat):
        for c in ('label', 'label_1', 'Label', 'LABEL', 'name'):
            i = feat.fields().indexOf(c)
            if i >= 0 and feat[i] not in (None, ''):
                return str(feat[i])
        return None

    @staticmethod
    def _field_val(feat, *names):
        for n in names:
            i = feat.fields().indexOf(n)
            if i >= 0 and feat[i] not in (None, ''):
                return str(feat[i])
        return None

    def _build_bands(self):
        line_hops = [('feeder', 7), ('dist', 5), ('drop', 3)]
        for hop, w in line_hops:
            b = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
            b.setColor(_HOP_COLOURS[hop]); b.setWidth(w)
            self._bands[hop] = b
        pt_hops = [
            ('agg', QgsRubberBand.ICON_FULL_DIAMOND, 26),
            ('dis', QgsRubberBand.ICON_CIRCLE,       16),
            ('fts', QgsRubberBand.ICON_FULL_DIAMOND, 30),
            ('sts', QgsRubberBand.ICON_BOX,          20),
            ('ont', QgsRubberBand.ICON_CIRCLE,        9),
        ]
        for hop, icon, size in pt_hops:
            b = QgsRubberBand(self.canvas, QgsWkbTypes.PointGeometry)
            b.setColor(_HOP_COLOURS[hop]); b.setIcon(icon)
            b.setIconSize(size); b.setWidth(3)
            b.setSecondaryStrokeColor(QColor(10, 12, 20, 220))
            self._bands[hop] = b
        # flow-direction arrowheads (POP -> drop) drawn over the route lines
        ab = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        ab.setColor(QColor(255, 255, 255, 245)); ab.setWidth(3)
        self._bands['arrow'] = ab
        # bright halo ring around whatever is SELECTED on the Excel sheet (or the
        # scope-combo STS) so the picked splitter/home is unmistakable
        halo = QgsRubberBand(self.canvas, QgsWkbTypes.PointGeometry)
        halo.setColor(QColor(255, 235, 0, 255))           # vivid yellow
        halo.setIcon(QgsRubberBand.ICON_CIRCLE)
        halo.setIconSize(44); halo.setWidth(5)
        halo.setSecondaryStrokeColor(QColor(0, 0, 0, 200))
        self._bands['halo'] = halo
        # text-label overlay (splitters / legs / domes / cables)
        self._labels = _RouteLabels(self.canvas)
        # text-label overlay (splitters / legs / domes / cables)
        self._labels = _RouteLabels(self.canvas)

    def _build_index(self):
        """Read the splice layers once into light lookup tables keyed for fast
        per-port route resolution. Stores feature ids so we can also select the
        features in their layers (drives the attribute table for cross-check)."""
        import re
        from qgis.core import QgsGeometry
        L = self._layers = {
            'fts':  self._lyr('FTS Splitters', 'FTS Splitters v1'),
            'sts':  self._lyr('STS Splitters', 'STS Splitters v1'),
            'agg':  self._lyr('Enclosures Splice', 'Enclosures Splice v1'),
            'dis':  self._lyr('Enclosures Connectorised', 'Enclosures Connectorised v1'),
            'dist': self._lyr('Distribution Cable', 'Distribution Cable v1'),
            'drop': self._lyr('Drop Cable', 'Drop Cable v1'),
            'ont':  self._lyr('ONT', 'ONT v1'),
            'sec':  self._lyr('Secondary Cable', 'Secondary Cable v1'),
            'pri':  self._lyr('Primary Cable', 'Primary Cable v1'),
            'spare': self._lyr('Spare Drop Cable', 'Spare Drop Cable v1'),
        }
        PORT = re.compile(r'C\d\dP\d\d')
        # The AGG/DIS dome token is embedded INSIDE the splitter label after a
        # prefix (e.g. "MOA.STS.16.DIS.DM.P.F726.C15P11.L1"), so match the bare
        # "AGG.DM.P.x" / "DIS.DM.P.x" token and rebuild the dome label "MOA.<tok>"
        # to match the dome layer's label_1 and the drop strtfeat values.
        AGG  = re.compile(r'AGG\.DM\.P\.\w+')
        DIS  = re.compile(r'DIS\.DM\.P\.\w+')
        LEG  = re.compile(r'\.(L\d+)')

        idx = {
            'fts_by_port':  {},     # port -> {fid, geom, label, agg}
            'sts_by_port':  {},     # port -> [ {fid, geom, label, dis, leg} ]
            'agg_by_label': {},     # label_1 -> {fid, geom}
            'dis_by_label': {},     # label_1 -> {fid, geom}
            'drops_by_dis': {},     # dis label -> [ {fid, geom, label, ont} ]
            'ont_by_label': {},     # ont label -> {fid, geom}
            'dist_by_pon':  {},     # pon -> [ {fid, geom, label} ]
            'feed_by_pon':  {},     # pon -> [ {fid, geom, label, kind} ]  (fallback)
            'feed_by_label': {},    # cable label -> {fid, geom, strt, end, kind}
            'feed_by_endfeat': {},  # endfeat pole -> [cable label]  (upstream trace)
            'ports':        [],     # sorted port list
        }

        if L['fts']:
            for f in L['fts'].getFeatures():
                lab = self._label_of(f)
                if not lab:
                    continue
                m = PORT.search(lab)
                if not m or m.group(0) in idx['fts_by_port']:
                    continue
                a = AGG.search(lab)
                idx['fts_by_port'][m.group(0)] = {
                    'fid': f.id(), 'geom': QgsGeometry(f.geometry()),
                    'label': lab, 'agg': ('MOA.' + a.group(0)) if a else None,
                    'strtfeat': self._field_val(f, 'strtfeat')}
        if L['sts']:
            for f in L['sts'].getFeatures():
                lab = self._label_of(f)
                if not lab:
                    continue
                m = PORT.search(lab)
                if not m:
                    continue
                d = DIS.search(lab); lg = LEG.search(lab)
                idx['sts_by_port'].setdefault(m.group(0), []).append({
                    'fid': f.id(), 'geom': QgsGeometry(f.geometry()),
                    'label': lab, 'dis': ('MOA.' + d.group(0)) if d else None,
                    'leg': lg.group(1) if lg else None})
        for key, lyr in (('agg_by_label', L['agg']), ('dis_by_label', L['dis'])):
            if not lyr:
                continue
            for f in lyr.getFeatures():
                lab = self._label_of(f)
                if lab and lab not in idx[key]:
                    idx[key][lab] = {'fid': f.id(), 'geom': QgsGeometry(f.geometry())}
        if L['drop']:
            for f in L['drop'].getFeatures():
                lab = self._label_of(f)
                strt = self._field_val(f, 'strtfeat')
                ont  = self._field_val(f, 'endfeat')
                if strt is None:
                    continue
                idx['drops_by_dis'].setdefault(strt, []).append({
                    'fid': f.id(), 'geom': QgsGeometry(f.geometry()),
                    'label': lab, 'ont': ont})
        if L['ont']:
            for f in L['ont'].getFeatures():
                lab = self._label_of(f)
                if lab and lab not in idx['ont_by_label']:
                    idx['ont_by_label'][lab] = {'fid': f.id(), 'geom': QgsGeometry(f.geometry())}
        if L['dist']:
            for f in L['dist'].getFeatures():
                pon = self._field_val(f, 'pon_no')
                if pon is None:
                    continue
                idx['dist_by_pon'].setdefault(pon, []).append({
                    'fid': f.id(), 'geom': QgsGeometry(f.geometry()),
                    'label': self._label_of(f)})
        for kind, lyr in (('Secondary', L['sec']), ('Primary', L['pri'])):
            if not lyr:
                continue
            for f in lyr.getFeatures():
                lab  = self._label_of(f)
                geom = QgsGeometry(f.geometry())
                strt = self._field_val(f, 'strtfeat')
                end  = self._field_val(f, 'endfeat')
                pon  = self._field_val(f, 'pon_no')
                if pon is not None:
                    idx['feed_by_pon'].setdefault(pon, []).append(
                        {'fid': f.id(), 'geom': geom, 'label': lab, 'kind': kind})
                if lab:
                    idx['feed_by_label'][lab] = {'fid': f.id(), 'geom': geom,
                                                 'strt': strt, 'end': end, 'kind': kind}
                if end:
                    idx['feed_by_endfeat'].setdefault(end, []).append(lab)
        # The generator picks the feeder by WHICH cable the FTS physically sits on
        # (vertex analysis in fts_cable_map.json), then traces upstream — NOT by
        # pon_no (feeders are shared trunks). Load that map so the highlighted
        # feeder matches the Excel feeder row exactly.
        idx['fts_cable_map'] = {}
        try:
            import json as _json, os as _os
            _p = r'C:/Temp/fts_cable_map.json'
            if _os.path.exists(_p):
                idx['fts_cable_map'] = _json.loads(open(_p, encoding='utf-8').read())
        except Exception:
            idx['fts_cable_map'] = {}
        # Resolve each FTS to a real AGG dome FEATURE. The AGG label embedded in
        # the FTS label matches the Enclosures-Splice label_1 for only ~9/66
        # (known convention quirk — see build_field_cards.py), so fall back to the
        # nearest AGG dome by geometry (the FTS physically sits at its dome).
        agg_items = [(lab, e['fid'], e['geom'])
                     for lab, e in idx['agg_by_label'].items()
                     if e['geom'] is not None and not e['geom'].isEmpty()]
        for fts in idx['fts_by_port'].values():
            hit = idx['agg_by_label'].get(fts['agg'])
            if hit:
                fts.update(agg_fid=hit['fid'], agg_geom=hit['geom'],
                           agg_label=fts['agg'], agg_matched='label')
                continue
            fg = fts['geom']
            best = None
            if fg is not None and not fg.isEmpty() and agg_items:
                fc = fg.centroid()
                best = min(agg_items, key=lambda it: it[2].centroid().distance(fc))
            if best:
                fts.update(agg_fid=best[1], agg_geom=best[2],
                           agg_label=best[0], agg_matched='nearest')
            else:
                fts.update(agg_fid=None, agg_geom=None,
                           agg_label=fts['agg'], agg_matched='none')

        # Resolve each STS to the DIS dome FEATURE it physically sits on (nearest).
        # The STS's label-dome is a clean 1:1 reference, but the dome POINT layer
        # wasn't snapped with the STS, so the label-point is often stray (250-530m
        # away). Draw the marker at the co-located dome instead, keeping the plan
        # label. Zero data change — display only.
        from qgis.core import QgsSpatialIndex
        dis_lyr = L['dis']
        if dis_lyr is not None:
            si = QgsSpatialIndex()
            di_geom = {}
            for f in dis_lyr.getFeatures():
                g = f.geometry()
                if g and not g.isEmpty():
                    si.insertFeature(f)
                    di_geom[f.id()] = QgsGeometry(g)
            for lst in idx['sts_by_port'].values():
                for s in lst:
                    g = s.get('geom')
                    s['dis_geom'] = None; s['dis_fid'] = None
                    if g is None or g.isEmpty():
                        continue
                    try:
                        nb = si.nearestNeighbor(g.centroid().asPoint(), 1)
                    except Exception:
                        nb = []
                    if nb:
                        s['dis_fid'] = nb[0]
                        s['dis_geom'] = di_geom.get(nb[0])

        # Spatial index of distribution cables so we can draw the cable each dome
        # PHYSICALLY sits on, regardless of pon_no tag — distribution cables are
        # shared trunks tagged to one PON, like the feeder. pon_no filtering alone
        # leaves most of the route undrawn.
        idx['dist_index'] = None
        idx['dist_feats'] = {}
        if L['dist'] is not None:
            dsi = QgsSpatialIndex()
            for f in L['dist'].getFeatures():
                g = f.geometry()
                if g and not g.isEmpty():
                    dsi.insertFeature(f)
                    idx['dist_feats'][f.id()] = {
                        'fid': f.id(), 'geom': QgsGeometry(g),
                        'label': self._label_of(f)}
            idx['dist_index'] = dsi

        idx['ports'] = sorted(idx['fts_by_port'].keys())
        self._idx = idx

    def _resolve_distribution(self, dome_geoms, agg_geom, pon):
        """Distribution cables that PHYSICALLY serve this PON — the cable each of
        its domes (and the AGG dome) sits on — unioned with the pon_no-tagged ones.
        Cables are shared trunks, so the tag alone misses most of the route."""
        si = self._idx.get('dist_index')
        feats = self._idx.get('dist_feats') or {}
        out = {}
        if si is not None:
            pts = list(dome_geoms)
            if agg_geom is not None and not agg_geom.isEmpty():
                pts.append(agg_geom)
            for g in pts:
                if g is None or g.isEmpty():
                    continue
                try:
                    cand = si.nearestNeighbor(g.centroid().asPoint(), 3)
                except Exception:
                    cand = []
                best, bestd = None, 1e18
                for fid in cand:
                    fe = feats.get(fid)
                    if fe and g.distance(fe['geom']) < bestd:
                        bestd = g.distance(fe['geom']); best = fid
                if best is not None and bestd * 111320 < 30:   # dome sits on this cable
                    out[best] = feats[best]
        for dc in self._idx['dist_by_pon'].get(pon, []):
            if dc.get('fid') is not None:
                out.setdefault(dc['fid'], dc)
        return list(out.values())

    # ── UI ──────────────────────────────────────────────────────────────────
    def _build_ui(self):
        from qgis.PyQt.QtWidgets import QComboBox, QListWidget
        self.setStyleSheet(_DIALOG_BG)
        layout = QVBoxLayout(self)
        layout.setSpacing(6); layout.setContentsMargins(12, 12, 12, 10)

        subtitle = QLabel('Pick an OLT port (PON) → light up its fibre route on the canvas.')
        subtitle.setWordWrap(True); subtitle.setStyleSheet(_SUBTITLE_LBL)
        layout.addWidget(subtitle)

        if not self._idx['ports']:
            warn = QLabel('⚠ No FTS Splitters layer found in this project.\n'
                          'Open the splice project (with FTS/STS/dome layers) and reopen.')
            warn.setWordWrap(True); warn.setStyleSheet(_STATUS_LBL)
            layout.addWidget(warn)
            return

        # ── Find box: type any DR / dome / STS / cable / port → jump + highlight
        from qgis.PyQt.QtWidgets import QLineEdit
        find_lbl = QLabel('FIND  (DR · dome · STS · cable · port)')
        find_lbl.setStyleSheet(_SECTION_LBL); layout.addWidget(find_lbl)
        self.find_edit = QLineEdit()
        self.find_edit.setPlaceholderText('e.g. DR1876230, F726, C16P04, DF.24F…')
        self.find_edit.setStyleSheet(
            f"QLineEdit {{ background:#11131f; color:{_TEXT}; border:1px solid {_BORDER};"
            f" border-radius:4px; padding:6px 8px; font-family:Consolas; font-size:11px; }}"
            f"QLineEdit:focus {{ border-color:{_ACCENT}; }}")
        self.find_edit.returnPressed.connect(self._find)
        layout.addWidget(self.find_edit)

        sel_lbl = QLabel('OLT PORT  ·  PON')
        sel_lbl.setStyleSheet(_SECTION_LBL); layout.addWidget(sel_lbl)

        self.port_combo = QComboBox()
        self.port_combo.setStyleSheet(_COMBO_CSS)
        for port in self._idx['ports']:
            pon = self._port_to_pon(port); zone = self._pon_to_zone(pon)
            homes = self._home_count(port)
            self.port_combo.addItem(
                f'{port}    PON {pon} · Zone {zone}    ({homes} homes)', port)
        self.port_combo.currentIndexChanged.connect(self._on_port_changed)
        layout.addWidget(self.port_combo)

        nav = QHBoxLayout(); nav.setSpacing(8)
        btn_prev = QPushButton('◀  Prev'); btn_prev.setStyleSheet(_BTN_CLEAR)
        btn_prev.clicked.connect(lambda: self._step(-1)); nav.addWidget(btn_prev)
        btn_next = QPushButton('Next  ▶'); btn_next.setStyleSheet(_BTN_CLEAR)
        btn_next.clicked.connect(lambda: self._step(1)); nav.addWidget(btn_next)
        layout.addLayout(nav)

        sts_lbl = QLabel('SCOPE  (narrow to one STS leg)')
        sts_lbl.setStyleSheet(_SECTION_LBL); layout.addWidget(sts_lbl)
        self.sts_combo = QComboBox(); self.sts_combo.setStyleSheet(_COMBO_CSS)
        layout.addWidget(self.sts_combo)

        act = QHBoxLayout(); act.setSpacing(8)
        btn_show = QPushButton('🔦  Show on Canvas'); btn_show.setStyleSheet(_BTN_GREEN)
        btn_show.clicked.connect(self._show_route); act.addWidget(btn_show)
        btn_clear = QPushButton('Clear'); btn_clear.setStyleSheet(_BTN_CLEAR)
        btn_clear.clicked.connect(self._clear); act.addWidget(btn_clear)
        layout.addLayout(act)

        from qgis.PyQt.QtWidgets import QCheckBox
        _chk_css = f"QCheckBox {{ color:{_TEXT}; font-family:'Segoe UI'; font-size:10px; }}"
        self.solo_chk = QCheckBox('Solo — dim every other layer so only this route shows')
        self.solo_chk.setChecked(True); self.solo_chk.setStyleSheet(_chk_css)
        self.solo_chk.toggled.connect(self._on_solo_toggled)
        layout.addWidget(self.solo_chk)

        # last-mile drop cables fan out 1:16 from every STS — off by default so the
        # canvas shows the clean trunk (feeder -> FTS -> distribution -> STS) flow.
        self.drops_chk = QCheckBox('Show drop cables (last-mile — busy)')
        self.drops_chk.setChecked(False); self.drops_chk.setStyleSheet(_chk_css)
        self.drops_chk.toggled.connect(lambda *_: self._show_route())
        layout.addWidget(self.drops_chk)

        # on-canvas labels: FTS, each STS leg, domes, distribution + feeder cables
        self.labels_chk = QCheckBox('Show labels (splitters · legs · domes · cables)')
        self.labels_chk.setChecked(True); self.labels_chk.setStyleSheet(_chk_css)
        self.labels_chk.toggled.connect(lambda *_: self._show_route())
        layout.addWidget(self.labels_chk)

        # follow the live Excel sheet + cell selection (via excel_watch.py)
        self.excel_chk = QCheckBox('Follow Excel selection (sheet + selected rows)')
        self.excel_chk.setChecked(True); self.excel_chk.setStyleSheet(_chk_css)
        layout.addWidget(self.excel_chk)

        line = QFrame(); line.setFrameShape(QFrame.HLine)
        line.setStyleSheet(_DIVIDER); layout.addWidget(line)

        # IDENTIFY — click any cable / splitter / dome on the map → which PON sheet
        id_lbl = QLabel('IDENTIFY  (click a feature on the map)')
        id_lbl.setStyleSheet(_SECTION_LBL); layout.addWidget(id_lbl)
        self._id_lbl = QLabel('Select a feature on the canvas…')
        self._id_lbl.setWordWrap(True)
        self._id_lbl.setStyleSheet(
            f"QLabel {{ background:#11131f; color:{_TEXT}; border:1px solid {_BORDER};"
            f" border-radius:4px; padding:6px 8px; font-family:Consolas; font-size:10px; }}")
        layout.addWidget(self._id_lbl)
        id_row = QHBoxLayout(); id_row.setSpacing(8)
        self._id_open_btn = QPushButton('↪  Open that PON')
        self._id_open_btn.setStyleSheet(_BTN_GRADIENT); self._id_open_btn.setEnabled(False)
        self._id_open_btn.clicked.connect(self._open_identified_pon)
        id_row.addWidget(self._id_open_btn)
        self.idjump_chk = QCheckBox('auto-jump')
        self.idjump_chk.setChecked(False); self.idjump_chk.setStyleSheet(_chk_css)
        id_row.addWidget(self.idjump_chk)
        layout.addLayout(id_row)
        self._id_target_port = None

        line2 = QFrame(); line2.setFrameShape(QFrame.HLine)
        line2.setStyleSheet(_DIVIDER); layout.addWidget(line2)

        ro_row = QHBoxLayout(); ro_row.setSpacing(8)
        ro_lbl = QLabel('ROUTE  (tick against the Excel sheet)')
        ro_lbl.setStyleSheet(_SECTION_LBL); ro_row.addWidget(ro_lbl, 1)
        btn_copy = QPushButton('📋 Copy')
        btn_copy.setStyleSheet(_BTN_CLEAR)
        btn_copy.setMaximumWidth(80)
        btn_copy.clicked.connect(self._copy_route)
        ro_row.addWidget(btn_copy)
        layout.addLayout(ro_row)
        self.readout = QListWidget()
        self.readout.setStyleSheet(
            f"QListWidget {{ background:#11131f; color:{_TEXT}; border:1px solid {_BORDER};"
            f" border-radius:4px; font-family:Consolas; font-size:10px; }}"
            f"QListWidget::item {{ padding:2px 6px; }}")
        self.readout.setMinimumHeight(150)
        layout.addWidget(self.readout, 1)

        self._status_lbl = QLabel(''); self._status_lbl.setWordWrap(True)
        self._status_lbl.setStyleSheet(_STATUS_LBL); layout.addWidget(self._status_lbl)

        # legend
        legend = QLabel(
            '🟥 feeder  🟧 distribution  🟨 drops   '
            '🔷 AGG dome  🔵 DIS dome   🟪 FTS  🟩 STS  ⚪ ONT')
        legend.setWordWrap(True); legend.setStyleSheet(_HINT_LBL)
        layout.addWidget(legend)

        self._on_port_changed()          # populate STS combo for first port

        # live poll: re-show automatically when the Excel sheet/selection changes
        self._xl_last_key = None
        self._xl_timer = QTimer(self)
        self._xl_timer.setInterval(1200)
        self._xl_timer.timeout.connect(self._poll_excel)
        self._xl_timer.start()

        # IDENTIFY: react when the user clicks/selects a feature on any route layer
        for lyr in self._layers.values():
            if lyr is not None:
                try:
                    lyr.selectionChanged.connect(self._on_user_select)
                except Exception:
                    pass

    # ── identify clicked feature -> PON sheet ────────────────────────────────
    def _on_user_select(self, selected=None, deselected=None, clearAndSelect=None):
        if getattr(self, '_programmatic_select', False):
            return                                  # ignore our own route selection
        lyr = self.sender()
        if lyr is None:
            return
        try:
            # identify the NEWLY-selected feature (the user's click) — not the whole
            # selection, so it still works when the route viewer leaves features
            # selected. selectionChanged passes the new-selection delta.
            ids = list(selected) if selected else []
            if not ids:
                if lyr.selectedFeatureCount() == 1:
                    ids = [next(lyr.getSelectedFeatures()).id()]
                else:
                    return
            if len(ids) > 12:                        # huge select -> not a click
                return
            feat = lyr.getFeature(ids[-1])           # the last one the user added
        except Exception:
            return
        info = self._feature_info(lyr, feat)
        self._show_identify(info)

    def _show_identify(self, info):
        lab, lname = info['label'], info['lname']
        cap = f'  ·  {info["extra"]}' if info['extra'] else ''
        if info['pon'] and info['sheet']:
            head = (f'<b>{lab}</b>{cap}<br>{lname}<br>'
                    f'➜ <b>PON {info["pon"]}</b> · Zone {info["zone"]} · sheet '
                    f'<b>{info["sheet"]}</b>')
            body = (f'<br><span style="color:#f59e0b">{info["note"]}</span>'
                    if not info['in_plan']
                    else f'<br><span style="color:#22c55e">in plan → {info["note"]}</span>')
            self._id_lbl.setText(head + body)
            self._id_target_port = info['sheet']
            self._id_open_btn.setEnabled(True)
            self._id_open_btn.setText(f'↪  Open {info["sheet"]} (PON {info["pon"]})')
            if getattr(self, 'idjump_chk', None) and self.idjump_chk.isChecked():
                self._open_identified_pon()
        else:
            self._id_lbl.setText(f'<b>{lab}</b>{cap}<br>{lname}<br>'
                                 f'<span style="color:#94a3b8">no PON tag on this feature</span>')
            self._id_target_port = None
            self._id_open_btn.setEnabled(False)
            self._id_open_btn.setText('↪  Open that PON')

    def _open_identified_pon(self):
        port = getattr(self, '_id_target_port', None)
        if not port:
            return
        i = self.port_combo.findData(port)
        if i < 0:
            return
        # opening a neighbour PON: stop following Excel so it doesn't snap back
        if getattr(self, 'excel_chk', None) and self.excel_chk.isChecked():
            self.excel_chk.setChecked(False)
        self.port_combo.setCurrentIndex(i)
        self._on_port_changed()
        self._show_route()

    def _poll_excel(self):
        if not self.isVisible():
            return
        xl = self._read_excel_sel()
        if not xl:
            return
        key = (xl.get('sheet'), xl.get('selection'),
               tuple(xl.get('sts', [])), tuple(xl.get('drs', [])))
        if key != self._xl_last_key:
            self._xl_last_key = key
            self._show_route()

    def _home_count(self, port):
        n = 0
        for s in self._idx['sts_by_port'].get(port, []):
            n += len(self._idx['drops_by_dis'].get(s['dis'], []))
        return n

    def _loss_budget(self, fts, sts_list, feeder_lbls, dist_cables):
        """Estimate worst-case optical loss POP→ONT vs GPON Class B+ (28 dB).
        Cascaded splitters dominate: 1:8 FTS ≈10.5 + 1:16 STS ≈13.5 = 24 dB;
        + 3 connectors (0.30) + 4 splices (0.10) + fibre 0.35 dB/km. Returns
        (loss_db, margin_db, status, fibre_km)."""
        def km(g):
            try:
                return g.length() * 111.32        # degrees → km (approx at this lat)
            except Exception:
                return 0.0
        feeder_km = sum(km(self._idx['feed_by_label'][fl]['geom'])
                        for fl in (feeder_lbls or [])
                        if fl in self._idx['feed_by_label'])
        dist_km = max([km(dc.get('geom')) for dc in (dist_cables or [])] or [0.0])
        drop_km = 0.0
        for s in sts_list:
            for dr in self._idx['drops_by_dis'].get(s['dis'], []):
                drop_km = max(drop_km, km(dr.get('geom')))
        fibre_km = feeder_km + dist_km + drop_km
        loss = 10.5 + 13.5 + 3 * 0.30 + 4 * 0.10 + fibre_km * 0.35
        margin = 28.0 - loss
        status = 'PASS' if margin >= 3 else ('MARGINAL' if margin >= 1 else 'FAIL')
        return round(loss, 1), round(margin, 1), status, round(fibre_km, 2)

    def _resolve_feeders(self, fts):
        """Mirror the generator's feeder_hops: find the feeder cable the FTS
        physically sits on (fts_cable_map keyed by the FTS pole, else the AGG-dome
        pole), then trace upstream via endfeat. Returns [cable_label, ...] in the
        same set the Excel feeder row lists. Empty list -> caller falls back to
        the pon_no-tagged feeder."""
        import re
        cmap = self._idx.get('fts_cable_map') or {}
        if not cmap:
            return []
        pole = fts.get('strtfeat')
        hit = cmap.get(pole)
        if not hit and fts.get('agg'):
            agg_pole = re.sub(r'AGG\.DM\.', '', fts['agg'])   # MOA.AGG.DM.P.H110 -> MOA.P.H110
            hit = cmap.get(agg_pole)
        if not hit:
            return []
        out = []
        seen = set()
        lbl = hit.get('cable')
        while lbl and lbl not in seen:
            seen.add(lbl); out.append(lbl)
            cab = self._idx['feed_by_label'].get(lbl)
            if not cab or not cab.get('strt'):
                break
            ups = self._idx['feed_by_endfeat'].get(cab['strt'], [])
            lbl = ups[0] if ups else None
        return out

    def _on_port_changed(self):
        port = self.port_combo.currentData()
        self.sts_combo.blockSignals(True)
        self.sts_combo.clear()
        self.sts_combo.addItem('All STS in PON', None)
        for s in sorted(self._idx['sts_by_port'].get(port, []),
                        key=lambda x: (x['leg'] or '')):
            n = len(self._idx['drops_by_dis'].get(s['dis'], []))
            self.sts_combo.addItem(f"{s['leg'] or '—'}  {s['dis']}  ({n})", s['label'])
        self.sts_combo.blockSignals(False)

    def _step(self, delta):
        i = self.port_combo.currentIndex() + delta
        if 0 <= i < self.port_combo.count():
            self.port_combo.setCurrentIndex(i)
            self._show_route()

    def _jump_to(self, port, sts_label=None):
        """Switch the viewer to *port* (and optionally narrow to one STS) and show
        it. Turns off Excel-follow so the jump sticks."""
        i = self.port_combo.findData(port)
        if i < 0:
            return False
        if getattr(self, 'excel_chk', None) and self.excel_chk.isChecked():
            self.excel_chk.setChecked(False)
        self.port_combo.setCurrentIndex(i)
        self._on_port_changed()
        if sts_label:
            for j in range(self.sts_combo.count()):
                if self.sts_combo.itemData(j) == sts_label:
                    self.sts_combo.setCurrentIndex(j); break
        else:
            self.sts_combo.setCurrentIndex(0)
        self._show_route()
        return True

    def _find(self):
        """Resolve the Find text (DR / dome / STS / cable / port) to a PON and jump
        there, narrowing to the matching STS when relevant."""
        import re
        q = self.find_edit.text().strip()
        if not q:
            return
        idx = self._idx
        # 1. DR number -> the STS/dome that serves it
        m = re.search(r'DR\s*0*(\d+)', q, re.I)
        if m:
            dr = 'DR' + m.group(1)
            for port, lst in idx['sts_by_port'].items():
                for s in lst:
                    for drp in idx['drops_by_dis'].get(s['dis'], []):
                        if dr in ((drp.get('label') or '') + ' ' + (drp.get('ont') or '')):
                            self._jump_to(port, sts_label=s['label'])
                            self._set_status(f'Found {dr} → {s["leg"]} · {s["dis"].split(".")[-1]}',
                                             colour=_GREEN)
                            return
        # 2. explicit OLT port
        mp = re.search(r'C\d\dP\d\d', q, re.I)
        if mp and mp.group(0).upper() in idx['fts_by_port']:
            self._jump_to(mp.group(0).upper()); return
        # 3. DIS dome
        md = re.search(r'(?:DIS\.DM\.P\.)?([A-Z]?\d{3,})', q, re.I)
        token = md.group(1).upper() if md else None
        if token:
            for port, lst in idx['sts_by_port'].items():
                for s in lst:
                    if s.get('dis') and s['dis'].endswith('.' + token):
                        self._jump_to(port, sts_label=s['label'])
                        self._set_status(f'Found dome {token} → {port}', colour=_GREEN)
                        return
            # 4. AGG dome
            for port, fts in idx['fts_by_port'].items():
                if fts.get('agg') and fts['agg'].endswith('.' + token):
                    self._jump_to(port); self._set_status(f'Found AGG {token} → {port}', colour=_GREEN)
                    return
        # 5. cable label substring (distribution / feeder)
        ql = q.lower()
        for fid, fe in (idx.get('dist_feats') or {}).items():
            if fe.get('label') and ql in fe['label'].lower():
                info = {'label': fe['label'], 'lname': 'Distribution Cable'}
                # find pon via the route resolution: jump to the cable's pon_no tag
                for pon, cs in idx['dist_by_pon'].items():
                    if any(c.get('fid') == fid for c in cs):
                        port = self._pon_to_port(pon)
                        if port and self._jump_to(port):
                            self._set_status(f'Found cable {fe["label"].split(".P.")[-1]} → {port}',
                                             colour=_GREEN)
                            return
        self._set_status(f'"{q}" not found', colour=_RED)

    def _read_excel_sel(self):
        """Read C:/Temp/excel_selection.json (written by excel_watch.py) — the live
        active splice sheet + selected STS/DR. Returns None if disabled, stale
        (watcher not running), or the active sheet isn't a known PON."""
        if not getattr(self, 'excel_chk', None) or not self.excel_chk.isChecked():
            return None
        import json, os, time
        p = r'C:/Temp/excel_selection.json'
        try:
            if not os.path.exists(p) or (time.time() - os.path.getmtime(p)) > 8:
                return None
            d = json.load(open(p))
        except Exception:
            return None
        if not d.get('valid') or d.get('sheet') not in self._idx['fts_by_port']:
            return None
        return d

    # ── route resolution + draw ─────────────────────────────────────────────
    def _show_route(self):
        # follow the live Excel sheet + selection if enabled
        xl = self._read_excel_sel()
        if xl:
            i = self.port_combo.findData(xl['sheet'])
            if i >= 0 and i != self.port_combo.currentIndex():
                self.port_combo.blockSignals(True)
                self.port_combo.setCurrentIndex(i)
                self.port_combo.blockSignals(False)
                self._on_port_changed()

        port = self.port_combo.currentData()
        if not port:
            return
        pon  = str(self._port_to_pon(port))
        only_sts = self.sts_combo.currentData()       # None = whole PON

        # Excel-driven filter: restrict to the STS / DR rows selected on the sheet
        xl_sts = set(xl['sts']) if (xl and not xl.get('whole') and xl.get('sts')) else None
        xl_drs = set(xl['drs']) if (xl and not xl.get('whole') and xl.get('drs')) else None

        self._clear(keep_status=True)
        sel = {}                                       # layer -> set(fid)
        geoms = {hop: [] for hop in _HOP_COLOURS}
        labels = OrderedDict((hop, []) for hop in _HOP_COLOURS)

        def add(hop, lyr_key, entry):
            if not entry:
                return
            if entry.get('geom') is not None and not entry['geom'].isEmpty():
                geoms[hop].append(entry['geom'])
            if entry.get('label'):
                labels[hop].append(entry['label'])
            lyr = self._layers.get(lyr_key)
            if lyr is not None and entry.get('fid') is not None:
                sel.setdefault(lyr.id(), (lyr, set()))[1].add(entry['fid'])

        # FTS + AGG dome (the head of the PON). Show the CANONICAL AGG label from
        # the FTS (matches the Excel sheet) for the read-out; light the dome at the
        # nearest physical Enclosures-Splice feature (the FTS label only matches the
        # layer's label_1 for 9/66 — known quirk), noting the feature label.
        fts = self._idx['fts_by_port'].get(port)
        add('fts', 'fts', fts)
        if fts and fts.get('agg_geom') is not None:
            canon = fts.get('agg')                         # matches the Excel
            feat_lab = fts.get('agg_label')
            if fts.get('agg_matched') == 'nearest' and feat_lab and feat_lab != canon:
                lab = f'{canon}   (dome feat: {feat_lab.split(".")[-1]})'
            else:
                lab = canon
            add('agg', 'agg', {'fid': fts.get('agg_fid'),
                               'geom': fts['agg_geom'], 'label': lab})
        elif fts and fts.get('agg'):
            labels['agg'].append(fts['agg'] + '  (no dome feature)')

        # feeder: the cable(s) the FTS actually sits on + upstream trace (same as
        # the Excel feeder row). Fall back to pon_no-tagged feeder if no map hit.
        feeder_lbls = self._resolve_feeders(fts) if fts else []
        if feeder_lbls:
            for fl in feeder_lbls:
                cab = self._idx['feed_by_label'].get(fl)
                if cab:
                    add('feeder', 'sec' if cab['kind'] == 'Secondary' else 'pri',
                        {'fid': cab['fid'], 'geom': cab['geom'], 'label': fl})
        else:
            for fc in self._idx['feed_by_pon'].get(pon, []):
                add('feeder', 'sec' if fc['kind'] == 'Secondary' else 'pri', fc)

        # STS → DIS dome → drops → ONTs, restricted by the active filter:
        #   Excel-selected STS  >  the scope combo's single STS  >  all STS
        import re as _re
        sts_list = self._idx['sts_by_port'].get(port, [])
        if xl_sts is not None:
            sts_list = [s for s in sts_list if s['label'] in xl_sts]
        elif only_sts:
            sts_list = [s for s in sts_list if s['label'] == only_sts]
        for s in sts_list:
            add('sts', 'sts', s)
            if s.get('dis'):
                # draw the DIS dome at the co-located feature (nearest to the STS),
                # not the stray label-point; keep the plan label
                if s.get('dis_geom') is not None:
                    add('dis', 'dis', {'fid': s.get('dis_fid'),
                                       'geom': s['dis_geom'], 'label': s['dis']})
                else:
                    dis = self._idx['dis_by_label'].get(s['dis'])
                    if dis:
                        add('dis', 'dis', {**dis, 'label': s['dis']})
                for dr in self._idx['drops_by_dis'].get(s['dis'], []):
                    if xl_drs is not None:                 # only the selected DR rows
                        m = _re.search(r'DR\d+', dr.get('ont') or dr.get('label') or '')
                        if not m or m.group(0) not in xl_drs:
                            continue
                    add('drop', 'drop', dr)
                    if dr.get('ont'):
                        ont = self._idx['ont_by_label'].get(dr['ont'])
                        if ont:
                            add('ont', 'ont', {**ont, 'label': dr['ont']})

        # distribution: every cable the route's domes physically sit on (shared
        # trunks tagged to other PONs included), so the WHOLE route shows — not
        # just the 2-3 cables that happen to carry this PON's tag. CLIP each cable
        # to the cluster vicinity so a long shared trunk doesn't shoot a tail
        # across the map (deviation).
        from qgis.core import QgsRectangle, QgsGeometry
        agg_g = fts.get('agg_geom') if fts else None
        dist_cables = self._resolve_distribution(geoms['dis'], agg_g, pon)
        crect = None
        for hop in ('dis', 'sts', 'ont', 'drop'):
            for g in geoms[hop]:
                bb = g.boundingBox()
                if not bb.isEmpty():
                    crect = QgsRectangle(bb) if crect is None else (crect.combineExtentWith(bb) or crect)
        clip = None
        if crect is not None and not crect.isEmpty():
            buf = 0.0014                      # ~150 m around the cluster
            clip = QgsGeometry.fromRect(QgsRectangle(
                crect.xMinimum()-buf, crect.yMinimum()-buf,
                crect.xMaximum()+buf, crect.yMaximum()+buf))
        clipped = []
        for dc in dist_cables:
            g = dc.get('geom')
            if g is None:
                continue
            if clip is not None:
                gi = g.intersection(clip)
                if gi is None or gi.isEmpty():
                    continue
                dc = {**dc, 'geom': gi}
            clipped.append(dc)
            add('dist', 'dist', dc)
        dist_cables = clipped

        # the 100 last-mile drop lines fan out from each STS into a starburst —
        # only draw them when the user asks (checkbox); the read-out always counts
        # them. Default view = clean trunk: feeder -> FTS -> distribution -> STS.
        show_drops = bool(getattr(self, 'drops_chk', None) and self.drops_chk.isChecked())
        draw_geoms = dict(geoms)
        if not show_drops:
            draw_geoms['drop'] = []

        # draw rubber bands
        for hop, glist in draw_geoms.items():
            band = self._bands[hop]
            gt = (QgsWkbTypes.LineGeometry if hop in ('feeder', 'dist', 'drop')
                  else QgsWkbTypes.PointGeometry)
            band.reset(gt)
            for g in glist:
                band.addGeometry(g, None)

        # bright halo around the SELECTED splitters + homes (Excel selection or the
        # scope-combo STS) so the picked item is unmistakable. No halo on a full PON.
        halo = self._bands['halo']
        halo.reset(QgsWkbTypes.PointGeometry)
        filtered = (xl_sts is not None) or (xl_drs is not None) or bool(only_sts)
        if filtered:
            for g in geoms['sts'] + geoms['ont']:
                halo.addGeometry(g, None)

        # flow-direction arrows on the trunk (feeder -> FTS -> distribution),
        # plus drops only if the drop layer is shown.
        dome_pt = None
        if fts and fts.get('agg_geom') is not None and not fts['agg_geom'].isEmpty():
            dome_pt = fts['agg_geom'].centroid().asPoint()
        self._draw_arrows(draw_geoms, dome_pt)

        # on-canvas text labels: FTS, each STS leg, AGG/DIS domes, dist + feeder
        self._draw_labels(port, fts, sts_list, pon, feeder_lbls, show_drops,
                          filtered, dist_cables)

        # select features in their layers (feeds the attribute table). Flag it so
        # the IDENTIFY handler ignores our own selection (only user clicks count).
        self._programmatic_select = True
        try:
            for lyr, fids in sel.values():
                try:
                    lyr.selectByIds(list(fids))
                except Exception:
                    pass
        finally:
            self._programmatic_select = False

        # solo: dim every other layer so only this route stands out
        if getattr(self, 'solo_chk', None) and self.solo_chk.isChecked():
            self._apply_solo()
        else:
            self._restore_solo()

        # zoom to combined extent
        self._zoom_to(geoms)

        # read-out
        self._fill_readout(port, pon, only_sts, labels)
        # optical loss budget (worst-case POP->ONT vs GPON Class B+ 28 dB)
        loss_db, margin_db, lstatus, fibre_km = self._loss_budget(
            fts, sts_list, feeder_lbls, dist_cables)
        from qgis.PyQt.QtWidgets import QListWidgetItem
        lcol = {'PASS': _GREEN, 'MARGINAL': '#f59e0b', 'FAIL': _RED}[lstatus]
        it = QListWidgetItem(
            f'LOSS BUDGET  {loss_db} dB  ·  margin {margin_db} dB  ·  {lstatus}'
            f'   (1:8+1:16 = 24 dB · {fibre_km} km fibre · vs 28 dB B+)')
        it.setForeground(QColor(lcol)); self.readout.insertItem(1, it)

        nhomes = len(labels['drop'])
        nsts = len(labels['sts'])
        # capacity / fill: each 1:16 STS = 16 ports; fill% of homes vs capacity
        cap = nsts * 16
        spare = cap - nhomes
        fill = round(nhomes / cap * 100) if cap else 0
        tag = ''
        if xl_sts is not None or xl_drs is not None:
            tag = f'  ◀ Excel selection ({xl.get("selection","")})'
        elif xl:
            tag = '  ◀ following Excel sheet'
        self._set_status(
            f'PON {pon} · {port} — {nsts} STS · {nhomes} homes · {spare} spare · '
            f'{cap} ports · {fill}% fill{tag}',
            colour=_GREEN)
        self.canvas.refresh()

    def _copy_route(self):
        """Copy the read-out (the full route breakdown) to the clipboard."""
        lines = [self.readout.item(i).text() for i in range(self.readout.count())]
        if not lines:
            return
        try:
            QApplication.clipboard().setText('\n'.join(lines))
            self._set_status(f'Copied {len(lines)} route lines to clipboard', colour=_ACCENT)
        except Exception:
            pass

    def _draw_arrows(self, geoms, dome_pt):
        """Draw white flow-direction arrowheads along the feeder/dist/drop lines.
        Flow radiates from the AGG dome (the PON source): the feeder flows INTO
        the dome (from the POP), distribution + drops flow OUTWARD to the homes.
        Orientation per line is decided by distance-to-dome of its endpoints."""
        import math
        from qgis.core import QgsGeometry, QgsPointXY
        band = self._bands.get('arrow')
        if band is None:
            return
        band.reset(QgsWkbTypes.LineGeometry)
        if dome_pt is None:
            return
        dx0, dy0 = dome_pt.x(), dome_pt.y()
        def dist2(p): return (p.x() - dx0) ** 2 + (p.y() - dy0) ** 2

        def polylines(geom):
            try:
                if geom.isMultipart():
                    return [pl for pl in geom.asMultiPolyline() if len(pl) >= 2]
                pl = geom.asPolyline()
                return [pl] if len(pl) >= 2 else []
            except Exception:
                return []

        # arrowhead size from the route's OWN cluster extent (deterministic — the
        # canvas may still be mid-zoom when this runs)
        from qgis.core import QgsRectangle
        rect = None
        for hop in ('dist', 'drop', 'sts', 'dis', 'agg', 'feeder'):
            for g in geoms.get(hop, []):
                bb = g.boundingBox()
                if not bb.isEmpty():
                    rect = QgsRectangle(bb) if rect is None else (rect.combineExtentWith(bb) or rect)
        span = max(rect.width(), rect.height()) if rect else 0.005
        SIZE = min(max(span * 0.018, 2e-5), 1.2e-4)

        def add_head(p, ux, uy, sz):
            # chevron pointing along (ux,uy): [wingL, tip, wingR]
            bx, by = -ux * sz, -uy * sz                # back along flow
            px, py = -uy * sz * 0.55, ux * sz * 0.55   # perpendicular
            tip = QgsPointXY(p.x(), p.y())
            wl  = QgsPointXY(p.x() + bx + px, p.y() + by + py)
            wr  = QgsPointXY(p.x() + bx - px, p.y() + by - py)
            band.addGeometry(QgsGeometry.fromPolylineXY([wl, tip, wr]), None)

        # trunk arrows (feeder/dist) large & prominent; drop arrows small & subtle
        HOP_SZ = {'feeder': SIZE * 1.4, 'dist': SIZE * 1.3, 'drop': SIZE * 0.55}
        for hop in ('feeder', 'dist', 'drop'):
            outward = hop != 'feeder'               # feeder flows toward the dome
            sz = HOP_SZ[hop]
            for g in geoms.get(hop, []):
                for pl in polylines(g):
                    # orient vertex list upstream -> downstream
                    if outward:
                        if dist2(pl[0]) > dist2(pl[-1]):
                            pl = pl[::-1]            # ensure increasing dist (outward)
                    else:
                        if dist2(pl[0]) < dist2(pl[-1]):
                            pl = pl[::-1]            # ensure decreasing dist (toward dome)
                    # total length + sample points
                    segs = [(pl[i], pl[i + 1]) for i in range(len(pl) - 1)]
                    seglen = [math.hypot(b.x() - a.x(), b.y() - a.y()) for a, b in segs]
                    total = sum(seglen)
                    if total <= 0:
                        continue
                    # number of arrowheads: drops 1, trunk lines scale with length
                    n = 1 if hop == 'drop' else min(4, max(1, int(total / (SIZE * 6))))
                    for k in range(n):
                        target = total * (k + 1) / (n + 1)
                        acc = 0.0
                        for (a, b), L in zip(segs, seglen):
                            if acc + L >= target and L > 0:
                                t = (target - acc) / L
                                px = a.x() + (b.x() - a.x()) * t
                                py = a.y() + (b.y() - a.y()) * t
                                ux, uy = (b.x() - a.x()) / L, (b.y() - a.y()) / L
                                add_head(QgsPointXY(px, py), ux, uy, sz)
                                break
                            acc += L

    def _draw_labels(self, port, fts, sts_list, pon, feeder_lbls, show_drops,
                     emphasize=False, dist_cables=None):
        """Populate the text-label overlay: FTS, each STS leg + its DIS dome, the
        AGG dome, and the distribution + feeder cable IDs. When *emphasize* (a
        specific STS/DR is selected) the STS labels are drawn larger."""
        if not getattr(self, 'labels_chk', None) or not self.labels_chk.isChecked():
            self._labels.clear()
            return
        import re
        def sd(l):   # dome/pole tail: MOA.DIS.DM.P.F726 -> F726
            return re.sub(r'.*\.P\.', '', l or '')
        def sc(l):   # cable: MOA.DF.24F.P.F409-P.H263 -> F409-H263
            if not l:
                return ''
            return re.sub(r'^MOA\.\w+\.\d+F\.P\.', '', l).replace('-P.', '-')
        def ctr(g):
            try:
                return g.centroid().asPoint()
            except Exception:
                return None

        sts_sz = 14 if emphasize else 9       # selected splitter labels pop bigger
        items = []
        if fts and fts.get('geom') is not None and not fts['geom'].isEmpty():
            p = ctr(fts['geom'])
            if p: items.append((p, f'FTS 1:8 · {port}', QColor(245, 170, 255), 10))
        if fts and fts.get('agg_geom') is not None and not fts['agg_geom'].isEmpty():
            p = ctr(fts['agg_geom'])
            if p: items.append((p, 'AGG ' + sd(fts.get('agg')), QColor(120, 225, 245), 10))
        for s in sts_list:
            g = s.get('geom')
            if g is not None and not g.isEmpty():
                p = ctr(g)
                if p:
                    items.append((p, f"{s.get('leg') or 'STS'} · {sd(s.get('dis'))}",
                                  QColor(150, 245, 165), sts_sz))
        for dc in (dist_cables if dist_cables is not None
                   else self._idx['dist_by_pon'].get(str(pon), [])):
            g = dc.get('geom')
            if g is not None and not g.isEmpty():
                p = ctr(g)
                if p: items.append((p, sc(dc.get('label')), QColor(250, 180, 110), 9))
        for fl in (feeder_lbls or []):
            cab = self._idx['feed_by_label'].get(fl)
            if cab and cab.get('geom') is not None and not cab['geom'].isEmpty():
                p = ctr(cab['geom'])
                if p: items.append((p, 'feeder ' + sc(fl), QColor(255, 150, 150), 9))
        self._labels.set_items(items)

    def _zoom_to(self, geoms):
        from qgis.core import QgsRectangle
        rect = None
        # Frame the PON access cluster — the homes and their splitters/domes.
        # The feeder runs back to the POP and the distribution can fan out, so
        # zoom to drops/ONTs/STS/DIS first (the splice detail JJ checks); only
        # broaden to the other hops if that cluster is empty.
        cluster = ['drop', 'ont', 'sts', 'dis']
        broad   = ['agg', 'dist', 'fts', 'feeder']
        use = [h for h in cluster if geoms.get(h)]
        if not use:
            use = [h for h in (cluster + broad) if geoms.get(h)] or list(geoms.keys())
        for hop in use:
            for g in geoms.get(hop, []):
                bb = g.boundingBox()
                if bb.isEmpty():
                    continue
                rect = QgsRectangle(bb) if rect is None else (rect.combineExtentWith(bb) or rect)
        if rect is None or rect.isEmpty():
            return
        # buffer 12 %
        dx = rect.width() * 0.12 or 0.0005
        dy = rect.height() * 0.12 or 0.0005
        rect = QgsRectangle(rect.xMinimum() - dx, rect.yMinimum() - dy,
                            rect.xMaximum() + dx, rect.yMaximum() + dy)
        self.canvas.setExtent(rect)

    def _fill_readout(self, port, pon, only_sts, labels):
        from qgis.PyQt.QtWidgets import QListWidgetItem
        self.readout.clear()
        head = QListWidgetItem(
            f'━━ PON {pon} · Zone {self._pon_to_zone(pon)} · {port}'
            + (f'  ·  STS {only_sts.split(".")[-1]}' if only_sts else '  ·  WHOLE PON')
            + ' ━━')
        head.setForeground(QColor(_ACCENT)); self.readout.addItem(head)
        order = ['feeder', 'fts', 'agg', 'dist', 'sts', 'dis', 'drop', 'ont']
        for hop in order:
            vals = labels[hop]
            if not vals:
                continue
            hdr = QListWidgetItem(f'{_HOP_TITLES[hop]}  ({len(vals)})')
            hdr.setForeground(_HOP_COLOURS[hop]); self.readout.addItem(hdr)
            shown = vals if len(vals) <= 30 else vals[:30]
            for v in shown:
                self.readout.addItem(QListWidgetItem('   ' + str(v)))
            if len(vals) > 30:
                self.readout.addItem(QListWidgetItem(f'   … +{len(vals) - 30} more'))

    # ── solo (dim other layers) ──────────────────────────────────────────────
    def _apply_solo(self):
        """Fade every VECTOR layer to 15 % so only the bright route rubber bands
        (and the satellite basemap) stand out. Stores originals for restore."""
        from qgis.core import QgsVectorLayer
        if self._solo_saved is None:
            self._solo_saved = {}
            for l in QgsProject.instance().mapLayers().values():
                if isinstance(l, QgsVectorLayer):
                    try:
                        self._solo_saved[l.id()] = l.opacity()
                    except Exception:
                        pass
        for lid in list(self._solo_saved):
            l = QgsProject.instance().mapLayer(lid)
            if l:
                try:
                    l.setOpacity(0.15); l.triggerRepaint()
                except Exception:
                    pass

    def _restore_solo(self):
        if not self._solo_saved:
            self._solo_saved = None
            return
        for lid, op in self._solo_saved.items():
            l = QgsProject.instance().mapLayer(lid)
            if l:
                try:
                    l.setOpacity(op); l.triggerRepaint()
                except Exception:
                    pass
        self._solo_saved = None

    def _on_solo_toggled(self, on):
        # live toggle while a route is shown
        if on:
            if self.port_combo.currentData():
                self._apply_solo(); self.canvas.refresh()
        else:
            self._restore_solo(); self.canvas.refresh()

    def _set_status(self, msg, colour=_DIM):
        self._status_lbl.setText(msg)
        self._status_lbl.setStyleSheet(
            f"QLabel {{ color: {colour}; font-family: Consolas; font-size: 10px;"
            f" padding: 2px; }}")

    def _clear(self, keep_status=False):
        for hop, band in self._bands.items():
            gt = (QgsWkbTypes.LineGeometry if hop in ('feeder', 'dist', 'drop', 'arrow')
                  else QgsWkbTypes.PointGeometry)
            band.reset(gt)
        self._programmatic_select = True
        try:
            for lyr in self._layers.values():
                if lyr is not None:
                    try:
                        lyr.removeSelection()
                    except Exception:
                        pass
        finally:
            self._programmatic_select = False
        if getattr(self, '_labels', None) is not None:
            self._labels.clear()
        self._restore_solo()
        self.canvas.refresh()
        if not keep_status and hasattr(self, '_status_lbl'):
            self._set_status('Cleared.')

    def closeEvent(self, e):
        try:
            if getattr(self, '_xl_timer', None) is not None:
                self._xl_timer.stop()
        except Exception:
            pass
        # disconnect the per-layer selection handlers so they don't fire after close
        for lyr in self._layers.values():
            if lyr is not None:
                try:
                    lyr.selectionChanged.disconnect(self._on_user_select)
                except Exception:
                    pass
        self._clear()
        super().closeEvent(e)


# combo styling reused by the route viewer
_COMBO_CSS = (
    f"QComboBox {{ background:#11131f; color:{_TEXT}; border:1px solid {_BORDER};"
    f" border-radius:4px; padding:5px 8px; font-family:Consolas; font-size:11px; }}"
    f"QComboBox:hover {{ border-color:{_ACCENT}; }}"
    f"QComboBox QAbstractItemView {{ background:#11131f; color:{_TEXT};"
    f" selection-background-color:{_VIOLET}; font-family:Consolas; font-size:11px; }}")


# ── Merged Pole Editor panel ──────────────────────────────────────────────────

class PoleEditorPanel(QDialog):

    def __init__(self, iface, lyr, parent=None):
        super().__init__(iface.mainWindow(), Qt.Tool | Qt.WindowStaysOnTopHint)
        self.iface        = iface
        self.lyr          = lyr
        # Resolve thickness reason field name. Shapefile truncates to 10
        # chars ('thickness_'); GPKG keeps the full 'thickness_reason'.
        self.ti_thickness = lyr.fields().indexOf('thickness_')
        if self.ti_thickness < 0:
            self.ti_thickness = lyr.fields().indexOf('thickness_reason')
        if self.ti_thickness < 0:
            iface.messageBar().pushWarning(
                'Pole Editor',
                f"'{lyr.name()}' has no thickness_/thickness_reason field — "
                "RC and thickness buttons will be disabled."
            )
        self.ti_dim2      = lyr.fields().indexOf('dim2')
        # S5 Slack Bracket slot — note field name is 'subtype5' (NO underscore)
        self.ti_t5        = lyr.fields().indexOf('type_5')
        self.ti_st5       = lyr.fields().indexOf('subtype5')
        self.ti_sp5       = lyr.fields().indexOf('spec_5')
        self.ti_d5        = lyr.fields().indexOf('dim1_5')
        self.ti_d5_2      = lyr.fields().indexOf('dim2_5')
        self.setWindowTitle('Pole Editor')
        self.setMinimumWidth(360)

        # Static dashed rings — no animation, just visual markers.
        self._not_rc_geoms = {}
        self._blue_band = _SpinRing(
            iface.mapCanvas(), QColor(0, 170, 255, 255),          # electric blue
            radius_px=14, width_px=3.0, dash_pattern=[6, 3])
        self._yellow_band = _SpinRing(
            iface.mapCanvas(), QColor(0, 230, 80, 255),           # vivid lime
            radius_px=9, width_px=3.0, dash_pattern=[2, 2])
        self._red_band = _SpinRing(
            iface.mapCanvas(), QColor(255, 40, 80, 255),          # vivid red
            radius_px=11, width_px=3.0, dash_pattern=[1, 2])

        # Green diamonds — FTS splitters (reference overlay)
        self._fts_band = QgsRubberBand(iface.mapCanvas(), QgsWkbTypes.PointGeometry)
        self._fts_band.setColor(QColor(34, 197, 94, 255))           # bright green fill
        self._fts_band.setIcon(QgsRubberBand.ICON_FULL_DIAMOND)
        self._fts_band.setIconSize(26)
        self._fts_band.setWidth(3)                                    # outline stroke
        self._fts_band.setSecondaryStrokeColor(QColor(0, 80, 0, 220))  # dark green border

        # S5 band kept as a dummy so legacy callbacks don't AttributeError
        self._s5_band = QgsRubberBand(iface.mapCanvas(), QgsWkbTypes.PointGeometry)
        self._s5_band.setWidth(0)

        self._redraw_bands()

        # Keep the panel pinned to the canvas top-left corner
        canvas = iface.mapCanvas()
        canvas.installEventFilter(self)
        canvas.viewport().installEventFilter(self)

        # ── Layout ────────────────────────────────────────────────────────────
        self.setStyleSheet(_DIALOG_BG)
        layout = QVBoxLayout(self)
        layout.setSpacing(6)
        layout.setContentsMargins(12, 12, 12, 10)

        subtitle = QLabel('Click a pole on the map to select it, then:')
        subtitle.setStyleSheet(_SUBTITLE_LBL)
        layout.addWidget(subtitle)

        # Road crossing section
        rc_label = QLabel('ROAD CROSSING')
        rc_label.setStyleSheet(_SECTION_LBL)
        layout.addWidget(rc_label)

        rc_row = QHBoxLayout()
        rc_row.setSpacing(8)

        btn_mark_rc = QPushButton('🟢  Mark Road Crossing')
        btn_mark_rc.setStyleSheet(_BTN_GREEN)
        btn_mark_rc.clicked.connect(self._mark_rc)
        rc_row.addWidget(btn_mark_rc)

        btn_unmark_rc = QPushButton('🔴  Not Road Crossing')
        btn_unmark_rc.setStyleSheet(_BTN_RED)
        btn_unmark_rc.clicked.connect(self._unmark_rc)
        rc_row.addWidget(btn_unmark_rc)

        layout.addLayout(rc_row)

        # Divider
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setStyleSheet(_DIVIDER)
        layout.addWidget(line)

        # Thickness section
        th_label = QLabel('POLE THICKNESS')
        th_label.setStyleSheet(_SECTION_LBL)
        layout.addWidget(th_label)

        th_row = QHBoxLayout()
        th_row.setSpacing(8)

        btn_thick = QPushButton('🔵  140-160mm  (Thick)')
        btn_thick.setStyleSheet(_BTN_GRADIENT)
        btn_thick.clicked.connect(self._make_thick)
        th_row.addWidget(btn_thick)

        btn_thin = QPushButton('⚪  120-140mm  (Thin)')
        btn_thin.setStyleSheet(_BTN_CLEAR)
        btn_thin.clicked.connect(self._make_thin)
        th_row.addWidget(btn_thin)

        layout.addLayout(th_row)

        # Slack Bracket (S5) — manual-only per project_s5_slack_bracket_decision.md
        s5_label = QLabel('SLACK BRACKET (S5 · MANUAL)')
        s5_label.setStyleSheet(_SECTION_LBL)
        layout.addWidget(s5_label)

        s5_row = QHBoxLayout(); s5_row.setSpacing(8)
        btn_s5_add = QPushButton('🟣  Add Slack Bracket')
        btn_s5_add.setStyleSheet(_BTN_S5)
        btn_s5_add.clicked.connect(self._mark_s5)
        s5_row.addWidget(btn_s5_add)

        btn_s5_rm = QPushButton('🚫  Remove Slack Bracket')
        btn_s5_rm.setStyleSheet(_BTN_CLEAR)
        btn_s5_rm.clicked.connect(self._unmark_s5)
        s5_row.addWidget(btn_s5_rm)
        layout.addLayout(s5_row)

        # Status
        self._status_lbl = QLabel('')
        self._status_lbl.setWordWrap(True)
        self._status_lbl.setStyleSheet(_STATUS_LBL)
        layout.addWidget(self._status_lbl)

        # Legend — static dashed-ring previews that match the canvas overlays
        legend_frame = QFrame()
        legend_frame.setStyleSheet('background: transparent;')
        lg = QVBoxLayout(legend_frame)
        lg.setContentsMargins(0, 0, 0, 0)
        lg.setSpacing(4)
        for hex6, pattern, label in (
            ('#00aaff', [], '  large blue ring  =  140-160mm thick pole'),
            ('#00e650', [], '  medium green ring  =  road crossing'),
            ('#ff2850', [], '  small red ring  =  NOT a road crossing'),
        ):
            row = QHBoxLayout()
            row.setSpacing(6)
            ring = _SpinRingPreview(QColor(hex6), pattern, diameter_px=22, width_px=2.2)
            row.addWidget(ring)
            lbl = QLabel(label)
            lbl.setStyleSheet(_HINT_LBL)
            row.addWidget(lbl, 1)
            lg.addLayout(row)
        fts_lbl = QLabel('🟢 green diamond = FTS splitter (main cable origin)')
        fts_lbl.setStyleSheet(_HINT_LBL)
        lg.addWidget(fts_lbl)
        layout.addWidget(legend_frame)

        click_hint = QLabel('Click to select · Shift+click to add · Edits auto-fill attrs')
        click_hint.setWordWrap(True)
        click_hint.setStyleSheet(_HINT_LBL)
        layout.addWidget(click_hint)

    # ── Internals ─────────────────────────────────────────────────────────────

    def _set_status(self, msg, colour=_TEXT):
        self._status_lbl.setText(msg)
        self._status_lbl.setStyleSheet(
            f"QLabel {{ color: {colour}; font-family: Consolas; "
            f"font-size: 10px; padding: 2px; }}"
        )

    def _redraw_bands(self):
        blue_pts = []
        green_pts = []
        red_pts = []
        for f in self.lyr.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            pt = g.asPoint()
            if str(f['dim2']) == '140-160mm':
                blue_pts.append(pt)
            if 'road crossing' in str(f['thickness_']).lower():
                green_pts.append(pt)
        for geom in self._not_rc_geoms.values():
            if geom and not geom.isEmpty():
                red_pts.append(geom.asPoint())
        self._blue_band.setPoints(blue_pts)
        self._yellow_band.setPoints(green_pts)
        self._red_band.setPoints(red_pts)
        # FTS splitters — yellow diamonds (rubber band, not animated)
        self._fts_band.reset(QgsWkbTypes.PointGeometry)
        proj = QgsProject.instance()
        candidates = [l for l in proj.mapLayers().values()
                      if 'fts' in l.name().lower() and 'splitter' in l.name().lower()]
        fts_lyr = next((l for l in candidates if 'v1' in l.name().lower()), None) \
                  or (candidates[0] if candidates else None)
        if fts_lyr:
            for f in fts_lyr.getFeatures():
                g = f.geometry()
                if g and not g.isEmpty():
                    self._fts_band.addGeometry(g, None)

    def _write_attrs(self, attr_map):
        """Write attribute changes through the edit buffer when the layer is
        editable, otherwise via the data provider. Returns True on success."""
        if not attr_map:
            return True
        if self.lyr.isEditable():
            ok = True
            for fid, kv in attr_map.items():
                for idx, val in kv.items():
                    if not self.lyr.changeAttributeValue(fid, idx, val):
                        ok = False
            return ok
        return self.lyr.dataProvider().changeAttributeValues(attr_map)

    def _auto_populate_new(self, fids):
        """For any pole in *fids* that still has a null Label / Pole Type /
        hardware / lat / lon / dim2, compute and fill in the canonical PH2
        attribute set (H-sequence label, Pole Type from nearest cable, way
        count, Tangent-vs-Dead-End hardware per PH1 rule, Slot 4 Hook, Slot 6/7
        BandIt, dim2 default 140-160mm, lat/lon from geometry). Silent no-op
        for poles that already have everything filled in."""
        import math, re
        from qgis.core import QgsProject

        lyr = self.lyr
        flds = lyr.fields()
        def fi(n): return flds.indexOf(n)
        F_LBL=fi("Label"); F_PT=fi("Pole Type")
        F_T2=fi("type_2"); F_ST2=fi("subtype_2"); F_D2=fi("dim1_2"); F_SP2=fi("spec_2"); F_FN1=fi("featno1")
        F_T3=fi("type_3"); F_ST3=fi("subtype_3"); F_D3=fi("dim1_3"); F_SP3=fi("spec_3"); F_FN2=fi("featno2")
        F_T4=fi("type_4"); F_ST4=fi("subtype4"); F_SP4=fi("spec_4"); F_D4=fi("dim1_4"); F_FN3=fi("featno3"); F_FN4=fi("featno4")
        F_T6=fi("type_6"); F_ST6=fi("subtype_6"); F_SP6=fi("spec_6"); F_DM6=fi("dim1_6"); F_FN5=fi("featno5")
        F_T7=fi("type_7"); F_ST7=fi("subtype7");  F_SP7=fi("spec_7"); F_DM7=fi("dim1_7"); F_FN6=fi("featno6")
        F_LAT=fi("lat"); F_LON=fi("lon"); F_DIM2=fi("dim2")

        def is_null(v): return v is None or str(v).strip() in ("", "NULL", "None")

        needs = []
        for fid in fids:
            f = lyr.getFeature(fid)
            if (is_null(f.attribute(F_LBL)) or is_null(f.attribute(F_PT)) or
                (is_null(f.attribute(F_T2)) and is_null(f.attribute(F_T3))) or
                is_null(f.attribute(F_DIM2)) or is_null(f.attribute(F_LAT)) or
                is_null(f.attribute(F_LON)) or is_null(f.attribute(F_SP4)) or
                is_null(f.attribute(F_SP6))):
                needs.append(fid)
        if not needs:
            return

        target_geoms = {}
        for fid in needs:
            g = lyr.getFeature(fid).geometry()
            if g and not g.isEmpty():
                target_geoms[fid] = g.asPoint()
        if not target_geoms:
            return

        SNAP_M = 3.0
        SNAP_DEG = SNAP_M / 111320.0

        CABLE_LAYERS = [
            ("Primary Cable v1",    "Primary Feeder",   3),
            ("Secondary Cable v1",  "Secondary Feeder", 2),
            ("Distribution Cable v1","Distribution",    1),
            ("Drop Cable v1",       "Drop",             0),
        ]
        proj = QgsProject.instance()
        hits = {fid: [] for fid in target_geoms}
        for lname, ptype, rank in CABLE_LAYERS:
            clyr = next((l for l in proj.mapLayers().values()
                         if l.name().lower() == lname.lower()), None)
            if not clyr:
                continue
            for feat in clyr.getFeatures():
                g = feat.geometry()
                if not g or g.isEmpty():
                    continue
                cbb = g.boundingBox()
                relevant = [(fid, pt) for fid, pt in target_geoms.items()
                            if cbb.xMinimum() - SNAP_DEG <= pt.x() <= cbb.xMaximum() + SNAP_DEG
                            and cbb.yMinimum() - SNAP_DEG <= pt.y() <= cbb.yMaximum() + SNAP_DEG]
                if not relevant:
                    continue
                lines = [g.asPolyline()] if not g.isMultipart() else g.asMultiPolyline()
                for line in lines:
                    if len(line) < 2:
                        continue
                    for i, v in enumerate(line):
                        for fid, pt in relevant:
                            dx = v.x() - pt.x(); dy = v.y() - pt.y()
                            if (dx*dx + dy*dy) ** 0.5 > SNAP_DEG:
                                continue
                            neighbours = []
                            if i > 0:
                                for j in range(i - 1, -1, -1):
                                    nv = line[j]
                                    if ((nv.x() - pt.x())**2 + (nv.y() - pt.y())**2) ** 0.5 > SNAP_DEG:
                                        neighbours.append(nv); break
                            if i < len(line) - 1:
                                for j in range(i + 1, len(line)):
                                    nv = line[j]
                                    if ((nv.x() - pt.x())**2 + (nv.y() - pt.y())**2) ** 0.5 > SNAP_DEG:
                                        neighbours.append(nv); break
                            for nv in neighbours:
                                bin_ = round(math.degrees(math.atan2(nv.y() - pt.y(),
                                                                      nv.x() - pt.x())) / 15) * 15
                                hits[fid].append((bin_, rank, ptype))

        max_h = 0
        for f in lyr.getFeatures():
            m = re.search(r"\.H(\d+)$", str(f.attribute(F_LBL) or ""))
            if m:
                max_h = max(max_h, int(m.group(1)))

        null_lbl_fids = [fid for fid in needs
                         if is_null(lyr.getFeature(fid).attribute(F_LBL))]
        null_lbl_fids.sort()
        label_assign = {fid: f"MOA.P.H{max_h + 1 + i}"
                        for i, fid in enumerate(null_lbl_fids)}

        updates = {}
        for fid, pt in target_geoms.items():
            f = lyr.getFeature(fid)
            upd = updates.setdefault(fid, {})

            def fill(idx, val):
                # Only write if the cell is currently null — never clobber
                # a value the user set.
                if idx >= 0 and is_null(f.attribute(idx)):
                    upd[idx] = val

            if fid in label_assign:
                fill(F_LBL, label_assign[fid])

            h = hits.get(fid, [])
            non_drop_dirs = {x[0] for x in h if x[1] > 0}
            way_count = max(1, len(non_drop_dirs))

            cur_pt = str(f.attribute(F_PT))
            new_pt = None
            non_drop = [x for x in h if x[1] > 0]
            if non_drop:
                new_pt = max(non_drop, key=lambda x: x[1])[2]
            elif h:
                new_pt = "Drop"
            if is_null(cur_pt) and new_pt:
                fill(F_PT, new_pt)
                cur_pt = new_pt

            cur_t2 = str(f.attribute(F_T2))
            cur_t3 = str(f.attribute(F_T3))

            # Only write hardware slots if BOTH t2 and t3 are currently null
            # (i.e. the pole has never been classified). Never overwrite an
            # existing Tangent/Dead-End choice — that includes manual exceptions.
            if is_null(cur_t2) and is_null(cur_t3):
                cable_dim = "10,54-11,65mm" if cur_pt == "Primary Feeder" else "9,40-10,50mm"
                fill(F_T2, "Dead-End"); fill(F_ST2, "ADSS")
                fill(F_SP2, "Galvanised Steel Wire/Steel Thimble")
                fill(F_D2, cable_dim)
                fill(F_FN1, way_count)

            # Slot 4 Hook — fill only if null
            fill(F_T4, "Hook"); fill(F_ST4, "Offset Bracket")
            fill(F_SP4, f"{way_count}Way")
            fill(F_D4, f"(R19*W12,50mm)*{way_count}")
            fill(F_FN3, way_count)
            fill(F_FN4, 1)
            # Slot 6 / 7 BandIt — fill only if null
            fill(F_T6, "Attachment"); fill(F_ST6, "Strapping")
            fill(F_SP6, "Grade304 BandIt"); fill(F_DM6, "19*0,5mm"); fill(F_FN5, 4)
            fill(F_T7, "Attachment"); fill(F_ST7, "Buckle")
            fill(F_SP7, "Grade304 BandIt"); fill(F_DM7, "19mm"); fill(F_FN6, 2)

            # dim2 default — only if still null (never overwrites a manual 120/140)
            fill(F_DIM2, "140-160mm")
            # lat/lon — only if null
            if is_null(f.attribute(F_LAT)):
                fill(F_LAT, round(pt.y(), 6))
            if is_null(f.attribute(F_LON)):
                fill(F_LON, round(pt.x(), 6))

        # Drop empty update dicts
        updates = {k: v for k, v in updates.items() if v}
        if updates:
            self._write_attrs(updates)

    def _mark_rc(self):
        feats = self.lyr.selectedFeatures()
        if not feats:
            self._set_status('No poles selected — click a pole first.', '#f59e0b')
            return
        attr_map = {}
        skipped = 0
        for f in feats:
            cur = str(f[self.ti_thickness]).strip()
            self._not_rc_geoms.pop(f.id(), None)
            if 'road crossing' in cur.lower():
                skipped += 1
                continue
            new_val = (cur + '; road crossing') if cur not in ('', 'NULL', 'None') else 'road crossing'
            attr_map[f.id()] = {self.ti_thickness: new_val}
        if attr_map:
            self._write_attrs(attr_map)
            self._auto_populate_new([f.id() for f in feats])
            self.lyr.triggerRepaint()
        self._redraw_bands()
        msg = f'Marked {len(attr_map)} as road crossing'
        if skipped:
            msg += f'  ({skipped} already flagged)'
        self._set_status(msg, '#22c55e')

    def _unmark_rc(self):
        feats = self.lyr.selectedFeatures()
        if not feats:
            self._set_status('No poles selected — click a pole first.', '#f59e0b')
            return
        attr_map = {}
        skipped = 0
        for f in feats:
            cur = str(f[self.ti_thickness]).strip()
            if 'road crossing' not in cur.lower():
                skipped += 1
                continue
            new_val = (cur
                       .replace('; road crossing', '')
                       .replace('road crossing; ', '')
                       .replace('road crossing', '')
                       .strip().strip(';').strip())
            attr_map[f.id()] = {self.ti_thickness: new_val if new_val.lower() not in ('', 'null', 'none') else None}
            if f.geometry() and not f.geometry().isEmpty():
                self._not_rc_geoms[f.id()] = f.geometry()
        if attr_map:
            self._write_attrs(attr_map)
            self._auto_populate_new([f.id() for f in feats])
            self.lyr.triggerRepaint()
        self._redraw_bands()
        msg = f'Removed road crossing from {len(attr_map)} poles'
        if skipped:
            msg += f'  ({skipped} not flagged)'
        self._set_status(msg, '#ef4444')

    def _ensure_committed(self):
        """If the layer is in an edit session with pending changes, ask the
        user before committing. dataProvider().changeAttributeValues can't see
        uncommitted features (negative fids) so we need them flushed first."""
        if not self.lyr.isEditable():
            return True
        buf = self.lyr.editBuffer()
        if buf is None:
            # Editable but nothing pending — safe to leave as-is
            return True
        pending_add = len(buf.addedFeatures()) if hasattr(buf, "addedFeatures") else 0
        pending_chg = len(buf.changedAttributeValues()) if hasattr(buf, "changedAttributeValues") else 0
        pending_geo = len(buf.changedGeometries()) if hasattr(buf, "changedGeometries") else 0
        pending_del = len(buf.deletedFeatureIds()) if hasattr(buf, "deletedFeatureIds") else 0
        total = pending_add + pending_chg + pending_geo + pending_del
        if total == 0:
            return True

        from qgis.PyQt.QtWidgets import QMessageBox
        reply = QMessageBox.question(
            self, "Commit pending edits?",
            f"The poles layer has unsaved edits:\n"
            f"  • {pending_add} new pole(s)\n"
            f"  • {pending_chg} attribute change(s)\n"
            f"  • {pending_geo} geometry change(s)\n"
            f"  • {pending_del} deletion(s)\n\n"
            "The Pole Editor needs these saved before it can tag the new\n"
            "pole(s). Commit now and continue?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
        if reply != QMessageBox.Yes:
            self._set_status("Cancelled — commit your edits first.", "#f59e0b")
            return False
        ok = self.lyr.commitChanges()
        if not ok:
            err = "; ".join(self.lyr.commitErrors()[:3])
            self._set_status(f"Commit failed: {err}", "#ef4444")
            return False
        # Reopen edit session so user can keep drawing without losing mode
        self.lyr.startEditing()
        return True

    def _make_thick(self):
        feats = self.lyr.selectedFeatures()
        if not feats:
            self._set_status('No poles selected — click a pole first.', '#f59e0b')
            return
        attr_map = {}
        skipped = 0
        for f in feats:
            if str(f['dim2']) == '140-160mm':
                skipped += 1
                continue
            cur = str(f[self.ti_thickness]).strip()
            new_thick = (cur + '; manual override') if cur not in ('', 'NULL', 'None') else 'manual override'
            attr_map[f.id()] = {self.ti_dim2: '140-160mm', self.ti_thickness: new_thick}
        if attr_map:
            self._write_attrs(attr_map)
            self._auto_populate_new([f.id() for f in feats])
            self.lyr.triggerRepaint()
        self._redraw_bands()
        msg = f'Upgraded {len(attr_map)} to 140-160mm'
        if skipped:
            msg += f'  ({skipped} already thick)'
        self._set_status(msg, '#3b82f6')

    def _make_thin(self):
        feats = self.lyr.selectedFeatures()
        if not feats:
            self._set_status('No poles selected — click a pole first.', '#f59e0b')
            return
        attr_map = {}
        skipped = 0
        for f in feats:
            if str(f['dim2']) == '120-140mm':
                skipped += 1
                continue
            cur = str(f[self.ti_thickness]).strip()
            new_thick = (cur + '; manual override') if cur not in ('', 'NULL', 'None') else 'manual override'
            attr_map[f.id()] = {self.ti_dim2: '120-140mm', self.ti_thickness: new_thick}
        if attr_map:
            self._write_attrs(attr_map)
            self._auto_populate_new([f.id() for f in feats])
            self.lyr.triggerRepaint()
        self._redraw_bands()
        msg = f'Downgraded {len(attr_map)} to 120-140mm'
        if skipped:
            msg += f'  ({skipped} already thin)'
        self._set_status(msg, '#94a3b8')

    def _mark_s5(self):
        """Write canonical S5 Slack Bracket values to selected poles.
        Canonical values from PH2 live scan 2026-04-17: see
        project_s5_slack_bracket_decision.md."""
        feats = self.lyr.selectedFeatures()
        if not feats:
            self._set_status('No poles selected — click a pole first.', '#f59e0b')
            return
        if min(self.ti_t5, self.ti_st5, self.ti_sp5, self.ti_d5) < 0:
            self._set_status(
                'S5 fields missing (type_5 / subtype5 / spec_5 / dim1_5). '
                'Cannot write.', '#ef4444')
            return
        attr_map = {}
        skipped = 0
        for f in feats:
            if str(f['type_5']).strip() == 'Slack Bracket':
                skipped += 1
                continue
            row = {
                self.ti_t5:  'Slack Bracket',
                self.ti_st5: 'Bracket',
                self.ti_sp5: 'Extreme Slack',
                self.ti_d5:  'D620',
            }
            # dim2_5 'D516' confirmed against PH1 (4633 live examples, 2026-04-28)
            if self.ti_d5_2 >= 0:
                row[self.ti_d5_2] = 'D516'
            attr_map[f.id()] = row
        if attr_map:
            self._write_attrs(attr_map)
            self.lyr.triggerRepaint()
        self._redraw_bands()
        msg = f'Added Slack Bracket (S5) to {len(attr_map)} poles'
        if skipped:
            msg += f'  ({skipped} already had S5)'
        self._set_status(msg, '#7c3aed')

    def _unmark_s5(self):
        feats = self.lyr.selectedFeatures()
        if not feats:
            self._set_status('No poles selected — click a pole first.', '#f59e0b')
            return
        if min(self.ti_t5, self.ti_st5, self.ti_sp5, self.ti_d5) < 0:
            self._set_status(
                'S5 fields missing (type_5 / subtype5 / spec_5 / dim1_5). '
                'Cannot write.', '#ef4444')
            return
        attr_map = {}
        skipped = 0
        for f in feats:
            if str(f['type_5']).strip() != 'Slack Bracket':
                skipped += 1
                continue
            row = {
                self.ti_t5:  None,
                self.ti_st5: None,
                self.ti_sp5: None,
                self.ti_d5:  None,
            }
            if self.ti_d5_2 >= 0:
                row[self.ti_d5_2] = None
            attr_map[f.id()] = row
        if attr_map:
            self._write_attrs(attr_map)
            self.lyr.triggerRepaint()
        self._redraw_bands()
        msg = f'Removed Slack Bracket (S5) from {len(attr_map)} poles'
        if skipped:
            msg += f'  ({skipped} had no S5)'
        self._set_status(msg, '#94a3b8')

    def _snap_to_canvas_topleft(self):
        canvas = self.iface.mapCanvas()
        top_left = canvas.viewport().mapToGlobal(canvas.viewport().rect().topLeft())
        self.move(top_left.x() + 8, top_left.y() + 8)

    def _refresh_all_incomplete(self):
        """Auto-populate all poles that still have null Label / Pole Type /
        hardware / dim2 / lat / lon. Never overrides existing non-null values,
        so manual marks (road crossing, thick, thin, Tangent exceptions, S5)
        stay untouched."""
        try:
            fids = [f.id() for f in self.lyr.getFeatures()]
            self._auto_populate_new(fids)
        except Exception as e:
            print(f"[PoleEditor] auto-refresh skipped: {e}")

    def showEvent(self, event):
        super().showEvent(event)
        QTimer.singleShot(0, self._snap_to_canvas_topleft)
        # Fill in attrs on any new/incomplete poles when the panel opens
        QTimer.singleShot(50, self._refresh_all_incomplete)

    def eventFilter(self, obj, event):
        if event.type() in (QEvent.Resize, QEvent.Move, QEvent.Show):
            QTimer.singleShot(0, self._snap_to_canvas_topleft)
        return super().eventFilter(obj, event)

    def closeEvent(self, event):
        # Run a final auto-populate pass on the way out so anything you marked
        # during the session has full attrs before the panel disappears.
        try:
            self._refresh_all_incomplete()
        except Exception:
            pass
        canvas = self.iface.mapCanvas()
        canvas.removeEventFilter(self)
        canvas.viewport().removeEventFilter(self)
        scene = canvas.scene()
        for ring in (self._blue_band, self._yellow_band, self._red_band):
            ring.stop()
            ring.clear()
            if scene is not None and isinstance(ring, QgsMapCanvasItem):
                scene.removeItem(ring)
        self._fts_band.reset()
        self._s5_band.reset()
        super().closeEvent(event)


# ── Enclosure Editor panel ────────────────────────────────────────────────────
# claude:approved-destructive — writes only on explicit user button clicks; no bulk auto-run

class EnclosureEditorPanel(QDialog):
    """Floating panel for reclassifying enclosures on the canvas.

    Reads selected features from:
      - Enclosures Connectorised v1  (Distribution vs Spur Route)
      - Enclosures Splice v1         (UMJ/72F vs CMJ/144F)

    Use QGIS Select Features tool (S key) to click enclosures on the map,
    then click a type button to apply the canonical spec values.
    """

    _CONN_SPECS = {
        'distribution': {'spec_1': 'ODCFD0',       'cblcpty1': '24F', 'dim1': 'L220*W120*H73mm'},
        'spur':         {'spec_1': 'M16 Microloop', 'cblcpty1': '48F', 'dim1': 'H275*W160*D96mm'},
    }
    _SPLICE_SPECS = {
        'umj': {'spec_1': 'UMJ', 'cblcpty1': '72F',  'dim1': 'L250*W231*D164mm'},
        'cmj': {'spec_1': 'CMJ', 'cblcpty1': '144F', 'dim1': 'L290*W231*D164mm'},
    }

    def __init__(self, iface, parent=None):
        super().__init__(iface.mainWindow(), Qt.Tool | Qt.WindowStaysOnTopHint)
        self.iface = iface
        self.setWindowTitle('Enclosure Editor')
        self.setMinimumWidth(400)

        canvas = iface.mapCanvas()
        self._dist_band = QgsRubberBand(canvas, QgsWkbTypes.PointGeometry)
        self._dist_band.setColor(QColor(234, 115, 32, 210))
        self._dist_band.setIcon(QgsRubberBand.ICON_FULL_DIAMOND)
        self._dist_band.setIconSize(11)

        self._spur_band = QgsRubberBand(canvas, QgsWkbTypes.PointGeometry)
        self._spur_band.setColor(QColor(147, 51, 234, 210))
        self._spur_band.setIcon(QgsRubberBand.ICON_BOX)
        self._spur_band.setIconSize(13)

        self._umj_band = QgsRubberBand(canvas, QgsWkbTypes.PointGeometry)
        self._umj_band.setColor(QColor(8, 145, 178, 210))
        self._umj_band.setIcon(QgsRubberBand.ICON_CIRCLE)
        self._umj_band.setIconSize(11)

        self._cmj_band = QgsRubberBand(canvas, QgsWkbTypes.PointGeometry)
        self._cmj_band.setColor(QColor(34, 197, 94, 210))
        self._cmj_band.setIcon(QgsRubberBand.ICON_CIRCLE)
        self._cmj_band.setIconSize(13)

        # Cable route highlights — line rubber bands over Distribution Cable v1
        self._main_cable_band = QgsRubberBand(canvas, QgsWkbTypes.LineGeometry)
        self._main_cable_band.setColor(QColor(56, 189, 248, 170))   # sky blue
        self._main_cable_band.setWidth(4)

        self._spur_cable_band = QgsRubberBand(canvas, QgsWkbTypes.LineGeometry)
        self._spur_cable_band.setColor(QColor(234, 115, 32, 220))    # orange
        self._spur_cable_band.setWidth(4)

        # FTS splitter locations — large bright green diamonds
        self._fts_enc_band = QgsRubberBand(canvas, QgsWkbTypes.PointGeometry)
        self._fts_enc_band.setColor(QColor(34, 197, 94, 240))       # bright green fill
        self._fts_enc_band.setIcon(QgsRubberBand.ICON_FULL_DIAMOND)
        self._fts_enc_band.setIconSize(20)
        self._fts_enc_band.setWidth(4)                               # outline width
        self._fts_enc_band.setSecondaryStrokeColor(QColor(0, 60, 0, 255))  # dark border

        self._redraw_bands()
        self._redraw_cable_bands()

        canvas.installEventFilter(self)
        canvas.viewport().installEventFilter(self)

        self.setStyleSheet(_DIALOG_BG)
        layout = QVBoxLayout(self)
        layout.setSpacing(8)
        layout.setContentsMargins(12, 12, 12, 12)

        # ── How to use ─────────────────────────────────────────────────────
        steps_frame = QFrame()
        steps_frame.setStyleSheet(
            f"QFrame {{ background: {_PANEL}; border-radius: 6px;"
            f" border: 1px solid {_BORDER}; }}")
        sl = QVBoxLayout(steps_frame)
        sl.setContentsMargins(10, 8, 10, 8)
        sl.setSpacing(3)
        how_lbl = QLabel("HOW TO USE")
        how_lbl.setStyleSheet(_SECTION_LBL)
        sl.addWidget(how_lbl)
        _step_ss = (f"QLabel {{ color: {_TEXT}; font-family: 'Segoe UI';"
                    f" font-size: 10px; }}")
        for step in (
            "1  Press S key, then click an enclosure on the map",
            "2  Shift+click to add more enclosures to the selection",
            "3  Click the correct type button below",
        ):
            lbl = QLabel(step)
            lbl.setStyleSheet(_step_ss)
            sl.addWidget(lbl)

        div = QFrame()
        div.setFrameShape(QFrame.HLine)
        div.setStyleSheet(f"QFrame {{ color: {_BORDER}; margin-top: 4px; }}")
        sl.addWidget(div)

        ovr_hdr = QLabel("CANVAS OVERLAY — Distribution cables")
        ovr_hdr.setStyleSheet(_SECTION_LBL)
        sl.addWidget(ovr_hdr)
        _ovr_ss = (f"QLabel {{ color: {_TEXT}; font-family: 'Segoe UI'; font-size: 9px; }}")
        for col, sym, desc in (
            ("#38bdf8", "━━━", "Main distribution route"),
            ("#ea7320", "━━━", "Spur cable (branches off main)"),
        ):
            row_lbl = QLabel(
                f'<span style="color:{col}; font-weight:900; font-size:13px">{sym}</span>'
                f'  {desc}')
            row_lbl.setStyleSheet(_ovr_ss)
            sl.addWidget(row_lbl)
        layout.addWidget(steps_frame)

        # ── Connectorised section ───────────────────────────────────────────
        _hdr_ss = (f"QLabel {{ color: {_TEXT}; font-family: 'Segoe UI';"
                   f" font-size: 10px; font-weight: 700; padding-top: 4px; }}")
        conn_hdr = QLabel(
            '<span style="color:#ea7320">◆</span>'
            ' <span style="color:#9333ea">■</span>'
            '  CONNECTORISED  —  Enclosures Connectorised v1')
        conn_hdr.setStyleSheet(_hdr_ss)
        layout.addWidget(conn_hdr)

        conn_leg = QLabel(
            '<span style="color:#ea7320">◆ orange diamond</span>'
            '  = Distribution   '
            '<span style="color:#9333ea">■ purple square</span>'
            '  = Spur Route')
        conn_leg.setStyleSheet(
            f"QLabel {{ color: {_DIM}; font-family: 'Segoe UI'; font-size: 9px; }}")
        layout.addWidget(conn_leg)

        def _tall_btn(base, extra=''):
            return (base.replace('min-height: 32px', 'min-height: 60px')
                       .replace('font-size: 11px', 'font-size: 10px') + extra)

        conn_row = QHBoxLayout()
        conn_row.setSpacing(8)
        btn_dist = QPushButton(
            '◆  DISTRIBUTION\nODCFD0  ·  24F  ·  6-8 drops\nAlong main distribution route')
        btn_dist.setStyleSheet(_tall_btn(_BTN_ORANGE))
        btn_dist.clicked.connect(self._set_distribution)
        conn_row.addWidget(btn_dist)
        btn_spur = QPushButton(
            '■  SPUR ROUTE\nM16 Microloop  ·  48F  ·  16 drops\nAt cable branch-off point only')
        btn_spur.setStyleSheet(_tall_btn(_BTN_PURPLE))
        btn_spur.clicked.connect(self._set_spur)
        conn_row.addWidget(btn_spur)
        layout.addLayout(conn_row)

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setStyleSheet(_DIVIDER)
        layout.addWidget(line)

        # ── Splice section ──────────────────────────────────────────────────
        splice_hdr = QLabel(
            '<span style="color:#0891b2">●</span>'
            ' <span style="color:#22c55e">●</span>'
            '  SPLICE  —  Enclosures Splice v1  (feeder domes)')
        splice_hdr.setStyleSheet(_hdr_ss)
        layout.addWidget(splice_hdr)

        splice_leg = QLabel(
            '<span style="color:#0891b2">● cyan circle</span>'
            '  = Secondary feeder   '
            '<span style="color:#22c55e">● green circle</span>'
            '  = Primary feeder')
        splice_leg.setStyleSheet(
            f"QLabel {{ color: {_DIM}; font-family: 'Segoe UI'; font-size: 9px; }}")
        layout.addWidget(splice_leg)

        splice_row = QHBoxLayout()
        splice_row.setSpacing(8)
        btn_umj = QPushButton(
            '●  UMJ\n72F  ·  Secondary feeder\nAt secondary cable splice points')
        btn_umj.setStyleSheet(_tall_btn(_BTN_CYAN))
        btn_umj.clicked.connect(self._set_umj)
        splice_row.addWidget(btn_umj)
        btn_cmj = QPushButton(
            '●  CMJ\n144F  ·  Primary feeder\nAt primary cable splice points')
        btn_cmj.setStyleSheet(_tall_btn(_BTN_TEAL))
        btn_cmj.clicked.connect(self._set_cmj)
        splice_row.addWidget(btn_cmj)
        layout.addLayout(splice_row)

        # ── Summary + status ────────────────────────────────────────────────
        self._status_lbl = QLabel('')
        self._status_lbl.setWordWrap(True)
        self._status_lbl.setStyleSheet(_STATUS_LBL)
        layout.addWidget(self._status_lbl)

        self._summary_lbl = QLabel('')
        self._summary_lbl.setStyleSheet(_HINT_LBL)
        layout.addWidget(self._summary_lbl)

        self._update_summary()

    def _get_conn_lyr(self):
        return next((l for l in QgsProject.instance().mapLayers().values()
                     if l.name() == 'Enclosures Connectorised v1'), None)

    def _get_splice_lyr(self):
        return next((l for l in QgsProject.instance().mapLayers().values()
                     if l.name() == 'Enclosures Splice v1'), None)

    def _redraw_bands(self):
        conn_lyr   = self._get_conn_lyr()
        splice_lyr = self._get_splice_lyr()
        for band in (self._dist_band, self._spur_band,
                     self._umj_band, self._cmj_band,
                     self._fts_enc_band):
            band.reset(QgsWkbTypes.PointGeometry)
        fts_lyr = next((l for l in QgsProject.instance().mapLayers().values()
                        if l.name() == 'FTS Splitters v1'), None)
        if fts_lyr:
            for f in fts_lyr.getFeatures():
                g = f.geometry()
                if g and not g.isEmpty():
                    self._fts_enc_band.addGeometry(g, None)
        if conn_lyr:
            for f in conn_lyr.getFeatures():
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                if str(f['spec_1']) == 'M16 Microloop':
                    self._spur_band.addGeometry(g, None)
                else:
                    self._dist_band.addGeometry(g, None)
        if splice_lyr:
            for f in splice_lyr.getFeatures():
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                if str(f['spec_1']) == 'CMJ':
                    self._cmj_band.addGeometry(g, None)
                else:
                    self._umj_band.addGeometry(g, None)

    def _set_status(self, msg, colour='#e2e8f0'):
        self._status_lbl.setText(msg)
        self._status_lbl.setStyleSheet(
            f"QLabel {{ color: {colour}; font-family: Consolas; "
            f"font-size: 10px; padding: 2px; }}"
        )

    def _update_summary(self):
        parts = []
        conn_lyr = self._get_conn_lyr()
        if conn_lyr:
            feats  = list(conn_lyr.getFeatures())
            n_spur = sum(1 for f in feats if str(f['spec_1']) == 'M16 Microloop')
            parts.append(f'Conn: {len(feats) - n_spur} dist  {n_spur} spur')
        splice_lyr = self._get_splice_lyr()
        if splice_lyr:
            feats = list(splice_lyr.getFeatures())
            n_cmj = sum(1 for f in feats if str(f['spec_1']) == 'CMJ')
            parts.append(f'Splice: {len(feats) - n_cmj} UMJ  {n_cmj} CMJ')
        self._summary_lbl.setText('  |  '.join(parts))

    def _write_attrs(self, lyr, spec_vals):
        """Bulk-write spec_vals to all selected features in lyr."""
        if not lyr:
            return 0
        feats = lyr.selectedFeatures()
        if not feats:
            return 0
        flds    = lyr.fields()
        indices = {k: flds.indexOf(k) for k in spec_vals}
        writes  = {}
        for f in feats:
            row = {indices[k]: v for k, v in spec_vals.items() if indices[k] >= 0}
            if row:
                writes[f.id()] = row
        if writes:
            lyr.dataProvider().changeAttributeValues(writes)
            lyr.triggerRepaint()
        return len(writes)

    def _set_distribution(self):
        n = self._write_attrs(self._get_conn_lyr(), self._CONN_SPECS['distribution'])
        if n:
            self._redraw_bands(); self._update_summary()
            self._set_status(f'Changed {n}  Distribution (ODCFD0 / 24F)', '#ea7320')
        else:
            self._set_status(
                'No Connectorised enclosures selected.\n'
                'Use S key + click an orange/purple dot.', '#f59e0b')

    def _set_spur(self):
        n = self._write_attrs(self._get_conn_lyr(), self._CONN_SPECS['spur'])
        if n:
            self._redraw_bands(); self._update_summary()
            self._set_status(
                f'Changed {n}  Spur Route (M16 Microloop / 48F)', '#9333ea')
        else:
            self._set_status(
                'No Connectorised enclosures selected.\n'
                'Use S key + click an orange/purple dot.', '#f59e0b')

    def _set_umj(self):
        n = self._write_attrs(self._get_splice_lyr(), self._SPLICE_SPECS['umj'])
        if n:
            self._redraw_bands(); self._update_summary()
            self._set_status(f'Changed {n}  UMJ / 72F  (Secondary feeder)', '#0891b2')
        else:
            self._set_status(
                'No Splice enclosures selected.\n'
                'Use S key + click a cyan/green dot.', '#f59e0b')

    def _set_cmj(self):
        n = self._write_attrs(self._get_splice_lyr(), self._SPLICE_SPECS['cmj'])
        if n:
            self._redraw_bands(); self._update_summary()
            self._set_status(f'Changed {n}  CMJ / 144F  (Primary feeder)', '#22c55e')
        else:
            self._set_status(
                'No Splice enclosures selected.\n'
                'Use S key + click a cyan/green dot.', '#f59e0b')

    def _snap_to_canvas_topleft(self):
        canvas = self.iface.mapCanvas()
        tl = canvas.viewport().mapToGlobal(canvas.viewport().rect().topLeft())
        self.move(tl.x() + 8, tl.y() + 8)

    def showEvent(self, event):
        super().showEvent(event)
        QTimer.singleShot(0, self._snap_to_canvas_topleft)

    def eventFilter(self, obj, event):
        if event.type() in (QEvent.Resize, QEvent.Move, QEvent.Show):
            QTimer.singleShot(0, self._snap_to_canvas_topleft)
        return super().eventFilter(obj, event)

    def _get_dist_lyr(self):
        return next((l for l in QgsProject.instance().mapLayers().values()
                     if l.name() == 'Distribution Cable v1'), None)

    def _classify_cables(self):
        """Return (main_fids, spur_fids) for Distribution Cable v1.

        Algorithm:
          1. Seed: cables whose endpoint is within FTS_SNAP of an FTS Splitter v1
          2. Network BFS: expand through connected cables (endpoints within VERTEX_SNAP)
             - Only propagate along a cable if its far end has degree >= 2 (not a dead-end)
             - If both ends of a cable are already visited (loop), always add as main
          3. Main = everything reachable; Spur = unreachable dead-end branches
        """
        from qgis.core import QgsPointXY, QgsGeometry
        dist_lyr = self._get_dist_lyr()
        fts_lyr  = next((l for l in QgsProject.instance().mapLayers().values()
                         if l.name() == 'FTS Splitters v1'), None)
        if not dist_lyr:
            return set(), set()

        FTS_SNAP    = 12.0 / 111320.0  # 12 m — cable endpoint at FTS pole
        VERTEX_SNAP = 6.0  / 111320.0  # 6 m  — shared cable endpoint (connected)

        # --- collect cable endpoints ---
        cable_pts = {}   # fid -> (start_QgsPointXY, end_QgsPointXY)
        for cable in dist_lyr.getFeatures():
            g = cable.geometry()
            if not g or g.isEmpty():
                continue
            verts = (g.asPolyline() if not g.isMultipart()
                     else [v for part in g.asMultiPolyline() for v in part])
            if len(verts) < 2:
                continue
            cable_pts[cable.id()] = (QgsPointXY(verts[0]), QgsPointXY(verts[-1]))

        # --- quantize endpoints into node keys ---
        def node_key(pt):
            return (round(pt.x() / VERTEX_SNAP), round(pt.y() / VERTEX_SNAP))

        node_cables = {}   # node_key -> set of fids touching that node
        cable_nodes = {}   # fid -> (node_start, node_end)
        for fid, (s, e) in cable_pts.items():
            ns, ne = node_key(s), node_key(e)
            cable_nodes[fid] = (ns, ne)
            node_cables.setdefault(ns, set()).add(fid)
            node_cables.setdefault(ne, set()).add(fid)

        # --- find FTS-attached nodes ---
        fts_geoms = []
        if fts_lyr:
            for f in fts_lyr.getFeatures():
                if f.hasGeometry():
                    fts_geoms.append(f.geometry())

        def near_fts(pt):
            g = QgsGeometry.fromPointXY(pt)
            return any(g.distance(fg) <= FTS_SNAP for fg in fts_geoms)

        fts_nodes = set()
        for fid, (s, e) in cable_pts.items():
            ns, ne = cable_nodes[fid]
            if near_fts(s):
                fts_nodes.add(ns)
            if near_fts(e):
                fts_nodes.add(ne)

        # --- seed: cables with an endpoint at an FTS node ---
        main_fids = set()
        visited_nodes = set(fts_nodes)
        for fid, (ns, ne) in cable_nodes.items():
            if ns in fts_nodes or ne in fts_nodes:
                main_fids.add(fid)
                visited_nodes.add(ns)
                visited_nodes.add(ne)

        # --- BFS: propagate main status through the backbone ---
        changed = True
        while changed:
            changed = False
            for fid, (ns, ne) in cable_nodes.items():
                if fid in main_fids:
                    continue
                s_vis = ns in visited_nodes
                e_vis = ne in visited_nodes
                if not s_vis and not e_vis:
                    continue
                if s_vis and e_vis:
                    # Cable connects two already-visited nodes (closes a loop) → main
                    main_fids.add(fid)
                    changed = True
                    continue
                # One end visited, one end not: only extend if far end is not a dead-end
                far_node = ne if s_vis else ns
                if len(node_cables.get(far_node, set())) >= 2:
                    main_fids.add(fid)
                    visited_nodes.add(far_node)
                    changed = True

        spur_fids = set(cable_pts.keys()) - main_fids
        return main_fids, spur_fids

    def _redraw_cable_bands(self):
        self._main_cable_band.reset(QgsWkbTypes.LineGeometry)
        self._spur_cable_band.reset(QgsWkbTypes.LineGeometry)
        dist_lyr = self._get_dist_lyr()
        if not dist_lyr:
            return
        main_fids, spur_fids = self._classify_cables()
        crs = dist_lyr.crs()
        for cable in dist_lyr.getFeatures():
            g = cable.geometry()
            if not g or g.isEmpty():
                continue
            if cable.id() in spur_fids:
                self._spur_cable_band.addGeometry(g, crs)
            else:
                self._main_cable_band.addGeometry(g, crs)

    def closeEvent(self, event):
        canvas = self.iface.mapCanvas()
        canvas.removeEventFilter(self)
        canvas.viewport().removeEventFilter(self)
        scene = canvas.scene()
        for band in (self._dist_band, self._spur_band,
                     self._umj_band, self._cmj_band,
                     self._main_cable_band, self._spur_cable_band,
                     self._fts_enc_band):
            band.reset()
            try:
                scene.removeItem(band)
            except Exception:
                pass
        # Clear any lingering q.py test rubber bands on the iface namespace
        for b in getattr(self.iface, '_spur_check_bands', []):
            try:
                b.reset()
                scene.removeItem(b)
            except Exception:
                pass
        self.iface._spur_check_bands = []
        canvas.refresh()
        super().closeEvent(event)
