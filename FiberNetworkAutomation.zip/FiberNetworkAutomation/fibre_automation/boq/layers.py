"""layers — robust, client-agnostic layer resolution for the BoQ engines.

A teammate's project may spell a layer slightly differently ("Feeder Joints" vs
"Feeder Joint" vs "FeederJoints" vs "feeder_joints") or carry stray spaces
("Trenching "). A BoQ that misses a layer silently under-bills. This resolver finds
the intended layer by, in order of confidence:

  1. exact        — normalised names equal (case/space/punctuation-insensitive)
  2. alias        — an explicit alias matches exactly (normalised)
  3. substring    — one normalised name contains the other
  4. fuzzy        — difflib ratio >= min_ratio (default 0.82)

It ALWAYS reports which name matched and by what method (never a silent guess), so
the BoQ can surface "matched 'Feeder Joint' as Feeder Joints (fuzzy 0.91)". Pure
(the only QGIS touch is reading layer names/validity), so the matcher is unit- and
property-testable without QGIS via ``resolve_name``.
"""
import difflib
import re

_NON_ALNUM = re.compile(r"[^a-z0-9]+")


def _norm(s):
    """Lowercase + drop every non-alphanumeric char ('Feeder Joints ' -> 'feederjoints')."""
    return _NON_ALNUM.sub("", str(s or "").lower())


def resolve_name(canonical, candidates, aliases=(), min_ratio=0.82):
    """PURE core (no QGIS): pick the best candidate NAME for ``canonical``.

    Returns (matched_name, method, score) or (None, "none", 0.0). ``candidates`` is a
    list of real layer-name strings. Order of confidence: exact > alias > substring >
    fuzzy. ``substring`` only fires when the shorter normalised string is a real
    prefix/whole-token-ish chunk (length >= 4) of the other, to avoid 'core' matching
    'Scorecard'. Deterministic: ties break on the earliest candidate.
    """
    targets = [canonical] + list(aliases)
    tnorms = [t for t in (_norm(x) for x in targets) if t]
    if not tnorms or not candidates:
        return (None, "none", 0.0)

    norm_c = [(_norm(nm), nm) for nm in candidates]

    # 1 exact (canonical) then 2 alias-exact — same normalised comparison, but report
    for i, tn in enumerate(tnorms):
        for cn, raw in norm_c:
            if cn == tn:
                return (raw, "exact" if i == 0 else "alias", 1.0)

    # 3 substring — shorter must be >= 4 chars and a substring of the longer
    for cn, raw in norm_c:
        for tn in tnorms:
            if len(min(cn, tn, key=len)) >= 4 and (tn in cn or cn in tn):
                return (raw, "substring", 0.95)

    # 4 fuzzy — best difflib ratio across all targets, above threshold
    best = (None, "none", 0.0)
    for cn, raw in norm_c:
        r = max(difflib.SequenceMatcher(None, tn, cn).ratio() for tn in tnorms)
        if r >= min_ratio and r > best[2]:
            best = (raw, "fuzzy", round(r, 3))
    return best


def find_layer(project, canonical, aliases=(), min_ratio=0.82, want_geom=None):
    """Resolve ``canonical`` to a live QgsVectorLayer. Returns (layer, matched_name,
    method, score); layer is None if nothing matched confidently.

    ``want_geom`` optionally restricts to a geometry type ('Point'/'Line'/'Polygon')
    so 'Distribution' resolves to the cable line, not a same-named point layer.
    """
    from qgis.core import QgsVectorLayer, QgsWkbTypes
    gmap = {"Point": QgsWkbTypes.PointGeometry, "Line": QgsWkbTypes.LineGeometry,
            "Polygon": QgsWkbTypes.PolygonGeometry}
    want = gmap.get(want_geom)
    cands = []
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
            continue
        if want is not None and QgsWkbTypes.geometryType(lyr.wkbType()) != want:
            continue
        cands.append(lyr)
    by_name = {}
    for lyr in cands:
        by_name.setdefault(lyr.name(), lyr)      # first wins on duplicate names
    matched, method, score = resolve_name(canonical, list(by_name.keys()),
                                          aliases=aliases, min_ratio=min_ratio)
    return (by_name.get(matched), matched, method, score)
