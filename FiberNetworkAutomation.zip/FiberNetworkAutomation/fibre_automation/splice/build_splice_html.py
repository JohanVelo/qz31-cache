#!/usr/bin/env python3
"""
MOA Phase 2 Splice Plan — Interactive HTML Visualiser
Generates a single self-contained HTML file with all splice plan data embedded.
Output: C:/Users/jjsch/OneDrive/ON LAPTOP FIBRE/QGIS test/MOA_Splice_Plan.html
"""
import json
import re
from pathlib import Path

DATA = json.loads(Path('C:/Temp/splice_data.json').read_text())
fts_list       = DATA['fts']
sts_list       = DATA['sts']
agg_domes      = DATA['agg_domes']
dis_domes      = DATA['dis_domes']
primary        = DATA['primary']
secondary      = DATA['secondary']
distribution   = DATA['distribution']
drops          = DATA['drops']
pon_ont_counts = DATA['pon_ont_counts']

OUTPUT = 'C:/Users/jjsch/OneDrive/ON LAPTOP FIBRE/QGIS test/MOA_Splice_Plan.html'
OLT_OFFSETS = {15: 224, 16: 240, 17: 256, 18: 272, 19: 288}

def parse_olt(s):
    m = re.match(r'C(\d+)P(\d+)', s or '')
    if not m: return None
    c, p = int(m.group(1)), int(m.group(2))
    return {'card': c, 'port': p, 'pon': OLT_OFFSETS.get(c, 0) + p}

def parse_fts(label):
    m = re.match(r'(MOA\.FTS\.\d+\.AGG\.DM\.P\.\w+)-OLT\.01\.(C\d+P\d+)', label or '')
    if not m: return None
    fts_base, olt = m.group(1), m.group(2)
    agg_dome = re.sub(r'FTS\.\d+\.', '', fts_base)
    o = parse_olt(olt)
    if not o: return None
    return {'label': label, 'agg_dome': agg_dome, 'olt_port': olt,
            'card': o['card'], 'port': o['port'], 'pon': o['pon']}

def parse_sts(label):
    m = re.match(r'(MOA\.STS\.\d+\.DIS\.DM\.P\.\w+)\.(C\d+P\d+)\.L(\d+)', label or '')
    if not m: return None
    sts_base, olt, leg = m.group(1), m.group(2), int(m.group(3))
    dis_dome = re.sub(r'STS\.\d+\.', '', sts_base)
    o = parse_olt(olt)
    return {'label': label, 'dis_dome': dis_dome, 'olt_port': olt,
            'leg': leg, 'pon': o['pon'] if o else None}

def extract_dr(s):
    m = re.search(r'DR\d+', s or '')
    return m.group(0) if m else ''

def pon_to_zone(pon): return (pon - 235) // 16 + 17

# ── Lookups ───────────────────────────────────────────────────────────────────
agg_by_label = {d['label_1']: d for d in agg_domes if d.get('label_1')}
dis_by_label = {d['label_1']: d for d in dis_domes  if d.get('label_1')}

fts_by_pon = {}
for f in fts_list:
    lbl = f.get('label') or f.get('label_1') or ''
    p = parse_fts(lbl)
    if p:
        p.update({k: f.get(k) for k in ('strtfeat','lat','lon')})
        fts_by_pon[p['pon']] = p

sts_by_pon = {}
for s in sts_list:
    lbl = s.get('label') or s.get('label_1') or ''
    p = parse_sts(lbl)
    if p:
        sts_by_pon.setdefault(p['pon'], []).append(p)
for pon in sts_by_pon:
    sts_by_pon[pon].sort(key=lambda x: x['leg'])

drops_by_dis = {}
for dr in drops:
    key = dr.get('strtfeat') or ''
    if key:
        drops_by_dis.setdefault(key, []).append(dr)
for key in drops_by_dis:
    drops_by_dis[key].sort(
        key=lambda x: int(re.search(r'\d+', x.get('label','0')).group(0))
        if re.search(r'\d+', x.get('label','0')) else 0
    )

dist_by_pon = {}
for dc in distribution:
    pn = str(dc.get('pon_no') or '')
    if pn and pn != 'None':
        dist_by_pon.setdefault(pn, []).append(dc)

prim_by_pon = {}
for c in primary:
    pn = str(c.get('pon_no') or '')
    if pn and pn != 'None':
        prim_by_pon.setdefault(pn, []).append(c)

sec_by_pon = {}
for c in secondary:
    pn = str(c.get('pon_no') or '')
    if pn and pn != 'None':
        sec_by_pon.setdefault(pn, []).append(c)

all_pons = sorted(fts_by_pon.keys())

# ── Fiber assignment ──────────────────────────────────────────────────────────
prim_fiber_map = {}
prim_cable_map = {}
cable_fiber_ctr = {}
for pon in all_pons:
    cables = prim_by_pon.get(str(pon), [])
    lbl = cables[0].get('label', f'PRIMARY-Z{pon_to_zone(pon)}') if cables else f'PRIMARY-Z{pon_to_zone(pon)}'
    cable_fiber_ctr.setdefault(lbl, 0)
    cable_fiber_ctr[lbl] += 1
    prim_fiber_map[pon] = f"F{cable_fiber_ctr[lbl]}"
    prim_cable_map[pon] = cables[0].get('label', '') if cables else ''

_all_feeder = primary + secondary
_endfeat_idx = {}
for _c in _all_feeder:
    _ef = _c.get('endfeat', '')
    if _ef:
        _endfeat_idx.setdefault(_ef, []).append(_c)

def _joint_at(pole):
    return next((a['label_1'] for a in agg_domes if a.get('strtfeat') == pole), pole)

def feeder_hops(pon, fts):
    fiber    = prim_fiber_map[pon]
    fts_pole = fts.get('strtfeat', '')
    hops     = []
    current  = fts_pole
    visited  = set()
    while current and current not in visited and len(hops) < 5:
        visited.add(current)
        cables = _endfeat_idx.get(current, [])
        if not cables:
            break
        cable = cables[0]
        lbl   = cable.get('label', '')
        strt  = cable.get('strtfeat', '')
        j_end   = _joint_at(current)
        j_start = _joint_at(strt) if strt else strt
        hops.insert(0, {'fiber_in': fiber, 'cable': lbl, 'joint_start': j_start, 'joint_end': j_end, 'fiber_out': fiber})
        current = strt
    return hops

def dist_assignment(pon, fts, sts_list_pon):
    dist_cables = dist_by_pon.get(str(pon), [])
    endfeat_to_cable = {c.get('endfeat',''): c for c in dist_cables if c.get('endfeat')}
    cable_fiber_ctr2 = {}
    result = []
    for sts in sts_list_pon:
        dis_info = dis_by_label.get(sts['dis_dome'])
        dis_pole = dis_info['strtfeat'] if dis_info else ''
        cable = endfeat_to_cable.get(dis_pole)
        if not cable and dist_cables:
            idx = len(result) // 24
            cable = dist_cables[min(idx, len(dist_cables)-1)]
        cable_lbl = cable.get('label','') if cable else ''
        strt_pole = cable.get('strtfeat','') if cable else ''
        cable_fiber_ctr2.setdefault(cable_lbl, 0)
        cable_fiber_ctr2[cable_lbl] += 1
        fiber = f"F{cable_fiber_ctr2[cable_lbl]}"
        result.append({
            'sts': sts, 'cable': cable_lbl, 'strt_pole': strt_pole,
            'dis_dome': sts['dis_dome'], 'fiber': fiber
        })
    return result

# ── Build embed data ──────────────────────────────────────────────────────────
port_allocs = []
for pon in all_pons:
    fts = fts_by_pon[pon]
    port_allocs.append({
        'olt': 'OLT.01', 'card': fts['card'], 'port': fts['port'],
        'fiber': prim_fiber_map[pon], 'cable': prim_cable_map[pon],
        'pon': pon, 'zone': pon_to_zone(pon),
        'units': int(pon_ont_counts.get(str(pon), 0)),
        'olt_port': fts['olt_port'],
    })

pons_data = {}
for pon in all_pons:
    fts  = fts_by_pon[pon]
    hops = feeder_hops(pon, fts)
    sts_list_pon = sts_by_pon.get(pon, [])
    assignments  = dist_assignment(pon, fts, sts_list_pon)

    sts_groups = []
    for asgn in assignments:
        sts      = asgn['sts']
        dis_lbl  = sts['dis_dome']
        sts_drops = drops_by_dis.get(dis_lbl, [])
        ports = []
        for p in range(1, 17):
            if (p-1) < len(sts_drops):
                dr = extract_dr(sts_drops[p-1].get('endfeat',''))
            else:
                dr = 'SPARE'
            ports.append({'port': p, 'dr': dr})
        sts_groups.append({
            'label': sts['label'], 'leg': sts['leg'],
            'dis_dome': dis_lbl, 'cable': asgn['cable'],
            'strt_pole': asgn['strt_pole'], 'fiber': asgn['fiber'],
            'ports': ports
        })

    pons_data[str(pon)] = {
        'pon': pon, 'zone': pon_to_zone(pon),
        'olt_port': fts['olt_port'], 'card': fts['card'], 'port': fts['port'],
        'fts_label': fts['label'], 'agg_dome': fts['agg_dome'],
        'lat': fts.get('lat',''), 'lon': fts.get('lon',''),
        'units': int(pon_ont_counts.get(str(pon), 0)),
        'fiber': prim_fiber_map[pon], 'primary_cable': prim_cable_map[pon],
        'hops': hops,
        'sts_groups': sts_groups,
    }

embed = json.dumps({'port_allocs': port_allocs, 'pons': pons_data}, ensure_ascii=False)

# ── Count stats ───────────────────────────────────────────────────────────────
total_onts  = sum(int(pon_ont_counts.get(str(p),0)) for p in all_pons)
total_sts   = sum(len(v) for v in sts_by_pon.values())
total_spare = sum(
    max(0, 16 - len(drops_by_dis.get(g['dis_dome'],[])))
    for pon in all_pons
    for g in pons_data[str(pon)]['sts_groups']
)

# ── HTML ──────────────────────────────────────────────────────────────────────
HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MOA Phase 2 — Splice Plan</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Arial,sans-serif;background:#0f1117;color:#e2e8f0;height:100vh;display:flex;flex-direction:column;overflow:hidden}

/* ── Top bar ── */
.topbar{background:#1a1f2e;border-bottom:2px solid #FF6699;padding:12px 20px;display:flex;align-items:center;gap:20px;flex-shrink:0}
.topbar h1{font-size:16px;font-weight:700;color:#fff;letter-spacing:.5px}
.topbar .sub{font-size:11px;color:#94a3b8}
.topbar .stats{display:flex;gap:16px;margin-left:auto}
.stat{text-align:center}
.stat .val{font-size:20px;font-weight:700;color:#FF6699}
.stat .lbl{font-size:10px;color:#64748b;text-transform:uppercase;letter-spacing:.5px}

/* ── Tabs ── */
.tabs{background:#141824;border-bottom:1px solid #1e293b;display:flex;gap:0;flex-shrink:0}
.tab{padding:10px 20px;font-size:12px;font-weight:600;color:#64748b;cursor:pointer;border-bottom:2px solid transparent;transition:all .2s;letter-spacing:.3px}
.tab:hover{color:#e2e8f0;background:#1a1f2e}
.tab.active{color:#FF6699;border-bottom-color:#FF6699;background:#1a1f2e}

/* ── Main layout ── */
.main{display:flex;flex:1;overflow:hidden}

/* ── Sidebar ── */
.sidebar{width:220px;background:#141824;border-right:1px solid #1e293b;overflow-y:auto;flex-shrink:0}
.sidebar-hdr{padding:10px 14px;font-size:10px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:.8px;border-bottom:1px solid #1e293b;display:flex;align-items:center;gap:8px}
.sidebar-search{padding:8px 10px;border-bottom:1px solid #1e293b}
.sidebar-search input{width:100%;background:#0f1117;border:1px solid #1e293b;border-radius:4px;padding:5px 8px;font-size:11px;color:#e2e8f0;outline:none}
.sidebar-search input:focus{border-color:#FF6699}
.zone-group{}
.zone-hdr{padding:6px 14px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;display:flex;align-items:center;gap:6px}
.pon-item{padding:5px 14px 5px 22px;font-size:11px;color:#94a3b8;cursor:pointer;display:flex;justify-content:space-between;align-items:center;border-left:2px solid transparent}
.pon-item:hover{background:#1a1f2e;color:#e2e8f0}
.pon-item.active{background:#1e293b;color:#FF6699;border-left-color:#FF6699}
.pon-item .badge{font-size:9px;background:#1e293b;padding:1px 5px;border-radius:10px;color:#64748b}
.pon-item.active .badge{background:#2d1f2e;color:#FF6699}

/* ── Content area ── */
.content{flex:1;overflow:auto;padding:0}
.panel{display:none;height:100%;overflow:auto}
.panel.active{display:block}

/* ── Overview panel ── */
.overview{padding:24px}
.cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:16px;margin-bottom:28px}
.card{background:#141824;border:1px solid #1e293b;border-radius:8px;padding:18px;border-top:3px solid}
.card.z17{border-top-color:#3b82f6}.card.z18{border-top-color:#10b981}.card.z19{border-top-color:#f59e0b}.card.z20{border-top-color:#8b5cf6}
.card h3{font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px}
.card .big{font-size:28px;font-weight:700;color:#fff}
.card .detail{font-size:11px;color:#64748b;margin-top:4px}
.section-title{font-size:12px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px;padding-bottom:6px;border-bottom:1px solid #1e293b}
.zone-cards{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:24px}
.zcard{background:#141824;border:1px solid #1e293b;border-radius:6px;padding:14px}
.zcard h4{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px}
.zcard.z17 h4{color:#3b82f6}.zcard.z18 h4{color:#10b981}.zcard.z19 h4{color:#f59e0b}.zcard.z20 h4{color:#8b5cf6}
.zcard .row2{display:flex;justify-content:space-between;margin-top:4px}
.zcard .kv{font-size:11px}.zcard .kv .k{color:#475569}.zcard .kv .v{color:#e2e8f0;font-weight:600}

/* ── Port Allocations panel ── */
.pa-panel{padding:20px}
.pa-toolbar{display:flex;gap:10px;margin-bottom:14px;align-items:center}
.pa-toolbar input{background:#141824;border:1px solid #1e293b;border-radius:4px;padding:6px 10px;font-size:11px;color:#e2e8f0;outline:none;width:220px}
.pa-toolbar input:focus{border-color:#FF6699}
.pa-toolbar select{background:#141824;border:1px solid #1e293b;border-radius:4px;padding:6px 10px;font-size:11px;color:#e2e8f0;outline:none}
table{width:100%;border-collapse:collapse;font-size:11px}
thead th{background:#141824;color:#64748b;font-weight:700;font-size:10px;text-transform:uppercase;letter-spacing:.5px;padding:8px 10px;border-bottom:1px solid #1e293b;text-align:left;position:sticky;top:0;z-index:1}
tbody tr{border-bottom:1px solid #0f1117;transition:background .1s;cursor:pointer}
tbody tr:hover{background:#1a1f2e}
tbody td{padding:6px 10px;color:#e2e8f0}
.zone-pill{display:inline-block;padding:1px 8px;border-radius:10px;font-size:10px;font-weight:600}
.z17{background:#1e3a5f;color:#3b82f6}.z18{background:#1a3a2e;color:#10b981}.z19{background:#3a2e0f;color:#f59e0b}.z20{background:#2a1f3a;color:#8b5cf6}
.units-bar{display:flex;align-items:center;gap:6px}
.units-bar .bar{height:6px;border-radius:3px;background:#FF6699;opacity:.8}
.units-bar .num{font-size:10px;color:#94a3b8}

/* ── Feeder panel ── */
.feeder-panel{padding:20px}
.feeder-toolbar{display:flex;gap:10px;margin-bottom:14px;align-items:center}
.feeder-toolbar input{background:#141824;border:1px solid #1e293b;border-radius:4px;padding:6px 10px;font-size:11px;color:#e2e8f0;outline:none;width:220px}
.feeder-toolbar input:focus{border-color:#FF6699}
.feeder-rows{}
.feeder-row{display:flex;align-items:center;gap:0;padding:5px 0;border-bottom:1px solid #0f1117;font-size:11px;min-height:36px}
.feeder-row:hover{background:#141824}
.fr-pop{width:90px;flex-shrink:0;font-weight:700;color:#FF6699;font-size:11px;padding:0 8px}
.fr-fiber{width:40px;flex-shrink:0;color:#94a3b8;padding:0 4px;font-size:10px}
.hop{display:flex;align-items:center;padding:3px 6px;border-radius:4px;margin:0 2px;font-size:10px;gap:4px;flex-shrink:0}
.hop.odd{background:#0c2340;color:#93c5fd}
.hop.even{background:#0a2618;color:#6ee7b7}
.hop .arrow{color:#475569;font-size:12px}
.hop .cable{max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#94a3b8}
.hop .joint{max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.fr-fts{flex:1;text-align:right;padding:0 10px;color:#f9a8d4;font-size:10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.feeder-hdr-row{display:flex;align-items:center;gap:0;padding:6px 0;border-bottom:1px solid #1e293b;font-size:10px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:.5px}

/* ── PON Detail panel ── */
.pon-panel{padding:0}
.pon-header{background:#141824;border-bottom:2px solid #FF6699;padding:14px 20px;display:flex;gap:24px;align-items:center;flex-wrap:wrap}
.pon-header .big{font-size:22px;font-weight:700;color:#FF6699}
.pon-header .kv2{font-size:11px;line-height:1.8}.pon-header .kv2 .k{color:#475569}.pon-header .kv2 .v{color:#e2e8f0;font-weight:600;margin-left:4px}
.feeder-vis{background:#0f1117;padding:14px 20px;border-bottom:1px solid #1e293b;overflow-x:auto}
.feeder-vis .fv-title{font-size:10px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:.8px;margin-bottom:10px}
.fv-flow{display:flex;align-items:center;gap:0;white-space:nowrap}
.fv-node{background:#141824;border:1px solid #1e293b;border-radius:6px;padding:6px 10px;font-size:10px;text-align:center;min-width:80px}
.fv-node.olt{border-color:#FF6699;color:#FF6699;font-weight:700}
.fv-node.agg{border-color:#f59e0b;color:#f59e0b}
.fv-node.fts{border-color:#10b981;color:#10b981}
.fv-edge{display:flex;flex-direction:column;align-items:center;padding:0 6px}
.fv-edge .cable-lbl{font-size:9px;color:#3b82f6;max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.fv-edge .arrow-line{color:#475569;font-size:18px;line-height:1}
.fv-edge .fiber-lbl{font-size:9px;color:#94a3b8}

.dist-section{padding:16px 20px}
.dist-title{font-size:10px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px}
.sts-block{margin-bottom:16px;border:1px solid #1e293b;border-radius:6px;overflow:hidden}
.sts-hdr{background:#141824;padding:8px 12px;display:flex;gap:16px;align-items:center;border-bottom:1px solid #1e293b}
.sts-hdr .sts-lbl{font-size:11px;font-weight:700;color:#e2e8f0}
.sts-hdr .sts-meta{font-size:10px;color:#64748b}
.sts-hdr .sts-fill{margin-left:auto;font-size:10px}
.sts-hdr .sts-fill span{color:#10b981;font-weight:700}
.ports-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:0}
.port-cell{padding:6px 12px;border-right:1px solid #0f1117;border-bottom:1px solid #0f1117;display:flex;flex-direction:column;gap:1px}
.port-cell.spare{opacity:.4}
.port-cell .pnum{font-size:9px;color:#475569;font-weight:700}
.port-cell .dr{font-size:11px;color:#e2e8f0;font-weight:600;font-family:'Courier New',monospace}
.port-cell.spare .dr{color:#475569}

/* ── Search overlay ── */
.search-bar{position:fixed;top:60px;left:50%;transform:translateX(-50%);z-index:100;background:#141824;border:1px solid #FF6699;border-radius:8px;padding:12px;width:500px;box-shadow:0 8px 32px rgba(0,0,0,.5);display:none}
.search-bar.visible{display:block}
.search-bar input{width:100%;background:#0f1117;border:1px solid #1e293b;border-radius:4px;padding:8px 12px;font-size:13px;color:#e2e8f0;outline:none}
.search-results{margin-top:8px;max-height:300px;overflow-y:auto}
.sr-item{padding:8px 10px;cursor:pointer;border-radius:4px;font-size:12px;border-bottom:1px solid #1e293b}
.sr-item:hover{background:#1e293b}
.sr-item .sr-dr{font-family:monospace;color:#FF6699;font-weight:700}
.sr-item .sr-meta{color:#94a3b8;font-size:10px;margin-top:2px}

/* scrollbar */
::-webkit-scrollbar{width:6px;height:6px}
::-webkit-scrollbar-track{background:#0f1117}
::-webkit-scrollbar-thumb{background:#1e293b;border-radius:3px}
::-webkit-scrollbar-thumb:hover{background:#334155}
</style>
</head>
<body>

<div class="topbar">
  <div>
    <div class="topbar h1">MOA Phase 2 — Splice Plan</div>
    <div class="topbar sub">Potch · Mohadin · JB Marks LM · OLT.01 · C15P11–C19P10</div>
  </div>
  <div class="stats">
    <div class="stat"><div class="val">__TOTAL_PONS__</div><div class="lbl">PONs</div></div>
    <div class="stat"><div class="val">4</div><div class="lbl">Zones</div></div>
    <div class="stat"><div class="val">__TOTAL_STS__</div><div class="lbl">STS Domes</div></div>
    <div class="stat"><div class="val">__TOTAL_ONTS__</div><div class="lbl">Connected ONTs</div></div>
    <div class="stat"><div class="val">__TOTAL_SPARE__</div><div class="lbl">Spare Ports</div></div>
  </div>
</div>

<div class="tabs">
  <div class="tab active" onclick="showTab('overview')">Overview</div>
  <div class="tab" onclick="showTab('portalloc')">Port Allocations</div>
  <div class="tab" onclick="showTab('feeder')">Feeder Route</div>
  <div class="tab" onclick="showTab('pondetail')">PON Detail</div>
  <div class="tab" onclick="toggleSearch()" style="margin-left:auto;color:#3b82f6">🔍 Search DR</div>
</div>

<div class="main">
  <!-- Sidebar -->
  <div class="sidebar">
    <div class="sidebar-hdr">PON List</div>
    <div class="sidebar-search"><input type="text" placeholder="Filter PONs…" oninput="filterSidebar(this.value)" id="sb-filter"></div>
    <div id="sidebar-list"></div>
  </div>

  <!-- Content -->
  <div class="content">

    <!-- Overview -->
    <div class="panel active" id="panel-overview">
      <div class="overview">
        <div class="section-title">Zone Summary</div>
        <div class="zone-cards" id="zone-cards"></div>
        <div class="section-title">All PONs — Quick View</div>
        <div id="overview-table"></div>
      </div>
    </div>

    <!-- Port Allocations -->
    <div class="panel" id="panel-portalloc">
      <div class="pa-panel">
        <div class="pa-toolbar">
          <input type="text" placeholder="Filter by cable, PON, zone…" oninput="filterPA(this.value)" id="pa-filter">
          <select onchange="filterPA(document.getElementById('pa-filter').value)" id="pa-zone">
            <option value="">All Zones</option>
            <option value="17">Zone 17</option>
            <option value="18">Zone 18</option>
            <option value="19">Zone 19</option>
            <option value="20">Zone 20</option>
          </select>
          <span style="font-size:11px;color:#64748b" id="pa-count"></span>
        </div>
        <div style="overflow:auto;max-height:calc(100vh - 200px)">
          <table id="pa-table">
            <thead><tr>
              <th>OLT Port</th><th>Card</th><th>Port</th><th>Fiber</th>
              <th>Primary Cable</th><th>PON</th><th>Zone</th><th>ONTs</th><th>AC</th>
            </tr></thead>
            <tbody id="pa-body"></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Feeder -->
    <div class="panel" id="panel-feeder">
      <div class="feeder-panel">
        <div class="feeder-toolbar">
          <input type="text" placeholder="Filter by cable or dome…" oninput="filterFeeder(this.value)" id="feeder-filter">
          <span style="font-size:11px;color:#64748b" id="feeder-count"></span>
        </div>
        <div class="feeder-hdr-row" style="padding-left:8px">
          <div style="width:90px;flex-shrink:0">OLT Port</div>
          <div style="width:40px;flex-shrink:0">Fibre</div>
          <div style="flex:1">Hop 1 → Hop 2 → … → FTS Splitter</div>
        </div>
        <div id="feeder-rows"></div>
      </div>
    </div>

    <!-- PON Detail -->
    <div class="panel" id="panel-pondetail">
      <div id="pon-detail-content" style="height:100%;overflow:auto">
        <div style="padding:40px;text-align:center;color:#475569">
          <div style="font-size:32px;margin-bottom:12px">←</div>
          <div style="font-size:14px">Select a PON from the sidebar to view its splice detail</div>
        </div>
      </div>
    </div>

  </div><!-- end content -->
</div><!-- end main -->

<!-- Search overlay -->
<div class="search-bar" id="search-bar">
  <input type="text" placeholder="Search DR number… (e.g. DR1853300)" oninput="searchDR(this.value)" id="search-input" autofocus>
  <div class="search-results" id="search-results"></div>
</div>

<script>
const RAW = __EMBED_DATA__;

const PORT_ALLOCS = RAW.port_allocs;
const PONS = RAW.pons;

// ── Zone colours ──────────────────────────────────────────────────────────────
const ZONE_COLOR = {17:'#3b82f6', 18:'#10b981', 19:'#f59e0b', 20:'#8b5cf6'};
const ZONE_CLS   = {17:'z17', 18:'z18', 19:'z19', 20:'z20'};

// ── Tab switching ─────────────────────────────────────────────────────────────
function showTab(name) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  event.target.classList.add('active');
  document.getElementById('panel-' + name).classList.add('active');
}

// ── Sidebar ───────────────────────────────────────────────────────────────────
function buildSidebar() {
  const zones = {};
  PORT_ALLOCS.forEach(p => {
    zones[p.zone] = zones[p.zone] || [];
    zones[p.zone].push(p);
  });
  const el = document.getElementById('sidebar-list');
  el.innerHTML = '';
  [17,18,19,20].forEach(z => {
    if (!zones[z]) return;
    const g = document.createElement('div');
    g.className = 'zone-group';
    g.innerHTML = `<div class="zone-hdr" style="color:${ZONE_COLOR[z]}">
      <span>●</span> Zone ${z} <span style="color:#475569;font-weight:400">(${zones[z].length} PONs)</span>
    </div>`;
    zones[z].forEach(p => {
      const item = document.createElement('div');
      item.className = 'pon-item';
      item.id = `sb-${p.pon}`;
      item.innerHTML = `<span>${p.olt_port}</span><span class="badge">${p.units}</span>`;
      item.onclick = () => selectPON(p.pon);
      g.appendChild(item);
    });
    el.appendChild(g);
  });
}

function filterSidebar(q) {
  q = q.toLowerCase();
  document.querySelectorAll('.pon-item').forEach(el => {
    el.style.display = el.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}

// ── Overview ──────────────────────────────────────────────────────────────────
function buildOverview() {
  const zoneStats = {};
  PORT_ALLOCS.forEach(p => {
    if (!zoneStats[p.zone]) zoneStats[p.zone] = {pons:0, units:0, sts:0};
    zoneStats[p.zone].pons++;
    zoneStats[p.zone].units += p.units;
    const pd = PONS[p.pon];
    zoneStats[p.zone].sts += (pd ? pd.sts_groups.length : 0);
  });
  const zc = document.getElementById('zone-cards');
  zc.innerHTML = [17,18,19,20].map(z => {
    const s = zoneStats[z] || {pons:0,units:0,sts:0};
    return `<div class="zcard z${z}">
      <h4>Zone ${z}</h4>
      <div class="row2">
        <div class="kv"><div class="k">PONs</div><div class="v">${s.pons}</div></div>
        <div class="kv"><div class="k">ONTs</div><div class="v">${s.units}</div></div>
        <div class="kv"><div class="k">STS</div><div class="v">${s.sts}</div></div>
      </div>
    </div>`;
  }).join('');

  const maxUnits = Math.max(...PORT_ALLOCS.map(p => p.units));
  const ot = document.getElementById('overview-table');
  ot.innerHTML = `<table>
    <thead><tr><th>OLT Port</th><th>PON</th><th>Zone</th><th>ONTs</th><th style="width:200px">Fill</th><th>STS</th><th>Primary Cable</th></tr></thead>
    <tbody>${PORT_ALLOCS.map(p => {
      const pd = PONS[p.pon];
      const sts = pd ? pd.sts_groups.length : 0;
      const pct = Math.round(p.units / 128 * 100);
      const barW = Math.round(p.units / maxUnits * 150);
      return `<tr onclick="selectPON(${p.pon})">
        <td style="color:#FF6699;font-weight:700">${p.olt_port}</td>
        <td>${p.pon}</td>
        <td><span class="zone-pill ${ZONE_CLS[p.zone]}">Zone ${p.zone}</span></td>
        <td>${p.units}</td>
        <td><div class="units-bar"><div class="bar" style="width:${barW}px"></div><div class="num">${pct}%</div></div></td>
        <td>${sts}</td>
        <td style="font-size:10px;color:#64748b;max-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${p.cable}</td>
      </tr>`;
    }).join('')}</tbody>
  </table>`;
}

// ── Port Allocations ──────────────────────────────────────────────────────────
function buildPA() {
  renderPA();
}
function renderPA(q, zone) {
  q = (q||'').toLowerCase();
  zone = zone || document.getElementById('pa-zone').value;
  const rows = PORT_ALLOCS.filter(p => {
    if (zone && String(p.zone) !== zone) return false;
    if (q) return [p.olt_port,p.cable,String(p.pon),String(p.zone)].join(' ').toLowerCase().includes(q);
    return true;
  });
  document.getElementById('pa-count').textContent = `${rows.length} PONs`;
  const maxU = Math.max(...PORT_ALLOCS.map(p=>p.units));
  document.getElementById('pa-body').innerHTML = rows.map(p => {
    const barW = Math.round(p.units/maxU*80);
    return `<tr onclick="selectPON(${p.pon})">
      <td style="color:#FF6699;font-weight:700">${p.olt_port}</td>
      <td>${p.card}</td><td>${p.port}</td>
      <td style="font-family:monospace;color:#93c5fd">${p.fiber}</td>
      <td style="font-size:10px;color:#64748b;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${p.cable}</td>
      <td style="font-weight:600">${p.pon}</td>
      <td><span class="zone-pill ${ZONE_CLS[p.zone]}">Z${p.zone}</span></td>
      <td><div class="units-bar"><div class="bar" style="width:${barW}px"></div><div class="num">${p.units}</div></div></td>
      <td style="color:#475569">—</td>
    </tr>`;
  }).join('');
}
function filterPA(q) { renderPA(q, document.getElementById('pa-zone').value); }

// ── Feeder ────────────────────────────────────────────────────────────────────
function buildFeeder() {
  renderFeeder();
}
function renderFeeder(q) {
  q = (q||'').toLowerCase();
  const rows = Object.values(PONS).filter(p => {
    if (!q) return true;
    const txt = [p.olt_port, p.primary_cable, p.agg_dome, p.fts_label,
      ...p.hops.map(h=>h.cable+' '+h.joint_end)].join(' ').toLowerCase();
    return txt.includes(q);
  });
  document.getElementById('feeder-count').textContent = `${rows.length} PONs`;
  document.getElementById('feeder-rows').innerHTML = rows.map(p => {
    const hopsHtml = p.hops.map((h, i) => `
      <div class="hop ${i%2===0?'odd':'even'}">
        <span class="fiber-lbl" style="color:#93c5fd">${h.fiber_in}</span>
        <span class="arrow">→</span>
        <span class="cable">${h.cable}</span>
        <span class="arrow">→</span>
        <span class="joint">${h.joint_end}</span>
        <span class="arrow">→</span>
        <span class="fiber-lbl">${h.fiber_out}</span>
      </div>`).join('');
    return `<div class="feeder-row" onclick="selectPON(${p.pon})">
      <div class="fr-pop" style="color:${ZONE_COLOR[p.zone]}">${p.olt_port}</div>
      <div class="fr-fiber" style="color:#93c5fd;font-family:monospace">${p.fiber}</div>
      <div style="display:flex;align-items:center;flex:1;flex-wrap:wrap;gap:2px">${hopsHtml}</div>
      <div class="fr-fts">${p.agg_dome}</div>
    </div>`;
  }).join('');
}
function filterFeeder(q) { renderFeeder(q); }

// ── PON Detail ────────────────────────────────────────────────────────────────
let activePON = null;
function selectPON(pon) {
  activePON = pon;
  // Switch to PON detail tab
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab')[3].classList.add('active');
  document.getElementById('panel-pondetail').classList.add('active');

  // Update sidebar selection
  document.querySelectorAll('.pon-item').forEach(el => el.classList.remove('active'));
  const sbItem = document.getElementById(`sb-${pon}`);
  if (sbItem) { sbItem.classList.add('active'); sbItem.scrollIntoView({block:'nearest'}); }

  renderPONDetail(pon);
}

function renderPONDetail(pon) {
  const p = PONS[String(pon)];
  if (!p) return;
  const zc = ZONE_COLOR[p.zone];

  // Feeder visualisation
  const fv = [
    `<div class="fv-node olt">OLT.01<br><small>${p.olt_port}</small></div>`
  ];
  p.hops.forEach((h, i) => {
    fv.push(`<div class="fv-edge">
      <div class="cable-lbl" title="${h.cable}">${h.cable.substring(0,24)}…</div>
      <div class="arrow-line">→</div>
      <div class="fiber-lbl" style="color:#93c5fd">${h.fiber_in}</div>
    </div>`);
    fv.push(`<div class="fv-node agg">${h.joint_end.substring(0,18)}<br><small style="color:#64748b">AGG Dome</small></div>`);
  });
  if (p.hops.length === 0) {
    fv.push(`<div class="fv-edge"><div class="arrow-line">→</div></div>`);
    fv.push(`<div class="fv-node agg">${p.agg_dome.substring(0,18)}<br><small>AGG Dome</small></div>`);
  }
  fv.push(`<div class="fv-edge"><div class="cable-lbl">1:8 Splitter</div><div class="arrow-line">→</div></div>`);
  fv.push(`<div class="fv-node fts">FTS Splitter<br><small>${p.agg_dome.substring(p.agg_dome.lastIndexOf('.')+1)}</small></div>`);

  // STS blocks
  const stsHtml = p.sts_groups.map((g, gi) => {
    const connected = g.ports.filter(pt => pt.dr !== 'SPARE').length;
    const pct = Math.round(connected/16*100);
    const fillColor = pct >= 90 ? '#10b981' : pct >= 60 ? '#f59e0b' : '#3b82f6';
    const portsHtml = g.ports.map(pt => `
      <div class="port-cell ${pt.dr==='SPARE'?'spare':''}">
        <div class="pnum">Port ${pt.port}</div>
        <div class="dr">${pt.dr}</div>
      </div>`).join('');
    return `<div class="sts-block">
      <div class="sts-hdr">
        <div class="sts-lbl">${g.label}</div>
        <div class="sts-meta">Leg ${g.leg} · ${g.cable.substring(0,30)}</div>
        <div class="sts-meta">Fiber ${g.fiber} · ${g.dis_dome}</div>
        <div class="sts-fill">Fill: <span style="color:${fillColor}">${connected}/16 (${pct}%)</span></div>
      </div>
      <div class="ports-grid">${portsHtml}</div>
    </div>`;
  }).join('');

  const totalConnected = p.sts_groups.reduce((s,g) => s + g.ports.filter(pt=>pt.dr!=='SPARE').length, 0);
  const totalSpare = p.sts_groups.reduce((s,g) => s + g.ports.filter(pt=>pt.dr==='SPARE').length, 0);

  document.getElementById('pon-detail-content').innerHTML = `
    <div class="pon-header">
      <div class="big" style="color:${zc}">PON ${p.pon}</div>
      <div class="kv2">
        <div><span class="k">OLT Port:</span><span class="v">${p.olt_port}</span></div>
        <div><span class="k">Zone:</span><span class="v">${p.zone}</span></div>
        <div><span class="k">AGG Dome:</span><span class="v">${p.agg_dome}</span></div>
      </div>
      <div class="kv2">
        <div><span class="k">FTS Splitter:</span><span class="v">1:8</span></div>
        <div><span class="k">STS Splitters:</span><span class="v">${p.sts_groups.length} × 1:16</span></div>
        <div><span class="k">Primary Cable:</span><span class="v" style="font-size:10px">${p.primary_cable}</span></div>
      </div>
      <div class="kv2" style="margin-left:auto;text-align:right">
        <div><span class="k">Connected ONTs:</span><span class="v" style="color:#10b981">${totalConnected}</span></div>
        <div><span class="k">Spare Ports:</span><span class="v" style="color:#f59e0b">${totalSpare}</span></div>
        <div><span class="k">Max Capacity:</span><span class="v">${p.sts_groups.length * 16}</span></div>
      </div>
    </div>
    <div class="feeder-vis">
      <div class="fv-title">Feeder Route — OLT → FTS Splitter</div>
      <div class="fv-flow">${fv.join('')}</div>
    </div>
    <div class="dist-section">
      <div class="dist-title">Distribution — ${p.sts_groups.length} STS Splitters · ${totalConnected + totalSpare} ports total</div>
      ${stsHtml}
    </div>
  `;
}

// ── DR Search ─────────────────────────────────────────────────────────────────
function toggleSearch() {
  const bar = document.getElementById('search-bar');
  const vis = bar.classList.toggle('visible');
  if (vis) { document.getElementById('search-input').value=''; document.getElementById('search-results').innerHTML=''; document.getElementById('search-input').focus(); }
}
document.addEventListener('keydown', e => { if (e.key==='Escape') document.getElementById('search-bar').classList.remove('visible'); });

function searchDR(q) {
  q = q.trim().toLowerCase();
  const res = document.getElementById('search-results');
  if (q.length < 4) { res.innerHTML='<div style="color:#475569;font-size:11px;padding:6px">Type at least 4 characters…</div>'; return; }
  const hits = [];
  Object.values(PONS).forEach(p => {
    p.sts_groups.forEach(g => {
      g.ports.forEach(pt => {
        if (pt.dr.toLowerCase().includes(q)) {
          hits.push({pon: p.pon, olt_port: p.olt_port, zone: p.zone, sts: g.label, leg: g.leg, dis: g.dis_dome, port: pt.port, dr: pt.dr});
        }
      });
    });
  });
  if (!hits.length) { res.innerHTML='<div style="color:#ef4444;font-size:11px;padding:6px">No results found</div>'; return; }
  res.innerHTML = hits.slice(0,20).map(h => `
    <div class="sr-item" onclick="goToDR(${h.pon})">
      <div class="sr-dr">${h.dr}</div>
      <div class="sr-meta">PON ${h.pon} · ${h.olt_port} · Zone ${h.zone} · ${h.sts} Port ${h.port}</div>
      <div class="sr-meta" style="color:#334155">${h.dis}</div>
    </div>`).join('');
}
function goToDR(pon) {
  document.getElementById('search-bar').classList.remove('visible');
  selectPON(pon);
}

// ── Init ──────────────────────────────────────────────────────────────────────
buildSidebar();
buildOverview();
buildPA();
buildFeeder();
</script>
</body>
</html>
"""

HTML = HTML.replace('__EMBED_DATA__', embed)
HTML = HTML.replace('__TOTAL_PONS__', str(len(all_pons)))
HTML = HTML.replace('__TOTAL_STS__', str(total_sts))
HTML = HTML.replace('__TOTAL_ONTS__', str(total_onts))
HTML = HTML.replace('__TOTAL_SPARE__', str(total_spare))

Path(OUTPUT).write_text(HTML, encoding='utf-8')
sz = Path(OUTPUT).stat().st_size / 1024
print(f"Saved: {OUTPUT}")
print(f"Size: {sz:.0f} KB")
print(f"PONs: {len(all_pons)} | STS: {total_sts} | ONTs: {total_onts} | Spare: {total_spare}")
