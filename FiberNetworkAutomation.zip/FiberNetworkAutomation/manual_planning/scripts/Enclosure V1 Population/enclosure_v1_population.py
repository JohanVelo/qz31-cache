import sys, os
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')

# ============================================================
# ENCLOSURE V1 — FULL ATTRIBUTE POPULATION
# Project: Potch - Mohadin PH2
#
# Label format : MOA.DIS.DM.P.[NearestPoleAlphaNum]
# Example      : MOA.DIS.DM.P.F400
#
# Subtype logic:
#   - If geometry matches a feature in 'Enclosures Connectorised v1'
#     → subtyp = Connectorised
#   - Otherwise
#     → subtyp = Splice (DIS distribution-level splice)
#
# Fields populated:
#   label, type, subtyp, spec, dim1, cblcpty, conntr
#   cmpownr, subplace, mainplce, mun, stackref, crtdby
#   lat, lon, pon_no, zone_no
#
# To run from QGIS Python Console:
#   exec(open(r'C:\Users\jjsch\OneDrive - blitzfibre.com\Documents\CLAUDE\Enclosure V1 Population\enclosure_v1_population.py').read())
# ============================================================

# ── CONFIGURABLE PARAMETERS ────────────────────────────────
ENC_LAYER    = 'Enclosure v1'
CON_LAYER    = 'Enclosures Connectorised v1'   # used to determine subtype
POLES_LAYER  = 'poles v1'
PON_LAYER    = 'PON v1'
ZONE_LAYER   = 'Zones v1'

SR           = 'MOA'
MATCH_TOL    = 0.5   # metres — distance to consider same location as Connectorised v1

STATIC = {
    'cmpownr':  'VelocityFibre',
    'subplace': '676007',
    'mainplce': '676007',
    'mun':      'JB Marks Local Municipality',
    'stackref': 'MOA',
    'crtdby':   'Johan Scholtz',
}

# Attributes per subtype — change dim1/spec per project if needed
SUBTYPE_ATTRS = {
    'Connectorised': {
        'type':    'Enclosure',
        'subtyp':  'Connectorised',
        'spec':    'ODCFD0',
        'dim1':    'L220*W120*H73mm',
        'cblcpty': '24F',
        'conntr':  '6*LC/Duplex',
    },
    'Splice': {
        'type':    'Enclosure',
        'subtyp':  'Splice',
        'spec':    'UMJ',
        'dim1':    'L250*W231*D164mm',
        'cblcpty': '72F',
        'conntr':  None,
    },
}
# ── END PARAMETERS ─────────────────────────────────────────


# --- GET LAYERS ---
enc_layer = poles_layer = pon_layer = zone_layer = con_layer = None
for lyr in QgsProject.instance().mapLayers().values():
    n = lyr.name()
    if n == ENC_LAYER:   enc_layer   = lyr
    if n == CON_LAYER:   con_layer   = lyr
    if n == POLES_LAYER: poles_layer = lyr
    if n == PON_LAYER:   pon_layer   = lyr
    if n == ZONE_LAYER:  zone_layer  = lyr

missing = [n for n, l in [
    (ENC_LAYER, enc_layer), (POLES_LAYER, poles_layer),
    (PON_LAYER, pon_layer), (ZONE_LAYER, zone_layer)
] if not l]

if missing:
    print(f"ERROR: Missing layers: {missing}")
else:
    print(f"Enclosure v1:  {enc_layer.featureCount()} features")
    print(f"poles v1:      {poles_layer.featureCount()} features")
    if con_layer:
        print(f"Connectorised v1: {con_layer.featureCount()} features (subtype reference)")
    else:
        print(f"WARNING: '{CON_LAYER}' not found — all features will be Connectorised")

    from qgis.core import QgsSpatialIndex, QgsPointXY, QgsDistanceArea

    iface.mapCanvas().setRenderFlag(False)
    try:
        # --- BUILD SPATIAL INDEXES ---
        print("Building spatial indexes...")

        pole_index = QgsSpatialIndex(poles_layer.getFeatures())
        pole_feats = {f.id(): f for f in poles_layer.getFeatures()}

        pon_index = QgsSpatialIndex(pon_layer.getFeatures())
        pon_feats = {f.id(): f for f in pon_layer.getFeatures()}

        zone_index = QgsSpatialIndex(zone_layer.getFeatures())
        zone_feats = {f.id(): f for f in zone_layer.getFeatures()}

        # Build exact WKT set + spatial index from Connectorised v1 for subtype matching
        con_wkt_set = set()
        con_index = None
        con_feats_dict = {}
        if con_layer:
            con_index = QgsSpatialIndex(con_layer.getFeatures())
            con_feats_dict = {f.id(): f for f in con_layer.getFeatures()}
            for f in con_layer.getFeatures():
                g = f.geometry()
                if g:
                    con_wkt_set.add(g.asWkt())

        # Distance calculator (metres)
        d = QgsDistanceArea()
        d.setSourceCrs(enc_layer.crs(), QgsProject.instance().transformContext())
        d.setEllipsoid(QgsProject.instance().ellipsoid())

        print("Spatial indexes ready.")

        # --- HELPERS ---
        def get_pole_alphanum(point):
            """Return alpha-numeric part of nearest pole label e.g. 'F400' from 'MOA.P.F400'"""
            candidates = pole_index.nearestNeighbor(point, 1)
            if not candidates:
                return None
            lbl = str(pole_feats[candidates[0]]['Label'])
            return lbl.split('.')[-1] if '.' in lbl else lbl

        def is_connectorised(geom):
            """True if this geometry matches a feature in Enclosures Connectorised v1"""
            if not con_layer:
                return True
            # Fast exact WKT match first
            if geom.asWkt() in con_wkt_set:
                return True
            # Fallback: nearest neighbour within tolerance
            pt = geom.asPoint()
            pxy = QgsPointXY(pt.x(), pt.y())
            candidates = con_index.nearestNeighbor(pxy, 1)
            if candidates:
                nearest_pt = con_feats_dict[candidates[0]].geometry().asPoint()
                dist = d.measureLine(pxy, QgsPointXY(nearest_pt.x(), nearest_pt.y()))
                if dist <= MATCH_TOL:
                    return True
            return False

        def fidx(name):
            return enc_layer.fields().indexOf(name)

        # --- PROCESS ---
        dp = enc_layer.dataProvider()
        changes = {}

        processed = 0
        con_count = 0
        spl_count = 0
        no_pole = 0
        sample = []

        for feat in enc_layer.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue

            pt = geom.asPoint()
            pxy = QgsPointXY(pt.x(), pt.y())

            # 1. Label from nearest pole
            pole_alphanum = get_pole_alphanum(pxy)
            if not pole_alphanum:
                no_pole += 1
                continue
            label = f'{SR}.DIS.DM.P.{pole_alphanum}'

            # 2. Determine subtype
            subtype = 'Connectorised' if is_connectorised(geom) else 'Splice'
            attrs = SUBTYPE_ATTRS[subtype]
            if subtype == 'Connectorised':
                con_count += 1
            else:
                spl_count += 1

            # 3. Spatial join — pon_no
            pon_no = None
            for fid in pon_index.intersects(geom.boundingBox()):
                if pon_feats[fid].geometry().contains(geom):
                    pon_no = pon_feats[fid]['pon_no']
                    break

            # 4. Spatial join — zone_no
            zone_no = None
            for fid in zone_index.intersects(geom.boundingBox()):
                if zone_feats[fid].geometry().intersects(geom):
                    zone_no = zone_feats[fid]['zone_no']
                    break

            # 5. Build row for bulk write
            row = {}

            def set_f(name, val):
                idx = fidx(name)
                if idx != -1 and val is not None:
                    row[idx] = val

            set_f('label',   label)
            set_f('lat',     round(pt.y(), 6))
            set_f('lon',     round(pt.x(), 7))
            if pon_no  is not None: set_f('pon_no',  pon_no)
            if zone_no is not None: set_f('zone_no', zone_no)

            for field, val in STATIC.items():
                set_f(field, val)
            for field, val in attrs.items():
                set_f(field, val)

            changes[feat.id()] = row
            processed += 1

            if len(sample) < 5:
                sample.append(f"  {label} | sub={subtype} | pon={pon_no} | zone={zone_no}")

        # --- BULK WRITE ---
        dp.changeAttributeValues(changes)
        enc_layer.reload()
    finally:
        iface.mapCanvas().setRenderFlag(True)
        iface.mapCanvas().refresh()

    # --- SUMMARY ---
    print("=" * 65)
    print("  ENCLOSURE V1 POPULATION COMPLETE")
    print(f"  Processed:      {processed}")
    print(f"  Connectorised:  {con_count}")
    print(f"  Splice (DIS):   {spl_count}")
    print(f"  No pole found:  {no_pole}")
    print("=" * 65)
    print("\nSample — first 5:")
    for s in sample:
        print(s)

    null_labels = sum(1 for f in enc_layer.getFeatures() if not f['label'])
    print(f"\nNULL labels remaining: {null_labels}")
    if null_labels > 0:
        print("  TIP: Filter label IS NULL in attribute table to find them.")
