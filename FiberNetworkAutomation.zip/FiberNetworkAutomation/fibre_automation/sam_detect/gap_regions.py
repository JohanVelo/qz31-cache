"""
Gap-region detection for Hybrid Detect Buildings (Phase 1).

Given the Overture footprints already fetched for an AOI, work out WHERE those
footprints are thin or missing, and return clean polygon "gap regions" — the
only places the AI segmentation should run. Everything Overture already covers
is left alone (fast), the AI is spent only on the holes (smart).

This module is deliberately PURE: shapely + stdlib only. No QGIS, no network,
no geopandas — so it is unit/property testable in the venv and can run inside
the subprocess worker without touching the Qt main thread. It is also
DETERMINISTIC: the same inputs always give the same regions (required for the
Hypothesis property gate and for non-destructive re-runs).

Method (cell-based, matching the proven step_01_gob_density approach):
  * Project the AOI + building points into a local metric frame (cos-lat about
    the AOI centroid) so distances/areas are in real metres without a CRS lib.
  * Bin building representative-points into a `grid_m` grid; take the median of
    the OCCUPIED cell counts as the "normal" density for this AOI.
  * A cell is a GAP when its count < gap_thresh * sensitivity * median
    (this includes empty cells). `sensitivity` is the single tuning knob:
    higher = flag more area, lower = only true holes.
  * Union the gap cells, clip to the AOI, dilate slightly to merge neighbours
    into workable tile regions, drop slivers below `min_gap_area_m2`, and
    project back to EPSG:4326.

The returned `GapResult.regions` are EPSG:4326 shapely Polygons ready to feed
the tiler; `GapResult.stats` drives the run-report card.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from statistics import median

from shapely.geometry import (
    box,
    mapping,
    shape,
)
from shapely.ops import transform, unary_union

# ── Tunable defaults ─────────────────────────────────────────────────────────
GRID_M = 80.0            # density cell size (m) — matches step_01_gob_density
GAP_THRESH = 0.15        # NEAR-EMPTY: a cell is a gap below 15% of median density
#                          — Overture found ~nothing there. (A below-MEDIAN cell
#                          still HAS buildings, just fewer — not a miss; calibrated
#                          on Mohadin where 0.70 over-flagged roads/large stands.)
MIN_GAP_AREA_M2 = 15000.0  # require ~2+ empty cells: a lone empty cell inside the
#                            fabric is usually a yard / taxi-rank / open space, not
#                            a missed block. Filters single-cell noise.
GAP_DILATE_M = 8.0       # grow gaps to merge neighbours into tileable regions
MIN_BUILT_NEIGHBORS = 4  # an under-built cell is a real gap only if >= this many
#                          of its 8 neighbours are built-up (=> an enclosed hole,
#                          not a road / open field / sparse settlement edge)
COVERAGE_FALLBACK = 0.10  # if < 10% of AOI cells are built-up, skip the enclosure
#                           filter and flag every under-built cell — a blank / new
#                           area where the AI should just cover everything.
SENSITIVITY = 1.0        # 1 = default; >1 flags more area; <1 only true holes
_SENS_MIN, _SENS_MAX = 0.25, 4.0

M_PER_DEG_LAT = 111320.0


@dataclass
class GapResult:
    """Output of :func:`gap_regions`."""

    regions: list = field(default_factory=list)   # EPSG:4326 shapely Polygons
    stats: dict = field(default_factory=dict)

    @property
    def gap_fraction(self) -> float:
        return float(self.stats.get("gap_fraction", 0.0))


def _clean(geom):
    """Return a valid, non-empty geom or None (buffer(0) repair)."""
    if geom is None or geom.is_empty:
        return None
    if not geom.is_valid:
        geom = geom.buffer(0)
    if geom.is_empty:
        return None
    return geom


def _as_multipolygon(aoi):
    """Normalise the AOI input (shapely geom, GeoJSON-ish dict) to a clean
    (Multi)Polygon, or None."""
    if aoi is None:
        return None
    if isinstance(aoi, dict):
        geom = shape(aoi.get("geometry", aoi)) if "geometry" in aoi else shape(aoi)
    else:
        geom = aoi
    geom = _clean(geom)
    if geom is None or geom.geom_type not in ("Polygon", "MultiPolygon"):
        return None
    return geom


def _rep_point(g):
    """Representative point of a building geom (works for polys and points)."""
    try:
        if isinstance(g, dict):
            g = shape(g.get("geometry", g)) if "geometry" in g else shape(g)
        if g is None or g.is_empty:
            return None
        return g.representative_point()
    except Exception:
        return None


def _explode(geom):
    if geom is None or geom.is_empty:
        return []
    if geom.geom_type == "Polygon":
        return [geom]
    if geom.geom_type == "MultiPolygon":
        return [p for p in geom.geoms if not p.is_empty]
    # GeometryCollection etc. — keep only polygonal parts
    return [p for p in getattr(geom, "geoms", []) if p.geom_type == "Polygon"]


def gap_regions(
    buildings,
    aoi,
    *,
    grid_m: float = GRID_M,
    gap_thresh: float = GAP_THRESH,
    sensitivity: float = SENSITIVITY,
    min_gap_area_m2: float = MIN_GAP_AREA_M2,
    gap_dilate_m: float = GAP_DILATE_M,
    min_built_neighbors: int = MIN_BUILT_NEIGHBORS,
    coverage_fallback: float = COVERAGE_FALLBACK,
) -> GapResult:
    """Compute AI gap regions inside ``aoi`` given already-fetched ``buildings``.

    Parameters
    ----------
    buildings : iterable of shapely geoms (Polygon/Point) or GeoJSON dicts.
        The Overture footprints already fetched for this AOI.
    aoi : shapely (Multi)Polygon or GeoJSON dict, EPSG:4326.
    grid_m, gap_thresh, sensitivity, min_gap_area_m2, gap_dilate_m : tuning.

    Returns
    -------
    GapResult with ``regions`` (EPSG:4326 shapely Polygons) + ``stats``.
    """
    aoi_ll = _as_multipolygon(aoi)
    if aoi_ll is None:
        return GapResult(regions=[], stats={"error": "invalid_aoi"})

    sensitivity = min(_SENS_MAX, max(_SENS_MIN, float(sensitivity)))
    grid_m = max(5.0, float(grid_m))

    # local metric frame (cos-lat about AOI centroid) — pure, no CRS lib
    c = aoi_ll.centroid
    lon0, lat0 = float(c.x), float(c.y)
    mlat = M_PER_DEG_LAT
    mlon = max(1e-6, M_PER_DEG_LAT * math.cos(math.radians(lat0)))

    def _fwd(x, y, z=None):
        return ((x - lon0) * mlon, (y - lat0) * mlat)

    def _inv(x, y, z=None):
        return (x / mlon + lon0, y / mlat + lat0)

    aoi_m = _clean(transform(_fwd, aoi_ll))
    if aoi_m is None:
        return GapResult(regions=[], stats={"error": "invalid_aoi_projected"})
    aoi_area = float(aoi_m.area)

    minx, miny, maxx, maxy = aoi_m.bounds
    ncols = max(1, int(math.ceil((maxx - minx) / grid_m)))
    nrows = max(1, int(math.ceil((maxy - miny) / grid_m)))

    # bin building representative-points into the grid
    counts: dict = {}
    for b in buildings or []:
        p = _rep_point(b)
        if p is None:
            continue
        px, py = _fwd(p.x, p.y)
        col = int((px - minx) / grid_m)
        row = int((py - miny) / grid_m)
        if 0 <= col < ncols and 0 <= row < nrows:
            counts[(row, col)] = counts.get((row, col), 0) + 1

    occupied = [v for v in counts.values() if v > 0]
    med = float(median(occupied)) if occupied else 1.0
    threshold = gap_thresh * sensitivity * med

    # classify each in-AOI cell as built-up (>= threshold) or under-built
    ok_cells = set()
    under_cells = {}          # (row, col) -> clipped cell geom
    n_cells_in_aoi = 0
    for row in range(nrows):
        y0 = miny + row * grid_m
        y1 = y0 + grid_m
        for col in range(ncols):
            x0 = minx + col * grid_m
            x1 = x0 + grid_m
            cell = box(x0, y0, x1, y1)
            inter = cell.intersection(aoi_m)
            if inter.is_empty:
                continue
            n_cells_in_aoi += 1
            # A partial edge cell only sees points from its covered fraction, so
            # scale the threshold by how much of the cell lies inside the AOI —
            # otherwise a fully-covered edge is falsely flagged as a gap.
            frac = inter.area / cell.area if cell.area > 0 else 1.0
            if counts.get((row, col), 0) < threshold * frac:
                under_cells[(row, col)] = _clean(inter) or cell
            else:
                ok_cells.add((row, col))

    # Enclosure filter: on a well-covered AOI an under-built cell is only a REAL
    # gap when it sits inside the built fabric (>= min_built_neighbors of its 8
    # neighbours are built-up) — this rejects roads / open land / sparse edges
    # that are genuinely empty, not places Overture missed. On a blank AOI
    # (coverage < coverage_fallback) we skip the filter so a brand-new area gets
    # full AI coverage.
    coverage = (len(ok_cells) / n_cells_in_aoi) if n_cells_in_aoi else 0.0
    enclosure_on = min_built_neighbors > 0 and coverage >= coverage_fallback
    gap_cells = []
    for (row, col), geom in under_cells.items():
        if enclosure_on:
            nb = sum(1 for dr in (-1, 0, 1) for dc in (-1, 0, 1)
                     if (dr or dc) and (row + dr, col + dc) in ok_cells)
            if nb < min_built_neighbors:
                continue
        gap_cells.append(geom)

    stats = {
        "grid_m": grid_m,
        "sensitivity": sensitivity,
        "median_density": round(med, 3),
        "threshold_count": round(threshold, 3),
        "coverage": round(coverage, 3),
        "enclosure": enclosure_on,
        "n_cells_in_aoi": n_cells_in_aoi,
        "n_under_cells": len(under_cells),
        "n_gap_cells": len(gap_cells),
        "aoi_area_m2": round(aoi_area, 1),
        "n_buildings": sum(counts.values()),
    }

    if not gap_cells:
        stats.update(gap_area_m2=0.0, gap_fraction=0.0, n_regions=0)
        return GapResult(regions=[], stats=stats)

    gaps_m = _clean(unary_union(gap_cells))
    gaps_m = _clean(gaps_m.intersection(aoi_m)) if gaps_m else None
    if gaps_m and gap_dilate_m > 0:
        # dilate to merge neighbouring gap cells, then re-clip to the AOI
        gaps_m = _clean(gaps_m.buffer(gap_dilate_m).intersection(aoi_m))

    regions_m = []
    for part in _explode(gaps_m):
        if part.area >= min_gap_area_m2:
            regions_m.append(part)

    gap_area = float(sum(p.area for p in regions_m))
    regions_ll = [transform(_inv, p) for p in regions_m]

    stats.update(
        gap_area_m2=round(gap_area, 1),
        gap_fraction=round(gap_area / aoi_area, 4) if aoi_area > 0 else 0.0,
        n_regions=len(regions_ll),
    )
    return GapResult(regions=regions_ll, stats=stats)


def to_featurecollection(result: GapResult) -> dict:
    """GeoJSON FeatureCollection of the gap regions (for the preview layer)."""
    return {
        "type": "FeatureCollection",
        "features": [
            {"type": "Feature", "geometry": mapping(g),
             "properties": {"kind": "gap_region", "idx": i}}
            for i, g in enumerate(result.regions)
        ],
    }
