"""nexus_eggs — per-theme Easter-egg animations for the Velocity Nexus panel.

Triggered by 5 fast clicks on the knight logo. Each theme plays a distinct,
*smooth* transient overlay effect (glitch, matrix rain, shimmer sweep, glow
heartbeat, emoji drift, sparkle burst). Pure PyQt (QPainter + QTimer /
QPropertyAnimation), Qt5/6-safe (scoped enums via qgis.PyQt), parented to a host
widget, auto-cleans, wrapped so a failure can NEVER crash QGIS.

Sleekness: 60 fps timers, antialiasing everywhere, soft gradients for glow/
shimmer, glowing round particles, a bright-head matrix trail, and a global
fade-in/out envelope so nothing ever pops or cuts.

Public API:  play(host_widget, theme_slug)
"""
import math
import random

from qgis.PyQt.QtCore import (Qt, QTimer, QPropertyAnimation,
                              QSequentialAnimationGroup, QEasingCurve,
                              QPointF, QRectF, pyqtProperty)
from qgis.PyQt.QtGui import (QColor, QPainter, QFont, QBrush, QLinearGradient, QRadialGradient)
from qgis.PyQt.QtWidgets import QWidget

_WA_CLICK = Qt.WidgetAttribute.WA_TransparentForMouseEvents
_WA_NOBG = Qt.WidgetAttribute.WA_NoSystemBackground
_AA = QPainter.RenderHint.Antialiasing
_SMOOTH = QPainter.RenderHint.SmoothPixmapTransform
_EASE = QEasingCurve.Type.OutCubic
_INOUT = QEasingCurve.Type.InOutCubic
_BOLD = QFont.Weight.Bold
_FPS_MS = 16          # ~60 fps for the timer-driven effects


def _env(prog, fade_in=0.18, fade_out=0.28):
    """Smooth 0→1→0 opacity envelope over a 0..1 progress so effects ease in and
    out instead of popping. Cosine ramps for a soft feel."""
    if prog <= 0 or prog >= 1:
        return 0.0
    if prog < fade_in:
        return 0.5 - 0.5 * math.cos(math.pi * (prog / fade_in))
    if prog > 1 - fade_out:
        return 0.5 - 0.5 * math.cos(math.pi * ((1 - prog) / fade_out))
    return 1.0


class _Overlay(QWidget):
    """Transparent, click-through overlay sized to its host. Subclasses paint."""
    def __init__(self, host):
        super().__init__(host)
        self.setAttribute(_WA_CLICK, True)
        self.setAttribute(_WA_NOBG, True)
        self.setStyleSheet("background:transparent;")
        self.setGeometry(host.rect())
        self.raise_()

    def _painter(self):
        p = QPainter(self)
        p.setRenderHint(_AA, True)
        p.setRenderHint(_SMOOTH, True)
        return p


class GlowPulse(_Overlay):
    """A soft coloured glow swells from the top then fades — a sleek heartbeat."""
    def __init__(self, host, color, dur=1900):
        super().__init__(host)
        self._c = QColor(color)
        self._v = 0.0
        up = QPropertyAnimation(self, b"v", self)
        up.setStartValue(0.0); up.setEndValue(1.0)
        up.setDuration(int(dur * 0.42)); up.setEasingCurve(_EASE)
        dn = QPropertyAnimation(self, b"v", self)
        dn.setStartValue(1.0); dn.setEndValue(0.0)
        dn.setDuration(int(dur * 0.58)); dn.setEasingCurve(_INOUT)
        self._seq = QSequentialAnimationGroup(self)
        self._seq.addAnimation(up); self._seq.addAnimation(dn)
        self._seq.finished.connect(self.deleteLater)

    def _get_v(self):
        return self._v

    def _set_v(self, val):
        self._v = val
        self.update()
    v = pyqtProperty(float, _get_v, _set_v)

    def paintEvent(self, _e):
        if self._v <= 0:
            return
        p = self._painter()
        h = max(40, int(self.height() * 0.6))
        g = QLinearGradient(0, 0, 0, h)
        top = QColor(self._c); top.setAlpha(int(170 * self._v))
        g.setColorAt(0.0, top)
        g.setColorAt(1.0, QColor(self._c.red(), self._c.green(), self._c.blue(), 0))
        p.fillRect(0, 0, self.width(), h, QBrush(g))
        p.end()

    def start(self):
        self.show(); self._seq.start()


class ShimmerSweep(_Overlay):
    """A soft gradient highlight glides across the panel, twice — sleek light."""
    def __init__(self, host, color, dur=1100, repeats=2):
        super().__init__(host)
        self._c = QColor(color)
        self._p = 0.0
        self._left = repeats
        self._anim = QPropertyAnimation(self, b"p", self)
        self._anim.setStartValue(-0.15); self._anim.setEndValue(1.15)
        self._anim.setDuration(dur); self._anim.setEasingCurve(_INOUT)
        self._anim.finished.connect(self._next)

    def _next(self):
        self._left -= 1
        if self._left > 0:
            self._anim.start()
        else:
            self.deleteLater()

    def _get_p(self):
        return self._p

    def _set_p(self, val):
        self._p = val
        self.update()
    p = pyqtProperty(float, _get_p, _set_p)

    def paintEvent(self, _e):
        p = self._painter()
        w = self.width()
        cx = w * self._p
        band = max(60, w * 0.22)
        g = QLinearGradient(cx - band / 2, 0, cx + band / 2, 0)
        edge = QColor(self._c.red(), self._c.green(), self._c.blue(), 0)
        mid = QColor(self._c); mid.setAlpha(150)
        g.setColorAt(0.0, edge)
        g.setColorAt(0.5, mid)
        g.setColorAt(1.0, edge)
        p.fillRect(QRectF(cx - band / 2, 0, band, self.height()), QBrush(g))
        p.end()

    def start(self):
        self.show(); self._anim.start()


class FallingGlyphs(_Overlay):
    """Glyphs stream down with a bright head + fading trail — sleek matrix rain."""
    def __init__(self, host, color, glyphs="01", dur=2600, cols=24):
        super().__init__(host)
        self._c = QColor(color)
        self._frame = 0
        self._max = max(40, dur // _FPS_MS)
        w = max(40, host.width())
        self._cols = [{"x": random.randint(4, w - 10),
                       "g": random.choice(glyphs),
                       "s": random.randint(0, int(self._max * 0.45)),
                       "sp": random.uniform(0.75, 1.45)} for _ in range(cols)]
        self._t = QTimer(self)
        self._t.timeout.connect(self._tick)

    def _tick(self):
        self._frame += 1
        if self._frame >= self._max:
            self._t.stop(); self.deleteLater(); return
        self.update()

    def paintEvent(self, _e):
        p = self._painter()
        p.setFont(QFont("Segoe UI Symbol", 17, _BOLD))
        h = self.height()
        gfade = _env(self._frame / float(self._max), 0.12, 0.30)
        for col in self._cols:
            if self._frame < col["s"]:
                continue
            prog = (self._frame - col["s"]) / float(self._max - col["s"]) * col["sp"]
            if prog > 1.2:
                continue
            y = int(h * min(1.0, prog))
            head = QColor(255, 255, 255)              # bright leading head
            head.setAlpha(int(235 * gfade))
            p.setPen(head)
            p.drawText(col["x"], y, col["g"])
            for t in range(1, 5):                      # colour trail above
                gy = y - t * 18
                if gy < -12:
                    continue
                c = QColor(self._c)
                c.setAlpha(int(210 * gfade * (1.0 - t * 0.2)))
                p.setPen(c)
                p.drawText(col["x"], gy, col["g"])
        p.end()

    def start(self):
        self.show(); self._t.start(_FPS_MS)


class EmojiDrift(_Overlay):
    """An emoji glides across on a gentle arc with a smooth fade — sleek."""
    def __init__(self, host, emoji="✦", dur=2100, size=44):
        super().__init__(host)
        self._e = emoji
        self._size = size
        self._p = 0.0
        self._y = random.uniform(0.32, 0.58)
        self._anim = QPropertyAnimation(self, b"p", self)
        self._anim.setStartValue(0.0); self._anim.setEndValue(1.0)
        self._anim.setDuration(dur); self._anim.setEasingCurve(_INOUT)
        self._anim.finished.connect(self.deleteLater)

    def _get_p(self):
        return self._p

    def _set_p(self, val):
        self._p = val
        self.update()
    p = pyqtProperty(float, _get_p, _set_p)

    def paintEvent(self, _e):
        p = self._painter()
        p.setFont(QFont("Segoe UI Emoji", self._size))
        x = int(self.width() * self._p) - self._size // 2
        arc = math.sin(self._p * math.pi) * self.height() * 0.10   # gentle rise
        y = int(self.height() * self._y - arc)
        op = _env(self._p, 0.14, 0.18)
        c = QColor("#FFFFFF"); c.setAlpha(int(255 * op))
        p.setPen(c)
        p.drawText(x, y, self._e)
        p.end()

    def start(self):
        self.show(); self._anim.start()


class GlitchFlicker(_Overlay):
    """A sleek RGB-split glitch: smooth oscillating offset + a scanline, fades."""
    def __init__(self, host, color, text="SYSTEM.BREACH", dur=1100):
        super().__init__(host)
        self._c = QColor(color)
        self._text = text
        self._frame = 0
        self._max = max(24, dur // _FPS_MS)
        self._t = QTimer(self)
        self._t.timeout.connect(self._tick)

    def _tick(self):
        self._frame += 1
        if self._frame >= self._max:
            self._t.stop(); self.deleteLater(); return
        self.update()

    def paintEvent(self, _e):
        p = self._painter()
        p.setFont(QFont("Consolas", 15, _BOLD))
        prog = self._frame / float(self._max)
        op = _env(prog, 0.12, 0.25)
        # smooth oscillating split (sine) + a touch of jitter for life
        split = int(3 * math.sin(prog * math.pi * 6)) + random.randint(-1, 1)
        cy = self.height() // 2
        for col, dx in ((QColor("#FF2E63"), -split), (QColor("#19E5FF"), split),
                        (self._c, 0)):
            col.setAlpha(int(200 * op))
            p.setPen(col)
            p.drawText(14 + dx, cy, self._text)
        # a soft scanline sweeping down
        sy = int(self.height() * ((prog * 2) % 1.0))
        ln = QColor(self._c); ln.setAlpha(int(70 * op))
        p.fillRect(0, sy, self.width(), 2, QBrush(ln))
        p.end()

    def start(self):
        self.show(); self._t.start(_FPS_MS)


class SparkleBurst(_Overlay):
    """Glowing round particles burst from the top and arc with gravity, fading."""
    def __init__(self, host, color, dur=1700, n=20):
        super().__init__(host)
        self._c = QColor(color)
        self._frame = 0
        self._max = max(48, dur // _FPS_MS)
        cx = host.width() / 2.0
        self._ps = []
        for i in range(n):
            ang = math.radians(360.0 / n * i + random.uniform(-8, 8))
            sp = random.uniform(2.4, 5.6)
            self._ps.append({"x": cx, "y": 22.0,
                             "vx": sp * math.cos(ang),
                             "vy": sp * math.sin(ang) - 2.6,
                             "r": random.uniform(2.6, 4.6)})
        self._t = QTimer(self)
        self._t.timeout.connect(self._tick)

    def _tick(self):
        self._frame += 1
        for q in self._ps:
            q["x"] += q["vx"]; q["y"] += q["vy"]; q["vy"] += 0.14
            q["vx"] *= 0.99
        if self._frame >= self._max:
            self._t.stop(); self.deleteLater(); return
        self.update()

    def paintEvent(self, _e):
        p = self._painter()
        prog = self._frame / float(self._max)
        life = _env(prog, 0.05, 0.45)
        for q in self._ps:
            r = q["r"]
            # soft glow halo
            halo = QRadialGradient(QPointF(q["x"], q["y"]), r * 2.6)
            core = QColor(self._c); core.setAlpha(int(220 * life))
            edge = QColor(self._c.red(), self._c.green(), self._c.blue(), 0)
            halo.setColorAt(0.0, core)
            halo.setColorAt(1.0, edge)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(halo))
            p.drawEllipse(QPointF(q["x"], q["y"]), r * 2.6, r * 2.6)
            # bright core
            p.setBrush(QBrush(core))
            p.drawEllipse(QPointF(q["x"], q["y"]), r, r)
        p.end()

    def start(self):
        self.show(); self._t.start(_FPS_MS)


# theme slug → effect config (one place; theme dicts stay clean)
EGGS = {
    "velocity":  {"fx": "sparkle", "color": "#1AE5FF"},
    "fibertime": {"fx": "pulse",   "color": "#FFD400"},
    "cyberpunk": {"fx": "glitch",  "color": "#FF2E63", "text": "SYSTEM.BREACH"},
    "synthwave": {"fx": "shimmer", "color": "#FF2975"},
    "matrix":    {"fx": "rain",    "color": "#00FF41", "glyphs": "01●◆▪▮▰"},
    "vaporwave": {"fx": "drift",   "emoji": "🌴"},
    "dracula":   {"fx": "drift",   "emoji": "🦇"},
    "nord":      {"fx": "shimmer", "color": "#88c0d0"},
    "solarized": {"fx": "sparkle", "color": "#2aa198"},
    "royalgold": {"fx": "shimmer", "color": "#FFD700"},
    "crimson":   {"fx": "pulse",   "color": "#DC143C"},
    "arctic":    {"fx": "rain",    "color": "#A5F2F3", "glyphs": "❄✦★∗"},
}


def play(host, slug):
    """Play the Easter-egg effect for `slug` on `host`. Never raises. A hard
    backstop timer force-deletes the overlay after 4s so it can never linger."""
    try:
        cfg = EGGS.get(slug, {"fx": "sparkle", "color": "#1AE5FF"})
        fx = cfg.get("fx", "sparkle")
        color = cfg.get("color", "#1AE5FF")
        if fx == "glitch":
            ov = GlitchFlicker(host, color, cfg.get("text", "NEXUS"))
        elif fx == "rain":
            ov = FallingGlyphs(host, color, cfg.get("glyphs", "01"))
        elif fx == "shimmer":
            ov = ShimmerSweep(host, color)
        elif fx == "pulse":
            ov = GlowPulse(host, color)
        elif fx == "drift":
            ov = EmojiDrift(host, cfg.get("emoji", "✦"))
        else:
            ov = SparkleBurst(host, color)
        ov.start()
        QTimer.singleShot(4000, ov.deleteLater)
    except Exception:
        pass
