"""The Velocity planning schema — what OUR pipeline produces, not what a client sent.

Separate from `herotel_schema` on purpose. That one describes delivered client
work we may only report on; this one describes our own output, which we are free
to fix. The checks are shared — `herotel_schema.core.check()` consumes either
schema — because two copies of the same check logic disagree within a week.

⛔ `frozen: false` in schema.yaml. Nothing here may be enforced as a publish
gate until step 03 has cross-checked the draft beyond its two reference towns.
"""
import os

SCHEMA_PATH = os.path.join(os.path.dirname(__file__), "schema.yaml")
