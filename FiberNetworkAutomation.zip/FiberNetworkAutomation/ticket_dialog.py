"""ticket_dialog — the "Log a ticket" form for the home panel's red button.

A teammate reports a bug / requests a feature / asks a question; on submit,
`on_submit(payload)` is called (the plugin sends it to the planning office via
the Nexus backend). Screenshots ride along in payload['_shots'] as PNG bytes.
Returns True on a successful (queued) send. Fully fail-soft.

Design = "Bento Glass" refined for SPEED (JJ, 2026-06-16): hundreds of tickets
get logged, so the fast path is pick-type → one-line summary → Ctrl+Enter.
Everything else is optional with smart defaults. Notes:
  • TYPE segmented (Bug / Idea / Question) — kind stays bug/feature for the
    backend; a Question rides as a feature with [Question] in the body.
  • PRIORITY + AREA on one compact row (small dropdowns, area auto-detected) and
    folded into the body — so the {kind,title,body,_shots} payload CONTRACT is
    unchanged (the plugin does backend.insert('tickets', payload) with the whole
    dict, so a new top-level key would 400 the insert).
  • DETAILS has no length limit (paste whole tracebacks); a code-view toggle.
  • UNLIMITED screenshots; paste-anywhere; each downscaled to keep uploads small.
  • "Attach last error" + "Add map view" quick actions (best-effort, fail-soft).
  • Auto-diagnostics = one quiet line (version·QGIS·project·layers), on by default.
  • Ctrl+Enter to send, Esc to cancel.
"""
from qgis.PyQt.QtCore import Qt, QBuffer, QByteArray, QIODevice
from qgis.PyQt.QtGui import QImage, QPixmap
from qgis.PyQt.QtWidgets import (QApplication, QComboBox, QDialog, QFileDialog,
                                 QFrame, QHBoxLayout, QLabel, QLineEdit,
                                 QMessageBox, QPlainTextEdit, QPushButton,
                                 QVBoxLayout)

_TYPES = [("\U0001F41E", "Bug", "bug"),
          ("✨", "Idea", "feature"),
          ("❔", "Question", "question")]
_SEVERITIES = [("Normal", "normal"), ("Whenever", "low"),
               ("Soon", "high"), ("\U0001F6A8 Can't work", "blocker")]
_AREAS = ["Network Planner", "Erven Studio", "Splice Viewer",
          "Detect Buildings", "Home panel", "Not sure"]

_QSS = """
QDialog { background:#0A1322; }
QLabel { color:#F2F7FF; background:transparent; }
QLabel#vfTkBrand { color:#2DD4BF; font-size:9px; font-weight:700; letter-spacing:2px; }
QLabel#vfTkTitle { font-size:16px; font-weight:800; }
QLabel#vfTkHint  { color:#9DB2C8; font-size:11px; }
QLabel#vfTkLab   { color:#EAF1FF; font-size:12px; font-weight:700; }
QLabel#vfTkMini  { color:#6f86a0; font-size:9px; font-weight:700; letter-spacing:1px;
                   font-family:'JetBrains Mono','Consolas',monospace; }

QComboBox, QLineEdit, QPlainTextEdit {
    background:#0E1A2E; color:#F2F7FF; border:1px solid #234a5a;
    border-radius:10px; padding:9px 11px; font-size:12.5px;
}
QComboBox { padding:8px 11px; font-size:12px; }
QComboBox:focus, QLineEdit:focus, QPlainTextEdit:focus { border:1px solid #2DD4BF; }
QComboBox::drop-down { border:none; width:20px; }
/* style the OPEN dropdown list too — otherwise it falls back to the system
   palette (light list under a dark dialog) when QGIS is in light mode */
QComboBox QAbstractItemView {
    background:#0E1A2E; color:#F2F7FF; border:1px solid #234a5a;
    selection-background-color:#2DD4BF; selection-color:#042b27; outline:none;
}

QPushButton#vfTkSeg {
    background:rgba(255,255,255,0.03); color:#9DB2C8; border:1px solid #234a5a;
    border-radius:10px; padding:10px 6px; font-size:12.5px; font-weight:700;
}
QPushButton#vfTkSeg:hover { color:#EAF1FF; border:1px solid #2DD4BF; }
QPushButton#vfTkSeg[on="true"] { background:#2DD4BF; color:#042b27; border:1px solid #2DD4BF; }

QPushButton#vfTkQuick, QPushButton#vfTkMono {
    background:rgba(255,255,255,0.04); color:#9DB2C8; border:1px solid #234a5a;
    border-radius:9px; padding:7px 11px; font-size:11px; font-weight:700;
}
QPushButton#vfTkQuick:hover, QPushButton#vfTkMono:hover { color:#EAF1FF; border:1px solid #2DD4BF; }
QPushButton#vfTkMono[on="true"] { background:#2DD4BF; color:#042b27; border-color:#2DD4BF; }

QFrame#vfTkShots { background:rgba(45,212,191,0.05); border:1px dashed #2DD4BF55; border-radius:12px; }
QLabel#vfTkThumb { border:1px solid #234a5a; border-radius:8px; }
QLabel#vfTkThumb:hover { border:1px solid #FF6B6B; }

QFrame#vfTkDiag { background:rgba(255,255,255,0.025); border:1px solid #1c3344; border-radius:10px; }
QLabel#vfTkDiagV { color:#7e93b0; font-size:10px; font-family:'JetBrains Mono','Consolas',monospace; }
QPushButton#vfTkDiagBtn { border:none; border-radius:8px; font-size:9px; font-weight:800; padding:3px 9px; }
QPushButton#vfTkDiagBtn[on="true"]  { background:#2DD4BF; color:#042b27; }
QPushButton#vfTkDiagBtn[on="false"] { background:#234a5a; color:#9DB2C8; }

QPushButton#vfTkSend {
    background:qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #34e0cb, stop:1 #1fb6a3);
    color:#042b27; border:none; border-radius:10px; padding:10px 17px; font-weight:800; font-size:13px;
}
QPushButton#vfTkSend:hover { border:1px solid #FFFFFF; }
QPushButton#vfTkCancel { background:transparent; color:#9DB2C8; border:none; padding:10px 14px; font-weight:700; }
QPushButton#vfTkCancel:hover { color:#FFFFFF; }
QLabel#vfTkKbd { color:#6f86a0; font-size:10px; }
"""


class TicketDialog(QDialog):
    def __init__(self, iface, on_submit, parent=None):
        super().__init__(parent or iface.mainWindow())
        self.iface = iface
        self._on_submit = on_submit
        self._shots = []                       # list[bytes] (PNG) — no cap
        self._type_idx = 0
        self._diag_on = True
        self.setWindowTitle("Log a ticket")
        self.setMinimumWidth(470)
        self.setStyleSheet(_QSS)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 16, 20, 14)
        lay.setSpacing(8)

        # header
        hrow = QHBoxLayout()
        hrow.setSpacing(12)
        ic = QLabel("\U0001F3AB")
        ic.setFixedSize(38, 38)
        ic.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ic.setStyleSheet("background:qlineargradient(x1:0,y1:0,x2:1,y2:1,"
                         "stop:0 #F0455C, stop:1 #D11E37); color:#fff;"
                         "border-radius:11px; font-size:18px;")
        hrow.addWidget(ic, 0, Qt.AlignmentFlag.AlignTop)
        hcol = QVBoxLayout()
        hcol.setSpacing(1)
        br = QLabel("VELOCITY RELAY")
        br.setObjectName("vfTkBrand")
        hcol.addWidget(br)
        tt = QLabel("Log a ticket")
        tt.setObjectName("vfTkTitle")
        hcol.addWidget(tt)
        sub = QLabel("Goes straight to the planning office.")
        sub.setObjectName("vfTkHint")
        hcol.addWidget(sub)
        hrow.addLayout(hcol, 1)
        lay.addLayout(hrow)
        lay.addSpacing(4)

        # TYPE (segmented, no label — self-evident)
        self._seg_btns = []
        seg = QHBoxLayout()
        seg.setSpacing(8)
        for i, (emo, label, _key) in enumerate(_TYPES):
            b = QPushButton(f"{emo}  {label}")
            b.setObjectName("vfTkSeg")
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setProperty("on", "true" if i == 0 else "false")
            b.clicked.connect(lambda _=False, idx=i: self._pick_type(idx))
            self._seg_btns.append(b)
            seg.addWidget(b)
        lay.addLayout(seg)

        # SUMMARY (the one required field — placeholder is the label)
        self.title = QLineEdit()
        self.title.setPlaceholderText("One-line summary — e.g. 'Span check misses drop cables'")
        self.title.setMaxLength(160)
        lay.addWidget(self.title)

        # DETAILS (optional, no limit) + code-view toggle in the label row
        drow = QHBoxLayout()
        dl = QLabel("Details  (optional)")
        dl.setObjectName("vfTkLab")
        drow.addWidget(dl)
        drow.addStretch(1)
        self._mono = QPushButton("</>  code")
        self._mono.setObjectName("vfTkMono")
        self._mono.setCursor(Qt.CursorShape.PointingHandCursor)
        self._mono.setProperty("on", "false")
        self._mono.clicked.connect(self._toggle_mono)
        drow.addWidget(self._mono)
        lay.addLayout(drow)
        self.body = QPlainTextEdit()
        self.body.setPlaceholderText("What happened, or what you'd like. Paste a whole error "
                                     "here if you have one — no length limit.")
        self.body.setMinimumHeight(96)
        lay.addWidget(self.body)

        # quick actions
        qrow = QHBoxLayout()
        qrow.setSpacing(8)
        qerr = QPushButton("⚠️  Attach last error")
        qerr.setObjectName("vfTkQuick")
        qerr.setCursor(Qt.CursorShape.PointingHandCursor)
        qerr.setToolTip("Pull the most recent error the app recorded into Details")
        qerr.clicked.connect(self._attach_last_error)
        qrow.addWidget(qerr)
        qmap = QPushButton("\U0001F5FA️  Add map view")
        qmap.setObjectName("vfTkQuick")
        qmap.setCursor(Qt.CursorShape.PointingHandCursor)
        qmap.setToolTip("Attach a snapshot of your current map")
        qmap.clicked.connect(self._attach_map_view)
        qrow.addWidget(qmap)
        qrow.addStretch(1)
        lay.addLayout(qrow)

        # PICTURES (optional, compact)
        sr = QHBoxLayout()
        pl = QLabel("Pictures  (optional)")
        pl.setObjectName("vfTkLab")
        sr.addWidget(pl)
        sr.addStretch(1)
        paste = QPushButton("\U0001F4CB  Paste")
        paste.setObjectName("vfTkQuick")
        paste.setToolTip("Paste an image from the clipboard (Ctrl+V anywhere also works)")
        paste.clicked.connect(self._paste)
        sr.addWidget(paste)
        attach = QPushButton("\U0001F4CE  Attach")
        attach.setObjectName("vfTkQuick")
        attach.clicked.connect(self._attach)
        sr.addWidget(attach)
        lay.addLayout(sr)
        self._shots_box = QFrame()
        self._shots_box.setObjectName("vfTkShots")
        self._shots_box.setMinimumHeight(70)
        self._thumbs = QHBoxLayout(self._shots_box)
        self._thumbs.setContentsMargins(10, 9, 10, 9)
        self._thumbs.setSpacing(10)
        self._empty = QLabel("Press Ctrl+V anywhere to paste, or attach — add as many "
                             "as you need. Click a picture to remove it.")
        self._empty.setObjectName("vfTkHint")
        self._empty.setWordWrap(True)
        self._thumbs.addWidget(self._empty)
        self._thumbs.addStretch(1)
        lay.addWidget(self._shots_box)
        lay.addSpacing(3)

        # PRIORITY + AREA on one compact row (smart defaults — no touch needed)
        meta = QHBoxLayout()
        meta.setSpacing(10)
        pcol = QVBoxLayout()
        pcol.setSpacing(3)
        pm = QLabel("PRIORITY")
        pm.setObjectName("vfTkMini")
        pcol.addWidget(pm)
        self.sev = QComboBox()
        self.sev.addItems([s[0] for s in _SEVERITIES])
        pcol.addWidget(self.sev)
        meta.addLayout(pcol, 1)
        acol = QVBoxLayout()
        acol.setSpacing(3)
        am = QLabel("AREA")
        am.setObjectName("vfTkMini")
        acol.addWidget(am)
        self.area = QComboBox()
        self.area.addItems(_AREAS)
        self.area.setCurrentIndex(self._detect_area())
        acol.addWidget(self.area)
        meta.addLayout(acol, 1)
        lay.addLayout(meta)
        lay.addSpacing(4)

        # DIAGNOSTICS — one quiet line
        self._diag = QFrame()
        self._diag.setObjectName("vfTkDiag")
        dr = QHBoxLayout(self._diag)
        dr.setContentsMargins(11, 8, 9, 8)
        dr.setSpacing(9)
        dot = QLabel("●")
        dot.setStyleSheet("color:#3DFF9A; font-size:9px;")
        dr.addWidget(dot)
        self._diag_vals = QLabel("App info auto-attached — " + self._diagnostics_line())
        self._diag_vals.setObjectName("vfTkDiagV")
        self._diag_vals.setWordWrap(True)
        self._diag_vals.setToolTip("Version, QGIS, project + last error — no personal "
                                   "data, nothing from your files.")
        dr.addWidget(self._diag_vals, 1)
        self._diag_btn = QPushButton("On")
        self._diag_btn.setObjectName("vfTkDiagBtn")
        self._diag_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._diag_btn.setProperty("on", "true")
        self._diag_btn.clicked.connect(self._toggle_diag)
        dr.addWidget(self._diag_btn)
        lay.addWidget(self._diag)
        lay.addSpacing(4)

        # footer
        row = QHBoxLayout()
        kbd = QLabel("Ctrl+Enter to send  ·  Esc to close")
        kbd.setObjectName("vfTkKbd")
        row.addWidget(kbd)
        row.addStretch(1)
        cancel = QPushButton("Cancel")
        cancel.setObjectName("vfTkCancel")
        cancel.clicked.connect(self.reject)
        row.addWidget(cancel)
        self.send = QPushButton("Send ticket  →")
        self.send.setObjectName("vfTkSend")
        self.send.setCursor(Qt.CursorShape.PointingHandCursor)
        self.send.clicked.connect(self._submit)
        row.addWidget(self.send)
        lay.addLayout(row)

        self.title.setFocus()                  # ready to type immediately

    # ── helpers ───────────────────────────────────────────────────────────────
    def _restyle(self, w):
        w.style().unpolish(w)
        w.style().polish(w)

    def _pick_type(self, idx):
        self._type_idx = idx
        for i, b in enumerate(self._seg_btns):
            b.setProperty("on", "true" if i == idx else "false")
            self._restyle(b)

    def _toggle_mono(self):
        on = self._mono.property("on") != "true"
        self._mono.setProperty("on", "true" if on else "false")
        self._restyle(self._mono)
        f = self.body.font()
        f.setFamily("Consolas" if on else "")
        self.body.setFont(f)

    def _toggle_diag(self):
        self._diag_on = not self._diag_on
        self._diag_btn.setText("On" if self._diag_on else "Off")
        self._diag_btn.setProperty("on", "true" if self._diag_on else "false")
        self._restyle(self._diag_btn)
        self._diag_vals.setEnabled(self._diag_on)

    def _detect_area(self):
        try:
            from qgis.utils import plugins
            plug = plugins.get("FiberNetworkAutomation")
            if getattr(plug, "_np_dock", None) is not None:
                return 0
        except Exception:
            pass
        return 0

    def _diagnostics_line(self):
        bits = []
        try:
            from .update_check import installed_version
            bits.append(f"v{installed_version()}")
        except Exception:
            pass
        try:
            from qgis.core import Qgis, QgsProject
            bits.append(f"QGIS {Qgis.QGIS_VERSION.split('-')[0]}")
            proj = QgsProject.instance()
            if proj.baseName():
                bits.append(proj.baseName())
            bits.append(f"{len(proj.mapLayers())} layers")
        except Exception:
            pass
        return "  ·  ".join(bits) if bits else "app info will be attached"

    # ── screenshots (logic preserved; no cap) ─────────────────────────────────
    def keyPressEvent(self, e):
        m = e.modifiers() & Qt.KeyboardModifier.ControlModifier
        if e.key() == Qt.Key.Key_V and m:
            if self._paste(quiet=True):
                return
        if e.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and m:
            self._submit()
            return
        super().keyPressEvent(e)

    def _paste(self, quiet=False):
        cb = QApplication.clipboard()
        img = cb.image()
        if img is not None and not img.isNull():
            self._add_image(img)
            return True
        md = cb.mimeData()
        if md is not None and md.hasUrls():
            added = False
            for u in md.urls():
                p = u.toLocalFile()
                if p:
                    im = QImage(p)
                    if not im.isNull():
                        self._add_image(im)
                        added = True
            if added:
                return True
        if not quiet:
            QMessageBox.information(self, "Paste screenshot",
                                    "No image found on the clipboard. Take a screenshot "
                                    "(e.g. Win+Shift+S) first, then click Paste.")
        return False

    def _attach(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Attach screenshot(s)", "",
            "Images (*.png *.jpg *.jpeg *.bmp *.gif)")
        for p in paths or []:
            im = QImage(p)
            if not im.isNull():
                self._add_image(im)

    def _attach_map_view(self):
        try:
            pix = self.iface.mapCanvas().grab()
            self._add_image(pix.toImage())
        except Exception:
            QMessageBox.information(self, "Map view",
                                    "Couldn't grab the map view right now.")

    def _attach_last_error(self):
        text = None
        try:
            from .fibre_automation.nexus_profile import error_capture as ec
            text = getattr(ec, "last_error_text", lambda: None)()
        except Exception:
            text = None
        if text:
            cur = self.body.toPlainText()
            self.body.setPlainText((cur + "\n\n" if cur else "")
                                   + "--- last recorded error ---\n" + text)
        else:
            QMessageBox.information(self, "Last error",
                                    "No recent error was found in the app's log. If you "
                                    "saw an error message, please paste it into Details.")

    def _add_image(self, qimage):
        if qimage.width() > 1600:
            qimage = qimage.scaledToWidth(1600, Qt.TransformationMode.SmoothTransformation)
        ba = QByteArray()
        buf = QBuffer(ba)
        buf.open(QIODevice.OpenModeFlag.WriteOnly)
        qimage.save(buf, "PNG")
        buf.close()
        self._shots.append(bytes(ba))
        self._rebuild_thumbs()

    def _rebuild_thumbs(self):
        while self._thumbs.count():
            it = self._thumbs.takeAt(0)
            w = it.widget()
            if w is not None:
                w.deleteLater()
        if not self._shots:
            self._thumbs.addWidget(self._empty)
            self._empty.show()
            self._thumbs.addStretch(1)
            return
        for i, data in enumerate(self._shots):
            pix = QPixmap()
            pix.loadFromData(data, "PNG")
            thumb = QLabel()
            thumb.setObjectName("vfTkThumb")
            thumb.setPixmap(pix.scaled(80, 54, Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation))
            thumb.setToolTip("Click to remove")
            thumb.setCursor(Qt.CursorShape.PointingHandCursor)
            thumb.mousePressEvent = lambda _e, idx=i: self._remove_shot(idx)
            self._thumbs.addWidget(thumb)
        self._thumbs.addStretch(1)

    def _remove_shot(self, idx):
        if 0 <= idx < len(self._shots):
            self._shots.pop(idx)
            self._rebuild_thumbs()

    # ── submit ────────────────────────────────────────────────────────────────
    def _submit(self):
        title = self.title.text().strip()
        if not title:
            QMessageBox.information(self, "Log a ticket",
                                    "Please add a one-line summary so it's easy to triage.")
            return
        ui_emoji, ui_label, ui_kind = _TYPES[self._type_idx]
        sev_label, sev_key = _SEVERITIES[self.sev.currentIndex()]
        area = self.area.currentText()
        # kind MUST stay bug/feature for downstream logic + the DB; Question rides
        # as a feature with its real type in the body header.
        kind = ui_kind if ui_kind in ("bug", "feature") else "feature"
        header = f"[{ui_label}]  [Priority: {sev_label}]  [Area: {area}]"
        user_body = self.body.toPlainText().strip()
        parts = [header]
        if user_body:
            parts.append(user_body)
        if self._diag_on:
            parts.append("--- app info (auto) ---\n" + self._diagnostics_line())
        # EXACT original contract — {kind,title,body,_shots} only (no new top-level
        # keys; the plugin inserts the whole dict into the tickets table).
        payload = {
            "kind": kind,
            "title": title,
            "body": "\n\n".join(parts),
            "_shots": list(self._shots),
        }
        self.send.setEnabled(False)
        self.send.setText("Sending…")
        QApplication.processEvents()
        try:
            ok = self._on_submit(payload)
        except Exception:
            ok = False
        if ok is False:
            QMessageBox.warning(self, "Log a ticket",
                                "Couldn't reach the server right now — your ticket is "
                                "saved and will send automatically when you're back online.")
            self.accept()
            return
        total = ok.get("shots_total", 0) if isinstance(ok, dict) else 0
        uploaded = ok.get("shots_uploaded", 0) if isinstance(ok, dict) else 0
        pdf_ok = ok.get("pdf_ok", True) if isinstance(ok, dict) else True
        if pdf_ok is False:
            QMessageBox.warning(
                self, "Ticket sent — PDF not generated",
                "Your ticket was saved ✓\n\nBut the PDF document could not be built "
                "or uploaded (you may be offline). The full ticket text is still stored — "
                "please re-send once you're back online so it arrives as a PDF in the "
                "office feed.")
            self.accept()
            return
        if total and uploaded < total:
            missed = total - uploaded
            QMessageBox.warning(
                self, "Ticket sent — pictures not attached",
                f"Your ticket was sent ✓\n\nBut {missed} of {total} picture(s) could "
                "not be uploaded (you may be offline). The ticket text went through — "
                "please re-attach and re-send once you're back online.")
        else:
            extra = (f"  {uploaded} picture(s) attached." if uploaded else "")
            QMessageBox.information(self, "Ticket sent",
                                    "Thanks! Your ticket went to the planning office. ✓"
                                    + extra)
        self.accept()
