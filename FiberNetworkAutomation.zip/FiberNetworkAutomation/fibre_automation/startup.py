"""Global SESSION state and step routing."""

from qgis.core import QgsCoordinateReferenceSystem

VUMA = "vuma"
FIBRETIME = "fibretime"
HEROTEL = "herotel"

SESSION = {
    "client": None,
    "area_code": None,
    "zone_code": None,
    "crs": None,
    "project_folder": None,
    "aoi_source": None,
}

_NS = "FiberNetworkAutomation"  # QgsProject entry namespace


def save_session_to_project():
    """Persist SESSION into the current QGIS project file (survives save/reopen)."""
    from qgis.core import QgsProject
    proj = QgsProject.instance()
    proj.writeEntry(_NS, "client",       SESSION.get("client") or "")
    proj.writeEntry(_NS, "area_code",    SESSION.get("area_code") or "")
    proj.writeEntry(_NS, "zone_code",    SESSION.get("zone_code") or "")
    crs = SESSION.get("crs")
    proj.writeEntry(_NS, "crs_authid",   crs.authid() if crs else "EPSG:4326")
    proj.writeEntry(_NS, "project_folder", SESSION.get("project_folder") or "")
    proj.writeEntry(_NS, "aoi_source",   SESSION.get("aoi_source") or "")


def load_session_from_project():
    """Load SESSION from the current QGIS project file. Returns True if data found."""
    from qgis.core import QgsProject
    proj = QgsProject.instance()
    client, ok = proj.readEntry(_NS, "client", "")
    if not ok or not client:
        return False
    SESSION["client"]         = client
    SESSION["area_code"], _   = proj.readEntry(_NS, "area_code", "")
    SESSION["zone_code"], _   = proj.readEntry(_NS, "zone_code", "")
    crs_id, _                 = proj.readEntry(_NS, "crs_authid", "EPSG:4326")
    SESSION["crs"]            = QgsCoordinateReferenceSystem(crs_id)
    folder, _                 = proj.readEntry(_NS, "project_folder", "")
    SESSION["project_folder"] = folder or None
    aoi, _                    = proj.readEntry(_NS, "aoi_source", "")
    SESSION["aoi_source"]     = aoi or None
    return True


def clear_session():
    """Reset SESSION to empty (called when a new blank project is created)."""
    SESSION.update({"client": None, "area_code": None, "zone_code": None,
                    "crs": None, "project_folder": None, "aoi_source": None})


STEP_MAP = {}


def route_step(step_name):
    """Route a step-button press to the correct client function."""
    if SESSION["client"] is None:
        print("✗ No project active — use the New Project wizard to set up a project first.")
        return
    if step_name in STEP_MAP:
        STEP_MAP[step_name]()
    else:
        print(f"Unknown step: '{step_name}'")
