"""Pass 1 (PON Cluster) — pure, unit-testable helpers for the clustering step.

The clustering MATH lives in ``erf_grouping.cluster_tight_groups_of_8`` and is NOT
touched. This module only holds the *experience* around it: a pre-flight check that
catches the common mistakes before a run, and a result summary that tells the planner
what came out. Everything here is pure — the caller passes plain facts in and gets
plain data out — so it is fully testable without QGIS and keeps
``on_cluster_erven_clicked`` readable.

Terminology follows the shipped rename: a "group" of ~8 stands IS a splitter; a
"zone" IS a PON.
"""

from collections import Counter

#: Stands per splitter-group the clustering targets (tight PON of 96 = 12 × 8).
TARGET_GROUP_SIZE = 8


def cluster_preflight(field_names, subset_string, feature_count, has_group_link):
    """Checks to run BEFORE clustering. Returns a list of ``(severity, message)``.

    ``severity`` is ``"error"`` (must stop) or ``"warn"`` (proceed, but flag it).
    Pure: the caller supplies the facts (the demand layer's field names, its active
    filter string, its feature count, and whether it already carries a group-link
    field) and gets back the messages to show — no QGIS objects involved.
    """
    msgs = []
    fset = {str(f).lower() for f in (field_names or [])}

    if not feature_count:
        msgs.append(("error", "The selected layer has no features to cluster."))
        return msgs

    if "zone_name" in fset or has_group_link:
        msgs.append((
            "warn",
            "This layer already has 'zone_name' / 'group_<N>' fields — it looks like a "
            "layer that was already grouped, not the original demand points. Pick the "
            "ORIGINAL demand points layer in the dropdown above.",
        ))

    if subset_string:
        msgs.append((
            "warn",
            f"This layer has an active filter ({subset_string!r}); only the filtered "
            "features will be clustered.",
        ))

    return msgs


def cluster_summary(feature_to_group, target_size=TARGET_GROUP_SIZE):
    """Summarise a ``{feature_id: group_id}`` clustering result.

    Returns a dict: ``splitters`` (distinct groups), ``stands`` (total assigned),
    ``avg`` per splitter, ``min``/``max`` splitter size, ``over_target`` (list of
    ``(group_id, size)`` bigger than the target, worst first) and ``under_half``
    (tiny splitters below half the target, smallest first). Pure.
    """
    if not feature_to_group:
        return {"splitters": 0, "stands": 0, "avg": 0.0, "min": 0, "max": 0,
                "over_target": [], "under_half": []}

    sizes = Counter(feature_to_group.values())
    counts = sorted(sizes.values())
    stands = sum(counts)
    splitters = len(sizes)
    small_cut = max(1, target_size // 2)
    over = sorted(((g, n) for g, n in sizes.items() if n > target_size),
                  key=lambda t: (-t[1], t[0]))
    under = sorted(((g, n) for g, n in sizes.items() if n < small_cut),
                   key=lambda t: (t[1], t[0]))
    return {
        "splitters": splitters,
        "stands": stands,
        "avg": round(stands / splitters, 1),
        "min": counts[0],
        "max": counts[-1],
        "over_target": over,
        "under_half": under,
    }


def format_summary(summary, target_size=TARGET_GROUP_SIZE):
    """Render a :func:`cluster_summary` dict as clean log lines (list of str)."""
    if not summary.get("splitters"):
        return ["No splitters were formed — check the demand layer and try again."]

    lines = [
        "── Clustering result ─────────────────────────",
        f"  Splitters formed : {summary['splitters']}",
        f"  Stands assigned  : {summary['stands']}",
        f"  Avg per splitter : {summary['avg']}  "
        f"(min {summary['min']}, max {summary['max']}, target {target_size})",
    ]
    if summary["over_target"]:
        top = ", ".join(f"#{g}={n}" for g, n in summary["over_target"][:6])
        lines.append(f"  ⚠ {len(summary['over_target'])} splitter(s) over target: {top}")
    if summary["under_half"]:
        top = ", ".join(f"#{g}={n}" for g, n in summary["under_half"][:6])
        lines.append(f"  ⚠ {len(summary['under_half'])} small splitter(s): {top}")
    if not summary["over_target"] and not summary["under_half"]:
        lines.append("  ✓ every splitter is within a healthy size range")
    return lines
