# -*- coding: utf-8 -*-
# claude:intent MUTATE - user asked (JJ GO 2026-10-19, plan "One-Page Atlas Pictures"): "add a picture to one
#   page ... that picture goes onto every single other page. That's what we don't want" - plan: layout items +
#   one project entry only; never a layer, never a feature, never a file other than a copy of the chosen image.
# claude:boq-impact none - print-layout pictures only; no layer data is read for counts or written
"""Pictures pinned to ONE page of an atlas layout (JJ 2026-10-19; every layout 2026-10-20).

An atlas is one layout drawn once per page, so a picture placed on it prints on every page.
A pinned picture carries two data-defined rules that read the page being drawn:
  * Exclude from exports  - left out of the PDF / print on every other page;
  * Opacity               - 0 % on every other page, so the designer's atlas preview matches.

The page is remembered by its NAME (the book's `unit`: "PON 07", "Overview"), never its number,
because numbers move on a rebuild. A grid book renumbers its blocks (Remove Grid Blocks), so
there the page is the block's ORIGINAL number (`orig_no`) and the rule looks up the block's
current number when the page is drawn.

Any other atlas (Commercial page layouts, HLD Book custom pages, a layout the operator made)
keys the page by a page field it can find (`unit`, `orig_no`, `page_title`, or the atlas page
name field), else by the page feature itself. A layout without an atlas needs none of this:
a picture there already prints only on the page it sits on.

A rebuild deletes the layout and makes a new one, so every pinned picture is also stored in the
project (file, page, place, size) and put back after each build (`capture` before, `reapply`
after; called from live_build).
"""
import json
import os
import shutil
import uuid

ROLE = "page_picture"
ROLE_KEY = "vf_native_role"         # the engine's NATIVE_ROLE: its layout checks know this role
PIC_ID = "vf_page_pic_id"
PIC_KEY = "vf_page_key"
SCOPE, ENTRY = "VelocityNexus", "page_pictures"
FOLDER = "hld_pictures"
TOOLBAR_NAME = "vfPagePicturesToolbar"
TITLE = "Page pictures"
_NO_PAGE = "attribute(@atlas_feature,'seq') IS NULL"     # designer without atlas preview, plain export


class PinError(ValueError):
    """A pin request that must not be applied (nothing is changed)."""


def _ge():
    try:
        from . import grid_edit as GE
    except ImportError:  # pragma: no cover - plain-module tests
        import grid_edit as GE
    return GE


def _q(v):
    from qgis.core import QgsExpression
    return QgsExpression.quotedString(str(v))


def is_book(layout):
    """An HLD book atlas built by Velocity Nexus (its coverage is the generated page list)."""
    try:
        cov = layout.atlas().coverageLayer() if layout is not None else None
        return (cov is not None and cov.customProperty("vf_hld_role") == "book_pages"
                and cov.fields().indexOf("unit") >= 0)
    except Exception:
        return False


def is_atlas(layout):
    """Any layout with an atlas coverage layer (the page buttons work on all of them)."""
    try:
        return layout is not None and layout.atlas().coverageLayer() is not None
    except Exception:
        return False


_PAGE_FIELDS = ("unit", "orig_no", "page_title")


def _page_field(layout):
    """The coverage field that names a page in a non-book atlas, else None (use the feature)."""
    cov = layout.atlas().coverageLayer()
    names = cov.fields().names()
    for n in _PAGE_FIELDS:
        if n in names:
            return n
    expr = (layout.atlas().pageNameExpression() or "").strip()
    bare = expr[1:-1] if len(expr) > 1 and expr[0] == expr[-1] == '"' else expr
    return bare if bare in names else None


def _no_page(key):
    """True while no atlas page is being drawn (designer without preview, plain export)."""
    if key.get("kind") in ("field", "fid"):
        return "@atlas_featureid IS NULL"
    return _NO_PAGE


def _grid(layout):
    """The numbered grid of a grid book, else None (PON / zone books have none)."""
    try:
        return _ge().find_target(layout)[1]
    except Exception:
        return None


# ── the page rule ─────────────────────────────────────────────────────────────
def _set_clause(key):
    """Atlas Page Sets: a book page is (set, page). Keys pinned before sets existed have no
    set_no and stay on the Network pages (set 0)."""
    try:
        k = int(key.get("set_no") or 0)
    except (TypeError, ValueError):
        k = 0
    return " AND coalesce(attribute(@atlas_feature,'set_no'),0) = %d" % k


def show_expression(layout, key):
    """Expression true on exactly the pinned page; None when that page is not in the book."""
    if key.get("kind") == "grid":
        grid = _grid(layout)
        if grid is None:
            return None
        return ("coalesce(attribute(@atlas_feature,'is_overview'),0) = 0 AND "
                "attribute(get_feature(%s,'orig_no',%d),'cell_no') = to_int(attribute(@atlas_feature,'unit'))"
                % (_q(grid.id()), int(key["orig"]))) + _set_clause(key)
    if key.get("kind") == "field":
        return "coalesce(to_string(attribute(@atlas_feature,%s)),'') = %s" % (_q(key["field"]), _q(key["value"]))
    if key.get("kind") == "fid":
        return "@atlas_featureid = %d" % int(key["fid"])
    return "coalesce(attribute(@atlas_feature,'unit'),'') = %s" % _q(key["value"]) + _set_clause(key)


def _feature_set_no(f):
    try:
        return int(f["set_no"] or 0) if f.fields().indexOf("set_no") >= 0 else 0
    except (TypeError, ValueError):
        return 0


def _set_id(layout, set_no):
    """The id of page set `set_no` (pins follow the set, not its position - atlas_sets_qgis)."""
    try:
        sets = json.loads(layout.customProperty("vf_atlas_sets") or "{}").get("sets") or []
        return sets[int(set_no) - 1].get("set_id")
    except (TypeError, ValueError, IndexError, AttributeError):
        return None


def page_exists(layout, key):
    if key.get("kind") == "grid":
        grid = _grid(layout)
        return grid is not None and any(int(f["orig_no"]) == int(key["orig"]) for f in grid.getFeatures())
    cov = layout.atlas().coverageLayer()
    if cov is None:
        return False
    if key.get("kind") == "fid":
        return cov.getFeature(int(key["fid"])).isValid()
    field = key.get("field", "unit")
    if cov.fields().indexOf(field) < 0:
        return False
    k = int(key.get("set_no") or 0) if key.get("kind") == "unit" else None
    return sum(1 for f in cov.getFeatures() if _txt(f[field]) == str(key["value"])
               and (k is None or _feature_set_no(f) == k)) == 1


def _txt(v):
    """A page value as the text the page rule compares (NULL -> '')."""
    try:
        if v is None or v.isNull():
            return ""
    except Exception:
        pass
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return str(v)


def pin(item, layout, key):
    """Show `item` only on the page `key` names (export AND atlas preview)."""
    from qgis.core import QgsLayoutObject, QgsProperty
    show = show_expression(layout, key) or "false"
    nop = _no_page(key)
    dd = item.dataDefinedProperties()
    dd.setProperty(QgsLayoutObject.DataDefinedProperty.ExcludeFromExports, QgsProperty.fromExpression(
        "if(%s, false, NOT coalesce((%s), false))" % (nop, show)))
    dd.setProperty(QgsLayoutObject.DataDefinedProperty.Opacity, QgsProperty.fromExpression(
        "if(%s, 100, if(coalesce((%s), false), 100, 0))" % (nop, show)))
    item.setDataDefinedProperties(dd)
    item.setCustomProperty(ROLE_KEY, ROLE)
    item.setCustomProperty(PIC_KEY, json.dumps(key))
    if not item.customProperty(PIC_ID):
        item.setCustomProperty(PIC_ID, uuid.uuid4().hex)
    try:
        item.refreshDataDefinedProperty(QgsLayoutObject.DataDefinedProperty.AllProperties)
    except Exception:
        item.refresh()


def current_key(layout):
    """The page the designer is showing now -> key. PinError when it cannot be told apart."""
    if not is_atlas(layout):
        raise PinError("This layout has no atlas, so it has no per-page copies: a picture already "
                       "prints only on the page it sits on. Add it with Add Item > Picture.")
    cov = layout.atlas().coverageLayer()
    if cov.featureCount() == 0:
        raise PinError("This atlas has no pages (its page layer %r is empty). Rebuild the atlas "
                       "(HLD Map Book > Open in Print Layout) and try again." % cov.name())
    f = layout.reportContext().feature()
    if not layout.atlas().enabled() or not f.isValid():
        raise PinError("Turn on the atlas preview (Atlas toolbar) and go to the page first.")
    if not is_book(layout):
        return _other_key(layout, f)
    if f.fields().indexOf("unit") < 0:
        raise PinError("Turn on the atlas preview (Atlas toolbar) and go to the page first.")
    unit = "" if f["unit"] is None else str(f["unit"])
    overview = str(f["is_overview"]) in ("1", "True", "true")
    set_no = _feature_set_no(f)
    extra, prefix = {}, ""
    if set_no:                                  # a page of an Atlas Page Set (Underground...)
        extra = {"set_no": set_no, "set_id": _set_id(layout, set_no)}
        prefix = "%s " % (f["set_title"] if f.fields().indexOf("set_title") >= 0 and f["set_title"] else "set %d" % set_no)
    grid = None if overview else _grid(layout)
    if grid is not None:
        for g in grid.getFeatures():
            if str(g["cell_no"]) == unit:
                return dict({"kind": "grid", "orig": int(g["orig_no"]), "label": "%sblock %s" % (prefix, unit)}, **extra)
        raise PinError("Block %s is not in the grid any more - rebuild the atlas." % unit)
    if not unit:
        raise PinError("This page has no name, so a picture cannot be tied to it.")
    key = dict({"kind": "unit", "value": unit, "label": prefix + unit}, **extra)
    if not page_exists(layout, key):
        raise PinError("More than one page is called %r - the picture would print on all of them." % unit)
    return key


def _other_key(layout, f):
    """Page key on a non-book atlas: a naming field when it is unique, else the page feature."""
    at = layout.atlas()
    label = "page %d" % (at.currentFeatureNumber() + 1)
    field = _page_field(layout)
    if field is not None and f.fields().indexOf(field) >= 0:
        value = _txt(f[field])
        key = {"kind": "field", "field": field, "value": value, "label": value or label}
        if value and page_exists(layout, key):
            return key
    return {"kind": "fid", "fid": int(f.id()), "label": label}


def _pictures(layout):
    from qgis.core import QgsLayoutItemPicture
    return [it for it in layout.items()
            if isinstance(it, QgsLayoutItemPicture) and it.customProperty(ROLE_KEY) == ROLE]


# ── stored with the project ───────────────────────────────────────────────────
def _load(project):
    raw, _ok = project.readEntry(SCOPE, ENTRY, "")
    try:
        data = json.loads(raw) if raw else {}
        return data if isinstance(data, dict) else {}
    except ValueError:
        return {}


def _save(project, data):
    project.writeEntry(SCOPE, ENTRY, json.dumps(data))


def specs(layout, project=None):
    from qgis.core import QgsProject
    return list(_load(project or QgsProject.instance()).get(layout.name(), []))


def _spec_of(item, layout):
    pos = layout.convertToLayoutUnits(item.pagePositionWithUnits())
    size = layout.convertToLayoutUnits(item.sizeWithUnits())
    return {"id": item.customProperty(PIC_ID), "path": item.picturePath(),
            "key": json.loads(item.customProperty(PIC_KEY) or "{}"), "page": max(0, item.page()),
            "x": round(pos.x(), 3), "y": round(pos.y(), 3),
            "w": round(size.width(), 3), "h": round(size.height(), 3),
            "rot": round(item.itemRotation(), 3)}


def capture(layout, project=None):
    """Store every pinned picture of `layout` (as it sits now) in the project. Returns the count."""
    from qgis.core import QgsProject
    if layout is None:
        return 0
    project = project or QgsProject.instance()
    data = _load(project)
    rows = [_spec_of(it, layout) for it in _pictures(layout)]
    have = {r["id"] for r in rows}
    # a picture left out because its file was missing is not on the layout, but it is still the
    # operator's: keep it so it comes back when the file does (Remove drops it explicitly)
    rows += [s for s in data.get(layout.name(), []) if s.get("id") not in have and s.get("waiting")]
    if rows:
        data[layout.name()] = rows
    else:
        data.pop(layout.name(), None)
    _save(project, data)
    return len(rows)


def _add_picture(layout, path, x, y, w, h, page=0, rot=0.0):
    from qgis.core import QgsLayoutItemPicture, QgsLayoutPoint, QgsLayoutSize
    pic = QgsLayoutItemPicture(layout)
    pic.setPicturePath(path)
    mode = getattr(getattr(QgsLayoutItemPicture, "ResizeMode", QgsLayoutItemPicture), "Zoom", None)
    if mode is None:
        mode = QgsLayoutItemPicture.Zoom
    pic.setResizeMode(mode)
    layout.addLayoutItem(pic)
    pic.attemptResize(QgsLayoutSize(w, h, layout.units()))
    pic.attemptMove(QgsLayoutPoint(x, y, layout.units()), True, False, page)
    if rot:
        pic.setItemRotation(rot)
    return pic


def reapply(layout, project=None):
    """Put the stored pictures back on a (re)built book. Returns messages for the operator."""
    from qgis.core import QgsProject
    if layout is None or not is_atlas(layout):
        return []
    project = project or QgsProject.instance()
    rows = specs(layout, project)
    if not rows:
        return []
    for it in _pictures(layout):
        layout.removeLayoutItem(it)
    out = []
    for s in rows:
        key = s.get("key") or {}
        label = key.get("label") or key.get("value") or "?"
        s.pop("waiting", None)
        if not os.path.isfile(s.get("path") or ""):
            s["waiting"] = True                  # kept by capture() until its file is back
            out.append("Picture for page %s: file not found (%s) - left out." % (label, s.get("path")))
            continue
        pic = _add_picture(layout, s["path"], s["x"], s["y"], s["w"], s["h"], s.get("page", 0), s.get("rot", 0))
        pic.setId("Page picture - %s" % label)
        pic.setCustomProperty(PIC_ID, s.get("id") or uuid.uuid4().hex)
        pin(pic, layout, key)
        if not page_exists(layout, key):
            out.append("Picture %s: page %s is no longer in the book - it prints on no page."
                       % (os.path.basename(s["path"]), label))
    data = _load(project)
    data[layout.name()] = rows                   # the "waiting" marks
    _save(project, data)
    layout.refresh()
    return out


def _stash(path, project):
    """Copy the image next to the project (hld_pictures/) so moving the original cannot break the
    book. An unsaved project keeps the original path."""
    home = project.homePath() if project.fileName() else ""
    if not home or not os.path.isdir(home):
        return path
    dest_dir = os.path.join(home, FOLDER)
    if os.path.normcase(os.path.dirname(os.path.abspath(path))) == os.path.normcase(os.path.abspath(dest_dir)):
        return path
    os.makedirs(dest_dir, exist_ok=True)
    stem, ext = os.path.splitext(os.path.basename(path))
    dest, n = os.path.join(dest_dir, stem + ext), 1
    while os.path.exists(dest):
        n += 1
        dest = os.path.join(dest_dir, "%s_%d%s" % (stem, n, ext))
    shutil.copy2(path, dest)
    return dest


def add_to_current_page(layout, path, project=None):
    """Place the image `path` on the page the designer shows now. Returns the picture item."""
    from qgis.core import QgsLayoutItemMap, QgsProject
    project = project or QgsProject.instance()
    key = current_key(layout)
    if not os.path.isfile(path):
        raise PinError("No image at %s." % path)
    path = _stash(path, project)
    x, y = 20.0, 30.0
    maps = [it for it in layout.items() if isinstance(it, QgsLayoutItemMap)]
    if maps:
        r = layout.convertToLayoutUnits(maps[0].pagePositionWithUnits())
        x, y = r.x() + 8.0, r.y() + 8.0
    pic = _add_picture(layout, path, x, y, 80.0, 60.0)
    pic.setId("Page picture - %s" % key["label"])
    pin(pic, layout, key)
    capture(layout, project)
    fill_tiein_from_photo(layout, path)
    return pic


def fill_tiein_from_photo(layout, path):
    """As-Built book: a photo added on page 1 whose file carries GPS fills the empty
    "Tie in Pole Location" box (JJ 2026-10-21: from the photo, typed when it has none).
    A box the operator already typed in is never overwritten. Returns the text or None."""
    try:
        try:
            from . import book_pages_qgis as BQ
        except ImportError:  # pragma: no cover - plain-module tests
            import book_pages_qgis as BQ
        f = layout.reportContext().feature()
        idx = f.fields().indexOf("seq") if f is not None else -1
        if idx < 0 or _txt(f.attribute(idx)) != "0" or not BQ.tiein_is_blank(layout):
            return None
        from qgis.core import QgsExifTools
        res = QgsExifTools.getGeoTag(path)
        pt, found = res if isinstance(res, tuple) else (res, res is not None and not res.isEmpty())
        if not found:
            return None
        return BQ.set_tiein(layout, pt.y(), pt.x())
    except Exception:
        return None


def pin_selected(layout, project=None):
    """Pin every selected picture to the page shown now. Returns (pinned, skipped non-pictures)."""
    from qgis.core import QgsLayoutItemPicture, QgsProject
    key = current_key(layout)
    sel = list(layout.selectedLayoutItems(False))
    pics = [it for it in sel if isinstance(it, QgsLayoutItemPicture)
            and it.customProperty(ROLE_KEY) in (None, "", ROLE)]
    if not pics:
        raise PinError("Select a picture you placed on the layout first (logo and north arrow belong "
                       "on every page and are left alone).")
    for it in pics:
        pin(it, layout, key)
        it.setId("Page picture - %s" % key["label"])
    capture(layout, project or QgsProject.instance())
    return len(pics), len(sel) - len(pics)


def remove(layout, pic_id, project=None):
    from qgis.core import QgsProject
    project = project or QgsProject.instance()
    for it in _pictures(layout):
        if it.customProperty(PIC_ID) == pic_id:
            layout.removeLayoutItem(it)
    capture(layout, project)
    data = _load(project)                    # also when its file is missing (capture keeps those)
    rows = [s for s in data.get(layout.name(), []) if s.get("id") != pic_id]
    if rows:
        data[layout.name()] = rows
    else:
        data.pop(layout.name(), None)
    _save(project, data)


# ── designer toolbar ──────────────────────────────────────────────────────────
def _layout_for_window(win):
    """The layout window `win` shows now, looked up fresh (never a held wrapper: QGIS can free a
    layout on rebuild / revert and sip cannot see that delete)."""
    from qgis.PyQt import sip
    from qgis.utils import iface
    if win is None or sip.isdeleted(win) or iface is None:
        return None
    k = sip.unwrapinstance(win)
    for d in iface.openLayoutDesigners() or []:
        w = d.window() if hasattr(d, "window") else None
        if w is not None and sip.unwrapinstance(w) == k:
            return d.layout()
    return None


def _designer_for_window(win):
    """The QgsLayoutDesignerInterface of `win`, looked up fresh, else None."""
    from qgis.PyQt import sip
    from qgis.utils import iface
    if win is None or sip.isdeleted(win) or iface is None:
        return None
    k = sip.unwrapinstance(win)
    for d in iface.openLayoutDesigners() or []:
        w = d.window() if hasattr(d, "window") else None
        if w is not None and sip.unwrapinstance(w) == k:
            return d
    return None


def _run_for_key(key, slot):
    """Run a button's slot on the open designer window whose C++ address is `key`. The buttons hold
    this int, never the window: a lambda holding the window wrapper forms a cycle Python's GC
    clears, which empties the lambda's defaults while Qt still calls it ("() missing ...
    argument: 'w'", JJ 2026-10-26)."""
    from qgis.PyQt import sip
    from qgis.utils import iface
    for d in (iface.openLayoutDesigners() if iface is not None else None) or []:
        w = d.window() if hasattr(d, "window") else None
        if w is not None and sip.unwrapinstance(w) == key:
            slot(w)
            return


def _log(step):
    """One telemetry event per button outcome (action id only, no file names), so a click that
    "does nothing" on a teammate's machine shows how far it got (Lodewijk, 2026-10-20)."""
    try:
        from qgis.utils import plugins
        nx = getattr(plugins.get("FiberNetworkAutomation"), "_nexus", None)
        tel = getattr(nx, "telemetry", None)
        if tel is not None:
            tel.record_action("page_pictures:" + step, "tool")
    except Exception:
        pass


def _bar(win, text, warn=False):
    """The same message in the layout window's own message bar: visible even if a dialog is not."""
    try:
        from qgis.core import Qgis
        d = _designer_for_window(win)
        if d is not None and hasattr(d, "messageBar"):
            d.messageBar().pushMessage(TITLE, text, Qgis.MessageLevel.Warning if warn else Qgis.MessageLevel.Info, 10)
    except Exception:
        pass


def _front(win):
    """Bring the layout window forward so the dialog it opens is never hidden behind QGIS."""
    try:
        win.show()
        win.raise_()
        win.activateWindow()
    except Exception:
        pass


def _say(win, text, warn=False):
    from qgis.PyQt.QtWidgets import QMessageBox
    _bar(win, text, warn)
    _front(win)
    (QMessageBox.warning if warn else QMessageBox.information)(win, TITLE, text)


def _pick_image(win, title):
    """Ask for an image file. Qt's own dialog, owned by the layout window: the native Windows
    picker could open BEHIND QGIS, so the click looked like it did nothing while QGIS waited on
    a window nobody could see (2026-10-20)."""
    from qgis.PyQt.QtWidgets import QFileDialog
    dlg = QFileDialog(win, title, "", "Images (*.png *.jpg *.jpeg *.svg *.bmp *.gif *.tif *.tiff)")
    dlg.setOption(QFileDialog.Option.DontUseNativeDialog, True)
    dlg.setFileMode(QFileDialog.FileMode.ExistingFile)
    dlg.setAcceptMode(QFileDialog.AcceptMode.AcceptOpen)
    try:                                 # in front of every window, whatever QGIS is doing
        from qgis.PyQt.QtCore import Qt
        dlg.setWindowModality(Qt.WindowModality.ApplicationModal)
        dlg.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)
    except Exception:
        pass
    _front(win)
    dlg.raise_()
    dlg.activateWindow()
    try:
        if dlg.exec() != 1:              # QDialog.DialogCode.Accepted
            return ""
        files = dlg.selectedFiles()
        return files[0] if files else ""
    finally:
        dlg.deleteLater()


def _book_or_say(win):
    layout = _layout_for_window(win)
    if layout is None:
        _say(win, "This window's layout was rebuilt or closed. Reopen it from the Layout Manager.")
        return None
    return layout


def _preview_off(win):
    """True when this window's atlas preview is OFF. The layout keeps the last page it drew, so
    without this check a picture could be tied to a page the operator is not looking at."""
    d = _designer_for_window(win)
    try:
        return d is not None and hasattr(d, "atlasPreviewEnabled") and not d.atlasPreviewEnabled()
    except Exception:
        return False


def _on_add(win):
    _log("add_clicked")
    try:
        layout = _book_or_say(win)
        if layout is None:
            _log("add_no_layout")
            return
        try:
            if is_atlas(layout) and _preview_off(win):
                raise PinError("Turn on the atlas preview (Atlas toolbar) and go to the page first.")
            key = current_key(layout)
        except PinError as e:
            _log("add_refused")
            _say(win, str(e))
            return
        _bar(win, "Choose the picture for page %s." % key["label"])
        _log("add_dialog_open")
        path = _pick_image(win, "Picture for page %s" % key["label"])
        if not path:
            _log("add_cancelled")
            return
        layout = _book_or_say(win)             # the file dialog ran an event loop: look again
        if layout is None:
            return
        blank = _tiein_blank(layout)
        add_to_current_page(layout, path)
        _log("add_done")
        msg = "Picture added: it prints only on page %s." % key["label"]
        if blank and not _tiein_blank(layout):
            msg += " Tie-in pole coordinates filled from the photo's GPS."
        _bar(win, msg)
    except PinError as e:
        _log("add_refused")
        _say(win, str(e))
    except Exception as e:
        _log("add_error")
        _say(win, "Could not add the picture: %s" % e, warn=True)


def _tiein_blank(layout):
    try:
        from . import book_pages_qgis as BQ
        return BQ.tiein_is_blank(layout)
    except Exception:
        return False


def _on_pin(win):
    _log("pin_clicked")
    try:
        layout = _book_or_say(win)
        if layout is None:
            return
        n, skipped = pin_selected(layout)
        msg = "%d picture(s) now print only on this page." % n
        if skipped:
            msg += " %d selected item(s) are not pictures and were left on every page." % skipped
        _say(win, msg)
    except PinError as e:
        _say(win, str(e))
    except Exception as e:
        _say(win, "Could not pin: %s" % e, warn=True)


def _on_list(win):
    _log("list_clicked")
    try:
        layout = _book_or_say(win)
        if layout is None:
            return
        capture(layout)
        _front(win)
        PagePicturesDialog(win).exec()
    except Exception as e:
        _say(win, "Could not open the list: %s" % e, warn=True)


def _on_page_sets(win):
    _log("page_sets")
    try:
        from .atlas_sets_dialog import open_for_window
        open_for_window(win)
    except Exception as e:
        _say(win, "Could not open the pages window: %s" % e, warn=True)


def add_designer_buttons(designer):
    """Page-picture buttons on the toolbar of every layout designer (checked again at each click,
    so a layout that gets an atlas after the window opened works too)."""
    try:
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtGui import QAction
        from qgis.PyQt.QtWidgets import QToolBar
        layout = designer.layout() if hasattr(designer, "layout") else None
        win = designer.window() if hasattr(designer, "window") else None
        if layout is None or win is None:
            return
        old = win.findChild(QToolBar, TOOLBAR_NAME)
        if old is not None:                    # an earlier plugin copy's buttons: rebuild with this one
            win.removeToolBar(old)
            old.deleteLater()
        tb = QToolBar(TITLE, win)
        tb.setObjectName(TOOLBAR_NAME)
        from qgis.PyQt import sip
        key = sip.unwrapinstance(win)          # the window's address, never the window (_run_for_key)
        buttons = [
            ("vfPagePictureAdd", "Picture on this page…",
             "Add an image that prints ONLY on the page you are looking at (atlas preview on).", _on_add),
            ("vfPagePicturePin", "Only on this page",
             "Make the selected picture(s) print only on the page you are looking at.", _on_pin),
            ("vfPagePictureList", "Page pictures…", "See, find and remove the pictures pinned to pages.",
             _on_list)]
        try:
            from .atlas_sets_dialog import switched_off
            if not switched_off():                 # Atlas Page Sets (plan step 4); off switch hides it
                buttons.append(("vfAtlasPageSets", "Pages…",
                                "HLD Network Atlas: add page sets (e.g. Underground) with their own layers "
                                "and labels, printed after the Network pages.", _on_page_sets))
        except Exception as e:
            print("Pages… button skipped:", e)
        try:                                       # F4: the designer's own Export cannot be hooked
            from qgis.core import QgsProject, Qgis
            from .atlas_sets_qgis import export_block
            block = export_block(QgsProject.instance(), layout)
            if block and hasattr(designer, "messageBar"):
                designer.messageBar().pushMessage("Page sets", block, level=Qgis.MessageLevel.Warning, duration=0)
        except Exception as e:
            print("Page sets check skipped:", e)
        for name, text, tip, slot in buttons:
            act = QAction(text, win)
            act.setObjectName(name)
            act.setToolTip(tip)
            act.triggered.connect(lambda *_a, k=key, f=slot: _run_for_key(k, f))
            tb.addAction(act)
        win.addToolBar(Qt.ToolBarArea.TopToolBarArea, tb)
    except Exception as e:
        print("Page pictures buttons skipped:", e)


class DesignerHook:
    """Connects to iface.layoutDesignerOpened and also serves designers already open."""

    def __init__(self, iface):
        self.iface = iface
        self._connected = False

    def install(self):
        if self._connected:
            return
        try:
            self.iface.layoutDesignerOpened.connect(add_designer_buttons)
            self._connected = True
            for d in self.iface.openLayoutDesigners() or []:
                add_designer_buttons(d)
        except Exception as e:
            print("Page pictures hook skipped:", e)

    def uninstall(self):
        if not self._connected:
            return
        try:
            from qgis.PyQt import sip
            if not sip.isdeleted(self.iface.mainWindow()):
                self.iface.layoutDesignerOpened.disconnect(add_designer_buttons)
        except Exception as e:
            print("Page pictures unhook:", e)
        self._connected = False


def _dialog_base():
    from qgis.PyQt.QtWidgets import QDialog
    return QDialog


class PagePicturesDialog(_dialog_base()):
    """Every pinned picture of this window's layout: its page and file; go to it or remove it."""

    def __init__(self, win):
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtWidgets import QHBoxLayout, QLabel, QListWidget, QPushButton, QVBoxLayout
        super().__init__(win)
        self.win = win
        self.setWindowTitle(TITLE)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self.setMinimumWidth(480)
        v = QVBoxLayout(self)
        v.addWidget(QLabel("Each picture prints only on its page. Move or resize it in the layout as usual."))
        self.list = QListWidget()
        v.addWidget(self.list, 1)
        b = QHBoxLayout()
        self.b_go = QPushButton("Go to page")
        self.b_rm = QPushButton("Remove picture")
        b_close = QPushButton("Close")
        for w in (self.b_go, self.b_rm, b_close):
            b.addWidget(w)
        v.addLayout(b)
        self.b_go.clicked.connect(lambda _c=False: self._go())
        self.b_rm.clicked.connect(lambda _c=False: self._remove())
        b_close.clicked.connect(lambda _c=False: self.close())
        self._fill()

    def _fill(self):
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtWidgets import QListWidgetItem
        self.list.clear()
        layout = _layout_for_window(self.win)
        if layout is None:
            return
        for s in specs(layout):
            key = s.get("key") or {}
            ok = is_atlas(layout) and page_exists(layout, key)
            it = QListWidgetItem("%s  -  %s%s%s" % (key.get("label", "?"), os.path.basename(s.get("path") or ""),
                                                   "" if ok else "   (page no longer in the book)",
                                                   "" if os.path.isfile(s.get("path") or "")
                                                   else "   (image file missing)"))
            it.setData(Qt.ItemDataRole.UserRole, s.get("id"))
            it.setData(Qt.ItemDataRole.UserRole + 1, json.dumps(key))
            self.list.addItem(it)
        has = self.list.count() > 0
        self.b_go.setEnabled(has)
        self.b_rm.setEnabled(has)

    def _go(self):
        from qgis.PyQt.QtCore import Qt
        it = self.list.currentItem()
        layout = _layout_for_window(self.win)
        if it is None or layout is None:
            return
        key = json.loads(it.data(Qt.ItemDataRole.UserRole + 1) or "{}")
        at = layout.atlas()
        for i in range(at.count()):
            at.seekTo(i)
            if show_expression(layout, key) and _shown_here(layout, key):
                break
        layout.refresh()

    def _remove(self):
        from qgis.PyQt.QtCore import Qt
        it = self.list.currentItem()
        layout = _layout_for_window(self.win)
        if it is None or layout is None:
            return
        remove(layout, it.data(Qt.ItemDataRole.UserRole))
        self._fill()


def _shown_here(layout, key):
    """True when the atlas page shown now is the page `key` names."""
    from qgis.core import QgsExpression, QgsExpressionContextUtils
    expr = show_expression(layout, key)
    if not expr:
        return False
    ctx = layout.createExpressionContext()
    try:
        ctx.appendScope(QgsExpressionContextUtils.atlasScope(layout.atlas()))
    except Exception:
        pass
    return bool(QgsExpression(expr).evaluate(ctx))
