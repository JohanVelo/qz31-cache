<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="4.2.0" styleCategories="Symbology|Labeling" labelsEnabled="1">
  <renderer-v2 referencescale="-1" forceraster="0" enableorderby="0" type="categorizedSymbol" symbollevels="0" attr="PON">
        <categories>
          <category value="PON 01" type="string" label="PON 01" uuid="{4ba6b024-6d79-4caf-8ae3-a05176bc82c3}" symbol="0" render="true" />
          <category value="PON 02" type="string" label="PON 02" uuid="{dffbba82-1efe-4c17-bd79-cd3059a92fd5}" symbol="1" render="true" />
          <category value="PON 03" type="string" label="PON 03" uuid="{75ee50e3-8604-49a7-8c05-4969428e2610}" symbol="2" render="true" />
          <category value="PON 04" type="string" label="PON 04" uuid="{ac4c8088-af55-4b80-b831-008b6ed61891}" symbol="3" render="true" />
          <category value="PON 05" type="string" label="PON 05" uuid="{6b140e2f-6e18-4d0e-88f8-9aa3a93b13ff}" symbol="4" render="true" />
          <category value="PON 06" type="string" label="PON 06" uuid="{483103e6-4692-4374-9e51-82464cd19de0}" symbol="5" render="true" />
          <category value="PON 07" type="string" label="PON 07" uuid="{afb5e9f8-e252-4c19-b4b1-a79d70e2d25c}" symbol="6" render="true" />
          <category value="PON 08" type="string" label="PON 08" uuid="{1a26eeb3-a8ee-4499-ac9f-6f602bacb9a0}" symbol="7" render="true" />
          <category value="PON 09" type="string" label="PON 09" uuid="{14073c1f-6948-4af8-b3d2-b409284e9d1e}" symbol="8" render="true" />
          <category value="PON 10" type="string" label="PON 10" uuid="{027826a1-b524-4c0b-8a5a-3e0274892a65}" symbol="9" render="true" />
          <category value="PON 11" type="string" label="PON 11" uuid="{a2f83606-c3c1-4940-a8f6-d7d5267d5e58}" symbol="10" render="true" />
          <category value="PON 12" type="string" label="PON 12" uuid="{ba3635b3-4eb3-4e7b-8bb0-6d8dace8e783}" symbol="11" render="true" />
          <category value="PON 13" type="string" label="PON 13" uuid="{e6c5e101-58a9-4019-9234-881e1f7f4e20}" symbol="12" render="true" />
          <category value="PON 14" type="string" label="PON 14" uuid="{bf951f13-15b4-4c1f-92e2-5df190abbd69}" symbol="13" render="true" />
          <category value="PON 15" type="string" label="PON 15" uuid="{e602b048-1398-469b-91a7-03f8aa826c95}" symbol="14" render="true" />
          <category value="PON 16" type="string" label="PON 16" uuid="{b7e7b440-5c30-47f5-b171-11cda4a0ee7d}" symbol="15" render="true" />
          <category value="PON 17" type="string" label="PON 17" uuid="{d83cf06e-aa47-4241-852b-a67bf4d4bca4}" symbol="16" render="true" />
          <category value="PON 18" type="string" label="PON 18" uuid="{c5ffbdf7-ac1d-4736-8ea1-45ccfca4d93d}" symbol="17" render="true" />
          <category value="PON 19" type="string" label="PON 19" uuid="{32d06bd7-7c35-4806-833a-83b1619e7b94}" symbol="18" render="true" />
          <category value="PON 20" type="string" label="PON 20" uuid="{675c91f2-c641-4d26-acb1-5ffdaba2ee10}" symbol="19" render="true" />
          <category value="PON 21" type="string" label="PON 21" uuid="{70605d11-e9eb-452d-bcec-1362286db7f2}" symbol="20" render="true" />
          <category value="PON 22" type="string" label="PON 22" uuid="{f8d9a7f9-4528-49fe-989b-aa9a9cf32a7c}" symbol="21" render="true" />
          <category value="PON 23" type="string" label="PON 23" uuid="{1e3c4298-f65f-4f82-9c97-2e69265f72ee}" symbol="22" render="true" />
          <category value="PON 24" type="string" label="PON 24" uuid="{d873656a-f588-488e-834b-897c73f3e7c0}" symbol="23" render="true" />
          <category value="PON 25" type="string" label="PON 25" uuid="{c33a6257-67b0-47fb-9266-332dcee05880}" symbol="24" render="true" />
          <category value="PON 26" type="string" label="PON 26" uuid="{55ea893d-21d6-41e9-b691-090fd06b0455}" symbol="25" render="true" />
          <category value="PON 27" type="string" label="PON 27" uuid="{45cfb357-b37e-415e-a3d3-199862628a04}" symbol="26" render="true" />
          <category value="PON 28" type="string" label="PON 28" uuid="{d9ba4abf-0c05-4593-b9e1-fb39d2ba1c18}" symbol="27" render="true" />
          <category value="PON 29" type="string" label="PON 29" uuid="{30587653-75ef-4b29-9f2e-e12659b018c6}" symbol="28" render="true" />
          <category value="PON 30" type="string" label="PON 30" uuid="{b14a7064-3216-4150-b0b4-530d7a0f585b}" symbol="29" render="true" />
          <category value="PON 31" type="string" label="PON 31" uuid="{ec9dbd0b-60c7-46b1-b29a-9b23a3b59635}" symbol="30" render="true" />
          <category value="PON 32" type="string" label="PON 32" uuid="{d60adaea-28ea-4b6b-ac9c-6353c20f68f7}" symbol="31" render="true" />
          <category value="PON 33" type="string" label="PON 33" uuid="{528cefa8-ebd5-4be9-93c1-71fdf48e153f}" symbol="32" render="true" />
          <category value="PON 34" type="string" label="PON 34" uuid="{bb2dc81d-bddc-42ca-aaea-337597e7927a}" symbol="33" render="true" />
          <category value="PON 35" type="string" label="PON 35" uuid="{09bc5b86-46b7-4dc6-9c19-5d6c54a0711d}" symbol="34" render="true" />
          <category value="PON 36" type="string" label="PON 36" uuid="{a41f1fa2-e3a4-47be-9233-afff31a6afb4}" symbol="35" render="true" />
          <category value="PON 37" type="string" label="PON 37" uuid="{900f2360-5922-4e3a-b070-12a58a8c4db1}" symbol="36" render="true" />
          <category value="PON 38" type="string" label="PON 38" uuid="{026e06d5-070d-4578-96ff-979ab593082f}" symbol="37" render="true" />
          <category value="PON 39" type="string" label="PON 39" uuid="{ff334ecd-a8ed-4938-8b77-8ebd5dc0fe02}" symbol="38" render="true" />
          <category value="PON 40" type="string" label="PON 40" uuid="{edcdc3aa-6ab2-4042-ba89-805cb5520330}" symbol="39" render="true" />
          <category value="PON 41" type="string" label="PON 41" uuid="{872007c9-aa76-4e44-acb7-5275e4091f1d}" symbol="40" render="true" />
          <category value="PON 42" type="string" label="PON 42" uuid="{1e49e22c-096e-4ed0-84ed-be53345437fa}" symbol="41" render="true" />
          <category value="PON 43" type="string" label="PON 43" uuid="{1c4195ea-a77c-483d-a989-abcd13765b8f}" symbol="42" render="true" />
          <category value="PON 44" type="string" label="PON 44" uuid="{d3c52aec-ae51-4f59-88d5-cc1b5669d0ec}" symbol="43" render="true" />
          <category value="PON 45" type="string" label="PON 45" uuid="{a06fde4a-2c95-4873-82ae-4b16ae625258}" symbol="44" render="true" />
          <category value="PON 46" type="string" label="PON 46" uuid="{89b92b4c-43be-41d9-86a6-d1321800cb50}" symbol="45" render="true" />
          <category value="PON 47" type="string" label="PON 47" uuid="{fd254fff-e399-4439-91ec-f1afab7c3b92}" symbol="46" render="true" />
          <category value="PON 48" type="string" label="PON 48" uuid="{5584306c-c4d5-4a48-9985-b71e36a2bcd2}" symbol="47" render="true" />
          <category value="PON 49" type="string" label="PON 49" uuid="{c7a09719-6853-4f23-920a-b1b06b132e73}" symbol="48" render="true" />
          <category value="PON 50" type="string" label="PON 50" uuid="{3400b52d-5c94-4bad-b3c3-316401f6c444}" symbol="49" render="true" />
          <category value="PON 51" type="string" label="PON 51" uuid="{1bd732d6-f1df-4f81-82de-cee4f048bf4f}" symbol="50" render="true" />
          <category value="PON 52" type="string" label="PON 52" uuid="{dfabedd9-bc4c-4cb5-b46e-c3c41db2610a}" symbol="51" render="true" />
          <category value="PON 53" type="string" label="PON 53" uuid="{7c51b6b6-c129-429e-8f41-653fc244086f}" symbol="52" render="true" />
          <category value="PON 54" type="string" label="PON 54" uuid="{86e10bd0-0690-4d67-bf4b-717f3046728e}" symbol="53" render="true" />
          <category value="PON 55" type="string" label="PON 55" uuid="{31a70cfa-e134-4d81-8b57-51a0e770b39e}" symbol="54" render="true" />
          <category value="PON 56" type="string" label="PON 56" uuid="{943d38b0-1107-4929-b3ef-6b6e3cc0534f}" symbol="55" render="true" />
          <category value="PON 57" type="string" label="PON 57" uuid="{e7d5bb56-619f-4183-8534-e1284e505716}" symbol="56" render="true" />
          <category value="PON 58" type="string" label="PON 58" uuid="{ccb01b8f-2a56-405b-8690-482db8062e32}" symbol="57" render="true" />
          <category value="PON 59" type="string" label="PON 59" uuid="{9ea842d5-2493-4f90-9d09-f9f5c31614fa}" symbol="58" render="true" />
          <category value="PON 60" type="string" label="PON 60" uuid="{774e29a5-b951-493d-8f8f-0c210b66bc06}" symbol="59" render="true" />
          <category value="PON 61" type="string" label="PON 61" uuid="{2a9b3a78-8c56-4b67-b315-d01c0ff9ef4d}" symbol="60" render="true" />
          <category value="PON 62" type="string" label="PON 62" uuid="{371f5a30-56d5-43b8-b073-3e879c0ac8cd}" symbol="61" render="true" />
          <category value="PON 63" type="string" label="PON 63" uuid="{3e21e68d-2c94-4e0d-a5f7-b2eed9da1b14}" symbol="62" render="true" />
          <category value="PON 64" type="string" label="PON 64" uuid="{66d4632e-7350-4a26-852c-e826e1ae665c}" symbol="63" render="true" />
          <category value="PON 65" type="string" label="PON 65" uuid="{442f2447-56a4-4670-90c6-c78e31456f32}" symbol="64" render="true" />
          <category value="PON 66" type="string" label="PON 66" uuid="{e79be2d6-5d24-4a97-a4cb-13d276663a10}" symbol="65" render="true" />
          <category value="PON 67" type="string" label="PON 67" uuid="{269af280-24b8-44a7-aa2f-4f1dda2ccff7}" symbol="66" render="true" />
          <category value="PON 68" type="string" label="PON 68" uuid="{3659e487-e6ac-4b6a-a3f8-3c00535207ce}" symbol="67" render="true" />
          <category value="" type="string" label="" uuid="{5cdcec5d-1626-540a-834b-d4753843a0c5}" symbol="68" render="true" />
    </categories>
        <symbols>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="0" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{917d7219-4ba7-421f-a7af-76a11c5af409}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="210,54,93,255,hsv:0.95833333333333337,0.74509803921568629,0.82352941176470584,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="1" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{941da3cc-80d9-43d7-b41e-0733840938d1}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="50,89,208,255,hsv:0.625,0.76078431372549016,0.81568627450980391,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="10" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{f3d23586-712d-4a75-a2bd-4764d4c08e0c}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="202,64,87,255,hsv:0.97222222222222221,0.68235294117647061,0.792156862745098,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="11" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{7bfd5416-1c34-454b-ac2a-6b4f8948714a}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="175,240,23,255,hsv:0.21666666666666667,0.90588235294117647,0.94117647058823528,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="12" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{f878f6e7-7458-46dd-996a-6bb3ead11389}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="134,74,206,255,hsv:0.7416666666666667,0.63921568627450975,0.80784313725490198,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="13" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{3e1bc343-a998-476b-802a-8b047c7eb670}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="41,216,149,255,hsv:0.43611111111111112,0.81176470588235294,0.84705882352941175,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="14" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{13a4ed43-321e-49e5-9cfb-bd2358560cd4}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="47,126,237,255,hsv:0.59722222222222221,0.80000000000000004,0.92941176470588238,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="15" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{c98644dc-79e3-4a4c-9dca-dbaf68211459}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="163,117,203,255,hsv:0.75555555555555554,0.42352941176470588,0.79607843137254897,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="16" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{d1b525c4-a7a4-4bf6-a3e3-1bf81479efa2}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="16,205,70,255,hsv:0.38055555555555554,0.92156862745098034,0.80392156862745101,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="17" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{eba388d4-10fb-4136-97fd-3957b276b4af}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="219,60,73,255,hsv:0.98611111111111116,0.72549019607843135,0.85882352941176465,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="18" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{cd6987b8-5ece-4895-b692-ec9a6800fedb}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="238,131,49,255,hsv:0.07222222222222222,0.79607843137254897,0.93333333333333335,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="19" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{29c38113-2b59-4903-91d3-408dc3db1c84}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="225,171,84,255,hsv:0.10277777777777777,0.62745098039215685,0.88235294117647056,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="2" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{fe7f3696-c36b-4fe2-bf9e-8fe89c6b5321}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="238,50,147,255,hsv:0.91388888888888886,0.78823529411764703,0.93333333333333335,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="20" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{d8b319a5-f051-48eb-ade6-ce1cbe03b2cc}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="207,201,89,255,hsv:0.15833333333333333,0.56862745098039214,0.81176470588235294,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="21" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{ef31a9b8-296f-49f0-aa35-44e149b2f33b}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="41,199,227,255,hsv:0.52500000000000002,0.81960784313725488,0.8901960784313725,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="22" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{260829ea-c4d2-4d1b-bc55-fc47e8353b9e}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="196,58,234,255,hsv:0.79722222222222228,0.75294117647058822,0.91764705882352937,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="23" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{900c33a8-bb3b-43b9-a2be-a10ab73cfe3e}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="208,101,62,255,hsv:0.04444444444444445,0.70196078431372544,0.81568627450980391,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="24" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{e717efda-92df-491e-9583-4c8cd5b30487}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="97,227,223,255,hsv:0.49444444444444446,0.5725490196078431,0.8901960784313725,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="25" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{bd343113-d1fb-4d8b-bd80-e34bf8e43533}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="24,234,27,255,hsv:0.33611111111111114,0.89803921568627454,0.91764705882352937,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="26" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{68d85649-3213-495a-961e-ffacab7e4e09}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="240,37,176,255,hsv:0.88611111111111107,0.84705882352941175,0.94117647058823528,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="27" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{a793571c-ed26-496f-a792-e87d203f4af6}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="220,228,59,255,hsv:0.17499999999999999,0.74117647058823533,0.89411764705882357,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="28" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{60f08131-9873-446e-8deb-e39d55ebb7bd}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="69,237,217,255,hsv:0.48055555555555557,0.70980392156862748,0.92941176470588238,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="29" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{ea57d298-c051-405e-a6a3-517e5c0ba4d0}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="130,159,219,255,hsv:0.61111111111111116,0.40784313725490196,0.85882352941176465,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="3" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{e5bc1443-a76e-4f78-9de3-57b114dc9c73}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="208,187,113,255,hsv:0.13055555555555556,0.45882352941176469,0.81568627450980391,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="30" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{aa99fe3b-52c1-4c95-8ac1-d4f2ebb486fe}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="62,46,200,255,hsv:0.68333333333333335,0.7686274509803922,0.78431372549019607,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="31" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{186ecea9-829a-4bd3-988c-9507b6d21dae}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="51,66,226,255,hsv:0.65277777777777779,0.77254901960784317,0.88627450980392153,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="32" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{9343ad63-9f53-4c3d-999d-276fa23f258e}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="105,207,238,255,hsv:0.53888888888888886,0.5607843137254902,0.93333333333333335,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="33" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{ece14d16-a337-4252-bd38-766092db782a}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="147,218,32,255,hsv:0.23055555555555557,0.85098039215686272,0.85490196078431369,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="34" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{188d2cb7-1f87-439f-a906-d8d2ada0aa97}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="183,13,205,255,hsv:0.81388888888888888,0.93725490196078431,0.80392156862745101,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="35" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{4c7e50a1-d7d4-4406-a43d-91838ae8bdfa}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="111,203,65,255,hsv:0.27777777777777779,0.67843137254901964,0.79607843137254897,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="36" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{d0d18064-e858-4935-b2bf-c9feccdd9ac6}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="230,100,71,255,hsv:0.03055555555555555,0.69019607843137254,0.90196078431372551,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="37" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{62d9d44e-8991-4101-87cc-ef06afd99460}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="115,54,227,255,hsv:0.72499999999999998,0.76078431372549016,0.8901960784313725,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="38" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{85f46273-8a18-461f-9d85-665579943e09}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="159,24,217,255,hsv:0.78333333333333333,0.8901960784313725,0.85098039215686272,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="39" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{3be923e9-1fec-4989-bc81-3db2affae314}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="30,222,184,255,hsv:0.46666666666666667,0.8666666666666667,0.87058823529411766,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="4" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{09a1c9a3-a995-4178-aed8-b055985d761c}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="181,200,54,255,hsv:0.18888888888888888,0.72941176470588232,0.78431372549019607,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="40" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{d4660da2-fcc4-4df3-9592-92bb143f6d3d}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="171,227,132,255,hsv:0.2638888888888889,0.41960784313725491,0.8901960784313725,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="41" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{1736d843-52bc-419b-b6c3-1c5307e71b23}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="222,168,110,255,hsv:0.08611111111111111,0.50588235294117645,0.87058823529411766,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="42" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{793d5a8c-4ec4-4f5a-9d0b-d416d04c2bcd}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="70,219,40,255,hsv:0.30555555555555558,0.81568627450980391,0.85882352941176465,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="43" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{8abee0c6-777b-408f-8414-698668741c52}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="115,114,216,255,hsv:0.6694444444444444,0.47450980392156861,0.84705882352941175,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="44" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{f1f806f6-1a17-4cc0-9547-9de3cc46a3ec}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="231,82,146,255,hsv:0.92777777777777781,0.6470588235294118,0.90588235294117647,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="45" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{3d67dd78-d746-4905-b03e-6b342926f3ce}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="234,109,228,255,hsv:0.84166666666666667,0.53333333333333333,0.91764705882352937,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="46" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{9808bdeb-9304-49a9-8c3b-60d53d0ab4c2}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="131,219,147,255,hsv:0.36388888888888887,0.40000000000000002,0.85882352941176465,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="47" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{598e9b09-3dad-455d-bc1c-f4c22f7a6dfc}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="218,87,166,255,hsv:0.90000000000000002,0.59999999999999998,0.85490196078431369,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="48" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{7e7fab0e-6745-438f-afab-a29bc8285d7a}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="62,198,205,255,hsv:0.5083333333333333,0.69803921568627447,0.80392156862745101,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="49" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{2ca9e418-193f-4bc5-ad90-5f3776907703}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="53,208,42,255,hsv:0.32222222222222224,0.79607843137254897,0.81568627450980391,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="5" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{8d125451-49c7-40e9-ac22-254d97af156a}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="42,224,60,255,hsv:0.34999999999999998,0.81176470588235294,0.8784313725490196,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="50" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{c0d13063-70bd-42dc-84ea-927926847aa6}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="230,103,147,255,hsv:0.94166666666666665,0.55294117647058827,0.90196078431372551,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="51" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{725f29c4-f123-4b7a-a7a8-4b873403ec67}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="56,83,218,255,hsv:0.63888888888888884,0.74117647058823533,0.85490196078431369,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="52" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{5c3b3e81-a486-45fd-a6c7-40873839f4bf}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="126,217,167,255,hsv:0.40833333333333333,0.41960784313725491,0.85098039215686272,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="53" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{de48cc23-150c-4e46-a8de-84520511b863}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="203,29,14,255,hsv:0.01388888888888889,0.93333333333333335,0.79607843137254897,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="54" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{abbda256-0065-4095-937b-179b9dd8950d}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="138,17,213,255,hsv:0.76944444444444449,0.92156862745098034,0.83529411764705885,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="55" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{e2403a0b-4af0-4d97-b664-cdf3cd9f87e2}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="136,206,239,255,hsv:0.55277777777777781,0.43137254901960786,0.93725490196078431,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="56" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{3ddf1beb-0ab6-416d-bf29-2f581cfc75f6}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="236,48,211,255,hsv:0.85555555555555551,0.79607843137254897,0.92549019607843142,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="57" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{3821f372-3f2c-49ab-ace8-437d2495054f}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="239,221,105,255,hsv:0.14444444444444443,0.5607843137254902,0.93725490196078431,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="58" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{5d9e688e-565a-4f17-8241-85653372fd1e}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="228,179,65,255,hsv:0.11666666666666667,0.71372549019607845,0.89411764705882357,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="59" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{a7648a23-86e5-48ca-857a-0a6c0d2f6782}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="238,76,203,255,hsv:0.86944444444444446,0.68235294117647061,0.93333333333333335,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="6" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{1829b915-4621-4f1c-9db0-204c1a1f3f3b}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="35,150,227,255,hsv:0.56666666666666665,0.84705882352941175,0.8901960784313725,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="60" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{d3af9ea8-b6f3-4651-8058-757e65f3cd50}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="71,39,214,255,hsv:0.69722222222222219,0.81568627450980391,0.83921568627450982,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="61" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{cd64ae8a-a873-446a-aa8f-9e53d13de5cf}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="139,223,50,255,hsv:0.24722222222222223,0.77647058823529413,0.87450980392156863,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="62" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{40b75d8b-0633-489b-a0e5-37793add2aa8}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="70,227,128,255,hsv:0.39444444444444443,0.69019607843137254,0.8901960784313725,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="63" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{b3513acc-7321-46ad-9b2a-e5bd25fea613}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="79,240,194,255,hsv:0.45277777777777778,0.6705882352941176,0.94117647058823528,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="64" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{fd85ad5c-957a-4011-bff4-9e36f5ec3edd}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="134,183,229,255,hsv:0.5805555555555556,0.41568627450980394,0.89803921568627454,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="65" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{e094530d-46c7-42d9-994f-454ec17a1d99}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="91,46,215,255,hsv:0.71111111111111114,0.78431372549019607,0.84313725490196079,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="66" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{fa518e1b-9ce9-4aaa-9fc0-e57311361508}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="219,48,48,255,hsv:0,0.7803921568627451,0.85882352941176465,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="67" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{a1fe5951-f8ff-47cf-b2b5-30b1b5143f96}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="120,229,84,255,hsv:0.29166666666666669,0.63529411764705879,0.89803921568627454,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="7" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{dcb5619f-3de9-47b9-b7b7-e0da7e3f3b35}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="224,58,230,255,hsv:0.82777777777777772,0.74901960784313726,0.90196078431372551,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="8" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{9561d37f-2968-445a-b0c6-6e45f94b2d54}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="41,212,132,255,hsv:0.42222222222222222,0.80784313725490198,0.83137254901960789,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="9" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{14ad6293-1ea2-4c2b-bc3e-e5828627ea9b}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="220,164,134,255,hsv:0.05833333333333333,0.39215686274509803,0.86274509803921573,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="68" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{4aa60e42-be0a-4eb8-ba0c-299053b2c76e}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="141,90,153,255,rgb:0.5529412,0.3529412,0.6,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
    </symbols>
        <source-symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="0" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{4aa60e42-be0a-4eb8-ba0c-299053b2c76e}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="141,90,153,255,rgb:0.5529412,0.3529412,0.6,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </source-symbol>
        <rotation />
        <sizescale />
        <data-defined-properties>
          <Option type="Map">
            <Option type="QString" value="" name="name" />
            <Option name="properties" />
            <Option type="QString" value="collection" name="type" />
          </Option>
        </data-defined-properties>
      </renderer-v2>
  <labeling type="simple">
        <settings calloutType="simple">
          <text-style fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWordSpacing="0" textColor="50,50,50,255,rgb:0.1960784,0.1960784,0.1960784,1" fontKerning="1" fontUnderline="0" useSubstitutions="0" multilineHeight="1" allowHtml="0" capitalization="0" blendMode="0" fieldName="PON" multilineHeightUnit="Percentage" tabStopDistance="80" textOrientation="horizontal" fontSize="10" textOpacity="1" namedStyle="Bold" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" fontFamily="Open Sans" fontLetterSpacing="0" stretchFactor="100" fontWeight="75" legendString="Aa" forcedItalic="0" forcedBold="0" fontItalic="0" tabStopDistanceUnit="Point" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" isExpression="0" fontStrikeout="0">
            <families />
            <text-buffer bufferSize="1" bufferNoFill="1" bufferColor="250,250,250,255,rgb:0.9803922,0.9803922,0.9803922,1" bufferBlendMode="0" bufferDraw="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferOpacity="1" />
            <text-mask maskSize="1.5" maskedSymbolLayers="" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskJoinStyle="128" maskSize2="1.5" maskType="0" maskOpacity="1" maskEnabled="1" />
            <background shapeRadiiY="0" shapeRadiiUnit="Point" shapeBlendMode="0" shapeSizeType="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeRotationType="0" shapeSizeX="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeBorderWidth="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRotation="0" shapeOffsetX="0" shapeBorderWidthUnit="Point" shapeDraw="0" shapeOffsetUnit="Point" shapeSizeUnit="Point" shapeOpacity="1" shapeOffsetY="0" shapeSizeY="0" shapeSVGFile="" shapeType="0">
              <symbol frame_rate="10" is_animated="0" force_rhr="0" type="marker" name="markerSymbol" alpha="1" clip_to_extent="1">
                <data_defined_properties>
                  <Option type="Map">
                    <Option type="QString" value="" name="name" />
                    <Option name="properties" />
                    <Option type="QString" value="collection" name="type" />
                  </Option>
                </data_defined_properties>
                <layer locked="0" class="SimpleMarker" pass="0" id="" enabled="1">
                  <Option type="Map">
                    <Option type="QString" value="0" name="angle" />
                    <Option type="QString" value="square" name="cap_style" />
                    <Option type="QString" value="196,60,57,255,rgb:0.7686275,0.2352941,0.2235294,1" name="color" />
                    <Option type="QString" value="1" name="horizontal_anchor_point" />
                    <Option type="QString" value="bevel" name="joinstyle" />
                    <Option type="QString" value="circle" name="name" />
                    <Option type="QString" value="0,0" name="offset" />
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                    <Option type="QString" value="MM" name="offset_unit" />
                    <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                    <Option type="QString" value="solid" name="outline_style" />
                    <Option type="QString" value="0" name="outline_width" />
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" />
                    <Option type="QString" value="MM" name="outline_width_unit" />
                    <Option type="QString" value="diameter" name="scale_method" />
                    <Option type="QString" value="2" name="size" />
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale" />
                    <Option type="QString" value="MM" name="size_unit" />
                    <Option type="QString" value="1" name="vertical_anchor_point" />
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name" />
                      <Option name="properties" />
                      <Option type="QString" value="collection" name="type" />
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="fillSymbol" alpha="1" clip_to_extent="1">
                <data_defined_properties>
                  <Option type="Map">
                    <Option type="QString" value="" name="name" />
                    <Option name="properties" />
                    <Option type="QString" value="collection" name="type" />
                  </Option>
                </data_defined_properties>
                <layer locked="0" class="SimpleFill" pass="0" id="" enabled="1">
                  <Option type="Map">
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                    <Option type="QString" value="255,255,255,255,rgb:1,1,1,1" name="color" />
                    <Option type="QString" value="bevel" name="joinstyle" />
                    <Option type="QString" value="0,0" name="offset" />
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                    <Option type="QString" value="MM" name="offset_unit" />
                    <Option type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" name="outline_color" />
                    <Option type="QString" value="no" name="outline_style" />
                    <Option type="QString" value="0" name="outline_width" />
                    <Option type="QString" value="Point" name="outline_width_unit" />
                    <Option type="QString" value="solid" name="style" />
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name" />
                      <Option name="properties" />
                      <Option type="QString" value="collection" name="type" />
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowScale="100" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowRadius="1.5" shadowOffsetGlobal="1" shadowDraw="0" shadowBlendMode="6" shadowOffsetDist="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusAlphaOnly="0" shadowUnder="0" shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" />
            <dd_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </dd_properties>
            <substitutions />
          </text-style>
          <text-format useMaxLineLengthForAutoWrap="1" leftDirectionSymbol="&lt;" placeDirectionSymbol="0" wrapChar="" plussign="0" multilineAlign="3" reverseDirectionSymbol="0" autoWrapLength="0" addDirectionSymbol="0" rightDirectionSymbol="&gt;" formatNumbers="0" decimals="3" />
          <placement predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" maximumDistanceUnit="MM" centroidWhole="0" rotationAngle="0" rotationUnit="AngleDegrees" geometryGenerator="" lineAnchorTextPoint="FollowPlacement" lineAnchorClipping="0" yOffset="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" quadOffset="4" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overlapHandling="PreventOverlap" centroidInside="0" dist="0" distUnits="MM" overrunDistance="0" prioritization="PreferCloser" polygonPlacementFlags="2" geometryGeneratorEnabled="0" distMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" placement="0" layerType="PolygonGeometry" priority="5" offsetUnits="MM" xOffset="0" repeatDistanceUnits="MM" lineAnchorType="0" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" fitInPolygonOnly="0" overrunDistanceUnit="MM" placementFlags="10" preserveRotation="1" maximumDistance="0" offsetType="0" maxCurvedCharAngleIn="25" repeatDistance="0" />
          <rendering minFeatureSize="0" scaleMax="0" mergeLines="0" unplacedVisibility="0" labelPerPart="0" fontMinPixelSize="3" drawLabels="1" fontLimitPixelSize="0" scaleMin="0" zIndex="0" fontMaxPixelSize="10000" scaleVisibility="0" obstacleFactor="1" upsidedownLabels="0" maxNumLabels="2000" obstacleType="1" limitNumLabels="0" obstacle="1" />
          <dd_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name" />
              <Option name="properties" />
              <Option type="QString" value="collection" name="type" />
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint" />
              <Option type="int" value="0" name="blendMode" />
              <Option type="Map" name="ddProperties">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
              <Option type="bool" value="false" name="drawToAllParts" />
              <Option type="QString" value="0" name="enabled" />
              <Option type="QString" value="point_on_exterior" name="labelAnchorPoint" />
              <Option type="QString" value="&lt;symbol frame_rate=&quot;10&quot; is_animated=&quot;0&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; name=&quot;symbol&quot; alpha=&quot;1&quot; clip_to_extent=&quot;1&quot;&gt;&lt;data_defined_properties&gt;&lt;Option type=&quot;Map&quot;&gt;&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/&gt;&lt;Option name=&quot;properties&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/&gt;&lt;/Option&gt;&lt;/data_defined_properties&gt;&lt;layer locked=&quot;0&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; id=&quot;{e4afc581-b761-45a5-8709-fdbee64fe0c8}&quot; enabled=&quot;1&quot;&gt;&lt;Option type=&quot;Map&quot;&gt;&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot; name=&quot;line_color&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/&gt;&lt;/Option&gt;&lt;data_defined_properties&gt;&lt;Option type=&quot;Map&quot;&gt;&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/&gt;&lt;Option name=&quot;properties&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/&gt;&lt;/Option&gt;&lt;/data_defined_properties&gt;&lt;/layer&gt;&lt;/symbol&gt;" name="lineSymbol" />
              <Option type="double" value="0" name="minLength" />
              <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" />
              <Option type="QString" value="MM" name="minLengthUnit" />
              <Option type="double" value="0" name="offsetFromAnchor" />
              <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" />
              <Option type="QString" value="MM" name="offsetFromAnchorUnit" />
              <Option type="double" value="0" name="offsetFromLabel" />
              <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" />
              <Option type="QString" value="MM" name="offsetFromLabelUnit" />
            </Option>
          </callout>
        </settings>
      </labeling>
</qgis>
