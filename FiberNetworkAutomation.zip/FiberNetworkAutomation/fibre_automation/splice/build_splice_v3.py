#!/usr/bin/env python3
"""
MOA Phase 2 Splice Plan - v4
Matches LAW/ETW example format exactly:
  - LAW colours: #FF6699 headers, #96DCF8/#B4E5A2 hop alternation, #FBDEED FTS, #F2CEEF POP port
  - 5 columns per hop: Fibre IN | Cable ID | Spliced Joint | Spliced Joint | Fibre Out
  - Feeder sheet: row 1 blank, row 2 headers (LAW style)
  - Per-PON sheets named by OLT port: C15P11, C16P01 … C19P10
"""
import json
import re
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

# ── Load Data ────────────────────────────────────────────────────────────────
DATA = json.loads(Path('C:/Temp/splice_data.json').read_text())
fts_list       = DATA['fts']
sts_list       = DATA['sts']
agg_domes      = DATA['agg_domes']
dis_domes      = DATA['dis_domes']
primary        = DATA['primary']
secondary      = DATA['secondary']
distribution   = DATA['distribution']
drops          = DATA['drops']
pon_ont_counts = DATA['pon_ont_counts']

OUTPUT_PATH = 'C:/Users/jjsch/OneDrive/ON LAPTOP FIBRE/QGIS test/MOA_Splice_Plan_v9.xlsx'
OLT_OFFSETS = {15: 224, 16: 240, 17: 256, 18: 272, 19: 288}

# Manual STS->distribution-cable overrides (manually-added STS tapped onto a 24F that
# runs through them, so they have no cable-endpoint match for auto-assignment).
STS_DIST_OVERRIDE = {
    'MOA.STS.16.DIS.DM.P.G620.C16P03.L15': 'MOA.DF.24F.P.H011-P.F744',  # G620 taps the 24F running through it (AGG H011 -> F744)
}

# ── Parsers ──────────────────────────────────────────────────────────────────
def parse_olt(olt_port):
    m = re.match(r'C(\d+)P(\d+)', olt_port or '')
    if not m:
        return None
    card, port = int(m.group(1)), int(m.group(2))
    return {'card': card, 'port': port, 'pon': OLT_OFFSETS.get(card, 0) + port}

def parse_fts(label):
    m = re.match(r'(MOA\.FTS\.\d+\.AGG\.DM\.P\.\w+)-OLT\.01\.(C\d+P\d+)', label or '')
    if not m:
        return None
    fts_base, olt = m.group(1), m.group(2)
    agg_dome = re.sub(r'FTS\.\d+\.', '', fts_base)
    o = parse_olt(olt)
    if not o:
        return None
    return {'label': label, 'agg_dome': agg_dome, 'olt_port': olt,
            'card': o['card'], 'port': o['port'], 'pon': o['pon']}

def parse_sts(label):
    m = re.match(r'(MOA\.STS\.\d+\.DIS\.DM\.P\.\w+)\.(C\d+P\d+)\.L(\d+)', label or '')
    if not m:
        return None
    sts_base, olt, leg = m.group(1), m.group(2), int(m.group(3))
    dis_dome = re.sub(r'STS\.\d+\.', '', sts_base)
    o = parse_olt(olt)
    return {'label': label, 'dis_dome': dis_dome, 'olt_port': olt,
            'leg': leg, 'pon': o['pon'] if o else None}

def extract_dr(endfeat):
    m = re.search(r'DR\d+', endfeat or '')
    return m.group(0) if m else ''

def pon_to_zone(pon):
    return (pon - 235) // 16 + 17

# ── Build Lookups ─────────────────────────────────────────────────────────────
agg_by_label  = {d['label_1']: d for d in agg_domes if d.get('label_1')}
dis_by_label  = {d['label_1']: d for d in dis_domes  if d.get('label_1')}

fts_by_pon = {}
for f in fts_list:
    lbl = f.get('label') or f.get('label_1') or ''
    p = parse_fts(lbl)
    if p:
        p.update({k: f.get(k) for k in ('strtfeat', 'lat', 'lon', 'zone_no')})
        fts_by_pon[p['pon']] = p

sts_by_pon = {}
for s in sts_list:
    lbl = s.get('label') or s.get('label_1') or ''
    p = parse_sts(lbl)
    if p:
        sts_by_pon.setdefault(p['pon'], []).append(p)
for pon in sts_by_pon:
    sts_by_pon[pon].sort(key=lambda x: x['leg'])

drops_by_dis = {}
for dr in drops:
    key = dr.get('strtfeat') or ''
    if key:
        drops_by_dis.setdefault(key, []).append(dr)
for key in drops_by_dis:
    drops_by_dis[key].sort(
        key=lambda x: int(re.search(r'\d+', x.get('label', '0')).group(0))
        if re.search(r'\d+', x.get('label', '0')) else 0
    )

dist_by_pon = {}
for dc in distribution:
    pn = str(dc.get('pon_no') or '')
    if pn and pn != 'None':
        dist_by_pon.setdefault(pn, []).append(dc)
for pn in dist_by_pon:
    dist_by_pon[pn].sort(key=lambda c: c.get('label', ''))

prim_by_pon = {}
for c in primary:
    pn = str(c.get('pon_no') or '')
    if pn and pn != 'None':
        prim_by_pon.setdefault(pn, []).append(c)

sec_by_pon = {}
for c in secondary:
    pn = str(c.get('pon_no') or '')
    if pn and pn != 'None':
        sec_by_pon.setdefault(pn, []).append(c)

all_pons = sorted(fts_by_pon.keys())

# ── Fibre assignment: sequential per primary cable ────────────────────────────
prim_fiber_map = {}
prim_cable_map = {}
cable_fiber_ctr = {}
for pon in all_pons:
    pon_str = str(pon)
    cables = prim_by_pon.get(pon_str, [])
    lbl = cables[0].get('label', f'PRIMARY-Z{pon_to_zone(pon)}') if cables else f'PRIMARY-Z{pon_to_zone(pon)}'
    cable_fiber_ctr.setdefault(lbl, 0)
    cable_fiber_ctr[lbl] += 1
    prim_fiber_map[pon] = f"F{cable_fiber_ctr[lbl]}"
    prim_cable_map[pon] = cables[0].get('label', '') if cables else ''

# ── Load fts→cable map (from QGIS vertex analysis) ───────────────────────────
_FTS_CABLE_MAP = {}
_fts_cable_path = Path('C:/Temp/fts_cable_map.json')
if _fts_cable_path.exists():
    _FTS_CABLE_MAP = json.loads(_fts_cable_path.read_text())

# cable label → cable dict lookup
_cable_by_label = {c.get('label',''): c for c in primary + secondary if c.get('label')}

# endfeat → cable (for chaining past the direct match)
_endfeat_to_feeder = {}
for _c in primary + secondary:
    _ef = _c.get('endfeat', '')
    if _ef:
        _endfeat_to_feeder.setdefault(_ef, []).append(_c)

POP_POLE = 'MOA.P.G997'
POP_LABEL = 'OLT.01 (POP)'

def _joint_at_pole(pole):
    if pole == POP_POLE:
        return POP_LABEL
    return next((a['label_1'] for a in agg_domes if a.get('strtfeat') == pole), pole)

# ── Feeder hops: use vertex-based FTS→cable map, then trace back ─────────────
def feeder_hops(pon, fts):
    """
    Uses the pre-computed fts_cable_map (from QGIS vertex analysis) to identify
    which cable the FTS sits on (mid-span or endpoint), then traces back to POP.
    Returns list of (fibre_in, cable_id, joint_entry, joint_exit, fibre_out).
    """
    fiber    = prim_fiber_map[pon]
    fts_pole = fts.get('strtfeat', '')

    # Look up which cable passes through this FTS pole.
    # strtfeat may be the POP/OLT pole (G997) which is never in the map;
    # fall back to the AGG dome pole extracted from the agg_dome label.
    hit = _FTS_CABLE_MAP.get(fts_pole)
    if not hit:
        agg_dome_lbl = fts.get('agg_dome', '')
        # MOA.AGG.DM.P.H110 → MOA.P.H110
        agg_pole = re.sub(r'AGG\.DM\.', '', agg_dome_lbl)
        hit = _FTS_CABLE_MAP.get(agg_pole)
        if hit:
            fts_pole = agg_pole
        else:
            return []

    cable_lbl = hit.get('cable', '')
    method    = hit.get('method', '')

    # The splice at the FTS AGG dome
    fts_joint = fts['agg_dome']

    hops = []

    # If found via endfeat: this cable terminates AT the FTS → one direct hop
    # If found via vertex: this cable passes THROUGH the FTS → same, one hop
    # In both cases, we show: [cable from its strtfeat pole → FTS]
    cable = _cable_by_label.get(cable_lbl)
    if cable:
        strt_pole   = cable.get('strtfeat', '')
        joint_start = _joint_at_pole(strt_pole) if strt_pole else strt_pole
        hops.insert(0, (fiber, cable_lbl, joint_start, fts_joint, fiber))

        # Now trace backwards from strt_pole to find the next upstream cable
        current = strt_pole
        visited = {fts_pole, current}
        while current and len(hops) < 4:
            upstream_cables = _endfeat_to_feeder.get(current, [])
            if not upstream_cables:
                break
            up_cable = upstream_cables[0]
            up_lbl   = up_cable.get('label', '')
            up_strt  = up_cable.get('strtfeat', '')
            if up_strt in visited:
                break
            visited.add(up_strt)
            j_start = _joint_at_pole(up_strt) if up_strt else up_strt
            j_end   = _joint_at_pole(current)
            hops.insert(0, (fiber, up_lbl, j_start, j_end, fiber))
            current = up_strt

    return hops

# ── Distribution assignment ───────────────────────────────────────────────────
def dist_assignment(pon, fts, sts_list_pon):
    pon_str  = str(pon)
    agg_info = agg_by_label.get(fts['agg_dome'])
    agg_pole = agg_info['strtfeat'] if agg_info else ''

    dist_cables       = dist_by_pon.get(pon_str, [])
    endfeat_to_cable  = {c.get('endfeat', ''): c for c in dist_cables if c.get('endfeat')}
    cable_fiber_ctr2  = {}

    by_label_dist = {c.get('label', ''): c for c in dist_cables}
    result = []
    for sts in sts_list_pon:
        dis_info  = dis_by_label.get(sts['dis_dome'])
        dis_pole  = dis_info['strtfeat'] if dis_info else ''
        cable     = endfeat_to_cable.get(dis_pole)
        hop2_cable = hop2_pole = hop2_joint = ''

        # Manual routing overrides (STS tapped onto a 24F that runs THROUGH it,
        # so it has no cable-endpoint match — pin the actual cable explicitly).
        ov = STS_DIST_OVERRIDE.get(sts.get('label', ''))
        if ov and ov in by_label_dist:
            cable = by_label_dist[ov]

        if not cable and dist_cables:
            idx   = len(result) // 24
            cable = dist_cables[min(idx, len(dist_cables) - 1)]

        cable_lbl  = cable.get('label', '') if cable else ''
        strt_pole  = cable.get('strtfeat', '') if cable else agg_pole

        cable_fiber_ctr2.setdefault(cable_lbl, 0)
        cable_fiber_ctr2[cable_lbl] += 1
        fiber = f"F{cable_fiber_ctr2[cable_lbl]}"

        hop1_joint = sts['dis_dome']

        result.append({
            'sts'        : sts,
            'cable_lbl'  : cable_lbl,
            'strt_pole'  : strt_pole,
            'hop1_joint' : hop1_joint,
            'fiber'      : fiber,
            'hop2_cable' : hop2_cable,
            'hop2_pole'  : hop2_pole,
            'hop2_joint' : hop2_joint,
        })
    return result

# ── Style helpers ─────────────────────────────────────────────────────────────
THIN   = Side(style='thin')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

def fill(hex_):
    return PatternFill(fill_type='solid', fgColor=hex_)

# LAW/ETW exact colours
F_PINK    = fill('FF6699')   # header row
F_LAVEND  = fill('F2CEEF')   # POP Port data cells
F_BLUE    = fill('96DCF8')   # odd hops  (1, 3, 5)
F_GREEN   = fill('B4E5A2')   # even hops (2, 4, 6)
F_BLUSH   = fill('FBDEED')   # FTS Splitter columns
F_WHITE   = fill('FFFFFF')
F_SPARE   = fill('F2F2F2')

def _apply(cell, value='', bg=None, bold=False, sz=9, color='000000',
           halign='center', valign='center', wrap=False):
    cell.value = value
    cell.font  = Font(bold=bold, color=color, size=sz)
    cell.alignment = Alignment(horizontal=halign, vertical=valign, wrap_text=wrap)
    cell.border = BORDER
    if bg:
        cell.fill = bg

def hdr(cell, text, bg=F_PINK, sz=9):
    _apply(cell, text, bg=bg, bold=True, sz=sz, color='000000',
           halign='center', wrap=True)

def dat(cell, value='', bg=None, halign='left', sz=9):
    _apply(cell, value, bg=bg or F_WHITE, bold=False, sz=sz,
           color='000000', halign=halign)

# ── Feeder layout constants ───────────────────────────────────────────────────
MAX_HOPS    = 4   # max feeder hops to document (blank if fewer)
COLS_PER_HOP = 5  # Fibre IN | Cable ID | Spliced Joint | Spliced Joint | Fibre Out
FTS_COLS    = 3   # merged columns for FTS Splitter

def hop_fill(hop_idx):
    return F_BLUE if hop_idx % 2 == 0 else F_GREEN

# Feeder column layout:
#  col 1: blank
#  col 2: POP Port (lavender)
#  cols 3 .. 3+MAX_HOPS*5-1: hops (blue/green alternating)
#  last 3 cols: FTS Splitter (blush)
COL_BLANK   = 1
COL_POP     = 2
COL_HOP_START = 3
COL_FTS_START = COL_HOP_START + MAX_HOPS * COLS_PER_HOP
TOTAL_COLS    = COL_FTS_START + FTS_COLS - 1

HOP_SUBHDRS = ['Fibre IN', 'Cable ID', 'Spliced Joint', 'Spliced Joint', 'Fibre Out']

# ── Zone / card summary data ──────────────────────────────────────────────────
from collections import defaultdict
_zone_ont   = defaultdict(int)
_zone_pons  = defaultdict(list)
for _pon_str, _cnt in pon_ont_counts.items():
    _pon  = int(_pon_str)
    _zone = pon_to_zone(_pon)
    _zone_ont[_zone]  += int(_cnt)
    _zone_pons[_zone].append(_pon)

_card_pons = defaultdict(list)
for _pon in all_pons:
    _f = fts_by_pon[_pon]
    _card_pons[_f['card']].append(_pon)

# ── Workbook ──────────────────────────────────────────────────────────────────
wb = Workbook()

# ═══════════════════════════════════════════════════════════════════════════════
# Sheet 0 — Cover / Project Summary
# ═══════════════════════════════════════════════════════════════════════════════
ws_cov = wb.active
ws_cov.title = 'Cover'

def _cov_title(ws, row, text, sz=14, bold=True, merge_to=6):
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=merge_to)
    c = ws.cell(row, 1)
    c.value = text
    c.font  = Font(bold=bold, size=sz, color='000000')
    c.alignment = Alignment(horizontal='center', vertical='center')
    c.fill  = F_PINK
    c.border = BORDER
    ws.row_dimensions[row].height = 28 if sz >= 14 else 20

def _cov_row(ws, row, label, value, label_col=1, val_col=3, merge_val_to=6):
    # label merged across A:B so long labels (e.g. "DIS Domes (STS connect)") don't
    # clip in the narrow column A (A is shared with the narrow Zone column below).
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=2)
    for cc in (1, 2):
        b = ws.cell(row, cc)
        b.fill = fill('F2F2F2')
        b.border = BORDER
    c = ws.cell(row, label_col)
    c.value = label
    c.font  = Font(bold=True, size=9)
    c.alignment = Alignment(horizontal='right', vertical='center')
    ws.merge_cells(start_row=row, start_column=val_col, end_row=row, end_column=merge_val_to)
    for cc in range(val_col, merge_val_to + 1):
        b = ws.cell(row, cc)
        b.fill = F_WHITE
        b.border = BORDER
    v = ws.cell(row, val_col)
    v.value = value
    v.font  = Font(size=9)
    v.alignment = Alignment(horizontal='left', vertical='center')
    ws.row_dimensions[row].height = 16

from datetime import date
_today = date.today().strftime('%Y-%m-%d')
_total_onts = sum(_zone_ont.values())
_min_pon    = min(all_pons)
_max_pon    = max(all_pons)

r = 1
_cov_title(ws_cov, r, 'Potch – Mohadin Phase 2 | Splice Plan', sz=14); r += 1
_cov_title(ws_cov, r, 'MOA | JB Marks Local Municipality', sz=11, bold=False); r += 1
r += 1  # spacer
_cov_row(ws_cov, r, 'Project Code', 'MOA'); r += 1
_cov_row(ws_cov, r, 'Municipality', 'JB Marks Local Municipality'); r += 1
_cov_row(ws_cov, r, 'Generated', _today); r += 1
_cov_row(ws_cov, r, 'OLT', 'Nokia Lightspan FX — OLT.01'); r += 1
_first_port = fts_by_pon[all_pons[0]]['olt_port']
_last_port  = fts_by_pon[all_pons[-1]]['olt_port']
_cov_row(ws_cov, r, 'OLT Port Range', f'{_first_port} – {_last_port}'); r += 1
_cov_row(ws_cov, r, 'PON Range', f'{_min_pon} – {_max_pon}  ({len(all_pons)} PONs)'); r += 1
_cov_row(ws_cov, r, 'Total ONTs', f'{_total_onts:,}'); r += 1
_cov_row(ws_cov, r, 'AGG Domes (FTS splice)', f'{len(agg_domes)}  ×  Dome AGG'); r += 1
_cov_row(ws_cov, r, 'DIS Domes (STS connect)', f'{len(dis_domes)}  ×  Dome DIS'); r += 1
_cov_row(ws_cov, r, 'Splice Loss Target', '≤ 0.10 dB fusion (workmanship)  |  ≤ 0.30 dB max  |  ≤ 0.50 dB connector  |  ORL ≥ 26 dB'); r += 1
_cov_row(ws_cov, r, 'Acceptance Standards', 'ANSI/TIA-568.3-D  ·  ISO/IEC 14763-3:2024 Ed 3.0 (bi-directional OTDR)  ·  colour TIA-598-C'); r += 1
r += 1  # spacer

# Optical loss budget — worst-case POP → ONT (cascaded 1:8 + 1:16 design)
_cov_title(ws_cov, r, 'Optical Loss Budget — worst-case POP → ONT  (Combo 1: 1×1:8 FTS + 1:16 STS)', sz=10); r += 1
for _lbl, _val in [
    ('1:8 FTS splitter insertion (PLC)',        '10.5 dB'),
    ('1:16 STS splitter insertion (PLC)',       '13.5 dB'),
    ('Cascaded splitters (1:8 → 1:16)',         '24.0 dB   (vs 1:128 direct 27 dB → saves 3 dB)'),
    ('Connectors  (3 × 0.30 dB)',               '0.9 dB'),
    ('Fusion splices  (4 × 0.10 dB)',           '0.4 dB'),
    ('Fibre attenuation  (≤ ~1.5 km × 0.35 dB/km @1310)', '≤ ~0.5 dB'),
    ('TOTAL worst-case path loss',              '≈ 25.8 dB'),
    ('GPON Class B+ (28 dB)',                   'margin ≈ 2.2 dB   →  MARGINAL  (tight headroom)'),
    ('GPON Class C+ (32 dB)',                   'margin ≈ 6.2 dB   →  PASS'),
    ('Splitter loss source',                    'PLC typical (FS.com) · ITU-T G.984.2 · per-PON value live in Splice Viewer'),
]:
    _cov_row(ws_cov, r, _lbl, _val); r += 1
r += 1  # spacer

# Zone summary table
_cov_title(ws_cov, r, 'Zone Summary', sz=10); r += 1
for ci, hd in enumerate(['Zone', 'PON Range', 'PON Count', 'ONT Count', 'OLT Cards', ''], 1):
    c = ws_cov.cell(r, ci)
    c.value = hd; c.font = Font(bold=True, size=9); c.fill = F_PINK
    c.border = BORDER; c.alignment = Alignment(horizontal='center', vertical='center')
ws_cov.row_dimensions[r].height = 18; r += 1
for _z in sorted(_zone_ont.keys()):
    _pons = sorted(_zone_pons[_z])
    _cards = sorted({fts_by_pon[p]['card'] for p in _pons if p in fts_by_pon})
    _note  = '  ⚠ outside spec range (235-298)' if _z > 20 else ''
    _is_extra = _z > 20
    for ci, v in enumerate([_z, f'{_pons[0]}–{_pons[-1]}', len(_pons), f'{_zone_ont[_z]:,}', 'C' + '+C'.join(str(c) for c in _cards), _note], 1):
        c = ws_cov.cell(r, ci)
        c.value = v; c.font = Font(size=9, color='CC0000' if _is_extra else '000000')
        c.fill  = fill('FFF2CC') if _is_extra else F_WHITE
        c.border = BORDER
        c.alignment = Alignment(horizontal='center' if ci < 5 else 'left', vertical='center')
    ws_cov.row_dimensions[r].height = 15; r += 1

# Zone totals row
_spec_pons   = [p for p in all_pons if 235 <= p <= 298]
_spec_onts   = sum(int(pon_ont_counts.get(str(p), 0)) for p in _spec_pons)
_extra_onts  = _total_onts - _spec_onts
for ci, v in enumerate(['TOTAL', '235–298 (spec)', f'{len(_spec_pons)} + {len(all_pons)-len(_spec_pons)} extra',
                         f'{_spec_onts:,} + {_extra_onts} extra', '', ''], 1):
    c = ws_cov.cell(r, ci)
    c.value = v; c.font = Font(bold=True, size=9)
    c.fill  = fill('F2F2F2'); c.border = BORDER
    c.alignment = Alignment(horizontal='center' if ci < 5 else 'left', vertical='center')
ws_cov.row_dimensions[r].height = 15; r += 1

r += 1  # spacer

# OLT card summary table
_cov_title(ws_cov, r, 'OLT Card Summary', sz=10); r += 1
for ci, hd in enumerate(['Card', 'Port Range', 'PON Range', 'PON Count', 'Zones', ''], 1):
    c = ws_cov.cell(r, ci)
    c.value = hd; c.font = Font(bold=True, size=9); c.fill = F_PINK
    c.border = BORDER; c.alignment = Alignment(horizontal='center', vertical='center')
ws_cov.row_dimensions[r].height = 18; r += 1
for _card in sorted(_card_pons.keys()):
    _cp = sorted(_card_pons[_card])
    _ports = sorted({fts_by_pon[p]['port'] for p in _cp})
    _zones = sorted({pon_to_zone(p) for p in _cp})
    for ci, v in enumerate([f'C{_card}', f'P{_ports[0]}–P{_ports[-1]}', f'{min(_cp)}–{max(_cp)}', len(_cp), '+'.join(f'Z{z}' for z in _zones), ''], 1):
        c = ws_cov.cell(r, ci)
        c.value = v; c.font = Font(size=9)
        c.fill  = F_WHITE; c.border = BORDER
        c.alignment = Alignment(horizontal='center', vertical='center')
    ws_cov.row_dimensions[r].height = 15; r += 1

r += 1  # spacer

# ── Data Exceptions (computed from current data) ─────────────────────────────
_sts_domes = set()
for _s in sts_list:
    _m = re.match(r'(MOA\.STS\.\d+\.DIS\.DM\.P\.\w+)\.C\d+P\d+\.L\d+', _s.get('label', '') or '')
    if _m:
        _sts_domes.add(re.sub(r'STS\.\d+\.', '', _m.group(1)))
_ont_set = set(DATA.get('ont_labels', []))
def _drn(s):
    _mm = re.search(r'DR\d+', s or ''); return _mm.group(0) if _mm else None
_uns = defaultdict(lambda: [0, set()]); _dangling = []; _lblne = 0
for _dr in drops:
    _dome = _dr.get('strtfeat')
    if _dome and _dome not in _sts_domes:
        _uns[_dome][0] += 1
        if _dr.get('pon_no'):
            _uns[_dome][1].add(str(_dr['pon_no']))
    _e = _drn(_dr.get('endfeat'))
    if _e and ('MOA.ONT.' + _e) not in _ont_set:
        _dangling.append(_e)
    if _dr.get('label') and _e and _dr['label'] != _e:
        _lblne += 1
# NOTE: the old "feeder joint is a POLE" check was a FALSE POSITIVE. It assumed
# each PON has its own feeder cable terminating at its AGG dome. In reality the
# primary trunk -> secondary feeders split off it -> an FTS sits ON a (shared)
# secondary (mid-span or tapped at a pole) -> distribution -> STS. The feeder
# "joint" landing on a pole is correct design, not a defect. Check removed.
_no_sts = {d: v for d, v in _uns.items() if re.search(r'\.DIS\.DM\.', d)}
_pole   = {d: v for d, v in _uns.items() if re.match(r'MOA\.P\.\w+$', d)}
_tot_uns = sum(v[0] for v in _uns.values())
_placed  = _total_onts - _tot_uns
def _fmt(dct):
    return ',  '.join(f"{re.sub(r'.*\.P\.', '', d)} x{v[0]} (PON {'/'.join(sorted(v[1]))})"
                      for d, v in sorted(dct.items(), key=lambda x: -x[1][0]))

_cov_title(ws_cov, r, 'Data Exceptions — review (plan logic is correct; all items are upstream layer-data issues)', sz=10); r += 1
_exc_rows = [
    ('ONT reconciliation',
     f'{_total_onts:,} ONTs (demand)  ->  {_placed:,} actually spliced on the per-PON sheets. '
     f'{_tot_uns} homes cannot be spliced (their DIS dome has no STS splitter) — listed below.'),
    ('Unserved — dome has NO STS', _fmt(_no_sts) + f'   = {sum(v[0] for v in _no_sts.values())} homes'),
    ('Unserved — strtfeat is a POLE', _fmt(_pole) + f'   = {sum(v[0] for v in _pole.values())} homes'),
    (f'{len(set(_dangling))} DR numbers with no ONT', ',  '.join(sorted(set(_dangling))) + '  — drop endfeat points to a non-existent ONT'),
    (f'~{_lblne:,} drops — label != ONT', 'Drop-cable label is off-by-one vs its ONT. Cosmetic only: the plan keys off the ONT (endfeat). Re-sync the Drop layer labels.'),
]
for _lbl, _val in _exc_rows:
    _cov_row(ws_cov, r, _lbl, _val)
    ws_cov.cell(r, 3).alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
    ws_cov.row_dimensions[r].height = 28
    r += 1

for ci, w in enumerate([10, 18, 14, 12, 16, 40], 1):
    ws_cov.column_dimensions[get_column_letter(ci)].width = w

# ═══════════════════════════════════════════════════════════════════════════════
# Sheet 1 — Port Allocations (no colour, thin borders only, plain)
# ═══════════════════════════════════════════════════════════════════════════════
ws_pa = wb.create_sheet('Port Allocations')

PA_HDRS = ['OLT', 'Line Card', 'Port', 'Fiber', 'Cable (Primary)', 'PON', 'Zone', 'Units', 'Fill %']
for ci, h in enumerate(PA_HDRS, 1):
    c = ws_pa.cell(1, ci)
    c.value = h
    c.font  = Font(bold=True, size=9)
    c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    c.border = BORDER
ws_pa.row_dimensions[1].height = 28

for ri, pon in enumerate(all_pons, 2):
    fts     = fts_by_pon[pon]
    pon_str = str(pon)
    units   = int(pon_ont_counts.get(pon_str, 0))
    fill_pct = round(units / 128 * 100, 1)
    row     = [
        'OLT.01',
        fts['card'],
        fts['port'],
        prim_fiber_map[pon],
        prim_cable_map[pon],
        pon,
        pon_to_zone(pon),
        units,
        f'{fill_pct}%',
    ]
    _is_extra = pon > 298
    _row_bg   = fill('FFF2CC') if _is_extra else F_WHITE
    # Fill % colour: red <60%, amber 60-79%, green 80-100%
    _pct_bg   = fill('FFD7D7') if fill_pct < 60 else (fill('FFE7AA') if fill_pct < 80 else fill('C6EFCE'))
    for ci, v in enumerate(row, 1):
        c = ws_pa.cell(ri, ci)
        c.value = v
        c.font  = Font(size=9, color='CC0000' if _is_extra else '000000')
        c.fill  = _pct_bg if ci == 9 else _row_bg
        c.border = BORDER
        c.alignment = Alignment(horizontal='left', vertical='center')

ws_pa.row_dimensions[1].height = 28
for ci, w in enumerate([8, 10, 6, 6, 52, 6, 6, 8, 6], 1):
    ws_pa.column_dimensions[get_column_letter(ci)].width = w
ws_pa.freeze_panes = 'A2'

# ═══════════════════════════════════════════════════════════════════════════════
# Sheet 2 — Feeder  (LAW style: row 1 blank, row 2 headers, row 3+ data)
# ═══════════════════════════════════════════════════════════════════════════════
ws_f = wb.create_sheet('Feeder')

# Row 1: blank (just height)
ws_f.row_dimensions[1].height = 6

# Row 2: headers
ws_f.row_dimensions[2].height = 30

# Col 1: blank header
hdr(ws_f.cell(2, COL_BLANK), '', bg=F_WHITE)

# Col 2: POP Port header (pink like all headers)
hdr(ws_f.cell(2, COL_POP), 'POP Port')

# Hop headers (alternating blue/green)
for h in range(MAX_HOPS):
    hf = hop_fill(h)
    col_start = COL_HOP_START + h * COLS_PER_HOP
    for s, sub in enumerate(HOP_SUBHDRS):
        hdr(ws_f.cell(2, col_start + s), sub, bg=hf)

# FTS Splitter header (blush) — merge 3 cols
ws_f.merge_cells(
    start_row=2, start_column=COL_FTS_START,
    end_row=2,   end_column=COL_FTS_START + FTS_COLS - 1
)
hdr(ws_f.cell(2, COL_FTS_START), 'FTS Splitter', bg=F_BLUSH)

# Data rows (row 3+)
for ri, pon in enumerate(all_pons, 3):
    fts   = fts_by_pon[pon]
    hops  = feeder_hops(pon, fts)
    fiber = prim_fiber_map[pon]
    pop   = fts['olt_port']   # e.g. C15P11

    # Col 1: blank
    dat(ws_f.cell(ri, COL_BLANK), '')

    # Col 2: POP Port (lavender)
    dat(ws_f.cell(ri, COL_POP), pop, bg=F_LAVEND, halign='center')

    # Hop data
    for h in range(MAX_HOPS):
        hf        = hop_fill(h)
        col_start = COL_HOP_START + h * COLS_PER_HOP
        if h < len(hops):
            fi, cbl, j_in, j_out, fo = hops[h]
            vals = [fi, cbl, j_in, j_out, fo]
        else:
            vals = ['', '', '', '', '']
        for s, v in enumerate(vals):
            dat(ws_f.cell(ri, col_start + s), v, bg=hf)

    # FTS Splitter (blush, 3 cols — first has value, rest blank but same fill)
    dat(ws_f.cell(ri, COL_FTS_START),     fts['agg_dome'], bg=F_BLUSH)
    dat(ws_f.cell(ri, COL_FTS_START + 1), fts['label'],    bg=F_BLUSH)
    dat(ws_f.cell(ri, COL_FTS_START + 2), f"PON_{pon}",    bg=F_BLUSH)

# Column widths for Feeder
ws_f.column_dimensions[get_column_letter(COL_BLANK)].width = 2
ws_f.column_dimensions[get_column_letter(COL_POP)].width   = 12
for h in range(MAX_HOPS):
    col_start = COL_HOP_START + h * COLS_PER_HOP
    # Fibre IN / Fibre Out: narrow; Cable ID / Joints: wide
    for s, w in enumerate([8, 44, 42, 42, 8]):
        ws_f.column_dimensions[get_column_letter(col_start + s)].width = w
for fc in range(FTS_COLS):
    ws_f.column_dimensions[get_column_letter(COL_FTS_START + fc)].width = 36
ws_f.freeze_panes = 'C3'

# ═══════════════════════════════════════════════════════════════════════════════
# Per-PON sheets (one per OLT port: C15P11, C16P01 … C19P10)
# ═══════════════════════════════════════════════════════════════════════════════
DIST_HDRS = [
    '1:8 Splitter',        # A — FTS label
    'Splitter Leg',        # B — FTS output leg (= STS leg)
    'Fibre IN',            # C — fibre entering dist cable
    'Distribution Cable',  # D — cable ID
    'Spliced Joint',       # E — entry face (AGG dome or intermediate)
    'Spliced Joint',       # F — exit face (DIS dome)
    'Fibre Out',           # G — fibre at DIS dome
    '1:16 Splitter',       # H — STS label
    'Splitter Leg',        # I — STS port (1-16)
    'DR Number',           # J — connected ONT DR
]
DIST_N = len(DIST_HDRS)  # 10 columns

# Feeder sub-section headers for per-PON sheet
PON_FEEDER_HDRS = [
    'POP Port',
    'Fibre IN', 'Cable ID', 'Spliced Joint', 'Spliced Joint', 'Fibre Out',
    'Fibre IN', 'Cable ID', 'Spliced Joint', 'Spliced Joint', 'Fibre Out',
    'Fibre IN', 'Cable ID', 'Spliced Joint', 'Spliced Joint', 'Fibre Out',
    'FTS Splitter',
]
PON_FEEDER_N = len(PON_FEEDER_HDRS)  # 17

STS_PORTS = 16

def pon_loss(pon, fts):
    """Worst-case POP→ONT optical loss (dB) + margin vs GPON Class B+ (28 dB).
    1:8 FTS 10.5 + 1:16 STS 13.5 + 3×0.30 connectors + 4×0.10 splices + fibre."""
    hops = feeder_hops(pon, fts)
    feeder_m = sum(float((_cable_by_label.get(h[1]) or {}).get('dim2') or 0) for h in hops)
    dist_m = max([float(c.get('dim2') or 0) for c in dist_by_pon.get(str(pon), [])] or [0.0])
    drop_m = max([float(d.get('dim2') or 0) for d in drops if str(d.get('pon_no')) == str(pon)] or [0.0])
    fibre_km = (feeder_m + dist_m + drop_m) / 1000.0
    loss = 10.5 + 13.5 + 3 * 0.30 + 4 * 0.10 + fibre_km * 0.35
    margin = 28.0 - loss
    status = 'PASS' if margin >= 3 else ('MARGINAL' if margin >= 1 else 'FAIL')
    return loss, margin, status

for pon in all_pons:
    fts     = fts_by_pon[pon]
    pon_str = str(pon)
    # Sheet name = OLT port (C15P11 etc) — unique, fits in 31 chars
    sheet_name = fts['olt_port']
    ws = wb.create_sheet(sheet_name)

    # Use the wider of DIST_N / PON_FEEDER_N for banner merge
    banner_cols = max(DIST_N, PON_FEEDER_N)

    # ── Row 1: "Feeder Route" banner ─────────────────────────────────────────
    ws.merge_cells(f'A1:{get_column_letter(banner_cols)}1')
    c = ws.cell(1, 1)
    _ploss, _pmargin, _pstat = pon_loss(pon, fts)
    c.value     = (f'Feeder Route — PON {pon}  |  Zone {pon_to_zone(pon)}  |  {fts["olt_port"]}'
                   f'    ·    Optical loss ≈ {_ploss:.1f} dB · margin {_pmargin:.1f} dB (B+ 28 dB) {_pstat}')
    c.fill      = F_PINK
    c.font      = Font(bold=True, color='000000', size=11)
    c.alignment = Alignment(horizontal='center', vertical='center')
    ws.row_dimensions[1].height = 22

    # ── Row 2: Feeder column headers ─────────────────────────────────────────
    ws.row_dimensions[2].height = 26
    hdr(ws.cell(2, 1), 'POP Port')
    # hops: 3 hops × 5 cols each starting at col 2; FTS at col 17
    for h in range(3):
        hf = hop_fill(h)
        base = 2 + h * 5
        for s, sub in enumerate(HOP_SUBHDRS):
            hdr(ws.cell(2, base + s), sub, bg=hf)
    hdr(ws.cell(2, 17), 'FTS Splitter', bg=F_BLUSH)
    for ci in range(18, banner_cols + 1):
        hdr(ws.cell(2, ci), '', bg=F_PINK)

    # ── Row 3: Feeder data ───────────────────────────────────────────────────
    hops  = feeder_hops(pon, fts)
    fiber = prim_fiber_map[pon]
    ws.row_dimensions[3].height = 18

    dat(ws.cell(3, 1), fts['olt_port'], bg=F_LAVEND, halign='center')
    for h in range(3):
        hf   = hop_fill(h)
        base = 2 + h * 5
        if h < len(hops):
            fi, cbl, j_in, j_out, fo = hops[h]
            vals = [fi, cbl, j_in, j_out, fo]
        else:
            vals = ['', '', '', '', '']
        for s, v in enumerate(vals):
            dat(ws.cell(3, base + s), v, bg=hf)
    dat(ws.cell(3, 17), fts['label'], bg=F_BLUSH)
    for ci in range(18, banner_cols + 1):
        dat(ws.cell(3, ci), '', bg=F_WHITE)

    # ── Row 4: blank separator ───────────────────────────────────────────────
    ws.row_dimensions[4].height = 8

    # ── Row 5: Distribution section banner ───────────────────────────────────
    ws.merge_cells(f'A5:{get_column_letter(DIST_N)}5')
    c = ws.cell(5, 1)
    c.value     = 'Distribution'
    c.fill      = F_PINK
    c.font      = Font(bold=True, color='000000', size=10)
    c.alignment = Alignment(horizontal='center', vertical='center')
    ws.row_dimensions[5].height = 18

    # ── Row 6: Distribution headers ──────────────────────────────────────────
    ws.row_dimensions[6].height = 28
    for ci, h in enumerate(DIST_HDRS, 1):
        hdr(ws.cell(6, ci), h)

    # ── Rows 7+: one row per ONT port ────────────────────────────────────────
    sts_list_pon = sts_by_pon.get(pon, [])
    assignments  = dist_assignment(pon, fts, sts_list_pon)
    cur_row = 7

    for asgn in assignments:
        sts      = asgn['sts']
        dis_lbl  = sts['dis_dome']
        sts_drops = drops_by_dis.get(dis_lbl, [])

        # Alternate row shade per STS block to visually group 16 ports
        leg_idx  = sts['leg'] - 1
        row_fill = F_BLUE if leg_idx % 2 == 0 else F_GREEN

        for port in range(1, STS_PORTS + 1):
            r        = cur_row
            cur_row += 1
            is_spare = (port - 1) >= len(sts_drops)

            dat(ws.cell(r, 1),  fts['label'],       bg=row_fill)   # 1:8 Splitter
            dat(ws.cell(r, 2),  sts['leg'],          bg=row_fill)   # Splitter Leg (FTS leg)
            dat(ws.cell(r, 3),  asgn['fiber'],       bg=row_fill)   # Fibre IN
            dat(ws.cell(r, 4),  asgn['cable_lbl'],   bg=row_fill)   # Dist Cable
            dat(ws.cell(r, 5),  fts['agg_dome'],      bg=row_fill)   # Spliced Joint entry = FTS AGG dome
            dat(ws.cell(r, 6),  _joint_at_pole(asgn['hop1_joint']), bg=row_fill)  # Spliced Joint exit
            dat(ws.cell(r, 7),  asgn['fiber'],       bg=row_fill)   # Fibre Out
            dat(ws.cell(r, 8),  sts['label'],        bg=row_fill)   # 1:16 Splitter
            dat(ws.cell(r, 9),  port,                bg=row_fill)   # Splitter Leg / port
            if not is_spare:
                dr_row = sts_drops[port - 1]
                dr     = extract_dr(dr_row.get('endfeat', ''))
                dat(ws.cell(r, 10), dr, bg=row_fill)
            else:
                dat(ws.cell(r, 10), 'SPARE', bg=F_SPARE)

    # Column widths
    col_w = [44, 12, 8, 44, 44, 44, 8, 44, 12, 14]
    for ci, w in enumerate(col_w, 1):
        ws.column_dimensions[get_column_letter(ci)].width = w
    ws.freeze_panes = 'A7'

# ── Polish: hide gridlines on every sheet so empty margins read as a clean ──────
#    document instead of an "unfinished" white grid (removes the right-side gap).
for _ws in wb.worksheets:
    _ws.sheet_view.showGridLines = False

# ── Save ──────────────────────────────────────────────────────────────────────
wb.save(OUTPUT_PATH)
print(f"Saved: {OUTPUT_PATH}")
print(f"Sheets: Port Allocations + Feeder + {len(all_pons)} PON sheets ({min(all_pons)}-{max(all_pons)})")
print(f"STS total: {sum(len(v) for v in sts_by_pon.values())}")
print(f"Sheet names: {', '.join(fts_by_pon[p]['olt_port'] for p in all_pons[:5])} ...")
