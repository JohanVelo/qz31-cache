"""identity — install_id, session_id, and the breadcrumb ring buffer.

Pure Python (no QGIS imports) so it unit-tests standalone. The plugin passes
in a settings-getter/setter so install_id persists in QgsSettings without this
module depending on QGIS.
"""
import time
import uuid
from collections import deque


def new_session_id():
    return str(uuid.uuid4())


def get_or_create_install_id(get, set_):
    """install_id is generated ONCE and persisted forever (survives reinstall/
    upgrade). `get(key)->str|None` and `set_(key, value)` wrap the settings
    store. Returns the stable uuid string."""
    try:
        from . import config
    except ImportError:
        import config
    existing = get(config.KEY_INSTALL_ID)
    if existing:
        return existing
    iid = str(uuid.uuid4())
    set_(config.KEY_INSTALL_ID, iid)
    return iid


class Breadcrumbs:
    """Rolling buffer of the last N user actions in this session. Attached to
    every error so the owner can see exactly what the user was doing."""

    def __init__(self, maxlen=100):
        self._buf = deque(maxlen=maxlen)

    def add(self, action_id, category="tool", message="", version=""):
        self._buf.append({
            "action_id": action_id,
            "category": category,
            "message": message,
            "ts": time.time(),
            "version": version,
        })

    def tail(self, n=20):
        """The last n crumbs, oldest→newest (what the owner reads)."""
        items = list(self._buf)
        return items[-n:] if n else items

    def clear(self):
        self._buf.clear()

    def __len__(self):
        return len(self._buf)
