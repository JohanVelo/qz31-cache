try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

"""basemaps — version-portable XYZ basemap add + self-heal (bundled; native QGIS only).

Why: a project saved on QGIS 4.0 (Qt6) embeds its XYZ tile layers with 4.0-era
datasource cruft (`tilePixelRatio`, empty `format`, mixed `%3A`/`:` encoding). When
a teammate on an OLDER QGIS (3.40/3.44) opens that project, the XYZ provider can't
round-trip the string, so the basemap loads as an INVALID ("bad") layer and the
operator sees "QGIS deleted my basemap". This module heals that: on project open it
finds every invalid XYZ raster and REBUILDS it from a minimal, portable URI that
parses identically on 3.28 → 4.x. Version-agnostic, fail-silent, no timers, no deps.

  from fibre_automation import basemaps
  basemaps.heal_basemaps()          # call on project open — rebuild bad XYZ layers
  basemaps.clean_xyz_uri(src)       # minimal portable datasource for an XYZ url
  basemaps.add_xyz(proj, name, url) # add one basemap the safe/portable way
"""

# Canonical, portable datasources for the basemaps the plugin itself offers.
# Deliberately minimal: only type=xyz + url + zmin/zmax. No tilePixelRatio, no
# empty format=, no pre-encoded crs — every one of those is a cross-version break.
KNOWN_BASEMAPS = {
    "NGI Aerial":
        "https://aerial.openstreetmap.org.za/layer/ngi-aerial/%7Bz%7D/%7Bx%7D/%7By%7D.jpg",
    "Google Satellite":
        "https://mt1.google.com/vt/lyrs%3Ds%26x%3D%7Bx%7D%26y%3D%7By%7D%26z%3D%7Bz%7D",
    "Google Hybrid":
        "https://mt1.google.com/vt/lyrs%3Dy%26x%3D%7Bx%7D%26y%3D%7By%7D%26z%3D%7Bz%7D",
}


def clean_xyz_uri(source_or_url, zmin=0, zmax=20):
    """Return a minimal, version-portable XYZ datasource string.

    Accepts either a bare tile URL or a full existing datasource (from which the
    `url=` is extracted and everything else — tilePixelRatio, format, crs — is
    dropped). Returns None if no usable url is found.
    """
    try:
        s = str(source_or_url or "")
        if not s:
            return None
        url = s
        zmn, zmx = zmin, zmax
        if "url=" in s or "type=xyz" in s.lower() or "type%3dxyz" in s.lower():
            # Full datasource — pull url= / zmin= / zmax= out of the &-separated params.
            parts = s.replace("&amp;", "&").split("&")
            url = None
            for p in parts:
                key, _, val = p.partition("=")
                k = key.strip().lower()
                if k == "url":
                    url = val
                elif k == "zmin" and val.strip().lstrip("-").isdigit():
                    zmn = int(val)
                elif k == "zmax" and val.strip().isdigit():
                    zmx = int(val)
            if not url:
                return None
        return f"type=xyz&url={url}&zmin={zmn}&zmax={zmx}"
    except Exception:
        return None


def _is_xyz_raster(lyr):
    """True if this is an XYZ tile raster (the family that breaks across versions)."""
    try:
        from qgis.core import QgsRasterLayer
        if not isinstance(lyr, QgsRasterLayer):
            return False
        src = (lyr.source() or "").lower()
        return "type=xyz" in src or "type%3dxyz" in src
    except Exception:
        return False


def add_xyz(proj, name, url, zmin=0, zmax=20):
    """Add ONE XYZ basemap the safe/portable way (skip if a same-named layer exists).

    Registers without auto-legend then lets the layer-tree own the node via
    addLayer() (appends at the bottom). Returns the layer, or None on skip/fail.
    """
    try:
        from qgis.core import QgsRasterLayer
        if any(l.name() == name for l in proj.mapLayers().values()):
            return None
        uri = clean_xyz_uri(url, zmin=zmin, zmax=zmax)
        if not uri:
            return None
        lyr = QgsRasterLayer(uri, name, "wms")
        if not lyr.isValid():
            return None
        proj.addMapLayer(lyr, False)
        proj.layerTreeRoot().addLayer(lyr)
        return lyr
    except Exception:
        return None


def heal_basemaps(proj=None):
    """Rebuild every INVALID XYZ basemap in the project from a portable URI.

    Runs on project open. On the machine that saved the project every basemap is
    already valid, so this is a no-op there; on an older QGIS that couldn't parse
    the 4.0-written datasource, the bad layer is swapped for one that loads. The
    layer's tree position + visibility are preserved. Returns count healed.
    """
    healed = 0
    try:
        from qgis.core import QgsProject, QgsRasterLayer, QgsLayerTreeLayer
        proj = proj or QgsProject.instance()
        root = proj.layerTreeRoot()
        for lyr in list(proj.mapLayers().values()):
            try:
                if not _is_xyz_raster(lyr) or lyr.isValid():
                    continue
                uri = clean_xyz_uri(lyr.source())
                # Fall back to a known canonical URL if we recognise the name.
                if uri is None and lyr.name() in KNOWN_BASEMAPS:
                    uri = clean_xyz_uri(KNOWN_BASEMAPS[lyr.name()])
                if uri is None:
                    continue
                fresh = QgsRasterLayer(uri, lyr.name(), "wms")
                if not fresh.isValid():
                    continue
                # Find the bad layer's node so we can drop the rebuilt one in its place.
                old_node = root.findLayer(lyr.id())
                parent = old_node.parent() if old_node is not None else root
                was_visible = old_node.isVisible() if old_node is not None else True
                idx = parent.children().index(old_node) if old_node is not None else -1
                proj.addMapLayer(fresh, False)
                node = QgsLayerTreeLayer(fresh)
                node.setItemVisibilityChecked(was_visible)
                parent.insertChildNode(idx if idx >= 0 else 0, node)
                proj.removeMapLayer(lyr.id())   # drops the old node + the bad layer
                healed += 1
            except Exception:
                _swallowed_note(); continue
    except Exception:
        return healed
    return healed
