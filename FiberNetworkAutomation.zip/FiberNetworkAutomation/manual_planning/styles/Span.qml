<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyDrawingHints="1" symbologyReferenceScale="-1" maxScale="0" hasScaleBasedVisibilityFlag="0" minScale="100000000" simplifyDrawingTol="1" simplifyLocal="1" styleCategories="AllStyleCategories" autoRefreshMode="Disabled" simplifyAlgorithm="0" version="3.44.4-Solothurn" readOnly="0" labelsEnabled="0" autoRefreshTime="0" simplifyMaxScale="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endField="" startExpression="" endExpression="" durationField="id" mode="0" limitMode="0" startField="" enabled="0" fixedDuration="0" durationUnit="min" accumulate="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation zoffset="0" extrusion="0" type="IndividualFeatures" zscale="1" clamping="Terrain" extrusionEnabled="0" binding="Centroid" customToleranceEnabled="1" showMarkerSymbolInSurfacePlots="0" symbology="Line" respectLayerSymbol="1">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol name="" clip_to_extent="1" type="line" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleLine" id="{ee8a9dd3-69e7-4952-aeb9-1f191500b2c9}" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="145,82,45,255,rgb:0.5686275,0.3215686,0.1764706,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol name="" clip_to_extent="1" type="fill" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleFill" id="{1dc3e9ec-9427-4380-bf95-0f883ac4ca13}" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="145,82,45,255,rgb:0.5686275,0.3215686,0.1764706,1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="104,59,32,255,rgb:0.4061494,0.2296788,0.1260395,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol name="" clip_to_extent="1" type="marker" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleMarker" id="{375d6266-1733-4b95-b014-95d0676a1f17}" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="145,82,45,255,rgb:0.5686275,0.3215686,0.1764706,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="diamond"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="104,59,32,255,rgb:0.4061494,0.2296788,0.1260395,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" type="singleSymbol" forceraster="0" referencescale="-1" symbollevels="0">
    <symbols>
      <symbol name="0" clip_to_extent="1" type="line" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleLine" id="{72ba7250-1d27-40bc-abad-b2821eefade4}" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="0,6,255,255,hsv:0.66274999999999995,1,1,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.86"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol name="" clip_to_extent="1" type="line" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleLine" id="{7fc6d4d4-5bd3-4c9d-a81f-51394283bf1c}" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.26"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <customproperties>
    <Option type="Map">
      <Option name="QFieldSync/action" type="QString" value="copy"/>
      <Option name="QFieldSync/attachment_naming" type="QString" value="{}"/>
      <Option name="QFieldSync/attribute_editing_locked_expression" type="invalid"/>
      <Option name="QFieldSync/cloud_action" type="QString" value="offline"/>
      <Option name="QFieldSync/feature_addition_locked_expression" type="invalid"/>
      <Option name="QFieldSync/feature_deletion_locked_expression" type="invalid"/>
      <Option name="QFieldSync/geometry_editing_locked_expression" type="invalid"/>
      <Option name="QFieldSync/photo_naming" type="QString" value="{}"/>
      <Option name="QFieldSync/relationship_maximum_visible" type="QString" value="{}"/>
      <Option name="QFieldSync/tracking_distance_requirement_minimum_meters" type="int" value="30"/>
      <Option name="QFieldSync/tracking_erroneous_distance_safeguard_maximum_meters" type="int" value="1"/>
      <Option name="QFieldSync/tracking_measurement_type" type="int" value="0"/>
      <Option name="QFieldSync/tracking_time_requirement_interval_seconds" type="int" value="30"/>
      <Option name="QFieldSync/value_map_button_interface_threshold" type="int" value="0"/>
      <Option name="embeddedWidgets/count" type="int" value="0"/>
      <Option name="variableNames" type="invalid"/>
      <Option name="variableValues" type="invalid"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field name="label" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="type" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subtyp" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="spec" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim1" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim2" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cblcpty" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="conntr" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ntwrkptn" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cmpownr" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="strtfeat" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="endfeat" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="lat" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="lon" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sg21" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sg26" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="address" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="pon_no" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="zone_no" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subplace" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="mainplce" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="mun" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="stackref" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="datecrtd" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="crtdby" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="date_edt" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="editby" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="comments" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" index="0" field="label"/>
    <alias name="" index="1" field="type"/>
    <alias name="" index="2" field="subtyp"/>
    <alias name="" index="3" field="spec"/>
    <alias name="" index="4" field="dim1"/>
    <alias name="" index="5" field="dim2"/>
    <alias name="" index="6" field="cblcpty"/>
    <alias name="" index="7" field="conntr"/>
    <alias name="" index="8" field="ntwrkptn"/>
    <alias name="" index="9" field="cmpownr"/>
    <alias name="" index="10" field="strtfeat"/>
    <alias name="" index="11" field="endfeat"/>
    <alias name="" index="12" field="lat"/>
    <alias name="" index="13" field="lon"/>
    <alias name="" index="14" field="sg21"/>
    <alias name="" index="15" field="sg26"/>
    <alias name="" index="16" field="address"/>
    <alias name="" index="17" field="pon_no"/>
    <alias name="" index="18" field="zone_no"/>
    <alias name="" index="19" field="subplace"/>
    <alias name="" index="20" field="mainplce"/>
    <alias name="" index="21" field="mun"/>
    <alias name="" index="22" field="stackref"/>
    <alias name="" index="23" field="datecrtd"/>
    <alias name="" index="24" field="crtdby"/>
    <alias name="" index="25" field="date_edt"/>
    <alias name="" index="26" field="editby"/>
    <alias name="" index="27" field="comments"/>
  </aliases>
  <defaults>
    <default expression="" field="label" applyOnUpdate="0"/>
    <default expression="" field="type" applyOnUpdate="0"/>
    <default expression="" field="subtyp" applyOnUpdate="0"/>
    <default expression="" field="spec" applyOnUpdate="0"/>
    <default expression="" field="dim1" applyOnUpdate="0"/>
    <default expression="" field="dim2" applyOnUpdate="0"/>
    <default expression="" field="cblcpty" applyOnUpdate="0"/>
    <default expression="" field="conntr" applyOnUpdate="0"/>
    <default expression="" field="ntwrkptn" applyOnUpdate="0"/>
    <default expression="" field="cmpownr" applyOnUpdate="0"/>
    <default expression="" field="strtfeat" applyOnUpdate="0"/>
    <default expression="" field="endfeat" applyOnUpdate="0"/>
    <default expression="" field="lat" applyOnUpdate="0"/>
    <default expression="" field="lon" applyOnUpdate="0"/>
    <default expression="" field="sg21" applyOnUpdate="0"/>
    <default expression="" field="sg26" applyOnUpdate="0"/>
    <default expression="" field="address" applyOnUpdate="0"/>
    <default expression="" field="pon_no" applyOnUpdate="0"/>
    <default expression="" field="zone_no" applyOnUpdate="0"/>
    <default expression="" field="subplace" applyOnUpdate="0"/>
    <default expression="" field="mainplce" applyOnUpdate="0"/>
    <default expression="" field="mun" applyOnUpdate="0"/>
    <default expression="" field="stackref" applyOnUpdate="0"/>
    <default expression="" field="datecrtd" applyOnUpdate="0"/>
    <default expression="" field="crtdby" applyOnUpdate="0"/>
    <default expression="" field="date_edt" applyOnUpdate="0"/>
    <default expression="" field="editby" applyOnUpdate="0"/>
    <default expression="" field="comments" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="label"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="type"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subtyp"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="spec"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="cblcpty"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="conntr"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="ntwrkptn"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="cmpownr"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="strtfeat"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="endfeat"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="lat"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="lon"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="sg21"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="sg26"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="address"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="pon_no"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="zone_no"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subplace"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="mainplce"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="mun"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="stackref"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="datecrtd"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="crtdby"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="date_edt"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="editby"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="comments"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" field="label" desc=""/>
    <constraint exp="" field="type" desc=""/>
    <constraint exp="" field="subtyp" desc=""/>
    <constraint exp="" field="spec" desc=""/>
    <constraint exp="" field="dim1" desc=""/>
    <constraint exp="" field="dim2" desc=""/>
    <constraint exp="" field="cblcpty" desc=""/>
    <constraint exp="" field="conntr" desc=""/>
    <constraint exp="" field="ntwrkptn" desc=""/>
    <constraint exp="" field="cmpownr" desc=""/>
    <constraint exp="" field="strtfeat" desc=""/>
    <constraint exp="" field="endfeat" desc=""/>
    <constraint exp="" field="lat" desc=""/>
    <constraint exp="" field="lon" desc=""/>
    <constraint exp="" field="sg21" desc=""/>
    <constraint exp="" field="sg26" desc=""/>
    <constraint exp="" field="address" desc=""/>
    <constraint exp="" field="pon_no" desc=""/>
    <constraint exp="" field="zone_no" desc=""/>
    <constraint exp="" field="subplace" desc=""/>
    <constraint exp="" field="mainplce" desc=""/>
    <constraint exp="" field="mun" desc=""/>
    <constraint exp="" field="stackref" desc=""/>
    <constraint exp="" field="datecrtd" desc=""/>
    <constraint exp="" field="crtdby" desc=""/>
    <constraint exp="" field="date_edt" desc=""/>
    <constraint exp="" field="editby" desc=""/>
    <constraint exp="" field="comments" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="&quot;label&quot;" sortOrder="0">
    <columns>
      <column name="id" type="field" width="-1" hidden="0"/>
      <column type="actions" width="-1" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="id" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="id" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="id" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"id"</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>
