# Label Feeder Cables Algorithm

from qgis.core import (
    QgsProcessingParameterVectorLayer,
    QgsProcessing
)

from .base_algorithm import BaseFiberAlgorithm


class LabelFeederCablesAlgorithm(BaseFiberAlgorithm):
    """Algorithm to label Feeder Cable layers"""

    def name(self):
        return 'labelfeedercables'

    def displayName(self):
        return '7. Label Feeder Cables'

    def shortHelpString(self):
        return """
        Auto-populate Feeder Cable fields.

        Fields updated:
        - Feeder Cab: FC01, FC02...
        - Tlenght: geometry length (meters)
        - Slenght: calculated slack length
        - Name: Full engineering name
        - fid: 1, 2, 3...

        Note: Cable Size and To from fr must be filled manually
        """

    def initAlgorithm(self, config=None):
        # Input layer
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT,
                'Feeder Cable Layer',
                [QgsProcessing.TypeVectorLine]
            )
        )

        # Project selection
        self.add_common_parameters()

    def processAlgorithm(self, parameters, context, feedback):
        # Get parameters
        layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        project = self.get_project_code(parameters, context)

        feedback.pushInfo(f"Labeling Feeder Cables for {project}...")

        # Update Feeder Cab
        feedback.pushInfo("Updating Feeder Cab...")
        formula = "'FC' || lpad(to_string(@row_number), 2, '0')"
        self.calculate_field(layer, "Feeder Cab", formula, feedback)

        # Update Tlenght
        feedback.pushInfo("Updating Tlenght...")
        self.calculate_field(layer, "Tlenght", "$length", feedback)

        # Update Slenght (calculated slack)
        feedback.pushInfo("Updating Slenght...")
        slack_formula = """CASE
            WHEN "Tlenght" <= 50 THEN 15
            WHEN "Tlenght" <= 100 THEN 30
            WHEN "Tlenght" <= 200 THEN 40
            ELSE 50
        END"""
        self.calculate_field(layer, "Slenght", slack_formula, feedback)

        # Update Name (complex formula)
        feedback.pushInfo("Updating Name...")
        name_formula = f"""'VTC BUR {project} ' || "Feeder Cab" || ' ' || "Cable Size" || ' ' || "To from fr" || ' ADSS G6.657.A1 (' || to_string(ceil("Tlenght")) || 'm-' || to_string(ceil("Tlenght" + coalesce("Slenght", 0))) || 'm)'"""
        self.calculate_field(layer, "Name", name_formula, feedback)

        # Update fid
        feedback.pushInfo("Updating fid...")
        self.calculate_field(layer, "fid", "@row_number", feedback)

        layer.triggerRepaint()
        feedback.pushInfo("✅ Feeder Cables labeled successfully!")

        return {self.INPUT: layer.id()}
