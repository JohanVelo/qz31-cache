"""Velocity Nexus — branded home dock panel (themeable).

A clean, friendly control panel that fronts the plugin's tools so QGIS feels like a
product, not raw QGIS. Header shows a wordmark (or logo.png if present) + live bridge
status + a theme switcher; below are numbered workflow step buttons and a tools row.
Each button just triggers the plugin's existing actions/callbacks — no logic here.

Two built-in themes:
  • velocity  — VF identity: navy #14213D, blue #3B6FE0 → magenta #C2255C, teal #2ABFCC
  • fibertime — client identity: deep blue #081634, electric blue #1463FF + yellow #FFD400

Everything is styled by objectName via QSS, so switching theme = one stylesheet swap.
"""
import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QPixmap
from qgis.PyQt.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame,
    QLineEdit,
)

# ── theme palettes ───────────────────────────────────────────────────────────
THEMES = {
    "velocity": {
        "name": "Velocity Nexus",
        "bg":            "#0F1A30",
        "header":        "qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #14213D, stop:0.7 #1A2440, stop:1 #3A1733)",
        "accent":        "qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #3B6FE0, stop:1 #C2255C)",
        "word_top":      "#FFFFFF",
        "word_bot":      "#9FB0D0",
        "tagline":       "#7E8DB0",
        "section":       "#5E6E92",
        "step_bg":       "#18233E",
        "step_hover":    "#1F2C4C",
        "step_border":   "#222F4E",
        "step_hi":       "#3B6FE0",
        "title":         "#EAF0FF",
        "sub":           "#8294B8",
        "chev":          "#5E6E92",
        "tool_bg":       "#141E36",
        "tool_text":     "#B8C6E6",
        "tool_hover":    "#1D2949",
        "tool_hi":       "#2ABFCC",
        "status_on":     "#2ABFCC",
        "status_off":    "#E0607A",
        "badge_text":    "#FFFFFF",
    },
    "fibertime": {
        "name": "fibertime",
        "bg":            "#081634",
        "header":        "qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #0B2A6B, stop:0.6 #103A8E, stop:1 #155FD0)",
        "accent":        "qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #1463FF, stop:1 #FFD400)",
        "word_top":      "#FFFFFF",
        "word_bot":      "#FFD400",
        "tagline":       "#9FB6E8",
        "section":       "#5C77B8",
        "step_bg":       "#0E2356",
        "step_hover":    "#143071",
        "step_border":   "#1E3C82",
        "step_hi":       "#FFD400",
        "title":         "#EAF1FF",
        "sub":           "#9FB6E8",
        "chev":          "#5C77B8",
        "tool_bg":       "#0C1F4C",
        "tool_text":     "#BCD0F5",
        "tool_hover":    "#143071",
        "tool_hi":       "#FFD400",
        "status_on":     "#FFD400",
        "status_off":    "#FF6B6B",
        "badge_text":    "#08183A",
    },
}

# step title keyword → leading emoji icon (quick visual scanning)
_ICONS = [
    ("detect", "🛰"), ("erven", "📐"), ("planner", "🗺"), ("network", "🗺"),
    ("label", "🏷"), ("audit", "✅"), ("check", "✅"), ("splice", "🧵"),
]


def _icon_for(title):
    t = title.lower()
    for key, emo in _ICONS:
        if key in t:
            return emo
    return "▸"


def _build_qss(c):
    """Build the full panel stylesheet from a theme colour dict."""
    return f"""
#vfRoot {{ background:{c['bg']}; }}
#vfHeader {{ background:{c['header']}; }}
#vfWordTop   {{ color:{c['word_top']}; font-size:20px; font-weight:800; letter-spacing:3px; }}
#vfWordBot   {{ color:{c['word_bot']}; font-size:11px; font-weight:700; letter-spacing:6px; }}
#vfTagline   {{ color:{c['tagline']}; font-size:10px; }}
#vfStatus    {{ color:{c['word_bot']}; font-size:10px; }}
#vfSection   {{ color:{c['section']}; font-size:10px; font-weight:700; letter-spacing:2px; }}

#vfVmark {{ background:{c['accent']}; border-radius:9px; }}
#vfVmark QLabel {{ color:#FFFFFF; font-size:20px; font-weight:900; }}

QPushButton#vfThemeBtn {{
    color:{c['word_bot']}; background:rgba(255,255,255,0.06);
    border:1px solid rgba(255,255,255,0.12); border-radius:9px;
    padding:3px 9px; font-size:10px; font-weight:700;
}}
QPushButton#vfThemeBtn:hover {{ color:#FFFFFF; border:1px solid {c['step_hi']}; }}
QPushButton#vfThemeBtn[active="true"] {{
    color:{c['badge_text']}; background:{c['accent']};
    border:1px solid {c['step_hi']};
}}

QPushButton#vfGear {{
    color:{c['word_bot']}; background:rgba(255,255,255,0.06);
    border:1px solid rgba(255,255,255,0.12); border-radius:9px;
    padding:3px 9px; font-size:13px; font-weight:700;
}}
QPushButton#vfGear:hover {{ color:#FFFFFF; border:1px solid {c['step_hi']}; background:{c['step_hover']}; }}

/* step cards */
QFrame#vfStep {{
    border:1px solid {c['step_border']}; border-radius:12px; background:{c['step_bg']};
}}
QFrame#vfStep:hover {{ border:1px solid {c['step_hi']}; background:{c['step_hover']}; }}
QFrame#vfStripe {{ background:{c['accent']}; border-top-left-radius:12px; border-bottom-left-radius:12px; }}
QLabel#vfStepNum {{
    background:{c['accent']}; color:{c['badge_text']};
    font-weight:900; font-size:14px; border-radius:14px;
}}
QLabel#vfStepTitle {{ color:{c['title']}; font-size:14px; font-weight:700; }}
QLabel#vfStepSub   {{ color:{c['sub']};   font-size:10px; }}
QLabel#vfStepChev  {{ color:{c['chev']};  font-size:20px; font-weight:800; }}

/* tools */
QPushButton#vfTool {{
    padding:9px 6px; border:1px solid {c['step_border']}; border-radius:10px;
    background:{c['tool_bg']}; color:{c['tool_text']}; font-size:11px; font-weight:700;
}}
QPushButton#vfTool:hover {{ background:{c['tool_hover']}; border:1px solid {c['tool_hi']}; color:#FFFFFF; }}

/* activation (lock) card */
QFrame#vfLock {{
    background:{c['step_bg']}; border:2px solid {c['step_hi']}; border-radius:12px;
}}
QLabel#vfLockTitle {{ color:{c['title']}; font-size:14px; font-weight:800; }}
QLabel#vfLockSub   {{ color:{c['sub']};   font-size:10px; }}
QLabel#vfLockMsg   {{ color:{c['status_off']}; font-size:10px; font-weight:700; }}
QLineEdit#vfLockInput {{
    background:{c['tool_bg']}; color:{c['title']};
    border:1px solid {c['step_border']}; border-radius:8px; padding:8px 10px; font-size:12px;
}}
QLineEdit#vfLockInput:focus {{ border:1px solid {c['step_hi']}; }}
QPushButton#vfLockBtn {{
    background:{c['accent']}; color:{c['badge_text']};
    border:none; border-radius:9px; padding:9px; font-size:12px; font-weight:800;
}}
QPushButton#vfLockBtn:hover {{ border:1px solid #FFFFFF; }}
"""


class VelocityHomePanel(QDockWidget):
    """Branded dock. steps = [(title, subtitle, callable)], tools = [(label, callable)]."""

    def __init__(self, iface, steps, tools, logo_path=None, theme="velocity", parent=None):
        super().__init__("Velocity Nexus", parent or iface.mainWindow())
        self.setObjectName("VelocityHomePanel")
        self.iface = iface
        self._theme = theme if theme in THEMES else "velocity"
        self._status = None
        self._theme_btns = {}
        self._last_online = False
        self._last_port = None

        self._root = QWidget()
        self._root.setObjectName("vfRoot")
        v = QVBoxLayout(self._root)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)

        v.addWidget(self._build_header(logo_path))

        body = QVBoxLayout()
        body.setContentsMargins(12, 12, 12, 12)
        body.setSpacing(9)
        # Update banner — hidden until update_check finds a newer version
        self._update_card = self._build_update_card()
        body.addWidget(self._update_card)
        # Activation card — shown only while locked (impossible to miss, top of panel)
        self._lock_card = self._build_lock_card()
        body.addWidget(self._lock_card)
        self._workflow_lbl = self._label("WORKFLOW", "vfSection")
        body.addWidget(self._workflow_lbl)
        for i, (title, sub, cb) in enumerate(steps, 1):
            body.addWidget(self._step_card(i, title, sub, cb))
        body.addSpacing(6)
        body.addWidget(self._label("TOOLS", "vfSection"))
        trow = QHBoxLayout()
        trow.setSpacing(6)
        for label, cb in tools:
            trow.addWidget(self._tool_button(label, cb))
        body.addLayout(trow)
        body.addStretch(1)
        v.addLayout(body)

        self.setWidget(self._root)
        self.setMinimumWidth(258)
        self._apply_theme()

    # ── update banner ──
    def _build_update_card(self):
        card = QFrame()
        card.setObjectName("vfUpdateCard")
        card.setStyleSheet(
            "#vfUpdateCard{background:#173042;border:1px solid #2ec4f1;"
            "border-radius:8px;}"
            "#vfUpdateCard QLabel{color:#d9f3ff;background:transparent;"
            "font-size:11px;}"
            "#vfUpdateCard QLabel#vfUpdTitle{color:#2ec4f1;font-weight:700;"
            "font-size:12px;}"
            "#vfUpdateCard QPushButton{background:#2ec4f1;color:#06121c;"
            "font-weight:700;border:none;border-radius:6px;"
            "padding:6px 14px;}"
            "#vfUpdateCard QPushButton:hover{background:#5fd6ff;}")
        lay = QVBoxLayout(card)
        lay.setContentsMargins(10, 8, 10, 9)
        lay.setSpacing(5)
        self._upd_title = QLabel("🔄  Update available")
        self._upd_title.setObjectName("vfUpdTitle")
        lay.addWidget(self._upd_title)
        self._upd_text = QLabel("")
        self._upd_text.setWordWrap(True)
        lay.addWidget(self._upd_text)
        row = QHBoxLayout()
        self._upd_btn = QPushButton("Update now")
        self._upd_btn.setCursor(Qt.PointingHandCursor)
        row.addWidget(self._upd_btn)
        row.addStretch(1)
        lay.addLayout(row)
        card.hide()
        return card

    def show_update_banner(self, version, on_update):
        """Called by update_check when the team channel has a newer build."""
        try:
            self._upd_title.setText("🔄  Update available")
            self._upd_text.setText(
                f"Velocity Nexus v{version} is out — "
                "one click updates it (your activation is kept).")
            try:
                self._upd_btn.clicked.disconnect()
            except Exception:
                pass

            def _go():
                self._upd_btn.setEnabled(False)
                self._upd_btn.setText("Updating…")
                on_update()

            self._upd_btn.setEnabled(True)
            self._upd_btn.setText("Update now")
            self._upd_btn.clicked.connect(_go)
            self._update_card.show()
        except RuntimeError:
            pass                        # panel mid-teardown

    @staticmethod
    def _plugin_version():
        import re
        try:
            mp = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "metadata.txt")
            m = re.search(r"^version=([\d.]+)",
                          open(mp, encoding="utf-8").read(), flags=re.M)
            return m.group(1) if m else "?"
        except Exception:
            return "?"

    # ── header ──
    def _build_header(self, logo_path):
        h = QWidget()
        h.setObjectName("vfHeader")
        lay = QVBoxLayout(h)
        lay.setContentsMargins(14, 12, 14, 11)
        lay.setSpacing(3)

        top = QHBoxLayout()
        top.setSpacing(10)
        if logo_path and os.path.exists(logo_path):
            mark = QLabel()
            mark.setPixmap(QPixmap(logo_path).scaledToHeight(34, Qt.SmoothTransformation))
            top.addWidget(mark)
        else:
            mark = QWidget()
            mark.setObjectName("vfVmark")
            mark.setFixedSize(34, 34)
            ml = QVBoxLayout(mark)
            ml.setContentsMargins(0, 0, 0, 0)
            vlab = QLabel("V")
            vlab.setAlignment(Qt.AlignCenter)
            ml.addWidget(vlab)
            top.addWidget(mark)
        words = QVBoxLayout()
        words.setSpacing(0)
        words.addWidget(self._label("VELOCITY", "vfWordTop"))
        words.addWidget(self._label("NEXUS", "vfWordBot"))
        top.addLayout(words)
        top.addStretch(1)
        ver = QLabel(f"v{self._plugin_version()}")
        ver.setObjectName("vfVersion")
        ver.setStyleSheet("color:#7E8DB0;font-size:10px;font-weight:700;")
        ver.setToolTip("Installed Velocity Nexus version")
        top.addWidget(ver, alignment=Qt.AlignTop)
        lay.addLayout(top)
        lay.addWidget(self._label("FTTH Network Planner", "vfTagline"))

        # theme switch + status row
        row = QHBoxLayout()
        row.setSpacing(6)
        self._status = self._label("●  Bridge: checking…", "vfStatus")
        row.addWidget(self._status)
        row.addStretch(1)
        for key in ("velocity", "fibertime"):
            b = QPushButton("VF" if key == "velocity" else "fibertime")
            b.setObjectName("vfThemeBtn")
            b.setCursor(Qt.PointingHandCursor)
            b.setToolTip(f"Switch to the {THEMES[key]['name']} colour theme")
            b.clicked.connect(lambda _=False, k=key: self.set_theme(k))
            self._theme_btns[key] = b
            row.addWidget(b)
        # ⚙ Settings / menu button — opens the full Velocity Nexus menu + settings
        self._settings_cb = None
        gear = QPushButton("⚙")
        gear.setObjectName("vfGear")
        gear.setCursor(Qt.PointingHandCursor)
        gear.setToolTip("Settings, tools & help — Report a Problem, About & Activation, "
                        "updates, and every Velocity Nexus tool")
        gear.clicked.connect(self._on_settings)
        self._gear_btn = gear
        row.addWidget(gear)
        lay.addLayout(row)
        return h

    def _on_settings(self):
        if self._settings_cb:
            self._settings_cb(self._gear_btn)

    def set_settings_callback(self, cb):
        """cb(anchor_widget) is called when the ⚙ button is clicked."""
        self._settings_cb = cb

    # ── activation (lock) card ──
    def _build_lock_card(self):
        """A prominent 'enter password to unlock' card. Hidden once activated.
        Wired to self._activate_cb(password) which the plugin sets."""
        self._activate_cb = None
        card = QFrame()
        card.setObjectName("vfLock")
        lay = QVBoxLayout(card)
        lay.setContentsMargins(14, 13, 14, 13)
        lay.setSpacing(8)
        title = QLabel("🔒  Activation required")
        title.setObjectName("vfLockTitle")
        lay.addWidget(title)
        sub = QLabel("Enter the company password once to unlock every tool on this machine.")
        sub.setObjectName("vfLockSub")
        sub.setWordWrap(True)
        lay.addWidget(sub)
        self._pw_edit = QLineEdit()
        self._pw_edit.setObjectName("vfLockInput")
        self._pw_edit.setEchoMode(QLineEdit.Password)
        self._pw_edit.setPlaceholderText("Company password")
        lay.addWidget(self._pw_edit)
        self._lock_msg = QLabel("")
        self._lock_msg.setObjectName("vfLockMsg")
        self._lock_msg.setWordWrap(True)
        lay.addWidget(self._lock_msg)
        btn = QPushButton("Unlock")
        btn.setObjectName("vfLockBtn")
        btn.setCursor(Qt.PointingHandCursor)
        lay.addWidget(btn)
        btn.clicked.connect(self._on_unlock_clicked)
        self._pw_edit.returnPressed.connect(self._on_unlock_clicked)
        return card

    def _on_unlock_clicked(self):
        if not self._activate_cb:
            return
        ok, msg = self._activate_cb(self._pw_edit.text())
        if ok:
            self._pw_edit.clear()
            self.set_locked(False)
        else:
            self._lock_msg.setText(msg or "Wrong password.")
            self._pw_edit.selectAll()

    def set_locked(self, locked, on_activate=None):
        """Show/hide the activation card. on_activate(password) -> (ok, message)."""
        if on_activate is not None:
            self._activate_cb = on_activate
        try:
            self._lock_card.setVisible(locked)
        except RuntimeError:
            pass

    def lock_message(self, text):
        try:
            self._lock_msg.setText(text or "")
        except RuntimeError:
            pass

    # ── widgets ──
    def _label(self, text, obj):
        lab = QLabel(text)
        lab.setObjectName(obj)
        return lab

    def _step_card(self, n, title, sub, cb):
        card = QFrame()
        card.setObjectName("vfStep")
        card.setCursor(Qt.PointingHandCursor)
        lay = QHBoxLayout(card)
        lay.setContentsMargins(0, 0, 10, 0)
        lay.setSpacing(0)

        stripe = QFrame()
        stripe.setObjectName("vfStripe")
        stripe.setFixedWidth(5)
        lay.addWidget(stripe)

        inner = QHBoxLayout()
        inner.setContentsMargins(9, 8, 0, 8)
        inner.setSpacing(11)
        num = QLabel(str(n))
        num.setObjectName("vfStepNum")
        num.setFixedSize(28, 28)
        num.setAlignment(Qt.AlignCenter)
        inner.addWidget(num)

        txt = QVBoxLayout()
        txt.setSpacing(1)
        t = QLabel(f"{_icon_for(title)}  {title}")
        t.setObjectName("vfStepTitle")
        s = QLabel(sub)
        s.setObjectName("vfStepSub")
        txt.addWidget(t)
        txt.addWidget(s)
        inner.addLayout(txt)
        inner.addStretch(1)
        lay.addLayout(inner)

        chev = QLabel("›")
        chev.setObjectName("vfStepChev")
        lay.addWidget(chev)

        if cb:
            card.mousePressEvent = lambda _e, f=cb: self._safe(f)
        return card

    def _tool_button(self, label, cb):
        b = QPushButton(label)
        b.setObjectName("vfTool")
        b.setCursor(Qt.PointingHandCursor)
        if cb:
            b.clicked.connect(lambda _=False, f=cb: self._safe(f))
        return b

    def _safe(self, fn):
        try:
            fn()
        except Exception as e:  # never let a panel click raise into the UI
            try:
                self.iface.messageBar().pushWarning("Velocity Nexus", str(e)[:200])
            except Exception:
                pass

    # ── theming ──
    def _apply_theme(self):
        c = THEMES[self._theme]
        self._root.setStyleSheet(_build_qss(c))
        for key, btn in self._theme_btns.items():
            btn.setProperty("active", "true" if key == self._theme else "false")
            btn.style().unpolish(btn)
            btn.style().polish(btn)
        # re-apply status colour (it's set inline) for the new palette
        self.set_bridge(self._last_online, self._last_port)

    def set_theme(self, name):
        if name in THEMES and name != self._theme:
            self._theme = name
            self._apply_theme()

    # ── public ──
    def set_bridge(self, online, port=None):
        self._last_online, self._last_port = online, port
        if not self._status:
            return
        c = THEMES[self._theme]
        if online:
            self._status.setText("●  Bridge online" + (f" · {port}" if port else ""))
            self._status.setStyleSheet(f"color:{c['status_on']}; font-size:10px;")
        else:
            self._status.setText("●  Bridge offline")
            self._status.setStyleSheet(f"color:{c['status_off']}; font-size:10px;")
