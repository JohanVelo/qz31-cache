"""fingerprint — a stable per-machine id used to ban a deactivated person's
machine, so they can't just sign up again under a new name from the same PC.

Honest scope: this closes the CASUAL "sign out → register as john2" bypass while
the unmodified plugin reports the real fingerprint. A determined person editing
this Python could spoof it — that's the accepted client-side limit (the code is
on their disk). The point is to shut the easy re-registration loophole, which is
the one real hole left in the deactivation flow.
"""
import hashlib
import os
import platform
import uuid


def machine_fingerprint():
    """SHA-256 of (MAC, hostname, OS username). Stable across reboots; differs
    per machine and per OS user. 64-char hex, or '' on failure (never raises)."""
    try:
        mac = uuid.getnode()                       # NIC MAC as a 48-bit int
        host = platform.node() or ""
        user = os.environ.get("USERNAME") or os.environ.get("USER") or ""
        raw = f"{mac}|{host}|{user}"
        return hashlib.sha256(raw.encode("utf-8", "replace")).hexdigest()
    except Exception:
        return ""
