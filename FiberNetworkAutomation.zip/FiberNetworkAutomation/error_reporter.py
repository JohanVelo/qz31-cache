"""error_reporter — capture errors on teammates' machines so JJ can fix them.

Teammates have no Claude/terminal. When a Velocity Fibre tool throws, we:
  1. log it to a per-machine file (timestamp + version + user + full traceback),
  2. show a friendly message pointing at "Report a Problem",
  3. let them send the log to JJ in one click (email / copy / open folder).

JJ reads the report, fixes the code, runs `publish_plugin.py`, and the teammate
upgrades — the loop closes without anyone needing Claude.
"""
import base64
import os
import getpass
import platform
import traceback
from datetime import datetime, timezone

# Support address is base64-obfuscated so it can't be scraped from the shipped source
# by someone who merely stumbles on the plugin. Decoded only at runtime (same
# deterrent posture as the activation gate — not a vault, but stops casual harvesting).
_SUPPORT_B64 = 'ampAdmVsb2NpdHlmaWJyZS5jby56YQ=='


def support_email() -> str:
    return base64.b64decode(_SUPPORT_B64).decode('utf-8')


def _is_activated() -> bool:
    try:
        try:
            from . import activation
        except ImportError:
            import activation
        return activation.is_activated()
    except Exception:
        return False


# Backwards-compatible module attribute (computed, not a plaintext literal).
SUPPORT_EMAIL = support_email()


def _log_path():
    try:
        from .fibre_automation.shared.vf_paths import data_file
        return data_file('velocity_fibre_errors.log')
    except Exception:
        try:
            from fibre_automation.shared.vf_paths import data_file
            return data_file('velocity_fibre_errors.log')
        except Exception:
            import tempfile
            return os.path.join(tempfile.gettempdir(), 'velocity_fibre_errors.log')


def _version():
    try:
        import configparser
        cp = configparser.ConfigParser()
        cp.read(os.path.join(os.path.dirname(__file__), 'metadata.txt'), encoding='utf-8')
        return cp.get('general', 'version', fallback='?')
    except Exception:
        return '?'


def log_error(where: str, exc: BaseException):
    """Append a structured entry to the error log. Returns the log path."""
    try:
        when = datetime.now(timezone.utc).astimezone().strftime('%Y-%m-%d %H:%M:%S')
    except Exception:
        when = '?'
    tb = ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    try:
        user = getpass.getuser()
    except Exception:
        user = os.environ.get('USERNAME', '?')
    entry = (
        f"\n{'='*70}\n"
        f"TIME    : {when}\n"
        f"VERSION : Velocity Fibre Automation v{_version()}\n"
        f"USER    : {user}@{platform.node()}\n"
        f"QGIS    : {_qgis_version()}\n"
        f"ACTION  : {where}\n"
        f"ERROR   : {type(exc).__name__}: {exc}\n"
        f"{'-'*70}\n{tb}"
    )
    path = _log_path()
    try:
        with open(path, 'a', encoding='utf-8') as f:
            f.write(entry)
    except Exception:
        pass
    return path


def _qgis_version():
    try:
        from qgis.core import Qgis
        return Qgis.QGIS_VERSION
    except Exception:
        return '?'


def guard(iface, name, fn):
    """Wrap a zero-arg menu/toolbar callback so any exception is logged + shown
    nicely instead of dumping a raw traceback on a teammate.

    NOTE: QAction.triggered emits a `checked` bool. Because this wrapper has a
    *args signature, PyQt passes that bool through — but the wrapped menu
    callbacks take no arguments. So we deliberately call fn() with NO args and
    swallow whatever Qt sent. (All mk() callbacks are zero-arg.)"""
    def wrapped(*args, **kwargs):
        try:
            return fn()
        except Exception as exc:
            path = log_error(name, exc)
            try:
                iface.messageBar().pushWarning(
                    'Velocity Fibre',
                    f'"{name}" hit a problem and was logged. '
                    'Velocity Fibre menu -> Report a Problem to send it to support.')
            except Exception:
                pass
            print(f'[VelocityFibre] error in {name}: {exc}\n  logged to {path}')
    return wrapped


def read_recent(max_chars=12000):
    """Return the tail of the error log (most recent entries), or ''."""
    path = _log_path()
    if not os.path.exists(path):
        return ''
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            data = f.read()
        return data[-max_chars:]
    except Exception:
        return ''


def clear_log():
    path = _log_path()
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


class ProblemReportDialog:
    """Branded 'Report a Problem' dialog: shows recent errors, lets the user add
    a note, and send to JJ (email / copy / open folder)."""

    def __init__(self, iface):
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel, QPlainTextEdit,
                                         QPushButton, QHBoxLayout)
        self.iface = iface
        self.dlg = QDialog(iface.mainWindow())
        self.dlg.setWindowTitle('Velocity Fibre — Report a Problem')
        self.dlg.setMinimumSize(560, 480)
        lay = QVBoxLayout(self.dlg)
        lay.setContentsMargins(16, 12, 16, 14)
        lay.setSpacing(8)

        lay.addWidget(QLabel('Tell us what you were doing when it went wrong (optional):'))
        self.note = QPlainTextEdit()
        self.note.setPlaceholderText('e.g. "Clicked FT5 Generate PON Zones on the Kuruman project"')
        self.note.setFixedHeight(70)
        lay.addWidget(self.note)

        recent = read_recent()
        lay.addWidget(QLabel('Recent errors logged on this machine:'))
        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setPlainText(recent or 'No errors logged. 🎉')
        lay.addWidget(self.log_view, 1)

        row = QHBoxLayout()
        email = QPushButton('✉  Email to support')
        copy = QPushButton('Copy report')
        folder = QPushButton('Open log folder')
        close = QPushButton('Close')
        row.addWidget(email)
        row.addWidget(copy)
        row.addWidget(folder)
        row.addStretch(1)
        row.addWidget(close)
        lay.addLayout(row)

        email.clicked.connect(self._email)
        copy.clicked.connect(self._copy)
        folder.clicked.connect(self._folder)
        close.clicked.connect(self.dlg.accept)

        try:
            try:
                from .branding import vf_style
            except ImportError:
                from branding import vf_style
            vf_style.apply_vf_style(self.dlg, title='Report a Problem')
            vf_style.mark_secondary(close)
        except Exception:
            pass

    def _report_text(self):
        return (f"Velocity Fibre Automation v{_version()}\n"
                f"What I was doing:\n{self.note.toPlainText().strip()}\n\n"
                f"--- error log ---\n{read_recent()}")

    def _email(self):
        from qgis.PyQt.QtCore import QUrl
        from qgis.PyQt.QtGui import QDesktopServices
        import urllib.parse
        # The support address is only revealed to ACTIVATED machines — a random person
        # who stumbles on the plugin but never activates can't harvest it via the UI.
        if not _is_activated():
            try:
                self.iface.messageBar().pushWarning(
                    'Velocity Fibre',
                    'Activate the plugin first to contact support.')
            except Exception:
                pass
            return
        subject = urllib.parse.quote(f'Velocity Fibre Automation problem (v{_version()})')
        body = urllib.parse.quote(self._report_text()[:1800])  # mailto length limit
        QDesktopServices.openUrl(QUrl(f'mailto:{support_email()}?subject={subject}&body={body}'))
        # Also copy the full report so they can paste it if the email body was truncated.
        self._copy(silent=True)
        try:
            self.iface.messageBar().pushInfo(
                'Velocity Fibre',
                'Opened your email app. The full report is also on your clipboard — '
                'paste it into the email if needed.')
        except Exception:
            pass

    def _copy(self, silent=False):
        from qgis.PyQt.QtWidgets import QApplication
        QApplication.clipboard().setText(self._report_text())
        if not silent:
            try:
                self.iface.messageBar().pushInfo('Velocity Fibre', 'Report copied to clipboard.')
            except Exception:
                pass

    def _folder(self):
        from qgis.PyQt.QtCore import QUrl
        from qgis.PyQt.QtGui import QDesktopServices
        path = _log_path()
        try:
            QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.dirname(path)))
        except Exception:
            pass

    def show(self):
        self.dlg.show()
        self.dlg.raise_()
        return self.dlg
