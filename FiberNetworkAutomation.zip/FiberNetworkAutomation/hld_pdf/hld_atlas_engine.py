# -*- coding: utf-8 -*-
# ============================================================================
# HLD Atlas Engine  (Phase 0 — config-driven)
# ----------------------------------------------------------------------------
# Builds two editable QgsPrintLayouts in the CURRENT project:
#     <layout_overview>  (1 page: PON numbers + feeder routes)
#     <layout_atlas>     (N pages: one per coverage feature, full detail)
# A3 landscape, big map + sidebar (Legend / North / logo / title block),
# matching the Phase 1 reference deliverable.
#
# Idempotent: removes+recreates its own layouts each run. Does NOT export
# (export is a separate headless step — never render a big atlas on the GUI thread).
#
# DE-HARDCODED: every project-specific value lives in DEFAULT_CFG below.
# A caller injects overrides by defining a dict `HLD_CFG` in the namespace
# BEFORE exec()'ing this file, e.g.:
#     ns = {"HLD_CFG": {...}}
#     exec(open("hld_atlas_engine.py").read(), ns)
# With no HLD_CFG defined, it reproduces the Mohadin Phase 2 PDF exactly.
# ============================================================================
import os
import copy
from qgis.core import (
    QgsProject, QgsPrintLayout, QgsLayoutItemPage, QgsLayoutItemMap,
    QgsLayoutItemLabel, QgsLayoutItemPicture, QgsLayoutItemShape,
    QgsLayoutPoint, QgsLayoutSize, QgsUnitTypes, QgsRectangle, QgsLayoutMeasurement,
)
from qgis.PyQt.QtGui import QColor, QFont

# ---------------------------------------------------------------------------
# DEFAULT CONFIG = Mohadin Phase 2 (the proven deliverable).
# ---------------------------------------------------------------------------
DEFAULT_CFG = {
    # --- identity / title block ---
    "project_name":   "Mohadin Phase 2",
    "company":        "Velocity Fibre",
    "designer":       "Johan Scholtz",
    "date_str":       "07-07-2026",
    "revision":       "1",
    "title_overview": "Mohadin Phase 2 Overview",
    "title_atlas_expr": 'Mohadin Phase 2 - PON [% "pon_no" %]',   # dynamic per-page

    # --- assets ---
    "logo_path":  r"C:/Temp/ph2_hld_assets/fibertime_logo.png",
    "legend_dir": r"C:/Temp/ph2_hld_assets/legend",

    # --- layout names ---
    # The deliverable is ONE Report: header = overview (page 1), field-group body =
    # one detail page per coverage feature. The overview/detail layouts are OWNED by
    # the report (not separate entries in the Layout Manager).
    "layout_overview": "MOA PH2 HLD Overview",     # report header (page 1)
    "layout_atlas":    "MOA PH2 HLD Atlas",        # report body (per-PON detail)
    "layout_report":   "MOA PH2 HLD Book",         # the QgsReport shown in the manager

    # --- layer resolution ---
    "group_name":  "phase 2 hld",   # resolve layers inside this group (JJ renames v1->friendly)
    "aoi_layer":   "greenfield and overbuild poly",
    "aoi_subset":  '"Name" = \'Greenfield\'',   # only the Greenfield polygon; None to keep all
    "basemap":     "Google Satellite",

    # role -> ordered candidate layer names (first found wins; group first, then whole project)
    "roles": {
        "coverage":     ["PON v1"],
        "primary":      ["ADSS", "Primary Cable v1"],
        "secondary":    ["Secondary Cable v1", "Secondary Cable"],
        "distribution": ["Mini-ADSS", "Distribution Cable v1"],
        "drop":         ["Drop Cable", "Drop Cable v1"],
        "spare_drop":   ["Spare Drop Cable v1", "Spare Drop Cable"],
        "poles":        ["Pole", "poles v1"],
        "fts":          ["FTS Splitter", "FTS Splitters v1"],
        "sts":          ["STS Splitter", "STS Splitters v1"],
        "enc_splice":   ["Enclosures Splice v1", "Enclosures Splice"],
        "enc_conn":     ["Enclosures Connectorised v1", "Enclosures Connectorised"],
        "enclosure":    ["Enclosure v1"],
        "ont":          ["ONT v1"],
        # stable area layers for the summary (independent of the atlas coverage choice)
        "pon_area":     ["PON v1", "PON"],
        "zones":        ["Zones v1", "Zone v1", "Zones", "Zone"],
    },

    # detail-page layers when there is NO group (saved 'HLD only' project). Draw order = top first.
    # NO primary/secondary feeders (they are overview-only).
    "detail_fallback": [
        "STS Splitters v1", "STS Splitter",
        "Enclosures Splice v1", "Enclosures Splice",
        "Enclosures Connectorised v1", "Enclosures Connectorised",
        "FTS Splitters v1", "FTS Splitter",
        "ONT v1", "Distribution Cable v1", "Mini-ADSS",
        "Drop Cable v1", "Drop Cable", "Spare Drop Cable v1",
        "poles v1", "Pole", "PON v1",
    ],
    "detail_exclude": ["Zones v1", "where slack applies", "Erven v1"],

    # --- atlas ---
    "coverage_sort_field": "label",
    "atlas_filename_expr": "'MOA_PH2_PON_' || \"label\"",
    "atlas_margin": 0.15,

    # --- grid coverage (auto-tile the AOI; one detail page per grid cell) ---
    # >0 triggers grid mode: the engine builds a grid over the AOI polygon at this cell
    # size (metres) and uses it as the coverage. Cell width/height come from the box the
    # operator drags on the canvas. 0 = off (per-PON / per-Zone coverage as normal).
    "grid_cell_w_m": 0.0,
    "grid_cell_h_m": 0.0,
    "grid_layer_name": "HLD Grid",

    # "report" (Generate PDF: one book, overview page 1) | "layouts" (Open in Print Layout:
    # page-view overview + detail atlas you edit directly). Set by the caller.
    "build_mode": "report",

    # --- styling ---
    "enc_splice_rgb": "0,60,255",    # splice = blue
    "enc_conn_rgb":   "0,200,200",   # connectorised = cyan
    "pon_fill_alpha": 45,            # see houses through the PON fill

    # --- labels: role -> settings dict (label ON) or None (label OFF on detail pages) ---
    "labels": {
        "distribution": {"size": 5.5, "along_line": True,  "buf": 0.8, "strip": "MOA."},
        "poles":        {"size": 5.0, "along_line": False, "buf": 0.5, "strip": "MOA.P."},
        "fts":          {"size": 6.5, "along_line": False, "buf": 0.8, "strip": "MOA."},
        "sts":          {"size": 5.5, "along_line": False, "buf": 0.8, "strip": "MOA.STS.8.DIS.DM.P."},
        "primary":   None,   # feeders overview-only
        "secondary": None,
        "drop":      None,   # drop labels OFF (JJ)
        "spare_drop": None,
    },
    "label_min_scale": 9000.0,

    # --- legend ---
    # points render the layer's REAL symbol; lines draw as a coloured bar
    "legend_points": [
        ("FTS Splitter", "fts"), ("STS Splitter", "sts"),
        ("Enclosure (Splice)", "enc_splice"), ("Enclosure (Connectorised)", "enc_conn"),
        ("Pole", "poles"),
    ],
    "legend_lines": [
        ("ADSS", "primary", "#0000ff"),
        ("Mini-ADSS", "distribution", "#ef3ec8"),
        ("Drop Cable", "drop", "#29a500"),
    ],
    # GUARD RAIL: auto-complete the legend from the layers actually drawn on the map,
    # so nothing on the canvas is left out (the configured rows above render first for
    # nice names/order; any remaining drawn layer is appended with its REAL symbol).
    "legend_auto":         True,
    "legend_basemap_note": "Satellite Photography",
    # raw layer name -> friendly legend label (else the name minus a trailing " v1")
    "legend_aliases": {
        "ONT v1":               "Home Connections (ONT)",
        "Home Connection v1":   "Home Connections",
        "Spare Drop Cable v1":  "Spare Drop Cables",
        "Secondary Cable v1":   "Secondary Feeder",
        "Primary Cable v1":     "Primary Feeder (ADSS)",
        "Distribution Cable v1": "Distribution (Mini-ADSS)",
        "PON v1":               "PONs",
        "Zones v1":             "Zones",
        "Erven v1":             "Erfs",
        "poles v1":             "Poles",
        "greenfield and overbuild poly": "Project Boundary",
    },

    # --- sidebar detail (fill the empty space with real info, like the reference) ---
    "show_map_info":   True,                 # Scale / Projection block
    "projection_note": "EPSG:4326 · WGS 84",
    "show_summary":    True,                 # project feature-count summary panel
    "summary_title":   "PROJECT TOTALS",
    "summary_roles": [                       # (label, role) — counts read live at build time
        ("Homes (ONT)", "ont"),      ("Poles", "poles"),
        ("FTS Splitters", "fts"),    ("STS Splitters", "sts"),
        ("Enclosures", "enclosure"), ("PONs", "pon_area"),
        ("Zones", "zones"),          ("Drop Cables", "drop"),
        ("Spare Drops", "spare_drop"), ("Distribution", "distribution"),
    ],

    # --- MODEL / frame style: "hld" (default network atlas) | "commercial" (grid drawing) ---
    "frame_style":  "hld",
    "subtitle":     "",                # e.g. "COMMERCIAL DRAWING" (shown in the commercial sidebar)
    "created_by":   "",                # e.g. "Johan Scholtz"
    "scale_note":   "As-Shown (A3)",
    # explicit map layer lists (top-first). None -> HLD group/fallback logic.
    "detail_layers":   None,
    "overview_layers": None,
    # extra legend rows for fill/outline swatches (commercial zoning legend):
    "legend_fills":   [],              # [(label, "r,g,b" | layer_name)] -> filled colour box
    "legend_outline": [],              # [(label, "r,g,b")] -> outline-only box (e.g. AOI)
    # manual count tables in the sidebar: [{"title","headers":[...],"rows":[[...]]}]
    "count_tables": [],
    # label the coverage cells on the overview (grid numbers) with this field:
    "coverage_label_field": None,
    "logo_zoom": True,                 # Zoom (keep aspect); commercial logo is wider
}


def _deep_merge(base, over):
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


# caller may inject HLD_CFG in the exec namespace before running this file
CFG = _deep_merge(DEFAULT_CFG, globals().get("HLD_CFG", {}) or {})


def _enum(cls, *names):
    for n in names:
        obj = cls
        try:
            for part in n.split("."):
                obj = getattr(obj, part)
            return obj
        except AttributeError:
            continue
    raise AttributeError(f"none of {names} on {cls}")


MM = _enum(QgsUnitTypes, "LayoutUnit.LayoutMillimeters", "LayoutMillimeters")
LAND = _enum(QgsLayoutItemPage, "Orientation.Landscape", "Landscape")
HTMLMODE = _enum(QgsLayoutItemLabel, "Mode.ModeHtml", "ModeHtml")
ATLAS_AUTO = _enum(QgsLayoutItemMap, "AtlasScalingMode.Auto", "Auto")

p = QgsProject.instance()


def _lyr(name):
    for l in p.mapLayers().values():
        if l.name() == name:
            return l
    return None


# ---- group resolution (resolve layers within the configured group, not by hard-coded names) ----
def _p2_group():
    root = p.layerTreeRoot()
    want = CFG["group_name"].strip().lower()
    try:
        groups = root.findGroups(True)          # recursive (group may be nested)
    except TypeError:
        groups = []
        def _walk(node):
            for ch in node.children():
                if hasattr(ch, "children") and not hasattr(ch, "layer"):
                    groups.append(ch); _walk(ch)
        _walk(root)
    for g in groups:
        if g.name().strip().lower() == want:
            return g
    return None


def _p2_layer(*names):
    g = _p2_group()
    if g:
        for ch in g.findLayers():
            l = ch.layer()
            if l and l.name() in names:
                return l
    for n in names:
        x = _lyr(n)
        if x:
            return x
    return None


def _role(role):
    """Resolve a configured role to its layer (group-first, then whole project)."""
    names = CFG["roles"].get(role, [])
    return _p2_layer(*names) if names else None


def _p2_visible_layers(exclude=()):
    g = _p2_group()
    out = []
    if g:
        for ch in g.findLayers():
            l = ch.layer()
            if l and ch.isVisible() and l.name() not in exclude:
                out.append(l)
    return out


def _p2_enclosure():
    g = _p2_group()
    if g:
        for ch in g.findLayers():
            l = ch.layer()
            if not l:
                continue
            try:
                if any("Enclosure" in (c.label() or "") for c in l.renderer().categories()):
                    return l
            except Exception:
                pass
    return _role("enclosure")


def find_north_svg():
    from qgis.core import QgsApplication
    for base in QgsApplication.svgPaths():
        for cand in ("arrows/NorthArrow_02.svg", "arrows/NorthArrow_01.svg",
                     "arrows/NorthArrow_04.svg", "arrows/NorthArrow_11.svg"):
            fp = os.path.normpath(os.path.join(base, cand))
            if os.path.exists(fp):
                return fp
    return None


NORTH_SVG = find_north_svg()
LOGO = CFG["logo_path"]


def mmpoint(x, y): return QgsLayoutPoint(x, y, MM)
def mmsize(w, h): return QgsLayoutSize(w, h, MM)


def add_label(layout, x, y, w, h, html=None, text=None, size=9, bold=False,
              align_center=True, valign_center=True, frame=False):
    lbl = QgsLayoutItemLabel(layout)
    if html is not None:
        lbl.setMode(HTMLMODE)
        lbl.setText(html)
    else:
        lbl.setText(text or "")
        f = QFont(); f.setPointSize(size); f.setBold(bold)
        lbl.setFont(f)
    from qgis.PyQt.QtCore import Qt
    hz = _enum(Qt, "AlignmentFlag.AlignHCenter", "AlignHCenter") if align_center else _enum(Qt, "AlignmentFlag.AlignLeft", "AlignLeft")
    vt = _enum(Qt, "AlignmentFlag.AlignVCenter", "AlignVCenter") if valign_center else _enum(Qt, "AlignmentFlag.AlignTop", "AlignTop")
    try: lbl.setHAlign(hz); lbl.setVAlign(vt)
    except Exception: pass
    layout.addLayoutItem(lbl)
    lbl.attemptMove(mmpoint(x, y)); lbl.attemptResize(mmsize(w, h))
    if frame:
        lbl.setFrameEnabled(True); lbl.setFrameStrokeColor(QColor(0, 0, 0))
        lbl.setFrameStrokeWidth(QgsLayoutMeasurement(0.4, MM))
    return lbl


def add_rect(layout, x, y, w, h, stroke_w=0.6):
    RECT = _enum(QgsLayoutItemShape, "Shape.Rectangle", "Rectangle")
    sh = QgsLayoutItemShape(layout)
    try: sh.setShapeType(RECT)
    except Exception: pass
    layout.addLayoutItem(sh)
    sh.attemptMove(mmpoint(x, y)); sh.attemptResize(mmsize(w, h))
    sym = sh.symbol()
    if sym is not None:
        sym.setColor(QColor(255, 255, 255, 0))
        try:
            sl = sym.symbolLayer(0)
            sl.setStrokeColor(QColor(90, 90, 90)); sl.setStrokeWidth(stroke_w)
            sl.setFillColor(QColor(255, 255, 255, 0))
        except Exception: pass
    return sh


def _lyr_color(name, default):
    l = _lyr(name)
    if not l:
        return default
    try:
        return l.renderer().symbol().color().name()
    except Exception:
        return default


def _role_color(role, default):
    """Colour of the SAME layer the map draws for this role (group-first resolution).
    Using _role() — not a raw whole-project name scan — avoids grabbing a Phase-1
    'Drop Cable' when the map draws the Phase-2 'Drop Cable v1' (legend/map mismatch)."""
    l = _role(role)
    if l is not None:
        try:
            return l.renderer().symbol().color().name()
        except Exception:
            pass
    # last-ditch: any resolvable candidate by name
    for name in CFG["roles"].get(role, []):
        c = _lyr_color(name, None)
        if c:
            return c
    return default


def _render_legend_symbols():
    """Render each point role's ACTUAL symbol to a small PNG so the legend shows the real physical symbols."""
    from qgis.core import QgsSymbolLayerUtils
    from qgis.PyQt.QtCore import QSize
    d = CFG["legend_dir"]
    os.makedirs(d, exist_ok=True)
    out = {}

    def render(sym, name, w=200, h=200, mm=44):
        # render the REAL symbol big + anti-aliased so it FILLS the box (bold, not a tiny
        # marker floating in white). 200px source at ~44mm marker = crisp and prominent.
        if sym is None:
            return
        try:
            s2 = sym.clone()
            try:
                if hasattr(s2, "setSize"):
                    s2.setSize(mm)
            except Exception:
                pass
            pm = QgsSymbolLayerUtils.symbolPreviewPixmap(s2, QSize(w, h))
            path = f"{d}/{name}.png"
            pm.save(path)
            out[name] = path
        except Exception as e:
            print("legend sym err", name, e)

    def rsym(role):
        l = _role(role)
        if not l:
            return None
        r = l.renderer()
        try:
            if hasattr(r, "symbol"):
                s = r.symbol()
                if s is not None:
                    return s
        except Exception:
            pass
        try:
            from qgis.core import QgsRenderContext
            ss = r.symbols(QgsRenderContext())
            return ss[0] if ss else None
        except Exception:
            return None

    def enc(contains):
        l = _p2_enclosure()
        if not l:
            return None
        r = l.renderer()
        if not hasattr(r, "categories"):
            return r.symbol() if hasattr(r, "symbol") else None
        for c in r.categories():
            if contains.lower() in str(c.value()).lower():
                return c.symbol()
        return None

    # points only (rendered big + crisp); lines are drawn as coloured bars in the HTML
    for _label, key in CFG["legend_points"]:
        if key == "enc_splice":
            render(rsym("enc_splice") or enc("splice"), "enc_splice")
        elif key == "enc_conn":
            render(rsym("enc_conn") or enc("connect"), "enc_conn")
        else:
            render(rsym(key), key)
    return out


def _fill_or_color(spec):
    """Resolve a legend fill spec: a layer name (read its fill colour), "r,g,b", or "#hex"."""
    l = _lyr(spec)
    if l is not None:
        try:
            return l.renderer().symbol().color().name()
        except Exception:
            pass
    if "," in str(spec):
        try:
            r, g, b = [int(x) for x in str(spec).split(",")[:3]]
            return f"#{r:02x}{g:02x}{b:02x}"
        except Exception:
            pass
    return spec


def _resolve_layer_list(names):
    """Resolve an explicit layer-name list to layers (group-first, then whole project),
    de-duplicated, preserving order. Used by the commercial model's detail/overview sets."""
    out = []
    seen = set()
    g = _p2_group()
    for n in names:
        l = None
        if g:
            for ch in g.findLayers():
                if ch.layer() and ch.layer().name() == n:
                    l = ch.layer(); break
        if l is None:
            l = _lyr(n)
        if l and l.id() not in seen:
            seen.add(l.id()); out.append(l)
    return out


def _geom_of(layer):
    """point / line / polygon / other for any vector layer (Qt5/6-safe)."""
    from qgis.core import QgsWkbTypes
    try:
        return {0: "point", 1: "line", 2: "polygon"}.get(
            int(QgsWkbTypes.geometryType(layer.wkbType())), "other")
    except Exception:
        return "other"


def _safe_key(s):
    return "".join(ch if ch.isalnum() else "_" for ch in str(s))


def _layer_color(layer, default="#000000"):
    try:
        r = layer.renderer()
        if hasattr(r, "symbol") and r.symbol():
            return r.symbol().color().name()
        from qgis.core import QgsRenderContext
        ss = r.symbols(QgsRenderContext())
        return ss[0].color().name() if ss else default
    except Exception:
        return default


def _poly_swatch(layer):
    """(colour, outline_only) for a polygon legend swatch: use the outline colour when the
    fill is transparent (e.g. a boundary drawn as green outline, not a black box)."""
    try:
        sym = layer.renderer().symbol()
        fill = sym.color()
        if fill.alpha() < 30:                     # transparent fill -> outline layer
            sl = sym.symbolLayer(0)
            oc = sl.strokeColor() if hasattr(sl, "strokeColor") else fill
            if oc is not None and oc.alpha() > 0:
                return oc.name(), True
        return fill.name(), False
    except Exception:
        return "#888888", False


def _render_layer_symbol(layer, key):
    """Render a layer's REAL marker symbol to a small PNG for the legend."""
    from qgis.core import QgsSymbolLayerUtils, QgsRenderContext
    from qgis.PyQt.QtCore import QSize
    d = CFG["legend_dir"]; os.makedirs(d, exist_ok=True)
    try:
        r = layer.renderer()
        sym = r.symbol() if (hasattr(r, "symbol") and r.symbol()) else None
        if sym is None:
            ss = r.symbols(QgsRenderContext()); sym = ss[0] if ss else None
        if sym is None:
            return None
        s2 = sym.clone()
        try:
            if hasattr(s2, "setSize"):
                s2.setSize(44)          # big + crisp, fills the box (was 5.5mm @ 30px -> blurry)
        except Exception:
            pass
        pm = QgsSymbolLayerUtils.symbolPreviewPixmap(s2, QSize(200, 200))
        pth = f"{d}/auto_{key}.png"; pm.save(pth)
        return pth
    except Exception as e:
        print("auto legend sym err", key, e)
        return None


def _friendly_name(layer):
    alias = CFG.get("legend_aliases", {}).get(layer.name())
    if alias:
        return alias
    n = layer.name()
    return n[:-3].strip() if n.lower().endswith(" v1") else n


def _rect_png(key, fill=None, w=44, h=14, outline=None, outline_w=1.4):
    """Render a coloured rectangle (line bar / fill swatch / outline swatch) to a PNG so it
    aligns exactly like the point-symbol images (nested HTML tables don't align)."""
    from qgis.PyQt.QtGui import QImage, QPainter, QColor, QPen, QBrush
    d = CFG["legend_dir"]; os.makedirs(d, exist_ok=True)
    S = 6
    img = QImage(int(w * S), int(h * S), QImage.Format.Format_ARGB32)
    img.fill(0)
    pa = QPainter(img)
    try:
        pa.setRenderHint(_enum(QPainter, "RenderHint.Antialiasing", "Antialiasing"), True)
    except Exception:
        pass
    pa.setBrush(QBrush(QColor(fill) if fill is not None else QColor(0, 0, 0, 0)))
    pa.setPen(QPen(QColor(outline), outline_w * S) if outline else QPen(QColor("#444444"), 0.7 * S))
    m = (outline_w * S) if outline else (0.7 * S)
    pa.drawRect(int(m), int(m), int(w * S - 2 * m), int(h * S - 2 * m))
    pa.end()
    path = os.path.join(d, f"rect_{key}.png"); img.save(path)
    return path


def _legend_rows(map_layers=None):
    """The ordered [(label, swatch_html)] rows: configured rows first (nice names/order),
    then any drawn layer not yet shown (guard rail), then the basemap note."""
    syms = _render_legend_symbols()

    def img(name, w=22, h=22):
        pth = syms.get(name)
        return f"<img src='file:///{pth}' width='{w}' height='{h}'>" if pth else ""

    def bar(key, color):
        p = _rect_png("bar_" + _safe_key(key), color, w=44, h=12)
        return f"<img src='file:///{p}' width='44' height='12'>"

    def swatch(key, color, outline_only=False):
        if outline_only:
            p = _rect_png("sw_" + _safe_key(key), None, w=26, h=15, outline=color, outline_w=1.8)
        else:
            p = _rect_png("sw_" + _safe_key(key), color, w=26, h=15, outline="#444444", outline_w=0.7)
        return f"<img src='file:///{p}' width='26' height='15'>"

    rows = [(lab, img(key)) for lab, key in CFG["legend_points"]]
    for lab, color in CFG.get("legend_outline", []):
        rows.append((lab, swatch(lab, _fill_or_color(color), outline_only=True)))
    for lab, spec in CFG.get("legend_fills", []):
        rows.append((lab, swatch(lab, _fill_or_color(spec))))
    for lab, role, default in CFG["legend_lines"]:
        rows.append((lab, bar(lab, _role_color(role, default))))

    # --- GUARD RAIL: append any DRAWN layer not already represented above ---
    if CFG.get("legend_auto") and map_layers:
        covered = set()
        for role in ("fts", "sts", "enc_splice", "enc_conn", "poles", "enclosure",
                     "primary", "secondary", "distribution", "drop"):
            rl = _role(role)
            if rl is not None:
                covered.add(rl.id())
        bm = _lyr(CFG["basemap"])
        bm_id = bm.id() if bm else None
        for l in map_layers:
            if l is None or l.id() == bm_id or l.id() in covered:
                continue
            covered.add(l.id())
            g = _geom_of(l)
            nm = _friendly_name(l)
            if g == "point":
                pth = _render_layer_symbol(l, _safe_key(l.name()))
                cell = f"<img src='file:///{pth}' width='22' height='22'>" if pth else ""
            elif g == "line":
                cell = bar(nm, _layer_color(l))
            elif g == "polygon":
                col, outline = _poly_swatch(l)
                cell = swatch(nm, col, outline_only=outline)
            else:
                cell = ""
            rows.append((nm, cell))
        note = CFG.get("legend_basemap_note")
        if note and bm_id is not None and any(x is not None and x.id() == bm_id for x in map_layers):
            rows.append((note, ""))
    return rows


def _legend_table(rows):
    # QTextDocument ignores <td height>, so force EVEN rows with a fixed-height transparent
    # spacer in every cell — point symbols, bars and swatches then all line up.
    from qgis.PyQt.QtGui import QImage
    d = CFG["legend_dir"]; os.makedirs(d, exist_ok=True)
    spacer = ""
    try:
        sp = os.path.join(d, "spacer.png")
        _im = QImage(1, 28, QImage.Format.Format_ARGB32); _im.fill(0)   # transparent
        _im.save(sp)
        spacer = f"<img src='file:///{sp}' width='1' height='28'>"
    except Exception:
        pass
    trs = "".join(
        f"<tr><td valign='middle'>{spacer}{k}</td>"
        f"<td width='66' align='center' valign='middle'>{spacer}{v}</td></tr>"
        for k, v in rows)
    return (f"<table cellpadding='0' cellspacing='0' width='100%' "
            f"style='font-family:Arial;font-size:9px;color:#000000'>"
            f"<tr><td colspan='2' align='center' style='font-weight:bold;font-size:11px;"
            f"text-decoration:underline;padding-bottom:8px'>LEGEND</td></tr>{trs}</table>")


def build_legend_html(map_layers=None):
    return _legend_table(_legend_rows(map_layers))


def map_info_html():
    """Scale + projection block for the sidebar (matches the reference)."""
    rows = [("Scale", CFG.get("scale_note", "As-Shown (A3)")),
            ("Projection", CFG.get("projection_note", "EPSG:4326 · WGS 84"))]
    trs = "".join(f"<tr><td style='font-weight:bold' width='42%'>{k}:</td><td>{v}</td></tr>"
                  for k, v in rows)
    return (f"<table cellpadding='3' cellspacing='0' width='100%' "
            f"style='font-family:Arial;font-size:10px;color:#000000'>{trs}</table>")


def _summary_rows():
    rows = []
    for lab, role in CFG.get("summary_roles", []):
        l = _role(role)
        if l is None:
            continue
        try:
            rows.append((lab, f"{l.featureCount():,}"))
        except Exception:
            continue
    return rows


def summary_html():
    """Project feature-count summary (fills the empty sidebar band with real detail)."""
    rows = _summary_rows()
    if not rows:
        return ""
    body = "".join(f"<tr><td>{k}</td><td align='right' style='font-weight:bold'>{v}</td></tr>"
                   for k, v in rows)
    return (f"<table cellpadding='3' cellspacing='0' border='1' width='100%' "
            f"style='font-family:Arial;font-size:9px;color:#000000'>"
            f"<tr><td colspan='2' align='center' style='font-weight:bold;font-size:10px;"
            f"text-decoration:underline'>{CFG.get('summary_title', 'PROJECT TOTALS')}</td></tr>{body}</table>")


def count_tables_html():
    """Manual count tables (commercial model) → stacked HTML tables for the sidebar."""
    tables = CFG.get("count_tables") or []
    out = []
    for t in tables:
        headers = t.get("headers", [])
        span = max(1, len(headers))
        hdr = "".join(f"<td style='font-weight:bold'>{h}</td>" for h in headers)
        body = ""
        for row in t.get("rows", []):
            body += "<tr>" + "".join(f"<td>{c}</td>" for c in row) + "</tr>"
        out.append(
            f"<table cellpadding='2' cellspacing='0' border='1' width='100%' "
            f"style='font-family:Arial;font-size:7px'>"
            f"<tr><td colspan='{span}' align='center' style='font-weight:bold;"
            f"text-decoration:underline'>{t.get('title', '')}</td></tr>"
            f"<tr>{hdr}</tr>{body}</table>")
    return "<br>".join(out)


def titleblock_html():
    rows = [("Project", CFG["project_name"]), ("Company", CFG["company"]),
            ("Designer", CFG["designer"]), ("Date", CFG["date_str"]), ("Revision", CFG["revision"])]
    trs = "".join(
        f"<tr><td style='font-weight:bold' width='42%'>{k}:</td><td align='center'>{v}</td></tr>" for k, v in rows)
    return f"<table cellpadding='4' cellspacing='0' border='1' width='100%' style='font-family:Arial;font-size:12px'>{trs}</table>"


def build_frame_commercial(layout, title_text, map_layers=None):
    """Commercial-drawing frame: full-height map (no title bar) + a stacked sidebar
    (project / COMMERCIAL DRAWING / page / created-by · LEGEND · count tables · scale · logo)."""
    MAP = dict(x=6, y=6, w=322, h=285)      # full-height map, no title bar over it
    SB_X, SB_W = 334, 80
    add_rect(layout, 3, 3, 414, 291, stroke_w=1.0)                 # outer border
    add_rect(layout, MAP["x"], MAP["y"], MAP["w"], MAP["h"], stroke_w=0.6)  # map border
    # ── title block (stacked, centred) ──
    head = ("<div style='font-family:Arial;text-align:center'>"
            f"<div style='font-size:12px;font-weight:bold'>{CFG['project_name']}</div>"
            f"<div style='font-size:11px;font-weight:bold'>{CFG.get('subtitle', '')}</div>"
            f"<div style='font-size:9px;font-weight:bold;border:1px solid #000;"
            f"margin:2px 12px;padding:1px'>{title_text}</div>"
            + (f"<div style='font-size:8px'>Created by {CFG['created_by']}</div>"
               if CFG.get("created_by") else "")
            + "</div>")
    add_label(layout, SB_X, 5, SB_W, 26, html=head)
    # ── legend ──
    add_label(layout, SB_X, 33, SB_W, 46, html=build_legend_html(map_layers), frame=True)
    # ── count tables ──
    ct = count_tables_html()
    if ct:
        add_label(layout, SB_X, 81, SB_W, 168, html=ct, align_center=True, valign_center=False)
    # ── scale note ──
    add_label(layout, SB_X, 251, SB_W, 8,
              text=f"Scale: {CFG.get('scale_note', 'As-Shown (A3)')}", size=8, bold=True)
    # ── logo (wide) at the bottom ──
    if os.path.exists(LOGO):
        logo = QgsLayoutItemPicture(layout)
        logo.setPicturePath(LOGO)
        logo.setResizeMode(_enum(QgsLayoutItemPicture, "ResizeMode.Zoom", "Zoom"))
        layout.addLayoutItem(logo)
        logo.attemptMove(mmpoint(SB_X + 6, 262)); logo.attemptResize(mmsize(68, 28))
    return MAP


def _html_panel(layout, html, x, y, w, key, frame=False):
    """Render an HTML fragment to a PNG (via QTextDocument) and place it as a Picture at
    the EXACT height of its content. Bulletproof vs QGIS's HTML-label height quirks:
    the picture is a fixed image, so it can never overflow into a neighbour, and it
    looks identical in the live designer and the headless export. Returns (item, h_mm)."""
    from qgis.PyQt.QtGui import QTextDocument, QImage, QPainter, QColor
    d = CFG["legend_dir"]; os.makedirs(d, exist_ok=True)
    base, scale = 96.0, 5.0                       # 96-dpi CSS px; 5x = ~480dpi, crisp even zoomed
    px_w = max(10, int(round(w / 25.4 * base)))
    doc = QTextDocument(); doc.setHtml(html); doc.setTextWidth(px_w)
    px_h = max(10, int(round(doc.size().height())))
    img = QImage(int(px_w * scale), int(px_h * scale), QImage.Format.Format_ARGB32)
    img.fill(QColor(255, 255, 255))
    pa = QPainter(img)
    try:
        pa.setRenderHint(_enum(QPainter, "RenderHint.Antialiasing", "Antialiasing"), True)
        pa.setRenderHint(_enum(QPainter, "RenderHint.TextAntialiasing", "TextAntialiasing"), True)
    except Exception:
        pass
    pa.setPen(QColor(0, 0, 0))
    pa.scale(scale, scale)
    doc.drawContents(pa)
    pa.end()
    path = os.path.join(d, f"panel_{key}.png"); img.save(path)
    h_mm = px_h / base * 25.4
    pic = QgsLayoutItemPicture(layout)
    pic.setPicturePath(path)
    pic.setResizeMode(_enum(QgsLayoutItemPicture, "ResizeMode.Stretch", "Stretch"))
    layout.addLayoutItem(pic)
    pic.attemptMove(mmpoint(x, y)); pic.attemptResize(mmsize(w, h_mm))
    if frame:
        pic.setFrameEnabled(True)
        pic.setFrameStrokeColor(QColor(0, 0, 0))
        pic.setFrameStrokeWidth(QgsLayoutMeasurement(0.4, MM))
    return pic, h_mm


def build_frame(layout, title_text, map_layers=None):
    if CFG.get("frame_style") == "commercial":
        return build_frame_commercial(layout, title_text, map_layers)
    # geometry (mm) for A3 landscape 420x297
    MAP = dict(x=6, y=28, w=322, h=263)
    SB_W = 80.0
    # centre the sidebar in the white band between the map's right edge and the border
    _white_l = MAP["x"] + MAP["w"]      # 328
    _white_r = 417.0                    # inner border right
    SB_X = round(_white_l + (_white_r - _white_l - SB_W) / 2.0, 1)   # 332.5
    PAGE_H = 297.0
    add_rect(layout, 3, 3, 414, 291, stroke_w=1.0)          # outer border
    # title bar
    add_rect(layout, MAP["x"], 6, MAP["w"], 18, stroke_w=0.8)
    add_label(layout, MAP["x"], 6, MAP["w"], 18,
              html=f"<div style='font-family:Arial;font-size:19px;font-weight:bold;text-decoration:underline'>{title_text}</div>")

    # ── legend — pre-rendered image at its exact content height (never overflows) ──
    leg_rows = _legend_rows(map_layers)
    _leg, h_leg = _html_panel(layout, _legend_table(leg_rows), SB_X, 6, SB_W, "legend", frame=True)

    # ── title block — HTML label with a generous fixed box (few rows), bottom-anchored ──
    h_title = 46.0
    title_y = PAGE_H - 3.0 - h_title
    add_label(layout, SB_X, title_y, SB_W, h_title, html=titleblock_html(), valign_center=False)

    # ── middle blocks: build them (measured), then distribute evenly in the free band ──
    band_top = 6.0 + h_leg

    def _place_north(y):
        if NORTH_SVG:
            pic = QgsLayoutItemPicture(layout)
            pic.setPicturePath(NORTH_SVG)
            layout.addLayoutItem(pic)
            pic.attemptMove(mmpoint(SB_X + 28, y)); pic.attemptResize(mmsize(24, 24))
        add_label(layout, SB_X, y + 24, SB_W, 7, text="N", size=11, bold=True)

    def _place_logo(y):
        if os.path.exists(LOGO):
            logo = QgsLayoutItemPicture(layout)
            logo.setPicturePath(LOGO)
            logo.setResizeMode(_enum(QgsLayoutItemPicture, "ResizeMode.Zoom", "Zoom"))
            layout.addLayoutItem(logo)
            logo.attemptMove(mmpoint(SB_X + 16, y)); logo.attemptResize(mmsize(48, 28))

    items = [(31.0, _place_north), (28.0, _place_logo)]
    if CFG.get("show_map_info"):
        mi, h_mi = _html_panel(layout, map_info_html(), SB_X, band_top, SB_W, "mapinfo", frame=True)
        items.append((h_mi, lambda y, it=mi: it.attemptMove(mmpoint(SB_X, y))))
    if CFG.get("show_summary"):
        sm_html = summary_html()
        if sm_html:
            sm, h_sm = _html_panel(layout, sm_html, SB_X, band_top, SB_W, "summary")
            items.append((h_sm, lambda y, it=sm: it.attemptMove(mmpoint(SB_X, y))))

    total = sum(h for h, _ in items)
    gap = max(3.0, (title_y - band_top - total) / (len(items) + 1))
    y = band_top + gap
    for h, place in items:
        place(y)
        y += h + gap
    return MAP


def make_map(layout, MAP, layers, extent=None, atlas_driven=False, margin=0.10):
    m = QgsLayoutItemMap(layout)
    m.setId("mainmap")
    layout.addLayoutItem(m)
    m.attemptMove(mmpoint(MAP["x"], MAP["y"])); m.attemptResize(mmsize(MAP["w"], MAP["h"]))
    m.setLayers(layers)
    m.setFrameEnabled(True); m.setFrameStrokeWidth(QgsLayoutMeasurement(0.4, MM))
    m.setBackgroundColor(QColor(255, 255, 255))
    # NOTE: QGIS4 setExtent() RESIZES the item to the extent's aspect. For a fixed page
    # frame we must only ever hand it an extent that already matches the item aspect.
    if extent is not None and not atlas_driven:
        m.setExtent(extent)                        # overview: caller pre-fit to item aspect
    if atlas_driven:
        # Atlas "Auto" sets the per-feature extent itself (fitting it INSIDE this frame),
        # so we do NOT setExtent() here — that would resize the frame off the page.
        m.setAtlasDriven(True)
        m.setAtlasScalingMode(ATLAS_AUTO)
        m.setAtlasMargin(margin)
    # lock the frame to the page-fitting size (belt-and-suspenders vs any resize)
    m.attemptMove(mmpoint(MAP["x"], MAP["y"])); m.attemptResize(mmsize(MAP["w"], MAP["h"]))
    # remember the designed frame so the page-view atlas can RE-lock after preview resizes it
    # (QGIS4 atlas preview grows the frame to the first feature's aspect once; re-locking
    # once makes it hold across all features — verified).
    try:
        m.setCustomProperty("hld_frame_x", float(MAP["x"]))
        m.setCustomProperty("hld_frame_y", float(MAP["y"]))
        m.setCustomProperty("hld_frame_w", float(MAP["w"]))
        m.setCustomProperty("hld_frame_h", float(MAP["h"]))
    except Exception:
        pass
    return m


def remove_layout(name):
    lm = p.layoutManager()
    ex = lm.layoutByName(name)
    if ex is not None:
        lm.removeLayout(ex)


def new_layout(name):
    remove_layout(name)
    layout = QgsPrintLayout(p)
    layout.initializeDefaults()
    layout.setName(name)
    pc = layout.pageCollection()
    pg = pc.page(0)
    pg.setPageSize("A3", LAND)
    return layout


def _restore_aoi():
    aoi = _lyr(CFG["aoi_layer"])
    if aoi is not None:
        try:
            aoi.setOpacity(1.0)
            if CFG.get("aoi_subset"):
                aoi.setSubsetString(CFG["aoi_subset"])
            aoi.triggerRepaint()
        except Exception:
            pass
    return aoi


def _greenfield_extent():
    aoi = _lyr(CFG["aoi_layer"])
    if aoi is None:
        return None
    nmf = next((f.name() for f in aoi.fields() if f.name().lower() == "name"), None)
    ext = QgsRectangle(); ext.setMinimal(); n = 0
    for f in aoi.getFeatures():
        v = str(f[nmf]) if nmf else ""
        if "greenfield" in v.lower():
            g = f.geometry()
            if g and not g.isEmpty():
                ext.combineExtentWith(g.boundingBox()); n += 1
    return ext if n else None


def _aoi_geometry():
    """Union polygon of the AOI (greenfield) features; returns (geometry, crs) or (None, None).
    Honours aoi_subset (already applied by _restore_aoi); else keeps only 'greenfield' rows."""
    aoi = _restore_aoi()
    if aoi is None:
        return None, None
    from qgis.core import QgsGeometry
    nmf = next((f.name() for f in aoi.fields() if f.name().lower() == "name"), None)
    has_subset = bool(aoi.subsetString())
    geom = None
    for f in aoi.getFeatures():
        if nmf and not has_subset and "greenfield" not in str(f[nmf]).lower():
            continue
        g = f.geometry()
        if g and not g.isEmpty():
            geom = QgsGeometry(g) if geom is None else geom.combine(g)
    return geom, aoi.crs()


def _metres_to_units(cw, ch, crs, ext):
    """Cell width/height in metres -> layer units. For geographic CRS, convert with a
    latitude correction so cells are ~square on the ground."""
    import math
    if crs is not None and crs.isGeographic():
        lat = (ext.yMinimum() + ext.yMaximum()) / 2.0
        dx = cw / (111320.0 * max(0.15, math.cos(math.radians(lat))))
        dy = ch / 110540.0
        return dx, dy
    return cw, ch


def _generate_grid():
    """Auto-tile the AOI into a grid at the configured cell size; add it as a memory layer
    (in the project, not the tree) and return it. Only cells touching the AOI are kept and
    numbered 1..N (row-major, top-to-bottom). No-op unless grid_cell_w_m/h_m are set."""
    import math
    from qgis.core import QgsVectorLayer, QgsField, QgsFeature, QgsGeometry, QgsRectangle
    from qgis.PyQt.QtCore import QVariant
    cw = float(CFG.get("grid_cell_w_m") or 0.0)
    ch = float(CFG.get("grid_cell_h_m") or 0.0)
    if cw <= 0 or ch <= 0:
        return None
    geom, crs = _aoi_geometry()
    if geom is None:
        pon = _role("coverage")
        if pon is None:
            return None
        geom = QgsGeometry.fromRect(pon.extent()); crs = pon.crs()
    ext = geom.boundingBox()
    dx, dy = _metres_to_units(cw, ch, crs, ext)
    if dx <= 0 or dy <= 0:
        return None
    name = CFG.get("grid_layer_name", "HLD Grid")
    for l in list(p.mapLayers().values()):
        if l.name() == name:
            p.removeMapLayer(l.id())
    vl = QgsVectorLayer(f"Polygon?crs={crs.authid()}", name, "memory")
    dp = vl.dataProvider()
    dp.addAttributes([QgsField("cell_no", QVariant.Int)]); vl.updateFields()
    nx = max(1, int(math.ceil(ext.width() / dx)))
    ny = max(1, int(math.ceil(ext.height() / dy)))
    feats = []; k = 0
    for j in range(ny):                       # top row first -> readable numbering
        for i in range(nx):
            x0 = ext.xMinimum() + i * dx
            y1 = ext.yMaximum() - j * dy
            cell = QgsGeometry.fromRect(QgsRectangle(x0, y1 - dy, x0 + dx, y1))
            if not cell.intersects(geom):
                continue
            k += 1
            feat = QgsFeature(vl.fields())
            feat.setGeometry(cell); feat.setAttribute("cell_no", k)
            feats.append(feat)
    dp.addFeatures(feats); vl.updateExtents()
    # add to the layer TREE (True) so the overview map theme can include the numbered grid
    # (map themes only capture tree layers), then UNCHECK it so it doesn't clutter the live
    # canvas — the overview theme record still shows it explicitly.
    p.addMapLayer(vl, True)
    try:
        node = p.layerTreeRoot().findLayer(vl.id())
        if node is not None:
            node.setItemVisibilityChecked(False)
    except Exception:
        pass
    print(f"grid: {k} cells ({nx}x{ny} scan) at {cw:.0f}x{ch:.0f} m")
    return vl


def _style_labels():
    """Cable/pole/splitter labels ON with white halos (per CFG['labels']); OFF where configured None."""
    from qgis.core import (QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                           QgsVectorLayerSimpleLabeling, QgsUnitTypes)
    from qgis.PyQt.QtGui import QColor, QFont
    PT = _enum(QgsUnitTypes, "RenderUnit.RenderPoints", "RenderPoints")
    MMU = _enum(QgsUnitTypes, "RenderUnit.RenderMillimeters", "RenderMillimeters")

    def field(layer, *cands):
        names = [f.name() for f in layer.fields()]
        for c in cands:
            if c in names:
                return c
        return names[0] if names else None

    def lbl(layer, size, along_line, buf=0.8, strip=None):
        if layer is None:
            return
        s = QgsPalLayerSettings()
        fld = field(layer, "label", "Label", "name")
        if strip:
            s.fieldName = 'replace("' + fld + '", \'' + strip + '\', \'\')'
            s.isExpression = True
        else:
            s.fieldName = fld
        s.enabled = True
        fmt = QgsTextFormat(); fmt.setFont(QFont("Arial")); fmt.setSize(size)
        try: fmt.setSizeUnit(PT)
        except Exception: pass
        b = QgsTextBufferSettings(); b.setEnabled(True); b.setSize(buf); b.setColor(QColor(255, 255, 255))
        try: b.setSizeUnit(MMU)
        except Exception: pass
        fmt.setBuffer(b); s.setFormat(fmt)
        try:
            s.placement = (_enum(QgsPalLayerSettings, "Placement.Curved", "Curved", "Line") if along_line
                           else _enum(QgsPalLayerSettings, "Placement.AroundPoint", "AroundPoint", "OverPoint"))
        except Exception: pass
        # scale-based: labels ONLY when zoomed into a page (detail export) -> full-project canvas stays fast
        s.scaleVisibility = True
        s.minimumScale = float(CFG["label_min_scale"])
        s.maximumScale = 0.0
        layer.setLabeling(QgsVectorLayerSimpleLabeling(s))
        layer.setLabelsEnabled(True)   # NO triggerRepaint -> don't force a heavy canvas re-render

    def off(layer):
        if layer:
            layer.setLabelsEnabled(False)

    for role, spec in CFG["labels"].items():
        layer = _role(role)
        if spec is None:
            off(layer)
        else:
            lbl(layer, spec["size"], spec["along_line"], spec.get("buf", 0.8), spec.get("strip"))


def _rgb(spec):
    try:
        r, g, b = [int(x) for x in str(spec).split(",")[:3]]
        return QColor(r, g, b)
    except Exception:
        return QColor(spec)


def _style_enclosures():
    """Distinct colours for splice (blue) vs connectorised (cyan) enclosures — so they read
    clearly on the map AND the legend (which renders these same symbols) matches. Works for
    BOTH project shapes: separate splice/connectorised layers, or one categorized layer."""
    from qgis.core import (QgsMarkerSymbol, QgsSingleSymbolRenderer,
                           QgsCategorizedSymbolRenderer, QgsRendererCategory)

    def style_single(layer, rgb):
        if layer is None:
            return
        try:
            sym = QgsMarkerSymbol.createSimple({"name": "circle", "color": rgb,
                                                "outline_color": "40,40,40", "outline_width": "0.2", "size": "1.7"})
            layer.setRenderer(QgsSingleSymbolRenderer(sym)); layer.triggerRepaint()
        except Exception as e:
            print("enc style err", e)

    # (a) separate layers, if the project has them
    style_single(_role("enc_splice"), CFG["enc_splice_rgb"])
    style_single(_role("enc_conn"), CFG["enc_conn_rgb"])

    # (b) one categorized "Enclosure" layer -> recolour its splice/connectorised categories
    enc = _p2_enclosure()
    if enc is None:
        return
    r = enc.renderer()
    if not hasattr(r, "categories"):
        return
    try:
        cats = []
        for c in r.categories():
            v = str(c.value()).lower()
            sym = c.symbol().clone()
            if "splice" in v:
                sym.setColor(_rgb(CFG["enc_splice_rgb"]))
            elif "connect" in v:
                sym.setColor(_rgb(CFG["enc_conn_rgb"]))
            # keep every category enabled (map shows them all; don't trust a stray False)
            cats.append(QgsRendererCategory(c.value(), sym, c.label(), True))
        enc.setRenderer(QgsCategorizedSymbolRenderer(r.classAttribute(), cats))
        enc.triggerRepaint()
    except Exception as e:
        print("enc cat style err", e)


def _style_pon():
    """See-through PON fill + crisp outline; PON labels get a white halo."""
    from qgis.PyQt.QtGui import QColor
    from qgis.core import QgsVectorLayerSimpleLabeling, QgsUnitTypes
    pon = _role("coverage")
    if pon is None:
        return
    try:
        s = pon.renderer().symbol(); sl = s.symbolLayer(0)
        s.setOpacity(1.0)
        fc = sl.fillColor(); fc.setAlpha(int(CFG["pon_fill_alpha"])); sl.setFillColor(fc)
        st = sl.strokeColor(); st.setAlpha(255); sl.setStrokeColor(st)
        if pon.labeling():
            settings = pon.labeling().settings()
            fmt = settings.format()
            fmt.setSize(9)
            buf = fmt.buffer(); buf.setEnabled(True); buf.setSize(1.1)
            try:
                buf.setSizeUnit(_enum(QgsUnitTypes, "RenderUnit.RenderMillimeters", "RenderMillimeters"))
            except Exception:
                pass
            buf.setColor(QColor(255, 255, 255)); buf.setOpacity(1.0)
            fmt.setBuffer(buf)
            settings.setFormat(fmt)
            pon.setLabeling(QgsVectorLayerSimpleLabeling(settings))
        pon.triggerRepaint()
    except Exception as e:
        print("style_pon err", e)


def _style_commercial():
    """Commercial model: number the grid cells (coverage) for the overview; transparent
    fill + dark outline so the numbered grid reads over the basemap."""
    from qgis.core import (QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                           QgsVectorLayerSimpleLabeling, QgsUnitTypes, QgsFillSymbol,
                           QgsSingleSymbolRenderer)
    from qgis.PyQt.QtGui import QColor, QFont
    grid = _role("coverage")
    fld = CFG.get("coverage_label_field")
    if grid is None or not fld:
        return
    try:
        grid.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple(
            {"color": "0,0,0,0", "outline_color": "0,0,0", "outline_width": "0.4"})))
    except Exception as e:
        print("grid style err", e)
    try:
        s = QgsPalLayerSettings()
        s.fieldName = fld
        s.enabled = True
        try:
            s.centroidInside = True
        except Exception:
            pass
        try:
            s.placement = _enum(QgsPalLayerSettings, "Placement.Horizontal", "Horizontal",
                                "AroundPoint", "OverPoint")
        except Exception:
            pass
        fmt = QgsTextFormat(); fmt.setFont(QFont("Arial")); fmt.setSize(18)
        try:
            fmt.setSizeUnit(_enum(QgsUnitTypes, "RenderUnit.RenderPoints", "RenderPoints"))
        except Exception:
            pass
        b = QgsTextBufferSettings(); b.setEnabled(True); b.setSize(1.2); b.setColor(QColor(255, 255, 255))
        fmt.setBuffer(b); s.setFormat(fmt)
        grid.setLabeling(QgsVectorLayerSimpleLabeling(s))
        grid.setLabelsEnabled(True)
    except Exception as e:
        print("grid label err", e)


# ---- OVERVIEW (report header / page 1) ----
def _make_overview():
    name = CFG["layout_overview"]
    layout = new_layout(name)
    basemap = _lyr(CFG["basemap"])
    aoi = _restore_aoi()
    pon = _role("coverage")
    if CFG.get("overview_layers"):
        # commercial: explicit overview layer set (numbered grid + zoning + boundary + basemap)
        ov_layers = _resolve_layer_list(CFG["overview_layers"])
        ext = pon.extent() if pon else _greenfield_extent()
        gf_ext = _greenfield_extent()
        if gf_ext:
            ext.combineExtentWith(gf_ext)
    else:
        primary = _role("primary")
        secondary = _role("secondary")
        # OVERVIEW = PON numbers + primary & secondary FEEDER ROUTES only
        ov_layers = [l for l in (primary, secondary, pon, aoi, basemap) if l]
        ext = _greenfield_extent()
        if ext is None:
            ext = pon.extent()
        ext.combineExtentWith(pon.extent())   # every PON guaranteed in
        for _fl in (primary, secondary):      # include feeder routes so none run off the edge
            if _fl:
                ext.combineExtentWith(_fl.extent())
    # frame AFTER the layer list is known -> legend auto-completes from what's drawn
    MAP = build_frame(layout, CFG["title_overview"], map_layers=ov_layers)
    ext.scale(1.04)
    # force the extent to EXACTLY the map-item aspect (add to the shorter side) -> fills, no white bands
    target_ar = MAP["w"] / MAP["h"]
    cur_ar = ext.width() / ext.height()
    c = ext.center()
    if cur_ar > target_ar:                # too wide -> add height
        nh = ext.width() / target_ar
        ext.setYMinimum(c.y() - nh / 2); ext.setYMaximum(c.y() + nh / 2)
    else:                                 # too tall -> add width
        nw = ext.height() * target_ar
        ext.setXMinimum(c.x() - nw / 2); ext.setXMaximum(c.x() + nw / 2)
    make_map(layout, MAP, ov_layers, extent=ext)
    return layout                       # owned by the report (not added to the manager)


# ---- DETAIL (report body / one page per coverage feature) ----
def _make_detail():
    name = CFG["layout_atlas"]
    layout = new_layout(name)
    gf = _restore_aoi()
    if CFG.get("detail_layers"):
        # commercial: explicit detail layer set (zoning + SDU + boundary + basemap; NO grid overlay)
        layers = _resolve_layer_list(CFG["detail_layers"])
    else:
        # take exactly the visible group layers (adapts to renames); drop clutter + feeders
        feeder_names = set(CFG["roles"].get("primary", [])) | set(CFG["roles"].get("secondary", []))
        det_layers = _p2_visible_layers(exclude=set(CFG["detail_exclude"]) | feeder_names)
        if not det_layers:
            # no group (e.g. saved 'HLD only' project) -> known network layers, NO feeders
            seen = set(); det_layers = []
            for n in CFG["detail_fallback"]:
                l = _lyr(n)
                if l and l.id() not in seen:
                    seen.add(l.id()); det_layers.append(l)
        bm = _lyr(CFG["basemap"])
        layers = det_layers + [l for l in (gf, bm) if l]
    # frame AFTER the layer list is known -> legend auto-completes from what's drawn
    MAP = build_frame(layout, CFG["title_atlas_expr"], map_layers=layers)
    pon = _role("coverage")
    # atlas-driven map => the report field-group sets the current feature and this map
    # zooms/fits to it (proven: each body page frames its own PON inside the fixed frame).
    make_map(layout, MAP, layers, extent=pon.extent(), atlas_driven=True, margin=float(CFG["atlas_margin"]))
    return layout                       # owned by the report (not added to the manager)


def build_report():
    """Assemble ONE editable Report: header = overview (page 1), field-group body =
    one detail page per coverage feature. Exports to a single PDF (overview first)."""
    from qgis.core import QgsReport, QgsReportSectionFieldGroup
    name = CFG["layout_report"]
    lm = p.layoutManager()
    # drop any previous run's report + its stray header/body layouts
    for nm in (name, CFG["layout_overview"], CFG["layout_atlas"]):
        ex = lm.layoutByName(nm)
        if ex is not None:
            lm.removeLayout(ex)
    overview = _make_overview()
    detail = _make_detail()
    pon = _role("coverage")
    rep = QgsReport(p)
    rep.setName(name)
    rep.setHeaderEnabled(True)
    rep.setHeader(overview)             # PAGE 1
    fg = QgsReportSectionFieldGroup()
    fg.setLayer(pon)
    fg.setField(CFG["coverage_sort_field"])   # one body page per value, ascending
    try:
        fg.setSortAscending(True)
    except Exception:
        pass
    fg.setBody(detail)
    fg.setBodyEnabled(True)
    rep.appendChild(fg)
    lm.addLayout(rep)
    return name


def _book_layer_sets():
    """(overview_layers, detail_layers, all_layers) for the unified atlas. The overview page
    shows the grid (if grid mode) or feeders + PON + AOI + basemap; detail pages show the
    full network. The grid coverage layer never shows on the detail pages."""
    basemap = _lyr(CFG["basemap"])
    aoi = _restore_aoi()
    if CFG.get("overview_layers"):
        overview_layers = _resolve_layer_list(CFG["overview_layers"])   # grid mode: numbered grid + net
    else:
        net_cov = _role("coverage")
        primary = _role("primary"); secondary = _role("secondary")
        overview_layers = [l for l in (primary, secondary, net_cov, aoi, basemap) if l]
    feeder_names = set(CFG["roles"].get("primary", [])) | set(CFG["roles"].get("secondary", []))
    exclude = set(CFG["detail_exclude"]) | feeder_names | {CFG.get("grid_layer_name", "HLD Grid")}
    det = _p2_visible_layers(exclude=exclude)
    if not det:
        seen = set(); det = []
        for n in CFG["detail_fallback"]:
            l = _lyr(n)
            if l and l.id() not in seen:
                seen.add(l.id()); det.append(l)
    detail_layers = det + [l for l in (aoi, basemap) if l]
    allm = []; seen = set()
    for l in overview_layers + detail_layers:
        if l and l.id() not in seen:
            seen.add(l.id()); allm.append(l)
    return overview_layers, detail_layers, allm


def _build_book_coverage():
    """Unified atlas coverage: an OVERVIEW feature (whole AOI) FIRST, then one feature per
    network coverage unit (PON/Zone). Fields: seq (sort), is_overview, unit (page label)."""
    from qgis.core import QgsVectorLayer, QgsField, QgsFeature, QgsGeometry
    from qgis.PyQt.QtCore import QVariant
    cov = _role("coverage")
    if cov is None:
        return None
    name = "HLD Book Pages"
    for l in list(p.mapLayers().values()):
        if l.name() == name:
            p.removeMapLayer(l.id())
    vl = QgsVectorLayer(f"Polygon?crs={cov.crs().authid()}", name, "memory")
    dp = vl.dataProvider()
    dp.addAttributes([QgsField("seq", QVariant.Int), QgsField("is_overview", QVariant.Int),
                      QgsField("unit", QVariant.String)])
    vl.updateFields()
    geom, _crs = _aoi_geometry()
    if geom is None:
        g = None
        for f in cov.getFeatures():
            fg = f.geometry()
            if fg and not fg.isEmpty():
                g = QgsGeometry(fg) if g is None else g.combine(fg)
        geom = g
    feats = []
    ovf = QgsFeature(vl.fields())
    if geom is not None:
        ovf.setGeometry(geom)
    ovf.setAttribute("seq", 0); ovf.setAttribute("is_overview", 1); ovf.setAttribute("unit", "Overview")
    feats.append(ovf)
    sf = CFG["coverage_sort_field"]
    rows = sorted(cov.getFeatures(), key=lambda f: (f[sf] is None, f[sf]))
    for i, f in enumerate(rows, start=1):
        nf = QgsFeature(vl.fields()); nf.setGeometry(f.geometry())
        nf.setAttribute("seq", i); nf.setAttribute("is_overview", 0)
        nf.setAttribute("unit", "" if f[sf] is None else str(f[sf]))
        feats.append(nf)
    dp.addFeatures(feats); vl.updateExtents()
    p.addMapLayer(vl, False)
    return vl


def _register_book_themes(overview_layers, detail_layers):
    """Two map themes the unified atlas map switches between per page: HLD_Overview
    (feeders + coverage + AOI + basemap) and HLD_Detail (full network)."""
    from qgis.core import QgsMapThemeCollection
    mtc = p.mapThemeCollection()

    def rec(layers):
        r = QgsMapThemeCollection.MapThemeRecord()
        for l in layers:
            if l is None:
                continue
            lr = QgsMapThemeCollection.MapThemeLayerRecord(l)
            try:
                lr.usingCurrentStyle = True
            except Exception:
                pass
            r.addLayerRecord(lr)
        return r

    for nm in ("HLD_Overview", "HLD_Detail"):
        if mtc.hasMapTheme(nm):
            mtc.removeMapTheme(nm)
    mtc.insert("HLD_Overview", rec(overview_layers))
    mtc.insert("HLD_Detail", rec(detail_layers))


def build_unified_atlas():
    """ONE atlas book: page 1 = overview (whole project, feeders + PON only), then one
    detail page per unit (full network). Flip overview -> PONs in a single editable layout;
    export gives the same book. The map switches map-theme per page (data-defined)."""
    from qgis.core import (QgsProperty, QgsLayoutObject, QgsLayoutItemMap)
    lm = p.layoutManager()
    for nm in (CFG["layout_report"], CFG["layout_overview"], CFG["layout_atlas"]):
        ex = lm.layoutByName(nm)
        if ex is not None:
            lm.removeLayout(ex)
    ov_set, det_set, all_set = _book_layer_sets()
    _register_book_themes(ov_set, det_set)
    cover = _build_book_coverage()
    if cover is None:
        return build_report()                 # no coverage -> fall back
    # per-page title: "<project> Overview" on page 1, else the normal per-unit heading
    proj = str(CFG["project_name"]).replace("'", "''")
    prefix = str(CFG.get("title_atlas_expr", f"{CFG['project_name']} - PON ")).split("[%")[0]
    prefix = prefix.replace("'", "''")
    CFG["title_atlas_expr"] = (f"[% if(\"is_overview\"=1, '{proj} Overview', "
                               f"'{prefix}' || \"unit\") %]")
    layout = new_layout(CFG["layout_atlas"])
    MAP = build_frame(layout, CFG["title_atlas_expr"], map_layers=det_set)
    make_map(layout, MAP, all_set, atlas_driven=True, margin=float(CFG["atlas_margin"]))
    m = next((it for it in layout.items() if isinstance(it, QgsLayoutItemMap)), None)
    if m is not None:
        try:
            m.setFollowVisibilityPreset(True)
            expr = "if(attribute(@atlas_feature,'is_overview')=1,'HLD_Overview','HLD_Detail')"
            m.dataDefinedProperties().setProperty(
                QgsLayoutObject.DataDefinedProperty.MapStylePreset,
                QgsProperty.fromExpression(expr))
        except Exception as e:
            print("book theme dd err", e)
    at = layout.atlas()
    at.setEnabled(True)
    at.setCoverageLayer(cover)
    at.setSortFeatures(True)
    at.setSortExpression('"seq"')
    at.setFilenameExpression("'page_' || \"seq\"")
    lm.addLayout(layout)
    return CFG["layout_atlas"]


def build_page_layouts():
    """Build the overview + detail as standalone, PAGE-VIEW print layouts in the Layout
    Manager (WYSIWYG editing — you see + tweak each page immediately). The detail is a
    normal atlas: one page per coverage feature. Used by 'Open in Print Layout'."""
    lm = p.layoutManager()
    for nm in (CFG["layout_report"], CFG["layout_overview"], CFG["layout_atlas"]):
        ex = lm.layoutByName(nm)
        if ex is not None:
            lm.removeLayout(ex)
    overview = _make_overview()
    lm.addLayout(overview)
    detail = _make_detail()
    cov = _role("coverage")
    at = detail.atlas()
    at.setEnabled(True)
    at.setCoverageLayer(cov)
    at.setHideCoverage(bool(CFG.get("hide_coverage", False)))
    at.setSortFeatures(True)
    at.setSortExpression('"' + CFG["coverage_sort_field"] + '"')
    at.setFilenameExpression(CFG.get("atlas_filename_expr") or ('"' + CFG["coverage_sort_field"] + '"'))
    lm.addLayout(detail)
    return CFG["layout_overview"], CFG["layout_atlas"]


def build_all():
    """Style the layers + build the Report (safe on the GUI thread; no-op headless)."""
    try:
        from qgis.utils import iface as _iface
        _canvas = _iface.mapCanvas() if _iface else None
    except Exception:
        _canvas = None
    if _canvas is not None:
        _canvas.setRenderFlag(False)
    try:
        # ── GRID MODE: auto-tile the AOI, switch coverage to the grid (one page per cell) ──
        grid_mode = float(CFG.get("grid_cell_w_m") or 0.0) > 0.0
        if grid_mode:
            grid = _generate_grid()
            if grid is None:
                grid_mode = False                     # couldn't build (no AOI) -> normal coverage
            else:
                CFG["roles"] = dict(CFG.get("roles", {}))
                CFG["roles"]["coverage"] = [grid.name()]
                CFG["coverage_sort_field"] = "cell_no"
                CFG["coverage_label_field"] = "cell_no"
                CFG["hide_coverage"] = True
                CFG["atlas_filename_expr"] = "'grid_' || \"cell_no\""
                CFG["title_atlas_expr"] = f'{CFG["project_name"]} - Grid [% "cell_no" %]'
                # grid overview = the NUMBERED grid + feeders + boundary + basemap
                # (NOT the PON zones — those clutter the numbered-grid page)
                ov = [grid.name()]
                for _r in ("primary", "secondary"):
                    _l = _role(_r)
                    if _l:
                        ov.append(_l.name())
                for _n in (CFG["aoi_layer"], CFG["basemap"]):
                    _l = _lyr(_n)
                    if _l:
                        ov.append(_l.name())
                CFG["overview_layers"] = ov

        if CFG.get("frame_style") == "commercial":
            _style_commercial()
        else:
            _style_enclosures()
            _style_pon()
            _style_labels()
            if grid_mode:
                _style_commercial()                   # numbers the grid cells on the overview
        if CFG.get("frame_style") == "commercial":
            # commercial keeps the report-or-page-layouts flow
            if CFG.get("build_mode") == "layouts":
                res = build_page_layouts()
                print("BUILT PAGE LAYOUTS:", res)
            else:
                res = build_report()
                print("BUILT REPORT:", res)
        else:
            # standard HLD *and* grid: ONE book atlas — overview page 1 (grid = numbered grid,
            # else feeders + PON) then flip -> every detail page. Serves editing + export.
            res = build_unified_atlas()
            print("BUILT UNIFIED ATLAS:", res, "| grid:", grid_mode)
        return res
    finally:
        if _canvas is not None:
            try:
                _ext = _greenfield_extent()
                if _ext is not None:
                    _ext.scale(1.1); _canvas.setExtent(_ext)
            except Exception:
                pass
            _canvas.setRenderFlag(True)


# run on exec (preserves the original drop-in behaviour)
build_all()
