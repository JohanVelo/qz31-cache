"""ui_smooth — render-only smoothing for heavy layers (bundled; native QGIS + stdlib).

Makes pan/zoom smoother on big projects WITHOUT touching any data: applies QGIS's
own geometry-simplification at render time to heavy vector layers (>THRESH
features). Simplification is purely visual + reversible (the stored geometry is
untouched) and uses a sub-pixel tolerance, so the map looks identical but draws
2-5x faster when zoomed out. Toggleable via QSettings (default ON); fail-silent.

  from fibre_automation import ui_smooth
  ui_smooth.apply(project)        # optimize heavy layers' render path
  ui_smooth.set_enabled(False)    # operator opt-out (settings)
"""
_KEY = "VelocityFibre/renderSmoothing"
_CANVAS_KEY = "VelocityFibre/renderSmoothing.canvasPrior"   # "parallel,caching" before we changed it
HEAVY_FEATURES = 500          # only optimize layers above this many features
THRESHOLD_PX = 1.0            # sub-pixel render tolerance (visually identical)


def enabled():
    try:
        from qgis.core import QgsSettings
        return QgsSettings().value(_KEY, True, type=bool)
    except Exception:
        return True


def set_enabled(on):
    try:
        from qgis.core import QgsSettings
        QgsSettings().setValue(_KEY, bool(on))
    except Exception:
        pass


def _simplify_method():
    from qgis.core import QgsVectorSimplifyMethod
    m = QgsVectorSimplifyMethod()

    def _enum(name, *fallbacks):
        # tolerate scoped vs unscoped enum names across QGIS versions
        for holder in (getattr(QgsVectorSimplifyMethod, "SimplifyHint", None),
                       getattr(QgsVectorSimplifyMethod, "SimplifyAlgorithm", None),
                       QgsVectorSimplifyMethod):
            if holder is not None and hasattr(holder, name):
                return getattr(holder, name)
        for fb in fallbacks:
            for holder in (QgsVectorSimplifyMethod,):
                if hasattr(holder, fb):
                    return getattr(holder, fb)
        return None
    try:
        hint = _enum("GeometrySimplification")
        if hint is not None:
            m.setSimplifyHints(hint)
        alg = _enum("Distance")
        if alg is not None:
            m.setSimplifyAlgorithm(alg)
    except Exception:
        pass
    try:
        m.setThreshold(THRESHOLD_PX)
        m.setForceLocalOptimization(True)
    except Exception:
        pass
    return m


def apply(project=None):
    """Apply render smoothing to heavy vector layers. Returns count optimized.
    Render-only — never edits geometry. No-op if disabled. Never raises."""
    if not enabled():
        return 0
    n = 0
    try:
        from qgis.core import QgsProject, QgsVectorLayer
        project = project or QgsProject.instance()
        method = _simplify_method()
        for lyr in project.mapLayers().values():
            try:
                if (isinstance(lyr, QgsVectorLayer) and lyr.isValid()
                        and lyr.geometryType() != 0       # skip points (nothing to simplify)
                        and lyr.featureCount() >= HEAVY_FEATURES):
                    lyr.setSimplifyMethod(method)
                    n += 1
            except Exception:
                continue
    except Exception:
        return n
    return n


def _canvas(iface=None):
    """The active map canvas (via iface if given, else the QGIS singleton)."""
    try:
        if iface is not None and hasattr(iface, 'mapCanvas'):
            return iface.mapCanvas()
    except Exception:
        pass
    try:
        from qgis.utils import iface as _if
        return _if.mapCanvas() if _if else None
    except Exception:
        return None


def apply_canvas(iface=None):
    """Turn ON the canvas-level render boosts — parallel (multi-threaded) layer
    rendering + render caching (reuse cached tiles on pan/zoom). Both are visually
    LOSSLESS and native to QGIS. The prior state is saved once so restore_canvas()
    can put it back exactly. No-op if disabled; never raises."""
    if not enabled():
        return False
    canvas = _canvas(iface)
    if canvas is None:
        return False
    try:
        from qgis.core import QgsSettings
        # Save prior state ONCE (don't clobber a genuine prior with our own value
        # on a second apply) so OFF restores what the user actually had.
        if not QgsSettings().value(_CANVAS_KEY, '', type=str):
            was_par = bool(canvas.isParallelRenderingEnabled()) \
                if hasattr(canvas, 'isParallelRenderingEnabled') else True
            was_cache = bool(canvas.isCachingEnabled()) \
                if hasattr(canvas, 'isCachingEnabled') else True
            QgsSettings().setValue(
                _CANVAS_KEY, f"{int(was_par)},{int(was_cache)}")
        if hasattr(canvas, 'setParallelRenderingEnabled'):
            canvas.setParallelRenderingEnabled(True)
        if hasattr(canvas, 'setCachingEnabled'):
            canvas.setCachingEnabled(True)
        return True
    except Exception:
        return False


def restore_canvas(iface=None):
    """Undo apply_canvas() — restore parallel-rendering + caching to whatever the
    user had before we turned the boost on. Never raises."""
    canvas = _canvas(iface)
    if canvas is None:
        return False
    try:
        from qgis.core import QgsSettings
        prior = QgsSettings().value(_CANVAS_KEY, '', type=str)
        par, cache = True, True                     # sensible QGIS defaults
        if prior and ',' in prior:
            p, c = prior.split(',', 1)
            par, cache = (p.strip() == '1'), (c.strip() == '1')
        if hasattr(canvas, 'setParallelRenderingEnabled'):
            canvas.setParallelRenderingEnabled(par)
        if hasattr(canvas, 'setCachingEnabled'):
            canvas.setCachingEnabled(cache)
        QgsSettings().setValue(_CANVAS_KEY, '')      # forget prior; next ON re-captures
        return True
    except Exception:
        return False
