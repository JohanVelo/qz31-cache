"""
Project snapshot manager — save and restore QGIS layer state for undo.

Before running detection, the plugin saves a snapshot of current layer IDs.
After detection, "Undo Detection" removes only the layers added by the pipeline.

Uses only stdlib + PyQGIS — no external deps.
"""

from __future__ import annotations

import logging
from datetime import datetime

logger = logging.getLogger(__name__)


class SnapshotManager:
    """Manages a stack of project snapshots for pipeline undo support."""

    def __init__(self) -> None:
        self._snapshots: dict[str, dict] = {}
        self._latest_id: str | None = None

    def create_snapshot(self) -> str:
        """Save the current set of QGIS layer IDs.

        Returns:
            snapshot_id string (timestamp-based).
        """
        try:
            from qgis.core import QgsProject

            layer_ids = list(QgsProject.instance().mapLayers().keys())
            project_path = QgsProject.instance().fileName()
        except Exception as exc:
            # Do NOT record a poisoned empty snapshot: an empty layer_ids set
            # would make restore_snapshot() treat EVERY current layer as
            # "added after the snapshot" and remove them all (data loss).
            logger.warning("Snapshot: could not read QGIS project state: %s", exc)
            self._latest_id = None
            return ""

        snapshot_id = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        self._snapshots[snapshot_id] = {
            "layer_ids": layer_ids,
            "project_path": project_path,
            "timestamp": datetime.now().isoformat(),
        }
        self._latest_id = snapshot_id
        logger.info("Snapshot created: %s (%d layers)", snapshot_id, len(layer_ids))
        return snapshot_id

    def restore_snapshot(self, snapshot_id: str | None = None) -> dict:
        """Remove all layers added after the snapshot.

        Args:
            snapshot_id: Which snapshot to restore. Defaults to the latest.

        Returns:
            Dict: {"removed": int, "snapshot_id": str, "error": str|None}
        """
        sid = snapshot_id or self._latest_id
        if sid is None or sid not in self._snapshots:
            return {"removed": 0, "error": "No snapshot found to restore"}

        snap = self._snapshots[sid]
        snapshot_ids = set(snap["layer_ids"])

        try:
            from qgis.core import QgsProject

            current_ids = set(QgsProject.instance().mapLayers().keys())
            to_remove = list(current_ids - snapshot_ids)
            for lid in to_remove:
                QgsProject.instance().removeMapLayer(lid)

            # Refresh canvas
            try:
                from qgis.utils import iface
                iface.mapCanvas().refresh()
            except Exception:
                pass

        except Exception as exc:
            return {"removed": 0, "error": str(exc)}

        logger.info("Snapshot restored: removed %d layers", len(to_remove))
        return {"removed": len(to_remove), "snapshot_id": sid, "error": None}

    @property
    def latest_id(self) -> str | None:
        return self._latest_id

    def has_snapshot(self) -> bool:
        return self._latest_id is not None

    def clear(self) -> None:
        self._snapshots.clear()
        self._latest_id = None
