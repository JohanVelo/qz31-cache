"""Build the 16 empty HeroTel standard layers into ONE new GeoPackage.

Never overwrites or deletes a file it did not create:
  * refuses when the target (or a -wal/-shm/-journal sidecar) already exists;
  * writes every layer into a hidden temp file it created exclusively next to the target;
  * publishes with os.rename, which on Windows fails if the target appeared meanwhile;
  * on any failure deletes only its own temp file and that file's sidecars.

File and layer calls are bound by name (no `os.path.exists`-style attribute access),
so the VN 1 read guard can see every path this module touches.
"""
import json
from os import O_CREAT, O_EXCL, O_WRONLY, close, remove, rename
from os import open as os_open
from os.path import abspath, basename, dirname, exists, isdir, join, splitext
from uuid import uuid4

from qgis.core import (Qgis, QgsCoordinateReferenceSystem, QgsCoordinateTransformContext, QgsFeature, QgsField,
                       QgsFields, QgsMessageLog, QgsVectorFileWriter)
from qgis.PyQt.QtCore import QDateTime, QMetaType, Qt

from . import spec_hash

SPEC_PATH = join(str(spec_hash.PACKAGE_DIR), "gold_spec.json")
STYLES_DIR = join(str(spec_hash.PACKAGE_DIR), "styles")
STYLE_DESCRIPTION = "HeroTel standard (VN 1)"
# Same columns QGIS 4.2 creates when it saves a style into a GeoPackage (measured).
STYLE_COLUMNS = (("f_table_catalog", QMetaType.Type.QString, 256), ("f_table_schema", QMetaType.Type.QString, 256),
                 ("f_table_name", QMetaType.Type.QString, 256), ("f_geometry_column", QMetaType.Type.QString, 256),
                 ("styleName", QMetaType.Type.QString, 30), ("styleQML", QMetaType.Type.QString, 0),
                 ("styleSLD", QMetaType.Type.QString, 0), ("useAsDefault", QMetaType.Type.Bool, 0),
                 ("description", QMetaType.Type.QString, 0), ("owner", QMetaType.Type.QString, 30),
                 ("ui", QMetaType.Type.QString, 30), ("update_time", QMetaType.Type.QDateTime, 0))
LOG_TAG = "VN1"
SIDECARS = ("-wal", "-shm", "-journal")
FIELD_TYPES = {"String": QMetaType.Type.QString, "Integer": QMetaType.Type.Int,
               "Integer64": QMetaType.Type.LongLong, "Real": QMetaType.Type.Double,
               "Date": QMetaType.Type.QDate}
GEOMETRY = {"Point": Qgis.WkbType.Point, "LineString": Qgis.WkbType.LineString,
            "Polygon": Qgis.WkbType.Polygon, "PolygonZ": Qgis.WkbType.PolygonZ,
            "MultiPoint": Qgis.WkbType.MultiPoint}


class BuildError(Exception):
    """The GeoPackage could not be built; nothing was left behind."""


def load_spec():
    spec_hash.verify()
    with open(SPEC_PATH, "rb") as fh:
        return json.loads(fh.read())


def layer_fields(layer_spec):
    fields = QgsFields()
    for f in layer_spec["fields"]:
        width = f["width"] if f["type"] == "String" else 0
        fields.append(QgsField(f["name"], FIELD_TYPES[f["type"]], "", width, 0))
    return fields


def _write_styles(temp, names):
    """Store each layer's QML as its default style, in the layer_styles table QGIS reads.

    Written with QgsVectorFileWriter, which closes its file handle on delete. Opening the
    layers through QGIS instead would leave the GeoPackage locked and break the rename.
    """
    fields = QgsFields()
    for name, kind, width in STYLE_COLUMNS:
        fields.append(QgsField(name, kind, "", width, 0))
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = "layer_styles"
    options.layerOptions = ["FID=id"]
    options.actionOnExistingFile = QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteLayer
    writer = QgsVectorFileWriter.create(temp, fields, Qgis.WkbType.NoGeometry, QgsCoordinateReferenceSystem(),
                                        QgsCoordinateTransformContext(), options)
    if writer is None or writer.hasError() != QgsVectorFileWriter.WriterError.NoError:
        message = writer.errorMessage() if writer is not None else "no writer"
        del writer
        raise BuildError(f"The style table could not be created: {message}")
    now = QDateTime.currentDateTimeUtc()
    now.setTimeSpec(Qt.TimeSpec.UTC)
    for name in names:
        with open(join(STYLES_DIR, f"{name}.qml"), "rb") as fh:
            qml = fh.read().decode("utf-8")
        feature = QgsFeature(fields)
        feature.setAttributes(["", "", name, "geom", name[:30], qml, "", True, STYLE_DESCRIPTION, "", None, now])
        if not writer.addFeature(feature):
            message = writer.errorMessage()
            del writer
            raise BuildError(f"The style for '{name}' could not be saved: {message}")
    del writer


def _occupied(path):
    return exists(path) or any(exists(path + s) for s in SIDECARS)


def _discard(temp):
    """Delete only this build's temp file and its sidecars. Never raises: returns what it could not delete."""
    left = []
    for p in (temp, *(temp + s for s in SIDECARS)):
        if exists(p):
            try:
                remove(p)
            except OSError:
                left.append(p)
    return left


def build(path, crs, _hook=None):
    """Create `path` holding the 16 standard layers in `crs`.

    Returns {"outcome": "built" | "refused", ...}. Raises BuildError (after cleaning
    up its own temp file) or ValueError for a bad request. `_hook(stage, index)` is
    a test seam only.
    """
    hook = _hook or (lambda stage, index: None)
    spec = load_spec()
    target = abspath(path)
    folder = dirname(target)
    if splitext(target)[1].lower() != ".gpkg":
        raise ValueError("The file name must end in .gpkg")
    if not isdir(folder):
        raise ValueError(f"The folder does not exist: {folder}")
    if crs is None or not crs.isValid():
        raise ValueError("A valid coordinate reference system is required")
    if _occupied(target):
        return {"outcome": "refused", "reason": "exists", "path": target}

    temp = join(folder, ".%s.vn1tmp-%s.gpkg" % (splitext(basename(target))[0], uuid4().hex))
    close(os_open(temp, O_CREAT | O_EXCL | O_WRONLY))
    names = list(spec["layers"])
    try:
        for index, name in enumerate(names):
            layer_spec = spec["layers"][name]
            options = QgsVectorFileWriter.SaveVectorOptions()
            options.driverName = "GPKG"
            options.layerName = name
            options.actionOnExistingFile = (QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteFile if index == 0
                                            else QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteLayer)
            writer = QgsVectorFileWriter.create(temp, layer_fields(layer_spec), GEOMETRY[layer_spec["geometry"]],
                                                crs, QgsCoordinateTransformContext(), options)
            if writer is None or writer.hasError() != QgsVectorFileWriter.WriterError.NoError:
                message = writer.errorMessage() if writer is not None else "no writer"
                del writer
                raise BuildError(f"Layer '{name}' could not be created: {message}")
            del writer
            hook("after_layer", index)
        _write_styles(temp, names)
        hook("after_styles", len(names))
        hook("before_rename", len(names))
        try:
            rename(temp, target)
        except FileExistsError:
            left = _discard(temp)
            result = {"outcome": "refused", "reason": "appeared", "path": target}
            if left:
                result["temp_left"] = left
            return result
    except BaseException as exc:
        left = _discard(temp)
        if isinstance(exc, (KeyboardInterrupt, SystemExit)):
            raise
        note = f" (could not delete temp file: {left})" if left else ""
        if isinstance(exc, BuildError):
            raise BuildError(f"{exc}{note}") from exc
        raise BuildError(f"Build failed: {exc}{note}") from exc
    return {"outcome": "built", "path": target, "crs": crs.authid(), "layers": names}


def build_with_prompts(project, ask_path, ask_crs, log=None):
    """Ask where to save, pick the CRS (project CRS if valid, else ask once), build.

    Writes exactly one VN1 log record per call and returns it.
    """
    record = {"outcome": None, "path": None, "crs_decision": None, "project_crs_valid": False,
              "confirm_shown": False, "confirm_answer": None, "layers_added": 0}
    emit = log or (lambda text: QgsMessageLog.logMessage(text, LOG_TAG, Qgis.MessageLevel.Info))
    try:
        path = ask_path()
        if not path:
            record["outcome"] = "cancelled"
            return record
        record["path"] = abspath(path)
        crs = project.crs()
        record["project_crs_valid"] = bool(crs.isValid())
        if crs.isValid():
            record["crs_decision"] = "project"
        else:
            record["crs_decision"] = "asked"
            crs = ask_crs()
            if crs is None or not crs.isValid():
                record["outcome"] = "cancelled"
                return record
        result = build(path, crs)
        record["outcome"] = result["outcome"]
        record["crs"] = crs.authid()
        return record
    except (BuildError, ValueError) as exc:
        record["outcome"] = "error"
        record["error"] = str(exc)
        raise
    finally:
        emit(json.dumps(record, sort_keys=True))
