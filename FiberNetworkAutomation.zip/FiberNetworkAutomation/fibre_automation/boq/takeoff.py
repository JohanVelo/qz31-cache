"""takeoff — geometry-driven quantity take-off, grouped per PON and per Zone.

This is the *quantities* companion to the priced ``engine``/``fibertime_mml``
BoQ. It answers JJ's direct questions — "how many poles in a PON",
"how many features in a Phase" — plus pole size/length, derived pole hardware
(hooks / tangents / dead-ends), cable lengths, and trenching/drilling where
those layers or attributes exist.

Design rules (match the rest of boq/):
  * SCHEMA-AGNOSTIC — the PON/Zone grouping field is auto-detected per layer
    (``pon_no`` / ``group_id`` / ``zone_id`` …); when a layer has no such field
    we fall back to spatial containment in the project's PON/Zone polygon layer,
    and only then to "(ungrouped)". The method used is reported, never hidden.
  * LENGTHS IN METRES — measured on the source CRS with an ellipsoid set
    (EPSG:4326-degree-safe), identical to ``engine._measure_length_m`` /
    ``fibertime_mml._len_m``.
  * READ-ONLY — never edits a layer. No Qt imports (pure, unit-testable).
  * HONEST — a missing field/layer yields "n/a", never a silent 0.
"""
import math

# UTM 35S covers Potch/Mohadin; only used if a layer's own CRS is unusable.
_MEASURE_UTM = "EPSG:32735"

# Grouping-field candidates, first present wins (case-insensitive match).
_PON_FIELDS = ("pon_no", "pon_number", "ponno", "pon", "group_id", "group_8", "groupid")
_ZONE_FIELDS = ("zone_id", "zone_no", "zone_name", "zoneid", "zone")

# Pole attribute candidates.
_POLE_THICK_FIELDS = ("dim2", "pole_thick", "pole_thickness", "pole thick",
                      "thickness", "thick")
_POLE_LEN_FIELDS = ("height", "pole size", "pole_size", "pole_length",
                    "pole_len", "poleheight", "length_m")

# Layer-role classification tokens (all-lowercase substring match on the name).
# ORDER MATTERS — point/equipment roles are checked BEFORE cable-name tokens so
# "Distribution Poles" / "Feeder Poles" classify as poles (counted), not as
# distribution/feeder cables (length-measured).
_ROLE_TOKENS = [
    ("pole", ("pole",)),
    ("ont", ("ont",)),
    ("trench", ("trench", "excavat", "dig")),
    ("drill", ("drill", "bore", "hdd", "directional")),
    ("primary", ("primary",)),
    ("secondary", ("secondary",)),
    ("distribution", ("distribution",)),
    ("drop", ("drop",)),
    ("feeder", ("feeder",)),          # generic feeder cable (client-dependent)
]

# Per-feature "construction method" candidates (to catch trench/drill on cables).
_METHOD_FIELDS = ("method", "install", "installatio", "constructi",
                  "construction", "build_type", "buildtype")
_TRENCH_WORDS = ("trench", "excavat", "dig", "underground", "ug")
_DRILL_WORDS = ("bore", "drill", "hdd", "directional", "mole")

# Non-canonical "decoy" layers to keep OUT of the per-PON/Zone rollup (they are
# still shown in the all-layers count). Same intent as engine.py exclude_tokens
# + the codebase rule "poles v1 = canonical; watch bare-vs-v1 decoys".
_DECOY_TOKENS = ("backup", "old", "copy", "proposed", "draft", "v0",
                 "archive", "delete", "temp")
_METRIC_ROLES = ("pole", "ont", "primary", "secondary", "distribution",
                 "drop", "feeder", "trench", "drill")


# ── low-level helpers ────────────────────────────────────────────────────────
def _vector_layers(project):
    from qgis.core import QgsVectorLayer
    out = []
    for lyr in project.mapLayers().values():
        if isinstance(lyr, QgsVectorLayer) and lyr.isValid():
            out.append(lyr)
    return out


def _field_index(layer, candidates):
    """First matching field NAME (as it really is) for the candidate list, else None."""
    lut = {f.name().lower(): f.name() for f in layer.fields()}
    for c in candidates:
        real = lut.get(c.lower())
        if real is not None:
            return real
    return None


def _attr(feat, name):
    try:
        i = feat.fields().indexFromName(name)
        v = feat[i] if i >= 0 else None
    except Exception:
        return None
    return None if v is None else v


def _len_m(geom, src_crs, project):
    """Geodesic length (m) on the source CRS. 0.0 for null/empty/failure."""
    from qgis.core import QgsDistanceArea
    if geom is None or geom.isEmpty():
        return 0.0
    try:
        da = QgsDistanceArea()
        da.setSourceCrs(src_crs, project.transformContext())
        da.setEllipsoid(project.ellipsoid() or "WGS84")
        v = da.measureLength(geom)
        return v if (v is not None and math.isfinite(v) and v >= 0) else 0.0
    except Exception:
        return 0.0


def _rep_point(geom):
    """A representative point for a geometry (point/line/polygon), or None."""
    if geom is None or geom.isEmpty():
        return None
    try:
        pt = geom.pointOnSurface()
        if pt is None or pt.isEmpty():
            pt = geom.centroid()
        return pt
    except Exception:
        return None


def classify_role(name):
    n = name.lower()
    for role, toks in _ROLE_TOKENS:
        if any(t in n for t in toks):
            return role
    return "other"


def _is_decoy(name):
    n = name.lower()
    return any(t in n for t in _DECOY_TOKENS)


def _is_v1(name):
    """True for a canonical '… v1' layer (endswith v1, or a v1 token)."""
    import re
    return bool(re.search(r"\bv1\b", name.lower())) or name.lower().rstrip().endswith("v1")


def _is_spare(name):
    return "spare" in name.lower()


def select_canonical(layers):
    """Choose which layers feed the per-PON/Zone rollup.

    Rule (matches the priced engine + 'poles v1 = canonical' convention):
      * drop decoys (backup/old/copy/v0…);
      * per metric role, if any '… v1' layer exists, use ONLY the v1 layers —
        this kills the bare 'Poles'/'ONT'/'Drop Cable' duplicates that would
        otherwise double-count.
    Returns (selected_ids:set, excluded_names:list) — excluded lists metric-role
    layers left out (shown to the user for transparency).
    """
    from collections import defaultdict
    by_role = defaultdict(list)
    excluded = []
    for lyr in layers:
        role = classify_role(lyr.name())
        if role not in _METRIC_ROLES:
            continue
        if _is_decoy(lyr.name()):
            excluded.append(lyr.name())
            continue
        by_role[role].append(lyr)
    selected = set()
    for role, lst in by_role.items():
        v1 = [l for l in lst if _is_v1(l.name())]
        use = v1 if v1 else lst
        selected.update(id(l) for l in use)
        for l in lst:
            if id(l) not in selected:
                excluded.append(l.name())
    return selected, excluded


# ── grouping (attribute → spatial → ungrouped) ───────────────────────────────
class _PolyGrouper:
    """Point-in-polygon lookup of a group value, built from a polygon layer."""

    def __init__(self, layer, group_field, project):
        from qgis.core import QgsSpatialIndex, QgsFeature
        self.name = layer.name()
        self.field = group_field
        self.crs = layer.crs()
        self.project = project
        self._geoms = {}      # fid -> QgsGeometry
        self._vals = {}       # fid -> group value (str)
        feats = []
        for f in layer.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            self._geoms[f.id()] = g
            self._vals[f.id()] = _norm_group(_attr(f, group_field))
            nf = QgsFeature(f.id())
            nf.setGeometry(g)
            feats.append(nf)
        self.index = QgsSpatialIndex()
        for nf in feats:
            self.index.addFeature(nf)

    def value_for(self, point_geom, src_crs):
        """group value for a point (reprojected into this layer's CRS), or None."""
        from qgis.core import QgsCoordinateTransform, QgsGeometry
        if point_geom is None or point_geom.isEmpty():
            return None
        g = point_geom
        if src_crs != self.crs:
            try:
                g = QgsGeometry(point_geom)
                g.transform(QgsCoordinateTransform(src_crs, self.crs, self.project))
            except Exception:
                return None
        for fid in self.index.intersects(g.boundingBox()):
            poly = self._geoms.get(fid)
            if poly is not None and poly.contains(g):
                return self._vals.get(fid)
        # containment only — no nearest fallback (a point outside every polygon
        # is honestly '(ungrouped)', never mis-assigned to the nearest group)
        return None


def _norm_group(v):
    if v is None:
        return None
    s = str(v).strip()
    return s or None


def _find_group_polygon(layers, field_candidates, name_hint):
    """Best polygon layer + group field for spatial grouping, or (None, None)."""
    from qgis.core import QgsWkbTypes
    best = None
    for lyr in layers:
        if QgsWkbTypes.geometryType(lyr.wkbType()) != QgsWkbTypes.PolygonGeometry:
            continue
        if _is_decoy(lyr.name()):
            continue
        fld = _field_index(lyr, field_candidates)
        if fld is None:
            continue
        score = (2 if name_hint in lyr.name().lower() else 0)
        score += (1 if _is_v1(lyr.name()) else 0)   # prefer the canonical v1 polygon
        if best is None or score > best[0]:
            best = (score, lyr, fld)
    return (best[1], best[2]) if best else (None, None)


# ── size / length banding ─────────────────────────────────────────────────────
def _thick_band(val):
    if val is None:
        return "(unset)"
    s = str(val).lower().replace("mm", "").strip()
    if "140-160" in s or "140_160" in s:
        return "140-160mm"
    if "120-140" in s or "120_140" in s:
        return "120-140mm"
    num = _first_number(s)
    if num is not None:
        if 140 <= num <= 160:
            return "140-160mm"
        if 120 <= num < 140:
            return "120-140mm"
        return f"{num:g}mm"
    return str(val)


def _len_band(val):
    if val is None:
        return "(unset)"
    num = _first_number(str(val))
    if num is not None:
        return f"{num:g}m"
    return str(val)


def _first_number(s):
    import re
    m = re.search(r"\d+(?:[.,]\d+)?", str(s))
    if not m:
        return None
    try:
        return float(m.group(0).replace(",", "."))
    except ValueError:
        return None


# ── result container ──────────────────────────────────────────────────────────
class TakeoffResult:
    def __init__(self):
        self.project = ""
        self.notes = []            # human strings (method used, n/a, warnings)
        self.pon_groups = []       # sorted list of PON group values seen
        self.zone_groups = []      # sorted list of Zone group values seen
        # per-group metric rows: {group: {metric_key: value}}
        self.per_pon = {}
        self.per_zone = {}
        self.totals = {}           # metric_key -> grand total
        self.layer_counts = []     # [{layer, role, count}]
        self.pole_by_size = {}     # band -> count
        self.pole_by_length = {}   # band -> count
        self.method = {}           # layer name -> "field:x" | "spatial:LayerX" | "ungrouped"

    def _bump(self, bucket, group, key, amount):
        # NB: totals are NOT accumulated here — a feature is bumped into BOTH the
        # per-PON and per-Zone buckets, so counting totals here would double them.
        # Totals are derived once from per_pon in _finalise().
        if group is None:
            group = "(ungrouped)"
        row = bucket.setdefault(group, {})
        row[key] = row.get(key, 0) + amount


# Ordered metric columns for the per-PON / per-Zone tables.
METRIC_COLUMNS = [
    ("poles", "Poles"),
    ("hooks", "Hooks"),
    ("tangents", "Tangents"),
    ("deadends", "Dead-ends"),
    ("primary_m", "Primary m"),
    ("secondary_m", "Secondary m"),
    ("distribution_m", "Distribution m"),
    ("drop_m", "Drop m"),
    ("spare_drop_m", "Spare drop m"),
    ("feeder_m", "Feeder m"),
    ("ont", "ONTs"),
    ("trench_m", "Trench m"),
    ("drill_n", "Drill pts"),
]


# ── main entry ────────────────────────────────────────────────────────────────
def run_takeoff(project=None):
    """Compute the geometry take-off for the live QGIS project → TakeoffResult."""
    from qgis.core import QgsProject
    project = project or QgsProject.instance()
    res = TakeoffResult()
    res.project = project.baseName() or "(unsaved)"

    layers = _vector_layers(project)
    if not layers:
        res.notes.append("No vector layers in the project.")
        return res

    # Grouping polygons for spatial fallback (built once).
    pon_poly_lyr, pon_poly_fld = _find_group_polygon(layers, _PON_FIELDS, "pon")
    zone_poly_lyr, zone_poly_fld = _find_group_polygon(layers, _ZONE_FIELDS, "zone")
    pon_grouper = _PolyGrouper(pon_poly_lyr, pon_poly_fld, project) if pon_poly_lyr else None
    zone_grouper = _PolyGrouper(zone_poly_lyr, zone_poly_fld, project) if zone_poly_lyr else None
    if pon_grouper:
        res.notes.append(f"PON spatial fallback → '{pon_grouper.name}'.{pon_grouper.field}")
    if zone_grouper:
        res.notes.append(f"Zone spatial fallback → '{zone_grouper.name}'.{zone_grouper.field}")

    canonical_ids, excluded = select_canonical(layers)
    if excluded:
        res.notes.append("Rollup uses canonical (v1) layers only; excluded from "
                         "the per-PON/Zone totals (still in All layers): "
                         + ", ".join(sorted(set(excluded))))

    for lyr in layers:
        role = classify_role(lyr.name())
        res.layer_counts.append({"layer": lyr.name(), "role": role,
                                 "count": lyr.featureCount(),
                                 "in_rollup": id(lyr) in canonical_ids})
        if role in _METRIC_ROLES and id(lyr) not in canonical_ids:
            continue   # decoy / non-canonical → excluded from the rollup metrics
        _process_layer(res, lyr, role, project, pon_grouper, zone_grouper,
                       pon_poly_lyr, zone_poly_lyr)

    res.pon_groups = _sorted_groups(res.per_pon)
    res.zone_groups = _sorted_groups(res.per_zone)
    _finalise_notes(res)
    return res


def _process_layer(res, lyr, role, project, pon_grouper, zone_grouper,
                   pon_poly_lyr, zone_poly_lyr):
    crs = lyr.crs()
    pon_fld = _field_index(lyr, _PON_FIELDS)
    zone_fld = _field_index(lyr, _ZONE_FIELDS)

    # record grouping method (for the notes / transparency)
    if pon_fld:
        res.method[lyr.name()] = f"field:{pon_fld}"
    elif pon_grouper and lyr is not pon_poly_lyr:
        res.method[lyr.name()] = f"spatial:{pon_grouper.name}"
    else:
        res.method[lyr.name()] = "ungrouped"

    thick_fld = _field_index(lyr, _POLE_THICK_FIELDS) if role == "pole" else None
    len_fld = _field_index(lyr, _POLE_LEN_FIELDS) if role == "pole" else None
    method_fld = _field_index(lyr, _METHOD_FIELDS)
    has_slots = role == "pole" and _field_index(lyr, ("type_4", "type_3", "type_2"))

    from qgis.core import QgsWkbTypes
    gtype = QgsWkbTypes.geometryType(lyr.wkbType())

    for feat in lyr.getFeatures():
        geom = feat.geometry()
        # resolve this feature's PON + Zone group
        pon = _resolve_group(feat, geom, crs, pon_fld, pon_grouper,
                             lyr is pon_poly_lyr, project)
        zone = _resolve_group(feat, geom, crs, zone_fld, zone_grouper,
                              lyr is zone_poly_lyr, project)

        def bump(key, amt):
            res._bump(res.per_pon, pon, key, amt)
            res._bump(res.per_zone, zone, key, amt)

        # ── poles: count + size/length bands + Fibertime hardware slots ──
        if role == "pole":
            bump("poles", 1)
            if thick_fld:
                b = _thick_band(_attr(feat, thick_fld))
                res.pole_by_size[b] = res.pole_by_size.get(b, 0) + 1
            if len_fld:
                b = _len_band(_attr(feat, len_fld))
                res.pole_by_length[b] = res.pole_by_length.get(b, 0) + 1
            if has_slots:
                if str(_attr(feat, "type_4") or "").lower().startswith("hook"):
                    bump("hooks", 1)
                if str(_attr(feat, "type_3") or "").lower().startswith("tangent"):
                    bump("tangents", 1)
                if str(_attr(feat, "type_2") or "").lower().startswith("dead"):
                    bump("deadends", 1)

        # ── ONTs ──
        elif role == "ont":
            bump("ont", 1)

        # ── cables (length metres by role) ──
        elif role in ("primary", "secondary", "distribution", "drop", "feeder"):
            m = _len_m(geom, crs, project)
            # spare drops kept as a distinct metric (installed material, but not
            # the live drop count) so they are visible without inflating drops.
            key = "spare_drop_m" if (role == "drop" and _is_spare(lyr.name())) \
                else f"{role}_m"
            bump(key, m)
            # trench/drill flagged on the cable's construction-method attr
            if method_fld:
                mv = str(_attr(feat, method_fld) or "").lower()
                if any(w in mv for w in _TRENCH_WORDS):
                    bump("trench_m", m)
                if any(w in mv for w in _DRILL_WORDS):
                    bump("drill_n", 1)

        # ── dedicated trench / drill layers ──
        elif role == "trench":
            if gtype == QgsWkbTypes.LineGeometry:
                bump("trench_m", _len_m(geom, crs, project))
            else:
                bump("trench_m", 0)
        elif role == "drill":
            bump("drill_n", 1)


def _resolve_group(feat, geom, crs, field, grouper, is_grouper_layer, project):
    """Group value via attribute field, else spatial containment, else None."""
    if field:
        return _norm_group(_attr(feat, field))
    if grouper is not None and not is_grouper_layer:
        return grouper.value_for(_rep_point(geom), crs)
    return None


def _sorted_groups(bucket):
    def key(g):
        n = _first_number(g)
        return (0, n, "") if n is not None else (1, 0.0, g)
    return sorted(bucket.keys(), key=key)


def _finalise_notes(res):
    # derive grand totals ONCE from the per-PON bucket (every feature lands in
    # exactly one PON group, incl. "(ungrouped)") — never from _bump, which would
    # double-count across the PON+Zone dimensions.
    res.totals = {}
    for row in res.per_pon.values():
        for k, v in row.items():
            res.totals[k] = res.totals.get(k, 0) + v

    # round the metre metrics for display
    for bucket in (res.per_pon, res.per_zone):
        for row in bucket.values():
            for k in list(row.keys()):
                if k.endswith("_m"):
                    row[k] = round(row[k], 1)
    for k in list(res.totals.keys()):
        if k.endswith("_m"):
            res.totals[k] = round(res.totals[k], 1)

    if not any(res.totals.get(k) for k in ("trench_m", "drill_n")):
        res.notes.append("Trenching / drilling: n/a — no trench/drill layers or "
                         "construction-method attributes found (typical for an "
                         "all-aerial network).")
    if not any(res.totals.get(k) for k in ("hooks", "tangents", "deadends")):
        res.notes.append("Pole hardware (hooks/tangents/dead-ends): n/a — derived "
                         "from Fibertime pole slots (type_2/3/4); not present in "
                         "this schema.")
    if "(ungrouped)" in res.per_pon:
        res.notes.append("Some features could not be attributed to a PON (no PON "
                         "field and outside every PON polygon) — see '(ungrouped)'.")
