﻿"""cadastral_erven — build cadastral-style erven FROM SCRATCH, everywhere, with NO Voronoi.

Pipeline (works in formal AND informal areas, needs only the detected building footprints):
  Stage 1  BLOCKS  : rasterise buildings -> dilate to block-blobs (markers) -> watershed outward
                     across the built area so block boundaries fall on ROAD CENTRELINES. Gives clean
                     road-bounded blocks incl. informal lanes that OSM lacks.
  Stage 2  STANDS  : per block, rotate to its street axis (OBB), split front/back at mid-block, lay
                     UNIFORM street-fronting rectangular lots (width = median building spacing).
                     Regular cadastral look — NOT Voronoi.
  Stage 3  ASSEMBLE: optionally keep the surveyed CSG erven where they exist (ground truth) and use
                     generated stands only where there's no survey. One demand point per stand.

Outputs (EPSG:4326):
  erven_cadastral.geojson  : generated stands everywhere (the from-scratch automation)
  erven_best.geojson       : CSG survey where present + generated elsewhere  (--csg)
  demand_cadastral.geojson : one demand point per stand (on its building if present)

Usage (qgis-venv):
  python cadastral_erven.py --buildings C:/Temp/detected_buildings.geojson \
    --aoi C:/Temp/_aoi_detect.geojson --outdir C:/Temp \
    [--csg "C:/Users/jjsch/OneDrive/ON LAPTOP FIBRE/QGIS test/Vuma_MOA_Test/Erven.shp"]
"""
import argparse
import math

import numpy as np
import cv2
import geopandas as gpd
import pandas as pd
from rasterio.features import rasterize, shapes
from rasterio.transform import from_origin
from scipy import ndimage as ndi
from shapely.affinity import rotate as _rotate
from shapely.geometry import shape, box as _sbox

UTM = 32735


# ── Stage 1: blocks from buildings via watershed-to-road-centreline ──
def buildings_to_blocks(buildings, aoi_geom, merge_m=12, built_m=35, px=1.0, min_block=400):
    minx, miny, maxx, maxy = aoi_geom.bounds
    W = int((maxx - minx) / px) + 1; H = int((maxy - miny) / px) + 1
    tr = from_origin(minx, maxy, px, px)
    mask = rasterize([(g, 1) for g in buildings if g and not g.is_empty],
                     out_shape=(H, W), transform=tr, fill=0, dtype="uint8")
    aoimask = rasterize([(aoi_geom, 1)], out_shape=(H, W), transform=tr, fill=0, dtype="uint8")
    def disk(m): return cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (int(m) | 1, int(m) | 1))
    occ = cv2.dilate(mask * 255, disk(merge_m), iterations=1)
    _, markers = cv2.connectedComponents((occ > 0).astype("uint8"))
    built = (cv2.dilate(mask * 255, disk(built_m), iterations=1) > 0) & (aoimask > 0)
    dist = ndi.distance_transform_edt(occ == 0)
    # skimage only ships in the qgis-venv, not QGIS's embedded Python — import at use
    from skimage.segmentation import watershed
    ws = watershed(dist, markers, mask=built)
    blocks = []
    for geom, val in shapes(ws.astype("int32"), mask=(ws > 0), transform=tr):
        if val == 0:
            continue
        g = shape(geom).buffer(0)
        if g.area >= min_block:
            blocks.append(g.simplify(1.5))
    return gpd.GeoDataFrame(geometry=blocks, crs=UTM)


# ── Stage 2: regular street-aligned stand subdivision ──
def _long_az(poly):
    cc = list(poly.minimum_rotated_rectangle.exterior.coords)
    best, bl = 0.0, -1.0
    for i in range(4):
        dx = cc[i + 1][0] - cc[i][0]; dy = cc[i + 1][1] - cc[i][1]; L = math.hypot(dx, dy)
        if L > bl:
            bl, best = L, math.degrees(math.atan2(dy, dx))
    return best % 180.0


def _estimate_W(bx, w_default=18.0):
    if len(bx) < 4:
        return w_default
    gaps = np.diff(np.sort(bx)); gaps = gaps[(gaps > 6) & (gaps < 22)]
    if len(gaps) < 3:
        return w_default
    w = float(np.median(gaps))
    return w if 10 <= w <= 22 else w_default


def _clean_block(g):
    """Straighten the block outline so a uniform grid tiles it cleanly."""
    c = g.buffer(-4.0).buffer(4.0).simplify(8.0)
    if c.is_empty or c.geom_type != "Polygon":
        c = g.simplify(8.0)
    return c


def _dominant_azimuths(blocks):
    """Top street azimuths (area-weighted) so neighbouring blocks share lot orientation."""
    azs = np.array([_long_az(g) for g in blocks])
    ar = np.array([g.area for g in blocks])
    hist = np.zeros(180)
    for a, w in zip(azs, ar):
        hist[int(a) % 180] += w
    hist = np.convolve(np.r_[hist[-8:], hist, hist[:8]], np.ones(9) / 9, "same")[8:-8]
    peaks = []
    for o in np.argsort(hist)[::-1]:
        if all(min(abs(o - p), 180 - abs(o - p)) > 20 for p in peaks):
            peaks.append(float(o))
        if len(peaks) >= 3:
            break
    return peaks


def subdivide(blk, bpts, peaks=None, d_target=27.0, w_override=None,
              min_area=60.0, max_area=1300.0):
    """UNIFORM grid of identical lots; keep a lot if its CENTRE is in the (cleaned) block — gives
    even, survey-like rows with slight overshoot at curved edges (JJ's chosen 'uniform grid' style).
    w_override sets the stand width directly (slider); else it's estimated from building spacing."""
    blk = _clean_block(blk)
    if blk.is_empty:
        return []
    az = _long_az(blk)
    if peaks:                                   # snap to nearest dominant street azimuth
        best = min(peaks, key=lambda p: min(abs(az - p), 180 - abs(az - p)))
        if min(abs(az - best), 180 - abs(az - best)) <= 22:
            az = best
    o = blk.centroid
    bR = _rotate(blk, -az, origin=o)
    xmin, ymin, xmax, ymax = bR.bounds
    if (xmax - xmin) < 10 or (ymax - ymin) < 8:
        return []
    pin = [_rotate(p, -az, origin=o) for p in bpts if blk.contains(p)]
    bx = np.array([p.x for p in pin]) if pin else np.array([])
    W = float(w_override) if w_override else _estimate_W(bx)
    span_y = ymax - ymin
    krows = max(1, int(round(span_y / d_target))); dq = span_y / krows
    n = max(1, int(round((xmax - xmin) / W))); Wq = (xmax - xmin) / n
    out = []
    for ri in range(krows):
        ry0 = ymin + ri * dq
        for ci in range(n):
            cx0 = xmin + ci * Wq
            cell = _sbox(cx0, ry0, cx0 + Wq, ry0 + dq)
            if bR.contains(cell.centroid) and min_area <= cell.area <= max_area:
                out.append(_rotate(cell, az, origin=o))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--buildings", required=True)
    ap.add_argument("--aoi", required=True)
    ap.add_argument("--csg", help="surveyed CSG erven (used as ground truth where present)")
    ap.add_argument("--outdir", default="C:/Temp")
    ap.add_argument("--merge-m", type=float, default=12.0)
    args = ap.parse_args()

    aoi = gpd.read_file(args.aoi).to_crs(UTM); ageom = aoi.geometry.union_all()
    b = gpd.read_file(args.buildings).to_crs(UTM)
    b = b[b.geometry.notna() & ~b.geometry.is_empty]
    bpts = [g.representative_point() for g in b.geometry]

    print("[cad] Stage 1: blocks from buildings ...")
    blocks = buildings_to_blocks(list(b.geometry), ageom, merge_m=args.merge_m)
    print(f"[cad] {len(blocks)} blocks")

    print("[cad] Stage 2: uniform stand subdivision ...")
    peaks = _dominant_azimuths(list(blocks.geometry))
    print(f"[cad] dominant street azimuths: {[round(p) for p in peaks]}")
    stands = []
    for blk in blocks.geometry:
        if blk and not blk.is_empty:
            stands.extend(subdivide(blk, bpts, peaks=peaks))
    gen = gpd.GeoDataFrame(geometry=[s for s in stands if s and not s.is_empty], crs=UTM)
    gen["area_m2"] = gen.geometry.area
    print(f"[cad] {len(gen)} generated stands (median {gen.area_m2.median():.0f} m^2)")
    gen.to_crs(4326).to_file(f"{args.outdir}/erven_cadastral.geojson", driver="GeoJSON")

    # Stage 3: CSG where present + generated elsewhere
    if args.csg:
        e = gpd.read_file(args.csg).to_crs(UTM); e["_a"] = e.geometry.area
        csg = e[(e["_a"] >= 20) & (e["_a"] <= 2000)].copy()
        csg = csg[csg.intersects(ageom)]
        csg_union = csg.geometry.union_all()
        keep_gen = gen[gen.geometry.representative_point().apply(lambda p: not csg_union.contains(p))]
        best = pd.concat([
            csg[["geometry"]].assign(kind="survey"),
            keep_gen[["geometry"]].assign(kind="generated"),
        ], ignore_index=True)
        best = gpd.GeoDataFrame(best, crs=UTM)
        best.to_crs(4326).to_file(f"{args.outdir}/erven_best.geojson", driver="GeoJSON")
        print(f"[cad] erven_best: {len(csg)} survey + {len(keep_gen)} generated = {len(best)}")
        stand_src = best
    else:
        stand_src = gen.assign(kind="generated")

    # one demand point per stand (on its building if present, else stand centroid)
    bp = gpd.GeoDataFrame(geometry=bpts, crs=UTM)
    j = gpd.sjoin(bp, stand_src.reset_index(names="_sid"), how="inner", predicate="within")
    host = {int(r["_sid"]): r.geometry for _, r in j.drop_duplicates("_sid").iterrows()}
    rows = []
    for sid, s in enumerate(stand_src.geometry):
        pt = host.get(sid, s.representative_point())
        rows.append({"geometry": pt, "structure": 1 if sid in host else 0})
    dp = gpd.GeoDataFrame(rows, crs=UTM).to_crs(4326)
    dp["Geo Latitu"] = dp.geometry.y; dp["Geo Longit"] = dp.geometry.x
    dp["Type"] = "SDU"; dp["Status"] = "planned"; dp["Geo Countr"] = "South Africa"
    dp.to_file(f"{args.outdir}/demand_cadastral.geojson", driver="GeoJSON")
    print(f"[cad] {len(dp)} demand points ({int(dp.structure.sum())} on a building)")
    print("[cad] WROTE erven_cadastral.geojson, erven_best.geojson, demand_cadastral.geojson")


if __name__ == "__main__":
    main()
