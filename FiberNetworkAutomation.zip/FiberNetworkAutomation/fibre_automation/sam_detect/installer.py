"""installer — one-click install of the AI/data components on plain QGIS.

Teammates' machines have no dev venv: Detect Buildings needs torch+sam2
(AI) and geopandas+overturemaps (open-data footprint download), none of
which ship with QGIS. This installs them ONCE into the user's Python
site-packages using QGIS's own bundled interpreter — no admin rights,
no separate Python install, no subscriptions.

Two pip stages (torch must come from the CPU wheel index, or pip grabs
the multi-GB CUDA build):
  1. torch (CPU wheels index only)
  2. everything else from PyPI

Entry point: AIComponentsInstaller(iface).run(on_done=callable)
"""
from __future__ import annotations


from qgis.PyQt.QtCore import QProcess, Qt
from qgis.PyQt.QtWidgets import (QDialog, QHBoxLayout, QLabel, QMessageBox,
                                 QPlainTextEdit, QPushButton, QVBoxLayout)

try:
    from ..shared.vf_paths import python_exe
except ImportError:
    from fibre_automation.shared.vf_paths import python_exe

STAGES = [
    ("PyTorch (CPU — ~200 MB download)",
     ["-m", "pip", "install", "--user", "torch",
      "--index-url", "https://download.pytorch.org/whl/cpu"]),
    ("SAM2 + imaging + geodata packages",
     ["-m", "pip", "install", "--user",
      "sam2", "rasterio", "scikit-image", "scipy",
      "opencv-python-headless", "buildingregulariser",
      "geopandas", "overturemaps", "pillow"]),
]


_ACTIVE = None      # module-level: ONE install run at a time, plugin-wide


def get_installer(iface):
    """Singleton accessor — prevents two entry points (menu + Detect
    Buildings dialog) launching concurrent pip runs that would clash."""
    global _ACTIVE
    try:
        if _ACTIVE is not None and _ACTIVE.isVisible():
            _ACTIVE.raise_()
            return _ACTIVE
    except RuntimeError:
        pass                            # C++ object deleted — recreate
    _ACTIVE = AIComponentsInstaller(iface)
    return _ACTIVE


class AIComponentsInstaller(QDialog):
    """Modeless dialog that streams pip output while installing."""

    def __init__(self, iface, parent=None):
        super().__init__(parent or iface.mainWindow())
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.iface = iface
        self.proc = None
        self._stage = 0
        self._on_done = None
        self._cancelled = False
        self._retried_no_user = False
        self.setWindowTitle("Velocity Nexus — Install AI components")
        self.resize(640, 420)
        lay = QVBoxLayout(self)
        self.lbl = QLabel("One-time setup (~400 MB download). "
                          "QGIS stays usable while it runs.")
        lay.addWidget(self.lbl)
        self.out = QPlainTextEdit()
        self.out.setReadOnly(True)
        self.out.setStyleSheet("font-family: Consolas, monospace;"
                               "font-size: 9pt;")
        lay.addWidget(self.out)
        row = QHBoxLayout()
        row.addStretch(1)
        self.btn = QPushButton("Cancel")
        self.btn.clicked.connect(self._cancel)
        row.addWidget(self.btn)
        lay.addLayout(row)

    def run(self, on_done=None):
        if self.proc is not None and self.proc.state() != QProcess.ProcessState.NotRunning:
            self.show()
            self.raise_()
            return                      # already installing — never two pips
        self._on_done = on_done
        self._stage = 0
        self._cancelled = False
        self._retried_no_user = False
        self.btn.setText("Cancel")
        self.show()
        self.raise_()
        self._start_stage()

    def _start_stage(self, drop_user=False):
        if not drop_user:
            # each stage gets its own retry budget; don't reset on the
            # drop_user retry itself or the guard would loop forever
            self._retried_no_user = False
        name, args = STAGES[self._stage]
        if drop_user:
            args = [a for a in args if a != "--user"]
        self.lbl.setText(f"Step {self._stage + 1}/{len(STAGES)}: "
                         f"installing {name} …")
        self.out.appendPlainText(f"\n=== {name} ===\n$ python "
                                 + " ".join(args) + "\n")
        self.proc = QProcess(self)
        self.proc.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        self.proc.readyReadStandardOutput.connect(self._on_out)
        self.proc.finished.connect(self._on_finished)
        self.proc.start(python_exe(), args)

    def _on_out(self):
        if self.proc is None:
            return
        txt = bytes(self.proc.readAllStandardOutput()).decode("utf-8",
                                                              "replace")
        if txt:
            self.out.appendPlainText(txt.rstrip())
            sb = self.out.verticalScrollBar()
            sb.setValue(sb.maximum())

    def _cancel(self):
        if self.proc is not None and self.proc.state() != QProcess.ProcessState.NotRunning:
            self._cancelled = True
            self.proc.kill()
            self.out.appendPlainText("\n[cancelled]")
        self.close()

    def closeEvent(self, event):
        # title-bar X must behave like Cancel, not leave pip running
        if self.proc is not None and self.proc.state() != QProcess.ProcessState.NotRunning:
            self._cancelled = True
            self.proc.kill()
        global _ACTIVE
        _ACTIVE = None
        super().closeEvent(event)

    def _on_finished(self, code, _status):
        if self._cancelled:
            return                      # user cancel — no failure popup/log
        if code != 0:
            tail = self.out.toPlainText()[-1500:]
            if (not self._retried_no_user
                    and "site-packages are not visible" in tail):
                # rare QGIS builds disable user-site — retry system install
                self._retried_no_user = True
                self.out.appendPlainText(
                    "\n[user-site unavailable — retrying without --user]")
                self._start_stage(drop_user=True)
                return
            self.lbl.setText("Installation FAILED — see output below.")
            self.btn.setText("Close")
            try:
                try:
                    from ... import error_reporter
                except ImportError:
                    import error_reporter
                error_reporter.log_error(
                    "Install AI components", RuntimeError(tail))
            except Exception:
                pass
            QMessageBox.warning(
                self, "Install AI components",
                f"pip exited with code {code}. The log was saved — "
                "Velocity Nexus menu → Report a Problem to send it.")
            return
        self._stage += 1
        if self._stage < len(STAGES):
            self._start_stage()
            return
        self.lbl.setText("✅ All components installed.")
        self.btn.setText("Close")
        self.out.appendPlainText("\n=== DONE — all components installed ===")
        self.iface.messageBar().pushSuccess(
            "Velocity Nexus",
            "AI components installed — Detect Buildings is ready.")
        if self._on_done:
            try:
                self._on_done()
            except Exception:
                pass
