import sys, os
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')

# ============================================================
# HOME CONNECTIONS V1 — FAST BULK POPULATION
# Project: Potch - Mohadin PH2
# Uses dataProvider().changeAttributeValues() for speed
# UUID starts at DR1875440 (Phase 1 ended at DR1875439)
# ============================================================

HC_LAYER = 'Home Connection v1'
PON_LAYER = 'PON v1'
ZONE_LAYER = 'Zones v1'

SR = 'MOA'
UUID_START = 1875440

STATIC = {
    'type_1': 'Home Connection',
    'subtyp_1': 'ONT',
    'spec_1': 'Nokia ONT G-2425G-A',
    'dim1': 'H113*W170*D30mm',
    'dim2': '-',
    'cblcpty1': '1F',
    'conntr1': 'SC/APC',
    'status': 'No Sign-Up Registered',
    'pswrd': '-',
    'olt_add': '-',
    'apctmpnm': '"[""Final_L2_Service_Template""]"',
    'apc_arg': '"{}"',
    'srvc_nme': '"Final_L2_Service_Template"',
    'oltrx': '-22.2',
    'ontrx': '-26.0',
    'cmpownr': 'VelocityFibre',
    'type_2': 'Home Connection',
    'subtyp_2': 'UPS',
    'spec_2': 'GIZZU Lifepo 4 Mini 18W 38Wh',
    'dim1_2': 'L197*W132*H341mm',
    'subplace': '676007',
    'mainplce': '676007',
    'mun': 'JB Marks Local Municipality',
    'stackref': 'MOA',
    'crtdby': 'Johan Scholtz',
}

hc_layer = pon_layer = zone_layer = None
for lyr in QgsProject.instance().mapLayers().values():
    n = lyr.name()
    if n == HC_LAYER: hc_layer = lyr
    if n == PON_LAYER: pon_layer = lyr
    if n == ZONE_LAYER: zone_layer = lyr

missing = [n for n, l in [(HC_LAYER, hc_layer), (PON_LAYER, pon_layer), (ZONE_LAYER, zone_layer)] if not l]
if missing:
    print(f"ERROR: Missing layers: {missing}")
else:
    print(f"HC layer: {HC_LAYER} ({hc_layer.featureCount()} features)")
    from qgis.core import QgsSpatialIndex

    pon_index = QgsSpatialIndex(pon_layer.getFeatures())
    pon_feats = {f.id(): f for f in pon_layer.getFeatures()}
    zone_index = QgsSpatialIndex(zone_layer.getFeatures())
    zone_feats = {f.id(): f for f in zone_layer.getFeatures()}

    fields = hc_layer.fields()
    fidx = {fields.field(i).name(): i for i in range(fields.count())}
    static_indexed = {fidx[k]: v for k, v in STATIC.items() if k in fidx}

    iface.mapCanvas().setRenderFlag(False)

    changes = {}
    features = sorted(hc_layer.getFeatures(), key=lambda f: f.id())
    no_geom = 0
    pon_matched = 0
    pon_unmatched = 0
    sample = []
    assigned = 0

    for i, feat in enumerate(features):
        geom = feat.geometry()
        if geom is None or geom.isNull():
            no_geom += 1
            continue

        uuid_num = UUID_START + assigned
        assigned += 1
        uuid = f'DR{uuid_num}'
        label_1 = f'{SR}.ONT.{uuid}'

        pon_no = None
        for fid in pon_index.intersects(geom.boundingBox()):
            if pon_feats[fid].geometry().contains(geom):
                pon_no = pon_feats[fid]['pon_no']
                break
        if pon_no: pon_matched += 1
        else: pon_unmatched += 1

        zone_no = None
        for fid in zone_index.intersects(geom.boundingBox()):
            if zone_feats[fid].geometry().intersects(geom):
                zone_no = zone_feats[fid]['zone_no']
                break

        feat_changes = dict(static_indexed)
        if 'uuid' in fidx: feat_changes[fidx['uuid']] = uuid
        if 'label_1' in fidx: feat_changes[fidx['label_1']] = label_1
        if 'info' in fidx: feat_changes[fidx['info']] = uuid_num
        if 'pon_no' in fidx and pon_no: feat_changes[fidx['pon_no']] = pon_no
        if 'zone_no' in fidx and zone_no: feat_changes[fidx['zone_no']] = zone_no
        changes[feat.id()] = feat_changes

        if len(sample) < 5:
            sample.append(f"  {uuid} | {label_1} | pon={pon_no} | zone={zone_no}")

    hc_layer.dataProvider().changeAttributeValues(changes)
    hc_layer.reload()
    iface.mapCanvas().setRenderFlag(True)
    iface.mapCanvas().refresh()

    processed = len(changes)
    print("=" * 60)
    print("  HOME CONNECTIONS V1 POPULATION COMPLETE")
    print(f"  Processed: {processed}")
    print(f"  Skipped (no geometry): {no_geom}")
    print(f"  PON matched: {pon_matched} | unmatched: {pon_unmatched}")
    print(f"  UUID range: DR{UUID_START} → DR{UUID_START + processed - 1}")
    print("=" * 60)
    print("\nSample — first 5:")
    for s in sample: print(s)
