try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

# -*- coding: utf-8 -*-
"""Shared dock opener — every plugin panel opens natively in QGIS, full height.

QMainWindow owns the dock from the moment ``addDockWidget`` returns.  There is no
deferred callback and no programmatic float/re-show cycle, so plugin hot reload
cannot leave old code touching a deleted QDockWidget.

A panel that opens on the right while Velocity Nexus Home (or any other panel) is
already docked there is TABBED onto it and brought to the front, so it takes the
whole right side instead of being squeezed into a strip under Home (JJ 2026-10-23:
"it should take up this whole right side ... I don't want anything to open half").

Qt6/Qt5-safe: Qt via the qgis.PyQt shim, fully-scoped enums, no QGIS work at
import time (everything is inside the function).
"""

__all__ = ["bring_forward", "dock_fully"]

HOME_NAME = "VelocityHomePanel"


def _anchor(main_window, dock, area):
    """The docked, visible panel to tab onto: Velocity Nexus Home first, else any other."""
    from qgis.PyQt.QtWidgets import QDockWidget
    home = main_window.findChild(QDockWidget, HOME_NAME)
    others = [d for d in main_window.findChildren(QDockWidget) if d is not home]
    for d in ([home] if home is not None else []) + others:
        if d is None or d is dock:
            continue
        try:
            if d.isVisible() and not d.isFloating() and main_window.dockWidgetArea(d) == area:
                return d
        except RuntimeError:     # a dock deleted under us
            continue
    return None


def bring_forward(iface, dock, area=None):
    """Show `dock` over the whole side it is docked on: tab it onto the panel already there
    and raise its tab. A dock the operator floated stays floating. Returns ``dock``."""
    from qgis.PyQt.QtCore import Qt
    if area is None:
        area = Qt.DockWidgetArea.RightDockWidgetArea
    try:
        main_window = iface.mainWindow()
        if (main_window is not None and dock.objectName() != HOME_NAME and not dock.isFloating()
                and main_window.dockWidgetArea(dock) == area):
            anchor = _anchor(main_window, dock, area)
            if anchor is not None and dock not in main_window.tabifiedDockWidgets(anchor):
                main_window.tabifyDockWidget(anchor, dock)
    except Exception:
        _swallowed_note()
    try:
        dock.show()
        dock.raise_()
    except Exception:
        _swallowed_note()
    return dock


def dock_fully(iface, dock, area=None, width=440, prefer_float=False):
    """Register a QDockWidget with QGIS, full height, in front.

    iface        : QgisInterface (its mainWindow hosts the dock).
    dock         : the QDockWidget to open.
    area         : Qt.DockWidgetArea; defaults to the right edge.
    width        : docked width hint in pixels; full height comes from tabbing onto the
                   panel already on that side (see bring_forward).
    ``prefer_float`` remains in the public signature for old callers but is
    intentionally ignored. Floating is now an operator action through Qt's native
    title bar, never a startup side effect. Returns ``dock`` for chaining.
    """
    from qgis.PyQt.QtCore import Qt
    if area is None:
        area = Qt.DockWidgetArea.RightDockWidgetArea
    try:
        iface.addDockWidget(area, dock)
    except Exception:
        return dock
    bring_forward(iface, dock, area)
    # Side docks size by width; top/bottom docks size by height. Synchronous, no float cycle.
    try:
        horizontal = area not in (
            Qt.DockWidgetArea.TopDockWidgetArea,
            Qt.DockWidgetArea.BottomDockWidgetArea,
        )
        orientation = (
            Qt.Orientation.Horizontal if horizontal else Qt.Orientation.Vertical
        )
        main_window = iface.mainWindow()
        if main_window is not None:
            main_window.resizeDocks(
                [dock], [max(int(width), 360)], orientation
            )
    except Exception:
        _swallowed_note()
    return dock
