"""PON Boundary Reshaper — the dialog. Ticket #139 (Luke, 2026-07-28).

# claude:boq-impact NONE by itself. This tool reshapes PON BOUNDARY OUTLINES and
# nothing else: it never adds, removes or relabels a feature, and it never writes
# to a demand point, splitter, pole or cable. No component quantity changes, so no
# BoQ line moves. It is also refused outright on a shipped project's layers unless
# the operator picks them deliberately — and the operator, not this code, chooses
# which layer to reshape.
#
# claude:intent MUTATE — user asked: "enhance this ticket prompt ans build this
# tool for luke", ticket #139: "I want to be able to change my bubble looking PON
# boundaries to be more like the straight Polygon looking ones. add the feautre
# into the network planner and name it PON boundary reshaper." Plan: an
# operator-driven dialog. It previews every change first, refuses to write without
# a backup that has been re-opened and read back, writes ONLY polygon geometry on
# the one layer the operator chose, and then re-reads its own work to prove what
# landed. The write is a deliberate button press by the planner, never automatic.
#
# claude:approved-destructive — writing is gated on `pon_merge.backup_is_usable`,
# the same gate the Merge tool uses: the backup must already exist on disk AND
# re-open as a readable dataset before a single geometry is written. If the backup
# cannot be written or cannot be read back, nothing is reshaped at all.

Qt6-safe per the plugin's rules: imports through the ``qgis.PyQt`` shim, fully
scoped enums, ``WA_DeleteOnClose``, and every value read while the dialog is alive.
"""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QComboBox,
    QDialog,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from . import boundary_reshaper as reshaper
from . import field_names as vf_fields
from . import pon_merge

_HEADERS = ["PON", "Corners now", "After", "Change", "Area change"]


class _PctItem(QTableWidgetItem):
    """A "+17.5%" cell that sorts by how BIG the change is, not as text.

    Two bugs in one. ``QTableWidgetItem`` compares its DisplayRole, so a plain
    text cell sorts "+17.5%" before "+9.0%" and puts "-161.4%" — the single
    biggest movement in the layer — in the middle of the list. And because
    ``setSortingEnabled(True)`` re-sorts immediately, filling the table in
    worst-first order and then switching sorting on threw that order away
    entirely (caught by check_ui.py: the first three rows came out 17.5, 17.2,
    143.8).

    Sorting on the ABSOLUTE change is deliberate: the planner wants the
    boundaries that move most at the top, and a boundary that shrank 161% is
    every bit as worth looking at as one that grew 161%.
    """

    def __init__(self, pct):
        super().__init__(f"{pct:+.1f}%")
        self._pct = abs(float(pct))
        self.setTextAlignment(int(Qt.AlignmentFlag.AlignRight
                                 | Qt.AlignmentFlag.AlignVCenter))

    def __lt__(self, other):
        if isinstance(other, _PctItem):
            return self._pct < other._pct
        return super().__lt__(other)


class BoundaryReshaperDialog(QDialog):
    """Preview and apply a straight-edge reshape of one PON boundary layer."""

    def __init__(self, project, parent=None, term="PON"):
        super().__init__(parent)
        self._project = project
        self._term = term or "PON"
        self._changes = {}
        self._stats = {}
        self.setWindowTitle(f"{self._term} Boundary Reshaper")
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self.setMinimumSize(660, 560)
        self._build()
        self._refresh_layer_lists()

    # ── construction ────────────────────────────────────────────────────────
    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(10)

        intro = QLabel(
            f"Rebuilds each {self._term} boundary with straight edges instead of "
            "the rounded &ldquo;bubble&rdquo; outline.<br>"
            "Nothing is written until you press <b>Reshape</b>, and a backup is "
            "taken and read back first.")
        intro.setWordWrap(True)
        intro.setTextFormat(Qt.TextFormat.RichText)
        root.addWidget(intro)

        grid = QGridLayout()
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(6)

        grid.addWidget(QLabel(f"{self._term} boundaries:"), 0, 0)
        self._cbo_boundary = QComboBox()
        self._cbo_boundary.currentIndexChanged.connect(self._on_boundary_changed)
        grid.addWidget(self._cbo_boundary, 0, 1)

        grid.addWidget(QLabel("Built from:"), 1, 0)
        self._cbo_demand = QComboBox()
        grid.addWidget(self._cbo_demand, 1, 1)

        grid.addWidget(QLabel("Method:"), 2, 0)
        self._cbo_mode = QComboBox()
        # userData carries the mode key, so re-ordering or re-wording the visible
        # text can never silently change which engine runs.
        self._cbo_mode.addItem("Rebuild from the homes — straightest",
                               reshaper.MODE_RETILE)
        self._cbo_mode.addItem("Keep my outline, just straighten it",
                               reshaper.MODE_SIMPLIFY)
        self._cbo_mode.currentIndexChanged.connect(self._on_mode_changed)
        grid.addWidget(self._cbo_mode, 2, 1)

        # Tickets #141 + #142 (Luke): the tiles come out flush against each
        # other and he wants a visible 5-10 m separation between them.
        grid.addWidget(QLabel(f"Gap between {self._term}s:"), 3, 0)
        self._spin_gap = QSpinBox()
        self._spin_gap.setRange(0, int(reshaper.GAP_MAX_M))
        self._spin_gap.setSingleStep(1)
        self._spin_gap.setSuffix(" m")
        self._spin_gap.setValue(int(reshaper.GAP_DEFAULT_M))
        self._spin_gap.setSpecialValueText("none — edges touch")
        self._gap_tip = (
            f"Pull every {self._term} back by half this, so neighbours end up "
            "this far apart.\n"
            "Set 0 for the old behaviour, where the boundaries share an edge.\n"
            "A home sitting right on a shared edge can land in the gap — the "
            "preview counts them, and no home changes "
            f"{self._term} either way.")
        self._spin_gap.setToolTip(self._gap_tip)
        self._spin_gap.valueChanged.connect(self._invalidate)
        grid.addWidget(self._spin_gap, 3, 1)
        grid.setColumnStretch(1, 1)
        root.addLayout(grid)

        self._shape = QLabel("")
        self._shape.setWordWrap(True)
        root.addWidget(self._shape)

        btn_row = QHBoxLayout()
        self._btn_preview = QPushButton("Show me what changes")
        self._btn_preview.clicked.connect(self._on_preview)
        btn_row.addWidget(self._btn_preview)
        btn_row.addStretch(1)
        root.addLayout(btn_row)

        self._table = QTableWidget(0, len(_HEADERS))
        self._table.setHorizontalHeaderLabels(_HEADERS)
        self._table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers)
        self._table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setAlternatingRowColors(True)
        self._table.setSortingEnabled(True)
        head = self._table.horizontalHeader()
        head.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for c in range(1, len(_HEADERS)):
            head.setSectionResizeMode(c, QHeaderView.ResizeMode.ResizeToContents)
        root.addWidget(self._table, 1)

        self._summary = QLabel("")
        self._summary.setWordWrap(True)
        root.addWidget(self._summary)

        foot = QHBoxLayout()
        foot.addStretch(1)
        self._btn_apply = QPushButton("Reshape")
        self._btn_apply.setEnabled(False)
        self._btn_apply.clicked.connect(self._on_apply)
        foot.addWidget(self._btn_apply)
        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.reject)
        foot.addWidget(btn_close)
        root.addLayout(foot)

    # ── layer lists ─────────────────────────────────────────────────────────
    def _refresh_layer_lists(self):
        self._cbo_boundary.blockSignals(True)
        self._cbo_boundary.clear()
        for lyr in reshaper.candidate_boundary_layers(self._project):
            self._cbo_boundary.addItem(lyr.name().strip(), lyr.id())
        self._cbo_boundary.blockSignals(False)
        if self._cbo_boundary.count() == 0:
            # Say WHAT was looked for. "Nothing found" with no reason sends the
            # operator hunting through their layer list; naming the columns lets
            # them see in one glance that their project spells it differently.
            # Measured case: a Fibertime project stores the PON as `pon_no`,
            # which is deliberately NOT an alias here — it is a different
            # concept elsewhere in the plugin, and widening the shared resolver
            # would silently change which column a dozen other tools read.
            wanted = ", ".join(
                sorted({n for n in vf_fields.ALIASES[vf_fields.PON_NUM]}))
            self._summary.setText(
                f"<b>Nothing to reshape.</b> No polygon layer in this project "
                f"carries a {self._term} number column.<br>"
                f"Looked for a column named: <i>{wanted}</i>.")
            self._btn_preview.setEnabled(False)
            self._shape.setText("")
            return
        self._on_boundary_changed()

    def _layer(self, combo):
        lid = combo.currentData()
        if not lid:
            return None
        try:
            return self._project.mapLayer(lid)
        except Exception:
            return None

    def _on_boundary_changed(self, *_a):
        self._invalidate()
        boundary = self._layer(self._cbo_boundary)
        if boundary is None:
            return

        # Auto-pair by MEASURED containment, then let the operator override. The
        # measured pick is pre-selected so the common case is one click, but the
        # number behind it is shown — a pairing the operator cannot see is the
        # one that wrote into another town's layers.
        picked, frac = reshaper.pair_demand_layer(self._project, boundary)
        self._cbo_demand.blockSignals(True)
        self._cbo_demand.clear()
        for lyr in reshaper.candidate_demand_layers(self._project):
            self._cbo_demand.addItem(lyr.name().strip(), lyr.id())
        if picked is not None:
            idx = self._cbo_demand.findData(picked.id())
            if idx >= 0:
                self._cbo_demand.setCurrentIndex(idx)
        self._cbo_demand.blockSignals(False)

        m = reshaper.measure(boundary)
        if m["straight"]:
            shape = (f"<b>Already straight</b> — {m['pons']} {self._term}s, "
                     f"typically {m['median']:.0f} corners each.")
        else:
            shape = (f"<b>Rounded outlines</b> — {m['pons']} {self._term}s, "
                     f"typically {m['median']:.0f} corners each "
                     f"(up to {m['max']}). Straight ones have about "
                     f"{reshaper.STRAIGHT_MEDIAN_VERTICES} or fewer.")
        if picked is None:
            shape += ("<br><span style='color:#b3352e;'>No demand-point layer "
                      "matches this one — only "
                      f"{frac:.0%} of the nearest candidate's homes fall inside "
                      "these boundaries. Pick the right one above.</span>")
        else:
            shape += (f"<br>{frac:.1%} of <b>{picked.name().strip()}</b>'s homes "
                      "sit inside these boundaries.")
        self._shape.setText(shape)

    def _on_mode_changed(self, *_a):
        self._invalidate()
        simplify = self._cbo_mode.currentData() == reshaper.MODE_SIMPLIFY
        # Simplify never reads the homes — showing a demand layer would imply it
        # does, and an implied input is how an operator ends up blaming the wrong
        # layer for a bad result.
        self._cbo_demand.setEnabled(not simplify)
        # Same reasoning for the gap: simplify keeps outlines that may already
        # overlap, so a uniform inset does NOT open a uniform gap there (measured
        # — it made the closest pair CLOSER). Greyed out rather than silently
        # ignored, so the control never promises something it will not deliver.
        self._spin_gap.setEnabled(not simplify)
        self._spin_gap.setToolTip(
            "Only available when rebuilding from the homes — simplify keeps your "
            "existing outlines, which can already overlap, so an inset there does "
            "not produce an even gap."
            if simplify else self._gap_tip)

    def _invalidate(self):
        self._changes = {}
        self._stats = {}
        self._btn_apply.setEnabled(False)
        self._table.setRowCount(0)

    # ── preview ─────────────────────────────────────────────────────────────
    def _num(self, value):
        item = QTableWidgetItem()
        item.setData(Qt.ItemDataRole.DisplayRole, value)
        item.setTextAlignment(int(Qt.AlignmentFlag.AlignRight
                                 | Qt.AlignmentFlag.AlignVCenter))
        return item

    def _on_preview(self):
        boundary = self._layer(self._cbo_boundary)
        if boundary is None:
            return
        mode = self._cbo_mode.currentData()
        demand = None if mode == reshaper.MODE_SIMPLIFY \
            else self._layer(self._cbo_demand)

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            changes, stats = reshaper.plan(self._project, boundary,
                                           demand_layer=demand, mode=mode,
                                           gap_m=float(self._spin_gap.value()))
        except Exception as exc:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "Reshaper",
                                 f"The preview could not be built:\n{exc}")
            return
        finally:
            QApplication.restoreOverrideCursor()

        self._changes, self._stats = changes, stats
        if not changes:
            self._table.setRowCount(0)
            self._btn_apply.setEnabled(False)
            self._summary.setText(
                "<span style='color:#b3352e;'>Nothing to reshape — "
                f"{stats.get('reason') or 'no reason reported'}.</span>")
            return

        rows = reshaper.preview_rows(boundary, changes)
        self._table.setSortingEnabled(False)
        self._table.setRowCount(len(rows))
        bold = QFont()
        bold.setBold(True)
        for r, (pon, before, after, delta) in enumerate(rows):
            self._table.setItem(r, 0, QTableWidgetItem(str(pon)))
            self._table.setItem(r, 1, self._num(int(before)))
            self._table.setItem(r, 2, self._num(int(after)))
            drop = self._num(int(after - before))
            self._table.setItem(r, 3, drop)
            area = _PctItem(delta)
            # A boundary whose area moves more than a tenth is worth a look
            # before committing — flagged, never blocked. It is the planner's
            # call, and on a rounded outline a big change is often the point.
            if abs(delta) >= 10.0:
                area.setForeground(QColor("#b06000"))
                area.setFont(bold)
            self._table.setItem(r, 4, area)
        # Sorting ON first, then sort explicitly. Enabling it re-sorts by
        # whatever column Qt currently points at, which is how the worst-first
        # order got thrown away — so the order has to be (re)asserted after.
        self._table.setSortingEnabled(True)
        self._table.sortItems(4, Qt.SortOrder.DescendingOrder)

        befores = [r[1] for r in rows]
        afters = [r[2] for r in rows]
        parts = [f"<b>{len(rows)}</b> {self._term} boundaries would be reshaped",
                 f"typically {reshaper._median(befores):.0f} &rarr; "
                 f"<b>{reshaper._median(afters):.0f}</b> corners each"]
        gap = stats.get("gap_m") or 0
        if gap:
            parts.append(f"<b>{gap:.0f} m</b> gap between neighbours")
            # State the price of the gap up front. A home on a shared edge lands
            # in the gutter; that is inherent to a gap, so it is reported rather
            # than hidden. Membership is unaffected — it lives in the attribute.
            demand_for_count = self._layer(self._cbo_demand)
            outside, checked = reshaper.homes_in_gap(changes, demand_for_count)
            if checked and outside:
                parts.append(
                    f"<span style='color:#b06000;'>{outside} of {checked} homes "
                    f"fall in the gap (no {self._term} outline around them; "
                    "their PON number is unchanged)</span>")
        if stats.get("too_thin"):
            parts.append(f"<span style='color:#b06000;'>{stats['too_thin']} too "
                         "narrow for the gap — left flush</span>")
        if stats.get("untiled"):
            parts.append(f"{stats['untiled']} left as they are (no homes in them)")
        if stats.get("aoi_clipped"):
            parts.append(f"{stats['aoi_clipped']} trimmed to the project area")
        if stats.get("homes_outside"):
            parts.append(f"{stats['homes_outside']} homes end up on an edge")
        self._summary.setText(" &middot; ".join(parts) + ".")
        self._btn_apply.setEnabled(True)

    # ── apply ───────────────────────────────────────────────────────────────
    def _take_backup(self, boundary):
        """Snapshot the layer about to be written. ``(path, reason)``.

        Mirrors the Merge tool exactly, including returning the REASON: a project
        232 characters deep once blew the Windows path limit and the message
        named nothing, which cost a day.
        """
        try:
            parent = self.parent()
            writer = getattr(parent, "_pon_write_renumber_backup", None)
            if writer is None:
                return "", ("the Network Planner panel that owns the backup "
                            "writer is not available")
            ok, dest = writer([boundary])
            return (dest, "") if ok else ("", str(dest))
        except Exception as exc:
            return "", f"{type(exc).__name__}: {exc}"

    def _on_apply(self):
        boundary = self._layer(self._cbo_boundary)
        if boundary is None or not self._changes:
            return
        name = boundary.name().strip()
        n = len(self._changes)
        if QMessageBox.question(
                self, f"{self._term} Boundary Reshaper",
                f"Reshape {n} boundaries on <b>{name}</b>?<br><br>"
                "Only the outlines change — no home, splitter, pole or cable is "
                "touched, and no home changes "
                f"{self._term}.<br><br>A backup is taken first.",
                QMessageBox.StandardButton.Yes
                | QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
            return

        # REFUSE WHILE THE LAYER IS BEING EDITED. changeGeometryValues goes
        # straight to the provider, under the edit buffer — so an operator with
        # unsaved edits open would have them silently discarded by the reload
        # below. Same class as the label wizard's LayersEditableError: check
        # before the write, never after.
        if boundary.isEditable():
            QMessageBox.warning(
                self, f"{self._term} Boundary Reshaper",
                f"<b>{name}</b> is open for editing, so nothing was reshaped."
                "<br><br>Save or discard your edits on that layer first — "
                "reshaping writes straight to the file, and any unsaved edit "
                "would be lost.")
            return

        backup, why = self._take_backup(boundary)
        if not backup:
            QMessageBox.critical(
                self, f"{self._term} Boundary Reshaper",
                f"Nothing was reshaped — the backup could not be written, so "
                f"the reshape was refused.\n\nReason: {why}")
            return
        ok_backup, backup_why = pon_merge.backup_is_usable(backup)
        if not ok_backup:
            QMessageBox.critical(
                self, f"{self._term} Boundary Reshaper",
                f"Nothing was reshaped — {backup_why}\n\n"
                "A backup that cannot be re-opened is not a backup.")
            return

        before = reshaper.measure(boundary)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            written = boundary.dataProvider().changeGeometryValues(
                dict(self._changes))
            boundary.reload()
            boundary.triggerRepaint()
        except Exception as exc:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(
                self, f"{self._term} Boundary Reshaper",
                f"The reshape failed and stopped:\n{exc}\n\nBackup: {backup}")
            return
        finally:
            QApplication.restoreOverrideCursor()

        if not written:
            QMessageBox.critical(
                self, f"{self._term} Boundary Reshaper",
                "The layer refused the change — nothing was reshaped.\n\n"
                f"Backup: {backup}")
            return

        # PROVE IT. A provider call can return True and still have been rejected,
        # so the numbers reported below are re-measured off the layer, never taken
        # from the plan that was handed to it.
        after = reshaper.measure(boundary)
        verdict = ("now straight" if after["straight"]
                   else "still rounded — nothing was rejected, but the result "
                        "did not reach the straight band")
        self._invalidate()
        self._on_boundary_changed()
        QMessageBox.information(
            self, f"{self._term} Boundary Reshaper",
            f"Reshaped {n} boundaries on {name}.\n\n"
            f"Corners per boundary: {before['median']:.0f} → "
            f"{after['median']:.0f} (worst {before['max']} → {after['max']}) — "
            f"{verdict}.\n"
            f"{after['pons']} {self._term}s before and after.\n\n"
            f"Backup: {backup}")


def open_boundary_reshaper(project, parent=None, term="PON"):
    """Open the reshaper. Modeless so the planner can pan the map while it is up."""
    dlg = BoundaryReshaperDialog(project, parent=parent, term=term)
    dlg.show()
    return dlg
