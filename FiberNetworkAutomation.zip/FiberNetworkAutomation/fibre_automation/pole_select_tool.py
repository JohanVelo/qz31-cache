"""QGIS rectangle drag-select map tool, bound to ONE pole layer.

Qt6-safe: everything imports through the qgis.PyQt shim, enums are fully
scoped, and signal disconnects are guarded with sip.isdeleted — the publish
qt6 hard-crash lint enforces all three.

WHAT THIS DELIBERATELY DOES NOT DO
----------------------------------
It does not renumber, preview, cascade or write anything. It captures a
selection and hands plain dicts to the pure model in pole_selection.py.

API NOTE (measured 2026-08-03, QGIS 4.0.3): QgsMapToolSelectUtils — named in
the original handoff as the thing to build on — is NOT exposed in the Python
bindings on this install. QgsMapToolExtent, QgsRubberBand and the four
Qgis.SelectBehavior values ARE. So the rectangle is drawn with QgsRubberBand
on a plain QgsMapTool and the modifier convention is applied by
pole_selection.select_mode_for_modifiers.
"""

from qgis.PyQt import sip
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsCoordinateTransform, QgsGeometry, QgsPointXY, QgsProject,
    QgsRectangle, QgsWkbTypes,
)
from qgis.gui import QgsMapTool, QgsRubberBand

from . import pole_selection as ps

# A drag shorter than this is a click, not a rectangle — a click would
# otherwise sweep a zero-area box and silently clear the whole selection.
_MIN_DRAG_PX = 3


def _alive(obj):
    """True when a wrapped C++ object is still there."""
    if obj is None:
        return False
    try:
        return not sip.isdeleted(obj)
    except Exception:
        return True


class PoleRectSelectTool(QgsMapTool):
    """Drag a rectangle; emit the poles inside it, plus the drag mode.

    polesPicked(list, str) — [{"fid","x","y","attrs"}, ...], mode
    cancelled()            — Esc pressed mid-drag
    """

    polesPicked = pyqtSignal(list, str)
    cancelled = pyqtSignal()

    def __init__(self, canvas, layer_id):
        super().__init__(canvas)
        self._canvas = canvas
        self._layer_id = layer_id
        self._start = None
        self._dragging = False
        self._band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PolygonGeometry)
        self._band.setColor(QColor(0, 229, 255, 60))
        self._band.setStrokeColor(QColor(0, 229, 255, 220))
        self._band.setWidth(2)
        self._band.reset(QgsWkbTypes.GeometryType.PolygonGeometry)

    # -- identity ------------------------------------------------------
    def layer(self):
        """Resolve BY ID every time. Resolving by name would bind the wrong
        layer on a project holding two layers both called 'Poles' — PH2 has
        exactly that (5,393 and 4,869 features) beside 'poles v1' (1,924)."""
        try:
            return QgsProject.instance().mapLayer(self._layer_id)
        except Exception:
            return None

    def flags(self):
        return QgsMapTool.Flag.ShowContextMenu

    # -- drag ----------------------------------------------------------
    def canvasPressEvent(self, event):
        if event.button() != Qt.MouseButton.LeftButton:
            return
        self._start = event.pos()
        self._dragging = True
        self._band.reset(QgsWkbTypes.GeometryType.PolygonGeometry)

    def canvasMoveEvent(self, event):
        if not self._dragging or self._start is None:
            return
        self._draw(self._start, event.pos())

    def canvasReleaseEvent(self, event):
        if not self._dragging or self._start is None:
            return
        start, self._start, self._dragging = self._start, None, False
        end = event.pos()
        self._band.reset(QgsWkbTypes.GeometryType.PolygonGeometry)
        if (abs(end.x() - start.x()) < _MIN_DRAG_PX
                and abs(end.y() - start.y()) < _MIN_DRAG_PX):
            return                       # a click, not a rectangle
        mods = event.modifiers()
        mode = ps.select_mode_for_modifiers(
            bool(mods & Qt.KeyboardModifier.ShiftModifier),
            bool(mods & Qt.KeyboardModifier.ControlModifier),
        )
        rect = self._map_rect(start, end)
        if rect is None:
            return
        self.polesPicked.emit(self._poles_in(rect), mode)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self._start = None
            self._dragging = False
            self._band.reset(QgsWkbTypes.GeometryType.PolygonGeometry)
            self.cancelled.emit()

    # -- geometry ------------------------------------------------------
    def _draw(self, a, b):
        rect = self._map_rect(a, b)
        if rect is None:
            return
        self._band.setToGeometry(QgsGeometry.fromRect(rect), None)

    def _map_rect(self, a, b):
        try:
            p1 = self.toMapCoordinates(a)
            p2 = self.toMapCoordinates(b)
        except Exception:
            return None
        return QgsRectangle(QgsPointXY(p1), QgsPointXY(p2))

    def _poles_in(self, rect):
        """Features whose point INTERSECTS the rectangle — QGIS's own
        select-by-rectangle semantics for point layers.

        The rectangle is in canvas CRS; the layer may be in another, so it is
        transformed into the LAYER's CRS before the request rather than
        comparing coordinates from two different systems.
        """
        layer = self.layer()
        if layer is None:
            return []
        try:
            from qgis.core import QgsFeatureRequest
            box = QgsRectangle(rect)
            canvas_crs = self._canvas.mapSettings().destinationCrs()
            layer_crs = layer.crs()
            if canvas_crs != layer_crs:
                tr = QgsCoordinateTransform(
                    canvas_crs, layer_crs, QgsProject.instance())
                box = tr.transformBoundingBox(box)
            picked = []
            request = QgsFeatureRequest().setFilterRect(box)
            names = [f.name() for f in layer.fields()]
            for feat in layer.getFeatures(request):
                geom = feat.geometry()
                if geom is None or geom.isEmpty():
                    continue
                point = geom.asPoint()
                if not box.contains(QgsPointXY(point)):
                    continue
                picked.append({
                    "fid": feat.id(),        # hint only — never identity
                    "x": point.x(),
                    "y": point.y(),
                    "attrs": {n: feat[n] for n in names},
                })
            return picked
        except Exception:
            return []

    # -- lifecycle -----------------------------------------------------
    def deactivate(self):
        """Always leave the canvas clean, however the tool was dropped."""
        try:
            if _alive(self._band):
                self._band.reset(QgsWkbTypes.GeometryType.PolygonGeometry)
        except Exception:
            pass
        self._start = None
        self._dragging = False
        try:
            super().deactivate()
        except Exception:
            pass

    def cleanup(self):
        """Drop the rubber band's scene item. Safe to call twice."""
        self.deactivate()
        try:
            if _alive(self._band) and _alive(self._canvas):
                self._canvas.scene().removeItem(self._band)
        except Exception:
            pass
        self._band = None


class MapToolSwap(object):
    """Install a tool and guarantee the previous one comes back.

    The operator must never be stranded with a dead tool and no way back to
    pan/identify — so restoration happens on end(), on dock close and on
    plugin unload, and end() is safe to call more than once.
    """

    def __init__(self, canvas):
        self._canvas = canvas
        self._previous = None
        self._tool = None

    @property
    def active(self):
        return self._tool is not None

    def start(self, tool):
        if self._tool is not None:
            self.end()
        try:
            self._previous = self._canvas.mapTool()
        except Exception:
            self._previous = None
        self._tool = tool
        self._canvas.setMapTool(tool)
        return tool

    def end(self):
        """Restore the previous tool. Idempotent."""
        tool, self._tool = self._tool, None
        if tool is None:
            return False
        try:
            if _alive(self._previous):
                self._canvas.setMapTool(self._previous)
            elif _alive(self._canvas):
                self._canvas.unsetMapTool(tool)
        except Exception:
            pass
        try:
            if hasattr(tool, "cleanup"):
                tool.cleanup()
        except Exception:
            pass
        self._previous = None
        return True
