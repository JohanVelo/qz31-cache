# Label Feeder Joints Algorithm

from qgis.core import (
    QgsProcessingParameterVectorLayer,
    QgsProcessing
)

from .base_algorithm import BaseFiberAlgorithm


class LabelFeederJointsAlgorithm(BaseFiberAlgorithm):
    """Algorithm to label Feeder Joint layers"""

    def name(self):
        return 'labelfeederjoints'

    def displayName(self):
        return '5. Label Feeder Joints'

    def shortHelpString(self):
        return """
        Auto-populate Feeder Joint fields.

        Fields updated:
        - Label: PRAK-Z01-AG01, AG02... (aggregation point labels, 2-digit padding)
        - fid: 1, 2, 3...
        """

    def initAlgorithm(self, config=None):
        # Input layer
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT,
                'Feeder Joints Layer',
                [QgsProcessing.SourceType.TypeVectorPoint]
            )
        )

        # Project selection
        self.add_common_parameters()

    def processAlgorithm(self, parameters, context, feedback):
        # Get parameters
        layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        project = self.get_project_code(parameters, context)

        feedback.pushInfo(f"Labeling Feeder Joints for {project}...")

        # Update fid
        feedback.pushInfo("Updating fid...")
        self.calculate_field(layer, "fid", "@row_number", feedback)

        # Update Label (2-digit padding)
        feedback.pushInfo("Updating Label...")
        formula = f"'{project}-Z01-AG' || lpad(to_string(\"fid\"), 2, '0')"
        self.calculate_field(layer, "Label", formula, feedback)

        layer.triggerRepaint()
        feedback.pushInfo("✅ Feeder Joints labeled successfully!")

        return {self.INPUT: layer.id()}
