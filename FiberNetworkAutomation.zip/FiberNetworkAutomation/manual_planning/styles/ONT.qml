<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyDrawingHints="1" symbologyReferenceScale="-1" maxScale="0" hasScaleBasedVisibilityFlag="0" minScale="100000000" simplifyDrawingTol="1" simplifyLocal="1" styleCategories="AllStyleCategories" autoRefreshMode="Disabled" simplifyAlgorithm="0" version="3.44.4-Solothurn" readOnly="0" labelsEnabled="0" autoRefreshTime="0" simplifyMaxScale="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endField="" startExpression="" endExpression="" durationField="" mode="0" limitMode="0" startField="" enabled="0" fixedDuration="0" durationUnit="min" accumulate="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation zoffset="0" extrusion="0" type="IndividualFeatures" zscale="1" clamping="Terrain" extrusionEnabled="0" binding="Centroid" customToleranceEnabled="0" showMarkerSymbolInSurfacePlots="0" symbology="Line" respectLayerSymbol="1">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol name="" clip_to_extent="1" type="line" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleLine" id="{98c3007f-f227-48a6-a026-cfcd2563ba00}" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="152,125,183,255,rgb:0.5960784,0.4901961,0.7176471,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol name="" clip_to_extent="1" type="fill" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleFill" id="{f1bca951-8926-4e64-95eb-70aa3900d063}" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="152,125,183,255,rgb:0.5960784,0.4901961,0.7176471,1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="109,89,131,255,rgb:0.4257572,0.3501335,0.5125963,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol name="" clip_to_extent="1" type="marker" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleMarker" id="{21d8ab2a-6fe7-4caf-a7ba-44e46b222617}" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="152,125,183,255,rgb:0.5960784,0.4901961,0.7176471,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="diamond"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="109,89,131,255,rgb:0.4257572,0.3501335,0.5125963,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" type="singleSymbol" forceraster="0" referencescale="-1" symbollevels="0">
    <symbols>
      <symbol name="0" clip_to_extent="1" type="marker" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleMarker" id="{98149d58-f0fe-4e3d-b567-d1d65da2e64a}" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="190,207,80,255,rgb:0.745098,0.8117647,0.3137255,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="2"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
  </selection>
  <customproperties>
    <Option type="Map">
      <Option name="dualview/previewExpressions" type="List">
        <Option type="QString" value="&quot;label_1&quot;"/>
      </Option>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks type="StringList">
      <Option type="QString" value=""/>
    </activeChecks>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field name="label_1" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="type_1" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subtyp_1" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="spec_1" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim1" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim2" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cblcpty1" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="conntr1" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="status" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="serialno" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="revenue" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="uptime" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="uuid" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="pswrd" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="olt_add" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="apctmpnm" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="apc_arg" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="srvc_nme" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="info" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="oltrx" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ontrx" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="oltrxact" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ontrxact" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cmpownr" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="label_2" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="type_2" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subtyp_2" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="spec_2" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim1_2" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dim2_2" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cblcpty2" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="conntr2" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="strtfeat" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="endfeat" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sg21" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sg26" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="address" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="pon_no" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="zone_no" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subplace" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="mainplce" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="mun" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="stackref" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="datecrtd" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="crtdby" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="date_edt" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="editby" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="comments" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" index="0" field="label_1"/>
    <alias name="" index="1" field="type_1"/>
    <alias name="" index="2" field="subtyp_1"/>
    <alias name="" index="3" field="spec_1"/>
    <alias name="" index="4" field="dim1"/>
    <alias name="" index="5" field="dim2"/>
    <alias name="" index="6" field="cblcpty1"/>
    <alias name="" index="7" field="conntr1"/>
    <alias name="" index="8" field="status"/>
    <alias name="" index="9" field="serialno"/>
    <alias name="" index="10" field="revenue"/>
    <alias name="" index="11" field="uptime"/>
    <alias name="" index="12" field="uuid"/>
    <alias name="" index="13" field="pswrd"/>
    <alias name="" index="14" field="olt_add"/>
    <alias name="" index="15" field="apctmpnm"/>
    <alias name="" index="16" field="apc_arg"/>
    <alias name="" index="17" field="srvc_nme"/>
    <alias name="" index="18" field="info"/>
    <alias name="" index="19" field="oltrx"/>
    <alias name="" index="20" field="ontrx"/>
    <alias name="" index="21" field="oltrxact"/>
    <alias name="" index="22" field="ontrxact"/>
    <alias name="" index="23" field="cmpownr"/>
    <alias name="" index="24" field="label_2"/>
    <alias name="" index="25" field="type_2"/>
    <alias name="" index="26" field="subtyp_2"/>
    <alias name="" index="27" field="spec_2"/>
    <alias name="" index="28" field="dim1_2"/>
    <alias name="" index="29" field="dim2_2"/>
    <alias name="" index="30" field="cblcpty2"/>
    <alias name="" index="31" field="conntr2"/>
    <alias name="" index="32" field="strtfeat"/>
    <alias name="" index="33" field="endfeat"/>
    <alias name="" index="34" field="sg21"/>
    <alias name="" index="35" field="sg26"/>
    <alias name="" index="36" field="address"/>
    <alias name="" index="37" field="pon_no"/>
    <alias name="" index="38" field="zone_no"/>
    <alias name="" index="39" field="subplace"/>
    <alias name="" index="40" field="mainplce"/>
    <alias name="" index="41" field="mun"/>
    <alias name="" index="42" field="stackref"/>
    <alias name="" index="43" field="datecrtd"/>
    <alias name="" index="44" field="crtdby"/>
    <alias name="" index="45" field="date_edt"/>
    <alias name="" index="46" field="editby"/>
    <alias name="" index="47" field="comments"/>
  </aliases>
  <defaults>
    <default expression="" field="label_1" applyOnUpdate="0"/>
    <default expression="" field="type_1" applyOnUpdate="0"/>
    <default expression="" field="subtyp_1" applyOnUpdate="0"/>
    <default expression="" field="spec_1" applyOnUpdate="0"/>
    <default expression="" field="dim1" applyOnUpdate="0"/>
    <default expression="" field="dim2" applyOnUpdate="0"/>
    <default expression="" field="cblcpty1" applyOnUpdate="0"/>
    <default expression="" field="conntr1" applyOnUpdate="0"/>
    <default expression="" field="status" applyOnUpdate="0"/>
    <default expression="" field="serialno" applyOnUpdate="0"/>
    <default expression="" field="revenue" applyOnUpdate="0"/>
    <default expression="" field="uptime" applyOnUpdate="0"/>
    <default expression="" field="uuid" applyOnUpdate="0"/>
    <default expression="" field="pswrd" applyOnUpdate="0"/>
    <default expression="" field="olt_add" applyOnUpdate="0"/>
    <default expression="" field="apctmpnm" applyOnUpdate="0"/>
    <default expression="" field="apc_arg" applyOnUpdate="0"/>
    <default expression="" field="srvc_nme" applyOnUpdate="0"/>
    <default expression="" field="info" applyOnUpdate="0"/>
    <default expression="" field="oltrx" applyOnUpdate="0"/>
    <default expression="" field="ontrx" applyOnUpdate="0"/>
    <default expression="" field="oltrxact" applyOnUpdate="0"/>
    <default expression="" field="ontrxact" applyOnUpdate="0"/>
    <default expression="" field="cmpownr" applyOnUpdate="0"/>
    <default expression="" field="label_2" applyOnUpdate="0"/>
    <default expression="" field="type_2" applyOnUpdate="0"/>
    <default expression="" field="subtyp_2" applyOnUpdate="0"/>
    <default expression="" field="spec_2" applyOnUpdate="0"/>
    <default expression="" field="dim1_2" applyOnUpdate="0"/>
    <default expression="" field="dim2_2" applyOnUpdate="0"/>
    <default expression="" field="cblcpty2" applyOnUpdate="0"/>
    <default expression="" field="conntr2" applyOnUpdate="0"/>
    <default expression="" field="strtfeat" applyOnUpdate="0"/>
    <default expression="" field="endfeat" applyOnUpdate="0"/>
    <default expression="" field="sg21" applyOnUpdate="0"/>
    <default expression="" field="sg26" applyOnUpdate="0"/>
    <default expression="" field="address" applyOnUpdate="0"/>
    <default expression="" field="pon_no" applyOnUpdate="0"/>
    <default expression="" field="zone_no" applyOnUpdate="0"/>
    <default expression="" field="subplace" applyOnUpdate="0"/>
    <default expression="" field="mainplce" applyOnUpdate="0"/>
    <default expression="" field="mun" applyOnUpdate="0"/>
    <default expression="" field="stackref" applyOnUpdate="0"/>
    <default expression="" field="datecrtd" applyOnUpdate="0"/>
    <default expression="" field="crtdby" applyOnUpdate="0"/>
    <default expression="" field="date_edt" applyOnUpdate="0"/>
    <default expression="" field="editby" applyOnUpdate="0"/>
    <default expression="" field="comments" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="label_1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="type_1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subtyp_1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="spec_1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="cblcpty1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="conntr1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="status"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="serialno"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="revenue"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="uptime"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="uuid"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="pswrd"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="olt_add"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="apctmpnm"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="apc_arg"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="srvc_nme"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="info"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="oltrx"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="ontrx"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="oltrxact"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="ontrxact"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="cmpownr"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="label_2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="type_2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subtyp_2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="spec_2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim1_2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="dim2_2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="cblcpty2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="conntr2"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="strtfeat"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="endfeat"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="sg21"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="sg26"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="address"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="pon_no"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="zone_no"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="subplace"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="mainplce"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="mun"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="stackref"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="datecrtd"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="crtdby"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="date_edt"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="editby"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="comments"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" field="label_1" desc=""/>
    <constraint exp="" field="type_1" desc=""/>
    <constraint exp="" field="subtyp_1" desc=""/>
    <constraint exp="" field="spec_1" desc=""/>
    <constraint exp="" field="dim1" desc=""/>
    <constraint exp="" field="dim2" desc=""/>
    <constraint exp="" field="cblcpty1" desc=""/>
    <constraint exp="" field="conntr1" desc=""/>
    <constraint exp="" field="status" desc=""/>
    <constraint exp="" field="serialno" desc=""/>
    <constraint exp="" field="revenue" desc=""/>
    <constraint exp="" field="uptime" desc=""/>
    <constraint exp="" field="uuid" desc=""/>
    <constraint exp="" field="pswrd" desc=""/>
    <constraint exp="" field="olt_add" desc=""/>
    <constraint exp="" field="apctmpnm" desc=""/>
    <constraint exp="" field="apc_arg" desc=""/>
    <constraint exp="" field="srvc_nme" desc=""/>
    <constraint exp="" field="info" desc=""/>
    <constraint exp="" field="oltrx" desc=""/>
    <constraint exp="" field="ontrx" desc=""/>
    <constraint exp="" field="oltrxact" desc=""/>
    <constraint exp="" field="ontrxact" desc=""/>
    <constraint exp="" field="cmpownr" desc=""/>
    <constraint exp="" field="label_2" desc=""/>
    <constraint exp="" field="type_2" desc=""/>
    <constraint exp="" field="subtyp_2" desc=""/>
    <constraint exp="" field="spec_2" desc=""/>
    <constraint exp="" field="dim1_2" desc=""/>
    <constraint exp="" field="dim2_2" desc=""/>
    <constraint exp="" field="cblcpty2" desc=""/>
    <constraint exp="" field="conntr2" desc=""/>
    <constraint exp="" field="strtfeat" desc=""/>
    <constraint exp="" field="endfeat" desc=""/>
    <constraint exp="" field="sg21" desc=""/>
    <constraint exp="" field="sg26" desc=""/>
    <constraint exp="" field="address" desc=""/>
    <constraint exp="" field="pon_no" desc=""/>
    <constraint exp="" field="zone_no" desc=""/>
    <constraint exp="" field="subplace" desc=""/>
    <constraint exp="" field="mainplce" desc=""/>
    <constraint exp="" field="mun" desc=""/>
    <constraint exp="" field="stackref" desc=""/>
    <constraint exp="" field="datecrtd" desc=""/>
    <constraint exp="" field="crtdby" desc=""/>
    <constraint exp="" field="date_edt" desc=""/>
    <constraint exp="" field="editby" desc=""/>
    <constraint exp="" field="comments" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="&quot;label_1&quot;" sortOrder="0">
    <columns>
      <column name="label_1" type="field" width="-1" hidden="0"/>
      <column name="type_1" type="field" width="131" hidden="0"/>
      <column name="subtyp_1" type="field" width="-1" hidden="0"/>
      <column name="spec_1" type="field" width="-1" hidden="0"/>
      <column name="dim1" type="field" width="-1" hidden="0"/>
      <column name="dim2" type="field" width="-1" hidden="0"/>
      <column name="cblcpty1" type="field" width="-1" hidden="0"/>
      <column name="conntr1" type="field" width="-1" hidden="0"/>
      <column name="status" type="field" width="-1" hidden="0"/>
      <column name="serialno" type="field" width="-1" hidden="0"/>
      <column name="revenue" type="field" width="-1" hidden="0"/>
      <column name="uptime" type="field" width="-1" hidden="0"/>
      <column name="uuid" type="field" width="-1" hidden="0"/>
      <column name="pswrd" type="field" width="-1" hidden="0"/>
      <column name="olt_add" type="field" width="-1" hidden="0"/>
      <column name="apctmpnm" type="field" width="202" hidden="0"/>
      <column name="apc_arg" type="field" width="-1" hidden="0"/>
      <column name="srvc_nme" type="field" width="-1" hidden="0"/>
      <column name="info" type="field" width="-1" hidden="0"/>
      <column name="oltrx" type="field" width="-1" hidden="0"/>
      <column name="ontrx" type="field" width="-1" hidden="0"/>
      <column name="oltrxact" type="field" width="-1" hidden="0"/>
      <column name="ontrxact" type="field" width="-1" hidden="0"/>
      <column name="cmpownr" type="field" width="-1" hidden="0"/>
      <column name="label_2" type="field" width="-1" hidden="0"/>
      <column name="type_2" type="field" width="-1" hidden="0"/>
      <column name="subtyp_2" type="field" width="-1" hidden="0"/>
      <column name="spec_2" type="field" width="-1" hidden="0"/>
      <column name="dim1_2" type="field" width="-1" hidden="0"/>
      <column name="dim2_2" type="field" width="-1" hidden="0"/>
      <column name="cblcpty2" type="field" width="-1" hidden="0"/>
      <column name="conntr2" type="field" width="-1" hidden="0"/>
      <column name="strtfeat" type="field" width="-1" hidden="0"/>
      <column name="endfeat" type="field" width="-1" hidden="0"/>
      <column name="sg21" type="field" width="-1" hidden="0"/>
      <column name="sg26" type="field" width="-1" hidden="0"/>
      <column name="address" type="field" width="-1" hidden="0"/>
      <column name="pon_no" type="field" width="-1" hidden="0"/>
      <column name="zone_no" type="field" width="-1" hidden="0"/>
      <column name="subplace" type="field" width="-1" hidden="0"/>
      <column name="mainplce" type="field" width="-1" hidden="0"/>
      <column name="mun" type="field" width="173" hidden="0"/>
      <column name="stackref" type="field" width="-1" hidden="0"/>
      <column name="datecrtd" type="field" width="-1" hidden="0"/>
      <column name="crtdby" type="field" width="-1" hidden="0"/>
      <column name="date_edt" type="field" width="-1" hidden="0"/>
      <column name="editby" type="field" width="-1" hidden="0"/>
      <column name="comments" type="field" width="-1" hidden="0"/>
      <column type="actions" width="-1" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable/>
  <labelOnTop/>
  <reuseLastValue/>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"label_1"</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
