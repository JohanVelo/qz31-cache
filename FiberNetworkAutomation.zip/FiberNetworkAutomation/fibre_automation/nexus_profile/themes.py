"""themes — preset palettes + single-accent derivation + avatar colour.

Builds on the existing _build_qss(colour_dict) token system in
velocity_home_panel. A user picks a preset or a custom accent; we derive the
full ladder and persist it per username. Pure-ish (only stdlib colorsys +
hashlib); QColor only used when available.
"""
import colorsys
import hashlib

# 6 preset bases (full ~20-key dicts live in velocity_home_panel.THEMES for
# velocity/fibertime; these add the new ones as accent seeds the panel expands)
PRESETS = {
    "velocity":  {"label": "Velocity",  "accent": "#3B6FE0", "bg": "#0F1A30"},
    "fibertime": {"label": "fibertime",  "accent": "#1463FF", "bg": "#081634"},
    "forest":    {"label": "Forest",     "accent": "#5CCDA9", "bg": "#0A1410"},
    "graphite":  {"label": "Graphite",   "accent": "#2563EB", "bg": "#14161A"},
    "violet":    {"label": "Violet",     "accent": "#9D4EDD", "bg": "#120A2E"},
    "mono":      {"label": "Monochrome", "accent": "#9AA4B2", "bg": "#16181C"},
}

# Okabe-Ito colour-blind-safe accents offered in the picker
OKABE_ITO = ["#E69F00", "#56B4E9", "#009E73", "#F0E442",
             "#0072B2", "#D55E00", "#CC79A7", "#000000"]


def _clamp(x):
    return max(0.0, min(1.0, x))


def _hex_to_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))


def _rgb_to_hex(r, g, b):
    return "#%02x%02x%02x" % (int(_clamp(r) * 255),
                              int(_clamp(g) * 255), int(_clamp(b) * 255))


def _hls_to_hex(h, l, s):
    return _rgb_to_hex(*colorsys.hls_to_rgb(h, l, s))


def derive_accent(hex_accent):
    """One accent hex -> a 5-tone ladder for the QSS token system."""
    try:
        r, g, b = _hex_to_rgb(hex_accent)
    except Exception:
        r, g, b = _hex_to_rgb("#3B6FE0")
    h, l, s = colorsys.rgb_to_hls(r, g, b)
    return {
        "base": hex_accent,
        "hover": _hls_to_hex(h, _clamp(l + 0.15), s),
        "border": _hls_to_hex(h, _clamp(l - 0.20), s),
        "disabled": _hls_to_hex(h, _clamp(l - 0.40), min(0.3, s)),
        "badge_bg": _hls_to_hex(h, _clamp(l + 0.40), s),
    }


def contrast_ratio(fg_hex, bg_hex):
    """WCAG contrast ratio between two hex colours (1..21)."""
    def lum(hx):
        def chan(c):
            return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
        r, g, b = _hex_to_rgb(hx)
        return 0.2126 * chan(r) + 0.7152 * chan(g) + 0.0722 * chan(b)
    l1, l2 = lum(fg_hex), lum(bg_hex)
    hi, lo = max(l1, l2), min(l1, l2)
    return (hi + 0.05) / (lo + 0.05)


def accent_ok_on_dark(hex_accent, bg="#0F1A30"):
    """True if the accent meets WCAG AA for non-text UI elements (>=3:1) on
    the dark panel bg (the 3:1 graphical-object threshold, not the 4.5:1 body-
    text one — accents are used for borders/chips, not paragraph text)."""
    return contrast_ratio(hex_accent, bg) >= 3.0


def avatar_color(username):
    """Deterministic per-user colour (XEP-0392 style): hue from md5, mid S/L."""
    if not username:
        username = "user"
    hue = int(hashlib.md5(username.encode()).hexdigest()[:8], 16) % 360
    return _hls_to_hex(hue / 360.0, 0.42, 0.58)


def initials(name):
    parts = [p for p in str(name).strip().split() if p]
    if not parts:
        return "?"
    if len(parts) == 1:
        return parts[0][:2].upper()
    return (parts[0][0] + parts[-1][0]).upper()
