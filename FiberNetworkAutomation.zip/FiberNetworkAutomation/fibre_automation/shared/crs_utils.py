"""CRS validation and reprojection helpers."""

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
)


def ensure_projected(crs: QgsCoordinateReferenceSystem) -> bool:
    """Return True if CRS is projected (metres), False if geographic (degrees)."""
    return not crs.isGeographic()


def reproject_layer(layer, target_crs_authid: str):
    """Return a memory copy of layer reprojected to target_crs_authid."""
    import processing
    result = processing.run(
        "native:reprojectlayer",
        {
            "INPUT": layer,
            "TARGET_CRS": QgsCoordinateReferenceSystem(target_crs_authid),
            "OUTPUT": "memory:",
        },
    )
    return result["OUTPUT"]


def layer_crs_ok(layer, expected_authid: str) -> bool:
    """Check that a layer's CRS matches expected_authid."""
    return layer.crs().authid() == expected_authid


def transform_point(x: float, y: float, src_authid: str, dst_authid: str):
    """Transform a single point between CRS. Returns (x, y)."""
    src = QgsCoordinateReferenceSystem(src_authid)
    dst = QgsCoordinateReferenceSystem(dst_authid)
    xform = QgsCoordinateTransform(src, dst, QgsProject.instance())
    pt = xform.transform(x, y)
    return pt.x(), pt.y()
