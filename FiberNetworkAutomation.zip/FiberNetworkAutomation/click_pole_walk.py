# -*- coding: utf-8 -*-
# claude:intent READ (compute) - Click Line v3 pole numbering walk (JJ GO 2026-10-16, plan rev 4 part A).
# claude:boq-impact none - this module only reads layers and computes; it never writes a layer.
"""Number every pole in walk order, the way a HeroTel network is followed on the ground.

JJ (2026-10-16): "You follow it from the beginning, from your 1-to-16 splitter ... like a ladder ... when it
breaks off, you follow where it breaks off, and then you continue onto your main line." "Main route, your
longest route; spur cables are little cables that break off your main cables."

Rules (plan rev 4, A):
  * Two graphs. Feeder graph = Feeder + Link cables (puts the networks in order). One distribution graph per
    network = Distribution cables only. Main and spurs are worked out inside a network, never across.
  * A pole is ON a cable when within `same_pole_m` (1.0 m) of a vertex. Poles next to each other along a cable
    are joined. A cable END with no pole joins the nearest pole within `join_m` (3 m). True WGS84 metres.
  * Start: the feeder pole nearest the POP (refused with no POP / none within `pop_m`, 80 m).
  * Main = longest route (shortest-path distances from the start); ties within `eq_m` (0.01 m): farther by
    straight line, then smaller easting, then smaller northing. Spans that close a loop are listed, not walked.
  * Ladder: along the main pole by pole; at a pole where branches leave, each branch is walked first (its own
    main = its longest route, same rules inside), then the main carries on.
  * Right first: smaller clockwise turn from the direction of travel, measured along the cable over the last
    `dir_m` (10 m). At the start pole the reference is the direction towards the next main pole.
  * A feeder-graph pole within `splitter_m` (3 m) of an FTS splitter hands over to that splitter's network,
    which is numbered completely before the feeder walk carries on.
  * Distribution / Spur: a feature is the main word when MORE than half its length is on its network's main.
    Features within `near_half` of 50/50 are listed.
  * Leftovers: networks not reached from the POP, nearest first (each from its splitter, else its end nearest
    the last numbered pole); then poles on no cable, nearest first.
Pure computation on a snapshot of the layers: deterministic whatever the feature / pole storage order.
"""
import heapq
import math
import re
from collections import Counter, defaultdict

from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsDistanceArea, QgsFeature,
                       QgsGeometry, QgsPointXY, QgsProject, QgsRectangle, QgsSpatialIndex)

DEFAULTS = {
    "same_pole_m": 1.0,     # a vertex within this of a pole is ON that pole
    "join_m": 3.0,          # a cable end with no pole joins the nearest pole within this
    "pop_m": 80.0,          # the first feeder pole must be within this of the POP
    "splitter_m": 3.0,      # a pole within this of an FTS splitter belongs to that splitter
    "dir_m": 10.0,          # direction of travel measured along the cable over this distance
    "eq_m": 0.01,           # two lengths within this count as equal
    "near_half": 0.1,       # a feature with main share within 0.5 +/- this is listed
    "words": ("Distribution", "Spur"),
}
_M_PER_DEG = 111320.0


class _Geo:
    """WGS84 points, true metres, and a cheap local-metre approximation for directions / nearest-first."""

    def __init__(self, project=None):
        self.p = project or QgsProject.instance()
        self.wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        self.da = QgsDistanceArea()
        self.da.setSourceCrs(self.wgs, self.p.transformContext())
        self.da.setEllipsoid("WGS84")
        self._xf = {}
        self.coslat = None

    def xf(self, lyr):
        key = lyr.crs().authid() or lyr.crs().toWkt()
        x = self._xf.get(key)
        if x is None:
            x = self._xf[key] = QgsCoordinateTransform(lyr.crs(), self.wgs, self.p)
        return x

    def to_wgs(self, lyr, pt):
        return QgsPointXY(self.xf(lyr).transform(QgsPointXY(pt)))

    def m(self, a, b):
        return self.da.measureLine(a, b)

    def set_lat(self, lat):
        self.coslat = max(0.05, math.cos(math.radians(lat)))

    def flat(self, a, b):
        """Approximate metres (equirectangular): for nearest-first choices, never for a threshold or a length."""
        dx = (b.x() - a.x()) * _M_PER_DEG * self.coslat
        dy = (b.y() - a.y()) * _M_PER_DEG
        return math.hypot(dx, dy)

    def bearing(self, a, b):
        dx = (b.x() - a.x()) * self.coslat
        dy = b.y() - a.y()
        return math.degrees(math.atan2(dx, dy)) % 360.0


def _parts(g):
    if g is None or g.isEmpty():
        return []
    try:
        lines = g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]
    except Exception:
        c = g.constGet().segmentize() if hasattr(g.constGet(), "segmentize") else None
        lines = QgsGeometry(c).asMultiPolyline() if c is not None else []
    return [list(p) for p in lines if len(p) >= 2]


def _point(g):
    if g is None or g.isEmpty():
        return None
    try:
        return g.asPoint() if not g.isMultipart() else g.asMultiPoint()[0]
    except Exception:
        c = g.centroid()
        return c.asPoint() if c is not None and not c.isEmpty() else None


class _Graph:
    def __init__(self):
        self.adj = defaultdict(list)     # pole -> [(other pole, edge id)]

    def add(self, a, b, eid):
        self.adj[a].append((b, eid))
        self.adj[b].append((a, eid))


def compute(poles, feeder=None, link=None, dist=None, splitters=None, pop=None, project=None, **opts):
    """Snapshot the layers and walk. Returns a dict:
    order [pole fid], dist_type {dist fid: word}, refused (str or None), walked_from_pop, listed {...}."""
    o = dict(DEFAULTS)
    o.update(opts)
    geo = _Geo(project)
    eq = o["eq_m"]
    listed = {"loop_spans": [], "near_half": [], "offcable_splitters": [], "extra_splitters": [],
              "shared_networks": [], "islands": [], "loose_poles": [], "unjoined_dist": []}
    out = {"order": [], "dist_type": {}, "dist_order": [], "refused": None, "walked_from_pop": 0, "listed": listed}

    # ---- poles ----
    P = {}
    for f in poles.getFeatures():
        pt = _point(f.geometry())
        if pt is not None:
            P[f.id()] = geo.to_wgs(poles, pt)
    if not P:
        out["refused"] = "No poles on the pole layer."
        return out
    geo.set_lat(sum(p.y() for p in P.values()) / len(P))
    pidx = QgsSpatialIndex()
    for fid, pt in P.items():
        q = QgsFeature(fid)
        q.setGeometry(QgsGeometry.fromPointXY(pt))
        pidx.addFeature(q)
    dlat = 1.0 / _M_PER_DEG
    dlon = 1.0 / (_M_PER_DEG * geo.coslat)

    def pole_near(pt, tol):
        r = QgsRectangle(pt.x() - tol * dlon * 1.5, pt.y() - tol * dlat * 1.5,
                         pt.x() + tol * dlon * 1.5, pt.y() + tol * dlat * 1.5)
        best = None
        for fid in pidx.intersects(r):
            d = geo.m(pt, P[fid])
            if d <= tol:
                k = (d, P[fid].x(), P[fid].y(), fid)
                if best is None or k < best:
                    best = k
        return best[3] if best else None

    def key_xy(fid):
        return (P[fid].x(), P[fid].y(), fid)

    # ---- cables -> edges ----
    edges = []          # dict(a, b, len, kind, fid, pts[a->b])
    feat_edges = defaultdict(list)          # dist fid -> [edge id]
    dist_fids = []
    for kind, lyr in (("feeder", feeder), ("link", link), ("dist", dist)):
        if lyr is None:
            continue
        for f in lyr.getFeatures():
            if kind == "dist":
                dist_fids.append(f.id())
            for part in _parts(f.geometry()):
                line = [geo.to_wgs(lyr, v) for v in part]
                cum = [0.0]
                for a, b in zip(line, line[1:]):
                    cum.append(cum[-1] + geo.m(a, b))
                seq = []                   # (chainage, pole, vertex index)
                for i, v in enumerate(line):
                    pf = pole_near(v, o["same_pole_m"])
                    if pf is not None and (not seq or seq[-1][1] != pf):
                        seq.append((cum[i], pf, i))
                if not seq or seq[0][2] != 0:
                    pf = pole_near(line[0], o["join_m"])
                    if pf is not None and all(pf != s[1] for s in seq):
                        seq.insert(0, (0.0, pf, 0))
                last = len(line) - 1
                if not seq or seq[-1][2] != last:
                    pf = pole_near(line[-1], o["join_m"])
                    if pf is not None and all(pf != s[1] for s in seq):
                        seq.append((cum[-1], pf, last))
                for (ca, pa, ia), (cb, pb, ib) in zip(seq, seq[1:]):
                    if pa == pb:
                        continue
                    pts = line[ia:ib + 1]
                    eid = len(edges)
                    edges.append({"a": pa, "b": pb, "len": max(0.0, cb - ca), "kind": kind, "fid": f.id(),
                                  "pts": pts})
                    if kind == "dist":
                        feat_edges[f.id()].append(eid)

    gF, gD = _Graph(), _Graph()
    for eid, e in enumerate(edges):
        (gD if e["kind"] == "dist" else gF).add(e["a"], e["b"], eid)
    for g in (gF, gD):                     # storage-order independent neighbour order
        for k in g.adj:
            g.adj[k].sort(key=lambda t: (key_xy(t[0]), edges[t[1]]["len"], edges[t[1]]["fid"]))
    feeder_poles = {p for e in edges if e["kind"] == "feeder" for p in (e["a"], e["b"])}

    def components(g):
        comp = {}
        n = 0
        for s in sorted(g.adj, key=key_xy):
            if s in comp:
                continue
            stack = [s]
            comp[s] = n
            while stack:
                u = stack.pop()
                for v, _e in g.adj[u]:
                    if v not in comp:
                        comp[v] = n
                        stack.append(v)
            n += 1
        return comp, n

    compD, nD = components(gD)
    compF, nF = components(gF)

    # ---- splitters ----
    spl_pts = []
    if splitters is not None:
        for f in splitters.getFeatures():
            pt = _point(f.geometry())
            if pt is not None:
                spl_pts.append((f.id(), geo.to_wgs(splitters, pt)))
    spl_pts.sort(key=lambda t: (t[1].x(), t[1].y(), t[0]))
    spl_start = {}                         # splitter fid -> distribution start pole
    comp_spl = defaultdict(list)           # dist component -> [splitter fid]
    handover = defaultdict(list)           # feeder-graph pole -> [splitter fid]
    for sfid, spt in spl_pts:
        r = QgsRectangle(spt.x() - o["splitter_m"] * dlon * 1.5, spt.y() - o["splitter_m"] * dlat * 1.5,
                         spt.x() + o["splitter_m"] * dlon * 1.5, spt.y() + o["splitter_m"] * dlat * 1.5)
        near = sorted(((geo.m(spt, P[f]), key_xy(f), f) for f in pidx.intersects(r)), key=lambda t: (t[0], t[1]))
        near = [t for t in near if t[0] <= o["splitter_m"]]
        dpole = next((f for _d, _k, f in near if f in gD.adj), None)
        if dpole is None:
            listed["offcable_splitters"].append(sfid)
            continue
        spl_start[sfid] = dpole
        comp_spl[compD[dpole]].append(sfid)
        for _d, _k, f in near:
            if f in gF.adj:
                handover[f].append(sfid)
    for _c, sl in sorted(comp_spl.items()):
        if len(sl) > 1:
            listed["shared_networks"].append(list(sl))

    # ---- root ----
    pops = []
    if pop is not None:
        for f in pop.getFeatures():
            pt = _point(f.geometry())
            if pt is not None:
                pops.append(geo.to_wgs(pop, pt))
    if not pops:
        out["refused"] = "No POP point: the walk starts at the feeder pole nearest the POP."
        return out
    root = None
    for pf in feeder_poles:
        d = min(geo.m(P[pf], q) for q in pops)
        k = (d, key_xy(pf))
        if d <= o["pop_m"] and (root is None or k < root[0]):
            root = (k, pf)
    if root is None:
        out["refused"] = "No feeder pole within %.0f m of the POP." % o["pop_m"]
        return out
    root = root[1]

    # ---- the walk ----
    order, seen = [], set()
    walked_comp = set()                    # dist components already walked
    walked_fcomp = set()
    main_edges = set()                     # top-level main edges of every distribution network
    loop_seen = set()

    def emit(p):
        if p not in seen:
            seen.add(p)
            order.append(p)

    def dir_along(pts_from_v, metres):
        """Bearing from v (pts_from_v[0]) to the point `metres` along the polyline (or its end)."""
        v = pts_from_v[0]
        acc = 0.0
        tgt = pts_from_v[-1]
        for a, b in zip(pts_from_v, pts_from_v[1:]):
            seg = geo.flat(a, b)
            if acc + seg >= metres and seg > 0:
                t = (metres - acc) / seg
                tgt = QgsPointXY(a.x() + (b.x() - a.x()) * t, a.y() + (b.y() - a.y()) * t)
                break
            acc += seg
        if geo.flat(v, tgt) < 1e-6:
            tgt = pts_from_v[-1]
        return geo.bearing(v, tgt)

    def edge_pts_from(eid, v):
        e = edges[eid]
        return e["pts"] if e["a"] == v else e["pts"][::-1]

    def walk_graph(g, start, is_dist):
        # shortest-path tree from start (deterministic)
        dist_ = {start: 0.0}
        par, pedge = {start: None}, {start: None}
        done = set()
        heap = [(0.0, key_xy(start), start)]
        while heap:
            d, _k, u = heapq.heappop(heap)
            if u in done:
                continue
            done.add(u)
            for v, eid in g.adj[u]:
                nd = d + edges[eid]["len"]
                cur = dist_.get(v)
                if cur is None or nd < cur - eq:
                    dist_[v], par[v], pedge[v] = nd, u, eid
                    heapq.heappush(heap, (nd, key_xy(v), v))
                elif v not in done and abs(nd - cur) <= eq and key_xy(u) < key_xy(par[v]):
                    par[v], pedge[v] = u, eid
        children = defaultdict(list)
        for v, u in par.items():
            if u is not None:
                children[u].append(v)
        tree_edges = {pedge[v] for v in par if pedge[v] is not None}
        for u in par:
            for _v, eid in g.adj[u]:
                if eid not in tree_edges and eid not in loop_seen:
                    loop_seen.add(eid)
                    listed["loop_spans"].append((edges[eid]["a"], edges[eid]["b"]))

        def better(a, b, entry):
            """True when pole a beats b as the far end of the main from `entry`."""
            if dist_[a] > dist_[b] + eq:
                return True
            if dist_[b] > dist_[a] + eq:
                return False
            sa, sb = geo.m(P[entry], P[a]), geo.m(P[entry], P[b])
            if sa > sb + eq:
                return True
            if sb > sa + eq:
                return False
            return key_xy(a) < key_xy(b)

        def main_path(entry):
            best = entry
            stack = [entry]
            while stack:
                u = stack.pop()
                if better(u, best, entry):
                    best = u
                stack.extend(children[u])
            path = [best]
            while path[-1] != entry:
                path.append(par[path[-1]])
            return path[::-1]

        top = True
        tasks = [("sub", start, None)]
        while tasks:
            kind, node, ref = tasks.pop()
            if kind == "emit":
                emit(node)
                if not is_dist:
                    for sfid in handover.get(node, []):
                        c = compD.get(spl_start[sfid])
                        if c is not None and c not in walked_comp:
                            walked_comp.add(c)
                            walk_graph(gD, spl_start[sfid], True)
                continue
            path = main_path(node)
            if is_dist and top:
                for v in path[1:]:
                    main_edges.add(pedge[v])
            top = False
            plan = []
            for i, p in enumerate(path):
                plan.append(("emit", p, None))
                nxt = path[i + 1] if i + 1 < len(path) else None
                if i > 0:
                    rdir = (dir_along(edge_pts_from(pedge[p], p), o["dir_m"]) + 180.0) % 360.0
                elif ref is not None:
                    rdir = ref
                elif nxt is not None:
                    rdir = dir_along(edge_pts_from(pedge[nxt], p), o["dir_m"])
                else:
                    rdir = 0.0
                br = []
                for c in children[p]:
                    if c == nxt:
                        continue
                    out_dir = dir_along(edge_pts_from(pedge[c], p), o["dir_m"])
                    turn = (out_dir - rdir) % 360.0
                    in_dir_c = (dir_along(edge_pts_from(pedge[c], c), o["dir_m"]) + 180.0) % 360.0
                    br.append((turn, key_xy(c), c, in_dir_c))
                br.sort(key=lambda t: (t[0], t[1]))
                for _t, _k, c, in_dir_c in br:
                    plan.append(("sub", c, in_dir_c))
            tasks.extend(reversed(plan))
        return dist_

    walked_fcomp.add(compF[root])
    walk_graph(gF, root, False)
    out["walked_from_pop"] = len(order)

    # ---- leftovers: unreached networks, nearest first ----
    def comp_nodes(comp, n):
        groups = defaultdict(list)
        for p, c in comp.items():
            groups[c].append(p)
        return groups

    groupsD = comp_nodes(compD, nD)
    groupsF = comp_nodes(compF, nF)
    pending = []                            # ("d"|"f", component)
    for c in range(nD):
        if c not in walked_comp:
            pending.append(("d", c))
    for c in range(nF):
        if c not in walked_fcomp:
            pending.append(("f", c))
    while pending:
        last = P[order[-1]] if order else pops[0]
        best = None
        for item in pending:
            nodes = groupsD[item[1]] if item[0] == "d" else groupsF[item[1]]
            live = [p for p in nodes if p not in seen] or nodes
            d = min(geo.flat(last, P[p]) for p in live)
            k = (d, min(key_xy(p) for p in nodes))
            if best is None or k < best[0]:
                best = (k, item)
        item = best[1]
        pending.remove(item)
        kind_, c = item
        nodes = groupsD[c] if kind_ == "d" else groupsF[c]
        g = gD if kind_ == "d" else gF
        if all(p in seen for p in nodes):
            continue                         # numbered already through the other graph
        listed["islands"].append(sorted(nodes, key=key_xy))
        start = None
        if kind_ == "d" and comp_spl.get(c):
            start = min((spl_start[s] for s in comp_spl[c]), key=lambda p: (geo.flat(last, P[p]), key_xy(p)))
        if start is None:
            ends = [p for p in nodes if len({v for v, _e in g.adj[p]}) <= 1] or nodes
            start = min(ends, key=lambda p: (geo.flat(last, P[p]), key_xy(p)))
        if kind_ == "d":
            walked_comp.add(c)
        else:
            walked_fcomp.add(c)
        walk_graph(g, start, kind_ == "d")
    # poles on no cable, nearest first
    rest = [p for p in P if p not in seen]
    listed["loose_poles"] = []
    while rest:
        last = P[order[-1]] if order else pops[0]
        nxt = min(rest, key=lambda p: (geo.flat(last, P[p]), key_xy(p)))
        emit(nxt)
        listed["loose_poles"].append(nxt)
        rest.remove(nxt)
    # extra splitters: every splitter of a network except the one it was started from
    pos = {p: i for i, p in enumerate(order)}
    for sl in comp_spl.values():
        if any(spl_start[s] in pos for s in sl):
            first = min(sl, key=lambda s: pos.get(spl_start[s], len(pos)))
            listed["extra_splitters"].extend(s for s in sl if s != first)

    # ---- Distribution / Spur per feature ----
    w_main, w_spur = o["words"]
    for fid in dist_fids:
        eids = feat_edges.get(fid, [])
        tot = sum(edges[e]["len"] for e in eids)
        if tot <= 0:
            listed["unjoined_dist"].append(fid)
            continue
        on = sum(edges[e]["len"] for e in eids if e in main_edges)
        frac = on / tot
        out["dist_type"][fid] = w_main if frac > 0.5 else w_spur
        if abs(frac - 0.5) <= o["near_half"]:
            listed["near_half"].append(fid)
    listed["near_half"].sort()
    # ---- distribution cables in walk order (S2b names): by the walk positions of the poles each one touches ----
    dkey = {}
    for fid in dist_fids:
        ps = {p for e in feat_edges.get(fid, []) for p in (edges[e]["a"], edges[e]["b"])}
        if ps:
            first = edges[feat_edges[fid][0]]["pts"][0]
            dkey[fid] = (tuple(sorted(pos[p] for p in ps)), first.x(), first.y())
    out["dist_order"] = sorted(dkey, key=lambda f: dkey[f])
    out["order"] = order
    return out


_NAME_RX = re.compile(r"^(.*?)(\d+)([A-Za-z]*)$")


def name_pattern(names):
    """(prefix, digits width, suffix) of the commonest pole-name pattern, e.g. ("HT_VRE_", 4, "PL"); None when
    no existing name has a number in it (the tool then asks)."""
    c = Counter()
    for n in names:
        if not n or not isinstance(n, str):
            continue
        m = _NAME_RX.match(n.strip())
        if m:
            c[(m.group(1), len(m.group(2)), m.group(3))] += 1
    if not c:
        return None
    best = max(c.items(), key=lambda kv: (kv[1], kv[0][1], kv[0][0], kv[0][2]))
    return best[0]


def parse_pattern(text):
    """'HT_VRE_####PL' -> ("HT_VRE_", 4, "PL"); None when there is no run of '#'."""
    m = re.match(r"^(.*?)(#+)([^#]*)$", (text or "").strip())
    return (m.group(1), len(m.group(2)), m.group(3)) if m else None


def pattern_text(pattern):
    return "" if not pattern else "%s%s%s" % (pattern[0], "#" * pattern[1], pattern[2])


def names(order, pattern):
    """{pole fid: (Name, Pole ID)} numbered 1.. in walk order, no gaps: HT_VRE_0001PL / 0001PL."""
    prefix, width, suffix = pattern
    out = {}
    for i, pf in enumerate(order, 1):
        pid = "%0*d%s" % (width, i, suffix)
        out[pf] = (prefix + pid, pid)
    return out


_AOI_RX = re.compile(r"^HT_[A-Za-z0-9]+_$")
_SIZE_RX = re.compile(r"^\s*(\d+)\s*[Ff]\s*$")


def cable_size(v):
    """'24F' / '24 f' -> '24F'; None for anything else (empty, '24', '24 core'): a size is read, never guessed."""
    m = _SIZE_RX.match(v) if isinstance(v, str) else None
    return "%sF" % int(m.group(1)) if m else None


def cable_names(dist_order, sizes, pattern):
    """S2b, HeroTel labelling standard p.3: HT_<AOI>_DC<nn>_<size>_Aerial. Spurs are DC too (no spur code in the
    spec). Numbered 1.. town-wide in walk order over the cables that HAVE a size, no gaps; at least 2 digits, more
    when there are more than 99. Returns ({dist fid: (Name, Cable No)}, [fid with no size], why-off or '')."""
    prefix = pattern[0] if pattern else ""
    if not _AOI_RX.match(prefix):
        return {}, [], "pole names do not start HT_<AOI>_ (%s), so the cable prefix is unknown" % (prefix or "none")
    named = [f for f in dist_order if sizes.get(f)]
    no_size = [f for f in dist_order if not sizes.get(f)]
    width = max(2, len(str(len(named))))
    out = {}
    for i, fid in enumerate(named, 1):
        no = "DC%0*d" % (width, i)
        out[fid] = ("%s%s_%s_Aerial" % (prefix, no, sizes[fid]), no)
    return out, no_size, ""


# ════════════════════════════════════════════════════════════════════════════════════════════════════════════
# Apply side (plan rev 4, A "Where and how it writes"): find layers, refuse, fingerprint, name scan, backup,
# apply into the edit buffer (one undo command per layer), revert by position with compare-and-swap.
# claude:intent MUTATE - user asked (JJ GO 2026-10-16 on Click Line v3 plan rev 4, "Reply GO to build A + B + C"):
#   "Preview before writing; one Ctrl+Z undoes it." Plan: apply()/revert() write pole Name / Pole ID and the
#   Distribution Type + Name / Cable No (S2b, JJ GO 2026-10-16 "cable NAMES in scope") ONLY into the QGIS edit
#   buffer (never the provider, never saved), after refuse_reason, a
#   stale check, a typed project-name confirm and a backup that is reopened and compared row by row. The
#   dataProvider().addFeatures() below fills a throw-away in-memory layer that stages that backup.
# claude:approved-destructive - see above: edit buffer only, backed up and read back first.
# ════════════════════════════════════════════════════════════════════════════════════════════════════════════
import hashlib
import json
import os
from datetime import datetime

DELIVERED_HINTS = ("mohadin", "chloorkop", "malmesbury", "malmsbury", "middelburg", "botchabelo", "botshabelo",
                   "barberton")          # issued / delivered towns: never renumbered
_MOA_RX = re.compile(r"(^|[^a-z])moa([^a-z]|$)")
SCOPE = "VelocityClickLine"
REVERT_KEY = "walk_revert"
BACKUP_DIR = "_clickline_backup"
_PATH_BUDGET = 245
POLE_FIELDS = ("Name", "Pole ID")
SIZE_FIELD = "Cable Size"


def _cable_ix(dist):
    """[Name index, Cable No index] on the Distribution layer (-1 when absent; 'Cable_No' or 'Cable No')."""
    fl = dist.fields()
    cno = fl.indexOf("Cable_No")
    return [fl.indexOf("Name"), cno if cno >= 0 else fl.indexOf("Cable No")]


def _lname(lyr):
    return (lyr.name() or "").strip().lower()


def find_layers(project):
    """{"poles","feeder","link","dist","splitters","pop": layer or None}, plus "why" when one is ambiguous."""
    try:
        from . import click_pole as cp
    except ImportError:  # pragma: no cover - plain-module tests
        import click_pole as cp
    out = {"poles": cp.poles_layer(project), "why": ""}
    vec = [lyr for lyr in project.mapLayers().values() if hasattr(lyr, "geometryType") and lyr.isValid()]

    def pick(key, geom_line, test, exact):
        hits = [lyr for lyr in vec if (lyr.geometryType() == (1 if geom_line else 0)) and test(_lname(lyr))]
        ex = [lyr for lyr in hits if _lname(lyr) == exact]
        if len(ex) == 1:
            out[key] = ex[0]
        elif len(hits) == 1:
            out[key] = hits[0]
        else:
            out[key] = None
            if len(hits) > 1:
                out["why"] += "%d layers could be the %s layer. " % (len(hits), exact)
    pick("feeder", True, lambda n: "feeder" in n, "feeder cable")
    pick("link", True, lambda n: "link" in n, "link cable")
    pick("dist", True, lambda n: "distribution" in n, "distribution cable")
    pick("splitters", False, lambda n: "fts" in n, "fts splitter")
    pick("pop", False, lambda n: n == "pop" or n.startswith("pop "), "pop")
    return out


def _valuemap_values(lyr, idx):
    try:
        setup = lyr.editorWidgetSetup(idx)
        if setup.type() != "ValueMap":
            return None
        m = setup.config().get("map")
    except Exception:
        return None
    vals = set()
    if isinstance(m, dict):
        vals.update(str(v) for v in m.values())
    elif isinstance(m, (list, tuple)):
        for d in m:
            if isinstance(d, dict):
                vals.update(str(v) for v in d.values())
    return vals


def refuse_reason(project, L, words=DEFAULTS["words"], pattern=None, plan=None):
    """Why numbering must not be written on this project, or ''. With a plan, also the cable Name / Cable No
    field widths against the longest cable name it would write."""
    try:
        from . import click_pole as cp
    except ImportError:  # pragma: no cover
        import click_pole as cp
    poles, dist = L.get("poles"), L.get("dist")
    if poles is None:
        return "no Poles layer (pick it in the click-line settings)"
    if dist is None:
        return "no Distribution Cable layer"
    why = cp.frozen_reason(project, [poles, dist])
    if why:
        return why
    low = ((project.fileName() or "") + " | " + (project.baseName() or "")).replace("\\", "/").lower()
    for h in DELIVERED_HINTS:
        if h in low:
            return "this project is a delivered / issued town (%s): numbering is never rewritten there" % h
    if _MOA_RX.search(low):
        return "this project is MOA (delivered): numbering is never rewritten there"
    for lyr in (poles, dist):
        src = (lyr.source() or "").replace("\\", "/").lower()
        if any(h in src for h in DELIVERED_HINTS) or _MOA_RX.search(src):
            return "'%s' belongs to a delivered town's data" % lyr.name()
    if poles.fields().indexOf("Name") < 0:
        return "the Poles layer has no 'Name' field"
    idx = dist.fields().indexOf("Type")
    if idx < 0:
        return "the Distribution Cable layer has no 'Type' field"
    vals = _valuemap_values(dist, idx)
    if vals is not None and not all(w in vals for w in words):
        return "the 'Type' value list on %s does not allow %s" % (dist.name(), " / ".join(words))
    width = dist.fields()[idx].length()
    if width and width < max(len(w) for w in words):
        return "the 'Type' field on %s is only %d characters wide" % (dist.name(), width)
    if pattern is not None:
        longest = len(names([0], pattern)[0][0]) + 1
        for f in POLE_FIELDS:
            i = poles.fields().indexOf(f)
            if i >= 0 and 0 < poles.fields()[i].length() < longest:
                return "the '%s' field on %s is only %d characters wide" % (f, poles.name(), poles.fields()[i].length())
    rows = [r["new"] for r in ((plan or {}).get("dist_names") or {}).values()]
    for k, i in enumerate(_cable_ix(dist)):
        if i < 0 or not rows:
            continue
        longest = max(len(r[k] or "") for r in rows)
        if 0 < dist.fields()[i].length() < longest:
            return "the '%s' field on %s is only %d characters wide (cable names need %d)" % (
                dist.fields()[i].name(), dist.name(), dist.fields()[i].length(), longest)
    return ""


def _val(v):
    """None for every flavour of NULL (QGIS 3.x hands back a QVariant NULL, 4.x None) so values compare and
    serialise the same on every version."""
    try:
        if v is None or (hasattr(v, "isNull") and not isinstance(v, str) and v.isNull()):
            return None
    except Exception:
        pass
    return v


def _wkb(g):
    try:
        return bytes(g.asWkb()) if g is not None and not g.isEmpty() else b""
    except Exception:
        return b""


def fingerprint(L):
    """One hash over every input the walk reads (geometries + pole names + dist Type), edit buffer included.
    Apply refuses when it differs from the preview's."""
    h = hashlib.sha1()
    for key in ("poles", "feeder", "link", "dist", "splitters", "pop"):
        lyr = L.get(key)
        h.update(key.encode())
        if lyr is None:
            continue
        h.update((lyr.id() + lyr.crs().authid()).encode())
        rows = []
        for f in lyr.getFeatures():
            extra = ""
            if key == "poles":
                extra = "|".join(str(f[n]) for n in POLE_FIELDS if lyr.fields().indexOf(n) >= 0)
            elif key == "dist":
                extra = "|".join(str(_val(f[i])) for i in [lyr.fields().indexOf("Type"),
                                                            lyr.fields().indexOf(SIZE_FIELD)] + _cable_ix(lyr)
                                 if i >= 0)
            rows.append(hashlib.sha1(_wkb(f.geometry()) + extra.encode("utf-8", "replace")).hexdigest() + str(f.id()))
        for r in sorted(rows):
            h.update(r.encode())
    return h.hexdigest()


def _pos_key(lyr, geom):
    """A position key that survives save / close / reopen (fids do not): rounded coordinates."""
    nd = 9 if lyr.crs().isGeographic() else 4
    try:
        pts = [(round(v.x(), nd), round(v.y(), nd)) for v in geom.vertices()]
    except Exception:
        return ""
    return hashlib.sha1(repr(pts).encode()).hexdigest()


def make_plan(L, pattern=None, project=None, **opts):
    """compute() + the exact values Apply would write. pattern None -> from existing pole names (None if none:
    the caller must ask for one)."""
    poles, dist = L["poles"], L["dist"]
    res = compute(poles, feeder=L.get("feeder"), link=L.get("link"), dist=dist, splitters=L.get("splitters"),
                  pop=L.get("pop"), project=project, **opts)
    old = {f.id(): f for f in poles.getFeatures()}
    if pattern is None:
        pattern = name_pattern([f["Name"] for f in old.values()])
    plan = {"res": res, "pattern": pattern, "fingerprint": fingerprint(L), "poles": {}, "dist": {},
            "n_renamed": 0, "n_typed": 0, "old_names": set(), "dist_names": {}, "n_named": 0, "no_size": [],
            "names_off": "", "old_cable_names": set(), "dist_id": dist.id()}
    if res["refused"] or pattern is None:
        return plan
    has_pid = poles.fields().indexOf("Pole ID") >= 0
    for fid, (nm, pid) in names(res["order"], pattern).items():
        f = old[fid]
        o_nm = _val(f["Name"])
        o_pid = _val(f["Pole ID"]) if has_pid else None
        new = (nm, pid if has_pid else None)
        plan["poles"][fid] = {"old": (o_nm, o_pid), "new": new}
        if (o_nm, o_pid) != new:
            plan["n_renamed"] += 1
            if o_nm not in (None, "") and str(o_nm) != nm:
                plan["old_names"].add(str(o_nm))
    for f in dist.getFeatures():
        t = res["dist_type"].get(f.id())
        if t is None:
            continue
        plan["dist"][f.id()] = {"old": _val(f["Type"]), "new": t}
        if _val(f["Type"]) != t:
            plan["n_typed"] += 1
    # S2b cable names
    cix = _cable_ix(dist)
    si = dist.fields().indexOf(SIZE_FIELD)
    if cix[0] < 0:
        plan["names_off"] = "the Distribution Cable layer has no 'Name' field"
        return plan
    if si < 0:
        plan["names_off"] = "the Distribution Cable layer has no '%s' field" % SIZE_FIELD
        return plan
    D = {f.id(): f for f in dist.getFeatures()}
    sizes = {fid: cable_size(_val(D[fid][si])) for fid in res["dist_order"]}
    new, plan["no_size"], plan["names_off"] = cable_names(res["dist_order"], sizes, pattern)
    for fid, nm in new.items():
        f = D[fid]
        old = (_val(f[cix[0]]), _val(f[cix[1]]) if cix[1] >= 0 else None)
        nw = (nm[0], nm[1] if cix[1] >= 0 else None)
        plan["dist_names"][fid] = {"old": old, "new": nw}
        if old != nw:
            plan["n_named"] += 1
            if old[0] not in (None, "") and str(old[0]) != nw[0]:
                plan["old_cable_names"].add(str(old[0]))
    return plan


def name_scan(project, plan, skip=()):
    """[(layer name, n cells)] of OTHER layers whose text cells hold an old pole name (or an old cable name: the
    Distribution layer itself is not counted for those) Apply will change."""
    want = plan.get("old_names") or set()
    want_c = plan.get("old_cable_names") or set()
    if not want and not want_c:
        return []
    out = []
    skip_ids = {lyr.id() for lyr in skip if lyr is not None}
    for lyr in project.mapLayers().values():
        if not hasattr(lyr, "fields") or not lyr.isValid():
            continue
        w = (set() if lyr.id() in skip_ids else want) | (set() if lyr.id() == plan.get("dist_id") else want_c)
        if not w:
            continue
        idx = [i for i, f in enumerate(lyr.fields()) if "str" in f.typeName().lower() or "text" in f.typeName().lower()]
        if not idx:
            continue
        n = 0
        for f in lyr.getFeatures():
            a = f.attributes()
            for i in idx:
                v = a[i]
                if v is not None and str(v).strip() in w:
                    n += 1
        if n:
            out.append((lyr.name(), n))
    return sorted(out)


def _backup_root(project):
    path = project.fileName() or ""
    d = os.path.dirname(path)
    if not d or not os.path.isdir(d):
        return None, "the project has not been saved to disk, so there is nowhere to put the backup - save it first"
    if len(os.path.join(d, BACKUP_DIR, "20261016_000000", "Distribution_Cable.gpkg")) <= _PATH_BUDGET:
        return d, ""
    key = hashlib.sha1(path.encode("utf-8", "replace")).hexdigest()[:10]
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(base, "VelocityFibre", "spill", key), ""


def backup(project, layers, root=None):
    """Write each layer (edit buffer included) to <root>/_clickline_backup/<ts>/<name>.gpkg with a `_vf_fid`
    column, then REOPEN each file and prove every row's geometry and values match the live layer. (ok, dest|why)."""
    from qgis.core import (QgsCoordinateTransformContext, QgsField, QgsVectorFileWriter, QgsVectorLayer,
                           QgsWkbTypes)
    from qgis.PyQt.QtCore import QMetaType
    if root is None:
        root, why = _backup_root(project)
        if root is None:
            return False, why
    dest = os.path.join(root, BACKUP_DIR, datetime.now().strftime("%Y%m%d_%H%M%S"))
    n = 1
    while os.path.exists(dest):           # two applies in one second: never write into the first one's folder
        n += 1
        dest = os.path.join(root, BACKUP_DIR, datetime.now().strftime("%Y%m%d_%H%M%S") + "_%d" % n)
    try:
        os.makedirs(dest)
    except OSError as e:
        return False, "could not make the backup folder: %s" % e
    manifest = {}
    for lyr in layers:
        stem = "".join(c if c.isalnum() else "_" for c in lyr.name()) or "layer"
        path = os.path.join(dest, stem + ".gpkg")
        gt = QgsWkbTypes.displayString(lyr.wkbType())
        mem = QgsVectorLayer("%s?crs=%s" % (gt, lyr.crs().authid() or lyr.crs().toWkt()), stem, "memory")
        mem.dataProvider().addAttributes(list(lyr.fields()) + [QgsField("_vf_fid", QMetaType.Type.LongLong)])
        mem.updateFields()
        live = {}
        feats = []
        for f in lyr.getFeatures():
            nf = QgsFeature(mem.fields())
            nf.setAttributes(list(f.attributes()) + [int(f.id())])
            nf.setGeometry(f.geometry())
            feats.append(nf)
            # _val: after a Revert, QGIS 3.x holds a restored NULL as None ("None") but reads one back as NULL
            live[int(f.id())] = (_wkb(f.geometry()), tuple(str(_val(v)) for v in f.attributes()))
        if feats and not mem.dataProvider().addFeatures(feats):
            return False, "could not stage the backup of %s" % lyr.name()
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = "GPKG"
        opts.layerName = stem
        res = QgsVectorFileWriter.writeAsVectorFormatV3(mem, path, QgsCoordinateTransformContext(), opts)
        if int(res[0]) != 0:
            return False, "backing up %s failed: %s" % (lyr.name(), res[1] if len(res) > 1 else res[0])
        chk = QgsVectorLayer("%s|layername=%s" % (path, stem), "_chk", "ogr")
        if not chk.isValid():
            return False, "the backup of %s was written but cannot be reopened (path %d chars)" % (lyr.name(),
                                                                                                    len(path))
        back = {}
        ni = chk.fields().indexOf("_vf_fid")
        src_names = [f.name() for f in lyr.fields()]
        for f in chk.getFeatures():
            vals = tuple(str(_val(f[nm])) for nm in src_names)
            back[int(f.attributes()[ni])] = (_wkb(f.geometry()), vals)
        if back != live:
            bad = sum(1 for k in set(back) | set(live) if back.get(k) != live.get(k))
            return False, "the backup of %s reopened with %d row(s) different from the layer" % (lyr.name(), bad)
        manifest[stem] = {"layer": lyr.name(), "rows": len(live)}
    with open(os.path.join(dest, "manifest.json"), "w", encoding="utf-8") as fh:
        json.dump({"project": project.fileName(), "when": os.path.basename(dest), "layers": manifest}, fh, indent=1)
    return True, dest


def _write(lyr, changes, label):
    """changes {fid: {field index: value}} into the edit buffer as ONE undo command. (ok, why)."""
    if not changes:
        return True, ""
    if not lyr.isEditable() and not lyr.startEditing():
        return False, "%s cannot be put into editing" % lyr.name()
    lyr.beginEditCommand(label)
    try:
        for fid, vals in changes.items():
            if not lyr.changeAttributeValues(fid, vals):
                raise RuntimeError("feature %s refused the change" % fid)
    except Exception as e:
        lyr.destroyEditCommand()
        return False, "%s: %s" % (lyr.name(), e)
    lyr.endEditCommand()
    return True, ""


def apply(project, L, plan, typed_name, refs_ok=False, backup_root=None):
    """Write the preview. Refuses (nothing written) when: refuse_reason, the preview is stale, the typed project
    name is wrong, other layers hold old names and refs_ok is False, or the backup fails / does not read back.
    Pole names = one undo command on Poles; Type + cable Name / Cable No = one on Distribution Cable.
    Returns (ok, message, info)."""
    why = refuse_reason(project, L, DEFAULTS["words"], plan.get("pattern"), plan)
    if why:
        return False, "Refused: " + why, {}
    if plan["res"].get("refused") or plan.get("pattern") is None:
        return False, "Refused: nothing to apply (%s)" % (plan["res"].get("refused") or "no name pattern"), {}
    if fingerprint(L) != plan["fingerprint"]:
        return False, "Refused: something changed since the preview. Preview again.", {}
    if (typed_name or "").strip() != (project.baseName() or "").strip():
        return False, "Refused: type the project's name (%s) to confirm." % project.baseName(), {}
    refs = name_scan(project, plan, skip=[L["poles"]])
    if refs and not refs_ok:
        return False, "Refused: %d other layer(s) hold old pole / cable names: %s" % (
            len(refs), ", ".join("%s (%d)" % r for r in refs)), {"refs": refs}
    ok, dest = backup(project, [L["poles"], L["dist"]], backup_root)
    if not ok:
        return False, "Refused: backup failed - %s" % dest, {}
    poles, dist = L["poles"], L["dist"]
    ix = [poles.fields().indexOf(nm) for nm in POLE_FIELDS]
    pch = {}
    rec = {"project": project.fileName(), "backup": dest, "poles": {}, "dist": {}, "dist_names": {}}
    by_fid = {f.id(): f for f in poles.getFeatures()}
    for fid, row in plan["poles"].items():
        if row["old"] == row["new"]:
            continue
        pch[fid] = {ix[k]: row["new"][k] for k in range(2) if ix[k] >= 0}
        key = _pos_key(poles, by_fid[fid].geometry())
        rec["poles"].setdefault(key, []).append({"old": list(row["old"]), "new": list(row["new"])})
    ti = dist.fields().indexOf("Type")
    dch = {}
    dby = {f.id(): f for f in dist.getFeatures()}
    for fid, row in plan["dist"].items():
        if row["old"] == row["new"]:
            continue
        dch[fid] = {ti: row["new"]}
        key = _pos_key(dist, dby[fid].geometry())
        rec["dist"].setdefault(key, []).append({"old": row["old"], "new": row["new"]})
    n_typed = len(dch)
    cix = _cable_ix(dist)
    n_named = 0
    for fid, row in plan.get("dist_names", {}).items():
        if row["old"] == row["new"]:
            continue
        dch.setdefault(fid, {}).update({cix[k]: row["new"][k] for k in range(2) if cix[k] >= 0})
        n_named += 1
        key = _pos_key(dist, dby[fid].geometry())
        rec["dist_names"].setdefault(key, []).append({"old": list(row["old"]), "new": list(row["new"])})
    ok, why = _write(poles, pch, "Number poles (click line walk)")
    if not ok:
        return False, "Nothing written: " + why, {}
    ok, why = _write(dist, dch, "Distribution / Spur + cable names (click line walk)")
    if not ok:
        if pch:
            poles.undoStack().undo()       # take back the pole names: all or nothing
        return False, "Nothing written: " + why, {}
    project.writeEntry(SCOPE, REVERT_KEY, json.dumps(rec))
    return True, "%d poles renamed, %d cables typed, %d cables named, project %s" % (
        len(pch), n_typed, n_named, project.baseName()), {
        "backup": dest, "refs": refs}


def revert(project, L):
    """Put back what Apply wrote, by POSITION, only where the cell still holds what Apply wrote (compare-and-
    swap). Returns (ok, message, kept) - kept lists cells changed by hand since Apply (left alone)."""
    raw, found = project.readEntry(SCOPE, REVERT_KEY, "")
    if not found or not raw:
        return False, "Nothing to revert: no numbering was applied in this project.", []
    rec = json.loads(raw)
    poles, dist = L["poles"], L["dist"]
    kept = []
    ix = [poles.fields().indexOf(nm) for nm in POLE_FIELDS]
    pch = {}
    for f in poles.getFeatures():
        rows = rec["poles"].get(_pos_key(poles, f.geometry()))
        if not rows:
            continue
        cur = [_val(f[nm]) if ix[k] >= 0 else None for k, nm in enumerate(POLE_FIELDS)]
        hit = next((r for r in rows if list(r["new"]) == cur), None)
        if hit is None:
            kept.append(("pole", f.id(), cur))
            continue
        pch[f.id()] = {ix[k]: hit["old"][k] for k in range(2) if ix[k] >= 0}
    ti = dist.fields().indexOf("Type")
    dch = {}
    for f in dist.getFeatures():
        rows = rec["dist"].get(_pos_key(dist, f.geometry()))
        if not rows:
            continue
        hit = next((r for r in rows if r["new"] == _val(f["Type"])), None)
        if hit is None:
            kept.append(("cable", f.id(), _val(f["Type"])))
            continue
        dch[f.id()] = {ti: hit["old"]}
    cix = _cable_ix(dist)
    for f in dist.getFeatures():
        rows = (rec.get("dist_names") or {}).get(_pos_key(dist, f.geometry()))
        if not rows:
            continue
        cur = [_val(f[i]) if i >= 0 else None for i in cix]
        hit = next((r for r in rows if list(r["new"]) == cur), None)
        if hit is None:
            kept.append(("cable name", f.id(), cur))
            continue
        dch.setdefault(f.id(), {}).update({cix[k]: hit["old"][k] for k in range(2) if cix[k] >= 0})
    ok, why = _write(poles, pch, "Revert pole numbers (click line walk)")
    if not ok:
        return False, "Nothing reverted: " + why, kept
    ok, why = _write(dist, dch, "Revert Distribution / Spur + cable names (click line walk)")
    if not ok:
        if pch:
            poles.undoStack().undo()
        return False, "Nothing reverted: " + why, kept
    project.removeEntry(SCOPE, REVERT_KEY)
    return True, "%d poles and %d cables put back; %d changed since Apply were left alone" % (
        len(pch), len(dch), len(kept)), kept
