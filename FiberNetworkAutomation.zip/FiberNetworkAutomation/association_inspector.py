"""Associations — does every drop run from a pole to a home? (Velocity Nexus panel)

JJ, 2026-10-14: "a section in velocity nexus that checks your snaps on drops and poles, and
also drop to demand point centroids ... within a radius of 1 meter or you can change it
... and it needs to flag where you did not snap to a layer".

Pick the drop layers, the demand layer and the layers drops end on (poles, plus anchor
layers such as splitters and joints), dial a radius (0.01 - 5 m, default 1 m) and Run.
Every drop gets one verdict (good / no pole / no home / pole at both ends / broken), every
drop end that sits on nothing gets a red ring on the canvas, and homes with no drop or
with 2+ drops are listed. The measuring lives in ``fibre_automation.association_scan``;
this module is UI only.

READ-ONLY. No code path here opens an edit session or writes a feature. The canvas marks
are QgsRubberBands (overlays, never layers); "Select failing drops" only changes the
selection and "Restore" puts the original selection back.

Threading: feature sources, coordinate transforms and the distance measurer are built on
the main thread; reading, measuring and classifying run in a QgsTask. A generation
counter discards any result that an edit, a pick change or a newer Run made stale.
Live re-check is signal-driven (edit signals arm a single-shot debounce), never a loop.
"""
import math
import time

from qgis.PyQt import sip
from qgis.PyQt.QtCore import QAbstractTableModel, QModelIndex, Qt, QTimer
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QDockWidget, QFrame, QHBoxLayout, QHeaderView,
    QLabel, QLineEdit, QMessageBox, QPushButton, QScrollArea, QSlider, QTableView,
    QVBoxLayout, QWidget)
from qgis.core import (
    QgsApplication, QgsCoordinateReferenceSystem, QgsGeometry, QgsLineString,
    QgsMultiLineString, QgsMultiPoint, QgsMultiPolygon, QgsPoint, QgsPointXY, QgsPolygon,
    QgsProject, QgsRectangle, QgsSettings, QgsTask, QgsWkbTypes)
from qgis.gui import QgsRubberBand

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

try:                                     # bundled copy inside the installed plugin
    from .fibre_automation import association_scan as scan
except ImportError:                      # workspace / dev checkout
    from fibre_automation import association_scan as scan

_SETTINGS_ROOT = "VelocityFibre/associations"
_DEBOUNCE_MS = 250
_RADIUS_DEBOUNCE_MS = 150
_RING_COLOR = QColor(255, 45, 45)
_GAP_COLOR = QColor(255, 170, 40)
_MARK_PX = 14
_RING_SIDES = 36
_PROGRESS_S = 0.25
_EDIT_SIGNALS = ("geometryChanged", "featureAdded", "featuresDeleted",
                 "afterCommitChanges", "afterRollBack")
_WGS84 = "EPSG:4326"
_LEVEL_ICON = {"FAIL": "✖", "WARN": "⚠", "INFO": "·"}
_COLUMNS = ("", "What", "Layer", "ID", "End", "Pole m", "Home m")


def _alive(obj):
    """True if a Qt object is still usable — guards the deleted-C++ crash class."""
    if obj is None:
        return False
    try:
        return not sip.isdeleted(obj)
    except Exception:
        return True


def _project_key():
    """Stable per-project settings key (falls back to the name for unsaved projects)."""
    proj = QgsProject.instance()
    return (proj.fileName() or proj.baseName() or "unsaved").replace("/", "_") \
        .replace("\\", "_").replace(":", "")


def _kind(layer):
    """"point" / "line" / "polygon" for a vector layer, else None."""
    from qgis.core import QgsVectorLayer
    if not isinstance(layer, QgsVectorLayer):
        return None
    try:
        gt = layer.geometryType()
    except Exception:
        return None
    return {QgsWkbTypes.GeometryType.PointGeometry: "point",
            QgsWkbTypes.GeometryType.LineGeometry: "line",
            QgsWkbTypes.GeometryType.PolygonGeometry: "polygon"}.get(gt)


def _role_of():
    try:
        try:
            from .network_planner import layer_names
        except ImportError:
            from FiberNetworkAutomation.network_planner import layer_names
        return layer_names.role_of
    except Exception:
        return None


def _unit_circle(sides):
    cs = [(math.cos(2 * math.pi * k / sides), math.sin(2 * math.pi * k / sides))
          for k in range(sides)]
    return cs + cs[:1]


_UNIT = {_RING_SIDES: _unit_circle(_RING_SIDES)}


def ring_polygon(lon, lat, r_m, sides=_RING_SIDES):
    """A circle of r_m metres round (lon, lat) on the WGS84 ellipsoid, as an EPSG:4326
    QgsPolygon: meridional / prime-vertical radii of curvature, so the ring is round to
    well under 1 % at any latitude a fibre project sits on. Built from two coordinate
    lists in one call (2,000 rings ~45 ms, not ~180 ms point by point)."""
    a, e2 = 6378137.0, 0.00669437999014
    phi = math.radians(lat)
    w = 1 - e2 * math.sin(phi) ** 2
    m_lat = math.pi / 180 * a * (1 - e2) / w ** 1.5      # metres per degree of latitude
    m_lon = math.pi / 180 * a * math.cos(phi) / math.sqrt(w)
    dx, dy = r_m / m_lon, r_m / m_lat
    cs = _UNIT.get(sides) or _unit_circle(sides)
    return QgsPolygon(QgsLineString([lon + dx * c for c, _s in cs],
                                    [lat + dy * s for _c, s in cs]))


def ring_geometry(lon, lat, r_m, sides=_RING_SIDES):
    """:func:`ring_polygon` as a QgsGeometry."""
    return QgsGeometry(ring_polygon(lon, lat, r_m, sides))


# ── freeing big results without freezing the canvas ──────────────────────────────────
# A replaced 63,000-drop cache is ~250,000 Python / sip objects; dropping it in one go
# holds the main thread ~280 ms. It is handed here instead and emptied a slice at a time
# (<= _DRAIN_MS per event-loop turn). Module level on purpose: it never touches the panel,
# so a panel closed mid-drain cannot be called back.
_DRAIN_MS = 8.0
_DRAIN_SLICE = 500
_DRAIN = []


def _graveyard(cache):
    """The lists of a replaced cache, emptied in place, then the shell (spatial indexes).
    Only for a cache the panel alone holds: results may be kept by a caller and are never
    emptied here, they are just let go."""
    if cache is None:
        return []
    out = [*cache.drops.columns(), *cache.spares.columns()]
    for g in (cache.poles, cache.anchors, cache.demand, cache.others):
        out.extend((g.ll, g.layer, g.fid, g.key))
    out.append([cache])
    return out


def _bury(items):
    if not items:
        return
    start = not _DRAIN
    _DRAIN.extend(items)
    if start:
        QTimer.singleShot(0, _drain_step)


def _drain_step():
    t0 = time.perf_counter()
    try:
        while _DRAIN and (time.perf_counter() - t0) * 1000 < _DRAIN_MS:
            box = _DRAIN[-1]
            if not box:
                _DRAIN.pop()
            elif isinstance(box, list):
                del box[-_DRAIN_SLICE:]
            elif isinstance(box, dict):
                for _ in range(min(_DRAIN_SLICE, len(box))):
                    box.popitem()
            elif isinstance(box, set):
                for _ in range(min(_DRAIN_SLICE, len(box))):
                    box.pop()
            else:
                _DRAIN.pop()
    except Exception:
        _DRAIN.clear()
        _swallowed_note()
    if _DRAIN:
        QTimer.singleShot(0, _drain_step)


# ── background work ──────────────────────────────────────────────────────────────────

class _ScanTask(QgsTask):
    """One unit of work off the main thread: a full scan, a re-filter, or a live re-check.

    ``job`` runs in the worker with a ``cancel`` callable and returns the result dict;
    ``on_done(gen, result, error)`` runs on the main thread from finished()."""

    def __init__(self, title, job, gen, on_done):
        super().__init__(title)              # default flags include CanCancel
        self._job, self._gen, self._on_done = job, gen, on_done
        self.result, self.error = None, None
        self._last_progress = 0.0

    def _progress(self, f):
        # Every progressChanged is a queued Python slot on the main thread, and each one
        # waits for the GIL this worker holds: ~300 of them piled up froze the canvas
        # ~600 ms on 63,000 drops. At most four a second.
        now = time.perf_counter()
        if f >= 1.0 or now - self._last_progress >= _PROGRESS_S:
            self._last_progress = now
            self.setProgress(100.0 * f)

    def _cancelled(self):
        # The scan polls this every 500 - 2,000 items. sleep(0) hands the GIL to the main
        # thread if it is waiting, so the canvas keeps painting while the scan runs.
        time.sleep(0)
        return self.isCanceled()

    def run(self):
        try:
            self.result = self._job(self._cancelled, self._progress)
            return True
        except scan.Cancelled:
            self.error = "cancelled"
            return False
        except Exception as exc:                  # reported in the panel, never raised
            self.error = f"{type(exc).__name__}: {exc}"
            return False

    def finished(self, ok):
        try:
            self._on_done(self._gen, self.result if ok else None,
                          None if ok else (self.error or "cancelled"))
        except Exception:
            _swallowed_note()


def _full_job(inputs, radius, need_shares, user_ticks):
    """Worker: read + measure everything; when the demand pick changed, measure anchor
    shares and pre-tick (explicit user ticks always win)."""
    def job(cancel, progress):
        cand = inputs["candidates"] if need_shares else ()
        if need_shares:
            anchors, others = [], [*inputs["candidates"], *inputs["others_fixed"]]
        else:
            anchors, others = inputs["anchors"], inputs["others"]
        cache = scan.build_cache(inputs["drops"], inputs["spares"], inputs["poles"], anchors,
                                 inputs["demand"], others, inputs["da"], radius,
                                 anchor_candidates=cand, cancel=cancel, progress=progress)
        picked = None
        if need_shares:
            auto = set(scan.pre_ticked(cache.anchor_share))
            picked = sorted(i.name for i in inputs["candidates"]
                            if user_ticks.get(i.name, i.name in auto))
            scan.remeasure_points(cache, "anchor",
                                  [i for i in inputs["candidates"] if i.name in picked], cancel)
            scan.remeasure_points(cache, "other",
                                  [i for i in inputs["candidates"] if i.name not in picked]
                                  + list(inputs["others_fixed"]), cancel)
        return {"cache": cache, "result": scan.classify(cache, radius), "picked": picked,
                "index": _index(cache)}
    return job


def _index(cache):
    """(layer id, fid) -> (is spare, row), built in the worker (63,000 drops ~40 ms off the
    canvas). Rows, not Drop views: a view kept here would be one more long-lived object
    per drop for the garbage collector to walk."""
    out = {}
    for spare, t in ((False, cache.drops), (True, cache.spares)):
        out.update(((lid, fid), (spare, i)) for i, (lid, fid) in enumerate(zip(t.layer_id, t.fid)))
    return out


def _classify_job(cache, radius):
    def job(cancel, progress):
        return {"cache": cache, "result": scan.classify(cache, radius), "picked": None,
                "index": _index(cache)}
    return job


def _live_job(cache, radius, changed_drops, point_kinds):
    """Worker: re-measure only what an edit touched, then classify."""
    def job(cancel, progress):
        if changed_drops:
            scan.remeasure_drops(cache, changed_drops)
        for kind, inps in point_kinds.items():
            scan.remeasure_points(cache, kind, inps, cancel)
        return {"cache": cache, "result": scan.classify(cache, radius), "picked": None,
                "index": _index(cache)}
    return job


# ── result table ─────────────────────────────────────────────────────────────────────

class _RowModel(QAbstractTableModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.rows = []

    def set_rows(self, rows):
        self.beginResetModel()
        self.rows = list(rows)
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):  # noqa: N802
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QModelIndex()):  # noqa: N802
        return 0 if parent.isValid() else len(_COLUMNS)

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):  # noqa: N802
        if role == Qt.ItemDataRole.DisplayRole and orientation == Qt.Orientation.Horizontal:
            return _COLUMNS[section]
        return None

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or index.row() >= len(self.rows):
            return None
        r = self.rows[index.row()]
        if role == Qt.ItemDataRole.DisplayRole:
            c = index.column()
            if c == 0:
                return _LEVEL_ICON.get(r["level"], "")
            if c == 1:
                return r["what"] + (f" · on {r['other_layer']}" if r.get("other_layer") else "")
            if c == 2:
                return "home" if r.get("home") else (r.get("layer") or "")
            if c == 3:
                return "" if r.get("fid") is None else str(r["fid"])
            if c == 4:
                return r.get("end") or ""
            if c == 5:
                return "" if r.get("pole_m") is None else f"{r['pole_m']:.2f}"
            if c == 6:
                return "" if r.get("home_m") is None else f"{r['home_m']:.2f}"
        if role == Qt.ItemDataRole.ToolTipRole:
            return f"{r['level']} · {r['what']}\n{r['key']}"
        if role == Qt.ItemDataRole.UserRole:
            return r
        return None


# ── the dock ─────────────────────────────────────────────────────────────────────────

class AssociationsPanel(QDockWidget):
    """The dock. One instance is reused; closing it clears every overlay and signal."""

    def __init__(self, iface, parent=None):
        super().__init__("Associations", parent or iface.mainWindow())
        self.setObjectName("VelocityAssociations")
        self.iface = iface
        self.ask = self._ask_dialog          # test seam: replaced by the headless runtime
        self._gen = 0
        self._task = None
        self._pending = None                 # "full" queued while a task runs
        self._cache = None
        self._result = None
        self._page = 0
        self._cursor = -1
        self._active = True
        self._loading = False
        self._shares = {}
        self._shares_for = None              # demand layer id the shares were measured for
        self._user_ticks = {}                # anchor layer name -> explicit tick
        self._drop_index = {}
        self._watched = []
        self._proj_signals = []
        self._changed = {}                   # (layer_id, fid) -> QgsGeometry
        self._point_dirty = set()
        self._orig_sel = None
        self._rb_ring = self._rb_mark = self._rb_gap = None
        self._note = ""
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._live_flush)
        self._rtimer = QTimer(self)
        self._rtimer.setSingleShot(True)
        self._rtimer.timeout.connect(self._apply_radius)
        self.setWidget(self._build_ui())
        self._apply_theme()
        self.reload_layers()
        self._restore_settings()
        self._watch_project()
        try:
            from .nexus_dock import apply_dock_chrome
            apply_dock_chrome(self)
        except Exception:
            _swallowed_note()

    # ── styling: the Span Inspector's live-theme stylesheet, same object names ─────────
    def _apply_theme(self):
        try:
            try:
                from .span_inspector import _build_qss, _theme
                from . import theme_safe
            except ImportError:
                from span_inspector import _build_qss, _theme
                import theme_safe
            c = _theme()
            sem = {"ok": "#2ea043", "warn": "#e0a020", "bad": "#e5534b"}
            try:
                sem = {k: theme_safe.ensure_contrast(v, c.get("step_bg", "#0D1320"), 4.5).name()
                       for k, v in sem.items()}
            except Exception:
                _swallowed_note()
            self._sem = sem
            self._root.setStyleSheet(_build_qss(c, sem) + f"""
QTableView#vfAssocTable {{ background:{c['step_bg']}; color:{c['tool_text']};
    border:1px solid {c['step_border']}; border-radius:8px; gridline-color:{c['step_border']};
    font-family:'JetBrains Mono','Consolas','DejaVu Sans Mono',monospace; font-size:11px; }}
QTableView#vfAssocTable::item:selected {{ background:{c['step_hi']}; color:{c['badge_text']}; }}
QHeaderView::section {{ background:{c['tool_bg']}; color:{c['section']}; border:none;
    padding:3px 5px; font-size:10px; font-weight:700; }}
QLineEdit#vfAssocRadius {{ background:{c['tool_bg']}; color:{c['title']};
    border:1px solid {c['step_border']}; border-radius:6px; padding:4px 6px; font-weight:700; }}
""")
        except Exception:
            _swallowed_note()

    def _sec(self, text):
        lbl = QLabel(f"// {text.upper()}")
        lbl.setObjectName("vfSpanSection")
        return lbl

    def _checklist(self):
        box = QWidget()
        lay = QVBoxLayout(box)
        lay.setContentsMargins(4, 2, 4, 2)
        lay.setSpacing(1)
        return box, lay

    def _build_ui(self):
        outer = QScrollArea()
        outer.setObjectName("vfSpanScroll")
        outer.setWidgetResizable(True)
        outer.setFrameShape(QFrame.Shape.NoFrame)
        self._root = QWidget()
        self._root.setObjectName("vfSpanRoot")
        v = QVBoxLayout(self._root)
        v.setContentsMargins(14, 12, 14, 14)
        v.setSpacing(8)

        title = QLabel("ASSOCIATIONS")
        title.setObjectName("vfSpanTitle")
        sub = QLabel("Every drop: one end on a pole, the other on a home, inside the radius. "
                     "Read-only — nothing is moved or edited.")
        sub.setObjectName("vfSpanSub")
        sub.setWordWrap(True)
        v.addWidget(title)
        v.addWidget(sub)

        v.addWidget(self._sec("Drops"))
        self._drops_box, self._drops_v = self._checklist()
        v.addWidget(self._drops_box)
        v.addWidget(self._sec("Spare drops"))
        self._spares_box, self._spares_v = self._checklist()
        v.addWidget(self._spares_box)
        v.addWidget(self._sec("Demand (homes)"))
        self.demand_combo = QComboBox()
        self.demand_combo.setObjectName("vfSpanCombo")
        self.demand_combo.currentIndexChanged.connect(self._on_demand_changed)
        v.addWidget(self.demand_combo)
        v.addWidget(self._sec("Drop ends on"))
        self._ends_box, self._ends_v = self._checklist()
        v.addWidget(self._ends_box)

        v.addWidget(self._sec("Radius"))
        row = QHBoxLayout()
        self.radius_edit = QLineEdit(f"{scan.DEFAULT_RADIUS:.2f}")
        self.radius_edit.setObjectName("vfAssocRadius")
        self.radius_edit.setFixedWidth(70)
        self.radius_edit.editingFinished.connect(self._on_radius_typed)
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setObjectName("vfSpanSlider")
        self.slider.setRange(int(scan.RADIUS_MIN * 100), int(scan.RADIUS_MAX * 100))
        self.slider.setValue(int(round(scan.DEFAULT_RADIUS * 100)))
        self.slider.valueChanged.connect(self._on_slider)
        row.addWidget(self.radius_edit)
        row.addWidget(QLabel("m"))
        row.addWidget(self.slider, 1)
        v.addLayout(row)
        self.radius_note = QLabel("")
        self.radius_note.setObjectName("vfSpanHint")
        self.radius_note.setWordWrap(True)
        v.addWidget(self.radius_note)

        row = QHBoxLayout()
        self.btn_run = QPushButton("RUN CHECK")
        self.btn_run.setObjectName("vfSpanGo")
        self.btn_run.clicked.connect(self.run_scan)
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.setObjectName("vfSpanMini")
        self.btn_cancel.setEnabled(False)
        self.btn_cancel.clicked.connect(self.cancel_scan)
        row.addWidget(self.btn_run, 1)
        row.addWidget(self.btn_cancel)
        v.addLayout(row)
        row = QHBoxLayout()
        self.btn_live = QPushButton("● LIVE HIGHLIGHT")
        self.btn_live.setObjectName("vfSpanMini")
        self.btn_live.setCheckable(True)
        self.btn_live.setChecked(True)
        self.btn_live.toggled.connect(self._on_live)
        self.chk_near = QCheckBox("show near-misses")
        self.chk_near.toggled.connect(lambda _on: self._show_result())
        row.addWidget(self.btn_live)
        row.addWidget(self.chk_near)
        v.addLayout(row)

        self.result = QLabel("Pick the layers, then Run.")
        self.result.setWordWrap(True)
        self.result.setObjectName("vfSpanSub")
        v.addWidget(self.result)

        self.model = _RowModel(self)
        self.table = QTableView()
        self.table.setObjectName("vfAssocTable")
        self.table.setModel(self.model)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        # Size the columns from the first 50 rows only. Qt's default reads 1,000 rows x 7
        # columns through data() on every page change: ~0.35-0.5 s with the canvas frozen.
        self.table.horizontalHeader().setResizeContentsPrecision(50)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setMinimumHeight(220)
        self.table.clicked.connect(lambda ix: self.zoom_row(ix.row()))
        v.addWidget(self.table, 1)
        self.page_note = QLabel("")
        self.page_note.setObjectName("vfSpanHint")
        v.addWidget(self.page_note)

        row = QHBoxLayout()
        self.btn_next = QPushButton("Next ▶")
        self.btn_next.setObjectName("vfSpanMini")
        self.btn_next.clicked.connect(self.next_row)
        self.btn_select = QPushButton("Select failing drops")
        self.btn_select.setObjectName("vfSpanMini")
        self.btn_select.clicked.connect(self.select_failing)
        self.chk_warn = QCheckBox("+ warnings")
        self.btn_restore = QPushButton("Restore")
        self.btn_restore.setObjectName("vfSpanMini")
        self.btn_restore.setEnabled(False)
        self.btn_restore.clicked.connect(self.restore_selection)
        for w in (self.btn_next, self.btn_select, self.chk_warn, self.btn_restore):
            row.addWidget(w)
        v.addLayout(row)
        outer.setWidget(self._root)
        return outer

    # ── layers ───────────────────────────────────────────────────────────────────────
    def _fill_checks(self, lay, attr, ids, ticked, suffix=None):
        prev = {lid: cb.isChecked() for lid, cb in getattr(self, attr, {}).items() if _alive(cb)}
        while lay.count():
            it = lay.takeAt(0)
            w = it.widget()
            if w:
                w.setParent(None)
                w.deleteLater()
        checks = {}
        proj = QgsProject.instance()
        for lid in ids:
            lyr = proj.mapLayer(lid)
            if lyr is None:
                continue
            cb = QCheckBox(f"{lyr.name()}   ({lyr.featureCount():,})"
                           + (suffix(lyr) if suffix else ""))
            cb.setChecked(prev.get(lid, ticked(lid)))
            cb.toggled.connect(lambda on, _lid=lid, _a=attr: self._on_tick(_a, _lid, on))
            lay.addWidget(cb)
            checks[lid] = cb
        if not checks:
            lay.addWidget(QLabel("— none in this project —"))
        setattr(self, attr, checks)

    def reload_layers(self):
        """(Re)build every picker from the OPEN project."""
        self._loading = True
        try:
            proj = QgsProject.instance()
            layers = [l for l in proj.mapLayers().values() if _kind(l)]
            infos = [(l.id(), l.name(), _kind(l)) for l in layers]
            self._picks = scan.pick_layers(infos, _role_of())
            self._fill_checks(self._drops_v, "_drop_checks", self._picks["drops"], lambda _l: True)
            self._fill_checks(self._spares_v, "_spare_checks", self._picks["spares"],
                              lambda _l: True)
            keep = self.demand_combo.currentData() if _alive(self.demand_combo) else None
            self.demand_combo.blockSignals(True)
            self.demand_combo.clear()
            self.demand_combo.addItem("— pick the demand layer —", None)
            listed = list(self._picks["demand"])
            rest = sorted((l for l in layers if _kind(l) in ("point", "polygon")
                           and l.id() not in listed and l.id() not in self._picks["poles"]),
                          key=lambda l: l.name().lower())
            for lid in listed + [l.id() for l in rest]:
                lyr = proj.mapLayer(lid)
                self.demand_combo.addItem(f"{lyr.name()}   ({lyr.featureCount():,})", lid)
            want = keep or self._picks["demand_auto"]
            i = self.demand_combo.findData(want) if want else -1
            self.demand_combo.setCurrentIndex(max(i, 0))
            self.demand_combo.blockSignals(False)
            self._fill_ends()
        finally:
            self._loading = False
        self._update_run_state()

    def _candidate_ids(self):
        """Anchor candidates: point layers that are not poles and not the demand layer."""
        dem = self.demand_id()
        return [lid for lid in self._picks["others"] if lid != dem]

    def _fill_ends(self):
        proj = QgsProject.instance()
        poles = list(self._picks["poles"])
        cands = self._candidate_ids()

        def ticked(lid):
            if lid in poles:
                return True
            lyr = proj.mapLayer(lid)
            name = lyr.name() if lyr else ""
            return self._user_ticks.get(name, self._shares.get(name, 0) >= scan.ANCHOR_SHARE)

        def suffix(lyr):
            if lyr.id() in poles:
                return "   (pole)"
            s = self._shares.get(lyr.name())
            return "" if s is None else f"   (anchor {s:.0%})"

        self._fill_checks(self._ends_v, "_end_checks", poles + cands, ticked, suffix)

    def _on_tick(self, attr, lid, on):
        if self._loading:
            return
        if attr == "_end_checks" and lid not in self._picks["poles"]:
            lyr = QgsProject.instance().mapLayer(lid)
            if lyr is not None:
                self._user_ticks[lyr.name()] = bool(on)
        self._save_settings()
        self._update_run_state()
        if self._cache is not None:
            self._queue_full()

    def demand_id(self):
        return self.demand_combo.currentData() if _alive(self.demand_combo) else None

    def _ticked(self, attr):
        return [lid for lid, cb in getattr(self, attr, {}).items() if _alive(cb) and cb.isChecked()]

    def _on_demand_changed(self, _i=None):
        if self._loading:
            return
        self._loading = True
        try:
            self._fill_ends()                   # the old demand layer may become a candidate
        finally:
            self._loading = False
        self._save_settings()
        self._update_run_state()
        if self.demand_id():
            self.run_scan()                     # shares are measured inside the scan

    def _missing(self):
        """Why Run cannot start, or None."""
        if not self._ticked("_drop_checks"):
            return "tick a drop layer"
        if not self.demand_id():
            return "pick the demand layer"
        return None

    def _update_run_state(self):
        why = self._missing()
        if _alive(self.btn_run):
            busy = self._task is not None
            self.btn_run.setEnabled(why is None and not busy)
            self.btn_run.setToolTip(why or "Measure every drop end")
            if why and not busy and self._result is None:
                self._set_text(f"Run is off: {why}.")

    # ── per-project memory ───────────────────────────────────────────────────────────
    def _prefix(self):
        return f"{_SETTINGS_ROOT}/{_project_key()}"

    def _save_settings(self):
        if self._loading:
            return
        try:
            s, p = QgsSettings(), self._prefix()
            s.setValue(f"{p}/radius", float(self.radius()))
            s.setValue(f"{p}/drops", self._ticked("_drop_checks"))
            s.setValue(f"{p}/spares", self._ticked("_spare_checks"))
            s.setValue(f"{p}/demand", self.demand_id() or "")
            s.setValue(f"{p}/poles_off", [lid for lid, cb in self._end_checks.items()
                                          if lid in self._picks["poles"] and not cb.isChecked()])
            s.setValue(f"{p}/anchor_ticks", [f"{'1' if v else '0'}{k}"
                                             for k, v in sorted(self._user_ticks.items())])
        except Exception:
            _swallowed_note()

    def _restore_settings(self):
        self._loading = True
        try:
            s, p = QgsSettings(), self._prefix()

            def lst(key):
                v = s.value(f"{p}/{key}", None)
                return [v] if isinstance(v, str) and v else list(v or [])

            r = s.value(f"{p}/radius", None)
            if r is not None:
                self._set_radius_widgets(scan.clamp_radius(r)[0])
            self._user_ticks = {t[1:]: t[0] == "1" for t in lst("anchor_ticks") if len(t) > 1}
            dem = s.value(f"{p}/demand", "") or ""
            if dem:
                i = self.demand_combo.findData(dem)
                if i >= 0:
                    self.demand_combo.setCurrentIndex(i)
                    self._fill_ends()
            for attr, key in (("_drop_checks", "drops"), ("_spare_checks", "spares")):
                saved = lst(key)
                if saved:
                    for lid, cb in getattr(self, attr).items():
                        cb.setChecked(lid in saved)
            for lid in lst("poles_off"):
                cb = self._end_checks.get(lid)
                if cb is not None:
                    cb.setChecked(False)
        except Exception:
            _swallowed_note()
        finally:
            self._loading = False
        self._update_run_state()

    # ── radius ───────────────────────────────────────────────────────────────────────
    def radius(self):
        return scan.clamp_radius(self.radius_edit.text())[0] if _alive(self.radius_edit) \
            else scan.DEFAULT_RADIUS

    def _set_radius_widgets(self, r):
        self.radius_edit.setText(f"{r:.2f}")
        self.slider.blockSignals(True)
        self.slider.setValue(int(round(r * 100)))
        self.slider.blockSignals(False)

    def set_radius(self, value):
        """Clamp, show why it moved, re-filter or rescan. Returns the radius used."""
        r, msg = scan.clamp_radius(value)
        self._set_radius_widgets(r)
        self.radius_note.setText(msg or "")
        self._save_settings()
        self._rtimer.start(_RADIUS_DEBOUNCE_MS)
        return r

    def _on_radius_typed(self):
        self.set_radius(self.radius_edit.text())

    def _on_slider(self, value):
        self.set_radius(value / 100.0)

    def _apply_radius(self):
        if self._cache is None:
            if self._result is not None:            # a dropped half-updated cache
                self._queue_full()
            return
        r = self.radius()
        if r <= self._cache.radius + 1e-12 and self._task is None:
            self._start("Associations: re-filter", _classify_job(self._cache, r))
        else:
            self._queue_full()

    # ── running ──────────────────────────────────────────────────────────────────────
    def _ask_dialog(self, title, text):
        return QMessageBox.question(self, title, text) == QMessageBox.StandardButton.Yes

    def _inputs(self):
        """MAIN THREAD: every LayerInput the worker needs (raises ScanRefused)."""
        proj = QgsProject.instance()

        def li(lid):
            lyr = proj.mapLayer(lid)
            if lyr is None:
                raise scan.ScanRefused("a picked layer was removed: pick again")
            return scan.layer_input(lyr, proj)

        ends = self._ticked("_end_checks")
        poles = [lid for lid in self._picks["poles"] if lid in ends]
        poles_off = [lid for lid in self._picks["poles"] if lid not in ends]
        cands = self._candidate_ids()
        anchors = [lid for lid in cands if lid in ends]
        return {
            "drops": [li(lid) for lid in self._ticked("_drop_checks")],
            "spares": [li(lid) for lid in self._ticked("_spare_checks")],
            "poles": [li(lid) for lid in poles],
            "anchors": [li(lid) for lid in anchors],
            "others": [li(lid) for lid in [*poles_off, *(c for c in cands if c not in anchors)]],
            "others_fixed": [li(lid) for lid in poles_off],
            "candidates": [li(lid) for lid in cands],
            "demand": li(self.demand_id()),
            "da": scan.wgs84_measurer(),
        }

    def run_scan(self):
        """Full scan at the current radius. Returns False when it could not start."""
        why = self._missing()
        if why:
            self._set_text(f"Run is off: {why}.")
            return False
        need_shares = self._shares_for != self.demand_id()
        if not need_shares and not self._ticked("_end_checks"):
            self._set_text("No pole data: tick a pole or anchor layer under 'Drop ends on'.")
            return False
        dem = QgsProject.instance().mapLayer(self.demand_id())
        n_dem = dem.featureCount() if dem is not None else 0
        if n_dem > scan.ASK_ABOVE_HOMES and not self.ask(
                "Associations", f"The demand layer has {n_dem:,} features. "
                "Measuring them takes a while (it runs in the background). Run?"):
            self._set_text("Not run.")
            return False
        try:
            inputs = self._inputs()
        except scan.ScanRefused as exc:
            self._set_text(f"Not run: {exc}")
            return False
        if not need_shares and not inputs["poles"] and not inputs["anchors"]:
            self._set_text("No pole data: tick a pole or anchor layer under 'Drop ends on'.")
            return False
        self._live_cap(sum(max(i.feature_count, 0) for i in inputs["drops"]))
        self._full_inputs = inputs
        self._start("Associations: scan",
                    _full_job(inputs, self.radius(), need_shares, dict(self._user_ticks)),
                    shares_for=self.demand_id() if need_shares else None)
        return True

    def _live_cap(self, n_drops):
        over = n_drops > scan.LIVE_MAX_DROPS
        self._live_capped = over
        if over and _alive(self.btn_live) and self.btn_live.isChecked():
            self._note = (f"Live re-check is off above {scan.LIVE_MAX_DROPS:,} drops "
                          f"({n_drops:,} here): press Run after editing.")
        elif not over:
            self._note = ""

    def _start(self, title, job, shares_for=None):
        if self._task is not None:
            self._pending = "full"
            self._gen += 1
            try:
                self._task.cancel()
            except Exception:
                _swallowed_note()
            return
        self._gen += 1
        self._shares_pending = shares_for
        task = _ScanTask(title, job, self._gen, self._on_done)
        try:
            task.progressChanged.connect(self._on_progress)
        except Exception:
            _swallowed_note()
        self._task = task
        self.btn_cancel.setEnabled(True)
        self._update_run_state()
        QgsApplication.taskManager().addTask(task)

    def _on_progress(self, pct):
        if _alive(self.result) and self._task is not None:
            self.result.setText(f"Measuring… {pct:.0f}%")

    def cancel_scan(self):
        """Stop the running task; its result (if it still lands) is discarded."""
        if self._task is None:
            return
        self._gen += 1
        self._pending = None
        try:
            self._task.cancel()
        except Exception:
            _swallowed_note()
        self._clear_bands()
        self._result = None
        self.model.set_rows([])
        self.page_note.setText("")
        self._set_text("Cancelled.")

    def busy(self):
        return self._task is not None

    def _on_done(self, gen, res, err):
        self._task = None
        if _alive(self.btn_cancel):
            self.btn_cancel.setEnabled(False)
        stale = gen != self._gen
        live, self._live_running = getattr(self, "_live_running", False), False
        if live and (stale or err is not None or res is None):
            # A live re-check edits the cache in place; stopped part-way, the cache is half
            # old and half new. Drop it so the next re-filter or edit runs a clean full scan.
            old, self._cache = self._cache, None
            _bury(_graveyard(old))
        if not stale and err is None and res is not None:
            old_cache, old_result = self._cache, self._result
            old_index = self._drop_index
            self._cache = res["cache"]
            self._result = res["result"]
            if res.get("picked") is not None:
                self._shares = dict(self._cache.anchor_share)
                self._shares_for = self._shares_pending
                self._apply_picked(res["picked"])
            self._drop_index = res.get("index") or _index(self._cache)
            self._page, self._cursor = 0, -1
            self._show_result()
            if self.btn_live.isChecked():
                self._watch_layers()
            # a re-filter / live re-check returns the same cache: only a replaced one goes.
            # The old index goes first so it holds no Drop alive while the lists drain.
            del old_index, old_result
            if old_cache is not self._cache:
                _bury(_graveyard(old_cache))
        elif not stale and err:
            self._set_text("Cancelled." if err == "cancelled" else f"Scan failed: {err}")
        pending, self._pending = self._pending, None
        self._update_run_state()
        if pending == "full" or (stale and self._point_dirty):
            self._point_dirty.clear()
            self._changed.clear()
            self.run_scan()

    def _apply_picked(self, picked):
        """Tick exactly the anchors the scan measured with; the user's own ticks were
        already honoured by the worker."""
        self._loading = True
        try:
            self._fill_ends()
            proj = QgsProject.instance()
            for lid, cb in self._end_checks.items():
                if lid in self._picks["poles"]:
                    continue
                lyr = proj.mapLayer(lid)
                cb.setChecked(bool(lyr) and lyr.name() in picked)
        finally:
            self._loading = False

    def _queue_full(self):
        if self._task is not None:
            self._pending = "full"
            self._gen += 1
            try:
                self._task.cancel()
            except Exception:
                _swallowed_note()
        else:
            self.run_scan()

    # ── showing a result ─────────────────────────────────────────────────────────────
    def _set_text(self, text):
        if _alive(self.result):
            self.result.setText(text)

    def visible_rows(self):
        """All rows the table can page through (INFO near-misses only when asked)."""
        if self._result is None:
            return []
        show_info = _alive(self.chk_near) and self.chk_near.isChecked()
        return [r for r in self._result["rows"] if show_info or r["level"] != "INFO"]

    def page_rows(self):
        rows = self.visible_rows()
        return self._filled(rows[self._page * scan.PAGE:(self._page + 1) * scan.PAGE])

    def _filled(self, page):
        """Distances + gap point for the rows on screen. Page 1 already came filled from
        the scan; a later page is filled here once, when it is first opened."""
        if self._cache is not None:
            scan.fill_rows(page, self._cache)
        return page

    def _show_result(self):
        res = self._result
        if res is None:
            return
        lines = scan.summary_lines(res)
        if self._cache is not None and self._cache.anchor_skipped:
            lines.append("Skipped as anchor (over 200,000 points): "
                         + ", ".join(self._cache.anchor_skipped))
        if self._note:
            lines.append(self._note)
        self._set_text("\n".join(lines))
        rows = self.visible_rows()
        page = self._filled(rows[self._page * scan.PAGE:(self._page + 1) * scan.PAGE])
        self.model.set_rows(page)
        more = len(rows) - (self._page + 1) * scan.PAGE
        pages = max(1, math.ceil(len(rows) / scan.PAGE))
        self.page_note.setText(
            f"{len(rows):,} rows · page {self._page + 1} of {pages}"
            + (f" · +{more:,} more, use Next" if more > 0 else ""))
        self._draw(page)

    # ── canvas ───────────────────────────────────────────────────────────────────────
    def _bands(self):
        canvas = self.iface.mapCanvas()
        if not _alive(self._rb_ring):
            self._rb_ring = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PolygonGeometry)
            self._rb_ring.setStrokeColor(_RING_COLOR)
            self._rb_ring.setFillColor(QColor(0, 0, 0, 0))
            self._rb_ring.setWidth(2)
        if not _alive(self._rb_mark):
            self._rb_mark = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PointGeometry)
            self._rb_mark.setIcon(QgsRubberBand.IconType.ICON_CIRCLE)
            self._rb_mark.setIconSize(_MARK_PX)
            self._rb_mark.setColor(_RING_COLOR)
            self._rb_mark.setWidth(2)
        if not _alive(self._rb_gap):
            self._rb_gap = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.LineGeometry)
            self._rb_gap.setColor(_GAP_COLOR)
            self._rb_gap.setWidth(2)
            self._rb_gap.setLineStyle(Qt.PenStyle.DashLine)
        return self._rb_ring, self._rb_mark, self._rb_gap

    def ring_rows(self, page=None):
        """Rows that get a ring: FAIL rows that point at a drop end (or a broken drop's
        first point), on the current page."""
        return [r for r in (self.page_rows() if page is None else page)
                if r["level"] == "FAIL" and r.get("ll") and not r.get("home")]

    def _draw(self, page):
        self._clear_bands(keep=True)
        if not (_alive(self.btn_live) and self.btn_live.isChecked()):
            return
        ring, mark, gap = self._bands()
        wgs = QgsCoordinateReferenceSystem(_WGS84)
        r = self.radius()
        # One multi-geometry per band, added once: 2,000 rings ~60 ms instead of ~350 ms.
        rings, marks, gaps = QgsMultiPolygon(), QgsMultiPoint(), QgsMultiLineString()
        for row in self.ring_rows(page):
            lon, lat = row["ll"]
            try:
                rings.addGeometry(ring_polygon(lon, lat, r))
                marks.addGeometry(QgsPoint(lon, lat))
                if row.get("gap_ll"):
                    gx, gy = row["gap_ll"]
                    gaps.addGeometry(QgsLineString([lon, gx], [lat, gy]))
            except Exception:
                _swallowed_note()
        for rb, geom in ((ring, rings), (mark, marks), (gap, gaps)):
            if geom.numGeometries():
                try:
                    rb.addGeometry(QgsGeometry(geom), wgs, False)
                except Exception:
                    _swallowed_note()
        for rb in (ring, mark, gap):
            rb.updatePosition()
            rb.update()
            rb.show()

    def ring_count(self):
        if not _alive(self._rb_mark):
            return 0
        try:
            return self._rb_mark.numberOfVertices()
        except Exception:
            return 0

    def _clear_bands(self, keep=False):
        kinds = {"_rb_ring": QgsWkbTypes.GeometryType.PolygonGeometry,
                 "_rb_mark": QgsWkbTypes.GeometryType.PointGeometry,
                 "_rb_gap": QgsWkbTypes.GeometryType.LineGeometry}
        for attr, kind in kinds.items():
            rb = getattr(self, attr)
            if _alive(rb):
                try:
                    rb.reset(kind)
                    if not keep:
                        rb.hide()
                        self.iface.mapCanvas().scene().removeItem(rb)
                except Exception:
                    _swallowed_note()
            if not keep:
                setattr(self, attr, None)

    # ── navigation ───────────────────────────────────────────────────────────────────
    def zoom_row(self, i):
        page = self.page_rows()
        if not 0 <= i < len(page):
            return
        self._cursor = i
        row = page[i]
        if not row.get("ll"):
            return
        try:
            from qgis.core import QgsCoordinateTransform
            canvas = self.iface.mapCanvas()
            dest = canvas.mapSettings().destinationCrs()
            xf = QgsCoordinateTransform(QgsCoordinateReferenceSystem(_WGS84), dest,
                                        QgsProject.instance())
            lon, lat = row["ll"]
            d = max(self.radius() * 15, 15) / 111_000.0
            rect = xf.transformBoundingBox(QgsRectangle(lon - d, lat - d, lon + d, lat + d))
            canvas.setExtent(rect)
            canvas.refresh()
            geom = QgsGeometry.fromPointXY(QgsPointXY(lon, lat))
            canvas.flashGeometries([geom], QgsCoordinateReferenceSystem(_WGS84))
        except Exception:
            _swallowed_note()
        if _alive(self.table):
            self.table.selectRow(i)

    def next_row(self):
        """Step to the next row; past the end of a page load the next one; wrap to the start."""
        rows = self.visible_rows()
        if not rows:
            return
        page = self.page_rows()
        nxt = self._cursor + 1
        if nxt >= len(page):
            pages = max(1, math.ceil(len(rows) / scan.PAGE))
            self._page = (self._page + 1) % pages
            self._cursor = -1
            self._show_result()
            nxt = 0
        self.zoom_row(nxt)

    # ── selection (never an edit) ────────────────────────────────────────────────────
    def _failing_ids(self, with_warn):
        out = {}
        for r in (self._result or {}).get("rows", []):
            if r.get("home") or r.get("layer_id") is None or r.get("fid") is None:
                continue
            if r["level"] == "FAIL" or (with_warn and r["level"] == "WARN"):
                out.setdefault(r["layer_id"], set()).add(r["fid"])
        return out

    def select_failing(self):
        ids = self._failing_ids(_alive(self.chk_warn) and self.chk_warn.isChecked())
        proj = QgsProject.instance()
        if self._orig_sel is None:
            self._orig_sel = {lid: list(proj.mapLayer(lid).selectedFeatureIds())
                              for lid in self._ticked("_drop_checks") + self._ticked("_spare_checks")
                              if proj.mapLayer(lid) is not None}
        for lid in self._orig_sel:
            lyr = proj.mapLayer(lid)
            if lyr is not None:
                lyr.selectByIds(sorted(ids.get(lid, ())))
        self.btn_restore.setEnabled(True)
        return sum(len(v) for v in ids.values())

    def restore_selection(self):
        if self._orig_sel is None:
            return
        proj = QgsProject.instance()
        for lid, fids in self._orig_sel.items():
            lyr = proj.mapLayer(lid)
            if lyr is not None:
                lyr.selectByIds(fids)
        self._orig_sel = None
        self.btn_restore.setEnabled(False)

    # ── live re-check (signal-driven) ────────────────────────────────────────────────
    def _on_live(self, on):
        if on:
            self._live_cap(sum(QgsProject.instance().mapLayer(l).featureCount()
                               for l in self._ticked("_drop_checks")
                               if QgsProject.instance().mapLayer(l) is not None))
            self._watch_layers()
            self._show_result()
        else:
            self._unwatch_layers()
            self._clear_bands()

    def _watch_layers(self):
        self._unwatch_layers()
        if getattr(self, "_live_capped", False):
            return
        proj = QgsProject.instance()
        ids = set(self._ticked("_drop_checks") + self._ticked("_spare_checks")
                  + list(self._end_checks) + ([self.demand_id()] if self.demand_id() else []))
        for lid in ids:
            lyr = proj.mapLayer(lid)
            if lyr is None:
                continue
            for sig in _EDIT_SIGNALS:
                try:
                    getattr(lyr, sig).connect(self._edit_slot(lid, sig))
                except Exception:
                    _swallowed_note()
                    continue
            self._watched.append(lyr)

    def _edit_slot(self, lid, sig):
        slots = self.__dict__.setdefault("_slots", {})
        key = (lid, sig)
        if key not in slots:
            slots[key] = lambda *a, _l=lid, _s=sig: self._on_edit(_l, _s, a)
        return slots[key]

    def connected_signals(self):
        return len(self._watched) * len(_EDIT_SIGNALS) if self._watched else 0

    def _unwatch_layers(self):
        slots = self.__dict__.get("_slots", {})
        for lyr in self._watched:
            if not _alive(lyr):
                continue
            for sig in _EDIT_SIGNALS:
                fn = slots.get((lyr.id(), sig))
                if fn is None:
                    continue
                try:
                    getattr(lyr, sig).disconnect(fn)
                except Exception:
                    _swallowed_note()
        self._watched = []
        self.__dict__["_slots"] = {}

    def _on_edit(self, lid, sig, args):
        is_line = lid in self._ticked("_drop_checks") or lid in self._ticked("_spare_checks")
        if is_line and sig == "geometryChanged" and len(args) >= 2:
            self._changed[(lid, args[0])] = QgsGeometry(args[1])
        else:
            self._point_dirty.add(lid if not is_line else "*lines*")
        if self._task is not None:                # a running scan is stale now
            self._pending = "full"
            self._gen += 1
            try:
                self._task.cancel()
            except Exception:
                _swallowed_note()
            return
        self._timer.start(_DEBOUNCE_MS)

    def _live_flush(self):
        if self._cache is None or self._task is not None:
            return
        if "*lines*" in self._point_dirty:          # a drop was added / deleted / committed
            self._point_dirty.clear()
            self._changed.clear()
            self.run_scan()
            return
        proj = QgsProject.instance()
        changed = []
        for (lid, fid), geom in self._changed.items():
            ref = self._drop_index.get((lid, fid))
            lyr = proj.mapLayer(lid)
            if ref is None or lyr is None:
                self._changed.clear()
                self._point_dirty.clear()
                self.run_scan()
                return
            table = self._cache.spares if ref[0] else self._cache.drops
            changed.append((table[ref[1]], geom, scan.layer_input(lyr, proj)))
        kinds = {}
        if self._point_dirty:
            inp = self._inputs()
            dirty = self._point_dirty
            poles = set(self._picks["poles"])
            if dirty & poles:
                kinds["pole"] = inp["poles"]
            if self.demand_id() in dirty:
                kinds["demand"] = [inp["demand"]]
            if dirty - poles - {self.demand_id()}:
                kinds["anchor"] = inp["anchors"]
                kinds["other"] = inp["others"]
        self._changed.clear()
        self._point_dirty.clear()
        self._start("Associations: live re-check",
                    _live_job(self._cache, self.radius(), changed, kinds))
        self._live_running = self._task is not None

    # ── project tracking ─────────────────────────────────────────────────────────────
    def _watch_project(self):
        proj = QgsProject.instance()
        for name in ("layersAdded", "layersRemoved", "cleared", "readProject"):
            try:
                getattr(proj, name).connect(self._on_project_changed)
                self._proj_signals.append(name)
            except Exception:
                _swallowed_note()

    def _unwatch_project(self):
        proj = QgsProject.instance()
        for name in self._proj_signals:
            try:
                getattr(proj, name).disconnect(self._on_project_changed)
            except Exception:
                _swallowed_note()
        self._proj_signals = []

    def _on_project_changed(self, *args):
        self.cancel_scan()
        self._unwatch_layers()
        self._clear_bands()
        self._cache = self._result = None
        self._shares, self._shares_for, self._orig_sel = {}, None, None
        self.model.set_rows([])
        self.page_note.setText("")
        try:
            self.reload_layers()
            self._restore_settings()
        except Exception:
            _swallowed_note()

    # ── teardown ─────────────────────────────────────────────────────────────────────
    def deactivate(self):
        """No rings, no signals, no running task. Safe to call twice."""
        self.cancel_scan()
        for t in (self._timer, self._rtimer):
            try:
                t.stop()
            except Exception:
                _swallowed_note()
        self._unwatch_layers()
        self._clear_bands()

    def closeEvent(self, event):
        try:
            self.deactivate()
            self._unwatch_project()
        except Exception:
            _swallowed_note()
        try:
            super().closeEvent(event)
        except Exception:
            _swallowed_note()

    def showEvent(self, event):
        try:
            super().showEvent(event)
            self._apply_theme()
            if not self._proj_signals:
                self._watch_project()
        except Exception:
            _swallowed_note()


_PANEL = None


def show_associations(iface):
    """Open (or re-show) the Associations dock. Returns the dock."""
    global _PANEL
    if not _alive(_PANEL):
        _PANEL = AssociationsPanel(iface)
        iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, _PANEL)
    else:
        _PANEL.reload_layers()
        _PANEL._restore_settings()
        _PANEL._apply_theme()
    _PANEL.show()
    _PANEL.raise_()
    return _PANEL


def is_open():
    try:
        return bool(_alive(_PANEL) and _PANEL.isVisible())
    except Exception:
        return False


def close_associations():
    """Tear down on plugin unload — no rubber band, signal, task or project hook left."""
    global _PANEL
    if _alive(_PANEL):
        for fn in ("deactivate", "_unwatch_project"):
            try:
                getattr(_PANEL, fn)()
            except Exception:
                _swallowed_note()
        try:
            _PANEL.iface.removeDockWidget(_PANEL)
        except Exception:
            _swallowed_note()
        try:
            _PANEL.setParent(None)
            _PANEL.deleteLater()
        except Exception:
            _swallowed_note()
    _PANEL = None
