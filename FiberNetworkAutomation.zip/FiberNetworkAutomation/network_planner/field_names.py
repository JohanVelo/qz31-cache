"""Field-name resolver — one place that knows what a column is CALLED.

Why this exists
---------------
The Network Planner is being renamed: a "zone" is really a PON, and a "group" is
really a splitter (JJ 2026-07-23). The user-facing words are the easy part. The
hard part is that those words are also **column names written into your data**:

    zone_id  zone_name  group_id  group_local  group_8 … group_128

Those columns are read by 13 files OUTSIDE this package (the BoQ take-off, the
HLD Atlas, the tagging engine, four manual-planning scripts) and they are stored
in every project already on disk. A find-and-replace would strand all of it.

So instead of asking "is the field called zone_id?", code asks this module for a
ROLE — "the PON id" — and gets back whatever *that particular layer* calls it:
the new name, the old name, or the shapefile-truncated form. New layers are
created with the new names; old projects keep working untouched.

    idx = index_of(layer, PON_ID)          # -1 if absent
    name = resolve(layer, SPLITTER_ID)     # None if absent
    QgsField(new_name(PON_ID), ...)        # when CREATING a layer

The shapefile 10-character trap
-------------------------------
Shapefiles cut field names at 10 characters. That is why the size-keyed fields
become ``spl_<N>`` and NOT ``splitter_<N>``: splitter_16, splitter_12,
splitter_100 and splitter_128 would ALL truncate to "splitter_1" — four distinct
columns collapsing onto one name. ``spl_128`` is 7 characters and never
truncates. The names that do fit keep the full word.

Every alias list below therefore includes the 10-char truncation of any name
longer than that. ``assert_no_truncation_collision()`` proves the set is safe and
is called by the test suite — do not add a name without re-running it.

Pure Python: no QGIS imports, so this is testable headless. Anything exposing
``.fields()`` (or a plain list of names) can be passed in.
"""

import re

# ── Roles ────────────────────────────────────────────────────────────────────
# The stable identifiers the rest of the code uses. The strings themselves are
# arbitrary keys — never write them to data.
PON_NUM = "pon_num"
PON_NAME = "pon_name"
UNIT_COUNT = "unit_count"
SPLITTER_ID = "splitter_id"
SPLITTER_LOCAL = "splitter_local"
SPLITTER_COUNT = "splitter_count"

SHAPEFILE_NAME_LIMIT = 10


def _with_truncation(*names):
    """Return names plus the 10-char shapefile form of any that overflow.

    Order is preserved and duplicates dropped, so the caller's preference order
    (new name first, legacy last) survives.
    """
    out = []
    for n in names:
        for cand in (n, n[:SHAPEFILE_NAME_LIMIT]):
            if cand not in out:
                out.append(cand)
    return tuple(out)


#: role -> accepted column names, MOST PREFERRED FIRST.
#: New name, then its truncation, then the legacy name it replaced. Resolution
#: walks this in order, so a layer carrying both (a migrated project mid-flight)
#: deterministically resolves to the new one.
#: NOTE ON THE CHOSEN NAMES — the two obvious ones were already taken by
#: DIFFERENT concepts, and reusing them would have made the resolver silently
#: return the wrong column:
#:   'pon_id'      manual_planning/fibre_automation.py stores a STRING LABEL
#:                 there ("KYA.PON.01"), not an integer PON number.
#:   'splitter_id' dock_widget.py:5401 uses it as a sequential 1..N row index on
#:                 the "Optimal Splitter Locations" layer — nothing to do with
#:                 which splitter a demand point belongs to.
#: Hence pon_num and spl_id. Every name below is <=10 chars, so none of them is
#: altered by a shapefile, and none collides with an existing field anywhere in
#: the plugin (checked: pon_no 296 uses, pon_ref 4, pon_label 4 — all avoided).
ALIASES = {
    PON_NUM:        _with_truncation("pon_num", "zone_id"),
    PON_NAME:       _with_truncation("pon_name", "zone_name"),
    UNIT_COUNT:     _with_truncation("unit_count"),          # never renamed
    SPLITTER_ID:    _with_truncation("spl_id", "group_id"),
    SPLITTER_LOCAL: _with_truncation("spl_local", "group_local"),
    SPLITTER_COUNT: _with_truncation("spl_count", "splitter_count"),
}

#: role -> the name to use when CREATING a new layer.
NEW_NAMES = {
    PON_NUM:        "pon_num",
    PON_NAME:       "pon_name",
    UNIT_COUNT:     "unit_count",
    SPLITTER_ID:    "spl_id",
    SPLITTER_LOCAL: "spl_local",
    SPLITTER_COUNT: "spl_count",
}

#: Size-keyed splitter membership columns — ``group_8`` historically, ``spl_8``
#: going forward. Matches BOTH generations so a mixed project still resolves.
#:
#: CASE-SENSITIVE ON PURPOSE. This regex replaces dock_widget's ``_DROP_GRP_RE``
#: (was ``re.compile(r'group_\d+')``), and adding IGNORECASE would make ``GROUP_8``
#: start matching where it never did — a silent behaviour change smuggled into a
#: phase whose whole promise is that nothing changes. ``spl_<N>`` is the ONLY
#: intended addition. If upper-case field names turn out to be a real problem,
#: that is its own fix with its own evidence, not a side effect of this one.
SIZE_FIELD_RE = re.compile(r"(?:group|spl)_(\d+)$")

#: What a NEW size-keyed field is called. Deliberately short — see the module
#: docstring for the four-way truncation collision this avoids.
SIZE_FIELD_NEW = "spl_{n}"


def size_field_new(n):
    """Name for a new size-keyed splitter column, e.g. ``spl_128``."""
    return SIZE_FIELD_NEW.format(n=int(n))


def is_size_field(name):
    """True for ``group_<N>`` or ``spl_<N>`` (either generation)."""
    return bool(name) and SIZE_FIELD_RE.fullmatch(str(name)) is not None


def size_of_field(name):
    """The <N> from a size-keyed column name, or None if it isn't one."""
    m = SIZE_FIELD_RE.fullmatch(str(name)) if name else None
    return int(m.group(1)) if m else None


# ── Resolution ───────────────────────────────────────────────────────────────

def field_names(layer):
    """Column names for a layer, a QgsFields, or a plain iterable of names.

    Deliberately duck-typed so the resolver can be unit-tested with a list of
    strings and no QGIS in the process.
    """
    if layer is None:
        return []
    flds = None
    getter = getattr(layer, "fields", None)
    if callable(getter):
        try:
            flds = getter()
        except Exception:
            flds = None
    if flds is None:
        flds = layer
    out = []
    try:
        for f in flds:
            n = f.name() if hasattr(f, "name") else f
            if n is not None:
                out.append(str(n))
    except TypeError:
        return []
    return out


def resolve(layer, role, names=None):
    """The column this layer actually uses for ``role``, or None.

    Case-insensitive, because shapefile drivers are inconsistent about case and
    the existing code already lower-cases before comparing.
    """
    aliases = ALIASES.get(role)
    if not aliases:
        return None
    have = names if names is not None else field_names(layer)
    lower = {}
    for n in have:
        lower.setdefault(str(n).lower(), str(n))   # first spelling wins
    for cand in aliases:
        hit = lower.get(cand.lower())
        if hit is not None:
            return hit
    return None


def has(layer, role, names=None):
    """True if the layer carries a column for ``role`` under any known name."""
    return resolve(layer, role, names=names) is not None


def index_of(layer, role):
    """Field index for ``role``, or -1 — mirrors ``QgsFields.indexOf``."""
    name = resolve(layer, role)
    if name is None:
        return -1
    try:
        return layer.fields().indexOf(name)
    except Exception:
        pass
    try:
        return field_names(layer).index(name)
    except ValueError:
        return -1


def value(feature, layer, role, default=None):
    """Read ``role`` off a feature, resolving the column against ``layer``."""
    name = resolve(layer, role)
    if name is None:
        return default
    try:
        v = feature[name]
    except Exception:
        return default
    return default if v is None else v


def new_name(role):
    """The column name to CREATE for ``role``."""
    return NEW_NAMES[role]


def size_fields(layer, names=None):
    """Every size-keyed splitter column on the layer, e.g. ['group_8']."""
    have = names if names is not None else field_names(layer)
    return [n for n in have if is_size_field(n)]


# ── Safety net ───────────────────────────────────────────────────────────────

def assert_no_truncation_collision(extra_names=()):
    """Raise if any two column names we may WRITE collide at 10 characters.

    This is the check that caught ``splitter_16`` / ``splitter_12`` /
    ``splitter_100`` / ``splitter_128`` all truncating to ``splitter_1``. Pass
    the size-keyed names a project will actually create via ``extra_names``.
    """
    seen = {}
    clashes = []
    for name in list(NEW_NAMES.values()) + list(extra_names):
        key = str(name)[:SHAPEFILE_NAME_LIMIT].lower()
        if key in seen and seen[key] != name:
            clashes.append((seen[key], name, key))
        else:
            seen[key] = name
    if clashes:
        detail = "; ".join(f"{a} + {b} -> {k}" for a, b, k in clashes)
        raise ValueError(
            "Field names collide when a shapefile truncates them to "
            f"{SHAPEFILE_NAME_LIMIT} chars: {detail}")
    return True
