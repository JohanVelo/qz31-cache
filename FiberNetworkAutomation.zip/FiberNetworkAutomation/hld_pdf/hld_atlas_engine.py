# -*- coding: utf-8 -*-
# ============================================================================
# HLD Atlas Engine  (Phase 0 — config-driven)
# ----------------------------------------------------------------------------
# Builds two editable QgsPrintLayouts in the CURRENT project:
#     <layout_overview>  (1 page: PON numbers + feeder routes)
#     <layout_atlas>     (N pages: one per coverage feature, full detail)
# A3 landscape, big map + sidebar (Legend / North / logo / title block),
# matching the Phase 1 reference deliverable.
#
# Idempotent: removes+recreates its own layouts each run. Does NOT export
# (export is a separate headless step — never render a big atlas on the GUI thread).
#
# DE-HARDCODED: every project-specific value lives in DEFAULT_CFG below.
# A caller injects overrides by defining a dict `HLD_CFG` in the namespace
# BEFORE exec()'ing this file, e.g.:
#     ns = {"HLD_CFG": {...}}
#     exec(open("hld_atlas_engine.py").read(), ns)
# With no HLD_CFG defined, it reproduces the Mohadin Phase 2 PDF exactly.
# ============================================================================
import os
import copy
from qgis.core import (
    QgsProject, QgsPrintLayout, QgsLayoutItemPage, QgsLayoutItemMap,
    QgsLayoutItemLabel, QgsLayoutItemPicture, QgsLayoutItemShape,
    QgsLayoutPoint, QgsLayoutSize, QgsUnitTypes, QgsRectangle, QgsLayoutMeasurement,
)
from qgis.PyQt.QtGui import QColor, QFont

# ---------------------------------------------------------------------------
# DEFAULT CONFIG = Mohadin Phase 2 (the proven deliverable).
# ---------------------------------------------------------------------------
DEFAULT_CFG = {
    # --- identity / title block ---
    "project_name":   "Mohadin Phase 2",
    "company":        "Velocity Fibre",
    "designer":       "Johan Scholtz",
    "date_str":       "07-07-2026",
    "revision":       "1",
    # P1.4 ISO 7200 title block: dynamic Sheet "X of Y" + revision history + sign-off.
    # False → the simple 5-row block (MOA deliverable unchanged).
    "iso_title_block": False,
    "scale_note":      "As-Shown (A3)",
    "revision_rows":   [],          # [(rev, date, description, by), ...] up to 5
    "signoff":         ["Designed", "Reviewed", "Approved"],
    "cover_page":      False,       # P3: prepend a KPI + table-of-contents cover page (hld_generate)
    "title_overview": "Mohadin Phase 2 Overview",
    "title_atlas_expr": 'Mohadin Phase 2 - PON [% "pon_no" %]',   # dynamic per-page

    # --- assets ---
    "logo_path":  r"C:/Temp/ph2_hld_assets/fibertime_logo.png",
    "legend_dir": r"C:/Temp/ph2_hld_assets/legend",

    # --- layout names ---
    # The deliverable is ONE Report: header = overview (page 1), field-group body =
    # one detail page per coverage feature. The overview/detail layouts are OWNED by
    # the report (not separate entries in the Layout Manager).
    "layout_overview": "MOA PH2 HLD Overview",     # report header (page 1)
    "layout_atlas":    "MOA PH2 HLD Atlas",        # report body (per-PON detail)
    "layout_report":   "MOA PH2 HLD Book",         # the QgsReport shown in the manager

    # --- layer resolution ---
    "group_name":  "phase 2 hld",   # resolve layers inside this group (JJ renames v1->friendly)
    "aoi_layer":   "greenfield and overbuild poly",
    "aoi_subset":  '"Name" = \'Greenfield\'',   # only the Greenfield polygon; None to keep all
    "basemap":     "Google Satellite",

    # role -> ordered candidate layer names (first found wins; group first, then whole project)
    "roles": {
        "coverage":     ["PON v1"],
        "primary":      ["ADSS", "Primary Cable v1"],
        "secondary":    ["Secondary Cable v1", "Secondary Cable"],
        "distribution": ["Mini-ADSS", "Distribution Cable v1"],
        "drop":         ["Drop Cable", "Drop Cable v1"],
        "spare_drop":   ["Spare Drop Cable v1", "Spare Drop Cable"],
        "poles":        ["Pole", "poles v1"],
        "fts":          ["FTS Splitter", "FTS Splitters v1"],
        "sts":          ["STS Splitter", "STS Splitters v1"],
        "enc_splice":   ["Enclosures Splice v1", "Enclosures Splice"],
        "enc_conn":     ["Enclosures Connectorised v1", "Enclosures Connectorised"],
        "enclosure":    ["Enclosure v1"],
        "ont":          ["ONT v1"],
        # stable area layers for the summary (independent of the atlas coverage choice)
        "pon_area":     ["PON v1", "PON"],
        "zones":        ["Zones v1", "Zone v1", "Zones", "Zone"],
    },

    # detail-page layers when there is NO group (saved 'HLD only' project). Draw order = top first.
    # NO primary/secondary feeders (they are overview-only).
    "detail_fallback": [
        "STS Splitters v1", "STS Splitter",
        "Enclosures Splice v1", "Enclosures Splice",
        "Enclosures Connectorised v1", "Enclosures Connectorised",
        "FTS Splitters v1", "FTS Splitter",
        "ONT v1", "Distribution Cable v1", "Mini-ADSS",
        "Drop Cable v1", "Drop Cable", "Spare Drop Cable v1",
        "poles v1", "Pole", "PON v1",
    ],
    "detail_exclude": ["Zones v1", "where slack applies", "Erven v1"],

    # --- atlas ---
    "coverage_sort_field": "label",
    "atlas_filename_expr": "'MOA_PH2_PON_' || \"label\"",
    "atlas_margin": 0.15,

    # --- grid coverage (auto-tile the AOI; one detail page per grid cell) ---
    # >0 triggers grid mode: the engine builds a grid over the AOI polygon at this cell
    # size (metres) and uses it as the coverage. Cell width/height come from the box the
    # operator drags on the canvas. 0 = off (per-PON / per-Zone coverage as normal).
    "grid_cell_w_m": 0.0,
    "grid_cell_h_m": 0.0,
    "grid_layer_name": "HLD Grid",

    # "report" (Generate PDF: one book, overview page 1) | "layouts" (Open in Print Layout:
    # page-view overview + detail atlas you edit directly). Set by the caller.
    "build_mode": "report",

    # --- styling ---
    "enc_splice_rgb": "0,60,255",    # splice = blue
    "enc_conn_rgb":   "0,200,200",   # connectorised = cyan
    "pon_fill_alpha": 45,            # see houses through the PON fill
    # P1.3 optional tiered cable symbology. None = keep each layer's own style
    # (default → MOA deliverable unchanged). Else role -> {"w": <mm>, "color": "#hex"}
    # applied at build time so cluttered per-project cable styles become a clean HLD look.
    "hld_cable_style": None,
    # P2 QA overlay: flag cables whose longest pole-to-pole span (max vertex-to-vertex
    # segment) exceeds the limit, drawn thick RED on the map so violations show on the
    # page. False/{} = off (MOA unchanged). qa_span_limits: role -> max span (metres).
    "hld_qa_overlay": False,
    "qa_span_limits":  {},          # e.g. {"drop": 75, "distribution": 70, "primary": 70}

    # --- labels: role -> settings dict (label ON) or None (label OFF on detail pages) ---
    "labels": {
        "distribution": {"size": 5.5, "along_line": True,  "buf": 0.8, "strip": "MOA."},
        "poles":        {"size": 5.0, "along_line": False, "buf": 0.5, "strip": "MOA.P."},
        "fts":          {"size": 6.5, "along_line": False, "buf": 0.8, "strip": "MOA."},
        "sts":          {"size": 5.5, "along_line": False, "buf": 0.8, "strip": "MOA.STS.8.DIS.DM.P."},
        "primary":   None,   # feeders overview-only
        "secondary": None,
        "drop":      None,   # drop labels OFF (JJ)
        "spare_drop": None,
    },
    "label_min_scale": 9000.0,

    # --- legend ---
    # points render the layer's REAL symbol; lines draw as a coloured bar
    "legend_points": [
        ("FTS Splitter", "fts"), ("STS Splitter", "sts"),
        ("Enclosure (Splice)", "enc_splice"), ("Enclosure (Connectorised)", "enc_conn"),
        ("Pole", "poles"),
    ],
    "legend_lines": [
        ("ADSS", "primary", "#0000ff"),
        ("Mini-ADSS", "distribution", "#ef3ec8"),
        ("Drop Cable", "drop", "#29a500"),
    ],
    # GUARD RAIL: auto-complete the legend from the layers actually drawn on the map,
    # so nothing on the canvas is left out (the configured rows above render first for
    # nice names/order; any remaining drawn layer is appended with its REAL symbol).
    "legend_auto":         True,
    "legend_basemap_note": "Satellite Photography",
    "legend_compact":      False,    # tight rows/font (force); else auto below legend_max_h
    "legend_max_h":        82.0,     # mm: a taller normal legend auto-re-renders compact
    # raw layer name -> friendly legend label (else the name minus a trailing " v1")
    "legend_aliases": {
        "ONT v1":               "Home Connections (ONT)",
        "Home Connection v1":   "Home Connections",
        "Spare Drop Cable v1":  "Spare Drop Cables",
        "Secondary Cable v1":   "Secondary Feeder",
        "Primary Cable v1":     "Primary Feeder (ADSS)",
        "Distribution Cable v1": "Distribution (Mini-ADSS)",
        "PON v1":               "PONs",
        "Zones v1":             "Zones",
        "Erven v1":             "Erfs",
        "poles v1":             "Poles",
        "greenfield and overbuild poly": "Project Boundary",
    },

    # --- sidebar detail (fill the empty space with real info, like the reference) ---
    "show_map_info":   True,                 # Scale / Projection block
    "projection_note": "EPSG:4326 · WGS 84",
    "show_summary":    True,                 # project feature-count summary panel
    "summary_title":   "PROJECT TOTALS",
    # per-PAGE summary: when True, atlas detail pages show the CURRENT coverage
    # feature's own stats (from its stat_* fields) instead of whole-project totals.
    "per_page_summary": False,
    "zone_stat_source": {},        # {"units":"<zone field>","splitters":"<zone field>"} or {}
    "zone_stat_prefix": "ZONE ",
    # --- P3.3 per-page cable schedule table (config-gated; off => default/MOA unchanged) ---
    # A native QgsLayoutItemAttributeTable on the chosen cable role, filtered to the current
    # atlas unit (only cables intersecting THIS PON/Zone), row-capped, hidden on the overview.
    "per_page_table": False,
    "table_role":     "distribution",   # which cable role to schedule (drops would be 100s/unit)
    "table_columns":  None,             # [(field,"Header"), ...] or None -> auto-pick from fields
    "table_max_rows": 40,
    "table_title":    "CABLE SCHEDULE",
    "table_box_h":    58.0,             # sidebar box height (mm) reserved for title + table
    "summary_roles": [                       # (label, role) — counts read live at build time
        ("Homes (ONT)", "ont"),      ("Poles", "poles"),
        ("FTS Splitters", "fts"),    ("STS Splitters", "sts"),
        ("Enclosures", "enclosure"), ("PONs", "pon_area"),
        ("Zones", "zones"),          ("Drop Cables", "drop"),
        ("Spare Drops", "spare_drop"), ("Distribution", "distribution"),
    ],

    # --- page size for new_layout: "A3" (HLD/commercial) | "A4" (wayleave) ---
    "page_size":    "A3",

    # --- MODEL / frame style: "hld" (default network atlas) | "commercial" (grid drawing)
    #     | "wayleave" (A4 grid wayleave — Cambridge Village style: full-bleed map + bottom
    #       title strip + Poles/Span/Erven/POP legend + Velocity logo) ---
    "frame_style":  "hld",
    # wayleave bottom-strip content (only used by frame_style == "wayleave"):
    "wayleave_desc": ("Application for wayleave for the purpose of installing aerial fibre.\n"
                      "Fibre to be installed exclusively in mid-block deployment so as to avoid "
                      "any other services."),
    "wayleave_scale_note": "NTS",
    "page_label_expr": "",   # e.g. "Page [%@atlas_featurenumber%] of [%@atlas_totalfeatures%]"
    "subtitle":     "",                # e.g. "COMMERCIAL DRAWING" (shown in the commercial sidebar)
    "created_by":   "",                # e.g. "Johan Scholtz"
    # (scale_note defined once, above, in the title-block group)
    # explicit map layer lists (top-first). None -> HLD group/fallback logic.
    "detail_layers":   None,
    "overview_layers": None,
    # operator hand-picked HLD layers (names, top-first). Set -> use exactly these on the
    # map (overview + detail) AND build the legend from their real symbology.
    "hld_layers":         None,
    "legend_from_symbology": False,
    # extra legend rows for fill/outline swatches (commercial zoning legend):
    "legend_fills":   [],              # [(label, "r,g,b" | layer_name)] -> filled colour box
    "legend_outline": [],              # [(label, "r,g,b")] -> outline-only box (e.g. AOI)
    # manual count tables in the sidebar: [{"title","headers":[...],"rows":[[...]]}]
    "count_tables": [],
    # label the coverage cells on the overview (grid numbers) with this field:
    "coverage_label_field": None,
    "logo_zoom": True,                 # Zoom (keep aspect); commercial logo is wider
}


def _deep_merge(base, over):
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


# caller may inject HLD_CFG in the exec namespace before running this file
CFG = _deep_merge(DEFAULT_CFG, globals().get("HLD_CFG", {}) or {})


def _enum(cls, *names):
    for n in names:
        obj = cls
        try:
            for part in n.split("."):
                obj = getattr(obj, part)
            return obj
        except AttributeError:
            continue
    raise AttributeError(f"none of {names} on {cls}")


MM = _enum(QgsUnitTypes, "LayoutUnit.LayoutMillimeters", "LayoutMillimeters")
LAND = _enum(QgsLayoutItemPage, "Orientation.Landscape", "Landscape")
HTMLMODE = _enum(QgsLayoutItemLabel, "Mode.ModeHtml", "ModeHtml")
ATLAS_AUTO = _enum(QgsLayoutItemMap, "AtlasScalingMode.Auto", "Auto")

p = QgsProject.instance()


def _lyr(name):
    for l in p.mapLayers().values():
        if l.name() == name:
            return l
    return None


# ── schema-agnostic fallback ────────────────────────────────────────────────────────
# When a project doesn't use the exact Fibertime names (PON v1, poles v1, …), find each
# role by GEOMETRY + name keywords instead, so the tool works on ANY project's schema.
_FUZZY_ROLES = {
    "fts":          ("point",   ["fts", "agg"],                                 ["sts"]),
    "sts":          ("point",   ["sts", "splitter"],                            ["fts"]),
    "poles":        ("point",   ["pole"],                                       []),
    "enclosure":    ("point",   ["enclosure", "closure", "joint", "manhole",
                                 "chamber", "handhole"],                        []),
    "enc_splice":   ("point",   ["splice"],                                     []),
    "enc_conn":     ("point",   ["connectoris", "connectoriz"],                 []),
    "ont":          ("point",   ["ont", "home connection", "premise",
                                 "drop point", "customer"],                     []),
    "primary":      ("line",    ["primary", "feeder"],                          ["secondary", "distribution"]),
    "secondary":    ("line",    ["secondary"],                                  ["primary"]),
    "distribution": ("line",    ["distribution", "mini"],                       ["spare"]),
    "drop":         ("line",    ["drop"],                                       ["spare", "distribution"]),
    "spare_drop":   ("line",    ["spare drop", "spare"],                        []),
    "coverage":     ("polygon", ["pon"],                                        ["zone"]),
    "pon_area":     ("polygon", ["pon"],                                        ["zone"]),
    "zones":        ("polygon", ["zone"],                                       []),
}


def _fuzzy_layer(geom, include, exclude=()):
    """First vector layer whose geometry is `geom` and whose name contains an `include`
    keyword and no `exclude` keyword. Prefers a non-empty layer."""
    from qgis.core import QgsVectorLayer
    inc = [s.lower() for s in include]
    exc = [s.lower() for s in exclude]
    fallback = None
    for l in p.mapLayers().values():
        if not isinstance(l, QgsVectorLayer):
            continue
        if geom and _geom_of(l) != geom:
            continue
        nm = l.name().lower()
        if any(x in nm for x in exc) or not any(x in nm for x in inc):
            continue
        try:
            if l.featureCount() > 0:
                return l
        except Exception:
            return l
        fallback = fallback or l
    return fallback


def _aoi_layer():
    """The area-of-interest polygon (greenfield boundary), by name then fuzzy."""
    l = _lyr(CFG["aoi_layer"])
    if l is not None:
        return l
    return _fuzzy_layer("polygon",
                        ["greenfield", "overbuild", "boundary", "aoi", "area of interest", "extent"],
                        ["pon", "zone", "erven", "erf", "building", "grid"])


def _basemap_layer():
    """The basemap raster, by name then any raster in the project."""
    l = _lyr(CFG["basemap"])
    if l is not None:
        return l
    from qgis.core import QgsRasterLayer
    for x in p.mapLayers().values():
        if isinstance(x, QgsRasterLayer):
            return x
    return None


# ---- group resolution (resolve layers within the configured group, not by hard-coded names) ----
def _p2_group():
    root = p.layerTreeRoot()
    want = CFG["group_name"].strip().lower()
    try:
        groups = root.findGroups(True)          # recursive (group may be nested)
    except TypeError:
        groups = []
        def _walk(node):
            for ch in node.children():
                if hasattr(ch, "children") and not hasattr(ch, "layer"):
                    groups.append(ch); _walk(ch)
        _walk(root)
    for g in groups:
        if g.name().strip().lower() == want:
            return g
    return None


def _p2_layer(*names):
    g = _p2_group()
    if g:
        for ch in g.findLayers():
            l = ch.layer()
            if l and l.name() in names:
                return l
    for n in names:
        x = _lyr(n)
        if x:
            return x
    return None


def _best_polygon_coverage():
    """Last-resort per-page coverage when the configured + fuzzy resolution both fail: the
    best polygon layer in the project. Prefers a 'pon' polygon, then a 'zone' polygon (a zone
    layer IS a valid per-page unit — e.g. the Matiko sandbox has ONLY zones), then any
    non-empty polygon. Never a raster/point/line. Stops the atlas crashing on a project whose
    coverage layer the fuzzy rules don't anticipate (they exclude 'zone' to avoid picking a
    zone OVER a pon when both exist — but when only zones exist, a zone is the right pick)."""
    from qgis.core import QgsVectorLayer
    polys = [l for l in p.mapLayers().values()
             if isinstance(l, QgsVectorLayer) and _geom_of(l) == "polygon"]

    def nonempty(l):
        try:
            return l.featureCount() > 0
        except Exception:
            return True
    for want in ("pon", "zone"):
        for l in polys:
            if want in l.name().lower() and nonempty(l):
                return l
    for l in polys:
        if nonempty(l):
            return l
    return None


def _role(role):
    """Resolve a role: exact configured names first (fast path, unchanged for Fibertime),
    then a schema-agnostic fuzzy match by geometry + name so it works on ANY project."""
    names = CFG["roles"].get(role, [])
    l = _p2_layer(*names) if names else None
    if l is not None:
        return l
    spec = _FUZZY_ROLES.get(role)
    l = _fuzzy_layer(*spec) if spec else None
    if l is not None:
        return l
    # last resort for the per-page coverage: any polygon, so the book still builds (never
    # crash on a None coverage). Only fires when nothing else matched -> MOA/Fibertime unchanged.
    if role in ("coverage", "pon_area"):
        return _best_polygon_coverage()
    return None


def _p2_visible_layers(exclude=()):
    from qgis.core import QgsVectorLayer
    g = _p2_group()
    out = []
    if g:
        for ch in g.findLayers():
            l = ch.layer()
            if l and ch.isVisible() and l.name() not in exclude:
                out.append(l)
        if out:
            return out
    # no HLD group (or empty) -> every VISIBLE vector layer in the tree (schema-agnostic)
    for ch in p.layerTreeRoot().findLayers():
        l = ch.layer()
        if isinstance(l, QgsVectorLayer) and ch.isVisible() and l.name() not in exclude:
            out.append(l)
    return out


def _p2_enclosure():
    g = _p2_group()
    if g:
        for ch in g.findLayers():
            l = ch.layer()
            if not l:
                continue
            try:
                if any("Enclosure" in (c.label() or "") for c in l.renderer().categories()):
                    return l
            except Exception:
                pass
    return _role("enclosure")


def find_north_svg():
    from qgis.core import QgsApplication
    for base in QgsApplication.svgPaths():
        for cand in ("arrows/NorthArrow_02.svg", "arrows/NorthArrow_01.svg",
                     "arrows/NorthArrow_04.svg", "arrows/NorthArrow_11.svg"):
            fp = os.path.normpath(os.path.join(base, cand))
            if os.path.exists(fp):
                return fp
    return None


NORTH_SVG = find_north_svg()
LOGO = CFG["logo_path"]


def mmpoint(x, y): return QgsLayoutPoint(x, y, MM)
def mmsize(w, h): return QgsLayoutSize(w, h, MM)


def add_label(layout, x, y, w, h, html=None, text=None, size=9, bold=False,
              align_center=True, valign_center=True, frame=False):
    lbl = QgsLayoutItemLabel(layout)
    if html is not None:
        lbl.setMode(HTMLMODE)
        lbl.setText(html)
    else:
        lbl.setText(text or "")
        f = QFont(); f.setPointSize(size); f.setBold(bold)
        lbl.setFont(f)
    from qgis.PyQt.QtCore import Qt
    hz = _enum(Qt, "AlignmentFlag.AlignHCenter", "AlignHCenter") if align_center else _enum(Qt, "AlignmentFlag.AlignLeft", "AlignLeft")
    vt = _enum(Qt, "AlignmentFlag.AlignVCenter", "AlignVCenter") if valign_center else _enum(Qt, "AlignmentFlag.AlignTop", "AlignTop")
    try: lbl.setHAlign(hz); lbl.setVAlign(vt)
    except Exception: pass
    layout.addLayoutItem(lbl)
    lbl.attemptMove(mmpoint(x, y)); lbl.attemptResize(mmsize(w, h))
    if frame:
        lbl.setFrameEnabled(True); lbl.setFrameStrokeColor(QColor(0, 0, 0))
        lbl.setFrameStrokeWidth(QgsLayoutMeasurement(0.4, MM))
    return lbl


def add_rect(layout, x, y, w, h, stroke_w=0.6):
    RECT = _enum(QgsLayoutItemShape, "Shape.Rectangle", "Rectangle")
    sh = QgsLayoutItemShape(layout)
    try: sh.setShapeType(RECT)
    except Exception: pass
    layout.addLayoutItem(sh)
    sh.attemptMove(mmpoint(x, y)); sh.attemptResize(mmsize(w, h))
    sym = sh.symbol()
    if sym is not None:
        sym.setColor(QColor(255, 255, 255, 0))
        try:
            sl = sym.symbolLayer(0)
            sl.setStrokeColor(QColor(90, 90, 90)); sl.setStrokeWidth(stroke_w)
            sl.setFillColor(QColor(255, 255, 255, 0))
        except Exception: pass
    return sh


def _any_symbol(rndr):
    """A representative QgsSymbol from ANY renderer — single-symbol, categorized,
    rule-based or graduated. `.symbol()` only exists on single-symbol renderers, so
    fall back to `.symbols(context)[0]` which every renderer implements. This is what
    makes the LEGEND colours match the MAP on projects that use categorized styling
    (e.g. Matiko's cables) instead of falling back to a hard-coded default."""
    if rndr is None:
        return None
    try:
        if hasattr(rndr, "symbol") and rndr.symbol() is not None:
            return rndr.symbol()
    except Exception:
        pass
    try:
        from qgis.core import QgsRenderContext
        ss = rndr.symbols(QgsRenderContext())
        return ss[0] if ss else None
    except Exception:
        return None


def _sym_color_name(sym):
    try:
        return sym.color().name() if sym is not None else None
    except Exception:
        return None


def _lyr_color(name, default):
    l = _lyr(name)
    if not l:
        return default
    return _sym_color_name(_any_symbol(l.renderer())) or default


def _role_color(role, default):
    """Colour of the SAME layer the map draws for this role (group-first resolution).
    Using _role() — not a raw whole-project name scan — avoids grabbing a Phase-1
    'Drop Cable' when the map draws the Phase-2 'Drop Cable v1' (legend/map mismatch).
    Works for categorized/rule-based renderers via _any_symbol()."""
    l = _role(role)
    if l is not None:
        c = _sym_color_name(_any_symbol(l.renderer()))
        if c:
            return c
    # last-ditch: any resolvable candidate by name
    for name in CFG["roles"].get(role, []):
        c = _lyr_color(name, None)
        if c:
            return c
    return default


def _render_legend_symbols():
    """Render each point role's ACTUAL symbol to a small PNG so the legend shows the real physical symbols."""
    from qgis.core import QgsSymbolLayerUtils
    from qgis.PyQt.QtCore import QSize
    d = CFG["legend_dir"]
    os.makedirs(d, exist_ok=True)
    out = {}

    def render(sym, name, w=200, h=200, mm=44):
        # render the REAL symbol big + anti-aliased so it FILLS the box (bold, not a tiny
        # marker floating in white). 200px source at ~44mm marker = crisp and prominent.
        if sym is None:
            return
        try:
            s2 = sym.clone()
            try:
                if hasattr(s2, "setSize"):
                    s2.setSize(mm)
            except Exception:
                pass
            pm = QgsSymbolLayerUtils.symbolPreviewPixmap(s2, QSize(w, h))
            path = f"{d}/{name}.png"
            pm.save(path)
            out[name] = path
        except Exception as e:
            print("legend sym err", name, e)

    def rsym(role):
        l = _role(role)
        if not l:
            return None
        r = l.renderer()
        try:
            if hasattr(r, "symbol"):
                s = r.symbol()
                if s is not None:
                    return s
        except Exception:
            pass
        try:
            from qgis.core import QgsRenderContext
            ss = r.symbols(QgsRenderContext())
            return ss[0] if ss else None
        except Exception:
            return None

    def enc(contains):
        l = _p2_enclosure()
        if not l:
            return None
        r = l.renderer()
        if not hasattr(r, "categories"):
            return r.symbol() if hasattr(r, "symbol") else None
        for c in r.categories():
            if contains.lower() in str(c.value()).lower():
                return c.symbol()
        return None

    # points only (rendered big + crisp); lines are drawn as coloured bars in the HTML
    for _label, key in CFG["legend_points"]:
        if key == "enc_splice":
            render(rsym("enc_splice") or enc("splice"), "enc_splice")
        elif key == "enc_conn":
            render(rsym("enc_conn") or enc("connect"), "enc_conn")
        else:
            render(rsym(key), key)
    return out


def _fill_or_color(spec):
    """Resolve a legend fill spec: a layer name (read its fill colour), "r,g,b", or "#hex"."""
    l = _lyr(spec)
    if l is not None:
        try:
            return l.renderer().symbol().color().name()
        except Exception:
            pass
    if "," in str(spec):
        try:
            r, g, b = [int(x) for x in str(spec).split(",")[:3]]
            return f"#{r:02x}{g:02x}{b:02x}"
        except Exception:
            pass
    return spec


def _resolve_layer_list(names):
    """Resolve an explicit layer-name list to layers (group-first, then whole project),
    de-duplicated, preserving order. Used by the commercial model's detail/overview sets."""
    out = []
    seen = set()
    g = _p2_group()
    for n in names:
        l = None
        if g:
            for ch in g.findLayers():
                if ch.layer() and ch.layer().name() == n:
                    l = ch.layer(); break
        if l is None:
            l = _lyr(n)
        if l and l.id() not in seen:
            seen.add(l.id()); out.append(l)
    return out


def _geom_of(layer):
    """point / line / polygon / other for any vector layer (Qt5/6-safe)."""
    from qgis.core import QgsWkbTypes
    try:
        return {0: "point", 1: "line", 2: "polygon"}.get(
            int(QgsWkbTypes.geometryType(layer.wkbType())), "other")
    except Exception:
        return "other"


def _safe_key(s):
    return "".join(ch if ch.isalnum() else "_" for ch in str(s))


def _layer_color(layer, default="#000000"):
    try:
        r = layer.renderer()
        if hasattr(r, "symbol") and r.symbol():
            return r.symbol().color().name()
        from qgis.core import QgsRenderContext
        ss = r.symbols(QgsRenderContext())
        return ss[0].color().name() if ss else default
    except Exception:
        return default


def _poly_swatch(layer):
    """(colour, outline_only) for a polygon legend swatch: use the outline colour when the
    fill is transparent (e.g. a boundary drawn as green outline, not a black box)."""
    try:
        sym = layer.renderer().symbol()
        fill = sym.color()
        if fill.alpha() < 30:                     # transparent fill -> outline layer
            sl = sym.symbolLayer(0)
            oc = sl.strokeColor() if hasattr(sl, "strokeColor") else fill
            if oc is not None and oc.alpha() > 0:
                return oc.name(), True
        return fill.name(), False
    except Exception:
        return "#888888", False


def _render_layer_symbol(layer, key):
    """Render a layer's REAL marker symbol to a small PNG for the legend."""
    from qgis.core import QgsSymbolLayerUtils, QgsRenderContext
    from qgis.PyQt.QtCore import QSize
    d = CFG["legend_dir"]; os.makedirs(d, exist_ok=True)
    try:
        r = layer.renderer()
        sym = r.symbol() if (hasattr(r, "symbol") and r.symbol()) else None
        if sym is None:
            ss = r.symbols(QgsRenderContext()); sym = ss[0] if ss else None
        if sym is None:
            return None
        s2 = sym.clone()
        try:
            if hasattr(s2, "setSize"):
                s2.setSize(44)          # big + crisp, fills the box (was 5.5mm @ 30px -> blurry)
        except Exception:
            pass
        pm = QgsSymbolLayerUtils.symbolPreviewPixmap(s2, QSize(200, 200))
        pth = f"{d}/auto_{key}.png"; pm.save(pth)
        return pth
    except Exception as e:
        print("auto legend sym err", key, e)
        return None


def _friendly_name(layer):
    alias = CFG.get("legend_aliases", {}).get(layer.name())
    if alias:
        return alias
    n = layer.name()
    return n[:-3].strip() if n.lower().endswith(" v1") else n


def _rect_png(key, fill=None, w=44, h=14, outline=None, outline_w=1.4):
    """Render a coloured rectangle (line bar / fill swatch / outline swatch) to a PNG so it
    aligns exactly like the point-symbol images (nested HTML tables don't align)."""
    from qgis.PyQt.QtGui import QImage, QPainter, QColor, QPen, QBrush
    d = CFG["legend_dir"]; os.makedirs(d, exist_ok=True)
    S = 6
    img = QImage(int(w * S), int(h * S), QImage.Format.Format_ARGB32)
    img.fill(0)
    pa = QPainter(img)
    try:
        pa.setRenderHint(_enum(QPainter, "RenderHint.Antialiasing", "Antialiasing"), True)
    except Exception:
        pass
    pa.setBrush(QBrush(QColor(fill) if fill is not None else QColor(0, 0, 0, 0)))
    pa.setPen(QPen(QColor(outline), outline_w * S) if outline else QPen(QColor("#444444"), 0.7 * S))
    m = (outline_w * S) if outline else (0.7 * S)
    pa.drawRect(int(m), int(m), int(w * S - 2 * m), int(h * S - 2 * m))
    pa.end()
    path = os.path.join(d, f"rect_{key}.png"); img.save(path)
    return path


def _legend_rows(map_layers=None):
    """The ordered [(label, swatch_html)] rows: configured rows first (nice names/order),
    then any drawn layer not yet shown (guard rail), then the basemap note."""
    syms = _render_legend_symbols()

    def img(name, w=22, h=22):
        pth = syms.get(name)
        return f"<img src='file:///{pth}' width='{w}' height='{h}'>" if pth else ""

    def bar(key, color):
        p = _rect_png("bar_" + _safe_key(key), color, w=44, h=12)
        return f"<img src='file:///{p}' width='44' height='12'>"

    def swatch(key, color, outline_only=False):
        if outline_only:
            p = _rect_png("sw_" + _safe_key(key), None, w=26, h=15, outline=color, outline_w=1.8)
        else:
            p = _rect_png("sw_" + _safe_key(key), color, w=26, h=15, outline="#444444", outline_w=0.7)
        return f"<img src='file:///{p}' width='26' height='15'>"

    rows = [(lab, img(key)) for lab, key in CFG["legend_points"]]
    for lab, color in CFG.get("legend_outline", []):
        rows.append((lab, swatch(lab, _fill_or_color(color), outline_only=True)))
    for lab, spec in CFG.get("legend_fills", []):
        rows.append((lab, swatch(lab, _fill_or_color(spec))))
    for lab, role, default in CFG["legend_lines"]:
        rows.append((lab, bar(lab, _role_color(role, default))))

    # --- GUARD RAIL: append any DRAWN layer not already represented above ---
    if CFG.get("legend_auto") and map_layers:
        covered = set()
        for role in ("fts", "sts", "enc_splice", "enc_conn", "poles", "enclosure",
                     "primary", "secondary", "distribution", "drop"):
            rl = _role(role)
            if rl is not None:
                covered.add(rl.id())
        bm = _basemap_layer()
        bm_id = bm.id() if bm else None
        for l in map_layers:
            if l is None or l.id() == bm_id or l.id() in covered:
                continue
            covered.add(l.id())
            g = _geom_of(l)
            nm = _friendly_name(l)
            if g == "point":
                pth = _render_layer_symbol(l, _safe_key(l.name()))
                cell = f"<img src='file:///{pth}' width='22' height='22'>" if pth else ""
            elif g == "line":
                cell = bar(nm, _layer_color(l))
            elif g == "polygon":
                col, outline = _poly_swatch(l)
                cell = swatch(nm, col, outline_only=outline)
            else:
                cell = ""
            rows.append((nm, cell))
        note = CFG.get("legend_basemap_note")
        if note and bm_id is not None and any(x is not None and x.id() == bm_id for x in map_layers):
            rows.append((note, ""))
    return rows


def _legend_table(rows, compact=False):
    # QTextDocument ignores <td height>, so force EVEN rows with a fixed-height transparent
    # spacer in every cell — point symbols, bars and swatches then all line up.
    # compact = tighter rows/font so a many-layer legend fits the small wayleave strip.
    from qgis.PyQt.QtGui import QImage
    d = CFG["legend_dir"]; os.makedirs(d, exist_ok=True)
    sp_h = 15 if compact else 28
    font_px = 8 if compact else 9
    hdr_px = 9 if compact else 11
    pad = 2 if compact else 8
    spacer = ""
    try:
        sp = os.path.join(d, f"spacer{sp_h}.png")
        _im = QImage(1, sp_h, QImage.Format.Format_ARGB32); _im.fill(0)   # transparent
        _im.save(sp)
        spacer = f"<img src='file:///{sp}' width='1' height='{sp_h}'>"
    except Exception:
        pass
    trs = "".join(
        f"<tr><td valign='middle'>{spacer}{k}</td>"
        f"<td width='66' align='center' valign='middle'>{spacer}{v}</td></tr>"
        for k, v in rows)
    return (f"<table cellpadding='0' cellspacing='0' width='100%' "
            f"style='font-family:Arial;font-size:{font_px}px;color:#000000'>"
            f"<tr><td colspan='2' align='center' style='font-weight:bold;font-size:{hdr_px}px;"
            f"text-decoration:underline;padding-bottom:{pad}px'>LEGEND</td></tr>{trs}</table>")


def _symbology_legend_rows(layers):
    """Legend rows built PURELY from each drawn layer's REAL QGIS symbology — points render
    the actual marker image, lines a bar of the real colour, polygons a fill/outline swatch.
    Used when the operator hand-picks the HLD layers ('pull the legend from the project')."""
    def bar(key, color):
        pth = _rect_png("bar_" + _safe_key(key), color, w=44, h=12)
        return f"<img src='file:///{pth}' width='44' height='12'>"

    def swatch(key, color, outline_only=False):
        if outline_only:
            pth = _rect_png("sw_" + _safe_key(key), None, w=26, h=15, outline=color, outline_w=1.8)
        else:
            pth = _rect_png("sw_" + _safe_key(key), color, w=26, h=15, outline="#444444", outline_w=0.7)
        return f"<img src='file:///{pth}' width='26' height='15'>"

    rows = []
    bm = _basemap_layer(); bm_id = bm.id() if bm else None
    seen = set()
    for l in (layers or []):
        if l is None or l.id() in seen or (bm_id and l.id() == bm_id):
            continue
        seen.add(l.id())
        g = _geom_of(l); nm = _friendly_name(l)
        if g == "point":
            pth = _render_layer_symbol(l, _safe_key(l.name()))
            cell = f"<img src='file:///{pth}' width='22' height='22'>" if pth else ""
        elif g == "line":
            cell = bar(nm, _layer_color(l))
        elif g == "polygon":
            col, outline = _poly_swatch(l); cell = swatch(nm, col, outline_only=outline)
        else:
            cell = ""
        rows.append((nm, cell))
    note = CFG.get("legend_basemap_note")
    if note and bm_id is not None and any(x is not None and x.id() == bm_id for x in (layers or [])):
        rows.append((note, ""))
    return rows


def build_legend_html(map_layers=None, compact=False):
    if CFG.get("legend_from_symbology"):
        # show EXACTLY the operator-picked layers (not the auto-added grid/AOI/basemap),
        # so the legend is identical on the overview and every detail page.
        layers = _resolve_layer_list(CFG["hld_layers"]) if CFG.get("hld_layers") else map_layers
        return _legend_table(_symbology_legend_rows(layers), compact=compact)
    return _legend_table(_legend_rows(map_layers), compact=compact)


def map_info_html():
    """Scale + projection block for the sidebar (matches the reference)."""
    rows = [("Scale", CFG.get("scale_note", "As-Shown (A3)")),
            ("Projection", CFG.get("projection_note", "EPSG:4326 · WGS 84"))]
    trs = "".join(f"<tr><td style='font-weight:bold' width='42%'>{k}:</td><td>{v}</td></tr>"
                  for k, v in rows)
    return (f"<table cellpadding='3' cellspacing='0' width='100%' "
            f"style='font-family:Arial;font-size:10px;color:#000000'>{trs}</table>")


def _summary_rows():
    rows = []
    for lab, role in CFG.get("summary_roles", []):
        l = _role(role)
        if l is None:
            continue
        try:
            rows.append((lab, f"{l.featureCount():,}"))
        except Exception:
            continue
    return rows


def summary_html():
    """Project feature-count summary (fills the empty sidebar band with real detail)."""
    rows = _summary_rows()
    if not rows:
        return ""
    body = "".join(f"<tr><td>{k}</td><td align='right' style='font-weight:bold'>{v}</td></tr>"
                   for k, v in rows)
    return (f"<table cellpadding='3' cellspacing='0' border='1' width='100%' "
            f"style='font-family:Arial;font-size:9px;color:#000000'>"
            f"<tr><td colspan='2' align='center' style='font-weight:bold;font-size:10px;"
            f"text-decoration:underline'>{CFG.get('summary_title', 'PROJECT TOTALS')}</td></tr>{body}</table>")


def _zone_summary_label(layout, w):
    """Atlas-driven per-page stats box: a REAL QgsLayoutItemLabel (not a baked image),
    so [% attribute(@atlas_feature,'stat_*') %] re-evaluates for each atlas page — the
    overview shows PROJECT TOTALS, every detail page shows that zone's own numbers."""
    from qgis.core import QgsLayoutItemLabel
    lbl = QgsLayoutItemLabel(layout)
    lbl.setMode(_enum(QgsLayoutItemLabel, "Mode.ModeHtml", "ModeHtml"))
    a = "attribute(@atlas_feature,"
    row = "<tr><td>%s</td><td align='right' style='font-weight:bold'>[%% %s%s) %%]</td></tr>"
    body = "".join(row % (lab, a, fld) for lab, fld in (
        ("Homes / Units", "'stat_units'"), ("Splitters", "'stat_spl'"),
        ("Drop cables", "'stat_drops'"), ("Poles", "'stat_poles'"),
        ("Distribution (m)", "'stat_distm'")))
    lbl.setText(
        "<div style='font-family:Arial;color:#000;font-size:9px'>"
        "<div style='text-align:center;font-weight:bold;font-size:11px;"
        "text-decoration:underline'>[% " + a + "'stat_name') %]</div>"
        "<table width='100%' cellspacing='0' cellpadding='3' border='1' "
        "style='border-collapse:collapse;font-size:9px'>" + body + "</table></div>")
    layout.addLayoutItem(lbl)
    lbl.attemptResize(mmsize(w, 42.0))
    return lbl, 42.0


def count_tables_html():
    """Manual count tables (commercial model) → stacked HTML tables for the sidebar."""
    tables = CFG.get("count_tables") or []
    out = []
    for t in tables:
        headers = t.get("headers", [])
        span = max(1, len(headers))
        hdr = "".join(f"<td style='font-weight:bold'>{h}</td>" for h in headers)
        body = ""
        for row in t.get("rows", []):
            body += "<tr>" + "".join(f"<td>{c}</td>" for c in row) + "</tr>"
        out.append(
            f"<table cellpadding='2' cellspacing='0' border='1' width='100%' "
            f"style='font-family:Arial;font-size:7px'>"
            f"<tr><td colspan='{span}' align='center' style='font-weight:bold;"
            f"text-decoration:underline'>{t.get('title', '')}</td></tr>"
            f"<tr>{hdr}</tr>{body}</table>")
    return "<br>".join(out)


def titleblock_html():
    base = [("Project", CFG["project_name"]), ("Company", CFG["company"]),
            ("Designer", CFG["designer"]), ("Date", CFG["date_str"]), ("Revision", CFG["revision"])]

    def tbl(rows, fs=12):
        trs = "".join(f"<tr><td style='font-weight:bold' width='42%'>{k}:</td>"
                      f"<td align='center'>{v}</td></tr>" for k, v in rows)
        return (f"<table cellpadding='4' cellspacing='0' border='1' width='100%' "
                f"style='font-family:Arial;font-size:{fs}px'>{trs}</table>")

    if not CFG.get("iso_title_block"):
        return tbl(base)                                   # simple block — MOA unchanged
    # ISO 7200-style: identity (+ Scale/Datum/Sheet) + revision history + sign-off.
    # Sheet is a per-page atlas expression (add_label evaluates [% ... %] in HTML mode).
    ident = base + [("Scale", CFG.get("scale_note", "As-Shown (A3)")),
                    ("Datum / CRS", CFG.get("projection_note", "EPSG:4326 · WGS 84")),
                    ("Sheet", "[% @atlas_featurenumber %] of [% @atlas_totalfeatures %]")]
    out = tbl(ident, fs=10)
    rev = CFG.get("revision_rows") or []
    if rev:
        head = ("<tr><td style='font-weight:bold'>Rev</td><td style='font-weight:bold'>Date</td>"
                "<td style='font-weight:bold'>Description</td><td style='font-weight:bold'>By</td></tr>")
        body = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in (list(r) + ['', '', '', ''])[:4])
                       + "</tr>" for r in rev[:5])
        out += ("<table cellpadding='2' cellspacing='0' border='1' width='100%' "
                "style='font-family:Arial;font-size:8px;margin-top:2px'>"
                "<tr><td colspan='4' align='center' style='font-weight:bold'>REVISION HISTORY</td></tr>"
                + head + body + "</table>")
    signoff = "".join(f"<tr><td style='font-weight:bold' width='34%'>{r}:</td><td>&nbsp;</td></tr>"
                      for r in (CFG.get("signoff") or ["Designed", "Reviewed", "Approved"]))
    out += ("<table cellpadding='3' cellspacing='0' border='1' width='100%' "
            "style='font-family:Arial;font-size:9px;margin-top:2px'>" + signoff + "</table>")
    return out


def build_frame_commercial(layout, title_text, map_layers=None):
    """Commercial-drawing frame: full-height map (no title bar) + a stacked sidebar
    (project / COMMERCIAL DRAWING / page / created-by · LEGEND · count tables · scale · logo)."""
    MAP = dict(x=6, y=6, w=322, h=285)      # full-height map, no title bar over it
    SB_X, SB_W = 334, 80
    add_rect(layout, 3, 3, 414, 291, stroke_w=1.0)                 # outer border
    add_rect(layout, MAP["x"], MAP["y"], MAP["w"], MAP["h"], stroke_w=0.6)  # map border
    # ── title block (stacked, centred) ──
    head = ("<div style='font-family:Arial;text-align:center'>"
            f"<div style='font-size:12px;font-weight:bold'>{CFG['project_name']}</div>"
            f"<div style='font-size:11px;font-weight:bold'>{CFG.get('subtitle', '')}</div>"
            f"<div style='font-size:9px;font-weight:bold;border:1px solid #000;"
            f"margin:2px 12px;padding:1px'>{title_text}</div>"
            + (f"<div style='font-size:8px'>Created by {CFG['created_by']}</div>"
               if CFG.get("created_by") else "")
            + "</div>")
    add_label(layout, SB_X, 5, SB_W, 26, html=head)
    # ── legend ──
    add_label(layout, SB_X, 33, SB_W, 46, html=build_legend_html(map_layers), frame=True)
    # ── count tables ──
    ct = count_tables_html()
    if ct:
        add_label(layout, SB_X, 81, SB_W, 168, html=ct, align_center=True, valign_center=False)
    # ── scale note ──
    add_label(layout, SB_X, 251, SB_W, 8,
              text=f"Scale: {CFG.get('scale_note', 'As-Shown (A3)')}", size=8, bold=True)
    # ── logo (wide) at the bottom ──
    if os.path.exists(LOGO):
        logo = QgsLayoutItemPicture(layout)
        logo.setPicturePath(LOGO)
        logo.setResizeMode(_enum(QgsLayoutItemPicture, "ResizeMode.Zoom", "Zoom"))
        layout.addLayoutItem(logo)
        logo.attemptMove(mmpoint(SB_X + 6, 262)); logo.attemptResize(mmsize(68, 28))
    return MAP


def _wayleave_icon(kind):
    """Draw one fixed legend icon (Cambridge wayleave style) to a PNG:
    poles = hollow circle · span = red bar · erven = black rectangle · pop = orange star."""
    from qgis.PyQt.QtGui import QImage, QPainter, QColor, QPen, QBrush, QPolygonF
    from qgis.PyQt.QtCore import QPointF
    import math
    d = CFG["legend_dir"]; os.makedirs(d, exist_ok=True)
    S = 8
    w = h = 24
    img = QImage(w * S, h * S, QImage.Format.Format_ARGB32); img.fill(0)
    pa = QPainter(img)
    try:
        pa.setRenderHint(_enum(QPainter, "RenderHint.Antialiasing", "Antialiasing"), True)
    except Exception:
        pass
    cx, cy = w * S / 2.0, h * S / 2.0
    if kind == "poles":
        pa.setPen(QPen(QColor(0, 0, 0), 2 * S)); pa.setBrush(QBrush(QColor(255, 255, 255)))
        r = 6 * S; pa.drawEllipse(int(cx - r), int(cy - r), int(2 * r), int(2 * r))
    elif kind == "span":
        pa.setPen(QPen(QColor(225, 29, 29), 5 * S))
        pa.drawLine(int(2 * S), int(cy), int((w - 2) * S), int(cy))
    elif kind == "erven":
        pa.setPen(QPen(QColor(0, 0, 0), 2 * S)); pa.setBrush(QBrush(QColor(0, 0, 0, 0)))
        pa.drawRect(int(3 * S), int(7 * S), int((w - 6) * S), int((h - 14) * S))
    elif kind == "pop":
        pa.setPen(QPen(QColor(180, 90, 0), 1)); pa.setBrush(QBrush(QColor(245, 166, 35)))
        pts = []
        for i in range(10):
            ang = math.pi / 2 + i * math.pi / 5
            rr = (9 * S) if i % 2 == 0 else (3.8 * S)
            pts.append(QPointF(cx + rr * math.cos(ang), cy - rr * math.sin(ang)))
        pa.drawPolygon(QPolygonF(pts))
    pa.end()
    path = os.path.join(d, f"wl_{kind}.png"); img.save(path)
    return path


def _wl_text(layout, x, y, w, h, text, size=9, bold=False, left=False, top=False,
             frame=False, bg=False, z=None):
    """A NATIVE plain-text layout label (NOT HTML) — individually selectable + editable in
    the designer. [% … %] expressions still evaluate in text mode."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtGui import QFont
    lbl = QgsLayoutItemLabel(layout)
    lbl.setText(text or "")
    f = QFont("Arial"); f.setPointSize(size); f.setBold(bold); lbl.setFont(f)
    hz = (_enum(Qt, "AlignmentFlag.AlignLeft", "AlignLeft") if left
          else _enum(Qt, "AlignmentFlag.AlignHCenter", "AlignHCenter"))
    vt = (_enum(Qt, "AlignmentFlag.AlignTop", "AlignTop") if top
          else _enum(Qt, "AlignmentFlag.AlignVCenter", "AlignVCenter"))
    try:
        lbl.setHAlign(hz); lbl.setVAlign(vt)
    except Exception:
        pass
    layout.addLayoutItem(lbl)
    lbl.attemptMove(mmpoint(x, y)); lbl.attemptResize(mmsize(w, h))
    if frame:
        lbl.setFrameEnabled(True); lbl.setFrameStrokeColor(QColor(0, 0, 0))
        lbl.setFrameStrokeWidth(QgsLayoutMeasurement(0.4, MM))
    if bg:
        try:
            lbl.setBackgroundEnabled(True); lbl.setBackgroundColor(QColor(255, 255, 255))
        except Exception:
            pass
    if z is not None:
        lbl.setZValue(z)
    return lbl


def _wl_pic(layout, x, y, w, h, path, z=None):
    """A native Picture item (logo / north / legend icon)."""
    if not path or not os.path.exists(path):
        return None
    pic = QgsLayoutItemPicture(layout)
    pic.setPicturePath(path)
    pic.setResizeMode(_enum(QgsLayoutItemPicture, "ResizeMode.Zoom", "Zoom"))
    layout.addLayoutItem(pic)
    pic.attemptMove(mmpoint(x, y)); pic.attemptResize(mmsize(w, h))
    if z is not None:
        pic.setZValue(z)
    return pic


def _wl_legend_items(map_layers):
    """[(label, icon_png_path)] for the wayleave legend — from the picked layers' REAL
    symbology when the operator chose layers, else the fixed Poles/Span/Erven/POP icons."""
    if CFG.get("legend_from_symbology"):
        layers = _resolve_layer_list(CFG["hld_layers"]) if CFG.get("hld_layers") else (map_layers or [])
        bm = _basemap_layer(); bm_id = bm.id() if bm else None
        out = []; seen = set()
        for l in layers:
            if l is None or l.id() in seen or (bm_id and l.id() == bm_id):
                continue
            seen.add(l.id())
            g = _geom_of(l); nm = _friendly_name(l)
            if g == "point":
                png = _render_layer_symbol(l, _safe_key(l.name()))
            elif g == "line":
                png = _rect_png("bar_" + _safe_key(nm), _layer_color(l), w=44, h=10)
            elif g == "polygon":
                col, outline = _poly_swatch(l)
                png = (_rect_png("sw_" + _safe_key(nm), None, w=26, h=14, outline=col, outline_w=1.6)
                       if outline else
                       _rect_png("sw_" + _safe_key(nm), col, w=26, h=14, outline="#444444", outline_w=0.7))
            else:
                png = None
            out.append((nm, png))
        return out
    return [("Poles", _wayleave_icon("poles")), ("Span", _wayleave_icon("span")),
            ("Erven", _wayleave_icon("erven")), ("POP", _wayleave_icon("pop"))]


def build_frame_wayleave(layout, title_text, map_layers=None):
    """Cambridge wayleave frame (A4 landscape), built from NATIVE layout items ONLY — no
    HTML anywhere. Every piece (title, page number, description, each legend row, each
    title-block cell, logo) is an individually selectable + editable text / rectangle /
    picture item. Full-bleed map + bottom strip (Description · legend · Date/Scale/Project ·
    logo). Used inside the unified single-layout book (overview = page 1, then tiles)."""
    PAGE_W, PAGE_H = 297.0, 210.0
    STRIP_H = 34.0
    strip_y = PAGE_H - 3.0 - STRIP_H
    MAP = dict(x=4, y=4, w=PAGE_W - 8, h=strip_y - 4 - 1)
    ZTOP = 900.0                                       # keep frame items above the later map
    add_rect(layout, 3, 3, PAGE_W - 6, PAGE_H - 6, stroke_w=1.0)                 # outer border
    add_rect(layout, MAP["x"], MAP["y"], MAP["w"], MAP["h"], stroke_w=0.6)       # map border

    # ── title (expression -> "Wayleave Application" on the overview, blank on tiles) ──
    if title_text:
        _wl_text(layout, (PAGE_W - 180) / 2.0, 5, 180, 12, title_text, size=15, bold=True, z=ZTOP)

    # ── north arrow ──
    _wl_pic(layout, PAGE_W - 22, 8, 13, 13, NORTH_SVG, z=ZTOP)

    # ── page-number corner (expression) — native bordered white box ──
    corner = CFG.get("page_label_expr") or ""
    if corner:
        _wl_text(layout, PAGE_W - 3 - 46, strip_y - 10, 46, 9, corner,
                 size=10, bold=True, frame=True, bg=True, z=ZTOP)

    # ── bottom strip dividers ──
    x_desc, x_leg, x_info, x_logo, x_end = 4.0, 156.0, 200.0, 254.0, PAGE_W - 3.0
    for xd in (x_leg, x_info, x_logo):
        add_rect(layout, xd, strip_y, 0.0, STRIP_H, stroke_w=0.6)

    # ── Project Description (native heading + body text) ──
    _wl_text(layout, x_desc + 2, strip_y + 1.5, x_leg - x_desc - 4, 6,
             "Project Description:", size=9, bold=True, left=True, top=True)
    _wl_text(layout, x_desc + 2, strip_y + 8, x_leg - x_desc - 4, STRIP_H - 10,
             str(CFG.get("wayleave_desc", "")), size=8, left=True, top=True)

    # ── Legend (native header + one picture + one text per row) ──
    _wl_text(layout, x_leg, strip_y + 1.0, x_info - x_leg, 5, "LEGEND", size=8, bold=True)
    items = _wl_legend_items(map_layers)
    row_h = min(6.0, (STRIP_H - 7.5) / max(1, len(items)))
    icon_w = 12.0
    ry = strip_y + 6.5
    for lab, png in items:
        _wl_pic(layout, x_info - icon_w - 2, ry + 0.5, icon_w, max(2.5, row_h - 1), png)
        _wl_text(layout, x_leg + 2, ry, (x_info - x_leg) - icon_w - 5, row_h, lab,
                 size=7, left=True)
        ry += row_h

    # ── Title block: Date / Scale / Project as native boxed rows ──
    info_rows = [("Date", str(CFG.get("date_str", ""))),
                 ("Scale", str(CFG.get("wayleave_scale_note", "NTS"))),
                 ("Project", str(CFG.get("project_name", "")))]
    bh = STRIP_H / 3.0
    key_w = (x_logo - x_info) * 0.36
    for i, (k, val) in enumerate(info_rows):
        yy = strip_y + i * bh
        add_rect(layout, x_info, yy, key_w, bh, stroke_w=0.5)
        add_rect(layout, x_info + key_w, yy, (x_logo - x_info) - key_w, bh, stroke_w=0.5)
        _wl_text(layout, x_info + 1.5, yy, key_w - 2, bh, k + ":", size=9, bold=True, left=True)
        _wl_text(layout, x_info + key_w + 1, yy, (x_logo - x_info) - key_w - 2, bh, val, size=9)

    # ── logo ──
    _wl_pic(layout, x_logo + 3, strip_y + 4, x_end - x_logo - 6, STRIP_H - 8, LOGO)
    return MAP


def _html_panel(layout, html, x, y, w, key, frame=False):
    """Render an HTML fragment to a PNG (via QTextDocument) and place it as a Picture at
    the EXACT height of its content. Bulletproof vs QGIS's HTML-label height quirks:
    the picture is a fixed image, so it can never overflow into a neighbour, and it
    looks identical in the live designer and the headless export. Returns (item, h_mm)."""
    from qgis.PyQt.QtGui import QTextDocument, QImage, QPainter, QColor
    d = CFG["legend_dir"]; os.makedirs(d, exist_ok=True)
    base, scale = 96.0, 5.0                       # 96-dpi CSS px; 5x = ~480dpi, crisp even zoomed
    px_w = max(10, int(round(w / 25.4 * base)))
    doc = QTextDocument(); doc.setHtml(html); doc.setTextWidth(px_w)
    px_h = max(10, int(round(doc.size().height())))
    img = QImage(int(px_w * scale), int(px_h * scale), QImage.Format.Format_ARGB32)
    img.fill(QColor(255, 255, 255))
    pa = QPainter(img)
    try:
        pa.setRenderHint(_enum(QPainter, "RenderHint.Antialiasing", "Antialiasing"), True)
        pa.setRenderHint(_enum(QPainter, "RenderHint.TextAntialiasing", "TextAntialiasing"), True)
    except Exception:
        pass
    pa.setPen(QColor(0, 0, 0))
    pa.scale(scale, scale)
    doc.drawContents(pa)
    pa.end()
    path = os.path.join(d, f"panel_{key}.png"); img.save(path)
    h_mm = px_h / base * 25.4
    pic = QgsLayoutItemPicture(layout)
    pic.setPicturePath(path)
    pic.setResizeMode(_enum(QgsLayoutItemPicture, "ResizeMode.Stretch", "Stretch"))
    layout.addLayoutItem(pic)
    pic.attemptMove(mmpoint(x, y)); pic.attemptResize(mmsize(w, h_mm))
    if frame:
        pic.setFrameEnabled(True)
        pic.setFrameStrokeColor(QColor(0, 0, 0))
        pic.setFrameStrokeWidth(QgsLayoutMeasurement(0.4, MM))
    return pic, h_mm


def _exclude_on_overview(item):
    """Data-defined: keep this layout item OUT of the exported overview page (is_overview=1),
    so a per-page table/title only appears on the detail pages (re-evaluates per atlas page)."""
    from qgis.core import QgsLayoutObject, QgsProperty
    try:
        item.dataDefinedProperties().setProperty(
            QgsLayoutObject.DataDefinedProperty.ExcludeFromExports,
            QgsProperty.fromExpression("attribute(@atlas_feature,'is_overview')=1"))
    except Exception:
        pass


def _auto_table_columns(fields):
    """Pick sensible cable-schedule columns from whatever fields the layer actually has
    (schema-agnostic; tolerates the 'Lenght' misspelling in the Matiko data)."""
    low = {f.lower(): f for f in fields}
    picks = []

    def add(cands, head):
        for c in cands:
            if c in low:
                picks.append((low[c], head))
                return
    add(["cable_id", "id", "name", "cab name", "label"], "ID")
    add(["type", "tier", "size", "cable_type", "fiber_size"], "Type")
    add(["lenght", "length", "cable_leng", "len_m", "dim2"], "Length")
    if not picks and fields:
        picks = [(fields[0], fields[0])]
    return picks


def _add_per_page_table(layout, x, y, w, h):
    """P3.3: native per-page cable schedule — an attribute table on the configured cable role,
    filtered to the current atlas feature, row-capped, hidden on the overview page. Editable
    in the designer. Returns the frame (or None if the role can't be resolved)."""
    from qgis.core import (QgsLayoutItemAttributeTable, QgsLayoutFrame, QgsLayoutTableColumn)
    from qgis.PyQt.QtGui import QFont
    lyr = _role(CFG.get("table_role", "distribution"))
    if lyr is None:
        return None
    t = QgsLayoutItemAttributeTable.create(layout)
    layout.addMultiFrame(t)
    t.setVectorLayer(lyr)
    for setter, arg in (("setFilterToAtlasFeature", True),
                        ("setMaximumNumberOfFeatures", int(CFG.get("table_max_rows", 40))),
                        ("setDisplayOnlyVisibleFeatures", False),
                        ("setShowEmptyRows", False)):
        try:
            getattr(t, setter)(arg)
        except Exception:
            pass
    fields = [f.name() for f in lyr.fields()]
    spec_cols = CFG.get("table_columns") or _auto_table_columns(fields)
    cols = []
    for spec in spec_cols:
        fld, head = (spec if isinstance(spec, (list, tuple)) else (spec, spec))
        if fld in fields:
            c = QgsLayoutTableColumn()
            c.setAttribute(fld)
            c.setHeading(head)
            cols.append(c)
    if cols:
        try:
            t.setColumns(cols)
        except Exception:
            pass
    cf = QFont("Arial"); cf.setPointSize(6)
    hf = QFont("Arial"); hf.setPointSize(6); hf.setBold(True)
    try:
        t.setContentFont(cf); t.setHeaderFont(hf)
    except Exception:
        pass
    frame = QgsLayoutFrame(layout, t)
    frame.attemptMove(mmpoint(x, y)); frame.attemptResize(mmsize(w, h))
    frame.setFrameEnabled(True)
    frame.setFrameStrokeColor(QColor(0, 0, 0))
    frame.setFrameStrokeWidth(QgsLayoutMeasurement(0.4, MM))
    t.addFrame(frame)
    _exclude_on_overview(frame)      # no table on the whole-AOI overview page
    return frame


def _place_per_page_table(layout, x, y, w, box_h):
    """Title label + the schedule table stacked in a reserved sidebar box; both hidden on
    the overview page. Called from the band-distribution loop with the resolved y."""
    title = CFG.get("table_title", "CABLE SCHEDULE")
    th = 5.0
    lbl = add_label(
        layout, x, y, w, th,
        html=("<div style='font-family:Arial;font-size:9px;font-weight:bold;"
              "text-decoration:underline;text-align:center'>%s</div>" % title))
    _exclude_on_overview(lbl)
    _add_per_page_table(layout, x, y + th, w, max(8.0, box_h - th))


def _distribute_sidebar(items, top, bottom):
    """Place sidebar items top->bottom, GUARANTEEING every item stays within
    [top, bottom] with no overlap — so the last item can never cross the bottom-anchored
    title block. Even gaps when there's room; when the band is tight, gaps collapse to a
    minimum and the FLEXIBLE items (north arrow, logo) shrink toward their floor until
    everything fits. Deterministic — identical on every page. items = list of mutable
    [reserve_h, place_fn(y, h), flex(bool), floor_h]."""
    MIN_GAP = 3.0                          # matches the historical floor (keeps MOA identical)
    avail = bottom - top

    def tight():
        return sum(it[0] for it in items) + MIN_GAP * (len(items) + 1)

    # Only engage the NEW safety behaviour when the content would otherwise overflow the band:
    # shrink the flexible items (north/logo) toward their floor until it fits. When everything
    # already fits, fall through to the ORIGINAL even-gap formula below -> byte-identical output.
    guard = 0
    while tight() > avail and guard < 600:
        guard += 1
        flex = [it for it in items if it[2] and it[0] > it[3] + 0.05]
        if not flex:
            break                          # only fixed panels left -> can't shrink further
        tallest = max(flex, key=lambda it: it[0])
        tallest[0] = max(tallest[3], tallest[0] - 1.0)
    total = sum(it[0] for it in items)
    gap = max(MIN_GAP, (avail - total) / (len(items) + 1))   # original formula (no upper cap)
    y = top + gap
    for h, place, _flex, _floor in items:
        place(y, h)
        y += h + gap


def build_frame(layout, title_text, map_layers=None):
    if CFG.get("frame_style") == "wayleave":
        return build_frame_wayleave(layout, title_text, map_layers)
    if CFG.get("frame_style") == "commercial":
        return build_frame_commercial(layout, title_text, map_layers)
    # geometry (mm) for A3 landscape 420x297
    MAP = dict(x=6, y=28, w=322, h=263)
    SB_W = 80.0
    # centre the sidebar in the white band between the map's right edge and the border
    _white_l = MAP["x"] + MAP["w"]      # 328
    _white_r = 417.0                    # inner border right
    SB_X = round(_white_l + (_white_r - _white_l - SB_W) / 2.0, 1)   # 332.5
    PAGE_H = 297.0
    add_rect(layout, 3, 3, 414, 291, stroke_w=1.0)          # outer border
    # title bar
    add_rect(layout, MAP["x"], 6, MAP["w"], 18, stroke_w=0.8)
    add_label(layout, MAP["x"], 6, MAP["w"], 18,
              html=f"<div style='font-family:Arial;font-size:19px;font-weight:bold;text-decoration:underline'>{title_text}</div>")

    # ── legend — pre-rendered image at its exact content height (never overflows) ──
    if CFG.get("legend_from_symbology"):
        _picked = _resolve_layer_list(CFG["hld_layers"]) if CFG.get("hld_layers") else map_layers
        leg_rows = _symbology_legend_rows(_picked)
    else:
        leg_rows = _legend_rows(map_layers)
    _compact = bool(CFG.get("legend_compact"))
    _leg, h_leg = _html_panel(layout, _legend_table(leg_rows, compact=_compact),
                              SB_X, 6, SB_W, "legend", frame=True)
    # ADAPTIVE: a many-layer legend can grow tall enough to crowd the sidebar. If a normal
    # legend exceeds its height budget, re-render it COMPACT so the middle band keeps room
    # for north/logo. Short legends (e.g. MOA/Fibertime) stay under budget -> untouched.
    _leg_budget = float(CFG.get("legend_max_h", 82.0))
    if not _compact and h_leg > _leg_budget:
        layout.removeLayoutItem(_leg)
        _leg, h_leg = _html_panel(layout, _legend_table(leg_rows, compact=True),
                                  SB_X, 6, SB_W, "legend", frame=True)
        print("legend auto-compacted: %.1fmm -> %.1fmm (%d rows)" % (_leg_budget, h_leg, len(leg_rows)))

    # ── title block — HTML label with a generous fixed box (few rows), bottom-anchored ──
    h_title = 76.0 if CFG.get("iso_title_block") else 46.0   # ISO block has more rows
    title_y = PAGE_H - 3.0 - h_title
    add_label(layout, SB_X, title_y, SB_W, h_title, html=titleblock_html(), valign_center=False)

    # ── middle blocks: build them (measured), then distribute evenly in the free band ──
    band_top = 6.0 + h_leg

    def _place_north(y, h=31.0):
        arrow = max(12.0, min(24.0, h - 7.0))       # arrow scales with the reserved box
        if NORTH_SVG:
            pic = QgsLayoutItemPicture(layout)
            pic.setPicturePath(NORTH_SVG)
            layout.addLayoutItem(pic)
            pic.attemptMove(mmpoint(SB_X + (SB_W - arrow) / 2.0, y))
            pic.attemptResize(mmsize(arrow, arrow))
        add_label(layout, SB_X, y + arrow, SB_W, 7, text="N", size=11, bold=True)

    def _place_logo(y, h=28.0):
        if os.path.exists(LOGO):
            lw = min(SB_W, h * (48.0 / 28.0))        # keep the 48x28 aspect while scaling
            logo = QgsLayoutItemPicture(layout)
            logo.setPicturePath(LOGO)
            logo.setResizeMode(_enum(QgsLayoutItemPicture, "ResizeMode.Zoom", "Zoom"))
            layout.addLayoutItem(logo)
            logo.attemptMove(mmpoint(SB_X + (SB_W - lw) / 2.0, y))
            logo.attemptResize(mmsize(lw, h))

    # middle band items, top->bottom: [reserve_h, place_fn(y,h), flexible, floor_h].
    # summary/tables are FIXED (pre-rendered); north + logo are FLEXIBLE (can shrink to fit).
    items = []
    if CFG.get("show_summary"):
        if CFG.get("per_page_summary"):
            sm, h_sm = _zone_summary_label(layout, SB_W)
            items.append([h_sm, lambda y, h, it=sm: it.attemptMove(mmpoint(SB_X, y)), False, h_sm])
        else:
            sm_html = summary_html()
            if sm_html:
                sm, h_sm = _html_panel(layout, sm_html, SB_X, band_top, SB_W, "summary")
                items.append([h_sm, lambda y, h, it=sm: it.attemptMove(mmpoint(SB_X, y)), False, h_sm])
    # the ISO title block already carries Scale + Datum/CRS → skip the redundant map-info panel
    if CFG.get("show_map_info") and not CFG.get("iso_title_block"):
        mi, h_mi = _html_panel(layout, map_info_html(), SB_X, band_top, SB_W, "mapinfo", frame=True)
        items.append([h_mi, lambda y, h, it=mi: it.attemptMove(mmpoint(SB_X, y)), False, h_mi])
    # ── P3.3: per-page cable schedule (config-gated) — reserve a box in the sidebar band ──
    if CFG.get("per_page_table"):
        _box = float(CFG.get("table_box_h", 58.0))
        items.append([_box, lambda y, h: _place_per_page_table(layout, SB_X, y, SB_W, h), False, _box])
    items.append([31.0, _place_north, True, 20.0])
    items.append([28.0, _place_logo, True, 16.0])

    # guaranteed-fit distribution: nothing ever crosses the title block (title_y)
    _distribute_sidebar(items, band_top, title_y)
    return MAP


def make_map(layout, MAP, layers, extent=None, atlas_driven=False, margin=0.10):
    m = QgsLayoutItemMap(layout)
    m.setId("mainmap")
    layout.addLayoutItem(m)
    m.attemptMove(mmpoint(MAP["x"], MAP["y"])); m.attemptResize(mmsize(MAP["w"], MAP["h"]))
    m.setLayers(layers)
    m.setFrameEnabled(True); m.setFrameStrokeWidth(QgsLayoutMeasurement(0.4, MM))
    m.setBackgroundColor(QColor(255, 255, 255))
    # NOTE: QGIS4 setExtent() RESIZES the item to the extent's aspect. For a fixed page
    # frame we must only ever hand it an extent that already matches the item aspect.
    if extent is not None and not atlas_driven:
        m.setExtent(extent)                        # overview: caller pre-fit to item aspect
    if atlas_driven:
        # Atlas "Auto" sets the per-feature extent itself (fitting it INSIDE this frame),
        # so we do NOT setExtent() here — that would resize the frame off the page.
        m.setAtlasDriven(True)
        m.setAtlasScalingMode(ATLAS_AUTO)
        m.setAtlasMargin(margin)
    # lock the frame to the page-fitting size (belt-and-suspenders vs any resize)
    m.attemptMove(mmpoint(MAP["x"], MAP["y"])); m.attemptResize(mmsize(MAP["w"], MAP["h"]))
    # remember the designed frame so the page-view atlas can RE-lock after preview resizes it
    # (QGIS4 atlas preview grows the frame to the first feature's aspect once; re-locking
    # once makes it hold across all features — verified).
    try:
        m.setCustomProperty("hld_frame_x", float(MAP["x"]))
        m.setCustomProperty("hld_frame_y", float(MAP["y"]))
        m.setCustomProperty("hld_frame_w", float(MAP["w"]))
        m.setCustomProperty("hld_frame_h", float(MAP["h"]))
    except Exception:
        pass
    return m


def remove_layout(name):
    lm = p.layoutManager()
    ex = lm.layoutByName(name)
    if ex is not None:
        lm.removeLayout(ex)


def new_layout(name):
    remove_layout(name)
    layout = QgsPrintLayout(p)
    layout.initializeDefaults()
    layout.setName(name)
    pc = layout.pageCollection()
    pg = pc.page(0)
    pg.setPageSize(CFG.get("page_size", "A3"), LAND)
    return layout


def _restore_aoi():
    aoi = _aoi_layer()
    if aoi is not None:
        try:
            aoi.setOpacity(1.0)
            if CFG.get("aoi_subset"):
                aoi.setSubsetString(CFG["aoi_subset"])
            aoi.triggerRepaint()
        except Exception:
            pass
    return aoi


def _aoi_filter_greenfield(aoi):
    """True only when this AOI layer distinguishes 'Greenfield' rows AND no subset is
    already applied. Mohadin's boundary carries Greenfield + Overbuild polygons (filter to
    Greenfield); a generic client boundary has no such row -> use the whole layer."""
    if aoi.subsetString():
        return False, None
    nmf = next((f.name() for f in aoi.fields() if f.name().lower() == "name"), None)
    if not nmf:
        return False, None
    try:
        has_gf = any("greenfield" in str(f[nmf]).lower() for f in aoi.getFeatures())
    except Exception:
        has_gf = False
    return has_gf, nmf


def _greenfield_extent():
    aoi = _aoi_layer()
    if aoi is None:
        return None
    filter_gf, nmf = _aoi_filter_greenfield(aoi)
    ext = QgsRectangle(); ext.setMinimal(); n = 0
    for f in aoi.getFeatures():
        if filter_gf and "greenfield" not in str(f[nmf]).lower():
            continue
        g = f.geometry()
        if g and not g.isEmpty():
            ext.combineExtentWith(g.boundingBox()); n += 1
    return ext if n else None


def _aoi_geometry():
    """Union polygon of the AOI (greenfield) features; returns (geometry, crs) or (None, None).
    Honours aoi_subset (already applied by _restore_aoi); else keeps only 'greenfield' rows."""
    aoi = _restore_aoi()
    if aoi is None:
        return None, None
    from qgis.core import QgsGeometry
    filter_gf, nmf = _aoi_filter_greenfield(aoi)
    geom = None
    for f in aoi.getFeatures():
        if filter_gf and "greenfield" not in str(f[nmf]).lower():
            continue
        g = f.geometry()
        if g and not g.isEmpty():
            geom = QgsGeometry(g) if geom is None else geom.combine(g)
    return geom, aoi.crs()


def _metres_to_units(cw, ch, crs, ext):
    """Cell width/height in metres -> layer units. For geographic CRS, convert with a
    latitude correction so cells are ~square on the ground."""
    import math
    if crs is not None and crs.isGeographic():
        lat = (ext.yMinimum() + ext.yMaximum()) / 2.0
        dx = cw / (111320.0 * max(0.15, math.cos(math.radians(lat))))
        dy = ch / 110540.0
        return dx, dy
    return cw, ch


def _generate_grid():
    """Auto-tile the AOI into a grid at the configured cell size; add it as a memory layer
    (in the project, not the tree) and return it. Only cells touching the AOI are kept and
    numbered 1..N (row-major, top-to-bottom). No-op unless grid_cell_w_m/h_m are set."""
    import math
    from qgis.core import QgsVectorLayer, QgsField, QgsFeature, QgsGeometry, QgsRectangle
    from qgis.PyQt.QtCore import QVariant
    cw = float(CFG.get("grid_cell_w_m") or 0.0)
    ch = float(CFG.get("grid_cell_h_m") or 0.0)
    if cw <= 0 or ch <= 0:
        return None
    geom, crs = _aoi_geometry()
    if geom is None:
        pon = _role("coverage")
        if pon is None:
            return None
        geom = QgsGeometry.fromRect(pon.extent()); crs = pon.crs()
    ext = geom.boundingBox()
    dx, dy = _metres_to_units(cw, ch, crs, ext)
    if dx <= 0 or dy <= 0:
        return None
    name = CFG.get("grid_layer_name", "HLD Grid")
    for l in list(p.mapLayers().values()):
        if l.name() == name:
            p.removeMapLayer(l.id())
    vl = QgsVectorLayer(f"Polygon?crs={crs.authid()}", name, "memory")
    dp = vl.dataProvider()
    dp.addAttributes([QgsField("cell_no", QVariant.Int)]); vl.updateFields()
    nx = max(1, int(math.ceil(ext.width() / dx)))
    ny = max(1, int(math.ceil(ext.height() / dy)))
    feats = []; k = 0
    for j in range(ny):                       # top row first -> readable numbering
        for i in range(nx):
            x0 = ext.xMinimum() + i * dx
            y1 = ext.yMaximum() - j * dy
            cell = QgsGeometry.fromRect(QgsRectangle(x0, y1 - dy, x0 + dx, y1))
            if not cell.intersects(geom):
                continue
            k += 1
            feat = QgsFeature(vl.fields())
            feat.setGeometry(cell); feat.setAttribute("cell_no", k)
            feats.append(feat)
    dp.addFeatures(feats); vl.updateExtents()
    # add to the layer TREE (True) so the overview map theme can include the numbered grid
    # (map themes only capture tree layers), then UNCHECK it so it doesn't clutter the live
    # canvas — the overview theme record still shows it explicitly.
    p.addMapLayer(vl, True)
    try:
        node = p.layerTreeRoot().findLayer(vl.id())
        if node is not None:
            node.setItemVisibilityChecked(False)
    except Exception:
        pass
    print(f"grid: {k} cells ({nx}x{ny} scan) at {cw:.0f}x{ch:.0f} m")
    return vl


def _style_labels():
    """Cable/pole/splitter labels ON with white halos (per CFG['labels']); OFF where configured None."""
    from qgis.core import (QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                           QgsVectorLayerSimpleLabeling, QgsUnitTypes)
    from qgis.PyQt.QtGui import QColor, QFont
    PT = _enum(QgsUnitTypes, "RenderUnit.RenderPoints", "RenderPoints")
    MMU = _enum(QgsUnitTypes, "RenderUnit.RenderMillimeters", "RenderMillimeters")

    def field(layer, *cands):
        names = [f.name() for f in layer.fields()]
        for c in cands:
            if c in names:
                return c
        return names[0] if names else None

    def lbl(layer, size, along_line, buf=0.8, strip=None):
        if layer is None:
            return
        s = QgsPalLayerSettings()
        fld = field(layer, "label", "Label", "name")
        if strip:
            s.fieldName = 'replace("' + fld + '", \'' + strip + '\', \'\')'
            s.isExpression = True
        else:
            s.fieldName = fld
        s.enabled = True
        fmt = QgsTextFormat(); fmt.setFont(QFont("Arial")); fmt.setSize(size)
        try: fmt.setSizeUnit(PT)
        except Exception: pass
        b = QgsTextBufferSettings(); b.setEnabled(True); b.setSize(buf); b.setColor(QColor(255, 255, 255))
        try: b.setSizeUnit(MMU)
        except Exception: pass
        fmt.setBuffer(b); s.setFormat(fmt)
        try:
            s.placement = (_enum(QgsPalLayerSettings, "Placement.Curved", "Curved", "Line") if along_line
                           else _enum(QgsPalLayerSettings, "Placement.AroundPoint", "AroundPoint", "OverPoint"))
        except Exception: pass
        # scale-based: labels ONLY when zoomed into a page (detail export) -> full-project canvas stays fast
        s.scaleVisibility = True
        s.minimumScale = float(CFG["label_min_scale"])
        s.maximumScale = 0.0
        layer.setLabeling(QgsVectorLayerSimpleLabeling(s))
        layer.setLabelsEnabled(True)   # NO triggerRepaint -> don't force a heavy canvas re-render

    def off(layer):
        if layer:
            layer.setLabelsEnabled(False)

    for role, spec in CFG["labels"].items():
        layer = _role(role)
        if spec is None:
            off(layer)
        else:
            lbl(layer, spec["size"], spec["along_line"], spec.get("buf", 0.8), spec.get("strip"))


def _rgb(spec):
    try:
        r, g, b = [int(x) for x in str(spec).split(",")[:3]]
        return QColor(r, g, b)
    except Exception:
        return QColor(spec)


def _style_enclosures():
    """Distinct colours for splice (blue) vs connectorised (cyan) enclosures — so they read
    clearly on the map AND the legend (which renders these same symbols) matches. Works for
    BOTH project shapes: separate splice/connectorised layers, or one categorized layer."""
    from qgis.core import (QgsMarkerSymbol, QgsSingleSymbolRenderer,
                           QgsCategorizedSymbolRenderer, QgsRendererCategory)

    def style_single(layer, rgb):
        if layer is None:
            return
        try:
            sym = QgsMarkerSymbol.createSimple({"name": "circle", "color": rgb,
                                                "outline_color": "40,40,40", "outline_width": "0.2", "size": "1.7"})
            layer.setRenderer(QgsSingleSymbolRenderer(sym)); layer.triggerRepaint()
        except Exception as e:
            print("enc style err", e)

    # (a) separate layers, if the project has them
    style_single(_role("enc_splice"), CFG["enc_splice_rgb"])
    style_single(_role("enc_conn"), CFG["enc_conn_rgb"])

    # (b) one categorized "Enclosure" layer -> recolour its splice/connectorised categories
    enc = _p2_enclosure()
    if enc is None:
        return
    r = enc.renderer()
    if not hasattr(r, "categories"):
        return
    try:
        cats = []
        for c in r.categories():
            v = str(c.value()).lower()
            sym = c.symbol().clone()
            if "splice" in v:
                sym.setColor(_rgb(CFG["enc_splice_rgb"]))
            elif "connect" in v:
                sym.setColor(_rgb(CFG["enc_conn_rgb"]))
            # keep every category enabled (map shows them all; don't trust a stray False)
            cats.append(QgsRendererCategory(c.value(), sym, c.label(), True))
        enc.setRenderer(QgsCategorizedSymbolRenderer(r.classAttribute(), cats))
        enc.triggerRepaint()
    except Exception as e:
        print("enc cat style err", e)


def _style_hld_cables():
    """Optional tiered cable symbology (feeder thick, distribution medium, drop thin)
    with a clean, colourblind-safe palette. Config-gated via CFG['hld_cable_style'] so it
    never overrides a project's own careful styling (default None → MOA untouched).
    Tames cluttered per-project cable rendering (e.g. Matiko's magenta spaghetti)."""
    spec = CFG.get("hld_cable_style")
    if not spec:
        return
    from qgis.core import QgsLineSymbol, QgsSingleSymbolRenderer
    order = ("primary", "secondary", "distribution", "spare_drop", "drop")  # thick→thin draw order
    for role in order:
        st = spec.get(role)
        if not st:
            continue
        lyr = _role(role)
        if lyr is None:
            continue
        try:
            sym = QgsLineSymbol.createSimple({
                "color": str(st.get("color", "#555555")),
                "width": str(st.get("w", 0.4)),
                "capstyle": "round", "joinstyle": "round",
            })
            lyr.setRenderer(QgsSingleSymbolRenderer(sym))
            lyr.triggerRepaint()
        except Exception as e:
            print("hld_cable_style err", role, e)


def _style_pon():
    """See-through PON fill + crisp outline; PON labels get a white halo."""
    from qgis.PyQt.QtGui import QColor
    from qgis.core import QgsVectorLayerSimpleLabeling, QgsUnitTypes
    pon = _role("coverage")
    if pon is None:
        return
    try:
        s = pon.renderer().symbol(); sl = s.symbolLayer(0)
        s.setOpacity(1.0)
        fc = sl.fillColor(); fc.setAlpha(int(CFG["pon_fill_alpha"])); sl.setFillColor(fc)
        st = sl.strokeColor(); st.setAlpha(255); sl.setStrokeColor(st)
        if pon.labeling():
            settings = pon.labeling().settings()
            fmt = settings.format()
            fmt.setSize(9)
            buf = fmt.buffer(); buf.setEnabled(True); buf.setSize(1.1)
            try:
                buf.setSizeUnit(_enum(QgsUnitTypes, "RenderUnit.RenderMillimeters", "RenderMillimeters"))
            except Exception:
                pass
            buf.setColor(QColor(255, 255, 255)); buf.setOpacity(1.0)
            fmt.setBuffer(buf)
            settings.setFormat(fmt)
            pon.setLabeling(QgsVectorLayerSimpleLabeling(settings))
        pon.triggerRepaint()
    except Exception as e:
        print("style_pon err", e)


def _style_wayleave():
    """Cambridge-Village wayleave look: the AOI polygon is invisible (the numbered grid
    defines the area) and erven are drawn outline-only (not filled) so the aerial + spans
    read through. Poles/spans/POP keep their project symbols."""
    from qgis.core import QgsFillSymbol, QgsSingleSymbolRenderer
    aoi = _aoi_layer()
    if aoi is not None:
        try:
            aoi.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple(
                {"color": "0,0,0,0", "outline_color": "0,0,0,0", "outline_width": "0"})))
            aoi.triggerRepaint()
        except Exception as e:
            print("wayleave aoi style err", e)
    erv = _fuzzy_layer("polygon", ["erf", "erven"],
                       ["pon", "zone", "grid", "overbuild", "greenfield", "aoi", "boundary"])
    if erv is not None:
        try:
            erv.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple(
                {"color": "0,0,0,0", "outline_color": "35,35,35", "outline_width": "0.2"})))
            erv.triggerRepaint()
        except Exception as e:
            print("wayleave erven style err", e)
    # poles -> hollow white circles; spans/running-lines -> red (Cambridge convention)
    from qgis.core import (QgsMarkerSymbol, QgsLineSymbol, QgsVectorLayer)
    for l in p.mapLayers().values():
        if not isinstance(l, QgsVectorLayer):
            continue
        nm = l.name().lower()
        g = _geom_of(l)
        try:
            if g == "point" and "pole" in nm:
                l.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple(
                    {"name": "circle", "color": "255,255,255",
                     "outline_color": "0,0,0", "outline_width": "0.3", "size": "1.4"})))
                l.triggerRepaint()
            elif g == "line" and ("span" in nm or "running line" in nm):
                l.setRenderer(QgsSingleSymbolRenderer(QgsLineSymbol.createSimple(
                    {"color": "225,29,29", "width": "0.6"})))
                l.triggerRepaint()
        except Exception as e:
            print("wayleave point/line style err", nm, e)


def _style_commercial():
    """Commercial model: number the grid cells (coverage) for the overview; transparent
    fill + dark outline so the numbered grid reads over the basemap."""
    from qgis.core import (QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                           QgsVectorLayerSimpleLabeling, QgsUnitTypes, QgsFillSymbol,
                           QgsSingleSymbolRenderer)
    from qgis.PyQt.QtGui import QColor, QFont
    grid = _role("coverage")
    fld = CFG.get("coverage_label_field")
    if grid is None or not fld:
        return
    try:
        grid.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple(
            {"color": "0,0,0,0", "outline_color": "0,0,0", "outline_width": "0.4"})))
    except Exception as e:
        print("grid style err", e)
    try:
        s = QgsPalLayerSettings()
        s.fieldName = fld
        s.enabled = True
        try:
            s.centroidInside = True
        except Exception:
            pass
        try:
            s.placement = _enum(QgsPalLayerSettings, "Placement.Horizontal", "Horizontal",
                                "AroundPoint", "OverPoint")
        except Exception:
            pass
        fmt = QgsTextFormat(); fmt.setFont(QFont("Arial")); fmt.setSize(18)
        try:
            fmt.setSizeUnit(_enum(QgsUnitTypes, "RenderUnit.RenderPoints", "RenderPoints"))
        except Exception:
            pass
        b = QgsTextBufferSettings(); b.setEnabled(True); b.setSize(1.2); b.setColor(QColor(255, 255, 255))
        fmt.setBuffer(b); s.setFormat(fmt)
        grid.setLabeling(QgsVectorLayerSimpleLabeling(s))
        grid.setLabelsEnabled(True)
    except Exception as e:
        print("grid label err", e)


# ---- OVERVIEW (report header / page 1) ----
def _make_overview():
    name = CFG["layout_overview"]
    layout = new_layout(name)
    basemap = _basemap_layer()
    aoi = _restore_aoi()
    pon = _role("coverage")
    if CFG.get("overview_layers"):
        # commercial: explicit overview layer set (numbered grid + zoning + boundary + basemap)
        ov_layers = _resolve_layer_list(CFG["overview_layers"])
        ext = pon.extent() if pon else _greenfield_extent()
        gf_ext = _greenfield_extent()
        if gf_ext:
            ext.combineExtentWith(gf_ext)
    elif CFG.get("hld_layers"):
        # operator hand-picked the layers -> coverage + those + basemap
        ov_layers = [l for l in ([pon] + _resolve_layer_list(CFG["hld_layers"]) + [basemap]) if l]
        ext = _greenfield_extent() or (pon.extent() if pon else None)
        if ext is not None and pon:
            ext.combineExtentWith(pon.extent())
    else:
        primary = _role("primary")
        secondary = _role("secondary")
        # OVERVIEW = PON numbers + primary & secondary FEEDER ROUTES only
        ov_layers = [l for l in (primary, secondary, pon, aoi, basemap) if l]
        ext = _greenfield_extent()
        if ext is None:
            ext = pon.extent()
        ext.combineExtentWith(pon.extent())   # every PON guaranteed in
        for _fl in (primary, secondary):      # include feeder routes so none run off the edge
            if _fl:
                ext.combineExtentWith(_fl.extent())
    # frame AFTER the layer list is known -> legend auto-completes from what's drawn
    MAP = build_frame(layout, CFG["title_overview"], map_layers=ov_layers)
    ext.scale(1.04)
    # force the extent to EXACTLY the map-item aspect (add to the shorter side) -> fills, no white bands
    target_ar = MAP["w"] / MAP["h"]
    cur_ar = ext.width() / ext.height()
    c = ext.center()
    if cur_ar > target_ar:                # too wide -> add height
        nh = ext.width() / target_ar
        ext.setYMinimum(c.y() - nh / 2); ext.setYMaximum(c.y() + nh / 2)
    else:                                 # too tall -> add width
        nw = ext.height() * target_ar
        ext.setXMinimum(c.x() - nw / 2); ext.setXMaximum(c.x() + nw / 2)
    make_map(layout, MAP, ov_layers, extent=ext)
    return layout                       # owned by the report (not added to the manager)


# ---- DETAIL (report body / one page per coverage feature) ----
def _make_detail():
    name = CFG["layout_atlas"]
    layout = new_layout(name)
    gf = _restore_aoi()
    if CFG.get("hld_layers"):
        # operator hand-picked the HLD layers -> use exactly those (+ basemap under them)
        layers = _resolve_layer_list(CFG["hld_layers"])
        bm = _basemap_layer()
        if bm is not None and bm.id() not in {l.id() for l in layers}:
            layers = layers + [bm]
    elif CFG.get("detail_layers"):
        # commercial: explicit detail layer set (zoning + SDU + boundary + basemap; NO grid overlay)
        layers = _resolve_layer_list(CFG["detail_layers"])
    else:
        # take exactly the visible group layers (adapts to renames); drop clutter + feeders
        feeder_names = set(CFG["roles"].get("primary", [])) | set(CFG["roles"].get("secondary", []))
        det_layers = _p2_visible_layers(exclude=set(CFG["detail_exclude"]) | feeder_names)
        if not det_layers:
            # no group (e.g. saved 'HLD only' project) -> known network layers, NO feeders
            seen = set(); det_layers = []
            for n in CFG["detail_fallback"]:
                l = _lyr(n)
                if l and l.id() not in seen:
                    seen.add(l.id()); det_layers.append(l)
        bm = _basemap_layer()
        layers = det_layers + [l for l in (gf, bm) if l]
    # frame AFTER the layer list is known -> legend auto-completes from what's drawn
    MAP = build_frame(layout, CFG["title_atlas_expr"], map_layers=layers)
    pon = _role("coverage")
    # atlas-driven map => the report field-group sets the current feature and this map
    # zooms/fits to it (proven: each body page frames its own PON inside the fixed frame).
    make_map(layout, MAP, layers, extent=pon.extent(), atlas_driven=True, margin=float(CFG["atlas_margin"]))
    return layout                       # owned by the report (not added to the manager)


def build_report():
    """Assemble ONE editable Report: header = overview (page 1), field-group body =
    one detail page per coverage feature. Exports to a single PDF (overview first)."""
    from qgis.core import QgsReport, QgsReportSectionFieldGroup
    name = CFG["layout_report"]
    lm = p.layoutManager()
    # drop any previous run's report + its stray header/body layouts
    for nm in (name, CFG["layout_overview"], CFG["layout_atlas"]):
        ex = lm.layoutByName(nm)
        if ex is not None:
            lm.removeLayout(ex)
    if _role("coverage") is None:
        raise ValueError(
            "HLD report: no coverage layer (PON/Zone polygon) resolved. Pick or add one.")
    overview = _make_overview()
    detail = _make_detail()
    pon = _role("coverage")
    rep = QgsReport(p)
    rep.setName(name)
    rep.setHeaderEnabled(True)
    rep.setHeader(overview)             # PAGE 1
    fg = QgsReportSectionFieldGroup()
    fg.setLayer(pon)
    fg.setField(CFG["coverage_sort_field"])   # one body page per value, ascending
    try:
        fg.setSortAscending(True)
    except Exception:
        pass
    fg.setBody(detail)
    fg.setBodyEnabled(True)
    rep.appendChild(fg)
    lm.addLayout(rep)
    return name


def _book_layer_sets():
    """(overview_layers, detail_layers, all_layers) for the unified atlas. The overview page
    shows the grid (if grid mode) or feeders + PON + AOI + basemap; detail pages show the
    full network. The grid coverage layer never shows on the detail pages."""
    basemap = _basemap_layer()
    aoi = _restore_aoi()
    picked = _resolve_layer_list(CFG["hld_layers"]) if CFG.get("hld_layers") else None
    if CFG.get("overview_layers"):
        overview_layers = _resolve_layer_list(CFG["overview_layers"])   # grid mode: numbered grid + net
    elif picked:
        net_cov = _role("coverage")
        overview_layers = [l for l in ([net_cov] + picked + [basemap]) if l]
    else:
        net_cov = _role("coverage")
        primary = _role("primary"); secondary = _role("secondary")
        overview_layers = [l for l in (primary, secondary, net_cov, aoi, basemap) if l]
    if picked:
        detail_layers = picked + [l for l in (basemap,) if l and l.id() not in {x.id() for x in picked}]
    else:
        feeder_names = set(CFG["roles"].get("primary", [])) | set(CFG["roles"].get("secondary", []))
        exclude = set(CFG["detail_exclude"]) | feeder_names | {CFG.get("grid_layer_name", "HLD Grid")}
        det = _p2_visible_layers(exclude=exclude)
        if not det:
            seen = set(); det = []
            for n in CFG["detail_fallback"]:
                l = _lyr(n)
                if l and l.id() not in seen:
                    seen.add(l.id()); det.append(l)
        detail_layers = det + [l for l in (aoi, basemap) if l]
    allm = []; seen = set()
    for l in overview_layers + detail_layers:
        if l and l.id() not in seen:
            seen.add(l.id()); allm.append(l)
    return overview_layers, detail_layers, allm


def _role_layers(role):
    """ALL layers configured for a role (not just the first). Multi-layer roles like poles
    (e.g. Distribution Poles + Feeder Poles) would otherwise be undercounted. Falls back to
    the fuzzy single-layer _role() when nothing is configured by exact name."""
    names = CFG["roles"].get(role, []) or []
    out, seen = [], set()
    for nm in names:
        l = _lyr(nm)
        if l is not None and l.id() not in seen:
            seen.add(l.id()); out.append(l)
    if out:
        return out
    one = _role(role)
    return [one] if one is not None else []


def _zone_stat_index():
    """Spatial indexes + feature caches for per-zone stats (drops / poles / distribution).
    Merges ALL layers per role into one index with synthetic unique ids (raw feature ids
    collide across layers), so multi-layer roles (poles = Distribution + Feeder) count in full."""
    from qgis.core import QgsSpatialIndex, QgsFeature
    out = {}
    for key, role in (("drops", "drop"), ("poles", "poles"), ("dist", "distribution")):
        layers = _role_layers(role)
        if not layers:
            out[key] = (None, {})
            continue
        idx = QgsSpatialIndex(); cache = {}; uid = 0
        for lyr in layers:
            for f in lyr.getFeatures():
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                nf = QgsFeature(); nf.setId(uid); nf.setGeometry(g)
                idx.addFeature(nf); cache[uid] = nf; uid += 1
        out[key] = (idx, cache)
    return out


def _zone_stats(geom, srcfeat, sidx):
    """Per-coverage-feature stats. Prefer source fields (e.g. unit_count / splitter_c),
    else spatial counts within `geom`. Returns dict of display strings."""
    src_map = CFG.get("zone_stat_source") or {}

    def src(field):
        if not field or srcfeat is None:
            return None
        try:
            return srcfeat[field] if field in srcfeat.fields().names() else None
        except Exception:
            return None

    def within(key):
        idx, feats = sidx.get(key, (None, {}))
        if idx is None or geom is None:
            return 0, 0.0
        n, length = 0, 0.0
        for fid in idx.intersects(geom.boundingBox()):
            fg = feats[fid].geometry()
            if fg and not fg.isEmpty() and geom.intersects(fg):
                n += 1
                length += fg.length() * 111320.0     # deg -> m (CRS 4326)
        return n, length

    units = src(src_map.get("units"))
    spl = src(src_map.get("splitters"))
    n_drops, _ = within("drops")
    n_poles, _ = within("poles")
    _, dist_m = within("dist")
    if units is None:
        units = n_drops
    return {"units": str(units), "spl": "" if spl is None else str(spl),
            "drops": str(n_drops), "poles": str(n_poles), "distm": "%.0f" % dist_m}


def _build_book_coverage():
    """Unified atlas coverage: an OVERVIEW feature (whole AOI) FIRST, then one feature per
    network coverage unit (PON/Zone). Fields: seq (sort), is_overview, unit (page label)."""
    from qgis.core import QgsVectorLayer, QgsField, QgsFeature, QgsGeometry
    from qgis.PyQt.QtCore import QVariant
    cov = _role("coverage")
    if cov is None:
        return None
    name = "HLD Book Pages"
    for l in list(p.mapLayers().values()):
        if l.name() == name:
            p.removeMapLayer(l.id())
    vl = QgsVectorLayer(f"Polygon?crs={cov.crs().authid()}", name, "memory")
    dp = vl.dataProvider()
    dp.addAttributes([QgsField("seq", QVariant.Int), QgsField("is_overview", QVariant.Int),
                      QgsField("unit", QVariant.String),
                      # per-page stats (populated below; drive the per-zone summary box)
                      QgsField("stat_name", QVariant.String),
                      QgsField("stat_units", QVariant.String),
                      QgsField("stat_spl", QVariant.String),
                      QgsField("stat_drops", QVariant.String),
                      QgsField("stat_poles", QVariant.String),
                      QgsField("stat_distm", QVariant.String)])
    vl.updateFields()
    geom, _crs = _aoi_geometry()
    if geom is None:
        g = None
        for f in cov.getFeatures():
            fg = f.geometry()
            if fg and not fg.isEmpty():
                g = QgsGeometry(fg) if g is None else g.combine(fg)
        geom = g
    feats = []
    per_page = bool(CFG.get("per_page_summary"))     # only compute stats when shown
    sidx = _zone_stat_index() if per_page else None
    ovf = QgsFeature(vl.fields())
    if geom is not None:
        ovf.setGeometry(geom)
    ovf.setAttribute("seq", 0); ovf.setAttribute("is_overview", 1); ovf.setAttribute("unit", "Overview")
    if per_page:
        ov = _zone_stats(geom, None, sidx)
        _sts = _role("sts")
        ovf.setAttribute("stat_name", CFG.get("summary_title", "PROJECT TOTALS"))
        ovf.setAttribute("stat_units", ov["units"])
        ovf.setAttribute("stat_spl", str(_sts.featureCount()) if _sts else "")
        ovf.setAttribute("stat_drops", ov["drops"])
        ovf.setAttribute("stat_poles", ov["poles"])
        ovf.setAttribute("stat_distm", ov["distm"])
    feats.append(ovf)
    # sort field: use the configured one, else fall back so ANY coverage layer works
    sf = CFG["coverage_sort_field"]
    cov_fields = [fld.name() for fld in cov.fields()]
    if sf not in cov_fields:
        for cand in ("label", "pon_no", "zone_id", "zone_name", "name", "id", "fid"):
            if cand in cov_fields:
                sf = cand
                break
        else:
            sf = cov_fields[0] if cov_fields else None

    def _cov_val(f):
        return f.id() if sf is None else f[sf]

    def _sortkey(f):
        v = _cov_val(f)
        # string-safe: coverage pages may mix int/str keys
        return (v is None, str(v) if not isinstance(v, (int, float)) else "", v if isinstance(v, (int, float)) else 0, str(v))
    rows = sorted(cov.getFeatures(), key=_sortkey)
    zprefix = CFG.get("zone_stat_prefix", "ZONE ")
    for i, f in enumerate(rows, start=1):
        nf = QgsFeature(vl.fields()); nf.setGeometry(f.geometry())
        nf.setAttribute("seq", i); nf.setAttribute("is_overview", 0)
        v = _cov_val(f)
        nf.setAttribute("unit", "" if v is None else str(v))
        if per_page:
            st = _zone_stats(f.geometry(), f, sidx)
            nf.setAttribute("stat_name", zprefix + ("" if v is None else str(v)))
            nf.setAttribute("stat_units", st["units"])
            nf.setAttribute("stat_spl", st["spl"])
            nf.setAttribute("stat_drops", st["drops"])
            nf.setAttribute("stat_poles", st["poles"])
            nf.setAttribute("stat_distm", st["distm"])
        feats.append(nf)
    dp.addFeatures(feats); vl.updateExtents()
    p.addMapLayer(vl, False)
    return vl


def _register_book_themes(overview_layers, detail_layers):
    """Two map themes the unified atlas map switches between per page: HLD_Overview
    (feeders + coverage + AOI + basemap) and HLD_Detail (full network)."""
    from qgis.core import QgsMapThemeCollection
    mtc = p.mapThemeCollection()

    def rec(layers):
        r = QgsMapThemeCollection.MapThemeRecord()
        for l in layers:
            if l is None:
                continue
            lr = QgsMapThemeCollection.MapThemeLayerRecord(l)
            try:
                lr.usingCurrentStyle = True
            except Exception:
                pass
            r.addLayerRecord(lr)
        return r

    for nm in ("HLD_Overview", "HLD_Detail"):
        if mtc.hasMapTheme(nm):
            mtc.removeMapTheme(nm)
    mtc.insert("HLD_Overview", rec(overview_layers))
    mtc.insert("HLD_Detail", rec(detail_layers))


def _max_span_m(g):
    """Longest vertex-to-vertex segment of a (multi)line in metres (deg CRS → m)."""
    from qgis.core import QgsPointXY, QgsGeometry
    verts = [QgsPointXY(pt) for pt in g.vertices()]
    mx = 0.0
    for i in range(len(verts) - 1):
        d = (QgsGeometry.fromPointXY(verts[i]).distance(
             QgsGeometry.fromPointXY(verts[i + 1])) * 111320.0)
        if d > mx:
            mx = d
    return mx


def _build_qa_layer():
    """'HLD Issues' overlay: cables whose longest span exceeds the configured limit,
    as a thick-red memory line layer added on top of the map. Returns (layer, count)."""
    limits = CFG.get("qa_span_limits") or {}
    if not CFG.get("hld_qa_overlay") or not limits:
        return None, 0
    from qgis.core import (QgsVectorLayer, QgsField, QgsFeature, QgsLineSymbol,
                           QgsSingleSymbolRenderer)
    from qgis.PyQt.QtCore import QVariant
    name = "HLD Issues"
    for l in list(p.mapLayers().values()):
        if l.name() == name:
            p.removeMapLayer(l.id())
    vl = dp = None
    feats = []
    for role, lim in limits.items():
        lyr = _role(role)
        if lyr is None:
            continue
        if vl is None:
            vl = QgsVectorLayer(f"LineString?crs={lyr.crs().authid()}", name, "memory")
            dp = vl.dataProvider()
            dp.addAttributes([QgsField("issue", QVariant.String),
                              QgsField("role", QVariant.String),
                              QgsField("span_m", QVariant.Double)])
            vl.updateFields()
        for f in lyr.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            span = _max_span_m(g)
            if span > lim:
                nf = QgsFeature(vl.fields())
                nf.setGeometry(g)
                nf.setAttribute("issue", "over-span")
                nf.setAttribute("role", role)
                nf.setAttribute("span_m", round(span, 1))
                feats.append(nf)
    if vl is None or not feats:
        return None, 0
    dp.addFeatures(feats)
    vl.updateExtents()
    # bold red (a white casing beneath makes it pop on red-hued zones too)
    sym = QgsLineSymbol.createSimple({"color": "#dc0000", "width": "1.0",
                                      "capstyle": "round"})
    try:
        from qgis.core import QgsSimpleLineSymbolLayer
        from qgis.PyQt.QtGui import QColor
        casing = QgsSimpleLineSymbolLayer(QColor(255, 255, 255))
        casing.setWidth(1.9)
        sym.insertSymbolLayer(0, casing)          # white casing UNDER the red core
    except Exception:
        pass
    vl.setRenderer(QgsSingleSymbolRenderer(sym))
    p.addMapLayer(vl, False)
    return vl, len(feats)


def build_unified_atlas():
    """ONE atlas book: page 1 = overview (whole project, feeders + PON only), then one
    detail page per unit (full network). Flip overview -> PONs in a single editable layout;
    export gives the same book. The map switches map-theme per page (data-defined)."""
    from qgis.core import (QgsProperty, QgsLayoutObject, QgsLayoutItemMap)
    lm = p.layoutManager()
    for nm in (CFG["layout_report"], CFG["layout_overview"], CFG["layout_atlas"]):
        ex = lm.layoutByName(nm)
        if ex is not None:
            lm.removeLayout(ex)
    ov_set, det_set, all_set = _book_layer_sets()
    qa_layer, qa_n = _build_qa_layer()            # P2 QA overlay (config-gated)
    if qa_layer is not None:
        det_set = [qa_layer] + det_set            # draw violations on top of detail pages
        all_set = [qa_layer] + all_set
        print("HLD QA overlay: %d over-span cables flagged" % qa_n)
    _register_book_themes(ov_set, det_set)
    cover = _build_book_coverage()
    if cover is None:
        # no per-page coverage AND no polygon fallback -> a clear, actionable error beats an
        # AttributeError deep in _make_overview (build_report needs coverage too).
        raise ValueError(
            "HLD atlas: no per-page coverage layer found. Pick the PON/Zone polygon under "
            "“Each page shows”, or add a coverage polygon to the project.")
    # per-page title: page 1 = overview, else the per-unit heading.
    proj = str(CFG["project_name"]).replace("'", "''")
    if CFG.get("frame_style") == "wayleave":
        # wayleave: overview shows "Wayleave Application", tiles show no heading; the page
        # number lives in the corner box ("Page Overview" / "Page N of M").
        CFG["title_atlas_expr"] = ("[% if(attribute(@atlas_feature,'is_overview')=1,"
                                   "'Wayleave Application','') %]")
        CFG["page_label_expr"] = ("[% if(attribute(@atlas_feature,'is_overview')=1,'Page Overview',"
                                  "'Page ' || attribute(@atlas_feature,'seq') || ' of ' || "
                                  "(@atlas_totalfeatures - 1)) %]")
    else:
        prefix = str(CFG.get("title_atlas_expr", f"{CFG['project_name']} - PON ")).split("[%")[0]
        prefix = prefix.replace("'", "''")
        CFG["title_atlas_expr"] = (f"[% if(\"is_overview\"=1, '{proj} Overview', "
                                   f"'{prefix}' || \"unit\") %]")
    layout = new_layout(CFG["layout_atlas"])
    MAP = build_frame(layout, CFG["title_atlas_expr"], map_layers=det_set)
    make_map(layout, MAP, all_set, atlas_driven=True, margin=float(CFG["atlas_margin"]))
    m = next((it for it in layout.items() if isinstance(it, QgsLayoutItemMap)), None)
    if m is not None:
        try:
            m.setFollowVisibilityPreset(True)
            expr = "if(attribute(@atlas_feature,'is_overview')=1,'HLD_Overview','HLD_Detail')"
            m.dataDefinedProperties().setProperty(
                QgsLayoutObject.DataDefinedProperty.MapStylePreset,
                QgsProperty.fromExpression(expr))
        except Exception as e:
            print("book theme dd err", e)
    at = layout.atlas()
    at.setEnabled(True)
    at.setCoverageLayer(cover)
    at.setSortFeatures(True)
    at.setSortExpression('"seq"')
    at.setFilenameExpression("'page_' || \"seq\"")
    lm.addLayout(layout)
    return CFG["layout_atlas"]


def build_page_layouts():
    """Build the overview + detail as standalone, PAGE-VIEW print layouts in the Layout
    Manager (WYSIWYG editing — you see + tweak each page immediately). The detail is a
    normal atlas: one page per coverage feature. Used by 'Open in Print Layout'."""
    lm = p.layoutManager()
    for nm in (CFG["layout_report"], CFG["layout_overview"], CFG["layout_atlas"]):
        ex = lm.layoutByName(nm)
        if ex is not None:
            lm.removeLayout(ex)
    overview = _make_overview()
    lm.addLayout(overview)
    detail = _make_detail()
    cov = _role("coverage")
    at = detail.atlas()
    at.setEnabled(True)
    at.setCoverageLayer(cov)
    at.setHideCoverage(bool(CFG.get("hide_coverage", False)))
    at.setSortFeatures(True)
    at.setSortExpression('"' + CFG["coverage_sort_field"] + '"')
    at.setFilenameExpression(CFG.get("atlas_filename_expr") or ('"' + CFG["coverage_sort_field"] + '"'))
    lm.addLayout(detail)
    return CFG["layout_overview"], CFG["layout_atlas"]


def _qa_strip_html(t):
    import re
    return re.sub(r"<[^>]+>", " ", t or "").replace("&nbsp;", " ").replace("&amp;", "&")


def _qa_desc(it):
    tn = type(it).__name__.replace("QgsLayoutItem", "")
    try:
        from qgis.core import QgsLayoutItemPicture, QgsLayoutItemLabel
        if isinstance(it, QgsLayoutItemPicture):
            return "%s(%s)" % (tn, os.path.basename(it.picturePath() or ""))
        if isinstance(it, QgsLayoutItemLabel):
            return "%s(%s)" % (tn, _qa_strip_html(it.text() or "")[:24].strip())
    except Exception:
        pass
    return tn


def _layout_qa(layout):
    """PERFECT-RENDER self-check. Returns (hard, soft): hard = must-not-ship problems,
    soft = warnings. Frame-agnostic — works on ANY built layout (HLD atlas / commercial /
    wayleave, any client). Checks: item overlap (excl. the map + legitimate label-in-frame),
    items off the page, map has layers + a non-empty extent, legend rendered, and static-text
    integrity (empty / None / nan). Atlas-expression labels ([% … %]) are evaluated per page,
    so they're skipped here and covered by the post-render pixel check."""
    from qgis.core import (QgsLayoutItemMap, QgsLayoutItemLabel, QgsLayoutItemPicture,
                           QgsLayoutItemShape, QgsLayoutItemPage)
    hard, soft = [], []
    items = [it for it in layout.items()
             if hasattr(it, "sceneBoundingRect")
             and (it.sceneBoundingRect().width() > 0.1 or it.sceneBoundingRect().height() > 0.1)]
    try:
        pg = layout.pageCollection().page(0)
        pr = pg.sceneBoundingRect() if pg else None
    except Exception:
        pr = None

    def rct(it):
        r = it.sceneBoundingRect()
        return (r.x(), r.y(), r.x() + r.width(), r.y() + r.height())

    def is_bg(it):
        # background / structural items that legitimately sit under or around content:
        # shapes (table cells, panel backgrounds, the border), the page item, and the
        # scene's page-boundary rect. Frame-agnostic (works for A3 HLD and A4 wayleave).
        if isinstance(it, (QgsLayoutItemShape, QgsLayoutItemPage)):
            return True
        return type(it).__name__ in ("QgsLayoutItemPage", "QGraphicsRectItem")

    # FOREGROUND content only: a bad layout is two pieces of content colliding (logo on the
    # title text, a summary box on the title block). Overlaps that INVOLVE a background shape
    # or the page are legitimate by design (labels sit inside their cells) -> never flagged.
    fg = [it for it in items if not isinstance(it, QgsLayoutItemMap) and not is_bg(it)]
    # 1) overlaps (foreground vs foreground only)
    for i in range(len(fg)):
        for j in range(i + 1, len(fg)):
            a, b = rct(fg[i]), rct(fg[j])
            ix = max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
            iy = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
            if ix * iy <= 1.5:
                continue
            hard.append("overlap %.0fx%.0fmm: %s <-> %s"
                        % (ix, iy, _qa_desc(fg[i]), _qa_desc(fg[j])))
    # 2) off the page (foreground content only)
    if pr is not None:
        for it in fg:
            r = it.sceneBoundingRect()
            if (r.x() < pr.x() - 1.0 or r.y() < pr.y() - 1.0
                    or r.x() + r.width() > pr.x() + pr.width() + 1.0
                    or r.y() + r.height() > pr.y() + pr.height() + 1.0):
                hard.append("off-page: %s" % _qa_desc(it))
    # 3) map validity
    maps = [it for it in items if isinstance(it, QgsLayoutItemMap)]
    if not maps:
        hard.append("no map item on the page")
    for m in maps:
        try:
            if not m.layers() and not m.followVisibilityPreset():
                hard.append("map has no layers")
            drv = False
            try:
                drv = m.atlasDriven()
            except Exception:
                drv = False
            if not drv:                       # atlas maps get their extent per-feature at render
                ext = m.extent()
                if ext is None or ext.isEmpty() or ext.width() <= 0:
                    hard.append("map extent is empty")
        except Exception as e:
            soft.append("map check error: %s" % e)
    # 4) legend rendered (picture file present + non-empty)
    for it in items:
        if isinstance(it, QgsLayoutItemPicture):
            pth = it.picturePath() or ""
            if "legend" in os.path.basename(pth).lower():
                if not (os.path.exists(pth) and os.path.getsize(pth) > 0):
                    hard.append("legend image missing/empty")
    # 5) static-text integrity (skip atlas templates)
    for it in items:
        if isinstance(it, QgsLayoutItemLabel):
            try:
                t = it.text() or ""
            except Exception:
                t = ""
            if "[%" in t:
                continue
            plain = _qa_strip_html(t).strip()
            if plain.lower() in ("", "none", "nan", "null"):
                soft.append("empty/placeholder label")
    return hard, soft


def build_all():
    """Style the layers + build the Report (safe on the GUI thread; no-op headless)."""
    try:
        from qgis.utils import iface as _iface
        _canvas = _iface.mapCanvas() if _iface else None
    except Exception:
        _canvas = None
    if _canvas is not None:
        _canvas.setRenderFlag(False)
    try:
        # ── GRID MODE: auto-tile the AOI, switch coverage to the grid (one page per cell) ──
        grid_mode = float(CFG.get("grid_cell_w_m") or 0.0) > 0.0
        if grid_mode:
            grid = _generate_grid()
            if grid is None:
                grid_mode = False                     # couldn't build (no AOI) -> normal coverage
            else:
                CFG["roles"] = dict(CFG.get("roles", {}))
                CFG["roles"]["coverage"] = [grid.name()]
                CFG["coverage_sort_field"] = "cell_no"
                CFG["coverage_label_field"] = "cell_no"
                CFG["hide_coverage"] = True
                CFG["atlas_filename_expr"] = "'grid_' || \"cell_no\""
                _wayleave = CFG.get("frame_style") == "wayleave"
                if not _wayleave:
                    # wayleave shows NO per-page heading (its preset sets title_atlas_expr="")
                    CFG["title_atlas_expr"] = f'{CFG["project_name"]} - Grid [% "cell_no" %]'
                # grid overview = the NUMBERED grid + network + boundary + basemap.
                # wayleave shows the full network (span/poles/erven/pop); HLD/commercial
                # show the feeder routes only (PON zones would clutter the numbered grid).
                ov = [grid.name()]
                if CFG.get("hld_layers"):
                    # operator hand-picked the layers -> numbered grid + exactly those
                    for _l in _resolve_layer_list(CFG["hld_layers"]):
                        ov.append(_l.name())
                elif _wayleave:
                    for _l in _p2_visible_layers(exclude={grid.name()}):
                        ov.append(_l.name())
                else:
                    for _r in ("primary", "secondary"):
                        _l = _role(_r)
                        if _l:
                            ov.append(_l.name())
                for _n in (CFG["aoi_layer"], CFG["basemap"]):
                    _l = _lyr(_n)
                    if _l:
                        ov.append(_l.name())
                CFG["overview_layers"] = ov

        if CFG.get("frame_style") == "commercial":
            _style_commercial()
        elif CFG.get("frame_style") == "wayleave":
            _style_wayleave()                         # invisible AOI + outline-only erven
            _style_labels()                           # pole numbers (Cambridge shows them)
            if grid_mode:
                _style_commercial()                   # numbers the grid tiles on the overview
        else:
            _style_hld_cables()                       # optional tiered cable style (config-gated)
            _style_enclosures()
            _style_pon()
            _style_labels()
            if grid_mode:
                _style_commercial()                   # numbers the grid cells on the overview
        if CFG.get("frame_style") == "commercial":
            # commercial keeps the report-or-page-layouts flow.
            if CFG.get("build_mode") == "layouts":
                res = build_page_layouts()
                print("BUILT PAGE LAYOUTS:", res)
            else:
                res = build_report()
                print("BUILT REPORT:", res)
        else:
            # standard HLD *and* grid: ONE book atlas — overview page 1 (grid = numbered grid,
            # else feeders + PON) then flip -> every detail page. Serves editing + export.
            res = build_unified_atlas()
            print("BUILT UNIFIED ATLAS:", res, "| grid:", grid_mode)
        return res
    finally:
        if _canvas is not None:
            try:
                _ext = _greenfield_extent()
                if _ext is not None:
                    _ext.scale(1.1); _canvas.setExtent(_ext)
            except Exception:
                pass
            _canvas.setRenderFlag(True)


# run on exec (preserves the original drop-in behaviour)
build_all()
