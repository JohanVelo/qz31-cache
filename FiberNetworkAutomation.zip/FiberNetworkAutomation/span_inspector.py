"""Span Inspector — dial a max span, see every longer POLE-TO-POLE run light up.

Set the limit (0–100 m). Every span from one pole to the next pole, measured ALONG
the cable, that is longer than the limit glows red on the canvas and STAYS glowing
until you switch it off. Fix a span — move a pole, re-route a cable — and it
un-highlights itself the moment it comes under the limit, so what is still glowing
is exactly what is still wrong.

A span is pole → next pole along the cable geometry. NOT the whole cable, and NOT
vertex-to-vertex: a cable's vertices are not poles (JJ, 2026-07-23). The measurement
lives in `fibre_automation.span_scan`; this module is UI only.

WORKS ON ANY PROJECT. Nothing here is Malmesbury- or PH2-specific: layers are
discovered from whatever project is open, the operator's choices are remembered per
project, and the lists rebuild themselves when the project or its layers change. A
project whose layers are named differently just needs the pole layer picked once.

READ-ONLY. No code path here starts an edit session or writes a feature, so it is
safe on live Mohadin PH2 / Malmesbury (write-off-limits). The highlight is a
QgsRubberBand — a canvas overlay, not a layer: nothing is added to the Layers panel
and nothing is written to disk.

Live re-check is SIGNAL-DRIVEN, never a polling loop. Edit signals on the cable
layers AND the pole layer arm a single-shot debounce; nothing ticks while you are
not editing.

Styling follows the live Velocity Nexus theme (`VelocityFibre/panel_theme`) using the
same colour keys as the home panel, so a theme switch restyles this panel too.
Semantic colours (ok/warn/bad) come from `theme_safe`, which contrast-checks against
the real background — hardcoding them is a bug class that has broken light mode here
before.
"""
from qgis.PyQt import sip
from qgis.PyQt.QtCore import Qt, QTimer
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QDockWidget, QFrame, QHBoxLayout,
    QLabel, QListWidget, QListWidgetItem, QPushButton, QScrollArea, QSizePolicy,
    QSlider, QSpinBox, QVBoxLayout, QWidget)
from qgis.core import QgsGeometry, QgsProject, QgsSettings, QgsWkbTypes
from qgis.gui import QgsRubberBand

try:
    from . import theme_safe
except ImportError:
    import theme_safe

try:                                     # bundled copy inside the installed plugin
    from .fibre_automation import span_scan
except ImportError:                      # workspace / dev checkout
    from fibre_automation import span_scan

_CABLE_HINTS = ("cable", "feeder", "span", "drop", "distribution", "primary",
                "secondary", "backhaul", "kabel")
_DEBOUNCE_MS = 250
_HL_COLOR = QColor(255, 45, 45)
_HL_WIDTH = 6
_EDIT_SIGNALS = ("geometryChanged", "featureAdded", "featuresDeleted",
                 "editCommandEnded", "afterCommitChanges", "afterRollBack")
_SETTINGS_ROOT = "VelocityFibre/span_inspector"

# Fallback theme — used only if the home panel's THEMES cannot be imported, so the
# panel is never unstyled.
_FALLBACK_THEME = {
    "bg": "#05070C", "step_bg": "#0D1320", "step_border": "#1E2A3D",
    "step_hi": "#1AE5FF", "section": "#7E93B8", "title": "#EAF3FF",
    "sub": "#9DB0CC", "word_bot": "#1AE5FF", "tool_bg": "#111A2B",
    "tool_text": "#C7D6EE", "tool_hover": "#16223A",
    "accent": "qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #1AE5FF, stop:1 #1AA6FF)",
    "badge_text": "#05070C",
}


def _alive(obj):
    """True if a Qt object is still usable — guards the deleted-C++ crash class."""
    if obj is None:
        return False
    try:
        return not sip.isdeleted(obj)
    except Exception:
        return True


def _theme():
    """The live Nexus theme dict. Falls back so a missing key can't break the UI."""
    try:
        try:
            from .velocity_home_panel import THEMES
        except ImportError:
            from velocity_home_panel import THEMES
        name = QgsSettings().value("VelocityFibre/panel_theme", "velocity")
        c = dict(THEMES.get(name) or THEMES.get("velocity") or {})
    except Exception:
        c = {}
    for k, v in _FALLBACK_THEME.items():
        c.setdefault(k, v)
    return c


def _project_key():
    """Stable per-project settings key (falls back to the name for unsaved projects)."""
    proj = QgsProject.instance()
    return (proj.fileName() or proj.baseName() or "unsaved").replace("/", "_") \
        .replace("\\", "_").replace(":", "")


def _build_qss(c, sem):
    """Panel stylesheet from the live theme + contrast-checked semantic colours."""
    return f"""
#vfSpanRoot {{ background:{c['bg']}; }}
#vfSpanRoot QLabel {{ color:{c['sub']}; }}
#vfSpanTitle {{ color:{c['title']}; font-size:15px; font-weight:800;
                letter-spacing:0.4px; }}
#vfSpanSub {{ color:{c['sub']}; font-size:11px; }}
#vfSpanSection {{ color:{c['section']}; font-size:10px; font-weight:700;
                letter-spacing:2px;
                font-family:'JetBrains Mono','Consolas','DejaVu Sans Mono',monospace;
                border-top:1px solid {c['step_border']}; padding-top:9px; }}
#vfSpanBeta {{ color:{sem['warn']}; font-size:10px; font-weight:700;
               letter-spacing:0.6px; border:1px solid {sem['warn']};
               border-radius:4px; padding:3px 7px; }}
QFrame#vfSpanCard {{ background:{c['step_bg']}; border:1px solid {c['step_border']};
                     border-radius:8px; }}
QFrame#vfSpanCard QLabel {{ border:none; }}
#vfSpanReadout {{ color:{c['word_bot']}; font-size:30px; font-weight:800;
                  letter-spacing:1px; }}
#vfSpanHint {{ color:{c['section']}; font-size:9px; font-weight:600;
               letter-spacing:1px;
               font-family:'JetBrains Mono','Consolas','DejaVu Sans Mono',monospace; }}
QSlider#vfSpanSlider::groove:horizontal {{ height:6px; border-radius:3px;
                                           background:{c['step_border']}; }}
QSlider#vfSpanSlider::sub-page:horizontal {{ background:{c['accent']};
                                             border-radius:3px; }}
QSlider#vfSpanSlider::handle:horizontal {{ background:{c['title']};
    border:2px solid {c['step_hi']}; width:14px; height:14px; margin:-6px 0;
    border-radius:8px; }}
QSpinBox#vfSpanSpin {{ background:{c['tool_bg']}; color:{c['title']};
    border:1px solid {c['step_border']}; border-radius:6px; padding:4px 6px;
    font-weight:700; }}
QComboBox#vfSpanCombo {{ background:{c['tool_bg']}; color:{c['tool_text']};
    border:1px solid {c['step_border']}; border-radius:6px; padding:5px 8px; }}
QComboBox#vfSpanCombo::drop-down {{ border:none; width:18px; }}
#vfSpanRoot QCheckBox {{ color:{c['tool_text']}; padding:2px 0; }}
QPushButton#vfSpanGo {{ background:{c['tool_bg']}; color:{c['title']};
    border:1px solid {c['step_border']}; border-radius:8px; padding:10px 12px;
    font-weight:800; letter-spacing:0.5px; }}
QPushButton#vfSpanGo:hover {{ background:{c['tool_hover']};
                              border:1px solid {c['step_hi']}; }}
QPushButton#vfSpanGo:checked {{ background:{sem['bad']}; color:#FFFFFF;
                                border:1px solid {sem['bad']}; }}
QPushButton#vfSpanMini {{ background:{c['tool_bg']}; color:{c['tool_text']};
    border:1px solid {c['step_border']}; border-radius:7px; padding:7px 10px;
    font-size:11px; font-weight:700; }}
QPushButton#vfSpanMini:hover {{ background:{c['tool_hover']};
                                border:1px solid {c['step_hi']}; }}
QPushButton#vfSpanMini:disabled {{ color:{c['section']}; }}
QListWidget#vfSpanList {{ background:{c['step_bg']}; color:{c['tool_text']};
    border:1px solid {c['step_border']}; border-radius:8px; padding:3px;
    font-family:'JetBrains Mono','Consolas','DejaVu Sans Mono',monospace;
    font-size:11px; }}
QListWidget#vfSpanList::item {{ padding:4px 6px; border-radius:5px; }}
QListWidget#vfSpanList::item:hover {{ background:{c['tool_hover']}; }}
QListWidget#vfSpanList::item:selected {{ background:{c['step_hi']};
                                         color:{c['badge_text']}; }}
QScrollArea#vfSpanScroll {{ border:none; background:transparent; }}
"""


class SpanInspectorPanel(QDockWidget):
    """The dock. One instance is reused; closing it clears the highlight."""

    def __init__(self, iface, parent=None):
        super().__init__("Span Inspector", parent or iface.mainWindow())
        self.setObjectName("VelocitySpanInspector")
        self.iface = iface
        self._rb = None
        self._spans = []
        self._all_spans = []
        self._total_spans = 0
        self._watched = []
        self._active = False
        self._loading = False
        self._proj_signals = []
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._rescan)

        self.setWidget(self._build_ui())
        self._apply_theme()
        self._watch_project()
        try:
            from .nexus_dock import apply_dock_chrome
            apply_dock_chrome(self)
        except Exception:
            pass

    # ── styling ───────────────────────────────────────────────────────────────
    def _apply_theme(self):
        """Re-style from the live Nexus theme. Safe to call any time."""
        c = _theme()
        # Contrast-check the ok/warn/bad colours against THIS PANEL's card colour,
        # not the QGIS window palette. The panel always paints on the Nexus theme
        # background (every bundled theme is dark), so checking against the QGIS
        # palette would return light-mode colours for a dark card — unreadable.
        sem = {"ok": "#2ea043", "warn": "#e0a020", "bad": "#e5534b"}
        try:
            bg = c.get("step_bg", "#0D1320")
            sem = {k: theme_safe.ensure_contrast(v, bg, 4.5).name()
                   for k, v in sem.items()}
        except Exception:
            pass
        try:
            self._root.setStyleSheet(_build_qss(c, sem))
        except Exception:
            pass
        self._paint_result()

    # ── UI ────────────────────────────────────────────────────────────────────
    def _sec(self, text):
        lbl = QLabel(f"// {text.upper()}")
        lbl.setObjectName("vfSpanSection")
        return lbl

    def _build_ui(self):
        outer = QScrollArea()
        outer.setObjectName("vfSpanScroll")
        outer.setWidgetResizable(True)
        outer.setFrameShape(QFrame.Shape.NoFrame)

        self._root = QWidget()
        self._root.setObjectName("vfSpanRoot")
        v = QVBoxLayout(self._root)
        v.setContentsMargins(14, 12, 14, 14)
        v.setSpacing(9)

        title = QLabel("SPAN INSPECTOR")
        title.setObjectName("vfSpanTitle")
        v.addWidget(title)

        sub = QLabel("Pole → next pole, measured along the cable. Anything longer "
                     "than your limit lights up, and clears itself when you fix it.")
        sub.setObjectName("vfSpanSub")
        sub.setWordWrap(True)
        v.addWidget(sub)

        beta = QLabel("BETA · READ-ONLY — never edits your data")
        beta.setObjectName("vfSpanBeta")
        beta.setWordWrap(True)
        v.addWidget(beta)

        # ── limit ──
        v.addWidget(self._sec("max span"))
        card = QFrame()
        card.setObjectName("vfSpanCard")
        cv = QVBoxLayout(card)
        cv.setContentsMargins(14, 12, 14, 12)
        cv.setSpacing(7)

        self.readout = QLabel("70 m")
        self.readout.setObjectName("vfSpanReadout")
        self.readout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cv.addWidget(self.readout)

        row = QHBoxLayout()
        row.setSpacing(9)
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setObjectName("vfSpanSlider")
        self.slider.setRange(int(span_scan.MIN_LIMIT_M), int(span_scan.MAX_LIMIT_M))
        self.slider.setValue(int(span_scan.DEFAULT_LIMIT_M))
        self.slider.setToolTip("0–100 m. 70 m = ADSS feeder/distribution · 55 m = drops.")
        row.addWidget(self.slider, 1)
        self.spin = QSpinBox()
        self.spin.setObjectName("vfSpanSpin")
        self.spin.setRange(int(span_scan.MIN_LIMIT_M), int(span_scan.MAX_LIMIT_M))
        self.spin.setValue(int(span_scan.DEFAULT_LIMIT_M))
        self.spin.setSuffix(" m")
        self.spin.setFixedWidth(82)
        row.addWidget(self.spin)
        cv.addLayout(row)

        hint = QLabel("70 M ADSS   ·   55 M DROPS")
        hint.setObjectName("vfSpanHint")
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cv.addWidget(hint)
        v.addWidget(card)
        self.slider.valueChanged.connect(self._on_limit)
        self.spin.valueChanged.connect(self._on_limit)

        # ── poles ──
        v.addWidget(self._sec("pole layer"))
        self.pole_combo = QComboBox()
        self.pole_combo.setObjectName("vfSpanCombo")
        self.pole_combo.setToolTip(
            "Spans run between the poles ON each cable. A cable with fewer than two "
            "poles has no spans.")
        self.pole_combo.currentIndexChanged.connect(self._on_poles_changed)
        v.addWidget(self.pole_combo)


        # ── cables ──
        v.addWidget(self._sec("cable layers"))
        self._layer_box = QWidget()
        self._layer_v = QVBoxLayout(self._layer_box)
        self._layer_v.setContentsMargins(10, 8, 10, 8)
        self._layer_v.setSpacing(4)
        self._layer_scroll = QScrollArea()
        self._layer_scroll.setObjectName("vfSpanScroll")
        self._layer_scroll.setWidgetResizable(True)
        self._layer_scroll.setWidget(self._layer_box)
        self._layer_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self._layer_scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._layer_scroll.setSizePolicy(QSizePolicy.Policy.Expanding,
                                         QSizePolicy.Policy.Fixed)
        wrap = QFrame()
        wrap.setObjectName("vfSpanCard")
        wv = QVBoxLayout(wrap)
        wv.setContentsMargins(2, 2, 2, 2)
        wv.addWidget(self._layer_scroll)
        v.addWidget(wrap)
        self._checks = {}

        # ── actions ──
        self.btn_toggle = QPushButton("HIGHLIGHT VIOLATIONS")
        self.btn_toggle.setObjectName("vfSpanGo")
        self.btn_toggle.setCheckable(True)
        self.btn_toggle.setMinimumHeight(40)
        self.btn_toggle.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_toggle.clicked.connect(self._on_toggle)
        v.addWidget(self.btn_toggle)

        nav = QHBoxLayout()
        nav.setSpacing(8)
        self.btn_zoom = QPushButton("Zoom to worst")
        self.btn_zoom.setObjectName("vfSpanMini")
        self.btn_zoom.clicked.connect(self._zoom_worst)
        self.btn_zoom.setEnabled(False)
        nav.addWidget(self.btn_zoom)
        self.btn_refresh = QPushButton("Re-scan")
        self.btn_refresh.setObjectName("vfSpanMini")
        self.btn_refresh.setToolTip("Re-read the layers now (also automatic whenever "
                                    "you edit a cable or a pole).")
        self.btn_refresh.clicked.connect(self._rescan)
        nav.addWidget(self.btn_refresh)
        v.addLayout(nav)

        self.result = QLabel("Not running.")
        self.result.setObjectName("vfSpanResult")
        self.result.setWordWrap(True)
        v.addWidget(self.result)

        v.addWidget(self._sec("violations — click to zoom"))
        self.list = QListWidget()
        self.list.setObjectName("vfSpanList")
        self.list.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.list.setMinimumHeight(190)
        self.list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.list.itemClicked.connect(self._on_pick)
        v.addWidget(self.list, 1)

        outer.setWidget(self._root)
        self._result_kind = "idle"
        self.reload_layers()
        self._restore_settings()
        return outer

    # ── layer discovery (project-agnostic) ────────────────────────────────────
    def reload_layers(self):
        """(Re)build the pole picker and cable checklist from the OPEN project."""
        self._loading = True
        try:
            proj = QgsProject.instance()

            if _alive(self.pole_combo):
                keep = self.pole_combo.currentData()
                self.pole_combo.blockSignals(True)
                self.pole_combo.clear()
                found = span_scan.find_pole_layers(proj)
                for l in found:
                    self.pole_combo.addItem(f"{l.name()}   ({l.featureCount()})", l.id())
                if not found:
                    self.pole_combo.addItem("— no point layer in this project —", None)
                if keep:
                    i = self.pole_combo.findData(keep)
                    if i >= 0:
                        self.pole_combo.setCurrentIndex(i)
                self.pole_combo.blockSignals(False)

            prev = {lid: cb.isChecked() for lid, cb in self._checks.items()
                    if _alive(cb)}
            while self._layer_v.count():
                it = self._layer_v.takeAt(0)
                w = it.widget()
                if w:
                    w.setParent(None)
                    w.deleteLater()
            self._checks = {}
            lyrs = [l for l in proj.mapLayers().values() if span_scan.is_line_layer(l)]
            lyrs.sort(key=lambda l: l.name().lower())
            if not lyrs:
                msg = QLabel("No line layers in this project.")
                msg.setWordWrap(True)
                self._layer_v.addWidget(msg)
            for l in lyrs:
                cb = QCheckBox(f"{l.name()}   ({l.featureCount()})")
                cb.setChecked(prev.get(
                    l.id(), any(h in l.name().lower() for h in _CABLE_HINTS)))
                cb.stateChanged.connect(self._on_layers_changed)
                self._layer_v.addWidget(cb)
                self._checks[l.id()] = cb
            # Height must be a WHOLE number of rows, measured from a real row —
            # row height varies with theme + font, so any hardcoded guess clips a
            # row (top or bottom) and the panel looks broken.
            self._layer_box.adjustSize()
            spacing = self._layer_v.spacing()
            margins = self._layer_v.contentsMargins()
            chrome = margins.top() + margins.bottom() + 4
            first = next((cb for cb in self._checks.values() if _alive(cb)), None)
            row_h = (first.sizeHint().height() if first is not None else 20) + spacing
            visible = max(1, min(len(self._checks) or 1, 5))
            self._layer_scroll.setFixedHeight(visible * row_h + chrome)
        finally:
            self._loading = False

    def _pole_layer(self):
        if not _alive(self.pole_combo):
            return None
        lid = self.pole_combo.currentData()
        return QgsProject.instance().mapLayer(lid) if lid else None

    def _selected_layers(self):
        proj = QgsProject.instance()
        out = []
        for lid, cb in self._checks.items():
            if _alive(cb) and cb.isChecked():
                l = proj.mapLayer(lid)
                if l is not None:
                    out.append(l)
        return out

    # ── per-project memory ────────────────────────────────────────────────────
    def _settings_prefix(self):
        return f"{_SETTINGS_ROOT}/{_project_key()}"

    def _save_settings(self):
        if self._loading:
            return
        try:
            s = QgsSettings()
            p = self._settings_prefix()
            s.setValue(f"{p}/limit", int(self.spin.value()))
            s.setValue(f"{p}/pole", self.pole_combo.currentData() or "")
            s.setValue(f"{p}/cables", [lid for lid, cb in self._checks.items()
                                       if _alive(cb) and cb.isChecked()])
        except Exception:
            pass

    def _restore_settings(self):
        """Bring back this project's limit + layer choices, if we've seen it before."""
        self._loading = True
        try:
            s = QgsSettings()
            p = self._settings_prefix()
            lim = s.value(f"{p}/limit", None)
            if lim is not None:
                try:
                    val = int(span_scan.clamp_limit(lim))
                    self.spin.setValue(val)
                    self.slider.setValue(val)
                    self.readout.setText(f"{val} m")
                except Exception:
                    pass
            pole = s.value(f"{p}/pole", "") or ""
            if pole:
                i = self.pole_combo.findData(pole)
                if i >= 0:
                    self.pole_combo.setCurrentIndex(i)
            cables = s.value(f"{p}/cables", None)
            if cables:
                if isinstance(cables, str):
                    cables = [cables]
                want = set(cables)
                for lid, cb in self._checks.items():
                    if _alive(cb):
                        cb.setChecked(lid in want)
        except Exception:
            pass
        finally:
            self._loading = False

    # ── project tracking (signal-driven; no polling) ──────────────────────────
    def _watch_project(self):
        """Rebuild when the project or its layer set changes — any project, any time."""
        proj = QgsProject.instance()
        for name in ("layersAdded", "layersRemoved", "cleared", "readProject"):
            try:
                getattr(proj, name).connect(self._on_project_changed)
                self._proj_signals.append(name)
            except Exception:
                continue

    def _unwatch_project(self):
        proj = QgsProject.instance()
        for name in self._proj_signals:
            try:
                getattr(proj, name).disconnect(self._on_project_changed)
            except Exception:
                continue
        self._proj_signals = []

    def _on_project_changed(self, *args):
        was_active = self._active
        if was_active:
            self.deactivate()
        try:
            self.reload_layers()
            self._restore_settings()
        except Exception:
            pass
        if was_active:
            self.activate()

    # ── behaviour ─────────────────────────────────────────────────────────────
    def _on_limit(self, value):
        for w in (self.slider, self.spin):
            if _alive(w) and w.value() != value:
                w.blockSignals(True)
                w.setValue(value)
                w.blockSignals(False)
        if _alive(self.readout):
            self.readout.setText(f"{value} m")
        self._save_settings()
        if self._active:
            # Moving the dial does NOT need a re-measure — filter the spans we
            # already have, so the slider stays instant even on a 4,800-pole project.
            self._apply_limit()

    def _on_layers_changed(self, _state=None):
        self._save_settings()
        if self._active:
            self._watch_layers()
            self._schedule()


    def _on_poles_changed(self, _i=None):
        self._save_settings()
        if self._active:
            self._watch_layers()
            self._schedule()

    def _on_toggle(self, checked):
        self.activate() if checked else self.deactivate()

    def activate(self):
        self._active = True
        if _alive(self.btn_toggle):
            self.btn_toggle.setChecked(True)
            self.btn_toggle.setText("HIGHLIGHTING — CLICK TO STOP")
        self._watch_layers()
        self._rescan()

    def deactivate(self):
        """Stop watching and clear the canvas. Safe to call twice."""
        self._active = False
        self._unwatch_layers()
        try:
            self._timer.stop()
        except Exception:
            pass
        self._clear_band()
        self._spans = []
        self._all_spans = []
        self._total_spans = 0
        if _alive(self.list):
            self.list.clear()
        if _alive(self.btn_toggle):
            self.btn_toggle.setChecked(False)
            self.btn_toggle.setText("HIGHLIGHT VIOLATIONS")
        if _alive(self.btn_zoom):
            self.btn_zoom.setEnabled(False)
        self._set_result("Not running.", "idle")

    def _schedule(self):
        if self._active and _alive(self._timer):
            self._timer.start(_DEBOUNCE_MS)

    # ── live edit tracking ────────────────────────────────────────────────────
    def _watch_layers(self):
        """Watch the cables AND the poles — moving a pole changes a span too."""
        self._unwatch_layers()
        targets = list(self._selected_layers())
        pl = self._pole_layer()
        if pl is not None:
            targets.append(pl)
        for l in targets:
            for sig in _EDIT_SIGNALS:
                try:
                    getattr(l, sig).connect(self._on_layer_edited)
                except Exception:
                    continue
            self._watched.append(l)

    def _unwatch_layers(self):
        for l in self._watched:
            if not _alive(l):
                continue
            for sig in _EDIT_SIGNALS:
                try:
                    getattr(l, sig).disconnect(self._on_layer_edited)
                except Exception:
                    continue
        self._watched = []

    def _on_layer_edited(self, *args):
        self._schedule()

    # ── scan + draw ───────────────────────────────────────────────────────────
    def _set_result(self, text, kind="idle"):
        self._result_text = text
        self._result_kind = kind
        self._paint_result()

    def _paint_result(self):
        if not _alive(getattr(self, "result", None)):
            return
        sem = getattr(self, "_sem", {"ok": "#2ea043", "warn": "#e0a020",
                                     "bad": "#e5534b"})
        c = _theme()
        fg = {"ok": sem["ok"], "bad": sem["bad"]}.get(self._result_kind, c["section"])
        self.result.setStyleSheet(
            f"color:{fg}; background:{c['step_bg']}; border:1px solid {fg};"
            " border-radius:8px; padding:9px 11px; font-weight:700;")
        self.result.setText(getattr(self, "_result_text", "Not running."))

    def _rescan(self):
        if not self._active:
            return
        cables = self._selected_layers()
        poles = self._pole_layer()
        proj = QgsProject.instance()
        if not cables:
            self._all_spans = []
            self._spans = []
            self._total_spans = 0
            self._draw()
            self._set_result("Tick at least one cable layer to scan.", "idle")
            return
        if poles is None:
            self._all_spans = []
            self._spans = []
            self._total_spans = 0
            self._draw()
            self._set_result("Pick the pole layer — spans are measured pole to pole.",
                             "idle")
            return
        try:
            # ONE measuring pass; every limit change after this is a cheap filter.
            # Ends always count as span boundaries. Ticking a layer means "measure
            # it" — a separate opt-in was a technical detail leaking into the UI
            # (JJ, 2026-07-23). Backbone cables are unaffected: their end sits on a
            # pole and collapses onto it. Drops become measurable.
            self._all_spans = span_scan.scan_all(cables, poles, proj)
            self._total_spans = len(self._all_spans)
        except Exception as exc:
            self._all_spans = []
            self._spans = []
            self._total_spans = 0
            self._set_result(f"Scan failed: {exc}", "bad")
            return
        self._apply_limit()

    def _apply_limit(self):
        """Re-filter the measured spans against the current limit. No re-measure."""
        limit = span_scan.clamp_limit(self.spin.value() if _alive(self.spin)
                                      else span_scan.DEFAULT_LIMIT_M)
        self._spans = span_scan.over_limit(getattr(self, "_all_spans", []), limit)
        self._draw()
        self._fill_list()
        total, worst, per = span_scan.summarise(self._spans)
        if self._total_spans == 0:
            self._set_result(
                "No pole-to-pole spans found — do these cables have poles on them? "
                "Check the pole layer above.", "idle")
        elif total == 0:
            self._set_result(
                f"✅  All clear — no span over {limit:g} m\n"
                f"{self._total_spans} pole-to-pole spans checked", "ok")
        else:
            bits = "   ".join(f"{k} {v}" for k, v in sorted(per.items()))
            self._set_result(
                f"⚠  {total} of {self._total_spans} spans over {limit:g} m "
                f"· worst {worst:.1f} m\n{bits}", "bad")
        if _alive(self.btn_zoom):
            self.btn_zoom.setEnabled(bool(self._spans))

    def _band(self):
        canvas = self.iface.mapCanvas()
        if not _alive(self._rb):
            self._rb = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.LineGeometry)
            self._rb.setColor(_HL_COLOR)
            self._rb.setWidth(_HL_WIDTH)
        return self._rb

    def _draw(self):
        """One rubber band holding every offending span, drawn along the cable."""
        rb = self._band()
        rb.reset(QgsWkbTypes.GeometryType.LineGeometry)
        proj = QgsProject.instance()
        for s in self._spans:
            lyr = proj.mapLayer(s.layer_id)
            if lyr is None or not s.path:
                continue
            try:
                rb.addGeometry(QgsGeometry.fromPolylineXY(list(s.path)), lyr)
            except Exception:
                continue
        rb.show()

    def _clear_band(self):
        if _alive(self._rb):
            try:
                self._rb.reset(QgsWkbTypes.GeometryType.LineGeometry)
                self._rb.hide()
            except Exception:
                pass
        self._rb = None

    def _fill_list(self):
        if not _alive(self.list):
            return
        self.list.clear()
        for s in self._spans[:500]:
            it = QListWidgetItem(
                f"{s.length_m:7.1f} m   {s.pole_a} → {s.pole_b}   {s.label}")
            it.setToolTip(f"{s.label}  ·  span {s.index}  ·  {s.layer_name}\n"
                          f"pole {s.pole_a} → pole {s.pole_b}\n"
                          f"{s.length_m:.3f} m along the cable")
            it.setData(Qt.ItemDataRole.UserRole, s)
            self.list.addItem(it)
        if len(self._spans) > 500:
            self.list.addItem(QListWidgetItem(f"… and {len(self._spans) - 500} more"))

    # ── navigation ────────────────────────────────────────────────────────────
    def _zoom_to(self, span):
        proj = QgsProject.instance()
        lyr = proj.mapLayer(span.layer_id)
        if lyr is None or not span.path:
            return
        try:
            from qgis.core import QgsCoordinateTransform, QgsRectangle
            rect = QgsRectangle(span.p1, span.p2)
            rect.normalize()
            canvas = self.iface.mapCanvas()
            xform = QgsCoordinateTransform(
                lyr.crs(), canvas.mapSettings().destinationCrs(), proj)
            rect = xform.transformBoundingBox(rect)
            rect.scale(3.0)
            canvas.setExtent(rect)
            canvas.refresh()
        except Exception:
            pass

    def _on_pick(self, item):
        span = item.data(Qt.ItemDataRole.UserRole)
        if span is not None:
            self._zoom_to(span)

    def _zoom_worst(self):
        if self._spans:
            self._zoom_to(self._spans[0])

    # ── teardown ──────────────────────────────────────────────────────────────
    def closeEvent(self, event):
        """Closing the panel must leave no overlay and no live signal behind."""
        try:
            self.deactivate()
        except Exception:
            pass
        try:
            self._unwatch_project()
        except Exception:
            pass
        try:
            super().closeEvent(event)
        except Exception:
            pass


_PANEL = None


def show_span_inspector(iface):
    """Open (or re-show) the Span Inspector. Returns the dock."""
    global _PANEL
    if not _alive(_PANEL):
        _PANEL = SpanInspectorPanel(iface)
        iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, _PANEL)
    else:
        _PANEL.reload_layers()
        _PANEL._restore_settings()
        _PANEL._apply_theme()
    _PANEL.show()
    _PANEL.raise_()
    return _PANEL


def close_span_inspector():
    """Tear down on plugin unload — no dangling rubber band, signal or project hook."""
    global _PANEL
    if _alive(_PANEL):
        for fn in ("deactivate", "_unwatch_project"):
            try:
                getattr(_PANEL, fn)()
            except Exception:
                pass
        try:
            _PANEL.setParent(None)
        except Exception:
            pass
    _PANEL = None
