"""Vuma Step 2 — Generate Span cable routes from Erven midblock boundaries.

ALGORITHM:
  1. Block polygons — unary_union(erven).buffer(2m).buffer(-2m)
  2. Per-block Voronoi skeleton + rear-boundary snap + single-row frontage
  3. Connectors — nearest endpoints within 60m, gap test (max non-erven gap < 30m)
  4. MST — Kruskal connects all spines + POP into ONE tree
  5. Connectivity gate — abort write if > 1 component
  6. Final clip — trim routes to erven.buffer(5)

STATUS: [x] BUILT
"""

# claude:approved-destructive

from qgis.PyQt.QtCore import QMetaType
import datetime
import json
import tempfile
import subprocess
from pathlib import Path

from PyQt5.QtCore import QVariant
from PyQt5.QtWidgets import QApplication
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsLayerTreeGroup,
    QgsPointXY,
    QgsProject,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsWkbTypes,
)

MAX_DROP_LENGTH = 65.0


def _python_exe():
    """Dev venv if present, else QGIS's own Python (teammates have no venv)."""
    venv = Path.home() / ".qgis-venv" / "Scripts" / "python.exe"
    if venv.exists():
        return str(venv)
    import sys
    return sys.executable


VENV_PYTHON = _python_exe()


def _get(name):
    from qgis.core import QgsVectorLayer
    layers = QgsProject.instance().mapLayersByName(name)
    lyr = layers[0] if layers else None
    return lyr if isinstance(lyr, QgsVectorLayer) else None


def _get_any(*names):
    for n in names:
        lyr = _get(n)
        if lyr is not None:
            return lyr
    return None


def _epsg_for_lon(lon):
    if lon < 24:
        return 32734
    if lon < 30:
        return 32735
    return 32736


def _export_geojson(layer, path):
    opts = QgsVectorFileWriter.SaveVectorOptions()
    opts.driverName = "GeoJSON"
    opts.fileEncoding = "UTF-8"
    QgsVectorFileWriter.writeAsVectorFormatV3(
        layer, str(path), layer.transformContext(), opts
    )


def _version_existing(path: Path):
    if not path.exists():
        return
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    stem = path.stem
    success = True
    for ext in [".shp", ".shx", ".dbf", ".prj", ".cpg"]:
        src = path.with_suffix(ext)
        if src.exists():
            dst = path.with_name(f"{stem}_{ts}{ext}")
            try:
                src.rename(dst)
            except PermissionError:
                try:
                    src.unlink()
                    success = False
                except PermissionError:
                    pass
    if success:
        print(f"  Existing Span.shp versioned → {stem}_{ts}.shp")
    else:
        print("  Existing Span.shp deleted (was locked — could not rename)")


def vuma_step_02_spans():
    print(f"\n{'=' * 60}")
    print("  VUMA STEP 2 — Span Routes (Voronoi + rear-snap + MST)")
    print(f"{'=' * 60}")

    proj = QgsProject.instance()
    home = Path(proj.homePath())

    for lyr_id in [l.id() for l in proj.mapLayersByName("Span")]:
        proj.removeMapLayer(lyr_id)
    import gc as _gc; _gc.collect()
    QApplication.processEvents()

    out_shp = home / "Span.shp"
    _version_existing(out_shp)
    if out_shp.exists():
        QgsVectorFileWriter.deleteShapeFile(str(out_shp))
        for _ext in ('.shp', '.shx', '.dbf', '.prj', '.cpg', '.qmd'):
            _f = out_shp.with_suffix(_ext)
            if _f.exists():
                try:
                    _f.unlink()
                except Exception:
                    pass
        print("  Warning: Span.shp was locked — deleted residual files")

    log_dir = home / "logs"
    log_dir.mkdir(exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = log_dir / f"step2_span_{ts}.log"
    log_lines: list = []

    def log(msg):
        print(f"  {msg}")
        log_lines.append(msg)

    erven_lyr = _get_any("Erven", "Tsakane Erven")
    dp_lyr    = _get_any("Demand Points", "DemandPoints", "Building Polygon")
    pop_lyr   = _get_any("Node", "POP")
    aoi_lyr   = _get_any("P2 AOI Poly", "AOI",
                         "Tsakane Zone 1", "Tsakane Zone 2", "Tsakane Zone 3",
                         "Phomolong")

    ok = True
    if erven_lyr is None or erven_lyr.featureCount() == 0:
        log("ERROR: 'Erven' / 'Tsakane Erven' layer not found or empty — run Step 1b first.")
        ok = False
    if dp_lyr is None or dp_lyr.featureCount() == 0:
        log("ERROR: 'Demand Points' layer not found or empty.")
        ok = False
    if pop_lyr is None:
        log("ERROR: 'Node' / 'POP' layer not found.")
        ok = False
    if not ok:
        log("Aborting.")
        log_path.write_text("\n".join(log_lines), encoding="utf-8")
        return

    log(f"Erven:         {erven_lyr.featureCount():,}")
    log(f"Demand Points: {dp_lyr.featureCount():,}")
    log(f"POP layer:     '{pop_lyr.name()}'")

    _pop_feats = list(pop_lyr.getFeatures())
    if not _pop_feats:
        log("ERROR: POP / Node layer has no features.")
        log_path.write_text("\n".join(log_lines), encoding="utf-8")
        return
    pop_pt = _pop_feats[0].geometry().asPoint()
    if aoi_lyr is not None:
        _aoi_feats = list(aoi_lyr.getFeatures())
        if not _aoi_feats:
            log("WARNING: AOI layer found but has no features — using POP longitude for UTM zone.")
            lon_centre = pop_pt.x()
        else:
            aoi_centroid = _aoi_feats[0].geometry().centroid().asPoint()
            lon_centre = aoi_centroid.x()
    else:
        lon_centre = pop_pt.x()
    utm_epsg = _epsg_for_lon(lon_centre)
    log(f"Working CRS:   EPSG:{utm_epsg}  (lon={lon_centre:.2f})")

    tmp_dir   = Path(tempfile.mkdtemp())
    erven_tmp = tmp_dir / "erven.geojson"
    dp_tmp    = tmp_dir / "demand_points.geojson"
    pop_tmp   = tmp_dir / "pop.geojson"
    aoi_tmp   = tmp_dir / "aoi.geojson"
    out_spans = tmp_dir / "spans.geojson"
    out_qa    = tmp_dir / "qa.json"

    log("Exporting layers to temp files…")
    _export_geojson(erven_lyr, erven_tmp)
    _export_geojson(dp_lyr,    dp_tmp)
    _export_geojson(pop_lyr,   pop_tmp)
    has_aoi = aoi_lyr is not None
    if has_aoi:
        _export_geojson(aoi_lyr, aoi_tmp)

    # Locate pattern library — this script's own folder first, then a home fallback.
    _vuma_dirs = []
    try:
        _vuma_dirs.append(Path(__file__).resolve().parent)
    except NameError:
        pass
    _vuma_dirs.append(Path.home() / "OneDrive - blitzfibre.com/Documents/Workspace/QGIS/fibre_automation/vuma")
    _lib_candidates = [d / "tsakane_pattern_library.json" for d in _vuma_dirs]
    _lib_path = next((p for p in _lib_candidates if p.exists()), None)
    if _lib_path is not None:
        log(f"Pattern library: {_lib_path.name} ({_lib_path.stat().st_size // 1024} KB)")
    else:
        log("Pattern library: not found — using classify_block() dispatch only")

    # Load crossing stats — informational only. Do NOT apply p90 directly as MAX_GAP_M.
    # Tsakane has narrow informal tracks (p50=7.8m); formal townships like Mohadin have
    # wider road reserves (12-30m). MAX_GAP_M stays at the project default (30m).
    _cross_candidates = [d / "tsakane_crossings.json" for d in _vuma_dirs]
    _cross_path = next((p for p in _cross_candidates if p.exists()), None)
    if _cross_path is not None:
        try:
            _cstats = json.loads(_cross_path.read_text(encoding='utf-8'))
            log(f"Crossing stats:  Tsakane p50={_cstats['gap_length']['p50']}m  "
                f"p90={_cstats['gap_length']['p90']}m  (reference only)")
        except Exception:
            pass

    # Project-adaptive parameters
    _proj_name = proj.baseName().lower()
    _is_tsakane = "tsakane" in _proj_name
    _span_params = {
        # Tsakane informal settlement: narrow roads, tight blocks, sweep-proven values
        # Mohadin / formal grid: wider road reserves need larger gap tolerance
        "max_gap_m":    18.0  if _is_tsakane else 50.0,
        "block_buf_m":  0.5   if _is_tsakane else 2.0,
        "rear_snap_m":  80.0,   # same for both — sweep ceiling
        "use_rear_spine": True, # rear back-fence chain as primary double-row method
    }
    log(f"Span params: gap={_span_params['max_gap_m']}m  buf={_span_params['block_buf_m']}m  "
        f"rear_snap={_span_params['rear_snap_m']}m  rear_spine={_span_params['use_rear_spine']}")

    log("Running span worker…")
    worker_result = _run_span_worker(
        tmp_dir, erven_tmp, dp_tmp, pop_tmp,
        aoi_tmp if has_aoi else None,
        out_spans, out_qa, utm_epsg, MAX_DROP_LENGTH,
        pattern_library_path=_lib_path,
        **_span_params,
    )
    log(f"Worker exit code: {worker_result.returncode}")
    for line in worker_result.stdout.splitlines()[-25:]:
        log(f"  [worker] {line}")
    if worker_result.returncode != 0:
        for line in worker_result.stderr.splitlines()[-10:]:
            log(f"  [stderr] {line}")

    if not out_spans.exists():
        log("ERROR: span worker did not produce output — see log above.")
        if out_qa.exists():
            qa = json.loads(out_qa.read_text(encoding="utf-8"))
            if qa.get("connectivity_error"):
                log(f"ERROR: {qa['connectivity_error']}")
            if qa.get("isolated_spine_count"):
                log(f"  {qa['isolated_spine_count']} isolated spines — corridor blocked all connectors to them")
        log_path.write_text("\n".join(log_lines), encoding="utf-8")
        return

    qa: dict = {}
    if out_qa.exists():
        qa = json.loads(out_qa.read_text(encoding="utf-8"))
    spans_fc   = json.loads(out_spans.read_text(encoding="utf-8"))
    span_feats = spans_fc.get("features", [])
    log(f"Span features: {len(span_feats):,}")

    if not span_feats:
        log("ERROR: worker returned 0 span features.")
        log_path.write_text("\n".join(log_lines), encoding="utf-8")
        return

    # Write to a fresh temp path first — avoids any QGIS file-handle lock on Span.shp
    log("Writing Span.shp (CRS: EPSG:4326)…")
    shp_tmp = tmp_dir / "Span_out.shp"
    fields = QgsFields()
    fields.append(QgsField("id",     QMetaType.Type.Int))
    fields.append(QgsField("Lenght", QMetaType.Type.Double))
    fields.append(QgsField("type",   QMetaType.Type.QString))

    w_opts = QgsVectorFileWriter.SaveVectorOptions()
    w_opts.driverName = "ESRI Shapefile"
    w_opts.fileEncoding = "UTF-8"

    writer = QgsVectorFileWriter.create(
        str(shp_tmp), fields, QgsWkbTypes.Type.LineString,
        QgsCoordinateReferenceSystem("EPSG:4326"),
        proj.transformContext(), w_opts,
    )
    if writer.hasError():
        log(f"ERROR creating Span.shp: {writer.errorMessage()}")
        del writer
        log_path.write_text("\n".join(log_lines), encoding="utf-8")
        return

    written = 0
    for fd in span_feats:
        gd     = fd.get("geometry", {})
        props  = fd.get("properties", {})
        gtype  = gd.get("type", "")
        coords = gd.get("coordinates", [])
        if gtype == "LineString":
            rings = [coords]
        elif gtype == "MultiLineString":
            rings = coords if coords else []
        else:
            continue
        for ring in rings:
            pts = [QgsPointXY(x, y) for x, y in ring]
            if len(pts) < 2:
                continue
            feat = QgsFeature(fields)
            feat.setGeometry(QgsGeometry.fromPolylineXY(pts))
            feat.setAttribute("id",     props.get("id", written + 1))
            feat.setAttribute("Lenght", round(props.get("length_m", 0), 2))
            feat.setAttribute("type",   props.get("type", "spine"))
            writer.addFeature(feat)
            written += 1
    del writer

    # Copy temp shapefile components to project home (replaces any locked previous file)
    import shutil as _shutil
    for _ext in ('.shp', '.shx', '.dbf', '.prj', '.cpg'):
        _src = shp_tmp.with_suffix(_ext)
        if _src.exists():
            try:
                _shutil.copy2(str(_src), str(out_shp.with_suffix(_ext)))
            except Exception as _ce:
                log(f"WARN: could not copy Span{_ext}: {_ce}")
    log(f"Written: {written:,} features → {out_shp}")

    from qgis.utils import iface as _iface_raw
    span_layer = QgsVectorLayer(str(out_shp), "Span", "ogr")
    if not span_layer.isValid():
        log("ERROR: Span.shp failed to load as QGIS layer.")
    else:
        proj.addMapLayer(span_layer, True)
        root = proj.layerTreeRoot()
        node = root.findLayer(span_layer.id())
        if node:
            clone = node.clone()
            root.insertChildNode(0, clone)
            parent = node.parent()
            if isinstance(parent, QgsLayerTreeGroup):
                parent.removeChildNode(node)
        _iface_raw.mapCanvas().refreshAllLayers()
        _iface_raw.mapCanvas().refresh()
        log("Span layer added to project root.")

    lengths = [fd.get("properties", {}).get("length_m", 0) for fd in span_feats]
    if lengths:
        import statistics
        total_m = sum(lengths)
        med_m   = statistics.median(lengths)
        mean_m  = statistics.mean(lengths)
        n_spines = (qa.get('skeleton_spines', 0) + qa.get('single_row_spines', 0)
                    + qa.get('stub_spines', 0))
        n_conn   = qa.get('mst_connectors', 0)
        log("")
        log("── QA SUMMARY ──────────────────────────────────────────")
        log(f"  Span features:       {written:,}  (spines={n_spines}  connectors={n_conn})")
        log(f"  Total length:        {total_m/1000:.2f} km")
        log(f"  Length stats:        min={min(lengths):.0f}m  median={med_m:.0f}m  "
            f"mean={mean_m:.0f}m  max={max(lengths):.0f}m")
        log(f"  Block polygons:      {qa.get('total_blocks', '?')}  "
            f"(double={qa.get('double_row_blocks','?')}  "
            f"single={qa.get('single_row_blocks','?')}  "
            f"stub={qa.get('stub_blocks','?')}  "
            f"tiny={qa.get('tiny_blocks','?')})")
        log(f"  Spines:              {n_spines}  "
            f"(skeleton={qa.get('skeleton_spines',0)}  "
            f"frontage={qa.get('single_row_spines',0)}  "
            f"stub={qa.get('stub_spines',0)})")
        log(f"  Rear-boundary snaps: {qa.get('rear_snaps','?')} vertices / {qa.get('blocks_with_rear','?')} blocks")
        log(f"  Connector search:    corridor-rejected {qa.get('corridor_rejected','?')}  "
            f"fallback open-crossings: {qa.get('fallback_connectors', 0)}")
        log(f"  QA gate:             corridor_violations={qa.get('corridor_violations','?')}  "
            f"open_ground_spans={qa.get('open_ground_spans','?')}  "
            f"dp_coverage_ok={qa.get('dp_coverage_ok','?')}  "
            f"gate={'PASS' if qa.get('qa_gate_pass') else 'FAIL'}")
        log(f"  Corridor-clipped:    {qa.get('corridor_clipped','?')} features trimmed at final clip")
        log(f"  Connectivity:        {qa.get('n_components', '?')} component(s)  "
            f"{qa.get('nodes_reachable', '?')}/{qa.get('nodes_total', '?')} nodes from POP")
        log(f"  Reachable DPs:       {qa.get('reachable', '?')} / {qa.get('total_dp', '?')}")
        log(f"  Servable DPs:        {qa.get('servable_reachable', '?')} reachable / "
            f"{qa.get('servable_unreachable', '?')} unreachable  (of {qa.get('n_servable', '?')} servable)")
        log(f"  Orphan DPs:          {qa.get('n_orphan', '?')}  (no erf within 5m — not eligible for midblock service)")
        if qa.get("servable_unreachable_ids"):
            log(f"  Servable unreachable sample: {qa['servable_unreachable_ids'][:10]}")
        if qa.get("orphan_ids_sample"):
            log(f"  Orphan DP sample:    {qa['orphan_ids_sample'][:10]}")
        if qa.get("open_crossing_review"):
            for ocr in qa['open_crossing_review']:
                log(f"  PLANNER REVIEW — open-crossing: direct={ocr['direct_m']}m  "
                    f"perimeter={ocr.get('perimeter_m', 'N/A')}m")
        log(f"  POP → nearest span:  {qa.get('pop_dist_m', '?')} m")
        for w in _sanity_check(med_m, written, qa):
            log(f"  WARN: {w}")
        log("────────────────────────────────────────────────────────")

    log_path.write_text("\n".join(log_lines), encoding="utf-8")
    log(f"Log → {log_path}")
    print(f"\n{'=' * 60}\n")


def _sanity_check(med_m, n_feats, qa):
    warns = []
    n_blocks = qa.get('total_blocks', 0)
    n_spines = qa.get('skeleton_spines', 0)
    if n_blocks > 0 and n_spines > 0:
        ratio = n_spines / n_blocks
        if ratio > 3:
            warns.append(f"{ratio:.1f} spines/block — skeleton over-generating")
        if ratio < 0.5:
            warns.append(f"{ratio:.1f} spines/block — spine detection missing blocks")
    if med_m < 40:
        warns.append(f"median {med_m:.0f}m < 40m — spines too short")
    if med_m > 2000:
        warns.append(f"median {med_m:.0f}m > 2000m — blocks may be over-merged")
    if n_feats < 5:
        warns.append(f"only {n_feats} spans — check block detection")
    return warns


def _run_span_worker(tmp_dir, erven_path, dp_path, pop_path, aoi_path,
                     out_spans, out_qa, utm_epsg, max_drop_m,
                     pattern_library_path=None, max_gap_m=18.0,
                     block_buf_m=0.5, rear_snap_m=80.0, use_rear_spine=True):
    def fwd(p):
        return str(p).replace("\\", "/") if p else ""

    config = {
        "erven_path":           fwd(erven_path),
        "dp_path":              fwd(dp_path),
        "pop_path":             fwd(pop_path),
        "aoi_path":             fwd(aoi_path) if aoi_path else "",
        "out_spans":            fwd(out_spans),
        "out_qa":               fwd(out_qa),
        "utm_epsg":             utm_epsg,
        "max_drop_m":           max_drop_m,
        "pattern_library_path": fwd(pattern_library_path) if pattern_library_path else "",
        "max_gap_m":            float(max_gap_m),
        "block_buf_m":          float(block_buf_m),
        "rear_snap_m":          float(rear_snap_m),
        "use_rear_spine":       bool(use_rear_spine),
    }
    cfg_path    = tmp_dir / "config.json"
    worker_path = tmp_dir / "span_worker.py"
    cfg_path.write_text(json.dumps(config), encoding="utf-8")
    worker_path.write_text(_WORKER_CODE, encoding="utf-8")

    import sys as _sys
    stdout_file = tmp_dir / "worker_stdout.txt"
    stderr_file = tmp_dir / "worker_stderr.txt"
    flags = 0
    if _sys.platform == "win32":
        flags = subprocess.CREATE_NO_WINDOW

    with open(stdout_file, "w", encoding="utf-8") as fout, \
         open(stderr_file, "w", encoding="utf-8") as ferr:
        result = subprocess.run(
            [VENV_PYTHON, "-u", str(worker_path), str(cfg_path)],
            stdout=fout, stderr=ferr,
            timeout=600,
            creationflags=flags,
        )

    stdout_txt = stdout_file.read_text(encoding="utf-8", errors="replace") if stdout_file.exists() else ""
    stderr_txt = stderr_file.read_text(encoding="utf-8", errors="replace") if stderr_file.exists() else ""

    for line in stdout_txt.splitlines():
        print(f"  [worker] {line}")
    if result.returncode != 0:
        print(f"  [worker] STDERR:\n{stderr_txt[-2000:]}")

    class _Result:
        returncode = result.returncode
        stdout = stdout_txt
        stderr = stderr_txt

    return _Result()


_WORKER_CODE = r'''
import json
import sys
from pathlib import Path
from collections import defaultdict
from heapq import heappush, heappop

import numpy as np
import geopandas as gpd
from shapely.geometry import LineString, MultiLineString, Point, Polygon, MultiPolygon
from shapely.ops import unary_union, linemerge
from shapely.strtree import STRtree
from scipy.spatial import Voronoi
from pyproj import Transformer

# ── Road-side detection (matches builder's count_road_facing_sides) ───────────

def count_road_facing_sides(block, block_strtree, all_blocks, buffer_m=6.0):
    """Count MRR sides that face roads/open space (not adjacent blocks).

    Uses block adjacency: a side is road-facing if no other block lies within
    buffer_m of the outward probe point.  Fast because block_strtree returns
    only nearby candidates instead of testing a complex erven_union polygon.
    """
    mrr    = block.minimum_rotated_rectangle
    coords = list(mrr.exterior.coords)[:4]
    cx, cy = block.centroid.x, block.centroid.y
    n_road = 0
    for i in range(4):
        a = coords[i]; b = coords[(i + 1) % 4]
        mx = (a[0] + b[0]) / 2; my = (a[1] + b[1]) / 2
        dx = b[0] - a[0]; dy = b[1] - a[1]
        L  = (dx * dx + dy * dy) ** 0.5
        if L < 1e-9:
            continue
        nx = -dy / L; ny = dx / L
        if (mx - cx) * nx + (my - cy) * ny < 0:
            nx = -nx; ny = -ny
        probe = Point(mx + nx * buffer_m, my + ny * buffer_m)
        nearby = block_strtree.query(probe.buffer(buffer_m))
        has_neighbour = any(
            all_blocks[j] is not block and all_blocks[j].distance(probe) < buffer_m
            for j in nearby
        )
        if not has_neighbour:
            n_road += 1
    return n_road


# ── MRR centreline alignment (M3 fix for regular straight blocks) ─────────────

def align_to_mrr_centreline(spine, block):
    """Project spine endpoints onto the MRR centreline.

    For regular rectangular blocks this snaps the Voronoi spine exactly onto
    the geometric centreline of the block, eliminating Voronoi wander.
    Only called for '1_centreline_straight' pattern with high regularity.
    """
    mrr    = block.minimum_rotated_rectangle
    coords = list(mrr.exterior.coords)[:4]
    sides  = sorted(
        (((coords[(i+1)%4][0]-coords[i][0])**2 +
          (coords[(i+1)%4][1]-coords[i][1])**2)**0.5, i)
        for i in range(4)
    )
    # Centreline connects midpoints of the two SHORT sides (indices 0 and 1)
    def side_mid(idx):
        i = sides[idx][1]
        return ((coords[i][0] + coords[(i+1)%4][0]) / 2,
                (coords[i][1] + coords[(i+1)%4][1]) / 2)
    m1 = side_mid(0); m2 = side_mid(1)
    centreline = LineString([m1, m2])
    if centreline.length < 5.0:
        return spine
    s_pt  = Point(list(spine.coords)[0])
    e_pt  = Point(list(spine.coords)[-1])
    s_proj = centreline.interpolate(centreline.project(s_pt))
    e_proj = centreline.interpolate(centreline.project(e_pt))
    new_spine = LineString([(s_proj.x, s_proj.y), (e_proj.x, e_proj.y)])
    return new_spine if new_spine.length >= 5.0 else spine


# ── MBR centreline spine (PRIMARY method) ─────────────────────────────────────

def mbr_centreline_spine(block, min_spine_m=20.0):
    """Straight line connecting midpoints of the two short sides of the block MBR.

    This is the correct midblock spine: it runs parallel to the streets through
    the geometric centre of all touching erven, full length of the block.
    """
    mrr = block.minimum_rotated_rectangle
    coords = list(mrr.exterior.coords)[:4]
    sides = sorted(
        (((coords[(i+1)%4][0]-coords[i][0])**2 +
          (coords[(i+1)%4][1]-coords[i][1])**2)**0.5, i)
        for i in range(4)
    )
    def side_mid(k):
        i = sides[k][1]
        return ((coords[i][0] + coords[(i+1)%4][0]) / 2,
                (coords[i][1] + coords[(i+1)%4][1]) / 2)
    m1 = side_mid(0); m2 = side_mid(1)
    line = LineString([m1, m2])
    return [line] if line.length >= min_spine_m else []


# ── geometry helpers ──────────────────────────────────────────────────────────

def to_poly_list(geom):
    if geom is None or geom.is_empty:
        return []
    if isinstance(geom, Polygon):
        return [geom]
    if isinstance(geom, MultiPolygon):
        return list(geom.geoms)
    if hasattr(geom, 'geoms'):
        return [g for g in geom.geoms if isinstance(g, Polygon)]
    return []


def line_from_geom(geom):
    if geom is None or geom.is_empty:
        return []
    if isinstance(geom, LineString):
        return [geom] if geom.length > 0.1 else []
    if isinstance(geom, MultiLineString):
        return [g for g in geom.geoms if g.length > 0.1]
    if hasattr(geom, 'geoms'):
        result = []
        for g in geom.geoms:
            result.extend(line_from_geom(g))
        return result
    return []


def snap_pt(x, y, tol=0.5):
    return (round(x / tol) * tol, round(y / tol) * tol)


def merge_to_list(merged):
    if isinstance(merged, LineString):
        return [merged]
    if isinstance(merged, MultiLineString):
        return list(merged.geoms)
    if hasattr(merged, 'geoms'):
        return [g for g in merged.geoms if isinstance(g, LineString)]
    return []


# ── graph primitives ──────────────────────────────────────────────────────────

def connected_components(adj):
    visited = set()
    comps = []
    for node in adj:
        if node in visited:
            continue
        comp = set()
        stack = [node]
        while stack:
            n = stack.pop()
            if n in visited:
                continue
            visited.add(n)
            comp.add(n)
            for nb, _ in adj[n]:
                if nb not in visited:
                    stack.append(nb)
        comps.append(comp)
    return comps


def dijkstra_farthest(adj, edge_list, start):
    INF = float('inf')
    dist = defaultdict(lambda: INF)
    dist[start] = 0.0
    prev = {start: None}
    pq = [(0.0, 0, start)]
    counter = 1
    farthest = start
    while pq:
        d, _, node = heappop(pq)
        if d > dist[node]:
            continue
        for nb, eid in adj[node]:
            nd = d + edge_list[eid][2]
            if nd < dist[nb]:
                dist[nb] = nd
                prev[nb] = node
                heappush(pq, (nd, counter, nb))
                counter += 1
                if nd > dist[farthest]:
                    farthest = nb
    return farthest, prev


def graph_diameter_path(adj, edge_list):
    if not adj:
        return []
    start = next(iter(adj))
    far1, _     = dijkstra_farthest(adj, edge_list, start)
    far2, prev2 = dijkstra_farthest(adj, edge_list, far1)
    path = []
    node = far2
    while node is not None:
        path.append(node)
        node = prev2.get(node)
    path.reverse()
    return path


# ── Block classification ──────────────────────────────────────────────────────

def classify_block(block, block_erven_geoms):
    if len(block_erven_geoms) < 4:
        return 'stub', 0.0, 0.0
    mrr = block.minimum_rotated_rectangle
    mrr_coords = list(mrr.exterior.coords)[:4]
    sides = []
    for i in range(4):
        dx = mrr_coords[(i + 1) % 4][0] - mrr_coords[i][0]
        dy = mrr_coords[(i + 1) % 4][1] - mrr_coords[i][1]
        sides.append((dx * dx + dy * dy) ** 0.5)
    sides.sort()
    short_side = sides[0]
    depths = sorted(g.area ** 0.5 for g in block_erven_geoms if g.area > 10)
    if not depths:
        return 'stub', short_side, 0.0
    median_depth = depths[len(depths) // 2]
    if short_side < 1.6 * median_depth:
        return 'single', short_side, median_depth
    return 'double', short_side, median_depth


# ── Rear-boundary snapping ────────────────────────────────────────────────────

def find_rear_boundary(block_erven_geoms, min_seg_m=3.0):
    if len(block_erven_geoms) < 2:
        return None
    erf_tree = STRtree(block_erven_geoms)
    shared_segs = []
    for i, ea in enumerate(block_erven_geoms):
        for j in erf_tree.query(ea):
            if j <= i:
                continue
            try:
                inter = ea.intersection(block_erven_geoms[j])
            except Exception:
                continue
            if inter.is_empty:
                continue
            for seg in line_from_geom(inter):
                if seg.length >= min_seg_m:
                    shared_segs.append(seg)
    if not shared_segs:
        return None
    combined = unary_union(shared_segs)
    try:
        merged = linemerge(combined)
    except ValueError:
        merged = combined  # already a single LineString — linemerge doesn't accept bare LS
    return merged if not merged.is_empty else None


def snap_to_rear_boundary(spine, block_erven_geoms, snap_tol_m=8.0):
    rear_chain = find_rear_boundary(block_erven_geoms)
    if rear_chain is None:
        return spine, 0
    coords = list(spine.coords)
    snapped = []
    n_snapped = 0
    for c in coords:
        pt = Point(c)
        nearest = rear_chain.interpolate(rear_chain.project(pt))
        if pt.distance(nearest) <= snap_tol_m:
            snapped.append((nearest.x, nearest.y))
            n_snapped += 1
        else:
            snapped.append(c)
    clean = [snapped[0]]
    for c in snapped[1:]:
        if abs(c[0] - clean[-1][0]) > 1e-9 or abs(c[1] - clean[-1][1]) > 1e-9:
            clean.append(c)
    return (LineString(clean), n_snapped) if len(clean) >= 2 else (spine, 0)


# ── Rear-boundary spine (primary double-row method) ──────────────────────────

def rear_boundary_spine_method(block_erven_geoms, min_spine_m=20.0):
    """Generate spine from merged shared erf back-fence edges.

    Primary method for double-row blocks: the shared edges between
    back-to-back erven rows ARE the cable route — no MBR approximation needed.
    Returns list of LineStrings (longest first), empty list if insufficient edges.
    """
    chain = find_rear_boundary(block_erven_geoms)
    if chain is None or chain.is_empty:
        return []
    lines = line_from_geom(chain)
    if not lines:
        return []
    try:
        merged = linemerge(unary_union(lines))
    except Exception:
        merged = chain
    result = sorted(
        [seg for seg in line_from_geom(merged) if seg.length >= min_spine_m - 0.05],
        key=lambda l: l.length, reverse=True,
    )
    return result


# ── Rear-boundary trim ───────────────────────────────────────────────────────

def trim_spine_to_rear_boundary(spine, block_erven_geoms, min_keep_ratio=0.3):
    """Trim spine endpoints to the extent of the rear-boundary chain.

    Projects all rear-boundary chain vertices onto the spine arc to find the
    [t_min, t_max] range covered by the chain, then slices the spine to that
    range.  Result: the cable terminates at the last erf back-corner, not at
    the road edge of the block polygon.

    Falls back to original spine if:
    - no rear boundary found (too few erven)
    - chain extent is < min_keep_ratio of the spine (would trim too aggressively)
    - trimmed result would be < 5 m
    """
    chain = find_rear_boundary(block_erven_geoms)
    if chain is None or chain.is_empty:
        return spine
    spine_len = spine.length
    if spine_len < 1.0:
        return spine

    # Collect all chain vertex coordinates
    if isinstance(chain, LineString):
        chain_coords = list(chain.coords)
    elif isinstance(chain, MultiLineString):
        chain_coords = [c for line in chain.geoms for c in line.coords]
    else:
        try:
            chain_coords = [c for geom in chain.geoms for c in geom.coords]
        except Exception:
            return spine
    if not chain_coords:
        return spine

    # Project each chain vertex onto the spine arc length parameterisation
    projections = [spine.project(Point(p)) for p in chain_coords]
    t_min = max(0.0, min(projections))
    t_max = min(spine_len, max(projections))

    # Safety: don't collapse the spine if the chain appears very short relative to it
    if (t_max - t_min) < min_keep_ratio * spine_len:
        return spine
    if t_max - t_min < 5.0:
        return spine

    try:
        from shapely.ops import substring
        trimmed = substring(spine, t_min, t_max)
    except Exception:
        # Fallback: interpolate endpoints (loses curve for Voronoi spines, acceptable)
        p1 = spine.interpolate(t_min)
        p2 = spine.interpolate(t_max)
        trimmed = LineString([(p1.x, p1.y), (p2.x, p2.y)])

    if trimmed is None or trimmed.is_empty or trimmed.length < 5.0:
        return spine
    return trimmed


# ── Road-frontage spine ───────────────────────────────────────────────────────

def road_frontage_spine(block, offset_m=2.0, min_spine_m=20.0):
    mrr = block.minimum_rotated_rectangle
    mrr_coords = list(mrr.exterior.coords)[:4]
    sides = []
    for i in range(4):
        a = mrr_coords[i]; b = mrr_coords[(i + 1) % 4]
        dx, dy = b[0] - a[0], b[1] - a[1]
        sides.append(((dx * dx + dy * dy) ** 0.5, a, b))
    sides.sort(key=lambda s: s[0], reverse=True)
    L0, a0, b0 = sides[0]; L1, a1, b1 = sides[1]
    long_ux = (b0[0] - a0[0]) / L0; long_uy = (b0[1] - a0[1]) / L0
    c0x, c0y = (a0[0] + b0[0]) / 2, (a0[1] + b0[1]) / 2
    c1x, c1y = (a1[0] + b1[0]) / 2, (a1[1] + b1[1]) / 2
    dx_pp, dy_pp = c1x - c0x, c1y - c0y
    d_pp = (dx_pp * dx_pp + dy_pp * dy_pp) ** 0.5
    if d_pp < 1e-9:
        return None
    perp_ux = dx_pp / d_pp; perp_uy = dy_pp / d_pp
    ring_coords = list(block.exterior.coords)
    len0 = len1 = 0.0
    for k in range(len(ring_coords) - 1):
        px, py = ring_coords[k]; qx, qy = ring_coords[k + 1]
        sl = ((qx - px) ** 2 + (qy - py) ** 2) ** 0.5
        if sl < 1.0:
            continue
        sdx, sdy = (qx - px) / sl, (qy - py) / sl
        if abs(long_ux * sdx + long_uy * sdy) < 0.8:
            continue
        mx, my = (px + qx) / 2, (py + qy) / 2
        proj = ((mx - c0x) * perp_ux + (my - c0y) * perp_uy) / d_pp
        if proj < 0.5:
            len0 += sl
        else:
            len1 += sl
    if len1 > len0:
        front_a, front_b = a1, b1; inward_ux, inward_uy = -perp_ux, -perp_uy
    else:
        front_a, front_b = a0, b0; inward_ux, inward_uy = perp_ux, perp_uy
    off_a = (front_a[0] + inward_ux * offset_m, front_a[1] + inward_uy * offset_m)
    off_b = (front_b[0] + inward_ux * offset_m, front_b[1] + inward_uy * offset_m)
    clipped = LineString([off_a, off_b]).intersection(block)
    if clipped.is_empty:
        clipped = LineString([off_a, off_b])
    lines = merge_to_list(clipped)
    if not lines:
        return None
    best = max(lines, key=lambda l: l.length)
    return best if best.length >= min_spine_m else None


# ── Stub spine ────────────────────────────────────────────────────────────────

def stub_spine(block, min_spine_m=20.0):
    ring = list(block.exterior.coords)
    best_seg = None; best_len = 0.0
    for i in range(len(ring) - 1):
        dx = ring[i + 1][0] - ring[i][0]; dy = ring[i + 1][1] - ring[i][1]
        L = (dx * dx + dy * dy) ** 0.5
        if L > best_len:
            best_len = L; best_seg = LineString([ring[i], ring[i + 1]])
    return [best_seg] if (best_seg is not None and best_len >= min_spine_m) else []


# ── Voronoi skeleton ──────────────────────────────────────────────────────────

def skeleton_spines(block, sample_spacing=3.0, min_spine_m=20.0, snap_tol=0.5):
    perim = block.exterior.length
    n = max(20, int(perim / sample_spacing))
    pts = np.array([
        (block.exterior.interpolate(i * perim / n).x,
         block.exterior.interpolate(i * perim / n).y)
        for i in range(n)
    ])
    if len(pts) < 4:
        return []
    try:
        vor = Voronoi(pts)
    except Exception:
        return []
    block_inner = block.buffer(-0.5)
    if block_inner.is_empty:
        block_inner = block
    adj = defaultdict(list); edge_list = []
    for ridge in vor.ridge_vertices:
        if -1 in ridge:
            continue
        p1 = vor.vertices[ridge[0]]; p2 = vor.vertices[ridge[1]]
        if not (block_inner.contains(Point(p1)) and block_inner.contains(Point(p2))):
            continue
        s1 = snap_pt(p1[0], p1[1], snap_tol); s2 = snap_pt(p2[0], p2[1], snap_tol)
        if s1 == s2:
            continue
        seg_len = ((s2[0] - s1[0]) ** 2 + (s2[1] - s1[1]) ** 2) ** 0.5
        if seg_len < 0.5:
            continue
        eid = len(edge_list); edge_list.append((s1, s2, seg_len))
        adj[s1].append((s2, eid)); adj[s2].append((s1, eid))
    if not adj:
        return []
    best = None
    for comp_nodes in connected_components(adj):
        comp_adj = {nd: [(nb, eid) for nb, eid in adj[nd] if nb in comp_nodes] for nd in comp_nodes}
        path = graph_diameter_path(comp_adj, edge_list)
        if len(path) < 2:
            continue
        spine = LineString(path)
        if spine.length < min_spine_m:
            continue
        if best is None or spine.length > best.length:
            best = spine
    return [best] if best is not None else []


# ── Two-spine block (2-parallel pattern) ─────────────────────────────────────

def two_spine_block(block, min_spine_m=20.0, snap_tol=0.5):
    """Split block along long axis, generate one Voronoi spine per half.

    Used for wide blocks where k-NN library identifies a '2_parallel' pattern.
    Falls back to single skeleton_spines() if split fails or halves are too small.
    """
    from shapely.ops import split as shp_split
    mrr = block.minimum_rotated_rectangle
    mrr_coords = list(mrr.exterior.coords)[:4]
    sides = []
    for i in range(4):
        dx = mrr_coords[(i + 1) % 4][0] - mrr_coords[i][0]
        dy = mrr_coords[(i + 1) % 4][1] - mrr_coords[i][1]
        L = (dx * dx + dy * dy) ** 0.5
        sides.append((L, mrr_coords[i], mrr_coords[(i + 1) % 4]))
    sides.sort(key=lambda s: s[0], reverse=True)
    L0, a0, b0 = sides[0]
    long_ux = (b0[0] - a0[0]) / L0
    long_uy = (b0[1] - a0[1]) / L0
    cx, cy = block.centroid.x, block.centroid.y
    big = max(block.area ** 0.5 * 3, 500)
    div_line = LineString([
        (cx - long_ux * big, cy - long_uy * big),
        (cx + long_ux * big, cy + long_uy * big),
    ])
    try:
        parts = [g for g in shp_split(block, div_line).geoms
                 if isinstance(g, Polygon) and g.area > 200]
    except Exception:
        return skeleton_spines(block, min_spine_m=min_spine_m, snap_tol=snap_tol)
    if len(parts) < 2:
        return skeleton_spines(block, min_spine_m=min_spine_m, snap_tol=snap_tol)
    spines = []
    for part in parts:
        spines.extend(skeleton_spines(part, min_spine_m=min_spine_m, snap_tol=snap_tol))
    return spines if spines else skeleton_spines(block, min_spine_m=min_spine_m, snap_tol=snap_tol)


# ── Corridor validity check ───────────────────────────────────────────────────

def is_valid_connector(line, tight_corridor, max_gap_m=30.0):
    """True if line only exits tight_corridor for short stretches (road crossings).

    A connector can cross non-erven ground only if each individual gap segment
    is <= max_gap_m (narrow road reserve). Longer gaps = open ground = rejected.
    """
    try:
        outside = line.difference(tight_corridor)
    except Exception:
        return False
    if outside.is_empty:
        return True
    for seg in line_from_geom(outside):
        if seg.length > max_gap_m:
            return False
    return True


# ── MST connectivity ──────────────────────────────────────────────────────────

def build_mst_connectors(all_spines, pop_pt, tight_corridor,
                         max_conn_m=60.0, max_gap_m=30.0):
    """Kruskal MST connecting all spines + POP.

    Connector candidates: nearest endpoints within max_conn_m on OTHER spines.
    Validity: each non-erven gap the connector crosses must be <= max_gap_m.
    POP connector: always included (no corridor restriction on root).
    Returns (connectors, n_rejected, isolated_spine_indices).
    """
    N = len(all_spines)
    if N == 0:
        return [], 0, []

    ep_coords = []; ep_spine = []
    for i, spine in enumerate(all_spines):
        coords = list(spine.coords)
        ep_coords.append(coords[0]);  ep_spine.append(i)
        ep_coords.append(coords[-1]); ep_spine.append(i)

    ep_arr  = np.array(ep_coords)
    ep_geoms = [Point(c) for c in ep_coords]
    ep_tree  = STRtree(ep_geoms)

    best_conn = {}   # (si, sj) si<sj → (dist, coord_i, coord_j)
    n_rejected = 0

    for k in range(len(ep_coords)):
        si = ep_spine[k]
        pk = Point(ep_coords[k])
        # Nearest neighbours within search radius
        for m in ep_tree.query(pk.buffer(max_conn_m)):
            if m <= k:
                continue
            sj = ep_spine[m]
            if sj == si:
                continue
            dx = ep_arr[k][0] - ep_arr[m][0]
            dy = ep_arr[k][1] - ep_arr[m][1]
            d  = (dx * dx + dy * dy) ** 0.5
            if d > max_conn_m:
                continue
            key = (min(si, sj), max(si, sj))
            if key in best_conn and d >= best_conn[key][0]:
                continue  # already have a shorter valid candidate for this pair
            if not is_valid_connector(LineString([ep_coords[k], ep_coords[m]]),
                                      tight_corridor, max_gap_m=max_gap_m):
                n_rejected += 1
                continue
            best_conn[key] = (d, ep_coords[k], ep_coords[m])

    # POP: always connect to nearest spine endpoint, no corridor restriction
    pop_arr  = np.array([pop_pt.x, pop_pt.y])
    dists_to_pop = np.linalg.norm(ep_arr - pop_arr, axis=1)
    best_pop_k = int(np.argmin(dists_to_pop))
    pop_si  = ep_spine[best_pop_k]
    best_conn[(min(pop_si, N), max(pop_si, N))] = (
        float(dists_to_pop[best_pop_k]),
        ep_coords[best_pop_k],
        (pop_pt.x, pop_pt.y),
    )

    # Kruskal
    parent = list(range(N + 1)); rank = [0] * (N + 1)

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]; x = parent[x]
        return x

    def union(x, y):
        px, py = find(x), find(y)
        if px == py: return False
        if rank[px] < rank[py]: px, py = py, px
        parent[py] = px
        if rank[px] == rank[py]: rank[px] += 1
        return True

    connectors = []
    for (si, sj), (d, ci, cj) in sorted(best_conn.items(), key=lambda x: x[1][0]):
        if union(si, sj):
            connectors.append(LineString([ci, cj]))

    # Find which spines are isolated from POP
    pop_root = find(N)
    isolated      = [i for i in range(N) if find(i) != pop_root]
    pop_connected = set(i for i in range(N) if find(i) == pop_root)
    return connectors, n_rejected, isolated, pop_connected


# ── Block adjacency + block-level MST ────────────────────────────────────────

def find_block_adjacencies(blocks, max_gap_m=30.0):
    """Adjacent block pairs → closest boundary crossing points.

    Returns dict (i, j) → (pt_on_i, pt_on_j, gap_dist), i < j.
    Only pairs where gap_dist <= max_gap_m are included.
    """
    from shapely.ops import nearest_points as _npts
    tree = STRtree(blocks)
    result = {}
    for i, bi in enumerate(blocks):
        for j in tree.query(bi.buffer(max_gap_m + 1.0)):
            if j <= i:
                continue
            bj = blocks[j]
            d = bi.distance(bj)
            if 0.01 < d <= max_gap_m:
                pi, pj = _npts(bi.exterior, bj.exterior)
                key = (i, j)
                if key not in result or d < result[key][2]:
                    result[key] = (pi, pj, float(d))
    return result


def _nearest_ep(spines, pt):
    """Return (x, y) of the spine endpoint nearest to pt, or None.

    Uses endpoints (not midpoints) so connectors share coordinates with
    spine ends and can be merged by linemerge at degree-2 junctions.
    """
    best = None; best_d = float('inf')
    for sp in spines:
        c = list(sp.coords)
        if not c:
            continue
        for ep in [c[0], c[-1]]:
            d = pt.distance(Point(ep))
            if d < best_d:
                best_d = d; best = ep
    return best


def _build_connector_geom(ep_i, pi, pj, ep_j, block_i=None, block_j=None):
    """Build connector: ep_i → corner_i → pi → pj → corner_j → ep_j

    corner_i/corner_j are L-shape elbows: project the spine endpoint onto the
    road-edge line (line through pi/pj in the along-road direction).  This routes
    via the side fence rather than cutting diagonally through erven.

    The road-crossing direction is pi→pj (d_cross).  The along-road direction
    (d_along) is perpendicular to d_cross.  The elbow for side i is:
        corner_i = pi + dot(ep_i − pi, d_along) * d_along
    which places corner_i at the same along-road position as ep_i but on the
    road-facing boundary of block i (same perpendicular distance as pi).
    """
    import math as _math

    # Max along-road elbow displacement before falling back to straight connector.
    # Beyond this the elbow retraces the spine rather than routing a side fence.
    MAX_ELBOW_M = 30.0  # degrees (~30m at Tsakane latitude)

    def _elbow(ep, p_road, d_along_x, d_along_y):
        """Return elbow (x, y) or None if it collapses, is too large, or adds no value."""
        if ep is None:
            return None
        ex, ey = ep[0], ep[1]
        rx, ry = p_road.x, p_road.y
        dot_along = (ex - rx) * d_along_x + (ey - ry) * d_along_y
        cx = rx + dot_along * d_along_x
        cy = ry + dot_along * d_along_y
        d_ep   = _math.hypot(cx - ex, cy - ey)
        d_road = _math.hypot(cx - rx, cy - ry)
        # Skip if elbow collapses
        if d_ep < 0.5 or d_road < 0.5:
            return None
        # Skip if the along-road walk is too long — the elbow would retrace the spine
        # or create a large L that looks worse than a straight diagonal connector.
        along_m = abs(dot_along) * 111320  # approximate metric (good enough for guard)
        if along_m > MAX_ELBOW_M:
            return None
        return (cx, cy)

    # Road-crossing direction pi→pj; along-road direction is perpendicular.
    dx = pj.x - pi.x
    dy = pj.y - pi.y
    L = _math.hypot(dx, dy)
    if L > 0.1:
        d_cx, d_cy = dx / L, dy / L
    else:
        d_cx, d_cy = 1.0, 0.0
    d_ax, d_ay = -d_cy, d_cx   # along-road (90° CCW from d_cross)

    pts = []
    if ep_i is not None:
        pts.append((ep_i[0], ep_i[1]))
        elbow_i = _elbow(ep_i, pi, d_ax, d_ay)
        if elbow_i is not None:
            pts.append(elbow_i)
    pts.append((pi.x, pi.y))
    pts.append((pj.x, pj.y))
    if ep_j is not None:
        elbow_j = _elbow(ep_j, pj, d_ax, d_ay)
        if elbow_j is not None:
            pts.append(elbow_j)
        pts.append((ep_j[0], ep_j[1]))

    clean = [pts[0]]
    for c in pts[1:]:
        if (c[0] - clean[-1][0]) ** 2 + (c[1] - clean[-1][1]) ** 2 > 1e-6:
            clean.append(c)
    if len(clean) < 2:
        return None
    conn = LineString(clean)
    return conn if conn.length > 0.1 else None


def build_block_mst_connectors(blocks, block_spines, pop_pt, block_adjacencies,
                               tight_corridor=None, max_gap_m=30.0,
                               max_fallback_m=200.0):
    """Kruskal MST on BLOCKS using corridor-validated adjacency edges only.

    Phase 1: Pre-filter adjacency edges by corridor validity (connector must not
             exit erven.buffer(5) for more than max_gap_m in any single segment).
             Kruskal on the surviving valid edges.
    Phase 2: Long-gap fallback for isolated clusters — connects to nearest real
             neighbour; fallback edges use a wider gap tolerance (3×max_gap_m) so
             wide road reserves don't silently block connectivity.
    Phase 3: Single POP connector from POP to nearest spine endpoint of pop_block.

    Returns (connectors, n_fallback, n_isolated_blocks, n_corridor_rejected).
    """
    from shapely.ops import nearest_points as _npts
    N = len(blocks)

    # Phase 1: Kruskal on all adjacency edges (gap ≤ MAX_GAP_M = road reserve).
    # Adjacency edges cross road reserves by definition — no corridor check here.
    # The corridor check applies only to Phase 2 long-gap fallback edges which
    # might cross parks or open ground.
    valid_edges = []
    n_corridor_rejected = 0
    for (i, j), (pi, pj, d) in block_adjacencies.items():
        ep_i = _nearest_ep(block_spines.get(i, []), pi)
        ep_j = _nearest_ep(block_spines.get(j, []), pj)
        conn = _build_connector_geom(ep_i, pi, pj, ep_j, blocks[i], blocks[j])
        if conn is None:
            n_corridor_rejected += 1
            continue
        valid_edges.append((d, i, j))

    parent = list(range(N)); rank = [0] * N

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]; x = parent[x]
        return x

    def union(x, y):
        px, py = find(x), find(y)
        if px == py: return False
        if rank[px] < rank[py]: px, py = py, px
        parent[py] = px
        if rank[px] == rank[py]: rank[px] += 1
        return True

    mst = []
    for d, i, j in sorted(valid_edges):
        if union(i, j):
            mst.append((i, j, d))

    # Phase 2: Connect isolated clusters to nearest real neighbour (not POP).
    # No corridor check here — connectivity is required for the output to be valid.
    # Connections that cross open ground will be flagged by the QA corridor_violations check.
    pop_block = min(range(N), key=lambda i: pop_pt.distance(blocks[i]))
    pop_root = find(pop_block)
    isolated_blocks = [i for i in range(N) if find(i) != pop_root]
    n_fallback = 0
    if isolated_blocks:
        long_edges = []
        for iso in isolated_blocks:
            bi = blocks[iso]
            for j in range(N):
                if j == iso:
                    continue
                d = bi.distance(blocks[j])
                if d < max_fallback_m:
                    long_edges.append((d, iso, j))
        for d, i, j in sorted(long_edges):
            if find(i) != find(j):
                pi, pj = _npts(blocks[i].exterior, blocks[j].exterior)
                ep_i = _nearest_ep(block_spines.get(i, []), pi)
                ep_j = _nearest_ep(block_spines.get(j, []), pj)
                conn = _build_connector_geom(ep_i, pi, pj, ep_j, blocks[i], blocks[j])
                if conn is None:
                    continue
                if union(i, j):
                    mst.append((i, j, d))
                    n_fallback += 1
                    print(f"  Block {i}: long-gap fallback {d:.0f}m to block {j}")

    # Build connectors for finalised MST edges
    connectors = []
    connector_gaps = []  # block-gap distance (m) for each connector; used by Stage 3g
    for i, j, d in mst:
        key = (min(i, j), max(i, j))
        if key in block_adjacencies:
            pi, pj, _ = block_adjacencies[key]
        else:
            pi, pj = _npts(blocks[i].exterior, blocks[j].exterior)
        ep_i = _nearest_ep(block_spines.get(i, []), pi)
        ep_j = _nearest_ep(block_spines.get(j, []), pj)
        conn = _build_connector_geom(ep_i, pi, pj, ep_j, blocks[i], blocks[j])
        if conn is not None:
            connectors.append(conn)
            connector_gaps.append(d)

    # Phase 2b: Force-connect any block still isolated from pop_block — no distance cap.
    # These ultra-long connectors get tagged as open-crossings in Stage 3f.
    pop_root = find(pop_block)
    still_isolated = [i for i in range(N) if find(i) != pop_root]
    if still_isolated:
        pop_component = [j for j in range(N) if find(j) == pop_root]
        for iso in still_isolated:
            bi = blocks[iso]
            best_j, best_d = None, float('inf')
            for j in pop_component:
                d = bi.distance(blocks[j])
                if d < best_d:
                    best_d = d; best_j = j
            if best_j is None:
                continue
            if union(iso, best_j):
                mst.append((iso, best_j, best_d))
                n_fallback += 1
                pop_root = find(pop_block)
                pop_component = [j for j in range(N) if find(j) == pop_root]
                print(f"  Block {iso}: force-connect {best_d:.0f}m to block {best_j} (unlimited fallback)")

    # Phase 3: Single POP connector to the nearest block (pop_block)
    pop_spines = block_spines.get(pop_block, [])
    if pop_spines:
        ep = _nearest_ep(pop_spines, pop_pt)
        if ep:
            connectors.append(LineString([(pop_pt.x, pop_pt.y), ep]))
    else:
        bnd = _npts(blocks[pop_block].exterior, pop_pt)[0]
        connectors.append(LineString([(pop_pt.x, pop_pt.y), (bnd.x, bnd.y)]))
    connector_gaps.append(0.0)  # POP connector — never filtered

    return connectors, connector_gaps, n_fallback, len(isolated_blocks), n_corridor_rejected


def coverage_pass(all_spines, dp_geoms, erven_geoms,
                  min_dp_cluster=6, max_drop_m=50.0, cluster_eps=25.0,
                  min_samples=4, min_spine_m=20.0, snap_tol=0.5):
    """Add supplemental spines for clusters of DPs not covered by existing spines.

    1. Find DPs >max_drop_m from any existing spine.
    2. DBSCAN-cluster them (eps=cluster_eps, min_samples=min_samples).
    3. For each cluster ≥ min_dp_cluster DPs: collect nearby erven, dissolve to a
       temp block, run skeleton_spines on it.  Add any resulting spine to output.

    Returns (supp_spines, n_uncovered_before, n_newly_covered).
    """
    from scipy.spatial import cKDTree as _KDT
    if not dp_geoms or not all_spines:
        return [], 0, 0

    spine_tree = STRtree(all_spines)

    uncovered_pts = []
    for pt in dp_geoms:
        if pt is None or pt.is_empty:
            continue
        if pt.distance(all_spines[spine_tree.nearest(pt)]) > max_drop_m:
            uncovered_pts.append([pt.x, pt.y])

    n_uncov = len(uncovered_pts)
    if n_uncov == 0:
        return [], 0, 0

    pts_arr = np.array(uncovered_pts)
    kdt = _KDT(pts_arr)

    # DBSCAN
    n = len(pts_arr)
    labels = np.full(n, -1, dtype=int)
    cluster_id = 0
    for i in range(n):
        if labels[i] >= 0:
            continue
        nbrs = kdt.query_ball_point(pts_arr[i], cluster_eps)
        if len(nbrs) < min_samples:
            continue
        labels[i] = cluster_id
        queue = [k for k in nbrs if labels[k] < 0]
        while queue:
            j = queue.pop()
            if labels[j] >= 0:
                continue
            labels[j] = cluster_id
            j_nbrs = kdt.query_ball_point(pts_arr[j], cluster_eps)
            if len(j_nbrs) >= min_samples:
                queue.extend(k for k in j_nbrs if labels[k] < 0)
        cluster_id += 1

    erven_tree = STRtree(erven_geoms)
    supp_spines = []
    n_newly_covered = 0

    for cid in range(cluster_id):
        mask = (labels == cid)
        n_in = int(mask.sum())
        if n_in < min_dp_cluster:
            continue
        cluster_pts = pts_arr[mask]

        # Collect erven within 30m of any DP in the cluster
        seen = set()
        cluster_erven = []
        for pt in cluster_pts:
            for idx in erven_tree.query(Point(pt).buffer(30.0)):
                if idx not in seen:
                    seen.add(idx)
                    cluster_erven.append(erven_geoms[idx])

        if len(cluster_erven) < 2:
            continue

        try:
            temp_block = unary_union(cluster_erven).buffer(1.0).buffer(-1.0)
        except Exception:
            continue

        for poly in to_poly_list(temp_block):
            if poly.area < 200:
                continue
            raw = mbr_centreline_spine(poly, min_spine_m=min_spine_m)
            if raw:
                supp_spines.append(raw[0])
                n_newly_covered += n_in
                break

    return supp_spines, n_uncov, n_newly_covered


def corridor_perimeter_route(ep_i, ep_j, tight_corridor, min_len_m=10.0):
    """Route between two endpoints by walking along the tight_corridor exterior ring.

    Used for connectors that would otherwise cross >100m of open ground.
    Returns the shorter of the two arcs around the ring, or None on failure.
    ep_i, ep_j: (x, y) tuples.
    """
    from shapely.ops import substring as _sub

    pt_i = Point(ep_i); pt_j = Point(ep_j)
    corridors = to_poly_list(tight_corridor)
    if not corridors:
        return None
    main_corr = max(corridors, key=lambda p: p.area)
    ring = main_corr.exterior
    ring_len = ring.length
    if ring_len < 1.0:
        return None

    t_i = ring.project(pt_i)
    t_j = ring.project(pt_j)

    # Two arc lengths; always orient so t_start < t_end for substring
    if t_i <= t_j:
        t_start, t_end = t_i, t_j
        start_ep, end_ep = ep_i, ep_j
    else:
        t_start, t_end = t_j, t_i
        start_ep, end_ep = ep_j, ep_i

    arc1_len = t_end - t_start
    arc2_len = ring_len - arc1_len

    if arc1_len <= arc2_len:
        arc = _sub(ring, t_start, t_end)
    else:
        # Wrap around: t_end → ring end → ring start → t_start
        a = _sub(ring, t_end, ring_len)
        b = _sub(ring, 0.0, t_start)
        ca = list(a.coords) if isinstance(a, LineString) else []
        cb = list(b.coords) if isinstance(b, LineString) else []
        full = ca + cb
        arc = LineString(full) if len(full) >= 2 else None

    if arc is None or arc.is_empty:
        return None

    arc_coords = list(arc.coords) if isinstance(arc, LineString) else []
    if not arc_coords:
        return None

    # Ensure arc runs from start_ep end to end_ep
    if Point(arc_coords[0]).distance(Point(start_ep)) > Point(arc_coords[-1]).distance(Point(start_ep)):
        arc_coords = arc_coords[::-1]

    all_coords = [start_ep] + arc_coords + [end_ep]
    clean = [all_coords[0]]
    for c in all_coords[1:]:
        if (c[0] - clean[-1][0]) ** 2 + (c[1] - clean[-1][1]) ** 2 > 0.01:
            clean.append(c)
    if len(clean) < 2:
        return None
    result = LineString(clean)
    return result if result.length >= min_len_m else None


def verify_connectivity(features, pop_pt, snap_tol=1.0):
    def snap(c):
        return (round(c[0] / snap_tol) * snap_tol, round(c[1] / snap_tol) * snap_tol)
    adj = defaultdict(set)
    for feat in features:
        coords = list(feat.coords)
        if len(coords) < 2:
            continue
        a = snap(coords[0]); b = snap(coords[-1])
        if a != b:
            adj[a].add(b); adj[b].add(a)
    if not adj:
        return False, 0, 0, 0
    pop_snapped = snap((pop_pt.x, pop_pt.y))
    if pop_snapped not in adj:
        pop_snapped = min(adj, key=lambda n: (n[0] - pop_pt.x)**2 + (n[1] - pop_pt.y)**2)
    visited = set(); stack = [pop_snapped]
    while stack:
        n = stack.pop()
        if n in visited: continue
        visited.add(n)
        stack.extend(nb for nb in adj[n] if nb not in visited)
    all_v = set(); n_comp = 0
    for start in adj:
        if start in all_v: continue
        n_comp += 1; stk = [start]
        while stk:
            n = stk.pop()
            if n in all_v: continue
            all_v.add(n)
            stk.extend(nb for nb in adj[n] if nb not in all_v)
    return n_comp == 1, n_comp, len(adj), len(visited)


# ── main ─────────────────────────────────────────────────────────────────────

def main():
    cfg = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))

    UTM_EPSG       = cfg['utm_epsg']
    MAX_DROP_M     = cfg['max_drop_m']
    MIN_SPINE_M    = 20.0
    BLOCK_BUF_M    = float(cfg.get('block_buf_m', 0.5))
    SNAP_TOL       = 0.5
    REAR_SNAP_M    = float(cfg.get('rear_snap_m', 80.0))
    USE_REAR_SPINE = bool(cfg.get('use_rear_spine', True))
    TIGHT_BUF_M    = 5.0    # erven buffer for corridor gap test + final clip
    MAX_CONN_M     = 250.0  # max connector search radius
    MAX_GAP_M      = float(cfg.get('max_gap_m', 18.0))  # Tsakane p90=18.8m; Mohadin formal ~50m

    # Pattern library — k-NN dispatch (optional, falls back to classify_block if absent)
    _lib_patterns = None
    _lib_normed   = None
    _lib_ec       = None
    _lib_mean     = None
    _lib_std      = None
    _lib_tree     = None

    lib_path = cfg.get('pattern_library_path', '')
    if lib_path and Path(lib_path).exists():
        try:
            from scipy.spatial import cKDTree as _KDTree
            _raw = json.loads(Path(lib_path).read_text(encoding='utf-8'))
            if _raw:
                # 7-feature vector: erven_count, regularity, aspect_ratio,
                # median_erf_depth_m, short_side_m, erven_depth_cv, n_road_sides
                _arr = np.array([[
                    e['erven_count'], e['regularity'], e['aspect_ratio'],
                    e['median_erf_depth_m'], e['short_side_m'],
                    e.get('erven_depth_cv', 0.0), e.get('n_road_sides', 2.0),
                ] for e in _raw], dtype=float)
                _lib_mean     = _arr.mean(axis=0)
                _lib_std      = _arr.std(axis=0) + 1e-9
                _lib_normed   = (_arr - _lib_mean) / _lib_std
                _lib_tree     = _KDTree(_lib_normed)
                _lib_patterns = [e['pattern'] for e in _raw]
                _lib_ec       = _arr[:, 0]
                _pcounts = {p: _lib_patterns.count(p) for p in set(_lib_patterns)}
                print(f"Pattern library: {len(_raw)} entries  {_pcounts}")
        except Exception as _ex:
            print(f"WARN: pattern library load failed: {_ex}")

    def _knn_pattern(ec, reg, ar, med_depth, short_side, depth_cv=0.0, n_road=2, k=5):
        """Return modal pattern from k nearest library blocks, or None."""
        if _lib_tree is None:
            return None
        feat   = np.array([ec, reg, ar, med_depth, short_side, depth_cv, float(n_road)], dtype=float)
        normed = (feat - _lib_mean) / _lib_std
        k_use  = min(k, len(_lib_patterns))
        _, idxs = _lib_tree.query(normed, k=k_use)
        neighbors = [_lib_patterns[i] for i in idxs]
        # Erven-count ratio guard: skip if this block is very different in size
        nb_ec = float(np.median(_lib_ec[idxs]))
        if nb_ec > 0 and not (0.2 <= ec / nb_ec <= 5.0):
            return None
        modal = max(set(neighbors), key=neighbors.count)
        return modal

    erven = gpd.read_file(cfg['erven_path']).to_crs(UTM_EPSG)
    dp    = gpd.read_file(cfg['dp_path']).to_crs(UTM_EPSG)
    pop   = gpd.read_file(cfg['pop_path']).to_crs(UTM_EPSG)
    print(f"Erven: {len(erven):,}  DPs: {len(dp):,}")

    if cfg.get('aoi_path'):
        aoi = gpd.read_file(cfg['aoi_path']).to_crs(UTM_EPSG)
        aoi_geom = aoi.geometry.union_all().buffer(10.0)
        erven = erven[erven.geometry.intersects(aoi_geom)].copy()
        dp    = dp[dp.geometry.intersects(aoi_geom)].copy()
        print(f"After AOI clip: {len(erven):,} erven, {len(dp):,} DPs")

    # Stage 1 — block polygons + tight corridor
    # Repair invalid geometries before union (avoids GEOS TopologyException)
    erven_geom_fixed = erven.geometry.buffer(0)
    n_invalid = int((~erven_geom_fixed.is_valid).sum())
    if n_invalid:
        print(f"Stage 1 — Repaired {n_invalid} invalid erven geometries via buffer(0)")
    erven_union    = erven_geom_fixed.union_all()
    tight_corridor = erven_union.buffer(TIGHT_BUF_M).simplify(0.5)
    _buf = max(0.1, BLOCK_BUF_M)  # safety: buf must be > 0
    blocks_raw     = erven_union.buffer(_buf).buffer(-_buf)
    blocks         = to_poly_list(blocks_raw)
    print(f"Stage 1 — Block polygons: {len(blocks):,}  Corridor area: {tight_corridor.area/1e6:.2f} km²")

    erven_geoms  = list(erven_geom_fixed)
    erven_tree   = STRtree(erven_geoms)
    block_strtree = STRtree(blocks)   # for fast road-side detection

    # Stage 2 — per-block classification + spine dispatch
    n_double = n_single = n_stub = n_tiny = 0
    n_aligned = 0      # MRR centreline aligned spines
    n_road_forced = 0  # blocks forced to frontage by n_road_sides rule
    all_spines = []; spine_types = []; spine_block = []
    total_rear_snaps = 0; blocks_with_rear = 0

    for blk_idx, block in enumerate(blocks):
        if block.area < 500:
            n_tiny += 1; continue
        idxs = erven_tree.query(block)
        block_erven = [
            erven_geoms[i] for i in idxs
            if erven_geoms[i] is not None
            and not erven_geoms[i].is_empty
            and block.intersects(erven_geoms[i])
        ]
        if len(block_erven) < 2:
            continue

        btype, short_side, erf_depth = classify_block(block, block_erven)

        if btype == 'stub':
            spines = stub_spine(block, min_spine_m=MIN_SPINE_M)
            n_stub += 1; stype = 'stub'
        else:
            # Compute 7-feature vector (matches builder's block_features)
            _mrr = block.minimum_rotated_rectangle
            _sides = sorted(
                ((_mrr.exterior.coords[(i+1)%4][0] - _mrr.exterior.coords[i][0])**2 +
                 (_mrr.exterior.coords[(i+1)%4][1] - _mrr.exterior.coords[i][1])**2)**0.5
                for i in range(4)
            )
            _reg  = block.area / (_mrr.area + 1e-9)
            _ar   = _sides[-1] / (_sides[0] + 1e-9)
            # erven_depth_cv — coefficient of variation of erf depths
            _depths = sorted(g.area ** 0.5 for g in block_erven if g.area > 10)
            if len(_depths) > 2:
                _da = np.array(_depths, dtype=float)
                _depth_cv = float(np.std(_da) / (np.mean(_da) + 1e-9))
            else:
                _depth_cv = 0.0
            # n_road_sides — how many MRR sides face roads/open space
            _n_road = count_road_facing_sides(block, block_strtree, blocks)

            knn = _knn_pattern(len(block_erven), _reg, _ar, erf_depth, short_side,
                               _depth_cv, _n_road)

            # Road-side override: blocks surrounded by roads on 3+ sides are always
            # frontage (peninsula/island blocks).  Blocks with 2 road sides AND a
            # shallow aspect ratio (< 2.5) are likely corner frontage blocks.
            _force_frontage = (_n_road >= 3) or (_n_road == 2 and _ar < 2.5)

            if knn == '2_parallel' and not _force_frontage:
                spines = two_spine_block(block, min_spine_m=MIN_SPINE_M, snap_tol=SNAP_TOL)
                spines = [trim_spine_to_rear_boundary(sp, block_erven) for sp in spines]
                n_double += 1; stype = 'double-row'
            elif knn in ('frontage', 'frontage_corner') or btype == 'single' or _force_frontage:
                # Try rear boundary first — misclassified double-row blocks have shared
                # back-fence edges; true single-row blocks return empty (side fences too short).
                rear_spines = rear_boundary_spine_method(block_erven, min_spine_m=MIN_SPINE_M) if USE_REAR_SPINE else []
                if rear_spines:
                    spines = [trim_spine_to_rear_boundary(sp, block_erven) for sp in rear_spines]
                    n_double += 1; stype = 'double-row'
                else:
                    spine = road_frontage_spine(block, offset_m=2.0, min_spine_m=MIN_SPINE_M)
                    if spine is not None:
                        spine = trim_spine_to_rear_boundary(spine, block_erven)
                    spines = [spine] if spine is not None else mbr_centreline_spine(block, min_spine_m=MIN_SPINE_M)
                    if _force_frontage and knn not in ('frontage', 'frontage_corner') and btype != 'single':
                        n_road_forced += 1
                    n_single += 1; stype = 'single-row'
            else:
                if USE_REAR_SPINE:
                    # Primary: shared back-fence chain — follows exact erf boundaries,
                    # handles L-shaped/irregular blocks without MBR approximation.
                    spines = rear_boundary_spine_method(block_erven, min_spine_m=MIN_SPINE_M)
                    if not spines:
                        # Fallback: MBR centreline + snap vertices to rear boundary
                        spines = mbr_centreline_spine(block, min_spine_m=MIN_SPINE_M)
                        spines_snapped = []
                        for sp in spines:
                            snapped, n_s = snap_to_rear_boundary(sp, block_erven,
                                                                  snap_tol_m=REAR_SNAP_M)
                            spines_snapped.append(snapped)
                            total_rear_snaps += n_s
                        if spines_snapped:
                            blocks_with_rear += 1
                        spines = spines_snapped
                else:
                    # MBR centreline + snap
                    spines = mbr_centreline_spine(block, min_spine_m=MIN_SPINE_M)
                    spines_snapped = []
                    for sp in spines:
                        snapped, n_s = snap_to_rear_boundary(sp, block_erven,
                                                             snap_tol_m=REAR_SNAP_M)
                        spines_snapped.append(snapped)
                        total_rear_snaps += n_s
                    if spines_snapped:
                        blocks_with_rear += 1
                    spines = spines_snapped
                n_double += 1; stype = 'double-row'

        for sp in spines:
            all_spines.append(sp); spine_types.append(stype); spine_block.append(blk_idx)

    print(f"Stage 2 — double={n_double}  single={n_single}  stub={n_stub}  tiny={n_tiny}")
    print(f"Stage 2 — Spines: {len(all_spines):,}  Rear-snaps: {total_rear_snaps} verts / {blocks_with_rear} blocks  "
          f"Centreline-aligned: {n_aligned}  Road-forced frontage: {n_road_forced}")

    # Blocks with no spine get a short centroid stub so connectors have an endpoint to attach to.
    # Includes tiny blocks — they're in the MST and need a valid endpoint too.
    _spineless = set(range(len(blocks))) - set(spine_block)
    if _spineless:
        for _bi in _spineless:
            _b = blocks[_bi]
            _cx, _cy = _b.centroid.x, _b.centroid.y
            _stub = LineString([(_cx - 8.0, _cy), (_cx + 8.0, _cy)])
            all_spines.append(_stub); spine_types.append('stub'); spine_block.append(_bi)
        print(f"Stage 2 — Added {len(_spineless)} centroid stubs for spineless blocks")

    if not all_spines:
        print("ERROR: no spines generated — aborting")
        Path(cfg['out_qa']).write_text(json.dumps({'connectivity_error': 'no spines'}), encoding='utf-8')
        return

    pop_pt = pop.geometry.iloc[0]

    # Stage 3 — Block-adjacency MST connectors
    # Route connectors through actual road gap crossing points between adjacent blocks.
    # corridor-filtered: each connector is tested against erven.buffer(5) before Kruskal.
    block_spines_map = defaultdict(list)
    for sp_idx, blk_idx in enumerate(spine_block):
        block_spines_map[blk_idx].append(all_spines[sp_idx])

    print("Stage 3 — Finding block adjacencies...")
    block_adjacencies = find_block_adjacencies(blocks, max_gap_m=MAX_GAP_M)
    print(f"Stage 3 — Block adjacencies: {len(block_adjacencies)}  blocks: {len(blocks)}")

    connectors, connector_gaps, n_fallback, n_isolated_blk, n_corr_rejected = build_block_mst_connectors(
        blocks, block_spines_map, pop_pt, block_adjacencies,
        tight_corridor=tight_corridor, max_gap_m=MAX_GAP_M,
    )
    print(f"Stage 3 — Block MST: {len(connectors)} connectors  long-gap fallback: {n_fallback}  isolated blocks: {n_isolated_blk}  corridor-rejected: {n_corr_rejected}")

    route_types = ['spine'] * len(all_spines) + ['connector'] * len(connectors)
    routes = all_spines + connectors
    n_clipped = 0

    # Stage 3c — verify connectivity of the main backbone (blocks + MST only)
    is_connected, n_comp, n_nodes, n_reach = verify_connectivity(routes, pop_pt)
    print(f"Stage 3c — Connectivity: {n_comp} component(s), {n_reach}/{n_nodes} nodes reachable from POP")
    if not is_connected:
        # For zone-subset runs the POP is outside the AOI — allow output but flag it.
        # Only abort if extremely fragmented (more components than blocks), which
        # indicates a genuine algorithm failure rather than a zone-boundary effect.
        n_blocks_approx = len(all_spines) // 3 + 1
        if n_comp > n_blocks_approx * 4:
            print(f"ERROR: {n_comp} disconnected components — severe fragmentation, output NOT written")
            qa = {'connectivity_error': f'{n_comp} components after clip', 'n_components': n_comp}
            Path(cfg['out_qa']).write_text(json.dumps(qa), encoding='utf-8')
            return
        print(f"WARNING: {n_comp} components (zone-subset run — POP likely outside AOI)")

    # Stage 3f — Open-crossing detection: connectors that exit corridor >50m get a
    # perimeter-route alternative written alongside the direct line.
    # Both variants are tagged for planner review; downstream consumers pick one.
    # >50m = planner review; >100m = SERIOUS (park / open ground).
    OPEN_CROSSING_M = 50.0
    open_crossing_review = []
    n_spine = len(all_spines)
    for k in range(n_spine, len(routes)):
        conn = routes[k]
        try:
            outside = conn.difference(tight_corridor)
        except Exception:
            continue
        max_outside = max((seg.length for seg in line_from_geom(outside)), default=0.0)
        if max_outside > OPEN_CROSSING_M:
            route_types[k] = 'open-crossing-direct'
            c0 = list(conn.coords)[0]; c1 = list(conn.coords)[-1]
            perim = corridor_perimeter_route(c0, c1, tight_corridor)
            severity = 'SERIOUS' if max_outside > 100.0 else 'review'
            if perim is not None and perim.length > 10.0:
                # Perimeter route recorded in QA metadata only — not added to span output
                # (it can be 1000s of metres and creates large visual loops).
                print(f"  Open-crossing ({severity}): gap={max_outside:.0f}m  direct={conn.length:.0f}m  perimeter={perim.length:.0f}m")
                open_crossing_review.append({'direct_m': round(conn.length, 0), 'perimeter_m': round(perim.length, 0), 'max_gap_m': round(max_outside, 0), 'severity': severity})
            else:
                print(f"  Open-crossing ({severity}): gap={max_outside:.0f}m  direct={conn.length:.0f}m  perimeter=N/A")
                open_crossing_review.append({'direct_m': round(conn.length, 0), 'perimeter_m': None, 'max_gap_m': round(max_outside, 0), 'severity': severity})
    if open_crossing_review:
        n_serious = sum(1 for r in open_crossing_review if r.get('severity') == 'SERIOUS')
        print(f"Stage 3f — {len(open_crossing_review)} open-crossing(s) tagged ({n_serious} SERIOUS >100m, {len(open_crossing_review)-n_serious} minor >50m)")

    # Stage 3e — Coverage pass: supplemental spines AFTER backbone is verified.
    # Each supplemental spine is attached to its nearest backbone route endpoint via a
    # short spur — this guarantees reachability from POP without re-running the MST.
    dp_geoms_utm = [pt for pt in dp.geometry if pt is not None and not pt.is_empty]
    supp_spines, n_uncov_before, n_newly_covered = coverage_pass(
        routes, dp_geoms_utm, erven_geoms,
        min_dp_cluster=6, max_drop_m=MAX_DROP_M,
        min_spine_m=MIN_SPINE_M, snap_tol=SNAP_TOL,
    )
    n_supp_added = 0
    if supp_spines:
        rt_tree = STRtree(routes)
        for sp in supp_spines:
            sp_c = list(sp.coords)
            best_spur = None; best_spur_len = float('inf')
            for sp_ep in [Point(sp_c[0]), Point(sp_c[-1])]:
                nr_idx = rt_tree.nearest(sp_ep)
                nr = routes[nr_idx]
                nr_c = list(nr.coords)
                ep_a = Point(nr_c[0]); ep_b = Point(nr_c[-1])
                attach = ep_a if sp_ep.distance(ep_a) <= sp_ep.distance(ep_b) else ep_b
                spur = LineString([(sp_ep.x, sp_ep.y), (attach.x, attach.y)])
                if 0.5 < spur.length < best_spur_len:
                    best_spur_len = spur.length; best_spur = spur
            routes.append(sp); route_types.append('supplemental-spine')
            n_supp_added += 1
            if best_spur is not None:
                routes.append(best_spur); route_types.append('supplemental-spur')
        print(f"Stage 3e — Added {n_supp_added} supplemental spines covering ~{n_newly_covered}/{n_uncov_before} DPs")

    # Stage 3g — Tag long fallback connectors so they are excluded from output.
    # Filter by BLOCK GAP distance (>50m) not connector geometry length — normal connectors
    # with L-shape elbows can reach 60-80m total length while spanning only a 15m road gap.
    LONG_GAP_FALLBACK_M = 50.0
    n_spine = len(all_spines)
    n_long_fallback = 0
    for idx, (k, gap) in enumerate(zip(range(n_spine, n_spine + len(connectors)), connector_gaps)):
        if k < len(routes) and route_types[k] == 'connector':
            if gap > LONG_GAP_FALLBACK_M:
                route_types[k] = 'long-fallback'
                n_long_fallback += 1
    if n_long_fallback:
        print(f"Stage 3g — Tagged {n_long_fallback} long-fallback connectors (block gap >{LONG_GAP_FALLBACK_M:.0f}m) — excluded from output")

    # Stage 3d — dissolve at degree-2 junctions
    # open-crossing and long-fallback variants are excluded from merge.
    from shapely.geometry import MultiLineString as MLS
    n_pre_dissolve = len(routes)
    _exclude = {'open-crossing', 'long-fallback'}
    normal_rt = [(r, t) for r, t in zip(routes, route_types)
                 if not any(t.startswith(x) for x in _exclude)]
    special_rt = [(r, t) for r, t in zip(routes, route_types)
                  if any(t.startswith(x) for x in _exclude)]
    if normal_rt:
        norm_geoms, norm_types = zip(*normal_rt)
        merged = linemerge(MLS(norm_geoms))
        if merged.geom_type == 'MultiLineString':
            merged_geoms = list(merged.geoms)
        elif merged.geom_type == 'LineString':
            merged_geoms = [merged]
        else:
            merged_geoms = list(norm_geoms)
    else:
        merged_geoms = []
    sp_geoms  = [r for r, _ in special_rt]
    sp_types  = [t for _, t in special_rt]
    routes     = merged_geoms + sp_geoms
    route_types = ['span'] * len(merged_geoms) + sp_types
    print(f"Stage 3d — Dissolve: {n_pre_dissolve} -> {len(routes)} features (merged {n_pre_dissolve - len(routes)} junctions)")

    # Stage 4 — DP reachability + servable/orphan classification
    # Servable: DP centroid within 5m of an erf polygon → eligible for midblock service
    # Orphan: no erf within 5m → in road/park/open space → excluded from coverage gate
    dp_geoms = list(dp.geometry)
    dp_names = list(dp['Name']) if 'Name' in dp.columns else [str(i) for i in range(len(dp_geoms))]

    erven_class_tree = STRtree(erven_geoms)
    servable_mask = []
    for pt in dp_geoms:
        if pt is None or pt.is_empty:
            servable_mask.append(False); continue
        nearby = erven_class_tree.query(pt.buffer(5.0))
        servable_mask.append(any(erven_geoms[j].distance(pt) <= 5.0 for j in nearby))
    n_servable = sum(servable_mask)
    n_orphan   = len(dp_geoms) - n_servable

    route_tree = STRtree(routes)
    reachable = 0
    servable_reachable = 0; servable_unreachable_ids = []
    orphan_ids_sample = []
    unreachable_ids = []

    for i, pt in enumerate(dp_geoms):
        if pt is None or pt.is_empty:
            continue
        dist = pt.distance(routes[route_tree.nearest(pt)])
        reached = dist <= MAX_DROP_M
        if reached:
            reachable += 1
            if servable_mask[i]:
                servable_reachable += 1
        else:
            name = str(dp_names[i]) if i < len(dp_names) else str(i)
            unreachable_ids.append(name)
            if servable_mask[i]:
                servable_unreachable_ids.append(name)
            elif len(orphan_ids_sample) < 20:
                orphan_ids_sample.append(name)

    servable_unreachable = len(servable_unreachable_ids)
    pop_dist = min(pop_pt.distance(r) for r in routes)
    print(f"Stage 4 — Reachable: {reachable:,}/{len(dp_geoms):,}  "
          f"Servable: {servable_reachable}/{n_servable} reachable  "
          f"Orphan DPs (no erf): {n_orphan}  POP dist: {pop_dist:.1f} m")

    # Stage 4b — Three blocking QA checks
    # Tagged open-crossings are excluded from both corridor and open-ground violation counts
    # (they are expected to exit the corridor and are handled via planner review).
    # Check 1: corridor violations — untagged route exits tight_corridor for > 50m
    # (normal road reserves ≤ 50m are acceptable; >50m triggers this flag)
    CORR_VIOLATION_M = 50.0
    n_corr_violations = 0
    for route, rtype in zip(routes, route_types):
        if rtype.startswith('open-crossing'):
            continue
        try:
            outside = route.difference(tight_corridor)
        except Exception:
            continue
        if outside.is_empty:
            continue
        for seg in line_from_geom(outside):
            if seg.length > CORR_VIOLATION_M:
                n_corr_violations += 1
                break

    # Check 2: open-ground spans — untagged route exits corridor for > 100m
    n_open_ground = 0
    for route, rtype in zip(routes, route_types):
        if rtype.startswith('open-crossing'):
            continue
        try:
            outside = route.difference(tight_corridor)
        except Exception:
            continue
        if outside.is_empty:
            continue
        for seg in line_from_geom(outside):
            if seg.length > 100.0:
                n_open_ground += 1
                break

    # Check 3: DP coverage gate — servable_unreachable > 500 is a coverage failure
    # (Orphan DPs in roads/parks are excluded — they're data quality, not algorithm failures)
    n_unreachable = len(unreachable_ids)
    dp_coverage_ok = servable_unreachable < 500

    # Open-crossings gate: any open-crossing routes must be tagged (not plain connectors)
    n_tagged_open = sum(1 for t in route_types if t.startswith('open-crossing'))
    open_crossings_ok = n_open_ground == 0 or (n_tagged_open > 0 and n_open_ground <= len(routes) * 0.05)

    qa_gate_pass = n_corr_violations == 0 and open_crossings_ok and dp_coverage_ok
    print(f"Stage 4b — QA gates: corridor_violations={n_corr_violations}  "
          f"open_ground_spans={n_open_ground} (tagged={n_tagged_open})  "
          f"servable_unreachable={servable_unreachable}/{n_servable}  orphan_DPs={n_orphan}  "
          f"gate={'PASS' if qa_gate_pass else 'FAIL'}")

    # Output
    transformer = Transformer.from_crs(f'EPSG:{UTM_EPSG}', 'EPSG:4326', always_xy=True)
    feats = []

    def to_wgs(line, feat_type):
        return {
            'type': 'Feature',
            'geometry': {
                'type': 'LineString',
                'coordinates': [[lon, lat] for lon, lat in
                                (transformer.transform(x, y) for x, y in line.coords)],
            },
            'properties': {'id': len(feats) + 1, 'length_m': round(line.length, 2), 'type': feat_type},
        }

    n_sp = len(all_spines)
    n_conn = len(connectors)
    n_oc_filtered = 0
    for route, rtype in zip(routes, route_types):
        # Exclude open-crossing and long-fallback connectors from span output.
        # Open-crossings and long-fallbacks cross open ground far beyond road reserves;
        # they are recorded in QA for manual planner review.
        if rtype in ('open-crossing-direct', 'long-fallback'):
            n_oc_filtered += 1
            continue
        feats.append(to_wgs(route, rtype))
    if n_oc_filtered:
        print(f"  Filtered {n_oc_filtered} open-crossing/long-fallback routes from output (see QA)")

    Path(cfg['out_spans']).write_text(json.dumps({'type': 'FeatureCollection', 'features': feats}), encoding='utf-8')
    print(f"Saved {len(feats)} spans (pre-dissolve: {n_pre_dissolve} = {n_sp} spines + {n_conn} block-MST connectors)")

    n_sk = spine_types.count('double-row')
    qa = {
        'total_blocks': len(blocks), 'double_row_blocks': n_double,
        'single_row_blocks': n_single, 'stub_blocks': n_stub, 'tiny_blocks': n_tiny,
        'skeleton_spines': n_sk, 'single_row_spines': spine_types.count('single-row'),
        'stub_spines': spine_types.count('stub'), 'back_fence_spines': blocks_with_rear,
        'n_features_pre_dissolve': n_pre_dissolve, 'n_features_post_dissolve': len(routes),
        'mst_connectors': n_conn, 'fallback_connectors': n_fallback,
        'corridor_rejected': n_corr_rejected,
        'corridor_violations': n_corr_violations,
        'open_ground_spans': n_open_ground,
        'open_crossing_review': open_crossing_review,
        'dp_coverage_ok': dp_coverage_ok,
        'qa_gate_pass': qa_gate_pass,
        'corridor_clipped': n_clipped, 'rear_snaps': total_rear_snaps,
        'blocks_with_rear': blocks_with_rear, 'centreline_aligned': n_aligned,
        'n_components': n_comp,
        'nodes_total': n_nodes, 'nodes_reachable': n_reach,
        'total_dp': len(dp_geoms), 'reachable': reachable,
        'n_servable': n_servable, 'servable_reachable': servable_reachable,
        'servable_unreachable': servable_unreachable,
        'servable_unreachable_ids': servable_unreachable_ids[:50],
        'n_orphan': n_orphan, 'orphan_ids_sample': orphan_ids_sample,
        'unreachable_count': len(unreachable_ids), 'unreachable_ids': unreachable_ids[:50],
        'pop_dist_m': round(pop_dist, 1),
    }
    Path(cfg['out_qa']).write_text(json.dumps(qa), encoding='utf-8')


if __name__ == '__main__':
    main()
'''
