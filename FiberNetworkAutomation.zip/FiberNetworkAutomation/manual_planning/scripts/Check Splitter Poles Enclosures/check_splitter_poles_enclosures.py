import sys, os
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')

# ============================================================
# CHECK FTS/STS — MISSING POLES AND ENCLOSURES
# ============================================================

FTS_LAYER = 'FTS Splitters v1'
STS_LAYER = 'STS Splitters v1'
POLES_LAYER = 'poles v1'
ENC_LAYER = 'Enclosure v1'

fts_layer = sts_layer = poles_layer = enc_layer = None
for lyr in QgsProject.instance().mapLayers().values():
    n = lyr.name()
    if n == FTS_LAYER: fts_layer = lyr
    if n == STS_LAYER: sts_layer = lyr
    if n == POLES_LAYER: poles_layer = lyr
    if n == ENC_LAYER: enc_layer = lyr

missing = [n for n, l in [(FTS_LAYER, fts_layer), (STS_LAYER, sts_layer), (POLES_LAYER, poles_layer), (ENC_LAYER, enc_layer)] if not l]
if missing:
    print(f"ERROR: Missing layers: {missing}")
else:
    print(f"FTS: {fts_layer.featureCount()} | STS: {sts_layer.featureCount()} | Poles: {poles_layer.featureCount()} | Enc: {enc_layer.featureCount()}")

    from qgis.core import QgsSpatialIndex, QgsDistanceArea, QgsProject, QgsPointXY

    d = QgsDistanceArea()
    d.setSourceCrs(fts_layer.crs(), QgsProject.instance().transformContext())
    d.setEllipsoid(QgsProject.instance().ellipsoid())

    # Build indexes
    pole_index = QgsSpatialIndex(poles_layer.getFeatures())
    pole_feats = {f.id(): f for f in poles_layer.getFeatures()}
    enc_index = QgsSpatialIndex(enc_layer.getFeatures())
    enc_feats = {f.id(): f for f in enc_layer.getFeatures()}

    POLE_THRESHOLD = 5.0    # metres — splitter should be within 5m of a pole
    ENC_THRESHOLD = 5.0     # metres — enclosure should be within 5m of splitter

    def nearest_dist(index, feats, point):
        candidates = index.nearestNeighbor(point, 1)
        if not candidates:
            return None, 999999
        feat = feats[candidates[0]]
        g = feat.geometry()
        if not g or g.isNull() or g.isEmpty():
            return None, 999999
        dist = d.measureLine(point, g.asPoint())
        return feat, dist

    # --- CHECK FTS ---
    print("\n=== FTS SPLITTERS ===")
    fts_no_pole = []
    fts_no_enc = []

    for feat in fts_layer.getFeatures():
        geom = feat.geometry()
        if not geom or geom.isNull() or geom.isEmpty(): continue
        pt = QgsPointXY(geom.asPoint().x(), geom.asPoint().y())
        label = feat['label'] or f'fid={feat.id()}'

        _, pole_dist = nearest_dist(pole_index, pole_feats, pt)
        _, enc_dist = nearest_dist(enc_index, enc_feats, pt)

        if pole_dist > POLE_THRESHOLD:
            fts_no_pole.append((label, pole_dist))
        if enc_dist > ENC_THRESHOLD:
            fts_no_enc.append((label, enc_dist))

    print(f"  Missing pole (>{POLE_THRESHOLD}m away): {len(fts_no_pole)}")
    for label, dist in fts_no_pole[:10]:
        print(f"    {label} — nearest pole {dist:.1f}m away")

    print(f"  Missing enclosure (>{ENC_THRESHOLD}m away): {len(fts_no_enc)}")
    for label, dist in fts_no_enc[:10]:
        print(f"    {label} — nearest enclosure {dist:.1f}m away")

    # --- CHECK STS ---
    print("\n=== STS SPLITTERS ===")
    sts_no_pole = []
    sts_no_enc = []

    for feat in sts_layer.getFeatures():
        geom = feat.geometry()
        if not geom or geom.isNull() or geom.isEmpty(): continue
        pt = QgsPointXY(geom.asPoint().x(), geom.asPoint().y())
        label = feat['label'] or f'fid={feat.id()}'

        _, pole_dist = nearest_dist(pole_index, pole_feats, pt)
        _, enc_dist = nearest_dist(enc_index, enc_feats, pt)

        if pole_dist > POLE_THRESHOLD:
            sts_no_pole.append((label, pole_dist))
        if enc_dist > ENC_THRESHOLD:
            sts_no_enc.append((label, enc_dist))

    print(f"  Missing pole (>{POLE_THRESHOLD}m away): {len(sts_no_pole)}")
    for label, dist in sts_no_pole[:10]:
        print(f"    {label} — nearest pole {dist:.1f}m away")
    if len(sts_no_pole) > 10:
        print(f"    ... and {len(sts_no_pole)-10} more")

    print(f"  Missing enclosure (>{ENC_THRESHOLD}m away): {len(sts_no_enc)}")
    for label, dist in sts_no_enc[:10]:
        print(f"    {label} — nearest enclosure {dist:.1f}m away")
    if len(sts_no_enc) > 10:
        print(f"    ... and {len(sts_no_enc)-10} more")

    print("\n=== SUMMARY ===")
    print(f"  FTS missing poles: {len(fts_no_pole)}")
    print(f"  FTS missing enclosures: {len(fts_no_enc)}")
    print(f"  STS missing poles: {len(sts_no_pole)}")
    print(f"  STS missing enclosures: {len(sts_no_enc)}")
