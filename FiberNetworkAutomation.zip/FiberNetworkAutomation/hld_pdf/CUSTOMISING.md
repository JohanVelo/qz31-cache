# Customising the wayleave drawing

Everything on a wayleave sheet — the legend, the colours, the labels, what is drawn at all,
the credit line — is **data, not code**. You change it by dropping one JSON file into your
QGIS profile. No plugin edit, no rebuild, no developer.

---

## Where your file goes

```
C:/Users/<you>/AppData/Roaming/QGIS/QGIS4/profiles/default/hld_pdf/models/
```

That folder is created for you the first time the HLD dialog opens. Two things make it the
right place:

- **It survives plugin updates.** Files bundled inside the plugin get replaced every time
  the team publishes; this folder never does.
- **It shadows the bundled preset of the same id.** A file named `wayleave.json` here wins
  over the house-standard `wayleave.json` inside the plugin — so you can override the
  standard sheet without touching it, and delete your file to go straight back.

Give it a **new** id (say `wayleave_mine.json`) and it appears as an extra choice in the
model dropdown. Give it the id `wayleave.json` and it *replaces* the standard one for you.

⚠️ Only ever put custom presets in the profile folder above. A `.json` dropped into the
plugin's own `hld_pdf/models/` is listed in everyone's dropdown as if it were a real
deliverable — including half-finished experiments.

---

## The smallest useful file

Keep only the keys you actually want to change. Everything you leave out falls back to the
house standard, so a three-line file is perfectly normal.

```json
{
  "display_name": "Wayleave — my version",
  "requires_restyle": true,
  "hld_cfg": {
    "wayleave_span_color": "255,34,0"
  }
}
```

`requires_restyle: true` matters: it tells the dialog this model's *look* is the
deliverable, so the wayleave styling is applied instead of your project's own symbology.
Leave it in.

After saving, just run the export again — presets are read fresh on every build.

---

## The legend

The legend is a list you edit. Rows print in the order you write them.

```json
"wayleave_legend_rows": [
  ["Poles",    "pole"],
  ["Span",     "route"],
  ["Erven",    "erven"],
  ["POP",      "pop"],
  ["Boundary", "boundary"],
  ["Obstacle", "obstacle"]
]
```

Reorder them, rename a label ("Span" → "Aerial fibre"), delete a row, add one back. The
**label** is yours; the **role** tells the engine which layer to draw the swatch from, so a
row can never advertise a symbol the sheet did not actually draw.

Valid roles: `pole` · `route` · `erven` · `pop` · `splitter` · `demand` · `boundary` ·
`obstacle` · `road`

A row whose role has no layer in your project drops out on its own, as does a row whose
role you hid (below). Set the whole key to `null` for the issued reference sheet's rows.

A malformed row is skipped **with a message in the log** rather than silently — a legend
that quietly lost a row is how a drawing goes out promising less than it shows.

---

## Hiding things entirely

```json
"wayleave_hide_roles": ["splitter", "demand"]
```

These are drawn **nowhere** — not on the map, not in the legend. One list controls both, so
what is drawn and what is named can never disagree.

The house standard hides splitters and demand points: a wayleave asks for permission over a
*route*, and internal build detail is a question the client then has to ask. Empty the list
to show everything. Add `"road"` to drop street names altogether.

---

## Everything else you can set

| Key | Default | What it does |
|---|---|---|
| `wayleave_span_color` | `"255,34,0"` | Route red, measured off the issued Burgersdorp sheet |
| `wayleave_span_width` | `0.6` | Route line width, mm |
| `wayleave_pole_color` / `_outline` / `_outline_w` / `_size` | white / black / `0.3` / `1.4` | Poles are hollow circles, not filled dots |
| `wayleave_pop_color` / `_outline` / `_size` | `"245,166,35"` / `"180,90,0"` / `4.4` | The POP starburst |
| `wayleave_obstacle_color` / `_outline` | `"255,0,0"` / `"35,35,35"` | Obstacles |
| `wayleave_erf_labels` / `_label_size` | `true` / `5` | Erf numbers |
| `wayleave_pole_labels` / `_label_size` | `true` / `5` | Pole numbers |
| `wayleave_route_labels` / `_label_size` | `false` / `6` | Cable labels — off by default, they crowd the route |
| `wayleave_road_labels` / `_label_size` | `true` / `8` | Street names |
| `wayleave_basemap_opacity` | `0.35` | The aerial sits **under** the drawing. `1.0` full, `0.0` invisible |
| `wayleave_desc` | see below | The Project Description paragraph |
| `wayleave_scale_note` | `"NTS"` | The Scale row |
| `wayleave_attribution` | OSM credit | The data credit line — see below |
| `wayleave_attribution_size` | `6` | Credit line size, points |
| `grid_cell_w_m` / `grid_cell_h_m` | `775` / `550` | Page footprint on the ground, metres |
| `grid_skip_empty_cells` | `true` | Drop pages with no network on them |

**Colours** are `"R,G,B"` strings, 0–255. **Sizes** are millimetres unless the row says
points. **Label sizes must be whole numbers** — Qt6 rejects a fraction with a hard error,
so `7.5` will fail the build where `8` is fine.

---

## The credit line — read before you delete it

```json
"wayleave_attribution": "Street names and road centrelines © OpenStreetMap contributors (ODbL)."
```

Our street names and road centrelines come from OpenStreetMap, which is licensed **ODbL**.
That licence requires visible attribution wherever the data is displayed — and a wayleave
sheet is displayed to a municipality.

Set it to `""` **only** when the streets on that particular project came from a municipal
or purchased layer instead. Otherwise leave it exactly as it is.

---

## Street names that aren't there

If a town's streets print blank, it is almost never a settings problem. Measured on
Fouriesburg (2026-09-03): of 337 road segments, **233 have no name**, and 201 of those have
no name in OpenStreetMap, in Overture, in `addr:street`, or on Google's own tiles. Those
streets have never been named in any published dataset.

Switching basemap will not fix it — Google labels the same streets OSM does and is equally
blank on the township grid. The only real fixes are a municipal street layer, a purchased
one (AfriGIS, 1map), or local knowledge typed in by hand.

---

## If a build fails after you edit

The log names the offending key. The usual causes, in order:

1. **A fractional label size** — `7.5` where Qt6 demands `8`.
2. **A trailing comma** or a smart quote — it must be strict JSON.
3. **An unknown role** in `wayleave_legend_rows` — check the list above; the row is skipped
   and the reason is logged.

Delete your file from the profile folder and the house standard comes straight back.
