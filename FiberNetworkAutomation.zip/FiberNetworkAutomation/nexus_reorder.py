"""nexus_reorder — reorder + persist Velocity Nexus widgets (dock cards + tools,
and later the top bar). Bundled.

Two layers:
  * a PURE order model (``merge_order``) — property-tested, no Qt — that turns a
    saved id list + the current default id list into a display order. Reorder is a
    PERMUTATION only: it never invents an id and never drops a default id, so a NEW
    widget added in a future version always appears (appended) and can never vanish.
  * thin Qt helpers (``apply_layout_order``) that re-order real widgets inside a
    QBoxLayout, asserting the widget count is unchanged (reorder ≠ removal).

Persistence is GLOBAL (QgsSettings, QGIS4 profile) so the layout survives a project
switch and a QGIS restart. Every caller wraps use in try/except → fail-open to the
static build (no widget ever lost). Kill-switch: env ``VF_NO_DRAG=1``.
"""
import os

_KEY = "VelocityFibre/nexus_order/%s"
_SEP = "\x1f"          # unit separator — safe joiner for the id list fallback


def disabled():
    """True when the whole reorder feature is killed (env flag)."""
    return os.environ.get("VF_NO_DRAG", "") == "1"


# ── pure model (unit/property-tested; no Qt) ──────────────────────────────────
def merge_order(default_ids, saved_ids):
    """Display order = saved ids that still exist (in their saved order), then any
    default id not in the saved list (appended). Guarantees:
      * output is a permutation of ``default_ids`` (same set, no dupes),
      * a saved id no longer present is dropped, a brand-new default id is kept.
    """
    default = list(dict.fromkeys(default_ids))     # de-dupe, keep order
    dset = set(default)
    out, seen = [], set()
    for i in saved_ids:
        if i in dset and i not in seen:
            out.append(i)
            seen.add(i)
    for i in default:
        if i not in seen:
            out.append(i)
            seen.add(i)
    return out


# ── persistence (global QgsSettings) ──────────────────────────────────────────
def saved_order(scope):
    try:
        from qgis.core import QgsSettings
        v = QgsSettings().value(_KEY % scope)
    except Exception:
        return []
    if not v:
        return []
    if isinstance(v, (list, tuple)):
        return [str(x) for x in v if str(x)]
    return [s for s in str(v).split(_SEP) if s]


def save_order(scope, ids):
    try:
        from qgis.core import QgsSettings
        QgsSettings().setValue(_KEY % scope, list(ids))
    except Exception:
        pass


def reset(scope):
    try:
        from qgis.core import QgsSettings
        QgsSettings().remove(_KEY % scope)
    except Exception:
        pass


def display_order(scope, default_ids):
    """The order to draw ``default_ids`` in, honouring the saved layout."""
    if disabled():
        return list(dict.fromkeys(default_ids))
    return merge_order(default_ids, saved_order(scope))


# ── Qt layout re-order (fail-open callers) ────────────────────────────────────
def apply_layout_order(layout, id_widget, order):
    """Re-order the widgets of ``id_widget`` (an {id: QWidget} map) INSIDE ``layout``
    into ``order``, keeping the block's starting position among any other widgets in
    the same layout. Only these widgets are moved. Returns True if it reordered.

    Asserts the layout's widget count is unchanged — a reorder must never add or
    drop a widget. Raises on violation so a caller's try/except falls back to the
    static build rather than shipping a bar/dock with a missing button.
    """
    widgets = [id_widget[i] for i in order if i in id_widget]
    if len(widgets) < 2:
        return False
    idxs = [layout.indexOf(w) for w in widgets]
    idxs = [i for i in idxs if i >= 0]
    if len(idxs) < 2:
        return False
    start = min(idxs)
    before = layout.count()
    for w in widgets:
        layout.removeWidget(w)
    for k, w in enumerate(widgets):
        layout.insertWidget(start + k, w)
    if layout.count() != before:
        raise RuntimeError("nexus_reorder: widget count changed (%d→%d)"
                           % (before, layout.count()))
    return True


def _order_ids(id_widget, layout):
    """Current on-screen order of the ids, by their layout position."""
    pos = []
    for wid, w in id_widget.items():
        i = layout.indexOf(w)
        if i >= 0:
            pos.append((i, wid))
    return [wid for _i, wid in sorted(pos)]


def install_drag_reorder(owner, layout, id_widget, scope, threshold=6, commit=None):
    """Press-and-hold drag to reorder the widgets of ``id_widget`` (reorder ONLY).

    Two modes:
      * ``commit=None`` (vertical QBoxLayout): live in-place reorder via the layout,
        order saved under ``scope`` on drop.
      * ``commit=fn`` (grid / non-box): no live layout mutation — on drop the new id
        order is computed by geometry and passed to ``fn(order_ids)`` (which typically
        saves + rebuilds the section). Works for a 2-column tool grid.

    Returns a DragReorder kept alive on ``owner`` so the event filter isn't GC'd.
    Fail-open: the caller wraps this in try/except."""
    dr = _dr_cls()(layout, id_widget, scope, threshold, commit)
    if not hasattr(owner, "_vf_draggers"):
        owner._vf_draggers = []
    owner._vf_draggers.append(dr)          # keep a strong ref
    return dr


def _make_dragreorder_cls():
    """Build the QObject subclass lazily so importing this module needs no Qt."""
    from qgis.PyQt.QtCore import QObject, QEvent, Qt

    class _DR(QObject):
        def __init__(self, layout, id_widget, scope, threshold, commit=None):
            super().__init__()
            self.layout = layout
            self.id_widget = id_widget
            self.scope = scope
            self.threshold = threshold
            self.commit = commit        # grid mode: fn(order_ids) on drop
            self._press = None          # (widget, start_y_global)
            self._dragging = False
            for w in id_widget.values():
                w.installEventFilter(self)

        def _widget_id(self, w):
            for wid, ww in self.id_widget.items():
                if ww is w:
                    return wid
            return None

        def eventFilter(self, obj, ev):
            t = ev.type()
            if t == QEvent.Type.MouseButtonPress:
                if ev.button() == Qt.MouseButton.LeftButton and self._widget_id(obj):
                    self._press = (obj, ev.globalPosition().y())
                return False
            if t == QEvent.Type.MouseMove and self._press is not None:
                drag_w, y0 = self._press
                if not self._dragging:
                    if abs(ev.globalPosition().y() - y0) < self.threshold:
                        return False
                    self._dragging = True
                    try:
                        drag_w.setCursor(Qt.CursorShape.ClosedHandCursor)
                    except Exception:
                        pass
                if self.commit is None:            # live box reorder
                    self._reorder_to_cursor(drag_w, ev.globalPosition().y())
                return True
            if t == QEvent.Type.MouseButtonRelease and self._press is not None:
                drag_w = self._press[0]
                was_dragging = self._dragging
                self._press = None
                self._dragging = False
                try:
                    drag_w.unsetCursor()
                except Exception:
                    pass
                if was_dragging:
                    if self.commit is not None:    # grid: compute order, hand to caller
                        self.commit(self._computed_order(drag_w, ev.globalPosition()))
                    else:
                        save_order(self.scope, _order_ids(self.id_widget, self.layout))
                    return True
                return False
            return False

        def _computed_order(self, drag_w, cursor):
            """Grid mode: the other ids in their current order, with the dragged id
            inserted at the slot nearest the cursor (a QPointF)."""
            cur = _order_ids(self.id_widget, self.layout)
            drag_id = self._widget_id(drag_w)
            others = [i for i in cur if i != drag_id]
            cx, cy = cursor.x(), cursor.y()
            best_k, best_d = len(others), None
            for k, oid in enumerate(others):
                w = self.id_widget[oid]
                c = w.mapToGlobal(w.rect().center())
                d = (c.x() - cx) ** 2 + (c.y() - cy) ** 2
                if best_d is None or d < best_d:
                    after = (cy > c.y() + 4) or (abs(cy - c.y()) <= 4 and cx > c.x())
                    best_k = k + (1 if after else 0)
                    best_d = d
            return others[:best_k] + [drag_id] + others[best_k:]

        def _reorder_to_cursor(self, drag_w, y_global):
            """Move drag_w to sit where the cursor is, among the sibling widgets."""
            sibs = [w for w in self.id_widget.values()]
            # target = the sibling whose vertical centre is nearest the cursor
            best, best_d = None, None
            for w in sibs:
                if w is drag_w:
                    continue
                c = w.mapToGlobal(w.rect().center())
                d = abs(c.y() - y_global)
                if best_d is None or d < best_d:
                    best, best_d = w, d
            if best is None:
                return
            di = self.layout.indexOf(drag_w)
            ti = self.layout.indexOf(best)
            if di < 0 or ti < 0 or di == ti:
                return
            before = self.layout.count()
            self.layout.removeWidget(drag_w)
            self.layout.insertWidget(ti, drag_w)
            if self.layout.count() != before:      # never lose a widget
                self.layout.removeWidget(drag_w)
                self.layout.insertWidget(di, drag_w)

    return _DR


_DR_CLS = None


def _dr_cls():
    """The DragReorder QObject class, built once on first use (import stays Qt-free)."""
    global _DR_CLS
    if _DR_CLS is None:
        _DR_CLS = _make_dragreorder_cls()
    return _DR_CLS
