"""Assign demand points to PONs, constrained by the span.

The pipeline, and why each stage is there:

  1. **snap** every stand to its nearest run,
  2. **pre-split** any run that alone carries more than the cap,
  3. **seed** with capacitated k-means on the stand coordinates — compactness
     has to come from the seed, because growing PONs by walking up the span
     tree gathers runs along one spine and produces ribbons no later repair can
     undo,
  4. **vote** each run to the majority PON of its own stands, which makes runs
     atomic so a cut can only land on a junction,
  5. **repair contiguity** so each PON's span is one connected piece,
  6. **split** any PON over the cap, along its own span,
  7. **refine** by moving whole runs between neighbours to tighten clumping,
  8. **renumber** outward from the DC, per the OPL labelling standard.

There is deliberately **no minimum PON size** (JJ, 2026-09-04): once the full
PONs are packed, whatever is left under is acceptable. Enforcing a floor forced
merges that made the clumping worse.
"""

from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field

import networkx as nx
import numpy as np
from scipy.spatial import cKDTree
from shapely.geometry import LineString

from .core import (
    MAX_STANDS,
    RESTART_SEEDS,
    TARGET_STANDS,
    PonWayleaveError,
    SpanGraph,
)

__all__ = ["GroupingResult", "group_pons", "renumber_from_dc"]


@dataclass
class GroupingResult:
    """What the engine decided, plus how it got there."""

    pon_of_stand: np.ndarray          # stand index -> PON number (1..K)
    pon_of_run: dict                  # run index   -> PON number
    graph: SpanGraph
    snap_run: list                    # stand index -> run index
    snap_offset_m: np.ndarray         # stand index -> metres to its run
    stats: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)

    @property
    def n_pons(self) -> int:
        return int(self.pon_of_stand.max()) if len(self.pon_of_stand) else 0

    def counts(self) -> np.ndarray:
        """Stands per PON, index 0 == PON 1."""
        if not len(self.pon_of_stand):
            return np.zeros(0, dtype=int)
        return np.bincount(self.pon_of_stand, minlength=self.n_pons + 1)[1:]


def _noop(*_a, **_k):
    return False


def group_pons(
    span_lines,
    demand_xy,
    dc_xy=None,
    target=TARGET_STANDS,
    max_stands=MAX_STANDS,
    snap_m=0.5,
    max_snap_m=250.0,
    restarts=len(RESTART_SEEDS),
    progress=None,
    is_cancelled=None,
):
    """Group ``demand_xy`` into PONs along ``span_lines``. All in metres.

    ``progress(pct, message)`` is called as it goes; ``is_cancelled()`` is
    polled and, when it returns True, the run stops with PonWayleaveError.
    """
    progress = progress or (lambda *_a, **_k: None)
    is_cancelled = is_cancelled or _noop

    def tick(pct, msg):
        if is_cancelled():
            raise PonWayleaveError("Cancelled.")
        progress(pct, msg)

    demand_xy = np.asarray(demand_xy, dtype=float)
    if demand_xy.ndim != 2 or demand_xy.shape[1] != 2:
        raise PonWayleaveError("Demand points must be an N x 2 array of coordinates.")
    n = len(demand_xy)
    if n == 0:
        raise PonWayleaveError(
            "There are no demand points to group. Check the demand layer is not "
            "empty and not filtered."
        )
    if max_stands < 1:
        raise PonWayleaveError("Maximum stands per PON must be at least 1.")
    target = max(1, min(int(target), int(max_stands)))

    warnings: list[str] = []

    tick(2, "Building the span graph")
    graph = SpanGraph(span_lines, snap_m=snap_m)
    if graph.n_components > 1:
        warnings.append(
            f"The span is in {graph.n_components} disconnected pieces. Each is "
            "grouped on its own; PONs never bridge a gap in the route."
        )

    tick(10, "Snapping demand to the route")
    snap_run, snap_pos, snap_off = _snap(graph, demand_xy)
    far = int((snap_off > max_snap_m).sum())
    if far:
        warnings.append(
            f"{far} demand point(s) are more than {max_snap_m:.0f} m from any span. "
            "They are still assigned, but no drop cable reaches that far — check "
            "the span layer covers the whole area."
        )

    tick(18, "Splitting oversized runs")
    graph, snap_run, snap_pos, snap_off, n_presplit = _presplit(
        graph, demand_xy, snap_run, snap_pos, snap_off, max_stands, snap_m
    )

    stands_on_run = defaultdict(list)
    for i, r in enumerate(snap_run):
        stands_on_run[r].append(i)

    k = max(1, math.ceil(n / target))

    tick(25, f"Clustering {n:,} stands into about {k} PONs")
    best = None
    for si in range(max(1, int(restarts))):
        if si >= len(RESTART_SEEDS):
            break
        labels = _capacitated_kmeans(
            demand_xy, k, max_stands, RESTART_SEEDS[si], is_cancelled
        )
        pon_of_run = _vote_runs(graph, stands_on_run, labels)
        pon_of_run = _repair_contiguity(graph, stands_on_run, pon_of_run)
        pon_of_run = _split_over_cap(graph, stands_on_run, pon_of_run, max_stands)
        pon_of_run = _consolidate(graph, stands_on_run, pon_of_run, k, max_stands)
        pon_of_run = _dissolve_toward(graph, stands_on_run, pon_of_run, k, max_stands)
        pon_of_run = _refine(graph, stands_on_run, demand_xy, pon_of_run, max_stands)
        inertia = _inertia(demand_xy, _labels_from_runs(snap_run, pon_of_run))
        tick(25 + int(45 * (si + 1) / max(1, restarts)),
             f"Restart {si + 1}: inertia {inertia / 1e6:.1f}")
        if best is None or inertia < best[0]:
            best = (inertia, pon_of_run)
    if best is None:                                    # pragma: no cover
        raise PonWayleaveError("Clustering produced no result.")
    pon_of_run = best[1]

    tick(85, "Numbering outward from the DC")
    pon_of_run = renumber_from_dc(graph, pon_of_run, dc_xy, warnings)

    pon_of_stand = _labels_from_runs(snap_run, pon_of_run)
    counts = np.bincount(pon_of_stand, minlength=int(pon_of_stand.max()) + 1)[1:]

    result = GroupingResult(
        pon_of_stand=pon_of_stand,
        pon_of_run=pon_of_run,
        graph=graph,
        snap_run=snap_run,
        snap_offset_m=snap_off,
        warnings=warnings,
        stats={
            "stands": int(n),
            "pons": int(pon_of_stand.max()),
            "target": int(target),
            "max_stands": int(max_stands),
            "runs": len(graph.runs),
            "runs_presplit": int(n_presplit),
            "span_components": graph.n_components,
            "span_length_m": round(graph.total_length_m()),
            "stands_min": int(counts.min()),
            "stands_median": int(np.median(counts)),
            "stands_max": int(counts.max()),
            "stands_mean": round(float(counts.mean()), 1),
            "over_cap": int((counts > max_stands).sum()),
            "snap_p50_m": round(float(np.percentile(snap_off, 50)), 1),
            "snap_p90_m": round(float(np.percentile(snap_off, 90)), 1),
            "snap_max_m": round(float(snap_off.max()), 1),
            "inertia": float(best[0]),
            "restarts": int(min(restarts, len(RESTART_SEEDS))),
        },
    )
    tick(100, f"{result.n_pons} PONs")
    return result


# ── stages ──────────────────────────────────────────────────────────────────

def _snap(graph: SpanGraph, xy):
    """Nearest run, position along it, and perpendicular offset, per stand.

    Uses true geometric distance. A bounding-box "nearest" is not good enough:
    on long sprawling span lines it returns the wrong feature and inflates the
    measured offset by hundreds of metres (measured, 2026-09-04).
    """
    runs = graph.runs
    # candidate runs via densified vertices, then exact distance among them
    verts, owner = [], []
    for i, r in enumerate(runs):
        for c in r.coords:
            verts.append(c)
            owner.append(i)
    tree = cKDTree(np.asarray(verts, dtype=float))
    owner = np.asarray(owner)

    run_idx, pos, off = [], [], []
    kq = min(24, len(verts))
    for x, y in xy:
        _d, idx = tree.query([x, y], k=kq)
        cand = np.unique(owner[np.atleast_1d(idx)])
        pt = _Pt(x, y)
        bi, bd = int(cand[0]), float("inf")
        for c in cand:
            d = runs[int(c)].distance(pt)
            if d < bd:
                bd, bi = d, int(c)
        run_idx.append(bi)
        pos.append(float(runs[bi].project(pt)))
        off.append(float(bd))
    return run_idx, pos, np.asarray(off, dtype=float)


def _Pt(x, y):
    from shapely.geometry import Point
    return Point(x, y)


def _presplit(graph, xy, snap_run, snap_pos, snap_off, max_stands, snap_m):
    """Split any run that alone carries more than the cap.

    Cut at the largest gap between consecutive houses along the run — the
    natural break in the housing, not an arbitrary midpoint. Bounded, because
    duplicate coordinates can otherwise make the cut fail to separate anything
    and loop forever.
    """
    n_split = 0
    for _ in range(200):
        load = defaultdict(list)
        for i, r in enumerate(snap_run):
            load[r].append(snap_pos[i])
        over = [r for r, ps in load.items() if len(ps) > max_stands]
        if not over:
            break
        made = False
        for r in over:
            ln = graph.runs[r]
            ps = sorted(load[r])
            gaps = [(ps[i + 1] - ps[i], (ps[i + 1] + ps[i]) / 2.0)
                    for i in range(len(ps) - 1)]
            lo, hi = ln.length * 0.2, ln.length * 0.8
            mid = [g for g in gaps if lo < g[1] < hi] or gaps
            if not mid:
                break
            cut = max(mid)[1]
            if not (0.5 < cut < ln.length - 0.5):
                break                       # cannot separate — leave it
            a = _slice(ln, 0.0, cut)
            b = _slice(ln, cut, ln.length)
            if a is None or b is None:
                break
            graph.runs[r] = a
            graph.runs.append(b)
            n_split += 1
            made = True
        if not made:
            break
        graph = SpanGraph(graph.runs, snap_m=snap_m)
        snap_run, snap_pos, snap_off = _snap(graph, xy)
    return graph, snap_run, snap_pos, snap_off, n_split


def _slice(ln: LineString, a: float, b: float):
    if b - a < 0.5:
        return None
    n = max(2, int((b - a) / 5.0) + 2)
    return LineString([ln.interpolate(x) for x in np.linspace(a, b, n)])


def _capacitated_kmeans(xy, k, cap, seed, is_cancelled):
    """k-means with a hard maximum cluster size.

    Assignment is greedy over (stand, centre) pairs in ascending distance, but
    only over each stand's nearest few centres via a KD-tree — a dense n x k
    matrix plus a global argsort is ~1-3 GB and tens of minutes at 50,000
    stands, which is not shippable.
    """
    n = len(xy)
    k = max(1, min(int(k), n))
    rng = np.random.default_rng(seed)

    # k-means++ seeding
    centres = [xy[rng.integers(n)]]
    d2 = ((xy - centres[0]) ** 2).sum(1)
    for _ in range(k - 1):
        total = float(d2.sum())
        if not np.isfinite(total) or total <= 0:
            centres.append(xy[rng.integers(n)])       # all points coincide
        else:
            centres.append(xy[rng.choice(n, p=d2 / total)])
        d2 = np.minimum(d2, ((xy - centres[-1]) ** 2).sum(1))
    centres = np.asarray(centres, dtype=float)

    labels = np.zeros(n, dtype=int)
    for _ in range(30):
        if is_cancelled():
            raise PonWayleaveError("Cancelled.")
        tree = cKDTree(centres)
        probe = min(k, max(4, int(math.ceil(3.0 * n / max(1, k * 1)))))
        probe = min(k, max(4, min(probe, 32)))
        dist, cand = tree.query(xy, k=probe)
        dist = np.atleast_2d(dist)
        cand = np.atleast_2d(cand)

        order = np.argsort(dist, axis=None, kind="stable")
        rows, cols = np.unravel_index(order, dist.shape)
        labels[:] = -1
        room = np.full(k, cap, dtype=int)
        left = n
        for r, c in zip(rows, cols):
            if labels[r] != -1:
                continue
            j = int(cand[r, c])
            if room[j] <= 0:
                continue
            labels[r] = j
            room[j] -= 1
            left -= 1
            if left == 0:
                break
        if left:                       # candidates exhausted — place the rest
            for r in np.where(labels == -1)[0]:
                free = np.where(room > 0)[0]
                if not len(free):
                    free = np.arange(k)
                d = np.hypot(centres[free, 0] - xy[r, 0], centres[free, 1] - xy[r, 1])
                j = int(free[int(d.argmin())])
                labels[r] = j
                room[j] -= 1

        new = np.array([xy[labels == j].mean(0) if (labels == j).any() else centres[j]
                        for j in range(k)])
        if np.allclose(new, centres, atol=0.5):
            centres = new
            break
        centres = new
    return labels


def _vote_runs(graph, stands_on_run, labels):
    """Each run takes the majority PON of the stands on it — runs stay atomic."""
    pon_of_run = {}
    for r in range(len(graph.runs)):
        ids = stands_on_run.get(r, ())
        if ids:
            vals, cnt = np.unique(labels[list(ids)], return_counts=True)
            pon_of_run[r] = int(vals[int(cnt.argmax())]) + 1
    # runs with no stands join the nearest run that has a PON
    unset = [r for r in range(len(graph.runs)) if r not in pon_of_run]
    if unset and pon_of_run:
        known = list(pon_of_run)
        cents = np.array([[graph.runs[r].centroid.x, graph.runs[r].centroid.y]
                          for r in known])
        tree = cKDTree(cents)
        for r in unset:
            c = graph.runs[r].centroid
            _d, i = tree.query([c.x, c.y], k=1)
            pon_of_run[r] = pon_of_run[known[int(i)]]
    elif unset:
        for r in unset:
            pon_of_run[r] = 1
    return pon_of_run


def _load(stands_on_run, runs):
    return sum(len(stands_on_run.get(r, ())) for r in runs)


def _by_pon(pon_of_run):
    g = defaultdict(set)
    for r, p in pon_of_run.items():
        g[p].add(r)
    return g


def _repair_contiguity(graph, stands_on_run, pon_of_run):
    """A PON keeps its biggest connected group; strays join a PON they touch."""
    for _ in range(20):
        fixed = False
        for p, runs in list(_by_pon(pon_of_run).items()):
            groups = graph.run_groups(runs)
            if len(groups) <= 1:
                continue
            groups.sort(key=lambda g: _load(stands_on_run, g), reverse=True)
            for stray in groups[1:]:
                votes = defaultdict(int)
                for r in stray:
                    for nb in graph.run_neighbours.get(r, ()):
                        q = pon_of_run.get(nb)
                        if q is not None and q != p:
                            votes[q] += 1
                if votes:
                    tgt = max(sorted(votes), key=lambda q: votes[q])
                    for r in stray:
                        pon_of_run[r] = tgt
                    fixed = True
        if not fixed:
            break
    return pon_of_run


def _split_runs(graph, stands_on_run, runs, max_stands):
    """Cut a connected run-set in two along its own span, as evenly as possible."""
    runs = set(runs)
    groups = graph.run_groups(runs)
    if len(groups) > 1:                     # already in pieces — split there
        groups.sort(key=lambda g: _load(stands_on_run, g), reverse=True)
        return groups[0], set().union(*groups[1:])
    H = nx.Graph()
    H.add_nodes_from(runs)
    for r in runs:
        for nb in graph.run_neighbours.get(r, ()):
            if nb in runs:
                H.add_edge(r, nb)
    if H.number_of_edges() == 0:
        ordered = sorted(runs)
        return {ordered[0]}, set(ordered[1:])
    T = nx.minimum_spanning_tree(H)
    total = _load(stands_on_run, runs)
    best = best_legal = None
    for e in list(T.edges()):
        T.remove_edge(*e)
        parts = list(nx.connected_components(T))
        T.add_edge(*e)
        if len(parts) != 2:
            continue
        a = _load(stands_on_run, parts[0])
        score = abs(a - (total - a))
        if best is None or score < best[0]:
            best = (score, set(parts[0]), set(parts[1]))
        if max(a, total - a) <= max_stands:
            if best_legal is None or score < best_legal[0]:
                best_legal = (score, set(parts[0]), set(parts[1]))
    chosen = best_legal or best
    if chosen is None:
        ordered = sorted(runs)
        return {ordered[0]}, set(ordered[1:])
    return chosen[1], chosen[2]


def _split_over_cap(graph, stands_on_run, pon_of_run, max_stands):
    """Split every PON over the cap. One unsplittable PON must not stop the rest."""
    nxt = max(pon_of_run.values()) + 1 if pon_of_run else 1
    stuck = set()
    for _ in range(2000):
        groups = _by_pon(pon_of_run)
        over = [p for p, rs in groups.items()
                if p not in stuck and _load(stands_on_run, rs) > max_stands]
        if not over:
            break
        p = max(over, key=lambda q: _load(stands_on_run, groups[q]))
        a, b = _split_runs(graph, stands_on_run, groups[p], max_stands)
        if not a or not b:
            stuck.add(p)          # continue, never break: other PONs still need it
            continue
        for r in b:
            pon_of_run[r] = nxt
        nxt += 1
    return pon_of_run


def _consolidate(graph, stands_on_run, pon_of_run, k_target, max_stands):
    """Merge span-adjacent PONs that fit under the cap, tightest pair first.

    With no minimum size there is nothing to rescue, so this only pulls the PON
    count back toward n/target when splitting overshot.
    """
    for _ in range(500):
        groups = _by_pon(pon_of_run)
        if len(groups) <= k_target:
            break
        load = {p: _load(stands_on_run, rs) for p, rs in groups.items()}
        touch = defaultdict(set)
        for r, p in pon_of_run.items():
            for nb in graph.run_neighbours.get(r, ()):
                q = pon_of_run.get(nb)
                if q is not None and q != p:
                    touch[p].add(q)
        best = None
        for p in sorted(touch):
            for q in sorted(touch[p]):
                if q <= p or load[p] + load[q] > max_stands:
                    continue
                merged = groups[p] | groups[q]
                if not graph.runs_connected(merged):
                    continue
                score = _spread(stands_on_run, merged)
                if best is None or score < best[0]:
                    best = (score, p, q)
        if best is None:
            break
        _, p, q = best
        for r in groups[q]:
            pon_of_run[r] = p
    return pon_of_run


def _dissolve_toward(graph, stands_on_run, pon_of_run, k_target, max_stands):
    """Pull the PON count down toward ``k_target`` by dissolving the smallest.

    Merging two PONs whole is usually impossible once both are near the cap
    (two 86s do not fit under 120), so the smallest PON is taken apart instead
    and its runs handed out ONE AT A TIME to span-adjacent PONs that have room.
    Adjacency is re-read after every placement, because an interior run only
    becomes placeable once the run beside it has already moved.

    Fewer, fuller PONs is the point: each PON costs an OLT port.
    """
    blocked = set()
    for _ in range(400):
        groups = _by_pon(pon_of_run)
        if len(groups) <= k_target:
            break
        load = {p: _load(stands_on_run, rs) for p, rs in groups.items()}
        cand = [p for p in sorted(load, key=lambda q: load[q]) if p not in blocked]
        if not cand:
            break
        done = False
        for victim in cand:
            room = {p: max_stands - load[p] for p in load if p != victim}
            remaining = set(groups[victim])
            trial = dict(pon_of_run)
            progress = True
            while remaining and progress:
                progress = False
                for r in sorted(remaining, key=lambda x: -len(stands_on_run.get(x, ()))):
                    need = len(stands_on_run.get(r, ()))
                    best = None
                    for nb in sorted(graph.run_neighbours.get(r, ())):
                        q = trial.get(nb)
                        if q is None or q == victim or nb in remaining:
                            continue
                        if room.get(q, 0) < need:
                            continue
                        owned = {x for x, v in trial.items() if v == q} | {r}
                        if not graph.runs_connected(owned):
                            continue
                        if best is None or room[q] > room[best]:
                            best = q
                    if best is None:
                        continue
                    trial[r] = best
                    room[best] -= need
                    remaining.discard(r)
                    progress = True
            if remaining:
                blocked.add(victim)      # cannot dissolve this one; try the next
                continue
            pon_of_run = trial
            pon_of_run = _repair_contiguity(graph, stands_on_run, pon_of_run)
            done = True
            break
        if not done:
            break
    return pon_of_run


def _spread(stands_on_run, runs):
    idx = [i for r in runs for i in stands_on_run.get(r, ())]
    return len(idx)


def _refine(graph, stands_on_run, xy, pon_of_run, max_stands, sweeps=None):
    """Move whole runs to a neighbouring PON when it tightens the clumping.

    Objective is within-PON sum of squared distance to the centroid — the same
    thing k-means minimises, and the thing JJ described as "how clumped are the
    demand points". Evaluated in O(1) per move from running totals via
    sum|x|^2 - |sum x|^2 / n.
    """
    groups = _by_pon(pon_of_run)
    if sweeps is None:
        sweeps = max(60, 4 * len(groups))       # scales with the problem

    def stats_of(runs):
        idx = [i for r in runs for i in stands_on_run.get(r, ())]
        if not idx:
            return [0, 0.0, 0.0, 0.0]
        a = xy[idx]
        return [len(idx), float(a[:, 0].sum()), float(a[:, 1].sum()),
                float((a ** 2).sum())]

    def inertia(s):
        n, sx, sy, ss = s
        return 0.0 if n == 0 else ss - (sx * sx + sy * sy) / n

    stat = {p: stats_of(rs) for p, rs in groups.items()}
    run_stat = {r: stats_of([r]) for r in pon_of_run}
    moves = 0
    for _ in range(sweeps):
        best = None
        for p in sorted(groups):
            runs = groups[p]
            if len(runs) < 2:
                continue
            for r in sorted(runs):
                rs = run_stat[r]
                if rs[0] == 0:
                    continue
                if not graph.runs_connected(runs - {r}):
                    continue
                for nb in sorted(graph.run_neighbours.get(r, ())):
                    q = pon_of_run.get(nb)
                    if q is None or q == p:
                        continue
                    if stat[q][0] + rs[0] > max_stands:
                        continue
                    if not graph.runs_connected(groups[q] | {r}):
                        continue
                    sp, sq = stat[p], stat[q]
                    np_ = [sp[i] - rs[i] for i in range(4)]
                    nq_ = [sq[i] + rs[i] for i in range(4)]
                    delta = (inertia(np_) + inertia(nq_)) - (inertia(sp) + inertia(sq))
                    if delta < -1.0 and (best is None or delta < best[0]):
                        best = (delta, r, p, q, np_, nq_)
        if best is None:
            break
        _, r, p, q, np_, nq_ = best
        groups[p].discard(r)
        groups[q].add(r)
        pon_of_run[r] = q
        stat[p], stat[q] = np_, nq_
        moves += 1
    # drop any PON left with no runs
    return {r: p for r, p in pon_of_run.items()}


def renumber_from_dc(graph, pon_of_run, dc_xy, warnings=None):
    """PON 1 nearest the DC, increasing outward — the OPL labelling rule.

    Public because it must be applied AGAIN after anything that moves runs
    between PONs. ``balance_pons`` does exactly that, and without a second
    pass the numbering silently stops meaning what the HT 2 dialog promises
    the operator it means.

    ``warnings`` is optional so a re-numbering pass does not duplicate the
    DC-placement warning the first pass already raised.
    """
    if warnings is None:
        warnings = []
    groups = _by_pon(pon_of_run)
    reach = {}
    if dc_xy is not None:
        node, dist = graph.nearest_node(float(dc_xy[0]), float(dc_xy[1]))
        if dist > 500.0:
            warnings.append(
                f"The DC/POP is {dist:.0f} m from the nearest span. PON numbering "
                "still runs outward from it, but check the DC is in the right place."
            )
        try:
            along = graph.distance_from(node)
        except Exception:
            along = {}
        for p, runs in groups.items():
            ds = []
            for r in runs:
                a, b = graph.run_nodes[r]
                for nd in (a, b):
                    if nd in along:
                        ds.append(along[nd])
            reach[p] = min(ds) if ds else math.inf
    if not reach or all(not math.isfinite(v) for v in reach.values()):
        # no DC: fall back to distance from the centroid of the whole route
        cx = float(np.mean([r.centroid.x for r in graph.runs]))
        cy = float(np.mean([r.centroid.y for r in graph.runs]))
        for p, runs in groups.items():
            reach[p] = min(math.hypot(graph.runs[r].centroid.x - cx,
                                      graph.runs[r].centroid.y - cy) for r in runs)
        if dc_xy is None:
            warnings.append(
                "No DC/POP point was given, so PONs are numbered outward from the "
                "middle of the route instead."
            )
    order = sorted(reach, key=lambda p: (reach[p], p))
    remap = {old: i + 1 for i, old in enumerate(order)}
    return {r: remap[p] for r, p in pon_of_run.items()}


def _labels_from_runs(snap_run, pon_of_run):
    return np.asarray([pon_of_run.get(r, 0) for r in snap_run], dtype=int)


def _inertia(xy, labels):
    total = 0.0
    for p in np.unique(labels):
        if p <= 0:
            continue
        a = xy[labels == p]
        if len(a) < 2:
            continue
        total += float(((a - a.mean(0)) ** 2).sum())
    return total
