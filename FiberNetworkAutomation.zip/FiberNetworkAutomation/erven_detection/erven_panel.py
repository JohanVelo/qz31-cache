"""
Dockable Erven Detection panel.

PyQGIS + PyQt5 only — no heavy deps. Talks to the MCP server via MCPClient
(stdlib HTTP on port 8780). Uses a QTimer to poll progress every 500ms.
"""

from __future__ import annotations

import logging

from qgis.PyQt.QtCore import Qt, QTimer
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QDockWidget,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QProgressBar,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

logger = logging.getLogger(__name__)

_PRESETS = [
    ("SA Informal (shacks)", "sa_informal"),
    ("SA Formal low-cost (RDP)", "sa_formal_low"),
    ("SA Mixed", "sa_mixed"),
    ("SA Commercial (spaza)", "sa_commercial"),
    ("Rural (homesteads)", "rural"),
    ("Dense urban", "dense_urban"),
]

_STEP_LABELS = {
    "status_check":            "Checking backend...",
    "acquire_raster":          "Acquiring imagery...",
    "export_canvas_raster":    "Exporting canvas...",
    "fetch_basemap":           "Downloading basemap...",
    "validate_imagery":        "Validating imagery...",
    "detect_buildings":        "Detecting buildings...",
    "regularize_erven":        "Regularizing erven...",
    "add_to_qgis_erven":       "Loading erven layer...",
    "place_onts":              "Placing ONTs...",
    "group_pon":               "Grouping PONs...",
    "complete":                "Done!",
    "failed":                  "Failed",
    "cancelled":               "Cancelled",
}


class ErvenPanel(QDockWidget):
    """Dockable panel with controls, progress bar, and log output."""

    def __init__(self, iface, parent=None):
        super().__init__("Erven Detection", parent)
        self.iface = iface
        self.setObjectName("ErvenDetectionPanel")
        self.setAllowedAreas(Qt.RightDockWidgetArea | Qt.LeftDockWidgetArea)

        from .mcp_client import MCPClient
        from .snapshot_manager import SnapshotManager

        self._client = MCPClient()
        self._snapshots = SnapshotManager()
        self._poll_timer = QTimer(self)
        self._poll_timer.setInterval(500)
        self._poll_timer.timeout.connect(self._poll_progress)

        self._build_ui()

    # ── UI construction ───────────────────────────────────────────────────

    def _build_ui(self):
        root = QWidget()
        self.setWidget(root)
        layout = QVBoxLayout(root)
        layout.setSpacing(8)
        layout.setContentsMargins(8, 8, 8, 8)

        # Velocity Nexus theme (Phase 2, JJ-approved) — never break the panel
        try:
            try:
                from ..branding import vf_style
            except ImportError:
                from branding import vf_style
            self.setStyleSheet(vf_style.DIALOG_QSS)
            layout.addWidget(vf_style.make_header('Erven Detection', root))
        except Exception as e:
            print(f'[FiberNet] erven panel theming skipped: {e}')

        # ── Server status indicator ───────────────────────────────────────
        status_row = QHBoxLayout()
        self._status_dot = QLabel("●")
        self._status_dot.setFixedWidth(16)
        self._status_label = QLabel("MCP server: checking...")
        self._status_label.setStyleSheet("font-size: 11px; color: #586e75;")
        status_row.addWidget(self._status_dot)
        status_row.addWidget(self._status_label)
        status_row.addStretch()
        layout.addLayout(status_row)

        # ── Settings group ────────────────────────────────────────────────
        settings_grp = QGroupBox("Detection Settings")
        sg = QVBoxLayout(settings_grp)

        # Preset dropdown
        preset_row = QHBoxLayout()
        preset_row.addWidget(QLabel("Preset:"))
        self._preset_combo = QComboBox()
        for label, _ in _PRESETS:
            self._preset_combo.addItem(label)
        self._preset_combo.setCurrentIndex(0)
        preset_row.addWidget(self._preset_combo)
        sg.addLayout(preset_row)

        # Thresholds
        thresh_row = QHBoxLayout()
        thresh_row.addWidget(QLabel("Box thresh:"))
        self._box_thresh = QDoubleSpinBox()
        self._box_thresh.setRange(0.10, 0.50)
        self._box_thresh.setSingleStep(0.01)
        self._box_thresh.setValue(0.22)
        self._box_thresh.setDecimals(2)
        self._box_thresh.setFixedWidth(70)
        thresh_row.addWidget(self._box_thresh)

        thresh_row.addWidget(QLabel("Text:"))
        self._text_thresh = QDoubleSpinBox()
        self._text_thresh.setRange(0.10, 0.50)
        self._text_thresh.setSingleStep(0.01)
        self._text_thresh.setValue(0.22)
        self._text_thresh.setDecimals(2)
        self._text_thresh.setFixedWidth(70)
        thresh_row.addWidget(self._text_thresh)
        thresh_row.addStretch()
        sg.addLayout(thresh_row)

        # Buffer + min area
        opt_row = QHBoxLayout()
        opt_row.addWidget(QLabel("Buffer (m):"))
        self._buffer_spin = QDoubleSpinBox()
        self._buffer_spin.setRange(0.0, 4.0)
        self._buffer_spin.setSingleStep(0.5)
        self._buffer_spin.setValue(1.5)
        self._buffer_spin.setDecimals(1)
        self._buffer_spin.setFixedWidth(65)
        opt_row.addWidget(self._buffer_spin)

        opt_row.addWidget(QLabel("Min area:"))
        self._min_area = QDoubleSpinBox()
        self._min_area.setRange(1.0, 100.0)
        self._min_area.setSingleStep(1.0)
        self._min_area.setValue(6.0)
        self._min_area.setDecimals(0)
        self._min_area.setSuffix(" m²")
        self._min_area.setFixedWidth(75)
        opt_row.addWidget(self._min_area)
        opt_row.addStretch()
        sg.addLayout(opt_row)

        # Source selection
        self._use_canvas_chk = QCheckBox("Use loaded raster (canvas export)")
        self._use_canvas_chk.setChecked(True)
        sg.addWidget(self._use_canvas_chk)

        # FTTH checkbox
        self._ftth_chk = QCheckBox("Run FTTH pipeline (ONT placement + PON grouping)")
        sg.addWidget(self._ftth_chk)

        layout.addWidget(settings_grp)

        # ── Run / Cancel buttons ──────────────────────────────────────────
        btn_row = QHBoxLayout()
        self._run_btn = QPushButton("🔍  Run Detection")
        self._run_btn.setStyleSheet(
            "QPushButton { background-color: #859900; color: white; "
            "font-weight: bold; padding: 6px 12px; border-radius: 4px; }"
            "QPushButton:hover { background-color: #6c7a00; }"
            "QPushButton:disabled { background-color: #93a1a1; }"
        )
        self._run_btn.clicked.connect(self._on_run_clicked)
        btn_row.addWidget(self._run_btn)

        self._cancel_btn = QPushButton("✖  Cancel")
        self._cancel_btn.setEnabled(False)
        self._cancel_btn.setStyleSheet(
            "QPushButton { background-color: #dc322f; color: white; "
            "padding: 6px 12px; border-radius: 4px; }"
            "QPushButton:disabled { background-color: #93a1a1; }"
        )
        self._cancel_btn.clicked.connect(self._on_cancel_clicked)
        btn_row.addWidget(self._cancel_btn)
        layout.addLayout(btn_row)

        # Undo button
        self._undo_btn = QPushButton("↩  Undo Detection")
        self._undo_btn.setEnabled(False)
        self._undo_btn.setStyleSheet("padding: 4px 8px;")
        self._undo_btn.clicked.connect(self._on_undo_clicked)
        layout.addWidget(self._undo_btn)

        # ── Progress bar ──────────────────────────────────────────────────
        self._progress_label = QLabel("Ready")
        self._progress_label.setStyleSheet("font-size: 11px; color: #586e75;")
        layout.addWidget(self._progress_label)

        self._progress_bar = QProgressBar()
        self._progress_bar.setRange(0, 100)
        self._progress_bar.setValue(0)
        self._progress_bar.setTextVisible(True)
        layout.addWidget(self._progress_bar)

        # ── Log area ──────────────────────────────────────────────────────
        self._log = QTextEdit()
        self._log.setReadOnly(True)
        self._log.setMaximumHeight(180)
        self._log.setStyleSheet(
            "QTextEdit { background-color: #fdf6e3; font-family: monospace; "
            "font-size: 11px; color: #586e75; }"
        )
        layout.addWidget(self._log)
        layout.addStretch()

        # Initial server check
        QTimer.singleShot(500, self._check_server_status)

    # ── Button handlers ───────────────────────────────────────────────────

    def _on_run_clicked(self):
        if not self._client.is_connected():
            self._log_msg("❌ MCP server not running. Start it with: erven-mcp --http", error=True)
            return

        # Save snapshot for undo
        snap_id = self._snapshots.create_snapshot()
        self._log_msg(f"📸 Snapshot saved ({snap_id})")

        preset_index = self._preset_combo.currentIndex()
        _, preset_key = _PRESETS[preset_index]

        config = {
            "source": "canvas" if self._use_canvas_chk.isChecked() else "esri",
            "preset": preset_key,
            "box_threshold": self._box_thresh.value(),
            "text_threshold": self._text_thresh.value(),
            "buffer_m": self._buffer_spin.value(),
            "min_area_m2": self._min_area.value(),
            "run_ftth": self._ftth_chk.isChecked(),
        }

        result = self._client.run_pipeline(config)
        if result.get("error"):
            self._log_msg(f"❌ Failed to start: {result['error']}", error=True)
            return

        self._log_msg("🚀 Pipeline started...")
        self._run_btn.setEnabled(False)
        self._cancel_btn.setEnabled(True)
        self._undo_btn.setEnabled(False)
        self._progress_bar.setValue(0)
        self._poll_timer.start()

    def _on_cancel_clicked(self):
        self._client.cancel_pipeline()
        self._log_msg("⏹ Cancel requested...")
        self._cancel_btn.setEnabled(False)

    def _on_undo_clicked(self):
        result = self._snapshots.restore_snapshot()
        if result.get("error"):
            self._log_msg(f"❌ Undo failed: {result['error']}", error=True)
        else:
            n = result.get("removed", 0)
            self._log_msg(f"↩ Undo: removed {n} layer(s)")
            self._undo_btn.setEnabled(False)
            self._progress_bar.setValue(0)
            self._progress_label.setText("Ready")

    # ── Progress polling ──────────────────────────────────────────────────

    def _poll_progress(self):
        prog = self._client.get_progress()
        if prog.get("error"):
            self._poll_timer.stop()
            self._log_msg(f"⚠ Lost connection to MCP server: {prog['error']}", error=True)
            self._reset_buttons()
            return

        fraction = prog.get("progress", 0.0)
        step = prog.get("step", "")
        message = prog.get("message", "")
        running = prog.get("pipeline_running", False)

        pct = int(fraction * 100)
        self._progress_bar.setValue(pct)

        label = _STEP_LABELS.get(step, step)
        self._progress_label.setText(f"{label} ({pct}%)")

        if message:
            self._log_msg(message)

        if not running and pct > 0:
            # Pipeline finished — fetch final result
            self._poll_timer.stop()
            self._reset_buttons()

            result = self._client.get_pipeline_result()
            if result.get("error"):
                self._log_msg(f"❌ {result['error']}", error=True)
                self._progress_bar.setStyleSheet("QProgressBar::chunk { background-color: #dc322f; }")
            elif result.get("cancelled"):
                self._log_msg("⏹ Pipeline cancelled")
            else:
                summary = result.get("summary", "Done")
                self._log_msg(f"✅ {summary}")
                self._progress_bar.setStyleSheet("QProgressBar::chunk { background-color: #859900; }")
                self._undo_btn.setEnabled(True)

    def _reset_buttons(self):
        self._run_btn.setEnabled(True)
        self._cancel_btn.setEnabled(False)

    # ── Server status ─────────────────────────────────────────────────────

    def _check_server_status(self):
        if self._client.is_connected():
            status = self._client.get_status()
            device = status.get("device_name", "?")
            ready = status.get("ready", False)
            self._status_dot.setStyleSheet(
                f"color: {'#859900' if ready else '#b58900'}; font-size: 14px;"
            )
            self._status_label.setText(
                f"MCP server: {'ready' if ready else 'connected (not ready)'} — {device}"
            )
            if not ready:
                for err in status.get("errors", []):
                    self._log_msg(f"⚠ {err}")
        else:
            self._status_dot.setStyleSheet("color: #dc322f; font-size: 14px;")
            self._status_label.setText("MCP server: offline  (run: erven-mcp --http)")

    # ── Log helper ────────────────────────────────────────────────────────

    def _log_msg(self, msg: str, error: bool = False):
        colour = "#dc322f" if error else "#586e75"
        self._log.append(f'<span style="color:{colour}">{msg}</span>')
        # Auto-scroll
        sb = self._log.verticalScrollBar()
        sb.setValue(sb.maximum())

    # ── Cleanup ───────────────────────────────────────────────────────────

    def closeEvent(self, event):
        self._poll_timer.stop()
        super().closeEvent(event)
