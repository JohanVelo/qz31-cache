"""Vuma data fetch worker — runs in venv subprocess.

Reads  C:/Temp/_vuma_fetch_cfg.json
Writes C:/Temp/vuma_erven.geojson
       C:/Temp/vuma_buildings.geojson
       C:/Temp/vuma_ramp_centroids.geojson  (only when Overture returns 0 buildings
                                             and building_detect.onnx is present)
"""
import json
import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

import ssl
import geopandas as gpd
from shapely.geometry import Polygon, MultiPolygon, mapping

def _data_dir() -> Path:
    """Portable scratch dir (mirrors vf_paths.data_dir; standalone worker)."""
    import os
    import tempfile
    env = os.environ.get("VF_DATA_DIR")
    if env:
        os.makedirs(env, exist_ok=True)
        return Path(env)
    if os.path.isdir("C:/Temp"):
        return Path("C:/Temp")
    d = Path(tempfile.gettempdir()) / "VelocityFibre"
    d.mkdir(parents=True, exist_ok=True)
    return d


_DD = _data_dir()
CFG_FILE = _DD / "_vuma_fetch_cfg.json"
ERVEN_OUT = _DD / "vuma_erven.geojson"
BUILDINGS_OUT = _DD / "vuma_buildings.geojson"
RAMP_CENTROIDS_OUT = _DD / "vuma_ramp_centroids.geojson"

# RAMP model search paths (first found wins)
_RAMP_MODEL_PATHS = [
    Path(r"C:/Temp/building_detect.onnx"),
    Path(r"C:/Models/building_detect.onnx"),
    Path.home() / "Models/building_detect.onnx",
]

NGI_TILE_URL = "https://aerial.openstreetmap.org.za/layer/ngi-aerial/{z}/{x}/{y}.jpg"
RAMP_ZOOM = 18
RAMP_MODEL_PX = 256
RAMP_MASK_THRESH = 0.45
RAMP_MIN_BLOB_PX = 12
RAMP_DEDUP_M = 8.0   # merge centroids closer than this (tile-edge duplicates)

CSG_URL = (
    "https://csggis.drdlr.gov.za/server/rest/services"
    "/CSGSearch/MapServer/2/query"
)
PAGE_SIZE = 1000
MAX_PAGES = 80  # 80k cap

# DRDLR certificate not trusted by default — disable verification
_SSL_CTX = ssl.create_default_context()
_SSL_CTX.check_hostname = False
_SSL_CTX.verify_mode = ssl.CERT_NONE


def log(msg):
    print(msg, flush=True)


# ── CSG erven fetch ───────────────────────────────────────────────────────────

def _signed_area(coords):
    s = 0.0
    for i in range(len(coords) - 1):
        x1, y1 = coords[i][:2]
        x2, y2 = coords[i + 1][:2]
        s += (x2 - x1) * (y2 + y1)
    return s


def _esri_rings_to_shapely(rings):
    """Esri JSON rings → Shapely (Multi)Polygon."""
    if not rings:
        return None
    polys, outer, holes = [], None, []
    for ring in rings:
        coords = [tuple(c[:2]) for c in ring]
        if len(coords) < 4:
            continue
        if _signed_area(coords) > 0:
            if outer is not None:
                polys.append(Polygon(outer, holes))
            outer, holes = coords, []
        else:
            if outer is not None:
                holes.append(coords)
    if outer is not None:
        polys.append(Polygon(outer, holes))
    if not polys:
        return None
    return polys[0] if len(polys) == 1 else MultiPolygon(polys)


def _csg_get(params):
    """HTTP GET to CSG endpoint with SSL verification disabled."""
    import urllib.parse
    import urllib.request
    url = CSG_URL + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": "fiber-hld/1.0"})
    with urllib.request.urlopen(req, context=_SSL_CTX, timeout=60) as resp:
        return json.loads(resp.read().decode("utf-8"))


def fetch_csg_erven(bbox):
    """Download CSG erven for bbox=[minx,miny,maxx,maxy] in EPSG:4326."""
    log(f"[CSG] Fetching erven for bbox {bbox} ...")
    all_feats = []
    for page in range(MAX_PAGES):
        params = {
            "where": "LSTATUS IN ('R','S')",
            "geometry": f"{bbox[0]},{bbox[1]},{bbox[2]},{bbox[3]}",
            "geometryType": "esriGeometryEnvelope",
            "inSR": "4326",
            "outSR": "4326",
            "spatialRel": "esriSpatialRelIntersects",
            "returnGeometry": "true",
            "outFields": "PRCL_KEY,LSTATUS,WSTATUS,GEOM_AREA,TAG_VALUE",
            "f": "json",
            "resultRecordCount": PAGE_SIZE,
            "resultOffset": page * PAGE_SIZE,
        }
        for attempt in range(3):
            try:
                data = _csg_get(params)
                break
            except Exception as e:
                log(f"  [CSG] attempt {attempt+1} failed: {e}")
                time.sleep(2 ** attempt)
        else:
            raise RuntimeError("CSG fetch failed after 3 attempts")

        if "error" in data:
            raise RuntimeError(f"CSG server error: {data['error']}")

        esri_feats = data.get("features", [])
        for ef in esri_feats:
            rings = ef.get("geometry", {}).get("rings")
            geom = _esri_rings_to_shapely(rings)
            if geom is None:
                continue
            attr = ef.get("attributes", {})
            all_feats.append({
                "type": "Feature",
                "geometry": mapping(geom),
                "properties": {
                    "PRCL_KEY": str(attr.get("PRCL_KEY") or ""),
                    "Label": str(attr.get("TAG_VALUE") or ""),
                    "Area": float(attr.get("GEOM_AREA") or 0),
                    "LSTATUS": str(attr.get("LSTATUS") or ""),
                    "WSTATUS": str(attr.get("WSTATUS") or ""),
                },
            })
        log(f"  [CSG] page {page+1}: +{len(esri_feats)}  total={len(all_feats)}")
        if len(esri_feats) < PAGE_SIZE:
            break
        if not data.get("exceededTransferLimit", False):
            break

    log(f"[CSG] Done — {len(all_feats)} erven")
    return all_feats


# ── Overture buildings fetch ──────────────────────────────────────────────────

def fetch_overture_buildings(bbox):
    """Download Overture building footprints for bbox=[minx,miny,maxx,maxy].

    Retries up to 3 times — first connection to AWS S3 often fails with a
    timeout on fresh environments.
    """
    log(f"[Overture] Fetching buildings for bbox {bbox} ...")
    import overturemaps
    last_err = None
    for attempt in range(1, 4):
        try:
            reader = overturemaps.record_batch_reader(
                "building",
                bbox=(bbox[0], bbox[1], bbox[2], bbox[3]),
            )
            table = reader.read_all()
            gdf = gpd.GeoDataFrame.from_arrow(table)
            if gdf.crs is None:
                gdf = gdf.set_crs(4326)
            log(f"[Overture] Got {len(gdf)} buildings")
            return gdf
        except Exception as e:
            last_err = e
            log(f"[Overture] attempt {attempt} failed: {e}")
            if attempt < 3:
                time.sleep(5 * attempt)
    log(f"[Overture] All attempts failed — {last_err}")
    return gpd.GeoDataFrame()


# ── One-per-erven primary selection ──────────────────────────────────────────

def assign_primary(buildings_gdf, erven_gdf):
    """Spatial join buildings → erven. Mark is_primary=1 for the largest
    building (by footprint area) within each erven. All others = 0."""
    if erven_gdf is None or len(erven_gdf) == 0:
        buildings_gdf["is_primary"] = 1
        return buildings_gdf

    # Work in a metric CRS for area comparisons (EPSG:32735 UTM 35S)
    b = buildings_gdf.copy().to_crs(32735)
    e = erven_gdf.copy().to_crs(32735)
    b["_area_m2"] = b.geometry.area

    joined = gpd.sjoin(b, e[["geometry"]], how="left", predicate="within")

    b["is_primary"] = 0
    b["area_m2"] = b["_area_m2"].round(2)

    # For each erven, pick the building with the largest footprint
    erven_groups = joined.groupby("index_right")
    for _, group in erven_groups:
        if len(group) == 0:
            continue
        primary_idx = group["_area_m2"].idxmax()
        b.at[primary_idx, "is_primary"] = 1

    # Buildings not within any erven: still give them is_primary=1
    # (they're genuine buildings, just outside cadastral coverage)
    no_erven = joined[joined["index_right"].isna()].index
    b.loc[no_erven, "is_primary"] = 1

    log(f"[Primary] {int(b['is_primary'].sum())} primary / {len(b)} total buildings")
    return b.to_crs(4326)


# ── AOI clip helper ───────────────────────────────────────────────────────────

def _load_aoi_geom(aoi_geojson: str | None):
    """Parse AOI GeoJSON string → Shapely geometry, or None if not provided."""
    if not aoi_geojson:
        return None
    try:
        from shapely.geometry import shape
        fc = json.loads(aoi_geojson)
        # Accept FeatureCollection, Feature, or bare geometry
        if fc.get("type") == "FeatureCollection":
            geoms = [shape(f["geometry"]) for f in fc.get("features", [])
                     if f.get("geometry")]
            if not geoms:
                return None
            from shapely.ops import unary_union
            return unary_union(geoms)
        if fc.get("type") == "Feature":
            return shape(fc["geometry"])
        return shape(fc)
    except Exception as e:
        log(f"[AOI] Could not parse AOI geometry: {e}")
        return None


def _clip_gdf_to_aoi(gdf: gpd.GeoDataFrame, aoi_geom) -> gpd.GeoDataFrame:
    """Keep only rows whose geometry intersects the AOI polygon."""
    if aoi_geom is None or len(gdf) == 0:
        return gdf
    mask = gdf.geometry.intersects(aoi_geom)
    clipped = gdf[mask].copy()
    log(f"[AOI clip] {len(gdf)} → {len(clipped)} features within AOI")
    return clipped


# ── RAMP fallback (runs when Overture returns 0 buildings) ────────────────────

def _latlon_to_tile(lat: float, lon: float, zoom: int) -> tuple[int, int]:
    import math

    n = 2**zoom
    x = int((lon + 180) / 360 * n)
    lat_r = math.radians(lat)
    y = int((1 - math.log(math.tan(lat_r) + 1 / math.cos(lat_r)) / math.pi) / 2 * n)
    return x, y


def _tile_nw_latlon(tx: int, ty: int, zoom: int) -> tuple[float, float]:
    import math

    n = 2**zoom
    lon = tx / n * 360 - 180
    lat = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * ty / n))))
    return lat, lon


def _fetch_ngi_tile(tx: int, ty: int, retries: int = 3):
    """Fetch one NGI aerial tile; returns PIL Image or None on failure."""
    import io

    try:
        import requests
        from PIL import Image
    except ImportError:
        return None

    url = NGI_TILE_URL.format(z=RAMP_ZOOM, x=tx, y=ty)
    for attempt in range(retries):
        try:
            r = requests.get(url, timeout=15, headers={"User-Agent": "BlitzFibre-QGIS-RAMP/1.0"})
            if r.status_code == 200:
                return Image.open(io.BytesIO(r.content)).convert("RGB")
        except Exception:
            if attempt < retries - 1:
                time.sleep(1)
    return None


def _dedup_centroids(points: list[dict], min_dist_m: float = RAMP_DEDUP_M) -> list[dict]:
    """Remove duplicate centroids closer than min_dist_m (tile-edge artefacts)."""
    import math

    if len(points) < 2:
        return points
    kept: list[dict] = []
    for pt in points:
        lon, lat = pt["lon"], pt["lat"]
        too_close = False
        for k in kept:
            dlat = (k["lat"] - lat) * 111320.0
            dlon = (k["lon"] - lon) * 111320.0 * math.cos(math.radians(lat))
            if dlat * dlat + dlon * dlon < min_dist_m * min_dist_m:
                too_close = True
                break
        if not too_close:
            kept.append(pt)
    return kept


def run_ramp_full_aoi(bbox: list[float], aoi_geom) -> gpd.GeoDataFrame:
    """Run RAMP on NGI tiles covering the bbox; return GDF of Point centroids.

    Returns an empty GeoDataFrame when:
      - building_detect.onnx is not found (logs install path)
      - onnxruntime / PIL / scipy are not installed
    """

    ramp_path = next((p for p in _RAMP_MODEL_PATHS if p.exists()), None)
    if ramp_path is None:
        log("[RAMP] ⚠  building_detect.onnx not found — RAMP fallback skipped")
        log("[RAMP]    Copy the model to C:/Temp/building_detect.onnx to enable")
        return gpd.GeoDataFrame()

    try:
        import numpy as np
        import onnxruntime as ort
        from PIL import Image  # noqa: F401 — guard import
        from scipy import ndimage
        from shapely.geometry import Point
    except ImportError as exc:
        log(f"[RAMP] ⚠  Missing package ({exc}) — RAMP fallback skipped")
        return gpd.GeoDataFrame()

    log(f"[RAMP] Overture empty — running RAMP on NGI tiles  (model: {ramp_path.name})")
    sess = ort.InferenceSession(str(ramp_path), providers=["CPUExecutionProvider"])
    inp_name = sess.get_inputs()[0].name
    out_name = sess.get_outputs()[0].name

    minx, miny, maxx, maxy = bbox

    # Tile grid (zoom 18) — ty increases southward, so NW corner has smallest ty
    tx0, ty0 = _latlon_to_tile(maxy, minx, RAMP_ZOOM)   # NW
    tx1, ty1 = _latlon_to_tile(miny, maxx, RAMP_ZOOM)   # SE
    tiles = [(tx, ty) for tx in range(tx0, tx1 + 1) for ty in range(ty0, ty1 + 1)]

    log(f"[RAMP] {len(tiles)} tiles to scan")
    if len(tiles) > 2000:
        log(f"[RAMP] ⚠  Very large AOI ({len(tiles)} tiles) — this may take 30+ min")

    raw_centroids: list[dict] = []
    ok = fail = 0

    for i, (tx, ty) in enumerate(tiles):
        tile_img = _fetch_ngi_tile(tx, ty)
        if tile_img is None:
            fail += 1
            continue
        ok += 1

        lat_n, lon_w = _tile_nw_latlon(tx, ty, RAMP_ZOOM)
        lat_s, lon_e = _tile_nw_latlon(tx + 1, ty + 1, RAMP_ZOOM)
        tw, th = tile_img.size

        crop = tile_img.resize((RAMP_MODEL_PX, RAMP_MODEL_PX))
        arr = np.array(crop, dtype=np.float32)[np.newaxis] / 255.0
        mask = sess.run([out_name], {inp_name: arr})[0][0, :, :, 0]

        binary = (mask >= RAMP_MASK_THRESH).astype(np.uint8)
        labeled, n_blobs = ndimage.label(binary)

        for blob_id in range(1, n_blobs + 1):
            ys, xs = np.where(labeled == blob_id)
            if len(ys) < RAMP_MIN_BLOB_PX:
                continue
            # Scale blob centre back to geographic coords
            px_c = float(xs.mean()) / RAMP_MODEL_PX * tw
            py_c = float(ys.mean()) / RAMP_MODEL_PX * th
            lon = lon_w + (px_c / tw) * (lon_e - lon_w)
            lat = lat_n + (py_c / th) * (lat_s - lat_n)
            if aoi_geom is not None and not aoi_geom.intersects(Point(lon, lat)):
                continue
            raw_centroids.append(
                {"lon": round(lon, 7), "lat": round(lat, 7), "blob_px": len(ys)}
            )

        if (i + 1) % max(1, len(tiles) // 10) == 0 or i == len(tiles) - 1:
            log(f"[RAMP] {i + 1}/{len(tiles)} tiles  centroids_so_far={len(raw_centroids)}")

    log(f"[RAMP] Tiles: {ok} OK / {fail} failed")

    # Deduplicate artefacts at tile boundaries
    centroids = _dedup_centroids(raw_centroids)
    log(f"[RAMP] {len(raw_centroids)} raw → {len(centroids)} after dedup ({RAMP_DEDUP_M}m)")

    if not centroids:
        return gpd.GeoDataFrame()

    gdf = gpd.GeoDataFrame(
        {
            "geometry":   [Point(c["lon"], c["lat"]) for c in centroids],
            "area_m2":    [float(c["blob_px"]) * 1.5 for c in centroids],  # rough estimate
            "is_primary": [1] * len(centroids),
            "building_t": ["SDU"] * len(centroids),
            "source":     ["RAMP"] * len(centroids),
        },
        crs=4326,
    )
    log(f"[RAMP] → {len(gdf)} centroids")
    return gdf


def _write_empty_buildings_and_ramp(bbox, aoi_geom):
    """Write empty buildings file; write RAMP centroids if model is available."""
    BUILDINGS_OUT.write_text('{"type":"FeatureCollection","features":[]}', encoding="utf-8")
    ramp_gdf = run_ramp_full_aoi(bbox, aoi_geom)
    if len(ramp_gdf) > 0:
        ramp_gdf.to_file(str(RAMP_CENTROIDS_OUT), driver="GeoJSON")
        log(f"[RAMP] centroids → {RAMP_CENTROIDS_OUT}  ({len(ramp_gdf)} points)")
    else:
        log("[Buildings] No buildings from Overture or RAMP — demand points must be placed manually")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    with open(CFG_FILE) as f:
        cfg = json.load(f)
    bbox = cfg["bbox_4326"]  # [minx, miny, maxx, maxy]
    fetch_erven = cfg.get("fetch_erven", True)
    fetch_buildings = cfg.get("fetch_buildings", True)
    aoi_geom = _load_aoi_geom(cfg.get("aoi_geojson"))

    if aoi_geom is not None:
        log("[AOI] polygon loaded — will clip results to AOI boundary")
    else:
        log("[AOI] no polygon provided — keeping full bbox results")

    if not fetch_erven:
        log("[CSG] Erven already loaded — skipping fetch")
    if not fetch_buildings:
        log("[Overture] Buildings already loaded — skipping fetch")
        if not fetch_erven:
            return

    # Run CSG + Overture in parallel to cut total time
    import concurrent.futures
    erven_future = bld_future = None
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
        if fetch_erven:
            erven_future = ex.submit(fetch_csg_erven, bbox)
        if fetch_buildings:
            bld_future = ex.submit(fetch_overture_buildings, bbox)
        erven_feats = erven_future.result() if erven_future else []
        bld_gdf = bld_future.result() if bld_future else None

    # Clip erven to AOI polygon before writing
    if fetch_erven:
        if aoi_geom is not None and erven_feats:
            erven_gdf_raw = gpd.GeoDataFrame.from_features(erven_feats, crs=4326)
            erven_gdf_raw = _clip_gdf_to_aoi(erven_gdf_raw, aoi_geom)
            erven_feats = list(json.loads(erven_gdf_raw.to_json())["features"])
        erven_fc = {"type": "FeatureCollection", "features": erven_feats}
        ERVEN_OUT.write_text(json.dumps(erven_fc), encoding="utf-8")
        log(f"[out] erven → {ERVEN_OUT}")

    if not fetch_buildings:
        return

    erven_gdf = gpd.GeoDataFrame.from_features(erven_feats, crs=4326) if erven_feats else None

    if bld_gdf is None or len(bld_gdf) == 0:
        log("[Overture] No buildings — trying RAMP fallback")
        _write_empty_buildings_and_ramp(bbox, aoi_geom)
        return

    # Clip buildings to AOI before further processing
    if aoi_geom is not None:
        bld_gdf = _clip_gdf_to_aoi(bld_gdf, aoi_geom)
        if len(bld_gdf) == 0:
            log("[Overture] No buildings remain after AOI clip — trying RAMP fallback")
            _write_empty_buildings_and_ramp(bbox, aoi_geom)
            return

    # Assign is_primary (one per erven)
    bld_gdf = assign_primary(bld_gdf, erven_gdf)

    # Pick only the geometry + fields we need for the Buildings layer
    keep = gpd.GeoDataFrame(geometry=bld_gdf.geometry, crs=bld_gdf.crs)
    keep["id"] = [str(i + 1) for i in range(len(bld_gdf))]
    keep["Name"] = ""
    keep["Discriptio"] = ""
    # Classify building_t from Overture 'class' if available, else SDU
    if "class" in bld_gdf.columns:
        def _btype(cls):
            cls = str(cls or "").lower()
            if "apartment" in cls or "residential" in cls:
                return "SDU"
            if "industrial" in cls or "commercial" in cls:
                return "MDU"
            return "SDU"
        keep["building_t"] = bld_gdf["class"].apply(_btype)
    else:
        keep["building_t"] = "SDU"
    keep["area_m2"] = (bld_gdf["area_m2"] if "area_m2" in bld_gdf.columns
                       else bld_gdf.geometry.to_crs(32735).area.round(2))
    keep["is_primary"] = bld_gdf["is_primary"].astype(int)

    keep.to_file(BUILDINGS_OUT, driver="GeoJSON")
    log(f"[out] buildings → {BUILDINGS_OUT}  ({len(keep)} features)")


if __name__ == "__main__":
    main()
