# claude:intent READ-ONLY on data - user asked (JJ 2026-11-02, GO 2026-11-03): "a permanent fix ... make sure it
#   doesn't influence anything else in QGIS" - plan: Velocity Plans/Snap index guard - plan.html. Clears QGIS's
#   cached snapping index only; never edits features, files, settings or the undo stack.
# claude:boq-impact none - no feature or attribute is created, changed or deleted
"""Snap index guard: keep QGIS's snapping index in step with its layers.

Proven on Deneysville, 2026-11-02: QGIS's snapping index (one QgsPointLocator per layer, owned by each canvas's
QgsSnappingUtils) kept OLD feature ids after features were deleted from a SHAPEFILE, because OGR renumbers the
ids (0..n-1 again). A click then snaps to the right spot, but QGIS's Add Line / Vertex tools read the exact
coordinates of "feature <old id>" from the layer - now a different feature, often far away (a drop vertex landed
on a pole 1.37 km off). Reopening the project clears it. QGIS bug #53040 (closed, unfixed).

Measured headless (research/snap_index_guard): a delete + save through QGIS's own edit buffer keeps the index
right; a delete or add written STRAIGHT to the data provider (dataProvider().deleteFeatures / addFeatures - what
many tools and scripts do) leaves it stale (300 of 300 wrong), and fires no Qt signal at all.

So the guard does two cheap things and nothing else:
  1. a save that removed or added features (committedFeaturesRemoved / committedFeaturesAdded) rebuilds the
     snapping index once, after the save;
  2. when the map redraws or the mouse moves (at most every 0.25 s) it compares, per layer, the number of
     features in the built snapping index with the layer's feature count - two stored numbers, microseconds.
     A difference means the index is stale: rebuild it. A difference that survives a rebuild (a layer whose
     count QGIS reports oddly) is remembered and never rebuilt again until the count changes - no loops.
"Rebuild" = QgsSnappingUtils.clearAllLocators(); QGIS builds the index again on the next snap. Several triggers
together give ONE rebuild. Data, files, snapping settings and undo are never touched. Off: VF_NO_SNAP_GUARD=1.
"""
import os
import time

from qgis.core import QgsMessageLog, QgsProject, QgsVectorLayer, Qgis
from qgis.PyQt import sip
from qgis.PyQt.QtCore import QEvent, QObject, QTimer

LOG_TAG = "Velocity Nexus"
SIGNALS = ("committedFeaturesRemoved", "committedFeaturesAdded")
CHECK_EVERY_S = 0.25


def _alive(obj):
    return obj is not None and not sip.isdeleted(obj)


class _MoveFilter(QObject):
    """Viewport event filter: a mouse move asks for a (throttled) check. Never eats the event."""

    def __init__(self, guard, parent):
        super().__init__(parent)
        self._guard = guard

    def eventFilter(self, obj, event):
        try:
            if event.type() == QEvent.Type.MouseMove:
                self._guard.check(throttle=True)
        except Exception:
            pass
        return False


class SnapIndexGuard:
    """canvases: a callable returning the map canvases whose snapping index to keep right."""

    def __init__(self, canvases, project=None):
        self._canvases = canvases
        self._project = project or QgsProject.instance()
        self._wired = {}           # layer id -> (layer, [(signal name, slot)])
        self._hooked = []          # [(canvas, move filter)]
        self._settled = {}         # layer id -> layer count at which a rebuild could not clear the difference
        self._pending = False
        self._on = False
        self._last = 0.0
        self.stats = {"saves": 0, "checks": 0, "stale": 0, "rebuilds": 0, "errors": 0}

    # on / off -----------------------------------------------------------------
    def start(self):
        if self._on:
            return
        self._on = True
        self._project.layersAdded.connect(self._on_layers_added)
        for lyr in list(self._project.mapLayers().values()):
            self._wire(lyr)
        for cv in list(self._canvases() or []):
            self._hook(cv)

    def stop(self):
        if not self._on:
            return
        self._on = False
        self._pending = False
        if _alive(self._project):
            try:
                self._project.layersAdded.disconnect(self._on_layers_added)
            except (TypeError, RuntimeError):
                pass
        for lid in list(self._wired):
            self._unwire(lid)
        for cv, flt in self._hooked:
            if _alive(cv):
                try:
                    cv.renderStarting.disconnect(self._on_render)
                except (TypeError, RuntimeError):
                    pass
                vp = cv.viewport()
                if _alive(vp) and _alive(flt):
                    vp.removeEventFilter(flt)
            if _alive(flt):
                flt.deleteLater()
        self._hooked = []

    def connected(self):
        """Signal connections + canvas hooks held (tests and live checks)."""
        return sum(len(slots) for _lyr, slots in self._wired.values()) + 2 * len(self._hooked)

    # canvases -------------------------------------------------------------------
    def _hook(self, cv):
        if not _alive(cv) or any(c is cv for c, _f in self._hooked):
            return
        flt = _MoveFilter(self, cv)
        cv.viewport().installEventFilter(flt)
        cv.renderStarting.connect(self._on_render)
        self._hooked.append((cv, flt))

    def _on_render(self):
        self.check(throttle=True)

    # layers ---------------------------------------------------------------------
    def _on_layers_added(self, layers):
        for lyr in layers:
            self._wire(lyr)

    def _wire(self, lyr):
        if not isinstance(lyr, QgsVectorLayer) or not _alive(lyr):
            return
        lid = lyr.id()
        if lid in self._wired:
            return
        slots = []
        for name in SIGNALS:
            getattr(lyr, name).connect(self._saved)
            slots.append((name, self._saved))
        gone = self._gone_slot(lid)
        lyr.willBeDeleted.connect(gone)
        slots.append(("willBeDeleted", gone))
        self._wired[lid] = (lyr, slots)

    def _gone_slot(self, lid):
        return lambda _l=lid: self._unwire(_l)

    def _unwire(self, lid):
        lyr, slots = self._wired.pop(lid, (None, []))
        self._settled.pop(lid, None)
        if not _alive(lyr):
            return
        for name, slot in slots:
            try:
                getattr(lyr, name).disconnect(slot)
            except (TypeError, RuntimeError):
                pass

    # the fix ------------------------------------------------------------------
    def _saved(self, *args):
        """A save removed or added features: the ids may have been renumbered. Rebuild once, after the save."""
        self.stats["saves"] += 1
        self._ask_rebuild()

    def check(self, throttle=False):
        """Rebuild when a built snapping index holds a different number of features than its layer."""
        if not self._on:
            return False
        now = time.monotonic()
        if throttle and now - self._last < CHECK_EVERY_S:
            return False
        self._last = now
        self.stats["checks"] += 1
        stale = False
        try:
            for cv in list(self._canvases() or []):
                if not _alive(cv):
                    continue
                self._hook(cv)                     # a map view opened since start
                su = cv.snappingUtils()
                if not _alive(su):
                    continue
                for lyr in cv.layers():
                    if not isinstance(lyr, QgsVectorLayer) or not _alive(lyr):
                        continue
                    loc = su.locatorForLayer(lyr)
                    if loc is None or not loc.hasIndex() or loc.extent() is not None:
                        continue                   # not built yet, or indexed for the view only: nothing to compare
                    n_lyr = lyr.featureCount()
                    if n_lyr < 0:
                        continue
                    lid = lyr.id()
                    if loc.cachedGeometryCount() == n_lyr:
                        self._settled.pop(lid, None)
                        continue
                    if self._settled.get(lid) == n_lyr:
                        continue                   # a rebuild did not clear it: QGIS counts this layer oddly
                    self._settled[lid] = n_lyr
                    stale = True
        except Exception as e:
            self.stats["errors"] += 1
            QgsMessageLog.logMessage("Snap index guard check: %s" % e, LOG_TAG, Qgis.MessageLevel.Warning)
            return False
        if stale:
            self.stats["stale"] += 1
            self._ask_rebuild()
        return stale

    def _ask_rebuild(self):
        if self._pending or not self._on:
            return
        self._pending = True
        QTimer.singleShot(0, self._rebuild)

    def _rebuild(self):
        if not self._pending or not self._on:
            return
        self._pending = False
        try:
            for cv in list(self._canvases() or []):
                if _alive(cv):
                    su = cv.snappingUtils()
                    if _alive(su):
                        su.clearAllLocators()
            self.stats["rebuilds"] += 1
        except Exception as e:
            self.stats["errors"] += 1
            QgsMessageLog.logMessage("Snap index guard: %s" % e, LOG_TAG, Qgis.MessageLevel.Warning)


_GUARD = None


def install(iface):
    """Called from the plugin's initGui. Safe to call twice."""
    global _GUARD
    uninstall()
    if os.environ.get("VF_NO_SNAP_GUARD") == "1":
        return None

    def canvases():
        try:
            return iface.mapCanvases() or [iface.mapCanvas()]
        except Exception:
            return [iface.mapCanvas()]

    guard = SnapIndexGuard(canvases)
    guard.start()
    _GUARD = guard
    return guard


def uninstall():
    global _GUARD
    guard, _GUARD = _GUARD, None
    if guard is not None:
        guard.stop()


def current():
    return _GUARD
