"""kml_export — GeoPackage / project → client-spec KML for Google Earth.

ZERO external dependencies: KML is plain XML, the rest is PyQGIS core (coordinate
transform to WGS84). Ships in the team plugin and runs inside QGIS's bundled Python —
no simplekml / geopandas needed. Read-only: it never edits a source layer.

What makes this "client-spec" (vs the older kmz_export):
  • Per-client symbology baked into KML <Style> blocks — Fibertime (official HLD spec),
    Vuma (apply_vuma_style palette), HeroTel (smart name-keyword fallback until its
    schema lands).
  • Status-based colours for Fibertime poles / ONT / Home Connection — one named style
    per (layer, status) so the legend reads correctly in Google Earth.
  • Folders: category (Boundaries / Cables / Infrastructure) → layer → placemarks.
  • Every placemark gets a CLEAN balloon (curated client fields, HTML table) AND an
    <ExtendedData> block carrying EVERY attribute — nothing is lost, re-import-safe.
  • All geometry reprojected to WGS84 (EPSG:4326).

API:
  build_kml(layers, out_path, client=None, feedback=None) -> dict
  build_kml_from_gpkg(gpkg_path, out_path, client=None, feedback=None) -> dict
  detect_client(layer_names) -> "fibertime" | "vuma" | "herotel"
"""
import os
import re
from xml.sax.saxutils import escape

from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform,
                       QgsProject, QgsGeometry, QgsWkbTypes)

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

# ── KML icon shapes (Google-hosted, colour-tintable) ───────────────────────
_SHAPE_ICON = {
    "circle":   "http://maps.google.com/mapfiles/kml/shapes/placemark_circle.png",
    "triangle": "http://maps.google.com/mapfiles/kml/shapes/triangle.png",
    "square":   "http://maps.google.com/mapfiles/kml/shapes/square.png",
}
_GREY = "808080"


def _kml_colour(rgb, alpha="ff"):
    """RRGGBB (web) -> aabbggrr (KML's byte order)."""
    rgb = (rgb or _GREY).lstrip("#")
    rr, gg, bb = rgb[0:2], rgb[2:4], rgb[4:6]
    return f"{alpha}{bb}{gg}{rr}".lower()


# ── Fibertime status colour tables (official HLD symbology spec) ────────────
# keys are normalised: lower-case, hyphens->spaces, whitespace collapsed.
FT_STATUS = {
    "pole": {
        "": _GREY, "permission not granted": "FF0000",
        "permission granted": "FF99FF",
        "permission granted but not installed": "800080",
        "installed": "FFA500", "cable strung": "00FF00",
    },
    "home": {
        "": _GREY, "no sign up registered": "FFFFFF",
        "connection disqualified": "800080", "declined sign up": "FF0000",
        "faulty ont": "FFA500", "installed": "00FF00",
    },
    "ont": {
        "": _GREY, "not installed": "FFFFFF", "online": "00FF00",
        "device not active": "FF0000", "degraded": "FFA500",
        "link down": "FFFF00", "rogue": "FF0000",
    },
}

# ── Per-client style rules. First keyword match wins. ──────────────────────
# Points:  (keywords, shape, rgb | None, status_table_key | None, scale)
# Lines:   (keywords, rgb, width)
# Polys:   (keywords, fill_rgb | None, fill_alpha_hex, outline_rgb, width)
_FT_POINTS = [
    (("enclosures connectorised", "connectorised"), "circle", "40E0D0", None, "1.0"),
    (("enclosures splice", "splice", "enclosure"),  "circle", "0000FF", None, "1.0"),
    (("fts splitter", "fts"),                       "triangle", "FF00FF", None, "1.2"),
    (("sts splitter", "sts"),                       "triangle", "FFFF00", None, "1.2"),
    (("home connection", "home"),                   "square", None, "home", "1.0"),
    (("ont",),                                      "circle", None, "ont", "0.9"),
    (("pole",),                                     "circle", None, "pole", "1.0"),
]
_FT_LINES = [
    (("spare drop",),                  "29A500", "1.3"),
    (("drop cable", "drop"),           "29A500", "1.8"),
    (("distribution",),                "00FFFF", "2.0"),
    (("secondary",),                   "0000FF", "2.0"),
    (("primary", "feeder", "trunk"),   "0000FF", "2.6"),
    (("span",),                        "7DC8FF", "1.2"),
]
_FT_POLYS = [
    (("pon",),                         "FCE639", "7f", "000000", "1"),
    (("zone",),                        "90EE90", "66", "000000", "1"),
    (("building",),                    "FF9E17", "55", "000000", "1"),
    (("erven", "erf", "stand"),        None,     "00", "111111", "1"),
    (("aoi", "boundary"),              None,     "00", "FF3B30", "2"),
]

# Vuma colours are the AUTHORITATIVE ones from apply_vuma_style (Malmsbury V1.1) —
# every Vuma layer is covered so none falls to the generic default.
_VUMA_POINTS = [
    (("aggregation joint",),            "circle", "00B400", None, "1.3"),
    (("feeder joints", "feeder joint"), "circle", "00FF24", None, "1.4"),
    (("link joints", "link joint"),     "circle", "2323F0", None, "1.3"),
    (("spur joints", "spur joint"),     "circle", "FF1AF3", None, "1.0"),
    (("dome joint",),                   "circle", "FF0000", None, "1.0"),
    (("4 way splitter", "splitter"),    "circle", "FF0000", None, "0.9"),
    (("demand point", "demand"),        "circle", "DE21AF", None, "0.6"),
    (("node",),                         "circle", "FF0000", None, "1.0"),
    (("pole",),                         "circle", "FFF200", None, "0.7"),
]
_VUMA_LINES = [
    (("road crossing underground", "road crossing"), "C8A214", "2.1"),
    (("distribution",),                "D30000", "1.6"),
    (("link cable", "link"),           "2323D5", "1.8"),
    (("spur cable", "spur"),           "F831DE", "1.6"),
    (("feeder",),                      "00FF24", "1.6"),
    (("drops", "drop"),                "30ECDD", "1.2"),
    (("core",),                        "FF00FF", "1.6"),
]
_VUMA_POLYS = [
    (("aggregation polygon", "aggregation"), "FFB223", "3c", "000000", "0.9"),
    (("block",),                             "25AB00", "3c", "000000", "0.9"),
    (("building",),                          "00C8C8", "64", "007878", "0.6"),
    (("erven", "erf"),                       None,     "00", "000000", "0.6"),
    (("aoi", "boundary"),                    None,     "00", "FF3B30", "2"),
]

# ── Generic fallback (HeroTel, or any unmatched layer) ─────────────────────
_GEN_POINTS = [
    (("ont", "home"),            "circle", "FFE100", None, "0.9"),
    (("pole",),                  "circle", "FF8C00", None, "0.9"),
    (("fts",),                   "triangle", "FF2D55", None, "1.1"),
    (("sts",),                   "triangle", "FF2DD4", None, "1.1"),
    (("splitter", "enclosure", "joint", "dome", "node"), "circle", "2DD4FF", None, "0.9"),
    (("demand",),                "circle", "DE21AF", None, "0.6"),
]
_GEN_POINT_DEFAULT = ("circle", "F2F7FF", None, "0.9")
_GEN_LINES = [
    (("drop",),                      "3DFF9A", "1.6"),
    (("distribution",),              "2D7DFF", "2.0"),
    (("secondary",),                 "9A4DFF", "2.0"),
    (("primary", "feeder", "trunk"), "FF4D2D", "2.4"),
    (("span", "cable", "link"),      "7DC8FF", "1.4"),
]
_GEN_LINE_DEFAULT = ("B0B8C4", "1.8")   # neutral grey — no real client line uses it
_GEN_POLYS = [
    (("pon",),                  "2DD4BF", "55", "000000", "1"),
    (("zone",),                 "FFD24D", "55", "000000", "1"),
    (("building",),             "FF9E17", "44", "000000", "1"),
    (("aggregation", "block"),  "00B400", "30", "008000", "1"),
    (("erf", "erven", "stand"), None,     "00", "111111", "1"),
    (("aoi", "boundary"),       None,     "00", "FF3B30", "2"),
]
_GEN_POLY_DEFAULT = ("9AA7B8", "33", "333333", "1")

_SPEC = {
    "fibertime": (_FT_POINTS, _FT_LINES, _FT_POLYS),
    "vuma":      (_VUMA_POINTS, _VUMA_LINES, _VUMA_POLYS),
    "herotel":   (_GEN_POINTS, _GEN_LINES, _GEN_POLYS),
}

# ── Balloon: curated client fields (those that exist + are non-empty) ──────
_BALLOON_PRIORITY = [
    "Label", "label", "label_1", "Name", "name",
    "Pole Type", "pole_type", "Pole Size", "type", "subtyp", "subtype",
    "spec", "dim1", "dim2", "thickness_", "thickness",
    "pon_no", "zone_no", "units", "n_sts", "AG", "Block",
    "Area", "area_m2", "building_t", "status",
    "strtfeat", "endfeat", "cable_size", "capacity", "lat", "lon",
]
_LABEL_MAP = {
    "pon_no": "PON", "zone_no": "Zone", "thickness_": "Thickness",
    "subtyp": "Subtype", "n_sts": "# STS", "area_m2": "Area (m²)",
    "building_t": "Building", "label_1": "Label", "strtfeat": "From",
    "endfeat": "To", "cable_size": "Cable size",
}
# Client-aware curated balloon: per (layer keyword) the exact fields the client
# wants to see, in order, with friendly labels. First keyword match wins; only
# fields that actually exist are shown. Falls back to _BALLOON_PRIORITY if no
# keyword matches. Field names are the EXACT schema strings (FT_LAYER_DEFS /
# VUMA_LAYER_DEFS) so case/spelling line up.
_BALLOON_SPEC = {
    "fibertime": [
        (("enclosures connectorised", "enclosures splice", "enclosure"),
         [("label_1", "Label"), ("type", "Type"), ("subtyp", "Subtype"),
          ("spec_1", "Spec"), ("cblcpty1", "Capacity"), ("pon_no", "PON"),
          ("zone_no", "Zone"), ("status", "Status")]),
        (("fts splitter", "sts splitter", "splitter"),
         [("label", "Label"), ("type", "Type"), ("subtyp", "Subtype"),
          ("spec", "Spec"), ("pon_no", "PON"), ("zone_no", "Zone"),
          ("strtfeat", "Feeds from")]),
        (("pole",),
         [("Label", "Label"), ("Pole Type", "Pole type"), ("dim2", "Thickness"),
          ("status", "Status"), ("pon_no", "PON"), ("zone_no", "Zone"),
          ("lat", "Lat"), ("lon", "Lon")]),
        (("ont", "home connection", "home"),
         [("label", "Label"), ("type", "Type"), ("subtyp", "Subtype"),
          ("spec", "Spec"), ("status", "Status"), ("pon_no", "PON"),
          ("zone_no", "Zone"), ("lat", "Lat"), ("lon", "Lon")]),
        (("spare drop", "drop cable", "drop"),
         [("label", "Label"), ("type", "Type"), ("spec", "Spec"),
          ("dim1", "Cable"), ("cblcpty", "Capacity"), ("tlenght", "Length m"),
          ("strtfeat", "From"), ("endfeat", "To"), ("pon_no", "PON")]),
        (("distribution", "secondary", "primary"),
         [("label", "Label"), ("type", "Type"), ("spec", "Spec"),
          ("dim1", "Cable"), ("dim2", "Fibre"), ("cblcpty", "Capacity"),
          ("tlenght", "Length m"), ("strtfeat", "From"), ("endfeat", "To")]),
        (("span",),
         [("strtfeat", "From"), ("endfeat", "To"), ("span_m", "Span m"),
          ("cable_lay", "Cable"), ("exceeds", "Over limit")]),
        (("pon", "zone"),
         [("label", "Label"), ("pon_no", "PON"), ("zone_no", "Zone"),
          ("units", "Units"), ("n_sts", "# STS"), ("spec", "Spec"),
          ("status", "Status")]),
        (("erven", "erf"),
         [("Label", "Label"), ("Area", "Area"), ("PRCL_KEY", "Parcel"),
          ("LSTATUS", "Land status")]),
        (("building",),
         [("Name", "Name"), ("building_t", "Building"), ("area_m2", "Area m²")]),
        (("aoi", "boundary"),
         [("Name", "Name"), ("Discriptio", "Description")]),
    ],
    "vuma": [
        (("pole",),
         [("Name", "Name"), ("Pole Size", "Pole size"), ("Type", "Type"),
          ("AG", "AG"), ("Block", "Block")]),
        (("feeder joints", "feeder joint"),
         [("Label", "Label"), ("Splitters", "Splitters"), ("Discriptio", "Description")]),
        (("link joints", "link joint"),
         [("Label", "Label"), ("Discriptio", "Description")]),
        (("dome joint", "spur joint", "aggregation joint"),
         [("Name", "Name"), ("Block", "Block"), ("AG", "AG"), ("Descriptio", "Description")]),
        (("4 way splitter", "splitter"),
         [("1-4 Splitt", "Splitter"), ("AG", "AG"), ("Block", "Block")]),
        (("demand point", "demand"),
         [("Name", "Name"), ("Status", "Status"), ("Type", "Type"),
          ("Allowed Pr", "Allowed product"), ("Inst Type", "Install type"),
          ("Zone", "Zone"), ("Connectabl", "Connectable"),
          ("Geo Erf Nu", "Erf no"), ("AG Name", "AG")]),
        (("node",), [("id", "ID")]),
        (("road crossing",),
         [("Lenght", "Length m"), ("up & down", "Up/Down")]),
        (("drops",),
         [("Block", "Block"), ("AG", "AG"), ("Lenght", "Length m")]),
        (("core",),
         [("Name", "Name"), ("Cable Size", "Cable size"), ("Lenght", "Length m")]),
        (("feeder", "link cable", "distribution", "spur cable"),
         [("Name", "Name"), ("Cable Size", "Cable size"), ("Feeder Cab", "Feeder cable"),
          ("Tlenght", "Total length"), ("Slenght", "Span length"),
          ("Discriptio", "Description")]),
        (("aggregation polygon", "block"),
         [("Label.", "Label"), ("Discriptio", "Description")]),
        (("erven", "erf"),
         [("Label", "Label"), ("Area", "Area"), ("PRCL_KEY", "Parcel"),
          ("LSTATUS", "Land status")]),
        (("building",),
         [("Name", "Name"), ("building_t", "Building"), ("area_m2", "Area m²")]),
        (("aoi", "boundary"),
         [("Name", "Name"), ("Discriptio", "Description")]),
    ],
}

# Tier 1: exact match on the NORMALISED field name (see _norm_field). 'id' is NOT
# here — it is applied last, after the contains- and descriptive-fallbacks, so a
# real name field can never lose to a row number. See _name_field.
_NAME_FIELDS_NORM = ("label", "label1", "name", "ponno")
# Tier 3: only consulted when a layer has NO label/name field at all. Without these
# such layers fall through to 'id' and read "1, 2, 3" in Google Earth — e.g.
# Malmesbury Phases has 'Phase Num' ("Phase 1"), Trenching has 'Type',
# 8Way Splitters has 'Descriptio'. Ordered most- to least-descriptive.
_DESC_FIELDS_NORM = ("descriptio", "description", "desc", "phasenum", "phaseno",
                     "phase", "zone", "title", "type", "code", "ref")
_MAX_BALLOON = 10
_MAX_VAL = 120


# Client fingerprints — each list holds ONLY names that are exclusive to that client.
# 'dome joint', 'feeder joint' and 'demand point' are deliberately ABSENT: Vuma and
# HeroTel both use them ("Dome Joint (Distribution Joints)" vs "Dome Joints"), so they
# identify nobody. They used to sit in the Vuma list, which is why Malmesbury — a
# HeroTel project — was classified as Vuma and exported with Vuma symbology.
# Names verified against the v2.5.273 HLD client profiles (real client schemas).
_FINGERPRINTS = {
    "fibertime": ("sts splitter", "fts splitter", "home connection",
                  "pon v1", "zones v1", "drop cable v1", "enclosures"),
    "vuma": ("aggregation polygon", "aggregation joint", "4 way splitter",
             "block polygon", "cable span", "spur joint", "link joint"),
    "herotel": ("8way splitter", "8 way splitter", "dc & bh"),
}


def detect_client(layer_names):
    """Best-effort client from layer-name fingerprints.

    An explicit brand mention wins outright; otherwise the client with the most
    EXCLUSIVE layer-name matches wins. Ties and no-match fall back to fibertime
    (the long-standing default).

    Only ever a fallback — the Export KML dialog's client dropdown overrides it.
    """
    s = " " + " ".join(n.lower() for n in layer_names) + " "
    if "herotel" in s or " hrt" in s or "hrt." in s:
        return "herotel"
    hits = {c: sum(1 for k in keys if k in s) for c, keys in _FINGERPRINTS.items()}
    best = max(hits, key=lambda c: hits[c])
    if hits[best] == 0:
        return "fibertime"
    if sum(1 for c in hits if hits[c] == hits[best]) > 1:   # tie -> old default
        return "fibertime"
    return best


def _norm_status(v):
    s = "" if v is None else str(v)
    s = s.strip().lower().replace("-", " ")
    return re.sub(r"\s+", " ", s)


def _status_colour(table, val):
    if val in table:
        return table[val]
    for k, c in table.items():
        if k and (k in val or val in k):
            return c
    return _GREY


def _slug(s):
    s = re.sub(r"[^a-z0-9]+", "_", (s or "").lower()).strip("_")
    return s or "null"


def _field_ci(layer, target):
    """Actual field name matching target (case-insensitive), else None."""
    t = target.lower()
    for f in layer.fields():
        if f.name().lower() == t:
            return f.name()
    return None


def _rule(rules, name_lc):
    for rule in rules:
        keys = rule[0]
        if any(k in name_lc for k in keys):
            return rule
    return None


def _fmt(v):
    try:
        from qgis.core import NULL
        if v is None or v == NULL:
            return ""
    except Exception:
        if v is None:
            return ""
    if isinstance(v, bool):
        return "Yes" if v else "No"
    if isinstance(v, float):
        # 10 sig-figs, not 6. At 6 a lat/lon attribute rounds to ~5 m on the ground
        # (-33.468242970250756 -> -33.4682) and a DR number renders as scientific
        # notation (1853300.0 -> 1.8533e+06). 10 holds lat/lon to ~0.03 mm and keeps
        # 7-digit IDs literal, while still trimming float noise (1.5 stays "1.5").
        return f"{v:.10g}"
    return str(v)


def _point_style_xml(sid, rgb, shape, scale):
    href = _SHAPE_ICON.get(shape, _SHAPE_ICON["circle"])
    return (f'<Style id="{sid}"><IconStyle><color>{_kml_colour(rgb)}</color>'
            f'<scale>{scale}</scale><Icon><href>{href}</href></Icon></IconStyle>'
            f'<LabelStyle><scale>0.7</scale></LabelStyle></Style>')


def _line_style_xml(sid, rgb, width):
    return (f'<Style id="{sid}"><LineStyle><color>{_kml_colour(rgb)}</color>'
            f'<width>{width}</width></LineStyle></Style>')


def _poly_style_xml(sid, fill_rgb, fill_alpha, outline_rgb, width):
    fill = _kml_colour(fill_rgb, fill_alpha) if fill_rgb else "00000000"
    fillflag = 1 if fill_rgb else 0
    return (f'<Style id="{sid}"><LineStyle><color>{_kml_colour(outline_rgb)}</color>'
            f'<width>{width}</width></LineStyle><PolyStyle><color>{fill}</color>'
            f'<fill>{fillflag}</fill><outline>1</outline></PolyStyle></Style>')


def _coords(pts):
    """list[QgsPointXY] -> KML 'lon,lat,0 ...' (KML is lon,lat order)."""
    return " ".join(f"{p.x():.7f},{p.y():.7f},0" for p in pts)


def _geom_kml(geom, gtype):
    """Already-WGS84 geometry -> KML geometry XML (MultiGeometry if multipart)."""
    parts = []
    if gtype == QgsWkbTypes.GeometryType.PointGeometry:
        pts = geom.asMultiPoint() if geom.isMultipart() else [geom.asPoint()]
        for p in pts:
            parts.append(f'<Point><coordinates>{p.x():.7f},{p.y():.7f},0</coordinates></Point>')
    elif gtype == QgsWkbTypes.GeometryType.LineGeometry:
        lines = geom.asMultiPolyline() if geom.isMultipart() else [geom.asPolyline()]
        for ln in lines:
            if len(ln) >= 2:
                parts.append(f'<LineString><tessellate>1</tessellate>'
                             f'<coordinates>{_coords(ln)}</coordinates></LineString>')
    elif gtype == QgsWkbTypes.GeometryType.PolygonGeometry:
        polys = geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]
        for poly in polys:
            if not poly:
                continue
            rings = [f'<outerBoundaryIs><LinearRing><coordinates>{_coords(poly[0])}'
                     f'</coordinates></LinearRing></outerBoundaryIs>']
            for hole in poly[1:]:
                rings.append(f'<innerBoundaryIs><LinearRing><coordinates>{_coords(hole)}'
                             f'</coordinates></LinearRing></innerBoundaryIs>')
            parts.append(f'<Polygon>{"".join(rings)}</Polygon>')
    if not parts:
        return None
    if len(parts) == 1:
        return parts[0]
    return f'<MultiGeometry>{"".join(parts)}</MultiGeometry>'


def _balloon_html(pairs):
    rows = "".join(
        f'<tr><td style="color:#888;padding:3px 9px;white-space:nowrap">{escape(k)}</td>'
        f'<td style="padding:3px 9px">{escape(v)}</td></tr>' for k, v in pairs)
    html = (f'<table style="font-family:Segoe UI,Arial,sans-serif;font-size:12px;'
            f'border-collapse:collapse">{rows}</table>').replace("]]>", "]]&gt;")
    return f'<![CDATA[{html}]]>'


def _extended_data(field_names, ft):
    rows = []
    for fn in field_names:
        rows.append(f'<Data name="{escape(fn, {chr(34): "&quot;"})}">'
                    f'<value>{escape(_fmt(ft[fn]))}</value></Data>')
    return f'<ExtendedData>{"".join(rows)}</ExtendedData>' if rows else ""


def _balloon_fields(layer, client):
    """Ordered (actual_field_name, display_label) of the fields THIS client wants to
    see for this layer. Uses the client-aware _BALLOON_SPEC; falls back to the generic
    priority list for unmatched layers / unknown clients (e.g. HeroTel)."""
    name_lc = (layer.name() or "").lower()
    for keys, fields in _BALLOON_SPEC.get(client, []):
        if any(k in name_lc for k in keys):
            out = []
            for fld, lbl in fields:
                actual = _field_ci(layer, fld)
                if actual:
                    out.append((actual, lbl))
            if out:
                return out[:_MAX_BALLOON]
            break
    out, seen = [], set()
    for cand in _BALLOON_PRIORITY:
        actual = _field_ci(layer, cand)
        if actual and actual.lower() not in seen:
            seen.add(actual.lower())
            out.append((actual, _LABEL_MAP.get(cand, cand)))
        if len(out) >= _MAX_BALLOON:
            break
    # ultimate fallback: a minimal layer (e.g. only 'id') still gets a balloon.
    if not out:
        for f in layer.fields():
            out.append((f.name(), f.name()))
            if len(out) >= _MAX_BALLOON:
                break
    return out


def _norm_field(s):
    """'Name.' -> 'name', 'Label.' -> 'label', 'PON_NO' -> 'ponno'."""
    return "".join(ch for ch in (s or "").lower() if ch.isalnum())


def _is_identifying(layer, field_name):
    """Does this field give each feature a DIFFERENT value?

    Only ever applied to a GUESSED descriptive field (tier 3), never to an explicit
    name/label — those are trusted, and legitimately repeat (two cable segments can
    share a name). The guard exists because a descriptive field often does NOT
    identify: Malmesbury's '8Way Splitters.Descriptio' is "1:8" for all 534 rows, so
    labelling by it would put the same "1:8" on every splitter — strictly worse than
    the row id it replaced. 'Phases.Phase Num' is 3-distinct-of-3 and passes.
    """
    try:
        idx = layer.fields().indexOf(field_name)
        if idx < 0:
            return False
        n = layer.featureCount()
        if n <= 0:
            return False
        vals = layer.uniqueValues(idx, limit=n + 1)   # provider-backed, capped
        return len(vals) == n
    except Exception:
        return False


def _name_field(layer):
    """The field to use as the Placemark <name>, or None.

    Matched on a NORMALISED name (lowercased, punctuation stripped), not an exact
    string. Real client data has fields like 'Name.' and 'Label.' with a trailing
    dot; an exact match misses those and silently falls through to 'id', which is
    why Malmesbury poles showed "1, 2, 3" in Google Earth instead of "MMB_0001PL",
    and why Pons got no label at all.

    Order matters — an explicit label/name always wins, 'id' is the last resort:
      1. exact (normalised) label / label_1 / name / pon_no
      2. any field CONTAINING name/label  ('Pole Name', 'label_text')
      3. a descriptive field, only if the layer has no name/label at all AND that
         field actually identifies ('Phase Num' -> "Phase 1" beats 'id' -> "1";
         but 'Descriptio' == "1:8" on all 534 splitters does NOT beat the id)
      4. 'id'
    """
    fields = [f.name() for f in layer.fields()]
    pairs = [(f, _norm_field(f)) for f in fields]
    for cand in _NAME_FIELDS_NORM:
        for f, n in pairs:
            if n == cand:
                return f
    for key in ("label", "name"):                 # 'Pole Name', 'label_text', ...
        for f, n in pairs:
            if key in n:
                return f
    for cand in _DESC_FIELDS_NORM:                # better than a bare row number...
        for f, n in pairs:
            if n == cand and _is_identifying(layer, f):   # ...only if it identifies
                return f
    for f, n in pairs:                            # last resort
        if n == "id":
            return f
    return None


def _layer_styles(layer, base_sid, client):
    """Return (assign_style_fn, {sid: style_xml}). assign_style_fn(ft) -> sid."""
    name_lc = (layer.name() or "").lower()
    gtype = layer.geometryType()
    spec_pts, spec_lines, spec_polys = _SPEC.get(client, _SPEC["herotel"])
    styles = {}

    if gtype == QgsWkbTypes.GeometryType.PointGeometry:
        rule = _rule(spec_pts, name_lc)
        if rule is None:
            rule = _rule(_GEN_POINTS, name_lc)
        if rule is None:
            shape, rgb, status_key, scale = _GEN_POINT_DEFAULT[0], _GEN_POINT_DEFAULT[1], None, _GEN_POINT_DEFAULT[3]
        else:
            _, shape, rgb, status_key, scale = rule
        if status_key:
            table = FT_STATUS[status_key]
            sfield = _field_ci(layer, "status")

            def assign(ft, _t=table, _sf=sfield, _sh=shape, _sc=scale):
                val = _norm_status(ft[_sf]) if _sf else ""
                colour = _status_colour(_t, val)
                sid = f"{base_sid}_{_slug(val)}"
                if sid not in styles:
                    styles[sid] = _point_style_xml(sid, colour, _sh, _sc)
                return sid
            return assign, styles
        styles[base_sid] = _point_style_xml(base_sid, rgb, shape, scale)
        return (lambda ft: base_sid), styles

    if gtype == QgsWkbTypes.GeometryType.LineGeometry:
        rule = _rule(spec_lines, name_lc) or _rule(_GEN_LINES, name_lc)
        rgb, width = (rule[1], rule[2]) if rule else _GEN_LINE_DEFAULT
        styles[base_sid] = _line_style_xml(base_sid, rgb, width)
        return (lambda ft: base_sid), styles

    rule = _rule(spec_polys, name_lc) or _rule(_GEN_POLYS, name_lc)
    if rule:
        _, fill_rgb, alpha, outline, width = rule
    else:
        fill_rgb, alpha, outline, width = _GEN_POLY_DEFAULT
    styles[base_sid] = _poly_style_xml(base_sid, fill_rgb, alpha, outline, width)
    return (lambda ft: base_sid), styles


def _category(gtype):
    if gtype == QgsWkbTypes.GeometryType.PolygonGeometry:
        return "Boundaries"
    if gtype == QgsWkbTypes.GeometryType.LineGeometry:
        return "Cables"
    return "Infrastructure"


def build_kml(layers, out_path, client=None, feedback=None, max_features=500000,
              detect_names=None):
    """Write a client-spec KML of the given vector layers. Returns a summary dict.

    layers: list of QgsVectorLayer (from the open project or a GeoPackage).
    client: None -> auto-detect; or 'fibertime' | 'vuma' | 'herotel'.
    feedback: optional .setProgress(0-100)/.pushInfo(str) — best-effort, guarded.
    detect_names: layer names to fingerprint the client from, when it differs from
        what is being exported. Auto-detect keys off layer NAMES, so exporting a
        subset would otherwise fingerprint only that subset and could pick a
        different client — the same project would export with different symbology
        depending on which layers you ticked. The caller passes the whole project's
        names here so detection stays stable. Left None for a GeoPackage export,
        where the exported layers ARE the whole story.
    """
    wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
    layers = [lyr for lyr in layers if lyr is not None]
    valid = []
    for lyr in layers:
        try:
            if lyr.type() != lyr.type().__class__.VectorLayer:
                continue
        except Exception:
            _swallowed_note()
        if lyr.geometryType() in (QgsWkbTypes.GeometryType.PointGeometry,
                                  QgsWkbTypes.GeometryType.LineGeometry,
                                  QgsWkbTypes.GeometryType.PolygonGeometry):
            valid.append(lyr)

    if client is None:
        client = detect_client(detect_names or [lyr.name() for lyr in valid])
    if client not in _SPEC:
        client = "herotel"

    all_styles = {}
    buckets = {"Boundaries": [], "Cables": [], "Infrastructure": []}
    total_feats = 0

    for li, layer in enumerate(valid):
        gtype = layer.geometryType()
        base_sid = f"L{li}"
        assign_style, styles = _layer_styles(layer, base_sid, client)
        nf = _name_field(layer)
        bfields = _balloon_fields(layer, client)
        all_field_names = [f.name() for f in layer.fields()]
        xform = QgsCoordinateTransform(layer.crs(), wgs84, QgsProject.instance())

        marks, n = [], 0
        for ft in layer.getFeatures():
            if total_feats + n >= max_features:
                break
            g = ft.geometry()
            if not g or g.isEmpty():
                continue
            gg = QgsGeometry(g)
            try:
                if gg.transform(xform) != 0:
                    continue
            except Exception:
                _swallowed_note(); continue
            geom_xml = _geom_kml(gg, gtype)
            if not geom_xml:
                continue
            sid = assign_style(ft)
            label = ft[nf] if nf else None
            name_xml = (f"<name>{escape(str(label))}</name>"
                        if label not in (None, "") else "")
            pairs = []
            for actual, disp in bfields:
                val = _fmt(ft[actual])
                if val != "":
                    pairs.append((disp, val[:_MAX_VAL]))
            desc = f"<description>{_balloon_html(pairs)}</description>" if pairs else ""
            extd = _extended_data(all_field_names, ft)
            marks.append(f'<Placemark>{name_xml}<styleUrl>#{sid}</styleUrl>'
                         f'{desc}{extd}{geom_xml}</Placemark>')
            n += 1

        all_styles.update(styles)
        buckets[_category(gtype)].append(
            f'<Folder><name>{escape(layer.name())} ({n})</name>'
            f'<open>0</open>{"".join(marks)}</Folder>')
        total_feats += n
        if feedback is not None:
            try:
                feedback.setProgress(int((li + 1) / max(len(valid), 1) * 100))
                feedback.pushInfo(f"{layer.name()}: {n} features")
            except Exception:
                _swallowed_note()

    folder_xml = []
    for cat in ("Boundaries", "Cables", "Infrastructure"):
        items = buckets[cat]
        if items:
            folder_xml.append(f'<Folder><name>{escape(cat)}</name><open>1</open>'
                              f'{"".join(items)}</Folder>')

    docname = os.path.splitext(os.path.basename(out_path))[0] or "network"
    doc = (f'<?xml version="1.0" encoding="UTF-8"?>'
           f'<kml xmlns="http://www.opengis.net/kml/2.2"><Document>'
           f'<name>{escape(docname)}</name>'
           f'<description>{escape("Velocity Nexus export - client: " + client)}</description>'
           f'{"".join(all_styles.values())}{"".join(folder_xml)}</Document></kml>')

    if not out_path.lower().endswith(".kml"):
        out_path += ".kml"
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write(doc)
    return {"layers": len(valid), "features": total_feats,
            "client": client, "path": out_path}


def _gpkg_layers(gpkg_path):
    """Load every spatial vector sublayer from a GeoPackage as QgsVectorLayer."""
    from qgis.core import QgsVectorLayer, QgsProviderRegistry
    out = []
    try:
        for d in QgsProviderRegistry.instance().querySublayers(gpkg_path):
            vl = QgsVectorLayer(d.uri(), d.name(), "ogr")
            if vl.isValid() and vl.isSpatial():
                out.append(vl)
    except Exception:
        pass
    if out:
        return out
    probe = QgsVectorLayer(gpkg_path, "probe", "ogr")
    if probe.isValid():
        try:
            for s in probe.dataProvider().subLayers():
                parts = s.split("!!::!!")
                nm = parts[1] if len(parts) > 1 else None
                if nm:
                    vl = QgsVectorLayer(f"{gpkg_path}|layername={nm}", nm, "ogr")
                    if vl.isValid() and vl.isSpatial():
                        out.append(vl)
        except Exception:
            pass
    return out


def build_kml_from_gpkg(gpkg_path, out_path, client=None, feedback=None):
    """Convenience: read all layers from a GeoPackage and export to KML."""
    layers = _gpkg_layers(gpkg_path)
    if not layers:
        raise RuntimeError(f"No spatial vector layers found in {gpkg_path}")
    return build_kml(layers, out_path, client=client, feedback=feedback)
