"""Offline building-anchored erven proof (runs in .qgis-venv, NEVER in QGIS).

Reads C:/Temp/erven_test.json, generates erven from the SAM buildings, and
scores them GEOMETRICALLY (mean IoU vs the real erven) — not just count/area,
which previously hid a messy result. Writes the best set to erven_gen.json.
"""
import json
from statistics import median
from shapely import wkt
from shapely.ops import unary_union
from shapely.geometry import Point
from shapely.strtree import STRtree
import erven_obb as e

d = json.load(open('C:/Temp/erven_test.json'))
buildings = [wkt.loads(w) for w in d['buildings_wkt']]
pts = [tuple(p) for p in d['building_pts']]
real = [wkt.loads(w) for w in d['real_erven_wkt']]
print(f'input: {len(buildings)} buildings, {len(real)} real erven')


def norm_angle(a):
    """Rectangle orientation is mod 180 → normalize to [-90, 90)."""
    return ((a + 90.0) % 180.0) - 90.0


def block_angle(footprints):
    """Robust street orientation = median of the buildings' own box angles."""
    angs = [norm_angle(e.obb_angle(f)) for f in footprints if f.area > 0]
    return median(angs) if angs else 0.0


def derive_blocks(road_gap, min_buildings=3):
    merged = unary_union([p.buffer(road_gap) for p in buildings])
    comps = [merged] if merged.geom_type == 'Polygon' else list(merged.geoms)
    return [c for c in comps
            if sum(1 for pt in pts if c.contains(Point(pt))) >= min_buildings]


def gen(road_gap, group_radius=8.0):
    blocks = derive_blocks(road_gap)
    erven = []
    for blk in blocks:
        idx = [i for i, pt in enumerate(pts) if blk.buffer(1).contains(Point(pt))]
        if not idx:
            continue
        seeds = [pts[i] for i in idx]
        ang = block_angle([buildings[i] for i in idx])      # street orientation
        erven += e.subdivide_grid_by_buildings(
            blk.minimum_rotated_rectangle, seeds, depth_d=22.0,
            min_w=10, max_w=18, group_radius=group_radius, angle=ang)
    return erven, len(blocks)


def score(gen_erven):
    """Mean best-IoU of each REAL erf vs the generated set + matched rate."""
    if not gen_erven:
        return 0.0, 0.0
    tree = STRtree(gen_erven)
    ious = []
    for r in real:
        best = 0.0
        for j in tree.query(r):
            g = gen_erven[j]
            inter = r.intersection(g).area
            if inter > 0:
                best = max(best, inter / (r.area + g.area - inter))
        ious.append(best)
    matched = sum(1 for v in ious if v >= 0.5) / len(ious)
    return sum(ious) / len(ious), matched


best = None
for rg in (2.0, 3.0, 4.0):
    erven, nblk = gen(rg)
    miou, matched = score(erven)
    print(f'  road_gap {rg:.0f}m -> {nblk} blocks, {len(erven)} erven | '
          f'mean IoU {miou:.2f}, matched(>0.5) {matched*100:.0f}% (real {len(real)})')
    if best is None or miou > best[0]:
        best = (miou, rg, erven)

miou, rg, erven = best
print(f'BEST road_gap {rg:.0f}m: mean IoU {miou:.2f}, {len(erven)} erven')
json.dump([s.wkt for s in erven], open('C:/Temp/erven_gen.json', 'w'))
