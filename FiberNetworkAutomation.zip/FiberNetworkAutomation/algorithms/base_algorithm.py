# Base Algorithm Class for Fiber Network Automation

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterEnum,
    QgsExpression,
    QgsExpressionContext,
    QgsExpressionContextUtils
)

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass


class BaseFiberAlgorithm(QgsProcessingAlgorithm):
    """Base class for fiber network labeling algorithms"""

    INPUT = 'INPUT'
    PROJECT = 'PROJECT'

    def createInstance(self):
        return self.__class__()

    def group(self):
        return 'Fiber Network Labeling'

    def groupId(self):
        return 'fibernetworklabeling'

    def calculate_field(self, layer, field_name, expression, feedback=None):
        """
        Calculate field values using expression

        Args:
            layer: Vector layer
            field_name: Name of field to update
            expression: QGIS expression string
            feedback: Processing feedback object

        Returns:
            bool: Success status
        """
        try:
            field_idx = layer.fields().indexOf(field_name)
            if field_idx == -1:
                if feedback:
                    feedback.pushWarning(f"Field '{field_name}' not found - skipping")
                return False

            expr = QgsExpression(expression)
            if expr.hasParserError():
                if feedback:
                    feedback.reportError(f"Expression error in '{field_name}': {expr.parserErrorString()}")
                return False

            context = QgsExpressionContext()
            context.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))

            total = layer.featureCount()
            attr_map = {}
            for current, feature in enumerate(layer.getFeatures()):
                if feedback and feedback.isCanceled():
                    return False

                context.setFeature(feature)
                value = expr.evaluate(context)

                if expr.hasEvalError():
                    if feedback:
                        feedback.pushWarning(f"Evaluation error for feature {feature.id()}: {expr.evalErrorString()}")
                    continue

                attr_map[feature.id()] = {field_idx: value}

                if feedback and total > 0:
                    feedback.setProgress(int(((current + 1) / total) * 100))

            if attr_map:
                layer.dataProvider().changeAttributeValues(attr_map)
            if feedback:
                feedback.pushInfo(f"[OK] {field_name} updated ({len(attr_map)} features)")
            return True

        except Exception as e:
            if feedback:
                feedback.reportError(f"Error updating {field_name}: {e!s}")
            return False

    def bulk_set_static_fields(self, layer, field_values: dict, feedback=None,
                               overwrite_existing: bool = False):
        """
        Write static values to features for each named field.

        Per `feedback_merge_not_override_pattern.md`: by default this NEVER
        overwrites a non-NULL existing value. Pass `overwrite_existing=True`
        only if the field is owned by this algorithm and you intend to refresh.

        Args:
            layer:              Vector layer (must not be in an active edit session)
            field_values:       {field_name: value, ...}
            feedback:           Optional processing feedback
            overwrite_existing: If False (default), skip per-field write where
                                current value is already non-NULL/non-empty.
        """
        name_to_idx = {}
        for fname, val in field_values.items():
            idx = layer.fields().indexOf(fname)
            if idx == -1:
                if feedback:
                    feedback.pushWarning(f"Field '{fname}' not found — skipping")
                continue
            name_to_idx[fname] = (idx, val)

        if not name_to_idx:
            return

        def _is_blank(v):
            if v is None: return True
            try:
                from qgis.core import NULL
                if v == NULL: return True
            except Exception:
                _swallowed_note()
            if isinstance(v, str) and v.strip() in ('', 'NULL', 'null', 'None'):
                return True
            return False

        attr_map = {}
        skipped = 0
        for feat in layer.getFeatures():
            row = {}
            for fname, (idx, val) in name_to_idx.items():
                if not overwrite_existing:
                    cur = feat[fname]
                    if not _is_blank(cur):
                        # already populated — preserve manual / prior value
                        continue
                row[idx] = val
            if row:
                attr_map[feat.id()] = row
            else:
                skipped += 1

        if attr_map:
            layer.dataProvider().changeAttributeValues(attr_map)
        if feedback:
            mode = "overwrite" if overwrite_existing else "fill-null-only"
            feedback.pushInfo(
                f"[OK] static fields ({mode}) — wrote {len(attr_map)}, "
                f"preserved {skipped}: {list(field_values.keys())}"
            )

    def add_common_parameters(self):
        """Add common input parameters"""
        # Project selection
        self.addParameter(
            QgsProcessingParameterEnum(
                self.PROJECT,
                'Project',
                options=['PRAK (Praktiseer)', 'MALM (Malmesbury)'],
                defaultValue=0
            )
        )

    def get_project_code(self, parameters, context):
        """Get project code from parameters"""
        project_idx = self.parameterAsEnum(parameters, self.PROJECT, context)
        return 'PRAK' if project_idx == 0 else 'MALM'
