# -*- coding: utf-8 -*-
# Background launcher: runs hld_generate.py in a separate QGIS process via a QgsTask,
# so the GUI never blocks. Reads result.json (the contract) and reports ok/error.
import os
import json
import subprocess
from qgis.core import QgsTask

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass


def _cancel_flag():
    # Qt6-safe enum resolution for QgsTask flags
    try:
        return QgsTask.Flags.CanCancel
    except AttributeError:
        pass
    try:
        return QgsTask.Flag.CanCancel
    except AttributeError:
        return QgsTask.CanCancel


class HldGenerateTask(QgsTask):
    """Runs the headless generator; on_done(result_dict, error_str) fires on the GUI thread."""

    def __init__(self, cfg_path, result_path, on_done, timeout=1800):
        super().__init__("Generate HLD PDF", _cancel_flag())
        self.cfg_path = cfg_path
        self.result_path = result_path
        self._on_done = on_done
        self.timeout = timeout
        self.result = None
        self.error = None

    def run(self):
        """Worker thread: launch the subprocess, wait, then read result.json."""
        try:
            here = os.path.dirname(os.path.abspath(__file__))
            script = os.path.join(here, "hld_generate.py")
            from .presets import find_python_qgis
            pyqgis = find_python_qgis()
            if not pyqgis:
                self.error = "python-qgis.bat not found next to the QGIS install"
                return False
            if not os.path.exists(script):
                self.error = f"generator script missing: {script}"
                return False
            env = dict(os.environ)
            env["QT_QPA_PLATFORM"] = "offscreen"
            # Run the .bat through cmd WITHOUT shell=True (security gate forbids it).
            # On Windows a STRING command line + shell=False is passed straight to
            # CreateProcess. The double-quote wrap ""prog" "a" "b"" uses cmd's rule of
            # stripping the outer pair, so spaced paths survive (the plain cmd/list form
            # mangles them). Verified end-to-end.
            cmdline = f'cmd /c ""{pyqgis}" "{script}" "{self.cfg_path}""'
            proc = subprocess.run(cmdline, shell=False, capture_output=True, text=True,
                                  timeout=self.timeout, env=env)
            if self.isCanceled():
                self.error = "cancelled"
                return False
            if os.path.exists(self.result_path):
                with open(self.result_path, encoding="utf-8") as f:
                    self.result = json.load(f)
                return bool(self.result.get("ok"))
            # no result.json => the process died before writing one
            tail = (proc.stderr or proc.stdout or "")[-600:]
            self.error = f"generator wrote no result (exit {proc.returncode}). Tail:\n{tail}"
            return False
        except subprocess.TimeoutExpired:
            self.error = f"timed out after {self.timeout}s (killed)"
            return False
        except Exception as e:
            self.error = str(e)
            return False

    def finished(self, ok):
        # runs on the GUI thread — safe to touch widgets from on_done
        try:
            self._on_done(self.result, self.error)
        except Exception:
            _swallowed_note()
