"""acceptance_scorecard_pdf — render an Acceptance Scorecard dict into a
client-signable PDF certificate.

Standalone: runs OUTSIDE QGIS (reportlab isn't in plain QGIS) — the plugin
dumps the scorecard dict to JSON, then calls this via the .qgis-venv python as
a subprocess (same pattern as the splice plans / hld_report). Cannot freeze the
QGIS UI.

    python acceptance_scorecard_pdf.py <scorecard.json> <out.pdf>

The input JSON is exactly what acceptance_scorecard.build_scorecard() returns.
"""
import json
import os
import sys

ACCENT = "#3B6FE0"   # Velocity blue (matches hld_report.py)

_VERDICT = {
    "ACCEPTED":    ("#1E8E3E", "ACCEPTED"),
    "CONDITIONAL": ("#B26A00", "CONDITIONAL PASS"),
    "REJECTED":    ("#C5221F", "NOT ACCEPTED"),
}
_STATUS = {
    "pass": ("PASS", "#1E8E3E"),
    "warn": ("WARN", "#B26A00"),
    "fail": ("FAIL", "#C5221F"),
    "n/a":  ("N/A",  "#888888"),
}


def build_scorecard_pdf(data, out_path):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.units import mm
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                    TableStyle)

    styles = getSampleStyleSheet()
    h1    = ParagraphStyle('h1', parent=styles['Title'], textColor=colors.HexColor(ACCENT))
    h2    = ParagraphStyle('h2', parent=styles['Heading2'], textColor=colors.HexColor(ACCENT))
    small = ParagraphStyle('small', parent=styles['Normal'], fontSize=8, textColor=colors.grey)
    # verdict + score sit side-by-side in a 26mm band — keep each to ONE line so
    # long verdicts ("CONDITIONAL PASS") never overflow the coloured band.
    vstyle = ParagraphStyle('vstyle', parent=styles['Title'], fontSize=22, leading=26, alignment=0)
    sstyle = ParagraphStyle('sstyle', parent=styles['Title'], fontSize=30, leading=32, alignment=2)

    overall = data.get('overall', 0)
    grade   = data.get('grade', '—')
    verdict = data.get('verdict', 'REJECTED')
    vcolor, vlabel = _VERDICT.get(verdict, ('#888888', verdict))

    story = []

    # ── Header ──
    story += [
        Paragraph('VELOCITY NEXUS', h1),
        Paragraph('HLD Acceptance Certificate', styles['Heading1']),
        Spacer(1, 3 * mm),
        Paragraph(f"<b>Project:</b> {data.get('project', '—')}", styles['Normal']),
        Paragraph(f"<b>Generated:</b> {data.get('date', '—')}", styles['Normal']),
        Spacer(1, 8 * mm),
    ]

    # ── Verdict band + score ──
    band = Table(
        [[Paragraph(f"<font color='white'><b>{vlabel}</b></font>", vstyle),
          Paragraph(f"<font color='white'><b>{overall:g}</b></font>"
                    f"<font color='white' size='13'> / 100 &nbsp; Grade {grade}</font>",
                    sstyle)]],
        colWidths=[95 * mm, 65 * mm], rowHeights=[24 * mm])
    band.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor(vcolor)),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('LEFTPADDING', (0, 0), (-1, -1), 12),
        ('ALIGN', (1, 0), (1, 0), 'RIGHT'),
        ('RIGHTPADDING', (1, 0), (1, 0), 12),
    ]))
    story += [band, Spacer(1, 9 * mm)]

    # ── Dimension scores ──
    story += [Paragraph('Dimension scores', h2)]
    rows = [['Dimension', 'Weight', 'Score', 'Status', 'Detail']]
    style_cmds = [
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(ACCENT)),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.4, colors.HexColor('#CCCCCC')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F2F5F8')]),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
    ]
    for i, d in enumerate(data.get('dimensions') or [], start=1):
        slabel, shex = _STATUS.get(d.get('status', ''), ('—', '#666666'))
        score = '—' if d.get('status') == 'n/a' else f"{d.get('score', 0):g}"
        rows.append([
            d.get('label', d.get('key', '')),
            f"{int(round(d.get('weight', 0) * 100))}%",
            score, slabel, d.get('detail', ''),
        ])
        style_cmds.append(('TEXTCOLOR', (3, i), (3, i), colors.HexColor(shex)))
        style_cmds.append(('FONTNAME', (3, i), (3, i), 'Helvetica-Bold'))
    t = Table(rows, colWidths=[30 * mm, 16 * mm, 16 * mm, 18 * mm, 80 * mm])
    t.setStyle(TableStyle(style_cmds))
    story += [t, Spacer(1, 8 * mm)]

    # ── Findings (issues that must be cleared) ──
    issues = [(d.get('label', ''), iss)
              for d in (data.get('dimensions') or [])
              for iss in (d.get('issues') or [])]
    if issues:
        story += [Paragraph('Findings to clear', h2)]
        for label, iss in issues:
            story += [Paragraph(f"&bull; <b>{label}:</b> {iss}", styles['Normal'])]
        story += [Spacer(1, 8 * mm)]
    else:
        story += [Paragraph('No outstanding findings.', styles['Normal']),
                  Spacer(1, 8 * mm)]

    # ── Sign-off block ──
    story += [Paragraph('Sign-off', h2)]
    sign = Table(
        [['Role', 'Name', 'Signature', 'Date'],
         ['Reviewed by (planning)', '', '', ''],
         ['Accepted by (client)', '', '', '']],
        colWidths=[45 * mm, 45 * mm, 45 * mm, 25 * mm], rowHeights=[8 * mm, 16 * mm, 16 * mm])
    sign.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#F2F5F8')),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.4, colors.HexColor('#CCCCCC')),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
    ]))
    story += [
        sign, Spacer(1, 6 * mm),
        Paragraph('Scores are computed from the live project layers against the '
                  'Phase-2 specification. ACCEPTED requires ≥90/100 and no failed '
                  'dimension. Verify findings before contract sign-off.', small),
    ]

    SimpleDocTemplate(out_path, pagesize=A4,
                      leftMargin=20 * mm, rightMargin=20 * mm,
                      topMargin=18 * mm, bottomMargin=16 * mm).build(story)
    return out_path


if __name__ == '__main__':
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    with open(sys.argv[1], encoding='utf-8') as _f:
        data = json.load(_f)
    out = build_scorecard_pdf(data, sys.argv[2])
    print('Acceptance certificate written:', out)
