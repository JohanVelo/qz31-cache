# -*- coding: utf-8 -*-
"""Velocity Measure - core rules (no GUI).

Everything here is read-only maths used by the three Velocity Measure tools:
span limits and colour bands, the segment rule for a capture in progress,
geodesic metres, the group-counter count, and the drop-hub clustering
(both ends of every drop, single-link at 0.5 m in the metric UTM zone).
"""

import math

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsCurve,
    QgsDistanceArea,
    QgsGeometryCollection,
    QgsPointXY,
    QgsProject,
    QgsRectangle,
)

# ── Span limits ──────────────────────────────────────────────────────────
# Same keys and values as Check Spans (fiber_network_plugin.py THRESH table).
CHECK_SPANS_LIMITS = {
    "drop cable v1": 50.0,
    "spare drop cable v1": 50.0,
    "distribution cable v1": 70.0,
    "secondary cable v1": 70.0,
    "primary cable v1": 70.0,
}
DROP_LIMIT_M = 50.0
DEFAULT_LIMIT_M = 70.0

GREEN, AMBER, AMBER_LOW, RED, NEUTRAL = "green", "amber", "amber-low", "red", "neutral"


def limit_for_layer(layer_name, override=None):
    """Span limit in metres for a line layer.

    override: None/'auto' -> rule; a number -> that number.
    Rule: exact Check Spans key first, then a name containing 'drop' -> 50, else 70.
    """
    if override not in (None, "", "auto"):
        return float(override)
    key = (layer_name or "").strip().lower()
    if key in CHECK_SPANS_LIMITS:
        return CHECK_SPANS_LIMITS[key]
    if "drop" in key:
        return DROP_LIMIT_M
    return DEFAULT_LIMIT_M


def is_drop_layer(layer_name):
    return "drop" in (layer_name or "").lower()


def span_colour(metres, limit_m):
    """green < 0.95 L, amber 0.95 L .. L (inclusive), red > L."""
    if metres > limit_m:
        return RED
    if metres >= 0.95 * limit_m:
        return AMBER
    return GREEN


# ── Drop length bands (Drop lengths button) ──────────────────────────────
LEN_ORANGE_M = 40.0
LEN_RED_M = 50.0


def length_band(metres, orange_from=LEN_ORANGE_M, red_above=LEN_RED_M):
    """green < orange_from, orange orange_from..red_above (inclusive), red > red_above."""
    if metres > red_above:
        return RED
    if metres >= orange_from:
        return AMBER
    return GREEN


# ── Group counter bands ──────────────────────────────────────────────────
PON, STS, FTS = "pon", "sts", "fts"
DEFAULT_BANDS = {
    "pon_low": 94, "pon_high": 102, "pon_cap": 128,
    "sts_max": 16, "sts_guide": "12-13",
    "fts_max": 8,
}


def band_classify(mode, count, bands=None):
    """Colour for a group count. PON: <low amber-low, low..high green,
    >high..cap amber, >cap red. STS / FTS: <= max green, > max red."""
    b = dict(DEFAULT_BANDS)
    if bands:
        b.update(bands)
    if mode == PON:
        if count > b["pon_cap"]:
            return RED
        if count > b["pon_high"]:
            return AMBER
        if count < b["pon_low"]:
            return AMBER_LOW
        return GREEN
    if mode == STS:
        return RED if count > b["sts_max"] else GREEN
    if mode == FTS:
        return RED if count > b["fts_max"] else GREEN
    raise ValueError("unknown mode %r" % (mode,))


# ── Geodesic metres ──────────────────────────────────────────────────────
WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")


def make_distance_area(source_crs):
    """QgsDistanceArea forced to the WGS84 ellipsoid whatever the project says,
    so an ellipsoid of NONE can never give degrees or planar metres."""
    da = QgsDistanceArea()
    da.setSourceCrs(source_crs, QgsProject.instance().transformContext())
    da.setEllipsoid("WGS84")
    return da


def segment_and_total(points, is_polygon):
    """The segment rule for a capture in progress.

    points: the vertices of the transient geometry QGIS hands over, in order.
      Line: [v0 .. vk, cursor]          -> segment vk -> cursor
      Polygon: closed ring [v0 .. vk, cursor, v0] -> segment vk -> cursor
    Returns (seg_a, seg_b, open_path) or None when there is no segment yet.
    open_path is the drawn path without the closing edge (its length is the total).
    """
    pts = list(points)
    if is_polygon:
        if len(pts) >= 2 and pts[0] == pts[-1]:
            pts = pts[:-1]
    if len(pts) < 2:
        return None
    return pts[-2], pts[-1], pts


def path_length(da, pts):
    total = 0.0
    for a, b in zip(pts, pts[1:]):
        total += da.measureLine(a, b)
    return total


def bearing_deg(da, a, b):
    """Geodesic bearing a -> b in degrees 0..360 (0 = north)."""
    return math.degrees(da.bearing(a, b)) % 360.0


# ── UTM zone for metre thresholds ────────────────────────────────────────
def utm_crs_for_extent(extent, layer_crs):
    """Metric UTM CRS for the centre of a layer extent (centre taken to 4326 first,
    so projected layers such as EPSG:2052 also work). None for an empty extent."""
    if extent is None or extent.isEmpty() or extent.isNull():
        return None
    c = extent.center()
    if layer_crs.authid() != "EPSG:4326":
        tr = QgsCoordinateTransform(layer_crs, WGS84, QgsProject.instance().transformContext())
        c = tr.transform(c)
    lon, lat = c.x(), c.y()
    zone = int(math.floor((lon + 180.0) / 6.0)) % 60 + 1
    return QgsCoordinateReferenceSystem("EPSG:%d" % ((32700 if lat < 0 else 32600) + zone))


# ── Group counter count ──────────────────────────────────────────────────
try:
    import numpy as _np
except ImportError:  # pragma: no cover - QGIS ships numpy; keep a pure-Python path anyway
    _np = None


class AreaTooLarge(Exception):
    pass


EDGE_TOL_M = 0.001
EDGE_TOL_DEG = 1e-8


class PointSet:
    """The points of one layer as plain coordinates (one per feature: its first vertex).
    Built once on the main thread; rebuilt after the layer changes."""

    def __init__(self, layer):
        from qgis.core import QgsFeatureRequest
        xy = []
        for f in layer.getFeatures(QgsFeatureRequest().setNoAttributes()):
            g = f.geometry()
            if g is None or g.isNull() or g.isEmpty():
                continue
            v = next(iter(g.constGet().vertices()), None)
            if v is not None:
                xy.append((v.x(), v.y()))
        self.geographic = layer.crs().isGeographic()
        self.xy = _np.array(xy, dtype=float).reshape(-1, 2) if _np is not None else xy

    def __len__(self):
        return len(self.xy)


def _ring_of(polygon):
    """Exterior ring of a single-part polygon as an OPEN list of (x, y)."""
    ag = polygon.constGet()
    if ag is None:
        return None
    if ag.partCount() != 1:
        return None
    if hasattr(ag, "exteriorRing"):
        ring = ag.exteriorRing()
    else:
        ring = ag.geometryN(0).exteriorRing()
    if ring is None:
        return None
    pts = [(v.x(), v.y()) for v in ring.vertices()]
    if len(pts) > 1 and pts[0] == pts[-1]:
        pts = pts[:-1]
    return pts if len(pts) >= 3 else None


def count_points_in(polygon, pointset, cap=2000):
    """Points inside a polygon; a point ON an edge counts as inside.

    polygon: QgsGeometry in the point layer CRS. pointset: PointSet of that layer.
    Rule: crossing-number inside, OR within 1 mm of an edge (1e-8 deg for geographic
    layers) - a point built exactly on an edge can land a rounding error outside it.
    Every point counts, including several homes on the same spot.
    Raises AreaTooLarge when more than `cap` points fall in the bounding box.
    """
    if polygon is None or polygon.isEmpty():
        return 0
    ring = _ring_of(polygon)
    if ring is None:
        return 0
    tol = EDGE_TOL_DEG if pointset.geographic else EDGE_TOL_M
    xs = [p[0] for p in ring]
    ys = [p[1] for p in ring]
    x0, x1, y0, y1 = min(xs) - tol, max(xs) + tol, min(ys) - tol, max(ys) + tol
    if _np is not None:
        a = pointset.xy
        if not len(a):
            return 0
        m = (a[:, 0] >= x0) & (a[:, 0] <= x1) & (a[:, 1] >= y0) & (a[:, 1] <= y1)
        cand = a[m]
        if len(cand) > cap:
            raise AreaTooLarge(len(cand))
        if not len(cand):
            return 0
        px, py = cand[:, 0:1], cand[:, 1:2]
        ax, ay = _np.array(xs)[None, :], _np.array(ys)[None, :]
        bx, by = _np.roll(ax, -1, axis=1), _np.roll(ay, -1, axis=1)
        dx, dy = bx - ax, by - ay
        with _np.errstate(divide="ignore", invalid="ignore"):
            xint = ax + (py - ay) * dx / dy
            cross = ((ay > py) != (by > py)) & (px < xint)
            L2 = dx * dx + dy * dy
            t = _np.clip(((px - ax) * dx + (py - ay) * dy) / _np.where(L2 == 0, 1.0, L2), 0.0, 1.0)
        d2 = (px - (ax + t * dx)) ** 2 + (py - (ay + t * dy)) ** 2
        inside = (cross.sum(axis=1) % 2 == 1) | (d2 <= tol * tol).any(axis=1)
        return int(inside.sum())
    cand = [(x, y) for x, y in pointset.xy if x0 <= x <= x1 and y0 <= y <= y1]
    if len(cand) > cap:
        raise AreaTooLarge(len(cand))
    n, m, t2 = 0, len(ring), tol * tol
    for x, y in cand:
        inside = False
        for i in range(m):
            xa, ya = ring[i]
            xb, yb = ring[(i + 1) % m]
            ddx, ddy = xb - xa, yb - ya
            L2 = ddx * ddx + ddy * ddy
            t = max(0.0, min(1.0, ((x - xa) * ddx + (y - ya) * ddy) / L2)) if L2 else 0.0
            if (x - (xa + t * ddx)) ** 2 + (y - (ya + t * ddy)) ** 2 <= t2:
                inside = True
                break
            if (ya > y) != (yb > y) and x < xa + (y - ya) * ddx / ddy:
                inside = not inside
        n += 1 if inside else 0
    return n


# ── Drop hubs ────────────────────────────────────────────────────────────
def drop_end_points(geom):
    """(first, last) QgsPointXY of a single-part drop, else None.

    Null/empty geometry and TRUE multipart (partCount() > 1) are skipped.
    Single-part MultiLineStrings (how shapefiles report drops) are fine.
    Never isMultipart() (true for every shapefile line) and never
    numGeometries() (raises on a plain LineString).
    """
    if geom is None:
        return None
    ag = geom.constGet()          # None for a null geometry
    if ag is None or ag.partCount() != 1:   # empty -> 0 parts, true multipart -> > 1
        return None
    if isinstance(ag, QgsGeometryCollection):
        ag = ag.geometryN(0)
    if isinstance(ag, QgsCurve):
        if ag.nCoordinates() < 2:
            return None
        return QgsPointXY(ag.startPoint()), QgsPointXY(ag.endPoint())
    pts = [QgsPointXY(v) for v in ag.vertices()]
    if len(pts) < 2:
        return None
    return pts[0], pts[-1]


try:
    from scipy.spatial import cKDTree as _KDTree
except ImportError:  # pragma: no cover - QGIS 4.2 on Windows ships scipy; keep a pure path anyway
    _KDTree = None


class HubIndex:
    """Both ends of every drop, clustered single-link at `tol` metres.

    Ends are added in METRIC coordinates (UTM). Each end also carries its
    layer-CRS point, used to place the number. A hub's count is the number of
    DISTINCT drops with an end in it (a drop with both ends in one hub counts once).

    update_drop() re-clusters only the whole connected components touched by the
    old and the new end positions, which gives exactly the same result as a full
    rebuild (single-link components are closed under the tol relation).
    """

    def __init__(self, tol=0.5):
        self.tol = float(tol)
        self._cell = self.tol
        self.ends = {}       # (drop_id, 0|1) -> (x, y, layer_pt)
        self.grid = {}       # (cx, cy) -> set of end keys
        self.comp_of = {}    # end key -> comp id
        self.comps = {}      # comp id -> set of end keys
        self.multi = {}      # comp id -> (layer_pt mean, distinct drop count), comps with >= 2 drops
        self._next = 0
        self._hubs = None    # cached hubs(2)

    # grid -------------------------------------------------------------
    def _cellkey(self, x, y):
        return (int(math.floor(x / self._cell)), int(math.floor(y / self._cell)))

    def _near(self, x, y):
        """End keys within tol of (x, y)."""
        cx, cy = self._cellkey(x, y)
        t2 = self.tol * self.tol
        out = []
        for i in (cx - 1, cx, cx + 1):
            for j in (cy - 1, cy, cy + 1):
                for k in self.grid.get((i, j), ()):
                    ex, ey, _ = self.ends[k]
                    if (ex - x) ** 2 + (ey - y) ** 2 <= t2:
                        out.append(k)
        return out

    def _add_end(self, key, x, y, layer_pt):
        self.ends[key] = (x, y, layer_pt)
        self.grid.setdefault(self._cellkey(x, y), set()).add(key)

    def _remove_end(self, key):
        x, y, _ = self.ends.pop(key)
        cell = self._cellkey(x, y)
        s = self.grid.get(cell)
        if s is not None:
            s.discard(key)
            if not s:
                del self.grid[cell]

    # components -------------------------------------------------------
    def _store(self, members):
        cid = self._next
        self._next += 1
        self.comps[cid] = members
        for k in members:
            self.comp_of[k] = cid
        n = len({k[0] for k in members}) if len(members) > 1 else 1
        if n >= 2:
            sx = sy = 0.0
            for k in members:
                lp = self.ends[k][2]
                sx += lp.x()
                sy += lp.y()
            m = float(len(members))
            self.multi[cid] = (QgsPointXY(sx / m, sy / m), n)

    def _drop_comp(self, cid):
        self.multi.pop(cid, None)
        return self.comps.pop(cid)

    def _cluster(self, keys):
        """Single-link union-find over `keys` (neighbours looked up in the grid,
        restricted to `keys`). Writes new components."""
        keys = set(keys)
        parent = {k: k for k in keys}

        def find(k):
            while parent[k] != k:
                parent[k] = parent[parent[k]]
                k = parent[k]
            return k

        for k in keys:
            x, y, _ = self.ends[k]
            for n in self._near(x, y):
                if n in parent:
                    ra, rb = find(k), find(n)
                    if ra != rb:
                        parent[ra] = rb
        groups = {}
        for k in keys:
            groups.setdefault(find(k), set()).add(k)
        for members in groups.values():
            self._store(members)
        self._hubs = None

    def rebuild(self, drops):
        """Full rebuild. drops: iterable of (drop_id, (x0, y0, lp0), (x1, y1, lp1))."""
        self.ends.clear()
        self.grid.clear()
        self.comp_of.clear()
        self.comps.clear()
        self.multi.clear()
        self._hubs = None
        keys, xy = [], []
        ends, grid, floor, cell = self.ends, self.grid, math.floor, self._cell
        for did, e0, e1 in drops:
            for k, e in (((did, 0), e0), ((did, 1), e1)):
                ends[k] = e
                ck = (int(floor(e[0] / cell)), int(floor(e[1] / cell)))
                s_ = grid.get(ck)
                if s_ is None:
                    grid[ck] = {k}
                else:
                    s_.add(k)
                keys.append(k)
                xy.append((e[0], e[1]))
        if _KDTree is None or _np is None or len(keys) < 2:
            self._cluster(keys)
            return
        # same single-link relation (distance <= tol), found with a KD-tree in C
        parent = list(range(len(keys)))

        def find(i):
            while parent[i] != i:
                parent[i] = parent[parent[i]]
                i = parent[i]
            return i

        for i, j in _KDTree(_np.asarray(xy, dtype=float)).query_pairs(self.tol, output_type="ndarray").tolist():
            ra, rb = find(i), find(j)
            if ra != rb:
                parent[ra] = rb
        groups = {}
        comp_of, comps = self.comp_of, self.comps
        for i, k in enumerate(keys):
            r = find(i)
            g = groups.get(r)
            if g is None:
                groups[r] = {k}
            else:
                g.add(k)
        for members in groups.values():
            if len(members) == 1:          # most ends: a house end on its own
                cid = self._next
                self._next += 1
                comps[cid] = members
                for k in members:
                    comp_of[k] = cid
            else:
                self._store(members)

    def update_drop(self, did, e0=None, e1=None):
        """Drop `did` changed: new ends e0/e1 ((x, y, layer_pt)), or None when the
        drop was deleted or is no longer countable."""
        touched = set()
        for w in (0, 1):
            k = (did, w)
            if k in self.comp_of:
                touched.add(self.comp_of[k])
        if e0 is not None and e1 is not None:
            for e in (e0, e1):
                for n in self._near(e[0], e[1]):
                    touched.add(self.comp_of[n])
        members = set()
        for cid in touched:
            members |= self._drop_comp(cid)
        for k in members:
            del self.comp_of[k]
        for w in (0, 1):
            k = (did, w)
            if k in self.ends:
                self._remove_end(k)
                members.discard(k)
        if e0 is not None and e1 is not None:
            self._add_end((did, 0), *e0)
            self._add_end((did, 1), *e1)
            members.add((did, 0))
            members.add((did, 1))
        if members:
            self._cluster(members)
        self._hubs = None

    # results ----------------------------------------------------------
    def hubs(self, min_drops=2):
        """[(layer_pt, count)] for every hub with >= min_drops distinct drops.
        layer_pt is the mean of the member ends in the layer CRS. Cached until the next change."""
        if min_drops == 2 and self._hubs is not None:
            return self._hubs
        out = [(pt, n) for pt, n in self.multi.values() if n >= min_drops]
        if min_drops == 2:
            self._hubs = out
        return out

    def signature(self, min_drops=2):
        """Order-free description of the clustering, for tests:
        sorted list of sorted drop-id tuples, one per hub with >= min_drops."""
        sig = []
        for cid, (_pt, n) in self.multi.items():
            if n >= min_drops:
                sig.append(tuple(sorted({k[0] for k in self.comps[cid]}, key=repr)))
        return sorted(sig, key=repr)


def rect_around(pt, r):
    return QgsRectangle(pt.x() - r, pt.y() - r, pt.x() + r, pt.y() + r)
