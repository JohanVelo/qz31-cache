#!/usr/bin/env python3
"""SAM detect worker — runs in a Python with torch+sam2 (OUTSIDE QGIS).

Reads every <tiles_dir>/job_*.json written by tiler.py, runs SAM 2.1
box-prompted on each building box (tuned gates from the Mohadin sweep:
NO roof-colour gate, raw mask polygons, area 6-2500 m2), then:

  - boxes WITH an erf tag  -> union per erf, clip to the erf boundary,
    regularize, keep the LARGEST part as THE house (one polygon per stand)
  - boxes WITHOUT an erf   -> watershed split of merged roofs, IoU-NMS,
    regularize, one polygon per building (works with no cadastre at all)

Every output polygon gets a shape class: shack/square/rectangle/L-shape/complex.
Vacant erven are emitted as outlines (has_building=0, shape='vacant').

Progress lines on stdout:  PROG <tile>/<total> roofs=<n>
Final line on stdout:      RESULT {json}

  python worker.py <tiles_dir> <out_geojson> [ckpt_path]

The SAM 2.1 tiny checkpoint (~150 MB, Meta, Apache-2.0, free) is downloaded
automatically next to <ckpt_path> if missing. No API keys, ever.
"""
from __future__ import annotations

import glob
import json
import math
import os
import sys
from collections import defaultdict

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sam_helpers as sw
import roof_classifier as rc
import cleanup as cl

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

CKPT_URL = ("https://dl.fbaipublicfiles.com/segment_anything_2/092824/"
            "sam2.1_hiera_tiny.pt")
SAM_CFG = "configs/sam2.1/sam2.1_hiera_t.yaml"

# tuned gates — Mohadin full-AOI sweep 2026-06-11 (F1 0.973 vs reference)
AREA_MIN_M2 = 6.0
AREA_MAX_M2 = 2500.0
MIN_AREA_PX = 50
SIMPLIFY_M = 0.3
NOERF_NMS_IOU = 0.3
NOERF_CONF_MIN = 0.5

# smallest-mask-covering-footprint selection (the merge-killer): SAM returns 3
# candidate masks per box; argmax(predicted-IoU) systematically prefers the
# largest coherent blob = the MERGED neighbour (the box is the footprint's
# axis-aligned bbox, which overlaps the neighbour's roof). Instead, when the
# job carries the footprint polygon (fp_wkt), pick the SMALLEST candidate that
# still covers >=70% of the footprint (proven in erven_mcp detection.py:631-668).
# Falls back to argmax when fp_wkt is absent or disabled (VF_SAM_SMALLEST_MASK=0).
SMALLEST_MASK = os.environ.get("VF_SAM_SMALLEST_MASK", "1") != "0"
SMALLEST_COVER_MIN = 0.70

# vacant-erf rescue (A1): before calling an erf "vacant" (which downstream means
# NO ONT for a possibly-occupied home), point-prompt SAM at the erf interior and
# keep the result ONLY if it passes the strict building_like + spectral gates.
# Never removes or alters an existing box-prompt detection — it can only ADD
# building-shaped polygons on stands the footprint source missed.
# OPT-IN (default OFF) until the precision knob is tuned against ground truth:
# testing 2026-07-03 showed real recoveries BUT bare-ground/cleared-stand false
# positives in the large "complex" class that the spectral gate can't catch.
# Enable per-run with VF_SAM_RESCUE=1. Default-off so a two-terminal publish
# cannot ship the untuned detector change to the team.
RESCUE_ENABLED = os.environ.get("VF_SAM_RESCUE", "0") == "1"
RESCUE_MIN_M2 = 10.0            # matches erven_mcp gap building_like bar
RESCUE_MAX_M2 = 300.0
RESCUE_SCORE_MIN = 0.55        # SAM predicted-IoU floor for a rescue mask
RESCUE_MAX_ERF_FRAC = 0.85     # a house can't be ~the whole stand (ground grab)
RESCUE_MAX_POINTS = 4          # centroid + up to 3 interior fallbacks per erf
# Rescues are emitted as REVIEW CANDIDATES (flag_for_review=1 + clf_score), not
# auto-confirmed buildings — the appearance classifier is too weak on our GSD to
# hard-filter (real/ground scores overlap), so a human confirms. We still hard-
# drop only clear non-buildings below this recall-biased floor (erven_mcp 0.30).
RESCUE_CLF_FLOOR = float(os.environ.get("VF_ROOF_CLF_THRESH", "0.30"))

# speed/memory — boxes are decoded in batches (one decoder pass per batch
# instead of one per box). Smaller batch on CPU keeps RAM flat on laptops.
BATCH_GPU = 32
BATCH_CPU = 8


def log(m):
    sys.stderr.write(f"[worker] {m}\n")
    sys.stderr.flush()


def progress(msg):
    print(msg, flush=True)


def ensure_checkpoint(path):
    if os.path.isfile(path) and os.path.getsize(path) > 100_000_000:
        return path
    log("checkpoint missing -> downloading SAM2.1 tiny (~150 MB, one-time)")
    progress("PROG download checkpoint")
    import urllib.request
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".part"
    urllib.request.urlretrieve(CKPT_URL, tmp)
    os.replace(tmp, path)
    log(f"checkpoint saved: {path}")
    return path


def geom_iou(a, b):
    try:
        if not a.intersects(b):
            return 0.0
        inter = a.intersection(b).area
        u = a.area + b.area - inter
        return inter / u if u > 0 else 0.0
    except Exception:
        return 0.0


def regularize_parts(rows):
    """rows: list of dicts with 'geometry'. Returns same-length geometries,
    orthogonalized via buildingregulariser; originals if the lib is missing."""
    if not rows:
        return []
    try:
        import geopandas as gpd
        from buildingregulariser import regularize_geodataframe
        gdf = gpd.GeoDataFrame(rows, crs="EPSG:3857")
        reg = regularize_geodataframe(gdf, simplify_tolerance=1.2)
        out = list(reg.geometry)
        if len(out) == len(rows):
            return out
        log("regulariser changed row count — keeping originals")
    except Exception as e:
        log(f"regularize skipped ({type(e).__name__}: {e})")
    return [r["geometry"] for r in rows]


_FP_CACHE = {}


def _fp_geom(b):
    """Parse & cache a box's footprint polygon (EPSG:3857 shapely) from fp_wkt."""
    w = b.get("fp_wkt")
    if not w:
        return None
    key = id(b)
    if key not in _FP_CACHE:
        from shapely.wkt import loads as _wkt
        try:
            g = _wkt(w)
            if not g.is_valid:
                g = g.buffer(0)
            _FP_CACHE[key] = g if (g and not g.is_empty) else None
        except Exception:
            _FP_CACHE[key] = None
    return _FP_CACHE[key]


def _select_mask_idx(masks3, scores3, fp_geom, transform):
    """Pick which of SAM's 3 candidate masks to keep. With a footprint polygon:
    the SMALLEST candidate covering >=70% of it (rejects the merged-neighbour
    blob AND the over-large candidate); else argmax(predicted-IoU)."""
    import numpy as np
    if fp_geom is None or not SMALLEST_MASK or fp_geom.area <= 0:
        return int(np.argmax(scores3))
    cands = []                       # (poly_area, coverage, idx)
    for j in range(masks3.shape[0]):
        mj = sw.refine_mask(masks3[j], True, MIN_AREA_PX)
        if mj.sum() == 0:
            continue
        pj = sw.mask_to_polygon(mj, transform, 0.0)
        if pj is None or pj.is_empty:
            continue
        try:
            cov = pj.intersection(fp_geom).area / fp_geom.area
        except Exception:
            cov = 0.0
        cands.append((pj.area, cov, j))
    if not cands:
        return int(np.argmax(scores3))
    covering = [c for c in cands if c[1] >= SMALLEST_COVER_MIN]
    if covering:
        return min(covering, key=lambda c: c[0])[2]   # smallest area that covers
    return max(cands, key=lambda c: c[1])[2]           # else best coverage


def _erf_prompt_points(poly, n_extra=3):
    """Positive-prompt points inside an erf: centroid first (best single guess
    for a centred roof), then an interior grid for offset roofs (SA stands often
    put the house at the front/back, not the middle). Each point clamped to
    actually lie within the polygon. Returns up to RESCUE_MAX_POINTS points."""
    from shapely.geometry import Point
    pts = []
    c = poly.centroid
    if not c.is_empty and poly.contains(c):
        pts.append((c.x, c.y))
    rp = poly.representative_point()
    if poly.contains(rp) and (rp.x, rp.y) not in pts:
        pts.append((rp.x, rp.y))
    minx, miny, maxx, maxy = poly.bounds
    for i in (1, 2, 3):
        for j in (1, 2, 3):
            if len(pts) >= 1 + n_extra:
                break
            x = minx + (maxx - minx) * i / 4.0
            y = miny + (maxy - miny) * j / 4.0
            if poly.contains(Point(x, y)) and (x, y) not in pts:
                pts.append((x, y))
    return pts[:RESCUE_MAX_POINTS]


def rescue_vacant_erven(predictor, jobs, tiles_dir, erven_geom, by_erf, af):
    """A1: recover buildings on stands the footprint source missed.

    For every erf that got NO box-prompt roof, re-open the tile its centroid
    falls in, point-prompt SAM inside the erf, and — only if the mask clips to a
    strictly building_like polygon — add it to by_erf so the stand is no longer
    reported as vacant. Conservative by construction: it can only turn a false
    'vacant' into a detection, never the reverse. Runs inside the caller's
    torch.inference_mode()/autocast context. Returns (n_rescued, rescued_set)."""
    import numpy as np
    from rasterio.transform import from_bounds

    candidates = [erf for erf in erven_geom if erf not in by_erf]
    if not candidates:
        return 0, set()

    # which tile does each candidate erf centroid fall in? (first job whose
    # 3857 bbox contains it). Group so each tile image is encoded at most once.
    job_by_idx = {}
    for jp in jobs:
        try:
            with open(jp, encoding="utf-8") as f:
                job_by_idx[jp] = json.load(f)
        except Exception:
            _swallowed_note(); continue
    per_tile = defaultdict(list)
    for erf in candidates:
        g = erven_geom[erf]
        if g.is_empty:
            continue
        c = g.centroid
        for jp, job in job_by_idx.items():
            bx = job.get("bbox")
            if not bx:
                continue
            if bx[0] <= c.x <= bx[2] and bx[1] <= c.y <= bx[3]:
                per_tile[jp].append(erf)
                break

    rescued = set()
    rescued_score = {}              # erf -> classifier score (triage aid, may be None)
    n = 0
    clf_thr = RESCUE_CLF_FLOOR
    for jp, erfs in per_tile.items():
        job = job_by_idx[jp]
        try:
            raw = sw.load_image(job["image_path"])
        except Exception:
            _swallowed_note(); continue
        img = sw.clahe_enhance(raw)     # CLAHE for SAM; raw kept for colour test
        h, w = img.shape[:2]
        bx = job["bbox"]
        transform = from_bounds(bx[0], bx[1], bx[2], bx[3], w, h)
        predictor.set_image(img)

        def px(mx, my, _bx=bx, _w=w, _h=h):
            return [(mx - _bx[0]) / (_bx[2] - _bx[0]) * _w,
                    (_bx[3] - my) / (_bx[3] - _bx[1]) * _h]

        for erf in erfs:
            eg = erven_geom[erf]
            erf_area = eg.area * af
            best = None                 # (clipped_poly, area_m2)
            for (ptx, pty) in _erf_prompt_points(eg):
                try:
                    masks, scores, _ = predictor.predict(
                        point_coords=np.array([px(ptx, pty)], dtype=np.float32),
                        point_labels=np.array([1], dtype=np.int32),
                        multimask_output=True)
                except Exception as exc:
                    log(f"rescue erf {erf}: predict failed ({exc})")
                    continue
                s = np.asarray(scores).ravel()
                order = np.argsort(s)[::-1]
                for mi in order:
                    if float(s[mi]) < RESCUE_SCORE_MIN:
                        break           # scores sorted desc — rest are worse
                    mask = sw.refine_mask(masks[mi], True, MIN_AREA_PX)
                    if mask.sum() == 0:
                        continue
                    # colour gate: reject tree-crown / shadow grabs on vacant land
                    if not sw.mask_spectral_ok(raw, mask):
                        continue
                    poly = sw.mask_to_polygon(mask, transform, SIMPLIFY_M)
                    if poly is None or poly.is_empty:
                        continue
                    poly = poly.intersection(eg)
                    if poly.is_empty:
                        continue
                    if poly.geom_type == "MultiPolygon":
                        poly = max(poly.geoms, key=lambda p: p.area)
                    area = poly.area * af
                    # reject a mask that swallows ~the whole stand (bare-ground grab)
                    if erf_area > 0 and area / erf_area > RESCUE_MAX_ERF_FRAC:
                        continue
                    if not sw.building_like(poly, area, RESCUE_MIN_M2,
                                            RESCUE_MAX_M2):
                        continue
                    # APPEARANCE score — trained building/non-building classifier
                    # on the roof patch. Judges by LOOK, not shape, so irregular
                    # ("complex") REAL roofs are kept. It is too weak on our GSD
                    # to hard-filter (real/ground scores overlap), so it is only a
                    # recall-biased floor to drop clear non-buildings; the score
                    # rides along as a triage aid for the review layer. No-op if
                    # the classifier isn't installed (score_patch -> None).
                    cc = poly.centroid
                    _col, _row = px(cc.x, cc.y)
                    r0 = max(int(_row) - 32, 0)
                    c0 = max(int(_col) - 32, 0)
                    patch = raw[r0:r0 + 64, c0:c0 + 64]
                    sc = (rc.score_patch(patch)
                          if patch.shape[0] >= 8 and patch.shape[1] >= 8
                          else None)
                    if sc is not None and sc < clf_thr:
                        continue
                    if best is None or area > best[1]:
                        best = (poly, area, sc)
                if best is not None:
                    break               # centroid/early point already found one
            if best is not None:
                by_erf[erf].append(best[0])
                rescued.add(erf)
                rescued_score[erf] = best[2]
                n += 1
        del img
    return n, rescued, rescued_score


def main():
    if len(sys.argv) < 3:
        log("usage: worker.py <tiles_dir> <out_geojson> [ckpt]")
        return 2
    tiles_dir, out_path = sys.argv[1], sys.argv[2]
    ckpt = sys.argv[3] if len(sys.argv) > 3 else os.path.join(
        os.path.expanduser("~"), ".velocityfibre", "sam2.1_hiera_tiny.pt")

    jobs = sorted((p for p in glob.glob(os.path.join(tiles_dir, "job_*.json"))
                   if os.path.basename(p)[4:-5].isdigit()),
                  key=lambda p: int(os.path.basename(p)[4:-5]))
    if not jobs:
        log("no job files found")
        return 1
    log(f"{len(jobs)} tiles")

    from shapely.wkt import loads as wkt_loads
    from shapely.ops import unary_union
    from shapely.geometry import mapping
    from rasterio.transform import from_bounds

    ensure_checkpoint(ckpt)
    device = sw.resolve_device(os.environ.get("VF_SAM_DEVICE", "auto"))

    # CPU threading: intra-op = all cores, inter-op = 1 (we run a serial
    # loop — oversubscription makes laptops crawl). Env vars must be set
    # BEFORE torch spins up its thread pools.
    ncpu = os.cpu_count() or 4
    for var in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
        os.environ.setdefault(var, str(ncpu))
    import torch
    from sam2.build_sam import build_sam2
    from sam2.sam2_image_predictor import SAM2ImagePredictor
    torch.set_num_threads(ncpu)
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass                            # already initialised — fine
    log(f"loading SAM2.1 tiny on {device}")
    model = build_sam2(SAM_CFG, ckpt, device=device, mode="eval")
    predictor = SAM2ImagePredictor(model)
    batch = BATCH_GPU if str(device).startswith("cuda") else BATCH_CPU

    erven_geom = {}
    erven_prcl = {}
    by_erf = defaultdict(list)          # erf -> [shapely roof polys]
    noerf = []                          # [(geom, score)] outside the cadastre
    lat0 = None
    total_boxes = roofs = 0

    def add_poly(poly, score, erf, af):
        """Gate one polygon candidate into the erf / no-erf accumulators.
        Returns list of (erf, wkt) or (None, wkt, score) rows for resume."""
        nonlocal roofs
        rows = []
        if erf is not None and erf in erven_geom:
            area = poly.area * af
            if area < AREA_MIN_M2 or area > AREA_MAX_M2:
                return rows
            poly = poly.intersection(erven_geom[erf])
            if not poly.is_empty:
                by_erf[erf].append(poly)
                rows.append({"erf": erf, "wkt": poly.wkt})
                roofs += 1
        else:
            if score < NOERF_CONF_MIN:
                return rows
            area = poly.area * af
            if AREA_MIN_M2 <= area <= AREA_MAX_M2:
                noerf.append((poly, score))
                rows.append({"erf": None, "wkt": poly.wkt, "score": score})
                roofs += 1
        return rows

    with torch.inference_mode(), sw.autocast_ctx(device):
        for ti, jp in enumerate(jobs):
            idx = os.path.basename(jp)[4:-5]
            with open(jp, encoding="utf-8") as f:
                job = json.load(f)
            if lat0 is None:
                lat0 = float(job.get("lat_deg", 0.0))
            for e in job.get("erven", []):
                erf = e["erf"]
                if erf not in erven_geom:
                    try:
                        g = wkt_loads(e["wkt"])
                        if not g.is_valid:
                            g = g.buffer(0)
                        erven_geom[erf] = g
                        erven_prcl[erf] = e.get("prcl", "")
                    except Exception:
                        _swallowed_note()
            boxes = job.get("boxes", [])
            total_boxes += len(boxes)
            af = math.cos(math.radians(lat0)) ** 2 if lat0 else 1.0

            # resume: a parts file means this tile is already done.
            # Replay into locals first — commit only if the WHOLE file parses
            # (a bad row otherwise leaves half-applied rows + full recompute).
            parts_path = os.path.join(tiles_dir, f"parts_{idx}.json")
            if os.path.isfile(parts_path):
                try:
                    with open(parts_path, encoding="utf-8") as f:
                        saved = json.load(f)
                    replay_erf, replay_noerf = [], []
                    for r in saved:
                        g = wkt_loads(r["wkt"])
                        if r["erf"] is not None and r["erf"] in erven_geom:
                            replay_erf.append((r["erf"], g))
                        else:
                            replay_noerf.append((g, float(r.get("score", 1.0))))
                    for erf_k, g in replay_erf:
                        by_erf[erf_k].append(g)
                    noerf.extend(replay_noerf)
                    roofs += len(replay_erf) + len(replay_noerf)
                    progress(f"PROG {ti + 1}/{len(jobs)} roofs={roofs}")
                    continue
                except Exception:
                    _swallowed_note()                # corrupt parts file -> recompute

            tile_rows = []
            n_failed = 0
            if boxes:
                img = sw.load_image(job["image_path"])
                img = sw.clahe_enhance(img)
                h, w = img.shape[:2]
                transform = from_bounds(job["bbox"][0], job["bbox"][1],
                                        job["bbox"][2], job["bbox"][3], w, h)
                gsd = (job["bbox"][2] - job["bbox"][0]) / w
                predictor.set_image(img)

                # clamp + drop degenerate boxes, keep source box alongside
                valid = []
                for b in boxes:
                    x0, y0, x1, y1 = b["box"]
                    x0 = max(0.0, min(x0, w - 1)); x1 = max(0.0, min(x1, w - 1))
                    y0 = max(0.0, min(y0, h - 1)); y1 = max(0.0, min(y1, h - 1))
                    if x1 - x0 >= 2 and y1 - y0 >= 2:
                        valid.append(([x0, y0, x1, y1], b))

                # batched decoding: ONE decoder pass per chunk of boxes.
                # multimask stays ON (3 candidates, argmax) — turning it off
                # halves time but shrinks masks enough to shift shape classes
                # (validated 2026-06-12: shack count 3x'd with it off).
                for c0 in range(0, len(valid), batch):
                    chunk = valid[c0:c0 + batch]
                    arr = np.array([v[0] for v in chunk], dtype=np.float32)
                    try:
                        masks, scores, _ = predictor.predict(
                            box=arr, multimask_output=True)
                    except Exception as exc:
                        log(f"batch failed ({exc}) — falling back per-box")
                        masks = scores = None
                    if masks is not None:
                        m = np.asarray(masks)
                        s = np.asarray(scores)
                        if m.ndim == 3:          # single box -> (3, H, W)
                            m = m[None]
                            s = s.reshape(1, -1)
                        best = [_select_mask_idx(m[i], s[i],
                                                 _fp_geom(chunk[i][1]), transform)
                                for i in range(len(chunk))]
                        pairs = [(m[i, best[i]], float(s[i, best[i]]),
                                  chunk[i]) for i in range(len(chunk))]
                    else:
                        pairs = []
                        for bx, b in chunk:
                            try:
                                m1, s1, _ = predictor.predict(
                                    box=np.array(bx), multimask_output=True)
                                bi = _select_mask_idx(
                                    np.asarray(m1), np.asarray(s1).ravel(),
                                    _fp_geom(b), transform)
                                pairs.append((m1[bi], float(np.asarray(s1).ravel()[bi]),
                                              (bx, b)))
                            except Exception as exc2:
                                n_failed += 1
                                log(f"box {b.get('fid')} failed: {exc2}")
                    # masks -> polygons immediately; arrays freed per chunk
                    for mask, score, (bx, b) in pairs:
                        score = float(score)
                        erf = b.get("erf")
                        mask = sw.refine_mask(mask, True, MIN_AREA_PX)
                        if mask.sum() == 0:
                            continue
                        if erf is not None and erf in erven_geom:
                            poly = sw.mask_to_polygon(mask, transform,
                                                      SIMPLIFY_M)
                            if poly is not None:
                                tile_rows += add_poly(poly, score, erf, af)
                        else:
                            for comp in sw.split_touching_roofs(mask, gsd=gsd):
                                comp = sw.refine_mask(comp, True, MIN_AREA_PX)
                                if comp.sum() == 0:
                                    continue
                                poly = sw.mask_to_polygon(comp, transform,
                                                          SIMPLIFY_M)
                                if poly is not None:
                                    tile_rows += add_poly(poly, score, None, af)
                    # release chunk arrays NOW (del alone keeps them alive
                    # through pairs/m/s views until the next rebind)
                    pairs = masks = scores = None
                    m = s = None
                del img

            if n_failed:
                # don't persist a lossy tile — leave no parts file so a
                # resume recomputes it instead of replaying the holes
                log(f"tile {idx}: {n_failed} boxes failed — not cached")
            else:
                try:
                    with open(parts_path, "w", encoding="utf-8") as f:
                        json.dump(tile_rows, f)
                except OSError:
                    pass                # resume is best-effort
            progress(f"PROG {ti + 1}/{len(jobs)} roofs={roofs}")

        # ── A1 vacant-erf rescue (inside the inference context) ──────────────
        rescued_erven = set()
        rescued_score = {}
        if RESCUE_ENABLED and erven_geom:
            _af = math.cos(math.radians(lat0)) ** 2 if lat0 else 1.0
            n_resc, rescued_erven, rescued_score = rescue_vacant_erven(
                predictor, jobs, tiles_dir, erven_geom, by_erf, _af)
            if n_resc:
                log(f"vacant rescue: recovered {n_resc} buildings on "
                    f"footprint-missed stands")
                progress(f"PROG rescue roofs={roofs + n_resc}")

    af = math.cos(math.radians(lat0)) ** 2 if lat0 else 1.0

    # ── per-erf: union, explode, regularize, keep largest part ──────────────
    erf_rows = []
    for erf, geoms in by_erf.items():
        u = unary_union(geoms)
        if not u.is_valid:
            u = u.buffer(0)
        if u.is_empty:
            continue
        parts = list(u.geoms) if u.geom_type == "MultiPolygon" else [u]
        parts = [p for p in parts if p.area * af >= AREA_MIN_M2]
        for p in parts:
            erf_rows.append({"erf": erf, "n_parts": len(parts), "geometry": p})
    log(f"{len(erf_rows)} erf building parts; {len(noerf)} no-erf candidates")
    progress("PROG regularize")
    erf_regs = regularize_parts(erf_rows)

    best_per_erf = {}
    for row, g in zip(erf_rows, erf_regs):
        if g is None or g.is_empty:
            g = row["geometry"]
        if g.geom_type == "MultiPolygon":
            g = max(g.geoms, key=lambda p: p.area)
        cur = best_per_erf.get(row["erf"])
        if cur is None or g.area > cur[0].area:
            best_per_erf[row["erf"]] = (g, row["n_parts"])

    # ── no-erf: IoU-NMS then regularize ──────────────────────────────────────
    noerf.sort(key=lambda t: t[1], reverse=True)
    kept = []
    for g, s in noerf:
        if any(geom_iou(g, k) > NOERF_NMS_IOU for k, _ in kept):
            continue
        kept.append((g, s))
    noerf_rows = [{"geometry": g, "score": s} for g, s in kept]
    noerf_regs = regularize_parts(noerf_rows)

    # ── features ─────────────────────────────────────────────────────────────
    feats = []
    for erf, (g, n_parts) in best_per_erf.items():
        area = round(g.area * af, 1)
        cat, rr, asp, corners = sw.classify_shape(g, area)
        is_resc = erf in rescued_erven
        feats.append({"type": "Feature", "geometry": mapping(g),
                      "properties": {"erf": erf, "prcl": erven_prcl.get(erf, ""),
                                     "has_building": 1, "n_build": n_parts,
                                     "area_m2": area, "shape": cat,
                                     "rect_ratio": rr, "aspect": asp, "corners": corners,
                                     "source": ("rescue" if is_resc else "erf"),
                                     # rescues are REVIEW CANDIDATES — operator
                                     # confirms/deletes; clf_score aids triage
                                     "flag_for_review": (1 if is_resc else 0),
                                     "clf_score": (rescued_score.get(erf)
                                                   if is_resc else None)}})
    n_vac = 0
    for erf, g in erven_geom.items():
        if erf in best_per_erf or g.is_empty:
            continue
        n_vac += 1
        feats.append({"type": "Feature", "geometry": mapping(g),
                      "properties": {"erf": erf, "prcl": erven_prcl.get(erf, ""),
                                     "has_building": 0, "n_build": 0,
                                     "area_m2": 0.0, "shape": "vacant",
                                     "rect_ratio": None, "aspect": None,
                                     "corners": None, "source": "erf",
                                     "flag_for_review": 0, "clf_score": None}})
    for row, g in zip(noerf_rows, noerf_regs):
        if g is None or g.is_empty:
            g = row["geometry"]
        if g.geom_type == "MultiPolygon":
            g = max(g.geoms, key=lambda p: p.area)
        area = round(g.area * af, 1)
        cat, rr, asp, corners = sw.classify_shape(g, area)
        feats.append({"type": "Feature", "geometry": mapping(g),
                      "properties": {"erf": None, "prcl": "",
                                     "has_building": 1, "n_build": 1,
                                     "area_m2": area, "shape": cat,
                                     "rect_ratio": rr, "aspect": asp,
                                     "corners": corners, "source": "standalone",
                                     "flag_for_review": 0, "clf_score": None}})

    # ── final topological cleanup: global dedup + circle/merged flags ────────
    feats, clean_stats = cl.global_cleanup(feats, af)
    if clean_stats.get("enabled"):
        log(f"cleanup: deduped {clean_stats['deduped']}, flagged "
            f"{clean_stats['circles_flagged']} circle / "
            f"{clean_stats['merged_flagged']} merged")

    fc = {"type": "FeatureCollection",
          "crs": {"type": "name", "properties": {"name": "EPSG:3857"}},
          "features": feats}
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(fc, f)

    from collections import Counter
    cnt = Counter(ft["properties"]["shape"] for ft in feats)
    res = {"features": len(feats), "occupied_erven": len(best_per_erf),
           "vacant_erven": n_vac, "standalone": len(noerf_rows),
           "rescued": len(rescued_erven), "boxes": total_boxes,
           "deduped": clean_stats.get("deduped", 0),
           "shapes": dict(cnt), "out": out_path}
    log(f"DONE {json.dumps(res)}")
    progress("RESULT " + json.dumps(res))
    return 0


if __name__ == "__main__":
    sys.exit(main())
