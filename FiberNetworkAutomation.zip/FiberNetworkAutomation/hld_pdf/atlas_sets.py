# -*- coding: utf-8 -*-
"""HLD Network Atlas page SETS (e.g. "Underground"), in pure Python (no QGIS imports).

A grid atlas prints the Network set: an overview page, then one page per grid block. A page
set prints the same pages again (its own overview with the grid, then every block at the same
zoom) drawing only the layers and labels the operator ticked. Sets print one after another
(JJ 2026-10-26, D1/D2). This module holds everything about sets that can be decided without
QGIS, so it can be property tested in isolation:

  * the set list (JSON on the layout, schema_version) - round trip, cleaning, validation,
  * row expansion: set k's rows get seq = k * (N + 1) + network seq, so the atlas sort stays
    "seq" and pages run set after set with no gaps; Network rows are passed through untouched,
  * the label table (which layer or copy draws for a ticked layer) and a set page's id row,
  * page titles, PDF bookmark labels, the (set_no, unit) page key, and the QGIS expressions
    the layout uses (map layer list, per-set item visibility, title).

QGIS-side reading and writing lives in atlas_sets_qgis.py.
"""
import json
import re
import secrets

SCHEMA_VERSION = 1

# QSettings switch: on = the Pages... button is hidden and Rebuild ignores stored sets, which
# gives the exact pre-feature output (plan F5).
SETTING_OFF = "vf/hld/atlas_sets_off"

PROP_SETS = "vf_atlas_sets"            # set list JSON on the layout (and the Rebuild copy)
PROP_OWNER = "vf_atlas_set_owner"      # on every copy layer: the set id that owns it
PROP_SET_NO = "vf_set_no"              # on every per-set sidebar item
NAME_PREFIX = "vfas_"
NETWORK_TITLE = "Network"              # set 0, always first, never edited (assumption 1)
DEFAULT_SET_TITLE = "Page set"

# Fields the feature adds to "HLD Book Pages". Network rows carry the defaults.
NEW_FIELDS = ("set_no", "set_title", "page_ids")
NETWORK_DEFAULTS = {"set_no": 0, "set_title": "", "page_ids": ""}

COPY_NOLABEL = "nolbl"                 # same style, labels off
COPY_LABELONLY = "lbl"                 # labels only (the HLD Book's virtual-layer pattern)

_HEX12 = re.compile(r"^[0-9a-f]{12}$")
COPY_NAME_RE = re.compile(r"^vfas_[0-9a-f]{12}_[0-9]+_(nolbl|lbl)$")


class SetsError(ValueError):
    """A set list or a page-row table this module refuses to work with."""


# ── ids and names ──────────────────────────────────────────────────────────────────────
def new_set_id():
    """12 random lowercase hex chars - hex can never spell a role keyword."""
    return secrets.token_hex(6)


def is_set_id(s):
    return bool(_HEX12.match(str(s or "")))


def copy_layer_name(set_id, n, kind):
    """Private copy name: vfas_<set id>_<n>_nolbl|lbl. Unique per set and per copy."""
    if kind not in (COPY_NOLABEL, COPY_LABELONLY):
        raise SetsError("unknown copy kind %r" % (kind,))
    return "%s%s_%d_%s" % (NAME_PREFIX, set_id, int(n), kind)


def is_copy_name(name):
    return bool(COPY_NAME_RE.match(str(name or "")))


# ── set list ───────────────────────────────────────────────────────────────────────────
def empty_sets():
    return {"schema_version": SCHEMA_VERSION, "sets": []}


def make_set(title, layers=(), note="", set_id=None):
    """layers: [(layer id, labels ticked)] or [{"id", "labels"}]."""
    return {"set_id": set_id or new_set_id(), "title": str(title), "note": str(note or ""),
            "layers": _clean_layers(layers)}


def _clean_layers(layers):
    out, seen = [], set()
    for x in layers or ():
        if isinstance(x, dict):
            lid, lab = x.get("id"), x.get("labels")
        else:
            lid, lab = x[0], x[1]
        lid = str(lid or "")
        if lid and lid not in seen:
            seen.add(lid)
            out.append({"id": lid, "labels": bool(lab)})
    return out


def unique_titles(titles, reserved=(NETWORK_TITLE,)):
    """Unique set titles, case-insensitive, order kept; '' becomes 'Page set'; a reserved
    title (Network) is never handed to an added set."""
    out, used = [], {r.lower() for r in reserved}
    for t in titles:
        base = " ".join(str(t).replace("\\", "/").split()) or DEFAULT_SET_TITLE
        cand, n = base, 2
        while cand.lower() in used:
            cand = "%s (%d)" % (base, n)
            n += 1
        used.add(cand.lower())
        out.append(cand)
    return out


def normalise(sets):
    """A cleaned copy: valid and unique set ids, unique titles, de-duplicated layer lists."""
    if not isinstance(sets, dict):
        raise SetsError("a set list is a JSON object")
    s = json.loads(json.dumps(sets))
    out, ids = [], set()
    for x in s.get("sets") or []:
        if not isinstance(x, dict):
            raise SetsError("a page set is a JSON object")
        sid = str(x.get("set_id") or "")
        if not is_set_id(sid) or sid in ids:
            sid = new_set_id()
            while sid in ids:
                sid = new_set_id()
        ids.add(sid)
        out.append(make_set(x.get("title", ""), x.get("layers"), x.get("note", ""), sid))
    for x, t in zip(out, unique_titles([x["title"] for x in out])):
        x["title"] = t
    return {"schema_version": SCHEMA_VERSION, "sets": out}


def to_json(sets):
    return json.dumps(normalise(sets), sort_keys=True, separators=(",", ":"))


def from_json(text):
    """Parse the stored set list. A newer schema_version is refused, never guessed."""
    try:
        s = json.loads(text)
    except (TypeError, ValueError) as e:
        raise SetsError("the stored page sets cannot be read (%s)" % e)
    if not isinstance(s, dict):
        raise SetsError("the stored page sets are not a JSON object")
    try:
        v = int(s.get("schema_version", 0))
    except (TypeError, ValueError):
        raise SetsError("the stored page sets have no valid schema_version")
    if v > SCHEMA_VERSION:
        raise SetsError("these page sets were saved by a newer Velocity Nexus (schema %d, this "
                        "release reads %d) - update the plugin." % (v, SCHEMA_VERSION))
    if v < 1:
        raise SetsError("the stored page sets have no valid schema_version")
    return normalise(s)


def validate(sets, names_by_id):
    """(errors, warnings, missing). `names_by_id` = {layer id: current name}.

    errors   refuse OK / Rebuild / export: a ticked layer whose name contains '|' (the map's
             layer list is '|'-joined), a ticked layer whose name another layer also has (the
             map resolves its list by NAME and would draw both - QGIS 3.38-4.2 take no ids
             there), a set title holding "[%" (it would be read as an expression).
    warnings never refuse: a set with nothing ticked (it draws aerial + guard only, F7).
    missing  [(set title, layer id)] - a ticked layer that was deleted. Exports stop until the
             set is fixed or the operator confirms (plan "Missing layers")."""
    errors, warnings, missing = [], [], []
    uses = {}
    for n in names_by_id.values():
        uses[n] = uses.get(n, 0) + 1
    for x in normalise(sets)["sets"]:
        if "[%" in x["title"]:
            errors.append("Page set title “%s” cannot contain “[%%”." % x["title"])
        if not x["layers"]:
            warnings.append("Page set “%s” has no layers ticked - its pages show the aerial "
                            "photo only." % x["title"])
        for lay in x["layers"]:
            n = names_by_id.get(lay["id"])
            if n is None:
                missing.append((x["title"], lay["id"]))
            elif "|" in n:
                errors.append("Page set “%s”: layer name “%s” contains “|” - rename it."
                              % (x["title"], n))
            elif uses.get(n, 0) > 1:
                errors.append("Page set “%s”: %d layers are called “%s” - rename the others, or "
                              "these pages would draw all of them." % (x["title"], uses[n], n))
    return errors, warnings, missing


# ── page rows ──────────────────────────────────────────────────────────────────────────
def check_network_rows(rows):
    """The Network rows must be what the engine builds: seq 0..N, exactly one overview, at
    seq 0, and no set rows. Returns N (blocks). Raises SetsError otherwise."""
    if not rows:
        raise SetsError("the atlas has no pages")
    seqs = sorted(int(r["seq"]) for r in rows)
    if seqs != list(range(len(rows))):
        raise SetsError("page numbers are not 0..%d - rebuild the atlas" % (len(rows) - 1))
    ovs = [int(r["seq"]) for r in rows if int(r.get("is_overview") or 0) == 1]
    if ovs != [0]:
        raise SetsError("the atlas must have exactly one overview page, first")
    if any(int(r.get("set_no") or 0) != 0 for r in rows):
        raise SetsError("these rows already hold page sets")
    return len(rows) - 1


def expand_rows(network_rows, sets, page_ids):
    """All page rows: the Network rows (passed through, NEW_FIELDS added at their defaults),
    then for each set k = 1, 2, ... one copy of every Network row, in Network order, with
    seq = k * (N + 1) + network seq, set_no = k, set_title, and page_ids.

    page_ids: {set id: (overview ids, block ids)} - the '|'-joined row text is built here."""
    n = check_network_rows(network_rows)
    net = sorted(network_rows, key=lambda r: int(r["seq"]))
    out = []
    for r in net:
        row = dict(r)
        row.update(NETWORK_DEFAULTS)
        out.append(row)
    for k, x in enumerate(normalise(sets)["sets"], start=1):
        ov_ids, blk_ids = page_ids[x["set_id"]]
        for r in net:
            row = dict(r)
            ov = int(r.get("is_overview") or 0) == 1
            row.update({"seq": k * (n + 1) + int(r["seq"]), "set_no": k, "set_title": x["title"],
                        "page_ids": join_ids(ov_ids if ov else blk_ids)})
            out.append(row)
    return out


def network_rows(rows):
    """The Network rows only, NEW_FIELDS removed - what Remove Grid Blocks snapshots."""
    return [{k: v for k, v in r.items() if k not in NEW_FIELDS}
            for r in rows if int(r.get("set_no") or 0) == 0]


def page_count(n_sets, n_blocks):
    return (int(n_sets) + 1) * (int(n_blocks) + 1)


def set_page_range(set_no, n_blocks):
    """1-based (first, last) printed page of set `set_no`."""
    k, n1 = int(set_no), int(n_blocks) + 1
    return k * n1 + 1, (k + 1) * n1


def network_seq(seq, n_blocks):
    """The Network page a set page repeats."""
    return int(seq) % (int(n_blocks) + 1)


# ── label table and a set page's layer list ────────────────────────────────────────────
def draw_parts(own_labels_on, labels_ticked):
    """What draws for one ticked layer, top first (the plan's label table):
        own labels on,  ticked     -> the real layer
        own labels on,  not ticked -> a no-label copy
        own labels off, ticked     -> a label-only copy above the real layer
        own labels off, not ticked -> the real layer"""
    if own_labels_on:
        return ("real",) if labels_ticked else (COPY_NOLABEL,)
    return (COPY_LABELONLY, "real") if labels_ticked else ("real",)


def copies_needed(set_spec, labels_on_by_id):
    """[(source id, copy kind)] the set needs, in its layer order. Layers missing from
    `labels_on_by_id` (deleted) need nothing."""
    out = []
    for lay in set_spec["layers"]:
        if lay["id"] not in labels_on_by_id:
            continue
        for part in draw_parts(labels_on_by_id[lay["id"]], lay["labels"]):
            if part != "real":
                out.append((lay["id"], part))
    return out


def set_page_ids(set_spec, labels_on_by_id, tree_order, copies, aerial_id, guard_id, grid_id=""):
    """(overview ids, block ids) for one set, top first.

    Ticked layers in Layers-panel order (`tree_order`, top first; layers not in the panel
    after it, in set order), each replaced by its draw parts; copies come from
    `copies` {(source id, kind): copy id}. The grid draws on the overview only. Aerial + guard
    always close the list, so a page can never resolve to nothing (F7: an empty list makes
    QGIS draw every Layers-panel layer). Deleted layers are skipped (validate() reports them)."""
    pos = {lid: i for i, lid in enumerate(tree_order or [])}
    lays = [lay for lay in set_spec["layers"] if lay["id"] in labels_on_by_id]
    lays.sort(key=lambda lay: (pos.get(lay["id"], 10 ** 6), set_spec["layers"].index(lay)))
    body = []
    for lay in lays:
        for part in draw_parts(labels_on_by_id[lay["id"]], lay["labels"]):
            if part == "real":
                body.append(lay["id"])
            else:
                cid = copies.get((lay["id"], part))
                if cid:
                    body.append(cid)
                elif part == COPY_NOLABEL:
                    body.append(lay["id"])       # no copy could be made (warned): the real layer draws
                # a label-only copy that could not be made: the real layer below still draws
    fixed = [i for i in (aerial_id, guard_id) if i]
    block = _uniq(body + fixed)
    overview = _uniq(([grid_id] if grid_id else []) + body + fixed)
    return overview, block


def join_ids(ids):
    return "|".join(ids)


def split_ids(text):
    return [x for x in str(text or "").split("|") if x]


def _uniq(seq):
    out, seen = [], set()
    for x in seq or ():
        x = str(x)
        if x and x not in seen:
            seen.add(x)
            out.append(x)
    return out


# ── titles, bookmarks, page key ────────────────────────────────────────────────────────
_OVERVIEW_TAIL = re.compile(r"\s*Overview\s*$")
_LAST_DASH = re.compile(r"^(.*) - ([^-]*)$")


def set_page_title(network_title, set_title, is_overview):
    """A set page's title, derived from the Network page it repeats so the wording stays the
    operator's own (JJ's Groenhuewel book says "Grid", the engine default says "PON"):
        "<Head> Overview"   -> "<Head> - Underground Overview"
        "<Head> - Grid 5"   -> "<Head> - Underground - Grid 5"
        anything else       -> "Underground - <title>"
    Mirrors title_expression() exactly."""
    t, st = str(network_title or ""), str(set_title or "")
    if is_overview:
        return "%s - %s Overview" % (_OVERVIEW_TAIL.sub("", t), st)
    m = _LAST_DASH.match(t)
    return "%s - %s - %s" % (m.group(1), st, m.group(2)) if m else "%s - %s" % (st, t)


def page_labels(rows, network_label):
    """Ordered [(0-based page index, bookmark label)] over all rows, by seq.

    `network_label(row, index)` gives today's label for a Network row (hld_generate's
    'Overview' / '<unit word> <unit>'), so Network bookmarks do not change. A set row reads
    '<Set> - <the label of the Network page it repeats>'."""
    rows = sorted(rows, key=lambda r: int(r["seq"]))
    net = [r for r in rows if int(r.get("set_no") or 0) == 0]
    n1 = len(net)
    out = []
    for i, r in enumerate(rows):
        if int(r.get("set_no") or 0) == 0:
            out.append((i, network_label(r, i)))
        else:
            j = network_seq(r["seq"], n1 - 1)
            out.append((i, "%s - %s" % (r.get("set_title"), network_label(net[j], j))))
    return out


def page_key(row):
    """(set_no, unit) - unique over all rows."""
    return int(row.get("set_no") or 0), "" if row.get("unit") is None else str(row["unit"])


def key_set_no(key):
    """A Page pictures key's set; keys pinned before this release count as Network."""
    try:
        return int((key or {}).get("set_no") or 0)
    except (TypeError, ValueError):
        return 0


# ── QGIS expressions (built here so they are tested here) ──────────────────────────────
_SET_NO = "coalesce(attribute(@atlas_feature,'set_no'),0)"


def _sql_str(s):
    return "'" + str(s if s is not None else "").replace("'", "''") + "'"


def map_layers_expression(guard_name):
    """Data-defined map layers. NULL on Network rows, so the per-page theme decides exactly
    as before (step 0 proved this on 3.38-4.2). On set rows: the row's ids turned into
    CURRENT names (a rename never drops a layer), falling back to the guard layer."""
    return ("CASE WHEN %s = 0 THEN NULL ELSE coalesce(nullif(array_to_string(array_filter("
            "array_foreach(string_to_array(coalesce(attribute(@atlas_feature,'page_ids'),''),'|'),"
            "layer_property(@element,'name')), @element IS NOT NULL AND @element <> ''),'|'),''),"
            "%s) END" % (_SET_NO, _sql_str(guard_name)))


def set_hidden_expression(set_no):
    """True on every page that is not set `set_no` - drives ExcludeFromExports (and opacity
    0) on that set's sidebar items, the rule Page pictures already uses."""
    return "%s <> %d" % (_SET_NO, int(set_no))


def title_expression(network_expr_body):
    """Wrap the engine's title expression body (the text between [% and %]) so Network pages
    keep it exactly and set pages read set_page_title() of that same text."""
    # QGIS string literals unescape "\\" to "\", so the regex text is written doubled here;
    # set titles never hold a backslash (unique_titles), so they are safe in a replacement
    body = "(%s)" % network_expr_body
    st = "coalesce(attribute(@atlas_feature,'set_title'),'')"
    ov = "regexp_replace(%s, '\\\\s*Overview\\\\s*$', '') || ' - ' || %s || ' Overview'" % (body, st)
    det = ("if(regexp_match(%s, '^(.*) - ([^-]*)$') > 0, "
           "regexp_replace(%s, '^(.*) - ([^-]*)$', '\\\\1 - ' || %s || ' - \\\\2'), "
           "%s || ' - ' || %s)" % (body, body, st, st, body))
    return ("[%% if(%s = 0, %s, if(coalesce(attribute(@atlas_feature,'is_overview'),0) = 1, %s, %s)) %%]"
            % (_SET_NO, network_expr_body, ov, det))


_QGIS_ID_TAIL = re.compile(r"_[0-9a-f]{8}_[0-9a-f]{4}_[0-9a-f]{4}_[0-9a-f]{4}_[0-9a-f]{12}$")


def name_from_layer_id(layer_id):
    """A deleted layer has no name left; QGIS ids are '<name>_<uuid>', so show the name part."""
    s = str(layer_id or "")
    return _QGIS_ID_TAIL.sub("", s) or s


def missing_layer_message(set_title, layer_name, set_no, n_blocks):
    if int(n_blocks) < 0:                     # the atlas has no pages yet (reopened, not rebuilt)
        where = "Its pages would print without it"
    else:
        where = "Pages %d-%d would print without it" % set_page_range(set_no, n_blocks)
    return ("Page set “%s”: layer “%s” was deleted. %s - untick it in Pages… or confirm to "
            "export anyway." % (set_title, layer_name, where))
