"""Phase 5 — Erven Tuning Studio (Gradio local app).

All logic is in plain functions (load/detect/tune/learn/save/load/export) so it can be tested
headlessly; the Gradio widgets in build_ui() just bind to them. Run:  python app.py  -> browser UI.

State is a module dict: img (uint8 RGB), transform (6 affine, EPSG:3857), buildings/erven GeoDataFrames,
params, aoi. Works on the Mohadin demo tile (.npz) or any GeoTIFF.
"""
import json
import time
from pathlib import Path

import numpy as np
import cv2
import geopandas as gpd
from rasterio.transform import Affine
from shapely.geometry import box

from buildings import propose_buildings
from erven import generate_erven
from infer_params import fit_params

DEMO_NPZ = "C:/Temp/erven_work/bld_g/mosaic/mohadin.npz"
DEFAULTS = {"iou": 0.7, "stability": 0.9, "min_area_b": 20.0, "max_area_b": 600.0,
            "roof_colour_on": True, "merge_m": 12.0, "stand_W": 0.0, "stand_depth": 27.0,
            "orient_snap": True, "min_area_e": 60.0, "max_area_e": 1300.0}
S = {"img": None, "tr": None, "crs": 3857, "buildings": None, "erven": None,
     "params": dict(DEFAULTS), "aoi": None}


# ── helpers ──
def _overlay(img, gdf, colour, width=2):
    if gdf is None or len(gdf) == 0:
        return img.copy()
    a, b, c, d, e, f = S["tr"]; inv = ~Affine(a, b, c, d, e, f)
    ov = img.copy()
    g = gdf.to_crs(S["crs"])
    for geom in g.geometry:
        polys = geom.geoms if geom.geom_type == "MultiPolygon" else [geom]
        for pp in polys:
            ring = [tuple(map(int, inv * (x, y))) for x, y in pp.exterior.coords]
            cv2.polylines(ov, [np.array(ring, np.int32)], True, colour, width)
    return ov


def _aoi():
    a, b, c, d, e, f = S["tr"]; H, W = S["img"].shape[:2]
    xs = [c, a * W + c]; ys = [f, e * H + f]
    return gpd.GeoDataFrame(geometry=[box(min(xs), min(ys), max(xs), max(ys))], crs=S["crs"])


# ── callbacks ──
def load_raster(path=None):
    if path and str(path).lower().endswith((".tif", ".tiff")):
        import rasterio
        with rasterio.open(path) as src:
            img = np.transpose(src.read([1, 2, 3]), (1, 2, 0)).astype("uint8")
            t = src.transform; S["tr"] = [t.a, t.b, t.c, t.d, t.e, t.f]; S["crs"] = src.crs.to_epsg()
    else:
        z = np.load(DEMO_NPZ); m = z["mos"]
        y, x = m.shape[0] // 2, m.shape[1] // 2
        img = np.ascontiguousarray(m[y - 320:y + 320, x - 320:x + 320])
        a, b, c, d, e, f = z["transform"]
        S["tr"] = [a, b, a * (x - 320) + c, d, e, e * (y - 320) + f]; S["crs"] = 3857
    S["img"] = img; S["aoi"] = _aoi(); S["buildings"] = None; S["erven"] = None
    return img


def detect(mode, iou, stability, min_area_b, max_area_b, roof_colour_on):
    if S["img"] is None:
        load_raster()
    p = {"iou": iou, "stability": stability, "min_area": min_area_b, "max_area": max_area_b,
         "roof_colour_on": roof_colour_on, "points_per_side": 24}
    try:
        S["buildings"] = propose_buildings(S["img"], S["tr"], p, mode=mode)
    except Exception as e:
        # e.g. AI/torch not installed on this laptop — show a clear message, don't crash.
        return S["img"], f"Detection unavailable: {e}"
    return _overlay(S["img"], S["buildings"], (0, 255, 0), 2), f"{len(S['buildings'])} buildings"


def tune(merge_m, stand_W, stand_depth, orient_snap, min_area_e, max_area_e):
    if S["buildings"] is None or len(S["buildings"]) == 0:
        return S["img"], S["img"], "detect buildings first"
    p = {"merge_m": merge_m, "stand_W": stand_W, "stand_depth": stand_depth,
         "orient_snap": orient_snap, "min_area": min_area_e, "max_area": max_area_e,
         "orient": S["params"].get("orient")}
    t0 = time.time()
    S["erven"] = generate_erven(S["buildings"], S["aoi"], p)
    after = _overlay(S["img"], S["erven"], (255, 160, 0), 2)
    return S["img"], after, f"{len(S['erven'])} erven ({time.time()-t0:.1f}s)"


def learn_from_examples(example_gdf):
    """example_gdf: GeoDataFrame of erven the user drew/uploaded. Returns fitted slider values."""
    fit = fit_params(example_gdf)
    S["params"].update(fit)
    return fit


def save_config(path="C:/Temp/erven_studio_config.json", name="area"):
    cfg = {"name": name, **S["params"]}
    Path(path).write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    return cfg


def load_config(path="C:/Temp/erven_studio_config.json"):
    cfg = json.loads(Path(path).read_text(encoding="utf-8"))
    S["params"].update({k: v for k, v in cfg.items() if k in DEFAULTS or k in ("stand_W", "stand_depth", "merge_m", "orient")})
    return cfg


def export(outdir="C:/Temp"):
    paths = {}
    if S["buildings"] is not None and len(S["buildings"]):
        pth = f"{outdir}/studio_buildings.geojson"; S["buildings"].to_crs(4326).to_file(pth, driver="GeoJSON"); paths["buildings"] = pth
    if S["erven"] is not None and len(S["erven"]):
        pth = f"{outdir}/studio_erven.geojson"; S["erven"].to_crs(4326).to_file(pth, driver="GeoJSON"); paths["erven"] = pth
        dp = S["erven"].copy(); dp["geometry"] = S["erven"].to_crs(32735).geometry.representative_point()
        pth = f"{outdir}/studio_demand.geojson"; dp.set_geometry("geometry").to_crs(4326).to_file(pth, driver="GeoJSON"); paths["demand"] = pth
    return paths


# ── Gradio UI ──
def build_ui():
    import gradio as gr
    try:
        from gradio_imageslider import ImageSlider
        _Slider = lambda: ImageSlider(label="Before | After", type="numpy")
    except Exception:
        _Slider = lambda: gr.Image(label="After")

    with gr.Blocks(title="Erven Tuning Studio") as ui:
        gr.Markdown("# Erven Tuning Studio\nLoad raster → Detect → tune sliders → draw examples → Learn → Save/Export.")
        with gr.Row():
            raster = gr.File(label="Raster (.tif) — empty = Mohadin demo", file_types=[".tif", ".tiff"])
            mode = gr.Dropdown(["sam_auto", "gob_batch"], value="sam_auto", label="Building source")
        with gr.Accordion("Building sliders", open=True):
            iou = gr.Slider(0.5, 0.95, 0.7, label="SAM IoU")
            stab = gr.Slider(0.8, 0.99, 0.9, label="Stability")
            minb = gr.Slider(5, 200, 20, label="Min area m²"); maxb = gr.Slider(100, 1200, 600, label="Max area m²")
            roof = gr.Checkbox(True, label="Roof-colour filter")
        det_btn = gr.Button("Detect buildings"); det_img = gr.Image(label="Buildings"); det_txt = gr.Textbox(label="")
        with gr.Accordion("Erven sliders", open=True):
            merge = gr.Slider(6, 24, 12, label="Block merge m")
            sw = gr.Slider(0, 30, 0, label="Stand width m (0=auto)"); sd = gr.Slider(15, 45, 27, label="Stand depth m")
            osnap = gr.Checkbox(True, label="Snap to street orientation")
            mine = gr.Slider(30, 300, 60, label="Min erf m²"); maxe = gr.Slider(300, 2000, 1300, label="Max erf m²")
        tune_btn = gr.Button("Generate / tune erven")
        slider_out = _Slider()
        with gr.Row():
            name = gr.Textbox("area", label="Config name"); save_btn = gr.Button("Save config"); exp_btn = gr.Button("Export GeoJSON")
        status = gr.Textbox(label="Status")

        raster.change(lambda f: load_raster(f.name if f else None), raster, det_img)
        det_btn.click(detect, [mode, iou, stab, minb, maxb, roof], [det_img, det_txt])
        tune_btn.click(tune, [merge, sw, sd, osnap, mine, maxe], [det_img, slider_out, status])
        save_btn.click(lambda n: json.dumps(save_config(name=n)), name, status)
        exp_btn.click(lambda: json.dumps(export()), None, status)
    return ui


if __name__ == "__main__":
    build_ui().launch(server_name="127.0.0.1", server_port=7861, inbrowser=True)
