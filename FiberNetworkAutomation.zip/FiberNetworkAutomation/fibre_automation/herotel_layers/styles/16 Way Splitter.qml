<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="4.2.0" styleCategories="Symbology|Labeling" labelsEnabled="0">
  <renderer-v2 referencescale="-1" forceraster="0" enableorderby="0" type="singleSymbol" symbollevels="0">
        <symbols>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="marker" name="0" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleMarker" pass="0" id="{10a05da9-d9c9-48e4-8c35-1bc28acabb94}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="0" name="angle" />
                <Option type="QString" value="square" name="cap_style" />
                <Option type="QString" value="219,30,42,255,rgb:0.8588235,0.1176471,0.1647059,1" name="color" />
                <Option type="QString" value="1" name="horizontal_anchor_point" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="triangle" name="name" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="128,17,25,255,rgb:0.5019608,0.0666667,0.0980392,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.4" name="outline_width" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="diameter" name="scale_method" />
                <Option type="QString" value="4" name="size" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale" />
                <Option type="QString" value="MM" name="size_unit" />
                <Option type="QString" value="1" name="vertical_anchor_point" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </symbols>
        <rotation />
        <sizescale />
        <data-defined-properties>
          <Option type="Map">
            <Option type="QString" value="" name="name" />
            <Option name="properties" />
            <Option type="QString" value="collection" name="type" />
          </Option>
        </data-defined-properties>
      </renderer-v2>
</qgis>
