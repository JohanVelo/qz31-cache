"""Retire only the obsolete BOQ package left by overlay installs.

Preimages and a resumable journal stay outside the importable plugin. This module
contains no quantity extraction or spreadsheet generation.
"""
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

FILES = frozenset({
    '__init__.py', 'constants.py', 'detail_tabs.py', 'engine.py', 'excel.py',
    'fibertime_mml.py', 'herotel_boq.py', 'layers.py', 'phase_split.py',
    'router.py', 'takeoff.py', 'way_counter.py', 'boq_rates_default.json',
    'fibertime_rates.json', 'boq_template_moa.json',
})
PREFIXES = ('fibre_automation.boq', 'FiberNetworkAutomation.fibre_automation.boq')


def _digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _safe(path, root):
    """Check lexical containment and every existing component before resolving."""
    path, root = Path(path).absolute(), Path(root).absolute()
    if not path.is_relative_to(root):
        raise ValueError('Retirement path escaped its declared root')
    for part in (path, *path.parents):
        if part.exists() or part.is_symlink():
            attrs = part.lstat()
            if stat.S_ISLNK(attrs.st_mode) or getattr(attrs, 'st_file_attributes', 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
                raise ValueError('Retirement refuses linked or reparse paths')
        if part == root:
            break
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError('Resolved retirement path escaped its root')
    return path


def _allowed(relative):
    parts = Path(relative).parts
    if len(parts) == 1:
        return parts[0] in FILES or parts[0].endswith('.pyc') and parts[0][:-1] in FILES
    if len(parts) == 2 and parts[0] == '__pycache__':
        # Only Python's cache spelling for a known retired module, not any *.pyc.
        name = parts[1]
        import re
        # Six such backups remain from the QGIS MSI migration on existing installs.
        msi = re.fullmatch(r'(__init__|constants|engine|excel|fibertime_mml|takeoff)\.cpython-312-MSI\.pyc', name)
        if msi:
            return True
        match = re.fullmatch(r'([A-Za-z_][A-Za-z_0-9]*)\.(?:cpython|pypy)-[0-9]+(?:\.opt-[012])?\.pyc', name)
        return bool(match and match.group(1) + '.py' in FILES)
    return False


def _locations(plugin_root):
    root = Path(plugin_root).absolute()
    if root.name != 'FiberNetworkAutomation':
        raise ValueError('Unexpected installed plugin identity')
    _safe(root, root.parent)
    package = _safe(root/'fibre_automation'/'boq', root)
    archive = _safe(root.parent/'.velocity_retired_boq', root.parent)
    return root, package, archive


@contextmanager
def _locked(archive):
    """OS lock releases on process death; a leftover lock file is harmless."""
    archive.mkdir(exist_ok=True)
    lock = _safe(archive/'retirement.lock', archive)
    with lock.open('a+b') as handle:
        handle.seek(0, os.SEEK_END)
        if handle.tell() == 0:
            handle.write(b'0')
            handle.flush()
        handle.seek(0)
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == 'nt':
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle, fcntl.LOCK_UN)


def _load(archive, root):
    path = _safe(archive/'journal.json', archive)
    if not path.exists():
        return {'root': str(root), 'entries': {}}
    journal = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(journal, dict) or journal.get('root') != str(root) or not isinstance(journal.get('entries'), dict):
        raise ValueError('Retirement journal belongs to a different plugin')
    for relative, entry in journal['entries'].items():
        if not _allowed(relative) or not isinstance(entry, dict):
            raise ValueError('Unexpected journal entry')
        digest = entry.get('sha256', '')
        if not isinstance(digest, str) or len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
            raise ValueError('Invalid journal digest')
    return journal


def _save(archive, journal):
    temp = _safe(archive/'journal.tmp', archive)
    target = _safe(archive/'journal.json', archive)
    with temp.open('w', encoding='utf-8') as handle:
        json.dump(journal, handle, indent=2)
        handle.flush()
        os.fsync(handle.fileno())
    _replace(temp, target)


def _replace(source, target, expected_digest=None):
    """Bounded recovery from transient Windows scanner/OneDrive file locks."""
    for attempt in range(3):
        try:
            if expected_digest is not None:
                if _digest(source) != expected_digest:
                    raise ValueError('Concurrent source change during retirement retry')
                if target.exists() and _digest(target) != expected_digest:
                    raise ValueError('Backup changed during retirement retry')
            os.replace(source, target)
            return
        except PermissionError:
            if attempt == 2:
                raise
            time.sleep(0.05 * (attempt + 1))


def _backup(archive, relative, digest):
    # Deterministic and independent of a journal-provided destination path.
    key = hashlib.sha256(relative.encode('utf-8')).hexdigest()
    return _safe(archive/(key+'-'+digest+'.bak'), archive)


def _candidates(package):
    if not package.exists():
        return []
    result = []
    for child in package.iterdir():
        _safe(child, package)
        if child.name == '__pycache__' and child.is_dir():
            for cached in child.iterdir():
                _safe(cached, package)
                result.append(cached)
        else:
            result.append(child)
    return result


def retire(plugin_root):
    result = {'complete': False, 'moved': [], 'issues': []}
    try:
        root, package, archive = _locations(plugin_root)
        if not package.exists() and not archive.exists():
            result['complete'] = True
            return result
        with _locked(archive):
            journal = _load(archive, root)
            candidates = _candidates(package)
            for path in sorted(candidates):
                rel = path.relative_to(package).as_posix()
                if not path.is_file() or not _allowed(rel):
                    result['issues'].append('Unrecognized file retained: '+rel)
                    continue
                try:
                    _safe(path, root)
                    digest = _digest(path)
                    entry = journal['entries'].get(rel)
                    if entry and entry['sha256'] != digest:
                        raise ValueError('File changed since retirement snapshot: '+rel)
                    backup = _backup(archive, rel, digest)
                    if backup.exists() and _digest(backup) != digest:
                        raise ValueError('Backup does not match: '+rel)
                    journal['entries'][rel] = {'sha256': digest}
                    _save(archive, journal)  # Persist intent BEFORE touching source.
                    if _digest(path) != digest:
                        raise ValueError('Concurrent source change: '+rel)
                    _replace(path, backup, expected_digest=digest)
                    if _digest(backup) != digest:
                        raise ValueError('Moved-file verification failed: '+rel)
                    result['moved'].append(rel)
                except (OSError, ValueError) as exc:
                    result['issues'].append(str(exc))
            # A prior crash after intent but before move must not become success.
            for rel, entry in journal['entries'].items():
                src = _safe(package/rel, root)
                backup = _backup(archive, rel, entry['sha256'])
                if src.exists() or not backup.exists() or _digest(backup) != entry['sha256']:
                    result['issues'].append('Incomplete retirement: '+rel)
            for directory in (package/'__pycache__', package):
                _safe(directory, root)
                if directory.is_dir() and not any(directory.iterdir()):
                    directory.rmdir()  # Empty, bounded directory only; never recursive.
    except (OSError, ValueError, TypeError) as exc:
        result['issues'].append(str(exc))
    result['complete'] = not result['issues']
    return result


def restore(plugin_root):
    """Explicit rollback; never invoked automatically by startup."""
    result = {'complete': False, 'restored': [], 'issues': []}
    try:
        root, package, archive = _locations(plugin_root)
        if not archive.exists():
            result['complete'] = True
            return result
        with _locked(archive):
            journal = _load(archive, root)
            for rel, entry in journal['entries'].items():
                src = _safe(package/rel, root)
                backup = _backup(archive, rel, entry['sha256'])
                if src.exists():
                    if _digest(src) != entry['sha256']:
                        result['issues'].append('Concurrent edit retained: '+rel)
                    continue
                if not backup.exists() or _digest(backup) != entry['sha256']:
                    result['issues'].append('Missing or changed backup: '+rel)
                    continue
                src.parent.mkdir(parents=True, exist_ok=True)
                _safe(src, root)
                # Exclusive create: never clobber a racing editor.
                with src.open('xb') as handle:
                    handle.write(backup.read_bytes())
                if _digest(src) != entry['sha256']:
                    result['issues'].append('Restore verification failed: '+rel)
                else:
                    result['restored'].append(rel)
    except (OSError, ValueError, TypeError) as exc:
        result['issues'].append(str(exc))
    result['complete'] = not result['issues']
    return result


def purge_modules():
    for name in list(sys.modules):
        if any(name == prefix or name.startswith(prefix+'.') for prefix in PREFIXES):
            sys.modules.pop(name, None)
    for prefix in PREFIXES:
        parent, _, child = prefix.rpartition('.')
        module = sys.modules.get(parent)
        if module is not None and hasattr(module, child):
            delattr(module, child)


def startup(iface, plugin_root):
    result = retire(plugin_root)
    purge_modules()
    if not result['complete']:
        from qgis.core import QgsMessageLog, Qgis
        details = '; '.join(result['issues'])
        QgsMessageLog.logMessage(details, 'Velocity Nexus retirement', Qgis.MessageLevel.Warning)
        iface.messageBar().pushWarning('Velocity Nexus', 'Old BOQ controls are removed; cleanup is incomplete. See the message log.')
    return result
