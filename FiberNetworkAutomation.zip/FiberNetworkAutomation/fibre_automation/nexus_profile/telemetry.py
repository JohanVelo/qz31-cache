"""telemetry — presence heartbeat, event capture, breadcrumbs, error reports.

One singleton per plugin. QTimer-driven (main thread), all network via the
dry-run-aware Backend (fire-and-forget). Wrap the action factory + error guard
ONCE to capture every tool without per-tool edits.
"""
import re
import time

from . import config, identity

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

# PII scrub (POPIA-aware): strip file paths + emails from error text before it
# ever leaves the machine. Action names / exception types are kept (safe).
_PATH_RE = re.compile(r'(?:[A-Za-z]:\\|/home/|/Users/|/mnt/|\\\\)[^\s\'"]+')
_EMAIL_RE = re.compile(r'[\w.%+-]+@[\w.-]+\.\w{2,}')


def _scrub(text):
    if not text:
        return text
    try:
        text = _PATH_RE.sub('<path>', text)
        text = _EMAIL_RE.sub('<email>', text)
    except Exception:
        _swallowed_note()
    return text


class Telemetry:
    def __init__(self, iface, backend, profile, data_dir,
                 qgis_version="", plugin_version=""):
        self.iface = iface
        self.backend = backend
        self.profile = profile
        self.data_dir = data_dir
        self.qgis_version = qgis_version
        self.plugin_version = plugin_version
        self.install_id = None
        self.session_id = identity.new_session_id()
        self.crumbs = identity.Breadcrumbs(config.BREADCRUMB_MAX)
        self._queue = []
        self._last_error_ts = 0.0
        self._hb_timer = None
        self._flush_timer = None
        self._active_tool = None

    # ── lifecycle ───────────────────────────────────────────────────────────
    def start(self):
        from .profile import Profile
        self.install_id = Profile.install_id()
        # ensure this machine's install row exists (it IS the presence row).
        # Plain insert — a re-launch just 409s harmlessly. Best-effort, not
        # spooled (registration already spooled the authoritative row).
        self.backend.insert("installs", {
            "install_id": self.install_id,
            "username": self.profile.username,
            "qgis_version": self.qgis_version,
            "plugin_version": self.plugin_version,
        }, spool_it=False)
        # open a session row
        self.backend.insert("sessions", {
            "session_id": self.session_id,
            "install_id": self.install_id,
            "username": self.profile.username,
            "qgis_version": self.qgis_version,
            "plugin_version": self.plugin_version,
            "project_name": self._project_name(),
        })
        self._heartbeat()
        try:
            from qgis.PyQt.QtCore import QTimer
            self._hb_timer = QTimer(self.iface.mainWindow())
            self._hb_timer.timeout.connect(self._heartbeat)
            self._hb_timer.start(config.HEARTBEAT_MS)
            self._flush_timer = QTimer(self.iface.mainWindow())
            self._flush_timer.timeout.connect(self._flush)
            self._flush_timer.start(config.EVENT_FLUSH_MS)
        except Exception:
            _swallowed_note()

    def stop(self):
        for t in (self._hb_timer, self._flush_timer):
            try:
                if t is not None:
                    t.stop()
                    t.deleteLater()
            except Exception:
                _swallowed_note()
        self._hb_timer = self._flush_timer = None
        self._flush()
        # No offline-mark write — presence is INSERT-based (heartbeat events)
        # and simply ages out of the online window. (anon UPDATE is a no-op under
        # the insert-only RLS, so we never relied on it.)

    # ── capture (called from the choke-point wrappers) ──────────────────────
    def record_action(self, action_id, category="tool", message=""):
        self._active_tool = action_id
        self.crumbs.add(action_id, category, message, self.plugin_version)
        self._queue.append({
            "session_id": self.session_id,
            "install_id": self.install_id,
            "username": self.profile.username,
            "plugin_version": self.plugin_version,
            "action_id": action_id,
            "category": category,
            "project_name": self._project_name(),
        })
        if len(self._queue) >= config.EVENT_FLUSH_COUNT:
            self._flush()

    def record_error(self, where, exc, user_note=None):
        """Auto-capture AND Report-a-Problem land here. Rate-limited."""
        now = time.time()
        if now - self._last_error_ts < config.ERROR_MIN_INTERVAL_S and not user_note:
            return                      # crash-loop guard (user reports always go)
        self._last_error_ts = now
        import traceback
        tb = "".join(traceback.format_exception(type(exc), exc,
                                                exc.__traceback__))
        self.backend.insert("errors", {
            "session_id": self.session_id,
            "install_id": self.install_id,
            "username": self.profile.username,
            "plugin_version": self.plugin_version,
            "qgis_version": self.qgis_version,
            "project_name": self._project_name(),
            "action": str(where),
            "error_message": _scrub(f"{type(exc).__name__}: {exc}"),
            "error_traceback": _scrub(tb)[-4000:],
            "active_tool": self._active_tool,
            "breadcrumbs": self.crumbs.tail(20),
            "user_note": user_note,
        })

    def record_freeze(self, severity, duration_ms, stack_text, fingerprint):
        """A UI-freeze captured by the freeze watchdog. Logged into the SAME
        `errors` table (queryable + visible in the Team Monitor) with an action
        tag so freezes are filterable. Called on the MAIN thread (the watchdog
        buffers until the UI is responsive), so the async backend insert is
        safe. Never raises."""
        try:
            self.backend.insert("errors", {
                "session_id": self.session_id,
                "install_id": self.install_id,
                "username": self.profile.username,
                "plugin_version": self.plugin_version,
                "qgis_version": self.qgis_version,
                "project_name": self._project_name(),
                "action": f"ui_freeze:{severity}:{fingerprint}",
                "error_message": _scrub(
                    f"UI freeze {duration_ms} ms [{severity}] fp={fingerprint}"),
                "error_traceback": _scrub(stack_text or "")[-4000:],
                "active_tool": self._active_tool,
                "breadcrumbs": self.crumbs.tail(20),
                "user_note": None,
            })
        except Exception:
            _swallowed_note()

    # ── internals ───────────────────────────────────────────────────────────
    def _heartbeat(self):
        # Presence via INSERT — a '__heartbeat__' event = "alive now, on this
        # version". The monitor takes the latest heartbeat per user within
        # ONLINE_WINDOW_S. INSERT-only (anon UPDATE is a no-op under our RLS).
        # Not spooled — presence is ephemeral; a missed beat is superseded.
        self.backend.insert("events", {
            "session_id": self.session_id,
            "install_id": self.install_id,
            "username": self.profile.username,
            "plugin_version": self.plugin_version,
            "action_id": "__heartbeat__",
            "category": "presence",
            "project_name": self._project_name(),
        }, spool_it=False)

    def _flush(self):
        q, self._queue = self._queue, []
        for ev in q:
            self.backend.insert("events", ev)
        self.backend.flush()

    def _project_name(self):
        try:
            from qgis.core import QgsProject
            return QgsProject.instance().baseName() or None
        except Exception:
            return None


def make_action_wrapper(telemetry):
    """Returns a decorator that records an event before running a callback —
    wrap the plugin's mk() callbacks once at the choke point."""
    def wrap(action_id, fn, category="tool"):
        def inner(*a, **k):
            try:
                if telemetry is not None:
                    telemetry.record_action(action_id, category)
            except Exception:
                _swallowed_note()
            return fn(*a, **k)
        return inner
    return wrap
