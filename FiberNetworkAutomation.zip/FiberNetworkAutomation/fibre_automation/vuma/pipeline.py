"""Vuma master pipeline — runs all 10 steps in sequence."""

from fibre_automation.vuma.step_01_setup import vuma_step_01_setup
from fibre_automation.vuma.step_01b_fetch import vuma_step_01b_fetch  # noqa: F401
from fibre_automation.vuma.step_02_buildings import vuma_step_02_buildings
from fibre_automation.vuma.step_03_demand import vuma_step_03_demand
from fibre_automation.vuma.step_04_pon import vuma_step_04_pon
from fibre_automation.vuma.step_05_nodes import vuma_step_05_nodes
from fibre_automation.vuma.step_06_cables import vuma_step_06_cables
from fibre_automation.vuma.step_07_naming import vuma_step_07_naming
from fibre_automation.vuma.step_08_attributes import vuma_step_08_attributes
from fibre_automation.vuma.step_09_qa import vuma_step_09_qa
from fibre_automation.vuma.step_10_output import vuma_step_10_output

VUMA_STEPS = {
    1: vuma_step_01_setup,
    2: vuma_step_02_buildings,
    3: vuma_step_03_demand,
    4: vuma_step_04_pon,
    5: vuma_step_05_nodes,
    6: vuma_step_06_cables,
    7: vuma_step_07_naming,
    8: vuma_step_08_attributes,
    9: vuma_step_09_qa,
    10: vuma_step_10_output,
}


def vuma_run_step(n: int):
    """Run a single Vuma step by number (1–10)."""
    fn = VUMA_STEPS.get(n)
    if fn is None:
        print(f"  ✗ No Vuma step {n} (valid: 1–10)")
        return
    fn()


def vuma_run_all():
    """Run all 10 Vuma steps in order."""
    print(f"\n{'═' * 55}")
    print("  VUMA FULL PIPELINE — Steps 1–10")
    print(f"{'═' * 55}\n")
    for n in range(1, 11):
        vuma_run_step(n)
    print(f"\n{'═' * 55}")
    print("  VUMA PIPELINE COMPLETE")
    print(f"{'═' * 55}\n")
