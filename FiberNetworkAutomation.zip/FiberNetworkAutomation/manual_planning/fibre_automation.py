"""
=============================================================================
FIBRE NETWORK AUTOMATION — FULL PIPELINE
=============================================================================
File    : fibre_automation.py
Author  : JJ
Version : 1.0

WHAT THIS FILE DOES
-------------------
This is the master automation file for fibre network planning in QGIS.
Paste this into VS Code and wire each function to your plugin buttons.
It handles EVERYTHING — from raw data to a fully designed network.

CLIENT AWARENESS
----------------
Every function knows the difference between Vuma and Fibre Time.
When you hit the first button it asks which client. That choice flows
through the entire pipeline automatically.

THE FULL PIPELINE (in order)
-----------------------------
STEP 1  → create_layers()         Create all standard layers + groups + fields + symbology
STEP 2  → clean_buildings()       Clean raw building polygons → accurate house counts
STEP 3  → create_pon_boundaries() Auto-generate PON boundary polygons
STEP 4  → place_poles()           Place poles along street/road network
STEP 5  → place_nodes()           Place AGG domes + FTS (FT) / AG points (Vuma)
STEP 6  → place_dis_nodes()       Place DIS domes + STS (FT) / Pedestals (Vuma)
STEP 7  → route_distribution()    Route distribution cables pole to pole
STEP 8  → generate_drops()        Generate drop cables + assign DR numbers
STEP 9  → name_all_features()     Auto-name every feature per client convention
STEP 10 → populate_attributes()   Fill all attribute tables (counts, refs, lengths)
STEP 11 → run_qa()                QA check — flags anything missing or wrong
STEP 12 → run_full_pipeline()     Runs steps 1-11 in sequence (one button)

NAMING STANDARDS
----------------
Vuma        → AREA_ZONE_TYPE_NUMBER     e.g. WMD_201_DJ0001
Fibre Time  → AREA.TYPE.NUMBER          e.g. KYA.DIS.DM.P.C001

PON LIMITS
----------
Vuma        → max 48 SDUs per PON
Fibre Time  → 100-102 units per PON (128 physical max via FTS × STS)

FIBRE TIME SPLIT ARCHITECTURE
------------------------------
POP → Primary Feeder → AGG Dome [FTS bare, yellow] → Distribution →
DIS Dome [STS connectorised, magenta] → Drop (green) → Home
- FTS lives in AGG Dome — NO drops here
- STS lives in DIS Dome — drops connect here
- SS (spare splitter) always installed alongside FTS
- Split combos: 1:8 × 1:16 or 1:16 × 1:8 = 128 max

QGIS COLOUR STANDARDS (Fibre Time)
------------------------------------
Primary Feeder     → Blue    #0000FF  (ADSS)
Secondary Feeder   → Blue    #0000FF  (ADSS, thinner)
Distribution       → Cyan    #00FFFF  (24F Mini-ADSS)
Drop Cable         → Green   #29A500  (1F)
Micro-Blown        → Red     #FF0000  (dashed)
AGG Dome (splice)  → Blue    #0000FF  circle
DIS Dome (conn)    → Turquoise #40E0D0 circle
FTS (bare)         → Yellow  #FFFF00  triangle
STS (conn)         → Magenta #FF00FF  triangle
SS (spare)         → Yellow  #FFFF00  triangle
Progress Checker   → Yellow  #EAB308  line

HOW TO USE
----------
Option A — Wire to plugin buttons (one button per step)
Option B — Call run_full_pipeline() for the complete run
Option C — Call any individual function directly for that step only

All functions print status to the QGIS Python Console.
=============================================================================
"""

# =============================================================================
# IMPORTS
# =============================================================================

from qgis.PyQt.QtCore import QMetaType
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsField, QgsFeature, QgsGeometry,
    QgsPointXY, QgsSpatialIndex, QgsDistanceArea,
    QgsFillSymbol, QgsLineSymbol, QgsMarkerSymbol,
    QgsSingleSymbolRenderer, QgsPalLayerSettings, QgsTextFormat, QgsVectorLayerSimpleLabeling
)
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtWidgets import QMessageBox, QInputDialog
import math
import traceback

# =============================================================================
# GLOBAL STATE
# =============================================================================

# These are set once at the start and used throughout the pipeline.
# You can also set them manually if running individual steps.

CLIENT = None        # "VUMA" or "FIBRETIME" — set by ask_client()
AREA_CODE = None     # e.g. "WMD_201" or "KYA" — set by ask_area_code()
CRS = QgsProject.instance().crs().authid() or "EPSG:32735"  # uses project CRS automatically

VUMA = "VUMA"
FIBRETIME = "FIBRETIME"

# PON limits
PON_MAX = {
    VUMA: 48,
    FIBRETIME: 102
}

# =============================================================================
# SECTION 0 — CLIENT SETUP
# =============================================================================

def ask_client():
    """
    Pops a dialog: Vuma or Fibre Time?
    Sets the global CLIENT variable.
    """
    global CLIENT
    options = ["Vuma (Britelink/VTC)", "Fibre Time"]
    choice, ok = QInputDialog.getItem(
        None, "Select Client",
        "Which client is this project for?",
        options, 0, False
    )
    if not ok:
        return False
    CLIENT = VUMA if "Vuma" in choice else FIBRETIME
    label = "Vuma (Britelink/VTC)" if CLIENT == VUMA else "Fibre Time"
    print(f"  Client set: {label}")
    return True


def ask_area_code():
    """
    Asks for the area/zone code prefix.
    Vuma: WMD_201 | Fibre Time: KYA
    Sets the global AREA_CODE variable.
    """
    global AREA_CODE
    if CLIENT == VUMA:
        prompt = "Enter area/zone code (e.g. WMD_201):"
        default = "WMD_201"
    else:
        prompt = "Enter area code (e.g. KYA):"
        default = "KYA"
    code, ok = QInputDialog.getText(None, "Area Code", prompt, text=default)
    if not ok or not code.strip():
        AREA_CODE = default
    else:
        AREA_CODE = code.strip().upper()
    print(f"  Area code set: {AREA_CODE}")
    return True


def setup():
    """
    Runs client and area code dialogs.
    Call this before running any individual step.
    """
    print("\n" + "="*60)
    print("  FIBRE NETWORK AUTOMATION")
    print("="*60)
    if not ask_client():
        print("  ✗ Cancelled.")
        return False
    if not ask_area_code():
        return False
    print(f"  CRS: {CRS}")
    print()
    return True


# =============================================================================
# SECTION 1 — LAYER CREATION
# =============================================================================

def get_layer_definitions():
    """
    Returns all layer definitions for the current client.
    Each layer knows its name, geometry, fields, colour, group, and label field.
    """

    if CLIENT == VUMA:
        return [
            # BOUNDARIES
            dict(name="PON Boundaries", geometry="Polygon", group="Boundaries",
                 style="fill", color="#ec4899", opacity=0.15, label_field="pon_label",
                 fields=[
                     ("pon_id",       QMetaType.Type.QString),
                     ("pon_label",    QMetaType.Type.QString),
                     ("sdu_count",    QMetaType.Type.Int),
                     ("mdu_count",    QMetaType.Type.Int),
                     ("school_count", QMetaType.Type.Int),
                     ("ag_ref",       QMetaType.Type.QString),
                     ("notes",        QMetaType.Type.QString),
                 ]),
            dict(name="Erven", geometry="Polygon", group="Boundaries",
                 style="fill", color="#f59e0b", opacity=0.05, label_field="erf_no",
                 fields=[
                     ("erf_no",   QMetaType.Type.QString),
                     ("stand_no", QMetaType.Type.QString),
                     ("area_m2",  QMetaType.Type.Double),
                     ("zoning",   QMetaType.Type.QString),
                     ("notes",    QMetaType.Type.QString),
                 ]),
            dict(name="Buildings", geometry="Polygon", group="Boundaries",
                 style="fill", color="#94a3b8", opacity=0.4, label_field=None,
                 fields=[
                     ("unit_type",    QMetaType.Type.QString),  # SDU / MDU / shack / BY
                     ("area_m2",      QMetaType.Type.Double),
                     ("erf_ref",      QMetaType.Type.QString),
                     ("clean_status", QMetaType.Type.QString),  # clean / merged / overlap
                     ("notes",        QMetaType.Type.QString),
                 ]),
            # NODES
            dict(name="Aggregation Points (AG)", geometry="Point", group="Nodes",
                 style="marker", color="#22c55e", size=4.0, label_field="name",
                 fields=[
                     ("name",     QMetaType.Type.QString),   # WMD_Z01_AG01
                     ("area",     QMetaType.Type.QString),
                     ("zone",     QMetaType.Type.QString),
                     ("number",   QMetaType.Type.QString),
                     ("pon_ref",  QMetaType.Type.QString),
                     ("pole_ref", QMetaType.Type.QString),
                     ("notes",    QMetaType.Type.QString),
                 ]),
            dict(name="Distribution Joints (DJ)", geometry="Point", group="Nodes",
                 style="marker", color="#ef4444", size=3.5, label_field="name",
                 fields=[
                     ("name",        QMetaType.Type.QString),  # WMD_201_DJ0001
                     ("area",        QMetaType.Type.QString),
                     ("zone",        QMetaType.Type.QString),
                     ("number",      QMetaType.Type.QString),
                     ("ag_ref",      QMetaType.Type.QString),
                     ("pole_ref",    QMetaType.Type.QString),
                     ("fibre_count", QMetaType.Type.Int),
                     ("notes",       QMetaType.Type.QString),
                 ]),
            dict(name="Pedestals (P)", geometry="Point", group="Nodes",
                 style="marker", color="#ef4444", size=2.5, label_field="name",
                 fields=[
                     ("name",       QMetaType.Type.QString),  # WMD_201_P0001
                     ("area",       QMetaType.Type.QString),
                     ("zone",       QMetaType.Type.QString),
                     ("number",     QMetaType.Type.QString),
                     ("dj_ref",     QMetaType.Type.QString),
                     ("drop_count", QMetaType.Type.Int),
                     ("notes",      QMetaType.Type.QString),
                 ]),
            dict(name="Distribution Boxes (DB)", geometry="Point", group="Nodes",
                 style="marker", color="#eab308", size=2.5, label_field="name",
                 fields=[
                     ("name",   QMetaType.Type.QString),  # WMD_201_DB0001
                     ("area",   QMetaType.Type.QString),
                     ("zone",   QMetaType.Type.QString),
                     ("number", QMetaType.Type.QString),
                     ("notes",  QMetaType.Type.QString),
                 ]),
            dict(name="Manholes (MH)", geometry="Point", group="Nodes",
                 style="marker", color="#6b7280", size=3.0, label_field="name",
                 fields=[
                     ("name",     QMetaType.Type.QString),  # WMD_201_MH0001
                     ("area",     QMetaType.Type.QString),
                     ("zone",     QMetaType.Type.QString),
                     ("number",   QMetaType.Type.QString),
                     ("depth_m",  QMetaType.Type.Double),
                     ("notes",    QMetaType.Type.QString),
                 ]),
            # CABLES
            dict(name="Feeder Cable", geometry="LineString", group="Cables",
                 style="line", color="#ef4444", size=0.6, label_field="name",
                 fields=[
                     ("name",        QMetaType.Type.QString),
                     ("from_node",   QMetaType.Type.QString),
                     ("to_node",     QMetaType.Type.QString),
                     ("fibre_count", QMetaType.Type.Int),
                     ("length_m",    QMetaType.Type.Double),
                     ("cable_type",  QMetaType.Type.QString),
                     ("notes",       QMetaType.Type.QString),
                 ]),
            dict(name="Distribution Cable", geometry="LineString", group="Cables",
                 style="line", color="#ef4444", size=0.4, label_field="name",
                 fields=[
                     ("name",        QMetaType.Type.QString),
                     ("from_node",   QMetaType.Type.QString),
                     ("to_node",     QMetaType.Type.QString),
                     ("fibre_count", QMetaType.Type.Int),
                     ("length_m",    QMetaType.Type.Double),
                     ("cable_type",  QMetaType.Type.QString),
                     ("notes",       QMetaType.Type.QString),
                 ]),
            dict(name="Drop Cable", geometry="LineString", group="Cables",
                 style="line", color="#3b82f6", size=0.3, label_field=None,
                 fields=[
                     ("name",      QMetaType.Type.QString),
                     ("from_node", QMetaType.Type.QString),
                     ("to_erf",    QMetaType.Type.QString),
                     ("length_m",  QMetaType.Type.Double),
                     ("notes",     QMetaType.Type.QString),
                 ]),
            # ANNOTATION
            dict(name="Progress Checker", geometry="LineString", group="Annotation",
                 style="line", color="#eab308", size=1.5, label_field=None,
                 fields=[
                     ("checked_by", QMetaType.Type.QString),
                     ("date",       QMetaType.Type.QString),
                     ("notes",      QMetaType.Type.QString),
                 ]),
        ]

    elif CLIENT == FIBRETIME:
        return [
            # BOUNDARIES
            dict(name="PON Boundaries", geometry="Polygon", group="Boundaries",
                 style="fill", color="#a855f7", opacity=0.12, label_field="pon_id",
                 fields=[
                     ("pon_id",       QMetaType.Type.QString),  # KYA.PON.01
                     ("unit_count",   QMetaType.Type.Int),     # target 100-102
                     ("sdu_count",    QMetaType.Type.Int),
                     ("mdu_count",    QMetaType.Type.Int),
                     ("by_count",     QMetaType.Type.Int),     # backyard dwellers
                     ("school_count", QMetaType.Type.Int),
                     ("zone_ref",     QMetaType.Type.QString),
                     ("olt_port",     QMetaType.Type.QString),  # OLT.01.C1P1
                     ("fts_ref",      QMetaType.Type.QString),
                     ("notes",        QMetaType.Type.QString),
                 ]),
            dict(name="Erven", geometry="Polygon", group="Boundaries",
                 style="fill", color="#f59e0b", opacity=0.05, label_field="erf_no",
                 fields=[
                     ("erf_no",   QMetaType.Type.QString),
                     ("stand_no", QMetaType.Type.QString),
                     ("area_m2",  QMetaType.Type.Double),
                     ("zoning",   QMetaType.Type.QString),
                     ("notes",    QMetaType.Type.QString),
                 ]),
            dict(name="Buildings", geometry="Polygon", group="Boundaries",
                 style="fill", color="#94a3b8", opacity=0.4, label_field=None,
                 fields=[
                     ("unit_type",    QMetaType.Type.QString),  # SDU / MDU / shack / BY
                     ("area_m2",      QMetaType.Type.Double),
                     ("erf_ref",      QMetaType.Type.QString),
                     ("clean_status", QMetaType.Type.QString),
                     ("dr_number",    QMetaType.Type.QString),  # assigned DR number
                     ("pon_ref",      QMetaType.Type.QString),
                     ("notes",        QMetaType.Type.QString),
                 ]),
            # NODES
            dict(name="POP", geometry="Polygon", group="Nodes",
                 style="fill", color="#eab308", opacity=0.4, label_field="name",
                 fields=[
                     ("name",         QMetaType.Type.QString),  # KYA.AGG.POP.01
                     ("area",         QMetaType.Type.QString),
                     ("status",       QMetaType.Type.QString),  # Planned/In Build/Built/Commissioned
                     ("olt_name",     QMetaType.Type.QString),  # KYA.OLT.01
                     ("olt_cards",    QMetaType.Type.Int),
                     ("olt_ports",    QMetaType.Type.Int),
                     ("transmission", QMetaType.Type.QString),  # Liquid / DFA
                     ("notes",        QMetaType.Type.QString),
                 ]),
            dict(name="AGG Domes", geometry="Point", group="Nodes",
                 style="marker", color="#0000ff", size=4.0, label_field="name",
                 fields=[
                     ("name",       QMetaType.Type.QString),  # KYA.AGG.DM.P.A001
                     ("area",       QMetaType.Type.QString),
                     ("pole_ref",   QMetaType.Type.QString),  # P.A001
                     ("enclosure",  QMetaType.Type.QString),  # UMJ/CMJ/MMJ
                     ("fibre_cap",  QMetaType.Type.Int),     # 72/144/288
                     ("fts_ref",    QMetaType.Type.QString),
                     ("ss_ref",     QMetaType.Type.QString),  # spare splitter ref
                     ("notes",      QMetaType.Type.QString),
                 ]),
            dict(name="DIS Domes", geometry="Point", group="Nodes",
                 style="marker", color="#40e0d0", size=3.5, label_field="name",
                 fields=[
                     ("name",       QMetaType.Type.QString),  # KYA.DIS.DM.P.C001
                     ("area",       QMetaType.Type.QString),
                     ("pole_ref",   QMetaType.Type.QString),  # P.C001
                     ("enclosure",  QMetaType.Type.QString),  # ODCFD0/M8/M16
                     ("fibre_cap",  QMetaType.Type.Int),
                     ("sts_ref",    QMetaType.Type.QString),
                     ("drop_count", QMetaType.Type.Int),
                     ("notes",      QMetaType.Type.QString),
                 ]),
            dict(name="FTS Splitters", geometry="Point", group="Splitters",
                 style="marker", color="#ffff00", size=3.0, shape="triangle", label_field="name",
                 fields=[
                     ("name",     QMetaType.Type.QString),  # KYA.FTS.16.AGG.DM.P.A010-OLT.01.C1P1
                     ("area",     QMetaType.Type.QString),
                     ("ratio",    QMetaType.Type.QString),  # 1:8 or 1:16
                     ("agg_dome", QMetaType.Type.QString),
                     ("olt_port", QMetaType.Type.QString),  # OLT.01.C1P1
                     ("type",     QMetaType.Type.QString),  # Bare
                     ("notes",    QMetaType.Type.QString),
                 ]),
            dict(name="STS Splitters", geometry="Point", group="Splitters",
                 style="marker", color="#ff00ff", size=3.0, shape="triangle", label_field="name",
                 fields=[
                     ("name",     QMetaType.Type.QString),  # KYA.STS.8.DIS.DM.P.C001-OLT.01.C1P1.L1
                     ("area",     QMetaType.Type.QString),
                     ("ratio",    QMetaType.Type.QString),  # 1:8 or 1:16
                     ("dis_dome", QMetaType.Type.QString),
                     ("fts_ref",  QMetaType.Type.QString),
                     ("olt_port", QMetaType.Type.QString),
                     ("leg",      QMetaType.Type.QString),  # L1, L2 etc.
                     ("type",     QMetaType.Type.QString),  # Connectorised
                     ("notes",    QMetaType.Type.QString),
                 ]),
            dict(name="SS Spare Splitters", geometry="Point", group="Splitters",
                 style="marker", color="#ffff00", size=3.0, shape="triangle", label_field="name",
                 fields=[
                     ("name",     QMetaType.Type.QString),  # KYA.SS.16.AGG.DM.P.A010-OLT.01.C1P1
                     ("area",     QMetaType.Type.QString),
                     ("ratio",    QMetaType.Type.QString),
                     ("agg_dome", QMetaType.Type.QString),
                     ("olt_port", QMetaType.Type.QString),
                     ("notes",    QMetaType.Type.QString),
                 ]),
            dict(name="Poles", geometry="Point", group="Nodes",
                 style="marker", color="#a16207", size=2.5, label_field="name",
                 fields=[
                     ("name",      QMetaType.Type.QString),  # P.A001
                     ("area",      QMetaType.Type.QString),
                     ("pole_type", QMetaType.Type.QString),  # H4SANS754 etc.
                     ("height_m",  QMetaType.Type.Double),  # 5.4/6/7/9
                     ("diameter",  QMetaType.Type.QString),  # 100-120mm etc.
                     ("agg_dome",  QMetaType.Type.QString),
                     ("notes",     QMetaType.Type.QString),
                 ]),
            dict(name="Manholes", geometry="Point", group="Nodes",
                 style="marker", color="#6b7280", size=3.0, label_field="name",
                 fields=[
                     ("name",    QMetaType.Type.QString),  # KYA.MH.001
                     ("area",    QMetaType.Type.QString),
                     ("depth_m", QMetaType.Type.Double),
                     ("notes",   QMetaType.Type.QString),
                 ]),
            dict(name="Demand Points", geometry="Point", group="Nodes",
                 style="marker", color="#ef4444", size=2.0, opacity=0.7, label_field="dr_number",
                 fields=[
                     ("dr_number", QMetaType.Type.QString),  # KYA.ONT.DR000001
                     ("area",      QMetaType.Type.QString),
                     ("unit_type", QMetaType.Type.QString),  # SDU/MDU/BY
                     ("pon_ref",   QMetaType.Type.QString),
                     ("sts_ref",   QMetaType.Type.QString),
                     ("dis_dome",  QMetaType.Type.QString),
                     ("address",   QMetaType.Type.QString),
                     ("erf_no",    QMetaType.Type.QString),
                     ("notes",     QMetaType.Type.QString),
                 ]),
            # CABLES
            dict(name="Primary Feeder", geometry="LineString", group="Cables",
                 style="line", color="#0000ff", size=0.7, label_field="name",
                 fields=[
                     ("name",        QMetaType.Type.QString),  # KYA.PF.144F.AGG.POP.01-P.A001
                     ("area",        QMetaType.Type.QString),
                     ("from_node",   QMetaType.Type.QString),
                     ("to_node",     QMetaType.Type.QString),
                     ("fibre_count", QMetaType.Type.Int),   # 72/96/144/288
                     ("cable_type",  QMetaType.Type.QString),# ADSS / Mini-ADSS
                     ("length_m",    QMetaType.Type.Double),
                     ("notes",       QMetaType.Type.QString),
                 ]),
            dict(name="Secondary Feeder", geometry="LineString", group="Cables",
                 style="line", color="#0000ff", size=0.5, label_field="name",
                 fields=[
                     ("name",        QMetaType.Type.QString),  # KYA.SF.72F.P.A010-P.A025
                     ("area",        QMetaType.Type.QString),
                     ("from_node",   QMetaType.Type.QString),
                     ("to_node",     QMetaType.Type.QString),
                     ("fibre_count", QMetaType.Type.Int),
                     ("cable_type",  QMetaType.Type.QString),
                     ("length_m",    QMetaType.Type.Double),
                     ("notes",       QMetaType.Type.QString),
                 ]),
            dict(name="Distribution Cable", geometry="LineString", group="Cables",
                 style="line", color="#00ffff", size=0.4, label_field="name",
                 fields=[
                     ("name",        QMetaType.Type.QString),  # KYA.DF.24F.P.A025-P.C001
                     ("area",        QMetaType.Type.QString),
                     ("from_node",   QMetaType.Type.QString),
                     ("to_node",     QMetaType.Type.QString),
                     ("fibre_count", QMetaType.Type.Int),   # Standard = 24
                     ("cable_type",  QMetaType.Type.QString),# Mini-ADSS
                     ("length_m",    QMetaType.Type.Double),
                     ("notes",       QMetaType.Type.QString),
                 ]),
            dict(name="Drop Cable", geometry="LineString", group="Cables",
                 style="line", color="#29a500", size=0.4, label_field="name",
                 fields=[
                     ("name",      QMetaType.Type.QString),  # KYA.DR.1F.P.C001-DR000001
                     ("area",      QMetaType.Type.QString),
                     ("from_node", QMetaType.Type.QString),
                     ("dr_number", QMetaType.Type.QString),  # DR000001
                     ("ont_ref",   QMetaType.Type.QString),  # KYA.ONT.DR000001
                     ("length_m",  QMetaType.Type.Double),
                     ("unit_type", QMetaType.Type.QString),  # SDU/MDU/BY
                     ("notes",     QMetaType.Type.QString),
                 ]),
            dict(name="Micro-Blown", geometry="LineString", group="Cables",
                 style="line", color="#ff0000", size=0.6, label_field=None,
                 fields=[
                     ("name",      QMetaType.Type.QString),
                     ("from_node", QMetaType.Type.QString),
                     ("to_node",   QMetaType.Type.QString),
                     ("length_m",  QMetaType.Type.Double),
                     ("notes",     QMetaType.Type.QString),
                 ]),
            # ANNOTATION
            dict(name="Progress Checker", geometry="LineString", group="Annotation",
                 style="line", color="#eab308", size=1.5, label_field=None,
                 fields=[
                     ("checked_by", QMetaType.Type.QString),
                     ("date",       QMetaType.Type.QString),
                     ("notes",      QMetaType.Type.QString),
                 ]),
        ]


def _layer_exists(name):
    return bool(QgsProject.instance().mapLayersByName(name))


def _get_layer(name):
    layers = QgsProject.instance().mapLayersByName(name)
    return layers[0] if layers else None


def _get_or_create_group(name, parent=None):
    root = QgsProject.instance().layerTreeRoot()
    target = parent if parent else root
    existing = target.findGroup(name)
    return existing if existing else target.addGroup(name)


def _apply_symbology(layer, defn):
    style   = defn.get("style",   "marker")
    opacity = defn.get("opacity", 1.0)
    size    = defn.get("size",    0.4)
    shape   = defn.get("shape",   "circle")   # "triangle" for FTS/STS/SS

    if style == "fill":
        symbol = QgsFillSymbol.createSimple({
            "color":         defn["color"],
            "outline_color": defn["color"],
            "outline_width": "0.4",
            "style":         "solid"
        })
        symbol.setOpacity(opacity)
    elif style == "line":
        symbol = QgsLineSymbol.createSimple({
            "color":     defn["color"],
            "width":     str(size),
            "capstyle":  "round",
            "joinstyle": "round"
        })
    else:
        symbol = QgsMarkerSymbol.createSimple({
            "name":          shape,           # circle / triangle / square etc.
            "color":         defn["color"],
            "size":          str(size),
            "outline_color": "#000000",
            "outline_width": "0.2"
        })
        if opacity < 1.0:
            symbol.setOpacity(opacity)

    layer.setRenderer(QgsSingleSymbolRenderer(symbol))


def _apply_labels(layer, field_name):
    if not field_name:
        return
    settings = QgsPalLayerSettings()
    settings.fieldName = field_name
    settings.enabled = True
    tf = QgsTextFormat()
    tf.setFont(QFont("DM Sans", 7))
    tf.setSize(7)
    tf.setColor(QColor("#f0f4ff"))
    settings.setFormat(tf)
    layer.setLabelsEnabled(True)
    layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))


def create_layers():
    """
    STEP 1 — Create all standard layers for the current client.
    Groups them, applies symbology and field definitions.
    Safe to re-run — skips layers that already exist.
    """
    print("\n--- STEP 1: LAYER CREATION ---")
    definitions = get_layer_definitions()

    group_order = (
        ["Boundaries", "Nodes", "Splitters", "Cables", "Annotation"]
        if CLIENT == FIBRETIME else
        ["Boundaries", "Nodes", "Cables", "Annotation"]
    )

    client_label = "Vuma (Britelink/VTC)" if CLIENT == VUMA else "Fibre Time"
    root_group = _get_or_create_group(f"{client_label} — {AREA_CODE}")
    sub_groups = {g: _get_or_create_group(g, root_group) for g in group_order}

    created, skipped = [], []

    for defn in definitions:
        name = defn["name"]
        if _layer_exists(name):
            print(f"  ↷ Skipped: {name}")
            skipped.append(name)
            continue

        geom = defn["geometry"]
        uri = f"{geom}?crs={CRS}&index=yes"
        layer = QgsVectorLayer(uri, name, "memory")
        if not layer.isValid():
            print(f"  ✗ Failed: {name}")
            continue

        provider = layer.dataProvider()
        provider.addAttributes([QgsField(fn, ft) for fn, ft in defn["fields"]])
        layer.updateFields()
        _apply_symbology(layer, defn)
        _apply_labels(layer, defn.get("label_field"))

        QgsProject.instance().addMapLayer(layer, False)
        sub_groups.get(defn["group"], root_group).addLayer(layer)
        print(f"  ✓ Created: {name}")
        created.append(name)

    print(f"\n  Done. Created: {len(created)} | Skipped: {len(skipped)}")


# =============================================================================
# SECTION 2 — BUILDING POLYGON CLEANING
# =============================================================================

def clean_buildings():
    """
    STEP 2 — Clean raw building footprint polygons.

    What it does:
    - Removes polygons below minimum area threshold (noise/slivers)
    - Flags merged polygons (too large — likely covers multiple buildings)
    - Detects and resolves overlapping polygons
    - Tags each polygon: SDU / MDU / shack / BY based on size + shape
    - Snaps buildings to their erven boundary
    - Assigns each building to its parent erf
    - Runs iteratively until the layer is clean
    - Outputs ✓ kept / ✗ removed per feature

    Thresholds (tuned for South African residential):
    - Below 12m²  → noise, remove
    - 12–25m²     → likely shack / informal
    - 25–80m²     → SDU (standard house)
    - Above 80m²  → MDU or merged — flag for review
    - Compactness below 0.3 → irregular shape, flag
    """
    print("\n--- STEP 2: BUILDING POLYGON CLEANING ---")

    buildings = _get_layer("Buildings")
    erven = _get_layer("Erven")

    if not buildings:
        print("  ✗ No 'Buildings' layer found. Create layers first (Step 1).")
        return

    # Area thresholds in square metres
    MIN_AREA = 12        # below this = noise, remove
    SHACK_MAX = 25       # 12-25 = informal/shack
    SDU_MAX = 80         # 25-80 = SDU
    MDU_MIN = 80         # above 80 = MDU or merged, flag
    COMPACTNESS_MIN = 0.3

    dist_area = QgsDistanceArea()
    dist_area.setSourceCrs(buildings.crs(), QgsProject.instance().transformContext())
    dist_area.setEllipsoid(QgsProject.instance().ellipsoid())

    to_delete = []
    updated = {}
    kept = 0
    removed = 0
    flagged = 0

    for feature in buildings.getFeatures():
        geom = feature.geometry()
        if geom is None or geom.isEmpty():
            to_delete.append(feature.id())
            print(f"  ✗ Empty geometry: fid {feature.id()}")
            removed += 1
            continue

        area = dist_area.measureArea(geom)

        # Compactness = 4π × area / perimeter²
        perimeter = dist_area.measurePerimeter(geom)
        compactness = (4 * math.pi * area / (perimeter ** 2)) if perimeter > 0 else 0

        # Tag unit type
        if area < MIN_AREA:
            to_delete.append(feature.id())
            print(f"  ✗ Removed (too small {area:.1f}m²): fid {feature.id()}")
            removed += 1
            continue
        elif area < SHACK_MAX:
            unit_type = "shack"
        elif area < SDU_MAX:
            unit_type = "SDU"
        else:
            unit_type = "MDU"
            flagged += 1
            print(f"  ⚠ Flagged (large {area:.1f}m² — check if merged): fid {feature.id()}")

        if compactness < COMPACTNESS_MIN:
            print(f"  ⚠ Irregular shape (compactness {compactness:.2f}): fid {feature.id()}")
            flagged += 1

        updated[feature.id()] = {
            "unit_type":    unit_type,
            "area_m2":      round(area, 2),
            "clean_status": "clean"
        }
        kept += 1
        print(f"  ✓ {unit_type.upper()} ({area:.1f}m²): fid {feature.id()}")

    # Delete noise features
    buildings.dataProvider().deleteFeatures(to_delete)

    # Update attributes
    name_idx = buildings.fields().indexOf("unit_type")
    area_idx = buildings.fields().indexOf("area_m2")
    status_idx = buildings.fields().indexOf("clean_status")

    attr_map = {}
    for fid, attrs in updated.items():
        row = {}
        if name_idx >= 0:
            row[name_idx] = attrs["unit_type"]
        if area_idx >= 0:
            row[area_idx] = attrs["area_m2"]
        if status_idx >= 0:
            row[status_idx] = attrs["clean_status"]
        if row:
            attr_map[fid] = row
    # Bulk provider write (CLAUDE rule): ONE call instead of N per-feature
    # changeAttributeValue() — the per-feature loop froze the UI on a large
    # Buildings layer. Deletes above are already provider-level, so no edit
    # session is needed (start/commitChanges removed).
    if attr_map:
        buildings.dataProvider().changeAttributeValues(attr_map)
    buildings.triggerRepaint()

    print(f"\n  Done. ✓ Kept: {kept} | ✗ Removed: {removed} | ⚠ Flagged: {flagged}")
    print("  Run Step 2 again if flagged features need further splitting.")


# =============================================================================
# SECTION 3 — PON BOUNDARY CREATION
# =============================================================================

def create_pon_boundaries():
    """
    STEP 3 — Auto-generate PON boundary polygons from building centroids.

    Method: K-means style spatial grouping
    - Groups buildings into clusters respecting the PON max limit
    - Uses Voronoi polygons as starting boundaries then clips to erven
    - Labels each PON with counts
    - Assigns PON IDs using the correct naming convention per client

    PON limits:
    - Vuma       → max 48 SDUs
    - Fibre Time → 100-102 units (capped from 128 physical max)
    """
    print("\n--- STEP 3: PON BOUNDARY CREATION ---")

    buildings = _get_layer("Buildings")
    pon_layer = _get_layer("PON Boundaries")

    if not buildings or not pon_layer:
        print("  ✗ Missing 'Buildings' or 'PON Boundaries' layer. Run Step 1 first.")
        return

    max_units = PON_MAX[CLIENT]
    print(f"  PON max units: {max_units} ({CLIENT})")

    # Get all building centroids
    centroids = []
    for feat in buildings.getFeatures():
        geom = feat.geometry()
        if geom and not geom.isEmpty():
            centroid = geom.centroid().asPoint()
            unit_type = feat["unit_type"] if "unit_type" in feat.fields().names() else "SDU"
            centroids.append({"point": centroid, "unit_type": unit_type, "fid": feat.id()})

    if not centroids:
        print("  ✗ No buildings found.")
        return

    total_units = len(centroids)
    num_pons = math.ceil(total_units / max_units)
    print(f"  Total units: {total_units} → {num_pons} PONs needed")

    # Simple spatial sorting: sort by X then Y to group into rough clusters
    # For production use, replace with proper K-means via scipy if available
    centroids.sort(key=lambda c: (
        round(c["point"].x() / 100) * 100,
        c["point"].y()
    ))

    # Split into groups of max_units
    pon_groups = [centroids[i:i+max_units] for i in range(0, total_units, max_units)]

    pon_layer.startEditing()
    pon_counter = 1

    for group in pon_groups:
        if not group:
            continue

        # Build a convex hull around the group's centroids
        points = [QgsPointXY(c["point"].x(), c["point"].y()) for c in group]
        geom = QgsGeometry.fromMultiPointXY(points).convexHull()

        # Buffer slightly so the polygon covers the buildings properly
        geom = geom.buffer(30, 5)

        # Count unit types
        sdu = sum(1 for c in group if c["unit_type"] in ("SDU", "shack"))
        mdu = sum(1 for c in group if c["unit_type"] == "MDU")
        by = sum(1 for c in group if c["unit_type"] == "BY")

        # Generate PON ID per client convention
        if CLIENT == VUMA:
            pon_id = f"AG{pon_counter:02d}"
            pon_label = f"{pon_id} / {sdu} SDU / {mdu} x MDU / 0 x School"
        else:
            pon_id = f"{AREA_CODE}.PON.{pon_counter:02d}"
            pon_label = pon_id

        feat = QgsFeature(pon_layer.fields())
        feat.setGeometry(geom)
        feat["pon_id"] = pon_id
        feat["sdu_count"] = sdu
        feat["mdu_count"] = mdu

        if CLIENT == FIBRETIME:
            feat["unit_count"] = len(group)
            feat["by_count"] = by
        else:
            feat["pon_label"] = pon_label

        pon_layer.addFeature(feat)
        print(f"  ✓ PON {pon_id}: {len(group)} units (SDU:{sdu} MDU:{mdu} BY:{by})")
        pon_counter += 1

    pon_layer.commitChanges()
    pon_layer.triggerRepaint()

    # Fibre Time sizing summary
    if CLIENT == FIBRETIME:
        zones = math.ceil(num_pons / 16)
        ff = num_pons * 2
        if ff <= 48: fs = "48F"
        elif ff <= 72: fs = "72F"
        elif ff <= 96: fs = "96F"
        elif ff <= 144: fs = "144F"
        else: fs = "288F"
        print("\n  Fibre Time sizing:")
        print(f"  PONs={num_pons} → Zones={zones} → OLT ports={num_pons}")
        print(f"  Primary feeder: {num_pons}×2={ff}F → recommend {fs} ADSS")

    print(f"\n  Done. {pon_counter-1} PON boundaries created.")


# =============================================================================
# SECTION 4 — POLE PLACEMENT
# =============================================================================

def place_poles():
    """
    STEP 4 — Place poles along the road/street network.

    Logic:
    - Reads the road/street layer
    - Places poles at regular intervals along road edges
    - Default spacing: 40m (standard aerial span)
    - Names each pole per client convention
    - Fibre Time: P.A001, P.B001 etc. (letter = street/route group)
    - Vuma: no formal pole naming convention in this script

    Requires a layer named 'Roads' or 'Streets' to already exist.
    If it doesn't exist, prints a message and exits gracefully.
    """
    print("\n--- STEP 4: POLE PLACEMENT ---")

    roads = _get_layer("Roads") or _get_layer("Streets") or _get_layer("Road Network")
    poles_layer = (
        _get_layer("Poles") if CLIENT == FIBRETIME
        else _get_layer("Pedestals (P)")
    )

    if not roads:
        print("  ✗ No roads layer found. Add a layer named 'Roads' or 'Streets'.")
        print("  You can load from OpenStreetMap or your client's GIS data.")
        return

    if not poles_layer:
        print("  ✗ No poles layer found. Run Step 1 first.")
        return

    POLE_SPACING = 40  # metres between poles

    poles_layer.startEditing()
    pole_counter = 1
    route_letter = "A"
    added = 0

    for road_feat in roads.getFeatures():
        geom = road_feat.geometry()
        if geom is None or geom.isEmpty():
            continue

        length = geom.length()
        num_poles = max(2, int(length / POLE_SPACING))
        pole_counter_on_route = 1

        for i in range(num_poles):
            fraction = i / (num_poles - 1) if num_poles > 1 else 0
            point = geom.interpolate(fraction * length)

            feat = QgsFeature(poles_layer.fields())
            feat.setGeometry(point)

            if CLIENT == FIBRETIME:
                pole_name = f"P.{route_letter}{pole_counter_on_route:03d}"
                feat["name"] = pole_name
                feat["area"] = AREA_CODE
                feat["height_m"] = 6.0
                feat["pole_type"] = "H4SANS756"
            else:
                feat["name"] = f"{AREA_CODE}_P{pole_counter:04d}"
                feat["area"] = AREA_CODE

            poles_layer.addFeature(feat)
            pole_counter += 1
            pole_counter_on_route += 1
            added += 1

        # Advance route letter for next road segment
        route_letter = chr(ord(route_letter) + 1) if route_letter < "Z" else "A"

    poles_layer.commitChanges()
    poles_layer.triggerRepaint()
    print(f"  Done. ✓ {added} poles placed at {POLE_SPACING}m spacing.")


# =============================================================================
# SECTION 5 — AGG NODE PLACEMENT (FTS / AG)
# =============================================================================

def place_nodes():
    """
    STEP 5 — Place aggregation nodes.

    Fibre Time: AGG Domes + FTS Splitters + SS Spare Splitters
    - One AGG Dome per PON boundary (placed at centroid of PON area)
    - FTS (bare splitter, yellow) placed at same location
    - SS (spare splitter, yellow) placed alongside FTS — always
    - Named per Fibre Time convention

    Vuma: Aggregation Points (AG)
    - One AG per PON boundary
    - Named: AREA_ZONE_AG01 etc.
    """
    print("\n--- STEP 5: AGG NODE PLACEMENT ---")

    pon_layer = _get_layer("PON Boundaries")
    if not pon_layer:
        print("  ✗ No PON Boundaries layer. Run Step 3 first.")
        return

    if CLIENT == FIBRETIME:
        agg_layer = _get_layer("AGG Domes")
        fts_layer = _get_layer("FTS Splitters")
        ss_layer = _get_layer("SS Spare Splitters")
        if not agg_layer or not fts_layer or not ss_layer:
            print("  ✗ Missing AGG Domes / FTS / SS layers. Run Step 1 first.")
            return
    else:
        agg_layer = _get_layer("Aggregation Points (AG)")
        if not agg_layer:
            print("  ✗ Missing Aggregation Points layer. Run Step 1 first.")
            return

    olt_card = 1
    olt_port = 1
    added = 0

    # FTS split ratio — use 1:16 for lower density, 1:8 for high density.
    # Combined with STS gives 128 max, capped at 100-102 per PON.
    FTS_RATIO = 16   # change to 8 for high-density areas

    # Feeder double-up rule: (PONs × 1) × 2 → select next cable size up
    num_pons = pon_layer.featureCount()
    feeder_fibres = num_pons * 2
    if   feeder_fibres <= 48:  agg_enclosure, agg_cap = "UMJ", 72
    elif feeder_fibres <= 72:  agg_enclosure, agg_cap = "UMJ", 72
    elif feeder_fibres <= 144: agg_enclosure, agg_cap = "CMJ", 144
    else:                      agg_enclosure, agg_cap = "MMJ", 288

    # Build nearest-pole index if poles are placed already (Step 4)
    poles_layer = _get_layer("Poles")
    pole_index  = None
    pole_feats  = {}
    if poles_layer and poles_layer.featureCount() > 0:
        pole_index = QgsSpatialIndex(poles_layer.getFeatures())
        pole_feats = {f.id(): f for f in poles_layer.getFeatures()}

    if CLIENT == FIBRETIME:
        agg_layer.startEditing()
        fts_layer.startEditing()
        ss_layer.startEditing()
    else:
        agg_layer.startEditing()

    for pon_feat in pon_layer.getFeatures():
        geom = pon_feat.geometry()
        if geom is None or geom.isEmpty():
            continue

        centroid = geom.centroid()
        pon_id = pon_feat["pon_id"]

        if CLIENT == FIBRETIME:
            # Resolve nearest pole alphanum for naming (P.AXXX)
            pole_ref = "A001"
            if pole_index:
                pt = centroid.asPoint()
                nids = pole_index.nearestNeighbor(QgsPointXY(pt.x(), pt.y()), 1)
                if nids:
                    pole_name = str(pole_feats[nids[0]]["name"])  # e.g. "P.A042"
                    if "." in pole_name:
                        pole_ref = pole_name.split(".")[-1]       # "A042"

            # AGG Dome — AREA.AGG.DM.P.AXXX
            agg_name = f"{AREA_CODE}.AGG.DM.P.{pole_ref}"
            agg_feat = QgsFeature(agg_layer.fields())
            agg_feat.setGeometry(centroid)
            agg_feat["name"]      = agg_name
            agg_feat["area"]      = AREA_CODE
            agg_feat["enclosure"] = agg_enclosure   # UMJ/CMJ/MMJ by feeder size
            agg_feat["fibre_cap"] = agg_cap
            agg_layer.addFeature(agg_feat)

            olt_ref = f"OLT.01.C{olt_card}P{olt_port}"

            # FTS Splitter (bare, yellow triangle) — NO drops here
            # Format: AREA.FTS.RATIO.AGG.DM.P.AXXX-OLT.XX.C#P#
            fts_name = f"{AREA_CODE}.FTS.{FTS_RATIO}.AGG.DM.P.{pole_ref}-{olt_ref}"
            fts_feat = QgsFeature(fts_layer.fields())
            fts_feat.setGeometry(centroid)
            fts_feat["name"]     = fts_name
            fts_feat["area"]     = AREA_CODE
            fts_feat["ratio"]    = f"1:{FTS_RATIO}"
            fts_feat["agg_dome"] = agg_name
            fts_feat["olt_port"] = olt_ref
            fts_feat["type"]     = "Bare"
            fts_layer.addFeature(fts_feat)

            # SS Spare Splitter (yellow triangle) — ALWAYS at FTS location
            # Format: AREA.SS.RATIO.AGG.DM.P.AXXX-OLT.XX.C#P#
            ss_name = f"{AREA_CODE}.SS.{FTS_RATIO}.AGG.DM.P.{pole_ref}-{olt_ref}"
            ss_feat = QgsFeature(ss_layer.fields())
            ss_feat.setGeometry(centroid)
            ss_feat["name"]     = ss_name
            ss_feat["area"]     = AREA_CODE
            ss_feat["ratio"]    = f"1:{FTS_RATIO}"
            ss_feat["agg_dome"] = agg_name
            ss_feat["olt_port"] = olt_ref
            ss_layer.addFeature(ss_feat)

            print(f"  ✓ AGG Dome {agg_name} ({agg_enclosure}) + FTS + SS → {olt_ref}")

            olt_port += 1
            if olt_port > 16:
                olt_port = 1
                olt_card += 1

        else:
            # Vuma AG point
            ag_num = added + 1
            ag_name = f"{AREA_CODE}_AG{ag_num:02d}"
            ag_feat = QgsFeature(agg_layer.fields())
            ag_feat.setGeometry(centroid)
            ag_feat["name"] = ag_name
            ag_feat["area"] = AREA_CODE
            ag_feat["pon_ref"] = pon_id
            agg_layer.addFeature(ag_feat)
            print(f"  ✓ AG point: {ag_name}")

        added += 1

    if CLIENT == FIBRETIME:
        agg_layer.commitChanges()
        fts_layer.commitChanges()
        ss_layer.commitChanges()
        agg_layer.triggerRepaint()
        fts_layer.triggerRepaint()
        ss_layer.triggerRepaint()
    else:
        agg_layer.commitChanges()
        agg_layer.triggerRepaint()

    print(f"\n  Done. ✓ {added} aggregation nodes placed.")


# =============================================================================
# SECTION 6 — DIS NODE PLACEMENT (STS / Pedestals)
# =============================================================================

def place_dis_nodes():
    """
    STEP 6 — Place distribution nodes.

    Fibre Time: DIS Domes + STS Splitters
    - Groups buildings within each PON into sub-clusters of STS ratio size
    - Places DIS Dome at centroid of each sub-cluster
    - Places connectorised STS splitter at DIS Dome — drops connect here
    - Enclosure auto-selected based on drop count:
        ≤6 drops  → ODCFD0 (24F)
        ≤8 drops  → M8 (24F)
        ≤16 drops → M16 (48F)

    Vuma: Distribution Joints (DJ) and Pedestals (P)
    - DJ placed per cluster of homes
    - Pedestal placed close to home clusters
    """
    print("\n--- STEP 6: DISTRIBUTION NODE PLACEMENT ---")

    pon_layer = _get_layer("PON Boundaries")
    buildings = _get_layer("Buildings")

    if not pon_layer or not buildings:
        print("  ✗ Missing PON Boundaries or Buildings layers.")
        return

    if CLIENT == FIBRETIME:
        dis_layer = _get_layer("DIS Domes")
        sts_layer = _get_layer("STS Splitters")
        if not dis_layer or not sts_layer:
            print("  ✗ Missing DIS Domes or STS Splitters layers. Run Step 1.")
            return
    else:
        dj_layer = _get_layer("Distribution Joints (DJ)")
        ped_layer = _get_layer("Pedestals (P)")
        if not dj_layer or not ped_layer:
            print("  ✗ Missing DJ or Pedestal layers. Run Step 1.")
            return

    STS_RATIO = 8     # drops per STS (1:8 standard; change to 16 for 1:16)
    spatial_index = QgsSpatialIndex(buildings.getFeatures())

    if CLIENT == FIBRETIME:
        dis_layer.startEditing()
        sts_layer.startEditing()
    else:
        dj_layer.startEditing()
        ped_layer.startEditing()

    dis_counter = 1
    dj_counter = 1
    ped_counter = 1
    olt_card = 1
    olt_port = 1
    leg_counter = {}

    for pon_feat in pon_layer.getFeatures():
        pon_geom = pon_feat.geometry()
        pon_id = pon_feat["pon_id"]
        if not pon_geom or pon_geom.isEmpty():
            continue

        # Get buildings inside this PON
        candidates = spatial_index.intersects(pon_geom.boundingBox())
        pon_buildings = []
        for bid in candidates:
            b_feat = next(buildings.getFeatures(f"$id = {bid}"), None)
            if b_feat and pon_geom.contains(b_feat.geometry()):
                pon_buildings.append(b_feat)

        if not pon_buildings:
            continue

        # Sub-cluster into groups of STS_RATIO
        pon_buildings.sort(key=lambda f: f.geometry().centroid().asPoint().x())
        sub_clusters = [pon_buildings[i:i+STS_RATIO]
                        for i in range(0, len(pon_buildings), STS_RATIO)]

        leg_counter[pon_id] = 1

        for cluster in sub_clusters:
            points = [f.geometry().centroid().asPoint() for f in cluster]
            cx = sum(p.x() for p in points) / len(points)
            cy = sum(p.y() for p in points) / len(points)
            centroid = QgsGeometry.fromPointXY(QgsPointXY(cx, cy))
            drop_count = len(cluster)

            if CLIENT == FIBRETIME:
                # Select enclosure by drop count
                if drop_count <= 6:
                    enclosure = "ODCFD0"
                elif drop_count <= 8:
                    enclosure = "M8"
                else:
                    enclosure = "M16"

                # Format: AREA.DIS.DM.P.CXXX  (P. prefix required per naming standard)
                dis_name = f"{AREA_CODE}.DIS.DM.P.C{dis_counter:03d}"
                # FTS ref uses FTS_RATIO from place_nodes — default 16
                fts_ref  = f"{AREA_CODE}.FTS.16.AGG.DM.P."   # partial — pole ref unknown here
                olt_ref  = f"OLT.01.C{olt_card}P{olt_port}"
                leg      = f"L{leg_counter[pon_id]}"
                # Format: AREA.STS.RATIO.DIS.DM.P.CXXX-OLT.XX.C#P#.L#
                sts_name = (
                    f"{AREA_CODE}.STS.{STS_RATIO}.DIS.DM.P.C{dis_counter:03d}"
                    f"-{olt_ref}.{leg}"
                )

                # DIS Dome
                dis_feat = QgsFeature(dis_layer.fields())
                dis_feat.setGeometry(centroid)
                dis_feat["name"] = dis_name
                dis_feat["area"] = AREA_CODE
                dis_feat["enclosure"] = enclosure
                dis_feat["sts_ref"] = sts_name
                dis_feat["drop_count"] = drop_count
                dis_layer.addFeature(dis_feat)

                # STS Splitter (connectorised, magenta) — drops HERE
                sts_feat = QgsFeature(sts_layer.fields())
                sts_feat.setGeometry(centroid)
                sts_feat["name"] = sts_name
                sts_feat["area"] = AREA_CODE
                sts_feat["ratio"] = f"1:{STS_RATIO}"
                sts_feat["dis_dome"] = dis_name
                sts_feat["fts_ref"] = fts_ref
                sts_feat["olt_port"] = olt_ref
                sts_feat["leg"] = leg
                sts_feat["type"] = "Connectorised"
                sts_layer.addFeature(sts_feat)

                print(f"  ✓ DIS Dome {dis_name} ({enclosure}, {drop_count} drops)")
                dis_counter += 1
                leg_counter[pon_id] += 1
                olt_port += 1
                if olt_port > 16:
                    olt_port = 1
                    olt_card += 1

            else:
                # Vuma DJ
                dj_name = f"{AREA_CODE}_DJ{dj_counter:04d}"
                dj_feat = QgsFeature(dj_layer.fields())
                dj_feat.setGeometry(centroid)
                dj_feat["name"] = dj_name
                dj_feat["area"] = AREA_CODE
                dj_feat["drop_count"] = drop_count if "drop_count" in dj_feat.fields().names() else None
                dj_layer.addFeature(dj_feat)

                # Pedestal slightly offset from DJ
                ped_name = f"{AREA_CODE}_P{ped_counter:04d}"
                ped_geom = QgsGeometry.fromPointXY(QgsPointXY(cx + 5, cy))
                ped_feat = QgsFeature(ped_layer.fields())
                ped_feat.setGeometry(ped_geom)
                ped_feat["name"] = ped_name
                ped_feat["area"] = AREA_CODE
                ped_feat["dj_ref"] = dj_name
                ped_feat["drop_count"] = drop_count
                ped_layer.addFeature(ped_feat)

                print(f"  ✓ DJ {dj_name} + Pedestal {ped_name} ({drop_count} drops)")
                dj_counter += 1
                ped_counter += 1

    if CLIENT == FIBRETIME:
        dis_layer.commitChanges()
        sts_layer.commitChanges()
        dis_layer.triggerRepaint()
        sts_layer.triggerRepaint()
    else:
        dj_layer.commitChanges()
        ped_layer.commitChanges()
        dj_layer.triggerRepaint()
        ped_layer.triggerRepaint()

    print("\n  Done. Distribution nodes placed.")


# =============================================================================
# SECTION 7 — DISTRIBUTION CABLE ROUTING
# =============================================================================

def route_distribution():
    """
    STEP 7 — Route distribution cables between nodes.

    Fibre Time:
    - Routes distribution cable (Cyan, 24F Mini-ADSS) from each AGG Dome
      to the DIS Domes that it feeds
    - Names: AREA.DF.24F.P.AXXX-P.CXXX

    Vuma:
    - Routes distribution cable (Red) from each AG to its DJs
    - Names follow Vuma convention

    Method: Nearest-neighbour connection from AGG/AG to DIS/DJ nodes.
    For production, replace with shortest-path routing along road network.
    """
    print("\n--- STEP 7: DISTRIBUTION CABLE ROUTING ---")

    dist_layer = _get_layer("Distribution Cable")
    if not dist_layer:
        print("  ✗ No Distribution Cable layer. Run Step 1 first.")
        return

    if CLIENT == FIBRETIME:
        from_layer = _get_layer("AGG Domes")
        to_layer = _get_layer("DIS Domes")
    else:
        from_layer = _get_layer("Aggregation Points (AG)")
        to_layer = _get_layer("Distribution Joints (DJ)")

    if not from_layer or not to_layer:
        print("  ✗ Missing source or destination node layers.")
        return

    to_index = QgsSpatialIndex(to_layer.getFeatures())
    dist_layer.startEditing()
    cable_counter = 1
    added = 0

    for from_feat in from_layer.getFeatures():
        from_geom = from_feat.geometry()
        from_name = from_feat["name"]
        from_point = from_geom.asPoint()

        # Find nearest 2 DIS/DJ nodes to connect to
        nearest_ids = to_index.nearestNeighbor(from_point, 2)

        for nid in nearest_ids:
            to_feat = next(to_layer.getFeatures(f"$id = {nid}"), None)
            if not to_feat:
                continue
            to_name = to_feat["name"]
            to_point = to_feat.geometry().asPoint()

            line = QgsGeometry.fromPolylineXY([
                QgsPointXY(from_point.x(), from_point.y()),
                QgsPointXY(to_point.x(), to_point.y())
            ])
            length = line.length()

            if CLIENT == FIBRETIME:
                cable_name = f"{AREA_CODE}.DF.24F.{from_name.split('.')[-1]}-{to_name.split('.')[-1]}"
            else:
                cable_name = f"{AREA_CODE}_DIST_{cable_counter:04d}"

            feat = QgsFeature(dist_layer.fields())
            feat.setGeometry(line)
            feat["name"] = cable_name
            feat["from_node"] = from_name
            feat["to_node"] = to_name
            feat["fibre_count"] = 24
            feat["cable_type"] = "Mini-ADSS"
            feat["length_m"] = round(length, 2)
            if CLIENT == FIBRETIME:
                feat["area"] = AREA_CODE
            dist_layer.addFeature(feat)

            print(f"  ✓ Distribution cable: {from_name} → {to_name} ({length:.0f}m)")
            cable_counter += 1
            added += 1

    dist_layer.commitChanges()
    dist_layer.triggerRepaint()
    print(f"\n  Done. ✓ {added} distribution cables routed.")


# =============================================================================
# SECTION 7b — PRIMARY FEEDER ROUTING
# =============================================================================

def route_primary_feeder():
    """
    Route Primary Feeder cable (Blue ADSS) from POP to each AGG Dome.

    Fibre Time double-up rule: cable capacity = (num_agg_domes × 1) × 2,
    then select next available cable size up (48F / 72F / 96F / 144F / 288F).

    Format: AREA.PF.CAPACITY.AGG.POP.01-P.AXXX
    Colour:  Blue #0000FF (same as Secondary Feeder, Primary is thicker)
    """
    if CLIENT != FIBRETIME:
        print("  ↷ Primary Feeder routing is Fibre Time only.")
        return

    print("\n--- STEP 7b: PRIMARY FEEDER ROUTING ---")

    pop_layer  = _get_layer("POP")
    agg_layer  = _get_layer("AGG Domes")
    pf_layer   = _get_layer("Primary Feeder")

    if not pop_layer or not agg_layer or not pf_layer:
        print("  ✗ Missing POP, AGG Domes, or Primary Feeder layer. Run Steps 1 and 5 first.")
        return

    # Get POP centroid
    pop_feat = next(pop_layer.getFeatures(), None)
    if not pop_feat:
        print("  ✗ No POP feature found.")
        return
    pop_pt   = pop_feat.geometry().centroid().asPoint()
    pop_name = pop_feat["name"] if pop_feat["name"] else f"{AREA_CODE}.AGG.POP.01"

    # Double-up rule: (num_agg_domes × 1) × 2 → select cable size
    num_agg = agg_layer.featureCount()
    ff      = num_agg * 2                # minimum fibre count needed
    if   ff <= 48:  cap, ctype = "48F",  "Mini-ADSS"
    elif ff <= 72:  cap, ctype = "72F",  "ADSS"
    elif ff <= 96:  cap, ctype = "96F",  "ADSS"
    elif ff <= 144: cap, ctype = "144F", "ADSS"
    else:           cap, ctype = "288F", "ADSS"
    fibre_int = int(cap.replace("F", ""))

    print(f"  AGG Domes: {num_agg} × 2 = {ff}F → using {cap} {ctype}")

    pf_layer.startEditing()
    added = 0

    for agg_feat in agg_layer.getFeatures():
        agg_geom = agg_feat.geometry()
        agg_name = agg_feat["name"]    # e.g. KYA.AGG.DM.P.A001
        agg_pt   = agg_geom.asPoint()

        # Pole ref = last component of AGG Dome name (e.g. "A001")
        pole_ref = agg_name.split(".")[-1] if "." in agg_name else "A001"

        line   = QgsGeometry.fromPolylineXY([QgsPointXY(pop_pt.x(), pop_pt.y()),
                                              QgsPointXY(agg_pt.x(), agg_pt.y())])
        length = line.length()

        # Format: AREA.PF.CAPACITY.AGG.POP.01-P.AXXX
        cable_name = f"{AREA_CODE}.PF.{cap}.AGG.POP.01-P.{pole_ref}"

        feat = QgsFeature(pf_layer.fields())
        feat.setGeometry(line)
        feat["name"]        = cable_name
        feat["area"]        = AREA_CODE
        feat["from_node"]   = pop_name
        feat["to_node"]     = agg_name
        feat["fibre_count"] = fibre_int
        feat["cable_type"]  = ctype
        feat["length_m"]    = round(length, 2)
        pf_layer.addFeature(feat)

        print(f"  ✓ Primary Feeder: {pop_name} → {agg_name} ({cap}, {length:.0f}m)")
        added += 1

    pf_layer.commitChanges()
    pf_layer.triggerRepaint()
    print(f"\n  Done. ✓ {added} Primary Feeder cables routed ({cap} {ctype}).")


# =============================================================================
# SECTION 8 — DROP CABLE GENERATION
# =============================================================================

def generate_drops():
    """
    STEP 8 — Generate drop cables from distribution nodes to every home.

    - Connects each building centroid to its nearest DIS Dome (FT) or Pedestal (Vuma)
    - Creates a Drop Cable line feature for each home
    - Fibre Time: assigns DR number (DR000001, DR000002...)
    - Fibre Time: names cable KYA.DR.1F.P.CXXX-DR000001
    - Fibre Time: creates Demand Point at each home location
    - Vuma: names drop per Vuma convention
    - Updates the building attribute with its assigned DR number and DIS Dome ref
    """
    print("\n--- STEP 8: DROP CABLE GENERATION ---")

    buildings = _get_layer("Buildings")
    drop_layer = _get_layer("Drop Cable")

    if not buildings or not drop_layer:
        print("  ✗ Missing Buildings or Drop Cable layer.")
        return

    if CLIENT == FIBRETIME:
        dis_layer = _get_layer("DIS Domes")
        demand_layer = _get_layer("Demand Points")
        if not dis_layer or not demand_layer:
            print("  ✗ Missing DIS Domes or Demand Points layer.")
            return
        node_layer = dis_layer
    else:
        node_layer = _get_layer("Pedestals (P)")
        if not node_layer:
            print("  ✗ Missing Pedestals layer.")
            return

    node_index = QgsSpatialIndex(node_layer.getFeatures())

    drop_layer.startEditing()
    buildings.startEditing()
    if CLIENT == FIBRETIME:
        demand_layer.startEditing()

    dr_counter = 1
    drop_counter = 1
    added = 0

    for building in buildings.getFeatures():
        b_geom = building.geometry()
        if not b_geom or b_geom.isEmpty():
            continue

        b_point = b_geom.centroid().asPoint()
        nearest = node_index.nearestNeighbor(b_point, 1)
        if not nearest:
            continue

        node_feat = next(node_layer.getFeatures(f"$id = {nearest[0]}"), None)
        if not node_feat:
            continue

        node_name = node_feat["name"]
        node_point = node_feat.geometry().asPoint()

        line = QgsGeometry.fromPolylineXY([
            QgsPointXY(b_point.x(), b_point.y()),
            QgsPointXY(node_point.x(), node_point.y())
        ])
        length = line.length()

        if CLIENT == FIBRETIME:
            dr_number = f"DR{dr_counter:06d}"
            ont_ref   = f"{AREA_CODE}.ONT.{dr_number}"
            # Format: AREA.DR.1F.P.CXXX-DRXXXXXX
            # node_name is e.g. "KYA.DIS.DM.P.C001" → extract "C001" → prepend "P."
            _node_suffix = node_name.split(".")[-1]   # "C001"
            cable_name = f"{AREA_CODE}.DR.1F.P.{_node_suffix}-{dr_number}"
            unit_type = building["unit_type"] if "unit_type" in building.fields().names() else "SDU"
        else:
            dr_number = f"{AREA_CODE}_DROP{drop_counter:04d}"
            cable_name = dr_number
            ont_ref = ""
            unit_type = "SDU"

        # Drop cable
        drop_feat = QgsFeature(drop_layer.fields())
        drop_feat.setGeometry(line)
        drop_feat["name"] = cable_name
        drop_feat["from_node"] = node_name
        drop_feat["length_m"] = round(length, 2)
        if CLIENT == FIBRETIME:
            drop_feat["dr_number"] = dr_number
            drop_feat["ont_ref"] = ont_ref
            drop_feat["unit_type"] = unit_type
            drop_feat["area"] = AREA_CODE
        else:
            drop_feat["to_erf"] = (
                building["erf_ref"]
                if "erf_ref" in building.fields().names() else ""
            )
        drop_layer.addFeature(drop_feat)

        # Update building with DR number and node ref
        if CLIENT == FIBRETIME:
            dr_idx = buildings.fields().indexOf("dr_number")
            dis_idx = buildings.fields().indexOf("dis_dome") if "dis_dome" in buildings.fields().names() else -1
            if dr_idx >= 0:
                buildings.changeAttributeValue(building.id(), dr_idx, dr_number)
            if dis_idx >= 0:
                buildings.changeAttributeValue(building.id(), dis_idx, node_name)

            # Demand Point at building centroid
            dp_feat = QgsFeature(demand_layer.fields())
            dp_feat.setGeometry(QgsGeometry.fromPointXY(b_point))
            dp_feat["dr_number"] = ont_ref
            dp_feat["area"] = AREA_CODE
            dp_feat["unit_type"] = unit_type
            dp_feat["dis_dome"] = node_name
            dp_feat["sts_ref"] = node_feat["sts_ref"] if "sts_ref" in node_feat.fields().names() else ""
            demand_layer.addFeature(dp_feat)

            print(f"  ✓ Drop {dr_number} → {node_name} ({length:.0f}m) [{unit_type}]")
            dr_counter += 1
        else:
            print(f"  ✓ Drop {drop_counter} → {node_name} ({length:.0f}m)")
            drop_counter += 1

        added += 1

    drop_layer.commitChanges()
    buildings.commitChanges()
    if CLIENT == FIBRETIME:
        demand_layer.commitChanges()
        demand_layer.triggerRepaint()
    drop_layer.triggerRepaint()
    buildings.triggerRepaint()

    print(f"\n  Done. ✓ {added} drop cables generated.")


# =============================================================================
# SECTION 9 — AUTO-NAMING ALL FEATURES
# =============================================================================

def name_all_features():
    """
    STEP 9 — Ensure every feature has a correctly formatted name.

    Scans all node and cable layers and fills in any blank name fields
    using the correct convention for the current client.

    Vuma:    AREA_ZONE_TYPE_NUMBER  (e.g. WMD_201_DJ0001)
    Fibre Time: AREA.TYPE.NUMBER   (e.g. KYA.DIS.DM.P.C001)

    This step is safe to run at any time — it only fills blank names,
    it never overwrites an existing name.
    """
    print("\n--- STEP 9: AUTO-NAMING ---")

    if CLIENT == VUMA:
        targets = [
            ("Aggregation Points (AG)", "AG",  "AG",  4),
            ("Distribution Joints (DJ)", "DJ",  "DJ",  4),
            ("Pedestals (P)",            "P",   "P",   4),
            ("Distribution Boxes (DB)",  "DB",  "DB",  4),
            ("Manholes (MH)",            "MH",  "MH",  4),
        ]
        sep = "_"
    else:
        targets = [
            ("Poles",        "POL", "P.A",  3),
            ("AGG Domes",    "AGG", "AGG.DM.P.A", 3),
            ("DIS Domes",    "DIS", "DIS.DM.P.C", 3),
            ("Manholes",     "MH",  "MH",   3),
        ]
        sep = "."

    total_named = 0

    for layer_name, short_type, prefix, pad in targets:
        layer = _get_layer(layer_name)
        if not layer:
            continue

        name_idx = layer.fields().indexOf("name")
        if name_idx < 0:
            continue

        layer.startEditing()
        counter = 1

        for feat in layer.getFeatures():
            existing = feat["name"]
            if existing and str(existing).strip():
                continue  # already named — never overwrite

            if CLIENT == VUMA:
                new_name = f"{AREA_CODE}_{prefix}{counter:0{pad}d}"
            else:
                new_name = f"{AREA_CODE}.{prefix}{counter:0{pad}d}"

            layer.changeAttributeValue(feat.id(), name_idx, new_name)
            print(f"  ✓ Named: {new_name}")
            counter += 1
            total_named += 1

        layer.commitChanges()

    print(f"\n  Done. ✓ {total_named} features named.")


# =============================================================================
# SECTION 10 — ATTRIBUTE TABLE POPULATION
# =============================================================================

def populate_attributes():
    """
    STEP 10 — Fill all remaining attribute fields across all layers.

    - Calculates and stores cable lengths
    - Updates PON boundary unit counts from buildings within them
    - Updates drop counts on DIS Domes / Pedestals
    - Updates OLT port counts on POP layer (Fibre Time)
    - Recalculates all area_m2 fields on polygon layers
    - Links nodes to their parent PON IDs
    """
    print("\n--- STEP 10: ATTRIBUTE TABLE POPULATION ---")

    dist_area = QgsDistanceArea()
    dist_area.setEllipsoid(QgsProject.instance().ellipsoid())

    updated_total = 0

    # Update cable lengths
    cable_layers = ["Drop Cable", "Distribution Cable", "Feeder Cable",
                    "Primary Feeder", "Secondary Feeder"]
    for lname in cable_layers:
        layer = _get_layer(lname)
        if not layer:
            continue
        length_idx = layer.fields().indexOf("length_m")
        if length_idx < 0:
            continue
        layer.startEditing()
        for feat in layer.getFeatures():
            if feat.geometry() and not feat.geometry().isEmpty():
                length = feat.geometry().length()
                layer.changeAttributeValue(feat.id(), length_idx, round(length, 2))
                updated_total += 1
        layer.commitChanges()
        print(f"  ✓ Lengths updated: {lname}")

    # Update building area_m2 values
    buildings = _get_layer("Buildings")
    if buildings:
        area_idx = buildings.fields().indexOf("area_m2")
        if area_idx >= 0:
            buildings.startEditing()
            for feat in buildings.getFeatures():
                if feat.geometry() and not feat.geometry().isEmpty():
                    area = dist_area.measureArea(feat.geometry())
                    buildings.changeAttributeValue(feat.id(), area_idx, round(area, 2))
                    updated_total += 1
            buildings.commitChanges()
            print("  ✓ Building areas updated.")

    # Update PON unit counts from buildings inside each PON
    pon_layer = _get_layer("PON Boundaries")
    if pon_layer and buildings:
        b_index = QgsSpatialIndex(buildings.getFeatures())
        sdu_idx = pon_layer.fields().indexOf("sdu_count")
        mdu_idx = pon_layer.fields().indexOf("mdu_count")
        unit_idx = pon_layer.fields().indexOf("unit_count") if CLIENT == FIBRETIME else -1
        by_idx = pon_layer.fields().indexOf("by_count") if CLIENT == FIBRETIME else -1

        pon_layer.startEditing()
        for pon_feat in pon_layer.getFeatures():
            pon_geom = pon_feat.geometry()
            if not pon_geom:
                continue
            candidates = b_index.intersects(pon_geom.boundingBox())
            sdu = mdu = by = 0
            for bid in candidates:
                b = next(buildings.getFeatures(f"$id = {bid}"), None)
                if b and pon_geom.contains(b.geometry()):
                    ut = b["unit_type"] if "unit_type" in b.fields().names() else "SDU"
                    if ut in ("SDU", "shack"): sdu += 1
                    elif ut == "MDU": mdu += 1
                    elif ut == "BY": by += 1

            if sdu_idx >= 0: pon_layer.changeAttributeValue(pon_feat.id(), sdu_idx, sdu)
            if mdu_idx >= 0: pon_layer.changeAttributeValue(pon_feat.id(), mdu_idx, mdu)
            if unit_idx >= 0: pon_layer.changeAttributeValue(pon_feat.id(), unit_idx, sdu+mdu+by)
            if by_idx >= 0: pon_layer.changeAttributeValue(pon_feat.id(), by_idx, by)
            updated_total += 1

        pon_layer.commitChanges()
        print("  ✓ PON unit counts updated from buildings.")

    # Update Vuma pon_label field
    if CLIENT == VUMA and pon_layer:
        label_idx = pon_layer.fields().indexOf("pon_label")
        id_idx = pon_layer.fields().indexOf("pon_id")
        sdu_idx = pon_layer.fields().indexOf("sdu_count")
        mdu_idx = pon_layer.fields().indexOf("mdu_count")
        school_idx = pon_layer.fields().indexOf("school_count")

        if label_idx >= 0:
            pon_layer.startEditing()
            for feat in pon_layer.getFeatures():
                pon_id = feat["pon_id"] or "?"
                sdu = feat["sdu_count"] or 0
                mdu = feat["mdu_count"] or 0
                school = feat["school_count"] or 0
                label = f"{pon_id} / {sdu} SDU / {mdu} x MDU / {school} x School"
                pon_layer.changeAttributeValue(feat.id(), label_idx, label)
            pon_layer.commitChanges()
            print("  ✓ Vuma PON labels updated.")

    print(f"\n  Done. ✓ {updated_total} attribute values updated.")


# =============================================================================
# SECTION 11 — QA CHECK
# =============================================================================

def run_qa():
    """
    STEP 11 — Quality assurance check across all layers.

    Checks:
    - Every home/building has a drop cable assigned
    - No PON exceeds the max unit count
    - Every named feature follows the correct naming convention
    - No duplicate names exist in any layer
    - All cable lengths are populated
    - Fibre Time: every FTS location has an SS (spare splitter)
    - Fibre Time: no drops connected directly to AGG Dome (only DIS Dome)
    - Fibre Time: all DR numbers are sequential with no gaps
    - CRS is consistent across all layers

    Outputs a pass/fail summary with counts of issues found.
    """
    print("\n--- STEP 11: QA CHECK ---")
    issues = []
    warnings = []

    # Check CRS consistency
    project_crs = QgsProject.instance().crs().authid()
    for layer in QgsProject.instance().mapLayers().values():
        if isinstance(layer, QgsVectorLayer):
            if layer.crs().authid() != project_crs and layer.crs().authid() != CRS:
                warnings.append(f"CRS mismatch: '{layer.name()}' is {layer.crs().authid()}")

    # Check PON limits
    pon_layer = _get_layer("PON Boundaries")
    max_units = PON_MAX[CLIENT]
    if pon_layer:
        count_field = "unit_count" if CLIENT == FIBRETIME else "sdu_count"
        count_idx = pon_layer.fields().indexOf(count_field)
        if count_idx >= 0:
            for feat in pon_layer.getFeatures():
                count = feat[count_field] or 0
                if count > max_units:
                    issues.append(
                        f"PON {feat['pon_id']} has {count} units "
                        f"(max {max_units} for {CLIENT})"
                    )

    # Check all buildings have a drop
    buildings = _get_layer("Buildings")
    drop_layer = _get_layer("Drop Cable")
    if buildings and drop_layer:
        drop_index = QgsSpatialIndex(drop_layer.getFeatures())
        for feat in buildings.getFeatures():
            if feat.geometry():
                b_point = feat.geometry().centroid().asPoint()
                near = drop_index.nearestNeighbor(b_point, 1)
                if not near:
                    issues.append(f"Building fid {feat.id()} has no drop cable assigned.")

    # Check for duplicate names
    name_layers = [
        "Aggregation Points (AG)", "Distribution Joints (DJ)", "Pedestals (P)",
        "AGG Domes", "DIS Domes", "FTS Splitters", "STS Splitters",
        "Drop Cable", "Distribution Cable", "Poles"
    ]
    for lname in name_layers:
        layer = _get_layer(lname)
        if not layer:
            continue
        name_idx = layer.fields().indexOf("name")
        if name_idx < 0:
            continue
        seen = {}
        for feat in layer.getFeatures():
            n = feat["name"]
            if not n or not str(n).strip():
                issues.append(f"Unnamed feature in '{lname}' fid {feat.id()}")
                continue
            if n in seen:
                issues.append(f"Duplicate name '{n}' in '{lname}'")
            seen[n] = True

    # Fibre Time: check every AGG Dome has a paired SS
    if CLIENT == FIBRETIME:
        agg_layer = _get_layer("AGG Domes")
        ss_layer = _get_layer("SS Spare Splitters")
        if agg_layer and ss_layer:
            agg_count = agg_layer.featureCount()
            ss_count = ss_layer.featureCount()
            if ss_count < agg_count:
                issues.append(
                    f"Only {ss_count} SS splitters for {agg_count} AGG Domes. "
                    f"Every FTS location must have a Spare Splitter."
                )

        # Check DR number sequence
        dp_layer = _get_layer("Demand Points")
        if dp_layer:
            dr_numbers = []
            for feat in dp_layer.getFeatures():
                dr = feat["dr_number"]
                if dr:
                    import re
                    match = re.search(r'DR(\d+)', str(dr))
                    if match:
                        dr_numbers.append(int(match.group(1)))
            if dr_numbers:
                dr_numbers.sort()
                for i, n in enumerate(dr_numbers):
                    expected = i + 1
                    if n != expected:
                        issues.append(
                            f"DR number gap: expected DR{expected:06d}, found DR{n:06d}"
                        )
                        break

    # Check cable lengths populated
    for lname in ["Drop Cable", "Distribution Cable", "Primary Feeder", "Feeder Cable"]:
        layer = _get_layer(lname)
        if not layer:
            continue
        length_idx = layer.fields().indexOf("length_m")
        if length_idx < 0:
            continue
        for feat in layer.getFeatures():
            if feat["length_m"] is None or feat["length_m"] == 0:
                warnings.append(f"Zero/null length on '{lname}' fid {feat.id()}")

    # Print results
    print()
    if not issues and not warnings:
        print("  ✅ ALL CHECKS PASSED — network is clean and ready.")
    else:
        if issues:
            print(f"  ✗ {len(issues)} ISSUE(S) FOUND:")
            for i in issues:
                print(f"    ✗ {i}")
        if warnings:
            print(f"\n  ⚠ {len(warnings)} WARNING(S):")
            for w in warnings:
                print(f"    ⚠ {w}")

    print(f"\n  QA Summary: {len(issues)} issues | {len(warnings)} warnings")
    print("="*60)

    if issues:
        QMessageBox.warning(None, "QA Failed",
            f"{len(issues)} issue(s) found.\nCheck the Python Console for details.")
    else:
        QMessageBox.information(None, "QA Passed",
            f"✅ All checks passed.\n{len(warnings)} warning(s) — see console.")


# =============================================================================
# MASTER PIPELINE
# =============================================================================

def run_full_pipeline():
    """
    Runs the complete pipeline from Step 1 to Step 11 in one go.
    Ask client + area code once at the start, then fully automated.

    Wire this to your "Run Full Pipeline" plugin button.
    """
    print("\n" + "="*60)
    print("  FIBRE NETWORK AUTOMATION — FULL PIPELINE")
    print("="*60)

    if not setup():
        return

    steps = [
        ("1 — Layer Creation",             create_layers),
        ("2 — Building Polygon Cleaning",  clean_buildings),
        ("3 — PON Boundary Creation",      create_pon_boundaries),
        ("4 — Pole Placement",             place_poles),
        ("5 — AGG Node Placement",         place_nodes),
        ("6 — DIS Node Placement",         place_dis_nodes),
        ("7 — Distribution Cable Routing", route_distribution),
        ("7b — Primary Feeder Routing",    route_primary_feeder),
        ("8 — Drop Cable Generation",      generate_drops),
        ("9 — Auto-Naming",                name_all_features),
        ("10 — Attribute Population",      populate_attributes),
        ("11 — QA Check",                  run_qa),
    ]

    for label, func in steps:
        print(f"\n{'='*60}")
        print(f"  RUNNING STEP {label}")
        print(f"{'='*60}")
        try:
            func()
        except Exception as e:
            print(f"\n  ✗ ERROR in Step {label}:")
            print(traceback.format_exc())
            result = QMessageBox.question(
                None, "Step Failed",
                f"Step {label} failed:\n{e}\n\nContinue to next step?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if result == QMessageBox.StandardButton.No:
                print("  Pipeline stopped by user.")
                return

    print("\n" + "="*60)
    print("  ✅ FULL PIPELINE COMPLETE")
    client_label = "Vuma (Britelink/VTC)" if CLIENT == VUMA else "Fibre Time"
    print(f"  Client: {client_label} | Area: {AREA_CODE}")
    print("="*60 + "\n")

    QMessageBox.information(None, "Pipeline Complete",
        f"✅ Full pipeline complete!\n\n"
        f"Client : {client_label}\n"
        f"Area   : {AREA_CODE}\n\n"
        f"Run Step 11 (QA Check) again any time to verify the network.")


# =============================================================================
# ENTRY POINT
# =============================================================================
# Wire to your plugin buttons like this:
#
#   btn_full_pipeline.clicked.connect(run_full_pipeline)
#   btn_create_layers.clicked.connect(lambda: (setup() and create_layers()))
#   btn_clean.clicked.connect(lambda: (setup() and clean_buildings()))
#   btn_pon.clicked.connect(lambda: (setup() and create_pon_boundaries()))
#   btn_poles.clicked.connect(lambda: (setup() and place_poles()))
#   btn_nodes.clicked.connect(lambda: (setup() and place_nodes()))
#   btn_dis.clicked.connect(lambda: (setup() and place_dis_nodes()))
#   btn_dist.clicked.connect(lambda: (setup() and route_distribution()))
#   btn_drops.clicked.connect(lambda: (setup() and generate_drops()))
#   btn_name.clicked.connect(lambda: (setup() and name_all_features()))
#   btn_attrs.clicked.connect(lambda: (setup() and populate_attributes()))
#   btn_qa.clicked.connect(lambda: (setup() and run_qa()))
#
# Or run directly from QGIS Python Console:
#   run_full_pipeline()

if __name__ == "__main__":
    run_full_pipeline()
