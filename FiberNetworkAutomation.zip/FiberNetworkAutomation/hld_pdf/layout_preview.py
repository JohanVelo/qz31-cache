# -*- coding: utf-8 -*-
"""Show-before-you-build for the HLD Map Book dialog (JJ 2026-11-12).

Three pieces, all pure Qt, no project access:

* MODEL_INFO   - one plain-language card per layout model: page size, what each page
                 shows, where the legend / north arrow / logo sit, what it is for.
* LayoutSketch - a live drawing of the book the current choices will produce: page 1
                 (overview) and a detail page, at the model's real page shape, with the
                 sidebar / bottom strip / title bar where the engine puts them.
* HoverPicture - a small example picture (a real render of that model) that opens a big
                 copy beside the cursor while the mouse is over it.

Example pictures live in assets/previews/<model id>.png. A model without one shows only
the sketch, never a broken image.
"""
import os

from qgis.PyQt.QtCore import Qt, QRectF, QPointF
from qgis.PyQt.QtGui import QColor, QPainter, QPen, QBrush, QFont, QPixmap, QCursor
from qgis.PyQt.QtWidgets import QLabel, QWidget, QSizePolicy

_HERE = os.path.dirname(os.path.abspath(__file__))
PREVIEW_DIR = os.path.join(_HERE, "assets", "previews")

# frame kinds the sketch knows how to draw
SIDEBAR, STRIP, BOOK, ASBUILT = "sidebar", "strip", "book", "asbuilt"

MODEL_INFO = {
    "hld_atlas": {
        "frame": SIDEBAR, "page": "A3 landscape",
        "summary": "The standard network HLD.",
        "pages": "Page 1 is the whole area. Then one page per grid block (or per PON).",
        "layout": "Map on the left. Sidebar on the right: legend, project totals, scale, "
                  "north arrow, logo, title block. Page number in the title bar.",
        "for": "Client HLD hand-over and internal review.",
    },
    "ftts": {
        "frame": SIDEBAR, "page": "A3 landscape",
        "summary": "Grid book in cable-route order.",
        "pages": "Page 1 is the numbered grid. Then one page per 775 x 550 m block, numbered "
                 "along the route.",
        "layout": "Same sidebar as the HLD atlas, without the totals box. Erf numbers off on "
                  "the overview.",
        "for": "Field teams following the route block by block.",
    },
    "wayleave": {
        "frame": STRIP, "page": "A4 landscape",
        "summary": "Municipal wayleave application.",
        "pages": "Page 1 is the whole route over the numbered grid. Then one page per "
                 "775 x 550 m block.",
        "layout": "Full-page map. Bottom strip: project description, legend, page number, "
                  "north arrow, date and logo. Street names and erf numbers on.",
        "for": "Submitting to the municipality.",
    },
    "commercial_grid": {
        "frame": SIDEBAR, "page": "A3 landscape",
        "summary": "Commercial zoning drawing with HP / erf counts.",
        "pages": "Page 1 is the plotting grid. Then one page per grid block.",
        "layout": "Sidebar with zoning legend and the count tables you type in.",
        "for": "Commercial take-off. Needs the zoning layers in the project.",
    },
    "hld_book_pages": {
        "frame": BOOK, "page": "A3 landscape",
        "summary": "A book where you pick every page.",
        "pages": "Default: area, PON zones, FTS splitters, feeders - then one page per PON. "
                 "Change it with Edit pages.",
        "layout": "HLD sidebar on every page, its own layers per page.",
        "for": "Presentations and custom hand-overs.",
    },
    "hld_asbuilt": {
        "frame": ASBUILT, "page": "A4 landscape",
        "summary": "As-Built book.",
        "pages": "Overview pages, then one page per PON with readable labels.",
        "layout": "Full-width map, bottom title band with the as-built facts and logo.",
        "for": "Close-out / as-built submission.",
    },
}


def info(model_id):
    return MODEL_INFO.get(model_id or "", MODEL_INFO["hld_atlas"])


def preview_path(model_id):
    for ext in ("jpg", "png"):
        pth = os.path.join(PREVIEW_DIR, "%s.%s" % (model_id or "", ext))
        if os.path.exists(pth):
            return pth
    return None


def tooltip_html(model_id, width=560):
    """Rich tooltip for a model in the drop-down: the card, plus the example picture."""
    i = info(model_id)
    img = preview_path(model_id)
    pic = ("<br><img src='file:///%s' width='%d'>" % (img.replace("\\", "/"), width)) if img else ""
    return ("<b>%s</b> - %s<br>%s<br><i>%s</i>%s"
            % (i["page"], i["summary"], i["pages"], i["layout"], pic))


def card_html(model_id):
    i = info(model_id)
    return ("<b>%s</b> &nbsp;·&nbsp; %s<br>"
            "<b>Pages:</b> %s<br><b>Layout:</b> %s<br><b>Use it for:</b> %s"
            % (i["page"], i["summary"], i["pages"], i["layout"], i["for"]))


class HoverPicture(QLabel):
    """A small picture that shows a big copy next to the cursor while hovered."""

    def __init__(self, parent=None, small_w=300, big_w=900):
        super().__init__(parent)
        self._small_w = small_w
        self._big_w = big_w
        self._pix = None
        self._pop = None
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)

    def set_image(self, path):
        self._pix = QPixmap(path) if path and os.path.exists(path) else None
        if self._pix is None or self._pix.isNull():
            self._pix = None
            self.clear()
            self.setVisible(False)
            return
        self.setPixmap(self._pix.scaledToWidth(self._small_w,
                                               Qt.TransformationMode.SmoothTransformation))
        self.setToolTip("")
        self.setVisible(True)

    def enterEvent(self, ev):
        if self._pix is None:
            return
        if self._pop is None:
            self._pop = QLabel(None, Qt.WindowType.ToolTip | Qt.WindowType.WindowTransparentForInput)
            self._pop.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
            self._pop.setStyleSheet("background:#ffffff;border:2px solid #444;")
        big = self._pix.scaledToWidth(self._big_w, Qt.TransformationMode.SmoothTransformation)
        self._pop.setPixmap(big)
        self._pop.resize(big.size())
        pos = QCursor.pos()
        scr = self.screen().availableGeometry() if self.screen() else None
        x, y = pos.x() + 24, pos.y() - big.height() // 2
        if scr is not None:
            x = min(x, scr.right() - big.width() - 8)
            if x < scr.left():
                x = scr.left() + 8
            y = max(scr.top() + 8, min(y, scr.bottom() - big.height() - 8))
        self._pop.move(x, y)
        self._pop.show()

    def leaveEvent(self, ev):
        if self._pop is not None:
            self._pop.hide()

    def hideEvent(self, ev):
        if self._pop is not None:
            self._pop.hide()
        super().hideEvent(ev)


class LayoutSketch(QWidget):
    """Draws page 1 + a detail page for the current choices. `big` hover-enlarges."""

    def __init__(self, parent=None, height=170):
        super().__init__(parent)
        self._h = height
        self._model = "hld_atlas"
        self._cover = "grid"         # "grid" | "pon" | "phase"
        self._pages = None
        self._title = ""
        self._aoi = True
        self._pop = None
        self.setMinimumHeight(height)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setToolTip("")

    def update_state(self, model=None, cover=None, pages=None, title=None, aoi=None):
        if model is not None:
            self._model = model
        if cover is not None:
            self._cover = cover
        self._pages = pages
        if title is not None:
            self._title = title
        if aoi is not None:
            self._aoi = aoi
        self.update()
        if self._pop is not None and self._pop.isVisible():
            self._pop.update_state(self._model, self._cover, self._pages, self._title, self._aoi)

    def sizeHint(self):
        from qgis.PyQt.QtCore import QSize
        return QSize(520, self._h)

    # hover: a big copy of the same drawing
    def enterEvent(self, ev):
        if self._h >= 400:
            return
        if self._pop is None:
            self._pop = LayoutSketch(None, height=460)
            self._pop.setWindowFlags(Qt.WindowType.ToolTip | Qt.WindowType.WindowTransparentForInput)
            self._pop.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
            self._pop.resize(1000, 460)
        self._pop.update_state(self._model, self._cover, self._pages, self._title, self._aoi)
        pos = QCursor.pos()
        scr = self.screen().availableGeometry() if self.screen() else None
        x, y = pos.x() + 24, pos.y() - 230
        if scr is not None:
            x = max(scr.left() + 8, min(x, scr.right() - 1008))
            y = max(scr.top() + 8, min(y, scr.bottom() - 468))
        self._pop.move(x, y)
        self._pop.show()

    def leaveEvent(self, ev):
        if self._pop is not None:
            self._pop.hide()

    def hideEvent(self, ev):
        if self._pop is not None:
            self._pop.hide()
        super().hideEvent(ev)

    # ── drawing ──
    def paintEvent(self, ev):
        qp = QPainter(self)
        try:
            qp.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            qp.fillRect(self.rect(), QColor(250, 250, 250))
            i = info(self._model)
            a4 = "A4" in i["page"]
            aspect = 297.0 / 210.0       # A3 and A4 landscape share the ISO ratio
            pad = 10.0
            caption_h = 34.0
            avail_h = self.height() - 2 * pad - caption_h
            gap = 18.0
            page_w = min((self.width() - 2 * pad - gap) / 2.0, avail_h * aspect)
            page_h = page_w / aspect
            x0 = (self.width() - (2 * page_w + gap)) / 2.0
            y0 = pad
            ov = QRectF(x0, y0, page_w, page_h)
            det = QRectF(x0 + page_w + gap, y0, page_w, page_h)
            self._page(qp, ov, i["frame"], overview=True)
            self._page(qp, det, i["frame"], overview=False)
            f = QFont(); f.setPointSizeF(max(7.0, self._h / 26.0)); f.setBold(True)
            qp.setFont(f); qp.setPen(QColor(40, 40, 40))
            qp.drawText(QRectF(ov.left(), ov.bottom() + 3, page_w, 16),
                        Qt.AlignmentFlag.AlignCenter, "Page 1 - overview")
            n = self._pages
            lab = ("Pages 2 to %d - one per %s" % (n + 1, self._unit())) if n else \
                  ("Page 2 onward - one per %s" % self._unit())
            qp.drawText(QRectF(det.left(), det.bottom() + 3, page_w, 16),
                        Qt.AlignmentFlag.AlignCenter, lab)
            f.setBold(False); f.setPointSizeF(max(6.5, self._h / 30.0)); qp.setFont(f)
            qp.setPen(QColor(90, 90, 90))
            qp.drawText(QRectF(0, ov.bottom() + 18, self.width(), 16), Qt.AlignmentFlag.AlignCenter,
                        "%s · %s%s" % (i["page"], i["summary"],
                                       "" if a4 or True else ""))
        finally:
            qp.end()

    def _unit(self):
        return {"grid": "grid block", "pon": "PON", "phase": "PON (one book per phase)"}.get(
            self._cover, "page")

    def _page(self, qp, r, frame, overview):
        qp.setPen(QPen(QColor(60, 60, 60), 1.2))
        qp.setBrush(QBrush(QColor(255, 255, 255)))
        qp.drawRect(r)
        m = r.adjusted(r.width() * 0.015, r.height() * 0.02, -r.width() * 0.015, -r.height() * 0.02)
        if frame in (SIDEBAR, BOOK):
            side = QRectF(m.right() - m.width() * 0.2, m.top(), m.width() * 0.2, m.height())
            title = QRectF(m.left(), m.top(), m.width() - side.width() - 3, m.height() * 0.08)
            mapr = QRectF(m.left(), title.bottom() + 2, title.width(), m.bottom() - title.bottom() - 2)
            self._map(qp, mapr, overview)
            self._box(qp, title, "Page title / page N of M" if not overview else "Overview")
            self._sidebar(qp, side, totals=(self._model != "ftts"))
        elif frame == STRIP:
            strip = QRectF(m.left(), m.bottom() - m.height() * 0.17, m.width(), m.height() * 0.17)
            mapr = QRectF(m.left(), m.top(), m.width(), strip.top() - m.top() - 2)
            self._map(qp, mapr, overview)
            w = strip.width()
            parts = [("Description", 0.34), ("Legend", 0.30), ("Page · N", 0.12),
                     ("Date", 0.12), ("Logo", 0.12)]
            x = strip.left()
            for name, frac in parts:
                self._box(qp, QRectF(x, strip.top(), w * frac, strip.height()), name)
                x += w * frac
        else:   # ASBUILT
            band = QRectF(m.left(), m.bottom() - m.height() * 0.16, m.width(), m.height() * 0.16)
            mapr = QRectF(m.left(), m.top(), m.width(), band.top() - m.top() - 2)
            self._map(qp, mapr, overview)
            w = band.width()
            x = band.left()
            for name, frac in (("Title", 0.18), ("Legend", 0.22), ("As-built facts", 0.45), ("Logo", 0.15)):
                self._box(qp, QRectF(x, band.top(), w * frac, band.height()), name)
                x += w * frac

    def _box(self, qp, r, text):
        qp.setPen(QPen(QColor(110, 110, 110), 0.8))
        qp.setBrush(QBrush(QColor(242, 242, 242)))
        qp.drawRect(r)
        f = QFont(); f.setPointSizeF(max(5.0, min(9.0, r.height() * 0.32, self._h / 30.0)))
        qp.setFont(f); qp.setPen(QColor(70, 70, 70))
        qp.drawText(r, Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap, text)

    def _sidebar(self, qp, s, totals=True):
        rows = [("Legend", 0.30)]
        if totals:
            rows.append(("Project totals", 0.14))
        rows += [("Scale · projection", 0.07), ("N", 0.12), ("Logo", 0.12), ("Title block", 0.13)]
        tot = sum(f for _n, f in rows)
        y = s.top()
        gap = 2.0
        for name, frac in rows:
            h = (s.height() - gap * (len(rows) - 1)) * frac / tot
            self._box(qp, QRectF(s.left(), y, s.width(), h), name)
            y += h + gap

    def _map(self, qp, r, overview):
        qp.setPen(Qt.PenStyle.NoPen)
        qp.setBrush(QBrush(QColor(176, 196, 160)))      # satellite stand-in
        qp.drawRect(r)
        # the area of interest: red dashed, roads only inside it (the hard rule)
        aoi = QRectF(r.left() + r.width() * 0.12, r.top() + r.height() * 0.18,
                     r.width() * 0.7, r.height() * 0.62)
        if not overview:
            aoi = QRectF(r.left() - r.width() * 0.2, r.top() + r.height() * 0.1,
                         r.width() * 1.0, r.height() * 1.1)
        qp.save()
        qp.setClipRect(r)
        # roads, inside the AOI only
        qp.setPen(QPen(QColor(255, 255, 255), 1.2))
        qp.save(); qp.setClipRect(aoi.intersected(r))
        steps = 4 if overview else 3
        for k in range(1, steps + 1):
            yy = aoi.top() + aoi.height() * k / (steps + 1)
            qp.drawLine(QPointF(aoi.left(), yy), QPointF(aoi.right(), yy))
            xx = aoi.left() + aoi.width() * k / (steps + 1)
            qp.drawLine(QPointF(xx, aoi.top()), QPointF(xx, aoi.bottom()))
        # the network: pink distribution, red feeder
        qp.setPen(QPen(QColor(239, 62, 200), 1.6))
        for k in range(1, steps + 1):
            yy = aoi.top() + aoi.height() * (k - 0.5) / (steps + 1) + 4
            qp.drawLine(QPointF(aoi.left() + 6, yy), QPointF(aoi.right() - 6, yy))
        qp.setPen(QPen(QColor(220, 0, 0), 2.2))
        qp.drawLine(QPointF(aoi.left() + 4, aoi.center().y()), QPointF(aoi.right() - 4, aoi.center().y()))
        qp.restore()
        if self._aoi:
            pen = QPen(QColor(227, 26, 28), 1.4); pen.setStyle(Qt.PenStyle.DashLine)
            qp.setPen(pen); qp.setBrush(Qt.BrushStyle.NoBrush)
            qp.drawRect(aoi)
        if overview and self._cover == "grid":
            qp.setPen(QPen(QColor(0, 0, 0), 0.8))
            cols, rows = 4, 3
            gw, gh = aoi.width() / cols, aoi.height() / rows
            f = QFont(); f.setPointSizeF(max(5.0, self._h / 28.0)); f.setBold(True); qp.setFont(f)
            n = 1
            for rr in range(rows):
                for cc in range(cols):
                    cell = QRectF(aoi.left() + cc * gw, aoi.top() + rr * gh, gw, gh)
                    qp.setBrush(Qt.BrushStyle.NoBrush); qp.drawRect(cell)
                    qp.drawText(cell, Qt.AlignmentFlag.AlignCenter, str(n)); n += 1
        elif overview and self._cover in ("pon", "phase"):
            pen = QPen(QColor(230, 210, 0), 1.6); qp.setPen(pen); qp.setBrush(Qt.BrushStyle.NoBrush)
            for k in range(3):
                qp.drawRect(QRectF(aoi.left() + 4 + k * aoi.width() / 3, aoi.top() + 4,
                                   aoi.width() / 3 - 8, aoi.height() - 8))
        qp.restore()
