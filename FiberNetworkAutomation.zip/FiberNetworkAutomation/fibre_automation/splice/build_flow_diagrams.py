"""
MOA Phase 2 — Per-PON Splice FLOW Diagrams (professional, paginated)
====================================================================
A splice plan read as a flow: START at OLT/POP -> follow the feeder (fusion) ->
1:16 FTS splitter -> distribution -> 1:8 STS (LC/APC) -> END at the drops.

* Max 8 STS per page (dense PONs split across pages; OLT+FTS+feeder repeat).
* Reads the validated workbook MOA_Splice_Plan_v9.xlsx as the single source of
  truth so the diagram can never disagree with the splice schedule.
* Every value is taken verbatim from the sheet cells; verify_flow.py independently
  re-reads the sheet and the live-network ground truth and asserts equality.

Writes: MOA_Splice_FlowDiagrams_v9.pdf
"""
import re
import openpyxl
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.backends.backend_pdf import PdfPages

import os as _os
from pathlib import Path as _Path
_OUT_DIR = _Path(_os.environ.get('VF_SPLICE_OUT', _Path(__file__).resolve().parent / 'output'))
_OUT_DIR.mkdir(parents=True, exist_ok=True)
XLSX = str(_OUT_DIR / 'MOA_Splice_Plan_v9.xlsx')
OUT  = str(_OUT_DIR / 'MOA_Splice_FlowDiagrams_v9.pdf')

STS_PER_PAGE = 8

# palette
C_BAND   = "#1F2D3D"   # title / footer bands
C_OLT    = "#33475B"
C_FTS    = "#1565C0"
C_STS    = "#2E7D32"
C_DROPBG = "#E8F5E9"
C_DROPTX = "#1B5E20"
C_EDGE   = "#9AA7B2"
C_SHADOW = "#D7DDE2"
C_MUTE   = "#7F8C8D"

def fts_agg(label):
    """Canonical AGG dome from the FTS label: MOA.FTS.8.AGG.DM.P.F942-OLT... -> MOA.AGG.DM.P.F942"""
    return re.sub(r'FTS\.\d+\.', '', (label or '').split('-OLT')[0]) or None

def short(lbl):
    """MOA.AGG.DM.P.F942 -> 'AGG F942'; MOA.DIS.DM.P.F932 -> 'DIS F932'; pole MOA.P.G643 -> 'pole G643'."""
    if not lbl:
        return ""
    m = re.search(r'\.(AGG|DIS)\.DM\.P\.(\w+)', lbl)
    if m:
        return f"{m.group(1)} {m.group(2)}"
    m = re.match(r'MOA\.P\.(\w+)$', lbl)
    if m:
        return f"pole {m.group(1)}"
    return lbl

def parse_sheet(ws):
    """Return a fully-resolved record for one per-PON sheet (verbatim cell values)."""
    title = ws.cell(1, 1).value or ""
    mp = re.search(r'PON\s+(\d+)', title); mz = re.search(r'Zone\s+(\d+)', title)
    pon  = int(mp.group(1)) if mp else None
    zone = int(mz.group(1)) if mz else None
    port = ws.cell(3, 1).value
    fts  = ws.cell(3, 17).value
    agg  = fts_agg(fts)                              # canonical AGG dome (from FTS label)
    feeder_exit = ws.cell(3, 5).value               # what the feeder row records as its exit joint

    # Feeder hops: cols (2..6),(7..11),(12..16) = FibreIN|Cable|JointEntry|JointExit|FibreOut
    hops = []
    for base in (2, 7, 12):
        fin, cab, je, jx, fout = (ws.cell(3, base + k).value for k in range(5))
        if cab:
            hops.append({'fibre_in': fin, 'cable': cab, 'joint_entry': je,
                         'joint_exit': jx, 'fibre_out': fout})

    # Distribution: group 16 rows per STS (col8). Capture per-STS attributes + drop tally.
    legs = []          # ordered list of dicts
    cur = None
    r = 7
    while r < 6000:
        a   = ws.cell(r, 1).value
        sts = ws.cell(r, 8).value
        if a is None and sts is None:
            break
        if sts:
            if cur is None or sts != cur['sts']:
                cur = {'sts': sts, 'leg': ws.cell(r, 2).value,
                       'fibre_in': ws.cell(r, 3).value, 'cable': ws.cell(r, 4).value,
                       'agg_entry': ws.cell(r, 5).value, 'dis': ws.cell(r, 6).value,
                       'fibre_out': ws.cell(r, 7).value, 'filled': 0, 'spare': 0, 'rows': 0}
                legs.append(cur)
            cur['rows'] += 1
            dr = ws.cell(r, 10).value
            if dr and str(dr).upper() == 'SPARE':
                cur['spare'] += 1
            elif dr:
                cur['filled'] += 1
        r += 1

    legs.sort(key=lambda L: (L['leg'] is None, L['leg']))
    return {'title': title, 'pon': pon, 'zone': zone, 'port': port, 'fts': fts,
            'agg': agg, 'feeder_exit': feeder_exit, 'hops': hops, 'legs': legs}

# ── drawing helpers ───────────────────────────────────────────────────────────
def node(ax, cx, cy, w, h, lines, fc, tc="white", fs=8, header=None, hfs=None):
    # soft shadow
    ax.add_patch(FancyBboxPatch((cx-w/2+0.004, cy-h/2-0.006), w, h,
                 boxstyle="round,pad=0.012,rounding_size=0.03",
                 linewidth=0, facecolor=C_SHADOW, zorder=2))
    ax.add_patch(FancyBboxPatch((cx-w/2, cy-h/2), w, h,
                 boxstyle="round,pad=0.012,rounding_size=0.03",
                 linewidth=1.0, edgecolor="#2C3E50", facecolor=fc, zorder=3))
    if header is not None:
        ax.text(cx, cy + h/2 - 0.022, header, ha="center", va="center",
                fontsize=hfs or fs, color=tc, fontweight="bold", zorder=4)
        ax.text(cx, cy - 0.006, "\n".join(lines), ha="center", va="center",
                fontsize=fs, color=tc, zorder=4)
    else:
        ax.text(cx, cy, "\n".join(lines), ha="center", va="center",
                fontsize=fs, color=tc, fontweight="bold", zorder=4)

def edge(ax, x0, y0, x1, y1, rad=0.0, label=None, fs=5.6, lcolor="#4A5A66"):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>",
                 mutation_scale=9, lw=1.0, color=C_EDGE, zorder=1,
                 connectionstyle=f"arc3,rad={rad}"))
    if label:
        ax.text((x0+x1)/2, (y0+y1)/2 + 0.011, label, ha="center", va="bottom",
                fontsize=fs, color=lcolor, zorder=4)

def draw_page(pdf, rec, page_idx, page_tot, legs_slice, idx0):
    pon, zone, port = rec['pon'], rec['zone'], rec['port']
    fig = plt.figure(figsize=(11.69, 8.27))
    ax = fig.add_axes((0, 0, 1, 1)); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")

    # title band
    ax.add_patch(FancyBboxPatch((0.015, 0.905), 0.97, 0.078,
                 boxstyle="round,pad=0.004,rounding_size=0.02",
                 linewidth=0, facecolor=C_BAND, zorder=2))
    ax.text(0.03, 0.958, "SPLICE FLOW", ha="left", va="center",
            fontsize=15, color="white", fontweight="bold")
    ax.text(0.03, 0.927, "Potch–Mohadin Phase 2", ha="left", va="center",
            fontsize=8, color="#AEB9C4")
    ax.text(0.50, 0.952, f"PON {pon}   ·   Zone {zone}   ·   OLT.01 {port}",
            ha="center", va="center", fontsize=13, color="white", fontweight="bold")
    n_total = len(rec['legs'])
    a, b = idx0 + 1, idx0 + len(legs_slice)
    ax.text(0.97, 0.952, f"Page {page_idx}/{page_tot}", ha="right", va="center",
            fontsize=11, color="white", fontweight="bold")
    ax.text(0.97, 0.925, f"STS {a}–{b} of {n_total}", ha="right", va="center",
            fontsize=8, color="#AEB9C4")

    # flow legend line
    ax.text(0.50, 0.882,
            "START  OLT/POP   →   feeder (fusion)   →   1:16 FTS   →   distribution   →   1:8 STS (LC/APC)   →   END  drops",
            ha="center", va="center", fontsize=8.2, color=C_MUTE, style="italic")

    # column captions
    x_olt, x_fts, x_sts, x_drop = 0.085, 0.31, 0.625, 0.905
    for x, cap in [(x_olt, "START · OLT"), (x_fts, "1:16 FTS · FUSION"),
                   (x_sts, "1:8 STS · LC/APC"), (x_drop, "DROPS")]:
        ax.text(x, 0.858, cap, ha="center", va="center", fontsize=7.5,
                color=C_FTS if x == x_fts else (C_STS if x in (x_sts, x_drop) else C_OLT),
                fontweight="bold")

    y_top, y_bot = 0.785, 0.15
    n = len(legs_slice)
    if n > 1:
        ys = [y_top - i*(y_top - y_bot)/(n-1) for i in range(n)]
    else:
        ys = [(y_top + y_bot)/2]
    y_mid = (y_top + y_bot)/2

    # START node
    node(ax, x_olt, y_mid, 0.12, 0.13,
         ["OLT.01", f"{port}", f"PON {pon}", f"Zone {zone}"], C_OLT, fs=8,
         header="POP / OLT", hfs=8.5)

    # FTS node
    node(ax, x_fts, y_mid, 0.165, 0.14,
         [short(rec['agg']), "bare-fibre", "FUSION splice"], C_FTS, fs=8,
         header="1:16 FTS", hfs=9)

    # feeder edge + hop annotation (placed in the clear band ABOVE the OLT->FTS link)
    edge(ax, x_olt+0.062, y_mid, x_fts-0.085, y_mid, rad=0.0)
    fx = (x_olt + x_fts) / 2
    hop_txt = []
    for hp in rec['hops']:
        hop_txt.append(f"{hp['cable']}  ·  {hp['fibre_out']}   [{short(hp['joint_entry'])} → {short(hp['joint_exit'])}]")
    ax.text(fx, y_mid + 0.118, "FEEDER", ha="center", va="bottom",
            fontsize=6.5, color=C_MUTE, fontweight="bold")
    ax.text(fx, y_mid + 0.108, "\n".join(hop_txt) or "(direct)",
            ha="center", va="top", fontsize=5.4, color="#4A5A66")

    # STS rows
    for L, y in zip(legs_slice, ys):
        rad = 0.0 if abs(y - y_mid) < 1e-6 else (0.12 if y > y_mid else -0.12)
        edge(ax, x_fts+0.085, y_mid + (y - y_mid)*0.10, x_sts-0.10, y, rad=rad,
             label=f"STS #{L['leg']} · {L['cable']} · {L['fibre_out']}", fs=5.3)
        node(ax, x_sts, y, 0.20, 0.078,
             [f"{short(L['dis'])}", "LC/APC connectorised"], C_STS, fs=6.6,
             header=f"1:8 STS #{L['leg']}", hfs=7.2)
        # drops leaf
        cap = L['rows'] if L['rows'] else 8
        edge(ax, x_sts+0.10, y, x_drop-0.066, y, rad=0.0)
        node(ax, x_drop, y, 0.13, 0.066,
             [f"{L['filled']} connected", f"{L['spare']} spare  / {cap}"], C_DROPBG,
             tc=C_DROPTX, fs=6.4, header="DROPS", hfs=6.8)

    # footer band
    pg_fill = sum(L['filled'] for L in legs_slice); pg_spare = sum(L['spare'] for L in legs_slice)
    tot_fill = sum(L['filled'] for L in rec['legs']); tot_spare = sum(L['spare'] for L in rec['legs'])
    tot_cap  = sum((L['rows'] or 16) for L in rec['legs'])
    ax.add_patch(FancyBboxPatch((0.015, 0.052), 0.97, 0.052,
                 boxstyle="round,pad=0.004,rounding_size=0.02",
                 linewidth=0, facecolor="#F4F6F7", zorder=2))
    ax.text(0.03, 0.078, f"THIS PAGE:  {len(legs_slice)} STS  ·  {pg_fill} connected  ·  {pg_spare} spare",
            ha="left", va="center", fontsize=8, color=C_BAND, fontweight="bold")
    ax.text(0.97, 0.078,
            f"PON {pon} TOTAL:  {len(rec['legs'])} STS  ·  {tot_fill} homes  ·  {tot_spare} spare  ·  "
            f"capacity {tot_cap}  ·  fill {round(tot_fill/max(1,tot_cap)*100)}%",
            ha="right", va="center", fontsize=8, color=C_BAND, fontweight="bold")
    ax.text(0.50, 0.060,
            "Acceptance: fusion ≤0.10 dB target / ≤0.30 dB max (ANSI/TIA-568.3-D) · ORL ≥26 dB · "
            "bi-directional OTDR (ISO/IEC 14763-3:2024 Ed 3.0) · colour TIA-598-C",
            ha="center", va="center", fontsize=6, color=C_MUTE)
    ax.text(0.50, 0.022, "Drops connect to the STS via LC/APC connectors (plugged, not spliced). "
            "Fusion splices occur at the AGG dome only.",
            ha="center", va="center", fontsize=6, color=C_MUTE, style="italic")

    pdf.savefig(fig); plt.close(fig)

def iter_pages(rec):
    legs = rec['legs']
    if not legs:
        yield (1, 1, [], 0); return
    tot = (len(legs) + STS_PER_PAGE - 1) // STS_PER_PAGE
    for p in range(tot):
        s = p * STS_PER_PAGE
        yield (p + 1, tot, legs[s:s + STS_PER_PAGE], s)

def main():
    wb = openpyxl.load_workbook(XLSX, read_only=False, data_only=True)
    OLT_OFFSET = {15: 224, 16: 240, 17: 256, 18: 272, 19: 288}
    ports = [s for s in wb.sheetnames if re.match(r'^C\d\dP\d\d$', s) and int(s[1:3]) in OLT_OFFSET]
    def pon_of(p):
        m = re.match(r'C(\d+)P(\d+)', p); return OLT_OFFSET.get(int(m.group(1)), 0) + int(m.group(2))
    ports.sort(key=pon_of)
    pages = 0
    with PdfPages(OUT) as pdf:
        for p in ports:
            rec = parse_sheet(wb[p])
            for (pi, pt, sl, i0) in iter_pages(rec):
                draw_page(pdf, rec, pi, pt, sl, i0); pages += 1
    wb.close()
    print(f"  PONs: {len(ports)}   pages: {pages}")
    print(f"  PDF -> {OUT}")

if __name__ == "__main__":
    main()
