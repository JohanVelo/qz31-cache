"""Small planar geometry kit for the wayleave engine (metric coordinates).

Only numpy + stdlib, so it runs on every QGIS from 3.38 to 4.2 and headless in tests:
shapely and networkx are not guaranteed on a teammate's stock QGIS.
"""
from __future__ import annotations

import math
from collections import defaultdict


def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def seg_project(a, b, p):
    """(distance from p to segment ab, t in [0,1] of the closest point)."""
    ax, ay = a; bx, by = b; px, py = p
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    if L2 <= 0.0:
        return math.hypot(px - ax, py - ay), 0.0
    t = ((px - ax) * dx + (py - ay) * dy) / L2
    t = 0.0 if t < 0.0 else 1.0 if t > 1.0 else t
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy)), t


def seg_intersection(a, b, c, d):
    """Crossing point of segments ab and cd, or None (parallel / not touching)."""
    r = (b[0] - a[0], b[1] - a[1]); s = (d[0] - c[0], d[1] - c[1])
    den = r[0] * s[1] - r[1] * s[0]
    if abs(den) < 1e-12:
        return None
    qp = (c[0] - a[0], c[1] - a[1])
    t = (qp[0] * s[1] - qp[1] * s[0]) / den
    u = (qp[0] * r[1] - qp[1] * r[0]) / den
    if -1e-9 <= t <= 1 + 1e-9 and -1e-9 <= u <= 1 + 1e-9:
        return (a[0] + t * r[0], a[1] + t * r[1])
    return None


def turn_deg(a, b, c):
    """Direction change at b in degrees (0 = straight on)."""
    v1 = (b[0] - a[0], b[1] - a[1]); v2 = (c[0] - b[0], c[1] - b[1])
    n1, n2 = math.hypot(*v1), math.hypot(*v2)
    if n1 < 1e-6 or n2 < 1e-6:
        return 0.0
    cosv = (v1[0] * v2[0] + v1[1] * v2[1]) / (n1 * n2)
    return math.degrees(math.acos(max(-1.0, min(1.0, cosv))))


def line_length(pts):
    return sum(dist(a, b) for a, b in zip(pts[:-1], pts[1:]))


def point_at(pts, frac):
    """Point at a fraction of the way along a polyline."""
    total = line_length(pts); want = total * frac; run = 0.0
    for a, b in zip(pts[:-1], pts[1:]):
        L = dist(a, b)
        if run + L >= want and L > 0:
            t = (want - run) / L
            return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
        run += L
    return pts[-1]


def in_ring(p, ring):
    x, y = p; inside = False; n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i]; xj, yj = ring[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-300) + xi:
            inside = not inside
        j = i
    return inside


def in_polygon(p, poly):
    """poly = [outer ring, hole, hole...]"""
    return in_ring(p, poly[0]) and not any(in_ring(p, h) for h in poly[1:])


def ring_distance(p, ring):
    return min(seg_project(a, b, p)[0] for a, b in zip(ring[:-1], ring[1:])) if len(ring) > 1 else dist(p, ring[0])


class Area:
    """A (multi)polygon with a bounding box, for contains / distance."""

    def __init__(self, polys):
        self.polys = [p for p in polys if p and len(p[0]) >= 3]
        xs = [x for p in self.polys for x, _ in p[0]]; ys = [y for p in self.polys for _, y in p[0]]
        self.bbox = (min(xs), min(ys), max(xs), max(ys)) if xs else (0, 0, 0, 0)

    def contains(self, p):
        x0, y0, x1, y1 = self.bbox
        if not (x0 <= p[0] <= x1 and y0 <= p[1] <= y1):
            return False
        return any(in_polygon(p, poly) for poly in self.polys)

    def distance(self, p):
        if self.contains(p):
            return 0.0
        return min(ring_distance(p, r) for poly in self.polys for r in poly)


class SegIndex:
    """Uniform grid over segments. Items are (key, a, b); query returns candidate items near a box."""

    def __init__(self, cell=50.0):
        self.cell = float(cell); self.grid = defaultdict(list); self.items = []

    def _cells(self, x0, y0, x1, y1):
        c = self.cell
        for i in range(int(math.floor(x0 / c)), int(math.floor(x1 / c)) + 1):
            for j in range(int(math.floor(y0 / c)), int(math.floor(y1 / c)) + 1):
                yield (i, j)

    def add(self, key, a, b):
        k = len(self.items); self.items.append((key, a, b))
        for cell in self._cells(min(a[0], b[0]), min(a[1], b[1]), max(a[0], b[0]), max(a[1], b[1])):
            self.grid[cell].append(k)

    def near(self, p, r):
        seen = set()
        for cell in self._cells(p[0] - r, p[1] - r, p[0] + r, p[1] + r):
            for k in self.grid.get(cell, ()):
                if k not in seen:
                    seen.add(k); yield self.items[k]

    def box(self, a, b, pad=0.0):
        seen = set()
        for cell in self._cells(min(a[0], b[0]) - pad, min(a[1], b[1]) - pad, max(a[0], b[0]) + pad, max(a[1], b[1]) + pad):
            for k in self.grid.get(cell, ()):
                if k not in seen:
                    seen.add(k); yield self.items[k]


class PointIndex:
    """Uniform grid over points: nearest within a radius, and all within a radius."""

    def __init__(self, pts, cell=5.0):
        self.cell = float(cell); self.pts = list(pts); self.grid = defaultdict(list)
        for k, p in enumerate(self.pts):
            self.grid[(int(math.floor(p[0] / self.cell)), int(math.floor(p[1] / self.cell)))].append(k)

    def within(self, p, r):
        c = self.cell; out = []
        for i in range(int(math.floor((p[0] - r) / c)), int(math.floor((p[0] + r) / c)) + 1):
            for j in range(int(math.floor((p[1] - r) / c)), int(math.floor((p[1] + r) / c)) + 1):
                for k in self.grid.get((i, j), ()):
                    if dist(self.pts[k], p) <= r:
                        out.append(k)
        return out

    def nearest(self, p, r_max=1e9):
        r = self.cell
        while True:
            hits = self.within(p, r)
            if hits:
                return min(hits, key=lambda k: dist(self.pts[k], p))
            if r > r_max or not self.pts:
                return None
            r *= 2.0


def dijkstra(adj, sources):
    """adj: node -> list of (nbr, weight, edge_data). sources: {node: start_dist}.
    Returns (dist, prev) where prev[node] = (parent, edge_data)."""
    import heapq
    dist_ = dict(sources); prev = {}
    heap = [(d, n) for n, d in sources.items()]; heapq.heapify(heap)
    while heap:
        d, n = heapq.heappop(heap)
        if d > dist_.get(n, math.inf):
            continue
        for m, w, data in adj.get(n, ()):
            nd = d + w
            if nd < dist_.get(m, math.inf):
                dist_[m] = nd; prev[m] = (n, data); heapq.heappush(heap, (nd, m))
    return dist_, prev


def path_edges(prev, node):
    """Edge data along the shortest-path tree from a source to node."""
    out = []
    while node in prev:
        parent, data = prev[node]; out.append(data); node = parent
    return out
