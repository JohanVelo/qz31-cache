"""Main FTTH Plan Tool plugin module."""

import os.path

from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication, Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtGui import QAction

from .resources import *
from .dock_widget import FTTHPlanToolDockWidget


class FTTHPlanTool:
    """QGIS Plugin for FTTH network planning and routing."""

    def __init__(self, iface):
        """Constructor.

        Args:
            iface: An interface instance that will be passed to this class
                which provides the hook by which you can manipulate the QGIS
                application at run time.
        """
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        
        # Initialize locale — value can be None on a fresh QGIS profile
        locale = (QSettings().value('locale/userLocale') or 'en')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'FTTHPlanTool_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr('&Velocity Network Planner')
        self.toolbar = self.iface.addToolBar('FTTHPlanTool')
        self.toolbar.setObjectName('FTTHPlanTool')

        self.pluginIsActive = False
        self.dockwidget = None

    def tr(self, message):
        """Get the translation for a string using Qt translation API."""
        return QCoreApplication.translate('FTTHPlanTool', message)

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        """Add a toolbar icon to the toolbar."""

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToVectorMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        # Use QGIS built-in network/routing icon
        from qgis.PyQt.QtGui import QIcon
        from qgis.core import QgsApplication
        
        # Try to use built-in icon, fallback to default if not available
        icon = QgsApplication.getThemeIcon('/mActionMapTips.svg')
        if icon.isNull():
            icon = QIcon()  # Empty icon fallback
        
        action = QAction(icon, self.tr('Velocity Network Planner'), self.iface.mainWindow())
        action.triggered.connect(self.run)
        action.setEnabled(True)
        action.setStatusTip(self.tr('FTTH Network Planning Tool'))
        
        self.toolbar.addAction(action)
        self.iface.addPluginToVectorMenu(self.menu, action)
        self.actions.append(action)

    def onClosePlugin(self):
        """Cleanup necessary items here when plugin dockwidget is closed."""
        # run() reconnects on every open, so after an open→close→open cycle the
        # signal may already be disconnected — guard so the Nth close can't raise.
        try:
            self.dockwidget.closingPlugin.disconnect(self.onClosePlugin)
        except (TypeError, RuntimeError):
            pass
        self.pluginIsActive = False

    def unload(self):
        """Remove the plugin menu item and icon from QGIS GUI."""
        # remove + delete the dock itself, or a stale widget (and any map
        # tool it installed) survives a plugin upgrade/reload
        try:
            if self.dockwidget is not None:
                self.iface.removeDockWidget(self.dockwidget)
                self.dockwidget.close()
                self.dockwidget.deleteLater()
                self.dockwidget = None
        except Exception:
            pass
        for action in self.actions:
            self.iface.removePluginVectorMenu(
                self.tr('&Velocity Network Planner'),
                action)
            self.iface.removeToolBarIcon(action)
        # detach the toolbar from the QGIS main window before dropping the
        # Python ref, or an empty toolbar band survives every reload
        try:
            self.iface.mainWindow().removeToolBar(self.toolbar)
        except Exception:
            pass
        del self.toolbar

    def run(self):
        """Run method that loads and starts the plugin."""

        if not self.pluginIsActive:
            self.pluginIsActive = True

            # dockwidget may not exist if:
            # first run of plugin or closed and reopened during QGIS session
            if self.dockwidget is None:
                self.dockwidget = FTTHPlanToolDockWidget(self.iface)

            # connect to provide cleanup on closing of dockwidget
            self.dockwidget.closingPlugin.connect(self.onClosePlugin)

            # show the dockwidget
            self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.dockwidget)
            self.dockwidget.show()
