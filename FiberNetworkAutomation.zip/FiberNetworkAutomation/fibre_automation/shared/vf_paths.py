"""vf_paths — portable path resolution so the plugin runs on ANY machine.

Teammates have plain QGIS: no C:\\Temp, no .qgis-venv, no fixed user folder.
Everything that needs a scratch/data location goes through here.

    from fibre_automation.shared.vf_paths import data_dir, data_file, python_exe, roads_json
"""
import os
import sys
import tempfile
from pathlib import Path


def data_dir() -> str:
    """Writable scratch/data folder, created if missing.

    Order: $VF_DATA_DIR  ->  C:\\Temp (if it already exists)  ->  %TEMP%\\VelocityFibre.
    Always returns a path that exists and is writable.
    """
    env = os.environ.get('VF_DATA_DIR')
    if env:
        try:
            os.makedirs(env, exist_ok=True)
            return env
        except OSError:
            pass
    legacy = 'C:/Temp'
    if os.path.isdir(legacy):
        return legacy
    fallback = os.path.join(tempfile.gettempdir(), 'VelocityFibre')
    os.makedirs(fallback, exist_ok=True)
    return fallback


def data_file(name: str) -> str:
    """Absolute path to <name> inside the portable data dir."""
    return os.path.join(data_dir(), name)


def roads_json() -> str:
    """Path to roads.json (OSM road data for FT7/FT8). May not exist yet."""
    return data_file('roads.json')


def python_exe() -> str:
    """Best Python for subprocess helpers that need geopandas/overturemaps etc.

    Prefers the dev venv if present (JJ's machine), else QGIS's bundled
    python.exe. Inside QGIS on Windows, sys.executable is qgis-bin.exe —
    launching THAT as a subprocess would open a whole new QGIS window, so we
    must resolve the real interpreter under apps\\PythonXX instead.
    """
    venv = Path.home() / '.qgis-venv' / 'Scripts' / 'python.exe'
    if venv.exists():
        return str(venv)
    if os.name == 'nt' and not sys.executable.lower().endswith('python.exe'):
        cand = os.path.join(sys.exec_prefix, 'python.exe')
        if os.path.isfile(cand):
            return cand
    return sys.executable


def project_output_dir() -> str:
    """Where to write user-facing outputs (splice xlsx, BOM csv, flow PDFs).

    Prefers the current QGIS project's folder (so deliverables sit beside the
    project), else the portable data dir.
    """
    try:
        from qgis.core import QgsProject
        p = QgsProject.instance().homePath()
        if p and os.path.isdir(p):
            out = os.path.join(p, 'Velocity Nexus Output')
            os.makedirs(out, exist_ok=True)
            return out
    except Exception:
        pass
    return data_dir()


# ── Windows MAX_PATH, and where a safety backup can actually be written ─────
#
# ONE definition, imported by everything that writes a backup into a project
# folder. It used to be duplicated per caller, and a measured constant that
# exists twice is a constant that drifts.
#
# MEASURED on JJ's machine 2026-07-28 (QGIS 4.0.3 Qt6, LongPathsEnabled = 0):
# a plain path wrote a GeoPackage *and re-read it* clean at 245 characters and
# failed outright from 260. 245 was measured with a real GPKG write, which also
# creates SQLite's `-journal` sidecar at +8 (253), so the sidecars are proven
# inside the wall too. Do NOT raise this on a hunch — re-measure.
#
# The `\\?\` extended-length prefix is NOT a way around it, and this was tested
# rather than assumed: makedirs, open() and even GDAL's GPKG write all succeed
# with it at 289 characters, but nothing can read the result back, because a
# GeoPackage is SQLite and sqlite3_open ignores the prefix. It would hand us a
# backup that writes and can never restore — worse than refusing, and invisible
# to every gate we own.
MAXPATH_BUDGET = 245


def spill_root(project_path: str) -> str:
    """Short local folder to hold a backup when the project's own folder is too deep.

    Keyed by a hash of the project path so two projects can never share one, and
    stable for a given path so a restore can always find what a write left.
    """
    import hashlib
    key = hashlib.sha1(
        (project_path or '').encode('utf-8', 'replace')).hexdigest()[:10]
    base = os.environ.get('LOCALAPPDATA') or os.path.expanduser('~')
    return os.path.join(base, 'VelocityFibre', 'spill', key)


def longest_write(root: str, relative_tails) -> int:
    """Longest full path produced by joining each tail onto root.

    Pass EVERY path that will be written — a manifest or a timestamp folder can
    be the longest one, not just the obvious data file.
    """
    tails = list(relative_tails or [])
    if not tails:
        return len(root)
    return max(len(os.path.join(root, t)) for t in tails)


def choose_backup_root(project_path: str, relative_tails,
                       budget: int = MAXPATH_BUDGET):
    """Where a backup for `project_path` can be written → (root, spilled, longest).

    Prefers the project's own folder, which keeps the backup beside the data and
    inside OneDrive/SharePoint sync. Only when that would breach MAX_PATH does it
    fall back to the short local root, so a project that works today is entirely
    unaffected.

    Returns ('', False, 0) when the project has not been saved — the caller must
    say so in its own words, because "unsaved" and "too deep" are different
    problems and reporting one as the other sends the operator hunting in the
    wrong place.
    """
    proj_dir = os.path.dirname(project_path or '')
    if not proj_dir:
        return '', False, 0
    longest = longest_write(proj_dir, relative_tails)
    if longest <= budget:
        return proj_dir, False, longest
    return spill_root(project_path), True, longest
