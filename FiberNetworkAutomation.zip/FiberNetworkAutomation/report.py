"""report — one-click 'Design Report' PDF for stakeholders.

Builds a Print Layout on the fly (title + map + legend + scalebar) and, if a
PON/Zone coverage layer exists, runs it as an Atlas (one page per PON) to a
multi-page PDF. No pre-saved layout needed. Falls back to a single current-view
page when there's no coverage layer. Output lands in the project output folder.
"""
import os

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass


def _coverage_layer():
    """Prefer a PON layer, then Zone, as the atlas coverage."""
    from qgis.core import QgsProject, QgsWkbTypes
    layers = list(QgsProject.instance().mapLayers().values())
    def poly(name_frag):
        for l in layers:
            if (hasattr(l, 'geometryType') and l.geometryType() == QgsWkbTypes.GeometryType.PolygonGeometry
                    and name_frag in l.name().lower() and l.featureCount() > 0):
                return l
        return None
    return poly('pon') or poly('zone')


def export_design_report(iface):
    """Generate and export the Design Report PDF. Returns the output path or None."""
    from qgis.core import (QgsProject, QgsPrintLayout, QgsLayoutItemMap,
                           QgsLayoutItemLabel, QgsLayoutItemLegend,
                           QgsLayoutItemScaleBar, QgsLayoutPoint, QgsLayoutSize,
                           QgsUnitTypes, QgsLayoutExporter)
    from qgis.PyQt.QtGui import QFont
    from qgis.PyQt.QtCore import QRectF

    project = QgsProject.instance()
    canvas = iface.mapCanvas()

    # Output path (portable: project folder / Velocity Nexus Output)
    try:
        from .fibre_automation.shared.vf_paths import project_output_dir
    except ImportError:
        from fibre_automation.shared.vf_paths import project_output_dir
    out_dir = project_output_dir()
    out_pdf = os.path.join(out_dir, 'Velocity_Fibre_Design_Report.pdf')

    layout = QgsPrintLayout(project)
    layout.initializeDefaults()  # A4 landscape page
    layout.setName('Velocity Nexus Design Report')

    # Map item — fills most of the page, uses the current visible layers
    map_item = QgsLayoutItemMap(layout)
    map_item.setRect(QRectF(0, 0, 240, 160))
    map_item.attemptMove(QgsLayoutPoint(10, 24, QgsUnitTypes.LayoutUnit.LayoutMillimeters))
    map_item.attemptResize(QgsLayoutSize(200, 160, QgsUnitTypes.LayoutUnit.LayoutMillimeters))
    map_item.setExtent(canvas.extent())
    map_item.setLayers(canvas.layers())
    map_item.setFrameEnabled(True)
    layout.addLayoutItem(map_item)

    # Title
    title = QgsLayoutItemLabel(layout)
    title.setText('Velocity Nexus — Network Design Report')
    title.setFont(QFont('Segoe UI', 18))
    title.adjustSizeToText()
    title.attemptMove(QgsLayoutPoint(10, 8, QgsUnitTypes.LayoutUnit.LayoutMillimeters))
    layout.addLayoutItem(title)

    # Legend
    legend = QgsLayoutItemLegend(layout)
    legend.setTitle('Legend')
    legend.setLinkedMap(map_item)
    legend.attemptMove(QgsLayoutPoint(214, 24, QgsUnitTypes.LayoutUnit.LayoutMillimeters))
    legend.attemptResize(QgsLayoutSize(80, 150, QgsUnitTypes.LayoutUnit.LayoutMillimeters))
    layout.addLayoutItem(legend)

    # Scale bar
    sbar = QgsLayoutItemScaleBar(layout)
    sbar.setStyle('Single Box')
    sbar.setLinkedMap(map_item)
    sbar.applyDefaultSize()
    sbar.attemptMove(QgsLayoutPoint(12, 186, QgsUnitTypes.LayoutUnit.LayoutMillimeters))
    layout.addLayoutItem(sbar)

    cov = _coverage_layer()
    exporter = QgsLayoutExporter(layout)
    settings = QgsLayoutExporter.PdfExportSettings()

    if cov is not None:
        # Atlas: one page per PON/Zone polygon
        atlas = layout.atlas()
        atlas.setEnabled(True)
        atlas.setCoverageLayer(cov)
        lbl = 'label' if cov.fields().indexOf('label') != -1 else None
        atlas.setPageNameExpression(f'"{lbl}"' if lbl else "@atlas_featurenumber")
        map_item.setExtent(cov.extent())
        map_item.setAtlasDriven(True)
        map_item.setAtlasMargin(0.15)
        try:
            # Atlas overload is a static method returning (ExportResult, errorFile)
            res, _err = exporter.exportToPdf(atlas, out_pdf, settings)
            n_pages = cov.featureCount()
        except TypeError:
            # Fallback: instance overload exports only the current page (1)
            res = exporter.exportToPdf(out_pdf, settings)
            n_pages = 1
    else:
        res = exporter.exportToPdf(out_pdf, settings)
        n_pages = 1

    ok = (res == QgsLayoutExporter.ExportResult.Success) if hasattr(QgsLayoutExporter, 'ExportResult') else (res == 0)
    if ok:
        # Shrink the map JPEGs at the same pixel size (JJ 2026-09-28). Runs on a worker
        # thread while Qt keeps pumping; fail-open, the file is kept as-is on any problem.
        note = ''
        try:
            try:
                from .hld_pdf import pdf_reduce as PR
            except ImportError:
                from hld_pdf import pdf_reduce as PR
            rs = PR.reduce_on_gui_thread(out_pdf)
            if rs.get('reduced'):
                note = ' · reduced ' + PR.summary(rs)
        except Exception:
            _swallowed_note()
        try:
            iface.messageBar().pushSuccess(
                'Velocity Nexus',
                f'Design Report exported ({n_pages} page(s)){note} → {out_pdf}')
        except Exception:
            _swallowed_note()
        try:
            os.startfile(out_dir)  # noqa: open the folder
        except Exception:
            _swallowed_note()
        return out_pdf
    iface.messageBar().pushWarning('Velocity Nexus', 'Design Report export failed.')
    return None
