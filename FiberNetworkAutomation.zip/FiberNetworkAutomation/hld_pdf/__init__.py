# HLD PDF automation — Velocity Nexus "Generate HLD PDF" button (BETA).
# Builds the A3 HLD atlas (overview + 1 page/PON) as a PDF in a separate headless
# QGIS process, so the live session can never freeze. See open_hld_pdf_dialog().
from .dialog import open_hld_pdf_dialog

__all__ = ["open_hld_pdf_dialog"]
