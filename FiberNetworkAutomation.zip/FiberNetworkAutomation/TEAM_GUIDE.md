# Velocity Fibre Automation — Team Guide

Everything the planning team needs, in one QGIS plugin. This guide takes you from
zero to designing a network. No coding, no AI, no extra apps — just QGIS.

---

## A. One-time install (~3 minutes)

You do this once. After that, updates are automatic.

1. Open **QGIS** (version 3.28 or newer).
2. Menu bar → **Plugins → Manage and Install Plugins…**
3. Click the **Settings** tab (left side) → under *Plugin Repositories* click **Add…**
4. Fill in:
   - **Name:** `Velocity Fibre`
   - **URL:** `https://raw.githubusercontent.com/JohanVelo/qz31-cache/main/plugins.xml`
   - Make sure **Enabled** is ticked.
   - Tick **Check for updates on startup** (top of the Settings tab) so you get new
     versions automatically.
5. Click **OK**. QGIS fetches the repository.
6. Go to the **All** tab → in the search box type **Velocity**.
7. Click **Velocity Fibre Automation** → **Install Plugin**.
8. A new **Velocity Fibre** menu appears in the QGIS menu bar. Done.

---

## B. Activate (one-time, per machine)

The plugin is **locked** until you enter the company password — this keeps it private.

1. Menu bar → **Velocity Fibre → ℹ️ About & Activation…**
2. Type the **company password** (ask JJ — it is never written down in the plugin).
3. Click **Activate**.
4. You'll see a **Welcome** screen and every tool unlocks.

Notes:
- You only activate **once** — it is remembered on your machine and survives updates and
  QGIS restarts.
- 5 wrong attempts → a 60-second lockout (just wait it out).
- To move to a new machine: activate there too. To remove: About & Activation → *Deactivate*.

---

## C. Getting updates (automatic)

When JJ publishes an improvement:
- Your QGIS shows **"Upgradeable"** next to the plugin in the Plugin Manager (and notifies
  you on startup if you ticked that box in step A4).
- Open **Plugins → Manage and Install Plugins → Upgradeable → Upgrade Plugin** (one click).
- Your activation stays — no need to re-enter the password.
- You can also check anytime: **Velocity Fibre → 🔄 Check for updates…**

---

## D. See everything at a glance

**Velocity Fibre → 🗺 Tool Map** opens a page in your browser listing **every tool**, what
it does, and where it lives. It is generated from the live menu, so it is always accurate.
Start here whenever you're unsure where something is.

---

## E. The menu, top to bottom

### 🆕 New Project…
A wizard that sets up a fresh project area. Choose the client type — **Vuma**, **Fibertime**,
or **HeroTel** — and it creates all the standard layers with the correct fields and styles.
Run this first on a brand-new area.

### 🤖 AI Mapping  *(detects buildings & erven from imagery)*
- **Detect Buildings (GOB/Overture)** — downloads building footprints for your area from
  Google Open Buildings / Overture. Works on plain QGIS (needs internet; first run may
  install a couple of Python packages — see *Section G*).
- **Erven Detection / AI Detect / AutoDetect** — advanced AI detection. These need an AI
  server running on the network; if it isn't, you'll see a clear "server offline" message —
  nothing breaks. Ask JJ if you need these.
- **Erven Studio** — a dock to detect buildings and tune erven with sliders.

### ✏️ Manual Planning  *(draw the network by hand — pure QGIS, always works)*
Click-to-place and draw tools, each fills in the standard attributes for you:
- **Place Pole / AGG Dome / STS Dome**, **Auto FTS+SS / Auto STS Splitters**
- **Draw Distribution / Primary / Secondary cables**, **Auto-Plan Street Block**
- **Auto PON Boundaries** (clusters erven into PONs), **Draw PON / Zone**, **Auto Zones**
- **Connect Drops** (links homes to the nearest splitter), **Populate Attributes**,
  **Label Network**
- **Setup Project** (legacy one-shot: layers + cadastral erven + home connections)

### 🏷 Labelling  *(PRAK / MALM projects)*
The Group A labelling algorithms — aggregation polygons, blocks, poles, joints, demand
points, feeder/distribution cables, plus Clean Buildings.

### 🔌 FT Pipeline  *(Fibertime MOA standard — pure QGIS, always works)*
Run in order, or use **Run All**:
FT1 Label Poles → FT2 Distribution → FT3 Secondary → FT4 Enclosure → FT4b STS →
FT5 PON Zones → FT6 PON Order → FT7 Pole Thickness → FT8 Road Crossing → FT9 PON Voronoi.
You can also run any one from the **Processing Toolbox** (search "FT").
*(FT7/FT8 use road data; if it's missing they skip the road-crossing step with a notice —
they don't fail. See Section G.)*

### 🏢 HeroTel  *(TSD standard)*
HT1 ONT Placement → HT2 PON Clustering → HT3 Splitter Placement → HT4 Drop Routing →
HT5 Feeder Routing.

### ✅ QA & Output
- **HLD Audit** — full compliance check (labels, PON range, spans, drops-per-STS, 8 km
  POP→ONT, and more). Tuned for Mohadin-style MOA projects.
- **Check Spans** — flags pole-to-pole spans over the limit (Drop ≤50 m, others ≤70 m).
- **Refresh Attributes** — re-fills attributes after manual edits.
- **Splice Plans** — Excel workbook + A4 field cards + flow-diagram PDF. Outputs land in a
  **"Velocity Fibre Output"** folder next to your project. *(Needs a few Python packages —
  Section G.)*
- **Bill of Materials**, **Export OES CSV**.

### 🛠 Tools
Pole Editor, Enclosure Editor, Splice Viewer, Record PON Order, Canvas snapshot.

---

## F. A typical first session

1. **New Project…** → pick your client type → it builds the layers.
2. Load your aerial imagery / basemap.
3. **AI Mapping → Detect Buildings** (or place demand points manually).
4. **Manual Planning** or the **FT Pipeline** to design poles, cables, splitters, PONs.
5. **QA & Output → HLD Audit** and **Check Spans** to validate.
6. **QA & Output → Splice Plans / BOM / OES** for deliverables.
Use **🗺 Tool Map** anytime to find a tool.

---

## G. What needs a little extra (and how the plugin tells you)

The core tools — **New Project, Manual Planning, Labelling, FT Pipeline, HeroTel, QA,
Check Spans** — are pure QGIS and work out of the box. A few advanced tools need extra
Python packages or a network server. **None of them crash** — they show a clear message:

| Tool | Needs | If missing… |
|---|---|---|
| Detect Buildings, Vuma fetch | `geopandas`, `overturemaps` (internet) | On first use the plugin installs them into QGIS's Python automatically. **This takes a few minutes the first time — let it finish** (watch the Python Console: Plugins → Python Console). After that it's instant. |
| Splice Plans | `openpyxl`, `reportlab`, `matplotlib` | Shows a message naming what's missing. Ask JJ, or install once via the QGIS Python Console. |
| AI Detect / Erven Detection / AutoDetect | an AI server on the LAN | Shows "server offline" — ask JJ if you need these. |
| FT7 / FT8 road crossing | a `roads.json` file | Skips the road-crossing step with a notice; the rest of FT7/FT8 still runs. |

Nothing here stops you from designing a network with the core tools.

---

## H. Something went wrong? Report it (built in)

If any tool hits a problem, the plugin **catches it, logs it, and tells you** — you never get
a scary crash. To send the details to support so it can be fixed:

1. **Velocity Fibre → 🐞 Report a Problem…**
2. (Optional) type what you were doing in the box.
3. Click **✉ Email to support** — your email app opens with the report ready to send (the
   full report is also copied to your clipboard). Or **Copy report** to paste it into a chat,
   or **Open log folder** to attach the log file.

JJ fixes it and publishes an update; you click **Upgrade** in the Plugin Manager and carry on.

## I. Other troubleshooting

- **Menu is greyed out / a yellow "Not activated" banner** → you haven't activated yet:
  Velocity Fibre → About & Activation → enter the password.
- **"Velocity Fibre" menu missing** → the plugin isn't enabled: Plugins → Manage and Install
  Plugins → Installed → tick **Velocity Fibre Automation**.
- **A tool says a server/package is missing** → that's an advanced tool (Section G); the core
  tools still work. Ask JJ to set up the extras if you need them.
- **Check your version** → Velocity Fibre → About & Activation shows the version + activation
  state.

---

*Anything odd? Use 🐞 Report a Problem — that captures everything support needs.*
