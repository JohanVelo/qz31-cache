# -*- coding: utf-8 -*-
# "Remove Grid Blocks" — the menu JJ asked for (2026-09-30): tick the blocks to drop, see
# "17 → 15 blocks · 16 pages", Apply. The rest are renumbered 1..K, the overview loses the
# removed frames, and the atlas never visits their pages. "Restore all" puts them back.
#
# Opened from a button on the Print Layout designer's toolbar (installed for every designer,
# shown only on a grid atlas this tool can edit) and from the Generate HLD PDF dialog.
# Kill switch: QSettings "vf/hld/grid_remover_button" = "off" hides the designer button.
# All edits go through grid_edit.py, which refuses (changing nothing) anything it cannot
# prove is a grid atlas built by Velocity Nexus.
from qgis.PyQt.QtCore import Qt, QSettings
from qgis.PyQt.QtWidgets import (QDialog, QDialogButtonBox, QHBoxLayout, QLabel,
                                 QListWidget, QListWidgetItem, QMessageBox, QPushButton,
                                 QVBoxLayout)

from . import grid_edit as GE

SWITCH_KEY = "vf/hld/grid_remover_button"
ACTION_NAME = "vfRemoveGridBlocks"
TOOLBAR_NAME = "vfGridBlocksToolbar"


def _theme():
    try:
        try:
            from .. import theme_safe
        except ImportError:
            import theme_safe
        return theme_safe.colors()
    except Exception:
        return {"ink": "", "muted": "", "accent": "", "warn": "", "ok": "", "bad": ""}


class GridBlocksDialog(QDialog):
    """Tick list of the blocks printed on the overview now; Apply / Restore all."""

    def __init__(self, layout, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self.setWindowTitle("Remove Grid Blocks — %s" % layout.name())
        self._layout = layout
        self.changed = False
        c = _theme()
        v = QVBoxLayout(self)
        intro = QLabel("Tick the blocks to remove. The rest are renumbered in order, the "
                       "overview drops the removed blocks and the page count follows.")
        intro.setWordWrap(True)
        v.addWidget(intro)
        self.list = QListWidget(self)
        self.list.itemChanged.connect(self._update_preview)
        v.addWidget(self.list, 1)
        self.preview = QLabel("")
        self.preview.setStyleSheet(("color:%s;" % c["accent"] if c["accent"] else "")
                                   + "font-weight:bold;")
        v.addWidget(self.preview)
        row = QHBoxLayout()
        self.restore_btn = QPushButton("Restore all blocks")
        self.restore_btn.clicked.connect(self._restore)
        row.addWidget(self.restore_btn)
        row.addStretch(1)
        v.addLayout(row)
        bb = QDialogButtonBox(self)
        self.apply_btn = bb.addButton("Remove ticked blocks",
                                      QDialogButtonBox.ButtonRole.AcceptRole)
        bb.addButton(QDialogButtonBox.StandardButton.Close)
        self.apply_btn.clicked.connect(self._apply)
        bb.rejected.connect(self.reject)
        v.addWidget(bb)
        self.resize(360, 520)
        self._reload()

    # ── state ────────────────────────────────────────────────────────────────
    def _reload(self):
        self.list.blockSignals(True)
        self.list.clear()
        try:
            blocks = GE.current_blocks(self._layout)
        except GE.RemovalError as e:
            blocks = []
            self.preview.setText(str(e))
        for n in blocks:
            it = QListWidgetItem("Block %d" % n)
            it.setData(Qt.ItemDataRole.UserRole, n)
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(Qt.CheckState.Unchecked)
            self.list.addItem(it)
        self.list.blockSignals(False)
        self._blocks = blocks
        try:
            has_original = bool(self._layout.atlas().coverageLayer()
                                .customProperty(GE.ORIGINAL_KEY))
        except Exception:
            has_original = False
        self.restore_btn.setEnabled(has_original)
        if blocks:
            self._update_preview()
        self.apply_btn.setEnabled(False)

    def ticked(self):
        return [self.list.item(i).data(Qt.ItemDataRole.UserRole)
                for i in range(self.list.count())
                if self.list.item(i).checkState() == Qt.CheckState.Checked]

    def _update_preview(self, *_a):
        n, r = len(self._blocks), len(self.ticked())
        k = n - r
        if r == 0:
            self.preview.setText("%d blocks · %d pages" % (n, n + 1))
        elif k < 1:
            self.preview.setText("Keep at least one block.")
        else:
            self.preview.setText("%d → %d blocks · %d pages" % (n, k, k + 1))
        self.apply_btn.setEnabled(0 < r < n)

    # ── actions ──────────────────────────────────────────────────────────────
    def _apply(self):
        nums = self.ticked()                       # read before anything can close us
        try:
            res = GE.remove_blocks(self._layout, nums)
        except GE.RemovalError as e:
            QMessageBox.warning(self, "Remove Grid Blocks", str(e))
            return
        self.changed = True
        self._reload()
        self.preview.setText("Done: %d → %d blocks · %d pages"
                             % (res["before"], res["after"], res["pages"]))

    def _restore(self):
        try:
            res = GE.restore_all(self._layout)
        except GE.RemovalError as e:
            QMessageBox.warning(self, "Remove Grid Blocks", str(e))
            return
        self.changed = True
        self._reload()
        self.preview.setText("Restored: %d blocks · %d pages" % (res["after"], res["pages"]))


def open_dialog(layout, parent=None):
    from qgis.PyQt import sip
    if layout is None or sip.isdeleted(layout):
        QMessageBox.information(parent, "Remove Grid Blocks",
                                "That layout no longer exists — it was rebuilt or closed.")
        return
    dlg = GridBlocksDialog(layout, parent)
    dlg.exec()


def grid_atlas_layouts(project=None):
    """Every print layout in the project whose atlas is a stamped grid book."""
    from qgis.core import QgsProject, QgsPrintLayout
    project = project or QgsProject.instance()
    return [l for l in project.layoutManager().layouts()
            if isinstance(l, QgsPrintLayout) and _is_grid_atlas(l)]


def open_for_project(parent=None):
    """Entry from the Generate HLD PDF dialog: pick the grid atlas, then open the menu."""
    from qgis.PyQt.QtWidgets import QInputDialog
    books = grid_atlas_layouts()
    if not books:
        QMessageBox.information(parent, "Remove Grid Blocks",
                                "No grid atlas in this project yet. Build one with "
                                "“Open in Print Layout”, then remove blocks.")
        return
    layout = books[0]
    if len(books) > 1:
        names = [b.name() for b in books]
        name, ok = QInputDialog.getItem(parent, "Remove Grid Blocks", "Which atlas?",
                                        names, 0, False)
        if not ok:
            return
        layout = books[names.index(name)]
    open_dialog(layout, parent)


# ── Print Layout designer button ─────────────────────────────────────────────
def _enabled():
    try:
        return str(QSettings().value(SWITCH_KEY, "on")).lower() != "off"
    except Exception:
        return True


def _is_grid_atlas(layout):
    """A stamped book whose build also made a numbered grid (PON / zone books have none)."""
    try:
        from qgis.core import QgsProject
        cov = layout.atlas().coverageLayer()
        if cov is None or cov.customProperty(GE.ROLE_KEY) != "book_pages":
            return False
        build = cov.customProperty(GE.BUILD_KEY)
        return bool(build) and any(
            l.customProperty(GE.ROLE_KEY) == "grid" and l.customProperty(GE.BUILD_KEY) == build
            for l in QgsProject.instance().mapLayers().values())
    except Exception:
        return False


def add_designer_button(designer):
    """Put "Remove Grid Blocks" on this designer's toolbar if its layout is a grid atlas."""
    try:
        from qgis.PyQt.QtGui import QAction
        from qgis.PyQt.QtWidgets import QToolBar
        layout = designer.layout() if hasattr(designer, "layout") else None
        win = designer.window() if hasattr(designer, "window") else None
        if layout is None or win is None or not _is_grid_atlas(layout):
            return
        if win.findChild(QToolBar, TOOLBAR_NAME) is not None:
            return                                  # already there
        tb = QToolBar("Grid blocks", win)
        tb.setObjectName(TOOLBAR_NAME)
        act = QAction("Remove Grid Blocks…", win)
        act.setObjectName(ACTION_NAME)
        act.setToolTip("Tick grid blocks to remove from this atlas; the rest are "
                       "renumbered and the page count follows.")
        act.triggered.connect(lambda *_a: open_dialog(layout, win))
        tb.addAction(act)
        win.addToolBar(Qt.ToolBarArea.TopToolBarArea, tb)
    except Exception as e:
        print("Remove Grid Blocks button skipped:", e)


class DesignerHook:
    """Connects to iface.layoutDesignerOpened and also serves designers already open."""

    def __init__(self, iface):
        self.iface = iface
        self._connected = False

    def install(self):
        if not _enabled() or self._connected:
            return
        try:
            self.iface.layoutDesignerOpened.connect(add_designer_button)
            self._connected = True
            for d in self.iface.openLayoutDesigners() or []:
                add_designer_button(d)
        except Exception as e:
            print("Remove Grid Blocks hook skipped:", e)

    def uninstall(self):
        if not self._connected:
            return
        try:
            from qgis.PyQt import sip
            if not sip.isdeleted(self.iface.mainWindow()):
                self.iface.layoutDesignerOpened.disconnect(add_designer_button)
        except Exception as e:
            print("Remove Grid Blocks unhook:", e)
        self._connected = False
