"""Labeling Wizard — orchestration engine (Structure mode).

Ties the pure-Python graph + numbering core to the QGIS project:

    build_graph (structure_graph)  ->  traverse  ->  assign_labels (numbering)

The heavy work is split so the graph/number CORE runs on plain data (dicts) and
is unit-testable with no QGIS, while a thin lazy-QGIS layer extracts that data
from layers and writes labels back.

Structure is FULLY customizable per project (see numbering.HierarchyConfig):
nothing here hardcodes a client's tiers.  Two scoping modes:

* ZONED   — when a zone polygon layer + per-point zone field are bound, the
            network is partitioned per zone and each zone walked from its own
            root.  This is exact + fast (each zone's graph is tiny) and stops
            one zone's root from wandering into a neighbour ("zone bleed").
* GLOBAL  — no zone binding: one graph, every configured root, single walk.

A single dry_run() drives BOTH the preview and the apply, so what you see is
exactly what gets written.  Nothing is written until apply() is called.
"""
try:                                    # sibling modules (package or flat copy)
    from . import structure_graph as sg
    from . import numbering as nb
except ImportError:                     # pragma: no cover - flat fibre_automation
    import structure_graph as sg
    import numbering as nb

DEG_PER_M = sg.DEG_PER_M


# ---------------------------------------------------------------------------
# geometry helpers (plain python; shared with the harness)
# ---------------------------------------------------------------------------

def _pip(x, y, ring):
    """Ray-cast point-in-polygon."""
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if ((yi > y) != (yj > y)) and \
                (x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-12) + xi):
            inside = not inside
        j = i
    return inside


def zone_of_xy(xy, zones):
    """Id of the first zone polygon (sorted by str id) containing xy."""
    for z in sorted(zones, key=lambda z: str(z.get("id"))):
        for ring in z.get("rings", ()):
            if len(ring) >= 3 and _pip(xy[0], xy[1], ring):
                return z.get("id")
    return None


def _midpoint(coords):
    return coords[len(coords) // 2]


def _seg_ends(coords):
    return (coords[0], coords[-1])


# ---------------------------------------------------------------------------
# core: partition + run  (plain data in, labels out)
# ---------------------------------------------------------------------------

def _root_role(config):
    roots = config.roots()
    return roots[0].cls_or_role if roots else None


def partition_by_zone(segments, points, zones, config):
    """Split the network into per-zone sub-problems.

    Points carry an explicit ``attrs["zone"]`` (the wizard's zone field).  A
    cable is assigned to the zone whose polygon contains its midpoint.  Each
    zone's root = the root-level point nearest that zone's cable endpoints
    (a cable end lands on the root device), falling back to the zone-point
    centroid.  Returns list of dicts: {zone, segments, points, root_id}.
    """
    root_role = _root_role(config)
    roots = [p for p in points if str(p.get("role")) == str(root_role)]
    non_root_pts = [p for p in points if str(p.get("role")) != str(root_role)]

    # the cable class(es) that connect directly to the root (its cable children)
    # — the root sits on ONE of these cable ends, so root-picking uses only
    # these, not drop ends scattered across the zone.
    root_levels = config.roots()
    seg_classes = {s.get("cls") for s in segments}
    root_cable_cls = set()
    if root_levels:
        for c in config.children_of(root_levels[0].name):
            if getattr(c, "kind", "auto") == "cable" or c.cls_or_role in seg_classes:
                root_cable_cls.add(c.cls_or_role)

    # cable -> zone by midpoint polygon (precomputed once)
    seg_zone = {}
    for s in segments:
        co = s.get("coords") or []
        seg_zone[id(s)] = zone_of_xy(_midpoint(co), zones) if len(co) >= 1 else None

    zone_ids = sorted({z.get("id") for z in zones},
                      key=lambda z: (z is None, str(z)))
    out = []
    for Z in zone_ids:
        zpts = [p for p in non_root_pts if p.get("attrs", {}).get("zone") == Z]
        zsegs = [s for s in segments if seg_zone[id(s)] == Z]
        if not zpts and not zsegs:
            continue
        # root-connecting cables only (fall back to all if none of that class)
        root_segs = [s for s in zsegs if s.get("cls") in root_cable_cls] or zsegs
        root = _pick_root(roots, root_segs, zpts)
        if root is not None:
            r = dict(root)
            r["attrs"] = dict(r.get("attrs") or {})
            r["attrs"]["zone"] = Z          # feed the {zone} label token
            zpts_full = [r] + zpts
            root_id = r.get("id")
        else:
            zpts_full = zpts
            root_id = None
        out.append({"zone": Z, "segments": zsegs, "points": zpts_full,
                    "root_id": root_id})
    return out


def _pick_root(roots, zsegs, zpts):
    if not roots:
        return None
    ends = [e for s in zsegs for e in _seg_ends(s.get("coords") or [None, None])
            if e is not None]
    if ends:
        return min(roots, key=lambda p: min(
            (p["xy"][0] - e[0]) ** 2 + (p["xy"][1] - e[1]) ** 2 for e in ends))
    if zpts:
        cx = sum(p["xy"][0] for p in zpts) / len(zpts)
        cy = sum(p["xy"][1] for p in zpts) / len(zpts)
        return min(roots, key=lambda p: (p["xy"][0] - cx) ** 2
                   + (p["xy"][1] - cy) ** 2)
    return roots[0]


def run_structure(segments, points, zones, config, *, snap_m=2.0, tap_m=8.0,
                  cable_tap_m=6.0):
    """Walk + number the whole network.  Returns (labels, anomalies, meta).

    labels    : {feature_id: label | None}
    anomalies : merged anomaly dicts across all zones/walks
    meta      : {"zoned": bool, "zones": [{zone, root_id, walks, coverage}...]}
    """
    zoned = bool(zones) and any(
        p.get("attrs", {}).get("zone") is not None for p in points)
    labels = {}
    anomalies = []
    zmeta = []

    if zoned:
        for part in partition_by_zone(segments, points, zones, config):
            roots = [part["root_id"]] if part["root_id"] is not None else []
            g = sg.build_graph(part["segments"], part["points"],
                               snap_m=snap_m, tap_m=tap_m, cable_tap_m=cable_tap_m)
            walks, anoms = sg.traverse(g, roots, config)
            zlabels = nb.assign_labels((walks, anoms), config)
            labels.update(zlabels)
            anomalies.extend(anoms)
            zmeta.append({"zone": part["zone"], "root_id": part["root_id"],
                          "walks": walks,
                          "labeled": sum(1 for v in zlabels.values() if v)})
    else:
        root_role = _root_role(config)
        roots = [p.get("id") for p in points
                 if str(p.get("role")) == str(root_role)]
        g = sg.build_graph(segments, points, snap_m=snap_m, tap_m=tap_m,
                           cable_tap_m=cable_tap_m)
        walks, anoms = sg.traverse(g, roots, config)
        labels = nb.assign_labels((walks, anoms), config)
        anomalies = anoms
        zmeta.append({"zone": None, "root_id": None, "walks": walks,
                      "labeled": sum(1 for v in labels.values() if v)})

    return labels, anomalies, {"zoned": zoned, "zones": zmeta}


def dry_run(segments, points, zones, config, *, existing=None, snap_m=2.0,
            tap_m=8.0, cable_tap_m=6.0):
    """Preview a relabel without writing.  Returns a summary dict.

    {labels, anomalies, changes, duplicates, gaps, collisions, coverage, meta}
    coverage = {total, labeled, flagged} counted over configured features.
    """
    existing = existing or {}
    labels, anomalies, meta = run_structure(
        segments, points, zones, config,
        snap_m=snap_m, tap_m=tap_m, cable_tap_m=cable_tap_m)
    summary = nb.dry_run_summary(labels, existing)
    total = len(labels)
    labeled = sum(1 for v in labels.values() if v)
    return {
        "labels": labels, "anomalies": anomalies, "meta": meta,
        "changes": summary["changes"], "duplicates": summary["duplicates"],
        "gaps": summary["gaps"], "collisions": summary["collisions"],
        "coverage": {"total": total, "labeled": labeled,
                     "flagged": total - labeled},
    }


# ---------------------------------------------------------------------------
# QGIS layer bindings + extract / apply  (lazy import — no QGIS needed above)
# ---------------------------------------------------------------------------

class LevelBinding:
    """Maps ONE hierarchy level to a QGIS layer + fields.

    level      : the Level.name it feeds.
    layer      : QgsVectorLayer.
    id_field   : unique feature id field (or "$id" for the native fid).
    label_field: field to write the label into (None = map-labels only).
    zone_field : optional field carrying the zone id (points).
    """
    def __init__(self, level, layer, *, id_field="$id", label_field=None,
                 zone_field=None):
        self.level = level
        self.layer = layer
        self.id_field = id_field
        self.label_field = label_field
        self.zone_field = zone_field


def _coords_of(geom):
    if not geom or geom.isEmpty():
        return None
    if geom.isMultipart():
        pts = [q for part in geom.asMultiPolyline() for q in part]
    else:
        pts = geom.asPolyline()
    if len(pts) < 2:
        return None
    return [(p.x(), p.y()) for p in pts]


def _rings_of(geom):
    rings = []
    polys = geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]
    for poly in polys:
        for ring in poly:
            rings.append([(p.x(), p.y()) for p in ring])
    return rings


def _fid_value(feat, id_field):
    return feat.id() if id_field in ("$id", None, "") else feat[id_field]


def extract(bindings, config, *, zone_layer=None, zone_id_field="zone_id",
            size_field=None):
    """Read the bound layers into plain (segments, points, zones).

    A feature id becomes ("<level>", <id_value>) so ids never collide across
    layers.  Cable vs point is decided by the level's kind / geometry.
    """
    from qgis.core import QgsWkbTypes  # noqa: F401 (lazy)
    seg_classes = set()
    pt_roles = set()
    for lv in config.levels:
        k = getattr(lv, "kind", "auto")
        if k == "cable":
            seg_classes.add(lv.cls_or_role)
        elif k == "point":
            pt_roles.add(lv.cls_or_role)

    segments, points = [], []
    for b in bindings:
        lv = config.level(b.level)
        is_cable = (lv.cls_or_role in seg_classes) or (
            lv.kind == "auto" and b.layer.geometryType() == 1)
        for f in b.layer.getFeatures():
            g = f.geometry()
            fid = _fid_value(f, b.id_field)
            if is_cable:
                co = _coords_of(g)
                if co is None:
                    continue
                sz = 0
                if size_field:
                    try:
                        sz = float(f[size_field] or 0)
                    except (TypeError, ValueError):
                        sz = 0
                segments.append({"id": (b.level, fid), "cls": lv.cls_or_role,
                                 "coords": co, "size": sz,
                                 "attrs": {"fid": f.id()}})
            else:
                if not g or g.isEmpty():
                    continue
                pt = g.asPoint()
                attrs = {"fid": f.id()}
                if b.zone_field:
                    attrs["zone"] = f[b.zone_field]
                points.append({"id": (b.level, fid), "role": lv.cls_or_role,
                               "xy": (pt.x(), pt.y()), "attrs": attrs})

    zones = []
    if zone_layer is not None:
        for f in zone_layer.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            zones.append({"id": f[zone_id_field], "rings": _rings_of(g)})
    return segments, points, zones


def apply_labels(bindings, labels, config, *, only_changed=True):
    """Write labels into each level's label_field via ONE bulk provider write
    per layer (never per-feature edit).  Returns undo = {(level,fid): old}.

    Features whose label is None are skipped (kept as-is) so the engine never
    overwrites a value with a guess.  Type-preserving.
    """
    undo = {}
    by_level = {}
    for (lvl, fid), lab in labels.items():
        by_level.setdefault(lvl, {})[fid] = lab
    for b in bindings:
        if not b.label_field:
            continue
        want = by_level.get(b.level)
        if not want:
            continue
        prov = b.layer.dataProvider()
        fidx = b.layer.fields().indexOf(b.label_field)
        if fidx < 0:
            continue
        changes = {}
        for f in b.layer.getFeatures():
            key = _fid_value(f, b.id_field)
            if key not in want:
                continue
            new = want[key]
            if new is None:
                continue
            old = f[b.label_field]
            if only_changed and old == new:
                continue
            undo[(b.level, key)] = old
            changes[f.id()] = {fidx: new}
        if changes:
            prov.changeAttributeValues(changes)
        b.layer.triggerRepaint()
    return undo


def dry_run_project(bindings, config, *, zone_layer=None,
                    zone_id_field="zone_id", size_field=None, **kw):
    """Extract from the live project, then dry_run().  existing labels are
    read from each bound label_field so changes/collisions are real."""
    segments, points, zones = extract(
        bindings, config, zone_layer=zone_layer,
        zone_id_field=zone_id_field, size_field=size_field)
    existing = {}
    for b in bindings:
        if not b.label_field:
            continue
        for f in b.layer.getFeatures():
            existing[(b.level, _fid_value(f, b.id_field))] = f[b.label_field]
    return dry_run(segments, points, zones, config, existing=existing, **kw)
