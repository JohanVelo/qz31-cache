try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

"""Native QGIS PAL label-placement factories for dense FTTH maps.

No 3rd-party engine — everything here configures QGIS's own labeling
(PAL) so hundreds of pole/splitter/cable labels stay readable on an HLD:
points get ordered candidate positions + leader callouts + anti-overlap;
cables get ONE curved label per merged run (the layers store chopped
pole-to-pole segments that share a label — merging is what makes a run
read as a single cable); heavy linework/buildings register as obstacles
that push point labels clear.

All Qt6/QGIS enums are FULLY SCOPED (Qgis.LabelPlacement.*,
Qgis.LabelOverlapHandling.*, Qgis.LabelingFlag.*, ...) and every API that
differs across QGIS builds is probed with getattr/hasattr, so nothing
here can hard-crash on load.  qgis imports are lazy (inside functions):
the module imports fine in plain Python 3.12 for tests.

API (each returns/acts ready-to-apply — see apply_labeling):
    dense_point_labels(field, *, priority=7, scale_min=None)
    cable_labels(field, *, priority=5, repeat_distance=0.0)
    register_as_obstacle(layer, factor=2.0)
    apply_labeling(layer, labeling)
    project_label_engine_settings(project=None)
"""


# ---------------------------------------------------------------------------
# guarded enum/API helpers
# ---------------------------------------------------------------------------

def _enum(owner, name):
    """Fully-scoped enum member, or None on builds that don't have it."""
    return getattr(owner, name, None)


def _or_flags(members):
    """OR together the non-None flag members ([] -> None)."""
    flags = None
    for m in members:
        if m is None:
            continue
        flags = m if flags is None else (flags | m)
    return flags


# ---------------------------------------------------------------------------
# point layers (poles / splitters / ONTs)
# ---------------------------------------------------------------------------

def dense_point_labels(field, *, priority=7, scale_min=None):
    """Labeling for dense point layers — poles, splitters, domes, ONTs.

    Rationale: OrderedPositionsAroundPoint lets PAL walk 8 candidate spots
    per point instead of stacking every label top-right; PreventOverlap +
    degraded placement keeps 100% of labels on the map without collisions;
    a Manhattan leader line ties a displaced label back to its point; the
    points themselves are obstacles so neighbours' labels keep clear.

    field     : attribute (or expression via isExpression on the returned
                settings) to label with.
    priority  : 0-10 PAL priority; point IDs default high (7) so they beat
                cable labels when space is tight.
    scale_min : if given, labels only draw when zoomed IN past
                1:scale_min (e.g. 5000 -> hidden at 1:10000).
    Returns a QgsVectorLayerSimpleLabeling ready for apply_labeling().
    """
    from qgis.core import (Qgis, QgsPalLayerSettings,
                           QgsVectorLayerSimpleLabeling)

    settings = QgsPalLayerSettings()
    settings.fieldName = field
    settings.drawLabels = True
    settings.priority = int(priority)

    # ordered candidate positions around the point
    placement = _enum(_enum(Qgis, "LabelPlacement"),
                      "OrderedPositionsAroundPoint")
    if placement is not None:
        settings.placement = placement

    # point-specific knobs (QgsLabelPointSettings — newer QGIS builds)
    if hasattr(settings, "pointSettings"):
        point = settings.pointSettings()
        if hasattr(point, "setMaximumDistance"):
            point.setMaximumDistance(8.0)  # let PAL slide a label up to 8mm
            unit = _enum(_enum(Qgis, "RenderUnit"), "Millimeters")
            if unit is not None and hasattr(point, "setMaximumDistanceUnit"):
                point.setMaximumDistanceUnit(unit)
        pos_enum = _enum(Qgis, "LabelPredefinedPointPosition")
        if pos_enum is not None and hasattr(point,
                                            "setPredefinedPositionOrder"):
            order = [_enum(pos_enum, n) for n in (
                "TopRight", "TopLeft", "BottomRight", "BottomLeft",
                "MiddleRight", "MiddleLeft", "TopMiddle", "BottomMiddle")]
            order = [p for p in order if p is not None]
            if order:
                point.setPredefinedPositionOrder(order)
        if hasattr(settings, "setPointSettings"):
            settings.setPointSettings(point)

    # never draw two labels on top of each other; degrade before dropping
    if hasattr(settings, "placementSettings"):
        place = settings.placementSettings()
        overlap = _enum(_enum(Qgis, "LabelOverlapHandling"), "PreventOverlap")
        if overlap is not None and hasattr(place, "setOverlapHandling"):
            place.setOverlapHandling(overlap)
        if hasattr(place, "setAllowDegradedPlacement"):
            place.setAllowDegradedPlacement(True)
        if hasattr(settings, "setPlacementSettings"):
            settings.setPlacementSettings(place)

    # the points themselves block other labels
    if hasattr(settings, "obstacleSettings"):
        obstacle = settings.obstacleSettings()
        if hasattr(obstacle, "setIsObstacle"):
            obstacle.setIsObstacle(True)
        if hasattr(settings, "setObstacleSettings"):
            settings.setObstacleSettings(obstacle)

    # Manhattan leader line so a displaced label points home
    try:
        from qgis.core import QgsManhattanLineCallout
        callout = QgsManhattanLineCallout()
        callout.setEnabled(True)
        if hasattr(callout, "setMinimumLength"):
            callout.setMinimumLength(1.5)  # no stub leaders on tiny offsets
        settings.setCallout(callout)       # settings takes ownership
    except Exception:                      # callout API unavailable — labels
        _swallowed_note()                               # still place fine without leaders

    if scale_min:
        settings.scaleVisibility = True
        # minimumScale = the most zoomed-OUT scale labels remain visible at
        settings.minimumScale = float(scale_min)

    return QgsVectorLayerSimpleLabeling(settings)


# ---------------------------------------------------------------------------
# cable layers (drops / distribution / feeders)
# ---------------------------------------------------------------------------

def cable_labels(field, *, priority=5, repeat_distance=0.0):
    """Curved labels for cable layers, ONE label per connected run.

    Rationale: cable layers are chopped into pole-to-pole segments that all
    share a label — setMergeLines(True) is CRITICAL: PAL joins touching
    same-label segments and labels the whole RUN once instead of stamping
    the label on every 50 m stick.  Curved + AboveLine|MapOrientation reads
    like a drafted plan; a small overrun lets short runs still label.

    field           : attribute holding the run label.
    priority        : 0-10; cables default below point labels (5).
    repeat_distance : >0 repeats the label every N mm along very long runs
                      (0 = single label per run — the default).
    Returns a QgsVectorLayerSimpleLabeling ready for apply_labeling().
    """
    from qgis.core import (Qgis, QgsPalLayerSettings,
                           QgsVectorLayerSimpleLabeling)

    settings = QgsPalLayerSettings()
    settings.fieldName = field
    settings.drawLabels = True
    settings.priority = int(priority)

    placement = _enum(_enum(Qgis, "LabelPlacement"), "Curved")
    if placement is not None:
        settings.placement = placement

    if hasattr(settings, "lineSettings"):
        line = settings.lineSettings()
        if hasattr(line, "setMergeLines"):
            line.setMergeLines(True)       # segments sharing a label = 1 run
        flag_enum = _enum(Qgis, "LabelLinePlacementFlag")
        if flag_enum is not None and hasattr(line, "setPlacementFlags"):
            flags = _or_flags([_enum(flag_enum, "AboveLine"),
                               _enum(flag_enum, "MapOrientation")])
            if flags is not None:
                line.setPlacementFlags(flags)
        if hasattr(line, "setOverrunDistance"):
            line.setOverrunDistance(2.0)   # mm past the end for short runs
        if hasattr(settings, "setLineSettings"):
            settings.setLineSettings(line)

    if repeat_distance and repeat_distance > 0:
        settings.repeatDistance = float(repeat_distance)

    if hasattr(settings, "placementSettings"):
        place = settings.placementSettings()
        overlap = _enum(_enum(Qgis, "LabelOverlapHandling"), "PreventOverlap")
        if overlap is not None and hasattr(place, "setOverlapHandling"):
            place.setOverlapHandling(overlap)
        if hasattr(settings, "setPlacementSettings"):
            settings.setPlacementSettings(place)

    return QgsVectorLayerSimpleLabeling(settings)


# ---------------------------------------------------------------------------
# obstacle-only layers + apply helpers
# ---------------------------------------------------------------------------

def register_as_obstacle(layer, factor=2.0):
    """Make a layer an obstacle WITHOUT labeling it.

    Rationale: cables/buildings registered as obstacles push point labels
    off the linework so pole numbers never sit on top of a cable.  Draws
    nothing itself (drawLabels=False) — but labelsEnabled must stay True
    or PAL never sees the obstacle geometry.

    factor : obstacle weight; 1.0 = normal, ~1.5-2.0 = strongly avoided.
    """
    from qgis.core import QgsPalLayerSettings, QgsVectorLayerSimpleLabeling

    settings = QgsPalLayerSettings()
    settings.drawLabels = False            # obstacle only — no text
    if hasattr(settings, "obstacleSettings"):
        obstacle = settings.obstacleSettings()
        if hasattr(obstacle, "setIsObstacle"):
            obstacle.setIsObstacle(True)
        if hasattr(obstacle, "setFactor"):
            obstacle.setFactor(float(factor))
        if hasattr(settings, "setObstacleSettings"):
            settings.setObstacleSettings(obstacle)

    layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
    layer.setLabelsEnabled(True)           # required — else PAL skips layer
    layer.triggerRepaint()


def apply_labeling(layer, labeling):
    """Apply a labeling object built above and refresh the canvas."""
    layer.setLabeling(labeling)
    layer.setLabelsEnabled(True)
    layer.triggerRepaint()


def project_label_engine_settings(project=None):
    """Project-wide PAL settings for clean HLD PDFs.

    Rationale: unplaced labels render as ugly red-highlighted overlaps in
    exports — suppress them; PreventOverlap layers already guarantee what
    IS drawn doesn't collide.
    """
    from qgis.core import Qgis, QgsProject

    if project is None:
        project = QgsProject.instance()
    engine = project.labelingEngineSettings()
    flag = _enum(_enum(Qgis, "LabelingFlag"), "DrawUnplacedLabels")
    if flag is not None:
        engine.setFlag(flag, False)
    project.setLabelingEngineSettings(engine)
    return engine
