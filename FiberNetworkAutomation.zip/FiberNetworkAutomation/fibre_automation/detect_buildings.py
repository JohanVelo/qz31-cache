﻿"""detect_buildings — reusable building-footprint detection for ANY project AOI.

The PROVEN approach (validated on Mohadin: 21,252 footprints, near-perfect roof coverage):
Google Open Buildings / Overture footprints — Google's model trained on millions of dense
African buildings, so it generalises to wall-to-wall townships where a from-scratch U-Net floods.
Optional --crisp orthogonalises footprints to a neat cadastral look.

Usage (run in qgis-venv):
  python detect_buildings.py --aoi C:/Temp/aoi.geojson --out C:/Temp/detected_buildings.geojson [--crisp]
  python detect_buildings.py --bbox 27.0325 -26.7399 27.0648 -26.7102 --out ... [--crisp]

The /detect-buildings skill: reads the project AOI via the bridge → runs this → loads the
result as the `Buildings` layer. See .claude/commands/detect-buildings.md.
"""
import argparse
import json
import subprocess
import sys
from pathlib import Path

WORKER = str(Path(__file__).parent / "vuma" / "_fetch_worker.py")
CFG_FILE = r"C:/Temp/_vuma_fetch_cfg.json"
BUILDINGS_OUT = r"C:/Temp/vuma_buildings.geojson"


def _venv_python() -> str:
    cand = Path.home() / ".qgis-venv" / "Scripts" / "python.exe"
    return str(cand) if cand.exists() else sys.executable


def _aoi_to_bbox_and_geojson(aoi_path):
    import geopandas as gpd
    g = gpd.read_file(aoi_path).to_crs(4326)
    minx, miny, maxx, maxy = g.total_bounds
    return [float(minx), float(miny), float(maxx), float(maxy)], g.to_json()


def crisp_rectangles(gdf, rect_thresh=0.62, inset_m=0.4):
    """Area-matched min-rotated-rectangle for footprints that are already ~rectangular.
    Non-rectangular footprints kept as-is. Light orthogonal polish, no per-block snap."""
    from shapely.affinity import scale
    m = gdf.to_crs(32735).copy()
    out = []
    for geom in m.geometry:
        if geom is None or geom.is_empty:
            out.append(geom); continue
        poly = geom if geom.geom_type == "Polygon" else max(geom.geoms, key=lambda p: p.area)
        mrr = poly.minimum_rotated_rectangle
        if mrr.area <= 0:
            out.append(geom); continue
        fill = poly.area / mrr.area               # how rectangular the footprint is
        if fill >= rect_thresh:
            # area-match the rectangle to the footprint, then inset slightly
            f = (poly.area / mrr.area) ** 0.5
            r = scale(mrr, xfact=f, yfact=f, origin="center")
            if inset_m > 0:
                b = r.buffer(-inset_m, join_style=2)
                r = b if (not b.is_empty and b.geom_type == "Polygon") else r
            out.append(r if not r.is_empty else poly)
        else:
            out.append(poly)
    m["geometry"] = out
    return m.set_geometry("geometry").to_crs(4326)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--aoi", help="AOI polygon file (any OGR format, reprojected to 4326)")
    ap.add_argument("--bbox", nargs=4, type=float, metavar=("MINX", "MINY", "MAXX", "MAXY"))
    ap.add_argument("--out", default="C:/Temp/detected_buildings.geojson")
    ap.add_argument("--crisp", action="store_true", help="orthogonalise footprints (cadastral look)")
    ap.add_argument("--one-per-erf", action="store_true",
                    help="keep only the largest building per surveyed erf (needs --erven)")
    ap.add_argument("--erven", help="erven/cadastral polygon file for --one-per-erf")
    ap.add_argument("--drop-standalone", action="store_true",
                    help="with --one-per-erf, also drop buildings outside every surveyed stand")
    args = ap.parse_args()
    if args.one_per_erf and not args.erven:
        ap.error("--one-per-erf requires --erven <cadastral polygons>")

    if args.aoi:
        bbox, aoi_geojson = _aoi_to_bbox_and_geojson(args.aoi)
    elif args.bbox:
        bbox, aoi_geojson = args.bbox, None
    else:
        ap.error("provide --aoi or --bbox")

    print(f"[detect] AOI bbox {bbox}")
    cfg = {"bbox_4326": bbox, "fetch_erven": False, "fetch_buildings": True,
           "aoi_geojson": aoi_geojson}
    Path(CFG_FILE).write_text(json.dumps(cfg), encoding="utf-8")

    print("[detect] downloading footprints (Google Open Buildings / Overture) ...")
    r = subprocess.run([_venv_python(), WORKER], capture_output=True, text=True)
    print(r.stdout)
    if r.returncode != 0:
        print(r.stderr); sys.exit(1)

    import geopandas as gpd
    gdf = gpd.read_file(BUILDINGS_OUT)
    print(f"[detect] {len(gdf)} footprints downloaded")
    if len(gdf) == 0:
        print("[detect] no footprints — AOI may be outside coverage"); sys.exit(2)

    if args.crisp:
        before = len(gdf)
        gdf = crisp_rectangles(gdf)
        print(f"[detect] crisp-rectangled {before} footprints")

    if args.one_per_erf:
        from one_building_per_erf import cull_one_per_erf
        before = len(gdf)
        gdf = cull_one_per_erf(gdf, args.erven, drop_standalone=args.drop_standalone)
        print(f"[detect] one-per-erf cull: {before} -> {len(gdf)} buildings")

    gdf.to_file(args.out, driver="GeoJSON")
    print(f"[detect] WROTE {args.out}  ({len(gdf)} buildings)")


if __name__ == "__main__":
    main()
