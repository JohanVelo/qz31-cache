"""Vuma Step 1c — Place one centroid point per erven from primary buildings.

Runs automatically at the end of Step 1b (both background and sync paths).
Also callable standalone after Step 1b has populated Buildings + Erven.

STATUS: [x] BUILT
"""

# claude:approved-destructive

from qgis.core import (
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsSpatialIndex,
)


def _get(name):
    layers = QgsProject.instance().mapLayersByName(name)
    return layers[0] if layers else None


def vuma_step_01c_centroids():
    """Place one Demand Point centroid per erven from primary buildings.

    STATUS: [x] BUILT
    Safe to re-run — skips buildings whose centroid is already in Demand Points.

    Name = erven Label (erf number, e.g. "7868") — portable across all projects.
    pointOnSurface() guarantees the point lands inside even for L-shaped footprints.
    """
    print(f"\n{'═' * 50}")
    print("  VUMA STEP 1c — Home Centroids")
    print(f"{'═' * 50}")

    bld_lyr   = _get("Buildings")
    dp_lyr    = _get("Demand Points")
    erven_lyr = _get("Erven")

    if bld_lyr is None:
        print("  ✗ 'Buildings' layer not found — run Step 1 first.")
        return
    if dp_lyr is None:
        print("  ✗ 'Demand Points' layer not found — run Step 1 first.")
        return
    has_buildings = bld_lyr.featureCount() > 0
    has_erven     = erven_lyr is not None and erven_lyr.featureCount() > 0
    if not has_buildings and not has_erven:
        print("  ✗ No buildings or erven yet — run Step 1b first.")
        return
    if not has_buildings:
        print("  ℹ  No Overture buildings — using erven centroids as fallback.")

    prim_idx = bld_lyr.fields().indexOf("is_primary")

    # Build spatial index on erven for fast point-in-polygon lookup
    erven_by_fid    = {}
    erven_index     = None
    erven_label_idx = -1
    if erven_lyr and erven_lyr.featureCount() > 0:
        erven_label_idx = erven_lyr.fields().indexOf("Label")
        erven_by_fid    = {f.id(): f for f in erven_lyr.getFeatures()}
        erven_index     = QgsSpatialIndex()
        for f in erven_by_fid.values():
            erven_index.addFeature(f)

    # Build set of existing centroid positions to skip on re-run
    dp_fields  = dp_lyr.fields()
    f_name     = dp_fields.indexOf("Name")
    f_lat      = dp_fields.indexOf("Geo Latitu")
    f_lon      = dp_fields.indexOf("Geo Longit")
    f_erf      = dp_fields.indexOf("Geo Erf Nu")
    f_type     = dp_fields.indexOf("Type")
    f_status   = dp_fields.indexOf("Status")
    f_ntwk     = dp_fields.indexOf("Network Ty")
    f_build    = dp_fields.indexOf("Build Meth")
    f_premises = dp_fields.indexOf("Premises T")
    f_zone     = dp_fields.indexOf("Zone")
    f_conn     = dp_fields.indexOf("Connectabl")
    f_country  = dp_fields.indexOf("Geo Countr")

    existing_pts: set = set()
    for feat in dp_lyr.getFeatures():
        lat = feat[f_lat] if f_lat >= 0 else None
        lon = feat[f_lon] if f_lon >= 0 else None
        if lat is not None and lon is not None:
            existing_pts.add((round(float(lon), 5), round(float(lat), 5)))

    # Collect primary buildings not yet in Demand Points
    to_add = []  # list of (QgsPointXY, erf_label_or_None)
    for feat in bld_lyr.getFeatures():
        if not feat.hasGeometry():
            continue
        if prim_idx >= 0 and feat[prim_idx] != 1:
            continue
        pt  = feat.geometry().pointOnSurface().asPoint()
        key = (round(pt.x(), 5), round(pt.y(), 5))
        if key in existing_pts:
            continue

        # Spatial lookup: which erven does this building sit in?
        erf_label = None
        if erven_index is not None:
            pt_geom    = QgsGeometry.fromPointXY(pt)
            candidates = erven_index.intersects(pt_geom.boundingBox())
            for fid in candidates:
                if erven_by_fid[fid].geometry().contains(pt_geom):
                    raw = erven_by_fid[fid][erven_label_idx] if erven_label_idx >= 0 else None
                    erf_label = str(raw) if raw is not None else None
                    break

        to_add.append((pt, erf_label))

    # ── Erven fallback: any erf with no building gets a centroid anyway ──────
    # Overture misses many structures in informal settlements — every occupied
    # erf still needs a demand point for planning purposes.
    if erven_lyr and erven_index is not None:
        # Build set of erven already covered by the building-matched centroids
        covered_erf_labels: set = set()
        for pt, erf_label in to_add:
            if erf_label:
                covered_erf_labels.add(erf_label)
        # Also check existing demand points for covered erfs
        for feat in dp_lyr.getFeatures():
            erf_val = feat[f_erf] if f_erf >= 0 else None
            if erf_val:
                covered_erf_labels.add(str(erf_val))

        for fid, erf_feat in erven_by_fid.items():
            if not erf_feat.hasGeometry():
                continue
            raw_label = erf_feat[erven_label_idx] if erven_label_idx >= 0 else None
            erf_label = str(raw_label) if raw_label is not None else None
            if erf_label and erf_label in covered_erf_labels:
                continue  # already has a centroid
            pt = erf_feat.geometry().pointOnSurface().asPoint()
            key = (round(pt.x(), 5), round(pt.y(), 5))
            if key in existing_pts:
                continue
            to_add.append((pt, erf_label))

    if not to_add:
        n = dp_lyr.featureCount()
        print(f"  (all {n:,} centroids already placed — nothing to do)")
        print(f"{'═' * 50}\n")
        return

    # Sort north → south, west → east for deterministic output order
    to_add.sort(key=lambda x: (-x[0].y(), x[0].x()))

    # Sequential fallback counter for buildings that fall outside every erven
    next_seq = dp_lyr.featureCount() + 1

    new_features = []
    for pt, erf_label in to_add:
        nf = QgsFeature(dp_lyr.fields())
        nf.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(pt.x(), pt.y())))

        name_val = erf_label if erf_label else f"{next_seq:04d}"
        if not erf_label:
            next_seq += 1

        attrs = {}
        if f_name     >= 0: attrs[f_name]     = name_val
        if f_lat      >= 0: attrs[f_lat]      = round(pt.y(), 8)
        if f_lon      >= 0: attrs[f_lon]      = round(pt.x(), 8)
        if f_erf      >= 0: attrs[f_erf]      = erf_label or ""
        if f_type     >= 0: attrs[f_type]     = "SDU"
        if f_status   >= 0: attrs[f_status]   = "planned"
        if f_ntwk     >= 0: attrs[f_ntwk]     = "GPON"
        if f_build    >= 0: attrs[f_build]    = "Aerial"
        if f_premises >= 0: attrs[f_premises] = "Residentia"
        if f_zone     >= 0: attrs[f_zone]     = 1
        if f_conn     >= 0: attrs[f_conn]     = "Yes"
        if f_country  >= 0: attrs[f_country]  = "South Africa"
        for k, v in attrs.items():
            nf.setAttribute(k, v)
        new_features.append(nf)

    BATCH = 2000
    for i in range(0, len(new_features), BATCH):
        dp_lyr.dataProvider().addFeatures(new_features[i:i + BATCH])
    dp_lyr.updateExtents()
    dp_lyr.triggerRepaint()

    matched   = sum(1 for _, erf in to_add if erf)
    unmatched = len(to_add) - matched

    print("\n  ══ HOME CENTROIDS ══")
    print(f"  Centroids placed:  {len(new_features):,}")
    print(f"  From buildings:    {matched:,}")
    if unmatched:
        print(f"  Erf fallback:      {unmatched:,}  (no Overture building — erf centroid used)")
    print(f"  Total demand pts:  {dp_lyr.featureCount():,}")
    print(f"{'═' * 50}\n")
