"""manual_planning — interactive Fibertime planning toolkit (ported from fibretime_tools v1.0).

Phase 1 of the Velocity Nexus merge. The legacy plugin's FibretimeTools class is
reused wholesale for its 18 interactive tools (map tools, dialogs, business logic), but its
own toolbars are never built — instead `install_menu()` wires the tool handlers into the
unified Velocity Nexus menu.

Not exposed (per the Phase 0 sign-off):
  - Setup Project        → MERGED into the New Project wizard (DRDLR fetch + skip-done boxes)
  - HLD Compliance Audit → MERGED into audit_all_ph2 (unique checks folded in)
  - Check Long Spans     → RETIRED (covered by QA & Output ▸ Check Spans)
  - Logo widget          → assets harvested into branding/ (Phase 2)
"""

_INSTANCE = None


def get_tools(iface):
    """Singleton FibretimeTools instance (never builds its own toolbar)."""
    global _INSTANCE
    if _INSTANCE is None:
        from .fibretime_tools import FibretimeTools
        _INSTANCE = FibretimeTools(iface)
    return _INSTANCE


# (label, handler attr, tooltip) per the approved Phase 0 menu tree.
MENU_SPEC = [
    # Setup Project stays reachable here until the New Project wizard fully absorbs its
    # DRDLR cadastral fetch + skip-done checkboxes (Phase 0: MERGE, in progress).
    ('🏗️  Setup Project (layers + DRDLR erven + HCs)', 'run_setup_project',
     'One-shot legacy setup: standard Fibertime layers, DRDLR cadastral erf download, '
     'auto Home Connections from Overture. Checkboxes skip steps already done.'),
    None,
    ('🪧  Place Pole',               'run_quick_pole',       'Click-to-place distribution poles (auto attributes, road-blocked)'),
    ('🟡  Place AGG Dome',           'run_quick_agg_dome',   'Click near a pole — CMJ 144F AGG splice enclosure (snaps ≤30 m)'),
    ('🔵  Place STS Dome',           'run_quick_sts',        'Click near a pole — connectorised 1:8 STS splitter (snaps ≤30 m)'),
    ('⚡  Auto FTS+SS Splitters',    'run_auto_fts',         'Batch-place bare 1:16 FTS + spare SS at every AGG dome missing one'),
    ('⚡  Auto STS Splitters',       'run_auto_sts',         'Batch-place 1:8 LC/APC STS at every DIS dome missing one'),
    None,
    ('〰️  Draw Distribution Cable',  'run_quick_dist_cable', 'Click start pole → end pole — 24F Mini-ADSS with auto-labels'),
    ('🔵  Draw Primary Feeder',      'run_primary_feeder',   'Draw POP → AGG route; auto-places feeder poles, auto-sizes capacity'),
    ('🟠  Draw Secondary Feeder',    'run_secondary_feeder', 'Draw branch off the primary; same auto-pole spacing'),
    ('🤖  Auto-Plan Street Block',   'run_plan_block',       'Draw a midblock line — auto-places poles + STS + cable + drop groups'),
    None,
    ('⚡  Auto PON Boundaries',      'run_generate_pons',    'Morton Z-order clustering of erven — target 96 units per PON'),
    ('✏️  Draw PON',                 'run_quick_pon',        'Draw a single PON polygon; homes inside auto-counted'),
    ('⚡  Auto Zone Boundaries',     'run_generate_zones',   'Group PONs into zones (1 zone = 1 OLT card = 16 PONs)'),
    ('✏️  Draw Zone',                'run_quick_zone',       'Draw a single Zone polygon; PONs inside auto-counted'),
    None,
    ('🏠  Place Home Connections',   'run_hc_from_erven',    'One HC per erf from building/erf centroids (skips covered erven)'),
    ('🔗  Connect Drops',            'run_auto_drops',       'Connect unlinked homes to nearest STS (≤8 per dome, sequential DR)'),
    ('⚙️  Populate Attributes…',     'run_populate_pipeline', 'Step-by-step attribute fill for a hand-drawn network'),
    ('🏷️  Label Network',            'run_master_update',    'Fill all NULL labels across every layer (never overwrites)'),
]
# BOM + OES export live under QA & Output; Record PON Order under Tools (Phase 0 tree) —
# the main plugin wires those from get_tools() directly.


def install_menu(iface, parent_menu):
    """Add the Manual Planning actions to `parent_menu` (a QMenu). Returns the QMenu."""
    from qgis.PyQt.QtGui import QAction

    tools = get_tools(iface)
    menu = parent_menu.addMenu('✏️  Manual Planning')
    for entry in MENU_SPEC:
        if entry is None:
            menu.addSeparator()
            continue
        label, attr, tip = entry
        act = QAction(label, iface.mainWindow())
        act.setToolTip(tip)
        act.triggered.connect(getattr(tools, attr))
        menu.addAction(act)
    return menu
