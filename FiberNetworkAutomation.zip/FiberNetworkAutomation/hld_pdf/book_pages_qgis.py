# -*- coding: utf-8 -*-
"""HLD Book (custom pages) — every QGIS-side read and write.

A custom-pages book is ONE print layout with ONE atlas over a private virtual layer
(`vfbk_<id>_pages`). Each row of that layer is a page: the overview pages first, then one
row per PON, read live from the PON layer. A row's `page_ids` lists the layer ids that page
draws; the map's data-defined layer list turns those ids into current names when it draws
(a rename never drops a layer) and falls back to a private, empty guard layer so it can
never come out empty.

Nothing here edits a layer's data, style or labelling. Book-owned layers are private and
kept out of the Layers panel; their names start `vfbk_<12 hex>` so no engine role finder
can mistake them for network layers, and the engine skips anything carrying a book id.

Entry points used by the dialog, the designer hook and the tests:
    default_spec(cfg, project, phase=None)      -> spec dict
    build_or_update(cfg, spec, project=None)    -> (layout, message)
    update_book(layout, spec)                   -> layout
    check_book(layout)                          -> (hard[], soft[])  never raises
    backup_book / restore_book / rebuild_book / remove_book / clone_book
    reattach_pon / add_override / discard_override / reattach_override
"""
import json
import os
import time
from urllib.parse import quote

from qgis.core import (QgsProject, QgsVectorLayer, QgsRasterLayer, QgsMapLayer, QgsPrintLayout,
                       QgsLayoutItemMap, QgsLayoutItemLegend, QgsLayoutObject, QgsProperty,
                       QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsGeometry,
                       QgsPointXY, QgsRectangle, QgsNullSymbolRenderer, QgsPalLayerSettings,
                       QgsVectorLayerSimpleLabeling, QgsLayoutPoint, QgsLayoutSize, QgsUnitTypes,
                       QgsReadWriteContext, QgsWkbTypes)
from qgis.PyQt.QtCore import QMetaType

from . import book_pages as BP

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

HERE = os.path.dirname(os.path.abspath(__file__))
ENGINE = os.path.join(HERE, "hld_atlas_engine.py")
MM = QgsUnitTypes.LayoutUnit.LayoutMillimeters

# A3 landscape frame (same geometry as the engine's HLD frame, hld_atlas_engine.build_frame)
MAP = dict(x=6.0, y=28.0, w=322.0, h=263.0)
SB_W = 80.0
SB_X = round(MAP["x"] + MAP["w"] + (417.0 - (MAP["x"] + MAP["w"]) - SB_W) / 2.0, 1)
PAGE_H = 297.0
TITLE_BLOCK_H = 46.0
NOTE_H = 24.0


# ── small helpers ──────────────────────────────────────────────────────────────────────
def _mm_pt(x, y):
    return QgsLayoutPoint(float(x), float(y), MM)


def _mm_sz(w, h):
    return QgsLayoutSize(float(w), float(h), MM)


def engine_ns(cfg):
    """The engine's namespace with `cfg` merged — defines only, builds nothing."""
    ns = {"HLD_CFG": dict(cfg or {})}
    with open(ENGINE, encoding="utf-8") as f:
        exec(compile(f.read(), ENGINE, "exec"), ns)
    return ns


def is_book_layer(layer):
    try:
        return bool(layer.customProperty(BP.PROP_BOOK_ID))
    except Exception:
        return False


def is_book_layout(layout):
    try:
        return BP.is_book_id(layout.customProperty(BP.PROP_BOOK_ID))
    except Exception:
        return False


def names_by_id(project=None):
    p = project or QgsProject.instance()
    return {lid: l.name() for lid, l in p.mapLayers().items()}


def _kind(layer):
    if isinstance(layer, QgsRasterLayer):
        return "raster"
    if isinstance(layer, QgsVectorLayer):
        try:
            gt = layer.geometryType()
            return {QgsWkbTypes.GeometryType.PointGeometry: "point",
                    QgsWkbTypes.GeometryType.LineGeometry: "line",
                    QgsWkbTypes.GeometryType.PolygonGeometry: "polygon"}.get(gt, "unknown")
        except Exception:
            return "unknown"
    return "unknown"


def kinds_by_id(project=None):
    p = project or QgsProject.instance()
    return {lid: _kind(l) for lid, l in p.mapLayers().items()}


def tree_order(project=None):
    p = project or QgsProject.instance()
    return [n.layerId() for n in p.layerTreeRoot().findLayers()]


def ticked_vectors(project=None):
    p = project or QgsProject.instance()
    out = []
    for node in p.layerTreeRoot().findLayers():
        l = node.layer()
        if isinstance(l, QgsVectorLayer) and node.isVisible() and not is_book_layer(l):
            out.append((l.id(), l.name()))
    return out


def book_layers(book_id, project=None):
    p = project or QgsProject.instance()
    return [l for l in p.mapLayers().values() if str(l.customProperty(BP.PROP_BOOK_ID) or "") == book_id]


def layouts_for_book(book_id, project=None):
    p = project or QgsProject.instance()
    return [lay for lay in p.layoutManager().printLayouts()
            if str(lay.customProperty(BP.PROP_BOOK_ID) or "") == book_id]


def all_book_layouts(project=None):
    p = project or QgsProject.instance()
    return [lay for lay in p.layoutManager().printLayouts() if is_book_layout(lay)]


def orphan_book_layers(project=None):
    """Book-owned layers whose book id no layout carries any more."""
    p = project or QgsProject.instance()
    held = {str(lay.customProperty(BP.PROP_BOOK_ID)) for lay in all_book_layouts(p)}
    return [l for l in p.mapLayers().values() if is_book_layer(l)
            and str(l.customProperty(BP.PROP_BOOK_ID)) not in held]


def get_spec(layout):
    try:
        return BP.from_json(layout.customProperty(BP.PROP_SPEC) or "")
    except Exception:
        return None


def set_spec(layout, spec):
    layout.setCustomProperty(BP.PROP_SPEC, BP.to_json(spec))
    layout.setCustomProperty(BP.PROP_BOOK_ID, spec["book_id"])


def book_map(layout):
    for it in layout.items():
        if isinstance(it, QgsLayoutItemMap) and it.id() == "bookmap":
            return it
    return next((it for it in layout.items() if isinstance(it, QgsLayoutItemMap)), None)


def book_legend(layout):
    for it in layout.items():
        if isinstance(it, QgsLayoutItemLegend) and it.id() == "booklegend":
            return it
    return None


def is_original(layout, spec=None):
    """The layout the book was built as (a duplicated layout carries the same id)."""
    spec = spec or get_spec(layout)
    return bool(spec) and layout.name() == spec.get("layout_name")


# ── defaults ───────────────────────────────────────────────────────────────────────────
def _role_ids(ns, role, allowed=None):
    """The engine's own resolution for a role (v1-canonical names, else one fuzzy match),
    restricted to `allowed` ids in phase mode. Book layers are never returned."""
    out = []
    try:
        for l in ns["_role_layers"](role) or []:
            if l is not None and not is_book_layer(l) and (allowed is None or l.id() in allowed):
                out.append(l.id())
    except Exception:
        _swallowed_note()
    if not out and allowed is not None:
        # phase mode: the engine's names did not match inside the phase - use the phase's
        # own layers whose name carries the role's fuzzy keywords (same table as the engine)
        spec = (ns.get("_FUZZY_ROLES") or {}).get(role)
        if spec:
            geom, inc, exc = spec
            p = QgsProject.instance()
            for lid in allowed:
                l = p.mapLayer(lid)
                if l is None or not isinstance(l, QgsVectorLayer):
                    continue
                nm = l.name().lower()
                if _kind(l) == geom and any(k in nm for k in inc) and not any(k in nm for k in exc):
                    out.append(lid)
                    break
    return out


def _metric_epsg(layer):
    try:
        ext = layer.extent()
        c = ext.center()
        tr = QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem("EPSG:4326"),
                                    QgsProject.instance())
        ll = tr.transform(QgsPointXY(c.x(), c.y()))
        return BP.utm_epsg(ll.x(), ll.y())
    except Exception:
        return 32735


def _label_field(layer, ns=None):
    names = [f.name() for f in layer.fields()]
    for cand in ("label", "pon_no", "pon", "PON", "name", "Name", "zone_id", "id", "fid"):
        if cand in names:
            return cand
    for f in layer.fields():
        if f.type() in (QMetaType.Type.QString,):
            return f.name()
    return names[0] if names else ""


def _numeric_field(layer, field):
    try:
        idx = layer.fields().indexOf(field)
        if idx < 0:
            return False
        if layer.fields().at(idx).isNumeric():
            return True
        vals = [f[field] for f in layer.getFeatures()][:200]
        return bool(vals) and all(str(v).strip().lstrip("-").replace(".", "", 1).isdigit()
                                  for v in vals if v is not None)
    except Exception:
        return False


def _overview_geom(spec, pon_layer, aoi_layer):
    """Overview page framing = bbox of the AOI and the PON layer, in the PON layer's CRS."""
    ext = QgsRectangle(pon_layer.extent())
    if aoi_layer is not None:
        try:
            e2 = aoi_layer.extent()
            if aoi_layer.crs() != pon_layer.crs():
                e2 = QgsCoordinateTransform(aoi_layer.crs(), pon_layer.crs(),
                                            QgsProject.instance()).transformBoundingBox(e2)
            ext.combineExtentWith(e2)
        except Exception:
            _swallowed_note()
    if ext.isNull() or ext.width() <= 0 or ext.height() <= 0:
        ext = QgsRectangle(0, 0, 1, 1)
    spec["overview_wkt"] = QgsGeometry.fromRect(ext).asWkt(9)
    spec["overview_srid"] = int(pon_layer.crs().postgisSrid())


def default_spec(cfg, project=None, phase=None, pon_layer=None):
    """A ready-to-build spec for this project (or one phase group)."""
    p = project or QgsProject.instance()
    ns = engine_ns(cfg)
    allowed = None
    aoi = None
    if phase is not None:
        allowed = {l.id() for l in (phase.get("content") or [])}
        if phase.get("coverage") is not None:
            allowed.add(phase["coverage"].id())
        aoi = phase.get("boundary")
        pon_layer = pon_layer or phase.get("coverage")
    else:
        try:
            aoi = ns["_aoi_layer"]()          # NOTE: never _restore_aoi (it edits the AOI)
        except Exception:
            aoi = None
    if pon_layer is None:
        try:
            pon_layer = ns["_role"]("coverage")
        except Exception:
            pon_layer = None
    if pon_layer is None:
        raise ValueError("No PON / zone polygon layer found — pick one under “Each page shows”.")
    if aoi is not None and (is_book_layer(aoi) or aoi.id() == pon_layer.id()):
        aoi = None
    roles = {r: _role_ids(ns, r, allowed) for r in BP.PON_PAGE_ROLES}
    roles["coverage"] = [pon_layer.id()]
    fts = (roles.get("fts") or [""])[0]
    ticked = [(i, n) for i, n in ticked_vectors(p) if allowed is None or i in allowed]
    ov, pon_ids, pon_labels = BP.default_pages(roles, ticked, aoi.id() if aoi else "",
                                               pon_layer.id(), fts)
    title = str(cfg.get("project_name") or "HLD").strip()
    spec = BP.empty_spec(title=title)
    spec["phase"] = phase.get("phase_no") if phase is not None else None
    # a default page whose layer this project does not have (no FTS layer, no feeders) is left
    # out rather than built empty; the build message names it and Edit pages can add it back
    spec["defaults_left_out"] = [pg["title"] for pg in ov if not pg["ids"]]
    spec["overview"] = [pg for pg in ov if pg["ids"]]
    spec["pon"] = {"ids": pon_ids, "labels": pon_labels, "note": ""}
    spec["pon_layer_id"] = pon_layer.id()
    unit, id_field, sort_field = "PON", "", ""
    try:
        from .presets import coverage_descriptor
        unit, id_field, sort_field = coverage_descriptor(pon_layer)
    except Exception:
        _swallowed_note()
    names_ = pon_layer.fields().names()
    spec["pon_label_field"] = id_field if id_field in names_ else _label_field(pon_layer)
    spec["pon_sort_field"] = sort_field if sort_field in names_ else spec["pon_label_field"]
    spec["pon_sort_numeric"] = _numeric_field(pon_layer, spec["pon_sort_field"])
    unit = unit or "PON"
    spec["pon_title_prefix"] = "%s - %s " % (title, unit) if title else "%s " % unit
    spec["metric_epsg"] = _metric_epsg(pon_layer)
    try:
        base = ns["_basemap_layer"]()
    except Exception:
        base = None
    spec["aerial_id"] = base.id() if (base is not None and not is_book_layer(base)) else ""
    _overview_geom(spec, pon_layer, aoi)
    return BP.normalise(spec)


# ── book-owned layers ──────────────────────────────────────────────────────────────────
def _own(layer, book_id, role):
    layer.setFlags(layer.flags() | QgsMapLayer.LayerFlag.Private)
    layer.setCustomProperty(BP.PROP_BOOK_ID, book_id)
    layer.setCustomProperty(BP.PROP_ROLE, role)
    return layer


def _add_private(layer):
    p = QgsProject.instance()
    p.addMapLayer(layer, False)
    node = p.layerTreeRoot().findLayer(layer.id())
    if node is not None:                      # never in the Layers panel
        node.parent().removeChildNode(node)
    return layer


def _ensure_guard(spec, crs):
    p = QgsProject.instance()
    g = p.mapLayer(spec.get("guard_id") or "")
    name = BP.guard_layer_name(spec["book_id"])
    if g is None or not is_book_layer(g):
        g = QgsVectorLayer("Point?crs=%s" % crs.authid(), name, "memory")
        _add_private(_own(g, spec["book_id"], "guard"))
        spec["guard_id"] = g.id()
    elif g.name() != name:
        g.setName(name)
    return g


def _label_settings_for(src):
    """Labelling for a book label layer: a clone of the source's own labelling when it has
    one (source untouched), else a plain label on the best name field."""
    try:
        if src.labeling() is not None:
            lab = src.labeling().clone()
            return lab
    except Exception:
        _swallowed_note()
    s = QgsPalLayerSettings()
    s.fieldName = _label_field(src)
    s.enabled = True
    try:
        s.placement = (QgsPalLayerSettings.Placement.Horizontal
                       if _kind(src) == "polygon" else s.placement)
    except Exception:
        _swallowed_note()
    return QgsVectorLayerSimpleLabeling(s)


def _ensure_label_layers(spec):
    """One private label layer per labelled source layer; unused ones are removed."""
    p = QgsProject.instance()
    wanted = set()
    for pg in spec["overview"]:
        wanted |= set(pg["labels"])
    wanted |= set(spec["pon"]["labels"])
    for o in spec["overrides"]:
        wanted |= set(o["labels"])
    cur = dict(spec.get("label_layers") or {})
    used_n = set()
    for lid in list(cur.values()):
        l = p.mapLayer(lid)
        if l is not None:
            try:
                used_n.add(int(l.name().rsplit("_", 1)[1]))
            except Exception:
                _swallowed_note()
    for src_id, lab_id in list(cur.items()):
        if src_id not in wanted or p.mapLayer(src_id) is None or p.mapLayer(lab_id) is None:
            if p.mapLayer(lab_id) is not None:
                p.removeMapLayer(lab_id)
            cur.pop(src_id, None)
    n = 1
    for src_id in sorted(wanted):
        if src_id in cur:
            continue
        src = p.mapLayer(src_id)
        if not isinstance(src, QgsVectorLayer):
            continue
        while n in used_n:
            n += 1
        used_n.add(n)
        uri = "?layer_ref=%s:src&query=%s" % (src_id, quote("SELECT * FROM src"))
        lab = QgsVectorLayer(uri, BP.label_layer_name(spec["book_id"], n), "virtual")
        if not lab.isValid():
            continue
        lab.setRenderer(QgsNullSymbolRenderer())
        lab.setLabeling(_label_settings_for(src))
        lab.setLabelsEnabled(True)
        lab.setCustomProperty("vf_book_label_source", src_id)
        _add_private(_own(lab, spec["book_id"], "label"))
        cur[src_id] = lab.id()
    spec["label_layers"] = cur
    return cur


def _page_rows(spec, project=None):
    p = project or QgsProject.instance()
    kinds = kinds_by_id(p)
    order = tree_order(p)
    ll = spec.get("label_layers") or {}
    aerial = spec.get("aerial_id") if p.mapLayer(spec.get("aerial_id") or "") is not None else ""
    guard = spec.get("guard_id") or ""

    def ids_text(ids, labels):
        return BP.join_ids(BP.page_id_list(ids, labels, ll, aerial, guard, kinds, order))
    return {
        "overview": [(pg["title"], ids_text(pg["ids"], pg["labels"]), pg["note"]) for pg in spec["overview"]],
        "pon_ids": ids_text(spec["pon"]["ids"], spec["pon"]["labels"]),
        "pon_note": spec["pon"]["note"],
        "overrides": [(o["cx"], o["cy"], o["area"], ids_text(o["ids"], o["labels"]), o["note"])
                      for o in spec["overrides"]],
        "aerial_guard": BP.join_ids([x for x in (aerial, guard) if x]),
    }


def _pages_uri(spec, project=None):
    sql = BP.page_layer_sql(spec, _page_rows(spec, project))
    return ("?layer_ref=%s:pon&query=%s&geometry=geometry:3:%d&uid=seq"
            % (spec["pon_layer_id"], quote(sql), int(spec["overview_srid"])))


def _ensure_pages(spec):
    p = QgsProject.instance()
    uri = _pages_uri(spec, p)
    name = BP.pages_layer_name(spec["book_id"])
    lyr = p.mapLayer(spec.get("pages_id") or "")
    if lyr is not None and is_book_layer(lyr):
        lyr.setDataSource(uri, name, "virtual")       # same layer id -> atlas stays attached
        if not lyr.isValid():
            raise RuntimeError("Book page list could not be rebuilt: %s"
                               % lyr.dataProvider().error().message())
        return lyr
    lyr = QgsVectorLayer(uri, name, "virtual")
    if not lyr.isValid():
        raise RuntimeError("Book page list could not be created: %s" % lyr.dataProvider().error().message())
    _add_private(_own(lyr, spec["book_id"], "pages"))
    spec["pages_id"] = lyr.id()
    return lyr


# ── layout ─────────────────────────────────────────────────────────────────────────────
def _layout_name(spec, project=None):
    p = project or QgsProject.instance()
    base = "%s Pages Book" % (spec.get("title") or "HLD")
    if spec.get("phase") is not None:
        base = "%s Phase %s Pages Book" % (spec.get("title") or "HLD", spec["phase"])
    name, n = base, 2
    while True:
        ex = p.layoutManager().layoutByName(name)
        if ex is None or str(ex.customProperty(BP.PROP_BOOK_ID) or "") == spec["book_id"]:
            return name
        name = "%s (%d)" % (base, n); n += 1


def _legend_layer_ids(spec, project=None):
    p = project or QgsProject.instance()
    ids = []
    for pg in spec["overview"]:
        ids += pg["ids"]
    ids += spec["pon"]["ids"]
    for o in spec["overrides"]:
        ids += o["ids"]
    out = []
    for i in BP._uniq(ids):
        l = p.mapLayer(i)
        if isinstance(l, QgsVectorLayer) and not is_book_layer(l):
            out.append(i)
    return BP.ordered_ids(out, kinds_by_id(p), tree_order(p))


def _auto_label(ns, layer):
    try:
        return ns["_legend_label"](layer)
    except Exception:
        return layer.name()


def _sync_legend(layout, spec, ns, first=False):
    """Legend writes allowed after the first build: rows for layers NEWLY added to a page
    and the label of a row the operator has not renamed. Box, columns, fonts, symbol sizes,
    title, order and deleted rows are never touched."""
    leg = book_legend(layout)
    if leg is None:
        return
    p = QgsProject.instance()
    root = leg.model().rootGroup()
    want = _legend_layer_ids(spec, p)
    known = set(spec.get("legend_known") or [])
    present = {n.layerId(): n for n in root.findLayers()}
    for lid in want:
        if lid in known and not first:
            continue                                      # the operator may have deleted it
        if lid in present:
            continue
        lyr = p.mapLayer(lid)
        if lyr is None:
            continue
        node = root.addLayer(lyr)
        lab = _auto_label(ns, lyr)
        node.setCustomProperty("legend/title-label", lab)
        node.setCustomProperty(BP.PROP_AUTO_LABEL, lab)
        present[lid] = node
    for lid, node in present.items():
        lyr = p.mapLayer(lid)
        if lyr is None:
            continue
        stored = node.customProperty(BP.PROP_AUTO_LABEL)
        if stored is not None and (node.customProperty("legend/title-label") or "") == stored:
            lab = _auto_label(ns, lyr)
            node.setCustomProperty("legend/title-label", lab)
            node.setCustomProperty(BP.PROP_AUTO_LABEL, lab)
    spec["legend_known"] = BP._uniq(list(known) + want)
    try:
        leg.updateLegend()
    except Exception:
        _swallowed_note()


def _sample_pages(n, spec):
    """Every page for a short book; else every overview page plus 12 PON pages spread out
    (all PON pages share one layer set unless overridden, so the legend barely varies)."""
    k = len(spec.get("overview") or [])
    if n <= 30:
        return list(range(n))
    pon = list(range(k, n))
    step = max(1, len(pon) // 12)
    return sorted(set(list(range(min(k, n))) + pon[::step] + [n - 1]))


def _legend_heights(layout, spec=None):
    """Legend content height (mm) on the sampled pages. The legend only learns its filtered
    size when the page is RENDERED, so each sampled page is drawn once at 12 dpi."""
    from qgis.core import QgsLayoutExporter
    leg = book_legend(layout)
    at = layout.atlas()
    out = []
    if leg is None or not at.enabled():
        return out
    leg.setResizeToContents(True)
    ex = QgsLayoutExporter(layout)
    at.updateFeatures()
    at.beginRender()
    try:
        for i in _sample_pages(at.count(), spec or get_spec(layout) or {}):
            at.seekTo(i)
            ex.renderPageToImage(0, dpi=12)
            leg.adjustBoxSize()
            out.append(float(leg.rect().height()))
    finally:
        at.endRender()
    return out


def _new_layout(ns, cfg, spec, pages, guard):
    p = QgsProject.instance()
    lay = QgsPrintLayout(p)
    lay.initializeDefaults()
    lay.setName(_layout_name(spec, p))
    lay.pageCollection().page(0).setPageSize("A3", ns["LAND"])
    add_rect, add_label = ns["add_rect"], ns["add_label"]
    add_rect(lay, 3, 3, 414, 291, stroke_w=1.0)
    add_rect(lay, MAP["x"], 6, MAP["w"], 18, stroke_w=0.8)
    t = add_label(lay, MAP["x"], 6, MAP["w"], 18,
                  html="<div style='font-family:Arial;font-size:19px;font-weight:bold;"
                       "text-decoration:underline'>[% attribute(@atlas_feature,'page_title') %]</div>")
    t.setId("booktitle")
    # map
    m = QgsLayoutItemMap(lay)
    m.setId("bookmap")
    lay.addLayoutItem(m)
    m.attemptMove(_mm_pt(MAP["x"], MAP["y"])); m.attemptResize(_mm_sz(MAP["w"], MAP["h"]))
    aerial = p.mapLayer(spec.get("aerial_id") or "")
    m.setLayers([x for x in (guard, aerial) if x is not None])
    m.setKeepLayerSet(True)
    m.dataDefinedProperties().setProperty(
        QgsLayoutObject.DataDefinedProperty.MapLayers,
        QgsProperty.fromExpression(BP.map_layers_expression(guard.name())))
    m.setFrameEnabled(True)
    m.setFrameStrokeWidth(ns["QgsLayoutMeasurement"](0.4, MM))
    m.setBackgroundColor(ns["QColor"](255, 255, 255))
    m.setAtlasDriven(True)
    m.setAtlasScalingMode(ns["ATLAS_AUTO"])
    m.setAtlasMargin(float(cfg.get("atlas_margin", 0.15)))
    m.attemptMove(_mm_pt(MAP["x"], MAP["y"])); m.attemptResize(_mm_sz(MAP["w"], MAP["h"]))
    for k, v in (("hld_frame_x", MAP["x"]), ("hld_frame_y", MAP["y"]),
                 ("hld_frame_w", MAP["w"]), ("hld_frame_h", MAP["h"])):
        m.setCustomProperty(k, float(v))
    spec["frame"] = dict(MAP)
    # legend (native, one, rows follow the page)
    leg = QgsLayoutItemLegend(lay)
    leg.setId("booklegend")
    lay.addLayoutItem(leg)
    leg.setLinkedMap(m)
    leg.setAutoUpdateModel(False)
    leg.setTitle("LEGEND")
    try:
        leg.setLegendFilterByMapEnabled(True)
    except Exception:
        _swallowed_note()
    leg.model().rootGroup().removeAllChildren()
    leg.setFrameEnabled(True)
    leg.setResizeToContents(True)
    leg.attemptMove(_mm_pt(SB_X, 6))
    # note
    note = add_label(lay, SB_X, 120, SB_W, NOTE_H,
                     html="<div style='font-family:Arial;font-size:12px;font-weight:bold'>"
                          "[% coalesce(attribute(@atlas_feature,'page_note'),'') %]</div>",
                     frame=False)
    note.setId("booknote")
    # title block
    h_title = TITLE_BLOCK_H
    title_y = PAGE_H - 3.0 - h_title
    tb = add_label(lay, SB_X, title_y, SB_W, h_title, html=ns["titleblock_html"](), valign_center=False)
    tb.setId("booktitleblock")
    # atlas
    at = lay.atlas()
    at.setCoverageLayer(pages)
    at.setEnabled(True)
    at.setHideCoverage(True)
    at.setSortFeatures(True)
    at.setSortExpression('"seq"')
    at.setFilenameExpression("'page_' || \"seq\"")
    return lay, m, leg, note, title_y


def _legend_style(leg, size):
    """Legend text sizes in points (item = size); symbols scaled with it."""
    from qgis.core import QgsLegendStyle
    try:
        for st, sz in ((QgsLegendStyle.Style.Title, size + 3.0), (QgsLegendStyle.Style.Group, size + 1.0),
                       (QgsLegendStyle.Style.Subgroup, size + 0.5), (QgsLegendStyle.Style.SymbolLabel, size)):
            style = leg.rstyle(st)
            tf = style.textFormat()
            tf.setSize(sz)
            style.setTextFormat(tf)
            leg.setStyle(st, style)
        leg.setSymbolHeight(max(2.5, size * 0.45))
        leg.setSymbolWidth(max(4.0, size * 0.7))
    except Exception:
        _swallowed_note()


def _place_sidebar(ns, lay, leg, note, title_y):
    """Size the legend box once, to the tallest (sampled) page, then place note, north and
    logo below it. Fit order: 7.5 pt, 6 pt, then drop the logo and shrink the north arrow,
    and only then two columns (which may run wider than the sidebar - the bar warns)."""
    full = title_y - 6.0 - (3 + NOTE_H + 3 + 26 + 3 + 22 + 3)       # note + north + logo
    lean = title_y - 6.0 - (3 + NOTE_H + 3 + 16 + 3)                # note + small north
    _legend_style(leg, 7.5)
    hs = _legend_heights(lay)
    h = max(hs) if hs else 40.0
    fit = "7.5pt"
    if h > full:
        _legend_style(leg, 6.0)
        hs = _legend_heights(lay)
        h = max(hs) if hs else h
        fit = "6pt"
    show_logo, arrow = True, 18.0
    if h > full:
        show_logo, arrow, fit = False, 10.0, "6pt, no logo"
    if h > lean:
        leg.setColumnCount(2)
        leg.setSplitLayer(True)
        hs = _legend_heights(lay)
        h = max(hs) if hs else h
        fit = "6pt, no logo, 2 columns"
    room = full if show_logo else lean
    box = min(h, max(room, 20.0))
    leg.setResizeToContents(False)
    leg.attemptMove(_mm_pt(SB_X, 6))
    leg.attemptResize(_mm_sz(SB_W, box))
    y = 6 + box + 3
    note.attemptMove(_mm_pt(SB_X, y)); note.attemptResize(_mm_sz(SB_W, NOTE_H))
    y += NOTE_H + 3
    north = ns.get("NORTH_SVG")
    if north:
        from qgis.core import QgsLayoutItemPicture
        pic = QgsLayoutItemPicture(lay)
        pic.setPicturePath(north)
        lay.addLayoutItem(pic)
        pic.attemptMove(_mm_pt(SB_X + (SB_W - arrow) / 2.0, y))
        pic.attemptResize(_mm_sz(arrow, arrow))
        ns["add_label"](lay, SB_X, y + arrow, SB_W, 5, text="N", size=9 if arrow < 15 else 11, bold=True)
    y += arrow + 8 + 3
    logo = ns.get("LOGO")
    if show_logo and logo and os.path.exists(logo) and y + 22 <= title_y:
        from qgis.core import QgsLayoutItemPicture
        lg = QgsLayoutItemPicture(lay)
        lg.setPicturePath(logo)
        lg.setResizeMode(QgsLayoutItemPicture.ResizeMode.Zoom)
        lay.addLayoutItem(lg)
        lw = min(SB_W, 22 * (48.0 / 28.0))
        lg.attemptMove(_mm_pt(SB_X + (SB_W - lw) / 2.0, y))
        lg.attemptResize(_mm_sz(lw, 22))
    lay.setCustomProperty("vf_book_legend_fit", "%s · tallest page %.0f mm · box %.0f mm" % (fit, h, box))
    return h


def _apply_clip(m, spec, enabled):
    if not enabled:
        return
    try:
        from qgis.core import QgsMapClippingRegion
        p = QgsProject.instance()
        cs = m.atlasClippingSettings()
        cs.setEnabled(True)
        cs.setFeatureClippingType(QgsMapClippingRegion.FeatureClippingType.ClipToIntersection)
        cs.setForceLabelsInsideFeature(True)
        keep = ("feeder", "primary", "adss")
        clip = []
        for lid in _legend_layer_ids(spec, p):
            l = p.mapLayer(lid)
            nm = (l.name() or "").lower()
            if "mini" not in nm and any(k in nm for k in keep):
                continue
            clip.append(l)
        for lid in (spec.get("label_layers") or {}).values():
            if p.mapLayer(lid) is not None:
                clip.append(p.mapLayer(lid))
        cs.setRestrictToLayers(True)
        cs.setLayersToClip(clip)
    except Exception:
        _swallowed_note()


def build_or_update(cfg, spec, project=None):
    """Build the book, or — when a layout already carries this book id — update it in place
    (the operator's Print Layout edits stay). Returns (layout, message)."""
    p = project or QgsProject.instance()
    spec = BP.normalise(spec)
    names = names_by_id(p)
    errors, warnings = BP.validate(spec, names)
    if errors:
        raise ValueError("Book not built:\n• " + "\n• ".join(errors))
    existing = [lay for lay in layouts_for_book(spec["book_id"], p) if is_original(lay, get_spec(lay))]
    if existing:
        lay = update_book(existing[0], spec, cfg=cfg)
        return lay, "Updated “%s” in place — your Print Layout edits were kept." % lay.name()
    ns = engine_ns(cfg)
    pon = p.mapLayer(spec["pon_layer_id"])
    guard = _ensure_guard(spec, pon.crs())
    _ensure_label_layers(spec)
    pages = _ensure_pages(spec)
    lay, m, leg, note, title_y = _new_layout(ns, cfg, spec, pages, guard)
    spec["layout_name"] = lay.name()
    _apply_clip(m, spec, bool(cfg.get("atlas_clip")))
    set_spec(lay, spec)
    if not p.layoutManager().addLayout(lay):
        for l in book_layers(spec["book_id"], p):
            p.removeMapLayer(l.id())
        raise RuntimeError("QGIS refused to add the layout “%s”." % lay.name())
    _sync_legend(lay, spec, ns, first=True)
    _place_sidebar(ns, lay, leg, note, title_y)
    set_spec(lay, spec)
    msg = "Built “%s” — %d overview page(s) + %d PON page(s)." % (
        lay.name(), len(spec["overview"]), pon.featureCount())
    if spec.get("defaults_left_out"):
        msg += "  Left out (no matching layer in this project): %s — add them in Book Pages ▸ Edit pages." % (
            ", ".join(spec["defaults_left_out"]))
    if warnings:
        msg += "  Note: " + " ".join(warnings[:3])
    return lay, msg


def update_book(layout, spec, cfg=None):
    """Rewrite the page list, label layers, notes and the allowed legend parts in place."""
    p = QgsProject.instance()
    old = get_spec(layout)
    if old is None or not is_original(layout, old):
        raise ValueError("This layout is a copy of a book — use “Make this copy its own book” first.")
    spec = BP.normalise(spec)
    for k in ("book_id", "layout_name", "pages_id", "guard_id", "label_layers", "legend_known", "frame"):
        spec[k] = old.get(k) if k not in ("label_layers",) else (spec.get(k) or old.get(k) or {})
    errors, _w = BP.validate(spec, names_by_id(p))
    if errors:
        raise ValueError("Book not updated:\n• " + "\n• ".join(errors))
    pon = p.mapLayer(spec["pon_layer_id"])
    guard = _ensure_guard(spec, pon.crs())
    _ensure_label_layers(spec)
    pages = _ensure_pages(spec)
    m = book_map(layout)
    if m is not None:
        aerial = p.mapLayer(spec.get("aerial_id") or "")
        m.setLayers([x for x in (guard, aerial) if x is not None])
        m.dataDefinedProperties().setProperty(
            QgsLayoutObject.DataDefinedProperty.MapLayers,
            QgsProperty.fromExpression(BP.map_layers_expression(guard.name())))
    if layout.atlas().coverageLayer() is None or layout.atlas().coverageLayer().id() != pages.id():
        layout.atlas().setCoverageLayer(pages)
    ns = engine_ns(cfg or {"project_name": spec.get("title")})
    _sync_legend(layout, spec, ns)
    set_spec(layout, spec)
    layout.refresh()
    return layout


# ── checks ─────────────────────────────────────────────────────────────────────────────
def guard_enabled():
    try:
        from qgis.core import QgsSettings
        v = QgsSettings().value(BP.SETTING_GUARD, BP.GUARD_DEFAULT_ON)
        return str(v).lower() not in ("false", "0", "off", "no")
    except Exception:
        return True


def check_book(layout, force=False):
    """Fail-closed draw check for our exports. Returns (hard, soft); never raises.

    hard (refuse): spec unreadable, a copy not made its own book, PON layer missing, page
    count != overview pages + live PON count, any page drawing something it should not or
    missing a listed layer that exists, a listed layer deleted, a '|' in a listed name.
    soft (warn): same-named twins drawn, switch off."""
    hard, soft = [], []
    try:
        p = QgsProject.instance()
        spec = get_spec(layout)
        if spec is None:
            return ["Book spec is missing or unreadable on this layout."], []
        if not guard_enabled() and not force:
            return [], ["Book draw check is switched off (%s)." % BP.SETTING_GUARD]
        if not is_original(layout, spec):
            hard.append("This layout is a copy of book “%s” — use “Make this copy its own book”."
                        % spec.get("layout_name"))
        names = names_by_id(p)
        errors, warns = BP.validate(spec, names)
        hard += errors
        for w in warns:
            if "no longer exists" in w:
                hard.append(w)
            else:
                soft.append(w)
        pon = p.mapLayer(spec.get("pon_layer_id") or "")
        at = layout.atlas()
        cov = at.coverageLayer()
        if cov is None or cov.id() != spec.get("pages_id") or not cov.isValid():
            hard.append("The book's page list is missing or broken (re-attach the PON layer).")
            return hard, soft
        try:
            at.updateFeatures()                  # count() is 0 until the atlas reads its rows
        except Exception:
            _swallowed_note()
        if pon is not None:
            want = len(spec["overview"]) + pon.featureCount()
            if at.count() != want:
                hard.append("Page count %d ≠ %d overview + %d PON pages." % (
                    at.count(), len(spec["overview"]), pon.featureCount()))
        m = book_map(layout)
        if m is None:
            hard.append("The book's map item is missing.")
            return hard, soft
        twins_seen = set()
        at.beginRender()
        try:
            for i in range(at.count()):
                at.seekTo(i)
                f = layout.reportContext().feature()
                title = f["page_title"]
                ids = BP.split_ids(f["page_ids"])
                rendered = [l.id() for l in m.layersToRender()]
                v = BP.check_page(ids, rendered, names)
                if not v["ok"]:
                    bits = []
                    if v["extra"]:
                        bits.append("draws unlisted: " + ", ".join(names.get(x, x) for x in v["extra"]))
                    if v["missing"]:
                        bits.append("missing: " + ", ".join(names.get(x, x) for x in v["missing"]))
                    hard.append("Page “%s”: %s." % (title, "; ".join(bits)))
                for t in v["twins"]:
                    twins_seen.add(names.get(t, t))
        finally:
            at.endRender()
        for n in sorted(twins_seen):
            soft.append("Two or more layers are named “%s”; all of them draw." % n)
        unmatched = unmatched_overrides(spec, pon)
        if unmatched:
            soft.append("%d per-PON override(s) no longer match a zone (merged or reshaped) and "
                        "are not drawn: %s." % (len(unmatched), ", ".join("PON %s" % o.get("pon") for o in unmatched)))
    except Exception as e:
        hard.append("Book draw check failed: %s" % e)
    return hard, soft


def make_qa(engine_qa=None):
    """QA callable for live_build._write_atlas_pdf: engine layout QA + the book draw check.
    Never raises (the caller's wrapper is fail-open), so a crash here blocks the export."""
    def _qa(layout):
        hard, soft = [], []
        if callable(engine_qa):
            try:
                h, s = engine_qa(layout)
                soft += list(h) + list(s)       # engine QA stays advisory for the book frame
            except Exception as e:
                soft.append("engine QA skipped: %s" % e)
        h2, s2 = check_book(layout)
        return hard + h2, soft + s2
    return _qa


# ── overrides ──────────────────────────────────────────────────────────────────────────
def fingerprint(geom, crs, metric_epsg):
    g = QgsGeometry(geom)
    g.transform(QgsCoordinateTransform(crs, QgsCoordinateReferenceSystem("EPSG:%d" % int(metric_epsg)),
                                       QgsProject.instance()))
    c = g.centroid().asPoint()
    return float(c.x()), float(c.y()), float(g.area())


def unmatched_overrides(spec, pon_layer):
    if pon_layer is None or not spec.get("overrides"):
        return []
    fps = [fingerprint(f.geometry(), pon_layer.crs(), spec["metric_epsg"])
           for f in pon_layer.getFeatures() if f.geometry() and not f.geometry().isEmpty()]
    out = []
    for o in spec["overrides"]:
        if not any(BP.zone_matches(o, cx, cy, a) for cx, cy, a in fps):
            out.append(o)
    return out


def add_override(spec, pon_feature, pon_layer, ids=None, labels=None, note=None):
    cx, cy, a = fingerprint(pon_feature.geometry(), pon_layer.crs(), spec["metric_epsg"])
    spec = BP.normalise(spec)
    spec["overrides"] = [o for o in spec["overrides"] if not BP.zone_matches(o, cx, cy, a)]
    fld = spec.get("pon_label_field")
    spec["overrides"].append({
        "cx": cx, "cy": cy, "area": a,
        "pon": str(pon_feature[fld]) if fld and fld in pon_feature.fields().names() else "",
        "ids": list(ids if ids is not None else spec["pon"]["ids"]),
        "labels": list(labels if labels is not None else spec["pon"]["labels"]),
        "note": spec["pon"]["note"] if note is None else note})
    return BP.normalise(spec)


def discard_override(spec, index):
    spec = BP.normalise(spec)
    if 0 <= index < len(spec["overrides"]):
        spec["overrides"].pop(index)
    return spec


def reattach_override(spec, index, pon_feature, pon_layer):
    spec = BP.normalise(spec)
    o = spec["overrides"][index]
    cx, cy, a = fingerprint(pon_feature.geometry(), pon_layer.crs(), spec["metric_epsg"])
    o.update({"cx": cx, "cy": cy, "area": a})
    fld = spec.get("pon_label_field")
    if fld and fld in pon_feature.fields().names():
        o["pon"] = str(pon_feature[fld])
    return BP.normalise(spec)


def override_index_for(spec, pon_feature, pon_layer):
    cx, cy, a = fingerprint(pon_feature.geometry(), pon_layer.crs(), spec["metric_epsg"])
    for i, o in enumerate(spec["overrides"]):
        if BP.zone_matches(o, cx, cy, a):
            return i
    return -1


# ── re-attach / copies / backup / restore / rebuild / remove ──────────────────────────
def reattach_pon(layout, new_layer, cfg=None):
    spec = get_spec(layout)
    if spec is None:
        raise ValueError("Not a book layout.")
    old = spec["pon_layer_id"]
    spec["pon_layer_id"] = new_layer.id()
    for coll in [spec["pon"]] + spec["overview"] + spec["overrides"]:
        coll["ids"] = [new_layer.id() if x == old else x for x in coll["ids"]]
        coll["labels"] = [new_layer.id() if x == old else x for x in coll["labels"]]
    if old in (spec.get("label_layers") or {}):
        lab = QgsProject.instance().mapLayer(spec["label_layers"].pop(old))
        if lab is not None:
            QgsProject.instance().removeMapLayer(lab.id())
    spec["overview_srid"] = int(new_layer.crs().postgisSrid())
    if spec.get("pon_label_field") not in new_layer.fields().names():
        spec["pon_label_field"] = _label_field(new_layer)
        spec["pon_sort_numeric"] = _numeric_field(new_layer, spec["pon_label_field"])
    # update_book needs the stored spec to agree on identity - write it first
    set_spec(layout, dict(get_spec(layout) or spec, pon_layer_id=new_layer.id()))
    return update_book(layout, spec, cfg=cfg)


def _backup_root():
    env = os.environ.get("VF_BOOK_BACKUP_DIR")
    if env:
        return env
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(base, "VelocityNexus", "book_backups")


def backup_book(layout, reason="backup"):
    """.qpt (every layout item, your edits included) + spec. The private layers are
    regenerated from the spec on restore, so the pair is the whole book."""
    import hashlib
    p = QgsProject.instance()
    spec = get_spec(layout)
    if spec is None:
        raise ValueError("Not a book layout.")
    key = hashlib.sha256((p.fileName() or "unsaved").lower().encode()).hexdigest()[:16]
    d = os.path.join(_backup_root(), key, spec["book_id"], time.strftime("%Y%m%d_%H%M%S") + "_" + reason)
    os.makedirs(d, exist_ok=True)
    qpt = os.path.join(d, "layout.qpt")
    if not layout.saveAsTemplate(qpt, QgsReadWriteContext()):
        raise RuntimeError("Could not write the layout backup %s" % qpt)
    with open(os.path.join(d, "spec.json"), "w", encoding="utf-8") as f:
        f.write(BP.to_json(spec))
    with open(os.path.join(d, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump({"project": p.fileName(), "book_id": spec["book_id"], "layout": layout.name(),
                   "reason": reason, "t": time.time()}, f)
    if not (os.path.getsize(qpt) > 0):
        raise RuntimeError("Layout backup is empty: %s" % qpt)
    return d


def list_backups(project=None):
    import hashlib
    p = project or QgsProject.instance()
    key = hashlib.sha256((p.fileName() or "unsaved").lower().encode()).hexdigest()[:16]
    root = os.path.join(_backup_root(), key)
    out = []
    if not os.path.isdir(root):
        return out
    for bid in sorted(os.listdir(root)):
        for stamp in sorted(os.listdir(os.path.join(root, bid)), reverse=True):
            d = os.path.join(root, bid, stamp)
            try:
                with open(os.path.join(d, "manifest.json"), encoding="utf-8") as f:
                    man = json.load(f)
            except Exception:
                continue
            if os.path.normcase(str(man.get("project") or "")) == os.path.normcase(p.fileName() or ""):
                out.append((d, man))
    return out


def _retarget_items(layout, spec, guard, pages):
    m = book_map(layout)
    p = QgsProject.instance()
    if m is not None:
        aerial = p.mapLayer(spec.get("aerial_id") or "")
        m.setLayers([x for x in (guard, aerial) if x is not None])
        m.dataDefinedProperties().setProperty(
            QgsLayoutObject.DataDefinedProperty.MapLayers,
            QgsProperty.fromExpression(BP.map_layers_expression(guard.name())))
    leg = book_legend(layout)
    if leg is not None and m is not None:
        leg.setLinkedMap(m)
    layout.atlas().setCoverageLayer(pages)
    layout.atlas().setEnabled(True)


def restore_book(backup_dir, cfg=None):
    """Recreate a removed book from its backup: layout items from the .qpt, private layers
    regenerated from the spec (detached, private, never in the Layers panel)."""
    p = QgsProject.instance()
    with open(os.path.join(backup_dir, "manifest.json"), encoding="utf-8") as f:
        man = json.load(f)
    if os.path.normcase(str(man.get("project") or "")) != os.path.normcase(p.fileName() or ""):
        raise ValueError("That backup belongs to a different project (%s)." % man.get("project"))
    with open(os.path.join(backup_dir, "spec.json"), encoding="utf-8") as f:
        spec = BP.from_json(f.read())
    if layouts_for_book(spec["book_id"], p):
        spec["book_id"] = BP.new_book_id()          # the original still exists: a new book
    for k in ("pages_id", "guard_id"):
        spec[k] = ""
    spec["label_layers"] = {}
    pon = p.mapLayer(spec["pon_layer_id"])
    if pon is None:
        raise ValueError("The book's PON layer is not in this project.")
    guard = _ensure_guard(spec, pon.crs())
    _ensure_label_layers(spec)
    pages = _ensure_pages(spec)
    from qgis.PyQt.QtXml import QDomDocument
    doc = QDomDocument()
    with open(os.path.join(backup_dir, "layout.qpt"), encoding="utf-8") as f:
        doc.setContent(f.read())
    lay = QgsPrintLayout(p)
    lay.initializeDefaults()
    lay.loadFromTemplate(doc, QgsReadWriteContext(), True)
    spec["layout_name"] = _layout_name(spec, p) if p.layoutManager().layoutByName(man.get("layout") or "") \
        else (man.get("layout") or _layout_name(spec, p))
    lay.setName(spec["layout_name"])
    _retarget_items(lay, spec, guard, pages)
    set_spec(lay, spec)
    if not p.layoutManager().addLayout(lay):
        raise RuntimeError("QGIS refused to add the restored layout.")
    return lay


def rebuild_book(layout, cfg=None):
    """Recreate the book's private layers, page list, atlas binding and clip set. The layout
    object and every item on it (your edits) are kept. Backs up first."""
    p = QgsProject.instance()
    spec = get_spec(layout)
    if spec is None or not is_original(layout, spec):
        raise ValueError("Only the original book layout can be rebuilt.")
    backup_book(layout, "before_rebuild")
    for l in book_layers(spec["book_id"], p):
        p.removeMapLayer(l.id())
    for k in ("pages_id", "guard_id"):
        spec[k] = ""
    spec["label_layers"] = {}
    pon = p.mapLayer(spec["pon_layer_id"])
    if pon is None:
        raise ValueError("The book's PON layer is missing — re-attach it first.")
    guard = _ensure_guard(spec, pon.crs())
    _ensure_label_layers(spec)
    pages = _ensure_pages(spec)
    _retarget_items(layout, spec, guard, pages)
    set_spec(layout, spec)
    layout.refresh()
    return layout


def remove_book(layout, backup=True):
    """Delete only this book's id-tagged items (its layout and its private layers)."""
    p = QgsProject.instance()
    spec = get_spec(layout)
    if spec is None:
        raise ValueError("Not a book layout.")
    if not is_original(layout, spec):
        raise ValueError("This layout is a copy — use “Make this copy its own book” first.")
    d = backup_book(layout, "before_remove") if backup else None
    others = [lay for lay in layouts_for_book(spec["book_id"], p) if lay is not layout]
    p.layoutManager().removeLayout(layout)
    if not others:
        for l in book_layers(spec["book_id"], p):
            p.removeMapLayer(l.id())
    return d


def remove_orphans(project=None):
    p = project or QgsProject.instance()
    n = 0
    for l in orphan_book_layers(p):
        p.removeMapLayer(l.id()); n += 1
    return n


def clone_book(layout, cfg=None):
    """Make a duplicated layout its own book: new id, its own private layers, its atlas,
    map, clip set and legend re-pointed. The original is untouched."""
    p = QgsProject.instance()
    spec = get_spec(layout)
    if spec is None:
        raise ValueError("Not a book layout.")
    if is_original(layout, spec):
        raise ValueError("This is the original book; it is already its own book.")
    spec = BP.normalise(spec)
    spec["book_id"] = BP.new_book_id()
    for k in ("pages_id", "guard_id"):
        spec[k] = ""
    spec["label_layers"] = {}
    pon = p.mapLayer(spec["pon_layer_id"])
    if pon is None:
        raise ValueError("The book's PON layer is missing.")
    guard = _ensure_guard(spec, pon.crs())
    _ensure_label_layers(spec)
    pages = _ensure_pages(spec)
    _retarget_items(layout, spec, guard, pages)
    m = book_map(layout)
    if m is not None and m.atlasClippingSettings().enabled():
        _apply_clip(m, spec, True)
    spec["layout_name"] = layout.name()
    set_spec(layout, spec)
    layout.refresh()
    return layout


# ── designer helpers ───────────────────────────────────────────────────────────────────
def relock_frame(layout):
    """Put the map frame back to its designed size (QGIS 4 preview grows it)."""
    m = book_map(layout)
    if m is None:
        return False
    try:
        w = m.customProperty("hld_frame_w"); h = m.customProperty("hld_frame_h")
        x = m.customProperty("hld_frame_x"); y = m.customProperty("hld_frame_y")
        if not (w and h):
            return False
        cur = m.sizeWithUnits(); pos = m.positionWithUnits()
        if (abs(cur.width() - float(w)) < 0.01 and abs(cur.height() - float(h)) < 0.01
                and abs(pos.x() - float(x)) < 0.01 and abs(pos.y() - float(y)) < 0.01):
            return False                                  # already right: no edit recorded
        m.attemptMove(_mm_pt(x, y)); m.attemptResize(_mm_sz(w, h))
        return True
    except Exception:
        _swallowed_note()
        return False


def lock_frame_position_here(layout):
    """Store the frame's CURRENT position AND size as the designed ones, so an operator who
    restyles the layout (other page size, frame moved or resized) keeps it on every page."""
    m = book_map(layout)
    if m is None:
        return False
    pos = m.positionWithUnits()
    size = m.sizeWithUnits()
    m.setCustomProperty("hld_frame_x", float(pos.x()))
    m.setCustomProperty("hld_frame_y", float(pos.y()))
    m.setCustomProperty("hld_frame_w", float(size.width()))
    m.setCustomProperty("hld_frame_h", float(size.height()))
    relock_frame(layout)
    return True


def page_titles(layout):
    at = layout.atlas()
    out = []
    cov = at.coverageLayer()
    if cov is None:
        return out
    feats = sorted(cov.getFeatures(), key=lambda f: (f["seq"] is None, f["seq"] or 0))
    for i, f in enumerate(feats):
        out.append((i, str(f["page_title"] or "Page %d" % (i + 1))))
    return out


def legend_overflow_pages(layout):
    """Pages whose legend content is taller than the legend box (bar warning). The box itself
    is put back exactly as it was - this only measures."""
    from qgis.core import QgsLayoutExporter
    leg = book_legend(layout)
    if leg is None or not layout.atlas().enabled():
        return []
    size = leg.sizeWithUnits()
    box_h = float(size.height())
    rr = leg.resizeToContents()
    leg.setResizeToContents(True)
    out = []
    at = layout.atlas()
    ex = QgsLayoutExporter(layout)
    at.updateFeatures()
    at.beginRender()
    try:
        for i in range(at.count()):
            at.seekTo(i)
            ex.renderPageToImage(0, dpi=12)
            leg.adjustBoxSize()
            if float(leg.rect().height()) > box_h + 0.5:
                out.append(i)
    finally:
        at.endRender()
        leg.setResizeToContents(rr)
        leg.attemptResize(size)
    return out
