"""Reviewable HeroTel take-off using read-only bounded QGIS snapshots."""
import json
import re
from dataclasses import replace
from pathlib import Path
import time

from qgis.PyQt import sip
from qgis.PyQt.QtCore import Qt, QTimer
from qgis.PyQt.QtWidgets import (QCheckBox, QComboBox, QDialog, QFileDialog,
                                QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                                QPushButton, QTableWidget, QTableWidgetItem,
                                QTextEdit, QVBoxLayout)
from qgis.core import (QgsApplication, QgsCoordinateTransform, QgsGeometry,
                       QgsProject, QgsSpatialIndex, QgsTask, QgsVectorLayer, QgsWkbTypes)

from fibre_automation.herotel_boq.mapping import Binding
from fibre_automation.herotel_boq.model import (INPUT_ROWS, MAX_BYTES, MAX_FEATURES,
                                               Layer, Record, Snapshot, fingerprint)
from fibre_automation.herotel_boq.quantities import calculate
from fibre_automation.herotel_boq.workbook import TEMPLATE, export

_FILE_CHECK_S = 1.0  # max gap between source-file stat checks while capturing


class SourceMappingDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('HeroTel BOQ — source mapping and preview')
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.resize(1150, 720)
        self.project = QgsProject.instance()
        self.layers = {layer.id(): layer for layer in self.project.mapLayers().values()
                       if isinstance(layer, QgsVectorLayer)}
        self.task = None
        self.snapshot = self.result = None
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._capture_tick)
        self.capture = None
        self.connections = []
        self.invalid = False
        layout = QVBoxLayout(self)
        note = QLabel('Select sources and exact fields. Green inputs only; formulas are preserved. '
                      'Trenching and backhaul are excluded. Missing inputs stay #N/A. '
                      'Mapping review confirms physical materials and the complete selected population.')
        note.setWordWrap(True)
        layout.addWidget(note)
        self.scope = QLineEdit('All selected data')
        self.scope.setPlaceholderText('Scope name (aggregate mode)')
        layout.addWidget(self.scope)
        self.phased = QCheckBox('Separate phases (enter phase names separated by commas above)')
        layout.addWidget(self.phased)
        phase_options = QHBoxLayout()
        self.phase_layer = QComboBox()
        self.phase_layer.addItem('Phase polygons: none', '')
        for identity, layer in self.layers.items():
            if layer.geometryType() == QgsWkbTypes.GeometryType.PolygonGeometry:
                self.phase_layer.addItem(layer.name(), identity)
        self.phase_name_field = QLineEdit()
        self.phase_name_field.setPlaceholderText('Phase polygon name field')
        phase_options.addWidget(self.phase_layer)
        phase_options.addWidget(self.phase_name_field)
        layout.addLayout(phase_options)
        self.table = QTableWidget(len(INPUT_ROWS), 5)
        self.table.setHorizontalHeaderLabels(['BOQ input', 'Source layer', 'Operation', 'Quantity field', 'Mapping options JSON'])
        labels = json.loads(TEMPLATE.read_text(encoding='utf-8'))['rows']
        for i, row in enumerate(INPUT_ROWS):
            item = QTableWidgetItem(f'{row}: {labels[row-1][0]["value"] or ""}')
            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            item.setData(Qt.ItemDataRole.UserRole, row)
            self.table.setItem(i, 0, item)
            sources = QComboBox()
            sources.addItem('Unresolved — no source', '')
            for identity, layer in self.layers.items():
                sources.addItem(layer.name(), identity)
            self.table.setCellWidget(i, 1, sources)
            operation = QComboBox()
            operation.addItems(['count', 'sum', 'length', 'splitter8', 'splitter16'])
            self.table.setCellWidget(i, 2, operation)
            fields = QComboBox()
            fields.addItem('')
            self.table.setCellWidget(i, 3, fields)
            self.table.setItem(i, 4, QTableWidgetItem('{}'))
            sources.currentIndexChanged.connect(lambda _, index=i: self._source_changed(index))
        self.table.setColumnWidth(0, 285)
        self.table.setColumnWidth(1, 210)
        self.table.setColumnWidth(4, 300)
        layout.addWidget(self.table)
        help_text = QLabel('Options: {"filters": [["Type", "M8"]], "slack_field": "Slack", '
                           '"total_field": "Total_Length", "rationale": "Reviewed material and scope"}. '
                           'Filters use exact values. No automatic material substitution.')
        help_text.setWordWrap(True)
        layout.addWidget(help_text)
        self.reviewed = QCheckBox('I reviewed the mappings, materials and complete source coverage for each mapped input')
        layout.addWidget(self.reviewed)
        buttons = QHBoxLayout()
        for title, handler in [('Add source for selected input', self._add_source), ('Load mapping', self._load_mapping), ('Save mapping', self._save_mapping),
                               ('Capture and preview', self._preview), ('Export preview', self._export),
                               ('Cancel current work', self._cancel)]:
            button = QPushButton(title)
            button.clicked.connect(handler)
            buttons.addWidget(button)
        layout.addLayout(buttons)
        self.output = QTextEdit()
        self.output.setReadOnly(True)
        layout.addWidget(self.output)

    def _add_source(self):
        selected = self.table.currentRow()
        if selected < 0:
            return
        i = self.table.rowCount()
        self.table.insertRow(i)
        self.table.setItem(i, 0, self.table.item(selected, 0).clone())
        for col in (1, 2, 3):
            original = self.table.cellWidget(selected, col)
            combo = QComboBox()
            for index in range(original.count()):
                combo.addItem(original.itemText(index), original.itemData(index))
            self.table.setCellWidget(i, col, combo)
        self.table.setItem(i, 4, QTableWidgetItem('{}'))
        self.table.cellWidget(i, 1).currentIndexChanged.connect(lambda _, index=i: self._source_changed(index))
        self.reviewed.setChecked(False)

    def _source_changed(self, i):
        fields = self.table.cellWidget(i, 3)
        fields.clear()
        fields.addItem('')
        layer = self.layers.get(self.table.cellWidget(i, 1).currentData())
        if layer is not None and not sip.isdeleted(layer):
            fields.addItems([f.name() for f in layer.fields()])
        self.reviewed.setChecked(False)

    def _config(self):
        mappings = []
        for i in range(self.table.rowCount()):
            row = self.table.item(i, 0).data(Qt.ItemDataRole.UserRole)
            layer_id = self.table.cellWidget(i, 1).currentData()
            if not layer_id:
                continue
            options = json.loads(self.table.item(i, 4).text())
            allowed = {'filters', 'slack_field', 'total_field', 'rationale', 'phase_field', 'phase_constant', 'identity_field', 'allow_empty_filter'}
            if not isinstance(options, dict) or set(options)-allowed:
                raise ValueError('Unsupported mapping options')
            mappings.append(dict(row=row, layer_id=layer_id, operation=self.table.cellWidget(i, 2).currentText(),
                                 field=self.table.cellWidget(i, 3).currentText(), options=options))
        return dict(contract_version=1, scope=self.scope.text().strip(), mappings=mappings,
                    phased=self.phased.isChecked(), phase_layer=self.phase_layer.currentData(),
                    phase_name_field=self.phase_name_field.text().strip())

    def _save_mapping(self):
        path, _ = QFileDialog.getSaveFileName(self, 'Save reviewed mapping', '', 'JSON (*.json)')
        if path:
            try:
                Path(path).write_text(json.dumps(self._config(), indent=2), encoding='utf-8')
            except Exception as exc:
                self._error(exc)

    def _load_mapping(self):
        path, _ = QFileDialog.getOpenFileName(self, 'Load mapping', '', 'JSON (*.json)')
        if not path:
            return
        try:
            cfg = json.loads(Path(path).read_text(encoding='utf-8'))
            if cfg['contract_version'] != 1:
                raise ValueError('Unsupported mapping contract version')
            for i in range(self.table.rowCount()):
                self.table.cellWidget(i, 1).setCurrentIndex(0)
            assigned = set()
            for entry in cfg['mappings']:
                i = INPUT_ROWS.index(entry['row'])
                if i in assigned:
                    self.table.setCurrentCell(i, 0)
                    self._add_source()
                    i = self.table.rowCount()-1
                assigned.add(i)
                combo = self.table.cellWidget(i, 1)
                index = combo.findData(entry['layer_id'])
                if index < 0:
                    raise ValueError('Saved source layer unavailable; remap explicitly')
                combo.setCurrentIndex(index)
                self.table.cellWidget(i, 2).setCurrentText(entry['operation'])
                self.table.cellWidget(i, 3).setCurrentText(entry['field'])
                self.table.item(i, 4).setText(json.dumps(entry['options']))
            self.scope.setText(cfg['scope'])
            self.phased.setChecked(cfg.get('phased', False))
            index = self.phase_layer.findData(cfg.get('phase_layer', ''))
            if index < 0:
                raise ValueError('Saved phase layer unavailable')
            self.phase_layer.setCurrentIndex(index)
            self.phase_name_field.setText(cfg.get('phase_name_field', ''))
            self.reviewed.setChecked(False)
        except Exception as exc:
            self._error(exc)

    def _invalidate(self, *args):
        self.invalid = True
        if self.task:
            self.task.cancel()

    def _disconnect(self):
        for obj, signal in self.connections:
            if not sip.isdeleted(obj):
                try:
                    signal.disconnect(self._invalidate)
                except (TypeError, RuntimeError):
                    pass
        self.connections = []

    def _preview(self):
        if self.task or self.timer.isActive():
            return
        try:
            if not self.reviewed.isChecked():
                raise ValueError('Review and confirm mappings before capture')
            cfg = self._config()
            if not cfg['scope'] or not cfg['mappings']:
                raise ValueError('Select a source and name the scope')
            self._disconnect()
            self.invalid = False
            self.snapshot = self.result = None
            selected = sorted({m['layer_id'] for m in cfg['mappings']})
            phases = tuple(s.strip() for s in cfg['scope'].split(',')) if cfg['phased'] else (cfg['scope'],)
            if not all(phases) or len(phases) > 64 or len(set(phases)) != len(phases):
                raise ValueError('Use 1–64 distinct phase names')
            phase_id = cfg['phase_layer'] if cfg['phased'] else ''
            if phase_id:
                phase = self.layers[phase_id]
                if cfg['phase_name_field'] not in [f.name() for f in phase.fields()]:
                    raise ValueError('Phase name field missing')
                selected = [phase_id]+[identity for identity in selected if identity != phase_id]
            if len(selected) > 200:
                raise ValueError('More than 200 layers')
            self.capture = dict(config=cfg, pending=selected, layers=[], current=None,
                                count=0, bytes=0, tick_max=0, project_file=self.project.fileName(),
                                polygons={}, phase_index=QgsSpatialIndex(), phase_invalid=False, phase_id=phase_id, phases=phases, file_states={})
            for identity in selected:
                layer = self.layers[identity]
                if sip.isdeleted(layer) or not layer.isValid() or layer.isEditable():
                    raise ValueError('Source invalid or has an active edit session; finish edits before capture')
                if layer.subsetString():
                    raise ValueError('Source has a provider subset filter. Review/remove it before a complete BOQ capture')
                source = layer.source().split('|')[0]
                import re
                if re.search(r'password\s*=|token\s*=|authcfg\s*=|user\s*=', layer.source(), re.I):
                    raise ValueError('Credential-bearing source descriptors unsupported')
                if layer.providerType() not in ('ogr', 'memory') or (layer.providerType() != 'memory' and
                    (not Path(source).is_file() or source.startswith(('\\\\', '//')) or '://' in source)):
                    raise ValueError('Initial BOQ capture supports local OGR files and memory layers only')
                if layer.providerType() != 'memory':
                    path = Path(source)
                    paths = [path]
                    if path.suffix.lower() == '.shp':
                        paths += [path.with_suffix(suffix) for suffix in ('.dbf', '.shx', '.prj', '.cpg') if path.with_suffix(suffix).exists()]
                    for path in paths:
                        stat = path.stat()
                        self.capture['file_states'][str(path)] = (stat.st_size, stat.st_mtime_ns)
                for signal in (layer.dataChanged, layer.editingStarted):
                    signal.connect(self._invalidate)
                    self.connections.append((layer, signal))
            for signal in (self.project.layersWillBeRemoved, self.project.cleared):
                signal.connect(self._invalidate)
                self.connections.append((self.project, signal))
            self.timer.start(1)
        except Exception as exc:
            self._error(exc)

    def _capture_tick(self):
        started = time.perf_counter()
        try:
            state = self.capture
            if self.invalid or self.project.fileName() != state['project_file']:
                raise ValueError('Project changed; capture invalidated')
            # Stat the sources at most once a second (a tick is ~15 ms), plus a forced
            # check before _captured(). _export() re-checks every file twice anyway.
            if started - state.get('files_checked_at', 0.0) >= _FILE_CHECK_S:
                self._check_capture_files(state, started)
            for _ in range(200):
                if time.perf_counter()-started >= .015:
                    break
                if state['current'] is None:
                    if not state['pending']:
                        self._check_capture_files(state, time.perf_counter())
                        self.timer.stop()
                        state['tick_max'] = max(state['tick_max'], time.perf_counter()-started)
                        self._captured()
                        return
                    identity = state['pending'].pop(0)
                    layer = self.layers[identity]
                    source = layer.source().split('|')[0] if layer.providerType() != 'memory' else 'memory:'+identity
                    physical = str(Path(source).resolve())+'|'+layer.source().partition('|')[2] if layer.providerType() != 'memory' else source
                    state['current'] = dict(identity=physical, qgis_id=identity, name=layer.name(), source=source,
                                            fields=tuple(f.name() for f in layer.fields()), iterator=layer.getFeatures(), records=[])
                current = state['current']
                feature = next(current['iterator'], None)
                if feature is None:
                    records = tuple(current['records'])
                    fields = current['fields']
                    if state['phase_id']:
                        fields = tuple(dict.fromkeys((*fields, '__spatial_phase__', '__phase_issue__', '__geometry_wkt__', '__crs__')))
                    state['layers'].append((current['qgis_id'], Layer(current['identity'], current['source'], current['name'], fields, records, 'pending-snapshot-hash')))
                    state['current'] = None
                    continue
                values = {}
                for field, value in zip(current['fields'], feature.attributes()):
                    if value is None or (hasattr(value, 'isNull') and value.isNull()):
                        value = None
                    elif not isinstance(value, (str, bool, int, float)):
                        value = str(value)
                    values[field] = value
                if current['qgis_id'] == state['phase_id']:
                    geometry = feature.geometry()
                    values['__geometry_wkt__'] = geometry.asWkt()
                    values['__crs__'] = self.layers[current['qgis_id']].crs().authid()
                    name = values.get(state['config']['phase_name_field'])
                    if name is None or geometry.isEmpty() or not geometry.isGeosValid():
                        state['phase_invalid'] = True
                    else:
                        state['polygons'][feature.id()] = (str(name), QgsGeometry(geometry))
                        state['phase_index'].addFeature(feature)
                    if len(state['polygons']) > 10000:
                        raise ValueError('Phase polygon capacity exceeded')
                elif state['phase_id'] and self.layers[current['qgis_id']].geometryType() == QgsWkbTypes.GeometryType.PointGeometry:
                    geometry = QgsGeometry(feature.geometry())
                    values['__geometry_wkt__'] = geometry.asWkt()
                    values['__crs__'] = self.layers[current['qgis_id']].crs().authid()
                    phase_layer = self.layers[state['phase_id']]
                    source_layer = self.layers[current['qgis_id']]
                    if not source_layer.crs().isValid() or not phase_layer.crs().isValid():
                        values['__phase_issue__'] = 'Invalid phase/source CRS'
                    else:
                        geometry.transform(QgsCoordinateTransform(source_layer.crs(), phase_layer.crs(), self.project))
                        candidates = [state['polygons'][fid] for fid in state['phase_index'].intersects(geometry.boundingBox())]
                        hits = [name for name, polygon in candidates if polygon.contains(geometry)]
                        touches = [name for name, polygon in candidates if polygon.intersects(geometry)]
                        if state['phase_invalid'] or geometry.isEmpty() or len(hits) != 1 or len(touches) != 1:
                            values['__phase_issue__'] = 'Missing, invalid, boundary or ambiguous phase geometry'
                        else:
                            values['__spatial_phase__'] = hits[0]
                            for mapping in state['config']['mappings']:
                                if mapping['layer_id'] == current['qgis_id']:
                                    options = mapping['options']
                                    attribute = values.get(options.get('phase_field', '')) if options.get('phase_field') else options.get('phase_constant')
                                    if attribute is not None and str(attribute) != hits[0]:
                                        values['__phase_issue__'] = 'Attribute/spatial phase conflict'
                record = Record(str(feature.id()), values)
                current['records'].append(record)
                state['count'] += 1
                state['bytes'] += len(json.dumps(values, ensure_ascii=False).encode())
                if state['count'] > MAX_FEATURES or state['bytes'] > MAX_BYTES:
                    raise ValueError('Snapshot capacity exceeded')
            state['tick_max'] = max(state['tick_max'], time.perf_counter()-started)
            self.output.setPlainText(f'Captured {state["count"]} features; longest tick {state["tick_max"]:.3f}s')
        except Exception as exc:
            self.timer.stop()
            self._error(exc)

    @staticmethod
    def _check_capture_files(state, now):
        for path, previous in state['file_states'].items():
            stat = Path(path).stat()
            if (stat.st_size, stat.st_mtime_ns) != previous:
                raise ValueError('Source file changed; capture invalidated')
        state['files_checked_at'] = now

    def _captured(self):
        state = self.capture
        cfg = state['config']
        identities = {qid: layer.identity for qid, layer in state['layers']}
        snapshot = Snapshot(self.project.title() or self.project.baseName(), tuple(layer for _, layer in state['layers']))
        bindings = []
        for item in cfg['mappings']:
            options = dict(item['options'])
            options['filters'] = tuple(tuple(pair) for pair in options.get('filters', []))
            if cfg['phased'] and not options.get('phase_field') and not options.get('phase_constant'):
                options['phase_field'] = '__spatial_phase__'
            bindings.append(Binding(item['row'], identities[item['layer_id']], item['operation'], item['field'],
                                    reviewed=True, complete_scope=True, **options))
        self.captured_config = cfg
        self.captured_files = state['file_states']
        self.bindings = tuple(bindings)
        phases = state['phases']

        def work(task):
            hashed = replace(snapshot, layers=tuple(replace(layer, source_hash=fingerprint(
                [dict(fid=r.fid, values=dict(r.values)) for r in layer.records])) for layer in snapshot.layers))
            return hashed, calculate(hashed, bindings, phases, aggregate=not cfg['phased'])

        def finished(exc, answer):
            self.task = None
            if sip.isdeleted(self):
                return
            if exc or not answer or self.invalid:
                self._error(exc or ValueError('Capture invalidated or cancelled'))
                return
            self.snapshot, self.result = answer
            lines = [f'{scope} / {row}: {self.result.cells[scope, row] if self.result.cells[scope,row] is not None else "UNRESOLVED"}' for scope in phases for row in INPUT_ROWS]
            self.output.setPlainText('SCOPED PREVIEW — civil/backhaul excluded\n'+'\n'.join(lines)+'\n\n'+'\n'.join(self.result.issues[:100]))
        self.task = QgsTask.fromFunction('HeroTel BOQ preview', work, on_finished=finished)
        QgsApplication.taskManager().addTask(self.task)

    def _export(self):
        if self.task or not self.result:
            return
        try:
            if self.invalid or self._config() != self.captured_config or not self.reviewed.isChecked():
                raise ValueError('Mapping/project changed; capture a fresh preview')
            for path, previous in self.captured_files.items():
                stat = Path(path).stat()
                if (stat.st_size, stat.st_mtime_ns) != previous:
                    raise ValueError('Source file changed; capture a fresh preview')
            parent = self._choose_output_directory()
            if not parent:
                return
            # A modal folder chooser runs a nested event loop; sources can change
            # while it is open. Revalidate after the user chooses a destination.
            if self.invalid or self._config() != self.captured_config or not self.reviewed.isChecked():
                raise ValueError('Project or source choices changed. Analyse again before exporting.')
            for path, previous in self.captured_files.items():
                stat = Path(path).stat()
                if (stat.st_size, stat.st_mtime_ns) != previous:
                    raise ValueError('Source file changed. Analyse again before exporting.')
            destination = Path(parent)/('HeroTel BOQ '+time.strftime('%Y%m%d_%H%M%S')+'_'+str(time.time_ns()))
            snapshot, bindings, result = self.snapshot, self.bindings, self.result

            def work(task):
                return str(export(snapshot, bindings, result, destination, cancelled=task.isCanceled))

            def finished(exc, answer):
                self.task = None
                if sip.isdeleted(self):
                    return
                if exc or not answer:
                    self._error(exc or ValueError('Export cancelled'))
                else:
                    complete = all(result.cells.get(('Whole project', row)) is not None for row in INPUT_ROWS)
                    self.output.setPlainText(('Saved scoped BOQ:\n' if complete else 'Saved scoped draft:\n')+answer+
                                             '\nProvenance is in the same folder.'+
                                             ('' if complete else '\nUnresolved inputs are #N/A.'))
                if hasattr(self, '_update_ready'):
                    self._update_ready()
            self.task = QgsTask.fromFunction('Export HeroTel BOQ', work, on_finished=finished)
            QgsApplication.taskManager().addTask(self.task)
        except Exception as exc:
            self._error(exc)

    def _choose_output_directory(self):
        return QFileDialog.getExistingDirectory(self, 'Choose output parent folder')

    def _cancel(self):
        self.timer.stop()
        self.invalid = True
        if self.task:
            self.task.cancel()
        self.capture = None

    def _error(self, exc):
        self.output.setPlainText(str(exc))
        QMessageBox.warning(self, 'HeroTel BOQ', str(exc))

    def closeEvent(self, event):
        self._cancel()
        self._disconnect()
        super().closeEvent(event)


class HeroTelBoqDialog(SourceMappingDialog):
    """Staff workflow; the inherited capture/export engine stays read-only."""

    def __init__(self, parent=None, *, automatic_export=True):
        self._automatic_export_requested = automatic_export
        self._automatic_export = False
        self._auto_export_pending = automatic_export
        super().__init__(parent)
        from qgis.PyQt.QtWidgets import QGroupBox, QScrollArea
        from fibre_automation.herotel_boq.discovery import candidate_roles
        self.setWindowTitle('Create HeroTel BOQ')
        self.resize(1000, 720)
        layout = self.layout()
        while layout.count():
            item = layout.takeAt(0)
            if item.widget():
                item.widget().hide()
            elif item.layout():
                nested = item.layout()
                while nested.count():
                    child = nested.takeAt(0)
                    if child.widget():
                        child.widget().hide()
        self._automatic_choices = {}
        self._confirmed_facts = {}
        self._fact_boxes = {}
        self._manual_mode = False
        self._automatic_snapshot = None
        self._analysis_generation = 0
        self._role_boxes = {}
        self._role_choice_labels = {}
        self._candidate_ids = []
        self._geometry_types = {}
        physical_seen = set()
        for identity, layer in self.layers.items():
            if sip.isdeleted(layer) or not layer.isValid():
                continue
            geometry = {QgsWkbTypes.GeometryType.PointGeometry: 'point',
                        QgsWkbTypes.GeometryType.LineGeometry: 'line',
                        QgsWkbTypes.GeometryType.PolygonGeometry: 'polygon'}.get(layer.geometryType(), 'other')
            if not candidate_roles(layer.name(), tuple(f.name() for f in layer.fields()), geometry):
                continue
            physical = (layer.providerType(), layer.source())
            if physical in physical_seen:
                continue
            physical_seen.add(physical)
            self._candidate_ids.append(identity)
            self._geometry_types[identity] = geometry
        title = QLabel(self.project.title() or self.project.baseName() or 'Current project')
        title.setStyleSheet('font-size:20px; font-weight:bold;')
        layout.addWidget(title)
        layout.addWidget(QLabel('Whole project · Trenching and backhaul excluded'))
        note = QLabel('Reads the project and saves the BOQ automatically when all quantities are verified. Missing information is shown below.')
        note.setWordWrap(True)
        layout.addWidget(note)
        self.summary = QTableWidget(len(INPUT_ROWS), 4)
        self.summary.setHorizontalHeaderLabels(['Material / item', 'Quantity', 'Status', 'Source'])
        self.summary.setColumnWidth(0, 380)
        self.summary.setColumnWidth(1, 100)
        self.summary.setColumnWidth(2, 140)
        self.summary.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.summary)
        self.questions_group = QGroupBox('Project questions')
        self.questions_layout = QVBoxLayout(self.questions_group)
        self.questions_scroll = QScrollArea()
        self.questions_scroll.setWidgetResizable(True)
        self.questions_scroll.setMaximumHeight(180)
        self.questions_scroll.setWidget(self.questions_group)
        layout.addWidget(self.questions_scroll)
        self.questions_scroll.hide()
        self.questions_group.hide()
        self.output.setMaximumHeight(135)
        self.output.show()
        layout.addWidget(self.output)
        self.confirm = QCheckBox('These are the current project sources for this BOQ')
        self.confirm.toggled.connect(self._update_ready)
        layout.addWidget(self.confirm)
        self.confirm.setVisible(not automatic_export)
        buttons = QHBoxLayout()
        self.analyze_button = QPushButton('Analyse project again')
        self.analyze_button.clicked.connect(self._analyse)
        buttons.addWidget(self.analyze_button)
        self.generate_button = QPushButton('Generate BOQ')
        self.generate_button.clicked.connect(self._generate)
        self.generate_button.setEnabled(False)
        buttons.addWidget(self.generate_button)
        self.draft_button = QPushButton('Save incomplete draft')
        self.draft_button.clicked.connect(self._draft)
        self.draft_button.setEnabled(False)
        buttons.addWidget(self.draft_button)
        cancel = QPushButton('Cancel')
        cancel.clicked.connect(self._cancel)
        buttons.addWidget(cancel)
        layout.addLayout(buttons)
        self.output.setPlainText('Reading the project…')
        QTimer.singleShot(0, self._start_automatically)

    def _start_automatically(self):
        if not self.invalid:
            self._analyse()

    def _config(self):
        if self._manual_mode:
            return super()._config()
        return dict(contract_version=1, scope='Whole project', phased=False,
                    phase_layer='', phase_name_field='',
                    choices={k: sorted(v) for k, v in self._automatic_choices.items()},
                    confirmations={k: sorted(v) for k, v in self._confirmed_facts.items()},
                    mappings=[dict(row=15, layer_id=identity, operation='count', field='',
                                   options={'rationale': 'Discovery capture only'})
                              for identity in self._candidate_ids])

    def _preview(self):
        # Preserve the explicit mapping API for diagnostic tools and phase tests.
        # The staff workflow enters through _analyse, not this method.
        self._manual_mode = True
        return super()._preview()

    def _analyse(self):
        if self.task or self.timer.isActive():
            return
        self._auto_export_pending = self._automatic_export_requested
        self._manual_mode = False
        from fibre_automation.herotel_boq.discovery import candidate_roles
        self.layers = {layer.id(): layer for layer in self.project.mapLayers().values()
                       if isinstance(layer, QgsVectorLayer)}
        self._candidate_ids = []
        self._geometry_types = {}
        seen = set()
        for identity, layer in self.layers.items():
            if sip.isdeleted(layer) or not layer.isValid():
                continue
            geometry = {QgsWkbTypes.GeometryType.PointGeometry: 'point',
                        QgsWkbTypes.GeometryType.LineGeometry: 'line'}.get(layer.geometryType(), 'other')
            if candidate_roles(layer.name(), tuple(f.name() for f in layer.fields()), geometry):
                key = (layer.providerType(), layer.source(), layer.subsetString())
                if key not in seen:
                    seen.add(key)
                    self._candidate_ids.append(identity)
                    self._geometry_types[identity] = geometry
        self._automatic_choices = {}
        self._confirmed_facts = {}
        self._fact_boxes = {}
        self._role_boxes = {}
        self._role_choice_labels = {}
        while self.questions_layout.count():
            item = self.questions_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.questions_group.hide()
        self.questions_scroll.hide()
        self.confirm.setChecked(False)
        self._automatic_snapshot = None
        self.reviewed.setChecked(True)
        self.generate_button.setEnabled(False)
        self.draft_button.setEnabled(False)
        self.output.setPlainText('Reading candidate project layers…')
        if not self._candidate_ids:
            self.snapshot = self.result = None
            self.output.setPlainText('No supported network sources were found. Open the project containing its demand, poles, equipment and cable layers, then analyse again.')
            return
        super()._preview()
        if self.timer.isActive():
            self.project.layersAdded.connect(self._invalidate)
            self.connections.append((self.project, self.project.layersAdded))

    def _captured(self):
        if self._manual_mode:
            return super()._captured()
        state = self.capture
        self.captured_files = state['file_states']
        self._captured_geometries = {layer.identity: self._geometry_types[qid] for qid, layer in state['layers']}
        self._automatic_snapshot = Snapshot(self.project.title() or self.project.baseName(),
                                           tuple(layer for _, layer in state['layers']),
                                           schema_name='automatic-exact-values')
        from fibre_automation.herotel_boq.profiles import automatic_profile_supported
        self._automatic_export = bool(self._automatic_export_requested and
                                      automatic_profile_supported(self._automatic_snapshot))
        self.confirm.setVisible(not self._automatic_export)
        self._interpret()

    def _interpret(self):
        from fibre_automation.herotel_boq.discovery import discover
        if self.task or not self._automatic_snapshot or self.invalid:
            return
        self._analysis_generation += 1
        generation = self._analysis_generation
        snapshot = self._automatic_snapshot
        choices = {k: tuple(v) for k, v in self._automatic_choices.items()}
        facts = {k: tuple(v) for k, v in self._confirmed_facts.items()}
        geometries = dict(self._captured_geometries)
        self.captured_config = self._config()
        self.confirm.setChecked(False)
        self.generate_button.setEnabled(False)
        self.draft_button.setEnabled(False)

        def work(task):
            hashed = replace(snapshot, layers=tuple(replace(layer, source_hash=fingerprint(
                [dict(fid=r.fid, values=dict(r.values)) for r in layer.records])) for layer in snapshot.layers))
            discovery = discover(hashed, geometries, choices, facts)
            return hashed, discovery, calculate(hashed, discovery.bindings, ('Whole project',))

        def finished(exc, answer):
            if sip.isdeleted(self):
                return
            self.task = None
            if generation != self._analysis_generation:
                return
            if exc or not answer or self.invalid:
                self._error(exc or ValueError('Project changed or analysis cancelled. Analyse the project again.'))
                return
            self.snapshot, self.discovery, self.result = answer
            self.bindings = self.discovery.bindings
            self._render_results()
        self.task = QgsTask.fromFunction('Analyse HeroTel BOQ', work, on_finished=finished)
        QgsApplication.taskManager().addTask(self.task)

    def _render_results(self):
        from fibre_automation.herotel_boq.discovery import ROLE_LABELS
        rows = json.loads(TEMPLATE.read_text(encoding='utf-8'))['rows']
        for index, row in enumerate(INPUT_ROWS):
            value = self.result.cells['Whole project', row]
            texts = (str(rows[row-1][0]['value']), '—' if value is None else f'{value:,.2f}'.rstrip('0').rstrip('.'),
                     'Needs information' if value is None else 'Calculated',
                     '; '.join(self.discovery.reasons.get(row, ())) or 'No verified source')
            for col, text in enumerate(texts):
                item = QTableWidgetItem(text)
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                self.summary.setItem(index, col, item)
        if not self._role_boxes:
            for role, candidates in self.discovery.candidates.items():
                if not any(question.startswith(ROLE_LABELS[role]+': choose')
                           for question in self.discovery.questions):
                    continue
                label = QLabel(f'{ROLE_LABELS[role]}: select the current source(s), excluding old copies.')
                self._role_choice_labels[role] = label
                self.questions_layout.addWidget(label)
                self._role_boxes[role] = []
                for identity, name in candidates:
                    box = QCheckBox(name)
                    box.toggled.connect(lambda _: self._update_ready())
                    self.questions_layout.addWidget(box)
                    self._role_boxes[role].append((identity, box))
                apply = QPushButton('Use these sources')
                apply.clicked.connect(lambda _, r=role: self._select_sources(r))
                self.questions_layout.addWidget(apply)
        for role, label in self._role_choice_labels.items():
            if role in self._automatic_choices:
                label.setText(f'Selected sources for {ROLE_LABELS[role].lower()} (change below if needed)')
        for kind, items in self.discovery.confirmations.items():
            for identity, name in items:
                if (kind, identity) in self._fact_boxes:
                    continue
                title = (f'Each feature in “{name}” represents exactly one home' if kind == 'one_home'
                         else f'The cable length and slack fields in “{name}” are in metres')
                box = QCheckBox(title)
                box.toggled.connect(lambda _: self._update_ready())
                self._fact_boxes[kind, identity] = box
                self.questions_layout.addWidget(box)
                apply = QPushButton('Confirm this project fact')
                apply.clicked.connect(lambda _, k=kind, i=identity: self._confirm_fact(k, i))
                self.questions_layout.addWidget(apply)
        self.questions_group.setVisible(bool(self._role_boxes or self._fact_boxes))
        self.questions_scroll.setVisible(bool(self._role_boxes or self._fact_boxes))
        issues = list(self.discovery.questions) + list(self.discovery.observations)
        labels = {r: str(rows[r-1][0]['value']) for r in INPUT_ROWS}
        grouped_issues = {}
        for issue in self.result.issues:
            for row in INPUT_ROWS:
                issue = issue.replace(f'Row {row}:', labels[row]+':').replace(f'Row {row},', labels[row]+',')
            message = re.sub(r', feature [^:]+:', ':', issue)
            grouped_issues[message] = grouped_issues.get(message, 0) + int(', feature ' in issue)
        issues.extend(message + (f' ({count} records)' if count > 1 else '')
                      for message, count in grouped_issues.items())
        resolved = sum(self.result.cells['Whole project', r] is not None for r in INPUT_ROWS)
        self.output.setPlainText(f'{resolved} of {len(INPUT_ROWS)} BOQ inputs calculated.\n'+'\n'.join(issues[:80]))
        self._update_ready()
        if self._automatic_export and self._auto_export_pending and self.generate_button.isEnabled():
            self._auto_export_pending = False
            QTimer.singleShot(0, self._generate)

    def _select_sources(self, role):
        if self.task:
            return
        self._automatic_choices[role] = [identity for identity, box in self._role_boxes[role] if box.isChecked()]
        self._interpret()

    def _confirm_fact(self, kind, identity):
        if self.task:
            return
        previous = set(self._confirmed_facts.get(kind, ()))
        if self._fact_boxes[kind, identity].isChecked():
            previous.add(identity)
        else:
            previous.discard(identity)
        self._confirmed_facts[kind] = sorted(previous)
        self._interpret()

    def _update_ready(self):
        pending = any([identity for identity, box in boxes if box.isChecked()] != self._automatic_choices.get(role, [])
                      for role, boxes in self._role_boxes.items())
        pending = pending or any(box.isChecked() != (identity in self._confirmed_facts.get(kind, ()))
                                 for (kind, identity), box in self._fact_boxes.items())
        ready = bool(self.result and not self.invalid and not self.task and
                     (self._automatic_export or self.confirm.isChecked()) and not pending)
        complete = bool(self.result and getattr(self, 'discovery', None) and not self.discovery.questions and
                        all(self.result.cells['Whole project', row] is not None for row in INPUT_ROWS))
        self.generate_button.setEnabled(ready and complete)
        self.draft_button.setEnabled(ready and not complete)

    def _generate(self):
        self._update_ready()
        if self.generate_button.isEnabled():
            super()._export()
            self._update_ready()

    def _automatic_output_parent(self):
        from qgis.PyQt.QtCore import QStandardPaths
        documents = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DocumentsLocation)
        if not documents:
            raise ValueError('No Documents folder is available for the BOQ output.')
        project_name = re.sub(r'[^\w .-]', '_', self.project.title() or self.project.baseName() or 'Untitled').strip(' .')[:80]
        return Path(documents)/'Velocity Nexus BOQ'/(project_name or 'Untitled')

    def _choose_output_directory(self):
        if not self._automatic_export or self._manual_mode:
            return super()._choose_output_directory()
        parent = self._automatic_output_parent()
        parent.mkdir(parents=True, exist_ok=True)
        return str(parent)

    def _error(self, exc):
        if self._automatic_export:
            self.output.setPlainText('BOQ could not be generated:\n'+str(exc))
        else:
            super()._error(exc)

    def _draft(self):
        self._update_ready()
        if not self.draft_button.isEnabled():
            return
        answer = QMessageBox.question(self, 'Incomplete BOQ',
            'Some quantities are missing. Save a clearly marked draft with those items unresolved?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        if answer == QMessageBox.StandardButton.Yes:
            super()._export()
            self._update_ready()

    def _invalidate(self, *args):
        super()._invalidate(*args)
        if hasattr(self, 'generate_button'):
            self.generate_button.setEnabled(False)
            self.draft_button.setEnabled(False)
            self.output.setPlainText('Project data changed. Analyse the project again before generating a BOQ.')

    def _cancel(self):
        self._auto_export_pending = False
        super()._cancel()
        if hasattr(self, 'generate_button'):
            self.generate_button.setEnabled(False)
            self.draft_button.setEnabled(False)
            self.output.setPlainText('Cancelled. You can analyse the project again.')
