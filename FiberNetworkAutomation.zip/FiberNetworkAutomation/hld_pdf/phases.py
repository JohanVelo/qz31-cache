# -*- coding: utf-8 -*-
"""Phase discovery for the per-phase HLD map book.

A "phase" is a layer-tree GROUP (e.g. "Mahikeng Phase 3"), not a field on a
layer, so everything here walks the tree rather than querying attributes.
Inside each phase group we expect:

  * a **boundary** polygon layer named like the phase itself ("Phase 3") — one
    feature, labelled. It belongs on the book's OVERVIEW page only; on a detail
    page its solid fill paints over the PON zones and the satellite buildings
    underneath, which is exactly what the operator asked us to stop doing.
  * a **coverage** polygon layer ("Ponds PH3") — one atlas page per feature.
  * everything else = the phase's network content.

Nothing here mutates the project. `detect_phases()` is a pure read so it can be
asserted against the live project before a single layout is built.
"""
import re

# Group that holds a phase's layers, e.g. "Mahikeng Phase 3" / "Phase 3".
_GROUP_RE = re.compile(r"(?i)(?:^|\s)phase\s*0*(\d+)\s*$")
# The phase's own boundary polygon — the layer name is JUST "Phase <n>".
_BOUNDARY_RE = re.compile(r"(?i)^phase\s*0*(\d+)\s*$")
# The PON-zone coverage layer. Spelled "Ponds" in the field data, "PON" elsewhere.
_COVERAGE_RE = re.compile(r"(?i)^(?:ponds?|pon)\b")

# Layer kinds that stay OFF in the book on the operator's instruction. Matched
# against the name with the PH<n> suffix stripped, so it holds for every phase.
_NEVER_SHOW = ("ajoint", "demand point", "splicing")

# "To be Confirmed" content is excluded by default: it is not part of the
# approved design and must not silently become extra atlas pages.
_TBC_RE = re.compile(r"(?i)\btbc\b|to be confirmed")


def _kind(layer_name):
    """Strip the phase suffix so 'Poles PH3' and 'Poles PH7' share a kind."""
    n = re.sub(r"(?i)\s*PH\s*\d+(\.\d+)?\s*$", "", layer_name or "").strip()
    return re.sub(r"(?i)\s*v\d+\s*$", "", n).strip()


def _is_never_show(layer_name):
    k = _kind(layer_name).lower()
    return any(k.startswith(bad) for bad in _NEVER_SHOW)


def is_tbc(name):
    return bool(_TBC_RE.search(name or ""))


def _group_phase_no(name):
    m = _GROUP_RE.search(name or "")
    return int(m.group(1)) if m else None


def _polygon(layer):
    """True for a polygon vector layer (2 == QgsWkbTypes.PolygonGeometry)."""
    try:
        from qgis.core import QgsVectorLayer
        return isinstance(layer, QgsVectorLayer) and layer.geometryType() == 2
    except Exception:
        return False


def detect_phases(project=None, include_tbc=False):
    """Return one dict per phase group found in the layer tree, ordered by number.

    Each dict:
        phase_no        int
        group_name      str
        boundary        QgsVectorLayer | None   (overview page only)
        coverage        QgsVectorLayer | None   (one atlas page per feature)
        coverage_field  str | None              (page id/sort field)
        pon_count       int
        content         [QgsVectorLayer]        (drawn on the detail pages)
        excluded        [str]                   (names deliberately left out)

    Returns [] when the project has no phase groups at all — a caller must not
    fall back to "some polygon layer" and quietly build the wrong book.
    """
    from qgis.core import QgsProject
    p = project or QgsProject.instance()
    out = []
    for node in p.layerTreeRoot().children():
        if not hasattr(node, "findLayers"):
            continue                                   # a bare layer, not a group
        phase_no = _group_phase_no(node.name())
        if phase_no is None:
            continue
        boundary = coverage = None
        content, excluded = [], []
        for child in node.findLayers():
            lyr = child.layer()
            if lyr is None:
                continue
            name = lyr.name()
            if not include_tbc and is_tbc(name):
                excluded.append(name)
                continue
            m = _BOUNDARY_RE.match(name)
            if m and int(m.group(1)) == phase_no and _polygon(lyr):
                boundary = lyr
                continue                               # overview only, never content
            if coverage is None and _COVERAGE_RE.match(name) and _polygon(lyr):
                coverage = lyr
                # the coverage layer is ALSO drawn on its own detail pages
                content.append(lyr)
                continue
            if _is_never_show(name):
                excluded.append(name)
                continue
            content.append(lyr)
        out.append({
            "phase_no": phase_no,
            "group_name": node.name(),
            "boundary": boundary,
            "coverage": coverage,
            "coverage_field": coverage_field(coverage),
            "pon_count": coverage.featureCount() if coverage is not None else 0,
            "content": content,
            "excluded": excluded,
        })
    out.sort(key=lambda d: d["phase_no"])
    return out


def coverage_field(layer):
    """The field that names each atlas page. 'Pond' in the Mahikeng data; fall
    back through the usual suspects so another project's book still builds."""
    if layer is None:
        return None
    names = [f.name() for f in layer.fields()]
    for cand in ("Pond", "PON", "pon_no", "pon", "label", "zone_id", "name", "id"):
        for n in names:
            if n.lower() == cand.lower():
                return n
    return names[0] if names else None


def boundary_layers(phases):
    """Every phase boundary polygon, for the shared overview page."""
    return [ph["boundary"] for ph in phases if ph.get("boundary") is not None]


def boundary_layer_ids(phases):
    """Ids of every boundary polygon — used to assert they are absent from the
    detail page layer set. Ids, not names, so a renamed layer cannot slip past."""
    return {b.id() for b in boundary_layers(phases)}


def snapshot_visibility(project=None):
    """Record every layer node's tick state, keyed by layer id (a name can repeat, an id
    cannot). Written to disk by the caller BEFORE any change, so the operator's panel can
    be put back exactly — including the groups, which hide their children when unticked."""
    from qgis.core import QgsProject
    p = project or QgsProject.instance()
    root = p.layerTreeRoot()
    snap = {"layers": {}, "groups": {}}
    for node in root.findLayers():
        if node.layer() is not None:
            snap["layers"][node.layer().id()] = bool(node.itemVisibilityChecked())

    for grp in root.findGroups(True):
        snap["groups"][_group_path(grp)] = bool(grp.itemVisibilityChecked())
    return snap


def _group_path(node):
    """Slash-joined path so two groups with the same name stay distinct."""
    parts = []
    n = node
    while n is not None and n.parent() is not None:
        parts.append(n.name())
        n = n.parent()
    return "/".join(reversed(parts))


def restore_visibility(snapshot, project=None):
    """Put every tick back exactly as `snapshot` recorded it. Returns (restored, missing)."""
    from qgis.core import QgsProject
    p = project or QgsProject.instance()
    root = p.layerTreeRoot()
    restored, missing = 0, []
    for node in root.findLayers():
        lyr = node.layer()
        if lyr is None:
            continue
        want = snapshot.get("layers", {}).get(lyr.id())
        if want is None:
            missing.append(lyr.name())
            continue
        node.setItemVisibilityChecked(bool(want))
        restored += 1
    for grp in root.findGroups(True):
        want = snapshot.get("groups", {}).get(_group_path(grp))
        if want is not None:
            grp.setItemVisibilityChecked(bool(want))
    return restored, missing


def apply_book_visibility(phases, project=None):
    """Set the Layers panel to the book's DETAIL state, so the canvas shows what the PDF
    will show — the operator's standing rule, and the reason this is a write at all.

    ON : every phase's content layers (splitters, poles, cables, PON zones) in all phases.
    OFF: every phase boundary polygon — its solid fill paints over the PON zones and the
         satellite buildings. It comes back only on the book's overview page, via the map
         theme, which does not depend on these ticks.
    OFF: the excluded kinds (AJoint, Demand Points, Splicing, To-be-Confirmed).

    Returns a summary dict of what changed. Never touches geometry or attributes.
    """
    from qgis.core import QgsProject
    p = project or QgsProject.instance()
    root = p.layerTreeRoot()
    changed = {"on": [], "off": []}
    want = {}
    for ph in phases:
        for lyr in ph["content"]:
            want[lyr.id()] = True
        if ph.get("boundary") is not None:
            want[ph["boundary"].id()] = False
    excluded_names = {n for ph in phases for n in ph["excluded"]}
    for node in root.findLayers():
        lyr = node.layer()
        if lyr is None:
            continue
        target = want.get(lyr.id())
        if target is None:
            if lyr.name() in excluded_names:
                target = False
            else:
                continue                      # not ours — leave the operator's choice alone
        if bool(node.itemVisibilityChecked()) == bool(target):
            continue
        node.setItemVisibilityChecked(bool(target))
        changed["on" if target else "off"].append(lyr.name())
    # a group unticked hides its children whatever their own tick says
    for grp in root.findGroups(True):
        if _group_phase_no(grp.name()) is not None and not grp.itemVisibilityChecked():
            grp.setItemVisibilityChecked(True)
            changed["on"].append("[group] " + grp.name())
    return changed


def summarise(phases):
    """One line per phase for the dialog preview and for test assertions."""
    return [
        "Phase {n}: {c} ({p} PONs)".format(
            n=ph["phase_no"],
            c=ph["coverage"].name() if ph["coverage"] is not None else "NO COVERAGE",
            p=ph["pon_count"])
        for ph in phases
    ]
