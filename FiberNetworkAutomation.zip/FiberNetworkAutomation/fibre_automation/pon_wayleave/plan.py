"""One end-to-end PON plan: span -> groups -> whole blocks -> boundaries.

Why this module exists at all: the acceptance gate and the QGIS algorithm each
used to stitch the six stages together themselves. Two copies of a pipeline
drift, and in this repo that has already shipped a defect -- ``check_zone_fit``
was imported by the gate and never called by the plugin, so the gate was
stricter than the path the operator actually ran. The pipeline now lives here
once and both callers call :func:`plan_pons`.

Nothing here imports QGIS. The caller hands in plain geometry already in a
METRIC CRS; distances in EPSG:4326 are degrees and a 20 m gap prints as 0.0.
"""

from __future__ import annotations

from collections import defaultdict

from .balance import (BAND_HI, BAND_LO, HARD_MAX, WORKING_CAP, balance_pons,
                      build_run_graph)
from .blockplan import balance_blocks, pon_of_stands
from .blocks import street_blocks, subdivide_blocks
from .boundaries import build_block_boundaries
from .core import PonWayleaveError
from .grouping import group_pons, renumber_from_dc

__all__ = ["BalancedGrouping", "PonPlan", "SUBDIVIDE_MAX", "balanced_grouping",
           "blocks_of_stands", "plan_pons"]

#: No single block may hold more than this many homes. A block is the ATOM of
#: the plan, so a block that alone exceeds the PON cap can never be placed
#: legally -- measured on Ventersdorp one block held 276 homes against a cap of
#: 128, and four blocks together held 10.4% of the town. Half the cap leaves
#: room for the balancer to pair blocks up.
SUBDIVIDE_MAX = 60


class PonPlan:
    """Everything the callers need, and everything the gate must inspect.

    Deliberately carries the intermediate graphs: a check that can only read
    the final polygons cannot tell a connected PON from one that was repaired
    into looking connected.
    """

    __slots__ = ("pon_of_stand", "polys", "blocks", "block_of_stand",
                 "block_to_pon", "block_graph", "run_graph", "pon_of_run",
                 "grouping", "stats", "warnings")

    def __init__(self, **kw):
        for k in self.__slots__:
            setattr(self, k, kw.get(k))

    def sizes(self):
        """{pon: home count}, counting only stands that landed in a PON."""
        out = defaultdict(int)
        for p in self.pon_of_stand:
            if p is not None:
                out[p] += 1
        return dict(out)


def blocks_of_stands(blocks, stand_xy):
    """``[block index or None]`` per stand -- point-in-block, no geopandas.

    ``within`` semantics on purpose (a point exactly ON a block edge belongs to
    neither): the edge is the road centre line, and a home is not in the road.
    Candidates are sorted before testing so the answer cannot depend on the
    spatial index's internal order -- a set-iteration order once decided which
    page a book printed in this repo.
    """
    from shapely.geometry import Point

    try:
        from shapely import STRtree
        tree = STRtree(blocks)
        query = lambda pt: sorted(int(k) for k in tree.query(pt))
    except Exception:                                       # pragma: no cover
        query = lambda pt: range(len(blocks))

    out = []
    for xy in stand_xy:
        pt = Point(float(xy[0]), float(xy[1]))
        hit = None
        for k in query(pt):
            if pt.within(blocks[k]):
                hit = k
                break
        out.append(hit)
    return out




class BalancedGrouping:
    """What HT 2 needs: membership, numbering, and the evidence behind both."""

    __slots__ = ("pon_of_stand", "pon_of_run", "run_graph", "grouping",
                 "stats", "warnings", "balanced")

    def __init__(self, **kw):
        for k in self.__slots__:
            setattr(self, k, kw.get(k))

    def sizes(self):
        out = defaultdict(int)
        for p in self.pon_of_stand:
            if p is not None:
                out[int(p)] += 1
        return dict(out)


def balanced_grouping(span_lines, stand_xy, dc_xy=None, target=96,
                      max_stands=HARD_MAX, lo=BAND_LO, hi=BAND_HI,
                      balance=True, progress=None, is_cancelled=None):
    """Group along the span, then even the PON sizes out. No roads, no AOI.

    This is the measured win and the whole of it. ``group_pons`` packs to the
    cap and leaves runts behind -- on Ventersdorp a 26-home PON beside a
    116-home one -- and ``balance_pons`` is what fixes that: measured 32.5% ->
    62.2% of PONs inside the 80-102 band on Ventersdorp and 33.3% -> 81.2% on
    Malmesbury, with span containment improving on both towns at the same time.

    Two things this function exists to get right, both of which a caller doing
    the three steps by hand has already got wrong once:

    * **It renumbers afterwards.** Balancing moves runs between PONs, so PON 1
      stops being the one nearest the DC unless the numbering is redone.
    * **It honours ``max_stands``.** The grouper's own check runs before
      balancing, and the balancer defaults to its own ``HARD_MAX``; passing the
      operator's ceiling through means "never exceeded" is true of the result
      rather than of an intermediate.

    ``balance=False`` returns the grouping untouched, so a caller can offer the
    old behaviour without a second code path.
    """
    progress = progress or (lambda *_a, **_k: None)
    max_stands = int(max_stands)

    res = group_pons(span_lines, stand_xy, dc_xy=dc_xy, target=target,
                     max_stands=max_stands,
                     progress=(lambda p, m: progress(p * 0.7, m)),
                     is_cancelled=is_cancelled)
    warnings = list(res.warnings)

    if not balance:
        progress(100.0, "balancing skipped")
        return BalancedGrouping(
            pon_of_stand=[int(p) for p in res.pon_of_stand],
            pon_of_run=dict(res.pon_of_run), run_graph=None, grouping=res,
            stats=None, warnings=warnings, balanced=False)

    stands_on_run = defaultdict(list)
    for i, r in enumerate(res.snap_run):
        stands_on_run[r].append(i)
    run_graph = build_run_graph(res.graph.run_neighbours, stands_on_run,
                                set(res.pon_of_run))

    # Work below the operator's ceiling where there is room to: the headroom is
    # what lets a runt be merged into a neighbour at all.
    work_cap = min(max_stands, WORKING_CAP) if max_stands > WORKING_CAP else max_stands
    pon_of_run, _loads, stats = balance_pons(
        run_graph, stands_on_run, dict(res.pon_of_run), lo, hi, work_cap,
        progress=(lambda p, m: progress(70.0 + p * 0.25, m)),
        hard_cap=max_stands)

    pon_of_run = renumber_from_dc(res.graph, pon_of_run, dc_xy)
    progress(100.0, "PONs renumbered outward from the DC")

    pon_of_stand = [pon_of_run.get(r) for r in res.snap_run]
    missing = sum(1 for p in pon_of_stand if p is None)
    if missing:
        warnings.append(
            f"{missing:,} stand(s) reached no PON and were left unassigned.")
    return BalancedGrouping(
        pon_of_stand=pon_of_stand, pon_of_run=pon_of_run, run_graph=run_graph,
        grouping=res, stats=stats, warnings=warnings, balanced=True)


def plan_pons(span_lines, stand_xy, road_lines, aoi_polygon, dc_xy=None,
              target=96, work_cap=WORKING_CAP, lo=BAND_LO, hi=BAND_HI,
              cap=HARD_MAX, subdivide_max=SUBDIVIDE_MAX, gap_m=None,
              progress=None, is_cancelled=None):
    """Plan every PON for one AOI. Returns a :class:`PonPlan`.

    The six stages, and what each one is for:

    1. ``group_pons``    -- follow the span, so a PON is one continuous run.
    2. ``balance_pons``  -- fix the size spread without breaking that.
    3. ``street_blocks`` -- the blocks the boundaries will be drawn on.
    4. ``subdivide_blocks`` -- cut any block too big to ever place legally.
    5. ``balance_blocks``   -- assign WHOLE blocks, so an island is impossible.
    6. ``build_block_boundaries`` -- union each PON's blocks, cut the gap.

    ``road_lines`` and ``aoi_polygon`` are required: without the AOI edge
    ``polygonize`` never closes the outer blocks and the whole edge of town is
    lost, and without roads there are no blocks to draw on.
    """
    progress = progress or (lambda *_a, **_k: None)
    if aoi_polygon is None or getattr(aoi_polygon, "is_empty", True):
        raise PonWayleaveError(
            "An AOI polygon is required -- without it the outer street blocks "
            "never close and the edge of town is dropped.")
    if not road_lines:
        raise PonWayleaveError(
            "A road layer is required: PON boundaries are drawn on street "
            "blocks, and there are no blocks without roads.")

    def _stage(base, span):
        return lambda pct, msg: progress(base + span * pct / 100.0, msg)

    res = group_pons(span_lines, stand_xy, dc_xy=dc_xy, target=target,
                     max_stands=work_cap, progress=_stage(0.0, 35.0),
                     is_cancelled=is_cancelled)

    stands_on_run = defaultdict(list)
    for i, r in enumerate(res.snap_run):
        stands_on_run[r].append(i)
    run_graph = build_run_graph(res.graph.run_neighbours, stands_on_run,
                                set(res.pon_of_run))
    pon_of_run, _loads, _bstats = balance_pons(
        run_graph, stands_on_run, dict(res.pon_of_run), lo, hi, work_cap,
        progress=_stage(35.0, 20.0), hard_cap=cap)
    # balancing moved runs between PONs, so PON 1 is no longer necessarily the
    # one nearest the DC -- renumber or the OPL labelling promise is broken
    pon_of_run = renumber_from_dc(res.graph, pon_of_run, dc_xy)

    progress(55.0, "street blocks from the roads")
    blocks = street_blocks(road_lines, aoi_polygon)
    if not blocks:
        raise PonWayleaveError(
            "The roads and the AOI produced no street blocks. Check the road "
            "layer covers the AOI -- a cached roads file from another town "
            "returns nothing here.")
    block_of_stand = blocks_of_stands(blocks, stand_xy)
    blocks, block_of_stand = subdivide_blocks(blocks, stand_xy, block_of_stand,
                                              max_homes=subdivide_max)
    progress(65.0, f"{len(blocks)} street blocks")

    seed_pon = [pon_of_run.get(r) for r in res.snap_run]
    block_to_pon, _bl, stats, bgraph = balance_blocks(
        blocks, block_of_stand, seed_pon, lo=lo, hi=hi, cap=cap,
        progress=_stage(65.0, 25.0))

    pon_of_stand = pon_of_stands(block_of_stand, block_to_pon)
    kw = {} if gap_m is None else {"gap_m": gap_m}
    polys = build_block_boundaries(blocks, block_to_pon, stand_xy=stand_xy,
                                   pon_of_stand=pon_of_stand,
                                   progress=_stage(90.0, 10.0), **kw)
    return PonPlan(pon_of_stand=pon_of_stand, polys=polys, blocks=blocks,
                   block_of_stand=block_of_stand, block_to_pon=block_to_pon,
                   block_graph=bgraph, run_graph=run_graph,
                   pon_of_run=pon_of_run, grouping=res, stats=stats,
                   warnings=list(res.warnings))
