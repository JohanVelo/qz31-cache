try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

"""zone_tag — tag features with the PON / Phase (or any polygon) they fall inside.

Answers "which PON does this cable run through?" as a real, filterable attribute
column instead of a manual click-around on the canvas.

Design rules (match ``historical quantity take-off implementation``):
  * SCHEMA-AGNOSTIC — the caller names the polygon layer + the field that supplies
    the value, so this works for Fibertime ``PON v1``.pon_no, HeroTel ``Pons``.PON,
    ``Phases``."Phase Num" or any other client's areas.
  * TWO PHASES — ``build_plan`` only READS (it is safe to run on client data and
    is what the dialog previews); ``apply_plan`` is the ONLY writer.
  * HONEST — a feature outside every polygon gets NULL and is counted as
    "outside". It is never snapped to the nearest polygon.
  * NO Qt AT MODULE LEVEL — pure + unit-testable; qgis imports are function-local.

Geometry rules (JJ's call, 2026-07-15):
  * point / polygon target → containment of its point-on-surface → ONE value.
    An erf or a pole belongs to exactly one PON.
  * line target → EVERY polygon it genuinely runs through, joined ", ".
    A 1976 m feeder really does serve several PONs; collapsing that to one lies.
    "Genuinely" = at least ``_MIN_SHARED_M`` metres of the line lies inside —
    without that guard a cable collects a phantom PON from every polygon corner
    it grazes, and the column stops being trustworthy.
"""

# Minimum length (m) a line must run INSIDE a polygon before that polygon is
# listed. Guards against corner-clips. See module docstring.
_MIN_SHARED_M = 1.0

# ESRI Shapefile truncates field names to 10 chars; we surface the truncated name
# to the user rather than let the .dbf surprise them later.
_SHP_FIELD_MAX = 10
_SHP_MAX_TEXT = 254      # longest text a .dbf field stores

# Value used in the plan for "inside no polygon at all".
OUTSIDE = None

_STRING_TYPE_NAMES = ("string", "text", "varchar", "qstring", "character")


# ── small helpers ────────────────────────────────────────────────────────────
def _rep_point(geom):
    """A representative point for a geometry (point/line/polygon), or None.

    Same convention as ``takeoff._rep_point``: pointOnSurface is guaranteed to
    fall INSIDE a concave polygon, where centroid is not.
    """
    if geom is None or geom.isEmpty():
        return None
    try:
        pt = geom.pointOnSurface()
        if pt is None or pt.isEmpty():
            pt = geom.centroid()
        return None if (pt is None or pt.isEmpty()) else pt
    except Exception:
        return None


def _norm_value(v):
    """Attribute → display string, or None for NULL/blank."""
    if v is None:
        return None
    try:
        from qgis.PyQt.QtCore import QVariant
        if isinstance(v, QVariant) and v.isNull():
            return None
    except Exception:
        _swallowed_note()
    s = str(v).strip()
    if not s or s.lower() == "null":
        return None
    return s


def _natural_key(s):
    """Sort key so P003 < P004 < P013 (not P003 < P013 < P004)."""
    import re
    out = []
    for part in re.split(r"(\d+)", str(s)):
        if part.isdigit():
            out.append((1, int(part), ""))
        elif part:
            out.append((0, 0, part.lower()))
    return out


def sanitize_field_name(name, shapefile=False):
    """A safe attribute name: alnum + underscore, never leading-digit, ≤10 for .shp."""
    import re
    s = re.sub(r"[^0-9A-Za-z_]+", "_", str(name or "").strip()).strip("_")
    if not s:
        s = "zone"
    if s[0].isdigit():
        s = "f_" + s
    if shapefile:
        s = s[:_SHP_FIELD_MAX]
    return s


def is_shapefile(layer):
    try:
        return "shapefile" in (layer.dataProvider().storageType() or "").lower()
    except Exception:
        return False


def _field_lookup(layer, name):
    """Real field name matching ``name`` case-insensitively, else None."""
    want = str(name).lower()
    for f in layer.fields():
        if f.name().lower() == want:
            return f.name()
    return None


def _is_string_field(field):
    try:
        return any(t in (field.typeName() or "").lower() for t in _STRING_TYPE_NAMES)
    except Exception:
        return False


def _crs_key(crs):
    """A key that is unique per CRS.

    NOT authid() alone: a CUSTOM CRS reports authid() == '', so two different
    custom-CRS polygon layers would collide on '' and the second would silently
    reuse the first's transform — putting features in the wrong zone with no
    error. Fall back to the WKT, which is always distinct.
    """
    try:
        return crs.authid() or crs.toWkt()
    except Exception:
        return repr(crs)


def _measurer(crs, project):
    """QgsDistanceArea that really measures METRES — never degrees.

    The trap (found 2026-07-15, and it silently NULLs every cable):
    ``project.ellipsoid()`` returns the STRING ``'NONE'`` for a project with no
    ellipsoid set — which is QGIS's default for a brand-new project. ``'NONE'``
    is truthy, so the old ``project.ellipsoid() or "WGS84"`` did NOT fall back;
    it set the ellipsoid to "NONE", and a geographic CRS then measures in
    DEGREES. A 1976 m cable measures 0.019, falls under the 1 m corner-clip
    guard, and every line silently comes back NULL with no error at all.

    So: treat 'NONE'/'' as "unset" and force a real ellipsoid, then VERIFY with
    willUseEllipsoid() rather than trust setEllipsoid()'s return (it happily
    returns True for 'NONE').
    """
    try:
        from ..shared.crs_utils import metre_measurer
    except ImportError:                       # pragma: no cover - flat import
        from fibre_automation.shared.crs_utils import metre_measurer
    return metre_measurer(crs, project)


def measures_metres(da):
    """True if this QgsDistanceArea returns metres. Used to fail loudly, not silently."""
    try:
        from ..shared.crs_utils import measures_metres as _mm
    except ImportError:                       # pragma: no cover
        from fibre_automation.shared.crs_utils import measures_metres as _mm
    return _mm(da)


def _shared_length_m(poly_geom, line_geom, da):
    """Metres of ``line_geom`` lying inside ``poly_geom``. 0.0 on any failure."""
    import math
    try:
        inter = poly_geom.intersection(line_geom)
        if inter is None or inter.isEmpty():
            return 0.0
        v = da.measureLength(inter)
        return v if (v is not None and math.isfinite(v) and v >= 0) else 0.0
    except Exception:
        return 0.0


# ── polygon index ────────────────────────────────────────────────────────────
class _PolyIndex:
    """Spatial index + prepared engines over one polygon layer.

    Prepared geometry engines matter: ``drops`` is 3618 features and this runs on
    the Qt main thread — an unprepared contains() per candidate would stall QGIS
    (that bug class has frozen us twice before).
    """

    def __init__(self, layer, value_field, project):
        from qgis.core import QgsSpatialIndex, QgsFeature
        self.name = layer.name()
        self.field = value_field
        self.crs = layer.crs()
        self.project = project
        self._geoms = {}
        self._vals = {}
        self._engines = {}
        self._da = _measurer(self.crs, project)
        # If this cannot measure metres, the >=1 m corner-clip guard is comparing
        # against degrees and would drop EVERY line to NULL. Say so instead.
        self.metres_ok = measures_metres(self._da)
        real = _field_lookup(layer, value_field)
        feats = []
        for f in layer.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            fid = f.id()
            self._geoms[fid] = g
            self._vals[fid] = _norm_value(f[real]) if real else None
            nf = QgsFeature(fid)
            nf.setGeometry(g)
            feats.append(nf)
        self.index = QgsSpatialIndex()
        for nf in feats:
            self.index.addFeature(nf)

    def __len__(self):
        return len(self._geoms)

    def _engine(self, fid):
        eng = self._engines.get(fid)
        if eng is None:
            from qgis.core import QgsGeometry
            eng = QgsGeometry.createGeometryEngine(self._geoms[fid].constGet())
            eng.prepareGeometry()
            self._engines[fid] = eng
        return eng

    def value_at_point(self, point_geom):
        """Value of the polygon containing ``point_geom`` (already in self.crs)."""
        if point_geom is None or point_geom.isEmpty():
            return None
        for fid in self.index.intersects(point_geom.boundingBox()):
            if self._engine(fid).contains(point_geom.constGet()):
                return self._vals.get(fid)
        return None

    def values_along_line(self, line_geom):
        """Sorted values of every polygon the line runs ≥ _MIN_SHARED_M inside."""
        if line_geom is None or line_geom.isEmpty():
            return []
        found = set()
        for fid in self.index.intersects(line_geom.boundingBox()):
            val = self._vals.get(fid)
            if val is None or val in found:
                continue
            if not self._engine(fid).intersects(line_geom.constGet()):
                continue
            if _shared_length_m(self._geoms[fid], line_geom, self._da) >= _MIN_SHARED_M:
                found.add(val)
        return sorted(found, key=_natural_key)


# ── plan containers ──────────────────────────────────────────────────────────
class TagSpec:
    """One "tag WITH this polygon layer" instruction."""

    def __init__(self, poly_layer_id, value_field, out_field):
        self.poly_layer_id = poly_layer_id
        self.value_field = value_field
        self.out_field = out_field
        self.poly_name = ""      # filled by build_plan (display only)

    def __repr__(self):   # pragma: no cover - debug aid
        return f"TagSpec({self.poly_name or self.poly_layer_id}.{self.value_field} → {self.out_field})"


class TagPlan:
    """What WOULD be written. Produced by build_plan; consumed by apply_plan."""

    SAMPLE_CAP = 200      # on-screen preview rows per layer; the plan holds all

    def __init__(self):
        self.specs = []
        self.rows = {}          # layer_id -> {fid: {out_field: value|None}}
        self.stats = {}         # layer_id -> {out_field: {total, tagged, outside}}
        self.layer_names = {}   # layer_id -> name
        self.out_fields = {}    # layer_id -> [out_field, ...] (ordered)
        self.samples = {}       # layer_id -> [{"label":…, out_field: val, …}]
        self.warnings = []
        self.errors = []
        self.elapsed_s = 0.0

    @property
    def total_features(self):
        return sum(len(r) for r in self.rows.values())

    def summary_lines(self):
        """Human "layer · n features · x tagged · y outside" lines."""
        out = []
        for lid, name in self.layer_names.items():
            per = self.stats.get(lid, {})
            for fld, st in per.items():
                bit = f"{name} · {st['total']} features · {st['tagged']} tagged"
                if st["outside"]:
                    bit += f" · {st['outside']} outside every polygon"
                out.append(f"{bit}  →  `{fld}`")
        return out


class ApplyResult:
    def __init__(self):
        self.written = {}      # layer_id -> features changed
        self.fields_added = [] # "layer.field" strings
        self.skipped = []      # honest per-layer reasons
        self.errors = []
        self.layer_names = {}
        self.backups = []      # file backups taken this run

    @property
    def ok(self):
        return not self.errors

    @property
    def total_written(self):
        return sum(self.written.values())


# ── label guessing (for the preview table only) ──────────────────────────────
_LABEL_FIELDS = ("name", "name.", "label", "label.", "id", "fid",
                 "descriptio", "description")


def _label_field(layer):
    lut = {f.name().lower(): f.name() for f in layer.fields()}
    for c in _LABEL_FIELDS:
        if c in lut:
            return lut[c]
    flds = layer.fields()
    return flds[0].name() if len(flds) else None


# ── build (READ-ONLY) ────────────────────────────────────────────────────────
def build_plan(project, specs, target_layer_ids, merged=False, on_conflict="new"):
    """Compute what every selected feature would be tagged with. Writes NOTHING.

    ``specs``            — list of TagSpec (which polygon layers supply values)
    ``target_layer_ids`` — layer ids that get the new column(s)
    ``merged``           — the dialog's path: specs sharing a column name merge into
                           one column. Off by default so renumber's call never moves.
    ``on_conflict``      — merged path only: "new", "fill" or "overwrite".
    """
    if merged:
        return _build_merged(project, specs, target_layer_ids, on_conflict)
    import time
    from qgis.core import (QgsCoordinateTransform, QgsGeometry, QgsProject,
                           QgsWkbTypes)
    t0 = time.time()
    project = project or QgsProject.instance()
    plan = TagPlan()

    # ── resolve + index the polygon layers once ──
    indexes = []      # (spec, _PolyIndex)
    for spec in specs:
        lyr = project.mapLayer(spec.poly_layer_id)
        if lyr is None or not lyr.isValid():
            plan.errors.append(f"Polygon layer for '{spec.out_field}' is missing.")
            continue
        spec.poly_name = lyr.name()
        if QgsWkbTypes.geometryType(lyr.wkbType()) != QgsWkbTypes.PolygonGeometry:
            plan.errors.append(f"'{lyr.name()}' is not a polygon layer — skipped.")
            continue
        if _field_lookup(lyr, spec.value_field) is None:
            plan.errors.append(f"'{lyr.name()}' has no field '{spec.value_field}'.")
            continue
        idx = _PolyIndex(lyr, spec.value_field, project)
        if not len(idx):
            plan.warnings.append(f"'{lyr.name()}' has no usable geometry — "
                                 f"every feature will be blank for '{spec.out_field}'.")
        if not getattr(idx, "metres_ok", True):
            plan.errors.append(
                f"'{lyr.name()}': this project has no ellipsoid set, so lengths "
                f"cannot be measured in metres and every CABLE would come back "
                f"blank. Set one in Project ▸ Properties ▸ General ▸ Measurements "
                f"(WGS 84 is fine). Points are unaffected.")
        plan.specs.append(spec)
        indexes.append((spec, idx))

    if not indexes:
        plan.errors.append("Nothing to tag with — select at least one polygon layer.")
        return plan

    # ── walk each target layer ──
    for lid in target_layer_ids:
        lyr = project.mapLayer(lid)
        if lyr is None or not lyr.isValid():
            plan.errors.append("A selected layer is missing from the project.")
            continue
        if any(lid == s.poly_layer_id for s, _ in indexes):
            plan.warnings.append(f"'{lyr.name()}' is one of the polygon layers — "
                                 f"not tagging it with itself.")
            continue

        plan.layer_names[lid] = lyr.name()
        shp = is_shapefile(lyr)
        gtype = QgsWkbTypes.geometryType(lyr.wkbType())
        is_line = gtype == QgsWkbTypes.LineGeometry
        src_crs = lyr.crs()

        # per-spec: resolved output field name + existing-field checks
        fields_here = []
        for spec, _idx in indexes:
            fld = sanitize_field_name(spec.out_field, shapefile=shp)
            if fld != spec.out_field:
                plan.warnings.append(
                    f"'{lyr.name()}': field name '{spec.out_field}' → '{fld}' "
                    f"({'shapefiles cap names at 10 characters' if shp else 'illegal characters removed'}).")
            existing = _field_lookup(lyr, fld)
            if existing is not None:
                efield = lyr.fields()[lyr.fields().indexFromName(existing)]
                if not _is_string_field(efield):
                    plan.errors.append(
                        f"'{lyr.name()}' already has a field '{existing}' of type "
                        f"{efield.typeName()} — refusing to overwrite it. "
                        f"Choose a different name.")
                    continue
                plan.warnings.append(
                    f"'{lyr.name()}': '{existing}' already exists — Apply overwrites it.")
                fld = existing
            fields_here.append((spec, _idx, fld))

        if not fields_here:
            continue

        plan.out_fields[lid] = [f for _s, _i, f in fields_here]
        rows = {}
        stats = {f: {"total": 0, "tagged": 0, "outside": 0}
                 for _s, _i, f in fields_here}

        # one cached transform per (target, polygon) CRS pair
        xforms = {}
        for _s, idx, _f in fields_here:
            key = _crs_key(idx.crs)
            if key not in xforms:
                xforms[key] = (None if src_crs == idx.crs
                               else QgsCoordinateTransform(src_crs, idx.crs, project))

        label_fld = _label_field(lyr)
        samples = []
        for feat in lyr.getFeatures():
            geom = feat.geometry()
            row = {}
            for _spec, idx, fld in fields_here:
                xf = xforms[_crs_key(idx.crs)]
                val = None
                if geom is not None and not geom.isEmpty():
                    g = geom
                    if xf is not None:
                        try:
                            g = QgsGeometry(geom)
                            g.transform(xf)
                        except Exception:
                            g = None
                    if g is not None:
                        if is_line:
                            vals = idx.values_along_line(g)
                            val = ", ".join(vals) if vals else None
                        else:
                            val = idx.value_at_point(_rep_point(g))
                row[fld] = val
                stats[fld]["total"] += 1
                if val is None:
                    stats[fld]["outside"] += 1
                else:
                    stats[fld]["tagged"] += 1
            rows[feat.id()] = row
            if len(samples) < TagPlan.SAMPLE_CAP:
                s = {"label": _norm_value(feat[label_fld]) if label_fld else str(feat.id())}
                s.update(row)
                samples.append(s)

        plan.rows[lid] = rows
        plan.stats[lid] = stats
        plan.samples[lid] = samples

    if not plan.rows and not plan.errors:
        plan.errors.append("Nothing to tag — select at least one target layer.")
    plan.elapsed_s = time.time() - t0
    return plan


# ── apply (THE ONLY WRITER) ──────────────────────────────────────────────────
# claude:intent MUTATE fibre_automation/tagging/zone_tag.py apply_plan
#   Adds ONE new text attribute per (layer, spec) and fills it from the plan the
#   user just previewed. Purely ADDITIVE: no existing field's value is touched
#   and no geometry changes, so the undo is deleteAttributes(idx).
#   Gated behind an explicit "Apply" click on the preview. approved-destructive
def apply_plan(project, plan, backup=False):
    """Write ``plan`` to the layers. Additive only; reversible by deleting the field.

    A merged plan goes through ``_apply_merged``, which also honours ``backup``.
    """
    if getattr(plan, "merged", False):
        return _apply_merged(project, plan, backup)
    from qgis.core import QgsField, QgsProject, QgsVectorDataProvider
    from qgis.PyQt.QtCore import QMetaType

    project = project or QgsProject.instance()
    res = ApplyResult()
    res.layer_names = dict(plan.layer_names)

    for lid, rows in plan.rows.items():
        name = plan.layer_names.get(lid, lid)
        lyr = project.mapLayer(lid)
        if lyr is None or not lyr.isValid():
            res.errors.append(f"'{name}' is no longer in the project — skipped.")
            continue
        dp = lyr.dataProvider()
        caps = dp.capabilities()
        if not (caps & QgsVectorDataProvider.Capability.AddAttributes):
            res.skipped.append(f"'{name}' is read-only (cannot add a field).")
            continue
        if not (caps & QgsVectorDataProvider.Capability.ChangeAttributeValues):
            res.skipped.append(f"'{name}' does not allow attribute edits.")
            continue

        # ── ensure every output field exists (add the missing ones in ONE call) ──
        wanted = plan.out_fields.get(lid, [])
        to_add = [f for f in wanted if _field_lookup(lyr, f) is None]
        if to_add:
            new = [QgsField(f, QMetaType.Type.QString, len=254) for f in to_add]
            if not dp.addAttributes(new):
                res.errors.append(f"'{name}': could not add "
                                  f"{', '.join(to_add)} — layer left unchanged.")
                continue
            lyr.updateFields()
            for f in to_add:
                res.fields_added.append(f"{name}.{f}")

        # resolve real (possibly provider-truncated) names → provider indices
        idx_of = {}
        missing = []
        for f in wanted:
            real = _field_lookup(lyr, f)
            i = dp.fields().indexOf(real) if real else -1
            if i < 0:
                missing.append(f)
            else:
                idx_of[f] = i
        if missing:
            res.errors.append(f"'{name}': field(s) {', '.join(missing)} did not "
                              f"materialise on the provider — layer left unchanged.")
            continue

        # ── ONE bulk provider write per layer (never per-feature in a loop) ──
        attr_map = {}
        for fid, row in rows.items():
            attr_map[fid] = {idx_of[f]: v for f, v in row.items() if f in idx_of}
        if not attr_map:
            continue
        if dp.changeAttributeValues(attr_map):
            res.written[lid] = len(attr_map)
        else:
            res.errors.append(f"'{name}': the provider rejected the attribute write.")

        try:
            lyr.updateFields()
            lyr.triggerRepaint()
        except Exception:
            _swallowed_note()

    return res


# ── dialog conveniences (kept here so the UI stays thin) ─────────────────────
_VALUE_FIELD_HINTS = ("pon", "pon_no", "phase num", "phase", "zone", "zone_id",
                      "zone_no", "group_id", "label", "name")

# Which polygon layers arrive PRE-TICKED. An AOI is one polygon covering everything,
# so tagging with it yields a column where every row says the same thing. It stays
# listed (JJ can tick it) but defaulting it on would just add noise to every table.
_PRETICK_ROLES = ("pon", "phase", "zone")

# Technical ids are never what a planner means by "which area".
_TECH_FIELDS = ("fid", "ogc_fid", "objectid", "gid", "id", "uuid", "globalid",
                "featureid", "feature_id")
_ROLE_FIELDS = {
    "pon": ("pon", "pon_no", "pon_id", "ponid", "pon_name", "pon_number", "pons"),
    "phase": ("phase", "phase num", "phase_num", "phase_no", "phaseno", "phase_name"),
    "zone": ("zone", "zone_id", "zone_no", "zone_name", "group_id"),
    "aoi": (),
}
_IDENTITY_FIELDS = ("name", "label", "title", "block", "area")
# Never default a NEW column to one of these: it is what target layers already use.
_RESERVED_OUT_NAMES = ("name", "id", "fid", "label", "descriptio", "description")
_GUESS_SCAN = 200       # features read when looking at field values


def _role_word(role):
    return r"(?:^|[^a-z])" + role + r"s?(?:[^a-z]|$)"


def _layer_role(name):
    """'pon', 'phase', 'zone', 'aoi' or None, as whole words: 'Ponds' is not a PON."""
    import re
    low = str(name or "").lower()
    for role in ("pon", "phase", "zone", "aoi"):
        if re.search(_role_word(role), low):
            return role
    return None


def _names_each_polygon(layer, field):
    """True when values are filled and at least 90% unique across the layer's polygons."""
    values = [_norm_value(f[field]) for f in layer.getFeatures()]
    named = [v for v in values if v]
    return bool(named) and len(named) * 10 >= len(values) * 9 and len(set(named)) * 10 >= len(named) * 9


def polygon_layers(project=None):
    """[(layer, pre_tick)] — every polygon layer, the PON/Phase/Zone ones first."""
    from qgis.core import QgsProject, QgsVectorLayer, QgsWkbTypes
    project = project or QgsProject.instance()
    out = []
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
            continue
        try:
            if QgsWkbTypes.geometryType(lyr.wkbType()) != QgsWkbTypes.PolygonGeometry:
                continue
        except Exception:
            _swallowed_note(); continue
        # an empty polygon layer, or one with no identity field, can't tag anything
        role = _layer_role(lyr.name())
        guess = guess_value_field(lyr) if role in _PRETICK_ROLES and lyr.featureCount() else ""
        pre = bool(guess)
        # A real PON layer names each polygon once. A layer that repeats values only
        # describes PONs, like 'PON Progress' after this tool has tagged it.
        if pre and role == "pon" and not _names_each_polygon(lyr, guess):
            pre = False
        out.append((lyr, pre))
    out.sort(key=lambda t: (not t[1], t[0].name().lower()))
    return out


def target_layers(project=None):
    """Every valid vector layer — the candidates for "add the field to"."""
    from qgis.core import QgsProject, QgsVectorLayer
    project = project or QgsProject.instance()
    out = [l for l in project.mapLayers().values()
           if isinstance(l, QgsVectorLayer) and l.isValid()]
    out.sort(key=lambda l: l.name().lower())
    return out


def guess_value_field(layer):
    """The field that names each polygon, or "" for a PON/Phase layer without one.

    Ordered rules, first hit wins. The layer's own name sets the role:
      1. a field named for that role (PONS.PON_ID, Phases."Phase Num")
      2. a field whose name holds the role word and no other role's word
      3. a text field whose VALUES hold the role word; most rows, then most distinct
         (PONS PH1.Name = 'Botshabelo W U V S PON 001')
      4. a general identity field that has a value (Name, Label, ...)
      5. no role at all: the old hint list, then the first non-technical field
    Technical ids are never picked, so a PON layer can't feed fid into a pon column.
    """
    import re
    role = _layer_role(layer.name())
    cand = [f.name() for f in layer.fields() if f.name().lower() not in _TECH_FIELDS]
    lut = {n.lower(): n for n in cand}
    others = [r for r in _ROLE_FIELDS if r != role]

    def has_word(text, word):
        return re.search(_role_word(word), str(text).lower()) is not None

    if role:
        for c in _ROLE_FIELDS[role]:
            if c in lut:
                return lut[c]
        for n in cand:
            if has_word(n, role) and not any(has_word(n, o) for o in others):
                return n
        best, best_score = "", (0, 0)
        for fld in layer.fields():
            n = fld.name()
            if n not in cand or not _is_string_field(fld):
                continue
            seen, hits = set(), 0
            for i, feat in enumerate(layer.getFeatures()):
                if i >= _GUESS_SCAN:
                    break
                val = _norm_value(feat[n])
                if val and has_word(val, role):
                    hits += 1
                    seen.add(val)
            if (hits, len(seen)) > best_score:
                best, best_score = n, (hits, len(seen))
        if best:
            return best
    else:
        for c in _VALUE_FIELD_HINTS:
            if c in lut:
                return lut[c]
    for c in _IDENTITY_FIELDS:
        real = lut.get(c)
        if real and any(_norm_value(f[real]) for i, f in zip(range(_GUESS_SCAN), layer.getFeatures())):
            return real
    if role in _PRETICK_ROLES:
        return ""
    return cand[0] if cand else ""


def guess_out_field(layer, value_field, shapefile=False):
    """Default column name: short, obvious, shapefile-safe, and never one that target
    layers already use for their own identity ('Blocks'.name must not become 'name')."""
    role = _layer_role(layer.name())
    if role:
        return sanitize_field_name(role, shapefile)
    out = sanitize_field_name((layer.name() or value_field).lower(), shapefile)
    return "zone" if out.lower() in _RESERVED_OUT_NAMES else out


# ══ merged path (what the dialog uses) ═══════════════════════════════════════
# Several ticked polygon layers can feed one column, which is how a project split into
# Phase 1-9 and PONS PH1-9 reads. Decisions (JJ, GO on plan e4e8f0bb, 2026-11-05):
#   D1 a point on a border takes the first value in natural order, and is counted.
#   D2 a populated column is never changed unless "overwrite" or "fill" is picked;
#      otherwise the next free name is used. Overwrite first copies old values.
#   D3 a point inside two areas takes the first in natural order, and is counted.
#   D4 same column name means one merged column.
class MergedPlan(TagPlan):
    merged = True

    def __init__(self):
        super().__init__()
        self.col_info = {}    # layer_id -> {column: {action, existing, old, kept_type...}}
        self.sources = {}     # column name asked for -> [ "Layer.field", ... ]
        self.value_counts = {}  # layer_id -> {column: {value: n}}
        self.source_prints = {}  # polygon layer_id -> geometry checksum at Preview
        self.target_prints = {}  # target layer_id -> geometry checksum at Preview

    def summary_lines(self):
        out = []
        for lid, name in self.layer_names.items():
            for col, st in self.stats.get(lid, {}).items():
                action = self.col_info.get(lid, {}).get(col, {}).get("action", "new")
                bit = f"{name} · {st['total']} features · {st['tagged']} tagged"
                if st["outside"]:
                    bit += f" · {st['outside']} outside"
                if st.get("blank_value"):
                    bit += f" · {st['blank_value']} in a blank-value polygon"
                label = {"new": "new column", "reuse": "empty column reused",
                         "fill": "fill blanks", "overwrite": "overwrite",
                         "same": "no change"}.get(action, action)
                out.append(f"{bit}  →  `{col}` ({label})")
        return out


class _ZoneIndex:
    """One polygon layer's areas. Repairs invalid polygons in memory only."""

    def __init__(self, layer, value_field, project):
        from qgis.core import QgsFeature, QgsSpatialIndex
        self.name = layer.name()
        self.crs = layer.crs()
        self.repaired = 0
        self._da = _measurer(self.crs, project)
        self.metres_ok = measures_metres(self._da)
        self._geoms, self._vals, self._engines = {}, {}, {}
        self.index = QgsSpatialIndex()
        real = _field_lookup(layer, value_field)
        for f in layer.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            if not g.isGeosValid():
                fixed = g.makeValid()
                if fixed is not None and not fixed.isEmpty():
                    g = fixed
                    self.repaired += 1
            fid = f.id()
            self._geoms[fid] = g
            self._vals[fid] = _tag_value(f[real]) if real else None
            nf = QgsFeature(fid)
            nf.setGeometry(g)
            self.index.addFeature(nf)

    def _engine(self, fid):
        eng = self._engines.get(fid)
        if eng is None:
            from qgis.core import QgsGeometry
            eng = QgsGeometry.createGeometryEngine(self._geoms[fid].constGet())
            eng.prepareGeometry()
            self._engines[fid] = eng
        return eng

    def at_point(self, pt):
        """(values strictly inside, values on the border, touched a blank polygon)."""
        inside, border, blank = set(), set(), False
        for fid in self.index.intersects(pt.boundingBox()):
            eng = self._engine(fid)
            if not eng.intersects(pt.constGet()):
                continue
            val = self._vals.get(fid)
            if val is None:
                blank = True
            elif eng.contains(pt.constGet()):
                inside.add(val)
            else:
                border.add(val)
        return inside, border, blank

    def along_line(self, line):
        """(values the line runs at least _MIN_SHARED_M inside, touched a blank polygon)."""
        found, blank = set(), False
        for fid in self.index.intersects(line.boundingBox()):
            if not self._engine(fid).intersects(line.constGet()):
                continue
            if _shared_length_m(self._geoms[fid], line, self._da) < _MIN_SHARED_M:
                continue
            val = self._vals.get(fid)
            if val is None:
                blank = True
            else:
                found.add(val)
        return found, blank

    def across_area(self, poly):
        """Values a target polygon shares at least 1 m2 with."""
        found = set()
        for fid in self.index.intersects(poly.boundingBox()):
            val = self._vals.get(fid)
            if val is None or val in found:
                continue
            try:
                eng = self._engine(fid)
                if not eng.intersects(poly.constGet()):
                    continue
                if eng.contains(poly.constGet()):
                    found.add(val)
                    continue
                inter = self._geoms[fid].intersection(poly)
                if inter is not None and not inter.isEmpty() and self._da.measureArea(inter) >= 1.0:
                    found.add(val)
            except Exception:
                _swallowed_note()
        return found


def _tag_value(v):
    """Attribute to column text. A whole-number double reads 1, not 1.0."""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return _norm_value(v)


def _natural_first(values):
    return sorted(values, key=_natural_key)[0] if values else None


def _join_values(values, limit):
    """Natural-order list. Past ``limit`` it stops at a whole name, then ' +N more'."""
    ordered = sorted(values, key=_natural_key)
    text = ", ".join(ordered)
    if not limit or len(text) <= limit:
        return text, False
    for keep in range(len(ordered) - 1, 0, -1):
        cut = ", ".join(ordered[:keep]) + f" +{len(ordered) - keep} more"
        if len(cut) <= limit:
            return cut, True
    return f"{ordered[0][:max(0, limit - 10)]} +{len(ordered) - 1} more", True


def _next_free_name(base, lyr, shapefile, suffix="_2", reserved=()):
    """A name no field on this layer uses and no other column in this run has taken,
    compared as the provider will store it."""
    taken = {f.name().lower() for f in lyr.fields()} | {r.lower() for r in reserved}

    def stored(name):
        return (name[:_SHP_FIELD_MAX] if shapefile else name).lower()

    def fit(stem, tail):
        return stem[:_SHP_FIELD_MAX - len(tail)] + tail if shapefile else stem + tail

    if suffix == "_old":
        cand = fit(base, "_old")
        n = 2
        while stored(cand) in taken:
            cand = fit(base, f"_old{n}")
            n += 1
        return cand
    n = 2
    cand = fit(base, f"_{n}")
    while stored(cand) in taken:
        n += 1
        cand = fit(base, f"_{n}")
    return cand


def _is_blank(v):
    return _norm_value(v) is None


def _layer_file(lyr):
    """The file behind an OGR layer, or None for memory and database layers."""
    import os
    try:
        if lyr.providerType() != "ogr":
            return None
        path = lyr.source().split("|")[0]
        return path if os.path.isfile(path) else None
    except Exception:
        return None


def _short_pon_name(value, bare_ok=False):
    """'Botshabelo W U V S PON 094' -> 'PON 94'. None when it does not end in a PON number.

    bare_ok: a column named for PONs may hold plain numbers, as Deneysville does ('02' -> 'PON 2').
    """
    import re
    text = str(value).strip()
    if bare_ok:
        bare = re.fullmatch(r"0*(\d+)(?:\.0+)?", text)
        if bare:
            return f"PON {bare.group(1)}"
    m = re.fullmatch(r"(?:.*[^A-Za-z])?PON\s*[-_.]?\s*0*(\d+)\s*", text, re.IGNORECASE)
    return f"PON {m.group(1)}" if m else None


def _is_pon_column(name):
    return str(name).lower().startswith("pon")


def _same_pon(current, value):
    """'78' or 'Town PON 078' in a column already says what 'PON 78' says, cable lists too."""
    import re
    if _is_blank(current) or not value:
        return False
    # Only a shortened value. 'Area B PON 1' is kept long because another area also has a PON 1.
    if not all(re.fullmatch(r"PON \d+", p.strip()) for p in str(value).split(",")):
        return False
    have = [_short_pon_name(p, bare_ok=True) for p in str(current).split(",")]
    want = [_short_pon_name(p, bare_ok=True) for p in str(value).split(",")]
    return all(have) and have == want


def _shorten_pon_names(plan, sources):
    """A column reads 'PON 94', not the town and block in front (JJ, 2026-11-05).

    All or nothing per column: every value must end in a PON number, and no two different
    names may shorten to the same one, or two PONs would silently become one.
    """
    columns = {}
    for spec, idx in sources:
        columns.setdefault(sanitize_field_name(spec.out_field).lower(), []).append(idx)
    for col, indexes in columns.items():
        names = {v for idx in indexes for v in idx._vals.values() if v}
        if not names:
            continue
        short = {v: _short_pon_name(v, bare_ok=_is_pon_column(col)) for v in names}
        if not all(short.values()):
            continue
        if len(set(short.values())) < len(names):
            plan.warnings.append(f"'{col}': full PON names kept, because shortening them would "
                                 f"make two different PONs read the same.")
            continue
        for idx in indexes:
            idx._vals = {fid: short.get(v) if v else v for fid, v in idx._vals.items()}


def _build_merged(project, specs, target_layer_ids, on_conflict):
    """Read-only. One column per name per layer, merged across its polygon layers."""
    import time
    from qgis.core import QgsCoordinateTransform, QgsGeometry, QgsProject, QgsWkbTypes
    t0 = time.time()
    project = project or QgsProject.instance()
    plan = MergedPlan()

    sources = []        # (spec, _ZoneIndex)
    for spec in specs:
        lyr = project.mapLayer(spec.poly_layer_id)
        if lyr is None or not lyr.isValid():
            plan.errors.append(f"Polygon layer for '{spec.out_field}' is missing.")
            continue
        spec.poly_name = lyr.name()
        if QgsWkbTypes.geometryType(lyr.wkbType()) != QgsWkbTypes.PolygonGeometry:
            plan.errors.append(f"'{lyr.name()}' is not a polygon layer, so it was skipped.")
            continue
        if _field_lookup(lyr, spec.value_field) is None:
            plan.errors.append(f"'{lyr.name()}' has no field '{spec.value_field}'.")
            continue
        idx = _ZoneIndex(lyr, spec.value_field, project)
        plan.source_prints[lyr.id()] = _geom_print(lyr, attrs=True)
        if not idx.metres_ok:
            plan.errors.append(
                f"'{lyr.name()}': this project has no ellipsoid set, so lengths cannot be "
                f"measured in metres and every cable would come back blank. Set one in "
                f"Project > Properties > General > Measurements (WGS 84 is fine).")
        if idx.repaired:
            plan.warnings.append(f"'{lyr.name()}': {idx.repaired} invalid polygon(s) repaired "
                                 f"in memory for this calculation. Check them; the layer is not changed.")
        plan.specs.append(spec)
        plan.sources.setdefault(sanitize_field_name(spec.out_field).lower(), []).append(
            f"{lyr.name()}.{spec.value_field}")
        sources.append((spec, idx))
    if not sources:
        plan.errors.append("Nothing to tag with. Select at least one polygon layer.")
        return plan
    _shorten_pon_names(plan, sources)

    for lid in target_layer_ids:
        _plan_one_layer(plan, project, lid, sources, on_conflict,
                        QgsCoordinateTransform, QgsGeometry, QgsWkbTypes)

    if not plan.rows and not plan.errors and not plan.warnings:
        plan.errors.append("Nothing to tag. Select at least one target layer.")
    plan.elapsed_s = time.time() - t0
    return plan


def _plan_one_layer(plan, project, lid, sources, on_conflict,
                    QgsCoordinateTransform, QgsGeometry, QgsWkbTypes):
    lyr = project.mapLayer(lid)
    if lyr is None or not lyr.isValid():
        plan.errors.append("A selected layer is missing from the project.")
        return
    name = lyr.name()
    if lyr.isEditable():
        plan.errors.append(f"'{name}' is being edited. Save or discard those edits first, "
                           f"then run this again. It was left out.")
        return
    gtype = QgsWkbTypes.geometryType(lyr.wkbType())
    if gtype not in (QgsWkbTypes.PointGeometry, QgsWkbTypes.LineGeometry, QgsWkbTypes.PolygonGeometry):
        plan.warnings.append(f"'{name}' has no geometry, so it was left out.")
        return
    shp = is_shapefile(lyr)
    limit = _SHP_MAX_TEXT if shp else 0
    filtered = bool(lyr.subsetString())
    if filtered:
        plan.warnings.append(f"'{name}' has a filter on it, so only the features it shows are tagged.")

    # group this layer's sources by column, as this provider will store the name
    cols = {}
    for spec, idx in sources:
        if spec.poly_layer_id == lid:
            plan.warnings.append(f"'{name}' is one of the polygon layers, so it does not "
                                 f"tag itself with '{spec.out_field}'.")
            continue
        base = sanitize_field_name(spec.out_field, shapefile=shp)
        cols.setdefault(base.lower(), {"base": base, "idx": []})["idx"].append(idx)
    if not cols:
        return

    src_crs = lyr.crs()
    xforms = {}
    for col in cols.values():
        for idx in col["idx"]:
            key = _crs_key(idx.crs)
            if key not in xforms:
                xforms[key] = None if src_crs == idx.crs else QgsCoordinateTransform(src_crs, idx.crs, project)

    label_fld = _label_field(lyr)
    values = {k: {} for k in cols}
    tally = {k: {"total": 0, "tagged": 0, "outside": 0, "border": 0, "overlap": 0,
                 "blank_value": 0, "cut": 0, "straddle": 0, "failed": 0} for k in cols}
    labels = {}
    for feat in lyr.getFeatures():
        labels[feat.id()] = _norm_value(feat[label_fld]) if label_fld else str(feat.id())
        geom = feat.geometry()
        for key, col in cols.items():
            tally[key]["total"] += 1
            val = _merged_value(geom, gtype, col["idx"], xforms, limit, tally[key], QgsGeometry, QgsWkbTypes)
            values[key][feat.id()] = val
            if val is None:
                if not tally[key].pop("_blank_hit", False):
                    tally[key]["outside"] += 1
            else:
                tally[key]["tagged"] += 1
                tally[key].pop("_blank_hit", None)

    # decide the final column name per column, against this layer's own fields
    plan.layer_names[lid] = name
    rows, stats, info, counts = {}, {}, {}, {}
    for key, col in cols.items():
        decision = _decide_column(plan, lyr, name, col["base"], values[key], on_conflict, shp, filtered)
        if decision is None:
            continue
        final = decision["column"]
        if final.lower() in {c.lower() for c in info}:     # 'pon' became pon_2, and pon_2 was also asked for
            final = _next_free_name(col["base"], lyr, shp, reserved=list(info))
            decision["column"] = final
        stats[final] = tally[key]
        info[final] = decision
        counts[final] = {}
        for v in values[key].values():
            if v is not None:
                counts[final][v] = counts[final].get(v, 0) + 1
        _warn_counts(plan, name, final, tally[key], src_crs)
        if decision["action"] == "same":
            continue
        for fid, v in values[key].items():
            if decision["action"] == "fill" and fid not in decision["blank_fids"]:
                continue
            rows.setdefault(fid, {})[final] = v

    plan.stats[lid] = stats
    plan.col_info[lid] = info
    plan.value_counts[lid] = counts
    written_cols = [c for c, d in info.items() if d["action"] != "same"]
    if not written_cols:
        return
    plan.out_fields[lid] = written_cols
    plan.rows[lid] = rows
    plan.target_prints[lid] = _geom_print(lyr)
    samples = []
    for fid in list(labels)[:TagPlan.SAMPLE_CAP]:
        s = {"label": labels[fid]}
        s.update(rows.get(fid, {}))
        samples.append(s)
    plan.samples[lid] = samples


def _merged_value(geom, gtype, indexes, xforms, limit, tally, QgsGeometry, QgsWkbTypes):
    """One feature against every polygon layer feeding one column."""
    if geom is None or geom.isEmpty():
        return None

    def local(idx):
        xf = xforms[_crs_key(idx.crs)]
        if xf is None:
            return geom
        g = QgsGeometry(geom)
        g.transform(xf)
        return g

    if gtype == QgsWkbTypes.LineGeometry:
        found, blank = set(), False
        mid_line = []
        try:
            for idx in indexes:
                g = local(idx)
                mid_line.append((idx, g))
                got, b = idx.along_line(g)
                found |= got
                blank = blank or b
            if not found:                         # a line shorter than the guard
                for idx, g in mid_line:
                    pt = g.interpolate(g.length() / 2.0)
                    inside, border, b = idx.at_point(pt)
                    found |= inside | border
                    blank = blank or b
        except Exception:
            _swallowed_note()
            tally["failed"] += 1
            return None
        if not found:
            if blank:
                tally["blank_value"] += 1
                tally["_blank_hit"] = True
            return None
        text, was_cut = _join_values(found, limit)
        if was_cut:
            tally["cut"] += 1
        return text

    inside, border, blank = set(), set(), False
    across = set()
    try:
        for idx in indexes:
            g = local(idx)
            pt = g if gtype == QgsWkbTypes.PointGeometry else _rep_point(g)
            if pt is None:
                continue
            a, b_, bl = idx.at_point(pt)
            inside |= a
            border |= b_
            blank = blank or bl
            if gtype == QgsWkbTypes.PolygonGeometry:
                across |= idx.across_area(g)
    except Exception:
        _swallowed_note()
        tally["failed"] += 1
        return None
    if len(across) > 1:
        tally["straddle"] += 1
    if len(inside) > 1:
        tally["overlap"] += 1
    if border:
        tally["border"] += 1
    found = inside | border
    if not found:
        if blank:
            tally["blank_value"] += 1
            tally["_blank_hit"] = True
        return None
    return _natural_first(found)


def _decide_column(plan, lyr, name, base, values, on_conflict, shp, filtered):
    """Final column and action for one column on one layer. None means refused."""
    stored = (base[:_SHP_FIELD_MAX] if shp else base).lower()
    existing = None
    for f in lyr.fields():
        if f.name().lower() == stored:
            existing = f
            break
    longest = max((len(v) for v in values.values() if v), default=0)
    new_len = _SHP_MAX_TEXT if shp else 0
    near = [f.name() for f in lyr.fields()
            if f.name().lower() != stored and f.name().lower().startswith(stored)]
    if near:
        plan.warnings.append(f"'{name}' also has {', '.join(near)}. Left alone.")
    if existing is None:
        return {"column": base, "action": "new", "existing": None, "old": None,
                "length": new_len, "blank_fids": set()}

    real = existing.name()
    text = _is_string_field(existing)
    fits = text and (not existing.length() or existing.length() >= longest)
    current = {f.id(): f[real] for f in lyr.getFeatures()}
    blank_fids = {fid for fid, v in current.items() if _is_blank(v)}

    def holds_these(column):
        pon = _is_pon_column(base)
        return all(_norm_value(column.get(fid)) == v or (pon and _same_pon(column.get(fid), v))
                   for fid, v in values.items())

    differs = sum(1 for fid, v in values.items()
                  if _norm_value(current.get(fid)) != v
                  and not (_is_pon_column(base) and _same_pon(current.get(fid), v)))

    if on_conflict == "overwrite":
        if not fits:
            plan.errors.append(f"'{name}': column '{real}' is {existing.typeName()} and cannot "
                               f"hold these values, so it was not overwritten. Use a new column.")
            return None
        if _layer_file(lyr) is None:
            plan.errors.append(f"'{name}' is not a file layer, so it cannot be backed up first. "
                               f"Column '{real}' was not overwritten.")
            return None
        old = _next_free_name(real, lyr, shp, suffix="_old")
        plan.warnings.append(f"'{name}': overwriting '{real}'. {differs} value(s) change; "
                             f"the old values are copied to '{old}' and the file is backed up first.")
        return {"column": real, "action": "overwrite", "existing": real, "old": old,
                "length": existing.length(), "blank_fids": blank_fids}
    if on_conflict == "fill":
        if not fits:
            plan.errors.append(f"'{name}': column '{real}' is {existing.typeName()} and cannot "
                               f"hold these values, so it was left alone. Use a new column.")
            return None
        plan.warnings.append(f"'{name}': filling {len(blank_fids)} blank value(s) in '{real}'. "
                             f"Values already there stay.")
        return {"column": real, "action": "fill", "existing": real, "old": None,
                "length": existing.length(), "blank_fids": blank_fids}

    if not filtered:
        if differs == 0 and len(blank_fids) == len(current):
            plan.warnings.append(f"'{name}': '{real}' is empty and nothing here falls in an area. No change.")
            return {"column": real, "action": "same", "existing": real, "old": None,
                    "length": existing.length(), "blank_fids": blank_fids}
        if fits and len(blank_fids) == len(current):
            plan.warnings.append(f"'{name}': column '{real}' is empty, so it is filled "
                                 f"rather than adding another.")
            return {"column": real, "action": "reuse", "existing": real, "old": None,
                    "length": existing.length(), "blank_fids": blank_fids}
        if differs == 0:
            plan.warnings.append(f"'{name}': '{real}' already holds these values. No change.")
            return {"column": real, "action": "same", "existing": real, "old": None,
                    "length": existing.length(), "blank_fids": blank_fids}
        # An earlier run's pon_2 already says this: a rerun must not grow pon_3, pon_4...
        import re
        for f in lyr.fields():
            if not re.fullmatch(re.escape(stored) + r"_\d+", f.name().lower()):
                continue
            if holds_these({feat.id(): feat[f.name()] for feat in lyr.getFeatures()}):
                plan.warnings = [w for w in plan.warnings if w != f"'{name}' also has {', '.join(near)}. Left alone."]
                plan.warnings.append(f"'{name}': '{f.name()}' already holds these values. No change.")
                return {"column": f.name(), "action": "same", "existing": f.name(), "old": None,
                        "length": f.length(), "blank_fids": set()}
    new = _next_free_name(base, lyr, shp)
    plan.warnings.append(f"'{name}': '{real}' already holds data, so the new column is '{new}'. "
                         f"'{real}' is not touched.")
    return {"column": new, "action": "new", "existing": None, "old": None,
            "length": new_len, "blank_fids": set()}


def _warn_counts(plan, name, col, st, crs):
    if st["total"] and not st["tagged"]:
        plan.warnings.append(f"'{name}': 0 of {st['total']} features fall inside any polygon for "
                             f"'{col}'. Wrong area, or a wrong layer CRS ({crs.authid() or 'custom'})?")
    if st["border"]:
        plan.warnings.append(f"'{name}': {st['border']} feature(s) sit exactly on a border in "
                             f"'{col}' and took the first value in order.")
    if st["overlap"]:
        plan.warnings.append(f"'{name}': {st['overlap']} feature(s) sit inside two overlapping "
                             f"areas in '{col}'. The first in order is kept, the other is dropped.")
    if st["straddle"]:
        plan.warnings.append(f"'{name}': {st['straddle']} polygon(s) straddle a border in "
                             f"'{col}'. Each took the area its centre point falls in.")
    if st["blank_value"]:
        plan.warnings.append(f"'{name}': {st['blank_value']} feature(s) sit in a polygon with a "
                             f"blank value, so '{col}' stays blank for them.")
    if st["cut"]:
        plan.warnings.append(f"'{name}': {st['cut']} long list(s) in '{col}' do not fit a shapefile "
                             f"field of {_SHP_MAX_TEXT} characters. Cut at a whole name, then '+N more'.")
    if st["failed"]:
        plan.warnings.append(f"'{name}': {st['failed']} feature(s) could not be converted to the "
                             f"polygon layer's CRS, so '{col}' stays blank for them.")


# claude:intent MUTATE fibre_automation/tagging/zone_tag.py _apply_merged, _rollback,
#   _delete_columns, backup_layer_file. User asked: "Make sure that this works perfectly"
#   and "go" on plan e4e8f0bb. Adds columns and fills them from the plan the user previewed.
#   Existing values change only in overwrite or fill mode, which the user picks; overwrite
#   copies old values first and takes a file backup. On failure it restores originals, then
#   removes only columns this run added. Gated behind Apply. approved-destructive
def backup_layer_file(lyr):
    """Copy the file behind a layer beside it, timestamped. Returns the path, or None.

    GeoPackage goes through sqlite's backup API with a read-only source, so a file QGIS
    holds open still copies consistently. Restoring reverts every layer in that file.
    """
    import datetime
    import os
    import shutil
    import sqlite3
    from pathlib import Path
    src = _layer_file(lyr)
    if not src:
        return None
    path = Path(src)
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    suffix = path.suffix.lower()
    siblings = [path]
    if suffix == ".shp":
        siblings = [path.with_suffix(e) for e in (".shp", ".shx", ".dbf", ".prj", ".cpg", ".qix", ".qmd")
                    if path.with_suffix(e).exists()]
    size = sum(p.stat().st_size for p in siblings)
    try:
        if shutil.disk_usage(str(path.parent)).free < size * 1.1:
            return None
    except OSError:
        return None
    n, stem = 0, f"{path.stem}.bak_{stamp}"
    while any(path.with_name(f"{stem}{p.suffix}").exists() for p in siblings):
        n += 1
        stem = f"{path.stem}.bak_{stamp}_{n}"
    made = []
    try:
        if suffix == ".gpkg":
            dest = path.with_name(stem + suffix)
            made.append(dest)
            source = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)
            try:
                target = sqlite3.connect(str(dest))
                try:
                    source.backup(target)
                finally:
                    target.close()
            finally:
                source.close()
            return str(dest)
        for p in siblings:
            dest = path.with_name(stem + p.suffix)
            made.append(dest)
            shutil.copy2(str(p), str(dest))
        return str(path.with_name(stem + path.suffix))
    except Exception:
        _swallowed_note()
        for p in made:
            try:
                os.remove(str(p))
            except OSError:
                _swallowed_note()
        return None


def _write_values(dp, attr_map):
    """The one bulk value write."""
    return dp.changeAttributeValues(attr_map)


def _delete_columns(dp, indexes):
    return dp.deleteAttributes(indexes)


def _same_value(a, b):
    return _norm_value(a) == _norm_value(b)


def _exactly_same(a, b):
    """For proving a restore: 'HAND ' is not 'HAND', and NULL is not ''."""
    def null(v):
        return v is None or (hasattr(v, "isNull") and v.isNull())
    if null(a) or null(b):
        return null(a) and null(b)
    return a == b


def _disk_view(lyr, dp):
    """A fresh look at the file, so a failed run's report does not rest on this provider's memory."""
    from qgis.core import QgsVectorLayer
    try:
        if lyr.providerType() == "ogr":
            fresh = QgsVectorLayer(lyr.source(), "check", "ogr")
            if fresh.isValid():
                return fresh.dataProvider()
    except Exception:
        _swallowed_note()
    return dp


def _rollback(lyr, dp, written, originals, added):
    """Undo a failed run. Returns what could NOT be undone; [] means the layer is as it was.

    Original values go back first, and only on cells still holding what this run wrote
    (or already back to the original). Then only columns this run added are removed.
    """
    from qgis.core import QgsFeatureRequest
    left = []
    if originals:
        restore, moved = {}, 0
        names = dp.fields()
        for feat in dp.getFeatures(QgsFeatureRequest().setFilterFids(list(originals))):
            fid = feat.id()
            for idx, orig in originals[fid].items():
                now = feat.attribute(names.at(idx).name())
                ours = written.get(fid, {}).get(idx)
                if _same_value(now, orig) and now == orig:
                    continue
                if _same_value(now, ours) or _same_value(now, orig):
                    restore.setdefault(fid, {})[idx] = orig
                else:
                    moved += 1
        if restore:
            try:
                _write_values(dp, restore)
            except Exception:
                _swallowed_note()
            # Believe the file, not the provider's True.
            wrong = 0
            for feat in _disk_view(lyr, dp).getFeatures(QgsFeatureRequest().setFilterFids(list(restore))):
                for idx, orig in restore[feat.id()].items():
                    if not _exactly_same(feat.attribute(names.at(idx).name()), orig):
                        wrong += 1
            if wrong:
                left.append(f"{wrong} original value(s) did not go back")
        if moved:
            left.append(f"{moved} value(s) changed by someone else in the meantime, not touched")
    if left:
        # Old values may be the only copy left in an *_old column: keep every added column.
        if added:
            left.append("column(s) " + ", ".join(added))
        return left
    if added:
        fields = dp.fields()
        idxs = [fields.indexOf(n) for n in added if fields.indexOf(n) >= 0]
        try:
            if idxs:
                _delete_columns(dp, idxs)
        except Exception:
            _swallowed_note()
        lyr.updateFields()
        still = [n for n in added if dp.fields().indexOf(n) >= 0]
        if still:
            left.append("column(s) " + ", ".join(still))
    return left


def _geom_print(lyr, attrs=False):
    """A checksum of a layer's geometry, to notice anything moving after Preview.
    attrs: its values too. A polygon renamed after Preview makes the tags just as wrong."""
    import zlib
    crc = 0
    n = 0
    for feat in lyr.getFeatures():
        n += 1
        crc = zlib.crc32(str(feat.id()).encode(), crc)
        if feat.hasGeometry():
            crc = zlib.crc32(bytes(feat.geometry().asWkb()), crc)
        if attrs:
            crc = zlib.crc32(repr([None if a is None or (hasattr(a, "isNull") and a.isNull()) else a
                                   for a in feat.attributes()]).encode(), crc)
    return n, crc


def _apply_merged(project, plan, backup):
    from qgis.core import QgsFeatureRequest, QgsField, QgsProject, QgsVectorDataProvider
    from qgis.PyQt.QtCore import QMetaType
    project = project or QgsProject.instance()
    res = ApplyResult()
    res.layer_names = dict(plan.layer_names)
    backed_up = {}

    # Values were worked out at Preview. If a polygon moved since, none of them can be trusted.
    for pid, print_then in plan.source_prints.items():
        poly = project.mapLayer(pid)
        if poly is None or _geom_print(poly, attrs=True) != print_then:
            res.errors.append(f"'{poly.name() if poly else pid}' changed since Preview. "
                              f"Nothing was written. Run Preview again.")
            return res

    def fail(name, what, left, bak):
        tail = f" A backup is at {bak}." if bak else ""
        if left:
            res.errors.append(f"'{name}': {what} These were left behind: {'; '.join(left)}.{tail}")
        else:
            res.errors.append(f"'{name}': {what} The layer was put back, so it is unchanged.")

    for lid, rows in plan.rows.items():
        name = plan.layer_names.get(lid, lid)
        lyr = project.mapLayer(lid)
        if lyr is None or not lyr.isValid():
            res.errors.append(f"'{name}' is no longer in the project, so it was skipped.")
            continue
        if lyr.isEditable():
            res.skipped.append(f"'{name}' is being edited. Save or discard those edits first.")
            continue
        dp = lyr.dataProvider()
        caps = dp.capabilities()
        if not (caps & QgsVectorDataProvider.Capability.AddAttributes
                and caps & QgsVectorDataProvider.Capability.ChangeAttributeValues
                and caps & QgsVectorDataProvider.Capability.DeleteAttributes):
            res.skipped.append(f"'{name}' does not allow adding, filling and removing columns.")
            continue

        info = plan.col_info.get(lid, {})
        wanted = plan.out_fields.get(lid, [])
        needs_backup = any(info[c]["action"] == "overwrite" for c in wanted)

        # the layer may have changed since Preview
        names_now = {n.lower() for n in lyr.fields().names()}
        clash = [c for c in wanted if info[c]["action"] == "new" and c.lower() in names_now]
        if clash:
            res.errors.append(f"'{name}': {', '.join(clash)} appeared since Preview. "
                              f"Nothing was written. Run Preview again.")
            continue
        if _geom_print(lyr) != plan.target_prints.get(lid):
            res.errors.append(f"'{name}' changed since Preview. Nothing was written. Run Preview again.")
            continue
        # a blank Preview promised to fill must still be blank now
        now_filled = []
        for c in wanted:
            action = info[c]["action"]
            if action not in ("reuse", "fill"):
                continue
            for feat in lyr.getFeatures():
                if feat.id() in rows and c in rows[feat.id()] and not _is_blank(feat[info[c]["existing"]]):
                    now_filled.append(c)
                    break
        if now_filled:
            res.errors.append(f"'{name}': {', '.join(now_filled)} got values since Preview. "
                              f"Nothing was written. Run Preview again.")
            continue

        src_file = _layer_file(lyr)
        bak = backed_up.get(src_file)
        if (backup or needs_backup) and src_file and not bak:
            bak = backup_layer_file(lyr)
            if not bak:
                res.errors.append(f"'{name}': could not back up {src_file}. Nothing was written.")
                continue
            backed_up[src_file] = bak
            res.backups.append(bak)
        if needs_backup and not bak:
            res.errors.append(f"'{name}' has no file to back up. Nothing was written.")
            continue

        # new columns, plus an *_old copy for each overwrite with the source column's type
        before = set(dp.fields().names())
        to_add = []
        for c in wanted:
            d = info[c]
            if d["action"] == "new":
                to_add.append(QgsField(c, QMetaType.Type.QString, len=d["length"]))
            elif d["action"] == "overwrite":
                ef = lyr.fields()[lyr.fields().indexFromName(d["existing"])]
                keep = QgsField(ef)
                keep.setName(d["old"])
                to_add.append(keep)
        added = []
        if to_add:
            why = ""
            try:
                ok = dp.addAttributes(to_add)
            except Exception as exc:
                ok, why = False, f" ({exc})"
            lyr.updateFields()
            added = [n for n in dp.fields().names() if n not in before]
            if not ok or {n.lower() for n in added} != {f.name().lower() for f in to_add}:
                left = _rollback(lyr, dp, {}, {}, added)
                fail(name, f"could not add {', '.join(f.name() for f in to_add)}{why}.", left, bak)
                continue

        originals, attr_map = {}, {}
        try:
            # resolve provider indices, and read what is there now for anything we touch
            fields = dp.fields()
            idx_of = {c: fields.indexOf(c if info[c]["action"] == "new" else info[c]["existing"]) for c in wanted}
            old_of = {info[c]["old"]: fields.indexOf(info[c]["existing"]) for c in wanted if info[c]["old"]}
            if any(i < 0 for i in idx_of.values()) or any(fields.indexOf(o) < 0 for o in old_of):
                left = _rollback(lyr, dp, {}, {}, added)
                fail(name, "a column did not appear on the provider.", left, bak)
                continue
            touched = {idx_of[c] for c in wanted if info[c]["action"] != "new"}
            for feat in dp.getFeatures():
                fid = feat.id()
                row = rows.get(fid)
                if row is None and not old_of:
                    continue
                attrs = feat.attributes()
                if touched:
                    originals[fid] = {i: attrs[i] for i in touched}
                out = {}
                for old_name, src_i in old_of.items():
                    out[fields.indexOf(old_name)] = attrs[src_i]
                for c, v in (row or {}).items():
                    out[idx_of[c]] = v
                if out:
                    attr_map[fid] = out
            if not attr_map:
                continue

            why = ""
            try:
                wrote = _write_values(dp, attr_map)
            except Exception as exc:
                wrote, why = False, f" ({exc})"
            if not wrote:
                left = _rollback(lyr, dp, attr_map, originals, added)
                fail(name, f"the provider rejected the write{why}.", left, bak)
                lyr.reload()
                continue

            # what the provider says it stored must be what the plan said
            wrong = 0
            for feat in dp.getFeatures(QgsFeatureRequest().setFilterFids(list(attr_map))):
                attrs = feat.attributes()
                wrong += sum(1 for i, v in attr_map[feat.id()].items() if not _same_value(attrs[i], v))
            if wrong:
                left = _rollback(lyr, dp, attr_map, originals, added)
                fail(name, f"{wrong} value(s) did not store as planned.", left, bak)
                lyr.reload()
                continue
        except Exception as exc:
            # anything raised after the columns went on must still undo them and say so
            _swallowed_note()
            try:
                left = _rollback(lyr, dp, attr_map, originals, added)
            except Exception:
                _swallowed_note()
                left = ["the layer could not be checked afterwards"] + [f"column {n}" for n in added]
            fail(name, f"the write stopped on an error ({exc}).", left, bak)
            lyr.reload()
            continue

        res.written[lid] = len(attr_map)
        for n in added:
            res.fields_added.append(f"{name}.{n}")
        try:
            lyr.updateFields()
            lyr.reload()
            lyr.triggerRepaint()
        except Exception:
            _swallowed_note()
    return res
