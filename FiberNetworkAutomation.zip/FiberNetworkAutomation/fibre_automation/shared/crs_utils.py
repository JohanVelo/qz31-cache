"""CRS validation and reprojection helpers."""

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsPointXY,
    QgsProject,
)


def ensure_projected(crs: QgsCoordinateReferenceSystem) -> bool:
    """Return True only if CRS is valid AND projected (metres). An invalid/empty
    CRS reports isGeographic()==False, so guard validity first — otherwise an
    unprojected/invalid layer would be wrongly waved through the metres gate."""
    return bool(crs) and crs.isValid() and not crs.isGeographic()


def reproject_layer(layer, target_crs_authid: str):
    """Return a memory copy of layer reprojected to target_crs_authid."""
    import processing
    result = processing.run(
        "native:reprojectlayer",
        {
            "INPUT": layer,
            "TARGET_CRS": QgsCoordinateReferenceSystem(target_crs_authid),
            "OUTPUT": "memory:",
        },
    )
    return result["OUTPUT"]


def layer_crs_ok(layer, expected_authid: str) -> bool:
    """Check that a layer's CRS matches expected_authid."""
    return layer.crs().authid() == expected_authid


def transform_point(x: float, y: float, src_authid: str, dst_authid: str):
    """Transform a single point between CRS. Returns (x, y)."""
    src = QgsCoordinateReferenceSystem(src_authid)
    dst = QgsCoordinateReferenceSystem(dst_authid)
    xform = QgsCoordinateTransform(src, dst, QgsProject.instance())
    pt = xform.transform(QgsPointXY(x, y))
    return pt.x(), pt.y()


# ── ellipsoid / metre measurement ────────────────────────────────────────────
# THE TRAP (found 2026-07-15, and it fails SILENTLY):
#   QgsProject.ellipsoid() returns the STRING 'NONE' when a project has no
#   ellipsoid set — which is QGIS's default for a brand-new project. 'NONE' is
#   TRUTHY, so the very common
#       da.setEllipsoid(project.ellipsoid() or "WGS84")
#   does NOT fall back: it sets the ellipsoid to "NONE". A geographic CRS then
#   measures in DEGREES, so a 1976 m cable measures 0.019 — and every length in
#   the plugin (cable km, spans, BOQ quantities) is silently wrong by ~100000x.
#   setEllipsoid('NONE') even returns True, so its return value proves nothing;
#   willUseEllipsoid() is the only honest check.
_NO_ELLIPSOID = ("", "NONE")


def safe_ellipsoid(project=None, crs=None) -> str:
    """The ellipsoid to actually use — never 'NONE', never empty.

    project.ellipsoid() → the layer/CRS's own ellipsoid → WGS84.
    """
    for src in (
        (lambda: project.ellipsoid()) if project is not None else None,
        (lambda: crs.ellipsoidAcronym()) if crs is not None else None,
    ):
        if src is None:
            continue
        try:
            v = (src() or "").strip()
        except Exception:
            continue
        if v and v.upper() not in _NO_ELLIPSOID:
            return v
    return "WGS84"


def metre_measurer(crs=None, project=None):
    """A QgsDistanceArea that really returns METRES. Use this, never raw setEllipsoid.

    Verifies with willUseEllipsoid() and falls back to WGS84, so callers can
    trust measureLength()/measureLine() to be metres on any project.
    """
    from qgis.core import QgsDistanceArea
    project = project or QgsProject.instance()
    da = QgsDistanceArea()
    try:
        if crs is not None:
            da.setSourceCrs(crs, project.transformContext())
    except Exception:
        pass
    try:
        da.setEllipsoid(safe_ellipsoid(project, crs))
        if not da.willUseEllipsoid():
            da.setEllipsoid("WGS84")
    except Exception:
        try:
            da.setEllipsoid("WGS84")
        except Exception:
            pass
    return da


def measures_metres(da) -> bool:
    """True if `da` returns metres — so a caller can fail loudly, not silently."""
    try:
        from qgis.core import QgsUnitTypes
        return (da.willUseEllipsoid()
                or da.lengthUnits() == QgsUnitTypes.DistanceUnit.DistanceMeters)
    except Exception:
        return False
