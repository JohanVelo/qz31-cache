"""Phase 3 gate: stand_W slider changes the erven. Clip to a small block region, generate at
stand_W=14 and stand_W=22. PASS if both produce uniform rectangles and median area grows with W
(ratio > 1.2) -> the slider deterministically controls lot size."""
import geopandas as gpd
from shapely.geometry import box
from erven import generate_erven

BLD = "C:/Temp/detected_buildings.geojson"
# small formal block window (clean grid) for a fast, clear test
BBOX = (27.046, -26.7235, 27.0515, -26.719)


def main():
    aoi = gpd.GeoDataFrame(geometry=[box(*BBOX)], crs=4326)
    b = gpd.read_file(BLD).to_crs(4326)
    b = b[b.intersects(box(*BBOX))].copy()
    print(f"buildings in window: {len(b)}")

    base = dict(merge_m=12.0, stand_depth=27.0, orient_snap=True, min_area=60.0, max_area=1300.0)
    g14 = generate_erven(b, aoi, {**base, "stand_W": 14.0})
    g22 = generate_erven(b, aoi, {**base, "stand_W": 22.0})
    m14 = float(g14["area_m2"].median()) if len(g14) else 0
    m22 = float(g22["area_m2"].median()) if len(g22) else 0
    print(f"stand_W=14 -> {len(g14)} erven, median {m14:.0f} m^2 | "
          f"stand_W=22 -> {len(g22)} erven, median {m22:.0f} m^2")

    ratio = (m22 / m14) if m14 else 0
    ok = len(g14) > 0 and len(g22) > 0 and ratio > 1.2
    print(f"median ratio (22/14) = {ratio:.2f}")
    print("GATE:", "PASS" if ok else "FAIL", "(stand_W slider deterministically changes lot size; no Voronoi)")
    g14.to_file("C:/Temp/phase3_erven_w14.geojson", driver="GeoJSON")
    g22.to_file("C:/Temp/phase3_erven_w22.geojson", driver="GeoJSON")
    print("wrote phase3_erven_w14/w22.geojson")


if __name__ == "__main__":
    main()
