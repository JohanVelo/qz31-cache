"""Start Number preview engine for Label My Network pole selection.

PREVIEW ONLY. This module computes what a renumber WOULD do and hands back a
plan. It never writes an attribute, never touches a QGIS layer, never updates a
reference or cascade, and imports neither Qt nor QGIS. The dangerous half is a
separate, later, separately-approved step.

THE BLOCK MODEL (JJ, 2026-08-03)
--------------------------------
A block VALUE is the complete pole sequence prefix plus its number - "A001".
The block itself is the prefix ("A"); the number is what increments inside it.

Three rules follow from that, and all three are hard:

  * Collisions are compared on the FULL TARGET LABEL ("MOA.P.A001"), never on
    the bare number and never on the block value alone. Two poles differing
    only in role or stack are NOT a collision; two resolving to the same
    complete label ARE, whatever produced them.

  * A selection spanning several blocks needs a start number FOR EACH BLOCK.
    One number applied across blocks A and B would silently reflow one into
    the other, so a mixed-block selection with any block missing its start is
    refused outright rather than guessed at.

  * Unselected poles are NEVER renumbered - not to make room, not to close a
    gap, not for any reason. They appear here only as labels to collide
    against.

WHY A PLAN OBJECT AND NOT A BOOLEAN
-----------------------------------
A renumber that is refused must say exactly which poles and which labels caused
the refusal. "Blocked" on its own sends the operator hunting.
"""

import re

__all__ = [
    "BLOCKED",
    "READY",
    "RenumberPlan",
    "format_block",
    "parse_block",
    "plan_renumber",
]

READY = "ready"
BLOCKED = "blocked"

# "A001" -> prefix "A", number 1, width 3. The prefix may be empty ("0007")
# and may be multi-letter ("AB12"); the number is the trailing digit run.
_BLOCK_RE = re.compile(r"^\s*([^\d\s]*)\s*(\d+)\s*$")


def parse_block(value):
    """Split a block value into its parts, or None when it cannot be read.

    Returns {"prefix", "number", "width", "raw"}. None means the operator must
    supply the answer - it is never guessed, because a wrong guess renumbers a
    real pole.
    """
    if value is None:
        return None
    raw = str(value).strip()
    if not raw:
        return None
    m = _BLOCK_RE.match(raw)
    if not m:
        return None
    prefix, digits = m.group(1), m.group(2)
    return {"prefix": prefix, "number": int(digits),
            "width": len(digits), "raw": raw}


def format_block(prefix, number, width):
    """Rebuild a block value, keeping the original zero padding."""
    return "%s%0*d" % (prefix or "", max(int(width), 1), int(number))


class RenumberPlan(object):
    """What a renumber WOULD do. Nothing here has been applied."""

    def __init__(self, rows=None, problems=None, blocks=None):
        self.rows = list(rows or ())          # [{key,old,new,old_label,new_label,changed}]
        self.problems = list(problems or ())  # [{code, detail, items}]
        self.blocks = dict(blocks or {})      # prefix -> {"count","start","width"}

    @property
    def status(self):
        return BLOCKED if self.problems else READY

    @property
    def blocked(self):
        return bool(self.problems)

    @property
    def changed(self):
        return [r for r in self.rows if r["changed"]]

    def counts(self):
        return {"selected": len(self.rows), "changed": len(self.changed),
                "unchanged": len(self.rows) - len(self.changed),
                "problems": len(self.problems)}

    def summary(self):
        """One operator-facing line. Never claims success while blocked."""
        c = self.counts()
        if self.blocked:
            return ("RENUMBER BLOCKED - %d problem%s must be resolved before "
                    "anything can be previewed."
                    % (c["problems"], "" if c["problems"] == 1 else "s"))
        if not c["changed"]:
            return ("Nothing would change - every selected pole already has "
                    "the number it would be given.")
        return ("Ready: %d of %d selected pole%s would be renumbered. "
                "Nothing is written until you apply."
                % (c["changed"], c["selected"],
                   "" if c["selected"] == 1 else "s"))

    def __repr__(self):
        return "RenumberPlan(%s, %s)" % (self.status, self.counts())


def _identity_label(block_value, entry):
    return block_value


def plan_renumber(entries, starts, label_fmt=None, existing_labels=None,
                  order=None):
    """Work out the target number for every SELECTED pole.

    entries  : the retained selection, IN THE ORDER IT WILL BE NUMBERED -
               capture order by default, or walk order when that mode is on.
               Each needs {"key", "block"}; "label" is optional and used only
               for messages.
    starts   : {prefix: start_number}. One entry per block present in the
               selection. A missing block is a hard refusal, never a guess.
    label_fmt: callable(block_value, entry) -> the FULL label that block value
               would produce. Collisions are judged on this, not on the block
               value. Defaults to identity so the engine stays usable bare.
    existing_labels: full labels of poles NOT in the selection. Targets are
               checked against these; those poles are never modified.
    order    : optional explicit ordering of keys (walk order). Any selected
               key missing from it keeps its relative capture order after the
               ones listed - a partial walk stays sensible rather than
               scrambling the rest.

    Returns a RenumberPlan. Computes only; writes nothing.
    """
    entries = list(entries or ())
    starts = dict(starts or {})
    fmt = label_fmt or _identity_label
    existing = set(existing_labels or ())
    problems = []

    # -- explicit ordering (walk order) ---------------------------------
    if order:
        rank = {k: i for i, k in enumerate(order)}
        entries = sorted(
            entries,
            key=lambda e: (0, rank[e["key"]]) if e["key"] in rank
            else (1, entries.index(e)))

    # -- every selected pole must be readable ---------------------------
    parsed = []
    unreadable = []
    for e in entries:
        p = parse_block(e.get("block"))
        if p is None:
            unreadable.append(e.get("label") or e.get("block") or "(blank)")
        parsed.append((e, p))
    if unreadable:
        problems.append({
            "code": "unreadable_number",
            "detail": ("%d selected pole%s ha%s a blank or unreadable number, "
                       "so where the sequence starts cannot be worked out. "
                       "Enter it, or deselect those poles."
                       % (len(unreadable), "" if len(unreadable) == 1 else "s",
                          "s" if len(unreadable) == 1 else "ve")),
            "items": unreadable[:12]})

    # -- every block present must have its own start --------------------
    present = []
    for _e, p in parsed:
        if p and p["prefix"] not in present:
            present.append(p["prefix"])
    missing = [b for b in present if b not in starts]
    if missing:
        problems.append({
            "code": "missing_start",
            "detail": ("This selection spans %d block%s and %d ha%s no start "
                       "number. One number cannot be shared across blocks - it "
                       "would reflow one into another. Give each block its own."
                       % (len(present), "" if len(present) == 1 else "s",
                          len(missing), "s" if len(missing) == 1 else "ve")),
            "items": [b or "(no prefix)" for b in missing]})

    if problems:                       # cannot number anything meaningfully
        return RenumberPlan(problems=problems)

    # -- assign, in the given order, per block --------------------------
    counters = {b: int(starts[b]) for b in present}
    rows = []
    blocks = {}
    for e, p in parsed:
        prefix = p["prefix"]
        n = counters[prefix]
        counters[prefix] = n + 1
        new_block = format_block(prefix, n, p["width"])
        old_label = e.get("label") or fmt(p["raw"], e)
        new_label = fmt(new_block, e)
        rows.append({"key": e.get("key"), "old": p["raw"], "new": new_block,
                     "old_label": old_label, "new_label": new_label,
                     "changed": new_block != p["raw"]})
        b = blocks.setdefault(prefix, {"count": 0, "start": int(starts[prefix]),
                                       "width": p["width"]})
        b["count"] += 1

    # -- collision 1: targets colliding WITH EACH OTHER -----------------
    seen = {}
    dupes = []
    for r in rows:
        if r["new_label"] in seen:
            dupes.append("%s and %s both become %s"
                         % (seen[r["new_label"]], r["old"], r["new_label"]))
        else:
            seen[r["new_label"]] = r["old"]
    if dupes:
        problems.append({
            "code": "duplicate_target",
            "detail": ("%d target label%s would be produced twice by this "
                       "selection. Renumbering would create duplicates."
                       % (len(dupes), "" if len(dupes) == 1 else "s")),
            "items": dupes[:12]})

    # -- collision 2: targets colliding with UNSELECTED poles -----------
    # This is the one that silently corrupts a network: the clashing pole is
    # not in the selection, so it is never renumbered out of the way.
    # NOTE (Codex review 2026-08-05): do NOT suppress this when the pole is
    # unchanged. existing_labels holds poles NOT in the selection, so a match
    # on an UNCHANGED pole means a different pole already carries that exact
    # label — a pre-existing duplicate. Renumbering the rest of the selection
    # around an existing duplicate is not safe, so it is surfaced, not hidden.
    # The earlier "new_label != old_label" guard only helped callers who broke
    # the contract by passing selected poles in here too.
    clashes = []
    for r in rows:
        if r["new_label"] not in existing:
            continue
        if r["changed"]:
            clashes.append(
                "%s would become %s, which already belongs to a pole that is "
                "NOT selected" % (r["old"], r["new_label"]))
        else:
            clashes.append(
                "%s already shares the label %s with a pole that is NOT "
                "selected — a duplicate that exists before any renumber"
                % (r["old"], r["new_label"]))
    if clashes:
        problems.append({
            "code": "collides_with_unselected",
            "detail": ("%d target label%s already belong%s to a pole outside "
                       "this selection. Unselected poles are never renumbered "
                       "to make room, so this is refused."
                       % (len(clashes), "" if len(clashes) == 1 else "s",
                          "s" if len(clashes) == 1 else "")),
            "items": clashes[:12]})

    if problems:                       # refuse UNSAFE output entirely
        return RenumberPlan(problems=problems, blocks=blocks)
    return RenumberPlan(rows=rows, blocks=blocks)
