"""fibertime_mml — Fibertime-approved "Master Material List" BoQ generator.

Reverse-engineered (2026-06-19, 6-agent analysis) from the 3 Fibertime-APPROVED
BoQs (MOA / MAM / LAW) so our output matches the structure + SKUs Fibertime signs
off — a per-SKU Bill of Materials, NOT a cost summary. Rates come from the bundled
`fibertime_rates.json` (2025 canonical price list). Shippable: openpyxl + stdlib +
native QGIS only.

Derivation (each rule cites the approved evidence in code comments):
  Cable     drops binned by length→DP-A/PRE SKUs · aerial/UG by (subtyp,cblcpty)→FIB
  Splitters STS(1:16 dome)→SPL029 · FTS(1:8 dome)→SPL063  (count by role, see note)
  Domes     enclosure spec_1 string→BOX/JOI SKU
  Midcoupl. 4*ODCFD0 + 8*M16
  Poles     1/pole, SKU by dim2 thickness band
  Hooks     Σ=Σpoles, split by cables-at-pole (fallback 10/81/7%)
  Hardware  dead-ends/tangents/slack/strapping/buckles (ratio rules; flagged)
  Splicing  splice protector + alcohol + kim wipes (from splice estimate)
  Home Conn 1 install-kit per ONT
All quantities scale to the LIVE design's feature counts (approved files are
whole-project; we ignore their numbers, keep their rates+SKUs).
"""
import json
import math
import os

_RATES_PATH = os.path.join(os.path.dirname(__file__), "fibertime_rates.json")

# ── cable SKU maps (subtyp, fibre-count) → FIB code  [agent 1] ──────────────
_ADSS = {"12F": "FIB124", "24F": "FIB243", "48F": "FIB431", "72F": "FIB710",
         "96F": "FIB907", "144F": "FIB125"}
_MINI = {"12F": "FIB915", "24F": "FIB916", "48F": "FIB917"}
_MICRO = {"12F": "FIB130", "24F": "FIB242", "48F": "FIB433", "72F": "FIB714",
          "96F": "FIB905", "144F": "FIB121", "288F": "FIB246"}
_DROP_BINS = [25, 30, 35, 40, 50, 60, 70]          # round UP; floor 25, cap 70

# enclosure spec_1 string → SKU  [agent 2]
# NB: most-specific keys FIRST — 'ODCFD0' is a substring of 'ODCFD08L', so the
# 8L variant must be tested before the prefix or it mis-matches to BOX181.
_ENCL_CONN = {"ODCFD08L": "BOX179", "ODCFD0": "BOX181",
              "M16 MICROLOOP": "BOX189", "M8 MICROLOOP": "BOX168"}
_ENCL_SPLICE = {"UMJ": "JOI033", "CMJ": "JOI028", "MMJ": "JOI027"}

# poles by dim2 thickness band  [agent 3]  (LCTT internal codes; rate fallback)
_POLE = {"120-140": ("POLE-CRE-7-120140", "Pole.Creosote.H4SANS754.7,0m.120-140", 554.46),
         "140-160": ("POLE-CRE-7-140160", "Pole.Creosote.H4SANS754.7,0m.140-160", 707.30)}
_HOOK = {1: "BRA063", 2: "BRA123", 3: "BRA064"}    # 1/2/3-way monopole bracket

_SECTION_ORDER = ["Cable", "Splitters", "Midcouplers", "Dome Joints", "Poles",
                  "Dead-Ends", "Tangents", "Hooks", "Slack Brackets",
                  "Strapping, Buckles & Coach Screws", "Labels", "Splicing",
                  "Home Connections", "Labour (Estimate)"]

# Canonical CATEGORY order — extracted from the approved bills (MAM, the fullest).
# Used to order categories within each section so our Master Material List reads in
# the exact reference sequence (e.g. Drop Cable before Aerial Cable in the Cable section).
import re as _re_mod
CATEGORY_ORDER = [
    "Drop Cable (Connectorised)", "Aerial Cable (ADSS)", "Aerial Cable (Mini-ADSS)",
    "Underground Cable (Micro-Blown)", "Splitter (Bare)", "Splitter (Connectorised)",
    "Midcoupler (Flanged)", "Midcoupler (Flangeless)", "Enclosure (Connectorised)",
    "Enclosure (Splice)", "Poles (Creosote)", "Dead-End(ADSS)", "Dead-End(Mini-ADSS)",
    "Hook (Monopole Bracket Offset)", "Tangent (ADSS)", "Slack Bracket (Bracket)",
    "Strapping (Steel)", "Buckle (Steel)", "Access Chamber (Manhole)",
    "Access Chamber (Manhole Key)", "Micro Duct (HDPE, Polyethylene)", "Conduit (HDPE)",
    "Conduit (Corr)", "Coupling (Micro Duct)", "End Cap (Micro Duct)", "Label (Chromadek)",
    "Cement Bag", "Tar Bag", "Bituman (SC60)", "Caution Tape (Trench)", "Alcohol (Aerosol)",
    "Kim Wipes", "Splice Protector", "Wall Attachment", "Electrical", "Cable Tie",
    "Screw", "Wall Attchment", "Label", "Power Cable Kit", "Micro Duct",
    "Drop Cable Installation", "Trenching (Underground)"]
_CATORDER_NORM = {_re_mod.sub(r"\s+", " ", c.strip().lower()): i for i, c in enumerate(CATEGORY_ORDER)}


def _cat_sort_key(cat):
    return _CATORDER_NORM.get(_re_mod.sub(r"\s+", " ", str(cat).strip().lower()), 999)


def _inum(v):
    """Tolerant int — non-numeric/None → 0 (for the featno count fields)."""
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return 0


def _distribute(total, prop):
    """Split `total` across keys in proportion to `prop` (a {key:count} dict),
    integer parts summing exactly to total (remainder on the largest key). Used to
    spread the featno hardware TOTAL across the slot subtypes/ways for the SKU lines."""
    s = sum(prop.values())
    if not total:
        return {}
    if not s:
        return {}
    keys = sorted(prop, key=lambda k: -prop[k])
    out = {}
    acc = 0
    for k in keys[1:]:
        v = int(round(total * prop[k] / s))
        out[k] = v
        acc += v
    out[keys[0]] = total - acc          # remainder onto the largest bucket
    return {k: v for k, v in out.items() if v}

# ── Labour (ESTIMATE only) ──────────────────────────────────────────────────
# These are the ONLY publicly-confirmed SA labour rates (2025-2026 market):
#   drop install R50-60/m · trenching R100-500/m. They are ROUGH ESTIMATES that
# vary hugely by contractor/terrain — every labour line is flagged "ESTIMATE,
# confirm with contractor" and totalled SEPARATELY from the (firm) material cost.
# Edit these two numbers to your own contractor rates.
_LABOUR_SECTION = "Labour (Estimate)"
LABOUR_DROP_INSTALL_PER_M = 55.0     # R50-60/m last-mile drop install (midpoint)
LABOUR_TRENCH_PER_M = 300.0          # R100-500/m underground trenching (midpoint)


def _load_rates():
    try:
        rb = json.load(open(_RATES_PATH, encoding="utf-8")).get("rate_book", {})
    except Exception:
        rb = {}
    return rb


class Line:
    __slots__ = (
        "category",
        "code",
        "desc",
        "note",
        "qty",
        "rate",
        "section",
        "supplier",
        "uom",
    )

    def __init__(self, section, code, qty, rb, uom=None, desc=None, category=None,
                 rate=None, supplier=None, note=""):
        info = rb.get(code, {})
        self.section = section
        self.code = code
        self.qty = qty
        self.category = category or info.get("category") or section
        self.desc = desc or info.get("description") or code
        self.uom = uom or info.get("uom") or "Each"
        self.rate = info.get("rate") if rate is None else rate
        self.supplier = supplier or info.get("supplier") or "FTTX"
        self.note = note


# ── design readers ──────────────────────────────────────────────────────────
def _norm_name(s):
    """Normalise a layer name for tolerant matching: lower-case, collapse spaces,
    and drop a trailing version suffix (' v1', ' V2', …) so 'Drop Cable v1'
    resolves to a project layer simply named 'Drop Cable'."""
    import re
    s = re.sub(r"\s+v\d+$", "", str(s).strip().lower())
    return re.sub(r"\s+", " ", s)


class _LayerMap(dict):
    """name -> layer. .get() falls back to a case-insensitive, version-suffix-
    tolerant match, so the canonical 'X v1' lookups in derive() still resolve
    against projects whose layers are named plainly ('X')."""

    def __init__(self, layers):
        super().__init__(layers)
        self._norm = {}
        for k, v in layers.items():
            self._norm.setdefault(_norm_name(k), v)

    def get(self, name, default=None):
        if name in self:
            return self[name]
        return self._norm.get(_norm_name(name), default)


def _layers(project):
    return _LayerMap({l.name(): l for l in project.mapLayers().values()})


def _utm(project):
    from qgis.core import (QgsDistanceArea, QgsCoordinateReferenceSystem)
    da = QgsDistanceArea()
    da.setSourceCrs(QgsCoordinateReferenceSystem("EPSG:32735"), project.transformContext())
    da.setEllipsoid("WGS84")
    return da


def _len_m(geom, src_crs, project):
    """Geodesic length in metres on the source-CRS geometry (kills the EPSG:4326
    degree bug — the proven setSourceCrs+ellipsoid pattern, same as boq/engine.py)."""
    from qgis.core import QgsDistanceArea
    try:
        da = QgsDistanceArea()
        da.setSourceCrs(src_crs, project.transformContext())
        # The project's ellipsoid is often "NONE" (ellipsoidal measure off) — a
        # TRUTHY string, so `or "WGS84"` would keep "NONE" and measureLength would
        # return DEGREES (~0) on a 4326 layer. Force a real ellipsoid so cable
        # metres + drop-length bins are correct.
        ell = project.ellipsoid()
        if not ell or str(ell).upper() == "NONE":
            ell = "WGS84"
        da.setEllipsoid(ell)
        v = da.measureLength(geom)
        return v if (v is not None and math.isfinite(v) and v >= 0) else 0.0
    except Exception:
        return 0.0


def _count(layer):
    return layer.featureCount() if layer else 0


def _attr(feat, name):
    try:
        i = feat.fields().indexFromName(name)
        return feat[i] if i >= 0 else None
    except Exception:
        return None


def _cap(val):
    """Normalise a fibre-capacity attribute to '24F' style."""
    if val is None:
        return None
    s = str(val).upper().replace(" ", "")
    if s and not s.endswith("F"):
        s += "F"
    return s


def _decompose_way(n):
    """Split a hook 'way' >3 into parts of 2 and 3 only (no 1-way leftovers, none >3)
    so the bill matches the 1-3-way catalogue in every approved BoQ. JJ rule (2026-06-22):
    4=2+2, 5=3+2, 6=3+3, 7=3+2+2, 8=3+3+2, ... Conserves total way-capacity (sum of parts
    == n). 1/2/3-way pass through unchanged."""
    if n <= 3:
        return [n] if n > 0 else []
    threes, rem = divmod(n, 3)
    if rem == 0:
        return [3] * threes
    if rem == 1:                       # 3+1 -> 2+2 (never leave a 1-way)
        return [3] * (threes - 1) + [2, 2]
    return [3] * threes + [2]          # rem == 2


DEFAULT_SLACK_M = 15.0   # service-loop + pole-height added to each drawn drop before
#                          length-binning (best-fit to approved MOA; configurable, flagged)

# ── Cable spool/sag slack multipliers (configurable; surfaced on the Audit sheet) ──
# These are BACK-CALCULATED to the approved MOA/MAM/LAW cable totals. NOTE: FOA 2025
# §9.10 + Corning field practice for AERIAL fibre is only ~5-10% (ADSS≈1.05, Mini≈1.08,
# Micro/UG≈1.10). The values below reproduce the approved bills; the Audit sheet shows
# route-metres vs ordered-metres + this factor so the buyer sees and can change it.
SLACK = {"adss": 1.30, "mini": 1.15, "micro": 1.12}
SLACK_FOA = {"adss": 1.05, "mini": 1.08, "micro": 1.10}   # research alternative (FOA/Corning)


def derive(project, slack_m=DEFAULT_SLACK_M):
    """Return (lines, diagnostics). Lines are ordered by _SECTION_ORDER."""
    rb = _load_rates()
    L = _layers(project)
    lines = []
    diag = {}

    def add(section, code, qty, **kw):
        if qty and qty > 0:
            lines.append(Line(section, code, qty, rb, **kw))

    # ── CABLE: aerial/underground by (subtyp, cblcpty) → FIB, Σ metres ──
    cable_layers = ["Primary Cable v1", "Secondary Cable v1", "Distribution Cable v1"]
    fib_tot = {}                              # code -> metres
    unmapped_cable = {}                       # 'subtyp|cap' -> count (no SKU → audit FAIL)
    for nm in cable_layers:
        lyr = L.get(nm)
        if not lyr:
            continue
        crs = lyr.crs()
        for f in lyr.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            sub = str(_attr(f, "subtyp") or "").lower()
            cap = _cap(_attr(f, "cblcpty"))
            table = _ADSS if "adss" in sub and "mini" not in sub else \
                    _MINI if "mini" in sub else \
                    _MICRO if "micro" in sub or "blown" in sub else _MINI
            code = table.get(cap)
            if not code:
                key = "%s|%s" % (sub or "?", cap or "?")
                unmapped_cable[key] = unmapped_cable.get(key, 0) + 1
                continue
            fib_tot[code] = fib_tot.get(code, 0.0) + _len_m(g, crs, project)
    # spool/sag slack factors (SLACK config; transparent — note shows route→ordered)
    _ADSS_S, _MINI_S, _MICRO_S = set(_ADSS.values()), set(_MINI.values()), set(_MICRO.values())
    for code, m in sorted(fib_tot.items()):
        sf = (SLACK["adss"] if code in _ADSS_S else SLACK["mini"] if code in _MINI_S
              else SLACK["micro"] if code in _MICRO_S else 1.0)
        add("Cable", code, round(m * sf), uom="Meter",
            note="route %dm x%.2f spool/sag slack" % (round(m), sf))
    underground_m = sum(m for code, m in fib_tot.items() if code in _MICRO_S)

    # ── CABLE: drops binned by length → DP-A (3,0mm) / PRE (2,8mm) ──
    drop_bins = {}                            # (sku_family, bin) -> count
    total_drop_m = 0.0                        # raw route metres, for install labour
    # Spare Drop EXCLUDED — all 3 approved bills count only the main drop layer
    # (= homes); spare-drop cables are not a BoQ drop line. (Verified MOA + MAM.)
    for nm in ("Drop Cable v1",):
        lyr = L.get(nm)
        if not lyr:
            continue
        crs = lyr.crs()
        for f in lyr.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            raw = _len_m(g, crs, project)
            total_drop_m += raw
            ln = raw + slack_m
            b = next((b for b in _DROP_BINS if ln <= b), _DROP_BINS[-1])  # round UP, cap 70
            dia = str(_attr(f, "dim1") or "3,0mm")
            fam = "PRE" if dia.startswith("2,8") else "DPA"   # by diameter [agent 1]
            drop_bins[(fam, b)] = drop_bins.get((fam, b), 0) + 1
    diag["drops_binned"] = sum(drop_bins.values())
    for (fam, b), c in sorted(drop_bins.items(), key=lambda x: x[0][1]):
        code = f"DP-A-1-LB-86/73-2-{b}" if fam == "DPA" else f"PRE0{b}FT"
        add("Cable", code, c, uom="Each",
            category="Drop Cable (Connectorised)",
            desc=f"Drop Cable.Connectorised.{'3,0mm' if fam=='DPA' else '2,8mm'}.1F.{b}m",
            supplier="Dartcom" if fam == "DPA" else "FTTX")

    # ── SPLITTERS: count by role (NB inverted ratio labels — map by count) ──
    n_sts = _count(L.get("STS Splitters v1"))           # 1:16 dome → SPL029
    n_fts = _count(L.get("FTS Splitters v1"))           # 1:8 dome  → SPL063
    add("Splitters", "SPL029", n_sts, note="STS (1:16 dome)")
    add("Splitters", "SPL063", n_fts, note="FTS (1:8 dome)")

    # ── DOME JOINTS: enclosures grouped by spec_1 string → SKU ──
    n_m16 = n_odcfd0 = 0
    for nm, table in (("Enclosures Connectorised v1", _ENCL_CONN),
                      ("Enclosures Splice v1", _ENCL_SPLICE)):
        lyr = L.get(nm)
        if not lyr:
            continue
        by = {}
        for f in lyr.getFeatures():
            spec = str(_attr(f, "spec_1") or "").upper()
            code = next((v for k, v in table.items() if k in spec), None)
            if code:
                by[code] = by.get(code, 0) + 1
                if "ODCFD0" in spec and "08L" not in spec:
                    n_odcfd0 += 1
                if "M16" in spec:
                    n_m16 += 1
        for code, c in sorted(by.items()):
            add("Dome Joints", code, c)

    # ── MIDCOUPLERS: 4*ODCFD0 + 8*M16  [agent 4 — matches LAW+MAM exactly] ──
    add("Midcouplers", "MID013", 4 * n_odcfd0 + 8 * n_m16,
        note="ESTIMATE (4xODCFD0+8xM16; ratio varies across approved bills — confirm)")

    # ── POLES + pole-mounted hardware: COUNT the populated attribute SLOTS
    #    (slot1 Pole·dim2 · slot2 Dead-End·subtyp · slot3 Tangent·dim1_3 ·
    #     slot4 Hook·spec_4 way · slot5 Slack · slot6 Strapping·featno5 ·
    #     slot7 Buckle·featno6) + 1 Label/pole. The Fibertime BoQ is the SUM of
    #    these slots, not a ratio (proven vs approved MOA + MAM). ──
    import re as _re
    poles = L.get("Poles v1")
    n_poles = _count(poles)
    band = {"120-140": 0, "140-160": 0}
    tangent = {}      # dim1_3 band -> count (for SUBTYPE proportions only)
    hook = {}         # way (int) -> count (spec_4, for WAY proportions only)
    slack = 0
    strap_u = buckle_u = 0
    deadend = {}      # subtyp -> count (for proportions only)
    # featnoN = per-pole COUNT of [1 dead-end, 2 tangent, 3 hook, 4 slack, 5 strap,
    # 6 buckle]. The approved bills tally these SUMS, not slot-presence (proven on
    # MOA/LAW/MAM: featno4==Slack & featno3==Hook & featno1==Dead-End exactly).
    fn1 = fn2 = fn3 = fn4 = 0
    if poles:
        for f in poles.getFeatures():
            d = str(_attr(f, "dim2") or "").strip()
            # Only band poles whose thickness is actually populated — otherwise an
            # unclassified pole (FT7 not yet run) would silently inflate 120-140.
            if d:
                band["140-160" if "140-160" in d else "120-140"] += 1
            else:
                diag["poles_unclassified"] = diag.get("poles_unclassified", 0) + 1
            if str(_attr(f, "type_3") or "").lower().startswith("tangent"):
                k = str(_attr(f, "dim1_3") or "?")
                tangent[k] = tangent.get(k, 0) + 1
            if str(_attr(f, "type_4") or "").lower().startswith("hook"):
                m = _re.match(r"(\d+)", str(_attr(f, "spec_4") or ""))
                w = int(m.group(1)) if m else 0
                hook[w] = hook.get(w, 0) + 1
            if str(_attr(f, "type_5") or "").lower().startswith("slack"):
                slack += 1
            fn1 += _inum(_attr(f, "featno1")); fn2 += _inum(_attr(f, "featno2"))
            fn3 += _inum(_attr(f, "featno3")); fn4 += _inum(_attr(f, "featno4"))
            strap_u += _inum(_attr(f, "featno5"))
            buckle_u += _inum(_attr(f, "featno6"))
            s2 = _attr(f, "subtype_2") or _attr(f, "subtyp_2")
            if s2 and str(_attr(f, "type_2") or "").lower().startswith("dead"):
                deadend[str(s2)] = deadend.get(str(s2), 0) + 1
    for k, (code, desc, rate) in _POLE.items():
        add("Poles", code, band[k], uom="Each", desc=desc, rate=rate,
            supplier="LCTT", category="Poles (Creosote)")
    # Dead-Ends = Σ featno1 (best-available basis: EXACT in LAW, but MOA & MAM bills
    # diverge from featno1 — flagged ESTIMATE, no consistent rule across approved bills).
    for st, c in _distribute(fn1 or sum(deadend.values()), deadend or {"Mini-ADSS": 1}).items():
        add("Dead-Ends", "DEA030", c, rate=24.55, category="Dead-End(Mini-ADSS)",
            desc=f"Dead-End.{st}", note="ESTIMATE: Σ featno1 (varies vs approved bills — confirm)")
    # Tangents = Σ featno2 (ESTIMATE — MOA bill 478 != featno2 681; LAW/MAM have none).
    for bnd, c in _distribute(fn2 or sum(tangent.values()), tangent or {}).items():
        add("Tangents", "TAN006", c, rate=99.78, category="Tangent (ADSS)",
            desc=f"Tangent.ADSS.{bnd}", note="ESTIMATE: Σ featno2 (varies vs approved bills — confirm)")
    # Hooks = Σ featno3, split by spec_4 way proportion, then >3-way decomposed to
    # 1-3-way brackets (4=2+2, 5=3+2, 6=3+3 — way-capacity conserved).
    _HOOKSKU = {1: ("BRA063", 37.91), 2: ("BRA123", 44.49), 3: ("BRA064", 55.73)}
    hook_by_way = _distribute(fn3 or sum(hook.values()), hook) if (hook or fn3) else {}
    hook_decomp = {}
    for w, c in hook_by_way.items():
        for part in _decompose_way(w):
            hook_decomp[part] = hook_decomp.get(part, 0) + c
    n_gt3 = sum(c for w, c in hook_by_way.items() if w > 3)
    for w, c in sorted(hook_decomp.items()):
        code, rate = _HOOKSKU[w]
        add("Hooks", code, c, rate=rate, category="Hook (Monopole Bracket Offset)",
            desc=f"Hook.Monopole Bracket Offset.{w}-Way",
            note="Σ featno3; %d-way" % w + (" (incl. split from >3-way)" if w <= 3 and n_gt3 else ""))
    # Slack brackets = Σ featno4.
    slack_total = fn4 or slack
    if slack_total:
        add("Slack Brackets", "SLA013", slack_total, note="Σ featno4 (per-pole slack count)")
    # Strapping (Σ featno5 units → 30 m rolls) + Buckles (Σ featno6 → box of 100)
    if strap_u:
        add("Strapping, Buckles & Coach Screws", "BAN002",
            math.ceil(strap_u / 30.0),
            note=f"ESTIMATE: {strap_u} featno5 units / 30 m roll (roll factor varies by project)")
    if buckle_u:
        add("Strapping, Buckles & Coach Screws", "BAN003",
            math.ceil(buckle_u / 100.0),
            note=f"ESTIMATE: {buckle_u} featno6 units / box of 100 (box factor varies by project)")
    # Labels — 1 Chromadek nameplate per pole
    if n_poles:
        add("Labels", "SIG008", n_poles, rate=82.45, category="Label (Chromadek)",
            desc="Label.Chromadek.Pole nameplate", note="1 per pole")

    # ── SPLICING: protector + consumables from a splice estimate ──
    #   splices ≈ 1*(connectorised splitters) + 12*M16 + 212  [agent 4 LAW closed-form]
    splices = (n_sts + n_fts) + 12 * n_m16 + 212
    diag["splice_estimate"] = splices
    add("Splicing", "SPL076", splices,
        note="ESTIMATE — not consistently design-derived across bills; splice-plan is authoritative")
    add("Splicing", "ALC001", math.ceil(splices / 350), note="ESTIMATE (bulk consumable)")
    add("Splicing", "KIM001", math.ceil(splices / 280), note="ESTIMATE (bulk consumable)")

    # ── HOME CONNECTIONS: the per-home install kit, matched line-for-line to the
    #    approved MOA BoQ (14 SKUs @ 1/home). Priced SKUs come from the rate book;
    #    the codeless ones (Free Supply / quote-on-request / R3) are spelled out. ──
    n_ont = _count(L.get("ONT v1"))
    diag["ont"] = n_ont
    for code in ("ONT001", "PLU024", "EXT003", "TIE016", "TIE001", "CLI023"):
        add("Home Connections", code, n_ont)
    add("Home Connections", "PLU021", n_ont, category="Electrical")
    add("Home Connections", "PIG029", n_ont, category="Wall Attchment")
    # codeless install-kit SKUs present in the approved BoQ but previously omitted
    # (code, desc, category, uom, rate, supplier). rate None = quote-on-request (TBD).
    for code, desc, cat, uom, rate, sup in (
            ("WALL-BRKT", "Wall Attachment.ONT Bracket.1 per Home", "Wall Attachment", "Each", 0.0, "Fiber Time"),
            ("WALL-SADL", "Wall Attachment.Saddles.15 per Home", "Wall Attachment", "Each", None, "FTTX"),
            ("SCR-FH", "Screw.Flathead self tapping screws", "Screw", "Pair", None, "FTTX"),
            ("SCR-ST", "Screw.Self Tapping Screws.2 per Home", "Screw", "Pair", None, "FTTX"),
            ("LBL-ONT", "Label.ONT Sticker.1 per Home", "Label", "Each", 0.0, "Fiber Time"),
            ("ELE-GLAND", "Electrical.Entry Gland.1 per Home", "Electrical", "Each", 3.0, "FTTX")):
        add("Home Connections", code, n_ont, desc=desc, category=cat, uom=uom, rate=rate, supplier=sup)
    add("Home Connections", "WAY122", round(n_ont * 0.10, 1), uom="Meter",
        note="0.10 m/home (per description)")

    # ── LABOUR (ESTIMATE — separate subtotal, confirm with contractor) ──
    add(_LABOUR_SECTION, "LAB-DROP", round(total_drop_m), uom="Meter",
        rate=LABOUR_DROP_INSTALL_PER_M, supplier="Contractor",
        category="Drop Cable Installation",
        desc="Labour.Drop install (last-mile to home)",
        note="ESTIMATE R50-60/m — confirm with contractor")
    add(_LABOUR_SECTION, "LAB-TRENCH", round(underground_m), uom="Meter",
        rate=LABOUR_TRENCH_PER_M, supplier="Contractor",
        category="Trenching (Underground)",
        desc="Labour.Trenching for underground/micro-duct",
        note="ESTIMATE R100-500/m by soil — confirm with contractor")
    diag["labour_drop_m"] = round(total_drop_m)
    diag["labour_trench_m"] = round(underground_m)

    # ── stash the DIRECT take-off so audit() can reconcile every line to the
    #    design without re-reading the layers (each value is a raw count/sum). ──
    diag["direct"] = {
        "poles": n_poles, "bands": dict(band),
        "deadend": fn1 or sum(deadend.values()), "tangent": fn2 or sum(tangent.values()),
        "hook": fn3 or sum(hook.values()), "slack": slack_total,
        "hook_waycap": sum(w * c for w, c in hook_by_way.items()),
        "hook_brackets": sum(hook_decomp.values()),
        "strap_units": strap_u, "buckle_units": buckle_u,
        "sts": n_sts, "fts": n_fts, "ont": n_ont,
        "drop": _count(L.get("Drop Cable v1")),
        "spare": _count(L.get("Spare Drop Cable v1")),
        "encl_conn": _count(L.get("Enclosures Connectorised v1")),
        "encl_splice": _count(L.get("Enclosures Splice v1")),
        "cable_m": {k: round(v) for k, v in fib_tot.items()},
    }
    diag["unmapped_cable"] = dict(unmapped_cable)

    # order by section
    lines.sort(key=lambda x: (_SECTION_ORDER.index(x.section)
                              if x.section in _SECTION_ORDER else 99))
    diag["poles"] = n_poles
    diag["lines"] = len(lines)
    return lines, diag


def audit(project, lines, diag):
    """Reconcile the BoQ against the DIRECT design take-off + run validation rules.
    Returns {rows, findings, verdict}. rows = (check, design, in_boq, status, note);
    additive only — never changes a quantity. verdict OK / REVIEW / FAIL."""
    from collections import Counter
    L = _layers(project)
    d = diag.get("direct", {})
    rows = []
    findings = []

    def bsum(pred):
        return sum(l.qty for l in lines if pred(l))

    def rec(check, design, in_boq, note=""):
        status = "OK" if round(design) == round(in_boq) else "CHECK"
        rows.append((check, design, in_boq, status, note))
        if status != "OK":
            findings.append(("WARN", "%s: design %s vs BoQ %s" % (check, design, in_boq)))

    # ── tie-outs: every take-off line must equal the design ──
    rec("Poles", d.get("poles", 0), bsum(lambda l: l.section == "Poles"), "1 pole / feature")
    rec("Dead-Ends", d.get("deadend", 0), bsum(lambda l: l.section == "Dead-Ends"), "slot2 tally")
    rec("Tangents", d.get("tangent", 0), bsum(lambda l: l.section == "Tangents"), "slot3 tally")
    # hooks decompose >3-way → 1-3-way brackets; reconcile the CONSERVED way-capacity
    _WAY = {"BRA063": 1, "BRA123": 2, "BRA064": 3}
    boq_waycap = sum(_WAY.get(l.code, 0) * l.qty for l in lines if l.section == "Hooks")
    rec("Hook way-capacity", d.get("hook_waycap", 0), boq_waycap, "Σ way×qty (conserved)")
    rows.append(("Hook brackets (≤3-way)", d.get("hook", 0), d.get("hook_brackets", 0),
                 "INFO", "%d pole-hooks → %d brackets after splitting >3-way"
                 % (d.get("hook", 0), d.get("hook_brackets", 0))))
    rec("Slack Brackets", d.get("slack", 0), bsum(lambda l: l.section == "Slack Brackets"), "slot5 tally")
    rec("Splitters STS", d.get("sts", 0), bsum(lambda l: l.code == "SPL029"), "1:16 dome")
    rec("Splitters FTS", d.get("fts", 0), bsum(lambda l: l.code == "SPL063"), "1:8 dome")
    rec("Enclosures Conn", d.get("encl_conn", 0),
        bsum(lambda l: l.section == "Dome Joints" and str(l.code).startswith("BOX")), "spec→SKU")
    rec("Enclosures Splice", d.get("encl_splice", 0),
        bsum(lambda l: l.section == "Dome Joints" and str(l.code).startswith("JOI")), "spec→SKU")
    rec("Drops (main, no spare)", d.get("drop", 0),
        bsum(lambda l: l.category == "Drop Cable (Connectorised)"),
        "Drop Cable layer only; %d spare excluded" % d.get("spare", 0))
    rec("Home kit (per home)", d.get("ont", 0), bsum(lambda l: l.code == "ONT001"), "1 kit / ONT")

    # ── strapping/buckle: unit→pack conversion, NOT a 1:1 tie-out (info) ──
    rows.append(("Strapping units→rolls", d.get("strap_units", 0),
                 bsum(lambda l: l.code == "BAN002"), "INFO", "%d units / 30 m roll" % d.get("strap_units", 0)))
    rows.append(("Buckle units→boxes", d.get("buckle_units", 0),
                 bsum(lambda l: l.code == "BAN003"), "INFO", "%d units / box of 100" % d.get("buckle_units", 0)))

    # ── cable: route metres (design truth) → ordered metres (with slack) ──
    for code, route in sorted(d.get("cable_m", {}).items()):
        ordered = bsum(lambda ll, c=code: ll.code == c and ll.section == "Cable")
        sf = (ordered / route) if route else 0.0
        rows.append(("Cable %s" % code, route, ordered, "INFO",
                     "route m → ordered m (×%.2f slack)" % sf))

    # ── validation rules ──
    ont = d.get("ont", 0); drop = d.get("drop", 0)
    if ont:
        pct = abs(drop - ont) / ont * 100.0
        sev = "OK" if pct <= 5 else ("WARN" if pct <= 15 else "FAIL")
        rows.append(("Drop ≈ ONT (±5%)", ont, drop, sev, "%.1f%% diff" % pct))
        if sev == "FAIL":
            findings.append(("FAIL", "drops %d vs homes %d (%.0f%%)" % (drop, ont, pct)))
    sts = d.get("sts", 0); fts = d.get("fts", 0)
    ratio = (sts / fts) if fts else 0
    rows.append(("FTS×8 ≥ STS", fts * 8, sts, "OK" if fts * 8 >= sts else "WARN",
                 "design %.1f STS/FTS vs 1:8 combo — verify splitter design" % ratio))
    rows.append(("STS×16 ≥ drops", sts * 16, drop, "OK" if sts * 16 >= drop else "WARN",
                 "1:16 capacity; spare=%d" % (sts * 16 - drop)))
    cm = d.get("cable_m", {})
    tot_cm = sum(cm.values())
    rows.append(("Cable metres > 0", "yes", "yes" if tot_cm > 0 else "no",
                 "OK" if tot_cm > 0 else "FAIL", "%d m via QgsDistanceArea (UTM)" % tot_cm))
    if tot_cm <= 0:
        findings.append(("FAIL", "no cable metres measured"))
    un = diag.get("unmapped_cable", {})
    if un:
        rows.append(("Unmapped cable SKU", 0, sum(un.values()), "FAIL", "; ".join(un.keys())))
        findings.append(("FAIL", "unmapped cable (subtyp|cap): " + ", ".join("%s×%d" % (k, v) for k, v in un.items())))
    nulls = 0
    for nm in ("Poles v1", "Drop Cable v1", "Distribution Cable v1",
               "Enclosures Connectorised v1", "ONT v1"):
        lyr = L.get(nm)
        if not lyr:
            continue
        for f in lyr.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                nulls += 1
    rows.append(("Null geometries", 0, nulls, "OK" if nulls == 0 else "FAIL", "key layers"))
    if nulls:
        findings.append(("FAIL", "%d null geometries" % nulls))
    dups = 0
    for nm, fld in (("Enclosures Connectorised v1", "label_1"),
                    ("Enclosures Splice v1", "label_1"), ("Poles v1", "label")):
        lyr = L.get(nm)
        if not lyr:
            continue
        labs = [str(_attr(f, fld)) for f in lyr.getFeatures() if _attr(f, fld) is not None]
        dups += sum(c - 1 for c in Counter(labs).values() if c > 1)
    rows.append(("Duplicate labels", 0, dups, "OK" if dups == 0 else "WARN", "enclosures + poles"))
    if dups:
        findings.append(("WARN", "%d duplicate labels" % dups))
    tbd = [l.code for l in lines if l.rate is None]
    if tbd:
        rows.append(("Provisional (rate TBD)", len(tbd), len(tbd), "INFO", ", ".join(tbd[:8])))
    findings.append(("INFO", "Cable slack applied: ADSS ×%.2f / Mini ×%.2f / Micro ×%.2f "
                     "(back-calc to approved bills; FOA/Corning field practice is ×%.2f/×%.2f/×%.2f). "
                     "Drop length slack +%dm. Edit SLACK in fibertime_mml.py to change."
                     % (SLACK["adss"], SLACK["mini"], SLACK["micro"],
                        SLACK_FOA["adss"], SLACK_FOA["mini"], SLACK_FOA["micro"], int(DEFAULT_SLACK_M))))

    verdict = ("FAIL" if any(f[0] == "FAIL" for f in findings)
               else "REVIEW" if (any(f[0] == "WARN" for f in findings)
                                  or any(r[3] in ("CHECK", "WARN") for r in rows))
               else "OK")
    return {"rows": rows, "findings": findings, "verdict": verdict}


# Reference drawings + example screenshots for the Questions & Notes sheet.
# (Staged by research/ tooling; hyperlinks only added when a file actually exists.)
REF_DIR = r"C:/Users/jjsch/OneDrive/ON LAPTOP FIBRE/QGIS test/BoQ_References"


def build_notes(project, diag, audit_data):
    """Build the 'Questions & Notes for Fibertime' rows from the live design +
    audit. Each note: (topic, question, our_data, reference, example_file). Pure
    read — never changes the project. Returns [] if anything is unavailable."""
    import os
    import re as _re
    notes = []
    d = (diag or {}).get("direct", {})
    try:
        L = _layers(project)
        poles = L.get("Poles v1")
        hook_ways = {}
        if poles:
            for f in poles.getFeatures():
                if str(_attr(f, "type_4") or "").lower().startswith("hook"):
                    m = _re.match(r"(\d+)", str(_attr(f, "spec_4") or ""))
                    w = int(m.group(1)) if m else 0
                    hook_ways[w] = hook_ways.get(w, 0) + 1
        big = {w: c for w, c in hook_ways.items() if w > 3}
        ways_str = " · ".join("%d-way ×%d" % (w, c) for w, c in sorted(hook_ways.items()))
        if big:
            notes.append((
                "Hook ways > 3 (RESOLVED — confirm)",
                "Every approved bill lists only 1/2/3-way hooks. Our raw design had %s. "
                "APPROACH APPLIED: we split >3-way into 2+3 brackets (4=2+2, 5=3+2, 6=3+3) "
                "— way-capacity conserved. Please confirm Fibertime accepts this (each split "
                "bracket strapped & stacked underneath the other)."
                % ", ".join("%d-way ×%d" % (w, c) for w, c in sorted(big.items())),
                "Raw: " + ways_str, "Std drawing: hooks strapped individually & stacked",
                os.path.join(REF_DIR, "example_6way.png")))
        notes.append((
            "Strapping & buckles",
            "Confirm the make-up: strap size (drawings show 12.7mm StrapWithBuckle / "
            "19mm banded), metres of strap per attachment, and buckles per attachment. "
            "We carry %s strap units & %s buckle units (→ 30m rolls / box of 100)."
            % (d.get("strap_units", "?"), d.get("buckle_units", "?")),
            "Strapping %s units · Buckles %s units" % (d.get("strap_units", "?"), d.get("buckle_units", "?")),
            "ref_pole_mounting_detail.png (12.7mm Strap+Buckle, 6×50 Coach Screw)",
            os.path.join(REF_DIR, "ref_pole_mounting_detail.png")))
        notes.append((
            "Coach screws / Dome bracket / Hose clamp",
            "Drawings show 6×50mm Coach Screws, a Dome Bracket and a 12mm Hose Clamp per "
            "mount. Should these be separate BoQ lines (qty per pole), or are they bundled "
            "into the hook/strapping SKUs? They are not itemised yet.",
            "Not currently itemised", "ref_pole_mounting_detail.png",
            os.path.join(REF_DIR, "ref_pole_mounting_detail.png")))
        sts = d.get("sts", 0); fts = d.get("fts", 0)
        notes.append((
            "Splitter ratio",
            "Design has %d STS per FTS (%d STS / %d FTS) vs the 1:8 combo. Confirm this is "
            "intended (distributed/under-loaded splitters) or whether some STS are mis-roled."
            % (round(sts / fts, 1) if fts else 0, sts, fts),
            "%d STS · %d FTS" % (sts, fts), "Combo 1 = 1×1:8 FTS + 8×1:16 STS",
            os.path.join(REF_DIR, "ref_pole_mounting_multi_hook.png")))
        notes.append((
            "Cable slack %",
            "We apply ADSS ×%.2f / Mini ×%.2f (back-calculated to your approved bills). "
            "FOA/Corning field practice is only ×%.2f / ×%.2f. What spool/sag/service-loop "
            "allowance does Fibertime expect on aerial cable?"
            % (SLACK["adss"], SLACK["mini"], SLACK_FOA["adss"], SLACK_FOA["mini"]),
            "ADSS ×%.2f · Mini ×%.2f" % (SLACK["adss"], SLACK["mini"]),
            "FOA 2025 §9.10 / Corning ADSS SOP 005-038", ""))
        notes.append((
            "Quote-only items",
            "These approved-bill items are 'quote on request' (no price): Saddles, "
            "Flathead & Self-tapping Screws. Need unit prices from Fibertime/supplier.",
            "WALL-SADL, SCR-FH, SCR-ST", "Approved MOA bill (rate column blank)", ""))
        notes.append((
            "Drop spares",
            "Our bill counts %d drop + %d spare-drop cables; the approved bills count ~1 "
            "drop/home. Should spare drops be a separate BoQ line or excluded?"
            % (d.get("drop", 0), d.get("spare", 0)),
            "%d drop + %d spare" % (d.get("drop", 0), d.get("spare", 0)),
            "Approved bills = 1 drop/home", ""))
        notes.append((
            "Aerial scope (underground omitted)",
            "This is an AERIAL build, so the underground/civils categories present in the "
            "reference bills are intentionally EXCLUDED: Manhole + Manhole Key, Conduit "
            "(HDPE/Corr), Micro Duct + End Cap, Underground Cable (Micro-Blown), Cement, "
            "Caution Tape. Confirm there are no trenched/road-crossing sections needing these.",
            "0 underground civils (aerial)", "Ref bills had trenched sections", ""))
        notes.append((
            "Midcoupler type",
            "We use Flangeless (MID013) — matches the MOA approved bill. LAW & MAM use "
            "Flanged midcouplers. Confirm Flangeless is correct for this project.",
            "Flangeless (MID013)", "MOA=Flangeless · LAW/MAM=Flanged", ""))
    except Exception:
        pass
    return notes


# ── Excel writer — exact Fibertime "Master Material List" format [agent 5] ──
def write_mml(lines, path, project_name="Velocity Nexus", audit_data=None, notes=None):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    CYAN = PatternFill("solid", fgColor="01D9F2")
    YELLOW = PatternFill("solid", fgColor="FCE639")
    BANNER = PatternFill("solid", fgColor="FFFF99")
    WHITE = PatternFill("solid", fgColor="FFFFFF")
    F_TITLE = Font(name="Aptos Narrow", size=14, bold=True)
    F_HDR = Font(name="Aptos Narrow", size=12, bold=True)
    F_BODY = Font(name="Aptos Narrow", size=11)
    F_SUB = Font(name="Aptos Narrow", size=11, bold=True)
    CENTER = Alignment(horizontal="center")
    RATE_FMT, COST_FMT = r"\R#,##0.00", '"R"#,##0.00'
    HEADERS = ["Item No", "UoM", "Item Category", "Description", "Quantity",
               "Item Code", "Item Rate", "Supplier", "Lead Time", "Total Item Cost"]

    wb = Workbook()
    ws = wb.active
    ws.title = "Master Material List"
    ws.merge_cells("A1:J1")
    t = ws["A1"]; t.value = "MASTER MATERIAL LIST - FIBERTIME"
    t.font = F_TITLE; t.fill = CYAN; t.alignment = CENTER
    ws.row_dimensions[1].height = 18.5
    for i, h in enumerate(HEADERS, 1):
        c = ws.cell(row=2, column=i, value=h); c.font = F_HDR; c.fill = YELLOW; c.alignment = CENTER

    r = 3
    item_no = 0
    labour_banner_row = None                  # first row of the Labour section, if any
    from itertools import groupby
    for section in _SECTION_ORDER:
        # order categories within the section by the canonical reference sequence
        seclines = sorted([l for l in lines if l.section == section],
                          key=lambda x: _cat_sort_key(x.category))
        if not seclines:
            continue
        if section == _LABOUR_SECTION:
            labour_banner_row = r
        ws.merge_cells(f"A{r}:J{r}")
        b = ws.cell(row=r, column=1, value=section); b.font = F_BODY; b.fill = BANNER; b.alignment = CENTER
        r += 1
        # group by category as a sub-header
        for cat, grp in groupby(seclines, key=lambda x: x.category):
            grp = list(grp)
            sc = ws.cell(row=r, column=4, value=cat); sc.font = F_SUB; sc.alignment = CENTER
            r += 1
            for l in grp:
                item_no += 1
                ws.cell(row=r, column=1, value=item_no).font = F_BODY
                ws.cell(row=r, column=2, value=l.uom).font = F_BODY
                ws.cell(row=r, column=3, value=l.category).font = F_BODY
                ws.cell(row=r, column=4, value=l.desc).font = F_BODY
                ws.cell(row=r, column=5, value=l.qty).font = F_BODY
                ws.cell(row=r, column=6, value=l.code).font = F_BODY
                rc = ws.cell(row=r, column=7, value=l.rate)
                rc.font = F_BODY; rc.number_format = RATE_FMT; rc.fill = WHITE
                ws.cell(row=r, column=8, value=l.supplier).font = F_BODY
                ws.cell(row=r, column=9, value=l.note).font = F_BODY
                tc = ws.cell(row=r, column=10, value=f"=SUM(G{r}*E{r})")
                tc.font = F_BODY; tc.number_format = COST_FMT
                for col in (1, 2, 5, 6, 7, 8, 10):
                    ws.cell(row=r, column=col).alignment = CENTER
                r += 1
    # totals (MAM-style). Labour is kept in its OWN subtotal so it never inflates
    # the firm material cost; Total Project Cost = material + labour (estimate).
    BOLD = Font(name="Aptos Narrow", size=11, bold=True)
    last = r - 1

    def _total(row, label, formula, fill):
        lc = ws.cell(row=row, column=6, value=label); lc.font = BOLD; lc.fill = fill
        # value goes in column J (Total Item Cost), the column it sums.
        vc = ws.cell(row=row, column=10, value=formula); vc.font = BOLD; vc.fill = fill
        vc.number_format = COST_FMT

    if labour_banner_row:
        mat_last = labour_banner_row - 1
        _total(r + 1, "Total Material Cost", f"=SUM(J3:J{mat_last})", CYAN)
        _total(r + 2, "Total Labour Cost (estimate)",
               f"=SUM(J{labour_banner_row}:J{last})", YELLOW)
        _total(r + 3, "Total Project Cost (incl. labour est.)",
               f"=SUM(J3:J{last})", CYAN)
    else:
        _total(r + 1, "Total Material Cost", f"=SUM(J3:J{last})", CYAN)

    widths = {1: 9, 2: 9, 3: 34, 4: 60, 5: 12, 6: 28, 7: 14, 8: 12, 9: 26, 10: 18}
    for col, w in widths.items():
        ws.column_dimensions[chr(64 + col)].width = w

    # Validations sheet (pole lead-times + rates) [agent 5]
    vs = wb.create_sheet("Validations")
    vs["B2"] = "Lists"; vs["B2"].fill = CYAN
    vs["B3"] = "Pole Lead Times"; vs["B3"].fill = YELLOW
    for i, region in enumerate(("Immediate (Gauteng)", "Immediate (Port Elizabeth)",
                                "Immediate (Western Cape)"), 4):
        vs.cell(row=i, column=2, value=region)

    # ── Audit & Reconciliation sheet: proves every line ties to the design ──
    if audit_data:
        GREEN = PatternFill("solid", fgColor="C6EFCE")
        AMBER = PatternFill("solid", fgColor="FFEB9C")
        RED = PatternFill("solid", fgColor="FFC7CE")
        GREY = PatternFill("solid", fgColor="E0E0E0")
        SFILL = {"OK": GREEN, "CHECK": AMBER, "WARN": AMBER, "FAIL": RED, "INFO": GREY}
        a = wb.create_sheet("Audit & Reconciliation")
        a.merge_cells("A1:E1")
        verdict = audit_data.get("verdict", "OK")
        h = a["A1"]; h.value = "BoQ AUDIT — verdict: %s" % verdict
        h.font = F_TITLE; h.alignment = CENTER
        h.fill = {"OK": GREEN, "REVIEW": AMBER, "FAIL": RED}.get(verdict, CYAN)
        a["A2"] = ("Each row reconciles a BoQ quantity to the DIRECT take-off from the "
                   "design, or runs a validation rule. OK=ties exactly · CHECK/WARN=review "
                   "· FAIL=blocks trust · INFO=unit conversion / note.")
        a["A2"].font = F_BODY
        for j, hh in enumerate(("Check", "Design (take-off)", "In BoQ", "Status", "Note"), 1):
            c = a.cell(row=4, column=j, value=hh); c.font = F_HDR; c.fill = YELLOW
        rr = 5
        for check, design, in_boq, status, note in audit_data.get("rows", []):
            a.cell(row=rr, column=1, value=check).font = F_BODY
            a.cell(row=rr, column=2, value=design).font = F_BODY
            a.cell(row=rr, column=3, value=in_boq).font = F_BODY
            sc = a.cell(row=rr, column=4, value=status)
            sc.font = F_SUB; sc.fill = SFILL.get(status, WHITE); sc.alignment = CENTER
            a.cell(row=rr, column=5, value=note).font = F_BODY
            rr += 1
        findings = audit_data.get("findings", [])
        if findings:
            rr += 1
            fh = a.cell(row=rr, column=1, value="FINDINGS"); fh.font = F_HDR; fh.fill = YELLOW
            rr += 1
            for sev, msg in findings:
                fc = a.cell(row=rr, column=1, value=sev); fc.font = F_SUB
                fc.fill = RED if sev == "FAIL" else AMBER
                a.merge_cells(start_row=rr, start_column=2, end_row=rr, end_column=5)
                a.cell(row=rr, column=2, value=msg).font = F_BODY
                rr += 1
        for col, w in {1: 26, 2: 18, 3: 14, 4: 10, 5: 46}.items():
            a.column_dimensions[chr(64 + col)].width = w

    # ── Questions & Notes for Fibertime: open spec questions + click-through examples ──
    if notes:
        import os
        q = wb.create_sheet("Questions & Notes")
        q.merge_cells("A1:E1")
        h = q["A1"]; h.value = "QUESTIONS & NOTES FOR FIBERTIME"
        h.font = F_TITLE; h.fill = CYAN; h.alignment = CENTER
        q["A2"] = ("Open specification questions raised by the design data + reference standards. "
                   "Click an 'Example' link to open the drawing / a screenshot of a real pole.")
        q["A2"].font = F_BODY
        for j, hh in enumerate(("#", "Topic", "Question", "Our data", "Example (click)"), 1):
            c = q.cell(row=4, column=j, value=hh); c.font = F_HDR; c.fill = YELLOW; c.alignment = CENTER
        rr = 5
        for i, (topic, question, ourdata, reference, example) in enumerate(notes, 1):
            q.cell(row=rr, column=1, value=i).font = F_BODY
            q.cell(row=rr, column=2, value=topic).font = F_SUB
            qc = q.cell(row=rr, column=3, value=question); qc.font = F_BODY
            qc.alignment = Alignment(wrap_text=True, vertical="top")
            q.cell(row=rr, column=4, value=ourdata).font = F_BODY
            ec = q.cell(row=rr, column=5)
            if example and os.path.exists(example):
                ec.value = "Open example"; ec.hyperlink = "file:///" + example.replace("\\", "/")
                ec.font = Font(name="Aptos Narrow", size=11, color="0563C1", underline="single")
            else:
                ec.value = reference or "—"; ec.font = F_BODY
            ec.alignment = Alignment(wrap_text=True, vertical="top")
            q.row_dimensions[rr].height = 58
            rr += 1
        # reference library links
        rr += 1
        q.cell(row=rr, column=1, value="REFERENCE LIBRARY").font = F_HDR
        q.cell(row=rr, column=1).fill = YELLOW
        rr += 1
        for label, fn in (("Pole mounting — multi-hook (StrapWithBuckle, Dome Bracket)", "ref_pole_mounting_multi_hook.png"),
                          ("Pole mounting — detail (12.7mm strap, 6×50 coach screw, hose clamp)", "ref_pole_mounting_detail.png"),
                          ("Aerial deployment standard (reference PDF)", "ref_aerial_deployment_standard.pdf"),
                          ("Example pole — 4-way hook (MOA.P.F418)", "example_4way.png"),
                          ("Example pole — 5-way hook (MOA.P.F419)", "example_5way.png"),
                          ("Example pole — 6-way hook (MOA.P.F481)", "example_6way.png")):
            p2 = os.path.join(REF_DIR, fn)
            cc = q.cell(row=rr, column=2, value=label)
            if os.path.exists(p2):
                cc.value = label; cc.hyperlink = "file:///" + p2.replace("\\", "/")
                cc.font = Font(name="Aptos Narrow", size=11, color="0563C1", underline="single")
            else:
                cc.font = F_BODY
            rr += 1
        for col, w in {1: 5, 2: 40, 3: 70, 4: 22, 5: 26}.items():
            q.column_dimensions[chr(64 + col)].width = w

    # atomic save
    _dir = os.path.dirname(path) or "."
    import tempfile
    fd, tmp = tempfile.mkstemp(suffix=".xlsx", dir=_dir); os.close(fd)
    try:
        wb.save(tmp); os.replace(tmp, path)
    except PermissionError:
        try: os.remove(tmp)
        except Exception: pass
        raise RuntimeError(f"Cannot write — close '{os.path.basename(path)}' in Excel and retry.")
    return path


def run_fibertime_boq(out_path=None, project=None, slack_m=DEFAULT_SLACK_M):
    from qgis.core import QgsProject
    project = project or QgsProject.instance()
    out_path = out_path or os.path.join(
        os.path.expanduser("~"), (project.baseName() or "Project") + "_Fibertime_BoQ.xlsx")
    lines, diag = derive(project, slack_m=slack_m)
    audit_data = audit(project, lines, diag)
    notes = build_notes(project, diag, audit_data)
    write_mml(lines, out_path, project.baseName() or "Velocity Nexus",
              audit_data=audit_data, notes=notes)
    return {"path": out_path, "lines": len(lines), "diag": diag,
            "verdict": audit_data["verdict"], "findings": audit_data["findings"],
            "questions": len(notes)}
