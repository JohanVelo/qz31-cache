# -*- coding: utf-8 -*-
# Build the HLD map-book layouts INSIDE the live QGIS project so JJ can tweak them
# by hand in the Print Layout designer and export the PDF himself (his usual way of
# getting a nice PDF). This is the interactive counterpart to the headless one-shot
# generator (hld_generate.py) — same engine, same config, but run on the GUI thread
# against QgsProject.instance() and then the designer is opened.
#
# SAFE on the GUI thread: the engine only *builds* layout items (fast) and freezes
# the canvas while it does; the heavy N-page render happens later, when JJ hits
# Export in the designer — never here.
import copy
import os
import tempfile
import traceback


def _layer_source_path(layer):
    try:
        return os.path.normpath(layer.source().split("|")[0])
    except Exception:
        return ""


def _add_missing_extras(project, extra_layers):
    """Load framing helpers (e.g. the greenfield boundary) if not already present,
    mirroring the headless generator so the overview frames identically."""
    from qgis.core import QgsVectorLayer, QgsFillSymbol
    have = {_layer_source_path(l) for l in project.mapLayers().values()
            if isinstance(l, QgsVectorLayer)}
    for el in (extra_layers or []):
        src = el.get("path")
        if not src or not os.path.exists(src):
            continue
        if os.path.normpath(src) in have:
            continue
        vl = QgsVectorLayer(src, el.get("name", os.path.basename(src)), "ogr")
        if not vl.isValid():
            continue
        if el.get("fill"):
            try:
                vl.renderer().setSymbol(QgsFillSymbol.createSimple(el["fill"]))
            except Exception:
                pass
        project.addMapLayer(vl, el.get("add_to_tree", True))


def _downloads_dir():
    d = os.path.join(os.path.expanduser("~"), "Downloads")
    return d if os.path.isdir(d) else os.path.expanduser("~")


def _relock_frame(layout):
    """QGIS4's atlas preview / page-flip grows the map-frame ITEM to the current feature's
    aspect; force every map item back to its engine-designed page geometry (stashed as custom
    properties). Called right before export so exported pages never clip — this also makes the
    headless export path safe (the old one-shot clipped precisely because it never relocked)."""
    from qgis.core import QgsLayoutItemMap, QgsLayoutPoint, QgsLayoutSize, QgsUnitTypes
    MM = QgsUnitTypes.LayoutUnit.LayoutMillimeters
    for it in layout.items():
        if isinstance(it, QgsLayoutItemMap):
            w = it.customProperty("hld_frame_w"); h = it.customProperty("hld_frame_h")
            x = it.customProperty("hld_frame_x"); y = it.customProperty("hld_frame_y")
            if w and h:
                if x is not None and y is not None:
                    it.attemptMove(QgsLayoutPoint(float(x), float(y), MM))
                it.attemptResize(QgsLayoutSize(float(w), float(h), MM))


def _safe_unlink(pth):
    try:
        if pth and os.path.exists(pth):
            os.remove(pth)
    except Exception:
        pass


def _count_pdf_pages(pdf_path):
    """Best-effort PDF page count from the file bytes (no Ghostscript dependency). -1 on error."""
    import re
    try:
        with open(pdf_path, "rb") as f:
            data = f.read()
    except Exception:
        return -1
    counts = [int(m) for m in re.findall(rb"/Type\s*/Pages\b[^>]*?/Count\s+(\d+)", data)]
    if not counts:
        counts = [int(m) for m in re.findall(rb"/Count\s+(\d+)[^>]*?/Type\s*/Pages\b", data)]
    if counts:
        return max(counts)
    return len(re.findall(rb"/Type\s*/Page(?![s])", data))


MIN_PDF_MB = 0.3
_TRACE_FILE = os.path.join(tempfile.gettempdir(), "hld_export_trace.txt")


def _trace(msg):
    """Append one timestamped line to the export trace. Flushed per line so the file tells the
    truth even if QGIS dies mid-export (the crash reporter shows no Python line for that)."""
    try:
        import time
        with open(_TRACE_FILE, "a", encoding="utf-8") as f:
            f.write(time.strftime("%H:%M:%S ") + str(msg) + "\n")
            f.flush()
    except Exception:
        pass


def _write_atlas_pdf(layout, path, cov=None, eff=None, dpi=300, qa=None, feedback=None):
    """Gated export core (no UI): relock frame → hard QA gate → export to a STAGED temp →
    verify page count + size → bookmarks → atomic replace onto `path`. A broken layout or a
    short/partial PDF NEVER lands at the deliverable path. Returns (ok, message). Testable
    headlessly. `qa` is the engine's `_layout_qa` callable (returns (hard[], soft[])).
    `feedback` is an optional QgsFeedback: QGIS reports per-page progress on it and stops
    between pages once it is cancelled — the UI wrapper uses it to keep the GUI alive."""
    from qgis.core import QgsLayoutExporter, QgsProject
    if not path.lower().endswith(".pdf"):
        path += ".pdf"
    _trace(f"write_atlas_pdf start layout={layout.name()!r} dpi={dpi} path={path}")
    # 1. Re-lock the map frame to its designed size — the designer's atlas preview (or a prior
    #    page-flip) can grow the frame item and clip the exported pages.
    try:
        _relock_frame(layout)
        layout.refresh()
        _trace("relock+refresh ok")
    except Exception as e:
        print("HLD export: frame relock skipped:", e)
        _trace(f"relock failed: {e}")
    # 2. Hard QA gate (frame-agnostic; HLD / commercial / wayleave) — a broken page can't ship.
    if callable(qa):
        try:
            hard, soft = qa(layout)
            for s in (soft or []):
                print("HLD QA warn:", s)
            if hard:
                _trace(f"QA blocked: {list(hard)[:3]}")
                return (False, "Layout QA blocked the export: " + "; ".join(list(hard)[:3]))
            _trace(f"QA ok (soft={len(soft or [])})")
        except Exception as e:
            print("HLD export: QA gate skipped (fail-open):", e)
            _trace(f"QA raised (fail-open): {e}")
    # 3. Export to a STAGED file (never straight onto the deliverable path).
    staged = path + ".stage.tmp.pdf"
    settings = QgsLayoutExporter.PdfExportSettings()
    settings.dpi = int(dpi)
    _trace(f"exportToPdf begin staged={staged} atlas_enabled={layout.atlas().enabled()}")
    res = QgsLayoutExporter(layout).exportToPdf(layout.atlas(), staged, settings, feedback)
    code = res[0] if isinstance(res, tuple) else res
    _trace(f"exportToPdf returned code={int(code)} err={res[1] if isinstance(res, tuple) else ''!r} "
           f"cancelled={bool(feedback is not None and feedback.isCanceled())}")
    if feedback is not None and feedback.isCanceled():
        _safe_unlink(staged)
        return (False, "Export cancelled — nothing was written to the destination.")
    if int(code) != 0:
        _safe_unlink(staged)
        return (False, f"QGIS could not write the PDF (code {code}).")
    # 4. Verify page count (overview + one per coverage feature) + size.
    # Expected page count. Prefer the ATLAS's own feature count: it is exactly the number of
    # pages QGIS was asked to render, whatever layer drives it. The `1 + cov.featureCount()`
    # form below is the historical fallback and it is ambiguous — it is right when `cov` is
    # the raw PON layer (overview page + one per PON) and silently off-by-one when the caller
    # passes the generated book-pages layer, which already CONTAINS the overview feature.
    # Same number on the existing path; no longer a trap for a new one.
    n_expected = None
    try:
        n_expected = layout.atlas().count() or None
    except Exception:
        n_expected = None
    if n_expected is None:
        try:
            n_expected = 1 + (cov.featureCount() if cov else 0)
        except Exception:
            n_expected = None
    pages = _count_pdf_pages(staged)
    _trace(f"pages={pages} expected={n_expected} size={os.path.getsize(staged) if os.path.exists(staged) else -1}")
    if n_expected is not None and pages >= 0 and pages != n_expected:
        _safe_unlink(staged)
        return (False, f"page count {pages} ≠ expected {n_expected} — export incomplete.")
    try:
        if os.path.getsize(staged) < MIN_PDF_MB * 1024 * 1024:
            _safe_unlink(staged)
            return (False, "exported PDF is too small — the render likely failed.")
    except Exception:
        pass
    # 5. Navigable bookmarks (Overview · Zone/PON 1…N) on the staged file — never blocks.
    try:
        from . import hld_generate as HG
        base = (eff or {}).get("project_name") or os.path.splitext(os.path.basename(path))[0]
        labels = HG._book_page_labels(QgsProject.instance(), cov, eff or {}, True)
        meta = {"/Title": base,
                "/Author": (eff or {}).get("designer") or (eff or {}).get("company") or "Velocity Fibre",
                "/Subject": "HLD Network Atlas", "/Creator": "Velocity Nexus"}
        HG._add_bookmarks(staged, labels, meta)
    except Exception as e:
        print("HLD export: bookmarks skipped:", e)
    # 6. Atomic replace — only a verified PDF reaches the deliverable path.
    try:
        os.replace(staged, path)
    except Exception as e:
        _safe_unlink(staged)
        _trace(f"finalise failed: {e}")
        return (False, f"could not finalise the PDF: {e}")
    _trace("done ok")
    return (True, path)


# Export resolution choices offered before the render. 300 stays the default (the
# deliverable output is unchanged); the lower ones exist because every page re-renders the
# satellite basemap and the render time scales with dpi².
_DPI_CHOICES = [("300 dpi — print quality (default)", 300),
                ("200 dpi — balanced, ~2× faster", 200),
                ("150 dpi — quick draft, ~4× faster", 150)]

# Everything the deferred export needs, held at module level so nothing the C++ exporter is
# still using can be garbage-collected while the render runs (Python-owned QgsFeedback /
# QProgressDialog wrappers dying under a live export was the 2026-08-26 access violation).
_EXPORT_STATE = {}
_LAST_ERROR_FILE = os.path.join(tempfile.gettempdir(), "hld_export_last_error.txt")


def _log_export_error(text):
    """Persist the last export error where it can be read after a crash; never raises."""
    try:
        from qgis.core import QgsMessageLog, Qgis
        QgsMessageLog.logMessage(text, "HLD Export", Qgis.MessageLevel.Critical)
    except Exception:
        pass
    try:
        tmp = _LAST_ERROR_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp, _LAST_ERROR_FILE)
    except Exception:
        pass


def _set_designer_painting(designer, enabled):
    """Mirror what QGIS's own atlas export does (qgslayoutdesignerdialog.cpp:
    mView->setPaintingEnabled(false) before, true after): while the exporter iterates the
    atlas, the designer's preview must not repaint, or the event pumping between pages
    re-enters the render. Best-effort; silently no-op when the API is missing."""
    try:
        if designer is not None and hasattr(designer, "view"):
            designer.view().setPaintingEnabled(bool(enabled))
    except Exception:
        pass


def _export_atlas_pdf(layout, parent, cov=None, eff=None, qa=None, designer=None):
    """UI wrapper: Save-As dialog -> dpi choice -> DEFERRED gated _write_atlas_pdf with a live
    progress dialog -> open the result.

    Two hard-won rules live here (both from 2026-08-26 on Malmsbury Herotel V4):
    1. The render must NOT run inside the toolbutton's mouse-release event. It is queued
       with QTimer.singleShot(0) so it starts from a clean event-loop turn; the first
       version ran nested in QToolButton::mouseReleaseEvent and QGIS died on return.
    2. The render runs on the GUI thread (QgsLayoutExporter offers no other way for an
       atlas), so the progress dialog pumps events between pages — otherwise Windows flags
       QGIS as hung and kills it (AppHangB1, 16 pages / 91 MB written, no EOF). While it
       pumps, the designer view must not repaint (see _set_designer_painting)."""
    from qgis.PyQt.QtWidgets import QFileDialog, QMessageBox, QInputDialog

    if _EXPORT_STATE.get("running"):
        QMessageBox.information(parent, "Export Atlas as PDF", "An export is already running.")
        return
    base = (layout.name() or "HLD").replace("/", "-").replace("\\", "-")
    path, _sel = QFileDialog.getSaveFileName(
        parent, "Export Atlas as PDF", os.path.join(_downloads_dir(), base + ".pdf"),
        "PDF files (*.pdf)")
    if not path:
        return
    _trace("=== export clicked ===")
    try:
        n_pages = 1 + (cov.featureCount() if cov else 0)
    except Exception:
        n_pages = 0
    labels = [c[0] for c in _DPI_CHOICES]
    choice, accepted = QInputDialog.getItem(
        parent, "Export resolution",
        f"{n_pages or '?'} pages will be rendered. Choose the resolution:", labels, 0, False)
    if not accepted:
        return
    dpi = dict(_DPI_CHOICES).get(choice, 300)
    _trace(f"dpi={dpi} n_pages={n_pages} designer={'yes' if designer is not None else 'no'}")

    def _done(ok, msg, secs):
        if not ok:
            _log_export_error(msg)
            if "cancelled" in msg.lower():
                QMessageBox.information(parent, "Export cancelled", msg)
            else:
                QMessageBox.warning(parent, "Export failed", msg)
            return
        try:
            mb = os.path.getsize(msg) / (1024 * 1024)
            pages = _count_pdf_pages(msg)
        except Exception:
            mb, pages = 0.0, -1
        try:
            os.startfile(msg)   # noqa: S606 - open the exact PDF just written
        except Exception:
            pass
        try:
            from qgis.utils import iface
            iface.messageBar().pushSuccess(
                "HLD Export",
                f"✅ Atlas PDF saved in {secs:.0f} s — {pages} pages, {mb:.1f} MB at {dpi} dpi: {msg}")
        except Exception:
            pass

    _run_gated_export(layout, path, cov=cov, eff=eff, qa=qa, dpi=dpi, parent=parent,
                      designer=designer, n_pages=n_pages, on_done=_done)


def _run_gated_export(layout, path, *, cov=None, eff=None, qa=None, dpi=300, parent=None,
                      designer=None, n_pages=0, title="Export Atlas as PDF", on_done=None):
    """Run ONE gated atlas export with every protection the 2026-08-26 crash bought us.

    This is the ONLY sanctioned way to render an atlas. `_write_atlas_pdf` alone is not:
    it pumps no events and defers nothing, so calling it directly renders N satellite-backed
    pages inside the caller's event-loop turn and Windows kills QGIS as hung (AppHangB1,
    observed at 16 pages). Everything that keeps that from happening lives HERE, so the
    single-book button and the phase batch go through the same door and one proving run
    covers both:

    1. The render must not run inside the click handler that started it — QTimer.singleShot
       queues it for a clean event-loop turn (the nested version killed QGIS on return).
    2. QgsLayoutExporter has no off-thread mode for an atlas, so the render owns the GUI
       thread; the progress callback pumps events between pages to stay alive and cancellable.
    3. While it pumps, the designer view must not repaint, or the pump re-enters the render.
    4. The QProgressDialog and QgsFeedback are pinned at module level for the whole run —
       a Python-owned wrapper dying under a live C++ export was the original access violation.

    `on_done(ok, msg, seconds)` fires on the GUI thread when the book is finished; `msg` is
    the written path on success and the failure text otherwise. Never raises to the caller.
    """
    import time
    from qgis.PyQt.QtWidgets import QProgressDialog
    from qgis.PyQt.QtCore import QCoreApplication, QTimer
    from qgis.core import QgsFeedback

    prog = QProgressDialog(f"Rendering {n_pages or '?'} pages at {dpi} dpi…", "Cancel",
                           0, 100, parent)
    prog.setWindowTitle(title)
    prog.setMinimumDuration(0)
    prog.setAutoClose(False)
    prog.setAutoReset(False)
    prog.setValue(0)
    feedback = QgsFeedback(prog)
    state = {"running": True, "prog": prog, "feedback": feedback, "in_cb": False,
             "path": path, "dpi": dpi, "n_pages": n_pages}
    _EXPORT_STATE.clear()
    _EXPORT_STATE.update(state)

    def _on_progress(pct):
        # QGIS emits this between pages. Pumping events here keeps the window alive and lets
        # the Cancel click through; the guard stops a nested pump re-entering us.
        if state["in_cb"]:
            return
        state["in_cb"] = True
        try:
            prog.setValue(int(pct))
            prog.setLabelText(f"{title} — {n_pages or '?'} pages at {dpi} dpi… {int(pct)}%")
            QCoreApplication.processEvents()
        except Exception:
            pass
        finally:
            state["in_cb"] = False

    feedback.progressChanged.connect(_on_progress)
    prog.canceled.connect(feedback.cancel)

    def _finish(ok, msg, secs):
        _trace(f"finish ok={ok} secs={secs:.1f} msg={str(msg)[:200]!r}")
        _set_designer_painting(designer, True)
        try:
            feedback.progressChanged.disconnect(_on_progress)
        except Exception:
            pass
        try:
            prog.canceled.disconnect(feedback.cancel)
        except Exception:
            pass
        try:
            prog.close()
            prog.deleteLater()          # takes the child feedback with it, later, safely
        except Exception:
            pass
        _EXPORT_STATE.clear()
        if callable(on_done):
            try:
                on_done(ok, msg, secs)
            except Exception as e:
                _trace(f"on_done raised: {e}")

    def _run():
        _trace("deferred run start")
        t0 = time.time()
        _set_designer_painting(designer, False)
        try:
            ok, msg = _write_atlas_pdf(layout, path, cov, eff, dpi=dpi, qa=qa, feedback=feedback)
        except Exception as e:
            ok, msg = False, f"Export error: {e}\n{traceback.format_exc()[-600:]}"
        _finish(ok, msg, time.time() - t0)

    prog.show()
    _trace("progress shown; deferring run")
    # Leave the click handler first; start the render from a clean event-loop turn.
    QTimer.singleShot(0, _run)


def phase_book_cfg(base_cfg, phase, all_phases, extra_overview=()):
    """Config for ONE phase's book, derived from the shared dialog config.

    Two things make a phase book different from the normal one-book HLD, and both are
    encoded here rather than in the engine, so the engine's default path stays untouched:

    * `book_prefix` — themes and the generated page-coverage layer are addressed by name and
      each build deletes the existing one first, so without a per-phase prefix book 8 would
      steal books 1-7's themes and coverage and they would render the wrong phase while
      still exporting cleanly.
    * `overview_geometry_layers` + `overview_layers` — page 1 shows ALL the phase boundaries
      framed on their union (the whole-town picture the operator asked for), while the detail
      pages carry only this phase's network and NO boundary polygon at all.
    """
    from . import phases as PH
    cfg = copy.deepcopy(dict(base_cfg or {}))
    n = phase["phase_no"]
    title = str(cfg.get("project_name") or "HLD").strip()
    bounds = [b.name() for b in PH.boundary_layers(all_phases)]
    content = [l.name() for l in phase["content"]]

    cfg["book_prefix"] = "PH%d_" % n
    cfg["layout_atlas"] = "%s Phase %d HLD Atlas" % (title, n)
    cfg["layout_overview"] = "%s Phase %d HLD Overview" % (title, n)
    cfg["layout_report"] = "%s Phase %d HLD Book" % (title, n)
    cfg["project_name"] = "%s - Phase %d" % (title, n)

    roles = dict(cfg.get("roles") or {})
    roles["coverage"] = [phase["coverage"].name()] if phase.get("coverage") else []
    cfg["roles"] = roles
    cfg["coverage_sort_field"] = phase.get("coverage_field") or "id"
    cfg["coverage_label_field"] = phase.get("coverage_field")
    cfg["atlas_filename_expr"] = '"%s"' % (phase.get("coverage_field") or "id")
    cfg["title_atlas_expr"] = "%s - PON " % cfg["project_name"]

    # detail pages: this phase's content only. The engine builds the legend from these.
    cfg["hld_layers"] = content
    cfg["legend_from_symbology"] = True
    # overview page: every phase boundary (labelled) + whatever framing layers were asked
    # for + the basemap. NOTE the boundaries appear ONLY here, never in hld_layers.
    cfg["overview_layers"] = bounds + [n2 for n2 in extra_overview if n2] + [cfg.get("basemap")]
    cfg["overview_geometry_layers"] = bounds
    # the boundary-off guarantee rests entirely on the per-page theme binding, so a phase
    # book refuses to build if that binding cannot be proven (see _theme_binding_ok).
    cfg["require_theme_binding"] = True
    # never touch the operator's symbology
    cfg["restyle_layers"] = False
    return cfg


def build_phase_books(iface, base_cfg, selected_phases, all_phases, extra_overview=()):
    """Build one atlas layout per selected phase in the LIVE project.

    Returns (books, errors). `books` feeds straight into `export_phase_books`.
    Each book is built by the same engine entry point the single-book path uses; only the
    config differs. Nothing is exported and nothing is saved here.
    """
    from qgis.core import QgsProject
    p = QgsProject.instance()
    here = os.path.dirname(os.path.abspath(__file__))
    engine = os.path.join(here, "hld_atlas_engine.py")
    if not os.path.exists(engine):
        return [], ["Engine not found: %s" % engine]
    src = open(engine, encoding="utf-8").read()

    books, errors = [], []
    for phase in selected_phases:
        n = phase["phase_no"]
        if phase.get("coverage") is None or phase["pon_count"] < 1:
            errors.append("Phase %d: no PON coverage layer with features — skipped." % n)
            continue
        cfg = phase_book_cfg(base_cfg, phase, all_phases, extra_overview)
        ns = {"HLD_CFG": cfg}
        try:
            exec(compile(src, engine, "exec"), ns)      # defines the engine; builds nothing
            ns["build"]()                               # explicit entry point
        except Exception as e:
            errors.append("Phase %d: %s" % (n, e))
            _trace("phase %d build failed: %s\n%s" % (n, e, traceback.format_exc()[-400:]))
            continue
        eff = ns.get("CFG", {}) or {}
        layout = p.layoutManager().layoutByName(eff.get("layout_atlas", ""))
        if layout is None:
            errors.append("Phase %d: layout was not created." % n)
            continue
        role = ns.get("_role")
        cov = role("coverage") if callable(role) else None
        books.append({"label": "%s Phase %d HLD" % (str(base_cfg.get("project_name") or "HLD"), n),
                      "phase_no": n, "layout": layout, "cov": cov, "eff": eff,
                      "qa": ns.get("_layout_qa"),
                      "expected_pages": 1 + phase["pon_count"]})
        _trace("built phase %d book: %s (%d pages expected)"
               % (n, layout.name(), 1 + phase["pon_count"]))
    return books, errors


_BATCH_STATE = {}


def export_phase_books(books, parent, out_dir=None, dpi=None, designer=None, qa=None):
    """Export a phase book set — one PDF per phase — without freezing or crashing QGIS.

    `books` is a list of dicts: {"label", "layout", "cov", "eff"}. Each is rendered by
    `_run_gated_export`, the SAME function the single-book green button uses, so proving one
    export end to end proves the batch's render path too.

    The books are CHAINED, not looped: book N+1 is queued from book N's completion callback
    on a fresh event-loop turn. A plain `for` loop would stack eight GUI-thread renders inside
    one turn and reproduce exactly the hang this wrapper exists to prevent.

    A book that fails its QA gate or verification is recorded and SKIPPED; the remaining books
    still run, because seven good books beat none. The summary at the end reports every book's
    real page count, size and wall-clock — measured, not estimated.
    """
    from qgis.PyQt.QtWidgets import QFileDialog, QMessageBox, QInputDialog
    from qgis.PyQt.QtCore import QTimer

    if _BATCH_STATE.get("running") or _EXPORT_STATE.get("running"):
        QMessageBox.information(parent, "Export all phases", "An export is already running.")
        return
    books = [b for b in (books or []) if b.get("layout") is not None]
    if not books:
        QMessageBox.warning(parent, "Export all phases", "No phase books have been built yet.")
        return
    if not out_dir:
        out_dir = QFileDialog.getExistingDirectory(
            parent, "Folder for the phase PDFs", _downloads_dir())
        if not out_dir:
            return
    total_pages = 0
    for b in books:
        try:
            total_pages += 1 + (b["cov"].featureCount() if b.get("cov") else 0)
        except Exception:
            pass
    if dpi is None:
        labels = [c[0] for c in _DPI_CHOICES]
        choice, accepted = QInputDialog.getItem(
            parent, "Export resolution",
            f"{len(books)} books, {total_pages or '?'} pages in total. Choose the resolution:",
            labels, 0, False)
        if not accepted:
            return
        dpi = dict(_DPI_CHOICES).get(choice, 300)

    _trace(f"=== batch export: {len(books)} books, {total_pages} pages, dpi={dpi} ===")
    results = []
    _BATCH_STATE.clear()
    _BATCH_STATE.update({"running": True, "books": books, "results": results})

    def _finish_batch():
        _BATCH_STATE.clear()
        good = [r for r in results if r["ok"]]
        bad = [r for r in results if not r["ok"]]
        lines = [f"{r['label']}: {r['pages']} pages · {r['mb']:.1f} MB · {r['secs']:.0f} s"
                 for r in good]
        lines += [f"{r['label']}: FAILED — {r['msg']}" for r in bad]
        _trace("batch done: " + " | ".join(lines))
        body = (f"{len(good)} of {len(books)} books written to:\n{out_dir}\n\n"
                + "\n".join(lines))
        if bad:
            QMessageBox.warning(parent, "Export all phases — finished with failures", body)
        else:
            QMessageBox.information(parent, "Export all phases — done", body)
            try:
                os.startfile(out_dir)   # noqa: S606 - the folder the operator just chose
            except Exception:
                pass

    def _start(i):
        if i >= len(books):
            _finish_batch()
            return
        b = books[i]
        safe = str(b["label"]).replace("/", "-").replace("\\", "-").replace(":", "-")
        path = os.path.join(out_dir, safe + ".pdf")
        try:
            n_pages = 1 + (b["cov"].featureCount() if b.get("cov") else 0)
        except Exception:
            n_pages = 0
        _trace(f"batch book {i + 1}/{len(books)}: {b['label']} -> {path}")

        def _done(ok, msg, secs):
            pages, mb = -1, 0.0
            if ok:
                try:
                    pages = _count_pdf_pages(msg)
                    mb = os.path.getsize(msg) / (1024 * 1024)
                except Exception:
                    pass
            else:
                _log_export_error(f"{b['label']}: {msg}")
            results.append({"label": b["label"], "ok": ok, "msg": msg, "secs": secs,
                            "pages": pages, "mb": mb, "path": path if ok else None})
            # next book from a CLEAN event-loop turn, never nested inside this callback
            QTimer.singleShot(0, lambda: _start(i + 1))

        _run_gated_export(b["layout"], path, cov=b.get("cov"), eff=b.get("eff"), qa=qa,
                          dpi=dpi, parent=parent, designer=designer, n_pages=n_pages,
                          title=f"{b['label']}  ({i + 1} of {len(books)})", on_done=_done)

    _start(0)


_VIS_SNAPSHOT_FILE = os.path.join(tempfile.gettempdir(),
                                  "hld_phase_visibility_snapshot.json")


def build_phase_books_in_project(iface, base_cfg, wanted_phase_nos=None, extra_overview=()):
    """Build the whole phase book set in the CURRENT project and open the first one.

    Returns (ok, message, books). Nothing is exported and the project is never saved.

    Order matters: the layer-tick snapshot is written to disk BEFORE the first change, so
    the operator's panel can be restored exactly even if QGIS dies later in the run.
    """
    import json
    from qgis.core import QgsProject
    from . import phases as PH
    p = QgsProject.instance()

    all_phases = PH.detect_phases(p)
    if not all_phases:
        return (False, "No phase groups found in this project. A phase is a layer group "
                       "named like “Phase 3”.", [])
    sel = [ph for ph in all_phases
           if wanted_phase_nos is None or ph["phase_no"] in set(wanted_phase_nos)]
    if not sel:
        return (False, "None of the selected phases were found.", [])

    # 1. snapshot the operator's tick state to disk before touching anything
    snap = PH.snapshot_visibility(p)
    try:
        tmp = _VIS_SNAPSHOT_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(snap, f)
        os.replace(tmp, _VIS_SNAPSHOT_FILE)
        _trace("visibility snapshot written: %d layers, %d groups"
               % (len(snap["layers"]), len(snap["groups"])))
    except Exception as e:
        return (False, "Could not write the layer-visibility snapshot (%s). Refusing to "
                       "change your Layers panel without a way back." % e, [])

    # 2. put the panel into the book's detail state so the canvas matches the PDF
    changed = PH.apply_book_visibility(sel + [ph for ph in all_phases if ph not in sel], p)
    _trace("visibility applied: +%d on, -%d off" % (len(changed["on"]), len(changed["off"])))

    # 3. build one atlas layout per phase
    books, errors = build_phase_books(iface, base_cfg, sel, all_phases, extra_overview)
    if not books:
        return (False, "No phase books were built.\n" + "\n".join(errors), [])

    # 4. open the first book with an "Export ALL phases" button on it
    try:
        first = books[0]
        d = iface.openLayoutDesigner(first["layout"])
        try:
            d.setAtlasPreviewEnabled(True)
            first["layout"].atlas().seekTo(0)
            _relock_frame(first["layout"])
            first["layout"].atlas().refreshCurrentFeature()
            _relock_frame(first["layout"])
            first["layout"].refresh()
        except Exception:
            pass
        _add_export_button(d, first["layout"], first.get("cov"), first.get("eff"),
                           first.get("qa"))
        _add_batch_export_button(d, books, qa=first.get("qa"))
        w = d.window() if hasattr(d, "window") else None
        if w is not None:
            w.show(); w.raise_(); w.activateWindow()
    except Exception as e:
        _trace("phase book designer open skipped: %s" % e)

    total = sum(b["expected_pages"] for b in books)
    msg = ("Built %d phase books — %d pages in total. Click “🗂 Export ALL phases” in the "
           "designer to write one PDF per phase." % (len(books), total))
    if errors:
        msg += "  (%d phase(s) skipped: %s)" % (len(errors), "; ".join(errors))
    return (True, msg, books)


def restore_phase_visibility(project=None):
    """Undo `apply_book_visibility` from the on-disk snapshot. Returns (ok, message)."""
    import json
    from . import phases as PH
    try:
        with open(_VIS_SNAPSHOT_FILE, encoding="utf-8") as f:
            snap = json.load(f)
    except Exception as e:
        return False, "No usable visibility snapshot at %s (%s)." % (_VIS_SNAPSHOT_FILE, e)
    restored, missing = PH.restore_visibility(snap, project)
    return True, ("Restored %d layer ticks%s."
                  % (restored, "" if not missing else "; %d layer(s) not in the snapshot: %s"
                     % (len(missing), ", ".join(missing[:5]))))


def _add_batch_export_button(designer, books, qa=None):
    """The one button that writes the whole set: “🗂 Export ALL phases”."""
    try:
        from qgis.PyQt.QtWidgets import QToolBar
        from qgis.PyQt.QtGui import QAction
        from qgis.PyQt.QtCore import Qt
        win = designer.window() if hasattr(designer, "window") else None
        if win is None:
            return
        if win.findChild(QToolBar, "vfPhaseBatchToolbar") is not None:
            return
        tb = QToolBar("Export phase books", win)
        tb.setObjectName("vfPhaseBatchToolbar")
        act = QAction("🗂  Export ALL phases  (%d books)" % len(books), win)
        act.setObjectName("vfExportAllPhases")
        act.setToolTip("Write one PDF per phase into a folder you choose. Each book is "
                       "rendered one at a time so QGIS stays responsive.")
        act.triggered.connect(
            lambda *_a: export_phase_books(books, win, designer=designer, qa=qa))
        tb.addAction(act)
        win.addToolBar(Qt.ToolBarArea.TopToolBarArea, tb)
        try:
            tb.setStyleSheet(
                "QToolBar#vfPhaseBatchToolbar{background:#1a73e8;border:0;padding:2px;spacing:0;}"
                "QToolBar#vfPhaseBatchToolbar QToolButton{color:white;font-weight:bold;"
                "font-size:13px;padding:6px 14px;}")
        except Exception:
            pass
    except Exception as e:
        print("HLD phase batch button skipped:", e)


def _add_export_button(designer, layout, cov=None, eff=None, qa=None):
    """Add a big, unmissable green “📄 Export Atlas as PDF” button to the designer's toolbar.
    QGIS's own atlas-export action is buried in a dropdown, so operators miss it — this makes
    the one thing they need to click when they're happy obvious."""
    try:
        from qgis.PyQt.QtWidgets import QToolBar
        from qgis.PyQt.QtGui import QAction
        from qgis.PyQt.QtCore import Qt
        win = designer.window() if hasattr(designer, "window") else None
        if win is None:
            return
        if win.findChild(QToolBar, "vfExportToolbar") is not None:
            return                                        # already added — don't duplicate
        tb = QToolBar("Export HLD", win)
        tb.setObjectName("vfExportToolbar")
        act = QAction("📄  Export Atlas as PDF", win)
        act.setObjectName("vfExportAtlasPdf")
        act.setToolTip("Save the whole map book to a PDF (all pages) — click when you're happy.")
        # Take *args: PyQt hands a slot only as many of the signal's arguments as the
        # slot declares, so a fixed-arity lambda breaks the moment that count changes
        # (QAction.triggered emits one bool). Closure-captured, arity-proof.
        act.triggered.connect(
            lambda *_a: _export_atlas_pdf(layout, win, cov, eff, qa, designer=designer))
        tb.addAction(act)
        win.addToolBar(Qt.ToolBarArea.TopToolBarArea, tb)
        try:
            tb.setStyleSheet(
                "QToolBar#vfExportToolbar{background:#0f9d58;border:0;padding:2px;spacing:0;}"
                "QToolBar#vfExportToolbar QToolButton{color:white;font-weight:bold;"
                "font-size:13px;padding:6px 14px;}")
        except Exception:
            pass
    except Exception as e:
        print("HLD export button skipped:", e)


def build_in_project(iface, hld_cfg, extra_layers=None):
    """Build both HLD layouts in the CURRENT project and open the Print Layout designer.

    Returns (ok: bool, message: str, overview_name: str|None, atlas_name: str|None).
    The map layers get the HLD deliverable styling (the layouts render the live
    layers, so the styling has to live on them). Nothing is saved — close without
    saving to revert, or Save to keep the layouts + styling in your project.
    """
    from qgis.core import QgsProject
    p = QgsProject.instance()
    here = os.path.dirname(os.path.abspath(__file__))
    engine = os.path.join(here, "hld_atlas_engine.py")
    if not os.path.exists(engine):
        return (False, f"Engine not found: {engine}", None, None)

    try:
        _add_missing_extras(p, extra_layers)
    except Exception as e:
        # framing helper is optional — never fail the whole build over it
        print("HLD live build: extra-layer add skipped:", e)

    hld_cfg = dict(hld_cfg or {})
    hld_cfg["build_mode"] = "layouts"          # page-view overview + detail atlas (WYSIWYG)
    ns = {"HLD_CFG": hld_cfg}
    try:
        with open(engine, encoding="utf-8") as f:
            exec(compile(f.read(), engine, "exec"), ns)   # defines the engine; builds nothing
        ns["build"]()                                    # explicit entry point (was: build_all() on exec)
    except Exception as e:
        return (False, f"Layout build failed: {e}\n{traceback.format_exc()[-700:]}", None, None)

    eff = ns.get("CFG", {}) or {}
    ov_name = eff.get("layout_overview", "MOA PH2 HLD Overview")
    at_name = eff.get("layout_atlas", "MOA PH2 HLD Atlas")
    lm = p.layoutManager()
    overview = lm.layoutByName(ov_name)     # only exists in grid/commercial page-layout mode
    atlas = lm.layoutByName(at_name)        # the book atlas (overview page 1 + detail pages)
    if atlas is None:
        return (False, "Layout was not created (engine build produced nothing).", None, None)

    _role = ns.get("_role")
    cov = _role("coverage") if callable(_role) else None
    n = cov.featureCount() if cov else 0
    if not cov or n < 1:
        return (False, "Coverage layer is empty or unresolved — check the coverage/model selection.",
                None, None)

    def _show_atlas_toolbar(designer):
        """The Atlas Toolbar (◀ [page] ▶ page-flip arrows) is hidden by default in a fresh
        designer window — show it so the operator can flip through the pages."""
        try:
            from qgis.PyQt.QtWidgets import QToolBar
            win = designer.window() if hasattr(designer, "window") else None
            if win is None:
                return
            for tb in win.findChildren(QToolBar):
                if (tb.objectName() or "").lower() == "matlastoolbar":
                    tb.setVisible(True)
        except Exception:
            pass

    def _open_front(layout, atlas_preview=False):
        try:
            d = iface.openLayoutDesigner(layout)
            if atlas_preview:
                try:
                    d.setAtlasPreviewEnabled(True)
                    layout.atlas().seekTo(0)
                    _relock_frame(layout)                 # undo the preview resize, then fit
                    layout.atlas().refreshCurrentFeature()
                    _relock_frame(layout)                 # belt-and-suspenders
                    layout.refresh()
                    _show_atlas_toolbar(d)                # reveal the page-flip arrows
                except Exception:
                    pass
            if atlas_preview:
                # the obvious "Export Atlas as PDF" — wired to the same hard QA gate as headless
                _add_export_button(d, layout, cov, eff, ns.get("_layout_qa"))
            try:
                w = d.window() if hasattr(d, "window") else None
                if w is not None:
                    w.show(); w.raise_(); w.activateWindow()
            except Exception:
                pass
        except Exception as e:
            print("HLD live build: openLayoutDesigner skipped:", e)

    # open the book atlas: page 1 = overview, flip ▶ to each detail page
    if overview is not None and overview is not atlas:
        _open_front(overview)                          # grid/commercial: separate overview
    _open_front(atlas, atlas_preview=True)

    # advisory QA — a broken layout can't silently sail through; warn (never block) so the
    # operator fine-tunes before exporting. Frame-agnostic (HLD / commercial / wayleave).
    try:
        _qa = ns.get("_layout_qa")
        if callable(_qa):
            hard, _soft = _qa(atlas)
            if hard:
                from qgis.core import Qgis
                iface.messageBar().pushMessage(
                    "HLD layout check",
                    f"{len(hard)} item(s) may overlap or sit off-page — nudge them before you "
                    f"export. (e.g. {hard[0]})",
                    level=Qgis.MessageLevel.Warning, duration=12)
    except Exception as e:
        print("HLD advisory QA skipped:", e)

    pages = 1 + n
    return (True, f"Built “{at_name}” — page 1 overview, flip ▶ through {n} detail pages "
            f"({pages} total).", at_name, None)
