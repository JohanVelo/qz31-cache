import sys, os
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')

# ============================================================
# POLES V1 — NULL LABEL POLES FULL POPULATION
# Project: Potch - Mohadin PH2
# Finds all poles with NULL Label, assigns:
#   1. Pole Type — spatial proximity to cable layers
#   2. Label — continuing from MOA.P.H248
#   3. All attributes — based on Pole Type
#   4. Static fields — stack, subplace etc
#   5. lat/lon — from geometry
# ============================================================

POLES_LAYER = 'poles v1'
PRIMARY_LAYER = 'Primary Cable v1'
SECONDARY_LAYER = 'Secondary Cable v1'
DISTRIBUTION_LAYER = 'Distribution Cable v1'
PON_LAYER = 'PON v1'
ZONE_LAYER = 'Zones v1'

SEARCH_DISTANCE = 5  # metres — within 5m of cable = that pole type

# Label continues from H248
START_CABINET_LETTER = 'H'
START_NUM = 249
SR = 'MOA'

# Static values
STATIC = {
    'type_1': 'Pole',
    'subtype_1': 'Creosote',
    'spec_1': 'H4SANS754',
    'dim1': '7m',
    'status': 'Permission not granted',
    'companyown': 'VelocityFibre',
    'subplace': '676007',
    'mainplace': '676007',
    'municipal': 'JB Marks Local Municipality',
    'stack': 'MOA',
    'createdby': 'Johan Scholtz',
    # Child 4 — all poles
    'type_4': 'Hook',
    'subtype4': 'Offset Bracket',
    'spec_4': '2Way',
    'dim1_4': '(R19*W12,50mm)*2',
    # Child 6 — all poles
    'type_6': 'Attachment',
    'subtype_6': 'Strapping',
    'spec_6': 'Grade304 BandIt',
    'dim1_6': '19*0,5mm',
    'featno5': '4',
    # Child 7 — all poles
    'type_7': 'Attachment',
    'subtype7': 'Buckle',
    'spec_7': 'Grade304 BandIt',
    'dim1_7': '19mm',
    'featno6': '2',
}

# Per pole type values
TYPE_ATTRS = {
    'Primary Feeder': {
        'dim2': '140-160mm',
        'type_2': None, 'subtype_2': None, 'spec_2': None, 'dim1_2': None, 'featno1': None,
        'type_3': 'Tangent', 'subtype_3': 'ADSS',
        'spec_3': 'Galvanised Steel Wire/Steel Thimble',
        'dim1_3': '15,11-16,00mm', 'featno2': '2',
        'featno3': True,
        'type_5': None, 'subtype5': None, 'spec_5': None,
        'dim1_5': None, 'dim2_5': None, 'featno4': None,
    },
    'Secondary Feeder': {
        'dim2': '140-160mm',
        'type_2': 'Dead-End', 'subtype_2': 'Mini-ADSS',
        'spec_2': 'Galvanised Steel Wire/Steel Thimble',
        'dim1_2': '4,50-6,19mm', 'featno1': '2',
        'type_3': None, 'subtype_3': None, 'spec_3': None, 'dim1_3': None, 'featno2': None,
        'featno3': True,
        'type_5': None, 'subtype5': None, 'spec_5': None,
        'dim1_5': None, 'dim2_5': None, 'featno4': None,
    },
    'Distribution': {
        'dim2': '120-140mm',
        'type_2': 'Dead-End', 'subtype_2': 'Mini-ADSS',
        'spec_2': 'Galvanised Steel Wire/Steel Thimble',
        'dim1_2': '4,50-6,19mm', 'featno1': '2',
        'type_3': None, 'subtype_3': None, 'spec_3': None, 'dim1_3': None, 'featno2': None,
        'featno3': True,
        'type_5': 'Slack Bracket', 'subtype5': 'Bracket',
        'spec_5': 'Extreme Slack', 'dim1_5': 'D620', 'dim2_5': 'D516', 'featno4': True,
    },
}

# --- GET LAYERS ---
poles = None
primary = None
secondary = None
distribution = None
pon_layer = None
zone_layer = None

for lyr in QgsProject.instance().mapLayers().values():
    n = lyr.name()
    if n == POLES_LAYER: poles = lyr
    if n == PRIMARY_LAYER: primary = lyr
    if n == SECONDARY_LAYER: secondary = lyr
    if n == DISTRIBUTION_LAYER: distribution = lyr
    if n == PON_LAYER: pon_layer = lyr
    if n == ZONE_LAYER: zone_layer = lyr

missing = []
if not poles: missing.append(POLES_LAYER)
if not primary: missing.append(PRIMARY_LAYER)
if not secondary: missing.append(SECONDARY_LAYER)
if not distribution: missing.append(DISTRIBUTION_LAYER)
if missing:
    print(f"ERROR: Missing layers: {missing}")
else:
    print("All layers found.")

    # --- FIND NULL LABEL POLES ---
    null_poles = [f for f in poles.getFeatures()
                  if not f['Label'] or str(f['Label']).strip() in ('NULL', 'None', '')]
    print(f"NULL label poles found: {len(null_poles)}")

    if len(null_poles) == 0:
        print("Nothing to do.")
    else:
        # --- BUILD SPATIAL INDEXES FOR CABLE LAYERS ---
        from qgis.core import QgsSpatialIndex

        def build_index(lyr):
            idx = QgsSpatialIndex(lyr.getFeatures())
            feats = {f.id(): f for f in lyr.getFeatures()}
            return idx, feats

        pri_idx, pri_feats = build_index(primary)
        sec_idx, sec_feats = build_index(secondary)
        dis_idx, dis_feats = build_index(distribution)

        def nearest_dist(point, idx, feats):
            candidates = idx.nearestNeighbor(point, 1)
            if not candidates:
                return float('inf')
            feat = feats[candidates[0]]
            return feat.geometry().distance(QgsGeometry.fromPointXY(point))

        # --- BUILD SPATIAL INDEXES FOR PON AND ZONE ---
        if pon_layer:
            pon_idx = QgsSpatialIndex(pon_layer.getFeatures())
            pon_feats = {f.id(): f for f in pon_layer.getFeatures()}
        if zone_layer:
            zone_idx = QgsSpatialIndex(zone_layer.getFeatures())
            zone_feats = {f.id(): f for f in zone_layer.getFeatures()}

        # --- GENERATE LABELS ---
        def num_to_label(n):
            # n is absolute count from A001
            # Each letter block = 999
            letter_idx = (n - 1) // 999
            num = ((n - 1) % 999) + 1
            letter = chr(65 + letter_idx)
            return f'{SR}.P.{letter}{str(num).zfill(3)}'

        # Start from H249 = absolute position
        # H = letter index 7 (A=0), so absolute = 7*999 + 249 = 7242
        START_ABS = 7 * 999 + 249

        # Sort null poles top-to-bottom, left-to-right
        def sort_key(f):
            g = f.geometry()
            if g is None or g.isNull():
                return (9999, 9999)
            pt = g.centroid().asPoint()
            return (-pt.y(), pt.x())

        null_poles_sorted = sorted(null_poles, key=sort_key)

        # --- GET FIELD INDEXES ---
        def fidx(name):
            return poles.fields().indexOf(name)

        # --- ACCUMULATE BULK WRITES ---
        # Project rule: never per-feature changeAttributeValue() inside an edit
        # session for big layers — accumulate then write once via the provider.
        attr_map = {}

        assigned_types = {'Primary Feeder': 0, 'Secondary Feeder': 0, 'Distribution': 0}
        null_geom = 0
        written = 0  # only advances for poles actually labelled (skipped null-geom poles must not consume a label slot)

        for i, pole in enumerate(null_poles_sorted):
            geom = pole.geometry()

            if geom is None or geom.isNull() or geom.isEmpty():
                null_geom += 1
                continue

            pt = geom.centroid().asPoint()

            # --- ASSIGN POLE TYPE ---
            d_pri = nearest_dist(pt, pri_idx, pri_feats)
            d_sec = nearest_dist(pt, sec_idx, sec_feats)
            d_dis = nearest_dist(pt, dis_idx, dis_feats)

            min_d = min(d_pri, d_sec, d_dis)

            if min_d > SEARCH_DISTANCE:
                pole_type = 'Distribution'  # fallback
            elif d_pri <= d_sec and d_pri <= d_dis:
                pole_type = 'Primary Feeder'
            elif d_sec <= d_pri and d_sec <= d_dis:
                pole_type = 'Secondary Feeder'
            else:
                pole_type = 'Distribution'

            assigned_types[pole_type] += 1

            # --- ASSIGN LABEL ---
            abs_pos = START_ABS + written
            label = num_to_label(abs_pos)

            # --- ASSIGN lat/lon ---
            lat = round(pt.y(), 6)
            lon = round(pt.x(), 7)

            # --- ASSIGN pon_no ---
            pon_no = None
            if pon_layer:
                candidates = pon_idx.intersects(geom.boundingBox())
                for fid in candidates:
                    if pon_feats[fid].geometry().contains(geom):
                        pon_no = pon_feats[fid]['pon_no']
                        break

            # --- ASSIGN zone_no ---
            zone_no = None
            if zone_layer:
                candidates = zone_idx.intersects(geom.boundingBox())
                for fid in candidates:
                    if zone_feats[fid].geometry().contains(geom):
                        zone_no = zone_feats[fid]['zone_no']
                        break

            # --- WRITE ALL FIELDS (accumulate, single bulk write after loop) ---
            changes = {
                fidx('Label'): label,
                fidx('Pole Type'): pole_type,
                fidx('lat'): lat,
                fidx('lon'): lon,
            }
            if pon_no: changes[fidx('pon_no')] = pon_no
            if zone_no: changes[fidx('zone_no')] = zone_no

            # Static fields
            for field, val in STATIC.items():
                changes[fidx(field)] = val

            # Type-specific fields
            type_vals = TYPE_ATTRS[pole_type]
            for field, val in type_vals.items():
                changes[fidx(field)] = val

            attr_map[pole.id()] = changes

            written += 1

        # --- SINGLE BULK PROVIDER WRITE ---
        if attr_map:
            poles.dataProvider().changeAttributeValues(attr_map)
            poles.triggerRepaint()

        # --- SUMMARY ---
        print("=" * 50)
        print("  NULL LABEL POLES — POPULATION COMPLETE")
        print(f"  Total processed: {len(null_poles_sorted) - null_geom}")
        print(f"  NULL geometry skipped: {null_geom}")
        print(f"  Primary Feeder: {assigned_types['Primary Feeder']}")
        print(f"  Secondary Feeder: {assigned_types['Secondary Feeder']}")
        print(f"  Distribution: {assigned_types['Distribution']}")
        print("=" * 50)
