# -*- coding: utf-8 -*-
"""Project profile — everything that is NOT universal about a splice plan.

The engine itself knows how a GPON network is spliced: OLT port -> POP -> feeder ->
AGG dome -> 1:16 FTS -> distribution walk -> DIS dome -> 1:8 STS -> drop -> ONT. That
part is the same on every Fibertime job.

What differs per project is naming and wiring: the site prefix, which layer holds what,
how a label spells a splitter, which OLT card maps to which PON number. All of that lives
in a profile JSON so a second project is a config file, not a code fork.

⛔ A profile is NOT a place to put a guess. Every pattern here was measured against the
   delivered Mohadin PH2 workbook. If a project's labels do not match its profile, the
   engine REFUSES — it never falls back to "close enough", because a plausible-but-wrong
   splice plan sends a technician to the wrong pole.
"""
from __future__ import annotations

import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
PROFILE_DIR = os.path.join(os.path.dirname(HERE), "profiles")

# Keys a profile must define. Missing any one is a hard error at load time, not a
# KeyError three modules deep once a 30,000-row workbook is half written.
REQUIRED = (
    "name", "client", "site_prefix", "olt_name", "pop_label",
    "fts_ratio", "sts_ratio", "layers", "patterns", "sheet",
)
REQUIRED_LAYERS = (
    "poles", "ont", "fts", "sts", "agg_dome", "dis_dome",
    "distribution", "drop", "spare_drop", "primary", "secondary", "pon",
)
REQUIRED_PATTERNS = ("fts", "sts", "agg_dome", "dis_dome", "cable", "pole", "drop")


class ProfileError(ValueError):
    """A profile that cannot be trusted. Always names the key at fault."""


class Profile:
    """A validated project profile with the compiled label grammar."""

    def __init__(self, data, path=None):
        self.path = path
        self.data = data
        self._validate()
        self.name = data["name"]
        self.client = data["client"]
        self.prefix = data["site_prefix"]
        self.olt_name = data["olt_name"]
        self.pop_label = data["pop_label"]
        self.fts_ratio = int(data["fts_ratio"])
        self.sts_ratio = int(data["sts_ratio"])
        self.layers = dict(data["layers"])
        self.sheet = dict(data["sheet"])
        self.tolerance_m = float(data.get("tolerance_m", 1.0))
        self.metric_epsg = int(data.get("metric_epsg", 32735))
        self.card_offsets = {int(k): int(v) for k, v in data.get("card_offsets", {}).items()}
        self.overrides = dict(data.get("overrides", {}))
        self.rx = {k: re.compile(v) for k, v in data["patterns"].items()}

    # ── validation ───────────────────────────────────────────────────────────
    def _validate(self):
        d = self.data
        for k in REQUIRED:
            if k not in d:
                raise ProfileError(f"profile missing required key: {k!r}")
        for k in REQUIRED_LAYERS:
            if k not in d["layers"]:
                raise ProfileError(f"profile['layers'] missing role: {k!r}")
        for k in REQUIRED_PATTERNS:
            if k not in d["patterns"]:
                raise ProfileError(f"profile['patterns'] missing pattern: {k!r}")
            try:
                re.compile(d["patterns"][k])
            except re.error as e:
                raise ProfileError(f"profile['patterns'][{k!r}] is not a valid regex: {e}")
        for k in ("tab", "feeder", "all_splices", "ports", "cover", "how_to_read"):
            if k not in d["sheet"]:
                raise ProfileError(f"profile['sheet'] missing key: {k!r}")
        if int(d["fts_ratio"]) <= 0 or int(d["sts_ratio"]) <= 0:
            raise ProfileError("fts_ratio and sts_ratio must be positive")

    # ── label helpers ────────────────────────────────────────────────────────
    def parse(self, kind, label):
        """Return the named groups of `label` under pattern `kind`, or None."""
        if not label:
            return None
        m = self.rx[kind].match(str(label).strip())
        return m.groupdict() if m else None

    def pon_of(self, card, port):
        """OLT card+port -> PON number. Falls back to None when the card is unmapped,
        which the caller must treat as a refusal rather than a zero."""
        if card is None or port is None:
            return None
        base = self.card_offsets.get(int(card))
        return None if base is None else base + int(port)

    def olt_port(self, card, port):
        return f"C{int(card):02d}P{int(port):02d}"

    def pole_label(self, code):
        """Bare pole code -> full pole label, e.g. G812 -> MOA.P.G812."""
        return f"{self.prefix}.P.{code}"

    def tab_name(self, olt_port, pon):
        return self.sheet["tab"].format(olt_port=olt_port, pon=pon)

    def match_rate(self, kind, labels):
        """Share of `labels` this profile's grammar understands. The gate that stops a
        Fibertime profile from rendering a HeroTel network into a Fibertime-shaped book."""
        labels = [x for x in labels if x]
        if not labels:
            return 0.0
        ok = sum(1 for x in labels if self.rx[kind].match(str(x).strip()))
        return ok / len(labels)


def load(name_or_path):
    """Load a profile by name (from profiles/) or by explicit path."""
    path = name_or_path
    if not os.path.exists(path):
        cand = os.path.join(PROFILE_DIR, f"{name_or_path}.json")
        if not os.path.exists(cand):
            avail = sorted(
                f[:-5] for f in os.listdir(PROFILE_DIR)
                if f.endswith(".json")) if os.path.isdir(PROFILE_DIR) else []
            raise ProfileError(f"no such profile: {name_or_path!r}. available: {avail}")
        path = cand
    with open(path, encoding="utf-8") as fh:
        try:
            data = json.load(fh)
        except json.JSONDecodeError as e:
            raise ProfileError(f"{path}: not valid JSON: {e}")
    # A profile may name a parent to inherit from — client defaults live there.
    parent = data.pop("extends", None)
    if parent:
        base = load(parent).data
        merged = json.loads(json.dumps(base))
        for k, v in data.items():
            if isinstance(v, dict) and isinstance(merged.get(k), dict):
                merged[k].update(v)
            else:
                merged[k] = v
        data = merged
    return Profile(data, path=path)


def available():
    if not os.path.isdir(PROFILE_DIR):
        return []
    return sorted(f[:-5] for f in os.listdir(PROFILE_DIR) if f.endswith(".json"))
