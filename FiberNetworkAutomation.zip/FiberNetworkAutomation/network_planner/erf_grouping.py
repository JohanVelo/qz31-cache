"""ERF parcel grouping and batching utilities."""

from typing import List, Tuple, Dict, Optional
import math

try:
    from qgis.core import (
        QgsVectorLayer,
        QgsFeature,
        QgsField,
        QgsGeometry,
        QgsRectangle,
        QgsPointXY,
        QgsDistanceArea,
        QgsProject,
        QgsSpatialIndex,
    )
    from qgis.PyQt.QtCore import QVariant
except ImportError:
    # For testing outside QGIS
    pass

# Try to import scientific libraries for advanced clustering
try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False

try:
    from sklearn.cluster import DBSCAN, KMeans
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


def sort_features_spatial(features: List[QgsFeature], top_to_bottom: bool = True, 
                          left_to_right: bool = True) -> List[QgsFeature]:
    """Sort features spatially from top to bottom, left to right.
    
    Args:
        features: List of features to sort
        top_to_bottom: If True, sort from top (max Y) to bottom (min Y)
        left_to_right: If True, sort from left (min X) to right (max X)
    
    Returns:
        Sorted list of features
    """
    feature_centroids = []
    
    for feature in features:
        geom = feature.geometry()
        if geom and not geom.isEmpty():
            centroid = geom.centroid().asPoint()
            feature_centroids.append((feature, centroid.x(), centroid.y()))
    
    # Sort by Y (top to bottom), then by X (left to right)
    # Top to bottom means higher Y values first (assuming standard CRS)
    sorted_features = sorted(
        feature_centroids,
        key=lambda item: (
            -item[2] if top_to_bottom else item[2],  # Y coordinate
            item[1] if left_to_right else -item[1]    # X coordinate
        )
    )
    
    return [item[0] for item in sorted_features]


def detect_parcel_orientation(features: List[QgsFeature]) -> dict:
    """Detect the dominant orientation and layout pattern of parcels.
    
    Analyzes parcel centroids to determine if they're organized in rows/columns
    and the predominant direction.
    
    Args:
        features: List of features to analyze
    
    Returns:
        Dictionary with orientation info: {'angle': float, 'is_row_dominant': bool, 
        'row_spacing': float, 'col_spacing': float}
    """
    if len(features) < 3:
        return {'angle': 0, 'is_row_dominant': True, 'row_spacing': 0, 'col_spacing': 0}
    
    # Extract centroids
    centroids = []
    for feature in features:
        geom = feature.geometry()
        if geom and not geom.isEmpty():
            centroid = geom.centroid().asPoint()
            centroids.append((centroid.x(), centroid.y()))
    
    if len(centroids) < 3:
        return {'angle': 0, 'is_row_dominant': True, 'row_spacing': 0, 'col_spacing': 0}
    
    # Calculate distances between nearest neighbors
    distances_x = []
    distances_y = []
    
    # Sort by X to find horizontal spacing
    sorted_by_x = sorted(centroids, key=lambda p: p[0])
    for i in range(len(sorted_by_x) - 1):
        dx = abs(sorted_by_x[i+1][0] - sorted_by_x[i][0])
        if dx > 1:  # Ignore very close points
            distances_x.append(dx)
    
    # Sort by Y to find vertical spacing
    sorted_by_y = sorted(centroids, key=lambda p: p[1])
    for i in range(len(sorted_by_y) - 1):
        dy = abs(sorted_by_y[i+1][1] - sorted_by_y[i][1])
        if dy > 1:  # Ignore very close points
            distances_y.append(dy)
    
    # Find predominant spacing
    avg_dx = sum(distances_x) / len(distances_x) if distances_x else 0
    avg_dy = sum(distances_y) / len(distances_y) if distances_y else 0
    
    # Determine if rows (horizontal) or columns (vertical) are dominant
    is_row_dominant = avg_dx > avg_dy
    
    # Calculate rotation angle (simplified - assumes grid is roughly aligned)
    angle = 0  # Could be enhanced with PCA analysis
    
    return {
        'angle': angle,
        'is_row_dominant': is_row_dominant,
        'row_spacing': avg_dy,
        'col_spacing': avg_dx
    }


def sort_features_by_rows(features: List[QgsFeature], row_spacing: float = None) -> List[QgsFeature]:
    """Sort features by rows (horizontal bands), then left to right within each row.
    
    Args:
        features: List of features to sort
        row_spacing: Estimated spacing between rows (auto-detected if None)
    
    Returns:
        Sorted list of features
    """
    feature_centroids = []
    
    for feature in features:
        geom = feature.geometry()
        if geom and not geom.isEmpty():
            centroid = geom.centroid().asPoint()
            feature_centroids.append((feature, centroid.x(), centroid.y()))
    
    if not feature_centroids:
        return features
    
    # Auto-detect row spacing if not provided
    if row_spacing is None:
        orientation = detect_parcel_orientation(features)
        row_spacing = orientation['row_spacing'] if orientation['row_spacing'] > 0 else 50
    
    # Group features into rows based on Y coordinate
    # Find min and max Y
    y_coords = [item[2] for item in feature_centroids]
    min_y = min(y_coords)
    max_y = max(y_coords)
    
    # Assign row numbers
    feature_with_rows = []
    for item in feature_centroids:
        feature, x, y = item
        # Row number based on Y position (higher Y = lower row number for top-to-bottom)
        row_num = int((max_y - y) / (row_spacing * 0.8)) if row_spacing > 0 else 0
        feature_with_rows.append((feature, row_num, x, y))
    
    # Sort by row number (top to bottom), then by X (left to right)
    sorted_features = sorted(feature_with_rows, key=lambda item: (item[1], item[2]))
    
    return [item[0] for item in sorted_features]


def sort_features_by_columns(features: List[QgsFeature], col_spacing: float = None) -> List[QgsFeature]:
    """Sort features by columns (vertical bands), then top to bottom within each column.
    
    Args:
        features: List of features to sort
        col_spacing: Estimated spacing between columns (auto-detected if None)
    
    Returns:
        Sorted list of features
    """
    feature_centroids = []
    
    for feature in features:
        geom = feature.geometry()
        if geom and not geom.isEmpty():
            centroid = geom.centroid().asPoint()
            feature_centroids.append((feature, centroid.x(), centroid.y()))
    
    if not feature_centroids:
        return features
    
    # Auto-detect column spacing if not provided
    if col_spacing is None:
        orientation = detect_parcel_orientation(features)
        col_spacing = orientation['col_spacing'] if orientation['col_spacing'] > 0 else 50
    
    # Group features into columns based on X coordinate
    x_coords = [item[1] for item in feature_centroids]
    min_x = min(x_coords)
    max_x = max(x_coords)
    
    # Assign column numbers
    feature_with_cols = []
    for item in feature_centroids:
        feature, x, y = item
        # Column number based on X position (left to right)
        col_num = int((x - min_x) / (col_spacing * 0.8)) if col_spacing > 0 else 0
        feature_with_cols.append((feature, col_num, x, y))
    
    # Sort by column number (left to right), then by Y (top to bottom)
    sorted_features = sorted(feature_with_cols, key=lambda item: (item[1], -item[3]))
    
    return [item[0] for item in sorted_features]


def sort_features_intelligent(features: List[QgsFeature]) -> List[QgsFeature]:
    """Intelligently sort features based on their detected orientation.
    
    Automatically detects whether parcels are organized in rows or columns
    and sorts accordingly for optimal network access.
    
    Args:
        features: List of features to sort
    
    Returns:
        Sorted list of features optimized for network access
    """
    if len(features) < 2:
        return features
    
    # Detect orientation
    orientation = detect_parcel_orientation(features)
    
    # Sort based on detected orientation
    if orientation['is_row_dominant']:
        # Parcels are organized in horizontal rows
        return sort_features_by_rows(features, orientation['row_spacing'])
    else:
        # Parcels are organized in vertical columns
        return sort_features_by_columns(features, orientation['col_spacing'])


def find_linear_paths(features: List[QgsFeature], tolerance: float = 50.0) -> List[List[QgsFeature]]:
    """Find linear paths of parcels that align along streets or fiber spans.
    
    Groups parcels into linear sequences that follow natural street/network paths.
    This is optimal for FTTH planning where fiber runs along streets.
    
    Args:
        features: List of features to analyze
        tolerance: Maximum perpendicular distance from line to consider aligned (in layer units)
    
    Returns:
        List of linear paths, where each path is a list of features
    """
    if len(features) < 2:
        return [features]
    
    # Extract centroids
    centroids_data = []
    for feature in features:
        geom = feature.geometry()
        if geom and not geom.isEmpty():
            centroid = geom.centroid().asPoint()
            centroids_data.append({
                'feature': feature,
                'x': centroid.x(),
                'y': centroid.y(),
                'assigned': False
            })
    
    if len(centroids_data) < 2:
        return [features]
    
    paths = []
    
    # Start from top-left corner
    centroids_data.sort(key=lambda p: (-p['y'], p['x']))
    
    for start_point in centroids_data:
        if start_point['assigned']:
            continue
        
        # Start a new path
        current_path = [start_point]
        start_point['assigned'] = True
        
        # Find the best next point iteratively
        while True:
            if len(current_path) == 0:
                break
            
            last_point = current_path[-1]
            best_next = None
            best_score = float('inf')
            
            # Look for the closest unassigned point that maintains linear direction
            for candidate in centroids_data:
                if candidate['assigned']:
                    continue
                
                # Calculate distance
                dx = candidate['x'] - last_point['x']
                dy = candidate['y'] - last_point['y']
                distance = math.sqrt(dx**2 + dy**2)
                
                if distance > tolerance * 3:  # Too far away
                    continue
                
                # If path has multiple points, check if candidate maintains direction
                if len(current_path) >= 2:
                    prev_point = current_path[-2]
                    
                    # Vector from previous to current
                    v1_x = last_point['x'] - prev_point['x']
                    v1_y = last_point['y'] - prev_point['y']
                    
                    # Vector from current to candidate
                    v2_x = candidate['x'] - last_point['x']
                    v2_y = candidate['y'] - last_point['y']
                    
                    # Calculate angle between vectors (dot product)
                    mag1 = math.sqrt(v1_x**2 + v1_y**2)
                    mag2 = math.sqrt(v2_x**2 + v2_y**2)
                    
                    if mag1 > 0 and mag2 > 0:
                        cos_angle = (v1_x * v2_x + v1_y * v2_y) / (mag1 * mag2)
                        angle_penalty = 1 - max(-1, min(1, cos_angle))  # 0 = same direction, 2 = opposite
                        
                        # Score combines distance and direction consistency
                        score = distance * (1 + angle_penalty * 2)
                    else:
                        score = distance
                else:
                    score = distance
                
                if score < best_score:
                    best_score = score
                    best_next = candidate
            
            # Add best next point to path
            if best_next and best_score < tolerance * 2:
                current_path.append(best_next)
                best_next['assigned'] = True
            else:
                break
        
        # Only keep paths with at least 2 features
        if len(current_path) >= 2:
            paths.append([p['feature'] for p in current_path])
        elif len(current_path) == 1:
            # Single isolated parcel - add as its own path
            paths.append([current_path[0]['feature']])
    
    return paths


def sort_features_along_paths(features: List[QgsFeature], paths: List[List[QgsFeature]] = None) -> List[QgsFeature]:
    """Sort features by following linear paths (streets/spans).
    
    This groups parcels that align along natural paths like streets,
    making it optimal for FTTH fiber deployment.
    
    Args:
        features: List of features to sort
        paths: Pre-computed paths (if None, will be calculated with default tolerance)
    
    Returns:
        Sorted list of features following linear paths
    """
    if len(features) < 2:
        return features
    
    # Find linear paths if not provided
    if paths is None:
        paths = find_linear_paths(features, tolerance=100.0)
    
    # Sort paths by their starting position (top-left to bottom-right)
    def path_sort_key(path):
        if not path:
            return (0, 0)
        first_geom = path[0].geometry()
        if first_geom and not first_geom.isEmpty():
            centroid = first_geom.centroid().asPoint()
            return (-centroid.y(), centroid.x())  # Top to bottom, left to right
        return (0, 0)
    
    paths.sort(key=path_sort_key)
    
    # Flatten paths into a single sorted list
    sorted_features = []
    for path in paths:
        sorted_features.extend(path)
    
    return sorted_features


def sort_features_along_route(features: List[QgsFeature], route_layer: QgsVectorLayer, 
                               max_snap_distance: float = 100.0) -> List[QgsFeature]:
    """Sort features by their position along a route/span network layer.
    
    Snaps each feature to the nearest point on the route layer and sorts them
    according to their position along the route network.
    
    Args:
        features: List of features (parcels/points) to sort
        route_layer: Line layer representing the fiber route/span network
        max_snap_distance: Maximum distance to snap features to route
    
    Returns:
        List of features sorted along the route
    """
    if not features or not route_layer:
        return features
    
    # Get all route segments
    route_features = list(route_layer.getFeatures())
    if not route_features:
        return features
    
    # Build network topology - find connected segments
    # Create a graph of connected route segments
    segment_graph = {}  # {segment_id: {'start': Point, 'end': Point, 'neighbors': []}}
    
    for idx, route_feature in enumerate(route_features):
        route_geom = route_feature.geometry()
        if not route_geom or route_geom.isEmpty():
            continue
        
        # Get start and end points of segment
        vertices = []
        if route_geom.isMultipart():
            multiline = route_geom.asMultiPolyline()
            if multiline and len(multiline) > 0:
                vertices = multiline[0]
        elif route_geom.type() == 1:
            vertices = route_geom.asPolyline()
        
        if len(vertices) >= 2:
            start_pt = vertices[0]
            end_pt = vertices[-1]
            segment_graph[idx] = {
                'start': start_pt,
                'end': end_pt,
                'geometry': route_geom,
                'vertices': vertices,
                'neighbors': [],
                'length': route_geom.length()
            }
    
    # Find connected segments (within tolerance of 0.1 units)
    connection_tolerance = 1.0
    for seg_id, seg_data in segment_graph.items():
        for other_id, other_data in segment_graph.items():
            if seg_id == other_id:
                continue
            
            # Check if segments connect
            def points_equal(p1, p2, tol):
                return math.sqrt((p1.x() - p2.x())**2 + (p1.y() - p2.y())**2) < tol
            
            if (points_equal(seg_data['end'], other_data['start'], connection_tolerance) or
                points_equal(seg_data['end'], other_data['end'], connection_tolerance) or
                points_equal(seg_data['start'], other_data['start'], connection_tolerance) or
                points_equal(seg_data['start'], other_data['end'], connection_tolerance)):
                if other_id not in seg_data['neighbors']:
                    seg_data['neighbors'].append(other_id)
    
    # Find the starting segment (segment with fewest connections, or leftmost/topmost)
    start_segment_id = min(segment_graph.keys(), 
                          key=lambda sid: (len(segment_graph[sid]['neighbors']), 
                                          -segment_graph[sid]['start'].y(),
                                          segment_graph[sid]['start'].x()))
    
    # Traverse network using depth-first search to create ordered route
    visited = set()
    ordered_segments = []
    
    def traverse_network(seg_id, cumulative_distance=0.0):
        if seg_id in visited:
            return
        
        visited.add(seg_id)
        seg_data = segment_graph[seg_id]
        ordered_segments.append({
            'id': seg_id,
            'data': seg_data,
            'cumulative_start': cumulative_distance,
            'cumulative_end': cumulative_distance + seg_data['length']
        })
        
        # Visit neighbors
        for neighbor_id in seg_data['neighbors']:
            if neighbor_id not in visited:
                traverse_network(neighbor_id, cumulative_distance + seg_data['length'])
    
    traverse_network(start_segment_id)
    
    # For each parcel/point, find nearest point on the ordered route
    feature_positions = []
    
    for feature in features:
        geom = feature.geometry()
        if not geom or geom.isEmpty():
            continue
        
        centroid = geom.centroid().asPoint()
        
        # Find nearest point across all ordered segments
        min_distance = float('inf')
        best_segment = None
        best_point_on_route = None
        best_distance_along = 0.0
        
        for ordered_seg in ordered_segments:
            seg_data = ordered_seg['data']
            route_geom = seg_data['geometry']
            
            # Find nearest point on this segment
            nearest = route_geom.nearestPoint(QgsGeometry.fromPointXY(centroid))
            if nearest.isEmpty():
                continue
            
            nearest_pt = nearest.asPoint()
            distance = math.sqrt(
                (centroid.x() - nearest_pt.x())**2 + 
                (centroid.y() - nearest_pt.y())**2
            )
            
            if distance < min_distance:
                # Calculate position within this segment
                vertices = seg_data['vertices']
                distance_within_segment = 0.0
                
                if len(vertices) >= 2:
                    for i in range(len(vertices) - 1):
                        v1 = vertices[i]
                        v2 = vertices[i + 1]
                        
                        seg_geom = QgsGeometry.fromPolylineXY([v1, v2])
                        nearest_on_seg = seg_geom.nearestPoint(QgsGeometry.fromPointXY(nearest_pt))
                        
                        if not nearest_on_seg.isEmpty():
                            nearest_seg_pt = nearest_on_seg.asPoint()
                            dist_to_seg = math.sqrt(
                                (nearest_pt.x() - nearest_seg_pt.x())**2 +
                                (nearest_pt.y() - nearest_seg_pt.y())**2
                            )
                            
                            if dist_to_seg < 0.1:
                                distance_within_segment += math.sqrt(
                                    (nearest_pt.x() - v1.x())**2 +
                                    (nearest_pt.y() - v1.y())**2
                                )
                                break
                            else:
                                distance_within_segment += math.sqrt(
                                    (v2.x() - v1.x())**2 + (v2.y() - v1.y())**2
                                )
                
                min_distance = distance
                best_segment = ordered_seg
                best_point_on_route = nearest_pt
                best_distance_along = ordered_seg['cumulative_start'] + distance_within_segment
        
        # Only include features within snap distance
        if min_distance <= max_snap_distance and best_point_on_route:
            feature_positions.append({
                'feature': feature,
                'distance_along_route': best_distance_along,
                'snap_distance': min_distance
            })
    
    # Sort by distance along the complete route
    feature_positions.sort(key=lambda x: x['distance_along_route'])
    
    # Extract sorted features
    sorted_features = [item['feature'] for item in feature_positions]
    
    return sorted_features


def assign_path_based_batches(source_layer: QgsVectorLayer, route_layer: QgsVectorLayer,
                               batch_size: int = 100, max_snap_distance: float = 100.0):
    """Create tight batches of features along a route, ensuring each batch stays together.
    
    Uses segment-based clustering to prevent batches from spanning disconnected network branches.
    
    Args:
        source_layer: Layer with features to batch (parcels or points)
        route_layer: Line layer representing the route/span network
        batch_size: Number of features per batch
        max_snap_distance: Maximum distance to snap features to route
    
    Returns:
        Tuple of (new_layer, total_features, total_batches)
    """
    from qgis.core import QgsVectorLayer, QgsFeature, QgsField, QgsGeometry
    from qgis.PyQt.QtCore import QVariant
    import math
    
    # Get all features
    features = list(source_layer.getFeatures())
    if not features:
        return None, 0, 0
    
    # Get all route segments and build network
    route_features = list(route_layer.getFeatures())
    if not route_features:
        return None, 0, 0
    
    # Build segment graph with connectivity
    segment_graph = {}
    for idx, route_feature in enumerate(route_features):
        route_geom = route_feature.geometry()
        if not route_geom or route_geom.isEmpty():
            continue
        
        vertices = []
        if route_geom.isMultipart():
            multiline = route_geom.asMultiPolyline()
            if multiline and len(multiline) > 0:
                vertices = multiline[0]
        elif route_geom.type() == 1:
            vertices = route_geom.asPolyline()
        
        if len(vertices) >= 2:
            segment_graph[idx] = {
                'geometry': route_geom,
                'vertices': vertices,
                'features': [],  # Features snapped to this segment
                'start': vertices[0],
                'end': vertices[-1],
                'neighbors': []  # Connected segment IDs
            }
    
    # Find connected segments (within tolerance)
    connection_tolerance = 1.0
    for seg_id, seg_data in segment_graph.items():
        for other_id, other_data in segment_graph.items():
            if seg_id == other_id:
                continue
            
            def points_equal(p1, p2, tol):
                return math.sqrt((p1.x() - p2.x())**2 + (p1.y() - p2.y())**2) < tol
            
            if (points_equal(seg_data['end'], other_data['start'], connection_tolerance) or
                points_equal(seg_data['end'], other_data['end'], connection_tolerance) or
                points_equal(seg_data['start'], other_data['start'], connection_tolerance) or
                points_equal(seg_data['start'], other_data['end'], connection_tolerance)):
                if other_id not in seg_data['neighbors']:
                    seg_data['neighbors'].append(other_id)
    
    # Snap each feature to nearest segment and store
    feature_segment_map = {}  # {feature_id: (segment_id, distance_along_segment)}
    
    for feature in features:
        geom = feature.geometry()
        if not geom or geom.isEmpty():
            continue
        
        centroid = geom.centroid().asPoint()
        
        # Find nearest segment
        min_distance = float('inf')
        best_segment_id = None
        best_distance_along = 0.0
        
        for seg_id, seg_data in segment_graph.items():
            route_geom = seg_data['geometry']
            nearest = route_geom.nearestPoint(QgsGeometry.fromPointXY(centroid))
            
            if nearest.isEmpty():
                continue
            
            nearest_pt = nearest.asPoint()
            distance = math.sqrt(
                (centroid.x() - nearest_pt.x())**2 + 
                (centroid.y() - nearest_pt.y())**2
            )
            
            if distance < min_distance and distance <= max_snap_distance:
                # Calculate distance along this segment
                vertices = seg_data['vertices']
                dist_along = 0.0
                
                for i in range(len(vertices) - 1):
                    v1, v2 = vertices[i], vertices[i + 1]
                    seg_geom = QgsGeometry.fromPolylineXY([v1, v2])
                    nearest_on_seg = seg_geom.nearestPoint(QgsGeometry.fromPointXY(nearest_pt))
                    
                    if not nearest_on_seg.isEmpty():
                        nearest_seg_pt = nearest_on_seg.asPoint()
                        if math.sqrt((nearest_pt.x() - nearest_seg_pt.x())**2 + 
                                   (nearest_pt.y() - nearest_seg_pt.y())**2) < 0.1:
                            dist_along += math.sqrt(
                                (nearest_pt.x() - v1.x())**2 + (nearest_pt.y() - v1.y())**2
                            )
                            break
                        else:
                            dist_along += math.sqrt(
                                (v2.x() - v1.x())**2 + (v2.y() - v1.y())**2
                            )
                
                min_distance = distance
                best_segment_id = seg_id
                best_distance_along = dist_along
        
        if best_segment_id is not None:
            segment_graph[best_segment_id]['features'].append(feature)
            feature_segment_map[feature.id()] = (best_segment_id, best_distance_along)
    
    # Sort features within each segment by distance along segment
    for seg_data in segment_graph.values():
        seg_data['features'].sort(
            key=lambda f: feature_segment_map[f.id()][1]
        )
    
    # Traverse network and create batches across connected segments
    visited_segments = set()
    batched_features = []
    batch_id = 1
    
    # Find starting segments (segments with fewer connections - likely branch ends)
    start_segments = sorted(segment_graph.keys(), 
                           key=lambda sid: (len(segment_graph[sid]['neighbors']),
                                          -segment_graph[sid]['start'].y(),
                                          segment_graph[sid]['start'].x()))
    
    for start_seg_id in start_segments:
        if start_seg_id in visited_segments:
            continue
        
        # Traverse this connected component using BFS
        current_batch = []
        segment_queue = [start_seg_id]
        component_visited = set()
        
        while segment_queue:
            seg_id = segment_queue.pop(0)
            
            if seg_id in component_visited:
                continue
            
            component_visited.add(seg_id)
            visited_segments.add(seg_id)
            
            # Add features from this segment to current batch
            for feature in segment_graph[seg_id]['features']:
                current_batch.append(feature)
                
                # Check if batch is full
                if len(current_batch) >= batch_size:
                    # Assign batch ID to all features in this batch
                    for feat in current_batch:
                        batched_features.append((feat, batch_id))
                    
                    batch_id += 1
                    current_batch = []
            
            # Add connected neighbors to queue
            for neighbor_id in segment_graph[seg_id]['neighbors']:
                if neighbor_id not in component_visited:
                    segment_queue.append(neighbor_id)
        
        # Assign remaining features in partial batch
        if current_batch:
            for feat in current_batch:
                batched_features.append((feat, batch_id))
            batch_id += 1
    
    # Create new scratch layer
    crs = source_layer.crs().authid()
    geom_type = source_layer.geometryType()
    geom_type_names = {0: "Point", 1: "LineString", 2: "Polygon"}
    geom_name = geom_type_names.get(geom_type, "Polygon")
    
    new_layer = QgsVectorLayer(f"{geom_name}?crs={crs}", 
                              f"{source_layer.name()} - Path Batched", 
                              "memory")
    provider = new_layer.dataProvider()
    
    # Copy original fields and add batch_id
    provider.addAttributes(source_layer.fields().toList())
    provider.addAttributes([QgsField('batch_id', QVariant.Int)])
    new_layer.updateFields()
    
    # Add features with batch assignments
    new_features = []
    for feat, batch_num in batched_features:
        new_feat = QgsFeature(new_layer.fields())
        new_feat.setGeometry(feat.geometry())
        
        # Copy original attributes
        for field in source_layer.fields():
            new_feat[field.name()] = feat[field.name()]
        
        # Assign batch
        new_feat['batch_id'] = batch_num
        new_features.append(new_feat)
    
    provider.addFeatures(new_features)
    new_layer.updateExtents()
    
    total_features = len(batched_features)
    total_batches = batch_id - 1
    
    return new_layer, total_features, total_batches


def group_features_into_batches(features: List[QgsFeature], batch_size: int = 100) -> dict:
    """Group features into batches of specified size.
    
    Args:
        features: Sorted list of features
        batch_size: Number of features per batch
    
    Returns:
        Dictionary mapping feature ID to batch number
    """
    feature_to_batch = {}
    
    for idx, feature in enumerate(features):
        batch_number = (idx // batch_size) + 1
        feature_to_batch[feature.id()] = batch_number
    
    return feature_to_batch


def identify_erf_layer(layers: List[QgsVectorLayer]) -> List[QgsVectorLayer]:
    """Identify layers that contain ERF/erven parcels.
    
    Args:
        layers: List of vector layers to check
    
    Returns:
        List of layers that likely contain ERF parcels
    """
    erf_keywords = ['erf', 'erven', 'parcel', 'stand', 'plot']
    matching_layers = []
    
    for layer in layers:
        if not layer or not layer.isValid():
            continue
        
        # Check layer name
        layer_name = layer.name().lower()
        if any(keyword in layer_name for keyword in erf_keywords):
            matching_layers.append(layer)
            continue
        
        # Check field names
        fields = layer.fields()
        for field in fields:
            field_name = field.name().lower()
            if any(keyword in field_name for keyword in erf_keywords):
                matching_layers.append(layer)
                break
    
    return matching_layers


def add_batch_field_to_layer(layer: QgsVectorLayer, field_name: str = 'batch_id') -> bool:
    """Add a batch_id field to a layer if it doesn't exist.
    
    Args:
        layer: Layer to modify
        field_name: Name of the batch field
    
    Returns:
        True if successful
    """
    # Check if field already exists
    if layer.fields().indexOf(field_name) >= 0:
        return True
    
    # Add the field
    provider = layer.dataProvider()
    provider.addAttributes([QgsField(field_name, QVariant.Int)])
    layer.updateFields()
    
    return True


def assign_batches_to_layer(layer: QgsVectorLayer, batch_size: int = 100, 
                           field_name: str = 'batch_id', 
                           use_path_sorting: bool = True,
                           path_tolerance: float = 50.0) -> Tuple[int, int]:
    """Assign batch numbers to features in a layer.
    
    Sorts parcels along linear paths (streets/fiber spans) for optimal
    FTTH network deployment, then assigns them to batches.
    
    Args:
        layer: Vector layer containing ERF parcels
        batch_size: Number of features per batch
        field_name: Name of the field to store batch ID
        use_path_sorting: If True, follows linear paths; if False, uses row/column sorting
        path_tolerance: Distance tolerance for path detection (in layer units)
    
    Returns:
        Tuple of (total_features, total_batches)
    """
    # Add batch field if it doesn't exist
    add_batch_field_to_layer(layer, field_name)
    field_idx = layer.fields().indexOf(field_name)
    
    # Get all features
    features = list(layer.getFeatures())
    total_features = len(features)
    
    if total_features == 0:
        return (0, 0)
    
    # Sort features spatially
    if use_path_sorting:
        sorted_features = sort_features_along_paths(features, path_tolerance)
    else:
        sorted_features = sort_features_intelligent(features)
    
    # Group into batches
    feature_to_batch = group_features_into_batches(sorted_features, batch_size)
    # Batch C: max() of an empty sequence raises ValueError — guard the case where
    # features exist but the batcher returns no assignments.
    total_batches = max(feature_to_batch.values()) if feature_to_batch else 0
    
    # Bulk write — one provider call instead of N per-feature edits (~10x faster).
    attr_map = {}
    for feature in features:
        batch_id = feature_to_batch.get(feature.id())
        if batch_id is not None:
            attr_map[feature.id()] = {field_idx: batch_id}
    if attr_map:
        layer.dataProvider().changeAttributeValues(attr_map)
        layer.triggerRepaint()

    return (total_features, total_batches)


def get_batch_statistics(layer: QgsVectorLayer, field_name: str = 'batch_id') -> dict:
    """Get statistics about batch assignments.
    
    Args:
        layer: Layer with batch assignments
        field_name: Name of the batch field
    
    Returns:
        Dictionary with batch statistics
    """
    field_idx = layer.fields().indexOf(field_name)
    if field_idx < 0:
        return {}
    
    batch_counts = {}
    batch_extents = {}
    
    for feature in layer.getFeatures():
        batch_id = feature.attribute(field_name)
        if batch_id is None:
            continue
        
        # Count features per batch
        batch_counts[batch_id] = batch_counts.get(batch_id, 0) + 1
        
        # Track extent per batch
        geom = feature.geometry()
        if geom and not geom.isEmpty():
            bbox = geom.boundingBox()
            if batch_id not in batch_extents:
                batch_extents[batch_id] = bbox
            else:
                batch_extents[batch_id].combineExtentWith(bbox)
    
    return {
        'total_batches': len(batch_counts),
        'batch_counts': batch_counts,
        'batch_extents': batch_extents,
        'avg_batch_size': sum(batch_counts.values()) / len(batch_counts) if batch_counts else 0
    }


def cluster_features_by_proximity(features: List[QgsFeature], max_distance: float = 100.0) -> Dict[int, int]:
    """Group features into clusters based on spatial proximity.
    
    Uses a simple clustering approach where adjacent/nearby features are grouped together.
    Features within max_distance of each other are assigned to the same cluster.
    
    Args:
        features: List of features to cluster
        max_distance: Maximum distance between features to consider them adjacent (in layer units)
    
    Returns:
        Dictionary mapping feature ID to cluster number
    """
    if not features:
        return {}
    
    feature_to_cluster = {}
    cluster_id = 0
    visited = set()
    
    # Sort features for processing
    sorted_features = sort_features_spatial(features)
    
    for feature in sorted_features:
        if feature.id() in visited:
            continue
        
        # Start a new cluster
        cluster_id += 1
        cluster_stack = [feature.id()]
        
        while cluster_stack:
            current_fid = cluster_stack.pop()
            if current_fid in visited:
                continue
            
            visited.add(current_fid)
            feature_to_cluster[current_fid] = cluster_id
            
            # Find current feature
            current_feature = None
            for f in features:
                if f.id() == current_fid:
                    current_feature = f
                    break
            
            if not current_feature or not current_feature.geometry():
                continue
            
            current_geom = current_feature.geometry()
            current_centroid = current_geom.centroid().asPoint() if not current_geom.isEmpty() else None
            
            if not current_centroid:
                continue
            
            # Find nearby features to add to this cluster
            for other_feature in sorted_features:
                if other_feature.id() in visited:
                    continue
                
                other_geom = other_feature.geometry()
                if other_geom.isEmpty():
                    continue
                
                other_centroid = other_geom.centroid().asPoint()
                
                # Calculate distance between centroids
                distance = math.sqrt(
                    (current_centroid.x() - other_centroid.x()) ** 2 +
                    (current_centroid.y() - other_centroid.y()) ** 2
                )
                
                # If within max_distance, add to cluster
                if distance <= max_distance:
                    cluster_stack.append(other_feature.id())
    
    return feature_to_cluster


def assign_clusters_to_layer(layer: QgsVectorLayer, max_distance: float = 100.0,
                            field_name: str = 'cluster_id') -> Tuple[int, int]:
    """Assign cluster groups to features in a layer based on spatial proximity.
    
    This groups adjacent/nearby ERF parcels together sequentially, useful for
    grouping parcels that are physically close to each other.
    
    Args:
        layer: Vector layer containing ERF parcels
        max_distance: Maximum distance between features to consider them adjacent (in layer units)
        field_name: Name of the field to store cluster ID
    
    Returns:
        Tuple of (total_features, total_clusters)
    """
    # Add cluster field if it doesn't exist
    if layer.fields().indexOf(field_name) < 0:
        provider = layer.dataProvider()
        provider.addAttributes([QgsField(field_name, QVariant.Int)])
        layer.updateFields()
    
    field_idx = layer.fields().indexOf(field_name)
    
    # Get all features
    features = list(layer.getFeatures())
    total_features = len(features)
    
    if total_features == 0:
        return (0, 0)
    
    # Cluster features by proximity
    feature_to_cluster = cluster_features_by_proximity(features, max_distance)
    total_clusters = max(feature_to_cluster.values()) if feature_to_cluster else 0
    
    # Bulk write — one provider call instead of N per-feature edits (~10x faster
    # on large layers; identical result). See OPTIMIZATION roadmap / CLAUDE.md.
    attr_map = {}
    for feature in features:
        cluster_id = feature_to_cluster.get(feature.id())
        if cluster_id is not None:
            attr_map[feature.id()] = {field_idx: cluster_id}
    if attr_map:
        layer.dataProvider().changeAttributeValues(attr_map)
        layer.triggerRepaint()

    return (total_features, total_clusters)


def filter_layer_by_batch(layer: QgsVectorLayer, batch_ids: List[int], 
                         field_name: str = 'batch_id') -> str:
    """Create a filter expression for specific batch IDs.
    
    Args:
        layer: Layer to filter
        batch_ids: List of batch IDs to include
        field_name: Name of the batch field
    
    Returns:
        Filter expression string
    """
    if not batch_ids:
        return ""
    
    batch_list = ','.join(str(b) for b in batch_ids)
    return f'"{field_name}" IN ({batch_list})'


# ========== ADVANCED CLUSTERING ALGORITHMS ==========

def cluster_dbscan(features: List[QgsFeature], eps: float = 100.0, min_samples: int = 3) -> Dict[int, int]:
    """Cluster features using DBSCAN (Density-Based Spatial Clustering).
    
    Automatically detects clusters based on density. Great for irregular layouts
    and automatic zone detection.
    
    Args:
        features: List of features to cluster
        eps: Maximum distance between two samples to be considered neighbors
        min_samples: Minimum number of samples in a neighborhood to form a cluster
    
    Returns:
        Dictionary mapping feature ID to cluster number (-1 for noise/outliers)
    """
    if not SKLEARN_AVAILABLE or not NUMPY_AVAILABLE:
        raise ImportError("sklearn and numpy are required for DBSCAN clustering. Install with: pip install scikit-learn numpy")
    
    if len(features) < min_samples:
        return {f.id(): 1 for f in features}
    
    # Extract centroids
    centroids = []
    feature_ids = []
    for feature in features:
        geom = feature.geometry()
        if geom and not geom.isEmpty():
            centroid = geom.centroid().asPoint()
            centroids.append([centroid.x(), centroid.y()])
            feature_ids.append(feature.id())
    
    if len(centroids) < min_samples:
        return {fid: 1 for fid in feature_ids}
    
    # Perform DBSCAN clustering
    coords = np.array(centroids)
    clustering = DBSCAN(eps=eps, min_samples=min_samples).fit(coords)
    
    # Map feature IDs to cluster labels
    # DBSCAN uses -1 for noise, we'll convert to separate clusters
    feature_to_cluster = {}
    max_cluster = max(clustering.labels_) if len(clustering.labels_) > 0 else 0
    
    for fid, label in zip(feature_ids, clustering.labels_):
        if label == -1:
            # Assign noise points to individual clusters
            max_cluster += 1
            feature_to_cluster[fid] = max_cluster
        else:
            feature_to_cluster[fid] = label + 1  # Start from 1 instead of 0
    
    return feature_to_cluster


def cluster_kmeans(features: List[QgsFeature], n_clusters: int = 10) -> Dict[int, int]:
    """Cluster features using K-Means clustering.
    
    Groups features into N zones automatically, ensuring balanced distribution.
    
    Args:
        features: List of features to cluster
        n_clusters: Number of clusters to create
    
    Returns:
        Dictionary mapping feature ID to cluster number
    """
    if not SKLEARN_AVAILABLE or not NUMPY_AVAILABLE:
        raise ImportError("sklearn and numpy are required for K-Means clustering. Install with: pip install scikit-learn numpy")
    
    if len(features) < n_clusters:
        # If fewer features than clusters, assign each to its own cluster
        return {f.id(): idx + 1 for idx, f in enumerate(features)}
    
    # Extract centroids
    centroids = []
    feature_ids = []
    for feature in features:
        geom = feature.geometry()
        if geom and not geom.isEmpty():
            centroid = geom.centroid().asPoint()
            centroids.append([centroid.x(), centroid.y()])
            feature_ids.append(feature.id())
    
    if len(centroids) < n_clusters:
        return {fid: idx + 1 for idx, fid in enumerate(feature_ids)}
    
    # Perform K-Means clustering
    coords = np.array(centroids)
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10).fit(coords)
    
    # Map feature IDs to cluster labels
    feature_to_cluster = {}
    for fid, label in zip(feature_ids, kmeans.labels_):
        feature_to_cluster[fid] = label + 1  # Start from 1 instead of 0
    
    return feature_to_cluster


def find_optimal_splitter_locations(features: List[QgsFeature], n_splitters: int = 10) -> List[QgsPointXY]:
    """Find optimal splitter locations using K-Means centroids.
    
    Calculates the best positions for splitters to minimize average distance to parcels.
    
    Args:
        features: List of features (parcels/demand points)
        n_splitters: Number of splitters to place
    
    Returns:
        List of optimal splitter locations as QgsPointXY
    """
    if not SKLEARN_AVAILABLE or not NUMPY_AVAILABLE:
        raise ImportError("sklearn and numpy are required for splitter optimization. Install with: pip install scikit-learn numpy")
    
    if len(features) < n_splitters:
        # If fewer features than splitters, place at each feature
        splitter_locations = []
        for feature in features:
            geom = feature.geometry()
            if geom and not geom.isEmpty():
                centroid = geom.centroid().asPoint()
                splitter_locations.append(centroid)
        return splitter_locations
    
    # Extract centroids
    centroids = []
    for feature in features:
        geom = feature.geometry()
        if geom and not geom.isEmpty():
            centroid = geom.centroid().asPoint()
            centroids.append([centroid.x(), centroid.y()])
    
    # Perform K-Means to find cluster centers
    coords = np.array(centroids)
    kmeans = KMeans(n_clusters=n_splitters, random_state=42, n_init=10).fit(coords)
    
    # Convert cluster centers to QgsPointXY
    splitter_locations = []
    for center in kmeans.cluster_centers_:
        splitter_locations.append(QgsPointXY(center[0], center[1]))
    
    return splitter_locations


def balance_pon_loads(features: List[QgsFeature], n_pons: int, max_per_pon: int = 64) -> Dict[int, int]:
    """Balance features across PONs to ensure even distribution.
    
    Distributes parcels/demand points evenly across PON zones, respecting
    maximum PON capacity (typically 32 or 64).
    
    Args:
        features: List of features to distribute
        n_pons: Number of PON zones
        max_per_pon: Maximum features per PON (default 64)
    
    Returns:
        Dictionary mapping feature ID to PON number
    """
    if not SKLEARN_AVAILABLE or not NUMPY_AVAILABLE:
        # Fallback to simple round-robin distribution
        feature_to_pon = {}
        for idx, feature in enumerate(features):
            pon_id = (idx % n_pons) + 1
            feature_to_pon[feature.id()] = pon_id
        return feature_to_pon
    
    # Use K-Means for spatial clustering
    initial_clusters = cluster_kmeans(features, n_pons)
    
    # Count features per cluster
    cluster_counts = {}
    for fid, cluster_id in initial_clusters.items():
        cluster_counts[cluster_id] = cluster_counts.get(cluster_id, 0) + 1
    
    # Check if any cluster exceeds max_per_pon
    feature_to_pon = {}
    pon_counter = 0
    
    for cluster_id in sorted(cluster_counts.keys()):
        count = cluster_counts[cluster_id]
        
        if count <= max_per_pon:
            # Cluster fits in one PON
            pon_counter += 1
            for fid, cid in initial_clusters.items():
                if cid == cluster_id:
                    feature_to_pon[fid] = pon_counter
        else:
            # Split cluster into multiple PONs
            cluster_features = [f for f in features if initial_clusters.get(f.id()) == cluster_id]
            sub_pons = (count + max_per_pon - 1) // max_per_pon  # Ceiling division
            
            # Re-cluster this cluster
            sub_clusters = cluster_kmeans(cluster_features, sub_pons)
            for fid, sub_cid in sub_clusters.items():
                feature_to_pon[fid] = pon_counter + sub_cid
            
            pon_counter += sub_pons
    
    return feature_to_pon


def minimize_cable_length_clustering(features: List[QgsFeature], n_zones: int) -> Tuple[Dict[int, int], float]:
    """Cluster features to minimize total cable length.
    
    Uses K-Means clustering and calculates total distance from each feature
    to its cluster center (splitter location).
    
    Args:
        features: List of features to cluster
        n_zones: Number of zones/splitters
    
    Returns:
        Tuple of (feature_to_zone_mapping, total_cable_length)
    """
    if not SKLEARN_AVAILABLE or not NUMPY_AVAILABLE:
        raise ImportError("sklearn and numpy are required for cable length optimization. Install with: pip install scikit-learn numpy")
    
    # Extract centroids
    centroids = []
    feature_ids = []
    for feature in features:
        geom = feature.geometry()
        if geom and not geom.isEmpty():
            centroid = geom.centroid().asPoint()
            centroids.append([centroid.x(), centroid.y()])
            feature_ids.append(feature.id())
    
    if len(centroids) < n_zones:
        # Not enough features for clustering
        total_length = 0.0
        return {fid: idx + 1 for idx, fid in enumerate(feature_ids)}, total_length
    
    # Perform K-Means clustering
    coords = np.array(centroids)
    kmeans = KMeans(n_clusters=n_zones, random_state=42, n_init=10).fit(coords)
    
    # Calculate total cable length (sum of distances from each point to its cluster center)
    total_cable_length = 0.0
    feature_to_zone = {}
    
    for idx, (fid, label) in enumerate(zip(feature_ids, kmeans.labels_)):
        feature_to_zone[fid] = label + 1
        
        # Calculate distance to cluster center
        point = coords[idx]
        center = kmeans.cluster_centers_[label]
        distance = np.sqrt(np.sum((point - center) ** 2))
        total_cable_length += distance
    
    return feature_to_zone, total_cable_length


def assign_clusters_dbscan(layer: QgsVectorLayer, eps: float = 100.0, 
                           min_samples: int = 3, field_name: str = 'cluster_id') -> Tuple[int, int]:
    """Assign DBSCAN clusters to a layer.
    
    Args:
        layer: Vector layer to cluster
        eps: Maximum distance between neighbors
        min_samples: Minimum samples to form a cluster
        field_name: Field name for cluster ID
    
    Returns:
        Tuple of (total_features, total_clusters)
    """
    # Add cluster field if it doesn't exist
    if layer.fields().indexOf(field_name) < 0:
        provider = layer.dataProvider()
        provider.addAttributes([QgsField(field_name, QVariant.Int)])
        layer.updateFields()
    
    field_idx = layer.fields().indexOf(field_name)
    
    # Get all features
    features = list(layer.getFeatures())
    total_features = len(features)
    
    if total_features == 0:
        return (0, 0)
    
    # Perform DBSCAN clustering
    feature_to_cluster = cluster_dbscan(features, eps, min_samples)
    total_clusters = len(set(feature_to_cluster.values()))
    
    # Bulk write — one provider call instead of N per-feature edits (~10x faster).
    attr_map = {}
    for feature in features:
        cluster_id = feature_to_cluster.get(feature.id())
        if cluster_id is not None:
            attr_map[feature.id()] = {field_idx: cluster_id}
    if attr_map:
        layer.dataProvider().changeAttributeValues(attr_map)
        layer.triggerRepaint()

    return (total_features, total_clusters)


def assign_clusters_kmeans(layer: QgsVectorLayer, n_clusters: int = 10,
                           field_name: str = 'cluster_id') -> Tuple[int, int]:
    """Assign K-Means clusters to a layer.
    
    Args:
        layer: Vector layer to cluster
        n_clusters: Number of clusters to create
        field_name: Field name for cluster ID
    
    Returns:
        Tuple of (total_features, total_clusters)
    """
    # Add cluster field if it doesn't exist
    if layer.fields().indexOf(field_name) < 0:
        provider = layer.dataProvider()
        provider.addAttributes([QgsField(field_name, QVariant.Int)])
        layer.updateFields()
    
    field_idx = layer.fields().indexOf(field_name)
    
    # Get all features
    features = list(layer.getFeatures())
    total_features = len(features)
    
    if total_features == 0:
        return (0, 0)
    
    # Perform K-Means clustering
    feature_to_cluster = cluster_kmeans(features, n_clusters)
    total_clusters = len(set(feature_to_cluster.values()))
    
    # Bulk write — one provider call instead of N per-feature edits (~10x faster).
    attr_map = {}
    for feature in features:
        cluster_id = feature_to_cluster.get(feature.id())
        if cluster_id is not None:
            attr_map[feature.id()] = {field_idx: cluster_id}
    if attr_map:
        layer.dataProvider().changeAttributeValues(attr_map)
        layer.triggerRepaint()

    return (total_features, total_clusters)


# Kill-switch for the spatial nearest-pool optimisation. True = fast O(n log n) path
# (proven byte-identical to the plain scan via perf_harness.compare()). Flip to False
# to instantly fall back to the plain min() scan if ever needed — same output either way.
_USE_NEAREST_POOL = True


class _NearestPool:
    """Spatial-index pool for repeated 'nearest-unassigned-point-to-a-moving-centroid'
    queries during group building.

    Returns the SAME point a `min(remaining, key=(dist², id))` linear scan would — the
    (dist², id) tiebreak is applied among the k nearest the index returns, and there is
    a linear-min fallback — so group membership is BYTE-IDENTICAL to the un-optimised
    path. The win is purely speed: each pick is O(log n) instead of O(n), so filling
    groups in one large block goes from O(n²) to O(n log n). On a dense township
    (~13k erven) that is the difference between a ~20 s Cluster-Erven freeze and ~1 s.
    Used ONLY for large no-road buckets/blocks; small ones keep the plain min() (no
    index-build overhead, same result)."""
    __slots__ = ("_by_fid", "_feat", "_idx")

    def __init__(self, points):
        self._idx = QgsSpatialIndex()
        self._by_fid = {}
        self._feat = {}
        for p in points:
            fid = int(p['id'])
            f = QgsFeature(fid)
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(p['x'], p['y'])))
            self._idx.insertFeature(f)
            self._by_fid[fid] = p
            self._feat[fid] = f

    def remove(self, point):
        fid = int(point['id'])
        f = self._feat.pop(fid, None)
        self._by_fid.pop(fid, None)
        if f is not None:
            try:
                self._idx.deleteFeature(f)
            except Exception:
                pass

    def take_nearest(self, cx, cy, k=24):
        """Pop + return the (dist², id)-minimum remaining point, or None if empty."""
        if not self._by_fid:
            return None
        best = None
        best_key = None
        try:
            near = self._idx.nearestNeighbor(QgsPointXY(cx, cy), min(k, len(self._by_fid)))
            for fid in near:
                c = self._by_fid.get(fid)
                if c is None:
                    continue
                key = ((c['x'] - cx) ** 2 + (c['y'] - cy) ** 2, c['id'])
                if best_key is None or key < best_key:
                    best_key = key
                    best = c
        except Exception:
            best = None
        if best is None:
            # Index returned nothing usable — linear fallback so a point is NEVER
            # silently dropped (keeps output identical to the plain min()).
            best = min(self._by_fid.values(),
                       key=lambda c: ((c['x'] - cx) ** 2 + (c['y'] - cy) ** 2, c['id']))
        self.remove(best)
        return best


def cluster_tight_groups_of_8(features: List[QgsFeature], route_layer: Optional[QgsVectorLayer] = None, max_snap_distance: float = 100.0, target_size: int = 8, span_proximity_limit: float = 100.0, adjacency_distance: float = 120.0, gap_tolerance_multiplier: float = 3.0, progress_callback=None, road_layer: Optional[QgsVectorLayer] = None, demand_crs=None) -> Dict[int, int]:
    """Create tight spatial groups of a specified target size, respecting road boundaries.

    Detects natural blocks/clusters and groups within each block.
    When road_layer is supplied, two demand points can only share a group if the
    straight line between them does not cross any road feature.
    When route_layer is supplied, demand points closest to the span line are seeded
    first so that groups naturally work back toward the nearest span attachment.

    Args:
        features:     List of features to cluster.
        route_layer:  Span/route layer. Used to orient group seeds toward span line.
        target_size:  Target number of features per group (default: 8).
        road_layer:   Road/street layer used as a drop-cable barrier.
        demand_crs:   CRS of the demand layer (QgsCoordinateReferenceSystem).
                      Required for correct road-crossing detection when the road
                      layer is in a different CRS than the demand points.
    """
    if not features:
        return {}

    # Batch B: the metre thresholds below (span_proximity_limit / adjacency_distance
    # / max_snap_distance) are compared directly against raw coordinates. On a
    # GEOGRAPHIC CRS (EPSG:4326) coordinates are DEGREES, so a "150 m" corridor became
    # 150 degrees → the proximity filter was a no-op and points clustered across the
    # whole map. Convert metres→degrees when the demand CRS is geographic; projected
    # (metric) CRS is left exactly as before (no behaviour change there).
    try:
        if demand_crs is not None and demand_crs.isValid() and demand_crs.isGeographic():
            import math as _m_b
            _lat_sum = 0.0
            _lat_n = 0
            for _bf in features:
                _bg = _bf.geometry()
                if _bg and not _bg.isEmpty():
                    _lat_sum += _bg.centroid().asPoint().y()
                    _lat_n += 1
                    if _lat_n >= 200:
                        break
            _lat0 = (_lat_sum / _lat_n) if _lat_n else 0.0
            _m_per_deg = 111320.0 * max(0.1, _m_b.cos(_m_b.radians(_lat0)))
            span_proximity_limit = span_proximity_limit / _m_per_deg
            adjacency_distance = adjacency_distance / _m_per_deg
            max_snap_distance = max_snap_distance / _m_per_deg
    except Exception:
        pass

    # Build road spatial index for crossing checks
    road_geom_by_id: Dict[int, QgsGeometry] = {}
    road_index = None
    _road_transform = None  # demand CRS → road CRS transform (if CRS differ)
    if road_layer is not None:
        try:
            from qgis.core import QgsCoordinateTransform, QgsProject as _QgsProject
            road_crs = road_layer.crs()
            if demand_crs is not None and demand_crs.isValid() and road_crs.isValid() and demand_crs != road_crs:
                _road_transform = QgsCoordinateTransform(demand_crs, road_crs, _QgsProject.instance())
            road_index = QgsSpatialIndex()
            for rf in road_layer.getFeatures():
                rg = rf.geometry()
                if rg and not rg.isEmpty():
                    road_geom_by_id[rf.id()] = rg
                    road_index.addFeature(rf)
        except Exception:
            road_index = None
            road_geom_by_id = {}

    def _crosses_road(x1: float, y1: float, x2: float, y2: float) -> bool:
        """Return True if the line from (x1,y1) to (x2,y2) intersects any road geometry.

        Handles CRS mismatch by transforming the line to road CRS.
        Uses intersects()+touches() rather than crosses() to reliably detect all
        cases including diagonal and near-miss crossings.
        """
        if road_index is None or not road_geom_by_id:
            return False
        if _road_transform is not None:
            try:
                p1 = _road_transform.transform(QgsPointXY(x1, y1))
                p2 = _road_transform.transform(QgsPointXY(x2, y2))
            except Exception:
                p1, p2 = QgsPointXY(x1, y1), QgsPointXY(x2, y2)
        else:
            p1, p2 = QgsPointXY(x1, y1), QgsPointXY(x2, y2)
        line = QgsGeometry.fromPolylineXY([p1, p2])
        # Expand bbox slightly to catch near-edge roads
        bbox = line.boundingBox()
        bbox.grow(max(abs(p2.x() - p1.x()), abs(p2.y() - p1.y())) * 0.05 + 1e-9)
        candidates = road_index.intersects(bbox)
        for fid in candidates:
            rg = road_geom_by_id.get(fid)
            if rg is None:
                continue
            # intersects() + not touches() = true crossing (not just shared endpoint)
            if line.intersects(rg) and not line.touches(rg):
                return True
        return False

    # Memoised point-pair road-crossing: the batch-expansion loops below test the
    # same (candidate, batch-member) pairs repeatedly across grow steps. Caching by
    # the unordered feature-id pair turns each expensive intersects/touches geometry
    # check into a one-time cost. Behaviour-identical to calling _crosses_road.
    _xroad_cache = {}

    def _xroad(a, b):
        if road_index is None:
            return False
        ai, bi = a['id'], b['id']
        key = (ai, bi) if ai <= bi else (bi, ai)
        v = _xroad_cache.get(key)
        if v is None:
            v = _crosses_road(a['x'], a['y'], b['x'], b['y'])
            _xroad_cache[key] = v
        return v

    feature_data = []
    _n_features = len(features)

    for _fi, feature in enumerate(features):
        if progress_callback and _fi % 10 == 0:
            progress_callback(_fi + 1, _n_features, 'Extracting')
        geom = feature.geometry()
        if geom and not geom.isEmpty():
            centroid = geom.centroid().asPoint()
            feature_data.append({
                'id': feature.id(),
                'x': centroid.x(),
                'y': centroid.y(),
                'assigned': False,
            })

    if not feature_data:
        return {}

    feature_to_group: Dict[int, int] = {}
    current_group = 1

    # =========================================================================
    # PHASE 1: Span-segment grouping
    # =========================================================================
    # Algorithm:
    #   1. Extract every individual segment (p1→p2) from all span features.
    #   2. For each demand point find its nearest span segment and compute:
    #        - perpendicular distance to that segment
    #        - projection parameter t (0..1 along segment)
    #      Only keep the assignment if perp distance ≤ span_proximity_limit.
    #   3. Group demand points by their assigned span segment ID.
    #   4. Within each segment group, sort by projection t (order along span)
    #      then greedily fill road-aware batches of ≤ target_size.
    #
    # This means:
    #   • Groups follow each span branch naturally (separate segment → separate groups)
    #   • Groups are ordered along the span, splitters sit close to the span
    #   • Road barrier is respected within every batch
    # =========================================================================
    if route_layer is not None:
        # --- Step 1: extract span segments (Distribution only) --------------
        # seg_list: list of (seg_id, p1x, p1y, p2x, p2y)
        # Only process spans with Cable Type = 'Distribution' — skip Feeder,
        # Sub Feeder, Backhaul. If no Cable Type field, process all spans.
        seg_list = []
        try:
            _span_fields = [f.name() for f in route_layer.fields()]
            _has_cable_type = 'Cable Type' in _span_fields
            seg_id = 0
            _dist_count = 0
            _skipped_count = 0
            
            for _sf in route_layer.getFeatures():
                # Filter: only Distribution spans (case-insensitive)
                if _has_cable_type:
                    try:
                        _ct = _sf['Cable Type']
                        _ct_str = str(_ct).strip().lower() if _ct is not None else ''
                    except Exception:
                        _ct_str = ''
                    if _ct_str != 'distribution':
                        _skipped_count += 1
                        continue
                    _dist_count += 1
                
                _sg = _sf.geometry()
                if _sg is None or _sg.isEmpty():
                    continue
                lines = _sg.asMultiPolyline() if _sg.isMultipart() else [_sg.asPolyline()]
                for line in lines:
                    for i in range(len(line) - 1):
                        p1, p2 = line[i], line[i + 1]
                        seg_list.append((seg_id, p1.x(), p1.y(), p2.x(), p2.y()))
                        seg_id += 1
            
            if _has_cable_type and progress_callback:
                progress_callback(
                    0, 0, 
                    f'Filtered to {_dist_count} Distribution spans ({_skipped_count} non-Distribution skipped)')
        except Exception:
            seg_list = []

        if seg_list:
            # --- Step 2: build spatial index over segment bboxes -------------
            _seg_index = QgsSpatialIndex()
            _seg_geom_by_id: Dict[int, QgsGeometry] = {}
            for sid, x1, y1, x2, y2 in seg_list:
                _sf2 = QgsFeature(sid)
                _sf2.setGeometry(QgsGeometry.fromPolylineXY([QgsPointXY(x1, y1), QgsPointXY(x2, y2)]))
                _seg_index.addFeature(_sf2)
                _seg_geom_by_id[sid] = _sf2.geometry()

            # --- Step 3: assign each demand point to nearest span segment ----
            # seg_bucket[seg_id] = list of (t, fd)  where t = projection 0..1
            seg_bucket: Dict[int, list] = {}
            _corridor = span_proximity_limit

            _n_dem = len(feature_data)
            for _di, fd in enumerate(feature_data):
                if progress_callback and _di % 30 == 0:
                    progress_callback(_di + 1, _n_dem, 'Assigning to span')

                _pt_geom = QgsGeometry.fromPointXY(QgsPointXY(fd['x'], fd['y']))
                # Pre-filter segments within corridor bbox
                _bbox = QgsRectangle(
                    fd['x'] - _corridor, fd['y'] - _corridor,
                    fd['x'] + _corridor, fd['y'] + _corridor
                )
                _cands = _seg_index.intersects(_bbox)
                if not _cands:
                    continue

                best_seg = None
                best_perp = float('inf')
                best_t = 0.0

                for sid in _cands:
                    # Find nearest point on this segment
                    sg = _seg_geom_by_id.get(sid)
                    if sg is None:
                        continue
                    snap = sg.nearestPoint(_pt_geom)
                    if snap.isEmpty():
                        continue
                    sp = snap.asPoint()
                    perp = math.sqrt((fd['x'] - sp.x()) ** 2 + (fd['y'] - sp.y()) ** 2)
                    if perp < best_perp:
                        # Compute t (projection parameter 0..1 along this segment)
                        # Look up segment endpoints
                        seg_verts = sg.asPolyline()
                        if len(seg_verts) >= 2:
                            sx1, sy1 = seg_verts[0].x(), seg_verts[0].y()
                            sx2, sy2 = seg_verts[1].x(), seg_verts[1].y()
                            seg_len_sq = (sx2 - sx1) ** 2 + (sy2 - sy1) ** 2
                            if seg_len_sq > 0:
                                t = ((sp.x() - sx1) * (sx2 - sx1) + (sp.y() - sy1) * (sy2 - sy1)) / seg_len_sq
                                t = max(0.0, min(1.0, t))
                            else:
                                t = 0.0
                        else:
                            t = 0.0
                        best_perp = perp
                        best_seg = sid
                        best_t = t

                if best_seg is not None and best_perp <= _corridor:
                    fd['seg_t'] = best_t
                    seg_bucket.setdefault(best_seg, []).append((best_t, fd))

            # --- Step 4: form groups within each segment bucket --------------
            for sid in sorted(seg_bucket):
                items = seg_bucket[sid]
                # Sort by projection parameter t — demand points ordered along span.
                # id tiebreaker keeps the order deterministic when two points share t.
                items.sort(key=lambda x: (x[0], x[1]['id']))
                bucket_fds = [item[1] for item in items]

                for fd in bucket_fds:
                    fd['seg_assigned'] = False

                # Pre-compute even group sizes with a STRICT cap of target_size.
                # Use ceil so every group stays ≤ target_size (no remainders folded in).
                n_bucket = len(bucket_fds)
                n_groups = max(1, math.ceil(n_bucket / target_size))
                base_sz = n_bucket // n_groups
                extra = n_bucket % n_groups
                group_sizes = [base_sz + (1 if i < extra else 0) for i in range(n_groups)]

                # Large no-road buckets: O(log n) spatial pool for the nearest-pick
                # (identical output to the min() scan, just fast). Small buckets / the
                # road path keep the plain scan (no index-build overhead, same result).
                _pool = (_NearestPool(bucket_fds)
                         if (_USE_NEAREST_POOL and road_index is None and len(bucket_fds) > 48) else None)
                # Forward seed cursor for the pool path (identical seed sequence to the
                # scan; the no-road path never un-assigns so the cursor only advances).
                _seed_cur = [0]
                for grp_sz in group_sizes:
                    if _pool is not None:
                        while _seed_cur[0] < len(bucket_fds) and bucket_fds[_seed_cur[0]].get('seg_assigned'):
                            _seed_cur[0] += 1
                        seed = bucket_fds[_seed_cur[0]] if _seed_cur[0] < len(bucket_fds) else None
                    else:
                        seed = next((f for f in bucket_fds if not f.get('seg_assigned')), None)
                    if not seed:
                        break
                    batch = [seed]
                    seed['seg_assigned'] = True
                    if _pool is not None:
                        _pool.remove(seed)

                    # Expand batch by nearest unassigned point to current centroid,
                    # road-aware, up to grp_sz. Rank candidates by distance FIRST, then
                    # road-check nearest-first and STOP at the first acceptable one
                    # (road-check only until one passes — the O(n²) road check that froze
                    # QGIS). The spatial pool (above) collapses the no-road scan to O(log n).
                    while len(batch) < grp_sz:
                        bcx = sum(f['x'] for f in batch) / len(batch)
                        bcy = sum(f['y'] for f in batch) / len(batch)
                        if _pool is not None:
                            best_cand = _pool.take_nearest(bcx, bcy)
                            if best_cand is None:
                                break
                            batch.append(best_cand)
                            best_cand['seg_assigned'] = True
                            continue
                        cands = [c for c in bucket_fds if not c.get('seg_assigned')]
                        if not cands:
                            break
                        _key = lambda c: ((c['x'] - bcx) ** 2 + (c['y'] - bcy) ** 2, c['id'])
                        best_cand = None
                        if road_index is None:
                            # No road barrier → just the nearest by (dist,id). min() is
                            # O(n) and returns the SAME element sort()[0] would (identical
                            # output), without the per-step full sort.
                            best_cand = min(cands, key=_key)
                        else:
                            # Road barrier → rank by (dist,id) then take the first that
                            # isn't blocked (road-check only until one passes).
                            cands.sort(key=_key)
                            for cand in cands:
                                if any(_xroad(cand, bm) for bm in batch):
                                    continue
                                best_cand = cand
                                break
                        if best_cand:
                            batch.append(best_cand)
                            best_cand['seg_assigned'] = True
                        else:
                            break

                    # --- Validate batch: check drop cable (demand→splitter) road crossings ---
                    # Only runs when a road_layer was supplied. Groups are ALWAYS committed
                    # even if some members are blocked — blocked members return to pool.
                    if road_index is not None:
                        try:
                            # Estimate splitter location = centroid projected onto this span segment
                            _bcx_final = sum(f['x'] for f in batch) / len(batch)
                            _bcy_final = sum(f['y'] for f in batch) / len(batch)
                            _span_geom = _seg_geom_by_id.get(sid)
                            _splitter_x, _splitter_y = _bcx_final, _bcy_final
                            if _span_geom:
                                _cent_pt = QgsGeometry.fromPointXY(QgsPointXY(_bcx_final, _bcy_final))
                                _snap = _span_geom.nearestPoint(_cent_pt)
                                if _snap and not _snap.isEmpty():
                                    _sp = _snap.asPoint()
                                    _splitter_x, _splitter_y = _sp.x(), _sp.y()
                            # Remove demands whose drop cable would cross a road
                            _kept = []
                            for f in batch:
                                if _crosses_road(f['x'], f['y'], _splitter_x, _splitter_y):
                                    f['seg_assigned'] = False  # return to unassigned pool
                                else:
                                    _kept.append(f)
                            batch = _kept
                        except Exception:
                            pass  # on any error keep batch intact

                    # Commit group — always commit what we have (post-processing handles tiny groups)
                    if batch:
                        for f in batch:
                            f['assigned'] = True
                            feature_to_group[f['id']] = current_group
                        current_group += 1

    # =========================================================================
    # PHASE 2: Proximity fallback for unassigned demand points
    # =========================================================================
    # Demand points that had no span segment within corridor distance are grouped
    # by geographic proximity (road-aware, same max group size).
    unassigned = [fd for fd in feature_data if not fd['assigned']]
    # Deterministic order (independent of input feature order / hash seed) so the
    # whole proximity phase — block numbering, seeds, group numbers — is reproducible.
    unassigned.sort(key=lambda f: (round(f['y'], 6), round(f['x'], 6), f['id']))
    if unassigned:
        if progress_callback:
            progress_callback(0, len(unassigned), 'Proximity fallback')

        # Estimate typical neighbour distance for block detection.
        # Seeded local RNG → reproducible sample (the global random module is
        # unseeded, which made the gap estimate — and thus the whole grouping —
        # change on every run/session). A fixed seed gives one canonical design.
        import random as _rnd
        _smp = (unassigned if len(unassigned) <= 80
                else _rnd.Random(1234567).sample(unassigned, 80))
        _dists = []
        for f1 in _smp:
            _md = float('inf')
            for f2 in _smp:
                if f1['id'] == f2['id']:
                    continue
                _d = math.sqrt((f1['x'] - f2['x']) ** 2 + (f1['y'] - f2['y']) ** 2)
                if _d < _md:
                    _md = _d
            if _md != float('inf'):
                _dists.append(_md)
        _gap = (sum(_dists) / len(_dists) * gap_tolerance_multiplier) if _dists else adjacency_distance

        # Union-Find geographic blocks
        _par = {f['id']: f['id'] for f in unassigned}
        def _f(x):
            while _par[x] != x:
                _par[x] = _par[_par[x]]
                x = _par[x]
            return x
        def _u(a, b):
            a, b = _f(a), _f(b)
            if a != b:
                _par[a] = b

        _cell = max(_gap, 1.0)
        _grid: Dict = {}
        for f in unassigned:
            cx, cy = int(f['x'] // _cell), int(f['y'] // _cell)
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    for nbr in _grid.get((cx + dx, cy + dy), []):
                        if math.sqrt((f['x'] - nbr['x']) ** 2 + (f['y'] - nbr['y']) ** 2) <= _gap:
                            _u(f['id'], nbr['id'])
            _grid.setdefault((cx, cy), []).append(f)

        _blk_map: Dict = {}
        _blk_ctr = [1]
        for f in unassigned:
            r = _f(f['id'])
            if r not in _blk_map:
                _blk_map[r] = _blk_ctr[0]
                _blk_ctr[0] += 1
            f['blk'] = _blk_map[r]

        n_blks = _blk_ctr[0] - 1
        # Pre-bucket unassigned by block ID in ONE pass — the old per-block
        # `[f for f in unassigned if f['blk']==blk_id]` re-scanned ALL unassigned for
        # every block, i.e. O(blocks × n) = O(n²) (the real Cluster-Erven freeze on
        # large layers). This is O(n) and yields the identical per-block member set.
        _blocks_by_id: Dict[int, list] = {}
        for f in unassigned:
            _blocks_by_id.setdefault(f.get('blk'), []).append(f)
        for blk_id in range(1, n_blks + 1):
            blk = _blocks_by_id.get(blk_id, [])
            blk.sort(key=lambda f: (-f['y'], f['x'], f['id']))
            for f in blk:
                f['prox_assigned'] = False

            # Pre-compute even group sizes (same strict-cap logic as Phase 1)
            n_blk = len(blk)
            n_groups = max(1, math.ceil(n_blk / target_size))
            base_sz = n_blk // n_groups
            extra = n_blk % n_groups
            group_sizes = [base_sz + (1 if i < extra else 0) for i in range(n_groups)]

            # Large no-road blocks: O(log n) spatial pool (identical output, fast).
            _pool = (_NearestPool(blk)
                     if (_USE_NEAREST_POOL and road_index is None and len(blk) > 48) else None)
            # Forward seed cursor for the pool path: the seed is the first unassigned
            # point in sorted order; the no-road path never un-assigns, so a cursor that
            # only advances past assigned points yields the IDENTICAL seed sequence as
            # `next(f for f in blk if not assigned)` — but O(n) total instead of O(n²).
            _seed_cur = [0]
            for grp_sz in group_sizes:
                if _pool is not None:
                    while _seed_cur[0] < len(blk) and blk[_seed_cur[0]]['prox_assigned']:
                        _seed_cur[0] += 1
                    seed = blk[_seed_cur[0]] if _seed_cur[0] < len(blk) else None
                else:
                    seed = next((f for f in blk if not f['prox_assigned']), None)
                if not seed:
                    break
                batch = [seed]
                seed['prox_assigned'] = True
                if _pool is not None:
                    _pool.remove(seed)

                # Same nearest-non-road-blocked expansion as Phase 1, with the same
                # rank-by-distance-then-stop optimisation (avoids the O(n²) road check);
                # large no-road blocks use the spatial pool (O(log n), identical output).
                while len(batch) < grp_sz:
                    bcx = sum(f['x'] for f in batch) / len(batch)
                    bcy = sum(f['y'] for f in batch) / len(batch)
                    if _pool is not None:
                        best_cand = _pool.take_nearest(bcx, bcy)
                        if best_cand is None:
                            break
                        batch.append(best_cand)
                        best_cand['prox_assigned'] = True
                        continue
                    cands = [c for c in blk if not c['prox_assigned']]
                    if not cands:
                        break
                    _key = lambda c: ((c['x'] - bcx) ** 2 + (c['y'] - bcy) ** 2, c['id'])
                    best_cand = None
                    if road_index is None:
                        # No road barrier → nearest by (dist,id); min() == sort()[0],
                        # identical output without the per-step full sort.
                        best_cand = min(cands, key=_key)
                    else:
                        cands.sort(key=_key)
                        for cand in cands:
                            if any(_crosses_road(cand['x'], cand['y'], bm['x'], bm['y']) for bm in batch):
                                continue
                            best_cand = cand
                            break
                    if best_cand:
                        batch.append(best_cand)
                        best_cand['prox_assigned'] = True
                    else:
                        break

                for f in batch:
                    feature_to_group[f['id']] = current_group
                current_group += 1

    # =========================================================================
    # POST-PROCESSING: Merge undersized groups into nearest neighbours
    # =========================================================================
    # Groups with fewer than _MIN_GROUP_SIZE members are merged into the nearest
    # neighbour group.
    # Pass 1: prefer a neighbour that stays within target_size after merge.
    # Pass 2: if no such neighbour exists (all full), allow up to _OVERFLOW_CAP
    #         so that orphan groups of 1-3 are always eliminated.
    _MIN_GROUP_SIZE = 4          # groups smaller than this are absorbed
    _MERGE_CAP = target_size      # preferred cap (ideal: stay at 8)
    _OVERFLOW_CAP = target_size + 2  # fallback cap when all neighbours are full

    _fd_by_id = {fd['id']: fd for fd in feature_data}

    def _build_gmap(f2g):
        gmap: Dict[int, list] = {}
        for fid, gid in f2g.items():
            gmap.setdefault(gid, []).append(fid)
        return gmap

    def _gc(members):
        """Return centroid (x, y) of a list of feature ids."""
        xs = [_fd_by_id[m]['x'] for m in members if m in _fd_by_id]
        ys = [_fd_by_id[m]['y'] for m in members if m in _fd_by_id]
        if xs:
            return sum(xs) / len(xs), sum(ys) / len(ys)
        return 0.0, 0.0

    for _pass in range(30):  # bounded iterations
        _gmap = _build_gmap(feature_to_group)
        # Centroids are constant within a pass (membership only changes for the
        # NEXT pass), so compute each ONCE here instead of recomputing _gc() for
        # every group inside the inner loops for every small group — that
        # O(small x groups x members) recompute is what froze QGIS ~10s on big
        # projects. This precompute is behaviour-identical (same _gmap input).
        _cent = {gid: _gc(members) for gid, members in _gmap.items()}
        _small = [(gid, members) for gid, members in _gmap.items()
                  if len(members) < _MIN_GROUP_SIZE]
        if not _small:
            break

        _small.sort(key=lambda x: (len(x[1]), x[0]))  # smallest first; gid tiebreak
        _merged_any = False

        for small_gid, small_members in _small:
            sz = len(small_members)
            scx, scy = _cent[small_gid]

            # Pass 1: nearest group that stays within target_size after merge.
            # Iterate gids in sorted order so equidistant neighbours resolve to the
            # smallest gid (deterministic) rather than dict iteration order.
            best_gid = None
            best_dist = float('inf')
            for gid in sorted(_gmap):
                members = _gmap[gid]
                if gid == small_gid:
                    continue
                if len(members) + sz > _MERGE_CAP:
                    continue
                gcx, gcy = _cent[gid]
                # Batch D: don't merge a small group across a road barrier. The whole
                # clustering is road-aware EXCEPT this final merge, which could attach
                # a stray group to one on the FAR side of a road — assigning its drops
                # to a splitter they can't reach without crossing. (Pass 2 overflow
                # below may still cross as a last resort to avoid orphaning 1-3 erven.)
                if _crosses_road(scx, scy, gcx, gcy):
                    continue
                d = math.sqrt((scx - gcx) ** 2 + (scy - gcy) ** 2)
                if d < best_dist:
                    best_dist = d
                    best_gid = gid

            # Pass 2: if all neighbours are full, allow up to _OVERFLOW_CAP
            # so that orphan groups of 1-3 are never left behind.
            if best_gid is None:
                best_dist = float('inf')
                for gid in sorted(_gmap):
                    members = _gmap[gid]
                    if gid == small_gid:
                        continue
                    if len(members) + sz > _OVERFLOW_CAP:
                        continue
                    gcx, gcy = _cent[gid]
                    d = math.sqrt((scx - gcx) ** 2 + (scy - gcy) ** 2)
                    if d < best_dist:
                        best_dist = d
                        best_gid = gid

            if best_gid is not None:
                for m in small_members:
                    feature_to_group[m] = best_gid
                _merged_any = True

        if not _merged_any:
            break

    return feature_to_group


def group_zones_from_groups(feature_to_group: Dict[int, int], max_zone_size: int = 128,
                            feature_positions: Dict[int, Tuple[float, float]] = None,
                            route_layer=None,
                            pop_layer=None) -> Dict[int, int]:
    """Aggregate groups-of-8 into spatially coherent PON zones.

    Greedy nearest-neighbour packing: each zone seeds from the topmost-leftmost
    unassigned group and expands by picking the nearest unassigned group that still
    fits within max_zone_size.  This keeps every zone geographically compact.
    route_layer and pop_layer are accepted for API compatibility but not used —
    geographic proximity alone guarantees compact zones regardless of span topology.

    Args:
        feature_to_group:  Mapping of feature_id → group_id.
        max_zone_size:     Maximum total features per zone (default: 128).
        feature_positions: Optional ``{feature_id: (x, y)}`` centroid lookup.
        route_layer:       Accepted but unused (kept for API compatibility).
        pop_layer:         Accepted but unused (kept for API compatibility).

    Returns:
        Dictionary mapping feature_id → zone_id (1-based).
    """
    if not feature_to_group:
        return {}

    # Tally features per group and record membership
    group_counts: Dict[int, int] = {}
    group_members: Dict[int, List[int]] = {}
    for feat_id, grp_id in feature_to_group.items():
        group_counts[grp_id] = group_counts.get(grp_id, 0) + 1
        group_members.setdefault(grp_id, []).append(feat_id)

    if not feature_positions:
        # Sequential fallback: ascending group-ID order
        ftz: Dict[int, int] = {}
        current_zone = 1
        current_zone_size = 0
        for grp_id in sorted(group_counts.keys()):
            grp_size = group_counts[grp_id]
            if current_zone_size > 0 and current_zone_size + grp_size > max_zone_size:
                current_zone += 1
                current_zone_size = 0
            for feat_id in group_members[grp_id]:
                ftz[feat_id] = current_zone
            current_zone_size += grp_size
        return ftz

    # ------------------------------------------------------------------
    # Compute a centroid for each group
    # ------------------------------------------------------------------
    group_centroids: Dict[int, Tuple[float, float]] = {}
    for grp_id, members in group_members.items():
        xs = [feature_positions[fid][0] for fid in members if fid in feature_positions]
        ys = [feature_positions[fid][1] for fid in members if fid in feature_positions]
        group_centroids[grp_id] = (
            sum(xs) / len(xs) if xs else 0.0,
            sum(ys) / len(ys) if ys else 0.0,
        )

    # ------------------------------------------------------------------
    # Greedy nearest-neighbour zone packing.
    #
    # Each zone seeds from the topmost-leftmost unassigned group, then
    # expands by picking the nearest unassigned group (by zone centroid)
    # that still fits within max_zone_size.  No gap threshold — every
    # group is guaranteed a zone.  Geographic coherence comes naturally
    # from nearest-neighbour ordering.
    # ------------------------------------------------------------------
    unassigned: set = set(group_counts.keys())
    feature_to_zone: Dict[int, int] = {}
    current_zone = 1

    while unassigned:
        # Seed: topmost-leftmost unassigned group
        seed = min(unassigned,
                   key=lambda g: (-group_centroids[g][1], group_centroids[g][0]))
        zone_groups = [seed]
        unassigned.remove(seed)
        current_size = group_counts[seed]
        zone_cx, zone_cy = group_centroids[seed]
        n_in_zone = 1

        while unassigned:
            # Find nearest unassigned group that still fits in this zone
            best_grp = None
            best_dist = float('inf')
            for grp_id in unassigned:
                if current_size + group_counts[grp_id] > max_zone_size:
                    continue
                gcx, gcy = group_centroids[grp_id]
                d = (gcx - zone_cx) ** 2 + (gcy - zone_cy) ** 2
                if d < best_dist:
                    best_dist = d
                    best_grp = grp_id

            if best_grp is None:
                break  # No fitting group remains — start a new zone

            zone_groups.append(best_grp)
            unassigned.remove(best_grp)
            current_size += group_counts[best_grp]
            # Update running zone centroid
            gcx, gcy = group_centroids[best_grp]
            zone_cx = (zone_cx * n_in_zone + gcx) / (n_in_zone + 1)
            zone_cy = (zone_cy * n_in_zone + gcy) / (n_in_zone + 1)
            n_in_zone += 1

        for grp_id in zone_groups:
            for feat_id in group_members[grp_id]:
                feature_to_zone[feat_id] = current_zone
        current_zone += 1

    # Re-number zones compactly (1, 2, 3, …)
    old_ids = sorted(set(feature_to_zone.values()))
    renumber = {old: new for new, old in enumerate(old_ids, start=1)}
    return {fid: renumber[z] for fid, z in feature_to_zone.items()}







def assign_tight_groups_of_8(layer: QgsVectorLayer, route_layer: Optional[QgsVectorLayer] = None, field_name: str = 'group_8', span_proximity_limit: float = 100.0, adjacency_distance: float = 120.0, gap_tolerance_multiplier: float = 3.0) -> Tuple[int, int]:
    """Assign features to tight groups of 8.
    
    Args:
        layer: Vector layer to cluster
        route_layer: Optional route/span layer to constrain grouping
        field_name: Name of field to store group ID
        span_proximity_limit: Maximum distance from demand point to span line (default: 100 map units)
        adjacency_distance: Maximum distance between points within same group (default: 120 map units)
        gap_tolerance_multiplier: Multiplier for gap tolerance when filling incomplete groups (default: 3.0)
    """
    if layer.fields().indexOf(field_name) < 0:
        provider = layer.dataProvider()
        provider.addAttributes([QgsField(field_name, QVariant.Int)])
        layer.updateFields()
    
    field_idx = layer.fields().indexOf(field_name)
    features = list(layer.getFeatures())
    total_features = len(features)
    
    if total_features == 0:
        return (0, 0)
    
    feature_to_group = cluster_tight_groups_of_8(
        features, 
        route_layer=route_layer,
        span_proximity_limit=span_proximity_limit,
        adjacency_distance=adjacency_distance,
        gap_tolerance_multiplier=gap_tolerance_multiplier
    )
    total_groups = len(set(feature_to_group.values()))
    
    # Bulk write — one provider call instead of N per-feature edits (~10x faster).
    attr_map = {}
    for feature in features:
        group_id = feature_to_group.get(feature.id())
        if group_id is not None:
            attr_map[feature.id()] = {field_idx: group_id}
    if attr_map:
        layer.dataProvider().changeAttributeValues(attr_map)
        layer.triggerRepaint()

    return (total_features, total_groups)


def cluster_continuous_groups(features: List[QgsFeature], route_layer: QgsVectorLayer, target_size: int = 100, max_snap_distance: float = 500.0) -> Dict[int, int]:
    """Create tight sequential groups along the route.
    
    Groups features sequentially along the route, ensuring:
    - Each group has exactly target_size features (except last group)
    - Features in a group are within 5-15 meters of each other
    - Groups follow the route topology continuously
    - No scattered features in same group
    
    Args:
        features: List of features to cluster
        route_layer: Route/span layer defining the network topology
        target_size: Target number of features per group (default: 100)
        max_snap_distance: Maximum distance to snap features to route
    
    Returns:
        Dictionary mapping feature ID to group ID
    """
    if not features or not route_layer:
        return {}
    
    max_group_proximity = 15.0  # Maximum distance between features in same group (meters)
    
    # Build route network topology
    route_features = list(route_layer.getFeatures())

    # Batch D: build a spatial index over route segments ONCE and reuse it for both the
    # connectivity graph and the feature-snap below. The old code did an O(segments²)
    # all-pairs touches/intersects scan PLUS an O(features × segments) snap scan — a
    # multi-second-to-minute freeze on a real span network. Index lookups make both
    # roughly O(n · k).
    seg_index = QgsSpatialIndex()
    seg_geom_by_id = {}
    for i, seg in enumerate(route_features):
        g = seg.geometry()
        if not g or g.isEmpty():
            continue
        _sf = QgsFeature()
        _sf.setId(i)
        _sf.setGeometry(g)
        seg_index.addFeature(_sf)
        seg_geom_by_id[i] = g

    segment_graph = {i: [] for i in seg_geom_by_id}
    for i, g1 in seg_geom_by_id.items():
        for j in seg_index.intersects(g1.boundingBox()):
            if j == i:
                continue
            g2 = seg_geom_by_id.get(j)
            if g2 is not None and (g1.touches(g2) or g1.intersects(g2)):
                segment_graph[i].append(j)

    # Snap all features to nearest route segment — only test the few nearest segments
    # (by the index) instead of every segment.
    feature_data = []
    for feature in features:
        geom = feature.geometry()
        if not geom or geom.isEmpty():
            continue

        centroid = geom.centroid().asPoint()
        min_distance = float('inf')
        nearest_segment_id = None
        nearest_point = None

        for seg_idx in seg_index.nearestNeighbor(QgsPointXY(centroid.x(), centroid.y()), 8):
            route_geom = seg_geom_by_id.get(seg_idx)
            if route_geom is None:
                continue
            nearest = route_geom.nearestPoint(QgsGeometry.fromPointXY(centroid))
            if nearest.isEmpty():
                continue
            nearest_pt = nearest.asPoint()
            distance = math.sqrt(
                (centroid.x() - nearest_pt.x())**2 +
                (centroid.y() - nearest_pt.y())**2
            )
            if distance < min_distance:
                min_distance = distance
                nearest_segment_id = seg_idx
                nearest_point = nearest_pt

        if min_distance <= max_snap_distance and nearest_segment_id is not None:
            feature_data.append({
                'id': feature.id(),
                'segment_id': nearest_segment_id,
                'x': nearest_point.x(),
                'y': nearest_point.y(),
                'centroid': centroid,
                'assigned': False
            })
    
    if not feature_data:
        return {}
    
    # Group features by segment
    features_by_segment = {}
    for f in feature_data:
        seg_id = f['segment_id']
        if seg_id not in features_by_segment:
            features_by_segment[seg_id] = []
        features_by_segment[seg_id].append(f)
    
    # Calculate actual position along each line segment for proper sorting
    for seg_id, seg_features in features_by_segment.items():
        route_geom = route_features[seg_id].geometry()
        
        # For line geometries, calculate actual distance along line
        if route_geom.type() == 1:  # LineString
            for feat in seg_features:
                # Calculate distance from start of line to this point
                feat_point = QgsGeometry.fromPointXY(QgsPointXY(feat['x'], feat['y']))
                
                try:
                    # Get line vertices
                    if route_geom.isMultipart():
                        vertices = route_geom.asMultiPolyline()[0] if route_geom.asMultiPolyline() else []
                    else:
                        vertices = route_geom.asPolyline()
                    
                    # Calculate cumulative distance to find position along line
                    if vertices:
                        min_dist = float('inf')
                        best_cumulative = 0
                        cumulative = 0
                        
                        for i, vertex in enumerate(vertices):
                            # Distance from current vertex to feature
                            dist = math.sqrt(
                                (feat['x'] - vertex.x())**2 + 
                                (feat['y'] - vertex.y())**2
                            )
                            
                            if dist < min_dist:
                                min_dist = dist
                                best_cumulative = cumulative
                            
                            # Add segment length to cumulative
                            if i < len(vertices) - 1:
                                next_vertex = vertices[i + 1]
                                seg_length = math.sqrt(
                                    (next_vertex.x() - vertex.x())**2 + 
                                    (next_vertex.y() - vertex.y())**2
                                )
                                cumulative += seg_length
                        
                        feat['line_distance'] = best_cumulative
                    else:
                        feat['line_distance'] = feat['x'] + feat['y'] * 0.0001
                except Exception:                    feat['line_distance'] = feat['x'] + feat['y'] * 0.0001
        else:
            # For non-line geometries, use X,Y position
            for feat in seg_features:
                feat['line_distance'] = feat['x'] + feat['y'] * 0.0001
        
        # Sort features within segment by actual position along line
        seg_features.sort(key=lambda f: f['line_distance'])
    
    # Use DEPTH-FIRST traversal to follow complete paths through network
    # This prevents jumping between branches
    sequential_features = []
    visited_segments = set()
    
    def depth_first_collect(seg_id):
        """Recursively collect features following depth-first path"""
        if seg_id in visited_segments:
            return
        
        visited_segments.add(seg_id)
        
        # Add all features from this segment in order
        if seg_id in features_by_segment:
            for feat in features_by_segment[seg_id]:
                if not feat['assigned']:
                    sequential_features.append(feat)
                    feat['assigned'] = True
        
        # Recursively visit connected segments (depth-first)
        for connected_seg in segment_graph.get(seg_id, []):
            if connected_seg not in visited_segments and connected_seg in features_by_segment:
                depth_first_collect(connected_seg)
    
    # Start from segment with most features
    if features_by_segment:
        start_segment = max(features_by_segment.keys(), key=lambda s: len(features_by_segment[s]))
        depth_first_collect(start_segment)
        
        # Collect any remaining features from disconnected segments
        for seg_id in features_by_segment.keys():
            if seg_id not in visited_segments:
                depth_first_collect(seg_id)
    
    # Now group sequentially with STRICT proximity constraint
    # If we can't reach 100 due to gaps, cap the group and start fresh
    feature_to_group = {}
    current_group = 1
    current_batch = []
    last_position = None
    
    for feat in sequential_features:
        should_start_new_group = False
        
        if current_batch:
            # Check distance to last feature in current batch
            distance = math.sqrt(
                (feat['x'] - last_position['x'])**2 + 
                (feat['y'] - last_position['y'])**2
            )
            
            # STRICT RULE: If gap exceeds proximity limit, cap current group and start new one
            if distance > max_group_proximity:
                should_start_new_group = True
        
        # If we need to start a new group, close the current one
        if should_start_new_group:
            # Cap current group (even if less than 100)
            current_group += 1
            current_batch = []
            last_position = None
        
        # Add feature to current batch
        current_batch.append(feat)
        feature_to_group[feat['id']] = current_group
        last_position = {'x': feat['x'], 'y': feat['y']}
        
        # Check if batch reached target size of 100
        if len(current_batch) >= target_size:
            current_group += 1
            current_batch = []
            last_position = None
    
    return feature_to_group
