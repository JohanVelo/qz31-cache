"""ticket_dialog — a small "Log a ticket" form for the home panel's red button.

A teammate reports a bug or requests a feature; on submit, `on_submit(payload)`
is called (the plugin sends it to the planning office via the Nexus backend).
Returns True on a successful (queued) send. Fully fail-soft.
"""
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QComboBox, QDialog, QLabel, QLineEdit,
                                 QMessageBox, QPlainTextEdit, QPushButton,
                                 QVBoxLayout)

_QSS = """
QDialog { background:#0F172A; }
QLabel { color:#F1F5F9; }
QLabel#vfTkHint { color:#94A3B8; font-size:11px; }
QLabel#vfTkLbl  { color:#64748B; font-size:9px; font-weight:700; letter-spacing:1px; }
QComboBox, QLineEdit, QPlainTextEdit {
    background:#1A2942; color:#F1F5F9; border:1px solid #2A3A52;
    border-radius:7px; padding:7px 9px; font-size:12px;
}
QComboBox:focus, QLineEdit:focus, QPlainTextEdit:focus { border:1px solid #06B6D4; }
QPushButton#vfTkSend {
    background:qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #06B6D4, stop:1 #3B82F6);
    color:#08131F; border:none; border-radius:8px; padding:9px 14px; font-weight:800;
}
QPushButton#vfTkSend:hover { border:1px solid #FFFFFF; }
QPushButton#vfTkCancel { background:transparent; color:#94A3B8; border:none; padding:9px 12px; }
QPushButton#vfTkCancel:hover { color:#F1F5F9; }
"""


class TicketDialog(QDialog):
    def __init__(self, iface, on_submit, parent=None):
        super().__init__(parent or iface.mainWindow())
        self.iface = iface
        self._on_submit = on_submit
        self.setWindowTitle("Log a ticket")
        self.setMinimumWidth(440)
        self.setStyleSheet(_QSS)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(8)

        t = QLabel("🎫  Log a ticket")
        t.setStyleSheet("font-size:16px; font-weight:800;")
        lay.addWidget(t)
        hint = QLabel("Report a bug or request a feature — it goes straight to the "
                      "planning office.")
        hint.setObjectName("vfTkHint")
        hint.setWordWrap(True)
        lay.addWidget(hint)
        lay.addSpacing(4)

        lay.addWidget(self._lbl("TYPE"))
        self.kind = QComboBox()
        self.kind.addItems(["🐞  Bug — something is broken or wrong",
                            "💡  Feature — something I'd like built"])
        lay.addWidget(self.kind)

        lay.addWidget(self._lbl("TITLE"))
        self.title = QLineEdit()
        self.title.setPlaceholderText("Short summary (e.g. 'Span check misses drop cables')")
        self.title.setMaxLength(140)
        lay.addWidget(self.title)

        lay.addWidget(self._lbl("DETAILS"))
        self.body = QPlainTextEdit()
        self.body.setPlaceholderText("What happened, the steps to reproduce, or exactly "
                                     "what you'd like the tool to do…")
        self.body.setMinimumHeight(120)
        lay.addWidget(self.body)

        from qgis.PyQt.QtWidgets import QHBoxLayout
        row = QHBoxLayout()
        row.addStretch(1)
        cancel = QPushButton("Cancel")
        cancel.setObjectName("vfTkCancel")
        cancel.clicked.connect(self.reject)
        row.addWidget(cancel)
        self.send = QPushButton("Send ticket  →")
        self.send.setObjectName("vfTkSend")
        self.send.setCursor(Qt.CursorShape.PointingHandCursor)
        self.send.clicked.connect(self._submit)
        row.addWidget(self.send)
        lay.addLayout(row)

    def _lbl(self, text):
        ll = QLabel(text)
        ll.setObjectName("vfTkLbl")
        return ll

    def _submit(self):
        title = self.title.text().strip()
        if not title:
            QMessageBox.information(self, "Log a ticket",
                                    "Please add a short title so it's easy to triage.")
            return
        payload = {
            "kind": "bug" if self.kind.currentIndex() == 0 else "feature",
            "title": title,
            "body": self.body.toPlainText().strip(),
        }
        self.send.setEnabled(False)
        self.send.setText("Sending…")
        try:
            ok = self._on_submit(payload)
        except Exception:
            ok = False
        if ok is not False:
            QMessageBox.information(self, "Ticket sent",
                                    "Thanks! Your ticket was sent to the planning office. ✓")
            self.accept()
        else:
            QMessageBox.warning(self, "Log a ticket",
                                "Couldn't reach the server right now — your ticket is "
                                "saved and will send automatically when you're back online.")
            self.accept()
