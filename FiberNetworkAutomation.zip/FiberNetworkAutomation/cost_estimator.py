"""Transparent CAPEX / cost-per-home estimator — the priced-costing gap.

Two halves:
  * count_quantities(project)  — pure-ish: robustly tallies billable quantities
    from whatever fiber layers exist (Vuma / Fibertime / HeroTel naming), with
    cable length measured geodesically. Returns a plain dict so it's testable.
  * CostEstimatorDialog        — shows the COUNTED quantities (transparency, so
    the number is never a black box) next to OPERATOR-EDITABLE unit rates, and
    computes total CAPEX + cost-per-home live.

No fabricated totals: the tool automates quantity × rate; the rates are the
operator's to set (defaults are clearly labelled "example — edit to contract").
"""

# Default rates (ZAR) — EDITABLE in the dialog, NOT authoritative. Seeded from
# 2026 SA FTTH benchmarks (research R7), which are themselves derived from
# global rates + a ZAR premium — VALIDATE with your contractors (Frogfoot/
# MetroFibre/Vuma) + ONT distributor before quoting a client.
DEFAULT_RATES = {
    'pole':      2400.0,   # per pole, new install (make-ready ~600)
    'cable_m':   100.0,    # per metre, blended feeder/dist (mini-ADSS ~120, ADSS ~50)
    'splitter':  1400.0,   # per splitter (1:8 ~800, 1:16 ~1800)
    'ont':       1200.0,   # per ONT unit
    'drop_m':    4.0,      # per metre drop cable
    'enclosure': 1200.0,   # per joint/dome enclosure
}
# Sanity band for cost-per-home (SA FTTH benchmark, ZAR) — warn outside this.
PER_HOME_LO, PER_HOME_HI = 5000.0, 25000.0

_TEMP = ('temp', 'scratch', 'backup', '_bak', 'copy', '_best', '_old', 'test_')


def _vlayers(project):
    from qgis.core import QgsMapLayer
    return [l for l in project.mapLayers().values()
            if l.type() == QgsMapLayer.LayerType.VectorLayer
            and not any(s in l.name().lower() for s in _TEMP)]


def count_quantities(project):
    """Tally billable quantities from the live project. Cable/drop lengths in
    metres (geodesic). Returns {poles, cable_m, drop_m, splitters, onts,
    enclosures, and a per-layer breakdown}."""
    from qgis.core import QgsWkbTypes, QgsDistanceArea

    q = {'poles': 0, 'cable_m': 0.0, 'drop_m': 0.0,
         'splitters': 0, 'onts': 0, 'enclosures': 0, 'detail': {}}
    da = QgsDistanceArea()
    da.setEllipsoid('WGS84')

    for l in _vlayers(project):
        nm = l.name().lower()
        gt = l.geometryType()
        n = l.featureCount()
        try:
            da.setSourceCrs(l.crs(), project.transformContext())
        except Exception:
            pass

        if gt == QgsWkbTypes.GeometryType.PointGeometry:
            if 'pole' in nm:
                q['poles'] += n; q['detail'][l.name()] = n
            elif 'splitter' in nm:
                q['splitters'] += n; q['detail'][l.name()] = n
            elif any(k in nm for k in ('ont', 'home connection', 'home_conn')):
                q['onts'] += n; q['detail'][l.name()] = n
            elif any(k in nm for k in ('joint', 'enclosure', 'dome')):
                q['enclosures'] += n; q['detail'][l.name()] = n
        elif gt == QgsWkbTypes.GeometryType.LineGeometry:
            if 'span' in nm:
                continue  # routing spine, not billable cable
            is_drop = 'drop' in nm
            if not (is_drop or any(k in nm for k in
                    ('cable', 'feeder', 'distribution', 'spur', 'link'))):
                continue
            length = 0.0
            for f in l.getFeatures():
                g = f.geometry()
                if g and not g.isEmpty():
                    try:
                        length += da.measureLength(g)
                    except Exception:
                        pass
            if is_drop:
                q['drop_m'] += length
            else:
                q['cable_m'] += length
            q['detail'][l.name()] = f'{length/1000.0:.2f} km'
    return q


def estimate(quantities, rates):
    """Return {line_items: {key: (qty, rate, cost)}, total, per_home}."""
    qmap = {
        'pole':      quantities['poles'],
        'cable_m':   quantities['cable_m'],
        'splitter':  quantities['splitters'],
        'ont':       quantities['onts'],
        'drop_m':    quantities['drop_m'],
        'enclosure': quantities['enclosures'],
    }
    items, total = {}, 0.0
    for k, qty in qmap.items():
        rate = float(rates.get(k, 0.0))
        cost = qty * rate
        items[k] = (qty, rate, cost)
        total += cost
    homes = quantities['onts']
    per_home = (total / homes) if homes > 0 else None   # None = no ONTs → n/a
    return {'line_items': items, 'total': total,
            'per_home': per_home, 'homes': homes}


# ── transparent dialog ───────────────────────────────────────────────────────
_ROWS = [
    ('pole',      'Poles',          'poles',      'each'),
    ('cable_m',   'Feeder/Dist/Spur cable', 'cable_m', 'm'),
    ('splitter',  'Splitters',      'splitters',  'each'),
    ('ont',       'ONTs / homes',   'onts',       'each'),
    ('drop_m',    'Drop cable',     'drop_m',     'm'),
    ('enclosure', 'Joints / domes', 'enclosures', 'each'),
]


def open_dialog(iface):
    """Build + show the cost estimator over the live project."""
    from qgis.core import QgsProject
    from qgis.PyQt.QtWidgets import (
        QDialog, QVBoxLayout, QGridLayout, QLabel, QDoubleSpinBox, QFrame)

    from qgis.PyQt.QtCore import Qt

    q = count_quantities(QgsProject.instance())
    dlg = QDialog(iface.mainWindow())
    dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
    dlg.setWindowTitle('Velocity Nexus — Cost Estimator')
    dlg.setMinimumWidth(460)
    v = QVBoxLayout(dlg)
    v.addWidget(QLabel('<b>CAPEX estimate from live project quantities.</b><br>'
                       '<span style="color:#888">Quantities are counted from your '
                       'layers. Default rates are examples — edit to your contract.</span>'))

    grid = QGridLayout()
    for c, h in enumerate(('Item', 'Quantity', 'Unit rate (R)', 'Line cost (R)')):
        lab = QLabel(f'<b>{h}</b>'); grid.addWidget(lab, 0, c)
    spins, qty_vals, cost_lbls = {}, {}, {}
    for r, (key, label, qkey, unit) in enumerate(_ROWS, start=1):
        qty = q[qkey]
        qty_vals[key] = qty
        grid.addWidget(QLabel(label), r, 0)
        qty_txt = f'{qty:,.0f} {unit}' if unit == 'm' else f'{qty:,} {unit}'
        grid.addWidget(QLabel(qty_txt), r, 1)
        sp = QDoubleSpinBox(); sp.setRange(0, 1e7); sp.setDecimals(2)
        sp.setSingleStep(1.0); sp.setValue(DEFAULT_RATES.get(key, 0.0))
        spins[key] = sp; grid.addWidget(sp, r, 2)
        cl = QLabel('—'); cost_lbls[key] = cl; grid.addWidget(cl, r, 3)
    v.addLayout(grid)

    line = QFrame(); line.setFrameShape(QFrame.Shape.HLine); v.addWidget(line)
    total_lbl = QLabel(); total_lbl.setStyleSheet('font-size:14px;font-weight:800;')
    v.addWidget(total_lbl)

    def recalc():
        rates = {k: spins[k].value() for k in spins}
        res = estimate(q, rates)
        for key, (qty, rate, cost) in res['line_items'].items():
            cost_lbls[key].setText(f'{cost:,.0f}')
        if res['per_home'] is None:
            ph = 'Cost per home:  n/a (no ONTs in project)'
        else:
            ph = f'Cost per home:  R {res["per_home"]:,.0f}   ({res["homes"]:,} homes)'
        total_lbl.setText(f'Total CAPEX:  R {res["total"]:,.0f}      ·      ' + ph)

    for sp in spins.values():
        sp.valueChanged.connect(recalc)
    recalc()

    try:
        from .nexus_dock import chrome_dialog
        chrome_dialog(dlg)
    except Exception:
        pass
    dlg.exec()

