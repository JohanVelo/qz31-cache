"""Learn the building->erf spatial relationship from the REAL erven.

For each real erf: find the building(s) inside, then in the erf's own local
frame (rotated so its long axis = depth) measure:
  - erf frontage (short side) & depth (long side)
  - where the building sits: position along frontage (0..1) and depth (0..1)
  - how the building's orientation compares to the erf's
This tells us how to PLACE a generated erf around a building.
"""
import json
from statistics import median, pstdev
from shapely import wkt
from shapely.geometry import Point
from shapely.strtree import STRtree
from shapely import affinity
import erven_obb as e

d = json.load(open('C:/Temp/erven_test.json'))
buildings = [wkt.loads(w) for w in d['buildings_wkt']]
pts = [tuple(p) for p in d['building_pts']]
real = [wkt.loads(w) for w in d['real_erven_wkt']]

btree = STRtree([Point(p) for p in pts])
fronts, depths, pos_w, pos_d, ang_diff, nbld = [], [], [], [], [], []

for erf in real:
    a = e.obb_angle(erf)                      # long-edge angle
    cx, cy = erf.centroid.x, erf.centroid.y
    al = affinity.rotate(erf, -a, origin=(cx, cy))
    minx, miny, maxx, maxy = al.bounds
    w_x, w_y = maxx - minx, maxy - miny
    # depth = longer dimension; make x=frontage, y=depth by swapping if needed
    if w_x >= w_y:
        frontage, depth, swap = w_x, w_y, True
    else:
        frontage, depth, swap = w_y, w_x, False
    if not (8 < frontage < 60 and 12 < depth < 60):
        continue
    fronts.append(frontage); depths.append(depth)
    # buildings inside this erf
    bin_ = []
    for j in btree.query(erf):
        if erf.contains(Point(pts[j])):
            bin_.append(j)
    nbld.append(len(bin_))
    for j in bin_:
        bp = affinity.rotate(Point(pts[j]), -a, origin=(cx, cy))
        fx = (bp.x - minx) / w_x if w_x else 0.5
        fy = (bp.y - miny) / w_y if w_y else 0.5
        fpos, dpos = (fx, fy) if swap else (fy, fx)   # frontage-pos, depth-pos
        pos_w.append(fpos); pos_d.append(dpos)
        bang = e.obb_angle(buildings[j])
        diff = abs(((bang - a + 90) % 180) - 90)       # 0 = aligned to erf
        ang_diff.append(diff)

def stat(x):
    return f'median {median(x):.2f}  (sd {pstdev(x):.2f}, p10 {sorted(x)[len(x)//10]:.2f}, p90 {sorted(x)[9*len(x)//10]:.2f})'

print(f'erven analysed: {len(fronts)} | buildings/erf median {median(nbld)}')
print(f'frontage m : {stat(fronts)}')
print(f'depth    m : {stat(depths)}')
print(f'building pos along FRONTAGE (0=left,1=right): {stat(pos_w)}')
print(f'building pos along DEPTH   (0=street,1=back): {stat(pos_d)}')
print(f'building-vs-erf angle diff (deg, 0=aligned)  : {stat(ang_diff)}')

# ---- ORACLE: ceiling of the centred-placement model -------------------------
# For each real erf, place a rectangle CENTRED on its building, given the
# erf's true size + true angle, and measure IoU vs the real erf. This isolates
# how well "centre an erf on the building" explains the real placement.
from shapely.geometry import box
def oracle_iou(use_erf_centroid):
    ious = []
    for erf in real:
        a = e.obb_angle(erf)
        cx, cy = erf.centroid.x, erf.centroid.y
        al = affinity.rotate(erf, -a, origin=(cx, cy))
        minx, miny, maxx, maxy = al.bounds
        W, D = maxx - minx, maxy - miny
        bin_ = [j for j in btree.query(erf) if erf.contains(Point(pts[j]))]
        if not bin_:
            continue
        if use_erf_centroid:
            ox, oy = cx, cy
        else:
            mx = sum(pts[j][0] for j in bin_) / len(bin_)
            my = sum(pts[j][1] for j in bin_) / len(bin_)
            ox, oy = mx, my
        rect = box(ox - W/2, oy - D/2, ox + W/2, oy + D/2)
        rect = affinity.rotate(rect, a, origin=(ox, oy))
        inter = erf.intersection(rect).area
        ious.append(inter / (erf.area + rect.area - inter) if inter else 0.0)
    return sum(ious)/len(ious)

print(f'ORACLE IoU (rect centred on BUILDING, true size+angle): {oracle_iou(False):.2f}')
print(f'ORACLE IoU (rect at ERF centroid, true size+angle)    : {oracle_iou(True):.2f}')
