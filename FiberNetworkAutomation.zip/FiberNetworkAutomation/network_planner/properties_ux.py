"""Pass 7 (Properties panel) — pure, unit-testable helpers for the 🔧 Properties
layer auto-detect.

The keyword auto-detection in ``dock_widget._refresh_properties`` is NOT changed:
it still selects exactly the layers it always did. This module only turns the RESULT
of that pass into an honest report — what matched, what could NOT be found, and where
it had to GUESS between several candidates — so a planner catches a wrong or missing
pick before AutoNet runs on it. Everything here is pure (plain dicts in, plain lines
out; no QGIS objects) so it is fully testable and keeps the handler readable.

The three auto-detected roles: a *demand* layer (erven / buildings / ONTs), a *route*
(span / fibre / duct line) layer, and a *road* layer.
"""

#: Display label for each auto-detected role, in report order.
ROLE_LABELS = (
    ("demand", "Demand"),
    ("route", "Route"),
    ("road", "Road"),
)


def detect_report(picked, candidate_counts=None, ambiguous=None):
    """Turn one auto-detect pass into honest log lines (list[str]).

    ``picked``          : ``{role: layer_name or None}`` — what the pass selected.
    ``candidate_counts``: ``{role: int}`` — how many layers of the right geometry
                          existed to choose from (optional).
    ``ambiguous``       : ``{role: int}`` — how many of those matched a keyword; a
                          value > 1 means the pass took the FIRST of several and the
                          planner should confirm it (optional). Pure.
    """
    picked = dict(picked or {})
    counts = dict(candidate_counts or {})
    amb = dict(ambiguous or {})

    lines = ["── 🔄 Properties auto-detect ──────────────────"]
    for role, label in ROLE_LABELS:
        name = picked.get(role)
        pad = f"{label:<7}"
        if name:
            n_match = int(amb.get(role, 1) or 1)
            if n_match > 1:
                lines.append(f"  ≈ {pad}: {name}  (chose 1st of {n_match} matches — confirm)")
            else:
                lines.append(f"  ✓ {pad}: {name}")
        else:
            n_cand = int(counts.get(role, 0) or 0)
            if n_cand:
                lines.append(f"  ⚠ {pad}: NOT FOUND  ({n_cand} candidate layer(s) of the right type)")
            else:
                lines.append(f"  ⚠ {pad}: NOT FOUND  (no layers of the right geometry)")

    if not any(picked.get(r) for r, _ in ROLE_LABELS):
        lines.append("  — no layers matched; add/rename the source layers then refresh")
    return lines


def props_readiness(picks):
    """Readiness of the CURRENT Properties picks. Returns ``[(severity, message)]``.

    ``picks``: ``{role: layer_name or None}``. ``severity`` is ``"warn"`` for a role
    with no layer selected (AutoNet can still auto-detect it, so never an ``"error"``),
    or ``"ok"`` on the single all-set line. Pure.
    """
    picks = dict(picks or {})
    msgs = []
    missing = [label for role, label in ROLE_LABELS if not picks.get(role)]
    if missing:
        for label in missing:
            msgs.append((
                "warn",
                f"No {label} layer selected — AutoNet will try to auto-detect it at run time.",
            ))
    else:
        msgs.append(("ok", "All three layers (Demand · Route · Road) are selected."))
    return msgs
