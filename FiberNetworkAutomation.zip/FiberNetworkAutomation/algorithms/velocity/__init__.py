"""Velocity standards algorithms — the canonical layer benchmark.

Separate from `algorithms/herotel/` on purpose: those describe a CLIENT's
delivered work and may only report on it. These act on our own output.
"""
