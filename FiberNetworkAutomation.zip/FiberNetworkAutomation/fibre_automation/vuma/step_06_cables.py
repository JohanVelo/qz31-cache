"""Vuma Step 6 — Route cables along the road network.

STATUS: [ ] STUB — requires road network layer and placed nodes
"""

from qgis.core import QgsProject


def _get(name):
    layers = QgsProject.instance().mapLayersByName(name)
    return layers[0] if layers else None


def vuma_step_06_cables():
    """Route Feeder, Distribution, Spur, and Drop cables between nodes.

    STATUS: [ ] STUB
    Requires:
      - All node layers populated (Step 5)
      - Road network layer for routing

    Routing hierarchy:
      Feeder      Node → Aggregation Joint  (along main road)
      Distribution  Aggregation Joint → Dome Joint  (along road)
      Spur          Dome Joint → further Dome Joints (inline)
      Drops         Dome Joint → Demand Point (straight line, max 60 m)

    Cable sizes (Vuma Key Method):
      Feeder      144F ADSS
      Distribution 48F ADSS
      Spur         24F ADSS
      Drops         2F ADSS (aerial), 2F PDR (underground)

    TODO:
      1. Build road graph from road network layer
      2. Shortest-path route Feeder along main road spine
      3. Branch Distribution cables to each AGG Polygon centroid
      4. Spur cables between Dome Joints within same AGG Polygon
      5. Straight-line Drops from each Dome Joint to covered Demand Points
      6. Check all spans against limits (70 m ADSS, 60 m drops)
    """
    print(f"\n{'═' * 50}")
    print("  VUMA STEP 6 — Cable Routing")
    print(f"{'═' * 50}")
    print("  ⚠ Step 6 is a stub — road routing not yet built.")
    print("  Manual cable drawing required until road network integration")
    print("  is available.")
    print(f"{'═' * 50}\n")
