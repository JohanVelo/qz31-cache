"""off_thread — run heavy work OFF the Qt main thread so QGIS never freezes.

Bundled (qgis.core + stdlib only). Wraps QGIS's own QgsTask so a slow but
thread-safe callable runs on a worker thread; its return value is delivered back
on the MAIN thread via on_done(result), and any exception is caught and handed to
on_error(exc). Ties into the structured event log (error_reporter.log_event) so
every background op is traceable: task:start / task:ok / task:error with a shared
trace id + duration_ms.

    from fibre_automation import off_thread

    def heavy():                      # runs on a WORKER thread
        return sum(expensive(x) for x in data)      # pure compute — no GUI

    def done(total):                  # runs on the MAIN thread
        iface.messageBar().pushSuccess('Done', f'total={total}')

    off_thread.run_off_thread(heavy, on_done=done, description='Crunching…')

THREAD-SAFETY CONTRACT (read this): `work()` runs on a worker thread, so it MUST
NOT touch the GUI, the map canvas, iface, widgets, or edit layers — those QGIS
APIs are not thread-safe and will crash. The safe pattern for layer work is:
gather the feature data you need on the MAIN thread BEFORE calling, do the pure
compute inside work(), then APPLY the results inside on_done() (main thread).

Fail-soft: if the task manager isn't available (e.g. headless / no QGIS), work()
runs SYNCHRONOUSLY so behaviour is never lost — just without the freeze relief.
"""
from __future__ import annotations

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

# Strong references to in-flight tasks. QgsTask ownership passes to the C++ task
# manager, but the Python wrapper must be kept alive or it can be garbage-collected
# mid-run → hard crash. We hold a ref here and drop it in finished().
_LIVE = set()
_TASK_CLASS = None


def _er():
    """The error_reporter module if importable, else None (logging is optional)."""
    try:
        import error_reporter as er
        return er
    except Exception:
        try:
            from FiberNetworkAutomation import error_reporter as er   # packaged form
            return er
        except Exception:
            return None


def _new_trace() -> str:
    er = _er()
    if er is not None:
        try:
            return er.new_trace_id()
        except Exception:
            _swallowed_note()
    import uuid
    return uuid.uuid4().hex[:8]


def _log(level: str, message: str, trace=None, **extra):
    er = _er()
    if er is None:
        return
    try:
        er.log_event(level, 'off_thread', message, trace_id=trace, **extra)
    except Exception:
        _swallowed_note()


def available() -> bool:
    """True if the QGIS task manager is usable (so work can truly run off-thread)."""
    try:
        from qgis.core import QgsApplication
        return QgsApplication.taskManager() is not None
    except Exception:
        return False


def _task_class():
    """Build (once) and return the OffThreadTask class. Deferred so importing this
    module never requires QGIS — the class only exists once QgsTask is importable."""
    global _TASK_CLASS
    if _TASK_CLASS is not None:
        return _TASK_CLASS
    from qgis.core import QgsTask

    class OffThreadTask(QgsTask):
        def __init__(self, work, on_done, on_error, description, can_cancel, trace):
            flags = QgsTask.Flag.CanCancel if can_cancel else QgsTask.Flags()
            super().__init__(description or 'Working…', flags)
            self._work = work
            self._on_done = on_done
            self._on_error = on_error
            self._trace = trace
            self._result = None
            self._exc = None
            self._t0 = 0.0

        def run(self):
            # ── WORKER THREAD ── no GUI / canvas / layer-edit / iface here.
            import time
            self._t0 = time.time()
            try:
                self._result = self._work()
                return True
            except Exception as e:      # never let it escape run() → would crash QGIS
                self._exc = e
                return False

        def finished(self, ok):
            # ── MAIN THREAD ── safe to touch layers / GUI / fire callbacks.
            import time
            dur = round((time.time() - (self._t0 or time.time())) * 1000)
            try:
                if self.isCanceled():
                    _log('info', 'task:cancelled', trace=self._trace,
                         desc=self.description(), duration_ms=dur)
                    return
                if ok and self._exc is None:
                    _log('info', 'task:ok', trace=self._trace,
                         desc=self.description(), duration_ms=dur)
                    if self._on_done is not None:
                        try:
                            self._on_done(self._result)
                        except Exception as e:
                            _log('error', 'on_done raised', trace=self._trace,
                                 error=f'{type(e).__name__}: {e}')
                else:
                    err = (f'{type(self._exc).__name__}: {self._exc}'
                           if self._exc else 'task returned failure')
                    _log('error', 'task:error', trace=self._trace,
                         desc=self.description(), duration_ms=dur, error=err)
                    if self._on_error is not None:
                        try:
                            self._on_error(self._exc)
                        except Exception:
                            _swallowed_note()
            finally:
                _LIVE.discard(self)

    _TASK_CLASS = OffThreadTask
    return _TASK_CLASS


def run_off_thread(work, on_done=None, on_error=None, description='Working…',
                   can_cancel=True):
    """Run `work()` (a zero-arg callable) on a worker thread; deliver its return
    value to on_done(result) on the MAIN thread, or any raised exception to
    on_error(exc) on the MAIN thread. Returns the QgsTask, or None if it ran on the
    synchronous fallback.

    `work` MUST be thread-safe (pure compute / file / network) — see the module
    docstring. Callbacks are optional. Never raises."""
    trace = _new_trace()
    if not available():
        # synchronous fallback — behaviour preserved even with no task manager
        try:
            r = work()
        except Exception as e:
            _log('error', 'sync-fallback error', trace=trace,
                 error=f'{type(e).__name__}: {e}')
            if on_error is not None:
                try:
                    on_error(e)
                except Exception:
                    _swallowed_note()
            return None
        if on_done is not None:
            try:
                on_done(r)
            except Exception as e:
                _log('error', 'on_done raised (sync)', trace=trace,
                     error=f'{type(e).__name__}: {e}')
        return None
    try:
        from qgis.core import QgsApplication
        task = _task_class()(work, on_done, on_error, description, can_cancel, trace)
        _LIVE.add(task)
        _log('info', 'task:start', trace=trace, desc=description)
        QgsApplication.taskManager().addTask(task)
        return task
    except Exception as e:
        # if launching the task fails for any reason, don't lose the work
        _log('error', 'launch failed → sync', trace=trace,
             error=f'{type(e).__name__}: {e}')
        return run_off_thread_sync(work, on_done, on_error, trace)


def run_off_thread_sync(work, on_done=None, on_error=None, trace=None):
    """Explicit synchronous run with the same callback contract — used as the
    internal fallback and available for tests / headless callers."""
    try:
        r = work()
    except Exception as e:
        if on_error is not None:
            try:
                on_error(e)
            except Exception:
                _swallowed_note()
        return None
    if on_done is not None:
        try:
            on_done(r)
        except Exception:
            _swallowed_note()
    return None
