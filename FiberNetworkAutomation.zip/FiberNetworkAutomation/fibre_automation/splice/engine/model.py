# -*- coding: utf-8 -*-
"""The splice model — turn a snapshot into the ordered walk the field actually follows.

    OLT port -> POP -> feeder chain -> AGG dome -> 1:{fts} FTS
             -> distribution walk -> DIS dome -> 1:{sts} STS -> drop -> ONT

EVERY VALUE COMES FROM THE DATA. This module decides ORDER and ADJACENCY; it never
invents a fibre number, a leg or a label. The STS carries its own `.L<n>`, the drop
carries its own DR number — the model reads them. That is also why a project whose STS
labels were hand-numbered reproduces exactly: the numbering is data, not a rule.

Pure Python on purpose: the snapshot is plain JSON, so this module imports no geo stack
and can therefore live in the same process as openpyxl (gdal + openpyxl together throw
`No module named '_gdal'` under the qgis-venv).

THE RULES, AND WHERE EACH WAS MEASURED
  R1  feeder chain   walk BACK from the AGG dome: the cable through that pole, then the
                     cable through THAT cable's start pole, until a manhole. The POP->MH
                     duct is not a GIS feature and is synthesised (declared, not measured).
  R2  feeder joints  joint_i = the start feature of cable_{i+1}, named as a dome if a dome
                     sits on that pole, else a manhole, else a pole. Trailing joint blank —
                     except a 2-cable chain, which repeats the AGG dome (2 PONs; measured).
  R3  feeder fibre   rank of the PON, by PON number, within its own 96F primary. Constant
                     along the whole chain. 66/66 on MOA.
  R4  main route     a distribution cable whose START pole is the AGG dome's pole.
  R5  spur           a cable whose START pole lies ON another cable of the same PON; that
                     cable is its parent. Spurs come OFF the distribution, never back to
                     the FTS.
  R6  serving cable  the cable that physically passes the STS's dome. Ambiguity is reported,
                     never resolved by picking the first.
  R7  fibre out      main route -> F{fts leg}. Spur -> F{rank of this STS on its own spur
                     cable, in leg order}.
  R8  drop -> pole   test BOTH ends; take the end landing on a pole that carries a splitter
                     of that drop's own PON. 25 of MOA's 6,335 drops are drawn pole->ONT,
                     so taking line[-1] blindly picks the ONT end and invents a pole.
  R9  port order     real drops ascending by DR, then spares ascending. reals+spares == ratio.
"""
from __future__ import annotations

import math
from collections import defaultdict


# ── geometry, in metres (the snapshot is already in the profile's metric CRS) ──

def _seg_dist2(px, py, ax, ay, bx, by):
    """Squared distance from point p to segment ab."""
    vx, vy = bx - ax, by - ay
    wx, wy = px - ax, py - ay
    L2 = vx * vx + vy * vy
    if L2 <= 0.0:
        return wx * wx + wy * wy
    t = (wx * vx + wy * vy) / L2
    t = 0.0 if t < 0.0 else (1.0 if t > 1.0 else t)
    dx, dy = wx - t * vx, wy - t * vy
    return dx * dx + dy * dy


def point_to_line_m(pt, pts):
    """Distance in metres from a point to a polyline. inf for a degenerate line."""
    if not pts:
        return math.inf
    if len(pts) == 1:
        return math.hypot(pt[0] - pts[0][0], pt[1] - pts[0][1])
    best = math.inf
    px, py = pt
    for i in range(len(pts) - 1):
        d2 = _seg_dist2(px, py, pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1])
        if d2 < best:
            best = d2
    return math.sqrt(best)


class Grid:
    """Uniform bucket index over points. ~40x faster than a linear scan on 1,916 poles,
    and the whole walk does tens of thousands of nearest-pole queries."""

    def __init__(self, items, cell=40.0):
        self.cell = cell
        self.buckets = defaultdict(list)
        for it in items:
            if it.get("x") is None:
                continue
            self.buckets[(int(it["x"] // cell), int(it["y"] // cell))].append(it)

    def near(self, x, y, radius):
        c = self.cell
        r = int(radius // c) + 1
        cx, cy = int(x // c), int(y // c)
        out = []
        for i in range(cx - r, cx + r + 1):
            for j in range(cy - r, cy + r + 1):
                out.extend(self.buckets.get((i, j), ()))
        return out

    def nearest(self, x, y, radius=60.0):
        best, bd = None, math.inf
        for it in self.near(x, y, radius):
            d = math.hypot(it["x"] - x, it["y"] - y)
            if d < bd:
                best, bd = it, d
        return best, bd


class ModelError(RuntimeError):
    """A refusal. Always names the PON / label at fault — never a silent skip."""


class SpliceModel:
    """The whole project, resolved. Build once, render many times."""

    def __init__(self, snapshot, profile):
        self.snap = snapshot
        self.p = profile
        self.tol = profile.tolerance_m
        self.problems = []          # non-fatal findings, surfaced in the verdict
        self._index()
        self._resolve_pons()
        self._resolve_feeders()
        self._resolve_drops()
        self._resolve_distribution()

    # ── indexing ─────────────────────────────────────────────────────────────
    def _index(self):
        s = self.snap
        self.poles = s["poles"]
        self.pole_by_code = {}
        for p in self.poles:
            self.pole_by_code.setdefault(p["code"], p)
        self.pole_grid = Grid(self.poles)

        self.dome_by_label = {d["label"]: d for d in s["domes"]}
        self.dome_by_pole = defaultdict(list)
        for d in s["domes"]:
            self.dome_by_pole[d["pole"]].append(d)

        self.cables = s["cables"]
        self.cable_by_label = {}
        for c in self.cables:
            self.cable_by_label.setdefault(c["label"], c)
        self.dist_by_pon = defaultdict(list)
        for c in self.cables:
            if c["role"] == "distribution":
                self.dist_by_pon[c["pon"]].append(c)
        self.feeder_cables = [c for c in self.cables if c["role"] in ("primary", "secondary")]

        self.zone_by_pon = {p["pon"]: p["zone"] for p in s["pons"]}

    # ── PONs, from the FTS labels (the OLT port is the identity) ─────────────
    def _resolve_pons(self):
        self.fts_by_pon = {}
        for f in self.snap["fts"]:
            pon = self.p.pon_of(f["card"], f["port"])
            if pon is None:
                raise ModelError(
                    f"OLT card C{f['card']} is not in the profile's card_offsets, so "
                    f"{f['label']} cannot be given a PON number. Add the card, or use a "
                    f"profile that matches this project.")
            if pon in self.fts_by_pon:
                raise ModelError(f"two FTS splitters claim PON {pon}: "
                                 f"{self.fts_by_pon[pon]['label']} and {f['label']}")
            f["pon"] = pon
            f["olt_port"] = self.p.olt_port(f["card"], f["port"])
            self.fts_by_pon[pon] = f

        self.sts_by_pon = defaultdict(list)
        for t in self.snap["sts"]:
            pon = self.p.pon_of(t["card"], t["port"])
            t["pon"] = pon
            t["olt_port"] = self.p.olt_port(t["card"], t["port"])
            self.sts_by_pon[pon].append(t)
        for pon in self.sts_by_pon:
            self.sts_by_pon[pon].sort(key=lambda t: t["leg"])
        self.pons = sorted(self.fts_by_pon)

        # Derive card_offsets from the data and check the profile agrees. A profile that
        # disagrees with the network it is pointed at is a refusal, not a warning.
        seen = defaultdict(set)
        for f in self.snap["fts"]:
            if f.get("pon_attr"):
                seen[f["card"]].add(f["pon_attr"] - f["port"])
        for card, offsets in seen.items():
            if len(offsets) == 1:
                derived = offsets.pop()
                declared = self.p.card_offsets.get(card)
                if declared is not None and declared != derived:
                    raise ModelError(
                        f"profile says card C{card} offset {declared}, the data says "
                        f"{derived}. One of them is wrong — refusing to guess.")

    # ── feeder ───────────────────────────────────────────────────────────────
    def _cable_through(self, xy, candidates, exclude=None):
        """Cables from `candidates` whose geometry passes within tolerance of xy."""
        hits = []
        for c in candidates:
            if exclude is not None and c["label"] == exclude:
                continue
            d = point_to_line_m(xy, c["pts"])
            if d <= self.tol:
                hits.append((d, c))
        hits.sort(key=lambda t: t[0])
        return [c for _, c in hits]

    def _joint_name_at(self, code):
        """R2: name a splice point — dome if one sits there, else manhole, else pole."""
        domes = self.dome_by_pole.get(code)
        if domes:
            # AGG before DIS: an AGG dome is the more significant closure at a pole.
            domes = sorted(domes, key=lambda d: 0 if d["kind"] == "AGG" else 1)
            return domes[0]["label"]
        if code in self.pole_by_code:
            return self.p.pole_label(code)
        return code

    def _start_code(self, cable):
        """The pole/manhole code a cable starts from, taken from its label and CONFIRMED
        against geometry. Label and geometry disagreeing is a finding, not a silent pick."""
        raw = cable.get("start_raw") or ""
        mh = self.p.parse("manhole", raw)
        if mh:
            return "MH." + mh["code"], raw
        code = raw.split(".")[-1]
        pole = self.pole_by_code.get(code)
        if pole and cable["pts"]:
            d = math.hypot(pole["x"] - cable["pts"][0][0], pole["y"] - cable["pts"][0][1])
            d_end = math.hypot(pole["x"] - cable["pts"][-1][0], pole["y"] - cable["pts"][-1][1])
            if d > self.tol and d_end <= self.tol:
                self.problems.append(
                    f"cable {cable['label']} is drawn end-to-start: its label's start pole "
                    f"{code} is at the LAST vertex ({d_end:.2f} m) not the first ({d:.2f} m)")
        return code, raw

    def _resolve_feeders(self):
        """R1 + R2 + R3. One chain per PON, from the POP to the AGG dome."""
        self.feeder = {}
        primary_rank = defaultdict(list)

        for pon in self.pons:
            f = self.fts_by_pon[pon]
            agg_pole = self.pole_by_code.get(f["pole"])
            if agg_pole is None:
                raise ModelError(f"PON {pon}: AGG dome pole {f['pole']} is not in the poles layer")
            chain, guard = [], 0
            xy = (agg_pole["x"], agg_pole["y"])
            cur = None
            while guard < 12:
                guard += 1
                hits = self._cable_through(xy, self.feeder_cables,
                                           exclude=cur["label"] if cur else None)
                if not hits:
                    break
                cur = hits[0]
                chain.append(cur)
                code, raw = self._start_code(cur)
                if code.startswith("MH."):
                    chain.append({"label": f"{self.p.pop_label}-MH.{code[3:]}",
                                  "role": "duct", "kind": None, "pts": [],
                                  "start_raw": self.p.pop_label, "end_code": code[3:],
                                  "synthetic": True, "mh": raw})
                    break
                nxt = self.pole_by_code.get(code)
                if nxt is None:
                    self.problems.append(
                        f"PON {pon}: feeder cable {cur['label']} starts at {code}, "
                        f"which is not a pole in this project")
                    break
                xy = (nxt["x"], nxt["y"])
            chain.reverse()                       # POP-first order, as the field walks it
            self.feeder[pon] = {"cables": chain, "agg_dome": f["agg_dome"], "fts": f}

        # R3 — fibre = rank of the PON within its own 96F primary.
        for pon in self.pons:
            prim = next((c for c in self.feeder[pon]["cables"]
                         if c.get("role") == "primary"), None)
            primary_rank[prim["label"] if prim else None].append(pon)
        for _key, pons in primary_rank.items():
            for i, pon in enumerate(sorted(pons), 1):
                self.feeder[pon]["fibre"] = f"F{i}"

        # R2 — the joints between consecutive cables.
        for pon in self.pons:
            fd = self.feeder[pon]
            cabs = fd["cables"]
            joints = []
            for i in range(len(cabs) - 1):
                code, _ = self._start_code(cabs[i + 1])
                if code.startswith("MH."):
                    joints.append(f"{self.p.prefix}.MH.{code[3:]}")
                else:
                    joints.append(self._joint_name_at(code))
            if len(joints) < 2:
                # Measured on MOA: a 2-cable chain repeats the AGG dome in the trailing
                # joint slot rather than leaving it blank. 2 PONs of 66.
                joints.append(fd["agg_dome"])
            fd["joints"] = joints

    # ── drops ────────────────────────────────────────────────────────────────
    def _resolve_drops(self):
        """R8 — resolve each drop to the pole it is spliced at, using BOTH ends."""
        sts_poles = defaultdict(set)
        for t in self.snap["sts"]:
            sts_poles[t["pon"]].add(t["pole"])

        self.drops_by_pole = defaultdict(list)
        self.drop_unresolved = []
        for d in self.snap["drops"]:
            pon = d["pon"]
            best = None
            for end in ("a", "b"):
                pole, dist = self.pole_grid.nearest(d[end][0], d[end][1], 60.0)
                if pole is None:
                    continue
                on_sts = pole["code"] in sts_poles.get(pon, ())
                # prefer: lands on a pole carrying a splitter of this drop's own PON
                rank = (0 if on_sts else 1, dist)
                if best is None or rank < best[0]:
                    best = (rank, pole, dist, end)
            if best is None or best[0][0] == 1:
                self.drop_unresolved.append(d["label"])
                continue
            pole = best[1]
            d["pole"] = pole["code"]
            self.drops_by_pole[(pon, pole["code"])].append(d)

        for key in self.drops_by_pole:
            # R9 — real drops first, both groups ascending by DR number.
            self.drops_by_pole[key].sort(key=lambda x: (x["spare"], x["label"]))

    # ── distribution ─────────────────────────────────────────────────────────
    def _resolve_distribution(self):
        """R4-R7. Build the per-PON cable tree, attach every STS, number the fibres."""
        self.rows = {}
        for pon in self.pons:
            self.rows[pon] = self._pon_rows(pon)

    def _pon_rows(self, pon):
        f = self.fts_by_pon[pon]
        cabs = self.dist_by_pon.get(pon, [])
        by_label = {c["label"]: c for c in cabs}

        # R4 — main routes leave the AGG dome's pole.
        mains, others = [], []
        for c in cabs:
            code, _ = self._start_code(c)
            c["_start"] = code
            (mains if code == f["pole"] else others).append(c)

        # R5 — parent = the cable this one's start pole sits on. Resolve iteratively so a
        # spur off a spur finds its parent once that parent itself is placed.
        parent = {c["label"]: None for c in cabs}
        placed = {c["label"] for c in mains}
        pending = list(others)
        for _ in range(12):
            if not pending:
                break
            still = []
            for c in pending:
                pole = self.pole_by_code.get(c["_start"])
                if pole is None:
                    self.problems.append(
                        f"PON {pon}: distribution cable {c['label']} starts at "
                        f"{c['_start']}, which is not a pole")
                    continue
                hits = self._cable_through((pole["x"], pole["y"]),
                                           [by_label[x] for x in placed], exclude=c["label"])
                if hits:
                    parent[c["label"]] = hits[0]["label"]
                    placed.add(c["label"])
                else:
                    still.append(c)
            if len(still) == len(pending):
                break
            pending = still
        for c in pending:
            self.problems.append(
                f"PON {pon}: distribution cable {c['label']} does not branch off any other "
                f"cable of this PON — its parent is unresolvable")

        def ancestry(label):
            """[main, ...hops..., label]"""
            out, seen, cur = [], set(), label
            while cur and cur not in seen:
                seen.add(cur)
                out.append(cur)
                cur = parent.get(cur)
            out.reverse()
            return out

        # R6 — attach every STS to the cable that physically passes its dome.
        blocks = []
        for t in self.sts_by_pon.get(pon, []):
            pole = self.pole_by_code.get(t["pole"])
            if pole is None:
                self.problems.append(f"PON {pon}: STS {t['label']} sits at pole "
                                     f"{t['pole']}, which is not in the poles layer")
                continue
            hits = self._cable_through((pole["x"], pole["y"]), cabs)
            if not hits:
                self.problems.append(
                    f"PON {pon}: no distribution cable passes STS {t['label']} at pole "
                    f"{t['pole']} — cannot say which cable it is spliced onto")
                continue
            if len(hits) > 1:
                # Prefer a cable that ENDS here or STARTS here over one merely passing.
                def rank(c):
                    ends = c["pts"][-1] if c["pts"] else (0, 0)
                    starts = c["pts"][0] if c["pts"] else (0, 0)
                    de = math.hypot(pole["x"] - ends[0], pole["y"] - ends[1])
                    ds = math.hypot(pole["x"] - starts[0], pole["y"] - starts[1])
                    return (0 if min(de, ds) <= self.tol else 1, min(de, ds))
                hits = sorted(hits, key=rank)
            cable = hits[0]
            chain = ancestry(cable["label"])
            blocks.append({"sts": t, "cable": cable, "chain": chain,
                           "ambiguous": len(hits) > 1})

        blocks.sort(key=lambda b: b["sts"]["leg"])

        # R7 — spur fibre: rank of this STS among the STSs on the SAME final cable.
        spur_rank = defaultdict(int)
        rows = []
        for b in blocks:
            t, cable, chain = b["sts"], b["cable"], b["chain"]
            is_main = len(chain) <= 1
            leg = t["leg"]
            if is_main:
                fibre_out = f"F{leg}"
                parent_fibre = spur_fibre = ""
                main_route = ""
                hops = []
                junction = ""
            else:
                spur_rank[cable["label"]] += 1
                k = spur_rank[cable["label"]]
                fibre_out = f"F{k}"
                parent_fibre = f"F{leg}"
                spur_fibre = f"F{k}"
                main_route = chain[0]
                hops = chain[1:-1]
                junction = self.p.pole_label(cable["_start"])
            ports = self.drops_by_pole.get((pon, t["pole"]), [])
            rows.append({
                "step": leg, "route": "Main route" if is_main else "Spur",
                "fts": f["label"], "fts_leg": leg, "fibre_in": f"F{leg}",
                "main_route": main_route,
                "hops": [(h, self.p.pole_label(by_label[h]["_start"])) for h in hops],
                "junction": junction,
                "cable": cable["label"], "parent_fibre": parent_fibre,
                "spur_fibre": spur_fibre,
                "splice_pole": t["pole"], "spliced_joint": t["dis_dome"],
                "fibre_out": fibre_out, "sts": t["label"],
                "ports": ports, "ambiguous": b["ambiguous"],
            })
        return rows

    # ── summary numbers, all measured off the model ──────────────────────────
    def totals(self):
        homes = sum(1 for d in self.snap["drops"] if not d["spare"])
        spares = sum(1 for d in self.snap["drops"] if d["spare"])
        n_sts = len(self.snap["sts"])
        return {
            "n_pons": len(self.pons), "n_fts": len(self.snap["fts"]), "n_sts": n_sts,
            "homes": homes, "spares": spares, "ports": n_sts * self.p.sts_ratio,
            "first_port": self.fts_by_pon[self.pons[0]]["olt_port"] if self.pons else "",
            "last_port": self.fts_by_pon[self.pons[-1]]["olt_port"] if self.pons else "",
            "max_hops": max((len(r["hops"]) for rs in self.rows.values() for r in rs),
                            default=0),
            "max_feeder_cables": max((len(self.feeder[p]["cables"]) for p in self.pons),
                                     default=0),
        }
