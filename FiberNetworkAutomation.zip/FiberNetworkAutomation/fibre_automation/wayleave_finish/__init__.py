"""Finish a hand-drawn HeroTel wayleave: check it (read-only), then generate poles, Span and attributes.

    from fibre_automation.wayleave_finish import check, finish, WayleaveError

No QGIS imports: the plugin's qgis_io turns layers into the plain inputs described in engine.Net.
"""
from .checks import check, summary  # noqa: F401
from .engine import DEFAULTS, WayleaveError, finish  # noqa: F401
