# Erven Tuning Studio — build notes

## Phase 0 — environment + VRAM smoke test ✅ PASS (2026-06-02)
- Hardware: RTX 3050 Laptop, 4.3 GB. torch 2.5.1+cu121, CUDA OK.
- Installed: `sam2`, `segment_anything`, `samgeo 1.3.2`, `ultralytics`. Weights present: `C:/Temp/sam2.1_hiera_tiny.pt`.
- Missing (needed later): `gradio` (+`gradio-imageslider`) for Phase 5 UI; `mobile_sam` (optional fallback).
- **Result:** SAM2.1 Hiera-Tiny, one centre click on a 512 px Mohadin tile →
  load 1.5 s · **segment 1.2 s** · **peak VRAM 0.58 GB** · score 0.844 · clean single mask. Proof: `C:/Temp/sam2_smoke.png`.
- **Implications:**
  - The 4 GB VRAM risk is GONE — only 0.58 GB used, **huge headroom**. We can run SAM2 small/base, or even
    keep the encoded image + add HQ-SAM, without OOM. GeoOSAM (which wanted ≥8 GB for ViT-H) is likely viable
    here with the SAM2-tiny/base backend.
  - bfloat16 autocast on `cuda` works.
- Test: `erven_studio/smoke_test.py` (rerun anytime; prints PASS/FAIL).

## Phase 1 — buildings module + sliders ✅ PASS (2026-06-02)
- `buildings.py`: `propose_buildings(img, transform_6, params, mode)`; mode `sam_auto` (SAM2 automatic masks
  filtered by iou/stability/points_per_side/min_area/max_area/min_solidity + HSV roof-colour gate) and
  `gob_batch` (load footprint GeoJSON, area-filter).
- **Gate:** on a 512 px Mohadin tile, `min_area` 20→120 m² changed count **32 → 1**; georeferenced GeoJSON
  + proof `C:/Temp/phase1_buildings.png` (green roofs traced, veg rejected). Test: `erven_studio/test_phase1.py`.
- Note: harmless SAM2 warning "Skipping post-processing" = the optional compiled connected-components ext
  isn't built; results unaffected (per SAM2 INSTALL.md).

## Phase 2 — teach buildings by example ✅ PASS (2026-06-02)
- `similar.py`: SAM2 auto-masks = candidates; `descriptor()` = LAB colour + log-area + aspect + solidity;
  `find_similar()` z-scores candidates, keeps those nearest to the example(s); `strictness` slider = distance quantile.
  Dependency-light (no PerSAM install needed); 1-N examples.
- **Gate:** 82 candidates; red-roof example → 33, grey example → 33, **Jaccard overlap 0.12** (sets differ
  by example), total **6.0 s** (<15 s). Proof `C:/Temp/phase2_similar.png` (red example matched red roofs).
  Test: `erven_studio/test_phase2.py`.

## Phase 3 — erven module + sliders ✅ PASS (2026-06-02)
- `erven.py`: `generate_erven(buildings_gdf, aoi_gdf, params)` wraps `cadastral_erven` (watershed blocks +
  uniform grid, NO Voronoi). Sliders: merge_m, stand_W (0=auto), stand_depth, orient_snap, min/max area.
- Added `w_override` + `min_area`/`max_area` params to `cadastral_erven.subdivide` (DRY; module + app share it).
- **Gate (formal window, 830 buildings):** stand_W=14 → 640 erven median **381 m²** (≈14×27); stand_W=22 →
  416 erven median **601 m²** (≈22×27); ratio **1.57** = 22/14 exactly. Test: `erven_studio/test_phase3.py`.

## Phase 4 — learn erven from MY examples ✅ PASS (2026-06-02) [DECISIVE]
- `infer_params.fit_params(example_gdf)` -> {stand_W, stand_depth, merge_m}. KEY DESIGN: examples teach
  LOT SIZE/SHAPE (median short/long side of MRR); ORIENTATION stays PER-BLOCK (orient=None, orient_snap)
  because an area has several street directions — forcing one global angle is wrong (proven). erven.py
  honours explicit `orient` if given, else per-block dominant azimuth.
- **Gate:** sampled ~8 CSG stands as "drawn examples" -> fit width 22.1 m -> regenerate -> generated
  median width **22.3 m (0.9% err)**; local orientation vs nearest survey stand (axis mod 90) median
  **4.9 deg**, 86% within 20 deg. Test: `erven_studio/test_phase4.py`.
- Pitfall fixed: compare orientation LOCALLY (nearest CSG, mod 90) not globally — near-square lots flip
  the MRR long/short axis and an area has multiple street orientations.

## Phase 5 — Gradio app + live preview ✅ PASS (2026-06-02)
- `app.py`: all logic in plain fns (load_raster/detect/tune/learn_from_examples/save_config/load_config/
  export) + `build_ui()` binds Gradio widgets. State in module dict `S`. Runs on Mohadin demo .npz or any
  GeoTIFF. `python app.py` -> http://127.0.0.1:7861.
- Installed `gradio` + `gradio-imageslider`.
- **Gate (headless `test_phase5.py`):** detect 54 bldgs; tune W14→18 erven / W22→12 (preview differs);
  learn returns fitted params; config save/load round-trips; export writes buildings/erven/demand;
  `build_ui()` builds OK.
- NOTE: live browser interaction (drag sliders, draw) is verified in Phase 7 when JJ runs it.

## QGIS PLUGIN DOCK ✅ WORKING (2026-06-02) — JJ's preferred interface
- `qgis_worker.py` (venv): params JSON -> buildings (detect_buildings/GOB) -> erven (generate_erven,
  sliders) -> demand; emits PROGRESS lines; self-heals if AOI doesn't overlap buildings (uses hull).
- `qgis_dock.py` (runs IN QGIS): `_Dock` QDockWidget with sliders (source, merge_m, stand_W, stand_depth,
  orient_snap, min/max area) + "Learn lot size from example erven" picker + ▶Run + progress bar; `ErvenTask`
  (QgsTask) shells to venv worker off the main thread, loads Buildings/Erven/Demand (styled) in finished().
  `ErvenStudio.install()` adds the dock + a toolbar button.
- Install (live): bridge exec qgis_dock.py then `ErvenStudio.install()`.
- **Validated end-to-end in QGIS:** dock present, Run -> fresh live AOI export (correct Mohadin bounds)
  -> QgsTask -> worker -> loaded Buildings 21810 / Erven 14051 / Demand 14051. QGIS didn't freeze.
- PITFALL fixed: never pass QGIS objects across the thread (serialize AOI+params to JSON); stale AOI file
  -> self-heal to building hull.
- TODO to PERSIST across QGIS restarts: wire `ErvenStudio.install()` into FiberNetworkAutomation initGui
  (or ship as its own mini-plugin). Phase 7: package the standalone Gradio app as .exe (separate track).
