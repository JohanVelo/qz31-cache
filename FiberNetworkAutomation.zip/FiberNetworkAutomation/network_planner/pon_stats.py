"""How many units are in each PON — counted, not trusted.

"Just show us the numbers of units in that PON" (JJ 2026-07-23). Units are
demand points. This module answers that question for a whole project.

Two things it deliberately does NOT do:

* **It does not trust ``unit_count``.** That column is a cached label value,
  refreshed by ``_pon_refresh_zone_counts`` when the planner remembers to. If a
  demand point was added or deleted since, it is stale — and a merge decision
  made on a stale number is a wrong merge. So the units are COUNTED from the
  demand layer every time, and the stored value is reported alongside only so a
  drift can be spotted.
* **It does not judge.** No capacity rule, no "too small" flag, no suggestion to
  merge. The planner decides what merges; this only shows the numbers.

Field names come from :mod:`field_names`, so this reads projects written by
either generation of the plugin (``zone_id`` or ``pon_num``).

No Qt — QGIS core only, so it can be exercised headless or over the bridge.
"""

from . import field_names as vf_fields

#: Geometry type ids as QGIS reports them via ``QgsVectorLayer.geometryType()``.
_GEOM_POINT = 0
_GEOM_POLYGON = 2


class PonRow(object):
    """One PON's numbers.

    ``units`` is the counted truth. ``stored_units`` is what the layer claims —
    equal in a healthy project, different when the cache went stale.
    """

    __slots__ = (
        "fid",
        "name",
        "pon",
        "splitters",
        "stored_splitters",
        "stored_units",
        "units",
    )

    def __init__(self, pon, name=None, units=0, splitters=0,
                 stored_units=None, stored_splitters=None, fid=None):
        self.pon = pon
        self.name = name
        self.units = units
        self.splitters = splitters
        self.stored_units = stored_units
        self.stored_splitters = stored_splitters
        self.fid = fid

    @property
    def units_are_stale(self):
        """True when the cached count disagrees with the real one."""
        return (self.stored_units is not None
                and int(self.stored_units) != int(self.units))

    def __repr__(self):
        return (f"PonRow(pon={self.pon!r}, units={self.units}, "
                f"splitters={self.splitters})")


def _as_pon(value):
    """Normalise a PON id to int where possible, else a trimmed string.

    Shapefiles hand back PON ids as int, float or string depending on the
    driver and column type; without this, PON 7 and PON "7" and PON 7.0 become
    three different PONs in the tally.
    """
    if value is None:
        return None
    if isinstance(value, bool):          # bool is an int subclass — never a PON
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value) if value == int(value) else value
    s = str(value).strip()
    if not s:
        return None
    try:
        f = float(s)
        return int(f) if f == int(f) else f
    except ValueError:
        return s


def _vector_layers(project):
    try:
        layers = list(project.mapLayers().values())
    except Exception:
        return []
    out = []
    for lyr in layers:
        try:
            if lyr is None or not lyr.isValid():
                continue
            if not hasattr(lyr, "fields") or not hasattr(lyr, "geometryType"):
                continue
            out.append(lyr)
        except Exception:
            continue
    return out


def _geom_type(layer):
    try:
        return int(layer.geometryType())
    except Exception:
        return -1


def find_layers(project):
    """Locate the PON boundary, demand-point and splitter-point layers.

    Chosen by SHAPE + the fields they carry, never by layer name — names vary
    per project ("PON Zone Boundaries Final 5", "PON Groups Final"), and a
    name-based guess is how a tool ends up reading the wrong layer.

    Returns ``(boundary, demand, splitter)``; any may be None.
    """
    boundary = demand = splitter = None
    for lyr in _vector_layers(project):
        gt = _geom_type(lyr)
        has_pon = vf_fields.has(lyr, vf_fields.PON_NUM)
        if not has_pon:
            continue
        if gt == _GEOM_POLYGON and boundary is None:
            boundary = lyr
            continue
        if gt != _GEOM_POINT:
            continue
        # A demand point carries a SIZE-keyed membership column (group_8 /
        # spl_8). A splitter point carries the splitter id itself. Checking the
        # size field FIRST matters: demand layers carry both.
        if vf_fields.size_fields(lyr):
            if demand is None:
                demand = lyr
        elif vf_fields.has(lyr, vf_fields.SPLITTER_ID):
            if splitter is None:
                splitter = lyr
    return boundary, demand, splitter


def _tally_by_pon(layer):
    """{pon: feature count} for a layer, skipping features with no PON."""
    out = {}
    if layer is None:
        return out
    name = vf_fields.resolve(layer, vf_fields.PON_NUM)
    if not name:
        return out
    try:
        feats = layer.getFeatures()
    except Exception:
        return out
    for f in feats:
        try:
            pon = _as_pon(f[name])
        except Exception:
            continue
        if pon is None:
            continue
        out[pon] = out.get(pon, 0) + 1
    return out


def tally_by_containment(boundary_layer, point_layer):
    """{pon: how many of ``point_layer``'s points sit inside that PON polygon}.

    The fallback for a point layer with NO PON column — which is common, not
    exotic: Luke's ``BF_8_Way Splitters`` carries ``fid, ID, drop_count,
    Decription, Cross`` and nothing tying a splitter to a PON. "No column" is not
    "not countable": the points are on the map. Measured on that layer, 970 of
    971 splitters land inside exactly one PON.

    Lives here rather than in ``pon_merge`` so the list the operator READS and
    the values the merge WRITES are produced by the same function — they showed
    different numbers for one release when they were not.

    Returns ``(counts, unplaced)``, or ``(None, 0)`` if it cannot be done.
    """
    counts, unplaced = {}, 0
    if boundary_layer is None or point_layer is None:
        return None, 0
    pon_f = vf_fields.resolve(boundary_layer, vf_fields.PON_NUM)
    if not pon_f:
        return None, 0
    try:
        from qgis.core import QgsSpatialIndex
        idx = QgsSpatialIndex()
        polys = {}
        for f in boundary_layer.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            pon = _as_pon(f[pon_f])
            if pon is None:
                continue
            idx.addFeature(f)
            polys[f.id()] = (pon, g)
        if not polys:
            return None, 0
        # Seed every PON at zero, so a PON holding nothing is reported as 0 and
        # not simply left out — being absent from the tally is how a stale count
        # survives a refresh.
        for pon, _g in polys.values():
            counts.setdefault(pon, 0)
        for f in point_layer.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            placed = False
            for fid in idx.intersects(g.boundingBox()):
                pon, pg = polys.get(fid, (None, None))
                if pg is not None and pg.contains(g):
                    counts[pon] = counts.get(pon, 0) + 1
                    placed = True
                    break
            if not placed:
                unplaced += 1
    except Exception:
        return None, 0
    return counts, unplaced


def splitter_counts_for(boundary, splitter):
    """Splitters per PON — by their PON column if they have one, else by shape."""
    if splitter is None:
        return {}
    if vf_fields.has(splitter, vf_fields.PON_NUM):
        return _tally_by_pon(splitter)
    counts, _unplaced = tally_by_containment(boundary, splitter)
    return counts or {}


def collect(project, boundary=None, demand=None, splitter=None):
    """Every PON in the project with its counted unit and splitter totals.

    Sorted by PON, numeric PONs before string ones so a mixed project still
    lists deterministically instead of raising on the comparison.
    """
    if boundary is None and demand is None and splitter is None:
        boundary, demand, splitter = find_layers(project)

    unit_counts = _tally_by_pon(demand)
    # By PON column when there is one, otherwise by which polygon each splitter
    # sits in. Counting by attribute alone made this list report "0 splitters"
    # for every PON on a layer with no PON column, while the merge went on to
    # write the correct 31 — the operator was shown numbers that contradicted
    # what the tool was about to do.
    splitter_counts = splitter_counts_for(boundary, splitter)

    rows = {}
    # Seed from the boundary layer so a PON with zero demand points still shows
    # up — an empty PON is exactly the kind of thing worth seeing.
    if boundary is not None:
        pon_f = vf_fields.resolve(boundary, vf_fields.PON_NUM)
        name_f = vf_fields.resolve(boundary, vf_fields.PON_NAME)
        uc_f = vf_fields.resolve(boundary, vf_fields.UNIT_COUNT)
        sc_f = vf_fields.resolve(boundary, vf_fields.SPLITTER_COUNT)
        if pon_f:
            try:
                feats = list(boundary.getFeatures())
            except Exception:
                feats = []
            for f in feats:
                try:
                    pon = _as_pon(f[pon_f])
                except Exception:
                    continue
                if pon is None:
                    continue
                rows[pon] = PonRow(
                    pon=pon,
                    name=(f[name_f] if name_f else None),
                    units=unit_counts.get(pon, 0),
                    splitters=splitter_counts.get(pon, 0),
                    stored_units=(f[uc_f] if uc_f else None),
                    stored_splitters=(f[sc_f] if sc_f else None),
                    fid=f.id(),
                )

    # Any PON that only the demand/splitter layers know about — a boundary that
    # was never drawn. Silently dropping those would under-report the project.
    for pon in set(unit_counts) | set(splitter_counts):
        if pon not in rows:
            rows[pon] = PonRow(pon=pon,
                               units=unit_counts.get(pon, 0),
                               splitters=splitter_counts.get(pon, 0))

    return sorted(rows.values(), key=lambda r: (isinstance(r.pon, str), r.pon))


def summarise(rows):
    """Totals for the header line above the table."""
    rows = list(rows or [])
    units = [r.units for r in rows]
    return {
        "pons": len(rows),
        "units": sum(units),
        "splitters": sum(r.splitters for r in rows),
        "smallest": min(units) if units else 0,
        "largest": max(units) if units else 0,
        "stale": sum(1 for r in rows if r.units_are_stale),
    }
