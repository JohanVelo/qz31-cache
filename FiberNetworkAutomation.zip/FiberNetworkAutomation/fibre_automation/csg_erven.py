"""csg_erven — fetch REAL surveyed erven (property polygons) from the South African
Chief Surveyor-General cadastral MapServer for an AOI bbox.

This is the authoritative source of erf boundaries for SA — far better than deriving
a synthetic stand grid. Layer 2 of the CSG service is Erven (PRCL_TYPE='E'). The
service caps results per query, so we paginate. Pure stdlib + shapely for the core;
a geopandas wrapper is provided for the erven_studio worker.

Coverage is honest: formal townships are surveyed (Mohadin returns ~8.9k erven);
genuinely informal/un-surveyed pockets return nothing there — the caller falls back
to the derived grid for those.
"""
import json
import urllib.parse
import urllib.request

# Council for Geoscience mirror of the CSG cadastre. Layer 6 = "SA Erf", national.
# The DRDLR/DFFE hosts are all unreachable (measured 2026-08-11: drdlr NXDOMAIN,
# dalrrd + dffeportal refuse TCP 443). Identical schema, so this is a straight
# swap — PRCL_KEY / PRCL_TYPE / GEOM_AREA all still present, and this module
# asks for outFields="*" anyway.
LAYER_URL = ("https://maps.geoscience.org.za/hosting/rest/services/"
             "Administrative_Boundaries_and_Cadastral_Data/MapServer/6/query")
_PAGE = 1000
_TIMEOUT = 150   # the CSG server answers a bbox query in 45-60s when busy (measured 2026-08-11); 60s was right on the edge and produced timeouts


def _get(params):
    url = LAYER_URL + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": "VelocityNexus/CSG"})
    with urllib.request.urlopen(req, timeout=_TIMEOUT) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def count(bbox):
    """How many erven intersect the bbox (xmin,ymin,xmax,ymax in EPSG:4326)."""
    xmin, ymin, xmax, ymax = bbox
    try:
        d = _get({"geometry": f"{xmin},{ymin},{xmax},{ymax}",
                  "geometryType": "esriGeometryEnvelope", "inSR": "4326",
                  "spatialRel": "esriSpatialRelIntersects",
                  "returnCountOnly": "true", "f": "json"})
        return int(d.get("count", 0))
    except Exception:
        return -1


def _rings_to_poly(rings):
    from shapely.geometry import Polygon
    polys = [Polygon(r) for r in (rings or []) if len(r) >= 4]
    if not polys:
        return None
    polys.sort(key=lambda p: p.area, reverse=True)
    ext = polys[0]
    holes = [list(p.exterior.coords) for p in polys[1:]
             if ext.contains(p.representative_point())]
    return Polygon(ext.exterior.coords, holes) if holes else ext


def fetch_erven(bbox):
    """Return [(prcl_key, area_m2, shapely_polygon)] for erven (PRCL_TYPE='E')
    intersecting bbox (EPSG:4326), paginated past the server limit."""
    xmin, ymin, xmax, ymax = bbox
    base = {"geometry": f"{xmin},{ymin},{xmax},{ymax}",
            "geometryType": "esriGeometryEnvelope", "inSR": "4326", "outSR": "4326",
            "spatialRel": "esriSpatialRelIntersects", "outFields": "*",
            "returnGeometry": "true", "f": "json"}
    out, offset = [], 0
    while True:
        d = _get({**base, "resultOffset": offset, "resultRecordCount": _PAGE})
        fs = d.get("features", [])
        for ft in fs:
            a = ft.get("attributes", {})
            if str(a.get("PRCL_TYPE", "")).strip().upper() != "E":
                continue
            g = _rings_to_poly((ft.get("geometry") or {}).get("rings"))
            if g is None or g.is_empty:
                continue
            out.append((a.get("PRCL_KEY"), a.get("GEOM_AREA"), g))
        if len(fs) < _PAGE and not d.get("exceededTransferLimit"):
            break
        if not fs:
            break
        offset += len(fs)
    return out


def _empty_erven():
    import geopandas as gpd
    return gpd.GeoDataFrame({"prcl_key": [], "area_m2": [], "source": []},
                            geometry=[], crs="EPSG:4326")


def gap_fill_erven(csg_gdf, buildings_gdf, aoi_gdf, utm_epsg=32735,
                   min_area_m2=8.0, cap_radius_m=35.0):
    """Derive ONE erf for EVERY house that falls outside a surveyed CSG erf
    (informal/un-surveyed pockets). Each gap-house gets its Voronoi cell, clipped to
    the gap region AND to a `cap_radius_m` buffer around the house — so the erf
    always contains its house (never dropped for being too big) and never sprawls
    across empty veld. Result: ~100% house coverage. Returns GeoDataFrame (4326)."""
    import geopandas as gpd
    from shapely.geometry import MultiPoint
    from shapely.ops import unary_union, voronoi_diagram
    from shapely.strtree import STRtree

    aoi = unary_union(aoi_gdf.to_crs(4326).geometry)
    csg_u = unary_union(csg_gdf.to_crs(4326).geometry) if len(csg_gdf) else None
    gap = aoi.difference(csg_u) if (csg_u and not csg_u.is_empty) else aoi
    if gap.is_empty:
        return _empty_erven()
    b = buildings_gdf.to_crs(4326)
    cent = gpd.GeoSeries([g.representative_point() for g in b.geometry], crs="EPSG:4326")
    cent = cent[cent.within(gap)]
    if len(cent) < 3:
        return _empty_erven()
    pts = list(cent.to_crs(utm_epsg).geometry)
    gap_utm = gpd.GeoSeries([gap], crs="EPSG:4326").to_crs(utm_epsg).iloc[0]
    vor = voronoi_diagram(MultiPoint(pts), envelope=gap_utm)
    tree = STRtree(pts)
    cells, areas = [], []
    for cell in vor.geoms:
        # the generator house point inside this Voronoi cell
        gp = next((pts[i] for i in tree.query(cell) if cell.contains(pts[i])), None)
        if gp is None:
            continue
        erf = cell.intersection(gap_utm).intersection(gp.buffer(cap_radius_m))
        if erf.is_empty:
            continue
        for part in (erf.geoms if erf.geom_type.startswith("Multi") else [erf]):
            if part.geom_type == "Polygon" and part.area >= min_area_m2:
                cells.append(part)
                areas.append(part.area)
    g = gpd.GeoDataFrame({"prcl_key": [None] * len(cells), "area_m2": areas,
                          "source": ["derived"] * len(cells)},
                         geometry=cells, crs=f"EPSG:{utm_epsg}")
    return g.to_crs("EPSG:4326")


def fetch_erven_gdf(bbox, max_area_m2=5000.0):
    """GeoDataFrame (EPSG:4326) of erven for the bbox. Giant non-residential
    parcels (> max_area_m2, e.g. farms/public places) are dropped so the result is
    house-bearing stands. Returns an empty GeoDataFrame if the area is un-surveyed."""
    import geopandas as gpd
    recs = fetch_erven(bbox)
    rows, geoms = [], []
    for key, area, g in recs:
        if max_area_m2 and area and float(area) > max_area_m2:
            continue
        rows.append({"prcl_key": key, "area_m2": area})
        geoms.append(g)
    return gpd.GeoDataFrame(rows, geometry=geoms, crs="EPSG:4326")
