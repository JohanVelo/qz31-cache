"""structure_adapter — bridge QGIS project layers to the walk-engine contracts.

The walk engine (structure_graph.py + numbering.py) is pure-Python and knows
nothing about QGIS: it consumes Segment/Point dicts and a HierarchyConfig, and
produces labels numbered in PHYSICAL network order (a DFS pre-order walk from
the POP outward). This module is the ONLY QGIS-aware piece: it reads the
project's cable/splitter/ONT/POP layers into those contracts, and offers the
one-call glue walk_number() = build_graph -> traverse -> assign_labels.

Contracts (from structure_graph):
    Segment = {"id": fid, "cls": <tier tag>, "coords": [(lon,lat), ...],
               "size": optional number}
    Point   = {"id": fid, "role": <tier tag>, "xy": (lon,lat), "attrs": dict}

The QGIS reads live in extract() (lazy QGIS import). Everything else — the
per-client HierarchyConfig and the walk_number() glue — is pure Python and is
covered by _self_test() with a synthetic Fibertime-shaped network, so this
module imports and self-tests in plain Python 3.12 without QGIS.
"""
from .numbering import HierarchyConfig, Level, assign_labels
from .structure_graph import DEG_PER_M, build_graph, traverse

# Canonical tier tags — the cls (cables) / role (points) each Segment/Point
# carries, and what the HierarchyConfig levels match on.
POP, PRIMARY, SECONDARY, FTS, DISTRIBUTION, STS, DROP, ONT = (
    "POP", "PRIMARY", "SECONDARY", "FTS", "DISTRIBUTION", "STS", "DROP", "ONT")

# Canonical PH2 / Fibertime layer name -> (tier tag, kind). "v1" layers are the
# canonical ones (see memory: poles v1 / *_v1 are the source of truth).
FIBERTIME_LAYER_TIERS = {
    "POP": (POP, "point"),
    "Primary Cable v1": (PRIMARY, "cable"),
    "Secondary Cable v1": (SECONDARY, "cable"),
    "FTS Splitters v1": (FTS, "point"),
    "Distribution Cable v1": (DISTRIBUTION, "cable"),
    "STS Splitters v1": (STS, "point"),
    "Drop Cable v1": (DROP, "cable"),
    "ONT v1": (ONT, "point"),
}


def fibertime_hierarchy(constants=None):
    """The Fibertime physical hierarchy, POP outward to ONT (PH2 tiers).

    Walk order: POP -> Primary -> Secondary -> FTS -> Distribution -> STS ->
    Drop -> ONT (the reverse of the ONT->…->POP network hierarchy). Numbering
    is walk_order (chainage-ordered pre-order counter) at every level, so the
    sequence follows the actual fibre path, not arbitrary/spatial order.
    """
    return HierarchyConfig(name="Fibertime walk", constants=dict(constants or {}), levels=(
        Level(POP, POP, None, kind="point", fmt="{level}{n:02d}"),
        Level(PRIMARY, PRIMARY, POP, kind="cable"),
        Level(SECONDARY, SECONDARY, PRIMARY, kind="cable"),
        Level(FTS, FTS, SECONDARY, kind="point"),
        Level(DISTRIBUTION, DISTRIBUTION, FTS, kind="cable"),
        Level(STS, STS, DISTRIBUTION, kind="point"),
        Level(DROP, DROP, STS, kind="cable"),
        Level(ONT, ONT, DROP, kind="point"),
    ))


def walk_number(segments, points, roots, config, existing=None, zones=None,
                snap_m=2.0, tap_m=6.0):
    """Glue: build the graph, walk it from roots, assign walk-order labels.

    Returns (labels, anomalies): labels = {feature_id: label or None};
    anomalies = the flag list from traverse (off-network / zone-mismatch / …).
    Pure Python — no QGIS — so it is unit-testable offline.
    """
    graph = build_graph(segments, points, snap_m=snap_m, tap_m=tap_m)
    walks, anomalies = traverse(graph, roots, config)
    labels = assign_labels(walks, config, anomalies=anomalies,
                           existing=existing, zones=zones)
    return labels, anomalies


def walk_order_index(segments, points, roots, config, snap_m=2.0, tap_m=6.0):
    """Return {feature_id: global pre-order index} following the physical walk.

    This is the LMN integration point: rather than relabel with the walk
    engine's own format, we just take the ORDER — the DFS pre-order position of
    every feature across the whole hierarchy (POP outward) — and hand it to the
    recipe tool's sequence pre-pass so auto-numbering follows the fibre path
    instead of arbitrary/spatial order. Features not reached by the walk are
    simply absent (the caller sorts them last). Pure Python.
    """
    graph = build_graph(segments, points, snap_m=snap_m, tap_m=tap_m)
    walks, _ = traverse(graph, roots, config)
    order = {}
    i = 0
    for w in walks:
        for it in w.get("items", ()):
            fid = it.get("feature_id")
            if fid is not None and fid not in order:
                order[fid] = i
                i += 1
            for m in (it.get("members") or ()):   # merged same-class segments
                if m not in order:
                    order[m] = order[fid]
    return order


# --------------------------------------------------------------------------
# QGIS extraction (the only QGIS-aware code; validated live, not in self-test)
# --------------------------------------------------------------------------
def _to_wgs84_transform(layer):
    """A QgsCoordinateTransform layer-CRS -> EPSG:4326, or None if already 4326."""
    from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform,
                           QgsProject)
    src = layer.crs()
    dst = QgsCoordinateReferenceSystem("EPSG:4326")
    if src == dst:
        return None
    return QgsCoordinateTransform(src, dst, QgsProject.instance())


def _line_coords(geom, tr):
    """Flatten a (multi)line geometry to a list of (lon, lat) vertices."""
    pts = []
    for v in geom.vertices():
        x, y = v.x(), v.y()
        if tr is not None:
            p = tr.transform(x, y)
            x, y = p.x(), p.y()
        pts.append((x, y))
    return pts


def _point_xy(geom, tr):
    """A representative (lon, lat) for any geometry (centroid for poly/line)."""
    c = geom.centroid().asPoint()
    x, y = c.x(), c.y()
    if tr is not None:
        p = tr.transform(x, y)
        x, y = p.x(), p.y()
    return (x, y)


def extract(project=None, layer_tiers=None, size_fields=("cable_size", "size",
            "fibre", "fibres", "capacity"), zone_fields=("zone_no", "zone",
            "pon_no")):
    """Read the project's layers into (segments, points, roots) contracts.

    project     : a QgsProject (defaults to the active instance).
    layer_tiers : {layer_name: (tier_tag, "cable"|"point")} — defaults to
                  FIBERTIME_LAYER_TIERS. Roots = every extracted point whose
                  tier is the config's root level (POP).
    Feature ids are namespaced "<tier>:<fid>" so ids never collide across
    layers. Cable size + point zone are pulled from the first matching field.
    """
    from qgis.core import QgsProject
    project = project or QgsProject.instance()
    layer_tiers = layer_tiers or FIBERTIME_LAYER_TIERS

    by_name = {}
    for lyr in project.mapLayers().values():
        by_name.setdefault(lyr.name(), lyr)

    segments, points, roots = [], [], []
    for name, (tier, kind) in layer_tiers.items():
        lyr = by_name.get(name)
        if lyr is None:
            continue
        tr = _to_wgs84_transform(lyr)
        fields = [f.name() for f in lyr.fields()]
        size_f = next((f for f in size_fields if f in fields), None)
        zone_f = next((f for f in zone_fields if f in fields), None)
        for feat in lyr.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue
            fid = f"{tier}:{feat.id()}"
            if kind == "cable":
                seg = {"id": fid, "cls": tier, "coords": _line_coords(geom, tr)}
                if size_f is not None:
                    try:
                        seg["size"] = float(feat[size_f])
                    except (TypeError, ValueError):
                        pass
                segments.append(seg)
            else:
                attrs = {}
                if zone_f is not None:
                    zv = feat[zone_f]
                    if zv not in (None, ""):
                        attrs["zone"] = zv
                pt = {"id": fid, "role": tier, "xy": _point_xy(geom, tr),
                      "attrs": attrs}
                points.append(pt)
                if tier == POP:
                    roots.append(fid)
    return segments, points, roots


# --------------------------------------------------------------------------
# self-test — synthetic Fibertime-shaped network, no QGIS
# --------------------------------------------------------------------------
def _self_test():
    print("=" * 64)
    print("structure_adapter self-test (synthetic Fibertime network, no QGIS)")
    print("=" * 64)

    def xy(mx, my):
        return (mx * DEG_PER_M, my * DEG_PER_M)

    # POP at origin; a primary run east to an FTS; a distribution run north from
    # the FTS to an STS; two drops from the STS to two ONTs. One clean chain.
    segments = [
        {"id": "PRIMARY:1", "cls": PRIMARY, "size": 144,
         "coords": [xy(0, 0), xy(60, 0)]},
        {"id": "SECONDARY:1", "cls": SECONDARY, "size": 48,
         "coords": [xy(60, 0), xy(120, 0)]},
        {"id": "DISTRIBUTION:1", "cls": DISTRIBUTION, "size": 24,
         "coords": [xy(120, 0), xy(120, 60)]},
        {"id": "DROP:1", "cls": DROP, "coords": [xy(120, 60), xy(140, 70)]},
        {"id": "DROP:2", "cls": DROP, "coords": [xy(120, 60), xy(140, 50)]},
    ]
    points = [
        {"id": "POP:1", "role": POP, "xy": xy(0, 0), "attrs": {"zone": 17}},
        {"id": "FTS:1", "role": FTS, "xy": xy(120, 0), "attrs": {"zone": 17}},
        {"id": "STS:1", "role": STS, "xy": xy(120, 60), "attrs": {"zone": 17}},
        {"id": "ONT:1", "role": ONT, "xy": xy(140, 70), "attrs": {"zone": 17}},
        {"id": "ONT:2", "role": ONT, "xy": xy(140, 50), "attrs": {"zone": 17}},
    ]
    cfg = fibertime_hierarchy(constants={})
    labels, anomalies = walk_number(segments, points, ["POP:1"], cfg)

    # every non-flagged feature gets a label; POP is the root; parent-before-child
    labelled = {k: v for k, v in labels.items() if v is not None}
    assert labels.get("POP:1"), f"POP not labelled: {labels}"
    for fid in ("PRIMARY:1", "SECONDARY:1", "FTS:1", "DISTRIBUTION:1",
                "STS:1", "DROP:1", "DROP:2", "ONT:1", "ONT:2"):
        assert labels.get(fid) is not None, f"{fid} not labelled: {labels}"
    print(f"  [PASS] all 10 features labelled in walk order ({len(labelled)}/10)")

    # the two ONTs get distinct labels (unique within the STS parent scope)
    assert labels["ONT:1"] != labels["ONT:2"], "sibling ONTs share a label"
    print("  [PASS] sibling ONTs numbered distinctly")

    # an off-network stray ONT (far away) is flagged, not mis-numbered
    seg2 = segments + []
    pts2 = points + [{"id": "ONT:99", "role": ONT, "xy": xy(9000, 9000),
                      "attrs": {}}]
    labels2, _ = walk_number(seg2, pts2, ["POP:1"], cfg)
    assert labels2.get("ONT:99") is None, "stray ONT should be None, not numbered"
    print("  [PASS] off-network stray ONT -> None (never mis-numbered)")

    # walk_order_index follows the physical path: POP < Primary < … < ONT
    idx = walk_order_index(segments, points, ["POP:1"], cfg)
    chain = ["POP:1", "PRIMARY:1", "SECONDARY:1", "FTS:1", "DISTRIBUTION:1",
             "STS:1"]
    for a, b in zip(chain, chain[1:]):
        assert idx[a] < idx[b], f"walk order not monotonic: {a}={idx[a]} {b}={idx[b]}"
    assert idx["STS:1"] < idx["DROP:1"] and idx["DROP:1"] < idx["ONT:1"], "drop/ONT order"
    print("  [PASS] walk_order_index monotonic POP->Primary->...->STS->Drop->ONT")

    print("\nSTRUCTURE_ADAPTER SELF-TEST: ALL CHECKS PASSED")
    return True


if __name__ == "__main__":
    import sys
    if "--self-test" in sys.argv:
        sys.exit(0 if _self_test() else 1)
    print("structure_adapter — run with --self-test")
