# Fibertime: Generate PON Zone Polygons from Demand Points (MOA standard)
# Clusters demand points into groups of ~max_units using spatial grid approach.
# Outputs a polygon layer with all Fibertime PON fields populated.

import math
from collections import defaultdict

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterString,
    QgsProcessingParameterNumber,
    QgsProcessingParameterFeatureSink,
    QgsProcessing,
    QgsFeature,
    QgsFeatureSink,
    QgsFields,
    QgsField,
    QgsGeometry,
    QgsWkbTypes,
    QgsSpatialIndex,
    QgsDistanceArea,
    QgsUnitTypes,
)
from qgis.PyQt.QtCore import QMetaType

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass


class FTPonZoneAlgorithm(QgsProcessingAlgorithm):
    """Generate PON zone polygons by clustering demand points into groups
    of ~max_units using a spatial grid approach. Outputs a polygon layer
    with all Fibertime PON fields populated (label, pon_no, zone_no, units,
    type, subtyp, spec, stackref, n_sts)."""

    INPUT_DEMAND  = 'INPUT_DEMAND'
    INPUT_ZONES   = 'INPUT_ZONES'
    SR_CODE       = 'SR_CODE'
    MAX_UNITS     = 'MAX_UNITS'
    MIN_UNITS     = 'MIN_UNITS'
    PON_START_NO  = 'PON_START_NO'
    OUTPUT        = 'OUTPUT'

    def name(self):
        return 'ft_generate_pon_zones'

    def displayName(self):
        return 'FT 5. Generate PON Zones'

    def group(self):
        return 'Fibertime Network Labeling'

    def groupId(self):
        return 'fibertimenetworklabeling'

    def createInstance(self):
        return FTPonZoneAlgorithm()

    def shortHelpString(self):
        return """
        Generate PON zone polygons from demand points using spatial grid clustering.

        For each zone polygon: clusters demand points into groups of ~max_units,
        creates a convex hull polygon per cluster, and populates all Fibertime
        PON fields (label, pon_no, zone_no, units, type, subtyp, spec, stackref, n_sts).

        Label format: C{zone_no}P{local_pon_idx}
        Example:      C1P1, C1P2, ..., C2P1, C2P2

        2-stage splitter context (Phase 2 / MOA — Combo 1):
        - FTS (1:8 aggregation):   MOA.FTS.8.AGG.DM.P.[pole]-OLT.01.[pon_label]
        - STS (1:16 distribution): MOA.STS.16.DIS.DM.P.[pole].[pon_label].L[n]
        - n_sts = CEIL(units / 16) — must not exceed 8 (FTS port limit)

        Inputs:
        - Demand Points: point layer (one point per connectable home)
        - Zones: polygon layer with zone_no INTEGER field
        - SR Code: stack reference prefix (default MOA)
        - Max Units: target homes per PON (default 96, max spec 102)
        - Min Units: minimum homes; clusters below this merge with neighbour (default 80)
        - PON Start No: first global pon_no (Phase 2: set to last Phase 1 pon_no + 1)

        Validation flags written to Processing Log:
        - PONs with < min_units or > 109 homes
        - PONs where CEIL(units/8) > 16 (FTS port overflow)
        """

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.INPUT_DEMAND,
            'Demand Points',
            [QgsProcessing.SourceType.TypeVectorPoint]
        ))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.INPUT_ZONES,
            'Zones (polygon layer with zone_no field)',
            [QgsProcessing.SourceType.TypeVectorPolygon]
        ))
        self.addParameter(QgsProcessingParameterString(
            self.SR_CODE,
            'SR Code (stackref prefix, e.g. MOA)',
            defaultValue='MOA'
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.MAX_UNITS,
            'Max Units per PON (design target)',
            type=QgsProcessingParameterNumber.Type.Integer,
            defaultValue=96, minValue=8, maxValue=128
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.MIN_UNITS,
            'Min Units per PON (merge clusters below this)',
            type=QgsProcessingParameterNumber.Type.Integer,
            defaultValue=80, minValue=4, maxValue=96
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.PON_START_NO,
            'PON Start Number (global pon_no for first PON)',
            type=QgsProcessingParameterNumber.Type.Integer,
            defaultValue=1, minValue=1
        ))

        # Define output fields for the PON polygon sink
        pon_fields = QgsFields()
        for fname, qtype in [
            ('label',    QMetaType.Type.QString),
            ('pon_no',   QMetaType.Type.Int),
            ('zone_no',  QMetaType.Type.Int),
            ('units',    QMetaType.Type.Int),
            ('type',     QMetaType.Type.QString),
            ('subtyp',   QMetaType.Type.QString),
            ('spec',     QMetaType.Type.QString),
            ('stackref', QMetaType.Type.QString),
            ('n_sts',    QMetaType.Type.Int),
        ]:
            pon_fields.append(QgsField(fname, qtype))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT,
            'PON Zones (output polygon layer)',
            QgsProcessing.SourceType.TypeVectorPolygon
        ))

    def processAlgorithm(self, parameters, context, feedback):
        demand_layer = self.parameterAsVectorLayer(parameters, self.INPUT_DEMAND, context)
        zones_layer  = self.parameterAsVectorLayer(parameters, self.INPUT_ZONES, context)
        sr_code      = (self.parameterAsString(parameters, self.SR_CODE, context) or 'MOA').strip()
        max_units    = self.parameterAsInt(parameters, self.MAX_UNITS, context)
        min_units    = self.parameterAsInt(parameters, self.MIN_UNITS, context)
        pon_start    = self.parameterAsInt(parameters, self.PON_START_NO, context)

        # Build output PON fields
        pon_fields = QgsFields()
        for fname, qtype in [
            ('label',    QMetaType.Type.QString),
            ('pon_no',   QMetaType.Type.Int),
            ('zone_no',  QMetaType.Type.Int),
            ('units',    QMetaType.Type.Int),
            ('type',     QMetaType.Type.QString),
            ('subtyp',   QMetaType.Type.QString),
            ('spec',     QMetaType.Type.QString),
            ('stackref', QMetaType.Type.QString),
            ('n_sts',    QMetaType.Type.Int),
        ]:
            pon_fields.append(QgsField(fname, qtype))

        (sink, dest_id) = self.parameterAsSink(
            parameters, self.OUTPUT, context,
            pon_fields, QgsWkbTypes.Type.Polygon,
            demand_layer.crs()
        )

        # Load all demand points into memory (point geometry per fid)
        all_points = {}
        for feat in demand_layer.getFeatures():
            g = feat.geometry()
            if not g or g.isEmpty():
                continue
            all_points[feat.id()] = g.asPoint()

        if not all_points:
            feedback.reportError("Demand Points layer is empty — no PONs generated.")
            return {self.OUTPUT: dest_id}

        # Build spatial index over demand points for fast bbox queries
        demand_index = QgsSpatialIndex(demand_layer.getFeatures())

        # Degenerate (1- or 2-point) clusters get a 10 m placeholder buffer.
        # Buffer distance is in the layer's native CRS units, so convert 10 m
        # to that unit — for a geographic CRS (e.g. EPSG:4326) raw 10 would be
        # ~1,110 km, not 10 m. Use QgsDistanceArea for a CRS-correct factor.
        buffer_dist = self._metres_to_layer_units(10.0, demand_layer.crs(), context)

        global_pon_no = pon_start
        total_zones   = zones_layer.featureCount()
        validation_issues = []

        if zones_layer.fields().indexOf('zone_no') < 0:
            raise QgsProcessingException(
                "Zones layer must have a 'zone_no' field (FT 5 requires it).")

        for z_idx, zone_feat in enumerate(zones_layer.getFeatures()):
            if feedback.isCanceled():
                return {}

            zone_no   = zone_feat['zone_no']
            if zone_no is None:
                feedback.pushWarning("  Zone with NULL zone_no — skipping (set a valid zone_no integer)")
                continue
            zone_geom = zone_feat.geometry()
            if not zone_geom or zone_geom.isEmpty():
                feedback.pushWarning(f"  Zone {zone_no}: null/empty geometry — skipping")
                continue

            feedback.pushInfo(f"Processing Zone {zone_no} ({z_idx + 1}/{total_zones})...")
            feedback.setProgress(int(z_idx / max(total_zones, 1) * 80))

            # Collect demand points spatially inside this zone
            bbox_ids = demand_index.intersects(zone_geom.boundingBox())
            zone_pts = {}
            for fid in bbox_ids:
                pt = all_points.get(fid)
                if pt and zone_geom.contains(QgsGeometry.fromPointXY(pt)):
                    zone_pts[fid] = pt

            n_pts = len(zone_pts)
            if n_pts == 0:
                feedback.pushWarning(f"  Zone {zone_no}: no demand points — skipping")
                continue

            feedback.pushInfo(f"  Zone {zone_no}: {n_pts} demand points "
                              f"→ ~{math.ceil(n_pts / max_units)} PONs expected")

            # Cluster demand points using spatial grid
            clusters = self._grid_cluster(list(zone_pts.values()), max_units, min_units)

            # Emit one PON polygon per cluster
            local_pon_idx = 1
            for cluster_pts in clusters:
                if feedback.isCanceled():
                    return {}

                units = len(cluster_pts)
                n_sts = math.ceil(units / 16)
                label = f"C{zone_no}P{local_pon_idx}"

                # Build geometry: convex hull of cluster points
                geom = self._cluster_geometry(cluster_pts, buffer_dist)

                # Write PON feature
                feat = QgsFeature(pon_fields)
                feat.setGeometry(geom)
                feat.setAttributes([
                    label,
                    global_pon_no,
                    zone_no,
                    units,
                    'PON',
                    'GPON',
                    'Maximum 102 Units',
                    sr_code,
                    n_sts,
                ])
                sink.addFeature(feat, QgsFeatureSink.Flag.FastInsert)

                # Validation checks — log issues, don't fail
                if units < min_units or units > 109:
                    validation_issues.append(
                        f"  {label} (pon_no={global_pon_no}): {units} homes "
                        f"({'UNDER' if units < min_units else 'OVER'} spec)"
                    )
                if n_sts > 8:
                    validation_issues.append(
                        f"  {label} (pon_no={global_pon_no}): {n_sts} STS needed "
                        f"— exceeds 8 FTS port limit"
                    )

                local_pon_idx += 1
                global_pon_no += 1

        pons_created = global_pon_no - pon_start
        feedback.setProgress(100)
        feedback.pushInfo(f"✅ Generated {pons_created} PON zones "
                          f"(pon_no {pon_start} – {global_pon_no - 1}).")

        if validation_issues:
            feedback.pushWarning(f"⚠ {len(validation_issues)} validation issue(s):")
            for msg in validation_issues:
                feedback.pushWarning(msg)
        else:
            feedback.pushInfo("All PONs passed validation (80–109 homes, n_sts ≤ 8).")

        return {self.OUTPUT: dest_id}

    # ------------------------------------------------------------------
    # Spatial grid clustering
    # ------------------------------------------------------------------

    def _grid_cluster(self, pts_list, max_units, min_units):
        """
        Divide the bounding box of pts_list into a grid sized to produce
        clusters of approximately max_units points per cell.
        Merges undersized cells with the next cell (row-major order).
        Splits oversized cells by bisection.

        Returns: list of lists of QgsPointXY
        """
        n = len(pts_list)

        # Trivial cases
        if n <= max_units:
            return [pts_list]

        xs = [p.x() for p in pts_list]
        ys = [p.y() for p in pts_list]
        x_min, x_max = min(xs), max(xs)
        y_min, y_max = min(ys), max(ys)

        x_span = x_max - x_min or 1.0
        y_span = y_max - y_min or 1.0

        # Grid dimensions: aspect-ratio aware
        n_pons = math.ceil(n / max_units)
        aspect = x_span / y_span
        n_cols = max(1, round(math.sqrt(n_pons * aspect)))
        n_rows = max(1, math.ceil(n_pons / n_cols))

        x_step = x_span / n_cols
        y_step = y_span / n_rows

        # Assign each point to a (col, row) cell
        cell_map = defaultdict(list)
        for pt in pts_list:
            col = min(int((pt.x() - x_min) / x_step), n_cols - 1)
            row = min(int((pt.y() - y_min) / y_step), n_rows - 1)
            cell_map[(col, row)].append(pt)

        # Flatten to row-major ordered list (left→right, bottom→top)
        ordered_keys = sorted(cell_map.keys(), key=lambda k: (k[1], k[0]))
        clusters = [cell_map[k] for k in ordered_keys if cell_map[k]]

        # Greedy merge: absorb undersized clusters into their successor
        merged = True
        while merged:
            merged = False
            new_clusters = []
            i = 0
            while i < len(clusters):
                current = clusters[i]
                if len(current) < min_units and i + 1 < len(clusters):
                    successor = clusters[i + 1]
                    # Only merge if combined size stays within 25% of max_units
                    if len(current) + len(successor) <= int(max_units * 1.25):
                        new_clusters.append(current + successor)
                        i += 2
                        merged = True
                        continue
                new_clusters.append(current)
                i += 1
            clusters = new_clusters

        # Bisect oversized clusters (simple spatial split on longest axis)
        final_clusters = []
        for cluster in clusters:
            if len(cluster) > int(max_units * 1.25):
                # Sort by x or y (whichever has larger spread) then split at midpoint
                cxs = [p.x() for p in cluster]
                cys = [p.y() for p in cluster]
                if max(cxs) - min(cxs) >= max(cys) - min(cys):
                    cluster_sorted = sorted(cluster, key=lambda p: p.x())
                else:
                    cluster_sorted = sorted(cluster, key=lambda p: p.y())
                mid = len(cluster_sorted) // 2
                final_clusters.append(cluster_sorted[:mid])
                final_clusters.append(cluster_sorted[mid:])
            else:
                final_clusters.append(cluster)

        return final_clusters

    # ------------------------------------------------------------------
    # Geometry builder
    # ------------------------------------------------------------------

    def _metres_to_layer_units(self, metres, crs, context):
        """
        Convert a distance in metres to the layer CRS's native units.
        For a projected (metre) CRS this is ~1:1; for a geographic CRS it
        returns the degree-equivalent so buffer() produces real metres.
        """
        da = QgsDistanceArea()
        da.setSourceCrs(crs, context.transformContext())
        da.setEllipsoid(crs.ellipsoidAcronym() or 'WGS84')
        try:
            # 1 native unit, expressed in metres → invert to scale metres→units
            unit_in_m = da.convertLengthMeasurement(1.0, QgsUnitTypes.DistanceMeters)
            if unit_in_m and unit_in_m > 0:
                return metres / unit_in_m
        except Exception:
            _swallowed_note()
        # Fallback: geographic ≈ degrees, projected ≈ metres
        if crs.isGeographic():
            return metres / 111320.0
        return metres

    def _cluster_geometry(self, pts_list, buffer_dist):
        """
        Build a polygon geometry from a list of QgsPointXY.
        Uses convex hull for 3+ points; falls back to bounding box / buffer
        for degenerate cases. buffer_dist is in the layer's native CRS units
        (the 10 m placeholder converted to those units by the caller).
        """
        if len(pts_list) == 1:
            # Single point — 10m buffer as placeholder polygon
            return QgsGeometry.fromPointXY(pts_list[0]).buffer(buffer_dist, 5)

        if len(pts_list) == 2:
            # Two collinear points — small buffer around line
            line = QgsGeometry.fromPolylineXY(pts_list)
            return line.buffer(buffer_dist, 5)

        # Standard case: convex hull
        multi = QgsGeometry.fromMultiPointXY(pts_list)
        hull  = multi.convexHull()
        if hull.isEmpty():
            # Fallback: bounding box
            bbox = multi.boundingBox()
            return QgsGeometry.fromRect(bbox)
        return hull
