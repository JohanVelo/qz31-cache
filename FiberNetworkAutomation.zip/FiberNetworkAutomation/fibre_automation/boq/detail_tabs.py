"""detail_tabs — one Excel tab per live vector layer = its FULL attribute table.

A shared, client-agnostic writer so every client's BoQ can carry the same in-depth
per-layer attribute tabs the HeroTel bill has (poles, joints, cables, erven, …).
Read-only: it only reads layer names / fields / attributes, never edits a layer.

Self-contained on purpose — it does NOT import from herotel_boq, so refactoring or
re-verifying HeroTel can never be affected by (or affect) this module. The per-layer
writer mirrors the proven HeroTel one.

Design:
  * EVERY non-empty vector layer becomes a tab (rasters/basemaps skipped).
  * v1 (canonical Phase-2) layers are written FIRST.
  * each sheet caps at ``max_rows`` rows with an honest "showing N of M" note, so a
    22 140-feature layer can't bloat the workbook — the billed quantities come from
    the design take-off, these tabs are supporting detail.
"""


def _is_null(v):
    try:
        from qgis.core import NULL
        if v is NULL or v == NULL:
            return True
    except Exception:
        pass
    return v is None


def _clean(v):
    """Make an attribute value Excel-safe (matches herotel_boq._clean)."""
    if v is None or isinstance(v, (int, float, bool)):
        return v
    if isinstance(v, str):
        try:
            from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
            return ILLEGAL_CHARACTERS_RE.sub("", v)
        except Exception:
            return v
    try:
        from qgis.PyQt.QtCore import QDate, QDateTime, QTime
        if isinstance(v, QDateTime):
            return v.toString("yyyy-MM-dd HH:mm:ss")
        if isinstance(v, QDate):
            return v.toString("yyyy-MM-dd")
        if isinstance(v, QTime):
            return v.toString("HH:mm:ss")
    except Exception:
        pass
    try:
        import datetime
        if isinstance(v, (datetime.datetime, datetime.date, datetime.time)):
            return v
    except Exception:
        pass
    return str(v)


def default_styles():
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    return {
        "NAVY": PatternFill("solid", fgColor="1F3864"),
        "WHITE_B": Font(bold=True, color="FFFFFF"),
        "BOLD": Font(bold=True),
        "MUT": Font(color="7F7F7F", italic=True, size=10),
        "CENTER": Alignment(horizontal="center", vertical="center"),
        "THIN": Border(*[Side(style="thin", color="BFBFBF")] * 4),
    }


def _safe_title(name, used):
    """A unique, <=31-char, Excel-legal sheet title (mirrors herotel_boq)."""
    t = str(name)
    for ch in r'[]:*?/\\':
        t = t.replace(ch, " ")
    t = t.strip()[:31] or "Sheet"
    base, i = t, 2
    while t.lower() in used:
        suf = f" ({i})"
        t = base[:31 - len(suf)] + suf
        i += 1
    used.add(t.lower())
    return t


def read_project_tables(project, max_rows=2000):
    """{layer_name: {"fields":[...], "rows":[...], "total":N}} for every non-empty
    live *vector* layer. Rows are capped at ``max_rows`` (``total`` is the true count).
    """
    from qgis.core import QgsVectorLayer
    tables = {}
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
            continue
        total = lyr.featureCount()
        if total <= 0:
            continue
        fnames = [f.name() for f in lyr.fields()]
        rows = []
        for feat in lyr.getFeatures():
            if len(rows) >= max_rows:
                break
            rows.append([(None if _is_null(feat[f]) else feat[f]) for f in fnames])
        tables[lyr.name()] = {"fields": fnames, "rows": rows, "total": total}
    return tables


def full_table_sheet(wb, title, table, S, only_cols=None, total_cols=None, note=None):
    """One full attribute-table tab. Uses ws.append() row-writes and header-only
    styling so it stays fast even at thousands of rows (MOA layers reach 22k); per-cell
    borders are dropped on purpose — cosmetic, and prohibitively slow at that scale."""
    from openpyxl.utils import get_column_letter
    ws = wb.create_sheet(title[:31])
    fields = table.get("fields", [])
    idxs = ([fields.index(c) for c in only_cols if c in fields]
            if only_cols else list(range(len(fields))))
    headers = [fields[i] for i in idxs]

    ws.append(headers)
    for i in range(1, len(headers) + 1):
        c = ws.cell(1, i)
        c.fill = S["NAVY"]; c.font = S["WHITE_B"]; c.alignment = S["CENTER"]

    totals = {c: 0 for c in (total_cols or [])}
    for row in table.get("rows", []):
        ws.append([_clean(row[src]) if src < len(row) else None for src in idxs])
        for c in (total_cols or []):
            if c in headers:
                try:
                    totals[c] += int(float(str(row[fields.index(c)]).replace(",", ".")))
                except (TypeError, ValueError):
                    pass

    if total_cols:
        r = ws.max_row + 1
        ws.cell(r, 1, "TOTAL").font = S["BOLD"]
        for c in total_cols:
            if c in headers:
                ws.cell(r, headers.index(c) + 1, totals[c]).font = S["BOLD"]
    if note:
        ws.cell(ws.max_row + 2, 1, note).font = S["MUT"]

    for i, h in enumerate(headers, 1):
        ws.column_dimensions[get_column_letter(i)].width = max(10, min(28, len(str(h)) + 6))
    ws.freeze_panes = "A2"
    return ws


def select_detail_names(all_names):
    """PURE (no QGIS): from every layer name, pick which get a detail tab and in what
    order. DOMAIN RULE — when a canonical "X v1" layer exists, its bare twin "X" is a
    Phase-1 decoy (bare Drop Cable=22 140 vs Drop Cable v1=6 335); the BoQ is built from
    v1, so we drop the bare twin and keep v1. v1 layers are listed FIRST. Unit-testable.
    """
    def norm(n):
        return str(n).strip().lower()
    v1_bases = {norm(n)[:-2].strip() for n in all_names if norm(n).endswith("v1")}
    keep = [n for n in all_names if norm(n).endswith("v1") or norm(n) not in v1_bases]
    # stable sort: canonical " v1" layers first, original order preserved within group.
    return sorted(keep, key=lambda n: 0 if norm(n).endswith("v1") else 1)


def build_detail_tabs(wb, project, styles=None, max_rows=2000):
    """Append one full-attribute-table tab per non-empty live vector layer.

    v1 (canonical) layers first. Returns the number of tabs written. Never raises
    on a single bad layer — a failed layer is skipped, the rest still write.
    """
    S = styles or default_styles()
    tables = read_project_tables(project, max_rows=max_rows)
    names = select_detail_names(list(tables.keys()))
    used = {ws.title.lower() for ws in wb.worksheets}   # don't clash with summary tabs
    written = 0
    for name in names:
        tbl = tables[name]
        total = tbl.get("total", len(tbl["rows"]))
        shown = len(tbl["rows"])
        note = (f"Full '{name}' attribute table — {total} features."
                if shown >= total else
                f"'{name}' attribute table — showing {shown} of {total} features "
                f"(open the layer in QGIS for all rows).")
        try:
            full_table_sheet(wb, _safe_title(name, used), tbl, S, note=note)
            written += 1
        except Exception:
            continue
    return written
