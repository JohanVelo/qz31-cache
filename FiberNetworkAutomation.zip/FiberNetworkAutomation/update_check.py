"""update_check — notify the user inside the Velocity Nexus panel when a
newer plugin version is on the team channel, with a one-click update.

Checks the channel's plugins.xml (a ~1 KB fetch) shortly after startup and
every 30 minutes after that, fully async via QgsNetworkAccessManager — no
UI blocking, silent on any network failure. When the remote version is
newer than the installed one it shows the panel banner (and a one-time
message-bar notice per version).
"""
from __future__ import annotations

import os
import re

from qgis.core import QgsNetworkAccessManager
from qgis.PyQt.QtCore import QTimer, QUrl
from qgis.PyQt.QtNetwork import QNetworkRequest

PLUGINS_XML_URL = ("https://raw.githubusercontent.com/JohanVelo/qz31-cache/"
                   "main/plugins.xml")
PLUGIN_PKG = "FiberNetworkAutomation"
FIRST_CHECK_MS = 8000           # shortly after startup
RECHECK_MS = 30 * 60 * 1000    # every 30 minutes


def _ver_tuple(s):
    try:
        return tuple(int(x) for x in re.findall(r"\d+", s)[:4])
    except Exception:
        return (0,)


def installed_version():
    mp = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                      "metadata.txt")
    try:
        m = re.search(r"^version=([\d.]+)", open(mp, encoding="utf-8").read(),
                      flags=re.M)
        return m.group(1) if m else "0"
    except Exception:
        return "0"


def do_upgrade():
    """Pull + install the latest zip via QGIS's own plugin installer.
    Module-level on purpose: runs from a timer so it is not executing
    inside a widget of the plugin instance that is about to be replaced."""
    try:
        import pyplugin_installer
        inst = pyplugin_installer.instance()
        inst.fetchAvailablePlugins(True)   # fresh metadata, not this session's
        inst.installPlugin(PLUGIN_PKG)
    except Exception as e:
        try:
            from qgis.utils import iface
            iface.messageBar().pushWarning(
                "Velocity Nexus",
                f"One-click update failed ({e}) — use Plugins → Manage and "
                "Install Plugins → Upgradeable instead.")
        except Exception:
            pass


class UpdateChecker:
    """Owns the timer + async fetch. panel_getter() -> VelocityHomePanel."""

    def __init__(self, iface, panel_getter):
        self.iface = iface
        self._panel_getter = panel_getter
        self._notified_version = None
        self._reply = None
        self._bar_item = None           # persistent message-bar notification
        self._timer = QTimer(iface.mainWindow())
        self._timer.timeout.connect(self.check_now)
        self._timer.start(RECHECK_MS)
        self._first = QTimer(iface.mainWindow())   # owned -> stop() can kill it
        self._first.setSingleShot(True)
        self._first.timeout.connect(self.check_now)
        self._first.start(FIRST_CHECK_MS)

    def stop(self):
        for t in (self._timer, getattr(self, "_first", None)):
            try:
                t.stop()
                t.deleteLater()
            except Exception:
                pass
        if self._reply is not None:
            try:
                self._reply.abort()
            except Exception:
                pass
        self._pop_bar()
        try:
            if getattr(self, "_popup", None) is not None:
                self._popup.close()
                self._popup = None
        except Exception:
            pass

    def _pop_bar(self):
        if self._bar_item is not None:
            try:
                self.iface.messageBar().popWidget(self._bar_item)
            except Exception:
                pass
            self._bar_item = None

    # ── check ────────────────────────────────────────────────────────────
    def check_now(self):
        if self._reply is not None:     # a fetch is already in flight
            return
        try:
            req = QNetworkRequest(QUrl(PLUGINS_XML_URL))
            req.setRawHeader(b"Cache-Control", b"no-cache")
            self._reply = QgsNetworkAccessManager.instance().get(req)
            self._reply.finished.connect(self._on_reply)
        except Exception:
            self._reply = None          # network stack unavailable — retry later

    def _on_reply(self):
        reply, self._reply = self._reply, None
        if reply is None:
            return
        try:
            if int(reply.error()) != 0:    # 0 = NoError in PyQt5 AND PyQt6
                return                  # offline etc. — silently retry later
            xml = bytes(reply.readAll()).decode("utf-8", "replace")
        except Exception:
            return
        finally:
            try:
                reply.deleteLater()
            except Exception:
                pass
        m = re.search(r"<version>([\d.]+)</version>", xml)
        if not m:
            return
        remote = m.group(1)
        local = installed_version()
        if _ver_tuple(remote) <= _ver_tuple(local):
            return
        if remote == self._notified_version:
            self._refresh_banner(remote)
            return                      # already shown for this version
        self._notified_version = remote
        self._refresh_banner(remote)
        self._show_bar(local, remote)
        self._show_popup(local, remote)

    def _show_popup(self, local, remote):
        """Floating themed window — the message bar lives over the map
        canvas, which is INVISIBLE on the QGIS start page (Recent Projects),
        so a freshly-opened QGIS would never see the update. This popup is
        visible everywhere. Once per version per session."""
        try:
            from qgis.PyQt.QtCore import Qt
            from qgis.PyQt.QtWidgets import (QDialog, QHBoxLayout, QLabel,
                                             QPushButton, QVBoxLayout)
            old = getattr(self, "_popup", None)
            if old is not None:
                try:
                    old.close()
                except Exception:
                    pass
            dlg = QDialog(self.iface.mainWindow())
            dlg.setWindowTitle("Velocity Nexus — Update available")
            dlg.setMinimumWidth(420)
            dlg.setStyleSheet(
                "QDialog{background:#0F1A30;}"
                "QLabel{color:#EAF0FF;font-size:12px;}"
                "QLabel#hdr{color:#2ec4f1;font-size:16px;font-weight:800;}"
                "QPushButton{border-radius:7px;padding:8px 18px;"
                "font-weight:700;font-size:12px;}"
                "QPushButton#go{background:#2ec4f1;color:#06121c;border:none;}"
                "QPushButton#go:hover{background:#5fd6ff;}"
                "QPushButton#later{background:transparent;color:#9fb4c8;"
                "border:1px solid #2a3c55;}"
                "QPushButton#later:hover{color:#EAF0FF;}")
            lay = QVBoxLayout(dlg)
            lay.setContentsMargins(20, 16, 20, 16)
            lay.setSpacing(10)
            hdr = QLabel("🚀  Update available")
            hdr.setObjectName("hdr")
            lay.addWidget(hdr)
            body = QLabel(
                f"Velocity Nexus v{remote} is out (you have v{local}) — "
                "new tools and fixes.\nOne click updates it; your "
                "activation is kept.")
            body.setWordWrap(True)
            lay.addWidget(body)
            row = QHBoxLayout()
            row.addStretch(1)
            later = QPushButton("Later")
            later.setObjectName("later")
            later.clicked.connect(dlg.close)
            row.addWidget(later)
            go = QPushButton("Update now")
            go.setObjectName("go")
            go.setCursor(Qt.PointingHandCursor)

            def _go():
                go.setEnabled(False)
                go.setText("Updating…")
                self.upgrade()
                dlg.close()

            go.clicked.connect(_go)
            row.addWidget(go)
            lay.addLayout(row)
            dlg.finished.connect(dlg.deleteLater)
            self._popup = dlg
            dlg.show()
            dlg.raise_()
            dlg.activateWindow()
        except Exception:
            pass

    def _show_bar(self, local, remote):
        """Persistent, can't-miss notification over the canvas with its own
        Update button — stays until the operator acts or dismisses it."""
        try:
            from qgis.core import Qgis
            from qgis.PyQt.QtWidgets import QPushButton
            bar = self.iface.messageBar()
            self._pop_bar()
            item = bar.createMessage(
                "Velocity Nexus",
                f"🚀 Update available — v{local} → v{remote} with new tools "
                "and fixes.")
            btn = QPushButton("Update now")

            def _go():
                btn.setEnabled(False)
                btn.setText("Updating…")
                self.upgrade()

            btn.clicked.connect(_go)
            item.layout().addWidget(btn)
            # duration 0 = stays on screen until clicked or dismissed
            self._bar_item = bar.pushWidget(item, Qgis.Info, 0)
        except Exception:
            pass

    def _refresh_banner(self, remote):
        panel = None
        try:
            panel = self._panel_getter()
        except Exception:
            pass
        if panel is not None:
            try:
                panel.show_update_banner(remote, self.upgrade)
            except Exception:
                pass

    # ── upgrade ──────────────────────────────────────────────────────────
    def upgrade(self):
        self._pop_bar()                 # the old item must not outlive us
        try:
            self.iface.messageBar().pushInfo(
                "Velocity Nexus", "Updating — QGIS will reload the plugin…")
        except Exception:
            pass
        # detach from the panel's call stack before the plugin replaces itself
        QTimer.singleShot(50, do_upgrade)
