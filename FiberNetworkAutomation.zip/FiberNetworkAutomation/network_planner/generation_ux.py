"""Pass 3 — pure, unit-testable result summaries for the three generation steps
(Boundaries, Splitters, Drops).

The geometry MATH (Voronoi tiler, splitter placement, drop routing) is NOT touched.
The caller measures plain numbers off the layer each step just created and hands them
here; these turn them into clean, flagged summary lines. No QGIS objects — fully
testable on their own.
"""

#: Spec: at most 16 splitters per PON (ticket #98).
MAX_SPLITTERS_PER_PON = 16
#: Spec: a drop cable is at most 75 m.
MAX_DROP_LEN_M = 75.0


def boundary_summary(vertex_counts, invalid=0, overlapping_pairs=0):
    """``vertex_counts``: list of vertex counts, one per tile. ``invalid``: number of
    null/invalid geometries. ``overlapping_pairs``: number of overlapping tile pairs.
    Returns summary lines (list[str])."""
    counts = list(vertex_counts or [])
    if not counts:
        return ["── PON boundaries ─────────────────────────────", "  ⚠ no boundaries were built"]
    avg = round(sum(counts) / len(counts), 1)
    lines = [
        "── PON boundaries built ───────────────────────",
        f"  Tiles        : {len(counts)}",
        f"  Avg vertices : {avg}  (min {min(counts)}, max {max(counts)})",
    ]
    flags = []
    if invalid:
        flags.append(f"{invalid} invalid / null geometry")
    if overlapping_pairs:
        flags.append(f"{overlapping_pairs} overlapping tile pair(s)")
    if flags:
        lines += [f"  ⚠ {f}" for f in flags]
    else:
        lines.append("  ✓ all tiles valid and non-overlapping")
    return lines


def splitter_summary(drop_counts_per_splitter, splitters_per_pon, ungrouped_skipped=0):
    """``drop_counts_per_splitter``: list of drops served by each splitter.
    ``splitters_per_pon``: dict ``pon -> splitter count``. ``ungrouped_skipped``: int.
    Returns summary lines (list[str])."""
    counts = list(drop_counts_per_splitter or [])
    per_pon = dict(splitters_per_pon or {})
    if not counts:
        return ["── Splitters ──────────────────────────────────", "  ⚠ no splitters were placed"]
    avg = round(sum(counts) / len(counts), 1)
    over = sorted(((p, c) for p, c in per_pon.items() if c > MAX_SPLITTERS_PER_PON),
                  key=lambda t: (-t[1], str(t[0])))
    lines = [
        "── Splitters placed ───────────────────────────",
        f"  Splitters      : {len(counts)}",
        f"  PONs covered   : {len(per_pon)}",
        f"  Avg drops / spl: {avg}",
    ]
    flags = []
    if over:
        top = ", ".join(f"PON {p}={c}" for p, c in over[:5])
        flags.append(f"{len(over)} PON(s) over {MAX_SPLITTERS_PER_PON} splitters: {top}")
    if ungrouped_skipped:
        flags.append(f"{ungrouped_skipped} ungrouped feature(s) skipped")
    if flags:
        lines += [f"  ⚠ {f}" for f in flags]
    else:
        lines.append(f"  ✓ every PON within the {MAX_SPLITTERS_PER_PON}-splitter limit")
    return lines


def drop_summary(lengths_m, no_splitter_skipped=0):
    """``lengths_m``: list of drop-cable lengths in metres. ``no_splitter_skipped``:
    demand points that had no splitter to connect to. Returns summary lines (list[str])."""
    lens = [float(x) for x in (lengths_m or [])]
    if not lens:
        return ["── Drops ──────────────────────────────────────", "  ⚠ no drops were created"]
    total = sum(lens)
    over = [x for x in lens if x > MAX_DROP_LEN_M]
    lines = [
        "── Drops created ──────────────────────────────",
        f"  Drops        : {len(lens)}",
        f"  Total length : {total:.0f} m",
        f"  Avg length   : {total / len(lens):.1f} m  (max {max(lens):.0f} m)",
    ]
    flags = []
    if over:
        flags.append(f"{len(over)} drop(s) over {MAX_DROP_LEN_M:.0f} m (longest {max(over):.0f} m)")
    if no_splitter_skipped:
        flags.append(f"{no_splitter_skipped} demand point(s) had no splitter match (skipped)")
    if flags:
        lines += [f"  ⚠ {f}" for f in flags]
    else:
        lines.append(f"  ✓ all drops within {MAX_DROP_LEN_M:.0f} m")
    return lines
