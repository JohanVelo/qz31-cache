"""Venv subprocess runner for the HLD PDF (reportlab isn't in plain QGIS).
Usage: python hld_report_runner.py <data.json> <out.pdf>
Runs OUTSIDE the QGIS process — cannot freeze the UI."""
import sys
import os
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import hld_report

if __name__ == '__main__':
    with open(sys.argv[1], encoding='utf-8') as _f:
        data = json.load(_f)
    out = hld_report.build_hld_pdf(data, sys.argv[2])
    print('HLD PDF written:', out)
