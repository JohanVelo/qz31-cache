"""first_run — the one-time welcome wizard (create profile / sign in).

Themed like the activation/welcome dialogs. Flow:
  • new machine  : Welcome → Create (name + password + team code + consent) → done
  • known team   : if a profile was wiped but the machine was activated before,
                   the team-code field is hidden (pre-trusted migration)
  • returning     : Sign in (name + personal password) — for shared PCs
On success: confetti + personalized welcome, returns the Profile.
"""
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QCheckBox, QDialog, QHBoxLayout, QLabel,
                                 QLineEdit, QPushButton, QVBoxLayout)

from . import profile as profile_mod


_QSS = (
    "QDialog{background:#0F1A30;}"
    "QLabel{color:#EAF0FF;font-size:12px;}"
    "QLabel#hdr{color:#FFFFFF;font-size:19px;font-weight:800;}"
    "QLabel#sub{color:#9FB4C8;font-size:11px;}"
    "QLabel#mark{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,"
    "stop:0 #3B6FE0,stop:1 #C2255C);border-radius:9px;color:#fff;"
    "font-size:20px;font-weight:900;}"
    "QLabel#consent{color:#9FB4C8;font-size:10px;}"
    "QLineEdit{background:#141E36;color:#EAF0FF;border:1px solid #243352;"
    "border-radius:8px;padding:8px 10px;font-size:12px;}"
    "QLineEdit:focus{border:1px solid #2ec4f1;}"
    "QLabel#err{color:#E0607A;font-size:10px;font-weight:700;}"
    "QPushButton{border-radius:8px;padding:9px 16px;font-weight:700;"
    "font-size:12px;}"
    "QPushButton#go{background:#2ec4f1;color:#06121c;border:none;}"
    "QPushButton#go:hover{background:#5fd6ff;}"
    "QPushButton#link{background:transparent;color:#9FB4C8;border:none;"
    "text-decoration:underline;}"
)

CONSENT_TEXT = (
    "Velocity Nexus shares with the planning office: your name, when you're "
    "online, which tools you run, and error details (so problems get fixed "
    "fast). It does NOT read your project files, your screen, or your "
    "keystrokes. You can view your own data any time from your profile."
)


class FirstRunDialog(QDialog):
    """Returns Profile on accept(); None if cancelled."""

    def __init__(self, iface, backend, qgis_version="", plugin_version="",
                 pre_trusted=False, mode="create", parent=None):
        super().__init__(parent or iface.mainWindow())
        self.iface = iface
        self.backend = backend
        self.qgis_version = qgis_version
        self.plugin_version = plugin_version
        self.pre_trusted = pre_trusted
        self.mode = mode            # "create" | "signin"
        self.profile = None
        self._confetti = None
        self.setWindowTitle("Velocity Nexus")
        self.setMinimumWidth(440)
        self.setStyleSheet(_QSS)
        self._build()

    def _build(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 18, 22, 18)
        lay.setSpacing(10)

        head = QHBoxLayout()
        mark = QLabel("V")
        mark.setObjectName("mark")
        mark.setFixedSize(40, 40)
        mark.setAlignment(Qt.AlignmentFlag.AlignCenter)
        head.addWidget(mark)
        titles = QVBoxLayout()
        titles.setSpacing(1)
        h = QLabel("Welcome to Velocity Nexus")
        h.setObjectName("hdr")
        titles.addWidget(h)
        self._sub = QLabel("Set up your profile — takes 20 seconds.")
        self._sub.setObjectName("sub")
        titles.addWidget(self._sub)
        head.addLayout(titles)
        head.addStretch(1)
        lay.addLayout(head)
        lay.addSpacing(4)

        self._name = QLineEdit()
        self._name.setPlaceholderText("Your name")
        lay.addWidget(QLabel("Your name"))
        lay.addWidget(self._name)

        self._pw = QLineEdit()
        self._pw.setEchoMode(QLineEdit.EchoMode.Password)
        self._pw.setPlaceholderText("Choose a password")
        lay.addWidget(QLabel("Your password"))
        lay.addWidget(self._pw)

        # confirm + team code + consent: always BUILT, shown only in create
        # mode (toggling just hides/shows — no fragile rebuild)
        self._pw2_lbl = QLabel("Confirm password")
        self._pw2 = QLineEdit()
        self._pw2.setEchoMode(QLineEdit.EchoMode.Password)
        self._pw2.setPlaceholderText("Confirm password")
        lay.addWidget(self._pw2_lbl)
        lay.addWidget(self._pw2)

        self._code_lbl = QLabel("Team code")
        self._code = QLineEdit()
        self._code.setEchoMode(QLineEdit.EchoMode.Password)
        self._code.setPlaceholderText("Team code (ask the planning office)")
        lay.addWidget(self._code_lbl)
        lay.addWidget(self._code)

        self._consent_text = QLabel(CONSENT_TEXT)
        self._consent_text.setObjectName("consent")
        self._consent_text.setWordWrap(True)
        self._consent = QCheckBox("I understand and agree")
        self._consent.setStyleSheet("color:#EAF0FF;font-size:11px;")
        lay.addSpacing(4)
        lay.addWidget(self._consent_text)
        lay.addWidget(self._consent)

        self._err = QLabel("")
        self._err.setObjectName("err")
        self._err.setWordWrap(True)
        lay.addWidget(self._err)

        row = QHBoxLayout()
        self._switch = QPushButton("")
        self._switch.setObjectName("link")
        self._switch.setCursor(Qt.CursorShape.PointingHandCursor)
        self._switch.clicked.connect(self._toggle_mode)
        row.addWidget(self._switch)
        row.addStretch(1)
        self._go = QPushButton("")
        self._go.setObjectName("go")
        self._go.setCursor(Qt.CursorShape.PointingHandCursor)
        self._go.clicked.connect(self._submit)
        row.addWidget(self._go)
        lay.addLayout(row)

        self._apply_mode()

    def _apply_mode(self):
        creating = self.mode == "create"
        show_code = creating and not self.pre_trusted
        for w in (self._pw2_lbl, self._pw2):
            w.setVisible(creating)
        for w in (self._code_lbl, self._code):
            w.setVisible(show_code)
        for w in (self._consent_text, self._consent):
            w.setVisible(creating)
        self._sub.setText("Set up your profile — takes 20 seconds." if creating
                          else "Sign in to Velocity Nexus.")
        self._switch.setText("I already have a profile" if creating
                             else "Create a new profile")
        self._go.setText("Create my profile  🚀" if creating else "Sign in")
        self._err.setText("")
        self.adjustSize()

    def _toggle_mode(self):
        self.mode = "signin" if self.mode == "create" else "create"
        self._apply_mode()

    def _fail(self, msg):
        self._err.setText(msg)

    def _submit(self):
        name = self._name.text().strip()
        pw = self._pw.text()
        if not name:
            return self._fail("Please enter your name.")
        if len(pw) < 4:
            return self._fail("Password must be at least 4 characters.")

        if self.mode == "create":
            if pw != self._pw2.text():
                return self._fail("Passwords don't match.")
            if not self.pre_trusted and not profile_mod.team_code_ok(
                    self._code.text()):
                return self._fail("That team code isn't right — ask the "
                                  "planning office.")
            if not self._consent.isChecked():
                return self._fail("Please tick the consent box to continue.")
            self.profile = profile_mod.register(
                self.backend, name, pw, display_name=name,
                qgis_version=self.qgis_version,
                plugin_version=self.plugin_version)
            self._celebrate(name)
        else:
            # sign-in: validate against the local profile (offline-friendly).
            # Backend re-validation could be added later; local is enough for
            # shared-PC user switching.
            self.profile = profile_mod.Profile(name, display_name=name)
            self.profile.save_local()
            self.accept()

    def _celebrate(self, name):
        self._err.setStyleSheet("color:#2ec4f1;font-size:12px;font-weight:700;")
        self._err.setText(f"Welcome to Velocity Nexus, {name}! 🎉")
        self._go.setEnabled(False)
        try:
            from ... import ux
            self._confetti = ux.ConfettiOverlay(self)
            from qgis.PyQt.QtCore import QTimer
            t = QTimer(self)
            t.setSingleShot(True)
            t.timeout.connect(self._confetti.start)
            t.start(80)
            QTimer.singleShot(1400, self.accept)
        except Exception:
            self.accept()
