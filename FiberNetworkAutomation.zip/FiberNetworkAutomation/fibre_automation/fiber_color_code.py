"""fiber_color_code — the TIA-598-C fibre colour code (pure data, zero deps).

The industry-standard 12-colour sequence used for buffer tubes AND the fibres
within each tube. Lets any tool (splice cards, BoQ, port-assignment sheets,
schematics) turn a fibre/port NUMBER into its tube + fibre colour so a technician
never hand-counts colours. Shippable (stdlib only).

  fiber_color(n)      → dict for the n-th fibre (1-based): tube/position/colours
  legend(count)       → per-fibre rows for a cable of `count` fibres
  tube_color(t)       → colour of the t-th tube (1-based)
"""

# TIA-598-C standard order (position 1..12) with display hex.
TIA598C = [
    ("Blue", "#1f4ed8"),
    ("Orange", "#f97316"),
    ("Green", "#16a34a"),
    ("Brown", "#92400e"),
    ("Slate", "#64748b"),
    ("White", "#e5e7eb"),
    ("Red", "#dc2626"),
    ("Black", "#111827"),
    ("Yellow", "#eab308"),
    ("Violet", "#7c3aed"),
    ("Rose", "#ec4899"),
    ("Aqua", "#06b6d4"),
]


def _entry(idx0):
    """idx0 = 0-based position within the 12-colour cycle."""
    name, hexv = TIA598C[idx0 % 12]
    return name, hexv


def tube_color(tube):
    """Colour (name, hex) of the tube-th buffer tube, 1-based."""
    return _entry(int(tube) - 1)


def fiber_color(n, fibers_per_tube=12):
    """For the n-th fibre in a cable (1-based), return its tube, position-in-tube,
    fibre colour and tube colour. Default 12 fibres/tube (standard loose-tube)."""
    n = int(n)
    if n < 1:
        raise ValueError("fibre number is 1-based")
    fpt = int(fibers_per_tube) or 12
    tube = (n - 1) // fpt + 1
    pos = (n - 1) % fpt + 1
    f_name, f_hex = _entry(pos - 1)
    t_name, t_hex = _entry(tube - 1)
    return {
        "fiber": n,
        "tube": tube,
        "position": pos,
        "fiber_color": f_name,
        "fiber_hex": f_hex,
        "tube_color": t_name,
        "tube_hex": t_hex,
        "label": f"T{tube} {t_name} / F{pos} {f_name}",
    }


def legend(count, fibers_per_tube=12):
    """List of per-fibre dicts for a cable of `count` fibres — drop straight into
    an openpyxl 'Port-Colour Legend' sheet or a reportlab table."""
    return [fiber_color(n, fibers_per_tube) for n in range(1, int(count) + 1)]
