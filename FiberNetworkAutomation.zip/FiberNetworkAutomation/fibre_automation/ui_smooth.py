"""ui_smooth — render-only smoothing for heavy layers (bundled; native QGIS + stdlib).

Makes pan/zoom smoother on big projects WITHOUT touching any data: applies QGIS's
own geometry-simplification at render time to heavy vector layers (>THRESH
features). Simplification is purely visual + reversible (the stored geometry is
untouched) and uses a sub-pixel tolerance, so the map looks identical but draws
2-5x faster when zoomed out. Toggleable via QSettings (default ON); fail-silent.

  from fibre_automation import ui_smooth
  ui_smooth.apply(project)        # optimize heavy layers' render path
  ui_smooth.set_enabled(False)    # operator opt-out (settings)
"""
_KEY = "VelocityFibre/renderSmoothing"
HEAVY_FEATURES = 500          # only optimize layers above this many features
THRESHOLD_PX = 1.0            # sub-pixel render tolerance (visually identical)


def enabled():
    try:
        from qgis.core import QgsSettings
        return QgsSettings().value(_KEY, True, type=bool)
    except Exception:
        return True


def set_enabled(on):
    try:
        from qgis.core import QgsSettings
        QgsSettings().setValue(_KEY, bool(on))
    except Exception:
        pass


def _simplify_method():
    from qgis.core import QgsVectorSimplifyMethod
    m = QgsVectorSimplifyMethod()

    def _enum(name, *fallbacks):
        # tolerate scoped vs unscoped enum names across QGIS versions
        for holder in (getattr(QgsVectorSimplifyMethod, "SimplifyHint", None),
                       getattr(QgsVectorSimplifyMethod, "SimplifyAlgorithm", None),
                       QgsVectorSimplifyMethod):
            if holder is not None and hasattr(holder, name):
                return getattr(holder, name)
        for fb in fallbacks:
            for holder in (QgsVectorSimplifyMethod,):
                if hasattr(holder, fb):
                    return getattr(holder, fb)
        return None
    try:
        hint = _enum("GeometrySimplification")
        if hint is not None:
            m.setSimplifyHints(hint)
        alg = _enum("Distance")
        if alg is not None:
            m.setSimplifyAlgorithm(alg)
    except Exception:
        pass
    try:
        m.setThreshold(THRESHOLD_PX)
        m.setForceLocalOptimization(True)
    except Exception:
        pass
    return m


def apply(project=None):
    """Apply render smoothing to heavy vector layers. Returns count optimized.
    Render-only — never edits geometry. No-op if disabled. Never raises."""
    if not enabled():
        return 0
    n = 0
    try:
        from qgis.core import QgsProject, QgsVectorLayer
        project = project or QgsProject.instance()
        method = _simplify_method()
        for lyr in project.mapLayers().values():
            try:
                if (isinstance(lyr, QgsVectorLayer) and lyr.isValid()
                        and lyr.geometryType() != 0       # skip points (nothing to simplify)
                        and lyr.featureCount() >= HEAVY_FEATURES):
                    lyr.setSimplifyMethod(method)
                    n += 1
            except Exception:
                continue
    except Exception:
        return n
    return n
