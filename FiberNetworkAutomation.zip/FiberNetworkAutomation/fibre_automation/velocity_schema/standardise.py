"""The whole button, in one place: snapshot -> preview -> apply -> verify.

The order is the safety property, not a convenience:

    1  find what cannot be backed up, and say so
    2  snapshot every source file, hashing each one
    3  RESTORE the snapshot and re-hash, proving the rollback works
    4  plan the rewrite and hand it back
    ------------------------------------------------ preview stops here
    5  REFUSE if anything cannot be backed up
    6  apply that same plan into a NEW GeoPackage
    7  verify counts, geometry and columns against the sources
    8  write the styles

Steps 1-4 are `preview()` and write nothing but the snapshot. `apply()` takes
the plan that preview produced and executes it, so what was shown is literally
what runs — there is no second code path that could disagree.

⛔ Step 3 is not optional and not a formality. A backup that has never been
restored is a folder.

⛔ Step 5, and WHY IT IS NOT STEP 1 (changed 2026-09-11, JJ). Lulekani has four
memory layers and a dead path; Ventersdorp has three. No file-based backup can
capture any of them, and the existing zip backup skips them and still reports
success, so a project that cannot be rolled back looks identical to one that
can. That has to block a WRITE. It must NOT block a preview: a preview writes
nothing to your data, and refusing to even show the plan because a scratch layer
exists withholds the information you need in order to fix the scratch layer.
So preview warns — loudly, in the report, with each layer named — and proceeds.
`apply()` is where it refuses.

No QGIS import. The caller supplies views, source paths and an opener, which is
what makes this testable and what keeps the QGIS algorithm a thin shell.
"""
from __future__ import annotations

import os

def _siblings():
    """mapper, symbology and validate, by whichever route this was loaded.

    Imported through a function rather than at module level because this
    package is loaded three ways - installed plugin, workspace copy, and by
    path in the headless test harness - and a relative import fails outright
    in the third, which would make the orchestration untestable.
    """
    try:
        from . import mapper, symbology
        from . import validate as _v
    except (ImportError, ValueError):
        import mapper, symbology            # noqa: F401
        import validate as _v
    return mapper, symbology, _v


mapper, symbology, _validate = _siblings()


def _snapshot_mod():
    try:
        from .. import project_snapshot
    except (ImportError, ValueError):
        try:
            from fibre_automation import project_snapshot
        except ImportError:
            import project_snapshot
    return project_snapshot


class Refused(Exception):
    """Raised when the run must not proceed. Carries why, for the UI."""


def preview(views, source_files, project_name, schema=None, town=None,
            snapshot_root=None, unsaveable=None, verify_restore=True,
            scratch=None):
    """Snapshot, prove the snapshot restores, and return the plan.

    `unsaveable` is the output of project_snapshot.unsaveable_layers() — passed
    in rather than computed, because computing it needs a live QgsProject.
    Passing an empty list when you have not checked is how this safety net gets
    quietly disarmed, so `None` means "not checked" and is refused.
    """
    ps = _snapshot_mod()
    schema = schema or _validate.load_schema()

    if unsaveable is None:
        raise Refused(
            "unsaveable_layers() was not run. Refusing to continue: the rollback "
            "cannot be trusted without knowing what it cannot capture.")
    snap = ps.snapshot(source_files, project_name,
                       root=snapshot_root or ps.DEFAULT_ROOT,
                       label="standardise")
    if not snap["ok"]:
        raise Refused("snapshot failed, so there is no rollback: %s"
                      % (snap.get("msg") or "unknown"))

    check = ps.verify(snap["dir"])
    if not check["ok"]:
        raise Refused("the snapshot does not verify: %s"
                      % (check.get("msg") or "unknown"))

    restored = None
    if verify_restore:
        dest = scratch or os.path.join(snap["dir"], "_restore_test")
        restored = ps.restore(snap["dir"], dest)
        if not restored["ok"]:
            raise Refused(
                "the snapshot does not RESTORE: %s. A backup that has never "
                "been restored is a folder, not a rollback."
                % (restored.get("msg") or "unknown"))

    plans = mapper.plan(views, schema, town=town)
    findings = _validate.check(
        views, schema, town=town,
        project_layer_names=[v.name for v in views])

    return {
        "unsaveable": list(unsaveable),
        "plans": plans,
        "lines": mapper.describe(plans),
        "findings": findings,
        "counts": _validate.summarise(findings),
        "snapshot": snap,
        "snapshot_verified": check,
        "snapshot_restored": restored,
        "schema": schema,
        "town": town,
        "renames": sum(1 for p in plans
                       if p["src"].strip() != p["dst"] and not p.get("blocked")),
        "field_renames": sum(len(p["fields"]) for p in plans),
        "blocked": [p for p in plans if p.get("blocked")],
    }


def apply(prev, open_source, dst_gpkg, style_dir=None, views=None,
          progress=None):
    """Execute the plan `preview()` produced. Never re-plans.

    Taking the plan as data rather than recomputing it is the whole reason the
    preview can be trusted: there is no second derivation that could drift from
    the one JJ approved.
    """
    if not prev or "plans" not in prev:
        raise Refused("apply() needs the object preview() returned.")
    if not prev.get("snapshot", {}).get("ok"):
        raise Refused("refusing to apply without a good snapshot.")

    # The refusal that used to sit in preview. Here it guards a WRITE, which is
    # the only place it was ever guarding anything: these layers have no
    # rollback, so a run that changes the project is a run that cannot be undone
    # for them.
    unsaveable = prev.get("unsaveable")
    if unsaveable is None:
        raise Refused("this preview predates the unsaveable-layers check and "
                      "cannot be applied. Re-run the preview.")
    if unsaveable:
        names = ", ".join("%s (%s)" % (u["name"], u["provider"])
                          for u in unsaveable[:6])
        raise Refused(
            "%d layer(s) cannot be backed up, so applying would leave them with "
            "no rollback: %s. Save them to a file (right-click the layer -> Make "
            "Permanent) or remove them, then preview again."
            % (len(unsaveable), names))

    plans = prev["plans"]
    report = mapper.apply(plans, open_source, dst_gpkg, progress=progress)
    verified = mapper.verify(plans, open_source, dst_gpkg)

    styles = []
    if style_dir:
        os.makedirs(style_dir, exist_ok=True)
        by_role = {s["role"]: s for s in prev["schema"].get("layers") or []}
        for v in (views or []):
            plan_for = next((p for p in plans if p["src"] == v.name), None)
            if not plan_for or plan_for.get("blocked"):
                continue
            spec = by_role.get(plan_for.get("role"))
            if not spec:
                continue
            st = symbology.style_for(spec, v, prev["schema"])
            if not st:
                continue
            # A categorised style with no catch-all hides every unlisted value.
            # It is a bug in this module if one ever reaches disk, so it is
            # checked here rather than trusted.
            if not symbology.has_catch_all(st["qml"]):
                raise Refused("refusing to write a categorised style with no "
                              "all-other-values catch-all for %r" % plan_for["dst"])
            path = os.path.join(style_dir, "%s.qml" % plan_for["dst"])
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(st["qml"])
            styles.append({"layer": plan_for["dst"], "path": path,
                           "attribute": st["attribute"], "kind": st["kind"]})

    ok = bool(report.get("ok")) and bool(verified.get("ok"))
    return {"ok": ok, "written": report, "verified": verified,
            "styles": styles, "path": dst_gpkg,
            "rollback": prev["snapshot"]["dir"],
            "msg": None if ok else
            "standardise FAILED — %s %s" % (report.get("msg") or "",
                                            verified.get("msg") or "")}


def format_preview(prev, width=78):
    """The preview as text, for a processing log or a dialog."""
    out = []
    s = prev["snapshot"]
    out.append("SNAPSHOT  %d files, %.1f MB, %.1fs"
               % (s["files"], s["bytes"] / 1e6, s["elapsed_s"]))
    out.append("          %s" % s["dir"])
    out.append("          verified: %d files re-hashed"
               % prev["snapshot_verified"]["checked"])
    if prev.get("snapshot_restored"):
        out.append("          restore proven: %d files written and re-hashed"
                   % prev["snapshot_restored"]["restored"])
    un = prev.get("unsaveable") or []
    if un:
        out.append("")
        out.append("!" * width)
        out.append("NO ROLLBACK for %d layer(s) — the snapshot above does NOT "
                   "cover them:" % len(un))
        for u in un:
            out.append("    %-30s [%s] %s" % (u["name"], u["provider"],
                                              u["reason"]))
        out.append("This preview is safe to read. APPLYING IS BLOCKED until "
                   "they are saved to a file or removed.")
        out.append("!" * width)
    out.append("")
    out.append("PLAN      %d layer rename(s), %d field rename(s)"
               % (prev["renames"], prev["field_renames"]))
    out.append("-" * width)
    out.extend(prev["lines"])
    if prev["blocked"]:
        out.append("-" * width)
        for p in prev["blocked"]:
            out.append("BLOCKED   %s — %s" % (p["src"], p["blocked"]))
    c = prev["counts"]
    out.append("-" * width)
    out.append("SCHEMA    %d error  %d warn  %d info"
               % (c[_validate.ERROR], c[_validate.WARN], c[_validate.INFO]))
    return out
