"""excel — write a BoQResult to a client-ready .xlsx (openpyxl, formulas live)."""
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

_HDR = Font(bold=True, color="FFFFFF")
_HDR_FILL = PatternFill("solid", fgColor="1F2937")
_TITLE = Font(bold=True, size=14, color="B91C1C")
_MONEY = '#,##0.00'
_THIN = Border(*[Side(style="thin", color="D1D5DB")] * 4)
_STATUS_FILL = {
    "OK": PatternFill("solid", fgColor="DCFCE7"),
    "WARN": PatternFill("solid", fgColor="FEF9C3"),
    "GATE": PatternFill("solid", fgColor="FFE4E6"),
    "BLOCK": PatternFill("solid", fgColor="FECACA"),
}


def _hdr(ws, row, cols):
    for i, c in enumerate(cols, 1):
        cell = ws.cell(row=row, column=i, value=c)
        cell.font = _HDR
        cell.fill = _HDR_FILL
        cell.alignment = Alignment(horizontal="center")


def write_boq(result, path):
    wb = Workbook()

    # ── Summary ──────────────────────────────────────────────────────────────
    ws = wb.active
    ws.title = "Summary"
    ws["A1"] = "VELOCITY NEXUS — BILL OF QUANTITIES"
    ws["A1"].font = _TITLE
    r = 3
    for k, v in (("Project", result.meta.get("project")),
                 ("Measured in CRS", result.meta.get("crs_measure")),
                 ("Rates source", result.meta.get("rates_supplier")),
                 ("Rates file", result.meta.get("rates_path")),
                 ("Audit verdict", result.verdict)):
        ws.cell(row=r, column=1, value=k).font = Font(bold=True)
        ws.cell(row=r, column=2, value=v)
        r += 1
    r += 1
    _hdr(ws, r, ["Section", "Lines", "Amount (R)"])
    sec_start = r + 1
    sections = {}
    for ln in result.lines:
        sections.setdefault(ln["section"], []).append(ln)
    r += 1
    for sec, lns in sections.items():
        priced = [l["amount"] for l in lns if l.get("amount") is not None]
        ws.cell(row=r, column=1, value=sec)
        ws.cell(row=r, column=2, value=len(lns))
        ws.cell(row=r, column=3, value=round(sum(priced), 2) if priced else "TBD").number_format = _MONEY
        r += 1
    ws.cell(row=r, column=1, value="GRAND TOTAL (priced lines)").font = Font(bold=True)
    ws.cell(row=r, column=3,
            value=f"=SUM(C{sec_start}:C{r - 1})").number_format = _MONEY   # was sec_start+1 → dropped the first section
    ws.cell(row=r, column=3).font = Font(bold=True)
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 14
    ws.column_dimensions["C"].width = 16

    # ── Detail (cables + equipment) ──────────────────────────────────────────
    wd = wb.create_sheet("Detail")
    cols = ["Section", "Item", "Group", "Count", "Measured (m)", "Installed (m)",
            "Ordered (m)", "Spools", "Qty", "Unit", "Rate (R)", "Amount (R)"]
    _hdr(wd, 1, cols)
    row = 2
    for ln in result.lines:
        vals = [ln["section"], ln["key"], ln.get("group"), ln.get("count"),
                ln.get("measured_m"), ln.get("installed_m"), ln.get("ordered_m"),
                ln.get("spools"), ln.get("qty"), ln.get("unit"),
                ln.get("rate") if ln.get("rate") is not None else "TBD"]
        for i, v in enumerate(vals, 1):
            wd.cell(row=row, column=i, value=v).border = _THIN
        # Amount as a live formula = Qty * Rate (guard TBD)
        qcol, rcol = "I", "K"
        amt = wd.cell(row=row, column=12)
        amt.value = f'=IF(ISNUMBER({rcol}{row}),{qcol}{row}*{rcol}{row},"TBD")'
        amt.number_format = _MONEY
        amt.border = _THIN
        row += 1
    for col, w in zip("ABCDEFGHIJKL",
                      [12, 18, 14, 8, 13, 13, 12, 8, 12, 7, 11, 14]):
        wd.column_dimensions[col].width = w

    # ── Audit / cross-checks ─────────────────────────────────────────────────
    wa = wb.create_sheet("Audit")
    _hdr(wa, 1, ["Check", "Status", "Detail"])
    row = 2
    for a in result.audit:
        wa.cell(row=row, column=1, value=a["check"])
        sc = wa.cell(row=row, column=2, value=a["status"])
        sc.fill = _STATUS_FILL.get(a["status"], PatternFill())
        wa.cell(row=row, column=3, value=a["detail"])
        row += 1
    if result.blocked:
        row += 1
        wa.cell(row=row, column=1, value="BLOCKED GEOMETRIES").font = Font(bold=True)
        row += 1
        _hdr(wa, row, ["Layer", "FID", "Reason"])
        row += 1
        for b in result.blocked[:200]:
            wa.cell(row=row, column=1, value=b["layer"])
            wa.cell(row=row, column=2, value=b["fid"])
            wa.cell(row=row, column=3, value=b["reason"])
            row += 1
    wa.column_dimensions["A"].width = 18
    wa.column_dimensions["B"].width = 10
    wa.column_dimensions["C"].width = 80

    # ── Assumptions & sign-off ───────────────────────────────────────────────
    wx = wb.create_sheet("Assumptions")
    notes = [
        "Quantities are a quantity-surveying AID derived from the HLD layers; rates "
        "are subject to current supplier quotes.",
        "Cable lengths are 2D map-derived, measured in projected metres "
        f"({result.meta.get('crs_measure')}) — NOT EPSG:4326 degrees.",
        "Slack and sag percentages are applied per cable type (see Detail: Measured "
        "→ Installed → Ordered).",
        "Spools = CEILING(Ordered / spool size) — material is never rounded down.",
        "A missing rate is shown as 'TBD', never a silent zero.",
        "On steep terrain or long aerial spans, add contingency.",
    ]
    wx.cell(row=1, column=1, value="ASSUMPTIONS").font = Font(bold=True, size=12)
    for i, n in enumerate(notes, 2):
        wx.cell(row=i, column=1, value=f"• {n}")
    base = len(notes) + 4
    for i, lab in enumerate(("Prepared by:  ______________________   Date: __________",
                             "Reviewed (QS): ______________________   Date: __________")):
        wx.cell(row=base + i, column=1, value=lab)
    wx.column_dimensions["A"].width = 110

    # Atomic write so a mid-save failure can't truncate an existing BoQ; friendly
    # error if the target .xlsx is still open in Excel (Windows file lock).
    import os
    import tempfile
    _dir = os.path.dirname(path) or "."
    try:
        fd, _tmp = tempfile.mkstemp(suffix=".xlsx", dir=_dir)
        os.close(fd)
        wb.save(_tmp)
        os.replace(_tmp, path)
    except PermissionError:
        try:
            os.remove(_tmp)
        except Exception:
            pass
        raise RuntimeError(
            f"Cannot write the BoQ — close '{os.path.basename(path)}' in Excel and run it again.")
    return path
