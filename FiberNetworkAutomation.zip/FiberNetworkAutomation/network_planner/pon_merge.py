"""Merge PONs the planner picked — attributes, boundaries, shape, numbering.

# claude:intent MUTATE — user asked, verbatim: "We just need a setting or a tool
# in the network planner that can: merge the ponds / renumber all of the
# attributes in the ponds / merge their boundaries / change their boundaries
# into more of a rectangular shape ... You don't need to worry about the
# capping, because people will automatically calculate the amount of units they
# should be inside of a pond and whether the pond should merge or not." and
# "you need to be able to select which ponds you want to merge, and then that
# updates everything else and creates everything into how I want the ponds:
# the geometry boundaries of the ponds, all of that."
# Classification: MUTATE — an explicit instruction to build a tool that writes.
# Plan: compute a full PLAN first (pure data, zero writes) so the preview and
# the write cannot disagree; the operator confirms; only then apply — reassign
# PON attributes, fuse the absorbed boundary polygons into the target and delete
# them, square the result, compact the remaining PON numbers, and rewrite the
# _SP<n> references buried in joint labels.
#
# claude:approved-destructive — apply_plan() deletes the absorbed PONs' boundary
# polygons, which is the "merge their boundaries" the user asked for: leaving
# them behind would keep a stale outline for a PON that no longer exists. This
# is SAFE BY CONSTRUCTION rather than by convention:
#   * apply_plan() REFUSES to run without backup_path pointing at a file that
#     actually exists on disk — it is not a documented convention the caller can
#     forget, it is an argument the function will not proceed without.
#   * only the fids computed in the plan are touched, and those come solely from
#     features whose PON is in the operator's own chosen source list.
#   * nothing is deleted from any layer other than the boundary layer.

The operator chooses what merges. There is deliberately NO capacity rule here:
"people will automatically calculate the amount of units they should be inside
of a pond and whether the pond should merge or not" (JJ 2026-07-23).

What a merge does, in order:

1. **Reassign** every feature of the absorbed PONs to the target — in EVERY
   layer that carries a PON column, not just the ones we happen to know about.
   Attributes only; no geometry is moved, nothing is created.
2. **Fuse the boundaries** into one polygon and delete the absorbed ones.
3. **Square it off** with ``native:orthogonalize``, but only if the result stays
   valid and keeps its area. If it cannot, the un-squared merged polygon is
   kept — a correct blob beats a pretty sliver.
4. **Renumber** the remaining PONs to 1..N, closing the gap the merge left,
   including ``_SP<n>`` references buried inside joint labels.

Everything is computed as a PLAN first (:func:`plan`), which is what the preview
shows, and only then applied (:func:`apply_plan`).

Safety, learned the hard way on this codebase:

* the renumber refuses to write unless every match is accounted for
* ``_SP<n>`` is matched END-ANCHORED (``SP10`` prefixes ``SP100``; a ``\\b`` next
  to ``_`` once silently skipped 46 of 534 joints with every gate passing)
* squaring is verified before it is kept, never assumed
"""

import os
import re

from . import field_names as vf_fields
from .pon_stats import _as_pon, collect, find_layers

#: PON references hidden inside a text label, e.g. ``MMB_DJ262_SP10``.
#: END-ANCHORED on purpose — see the module docstring.
#:
#: Surrounding whitespace is CAPTURED, not stripped. Stripping it first meant a
#: padded value (shapefile text columns very often are) came back trimmed:
#: "MMB_DJ262_SP10 " -> "MMB_DJ262_SP7", quietly editing the label beyond the
#: number we were asked to change. Found by a property test, not by reading it.
SP_SUFFIX_RE = re.compile(r"^(?P<lead>\s*)(?P<head>.*_SP)(?P<num>\d+)(?P<tail>\s*)$")

#: Text columns that may carry an ``_SP<n>`` PON reference.
_LABEL_FIELDS = ("name", "label", "label_", "labelt")

#: The gap the reference design leaves between neighbouring PONs. MEASURED off
#: the Malmesbury V4 `Pons` layer, not guessed: 4.00 m on 148 of 151 adjacent
#: pairs, zero touching, zero overlap. The recipe that produces it is a gap-free
#: tiling shrunk by HALF the gap on every side (2 m + 2 m = a 4 m corridor).
DEFAULT_GAP_M = 4.0

#: Widest seam (metres) the merge will bridge into one continuous boundary. The
#: normal inter-PON gap is ~4 m; hand-edited projects can be wider. Beyond this the
#: two pieces are not really adjacent, so the merge keeps them as separate islands
#: (and warns) rather than drawing a long bridge across the map.
MAX_BRIDGE_M = 25.0

#: Douglas-Peucker tolerance used to pull the buffer-union "blobs" back to
#: straight runs before the corners are squared. ~8 m keeps the shape following
#: the blocks while dropping the dozens of vertices a buffer arc leaves behind.
DEFAULT_SIMPLIFY_M = 8.0



def sp_number(text):
    """The ``<n>`` from a trailing ``_SP<n>``, or None."""
    if text is None:
        return None
    m = SP_SUFFIX_RE.match(str(text))
    return int(m.group("num")) if m else None


def rewrite_sp(text, mapping):
    """Rewrite a trailing ``_SP<n>`` through ``mapping``. None if unchanged.

    Returning None rather than the original is what lets the caller COUNT real
    rewrites and compare that against the number of matches — the check that
    would have caught the 46-of-534 silent skip.
    """
    if text is None:
        return None
    m = SP_SUFFIX_RE.match(str(text))
    if not m:
        return None
    old = int(m.group("num"))
    if old not in mapping or mapping[old] == old:
        return None
    # lead/tail are put back verbatim: only the NUMBER may change.
    return (f"{m.group('lead')}{m.group('head')}"
            f"{mapping[old]}{m.group('tail')}")


class MergePlan(object):
    """Exactly what a merge will do. Pure data — the preview reads this."""

    def __init__(self, target, sources, project=None, scope=None):
        self.target = target
        self.sources = list(sources)
        # The project these layers actually belong to. Held on the plan because
        # apply() used to reach for QgsProject.instance() instead — which is the
        # singleton, NOT necessarily the project being worked on. Inside QGIS the
        # two happen to coincide, so it looked fine; the stress harness (which
        # builds its own QgsProject over copies) exposed it as 15 failures where
        # the name resync silently did nothing.
        self.project = project
        # The layers this merge is ALLOWED to touch, or None for "every layer in
        # the project carrying a PON column" (the original behaviour).
        #
        # None was the only behaviour until 2026-07-27, and on a project holding
        # one network it is correct. Luke's Phalaborwa project holds THREE —
        # Benfarm, Lulekani, Makgale — each numbering its PONs 1..N in the same
        # column. Unscoped, merging Benfarm's PON 68 would reassign, rename and
        # renumber features in the other two towns that merely happen to share a
        # number. Their extents overlap (measured: they are neighbouring
        # suburbs), so there is no spatial shortcut either — the only honest
        # answer is that the operator says which layers are in play.
        self.scope = list(scope) if scope else None
        self.reassign = []          # [(layer, {fid: {idx: value}})]
        self.delete = []            # [(layer, [fid, ...])] absorbed boundaries
        self.boundary = None        # (layer, fid, QgsGeometry) fused target
        # The layers themselves, kept separately from `boundary` above: that
        # tuple only exists when a fuse actually happened, but the retile needs
        # to know the boundary layer even when it did not.
        self.boundary_layer = None
        self.demand_layer = None
        self.splitter_layer = None
        self.count_stats = {}
        self.retile = {}            # {fid: QgsGeometry} straight-edged tiles
        self.retile_stats = {}
        self.renumber = {}          # {old_pon: new_pon}
        self.label_rewrites = []    # [(layer, {fid: {idx: value}}, matched)]
        self.moved = {}             # {layer name: n features}
        self.units_before = {}
        self.units_after = 0
        self.warnings = []
        self.squared = False

    @property
    def total_moved(self):
        return sum(self.moved.values())

    def describe(self):
        lines = [f"Merge {', '.join('PON ' + str(s) for s in self.sources)} "
                 f"into PON {self.target}",
                 f"  {self.units_after} units after the merge"]
        for name, n in sorted(self.moved.items()):
            lines.append(f"  {n} feature(s) reassigned in {name}")
        n_del = sum(len(f) for _l, f in self.delete)
        if n_del:
            lines.append(f"  {n_del} boundary polygon(s) absorbed into PON {self.target}")
        if self.renumber:
            lines.append(f"  {len(self.renumber)} PON(s) renumbered to close the gap")
        n_lbl = sum(len(c) for _l, c, _m in self.label_rewrites)
        if n_lbl:
            lines.append(f"  {n_lbl} joint label(s) updated (_SP references)")
        for w in self.warnings:
            lines.append(f"  ! {w}")
        return "\n".join(lines)


def in_scope(layer, scope):
    """Is this layer one the merge is allowed to touch?

    ``scope=None`` means "no restriction" — the behaviour every caller had
    before scoping existed. Compared by layer ID rather than object identity: a
    plan can outlive a redraw that hands back a different Python wrapper for the
    same underlying layer.
    """
    if scope is None:
        return True
    if layer is None:
        return False
    try:
        lid = layer.id()
    except Exception:
        return False
    for s in scope:
        if s is layer:
            return True
        try:
            if s is not None and s.id() == lid:
                return True
        except Exception:
            continue
    return False


def _pon_layers(project, scope=None):
    """Every valid vector layer carrying a PON column, within ``scope``."""
    out = []
    try:
        layers = list(project.mapLayers().values())
    except Exception:
        return out
    for lyr in layers:
        try:
            if lyr is None or not lyr.isValid() or not hasattr(lyr, "fields"):
                continue
        except Exception:
            continue
        if not in_scope(lyr, scope):
            continue
        name = vf_fields.resolve(lyr, vf_fields.PON_NUM)
        if name:
            out.append((lyr, name))
    return out


def _label_field(layer):
    """The text column that may hold ``_SP<n>``, or None."""
    try:
        flds = {f.name().lower(): f.name() for f in layer.fields()}
    except Exception:
        return None
    for cand in _LABEL_FIELDS:
        if cand in flds:
            return flds[cand]
    return None


#: What a PON is CALLED in the data. "Zone 7" was the old wording and it is the
#: thing JJ asked to be rid of — "zones are actually PONs ... it confuses a lot
#: of people". Any feature whose PON number changes gets its name rewritten to
#: match, so the label and the number can never drift apart again.
PON_NAME_TEMPLATE = "PON {n}"

#: A stored PON name we recognise and may rewrite: an optional word, then the
#: number. Anchored so a hand-written name like "Ben Farm north block" is left
#: completely alone rather than being stamped over.
_PON_NAME_RE = re.compile(r"^\s*(?:pon|zone)\s*[-_ ]?\s*(\d+)\s*$", re.IGNORECASE)


def pon_name_for(n):
    """The name a PON should carry."""
    return PON_NAME_TEMPLATE.format(n=n)


def name_needs_update(current, pon):
    """Should this stored name be rewritten for PON ``pon``?

    True only when the name is one of ours ("Zone 7" / "PON 7") AND it does not
    already say the right thing. A name we do not recognise is somebody's own
    wording and is never touched.
    """
    want = pon_name_for(pon)
    if current is None or str(current).strip() == "":
        return True, want
    cur = str(current)
    if cur == want:
        return False, cur
    if _PON_NAME_RE.match(cur):
        return True, want
    return False, cur                      # hand-written — leave it alone


#: A TEXT column with one of these names is treated as the PON label when the
#: layer has no proper ``pon_name``/``zone_name``. Luke's HeroTel layers spell it
#: plain "PON" and store "PON 1", "PON 2" — so after a renumber the polygon
#: labelled "PON 69" was left sitting on PON 68.
#:
#: Deliberately NOT added to ``field_names.ALIASES``: "PON" is a generic heading
#: that means the NUMBER on plenty of layers, and a global alias would make the
#: resolver hand it back as a name everywhere in the plugin. It is matched here,
#: for this one job, and only when the column really is text (see below).
_NAME_FALLBACK_FIELDS = ("pon",)


def _is_text_field(layer, name):
    """True when ``name`` is a string column on ``layer``.

    The type is PROBED, never pattern-matched off an enum int — Qt6 makes those
    class-dependent. Without this guard a layer whose "PON" column holds the
    integer PON number would have ``"PON 7"`` written into an integer field.
    """
    try:
        fld = layer.fields().field(layer.fields().indexOf(name))
        if fld.isNumeric():
            return False
        return str(fld.typeName()).lower() in {"string", "text", "qstring",
                                               "varchar", "character"}
    except Exception:
        return False


def _name_fallback(layer, pon_field):
    """A text column holding the PON label, or None."""
    try:
        have = {f.name().lower(): f.name() for f in layer.fields()}
    except Exception:
        return None
    for cand in _NAME_FALLBACK_FIELDS:
        hit = have.get(cand)
        if not hit or (pon_field and hit == pon_field):
            continue
        if _is_text_field(layer, hit):
            return hit
    return None


def plan_name_resync(project, scope=None):
    """Bring every PON name back in line with its PON number.

    Runs after the numbers have moved. It is written as a full resync rather
    than "update the ones we changed" on purpose: that way it also REPAIRS names
    that drifted earlier, instead of only avoiding new drift.

    ``scope`` bounds "full" to the layers this merge owns. Without it, merging in
    one town rewrites the PON names of every other network in the project — the
    repair-drift behaviour turns into cross-area vandalism.

    Returns [(layer, {fid: {idx: value}})].
    """
    out = []
    try:
        layers = list(project.mapLayers().values())
    except Exception:
        return out
    for lyr in layers:
        try:
            if lyr is None or not lyr.isValid() or not hasattr(lyr, "fields"):
                continue
        except Exception:
            continue
        if not in_scope(lyr, scope):
            continue
        pon_f = vf_fields.resolve(lyr, vf_fields.PON_NUM)
        name_f = (vf_fields.resolve(lyr, vf_fields.PON_NAME)
                  or _name_fallback(lyr, pon_f))
        if not pon_f or not name_f:
            continue
        idx = lyr.fields().indexOf(name_f)
        if idx < 0:
            continue
        changes = {}
        for feat in lyr.getFeatures():
            try:
                pon = _as_pon(feat[pon_f])
                if pon is None:
                    continue
                need, value = name_needs_update(feat[name_f], pon)
            except Exception:
                continue
            if need:
                changes[feat.id()] = {idx: value}
        if changes:
            out.append((lyr, changes))
    return out


#: Fraction of demand points that must already sit inside the boundary layer
#: before a retile is allowed. Measured separation on Luke's three-network
#: project: correct pairings 99.8-99.9%, wrong pairings 0.0%. Nothing lands in
#: between, so this sits in the middle of an empty gap rather than on a cliff.
RETILE_MIN_CONTAINMENT = 0.5

#: How many demand points to test for containment. The check is a sanity gate,
#: not a census — a few thousand points separate the cases just as decisively as
#: all of them, and keeps the dialog responsive on a 15,000-home project.
CONTAINMENT_SAMPLE = 2000


def _containment_sample(boundary_layer, demand_layer, cap=CONTAINMENT_SAMPLE):
    """(inside, sampled) — how many sampled demand points sit in a boundary."""
    try:
        from qgis.core import QgsSpatialIndex
    except Exception:
        return 0, 0
    try:
        polys, idx = {}, QgsSpatialIndex()
        for f in boundary_layer.getFeatures():
            g = f.geometry()
            if g and not g.isEmpty():
                polys[f.id()] = g
                idx.addFeature(f)
        if not polys:
            return 0, 0
        inside = sampled = 0
        for f in demand_layer.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            sampled += 1
            if sampled > cap:
                sampled -= 1
                break
            for fid in idx.intersects(g.boundingBox()):
                pg = polys.get(fid)
                if pg is not None and pg.contains(g):
                    inside += 1
                    break
        return inside, sampled
    except Exception:
        return 0, 0


def plan_retile(boundary_layer, demand_layer):
    """Straight-edged tile for every PON, rebuilt from the demand points.

    Returns ``({fid: QgsGeometry}, stats)`` and writes NOTHING, so the caller can
    show it before committing.

    No renumber map is needed: this runs AFTER the renumber, so both the boundary
    rows and the demand points already carry their final PON numbers and the two
    are matched on that number directly.

    Two refusals, both deliberate:

    * **A PON with no demand points is left exactly as it is.** There is nothing
      to build a tile from, and blanking the polygon would silently delete a
      boundary the operator can still see on the map. Counted in
      ``stats['untiled']`` so it is reported rather than hidden.
    * **Mismatched CRS aborts the whole retile.** Tiles come back in the demand
      layer's coordinates; writing them onto a boundary layer in a different CRS
      would drop every polygon somewhere else on Earth.
    """
    from . import pon_tiles
    stats = {"tiled": 0, "untiled": 0, "untiled_pons": [], "homes_outside": 0,
             "untiled_clipped": 0, "untiled_kept_whole": 0, "reason": ""}
    if boundary_layer is None or demand_layer is None:
        stats["reason"] = "no boundary or demand layer"
        return {}, stats
    try:
        if boundary_layer.crs().authid() != demand_layer.crs().authid():
            stats["reason"] = (f"CRS mismatch: {boundary_layer.crs().authid()} "
                               f"vs {demand_layer.crs().authid()}")
            return {}, stats
    except Exception:
        stats["reason"] = "could not compare the layer CRSs"
        return {}, stats

    b_field = vf_fields.resolve(boundary_layer, vf_fields.PON_NUM)
    d_field = vf_fields.resolve(demand_layer, vf_fields.PON_NUM)
    if not b_field or not d_field:
        stats["reason"] = "no PON column on the boundary or demand layer"
        return {}, stats

    # DO THE POINTS ACTUALLY LIVE HERE? Matching CRS is not enough — the three
    # networks in Luke's project are all EPSG:4326 neighbours, so picking another
    # town's demand layer passed every other check and still rebuilt 49 of
    # Benfarm's 71 boundaries out of Lulekani's points.
    #
    # The separation is absolute, not a judgement call. Measured over all nine
    # boundary/demand pairings in that project: a correct pairing puts 99.8-99.9%
    # of the demand points inside the existing boundaries, a wrong one puts
    # 0.0%. The gate below therefore has ~50 points of margin on both sides.
    inside, sampled = _containment_sample(boundary_layer, demand_layer)
    if sampled:
        frac = inside / float(sampled)
        stats["containment"] = frac
        if frac < RETILE_MIN_CONTAINMENT:
            stats["reason"] = (
                f"only {frac:.1%} of the demand points fall inside "
                f"{boundary_layer.name().strip()} — these two layers describe "
                f"different areas, so nothing was retiled")
            return {}, stats

    by_pon = {}
    try:
        for f in demand_layer.getFeatures():
            pon = _as_pon(f[d_field])
            if pon is None:
                continue
            by_pon.setdefault(str(pon), []).append(f)
    except Exception as exc:
        stats["reason"] = f"could not read the demand layer: {exc}"
        return {}, stats
    if not by_pon:
        stats["reason"] = "the demand layer carries no PON numbers"
        return {}, stats

    tiles = pon_tiles.voronoi_zone_polygons(demand_layer, by_pon)
    if not tiles:
        # pon_tiles returns {} rather than raising when numpy/scipy/shapely are
        # missing or the cloud is degenerate. Say so — a silent no-op here would
        # look identical to "the boundaries were already neat".
        stats["reason"] = ("tiling unavailable (numpy/scipy/shapely missing, or "
                           "too few demand points)")
        return {}, stats

    out = {}
    try:
        feats = list(boundary_layer.getFeatures())
    except Exception as exc:
        stats["reason"] = f"could not read the boundary layer: {exc}"
        return {}, stats
    leftovers = []
    for f in feats:
        pon = _as_pon(f[b_field])
        if pon is None:
            continue
        g = tiles.get(str(pon))
        if g is None or g.isEmpty():
            stats["untiled"] += 1
            stats["untiled_pons"].append(pon)
            leftovers.append((f.id(), f.geometry()))
            continue
        out[f.id()] = g
        stats["tiled"] += 1

    # A PON with no demand points keeps its OLD boundary — but that old blob was
    # drawn around homes that have since moved, so it sits on top of the fresh
    # tiles. Measured on Benfarm: the 68 tiles were clean (0 touches, 0 overlaps,
    # 4.02 m minimum gap) and these two leftovers alone produced 3 overlaps and
    # dragged the minimum gap to 3.74 m — breaking HeroTel's "boundaries must not
    # touch" rule.
    #
    # So the leftover is CLIPPED to whatever ground the new tiles do not claim.
    # It is never blanked: if the clip would erase the polygon entirely, the
    # original is kept and reported, because silently deleting a boundary the
    # operator can still see on the map is worse than a reported overlap.
    if leftovers and out:
        try:
            from qgis.core import QgsGeometry
            claimed = QgsGeometry.unaryUnion(list(out.values()))
        except Exception:
            claimed = None
        if claimed is not None and not claimed.isEmpty():
            for fid, geom in leftovers:
                if geom is None or geom.isEmpty():
                    continue
                try:
                    clipped = geom.difference(claimed)
                except Exception:
                    continue
                if (clipped is None or clipped.isEmpty()
                        or not clipped.isGeosValid()):
                    stats["untiled_kept_whole"] += 1
                    continue
                out[fid] = clipped
                stats["untiled_clipped"] += 1

    # Report how many homes end up outside their own tile. Points sitting exactly
    # on a shared edge are not "contained" — measured 10 of 6,034 on Benfarm,
    # matching the 0.12% seen on Malmesbury. Reported, never rounded to zero.
    try:
        for key, feats_in in by_pon.items():
            g = tiles.get(key)
            if g is None:
                continue
            for f in feats_in:
                fg = f.geometry()
                if fg and not fg.isEmpty() and not g.contains(fg):
                    stats["homes_outside"] += 1
    except Exception:
        pass
    return out, stats


def plan_count_refresh(boundary_layer, demand_layer, splitter_layer=None):
    """Recompute the stored unit / splitter counts from the live features.

    Returns ``({fid: {idx: value}}, stats)`` and writes nothing.

    This is the step that never existed. ``apply_plan`` reassigned features,
    deleted the absorbed boundaries, renumbered and renamed — and never once
    touched ``unit_count``. So the preview promised "PON 67 = 200 units" and
    nothing anywhere stored 200. Caught in the wild on Luke's project: a merge of
    PON 70 + 71 into 67 moved exactly 101 demand points and left ``Demands``
    reading 57, with the emptied PONs still claiming 42 and 59 homes they no
    longer had.

    Two things it will NOT do:

    * **No splitter layer, no splitter count.** Benfarm's splitter layer carries
      no PON column at all, so there is no way to attribute a splitter to a PON.
      The stored value is left exactly as it is rather than being overwritten
      with a confident zero.
    * **It never invents a column.** A layer with no count field is skipped.
    """
    stats = {"units_written": 0, "splitters_written": 0, "unchanged": 0,
             "splitter_source": None}
    if boundary_layer is None:
        return {}, stats
    pon_f = vf_fields.resolve(boundary_layer, vf_fields.PON_NUM)
    if not pon_f:
        return {}, stats
    uc_f = vf_fields.resolve(boundary_layer, vf_fields.UNIT_COUNT)
    sc_f = vf_fields.resolve(boundary_layer, vf_fields.SPLITTER_COUNT)

    units = _tally_pon(demand_layer)
    splitters = None
    if splitter_layer is not None and vf_fields.has(splitter_layer,
                                                    vf_fields.PON_NUM):
        splitters = _tally_pon(splitter_layer)
        stats["splitter_source"] = splitter_layer.name()

    flds = boundary_layer.fields()
    uc_i = flds.indexOf(uc_f) if uc_f else -1
    sc_i = flds.indexOf(sc_f) if sc_f else -1
    if uc_i < 0 and sc_i < 0:
        return {}, stats
    uc_text = uc_i >= 0 and _is_text_field(boundary_layer, uc_f)
    sc_text = sc_i >= 0 and _is_text_field(boundary_layer, sc_f)

    changes = {}
    try:
        feats = list(boundary_layer.getFeatures())
    except Exception:
        return {}, stats
    for f in feats:
        pon = _as_pon(f[pon_f])
        if pon is None:
            continue
        row = {}
        if uc_i >= 0 and units is not None:
            want = int(units.get(pon, 0))
            if _count_differs(f[uc_f], want):
                row[uc_i] = str(want) if uc_text else want
                stats["units_written"] += 1
        if sc_i >= 0 and splitters is not None:
            want = int(splitters.get(pon, 0))
            if _count_differs(f[sc_f], want):
                row[sc_i] = str(want) if sc_text else want
                stats["splitters_written"] += 1
        if row:
            changes[f.id()] = row
        else:
            stats["unchanged"] += 1
    return changes, stats


def _tally_pon(layer):
    """{pon: feature count} for a layer, or None when it cannot be counted."""
    if layer is None:
        return None
    field = vf_fields.resolve(layer, vf_fields.PON_NUM)
    if not field:
        return None
    out = {}
    try:
        for f in layer.getFeatures():
            pon = _as_pon(f[field])
            if pon is None:
                continue
            out[pon] = out.get(pon, 0) + 1
    except Exception:
        return None
    return out


def _count_differs(stored, want):
    """Is the stored count actually different from the counted one?

    NULL counts as different (it needs writing). Compared numerically so a
    shapefile handing back 98.0 or "98" does not trigger a pointless rewrite of
    every row on every merge.
    """
    if stored is None:
        return True
    try:
        return int(float(str(stored).strip())) != int(want)
    except (TypeError, ValueError):
        return True


def plan_boundary_polish(layer, gap_m=DEFAULT_GAP_M,
                         simplify_m=DEFAULT_SIMPLIFY_M):
    """Straighten the whole tiling, then pull every tile in so none touch.

    Returns ({fid: geometry}, stats). Measured on the live Matiko boundaries:
    123 touching pairs -> 0, median neighbour gap 3.94 m against the 4.00 m the
    reference design uses, 0.12% of homes ending up outside their own PON.

    The order matters. Simplification is done across the COVERAGE so shared
    edges stay identical (doing it per-polygon took overlaps from 3 to 46), and
    only then is each tile pulled in by half the gap.
    """
    stats = {"simplified": 0, "shrunk": 0, "skipped": 0}
    if layer is None:
        return {}, stats
    try:
        feats = list(layer.getFeatures())
    except Exception:
        return {}, stats
    orig = {f.id(): f.geometry() for f in feats
            if f.geometry() and not f.geometry().isEmpty()}
    if not orig:
        return {}, stats

    simplified = straighten_coverage(orig, layer, simplify_m=simplify_m)
    out = {}
    for fid, g in simplified.items():
        if g is not orig.get(fid):
            stats["simplified"] += 1
        pulled, ok = shrink(g, layer, gap_m=gap_m)
        if ok:
            stats["shrunk"] += 1
        else:
            stats["skipped"] += 1
        if not pulled.equals(orig[fid]):
            out[fid] = pulled
    return out, stats


def resync_renderer_categories(project, scope=None):
    """Follow a PON rename through the layer STYLING as well as the data.

    A categorized renderer stores the literal value it matches on. The boundary
    layer is categorized on the PON NAME, so renaming "Zone 7" -> "PON 7" in the
    data left all 56 categories still looking for "Zone 7": 0 of 52 features
    matched, everything dropped to the transparent 'all other values' symbol,
    and the map lost every fill colour.

    So the categories are remapped too — value and label only. The SYMBOL object
    is left untouched, so each PON keeps the exact colour it already had rather
    than getting a freshly generated palette.

    Returns the number of categories updated.
    """
    try:
        from qgis.core import QgsCategorizedSymbolRenderer, QgsVectorLayer
    except Exception:
        return 0
    updated = 0
    try:
        layers = list(project.mapLayers().values())
    except Exception:
        return 0
    for lyr in layers:
        try:
            if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
                continue
            if not in_scope(lyr, scope):
                continue
            r = lyr.renderer()
            if not isinstance(r, QgsCategorizedSymbolRenderer):
                continue
            attr = r.classAttribute()
            name_f = vf_fields.resolve(lyr, vf_fields.PON_NAME)
            # Only touch a renderer keyed on the PON NAME. One keyed on the PON
            # NUMBER needs nothing — a number does not change spelling.
            if not name_f or str(attr).lower() != str(name_f).lower():
                continue
            for i, cat in enumerate(list(r.categories())):
                val = cat.value()
                if val is None or str(val).strip() == "":
                    continue                       # the catch-all — leave it
                m = _PON_NAME_RE.match(str(val))
                if not m:
                    continue
                want = pon_name_for(int(m.group(1)))
                if str(val) == want:
                    continue
                r.updateCategoryValue(i, want)
                if str(cat.label()) == str(val):
                    r.updateCategoryLabel(i, want)
                updated += 1
            if updated:
                lyr.triggerRepaint()
        except Exception:
            continue
    return updated


def backup_is_usable(path):
    """(ok, why) — is there a REAL, finished backup at ``path``?

    The dock's snapshot writer produces a FOLDER (``_renumber_backup/<ts>/``)
    holding one ``.gpkg`` per layer plus ``manifest.json``, not a single file.
    An earlier ``os.path.isfile`` check therefore rejected every perfectly good
    backup and blocked the merge outright.

    ``manifest.json`` is written LAST, only after every layer snapshot has
    succeeded, so its presence is proof the backup actually completed — a much
    better test than "a path was returned". A single-file backup (a .zip, say)
    is accepted too, so this does not care who wrote it.
    """
    if not path:
        return False, "no backup was made."
    p = str(path)
    if os.path.isfile(p):
        try:
            if os.path.getsize(p) <= 0:
                return False, "the backup file is empty."
        except OSError:
            return False, "the backup file could not be read."
        return True, ""
    if not os.path.isdir(p):
        return False, f"the backup is not on disk ({p})."
    manifest = os.path.join(p, "manifest.json")
    if not os.path.isfile(manifest):
        return False, ("the backup folder has no manifest, which means the "
                       "snapshot did not finish.")
    try:
        snaps = [f for f in os.listdir(p) if f.lower().endswith(".gpkg")]
    except OSError:
        return False, "the backup folder could not be read."
    if not snaps:
        return False, "the backup folder contains no layer snapshots."
    return True, ""


def _is_text(layer, idx):
    try:
        return str(layer.fields()[idx].typeName()).lower() in ("string", "text")
    except Exception:
        return False


def plan(project, target, sources, renumber=True,
         boundary=None, demand=None, splitter=None, scope=None):
    """Work out everything the merge will change, without changing anything.

    ``boundary`` / ``demand`` / ``splitter`` are the layers the operator picked.
    Leave them None to auto-discover exactly as before.

    ``scope`` limits every write to a known set of layers. When it is None the
    merge reaches across the whole project, which is right for a single-network
    project and wrong for one holding several — see ``MergePlan.scope``.
    """
    target = _as_pon(target)
    sources = [s for s in (_as_pon(x) for x in sources)
               if s is not None and s != target]
    p = MergePlan(target, sources, project=project, scope=scope)
    if not sources:
        p.warnings.append("Nothing to merge — pick at least one other PON.")
        return p

    rows = {r.pon: r for r in collect(project, boundary=boundary,
                                      demand=demand, splitter=splitter)}

    # A PON that is not in the project cannot be merged. Without this the tool
    # accepted a bogus number, reassigned nothing, and then renumbered the whole
    # project anyway — a large write for no reason. Caught by the stress harness.
    missing = [x for x in sources if x not in rows]
    sources = [x for x in sources if x in rows]
    p.sources = list(sources)
    for x in missing:
        p.warnings.append(f"PON {x} is not in this project — ignored.")
    if not sources:
        p.warnings.append("Nothing to merge — none of those PONs exist here.")
        return p

    p.units_before = {s: rows[s].units for s in sources if s in rows}
    if target in rows:
        p.units_before[target] = rows[target].units
    p.units_after = sum(p.units_before.values())

    src_set = set(sources)
    if boundary is not None:
        boundary_layer = boundary
        demand_layer = demand
        splitter_layer = splitter
    else:
        boundary_layer, demand_layer, splitter_layer = find_layers(project)
    p.boundary_layer = boundary_layer
    p.demand_layer = demand_layer
    p.splitter_layer = splitter_layer

    # ── 1. attribute reassignment, across every in-scope PON-carrying layer ──
    for lyr, pon_field in _pon_layers(project, scope=scope):
        idx = lyr.fields().indexOf(pon_field)
        if idx < 0:
            continue
        text = _is_text(lyr, idx)
        changes = {}
        for feat in lyr.getFeatures():
            try:
                if _as_pon(feat[pon_field]) in src_set:
                    changes[feat.id()] = {idx: (str(target) if text else target)}
            except Exception:
                continue
        if changes:
            p.reassign.append((lyr, changes))
            p.moved[lyr.name()] = len(changes)

    # ── 2. boundaries: fuse into the target, drop the absorbed ones ──────
    if boundary_layer is not None:
        pon_field = vf_fields.resolve(boundary_layer, vf_fields.PON_NUM)
        tgt_feat, src_feats = None, []
        for feat in boundary_layer.getFeatures():
            try:
                v = _as_pon(feat[pon_field])
            except Exception:
                continue
            if v == target:
                tgt_feat = feat
            elif v in src_set:
                src_feats.append(feat)
        if tgt_feat is not None and src_feats:
            geom = tgt_feat.geometry()
            have = geom is not None and not geom.isEmpty()
            for f in src_feats:
                g = f.geometry()
                if g is None or g.isEmpty():
                    p.warnings.append(
                        f"PON {_as_pon(f[pon_field])} has no boundary geometry — "
                        "its features still move, but there is nothing to fuse.")
                    continue
                geom = g if not have else geom.combine(g)
                have = True
            if have and geom is not None and not geom.isEmpty():
                # JJ 2026-07-24: a merged PON should be ONE continuous boundary.
                # The absorbed tiles sit ~gap apart, so the union above is multipart;
                # bridge the internal seam into a single polygon. Guarded — a balloon
                # or a too-far gap falls back to this plain union, so a genuinely
                # non-adjacent merge still gets the honest "separate pieces" warning.
                try:
                    _bridged, _ok = bridge_seam(geom, boundary_layer, gap_m=DEFAULT_GAP_M)
                    if _ok and _bridged is not None and not _bridged.isEmpty():
                        geom = _bridged
                except Exception:
                    pass
                p.boundary = (boundary_layer, tgt_feat.id(), geom)
                # If bridging could not join them (too far apart), the result is
                # still multipart — say so plainly rather than quietly producing
                # two islands.
                try:
                    if geom.isMultipart():
                        n = len(geom.asGeometryCollection())
                        p.warnings.append(
                            f"Not adjacent: the merged PON would be {n} separate "
                            f"pieces on the map rather than one shape. Merge "
                            f"neighbouring PONs if you want a single area.")
                except Exception:
                    pass
            p.delete.append((boundary_layer, [f.id() for f in src_feats]))
        elif tgt_feat is None:
            p.warnings.append(
                f"PON {target} has no boundary polygon — features are "
                "reassigned but no boundary is fused.")

    # ── 3. compacting renumber ───────────────────────────────────────────
    if renumber:
        remaining = sorted((pon for pon in rows if pon not in src_set),
                           key=lambda v: (isinstance(v, str), v))
        numeric = [v for v in remaining if not isinstance(v, str)]
        p.renumber = {old: new for new, old in enumerate(numeric, start=1)
                      if old != new}
        if p.renumber:
            p.label_rewrites = _plan_label_rewrites(project, p.renumber,
                                                    scope=scope)
    return p


def _plan_label_rewrites(project, mapping, scope=None):
    """Rewrites for ``_SP<n>`` references buried in joint labels.

    The existing renumber engine only finds layers with a column literally named
    like the PON field, so it cannot see these at all — the PON lives INSIDE the
    text (``MMB_DJ262_SP10``). Returns (layer, changes, matched) so apply can
    assert that every match was accounted for.
    """
    out = []
    try:
        layers = list(project.mapLayers().values())
    except Exception:
        return out
    for lyr in layers:
        try:
            if lyr is None or not lyr.isValid() or not hasattr(lyr, "fields"):
                continue
        except Exception:
            continue
        if not in_scope(lyr, scope):
            continue
        fld = _label_field(lyr)
        if not fld:
            continue
        idx = lyr.fields().indexOf(fld)
        if idx < 0:
            continue
        changes, matched = {}, 0
        for feat in lyr.getFeatures():
            try:
                val = feat[fld]
            except Exception:
                continue
            if sp_number(val) is None:
                continue
            matched += 1
            new = rewrite_sp(val, mapping)
            if new is not None:
                changes[feat.id()] = {idx: new}
        if matched:
            out.append((lyr, changes, matched))
    return out


def _metric_crs_for(geom, layer):
    """A metre-based CRS suitable for ``geom``, or None if it is already metric.

    Matiko is EPSG:4326. Buffering by "2" there is 2 DEGREES — roughly 220 km —
    which is the ellipsoid/degrees trap that has bitten this codebase before. So
    anything measured in metres is done in a local UTM zone and transformed back.
    """
    try:
        from qgis.core import QgsCoordinateReferenceSystem
        crs = layer.crs()
        if not crs.isGeographic():
            return None                      # already in metres
        c = geom.centroid().asPoint()
        zone = int((c.x() + 180.0) / 6.0) + 1
        epsg = (32700 if c.y() < 0 else 32600) + zone      # UTM S / N
        out = QgsCoordinateReferenceSystem.fromEpsgId(epsg)
        return out if out.isValid() else None
    except Exception:
        return None


def _to_metric(geom, layer):
    """(geom_in_metres, back_transform) — back_transform may be None."""
    target = _metric_crs_for(geom, layer)
    if target is None:
        return geom, None
    try:
        from qgis.core import QgsCoordinateTransform, QgsProject
        proj = QgsProject.instance()
        fwd = QgsCoordinateTransform(layer.crs(), target, proj)
        rev = QgsCoordinateTransform(target, layer.crs(), proj)
        g = QgsGeometryClone(geom)
        if g.transform(fwd) != 0:
            return geom, None
        return g, rev
    except Exception:
        return geom, None


def QgsGeometryClone(geom):
    """A detached copy — transform() mutates in place."""
    from qgis.core import QgsGeometry
    return QgsGeometry(geom)


def straighten_coverage(geoms, layer, simplify_m=DEFAULT_SIMPLIFY_M):
    """Simplify a whole set of touching tiles TOGETHER. Returns {key: geom}.

    Per-polygon straightening is WRONG here and this was measured, not assumed:
    orthogonalizing each boundary on its own pushed edges across the shared
    border and took the layer from 3 overlapping pairs to 46, while ADDING
    vertices (median 14 -> 28) because squaring a corner inserts points.

    ``shapely.coverage_simplify`` is topology-aware: a shared edge is simplified
    ONCE and both neighbours get the identical result, so the tiling stays
    gap-free and overlap-free. That is the same call the existing Voronoi tiler
    already relies on. If shapely is too old, the originals come back unchanged
    rather than something subtly broken.
    """
    keys = list(geoms)
    if not keys:
        return {}
    try:
        import shapely
        from shapely import wkt as _wkt
    except Exception:
        return dict(geoms)
    if not hasattr(shapely, "coverage_simplify"):
        return dict(geoms)

    # Work in metres so the tolerance means what it says.
    sample = geoms[keys[0]]
    _m, back = _to_metric(sample, layer)
    fwd = None
    if back is not None:
        try:
            from qgis.core import QgsCoordinateTransform, QgsProject
            target = _metric_crs_for(sample, layer)
            fwd = QgsCoordinateTransform(layer.crs(), target, QgsProject.instance())
        except Exception:
            fwd, back = None, None

    shp, order = [], []
    for k in keys:
        g = geoms[k]
        if g is None or g.isEmpty():
            continue
        gg = QgsGeometryClone(g)
        if fwd is not None and gg.transform(fwd) != 0:
            return dict(geoms)
        try:
            shp.append(_wkt.loads(gg.asWkt()))
            order.append(k)
        except Exception:
            return dict(geoms)
    if not shp:
        return dict(geoms)

    try:
        out = list(shapely.coverage_simplify(shp, float(simplify_m),
                                             simplify_boundary=True))
    except Exception:
        return dict(geoms)

    from qgis.core import QgsGeometry
    result = dict(geoms)
    for k, sg in zip(order, out):
        try:
            if sg is None or sg.is_empty:
                continue
            qg = QgsGeometry.fromWkt(sg.wkt)
            if qg is None or qg.isEmpty() or not qg.isGeosValid():
                continue
            if back is not None:
                qg = QgsGeometryClone(qg)
                if qg.transform(back) != 0:
                    continue
            a0, a1 = geoms[k].area(), qg.area()
            if a0 <= 0 or not (0.90 <= (a1 / a0) <= 1.10):
                continue
            result[k] = qg
        except Exception:
            continue
    return result


#: Mitre limit for the inward buffer. 4.0 is GEOS's own default — high enough to
#: keep an ordinary corner square, low enough that a very sharp spike degrades to
#: a bevel instead of shooting off into a needle.
MITRE_LIMIT = 4.0


def _join_style_mitre():
    """The MITRE join-style enum for this QGIS build, or None.

    PROBED, never assumed. The enum moved between QGIS versions (``Qgis.JoinStyle``
    in 3.30+, ``QgsGeometry.JoinStyleMiter`` before) and Qt6 makes the integer
    values class-dependent, so hard-coding one is the trap that has bitten this
    codebase before. If neither is found the caller falls back to a round join —
    slightly rounded corners, never a crash.
    """
    try:
        from qgis.core import Qgis
        return Qgis.JoinStyle.Miter
    except Exception:
        pass
    try:
        from qgis.core import QgsGeometry as _QG
        return _QG.JoinStyleMiter
    except Exception:
        return None


def _inward_buffer(geom, distance, segments=8):
    """Buffer with SQUARE corners where the build supports it.

    A plain ``buffer()`` uses a round join, so pulling a straight-edged tile in by
    2 m re-rounds every convex corner — the tiles went from 12 vertices to 25 and
    started looking like the blobs they replaced. A mitre join keeps them square.
    Falls back to the round buffer if the enum is unavailable or the mitred result
    is unusable, so this can only ever improve the shape, never break it.
    """
    join = _join_style_mitre()
    cap = None
    try:
        from qgis.core import Qgis
        cap = Qgis.EndCapStyle.Round
    except Exception:
        cap = None
    # Both enums or neither. The 5-argument buffer needs a cap style too, and
    # passing a bare int for it would be the same class-dependent-enum guess this
    # codebase has already been bitten by — a wrong int silently changes the cap
    # rather than raising. Without both, take the round buffer: slightly rounded
    # corners are a cosmetic loss, a mis-set enum is a geometry bug.
    if join is not None and cap is not None:
        try:
            out = geom.buffer(distance, segments, cap, join, MITRE_LIMIT)
            if out is not None and not out.isEmpty() and out.isGeosValid():
                return out
        except Exception:
            pass
    try:
        return geom.buffer(distance, segments)
    except Exception:
        return None


def shrink(geom, layer, gap_m=DEFAULT_GAP_M):
    """Pull a boundary in by HALF the gap so neighbours end up ``gap_m`` apart.

    Returns (geom, changed). Measured in METRES via a local UTM zone, because
    the project CRS is very often degrees. Refuses if the result vanishes or
    loses more than a third of its area — a PON must still contain its homes.
    """
    if geom is None or geom.isEmpty() or gap_m <= 0:
        return geom, False
    metric, back = _to_metric(geom, layer)
    if back is None and layer.crs().isGeographic():
        return geom, False               # cannot measure metres — do not guess
    try:
        pulled = _inward_buffer(metric, -abs(float(gap_m)) / 2.0)
        if pulled is None or pulled.isEmpty() or not pulled.isGeosValid():
            return geom, False
        if back is not None:
            pulled = QgsGeometryClone(pulled)
            if pulled.transform(back) != 0:
                return geom, False
        a0, a1 = geom.area(), pulled.area()
        if a0 <= 0 or a1 <= 0 or (a1 / a0) < 0.67:
            return geom, False           # too much eaten — leave it alone
        return pulled, True
    except Exception:
        return geom, False


def _bridge_accept(area0, area_closed, now_multipart, max_growth=1.3):
    """Pure accept/reject for a seam-bridge close (JJ 2026-07-24 — a merged PON
    should be ONE continuous boundary). Accept only when the close produced a
    SINGLE piece AND did not balloon the area past ``max_growth``× — a balloon
    means the close reached something it should not (a neighbouring PON), so we
    fall back to the plain union. Pure, so it is unit-testable without QGIS.
    """
    if now_multipart or area0 <= 0 or area_closed <= 0:
        return False
    return area_closed <= area0 * max_growth


def bridge_seam(geom, layer, gap_m=DEFAULT_GAP_M):
    """Fill the INTERNAL seam of a just-merged boundary so it becomes ONE
    continuous polygon.

    The absorbed PON tiles sit ~``gap_m`` apart, so combining them gives a
    multipart (two islands). A morphological close (buffer +r then −r, sized to
    the gap) fills the concave seam between them while leaving the CONVEX outer
    edge in place — so it never reaches a non-merged neighbour. Measured in METRES
    via a local UTM zone (the project CRS is often degrees — the trap that has bitten
    this codebase). Returns ``(geom, bridged)``: the ORIGINAL geometry + ``False``
    when it is already one piece, cannot be measured in metres, the pieces are too
    far apart to bridge, or the close would balloon (guarded by ``_bridge_accept``).
    """
    # NB: a MultiPolygon layer reports isMultipart()==True even for a single piece,
    # so the real signal is the PART COUNT, not isMultipart().
    if geom is None or geom.isEmpty() or gap_m <= 0:
        return geom, False
    try:
        if len(geom.asGeometryCollection()) <= 1:
            return geom, False           # already one continuous piece
    except Exception:
        return geom, False
    metric, back = _to_metric(geom, layer)
    if back is None and layer.crs().isGeographic():
        return geom, False               # cannot measure metres — do not guess
    try:
        # Size the close to the ACTUAL widest seam between the pieces (measured in
        # metres), not a fixed guess — so adjacent PONs join whether the gap is the
        # usual ~4 m or a wider hand-edited one. Capped at MAX_BRIDGE_M: beyond that
        # the pieces are not really adjacent, so we refuse and keep them separate.
        _parts = metric.asGeometryCollection()
        _seam = 0.0
        for _a in range(len(_parts)):
            _nn = min((_parts[_a].distance(_parts[_b])
                       for _b in range(len(_parts)) if _b != _a), default=0.0)
            _seam = max(_seam, _nn)
        if _seam <= 0.0 or _seam > MAX_BRIDGE_M:
            return geom, False           # nothing to bridge, or too far to be adjacent
        r = _seam * 0.6 + 0.5            # 2r = 1.2·seam + 1 m → reliably spans it
        closed = metric.buffer(r, 8).buffer(-r, 8)
        if closed is None or closed.isEmpty() or not closed.isGeosValid():
            return geom, False
        _closed_parts = len(closed.asGeometryCollection())
        if not _bridge_accept(metric.area(), closed.area(), _closed_parts > 1):
            return geom, False
        if back is not None:
            closed = QgsGeometryClone(closed)
            if closed.transform(back) != 0:
                return geom, False
        if closed is None or closed.isEmpty() or not closed.isGeosValid():
            return geom, False
        return closed, True
    except Exception:
        return geom, False


def _orthogonalize(geom, angle_tolerance=15.0):
    """``native:orthogonalize`` on a bare geometry, or None."""
    try:
        from qgis.core import QgsGeometry
        return QgsGeometry(geom).orthogonalize(1e-8, 1000, angle_tolerance)
    except Exception:
        return None


def square_off(geom, layer, angle_tolerance=15.0):
    """Right-angle the merged polygon via ``native:orthogonalize``.

    Returns (geometry, squared). Falls back to the ORIGINAL geometry whenever
    squaring is unavailable, errors, or produces something invalid or a
    materially different size — a correct blob beats a pretty sliver.
    """
    if geom is None or geom.isEmpty():
        return geom, False
    try:
        import processing
        from qgis.core import QgsFeature, QgsVectorLayer
    except Exception:
        return geom, False
    try:
        tmp = QgsVectorLayer(f"Polygon?crs={layer.crs().authid()}", "sq", "memory")
        f = QgsFeature()
        f.setGeometry(geom)
        tmp.dataProvider().addFeatures([f])
        res = processing.run(
            "native:orthogonalize",
            {"INPUT": tmp, "ANGLE_TOLERANCE": angle_tolerance,
             "MAX_ITERATIONS": 1000, "OUTPUT": "memory:"})["OUTPUT"]
        out = next(res.getFeatures(), None)
        if out is None:
            return geom, False
        g2 = out.geometry()
        if g2 is None or g2.isEmpty() or not g2.isGeosValid():
            return geom, False
        a0, a1 = geom.area(), g2.area()
        if a0 <= 0 or not (0.90 <= (a1 / a0) <= 1.10):
            return geom, False        # collapsed or ballooned — refuse it
        return g2, True
    except Exception:
        return geom, False


def apply_plan(plan_obj, backup_path, feedback=None, square=True,
               polish=True, gap_m=DEFAULT_GAP_M, retile=True, counts=True):
    """Write the plan. Returns (ok, message).

    ``backup_path`` must point at a backup that ALREADY EXISTS on disk. This is
    an argument rather than a documented convention precisely so it cannot be
    forgotten: without a real file here, nothing is written at all.
    """
    def say(msg):
        if feedback:
            try:
                feedback(msg)
            except Exception:
                pass

    if not plan_obj.sources:
        return False, "Nothing to merge."
    ok_backup, why = backup_is_usable(backup_path)
    if not ok_backup:
        return False, (f"Refusing to merge: {why} A merge reassigns features "
                       "and removes the absorbed PON boundaries, so a "
                       "restorable backup must exist first.")

    written = 0

    # 1. reassign every absorbed feature to the target
    for lyr, changes in plan_obj.reassign:
        if not changes:
            continue
        if not lyr.dataProvider().changeAttributeValues(changes):
            return False, f"Could not reassign features in '{lyr.name()}'."
        written += len(changes)
        say(f"reassigned {len(changes)} in {lyr.name()}")

    # 2. fuse the boundary, square it, then remove the absorbed polygons
    if plan_obj.boundary is not None:
        lyr, fid, geom = plan_obj.boundary
        if square:
            geom, plan_obj.squared = square_off(geom, lyr)
            say("squared the merged boundary" if plan_obj.squared else
                "kept the un-squared boundary — squaring would have distorted it")
        if not lyr.dataProvider().changeGeometryValues({fid: geom}):
            return False, f"Could not update the boundary on '{lyr.name()}'."
        say("boundary fused")
    for lyr, fids in plan_obj.delete:
        if not fids:
            continue
        if not lyr.dataProvider().deleteFeatures(fids):
            return False, f"Could not remove absorbed boundaries in '{lyr.name()}'."
        say(f"absorbed {len(fids)} boundary polygon(s)")

    # 3. compacting renumber
    if plan_obj.renumber:
        for lyr, pon_field in _pon_layers_from_plan(plan_obj):
            idx = lyr.fields().indexOf(pon_field)
            if idx < 0:
                continue
            text = _is_text(lyr, idx)
            changes = {}
            for feat in lyr.getFeatures():
                try:
                    v = _as_pon(feat[pon_field])
                except Exception:
                    continue
                if v in plan_obj.renumber:
                    nv = plan_obj.renumber[v]
                    changes[feat.id()] = {idx: (str(nv) if text else nv)}
            if changes and not lyr.dataProvider().changeAttributeValues(changes):
                return False, f"Could not renumber '{lyr.name()}'."
            written += len(changes)
        say(f"renumbered {len(plan_obj.renumber)} PON(s)")

    # 4. _SP<n> joint labels
    for lyr, changes, matched in plan_obj.label_rewrites:
        if not changes:
            continue
        if not lyr.dataProvider().changeAttributeValues(changes):
            return False, f"Could not update joint labels in '{lyr.name()}'."
        written += len(changes)
        say(f"updated {len(changes)} of {matched} matching label(s) in {lyr.name()}")

    # 4b. BOUNDARY POLISH — straighten the whole tiling and separate the tiles.
    #
    # claude:intent MUTATE — user asked, verbatim: "the boundarie should be
    # straight lines and not blobs like the ermail mentioned and remember the
    # ponm boundaries should not touvch". Classification: MUTATE.
    # Plan: after the merge has settled, simplify the boundary COVERAGE (shared
    # edges stay identical) then pull every tile in by half the gap so no two
    # PONs touch.
    #
    # claude:approved-destructive — this rewrites boundary GEOMETRY. It is
    # reached only from inside apply_plan(), which has already refused to
    # proceed unless backup_is_usable(backup_path) confirmed a finished,
    # restorable snapshot exists on disk; the same backup covers this step.
    # Measured on real data before wiring: 123 touching pairs -> 0, median gap
    # 3.94 m, 0.12% of homes displaced. Every per-tile change is rejected if it
    # would move the area more than the guards in shrink()/straighten_coverage()
    # allow, so a bad reshape leaves the original geometry in place.
    # 4a. RETILE — rebuild EVERY boundary as a straight-edged tile.
    #
    # claude:intent MUTATE — user asked, verbatim: "make sure that when people
    # use the Merge tool, their PON boundaries also look nice ... It should just
    # change it across all of the different boundaries, just so it's neat and
    # there is a nice clear difference between them", with a before (rounded
    # blobs) and an after (straight tiles) screenshot. Classification: MUTATE.
    #
    # claude:approved-destructive — this REPLACES the geometry of every PON in
    # the boundary layer, not only the merged one. That is what was asked for and
    # JJ confirmed it knowing the blast radius. It is reached only from inside
    # apply_plan(), which has already refused to run unless a finished,
    # restorable backup exists on disk; the same backup covers this step.
    #
    # Runs AFTER the renumber so the boundary rows and the demand points agree on
    # PON numbers, and BEFORE the polish so the tiles get the same 4 m separation
    # every other boundary gets. Measured on Benfarm: median vertices per PON
    # 381 -> 12, overlapping pairs 51 -> 0.
    if retile and plan_obj.boundary_layer is not None:
        try:
            geoms, rstats = plan_retile(plan_obj.boundary_layer,
                                        plan_obj.demand_layer)
            plan_obj.retile_stats = rstats
            if geoms:
                blayer = plan_obj.boundary_layer
                if not blayer.dataProvider().changeGeometryValues(geoms):
                    return False, "Merged, but the boundaries could not be retiled."
                plan_obj.retile = geoms
                say(f"retiled {rstats['tiled']} boundary(ies) to straight edges")
                if rstats["untiled"]:
                    say(f"PON {', '.join(str(x) for x in rstats['untiled_pons'])} "
                        f"have no demand points to tile from — "
                        f"{rstats['untiled_clipped']} clipped clear of the new "
                        f"tiles, {rstats['untiled_kept_whole']} kept whole")
                if rstats["untiled_kept_whole"]:
                    # JJ 2026-07-27 chose KEEP-AND-WARN over delete: a boundary is
                    # never removed just because it is empty. So the warning has to
                    # do the work — it names the PONs and states the consequence.
                    # It goes to BOTH sinks on purpose: say() puts it in the log the
                    # dialog shows after a merge, and plan.warnings carries it on the
                    # plan object for any caller that inspects the result afterwards
                    # (the stress harness does). It cannot appear in the PRE-merge
                    # preview — which PONs end up empty is only known once the
                    # reassignment has been worked out.
                    pons = ", ".join(str(x) for x in rstats["untiled_pons"])
                    warn = (f"PON {pons} have no homes left, so their old "
                            f"boundaries were kept as-is and still overlap a "
                            f"neighbour. Nothing was deleted — review them and "
                            f"remove them by hand if they should not be there.")
                    plan_obj.warnings.append(warn)
                    say("WARNING: " + warn)
                if rstats["homes_outside"]:
                    say(f"{rstats['homes_outside']} home(s) sit on a tile edge "
                        f"rather than inside it")
                try:
                    blayer.triggerRepaint()
                except Exception:
                    pass
            elif rstats.get("reason"):
                say(f"boundaries NOT retiled — {rstats['reason']}")
        except Exception as exc:
            return False, f"Merged, but the boundary retile failed: {exc}"

    # A retile rebuilds every tile, so the polish must follow it even when this
    # merge fused nothing — otherwise the fresh tiles would be left touching.
    if polish and (plan_obj.boundary is not None or plan_obj.retile):
        blayer = (plan_obj.boundary[0] if plan_obj.boundary is not None
                  else plan_obj.boundary_layer)
        try:
            geoms, gstats = plan_boundary_polish(blayer, gap_m=gap_m)
            if geoms and not blayer.dataProvider().changeGeometryValues(geoms):
                return False, "Merged, but the boundaries could not be reshaped."
            if geoms:
                say(f"reshaped {len(geoms)} boundaries — "
                    f"{gstats['shrunk']} separated by {gap_m:g} m")
                try:
                    blayer.triggerRepaint()
                except Exception:
                    pass
        except Exception as exc:
            return False, f"Merged, but the boundary reshape failed: {exc}"

    # 4c. COUNTS — rewrite the stored unit/splitter totals from the live features.
    #
    # Runs after the renumber so every PON number is final, and before the names
    # so the whole row settles in one pass. THE PREVIEW ALREADY PROMISED THESE
    # NUMBERS: without this step "PON 67 = 200 units" was shown to the operator
    # and never written anywhere, which is the defect Luke reported.
    if counts and plan_obj.boundary_layer is not None:
        try:
            cchanges, cstats = plan_count_refresh(plan_obj.boundary_layer,
                                                  plan_obj.demand_layer,
                                                  plan_obj.splitter_layer)
            plan_obj.count_stats = cstats
            if cchanges:
                if not plan_obj.boundary_layer.dataProvider(
                        ).changeAttributeValues(cchanges):
                    return False, ("Merged, but the unit/splitter counts could "
                                   "not be updated.")
                written += len(cchanges)
                say(f"refreshed counts on {len(cchanges)} boundary row(s): "
                    f"{cstats['units_written']} unit count(s)"
                    + (f", {cstats['splitters_written']} splitter count(s)"
                       if cstats["splitter_source"] else ""))
            if cstats["splitter_source"] is None:
                say("splitter counts left untouched — the splitter layer has no "
                    "PON column, so they cannot be counted")
        except Exception as exc:
            return False, f"Merged, but the counts could not be refreshed: {exc}"

    # 5. NAMES LAST — resync every PON name to its (now final) PON number.
    #
    # claude:intent MUTATE — user asked, verbatim: "change it so that it updates
    # everything plrease and make sure everything gets renamed as pons and
    # splitters in the menues and when you change anything". Classification:
    # MUTATE — an explicit instruction to fix stored names.
    # Plan: after every PON number has settled, rewrite each recognised PON name
    # ("Zone 7" / "PON 7") to match its own PON number. Names we do not
    # recognise are somebody's own wording and are left untouched. Runs inside
    # the same backup-gated apply as the rest of the merge.
    #
    # It resyncs the WHOLE project rather than only the features this merge
    # touched, on purpose: that also REPAIRS names that drifted earlier instead
    # of merely not making it worse. Without this the merge renumbered zone_id
    # and left "Zone 3" sitting on PON 2 — 4,855 features out of sync on the
    # first real run.
    renamed = 0
    try:
        project = plan_obj.project or _project_of()
        if project is not None:
            for lyr, changes in plan_name_resync(project, scope=plan_obj.scope):
                if not changes:
                    continue
                if not lyr.dataProvider().changeAttributeValues(changes):
                    return False, (f"Merged, but could not update the PON names "
                                   f"in '{lyr.name()}'.")
                renamed += len(changes)
                try:
                    lyr.triggerRepaint()
                except Exception:
                    pass
            if renamed:
                say(f"renamed {renamed} feature(s) to match their PON number")
            # The STYLING matches on those names too — follow the rename through
            # it or the map loses every fill colour (measured: 0 of 52 features
            # matched a category afterwards).
            recat = resync_renderer_categories(project, scope=plan_obj.scope)
            if recat:
                say(f"updated {recat} map colour rule(s) to the new names")
    except Exception as exc:
        return False, f"Merged, but the PON names could not be resynced: {exc}"

    for lyr, _c in plan_obj.reassign:
        try:
            lyr.triggerRepaint()
        except Exception:
            pass
    tail = f", {renamed} name(s) resynced" if renamed else ""
    return True, (f"Merged into PON {plan_obj.target} — "
                  f"{written} value(s) written{tail}.")


def _project_of():
    """The live QgsProject, or None outside QGIS."""
    try:
        from qgis.core import QgsProject
        return QgsProject.instance()
    except Exception:
        return None


def _pon_layers_from_plan(plan_obj):
    """Re-resolve PON layers at apply time from the layers already in the plan."""
    seen, out = set(), []
    candidates = [lyr for lyr, _c in plan_obj.reassign]
    if plan_obj.boundary is not None:
        candidates.append(plan_obj.boundary[0])
    for lyr in candidates:
        if id(lyr) in seen:
            continue
        seen.add(id(lyr))
        name = vf_fields.resolve(lyr, vf_fields.PON_NUM)
        if name:
            out.append((lyr, name))
    return out
