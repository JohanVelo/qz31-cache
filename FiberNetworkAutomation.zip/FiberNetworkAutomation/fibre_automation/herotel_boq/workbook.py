"""Formula-preserving workbook output, committed together with its provenance."""
import ast
import hashlib
import json
import math
import operator
from pathlib import Path
import re
import shutil
import tempfile
import time
import xml.etree.ElementTree as ET
import zipfile

from .model import DEFERRED_ROWS, INPUT_ROWS, fingerprint

NA = '#N/A'
TEMPLATE = Path(__file__).with_name('template.json')


def _commit_directory(stage, destination, checkpoint):
    """Retry transient Windows sharing locks; never replace an existing output."""
    delays = (0.05, 0.1, 0.2, 0.4, 0.8)
    for attempt in range(len(delays) + 1):
        checkpoint()
        if destination.exists():
            raise FileExistsError('BOQ output already exists: ' + str(destination))
        try:
            stage.rename(destination)
            return
        except PermissionError as exc:
            if getattr(exc, 'winerror', None) not in (5, 32, 33) or attempt == len(delays):
                raise
            time.sleep(delays[attempt])


def evaluate(values):
    """Evaluate only audited arithmetic/SUM/ROUNDUP. Never execute Excel text."""
    cache, visiting = {}, set()
    binary = {ast.Add: operator.add, ast.Sub: operator.sub,
              ast.Mult: operator.mul, ast.Div: operator.truediv}

    def cell(address):
        if address in cache:
            return cache[address]
        if address in visiting or address not in values:
            raise ValueError('Circular or unsupported formula reference: '+address)
        visiting.add(address)
        value = values[address]
        if isinstance(value, str) and value.startswith('='):
            expr = value[1:].replace('$', '')
            expr = re.sub(r'([A-Z]+\d+):([A-Z]+\d+)', r'RANGE("\1","\2")', expr)
            value = node(ast.parse(expr, mode='eval').body)
        visiting.remove(address)
        if value is None:
            raise ValueError('Formula references unregistered blank: '+address)
        if value != NA and (not isinstance(value, (int, float)) or not math.isfinite(value)):
            raise ValueError('Unsupported formula result: '+address)
        cache[address] = value
        return value

    def node(n):
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
            return n.value
        if isinstance(n, ast.Name) and re.fullmatch(r'[A-Z]+\d+', n.id):
            return cell(n.id)
        if isinstance(n, ast.BinOp) and type(n.op) in binary:
            a, b = node(n.left), node(n.right)
            return NA if NA in (a, b) else binary[type(n.op)](a, b)
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.UAdd, ast.USub)):
            value = node(n.operand)
            return value if value == NA or isinstance(n.op, ast.UAdd) else -value
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and not n.keywords:
            if n.func.id == 'RANGE' and len(n.args) == 2:
                from openpyxl.utils.cell import range_boundaries, get_column_letter
                if not all(isinstance(a, ast.Constant) and isinstance(a.value, str) for a in n.args):
                    raise ValueError('Invalid range')
                a, b, c, d = range_boundaries(n.args[0].value+':'+n.args[1].value)
                if (c-a+1)*(d-b+1) > 10000:
                    raise ValueError('Formula range exceeds bound')
                return [cell(f'{get_column_letter(col)}{row}') for row in range(b, d+1) for col in range(a, c+1)]
            args = [node(a) for a in n.args]
            flat = [v for arg in args for v in (arg if isinstance(arg, list) else [arg])]
            if n.func.id == 'SUM':
                return NA if NA in flat else sum(flat)
            if n.func.id == 'ROUNDUP' and len(args) == 2:
                if NA in flat:
                    return NA
                value, digits = args
                if not isinstance(digits, (int, float)) or not float(digits).is_integer() or abs(digits) > 12:
                    raise ValueError('Unsupported ROUNDUP precision')
                factor = 10 ** digits
                return math.copysign(math.ceil(abs(value)*factor)/factor, value)
        raise ValueError('Unsupported formula syntax')

    for address in values:
        cell(address)
    return cache


def _literal(cell, value):
    cell.value = value
    if isinstance(value, str):
        cell.data_type = 's'


def _cache_formulas(path, cache):
    namespace = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
    staging = path.with_suffix('.cached.xlsx')
    with zipfile.ZipFile(path) as source, zipfile.ZipFile(staging, 'w', zipfile.ZIP_DEFLATED) as target:
        for info in source.infolist():
            data = source.read(info.filename)
            if info.filename == 'xl/worksheets/sheet1.xml':
                root = ET.fromstring(data)
                for cell in root.iter(namespace+'c'):
                    if cell.find(namespace+'f') is None:
                        continue
                    value = cache[cell.attrib['r']]
                    element = cell.find(namespace+'v')
                    if element is None:
                        element = ET.SubElement(cell, namespace+'v')
                    element.text = str(value)
                    if value == NA:
                        cell.set('t', 'e')
                    else:
                        cell.attrib.pop('t', None)
                data = ET.tostring(root, encoding='utf-8', xml_declaration=True)
            target.writestr(info, data)
    staging.replace(path)


def export(snapshot, bindings, result, destination, *, cancelled=lambda: False):
    """Create one new directory; cancellation/failure never leaves a final package."""
    from openpyxl import Workbook, load_workbook
    from openpyxl.formula.translate import Translator
    from openpyxl.styles import Alignment, Border, Font, PatternFill
    from openpyxl.utils import get_column_letter
    from openpyxl.xml.functions import fromstring

    snapshot.validate()
    if fingerprint(snapshot.payload()) != result.snapshot_hash or fingerprint([b.payload() for b in bindings]) != result.mapping_hash:
        raise ValueError('Preview no longer matches source or mapping')
    destination = Path(destination).resolve()
    if destination.exists():
        raise FileExistsError('Choose a new output folder; existing outputs are never overwritten')
    if not destination.parent.is_dir():
        raise ValueError('Output parent folder does not exist')
    stage = Path(tempfile.mkdtemp(prefix='.herotel-boq-', dir=destination.parent))
    try:
        def checkpoint():
            if cancelled():
                raise InterruptedError('BOQ generation cancelled')
        checkpoint()
        template = json.loads(TEMPLATE.read_text(encoding='utf-8'))
        wb = Workbook()
        ws = wb.active
        ws.title = 'HeroTel BOQ'
        ws.freeze_panes = 'C4'
        ws.column_dimensions['A'].width = 53
        ws.column_dimensions['B'].width = 18
        values = {}
        for row, source in enumerate(template['rows'], 1):
            for col in range(1, len(result.phases)+3):
                original = source[min(col, 3)-1]
                cell = ws.cell(row, col)
                cell.font = Font.from_tree(fromstring(original['font']))
                cell.fill = PatternFill.from_tree(fromstring(original['fill']))
                cell.border = Border.from_tree(fromstring(original['border']))
                cell.alignment = Alignment.from_tree(fromstring(original['alignment']))
                cell.number_format = original['number_format']
                value = original['value']
                if col <= 2:
                    if row == 2 and col == 1:
                        value = snapshot.project + ' — HeroTel BOQ'
                    _literal(cell, value)
                    continue
                phase = result.phases[col-3]
                if row == 1:
                    _literal(cell, phase)
                elif row in (*INPUT_ROWS, *DEFERRED_ROWS, 69, 70, 71, 72, 73):
                    quantity = result.cells.get((phase, row))
                    cell.value = quantity if quantity is not None else NA
                    cell.fill = PatternFill('solid', fgColor='FFC6EFCE' if row in INPUT_ROWS else 'FFFFE699')
                    values[cell.coordinate] = cell.value
                elif isinstance(value, str) and value.startswith('='):
                    cell.value = Translator(value, origin=f'C{row}').translate_formula(cell.coordinate)
                    values[cell.coordinate] = cell.value
                else:
                    _literal(cell, value)
            height = template['row_heights'].get(str(row))
            if height:
                ws.row_dimensions[row].height = height
        for col in range(3, len(result.phases)+3):
            ws.column_dimensions[get_column_letter(col)].width = 20
        for merged in template['merges']:
            ws.merge_cells(merged)
        cache = evaluate(values)
        info = wb.create_sheet('Run Info')
        metadata = dict(project=snapshot.project, status='SCOPED DRAFT — civil and backhaul excluded',
                        schema=snapshot.schema_name, schema_version=snapshot.schema_version,
                        snapshot_hash=result.snapshot_hash, mapping_hash=result.mapping_hash,
                        template_hash=fingerprint(template), template_correction=template['correction'],
                        reference_workbook_sha256=template['reference_sha256'],
                        calculation='Restricted supported-formula validation; native Excel validation not certified')
        for key, value in metadata.items():
            info.append([key, ''])
            _literal(info.cell(info.max_row, 2), str(value))
        issue_sheet = wb.create_sheet('Issues')
        for issue_row, issue in enumerate(('Trenching/backhaul deferred; #N/A means unresolved, not zero.',
                      'Tangent rows 69–73 have no approved green input or formula in the reference; unresolved.', *result.issues), 1):
            _literal(issue_sheet.cell(issue_row, 1), issue)
        sources = wb.create_sheet('Source Data')
        sources.append(['Layer identity', 'Layer', 'Source', 'Feature', 'Attributes JSON'])
        source_row = 2
        for layer in snapshot.layers:
            for record in layer.records:
                checkpoint()
                for column, value in enumerate((layer.identity, layer.name, layer.source, record.fid, json.dumps(dict(record.values), ensure_ascii=False)), 1):
                    if len(str(value)) > 32767:
                        raise ValueError('Source value exceeds Excel cell limit')
                    _literal(sources.cell(source_row, column), str(value))
                source_row += 1
        trace = wb.create_sheet('Quantity Trace')
        trace.append(['Phase', 'BOQ row', 'Layer identity', 'Feature', 'Contribution', 'Operation', 'Field', 'Mapping hash'])
        trace_row = 2
        for (phase, row), refs in result.trace.items():
            for ref in refs:
                if trace_row > 1048576:
                    trace = wb.create_sheet('Quantity Trace '+str(len(wb.worksheets)))
                    trace.append(['Phase', 'BOQ row', 'Layer identity', 'Feature', 'Contribution', 'Operation', 'Field', 'Mapping hash'])
                    trace_row = 2
                for col, value in enumerate((phase, row, ref['layer'], ref['fid'], ref['value'], ref['operation'], ref['field'], ref['binding_hash']), 1):
                    _literal(trace.cell(trace_row, col), value)
                trace_row += 1
        checkpoint()
        path = stage/'HeroTel BOQ.xlsx'
        wb.save(path)
        wb.close()
        _cache_formulas(path, cache)
        formula_wb = load_workbook(path, data_only=False)
        cached_wb = load_workbook(path, data_only=True)
        try:
            for address, original in values.items():
                if formula_wb.worksheets[0][address].value != original or cached_wb.worksheets[0][address].value != cache[address]:
                    raise ValueError('Workbook formula/cache verification failed: '+address)
        finally:
            formula_wb.close()
            cached_wb.close()
        receipt = dict(metadata=metadata, workbook_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                       sources=snapshot.payload(), mappings=[b.payload() for b in bindings],
                       inputs=[dict(phase=p, row=r, value=v, sources=result.trace.get((p,r), [])) for (p,r),v in result.cells.items()],
                       issues=result.issues)
        (stage/'provenance.json').write_text(json.dumps(receipt, indent=2, ensure_ascii=False, allow_nan=False), encoding='utf-8')
        checkpoint()
        _commit_directory(stage, destination, checkpoint)
        return destination/'HeroTel BOQ.xlsx'
    finally:
        if stage.exists():
            shutil.rmtree(stage)
