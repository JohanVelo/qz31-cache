"""plan — work out what to delete and how to renumber the survivors. READ-ONLY.

The contract (same as tagging/zone_tag.py): `build_plan` only READS and returns
a plan the dialog can show; `apply.py` is the only thing that writes. What you
see in the preview is exactly what gets written, because both come from here.

The renumber itself is deliberately boring:

    survivors = sorted(surviving numbers)          # "the order they flow now"
    remap = {old: new for new, old in enumerate(survivors, start=1)}

That is dense and monotonic BY CONSTRUCTION — gaps and duplicates are not
"checked for and rejected", they are impossible to express. Delete PON 15 and
16→15, 17→16: exactly what JJ asked for. The asserts in `verify_remap` are
belt-and-braces against a future edit, not the primary defence.

The risk was never the arithmetic. It is:
  * missing a place the number is written (`_SP`, the second `"Feeder Cab"`)
    → handled by scanning EVERY field into Occurrences and rewriting each one;
  * a REFERENCE getting its own sequence instead of following its target
    → handled by `follows=`: SP never gets a sequence, it rides PON's remap;
  * churn — reformatting labels whose number never moved
    → handled by only emitting an edit when `new != old`.
"""


# ── the MOA / PH2 lock ───────────────────────────────────────────────────────
# JJ's HARD standing rule: NEVER relabel or renumber the live Mohadin (MOA / PH2)
# network. Its labels are on built infrastructure, splice plans and as-builts that
# are already in the field — a renumber there is unrecoverable in any way that
# matters, even with a backup.
#
# Until 2026-07-15 that rule lived only in JJ's head. It now lives in the code,
# because both projects are routinely open side by side (Malmesbury on 8765,
# Mohadin on 8766) and this button sits in BOTH docks — it acts on whichever
# window it was launched from. One stray click was the only thing between the rule
# and a broken live network.
_MOA_PROJECT_HINTS = ("mohadin", "moa", "ph2", "potch")
# Layer-label evidence, so a renamed project file can't slip past the name check.
_MOA_LABEL_RE = r"^MOA\."


def moa_lock_reason(project):
    """Why this project must not be renumbered — or '' if it is fine to touch.

    Two independent tests: the project NAME/PATH, and the actual DATA (MOA.* labels
    + the documented 235..298 PON range). Either one trips the lock, because a
    project can be renamed but its labels cannot lie.
    """
    import re
    try:
        name = (project.baseName() or "")
        path = (project.fileName() or "")
    except Exception:
        return ""
    hay = f"{name} {path}".lower().replace("\\", "/")
    # word-ish match so 'moa' doesn't fire on 'Mohadin Backup'/'moat'/'promo'
    hit = None
    for h in _MOA_PROJECT_HINTS:
        if re.search(rf"(?<![a-z]){re.escape(h)}(?![a-z])", hay):
            hit = h
            break
    if hit and "backup" not in hay and "copy" not in hay and "sandbox" not in hay:
        return (f"This looks like the live Mohadin / PH2 project "
                f"(matched '{hit}' in '{name}').")

    # data evidence: MOA.* labels or the documented PH2 PON range 235..298
    try:
        from qgis.core import QgsVectorLayer
        rx = re.compile(_MOA_LABEL_RE)
        for lyr in project.mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
                continue
            names = {f.name().lower() for f in lyr.fields()}
            if "label" not in names:
                continue
            real = next(f.name() for f in lyr.fields()
                        if f.name().lower() == "label")
            n = 0
            for feat in lyr.getFeatures():
                v = feat[real]
                if isinstance(v, str) and rx.match(v):
                    return (f"This project carries live MOA labels "
                            f"(e.g. '{v}' in '{lyr.name()}').")
                n += 1
                if n >= 40:
                    break
    except Exception:
        pass
    return ""


# ── containers ───────────────────────────────────────────────────────────────
class Edit:
    """One field on one feature: old string → new string."""

    __slots__ = ("fid", "field", "layer_id", "layer_name", "new", "old", "system")

    def __init__(self, layer_id, layer_name, fid, field, old, new, system):
        self.layer_id = layer_id
        self.layer_name = layer_name
        self.fid = fid
        self.field = field
        self.old = old
        self.new = new
        self.system = system

    def __repr__(self):   # pragma: no cover
        return f"Edit({self.layer_name}.{self.field} {self.old!r}→{self.new!r})"


class Deletion:
    """Features to remove from one layer."""

    __slots__ = ("fids", "layer_id", "layer_name", "reason")

    def __init__(self, layer_id, layer_name, fids, reason):
        self.layer_id = layer_id
        self.layer_name = layer_name
        self.fids = sorted(fids)
        self.reason = reason

    def __len__(self):
        return len(self.fids)


class RenumberPlan:
    """Everything that WOULD happen. Produced read-only; consumed by apply."""

    SAMPLE_CAP = 200

    def __init__(self):
        self.deletions = []        # [Deletion]
        self.edits = []            # [Edit]
        self.remaps = {}           # system -> {old: new}  (identity systems)
        self.fid_remaps = {}       # system -> {(layer_id, fid): new}  (row numbers)
        self.blocked = []          # HARD stops — apply must refuse
        self.warnings = []         # things JJ must see but that don't stop it
        self.stats = {}            # system -> {"moved": n, "edits": n, "total": n}
        self.doomed_pons = []
        self.systems_renumbered = []

    @property
    def total_deleted(self):
        return sum(len(d) for d in self.deletions)

    @property
    def total_edits(self):
        return len(self.edits)

    @property
    def ok(self):
        return not self.blocked

    def edits_by_layer(self):
        out = {}
        for e in self.edits:
            out.setdefault(e.layer_id, []).append(e)
        return out

    def samples(self, system=None, cap=None):
        cap = cap or self.SAMPLE_CAP
        src = [e for e in self.edits if system is None or e.system == system]
        return src[:cap]

    def summary_lines(self):
        out = []
        for d in self.deletions:
            out.append(f"delete {len(d):,} from '{d.layer_name}'  ({d.reason})")
        for sysname in self.systems_renumbered:
            st = self.stats.get(sysname, {})
            out.append(f"renumber {sysname}: {st.get('moved', 0):,} number(s) move "
                       f"→ {st.get('edits', 0):,} label(s) rewritten")
        return out


# ── the remap ────────────────────────────────────────────────────────────────
def compact_remap(all_numbers, doomed=(), start=1):
    """{old: new} that closes every gap, preserving relative order.

    Dense + monotonic by construction: sort the survivors, hand out 1..N in that
    order. Returns EVERY survivor (including the ones that don't move) so callers
    can resolve references; use `movers()` for the ones that actually change.
    """
    doomed = set(doomed)
    survivors = sorted({int(n) for n in all_numbers} - doomed)
    return {old: new for new, old in enumerate(survivors, start=start)}


def movers(remap):
    return {o: n for o, n in remap.items() if o != n}


def verify_remap(remap, start=1):
    """Belt-and-braces. [] means the map is sound. Anything here is a hard stop."""
    problems = []
    if not remap:
        return problems
    olds = sorted(remap)
    news = [remap[o] for o in olds]
    # 1. order preserved — old_a < old_b  <=>  new_a < new_b
    if news != sorted(news):
        problems.append("the renumber would reorder the network "
                        "(a later item would get an earlier number)")
    # 2. no duplicates
    if len(set(news)) != len(news):
        dupes = sorted({n for n in news if news.count(n) > 1})
        problems.append(f"the renumber would create duplicate number(s): {dupes[:8]}")
    # 3. dense 1..N
    want = list(range(start, start + len(news)))
    if sorted(news) != want:
        problems.append(f"the renumber would not be gap-free "
                        f"(expected {start}..{start + len(news) - 1})")
    return problems


# ── plan builders ────────────────────────────────────────────────────────────
def build_renumber_plan(scans, systems, doomed_by_system=None, plan=None,
                        deleted_fids=None):
    """Renumber `systems` (names) using the measured `scans`. READ-ONLY.

    `doomed_by_system` = {system: {numbers being deleted}} — those numbers drop
    out and everything after them shifts down to close the gap.
    `deleted_fids`     = {layer_id: {fid}} — needed by by_feature (row-number)
                         systems, which renumber the SURVIVING features 1..N.
    """
    from . import scan as _scan     # noqa: F401  (kept for symmetry/typing)

    plan = plan or RenumberPlan()
    doomed_by_system = doomed_by_system or {}
    deleted_fids = deleted_fids or {}
    want = list(systems)

    # ids first, then references — a reference needs its target's remap to exist
    ordered = ([s for s in want if not scans[s].spec.is_reference]
               + [s for s in want if scans[s].spec.is_reference])

    for name in ordered:
        sc = scans.get(name)
        if sc is None:
            plan.blocked.append(f"'{name}' was not scanned.")
            continue
        spec = sc.spec

        if spec.is_reference:
            # A REFERENCE never gets its own sequence — it follows its target.
            # This is the SP rule: renumber PON 16→15 and every _SP16 becomes
            # _SP15. Proven 485/485 + 37/37 against the polygons.
            src = plan.remaps.get(spec.follows)
            if src is None:
                plan.blocked.append(
                    f"'{name}' follows '{spec.follows}', which is not being "
                    f"renumbered — its references would be left pointing at the "
                    f"old numbers.")
                continue
            remap = src
        elif spec.by_feature:
            # A ROW NUMBER (the plain `id` column): every surviving FEATURE gets
            # the next number, ordered by what it has now (fid breaks ties). So
            # duplicates resolve themselves instead of blocking — Trenching.id has
            # 11 dupes today and they are meaningless for a row number.
            survivors = [o for o in sc.occurrences
                         if o.fid not in deleted_fids.get(o.layer_id, ())]
            survivors.sort(key=lambda o: (o.number, o.fid))
            fid_remap = {(o.layer_id, o.fid): i
                         for i, o in enumerate(survivors, start=1)}
            plan.fid_remaps[name] = fid_remap
            moved = sum(1 for o in survivors
                        if fid_remap[(o.layer_id, o.fid)] != o.number)
            plan.stats[name] = {"moved": moved, "edits": 0, "total": sc.count}
            plan.systems_renumbered.append(name)
            continue
        else:
            doomed = doomed_by_system.get(name, set())
            if sc.duplicates:
                # Name the offenders. "duplicates exist" is useless; JJ needs to
                # know WHICH features so he can go fix them. On Malmsbury these
                # are DJ 259 (the same joint recorded in both layers) and DJ 505
                # (two joints 19.85 m apart that share a number — a real error).
                bits = []
                for num in sorted(sc.duplicates)[:4]:
                    vals = sorted({o.value for o in sc.occurrences
                                   if o.number == num})
                    bits.append(f"{num} = " + " + ".join(repr(v) for v in vals[:3]))
                plan.blocked.append(
                    f"{name}: {len(sc.duplicates)} number(s) are used twice, so "
                    f"renumbering would silently merge two features into one — "
                    f"{'; '.join(bits)}. Give each a unique number first, or "
                    f"untick {name}.")
                continue
            remap = compact_remap(sc.distinct, doomed)
            problems = verify_remap(remap)
            if problems:
                plan.blocked.extend(f"{name}: {p}" for p in problems)
                continue
            plan.remaps[name] = remap

        if sc.unparsed:
            plan.warnings.append(
                f"{name}: {len(sc.unparsed)} value(s) can't be read and will be "
                f"left exactly as they are — e.g. {sc.unparsed[0]}")

        plan.stats[name] = {"moved": len(movers(remap)), "edits": 0,
                            "total": sc.count}
        plan.systems_renumbered.append(name)
        plan.remaps.setdefault(name, remap)

    _compose_edits(scans, plan)
    return plan


def _compose_edits(scans, plan):
    """One Edit per (layer, feature, field) — every system applied together.

    This is not tidiness, it is correctness. Two systems can live in the SAME
    string: `Dome Joints.Name` = "MMB_DJ220_SP12" carries BOTH the DJ id and the
    SP reference. Emitting one edit per system would make them race on the same
    field — last writer wins and the other change vanishes silently.

    So: bucket every moved occurrence by the field it sits in, then rewrite all of
    that value's digit spans in ONE pass, RIGHT-TO-LEFT (so each replacement can't
    shift the offsets of the spans still to come).
    """
    buckets = {}
    for name in plan.systems_renumbered:
        sc = scans[name]
        remap = plan.remaps.get(name)
        fid_remap = plan.fid_remaps.get(name)
        for occ in sc.occurrences:
            if fid_remap is not None:        # a row number: keyed by FEATURE
                new = fid_remap.get((occ.layer_id, occ.fid))
            elif remap is not None:          # an identity: keyed by VALUE
                new = remap.get(occ.number)
            else:
                continue
            if new is None or new == occ.number:
                continue                     # deleted, or didn't move → no churn
            buckets.setdefault(
                (occ.layer_id, occ.layer_name, occ.fid, occ.field), []
            ).append((occ, new, name))

    for (lid, lname, fid, field), items in sorted(
            buckets.items(), key=lambda kv: (kv[0][1], kv[0][2], kv[0][3])):
        original = items[0][0].value
        value = original
        # right-to-left keeps every remaining span's offsets valid
        for occ, new, name in sorted(items, key=lambda t: t[0].start, reverse=True):
            w = occ.width if occ.zero_padded else scans[name].spec.width_for(field)
            value = value[:occ.start] + str(new).zfill(w) + value[occ.end:]
        if value == original:
            continue
        plan.edits.append(Edit(lid, lname, fid, field, original, value,
                               "+".join(sorted({n for _o, _n, n in items}))))
        for _o, _n, name in items:
            plan.stats[name]["edits"] += 1


def build_delete_plan(project, doomed_pon_numbers, cascade_layer_ids, scans,
                      pon_system="PON", plan=None):
    """Which features go: the PON polygons + whatever is INSIDE them (ticked).

    Containment reuses the shipped tagging engine (zone_tag), which is already
    proven 100% against QGIS's own select-by-location — so "inside PON 13" means
    the same thing here as it does in the Tag by PON / Phase column.
    """
    plan = plan or RenumberPlan()
    plan.doomed_pons = sorted(int(n) for n in doomed_pon_numbers)
    if not plan.doomed_pons:
        return plan

    sc = scans.get(pon_system)
    if sc is None:
        plan.blocked.append(f"'{pon_system}' was not scanned — cannot find the "
                            f"PONs to delete.")
        return plan

    doomed = set(plan.doomed_pons)

    # 1. the PON polygons themselves
    by_layer = {}
    for occ in sc.occurrences:
        if occ.number in doomed:
            by_layer.setdefault((occ.layer_id, occ.layer_name), set()).add(occ.fid)
    for (lid, lname), fids in by_layer.items():
        plan.deletions.append(Deletion(lid, lname, fids,
                                       f"{pon_system} " +
                                       ", ".join(str(n) for n in plan.doomed_pons)))

    # 2. everything that BELONGS to them, per ticked layer
    if cascade_layer_ids:
        inside = _features_inside(project, sc, doomed, cascade_layer_ids, plan,
                                  scans=scans)
        for lid, (lname, fids) in inside.items():
            if fids:
                plan.deletions.append(
                    Deletion(lid, lname, fids, "belongs to a removed PON"))
    return plan


def _check_orphan_refs(scans, plan, deleted_fids):
    """BLOCK if a surviving feature still references a PON that is being deleted.

    THE failure this whole tool exists to prevent. Delete PON 32 and leave a joint
    saying `_SP32` behind: the compaction makes the OLD PON 33 into the NEW 32, so
    that joint now belongs to a completely different PON — and nothing on screen
    says so. It looks fine. It is silently wrong.

    Verified on the live Malmsbury backup 2026-07-15: deleting PON 32 without
    cascading Dome Joints stranded 15 joints on `_SP32`, with no warning at all.

    So this is a hard BLOCK, not a warning: the fix (tick the layer, or keep the
    PON) is one click, and the cost of getting it wrong is a network that points
    at the wrong PON forever.
    """
    doomed = set(plan.doomed_pons)
    if not doomed:
        return
    for name in list(plan.systems_renumbered):
        sc = scans.get(name)
        if sc is None or not sc.spec.is_reference:
            continue
        if sc.spec.follows != "PON":
            continue
        stranded = {}
        for occ in sc.occurrences:
            if occ.number not in doomed:
                continue
            if occ.fid in deleted_fids.get(occ.layer_id, ()):
                continue                       # goes with the PON — fine
            stranded.setdefault(occ.layer_name, []).append(occ.value)
        if not stranded:
            continue
        where = ", ".join(f"{len(v)} in '{k}'" for k, v in sorted(stranded.items()))
        pons = ", ".join(str(d) for d in sorted(doomed))
        example = sorted(stranded[sorted(stranded)[0]])[0]
        plan.blocked.append(
            f"{name}: {where} still reference PON {pons}, which you are deleting "
            f"(e.g. {example!r}). After the renumber that number belongs to a "
            f"DIFFERENT PON, so those features would silently point at the wrong "
            f"one. Either tick {' + '.join(sorted(stranded))} under 'Cascade into' "
            f"so they go with the PON, or keep that PON.")


def build_containment(project, scans, layer_ids=None, warn=None):
    """Which PON(s) does each feature BELONG to → {layer_id: {fid: frozenset(pons)}}.

    "Belongs to PON 32" is deliberately BOTH of:
      * it sits inside PON 32's polygon, and
      * its name references PON 32 (`_SP32`).

    Geometry alone is not enough — proven live 2026-07-15: PON 32's feeder joint
    ('HT_MMB_DJ952_SP32') sits just OUTSIDE the P032 polygon, so a purely
    geometric cascade missed it and left it stranded pointing at the wrong PON.
    It belongs to PON 32 because it SAYS so, wherever it happens to sit.

    Also returns {pon: {layer_name: n}} for display. One function so the dialog's
    counts and the planner's deletions can never disagree.
    """
    try:
        from ..tagging import zone_tag
    except ImportError:                       # pragma: no cover - flat import
        from fibre_automation.tagging import zone_tag
    import re

    pon_scan = scans.get("PON")
    if pon_scan is None or not pon_scan.occurrences:
        return {}, {}
    poly_id = pon_scan.occurrences[0].layer_id
    value_field = pon_scan.occurrences[0].field
    if layer_ids is None:
        layer_ids = [l.id() for l in zone_tag.target_layers(project)]
    targets = [lid for lid in layer_ids if lid != poly_id]
    if not targets:
        return {}, {}

    contain = {}
    spec = zone_tag.TagSpec(poly_id, value_field, "pon_tmp")
    tag = zone_tag.build_plan(project, [spec], targets)
    if warn is not None:
        for e in tag.errors:
            warn.append(f"containment: {e}")

    # ── 1. geometry: what sits inside a PON polygon
    for lid, rows in tag.rows.items():
        if project.mapLayer(lid) is None:
            continue
        # Read the field name zone_tag ACTUALLY used — it sanitizes what we ask
        # for (a leading underscore is stripped, shapefile names are capped at
        # 10 chars), so assuming our own key silently returns None for every
        # feature and the cascade deletes nothing. Found on the sandbox.
        key = (tag.out_fields.get(lid) or ["pon_tmp"])[0]
        d = contain.setdefault(lid, {})
        for fid, row in rows.items():
            val = row.get(key)
            if not val:
                continue
            nums = set()
            for part in str(val).split(", "):
                m = re.sub(r"\D", "", part)
                if m:
                    nums.add(int(m))
            if nums:
                d[fid] = frozenset(nums)

    # ── 2. references: what NAMES a PON, wherever it physically sits
    for name, sc in scans.items():
        if not sc.spec.is_reference or sc.spec.follows != "PON":
            continue
        for occ in sc.occurrences:
            if occ.layer_id == poly_id or occ.layer_id not in contain:
                if occ.layer_id == poly_id:
                    continue
                contain.setdefault(occ.layer_id, {})
            d = contain[occ.layer_id]
            d[occ.fid] = frozenset(d.get(occ.fid, frozenset()) | {occ.number})

    per_pon = {}
    for lid, rows in contain.items():
        lyr = project.mapLayer(lid)
        if lyr is None:
            continue
        for pons in rows.values():
            for n in pons:
                per_pon.setdefault(n, {})
                per_pon[n][lyr.name()] = per_pon[n].get(lyr.name(), 0) + 1
    return contain, per_pon


def belongs_wholly_to(pons, doomed):
    """True if EVERY PON this feature belongs to is being deleted.

    A cable crossing a surviving PON still serves it, so it stays.
    """
    return bool(pons) and set(pons) <= set(doomed)


def _features_inside(project, pon_scan, doomed, layer_ids, plan, scans=None):
    """{layer_id: (name, {fids})} for features that BELONG to a doomed PON."""
    contain, _per = build_containment(project, scans or {"PON": pon_scan},
                                      layer_ids, warn=plan.warnings)
    out = {}
    for lid, rows in contain.items():
        lyr = project.mapLayer(lid)
        if lyr is None or lid not in set(layer_ids):
            continue
        fids = {fid for fid, pons in rows.items()
                if belongs_wholly_to(pons, doomed)}
        out[lid] = (lyr.name(), fids)
    return out


def build_plan(project, doomed_pon_numbers=(), cascade_layer_ids=(),
               systems=(), scans=None, specs=None):
    """The whole thing, read-only: what to delete + how to renumber. → RenumberPlan."""
    from . import scan as _scan
    from qgis.core import QgsProject
    project = project or QgsProject.instance()

    plan = RenumberPlan()
    # Gate FIRST, before we even read the layers: nothing about a locked project
    # should be plannable, previewable or appliable.
    lock = moa_lock_reason(project)
    if lock:
        plan.blocked.append(
            f"⛔ Refusing to touch this project. {lock}\n\n"
            f"The live Mohadin / PH2 network must never be renumbered — its "
            f"labels are on built infrastructure, splice plans and as-builts "
            f"already in the field. This tool is for Malmesbury / HeroTel and "
            f"other planning projects.\n\n"
            f"If you genuinely need to renumber a Mohadin COPY, put 'backup', "
            f"'copy' or 'sandbox' in the project name.")
        return plan

    if scans is None:
        scans = _scan.scan_project(project, specs)
    build_delete_plan(project, doomed_pon_numbers, cascade_layer_ids, scans,
                      plan=plan)

    # deleting a PON removes its number from the PON system; the rest close up
    doomed_by_system = {}
    if doomed_pon_numbers:
        doomed_by_system["PON"] = {int(n) for n in doomed_pon_numbers}

    # deleting features removes THEIR numbers from their own systems too
    deleted_fids = {}
    for d in plan.deletions:
        deleted_fids.setdefault(d.layer_id, set()).update(d.fids)
    for name in systems:
        sc = scans.get(name)
        if sc is None or sc.spec.is_reference or sc.spec.by_feature or name == "PON":
            continue
        gone = {o.number for o in sc.occurrences
                if o.fid in deleted_fids.get(o.layer_id, ())}
        if gone:
            doomed_by_system[name] = gone

    build_renumber_plan(scans, systems, doomed_by_system, plan=plan,
                        deleted_fids=deleted_fids)
    _check_orphan_refs(scans, plan, deleted_fids)

    # An edit on a feature we are about to delete is pointless; drop it so the
    # preview count is the truth and apply never writes to a dead fid.
    if deleted_fids:
        before = len(plan.edits)
        plan.edits = [e for e in plan.edits
                      if e.fid not in deleted_fids.get(e.layer_id, ())]
        dropped = before - len(plan.edits)
        if dropped:
            for name in plan.stats:
                plan.stats[name]["edits"] = sum(
                    1 for e in plan.edits if e.system == name)
    return plan
