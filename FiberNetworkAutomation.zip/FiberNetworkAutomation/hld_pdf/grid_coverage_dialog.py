# -*- coding: utf-8 -*-
"""Grid coverage — decide what the plotting grid covers, and which pages print.

The grid used to tile the AOI boundary box, so a drawing came out with pages over open
veld. It now tiles what is TICKED ON in the Layers panel, and this dialog is where that
choice is visible and adjustable before anything renders:

    * the top list is every visible vector layer the grid may cover — untick one here and
      the grid stops covering it, WITHOUT touching the operator's own layer tree;
    * the bottom list is the pages that choice produces, each with what falls inside it,
      so a page can be dropped by hand;
    * the kept cells travel to the render as geometry (WKT), not as a recipe, so the
      headless process cannot re-derive a different set from the one on screen.

Opened from the toolbar only. Never instantiate it through the bridge's /execute/sync —
a modal on the Qt main thread freezes QGIS.
"""
import os
import traceback

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QListWidget, QListWidgetItem,
    QPushButton, QDialogButtonBox, QApplication, QSplitter, QWidget, QMessageBox,
)
from qgis.PyQt.QtGui import QCursor

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

# Scoped enum names throughout, matching the rest of the plugin. An earlier draft used
# `getattr(Qt.CheckState, "Unchecked", None) or Qt.Unchecked` as a Qt5 fallback, and the
# qt6 lint was right to reject it: Unchecked is 0, so the `or` falls through to the
# unscoped name and raises on PyQt6 - a crash on the one branch that looked safest.
_CHECKED = Qt.CheckState.Checked
_UNCHECKED = Qt.CheckState.Unchecked
_USER_ROLE = Qt.ItemDataRole.UserRole


def load_engine(hld_cfg):
    """Exec the atlas engine into a fresh namespace carrying `hld_cfg`.

    Same loader the live build uses. A fresh namespace per call matters: the engine keeps
    its resolved config in a module-level CFG, so a reused one would answer for the
    previous run's settings.
    """
    here = os.path.dirname(os.path.abspath(__file__))
    engine = os.path.join(here, "hld_atlas_engine.py")
    if not os.path.exists(engine):
        raise RuntimeError("Engine not found: %s" % engine)
    ns = {"HLD_CFG": dict(hld_cfg or {})}
    with open(engine, encoding="utf-8") as f:
        exec(compile(f.read(), engine, "exec"), ns)   # defines the engine; builds nothing
    return ns


def _summarise(counts):
    """'poles 12 · Distribution Cable 3' — what is actually on a page, biggest first."""
    if not counts:
        return "empty"
    parts = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
    return "  ·  ".join("%s %d" % (n, c) for n, c in parts[:4])


class GridCoverageDialog(QDialog):
    """Pick the layers the grid covers, then the pages that get printed."""

    def __init__(self, parent, hld_cfg):
        super().__init__(parent)
        self.setWindowTitle("Plotting grid — what it covers")
        self.setMinimumSize(680, 620)
        self._base_cfg = dict(hld_cfg or {})
        self._rows = []          # plan_grid rows for the pages currently listed
        self._crs_authid = ""
        self._busy = False       # re-entry guard: reloading pages re-emits itemChanged

        root = QVBoxLayout(self)
        root.setSpacing(10)

        head = QLabel(
            "<b>BETA</b> — the grid covers whatever is ticked below, which starts as "
            "exactly what is switched on in your Layers panel. Unticking here changes "
            "<i>this drawing only</i>; your project is not touched.")
        head.setWordWrap(True)
        root.addWidget(head)

        split = QSplitter(self)
        split.setOrientation(Qt.Orientation.Vertical)

        # ── layers ────────────────────────────────────────────────────────
        top = QWidget()
        tl = QVBoxLayout(top)
        tl.setContentsMargins(0, 0, 0, 0)
        tl.addWidget(QLabel("Grid covers these layers"))
        self.layer_list = QListWidget()
        self.layer_list.itemChanged.connect(self._on_layer_toggled)
        tl.addWidget(self.layer_list)
        split.addWidget(top)

        # ── pages ─────────────────────────────────────────────────────────
        bot = QWidget()
        bl = QVBoxLayout(bot)
        bl.setContentsMargins(0, 0, 0, 0)
        self.pages_lbl = QLabel("Pages")
        bl.addWidget(self.pages_lbl)
        self.page_list = QListWidget()
        self.page_list.itemChanged.connect(self._on_page_toggled)
        bl.addWidget(self.page_list)
        row = QHBoxLayout()
        for text, fn in (("All pages", lambda: self._set_all_pages(True)),
                         ("No pages", lambda: self._set_all_pages(False))):
            b = QPushButton(text)
            b.clicked.connect(fn)
            row.addWidget(b)
        row.addStretch(1)
        bl.addLayout(row)
        split.addWidget(bot)
        split.setStretchFactor(0, 1)
        split.setStretchFactor(1, 2)
        root.addWidget(split, 1)

        self.status = QLabel("")
        self.status.setWordWrap(True)
        root.addWidget(self.status)

        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                              | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        self._ok = bb.button(QDialogButtonBox.StandardButton.Ok)
        self._ok.setText("Export these pages")
        root.addWidget(bb)

        self._load_layers()
        self._reload_pages()

    # ── population ────────────────────────────────────────────────────────
    def _load_layers(self):
        """Seed the list from what is ticked on right now — a copy, not the live tree."""
        from qgis.core import QgsProject, QgsVectorLayer
        proj = QgsProject.instance()
        grid_name = (self._base_cfg.get("grid_layer_name") or "HLD Grid")
        try:
            checked = {l.id() for l in proj.layerTreeRoot().checkedLayers()}
        except Exception:
            checked = set(proj.mapLayers().keys())
        self._busy = True
        self.layer_list.clear()
        for lyr in proj.mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer) or lyr.name() == grid_name:
                continue
            try:
                n = lyr.featureCount()
            except Exception:
                _swallowed_note(); continue
            if n <= 0:
                continue
            it = QListWidgetItem("%s   —   %s features" % (lyr.name(), format(n, ",d")))
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(_CHECKED if lyr.id() in checked else _UNCHECKED)
            it.setData(_USER_ROLE, lyr.id())
            self.layer_list.addItem(it)
        self._busy = False

    def _chosen_layer_ids(self):
        out = []
        for i in range(self.layer_list.count()):
            it = self.layer_list.item(i)
            if it.checkState() == _CHECKED:
                out.append(it.data(_USER_ROLE))
        return out

    def _reload_pages(self):
        """Ask the engine what would print, and list it."""
        ids = self._chosen_layer_ids()
        cfg = dict(self._base_cfg)
        cfg["grid_content_layer_ids"] = ids
        # a stale approved list would short-circuit the plan and echo the old pages back
        cfg["grid_cells_wkt"] = []
        cfg["grid_cells_crs"] = ""
        QApplication.setOverrideCursor(QCursor(Qt.CursorShape.WaitCursor))
        try:
            ns = load_engine(cfg)
            _cells, crs, rows = ns["plan_grid"]()
        except Exception as e:
            QApplication.restoreOverrideCursor()
            print("grid coverage: plan failed\n" + traceback.format_exc())
            self._rows = []
            self._crs_authid = ""
            self.page_list.clear()
            self.status.setText("Could not work out the pages: %s" % e)
            self._ok.setEnabled(False)
            return
        finally:
            try:
                QApplication.restoreOverrideCursor()
            except Exception:
                _swallowed_note()

        self._rows = rows or []
        self._crs_authid = crs.authid() if crs is not None else ""
        self._busy = True
        self.page_list.clear()
        for r in self._rows:
            it = QListWidgetItem("Page %d   —   %s" % (r["n"], _summarise(r.get("counts"))))
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(_CHECKED)
            it.setData(_USER_ROLE, r["n"])
            self.page_list.addItem(it)
        self._busy = False
        if not self._rows:
            self.status.setText(
                "No pages. Nothing ticked above has features to tile — tick the layers "
                "this drawing is about.")
        self._refresh_status()

    # ── interaction ───────────────────────────────────────────────────────
    def _on_layer_toggled(self, _item):
        if self._busy:
            return
        self._reload_pages()

    def _on_page_toggled(self, _item):
        if self._busy:
            return
        self._refresh_status()

    def _set_all_pages(self, on):
        self._busy = True
        for i in range(self.page_list.count()):
            self.page_list.item(i).setCheckState(_CHECKED if on else _UNCHECKED)
        self._busy = False
        self._refresh_status()

    def _kept_rows(self):
        keep = set()
        for i in range(self.page_list.count()):
            it = self.page_list.item(i)
            if it.checkState() == _CHECKED:
                keep.add(it.data(_USER_ROLE))
        return [r for r in self._rows if r["n"] in keep]

    def _refresh_status(self):
        kept = self._kept_rows()
        total = len(self._rows)
        self.pages_lbl.setText("Pages — untick any you do not want")
        if total:
            dropped = total - len(kept)
            msg = "%d page%s will print" % (len(kept), "" if len(kept) == 1 else "s")
            if dropped:
                msg += "  ·  %d dropped" % dropped
            msg += "  ·  they renumber 1…%d in the drawing" % len(kept)
            self.status.setText(msg)
        self._ok.setEnabled(bool(kept))

    # ── result ────────────────────────────────────────────────────────────
    def accept(self):
        if not self._kept_rows():
            QMessageBox.warning(self, "Nothing to print",
                                "Every page is unticked. Tick at least one, or Cancel.")
            return
        super().accept()

    def result_cfg(self):
        """The three keys the engine needs: the layer choice, and the approved cells."""
        kept = self._kept_rows()
        return {
            "grid_content_layer_ids": self._chosen_layer_ids(),
            "grid_cells_wkt": [r["wkt"] for r in kept],
            "grid_cells_crs": self._crs_authid,
        }


def choose_grid_coverage(parent, hld_cfg):
    """Show the dialog. Returns the cfg keys to merge, or None if the operator cancelled.

    On any failure to even plan the grid, returns {} — the caller carries on with the
    engine's own derivation rather than blocking an export over a preview.
    """
    try:
        dlg = GridCoverageDialog(parent, hld_cfg)
    except Exception:
        print("grid coverage dialog could not open\n" + traceback.format_exc())
        return {}
    if dlg.exec() != QDialog.DialogCode.Accepted:
        return None
    return dlg.result_cfg()
