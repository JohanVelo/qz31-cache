"""Generate a finished HeroTel wayleave from a hand-drawn one.

The planner draws feeder, link and distribution cables, one 1:16 per PON, PONs and a POP.
This engine adds, without moving anything the planner drew:

* vertices where a cable end or a 1:16 sits on another cable's segment (T-joints),
* vertices so no pole-to-pole gap is longer than ``max_span`` (70 m, JJ 2026-10-23),
* a pole on every vertex (vertices closer than ``pole_merge`` share one pole),
* the Span layer: every cable merged into continuous lines, cut only at junctions,
* every attribute table, numbered by walking the network from the POP (Vrede convention).

Pure python + stdlib (see geom.py): nothing here imports QGIS, so the acceptance harness
runs headless. Inputs and outputs are plain dicts; ``qgis_io`` (plugin side) reads and
writes the layers.

Proven against the Deneysville wayleave of 2026-10-23 (research/wayleave_verify).
"""
from __future__ import annotations

import math
from collections import defaultdict

from .geom import (Area, PointIndex, SegIndex, dijkstra, dist, line_length, path_edges,
                   point_at, seg_intersection, seg_project, turn_deg)

DEFAULTS = dict(
    max_span=70.0,       # m, longest pole-to-pole gap
    snap=0.5,            # m, an end / 1:16 this close to another cable is a joint on it
    pole_merge=0.5,      # m, vertices this close are one pole
    near_pole=3.0,       # m, two poles closer than this (but apart) are flagged
    turn_big=45.0,       # deg, turn above this -> 120-140mm pole (Vrede R29)
    s16_reach=3.0,       # m, a distribution cable starting this close to a 1:16 is fed by it
    crossing_dedupe=10.0,  # m, road-crossing points closer than this count once
    sizes=(12, 24, 48, 72, 96, 144),
    dc_size='24F',
    prefix='HT', town='XXX',
    dp_types=('CellTower', 'Church', 'FTTB SDU', 'School', 'SDU', 'Vacant'),
)
TRANSPORT = ('F', 'L')


class WayleaveError(Exception):
    """The drawing cannot be finished as it stands; the message says what to fix."""


def _opts(opts):
    o = dict(DEFAULTS); o.update(opts or {}); return o


# ── reading helpers shared with checks.py ───────────────────────────────────────

class Net:
    """The drawn wayleave in metric coordinates, plus lookups used by checks and finish."""

    def __init__(self, inp, opts=None):
        self.o = _opts(opts)
        # a fixed order, so the result never depends on the order QGIS hands the features over
        kind_rank = {'F': 0, 'L': 1, 'D': 2}
        inp = dict(inp, cables=sorted(inp['cables'], key=lambda c: (kind_rank[c['kind']], c['fid'])),
                   s16=sorted(inp['s16'], key=lambda s: s['fid']), dps=sorted(inp.get('dps') or [], key=lambda d: d['fid']),
                   pons=sorted(inp['pons'], key=lambda p: p['fid']))
        self.inp = inp
        self.cables = inp['cables']
        self.pons = [dict(p, area=p['area'] if isinstance(p['area'], Area) else Area(p['area'])) for p in inp['pons']]
        self.s16 = inp['s16']
        self.pop = inp.get('pop')
        self.roads = inp.get('roads') or []
        self.dps = inp.get('dps') or []
        self.road_idx = SegIndex(50.0)
        for ri, r in enumerate(self.roads):
            for a, b in zip(r[:-1], r[1:]):
                self.road_idx.add(ri, a, b)

    def pon_at(self, p):
        """Index of the PON containing p, else the nearest one."""
        hits = [i for i, q in enumerate(self.pons) if q['area'].contains(p)]
        if hits:
            return hits[0]
        return min(range(len(self.pons)), key=lambda i: self.pons[i]['area'].distance(p)) if self.pons else None

    @staticmethod
    def cable_distance(c, p):
        return min(seg_project(a, b, p)[0] for part in c['parts_m'] for a, b in zip(part[:-1], part[1:]))

    @staticmethod
    def cable_mid(c):
        parts = c['parts_m']; total = sum(line_length(q) for q in parts); want = total / 2.0
        for q in parts:
            L = line_length(q)
            if want <= L and L > 0:
                return point_at(q, want / L)
            want -= L
        return parts[-1][-1]

    @staticmethod
    def cable_ends(c):
        return [part[e] for part in c['parts_m'] for e in (0, -1)]

    def dcs(self):
        return [c for c in self.cables if c['kind'] == 'D']

    def s16_pon_map(self):
        """For each 1:16: the distribution cables that start on it, and their PONs. A cable belongs to the
        1:16 nearest its start (two PONs' 1:16s can share a pole, a few metres apart)."""
        dcs = self.dcs(); fed = {id(s): [] for s in self.s16}
        for c in dcs:
            best = None
            for s in self.s16:
                d = min(dist(e, s['m']) for e in self.cable_ends(c))
                if d < self.o['s16_reach'] and (best is None or d < best[0]):
                    best = (d, s)
            if best is not None:
                fed[id(best[1])].append(c)
        return [dict(s16=s, dcs=fed[id(s)], pons=sorted({self.pon_at(self.cable_mid(c)) for c in fed[id(s)]})) for s in self.s16]

    def crossings(self, c):
        pts = []
        for part in c['parts_m']:
            for a, b in zip(part[:-1], part[1:]):
                for _, ra, rb in self.road_idx.box(a, b):
                    x = seg_intersection(a, b, ra, rb)
                    if x is not None and all(dist(x, q) > self.o['crossing_dedupe'] for q in pts):
                        pts.append(x)
        return len(pts)


def size_for(n, sizes):
    need = 2 * n
    return next((s for s in sizes if s >= need), None)


# ── the generator ──────────────────────────────────────────────────────────────

def finish(inp, opts=None, progress=None):
    """Return dict(cables, poles, spans, attrs, issues, summary). Raises WayleaveError on a
    drawing that cannot be numbered (run checks.check() first; Generate refuses on errors)."""
    net = Net(inp, opts); o = net.o
    say = progress or (lambda pct, msg: None)
    issues = []
    # parts as mutable pairs of coordinate lists (layer CRS, metric)
    P = []
    for ci, c in enumerate(net.cables):
        for pi, (pl, pm) in enumerate(zip(c['parts_l'], c['parts_m'])):
            P.append(dict(ci=ci, kind=c['kind'], L=[tuple(v) for v in pl], M=[tuple(v) for v in pm]))
    orig = [list(p['L']) for p in P]
    say(5, 'Finding joints')
    # 1) joints: a cable end, or a 1:16, lying on another cable's segment gets a vertex there
    seg_idx = SegIndex(50.0)
    for k, p in enumerate(P):
        for i, (a, b) in enumerate(zip(p['M'][:-1], p['M'][1:])):
            seg_idx.add((k, i), a, b)
    req = defaultdict(list)   # part -> [(seg, t)]

    def want_vertex(pt, skip_part=None, only_kinds=None):
        best = {}
        for (k, i), a, b in seg_idx.near(pt, o['snap']):
            if k == skip_part or (only_kinds and P[k]['kind'] not in only_kinds):
                continue
            d, t = seg_project(a, b, pt)
            if d <= o['snap'] and (k not in best or d < best[k][0]):
                best[k] = (d, i, t, dist(a, b))
        for k, (d, i, t, L) in best.items():
            if t * L <= o['pole_merge'] or (1 - t) * L <= o['pole_merge']:
                continue   # already at a vertex
            req[k].append((i, t))

    for k, p in enumerate(P):
        for e in (p['M'][0], p['M'][-1]):
            want_vertex(e, skip_part=k)
    for s in net.s16:
        want_vertex(s['m'], only_kinds=TRANSPORT)
    added_joint = 0
    for k, reqs in req.items():
        p = P[k]; by_seg = defaultdict(list)
        for i, t in reqs:
            by_seg[i].append(t)
        for i in sorted(by_seg, reverse=True):
            a_l, b_l, a_m, b_m = p['L'][i], p['L'][i + 1], p['M'][i], p['M'][i + 1]
            L = dist(a_m, b_m); ts = []
            for t in sorted(by_seg[i]):
                if not ts or (t - ts[-1]) * L > o['pole_merge']:
                    ts.append(t)
            newl = [(a_l[0] + (b_l[0] - a_l[0]) * t, a_l[1] + (b_l[1] - a_l[1]) * t) for t in ts]
            newm = [(a_m[0] + (b_m[0] - a_m[0]) * t, a_m[1] + (b_m[1] - a_m[1]) * t) for t in ts]
            p['L'][i + 1:i + 1] = newl; p['M'][i + 1:i + 1] = newm; added_joint += len(ts)
    say(15, 'Adding vertices on long gaps')
    # 2) no gap longer than max_span: split long segments evenly
    added_span = 0
    for p in P:
        L2, M2 = [p['L'][0]], [p['M'][0]]
        for (al, bl), (am, bm) in zip(zip(p['L'][:-1], p['L'][1:]), zip(p['M'][:-1], p['M'][1:])):
            n = math.ceil(dist(am, bm) / o['max_span'] - 1e-9)
            for j in range(1, n):
                t = j / n
                L2.append((al[0] + (bl[0] - al[0]) * t, al[1] + (bl[1] - al[1]) * t))
                M2.append((am[0] + (bm[0] - am[0]) * t, am[1] + (bm[1] - am[1]) * t)); added_span += 1
            L2.append(bl); M2.append(bm)
        p['L'], p['M'] = L2, M2
    # proof: every vertex the planner drew is still there, unchanged, in order
    for p, o_l in zip(P, orig):
        it = iter(p['L'])
        if not all(any(v == w for w in it) for v in o_l):
            raise WayleaveError('Internal check failed: a drawn vertex would move. Nothing was written.')
    say(25, 'Placing poles')
    # 3) poles: one per vertex, vertices within pole_merge share one (a transport vertex wins)
    def place_poles():
        verts = []   # (part, idx)
        for k, p in enumerate(P):
            for j in range(len(p['M'])):
                verts.append((k, j))
        order = sorted(range(len(verts)), key=lambda v: 0 if P[verts[v][0]]['kind'] in TRANSPORT else 1)
        vidx = PointIndex([P[k]['M'][j] for k, j in verts], cell=1.0)
        taken = [False] * len(verts); vpole = {}; poles = []
        for v in order:
            if taken[v]:
                continue
            k, j = verts[v]; grp = [g for g in vidx.within(P[k]['M'][j], o['pole_merge']) if not taken[g]] or [v]
            if v not in grp:
                grp.append(v)
            pid = len(poles)
            for g in grp:
                taken[g] = True; vpole[verts[g]] = pid
            turn = 0.0
            for g in grp:
                gk, gj = verts[g]; M = P[gk]['M']
                if 0 < gj < len(M) - 1:
                    turn = max(turn, turn_deg(M[gj - 1], M[gj], M[gj + 1]))
            poles.append(dict(l=P[k]['L'][j], m=P[k]['M'][j], transport=any(P[verts[g][0]]['kind'] in TRANSPORT for g in grp), turn=turn))
        return vpole, poles
    # merging two vertices can stretch a neighbouring gap past max_span by up to pole_merge: give any such
    # gap one more vertex (on the segment, so nothing moves) and place the poles again
    vpole, poles = {}, []
    for _round in range(7):
        vpole, poles = place_poles(); long_gaps = []
        for k, p in enumerate(P):
            for j in range(len(p['M']) - 1):
                a, b = vpole[(k, j)], vpole[(k, j + 1)]
                if a != b and dist(poles[a]['m'], poles[b]['m']) > o['max_span'] + 1e-9:
                    long_gaps.append((k, j))
        if not long_gaps or _round == 6:   # the last round only places poles, so vpole always matches P
            break
        for k, j in sorted(long_gaps, reverse=True):
            p = P[k]; al, bl, am, bm = p['L'][j], p['L'][j + 1], p['M'][j], p['M'][j + 1]
            p['L'].insert(j + 1, ((al[0] + bl[0]) / 2, (al[1] + bl[1]) / 2)); p['M'].insert(j + 1, ((am[0] + bm[0]) / 2, (am[1] + bm[1]) / 2))
            added_span += 1
    pidx = PointIndex([p['m'] for p in poles], cell=3.0)
    for a, p in enumerate(poles):
        for b in pidx.within(p['m'], o['near_pole']):
            if b > a and dist(p['m'], poles[b]['m']) > o['pole_merge']:
                issues.append(dict(level='warn', code='close_poles', at=p['m'],
                                   msg=f"Two poles {dist(p['m'], poles[b]['m']):.1f} m apart: two cables have vertices side by side. If it is one pole, snap one vertex onto the other."))
    say(35, 'Checking spans and road crossings')
    # 4) pole-to-pole spans: longest, and road crossings (both end poles 7.2 m)
    tall = set(); span_max = 0.0; edges = []   # (pa, pb, metres, cable index, kind)
    for k, p in enumerate(P):
        for j in range(len(p['M']) - 1):
            a, b = vpole[(k, j)], vpole[(k, j + 1)]
            if a == b:
                continue
            L = dist(poles[a]['m'], poles[b]['m']); span_max = max(span_max, L)
            edges.append((a, b, L, p['ci'], p['kind']))
            ma, mb = p['M'][j], p['M'][j + 1]
            if any(seg_intersection(ma, mb, ra, rb) is not None for _, ra, rb in net.road_idx.box(ma, mb)):
                tall.add(a); tall.add(b)
    # 5) Span: the pole graph merged into continuous lines, cut only at junctions and ends
    adj = defaultdict(set)
    for a, b, *_ in edges:
        adj[a].add(b); adj[b].add(a)
    seen = set(); chains = []

    def walk(a, b):
        path = [a, b]; seen.add(frozenset((a, b)))
        while len(adj[path[-1]]) == 2:
            nxt = next(x for x in adj[path[-1]] if x != path[-2])
            if frozenset((path[-1], nxt)) in seen:
                break
            seen.add(frozenset((path[-1], nxt))); path.append(nxt)
        return path
    for a in sorted(adj, key=lambda i: (len(adj[i]) == 2, i)):
        for b in sorted(adj[a]):
            if frozenset((a, b)) not in seen:
                chains.append(walk(a, b))
    spans = []
    for ch in sorted(chains, key=lambda ch: (-poles[ch[0]]['l'][1], poles[ch[0]]['l'][0])):
        spans.append(dict(l=[poles[i]['l'] for i in ch], m=[poles[i]['m'] for i in ch],
                          length=round(line_length([poles[i]['m'] for i in ch]), 2)))
    for n, s in enumerate(spans):
        s['attrs'] = {'Name': f'Span {n + 1}', 'Length': s['length']}
    say(45, 'Walking the network from the POP')
    # 6) attributes, walked from the POP
    cables_new = [dict(c, parts_l=[], parts_m=[]) for c in net.cables]
    for p in P:
        cables_new[p['ci']]['parts_l'].append(p['L']); cables_new[p['ci']]['parts_m'].append(p['M'])
    net2 = Net(dict(inp, cables=cables_new), o)
    if o.get('attributes', True):
        attrs = _walk(net2, poles, vpole, P, edges, tall, issues, o, say)
    else:   # geometry only (used by the town-by-town accuracy harness on drawings Check would refuse)
        attrs = {'_summary': {}}
    say(95, 'Done')
    summary = dict(vertices_added_joint=added_joint, vertices_added_span=added_span, poles=len(poles),
                   poles_transport=sum(p['transport'] for p in poles), spans=len(spans),
                   span_km=round(sum(s['length'] for s in spans) / 1000, 3), pole_to_pole_max=round(span_max, 2),
                   close_pole_pairs=sum(1 for i in issues if i['code'] == 'close_poles'))
    summary.update(attrs.pop('_summary'))
    return dict(cables=cables_new, poles=poles, spans=spans, attrs=attrs, issues=issues, summary=summary)


def _walk(net, poles, vpole, P, edges, tall, issues, o, say):
    cables = net.cables
    nearest_pole = PointIndex([p['m'] for p in poles], cell=3.0)
    pole_of = lambda pt: nearest_pole.nearest(pt)
    F = [i for i, c in enumerate(cables) if c['kind'] == 'F']
    L = [i for i, c in enumerate(cables) if c['kind'] == 'L']
    D = [i for i, c in enumerate(cables) if c['kind'] == 'D']
    if not F:
        raise WayleaveError('There is no feeder cable. Draw the feeder from the POP first.')
    if net.pop is None:
        raise WayleaveError('There is no POP point. Add the POP before generating.')
    # transport graph + a virtual POP joined to each feeder's POP end
    tadj = defaultdict(list); fadj = defaultdict(list)
    for a, b, w, ci, kind in edges:
        for x, y in ((a, b), (b, a)):
            fadj[x].append((y, w, (kind, ci)))
            if kind in TRANSPORT:
                tadj[x].append((y, w, (kind, ci)))
    fstart = {}
    for fi in F:
        fstart[fi] = pole_of(min(net.cable_ends(cables[fi]), key=lambda q: dist(q, net.pop)))
        tadj['POP'].append((fstart[fi], 0.0, ('P', fi))); fadj['POP'].append((fstart[fi], 0.0, ('P', fi)))
    tdist, tprev = dijkstra(tadj, {'POP': 0.0})

    def feeder_of(pole):
        # the first feeder cable on the way out of the POP (feeders often share the POP pole,
        # so the virtual POP edge alone cannot tell them apart)
        e = [d for d in reversed(path_edges(tprev, pole)) if d[0] == 'F']
        if e:
            return e[0][1]
        return next((fi for fi, s in fstart.items() if s == pole), F[0])
    forder = sorted(F, key=lambda i: -sum(line_length(q) for q in cables[i]['parts_m']))
    fno = {fi: f'FC{k + 1:02d}' for k, fi in enumerate(forder)}
    # 1:16 -> PON (one each), position on the walk
    s16 = []
    for row in net.s16_pon_map():
        s = row['s16']
        if len(row['pons']) != 1:
            raise WayleaveError(f"A 1:16 feeds {len(row['pons'])} PONs (needs exactly 1). Run Check My Wayleave.")
        pole = pole_of(s['m'])
        if pole not in tdist:
            raise WayleaveError('A 1:16 is not connected to the POP through feeder/link cables. Run Check My Wayleave.')
        s16.append(dict(s=s, pon=row['pons'][0], pole=pole, dist=tdist[pole], feeder=feeder_of(pole)))
    if len({x['pon'] for x in s16}) != len(s16) or len(s16) != len(net.pons):
        raise WayleaveError(f'{len(s16)} 1:16s for {len(net.pons)} PONs: every PON needs exactly one. Run Check My Wayleave.')
    s16.sort(key=lambda x: (forder.index(x['feeder']), x['dist']))
    ponno = {x['pon']: f'{k + 1:02d}' for k, x in enumerate(s16)}
    carried = defaultdict(int)
    for x in s16:
        for ci in {d[1] for d in path_edges(tprev, x['pole']) if d[0] in TRANSPORT}:
            carried[ci] += 1
    # links: numbered by the walk position of their start (the end nearest the POP)
    lstart = {}
    for li in L:
        ends = [pole_of(e) for e in net.cable_ends(cables[li])]
        reach = [e for e in ends if e in tdist]
        if not reach:
            raise WayleaveError('A link cable is not connected to a feeder or another link. Run Check My Wayleave.')
        lstart[li] = min(reach, key=lambda e: tdist[e])
    lorder = sorted(L, key=lambda li: (forder.index(feeder_of(lstart[li])), tdist[lstart[li]]))
    lno = {li: f'LC{k + 1:02d}' for k, li in enumerate(lorder)}
    s16pts = [x['s']['m'] for x in s16]
    out = defaultdict(dict); pre = f"{o['prefix']}_{o['town']}"

    def transport(ci, no, kind):
        n = carried.get(ci, 0); sz = size_for(n, o['sizes'])
        if sz is None:
            sz = o['sizes'][-1]
            issues.append(dict(level='error', code='oversize', at=cables[ci]['parts_m'][0][0],
                               msg=f'{no} carries {n} PONs: more than {sz}F allows. Split it into two cables.'))
        joints = sum(1 for q in s16pts if net.cable_distance(cables[ci], q) < o['snap'])
        x = net.crossings(cables[ci]); length = sum(line_length(q) for q in cables[ci]['parts_m'])
        return {'Type': 'Feeder' if kind == 'F' else 'Link', 'Name': f'{pre}_{no}_{sz}F_Aerial', 'Cable No': no,
                'Lenght': round(length, 2), 'SLenght': float(20 + 20 * joints + 29 * x), 'Cable Size': f'{sz}F'}
    for fi in F:
        out['feeder'][cables[fi]['fid']] = transport(fi, fno[fi], 'F')
    for li in L:
        out['link'][cables[li]['fid']] = transport(li, lno[li], 'L')
    say(60, 'Numbering distribution cables')
    # distribution: PON by its middle; Distribution if it starts on the PON's 1:16, else Spur
    s16_of = {x['pon']: x for x in s16}
    for x in s16:
        x['dl'] = dijkstra(fadj, {x['pole']: 0.0})[0]
    rows = []
    for di in D:
        c = cables[di]; k = net.pon_at(net.cable_mid(c)); x = s16_of[k]
        main = min(dist(e, x['s']['m']) for e in net.cable_ends(c)) < o['s16_reach']
        start = min((x['dl'].get(vpole[(pk, j)], 1e12) for pk, p in enumerate(P) if p['ci'] == di for j in range(len(p['M']))), default=1e12)
        rows.append((ponno[k], not main, start, di, main, k))
    rows.sort()
    for n, (pn, _, _, di, main, k) in enumerate(rows):
        c = cables[di]; no = f'DC{n + 1:03d}'
        out['dc'][c['fid']] = {'Name': f"{pre}_{no}_{o['dc_size']}_Aerial", 'Type': 'Distribution' if main else 'Spur',
                               'Cable_No': no, 'Lenght': round(sum(line_length(q) for q in c['parts_m']), 2),
                               'SLenght': float(15 + 29 * net.crossings(c)), 'Cable Size': o['dc_size'], 'PON': pn}
    say(75, 'Numbering poles')
    dall = dijkstra(fadj, {'POP': 0.0})[0]
    prow = sorted(range(len(poles)), key=lambda i: (ponno[net.pon_at(poles[i]['m'])], dall.get(i, 1e12), i))
    pid = {}
    for n, i in enumerate(prow):
        p = poles[i]; pid[i] = f'{n + 1:04d}PL'
        p['attrs'] = {'Size': '120-140mm' if p['turn'] > o['turn_big'] else '100-120mm',
                      'Length': '7.2m' if (p['transport'] or i in tall) else '5.4m',
                      'Name': f'{pre}_{pid[i]}', 'Pole Role': 'Feeder' if p['transport'] else 'Distribution',
                      'Pole ID': pid[i], 'PON': ponno[net.pon_at(p['m'])], 'Drop Pole': 'No'}
    for x in s16:
        out['s16'][x['s']['fid']] = {'Type': '16 Way Splitter', 'Splitter': '1:16', 'Name': f"PON {ponno[x['pon']]} 1:16",
                                     'Pole ID': pid[x['pole']], 'PON': ponno[x['pon']]}
    say(85, 'Counting homes per PON')
    cnt = defaultdict(lambda: defaultdict(int)); other = 0
    for dp in net.dps:
        k = net.pon_at(dp['m']); out['dps'][dp['fid']] = {'PON': ponno[k]}
        t = dp.get('type') or 'SDU'
        if t not in o['dp_types']:
            other += 1; t = 'SDU'
        cnt[k][t] += int(dp.get('count') or 1)
    if other:
        issues.append(dict(level='info', code='dp_type', at=None, msg=f'{other} demand points have an unknown Type; counted as SDU.'))
    for k, q in enumerate(net.pons):
        c = cnt[k]; homes = sum(c.values())
        desc = ' , '.join(f'{c.get(t, 0)} x {t}' for t in o['dp_types'])
        out['pons'][q['fid']] = {'PON': ponno[k], 'Discriptio': desc, 'Home_Count': float(homes), '8Way Split': str(math.ceil(homes / 8))}
    out['_summary'] = dict(pons=len(ponno), feeders={fno[i]: out['feeder'][cables[i]['fid']]['Cable Size'] for i in F},
                           links=len(L), distribution=sum(1 for r in rows if r[4]), spurs=sum(1 for r in rows if not r[4]),
                           poles_7_2=sum(1 for p in poles if p['attrs']['Length'] == '7.2m'), demand_points=len(net.dps))
    return dict(out)
