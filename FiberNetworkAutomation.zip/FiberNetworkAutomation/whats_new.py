"""Premium "What's New" board — shown after an in-place update so the operator
sees EVERYTHING that changed since their previous version, not a one-line bar.

Mission-Control look (matches the Nexus panel): near-black console, electric cyan,
green/amber/cyan category chips, mono version pills. Fully self-styled (explicit
bg + colours on every label) so it reads correctly in QGIS LIGHT mode too — never
inherits the host palette half-way.

Public entry point: show_whats_new(before_version, now_version, parent=None).
Reads the bundled metadata.txt changelog, lists every entry in
(before, now], groups each as NEW / FIXED / IMPROVED. Degrade-not-crash — any
failure just skips the board (the update already succeeded).
"""
import os
import re

# ── palette (Mission Control, self-contained so the dialog never depends on theme) ─
_BG       = "#05070C"   # near-black console base
_PANEL    = "#0D1320"   # card / cell
_BORDER   = "#1B2740"
_INK      = "#E8EEF8"   # primary text
_SUB      = "#8A9BB8"   # secondary text
_CYAN     = "#1AE5FF"   # electric cyan accent
_GREEN    = "#3DFF9A"
_AMBER    = "#FFB020"
_DARKINK  = "#04070D"   # dark text on bright chips

# category → (label, colour). Order of detection matters (most specific first).
_CATS = {
    "fixed":    ("FIXED",    _CYAN),
    "new":      ("NEW",      _GREEN),
    "improved": ("IMPROVED", _AMBER),
}


def _meta_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "metadata.txt")


def _vtuple(s):
    try:
        return tuple(int(x) for x in re.findall(r"\d+", s)[:4])
    except Exception:
        return (0,)


def parse_changelog(text):
    """Return [(vtuple, 'x.y.z', body_text), ...] newest-first from a metadata
    changelog block. Entries start at an indented '  x.y.z - ...'; continuation
    lines (indented, no leading version) fold into the current entry."""
    lines = text.splitlines()
    # isolate the changelog= block: the value line + following indented lines
    block = []
    grabbing = False
    for ln in lines:
        if ln.startswith("changelog="):
            grabbing = True
            block.append(ln[len("changelog="):])
            continue
        if grabbing:
            if ln.strip() == "" or ln[:1] in (" ", "\t"):
                block.append(ln)
            else:
                break
    entries = []
    cur = None
    head = re.compile(r"^\s*(\d+\.\d+(?:\.\d+){0,2})\s*[-–]\s*(.*)$")
    for ln in block:
        m = head.match(ln)
        if m:
            if cur:
                entries.append(cur)
            cur = [_vtuple(m.group(1)), m.group(1), m.group(2).strip()]
        elif cur is not None and ln.strip():
            cur[2] = (cur[2] + " " + ln.strip()).strip()
    if cur:
        entries.append(cur)
    return entries


def changes_between(entries, before, now):
    """Entries with before < version <= now, newest-first."""
    bt, nt = _vtuple(before), _vtuple(now)
    out = [e for e in entries if e[0] > bt and e[0] <= nt]
    out.sort(key=lambda e: e[0], reverse=True)
    return out


def categorize(text):
    t = text.lower()
    if any(k in t for k in ("fix", "fixed", "no longer", "crash", "leak", "hang",
                            "freeze", "broke", "regression")):
        return _CATS["fixed"]
    if any(k in t for k in ("new ", "added", "now in", "introduc", "now reads",
                            "now shows", "now offers", "first ", "design")):
        return _CATS["new"]
    return _CATS["improved"]


def _load_entries():
    try:
        with open(_meta_path(), encoding="utf-8") as f:
            return parse_changelog(f.read())
    except Exception:
        return []


def show_whats_new(before, now, parent=None):
    """Show the board for changes in (before, now]. No-op (returns False) if there
    is nothing new or the UI can't be built. Never raises."""
    try:
        entries = changes_between(_load_entries(), before, now)
        if not entries:
            return False
        dlg = WhatsNewDialog(before, now, entries, parent=parent)
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()
        # keep a ref so it isn't GC'd while shown (modeless)
        global _LIVE_DLG
        _LIVE_DLG = dlg
        return True
    except Exception:
        return False


_LIVE_DLG = None


try:
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (QDialog, QFrame, QHBoxLayout, QLabel,
                                     QPushButton, QScrollArea, QVBoxLayout, QWidget)

    class WhatsNewDialog(QDialog):
        def __init__(self, before, now, entries, parent=None):
            super().__init__(parent)
            self.setWindowTitle("What's New — Velocity Nexus")
            self.setModal(False)
            self.setMinimumWidth(540)
            self.setMinimumHeight(560)
            self.setStyleSheet(f"QDialog {{ background:{_BG}; }}")

            root = QVBoxLayout(self)
            root.setContentsMargins(0, 0, 0, 0)
            root.setSpacing(0)

            self._entries = entries
            root.addWidget(self._header(before, now, len(entries)))

            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setFrameShape(QFrame.Shape.NoFrame)
            scroll.setStyleSheet(
                f"QScrollArea{{background:{_BG};border:none;}}"
                f"QScrollBar:vertical{{background:{_BG};width:10px;margin:0;}}"
                f"QScrollBar::handle:vertical{{background:{_BORDER};border-radius:5px;min-height:30px;}}"
                f"QScrollBar::add-line,QScrollBar::sub-line{{height:0;}}")
            body = QWidget()
            body.setStyleSheet(f"background:{_BG};")
            bl = QVBoxLayout(body)
            bl.setContentsMargins(18, 6, 18, 18)
            bl.setSpacing(10)
            for vt, vs, txt in entries:
                bl.addWidget(self._card(vs, txt))
            bl.addStretch(1)
            scroll.setWidget(body)
            root.addWidget(scroll, 1)

            root.addWidget(self._footer())
            try:
                from .nexus_dock import chrome_dialog
                chrome_dialog(self, "VELOCITY NEXUS  //  WHAT'S NEW")
            except Exception:
                pass

        def _header(self, before, now, n):
            h = QFrame()
            h.setStyleSheet(
                f"QFrame{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,"
                f"stop:0 #0B1019, stop:1 #070A11); border-bottom:1px solid {_BORDER};}}")
            lay = QVBoxLayout(h)
            lay.setContentsMargins(22, 18, 22, 16)
            lay.setSpacing(3)
            kicker = QLabel('<span style="color:#EF4444;font-size:14px;">&#9822;</span>'
                            '&nbsp;&nbsp;VELOCITY NEXUS')
            kicker.setTextFormat(Qt.TextFormat.RichText)
            kicker.setStyleSheet(
                f"color:{_CYAN};font-family:'Consolas','JetBrains Mono',monospace;"
                f"font-size:10px;font-weight:700;letter-spacing:2px;background:transparent;")
            title = QLabel("What's New")
            title.setStyleSheet(
                f"color:{_INK};font-family:'Segoe UI';font-size:24px;font-weight:800;"
                f"letter-spacing:0.5px;background:transparent;")
            jump = "you're now up to date" if _vtuple(before) <= (0,) else \
                   f"v{before}  →  v{now}"
            sub = QLabel(f"{jump}   ·   {n} update{'s' if n != 1 else ''}")
            sub.setStyleSheet(
                f"color:{_SUB};font-family:'Segoe UI';font-size:12px;"
                f"font-weight:600;background:transparent;")
            lay.addWidget(kicker)
            lay.addWidget(title)
            lay.addWidget(sub)
            # at-a-glance category summary (e.g. "20 Fixed · 7 New · 23 Improved")
            from collections import Counter
            counts = Counter(categorize(t)[0] for _, _, t in getattr(self, "_entries", []))
            order = [("NEW", _GREEN), ("FIXED", _CYAN), ("IMPROVED", _AMBER)]
            chips = [(lbl, col, counts[lbl]) for lbl, col in order if counts.get(lbl)]
            if chips:
                row = QHBoxLayout()
                row.setSpacing(6)
                row.setContentsMargins(0, 7, 0, 0)
                for lbl, col, c in chips:
                    chip = QLabel(f"{c} {lbl.title()}")
                    chip.setStyleSheet(
                        f"color:{col};background:transparent;border:1px solid {col};"
                        f"border-radius:9px;padding:1px 9px;font-family:'Segoe UI';"
                        f"font-size:10px;font-weight:700;")
                    row.addWidget(chip, 0)
                row.addStretch(1)
                lay.addLayout(row)
            return h

        def _card(self, version, text):
            label, colour = categorize(text)
            card = QFrame()
            card.setStyleSheet(
                f"QFrame{{background:{_PANEL};border:1px solid {_BORDER};"
                f"border-left:3px solid {colour};border-radius:8px;}}")
            lay = QVBoxLayout(card)
            lay.setContentsMargins(14, 12, 14, 12)
            lay.setSpacing(8)

            top = QHBoxLayout()
            top.setSpacing(8)
            chip = QLabel(label)
            chip.setStyleSheet(
                f"color:{_DARKINK};background:{colour};border-radius:4px;"
                f"padding:2px 8px;font-family:'Segoe UI';font-size:10px;"
                f"font-weight:800;letter-spacing:1px;")
            pill = QLabel(f"v{version}")
            pill.setStyleSheet(
                f"color:{_CYAN};background:transparent;"
                f"font-family:'Consolas','JetBrains Mono',monospace;"
                f"font-size:11px;font-weight:700;")
            top.addWidget(chip, 0)
            top.addWidget(pill, 0)
            top.addStretch(1)
            lay.addLayout(top)

            body = QLabel(text)
            body.setWordWrap(True)
            body.setStyleSheet(
                f"color:{_INK};background:transparent;font-family:'Segoe UI';"
                f"font-size:13px;font-weight:500;line-height:140%;")
            lay.addWidget(body)
            return card

        def _footer(self):
            f = QFrame()
            f.setStyleSheet(f"QFrame{{background:{_BG};border-top:1px solid {_BORDER};}}")
            lay = QHBoxLayout(f)
            lay.setContentsMargins(18, 12, 18, 14)
            tip = QLabel("Tip: tap the ⚡ logo to switch themes")
            tip.setStyleSheet(f"color:{_SUB};background:transparent;font-size:11px;")
            btn = QPushButton("Got it")
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setStyleSheet(
                f"QPushButton{{background:{_CYAN};color:{_DARKINK};border:none;"
                f"border-radius:6px;padding:8px 22px;font-family:'Segoe UI';"
                f"font-size:13px;font-weight:800;}}"
                f"QPushButton:hover{{background:#5BF0FF;}}"
                f"QPushButton:pressed{{background:#13C6DE;}}")
            btn.clicked.connect(self.accept)
            lay.addWidget(tip, 1)
            lay.addWidget(btn, 0)
            return f

except Exception:        # Qt unavailable (headless/tests) — parsing still importable
    WhatsNewDialog = None
