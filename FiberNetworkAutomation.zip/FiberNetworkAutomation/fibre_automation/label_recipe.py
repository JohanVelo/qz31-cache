"""Label My Network — reference-composition engine ("recipe per layer").

The operator places every feature, then labels at the END.  Each layer has a
RECIPE: a template whose tokens are resolved from the feature itself, from
project CONSTANTS, and from GEOMETRY REFERENCES to what is nearby:

    Fibertime cable   "{stack}.DF.{cblcpty}.{start}-{end}"
                      -> MOA.DF.24F.P.A423-P.A324   (start/end = nearest pole)
    Fibertime STS     "{stack}.STS.{ratio}.DIS.DM.{host}.C{card}P{port}.L{leg}"
    HeroTel cable     "{ht}{aoi}_Z{zone}_{num}_{size}_{mat}"
                      -> HT_PABA2_Z1_DC00_24F_Aerial ({num} <- field "Cab name")
    Vuma cable        "{owner}_{town}_Z{zone}_{ag}_{dc}_{cblcpty}F_ADSS_"
                      "G.657.A1_{chainage}"

This is NOT a structure walk — it mirrors how the real Velocity as-builts are
named (proven ~96% reproduction on Mohadin cables).  A cable/host reference is
found by NEAREST host (pole or manhole); pon_no/zone_no (and any custom
polygon ref such as {ag} or {zone}) by the containing polygon.

Token resolution order for a name in the template:
  1. geometry / derived ref -> {start,end,host} = short host label;
     {start_full,end_full,host_full} = full host label; {pon_no,zone_no} +
     any Recipe.poly_refs name = containing polygon value; {card}/{port}
     derived from pon_no; {polenum} = digits of the hosting pole's label;
     {chainage} = cable length window; the Recipe.sequence token when
     auto-numbering is on
  2. Recipe.field_map alias        (token -> ACTUAL field name, e.g.
                                    {num} -> "Cab name", {size} -> "Cable Size")
  3. session project constant      (stack, aoi, olt, ... — non-empty wins)
  4. Recipe.constants default      (per-recipe editable defaults)
  5. the feature's own attribute of that name (e.g. cblcpty, ratio, drop)

SEQUENCES: with Recipe.auto_number + a SequenceSpec, a feature whose number
field already holds a value USES it; empty fields get a GENERATED running
number per scope, in a deterministic order (field / x / y / spatial chain).
Generation needs the whole layer, so dry_run() does a per-layer pre-pass
(assign_sequence) before composing each feature.

Pure-python core (resolve/compose/assign_sequence/dry_run helpers) is
QGIS-free and testable; a thin lazy-QGIS layer extracts data from layers and
writes labels back.  Nothing is written until apply().
"""
import math
import re
import string

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

# metres -> degrees at SA latitudes (host snap tolerances are in metres)
DEG_PER_M = 1.0 / 102000.0

# token names resolved from geometry (everything else = constant or field)
_CABLE_REFS = {"start", "end", "start_full", "end_full"}
_POINT_REFS = {"host", "host_full"}
_POLY_REFS = {"pon_no", "zone_no"}
GEOM_REFS = _CABLE_REFS | _POINT_REFS | _POLY_REFS
# tokens that need the hosting point feature to be resolvable
_HOSTY_REFS = _POINT_REFS | {"polenum"}

_FMT = string.Formatter()


def template_tokens(template):
    """The {name} field names used in a template (ignoring literal text)."""
    return [fname for _lit, fname, _spec, _conv in _FMT.parse(template)
            if fname]


def _is_empty(v):
    """True for None / blank / QGIS NULL — 'the field has no usable value'."""
    if v is None:
        return True
    if isinstance(v, str):
        return not v.strip()
    try:
        return str(v).strip() in ("", "NULL", "None")
    except Exception:
        return False


# ---------------------------------------------------------------------------
# spatial host index (poles + manholes) — grid buckets, no external deps
# ---------------------------------------------------------------------------

def metre_scales(lat_deg):
    """(metres per degree longitude, per degree latitude) at this latitude.

    Standard WGS84 series. At Matiko (lat -23.9) this gives ~101,835 m per
    degree of LONGITUDE but ~110,757 m per degree of LATITUDE — an 8.8%
    difference that a single scale factor cannot express.
    """
    phi = math.radians(float(lat_deg))
    m_lat = (111132.92 - 559.82 * math.cos(2 * phi)
             + 1.175 * math.cos(4 * phi))
    m_lon = 111412.84 * math.cos(phi) - 93.5 * math.cos(3 * phi)
    return max(abs(m_lon), 1e-6), max(abs(m_lat), 1e-6)


class HostIndex:
    """Nearest-host lookup over point features carrying a label.

    hosts: iterable of {"label": str, "xy": (lon, lat)}.

    Distances are computed in TRUE local metres: longitude and latitude are
    scaled separately for the working latitude, so "nearest" means nearest on
    the ground.

    Why that is spelled out. This class used to rank candidates with
    ``hypot(dlon, dlat) / DEG_PER_M`` — ONE scale factor for both axes. It
    found the nearest host perfectly in that distorted space, but a degree of
    latitude is ~8.8% longer than a degree of longitude at this latitude, so a
    host to the NORTH scored closer than it really was. Measured on the Matiko
    sandbox (research/lmn_accuracy/oracle_v1.py): 145 of 9,426 drop-cable ends
    — 1.5% — named a pole that was NOT the nearest, by up to 3.9 m. Since
    {start}/{end}/{host} are exactly these references, those labels pointed a
    field tech at the wrong pole.

    ``legacy_metric=True`` restores the old single-factor behaviour for
    reproducing labels generated before the fix.
    """
    def __init__(self, hosts, cell_m=25.0, legacy_metric=False):
        self.hosts = list(hosts)
        self.source_locks = {}
        self.legacy_metric = bool(legacy_metric)
        if self.legacy_metric:
            self.mx = self.my = 1.0 / DEG_PER_M
        else:
            lats = [h["xy"][1] for h in self.hosts if h.get("xy")]
            lat0 = sum(lats) / len(lats) if lats else 0.0
            self.mx, self.my = metre_scales(lat0)
        self.cell = max(float(cell_m), 1e-6)          # metres, not degrees
        self.grid = {}
        for i, h in enumerate(self.hosts):
            self.grid.setdefault(self._cix(h["xy"]), []).append(i)

    def _m(self, xy):
        """(lon, lat) degrees -> local metres."""
        return (float(xy[0]) * self.mx, float(xy[1]) * self.my)

    def _cix(self, xy):
        x, y = self._m(xy)
        return (int(x // self.cell), int(y // self.cell))

    def nearest(self, xy, max_m=None):
        """(label, dist_m) of the truly nearest host, or (None, inf).

        Expands the grid ring by ring; stops only once the best distance found
        is <= ring*cell, because the next ring's cells are all at least that
        far away (query is inside the centre cell) -> guaranteed exact nearest.
        """
        qx, qy = self._m(xy)
        cx, cy = self._cix(xy)
        best_i, best_d2 = None, None
        proven = False
        ring = 0
        while ring <= 8:              # fast path: host within ~8 cells
            for dx in range(-ring, ring + 1):
                for dy in range(-ring, ring + 1):
                    if ring > 0 and max(abs(dx), abs(dy)) != ring:
                        continue  # only the border cells of this ring
                    for i in self.grid.get((cx + dx, cy + dy), ()):
                        hx, hy = self._m(self.hosts[i]["xy"])
                        d2 = (hx - qx) ** 2 + (hy - qy) ** 2
                        if best_d2 is None or d2 < best_d2:
                            best_d2, best_i = d2, i
            if best_i is not None and (best_d2 ** 0.5) <= ring * self.cell:
                proven = True         # no closer host possible farther out
                break
            ring += 1
        if not proven:                # sparse / far host: exact brute-force
            for i, h in enumerate(self.hosts):
                hx, hy = self._m(h["xy"])
                d2 = (hx - qx) ** 2 + (hy - qy) ** 2
                if best_d2 is None or d2 < best_d2:
                    best_d2, best_i = d2, i
        if best_i is None:
            return None, float("inf")
        d_m = best_d2 ** 0.5          # already metres — grid and ranking agree
        if max_m is not None and d_m > max_m:
            return None, d_m
        return self.hosts[best_i]["label"], d_m


def _pip(x, y, ring):
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if ((yi > y) != (yj > y)) and \
                (x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-12) + xi):
            inside = not inside
        j = i
    return inside


def polygon_value(xy, polygons):
    """Value of the first polygon (sorted by str value) containing xy."""
    for p in sorted(polygons, key=lambda p: str(p.get("value"))):
        for ring in p.get("rings", ()):
            if len(ring) >= 3 and _pip(xy[0], xy[1], ring):
                return p.get("value")
    return None


# ---------------------------------------------------------------------------
# derived-token helpers (pure python, deterministic)
# ---------------------------------------------------------------------------

def card_port(pon_no, per=16):
    """OLT (card, port) for a global pon_no: card=(pon-1)//per+1,
    port=(pon-1)%per+1.  Raises ValueError on a non-numeric / <1 pon."""
    p = int(str(pon_no).strip())
    if p < 1:
        raise ValueError("pon_no must be >= 1, got %r" % pon_no)
    per = max(int(per or 16), 1)
    return (p - 1) // per + 1, (p - 1) % per + 1


def polyline_length_m(coords):
    """Planar length of a lon/lat polyline in TRUE local metres.

    Longitude and latitude are scaled separately for the polyline's own
    latitude. The old single-factor version (hypot / DEG_PER_M) under-measured
    a north-south run by ~8.8% at South African latitudes — a 500 m feeder
    reported as ~456 m. Feeds {chainage}, so the window printed in a label is
    now the length actually walked.
    """
    if not coords or len(coords) < 2:
        return 0.0
    lat0 = sum(float(c[1]) for c in coords) / len(coords)
    mx, my = metre_scales(lat0)
    t = 0.0
    for (x0, y0), (x1, y1) in zip(coords, coords[1:]):
        dx = (float(x1) - float(x0)) * mx
        dy = (float(y1) - float(y0)) * my
        t += (dx * dx + dy * dy) ** 0.5
    return t


def chainage_value(length_m, slack_m=0.0, style="(%04dm-%04dm)"):
    """Vuma chainage window: format(length, length+slack).  Styles seen in
    real packs: "(%04dm-%04dm)" -> (0459m-0594m), "(%dm/%dm)" -> (291m/351m).
    Length is rounded UP to whole metres (with a float-noise guard)."""
    a = int(math.ceil(float(length_m) - 1e-6))
    b = a + int(round(float(slack_m)))
    return style % (a, b)


def _label_digits(label):
    """The trailing run of digits in a host label, padding kept:
    'HT_PABA2_Z1_0023PL' -> '0023';  'MOA.P.A423' -> '423'."""
    if label is None:
        return None
    runs = re.findall(r"\d+", str(label))
    return runs[-1] if runs else None


# ---------------------------------------------------------------------------
# optional sequence generator (Recipe.auto_number + SequenceSpec)
# ---------------------------------------------------------------------------

class SequenceSpec:
    """How to auto-number one token of a recipe.

    token        : the template token that carries the number (e.g. "pnum").
    scope        : other-token names whose resolved values key the counter
                   (e.g. ["zone"] -> one counter per zone; [] = one counter).
    start        : first generated number (default 1).
    pad          : zero-pad width (0 = none; letter_block defaults to 3).
    letter_block : Fibertime pole style — A001..A999 then B001.. (block=999
                   numbers per letter; letters roll A..Z, AA..).
    order_by     : "field:<name>" (sort by an existing field), "spatial"
                   (nearest-neighbour chain from the SW corner), "walk"
                   (physical network-walk order — needs feature["walk_order"]
                   from the Label-My-Network dock), "x" or "y".
    prefix       : literal prepended to generated values AND recognised on
                   existing values (e.g. "DC" -> generates "DC07"; an
                   existing "DC00" is used verbatim).
    """
    def __init__(self, token, *, scope=(), start=1, pad=0, letter_block=False,
                 order_by="y", prefix="", block=999):
        self.token = token
        self.scope = list(scope or ())
        self.start = int(start)
        self.pad = int(pad)
        self.letter_block = bool(letter_block)
        self.order_by = order_by or "y"
        self.prefix = prefix or ""
        self.block = max(int(block), 1)

    def to_dict(self):
        return {"token": self.token, "scope": list(self.scope),
                "start": self.start, "pad": self.pad,
                "letter_block": self.letter_block, "order_by": self.order_by,
                "prefix": self.prefix, "block": self.block}

    @classmethod
    def from_dict(cls, d):
        return cls(d["token"], scope=d.get("scope"), start=d.get("start", 1),
                   pad=d.get("pad", 0), letter_block=d.get("letter_block", False),
                   order_by=d.get("order_by", "y"), prefix=d.get("prefix", ""),
                   block=d.get("block", 999))


def _letters(li):
    """0-based letter-block index -> bijective letters: 0->A, 25->Z, 26->AA."""
    n = li + 1
    out = ""
    while n:
        n, r = divmod(n - 1, 26)
        out = chr(65 + r) + out
    return out


def _letters_index(s):
    """Inverse of _letters: 'A'->0, 'Z'->25, 'AA'->26; None if not letters."""
    n = 0
    for ch in s.upper():
        if not ("A" <= ch <= "Z"):
            return None
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def _num_norm(raw):
    """23.0 -> 23 so str() keeps no bogus '.0' tail."""
    if isinstance(raw, float) and raw.is_integer():
        return int(raw)
    return raw


def _seq_format(n, spec):
    """Overall counter value n (1-based) -> formatted sequence string."""
    if spec.letter_block:
        li = (n - 1) // spec.block
        k = (n - 1) % spec.block + 1
        s = _letters(li) + str(k).zfill(spec.pad or 3)
    else:
        s = str(n).zfill(spec.pad) if spec.pad else str(n)
    return spec.prefix + s


def _seq_parse(raw, spec):
    """Overall counter value encoded in an EXISTING field value, or None.
    Used to seed the per-scope counter past what is already numbered."""
    s = str(_num_norm(raw)).strip()
    if spec.prefix and s.upper().startswith(spec.prefix.upper()):
        s = s[len(spec.prefix):]
    if spec.letter_block:
        m = re.match(r"^([A-Za-z]+)(\d+)$", s)
        if not m:
            return None
        li = _letters_index(m.group(1))
        if li is None:
            return None
        return li * spec.block + int(m.group(2))
    runs = re.findall(r"\d+", s)
    return int(runs[-1]) if runs else None


def _seq_existing(raw, spec):
    """USE-EXISTING form of a populated number field: keep the value verbatim
    (incl. its own 'DC' style prefix); bare integers get the spec's pad +
    prefix so 23 composes the same as a generated '0023'."""
    s = str(_num_norm(raw)).strip()
    if spec.prefix and s.upper().startswith(spec.prefix.upper()):
        return s
    if s.isdigit() and spec.pad:
        s = s.zfill(spec.pad)
    return (spec.prefix + s) if spec.prefix else s


def _rep_point(feature):
    xy = feature.get("xy")
    if xy is not None:
        return xy
    co = feature.get("coords")
    if co:
        return co[0]
    return (0.0, 0.0)


def _ordkey(v):
    """Deterministic mixed-type sort key: None last, numbers before text."""
    if _is_empty(v):
        return (2, 0.0, "")
    try:
        return (0, float(v), "")
    except (TypeError, ValueError):
        return (1, 0.0, str(v))


def _spatial_nn(reps, idxs):
    """Deterministic nearest-neighbour chain from the SW-most point.

    reps maps index -> (x, y). Returns idxs ordered by walking to the closest
    unused point each step; the SW-most (min x+y) starts the chain. Ties break
    on the index so the order is identical regardless of input order.
    """
    remaining = sorted(idxs, key=lambda i: (reps[i][0] + reps[i][1], i))
    if not remaining:
        return []
    order = [remaining.pop(0)]
    while remaining:
        cx, cy = reps[order[-1]]
        j = min(remaining, key=lambda i:
                ((reps[i][0] - cx) ** 2 + (reps[i][1] - cy) ** 2, i))
        remaining.remove(j)
        order.append(j)
    return order


def _seq_order(features, idxs, spec):
    """The deterministic order in which empty features receive numbers."""
    ob = spec.order_by or "y"
    if ob.startswith("field:"):
        name = ob[6:]
        return sorted(idxs, key=lambda i: _ordkey(
            features[i].get("attrs", {}).get(name)) + (i,))
    if ob == "walk":                    # physical network-walk order (LMN B1)
        # feature["walk_order"] is the DFS pre-order index injected by the
        # Label-My-Network dock (structure_adapter.walk_order_index). Features
        # the walk reached number FIRST, in path order; the rest follow in the
        # normal spatial (nearest-neighbour) order — NOT arbitrary feature id —
        # so a partial walk stays sensible and honest.
        def _reached(i):
            w = features[i].get("walk_order")
            return isinstance(w, (int, float)) and not isinstance(w, bool)
        reached = sorted((i for i in idxs if _reached(i)),
                         key=lambda i: (float(features[i]["walk_order"]), i))
        rest = [i for i in idxs if not _reached(i)]
        if rest:
            reps = {i: _rep_point(features[i]) for i in rest}
            rest = _spatial_nn(reps, rest)
        return reached + rest
    reps = {i: _rep_point(features[i]) for i in idxs}
    if ob == "x":
        return sorted(idxs, key=lambda i: (reps[i][0], reps[i][1], i))
    if ob == "spatial":                 # NN chain from the SW corner
        return _spatial_nn(reps, idxs)
    return sorted(idxs, key=lambda i: (reps[i][1], reps[i][0], i))  # "y"


def _scope_value(token, refs, constants, attrs, field_map):
    """Resolve one scope token the same way _fill would (ref > alias >
    constant > own field)."""
    if token in refs and refs.get(token) is not None:
        return refs[token]
    if token in field_map:
        return attrs.get(field_map[token], "")
    if token in constants:
        return constants[token]
    return attrs.get(token, "")


def assign_sequence(features, spec, *, constants=None, refs_list=None,
                    field_map=None):
    """Per-layer sequence pre-pass (pure python — feed plain feature dicts).

    features : [{"xy"|"coords": ..., "attrs": {...}}, ...] whole layer.
    refs_list: optional per-feature resolved geometry refs (for scope tokens
               that come from polygons, e.g. scope=["pon_no"] or ["zone"]).

    Returns a list of STRINGS aligned with features:
      - a populated number field  -> its value, used as-is (_seq_existing);
      - an empty number field     -> a generated running number per scope,
        assigned in _seq_order() order, seeded past the scope's existing max.
    Deterministic: stable sorts, index tie-breaks, no time/random.
    """
    constants = constants or {}
    fmap = field_map or {}
    fld = fmap.get(spec.token, spec.token)
    n = len(features)
    refs_list = refs_list if refs_list is not None else [{}] * n
    out = [None] * n
    scope_keys = []
    seed = {}
    gen_idx = []
    for i, feat in enumerate(features):
        attrs = feat.get("attrs", {})
        key = tuple(str(_scope_value(t, refs_list[i], constants, attrs, fmap))
                    for t in spec.scope)
        scope_keys.append(key)
        raw = attrs.get(fld)
        if not _is_empty(raw):
            out[i] = _seq_existing(raw, spec)
            parsed = _seq_parse(raw, spec)
            if parsed is not None:
                seed[key] = max(seed.get(key, 0), parsed)
        else:
            gen_idx.append(i)
    counters = {}
    for i in _seq_order(features, gen_idx, spec):
        key = scope_keys[i]
        if key not in counters:
            counters[key] = max(spec.start, seed.get(key, 0) + 1)
        out[i] = _seq_format(counters[key], spec)
        counters[key] += 1
    return out


# ---------------------------------------------------------------------------
# recipe model + composition
# ---------------------------------------------------------------------------

class Recipe:
    """One layer's labelling rule.

    template   : e.g. "{stack}.DF.{cblcpty}.{start}-{end}".
    kind       : "cable" | "point".
    label_field: field to write the composed label into.
    also_fill  : {field: template} extra fields to populate from the same
                 tokens, e.g. {"strtfeat": "{start_full}", "endfeat":
                 "{end_full}", "pon_no": "{pon_no}"}.
    host_max_m : max distance to accept a host reference (else the feature is
                 flagged and left unlabelled).
    field_map  : {token: actual_field_name} — "editable headings".  Binds a
                 clean token to a messy/dialect heading ({num} -> "Cab name",
                 {size} -> "Cable Size").  No entry = the token IS the field
                 name (backward compatible).
    auto_number: enable the sequence generator for `sequence`'s token.
    sequence   : SequenceSpec (or its dict) — see SequenceSpec.
    poly_refs  : extra polygon-reference token names beyond pon_no/zone_no,
                 served by the polygons dict key of the same name (e.g.
                 poly_refs=["ag"] + polygons={"ag": [...]} -> {ag} = the
                 containing AG polygon's configured field).  A custom poly
                 ref that finds no polygon falls back to constant/field.
    chainage   : {"slack": metres, "style": "(%04dm-%04dm)"} for the derived
                 {chainage} token (cables only).
    card_per   : ports per OLT card for the derived {card}/{port} tokens.
    constants  : per-recipe default constants (e.g. {"ht": "HT_", "size":
                 "24F"}); non-empty session constants override them.
    """
    def __init__(self, layer_role, template, *, kind="point",
                 label_field="label", also_fill=None, host_max_m=60.0,
                 field_map=None, auto_number=False, sequence=None,
                 poly_refs=None, chainage=None, card_per=16, constants=None):
        self.layer_role = layer_role
        self.template = template
        self.kind = kind
        self.label_field = label_field
        self.also_fill = dict(also_fill or {})
        self.host_max_m = host_max_m
        self.field_map = dict(field_map or {})
        self.auto_number = bool(auto_number)
        if isinstance(sequence, dict):
            sequence = SequenceSpec.from_dict(sequence)
        self.sequence = sequence
        self.poly_refs = list(poly_refs or ())
        self.chainage = dict(chainage) if chainage else None
        self.card_per = int(card_per or 16)
        self.constants = dict(constants or {})

    def to_dict(self):
        return {"layer_role": self.layer_role, "template": self.template,
                "kind": self.kind, "label_field": self.label_field,
                "also_fill": dict(self.also_fill), "host_max_m": self.host_max_m,
                "field_map": dict(self.field_map),
                "auto_number": self.auto_number,
                "sequence": self.sequence.to_dict() if self.sequence else None,
                "poly_refs": list(self.poly_refs),
                "chainage": dict(self.chainage) if self.chainage else None,
                "card_per": self.card_per,
                "constants": dict(self.constants)}

    @classmethod
    def from_dict(cls, d):
        return cls(d["layer_role"], d["template"], kind=d.get("kind", "point"),
                   label_field=d.get("label_field", "label"),
                   also_fill=d.get("also_fill"),
                   host_max_m=d.get("host_max_m", 60.0),
                   field_map=d.get("field_map"),
                   auto_number=d.get("auto_number", False),
                   sequence=d.get("sequence"),
                   poly_refs=d.get("poly_refs"),
                   chainage=d.get("chainage"),
                   card_per=d.get("card_per", 16),
                   constants=d.get("constants"))


def _short(full_label, stack):
    """'MOA.P.A423' -> 'P.A423' (strip the leading '{stack}.')."""
    s = str(full_label)
    pre = str(stack) + "."
    return s[len(pre):] if s.startswith(pre) else s


def _ends(coords):
    return coords[0], coords[-1]


def _needed_tokens(recipe):
    """Every token the recipe's template + also_fill + sequence scope needs
    (plus pon_no when card/port must be derived)."""
    toks = set(template_tokens(recipe.template))
    for v in recipe.also_fill.values():
        toks |= set(template_tokens(v))
    if recipe.auto_number and recipe.sequence is not None:
        toks |= set(recipe.sequence.scope)
    if {"card", "port"} & toks:
        toks.add("pon_no")
    return toks


def _effective_constants(recipe, constants):
    """Recipe defaults overlaid by NON-EMPTY session constants."""
    out = dict(recipe.constants)
    for k, v in (constants or {}).items():
        if v not in (None, ""):
            out[k] = v
    return out


def resolve_refs(feature, recipe, hosts, polygons, constants):
    """Resolve all geometry references for a feature.

    feature: {"coords": [(x,y),...] for cable} OR {"xy": (x,y) for point},
             plus "attrs": {...}.
    Returns (refs_dict, flags list). refs has start/end/host (+_full),
    pon_no/zone_no + custom poly refs where applicable; missing host -> None
    + a flag.
    """
    refs = {}
    flags = []
    consts = _effective_constants(recipe, constants)
    stack = consts.get("stack", "")
    needed = _needed_tokens(recipe)
    if recipe.kind == "cable" and "coords" in feature:
        a, b = _ends(feature["coords"])
        # only resolve/flag start/end when the recipe actually uses a cable ref
        # (HeroTel/Vuma cables are numbered, not pole-referenced -> no false
        # "needs a pole" flags).
        if needed & _CABLE_REFS:
            for end_xy, k in ((a, "start"), (b, "end")):
                lab, d = hosts.nearest(end_xy, max_m=recipe.host_max_m)
                if lab is None:
                    flags.append({"code": "no_host", "detail":
                                  "no pole/manhole within %.0fm of %s"
                                  % (recipe.host_max_m, k)})
                    refs[k], refs[k + "_full"] = None, None
                else:
                    refs[k + "_full"] = lab
                    refs[k] = _short(lab, stack)
        rep = a  # representative point for polygon lookup = start
    else:
        xy = feature.get("xy")
        lab, d = hosts.nearest(xy, max_m=recipe.host_max_m) if xy else (None, 0)
        if lab is None:
            if needed & _HOSTY_REFS:
                flags.append({"code": "no_host",
                              "detail": "no pole/manhole within %.0fm"
                              % recipe.host_max_m})
            refs["host"], refs["host_full"] = None, None
        else:
            refs["host_full"] = lab
            refs["host"] = _short(lab, stack)
        rep = xy
    # polygon references (built-in pon_no/zone_no + recipe-configured names)
    need_poly = [t for t in needed if t in _POLY_REFS or t in recipe.poly_refs]
    if need_poly and rep is not None:
        for key in set(need_poly):
            polys = polygons.get(key, [])
            refs[key] = polygon_value(rep, polys)
    return refs, flags


def _fill(template, feature, refs, constants, recipe=None):
    """str.format the template, sourcing each token: geom/derived ref >
    field_map alias > constant > feature attr.  A None-valued resolved ref
    makes the label invalid (returns None) — never a wrong guess."""
    fmap = recipe.field_map if recipe is not None else {}
    attrs = feature.get("attrs", {})
    ctx = {}
    for name in template_tokens(template):
        if name in refs:
            ctx[name] = refs[name]
        elif name in fmap:
            ctx[name] = attrs.get(fmap[name], "")
        elif name in constants:
            ctx[name] = constants[name]
        else:
            ctx[name] = attrs.get(name, "")
    # a geometry/derived ref that failed (None) makes the label invalid
    for name in template_tokens(template):
        if name in refs and ctx.get(name) is None:
            return None
        if ctx.get(name) is None:
            ctx[name] = ""
    return _FMT.vformat(template, (), _SafeDict(ctx))


class _SafeDict(dict):
    def __missing__(self, key):
        return ""


def compose(feature, recipe, hosts, polygons, constants, *,
            resolved=None, seq_value=None):
    """Return (label|None, fills dict, flags).  label None => keep NULL.

    resolved : optional pre-computed (refs, flags) from resolve_refs() —
               dry_run's sequence pre-pass reuses its resolution here.
    seq_value: the feature's sequence string from assign_sequence().  Without
               it (single-feature compose), a populated number field is still
               USED; an empty one flags "no_sequence" instead of guessing.
    """
    if resolved is not None:
        refs, flags = dict(resolved[0]), list(resolved[1])
    else:
        refs, flags = resolve_refs(feature, recipe, hosts, polygons, constants)
    consts = _effective_constants(recipe, constants)
    attrs = feature.get("attrs", {})
    needed = _needed_tokens(recipe)

    # custom polygon refs are soft: no containing polygon -> fall back to
    # constant/field resolution instead of nulling the label
    for t in recipe.poly_refs:
        if t not in _POLY_REFS and t in refs and refs[t] is None:
            del refs[t]

    # derived: {card}/{port} from pon_no
    if {"card", "port"} & needed:
        pon = refs.get("pon_no")
        if _is_empty(pon):
            pon = attrs.get(recipe.field_map.get("pon_no", "pon_no"))
        if _is_empty(pon):
            pon = consts.get("pon_no")
        try:
            c, p = card_port(pon, recipe.card_per)
        except (TypeError, ValueError):
            c = p = None
            flags.append({"code": "no_pon", "detail":
                          "card/port need a numeric pon_no (got %r)" % (pon,)})
        refs["card"], refs["port"] = c, p

    # derived: {polenum} = digits of the hosting pole's label
    if "polenum" in needed:
        refs["polenum"] = _label_digits(refs.get("host_full"))

    # derived: {chainage} = cable length window
    if "chainage" in needed:
        co = feature.get("coords")
        if recipe.kind == "cable" and co and len(co) >= 2:
            spec = recipe.chainage or {}
            refs["chainage"] = chainage_value(
                polyline_length_m(co), float(spec.get("slack", 0.0)),
                str(spec.get("style", "(%04dm-%04dm)")))
        else:
            refs["chainage"] = None
            flags.append({"code": "no_chainage",
                          "detail": "chainage needs a cable geometry"})

    # sequence token: injected pre-pass value > existing field value > flag
    if recipe.auto_number and recipe.sequence is not None:
        tok = recipe.sequence.token
        if seq_value is not None:
            refs[tok] = seq_value
        else:
            fld = recipe.field_map.get(tok, tok)
            raw = attrs.get(fld)
            if not _is_empty(raw):
                refs[tok] = _seq_existing(raw, recipe.sequence)
            else:
                refs[tok] = None
                flags.append({"code": "no_sequence", "detail":
                              "'%s' is empty — numbers generate in a "
                              "full-layer preview" % fld})

    label = _fill(recipe.template, feature, refs, consts, recipe)
    fills = {}
    if label is not None:
        for field, tmpl in recipe.also_fill.items():
            toks = template_tokens(tmpl)
            # a single "{token}" fill passes the RAW value (keeps pon_no/zone_no
            # as ints instead of stringifying them) — else compose as text.
            if len(toks) == 1 and tmpl == "{%s}" % toks[0] and toks[0] in refs:
                val = refs[toks[0]]
            else:
                val = _fill(tmpl, feature, refs, consts, recipe)
            if val is not None and val != "":
                fills[field] = val
    return label, fills, flags


# ---------------------------------------------------------------------------
# QGIS orchestration (lazy import — everything above is QGIS-free)
# ---------------------------------------------------------------------------

class LayerRecipe:
    """Binds a Recipe to a target QgsVectorLayer + its id field."""
    def __init__(self, layer, recipe, *, id_field="$id"):
        self.layer = layer
        self.recipe = recipe
        self.id_field = id_field


def _coords_of(geom):
    if not geom or geom.isEmpty():
        return None
    if geom.isMultipart():
        pts = [q for part in geom.asMultiPolyline() for q in part]
    else:
        pts = geom.asPolyline()
    if len(pts) < 2:
        return None
    return [(p.x(), p.y()) for p in pts]


def _rings_of(geom):
    rings = []
    polys = geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]
    for poly in polys:
        for ring in poly:
            rings.append([(p.x(), p.y()) for p in ring])
    return rings


def build_host_index(host_layers, *, cell_m=25.0):
    """host_layers: list of (QgsVectorLayer, label_field). Poles + manholes."""
    hosts = []
    for layer, lf in host_layers:
        for f in layer.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            lab = f[lf]
            if lab in (None, ""):
                continue
            pt = g.asPoint()
            hosts.append({"label": str(lab), "xy": (pt.x(), pt.y())})
    index = HostIndex(hosts, cell_m=cell_m)
    index.source_locks = _dependency_source_locks(
        [("host:%d" % i, layer, field)
         for i, (layer, field) in enumerate(host_layers)]
    )
    return index


class DependencyPolygons(dict):
    """Polygon lookup values plus the live layers that authorised them."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.source_locks = {}


def build_polygons(polygon_layers):
    """polygon_layers: {ref_name: (QgsVectorLayer, value_field)} e.g.
    {'pon_no': (pon_layer, 'pon_no'), 'zone_no': (zone_layer, 'zone_no'),
    'ag': (ag_layer, 'Name')} — any Recipe.poly_refs name works the same."""
    out = DependencyPolygons()
    for ref, (layer, vf) in polygon_layers.items():
        polys = []
        for f in layer.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            polys.append({"value": f[vf], "rings": _rings_of(g)})
        out[ref] = polys
    out.source_locks = _dependency_source_locks(
        [("polygon:%s" % ref, layer, field)
         for ref, (layer, field) in polygon_layers.items()]
    )
    return out


def _fid(feat, id_field):
    return feat.id() if id_field in ("$id", None, "") else feat[id_field]


def dry_run(layer_recipes, host_index, polygons, constants):
    """Compose labels for every target layer WITHOUT writing.

    Auto-numbered layers get a per-layer PRE-PASS: refs are resolved for the
    whole layer, assign_sequence() allocates the running numbers (existing
    field values kept, empties generated in deterministic order), then each
    feature composes with its injected value.

    Returns {layer_role: {"changes":[{fid,old,new,fills}], "ready":int,
    "flagged":int, "flags":[...], "labels":{fid:(label,fills)}, "skipped":int,
    "skips":{fid:reason}}} + a totals key.  A feature with null/empty/degenerate
    geometry is NOT silently dropped: it is counted in "skipped" and its reason
    recorded in "skips" (it can't be labelled — it needs a geometry, not a host)
    so the preview total reconciles with the layer.  It is absent from "labels"
    exactly as before, so apply() still skips it (output-neutral).
    """
    dependencies = {}
    dependencies.update(getattr(host_index, "source_locks", {}) or {})
    dependencies.update(getattr(polygons, "source_locks", {}) or {})
    result = {
        "_dependencies": dependencies,
        "_totals": {"ready": 0, "flagged": 0, "skipped": 0},
    }
    for lrc in layer_recipes:
        rec = lrc.recipe
        lyr = lrc.layer
        lf = rec.label_field
        changes = []
        labels = {}
        flags = []
        skips = {}
        source = {}
        ready = flagged = skipped = 0
        rows = []
        field_names = tuple(lyr.fields().names())
        for f in lyr.getFeatures():
            fid = _fid(f, lrc.id_field)
            source[fid] = _feature_input_signature(f, field_names)
            g = f.geometry()
            if not g or g.isEmpty():
                skips[fid] = "no geometry"
                skipped += 1
                continue
            if rec.kind == "cable":
                co = _coords_of(g)
                if co is None:
                    skips[fid] = "bad geometry"
                    skipped += 1
                    continue
                feat = {"coords": co,
                        "attrs": dict((k, f[k]) for k in f.fields().names())}
            else:
                pt = g.asPoint()
                feat = {"xy": (pt.x(), pt.y()),
                        "attrs": dict((k, f[k]) for k in f.fields().names())}
            old = f[lf] if lf in f.fields().names() else None
            rows.append({"feat": feat, "fid": fid,
                         "qfid": f.id(), "old": old})
        resolved = None
        seq_vals = None
        if rec.auto_number and rec.sequence is not None:
            consts_m = _effective_constants(rec, constants)
            resolved = [resolve_refs(r["feat"], rec, host_index, polygons,
                                     consts_m) for r in rows]
            seq_vals = assign_sequence(
                [r["feat"] for r in rows], rec.sequence, constants=consts_m,
                refs_list=[rf for rf, _fl in resolved],
                field_map=rec.field_map)
        for i, row in enumerate(rows):
            label, fills, fl = compose(
                row["feat"], rec, host_index, polygons, constants,
                resolved=(resolved[i] if resolved is not None else None),
                seq_value=(seq_vals[i] if seq_vals is not None else None))
            fid = row["fid"]
            labels[fid] = (label, fills)
            if label is None:
                flagged += 1
                for x in fl:
                    flags.append({"fid": fid, **x})
            else:
                ready += 1
                if row["old"] != label:
                    changes.append({"fid": row["qfid"], "lfid": fid,
                                    "old": row["old"], "new": label,
                                    "fills": fills})
        result[rec.layer_role] = {"changes": changes, "ready": ready,
                                  "flagged": flagged, "flags": flags,
                                  "labels": labels, "skipped": skipped,
                                  "skips": skips,
                                  "source": source,
                                  "create_fields": _missing_fields(lyr, rec)}
        result["_totals"]["ready"] += ready
        result["_totals"]["flagged"] += flagged
        result["_totals"]["skipped"] += skipped
    return result


# fields the label writes into.  pon_no/zone_no are numeric; everything else
# (label + strtfeat/endfeat) is text.
_INT_FIELDS = {"pon_no", "zone_no"}


def _target_fields(recipe):
    return [recipe.label_field] + list(recipe.also_fill.keys())


def _missing_fields(layer, recipe):
    """Target fields the recipe writes that don't yet exist on the layer."""
    have = set(layer.fields().names())
    return [n for n in _target_fields(recipe) if n and n not in have]


def _ensure_fields(layer, recipe, names=None):
    """Create any missing target field so the operator never has to add the
    label/strtfeat/endfeat/pon_no/zone_no columns by hand.  Returns the names
    created (text by default, Int for pon_no/zone_no).

    # claude:intent MUTATE — user asked: "do we need this ID, length ... first
    # or does the label my network do it automatically" -> auto-create the
    # OUTPUT columns.  Only ever runs inside apply() (operator pressed Label);
    # never at preview/import.  # claude:approved-destructive
    """
    missing = _missing_fields(layer, recipe)
    if names is not None:
        wanted = set(names)
        missing = [name for name in missing if name in wanted]
    if not missing:
        return []
    from qgis.PyQt.QtCore import QMetaType
    from qgis.core import QgsField
    to_add = []
    for name in missing:
        if name in _INT_FIELDS:
            to_add.append(QgsField(name, QMetaType.Type.Int))
        else:
            to_add.append(QgsField(name, QMetaType.Type.QString, "", 254))
    ok = layer.dataProvider().addAttributes(to_add)
    if ok is False:
        raise RuntimeError(
            "provider refused output field creation: %s"
            % ", ".join(missing)
        )
    layer.updateFields()
    still_missing = [name for name in missing
                     if layer.fields().indexOf(name) < 0]
    if still_missing:
        raise RuntimeError(
            "output fields were not created: %s" % ", ".join(still_missing)
        )
    return missing


class LayersEditableError(RuntimeError):
    """Raised BEFORE any write when target layers are in edit mode — writing
    through the provider while an edit buffer is open is undefined behaviour
    (and was part of the 2026-07-24 native crash). .roles = offending roles."""

    def __init__(self, roles):
        self.roles = list(roles)
        super().__init__("layers in edit mode: %s" % ", ".join(map(str, roles)))


class PreviewStaleError(RuntimeError):
    """The live layer changed after the dry-run that authorised the write."""

    def __init__(self, issues):
        self.issues = list(issues)
        super().__init__("preview source changed: %s" % "; ".join(self.issues))


class ApplyPreflightError(RuntimeError):
    """The complete write plan is unsafe; nothing has been mutated."""

    def __init__(self, issues):
        self.issues = list(issues)
        super().__init__("apply preflight failed: %s" % "; ".join(self.issues))


class ApplyIdentityError(ApplyPreflightError):
    """Logical feature IDs are null/unhashable/duplicated."""


class ApplyTransactionError(RuntimeError):
    """A schema/value write or reread failed; the whole run was rolled back."""

    def __init__(self, cause, rollback_ok, rollback_errors=()):
        self.cause = cause
        self.rollback_ok = bool(rollback_ok)
        self.rollback_errors = list(rollback_errors)
        state = "rollback complete" if self.rollback_ok else "rollback incomplete"
        super().__init__("%s (%s): %s" % (type(cause).__name__, state, cause))


class UndoPlan(dict):
    """Backwards-compatible undo value map plus fields created by the run."""

    def __init__(self, *args, created_fields=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.created_fields = {
            role: list(fields)
            for role, fields in (created_fields or {}).items()
        }


def _signature_value(value):
    """Stable, equality-safe representation for a preview source lock."""
    if value is None:
        return ("null", "")
    try:
        if hasattr(value, "isNull") and value.isNull():
            return ("null", "")
    except Exception:
        _swallowed_note()
    if isinstance(value, bytes):
        return ("bytes", value)
    if isinstance(value, (bool, int, float, str)):
        return (type(value).__name__, value)
    return (
        "%s.%s" % (type(value).__module__, type(value).__name__),
        str(value),
    )


def _feature_input_signature(feature, field_names):
    """All attributes + geometry used to prove the preview is still fresh."""
    geom = feature.geometry()
    if geom is None:
        wkb = None
    else:
        try:
            wkb = bytes(geom.asWkb()) if not geom.isEmpty() else b""
        except Exception:
            wkb = None
    attrs = tuple(
        (name, _signature_value(feature[name])) for name in field_names
    )
    return (feature.id(), attrs, wkb)


def _source_snapshot(layer, id_field=None):
    """Per-feature source lock, keyed exactly like dry-run/apply."""
    names = tuple(layer.fields().names())
    return {
        _fid(feature, id_field): _feature_input_signature(feature, names)
        for feature in layer.getFeatures()
    }


def _identity_issues(layer, id_field=None):
    """Return every unsafe logical-ID condition without mutating the layer."""
    seen = {}
    issues = []
    for feature in layer.getFeatures():
        value = _fid(feature, id_field)
        if _is_empty(value):
            issues.append("provider FID %r has a null logical ID" % feature.id())
            continue
        try:
            previous = seen.get(value)
        except TypeError:
            issues.append(
                "provider FID %r has an unhashable logical ID" % feature.id()
            )
            continue
        if previous is not None:
            issues.append(
                "duplicate logical ID %r on provider FIDs %r and %r"
                % (value, previous, feature.id())
            )
        else:
            seen[value] = feature.id()
    return issues


def _dependency_source_locks(entries):
    """Capture full attributes + geometry for every host/polygon dependency.

    ``entries`` are ``(name, layer, value_field)`` tuples.  The layer reference
    intentionally stays in-memory: apply must reread the exact live provider,
    not rediscover a same-named layer.
    """
    locks = {}
    for name, layer, value_field in entries or ():
        try:
            layer_id = layer.id()
        except Exception:
            layer_id = repr(layer)
        key = "%s:%s" % (name, layer_id)
        locks[key] = {
            "layer": layer,
            "field": str(value_field or ""),
            "source": _source_snapshot(layer),
        }
    return locks


def _dependency_stale_issues(dry_result):
    locks = dry_result.get("_dependencies") if isinstance(dry_result, dict) else None
    if locks is None:
        return ["preview has no dependency lock"]
    issues = []
    for key, lock in (locks or {}).items():
        if not isinstance(lock, dict) or lock.get("layer") is None \
                or "source" not in lock:
            issues.append("dependency %s has no usable source lock" % key)
            continue
        current = _source_snapshot(lock["layer"])
        expected = lock["source"]
        if current != expected:
            issues.append("dependency %s changed after preview" % key)
    return issues


def _coerce_value(type_name, val):
    """Cast val to an OGR field storage type by typeName() — version-proof
    (Qt6 enum identity is class-dependent, provider typeName is not).
    Returns (ok, casted). ok=False means the value CANNOT represent in the
    column — the caller must refuse-and-report, never silently coerce.

    NOT length-aware, deliberately (probed on QGIS 4.0.3 / GDAL, 2026-07-26):
    the OGR shapefile provider AUTO-WIDENS a DBF text column to fit a longer
    value (str:16 + a 20-char label -> the column becomes str:20 and the value
    is intact), so refusing on the declared width would reject writes that
    actually succeed. The one real ceiling is DBF's 254 bytes, where GDAL
    truncates and still reports success — see research/label_width_verify/.
    Pure python, unit-testable."""
    if val is None:
        return True, None
    t = str(type_name or "").lower()
    try:
        if t.startswith("integer"):          # Integer / Integer64
            if isinstance(val, bool):
                return True, int(val)
            if isinstance(val, int):
                return True, val
            if isinstance(val, float):       # 3.0 fits; 3.7 would TRUNCATE
                return (True, int(val)) if val.is_integer() else (False, None)
            s = str(val).strip()
            return True, int(s)              # int("12") ok; int("A3") raises
        if t in ("real", "double", "float"):
            return True, float(val)
        return True, str(val)                # String and anything else
    except (TypeError, ValueError):
        return False, None


def _planned_type_name(field):
    return "Integer" if field in _INT_FIELDS else "String"


def _delete_created_fields(plan, errors):
    names = list(plan.get("created_fields") or ())
    if not names:
        return
    layer = plan["layer"]
    provider = plan["provider"]
    indexes = [layer.fields().indexOf(name) for name in names]
    indexes = [index for index in indexes if index >= 0]
    try:
        if indexes:
            ok = provider.deleteAttributes(indexes)
            if ok is False:
                errors.append("%s provider refused field rollback" % plan["role"])
        layer.updateFields()
        remaining = [name for name in names if layer.fields().indexOf(name) >= 0]
        if remaining:
            errors.append(
                "%s fields remain after rollback: %s"
                % (plan["role"], ", ".join(remaining))
            )
    except Exception as exc:
        errors.append(
            "%s field rollback: %s: %s"
            % (plan["role"], type(exc).__name__, exc)
        )


def _rollback_plans(plans, original_source):
    errors = []
    for plan in reversed(plans):
        rollback = plan.get("rollback_indexed") or {}
        if rollback:
            try:
                ok = plan["provider"].changeAttributeValues(rollback)
                if ok is False:
                    errors.append(
                        "%s provider refused value rollback" % plan["role"]
                    )
            except Exception as exc:
                errors.append(
                    "%s value rollback: %s: %s"
                    % (plan["role"], type(exc).__name__, exc)
                )
        _delete_created_fields(plan, errors)
        try:
            plan["layer"].triggerRepaint()
        except Exception:
            _swallowed_note()
    for plan in plans:
        role = plan["role"]
        try:
            current = _source_snapshot(plan["layer"], plan["id_field"])
            if current != original_source.get(role, {}):
                errors.append("%s did not reread exactly after rollback" % role)
        except Exception as exc:
            errors.append(
                "%s rollback verification: %s: %s"
                % (role, type(exc).__name__, exc)
            )
    return errors


def apply(layer_recipes, dry_result, progress=None, report=None):
    """Write composed labels + also_fill fields via ONE bulk provider write per
    layer. Skips None labels. Returns undo = {(role,fid): {field: old}}.

    Crash-hardened (2026-07-24 — "Label everything" killed QGIS natively):
    1. edit-mode layers are detected FIRST and raise LayersEditableError
       before ANY layer is written (all-or-nothing);
    2. every missing output column is created in EVERY layer up front —
       never a DBF schema rewrite interleaved with another layer's writes;
    3. every value is cast to the column's real storage type; a value that
       cannot be represented is REFUSED and reported (report["refused"]),
       never silently written wrong-typed (the crash wrote QString into a
       numeric column 99 times) and never coerced to junk;
    4. progress(done_layers, total_layers, role) fires per layer so the UI
       can show honest progress. The CALLER owns canvas freezing.
    report (optional dict) gains: refused=[(role, fid, field, value)…],
    written=<int changed features>, per_layer={role: n}.
    """
    rep = report if isinstance(report, dict) else {}
    rep["refused"] = []
    rep.setdefault("per_layer", {})
    rep["expected"] = {}
    rep["before"] = {}
    rep["source_lock_checked"] = False
    rep["rolled_back"] = False
    rep["rollback_errors"] = []
    rep["source"] = {}
    rep["created_fields"] = {}
    rep["written"] = 0

    live = [lrc for lrc in layer_recipes
            if lrc.layer is not None and dry_result.get(lrc.recipe.layer_role)]
    editable = [lrc.recipe.layer_role for lrc in live if lrc.layer.isEditable()]
    if editable:
        raise LayersEditableError(editable)

    identity_issues = []
    for lrc in live:
        role = lrc.recipe.layer_role
        identity_issues.extend(
            "%s: %s" % (role, issue)
            for issue in _identity_issues(lrc.layer, lrc.id_field)
        )
    if identity_issues:
        raise ApplyIdentityError(identity_issues)

    stale = _dependency_stale_issues(dry_result)
    for lrc in live:
        role = lrc.recipe.layer_role
        expected_source = (dry_result.get(role) or {}).get("source")
        if expected_source is None:
            stale.append("%s has no preview source lock" % role)
            continue
        current_source = _source_snapshot(lrc.layer, lrc.id_field)
        if current_source == expected_source:
            rep["source"][role] = dict(expected_source)
            continue
        before_ids = set(expected_source)
        now_ids = set(current_source)
        added = len(now_ids - before_ids)
        missing = len(before_ids - now_ids)
        changed = sum(
            1 for fid in before_ids & now_ids
            if expected_source[fid] != current_source[fid]
        )
        stale.append(
            "%s changed (%d added, %d removed, %d edited)"
            % (role, added, missing, changed)
        )
    if stale:
        raise PreviewStaleError(stale)
    rep["source_lock_checked"] = True

    undo_values = {}
    total = len(live)
    plans = []
    preflight_issues = []
    for lrc in live:
        rec = lrc.recipe
        role = rec.layer_role
        res = dry_result[role]
        lyr = lrc.layer
        fields = lyr.fields()
        idx = {n: fields.indexOf(n) for n in fields.names()}
        ftype = {n: fields.at(idx[n]).typeName() for n in idx if idx[n] >= 0}
        changes_by_name = {}
        rollback_by_name = {}
        create_fields = set()
        n_changed = 0
        for f in lyr.getFeatures():
            fid = _fid(f, lrc.id_field)
            got = res["labels"].get(fid)
            if not got or got[0] is None:
                continue
            label, fills = got
            row = {}
            old = {}
            for field, val in [(rec.label_field, label)] + list(fills.items()):
                exists = field in idx
                old_value = f[field] if exists else None
                type_name = (
                    ftype.get(field) if exists else _planned_type_name(field)
                )
                ok, cast = _coerce_value(type_name, val)
                if not ok:
                    rep["refused"].append((role, fid, field, val))
                    preflight_issues.append(
                        "%s logical ID %r field '%s' value %r cannot "
                        "represent in %s"
                        % (role, fid, field, val, type_name)
                    )
                    continue
                if exists and _signature_value(old_value) == _signature_value(cast):
                    continue
                row[field] = cast
                if exists:
                    old[field] = old_value
                else:
                    create_fields.add(field)
            if row:
                changes_by_name[f.id()] = row
                rollback_by_name[f.id()] = old
                undo_values[(role, fid)] = old
                rep["expected"][(role, fid)] = dict(row)
                rep["before"][(role, fid)] = dict(old)
                n_changed += 1
        plans.append({
            "role": role, "layer": lyr, "provider": lyr.dataProvider(),
            "id_field": lrc.id_field, "recipe": rec,
            "changes_by_name": changes_by_name,
            "rollback_by_name": rollback_by_name,
            "create_fields": sorted(create_fields),
            "created_fields": [], "count": n_changed,
        })
    if preflight_issues:
        raise ApplyPreflightError(preflight_issues)

    attempted = []
    try:
        # Schema and values are one transaction.  Every field is known and every
        # value is representable before this first mutation.
        for plan in plans:
            if plan["create_fields"]:
                plan["created_fields"] = list(plan["create_fields"])
                attempted.append(plan)
                created = _ensure_fields(
                    plan["layer"], plan["recipe"], plan["create_fields"]
                )
                plan["created_fields"] = list(created)
                rep["created_fields"][plan["role"]] = list(
                    plan["created_fields"]
                )
            elif plan not in attempted:
                attempted.append(plan)

        for plan in plans:
            fields = plan["layer"].fields()
            indexes = {name: fields.indexOf(name) for name in fields.names()}
            missing = [
                field
                for row in plan["changes_by_name"].values()
                for field in row
                if indexes.get(field, -1) < 0
            ]
            if missing:
                raise RuntimeError(
                    "%s planned fields missing after schema update: %s"
                    % (plan["role"], ", ".join(sorted(set(missing))))
                )
            plan["changes_indexed"] = {
                qfid: {indexes[field]: value for field, value in row.items()}
                for qfid, row in plan["changes_by_name"].items()
            }
            plan["rollback_indexed"] = {
                qfid: {indexes[field]: value for field, value in row.items()}
                for qfid, row in plan["rollback_by_name"].items()
            }

        for done, plan in enumerate(plans):
            if plan["changes_indexed"]:
                ok = plan["provider"].changeAttributeValues(
                    plan["changes_indexed"]
                )
                if ok is False:
                    raise RuntimeError(
                        "provider refused %s attribute write" % plan["role"]
                    )
            rep["per_layer"][plan["role"]] = plan["count"]
            plan["layer"].triggerRepaint()
            if callable(progress):
                try:
                    progress(done + 1, total, plan["role"])
                except Exception:
                    _swallowed_note()
        verification = verify_apply(layer_recipes, rep)
        rep["verification"] = verification
        if not verification["ok"]:
            raise RuntimeError(
                "post-write verification failed with %d mismatch(es)"
                % len(verification.get("mismatches", ()))
            )
    except Exception as exc:
        rollback_errors = _rollback_plans(attempted, rep["source"])
        rep["rolled_back"] = not rollback_errors
        rep["rollback_errors"] = rollback_errors
        rep["written"] = 0
        raise ApplyTransactionError(
            exc, not rollback_errors, rollback_errors
        ) from exc
    rep["written"] = len(undo_values)
    return UndoPlan(undo_values, created_fields=rep["created_fields"])


def undo_apply(layer_recipes, undo):
    """Restore a successful apply, including deleting fields it created.

    Provider return values and the final reread are mandatory.  The undo map is
    keyed by the same validated logical IDs as apply; duplicate/null IDs are
    refused before any restore.
    """
    created = dict(getattr(undo, "created_fields", {}) or {})
    errors = []
    restored = 0
    plans = []
    for lrc in layer_recipes:
        layer = lrc.layer
        if layer is None:
            continue
        role = lrc.recipe.layer_role
        identity = _identity_issues(layer, lrc.id_field)
        if identity:
            errors.extend("%s: %s" % (role, item) for item in identity)
            continue
        indexes = {name: layer.fields().indexOf(name)
                   for name in layer.fields().names()}
        changes = {}
        expected = {}
        for feature in layer.getFeatures():
            logical_id = _fid(feature, lrc.id_field)
            old = undo.get((role, logical_id))
            if old is None:
                continue
            row = {
                indexes[field]: value for field, value in old.items()
                if indexes.get(field, -1) >= 0
            }
            if row:
                changes[feature.id()] = row
                expected[logical_id] = dict(old)
        plans.append({
            "role": role,
            "layer": layer,
            "provider": layer.dataProvider(),
            "id_field": lrc.id_field,
            "changes": changes,
            "expected": expected,
            "created_fields": list(created.get(role, ())),
        })
    if errors:
        return {"ok": False, "restored": 0, "errors": errors}
    for plan in plans:
        try:
            if plan["changes"]:
                ok = plan["provider"].changeAttributeValues(plan["changes"])
                if ok is False:
                    errors.append(
                        "%s provider refused undo values" % plan["role"]
                    )
                else:
                    restored += len(plan["changes"])
            _delete_created_fields(plan, errors)
            plan["layer"].triggerRepaint()
        except Exception as exc:
            errors.append(
                "%s undo: %s: %s"
                % (plan["role"], type(exc).__name__, exc)
            )
    for plan in plans:
        role = plan["role"]
        fields = set(plan["layer"].fields().names())
        for name in plan["created_fields"]:
            if name in fields:
                errors.append("%s undo left field %s" % (role, name))
        by_logical = {
            _fid(feature, plan["id_field"]): feature
            for feature in plan["layer"].getFeatures()
        }
        for logical_id, expected in plan["expected"].items():
            feature = by_logical.get(logical_id)
            if feature is None:
                errors.append(
                    "%s undo lost logical ID %r" % (role, logical_id)
                )
                continue
            for field, value in expected.items():
                if field not in fields or \
                        _signature_value(feature[field]) != _signature_value(value):
                    errors.append(
                        "%s undo reread mismatch at %r.%s"
                        % (role, logical_id, field)
                    )
    return {"ok": not errors, "restored": restored, "errors": errors}


def verify_apply(layer_recipes, apply_report):
    """Re-read providers and prove promised values plus untouched state.

    The L4 report is the oracle: ``expected`` names every intended value and
    ``source`` is the full pre-write attribute/geometry snapshot.  This
    function writes nothing and returns a compact, JSON-safe verdict.
    """
    expected = dict((apply_report or {}).get("expected") or {})
    source = dict((apply_report or {}).get("source") or {})
    mismatches = []
    roles = {}
    verified_values = 0
    untouched_values = 0
    verified_geometry = 0
    current_by_role = {}
    lrc_by_role = {
        lrc.recipe.layer_role: lrc for lrc in layer_recipes
        if lrc.layer is not None
    }
    for role, before_rows in source.items():
        lrc = lrc_by_role.get(role)
        if lrc is None:
            mismatches.append({
                "role": role, "fid": None, "field": None,
                "kind": "missing_layer",
            })
            continue
        current = _source_snapshot(lrc.layer, lrc.id_field)
        current_by_role[role] = current
        before_ids = set(before_rows)
        current_ids = set(current)
        added = current_ids - before_ids
        missing = before_ids - current_ids
        if added:
            mismatches.append({
                "role": role, "fid": None, "field": None,
                "kind": "features_added", "count": len(added),
            })
        if missing:
            mismatches.append({
                "role": role, "fid": None, "field": None,
                "kind": "features_missing", "count": len(missing),
            })
        role_expected = {
            fid: fields for (exp_role, fid), fields in expected.items()
            if exp_role == role
        }
        allowed_new_fields = set()
        for fields in role_expected.values():
            allowed_new_fields.update(fields)
        role_verified = 0
        role_untouched = 0
        role_geometry = 0
        for fid in before_ids & current_ids:
            before_sig = before_rows[fid]
            current_sig = current[fid]
            before_attrs = dict(before_sig[1])
            current_attrs = dict(current_sig[1])
            promised = role_expected.get(fid, {})
            if before_sig[0] != current_sig[0]:
                mismatches.append({
                    "role": role, "fid": fid, "field": None,
                    "kind": "provider_fid_changed",
                })
            if before_sig[2] != current_sig[2]:
                mismatches.append({
                    "role": role, "fid": fid, "field": None,
                    "kind": "geometry_changed",
                })
            else:
                verified_geometry += 1
                role_geometry += 1
            for field, value in promised.items():
                want = _signature_value(value)
                got = current_attrs.get(field, ("missing", ""))
                if got != want:
                    mismatches.append({
                        "role": role, "fid": fid, "field": field,
                        "kind": "promised_value_mismatch",
                        "expected": repr(value), "actual": repr(got),
                    })
                else:
                    verified_values += 1
                    role_verified += 1
            for field, before_value in before_attrs.items():
                if field in promised:
                    continue
                if current_attrs.get(field, ("missing", "")) != before_value:
                    mismatches.append({
                        "role": role, "fid": fid, "field": field,
                        "kind": "untouched_value_changed",
                    })
                else:
                    untouched_values += 1
                    role_untouched += 1
            for field in set(current_attrs) - set(before_attrs):
                if field not in allowed_new_fields:
                    mismatches.append({
                        "role": role, "fid": fid, "field": field,
                        "kind": "unexpected_field_added",
                    })
                elif field not in promised and current_attrs[field] != ("null", ""):
                    mismatches.append({
                        "role": role, "fid": fid, "field": field,
                        "kind": "unpromised_new_field_value",
                    })
        roles[role] = {
            "features_before": len(before_rows),
            "features_after": len(current),
            "promised_features": len(role_expected),
            "verified_values": role_verified,
            "untouched_values": role_untouched,
            "verified_geometries": role_geometry,
        }
    promised_values = sum(len(fields) for fields in expected.values())
    return {
        "ok": not mismatches,
        "promised_features": len(expected),
        "promised_values": promised_values,
        "verified_values": verified_values,
        "untouched_values": untouched_values,
        "verified_geometries": verified_geometry,
        "roles": roles,
        "mismatches": mismatches,
    }


# ---------------------------------------------------------------------------
# recipe presets (EDITABLE defaults) — one CORRECT set per client, distilled
# from the evidence-backed label-grammar profiles (2026-07-09):
#   Fibertime: 8 as-built projects (~190k features), dot notation.
#   Vuma:      6 projects, hyphen assets + underscore engineering cable names.
#   HeroTel:   OPL spec + 5 projects, HT_ underscore notation.
# ---------------------------------------------------------------------------

_CABLE_FILL = {"strtfeat": "{start_full}", "endfeat": "{end_full}",
               "pon_no": "{pon_no}", "zone_no": "{zone_no}"}
_POINT_FILL = {"strtfeat": "{host_full}", "pon_no": "{pon_no}",
               "zone_no": "{zone_no}"}


def _velocity_recipes(stack=None):
    """Legacy generic 'stack' preset — kept as the fallback for unknown
    clients ({stack} resolves from the session constants)."""
    return {
        "DIST_CABLE": Recipe("DIST_CABLE", "{stack}.DF.{cblcpty}.{start}-{end}",
                             kind="cable", also_fill=dict(_CABLE_FILL)),
        "SEC_CABLE": Recipe("SEC_CABLE", "{stack}.SF.{cblcpty}.{start}-{end}",
                            kind="cable", also_fill=dict(_CABLE_FILL)),
        "PRI_CABLE": Recipe("PRI_CABLE", "{stack}.PF.{cblcpty}.{start}-{end}",
                            kind="cable", also_fill=dict(_CABLE_FILL),
                            host_max_m=120.0),
        "STS_SPLITTER": Recipe("STS_SPLITTER",
                               "{stack}.STS.{ratio}.DIS.DM.{host}.C#P#.L#",
                               kind="point", also_fill=dict(_POINT_FILL)),
        "FTS_SPLITTER": Recipe("FTS_SPLITTER",
                               "{stack}.FTS.{ratio}.AGG.DM.{host}-OLT.{olt}.C#P#",
                               kind="point", also_fill=dict(_POINT_FILL)),
        "ENCL_SPLICE": Recipe("ENCL_SPLICE", "{stack}.AGG.DM.{host}",
                              kind="point", label_field="label_1",
                              also_fill=dict(_POINT_FILL)),
        "ENCL_CONN": Recipe("ENCL_CONN", "{stack}.DIS.DM.{host}",
                            kind="point", label_field="label_1",
                            also_fill=dict(_POINT_FILL)),
        "ONT": Recipe("ONT", "{stack}.ONT.DR{drop}", kind="point",
                      label_field="label_1",
                      also_fill={"pon_no": "{pon_no}", "zone_no": "{zone_no}"}),
        "DROP_CABLE": Recipe("DROP_CABLE", "DR{drop}", kind="cable",
                             also_fill={"pon_no": "{pon_no}", "zone_no": "{zone_no}"}),
    }


def _fibertime_recipes():
    """Fibertime dot notation.  {host} short-form already carries its
    'P.'/'MH.' prefix.  STS legs (L{leg}) reset per PON; C{card}P{port}
    derive from the containing PON polygon's pon_no; pole/manhole/POP
    sequences are auto_number capable (poles roll A001..A999 -> B001)."""
    return {
        "DIST_CABLE": Recipe("DIST_CABLE", "{stack}.DF.{cblcpty}.{start}-{end}",
                             kind="cable", also_fill=dict(_CABLE_FILL)),
        "SEC_CABLE": Recipe("SEC_CABLE", "{stack}.SF.{cblcpty}.{start}-{end}",
                            kind="cable", also_fill=dict(_CABLE_FILL)),
        "PRI_CABLE": Recipe("PRI_CABLE", "{stack}.PF.{cblcpty}.{start}-{end}",
                            kind="cable", also_fill=dict(_CABLE_FILL),
                            host_max_m=120.0),
        "STS_SPLITTER": Recipe(
            "STS_SPLITTER",
            "{stack}.STS.{ratio}.DIS.DM.{host}.C{card}P{port}.L{leg}",
            kind="point", also_fill=dict(_POINT_FILL), auto_number=True,
            sequence=SequenceSpec("leg", scope=["pon_no"], start=1,
                                  order_by="spatial")),
        "FTS_SPLITTER": Recipe(
            "FTS_SPLITTER",
            "{stack}.FTS.{ratio}.AGG.DM.{host}-OLT.{olt}.C{card}P{port}",
            kind="point", also_fill=dict(_POINT_FILL),
            constants={"olt": "01"}),
        "ENCL_SPLICE": Recipe("ENCL_SPLICE", "{stack}.AGG.DM.{host}",
                              kind="point", label_field="label_1",
                              also_fill=dict(_POINT_FILL)),
        "ENCL_CONN": Recipe("ENCL_CONN", "{stack}.DIS.DM.{host}",
                            kind="point", label_field="label_1",
                            also_fill=dict(_POINT_FILL)),
        "ONT": Recipe("ONT", "{stack}.ONT.DR{drop}", kind="point",
                      label_field="label_1",
                      also_fill={"pon_no": "{pon_no}", "zone_no": "{zone_no}"}),
        "DROP_CABLE": Recipe("DROP_CABLE", "DR{drop}", kind="cable",
                             also_fill={"pon_no": "{pon_no}",
                                        "zone_no": "{zone_no}"}),
        "POLE": Recipe("POLE", "{stack}.P.{pnum}", kind="point",
                       label_field="label_1", auto_number=True,
                       sequence=SequenceSpec("pnum", pad=3, letter_block=True,
                                             order_by="spatial"),
                       also_fill={"pon_no": "{pon_no}",
                                  "zone_no": "{zone_no}"}),
        "MANHOLE": Recipe("MANHOLE", "{stack}.MH.{mhnum}", kind="point",
                          label_field="label_1", auto_number=True,
                          sequence=SequenceSpec("mhnum", pad=3,
                                                letter_block=True,
                                                order_by="spatial")),
        "POP": Recipe("POP", "{stack}.AGG.POP.{popnum}", kind="point",
                      auto_number=True,
                      sequence=SequenceSpec("popnum", pad=2,
                                            order_by="spatial")),
    }


def _herotel_recipes(zoned=False):
    """HeroTel OPL notation: HT_{AOI}[_Z{z}]_...  The {ht} prefix is a style
    knob (constant "HT_"; set "" for MMB-style bare labels).  Cable numbers
    ({num}) USE the existing field verbatim (Matiko "Cab name"=DC00) and
    GENERATE "DC01"-style values when empty; size/mat default to constants
    and can be re-bound to fields via field_map ({size} -> "Cable Size").
    zoned=True inserts _Z{zone} with {zone} served by a PON-zone polygon
    (falls back to the zone constant when no polygon is configured)."""
    pre = "{ht}{aoi}" + ("_Z{zone}" if zoned else "")
    pr = ["zone"] if zoned else []

    def _c(**kw):
        base = {"ht": "HT_"}
        base.update(kw)
        return base

    return {
        "PRI_CABLE": Recipe(          # feeder FC
            "PRI_CABLE", pre + "_{num}_{size}_{mat}", kind="cable",
            label_field="Name", field_map={"num": "Feeder Cab"},
            auto_number=True,
            sequence=SequenceSpec("num", prefix="FC", pad=2,
                                  order_by="spatial"),
            poly_refs=list(pr), constants=_c(size="144F", mat="Aerial"),
            host_max_m=120.0),
        "SEC_CABLE": Recipe(          # link LC (spec's "SC" — data says LC)
            "SEC_CABLE", pre + "_{num}_{size}_{mat}", kind="cable",
            label_field="Name", field_map={"num": "Feeder Cab"},
            auto_number=True,
            sequence=SequenceSpec("num", prefix="LC", pad=2,
                                  order_by="spatial"),
            poly_refs=list(pr), constants=_c(size="48F", mat="Aerial")),
        "DIST_CABLE": Recipe(         # DC — Matiko "Cab name"=DC00 used as-is
            "DIST_CABLE", pre + "_{num}_{size}_{mat}", kind="cable",
            label_field="Name", field_map={"num": "Cab name"},
            auto_number=True,
            sequence=SequenceSpec("num", prefix="DC", pad=2,
                                  scope=list(pr), order_by="spatial"),
            poly_refs=list(pr), constants=_c(size="24F", mat="Aerial")),
        "DROP_CABLE": Recipe(         # DR — one AOI-wide counter
            "DROP_CABLE", pre + "_{num}_{size}_{mat}", kind="cable",
            label_field="Name", field_map={"num": "Cab name"},
            auto_number=True,
            sequence=SequenceSpec("num", prefix="DR", pad=4,
                                  order_by="spatial"),
            poly_refs=list(pr), constants=_c(size="2F", mat="Aerial")),
        "POLE": Recipe(               # HT_{AOI}_{n:04d}PL — Matiko "Pole ID"
            "POLE", pre + "_{pnum}PL", kind="point", label_field="Name",
            field_map={"pnum": "Pole ID"}, auto_number=True,
            sequence=SequenceSpec("pnum", pad=4, order_by="spatial"),
            poly_refs=list(pr), constants=_c()),
        "ENCL_SPLICE": Recipe(        # feeder joint (1:16) — own SP sequence
            "ENCL_SPLICE", pre + "_{polenum}DJ_SP{sp}", kind="point",
            label_field="Name", auto_number=True,
            sequence=SequenceSpec("sp", pad=2, order_by="spatial"),
            poly_refs=list(pr), constants=_c()),
        "ENCL_CONN": Recipe(          # 1:8 dome — SP = PARENT 1:16 (a field)
            "ENCL_CONN", pre + "_{polenum}DJ_SP{sp}", kind="point",
            label_field="Name", field_map={"sp": "SP"},
            poly_refs=list(pr), constants=_c()),
        "MANHOLE": Recipe(            # handhole HT_{AOI}_{n:03d}MH
            "MANHOLE", pre + "_{mhnum}MH", kind="point", label_field="Name",
            auto_number=True,
            sequence=SequenceSpec("mhnum", pad=3, order_by="spatial"),
            poly_refs=list(pr), constants=_c()),
    }


def _vuma_recipes():
    """Vuma notation: hyphen short codes for assets, underscore engineering
    names with an AG polygon-name ref + chainage window for cables.  {zone}
    holds the BARE zone number ("01") — the literal Z lives in the template,
    so poles get MALM-Z01-P0001 and cables VTC_MMB_Z01_...  Slack defaults:
    +15 m distribution, +30 m feeder/link (editable per recipe)."""
    vc = {"owner": "VTN", "zone": "01"}
    tail = "_{cblcpty}F_ADSS_G.657.A1_{chainage}"
    return {
        "POLE": Recipe("POLE", "{proj}-Z{zone}-P{pnum}", kind="point",
                       label_field="Name", auto_number=True,
                       sequence=SequenceSpec("pnum", pad=4,
                                             order_by="spatial"),
                       constants=dict(vc)),
        "ENCL_CONN": Recipe(          # dome joint DJ
            "ENCL_CONN", "{proj}-Z{zone}-DJ{djnum}", kind="point",
            label_field="Name", auto_number=True,
            sequence=SequenceSpec("djnum", pad=4, order_by="spatial"),
            constants=dict(vc)),
        "DIST_CABLE": Recipe(         # DC — zone-global sequence, AG scope ref
            "DIST_CABLE", "{owner}_{town}_Z{zone}_{ag}_{dc}" + tail,
            kind="cable", label_field="Name", poly_refs=["ag"],
            auto_number=True,
            sequence=SequenceSpec("dc", prefix="DC", pad=3, scope=["zone"],
                                  order_by="spatial"),
            chainage={"slack": 15.0, "style": "(%04dm-%04dm)"},
            constants=dict(vc)),
        "SEC_CABLE": Recipe(          # link LC
            "SEC_CABLE", "{owner}_{town}_Z{zone}_{lc}" + tail,
            kind="cable", label_field="Name", auto_number=True,
            sequence=SequenceSpec("lc", prefix="LC", pad=2,
                                  order_by="spatial"),
            chainage={"slack": 30.0, "style": "(%04dm-%04dm)"},
            constants=dict(vc)),
        "PRI_CABLE": Recipe(          # feeder FC
            "PRI_CABLE", "{owner}_{town}_Z{zone}_{fc}" + tail,
            kind="cable", label_field="Name", auto_number=True,
            sequence=SequenceSpec("fc", prefix="FC", pad=3,
                                  order_by="spatial"),
            chainage={"slack": 30.0, "style": "(%04dm-%04dm)"},
            constants=dict(vc), host_max_m=120.0),
    }


RECIPE_PRESETS = {
    "Fibertime": _fibertime_recipes(),
    "Vuma": _vuma_recipes(),
    "HeroTel": _herotel_recipes(),
}

PROFILE_SCHEMA_VERSION = 1
PROFILE_REQUIRED_CONSTANTS = {
    "Fibertime": ("stack",),
    "HeroTel": ("aoi",),
    "Vuma": ("owner", "town", "proj", "zone"),
    "Custom": (),
}


def recipe_preset(client, stack=None, **project_constants):
    """A fresh editable set of recipes for a client.

    Extra keyword args become per-recipe default constants, e.g.
    recipe_preset("HeroTel", aoi="PABA2", zoned=True) or
    recipe_preset("Vuma", proj="MALM", town="MMB", zone="01", owner="VTC").
    HeroTel: pass zoned=True (or a zone=... constant) for the _Z{zone} form.
    """
    if client == "Fibertime":
        recs = _fibertime_recipes()
    elif client == "Vuma":
        recs = _vuma_recipes()
    elif client == "HeroTel":
        zoned = bool(project_constants.pop("zoned", False)
                     or "zone" in project_constants)
        recs = _herotel_recipes(zoned=zoned)
    else:
        recs = _velocity_recipes(stack or "PRJ")
    consts = {}
    if stack:
        consts["stack"] = stack
    consts.update(project_constants)
    if consts:
        for r in recs.values():
            r.constants.update(consts)
    return recs


def client_profile(client, recipes=None, constants=None, project=""):
    """Return a versioned, portable client-profile envelope.

    This is metadata around existing Recipe dictionaries only; it never
    changes recipe_preset() or any composed label.
    """
    recs = recipes if recipes is not None else recipe_preset(
        client, **dict(constants or {})
    )
    return {
        "schema_version": PROFILE_SCHEMA_VERSION,
        "client": str(client),
        "project": str(project or ""),
        "constants": dict(constants or {}),
        "recipes": {
            str(role): (
                recipe.to_dict() if isinstance(recipe, Recipe)
                else dict(recipe)
            )
            for role, recipe in recs.items()
        },
    }


def migrate_legacy_profile(payload, client="Custom", constants=None):
    """Wrap the pre-v1 ``{role: recipe_dict}`` saved-setup shape."""
    if not isinstance(payload, dict):
        return payload
    if "schema_version" in payload or "recipes" in payload:
        return dict(payload)
    return client_profile(
        client, recipes=payload, constants=dict(constants or {})
    )


def _recipe_semantic_errors(role, recipe):
    errors = []
    prefix = "recipe %s " % role
    if not isinstance(recipe.template, str) or not recipe.template.strip():
        errors.append(prefix + "template must be non-empty")
    else:
        try:
            template_tokens(recipe.template)
            for value in recipe.also_fill.values():
                template_tokens(value)
        except (ValueError, TypeError) as exc:
            errors.append(prefix + "template syntax is invalid: %s" % exc)
    if recipe.kind not in ("point", "cable"):
        errors.append(prefix + "kind must be point or cable")
    if not isinstance(recipe.label_field, str) or \
            not recipe.label_field.strip():
        errors.append(prefix + "label_field must be non-empty")
    if recipe.label_field in recipe.also_fill:
        errors.append(prefix + "also_fill duplicates label_field")
    if any(not isinstance(field, str) or not field.strip()
           for field in recipe.also_fill):
        errors.append(prefix + "also_fill field names must be non-empty")
    try:
        host_max = float(recipe.host_max_m)
        if not math.isfinite(host_max) or host_max <= 0:
            raise ValueError
    except (TypeError, ValueError):
        errors.append(prefix + "host_max_m must be greater than zero")
    if recipe.card_per <= 0:
        errors.append(prefix + "card_per must be greater than zero")
    if recipe.auto_number and recipe.sequence is None:
        errors.append(prefix + "auto_number requires a sequence")
    if recipe.sequence is not None:
        seq = recipe.sequence
        if not isinstance(seq.token, str) or not seq.token.strip():
            errors.append(prefix + "sequence token must be non-empty")
        if seq.start < 0 or seq.pad < 0 or seq.block <= 0:
            errors.append(prefix + "sequence numbers must be non-negative")
        order = str(seq.order_by or "")
        if order not in ("x", "y", "spatial", "walk") \
                and not (order.startswith("field:") and order[6:].strip()):
            errors.append(prefix + "sequence order_by is invalid")
    refs = list(recipe.poly_refs or ())
    if len(refs) != len(set(refs)) or any(
            not isinstance(ref, str) or not ref.strip() for ref in refs):
        errors.append(prefix + "poly_refs must be unique non-empty names")
    if recipe.chainage is not None and recipe.kind != "cable":
        errors.append(prefix + "chainage requires cable kind")
    return errors


def _valid_two_value_chainage_style(style):
    """True only for an old-style string with exactly two integer values."""
    if not isinstance(style, str) or not style:
        return False
    conversions = 0
    index = 0
    conversion = re.compile(r"%(?:[#0 +\-]*\d*(?:\.\d+)?)[diu]")
    while index < len(style):
        if style[index] != "%":
            index += 1
            continue
        if index + 1 < len(style) and style[index + 1] == "%":
            index += 2
            continue
        match = conversion.match(style, index)
        if match is None:
            return False
        conversions += 1
        index = match.end()
    if conversions != 2:
        return False
    try:
        rendered = style % (1, 2)
    except (TypeError, ValueError, OverflowError):
        return False
    return isinstance(rendered, str)


def _raw_recipe_errors(role, data):
    """Validate JSON shapes before constructors can normalize bad values."""
    prefix = "recipe %s " % role
    errors = []
    field_map = data.get("field_map", {})
    if not isinstance(field_map, dict):
        errors.append(prefix + "field_map must be an object")
    elif any(
            not isinstance(key, str) or not key.strip()
            or not isinstance(value, str) or not value.strip()
            for key, value in field_map.items()):
        errors.append(
            prefix + "field_map keys and values must be non-empty strings"
        )

    sequence = data.get("sequence")
    if sequence is not None:
        if not isinstance(sequence, dict):
            errors.append(prefix + "sequence must be an object")
        else:
            scope = sequence.get("scope", [])
            if not isinstance(scope, list):
                errors.append(prefix + "sequence.scope must be a list")
            elif any(
                    not isinstance(item, str) or not item.strip()
                    for item in scope) or len(scope) != len(set(scope)):
                errors.append(
                    prefix
                    + "sequence.scope must contain unique non-empty strings"
                )

    chainage = data.get("chainage")
    if chainage is not None:
        if not isinstance(chainage, dict):
            errors.append(prefix + "chainage must be an object")
        else:
            slack = chainage.get("slack", 0.0)
            if isinstance(slack, bool) or not isinstance(slack, (int, float)) \
                    or not math.isfinite(float(slack)):
                errors.append(prefix + "chainage.slack must be finite numeric")
            if not _valid_two_value_chainage_style(
                    chainage.get("style", "(%04dm-%04dm)")):
                errors.append(
                    prefix
                    + "chainage.style must contain exactly two integer "
                    "value formats"
                )
    return errors


def validate_client_profile(payload):
    """Return actionable errors; an empty list means safe to load."""
    errors = []
    if not isinstance(payload, dict):
        return ["profile must be a JSON object"]
    version = payload.get("schema_version")
    if version != PROFILE_SCHEMA_VERSION:
        errors.append(
            "profile schema version %r is not supported (expected %d)"
            % (version, PROFILE_SCHEMA_VERSION)
        )
    client = payload.get("client")
    if client not in PROFILE_REQUIRED_CONSTANTS:
        errors.append("unknown client %r" % client)
    constants = payload.get("constants")
    if not isinstance(constants, dict):
        errors.append("constants must be an object")
        constants = {}
    for key in PROFILE_REQUIRED_CONSTANTS.get(client, ()):
        if not str(constants.get(key, "")).strip():
            errors.append("missing required constant %s" % key)
    recipes = payload.get("recipes")
    if not isinstance(recipes, dict) or not recipes:
        errors.append("recipes must be a non-empty object")
        return errors
    for role, data in recipes.items():
        if not isinstance(data, dict):
            errors.append("recipe %s must be an object" % role)
            continue
        raw_errors = _raw_recipe_errors(role, data)
        errors.extend(raw_errors)
        if raw_errors:
            continue
        try:
            recipe = Recipe.from_dict(data)
        except Exception as exc:
            errors.append(
                "recipe %s is invalid: %s: %s"
                % (role, type(exc).__name__, exc)
            )
            continue
        if recipe.layer_role != role:
            errors.append(
                "recipe key %s disagrees with layer_role %s"
                % (role, recipe.layer_role)
            )
        errors.extend(_recipe_semantic_errors(role, recipe))
    return errors


def recipes_from_client_profile(payload):
    """Validate and deserialize a profile, refusing stale/invalid versions."""
    errors = validate_client_profile(payload)
    if errors:
        raise ValueError("; ".join(errors))
    return {
        role: Recipe.from_dict(data)
        for role, data in payload["recipes"].items()
    }


if __name__ == "__main__":  # self-test: recipes round-trip + token parse
    for client, recs in RECIPE_PRESETS.items():
        for role, r in recs.items():
            r2 = Recipe.from_dict(r.to_dict())
            assert r2.template == r.template and r2.also_fill == r.also_fill
            assert r2.to_dict() == r.to_dict()
            assert template_tokens(r.template)  # parses
    print("recipes OK")
