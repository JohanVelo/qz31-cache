"""backend — the ONE place that talks to Supabase (PostgREST).

QgsNetworkAccessManager + QNetworkRequest + JSON. No pip libraries. Every
write is fire-and-forget and NEVER blocks the UI. In dry-run mode (default
until the backend is configured) nothing is POSTed — records go to the spool.

Writes use the shipped ANON key: plain INSERT (insert-only RLS) + a filtered
PATCH for presence (update()). NO upsert — ON CONFLICT needs a SELECT grant
the anon role must not have. The admin SELECTs (Team Monitor) use the owner
read-key, passed in explicitly and never shipped.
"""
import json
import uuid

from . import config, spool


def _delivered(reply):
    """Classify a finished reply for spool purposes. True = stop retrying
    (the server gave a final answer: 2xx delivered, 3xx, or 4xx incl. 409
    duplicate). False = keep spooled (no response → offline, or 5xx transient).
    Status read cross-version-safely via the HTTP status attribute."""
    try:
        from qgis.PyQt.QtNetwork import QNetworkRequest
        code = reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute)
        if code is None:
            return False                 # transport failure (offline)
        return int(code) < 500           # 5xx → transient, keep for retry
    except Exception:
        return False


def _net_ok(reply):
    """True only if the reply came back with NO network-level error.

    Why this exists: on Qt6 `reply.error()` is a SCOPED enum (QNetworkReply.
    NetworkError) and int() on it raises TypeError. The old int()-on-the-enum
    check therefore blew up INSIDE the try, the bare
    `except` swallowed it, and the callback reported failure every single time —
    silently killing check_active() (so a deactivated account was never learned,
    and self_destruct could never arm) and the Team Monitor admin calls, for the
    whole Qt6 era. The identical bug was diagnosed and fixed in update_check.py
    on 2026-06-25; these call sites were missed. See
    [[reference_qt6_enum_int_inconsistent_2026-07-15]] — int() on a QGIS/Qt enum
    is class-dependent, so compare the enum, never convert it.

    Cross-version, in this order — do NOT reorder:
      1. int-ish (Qt5's sip enum IS an int subclass)     -> compare to 0
      2. Qt6 scoped enum                                  -> compare enum-to-enum
      3. anything else with a .value                      -> read it
      4. otherwise                                        -> False
    Step 1 must come first: an int NEVER equals an Enum member, so comparing a Qt5
    int error() against a Qt6 enum member would report a SUCCESSFUL reply as failed.
    Anything undeterminable returns False — never a false success.
    """
    try:
        e = reply.error()
    except Exception:
        return False
    if isinstance(e, int):                     # Qt5 (and any int-ish error code)
        return e == 0
    try:                                       # Qt6 scoped enum
        from qgis.PyQt.QtNetwork import QNetworkReply
        return e == QNetworkReply.NetworkError.NoError
    except Exception:
        pass
    try:
        return int(getattr(e, "value", -1)) == 0
    except Exception:
        return False


def _plugin_version():
    try:
        import os
        import re
        here = os.path.dirname(os.path.abspath(__file__))
        mp = os.path.normpath(os.path.join(here, "..", "..", "metadata.txt"))
        with open(mp, encoding="utf-8") as f:
            m = re.search(r"^version=(\S+)", f.read(), flags=re.M)
        return m.group(1) if m else "?"
    except Exception:
        return "?"


def get_user_token():
    """The per-user token from /plugin-login (QgsSettings), or '' if not logged in."""
    try:
        from qgis.core import QgsSettings
        return QgsSettings().value(
            f"{config.SETTINGS_NS}/{config.KEY_USER_TOKEN}", "", type=str) or ""
    except Exception:
        return ""


def set_user_token(tok):
    try:
        from qgis.core import QgsSettings
        QgsSettings().setValue(
            f"{config.SETTINGS_NS}/{config.KEY_USER_TOKEN}", tok or "")
    except Exception:
        pass


class Backend:
    """One instance, dependency-injected so dry-run is trivial.

    data_dir   : portable scratch dir (vf_paths.data_dir())
    dry_run    : when True, writes go to the spool only (no network)
    """

    def __init__(self, data_dir, dry_run=None):
        self.data_dir = data_dir
        if dry_run is None:
            dry_run = config.DRY_RUN_DEFAULT or not config.is_backend_configured()
        self.dry_run = dry_run
        self.version = _plugin_version()
        self._ua = f"VelocityNexus/{self.version} (QGIS)".encode()
        # idempotency keys currently posted-but-not-yet-acked, so flush() can't
        # re-fire a record that's still in flight from the previous tick (which
        # would stack many concurrent replies during a long offline stretch).
        self._inflight = set()

    # ── writes (anon key) ───────────────────────────────────────────────────
    # NOTE: NO upsert. PostgREST upsert (ON CONFLICT) needs a SELECT grant the
    # anon role must NOT have (insert-only RLS is the whole security model), so
    # it fails with 42501. Presence is created once (insert) and refreshed with
    # update() (a plain filtered PATCH, which RLS allows).
    def insert(self, table, payload, spool_it=True):
        """Queue+send one plain INSERT. Returns the idempotency key. Never
        raises, never blocks. spool_it=False for best-effort 'ensure row'
        writes that needn't survive a restart (a re-insert just 409s)."""
        idem = str(uuid.uuid4())
        payload = dict(payload)
        if table in ("events", "errors"):
            payload.setdefault("idempotency_key", idem)
        prefer = "return=minimal"
        if spool_it:
            # spool first (crash-safe); the record is removed ONLY when the
            # server confirms delivery — so an offline send stays queued.
            spool.append(self.data_dir, table, payload, idem, prefer)
            spool.enforce_cap(self.data_dir, config.SPOOL_MAX_BYTES)
        if not self.dry_run:
            self._post(table, payload, prefer,
                       on_done=(lambda ok: self._on_sent(idem, ok))
                       if spool_it else None)
        return idem

    def _on_sent(self, idem, delivered):
        """Drop a spooled record only on confirmed delivery (keeps it for retry
        when offline / on a 5xx)."""
        if idem:
            self._inflight.discard(idem)   # reply settled — free it for retry
        if delivered and idem:
            try:
                spool.remove(self.data_dir, idem)
            except Exception:
                pass

    def update(self, table, match, payload):
        """Plain filtered PATCH (anon UPDATE policy allows it). Used to refresh
        presence (installs.last_heartbeat). Fire-and-forget; never spooled —
        presence is ephemeral, the next heartbeat supersedes a missed one."""
        if self.dry_run:
            return
        self._patch(f"{table}?{match}", payload)

    # ── flush the spool (called on a timer + on reconnect) ──────────────────
    def flush(self):
        if self.dry_run or not config.is_backend_configured():
            return
        # Re-send each spooled record; the per-record reply handler removes it
        # from the spool ONLY on confirmed delivery (idempotency_key dedupes a
        # resend server-side). Offline / 5xx → it stays queued for next time.
        for r in spool.read_all(self.data_dir):
            idem = r.get("idem")
            if idem:
                if idem in self._inflight:
                    continue            # still posting from a previous tick
                self._inflight.add(idem)
            self._post(r["table"], r["payload"], r.get("prefer"),
                       on_done=(lambda ok, i=idem: self._on_sent(i, ok))
                       if idem else None)

    # ── low-level POST (async, fire-and-forget) ─────────────────────────────
    def _post(self, table, payload, prefer=None, on_done=None):
        """POST async. on_done(delivered: bool) fires when the reply finishes —
        delivered=True means 'stop retrying' (2xx/3xx/4xx incl. 409 dup);
        False means offline/transport-fail or 5xx (keep spooled)."""
        try:
            from qgis.core import QgsNetworkAccessManager
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtNetwork import QNetworkRequest
        except Exception:
            if on_done:
                on_done(False)
            return False
        url = f"{config.SUPABASE_URL}/rest/v1/{table}"
        req = QNetworkRequest(QUrl(url))
        try:
            req.setTransferTimeout(15000)   # Qt 5.15+: never hang on a dead socket
        except Exception:
            pass
        req.setHeader(QNetworkRequest.KnownHeaders.ContentTypeHeader, "application/json")
        req.setRawHeader(b"apikey", config.SUPABASE_ANON_KEY.encode())
        req.setRawHeader(b"Authorization",
                         f"Bearer {config.SUPABASE_ANON_KEY}".encode())
        req.setRawHeader(b"User-Agent", self._ua)
        if prefer:
            req.setRawHeader(b"Prefer", prefer.encode())
        body = json.dumps(payload).encode("utf-8")
        try:
            nam = QgsNetworkAccessManager.instance()
            try:
                nam.setAutoDeleteReplies(True)   # Qt 5.14+: clean reply lifecycle
            except Exception:
                pass
            reply = nam.post(req, body)

            def _finished(r=reply):
                try:
                    if on_done is not None:
                        on_done(_delivered(r))
                finally:
                    self._safe_delete(r)
            reply.finished.connect(_finished)
            return True
        except Exception:
            if on_done:
                on_done(False)
            return False        # network stack unavailable — keep in spool

    def _patch(self, path, payload):
        """Filtered PATCH (anon UPDATE). Async, fire-and-forget."""
        try:
            from qgis.core import QgsNetworkAccessManager
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtNetwork import QNetworkRequest
        except Exception:
            return
        req = QNetworkRequest(QUrl(f"{config.SUPABASE_URL}/rest/v1/{path}"))
        try:
            req.setTransferTimeout(15000)   # Qt 5.15+: never hang on a dead socket
        except Exception:
            pass
        req.setHeader(QNetworkRequest.KnownHeaders.ContentTypeHeader, "application/json")
        req.setRawHeader(b"apikey", config.SUPABASE_ANON_KEY.encode())
        req.setRawHeader(b"Authorization",
                         f"Bearer {config.SUPABASE_ANON_KEY}".encode())
        req.setRawHeader(b"User-Agent", self._ua)
        req.setRawHeader(b"Prefer", b"return=minimal")
        body = json.dumps(payload).encode("utf-8")
        try:
            nam = QgsNetworkAccessManager.instance()
            try:
                nam.setAutoDeleteReplies(True)
            except Exception:
                pass
            reply = nam.sendCustomRequest(req, b"PATCH", body)
            reply.finished.connect(lambda r=reply: self._safe_delete(r))
        except Exception:
            pass

    @staticmethod
    def _safe_delete(reply):
        try:
            reply.deleteLater()
        except Exception:
            pass

    def check_active(self, username, callback):
        """Ask the server if this account is still active (anon RPC
        is_user_active). callback(True/False) on a clear answer, callback(None)
        on offline/error (caller treats None as 'no change')."""
        if not username:
            callback(None)
            return
        try:
            from qgis.core import QgsNetworkAccessManager
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtNetwork import QNetworkRequest
        except Exception:
            callback(None)
            return
        req = QNetworkRequest(QUrl(f"{config.SUPABASE_URL}/rest/v1/rpc/is_user_active"))
        try:
            req.setTransferTimeout(15000)
        except Exception:
            pass
        req.setHeader(QNetworkRequest.KnownHeaders.ContentTypeHeader, "application/json")
        req.setRawHeader(b"apikey", config.SUPABASE_ANON_KEY.encode())
        req.setRawHeader(b"Authorization",
                         f"Bearer {config.SUPABASE_ANON_KEY}".encode())
        req.setRawHeader(b"User-Agent", self._ua)
        body = json.dumps({"u": username}).encode("utf-8")
        try:
            reply = QgsNetworkAccessManager.instance().post(req, body)

            def _done(r=reply):
                try:
                    if not _net_ok(r):
                        callback(None)
                    else:
                        txt = bytes(r.readAll()).decode("utf-8", "replace").strip()
                        callback(True if txt == "true"
                                 else False if txt == "false" else None)
                except Exception:
                    callback(None)
                finally:
                    self._safe_delete(r)

            reply.finished.connect(_done)
        except Exception:
            callback(None)

    def upload_bytes(self, data, ext, content_type, bucket="ticket-shots",
                     subdir="tickets", filename=None):
        """Upload arbitrary bytes to a PUBLIC Storage bucket with the anon key and
        return the public URL (or None). Used for ticket screenshots (PNG) and
        long-error PDFs so Telegram can fetch them by URL. Synchronous, never
        raises, dry-run / unconfigured → None.

        filename: optional human-readable basename (no extension). When given,
        the object is stored at `<subdir>/<uuid>/<slug>.<ext>` so the file's
        BASENAME stays clean — Telegram derives the document name from the URL's
        last segment, so a dragged-out PDF lands in VS Code named after the
        ticket title instead of a raw uuid. The uuid folder keeps paths unique.

        NOTE: no x-upsert header — upsert needs an UPDATE policy the anon role
        lacks (→ 403 RLS). Each path is a fresh uuid, so a plain insert never
        conflicts."""
        if self.dry_run or not data:
            return None
        try:
            import urllib.request
            import re as _re
            import uuid as _uuid
            if filename:
                slug = _re.sub(r"[^A-Za-z0-9._-]+", "-",
                               str(filename).strip()).strip("-._")[:60] or "ticket"
                path = f"{subdir}/{_uuid.uuid4().hex}/{slug}.{ext}"
            else:
                path = f"{subdir}/{_uuid.uuid4().hex}.{ext}"
            url = f"{config.SUPABASE_URL}/storage/v1/object/{bucket}/{path}"
            req = urllib.request.Request(url, data=bytes(data), method="POST")
            req.add_header("apikey", config.SUPABASE_ANON_KEY)
            req.add_header("Authorization", f"Bearer {config.SUPABASE_ANON_KEY}")
            req.add_header("Content-Type", content_type)
            with urllib.request.urlopen(req, timeout=20) as r:
                if 200 <= getattr(r, "status", r.getcode()) < 300:
                    return (f"{config.SUPABASE_URL}/storage/v1/object/public/"
                            f"{bucket}/{path}")
        except Exception:
            pass
        return None

    def upload_screenshot(self, png_bytes, bucket="ticket-shots"):
        """Back-compat wrapper — upload a PNG screenshot, return its public URL."""
        return self.upload_bytes(png_bytes, "png", "image/png", bucket)

    def plugin_login(self, username, password, callback):
        """Verify username+password at the edge fn and store a per-user token.
        callback(ok: bool, display_name|None). The token then authenticates the
        my_* reads so identity is server-verified, not a spoofable param."""
        if not username or not password:
            callback(False, None)
            return
        try:
            from qgis.core import QgsNetworkAccessManager
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtNetwork import QNetworkRequest
        except Exception:
            callback(False, None)
            return
        req = QNetworkRequest(QUrl(f"{config.FUNCTIONS_URL}/plugin-login"))
        try:
            req.setTransferTimeout(15000)
        except Exception:
            pass
        req.setHeader(QNetworkRequest.KnownHeaders.ContentTypeHeader, "application/json")
        req.setRawHeader(b"apikey", config.SUPABASE_ANON_KEY.encode())
        req.setRawHeader(b"Authorization", f"Bearer {config.SUPABASE_ANON_KEY}".encode())
        req.setRawHeader(b"User-Agent", self._ua)
        body = json.dumps({"username": username, "password": password}).encode("utf-8")
        try:
            reply = QgsNetworkAccessManager.instance().post(req, body)

            def _done(r=reply):
                try:
                    txt = bytes(r.readAll()).decode("utf-8", "replace")
                    data = json.loads(txt) if txt.strip() else {}
                    tok = data.get("token") if isinstance(data, dict) else None
                    if tok:
                        set_user_token(tok)
                        callback(True, data.get("display_name") or username)
                    else:
                        callback(False, None)
                except Exception:
                    callback(False, None)
                finally:
                    self._safe_delete(r)

            reply.finished.connect(_done)
        except Exception:
            callback(False, None)

    def _post_fn(self, path, payload, callback):
        """POST JSON to a FUNCTIONS_URL endpoint with the gateway anon key.
        callback(data_dict | None). Used for the unauthenticated reset endpoints."""
        try:
            from qgis.core import QgsNetworkAccessManager
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtNetwork import QNetworkRequest
        except Exception:
            callback(None)
            return
        req = QNetworkRequest(QUrl(f"{config.FUNCTIONS_URL}{path}"))
        try:
            req.setTransferTimeout(15000)
        except Exception:
            pass
        req.setHeader(QNetworkRequest.KnownHeaders.ContentTypeHeader, "application/json")
        req.setRawHeader(b"apikey", config.SUPABASE_ANON_KEY.encode())
        req.setRawHeader(b"Authorization", f"Bearer {config.SUPABASE_ANON_KEY}".encode())
        req.setRawHeader(b"User-Agent", self._ua)
        try:
            reply = QgsNetworkAccessManager.instance().post(
                req, json.dumps(payload).encode("utf-8"))

            def _done(r=reply):
                try:
                    txt = bytes(r.readAll()).decode("utf-8", "replace")
                    callback(json.loads(txt) if txt.strip() else {})
                except Exception:
                    callback(None)
                finally:
                    self._safe_delete(r)

            reply.finished.connect(_done)
        except Exception:
            callback(None)

    def request_reset(self, username, callback):
        """Ask the owner to issue a reset code. callback(message_str). Account-
        enumeration-safe: the server returns the same message regardless."""
        def _cb(data):
            msg = (data or {}).get("message") if isinstance(data, dict) else None
            callback(msg or "If that account exists, the owner has been notified. "
                            "Ask JJ for your reset code.")
        self._post_fn("/request-reset", {"username": username}, _cb)

    def redeem_reset(self, username, code, pw_hash, pw_salt, callback):
        """Redeem an owner-issued reset code + set a NEW (already client-hashed)
        password. callback(ok: bool, display_name|error_msg). Stores the token on
        success so the user is signed straight in."""
        def _cb(data):
            if not isinstance(data, dict):
                callback(False, "Could not reach the server — try again.")
                return
            tok = data.get("token")
            if tok:
                set_user_token(tok)
                callback(True, data.get("display_name") or username)
            else:
                callback(False, data.get("error") or "Invalid or expired reset code.")
        self._post_fn("/redeem-reset", {
            "username": username, "code": code,
            "pw_hash": pw_hash, "pw_salt": pw_salt}, _cb)

    def _authed_reply(self, method, path, body=None):
        """Build+fire a QNetworkReply to a FUNCTIONS_URL endpoint with the gateway
        anon key + the per-user X-User-Token. Returns the reply (or None)."""
        tok = get_user_token()
        if not tok:
            return None
        try:
            from qgis.core import QgsNetworkAccessManager
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtNetwork import QNetworkRequest
        except Exception:
            return None
        req = QNetworkRequest(QUrl(f"{config.FUNCTIONS_URL}{path}"))
        try:
            req.setTransferTimeout(15000)
        except Exception:
            pass
        req.setHeader(QNetworkRequest.KnownHeaders.ContentTypeHeader, "application/json")
        req.setRawHeader(b"apikey", config.SUPABASE_ANON_KEY.encode())
        req.setRawHeader(b"Authorization", f"Bearer {config.SUPABASE_ANON_KEY}".encode())
        req.setRawHeader(b"X-User-Token", tok.encode())
        req.setRawHeader(b"User-Agent", self._ua)
        try:
            nam = QgsNetworkAccessManager.instance()
            if method == "POST":
                return nam.post(req, body if body is not None else b"{}")
            return nam.get(req)
        except Exception:
            return None

    def my_resolved_tickets(self, username, callback):
        """THIS user's resolved tickets. Token-first (server-verified identity via
        /my-resolved); falls back to the anon RPC during the migration grace
        period if the user hasn't logged in yet. callback(list|[]|None)."""
        reply = self._authed_reply("POST", "/my-resolved", b"{}")
        if reply is not None:
            def _done(r=reply):
                try:
                    from qgis.PyQt.QtNetwork import QNetworkRequest
                    code = r.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute)
                    if code == 401:           # token missing/expired -> clear + fall back
                        set_user_token("")
                        self._safe_delete(r)
                        self._resolved_anon(username, callback)
                        return
                    txt = bytes(r.readAll()).decode("utf-8", "replace")
                    callback(json.loads(txt) if txt.strip() else [])
                except Exception:
                    callback(None)
                finally:
                    self._safe_delete(r)
            try:
                reply.finished.connect(_done)
            except Exception:
                self._resolved_anon(username, callback)
            return
        self._resolved_anon(username, callback)

    def _resolved_anon(self, username, callback):
        """Anon RPC fallback (grace): SECURITY DEFINER filters by username, but the
        username is caller-supplied — superseded by the token path above."""
        if not username:
            callback(None)
            return
        try:
            from qgis.core import QgsNetworkAccessManager
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtNetwork import QNetworkRequest
        except Exception:
            callback(None)
            return
        req = QNetworkRequest(
            QUrl(f"{config.SUPABASE_URL}/rest/v1/rpc/my_resolved_tickets"))
        try:
            req.setTransferTimeout(15000)
        except Exception:
            pass
        req.setHeader(QNetworkRequest.KnownHeaders.ContentTypeHeader,
                      "application/json")
        req.setRawHeader(b"apikey", config.SUPABASE_ANON_KEY.encode())
        req.setRawHeader(b"Authorization",
                         f"Bearer {config.SUPABASE_ANON_KEY}".encode())
        req.setRawHeader(b"User-Agent", self._ua)
        body = json.dumps({"u": username}).encode("utf-8")
        try:
            reply = QgsNetworkAccessManager.instance().post(req, body)

            def _done(r=reply):
                try:
                    if not _net_ok(r):
                        callback(None)
                    else:
                        txt = bytes(r.readAll()).decode("utf-8", "replace")
                        callback(json.loads(txt) if txt.strip() else [])
                except Exception:
                    callback(None)
                finally:
                    self._safe_delete(r)

            reply.finished.connect(_done)
        except Exception:
            callback(None)

    # ── admin reads (owner read-key; never shipped) ─────────────────────────
    def admin_get(self, query, admin_key, callback):
        """GET .../rest/v1/<query> with the owner key; callback(list|None).
        Used only by the Team Monitor on JJ's machine."""
        try:
            from qgis.core import QgsNetworkAccessManager
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtNetwork import QNetworkRequest
        except Exception:
            callback(None)
            return
        req = QNetworkRequest(QUrl(f"{config.SUPABASE_URL}/rest/v1/{query}"))
        req.setRawHeader(b"apikey", admin_key.encode())
        req.setRawHeader(b"Authorization", f"Bearer {admin_key}".encode())
        req.setRawHeader(b"User-Agent", self._ua)
        try:
            reply = QgsNetworkAccessManager.instance().get(req)

            def _done(r=reply):
                try:
                    if not _net_ok(r):
                        callback(None)
                    else:
                        callback(json.loads(
                            bytes(r.readAll()).decode("utf-8", "replace")))
                except Exception:
                    callback(None)
                finally:
                    self._safe_delete(r)

            reply.finished.connect(_done)
        except Exception:
            callback(None)

    def admin_count(self, query, admin_key, callback):
        """Exact row count for `query` via PostgREST; callback(int|None).

        Asks for a single row with `Prefer: count=exact` and reads the total off
        the Content-Range header (`0-0/6906`). Cheap — the count is computed
        server-side and no row payload comes back.

        callback(None) means the count is UNKNOWN (offline, or the header was
        missing/unparseable). Callers must render that as unknown; reporting an
        unknown total as 0 is the bug this whole path exists to stop."""
        try:
            from qgis.core import QgsNetworkAccessManager
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtNetwork import QNetworkRequest
        except Exception:
            callback(None)
            return
        req = QNetworkRequest(QUrl(f"{config.SUPABASE_URL}/rest/v1/{query}"))
        req.setRawHeader(b"apikey", admin_key.encode())
        req.setRawHeader(b"Authorization", f"Bearer {admin_key}".encode())
        req.setRawHeader(b"User-Agent", self._ua)
        req.setRawHeader(b"Prefer", b"count=exact")
        req.setRawHeader(b"Range-Unit", b"items")
        req.setRawHeader(b"Range", b"0-0")
        try:
            reply = QgsNetworkAccessManager.instance().get(req)

            def _done(r=reply):
                total = None
                try:
                    if _net_ok(r):
                        # "items 0-0/6906" or "0-0/6906" -> 6906; "*/*" -> unknown
                        cr = bytes(r.rawHeader(b"Content-Range")).decode(
                            "utf-8", "replace")
                        tail = cr.rsplit("/", 1)[-1].strip() if "/" in cr else ""
                        if tail.isdigit():
                            total = int(tail)
                except Exception:
                    total = None
                try:
                    callback(total)
                finally:
                    self._safe_delete(r)

            reply.finished.connect(_done)
        except Exception:
            callback(None)
