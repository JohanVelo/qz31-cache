"""Pass 5 (Manual Override) — pure, unit-testable helpers for the edit summary
shown after a splitter- or demand-point reassignment.

The reassignment logic itself (``apply_demand_change`` and the splitter-zone apply
in ``on_manual_override_clicked``) is NOT touched — every layer write, the drop
regen and the undo snapshot stay exactly as they are. These helpers only turn the
facts the handler already has (how many moved, source → target, each PON boundary's
count before → after, cables rerouted) into clean summary lines, plus a couple of
quality flags so the planner can spot an over-capacity splitter or an emptied PON at
a glance. No QGIS objects — fully testable on its own.
"""

# Combo-1 informal-settlement splitter fan-out: one FTS (1:16) feeds sixteen
# STS (1:8) → 128 drops max per splitter. A reassignment that pushes a target
# splitter past this is worth flagging (the write still happens — this only warns).
DEFAULT_CAP = 128


def _arrow(before, after):
    """One 'before → after' fragment; '(new)' when there was no prior count."""
    if before is None:
        return f"(new) {int(after)}"
    return f"{int(before)} → {int(after)}"


def boundary_delta_lines(deltas):
    """``deltas``: list of dicts with keys ``pon``, ``before`` (int or None),
    ``after`` (int). Returns one indented line per PON, marking an emptied PON."""
    out = []
    for d in deltas or []:
        pon = d.get("pon", "?")
        before = d.get("before")
        after = int(d.get("after", 0) or 0)
        if after == 0:
            out.append(f"    PON {pon}: {_arrow(before, after)} — now empty")
        else:
            out.append(f"    PON {pon}: {_arrow(before, after)}")
    return out


def capacity_flags(target_group, target_drop_count, cap=DEFAULT_CAP):
    """Warn when the target splitter is at/over its port budget after the move.
    Returns [] when comfortably under. ``target_drop_count`` is the post-move count."""
    n = int(target_drop_count or 0)
    cap = int(cap or DEFAULT_CAP)
    if n > cap:
        return [f"  ⚠ Splitter {target_group} now {n} drops — OVER the {cap}-port cap"]
    if n >= int(cap * 0.9):
        return [f"  ⚠ Splitter {target_group} now {n}/{cap} drops — near capacity"]
    return []


def reassign_summary(kind, n_moved, src, dst, boundary_deltas=None,
                     cables=None, flags=None):
    """Compose the full multi-line edit summary.

    kind: "demand point" or "splitter" (pluralised automatically).
    n_moved: how many features moved. src/dst: human strings (e.g. "Splitter 3 / PON 1").
    boundary_deltas: list of {pon, before, after}. cables: int rerouted or None.
    flags: extra warning lines (e.g. from ``capacity_flags``).
    Returns list[str].
    """
    n = int(n_moved or 0)
    noun = kind + ("s" if n != 1 else "")
    lines = ["── Manual Override — edit summary ─────────────",
             f"  Moved {n} {noun}: {src} → {dst}"]
    b_lines = boundary_delta_lines(boundary_deltas)
    if b_lines:
        lines.append("  PON boundary counts:")
        lines.extend(b_lines)
    if cables is not None and int(cables) > 0:
        lines.append(f"  Drop cables rerouted: {int(cables)}")
    for f in (flags or []):
        lines.append(f)
    return lines
