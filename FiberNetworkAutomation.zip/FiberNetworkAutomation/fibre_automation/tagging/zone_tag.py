"""zone_tag — tag features with the PON / Phase (or any polygon) they fall inside.

Answers "which PON does this cable run through?" as a real, filterable attribute
column instead of a manual click-around on the canvas.

Design rules (match ``boq/takeoff.py``):
  * SCHEMA-AGNOSTIC — the caller names the polygon layer + the field that supplies
    the value, so this works for Fibertime ``PON v1``.pon_no, HeroTel ``Pons``.PON,
    ``Phases``."Phase Num" or any other client's areas.
  * TWO PHASES — ``build_plan`` only READS (it is safe to run on client data and
    is what the dialog previews); ``apply_plan`` is the ONLY writer.
  * HONEST — a feature outside every polygon gets NULL and is counted as
    "outside". It is never snapped to the nearest polygon.
  * NO Qt AT MODULE LEVEL — pure + unit-testable; qgis imports are function-local.

Geometry rules (JJ's call, 2026-07-15):
  * point / polygon target → containment of its point-on-surface → ONE value.
    An erf or a pole belongs to exactly one PON.
  * line target → EVERY polygon it genuinely runs through, joined ", ".
    A 1976 m feeder really does serve several PONs; collapsing that to one lies.
    "Genuinely" = at least ``_MIN_SHARED_M`` metres of the line lies inside —
    without that guard a cable collects a phantom PON from every polygon corner
    it grazes, and the column stops being trustworthy.
"""

# Minimum length (m) a line must run INSIDE a polygon before that polygon is
# listed. Guards against corner-clips. See module docstring.
_MIN_SHARED_M = 1.0

# ESRI Shapefile truncates field names to 10 chars; we surface the truncated name
# to the user rather than let the .dbf surprise them later.
_SHP_FIELD_MAX = 10

# Value used in the plan for "inside no polygon at all".
OUTSIDE = None

_STRING_TYPE_NAMES = ("string", "text", "varchar", "qstring", "character")


# ── small helpers ────────────────────────────────────────────────────────────
def _rep_point(geom):
    """A representative point for a geometry (point/line/polygon), or None.

    Same convention as ``takeoff._rep_point``: pointOnSurface is guaranteed to
    fall INSIDE a concave polygon, where centroid is not.
    """
    if geom is None or geom.isEmpty():
        return None
    try:
        pt = geom.pointOnSurface()
        if pt is None or pt.isEmpty():
            pt = geom.centroid()
        return None if (pt is None or pt.isEmpty()) else pt
    except Exception:
        return None


def _norm_value(v):
    """Attribute → display string, or None for NULL/blank."""
    if v is None:
        return None
    try:
        from qgis.PyQt.QtCore import QVariant
        if isinstance(v, QVariant) and v.isNull():
            return None
    except Exception:
        pass
    s = str(v).strip()
    if not s or s.lower() == "null":
        return None
    return s


def _natural_key(s):
    """Sort key so P003 < P004 < P013 (not P003 < P013 < P004)."""
    import re
    out = []
    for part in re.split(r"(\d+)", str(s)):
        if part.isdigit():
            out.append((1, int(part), ""))
        elif part:
            out.append((0, 0, part.lower()))
    return out


def sanitize_field_name(name, shapefile=False):
    """A safe attribute name: alnum + underscore, never leading-digit, ≤10 for .shp."""
    import re
    s = re.sub(r"[^0-9A-Za-z_]+", "_", str(name or "").strip()).strip("_")
    if not s:
        s = "zone"
    if s[0].isdigit():
        s = "f_" + s
    if shapefile:
        s = s[:_SHP_FIELD_MAX]
    return s


def is_shapefile(layer):
    try:
        return "shapefile" in (layer.dataProvider().storageType() or "").lower()
    except Exception:
        return False


def _field_lookup(layer, name):
    """Real field name matching ``name`` case-insensitively, else None."""
    want = str(name).lower()
    for f in layer.fields():
        if f.name().lower() == want:
            return f.name()
    return None


def _is_string_field(field):
    try:
        return any(t in (field.typeName() or "").lower() for t in _STRING_TYPE_NAMES)
    except Exception:
        return False


def _crs_key(crs):
    """A key that is unique per CRS.

    NOT authid() alone: a CUSTOM CRS reports authid() == '', so two different
    custom-CRS polygon layers would collide on '' and the second would silently
    reuse the first's transform — putting features in the wrong zone with no
    error. Fall back to the WKT, which is always distinct.
    """
    try:
        return crs.authid() or crs.toWkt()
    except Exception:
        return repr(crs)


def _measurer(crs, project):
    """QgsDistanceArea measuring geodesic metres in ``crs`` (4326-degree-safe)."""
    from qgis.core import QgsDistanceArea
    da = QgsDistanceArea()
    try:
        da.setSourceCrs(crs, project.transformContext())
        da.setEllipsoid(project.ellipsoid() or "WGS84")
    except Exception:
        pass
    return da


def _shared_length_m(poly_geom, line_geom, da):
    """Metres of ``line_geom`` lying inside ``poly_geom``. 0.0 on any failure."""
    import math
    try:
        inter = poly_geom.intersection(line_geom)
        if inter is None or inter.isEmpty():
            return 0.0
        v = da.measureLength(inter)
        return v if (v is not None and math.isfinite(v) and v >= 0) else 0.0
    except Exception:
        return 0.0


# ── polygon index ────────────────────────────────────────────────────────────
class _PolyIndex:
    """Spatial index + prepared engines over one polygon layer.

    Prepared geometry engines matter: ``drops`` is 3618 features and this runs on
    the Qt main thread — an unprepared contains() per candidate would stall QGIS
    (that bug class has frozen us twice before).
    """

    def __init__(self, layer, value_field, project):
        from qgis.core import QgsSpatialIndex, QgsFeature
        self.name = layer.name()
        self.field = value_field
        self.crs = layer.crs()
        self.project = project
        self._geoms = {}
        self._vals = {}
        self._engines = {}
        self._da = _measurer(self.crs, project)
        real = _field_lookup(layer, value_field)
        feats = []
        for f in layer.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            fid = f.id()
            self._geoms[fid] = g
            self._vals[fid] = _norm_value(f[real]) if real else None
            nf = QgsFeature(fid)
            nf.setGeometry(g)
            feats.append(nf)
        self.index = QgsSpatialIndex()
        for nf in feats:
            self.index.addFeature(nf)

    def __len__(self):
        return len(self._geoms)

    def _engine(self, fid):
        eng = self._engines.get(fid)
        if eng is None:
            from qgis.core import QgsGeometry
            eng = QgsGeometry.createGeometryEngine(self._geoms[fid].constGet())
            eng.prepareGeometry()
            self._engines[fid] = eng
        return eng

    def value_at_point(self, point_geom):
        """Value of the polygon containing ``point_geom`` (already in self.crs)."""
        if point_geom is None or point_geom.isEmpty():
            return None
        for fid in self.index.intersects(point_geom.boundingBox()):
            if self._engine(fid).contains(point_geom.constGet()):
                return self._vals.get(fid)
        return None

    def values_along_line(self, line_geom):
        """Sorted values of every polygon the line runs ≥ _MIN_SHARED_M inside."""
        if line_geom is None or line_geom.isEmpty():
            return []
        found = set()
        for fid in self.index.intersects(line_geom.boundingBox()):
            val = self._vals.get(fid)
            if val is None or val in found:
                continue
            if not self._engine(fid).intersects(line_geom.constGet()):
                continue
            if _shared_length_m(self._geoms[fid], line_geom, self._da) >= _MIN_SHARED_M:
                found.add(val)
        return sorted(found, key=_natural_key)


# ── plan containers ──────────────────────────────────────────────────────────
class TagSpec:
    """One "tag WITH this polygon layer" instruction."""

    def __init__(self, poly_layer_id, value_field, out_field):
        self.poly_layer_id = poly_layer_id
        self.value_field = value_field
        self.out_field = out_field
        self.poly_name = ""      # filled by build_plan (display only)

    def __repr__(self):   # pragma: no cover - debug aid
        return f"TagSpec({self.poly_name or self.poly_layer_id}.{self.value_field} → {self.out_field})"


class TagPlan:
    """What WOULD be written. Produced by build_plan; consumed by apply_plan."""

    SAMPLE_CAP = 200      # on-screen preview rows per layer; the plan holds all

    def __init__(self):
        self.specs = []
        self.rows = {}          # layer_id -> {fid: {out_field: value|None}}
        self.stats = {}         # layer_id -> {out_field: {total, tagged, outside}}
        self.layer_names = {}   # layer_id -> name
        self.out_fields = {}    # layer_id -> [out_field, ...] (ordered)
        self.samples = {}       # layer_id -> [{"label":…, out_field: val, …}]
        self.warnings = []
        self.errors = []
        self.elapsed_s = 0.0

    @property
    def total_features(self):
        return sum(len(r) for r in self.rows.values())

    def summary_lines(self):
        """Human "layer · n features · x tagged · y outside" lines."""
        out = []
        for lid, name in self.layer_names.items():
            per = self.stats.get(lid, {})
            for fld, st in per.items():
                bit = f"{name} · {st['total']} features · {st['tagged']} tagged"
                if st["outside"]:
                    bit += f" · {st['outside']} outside every polygon"
                out.append(f"{bit}  →  `{fld}`")
        return out


class ApplyResult:
    def __init__(self):
        self.written = {}      # layer_id -> features changed
        self.fields_added = [] # "layer.field" strings
        self.skipped = []      # honest per-layer reasons
        self.errors = []
        self.layer_names = {}

    @property
    def ok(self):
        return not self.errors

    @property
    def total_written(self):
        return sum(self.written.values())


# ── label guessing (for the preview table only) ──────────────────────────────
_LABEL_FIELDS = ("name", "name.", "label", "label.", "id", "fid",
                 "descriptio", "description")


def _label_field(layer):
    lut = {f.name().lower(): f.name() for f in layer.fields()}
    for c in _LABEL_FIELDS:
        if c in lut:
            return lut[c]
    flds = layer.fields()
    return flds[0].name() if len(flds) else None


# ── build (READ-ONLY) ────────────────────────────────────────────────────────
def build_plan(project, specs, target_layer_ids):
    """Compute what every selected feature would be tagged with. Writes NOTHING.

    ``specs``            — list of TagSpec (which polygon layers supply values)
    ``target_layer_ids`` — layer ids that get the new column(s)
    """
    import time
    from qgis.core import (QgsCoordinateTransform, QgsGeometry, QgsProject,
                           QgsWkbTypes)
    t0 = time.time()
    project = project or QgsProject.instance()
    plan = TagPlan()

    # ── resolve + index the polygon layers once ──
    indexes = []      # (spec, _PolyIndex)
    for spec in specs:
        lyr = project.mapLayer(spec.poly_layer_id)
        if lyr is None or not lyr.isValid():
            plan.errors.append(f"Polygon layer for '{spec.out_field}' is missing.")
            continue
        spec.poly_name = lyr.name()
        if QgsWkbTypes.geometryType(lyr.wkbType()) != QgsWkbTypes.PolygonGeometry:
            plan.errors.append(f"'{lyr.name()}' is not a polygon layer — skipped.")
            continue
        if _field_lookup(lyr, spec.value_field) is None:
            plan.errors.append(f"'{lyr.name()}' has no field '{spec.value_field}'.")
            continue
        idx = _PolyIndex(lyr, spec.value_field, project)
        if not len(idx):
            plan.warnings.append(f"'{lyr.name()}' has no usable geometry — "
                                 f"every feature will be blank for '{spec.out_field}'.")
        plan.specs.append(spec)
        indexes.append((spec, idx))

    if not indexes:
        plan.errors.append("Nothing to tag with — select at least one polygon layer.")
        return plan

    # ── walk each target layer ──
    for lid in target_layer_ids:
        lyr = project.mapLayer(lid)
        if lyr is None or not lyr.isValid():
            plan.errors.append("A selected layer is missing from the project.")
            continue
        if any(lid == s.poly_layer_id for s, _ in indexes):
            plan.warnings.append(f"'{lyr.name()}' is one of the polygon layers — "
                                 f"not tagging it with itself.")
            continue

        plan.layer_names[lid] = lyr.name()
        shp = is_shapefile(lyr)
        gtype = QgsWkbTypes.geometryType(lyr.wkbType())
        is_line = gtype == QgsWkbTypes.LineGeometry
        src_crs = lyr.crs()

        # per-spec: resolved output field name + existing-field checks
        fields_here = []
        for spec, _idx in indexes:
            fld = sanitize_field_name(spec.out_field, shapefile=shp)
            if fld != spec.out_field:
                plan.warnings.append(
                    f"'{lyr.name()}': field name '{spec.out_field}' → '{fld}' "
                    f"({'shapefiles cap names at 10 characters' if shp else 'illegal characters removed'}).")
            existing = _field_lookup(lyr, fld)
            if existing is not None:
                efield = lyr.fields()[lyr.fields().indexFromName(existing)]
                if not _is_string_field(efield):
                    plan.errors.append(
                        f"'{lyr.name()}' already has a field '{existing}' of type "
                        f"{efield.typeName()} — refusing to overwrite it. "
                        f"Choose a different name.")
                    continue
                plan.warnings.append(
                    f"'{lyr.name()}': '{existing}' already exists — Apply overwrites it.")
                fld = existing
            fields_here.append((spec, _idx, fld))

        if not fields_here:
            continue

        plan.out_fields[lid] = [f for _s, _i, f in fields_here]
        rows = {}
        stats = {f: {"total": 0, "tagged": 0, "outside": 0}
                 for _s, _i, f in fields_here}

        # one cached transform per (target, polygon) CRS pair
        xforms = {}
        for _s, idx, _f in fields_here:
            key = _crs_key(idx.crs)
            if key not in xforms:
                xforms[key] = (None if src_crs == idx.crs
                               else QgsCoordinateTransform(src_crs, idx.crs, project))

        label_fld = _label_field(lyr)
        samples = []
        for feat in lyr.getFeatures():
            geom = feat.geometry()
            row = {}
            for _spec, idx, fld in fields_here:
                xf = xforms[_crs_key(idx.crs)]
                val = None
                if geom is not None and not geom.isEmpty():
                    g = geom
                    if xf is not None:
                        try:
                            g = QgsGeometry(geom)
                            g.transform(xf)
                        except Exception:
                            g = None
                    if g is not None:
                        if is_line:
                            vals = idx.values_along_line(g)
                            val = ", ".join(vals) if vals else None
                        else:
                            val = idx.value_at_point(_rep_point(g))
                row[fld] = val
                stats[fld]["total"] += 1
                if val is None:
                    stats[fld]["outside"] += 1
                else:
                    stats[fld]["tagged"] += 1
            rows[feat.id()] = row
            if len(samples) < TagPlan.SAMPLE_CAP:
                s = {"label": _norm_value(feat[label_fld]) if label_fld else str(feat.id())}
                s.update(row)
                samples.append(s)

        plan.rows[lid] = rows
        plan.stats[lid] = stats
        plan.samples[lid] = samples

    if not plan.rows and not plan.errors:
        plan.errors.append("Nothing to tag — select at least one target layer.")
    plan.elapsed_s = time.time() - t0
    return plan


# ── apply (THE ONLY WRITER) ──────────────────────────────────────────────────
# claude:intent MUTATE fibre_automation/tagging/zone_tag.py apply_plan
#   Adds ONE new text attribute per (layer, spec) and fills it from the plan the
#   user just previewed. Purely ADDITIVE: no existing field's value is touched
#   and no geometry changes, so the undo is deleteAttributes(idx).
#   Gated behind an explicit "Apply" click on the preview. approved-destructive
def apply_plan(project, plan):
    """Write ``plan`` to the layers. Additive only; reversible by deleting the field."""
    from qgis.core import QgsField, QgsProject, QgsVectorDataProvider
    from qgis.PyQt.QtCore import QMetaType

    project = project or QgsProject.instance()
    res = ApplyResult()
    res.layer_names = dict(plan.layer_names)

    for lid, rows in plan.rows.items():
        name = plan.layer_names.get(lid, lid)
        lyr = project.mapLayer(lid)
        if lyr is None or not lyr.isValid():
            res.errors.append(f"'{name}' is no longer in the project — skipped.")
            continue
        dp = lyr.dataProvider()
        caps = dp.capabilities()
        if not (caps & QgsVectorDataProvider.Capability.AddAttributes):
            res.skipped.append(f"'{name}' is read-only (cannot add a field).")
            continue
        if not (caps & QgsVectorDataProvider.Capability.ChangeAttributeValues):
            res.skipped.append(f"'{name}' does not allow attribute edits.")
            continue

        # ── ensure every output field exists (add the missing ones in ONE call) ──
        wanted = plan.out_fields.get(lid, [])
        to_add = [f for f in wanted if _field_lookup(lyr, f) is None]
        if to_add:
            new = [QgsField(f, QMetaType.Type.QString, len=254) for f in to_add]
            if not dp.addAttributes(new):
                res.errors.append(f"'{name}': could not add "
                                  f"{', '.join(to_add)} — layer left unchanged.")
                continue
            lyr.updateFields()
            for f in to_add:
                res.fields_added.append(f"{name}.{f}")

        # resolve real (possibly provider-truncated) names → provider indices
        idx_of = {}
        missing = []
        for f in wanted:
            real = _field_lookup(lyr, f)
            i = dp.fields().indexOf(real) if real else -1
            if i < 0:
                missing.append(f)
            else:
                idx_of[f] = i
        if missing:
            res.errors.append(f"'{name}': field(s) {', '.join(missing)} did not "
                              f"materialise on the provider — layer left unchanged.")
            continue

        # ── ONE bulk provider write per layer (never per-feature in a loop) ──
        attr_map = {}
        for fid, row in rows.items():
            attr_map[fid] = {idx_of[f]: v for f, v in row.items() if f in idx_of}
        if not attr_map:
            continue
        if dp.changeAttributeValues(attr_map):
            res.written[lid] = len(attr_map)
        else:
            res.errors.append(f"'{name}': the provider rejected the attribute write.")

        try:
            lyr.updateFields()
            lyr.triggerRepaint()
        except Exception:
            pass

    return res


# ── dialog conveniences (kept here so the UI stays thin) ─────────────────────
_POLY_NAME_HINTS = ("pon", "phase", "zone", "aoi", "area", "block", "region")
_VALUE_FIELD_HINTS = ("pon", "pon_no", "phase num", "phase", "zone", "zone_id",
                      "zone_no", "group_id", "label", "name")

# Which polygon layers arrive PRE-TICKED. Deliberately narrower than
# _POLY_NAME_HINTS: an AOI is one polygon covering everything, so tagging with it
# yields a column where every row says the same thing. It stays listed (JJ can
# tick it) but defaulting it on would just add noise to every table.
_PRETICK_HINTS = ("pon", "phase", "zone")


def polygon_layers(project=None):
    """[(layer, pre_tick)] — every polygon layer, the PON/Phase/Zone ones first."""
    from qgis.core import QgsProject, QgsVectorLayer, QgsWkbTypes
    project = project or QgsProject.instance()
    out = []
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
            continue
        try:
            if QgsWkbTypes.geometryType(lyr.wkbType()) != QgsWkbTypes.PolygonGeometry:
                continue
        except Exception:
            continue
        n = lyr.name().lower()
        # an empty polygon layer can't tag anything — never pre-tick it
        pre = any(h in n for h in _PRETICK_HINTS) and lyr.featureCount() > 0
        out.append((lyr, pre))
    out.sort(key=lambda t: (not t[1], t[0].name().lower()))
    return out


def target_layers(project=None):
    """Every valid vector layer — the candidates for "add the field to"."""
    from qgis.core import QgsProject, QgsVectorLayer
    project = project or QgsProject.instance()
    out = [l for l in project.mapLayers().values()
           if isinstance(l, QgsVectorLayer) and l.isValid()]
    out.sort(key=lambda l: l.name().lower())
    return out


def guess_value_field(layer):
    """Best "this is the identity" field on a polygon layer, else its first field."""
    lut = {f.name().lower(): f.name() for f in layer.fields()}
    for c in _VALUE_FIELD_HINTS:
        if c in lut:
            return lut[c]
    for low, real in lut.items():           # e.g. "phase num" via substring
        if any(h in low for h in _POLY_NAME_HINTS):
            return real
    flds = layer.fields()
    return flds[0].name() if len(flds) else ""


def guess_out_field(layer, value_field, shapefile=False):
    """Default column name — short, obvious, shapefile-safe ('PON'→pon)."""
    name = (layer.name() or "").lower()
    for hint in ("pon", "phase", "zone", "aoi"):
        if hint in name:
            return sanitize_field_name(hint, shapefile)
    return sanitize_field_name(value_field, shapefile)
