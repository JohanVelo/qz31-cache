import sys, os
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')

# ============================================================
# STS SPLITTERS V1 — LABEL POPULATION
# Project: Potch - Mohadin PH2
# Label format: MOA.STS.8.DIS.DM.P.[NearestPole]-[FTSPONLabel].L[LegNo]
# Example: MOA.STS.8.DIS.DM.P.H249-OLT.01.C15P11.L1
# Leg number is sequential per PON (L1-L16)
# ============================================================

STS_LAYER = 'STS Splitters v1'
POLES_LAYER = 'poles v1'
PON_LAYER = 'PON v1'
FTS_LAYER = 'FTS Splitters v1'

SR = 'MOA'
OLT = 'OLT.01'

sts_layer = None
poles_layer = None
pon_layer = None
fts_layer = None

for lyr in QgsProject.instance().mapLayers().values():
    n = lyr.name()
    if n == STS_LAYER: sts_layer = lyr
    if n == POLES_LAYER: poles_layer = lyr
    if n == PON_LAYER: pon_layer = lyr
    if n == FTS_LAYER: fts_layer = lyr

missing = []
if not sts_layer: missing.append(STS_LAYER)
if not poles_layer: missing.append(POLES_LAYER)
if not pon_layer: missing.append(PON_LAYER)
if not fts_layer: missing.append(FTS_LAYER)

if missing:
    print(f"ERROR: Missing layers: {missing}")
else:
    print(f"STS layer:   {STS_LAYER} ({sts_layer.featureCount()} features)")
    print(f"Poles layer: {POLES_LAYER} ({poles_layer.featureCount()} features)")
    print(f"PON layer:   {PON_LAYER} ({pon_layer.featureCount()} features)")
    print(f"FTS layer:   {FTS_LAYER} ({fts_layer.featureCount()} features)")

    from qgis.core import QgsSpatialIndex, QgsPointXY

    # --- BUILD SPATIAL INDEXES ---
    pole_index = QgsSpatialIndex(poles_layer.getFeatures())
    pole_feats = {f.id(): f for f in poles_layer.getFeatures()}

    # --- PON label lookup by pon_no ---
    pon_label_by_no = {f['pon_no']: f['label'] for f in pon_layer.getFeatures()}

    # --- GROUP STS BY PON_NO ---
    from collections import defaultdict
    sts_by_pon = defaultdict(list)
    for feat in sts_layer.getFeatures():
        pon_no = feat['pon_no']
        if pon_no:
            sts_by_pon[pon_no].append(feat)

    def nearest_pole_label(point):
        candidates = pole_index.nearestNeighbor(QgsPointXY(point.x(), point.y()), 1)
        if candidates:
            feat = pole_feats[candidates[0]]
            label = str(feat['Label'])
            if '.' in label:
                return label.split('.')[-1]
        return None

    def fidx(name):
        return sts_layer.fields().indexOf(name)

    sts_layer.startEditing()

    processed = 0
    no_pon = 0
    sample = []

    for pon_no, sts_list in sorted(sts_by_pon.items()):
        pon_label = pon_label_by_no.get(pon_no)
        if not pon_label:
            no_pon += len(sts_list)
            continue

        # Assign leg numbers sequentially L1, L2, L3...
        for leg_no, feat in enumerate(sts_list, start=1):
            geom = feat.geometry()
            if geom is None or geom.isNull():
                continue

            pt = geom.asPoint()
            pole_label = nearest_pole_label(pt)

            if pole_label and pon_label:
                label = f'{SR}.STS.8.DIS.DM.P.{pole_label}-{OLT}.{pon_label}.L{leg_no}'
            else:
                label = None

            label_idx = fidx('label')
            if label_idx != -1 and label:
                sts_layer.changeAttributeValue(feat.id(), label_idx, label)

            processed += 1
            if len(sample) < 5:
                sample.append(f"  {label} | pon={pon_no} | leg=L{leg_no}")

    sts_layer.commitChanges()

    # --- SUMMARY ---
    print("=" * 65)
    print(f"  STS SPLITTERS V1 LABEL POPULATION COMPLETE")
    print(f"  Processed: {processed}")
    print(f"  Skipped (no PON): {no_pon}")
    print("=" * 65)
    print("\nSample — first 5 STS:")
    for s in sample:
        print(s)

    # --- VERIFY NO NULLS ---
    null_count = sum(1 for f in sts_layer.getFeatures() if not f['label'])
    print(f"\nNULL labels remaining: {null_count}")
