# -*- coding: utf-8 -*-
# Remove blocks from a BUILT grid atlas and renumber the rest (JJ 2026-09-30).
#
# "Tick 2 of 17 and there are 15": the removed blocks leave the overview, the atlas never
# visits their pages, every remaining block is renumbered 1..K in reading order, and the
# page footer follows ("Page 15 of 15") because it is computed from the atlas feature count.
#
# This file is split in two:
#   * the pure core (plan_removal) — no QGIS, no Qt, so the property suite runs it in the
#     plain venv;
#   * the layout side (added in step 2) imports QGIS lazily inside its functions.
#
# Identity: every block carries an ORIGINAL id (orig_no — the number it had when the atlas
# was built). Its current number (cell_no) changes on every removal; its orig_no never
# does. Removals are always resolved against the numbers printed on the overview RIGHT NOW,
# then recorded by orig_no, so "remove A, then remove B" is well defined.


class RemovalError(ValueError):
    """A removal request that must not be applied (nothing is changed)."""


def plan_removal(current, remove_numbers):
    """Work out a removal without touching anything.

    current         {cell_no: orig_no} for every block in the atlas now. cell_no must be
                    exactly 1..N (the invariant this module maintains); orig_no unique.
    remove_numbers  iterable of CURRENT block numbers to remove. Duplicates are fine.

    Returns {"renumber": {orig_no: new_no}, "removed": [orig_no, ...]} where new_no runs
    1..K in the blocks' current order, K = N - len(removed).

    Raises RemovalError for: an empty atlas, a number that is not a current block, removing
    nothing, or removing every block (an atlas needs at least one detail page).
    """
    if not current:
        raise RemovalError("The atlas has no grid blocks.")
    nos = sorted(int(n) for n in current)
    if nos != list(range(1, len(nos) + 1)):
        raise RemovalError("Block numbers are not 1..%d — rebuild the atlas first." % len(nos))
    origs = [current[n] for n in nos]
    if len(set(origs)) != len(origs):
        raise RemovalError("Two blocks share one original id — rebuild the atlas first.")
    try:
        drop = {int(n) for n in (remove_numbers or [])}
    except (TypeError, ValueError):
        raise RemovalError("Block numbers must be whole numbers.")
    if not drop:
        raise RemovalError("No blocks ticked — nothing to remove.")
    unknown = sorted(n for n in drop if n not in current)
    if unknown:
        raise RemovalError("No block numbered %s." % ", ".join(str(n) for n in unknown))
    if len(drop) >= len(nos):
        raise RemovalError("Every block is ticked — keep at least one.")
    renumber, removed = {}, []
    for n in nos:
        if n in drop:
            removed.append(current[n])
        else:
            renumber[current[n]] = len(renumber) + 1
    return {"renumber": renumber, "removed": removed}


# ─────────────────────────────────────────────────────────────────────────────
# Layout side — QGIS imported lazily so the core above stays testable without it.
# claude:intent MUTATE — user asked: "I want a menu where I can select what blocks to
# remove, and then all the other blocks should be renumbered" (JJ 2026-09-30, GO on plan
# rev 3) — plan: write ONLY the two memory layers the atlas engine generated and stamped
# (grid + book pages, proven by find_target), never project/source data.
# ─────────────────────────────────────────────────────────────────────────────
ROLE_KEY = "vf_hld_role"          # "grid" / "book_pages", stamped by hld_atlas_engine
BUILD_KEY = "vf_hld_build"        # one id per build, on both layers
ORIGINAL_KEY = "vf_grid_original" # JSON of the as-built rows, saved on the first removal

# Stress harness only: a callable run after the grid is written and before the pages are,
# so the rollback can be proven on a real half-finished edit. Always None in the plugin.
_fault_hook = None

_BOOK_FIELDS = ("seq", "is_overview", "unit")
_GRID_FIELDS = ("cell_no", "orig_no")


def _plain(v):
    """A JSON-safe attribute value (QGIS NULL and Qt types -> None)."""
    return v if isinstance(v, (bool, int, float, str)) else None


def _rows(layer):
    """[{"a": {field: value}, "g": wkb-hex}] for every feature — exact geometry, no WKT
    rounding, so a restore is byte-identical."""
    names = [f.name() for f in layer.fields()]
    out = []
    for f in layer.getFeatures():
        g = f.geometry()
        out.append({"a": {n: _plain(f[n]) for n in names},
                    "g": bytes(g.asWkb()).hex() if g is not None and not g.isEmpty() else None})
    return out


def _add_rows(layer, rows):
    from qgis.core import QgsFeature, QgsGeometry
    feats = []
    for r in rows:
        feat = QgsFeature(layer.fields())
        if r.get("g"):
            geom = QgsGeometry()
            geom.fromWkb(bytes.fromhex(r["g"]))
            feat.setGeometry(geom)
        for n, v in r["a"].items():
            if layer.fields().indexOf(n) >= 0:
                feat.setAttribute(n, v)
        feats.append(feat)
    ok, _ = layer.dataProvider().addFeatures(feats)
    if not ok:
        raise RuntimeError("could not write %d features to %r" % (len(feats), layer.name()))


def _replace(layer, rows, keep=None):
    """Delete every feature (except those `keep` accepts) and add `rows`."""
    dp = layer.dataProvider()
    ids = [f.id() for f in layer.getFeatures() if not (keep and keep(f))]
    if ids and not dp.deleteFeatures(ids):
        raise RuntimeError("could not clear %r" % layer.name())
    _add_rows(layer, rows)


def _export_running():
    try:
        from . import live_build as lb
    except Exception:
        return False
    return bool(getattr(lb, "_EXPORT_STATE", {}).get("running")
                or getattr(lb, "_BATCH_STATE", {}).get("running"))


def _is_overview(f):
    try:
        return int(f["is_overview"] or 0) == 1
    except (TypeError, ValueError):
        return False


def find_target(layout, project=None):
    """(book_layer, grid_layer) for a layout this tool may edit, else RemovalError.

    Identity comes from the layout's OWN atlas coverage plus the build stamp — never from a
    layer name — so a PON/zone book, a book built before this release, or a grid that a
    later build replaced are all refused with nothing changed."""
    from qgis.core import QgsProject, QgsVectorLayer
    project = project or QgsProject.instance()
    if layout is None:
        raise RemovalError("No print layout.")
    book = layout.atlas().coverageLayer()
    if book is None or book.customProperty(ROLE_KEY) != "book_pages":
        raise RemovalError("This layout is not a grid atlas built by Velocity Nexus "
                           "(or it was built before the block remover existed) — rebuild it.")
    build = book.customProperty(BUILD_KEY) or ""
    grid = None
    for lyr in project.mapLayers().values():
        if (isinstance(lyr, QgsVectorLayer) and lyr.customProperty(ROLE_KEY) == "grid"
                and lyr.customProperty(BUILD_KEY) == build):
            grid = lyr
            break
    if not build or grid is None:
        raise RemovalError("This atlas has no numbered grid (PON / zone books have no "
                           "blocks to remove), or its grid was replaced by a later build.")
    for lyr, need in ((book, _BOOK_FIELDS), (grid, _GRID_FIELDS)):
        if lyr.providerType() != "memory":
            raise RemovalError("%r is not a generated layer — refusing to edit it." % lyr.name())
        missing = [n for n in need if lyr.fields().indexOf(n) < 0]
        if missing:
            raise RemovalError("%r is missing %s — rebuild the atlas." % (lyr.name(), ", ".join(missing)))
        if lyr.isEditable():
            raise RemovalError("%r is in edit mode — save or discard its edits first." % lyr.name())
    # the two layers must describe the same blocks: page unit == grid cell_no == seq
    cells = {int(f["cell_no"]) for f in grid.getFeatures()}
    if not cells:
        # Measured 2026-09-30 on QGIS 4.2: a saved + reopened project brings these generated
        # layers back EMPTY (core QGIS does not store memory-layer features), so the atlas
        # itself needs a rebuild before there is anything to remove.
        raise RemovalError("This atlas's grid is empty — QGIS does not keep it when a "
                           "project is reopened. Rebuild the atlas, then remove blocks.")
    pages = []
    for f in book.getFeatures():
        if _is_overview(f):
            continue
        try:
            pages.append((int(f["seq"]), int(str(f["unit"]))))
        except (TypeError, ValueError):
            raise RemovalError("Page %r is not a grid block — this is not a grid atlas." % f["unit"])
    if any(s != u for s, u in pages) or {u for _s, u in pages} != cells or len(pages) != len(cells):
        raise RemovalError("The pages and the grid no longer match — rebuild the atlas.")
    return book, grid


def current_blocks(layout, project=None):
    """Sorted list of the block numbers printed on the overview now (for the menu)."""
    _book, grid = find_target(layout, project)
    return sorted(int(f["cell_no"]) for f in grid.getFeatures())


def _refresh(layout, book, grid):
    for lyr in (book, grid):
        lyr.updateExtents()
        lyr.triggerRepaint()
    atlas = layout.atlas()
    atlas.updateFeatures()
    if atlas.enabled() and atlas.count():
        atlas.seekTo(0)                     # never left showing a page that is gone
        atlas.refreshCurrentFeature()
    layout.refresh()


def _guarded_write(layout, book, grid, write):
    """Run `write()`; on ANY failure put both layers back exactly as they were."""
    snap_book, snap_grid = _rows(book), _rows(grid)
    try:
        write()
    except Exception as e:
        try:
            _replace(book, snap_book)
            _replace(grid, snap_grid)
        finally:
            _refresh(layout, book, grid)
        raise RemovalError("Nothing was changed — the edit failed and was rolled back (%s)." % e)
    _refresh(layout, book, grid)


def remove_blocks(layout, numbers, project=None):
    """Remove the blocks currently numbered `numbers` and renumber the rest 1..K.

    Returns {"before": N, "after": K, "pages": K + 1, "removed_orig": [...]}.
    Raises RemovalError (nothing changed) when refused or when the write fails."""
    import json
    if _export_running():
        raise RemovalError("An atlas export is running — wait for it to finish.")
    book, grid = find_target(layout, project)
    gi_cell = grid.fields().indexOf("cell_no")
    by_cell = {int(f["cell_no"]): f for f in grid.getFeatures()}
    orig_of = {n: int(f["orig_no"]) for n, f in by_cell.items()}
    plan = plan_removal(orig_of, numbers)
    new_of = plan["renumber"]                         # orig_no -> new number
    removed = set(plan["removed"])
    bi = {n: book.fields().indexOf(n) for n in ("seq", "unit", "stat_name")}

    def write():
        if not book.customProperty(ORIGINAL_KEY):
            book.setCustomProperty(ORIGINAL_KEY, json.dumps({
                "grid": _rows(grid),
                "pages": [r for r in _rows(book) if not r["a"].get("is_overview")]}))
        g_del, g_chg = [], {}
        for n, f in by_cell.items():
            o = orig_of[n]
            if o in removed:
                g_del.append(f.id())
            elif new_of[o] != n:
                g_chg[f.id()] = {gi_cell: new_of[o]}
        b_del, b_chg = [], {}
        for f in book.getFeatures():
            if _is_overview(f):
                continue
            old = int(str(f["unit"]))
            o = orig_of[old]
            if o in removed:
                b_del.append(f.id())
                continue
            new = new_of[o]
            if new == old:
                continue
            chg = {bi["seq"]: new, bi["unit"]: str(new)}
            sn = f["stat_name"] if bi["stat_name"] >= 0 else None
            if isinstance(sn, str) and sn.endswith(str(old)):
                chg[bi["stat_name"]] = sn[: len(sn) - len(str(old))] + str(new)
            b_chg[f.id()] = chg
        gdp, bdp = grid.dataProvider(), book.dataProvider()
        if g_del and not gdp.deleteFeatures(g_del):
            raise RuntimeError("grid delete failed")
        if g_chg and not gdp.changeAttributeValues(g_chg):
            raise RuntimeError("grid renumber failed")
        if _fault_hook is not None:                   # test seam: fail between the layers
            _fault_hook()
        if b_del and not bdp.deleteFeatures(b_del):
            raise RuntimeError("page delete failed")
        if b_chg and not bdp.changeAttributeValues(b_chg):
            raise RuntimeError("page renumber failed")

    _guarded_write(layout, book, grid, write)
    k = len(new_of)
    return {"before": len(by_cell), "after": k, "pages": k + 1, "removed_orig": sorted(removed)}


def restore_all(layout, project=None):
    """Put back every block the atlas was built with, under its original number."""
    import json
    if _export_running():
        raise RemovalError("An atlas export is running — wait for it to finish.")
    book, grid = find_target(layout, project)
    raw = book.customProperty(ORIGINAL_KEY)
    if not raw:
        raise RemovalError("Nothing has been removed from this atlas.")
    try:
        orig = json.loads(raw)
        grid_rows, page_rows = orig["grid"], orig["pages"]
    except (TypeError, ValueError, KeyError):
        raise RemovalError("The saved original blocks are unreadable — rebuild the atlas.")

    def write():
        _replace(grid, grid_rows)
        _replace(book, page_rows, keep=_is_overview)
        book.removeCustomProperty(ORIGINAL_KEY)

    _guarded_write(layout, book, grid, write)
    return {"after": len(grid_rows), "pages": len(grid_rows) + 1}
