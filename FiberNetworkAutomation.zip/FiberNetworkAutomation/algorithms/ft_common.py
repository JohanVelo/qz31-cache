"""ft_common — small shared helpers for the Group B (FT / HeroTel) algorithms.

These algorithms don't extend BaseFiberAlgorithm, so the common safe-getters
live here. QGIS-bundled imports only (works on plain QGIS 3 and 4).
"""
from qgis.core import QgsProcessingException, QgsProject


def get_layer(name, feedback=None, project=None, required=True):
    """Return the first project layer called ``name``, or ``None``.

    Replaces the ``mapLayersByName(name)[0]`` pattern, which raises a raw
    ``IndexError`` (ugly traceback, not a clean Processing error) the moment a
    layer is renamed or missing. When ``required`` and the layer is absent this
    raises a ``QgsProcessingException`` that the Processing dialog renders nicely.
    """
    proj = project or QgsProject.instance()
    matches = proj.mapLayersByName(name)
    if matches:
        return matches[0]
    msg = f"Layer '{name}' not found in the project."
    if feedback is not None:
        try:
            feedback.reportError(msg)
        except Exception:
            pass
    if required:
        raise QgsProcessingException(msg)
    return None
