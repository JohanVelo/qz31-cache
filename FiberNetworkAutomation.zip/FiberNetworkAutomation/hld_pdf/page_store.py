# -*- coding: utf-8 -*-
# claude:intent MUTATE - user asked (JJ 2026-10-20): "make sure that it works for everyone and works on every QGIS
#   version" (page pictures did nothing on a reopened project) - plan: keep the HLD atlas page layers' features in
#   the project file and put them back on open; only memory layers Velocity Nexus built (vf_hld_role) are touched.
# claude:boq-impact none - atlas page layers only (generated page outlines); no network layer is read or written
"""Keep the HLD atlas page layers through a save and reopen (JJ 2026-10-20).

The book's pages ("HLD Book Pages") and the numbered grid ("HLD Grid") are memory layers the
engine builds. QGIS does not save the features of a memory layer, so after a reopen the atlas
had no pages: nothing to flip to, nothing to export, and "Picture on this page..." had no page.

While the project is written, each such layer's features go into its own <layer> element;
while it is read, they are put back. Only memory layers carrying `vf_hld_role` are touched.
"""
import json

ROLE_KEY = "vf_hld_role"
TAG = "vfMemoryFeatures"
VERSION = 1


def _wanted(layer):
    try:
        from qgis.core import QgsVectorLayer
        return (isinstance(layer, QgsVectorLayer) and layer.providerType() == "memory"
                and bool(layer.customProperty(ROLE_KEY)))
    except Exception:
        return False


def _plain(v):
    """A JSON-safe copy of an attribute value (NULL -> None)."""
    try:
        from qgis.core import NULL
        if v == NULL:
            return None
    except Exception:
        pass
    if v is None or isinstance(v, (bool, int, float, str)):
        return v
    try:
        if v.isNull():
            return None
    except Exception:
        pass
    return str(v)


def dump(layer):
    """The layer's features as a JSON string: field names, then [wkb hex, attrs] per feature."""
    names = [f.name() for f in layer.fields()]
    rows = []
    for f in layer.getFeatures():
        g = f.geometry()
        wkb = bytes(g.asWkb()).hex() if g is not None and not g.isNull() else ""
        rows.append([wkb, [_plain(v) for v in f.attributes()]])
    return json.dumps({"v": VERSION, "fields": names, "rows": rows})


def load(layer, text):
    """Put the features in `text` back into an EMPTY memory layer. Returns the count added."""
    from qgis.core import QgsFeature, QgsGeometry
    data = json.loads(text)
    if not isinstance(data, dict) or data.get("v") != VERSION or layer.featureCount() > 0:
        return 0
    have = [f.name() for f in layer.fields()]
    idx = [have.index(n) if n in have else -1 for n in data.get("fields", [])]
    feats = []
    for wkb, attrs in data.get("rows", []):
        f = QgsFeature(layer.fields())
        if wkb:
            g = QgsGeometry()
            g.fromWkb(bytes.fromhex(wkb))
            f.setGeometry(g)
        vals = [None] * len(have)
        for i, v in zip(idx, attrs):
            if i >= 0:
                vals[i] = v
        f.setAttributes(vals)
        feats.append(f)
    if not feats:
        return 0
    ok, _out = layer.dataProvider().addFeatures(feats)
    layer.updateExtents()
    layer.triggerRepaint()
    return len(feats) if ok else 0


def on_write_layer(layer, elem, doc):
    """QgsProject.writeMapLayer: store the features in the layer's element."""
    try:
        if not _wanted(layer):
            return
        node = doc.createElement(TAG)
        node.appendChild(doc.createTextNode(dump(layer)))
        elem.appendChild(node)
    except Exception as e:
        print("HLD page store: save skipped for %s: %s" % (layer.name(), e))


def on_read_layer(layer, elem):
    """QgsProject.readMapLayer: refill an empty Nexus memory layer from its element."""
    try:
        if not _wanted(layer):
            return
        node = elem.firstChildElement(TAG)
        if node.isNull():
            return
        load(layer, node.text())
    except Exception as e:
        print("HLD page store: restore skipped for %s: %s" % (layer.name(), e))


class PageStoreHook:
    """Connects the two QgsProject signals for the plugin's lifetime."""

    def __init__(self, project=None):
        self.project = project
        self._on = False

    def _p(self):
        from qgis.core import QgsProject
        return self.project or QgsProject.instance()

    def install(self):
        if self._on:
            return
        p = self._p()
        p.writeMapLayer.connect(on_write_layer)
        p.readMapLayer.connect(on_read_layer)
        self._on = True

    def uninstall(self):
        if not self._on:
            return
        p = self._p()
        for sig, slot in ((p.writeMapLayer, on_write_layer), (p.readMapLayer, on_read_layer)):
            try:
                sig.disconnect(slot)
            except Exception:
                pass
        self._on = False
