# FT 7 — Pole Thickness Classification (FOA 2015 standard)

from qgis.PyQt.QtCore import QMetaType
import math
import json
import os
from collections import defaultdict

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterBoolean,
    QgsProcessing,
    QgsSpatialIndex,
    QgsGeometry,
    QgsPointXY,
    QgsVectorLayer,
    QgsFeature,
    QgsField,
    QgsDistanceArea,
)


CABLE_LAYERS   = ('Distribution Cable v1', 'Secondary Cable v1', 'Primary Cable v1')
SNAP_DEG       = 10.0 / 111320.0   # 10 m in degrees


def _roads_json_path():
    """Portable roads.json location. $VF_DATA_DIR / C:\\Temp / %TEMP%\\VelocityFibre.
    Road-crossing classification is OPTIONAL — FT7 warns and skips if absent."""
    try:
        from fibre_automation.shared.vf_paths import roads_json
        return roads_json()
    except Exception:
        import os
        return os.path.join(os.environ.get('VF_DATA_DIR', 'C:/Temp'), 'roads.json')


ROAD_JSON_PATH = _roads_json_path()


class FTPoleThicknessAlgorithm(QgsProcessingAlgorithm):
    """
    Classify all Poles v1 to FOA (2015: 35) creosote pole thickness standard.

    140-160 mm (anchor / strain pole):
      - First or last pole on a cable run
      - Road crossing (requires OSM roads JSON at C:/Temp/roads.json)
      - Direction change > 15 degrees along cable
      - Overhead-to-underground transition (Primary Cable v1 endpoint)

    120-140 mm (intermediate pole):
      - All other poles between the above

    Writes to fields:
      dim2        — '140-160mm' or '120-140mm'
      thickness_  — reason string (end/start of run; road crossing; dir change; etc.)
    """

    INPUT        = 'INPUT'
    USE_ROADS    = 'USE_ROADS'

    def createInstance(self):
        return FTPoleThicknessAlgorithm()

    def name(self):
        return 'ft_pole_thickness'

    def displayName(self):
        return 'FT 7. Classify Pole Thickness (FOA)'

    def group(self):
        return 'Fibertime Network Labeling'

    def groupId(self):
        return 'fibertimenetworklabeling'

    def shortHelpString(self):
        return (
            'Classifies all Poles v1 to FOA (2015: 35) creosote-treated pole '
            'thickness standard and writes results to the dim2 and thickness_ fields.\n\n'
            '140-160 mm: end/start of run, road crossing, direction change >15 degrees, '
            'UG transition.\n\n'
            '120-140 mm: all intermediate poles between the above.\n\n'
            'Road crossing detection requires C:/Temp/roads.json (OSM Overpass export). '
            'Uncheck "Use road crossings" to skip this check.'
        )

    def initAlgorithm(self, config=None):
        from qgis.core import QgsProject
        proj = QgsProject.instance()
        poles_layers = proj.mapLayersByName('poles v1')
        default = poles_layers[0] if poles_layers else None

        self.addParameter(QgsProcessingParameterVectorLayer(
            self.INPUT, 'Poles v1 layer',
            [QgsProcessing.SourceType.TypeVectorPoint],
            defaultValue=default,
        ))
        self.addParameter(QgsProcessingParameterBoolean(
            self.USE_ROADS, 'Use road crossing detection (needs C:/Temp/roads.json)',
            defaultValue=os.path.exists(ROAD_JSON_PATH),
        ))

    def processAlgorithm(self, parameters, context, feedback):
        from qgis.core import QgsProject
        poles_lyr  = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        use_roads  = self.parameterAsBoolean(parameters, self.USE_ROADS, context)
        proj       = QgsProject.instance()

        dim2_idx   = poles_lyr.fields().indexFromName('dim2')
        reason_idx = poles_lyr.fields().indexFromName('thickness_')

        if dim2_idx == -1 or reason_idx == -1:
            raise Exception("poles v1 must have 'dim2' and 'thickness_' fields")

        feedback.pushInfo('Loading poles...')
        pole_index = QgsSpatialIndex()
        pole_feats = {}
        for feat in poles_lyr.getFeatures():
            if feat.geometry() and not feat.geometry().isEmpty():
                pole_index.addFeature(feat)
                pole_feats[feat.id()] = feat

        # ── Road index ───────────────────────────────────────────
        road_index    = None
        road_feat_map = {}
        if use_roads and os.path.exists(ROAD_JSON_PATH):
            feedback.pushInfo('Loading OSM roads...')
            road_geoms = []
            with open(ROAD_JSON_PATH) as f:
                osm = json.load(f)
            for el in osm.get('elements', []):
                if el['type'] == 'way' and 'geometry' in el:
                    pts = [QgsPointXY(n['lon'], n['lat']) for n in el['geometry']]
                    if len(pts) >= 2:
                        road_geoms.append(QgsGeometry.fromPolylineXY(pts))

            tmp = QgsVectorLayer('LineString?crs=EPSG:4326', 'roads_tmp', 'memory')
            tmp.dataProvider().addAttributes([QgsField('id', QMetaType.Type.Int)])
            tmp.updateFields()
            rfl = []
            for i, rg in enumerate(road_geoms):
                f = QgsFeature(); f.setGeometry(rg); f.setId(i); rfl.append(f)
            tmp.dataProvider().addFeatures(rfl)
            road_index = QgsSpatialIndex()
            for f in tmp.getFeatures():
                road_index.addFeature(f)
                road_feat_map[f.id()] = f.geometry()
            feedback.pushInfo(f'Roads loaded: {len(road_geoms)}')
        else:
            feedback.pushWarning('Road crossing check skipped (no roads.json)')

        # ── Process cables ────────────────────────────────────────
        da = QgsDistanceArea()
        da.setEllipsoid('WGS84')

        pole_reasons  = defaultdict(set)
        pole_on_cable = set()
        cable_runs    = []

        total_cables = sum(
            proj.mapLayersByName(n)[0].featureCount()
            for n in CABLE_LAYERS if proj.mapLayersByName(n)
        )
        processed = 0

        for lname in CABLE_LAYERS:
            lyrs = proj.mapLayersByName(lname)
            if not lyrs:
                feedback.pushWarning(f'{lname}: not found, skipping')
                continue
            for cab_feat in lyrs[0].getFeatures():
                if feedback.isCanceled():
                    return {}
                processed += 1
                feedback.setProgress(int(processed / max(total_cables, 1) * 80))

                geom = cab_feat.geometry()
                if not geom or geom.isEmpty():
                    continue
                try:
                    coords = geom.asPolyline() if not geom.isMultipart() else geom.asMultiPolyline()[0]
                except Exception:
                    continue
                if len(coords) < 2:
                    continue

                total_len_m   = da.measureLength(geom)
                total_len_deg = sum(
                    math.sqrt((coords[i+1].x()-coords[i].x())**2 +
                              (coords[i+1].y()-coords[i].y())**2)
                    for i in range(len(coords)-1))
                if total_len_m == 0 or total_len_deg == 0:
                    continue

                bbox = geom.boundingBox(); bbox.grow(SNAP_DEG)
                poles_here = []
                for fid in pole_index.intersects(bbox):
                    if geom.distance(pole_feats[fid].geometry()) <= SNAP_DEG:
                        pos_norm = geom.lineLocatePoint(pole_feats[fid].geometry()) / total_len_deg
                        poles_here.append((pos_norm, fid))
                        pole_on_cable.add(fid)
                poles_here.sort()
                cable_runs.append((total_len_m, poles_here))

                n = len(poles_here)
                for idx, (pos_norm, fid) in enumerate(poles_here):
                    if idx == 0 or idx == n - 1:
                        pole_reasons[fid].add('end/start of run')
                    if 0 < idx < n - 1:
                        def tangent_at(p, coords=coords, tld=total_len_deg):
                            target = p * tld; acc = 0.0
                            for i in range(len(coords)-1):
                                dx=coords[i+1].x()-coords[i].x()
                                dy=coords[i+1].y()-coords[i].y()
                                seg=math.sqrt(dx*dx+dy*dy)
                                if acc+seg >= target or i == len(coords)-2:
                                    m=seg or 1; return dx/m, dy/m
                                acc += seg
                            return 1.0, 0.0
                        t_in  = tangent_at((poles_here[idx-1][0]+pos_norm)/2)
                        t_out = tangent_at((pos_norm+poles_here[idx+1][0])/2)
                        dot   = max(-1.0, min(1.0, t_in[0]*t_out[0]+t_in[1]*t_out[1]))
                        bend  = math.degrees(math.acos(dot))
                        if bend > 15.0:
                            pole_reasons[fid].add(f'dir change ({bend:.0f}\u00b0)')

                if road_index:
                    for rid in road_index.intersects(geom.boundingBox()):
                        road_g = road_feat_map[rid]
                        if geom.crosses(road_g) or geom.intersects(road_g):
                            inter = geom.intersection(road_g)
                            ipts = []
                            if inter.wkbType() in (1, 0x80000001):
                                ipts = [inter.asPoint()]
                            elif inter.isMultipart():
                                ipts = list(inter.asMultiPoint())
                            for ipt in ipts:
                                for nfid in pole_index.nearestNeighbor(ipt, 2):
                                    if geom.distance(pole_feats[nfid].geometry()) <= SNAP_DEG:
                                        pole_reasons[nfid].add('road crossing')

        # ── Underground transitions (Primary Cable v1 endpoints) ──
        pl = proj.mapLayersByName('Primary Cable v1')
        if pl:
            pf = [f.name() for f in pl[0].fields()]
            lbl_to_fid = {str(f['Label']).strip(): fid for fid, f in pole_feats.items()}
            for feat in pl[0].getFeatures():
                for fld in ('strtfeat', 'endfeat'):
                    if fld in pf:
                        v = str(feat[fld]).strip()
                        if v and v not in ('NULL', 'None') and v in lbl_to_fid:
                            pole_reasons[lbl_to_fid[v]].add('UG transition')

        # ── Write results ─────────────────────────────────────────
        feedback.setProgress(90)
        feedback.pushInfo('Writing classifications...')

        attr_map = {}
        counts   = {'140-160mm': 0, '120-140mm': 0}
        preserved = 0

        for fid, feat in pole_feats.items():
            lbl = str(feat['Label']).strip()
            if not lbl or lbl in ('NULL', 'None'):
                continue

            # Read existing values to enforce merge-not-override
            cur_dim2  = str(feat['dim2']).strip() if feat['dim2'] is not None else ''
            cur_thick = str(feat['thickness_']).strip() if feat['thickness_'] is not None else ''
            cur_low   = cur_thick.lower()

            # Manual override marker — never auto-write per
            # feedback_merge_not_override_pattern.md
            if 'manual:' in cur_low:
                preserved += 1
                continue

            reasons = set(pole_reasons.get(fid, set()))

            # If user manually flagged "road crossing" but FT7 wasn't run with
            # roads, preserve the flag so we don't lose the RC.
            if 'road crossing' in cur_low and not use_roads:
                reasons.add('road crossing')

            if fid not in pole_on_cable and not reasons:
                thickness = '120-140mm'; reasons = {'no cable data'}
            elif reasons:
                thickness = '140-160mm'
            else:
                thickness = '120-140mm'; reasons = {'intermediate'}

            new_thick_str = '; '.join(sorted(reasons))[:120]

            # Count every classified pole (incl. already-correct ones), so a
            # re-run on a fully-classified layer reports the real totals rather
            # than '0 | 0'. 'rows touched' (below) still reports actual writes.
            counts[thickness] += 1

            # Skip write if both values already match — avoid provider churn
            if cur_dim2 == thickness and cur_thick == new_thick_str:
                continue

            row = {}
            if cur_dim2 != thickness:
                row[dim2_idx] = thickness
            if cur_thick != new_thick_str:
                row[reason_idx] = new_thick_str
            if row:
                attr_map[fid] = row

        if attr_map:
            poles_lyr.dataProvider().changeAttributeValues(attr_map)
        poles_lyr.triggerRepaint()

        feedback.setProgress(100)
        feedback.pushInfo(
            f"Done — 140-160mm: {counts['140-160mm']}  |  120-140mm: {counts['120-140mm']}  "
            f"|  preserved manual: {preserved}  |  rows touched: {len(attr_map)}"
        )
        return {}
