# Velocity: Build HeroTel Layers — VN 1
# claude:intent WRITES ONE NEW FILE — creates a new GeoPackage at the chosen path and
# refuses if anything already exists there. It never opens or edits an existing file.

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterCrs,
    QgsProcessingParameterFileDestination,
    QgsProcessingUtils,
    QgsProject,
)


def _key(p):
    """Path compare by string only: VN 1 modules never touch the file system here."""
    return str(p).split('|')[0].replace('\\', '/').rstrip('/').lower()


class VN01BuildHeroTelLayersAlgorithm(QgsProcessingAlgorithm):
    """VN 1 — Build HeroTel Layers: one new GeoPackage holding the 16 empty HeroTel
    standard layers, with their columns and styles. Nothing existing is changed."""

    OUTPUT = 'OUTPUT'
    CRS = 'CRS'

    def createInstance(self):
        return VN01BuildHeroTelLayersAlgorithm()

    def name(self):
        return 'vn_01_build_herotel_layers'

    def displayName(self):
        return 'VN 1 — Build HeroTel Layers'

    def group(self):
        return 'Velocity Standards'

    def groupId(self):
        return 'velocity_standards'

    def shortHelpString(self):
        return """
        <p><b>VN 1 — Build HeroTel Layers.</b> Creates one new GeoPackage with the
        16 HeroTel standard layers: empty, with the standard column headings and
        styles already set.</p>
        <p>It will not overwrite anything: if a file already exists at the chosen
        path, the tool stops and changes nothing.</p>
        <p>The coordinate system defaults to the project's.</p>
        """

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.OUTPUT, 'New GeoPackage', fileFilter='GeoPackage (*.gpkg)'))
        self.addParameter(
            QgsProcessingParameterCrs(
                self.CRS, 'Coordinate system', defaultValue='ProjectCrs'))

    def processAlgorithm(self, parameters, context, feedback):
        from fibre_automation.herotel_layers import build

        path = self.parameterAsFileOutput(parameters, self.OUTPUT, context)
        # A Processing TEMPORARY output is deleted when QGIS closes, so the layers
        # would show as scratch layers and vanish (JJ, 2026-09-23). Refuse it.
        if _key(path).startswith(_key(QgsProcessingUtils.tempFolder()) + '/'):
            raise QgsProcessingException(
                "Choose where to save the new GeoPackage. A temporary file is deleted "
                "when QGIS closes, and the layers would go with it.")
        crs = self.parameterAsCrs(parameters, self.CRS, context)
        if not crs.isValid():
            crs = (context.project() or QgsProject.instance()).crs()
        try:
            result = build.build(path, crs)
        except (build.BuildError, ValueError) as exc:
            raise QgsProcessingException(str(exc)) from exc
        if result['outcome'] != 'built':
            raise QgsProcessingException(
                f"Nothing was written: a file already exists at {result['path']}")
        feedback.pushInfo(f"Built {len(result['layers'])} layers in {result['path']} ({result['crs']})")
        self._built_path = result['path']
        return {self.OUTPUT: result['path']}

    def postProcessAlgorithm(self, context, feedback):
        """When the run is set to open its output, load the layers ourselves.

        Processing opens a multi-layer GeoPackage as '<output name> — <layer>'
        ('OUTPUT — Link', JJ 2026-09-23); the layers must carry their bare names, the
        same as the home-panel button gives them. So the file is taken off Processing's
        load list and the 16 layers are added by name, in spec order, in one group.
        A run that does not open its output (processing.run) is left as it was."""
        path = getattr(self, '_built_path', None)
        if not path:
            return {}
        pending = context.layersToLoadOnCompletion()
        ours = [k for k in pending if _key(k) == _key(path)]
        if not ours:
            return {self.OUTPUT: path}
        context.setLayersToLoadOnCompletion(
            {k: v for k, v in pending.items() if k not in ours})
        from fibre_automation.herotel_layers import build, dialog
        project = context.project() or QgsProject.instance()
        dialog.add_to_project(project, path, list(build.load_spec()['layers']))
        return {self.OUTPUT: path}
