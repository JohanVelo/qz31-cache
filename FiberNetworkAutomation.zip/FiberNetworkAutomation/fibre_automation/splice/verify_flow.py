"""
Independent verification of the flow-diagram data.
Re-reads MOA_Splice_Plan_v9.xlsx via a SEPARATE code path, compares field-by-field
to what build_flow_diagrams.parse_sheet() renders, and cross-checks the whole chain
(feeder -> FTS -> AGG dome -> dist cable -> DIS dome -> STS -> drops) against the live
network ground truth (splice_gt.json). Any mismatch is printed; exit 0 only if perfect.
"""
import re, json, sys, importlib.util
import openpyxl

XLSX = "C:/Users/jjsch/OneDrive/ON LAPTOP FIBRE/QGIS test/MOA_Splice_Plan_v9.xlsx"
spec = importlib.util.spec_from_file_location("bfd", "C:/Temp/build_flow_diagrams.py")
bfd = importlib.util.module_from_spec(spec); spec.loader.exec_module(bfd)
with open("C:/Temp/splice_gt.json") as _f:
    gt = json.load(_f)
fts_gt, sts_gt, dist_set = gt['fts'], gt['sts'], set(gt['dist'])
# Physical anchor for DIS domes = the set of dome labels that drops actually connect to
# (drop.strtfeat). The Enclosures Splice/Connectorised layers use a DIFFERENT label_1
# convention than the FTS/STS-embedded AGG/DIS labels (documented mismatch), so they are
# NOT a valid reference for these labels.
drop_domes = set(v['strt'] for v in gt['drops'].values() if v.get('strt'))

OLT_OFFSET = {15: 224, 16: 240, 17: 256, 18: 272, 19: 288}
def pon_of(p):
    m = re.match(r'C(\d+)P(\d+)', p or ''); return OLT_OFFSET[int(m.group(1))] + int(m.group(2)) if m else None
def fts_agg(label):
    return re.sub(r'FTS\.\d+\.', '', (label or '').split('-OLT')[0]) or None
def sts_dome(label):
    m = re.match(r'(MOA\.STS\.\d+\.DIS\.DM\.P\.\w+)\.C\d+P\d+\.L\d+', label or '')
    return re.sub(r'STS\.\d+\.', '', m.group(1)) if m else None
def sts_port(label):
    m = re.search(r'(C\d\dP\d\d)', label or ''); return m.group(1) if m else None
def sts_leg(label):
    m = re.search(r'\.L(\d+)$', label or ''); return int(m.group(1)) if m else None

def independent_parse(ws):
    """Separate reader: returns dict mirroring parse_sheet for comparison."""
    title = ws.cell(1, 1).value or ""
    port = ws.cell(3, 1).value
    fts = ws.cell(3, 17).value
    agg = ws.cell(3, 5).value
    legs = []
    blocks = {}
    order = []
    r = 7
    while r < 6000:
        a = ws.cell(r, 1).value; sts = ws.cell(r, 8).value
        if a is None and sts is None:
            break
        if sts:
            if sts not in blocks:
                blocks[sts] = {'sts': sts, 'leg': ws.cell(r, 2).value, 'cable': ws.cell(r, 4).value,
                               'agg_entry': ws.cell(r, 5).value, 'dis': ws.cell(r, 6).value,
                               'fibre_out': ws.cell(r, 7).value, 'filled': 0, 'spare': 0, 'rows': 0,
                               'ports': []}
                order.append(sts)
            blk = blocks[sts]; blk['rows'] += 1
            blk['ports'].append(ws.cell(r, 9).value)
            dr = ws.cell(r, 10).value
            if dr and str(dr).upper() == 'SPARE': blk['spare'] += 1
            elif dr: blk['filled'] += 1
        r += 1
    return title, port, fts, agg, [blocks[s] for s in order]

errs = []; warns = []
def E(sheet, msg): errs.append(f"[{sheet}] {msg}")
def W(sheet, msg): warns.append(f"[{sheet}] {msg}")

wb = openpyxl.load_workbook(XLSX, read_only=False, data_only=True)
ports = [s for s in wb.sheetnames if re.match(r'^C\d\dP\d\d$', s)]
glob_filled = glob_spare = glob_sts = 0
seen_sts = set()

for sh in ports:
    ws = wb[sh]
    rec = bfd.parse_sheet(ws)                      # what the diagram renders
    title, port, fts, agg, ilegs = independent_parse(ws)   # independent read

    agg_canon = fts_agg(fts)                 # canonical AGG dome from FTS label
    # 1) cross-path equality (generator vs independent)
    if rec['port'] != port: E(sh, f"port {rec['port']} != {port}")
    if rec['fts'] != fts:   E(sh, "fts mismatch")
    if rec['agg'] != agg_canon: E(sh, f"agg {rec['agg']} != canonical {agg_canon}")
    # (feeder col E may legitimately be an intermediate splice joint for multi-hop feeders;
    #  the real correctness check is that the LAST hop reaches the AGG dome — see below.)
    if len(rec['legs']) != len(ilegs): E(sh, f"leg count {len(rec['legs'])} != {len(ilegs)}")
    gmap = {L['sts']: L for L in rec['legs']}
    for il in ilegs:
        gl = gmap.get(il['sts'])
        if not gl: E(sh, f"generator missing STS {il['sts']}"); continue
        for k in ('leg', 'cable', 'dis', 'fibre_out', 'agg_entry', 'filled', 'spare', 'rows'):
            if gl[k] != il[k]: E(sh, f"{il['sts']} field {k}: {gl[k]} != {il[k]}")

    # 2) title PON/Zone correct vs port
    exp_pon = pon_of(port); exp_zone = (exp_pon - 235)//16 + 17
    if rec['pon'] != exp_pon: E(sh, f"title PON {rec['pon']} != computed {exp_pon}")
    if rec['zone'] != exp_zone: E(sh, f"title Zone {rec['zone']} != computed {exp_zone}")

    # 3) FTS correct vs ground truth
    if fts not in fts_gt: E(sh, f"FTS not in live: {fts}")
    else:
        if fts_gt[fts]['port'] != port: E(sh, f"FTS port {fts_gt[fts]['port']} != {port}")

    # 4) feeder chain "follows on": last hop exit joint == AGG dome (FTS)
    if rec['hops']:
        if rec['hops'][-1]['joint_exit'] != agg_canon:
            W(sh, f"feeder last hop exit {rec['hops'][-1]['joint_exit']} != AGG {agg_canon}")
        for hp in rec['hops']:
            if hp['cable'] not in dist_set and not re.search(r'\.(SF|PF)\.', hp['cable'] or ''):
                E(sh, f"feeder cable not feeder/dist: {hp['cable']}")

    # 5) each STS: live existence, port, dome-follows, dist cable, capacity
    for L in rec['legs']:
        s = L['sts']
        if s in seen_sts: E(sh, f"STS appears in >1 PON: {s}")
        seen_sts.add(s); glob_sts += 1
        if s not in sts_gt: E(sh, f"STS not in live: {s}")
        elif sts_gt[s]['port'] != port: E(sh, f"{s} live port {sts_gt[s]['port']} != {port}")
        if sts_port(s) != port: E(sh, f"{s} embedded port != {port}")
        if L['leg'] != sts_leg(s): E(sh, f"{s} leg col {L['leg']} != label L{sts_leg(s)}")
        if L['dis'] != sts_dome(s): E(sh, f"{s} dist DIS-joint {L['dis']} != STS-embedded dome {sts_dome(s)}")
        # connected STS must sit at a dome that real drops physically connect to
        if L['filled'] > 0 and L['dis'] not in drop_domes:
            E(sh, f"connected STS {s} dome {L['dis']} has no drops at it in live data")
        if L['agg_entry'] != agg_canon: E(sh, f"{s} dist AGG-entry {L['agg_entry']} != FTS AGG {agg_canon}")
        if L['cable'] not in dist_set: E(sh, f"dist cable not in live: {L['cable']}")
        if L['rows'] != 16: E(sh, f"{s} has {L['rows']} ports (expected 16)")
        if L['filled'] + L['spare'] != L['rows']: E(sh, f"{s} filled+spare != rows")
        if L['ports'] if False else False: pass
        glob_filled += L['filled']; glob_spare += L['spare']

    # 6) port sequence 1..16 within each STS (independent ports list)
    for il in ilegs:
        seq = [p for p in il['ports'] if isinstance(p, int)]
        if seq and seq != list(range(1, len(seq)+1)):
            E(sh, f"{il['sts']} port sequence not 1..n: {seq[:5]}...")

print(f"PONs checked        : {len(ports)}")
print(f"distinct STS         : {len(seen_sts)}  (live {len(sts_gt)})")
print(f"homes connected      : {glob_filled}")
print(f"spare ports          : {glob_spare}")
print(f"total capacity       : {glob_filled + glob_spare}")
print(f"ERRORS               : {len(errs)}")
for e in errs[:80]:
    print("  E ", e)
print(f"WARNINGS (non-blocking, pre-existing plan/data quirks): {len(warns)}")
for w in warns[:80]:
    print("  W ", w)
sys.exit(1 if errs else 0)
