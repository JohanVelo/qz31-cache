<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="4.2.0" styleCategories="Symbology|Labeling" labelsEnabled="0">
  <renderer-v2 referencescale="-1" forceraster="0" enableorderby="0" type="categorizedSymbol" symbollevels="0" attr="Phase">
        <categories>
          <category value="Phase 1" type="string" label="Phase 1" uuid="{fd9926b0-f358-4d73-a1b5-7d8625032e87}" symbol="0" render="true" />
          <category value="Phase 2" type="string" label="Phase 2" uuid="{69160213-cbcf-467b-b868-3a4f50c9e7d5}" symbol="1" render="true" />
          <category value="Phase 3" type="string" label="Phase 3" uuid="{1e517793-0c2c-448e-82cc-52a65efbd9b4}" symbol="2" render="true" />
          <category value="Phase 4" type="string" label="Phase 4" uuid="{baf94a90-ecbb-4f43-bbd0-688bb64789a7}" symbol="3" render="true" />
          <category value="Phase 5" type="string" label="Phase 5" uuid="{9f5036bc-51a8-4666-88eb-182517d9e91d}" symbol="4" render="true" />
          <category value="Phase 6" type="string" label="Phase 6" uuid="{e4dee407-74ca-4073-ae4f-10e967dd2834}" symbol="5" render="true" />
          <category value="" type="string" label="" uuid="{2d6dbfcc-028b-5db7-9cb7-e1d731b93a60}" symbol="6" render="true" />
    </categories>
        <symbols>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="0" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleLine" pass="0" id="{0ade863f-a780-4d63-9309-f43fa51572f7}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="0" name="align_dash_pattern" />
                <Option type="QString" value="square" name="capstyle" />
                <Option type="QString" value="5;2" name="customdash" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" />
                <Option type="QString" value="MM" name="customdash_unit" />
                <Option type="QString" value="0" name="dash_pattern_offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" />
                <Option type="QString" value="MM" name="dash_pattern_offset_unit" />
                <Option type="QString" value="0" name="draw_inside_polygon" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0,0,255,hsv:0.71944444444444444,0,0,1" name="line_color" />
                <Option type="QString" value="dash" name="line_style" />
                <Option type="QString" value="0.86" name="line_width" />
                <Option type="QString" value="MM" name="line_width_unit" />
                <Option type="QString" value="0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="0" name="ring_filter" />
                <Option type="QString" value="0" name="trim_distance_end" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" />
                <Option type="QString" value="MM" name="trim_distance_end_unit" />
                <Option type="QString" value="0" name="trim_distance_start" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" />
                <Option type="QString" value="MM" name="trim_distance_start_unit" />
                <Option type="QString" value="0" name="tweak_dash_pattern_on_corners" />
                <Option type="QString" value="0" name="use_custom_dash" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="1" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleLine" pass="0" id="{0ade863f-a780-4d63-9309-f43fa51572f7}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="0" name="align_dash_pattern" />
                <Option type="QString" value="square" name="capstyle" />
                <Option type="QString" value="5;2" name="customdash" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" />
                <Option type="QString" value="MM" name="customdash_unit" />
                <Option type="QString" value="0" name="dash_pattern_offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" />
                <Option type="QString" value="MM" name="dash_pattern_offset_unit" />
                <Option type="QString" value="0" name="draw_inside_polygon" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0,0,255,hsv:0.71944444444444444,0,0,1" name="line_color" />
                <Option type="QString" value="dash" name="line_style" />
                <Option type="QString" value="0.86" name="line_width" />
                <Option type="QString" value="MM" name="line_width_unit" />
                <Option type="QString" value="0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="0" name="ring_filter" />
                <Option type="QString" value="0" name="trim_distance_end" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" />
                <Option type="QString" value="MM" name="trim_distance_end_unit" />
                <Option type="QString" value="0" name="trim_distance_start" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" />
                <Option type="QString" value="MM" name="trim_distance_start_unit" />
                <Option type="QString" value="0" name="tweak_dash_pattern_on_corners" />
                <Option type="QString" value="0" name="use_custom_dash" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="2" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleLine" pass="0" id="{0ade863f-a780-4d63-9309-f43fa51572f7}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="0" name="align_dash_pattern" />
                <Option type="QString" value="square" name="capstyle" />
                <Option type="QString" value="5;2" name="customdash" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" />
                <Option type="QString" value="MM" name="customdash_unit" />
                <Option type="QString" value="0" name="dash_pattern_offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" />
                <Option type="QString" value="MM" name="dash_pattern_offset_unit" />
                <Option type="QString" value="0" name="draw_inside_polygon" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0,0,255,hsv:0.71944444444444444,0,0,1" name="line_color" />
                <Option type="QString" value="dash" name="line_style" />
                <Option type="QString" value="0.86" name="line_width" />
                <Option type="QString" value="MM" name="line_width_unit" />
                <Option type="QString" value="0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="0" name="ring_filter" />
                <Option type="QString" value="0" name="trim_distance_end" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" />
                <Option type="QString" value="MM" name="trim_distance_end_unit" />
                <Option type="QString" value="0" name="trim_distance_start" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" />
                <Option type="QString" value="MM" name="trim_distance_start_unit" />
                <Option type="QString" value="0" name="tweak_dash_pattern_on_corners" />
                <Option type="QString" value="0" name="use_custom_dash" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="3" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleLine" pass="0" id="{0ade863f-a780-4d63-9309-f43fa51572f7}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="0" name="align_dash_pattern" />
                <Option type="QString" value="square" name="capstyle" />
                <Option type="QString" value="5;2" name="customdash" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" />
                <Option type="QString" value="MM" name="customdash_unit" />
                <Option type="QString" value="0" name="dash_pattern_offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" />
                <Option type="QString" value="MM" name="dash_pattern_offset_unit" />
                <Option type="QString" value="0" name="draw_inside_polygon" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0,0,255,hsv:0.71944444444444444,0,0,1" name="line_color" />
                <Option type="QString" value="dash" name="line_style" />
                <Option type="QString" value="0.86" name="line_width" />
                <Option type="QString" value="MM" name="line_width_unit" />
                <Option type="QString" value="0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="0" name="ring_filter" />
                <Option type="QString" value="0" name="trim_distance_end" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" />
                <Option type="QString" value="MM" name="trim_distance_end_unit" />
                <Option type="QString" value="0" name="trim_distance_start" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" />
                <Option type="QString" value="MM" name="trim_distance_start_unit" />
                <Option type="QString" value="0" name="tweak_dash_pattern_on_corners" />
                <Option type="QString" value="0" name="use_custom_dash" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="4" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleLine" pass="0" id="{0ade863f-a780-4d63-9309-f43fa51572f7}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="0" name="align_dash_pattern" />
                <Option type="QString" value="square" name="capstyle" />
                <Option type="QString" value="5;2" name="customdash" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" />
                <Option type="QString" value="MM" name="customdash_unit" />
                <Option type="QString" value="0" name="dash_pattern_offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" />
                <Option type="QString" value="MM" name="dash_pattern_offset_unit" />
                <Option type="QString" value="0" name="draw_inside_polygon" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0,0,255,hsv:0.71944444444444444,0,0,1" name="line_color" />
                <Option type="QString" value="dash" name="line_style" />
                <Option type="QString" value="0.86" name="line_width" />
                <Option type="QString" value="MM" name="line_width_unit" />
                <Option type="QString" value="0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="0" name="ring_filter" />
                <Option type="QString" value="0" name="trim_distance_end" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" />
                <Option type="QString" value="MM" name="trim_distance_end_unit" />
                <Option type="QString" value="0" name="trim_distance_start" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" />
                <Option type="QString" value="MM" name="trim_distance_start_unit" />
                <Option type="QString" value="0" name="tweak_dash_pattern_on_corners" />
                <Option type="QString" value="0" name="use_custom_dash" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="5" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleLine" pass="0" id="{0ade863f-a780-4d63-9309-f43fa51572f7}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="0" name="align_dash_pattern" />
                <Option type="QString" value="square" name="capstyle" />
                <Option type="QString" value="5;2" name="customdash" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" />
                <Option type="QString" value="MM" name="customdash_unit" />
                <Option type="QString" value="0" name="dash_pattern_offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" />
                <Option type="QString" value="MM" name="dash_pattern_offset_unit" />
                <Option type="QString" value="0" name="draw_inside_polygon" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0,0,255,hsv:0.71944444444444444,0,0,1" name="line_color" />
                <Option type="QString" value="dash" name="line_style" />
                <Option type="QString" value="0.86" name="line_width" />
                <Option type="QString" value="MM" name="line_width_unit" />
                <Option type="QString" value="0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="0" name="ring_filter" />
                <Option type="QString" value="0" name="trim_distance_end" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" />
                <Option type="QString" value="MM" name="trim_distance_end_unit" />
                <Option type="QString" value="0" name="trim_distance_start" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" />
                <Option type="QString" value="MM" name="trim_distance_start_unit" />
                <Option type="QString" value="0" name="tweak_dash_pattern_on_corners" />
                <Option type="QString" value="0" name="use_custom_dash" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="6" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{2af44928-efef-4afd-95fc-ebe2fa926e77}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="125,139,143,255,rgb:0.4901961,0.545098,0.5607843,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
    </symbols>
        <source-symbol>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="0" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleFill" pass="0" id="{2af44928-efef-4afd-95fc-ebe2fa926e77}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                <Option type="QString" value="125,139,143,255,rgb:0.4901961,0.545098,0.5607843,1" name="color" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0.26" name="outline_width" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="solid" name="style" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </source-symbol>
        <rotation />
        <sizescale />
        <data-defined-properties>
          <Option type="Map">
            <Option type="QString" value="" name="name" />
            <Option name="properties" />
            <Option type="QString" value="collection" name="type" />
          </Option>
        </data-defined-properties>
      </renderer-v2>
</qgis>
