"""Fetch real surveyed ERVEN from the SA CSG cadastre — safely, in a background
QgsTask so it NEVER blocks the QGIS main thread (see
feedback_never_heavy_loops_via_bridge). Uses QgsBlockingNetworkRequest (no
`requests`/shapely dependency) and builds QgsGeometry directly from the
ArcGIS esriJSON rings. bbox-limited to the current canvas view.

Verified source: the CSG layer returns the exact surveyed erven (IoU 1.00).
Entry point: run_fetch_erven(iface).
"""
import json

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

# Council for Geoscience mirror of the CSG cadastre. Layer 6 = "SA Erf", national.
#
# WHY NOT THE DRDLR / DFFE URLS
# Measured 2026-08-11 from JJ's own laptop (control host reachable, so it is them
# not us): csggis.drdlr.gov.za is NXDOMAIN; csg.dalrrd.gov.za and
# dffeportal.environment.gov.za resolve but refuse TCP 443. dffeportal is the
# *correct documented* CSG URL — it is simply down. This host serves the same
# data with an IDENTICAL schema (PRCL_KEY, PRCL_TYPE, LSTATUS, WSTATUS,
# GEOM_AREA, TAG_VALUE, ...), so it is a straight swap with no field remapping.
CSG_URL = ('https://maps.geoscience.org.za/hosting/rest/services/'
           'Administrative_Boundaries_and_Cadastral_Data/MapServer/6/query')
PAGE = 1000


def _build_features(rings_list):
    """esriJSON rings -> list[QgsFeature]. Safe to call off the main thread."""
    from qgis.core import QgsFeature, QgsGeometry, QgsPointXY, QgsFields, QgsField
    from qgis.PyQt.QtCore import QMetaType
    fields = QgsFields()
    fields.append(QgsField('prcl_key', QMetaType.Type.QString))
    fields.append(QgsField('prcl_type', QMetaType.Type.QString))
    fields.append(QgsField('area', QMetaType.Type.Double))
    feats = []
    for rings, attrs in rings_list:
        try:
            pts = [[QgsPointXY(x, y) for x, y in ring] for ring in rings]
            g = QgsGeometry.fromPolygonXY(pts)
            if g.isEmpty():
                continue
            f = QgsFeature(fields)
            f.setGeometry(g)
            f.setAttributes([attrs.get('PRCL_KEY'), attrs.get('PRCL_TYPE'),
                             attrs.get('GEOM_AREA')])
            feats.append(f)
        except Exception:
            _swallowed_note(); continue
    return feats, fields


def _make_task(bbox4326, on_done):
    """Build a QgsTask that fetches CSG erven for bbox and calls on_done(feats,
    fields, err) on the main thread."""
    from qgis.core import QgsTask, QgsBlockingNetworkRequest
    from qgis.PyQt.QtCore import QUrl, QUrlQuery
    from qgis.PyQt.QtNetwork import QNetworkRequest

    class _Task(QgsTask):
        def __init__(self):
            super().__init__('Fetch CSG erven', QgsTask.Flag.CanCancel)
            self.rings = []
            self.err = None

        def run(self):
            offset = 0
            for _ in range(60):
                if self.isCanceled():
                    return False
                q = QUrlQuery()
                xmin, ymin, xmax, ymax = bbox4326
                q.addQueryItem('geometry', f'{xmin},{ymin},{xmax},{ymax}')
                q.addQueryItem('geometryType', 'esriGeometryEnvelope')
                q.addQueryItem('inSR', '4326')
                q.addQueryItem('outSR', '4326')
                q.addQueryItem('spatialRel', 'esriSpatialRelIntersects')
                q.addQueryItem('outFields', 'PRCL_KEY,PRCL_TYPE,GEOM_AREA')
                q.addQueryItem('returnGeometry', 'true')
                q.addQueryItem('resultOffset', str(offset))
                q.addQueryItem('resultRecordCount', str(PAGE))
                q.addQueryItem('f', 'json')
                url = QUrl(CSG_URL)
                url.setQuery(q)
                req = QgsBlockingNetworkRequest()
                # The CSG server answers a bbox query in 45-60s when busy
                # (measured 2026-08-11). Qt's default transfer timeout is well
                # under that, so without this the fetch dies on a slow-but-fine
                # server and reads to the operator as "no erven here".
                nreq = QNetworkRequest(url)
                try:
                    nreq.setTransferTimeout(150000)
                except Exception:
                    _swallowed_note()
                if req.get(nreq) != QgsBlockingNetworkRequest.ErrorCode.NoError:
                    self.err = req.errorMessage() or 'network error'
                    return False
                try:
                    data = bytes(req.reply().content())
                    j = json.loads(data.decode('utf-8'))
                except Exception as e:
                    self.err = f'parse error: {e}'
                    return False
                # Esri REST answers a FAILED query with HTTP 200 and an error
                # body. Without this check the error collapses to an empty
                # feature list and the operator is told "no surveyed erven here
                # (uncadastred / informal area)" — a WRONG explanation that
                # invites hand-drawing boundaries. Erven are CSG-first, never
                # Voronoi, so a false "uncadastred" reading is the one answer
                # that must never be given. (Verified live: a bad outFields
                # returns {"error":{"code":400}} under HTTP 200.)
                if isinstance(j, dict) and 'error' in j:
                    e = j['error'] or {}
                    msg = e.get('message') if isinstance(e, dict) else str(e)
                    code = e.get('code') if isinstance(e, dict) else ''
                    self.err = f'CSG server error {code}: {msg or "unknown"}'
                    return False
                feats = j.get('features', [])
                if not feats:
                    break
                for f in feats:
                    rings = f.get('geometry', {}).get('rings')
                    if rings:
                        self.rings.append((rings, f.get('attributes', {})))
                self.setProgress(min(95.0, (offset + PAGE) / (60.0 * PAGE) * 100.0))
                if not j.get('exceededTransferLimit') and len(feats) < PAGE:
                    break
                offset += PAGE
            return True

        def finished(self, ok):
            try:
                if not ok or self.err:
                    on_done(None, None, self.err or 'cancelled')
                    return
                feats, fields = _build_features(self.rings)
                on_done(feats, fields, None)
            finally:
                # drop the kept ref so finished tasks don't accumulate
                try:
                    run_fetch_erven._tasks.remove(self)
                except (AttributeError, ValueError):
                    pass

    return _Task()


def run_fetch_erven(iface):
    """Fetch CSG erven for the current canvas extent into a new layer, off the
    main thread. Real surveyed boundaries — no generation needed."""
    from qgis.core import (QgsProject, QgsApplication, QgsCoordinateTransform,
                           QgsCoordinateReferenceSystem, QgsVectorLayer)

    canvas = iface.mapCanvas()
    ext = canvas.extent()
    src = canvas.mapSettings().destinationCrs()
    to4326 = QgsCoordinateTransform(src, QgsCoordinateReferenceSystem('EPSG:4326'),
                                    QgsProject.instance())
    b = to4326.transformBoundingBox(ext)
    bbox = (b.xMinimum(), b.yMinimum(), b.xMaximum(), b.yMaximum())
    # guard: a continent-sized view would pull too much
    if (b.xMaximum() - b.xMinimum()) > 0.5 or (b.yMaximum() - b.yMinimum()) > 0.5:
        iface.messageBar().pushWarning(
            'CSG Erven', 'Zoom in first (current view too large to fetch).')
        return

    iface.messageBar().pushInfo('CSG Erven', 'Fetching surveyed erven from the CSG cadastre…')

    def on_done(feats, fields, err):
        if err:
            iface.messageBar().pushWarning('CSG Erven', f'Fetch failed: {err}')
            return
        if not feats:
            iface.messageBar().pushWarning(
                'CSG Erven', 'No surveyed erven here (uncadastred / informal area).')
            return
        lyr = QgsVectorLayer('Polygon?crs=EPSG:4326', 'Erven (CSG cadastre)', 'memory')
        dp = lyr.dataProvider()
        dp.addAttributes(fields.toList())
        lyr.updateFields()
        dp.addFeatures(feats)
        lyr.updateExtents()
        QgsProject.instance().addMapLayer(lyr)
        iface.messageBar().pushSuccess(
            'CSG Erven', f'Loaded {len(feats):,} real surveyed erven from the CSG cadastre.')

    task = _make_task(bbox, on_done)
    QgsApplication.taskManager().addTask(task)
    # keep a ref so the task isn't garbage-collected mid-run
    if not hasattr(run_fetch_erven, '_tasks'):
        run_fetch_erven._tasks = []
    run_fetch_erven._tasks.append(task)
