# Label Distribution Cables Algorithm

from qgis.core import (
    QgsProcessingParameterVectorLayer,
    QgsProcessing
)

from .base_algorithm import BaseFiberAlgorithm


class LabelDistributionCablesAlgorithm(BaseFiberAlgorithm):
    """Algorithm to label Distribution Cable layers"""

    def name(self):
        return 'labeldistributioncables'

    def displayName(self):
        return '8. Label Distribution Cables'

    def shortHelpString(self):
        return """
        Auto-populate Distribution Cable fields.

        Fields updated:
        - Dist Cable: DC001, DC002...
        - AG: PRAK-Z1-AG01 (spatial lookup)
        - Tlenght: geometry length (meters)
        - Slenght: calculated slack length
        - Name: Full engineering name
        - fid: 1, 2, 3...

        Note: Cable Size must be filled manually
        ⚠️ Run Aggregation Polygons first!
        """

    def initAlgorithm(self, config=None):
        # Input layer
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT,
                'Distribution Cable Layer',
                [QgsProcessing.TypeVectorLine]
            )
        )

        # Project selection
        self.add_common_parameters()

    def processAlgorithm(self, parameters, context, feedback):
        # Get parameters
        layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        project = self.get_project_code(parameters, context)

        feedback.pushInfo(f"Labeling Distribution Cables for {project}...")

        # Update Dist Cable
        feedback.pushInfo("Updating Dist Cable...")
        formula = "'DC' || lpad(to_string(@row_number), 3, '0')"
        self.calculate_field(layer, "Dist Cable", formula, feedback)

        # Update AG (spatial)
        feedback.pushInfo("Updating AG (spatial lookup)...")
        formula = "array_first(overlay_intersects('Aggregation Polygon', \"Label\"))"
        self.calculate_field(layer, "AG", formula, feedback)

        # Update Tlenght
        feedback.pushInfo("Updating Tlenght...")
        self.calculate_field(layer, "Tlenght", "$length", feedback)

        # Update Slenght (calculated slack)
        feedback.pushInfo("Updating Slenght...")
        slack_formula = """CASE
            WHEN "Tlenght" <= 50 THEN 15
            WHEN "Tlenght" <= 100 THEN 30
            WHEN "Tlenght" <= 200 THEN 40
            ELSE 50
        END"""
        self.calculate_field(layer, "Slenght", slack_formula, feedback)

        # Update Name (complex formula)
        feedback.pushInfo("Updating Name...")
        name_formula = f"""'VTC BUR {project} Z01 ' || "AG" || ' ' || "Dist Cable" || ' ' || "Cable Size" || ' ADSS G6.657.A1 (' || to_string(ceil("Tlenght")) || 'm-' || to_string(ceil("Tlenght" + coalesce("Slenght", 0))) || 'm)'"""
        self.calculate_field(layer, "Name", name_formula, feedback)

        # Update fid
        feedback.pushInfo("Updating fid...")
        self.calculate_field(layer, "fid", "@row_number", feedback)

        layer.triggerRepaint()
        feedback.pushInfo("✅ Distribution Cables labeled successfully!")

        return {self.INPUT: layer.id()}
