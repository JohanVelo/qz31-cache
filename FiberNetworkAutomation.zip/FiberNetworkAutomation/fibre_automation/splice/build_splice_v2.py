"""
MOA Phase 2 Splice Plan v2 — Restructured
Sheets:
  1. Cover / Summary
  2. Closure Master   (all AGG + DIS domes, one row each)
  3. Feeder Fiber Map (OLT port → feeder cable → FTS fiber assignment)
  4. FTS Splice Schedule (per FTS: input fiber → 8 output legs → STS dome)
  5. STS Port Register  (per STS dome: input fiber → 16 LC ports → DR/ONT)
  6. PON Audit         (per PON summary with fill rate)
"""

import json, re, os
from collections import defaultdict
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# ── Load data ──────────────────────────────────────────────────────────────
with open('C:/Temp/splice_data.json') as f:
    d = json.load(f)

primary      = d['primary']
secondary    = d['secondary']
distribution = d['distribution']
fts_data     = d['fts']
sts_data     = d['sts']
agg_domes    = d['agg_domes']
dis_domes    = d['dis_domes']
drops        = d['drops']
pon_counts   = d['pon_ont_counts']

# ── TIA-598-C colour sequence ─────────────────────────────────────────────
TUBE_COL = [
    ('Blue',   '2E75B6', 'FFFFFF'),
    ('Orange', 'FF8C00', '000000'),
    ('Green',  '70AD47', 'FFFFFF'),
    ('Brown',  '7B3F00', 'FFFFFF'),
    ('Slate',  '808080', 'FFFFFF'),
    ('White',  'F2F2F2', '000000'),
    ('Red',    'FF0000', 'FFFFFF'),
    ('Black',  '1A1A1A', 'FFFFFF'),
    ('Yellow', 'FFD700', '000000'),
    ('Violet', '7030A0', 'FFFFFF'),
    ('Rose',   'FF66CC', '000000'),
    ('Aqua',   '00B0F0', '000000'),
]

def tube_info(fiber_num_1based):
    """Given 1-based fiber number, return (tube_no, name, bg_hex, font_hex)."""
    idx = (fiber_num_1based - 1) // 12
    name, bg, fg = TUBE_COL[idx % 12]
    return idx + 1, name, bg, fg

def fiber_range(tube_no, fiber_count):
    start = (tube_no - 1) * 12 + 1
    end   = min(start + 11, fiber_count)
    return f'F{start}–F{end}'

def cable_fibers(cblcpty):
    try:
        return int(str(cblcpty).replace('F',''))
    except:
        return 0

# ── Zone styling ──────────────────────────────────────────────────────────
ZONE_BG   = {'17':'DDEEFF','18':'DFFFD6','19':'FFF2CC','20':'FFE0E0','':'F9F9F9'}
ZONE_HDR  = {'17':'1F4E79','18':'375623','19':'7B5A00','20':'832323','':'404040'}

def zf(zone):  return PatternFill('solid', fgColor=ZONE_BG.get(str(zone),'F9F9F9'))
def zhf(zone): return PatternFill('solid', fgColor=ZONE_HDR.get(str(zone),'404040'))
def tf(bg):    return PatternFill('solid', fgColor=bg)

THIN  = Side(style='thin',  color='BBBBBB')
MED   = Side(style='medium',color='888888')
BORD  = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
BORD_TOP = Border(left=THIN, right=THIN, top=MED,  bottom=THIN)

HF = Font(bold=True, color='FFFFFF', size=9)
BF = Font(size=9)
MF = Font(name='Courier New', size=8)

def hcell(c, val, bg='1F4E79'):
    c.value = val; c.font = HF
    c.fill  = PatternFill('solid', fgColor=bg)
    c.border = BORD
    c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)

def bcell(c, val, fill=None, bold=False, center=False, mono=False):
    c.value = val
    c.font  = Font(bold=bold, size=9, name='Courier New' if mono else 'Calibri')
    if fill: c.fill = fill
    c.border = BORD
    c.alignment = Alignment(
        horizontal='center' if center else 'left',
        vertical='center', wrap_text=True)

def tcell(c, val, bg, fg):
    c.value = val
    c.font  = Font(bold=True, size=9, color=fg)
    c.fill  = PatternFill('solid', fgColor=bg)
    c.border = BORD
    c.alignment = Alignment(horizontal='center', vertical='center')

def set_col_widths(ws, widths):
    for col, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(col)].width = w

def write_header_row(ws, row, headers, bg='1F4E79', height=28):
    for col, h in enumerate(headers, 1):
        hcell(ws.cell(row, col), h, bg)
    ws.row_dimensions[row].height = height

# ── Label parsers ─────────────────────────────────────────────────────────
def parse_fts(label):
    """MOA.FTS.8.AGG.DM.P.G348-OLT.01.C16P01
    → (agg_dome, pole, olt_port, card, port_no)"""
    try:
        left, right = label.split('-', 1)
        # Extract pole from left: last P.XXXX
        lp = left.split('.')
        pi = next(i for i in range(len(lp)-1, -1, -1) if lp[i] == 'P')
        pole_code = lp[pi+1]
        full_pole = f'MOA.P.{pole_code}'
        agg_dome  = f'MOA.AGG.DM.P.{pole_code}'
        # OLT port from right
        rp = right.split('.')
        olt_port = rp[-1]  # C16P01
        m = re.match(r'C(\d+)P(\d+)', olt_port)
        card, port = (int(m.group(1)), int(m.group(2))) if m else (0, 0)
        return agg_dome, full_pole, olt_port, card, port
    except:
        return label, '', '', 0, 0

def parse_sts(label):
    """MOA.STS.16.DIS.DM.P.F446.C16P02.L1
    → (dis_dome, pole, olt_port, leg_str, card, port_no)"""
    try:
        parts = label.split('.')
        pi = next(i for i in range(len(parts)-1,-1,-1)
                  if parts[i]=='P' and i < len(parts)-3)
        pole_code = parts[pi+1]
        dis_dome  = f'MOA.DIS.DM.P.{pole_code}'
        full_pole = f'MOA.P.{pole_code}'
        olt_port  = parts[pi+2]  # C16P02
        leg       = parts[pi+3]  # L1
        m = re.match(r'C(\d+)P(\d+)', olt_port)
        card, port = (int(m.group(1)), int(m.group(2))) if m else (0, 0)
        return dis_dome, full_pole, olt_port, leg, card, port
    except:
        return label, '', '', '', 0, 0

def olt_to_pon(card, port):
    """Map OLT card/port to PON number. C15P11=235 … C19P10=298."""
    offsets = {15: 224, 16: 240, 17: 256, 18: 272, 19: 288}
    base = offsets.get(card)
    if base is None: return None
    pon = base + port
    return pon if 235 <= pon <= 298 else None

# ── Pre-process data ──────────────────────────────────────────────────────

# Build FTS index: olt_port → fts record
fts_by_port = {}
for f in fts_data:
    lbl = f.get('label','')
    agg, pole, olt_port, card, port = parse_fts(lbl)
    pon = olt_to_pon(card, port) or f.get('pon_no','')
    f['_agg_dome'] = agg
    f['_pole']     = pole
    f['_olt_port'] = olt_port
    f['_card']     = card
    f['_port']     = port
    f['_pon']      = str(pon) if pon else str(f.get('pon_no',''))
    f['_zone']     = f.get('zone_no','')
    fts_by_port[olt_port] = f

# Build STS index: olt_port → list of STS records
sts_by_port = defaultdict(list)
for s in sts_data:
    lbl = s.get('label','')
    dis, pole, olt_port, leg, card, port = parse_sts(lbl)
    pon = olt_to_pon(card, port) or s.get('pon_no','')
    s['_dis_dome']  = dis
    s['_pole']      = pole
    s['_olt_port']  = olt_port
    s['_leg']       = leg
    s['_leg_no']    = int(leg[1:]) if re.match(r'L\d+', leg) else 99
    s['_card']      = card
    s['_port']      = port
    s['_pon']       = str(pon) if pon else str(s.get('pon_no',''))
    s['_zone']      = s.get('zone_no','')
    sts_by_port[olt_port].append(s)

# Build drop index: DIS dome label → list of drops (sorted by DR label)
drops_by_dome = defaultdict(list)
for dr in drops:
    sf = dr.get('strtfeat','')
    if sf:
        drops_by_dome[sf].append(dr)
for dome_key in drops_by_dome:
    drops_by_dome[dome_key].sort(key=lambda x: x.get('label',''))

# Build AGG dome index by label
agg_by_label = {a.get('label_1',''):a for a in agg_domes}
# Build DIS dome index by label
dis_by_label = {d.get('label_1',''):d for d in dis_domes}

# ONT count per PON (already have pon_counts)
def ont_count(pon):
    return int(pon_counts.get(str(pon), 0))

# PON → zone formula
def pon_zone(pon):
    try: return (int(pon) - 235) // 16 + 17
    except: return ''

# PON → OLT port string
def pon_to_olt(pon):
    try:
        p = int(pon)
        if 235 <= p <= 240: return f'C15P{p-224:02d}'
        if 241 <= p <= 256: return f'C16P{p-240:02d}'
        if 257 <= p <= 272: return f'C17P{p-256:02d}'
        if 273 <= p <= 288: return f'C18P{p-272:02d}'
        if 289 <= p <= 298: return f'C19P{p-288:02d}'
    except:
        pass
    return ''

# ── Workbook ──────────────────────────────────────────────────────────────
wb = Workbook()

# ════════════════════════════════════════════════════════════════════════════
# SHEET 1 — COVER
# ════════════════════════════════════════════════════════════════════════════
ws = wb.active
ws.title = '1. Cover'
ws.column_dimensions['A'].width = 32
ws.column_dimensions['B'].width = 44

ws.merge_cells('A1:B1')
c = ws['A1']
c.value = 'FIBER SPLICE PLAN'
c.font  = Font(bold=True, size=16, color='FFFFFF')
c.fill  = PatternFill('solid', fgColor='1F4E79')
c.alignment = Alignment(horizontal='center', vertical='center')
ws.row_dimensions[1].height = 36

ws.merge_cells('A2:B2')
c = ws['A2']
c.value = 'MOA — Potch Mohadin Phase 2'
c.font  = Font(bold=True, size=12, color='FFFFFF')
c.fill  = PatternFill('solid', fgColor='2E75B6')
c.alignment = Alignment(horizontal='center', vertical='center')
ws.row_dimensions[2].height = 22

def info_pair(r, label, val):
    a = ws.cell(r, 1, label); b = ws.cell(r, 2, val)
    a.font = Font(bold=True, size=9); b.font = Font(size=9)
    a.fill = PatternFill('solid', fgColor='D6E4F0')
    a.border = BORD; b.border = BORD
    a.alignment = Alignment(vertical='center')
    b.alignment = Alignment(vertical='center')

total_onts = sum(int(v) for v in pon_counts.values() if str(v).isdigit())

rows = [
    ('Operator',          'VelocityFibre / Fibertime'),
    ('Municipality',      'JB Marks Local Municipality'),
    ('Technology',        'GPON FTTH — Aerial / Overhead'),
    ('Date Prepared',     '2026-05-21'),
    ('Prepared By',       'VelocityFibre Planning'),
    ('', ''),
    ('PON Range',         '235 – 298  (64 PONs total)'),
    ('Zone Range',        '17 – 20  (16 PONs per zone)'),
    ('OLT Card/Port',     'C15P11 – C19P10'),
    ('Splitter Cascade',  '1:8 FTS  →  1:16 STS  =  128 max ONTs per PON'),
    ('Power Budget',      'B+ class (28 dB).  Cascade loss ≈ 24.5 dB.  Margin ~3.5 dB'),
    ('', ''),
    ('Total ONTs',        f'{total_onts:,}'),
    ('Total Drop Cables', f'{len(drops):,}'),
    ('Primary Cables',    str(len(primary))),
    ('Secondary Cables',  str(len(secondary))),
    ('Distribution Cables', str(len(distribution))),
    ('FTS Splitters (1:8)', str(len(fts_data))),
    ('STS Splitters (1:16)', str(len(sts_data))),
    ('AGG Domes (splice)', str(len(agg_domes))),
    ('DIS Domes (connector)', str(len(dis_domes))),
    ('', ''),
    ('Max Span — Feeder/Dist', '70 m (ADSS)'),
    ('Max Span — Drop',        '50 m'),
    ('Fusion Splice Loss',     '≤ 0.1 dB target  (TIA-568.3-D)'),
    ('Connector Loss (SC/APC)','≤ 0.5 dB  (IEC 61300-3-35)'),
]
for i, (lbl, val) in enumerate(rows, 3):
    info_pair(i, lbl, val)

# Zone key
r0 = len(rows) + 5
ws.cell(r0, 1, 'ZONE COLOUR KEY').font = Font(bold=True, size=9)
for i, (z, col) in enumerate({'17':'1F4E79','18':'375623','19':'7B5A00','20':'832323'}.items()):
    r = r0 + 1 + i
    c1 = ws.cell(r, 1, f'Zone {z}')
    c1.fill = PatternFill('solid', fgColor=ZONE_BG[z])
    c1.font = Font(bold=True, size=9)
    c1.border = BORD
    c1.alignment = Alignment(horizontal='center')
    c2 = ws.cell(r, 2, f'Rows coloured {["blue","green","yellow","red"][i]} in all data sheets')
    c2.fill = PatternFill('solid', fgColor=ZONE_BG[z]); c2.border = BORD; c2.font = Font(size=9)

# TIA-598-C tube legend
r1 = r0 + 7
ws.cell(r1, 1, 'TUBE COLOUR CODE (TIA-598-C)').font = Font(bold=True, size=9)
ws.cell(r1, 2, 'Fibers per tube: 12  |  Cable labels show F1–F12, F13–F24, etc.').font = Font(size=9)
for i, (name, bg, fg) in enumerate(TUBE_COL):
    r = r1 + 1 + i
    tcell(ws.cell(r,1), f'Tube {i+1}', bg, fg)
    tcell(ws.cell(r,2), name, bg, fg)

# ════════════════════════════════════════════════════════════════════════════
# SHEET 2 — CLOSURE MASTER
# All AGG domes (fusion splice) + DIS domes (connectorised)
# ════════════════════════════════════════════════════════════════════════════
ws2 = wb.create_sheet('2. Closure Master')
hdrs2 = ['Closure ID','Type','Splice / Term','Closure Spec',
          'Closure Capacity','Pole ID','GPS Lat','GPS Lon',
          'Zone','PON','Inbound Cable(s)','In Fiber Count',
          'Outbound / Connected Cable(s)','Out Fiber Count',
          'Spare Fibers','Technician','Date Completed','OTDR / Test','Notes']
widths2 = [30,10,14,12,14,16,14,14,6,6,30,12,30,12,10,16,14,14,22]
set_col_widths(ws2, widths2)
write_header_row(ws2, 1, hdrs2, '1F4E79')
ws2.freeze_panes = 'A2'
ws2.auto_filter.ref = f'A1:{get_column_letter(len(hdrs2))}1'

row2 = 2
# AGG domes — fusion splice closures (FTS enclosures)
for a in sorted(agg_domes, key=lambda x: (x.get('zone_no') or '', x.get('pon_no') or '', x.get('label_1') or '')):
    zone = a.get('zone_no','')
    fill = zf(zone)
    vals = [
        a.get('label_1',''),
        'AGG Dome',
        'Fusion Splice',
        a.get('spec_1',''),
        a.get('cblcpty1',''),
        a.get('strtfeat',''),
        a.get('lat',''),
        a.get('lon',''),
        zone,
        a.get('pon_no',''),
        '',   # inbound cable — would need route trace
        '',
        '',   # outbound
        '',
        '',   # spare
        '',   # tech
        '',   # date
        '',   # OTDR
        '',
    ]
    for col, v in enumerate(vals, 1):
        bcell(ws2.cell(row2, col), v, fill=fill,
              center=(col in (2,3,7,8,9,10,12,14,15,17)))
    row2 += 1

# DIS domes — connectorised termination points (STS enclosures)
for a in sorted(dis_domes, key=lambda x: (x.get('zone_no') or '', x.get('pon_no') or '', x.get('label_1') or '')):
    zone = a.get('zone_no','')
    fill = PatternFill('solid', fgColor='F7FBFF')  # lighter, connector type
    vals = [
        a.get('label_1',''),
        'DIS Dome',
        'Connectorised (LC/APC)',
        a.get('spec_1',''),
        a.get('cblcpty1',''),
        a.get('strtfeat',''),
        a.get('lat',''),
        a.get('lon',''),
        zone,
        a.get('pon_no',''),
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        'Pre-terminated — no OTDR required',
        '',
    ]
    for col, v in enumerate(vals, 1):
        bcell(ws2.cell(row2, col), v, fill=fill,
              center=(col in (2,3,7,8,9,10,12,14,15,17)))
    row2 += 1

print(f'Sheet 2: {row2-2} closure rows')

# ════════════════════════════════════════════════════════════════════════════
# SHEET 3 — FEEDER FIBER MAP
# One row per PON showing OLT port → cable → FTS fiber assignment
# ════════════════════════════════════════════════════════════════════════════
ws3 = wb.create_sheet('3. Feeder Fiber Map')
hdrs3 = ['PON #','Zone','OLT Card','OLT Port','FTS Label',
          'AGG Dome (FTS Location)','FTS Pole',
          'Input Cable Label','Cable Type','Cable Size (F)',
          'Assigned Fiber #','Tube #','Tube Colour','Fiber Range in Tube',
          'OLT Tx Power (dBm)','Notes']
widths3 = [7,6,9,9,48,26,16,38,16,11,12,8,12,16,16,24]
set_col_widths(ws3, widths3)
write_header_row(ws3, 1, hdrs3, '1F4E79')
ws3.freeze_panes = 'A2'
ws3.auto_filter.ref = f'A1:{get_column_letter(len(hdrs3))}1'

# Build feeder map from FTS data — sort by PON
fts_sorted = sorted(fts_data, key=lambda x: (x.get('_pon') or '999', x.get('label') or ''))

# Assign fiber numbers per cable group
# Cable grouping: cluster FTS by their secondary cable (group by zone → sequential within zone)
zone_pon_counter = defaultdict(int)

row3 = 2
for f in fts_sorted:
    pon  = f.get('_pon','')
    zone = f.get('_zone','')
    try:
        zone_pon_counter[zone] += 1
        global_fiber_in_zone = zone_pon_counter[zone]
        tube_no, tube_name, tube_bg, tube_fg = tube_info(global_fiber_in_zone)
        fiber_no = global_fiber_in_zone
    except:
        fiber_no = 0; tube_no = 1; tube_name = ''; tube_bg = 'F0F0F0'; tube_fg = '000000'

    olt_port = f.get('_olt_port','')
    card_s   = f'C{f["_card"]}' if f.get('_card') else ''

    # Find a secondary cable for this PON
    sec_match = next((s for s in secondary if str(s.get('pon_no',''))==str(pon)), None)
    if not sec_match:
        sec_match = next((s for s in distribution if str(s.get('pon_no',''))==str(pon)), None)

    cab_label = sec_match.get('label','—') if sec_match else '—'
    cab_type  = sec_match.get('ntwrkptn','—') if sec_match else '—'
    cab_size  = sec_match.get('cblcpty','—') if sec_match else '—'
    fill      = zf(zone)

    vals = [
        pon, zone, card_s, olt_port,
        f.get('label',''),
        f.get('_agg_dome',''),
        f.get('_pole',''),
        cab_label, cab_type, cab_size,
        fiber_no, tube_no, tube_name,
        f'F{fiber_no}' if fiber_no else '',
        '',  # OLT Tx Power (blank — field fill)
        '',
    ]
    for col, v in enumerate(vals, 1):
        c = ws3.cell(row3, col, v)
        c.border = BORD
        if col in (13, 14):  # tube colour cells
            tcell(c, v, tube_bg, tube_fg)
        else:
            c.font  = Font(size=9, bold=(col <= 4))
            c.fill  = fill
            c.alignment = Alignment(
                horizontal='center' if col in (1,2,3,4,10,11,12,14,15) else 'left',
                vertical='center', wrap_text=True)
    row3 += 1

print(f'Sheet 3: {row3-2} feeder fiber rows')

# ════════════════════════════════════════════════════════════════════════════
# SHEET 4 — FTS SPLICE SCHEDULE
# Per FTS: shows the 1:8 split — input fiber → each of 8 output legs → STS dome
# ════════════════════════════════════════════════════════════════════════════
ws4 = wb.create_sheet('4. FTS Splice Schedule')
hdrs4 = ['AGG Dome (FTS)','Pole','Zone','PON','OLT Port',
          'Input Cable','In Fiber #','In Tube','In Colour',
          'FTS Leg','STS Dome (DIS)','STS Pole',
          'Out Fiber #','Out Tube','Out Colour',
          'Distribution Cable','Splice Tray','Tray Slot',
          'Splice Loss (dB)','Notes']
widths4 = [28,16,6,6,10,30,10,8,12,8,28,16,10,8,12,36,10,9,14,22]
set_col_widths(ws4, widths4)
write_header_row(ws4, 1, hdrs4, '375623')
ws4.freeze_panes = 'A2'
ws4.auto_filter.ref = f'A1:{get_column_letter(len(hdrs4))}1'

row4 = 2
for f in sorted(fts_data, key=lambda x: (x.get('_zone') or '9', x.get('_pon') or '999')):
    olt_port = f.get('_olt_port','')
    pon      = f.get('_pon','')
    zone     = f.get('_zone','')
    agg_dome = f.get('_agg_dome','')
    pole     = f.get('_pole','')

    # Input fiber info (from Sheet 3 — same zone-sequential assignment)
    zone_idx = (int(pon) - 235) % 16 + 1 if pon.isdigit() else 1
    t_no, t_name, t_bg, t_fg = tube_info(zone_idx)

    # Get all STS for this OLT port, sorted by leg number
    sts_list = sorted(sts_by_port.get(olt_port, []), key=lambda x: x.get('_leg_no', 99))

    # Find distribution cables for this PON
    dist_for_pon = [dc for dc in distribution if str(dc.get('pon_no',''))==str(pon)]

    if not sts_list:
        # Write one placeholder row
        vals = [agg_dome, pole, zone, pon, olt_port,
                '—', zone_idx, t_no, t_name,
                '—','—','—','—','—','—','—','','','','No STS found']
        fill = zf(zone)
        for col, v in enumerate(vals, 1):
            c = ws4.cell(row4, col, v)
            c.border = BORD; c.font = Font(size=9); c.fill = fill
            c.alignment = Alignment(vertical='center', horizontal='center' if col in (3,4,5,7,8,10,13,14) else 'left')
        row4 += 1
        continue

    # One row per FTS output leg / STS
    for leg_idx, s in enumerate(sts_list, 1):
        leg    = s.get('_leg','')
        dis    = s.get('_dis_dome','')
        s_pole = s.get('_pole','')
        # Match a distribution cable to this STS dome (by pole reference)
        dc_match = next((dc for dc in dist_for_pon if
                         s_pole in (dc.get('strtfeat',''), dc.get('endfeat',''))), None)
        if not dc_match and dist_for_pon:
            dc_match = dist_for_pon[min(leg_idx-1, len(dist_for_pon)-1)]
        dc_label = dc_match.get('label','—') if dc_match else '—'

        fill = zf(zone)
        is_first = (leg_idx == 1)

        vals = [
            agg_dome  if is_first else '',
            pole      if is_first else '',
            zone      if is_first else '',
            pon       if is_first else '',
            olt_port  if is_first else '',
            '',                          # input cable (blank — from Sheet 3)
            zone_idx  if is_first else '',
            t_no      if is_first else '',
            t_name    if is_first else '',
            leg,
            dis, s_pole,
            '',   # out fiber — same as in (straight-through in FTS)
            '',   # out tube
            '',   # out colour
            dc_label,
            '',   # splice tray
            '',   # tray slot
            '',   # loss
            '',
        ]
        for col, v in enumerate(vals, 1):
            c = ws4.cell(row4, col, v)
            c.border = BORD
            if col == 9 and is_first:  # in colour
                tcell(c, v, t_bg, t_fg)
            elif col == 15:  # out colour placeholder
                c.font = Font(size=9); c.fill = fill
                c.alignment = Alignment(vertical='center')
            else:
                c.font  = Font(size=9, bold=is_first and col <= 5)
                c.fill  = fill
                c.alignment = Alignment(
                    horizontal='center' if col in (3,4,5,7,8,10,13,14,17,18,19) else 'left',
                    vertical='center', wrap_text=True)
        row4 += 1

print(f'Sheet 4: {row4-2} FTS splice schedule rows')

# ════════════════════════════════════════════════════════════════════════════
# SHEET 5 — STS PORT REGISTER
# Per STS dome: which LC/APC port → which drop cable → which ONT
# One row per drop cable (connectorised, not fusion spliced)
# ════════════════════════════════════════════════════════════════════════════
ws5 = wb.create_sheet('5. STS Port Register')
hdrs5 = ['DIS Dome (STS)','STS Splitter Label','FTS Leg','Zone','PON',
          'Pole','GPS Lat','GPS Lon',
          'Input Fiber #','Input Tube','Input Colour',
          'LC Port #','Drop Cable (DR#)','ONT Label',
          'Drop Length (m)','Connector Loss (dB)','ONT RX Level (dBm)','Notes']
widths5 = [28,44,8,6,6,16,13,13,11,9,12,9,18,26,14,16,18,22]
set_col_widths(ws5, widths5)
write_header_row(ws5, 1, hdrs5, '7B3F00')
ws5.freeze_panes = 'A2'
ws5.auto_filter.ref = f'A1:{get_column_letter(len(hdrs5))}1'

row5 = 2
sts_sorted_all = sorted(sts_data,
    key=lambda x: (x.get('_zone') or '9', x.get('_pon') or '999',
                   x.get('_dis_dome') or '', x.get('_leg_no') or 99))

for s in sts_sorted_all:
    dis    = s.get('_dis_dome','')
    pole   = s.get('_pole','')
    zone   = s.get('_zone','')
    pon    = s.get('_pon','')
    leg    = s.get('_leg','')
    lat    = s.get('lat','')
    lon    = s.get('lon','')
    lbl    = s.get('label','')

    # Input fiber: same zone-sequential number as assigned in Sheet 3
    zone_idx = (int(pon) - 235) % 16 + 1 if str(pon).isdigit() else 1
    t_no, t_name, t_bg, t_fg = tube_info(zone_idx)
    fill = zf(zone)

    # Drops connected to this DIS dome
    dome_drops = drops_by_dome.get(dis, [])

    if not dome_drops:
        # Write 16 empty port rows to show the capacity
        for port in range(1, 17):
            is_first = (port == 1)
            vals = [
                dis    if is_first else '',
                lbl    if is_first else '',
                leg    if is_first else '',
                zone   if is_first else '',
                pon    if is_first else '',
                pole   if is_first else '',
                lat    if is_first else '',
                lon    if is_first else '',
                zone_idx if is_first else '',
                t_no   if is_first else '',
                t_name if is_first else '',
                port,
                '— (spare)',
                '',
                '',  # drop length
                '',  # loss
                '',  # rx level
                '',
            ]
            for col, v in enumerate(vals, 1):
                c = ws5.cell(row5, col, v)
                c.border = BORD
                if col == 11 and is_first:
                    tcell(c, v, t_bg, t_fg)
                else:
                    c.font  = Font(size=9, bold=is_first and col <= 6)
                    c.fill  = PatternFill('solid', fgColor='F5F5F5')
                    c.alignment = Alignment(
                        horizontal='center' if col in (3,4,5,9,10,12,15,16,17) else 'left',
                        vertical='center')
            row5 += 1
    else:
        # Write one row per drop, assign LC port sequentially
        for port, dr in enumerate(dome_drops, 1):
            is_first = (port == 1)
            vals = [
                dis    if is_first else '',
                lbl    if is_first else '',
                leg    if is_first else '',
                zone   if is_first else '',
                pon    if is_first else '',
                pole   if is_first else '',
                lat    if is_first else '',
                lon    if is_first else '',
                zone_idx if is_first else '',
                t_no   if is_first else '',
                t_name if is_first else '',
                port,
                dr.get('label',''),
                dr.get('endfeat',''),
                dr.get('dim2',''),
                '',  # connector loss
                '',  # rx level
                '',
            ]
            for col, v in enumerate(vals, 1):
                c = ws5.cell(row5, col, v)
                c.border = BORD
                if col == 11 and is_first:
                    tcell(c, v, t_bg, t_fg)
                else:
                    c.font  = Font(size=9, bold=is_first and col <= 6)
                    c.fill  = fill
                    c.alignment = Alignment(
                        horizontal='center' if col in (3,4,5,9,10,12,15,16,17) else 'left',
                        vertical='center')
            row5 += 1
        # Remaining spare ports
        used = len(dome_drops)
        for port in range(used + 1, 17):
            vals = ['','','','','','','','','','','', port, '— (spare)', '','','','','']
            for col, v in enumerate(vals, 1):
                c = ws5.cell(row5, col, v)
                c.border = BORD
                c.font   = Font(size=9, color='999999')
                c.fill   = PatternFill('solid', fgColor='F5F5F5')
                c.alignment = Alignment(horizontal='center' if col == 12 else 'left', vertical='center')
            row5 += 1

print(f'Sheet 5: {row5-2} STS port rows')

# ════════════════════════════════════════════════════════════════════════════
# SHEET 6 — PON AUDIT
# One row per PON: zone, OLT port, FTS, STS count, ONT count, fill rate
# ════════════════════════════════════════════════════════════════════════════
ws6 = wb.create_sheet('6. PON Audit')
hdrs6 = ['PON #','Zone','OLT Port','FTS Label','AGG Dome','FTS Pole',
          '# STS Modules','# ONTs','Max Capacity (128)',
          'Fill Rate (%)','Spare Ports','Dist Cables',
          'Status','Notes']
widths6 = [7,6,9,48,26,16,13,9,16,12,12,12,14,24]
set_col_widths(ws6, widths6)
write_header_row(ws6, 1, hdrs6, '7030A0')
ws6.freeze_panes = 'A2'
ws6.auto_filter.ref = f'A1:{get_column_letter(len(hdrs6))}1'

row6 = 2
for pon_no in range(235, 299):
    pon  = str(pon_no)
    zone = str(pon_zone(pon_no))
    olt  = pon_to_olt(pon_no)
    fill = zf(zone)

    fts_rec  = fts_by_port.get(olt)
    fts_lbl  = fts_rec.get('label','—')    if fts_rec else '—'
    agg      = fts_rec.get('_agg_dome','—') if fts_rec else '—'
    fts_pole = fts_rec.get('_pole','—')     if fts_rec else '—'

    sts_list  = sts_by_port.get(olt, [])
    n_sts     = len(sts_list)
    n_ont     = ont_count(pon_no)
    max_cap   = 128
    fill_rate = round(n_ont / max_cap * 100, 1) if max_cap else 0
    spare     = max_cap - n_ont
    n_dist    = len([dc for dc in distribution if str(dc.get('pon_no',''))==pon])

    if fill_rate >= 95:   status = 'FULL'
    elif fill_rate >= 80: status = 'High'
    elif fill_rate >= 50: status = 'Medium'
    elif n_ont > 0:       status = 'Low'
    else:                 status = 'Empty'

    vals = [pon_no, zone, olt, fts_lbl, agg, fts_pole,
            n_sts, n_ont, max_cap,
            f'{fill_rate}%', spare, n_dist, status, '']
    for col, v in enumerate(vals, 1):
        c = ws6.cell(row6, col, v)
        c.border = BORD
        c.font   = Font(size=9, bold=(col<=3))
        c.fill   = fill
        c.alignment = Alignment(
            horizontal='center' if col in (1,2,3,7,8,9,10,11,12,13) else 'left',
            vertical='center')
        # Colour the fill-rate cell
        if col == 10:
            if fill_rate >= 95:   c.fill = PatternFill('solid', fgColor='FF9999')
            elif fill_rate >= 80: c.fill = PatternFill('solid', fgColor='FFCC99')
            elif fill_rate >= 50: c.fill = PatternFill('solid', fgColor='FFFFCC')
            else:                 c.fill = PatternFill('solid', fgColor='CCFFCC')
    row6 += 1

print(f'Sheet 6: {row6-2} PON audit rows')

# ── Save ──────────────────────────────────────────────────────────────────
out = r'C:/Users/jjsch/OneDrive/ON LAPTOP FIBRE/QGIS test/MOA_Splice_Plan_v2.xlsx'
wb.save(out)
print(f'\nSaved: {out}')
print(f'Sheets: {[s.title for s in wb.worksheets]}')
