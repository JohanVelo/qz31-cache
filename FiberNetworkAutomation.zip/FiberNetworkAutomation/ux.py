"""ux — shared UX helpers: step progress dialog + What's-New-on-upgrade popup.

Deliberately uses a modal QProgressDialog driven on the main thread with
processEvents() between steps — NOT a background QgsTask. Processing algorithms
here mutate layer data providers; keeping them on the main thread avoids the
threading hazards (and the access-violation class) while still giving the user
clear "step 3 of 8" feedback and a Cancel button. QGIS never looks frozen.
"""


def _vf_style():
    try:
        from .branding import vf_style
        return vf_style
    except ImportError:
        try:
            from branding import vf_style
            return vf_style
        except Exception:
            return None


class StepProgress:
    """Context manager: a themed, cancelable progress dialog over N named steps.

        with StepProgress(iface, 'Run All FT', steps) as prog:
            for name, fn in steps_with_fns:
                if prog.canceled: break
                prog.step(name)
                fn()
    """

    def __init__(self, iface, title, step_names):
        self.iface = iface
        self.title = title
        self.steps = list(step_names)
        self.dlg = None
        self._i = 0
        self.canceled = False

    def __enter__(self):
        from qgis.PyQt.QtWidgets import QProgressDialog
        from qgis.PyQt.QtCore import Qt
        self.dlg = QProgressDialog(self.iface.mainWindow())
        self.dlg.setWindowTitle('Velocity Fibre')
        self.dlg.setLabelText(f'{self.title}…')
        self.dlg.setRange(0, len(self.steps))
        self.dlg.setWindowModality(Qt.WindowModal)
        self.dlg.setMinimumWidth(420)
        self.dlg.setAutoClose(False)
        self.dlg.setAutoReset(False)
        st = _vf_style()
        if st:
            try:
                self.dlg.setStyleSheet(st.DIALOG_QSS)
            except Exception:
                pass
        self.dlg.show()
        from qgis.PyQt.QtWidgets import QApplication
        QApplication.processEvents()
        return self

    def step(self, name):
        from qgis.PyQt.QtWidgets import QApplication
        self._i += 1
        if self.dlg is not None:
            self.dlg.setValue(self._i - 1)
            self.dlg.setLabelText(f'[{self._i}/{len(self.steps)}]  {name} …')
            if self.dlg.wasCanceled():
                self.canceled = True
        QApplication.processEvents()

    def done(self):
        if self.dlg is not None:
            self.dlg.setValue(len(self.steps))

    def __exit__(self, *exc):
        try:
            if self.dlg is not None:
                self.dlg.close()
                self.dlg.deleteLater()
        except Exception:
            pass
        return False


def _changelog_top(plugin_dir):
    """Return the first changelog block from metadata.txt (the newest release)."""
    import os
    import re
    try:
        txt = open(os.path.join(plugin_dir, 'metadata.txt'), encoding='utf-8').read()
    except Exception:
        return ''
    m = re.search(r'changelog=(.*?)(?:\n\w+=|\Z)', txt, re.S)
    if not m:
        return ''
    block = m.group(1).strip()
    # keep only the first version entry (up to the second "  X.Y.Z -")
    entries = re.split(r'\n(?=\s*\d+\.\d+\.\d+\s*-)', block)
    return entries[0].strip() if entries else block


def maybe_show_whats_new(iface, plugin_dir, version):
    """Show a 'What's New' popup once per new version (after an upgrade).
    Stored in QgsSettings so it fires exactly once per version per machine."""
    from qgis.core import QgsSettings
    s = QgsSettings()
    seen = s.value('VelocityFibre/whatsNewVersion', '')
    if seen == version:
        return
    s.setValue('VelocityFibre/whatsNewVersion', version)
    if not seen:
        return  # first ever install — the welcome screen covers this, skip
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton, QHBoxLayout
    notes = _changelog_top(plugin_dir)
    dlg = QDialog(iface.mainWindow())
    dlg.setWindowTitle('Velocity Fibre — What’s New')
    dlg.setMinimumWidth(460)
    lay = QVBoxLayout(dlg)
    lay.setContentsMargins(16, 12, 16, 14)
    lay.setSpacing(10)
    head = QLabel(f'<div style="font-size:15px;font-weight:700;">Updated to v{version} 🎉</div>')
    head.setTextFormat(Qt.RichText)
    lay.addWidget(head)
    body = QLabel('<pre style="white-space:pre-wrap;font-family:Segoe UI;">'
                  + (notes or 'See the menu for the latest tools.') + '</pre>')
    body.setTextFormat(Qt.RichText)
    body.setWordWrap(True)
    lay.addWidget(body)
    row = QHBoxLayout()
    row.addStretch(1)
    ok = QPushButton('Got it')
    row.addWidget(ok)
    lay.addLayout(row)
    ok.clicked.connect(dlg.accept)
    st = _vf_style()
    if st:
        try:
            st.apply_vf_style(dlg, title=f'Version {version}')
        except Exception:
            pass
    dlg.show()
    dlg.raise_()
    return dlg
