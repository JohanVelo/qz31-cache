"""
AI gap-fill (Phase 3, Layer 2) — detect buildings inside a gap region with no
prompts, for houses no footprint source has (new builds, obscured roofs).

Pipeline per gap: fetch SA NGI aerial (legal) as a web-mercator mosaic → SAM2
AutomaticMaskGenerator → mask→polygon → false-positive filters (vegetation,
shadow, geometry) → regularise → return EPSG:4326 polygons with a confidence.

Subprocess-side only (imports torch/sam2/rasterio/cv2). Deterministic-ish: SAM2
automask is not seeded but this feeds the review-flagged layer, not final data.
Tuning follows the "Remote SAMsing" recipe + our building_like gates.
"""
from __future__ import annotations

import io
import math

import numpy as np

R = 6378137.0                       # web-mercator radius
NGI_URL = "https://aerial.openstreetmap.org.za/layer/ngi-aerial/{z}/{x}/{y}.jpg"
SAM2_CFG = "configs/sam2.1/sam2.1_hiera_t.yaml"

# false-positive gates (0.25-0.3 m/px SA informal roofs)
AREA_MIN_M2, AREA_MAX_M2 = 6.0, 600.0
EXG_VEG = 0.10                      # excess-green above this = vegetation
VEG_GREEN_FRAC = 0.45               # >45% green-hued pixels (HSV) = vegetation
SOLIDITY_MIN = 0.60
ASPECT_MAX = 4.0
PP_MIN, PP_MAX = 0.30, 0.96         # Polsby-Popper compactness window


def _lonlat_to_merc(lon, lat):
    x = math.radians(lon) * R
    y = math.log(math.tan(math.pi / 4 + math.radians(lat) / 2)) * R
    return x, y


def fetch_ngi_mosaic(bbox_4326, zoom=19, timeout=30):
    """Return (rgb uint8 HxWx3, affine3857, (px_size_m)) for the bbox, or None."""
    import requests
    from PIL import Image
    from affine import Affine

    minx, miny, maxx, maxy = bbox_4326
    world = 2 * math.pi * R
    tsize = world / (2 ** zoom)          # tile edge in metres
    px = tsize / 256.0

    def tile_ix(lon, lat):
        mx, my = _lonlat_to_merc(lon, lat)
        return int((mx + math.pi * R) / tsize), int((math.pi * R - my) / tsize)

    tx0, ty0 = tile_ix(minx, maxy)       # top-left
    tx1, ty1 = tile_ix(maxx, miny)       # bottom-right
    tx0, tx1 = sorted((tx0, tx1))
    ty0, ty1 = sorted((ty0, ty1))
    ncols, nrows = tx1 - tx0 + 1, ty1 - ty0 + 1
    if ncols * nrows > 400:              # safety cap (~ big gap at z19)
        return None
    mosaic = Image.new("RGB", (ncols * 256, nrows * 256), (0, 0, 0))
    got = 0
    for tx in range(tx0, tx1 + 1):
        for ty in range(ty0, ty1 + 1):
            try:
                r = requests.get(NGI_URL.format(z=zoom, x=tx, y=ty), timeout=timeout)
                if r.status_code == 200:
                    im = Image.open(io.BytesIO(r.content)).convert("RGB")
                    mosaic.paste(im, ((tx - tx0) * 256, (ty - ty0) * 256))
                    got += 1
            except Exception:
                pass
    if got == 0:
        return None
    merc_x0 = -math.pi * R + tx0 * tsize
    merc_y0 = math.pi * R - ty0 * tsize
    aff = Affine(px, 0, merc_x0, 0, -px, merc_y0)
    return np.asarray(mosaic), aff, px


def _mask_generator(ckpt_path, device="cpu", points_per_side=28):
    import torch  # noqa: F401
    from sam2.build_sam import build_sam2
    from sam2.automatic_mask_generator import SAM2AutomaticMaskGenerator
    sam2 = build_sam2(SAM2_CFG, ckpt_path, device=device, apply_postprocessing=False)
    return SAM2AutomaticMaskGenerator(
        sam2,
        points_per_side=points_per_side,
        pred_iou_thresh=0.86,
        stability_score_thresh=0.90,
        crop_n_layers=0,
        min_mask_region_area=180,       # ~15 m² @ 0.3 m/px
        box_nms_thresh=0.5,
    )


def _exg(rgb, seg):
    px = rgb[seg]
    if px.size == 0:
        return 1.0
    r, g, b = px[:, 0].astype(float), px[:, 1].astype(float), px[:, 2].astype(float)
    denom = (2 * g + r + b) + 1e-6
    return float(np.mean((2 * g - r - b) / denom))


def _is_vegetation(rgb, seg):
    """True if the mask is vegetation. ExG catches bright grass; an HSV green-hue
    fraction catches DARK / shadowed tree canopies that ExG misses (their green
    isn't bright, but the hue is still green)."""
    px = rgb[seg]
    if px.size == 0:
        return True
    if _exg(rgb, seg) > EXG_VEG:
        return True
    import cv2
    hsv = cv2.cvtColor(px.reshape(-1, 1, 3).astype(np.uint8),
                       cv2.COLOR_RGB2HSV).reshape(-1, 3)
    h, s = hsv[:, 0].astype(int), hsv[:, 1].astype(int)
    green = (h >= 35) & (h <= 90) & (s >= 35)      # OpenCV hue 0-180; green band
    return float(np.mean(green)) > VEG_GREEN_FRAC


def detect_gap(bbox_4326, ckpt_path, *, zoom=19, mask_gen=None, aoi_clip=None):
    """Detect building polygons inside one gap bbox. Returns (features_4326, meta).

    features: list of {geometry(shapely 4326), confidence}. mask_gen may be passed
    in to reuse the loaded model across gaps.
    """
    import cv2  # noqa: F401
    import geopandas as gpd
    import rasterio.features as rf
    from shapely.geometry import shape as shp_shape

    fetched = fetch_ngi_mosaic(bbox_4326, zoom=zoom)
    if fetched is None:
        return [], {"error": "no_imagery"}
    rgb, aff, px = fetched
    lat0 = (bbox_4326[1] + bbox_4326[3]) / 2.0
    cos2 = math.cos(math.radians(lat0)) ** 2       # merc area -> true m²

    gen = mask_gen or _mask_generator(ckpt_path)
    masks = gen.generate(rgb)

    keep = []
    for m in masks:
        seg = m["segmentation"]
        if _is_vegetation(rgb, seg):                 # vegetation reject (ExG + HSV)
            continue
        polys = [shp_shape(g) for g, v in rf.shapes(seg.astype(np.uint8), mask=seg,
                                                    transform=aff) if v == 1]
        if not polys:
            continue
        poly = max(polys, key=lambda p: p.area)      # 3857 metres
        true_area = poly.area * cos2
        if not (AREA_MIN_M2 <= true_area <= AREA_MAX_M2):
            continue
        if poly.convex_hull.area <= 0 or (poly.area / poly.convex_hull.area) < SOLIDITY_MIN:
            continue
        mrr = poly.minimum_rotated_rectangle
        xs, ys = mrr.exterior.xy
        import numpy as _np
        e = [_np.hypot(xs[i + 1] - xs[i], ys[i + 1] - ys[i]) for i in range(4)]
        short, long_ = max(1e-6, min(e[0], e[1])), max(e[0], e[1])
        if long_ / short > ASPECT_MAX:
            continue
        pp = 4 * math.pi * poly.area / (poly.length ** 2 + 1e-9)
        if not (PP_MIN <= pp <= PP_MAX):
            continue
        keep.append((poly, float(m.get("predicted_iou", 0.0))))

    if not keep:
        return [], {"n_masks": len(masks), "kept": 0}

    gdf = gpd.GeoDataFrame(
        {"confidence": [c for _, c in keep]},
        geometry=[p for p, _ in keep], crs="EPSG:3857")
    try:
        from buildingregulariser import regularize_geodataframe
        gdf = regularize_geodataframe(gdf, allow_45_degree=False)
    except Exception:
        pass
    gdf = gdf.to_crs(4326)
    if aoi_clip is not None:
        gdf = gdf[gdf.geometry.representative_point().within(aoi_clip)]
    feats = [{"geometry": g, "confidence": float(c)}
             for g, c in zip(gdf.geometry, gdf["confidence"])]
    return feats, {"n_masks": len(masks), "kept": len(feats)}
