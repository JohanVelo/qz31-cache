"""HT 1 rules: one HeroTel demand point per erf (measured, 2026-09-23).

Derived from the delivered client packages, not invented (the measurements and the
towns are in research/ht01_verify/ and tests/_stress_ht01.py):

- Erven = Demand Units in every delivered package: one point per erf, vacant stands
  included. The delivered `Service Type` is the erf's `Key` - Vacant and School
  (sometimes written 'School ' with a trailing space); every blank Key is SDU.
- Every delivered demand point that lies inside an erf sits on that erf's centroid;
  `Count` is '1'; `x`/`y` hold longitude/latitude whatever the layer CRS; `Type` is
  one of SDU, Vacant, School, Church, FTTB SDU, Cell Tower.

`PON`, `Phase` and `DJ Num` are assigned later (HT 2 / HT 3), so HT 1 leaves them empty.
"""

#: The Demand Points `Type` vocabulary seen in the delivered towns, in canonical spelling.
SERVICE_TYPES = ("SDU", "Vacant", "School", "Church", "FTTB SDU", "Cell Tower")

DEFAULT_TYPE = "SDU"


def _is_null(value):
    return value is None or (hasattr(value, "isNull") and value.isNull())


def _text(key):
    text = "" if _is_null(key) else str(key).strip()
    return "" if text.upper() == "NULL" else text


def service_type(key):
    """The demand point's Type for an erf whose Key is `key`.

    A known type is returned in its canonical spelling, whatever its case or
    surrounding spaces. Blank, and anything not in SERVICE_TYPES, is a home (SDU):
    a delivered package typed its one 'Police' erf as SDU. Use unrecognised() to
    list the values that were folded into SDU.

    Case: one delivered package typed an erf whose Key is 'school' (lower case) as
    SDU. HT 1 matches case-insensitively and makes it a School - the one place it
    differs from a delivered town (asserted by name in the stress harness).
    """
    text = _text(key)
    for known in SERVICE_TYPES:
        if text.casefold() == known.casefold():
            return known
    return DEFAULT_TYPE


def unrecognised(key):
    """The trimmed Key when it is filled in but is not a known type, else None."""
    text = _text(key)
    if text and not any(text.casefold() == k.casefold() for k in SERVICE_TYPES):
        return text
    return None


def point_for(geometry):
    """Where the erf's demand point goes: its centroid, or a point on its surface
    when the centroid falls outside it (an L-shaped or multi-part erf). Returns
    (point geometry, moved) where `moved` says the centroid was not used."""
    centroid = geometry.centroid()
    if not centroid.isNull() and not centroid.isEmpty() and geometry.contains(centroid):
        return centroid, False
    return geometry.pointOnSurface(), True
