# -*- coding: utf-8 -*-
# "Generate HLD PDF" (BETA) — settings dialog + background run + PASS/FAIL report.
# The dialog is modal and short-lived (just collects settings). The heavy render runs
# in a separate QGIS process via a QgsTask, so the live session never freezes.
import os
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QLineEdit,
    QSpinBox, QCheckBox, QPushButton, QFileDialog, QMessageBox, QWidget, QComboBox,
)
from qgis.core import QgsApplication, QgsProject
from .presets import LOCKED_GRID_W_M, LOCKED_GRID_H_M


def _downloads():
    d = os.path.join(os.path.expanduser("~"), "Downloads")
    return d if os.path.isdir(d) else os.path.expanduser("~")


GRID_COV = "__grid__"


class HldPdfDialog(QDialog):
    DRAW_CODE = 100   # exec() return: the operator asked to draw the grid box on the canvas

    def __init__(self, parent, default_dir, meta, coverage_names, default_coverage,
                 coverage_layers=None, models=None, default_model="hld_atlas",
                 clients=None, default_client="fibertime", count_tables=None,
                 iface=None, cell_w_m=0.0, cell_h_m=0.0):
        super().__init__(parent)
        self.setWindowTitle("Generate HLD PDF  —  BETA")
        self.setMinimumWidth(600)
        self._iface = iface
        self._dir = default_dir
        self._title = meta.get("title", "HLD")
        self._cov_by_name = {l.name(): l for l in (coverage_layers or [])}
        self._count_tables = count_tables or []
        self._mode = "generate"   # "generate" = headless PDF · "layout" = edit in Print Layout
        self._cell_w_m = float(cell_w_m or 0.0)
        self._cell_h_m = float(cell_h_m or 0.0)

        c = _theme()
        root = QVBoxLayout(self)

        # BETA badge + explainer — colours derived from the live theme, never hardcoded
        badge = QLabel("● BETA")
        badge.setStyleSheet((f"color:{c['warn']};" if c["warn"] else "") + "font-weight:bold;")
        root.addWidget(badge)
        info = QLabel(
            "Builds an A3 map-book — an overview page plus one detail page per unit — "
            "with legend, north arrow, logo and title block.  Choose what each page covers, "
            "the look, and the title block below."
        )
        info.setWordWrap(True)
        if c["ink"]:
            info.setStyleSheet(f"color:{c['ink']};")   # body text: full contrast on any theme
        root.addWidget(info)

        # ── ① WHAT TO MAP (coverage — the per-page driver) ──
        root.addWidget(_section("① WHAT TO MAP  ·  one page per…"))
        covf = QFormLayout()
        self.cov_combo = QComboBox()
        self.cov_combo.addItem(
            f"▦  Grid over the AOI  ({LOCKED_GRID_W_M:.0f} × {LOCKED_GRID_H_M:.0f} m tiles)", GRID_COV)
        for n in coverage_names:
            self.cov_combo.addItem(n, n)
        # default selection: remembered layer, else grid if a size was captured, else first layer
        if default_coverage == GRID_COV or (self._cell_w_m > 0 and not default_coverage):
            self.cov_combo.setCurrentIndex(self.cov_combo.findData(GRID_COV))
        elif default_coverage and self.cov_combo.findData(default_coverage) >= 0:
            self.cov_combo.setCurrentIndex(self.cov_combo.findData(default_coverage))
        elif coverage_names:
            self.cov_combo.setCurrentIndex(self.cov_combo.findData(coverage_names[0]))
        covf.addRow("Each page shows:", self.cov_combo)

        # grid: FIXED plotting-grid tile size (locked — no longer operator-drawn).
        self.grid_size_lbl = QLabel(
            f"🔒  {LOCKED_GRID_W_M:.0f} × {LOCKED_GRID_H_M:.0f} m  (fixed — standard plotting grid)")
        self.grid_size_lbl.setStyleSheet((f"color:{c['ink']};" if c["ink"] else "") + "font-size:11px;")
        covf.addRow("Grid tile size:", self.grid_size_lbl)
        self.cov_preview = QLabel("")
        self.cov_preview.setStyleSheet((f"color:{c['accent']};" if c["accent"] else "") + "font-size:11px;")
        covf.addRow("", self.cov_preview)
        root.addLayout(covf)
        self.cov_combo.currentIndexChanged.connect(self._on_coverage_changed)

        # ── ② LOOK (layout model + client branding) ──
        root.addWidget(_section("② LOOK  ·  layout + branding"))
        mform = QFormLayout()
        self.model_combo = QComboBox()
        for mid, disp, _u in (models or [("hld_atlas", "HLD Network Atlas", False)]):
            self.model_combo.addItem(disp, mid)
        _mi = self.model_combo.findData(default_model)
        if _mi >= 0:
            self.model_combo.setCurrentIndex(_mi)
        mform.addRow("Layout model:", self.model_combo)

        self.client_combo = QComboBox()
        for cid, disp, _u in (clients or [("fibertime", "Fibertime", False)]):
            self.client_combo.addItem(disp, cid)
        _ci = self.client_combo.findData(default_client)
        if _ci >= 0:
            self.client_combo.setCurrentIndex(_ci)
        mform.addRow("Client (branding):", self.client_combo)

        # count-tables editor — only relevant to models that use them (commercial)
        self.counts_btn = QPushButton("Edit count tables…")
        self.counts_btn.clicked.connect(self._edit_counts)
        mform.addRow("Count tables:", self.counts_btn)
        root.addLayout(mform)
        self.model_combo.currentIndexChanged.connect(self._on_model_changed)

        # ── ③ TITLE BLOCK (per-project; auto-filled, editable, remembered) ──
        root.addWidget(_section("③ TITLE BLOCK"))
        form = QFormLayout()
        self.title_edit = QLineEdit(meta.get("title", ""))
        form.addRow("Project title:", self.title_edit)
        self.designer_edit = QLineEdit(meta.get("designer", ""))
        form.addRow("Designer:", self.designer_edit)
        self.company_edit = QLineEdit(meta.get("company", "Velocity Fibre"))
        form.addRow("Company:", self.company_edit)
        self.revision_edit = QLineEdit(str(meta.get("revision", "1")))
        form.addRow("Revision:", self.revision_edit)
        root.addLayout(form)

        # ── ④ OUTPUT ──
        root.addWidget(_section("④ OUTPUT"))
        form2 = QFormLayout()
        self.dir_edit = QLineEdit(default_dir)
        browse = QPushButton("Browse…"); browse.clicked.connect(self._pick_dir)
        row = QHBoxLayout(); row.addWidget(self.dir_edit); row.addWidget(browse)
        rw = QWidget(); rw.setLayout(row)
        form2.addRow("Output folder:", rw)
        self.name_edit = QLineEdit(f"{self._title} HLD")
        form2.addRow("File name:", self.name_edit)
        self.dpi_spin = QSpinBox(); self.dpi_spin.setRange(72, 400); self.dpi_spin.setValue(150)
        form2.addRow("Resolution (DPI):", self.dpi_spin)
        self.compress_chk = QCheckBox("Also make a smaller emailable copy  (… (email).pdf)")
        self.compress_chk.setChecked(True)
        form2.addRow("", self.compress_chk)
        self.editable_chk = QCheckBox("Also save an editable “… HLD.qgz” copy")
        self.editable_chk.setChecked(True)
        form2.addRow("", self.editable_chk)
        root.addLayout(form2)

        # keep the file name following the title until the user edits it themselves
        self._name_touched = False
        self.name_edit.textEdited.connect(lambda *_: setattr(self, "_name_touched", True))
        self.title_edit.textChanged.connect(self._sync_name)
        self._on_model_changed()      # set counts-button state for the initial model
        self._on_coverage_changed()   # grid controls + preview for the initial coverage

        # buttons
        btns = QHBoxLayout(); btns.addStretch(1)
        cancel = QPushButton("Cancel"); cancel.clicked.connect(self.reject)
        self.layout_btn = QPushButton("Open in Print Layout")
        self.layout_btn.setToolTip(
            "Build the map-book layouts in THIS project's Print Layout so you can tweak "
            "them by hand and export the PDF yourself. Nothing is saved until you save.")
        self.layout_btn.clicked.connect(self._accept_layout)
        self.gen_btn = QPushButton("Generate PDF"); self.gen_btn.setDefault(True)
        self.gen_btn.clicked.connect(self.accept)
        btns.addWidget(cancel); btns.addWidget(self.layout_btn); btns.addWidget(self.gen_btn)
        root.addLayout(btns)

    def _accept_layout(self):
        self._mode = "layout"
        self.accept()

    def _is_commercial(self):
        return self.model_combo.currentData() == "commercial_grid"

    def _on_model_changed(self, *_):
        # count tables only apply to the commercial model; coverage picker is HLD-centric
        comm = self._is_commercial()
        self.counts_btn.setEnabled(comm)
        self.counts_btn.setText("Edit count tables…" if comm
                                else "Edit count tables…  (commercial model only)")

    def _edit_counts(self):
        dlg = CountsDialog(self, self._count_tables)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self._count_tables = dlg.result_tables()

    def _sync_name(self, txt):
        if not self._name_touched:
            self.name_edit.setText(f"{txt.strip()} HLD" if txt.strip() else "HLD")

    def _is_grid(self):
        return self.cov_combo.currentData() == GRID_COV

    def _on_coverage_changed(self, *_):
        """Show the fixed grid-size readout only for the grid option; update the preview."""
        grid = self._is_grid()
        self.grid_size_lbl.setVisible(grid)
        if grid:
            self.cov_preview.setText(
                f"→ the AOI is tiled into fixed {LOCKED_GRID_W_M:.0f} × {LOCKED_GRID_H_M:.0f} m "
                "pages; one page per grid cell.")
            return
        # a real polygon layer: describe the per-page unit
        lyr = self._cov_by_name.get(self.cov_combo.currentData())
        if lyr is None:
            self.cov_preview.setText("")
            return
        try:
            from .presets import coverage_descriptor
            unit, id_field, _sort = coverage_descriptor(lyr)
            n = lyr.featureCount()
            self.cov_preview.setText(f"→ {n} pages: one per {unit}  (heading “{unit} …”, by {id_field})")
        except Exception:
            self.cov_preview.setText("")

    def _draw_box_clicked(self):
        """Close the dialog with DRAW_CODE so the caller can run the canvas box tool
        (a modal dialog can't hand mouse events to the canvas)."""
        self.done(self.DRAW_CODE)

    def _pick_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Output folder", self.dir_edit.text() or self._dir)
        if d:
            self.dir_edit.setText(d)

    def values(self):
        name = (self.name_edit.text() or f"{self._title} HLD").strip()
        if name.lower().endswith(".pdf"):
            name = name[:-4]
        grid = self._is_grid()
        cov = "" if grid else (self.cov_combo.currentData() or "")
        return {
            "dir": self.dir_edit.text().strip() or self._dir,
            "name": name,
            "dpi": self.dpi_spin.value(),
            "compress": self.compress_chk.isChecked(),
            "editable": self.editable_chk.isChecked(),
            "title": self.title_edit.text().strip(),
            "designer": self.designer_edit.text().strip(),
            "company": self.company_edit.text().strip(),
            "revision": self.revision_edit.text().strip() or "1",
            "coverage": cov,
            "grid": grid,
            # grid tile size is LOCKED — always the standard plotting grid (no operator draw)
            "cell_w_m": LOCKED_GRID_W_M,
            "cell_h_m": LOCKED_GRID_H_M,
            "model": self.model_combo.currentData(),
            "client": self.client_combo.currentData(),
            "count_tables": self._count_tables,
            "mode": self._mode,
        }


DEFAULT_COUNT_TABLES = [
    {"title": "Commercial HP Counts", "headers": ["Zoning", "Informal", "Formal", "Total HPs"],
     "rows": [["Residential", "", "", ""], ["Business", "", "", ""], ["Special", "", "", ""],
              ["Industrial", "", "", ""], ["MDU", "", "", ""], ["Grand Total", "", "", ""]]},
    {"title": "Commercial Erf Counts", "headers": ["Zoning", "Informal", "Formal", "Total Erf"],
     "rows": [["Residential", "", "", ""], ["Business", "", "", ""], ["Special", "", "", ""],
              ["Industrial", "", "", ""], ["MDU", "", "", ""], ["Grand Total", "", "", ""]]},
]


class CountsDialog(QDialog):
    """Manual count-table entry (HP + Erf), saved with the project. No numbers are
    computed/guessed — these are exactly what you type."""
    def __init__(self, parent, tables):
        super().__init__(parent)
        from qgis.PyQt.QtWidgets import QTableWidget, QTableWidgetItem
        self.setWindowTitle("Commercial count tables")
        self.setMinimumWidth(460)
        c = _theme()
        root = QVBoxLayout(self)
        hint = QLabel("Type the counts exactly as they should appear. Saved with the project "
                      "and reused each render. Leave blank to omit a cell.")
        hint.setWordWrap(True)
        if c["ink"]:
            hint.setStyleSheet(f"color:{c['ink']};")
        root.addWidget(hint)
        self._widgets = []
        src = tables if tables else DEFAULT_COUNT_TABLES
        for t in src:
            root.addWidget(_section(t.get("title", "")))
            headers = t.get("headers", ["Zoning", "Informal", "Formal", "Total"])
            rows = t.get("rows", [])
            tw = QTableWidget(len(rows), len(headers))
            tw.setHorizontalHeaderLabels(headers)
            for r, row in enumerate(rows):
                for col in range(len(headers)):
                    val = row[col] if col < len(row) else ""
                    tw.setItem(r, col, QTableWidgetItem(str(val)))
            tw.resizeColumnsToContents()
            root.addWidget(tw)
            self._widgets.append((t.get("title", ""), headers, tw))
        btns = QHBoxLayout(); btns.addStretch(1)
        cancel = QPushButton("Cancel"); cancel.clicked.connect(self.reject)
        ok = QPushButton("Save"); ok.setDefault(True); ok.clicked.connect(self.accept)
        btns.addWidget(cancel); btns.addWidget(ok)
        root.addLayout(btns)

    def result_tables(self):
        out = []
        for title, headers, tw in self._widgets:
            rows = []
            for r in range(tw.rowCount()):
                row = []
                for col in range(tw.columnCount()):
                    it = tw.item(r, col)
                    row.append(it.text().strip() if it else "")
                if any(row):
                    rows.append(row)
            out.append({"title": title, "headers": headers, "rows": rows})
        return out


def _theme():
    """Readable colours for the CURRENT QGIS theme (light/dark/custom)."""
    try:
        try:
            from .. import theme_safe
        except ImportError:
            import theme_safe
        return theme_safe.colors()
    except Exception:
        # never let a colour helper break the dialog — fall back to palette default
        return {"ink": "", "muted": "", "accent": "", "warn": "", "ok": "", "bad": ""}


def _section(text):
    c = _theme()
    lbl = QLabel(f"// {text}")
    css = "font-weight:bold;font-size:11px;margin-top:6px;"
    if c["accent"]:
        css = f"color:{c['accent']};" + css
    lbl.setStyleSheet(css)
    return lbl


def _ensure_saved_for_headless(mw, proj):
    """The headless render reads the SAVED .qgz, so it must exist + be current.
    (The 'Open in Print Layout' path uses the live in-memory project instead, so it
    does NOT need this — unsaved edits are exactly what you want to see there.)"""
    project_path = proj.fileName()
    if not project_path or not os.path.exists(project_path):
        QMessageBox.warning(mw, "Save project first",
                            "Please save your QGIS project (.qgz) first — the PDF is rendered "
                            "from the saved project in a separate process.\n\n"
                            "(Or use “Open in Print Layout”, which works on the live project.)")
        return None
    if proj.isDirty():
        r = QMessageBox.question(
            mw, "Unsaved changes",
            "The project has unsaved changes. The PDF is rendered from the SAVED file, so recent "
            "edits won't appear.\n\nSave now and continue?",
            QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Cancel)
        if r == QMessageBox.StandardButton.Cancel:
            return None
        if not proj.write():
            QMessageBox.critical(mw, "Save failed", "Could not save the project. Aborting.")
            return None
    return project_path


def open_hld_pdf_dialog(iface):
    """Entry point wired to the Nexus menu. Collects settings then either launches the
    background render (Generate PDF) or builds the layouts in the live Print Layout."""
    mw = iface.mainWindow()
    proj = QgsProject.instance()
    project_path = proj.fileName() or ""

    # inspect the OPEN project so the dialog auto-fills for ANY project
    from . import presets
    from .presets import (build_config, find_python_qgis, polygon_layers,
                          best_coverage_layer, coverage_descriptor,
                          load_project_meta, save_project_meta, derive_hld_cfg,
                          derive_aoi_cfg, list_models, list_clients, load_model,
                          load_client, deep_merge)
    import json
    from qgis.core import QgsSettings
    cov_layers = polygon_layers(proj)
    cov_names = [l.name() for l in cov_layers]
    best_cov = best_coverage_layer(proj)
    default_cov = best_cov.name() if best_cov else ""
    meta = load_project_meta(project_path)

    # persisted model/client/counts for this project
    s = QgsSettings()
    mkey = presets._meta_key(project_path)
    def_model = s.value(f"{mkey}/model", "hld_atlas")
    def_client = s.value(f"{mkey}/client", "fibertime")
    try:
        saved_counts = json.loads(s.value(f"{mkey}/counts", "") or "[]")
    except Exception:
        saved_counts = []

    # remembered coverage choice (grid vs a layer) + the last grid page size
    def_cov = s.value(f"{mkey}/coverage", default_cov)
    try:
        cell_w = float(s.value(f"{mkey}/cell_w_m", 0) or 0)
        cell_h = float(s.value(f"{mkey}/cell_h_m", 0) or 0)
    except Exception:
        cell_w = cell_h = 0.0

    # Loop so "📐 Draw map size" can close the dialog, let the operator drag a box on the
    # canvas (a modal dialog can't), then re-open with the captured size pre-filled.
    while True:
        dlg = HldPdfDialog(mw, _downloads(), meta, cov_names, def_cov, cov_layers,
                           models=list_models(), default_model=def_model,
                           clients=list_clients(), default_client=def_client,
                           count_tables=saved_counts, iface=iface,
                           cell_w_m=cell_w, cell_h_m=cell_h)
        code = dlg.exec()
        # preserve whatever the operator typed, so re-opening doesn't lose edits
        meta = {"title": dlg.title_edit.text(), "designer": dlg.designer_edit.text(),
                "company": dlg.company_edit.text(), "revision": dlg.revision_edit.text()}
        def_model = dlg.model_combo.currentData()
        def_client = dlg.client_combo.currentData()
        saved_counts = dlg._count_tables
        def_cov = "__grid__" if dlg._is_grid() else (dlg.cov_combo.currentData() or default_cov)
        if code == HldPdfDialog.DRAW_CODE:
            try:
                from .box_tool import draw_box
                size = draw_box(iface)
            except Exception as e:
                QMessageBox.warning(mw, "Draw map size", f"Could not draw on the canvas:\n{e}")
                size = None
            if size:
                cell_w, cell_h = size
            continue
        if code != QDialog.DialogCode.Accepted:
            return
        break
    v = dlg.values()

    if v.get("grid") and (v["cell_w_m"] <= 0 or v["cell_h_m"] <= 0):
        QMessageBox.warning(mw, "Draw the map size first",
                            "For a grid book, click “📐 Draw map size on the canvas” and drag a "
                            "box on the map so I know how big each page should be.")
        return

    # remember for next time (title block + model/client/counts)
    save_project_meta(project_path, {"title": v["title"], "designer": v["designer"],
                                     "company": v["company"], "revision": v["revision"]})
    s.setValue(f"{mkey}/model", v["model"])
    s.setValue(f"{mkey}/client", v["client"])
    s.setValue(f"{mkey}/counts", json.dumps(v["count_tables"]))
    s.setValue(f"{mkey}/coverage", "__grid__" if v.get("grid") else v["coverage"])
    if v.get("grid"):
        s.setValue(f"{mkey}/cell_w_m", v["cell_w_m"])
        s.setValue(f"{mkey}/cell_h_m", v["cell_h_m"])

    # ── compose HLD_CFG: client branding < model structure < project text (project wins) ──
    model = load_model(v["model"]) or {"hld_cfg": {}}
    client = load_client(v["client"]) or {"hld_cfg": {}}
    hld_cfg = deep_merge(client["hld_cfg"], model["hld_cfg"])   # model structure wins over client
    brand = {}
    if v["title"]:
        brand["project_name"] = v["title"]
        # per-project layout names so a Malmesbury book isn't labelled "MOA PH2 …"
        brand["layout_overview"] = f"{v['title']} HLD Overview"
        brand["layout_atlas"] = f"{v['title']} HLD Atlas"
        brand["layout_report"] = f"{v['title']} HLD Book"
    if v["designer"]:
        brand["designer"] = v["designer"]
    if v["company"]:
        brand["company"] = v["company"]
    if v["revision"]:
        brand["revision"] = str(v["revision"])
    import datetime as _dt
    brand["date_str"] = _dt.date.today().strftime("%d-%m-%Y")
    hld_cfg = deep_merge(hld_cfg, brand)

    # frame the atlas to THIS project's own AOI/boundary (not a hardcoded Mohadin one)
    hld_cfg = deep_merge(hld_cfg, derive_aoi_cfg(proj))

    if v["model"] == "commercial_grid":
        hld_cfg["count_tables"] = v["count_tables"]
    elif v.get("grid"):
        # GRID book: engine auto-tiles the AOI at the drawn page size (coverage = grid).
        hld_cfg["grid_cell_w_m"] = float(v["cell_w_m"])
        hld_cfg["grid_cell_h_m"] = float(v["cell_h_m"])
    else:
        # per-layer HLD: coverage + per-page heading come from the dropdown + title
        cov_layer = next((l for l in cov_layers if l.name() == v["coverage"]), None)
        descriptor = coverage_descriptor(cov_layer) if cov_layer else None
        cov_cfg = derive_hld_cfg(v["title"], "", "", "", v["coverage"], descriptor)
        hld_cfg = deep_merge(hld_cfg, cov_cfg)

    # ── "Open in Print Layout": build in the LIVE project, hand off to the designer ──
    if v.get("mode") == "layout":
        from .presets import default_extra_layers
        from .live_build import build_in_project
        try:
            ok, msg, _ov, _at = build_in_project(iface, hld_cfg, default_extra_layers())
        except Exception as e:
            ok, msg = False, f"Unexpected error: {e}"
        if ok:
            # the atlas already opened on top — just a brief, non-blocking note (no popup)
            iface.messageBar().pushSuccess(
                "HLD Atlas", msg + "  Page 1 = overview; flip ▶ with the Atlas Toolbar arrows.")
        else:
            QMessageBox.critical(mw, "HLD — Print Layout failed", msg)
        return

    # ── "Generate PDF" (headless): renders from the SAVED project in a separate process ──
    project_path = _ensure_saved_for_headless(mw, proj)
    if not project_path:
        return

    out_dir = v["dir"]
    try:
        os.makedirs(out_dir, exist_ok=True)
    except Exception as e:
        QMessageBox.critical(mw, "Bad folder", f"Cannot use that output folder:\n{e}")
        return

    out_pdf = os.path.join(out_dir, v["name"] + ".pdf")
    out_project = os.path.join(out_dir, v["name"] + ".qgz") if v["editable"] else None
    work = os.path.join(out_dir, "_hld_work")
    os.makedirs(work, exist_ok=True)
    cfg_path = os.path.join(work, "config.json")
    result_path = os.path.join(work, "result.json")
    tmp = os.path.join(work, "_tmp")

    if not find_python_qgis():
        QMessageBox.critical(mw, "QGIS launcher missing",
                             "Could not find python-qgis.bat next to your QGIS install — cannot "
                             "start the background render.")
        return

    import json
    cfg = build_config(project_path, out_pdf, out_project, v["dpi"], v["compress"],
                       tmp, result_path, hld_cfg=hld_cfg)
    with open(cfg_path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
    # clear any stale result so we never read a previous run's outcome
    try:
        if os.path.exists(result_path):
            os.remove(result_path)
    except Exception:
        pass

    bar = iface.messageBar()
    bar.pushInfo("HLD PDF", "Generating in the background — QGIS stays usable. This takes a few minutes…")

    def on_done(result, error):
        if result and result.get("ok"):
            pages = result.get("pages", "?")
            size = result.get("size_mb", "?")
            the_pdf = result.get("output") or out_pdf
            # AUTO-OPEN the finished PDF (no popup to click through), + a brief note in the bar
            try:
                if os.path.exists(the_pdf):
                    os.startfile(the_pdf)  # noqa: S606 - open the exact PDF just written
            except Exception:
                pass
            b = iface.messageBar()
            try:
                from qgis.core import Qgis
                from qgis.PyQt.QtWidgets import QPushButton
                widget = b.createMessage("HLD PDF",
                                         f"✅ {pages} pages · {size} MB — opened.  {the_pdf}")
                btn = QPushButton("Open folder")
                btn.clicked.connect(lambda: os.startfile(out_dir))  # noqa: S606
                widget.layout().addWidget(btn)
                b.pushWidget(widget, Qgis.MessageLevel.Success, 10)
            except Exception:
                b.pushSuccess("HLD PDF", f"✅ {pages} pages · {size} MB — opened.  {the_pdf}")
        else:
            detail = (result or {}).get("message") or error or "unknown error"
            stage = (result or {}).get("stage", "?")
            QMessageBox.critical(mw, "HLD PDF — Failed",
                                 f"Could not generate the PDF.\n\nStage: {stage}\n{detail}\n\n"
                                 f"Log/config: {work}")

    from .runner import HldGenerateTask
    task = HldGenerateTask(cfg_path, result_path, on_done, timeout=1800)
    # keep a reference so the task isn't garbage-collected mid-run
    global _ACTIVE_TASK
    _ACTIVE_TASK = task
    QgsApplication.taskManager().addTask(task)


_ACTIVE_TASK = None
