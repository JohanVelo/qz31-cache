"""Read-only HeroTel quantities and traceable, scoped workbook exports."""

CONTRACT_VERSION = 1
