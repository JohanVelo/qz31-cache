"""kmz_export — turn the designed network into a KMZ for Google Earth / field phones.

ZERO external dependencies: KML is plain XML, KMZ is a zip, and everything else is
PyQGIS core (coordinate transform to WGS84). So it ships in the team plugin and runs
inside QGIS's bundled Python — no duckdb/simplekml/geopandas needed.

Read-only on the project: it never edits a layer. Exports the vector layers it is handed
(the caller decides which — the Export KMZ button asks via a layer picker), each as a KML
Folder with a sensible colour by name, point/line/polygon Placemarks, and the feature's
label as the Placemark name so a field tech can tap a pole/home and read its number.

Every attribute-table field rides along in each Placemark's <ExtendedData>, so tapping a
feature in Google Earth shows its full row — not just the label. The formatting is
kml_export's _extended_data/_fmt, reused deliberately so the two exporters can't drift.

API:  build_kmz(layers, out_path, feedback=None, include_attributes=True)
      -> {"layers":n, "features":n, "path":..}
"""
import os
import zipfile
from xml.sax.saxutils import escape

from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform,
                       QgsProject, QgsGeometry, QgsWkbTypes)

# RGB by name keyword (first match wins). KML wants aabbggrr, converted below.
_PALETTE = [
    (("ont", "home"),                 "FFE100"),   # homes — yellow
    (("pole",),                       "FF8C00"),   # poles — orange
    (("fts",),                        "FF2D55"),   # FTS splitter — red
    (("sts",),                        "FF2DD4"),   # STS splitter — magenta
    (("splitter", "enclosure"),       "2DD4FF"),   # other splitters/domes — cyan
    (("drop",),                       "3DFF9A"),   # drop cable — green
    (("distribution",),               "2D7DFF"),   # distribution — blue
    (("secondary",),                  "9A4DFF"),   # secondary — purple
    (("primary", "feeder", "trunk"),  "FF4D2D"),   # primary/feeder — red-orange
    (("span", "cable"),               "7DC8FF"),   # generic cable — light blue
    (("pon",),                        "2DD4BF"),   # PON polygons — teal
    (("zone",),                       "FFD24D"),   # zones — amber
    (("erf", "erven", "stand"),       "B0B8C4"),   # erven — grey
    (("aoi", "boundary"),             "FF3B30"),   # AOI — red
]
_DEFAULT_RGB = "F2F7FF"          # off-white for anything unmatched


def _rgb_for(layer_name):
    nl = (layer_name or "").lower()
    for keys, rgb in _PALETTE:
        if any(k in nl for k in keys):
            return rgb
    return _DEFAULT_RGB


def _symbol_style(layer):
    """Pull (rgb_hex, line_width_px_or_None) from the layer's LIVE renderer symbol,
    so whatever styling the user sets in QGIS carries into the KMZ. Falls back to the
    by-name palette + default width if the renderer can't be read (e.g. rule-based)."""
    try:
        from qgis.core import QgsRenderContext
        r = layer.renderer()
        sym = None
        if r is not None and hasattr(r, "symbol") and r.symbol() is not None:
            sym = r.symbol()                      # single-symbol renderer
        elif r is not None and hasattr(r, "symbols"):
            syms = r.symbols(QgsRenderContext())  # categorized/graduated -> first symbol
            sym = syms[0] if syms else None
        if sym is not None:
            c = sym.color()
            rgb = f"{c.red():02X}{c.green():02X}{c.blue():02X}"
            width = None
            try:
                w = sym.width()                    # QgsLineSymbol width (mm)
                if w and w > 0:
                    width = max(1.0, round(w * 3.0, 1))
            except Exception:
                pass
            return rgb, width
    except Exception:
        pass
    return _rgb_for(layer.name()), None


def _kml_colour(rgb, alpha="ff"):
    """RRGGBB (web) -> aabbggrr (KML's byte order)."""
    rgb = rgb.lstrip("#")
    rr, gg, bb = rgb[0:2], rgb[2:4], rgb[4:6]
    return f"{alpha}{bb}{gg}{rr}".lower()


def _import_sibling(attr):
    """Fetch `attr` from the sibling kml_export module, or None if unavailable.

    kmz_export deliberately owns no copy of the label/attribute logic — one source
    of truth means the two exporters cannot drift and label the same pole
    differently. Three spellings because the module is reached three ways:
    as a package member (normal), via the root fibre_automation package, or flat
    with its own directory on sys.path.
    """
    for how in ("relative", "packaged", "flat"):
        try:
            if how == "relative":
                from . import kml_export as _k
            elif how == "packaged":
                from fibre_automation import kml_export as _k
            else:
                import kml_export as _k
            return getattr(_k, attr, None)
        except ImportError:
            continue
    return None


def _name_field(layer):
    """The field to use as the Placemark <name>, or None.

    Delegates to kml_export._name_field so both exporters label features
    identically — a pole is "MMB_0001PL" in the KML and the KMZ, never "1" in one
    and "MMB_0001PL" in the other.
    """
    _shared = _import_sibling("_name_field")
    if _shared is None:
        return None                 # broken install: no labels rather than a crash
    try:
        return _shared(layer)
    except Exception:
        return None                 # labelling is cosmetic; never kill an export


def _label_text(value):
    """Placemark <name> text for an attribute value, or "" to emit no name at all.

    QGIS NULL is a QVariant, not None, so `value not in (None, "")` lets it through
    and str() renders the literal word "NULL" — e.g. 'DC & BH', whose id is null,
    would be labelled "NULL" in Google Earth. Treat NULL/None/blank as no-name.
    """
    if value is None:
        return ""
    try:
        from qgis.core import NULL
        if value == NULL:
            return ""
    except Exception:
        pass
    try:
        if hasattr(value, "isNull") and value.isNull():
            return ""
    except Exception:
        pass
    s = str(value).strip()
    return "" if s.upper() in ("", "NULL", "NONE") else s


def _coords(pts):
    """list[QgsPointXY] -> KML 'lon,lat,0 lon,lat,0 ...' (KML is lon,lat order)."""
    return " ".join(f"{p.x():.7f},{p.y():.7f},0" for p in pts)


def _placemarks(geom, gtype, style_id, label, ext=""):
    """Yield Placemark XML strings for one (already WGS84) geometry.

    ext: pre-rendered <ExtendedData> for the owning feature, or "". It lives in `head`,
    so a multipart feature gets its attributes on EVERY part, not just the first.
    Order is <name><styleUrl><ExtendedData><geometry> — KML 2.2 requires ExtendedData
    before the geometry (same order kml_export.py uses).
    """
    nm = f"<name>{escape(label)}</name>" if label else ""
    head = f'<Placemark>{nm}<styleUrl>#{style_id}</styleUrl>{ext}'
    if gtype == QgsWkbTypes.GeometryType.PointGeometry:
        pts = geom.asMultiPoint() if geom.isMultipart() else [geom.asPoint()]
        for p in pts:
            yield f'{head}<Point><coordinates>{p.x():.7f},{p.y():.7f},0</coordinates></Point></Placemark>'
    elif gtype == QgsWkbTypes.GeometryType.LineGeometry:
        lines = geom.asMultiPolyline() if geom.isMultipart() else [geom.asPolyline()]
        for ln in lines:
            if len(ln) >= 2:
                yield (f'{head}<LineString><tessellate>1</tessellate>'
                       f'<coordinates>{_coords(ln)}</coordinates></LineString></Placemark>')
    elif gtype == QgsWkbTypes.GeometryType.PolygonGeometry:
        polys = geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]
        for poly in polys:
            if not poly:
                continue
            rings = [f'<outerBoundaryIs><LinearRing><coordinates>{_coords(poly[0])}'
                     f'</coordinates></LinearRing></outerBoundaryIs>']
            for hole in poly[1:]:
                rings.append(f'<innerBoundaryIs><LinearRing><coordinates>{_coords(hole)}'
                             f'</coordinates></LinearRing></innerBoundaryIs>')
            yield f'{head}<Polygon>{"".join(rings)}</Polygon></Placemark>'


def _cat_value_getter(layer, class_attribute):
    """-> f(feature) giving the value a categorized renderer classifies on.

    QGIS lets you categorize by a FIELD NAME *or* by an EXPRESSION. Malmesbury's
    poles layer uses an expression:  "Pole Lengh" || ' ' || "Pole Size"
    Feeding that to feature[...] raises KeyError, which used to abort the whole
    export (the 'Export failed: "Pole Lengh" || \\ \\ || "Pole Size"' warning).
    So: use the field fast-path when it IS a field, else evaluate the expression
    the way QGIS itself does.

    Never raises — styling is cosmetic and must not be able to kill an export.
    On any failure the caller falls back to the layer's default style.
    """
    if not class_attribute:
        return None
    names = {f.name() for f in layer.fields()}
    if class_attribute in names:                 # plain field — cheap path
        def _by_field(ft):
            try:
                return ft[class_attribute]
            except Exception:
                return None
        return _by_field
    try:
        from qgis.core import (QgsExpression, QgsExpressionContext,
                               QgsExpressionContextUtils)
        expr = QgsExpression(class_attribute)
        if expr.hasParserError():
            return None
        ctx = QgsExpressionContext()
        ctx.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
        expr.prepare(ctx)
    except Exception:
        return None

    def _by_expr(ft):
        try:
            ctx.setFeature(ft)
            val = expr.evaluate(ctx)
            return None if expr.hasEvalError() else val
        except Exception:
            return None
    return _by_expr


def _attr_renderer(include_attributes):
    """-> f(field_names, feature) producing <ExtendedData>, or None if not wanted.

    Reuses kml_export's _extended_data rather than growing a second implementation:
    it already handles NULL/bool/float formatting and escapes quotes in field names,
    and one source of truth means the two exporters can't drift apart.
    Raises if the sibling is missing — a broken install must fail loudly, not quietly
    ship a KMZ with every attribute silently dropped.
    """
    if not include_attributes:
        return None
    fn = _import_sibling("_extended_data")
    if fn is None:
        raise ImportError(
            "kmz_export needs its sibling kml_export for attribute export; "
            "the plugin's fibre_automation package looks incomplete.")
    return fn


def build_kmz(layers, out_path, feedback=None, max_features=300000,
              include_attributes=True):
    """Write a KMZ of the given vector layers to out_path. Returns a summary dict.

    feedback: optional object with .setProgress(0-100)/.pushInfo(str) (QgsProcessingFeedback
    or a shim) — best-effort, all calls guarded.
    include_attributes: carry every attribute-table field into each Placemark's
    <ExtendedData>, so tapping a feature in Google Earth shows its full row.
    """
    wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
    ext_fn = _attr_renderer(include_attributes)
    styles, folders = [], []
    total_feats = 0
    layers = [l for l in layers if l is not None]

    for li, layer in enumerate(layers):
        try:
            if layer.type() != layer.type().__class__.VectorLayer:  # vector only
                continue
        except Exception:
            pass
        gtype = layer.geometryType()
        if gtype not in (QgsWkbTypes.GeometryType.PointGeometry,
                         QgsWkbTypes.GeometryType.LineGeometry,
                         QgsWkbTypes.GeometryType.PolygonGeometry):
            continue
        rgb, sym_width = _symbol_style(layer)   # live QGIS styling -> KMZ
        line_w = sym_width if sym_width else 2.4
        def _mk_style(sid_, rgb_, width_):
            if gtype == QgsWkbTypes.GeometryType.PointGeometry:
                return (f'<Style id="{sid_}"><IconStyle><color>{_kml_colour(rgb_)}</color>'
                        f'<scale>0.9</scale><Icon><href>http://maps.google.com/mapfiles/kml/'
                        f'shapes/placemark_circle.png</href></Icon></IconStyle>'
                        f'<LabelStyle><scale>0.7</scale></LabelStyle></Style>')
            if gtype == QgsWkbTypes.GeometryType.LineGeometry:
                return (f'<Style id="{sid_}"><LineStyle><color>{_kml_colour(rgb_)}</color>'
                        f'<width>{width_ or line_w}</width></LineStyle></Style>')
            return (f'<Style id="{sid_}"><LineStyle><color>{_kml_colour(rgb_)}</color>'
                    f'<width>1.6</width></LineStyle><PolyStyle>'
                    f'<color>{_kml_colour(rgb_, "44")}</color></PolyStyle></Style>')

        # Categorized renderers -> one KML style per category (matches QGIS exactly,
        # e.g. poles 5m vs 7m in different colours); everything else -> single style.
        cat_value, style_map, default_sid = None, {}, f"s{li}"
        try:
            from qgis.core import QgsCategorizedSymbolRenderer
            rnd = layer.renderer()
            if isinstance(rnd, QgsCategorizedSymbolRenderer):
                cat_value = _cat_value_getter(layer, rnd.classAttribute())
                for ci, cat in enumerate(rnd.categories()):
                    sym = cat.symbol()
                    col = sym.color() if sym else None
                    crgb = f"{col.red():02X}{col.green():02X}{col.blue():02X}" if col else rgb
                    cw = None
                    try:
                        w = sym.width()
                        if w and w > 0:
                            cw = max(1.0, round(w * 3.0, 1))
                    except Exception:
                        pass
                    csid = f"s{li}_{ci}"
                    styles.append(_mk_style(csid, crgb, cw))
                    style_map[str(cat.value())] = csid
                if style_map:
                    default_sid = next(iter(style_map.values()))
        except Exception:
            cat_value, style_map = None, {}
        if not style_map:
            styles.append(_mk_style(default_sid, rgb, sym_width))

        nf = _name_field(layer)
        field_names = [f.name() for f in layer.fields()] if ext_fn else []
        xform = QgsCoordinateTransform(layer.crs(), wgs84, QgsProject.instance())
        marks, n = [], 0
        for ft in layer.getFeatures():
            if total_feats + n >= max_features:
                break
            g = ft.geometry()
            if not g or g.isEmpty():
                continue
            gg = QgsGeometry(g)
            try:
                if gg.transform(xform) != 0:
                    continue
            except Exception:
                continue
            style_id = default_sid
            if cat_value is not None:
                style_id = style_map.get(str(cat_value(ft)), default_sid)
            label = _label_text(ft[nf]) if nf else ""
            ext = ext_fn(field_names, ft) if ext_fn else ""
            for pm in _placemarks(gg, gtype, style_id, label, ext):
                marks.append(pm)
            n += 1
        total_feats += n
        folders.append(f'<Folder><name>{escape(layer.name())}</name>'
                       f'<open>0</open>{"".join(marks)}</Folder>')
        if feedback is not None:
            try:
                feedback.setProgress(int((li + 1) / max(len(layers), 1) * 100))
                feedback.pushInfo(f"{layer.name()}: {n} features")
            except Exception:
                pass

    doc = (f'<?xml version="1.0" encoding="UTF-8"?>'
           f'<kml xmlns="http://www.opengis.net/kml/2.2"><Document>'
           f'<name>{escape(os.path.splitext(os.path.basename(out_path))[0])}</name>'
           f'{"".join(styles)}{"".join(folders)}</Document></kml>')

    if not out_path.lower().endswith(".kmz"):
        out_path += ".kmz"
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("doc.kml", doc)
    return {"layers": len(folders), "features": total_feats, "path": out_path}
