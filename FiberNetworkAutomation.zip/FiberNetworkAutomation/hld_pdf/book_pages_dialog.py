# -*- coding: utf-8 -*-
"""HLD Book (custom pages) — the page editor, the Print Layout "Book Pages" toolbar, the
frame guard and the book export.

Everything here is reachable only while the model switch (vf/hld/book_pages_model) is on;
BookPagesHook.install() returns before connecting anything when it is off.
"""
import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem,
                                 QPushButton, QLabel, QLineEdit, QTreeWidget, QTreeWidgetItem,
                                 QDialogButtonBox, QMessageBox, QInputDialog, QToolBar, QToolButton,
                                 QMenu, QSplitter, QWidget, QFormLayout, QHeaderView)

from . import book_pages as BP

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

TOOLBAR_NAME = "vfBookPagesToolbar"


# ── switches ───────────────────────────────────────────────────────────────────────────
def _setting_on(key, default):
    try:
        from qgis.core import QgsSettings
        v = QgsSettings().value(key, default)
        return str(v).lower() not in ("false", "0", "off", "no")
    except Exception:
        return bool(default)


def qgis_ok():
    try:
        from qgis.core import Qgis
        return int(Qgis.versionInt()) >= BP.MIN_QGIS_INT
    except Exception:
        return False


def _default_on():
    """The release default for the master switch: models/hld_book_pages.json
    "enabled_by_default" (data, so a release can switch it without a code change), else
    book_pages.MODEL_DEFAULT_ON."""
    try:
        import json
        fp = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", BP.MODEL_ID + ".json")
        with open(fp, encoding="utf-8") as f:
            v = json.load(f).get("enabled_by_default")
        if isinstance(v, bool):
            return v
    except Exception:
        _swallowed_note()
    return BP.MODEL_DEFAULT_ON


def model_enabled():
    """Master switch: the model shows, and the hook installs, only when this is on AND the
    QGIS version is one the feature was measured on (4.2+). A QSettings value set on this
    machine (vf/hld/book_pages_model) always wins over the release default."""
    if os.environ.get("VF_BOOK_PAGES_FORCE") == "1":          # test harness only
        return qgis_ok()
    return qgis_ok() and _setting_on(BP.SETTING_MODEL, _default_on())


def disabled_reason():
    """None = the model is switched off (hide it); "" = usable; text = shown greyed out with
    this reason (switch on, but this QGIS is older than the oldest version it was tested on)."""
    if os.environ.get("VF_BOOK_PAGES_FORCE") != "1" and not _setting_on(BP.SETTING_MODEL, _default_on()):
        return None
    return "" if qgis_ok() else "needs QGIS %s or newer" % BP.MIN_QGIS_TEXT


def button_enabled():
    return model_enabled() and _setting_on(BP.SETTING_BUTTON, BP.BUTTON_DEFAULT_ON)


# ── page editor ────────────────────────────────────────────────────────────────────────
class PageEditorDialog(QDialog):
    """Edit a spec: overview pages (add / remove / reorder / rename), the shared PON-page set,
    per-PON own sets; per page: which layers show, which get labels, and a note.

    The result is written into `holder["spec"]` from accept(), BEFORE the dialog closes, so
    the caller never reads a widget after exec() (WA_DeleteOnClose)."""

    ROLE_KIND = Qt.ItemDataRole.UserRole
    ROLE_IDX = Qt.ItemDataRole.UserRole + 1

    def __init__(self, parent, spec, holder, project=None, focus_override=-1):
        super().__init__(parent)
        from qgis.core import QgsProject, QgsVectorLayer
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self.setWindowTitle("HLD Book — pages")
        self.setMinimumSize(820, 560)
        self._p = project or QgsProject.instance()
        self._holder = holder
        self._spec = BP.normalise(spec)
        self._cur = None
        # layers offered: every vector layer in Layers-panel order (book layers never)
        self._layers = []
        for node in self._p.layerTreeRoot().findLayers():
            l = node.layer()
            if isinstance(l, QgsVectorLayer) and not l.customProperty(BP.PROP_BOOK_ID):
                self._layers.append((l.id(), l.name()))
        root = QVBoxLayout(self)
        tip = QLabel("Tick the layers each page draws and which of them get labels. "
                     "The aerial photo is always underneath. “All PON pages” is the shared set "
                     "every PON page uses unless that PON has its own.")
        tip.setWordWrap(True)
        root.addWidget(tip)
        split = QSplitter(Qt.Orientation.Horizontal)
        left = QWidget(); lv = QVBoxLayout(left); lv.setContentsMargins(0, 0, 0, 0)
        self.pages = QListWidget()
        lv.addWidget(self.pages)
        row = QHBoxLayout()
        for txt, fn in (("Add page", self._add), ("Remove", self._remove),
                        ("▲", lambda: self._move(-1)), ("▼", lambda: self._move(1))):
            b = QPushButton(txt); b.clicked.connect(fn); row.addWidget(b)
        lv.addLayout(row)
        split.addWidget(left)
        right = QWidget(); rv = QVBoxLayout(right); rv.setContentsMargins(0, 0, 0, 0)
        form = QFormLayout()
        self.title = QLineEdit()
        self.title.textEdited.connect(self._title_edited)
        form.addRow("Page title:", self.title)
        self.note = QLineEdit()
        self.note.setPlaceholderText("e.g. Splitter Ratio 1:16 to 1:8 — printed on this page")
        form.addRow("Note:", self.note)
        rv.addLayout(form)
        self.layers = QTreeWidget()
        self.layers.setColumnCount(3)
        self.layers.setHeaderLabels(["Layer", "Show", "Labels"])
        self.layers.setRootIsDecorated(False)
        hdr = self.layers.header()
        hdr.setStretchLastSection(False)
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for _c in (1, 2):
            hdr.setSectionResizeMode(_c, QHeaderView.ResizeMode.Fixed)
            self.layers.setColumnWidth(_c, 64)
        for lid, name in self._layers:
            it = QTreeWidgetItem([name, "", ""])
            it.setData(0, self.ROLE_KIND, lid)
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(1, Qt.CheckState.Unchecked)
            it.setCheckState(2, Qt.CheckState.Unchecked)
            self.layers.addTopLevelItem(it)
        rv.addWidget(self.layers)
        allrow = QHBoxLayout()
        b_all = QPushButton("Show all"); b_all.clicked.connect(lambda: self._tick_all(True))
        b_none = QPushButton("Show none"); b_none.clicked.connect(lambda: self._tick_all(False))
        allrow.addWidget(b_all); allrow.addWidget(b_none); allrow.addStretch(1)
        rv.addLayout(allrow)
        split.addWidget(right)
        split.setStretchFactor(1, 3)
        root.addWidget(split, 1)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        root.addWidget(bb)
        self._fill_pages()
        self.pages.currentRowChanged.connect(self._on_row)
        start = 0
        if focus_override >= 0:
            start = len(self._spec["overview"]) + 1 + focus_override
        self.pages.setCurrentRow(min(start, self.pages.count() - 1))

    # page list
    def _fill_pages(self):
        self.pages.blockSignals(True)
        self.pages.clear()
        for i, pg in enumerate(self._spec["overview"]):
            it = QListWidgetItem("%d · %s" % (i + 1, pg["title"]))
            it.setData(self.ROLE_KIND, "ov"); it.setData(self.ROLE_IDX, i)
            self.pages.addItem(it)
        it = QListWidgetItem("★ All PON pages (shared)")
        it.setData(self.ROLE_KIND, "pon"); it.setData(self.ROLE_IDX, -1)
        self.pages.addItem(it)
        for i, o in enumerate(self._spec["overrides"]):
            it = QListWidgetItem("   PON %s — own layers" % (o.get("pon") or "?"))
            it.setData(self.ROLE_KIND, "ovr"); it.setData(self.ROLE_IDX, i)
            self.pages.addItem(it)
        self.pages.blockSignals(False)

    def _page(self, row=None):
        it = self.pages.item(self.pages.currentRow() if row is None else row)
        if it is None:
            return None, None, None
        kind, idx = it.data(self.ROLE_KIND), it.data(self.ROLE_IDX)
        if kind == "ov":
            return kind, idx, self._spec["overview"][idx]
        if kind == "pon":
            return kind, idx, self._spec["pon"]
        return kind, idx, self._spec["overrides"][idx]

    def _store(self):
        """Write the right-hand panel back into the page it shows."""
        if self._cur is None:
            return
        kind, idx, pg = self._cur
        if pg is None:
            return
        ids, labels = [], []
        for i in range(self.layers.topLevelItemCount()):
            it = self.layers.topLevelItem(i)
            lid = it.data(0, self.ROLE_KIND)
            if it.checkState(1) == Qt.CheckState.Checked:
                ids.append(lid)
                if it.checkState(2) == Qt.CheckState.Checked:
                    labels.append(lid)
        # keep listed ids that are not offered here (e.g. deleted layers stay visible as a warning)
        offered = {lid for lid, _n in self._layers}
        keep = [x for x in pg.get("ids", []) if x not in offered]
        pg["ids"] = keep + ids
        pg["labels"] = labels
        pg["note"] = self.note.text()
        if kind == "ov":
            pg["title"] = self.title.text().strip() or pg["title"]

    def _on_row(self, row):
        self._store()
        kind, idx, pg = self._page(row)
        self._cur = (kind, idx, pg)
        if pg is None:
            return
        self.title.setEnabled(kind == "ov")
        self.title.setText(pg["title"] if kind == "ov" else
                           ("Every PON page" if kind == "pon" else "PON %s" % pg.get("pon")))
        self.note.setText(pg.get("note", ""))
        self.note.setPlaceholderText("printed on every PON page — e.g. Splitter Ratio 1:16 to 1:8"
                                     if kind == "pon" else
                                     "e.g. Splitter Ratio 1:16 to 1:8 — printed on this page")
        ids, labels = set(pg.get("ids", [])), set(pg.get("labels", []))
        for i in range(self.layers.topLevelItemCount()):
            it = self.layers.topLevelItem(i)
            lid = it.data(0, self.ROLE_KIND)
            it.setCheckState(1, Qt.CheckState.Checked if lid in ids else Qt.CheckState.Unchecked)
            it.setCheckState(2, Qt.CheckState.Checked if lid in labels else Qt.CheckState.Unchecked)

    def _title_edited(self, txt):
        kind, idx, _pg = self._cur or (None, None, None)
        if kind == "ov":
            it = self.pages.currentItem()
            if it is not None:
                it.setText("%d · %s" % (idx + 1, txt))

    def _tick_all(self, on):
        st = Qt.CheckState.Checked if on else Qt.CheckState.Unchecked
        for i in range(self.layers.topLevelItemCount()):
            self.layers.topLevelItem(i).setCheckState(1, st)
            if not on:
                self.layers.topLevelItem(i).setCheckState(2, st)

    def _add(self):
        self._store()
        n = len(self._spec["overview"])
        self._spec["overview"].append(BP.make_page("Page %d" % (n + 1)))
        self._cur = None
        self._fill_pages()
        self.pages.setCurrentRow(n)

    def _remove(self):
        kind, idx, _pg = self._page()
        if kind == "ov":
            self._spec["overview"].pop(idx)
        elif kind == "ovr":
            self._spec["overrides"].pop(idx)
        else:
            return
        self._cur = None
        self._fill_pages()
        self.pages.setCurrentRow(max(0, min(self.pages.count() - 1, (idx or 0))))

    def _move(self, d):
        kind, idx, _pg = self._page()
        if kind != "ov":
            return
        j = idx + d
        if not (0 <= j < len(self._spec["overview"])):
            return
        self._store()
        ov = self._spec["overview"]
        ov[idx], ov[j] = ov[j], ov[idx]
        self._cur = None
        self._fill_pages()
        self.pages.setCurrentRow(j)

    def accept(self):
        self._store()
        spec = BP.normalise(self._spec)
        from . import book_pages_qgis as BQ
        errors, warnings = BP.validate(spec, BQ.names_by_id(self._p))
        if errors:
            QMessageBox.warning(self, "HLD Book — pages", "Fix these first:\n• " + "\n• ".join(errors))
            return
        self._holder["spec"] = spec               # captured BEFORE close (WA_DeleteOnClose)
        self._holder["warnings"] = warnings
        super().accept()


def edit_spec(parent, spec, project=None, focus_override=-1):
    """Run the page editor; returns the edited spec or None if cancelled."""
    holder = {}
    dlg = PageEditorDialog(parent, spec, holder, project, focus_override)
    dlg.exec()
    return holder.get("spec")


# ── designer: toolbar, bar, export ─────────────────────────────────────────────────────
def _bar(designer, text, level="warning", secs=12):
    try:
        from qgis.core import Qgis
        lv = {"warning": Qgis.MessageLevel.Warning, "info": Qgis.MessageLevel.Info,
              "success": Qgis.MessageLevel.Success, "critical": Qgis.MessageLevel.Critical}[level]
        designer.messageBar().pushMessage("HLD Book", text, level=lv, duration=secs)
    except Exception:
        print("HLD Book:", text)


def designer_warnings(layout):
    """Quick warnings for the designer bar (no page stepping)."""
    from . import book_pages_qgis as BQ
    from qgis.core import QgsProject
    out = []
    spec = BQ.get_spec(layout)
    if spec is None:
        return ["This book's page spec is missing — rebuild it from the HLD dialog."]
    p = QgsProject.instance()
    if not BQ.is_original(layout, spec):
        out.append("This layout is a COPY of “%s”. Use Book Pages ▸ Make this copy its own book "
                   "before editing its pages." % spec.get("layout_name"))
    errors, warnings = BP.validate(spec, BQ.names_by_id(p))
    out += errors + warnings
    pon = p.mapLayer(spec.get("pon_layer_id") or "")
    um = BQ.unmatched_overrides(spec, pon)
    if um:
        out.append("%d PON override(s) no longer match a zone and are not drawn (Book Pages ▸ "
                   "Unmatched overrides)." % len(um))
    orphans = BQ.orphan_book_layers(p)
    if orphans:
        out.append("%d leftover book layer(s) from a deleted book (Book Pages ▸ Remove leftover "
                   "book layers)." % len(orphans))
    return out


def export_book(layout, parent, designer=None):
    """Our gated export: frame relock → engine QA (advisory) + book draw check (fail-closed)
    → staged PDF → page-count check → bookmarks → atomic replace (live_build)."""
    from . import book_pages_qgis as BQ
    from . import live_build as LB
    spec = BQ.get_spec(layout) or {}
    eff = {"project_name": spec.get("title") or layout.name()}

    def check(_pdf):
        _label_check(layout, spec, parent)
    LB._export_atlas_pdf(layout, parent, cov=None, eff=eff, qa=BQ.make_qa(None), designer=designer,
                         after_ok=check if BP.label_fit_on(spec) else None)


def _label_check(layout, spec, parent):
    """After a PDF export (tick on): read every page back through QGIS's PDF exporter and say what happened
    to the labels. Pumps the window between pages; Cancel stops the check, the PDF is already safe."""
    from . import book_pages_qgis as BQ
    from qgis.PyQt.QtCore import QCoreApplication, QEventLoop, Qt
    from qgis.PyQt.QtWidgets import QProgressDialog
    n = layout.atlas().count()
    bar = QProgressDialog("Checking the labels on every page...", "Cancel", 0, n, parent)
    bar.setWindowTitle("Label check")
    bar.setWindowModality(Qt.WindowModality.WindowModal)
    bar.setMinimumDuration(0)

    def tick(i):
        bar.setValue(i)
        QCoreApplication.processEvents(QEventLoop.ProcessEventsFlag.ExcludeUserInputEvents)
        return not bar.wasCanceled()
    try:
        rows = BQ.label_report(layout, spec, tick=tick)
    except Exception as e:
        bar.close()
        QMessageBox.warning(parent, "Label check", "The PDF is saved, but the label check could not run: %s" % e)
        return
    done = not bar.wasCanceled()
    bar.close()
    if done and rows:
        lines = BP.label_report_lines(rows)
        bad = any(r["missing"] or r["overlaps"] for r in rows)
        (QMessageBox.warning if bad else QMessageBox.information)(parent, "Label check", "\n".join(lines))


def _current_pon_feature(layout):
    """(PON feature, PON layer) for the atlas page on screen, or (None, None) on an overview."""
    from . import book_pages_qgis as BQ
    from qgis.core import QgsProject, QgsFeatureRequest
    spec = BQ.get_spec(layout)
    at = layout.atlas()
    f = layout.reportContext().feature()
    if spec is None or not f.isValid() or f["is_overview"] == 1:
        return None, None
    pon = QgsProject.instance().mapLayer(spec["pon_layer_id"])
    if pon is None:
        return None, None
    # the page row's geometry IS the PON zone; find the PON feature with the same geometry
    g = f.geometry()
    for pf in pon.getFeatures(QgsFeatureRequest().setFilterRect(g.boundingBox())):
        if pf.geometry().equals(g) or (pf.geometry().area() > 0
                                       and abs(pf.geometry().area() - g.area()) / pf.geometry().area() < 1e-6
                                       and pf.geometry().centroid().equals(g.centroid())):
            return pf, pon
    del at
    return None, None


def _act_edit(designer, layout, focus_override=-1, spec=None):
    from . import book_pages_qgis as BQ
    spec = spec or BQ.get_spec(layout)
    if spec is None or not BQ.is_original(layout, BQ.get_spec(layout)):
        _bar(designer, "This layout is a copy — make it its own book first."); return
    win = designer.window()
    new = edit_spec(win, spec, focus_override=focus_override)
    if new is None:
        return
    try:
        BQ.update_book(layout, new)
        _bar(designer, "Pages updated — your layout edits were kept.", "success", 6)
    except Exception as e:
        QMessageBox.warning(win, "HLD Book", str(e))


def _act_own_pon(designer, layout):
    from . import book_pages_qgis as BQ
    pf, pon = _current_pon_feature(layout)
    if pf is None:
        _bar(designer, "Flip to a PON page first (Atlas toolbar ▶)."); return
    spec = BQ.get_spec(layout)
    idx = BQ.override_index_for(spec, pf, pon)
    if idx < 0:
        spec = BQ.add_override(spec, pf, pon)      # written only if the editor is accepted
        idx = len(spec["overrides"]) - 1
    _act_edit(designer, layout, focus_override=idx, spec=spec)


def _act_discard_pon(designer, layout):
    from . import book_pages_qgis as BQ
    pf, pon = _current_pon_feature(layout)
    spec = BQ.get_spec(layout)
    idx = BQ.override_index_for(spec, pf, pon) if pf is not None else -1
    if idx < 0:
        _bar(designer, "This page uses the shared PON set already.", "info", 5); return
    BQ.update_book(layout, BQ.discard_override(spec, idx))
    _bar(designer, "This PON page uses the shared set again.", "success", 5)


def _act_unmatched(designer, layout):
    from . import book_pages_qgis as BQ
    from qgis.core import QgsProject
    spec = BQ.get_spec(layout)
    pon = QgsProject.instance().mapLayer(spec["pon_layer_id"])
    um = BQ.unmatched_overrides(spec, pon)
    win = designer.window()
    if not um:
        QMessageBox.information(win, "HLD Book", "Every PON override matches its zone."); return
    labels = ["PON %s (was)" % (o.get("pon") or "?") for o in um]
    choice, ok = QInputDialog.getItem(win, "Unmatched override", "Override:", labels, 0, False)
    if not ok:
        return
    o = um[labels.index(choice)]
    idx = spec["overrides"].index(o)
    what, ok = QInputDialog.getItem(win, "Unmatched override", "Do what with it?",
                                    ["Re-attach to the PON page on screen", "Discard it"], 0, False)
    if not ok:
        return
    if what.startswith("Discard"):
        BQ.update_book(layout, BQ.discard_override(spec, idx))
    else:
        pf, pon2 = _current_pon_feature(layout)
        if pf is None:
            _bar(designer, "Flip to the PON page it belongs to first."); return
        BQ.update_book(layout, BQ.reattach_override(spec, idx, pf, pon2))
    _bar(designer, "Override updated.", "success", 5)


def _act_reattach_pon(designer, layout):
    from . import book_pages_qgis as BQ
    from qgis.core import QgsProject, QgsVectorLayer, QgsWkbTypes
    win = designer.window()
    p = QgsProject.instance()
    polys = [l for l in p.mapLayers().values() if isinstance(l, QgsVectorLayer)
             and not BQ.is_book_layer(l) and l.geometryType() == QgsWkbTypes.GeometryType.PolygonGeometry]
    if not polys:
        QMessageBox.information(win, "HLD Book", "No polygon layer to page over."); return
    names = ["%s  (%d)" % (l.name(), l.featureCount()) for l in polys]
    choice, ok = QInputDialog.getItem(win, "Re-attach PON layer", "One page per feature of:", names, 0, False)
    if not ok:
        return
    try:
        BQ.reattach_pon(layout, polys[names.index(choice)])
        _bar(designer, "Book re-attached — pages, notes and overrides kept.", "success", 6)
    except Exception as e:
        QMessageBox.warning(win, "HLD Book", str(e))


def _act_clone(designer, layout):
    from . import book_pages_qgis as BQ
    try:
        BQ.clone_book(layout)
        _bar(designer, "This layout is now its own book.", "success", 6)
    except Exception as e:
        QMessageBox.warning(designer.window(), "HLD Book", str(e))


def _rebuild_asbuilt(designer, layout):
    """S4: Rebuild book on an As-Built book = it gets the As-Built fixes (titles from Name,
    isolated PON pages, readable labels). Pre-check, one confirm with the Isolate tick, a copy
    of the saved project beside it on the first (converting) Rebuild, then the result."""
    from . import book_pages_qgis as BQ
    from qgis.core import QgsProject
    from qgis.PyQt.QtWidgets import QCheckBox
    win = designer.window()
    err = BQ.rebuild_precheck(layout)
    if err:
        QMessageBox.warning(win, "Rebuild book", err)
        return
    spec = BQ.get_spec(layout)
    fix = BQ.asbuilt_fix_of(layout, spec)
    converting = fix is None
    p = QgsProject.instance()
    lines = ["Recreate this As-Built book's page list and hidden layers with the As-Built fixes: "
             "PON page titles from the PON layer's Name, readable book labels, and (ticked) each PON "
             "page showing only its own zone. Your layout edits stay; live layers are not changed. "
             "A layout backup is written first."]
    ren = BQ.title_preview(layout)
    if ren:
        lines.append("%d PON page title(s) renamed, e.g. %s." % (
            len(ren), "; ".join("%s -> %s" % (o, n) for o, n in ren[:3])))
    lines += BQ.pon_name_report(dict(spec, asbuilt_fix=fix or {"v": 1}), p)
    bad = sorted({p.mapLayer(i).name() for i in spec["pon"]["ids"]
                  if p.mapLayer(i) is not None and not p.mapLayer(i).isValid()})
    if bad:
        lines.append("Not found on this machine: %s - their labels and any existing book label copy "
                     "are left as they were; open this project where those files load and press "
                     "Book Pages > Rebuild book again to finish them." % ", ".join(bad))
    if converting:
        if not p.fileName() or not os.path.isfile(p.fileName()):
            QMessageBox.warning(win, "Rebuild book", "Save the project once first - Rebuild copies the "
                                "saved file before it changes anything.")
            return
        lines.append("First the saved project file is copied beside it (%s.before_asbuilt_fix_%s_<time>%s). "
                     "The copy is the project file as last saved; unsaved changes are not in it."
                     % (os.path.splitext(os.path.basename(p.fileName()))[0], spec["book_id"],
                        os.path.splitext(p.fileName())[1]))
    box = QMessageBox(win)
    box.setWindowTitle("Rebuild book")
    box.setText("\n\n".join(lines))
    cb = QCheckBox("Isolate each PON page")
    cb.setChecked(True if converting else bool(fix.get("isolate")))
    box.setCheckBox(cb)
    fit_cb = QCheckBox("Make every label readable, no overlaps")
    fit_cb.setChecked(BP.label_fit_on(spec))
    grid = box.layout()
    grid.addWidget(fit_cb, grid.rowCount(), 0, 1, grid.columnCount())
    box.setStandardButtons(QMessageBox.StandardButton.Ok | QMessageBox.StandardButton.Cancel)
    if box.exec() != QMessageBox.StandardButton.Ok:
        return
    try:
        _lay, info = BQ.rebuild_book_ex(layout, isolate=cb.isChecked(), label_fit=fit_cb.isChecked())
    except Exception as e:
        QMessageBox.warning(win, "Rebuild book", "Rebuild failed: %s. Close the project WITHOUT saving - "
                            "the saved project is unchanged. Layout backups: %s." % (e, BQ._backup_root()))
        return
    res = ["Book rebuilt with the As-Built fixes."] + list(info.get("messages") or [])
    if info.get("copy"):
        res.append("Safety copy of the saved project: %s" % info["copy"])
    res.append("Layout backup: %s" % BQ._backup_root())
    res.append("Save the project to keep this. Teammates need this plugin version or newer; an older "
               "plugin shows fid titles again after its own Edit pages - Rebuild book fixes it.")
    QMessageBox.information(win, "Rebuild book", "\n\n".join(res))


def _act_rebuild(designer, layout):
    from . import book_pages_qgis as BQ
    win = designer.window()
    spec = BQ.get_spec(layout) or {}
    if spec.get("frame_kind") == BP.FRAME_ASBUILT:
        _rebuild_asbuilt(designer, layout)
        return
    if QMessageBox.question(win, "Rebuild book",
                            "Recreate this book's page list and hidden layers? Your layout edits "
                            "stay. A backup is written first.") != QMessageBox.StandardButton.Yes:
        return
    try:
        BQ.rebuild_book(layout)
        _bar(designer, "Book rebuilt (backup written).", "success", 6)
    except Exception as e:
        QMessageBox.warning(win, "HLD Book", str(e))


def _act_remove(designer, layout):
    from . import book_pages_qgis as BQ
    win = designer.window()
    name = layout.name()
    typed, ok = QInputDialog.getText(win, "Remove book",
                                     "This deletes the layout and its hidden book layers (a backup "
                                     "is written first).\nType the layout name to confirm:\n%s" % name)
    if not ok or typed.strip() != name:
        return
    try:
        d = BQ.remove_book(layout, backup=True)
        try:
            designer.close()
        except Exception:
            _swallowed_note()
        from qgis.utils import iface
        iface.messageBar().pushSuccess("HLD Book", "Removed “%s”. Backup: %s" % (name, d))
    except Exception as e:
        QMessageBox.warning(win, "HLD Book", str(e))


def restore_dialog(parent):
    from . import book_pages_qgis as BQ
    backups = BQ.list_backups()
    if not backups:
        QMessageBox.information(parent, "Restore book", "No book backups for this project.")
        return None
    labels = ["%s — %s (%s)" % (m.get("layout"), m.get("reason"), os.path.basename(d)) for d, m in backups]
    choice, ok = QInputDialog.getItem(parent, "Restore book", "Backup:", labels, 0, False)
    if not ok:
        return None
    try:
        return BQ.restore_book(backups[labels.index(choice)][0])
    except Exception as e:
        QMessageBox.warning(parent, "Restore book", str(e))
        return None


def _act_check(designer, layout):
    from . import book_pages_qgis as BQ
    hard, soft = BQ.check_book(layout, force=True)
    over = BQ.legend_overflow_pages(layout)
    if over:
        soft.append("Legend taller than its box on page(s): %s." % ", ".join(str(i + 1) for i in over[:20]))
    win = designer.window()
    if hard:
        QMessageBox.warning(win, "HLD Book check", "Will NOT export:\n• " + "\n• ".join(hard[:15])
                            + ("\n\nWarnings:\n• " + "\n• ".join(soft[:10]) if soft else ""))
    else:
        QMessageBox.information(win, "HLD Book check", "Every page draws exactly its layers."
                                + ("\n\nWarnings:\n• " + "\n• ".join(soft[:10]) if soft else ""))


def _run_for_key(key, slot):
    """Run slot(designer, layout, window) for the open designer whose window has C++ address `key`.
    The toolbar holds this int, never the designer, layout or window: a lambda holding those
    wrappers forms a cycle Python's GC clears while Qt still calls it (TypeError, or an access
    violation for a cleared closure, JJ 2026-10-26)."""
    from qgis.PyQt import sip
    from qgis.utils import iface
    for d in (iface.openLayoutDesigners() if iface is not None else None) or []:
        w = d.window() if hasattr(d, "window") else None
        if w is not None and sip.unwrapinstance(w) == key:
            slot(d, d.layout(), w)
            return


def add_designer_toolbar(designer):
    """Book Pages menu + Export Book as PDF on a book layout's designer."""
    try:
        from . import book_pages_qgis as BQ
        layout = designer.layout() if hasattr(designer, "layout") else None
        win = designer.window() if hasattr(designer, "window") else None
        if layout is None or win is None or not BQ.is_book_layout(layout):
            return
        if win.findChild(QToolBar, TOOLBAR_NAME) is not None:
            return
        tb = QToolBar("HLD Book", win)
        tb.setObjectName(TOOLBAR_NAME)
        btn = QToolButton(tb)
        btn.setText("Book Pages")
        btn.setObjectName("vfBookPagesButton")
        btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        menu = QMenu(btn)
        # every slot gets (designer, layout, window) looked up at click time; the connections hold
        # only the window's address (see _run_for_key)
        items = [
            ("Edit pages…", lambda d, lay, w: _act_edit(d, lay)),
            ("Own layers for this PON…", lambda d, lay, w: _act_own_pon(d, lay)),
            ("Use the shared set for this PON", lambda d, lay, w: _act_discard_pon(d, lay)),
            ("Unmatched overrides…", lambda d, lay, w: _act_unmatched(d, lay)),
            (None, None),
            ("Lock map frame here (size and position)", lambda d, lay, w: (BQ.lock_frame_position_here(lay),
                                                                           _bar(d, "Map frame size and position locked "
                                                                                "for every page.", "success", 4))),
            ("Re-attach PON layer…", lambda d, lay, w: _act_reattach_pon(d, lay)),
            ("Make this copy its own book", lambda d, lay, w: _act_clone(d, lay)),
            (None, None),
            ("Check book", lambda d, lay, w: _act_check(d, lay)),
            ("Rebuild book (keeps your edits)…", lambda d, lay, w: _act_rebuild(d, lay)),
            ("Remove book…", lambda d, lay, w: _act_remove(d, lay)),
            ("Restore a removed book…", lambda d, lay, w: restore_dialog(w)),
            ("Remove leftover book layers", lambda d, lay, w: _bar(d, "Removed %d leftover layer(s)."
                                                                   % BQ.remove_orphans(), "success", 5)),
        ]
        from qgis.PyQt import sip
        key = sip.unwrapinstance(win)
        for txt, fn in items:
            if txt is None:
                menu.addSeparator(); continue
            a = menu.addAction(txt)
            a.triggered.connect(lambda *_a, k=key, f=fn: _run_for_key(k, f))
        btn.setMenu(menu)
        tb.addWidget(btn)
        ex = tb.addAction("Export Book as PDF")
        ex.setObjectName("vfExportBookPdf")
        ex.setToolTip("Export the whole book with the page draw check, page-count check and "
                      "bookmarks. QGIS's own export runs no checks.")
        ex.triggered.connect(lambda *_a, k=key: _run_for_key(k, lambda d, lay, w: export_book(lay, w, d)))
        win.addToolBar(Qt.ToolBarArea.TopToolBarArea, tb)
        BQ.relock_frame(layout)
        for w in designer_warnings(layout)[:3]:
            _bar(designer, w)
    except Exception as e:
        print("HLD Book toolbar skipped:", e)


class BookPagesHook:
    """Designer toolbar for book layouts + the frame guard (re-lock on every page flip of a
    book layout, connected from project read and layoutAdded — not only while a designer is
    open). Every connection is tracked and removed on uninstall."""

    def __init__(self, iface):
        self.iface = iface
        self._installed = False
        self._atlas_conns = []          # (atlas, slot)
        self._proj_conns = []           # (signal owner, signal name, slot)

    def install(self):
        if self._installed or not button_enabled():
            return
        from qgis.core import QgsProject
        try:
            self.iface.layoutDesignerOpened.connect(add_designer_toolbar)
            p = QgsProject.instance()
            p.readProject.connect(self._on_read)
            p.layoutManager().layoutAdded.connect(self._on_layout_added)
            self._proj_conns = [(p, "readProject", self._on_read),
                                (p.layoutManager(), "layoutAdded", self._on_layout_added)]
            self._installed = True
            self._on_read()
            for d in self.iface.openLayoutDesigners() or []:
                add_designer_toolbar(d)
        except Exception as e:
            print("HLD Book hook skipped:", e)

    def _on_read(self, *_a):
        from qgis.core import QgsProject
        from . import book_pages_qgis as BQ
        self._drop_atlas_conns()
        try:
            for lay in BQ.all_book_layouts(QgsProject.instance()):
                self._watch(lay)
        except Exception:
            _swallowed_note()

    def _on_layout_added(self, name):
        from qgis.core import QgsProject
        from . import book_pages_qgis as BQ
        try:
            lay = QgsProject.instance().layoutManager().layoutByName(name)
            if lay is not None and BQ.is_book_layout(lay):
                self._watch(lay)
        except Exception:
            _swallowed_note()

    def _watch(self, layout):
        from . import book_pages_qgis as BQ
        at = layout.atlas()
        for a, _s in self._atlas_conns:
            if a is at:
                return

        def slot(*_a, lay=layout):
            try:
                BQ.relock_frame(lay)
            except Exception:
                _swallowed_note()
        at.featureChanged.connect(slot)
        self._atlas_conns.append((at, slot))

    def _drop_atlas_conns(self):
        from qgis.PyQt import sip
        for at, slot in self._atlas_conns:
            try:
                if not sip.isdeleted(at):
                    at.featureChanged.disconnect(slot)
            except Exception:
                _swallowed_note()
        self._atlas_conns = []

    def uninstall(self):
        from qgis.PyQt import sip
        self._drop_atlas_conns()
        for owner, sig, slot in self._proj_conns:
            try:
                if not sip.isdeleted(owner):
                    getattr(owner, sig).disconnect(slot)
            except Exception:
                _swallowed_note()
        self._proj_conns = []
        if self._installed:
            try:
                if not sip.isdeleted(self.iface.mainWindow()):
                    self.iface.layoutDesignerOpened.disconnect(add_designer_toolbar)
            except Exception:
                _swallowed_note()
        self._installed = False


# ── dialog entry: build (or update) and open ───────────────────────────────────────────
def _existing_book_for(pon_id, phase=None, frame=BP.FRAME_HLD):
    """The original book for this PON layer / phase AND frame (an A3 book and an As-Built
    book over the same PONs are two different books)."""
    from qgis.core import QgsProject
    from . import book_pages_qgis as BQ
    for lay in BQ.all_book_layouts(QgsProject.instance()):
        sp = BQ.get_spec(lay)
        if sp and BQ.is_original(lay, sp) and sp.get("pon_layer_id") == pon_id \
                and sp.get("phase") == phase and (sp.get("frame_kind") or BP.FRAME_HLD) == frame:
            return lay, sp
    return None, None


class AsBuiltDetailsDialog(QDialog):
    """The typed half of the As-Built facts table, asked once per new book (counts are worked
    out from the layers). Every value stays editable later in the designer's table."""
    FIELDS = (("province", "Province"), ("area", "Area"), ("phase", "Phase"), ("date", "Date"),
              ("drawn_by", "Drawn by"), ("split_ratio", "Splitting ratio"))

    def __init__(self, parent, details):
        super().__init__(parent)
        self.setWindowTitle("As-Built details")
        lay = QFormLayout(self)
        lay.addRow(QLabel("These go in the facts table on every page. Counts (units, poles, FAPs, "
                          "CTPs, PONs) come from your layers."))
        self._edits = {}
        for key, label in self.FIELDS:
            e = QLineEdit(str(details.get(key) or ""))
            e.setObjectName("asbuilt_" + key)
            self._edits[key] = e
            lay.addRow(label + ":", e)
        # v2 (Cradock p1): optional photo of the tie-in pole, shown on the backhaul page only;
        # left empty, no photo slot is drawn (a pole photo in the data is used first)
        row = QHBoxLayout()
        self._photo = QLineEdit(str(details.get("tiein_photo") or ""))
        self._photo.setObjectName("asbuilt_tiein_photo")
        self._photo.setPlaceholderText("optional - shown on the backhaul page")
        pick = QPushButton("Browse…")
        pick.clicked.connect(self._pick_photo)
        row.addWidget(self._photo)
        row.addWidget(pick)
        lay.addRow("Tie-in pole photo:", row)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addRow(bb)

    def _pick_photo(self):
        from qgis.PyQt.QtWidgets import QFileDialog
        path, _f = QFileDialog.getOpenFileName(self, "Tie-in pole photo", self._photo.text() or "",
                                               "Images (*.jpg *.jpeg *.png *.bmp *.tif *.tiff)")
        if path:
            self._photo.setText(path)

    def values(self):
        out = {k: e.text().strip() for k, e in self._edits.items()}
        out["tiein_photo"] = self._photo.text().strip()
        return out


def ask_asbuilt_details(parent, details):
    """Returns the edited details, or None when cancelled."""
    d = AsBuiltDetailsDialog(parent, details)
    d.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, False)
    try:
        if d.exec() != QDialog.DialogCode.Accepted:
            return None
        return d.values()
    finally:
        d.deleteLater()


def open_book_designer(iface, layout):
    from . import book_pages_qgis as BQ
    try:
        d = iface.openLayoutDesigner(layout)
        try:
            d.setAtlasPreviewEnabled(True)
            layout.atlas().seekTo(0)
            BQ.relock_frame(layout)
            layout.atlas().refreshCurrentFeature()
            BQ.relock_frame(layout)
            layout.refresh()
            from qgis.PyQt.QtWidgets import QToolBar as _TB
            win = d.window()
            for tb in win.findChildren(_TB):
                if (tb.objectName() or "").lower() == "matlastoolbar":
                    tb.setVisible(True)
        except Exception:
            _swallowed_note()
        add_designer_toolbar(d)
        w = d.window()
        w.show(); w.raise_(); w.activateWindow()
        return d
    except Exception as e:
        print("HLD Book: designer open skipped:", e)
        return None


def run_book_build(iface, cfg, v, cov_layers, phases=None):
    """Build (or open/update) the custom-pages book(s) for the dialog's choices.
    Returns (ok, message). Never edits layer data, styles or the Layers panel."""
    from qgis.core import QgsProject
    from . import book_pages_qgis as BQ
    if not model_enabled():
        return False, "The HLD Book (custom pages) model is switched off."
    cfg = dict(cfg or {})
    cfg["book_pages"] = True
    cfg["restyle_layers"] = False
    frame = cfg.get("book_frame") or BP.FRAME_HLD
    p = QgsProject.instance()
    built = []
    asked = {}

    def _details(spec):
        # As-Built: the typed facts are asked once per run (phase books share them), never
        # for the A3 book; Cancel builds nothing.
        if spec.get("frame_kind") != BP.FRAME_ASBUILT:
            return spec
        if "d" not in asked:
            got = ask_asbuilt_details(iface.mainWindow() if iface is not None else None,
                                      dict((spec.get("asbuilt") or {}).get("details") or {}))
            if got is None:
                raise _Cancelled()
            BQ.asbuilt_remember(got)
            asked["d"] = got
        d = dict(asked["d"])
        if spec.get("phase") is not None:
            d["phase"] = str(spec["phase"])
        spec["asbuilt"] = dict(spec.get("asbuilt") or {}, details=d)
        return spec
    try:
        return _run_book_build(iface, cfg, v, cov_layers, phases, frame, p, built, _details)
    except _Cancelled:
        return False, "As-Built book not built (details cancelled)."


class _Cancelled(Exception):
    pass


def _run_book_build(iface, cfg, v, cov_layers, phases, frame, p, built, _details):
    from . import book_pages_qgis as BQ
    if v.get("phase_mode"):
        wanted = set(v.get("phases") or [])
        for ph in phases or []:
            if ph["phase_no"] not in wanted or ph.get("coverage") is None:
                continue
            lay, _sp = _existing_book_for(ph["coverage"].id(), ph["phase_no"], frame)
            if lay is None:
                spec = _details(BQ.default_spec(cfg, p, phase=ph, frame_kind=frame))
                lay, _m = BQ.build_or_update(cfg, spec, p)
            built.append(lay)
        if not built:
            return False, "No phase with a PON layer was selected."
        open_book_designer(iface, built[0])
        return True, "Built %d phase book(s): %s." % (len(built), ", ".join(l.name() for l in built))
    if v.get("grid"):
        return False, "A custom-pages book pages over a PON / zone layer, not the grid."
    pon = next((l for l in cov_layers if l.name() == v.get("coverage")), None)
    if pon is None:
        return False, "Pick the PON / zone layer under “Each page shows”."
    lay, sp = _existing_book_for(pon.id(), None, frame)
    edited = v.get("book_spec")
    if edited is not None and (edited.get("frame_kind") or BP.FRAME_HLD) != frame:
        edited = None                      # pages edited for the other model: start fresh
    if lay is not None and not edited:
        open_book_designer(iface, lay)
        hint = ""
        if frame == BP.FRAME_ASBUILT and BQ.asbuilt_fix_of(lay) is None:
            hint = ("  To give it the As-Built fixes (PON names, isolated PON pages, readable labels) "
                    "press Book Pages ▸ Rebuild book in the designer.")
        return True, ("“%s” is already built — opened it. Change pages with Book Pages ▸ Edit "
                      "pages… in the designer.%s" % (lay.name(), hint))
    if edited is not None and edited.get("pon_layer_id") == pon.id():
        spec = edited
        if lay is not None:
            spec = dict(spec, book_id=sp["book_id"])
    else:
        spec = BQ.default_spec(cfg, p, pon_layer=pon, frame_kind=frame)
    if lay is None:
        spec = _details(spec)
    lay, msg = BQ.build_or_update(cfg, spec, p)
    open_book_designer(iface, lay)
    return True, msg
