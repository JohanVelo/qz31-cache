"""
Run-report for Hybrid Detect Buildings (Phase 6).

Renders a small self-contained HTML card summarising a hybrid run: how many
Overture footprints came down, how much of the AOI was flagged as gaps, how many
AI buildings were added, and the tuning used. Pure string-building (no QGIS, no
deps) so it is testable and can be written from the subprocess worker.

Overture is CC-BY-4.0 — the attribution line is written into every report.
"""

from __future__ import annotations

OVERTURE_ATTRIB = ("Building footprints © Overture Maps Foundation (CC BY 4.0); "
                   "includes Google Open Buildings, Microsoft & OpenStreetMap.")


def _n(v, dp=0):
    try:
        return f"{float(v):,.{dp}f}"
    except (TypeError, ValueError):
        return "—"


def render_report_html(stats: dict, *, title: str = "Hybrid Detect Buildings",
                       aoi_name: str = "AOI", overture_count=None,
                       ai_added=None, ai_flagged=None,
                       overture_release: str = "", generated: str = "") -> str:
    """Return a complete HTML page (body content) summarising a hybrid run."""
    aoi_km2 = float(stats.get("aoi_area_m2", 0) or 0) / 1e6
    gap_km2 = float(stats.get("gap_area_m2", 0) or 0) / 1e6
    gap_pct = float(stats.get("gap_fraction", 0) or 0) * 100.0
    cov_pct = max(0.0, 100.0 - gap_pct)
    ov = overture_count if overture_count is not None else stats.get("n_buildings", 0)
    added = ai_added if ai_added is not None else 0
    total = (ov or 0) + (added or 0)

    def card(label, value, sub=""):
        s = f"<div class='sub'>{sub}</div>" if sub else ""
        return (f"<div class='c'><div class='v'>{value}</div>"
                f"<div class='l'>{label}</div>{s}</div>")

    cards = "".join([
        card("Overture footprints", _n(ov), "trusted base"),
        card("AI gap-fill added", _n(added), f"{_n(ai_flagged or added)} flagged for review"),
        card("Total buildings", _n(total), ""),
        card("Gap regions", _n(stats.get("n_regions", 0)), f"{_n(gap_km2,2)} km² · {gap_pct:.1f}% of AOI"),
        card("AOI area", f"{_n(aoi_km2,2)} km²", aoi_name),
        card("Median density", _n(stats.get("median_density", 0), 1), "buildings / 80 m cell"),
    ])

    params = " · ".join([
        f"sensitivity {stats.get('sensitivity','?')}",
        f"near-empty thresh {stats.get('threshold_count','?')}/cell",
        f"enclosure {'on' if stats.get('enclosure') else 'off'}",
        f"coverage {int(float(stats.get('coverage',0) or 0)*100)}%",
    ])

    return f"""<meta charset="utf-8">
<title>{title} — Run Report</title>
<style>
 :root{{--bg:#0a0e14;--panel:#111823;--line:#1e2b3a;--ink:#e6edf3;--dim:#93a4b8;
   --faint:#5f7288;--cyan:#22d3ee;--green:#34d399;--amber:#f5a623;
   --sans:'Chakra Petch','Segoe UI',system-ui,sans-serif;--mono:'JetBrains Mono',ui-monospace,monospace}}
 *{{box-sizing:border-box}} body{{margin:0;background:var(--bg);color:var(--ink);font-family:var(--sans)}}
 .wrap{{max-width:860px;margin:0 auto;padding:36px 24px 60px}}
 .tag{{font-family:var(--mono);font-size:11px;letter-spacing:2px;color:var(--cyan);text-transform:uppercase}}
 h1{{font-size:30px;margin:6px 0 2px}} .meta{{color:var(--faint);font-family:var(--mono);font-size:12px;margin-bottom:22px}}
 .bar{{height:26px;border-radius:8px;overflow:hidden;display:flex;border:1px solid var(--line);margin:6px 0 4px}}
 .bar .cov{{background:linear-gradient(90deg,#0891b2,#34d399);width:{cov_pct:.1f}%}}
 .bar .gap{{background:linear-gradient(90deg,#b45309,#f5a623);width:{gap_pct:.1f}%}}
 .barl{{display:flex;justify-content:space-between;font-size:12px;color:var(--dim);font-family:var(--mono);margin-bottom:24px}}
 .grid{{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}}
 @media(max-width:640px){{.grid{{grid-template-columns:1fr 1fr}}}}
 .c{{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px}}
 .c .v{{font-size:26px;font-weight:700;font-family:var(--mono);color:var(--cyan)}}
 .c .l{{color:var(--dim);font-size:13px;margin-top:2px}} .c .sub{{color:var(--faint);font-size:11px;margin-top:3px}}
 .foot{{margin-top:26px;padding-top:16px;border-top:1px solid var(--line);color:var(--faint);font-size:12px;font-family:var(--mono)}}
 .params{{margin-top:18px;font-family:var(--mono);font-size:12px;color:var(--dim);background:#0d141d;border:1px solid var(--line);border-radius:10px;padding:12px 14px}}
</style>
<div class="wrap">
  <div class="tag">Velocity Nexus · Detect Buildings · Run Report</div>
  <h1>{title}</h1>
  <div class="meta">{aoi_name}{'  ·  '+generated if generated else ''}{'  ·  Overture '+overture_release if overture_release else ''}</div>
  <div class="bar"><div class="cov"></div><div class="gap"></div></div>
  <div class="barl"><span>■ Overture-covered {cov_pct:.1f}%</span><span>■ AI gap candidates {gap_pct:.1f}%</span></div>
  <div class="grid">{cards}</div>
  <div class="params">tuning: {params}</div>
  <div class="foot">{OVERTURE_ATTRIB}</div>
</div>"""


def write_report(stats: dict, out_path: str, **kw) -> str:
    html = render_report_html(stats, **kw)
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write(html)
    return out_path
