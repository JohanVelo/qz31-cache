"""Vuma Step 9 — QA checks across all project layers.

STATUS: [x] BUILT
"""

from fibre_automation.shared.qa_utils import (
    check_crs_consistent,
    check_empty_layers,
    check_missing_layers,
    check_no_duplicate_names,
    check_no_null_names,
    get_layer,
    print_qa_report,
)

REQUIRED_LAYERS = [
    "Erven",
    "Aggregation Polygon",
    "Block",
    "Poles",
    "Dome Joint",
    "Feeder Joints",
    "Demand Points",
    "Feeder",
    "Distribution Cable",
    "Spur Cable",
    "Drops",
    "Buildings",
]

NAMED_LAYERS = [
    ("Poles",              "Name"),
    ("Dome Joint",         "Name"),
    ("Spur Joints",        "Name"),
    ("Feeder Joints",      "Label"),
    ("Demand Points",      "Name"),
    ("Feeder",             "Name"),
    ("Distribution Cable", "Name"),
    ("Spur Cable",         "Name"),
]

CRS_LAYERS = [
    "Poles",
    "Demand Points",
    "Feeder",
    "Distribution Cable",
    "Drops",
    "Buildings",
]

MUST_HAVE_FEATURES = [
    "Demand Points",
    "Buildings",
]


def vuma_step_09_qa():
    """Run QA checks and print a pass/fail report.

    STATUS: [x] BUILT
    Non-destructive — read-only checks only.

    Checks:
      - Missing layers
      - Empty layers (Demand Points and Buildings must not be empty)
      - CRS consistency across key layers
      - Null or empty Name fields
      - Duplicate Name values
      - Untagged buildings (building_t IS NULL)
      - Demand points without DR number
    """
    print(f"\n{'═' * 50}")
    print("  VUMA STEP 9 — QA Report")
    print(f"{'═' * 50}")

    errors = []
    warnings = []

    # Missing layers
    missing = check_missing_layers(REQUIRED_LAYERS)
    for name in missing:
        errors.append(f"Layer missing: '{name}'")

    # Empty layers that must have features
    empty = check_empty_layers(MUST_HAVE_FEATURES)
    for name in empty:
        errors.append(f"Layer is empty: '{name}'")

    # Warn on other empty required layers
    other_empty = check_empty_layers([l for l in REQUIRED_LAYERS if l not in MUST_HAVE_FEATURES])
    for name in other_empty:
        warnings.append(f"Layer empty (not yet populated?): '{name}'")

    # CRS consistency
    crs_bad = check_crs_consistent(CRS_LAYERS)
    # The reference CRS is the first PRESENT layer (matches check_crs_consistent),
    # not necessarily CRS_LAYERS[0] which may be absent from the project.
    crs_ref = next((n for n in CRS_LAYERS if get_layer(n)), CRS_LAYERS[0])
    for name in crs_bad:
        errors.append(f"CRS mismatch: '{name}' differs from '{crs_ref}'")

    # Null names
    for layer_name, field in NAMED_LAYERS:
        lyr = get_layer(layer_name)
        if lyr is None or lyr.featureCount() == 0:
            continue
        null_fids = check_no_null_names(lyr, field)
        if null_fids:
            warnings.append(f"{layer_name}: {len(null_fids)} feature(s) with null '{field}'")

    # Duplicate names
    for layer_name, field in NAMED_LAYERS:
        lyr = get_layer(layer_name)
        if lyr is None or lyr.featureCount() == 0:
            continue
        dupes = check_no_duplicate_names(lyr, field)
        if dupes:
            warnings.append(f"{layer_name}: duplicate {field} values: {dupes[:5]}")

    # Untagged buildings
    bld = get_layer("Buildings")
    if bld and bld.featureCount() > 0:
        btype_idx = bld.fields().indexOf("building_t")
        if btype_idx >= 0:
            untagged = sum(
                1 for f in bld.getFeatures()
                if f[btype_idx] is None or str(f[btype_idx]).strip() == ""
            )
            if untagged > 0:
                warnings.append(f"Buildings: {untagged:,} untagged (run Step 2)")

    # Demand points without DR number
    dp = get_layer("Demand Points")
    if dp and dp.featureCount() > 0:
        name_idx = dp.fields().indexOf("Name")
        if name_idx >= 0:
            no_dr = sum(
                1 for f in dp.getFeatures()
                if not str(f[name_idx] or "").startswith("DR")
            )
            if no_dr > 0:
                warnings.append(f"Demand Points: {no_dr:,} without DR number")

    n_err, n_warn = print_qa_report("VUMA", errors, warnings)
    return n_err == 0
