# -*- coding: utf-8 -*-
"""HLD Book (custom pages) — the page SPEC, in pure Python (no QGIS imports).

A custom-pages book is one atlas whose every page draws its own layer set. This module
holds everything about that spec that can be decided without QGIS, so it can be property
tested in isolation:

  * the spec dict (overview pages, the shared PON-page set, per-zone overrides) and its
    JSON round-trip + validation,
  * the default page contents (JJ 2026-10-08: page 1 area, page 2 PONs with labels,
    page 3 FTS splitters, page 4 feeders, then one page per PON with the network on),
  * the never-show rule for layers that no book draws,
  * draw order, the "expected draw set" (listed ids plus same-named twins, JJ 18:00:
    draw both and warn, never refuse) and the per-page draw check verdict,
  * the metric zone fingerprint used to tie a per-PON override to its zone, not its number.

QGIS-side reading and writing lives in book_pages_qgis.py.
"""
import json
import math
import re
import secrets

SPEC_VERSION = 1

# QSettings keys. The model switch is the master: while it is off nothing of this feature
# is reachable (no model in the dialog, no designer hook). Default OFF until the release
# that switches it on (plan Rev 8, S8).
SETTING_MODEL = "vf/hld/book_pages_model"
SETTING_BUTTON = "vf/hld/book_pages_button"
SETTING_GUARD = "vf/hld/book_pages_guard"
MODEL_DEFAULT_ON = False
BUTTON_DEFAULT_ON = True
GUARD_DEFAULT_ON = True

MODEL_ID = "hld_book_pages"
ASBUILT_MODEL_ID = "hld_asbuilt"
BOOK_MODEL_IDS = (MODEL_ID, ASBUILT_MODEL_ID)
FRAME_HLD = "hld"
FRAME_ASBUILT = "asbuilt"
PROP_BOOK_ID = "vf_book_id"          # on the layout and on every book-owned layer
PROP_SPEC = "vf_book_spec"           # full spec JSON on the layout
PROP_ROLE = "vf_book_role"           # pages | guard | label (on book-owned layers)
PROP_AUTO_LABEL = "vf_auto_label"    # on legend nodes the tool may still rewrite
NAME_PREFIX = "vfbk_"
# Oldest QGIS the book was MEASURED on (2026-10-09: all ACs on 3.38.0, 3.40.3, 3.44.9 and 4.2.0 -
# every version the team runs). Older versions see the model greyed out with the reason.
MIN_QGIS_INT = 33800
MIN_QGIS_TEXT = "3.38"

# Network roles the engine knows (hld_atlas_engine.py CFG["roles"]); every one the project
# has is always on a PON page (A3: "feeders poles splitters ect all on").
PON_PAGE_ROLES = ("primary", "secondary", "distribution", "drop", "spare_drop", "poles",
                  "fts", "sts", "enc_splice", "enc_conn", "enclosure", "ont", "coverage")
FEEDER_ROLES = ("primary", "secondary")

# Kinds no book draws (phases.py _NEVER_SHOW + hld_atlas_engine.py detail_exclude + the
# demand-point layers the round-8 review found on Mohadin). Matched on whole words in the
# lower-cased name, so "Splitter Points" is not "demand point".
_NEVER_SHOW_RE = re.compile(
    r"(?i)\b(demand\s*points?|demand\s*units?|ajoint|splicing|zones?|slack|erven|erfs?|"
    r"tbc|to be confirmed)\b")

_HEX12 = re.compile(r"^[0-9a-f]{12}$")
NAME_RE = re.compile(r"^vfbk_[0-9a-f]{12}_(pages|guard|lbl_[0-9]+)$")
ROLE_KEYWORDS = ("pon", "zone", "pole", "fts", "sts", "agg", "splitter", "enclosure", "closure",
                 "joint", "manhole", "chamber", "handhole", "splice", "connectoris", "connectoriz",
                 "ont", "home connection", "premise", "drop point", "customer", "primary",
                 "feeder", "secondary", "distribution", "mini", "drop", "spare", "greenfield",
                 "overbuild", "boundary", "aoi", "area of interest", "extent", "erven", "erf",
                 "building", "grid")


# ── ids and names ──────────────────────────────────────────────────────────────────────
def new_book_id():
    """12 random lowercase hex chars — hex can never spell a role keyword."""
    return secrets.token_hex(6)


def is_book_id(s):
    return bool(_HEX12.match(str(s or "")))


def pages_layer_name(book_id):
    return "%s%s_pages" % (NAME_PREFIX, book_id)


def guard_layer_name(book_id):
    return "%s%s_guard" % (NAME_PREFIX, book_id)


def label_layer_name(book_id, n):
    return "%s%s_lbl_%d" % (NAME_PREFIX, book_id, int(n))


def name_has_role_keyword(name):
    low = (name or "").lower()
    return any(k in low for k in ROLE_KEYWORDS)


def is_never_show(name):
    return bool(_NEVER_SHOW_RE.search(name or ""))


# ── spec ───────────────────────────────────────────────────────────────────────────────
def empty_spec(book_id=None, title="HLD"):
    return {
        "version": SPEC_VERSION,
        "book_id": book_id or new_book_id(),
        "title": title,
        "layout_name": "",
        "phase": None,
        "pon_layer_id": "",
        "pon_label_field": "",
        "pon_sort_field": "",
        "pon_sort_numeric": False,
        "pon_title_prefix": "PON ",
        "metric_epsg": 0,
        "overview_wkt": "",
        "overview_srid": 0,
        "aerial_id": "",
        "guard_id": "",
        "pages_id": "",
        "label_layers": {},        # source layer id -> label layer id
        "overview": [],            # [{"title","ids","labels","note"}]
        "pon": {"ids": [], "labels": [], "note": ""},
        "overrides": [],           # [{"cx","cy","area","pon","ids","labels","note"}]
        "legend_known": [],        # layer ids the legend already offered (user deletions stick)
        "defaults_left_out": [],   # default page titles left out because no layer matched
        "frame": None,             # {"x","y","w","h"} the designed map frame (mm)
        "frame_kind": FRAME_HLD,   # hld = A3 + sidebar; asbuilt = A4 + bottom strip
        "asbuilt": {},             # As-Built typed details + the layers its counts read
    }


def make_page(title, ids=(), labels=(), note=""):
    return {"title": str(title), "ids": _uniq(ids), "labels": _uniq(labels), "note": str(note or "")}


def _uniq(seq):
    out, seen = [], set()
    for x in seq or ():
        x = str(x)
        if x and x not in seen:
            seen.add(x); out.append(x)
    return out


def unique_titles(titles):
    """Make page titles unique by suffixing ' (2)', ' (3)'… — order kept."""
    out, used = [], set()
    for t in titles:
        base = str(t).strip() or "Page"
        cand, n = base, 2
        while cand.lower() in used:
            cand = "%s (%d)" % (base, n); n += 1
        used.add(cand.lower()); out.append(cand)
    return out


def normalise(spec):
    """Return a cleaned copy: unique titles, de-duplicated id lists, labels ⊆ ids."""
    s = json.loads(json.dumps(spec))
    base = empty_spec(s.get("book_id"), s.get("title", "HLD"))
    for k, v in base.items():
        s.setdefault(k, v)
    ov = []
    for p in s.get("overview") or []:
        ids = _uniq(p.get("ids"))
        ov.append(make_page(p.get("title", ""), ids, [x for x in _uniq(p.get("labels")) if x in ids],
                            p.get("note", "")))
    for p, t in zip(ov, unique_titles([p["title"] for p in ov])):
        p["title"] = t
    s["overview"] = ov
    pon = s.get("pon") or {}
    pids = _uniq(pon.get("ids"))
    s["pon"] = {"ids": pids, "labels": [x for x in _uniq(pon.get("labels")) if x in pids],
                "note": str(pon.get("note") or "")}
    ovr = []
    for o in s.get("overrides") or []:
        ids = _uniq(o.get("ids"))
        ovr.append({"cx": float(o["cx"]), "cy": float(o["cy"]), "area": float(o["area"]),
                    "pon": str(o.get("pon", "")), "ids": ids,
                    "labels": [x for x in _uniq(o.get("labels")) if x in ids],
                    "note": str(o.get("note") or "")})
    s["overrides"] = ovr
    s["legend_known"] = _uniq(s.get("legend_known"))
    s["frame_kind"] = FRAME_ASBUILT if s.get("frame_kind") == FRAME_ASBUILT else FRAME_HLD
    s["asbuilt"] = dict(s.get("asbuilt") or {}) if s["frame_kind"] == FRAME_ASBUILT else {}
    s["label_layers"] = {str(k): str(v) for k, v in (s.get("label_layers") or {}).items()}
    return s


def to_json(spec):
    return json.dumps(normalise(spec), sort_keys=True, separators=(",", ":"))


def from_json(text):
    s = json.loads(text)
    if not isinstance(s, dict) or int(s.get("version", 0)) != SPEC_VERSION:
        raise ValueError("not a version-%d book spec" % SPEC_VERSION)
    if not is_book_id(s.get("book_id")):
        raise ValueError("book spec has no valid book id")
    return normalise(s)


def validate(spec, names_by_id):
    """(errors, warnings). `names_by_id` = {layer id: current name} of the project.

    Errors refuse a build/export: a page with nothing listed, a listed layer whose name
    contains '|' (the map's layer expression is '|'-joined), the PON layer missing.
    Warnings never refuse: a listed layer that no longer exists (the page draws without
    it), and same-named layers (both draw — JJ 18:00)."""
    errors, warnings = [], []
    s = normalise(spec)
    if not s.get("pon_layer_id") or s["pon_layer_id"] not in names_by_id:
        errors.append("The PON layer this book pages over is missing from the project "
                      "(use “Re-attach PON layer”).")
    pages = [(p["title"], p["ids"]) for p in s["overview"]] + [("PON pages", s["pon"]["ids"])]
    pages += [("PON %s (own layers)" % (o.get("pon") or "?"), o["ids"]) for o in s["overrides"]]
    counts = {}
    for n in names_by_id.values():
        counts[n] = counts.get(n, 0) + 1
    for title, ids in pages:
        if not ids:
            errors.append("Page “%s” has no layers ticked." % title)
        for i in ids:
            n = names_by_id.get(i)
            if n is None:
                warnings.append("Page “%s”: a listed layer no longer exists." % title)
                continue
            if "|" in n:
                errors.append("Page “%s”: layer name “%s” contains “|” — rename it." % (title, n))
            if counts.get(n, 0) > 1:
                warnings.append("Page “%s”: %d layers are named “%s”; all of them draw."
                                % (title, counts[n], n))
    return errors, _uniq(warnings)


# ── defaults ───────────────────────────────────────────────────────────────────────────
def default_pages(roles, ticked, aoi_id="", pon_id="", fts_id="", label_pon=True):
    """Default overview pages + shared PON-page set.

    roles  : {role: [layer id, ...]} — the engine's own resolution per role (v1-canonical).
    ticked : [(layer id, name)] — vector layers ticked in the Layers panel.
    Returns (overview_pages, pon_ids, pon_labels)."""
    feeders = []
    for r in FEEDER_ROLES:
        feeders += list(roles.get(r) or [])
    ov = [make_page("Area", [aoi_id] if aoi_id else []),
          make_page("PON zones", [pon_id] if pon_id else [], [pon_id] if (pon_id and label_pon) else []),
          make_page("FTS splitters", [fts_id] if fts_id else []),
          make_page("Feeders", feeders)]
    pon_ids = []
    for r in PON_PAGE_ROLES:
        for lid in roles.get(r) or []:
            pon_ids.append(lid)
    for lid, name in ticked or []:
        if not is_never_show(name):
            pon_ids.append(lid)
    return ov, _uniq(pon_ids), []


# ── draw order / page ids ──────────────────────────────────────────────────────────────
_KIND_RANK = {"point": 0, "line": 1, "polygon": 2, "unknown": 3, "raster": 4}


def ordered_ids(ids, kinds, tree_order=None):
    """Top-first draw order: points, lines, polygons, then rasters; ties keep the Layers
    panel order (`tree_order` = ids top-first), then the listed order."""
    pos = {lid: i for i, lid in enumerate(tree_order or [])}
    lst = _uniq(ids)
    return sorted(lst, key=lambda i: (_KIND_RANK.get(kinds.get(i, "unknown"), 3),
                                      pos.get(i, 10 ** 6), lst.index(i)))


def page_id_list(ids, labels, label_layers, aerial_id, guard_id, kinds, tree_order=None):
    """The ids a page's row stores: its layers (top-first) with each labelled layer's label
    layer directly above it, then aerial, then the guard. Aerial + guard are always there,
    so a row can never resolve to nothing."""
    out = []
    for i in ordered_ids([x for x in ids if x not in (aerial_id, guard_id)], kinds, tree_order):
        if i in labels and label_layers.get(i):
            out.append(label_layers[i])
        out.append(i)
    if aerial_id:
        out.append(aerial_id)
    if guard_id:
        out.append(guard_id)
    return _uniq(out)


def join_ids(ids):
    return "|".join(ids)


def split_ids(text):
    return [x for x in str(text or "").split("|") if x]


# ── draw check ─────────────────────────────────────────────────────────────────────────
def expected_draw_set(page_ids, names_by_id):
    """Listed ids that still exist, plus every layer sharing a listed layer's current name
    (QGIS draws by name, so a same-named twin always comes along — JJ 18:00: allowed)."""
    listed = {i for i in page_ids if i in names_by_id}
    names = {names_by_id[i] for i in listed}
    twins = {i for i, n in names_by_id.items() if n in names and i not in listed}
    return listed | twins, twins


def check_page(page_ids, rendered_ids, names_by_id):
    """Verdict for one page. Returns dict(ok, missing, extra, twins, deleted).

    ok is False when something draws that is not expected, or a listed layer that exists
    does not draw. Same-named twins and deleted layers never make it False on their own
    (twins warn; a deleted layer is reported by validate() and refused by the exports)."""
    expected, twins = expected_draw_set(page_ids, names_by_id)
    rendered = set(rendered_ids)
    listed_existing = {i for i in page_ids if i in names_by_id}
    missing = sorted(listed_existing - rendered)
    extra = sorted(rendered - expected)
    deleted = sorted(i for i in page_ids if i not in names_by_id)
    return {"ok": not missing and not extra, "missing": missing, "extra": extra,
            "twins": sorted(twins & rendered), "deleted": deleted}


# ── zone fingerprint ───────────────────────────────────────────────────────────────────
ZONE_DIST_M = 5.0
ZONE_AREA_FRAC = 0.02


def utm_epsg(lon, lat):
    """WGS84 UTM zone EPSG for a lon/lat (south 327xx, north 326xx)."""
    z = int(math.floor((float(lon) + 180.0) / 6.0)) % 60 + 1
    return (32700 if float(lat) < 0 else 32600) + z


def zone_matches(fp, cx, cy, area):
    """Same zone? centroid within 5 m and area within 2 % — all in metres."""
    try:
        a0 = float(fp["area"])
        d = math.hypot(float(cx) - float(fp["cx"]), float(cy) - float(fp["cy"]))
        return d <= ZONE_DIST_M and a0 > 0 and abs(float(area) - a0) <= ZONE_AREA_FRAC * a0
    except Exception:
        return False


# ── SQL (virtual page layer) ───────────────────────────────────────────────────────────
def sql_str(s):
    return "'" + str(s if s is not None else "").replace("'", "''") + "'"


def sql_ident(s):
    return '"' + str(s).replace('"', '""') + '"'


def page_layer_sql(spec, page_rows, pon_alias="pon"):
    """SQL for the virtual page layer.

    page_rows: {"overview": [(title, ids_text, note)], "pon_ids": text, "pon_note": text,
                "overrides": [(cx, cy, area, ids_text, note)], "aerial_guard": text}
    Columns: seq, is_overview, unit, page_title, page_note, page_ids, geometry.
    The override CASE measures centroid distance and area in metres after ST_Transform
    to the spec's metric EPSG, so an EPSG:4326 project never compares degrees."""
    srid = int(spec["overview_srid"])
    geom = "GeomFromText(%s, %d)" % (sql_str(spec["overview_wkt"]), srid)
    parts = []
    for i, (title, ids_text, note) in enumerate(page_rows["overview"]):
        parts.append("SELECT %d AS seq, 1 AS is_overview, %s AS unit, %s AS page_title, "
                     "%s AS page_note, %s AS page_ids, %s AS geometry"
                     % (i, sql_str("Overview"), sql_str(title), sql_str(note),
                        sql_str(ids_text), geom))
    k = len(page_rows["overview"])
    fld = sql_ident(spec["pon_label_field"]) if spec.get("pon_label_field") else "NULL"
    sfld = sql_ident(spec["pon_sort_field"]) if spec.get("pon_sort_field") else fld
    order = ("CAST(%s AS REAL), %s" % (sfld, sfld)) if spec.get("pon_sort_numeric") else sfld
    unit = "COALESCE(CAST(%s AS TEXT), '')" % fld
    m = int(spec.get("metric_epsg") or 0)
    ids_case, note_case = [], []
    for cx, cy, area, ids_text, note in page_rows.get("overrides") or []:
        cond = ("ST_Distance(ST_Transform(ST_Centroid(geometry), %d), MakePoint(%r, %r, %d)) <= %r "
                "AND abs(ST_Area(ST_Transform(geometry, %d)) - %r) <= %r"
                % (m, float(cx), float(cy), m, ZONE_DIST_M, m, float(area), ZONE_AREA_FRAC * float(area)))
        ids_case.append("WHEN %s THEN %s" % (cond, sql_str(ids_text)))
        note_case.append("WHEN %s THEN %s" % (cond, sql_str(note)))
    ids_expr = sql_str(page_rows["pon_ids"])
    note_expr = sql_str(page_rows["pon_note"])
    if ids_case and m:
        ids_expr = "CASE %s ELSE %s END" % (" ".join(ids_case), ids_expr)
        note_expr = "CASE %s ELSE %s END" % (" ".join(note_case), note_expr)
    ids_expr = "COALESCE(NULLIF(%s, ''), %s)" % (ids_expr, sql_str(page_rows["aerial_guard"]))
    parts.append("SELECT %d + ROW_NUMBER() OVER (ORDER BY %s) AS seq, 0 AS is_overview, "
                 "%s AS unit, %s || %s AS page_title, %s AS page_note, %s AS page_ids, "
                 "geometry FROM %s"
                 % (k - 1, order, unit, sql_str(spec.get("pon_title_prefix") or ""), unit,
                    note_expr, ids_expr, pon_alias))
    return " UNION ALL ".join(parts)


def map_layers_expression(guard_name):
    """Data-defined map layers: the page row's ids turned into CURRENT names when drawn
    (a rename never drops a layer), falling back to the guard layer so the list can never
    be empty — an empty list makes QGIS draw every ticked Layers-panel layer."""
    return ("coalesce(nullif(array_to_string(array_filter(array_foreach("
            "string_to_array(coalesce(attribute(@atlas_feature,'page_ids'),''),'|'),"
            "layer_property(@element,'name')), @element IS NOT NULL AND @element <> ''),'|'),''),"
            "%s)" % sql_str(guard_name))


def legend_label(friendly, total_text):
    return "%s (%s)" % (friendly, total_text) if total_text else friendly


# ── As-Built frame (JJ 2026-10-21: Lodewijk's Cradock Phase 1 As-built PDF) ─────────────
# A4 landscape. Map on top, a bottom strip on every page: "Asbuilt" + the page name and a
# north arrow | legend with feature counts | 3 x 5 facts table | logo. Measured off the PDF
# (pages 1-16 share the strip): frame 2.2 mm in, map bottom 174.0, table 134.4-240.4 x
# 175.1-205.2 in five 6 mm rows, logo box from 240.6.
ASBUILT = dict(page_w=297.0, page_h=210.0, frame_x=2.2, frame_y=2.2, frame_w=292.0, frame_h=204.9,
               map_x=2.2, map_y=2.2, map_w=292.0, map_h=171.8,
               strip_y=174.0, strip_h=33.1,
               title_x=4.0, title_y=175.5, title_w=42.0, title_h=10.0,
               north_x=6.0, north_y=186.0, north_w=11.0, north_h=15.0,
               legend_x=47.0, legend_y=175.0, legend_w=85.5, legend_h=31.2,
               table_x=134.4, table_y=175.1, table_w=106.0, table_row_h=6.02,
               table_cols=(38.6, 25.1, 42.3),
               logo_x=240.6, logo_w=53.6,
               tiein_x=10.2, tiein_y=71.5, tiein_w=60.0, tiein_h=10.0)   # under page_pictures' default slot (map + 8 mm, 80 x 60)

# Layer roles an as-built page shows, matched on the layer NAME (HeroTel names differ per
# town: 16Way_Splitter, FAP, Feeder Joints...). Each role lists keyword groups in priority
# order: the first group that matches a layer wins, so a real 1:16 splitter layer beats a
# feeder-joint layer. Every keyword is matched on the lower-cased name with "_" / "-" read as
# spaces, and also with the spaces removed ("16Way_Splitter" -> "16way splitter", "16waysplitter").
ASBUILT_ROLES = (
    # role,           geometry, keyword groups (priority order),                         exclude,                          many
    ("backhaul",      "line",  (("backhaul",), ("back haul",)),                          ("pole", "joint"),                False),
    ("feeder_link",   "line",  (("feeder link", "link fibre", "link cable"), ("link",)),  ("joint", "pole"),                False),
    ("feeder",        "line",  (("feeder",), ("primary",)),                              ("link", "joint", "pole"),        False),
    ("spur",          "line",  (("spur",),),                                             ("joint", "pole"),                False),
    ("distribution",  "line",  (("distribution",), ("dc fibre", "dc cable")),            ("spare", "joint", "spur", "pole"), True),
    ("existing_pole", "point", (("existing herotel pole", "existing ht pole", "tie in", "tie-in", "breakin", "break in"),
                                ("existing pole",)),                                    (),                               False),
    ("poles",         "point", (("pole",),),                                             ("existing", "joint"),            True),
    ("fap",           "point", (("16way", "16 way", "1:16", "1x16"), ("fap",), ("fts",), ("feeder joint",)),
                                                                                         ("link joint",),                  False),
    ("ctp",           "point", (("8way", "8 way", "1:8", "1x8"), ("ctp",), ("sts",), ("dc joint",), ("dome joint", "dome")),
                                                                                         (),                               False),
    ("units",         "point", (("demand point", "demand unit", "demand"), ("home connection", "premise")),
                                                                                         ("pole", "joint"),                False),
)
ASBUILT_LINE_ROLES = ("backhaul", "feeder_link", "feeder", "spur", "distribution")

# Legend wording off Lodewijk's sheets.
ASBUILT_LABELS = {"backhaul": "Backhaul", "feeder_link": "Feeder Link", "feeder": "Feeder",
                  "spur": "Dist Spur", "distribution": "Distribution", "existing_pole": "Existing Herotel Pole",
                  "poles": "Poles", "fap": "FAP's", "ctp": "CTP's", "pon": "PON"}


def _role_name(name):
    low = re.sub(r"[_\-]+", " ", str(name or "").lower())
    return low, low.replace(" ", "")


def _hits(name, words):
    low, tight = _role_name(name)
    return any((w in low) or (w.replace(" ", "") in tight) for w in words)


def asbuilt_roles(layers):
    """{role: [layer id, ...]} for the as-built page set.

    layers: [(id, name, kind, feature count)] in Layers-panel order (top first), book-owned
    layers already left out. A layer is taken by at most one role (the first in ASBUILT_ROLES
    that wants it). Within a role the best keyword group wins; ties go to a non-empty layer,
    then to the panel order. A role marked many keeps every layer of its best group."""
    taken, out = set(), {}
    for role, kind, groups, exclude, many in ASBUILT_ROLES:
        pick = []
        for words in groups:
            cand = [(lid, n) for lid, name, k, n in layers
                    if lid not in taken and k == kind and _hits(name, words) and not _hits(name, exclude)]
            if not cand:
                continue
            if many:
                pick = [lid for lid, _n in cand]
            else:
                full = [lid for lid, n in cand if (n or 0) > 0]
                pick = [(full or [cand[0][0]])[0]]
            break
        out[role] = pick
        taken.update(pick)
    return out


def asbuilt_default_pages(roles, pon_id, aoi_id=""):
    """(overview pages, PON-page ids, PON-page labels) for an as-built book, or None when the
    project has none of the as-built line layers (the caller then uses the standard pages).

    Page 1 Backhaul overview (only with a backhaul layer), PON overview, Feeder overview (only
    with a FAP or feeder layer), then one page per PON. The PON layer is labelled on every page
    that shows it, like Lodewijk's sheets."""
    r = {k: list(v or []) for k, v in (roles or {}).items()}
    if not any(r.get(k) for k in ASBUILT_LINE_ROLES):
        return None
    pon = [pon_id] if pon_id else []
    ov = []
    if r.get("backhaul"):
        ov.append(make_page("Backhaul Overview", r["backhaul"] + r.get("existing_pole", []) + pon, pon))
    ov.append(make_page("PON Overview", pon + ([aoi_id] if aoi_id else []), pon))
    if r.get("fap") or r.get("feeder"):
        ov.append(make_page("Feeder Overview",
                            r.get("fap", []) + r.get("feeder", []) + r.get("feeder_link", []) + pon,
                            r.get("fap", []) + pon))
    ids = []
    for k in ("distribution", "spur", "feeder", "feeder_link", "backhaul", "existing_pole",
              "poles", "ctp", "fap"):
        ids += r.get(k, [])
    ids += pon
    return ov, _uniq(ids), list(pon)


def asbuilt_count_expr(layer_ids):
    """QGIS expression: total feature count over the given layers (by id), or None."""
    ids = [i for i in _uniq(layer_ids)]
    if not ids:
        return None
    return " + ".join("aggregate(layer:=%s, aggregate:='count', expression:=1)" % sql_str(i)
                      for i in ids)


def asbuilt_in_page_expr(layer_id, transform=None):
    """QGIS expression: features of `layer_id` inside the page's own polygon. `transform` =
    (from authid, to authid) when the page layer and the counted layer differ in CRS.
    @parent is the atlas page feature, so each page counts its own PON."""
    if not layer_id:
        return None
    geom = "geometry(@parent)"
    if transform and transform[0] != transform[1]:
        geom = "transform(%s, %s, %s)" % (geom, sql_str(transform[0]), sql_str(transform[1]))
    return ("aggregate(layer:=%s, aggregate:='count', expression:=1, filter:=intersects($geometry, %s))"
            % (sql_str(layer_id), geom))


_OVERVIEW = "coalesce(attribute(@atlas_feature,'is_overview'),0) = 1"


def _with_word(word, value):
    """'Phase' + '1' -> 'Phase 1'; 'Phase' + 'Phase 1' -> 'Phase 1'."""
    v = str(value or "").strip()
    return v if v.lower().startswith(word.lower()) else ("%s %s" % (word, v)).strip()


def asbuilt_facts_rows(details, counts):
    """The 5 x 3 facts table as cell specs (the engine's _nt_cell format), in Lodewijk's order.

    details: typed values {province, area, phase, date, drawn_by, split_ratio} - plain text
    cells the operator edits in the designer. counts: {units, units_in_pon, poles, fap, ctp,
    pons} - QGIS expressions (None = layer not found: the cell stays as editable text)."""
    d = details or {}
    c = counts or {}

    def count(label, key):
        e = c.get(key)
        return {"expr": "concat(%s, %s)" % (sql_str(label), e)} if e else {"text": label}

    pon_cell = {"expr": "if(%s, 'PON', attribute(@atlas_feature,'page_title'))" % _OVERVIEW}
    if c.get("units_in_pon"):
        units_cell = {"expr": "if(%s, 'Units', concat('Units in PON: ', %s))" % (_OVERVIEW, c["units_in_pon"])}
    else:
        units_cell = {"text": "Units in PON: "}
    return [
        [{"text": "Province: %s" % (d.get("province") or "")}, {"text": "Area: %s" % (d.get("area") or "")}, pon_cell],
        [{"text": _with_word("Phase", d.get("phase"))}, count("Total PONS ", "pons"), units_cell],
        [count("Unit Count: ", "units"), count("Poles: ", "poles"), {"text": _with_word("Date", d.get("date"))}],
        [count("FAP: ", "fap"), count("CTP: ", "ctp"), {"text": "Drawn by %s" % (d.get("drawn_by") or "")}],
        [{"text": "Splitting Ratio %s" % (d.get("split_ratio") or "")}, {"text": ""}, {"text": ""}],
    ]


def asbuilt_default_details(title="", phase=None, today=""):
    """Typed details before the operator changes them. Splitting ratio = the HeroTel cascade
    measured on every delivered town (1:16 feeder then 1:8)."""
    return {"province": "", "area": str(title or ""), "phase": "" if phase is None else str(phase),
            "date": str(today or ""), "drawn_by": "", "split_ratio": "1:16-1:8"}


def format_latlon(lat, lon, dp=7):
    """'32.1739121 S, 25.6233960 E' - hemisphere letters from the signs (never a minus sign
    AND a letter, which is how Lodewijk's sheet came to read '-32.17N, 25.62S')."""
    lat, lon = float(lat), float(lon)
    if not (-90.0 <= lat <= 90.0 and -180.0 <= lon <= 180.0):
        raise ValueError("not a latitude/longitude: %r, %r" % (lat, lon))
    return "%.*f %s, %.*f %s" % (dp, abs(lat), "S" if lat < 0 else "N", dp, abs(lon), "W" if lon < 0 else "E")
