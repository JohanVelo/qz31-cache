"""self_destruct — stage 2 of the account guard: "deactivated => remove".

Stage 1 (in fiber_network_plugin._apply_deactivation) locks the tool the moment
the planning office flips a user to is_active=false: menu, toolbar and the whole
Processing provider are disabled and the lock is cached locally so it survives
restarts and going offline.

This module adds what JJ asked for: if the account STAYS deactivated for
THRESHOLD_DAYS, the installed plugin folder is removed from the machine and the
local identity/activation is wiped.

How the countdown is safe (a bug here could nuke every legit install):
  * It ONLY arms on a *confirmed* deactivation (the cached account_deactivated
    flag, which is only ever set by an explicit server `is_user_active == false`).
    Offline / unknown answers leave everything untouched (fail-open).
  * The owner's machine (admin read-key present) is ALWAYS exempt.
  * ENABLED is a global kill-switch — ship it False to disable the whole stage.
  * selfDestructTestMinutes (QgsSettings) shortens the window for a safe test on
    a throwaway, non-owner account.

Honest limits (told to JJ): this can only act on a machine that comes online at
least once AFTER deactivation (to learn it is deactivated); it removes the
installed plugin folder + local trust, but cannot recover copies the person
already made (shapefiles, exported data, a saved .zip of the plugin), and a
determined reader of this Python can disable it. Strong deterrent + clean
revoke, not a guarantee against someone who already copied the files.
"""
import os
import subprocess
import tempfile

THRESHOLD_DAYS = 3
ENABLED = True                 # global kill-switch for the whole self-destruct

# QgsSettings keys (VelocityFibre/* namespace — set by the account guard)
KEY_DEACT = "VelocityFibre/account_deactivated"           # bool — confirmed lock
KEY_DEACT_AT = "VelocityFibre/deactivatedAt"              # ISO8601 — countdown start
KEY_DONE = "VelocityFibre/selfDestructDone"               # bool — purge scheduled once
KEY_TEST_MIN = "VelocityFibre/selfDestructTestMinutes"   # optional fast-test override
KEY_ADMIN = "VelocityFibre/nexus/adminKey"               # owner marker (never ships)

# Keys wiped on purge so surviving code stays locked and a reinstall can't
# silently reuse this machine's trust.
_IDENTITY_KEYS = (
    "VelocityFibre/activation",
    "VelocityFibre/account_deactivated",
    "VelocityFibre/deactivatedAt",
    "VelocityFibre/nexus/username",
    "VelocityFibre/nexus/profile",
)


def _settings():
    from qgis.core import QgsSettings
    return QgsSettings()


def _now():
    from datetime import datetime, timezone
    return datetime.now(timezone.utc)


def _is_owner(s):
    """JJ's machine carries the admin read-key — never self-destruct the owner."""
    try:
        return bool(s.value(KEY_ADMIN, "") or "")
    except Exception:
        return False


def _threshold_seconds(s):
    try:
        m = s.value(KEY_TEST_MIN, "", type=str)
        if m:
            return max(1.0, float(m)) * 60.0     # minutes -> seconds (test mode)
    except Exception:
        pass
    return THRESHOLD_DAYS * 86400.0


def arm(s):
    """Stamp the countdown start if not already stamped. Idempotent."""
    try:
        if not s.value(KEY_DEACT_AT, "", type=str):
            s.setValue(KEY_DEACT_AT, _now().isoformat())
    except Exception:
        pass


def disarm(s):
    """Reactivated (or never deactivated) -> cancel the countdown."""
    try:
        s.remove(KEY_DEACT_AT)
        s.remove(KEY_DONE)
    except Exception:
        pass


def _elapsed_seconds(s):
    raw = s.value(KEY_DEACT_AT, "", type=str)
    if not raw:
        return None
    try:
        from datetime import datetime
        return (_now() - datetime.fromisoformat(raw)).total_seconds()
    except Exception:
        return None


def evaluate(plugin_dir, iface=None):
    """One tick of the countdown. Called from the account guard at startup, on
    every deactivation state-change, and on the 10-minute timer (which runs even
    offline). Returns a short status string for logging/tests. Never raises."""
    if not ENABLED:
        return "disabled"
    try:
        s = _settings()
        if not s.value(KEY_DEACT, False, type=bool):
            disarm(s)                              # active -> nothing pending
            return "idle"
        if _is_owner(s):
            return "owner-exempt"                  # never nuke JJ's own machine
        arm(s)
        if s.value(KEY_DONE, False, type=bool):
            return "already-scheduled"
        elapsed = _elapsed_seconds(s)
        if elapsed is None or elapsed < _threshold_seconds(s):
            return "armed"
        s.setValue(KEY_DONE, True)                 # idempotent — schedule once
        _purge(plugin_dir, iface)
        return "purged"
    except Exception:
        return "error"


def _purge(plugin_dir, iface):
    s = _settings()
    # 1. stop QGIS auto-loading us on the next launch (correct cross-version way)
    try:
        s.setValue("PythonPlugins/FiberNetworkAutomation", False)
    except Exception:
        pass
    # 2. wipe local identity / activation
    for k in _IDENTITY_KEYS:
        try:
            s.remove(k)
        except Exception:
            pass
    # 3. tell the operator (best-effort)
    if iface is not None:
        try:
            iface.messageBar().pushCritical(
                "Velocity Nexus",
                "This installation has been deactivated by the planning office "
                "and is being removed from this machine.")
        except Exception:
            pass
    # 4. schedule the folder deletion for after QGIS exits (the .py/.pyd files
    #    are in use while QGIS runs). A detached PowerShell waits on this PID.
    try:
        _schedule_folder_delete(plugin_dir)
    except Exception:
        pass


def _schedule_folder_delete(plugin_dir):
    plugin_dir = os.path.abspath(plugin_dir)
    pid = os.getpid()
    ps_path = os.path.join(tempfile.gettempdir(), "vn_cleanup.ps1")
    # Single-quote the path for PowerShell; double any embedded single quotes.
    safe = plugin_dir.replace("'", "''")
    script = (
        "$ErrorActionPreference = 'SilentlyContinue'\n"
        f"$target = '{safe}'\n"
        f"try {{ Wait-Process -Id {pid} -Timeout 1800 }} catch {{}}\n"
        "Start-Sleep -Seconds 3\n"
        "for ($i = 0; $i -lt 12; $i++) {\n"
        "  try { Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction Stop; break }\n"
        "  catch { Start-Sleep -Seconds 5 }\n"
        "}\n"
        "Remove-Item -LiteralPath $MyInvocation.MyCommand.Path -Force\n"
    )
    with open(ps_path, "w", encoding="utf-8") as f:
        f.write(script)
    DETACHED_PROCESS = 0x00000008
    CREATE_NO_WINDOW = 0x08000000
    subprocess.Popen(
        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
         "-WindowStyle", "Hidden", "-File", ps_path],
        creationflags=DETACHED_PROCESS | CREATE_NO_WINDOW,
        close_fds=True)
