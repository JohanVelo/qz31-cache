<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="4.2.0" styleCategories="Symbology|Labeling" labelsEnabled="0">
  <renderer-v2 type="singleSymbol" symbollevels="0" enableorderby="0" forceraster="0" referencescale="-1">
        <symbols>
          <symbol alpha="1" is_animated="0" force_rhr="0" type="marker" clip_to_extent="1" name="0" frame_rate="10">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" name="name" value="" />
                <Option name="properties" />
                <Option type="QString" name="type" value="collection" />
              </Option>
            </data_defined_properties>
            <layer locked="0" pass="0" class="SimpleMarker" enabled="1" id="{79949393-6ac8-452d-8d97-2f713cf669d7}">
              <Option type="Map">
                <Option type="QString" name="angle" value="0" />
                <Option type="QString" name="cap_style" value="square" />
                <Option type="QString" name="color" value="184,8,8,255,rgb:0.7215686,0.0313725,0.0313725,1" />
                <Option type="QString" name="horizontal_anchor_point" value="1" />
                <Option type="QString" name="joinstyle" value="bevel" />
                <Option type="QString" name="name" value="star" />
                <Option type="QString" name="offset" value="0,0" />
                <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" />
                <Option type="QString" name="offset_unit" value="MM" />
                <Option type="QString" name="outline_color" value="184,8,8,255,rgb:0.7215686,0.0313725,0.0313725,1" />
                <Option type="QString" name="outline_style" value="solid" />
                <Option type="QString" name="outline_width" value="0.2" />
                <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" />
                <Option type="QString" name="outline_width_unit" value="MM" />
                <Option type="QString" name="scale_method" value="area" />
                <Option type="QString" name="size" value="7.56667" />
                <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0" />
                <Option type="QString" name="size_unit" value="MM" />
                <Option type="QString" name="vertical_anchor_point" value="1" />
              </Option>
              <effect type="effectStack" enabled="1">
                <effect type="dropShadow">
                  <Option type="Map">
                    <Option type="QString" name="blend_mode" value="0" />
                    <Option type="QString" name="blur_level" value="2.645" />
                    <Option type="QString" name="blur_unit" value="MM" />
                    <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0" />
                    <Option type="QString" name="color" value="0,0,0,255,rgb:0,0,0,1" />
                    <Option type="QString" name="draw_mode" value="2" />
                    <Option type="QString" name="enabled" value="1" />
                    <Option type="QString" name="offset_angle" value="135" />
                    <Option type="QString" name="offset_distance" value="2" />
                    <Option type="QString" name="offset_unit" value="MM" />
                    <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0" />
                    <Option type="QString" name="opacity" value="1" />
                  </Option>
                </effect>
                <effect type="drawSource">
                  <Option type="Map">
                    <Option type="QString" name="blend_mode" value="0" />
                    <Option type="QString" name="draw_mode" value="2" />
                    <Option type="QString" name="enabled" value="1" />
                    <Option type="QString" name="opacity" value="1" />
                  </Option>
                </effect>
              </effect>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" name="name" value="" />
                  <Option name="properties" />
                  <Option type="QString" name="type" value="collection" />
                </Option>
              </data_defined_properties>
            </layer>
            <layer locked="0" pass="0" class="SimpleMarker" enabled="1" id="{938366c6-0fb5-45d7-b6a2-d94bf4c83de8}">
              <Option type="Map">
                <Option type="QString" name="angle" value="34" />
                <Option type="QString" name="cap_style" value="square" />
                <Option type="QString" name="color" value="255,0,0,255,rgb:1,0,0,1" />
                <Option type="QString" name="horizontal_anchor_point" value="1" />
                <Option type="QString" name="joinstyle" value="bevel" />
                <Option type="QString" name="name" value="star" />
                <Option type="QString" name="offset" value="0,0" />
                <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" />
                <Option type="QString" name="offset_unit" value="MM" />
                <Option type="QString" name="outline_color" value="255,0,0,255,rgb:1,0,0,1" />
                <Option type="QString" name="outline_style" value="solid" />
                <Option type="QString" name="outline_width" value="0.2" />
                <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" />
                <Option type="QString" name="outline_width_unit" value="MM" />
                <Option type="QString" name="scale_method" value="area" />
                <Option type="QString" name="size" value="7.6" />
                <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0" />
                <Option type="QString" name="size_unit" value="MM" />
                <Option type="QString" name="vertical_anchor_point" value="1" />
              </Option>
              <effect type="effectStack" enabled="0">
                <effect type="drawSource">
                  <Option type="Map">
                    <Option type="QString" name="blend_mode" value="0" />
                    <Option type="QString" name="draw_mode" value="2" />
                    <Option type="QString" name="enabled" value="1" />
                    <Option type="QString" name="opacity" value="1" />
                  </Option>
                </effect>
              </effect>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" name="name" value="" />
                  <Option name="properties" />
                  <Option type="QString" name="type" value="collection" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </symbols>
        <rotation />
        <sizescale />
        <data-defined-properties>
          <Option type="Map">
            <Option type="QString" name="name" value="" />
            <Option name="properties" />
            <Option type="QString" name="type" value="collection" />
          </Option>
        </data-defined-properties>
      </renderer-v2>
</qgis>
