"""Associations check — the measurement core behind the Velocity Nexus "Associations" panel.

JJ, 2026-10-14: "checks your snaps on drops and poles, and also drop to demand point
centroids ... it needs to check that you snapped on the pole centroid within a radius of
1 meter or you can change it ... and it needs to flag where you did not snap to a layer".

Every drop should run from a pole (or an anchor: a splitter / joint layer drops are meant
to end on) to a home (a demand-point centroid), in either direction. This module reads
drop, spare-drop, pole, anchor, demand and other point layers and says, for a radius R,
which drops and which drop ENDS break that rule.

READ-ONLY. Nothing here opens an edit session, writes a feature or touches a renderer.

Rules (plan rev 7, section "What it checks"; the frozen numpy oracle in
research/associations/frozen/baseline_measure.py implements the same rules):

  network end  an end within R of a point on a ticked pole or anchor layer
  home end     an end within R of a demand centroid
  nearest wins an end within R of both is a network end when its nearest network point
               is no farther than its nearest home; otherwise it is a home end
  per drop     INVALID (null / empty / < 2 vertices) · NO_POLE (A1) · BOTH_POLE (A4,
               flag: any home within R of either end, measured BEFORE nearest-wins) ·
               NO_HOME (A2) · GOOD (split on pole / on anchor)
  per end      UNSNAPPED (A3; on_other when an unticked point layer sits there) ·
               STACKED (A5: pole end with 2+ deduped poles within R, anchors never count)
               · NEAR_MISS (A6: network end > 1 mm from its nearest network point)
  per home     A7: no home end within R, or home ends of 2+ different drops
  spare drops  exactly one network end = OK, none = NO_POLE, both = BOTH_POLE

Distances are WGS84 ellipsoid metres (QgsDistanceArea built on the main thread and passed
in). Candidates are found with QgsSpatialIndex in EPSG:4326 degrees, using a box that is
never smaller than R in any direction (1 % margin over the smallest metres-per-degree), so
the index can only return too many candidates, never too few.

Threading: build every input with :func:`layer_input` on the MAIN thread (feature source
+ coordinate transform), then call :func:`build_cache` from a worker. The worker never
touches QgsProject or a live layer.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsDistanceArea,
    QgsFeatureRequest,
    QgsPointXY,
    QgsRectangle,
    QgsSpatialIndex,
    QgsWkbTypes,
)

RADIUS_MIN = 0.01
RADIUS_MAX = 5.0
DEFAULT_RADIUS = 1.0
EPS_M = 1e-3                       # near-miss and pole-dedupe tolerance (1 mm)
ANCHOR_SHARE = 0.10                # pre-tick an anchor layer at >= 10 % of non-home ends
ANCHOR_PROBE_M = 1.0               # anchor shares are measured once, at 1 m
ANCHOR_MAX_FEATURES = 200_000      # a bigger candidate layer is skipped, never pre-ticked
PAGE = 2_000                       # rows / rings shown per page
LIVE_MAX_DROPS = 50_000            # live re-check switches off above this
ASK_ABOVE_HOMES = 200_000          # Run asks first above this many demand features

_M_PER_DEG_LAT_MIN = 110_574.0     # meridional degree at the equator (the shortest)
_M_PER_DEG_LON_EQ = 111_319.49     # pi/180 * a; the true value is larger off the equator
_BOX_MARGIN = 1.01

FAIL, WARN, INFO = "FAIL", "WARN", "INFO"
CLASSES = ("INVALID", "NO_POLE", "BOTH_POLE", "NO_HOME", "GOOD")
SPARE_CLASSES = ("OK", "NO_POLE", "BOTH_POLE", "INVALID")


class Cancelled(Exception):
    """The worker saw the cancel flag."""


class ScanRefused(Exception):
    """A precondition failed; the message is shown to the operator as is."""


def clamp_radius(value):
    """``(radius, message)`` — the radius inside 0.01..5 m, and why it moved (or None)."""
    try:
        r = float(value)
    except (TypeError, ValueError):
        return DEFAULT_RADIUS, f"'{value}' is not a number: radius set to {DEFAULT_RADIUS:g} m"
    if not math.isfinite(r):
        return DEFAULT_RADIUS, f"radius must be a number: set to {DEFAULT_RADIUS:g} m"
    if r < RADIUS_MIN:
        return RADIUS_MIN, f"smallest radius is {RADIUS_MIN:g} m"
    if r > RADIUS_MAX:
        return RADIUS_MAX, f"largest radius is {RADIUS_MAX:g} m"
    return r, None


def wgs84_measurer():
    """A QgsDistanceArea in EPSG:4326 on the WGS84 ellipsoid, proven to measure metres.

    Built on the main thread and handed to the worker. Never reads the project
    ellipsoid: a project set to 'NONE' would make every distance come back in degrees
    (incident 2026-07-15).
    """
    da = QgsDistanceArea()
    from qgis.core import QgsCoordinateTransformContext
    da.setSourceCrs(QgsCoordinateReferenceSystem("EPSG:4326"), QgsCoordinateTransformContext())
    da.setEllipsoid("WGS84")
    if not da.willUseEllipsoid():
        raise ScanRefused("could not set up WGS84 distance measuring")
    return da


# ── pickers: which layer plays which part (pure, by name + geometry + role) ──────────

POLE_ROLES = ("pole", "distribution_pole", "feeder_pole")
DEMAND_ROLES = ("demand_point", "ont", "home_connection")
DROP_ROLES = ("drop_cable",)
SPARE_ROLES = ("spare_drop_cable",)
_DEMAND_PARTS = ("demand", "home connection", "centroid")


def _is_demand_name(name):
    """Demand Points / Demand Units / Demand_Points… / Home Connection / centroids, or the
    whole word ONT (never 'Frontage' or 'Monte')."""
    w = " " + name.lower().replace("_", " ") + " "
    return any(p in w for p in _DEMAND_PARTS) or " ont " in w


def pick_layers(infos, role_of=None):
    """Sort layers into the panel's pickers. ``infos`` = ``[(layer_id, name, kind)]`` with
    kind "point" / "line" / "polygon"; ``role_of(name)`` is the shared resolver or None.

    Returns ``{"drops", "spares", "poles", "demand", "demand_auto", "others"}`` (lists of
    ids, project order; ``demand`` role-matched first; ``demand_auto`` set only when exactly
    one demand-type layer exists; ``others`` = remaining point layers = anchor candidates).
    """
    def role(n):
        try:
            return role_of(n) if role_of else None
        except Exception:                              # the resolver never blocks a pick
            return None

    out = {"drops": [], "spares": [], "poles": [], "demand": [], "demand_auto": None,
           "others": []}
    demand_role, demand_name = [], []
    for lid, name, kind in infos:
        r, low = role(name), name.lower()
        if kind == "line":
            if r in SPARE_ROLES or "spare" in low:
                out["spares"].append(lid)
            elif r in DROP_ROLES or "drop" in low:
                out["drops"].append(lid)
            continue
        if kind == "point" and (r in POLE_ROLES or "pole" in low):
            out["poles"].append(lid)
            continue
        if kind in ("point", "polygon"):
            if r in DEMAND_ROLES:
                demand_role.append(lid)
                continue
            if _is_demand_name(name):
                demand_name.append(lid)
                continue
        if kind == "point":
            out["others"].append(lid)
    out["demand"] = demand_role + demand_name
    if len(out["demand"]) == 1:
        out["demand_auto"] = out["demand"][0]
    return out


# ── inputs (built on the main thread) ────────────────────────────────────────────────

@dataclass
class LayerInput:
    """One layer, ready to be read off the main thread."""

    layer_id: str
    name: str
    source: object                       # QgsVectorLayerFeatureSource or any .getFeatures()
    transform: object                    # QgsCoordinateTransform to EPSG:4326, or None
    feature_count: int = -1
    filter_rect: object = None           # optional QgsRectangle in layer CRS

    def features(self):
        req = QgsFeatureRequest().setNoAttributes()
        if self.filter_rect is not None:
            req.setFilterRect(self.filter_rect)
        for f in self.source.getFeatures(req):
            yield f.id(), f.geometry()

    def to_ll(self, x, y):
        if self.transform is None:
            return x, y
        p = self.transform.transform(QgsPointXY(x, y))
        return p.x(), p.y()


def layer_input(layer, project):
    """MAIN THREAD ONLY. Feature source + transform for one layer, or ScanRefused."""
    from qgis.core import QgsVectorLayerFeatureSource
    crs = layer.crs()
    if not crs.isValid():
        raise ScanRefused(f"'{layer.name()}' has no valid CRS: set one, then run again")
    wgs = QgsCoordinateReferenceSystem("EPSG:4326")
    tr = None
    if crs.authid() != "EPSG:4326":
        tr = QgsCoordinateTransform(crs, wgs, project.transformContext())
    return LayerInput(layer.id(), layer.name(), QgsVectorLayerFeatureSource(layer), tr,
                      int(layer.featureCount()))


# ── geometry helpers ─────────────────────────────────────────────────────────────────

def line_ends(geom):
    """``(start_xy, end_xy, multipart)`` in the layer CRS, or None when invalid.

    Multipart: start of the first part, end of the last. Invalid = null, empty, or fewer
    than 2 vertices in total (a 2-part drop of one vertex each still has two ends).
    """
    if geom is None or geom.isNull() or geom.isEmpty():
        return None
    g = geom.constGet()
    parts = []
    if QgsWkbTypes.isMultiType(g.wkbType()):
        parts = [g.geometryN(i) for i in range(g.numGeometries())]
    else:
        parts = [g]
    parts = [p for p in parts if p is not None]
    if not parts or not all(hasattr(p, "startPoint") for p in (parts[0], parts[-1])):
        return None
    a, b = parts[0], parts[-1]
    n = a.numPoints() + (b.numPoints() if len(parts) > 1 else 0)
    if n < 2 or a.numPoints() == 0 or b.numPoints() == 0:
        return None
    s = a.startPoint()
    e = b.endPoint()
    return (s.x(), s.y()), (e.x(), e.y()), len(parts) > 1


_SINGLE_POINT = frozenset((QgsWkbTypes.Type.Point, QgsWkbTypes.Type.PointZ,
                           QgsWkbTypes.Type.PointM, QgsWkbTypes.Type.PointZM,
                           QgsWkbTypes.Type.Point25D))


def point_of(geom):
    """The point a feature stands for: the point itself, else its centroid. None if empty."""
    if geom is None:
        return None
    # Fast path for a plain point: one type test instead of ~8 calls. Called once per
    # candidate point, i.e. 2,000,000 times in the AC7 anchor pass. Same answer as the
    # general path below (null / empty / non-finite -> None), proven 2026-10-19.
    if geom.wkbType() in _SINGLE_POINT:
        q = geom.asPoint()
        x, y = q.x(), q.y()
        return (x, y) if (x - x == 0 and y - y == 0) else None
    if geom.isNull() or geom.isEmpty():
        return None
    if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.GeometryType.PointGeometry \
            and not geom.isMultipart():
        p = geom.asPoint()
    else:
        c = geom.centroid()
        if c is None or c.isEmpty():
            return None
        p = c.asPoint()
    if not (math.isfinite(p.x()) and math.isfinite(p.y())):
        return None
    return p.x(), p.y()


def drop_key(s, e):
    return f"{s[0]:.9f},{s[1]:.9f}|{e[0]:.9f},{e[1]:.9f}"


def _half(lat, r_m):
    """Half-width (lon, lat degrees) of a box that holds every point within r_m metres."""
    c = max(math.cos(math.radians(lat)), 1e-6)
    return (r_m * _BOX_MARGIN / (_M_PER_DEG_LON_EQ * c) + 1e-12,
            r_m * _BOX_MARGIN / _M_PER_DEG_LAT_MIN + 1e-12)


def _box(lon, lat, r_m):
    dx, dy = _half(lat, r_m)
    return QgsRectangle(lon - dx, lat - dy, lon + dx, lat + dy)


# ── point groups ─────────────────────────────────────────────────────────────────────

@dataclass
class PointGroup:
    """All points of one kind (poles merged over layers, anchors, demand, others)."""

    kind: str
    ll: list = field(default_factory=list)          # (lon, lat)
    layer: list = field(default_factory=list)       # layer name per point
    fid: list = field(default_factory=list)
    key: list = field(default_factory=list)         # "x,y" 9 dp, layer CRS (demand)
    index: object = None
    deduped: int = 0
    indexed: int = 0                                # points [0, indexed) are in `index`

    def add(self, lon, lat, layer_name, fid, key=None):
        i = len(self.ll)
        self.ll.append((lon, lat))
        self.layer.append(layer_name)
        self.fid.append(fid)
        self.key.append(key)
        return i

    def ensure_index(self):
        """The spatial index, caught up with every point added so far; None when empty.

        Points are indexed in one tight loop on the first query after they were added,
        not one by one inside add(): 200,000 polygon homes spent ~12 s of their 18.6 s
        read in per-point index inserts (2026-10-19). Pole de-duplication queries after
        every add, so poles still go in one at a time, exactly as before. build_cache()
        calls this for every group, so the catch-up never lands on the main thread.
        """
        n = len(self.ll)
        if self.indexed < n:
            if self.index is None:
                self.index = QgsSpatialIndex()
            put, rect, ll = self.index.addFeature, QgsRectangle, self.ll
            for i in range(self.indexed, n):
                lon, lat = ll[i]
                put(i, rect(lon, lat, lon, lat))
            self.indexed = n
        return self.index

    def within(self, qp, r_m, da):
        """``[(metres, i)]`` for every point within r_m of qp, nearest first."""
        index = self.ensure_index()
        if index is None:
            return ()                  # the shared empty tuple: no tracked list per end
        out = []
        for i in index.intersects(_box(qp.x(), qp.y(), r_m)):
            d = da.measureLine(qp, QgsPointXY(*self.ll[i]))
            if d <= r_m:
                out.append((d, i))
        out.sort()
        return tuple(out)

    def nearest(self, qp, da, k=8):
        """``(metres, i)`` of the nearest point (display only), or (inf, None)."""
        index = self.ensure_index()
        if index is None:
            return math.inf, None
        best = (math.inf, None)
        for i in index.nearestNeighbor(qp, k):
            d = da.measureLine(qp, QgsPointXY(*self.ll[i]))
            if d < best[0]:
                best = (d, i)
        return best


def _check(cancel):
    if cancel is not None and cancel():
        raise Cancelled()


def read_points(group, inp, da, cancel=None, dedupe_m=None, with_keys=False):
    """Append one layer's points to ``group``. Poles pass dedupe_m=EPS_M."""
    for n, (fid, geom) in enumerate(inp.features()):
        if n % 2000 == 0:
            _check(cancel)
        p = point_of(geom)
        if p is None:
            continue
        lon, lat = inp.to_ll(*p)
        if dedupe_m is not None and group.within(QgsPointXY(lon, lat), dedupe_m, da):
            group.deduped += 1
            continue
        key = f"{p[0]:.9f},{p[1]:.9f}" if with_keys else None
        group.add(lon, lat, inp.name, fid, key)


# ── the cache: everything distance-related, measured once at the scan radius ─────────

# One drop end is a PLAIN TUPLE, indexed by the names below:
#   (xy layer CRS, (lon, lat), poles, anchors, homes, others)
# each hit list a tuple of (metres, index) within the scan radius, nearest first.
# Not an object on purpose: the collector untracks a plain tuple that holds only numbers,
# but walks every class instance on every full pass. A 63,000-drop cache of End objects
# was ~250,000 tracked objects; full passes then held the GIL (and froze the canvas) for
# up to 0.46 s each, several times per scan.
XY, LL, POLES, ANCHORS, HOMES, OTHERS = range(6)
SLOT_OF = {"pole": POLES, "anchor": ANCHORS, "demand": HOMES, "other": OTHERS}


def new_end(xy, ll):
    return (xy, ll, (), (), (), ())


def end_qp(end):
    return QgsPointXY(*end[LL])


def with_slot(end, slot, hits):
    """A copy of ``end`` with one hit list replaced."""
    return end[:slot] + (hits,) + end[slot + 1:]


class DropTable:
    """Every drop (or spare drop) of one scan, stored as columns.

    Columns, not one object per drop, for the same reason an end is a tuple: 63,000 Drop
    objects were 63,000 more objects for every full garbage-collector pass to walk, and
    enough new long-lived objects to trigger extra full passes during each scan. The
    columns hold only strings, ints and untracked tuples. Indexing or iterating hands out
    :class:`Drop` views, made on the spot and meant to be let go straight away."""

    def __init__(self, spare=False):
        self.spare = spare
        self.layer_id, self.layer_name, self.fid, self.key, self.ends = [], [], [], [], []

    def append(self, layer_id, layer_name, fid, key, ends):
        self.layer_id.append(layer_id)
        self.layer_name.append(layer_name)
        self.fid.append(fid)
        self.key.append(key)
        self.ends.append(ends)

    def columns(self):
        return [self.layer_id, self.layer_name, self.fid, self.key, self.ends]

    def __len__(self):
        return len(self.fid)

    def __getitem__(self, i):
        n = len(self.fid)
        if i < 0:
            i += n
        if not 0 <= i < n:
            raise IndexError(i)
        return Drop(self, i)

    def __iter__(self):
        return (Drop(self, i) for i in range(len(self.fid)))


class Drop:
    """A view of one row of a :class:`DropTable`; ``key`` and ``ends`` write through.
    ``ends`` is (start end, end end) as end tuples, or None when the drop is invalid."""

    __slots__ = ("table", "index")

    def __init__(self, table, index):
        self.table, self.index = table, index

    layer_id = property(lambda self: self.table.layer_id[self.index])
    layer_name = property(lambda self: self.table.layer_name[self.index])
    fid = property(lambda self: self.table.fid[self.index])
    spare = property(lambda self: self.table.spare)

    @property
    def key(self):
        return self.table.key[self.index]

    @key.setter
    def key(self, value):
        self.table.key[self.index] = value

    @property
    def ends(self):
        return self.table.ends[self.index]

    @ends.setter
    def ends(self, value):
        self.table.ends[self.index] = value


@dataclass
class Cache:
    radius: float
    drops: DropTable
    spares: DropTable
    poles: PointGroup
    anchors: PointGroup
    demand: PointGroup
    others: PointGroup
    da: object
    multipart: int = 0
    anchor_share: dict = field(default_factory=dict)
    anchor_skipped: list = field(default_factory=list)


def _measured(end, cache, r_m):
    """``end`` with every hit list measured at r_m."""
    da, qp = cache.da, end_qp(end)
    return (end[XY], end[LL], cache.poles.within(qp, r_m, da),
            cache.anchors.within(qp, r_m, da), cache.demand.within(qp, r_m, da),
            cache.others.within(qp, r_m, da))


def _read_lines(inps, spare, cancel, progress, seen, counter):
    out, multipart = DropTable(spare), 0
    for inp in inps:
        for fid, geom in inp.features():
            counter[0] += 1
            if counter[0] % 1000 == 0:
                _check(cancel)
                if progress:
                    progress(counter)
            idx = len(out)
            ends = line_ends(geom)
            if ends is None:
                out.append(inp.layer_id, inp.name, fid, f"INVALID#{idx}", None)
                continue
            s, e, mp = ends
            multipart += mp
            k = drop_key(s, e)
            seen[k] = seen.get(k, 0) + 1
            if seen[k] > 1:
                k = f"{k}~{seen[k]}"
            ls, le = inp.to_ll(*s), inp.to_ll(*e)
            out.append(inp.layer_id, inp.name, fid, k, (new_end(s, ls), new_end(e, le)))
    return out, multipart


def build_cache(drops, spares, poles, anchors, demand, others, da, radius,
                anchor_candidates=(), cancel=None, progress=None):
    """WORKER-SAFE. Read every input and measure every drop end once, at ``radius``.

    ``drops`` / ``spares`` / ``poles`` / ``anchors`` / ``others`` are lists of
    :class:`LayerInput`; ``demand`` is one LayerInput. ``anchor_candidates`` are
    LayerInputs whose anchor share is measured (pre-tick rule) — never the demand layer.
    ``cancel()`` returning True stops the work (raises Cancelled); ``progress(fraction)``
    gets 0..1.
    """
    radius, _ = clamp_radius(radius)
    total = sum(max(i.feature_count, 0) for i in (*drops, *spares)) or 1

    def prog(counter):
        if progress:
            progress(min(0.5, 0.5 * counter[0] / total))

    pg, ag, dg, og = (PointGroup("pole"), PointGroup("anchor"), PointGroup("demand"),
                      PointGroup("other"))
    for inp in poles:
        read_points(pg, inp, da, cancel, dedupe_m=EPS_M)
    for inp in anchors:
        read_points(ag, inp, da, cancel)
    if demand is not None:
        read_points(dg, demand, da, cancel, with_keys=True)
    for inp in others:
        read_points(og, inp, da, cancel)
    seen, counter = {}, [0]
    dlist, mp = _read_lines(drops, False, cancel, prog, seen, counter)
    slist, _ = _read_lines(spares, True, cancel, prog, {}, counter)
    for g in (pg, ag, dg, og):
        g.ensure_index()                     # here, in the worker: never on the main thread
    cache = Cache(radius, dlist, slist, pg, ag, dg, og, da, mp)
    total, n = max(len(dlist) + len(slist), 1), 0
    for col in (dlist.ends, slist.ends):     # by column: no Drop views held while measuring
        for i, ends in enumerate(col):
            n += 1
            if n % 250 == 0:
                _check(cancel)
                if progress:
                    progress(0.5 + 0.45 * n / total)
            if ends:
                col[i] = (_measured(ends[0], cache, radius), _measured(ends[1], cache, radius))
    if anchor_candidates:
        measure_anchor_shares(cache, anchor_candidates, cancel)
    if progress:
        progress(1.0)
    return cache


def measure_anchor_shares(cache, candidates, cancel=None):
    """Share of NON-HOME drop ends (nearest home > 1 m) within 1 m of each candidate layer.

    The non-home ends are indexed once and each candidate layer is streamed past them,
    so 20 layers x 100,000 points cost one index of ~12,000 ends, not 20 big indexes.
    """
    da = cache.da
    nonhome = []
    for d in cache.drops:
        if not d.ends:
            continue
        for e in d.ends:
            near = cache.demand.within(end_qp(e), ANCHOR_PROBE_M, da)
            if not near:
                nonhome.append(e)
    cache.anchor_share, cache.anchor_skipped = {}, []
    if not nonhome:
        return
    # A dict grid, not a spatial index: millions of candidate points each cost one tuple
    # lookup instead of an index query. A cell is at least the probe box on both axes
    # (lon sized at the highest |lat| present), so the 3 x 3 cells around a point hold every
    # end within the probe; the exact metre check below decides.
    min_c = max(min(math.cos(math.radians(e[LL][1])) for e in nonhome), 1e-6)
    cy = ANCHOR_PROBE_M * _BOX_MARGIN / _M_PER_DEG_LAT_MIN
    cx = ANCHOR_PROBE_M * _BOX_MARGIN / (_M_PER_DEG_LON_EQ * min_c)
    # `reach` is the grid pre-expanded to the 3 x 3 neighbourhood: each cell lists every end
    # in it or next to it, so a candidate point costs ONE dict lookup instead of nine. An end
    # sits in one cell, so no index appears twice in a list.
    reach = {}
    for i, e in enumerate(nonhome):
        gx, gy = math.floor(e[LL][0] / cx), math.floor(e[LL][1] / cy)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                reach.setdefault((gx + dx, gy + dy), []).append(i)
    nq = [end_qp(e) for e in nonhome]
    floor, get = math.floor, reach.get
    for inp in candidates:
        if inp.feature_count > ANCHOR_MAX_FEATURES:
            cache.anchor_skipped.append(inp.name)
            continue
        hit = set()
        for n, (_fid, geom) in enumerate(inp.features()):
            if n % 2000 == 0:
                _check(cancel)
            p = point_of(geom)
            if p is None:
                continue
            lon, lat = inp.to_ll(*p)
            near = get((floor(lon / cx), floor(lat / cy)))
            if not near:
                continue
            qp = QgsPointXY(lon, lat)
            for i in near:
                if i not in hit and da.measureLine(qp, nq[i]) <= ANCHOR_PROBE_M:
                    hit.add(i)
        cache.anchor_share[inp.name] = round(len(hit) / len(nonhome), 4)


def pre_ticked(anchor_share):
    """Anchor layer names to pre-tick: share >= 10 %, in name order."""
    return sorted(n for n, s in anchor_share.items() if s >= ANCHOR_SHARE)


def remeasure_drops(cache, changed):
    """Live re-check: re-measure the ends of the given drops ``[(Drop, geometry, inp)]``.

    Keys are rebuilt afterwards so "~2" suffixes stay in feature order.
    """
    for drop, geom, inp in changed:
        ends = line_ends(geom)
        if ends is None:
            drop.ends = None
            continue
        s, e, _mp = ends
        ls, le = inp.to_ll(*s), inp.to_ll(*e)
        drop.ends = (_measured(new_end(s, ls), cache, cache.radius),
                     _measured(new_end(e, le), cache, cache.radius))
    rekey(cache)


def rekey(cache):
    for group in (cache.drops, cache.spares):
        seen = {}
        for i, d in enumerate(group):
            if not d.ends:
                d.key = f"INVALID#{i}"
                continue
            k = drop_key(d.ends[0][XY], d.ends[1][XY])
            seen[k] = seen.get(k, 0) + 1
            d.key = k if seen[k] == 1 else f"{k}~{seen[k]}"


_INCREMENTAL_MAX = 200             # more changed points than this: re-measure every end


def _changed_points(old, new):
    """Positions of points that differ between two reads of a group (moved, added,
    removed, or a different layer / fid / key at that spot), plus ``old index -> new
    index`` for the points that did not change. None when there is no old group."""
    if old is None:
        return None, None
    ident_old = list(zip(old.ll, old.layer, old.fid, old.key))
    ident_new = list(zip(new.ll, new.layer, new.fid, new.key))
    slots = {}
    for i, t in enumerate(ident_new):
        slots.setdefault(t, []).append(i)
    remap, changed, used = {}, set(), {}
    for i, t in enumerate(ident_old):
        k = used.get(t, 0)
        pool = slots.get(t, ())
        if k < len(pool):
            remap[i] = pool[k]
            used[t] = k + 1
        else:
            changed.add(t[0])
    for t, pool in slots.items():
        if used.get(t, 0) < len(pool):
            changed.add(t[0])
    return changed, remap


def remeasure_points(cache, kind, inputs, cancel=None):
    """Live re-check after a pole / anchor / demand / other layer changed: re-read that
    group, then re-measure only the ends whose search box holds a point that moved,
    appeared or vanished; every other end keeps its distances (indices remapped). The
    result equals re-measuring every end."""
    group = PointGroup(kind)
    for inp in inputs:
        read_points(group, inp, cache.da, cancel, dedupe_m=EPS_M if kind == "pole" else None,
                    with_keys=(kind == "demand"))
    group.ensure_index()                     # same thread as the read, as before
    attr ={"pole": "poles", "anchor": "anchors", "demand": "demand", "other": "others"}[kind]
    old = getattr(cache, attr, None)
    setattr(cache, attr, group)
    slot = SLOT_OF[kind]
    changed, remap = _changed_points(old, group)
    full = changed is None or len(changed) > _INCREMENTAL_MAX
    r = cache.radius

    def redo(e):
        if not full:
            lon, lat = e[LL]
            dx, dy = _half(lat, r)
            if not any(abs(x - lon) <= dx and abs(y - lat) <= dy for x, y in changed):
                return with_slot(e, slot, tuple(sorted((m, remap[i]) for m, i in e[slot])))
        return with_slot(e, slot, group.within(end_qp(e), r, cache.da))

    for d in (*cache.drops, *cache.spares):
        if d.ends:
            d.ends = (redo(d.ends[0]), redo(d.ends[1]))


# ── classification: pure Python over the cache, any radius <= cache.radius ──────────

def _first(lst, r):
    return lst[0][0] if lst and lst[0][0] <= r else math.inf


def _count(lst, r):
    n = 0
    for d, _i in lst:
        if d > r:
            break
        n += 1
    return n


def classify(cache, radius):
    """Verdicts at ``radius`` (must be <= the scan radius). Returns a result dict whose
    counts and keyed sets use the oracle's names, plus ``rows`` for the panel."""
    r, _ = clamp_radius(radius)
    if r > cache.radius + 1e-12:
        raise ValueError(f"radius {r} m is above the scanned {cache.radius} m: rescan")
    cls = dict.fromkeys(CLASSES, 0)
    bad = {}
    flags = {k: [] for k in ("unsnapped", "on_other", "stacked", "near_miss")}
    served = {}
    both_no_home, good_on_anchor, rows = [], [], []
    for idx, d in enumerate(cache.drops):
        if not d.ends:
            cls["INVALID"] += 1
            bad.setdefault("INVALID", []).append(d.key)
            rows.append(_row(FAIL, "broken geometry", d, None, None, cache))
            continue
        is_net, is_pole, is_home, raw_home, end_rows = [], [], [], [], []
        for tag, e in zip(("start", "end"), d.ends):
            dp, da_, dd = _first(e[POLES], r), _first(e[ANCHORS], r), _first(e[HOMES], r)
            p, h = dp <= r, dd <= r
            n = p or da_ <= r
            raw_home.append(h)
            if n and h and min(dp, da_) > dd:
                n = p = False
            elif n and h:
                h = False
            is_net.append(n)
            is_pole.append(p)
            is_home.append(h)
            ekey = f"{d.key}#{tag}"
            if not n and not h:
                flags["unsnapped"].append(ekey)
                other = [cache.others.layer[i] for dist, i in e[OTHERS] if dist <= r]
                if other:
                    flags["on_other"].append(ekey)
                end_rows.append((FAIL, "not snapped", tag, other[0] if other else None))
            if p and _count(e[POLES], r) >= 2:
                flags["stacked"].append(ekey)
                end_rows.append((WARN, "stacked poles", tag, None))
            if n and min(dp, da_) > EPS_M:
                flags["near_miss"].append(ekey)
                end_rows.append((INFO, "near-miss", tag, None))
            if h:
                for dist, j in e[HOMES]:
                    if dist > r:
                        break
                    served.setdefault(j, set()).add(idx)
        k = sum(is_net)
        if k == 0:
            c = "NO_POLE"
        elif k == 2:
            c = "BOTH_POLE"
            if not any(raw_home):
                both_no_home.append(d.key)
        else:
            net_i = 0 if is_net[0] else 1
            c = "GOOD" if is_home[1 - net_i] else "NO_HOME"
            if c == "GOOD" and not is_pole[net_i]:
                good_on_anchor.append(d.key)
        cls[c] += 1
        if c != "GOOD":
            bad.setdefault(c, []).append(d.key)
        if c == "NO_POLE":
            rows.append(_row(FAIL, "no pole", d, "start", None, cache))
        elif c == "NO_HOME":
            rows.append(_row(FAIL, "no home", d, "end" if is_net[0] else "start", None, cache))
        elif c == "BOTH_POLE":
            note = "home within R" if any(raw_home) else "no home"
            rows.append(_row(WARN, f"pole at both ends · {note}", d, None, None, cache))
        for level, what, tag, other in end_rows:
            rows.append(_row(level, what, d, tag, other, cache))
    sp, sp_bad = dict.fromkeys(SPARE_CLASSES, 0), {}
    for d in cache.spares:
        if not d.ends:
            c = "INVALID"
        else:
            n = sum(_first(e[POLES], r) <= r or _first(e[ANCHORS], r) <= r for e in d.ends)
            c = "OK" if n == 1 else ("NO_POLE" if n == 0 else "BOTH_POLE")
        sp[c] += 1
        if c != "OK":
            sp_bad.setdefault(c, []).append(d.key)
            rows.append(_row(FAIL if c != "BOTH_POLE" else WARN, f"spare {c.lower().replace('_', ' ')}",
                             d, None, None, cache))
    dkeys = cache.demand.key
    zero = [dkeys[j] for j in range(len(dkeys)) if j not in served]
    multi = [dkeys[j] for j, v in served.items() if len(v) > 1]
    order = {FAIL: 0, WARN: 1, INFO: 2}
    rows.sort(key=lambda x: (order[x["level"]], x["what"], x["key"]))
    for j in range(len(dkeys)):
        if j not in served:
            rows.append(_home_row(WARN, "home with no drop", cache, j))
    for j, v in served.items():
        if len(v) > 1:
            rows.append(_home_row(WARN, f"home with {len(v)} drops", cache, j))
    # Page 1 is filled here, off the main thread, for both views the panel offers (INFO
    # near-misses shown or hidden); later pages are filled when they are opened.
    fill_rows(rows[:PAGE], cache)
    fill_rows([x for x in rows if x["level"] != INFO][:PAGE], cache)
    return {
        "radius": r,
        "classes": cls, "class_sum_ok": sum(cls.values()) == len(cache.drops),
        "unsnapped_ends": len(flags["unsnapped"]),
        "unsnapped_on_other_layer": len(flags["on_other"]),
        "stacked_pole_ends": len(flags["stacked"]),
        "near_miss_pole_ends": len(flags["near_miss"]),
        "both_pole_without_home": len(both_no_home),
        "good_on_anchor": len(good_on_anchor),
        "demand_zero_drops": len(zero), "demand_multi_drops": len(multi), "spare": sp,
        "sets": {"non_good_drops_by_class": {k: sorted(v) for k, v in sorted(bad.items())},
                 "end_flags": {k: sorted(v) for k, v in flags.items()},
                 "both_pole_without_home": sorted(both_no_home),
                 "good_on_anchor": sorted(good_on_anchor),
                 "demand_zero_drops": sorted(zero), "demand_multi_drops": sorted(multi),
                 "spare_non_ok": {k: sorted(v) for k, v in sorted(sp_bad.items())}},
        "rows": rows,
    }


def _row(level, what, d, tag, other, cache):
    end = None
    if d.ends and tag is not None:
        end = d.ends[0] if tag == "start" else d.ends[1]
    row = {"level": level, "what": what, "key": d.key, "layer_id": d.layer_id,
           "layer": d.layer_name, "fid": d.fid, "end": tag, "ll": end[LL] if end else None,
           "pole_m": None, "home_m": None, "gap_ll": None, "other_layer": other,
           "filled": end is None}
    if end is None and d.ends:
        row["ll"] = d.ends[0][LL]
    return row


def fill_rows(rows, cache):
    """The display-only columns (nearest pole / home in metres, gap point) for these rows,
    each row once. Called for the page being shown, not for every row: a scan with 63,350
    problem drops spent ~11 s on 3 nearest-point searches per row, for rows nobody pages to
    (2026-10-19). Sorting never uses these columns, so filling late changes no order."""
    for row in rows:
        if row.get("filled", True):
            continue
        row["filled"] = True
        qp = QgsPointXY(*row["ll"])
        pm, pi = cache.poles.nearest(qp, cache.da)
        am, ai = cache.anchors.nearest(qp, cache.da)
        hm, hi = cache.demand.nearest(qp, cache.da)
        net_m, net_ll = (pm, cache.poles.ll[pi] if pi is not None else None)
        if am < pm:
            net_m, net_ll = am, cache.anchors.ll[ai]
        row["pole_m"] = None if math.isinf(net_m) else round(net_m, 2)
        row["home_m"] = None if math.isinf(hm) else round(hm, 2)
        if "home" in row["what"] and hi is not None:
            row["gap_ll"] = cache.demand.ll[hi]
        elif net_ll is not None:
            row["gap_ll"] = net_ll
    return rows


def _home_row(level, what, cache, j):
    return {"level": level, "what": what, "key": cache.demand.key[j], "layer_id": None,
            "layer": None, "fid": cache.demand.fid[j], "end": None, "ll": cache.demand.ll[j],
            "pole_m": None, "home_m": None, "gap_ll": None, "other_layer": None, "home": True}


def summary_lines(result):
    """The five summary lines the panel shows above the table."""
    c, s = result["classes"], result["spare"]
    good = c["GOOD"]
    on_anchor = result["good_on_anchor"]
    return [
        f"{good:,} good ({good - on_anchor:,} on pole · {on_anchor:,} on anchor)",
        f"{c['NO_POLE']:,} no pole · {c['NO_HOME']:,} no home · {c['BOTH_POLE']:,} pole both ends"
        + (f" · {c['INVALID']:,} broken" if c["INVALID"] else ""),
        f"{result['unsnapped_ends']:,} not snapped · {result['stacked_pole_ends']:,} stacked",
        f"Homes: {result['demand_zero_drops']:,} no drop · {result['demand_multi_drops']:,} with 2+ drops",
        f"Spare drops: {s['OK']:,} OK · {s['NO_POLE'] + s['INVALID']:,} fail"
        + (f" · {s['BOTH_POLE']:,} both ends on a pole" if s["BOTH_POLE"] else ""),
    ]
