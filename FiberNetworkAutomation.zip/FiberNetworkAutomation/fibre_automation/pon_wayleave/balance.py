"""Balance PON sizes after grouping, without ever breaking the feeder.

The grouping engine packs PONs along the span and leaves remainders, so the
sizes come out spread: on Ventersdorp, 17 of 82 PONs were below the 80-stand
target and the smallest held 27. That is a *distribution* problem, not a
grouping problem -- the mean was already 92.1, dead centre of the band.

The move used here is **ReCom** (recombination), from GerryChain
(https://github.com/mggg/GerryChain, BSD-3-Clause, MGGG). The library itself is
not a dependency: it pulls geopandas and matplotlib in, and ``networkx`` is
already available in QGIS's Python. ReCom merges two adjacent PONs, builds a
spanning tree over the merged run-set and cuts ONE tree edge. Both halves are
therefore connected **by construction**, which is why this cannot produce an
island -- a property a swap heuristic only approximates.

Three things here were learned the hard way and must not be undone:

* **The cost is asymmetric.** 80-102 is the target band but ``HARD_MAX`` is the
  legal ceiling, so a PON of 110 is acceptable while a PON of 33 is not.
  Weighting both ends equally spent the optimiser's effort shaving legal PONs
  down instead of rescuing the runts.
* **Every move re-checks connectivity on BOTH sides and is rejected, never
  repaired.** A repair pass is what lets an island through.
* **Iteration order is sorted everywhere a decision depends on it.** Set order
  decided a page in this repo once and the output changed between identical
  builds. Determinism here is proven by rebuilding under a different
  ``PYTHONHASHSEED``, never by reading the code.
"""

from __future__ import annotations

import random
from collections import defaultdict, deque

import networkx as nx

from .core import PonWayleaveError

__all__ = [
    "BAND_HI",
    "BAND_LO",
    "HARD_MAX",
    "WORKING_CAP",
    "SEEDS",
    "balance_pons",
    "band_stats",
    "build_run_graph",
]

#: Velocity's per-PON fill band. Matches the Capacity report
#: (``TARGET_LO, TARGET_HI, HARD_MAX = 80, 102, 128``) and
#: ``network_planner`` ``max_pon_size``. The engine's own MAX_STANDS was 120,
#: which is *tighter* than the standard and blocked the merge that rescues a
#: runt: a 27-stand pocket next to a 97 is 124, illegal at 120, legal at 128.
BAND_LO = 80
BAND_HI = 102
HARD_MAX = 128

#: Under-target is a defect; over-target is legal up to HARD_MAX. Measured on
#: Ventersdorp: equal weights left 12 PONs under 80, this leaves 6.
W_UNDER = 5.0
W_OVER = 1.0

#: The cap the grouper and balancer work to, BELOW the legal ceiling.
#:
#: Removing an island means handing a stray piece's homes to a neighbour, and a
#: neighbour already at the hard cap has nowhere to put them. Measured on
#: Ventersdorp: working to 124 left the absorb pass oscillating -- 760 homes
#: moved and 2 islands survived -- while working to 116 converged with 51 homes
#: moved and ZERO islands. The 12 stands of headroom are what make the island
#: guarantee reachable, so do not raise this to HARD_MAX.
WORKING_CAP = 116

#: A fixed list, not a random draw, so a rebuild reproduces the same plan.
#: Three seeds, not five: the fourth and fifth never won on Ventersdorp and
#: each costs ~30 s.
SEEDS = (1, 3, 7)

#: Stop a pass once this many iterations in a row have been rejected. The search
#: converges early and then grinds: on Ventersdorp the full 50,000-iteration
#: budget cost 181 s of a 253 s run, for no further improvement.
STAGNATION = 1200


def _loads_of(graph, pon_of_run):
    """Stands per PON for a given run assignment."""
    loads = defaultdict(int)
    for r, p in pon_of_run.items():
        loads[p] += graph.nodes[r]["w"]
    return dict(loads)


def _cost(load, lo=BAND_LO, hi=BAND_HI):
    """How far one PON is from the target band, in weighted stands."""
    return W_UNDER * max(0, lo - load) + W_OVER * max(0, load - hi)


def _plan_cost(loads, lo=BAND_LO, hi=BAND_HI):
    return sum(_cost(v, lo, hi) for v in loads.values())


def build_run_graph(run_neighbours, stands_on_run, runs_in_play):
    """The span as a graph: nodes are runs, node weight is stands carried.

    Nodes and edges are added in sorted order so the graph -- and therefore
    every spanning tree drawn from it -- is reproducible.
    """
    g = nx.Graph()
    for r in sorted(runs_in_play):
        g.add_node(r, w=len(stands_on_run.get(r, ())))
    for r in sorted(runs_in_play):
        for nb in sorted(run_neighbours.get(r, ())):
            if nb in g:
                g.add_edge(r, nb)
    return g


def _subtree_weights(tree, root, w):
    """Subtree weight per node, iteratively -- recursion overflows on long runs."""
    parent = {root: None}
    order = []
    seen = {root}
    dq = deque([root])
    while dq:
        n = dq.popleft()
        order.append(n)
        for m in sorted(tree[n]):
            if m not in seen:
                seen.add(m)
                parent[m] = n
                dq.append(m)
    sub = {n: w[n] for n in order}
    for n in reversed(order):
        p = parent[n]
        if p is not None:
            sub[p] += sub[n]
    return sub, parent


def _descendants(tree, parent, start):
    out = set()
    dq = deque([start])
    seen = {start}
    while dq:
        x = dq.popleft()
        out.add(x)
        for y in sorted(tree[x]):
            if y not in seen and parent[y] == x:
                seen.add(y)
                dq.append(y)
    return out


def _tree_cut(graph, nodes, rng, lo, hi, cap, tries=14):
    """Split a connected run-set into two connected halves, best cost first."""
    sub = graph.subgraph(nodes)
    if not nx.is_connected(sub):
        return None
    w = {n: graph.nodes[n]["w"] for n in nodes}
    total = sum(w.values())
    if total < 2 * lo or total > 2 * cap:
        return None                       # no split can leave both sides legal
    for _ in range(tries):
        for u, v in sorted(sub.edges()):
            sub.edges[u, v]["r"] = rng.random()
        tree = nx.minimum_spanning_tree(sub, weight="r")
        root = min(tree.nodes)
        swt, parent = _subtree_weights(tree, root, w)
        cands = [n for n in sorted(tree.nodes)
                 if parent[n] is not None
                 and lo <= swt[n] <= cap and lo <= total - swt[n] <= cap]
        if not cands:
            continue
        cands.sort(key=lambda n: (_cost(swt[n], lo, hi)
                                  + _cost(total - swt[n], lo, hi), n))
        n = cands[0]
        side = _descendants(tree, parent, n)
        other = set(nodes) - side
        if side and other:
            return side, other, swt[n], total - swt[n]
    return None


def _one_pass(graph, pon_of_run, lo, hi, cap, seed, iters, patience=STAGNATION):
    rng = random.Random(seed)
    por = dict(pon_of_run)
    by = defaultdict(set)
    for r, p in sorted(por.items()):
        by[p].add(r)
    loads = {p: sum(graph.nodes[r]["w"] for r in rs) for p, rs in by.items()}
    idle = 0

    for _ in range(iters):
        if idle >= patience:
            break                      # nothing has been accepted in a long while
        idle += 1
        off = sorted(p for p in by if _cost(loads[p], lo, hi) > 0)
        if not off:
            break
        # bias toward the worst runt: it is the one the operator complains about
        p = min(off, key=lambda q: loads[q]) if rng.random() < 0.6 else rng.choice(off)
        nb = set()
        for r in sorted(by[p]):
            for m in sorted(graph[r]):
                q = por.get(m)
                if q is not None and q != p:
                    nb.add(q)
        if not nb:
            continue
        q = rng.choice(sorted(nb))
        roll = rng.random()

        # --- MERGE: the only move that can rescue an isolated pocket ---------
        if roll < 0.35:
            if (loads[p] + loads[q] <= cap
                    and _cost(loads[p] + loads[q], lo, hi) < _cost(loads[p], lo, hi) + _cost(loads[q], lo, hi)
                    and nx.is_connected(graph.subgraph(by[p] | by[q]))):
                for r in sorted(by[q]):
                    por[r] = p
                by[p] |= by[q]
                loads[p] += loads[q]
                del by[q]
                del loads[q]
                idle = 0
                continue

        # --- RECUT: redraw the boundary between two adjacent PONs ------------
        if roll < 0.70:
            out = _tree_cut(graph, by[p] | by[q], rng, lo, hi, cap)
            if out is None:
                continue
            side, other, a, b = out
            if _cost(a, lo, hi) + _cost(b, lo, hi) >= _cost(loads[p], lo, hi) + _cost(loads[q], lo, hi):
                continue
            for r in sorted(side):
                por[r] = p
            for r in sorted(other):
                por[r] = q
            by[p], by[q] = side, other
            loads[p], loads[q] = a, b
            idle = 0
            continue

        # --- TRANSFER: move one boundary run ---------------------------------
        edge = sorted(r for r in by[q] if any(m in by[p] for m in graph[r]))
        if not edge:
            continue
        r = rng.choice(edge)
        w = graph.nodes[r]["w"]
        if loads[p] + w > cap or len(by[q]) <= 1:
            continue
        if (_cost(loads[p] + w, lo, hi) + _cost(loads[q] - w, lo, hi)
                >= _cost(loads[p], lo, hi) + _cost(loads[q], lo, hi)):
            continue
        if not nx.is_connected(graph.subgraph(by[q] - {r})):
            continue
        if not nx.is_connected(graph.subgraph(by[p] | {r})):
            continue
        by[q].discard(r)
        by[p].add(r)
        por[r] = p
        loads[q] -= w
        loads[p] += w
        idle = 0

    return por, dict(loads)


def band_stats(loads, lo=BAND_LO, hi=BAND_HI, cap=HARD_MAX):
    """Readable summary of a plan's sizes."""
    v = sorted(loads.values())
    n = len(v)
    return {
        "pons": n,
        "stands": sum(v),
        "min": v[0] if n else 0,
        "max": v[-1] if n else 0,
        "mean": (sum(v) / n) if n else 0.0,
        "under": sum(1 for x in v if x < lo),
        "over_band": sum(1 for x in v if x > hi),
        "over_cap": sum(1 for x in v if x > cap),
        "in_band": sum(1 for x in v if lo <= x <= hi),
        "cost": _plan_cost(loads, lo, hi),
    }


def balance_pons(graph, stands_on_run, pon_of_run,
                 lo=BAND_LO, hi=BAND_HI, cap=WORKING_CAP,
                 seeds=SEEDS, iters=40000, progress=None, hard_cap=None):
    """Rebalance PON sizes. Returns ``(pon_of_run, loads, stats)``.

    Runs each fixed seed and keeps the best plan, ranked by *number of PONs
    under target* first and weighted cost second -- an under-target PON is the
    visible defect, so it outranks a legal-but-large one.

    ``hard_cap`` is the ceiling the CALLER promised its operator -- HT 2 labels
    its parameter "never exceeded" -- and is asserted on the result. Without it
    this function silently works to its own ``HARD_MAX``: an operator asking for
    120 could be handed 128, because the algorithm checks the cap on the
    grouping and then balances afterwards. A breach raises rather than returning
    a plan that violates a promise already made to the operator.
    """
    progress = progress or (lambda *_a, **_k: None)
    if hard_cap is not None:
        hard_cap = int(hard_cap)
        if cap > hard_cap:
            cap = hard_cap          # never work above what the caller promised
        over = {p: v for p, v in _loads_of(graph, pon_of_run).items()
                if v > hard_cap}
        if over:
            raise PonWayleaveError(
                f"{len(over)} PON(s) already exceed the {hard_cap}-stand maximum "
                f"before balancing (largest {max(over.values())}). Balancing "
                f"cannot fix that -- raise the maximum or re-run the grouping.")
    if not seeds:
        loads = _loads_of(graph, pon_of_run)
        return dict(pon_of_run), loads, band_stats(loads, lo, hi, cap)
    best = None
    for i, seed in enumerate(seeds):
        por, loads = _one_pass(graph, pon_of_run, lo, hi, cap, seed, iters)
        s = band_stats(loads, lo, hi, cap)
        key = (s["under"], s["cost"], seed)
        progress(100.0 * (i + 1) / len(seeds),
                 f"balance seed {seed}: {s['under']} under target, "
                 f"{s['in_band']}/{s['pons']} in band")
        if best is None or key < best[0]:
            best = (key, por, loads, s)
    _, por, loads, stats = best
    if hard_cap is not None:
        over = {p: v for p, v in loads.items() if v > hard_cap}
        if over:
            raise PonWayleaveError(
                f"Balancing produced {len(over)} PON(s) over the {hard_cap}-stand "
                f"maximum (largest {max(over.values())}). This is a bug -- nothing "
                f"was written. Please report it.")
    return por, loads, stats
