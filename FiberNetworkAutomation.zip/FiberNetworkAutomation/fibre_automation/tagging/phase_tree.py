"""phase_tree — the "Phases" group in the Layers panel for a phase split.

    Phases
     ├─ Phase 1      Poles PH1, Drops PH1, … , Phase 1   (filtered copies, same style)
     ├─ Phase 2
     └─ …

Same pattern JJ accepted for Malmesbury V4 (2026-10-26): every phase layer is a
``layer.clone()`` of the live layer with a filter, so there is no data copy and an edit
in the combined layer shows in its phase straight away. The filter is on the Phase
VALUE (not a feature-id list), so it does not go stale when features are added.

Live-tree safety (memory: phase groups in the live project, live-restyle crash):
  * only ADDS layers and one group; the user's own layers are never moved or restyled;
  * a re-run removes only the group THIS tool made (custom property marker) — a group the
    user built (Botshabelo's own "Phases") is left alone and ours is named "Phase Split";
  * phase subgroups start switched off and collapsed so the canvas does not draw twice.
"""
try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

MARK = "vf_phase_split"
GROUP_NAMES = ("Phases", "Phase Split")


def _sql_literal(v):
    """Provider-SQL literal for one stored value (numbers bare, text quoted)."""
    if isinstance(v, bool):
        return "1" if v else "0"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        return repr(int(v)) if v.is_integer() else repr(v)
    return "'%s'" % str(v).replace("'", "''")


def phase_filter(field, raw_values):
    """``"Phase" IN ('Phase 1')`` for the exact values stored for one phase."""
    vals = sorted({_sql_literal(v) for v in raw_values if v is not None})
    if not vals:
        return ""
    ident = '"%s"' % str(field).replace('"', '""')
    if len(vals) == 1:
        return "%s = %s" % (ident, vals[0])
    return "%s IN (%s)" % (ident, ", ".join(vals))


def _combine(old, new):
    old = (old or "").strip()
    return new if not old else "(%s) AND (%s)" % (old, new)


def find_tool_group(root):
    """The group this tool made earlier, or None."""
    for node in root.children():
        try:
            if node.customProperty(MARK) and hasattr(node, "findLayerIds"):
                return node
        except Exception:
            _swallowed_note()
    return None


def _free_group_name(root):
    """'Phases' unless the user already has a 'Phases' group of their own."""
    taken = {n.name().lower() for n in root.children()
             if hasattr(n, "findLayerIds") and not n.customProperty(MARK)}
    for name in GROUP_NAMES:
        if name.lower() not in taken:
            return name
    return "Phase Split (tool)"


class TreeResult:
    def __init__(self):
        self.group_name = ""
        self.added = 0
        self.removed_old = 0
        self.mismatch = []          # (layer name, shown, expected)
        self.errors = []

    @property
    def ok(self):
        return not self.errors and not self.mismatch


# claude:intent MUTATE fibre_automation/tagging/phase_tree.py build_group
#   Adds filtered clones of the chosen layers to a new "Phases" group in the open
#   project's layer tree, and removes only a group this tool itself added earlier
#   (custom-property marker). User layers are not moved, restyled or edited.
#   JJ asked for this group 2026-10-27 11:55. approved-destructive
# claude:boq-impact none - layer-tree views only; no feature or attribute is written.
def build_group(project, ep):
    """Build the Phases group from an ExportPlan (its items carry the per-phase values)."""
    from qgis.core import QgsLayerTreeGroup
    res = TreeResult()
    root = project.layerTreeRoot()
    old = find_tool_group(root)
    if old is not None:
        ids = list(old.findLayerIds())
        try:
            order = list(root.customLayerOrder()) if root.hasCustomLayerOrder() else None
        except Exception:
            order = None
        root.removeChildNode(old)
        if ids:
            project.removeMapLayers(ids)
        if order is not None:
            try:
                root.setCustomLayerOrder([lyr for lyr in order
                                          if lyr is not None and lyr.id() not in ids])
            except Exception:
                _swallowed_note()
        res.removed_old = len(ids)

    name = _free_group_name(root)
    group = QgsLayerTreeGroup(name)
    group.setCustomProperty(MARK, 1)
    root.insertChildNode(0, group)
    res.group_name = name

    try:
        custom = list(root.customLayerOrder()) if root.hasCustomLayerOrder() else None
    except Exception:
        custom = None
    clones_for = {}                              # source layer id → [clone, …]

    for phase in ep.phases:
        sub = group.addGroup(phase)
        sub.setCustomProperty(MARK, 1)
        sub.setItemVisibilityChecked(False)
        sub.setExpanded(False)
        for it in ep.items:
            path = it.phase_paths.get(phase)
            fids = it.by_phase.get(phase)
            if not path or not fids:
                continue
            src = project.mapLayer(it.layer_id)
            if src is None:
                res.errors.append("'%s' left the project." % it.name)
                continue
            flt = phase_filter(it.field, it.raw_by_phase.get(phase, ())) if it.field else ""
            if not flt and not it.is_source:
                continue
            clone = src.clone()
            clone.setName(_layer_title(path))
            # a one-layer-per-phase source IS that phase: the clone needs no filter
            if flt and not clone.setSubsetString(_combine(src.subsetString(), flt)):
                res.errors.append("'%s': QGIS refused the filter %s." % (it.name, flt))
                continue
            project.addMapLayer(clone, False)
            node = sub.addLayer(clone)
            if node is not None:
                node.setExpanded(False)
            clones_for.setdefault(src.id(), []).append(clone)
            res.added += 1
            shown = clone.featureCount()
            if shown != len(fids):
                res.mismatch.append((clone.name(), shown, len(fids)))

    if custom is not None and clones_for:
        new_order = []
        for lyr in custom:
            if lyr is None:
                continue
            new_order.extend(clones_for.get(lyr.id(), []))
            new_order.append(lyr)
        try:
            root.setCustomLayerOrder(new_order)
        except Exception:
            _swallowed_note()
    return res


def _layer_title(path):
    import os
    return os.path.splitext(os.path.basename(path))[0]
