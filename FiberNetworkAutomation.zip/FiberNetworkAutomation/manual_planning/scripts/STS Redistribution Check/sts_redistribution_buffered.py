import sys, os
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')

# ============================================================
# BUFFERED NEIGHBOUR CHECK — STS REDISTRIBUTION
# Uses small buffer to catch PONs that nearly touch
# ============================================================

PON_LAYER = 'PON v1'
STS_LAYER = 'STS Splitters v1'

pon_layer = None
sts_layer = None

for lyr in QgsProject.instance().mapLayers().values():
    n = lyr.name()
    if n == PON_LAYER: pon_layer = lyr
    if n == STS_LAYER: sts_layer = lyr

if not pon_layer or not sts_layer:
    print("ERROR: Missing layers")
else:
    from collections import Counter
    from qgis.core import QgsSpatialIndex

    sts_counts = Counter([f['pon_no'] for f in sts_layer.getFeatures() if f['pon_no']])
    pon_by_no = {f['pon_no']: f for f in pon_layer.getFeatures()}
    pon_by_id = {f.id(): f for f in pon_layer.getFeatures()}
    pon_index = QgsSpatialIndex(pon_layer.getFeatures())

    over = {p: c for p, c in sts_counts.items() if c > 16}

    # Also check PON 235 which was missing from previous run
    if 235 not in over:
        over[235] = sts_counts.get(235, 0)

    # CRS-aware buffer: ~100m regardless of layer units. Raw degrees only
    # work for a geographic CRS; a projected CRS (e.g. UTM) measures in metres,
    # where 0.001 native units = 1mm and every neighbour search returns nothing.
    if pon_layer.crs().isGeographic():
        BUFFER = 0.001  # ~100m in degrees
    else:
        BUFFER = 100.0  # 100m in projected metres

    print("=" * 60)
    print("  BUFFERED NEIGHBOUR CHECK (100m buffer)")
    print("=" * 60)

    for pon_no in sorted(over.keys()):
        count = sts_counts.get(pon_no, 0)
        if count <= 16:
            continue
        excess = count - 16
        print(f"\nPON {pon_no}: {count} STS — needs to move {excess} STS out")

        pon_feat = pon_by_no.get(pon_no)
        if not pon_feat:
            print(f"  WARNING: PON {pon_no} not found")
            continue

        pon_geom = pon_feat.geometry()
        buffered = pon_geom.buffer(BUFFER, 5)

        candidates = pon_index.intersects(buffered.boundingBox())

        neighbours = []
        for fid in candidates:
            neighbour = pon_by_id[fid]
            n_no = neighbour['pon_no']
            if n_no == pon_no:
                continue
            n_geom = neighbour.geometry()
            if buffered.intersects(n_geom):
                n_count = sts_counts.get(n_no, 0)
                capacity = 16 - n_count
                if capacity > 0:
                    neighbours.append((n_no, n_count, capacity))

        if neighbours:
            neighbours.sort(key=lambda x: -x[2])
            print("  Neighbouring PONs with capacity:")
            for n_no, n_count, cap in neighbours:
                print(f"    → PON {n_no}: {n_count} STS (can take {cap} more)")
        else:
            # Show all neighbours even if full
            neighbours_all = []
            for fid in candidates:
                neighbour = pon_by_id[fid]
                n_no = neighbour['pon_no']
                if n_no == pon_no:
                    continue
                n_geom = neighbour.geometry()
                if buffered.intersects(n_geom):
                    n_count = sts_counts.get(n_no, 0)
                    neighbours_all.append((n_no, n_count))
            print("  ⚠ All neighbours are full:")
            for n_no, n_count in sorted(neighbours_all):
                print(f"    PON {n_no}: {n_count} STS")
