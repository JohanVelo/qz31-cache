"""optical_budget — GPON optical power-budget validator (ITU-T G.984 / G.9807).

Pure math, zero dependencies (stdlib only) → SHIPPABLE. Checks every ONT→OLT link
against the PON class power budget so a design that would silently lock ONTs out
(too much loss → no light on a rainy day) is caught BEFORE the field.

Combo 1 for informal settlements = 1:8 FTS + 1:16 STS cascade.

  link_loss_db(...)    total optical loss for one link
  validate_link(...)   {loss, budget, headroom, pass} for one link
  worst_case_reach_m(...) max fibre length that still passes
"""
import math

# Typical splitter INSERTION loss (dB) incl. excess, per split ratio (ITU-T/vendor).
SPLITTER_LOSS_DB = {1: 0.0, 2: 3.5, 4: 7.2, 8: 10.5, 16: 14.0, 32: 17.5, 64: 21.0}

# Fibre attenuation (dB/km) by wavelength — G.652.D / G.657.
FIBER_DB_PER_KM = {1310: 0.35, 1490: 0.30, 1550: 0.21}

CONNECTOR_DB = 0.75      # per mated connector pair
SPLICE_DB = 0.10         # per fusion splice

# Max allowed channel insertion loss (dB) per PON class.
CLASS_BUDGET_DB = {"A": 20.0, "B": 25.0, "B+": 28.0, "C+": 32.0, "C++": 35.0}


def _splitter_loss(ratio):
    if ratio in SPLITTER_LOSS_DB:
        return SPLITTER_LOSS_DB[ratio]
    # fall back to ideal split + ~1 dB excess if an odd ratio is given
    return round(10.0 * math.log10(ratio) + 1.0, 2) if ratio > 1 else 0.0


def link_loss_db(fiber_m, splitter_ratios=(8, 16), n_splices=2, n_connectors=2,
                 wavelength=1310):
    """Total optical loss (dB) for one ONT link. splitter_ratios = the cascade,
    e.g. (8, 16) for a 1:8 FTS feeding a 1:16 STS."""
    loss = (fiber_m / 1000.0) * FIBER_DB_PER_KM.get(wavelength, 0.35)
    for r in splitter_ratios:
        loss += _splitter_loss(r)
    loss += n_splices * SPLICE_DB + n_connectors * CONNECTOR_DB
    return round(loss, 3)


def validate_link(fiber_m, splitter_ratios=(8, 16), pon_class="B+", margin_db=2.0,
                  n_splices=2, n_connectors=2, wavelength=1310):
    """Return {loss_db, budget_db, margin_db, headroom_db, pass}. pass=True means
    the link has positive headroom after the safety margin."""
    loss = link_loss_db(fiber_m, splitter_ratios, n_splices, n_connectors, wavelength)
    budget = CLASS_BUDGET_DB.get(pon_class, 28.0)
    headroom = round(budget - loss - margin_db, 3)
    return {
        "loss_db": loss,
        "budget_db": budget,
        "margin_db": margin_db,
        "headroom_db": headroom,
        "pass": headroom >= 0.0,
    }


def worst_case_reach_m(splitter_ratios=(8, 16), pon_class="B+", margin_db=2.0,
                       n_splices=2, n_connectors=2, wavelength=1310):
    """Max fibre length (m) that still passes, given the fixed losses. Useful as a
    design rule: 'no ONT further than X m on this splitter combo'."""
    budget = CLASS_BUDGET_DB.get(pon_class, 28.0)
    fixed = margin_db + n_splices * SPLICE_DB + n_connectors * CONNECTOR_DB
    for r in splitter_ratios:
        fixed += _splitter_loss(r)
    per_km = FIBER_DB_PER_KM.get(wavelength, 0.35)
    remaining = budget - fixed
    if remaining <= 0 or per_km <= 0:
        return 0
    return int((remaining / per_km) * 1000.0)


# Common splitter combos → cascade ratios (total split = product).
COMBOS = {
    "1:32 (1x1:32)": (32,),
    "1:64 (1:8 + 1:8)": (8, 8),
    "1:64 (1:16 + 1:4)": (16, 4),
    "1:128 (1:8 + 1:16)": (8, 16),
}
SAFETY_MARGIN_DB = 3.0   # ITU-T recommended operating margin (rain/age/repairs)


def recommend_config(fiber_m, target_combo="1:128 (1:8 + 1:16)", margin_db=SAFETY_MARGIN_DB):
    """Advise the safe optics for a given reach. Returns, for the target split:
    each PON class's pass/headroom, the cheapest class that passes, and which
    combos fit the common Class B+ — so the OLT/splitter spec can be chosen with
    the safety margin baked in (default 3 dB, ITU)."""
    ratios = COMBOS.get(target_combo, (8, 16))
    per_class = {c: validate_link(fiber_m, ratios, c, margin_db) for c in ("B+", "C+", "C++")}
    min_safe = next((c for c in ("B+", "C+", "C++") if per_class[c]["pass"]), None)
    b_plus_ok = [name for name, r in COMBOS.items()
                 if validate_link(fiber_m, r, "B+", margin_db)["pass"]]
    return {
        "fiber_m": fiber_m,
        "target_combo": target_combo,
        "margin_db": margin_db,
        "per_class": per_class,
        "min_safe_class_for_target": min_safe,
        "combos_safe_on_B+": b_plus_ok,
    }


def validate_links(links, splitter_ratios=(8, 16), pon_class="B+", margin_db=2.0):
    """Validate many links. links = iterable of fibre lengths (m) OR dicts with a
    'fiber_m' key. Returns {total, passed, failed, worst_headroom_db, fails:[...]}."""
    total = passed = 0
    worst = None
    fails = []
    for i, lk in enumerate(links):
        fm = lk.get("fiber_m") if isinstance(lk, dict) else lk
        if fm is None:
            continue
        total += 1
        v = validate_link(fm, splitter_ratios, pon_class, margin_db)
        if worst is None or v["headroom_db"] < worst:
            worst = v["headroom_db"]
        if v["pass"]:
            passed += 1
        else:
            fails.append({"index": i, "fiber_m": fm, **v})
    return {
        "total": total,
        "passed": passed,
        "failed": total - passed,
        "worst_headroom_db": worst,
        "max_reach_m": worst_case_reach_m(splitter_ratios, pon_class, margin_db),
        "fails": fails[:50],
    }
