"""structure_adapter — bridge QGIS project layers to the walk-engine contracts.

The walk engine (structure_graph.py + numbering.py) is pure-Python and knows
nothing about QGIS: it consumes Segment/Point dicts and a HierarchyConfig, and
produces labels numbered in PHYSICAL network order (a DFS pre-order walk from
the POP outward). This module is the ONLY QGIS-aware piece: it reads the
project's cable/splitter/ONT/POP layers into those contracts, and offers the
one-call glue walk_number() = build_graph -> traverse -> assign_labels.

Contracts (from structure_graph):
    Segment = {"id": fid, "cls": <tier tag>, "coords": [(lon,lat), ...],
               "size": optional number}
    Point   = {"id": fid, "role": <tier tag>, "xy": (lon,lat), "attrs": dict}

The QGIS reads live in extract() (lazy QGIS import). Everything else — the
per-client HierarchyConfig and the walk_number() glue — is pure Python and is
covered by _self_test() with a synthetic Fibertime-shaped network, so this
module imports and self-tests in plain Python 3.12 without QGIS.
"""
from .numbering import HierarchyConfig, Level, assign_labels
from .structure_graph import DEG_PER_M, build_graph, traverse

# Canonical tier tags — the cls (cables) / role (points) each Segment/Point
# carries, and what the HierarchyConfig levels match on.
POP, PRIMARY, SECONDARY, FTS, DISTRIBUTION, STS, DROP, ONT = (
    "POP", "PRIMARY", "SECONDARY", "FTS", "DISTRIBUTION", "STS", "DROP", "ONT")
# Passive structure points: poles ride ON the cables (children of every cable
# tier) so walk-order numbers them pole-by-pole along the fibre path.
POLE = "POLE"

# The POP is routinely sited a block off the feeder trunk (verified live on the
# Matiko sandbox: POP was 85 m from the nearest feeder endpoint). Give the ROOT
# a generous attach distance so the walk can leave the POP, while every inner
# hop stays tight (tap_m=6 m) so a loose root never bridges a real gap deeper
# in the network. One POP per project => blast radius is a single point.
ROOT_ATTACH_M = 150.0

# Canonical PH2 / Fibertime layer name -> (tier tag, kind). "v1" layers are the
# canonical ones (see memory: poles v1 / *_v1 are the source of truth).
FIBERTIME_LAYER_TIERS = {
    "POP": (POP, "point"),
    "Primary Cable v1": (PRIMARY, "cable"),
    "Secondary Cable v1": (SECONDARY, "cable"),
    "FTS Splitters v1": (FTS, "point"),
    "Distribution Cable v1": (DISTRIBUTION, "cable"),
    "STS Splitters v1": (STS, "point"),
    "Drop Cable v1": (DROP, "cable"),
    "ONT v1": (ONT, "point"),
}

# Label-My-Network recipe role -> (walk tier, kind). This lets walk-order run
# on ANY project (Matiko / HeroTel / Vuma, whatever the layers are called) by
# reusing the layer->role mapping the operator already set in the wizard,
# instead of relying on the canonical Fibertime "v1" layer NAMES above.
LMN_ROLE_TIERS = {
    "POP": (POP, "point"),
    "PRI_CABLE": (PRIMARY, "cable"),
    "SEC_CABLE": (SECONDARY, "cable"),
    "FTS_SPLITTER": (FTS, "point"),
    "DIST_CABLE": (DISTRIBUTION, "cable"),
    "STS_SPLITTER": (STS, "point"),
    "DROP_CABLE": (DROP, "cable"),
    "ONT": (ONT, "point"),
    "POLE": (POLE, "point"),
}


def fibertime_hierarchy(constants=None):
    """The Fibertime physical hierarchy, POP outward to ONT (PH2 tiers).

    Walk order: POP -> Primary -> Secondary -> FTS -> Distribution -> STS ->
    Drop -> ONT (the reverse of the ONT->…->POP network hierarchy). Numbering
    is walk_order (chainage-ordered pre-order counter) at every level, so the
    sequence follows the actual fibre path, not arbitrary/spatial order.
    """
    return HierarchyConfig(name="Fibertime walk", constants=dict(constants or {}), levels=(
        Level(POP, POP, None, kind="point", fmt="{level}{n:02d}"),
        Level(PRIMARY, PRIMARY, POP, kind="cable"),
        Level(SECONDARY, SECONDARY, PRIMARY, kind="cable"),
        Level(FTS, FTS, SECONDARY, kind="point"),
        Level(DISTRIBUTION, DISTRIBUTION, FTS, kind="cable"),
        Level(STS, STS, DISTRIBUTION, kind="point"),
        Level(DROP, DROP, STS, kind="cable"),
        Level(ONT, ONT, DROP, kind="point"),
    ))


def island_hierarchy(constants=None):
    """Multi-root LMN walk: POP *and* every FTS are subtree roots.

    Real exports routinely have NO drawn trunk between the POP and the PON
    areas (verified on the Matiko sandbox 2026-07-24: each PON's cabling is a
    disconnected island a pole-span away from its neighbours, and the feeder
    home-runs POP->FTS are simply not digitised — 59 islands, nothing within
    ~25-47 m).  A single-root POP walk can therefore never cover such a
    project, no matter the tolerance.  This config walks the POP's own island
    first and then EACH FTS island in the caller-supplied root order (see
    walk_roots), with permissive parents + self-branching so any cable tier
    chains through junctions and branches.  On a fully-connected canonical
    network the POP walk simply covers everything and the extra roots
    contribute nothing — it is a strict superset of the single-root walk.
    """
    # Parent DAG covers BOTH shapes without a cycle (the config validator
    # rejects mutual parents):  canonical PH2 walks POP -> PRIMARY ->
    # SECONDARY and FTS -> DISTRIBUTION -> STS -> DROP -> ONT; Matiko-shaped
    # exports walk FTS -> DISTRIBUTION(snake) -> STS -> PRIMARY(street spans)
    # -> DROP, so PRIMARY is *also* a child of DISTRIBUTION/STS here.
    # JJ's walk sequence (2026-07-24): POP → feeder cable → feeder joints
    # (FTS) → distribution cable → second-tier splitters (STS) → drops.
    # Points sort BEFORE cables at the same node (structure_graph._dispatch),
    # so a joint numbers before the cable it feeds wherever the walk meets
    # it. FTS is BOTH fed by the feeder tiers (path-ordered when the feeder
    # is drawn up to it) AND a walk root via walk_roots (island entry when it
    # is not) — a genuinely mutual FTS<->cable relationship, declared with
    # allow_cycles (traverse is visited-set safe; see numbering.py).
    return HierarchyConfig(name="Island walk", constants=dict(constants or {}),
                           allow_cycles=True, levels=(
        Level(POP, POP, None, kind="point", fmt="{level}{n:02d}"),
        Level(FTS, FTS, [PRIMARY, SECONDARY, DISTRIBUTION], kind="point"),
        Level(DISTRIBUTION, DISTRIBUTION, [POP, FTS, DISTRIBUTION], kind="cable"),
        Level(STS, STS, [DISTRIBUTION], kind="point"),
        Level(PRIMARY, PRIMARY,
              [POP, FTS, DISTRIBUTION, STS, PRIMARY], kind="cable"),
        Level(SECONDARY, SECONDARY, [POP, FTS, PRIMARY, SECONDARY], kind="cable"),
        Level(DROP, DROP,
              [STS, DISTRIBUTION, PRIMARY, SECONDARY, DROP], kind="cable"),
        Level(ONT, ONT, [DROP, STS], kind="point"),
        Level(POLE, POLE,
              [PRIMARY, SECONDARY, DISTRIBUTION, DROP], kind="point"),
    ))


def _fid_sort_key(fid):
    """Natural sort key for "<tier>:<fid>" ids: numeric fid when possible."""
    s = str(fid)
    tail = s.rsplit(":", 1)[-1]
    try:
        return (0, int(tail), s)
    except ValueError:
        return (1, 0, s)


def walk_roots(points, pop_roots=None):
    """Root sequence for the island walk: POPs first, then FTSs, fid order.

    ``pop_roots`` (the roots list from extract()) keeps the POP set exactly as
    extracted; every FTS-role point is appended as an island root.  Ordering
    is by numeric feature id (FTS fid order matches the planner's FTS_001..N
    numbering on real exports), so the walk sequence is POP island ->
    FTS_001's island -> ... -> FTS_055's island, deterministic on any input
    order.
    """
    pops = sorted(pop_roots or
                  [p["id"] for p in points if str(p.get("role")) == POP],
                  key=_fid_sort_key)
    fts = sorted((p["id"] for p in points if str(p.get("role")) == FTS),
                 key=_fid_sort_key)
    return list(pops) + list(fts)


def walk_number(segments, points, roots, config, existing=None, zones=None,
                snap_m=2.0, tap_m=6.0, root_attach_m=ROOT_ATTACH_M):
    """Glue: build the graph, walk it from roots, assign walk-order labels.

    Returns (labels, anomalies): labels = {feature_id: label or None};
    anomalies = the flag list from traverse (off-network / zone-mismatch / …).
    Pure Python — no QGIS — so it is unit-testable offline.
    """
    graph = build_graph(segments, points, snap_m=snap_m, tap_m=tap_m,
                        role_tap_m={POP: root_attach_m})
    walks, anomalies = traverse(graph, roots, config)
    labels = assign_labels(walks, config, anomalies=anomalies,
                           existing=existing, zones=zones)
    return labels, anomalies


# How a feature came to have a walk index. The distinction the coverage report
# could not make before: FOLLOWED means the walk arrived down the fibre from a
# POP; ISLAND means it arrived because a splitter was ALSO made a root and the
# walk restarted there (see island_hierarchy / walk_roots). A project whose
# feeder is not digitised is 100% "reached" and ~0% FOLLOWED.
FOLLOWED, ISLAND = "followed", "island"


def walk_report(segments, points, roots, config, snap_m=2.0, tap_m=6.0,
                root_attach_m=ROOT_ATTACH_M, pop_role=POP):
    """ONE graph build, ONE traverse -> order + provenance + anomalies.

    Returns {"order": {feature_id: int}, "provenance": {feature_id: FOLLOWED |
    ISLAND}, "anomalies": [...], "roots": {"walked", "pop", "island"}}.

    "roots" counts roots that actually OPENED a walk, not roots supplied: a
    splitter the POP walk already reached is skipped as a duplicate, so
    roots["island"] is the number of genuinely disconnected islands — the
    number worth showing an operator.

    "order" is byte-identical to what walk_order_index() has always returned —
    that function now delegates here, so the two can never drift apart and the
    numbering contract is enforced by construction rather than by discipline.

    Provenance is read off the SAME walk, never a second traverse: traverse()
    returns one walk per root and its `visited` set is global, so the first
    root to reach a feature owns it. A walk rooted on a `pop_role` point is
    FOLLOWED; any other root is an island entry. Anomalies are the diagnostics
    traverse() already emits (point_off_network / unreachable / dangling_end /
    zone_mismatch / unmerged_segments / loop_closed) which the caller used to
    discard. Pure Python.
    """
    graph = build_graph(segments, points, snap_m=snap_m, tap_m=tap_m,
                        role_tap_m={POP: root_attach_m})
    walks, anomalies = traverse(graph, roots, config)
    role_of = {p["id"]: str(p.get("role")) for p in points}
    order = {}
    prov = {}
    i = 0
    n_pop = 0
    for w in walks:
        src = FOLLOWED if role_of.get(w.get("root")) == pop_role else ISLAND
        n_pop += (src == FOLLOWED)
        for it in w.get("items", ()):
            fid = it.get("feature_id")
            if fid is not None and fid not in order:
                order[fid] = i
                prov[fid] = src
                i += 1
            for m in (it.get("members") or ()):   # merged same-class segments
                if m not in order:
                    order[m] = order[fid]
                    prov[m] = src
    return {"order": order, "provenance": prov, "anomalies": anomalies,
            "roots": {"walked": len(walks), "pop": n_pop,
                      "island": len(walks) - n_pop}}


def walk_order_index(segments, points, roots, config, snap_m=2.0, tap_m=6.0,
                     root_attach_m=ROOT_ATTACH_M):
    """Return {feature_id: global pre-order index} following the physical walk.

    This is the LMN integration point: rather than relabel with the walk
    engine's own format, we just take the ORDER — the DFS pre-order position of
    every feature across the whole hierarchy (POP outward) — and hand it to the
    recipe tool's sequence pre-pass so auto-numbering follows the fibre path
    instead of arbitrary/spatial order. Features not reached by the walk are
    simply absent (the caller sorts them last). Pure Python.

    FROZEN CONTRACT: {feature_id: int} and nothing else. label_recipe._seq_order
    silently falls back to spatial ordering for a non-integer walk_order, so
    returning a richer value here would renumber every project without a word.
    Callers that want provenance call walk_report() and take ["order"].
    """
    return walk_report(segments, points, roots, config, snap_m=snap_m,
                       tap_m=tap_m, root_attach_m=root_attach_m)["order"]


# --------------------------------------------------------------------------
# QGIS extraction (the only QGIS-aware code; validated live, not in self-test)
# --------------------------------------------------------------------------
def _to_wgs84_transform(layer):
    """A QgsCoordinateTransform layer-CRS -> EPSG:4326, or None if already 4326."""
    from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform,
                           QgsProject)
    src = layer.crs()
    dst = QgsCoordinateReferenceSystem("EPSG:4326")
    if src == dst:
        return None
    return QgsCoordinateTransform(src, dst, QgsProject.instance())


def _line_coords(geom, tr):
    """Flatten a (multi)line geometry to a list of (lon, lat) vertices."""
    pts = []
    for v in geom.vertices():
        x, y = v.x(), v.y()
        if tr is not None:
            p = tr.transform(x, y)
            x, y = p.x(), p.y()
        pts.append((x, y))
    return pts


def _point_xy(geom, tr):
    """A representative (lon, lat) for any geometry (centroid for poly/line)."""
    c = geom.centroid().asPoint()
    x, y = c.x(), c.y()
    if tr is not None:
        p = tr.transform(x, y)
        x, y = p.x(), p.y()
    return (x, y)


def extract(project=None, layer_tiers=None, size_fields=("cable_size", "size",
            "fibre", "fibres", "capacity"), zone_fields=("zone_no", "zone",
            "pon_no")):
    """Read the project's layers into (segments, points, roots) contracts.

    project     : a QgsProject (defaults to the active instance).
    layer_tiers : {layer_name: (tier_tag, "cable"|"point")} — defaults to
                  FIBERTIME_LAYER_TIERS. Roots = every extracted point whose
                  tier is the config's root level (POP).
    Feature ids are namespaced "<tier>:<fid>" so ids never collide across
    layers. Cable size + point zone are pulled from the first matching field.
    """
    from qgis.core import QgsProject
    project = project or QgsProject.instance()
    layer_tiers = layer_tiers or FIBERTIME_LAYER_TIERS

    by_name = {}
    for lyr in project.mapLayers().values():
        by_name.setdefault(lyr.name(), lyr)

    segments, points, roots = [], [], []
    for name, (tier, kind) in layer_tiers.items():
        lyr = by_name.get(name)
        if lyr is None:
            continue
        tr = _to_wgs84_transform(lyr)
        fields = [f.name() for f in lyr.fields()]
        size_f = next((f for f in size_fields if f in fields), None)
        zone_f = next((f for f in zone_fields if f in fields), None)
        for feat in lyr.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue
            fid = f"{tier}:{feat.id()}"
            if kind == "cable":
                seg = {"id": fid, "cls": tier, "coords": _line_coords(geom, tr)}
                if size_f is not None:
                    try:
                        seg["size"] = float(feat[size_f])
                    except (TypeError, ValueError):
                        pass
                segments.append(seg)
            else:
                attrs = {}
                if zone_f is not None:
                    zv = feat[zone_f]
                    if zv not in (None, ""):
                        attrs["zone"] = zv
                pt = {"id": fid, "role": tier, "xy": _point_xy(geom, tr),
                      "attrs": attrs}
                points.append(pt)
                if tier == POP:
                    roots.append(fid)
    return segments, points, roots


# --------------------------------------------------------------------------
# self-test — synthetic Fibertime-shaped network, no QGIS
# --------------------------------------------------------------------------
def _self_test():
    print("=" * 64)
    print("structure_adapter self-test (synthetic Fibertime network, no QGIS)")
    print("=" * 64)

    def xy(mx, my):
        return (mx * DEG_PER_M, my * DEG_PER_M)

    # POP at origin; a primary run east to an FTS; a distribution run north from
    # the FTS to an STS; two drops from the STS to two ONTs. One clean chain.
    segments = [
        {"id": "PRIMARY:1", "cls": PRIMARY, "size": 144,
         "coords": [xy(0, 0), xy(60, 0)]},
        {"id": "SECONDARY:1", "cls": SECONDARY, "size": 48,
         "coords": [xy(60, 0), xy(120, 0)]},
        {"id": "DISTRIBUTION:1", "cls": DISTRIBUTION, "size": 24,
         "coords": [xy(120, 0), xy(120, 60)]},
        {"id": "DROP:1", "cls": DROP, "coords": [xy(120, 60), xy(140, 70)]},
        {"id": "DROP:2", "cls": DROP, "coords": [xy(120, 60), xy(140, 50)]},
    ]
    points = [
        {"id": "POP:1", "role": POP, "xy": xy(0, 0), "attrs": {"zone": 17}},
        {"id": "FTS:1", "role": FTS, "xy": xy(120, 0), "attrs": {"zone": 17}},
        {"id": "STS:1", "role": STS, "xy": xy(120, 60), "attrs": {"zone": 17}},
        {"id": "ONT:1", "role": ONT, "xy": xy(140, 70), "attrs": {"zone": 17}},
        {"id": "ONT:2", "role": ONT, "xy": xy(140, 50), "attrs": {"zone": 17}},
    ]
    cfg = fibertime_hierarchy(constants={})
    labels, anomalies = walk_number(segments, points, ["POP:1"], cfg)

    # every non-flagged feature gets a label; POP is the root; parent-before-child
    labelled = {k: v for k, v in labels.items() if v is not None}
    assert labels.get("POP:1"), f"POP not labelled: {labels}"
    for fid in ("PRIMARY:1", "SECONDARY:1", "FTS:1", "DISTRIBUTION:1",
                "STS:1", "DROP:1", "DROP:2", "ONT:1", "ONT:2"):
        assert labels.get(fid) is not None, f"{fid} not labelled: {labels}"
    print(f"  [PASS] all 10 features labelled in walk order ({len(labelled)}/10)")

    # the two ONTs get distinct labels (unique within the STS parent scope)
    assert labels["ONT:1"] != labels["ONT:2"], "sibling ONTs share a label"
    print("  [PASS] sibling ONTs numbered distinctly")

    # an off-network stray ONT (far away) is flagged, not mis-numbered
    seg2 = segments + []
    pts2 = points + [{"id": "ONT:99", "role": ONT, "xy": xy(9000, 9000),
                      "attrs": {}}]
    labels2, _ = walk_number(seg2, pts2, ["POP:1"], cfg)
    assert labels2.get("ONT:99") is None, "stray ONT should be None, not numbered"
    print("  [PASS] off-network stray ONT -> None (never mis-numbered)")

    # walk_order_index follows the physical path: POP < Primary < … < ONT
    idx = walk_order_index(segments, points, ["POP:1"], cfg)
    chain = ["POP:1", "PRIMARY:1", "SECONDARY:1", "FTS:1", "DISTRIBUTION:1",
             "STS:1"]
    for a, b in zip(chain, chain[1:]):
        assert idx[a] < idx[b], f"walk order not monotonic: {a}={idx[a]} {b}={idx[b]}"
    assert idx["STS:1"] < idx["DROP:1"] and idx["DROP:1"] < idx["ONT:1"], "drop/ONT order"
    print("  [PASS] walk_order_index monotonic POP->Primary->...->STS->Drop->ONT")

    # the LMN role->tier map covers every tier the hierarchy walks, so walk-
    # order can engage on any project via the operator's card->layer mapping
    mapped = {t for t, _k in LMN_ROLE_TIERS.values()}
    assert mapped == {POP, PRIMARY, SECONDARY, FTS, DISTRIBUTION, STS, DROP,
                      ONT, POLE}, f"LMN_ROLE_TIERS missing a tier: {mapped}"
    print("  [PASS] LMN_ROLE_TIERS covers all 9 walk tiers")

    # poles ride the cables: numbered in CHAINAGE order along the walk (the
    # Malmesbury behaviour — pole 1 nearest the POP, then outward)
    pseg = segments + []
    ppts = points + [
        {"id": "POLE:2", "role": POLE, "xy": xy(40, 0), "attrs": {}},
        {"id": "POLE:1", "role": POLE, "xy": xy(20, 0), "attrs": {}},
        {"id": "POLE:3", "role": POLE, "xy": xy(120, 30), "attrs": {}},
    ]
    idx_p = walk_order_index(pseg, ppts, walk_roots(ppts, ["POP:1"]),
                             island_hierarchy())
    assert idx_p["POLE:1"] < idx_p["POLE:2"] < idx_p["POLE:3"], \
        f"poles not in chainage walk order: {idx_p}"
    assert idx_p["POP:1"] < idx_p["POLE:1"], "POP must precede the first pole"
    print("  [PASS] poles numbered in chainage order along the walk")

    # root-attach tolerance: a POP sited ~80 m off the feeder start still
    # connects with the generous root tap, but a tight root tap dead-ends it
    pts_off = [dict(p) for p in points]
    pts_off[0] = {"id": "POP:1", "role": POP, "xy": xy(0, -80),
                  "attrs": {"zone": 17}}          # 80 m south of PRIMARY start
    idx_tight = walk_order_index(segments, pts_off, ["POP:1"], cfg,
                                 root_attach_m=6.0)
    assert set(idx_tight) <= {"POP:1"}, f"tight root tap should dead-end: {idx_tight}"
    idx_loose = walk_order_index(segments, pts_off, ["POP:1"], cfg,
                                 root_attach_m=150.0)
    assert idx_loose.get("PRIMARY:1") is not None and \
        idx_loose["POP:1"] < idx_loose["PRIMARY:1"], \
        f"loose root tap should reach the feeder: {idx_loose}"
    print("  [PASS] ROOT_ATTACH_M reconnects an off-feeder POP (80 m gap)")

    # ---- island walk: a PON island DISCONNECTED from the POP (no drawn
    # trunk, the real Matiko shape) is still covered via its FTS root
    iseg = segments + [
        {"id": "DISTRIBUTION:9", "cls": DISTRIBUTION, "size": 24,
         "coords": [xy(5000, 0), xy(5060, 0)]},          # island snake
        {"id": "DROP:9", "cls": DROP, "coords": [xy(5060, 0), xy(5080, 10)]},
    ]
    ipts = points + [
        {"id": "FTS:9", "role": FTS, "xy": xy(5000, 0), "attrs": {}},
        {"id": "STS:9", "role": STS, "xy": xy(5060, 0), "attrs": {}},
    ]
    icfg = island_hierarchy()
    iroots = walk_roots(ipts, ["POP:1"])
    assert iroots[0] == "POP:1" and iroots[-1] == "FTS:9", f"roots: {iroots}"
    idx_i = walk_order_index(iseg, ipts, iroots, icfg)
    for fid in ("POP:1", "PRIMARY:1", "DISTRIBUTION:9", "STS:9", "DROP:9"):
        assert fid in idx_i, f"island walk missed {fid}: {sorted(idx_i)}"
    assert idx_i["STS:1"] < idx_i["FTS:9"], "POP island must precede FTS island"
    print("  [PASS] island_hierarchy covers a POP-disconnected FTS island")

    # provenance is read off the SAME walk and does NOT disturb the order: the
    # POP's own subtree is FOLLOWED, the disconnected FTS island is ISLAND.
    rep_i = walk_report(iseg, ipts, iroots, icfg)
    assert rep_i["order"] == idx_i, "walk_report order drifted from walk_order_index"
    assert all(isinstance(v, int) for v in rep_i["order"].values()), \
        "walk order must stay {fid: int} — non-int silently falls back to spatial"
    prov = rep_i["provenance"]
    for fid in ("POP:1", "PRIMARY:1", "STS:1"):
        assert prov[fid] == FOLLOWED, f"{fid} should be FOLLOWED: {prov[fid]}"
    for fid in ("FTS:9", "DISTRIBUTION:9", "STS:9", "DROP:9"):
        assert prov[fid] == ISLAND, f"{fid} should be ISLAND: {prov[fid]}"
    assert set(prov) == set(idx_i), "provenance and order must cover the same ids"
    # FTS:1 is supplied as a root but the POP walk already reached it, so it
    # opens no walk: 3 roots in, 2 walks out, 1 genuinely disconnected island.
    assert len(iroots) == 3, iroots
    assert rep_i["roots"] == {"walked": 2, "pop": 1, "island": 1}, rep_i["roots"]
    print("  [PASS] walk_report: POP subtree FOLLOWED, FTS island ISLAND, order intact")

    # the mutation the other way: DRAW the missing feeder and the same island
    # must flip to FOLLOWED with no root change at all
    cseg = iseg + [{"id": "PRIMARY:77", "cls": PRIMARY, "size": 144,
                    "coords": [xy(120, 0), xy(5000, 0)]}]   # POP island -> FTS:9
    prov_c = walk_report(cseg, ipts, iroots, icfg)["provenance"]
    for fid in ("FTS:9", "DISTRIBUTION:9", "STS:9", "DROP:9"):
        assert prov_c[fid] == FOLLOWED, \
            f"{fid} should be FOLLOWED once the feeder is drawn: {prov_c[fid]}"
    print("  [PASS] drawing the feeder flips ISLAND -> FOLLOWED (mutation both ways)")

    # traverse honours the CALLER's root order (no str re-sorting)
    fts_first = walk_order_index(iseg, ipts, ["FTS:9", "POP:1"], icfg)
    assert fts_first["FTS:9"] == 0 and fts_first["DROP:9"] < fts_first["POP:1"], \
        f"caller root order not honoured: {fts_first}"
    print("  [PASS] traverse walks roots in the caller's order")

    # co-nearest multi-tap: a junction DEVICE fuses same-class spans A + B
    # (old nearest-per-class rule fragmented the chain at every such device)
    jseg = [
        {"id": "DROP:A", "cls": DROP, "coords": [xy(0, 0), xy(50, 0)]},
        {"id": "DROP:B", "cls": DROP, "coords": [xy(50.5, 0), xy(100, 0)]},
        {"id": "DISTRIBUTION:J", "cls": DISTRIBUTION, "size": 24,
         "coords": [xy(50, -40), xy(50, 0.5)]},
    ]
    jpts = [{"id": "STS:J", "role": STS, "xy": xy(50, 0), "attrs": {}},
            {"id": "POP:J", "role": POP, "xy": xy(50, -40), "attrs": {}}]
    jidx = walk_order_index(jseg, jpts, ["POP:J"], island_hierarchy())
    assert "DROP:A" in jidx and "DROP:B" in jidx, \
        f"device junction did not fuse both spans: {sorted(jidx)}"
    print("  [PASS] co-nearest multi-tap fuses same-class spans at a device")

    print("\nSTRUCTURE_ADAPTER SELF-TEST: ALL CHECKS PASSED")
    return True


if __name__ == "__main__":
    import sys
    if "--self-test" in sys.argv:
        sys.exit(0 if _self_test() else 1)
    print("structure_adapter — run with --self-test")
