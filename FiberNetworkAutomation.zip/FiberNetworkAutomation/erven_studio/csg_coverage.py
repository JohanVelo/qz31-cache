"""Does the CSG cadastre match JJ's real blue erven? Download CSG for the test
window and measure IoU vs the real erven. Offline (web only, no QGIS bridge)."""
import json, requests
from shapely.geometry import Polygon
from shapely.strtree import STRtree
from shapely import wkt
import geopandas as gpd

d = json.load(open('C:/Temp/erven_test.json'))
xmin, ymin, xmax, ymax = d['window_4326']
real = [wkt.loads(w) for w in d['real_erven_wkt']]   # already EPSG:32735 (metric)

url = 'https://dffeportal.environment.gov.za/hosting/rest/services/CSG_Cadaster/CSG_Cadastral_Data/MapServer/2/query'
params = {'geometry': f'{xmin},{ymin},{xmax},{ymax}',
          'geometryType': 'esriGeometryEnvelope', 'inSR': '4326',
          'spatialRel': 'esriSpatialRelIntersects', 'outFields': 'PRCL_KEY,PRCL_TYPE,GEOM_AREA',
          'returnGeometry': 'true', 'outSR': '4326', 'f': 'json'}
j = requests.get(url, params=params, timeout=40).json()
polys = []
for f in j.get('features', []):
    rings = f.get('geometry', {}).get('rings')
    if rings:
        polys.append(Polygon(rings[0]))   # exterior ring
print(f'CSG parcels in window: {len(polys)} | real erven: {len(real)}')

if polys:
    g = gpd.GeoDataFrame(geometry=polys, crs='EPSG:4326').to_crs('EPSG:32735')
    csg = list(g.geometry)
    tree = STRtree(csg)
    ious = []
    for r in real:
        best = 0.0
        for k in tree.query(r):
            inter = r.intersection(csg[k]).area
            if inter > 0:
                best = max(best, inter / (r.area + csg[k].area - inter))
        ious.append(best)
    matched = sum(1 for v in ious if v >= 0.5) / len(ious)
    print(f'mean IoU CSG-vs-real: {sum(ious)/len(ious):.2f} | matched(>0.5): {matched*100:.0f}%')
    # also: how many CSG areas look like erven (~100-1000 m2)
    erfsz = sum(1 for p in csg if 80 < p.area < 1200)
    print(f'CSG parcels of erf size (80-1200 m2): {erfsz}/{len(csg)}')
