"""update_check — notify the user inside the Velocity Nexus panel when a
newer plugin version is on the team channel, with a one-click update.

Checks the channel's plugins.xml (a ~1 KB fetch) shortly after startup and
every 30 minutes after that, fully async via QgsNetworkAccessManager — no
UI blocking, silent on any network failure. When the remote version is
newer than the installed one it shows the panel banner (and a one-time
message-bar notice per version).
"""
from __future__ import annotations

import os
import re

from qgis.core import QgsNetworkAccessManager
from qgis.PyQt.QtCore import QTimer, QUrl
from qgis.PyQt.QtNetwork import QNetworkRequest

PLUGINS_XML_URL = ("https://raw.githubusercontent.com/JohanVelo/qz31-cache/"
                   "main/plugins.xml")
PLUGIN_ZIP_URL = ("https://raw.githubusercontent.com/JohanVelo/qz31-cache/"
                  "main/FiberNetworkAutomation.zip")
# Instant delivery: the version-stamped zip on Supabase Storage — an IMMUTABLE
# public URL available the instant publish_plugin.upload_to_storage() uploads it,
# with NO GitHub raw-CDN propagation lag (the old ~1-5 min wait). The client tries
# this first (by the advertised version) and falls back to PLUGIN_ZIP_URL below.
STORAGE_ZIP_URL = ("https://hrrdohlrfrficrtphcet.supabase.co/storage/v1/object/"
                   "public/plugin-dist/FiberNetworkAutomation-{ver}.zip")
# Version the channel last advertised (announcements / plugins.xml); used to build
# the version-stamped Storage URL above. Module-level so do_upgrade() can read it.
_REMOTE_VERSION = None
PLUGIN_PKG = "FiberNetworkAutomation"
FIRST_CHECK_MS = 8000           # shortly after startup
RECHECK_MS = 30 * 60 * 1000    # every 30 minutes (plugins.xml fallback path)
# The INSTANT path: the Supabase announcements table is written the moment a
# publish runs (publish_plugin.announce_update) and is NOT behind GitHub's
# ~5-min raw-CDN cache, so polling it on a tight interval surfaces the banner
# almost immediately for anyone working in QGIS.
ANNOUNCE_FIRST_MS = 3000        # ~3 s after startup
ANNOUNCE_POLL_MS = 4 * 1000     # every 4 s — surfaces the "update available" banner within
# seconds of a publish (tiny anon SELECT). Detection NOTIFIES only; the plugin reloads when
# the operator clicks "Update now" (no silent auto-apply — see _on_announce_reply).
# Reporter replies — the office answers a ticket in Velocity Relay; the reply is
# written to ticket_notifications, and the reporter's plugin polls for its own.
NOTIF_FIRST_MS = 6000
NOTIF_POLL_MS = 10 * 1000       # every 10 s — "your ticket is done" lands near-instant


def _supabase():
    """(url, anon_key) for the announcements read. Public by design (anon key,
    SELECT-only RLS on announcements). Import from the bundled config; fall back
    to the known public values so a path hiccup never disables the check."""
    try:
        from .fibre_automation.nexus_profile import config as _cfg
        return _cfg.SUPABASE_URL, _cfg.SUPABASE_ANON_KEY
    except Exception:
        try:
            from fibre_automation.nexus_profile import config as _cfg
            return _cfg.SUPABASE_URL, _cfg.SUPABASE_ANON_KEY
        except Exception:
            return ("https://hrrdohlrfrficrtphcet.supabase.co",
                    "sb_publishable_LLMH2UZAmWGRws9j-aIWRQ_wVJ9qeOF")


def _ver_tuple(s):
    try:
        return tuple(int(x) for x in re.findall(r"\d+", s)[:4])
    except Exception:
        return (0,)


def installed_version():
    mp = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                      "metadata.txt")
    try:
        with open(mp, encoding="utf-8") as f:
            m = re.search(r"^version=([\d.]+)", f.read(), flags=re.M)
        return m.group(1) if m else "0"
    except Exception:
        return "0"


def _hot_reload():
    """Reliable SAME-SESSION reload so the new code takes effect with no QGIS
    restart. unloadPlugin alone leaves nested packages cached in sys.modules
    (Python then re-uses the OLD files) and does not always drop the Processing
    provider — so we: unload → force-remove the provider → evict every stale
    submodule → load + start. Raises on hard failure so the caller can degrade
    to a 'restart needed' message instead of leaving a half-loaded plugin."""
    import sys
    from qgis.utils import unloadPlugin, loadPlugin, startPlugin
    # a) unload — runs the plugin's own unload() (stops timers, removes
    #    toolbars/docks, removes its processing provider).
    try:
        unloadPlugin(PLUGIN_PKG)
    except Exception:
        pass
    # b) belt-and-braces: make sure the provider is really gone before re-import,
    #    else re-registration can error or duplicate.
    try:
        from qgis.core import QgsApplication
        reg = QgsApplication.processingRegistry()
        for pid in ("fibernetwork", PLUGIN_PKG):
            p = reg.providerById(pid)
            if p is not None:
                reg.removeProvider(p)
    except Exception:
        pass
    # c) evict every cached submodule so the NEW files are actually re-imported.
    #    (The running do_upgrade/_hot_reload frame keeps the old function objects
    #    alive, so evicting our own module here is safe.)
    for k in [m for m in list(sys.modules)
              if m == PLUGIN_PKG or m.startswith(PLUGIN_PKG + ".")
              or m == "fibre_automation" or m.startswith("fibre_automation.")
              or m.startswith("fiber_processing_provider")
              or m.startswith("fiber_network_plugin")]:
        try:
            del sys.modules[k]
        except Exception:
            pass
    # d) re-import + start (re-runs initGui()/initProcessing() on fresh code).
    loadPlugin(PLUGIN_PKG)
    startPlugin(PLUGIN_PKG)


def _fresh_install_zip(newer_than=None, target=None, attempts=5, delay=12):
    """Download the latest plugin zip with a CACHE-BUSTING query and extract it
    over the installed plugin folder. This bypasses BOTH GitHub's edge CDN and
    QGIS's own HTTP cache — the bug that made repeated 'Update now' clicks keep
    re-installing the SAME old version in a loop. Returns the version string in
    the downloaded zip. Raises on any failure (caller falls back).

    CDN-lag self-heal: raw.githubusercontent.com edge nodes can keep serving the
    PREVIOUS build for ~1-5 min after a publish even with a cache-busting query,
    so a click right after a release re-installs the same version. When
    `newer_than` is given we RETRY the download (fresh cache-bust each time) until
    the fetched zip is actually newer than the running version, or attempts run
    out. This runs on the QgsTask BACKGROUND thread, so the sleeps never freeze
    the UI. If every attempt is still stale we extract nothing and raise so the
    caller shows the honest 'try again in a minute' message instead of silently
    re-installing the same version."""
    import io
    import os
    import re as _re
    import time as _t
    import urllib.request
    import zipfile
    from qgis.core import QgsApplication
    plugins_dir = os.path.join(
        QgsApplication.qgisSettingsDirPath(), "python", "plugins")
    if not os.path.isdir(os.path.join(plugins_dir, PLUGIN_PKG)):
        raise RuntimeError("installed plugin folder not found")

    # INSTANT PATH — pull the exact advertised version straight from Supabase
    # Storage. It's an immutable URL available the moment publish uploads it, so
    # there's no CDN propagation lag and no retry loop. Only attempted when we know
    # which version to ask for; any miss/transient falls through to GitHub raw.
    if target:
        try:
            surl = f"{STORAGE_ZIP_URL.format(ver=target)}?t={int(_t.time())}"
            sreq = urllib.request.Request(
                surl, headers={"Cache-Control": "no-cache", "Pragma": "no-cache"})
            sdata = urllib.request.urlopen(sreq, timeout=90).read()
            szf = zipfile.ZipFile(io.BytesIO(sdata))
            if szf.testzip() is None:
                smeta = szf.read(f"{PLUGIN_PKG}/metadata.txt").decode("utf-8", "replace")
                sm = _re.search(r"^version=([\d.]+)", smeta, _re.M)
                sver = sm.group(1) if sm else None
                if sver and (newer_than is None
                             or _ver_tuple(sver) > _ver_tuple(newer_than)):
                    szf.extractall(plugins_dir)
                    return sver
        except Exception:
            pass   # Storage miss/transient — fall through to the GitHub raw path

    last_ver = None
    for _i in range(max(1, attempts)):
        url = f"{PLUGIN_ZIP_URL}?nocache={int(_t.time())}-{_i}"
        req = urllib.request.Request(
            url, headers={"Cache-Control": "no-cache", "Pragma": "no-cache"})
        data = urllib.request.urlopen(req, timeout=90).read()
        zf = zipfile.ZipFile(io.BytesIO(data))
        if zf.testzip() is not None:
            raise ValueError("downloaded zip is corrupt")
        meta = zf.read(f"{PLUGIN_PKG}/metadata.txt").decode("utf-8", "replace")
        m = _re.search(r"^version=([\d.]+)", meta, _re.M)
        ver = m.group(1) if m else None
        last_ver = ver
        # Accept this build if we're not gating on a version, or it's genuinely
        # newer than what's running (CDN has propagated the new release).
        if newer_than is None or _ver_tuple(ver) > _ver_tuple(newer_than):
            zf.extractall(plugins_dir)   # overwrite in place (pure-Python; no locks)
            # Warm the bytecode HERE, on the background thread: cold-compiling
            # ~360 fresh .py files is the biggest slice of the main-thread
            # hot-reload pause ("why does updating freeze QGIS a few seconds"
            # — JJ 2026-07-24). With __pycache__ pre-built, the reload's
            # imports are mostly disk reads. Best-effort: a failure just means
            # the old, slower pause.
            try:
                import compileall
                compileall.compile_dir(
                    os.path.join(plugins_dir, PLUGIN_PKG), quiet=2, force=True)
            except Exception:
                pass
            return ver
        # Still stale — wait for the CDN to catch up, then re-fetch.
        if _i < attempts - 1:
            _t.sleep(delay)
    raise RuntimeError(
        f"CDN still serving v{last_ver} (waiting for a build newer than "
        f"v{newer_than}) — GitHub is still propagating the release")


# Holds the in-flight update QgsTask so Python can't GC it mid-download.
_UPGRADE_TASK = None


def _msg_bar(text, ok=True):
    """Push a message-bar notice on the main thread (best-effort)."""
    try:
        from qgis.core import Qgis
        from qgis.utils import iface
        iface.messageBar().pushMessage(
            "Velocity Nexus", text,
            level=Qgis.MessageLevel.Success if ok
            else Qgis.MessageLevel.Warning, duration=7)
    except Exception:
        pass


# ── Don't-disrupt-the-Network-Planner guard ─────────────────────────────────
# A hot-reload destroys + recreates the toolbar / dock / dialogs. If a teammate is
# mid-work in the Network Planner, we must NOT yank it out from under them: we DEFER
# the in-place reload until they're idle, then apply it and re-open the dock. The
# plugin files are already on disk, so a QGIS restart would also pick it up.
_DEFER_TIMER = None
_PENDING = {"before": None, "target": None, "np_open": False}


def _planner_busy_reason():
    """Human reason if it's unsafe to hot-reload right now (active Network Planner
    work that a reload would interrupt or corrupt), else None."""
    try:
        from qgis.PyQt import sip
        from qgis.utils import plugins
        plug = plugins.get(PLUGIN_PKG)
        if plug is None:
            return None
        np = getattr(plug, "_np_dock", None)
        if np is None or sip.isdeleted(np):
            return None
        dlg = getattr(np, "_override_dlg", None)
        if dlg is not None and not sip.isdeleted(dlg) and dlg.isVisible():
            return "the Manual Override editor is open"
        if getattr(np, "_pon_per_pon_active", False):
            return "a PON-per-PON selection is in progress"
        ps = getattr(np, "_prog_strip", None)
        if ps is not None and not sip.isdeleted(ps) and ps.isVisible():
            return "a Network Planner operation is running"
    except Exception:
        return None
    return None


def _modal_open():
    """True if a modal dialog is currently open. Split out so it is unit-testable
    without monkeypatching a Qt class method in the live session."""
    try:
        from qgis.PyQt.QtWidgets import QApplication
        return QApplication.activeModalWidget() is not None
    except Exception:
        return False


def _busy_reason():
    """The GENERAL "is it unsafe to hot-reload right now" guard — not just the Network
    Planner. Returns a human reason (so we can tell the user what it's waiting for) or
    None when it's safe. An update DEFERS while this is non-None and applies the moment
    it clears, so a reload never interrupts or resets work in progress.

    Covers: Network Planner specifics (via _planner_busy_reason), an open modal dialog,
    ANY vector layer being edited with unsaved changes, an open interactive editor
    (Pole/Enclosure — a reload would destroy it mid-edit), and any tool that declared
    itself busy through the plugin's _busy() context manager."""
    r = _planner_busy_reason()
    if r:
        return r
    try:
        from qgis.utils import plugins

        # 1. A modal dialog is open — a reload underneath it would strand/kill it.
        if _modal_open():
            return "a dialog is open"

        # 2. Any vector layer is mid-edit with UNSAVED changes (editable-but-clean does
        #    NOT block — only genuinely unsaved work defers the update).
        try:
            from qgis.core import QgsProject, QgsMapLayer
            for lyr in QgsProject.instance().mapLayers().values():
                try:
                    if (lyr.type() == QgsMapLayer.LayerType.VectorLayer
                            and lyr.isEditable() and lyr.isModified()):
                        return f"you have unsaved edits in “{lyr.name()}”"
                except Exception:
                    continue
        except Exception:
            pass

        plug = plugins.get(PLUGIN_PKG)
        if plug is None:
            return None

        # 3. An interactive editor is open (delete-on-close: a reload destroys it mid-edit).
        for attr, label in (("_pole_editor_dock", "the Pole Editor"),
                            ("_enc_editor_dock", "the Enclosure Editor")):
            if _dock_visible(getattr(plug, attr, None)):
                return f"{label} is open"

        # 4. A tool declared itself busy via plug._busy(label) — a context manager that
        #    ALWAYS clears on exit (even on exception), so it can never stick permanently.
        ops = getattr(plug, "_busy_ops", None)
        if ops:
            try:
                label = sorted(str(x) for x in ops)[0]
            except Exception:
                label = "an operation"
            return f"{label} is running"
    except Exception:
        return None
    return None


def _np_dock_open():
    try:
        from qgis.PyQt import sip
        from qgis.utils import plugins
        plug = plugins.get(PLUGIN_PKG)
        np = getattr(plug, "_np_dock", None) if plug else None
        return np is not None and not sip.isdeleted(np) and np.isVisible()
    except Exception:
        return False


def _reopen_np_dock():
    """Re-open the Network Planner dock after a reload so the user isn't left
    without it (a plain unload/reload removes the dock)."""
    try:
        from qgis.utils import plugins
        plug = plugins.get(PLUGIN_PKG)
        if plug and hasattr(plug, "_open_network_planner"):
            plug._open_network_planner()
    except Exception:
        pass


# ── Restore the tool the user was in, across an update ─────────────────────────
# A hot-reload destroys every plugin dock, so the user is dropped on the home menu
# and has to navigate back into whatever they were using. Before the reload we
# snapshot which of these tools were open; after it we re-open them on the fresh
# plugin so the user lands right back where they were (Span Inspector, Pole Editor,
# Enclosures…), not on the home screen.
#   key -> (opener_method_name, plugin_attr_name | None)
# attr None => the tool's open-state is a module-level dock, checked specially below.
_RESTORABLE = {
    "network_planner": ("_open_network_planner", "_np_dock"),
    "pole_editor":     ("_open_pole_editor",     "_pole_editor_dock"),
    "route_viewer":    ("_open_route_viewer",    "_route_viewer_dock"),
    "enc_editor":      ("_open_enc_editor",      "_enc_editor_dock"),
    "workflow":        ("_open_workflow_dock",   "_workflow_dock"),
    "home":            ("_show_home_panel",      "_home_panel"),
    "span_inspector":  ("_open_span_inspector",  None),   # module dock (span_inspector._PANEL)
    "erven_studio":    ("_open_erven_studio",    None),   # module singleton (ErvenStudio._dock)
}
# Deliberately OUT of this registry (every shipped dockable panel is accounted for):
#   • Bridge dock — owned by the SEPARATE QGISBridgePlugin, which our update never
#     reloads, so it survives untouched. Nothing to restore.
#   • Home panel is auto-reinstalled by the plugin on every start; it is listed above
#     only so an explicit raise keeps it consistent — it can never be "lost".
#   • Team Monitor — JJ-only, dock nested deep inside nexus_profile.manager; low value,
#     hardest detection. Left for a follow-up rather than risk the reload path here.
#   • Splice Viewer — a one-shot Excel export, not a dock. Nothing to reopen.


def _dock_visible(obj):
    """True if a Qt dock object is alive (not C++-deleted) and visible."""
    try:
        from qgis.PyQt import sip
        return obj is not None and not sip.isdeleted(obj) and obj.isVisible()
    except Exception:
        return False


def _span_inspector_open():
    try:
        try:
            from .span_inspector import is_open as _si
        except ImportError:
            from FiberNetworkAutomation.span_inspector import is_open as _si
        return bool(_si())
    except Exception:
        return False


def _erven_studio_open():
    """True if the Erven Studio dock is open + visible. Its state is a module-level
    singleton (ErvenStudio._dock), reached via the plugin's cached module loader."""
    try:
        from qgis.utils import plugins
        plug = plugins.get(PLUGIN_PKG)
        if plug is None or not hasattr(plug, "_erven_studio_module"):
            return False
        mod = plug._erven_studio_module()
        dock = getattr(getattr(mod, "ErvenStudio", None), "_dock", None) if mod else None
        return _dock_visible(dock)
    except Exception:
        return False


def _open_tools_snapshot():
    """Which restorable tools are open RIGHT NOW — called BEFORE a hot-reload, while
    the old docks still exist. Returns a list of registry keys in registry order."""
    keys = []
    try:
        from qgis.utils import plugins
        plug = plugins.get(PLUGIN_PKG)
        if plug is None:
            return keys
        for key, (_opener, attr) in _RESTORABLE.items():
            try:
                if attr is None:
                    if key == "span_inspector" and _span_inspector_open():
                        keys.append(key)
                    elif key == "erven_studio" and _erven_studio_open():
                        keys.append(key)
                elif _dock_visible(getattr(plug, attr, None)):
                    keys.append(key)
            except Exception:
                pass
    except Exception:
        pass
    return keys


def _tool_dock(plug, key):
    """The live dock object for a registry key (attr-based docks only), or None.
    span_inspector (attr None) self-restores via QgsSettings, so it needs no hook."""
    attr = _RESTORABLE.get(key, (None, None))[1]
    if not attr:
        return None
    try:
        return getattr(plug, attr, None)
    except Exception:
        return None


def _snapshot_states(keys):
    """Capture each open tool's within-tool state (active tab, scroll, selection…) via an
    optional ``dock._snapshot_state()`` hook, BEFORE the reload while the docks are still
    alive. Returns ``{key: state}``. Best-effort + fully guarded: a tool with no hook, or
    one that throws mid-capture, is simply skipped — it never aborts the other tools' save."""
    states = {}
    try:
        from qgis.utils import plugins
        plug = plugins.get(PLUGIN_PKG)
        if plug is None:
            return states
        for key in keys:
            try:
                dock = _tool_dock(plug, key)
                fn = getattr(dock, "_snapshot_state", None) if dock is not None else None
                if callable(fn):
                    states[key] = fn()
            except Exception:
                pass
    except Exception:
        pass
    return states


def _reopen_tools(keys, states=None):
    """Re-open the tools that were open before the reload, on the FRESH plugin, so the
    user lands back in them instead of the home menu — and, where a tool offers a
    ``_restore_state`` hook, put it back where it was (active tab, selection…). Deferred
    one tick so the freshly reloaded plugin is fully initialised first; every opener AND
    every restore is guarded so one failure can never break the update or stop the rest."""
    if not keys:
        return
    states = states or {}

    def _do():
        try:
            from qgis.utils import plugins
            plug = plugins.get(PLUGIN_PKG)
            if plug is None:
                return
            for key in keys:
                opener = _RESTORABLE.get(key, (None, None))[0]
                fn = getattr(plug, opener, None) if opener else None
                if callable(fn):
                    try:
                        fn()
                    except Exception:
                        pass
                if key in states:
                    try:
                        dock = _tool_dock(plug, key)
                        rfn = getattr(dock, "_restore_state", None) if dock is not None else None
                        if callable(rfn):
                            rfn(states[key])
                    except Exception:
                        pass
        except Exception:
            pass

    try:
        QTimer.singleShot(0, _do)
    except Exception:
        _do()


def cancel_deferred():
    """Stop + clear the deferred-reload poller. Called before a reload and from
    the plugin's unload() so the module-global timer can never outlive the
    instance it would reload (orphaned timer / double hot-reload)."""
    global _DEFER_TIMER, _PENDING
    try:
        if _DEFER_TIMER is not None:
            _DEFER_TIMER.stop()
    except Exception:
        pass
    _DEFER_TIMER = None
    _PENDING = {}


def _plugin_loaded():
    try:
        from qgis.utils import plugins
        return plugins.get(PLUGIN_PKG) is not None
    except Exception:
        return False


def _ensure_loaded():
    """NEVER-STRAND guarantee: make sure the plugin is loaded after a reload. The
    in-session hot-reload of a *running* plugin is the fragile part; a clean
    loadPlugin/startPlugin from an unloaded state is reliable. Returns True if loaded."""
    if _plugin_loaded():
        return True
    try:
        from qgis.utils import loadPlugin, startPlugin
        loadPlugin(PLUGIN_PKG)
        startPlugin(PLUGIN_PKG)
    except Exception:
        pass
    return _plugin_loaded()


def _restart_modal(ver):
    """Unmissable modal if even a clean re-load can't complete — the operator is never
    left silently without the plugin."""
    try:
        from qgis.PyQt.QtWidgets import QMessageBox
        from qgis.utils import iface
        QMessageBox.information(
            iface.mainWindow(), "Velocity Nexus — update installed",
            f"Velocity Nexus v{ver} is installed, but it couldn't finish reloading in "
            f"place.\n\nPlease RESTART QGIS to finish — your project and sign-in are safe.")
    except Exception:
        pass


def _apply_reload(before, target, np_open):
    """Hot-reload the new code, then GUARANTEE the plugin is back. The in-session reload
    of a running plugin can occasionally fail; if so we do a clean re-load (reliable) and,
    only if even that fails, show a clear 'restart QGIS' modal. It can NEVER silently
    leave the operator with a missing/broken plugin."""
    # Stop the deferred poller BEFORE evicting this module — otherwise the stale
    # timer survives the reload and a second poller can spin up post-eviction.
    cancel_deferred()
    # Snapshot which tools are open NOW (while the old docks still exist) so we can
    # re-open them after the reload — the user lands back where they were, not on the
    # home menu. Fall back to the NP dock (old behaviour) if the snapshot found nothing
    # but the caller knew the planner was open.
    open_tools = _open_tools_snapshot()
    if not open_tools and np_open:
        open_tools = ["network_planner"]
    # …and capture each open tool's within-tool place (active tab, selection) while the
    # docks are still alive, so we can restore it after the reopen. Best-effort/guarded.
    open_states = _snapshot_states(open_tools)
    # Announce the pause BEFORE it happens and force a paint, so the coming
    # few seconds read as "applying update", never as "QGIS froze" (JJ
    # 2026-07-24). repaint() only — no event dispatch, no re-entrancy.
    try:
        _msg_bar("Applying update v%s — QGIS pauses a few seconds while the "
                 "new code loads…" % (target or ""), ok=True)
        from qgis.utils import iface as _ifc
        if _ifc is not None:
            _ifc.mainWindow().repaint()
    except Exception:
        pass
    reload_ok = True
    try:
        _hot_reload()
    except Exception:
        reload_ok = False
    # NEVER-STRAND: verify the plugin actually loaded; clean-load if the hot-reload left
    # it down. Only escalate to "restart QGIS" if even a fresh load fails.
    if not _ensure_loaded():
        _restart_modal(target or installed_version())
        return
    now = installed_version()
    if _ver_tuple(now) <= _ver_tuple(before) and (
            not target or _ver_tuple(now) < _ver_tuple(target)):
        _msg_bar(f"Update didn't take (still v{now}) — try again in a minute.", ok=False)
        return
    _reopen_tools(open_tools, open_states)
    if reload_ok:
        _msg_bar(f"Updated to v{now} — reloaded, no restart needed.")
    else:
        _msg_bar(f"Updated to v{now} — recovered in place. If anything looks off, "
                 f"restart QGIS.", ok=True)


def _try_deferred_apply():
    """Timer tick: apply the pending update the moment the user goes idle."""
    if _busy_reason():
        return  # still busy — wait for the next tick
    global _DEFER_TIMER
    if _DEFER_TIMER is not None:
        _DEFER_TIMER.stop()
    p = _PENDING
    _apply_reload(p.get("before"), p.get("target"),
                  _np_dock_open() or p.get("np_open"))


def _schedule_deferred_apply(before, target, np_open):
    """Remember the pending update and poll until the planner is idle, then apply."""
    global _DEFER_TIMER, _PENDING
    _PENDING = {"before": before, "target": target, "np_open": np_open}
    try:
        from qgis.PyQt.QtCore import QTimer
        if _DEFER_TIMER is None:
            _DEFER_TIMER = QTimer()
            _DEFER_TIMER.setInterval(15000)  # re-check every 15s
            _DEFER_TIMER.timeout.connect(_try_deferred_apply)
        if not _DEFER_TIMER.isActive():
            _DEFER_TIMER.start()
    except Exception:
        pass


def _finish_upgrade(before, target, download_failed):
    """MAIN-THREAD tail of the upgrade: optional installer fallback, then a
    NON-DISRUPTIVE hot-reload — deferred while the user is actively working in the
    Network Planner, and the dock is re-opened afterwards. Called from the QgsTask's
    on_finished callback (main thread) or the synchronous fallback path."""
    # 1. The direct background download failed. DO NOT fall back to QGIS's native
    # installer (pyplugin_installer.installPlugin): it compares the release against
    # QGIS's CACHED plugin-repo manifest, which lags a fresh publish, so on a genuine
    # UPGRADE (e.g. 2.5.235 → 2.5.236) it shows a FALSE "Are you sure you want to
    # downgrade the plugin to the latest available version? The installed one is
    # newer!" prompt. That confuses teammates into clicking No and missing a critical
    # update. Instead retry the IMMUTABLE, no-CDN-lag Supabase zip once more (quick —
    # no retry sleeps), and only ask for a re-click if even that misses. This way the
    # misleading native "downgrade?" dialog can never appear on an upgrade.
    if download_failed:
        retry_ver = None
        try:
            retry_ver = _fresh_install_zip(
                newer_than=before, target=(target or _REMOTE_VERSION),
                attempts=1, delay=0)
        except Exception:
            retry_ver = None
        if not retry_ver:
            _msg_bar("Update is still finishing on the server (about a minute) — "
                     "click “Update now” again shortly. No QGIS restart needed.", ok=False)
            return
        target = retry_ver
    # 2. don't yank the rug — if the planner is busy, defer + apply when idle.
    np_open = _np_dock_open()
    reason = _busy_reason()
    if reason:
        _msg_bar(
            f"Update v{target or ''} is ready — it'll apply automatically the moment "
            f"you finish ({reason}), so your Network Planner work isn't interrupted.",
            ok=True)
        _schedule_deferred_apply(before, target, np_open)
        return
    # 3. safe now — reload in place and restore the dock if it was open.
    _apply_reload(before, target, np_open)
    # (The premium "What's New" board is shown once-per-version by the plugin's
    # _maybe_whats_new on (re)start after the hot-reload — single path, no duplicate.)


def do_upgrade():
    """Download the latest version and HOT-RELOAD it in-session — no QGIS
    restart. Module-level on purpose (runs from a timer, detached from the widget
    being replaced).

    The download + zip-extract (the slow, network-bound part) runs in a QgsTask
    on a BACKGROUND thread so it can never freeze the QGIS UI — the audited
    main-thread block. Only the hot-reload + verify run back on the main thread
    (in the task's on_finished callback), since they touch QGIS/Qt objects.

    Robust against the cache-loop: the zip is fetched with a cache-busting query
    so neither GitHub's CDN nor QGIS's HTTP cache can serve a stale build, and we
    VERIFY the installed version actually advanced before claiming success — so a
    click can never silently re-install the same version and re-prompt forever.
    Degrade-not-crash with clear messages at every step."""
    before = installed_version()
    want = _REMOTE_VERSION   # advertised version → instant Supabase Storage fetch

    # Background path: QgsTask keeps the UI responsive during the download.
    try:
        from qgis.core import QgsApplication, QgsTask
        state = {"target": None, "failed": False}

        def _bg(_task):
            # BACKGROUND THREAD — pure network + file I/O only, no QGIS UI.
            # Instant: pull the advertised version from Supabase Storage; if that
            # misses, retry GitHub raw through CDN propagation lag until the fetched
            # build is newer than what's running (the sleeps are safe off-thread).
            try:
                state["target"] = _fresh_install_zip(newer_than=before, target=want)
            except Exception:
                state["failed"] = True
            return True

        def _on_finished(_exc, _result=None):
            # MAIN THREAD — safe to touch QGIS/Qt here.
            global _UPGRADE_TASK
            try:
                _finish_upgrade(before, state["target"], state["failed"])
            finally:
                _UPGRADE_TASK = None

        global _UPGRADE_TASK
        _UPGRADE_TASK = QgsTask.fromFunction(
            "Velocity Nexus update", _bg, on_finished=_on_finished)
        QgsApplication.taskManager().addTask(_UPGRADE_TASK)
        return
    except Exception:
        # QgsTask unavailable (very old QGIS) — fall back to the original
        # synchronous path so the update still works, just on the main thread.
        pass

    target = None
    try:
        target = _fresh_install_zip(target=want)
    except Exception:
        _finish_upgrade(before, None, True)
        return
    _finish_upgrade(before, target, False)


class UpdateChecker:
    """Owns the timer + async fetch. panel_getter() -> VelocityHomePanel."""

    def __init__(self, iface, panel_getter, user_getter=None):
        self.iface = iface
        self._panel_getter = panel_getter
        self._user_getter = user_getter   # () -> current user's display_name/username
        self._notified_version = None
        self._reply = None
        self._nreply = None             # in-flight reporter-replies fetch
        self._areply = None             # in-flight announcements fetch
        self._manual = False            # True = a user pressed "Check for updates"
        self._bar_item = None           # persistent message-bar notification
        self._timer = QTimer(iface.mainWindow())
        self._timer.timeout.connect(self.check_now)
        self._timer.start(RECHECK_MS)
        self._first = QTimer(iface.mainWindow())   # owned -> stop() can kill it
        self._first.setSingleShot(True)
        self._first.timeout.connect(self.check_now)
        self._first.start(FIRST_CHECK_MS)
        # INSTANT path — poll the announcements table (no CDN lag) every ~10 s so
        # a fresh publish surfaces the banner almost immediately while working.
        # Per-client jitter (0-2.5 s) so a whole team doesn't hit Supabase in lockstep.
        import random as _rnd
        _jit = _rnd.randint(0, 2500)
        self._atimer = QTimer(iface.mainWindow())
        self._atimer.timeout.connect(self.check_announcements)
        self._atimer.start(ANNOUNCE_POLL_MS + _jit)
        self._afirst = QTimer(iface.mainWindow())
        self._afirst.setSingleShot(True)
        self._afirst.timeout.connect(self.check_announcements)
        self._afirst.start(ANNOUNCE_FIRST_MS)
        # reporter-replies poll (office answers from Velocity Relay)
        self._ntimer = QTimer(iface.mainWindow())
        self._ntimer.timeout.connect(self.check_replies)
        self._ntimer.start(NOTIF_POLL_MS + _jit)
        self._nfirst = QTimer(iface.mainWindow())
        self._nfirst.setSingleShot(True)
        self._nfirst.timeout.connect(self.check_replies)
        self._nfirst.start(NOTIF_FIRST_MS)

    def stop(self):
        for t in (self._timer, getattr(self, "_first", None),
                  getattr(self, "_atimer", None), getattr(self, "_afirst", None),
                  getattr(self, "_ntimer", None), getattr(self, "_nfirst", None)):
            try:
                t.stop()
                t.deleteLater()
            except Exception:
                pass
        for r in (self._reply, getattr(self, "_areply", None),
                  getattr(self, "_nreply", None)):
            if r is not None:
                try:
                    r.abort()
                except Exception:
                    pass
        self._pop_bar()
        try:
            if getattr(self, "_popup", None) is not None:
                self._popup.close()
                self._popup = None
        except Exception:
            pass

    def _pop_bar(self):
        if self._bar_item is not None:
            try:
                self.iface.messageBar().popWidget(self._bar_item)
            except Exception:
                pass
            self._bar_item = None

    # ── check ────────────────────────────────────────────────────────────
    def check_now_manual(self, *_):
        """Entry point for the panel/toolbar 'Check for updates' button. Unlike
        the silent timer check, this always gives feedback — 'You're on the
        latest', the update prompt, or 'couldn't check'."""
        self._manual = True
        try:
            from qgis.core import Qgis
            self.iface.messageBar().pushMessage(
                "Velocity Nexus", "Checking for updates…",
                level=Qgis.MessageLevel.Info, duration=2)
        except Exception:
            pass
        # If a silent fetch is already in flight, the in-flight reply now honours
        # the manual flag — no need to start a second request.
        self.check_now()

    def _manual_feedback(self, text, ok=True):
        if not self._manual:
            return
        self._manual = False
        try:
            from qgis.core import Qgis
            self.iface.messageBar().pushMessage(
                "Velocity Nexus", text,
                level=Qgis.MessageLevel.Success if ok
                else Qgis.MessageLevel.Warning,
                duration=5)
        except Exception:
            pass

    def _notify(self, local, remote):
        """Surface an available update. The quiet in-dock panel banner refreshes
        every time (so it stays visible while behind), but the attention-grabbing
        popup + message bar fire ONLY ONCE per version — the seen version is
        persisted in QgsSettings so neither a 60-second re-poll nor a plugin
        reload can turn it into a popup loop."""
        self._notified_version = remote
        self._refresh_banner(remote)
        # Decide once-per-version: only show the popup/bar when this version was
        # NOT already surfaced. On a QgsSettings failure (rare locked/corrupt
        # profile) fall back to an in-memory flag so we still honour the "once,
        # no loop" contract instead of re-firing on every poll.
        already_seen = False
        try:
            from qgis.core import QgsSettings
            s = QgsSettings()
            already_seen = (s.value("VelocityFibre/update_popup_version") == remote)
            s.setValue("VelocityFibre/update_popup_version", remote)
        except Exception:
            already_seen = (getattr(self, "_notified_locally", None) == remote)
            self._notified_locally = remote
        if already_seen:
            # A manual "Check for updates" click would otherwise be silent here —
            # the popup/bar already fired earlier — so give explicit feedback.
            self._manual_feedback("Update available — see the notification above.")
            return                      # already popped this version — no loop
        self._manual = False            # the banner/popup below is the feedback
        self._show_bar(local, remote)
        self._show_popup(local, remote)

    def check_now(self):
        if self._reply is not None:     # a fetch is already in flight
            return
        try:
            req = QNetworkRequest(QUrl(PLUGINS_XML_URL))
            req.setRawHeader(b"Cache-Control", b"no-cache")
            try:
                req.setTransferTimeout(15000)   # Qt 5.15+: never hang forever
            except Exception:
                pass
            self._reply = QgsNetworkAccessManager.instance().get(req)
            self._reply.finished.connect(self._on_reply)
        except Exception:
            self._reply = None          # network stack unavailable — retry later

    # ── instant path: poll the announcements table (no CDN lag) ────────────
    def check_announcements(self):
        if getattr(self, "_areply", None) is not None:
            return                      # a fetch is already in flight
        try:
            url, key = _supabase()
            q = (f"{url}/rest/v1/announcements?select=title,created_at"
                 "&order=created_at.desc&limit=5")
            req = QNetworkRequest(QUrl(q))
            req.setRawHeader(b"apikey", key.encode())
            req.setRawHeader(b"Authorization", b"Bearer " + key.encode())
            req.setRawHeader(b"Cache-Control", b"no-cache")
            try:
                req.setTransferTimeout(15000)
            except Exception:
                pass
            self._areply = QgsNetworkAccessManager.instance().get(req)
            self._areply.finished.connect(self._on_announce_reply)
        except Exception:
            self._areply = None

    def _on_announce_reply(self):
        reply, self._areply = getattr(self, "_areply", None), None
        if reply is None:
            return
        try:
            # Qt6 BUG FIX (live-diagnosed 2026-06-25): reply.error() is a NetworkError
            # ENUM that int() CANNOT convert — `int(reply.error())` raised TypeError,
            # which the except below swallowed, silently killing the instant poll since
            # the Qt6 port (update_popup_version stuck at 2.5.214). Gate on the plain-int
            # HTTP status instead — no enum, can't blow up.
            status = reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute)
            if status != 200:              # offline / error — silently retry later
                return
            body = bytes(reply.readAll()).decode("utf-8", "replace")
        except Exception:
            return
        finally:
            try:
                reply.deleteLater()
            except Exception:
                pass
        # newest "Update available - vX" version across the recent rows
        best = None
        for mt in re.finditer(r'"title"\s*:\s*"([^"]*)"', body):
            title = mt.group(1)
            if "update available" not in title.lower():
                continue
            mv = re.search(r"v?(\d+(?:\.\d+){1,3})", title)
            if mv and (best is None
                       or _ver_tuple(mv.group(1)) > _ver_tuple(best)):
                best = mv.group(1)
        if not best:
            return
        global _REMOTE_VERSION
        _REMOTE_VERSION = best           # so do_upgrade pulls this exact version from Storage
        local = installed_version()
        if _ver_tuple(best) <= _ver_tuple(local):
            return                      # already current — nothing to show
        try:                            # verifiable trail so this can't silently die again
            from qgis.core import Qgis, QgsMessageLog
            QgsMessageLog.logMessage(
                f"update available: v{best} (installed v{local}) — notifying",
                "Velocity Nexus", Qgis.MessageLevel.Info)
        except Exception:
            pass
        self._notify(local, best)
        # JJ 2026-06-25: NO silent auto-apply. Detection only NOTIFIES (popup + bar);
        # the plugin reloads ONLY when the operator clicks "Update now" — so an update
        # can never yank the plugin out from under them mid-work.

    # ── reporter replies: poll ticket_notifications for THIS user ──────────
    def _recipient(self):
        try:
            return (self._user_getter() or "").strip() if self._user_getter else ""
        except Exception:
            return ""

    def _token_and_cfg(self):
        """(user_token, config_module) — for the server-verified notifications path.
        Returns ('', None) if unavailable so the caller uses the anon fallback."""
        _cfg = None
        get_user_token = None
        try:
            from .fibre_automation.nexus_profile import config as _cfg
            from .fibre_automation.nexus_profile.backend import get_user_token
        except Exception:
            try:
                from fibre_automation.nexus_profile import config as _cfg
                from fibre_automation.nexus_profile.backend import get_user_token
            except Exception:
                return "", None
        try:
            return (get_user_token() or ""), _cfg
        except Exception:
            return "", _cfg

    def check_replies(self):
        if getattr(self, "_nreply", None) is not None:
            return                          # a fetch is already in flight
        who = self._recipient()
        if not who:
            return                          # not signed in / unknown — nothing to poll
        try:
            import urllib.parse
            url, key = _supabase()
            tok, _cfg = self._token_and_cfg()
            if tok and _cfg is not None:
                # Token path: identity is SERVER-VERIFIED from the token (the edge
                # fn ignores the spoofable u param).
                q = f"{_cfg.FUNCTIONS_URL}/my-notifications?since=0"
            else:
                # Grace fallback (not logged in yet): filtered SECURITY DEFINER RPC.
                q = (f"{url}/rest/v1/rpc/my_notifications?u={urllib.parse.quote(who)}"
                     f"&order=id.desc&limit=10")
            req = QNetworkRequest(QUrl(q))
            req.setRawHeader(b"apikey", key.encode())
            req.setRawHeader(b"Authorization", b"Bearer " + key.encode())
            if tok:
                req.setRawHeader(b"X-User-Token", tok.encode())
            req.setRawHeader(b"Cache-Control", b"no-cache")
            try:
                req.setTransferTimeout(15000)
            except Exception:
                pass
            self._nreply = QgsNetworkAccessManager.instance().get(req)
            self._nreply.finished.connect(self._on_replies_reply)
        except Exception:
            self._nreply = None

    def _on_replies_reply(self):
        reply, self._nreply = getattr(self, "_nreply", None), None
        if reply is None:
            return
        try:
            code = reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute)
            if code == 401:                 # token expired/invalid -> drop it; next poll uses anon
                try:
                    from .fibre_automation.nexus_profile.backend import set_user_token
                except Exception:
                    from fibre_automation.nexus_profile.backend import set_user_token
                set_user_token("")
                return
            # Qt6 BUG FIX: int(reply.error()) raises on the NetworkError enum — gate on
            # the plain-int HTTP status (already read into `code` above) instead.
            if code != 200:                 # offline / error — retry later
                return
            body = bytes(reply.readAll()).decode("utf-8", "replace")
        except Exception:
            return
        finally:
            try:
                reply.deleteLater()
            except Exception:
                pass
        try:
            import json
            rows = json.loads(body)
            if not isinstance(rows, list) or not rows:
                return
        except Exception:
            return
        from qgis.core import QgsSettings
        s = QgsSettings()
        try:
            last = int(s.value("VelocityFibre/relay_last_notif", 0) or 0)
        except Exception:
            last = 0
        mx = max(int(r.get("id", 0) or 0) for r in rows)
        # First ever poll on this machine: adopt the high-water mark silently so
        # we never dump the whole reply history as "new".
        if last == 0:
            s.setValue("VelocityFibre/relay_last_notif", mx)
            return
        fresh = [r for r in rows if int(r.get("id", 0) or 0) > last]
        if not fresh:
            return
        s.setValue("VelocityFibre/relay_last_notif", mx)
        fresh.sort(key=lambda r: int(r.get("id", 0) or 0))   # oldest first
        try:
            from qgis.core import Qgis
            for r in fresh[-3:]:            # show at most the latest 3, rest are marked seen
                tid = r.get("ticket_id")
                raw = str(r.get("body") or "")
                txt = raw.replace("\n", " ").strip()
                if len(txt) > 220:
                    txt = txt[:217] + "…"
                # a "done" notice is the update-board moment → sticky green; ordinary
                # office replies stay brief & informational.
                is_done = ("✅" in raw) or ("is done" in raw.lower()) or ("has been built" in raw.lower()) or ("has been fixed" in raw.lower())
                if is_done:
                    title = "✅ Velocity Nexus — your ticket" + (f" #{tid}" if tid else "") + " is done"
                    lvl, dur = Qgis.MessageLevel.Success, 0          # sticky until dismissed
                else:
                    title = "Velocity Nexus — reply on your ticket" + (f" #{tid}" if tid else "")
                    lvl, dur = Qgis.MessageLevel.Info, 14
                self.iface.messageBar().pushMessage(title, txt, level=lvl, duration=dur)
        except Exception:
            pass

    def _on_reply(self):
        reply, self._reply = self._reply, None
        if reply is None:
            return
        try:
            # Qt6 BUG FIX: int(reply.error()) raises on the NetworkError enum (and was
            # swallowed by the except below) — gate on the plain-int HTTP status.
            status = reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute)
            if status != 200:
                self._manual_feedback(
                    "Couldn't reach the update server — check your connection "
                    "and try again.", ok=False)
                return                  # offline etc. — silently retry later
            xml = bytes(reply.readAll()).decode("utf-8", "replace")
        except Exception:
            self._manual_feedback(
                "Couldn't read the update info — try again shortly.", ok=False)
            return
        finally:
            try:
                reply.deleteLater()
            except Exception:
                pass
        m = re.search(r"<version>([\d.]+)</version>", xml)
        if not m:
            self._manual_feedback(
                "Couldn't read the update info — try again shortly.", ok=False)
            return
        remote = m.group(1)
        global _REMOTE_VERSION
        _REMOTE_VERSION = remote         # so do_upgrade pulls this exact version from Storage
        local = installed_version()
        if _ver_tuple(remote) <= _ver_tuple(local):
            self._manual_feedback(
                f"You're on the latest version (v{local}).")
            return
        # _notify shows the banner/popup as feedback; it also clears _manual after
        # giving an explicit message-bar notice (covers the already-popped path
        # where the popup/bar early-return otherwise leaves a manual click silent).
        self._notify(local, remote)

    def _show_popup(self, local, remote):
        """Floating themed window — the message bar lives over the map
        canvas, which is INVISIBLE on the QGIS start page (Recent Projects),
        so a freshly-opened QGIS would never see the update. This popup is
        visible everywhere. Once per version per session."""
        try:
            from qgis.PyQt.QtCore import Qt
            from qgis.PyQt.QtWidgets import (QDialog, QFrame, QHBoxLayout, QLabel,
                                             QPushButton, QVBoxLayout)
            old = getattr(self, "_popup", None)
            if old is not None:
                try:
                    old.close()
                except Exception:
                    pass
            # premium Mission-Control look, matching the What's New board (palette
            # imported from whats_new = single source of truth, degrade-safe).
            try:
                from . import whats_new as _wn
            except Exception:
                import whats_new as _wn
            BG, BORDER, INK, SUB, CYAN, DARK = (_wn._BG, _wn._BORDER, _wn._INK,
                                                _wn._SUB, _wn._CYAN, _wn._DARKINK)

            dlg = QDialog(self.iface.mainWindow())
            dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
            dlg.setWindowTitle("Velocity Nexus — Update available")
            dlg.setMinimumWidth(460)
            dlg.setStyleSheet(f"QDialog{{background:{BG};}}")
            root = QVBoxLayout(dlg)
            root.setContentsMargins(0, 0, 0, 0)
            root.setSpacing(0)

            # header band: red knight kicker + title + version jump
            head = QFrame()
            head.setStyleSheet(
                f"QFrame{{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,"
                f"stop:0 #0B1019, stop:1 #070A11);border-bottom:1px solid {BORDER};}}")
            hl = QVBoxLayout(head)
            hl.setContentsMargins(22, 18, 22, 15)
            hl.setSpacing(3)
            kick = QLabel('<span style="color:#EF4444;font-size:14px;">&#9822;</span>'
                          '&nbsp;&nbsp;VELOCITY NEXUS')
            kick.setTextFormat(Qt.TextFormat.RichText)
            kick.setStyleSheet(
                f"color:{CYAN};font-family:'Consolas','JetBrains Mono',monospace;"
                f"font-size:10px;font-weight:700;letter-spacing:2px;background:transparent;")
            title = QLabel("Update available")
            title.setStyleSheet(
                f"color:{INK};font-family:'Segoe UI';font-size:23px;font-weight:800;"
                f"background:transparent;")
            jump = QLabel(f'v{local}&nbsp;&nbsp;<span style="color:{CYAN};">&#8594;</span>'
                          f'&nbsp;&nbsp;<span style="color:{CYAN};font-weight:800;">v{remote}</span>')
            jump.setTextFormat(Qt.TextFormat.RichText)
            jump.setStyleSheet(f"color:{SUB};font-size:13px;font-weight:700;background:transparent;")
            hl.addWidget(kick)
            hl.addWidget(title)
            hl.addWidget(jump)
            root.addWidget(head)

            # body: invite + reassurance
            body = QVBoxLayout()
            body.setContentsMargins(22, 15, 22, 6)
            body.setSpacing(7)
            msg = QLabel("New tools, fixes &amp; improvements are ready.")
            msg.setTextFormat(Qt.TextFormat.RichText)
            msg.setWordWrap(True)
            msg.setStyleSheet(f"color:{INK};font-size:13px;font-weight:600;background:transparent;")
            keep = QLabel("One click takes you straight to the latest — your activation is "
                          "kept and no restart is needed. You'll see a What's New summary "
                          "after it updates.")
            keep.setWordWrap(True)
            keep.setStyleSheet(f"color:{SUB};font-size:11px;background:transparent;")
            body.addWidget(msg)
            body.addWidget(keep)
            root.addLayout(body)

            # footer: Later (ghost) + Update now (cyan)
            foot = QFrame()
            foot.setStyleSheet(f"QFrame{{background:{BG};border-top:1px solid {BORDER};}}")
            fr = QHBoxLayout(foot)
            fr.setContentsMargins(18, 12, 18, 14)
            fr.addStretch(1)
            later = QPushButton("Later")
            later.setStyleSheet(
                f"QPushButton{{background:transparent;color:{SUB};border:1px solid {BORDER};"
                f"border-radius:6px;padding:8px 18px;font-size:12px;font-weight:700;}}"
                f"QPushButton:hover{{color:{INK};}}")
            later.clicked.connect(dlg.close)
            go = QPushButton("Update now")
            go.setCursor(Qt.CursorShape.PointingHandCursor)
            go.setStyleSheet(
                f"QPushButton{{background:{CYAN};color:{DARK};border:none;border-radius:6px;"
                f"padding:8px 22px;font-size:12px;font-weight:800;}}"
                f"QPushButton:hover{{background:#5BF0FF;}}"
                f"QPushButton:pressed{{background:#13C6DE;}}")

            def _go():
                go.setEnabled(False)
                go.setText("Updating…")
                self.upgrade()
                dlg.close()

            go.clicked.connect(_go)
            fr.addWidget(later)
            fr.addWidget(go)
            root.addWidget(foot)

            dlg.finished.connect(dlg.deleteLater)
            self._popup = dlg
            try:
                from .nexus_dock import chrome_dialog
                chrome_dialog(dlg)
            except Exception:
                pass
            dlg.show()
            dlg.raise_()
            dlg.activateWindow()
        except Exception:
            pass

    def _show_bar(self, local, remote):
        """Persistent, can't-miss notification over the canvas with its own
        Update button — stays until the operator acts or dismisses it."""
        try:
            from qgis.core import Qgis
            from qgis.PyQt.QtWidgets import QPushButton
            bar = self.iface.messageBar()
            self._pop_bar()
            item = bar.createMessage(
                "Velocity Nexus",
                f"🚀 Update available — v{local} → v{remote} with new tools "
                "and fixes.")
            btn = QPushButton("Update now")

            def _go():
                btn.setEnabled(False)
                btn.setText("Updating…")
                self.upgrade()

            btn.clicked.connect(_go)
            item.layout().addWidget(btn)
            # duration 0 = stays on screen until clicked or dismissed
            self._bar_item = bar.pushWidget(item, Qgis.MessageLevel.Info, 0)
        except Exception:
            pass

    def _refresh_banner(self, remote):
        # Suppress the "Update available" banner on the DEV machine (the QGIS
        # Bridge plugin is loaded there, or VF_DEV is set). Dev auto-syncs the
        # latest code, so the banner is noise and the one-click update triggers a
        # confusing QGIS-installer "downgrade?" prompt (installed code is newer
        # than the published zip). Teammates — no bridge — still get the banner.
        try:
            import os as _os
            from qgis.utils import plugins as _plg
            if _os.environ.get("VF_DEV") or _plg.get("QGISBridgePlugin") is not None:
                return
        except Exception:
            pass
        panel = None
        try:
            panel = self._panel_getter()
        except Exception:
            pass
        if panel is not None:
            try:
                panel.show_update_banner(remote, self.upgrade)
            except Exception:
                pass

    # ── upgrade ──────────────────────────────────────────────────────────
    def upgrade(self):
        self._pop_bar()                 # the old item must not outlive us
        try:
            self.iface.messageBar().pushInfo(
                "Velocity Nexus", "Updating — QGIS will reload the plugin…")
        except Exception:
            pass
        # detach from the panel's call stack before the plugin replaces itself
        QTimer.singleShot(50, do_upgrade)
