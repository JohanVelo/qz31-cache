# -*- coding: utf-8 -*-
"""Label My Network — ATTRIBUTE-TABLE edition.

A dockable "Label My Network" that looks and works like the QGIS attribute
table (planners already know it): a layer rail on the left, a Field-Calculator
style "ƒ NEW LABEL =" rule bar, and a grid showing each feature's CURRENT label
next to the live-computed NEW LABEL (red where it needs a pole).  Nothing is
written until the operator presses Label; a backup is taken first and a
one-click UNDO is offered.

# claude:intent MUTATE — user asked (verbatim): "yes" (build the attribute-table
# Label My Network into QGIS, per the approved mock). The ONLY writes are the
# operator-triggered Label button (label_recipe.apply, backup-first) and its
# one-click UNDO (restores saved old values). No write happens at import, on
# open, or on preview — preview is read-only. Plan: reuse the wizard's proven
# backup/apply/undo helpers unchanged; this file only adds the table UI.

This is a THIN presentation layer.  All the real work is reused, unchanged:
  * label_recipe.py  — the composition engine (dry_run / apply / recipe_preset)
  * labeling_wizard.py — layer/host/polygon auto-detection, backup, undo helpers

Qt6/Qt5-safe: Qt via the qgis.PyQt shim, enums fully scoped, no QGIS call at
import time (engine + helpers imported lazily inside methods).
"""
import re

from qgis.PyQt import QtWidgets, QtCore, QtGui

Qt = QtCore.Qt

__all__ = ["LabelTableDock", "LabelTableWidget", "open_labeling_table"]

# ---------------------------------------------------------------------------
# palette — same Mission-Control console as the wizard / approved mock
# ---------------------------------------------------------------------------
_BG = "#0c1013"
_PANEL = "#12171d"
_HEAD = "#1b232c"
_LINE = "#242e38"
_LINE2 = "#303c47"
_INK = "#e7edf3"
_MUT = "#8291a0"
_DIM = "#5a6875"
_CYAN = "#22d3ee"
_AMBER = "#f0b429"
_GREEN = "#34d399"
_RED = "#f87171"
_SEL = "#12303a"

# role -> (emoji, friendly display)  — friendly name only; the engine roles
# themselves come from the picked client preset.
_ICON = {
    "ONT": "🏠", "DIST_CABLE": "🧵", "SEC_CABLE": "🧵", "PRI_CABLE": "🧵",
    "STS_SPLITTER": "🔀", "FTS_SPLITTER": "🔱", "ENCL_CONN": "📦",
    "ENCL_SPLICE": "📦", "DROP_CABLE": "🧵", "POLE": "📍", "MANHOLE": "⚫",
    "POP": "🏢",
}
_FRIENDLY = {
    "ONT": "Homes / ONT", "DIST_CABLE": "Distribution cable",
    "SEC_CABLE": "Secondary cable", "PRI_CABLE": "Primary cable",
    "STS_SPLITTER": "Street splitters", "FTS_SPLITTER": "Zone splitters",
    "ENCL_CONN": "Enclosures — dist", "ENCL_SPLICE": "Enclosures — agg",
    "DROP_CABLE": "Drop cable",
}
# preferred rail order
_ORDER = ["ONT", "DIST_CABLE", "SEC_CABLE", "PRI_CABLE", "STS_SPLITTER",
          "FTS_SPLITTER", "ENCL_CONN", "ENCL_SPLICE", "DROP_CABLE"]

# the table is a PREVIEW of the naming RULE, not an audit of every feature —
# so we only render a few example rows (the status bar shows the real total).
_EXAMPLE_ROWS = 8

# geometry/derived tokens -> "from the map" (cyan) in the rule bar
_MAP_TOKENS = {"host", "host_full", "start", "end", "start_full", "end_full",
               "pon_no", "zone_no", "zone", "ag", "card", "port", "polenum",
               "chainage"}
_AUTO_TOKENS = {"leg", "seq", "mhnum", "pnum", "popnum", "num"}


def _wiz():
    """The sibling wizard module — reused for detection/backup/apply helpers."""
    try:
        from . import labeling_wizard as w
    except ImportError:                      # pragma: no cover - flat copy
        import labeling_wizard as w
    return w


def _engine():
    """The label_recipe composition engine."""
    try:
        from . import label_recipe as eng
    except ImportError:                      # pragma: no cover - flat copy
        import label_recipe as eng
    return eng


# preset ratio/format defaults that reproduce the real as-builts (the approved
# mock).  Applied on top of engine.recipe_preset() WITHOUT touching the engine.
def _tune_preset(client, recs):
    if client != "Fibertime":
        return recs
    sts = recs.get("STS_SPLITTER")
    if sts is not None:
        sts.template = ("{stack}.STS.{ratio}.DIS.DM.{host}-OLT.{olt}"
                        ".C{card}P{port:02}.L{leg}")
        sts.constants.setdefault("ratio", "8")
    fts = recs.get("FTS_SPLITTER")
    if fts is not None:
        fts.template = ("{stack}.FTS.{ratio}.AGG.DM.{host}-OLT.{olt}"
                        ".C{card}P{port:02}")
        fts.constants.setdefault("ratio", "16")
    return recs


class LabelTableWidget(QtWidgets.QWidget):
    """The whole tool as one widget (put inside a QgsDockWidget)."""

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setObjectName("vnLblTblRoot")
        self._client = "Fibertime"
        self._recipes = {}          # role -> engine Recipe (tuned)
        self._role_layer = {}       # role -> QgsVectorLayer
        self._active = None         # active role key
        self._dry = None            # last dry-run result for active layer
        self._undo_all = []
        self._preview_error = None
        self._build_ui()
        self._autodetect()
        self._reload_recipes()
        self._select_first_layer()

    # -- construction --------------------------------------------------------
    def _build_ui(self):
        self.setStyleSheet(_qss())
        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # toolbar
        tb = QtWidgets.QFrame(objectName="tbar")
        tbl = QtWidgets.QHBoxLayout(tb)
        tbl.setContentsMargins(14, 8, 14, 8)
        tbl.setSpacing(12)
        brand = QtWidgets.QLabel("🏷️  LABEL MY NETWORK")
        brand.setObjectName("brand")
        beta = QtWidgets.QLabel("BETA")
        beta.setObjectName("beta")
        tbl.addWidget(brand)
        tbl.addWidget(beta)
        tbl.addSpacing(6)
        tbl.addWidget(_lbl("Company"))
        self.client_cb = QtWidgets.QComboBox()
        self.client_cb.addItems(["Fibertime", "Vuma", "HeroTel"])
        self.client_cb.currentTextChanged.connect(self._on_client)
        tbl.addWidget(self.client_cb)
        tbl.addWidget(_lbl("Project"))
        self.stack_ed = QtWidgets.QLineEdit("MOA")
        self.stack_ed.setMaximumWidth(72)
        self.stack_ed.setObjectName("mono")
        self.stack_ed.textEdited.connect(lambda *_: self.refresh())
        tbl.addWidget(self.stack_ed)
        tbl.addWidget(_lbl("OLT"))
        self.olt_ed = QtWidgets.QLineEdit("01")
        self.olt_ed.setMaximumWidth(52)
        self.olt_ed.setObjectName("mono")
        self.olt_ed.textEdited.connect(lambda *_: self.refresh())
        tbl.addWidget(self.olt_ed)
        tbl.addStretch(1)
        hint = QtWidgets.QLabel("looks & works like your attribute table — "
                                "nothing changes until you press Label")
        hint.setObjectName("hint")
        tbl.addWidget(hint)
        root.addWidget(tb)

        # body split: rail | content
        body = QtWidgets.QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)

        railwrap = QtWidgets.QFrame(objectName="rail")
        railwrap.setFixedWidth(230)
        rv = QtWidgets.QVBoxLayout(railwrap)
        rv.setContentsMargins(0, 0, 0, 0)
        rv.setSpacing(0)
        rh = QtWidgets.QLabel("LAYERS")
        rh.setObjectName("railhead")
        rv.addWidget(rh)
        self.rail_list = QtWidgets.QListWidget()
        self.rail_list.setObjectName("railList")
        self.rail_list.currentRowChanged.connect(self._on_rail)
        rv.addWidget(self.rail_list, 1)
        body.addWidget(railwrap)

        content = QtWidgets.QVBoxLayout()
        content.setContentsMargins(0, 0, 0, 0)
        content.setSpacing(0)

        # rule bar
        fc = QtWidgets.QFrame(objectName="fcbar")
        fcl = QtWidgets.QHBoxLayout(fc)
        fcl.setContentsMargins(14, 8, 14, 8)
        fcl.setSpacing(9)
        fx = QtWidgets.QLabel("ƒ  NEW LABEL =")
        fx.setObjectName("fx")
        fcl.addWidget(fx)
        self.expr_lbl = QtWidgets.QLabel("")
        self.expr_lbl.setObjectName("expr")
        self.expr_lbl.setTextFormat(Qt.TextFormat.RichText)
        fcl.addWidget(self.expr_lbl, 1)
        self.edit_btn = QtWidgets.QPushButton("⚙ Edit rule")
        self.edit_btn.setObjectName("gh")
        self.edit_btn.setCheckable(True)
        self.edit_btn.toggled.connect(lambda *_: self._render_drawer())
        fcl.addWidget(self.edit_btn)
        content.addWidget(fc)

        # editor drawer (hidden until Edit rule)
        self.drawer = QtWidgets.QFrame(objectName="drawer")
        self.drawer.setVisible(False)
        self.drawer_l = QtWidgets.QVBoxLayout(self.drawer)
        self.drawer_l.setContentsMargins(16, 12, 16, 14)
        self.drawer_l.setSpacing(10)
        content.addWidget(self.drawer)

        # table
        self.table = QtWidgets.QTableWidget()
        self.table.setObjectName("attrTable")
        self.table.setEditTriggers(
            QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(
            QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.setShowGrid(False)
        content.addWidget(self.table, 1)

        # status bar
        sb = QtWidgets.QFrame(objectName="statusbar")
        sbl = QtWidgets.QHBoxLayout(sb)
        sbl.setContentsMargins(14, 8, 14, 8)
        sbl.setSpacing(16)
        self.status_lbl = QtWidgets.QLabel("")
        self.status_lbl.setObjectName("status")
        sbl.addWidget(self.status_lbl)
        sbl.addStretch(1)
        self.backup_chk = QtWidgets.QCheckBox("Back up first")
        self.backup_chk.setChecked(True)
        sbl.addWidget(self.backup_chk)
        self.all_btn = QtWidgets.QPushButton("Label ALL layers")
        self.all_btn.setObjectName("gh")
        self.all_btn.clicked.connect(lambda *_: self._apply(all_layers=True))
        sbl.addWidget(self.all_btn)
        self.go_btn = QtWidgets.QPushButton("Label this layer  →")
        self.go_btn.setObjectName("go")
        self.go_btn.clicked.connect(lambda *_: self._apply(all_layers=False))
        sbl.addWidget(self.go_btn)
        content.addWidget(sb)

        body.addLayout(content, 1)
        root.addLayout(body, 1)

        # toast for undo
        self.toast = QtWidgets.QLabel("")
        self.toast.setObjectName("toast")
        self.toast.setVisible(False)
        self.toast.setWordWrap(True)
        root.addWidget(self.toast)

    # -- detection + recipes -------------------------------------------------
    def _project_layers(self):
        try:
            from qgis.core import QgsProject
            return list(QgsProject.instance().mapLayers().values())
        except Exception:
            return []

    def _autodetect(self):
        w = _wiz()
        layers = self._project_layers()
        self._role_layer = {}
        kinds = {"DIST_CABLE": "cable", "SEC_CABLE": "cable",
                 "PRI_CABLE": "cable", "DROP_CABLE": "cable",
                 "STS_SPLITTER": "point", "FTS_SPLITTER": "point",
                 "ENCL_CONN": "point", "ENCL_SPLICE": "point", "ONT": "point"}
        for role, kind in kinds.items():
            try:
                lyr = w._match_layer(role, kind, layers)
            except Exception:
                lyr = None
            if lyr is not None:
                self._role_layer[role] = lyr
        try:
            self._poles = w._guess_named_layer(layers, "point", "poles", "pole")
            self._man = w._guess_named_layer(layers, "point", "manhole")
            self._pon = w._guess_named_layer(layers, "polygon", "pon")
            self._zone = w._guess_named_layer(layers, "polygon", "zone")
        except Exception:
            self._poles = self._man = self._pon = self._zone = None
        try:
            st = w._detect_stack()
            if st:
                self.stack_ed.setText(str(st))
        except Exception:
            pass

    def _reload_recipes(self):
        eng = _engine()
        consts = {"stack": self.stack_ed.text().strip() or "MOA",
                  "olt": self.olt_ed.text().strip() or "01"}
        try:
            recs = eng.recipe_preset(self._client, **consts)
        except Exception:
            recs = {}
        self._recipes = _tune_preset(self._client, recs)

    def _host_field(self, lyr):
        w = _wiz()
        names = w._field_names(lyr) if lyr is not None else []
        return (w._guess_field(names, "label", "label_1", "name",
                               contains="label") or (names[0] if names else ""))

    def _host_index(self):
        eng = _engine()
        hosts = []
        for lyr in (self._poles, self._man):
            if lyr is not None:
                hosts.append((lyr, self._host_field(lyr)))
        return eng.build_host_index(hosts)

    def _polygons(self):
        eng = _engine()
        cfg = {}
        if self._pon is not None:
            cfg["pon_no"] = (self._pon, _pick(self._pon, "pon_no", "pon"))
        if self._zone is not None:
            cfg["zone_no"] = (self._zone, _pick(self._zone, "zone_no", "zone"))
        return eng.build_polygons(cfg)

    def _constants(self):
        return {"stack": self.stack_ed.text().strip() or "MOA",
                "olt": self.olt_ed.text().strip() or "01"}

    # -- rail ----------------------------------------------------------------
    def _select_first_layer(self):
        self._fill_rail()
        if self.rail_list.count():
            self.rail_list.setCurrentRow(0)

    def _rail_roles(self):
        return [r for r in _ORDER if r in self._role_layer and
                r in self._recipes]

    def _fill_rail(self):
        self.rail_list.blockSignals(True)
        self.rail_list.clear()
        for role in self._rail_roles():
            lyr = self._role_layer[role]
            try:
                cnt = lyr.featureCount()
                nm = lyr.name()
            except Exception:
                cnt, nm = 0, "?"
            it = QtWidgets.QListWidgetItem(
                "%s  %s\n      %s · %s" % (_ICON.get(role, "▫"),
                                          _FRIENDLY.get(role, role),
                                          "{:,}".format(cnt), nm))
            it.setData(Qt.ItemDataRole.UserRole, role)
            self.rail_list.addItem(it)
        self.rail_list.blockSignals(False)

    def _on_rail(self, row):
        if row < 0:
            return
        it = self.rail_list.item(row)
        if it is None:
            return
        self._active = it.data(Qt.ItemDataRole.UserRole)
        self.edit_btn.setChecked(False)
        self.refresh()

    # -- events --------------------------------------------------------------
    def _on_client(self, name):
        self._client = name
        self._reload_recipes()
        self.edit_btn.setChecked(False)
        self._fill_rail()
        if self.rail_list.count():
            self.rail_list.setCurrentRow(0)
        else:
            self.refresh()

    # -- rule bar + drawer ---------------------------------------------------
    def _segments(self, role):
        tmpl = self._recipes[role].template
        parts = re.split(r"(\{[^}]+\})", tmpl)
        out = []
        for p in parts:
            if not p:
                continue
            m = re.match(r"^\{([^}]+)\}$", p)
            if not m:
                out.append(("fixed", p))
                continue
            name = m.group(1).split(":")[0]
            cls = ("map" if name in _MAP_TOKENS
                   else "auto" if name in _AUTO_TOKENS
                   else "set")
            out.append((cls, m.group(1)))
        return out

    def _render_expr(self):
        if not self._active:
            self.expr_lbl.setText("")
            return
        cols = {"fixed": _MUT, "map": _CYAN, "auto": "#a78bfa", "set": _AMBER}
        html = []
        for cls, txt in self._segments(self._active):
            safe = txt.replace("<", "&lt;")
            if cls == "fixed":
                html.append('<span style="color:%s">%s</span>' % (_MUT, safe))
            else:
                html.append('<span style="color:%s">{%s}</span>'
                            % (cols[cls], safe))
        self.expr_lbl.setText("".join(html))

    def _render_drawer(self):
        _clear(self.drawer_l)
        show = self.edit_btn.isChecked() and bool(self._active)
        self.drawer.setVisible(show)
        if not show:
            return
        rec = self._recipes[self._active]
        toks = [m.split(":")[0]
                for m in re.findall(r"\{([^}]+)\}", rec.template)]
        cap = QtWidgets.QLabel("This column is built like:")
        cap.setObjectName("cap")
        self.drawer_l.addWidget(cap)
        seg = QtWidgets.QLabel(self._segmented_html(self._active))
        seg.setObjectName("bigexpr")
        seg.setTextFormat(Qt.TextFormat.RichText)
        seg.setWordWrap(True)
        self.drawer_l.addWidget(seg)
        legend = QtWidgets.QLabel(
            '<span style="color:%s">■</span> from the map &nbsp; '
            '<span style="color:%s">■</span> value you set / a column &nbsp; '
            '<span style="color:#a78bfa">■</span> counted automatically &nbsp; '
            '<span style="color:%s">■</span> fixed text'
            % (_CYAN, _AMBER, _MUT))
        legend.setObjectName("legend")
        legend.setTextFormat(Qt.TextFormat.RichText)
        self.drawer_l.addWidget(legend)
        opts = QtWidgets.QHBoxLayout()
        opts.setSpacing(20)
        if any(t in toks for t in ("host", "start", "end")):
            opts.addWidget(QtWidgets.QLabel("Names each feature after the "
                                            "nearest pole."))
        if "ratio" in rec.constants:
            opts.addWidget(_lbl("Splitter ratio"))
            ratio_ed = QtWidgets.QLineEdit(str(rec.constants.get("ratio", "")))
            ratio_ed.setMaximumWidth(56)
            ratio_ed.setObjectName("mono")
            ratio_ed.textEdited.connect(
                lambda v, r=rec: (r.constants.__setitem__("ratio", v),
                                  self.refresh()))
            opts.addWidget(ratio_ed)
        opts.addStretch(1)
        writeto = QtWidgets.QLabel("writes into column: <b>%s</b>"
                                   % rec.label_field)
        writeto.setObjectName("cap")
        writeto.setTextFormat(Qt.TextFormat.RichText)
        opts.addWidget(writeto)
        wrap = QtWidgets.QWidget()
        wrap.setLayout(opts)
        self.drawer_l.addWidget(wrap)
        done = QtWidgets.QPushButton("Done")
        done.setObjectName("go")
        done.clicked.connect(lambda *_: self.edit_btn.setChecked(False))
        row = QtWidgets.QHBoxLayout()
        row.addWidget(done)
        row.addStretch(1)
        w2 = QtWidgets.QWidget()
        w2.setLayout(row)
        self.drawer_l.addWidget(w2)

    def _segmented_html(self, role):
        cols = {"fixed": _MUT, "map": _CYAN, "auto": "#a78bfa", "set": _AMBER}
        html = ['<span style="font-family:Consolas;font-size:13px">']
        for cls, txt in self._segments(role):
            safe = txt.replace("<", "&lt;")
            if cls == "fixed":
                html.append('<span style="color:%s">%s</span>' % (_MUT, safe))
            else:
                bg = {"map": "#0c2b33", "auto": "#221b3a",
                      "set": "#2b230c"}[cls]
                html.append('<span style="color:%s;background:%s">&nbsp;{%s}'
                            '&nbsp;</span>' % (cols[cls], bg, safe))
        html.append("</span>")
        return "".join(html)

    # -- preview -------------------------------------------------------------
    def refresh(self):
        # a stale active role (e.g. after a client switch on an empty project)
        # must never reach the renderers, which index self._recipes directly.
        if self._active is not None and (
                self._active not in self._recipes
                or self._active not in self._role_layer):
            self._active = None
        self._render_expr()
        self._render_drawer()
        self._render_table()

    def _dry_run_active(self):
        """Read-only engine dry-run for the ACTIVE layer only."""
        role = self._active
        if (not role or role not in self._recipes
                or role not in self._role_layer):
            return None
        eng = _engine()
        lyr = self._role_layer[role]
        lrc = eng.LayerRecipe(lyr, self._recipes[role])
        try:
            host = self._host_index()
            polys = self._polygons()
            res = eng.dry_run([lrc], host, polys, self._constants())
        except Exception as exc:            # never crash the dock on preview
            self._preview_error = "%s: %s" % (type(exc).__name__, exc)
            return None
        self._preview_error = None
        return res.get(role)

    def _render_table(self):
        role = self._active
        if not role:
            self.table.clear()
            self.table.setRowCount(0)
            self.status_lbl.setText("Pick a layer on the left.")
            return
        QtWidgets.QApplication.setOverrideCursor(
            QtGui.QCursor(Qt.CursorShape.WaitCursor))
        try:
            self._dry = self._dry_run_active()
        finally:
            QtWidgets.QApplication.restoreOverrideCursor()
        lyr = self._role_layer[role]
        rec = self._recipes[role]
        lf = rec.label_field
        if self._dry is None:
            self.table.clear()
            self.table.setRowCount(0)
            self.status_lbl.setText(
                "Couldn't preview: %s"
                % (self._preview_error or "no data"))
            return
        labels = self._dry.get("labels", {})     # fid -> (label, fills)
        fill_cols = []
        for _fid, val in list(labels.items())[:200]:
            fills = val[1] if isinstance(val, (list, tuple)) else {}
            for k in fills:
                if k not in fill_cols and k != lf:
                    fill_cols.append(k)
        headers = ["#", "%s (current)" % lf, "✦ NEW LABEL"] + fill_cols + [""]
        newcol_idx = 2
        self.table.clear()
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        names = lyr.fields().names()
        has_lf = lf in names
        rows = []
        for f in lyr.getFeatures():
            fid = f.id()
            val = labels.get(fid, (None, {}))
            new, fills = (val if isinstance(val, (list, tuple))
                          else (None, {}))
            cur = f[lf] if has_lf else None
            rows.append((fid, cur, new, fills))
            if len(rows) >= _EXAMPLE_ROWS:
                break
        self.table.setRowCount(len(rows))
        for r, (fid, cur, new, fills) in enumerate(rows):
            self.table.setItem(r, 0, _cell(str(fid), _DIM, mono=True))
            self.table.setItem(r, 1, _cell(_s(cur), _MUT, mono=True))
            flag = new is None
            nc = _cell("✋ needs a pole" if flag else _s(new),
                       _RED if flag else _INK, mono=True, bold=not flag)
            nc.setBackground(QtGui.QColor("#241315" if flag else "#0c1f27"))
            self.table.setItem(r, newcol_idx, nc)
            for j, k in enumerate(fill_cols):
                self.table.setItem(r, 3 + j,
                                   _cell(_s(fills.get(k)), _CYAN, mono=True))
            st = _cell("!" if flag else "✔", _AMBER if flag else _GREEN)
            self.table.setItem(r, len(headers) - 1, st)
        hh = self.table.horizontalHeader()
        hh.setStretchLastSection(False)
        hh.setSectionResizeMode(
            QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        ready = self._dry.get("ready", 0)
        flagged = self._dry.get("flagged", 0)
        total = ready + flagged
        shown = ("" if total <= len(rows)
                 else "  ·  %d examples shown" % len(rows))
        self.status_lbl.setText(
            "%s features  ·  %s will be named  ·  %s need a pole%s"
            % ("{:,}".format(total), "{:,}".format(ready),
               "{:,}".format(flagged), shown))

    # -- apply / undo --------------------------------------------------------
    def _apply(self, all_layers):
        w = _wiz()
        eng = _engine()
        roles = (self._rail_roles() if all_layers
                 else ([self._active] if self._active else []))
        roles = [r for r in roles
                 if r in self._role_layer and r in self._recipes]
        if not roles:
            self._show_toast("warn", "Nothing to label.")
            return
        if self.backup_chk.isChecked():
            QtWidgets.QApplication.setOverrideCursor(
                QtGui.QCursor(Qt.CursorShape.WaitCursor))
            try:
                ok, detail = w._run_backup()
            finally:
                QtWidgets.QApplication.restoreOverrideCursor()
            if not ok:
                self._show_toast("error",
                                 "Backup failed — NOTHING written. %s" % detail)
                return
        host = self._host_index()
        polys = self._polygons()
        consts = self._constants()
        total_undo = 0
        self._undo_all = []
        QtWidgets.QApplication.setOverrideCursor(
            QtGui.QCursor(Qt.CursorShape.WaitCursor))
        try:
            for role in roles:
                lrc = eng.LayerRecipe(self._role_layer[role],
                                      self._recipes[role])
                dry = eng.dry_run([lrc], host, polys, consts)
                undo = eng.apply([lrc], dry)
                if undo:
                    total_undo += len(undo)
                    self._undo_all.append((lrc, undo))
        except Exception as exc:
            QtWidgets.QApplication.restoreOverrideCursor()
            self._show_toast("error", "Writing labels failed: %s: %s"
                             % (type(exc).__name__, exc))
            return
        finally:
            QtWidgets.QApplication.restoreOverrideCursor()
        try:
            if self.iface is not None:
                self.iface.messageBar().pushSuccess(
                    "Label My Network",
                    "Labelled %s feature(s)." % "{:,}".format(total_undo))
        except Exception:
            pass
        self._show_toast(
            "ok", "Labelled %s feature(s)." % "{:,}".format(total_undo),
            undo=(total_undo > 0))
        self.refresh()

    def _do_undo(self):
        w = _wiz()
        restored = 0
        for lrc, undo in list(getattr(self, "_undo_all", [])):
            lyr = lrc.layer
            if lyr is None or w._is_deleted(lyr):
                continue
            role = lrc.recipe.layer_role
            idx = {n: lyr.fields().indexOf(n) for n in lyr.fields().names()}
            changes = {}
            for f in lyr.getFeatures():
                old = undo.get((role, w._fid_of(f, lrc.id_field)))
                if not old:
                    continue
                rowmap = {idx[fld]: v for fld, v in old.items() if fld in idx}
                if rowmap:
                    changes[f.id()] = rowmap
            if changes:
                # restore previously-saved values (operator pressed UNDO)
                lyr.dataProvider().changeAttributeValues(changes)
                lyr.triggerRepaint()
                restored += len(changes)
        self._undo_all = []
        self._show_toast("ok", "Undone — %s feature(s) restored."
                         % "{:,}".format(restored))
        self.refresh()

    def _show_toast(self, kind, msg, undo=False):
        col = {"ok": _GREEN, "warn": _AMBER, "error": _RED}.get(kind, _INK)
        self.toast.setStyleSheet(
            "#toast{background:%s;color:%s;padding:9px 14px;"
            "border-top:1px solid %s;font-weight:600}" % (_PANEL, col, _LINE2))
        self.toast.setText(msg + ("   ↩ click here to UNDO" if undo else ""))
        self.toast.setVisible(True)
        try:
            self.toast.mousePressEvent = (
                (lambda *_: self._do_undo()) if undo else (lambda *_: None))
        except Exception:
            pass


class LabelTableDock(QtWidgets.QDockWidget):
    def __init__(self, iface, parent=None):
        super().__init__("Label My Network", parent)
        self.setObjectName("LabelMyNetworkTableDock")
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, False)
        self._w = LabelTableWidget(iface, self)
        self.setWidget(self._w)


_DOCK = None


def open_labeling_table(iface):
    """Open (or raise) the attribute-table Label My Network dock.

    Singleton by dock objectName so a plugin reload (which resets this
    module's _DOCK global) can never leave two docks stacked."""
    global _DOCK
    w = _wiz()
    if _DOCK is not None and not w._is_deleted(_DOCK):
        _DOCK.show()
        _DOCK.raise_()
        return _DOCK
    if iface is not None:                       # reuse an existing dock if any
        try:
            found = None
            for d in iface.mainWindow().findChildren(QtWidgets.QDockWidget):
                if d.objectName() != "LabelMyNetworkTableDock":
                    continue
                if found is None and isinstance(d, LabelTableDock):
                    found = d                   # keep the first real one
                else:
                    d.close()                   # drop stale/duplicate docks
                    d.setParent(None)
            if found is not None:
                _DOCK = found
                found.show()
                found.raise_()
                return found
        except Exception:
            pass
    _DOCK = LabelTableDock(iface, iface.mainWindow() if iface else None)
    if iface is not None:
        iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, _DOCK)
    _DOCK.show()
    _DOCK.raise_()
    return _DOCK


# ---------------------------------------------------------------------------
# small helpers
# ---------------------------------------------------------------------------
def _lbl(text):
    la = QtWidgets.QLabel(text)
    la.setObjectName("fld")
    return la


def _s(v):
    if v is None:
        return ""
    return str(v)


def _cell(text, colour, mono=False, bold=False):
    it = QtWidgets.QTableWidgetItem(text)
    it.setForeground(QtGui.QColor(colour))
    it.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
    f = it.font()
    if mono:
        f.setFamily("Consolas")
    if bold:
        f.setBold(True)
    it.setFont(f)
    return it


def _pick(layer, *cands):
    try:
        names = layer.fields().names()
    except Exception:
        return cands[0] if cands else ""
    for c in cands:
        if c in names:
            return c
    return names[0] if names else ""


def _clear(layout):
    while layout.count():
        it = layout.takeAt(0)
        wdg = it.widget()
        if wdg is not None:
            wdg.setParent(None)


def _qss():
    return """
    #vnLblTblRoot{background:%(bg)s;color:%(ink)s;font-family:'Segoe UI';}
    QLabel{color:%(ink)s;}
    #tbar,#statusbar{background:%(head)s;border-bottom:1px solid %(line)s;}
    #statusbar{border-bottom:0;border-top:1px solid %(line2)s;}
    #brand{font-weight:700;letter-spacing:1px;}
    #beta{color:%(amber)s;border:1px solid %(amber)s;border-radius:3px;
          padding:0px 5px;font-size:9px;}
    #hint{color:%(dim)s;font-size:11px;}
    #fld{color:%(mut)s;font-size:11px;}
    QLineEdit#mono{background:%(panel)s;border:1px solid %(line2)s;
          border-radius:6px;padding:4px 8px;color:%(ink)s;
          font-family:'Consolas';}
    QComboBox{background:%(panel)s;border:1px solid %(line2)s;border-radius:6px;
          padding:4px 9px;color:%(ink)s;}
    QComboBox QAbstractItemView{background:%(panel)s;color:%(ink)s;
          selection-background-color:%(sel)s;}
    #rail{background:%(panel)s;border-right:1px solid %(line)s;}
    #railhead{color:%(mut)s;font-size:10px;letter-spacing:2px;
          padding:12px 14px 6px;}
    #railList{background:transparent;border:0;outline:0;}
    #railList::item{border-left:3px solid transparent;padding:8px 12px;
          color:%(ink)s;}
    #railList::item:selected{background:%(sel)s;border-left:3px solid %(cyan)s;
          color:%(ink)s;}
    #fcbar{background:#161d25;border-bottom:1px solid %(line)s;}
    #fx{color:%(cyan)s;font-weight:700;font-family:'Consolas';}
    #expr{background:%(panel)s;border:1px solid %(line2)s;border-radius:7px;
          padding:6px 11px;font-family:'Consolas';}
    #drawer{background:#0b1015;border-bottom:1px solid %(line)s;}
    #cap{color:%(mut)s;font-size:11px;}
    #bigexpr{background:%(panel)s;border:1px solid %(line2)s;border-radius:8px;
          padding:10px 12px;}
    #legend{color:%(mut)s;font-size:11px;}
    #status{color:%(mut)s;font-size:12px;}
    QPushButton#gh{background:transparent;border:1px solid %(line2)s;
          border-radius:8px;padding:7px 13px;color:%(ink)s;}
    QPushButton#gh:hover{border-color:%(cyan)s;color:%(cyan)s;}
    QPushButton#gh:checked{border-color:%(cyan)s;color:%(cyan)s;}
    QPushButton#go{background:%(cyan)s;border:0;border-radius:8px;
          padding:8px 18px;color:#04222b;font-weight:700;}
    QCheckBox{color:%(mut)s;font-size:12px;}
    QTableWidget#attrTable{background:%(bg)s;border:0;gridline-color:%(line)s;
          color:%(ink)s;}
    QHeaderView::section{background:%(head)s;color:%(mut)s;border:0;
          border-bottom:2px solid %(line2)s;padding:7px 12px;
          font-weight:700;}
    QTableWidget#attrTable::item{padding:5px 12px;}
    QTableWidget#attrTable::item:selected{background:%(sel)s;}
    """ % {"bg": _BG, "panel": _PANEL, "head": _HEAD, "line": _LINE,
           "line2": _LINE2, "ink": _INK, "mut": _MUT, "dim": _DIM,
           "cyan": _CYAN, "amber": _AMBER, "sel": _SEL}
