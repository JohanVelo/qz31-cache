# claude:intent MUTATE — user asked (verbatim): "keep on training the AI until
#   it gets my buildings perfect ... I would detect the buildings, and then
#   that's your reference" then "yes" to building the review dock. Plan: an
#   OPERATOR-DRIVEN dock where JJ clicks Delete to remove a wrong polygon from
#   the Detected Buildings layer and every decision is logged to corrections.gpkg
#   as training ground-truth. Only user-triggered per-feature deletion.
# claude:approved-destructive — the only mutation is OPERATOR-triggered per-feature
#   deletion on a DERIVED, regenerable detection layer (never a source/cadastre
#   layer). It is fully recoverable: (1) every deleted geometry is logged to
#   corrections.gpkg BEFORE removal, and (2) _backup_once() copies the layer's
#   source file before the first delete of a session.
"""review_dock — human-in-the-loop review of Detected Buildings.

JJ walks the detected polygons (flagged/uncertain first), and for each one:
  Keep (K)  — it's a correct building
  Delete (D) — not a building (tree / ground / duplicate) -> removed + logged as
               a HARD NEGATIVE (the strongest signal to train the model)
  Fix (F)   — drop into native QGIS vertex editing to redraw the boundary
  Next/Prev — walk the queue

Every decision is appended to `<project output>/corrections.gpkg` — the ground
truth that feeds the active-learning flywheel (harvest -> fine-tune SAM +
classifier on JJ's own corrections).

Qt6-safe: qgis.PyQt shim, fully-scoped enums, QMetaType field types, sip guards.
"""
from __future__ import annotations

import os
import shutil

from qgis.PyQt.QtCore import Qt, QMetaType
from qgis.PyQt.QtGui import QColor, QKeySequence
from qgis.PyQt.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QPushButton, QShortcut, QVBoxLayout, QWidget)
from qgis.core import (
    QgsCoordinateTransform, QgsFeature, QgsField, QgsFields, QgsGeometry,
    QgsProject, QgsVectorFileWriter, QgsVectorLayer, QgsWkbTypes,
    QgsCoordinateTransformContext)
from qgis.gui import QgsRubberBand

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

BUILDING_LAYER_HINTS = ("detected buildings", "buildings")


def _find_review_layer(iface):
    """Active layer if it's a polygon buildings layer, else the first match."""
    proj = QgsProject.instance()
    act = iface.activeLayer()
    polys = [l for l in proj.mapLayers().values()
             if isinstance(l, QgsVectorLayer)
             and l.geometryType() == QgsWkbTypes.GeometryType.PolygonGeometry]
    if act in polys and any(h in act.name().lower() for h in BUILDING_LAYER_HINTS):
        return act
    for l in polys:
        if any(h in l.name().lower() for h in BUILDING_LAYER_HINTS):
            return l
    return act if act in polys else (polys[0] if polys else None)


def _corrections_path():
    proj = QgsProject.instance()
    base = os.path.dirname(proj.fileName()) if proj.fileName() else None
    if base and os.path.isdir(base):
        out = os.path.join(base, "Velocity Nexus Output")
        os.makedirs(out, exist_ok=True)
        return os.path.join(out, "corrections.gpkg")
    return os.path.join(os.path.expanduser("~"), ".velocityfibre", "corrections.gpkg")


class CorrectionLog:
    """Append-only correction store (GeoPackage). One row per review decision."""

    def __init__(self, path, crs):
        self.path = path
        self._crs = crs
        self._layer = None
        self._load_or_create()

    def _schema(self):
        f = QgsFields()
        for name, typ in (("action", QMetaType.Type.QString),
                          ("reason", QMetaType.Type.QString),
                          ("shape", QMetaType.Type.QString),
                          ("area_m2", QMetaType.Type.Double),
                          ("project", QMetaType.Type.QString),
                          ("src_layer", QMetaType.Type.QString),
                          ("ts", QMetaType.Type.QString)):
            f.append(QgsField(name, typ))
        return f

    def _load_or_create(self):
        if os.path.isfile(self.path):
            lyr = QgsVectorLayer(f"{self.path}|layername=corrections", "c", "ogr")
            if lyr.isValid():
                self._layer = lyr
                return
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = "GPKG"
        opts.layerName = "corrections"
        writer = QgsVectorFileWriter.create(
            self.path, self._schema(), QgsWkbTypes.Type.Polygon, self._crs,
            QgsCoordinateTransformContext(), opts)
        del writer                      # flush/close
        self._layer = QgsVectorLayer(
            f"{self.path}|layername=corrections", "c", "ogr")

    def append(self, geom, action, reason, shape, area, project, src_layer, ts):
        if self._layer is None or not self._layer.isValid():
            return False
        f = QgsFeature(self._layer.fields())
        if geom is not None:
            f.setGeometry(QgsGeometry(geom))
        # set by NAME (GPKG auto-adds an 'fid' column, so positional would shift)
        for name, val in (("action", action), ("reason", reason),
                          ("shape", shape), ("area_m2", float(area or 0.0)),
                          ("project", project), ("src_layer", src_layer),
                          ("ts", ts)):
            f.setAttribute(name, val)
        # claude:intent MUTATE — append-only write to corrections.gpkg (the
        # operator's review decisions = training data); not a source-data edit.
        ok, _ = self._layer.dataProvider().addFeatures([f])
        return ok

    def count(self):
        return self._layer.featureCount() if self._layer else 0


class BuildingReviewPanel(QWidget):
    """Content widget for the review dock. Walks a queue of building features."""

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.layer = _find_review_layer(iface)
        self._rb = None
        self._queue = []                # list of fids, flagged first
        self._pos = 0
        self._log = None
        self._backed_up = False
        self._build_ui()
        self._start()

    # ── UI ───────────────────────────────────────────────────────────────────
    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 12, 12, 12)
        lay.setSpacing(8)
        lay.addWidget(QLabel("<b>🔍 Review Buildings</b>"))
        self._src = QLabel("")
        self._src.setStyleSheet("color:#888;")
        lay.addWidget(self._src)
        line = QFrame(); line.setFrameShape(QFrame.Shape.HLine)
        lay.addWidget(line)
        self._info = QLabel("")
        self._info.setWordWrap(True)
        self._info.setMinimumHeight(70)
        lay.addWidget(self._info)
        self._progress = QLabel("")
        from . import theme_safe   # native dock background: colour follows the theme
        self._progress.setStyleSheet(f"color:{theme_safe.colors(self._progress)['accent']};")
        lay.addWidget(self._progress)

        row1 = QHBoxLayout()
        self._btn_keep = QPushButton("✅ Keep  (K)")
        self._btn_keep.clicked.connect(self._keep)
        self._btn_del = QPushButton("❌ Not a building  (D)")
        self._btn_del.clicked.connect(self._delete)
        row1.addWidget(self._btn_keep); row1.addWidget(self._btn_del)
        lay.addLayout(row1)

        row2 = QHBoxLayout()
        self._btn_fix = QPushButton("✏️ Fix boundary  (F)")
        self._btn_fix.clicked.connect(self._fix)
        row2.addWidget(self._btn_fix)
        lay.addLayout(row2)

        row3 = QHBoxLayout()
        self._btn_prev = QPushButton("⏮ Prev")
        self._btn_prev.clicked.connect(self._prev)
        self._btn_next = QPushButton("Skip ⏭")
        self._btn_next.clicked.connect(self._next)
        row3.addWidget(self._btn_prev); row3.addWidget(self._btn_next)
        lay.addLayout(row3)

        lay.addStretch(1)
        self._hint = QLabel("K keep · D delete · F fix · ←/→ prev/next")
        # #777 was 2.9:1 on a dark theme; muted follows the theme and stays >= 3:1
        theme_safe.style_label(self._hint, role="muted", size=11)
        lay.addWidget(self._hint)

        for key, fn in (("K", self._keep), ("D", self._delete), ("F", self._fix),
                        ("Right", self._next), ("Left", self._prev)):
            sc = QShortcut(QKeySequence(key), self)
            sc.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
            sc.activated.connect(fn)

    # ── queue ──────────────────────────────────────────────────────────────────
    def _start(self):
        if self.layer is None:
            self._info.setText("No Detected Buildings layer found. Run Detect "
                               "Buildings first, then reopen this panel.")
            self._set_enabled(False)
            return
        self._src.setText(f"Layer: {self.layer.name()}  ·  "
                          f"{self.layer.featureCount()} features")
        fields = [f.name() for f in self.layer.fields()]
        flagged, rest = [], []
        for f in self.layer.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            is_flag = ("flag_for_review" in fields
                       and f["flag_for_review"] in (1, "1", True))
            (flagged if is_flag else rest).append(f.id())
        self._queue = flagged + rest
        self._pos = 0
        self._log = CorrectionLog(_corrections_path(), self.layer.crs())
        self._show()

    def _set_enabled(self, on):
        for b in (self._btn_keep, self._btn_del, self._btn_fix,
                  self._btn_prev, self._btn_next):
            b.setEnabled(on)

    def _current_feature(self):
        if not self._queue or not (0 <= self._pos < len(self._queue)):
            return None
        return self.layer.getFeature(self._queue[self._pos])

    def _show(self):
        if not self._queue:
            self._info.setText("Nothing to review 🎉")
            self._progress.setText("")
            self._clear_rb()
            self._set_enabled(False)
            return
        if self._pos >= len(self._queue):
            self._info.setText(f"<b>Review complete 🎉</b><br>"
                               f"{self._log.count()} decisions saved to "
                               f"corrections.gpkg — that's your training data.")
            self._progress.setText("")
            self._clear_rb()
            self._set_enabled(False)
            return
        self._set_enabled(True)
        feat = self._current_feature()
        if feat is None or not feat.hasGeometry():
            self._next()
            return
        props = feat.fields().names()
        shp = feat["shape"] if "shape" in props else "?"
        area = feat["area_m2"] if "area_m2" in props else None
        flag = ("flag_for_review" in props
                and feat["flag_for_review"] in (1, "1", True))
        dflags = feat["defect_flags"] if "defect_flags" in props else ""
        tag = (f"<span style='color:#e67e22'><b>⚠ REVIEW</b> "
               f"({dflags})</span><br>" if flag else "")
        self._info.setText(
            f"{tag}<b>Shape:</b> {shp}"
            + (f" · <b>{area:.0f} m²</b>" if isinstance(area, (int, float)) else "")
            + "<br>Is this a real building, correctly outlined?")
        self._progress.setText(
            f"{self._pos + 1} / {len(self._queue)}   ·   "
            f"{self._log.count() if self._log else 0} logged")
        self._highlight(feat)

    # ── canvas ─────────────────────────────────────────────────────────────────
    def _clear_rb(self):
        from qgis.PyQt import sip
        if self._rb is not None and not sip.isdeleted(self._rb):
            self._rb.reset(QgsWkbTypes.GeometryType.PolygonGeometry)

    def _highlight(self, feat):
        canvas = self.iface.mapCanvas()
        g = feat.geometry()
        tr = QgsCoordinateTransform(self.layer.crs(),
                                    canvas.mapSettings().destinationCrs(),
                                    QgsProject.instance())
        gc = QgsGeometry(g)
        try:
            gc.transform(tr)
        except Exception:
            pass
        bb = gc.boundingBox()
        if bb.isEmpty():
            return
        # KEEP THE SCREEN STILL: never change the zoom. Only PAN (same scale) if
        # the feature is off-screen, so JJ's view stays put while reviewing.
        if not canvas.extent().contains(bb.center()):
            canvas.setCenter(bb.center())
        if self._rb is None:
            self._rb = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PolygonGeometry)
        self._rb.reset(QgsWkbTypes.GeometryType.PolygonGeometry)
        # bold magenta glow + thick edge — pops against red/green/blue shapes
        self._rb.setFillColor(QColor(255, 0, 255, 70))
        self._rb.setStrokeColor(QColor(255, 0, 255, 255))
        self._rb.setWidth(5)
        self._rb.setToGeometry(gc, None)
        canvas.refresh()

    # ── actions ────────────────────────────────────────────────────────────────
    def _ts(self):
        from datetime import datetime
        return datetime.now().isoformat(timespec="seconds")

    def _backup_once(self):
        """Copy the detection layer's source file before the first delete."""
        if self._backed_up:
            return
        self._backed_up = True
        try:
            src = self.layer.source().split("|")[0]
            if os.path.isfile(src):
                shutil.copy(src, src + ".reviewbak_" +
                            self._ts().replace(":", "").replace("-", ""))
        except Exception:
            pass

    def _log_current(self, action, reason):
        feat = self._current_feature()
        if feat is None or self._log is None:
            return
        props = feat.fields().names()
        self._log.append(
            feat.geometry(), action, reason,
            feat["shape"] if "shape" in props else "",
            feat["area_m2"] if "area_m2" in props else 0.0,
            os.path.basename(QgsProject.instance().fileName() or "unsaved"),
            self.layer.name(), self._ts())

    def _keep(self):
        self._log_current("keep", "")
        self._next()

    def _delete(self):
        feat = self._current_feature()
        if feat is None:
            return
        self._backup_once()
        self._log_current("delete", "not_a_building")   # log geom BEFORE removing
        fid = feat.id()
        try:
            self.layer.dataProvider().deleteFeatures([fid])
            self.layer.triggerRepaint()
        except Exception:
            _swallowed_note()
        try:
            self._queue.pop(self._pos)
        except IndexError:
            pass
        self._show()

    def _fix(self):
        """Hand off to native QGIS editing on this feature (operator redraws)."""
        feat = self._current_feature()
        if feat is None:
            return
        self.iface.setActiveLayer(self.layer)
        if not self.layer.isEditable():
            self.layer.startEditing()
        self.layer.selectByIds([feat.id()])
        try:
            self.iface.actionNodeTool().trigger()
        except Exception:
            pass
        self._info.setText("Editing this feature — redraw the boundary, then "
                           "press <b>Keep (K)</b> to log it and move on.")

    def _next(self):
        if self._pos < len(self._queue):
            self._pos += 1
        self._show()

    def _prev(self):
        if self._pos > 0:
            self._pos -= 1
        self._show()

    # ── lifecycle ──────────────────────────────────────────────────────────────
    def closeEvent(self, e):
        self._clear_rb()
        super().closeEvent(e)


def open_building_review(plugin):
    """Open the review dock via the plugin's proven _dock_panel host. `plugin`
    is the FiberNetworkAutomation plugin instance (has .iface + ._dock_panel)."""
    from qgis.PyQt import sip
    dock = getattr(plugin, "_review_dock", None)
    if dock is not None and not sip.isdeleted(dock):
        dock.setVisible(True); dock.raise_()
        return dock
    panel = BuildingReviewPanel(plugin.iface)
    plugin._review_panel = panel
    plugin._review_dock = plugin._dock_panel(
        panel, "🔍 Review Buildings", "VFBuildingReviewDock",
        float_size=(360, 560))
    return plugin._review_dock
