# Fiber Network Automation Plugin
# Auto-labeling for FTTH networks

import os
import sys


def classFactory(iface):
    from .legacy_boq_retirement import startup
    startup(iface, os.path.dirname(__file__))

    # When installed from ZIP, fibre_automation/ is bundled inside this plugin dir.
    # Add the plugin dir to sys.path so `import fibre_automation` finds it.
    _plugin_dir = os.path.normpath(os.path.dirname(__file__))
    if _plugin_dir not in [os.path.normpath(p) for p in sys.path]:
        sys.path.append(_plugin_dir)

    from .fiber_network_plugin import FiberNetworkPlugin
    return FiberNetworkPlugin(iface)
