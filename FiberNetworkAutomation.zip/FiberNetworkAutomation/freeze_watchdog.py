"""freeze_watchdog — detect when the QGIS GUI (Qt main) thread is blocked and
capture WHAT froze it, so intermittent "QGIS keeps hanging" reports become hard
data instead of guesswork (e.g. a hang after an autonet / Network-Planner run).

How it works (proven pattern — same as NVDA's watchdog):
  * A 1-second QTimer on the MAIN thread stamps a monotonic "last alive" time.
    If the event loop is responsive the stamp stays fresh; if the main thread is
    blocked in a long synchronous operation the timer can't fire and the stamp
    goes stale.
  * A daemon thread wakes every 0.5 s and, if the stamp is stale beyond a
    threshold, it's a freeze. The daemon captures the MAIN thread's Python stack
    with sys._current_frames() (GIL-safe, no Qt) — that stack is the culprit.

Critical design points for this plugin:
  * The freeze is DETECTED on the daemon thread, but REPORTING goes through Qt
    networking (telemetry → Supabase) which is main-thread-only — and the main
    thread is frozen at detection time. So the daemon only CAPTURES + BUFFERS;
    the main-thread heartbeat DRAINS the buffer and reports once the UI is
    responsive again. That also yields the accurate TOTAL freeze duration.
  * The daemon touches ONLY pure-Python (time, sys, traceback, hashlib) — never
    Qt, never iface, never layers — so it is GIL-safe and cannot crash QGIS.
  * Modal dialogs run a nested event loop, so the heartbeat keeps firing during
    them → they never false-trigger. Only genuine main-thread blocking is
    flagged, which is exactly what we want.
  * Dedup by stack fingerprint + cooldown so a repeating freeze can't spam.
  * Degrade-not-crash everywhere; clean shutdown on plugin unload.
"""
import hashlib
import json
import os
import re
import sys
import threading
import time
import traceback

_HOME = os.path.expanduser("~")
_PATH_RE = re.compile(r"(?:[A-Za-z]:\\|/home/|/Users/|/mnt/|\\\\)[^\s'\"]+")
# Where the daemon spools an in-progress PERMANENT hang so it survives a forced
# kill and gets reported on the next QGIS start (see drain_spool). Pure-Python
# path so the daemon never needs QGIS to compute it.
_DEFAULT_SPOOL = os.path.join(_HOME, ".velocity_nexus", "freeze_spool.json")


def drain_spool(path=None):
    """Read + delete a spooled permanent-hang record from the PREVIOUS session
    (or None). Called once on plugin start: a record here means QGIS was hung
    badly enough last time that the live (recover-then-report) path never fired —
    exactly the freezes that matter most. Best-effort, never raises."""
    path = path or _DEFAULT_SPOOL
    try:
        with open(path, encoding="utf-8") as f:
            rec = json.load(f)
    except Exception:
        return None
    try:
        os.remove(path)
    except Exception:
        pass
    if isinstance(rec, dict) and rec.get("duration_ms"):
        rec["from_previous_session"] = True
        return rec
    return None


class FreezeWatchdog:
    """Start with start(report_cb); report_cb(record: dict) is called ON THE
    MAIN THREAD for each finished freeze. `record` keys: duration_ms, severity,
    stack_text, fingerprint, started_iso."""

    HEARTBEAT_MS = 1000        # main-thread liveness stamp
    CHECK_INTERVAL = 0.5       # daemon poll
    FREEZE_THRESHOLD = 3.0     # seconds blocked before it counts as a freeze
    FROZEN_THRESHOLD = 8.0     # >= this is reported as "frozen" (vs "slow")
    PERMA_THRESHOLD = 25.0     # >= this, treat as a likely PERMANENT hang and spool
    SPOOL_REFRESH_S = 10.0     # while spooled, rewrite at most this often (grow duration)
    GRACE_S = 6.0              # ignore the first N s (plugin/QGIS startup)
    COOLDOWN_S = 60.0          # min seconds between reports of the same fingerprint
    SUSPEND_GAP = 10.0         # daemon-loop gap (s) above which we test for OS suspend

    def __init__(self):
        self._main_id = threading.main_thread().ident
        self._last_alive = time.monotonic()
        self._start_mono = time.monotonic()
        self._stop = threading.Event()
        self._thread = None
        self._timer = None
        self._lock = threading.Lock()
        self._pending = []                 # finished freezes awaiting main-thread report
        self._seen = {}                    # fingerprint -> last_reported_monotonic
        self._report_cb = None
        # in-progress freeze state (daemon-owned)
        self._fz_active = False
        self._fz_max = 0.0
        self._fz_stack = ""
        self._fz_fp = ""
        self._fz_started = 0.0
        self._fz_spooled_at = 0.0          # last duration (s) we wrote to the spool, 0 = not spooled
        self._spool_path = _DEFAULT_SPOOL
        # daemon-loop liveness — to tell a real main-thread hang (daemon kept running)
        # apart from whole-process suspension i.e. laptop sleep (daemon stopped too).
        self._last_check_mono = time.monotonic()
        self._last_check_cpu = time.process_time()

    # ── lifecycle ────────────────────────────────────────────────────────────
    def start(self, main_window, report_cb, spool_path=None):
        self._report_cb = report_cb
        if spool_path:
            self._spool_path = spool_path
        try:
            from qgis.PyQt.QtCore import QTimer
            self._timer = QTimer(main_window)
            self._timer.setInterval(self.HEARTBEAT_MS)
            self._timer.timeout.connect(self._on_heartbeat)
            self._timer.start()
        except Exception:
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._monitor, name="VFFreezeWatchdog", daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        try:
            if self._timer is not None:
                self._timer.stop()
                self._timer.deleteLater()
        except Exception:
            pass
        self._timer = None
        t = self._thread
        if t is not None:
            try:
                t.join(timeout=2.0)
            except Exception:
                pass
        self._thread = None

    # ── main thread: liveness stamp + report drain ─────────────────────────────
    def _on_heartbeat(self):
        # If we're here, the event loop is responsive → stamp + flush any freezes
        # the daemon captured while we were blocked.
        self._last_alive = time.monotonic()
        drained = None
        with self._lock:
            if self._pending:
                drained = self._pending
                self._pending = []
        if drained and callable(self._report_cb):
            for rec in drained:
                try:
                    self._report_cb(rec)
                except Exception:
                    pass

    # ── daemon thread: detect freezes (pure-Python only, never Qt) ─────────────
    def _monitor(self):
        while not self._stop.wait(self.CHECK_INTERVAL):
            try:
                self._check()
            except Exception:
                pass

    def _check(self):
        now = time.monotonic()
        cpu = time.process_time()
        # Whole-process suspension (laptop sleep/hibernate) vs a real main-thread hang:
        # the daemon's OWN loop runs every CHECK_INTERVAL. If it lost far more wall time
        # than that AND the process burned almost no CPU during the gap, the machine was
        # asleep — NOT a hang. (A real Python compute-hang starves the daemon too, but
        # pegs the CPU, so cpu_gap stays high.) Counting sleep as a freeze produced bogus
        # multi-hour reports — reset the baseline and skip without reporting.
        daemon_gap = now - self._last_check_mono
        cpu_gap = cpu - self._last_check_cpu
        self._last_check_mono = now
        self._last_check_cpu = cpu
        if daemon_gap >= self.SUSPEND_GAP and cpu_gap < daemon_gap * 0.3:
            self._last_alive = now
            if self._fz_active:
                self._fz_active = False
                self._clear_spool()
            return
        if now - self._start_mono < self.GRACE_S:
            return
        stale = now - self._last_alive
        if stale >= self.FREEZE_THRESHOLD:
            # main thread is currently blocked
            if not self._fz_active:
                self._fz_active = True
                self._fz_started = time.time()        # wall-clock start (for the record)
                self._fz_fp = ""
                self._fz_spooled_at = 0.0
            self._fz_max = stale
            # (re)capture the stuck stack — keep the latest sample
            txt, fp = self._capture_main_stack()
            if txt:
                self._fz_stack = txt
                self._fz_fp = fp
            # A hang this long likely won't recover before the user kills QGIS —
            # so the live "recover then report" path will never fire. Spool it to
            # disk from THIS (pure-Python) daemon thread so the next session can
            # report it. Refreshed occasionally so the recorded duration grows.
            if stale >= self.PERMA_THRESHOLD and stale - self._fz_spooled_at >= self.SPOOL_REFRESH_S:
                self._spool_current(stale)
        elif self._fz_active:
            # main thread just recovered → finalize this freeze (live report) and
            # drop any spool we wrote: the live path supersedes it (no double-report)
            self._finalize()
            self._clear_spool()

    def _finalize(self):
        dur = self._fz_max
        fp = self._fz_fp or "unknown"
        self._fz_active = False
        # dedup + cooldown
        now = time.monotonic()
        last = self._seen.get(fp, 0.0)
        if last and now - last < self.COOLDOWN_S:
            return
        self._seen[fp] = now
        if len(self._seen) > 200:
            # evict only the single oldest fingerprint — wiping the whole dict
            # would reset every other fingerprint's cooldown and let mid-cooldown
            # freezes re-spam, defeating the dedup guarantee.
            oldest = min(self._seen, key=self._seen.__getitem__)
            del self._seen[oldest]
        rec = {
            "duration_ms": int(dur * 1000),
            "severity": "frozen" if dur >= self.FROZEN_THRESHOLD else "slow",
            "stack_text": self._fz_stack or "<no stack captured>",
            "fingerprint": fp,
            "started_iso": _iso(self._fz_started),
        }
        with self._lock:
            self._pending.append(rec)
            if len(self._pending) > 50:
                self._pending = self._pending[-50:]

    def _spool_current(self, dur):
        """Write the in-progress (likely permanent) hang to disk from the daemon.
        Pure-Python file I/O only — GIL-safe, never touches Qt/QGIS."""
        rec = {
            "duration_ms": int(dur * 1000),
            "severity": "hung",               # distinct from recovered slow/frozen
            "stack_text": self._fz_stack or "<no stack captured>",
            "fingerprint": self._fz_fp or "unknown",
            "started_iso": _iso(self._fz_started),
        }
        try:
            os.makedirs(os.path.dirname(self._spool_path), exist_ok=True)
            tmp = self._spool_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(rec, f)
            os.replace(tmp, self._spool_path)      # atomic — never a half-written file
            self._fz_spooled_at = dur
        except Exception:
            pass

    def _clear_spool(self):
        if not self._fz_spooled_at:
            return
        try:
            os.remove(self._spool_path)
        except Exception:
            pass
        self._fz_spooled_at = 0.0

    def _capture_main_stack(self):
        """Top frames of the MAIN thread, scrubbed, + a fingerprint of the top 3
        (file:line). Pure-Python — safe from the daemon thread (GIL-protected)."""
        try:
            frame = sys._current_frames().get(self._main_id)
            if frame is None:
                return "", ""
            stack = traceback.extract_stack(frame)
        except Exception:
            return "", ""
        top = stack[-12:]
        lines = []
        for fr in top:
            fn = _scrub(fr.filename)
            lines.append(f'  File "{fn}", line {fr.lineno}, in {fr.name}\n'
                         f'    {(fr.line or "").strip()}')
        text = "\n".join(lines)
        fp_src = "|".join(f"{os.path.basename(fr.filename)}:{fr.lineno}:{fr.name}"
                          for fr in stack[-3:])
        fp = hashlib.sha1(fp_src.encode("utf-8", "replace")).hexdigest()[:12]
        return text, fp


def _scrub(text):
    if not text:
        return text
    try:
        text = text.replace(_HOME, "<user>")
        text = _PATH_RE.sub(lambda m: "<path>/" + os.path.basename(m.group(0)), text)
    except Exception:
        pass
    return text


def _iso(epoch):
    try:
        import datetime
        return datetime.datetime.fromtimestamp(
            epoch, datetime.timezone.utc).isoformat()
    except Exception:
        return ""
