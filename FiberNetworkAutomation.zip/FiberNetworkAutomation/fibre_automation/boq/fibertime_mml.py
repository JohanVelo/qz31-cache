"""fibertime_mml — Fibertime-approved "Master Material List" BoQ generator.

Reverse-engineered (2026-06-19, 6-agent analysis) from the 3 Fibertime-APPROVED
BoQs (MOA / MAM / LAW) so our output matches the structure + SKUs Fibertime signs
off — a per-SKU Bill of Materials, NOT a cost summary. Rates come from the bundled
`fibertime_rates.json` (2025 canonical price list). Shippable: openpyxl + stdlib +
native QGIS only.

Derivation (each rule cites the approved evidence in code comments):
  Cable     drops binned by length→DP-A/PRE SKUs · aerial/UG by (subtyp,cblcpty)→FIB
  Splitters STS(1:16 dome)→SPL029 · FTS(1:8 dome)→SPL063  (count by role, see note)
  Domes     enclosure spec_1 string→BOX/JOI SKU
  Midcoupl. 4*ODCFD0 + 8*M16
  Poles     1/pole, SKU by dim2 thickness band
  Hooks     Σ=Σpoles, split by cables-at-pole (fallback 10/81/7%)
  Hardware  dead-ends/tangents/slack/strapping/buckles (ratio rules; flagged)
  Splicing  splice protector + alcohol + kim wipes (from splice estimate)
  Home Conn 1 install-kit per ONT
All quantities scale to the LIVE design's feature counts (approved files are
whole-project; we ignore their numbers, keep their rates+SKUs).
"""
import json
import math
import os

_RATES_PATH = os.path.join(os.path.dirname(__file__), "fibertime_rates.json")

# ── cable SKU maps (subtyp, fibre-count) → FIB code  [agent 1] ──────────────
_ADSS = {"12F": "FIB124", "24F": "FIB243", "48F": "FIB431", "72F": "FIB710",
         "96F": "FIB907", "144F": "FIB125"}
_MINI = {"12F": "FIB915", "24F": "FIB916", "48F": "FIB917"}
_MICRO = {"12F": "FIB130", "24F": "FIB242", "48F": "FIB433", "72F": "FIB714",
          "96F": "FIB905", "144F": "FIB121", "288F": "FIB246"}
_DROP_BINS = [25, 30, 35, 40, 50, 60, 70]          # round UP; floor 25, cap 70

# enclosure spec_1 string → SKU  [agent 2]
# NB: most-specific keys FIRST — 'ODCFD0' is a substring of 'ODCFD08L', so the
# 8L variant must be tested before the prefix or it mis-matches to BOX181.
_ENCL_CONN = {"ODCFD08L": "BOX179", "ODCFD0": "BOX181",
              "M16 MICROLOOP": "BOX189", "M8 MICROLOOP": "BOX168"}
_ENCL_SPLICE = {"UMJ": "JOI033", "CMJ": "JOI028", "MMJ": "JOI027"}

# poles by dim2 thickness band  [agent 3]  (LCTT internal codes; rate fallback)
_POLE = {"120-140": ("POLE-CRE-7-120140", "Pole.Creosote.H4SANS754.7,0m.120-140", 554.46),
         "140-160": ("POLE-CRE-7-140160", "Pole.Creosote.H4SANS754.7,0m.140-160", 707.30)}
_HOOK = {1: "BRA063", 2: "BRA123", 3: "BRA064"}    # 1/2/3-way monopole bracket

_SECTION_ORDER = ["Cable", "Splitters", "Midcouplers", "Dome Joints", "Poles",
                  "Dead-Ends", "Tangents", "Hooks", "Slack Brackets",
                  "Strapping, Buckles & Coach Screws", "Labels", "Splicing",
                  "Home Connections", "Labour (Estimate)"]

# ── Labour (ESTIMATE only) ──────────────────────────────────────────────────
# These are the ONLY publicly-confirmed SA labour rates (2025-2026 market):
#   drop install R50-60/m · trenching R100-500/m. They are ROUGH ESTIMATES that
# vary hugely by contractor/terrain — every labour line is flagged "ESTIMATE,
# confirm with contractor" and totalled SEPARATELY from the (firm) material cost.
# Edit these two numbers to your own contractor rates.
_LABOUR_SECTION = "Labour (Estimate)"
LABOUR_DROP_INSTALL_PER_M = 55.0     # R50-60/m last-mile drop install (midpoint)
LABOUR_TRENCH_PER_M = 300.0          # R100-500/m underground trenching (midpoint)


def _load_rates():
    try:
        rb = json.load(open(_RATES_PATH, encoding="utf-8")).get("rate_book", {})
    except Exception:
        rb = {}
    return rb


class Line:
    __slots__ = (
        "category",
        "code",
        "desc",
        "note",
        "qty",
        "rate",
        "section",
        "supplier",
        "uom",
    )

    def __init__(self, section, code, qty, rb, uom=None, desc=None, category=None,
                 rate=None, supplier=None, note=""):
        info = rb.get(code, {})
        self.section = section
        self.code = code
        self.qty = qty
        self.category = category or info.get("category") or section
        self.desc = desc or info.get("description") or code
        self.uom = uom or info.get("uom") or "Each"
        self.rate = info.get("rate") if rate is None else rate
        self.supplier = supplier or info.get("supplier") or "FTTX"
        self.note = note


# ── design readers ──────────────────────────────────────────────────────────
def _norm_name(s):
    """Normalise a layer name for tolerant matching: lower-case, collapse spaces,
    and drop a trailing version suffix (' v1', ' V2', …) so 'Drop Cable v1'
    resolves to a project layer simply named 'Drop Cable'."""
    import re
    s = re.sub(r"\s+v\d+$", "", str(s).strip().lower())
    return re.sub(r"\s+", " ", s)


class _LayerMap(dict):
    """name -> layer. .get() falls back to a case-insensitive, version-suffix-
    tolerant match, so the canonical 'X v1' lookups in derive() still resolve
    against projects whose layers are named plainly ('X')."""

    def __init__(self, layers):
        super().__init__(layers)
        self._norm = {}
        for k, v in layers.items():
            self._norm.setdefault(_norm_name(k), v)

    def get(self, name, default=None):
        if name in self:
            return self[name]
        return self._norm.get(_norm_name(name), default)


def _layers(project):
    return _LayerMap({l.name(): l for l in project.mapLayers().values()})


def _utm(project):
    from qgis.core import (QgsDistanceArea, QgsCoordinateReferenceSystem)
    da = QgsDistanceArea()
    da.setSourceCrs(QgsCoordinateReferenceSystem("EPSG:32735"), project.transformContext())
    da.setEllipsoid("WGS84")
    return da


def _len_m(geom, src_crs, project):
    """Geodesic length in metres on the source-CRS geometry (kills the EPSG:4326
    degree bug — the proven setSourceCrs+ellipsoid pattern, same as boq/engine.py)."""
    from qgis.core import QgsDistanceArea
    try:
        da = QgsDistanceArea()
        da.setSourceCrs(src_crs, project.transformContext())
        # The project's ellipsoid is often "NONE" (ellipsoidal measure off) — a
        # TRUTHY string, so `or "WGS84"` would keep "NONE" and measureLength would
        # return DEGREES (~0) on a 4326 layer. Force a real ellipsoid so cable
        # metres + drop-length bins are correct.
        ell = project.ellipsoid()
        if not ell or str(ell).upper() == "NONE":
            ell = "WGS84"
        da.setEllipsoid(ell)
        v = da.measureLength(geom)
        return v if (v is not None and math.isfinite(v) and v >= 0) else 0.0
    except Exception:
        return 0.0


def _count(layer):
    return layer.featureCount() if layer else 0


def _attr(feat, name):
    try:
        i = feat.fields().indexFromName(name)
        return feat[i] if i >= 0 else None
    except Exception:
        return None


def _cap(val):
    """Normalise a fibre-capacity attribute to '24F' style."""
    if val is None:
        return None
    s = str(val).upper().replace(" ", "")
    if s and not s.endswith("F"):
        s += "F"
    return s


DEFAULT_SLACK_M = 15.0   # service-loop + pole-height added to each drawn drop before
#                          length-binning (best-fit to approved MOA; configurable, flagged)


def derive(project, slack_m=DEFAULT_SLACK_M):
    """Return (lines, diagnostics). Lines are ordered by _SECTION_ORDER."""
    rb = _load_rates()
    L = _layers(project)
    lines = []
    diag = {}

    def add(section, code, qty, **kw):
        if qty and qty > 0:
            lines.append(Line(section, code, qty, rb, **kw))

    # ── CABLE: aerial/underground by (subtyp, cblcpty) → FIB, Σ metres ──
    cable_layers = ["Primary Cable v1", "Secondary Cable v1", "Distribution Cable v1"]
    fib_tot = {}                              # code -> metres
    for nm in cable_layers:
        lyr = L.get(nm)
        if not lyr:
            continue
        crs = lyr.crs()
        for f in lyr.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            sub = str(_attr(f, "subtyp") or "").lower()
            cap = _cap(_attr(f, "cblcpty"))
            table = _ADSS if "adss" in sub and "mini" not in sub else \
                    _MINI if "mini" in sub else \
                    _MICRO if "micro" in sub or "blown" in sub else _MINI
            code = table.get(cap)
            if not code:
                continue
            fib_tot[code] = fib_tot.get(code, 0.0) + _len_m(g, crs, project)
    # spool/sag slack factors (from approved MOA/MAM/LAW back-calc; configurable)
    _ADSS_S, _MINI_S, _MICRO_S = set(_ADSS.values()), set(_MINI.values()), set(_MICRO.values())
    for code, m in sorted(fib_tot.items()):
        sf = (1.30 if code in _ADSS_S else 1.15 if code in _MINI_S
              else 1.12 if code in _MICRO_S else 1.0)
        add("Cable", code, round(m * sf), uom="Meter", note=f"x{sf} spool/sag slack")
    underground_m = sum(m for code, m in fib_tot.items() if code in _MICRO_S)

    # ── CABLE: drops binned by length → DP-A (3,0mm) / PRE (2,8mm) ──
    drop_bins = {}                            # (sku_family, bin) -> count
    total_drop_m = 0.0                        # raw route metres, for install labour
    for nm in ("Drop Cable v1", "Spare Drop Cable v1"):
        lyr = L.get(nm)
        if not lyr:
            continue
        crs = lyr.crs()
        for f in lyr.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            raw = _len_m(g, crs, project)
            total_drop_m += raw
            ln = raw + slack_m
            b = next((b for b in _DROP_BINS if ln <= b), _DROP_BINS[-1])  # round UP, cap 70
            dia = str(_attr(f, "dim1") or "3,0mm")
            fam = "PRE" if dia.startswith("2,8") else "DPA"   # by diameter [agent 1]
            drop_bins[(fam, b)] = drop_bins.get((fam, b), 0) + 1
    diag["drops_binned"] = sum(drop_bins.values())
    for (fam, b), c in sorted(drop_bins.items(), key=lambda x: x[0][1]):
        code = f"DP-A-1-LB-86/73-2-{b}" if fam == "DPA" else f"PRE0{b}FT"
        add("Cable", code, c, uom="Each",
            category="Drop Cable (Connectorised)",
            desc=f"Drop Cable.Connectorised.{'3,0mm' if fam=='DPA' else '2,8mm'}.1F.{b}m",
            supplier="Dartcom" if fam == "DPA" else "FTTX")

    # ── SPLITTERS: count by role (NB inverted ratio labels — map by count) ──
    n_sts = _count(L.get("STS Splitters v1"))           # 1:16 dome → SPL029
    n_fts = _count(L.get("FTS Splitters v1"))           # 1:8 dome  → SPL063
    add("Splitters", "SPL029", n_sts, note="STS (1:16 dome)")
    add("Splitters", "SPL063", n_fts, note="FTS (1:8 dome)")

    # ── DOME JOINTS: enclosures grouped by spec_1 string → SKU ──
    n_m16 = n_odcfd0 = 0
    for nm, table in (("Enclosures Connectorised v1", _ENCL_CONN),
                      ("Enclosures Splice v1", _ENCL_SPLICE)):
        lyr = L.get(nm)
        if not lyr:
            continue
        by = {}
        for f in lyr.getFeatures():
            spec = str(_attr(f, "spec_1") or "").upper()
            code = next((v for k, v in table.items() if k in spec), None)
            if code:
                by[code] = by.get(code, 0) + 1
                if "ODCFD0" in spec and "08L" not in spec:
                    n_odcfd0 += 1
                if "M16" in spec:
                    n_m16 += 1
        for code, c in sorted(by.items()):
            add("Dome Joints", code, c)

    # ── MIDCOUPLERS: 4*ODCFD0 + 8*M16  [agent 4 — matches LAW+MAM exactly] ──
    add("Midcouplers", "MID013", 4 * n_odcfd0 + 8 * n_m16)

    # ── POLES + pole-mounted hardware: COUNT the populated attribute SLOTS
    #    (slot1 Pole·dim2 · slot2 Dead-End·subtyp · slot3 Tangent·dim1_3 ·
    #     slot4 Hook·spec_4 way · slot5 Slack · slot6 Strapping·featno5 ·
    #     slot7 Buckle·featno6) + 1 Label/pole. The Fibertime BoQ is the SUM of
    #    these slots, not a ratio (proven vs approved MOA + MAM). ──
    import re as _re
    poles = L.get("Poles v1")
    n_poles = _count(poles)
    band = {"120-140": 0, "140-160": 0}
    tangent = {}      # dim1_3 band -> count
    hook = {}         # way (int) -> count
    slack = 0
    strap_u = buckle_u = 0
    deadend = {}      # subtyp -> count
    if poles:
        for f in poles.getFeatures():
            d = str(_attr(f, "dim2") or "").strip()
            # Only band poles whose thickness is actually populated — otherwise an
            # unclassified pole (FT7 not yet run) would silently inflate 120-140.
            if d:
                band["140-160" if "140-160" in d else "120-140"] += 1
            else:
                diag["poles_unclassified"] = diag.get("poles_unclassified", 0) + 1
            if str(_attr(f, "type_3") or "").lower().startswith("tangent"):
                k = str(_attr(f, "dim1_3") or "?")
                tangent[k] = tangent.get(k, 0) + 1
            if str(_attr(f, "type_4") or "").lower().startswith("hook"):
                m = _re.match(r"(\d+)", str(_attr(f, "spec_4") or ""))
                w = int(m.group(1)) if m else 0
                hook[w] = hook.get(w, 0) + 1
            if str(_attr(f, "type_5") or "").lower().startswith("slack"):
                slack += 1
            strap_u += int(_attr(f, "featno5") or 0)
            buckle_u += int(_attr(f, "featno6") or 0)
            s2 = _attr(f, "subtype_2") or _attr(f, "subtyp_2")
            if s2 and str(_attr(f, "type_2") or "").lower().startswith("dead"):
                deadend[str(s2)] = deadend.get(str(s2), 0) + 1
    for k, (code, desc, rate) in _POLE.items():
        add("Poles", code, band[k], uom="Each", desc=desc, rate=rate,
            supplier="LCTT", category="Poles (Creosote)")
    # Dead-Ends (slot2) by subtyp — 0 if the slot is empty in this design
    for st, c in sorted(deadend.items()):
        add("Dead-Ends", "DEA030", c, rate=24.55, category="Dead-End(Mini-ADSS)",
            desc=f"Dead-End.{st}", note="slot2 count")
    # Tangents (slot3) by diameter band
    for bnd, c in sorted(tangent.items()):
        add("Tangents", "TAN006", c, rate=99.78, category="Tangent (ADSS)",
            desc=f"Tangent.ADSS.{bnd}", note="slot3 count")
    # Hooks (slot4) by way
    _HOOKSKU = {1: ("BRA063", 37.91), 2: ("BRA123", 44.49), 3: ("BRA064", 55.73)}
    for w, c in sorted(hook.items()):
        code, rate = _HOOKSKU.get(w, ("BRA064", 55.73))
        add("Hooks", code, c, rate=rate, category="Hook (Monopole Bracket Offset)",
            desc=f"Hook.Monopole Bracket Offset.{w}-Way",
            note="slot4 count" + ("" if w <= 3 else f" ({w}-way→verify SKU)"))
    # Slack brackets (slot5)
    if slack:
        add("Slack Brackets", "SLA013", slack, note="slot5 count")
    # Strapping (Σ featno5 units → 30 m rolls) + Buckles (Σ featno6 → box of 100)
    if strap_u:
        add("Strapping, Buckles & Coach Screws", "BAN002",
            math.ceil(strap_u / 30.0), note=f"{strap_u} units / 30 m roll")
    if buckle_u:
        add("Strapping, Buckles & Coach Screws", "BAN003",
            math.ceil(buckle_u / 100.0), note=f"{buckle_u} units / box of 100")
    # Labels — 1 Chromadek nameplate per pole
    if n_poles:
        add("Labels", "SIG008", n_poles, rate=82.45, category="Label (Chromadek)",
            desc="Label.Chromadek.Pole nameplate", note="1 per pole")

    # ── SPLICING: protector + consumables from a splice estimate ──
    #   splices ≈ 1*(connectorised splitters) + 12*M16 + 212  [agent 4 LAW closed-form]
    splices = (n_sts + n_fts) + 12 * n_m16 + 212
    diag["splice_estimate"] = splices
    add("Splicing", "SPL076", splices, note="ESTIMATE — splice-plan is authoritative")
    add("Splicing", "ALC001", math.ceil(splices / 350))
    add("Splicing", "KIM001", math.ceil(splices / 280))

    # ── HOME CONNECTIONS: the per-home install kit, matched line-for-line to the
    #    approved MOA BoQ (14 SKUs @ 1/home). Priced SKUs come from the rate book;
    #    the codeless ones (Free Supply / quote-on-request / R3) are spelled out. ──
    n_ont = _count(L.get("ONT v1"))
    diag["ont"] = n_ont
    for code in ("ONT001", "PLU024", "EXT003", "TIE016", "TIE001", "CLI023"):
        add("Home Connections", code, n_ont)
    add("Home Connections", "PLU021", n_ont, category="Electrical")
    add("Home Connections", "PIG029", n_ont, category="Wall Attchment")
    # codeless install-kit SKUs present in the approved BoQ but previously omitted
    # (code, desc, category, uom, rate, supplier). rate None = quote-on-request (TBD).
    for code, desc, cat, uom, rate, sup in (
            ("WALL-BRKT", "Wall Attachment.ONT Bracket.1 per Home", "Wall Attachment", "Each", 0.0, "Fiber Time"),
            ("WALL-SADL", "Wall Attachment.Saddles.15 per Home", "Wall Attachment", "Each", None, "FTTX"),
            ("SCR-FH", "Screw.Flathead self tapping screws", "Screw", "Pair", None, "FTTX"),
            ("SCR-ST", "Screw.Self Tapping Screws.2 per Home", "Screw", "Pair", None, "FTTX"),
            ("LBL-ONT", "Label.ONT Sticker.1 per Home", "Label", "Each", 0.0, "Fiber Time"),
            ("ELE-GLAND", "Electrical.Entry Gland.1 per Home", "Electrical", "Each", 3.0, "FTTX")):
        add("Home Connections", code, n_ont, desc=desc, category=cat, uom=uom, rate=rate, supplier=sup)
    add("Home Connections", "WAY122", round(n_ont * 0.10, 1), uom="Meter",
        note="0.10 m/home (per description)")

    # ── LABOUR (ESTIMATE — separate subtotal, confirm with contractor) ──
    add(_LABOUR_SECTION, "LAB-DROP", round(total_drop_m), uom="Meter",
        rate=LABOUR_DROP_INSTALL_PER_M, supplier="Contractor",
        category="Drop Cable Installation",
        desc="Labour.Drop install (last-mile to home)",
        note="ESTIMATE R50-60/m — confirm with contractor")
    add(_LABOUR_SECTION, "LAB-TRENCH", round(underground_m), uom="Meter",
        rate=LABOUR_TRENCH_PER_M, supplier="Contractor",
        category="Trenching (Underground)",
        desc="Labour.Trenching for underground/micro-duct",
        note="ESTIMATE R100-500/m by soil — confirm with contractor")
    diag["labour_drop_m"] = round(total_drop_m)
    diag["labour_trench_m"] = round(underground_m)

    # order by section
    lines.sort(key=lambda x: (_SECTION_ORDER.index(x.section)
                              if x.section in _SECTION_ORDER else 99))
    diag["poles"] = n_poles
    diag["lines"] = len(lines)
    return lines, diag


# ── Excel writer — exact Fibertime "Master Material List" format [agent 5] ──
def write_mml(lines, path, project_name="Velocity Nexus"):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    CYAN = PatternFill("solid", fgColor="01D9F2")
    YELLOW = PatternFill("solid", fgColor="FCE639")
    BANNER = PatternFill("solid", fgColor="FFFF99")
    WHITE = PatternFill("solid", fgColor="FFFFFF")
    F_TITLE = Font(name="Aptos Narrow", size=14, bold=True)
    F_HDR = Font(name="Aptos Narrow", size=12, bold=True)
    F_BODY = Font(name="Aptos Narrow", size=11)
    F_SUB = Font(name="Aptos Narrow", size=11, bold=True)
    CENTER = Alignment(horizontal="center")
    RATE_FMT, COST_FMT = r"\R#,##0.00", '"R"#,##0.00'
    HEADERS = ["Item No", "UoM", "Item Category", "Description", "Quantity",
               "Item Code", "Item Rate", "Supplier", "Lead Time", "Total Item Cost"]

    wb = Workbook()
    ws = wb.active
    ws.title = "Master Material List"
    ws.merge_cells("A1:J1")
    t = ws["A1"]; t.value = "MASTER MATERIAL LIST - FIBERTIME"
    t.font = F_TITLE; t.fill = CYAN; t.alignment = CENTER
    ws.row_dimensions[1].height = 18.5
    for i, h in enumerate(HEADERS, 1):
        c = ws.cell(row=2, column=i, value=h); c.font = F_HDR; c.fill = YELLOW; c.alignment = CENTER

    r = 3
    item_no = 0
    labour_banner_row = None                  # first row of the Labour section, if any
    from itertools import groupby
    for section in _SECTION_ORDER:
        seclines = [l for l in lines if l.section == section]
        if not seclines:
            continue
        if section == _LABOUR_SECTION:
            labour_banner_row = r
        ws.merge_cells(f"A{r}:J{r}")
        b = ws.cell(row=r, column=1, value=section); b.font = F_BODY; b.fill = BANNER; b.alignment = CENTER
        r += 1
        # group by category as a sub-header
        for cat, grp in groupby(seclines, key=lambda x: x.category):
            grp = list(grp)
            sc = ws.cell(row=r, column=4, value=cat); sc.font = F_SUB; sc.alignment = CENTER
            r += 1
            for l in grp:
                item_no += 1
                ws.cell(row=r, column=1, value=item_no).font = F_BODY
                ws.cell(row=r, column=2, value=l.uom).font = F_BODY
                ws.cell(row=r, column=3, value=l.category).font = F_BODY
                ws.cell(row=r, column=4, value=l.desc).font = F_BODY
                ws.cell(row=r, column=5, value=l.qty).font = F_BODY
                ws.cell(row=r, column=6, value=l.code).font = F_BODY
                rc = ws.cell(row=r, column=7, value=l.rate)
                rc.font = F_BODY; rc.number_format = RATE_FMT; rc.fill = WHITE
                ws.cell(row=r, column=8, value=l.supplier).font = F_BODY
                ws.cell(row=r, column=9, value=l.note).font = F_BODY
                tc = ws.cell(row=r, column=10, value=f"=SUM(G{r}*E{r})")
                tc.font = F_BODY; tc.number_format = COST_FMT
                for col in (1, 2, 5, 6, 7, 8, 10):
                    ws.cell(row=r, column=col).alignment = CENTER
                r += 1
    # totals (MAM-style). Labour is kept in its OWN subtotal so it never inflates
    # the firm material cost; Total Project Cost = material + labour (estimate).
    BOLD = Font(name="Aptos Narrow", size=11, bold=True)
    last = r - 1

    def _total(row, label, formula, fill):
        lc = ws.cell(row=row, column=6, value=label); lc.font = BOLD; lc.fill = fill
        # value goes in column J (Total Item Cost), the column it sums.
        vc = ws.cell(row=row, column=10, value=formula); vc.font = BOLD; vc.fill = fill
        vc.number_format = COST_FMT

    if labour_banner_row:
        mat_last = labour_banner_row - 1
        _total(r + 1, "Total Material Cost", f"=SUM(J3:J{mat_last})", CYAN)
        _total(r + 2, "Total Labour Cost (estimate)",
               f"=SUM(J{labour_banner_row}:J{last})", YELLOW)
        _total(r + 3, "Total Project Cost (incl. labour est.)",
               f"=SUM(J3:J{last})", CYAN)
    else:
        _total(r + 1, "Total Material Cost", f"=SUM(J3:J{last})", CYAN)

    widths = {1: 9, 2: 9, 3: 34, 4: 60, 5: 12, 6: 28, 7: 14, 8: 12, 9: 26, 10: 18}
    for col, w in widths.items():
        ws.column_dimensions[chr(64 + col)].width = w

    # Validations sheet (pole lead-times + rates) [agent 5]
    vs = wb.create_sheet("Validations")
    vs["B2"] = "Lists"; vs["B2"].fill = CYAN
    vs["B3"] = "Pole Lead Times"; vs["B3"].fill = YELLOW
    for i, region in enumerate(("Immediate (Gauteng)", "Immediate (Port Elizabeth)",
                                "Immediate (Western Cape)"), 4):
        vs.cell(row=i, column=2, value=region)

    # atomic save
    _dir = os.path.dirname(path) or "."
    import tempfile
    fd, tmp = tempfile.mkstemp(suffix=".xlsx", dir=_dir); os.close(fd)
    try:
        wb.save(tmp); os.replace(tmp, path)
    except PermissionError:
        try: os.remove(tmp)
        except Exception: pass
        raise RuntimeError(f"Cannot write — close '{os.path.basename(path)}' in Excel and retry.")
    return path


def run_fibertime_boq(out_path=None, project=None, slack_m=DEFAULT_SLACK_M):
    from qgis.core import QgsProject
    project = project or QgsProject.instance()
    out_path = out_path or os.path.join(
        os.path.expanduser("~"), (project.baseName() or "Project") + "_Fibertime_BoQ.xlsx")
    lines, diag = derive(project, slack_m=slack_m)
    write_mml(lines, out_path, project.baseName() or "Velocity Nexus")
    return {"path": out_path, "lines": len(lines), "diag": diag}
