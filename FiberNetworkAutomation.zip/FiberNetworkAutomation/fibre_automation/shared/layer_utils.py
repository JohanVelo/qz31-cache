"""Create layers, add fields, set symbology — shared by both pipelines."""

from qgis.PyQt.QtCore import QMetaType
import os

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsField,
    QgsFields,
    QgsLayerTreeGroup,
    QgsProject,
    QgsSingleSymbolRenderer,
    QgsFillSymbol,
    QgsLineSymbol,
    QgsMarkerSymbol,
    QgsVectorFileWriter,
    QgsVectorLayer,
)
from qgis.PyQt.QtGui import QColor

S = QMetaType.Type.QString
D = QMetaType.Type.Double
I = QMetaType.Type.Int
L = QMetaType.Type.LongLong


# ---------------------------------------------------------------------------
# Layer creation
# ---------------------------------------------------------------------------

def create_shapefile(
    layer_name: str,
    wkb_type,
    field_defs: list,
    folder_path: str,
    crs_authid: str = "EPSG:4326",
    overwrite: bool = False,
) -> str:
    """Write an empty shapefile to disk. Returns the .shp path.

    field_defs: list of (field_name, QVariant type) tuples.
    """
    safe_name = layer_name.replace(" ", "_")
    shp_path = os.path.join(folder_path, f"{safe_name}.shp")
    if os.path.exists(shp_path) and not overwrite:
        return shp_path  # already exists, skip

    crs = QgsCoordinateReferenceSystem(crs_authid)
    ctx = QgsProject.instance().transformContext()
    fields = QgsFields()
    for fname, ftype in field_defs:
        fields.append(QgsField(fname, ftype))

    opts = QgsVectorFileWriter.SaveVectorOptions()
    opts.driverName = "ESRI Shapefile"
    opts.actionOnExistingFile = QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteFile

    writer = QgsVectorFileWriter.create(shp_path, fields, wkb_type, crs, ctx, opts)
    if writer.hasError() != QgsVectorFileWriter.WriterError.NoError:
        raise RuntimeError(f'Failed to create "{layer_name}": {writer.errorMessage()}')
    del writer
    return shp_path


def load_or_create_layer(
    layer_name: str,
    shp_path: str,
    group: QgsLayerTreeGroup,
) -> QgsVectorLayer:
    """Load a shapefile as a QGIS layer into the given layer tree group.

    If a layer with that name already exists in the project, returns it.
    Prints '✓ Created' or '⊘ Exists' status.
    """
    proj = QgsProject.instance()

    # Check if already loaded
    existing = proj.mapLayersByName(layer_name)
    if existing:
        print(f"  ⊘ Exists: {layer_name}")
        return existing[0]

    lyr = QgsVectorLayer(shp_path, layer_name, "ogr")
    if not lyr.isValid():
        print(f"  ✗ INVALID: {layer_name} — {shp_path}")
        return None

    proj.addMapLayer(lyr, False)
    group.addLayer(lyr)
    print(f"  ✓ Created: {layer_name}")
    return lyr


def get_or_create_group(group_name: str, parent=None) -> QgsLayerTreeGroup:
    """Get or create a layer tree group under parent (root if None)."""
    root = QgsProject.instance().layerTreeRoot()
    target = parent if parent is not None else root

    existing = target.findGroup(group_name)
    if existing:
        return existing
    return target.addGroup(group_name)


# ---------------------------------------------------------------------------
# Symbology helpers
# ---------------------------------------------------------------------------


def _apply_aoi_outline_style(lyr: QgsVectorLayer) -> None:
    """Black 1.06 mm solid outline, no fill."""
    from qgis.core import QgsSimpleFillSymbolLayer, QgsUnitTypes
    from qgis.PyQt.QtCore import Qt

    fill_layer = QgsSimpleFillSymbolLayer()
    fill_layer.setBrushStyle(Qt.BrushStyle.NoBrush)
    fill_layer.setStrokeColor(QColor(0, 0, 0))
    fill_layer.setStrokeWidth(1.06)
    fill_layer.setStrokeWidthUnit(QgsUnitTypes.RenderUnit.RenderMillimeters)
    fill_layer.setPenJoinStyle(Qt.PenJoinStyle.BevelJoin)
    sym = QgsFillSymbol()
    sym.changeSymbolLayer(0, fill_layer)
    lyr.setRenderer(QgsSingleSymbolRenderer(sym))
    lyr.triggerRepaint()


def apply_vuma_style(lyr: QgsVectorLayer):
    """Apply canonical Vuma styles (extracted from Malmsbury V1.1)."""
    name_lc = lyr.name().lower()
    geom = lyr.geometryType()  # 0=Point 1=Line 2=Polygon
    sym = None

    if geom == 0:
        POINT_STYLES = [
            ("aggregation joint", "0,180,0,60", "#008000", "0.6", "5.0"),
            ("feeder joints",     "0,255,36,255", "#232323", "0", "6.1"),
            ("link joints",       "35,35,240,255", "#232323", "0", "5.5"),
            ("spur joints",       "255,26,243,255", "#232323", "0", "3.8"),
            ("dome joint",        "255,0,0,255", "#232323", "0", "3.8"),
            ("4 way splitter",    "255,0,0,255", "#000000", "0.5", "2.6"),
            ("demand point",      "222,33,175,180", "#b40000", "0.15", "1.5"),
            ("node",              "255,0,0,255", "#8b0000", "0.4", "3.0"),
            ("pole",              "255,242,0,255", "#232323", "0", "1.4"),
        ]
        for key, color, outline, ow, size in POINT_STYLES:
            if key in name_lc:
                sym = QgsMarkerSymbol.createSimple(
                    {
                        "name": "circle",
                        "color": color,
                        "outline_color": outline,
                        "outline_width": ow,
                        "size": size,
                    }
                )
                break

    elif geom == 1:
        LINE_STYLES = [
            ("road crossing underground", "#c8a214", "2.1"),
            ("distribution cable",        "#d30000", "0.46"),
            ("link cable",                "#2323d5", "0.86"),
            ("spur cable",                "#f831de", "0.66"),
            ("feeder",                    "#00ff24", "0.66"),
            ("drops",                     "#30ecdd", "0.26"),
            ("core",                      "#ff00ff", "0.80"),
        ]
        for key, color, width in LINE_STYLES:
            if key in name_lc:
                sym = QgsLineSymbol.createSimple({"color": color, "width": width})
                break

    elif geom == 2:
        if "p2 aoi" in name_lc:
            _apply_aoi_outline_style(lyr)
            return
        POLY_STYLES = [
            ("aggregation polygon", "255,178,35,60", "#000000", "0.9",  "solid"),
            ("block",               "37,171,0,60",   "#000000", "0.86", "solid"),
            ("building",            "0,200,200,100",  "#007878", "0.15", "solid"),
            ("erven",               "0,0,0,0",        "#000000", "0.4",  "solid"),
        ]
        for key, fill, outline, ow, ostyle in POLY_STYLES:
            if key in name_lc:
                sym = QgsFillSymbol.createSimple(
                    {
                        "color": fill,
                        "outline_color": outline,
                        "outline_width": ow,
                        "outline_style": ostyle,
                    }
                )
                break

    if sym:
        lyr.setRenderer(QgsSingleSymbolRenderer(sym))
        lyr.triggerRepaint()


def apply_ft_style(lyr: QgsVectorLayer):
    """Apply Fibre Time symbology — canonical colours from fibretime_tools QML spec."""
    name_lc = lyr.name().lower()
    geom = lyr.geometryType()  # 0=Point 1=Line 2=Polygon
    sym = None

    if geom == 0:
        # (key, fill_rgba, outline_rgba, outline_width, size) — more-specific keys first
        POINT_STYLES = [
            ("enclosures connectorised", "164,113,88,255",  "0,0,0,255",  "0",   "2.0"),
            ("enclosures splice",        "114,155,111,255", "0,0,0,255",  "0",   "3.2"),
            ("fts splitter",             "0,245,88,255",    "0,0,0,255",  "0",   "2.0"),
            ("sts splitter",             "13,13,245,255",   "0,0,0,255",  "0",   "2.0"),
            ("home connection",          "255,158,23,255",  "0,0,0,255",  "0",   "2.0"),
            ("ont",                      "190,207,80,255",  "0,0,0,255",  "0",   "2.0"),
            ("pole",                     "248,0,5,255",     "0,0,0,255",  "0",   "2.0"),
        ]
        for key, color, outline, ow, size in POINT_STYLES:
            if key in name_lc:
                sym = QgsMarkerSymbol.createSimple({
                    "name": "circle",
                    "color": color,
                    "outline_color": outline,
                    "outline_width": ow,
                    "size": size,
                })
                break

    elif geom == 1:
        # (key, color_rgba, width) — more-specific keys first
        LINE_STYLES = [
            ("spare drop",      "253,14,11,255",   "0.26"),
            ("primary cable",   "253,14,11,255",   "2.06"),
            ("secondary cable", "0,0,0,255",       "0.66"),
            ("distribution",    "241,14,228,255",  "0.66"),
            ("drop cable",      "0,0,0,255",       "0.26"),
            ("span",            "0,6,255,255",     "0.86"),
        ]
        for key, color, width in LINE_STYLES:
            if key in name_lc:
                sym = QgsLineSymbol.createSimple({"color": color, "width": width})
                break

    elif geom == 2:
        if "p2 aoi" in name_lc:
            _apply_aoi_outline_style(lyr)
            return
        # (key, fill_rgba, outline_rgba, outline_width, outline_style)
        POLY_STYLES = [
            ("pon",      "9,240,248,56",    "9,240,248,255",  "0.46", "solid"),
            ("zones",    "231,113,72,100",  "0,0,0,255",      "0.26", "solid"),
            ("building", "255,158,23,100",  "0,0,0,255",      "0.26", "solid"),
            ("erven",    "0,0,0,0",         "17,17,3,255",    "0.26", "solid"),
        ]
        for key, fill, outline, ow, ostyle in POLY_STYLES:
            if key in name_lc:
                sym = QgsFillSymbol.createSimple({
                    "color": fill,
                    "outline_color": outline,
                    "outline_width": ow,
                    "outline_style": ostyle,
                })
                break

    if sym:
        lyr.setRenderer(QgsSingleSymbolRenderer(sym))
        lyr.triggerRepaint()


def apply_label(lyr: QgsVectorLayer, field: str = "Name", size: int = 8):
    """Enable simple name labels with white halo on a layer."""
    from qgis.core import QgsPalLayerSettings, QgsVectorLayerSimpleLabeling, QgsTextFormat, QgsTextBufferSettings
    from qgis.PyQt.QtGui import QFont

    fmt = QgsTextFormat()
    font = QFont()
    font.setPointSize(size)
    fmt.setFont(font)
    buf = QgsTextBufferSettings()
    buf.setEnabled(True)
    buf.setSize(1.0)
    buf.setColor(QColor("white"))
    fmt.setBuffer(buf)

    pal = QgsPalLayerSettings()
    pal.setFormat(fmt)
    pal.fieldName = field
    pal.enabled = True

    lyr.setLabeling(QgsVectorLayerSimpleLabeling(pal))
    lyr.setLabelsEnabled(True)
    lyr.triggerRepaint()
