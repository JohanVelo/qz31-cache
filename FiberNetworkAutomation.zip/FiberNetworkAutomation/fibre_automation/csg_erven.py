"""csg_erven — fetch REAL surveyed erven (property polygons) from the South African
Chief Surveyor-General cadastral MapServer for an AOI bbox.

This is the authoritative source of erf boundaries for SA — far better than deriving
a synthetic stand grid. Layer 2 of the CSG service is Erven (PRCL_TYPE='E'). The
service caps results per query, so we paginate. Pure stdlib + shapely for the core;
a geopandas wrapper is provided for the erven_studio worker.

Coverage is honest: formal townships are surveyed (Mohadin returns ~8.9k erven);
genuinely informal/un-surveyed pockets return nothing there — the caller falls back
to the derived grid for those.
"""
import json
import urllib.parse
import urllib.request

LAYER_URL = ("https://dffeportal.environment.gov.za/hosting/rest/services/"
             "CSG_Cadaster/CSG_Cadastral_Data/MapServer/2/query")
_PAGE = 1000
_TIMEOUT = 60


def _get(params):
    url = LAYER_URL + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": "VelocityNexus/CSG"})
    with urllib.request.urlopen(req, timeout=_TIMEOUT) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def count(bbox):
    """How many erven intersect the bbox (xmin,ymin,xmax,ymax in EPSG:4326)."""
    xmin, ymin, xmax, ymax = bbox
    try:
        d = _get({"geometry": f"{xmin},{ymin},{xmax},{ymax}",
                  "geometryType": "esriGeometryEnvelope", "inSR": "4326",
                  "spatialRel": "esriSpatialRelIntersects",
                  "returnCountOnly": "true", "f": "json"})
        return int(d.get("count", 0))
    except Exception:
        return -1


def _rings_to_poly(rings):
    from shapely.geometry import Polygon
    polys = [Polygon(r) for r in (rings or []) if len(r) >= 4]
    if not polys:
        return None
    polys.sort(key=lambda p: p.area, reverse=True)
    ext = polys[0]
    holes = [list(p.exterior.coords) for p in polys[1:]
             if ext.contains(p.representative_point())]
    return Polygon(ext.exterior.coords, holes) if holes else ext


def fetch_erven(bbox):
    """Return [(prcl_key, area_m2, shapely_polygon)] for erven (PRCL_TYPE='E')
    intersecting bbox (EPSG:4326), paginated past the server limit."""
    xmin, ymin, xmax, ymax = bbox
    base = {"geometry": f"{xmin},{ymin},{xmax},{ymax}",
            "geometryType": "esriGeometryEnvelope", "inSR": "4326", "outSR": "4326",
            "spatialRel": "esriSpatialRelIntersects", "outFields": "*",
            "returnGeometry": "true", "f": "json"}
    out, offset = [], 0
    while True:
        d = _get({**base, "resultOffset": offset, "resultRecordCount": _PAGE})
        fs = d.get("features", [])
        for ft in fs:
            a = ft.get("attributes", {})
            if str(a.get("PRCL_TYPE", "")).strip().upper() != "E":
                continue
            g = _rings_to_poly((ft.get("geometry") or {}).get("rings"))
            if g is None or g.is_empty:
                continue
            out.append((a.get("PRCL_KEY"), a.get("GEOM_AREA"), g))
        if len(fs) < _PAGE and not d.get("exceededTransferLimit"):
            break
        if not fs:
            break
        offset += len(fs)
    return out


def fetch_erven_gdf(bbox, max_area_m2=5000.0):
    """GeoDataFrame (EPSG:4326) of erven for the bbox. Giant non-residential
    parcels (> max_area_m2, e.g. farms/public places) are dropped so the result is
    house-bearing stands. Returns an empty GeoDataFrame if the area is un-surveyed."""
    import geopandas as gpd
    recs = fetch_erven(bbox)
    rows, geoms = [], []
    for key, area, g in recs:
        if max_area_m2 and area and float(area) > max_area_m2:
            continue
        rows.append({"prcl_key": key, "area_m2": area})
        geoms.append(g)
    return gpd.GeoDataFrame(rows, geometry=geoms, crs="EPSG:4326")
