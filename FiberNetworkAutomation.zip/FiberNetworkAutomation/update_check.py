"""update_check — notify the user inside the Velocity Nexus panel when a
newer plugin version is on the team channel, with a one-click update.

Checks the channel's plugins.xml (a ~1 KB fetch) shortly after startup and
every 30 minutes after that, fully async via QgsNetworkAccessManager — no
UI blocking, silent on any network failure. When the remote version is
newer than the installed one it shows the panel banner (and a one-time
message-bar notice per version).
"""
from __future__ import annotations

import os
import re

from qgis.core import QgsNetworkAccessManager
from qgis.PyQt.QtCore import QTimer, QUrl
from qgis.PyQt.QtNetwork import QNetworkRequest

PLUGINS_XML_URL = ("https://raw.githubusercontent.com/JohanVelo/qz31-cache/"
                   "main/plugins.xml")
PLUGIN_ZIP_URL = ("https://raw.githubusercontent.com/JohanVelo/qz31-cache/"
                  "main/FiberNetworkAutomation.zip")
PLUGIN_PKG = "FiberNetworkAutomation"
FIRST_CHECK_MS = 8000           # shortly after startup
RECHECK_MS = 30 * 60 * 1000    # every 30 minutes (plugins.xml fallback path)
# The INSTANT path: the Supabase announcements table is written the moment a
# publish runs (publish_plugin.announce_update) and is NOT behind GitHub's
# ~5-min raw-CDN cache, so polling it on a tight interval surfaces the banner
# almost immediately for anyone working in QGIS.
ANNOUNCE_FIRST_MS = 5000        # ~5 s after startup
ANNOUNCE_POLL_MS = 60 * 1000    # every 60 s while QGIS is open
# Reporter replies — the office answers a ticket in Velocity Relay; the reply is
# written to ticket_notifications, and the reporter's plugin polls for its own.
NOTIF_FIRST_MS = 8000
NOTIF_POLL_MS = 60 * 1000


def _supabase():
    """(url, anon_key) for the announcements read. Public by design (anon key,
    SELECT-only RLS on announcements). Import from the bundled config; fall back
    to the known public values so a path hiccup never disables the check."""
    try:
        from .fibre_automation.nexus_profile import config as _cfg
        return _cfg.SUPABASE_URL, _cfg.SUPABASE_ANON_KEY
    except Exception:
        try:
            from fibre_automation.nexus_profile import config as _cfg
            return _cfg.SUPABASE_URL, _cfg.SUPABASE_ANON_KEY
        except Exception:
            return ("https://hrrdohlrfrficrtphcet.supabase.co",
                    "sb_publishable_LLMH2UZAmWGRws9j-aIWRQ_wVJ9qeOF")


def _ver_tuple(s):
    try:
        return tuple(int(x) for x in re.findall(r"\d+", s)[:4])
    except Exception:
        return (0,)


def installed_version():
    mp = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                      "metadata.txt")
    try:
        with open(mp, encoding="utf-8") as f:
            m = re.search(r"^version=([\d.]+)", f.read(), flags=re.M)
        return m.group(1) if m else "0"
    except Exception:
        return "0"


def _hot_reload():
    """Reliable SAME-SESSION reload so the new code takes effect with no QGIS
    restart. unloadPlugin alone leaves nested packages cached in sys.modules
    (Python then re-uses the OLD files) and does not always drop the Processing
    provider — so we: unload → force-remove the provider → evict every stale
    submodule → load + start. Raises on hard failure so the caller can degrade
    to a 'restart needed' message instead of leaving a half-loaded plugin."""
    import sys
    from qgis.utils import unloadPlugin, loadPlugin, startPlugin
    # a) unload — runs the plugin's own unload() (stops timers, removes
    #    toolbars/docks, removes its processing provider).
    try:
        unloadPlugin(PLUGIN_PKG)
    except Exception:
        pass
    # b) belt-and-braces: make sure the provider is really gone before re-import,
    #    else re-registration can error or duplicate.
    try:
        from qgis.core import QgsApplication
        reg = QgsApplication.processingRegistry()
        for pid in ("fibernetwork", PLUGIN_PKG):
            p = reg.providerById(pid)
            if p is not None:
                reg.removeProvider(p)
    except Exception:
        pass
    # c) evict every cached submodule so the NEW files are actually re-imported.
    #    (The running do_upgrade/_hot_reload frame keeps the old function objects
    #    alive, so evicting our own module here is safe.)
    for k in [m for m in list(sys.modules)
              if m == PLUGIN_PKG or m.startswith(PLUGIN_PKG + ".")
              or m == "fibre_automation" or m.startswith("fibre_automation.")
              or m.startswith("fiber_processing_provider")
              or m.startswith("fiber_network_plugin")]:
        try:
            del sys.modules[k]
        except Exception:
            pass
    # d) re-import + start (re-runs initGui()/initProcessing() on fresh code).
    loadPlugin(PLUGIN_PKG)
    startPlugin(PLUGIN_PKG)


def _fresh_install_zip():
    """Download the latest plugin zip with a CACHE-BUSTING query and extract it
    over the installed plugin folder. This bypasses BOTH GitHub's edge CDN and
    QGIS's own HTTP cache — the bug that made repeated 'Update now' clicks keep
    re-installing the SAME old version in a loop. Returns the version string in
    the downloaded zip. Raises on any failure (caller falls back)."""
    import io
    import os
    import re as _re
    import time as _t
    import urllib.request
    import zipfile
    from qgis.core import QgsApplication
    url = f"{PLUGIN_ZIP_URL}?nocache={int(_t.time())}"
    req = urllib.request.Request(
        url, headers={"Cache-Control": "no-cache", "Pragma": "no-cache"})
    data = urllib.request.urlopen(req, timeout=90).read()
    zf = zipfile.ZipFile(io.BytesIO(data))
    if zf.testzip() is not None:
        raise ValueError("downloaded zip is corrupt")
    meta = zf.read(f"{PLUGIN_PKG}/metadata.txt").decode("utf-8", "replace")
    m = _re.search(r"^version=([\d.]+)", meta, _re.M)
    ver = m.group(1) if m else None
    plugins_dir = os.path.join(
        QgsApplication.qgisSettingsDirPath(), "python", "plugins")
    if not os.path.isdir(os.path.join(plugins_dir, PLUGIN_PKG)):
        raise RuntimeError("installed plugin folder not found")
    zf.extractall(plugins_dir)          # overwrite in place (pure-Python; no locks)
    return ver


def do_upgrade():
    """Download the latest version and HOT-RELOAD it in-session — no QGIS
    restart. Module-level on purpose (runs from a timer, detached from the widget
    being replaced).

    Robust against the cache-loop: the zip is fetched with a cache-busting query
    so neither GitHub's CDN nor QGIS's HTTP cache can serve a stale build, and we
    VERIFY the installed version actually advanced before claiming success — so a
    click can never silently re-install the same version and re-prompt forever.
    Degrade-not-crash with clear messages at every step."""
    from qgis.utils import iface

    def _msg(text, ok=True):
        try:
            from qgis.core import Qgis
            iface.messageBar().pushMessage(
                "Velocity Nexus", text,
                level=Qgis.MessageLevel.Success if ok
                else Qgis.MessageLevel.Warning, duration=7)
        except Exception:
            pass

    before = installed_version()
    target = None
    # 1. fetch + install the new files (cache-busted direct download).
    try:
        target = _fresh_install_zip()
    except Exception:
        # fall back to QGIS's native installer (may hit its cache, but better
        # than nothing if the direct download is blocked).
        try:
            import pyplugin_installer
            inst = pyplugin_installer.instance()
            inst.fetchAvailablePlugins(True)
            inst.installPlugin(PLUGIN_PKG)
        except Exception as e2:
            _msg(f"Update download failed ({e2}) — use Plugins → Manage and "
                 "Install Plugins → Upgradeable.", ok=False)
            return
    # 2. hot-reload so it's live without a restart.
    try:
        _hot_reload()
    except Exception as e:
        _msg(f"Downloaded v{target or '?'}, but the in-place reload failed ({e}). "
             "Restart QGIS to finish — your activation is kept.", ok=False)
        return
    # 3. VERIFY the version actually advanced (kills the re-install loop).
    now = installed_version()
    if _ver_tuple(now) <= _ver_tuple(before) and (
            not target or _ver_tuple(now) < _ver_tuple(target)):
        _msg(f"Update didn't take (still v{now}) — GitHub may still be "
             "propagating; try again in a minute.", ok=False)
        return
    _msg(f"Updated to v{now} — reloaded, no restart needed.")


class UpdateChecker:
    """Owns the timer + async fetch. panel_getter() -> VelocityHomePanel."""

    def __init__(self, iface, panel_getter, user_getter=None):
        self.iface = iface
        self._panel_getter = panel_getter
        self._user_getter = user_getter   # () -> current user's display_name/username
        self._notified_version = None
        self._reply = None
        self._nreply = None             # in-flight reporter-replies fetch
        self._areply = None             # in-flight announcements fetch
        self._manual = False            # True = a user pressed "Check for updates"
        self._bar_item = None           # persistent message-bar notification
        self._timer = QTimer(iface.mainWindow())
        self._timer.timeout.connect(self.check_now)
        self._timer.start(RECHECK_MS)
        self._first = QTimer(iface.mainWindow())   # owned -> stop() can kill it
        self._first.setSingleShot(True)
        self._first.timeout.connect(self.check_now)
        self._first.start(FIRST_CHECK_MS)
        # INSTANT path — poll the announcements table (no CDN lag) every 60 s so
        # a fresh publish surfaces the banner almost immediately while working.
        self._atimer = QTimer(iface.mainWindow())
        self._atimer.timeout.connect(self.check_announcements)
        self._atimer.start(ANNOUNCE_POLL_MS)
        self._afirst = QTimer(iface.mainWindow())
        self._afirst.setSingleShot(True)
        self._afirst.timeout.connect(self.check_announcements)
        self._afirst.start(ANNOUNCE_FIRST_MS)
        # reporter-replies poll (office answers from Velocity Relay)
        self._ntimer = QTimer(iface.mainWindow())
        self._ntimer.timeout.connect(self.check_replies)
        self._ntimer.start(NOTIF_POLL_MS)
        self._nfirst = QTimer(iface.mainWindow())
        self._nfirst.setSingleShot(True)
        self._nfirst.timeout.connect(self.check_replies)
        self._nfirst.start(NOTIF_FIRST_MS)

    def stop(self):
        for t in (self._timer, getattr(self, "_first", None),
                  getattr(self, "_atimer", None), getattr(self, "_afirst", None),
                  getattr(self, "_ntimer", None), getattr(self, "_nfirst", None)):
            try:
                t.stop()
                t.deleteLater()
            except Exception:
                pass
        for r in (self._reply, getattr(self, "_areply", None),
                  getattr(self, "_nreply", None)):
            if r is not None:
                try:
                    r.abort()
                except Exception:
                    pass
        self._pop_bar()
        try:
            if getattr(self, "_popup", None) is not None:
                self._popup.close()
                self._popup = None
        except Exception:
            pass

    def _pop_bar(self):
        if self._bar_item is not None:
            try:
                self.iface.messageBar().popWidget(self._bar_item)
            except Exception:
                pass
            self._bar_item = None

    # ── check ────────────────────────────────────────────────────────────
    def check_now_manual(self, *_):
        """Entry point for the panel/toolbar 'Check for updates' button. Unlike
        the silent timer check, this always gives feedback — 'You're on the
        latest', the update prompt, or 'couldn't check'."""
        self._manual = True
        try:
            from qgis.core import Qgis
            self.iface.messageBar().pushMessage(
                "Velocity Nexus", "Checking for updates…",
                level=Qgis.MessageLevel.Info, duration=2)
        except Exception:
            pass
        # If a silent fetch is already in flight, the in-flight reply now honours
        # the manual flag — no need to start a second request.
        self.check_now()

    def _manual_feedback(self, text, ok=True):
        if not self._manual:
            return
        self._manual = False
        try:
            from qgis.core import Qgis
            self.iface.messageBar().pushMessage(
                "Velocity Nexus", text,
                level=Qgis.MessageLevel.Success if ok
                else Qgis.MessageLevel.Warning,
                duration=5)
        except Exception:
            pass

    def _notify(self, local, remote):
        """Surface an available update. The quiet in-dock panel banner refreshes
        every time (so it stays visible while behind), but the attention-grabbing
        popup + message bar fire ONLY ONCE per version — the seen version is
        persisted in QgsSettings so neither a 60-second re-poll nor a plugin
        reload can turn it into a popup loop."""
        self._notified_version = remote
        self._refresh_banner(remote)
        try:
            from qgis.core import QgsSettings
            s = QgsSettings()
            if s.value("VelocityFibre/update_popup_version") == remote:
                return                  # already popped this version — no loop
            s.setValue("VelocityFibre/update_popup_version", remote)
        except Exception:
            pass
        self._show_bar(local, remote)
        self._show_popup(local, remote)

    def check_now(self):
        if self._reply is not None:     # a fetch is already in flight
            return
        try:
            req = QNetworkRequest(QUrl(PLUGINS_XML_URL))
            req.setRawHeader(b"Cache-Control", b"no-cache")
            try:
                req.setTransferTimeout(15000)   # Qt 5.15+: never hang forever
            except Exception:
                pass
            self._reply = QgsNetworkAccessManager.instance().get(req)
            self._reply.finished.connect(self._on_reply)
        except Exception:
            self._reply = None          # network stack unavailable — retry later

    # ── instant path: poll the announcements table (no CDN lag) ────────────
    def check_announcements(self):
        if getattr(self, "_areply", None) is not None:
            return                      # a fetch is already in flight
        try:
            url, key = _supabase()
            q = (f"{url}/rest/v1/announcements?select=title,created_at"
                 "&order=created_at.desc&limit=5")
            req = QNetworkRequest(QUrl(q))
            req.setRawHeader(b"apikey", key.encode())
            req.setRawHeader(b"Authorization", b"Bearer " + key.encode())
            req.setRawHeader(b"Cache-Control", b"no-cache")
            try:
                req.setTransferTimeout(15000)
            except Exception:
                pass
            self._areply = QgsNetworkAccessManager.instance().get(req)
            self._areply.finished.connect(self._on_announce_reply)
        except Exception:
            self._areply = None

    def _on_announce_reply(self):
        reply, self._areply = getattr(self, "_areply", None), None
        if reply is None:
            return
        try:
            if int(reply.error()) != 0:    # offline etc. — silently retry later
                return
            body = bytes(reply.readAll()).decode("utf-8", "replace")
        except Exception:
            return
        finally:
            try:
                reply.deleteLater()
            except Exception:
                pass
        # newest "Update available - vX" version across the recent rows
        best = None
        for mt in re.finditer(r'"title"\s*:\s*"([^"]*)"', body):
            title = mt.group(1)
            if "update available" not in title.lower():
                continue
            mv = re.search(r"v?(\d+(?:\.\d+){1,3})", title)
            if mv and (best is None
                       or _ver_tuple(mv.group(1)) > _ver_tuple(best)):
                best = mv.group(1)
        if not best:
            return
        local = installed_version()
        if _ver_tuple(best) <= _ver_tuple(local):
            return                      # already current — nothing to show
        self._notify(local, best)

    # ── reporter replies: poll ticket_notifications for THIS user ──────────
    def _recipient(self):
        try:
            return (self._user_getter() or "").strip() if self._user_getter else ""
        except Exception:
            return ""

    def check_replies(self):
        if getattr(self, "_nreply", None) is not None:
            return                          # a fetch is already in flight
        who = self._recipient()
        if not who:
            return                          # not signed in / unknown — nothing to poll
        try:
            import urllib.parse
            url, key = _supabase()
            q = (f"{url}/rest/v1/ticket_notifications?select=id,ticket_id,body,created_at"
                 f"&recipient=eq.{urllib.parse.quote(who)}&order=id.desc&limit=10")
            req = QNetworkRequest(QUrl(q))
            req.setRawHeader(b"apikey", key.encode())
            req.setRawHeader(b"Authorization", b"Bearer " + key.encode())
            req.setRawHeader(b"Cache-Control", b"no-cache")
            try:
                req.setTransferTimeout(15000)
            except Exception:
                pass
            self._nreply = QgsNetworkAccessManager.instance().get(req)
            self._nreply.finished.connect(self._on_replies_reply)
        except Exception:
            self._nreply = None

    def _on_replies_reply(self):
        reply, self._nreply = getattr(self, "_nreply", None), None
        if reply is None:
            return
        try:
            if int(reply.error()) != 0:     # offline etc. — retry later
                return
            body = bytes(reply.readAll()).decode("utf-8", "replace")
        except Exception:
            return
        finally:
            try:
                reply.deleteLater()
            except Exception:
                pass
        try:
            import json
            rows = json.loads(body)
            if not isinstance(rows, list) or not rows:
                return
        except Exception:
            return
        from qgis.core import QgsSettings
        s = QgsSettings()
        try:
            last = int(s.value("VelocityFibre/relay_last_notif", 0) or 0)
        except Exception:
            last = 0
        mx = max(int(r.get("id", 0) or 0) for r in rows)
        # First ever poll on this machine: adopt the high-water mark silently so
        # we never dump the whole reply history as "new".
        if last == 0:
            s.setValue("VelocityFibre/relay_last_notif", mx)
            return
        fresh = [r for r in rows if int(r.get("id", 0) or 0) > last]
        if not fresh:
            return
        s.setValue("VelocityFibre/relay_last_notif", mx)
        fresh.sort(key=lambda r: int(r.get("id", 0) or 0))   # oldest first
        try:
            from qgis.core import Qgis
            for r in fresh[-3:]:            # show at most the latest 3, rest are marked seen
                tid = r.get("ticket_id")
                txt = str(r.get("body") or "").replace("\n", " ").strip()
                if len(txt) > 220:
                    txt = txt[:217] + "…"
                self.iface.messageBar().pushMessage(
                    "Velocity Nexus — reply on your ticket"
                    + (f" #{tid}" if tid else ""),
                    txt, level=Qgis.MessageLevel.Info, duration=14)
        except Exception:
            pass

    def _on_reply(self):
        reply, self._reply = self._reply, None
        if reply is None:
            return
        try:
            if int(reply.error()) != 0:    # 0 = NoError in PyQt5 AND PyQt6
                self._manual_feedback(
                    "Couldn't reach the update server — check your connection "
                    "and try again.", ok=False)
                return                  # offline etc. — silently retry later
            xml = bytes(reply.readAll()).decode("utf-8", "replace")
        except Exception:
            self._manual_feedback(
                "Couldn't read the update info — try again shortly.", ok=False)
            return
        finally:
            try:
                reply.deleteLater()
            except Exception:
                pass
        m = re.search(r"<version>([\d.]+)</version>", xml)
        if not m:
            self._manual_feedback(
                "Couldn't read the update info — try again shortly.", ok=False)
            return
        remote = m.group(1)
        local = installed_version()
        if _ver_tuple(remote) <= _ver_tuple(local):
            self._manual_feedback(
                f"You're on the latest version (v{local}).")
            return
        self._manual = False            # the banner/popup below is the feedback
        self._notify(local, remote)

    def _show_popup(self, local, remote):
        """Floating themed window — the message bar lives over the map
        canvas, which is INVISIBLE on the QGIS start page (Recent Projects),
        so a freshly-opened QGIS would never see the update. This popup is
        visible everywhere. Once per version per session."""
        try:
            from qgis.PyQt.QtCore import Qt
            from qgis.PyQt.QtWidgets import (QDialog, QHBoxLayout, QLabel,
                                             QPushButton, QVBoxLayout)
            old = getattr(self, "_popup", None)
            if old is not None:
                try:
                    old.close()
                except Exception:
                    pass
            dlg = QDialog(self.iface.mainWindow())
            dlg.setWindowTitle("Velocity Nexus — Update available")
            dlg.setMinimumWidth(420)
            dlg.setStyleSheet(
                "QDialog{background:#0F1A30;}"
                "QLabel{color:#EAF0FF;font-size:12px;}"
                "QLabel#hdr{color:#2ec4f1;font-size:16px;font-weight:800;}"
                "QPushButton{border-radius:7px;padding:8px 18px;"
                "font-weight:700;font-size:12px;}"
                "QPushButton#go{background:#2ec4f1;color:#06121c;border:none;}"
                "QPushButton#go:hover{background:#5fd6ff;}"
                "QPushButton#later{background:transparent;color:#9fb4c8;"
                "border:1px solid #2a3c55;}"
                "QPushButton#later:hover{color:#EAF0FF;}")
            lay = QVBoxLayout(dlg)
            lay.setContentsMargins(20, 16, 20, 16)
            lay.setSpacing(10)
            hdr = QLabel("🚀  Update available")
            hdr.setObjectName("hdr")
            lay.addWidget(hdr)
            body = QLabel(
                f"Velocity Nexus v{remote} is out (you have v{local}) — "
                "new tools and fixes.\nOne click updates it; your "
                "activation is kept.")
            body.setWordWrap(True)
            lay.addWidget(body)
            row = QHBoxLayout()
            row.addStretch(1)
            later = QPushButton("Later")
            later.setObjectName("later")
            later.clicked.connect(dlg.close)
            row.addWidget(later)
            go = QPushButton("Update now")
            go.setObjectName("go")
            go.setCursor(Qt.CursorShape.PointingHandCursor)

            def _go():
                go.setEnabled(False)
                go.setText("Updating…")
                self.upgrade()
                dlg.close()

            go.clicked.connect(_go)
            row.addWidget(go)
            lay.addLayout(row)
            dlg.finished.connect(dlg.deleteLater)
            self._popup = dlg
            dlg.show()
            dlg.raise_()
            dlg.activateWindow()
        except Exception:
            pass

    def _show_bar(self, local, remote):
        """Persistent, can't-miss notification over the canvas with its own
        Update button — stays until the operator acts or dismisses it."""
        try:
            from qgis.core import Qgis
            from qgis.PyQt.QtWidgets import QPushButton
            bar = self.iface.messageBar()
            self._pop_bar()
            item = bar.createMessage(
                "Velocity Nexus",
                f"🚀 Update available — v{local} → v{remote} with new tools "
                "and fixes.")
            btn = QPushButton("Update now")

            def _go():
                btn.setEnabled(False)
                btn.setText("Updating…")
                self.upgrade()

            btn.clicked.connect(_go)
            item.layout().addWidget(btn)
            # duration 0 = stays on screen until clicked or dismissed
            self._bar_item = bar.pushWidget(item, Qgis.MessageLevel.Info, 0)
        except Exception:
            pass

    def _refresh_banner(self, remote):
        panel = None
        try:
            panel = self._panel_getter()
        except Exception:
            pass
        if panel is not None:
            try:
                panel.show_update_banner(remote, self.upgrade)
            except Exception:
                pass

    # ── upgrade ──────────────────────────────────────────────────────────
    def upgrade(self):
        self._pop_bar()                 # the old item must not outlive us
        try:
            self.iface.messageBar().pushInfo(
                "Velocity Nexus", "Updating — QGIS will reload the plugin…")
        except Exception:
            pass
        # detach from the panel's call stack before the plugin replaces itself
        QTimer.singleShot(50, do_upgrade)
