"""topology_qa — fast, dependency-free data-integrity / topology QA for the FTTH network.

Pure PyQGIS native (QgsSpatialIndex, QgsGeometry) + Python stdlib — NO numpy / networkx /
shapely / duckdb — so it runs in every teammate's stock QGIS, not just a dev box. Read-only
on the project: it never edits a layer.

Catches the defects that actually bite FTTH planners (and that broke our Steiner routing):
  * null / empty geometries (poles that need redrawing)
  * duplicate DR numbers / PON numbers / labels
  * out-of-range pon_no / zone math / DR numbers
  * cable DANGLES — an endpoint not snapped to any pole/splitter or other cable end
  * over-length spans (pole-to-pole vertex distance over the cable's limit)
  * ONTs outside the AOI

API:  run_qa(project, feedback=None) -> list[Issue dict]
      Issue = {severity, check, layer, fid, x, y, desc}
"""
import math
import re

from qgis.core import (QgsProject, QgsMapLayer, QgsWkbTypes, QgsSpatialIndex,
                       QgsFeature, QgsGeometry, QgsPointXY, QgsDistanceArea,
                       QgsCoordinateReferenceSystem, QgsUnitTypes)

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

# Phase-2 MOA spec constants (mirror CLAUDE.md / audit_all_ph2.py)
PON_LO, PON_HI = 235, 298
DR_LO, DR_HI = 1853300, 1886299
SNAP_M = 10.0                       # endpoint-to-node snap tolerance
SPAN_MAX_M = 70.0                   # ADSS feeder/distribution span limit
DROP_MAX_M = 50.0                   # drop-span limit

# Ellipsoidal distance calculator — TRUE metres regardless of source CRS
# (projected UTM *or* geographic EPSG:4326). Configured per-project in run_qa /
# check_dangles_and_spans; NEVER the EPSG:4326 degrees*111320 bug the spec forbids.
_DA = QgsDistanceArea()


def _configure_distance(project):
    """Set up the module distance calculator for this project's CRS + ellipsoid."""
    try:
        crs = project.crs()
        if not crs or not crs.isValid():
            crs = QgsCoordinateReferenceSystem("EPSG:4326")
        _DA.setSourceCrs(crs, project.transformContext())
        ell = crs.ellipsoidAcronym() or "WGS84"
        _DA.setEllipsoid(ell)
    except Exception:
        # last-resort: a sane default so measureLine still returns metres
        try:
            _DA.setEllipsoid("WGS84")
        except Exception:
            _swallowed_note()


def _vlayers(project):
    return [l for l in project.mapLayers().values()
            if l.type() == QgsMapLayer.LayerType.VectorLayer]


def _find(project, *keys):
    """First vector layer whose name contains ALL keys (case-insensitive)."""
    for l in _vlayers(project):
        nl = l.name().lower()
        if all(k in nl for k in keys):
            return l
    return None


def _field(layer, *cands):
    fields = [f.name() for f in layer.fields()]
    for c in cands:
        for f in fields:
            if f.lower() == c.lower():
                return f
    return None


def _pt(geom):
    """A representative QgsPointXY for any geometry (centroid fallback)."""
    try:
        if geom.type() == QgsWkbTypes.GeometryType.PointGeometry:
            return geom.asPoint() if not geom.isMultipart() else geom.asMultiPoint()[0]
        return geom.centroid().asPoint()
    except Exception:
        return QgsPointXY(0, 0)


def _endpoints(geom):
    """Start + end vertex of a (multi)line as QgsPointXY, or []."""
    try:
        if geom.isMultipart():
            parts = geom.asMultiPolyline()
            ends = []
            for part in parts:
                if part:               # every part's own start + end (catches gaps)
                    ends.append(part[0])
                    ends.append(part[-1])
            return ends
        poly = geom.asPolyline()
        if len(poly) < 2:
            return []
        return [poly[0], poly[-1]]
    except Exception:
        return []


def _dist_m(a, b):
    """True ellipsoidal metres between two points (NOT degrees*111320)."""
    try:
        d = _DA.measureLine(a, b)
        # measureLine returns metres when an ellipsoid is set; convert if the
        # configured CRS reports another linear unit (defensive — normally metres)
        return _DA.convertLengthMeasurement(d, QgsUnitTypes.DistanceMeters)
    except Exception:
        return math.hypot(a.x() - b.x(), a.y() - b.y())


def _add(issues, severity, check, layer, fid, pt, desc):
    issues.append({"severity": severity, "check": check, "layer": layer,
                   "fid": fid, "x": pt.x() if pt else 0.0, "y": pt.y() if pt else 0.0,
                   "desc": desc})


# ── individual checks ─────────────────────────────────────────────────────────
def check_null_geoms(layers, issues):
    for l in layers:
        for ft in l.getFeatures():
            g = ft.geometry()
            if not g or g.isEmpty():
                _add(issues, "ERROR", "null_geometry", l.name(), ft.id(), None,
                     f"{l.name()} feature {ft.id()} has null/empty geometry")


def check_duplicates(layer, field, issues, check="duplicate"):
    if layer is None or field is None:
        return
    seen = {}
    for ft in layer.getFeatures():
        v = ft[field]
        if v in (None, "", "NULL"):
            continue
        key = str(v).strip()
        if key in seen:
            _add(issues, "ERROR", check, layer.name(), ft.id(), _pt(ft.geometry()) if ft.geometry() and not ft.geometry().isEmpty() else None,
                 f"duplicate {field}={key} (also FID {seen[key]})")
        else:
            seen[key] = ft.id()


def check_range(layer, field, lo, hi, issues, check="range", severity="ERROR"):
    # Range invariants (PON 235-298, DR 1853300-1886299) are HARD spec defects, not
    # advisories — default ERROR so gates that treat WARN as non-blocking still catch them.
    if layer is None or field is None:
        return
    for ft in layer.getFeatures():
        v = ft[field]
        try:
            iv = int(float(str(v)))
        except (ValueError, TypeError):
            continue
        if not (lo <= iv <= hi):
            _add(issues, severity, check, layer.name(), ft.id(),
                 _pt(ft.geometry()) if ft.geometry() and not ft.geometry().isEmpty() else None,
                 f"{field}={iv} outside [{lo},{hi}]")


def check_zone_math(pon_layer, issues):
    """zone_no must equal (pon_no-235)//16 + 17."""
    if pon_layer is None:
        return
    fp, fz = _field(pon_layer, "pon_no", "pon"), _field(pon_layer, "zone_no", "zone")
    if not fp or not fz:
        return
    for ft in pon_layer.getFeatures():
        try:
            p, z = int(float(str(ft[fp]))), int(float(str(ft[fz])))
        except (ValueError, TypeError):
            continue
        if not (PON_LO <= p <= PON_HI):
            # out-of-range PON is already reported by check_range; computing a zone
            # from it would print a nonsense "expected" value, so skip the math here
            continue
        expect = (p - PON_LO) // 16 + 17
        if z != expect:
            _add(issues, "ERROR", "zone_math", pon_layer.name(), ft.id(),
                 _pt(ft.geometry()) if ft.geometry() and not ft.geometry().isEmpty() else None,
                 f"PON {p}: zone_no={z} but expected {expect}")


_DR_RE = re.compile(r"DR\s*0*(\d+)", re.IGNORECASE)


def check_dr_range(layer, issues, check="dr_range"):
    """Drop DR numbers (parsed from a DR<num> label/dr field) must fall in [DR_LO,DR_HI].
    A drop carrying a DR from another phase/project is a real defect, not a collision."""
    if layer is None:
        return
    field = _field(layer, "dr", "dr_no", "drnum", "label", "name")
    if field is None:
        return
    for ft in layer.getFeatures():
        v = ft[field]
        if v in (None, "", "NULL"):
            continue
        m = _DR_RE.search(str(v))
        if not m:
            continue
        dr = int(m.group(1))
        if not (DR_LO <= dr <= DR_HI):
            _add(issues, "ERROR", check, layer.name(), ft.id(),
                 _pt(ft.geometry()) if ft.geometry() and not ft.geometry().isEmpty() else None,
                 f"DR{dr} outside [{DR_LO},{DR_HI}]")


def _node_index(project):
    """QgsSpatialIndex over all pole + splitter points; returns (index, id->point)."""
    idx = QgsSpatialIndex()
    pts = {}
    nid = 0
    for l in _vlayers(project):
        nl = l.name().lower()
        if l.geometryType() != QgsWkbTypes.GeometryType.PointGeometry:
            continue
        if not any(k in nl for k in ("pole", "fts", "sts", "splitter", "enclosure")):
            continue
        for ft in l.getFeatures():
            g = ft.geometry()
            if not g or g.isEmpty():
                continue
            p = _pt(g)
            f = QgsFeature(nid)
            f.setGeometry(QgsGeometry.fromPointXY(p))
            idx.insertFeature(f)
            pts[nid] = p
            nid += 1
    return idx, pts


def check_dangles_and_spans(project, issues):
    """Cable endpoints must snap to a node or another cable end; spans must fit limit."""
    _configure_distance(project)
    node_idx, node_pts = _node_index(project)
    # collect every cable endpoint for endpoint-to-endpoint snapping
    end_idx = QgsSpatialIndex()
    end_pts = {}
    eid = 0
    # actual fibre cable plant only — NOT the "Span" planning skeleton (its endpoints
    # deliberately don't coincide; flagging them would bury real defects in noise)
    cable_layers = [l for l in _vlayers(project)
                    if l.geometryType() == QgsWkbTypes.GeometryType.LineGeometry
                    and any(k in l.name().lower() for k in ("cable", "feeder", "drop", "distribution", "secondary", "primary"))
                    and "span" not in l.name().lower()]
    cable_ends = []                       # (layer, fid, point)
    for l in cable_layers:
        for ft in l.getFeatures():
            g = ft.geometry()
            if not g or g.isEmpty():
                continue
            for p in _endpoints(g):
                f = QgsFeature(eid)
                f.setGeometry(QgsGeometry.fromPointXY(p))
                end_idx.insertFeature(f)
                end_pts[eid] = p
                cable_ends.append((l, ft.id(), p, eid))
                eid += 1
    has_nodes = bool(node_pts)
    for l, fid, p, my_eid in cable_ends:
        snapped = False
        if has_nodes:
            for nb in node_idx.nearestNeighbor(p, 1):
                if _dist_m(p, node_pts[nb]) <= SNAP_M:
                    snapped = True
                    break
        if not snapped:
            # endpoint-to-endpoint: any OTHER cable end within tolerance?
            for nb in end_idx.nearestNeighbor(p, 3):
                if nb != my_eid and _dist_m(p, end_pts[nb]) <= SNAP_M:
                    snapped = True
                    break
        if not snapped:
            _add(issues, "ERROR", "cable_dangle", l.name(), fid, p,
                 f"{l.name()} endpoint not snapped to any pole/splitter/cable (>{SNAP_M:.0f} m)")
    # over-length spans (consecutive vertices)
    for l in cable_layers:
        is_drop = "drop" in l.name().lower()
        limit = DROP_MAX_M if is_drop else SPAN_MAX_M
        for ft in l.getFeatures():
            g = ft.geometry()
            if not g or g.isEmpty():
                continue
            lines = g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]
            for line in lines:
                for a, b in zip(line, line[1:]):
                    d = _dist_m(a, b)
                    if d > limit + 0.5:
                        mid = QgsPointXY((a.x() + b.x()) / 2, (a.y() + b.y()) / 2)
                        _add(issues, "ERROR", "span_over_limit", l.name(), ft.id(), mid,
                             f"{l.name()} span {d:.0f} m > {limit:.0f} m limit")


def check_referential_integrity(project, issues):
    """Every non-null ONT/Drop pon_no must reference a PON that exists in the PON layer.
    (NULL pon_no is fine — FT5/FT6 set it later; only orphan NON-null refs are defects.)"""
    pon = _find(project, "pon")
    if pon is None:
        return
    fp = _field(pon, "pon_no", "pon")
    if not fp:
        return
    valid = set()
    for ft in pon.getFeatures():
        try:
            valid.add(int(float(str(ft[fp]))))
        except (ValueError, TypeError):
            pass
    if not valid:
        return
    for l in _vlayers(project):
        nl = l.name().lower()
        if not any(k in nl for k in ("ont", "home", "drop")):
            continue
        f = _field(l, "pon_no", "pon")
        if not f:
            continue
        for ft in l.getFeatures():
            v = ft[f]
            if v in (None, "", "NULL"):
                continue
            try:
                iv = int(float(str(v)))
            except (ValueError, TypeError):
                continue
            if iv not in valid:
                _add(issues, "ERROR", "orphan_pon_ref", l.name(), ft.id(),
                     _pt(ft.geometry()) if ft.geometry() and not ft.geometry().isEmpty() else None,
                     f"{l.name()} references pon_no={iv} with no matching PON feature")


def check_onts_outside_aoi(project, issues):
    ont = _find(project, "ont")
    aoi = _find(project, "aoi") or _find(project, "boundary")
    if ont is None or aoi is None:
        return
    aoi_geom = QgsGeometry.unaryUnion([f.geometry() for f in aoi.getFeatures()
                                       if f.geometry() and not f.geometry().isEmpty()])
    if aoi_geom is None or aoi_geom.isEmpty():
        return
    eng = QgsGeometry.createGeometryEngine(aoi_geom.constGet())
    eng.prepareGeometry()
    n = 0
    for ft in ont.getFeatures():
        g = ft.geometry()
        if not g or g.isEmpty():
            continue
        # intersects (not contains) so an ONT digitized exactly ON the AOI edge is
        # allowed — only a point strictly OUTSIDE the AOI is a defect
        if not eng.intersects(g.constGet()):
            n += 1
            if n <= 200:
                _add(issues, "WARN", "ont_outside_aoi", ont.name(), ft.id(), _pt(g),
                     "ONT lies outside the AOI polygon")


# ── orchestrator ──────────────────────────────────────────────────────────────
def run_qa(project=None, feedback=None):
    project = project or QgsProject.instance()
    issues = []

    def step(fn, *a):
        try:
            fn(*a)
        except Exception as e:           # one bad check never sinks the whole QA
            if feedback is not None:
                try:
                    feedback.pushInfo(f"QA check {fn.__name__} skipped: {e}")
                except Exception:
                    _swallowed_note()

    layers = _vlayers(project)
    step(check_null_geoms, layers, issues)
    drop = _find(project, "drop")
    pon = _find(project, "pon")
    step(check_duplicates, drop, _field(drop, "label", "name") if drop else None, issues, "duplicate_dr")
    step(check_duplicates, pon, _field(pon, "pon_no", "pon") if pon else None, issues, "duplicate_pon")
    step(check_range, pon, _field(pon, "pon_no", "pon") if pon else None, PON_LO, PON_HI, issues, "pon_range")
    step(check_dr_range, drop, issues, "dr_range")
    step(check_zone_math, pon, issues)
    step(check_referential_integrity, project, issues)
    step(check_dangles_and_spans, project, issues)
    step(check_onts_outside_aoi, project, issues)
    return issues
