# QGIS Plugin: Fiber Network Automation
# Main plugin class — config-driven toolbar
# claude:approved-destructive — EnclosureEditorPanel writes only on explicit UI button clicks

import os
from collections import OrderedDict
from qgis.core import QgsApplication, QgsProject
from qgis.core import Qgis  # Qt6: messageBar/log levels are Qgis.MessageLevel enums
from qgis.PyQt.QtWidgets import QApplication, QDialog, QHBoxLayout, QLabel, QFrame, QToolButton, QMenu, QWidgetAction, QWidget, QDockWidget
from qgis.PyQt.QtGui import QAction
from qgis.PyQt.QtCore import Qt, QSize, QTimer
from qgis.PyQt.QtGui import QIcon

from .fiber_processing_provider import FiberNetworkProvider

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

try:
    from . import theme_safe
except ImportError:
    pass   # standalone fallback


# ══════════════════════════════════════════════════════════════════════════════
# TOOLBAR_SPEC — the single source of truth for every button on the toolbar.
# Add a new automation = one dict entry. Flip enabled:False → True to activate.
# ══════════════════════════════════════════════════════════════════════════════

TOOLBAR_SPEC = [
    # ── Brand tile + quick action (inline) ────────────────────────────────────
    {"id": "brand",      "kind": "brand",  "group": "quick"},
    {"id": "run_q",      "kind": "action", "group": "quick", "client": "dev",
     "label": "⚙ Run q.py", "icon": "/mActionTerminal.svg",
     "tooltip": "Copy  exec(open('C:/Temp/q.py').read())  to clipboard.\nPaste into the QGIS Python Console to run the script.",
     "callback": "_run_q"},
    {"id": "ai_detect",  "kind": "callback", "group": "quick", "client": "dev",
     "label": "AI Detect", "icon": "/mActionPointLayer.svg",
     "callback": "_erven_detect_run",
     "tooltip": (
        "AI DETECT — SAM2 AutoMask building footprints.\n"
        "─────────────────────────────\n"
        "1. Zoom canvas to ≤300m wide (1:1500 or closer)\n"
        "2. Click — current canvas extent is used\n"
        "3. Wait ~3–7 min · BF16 autocast on RTX 3050\n"
        "4. Layer 'Buildings_detected' added with confidence QA\n"
        "─────────────────────────────\n"
        "Server: erven_mcp HTTP @ 127.0.0.1:8780\n"
        "Start: python -m erven_mcp.server --http  (erven_detection/src/)\n"
        "GPU: RTX 3050 CUDA · sam2-hiera-small · BF16 autocast")
     },
    {"id": "ai_erven",  "kind": "callback", "group": "quick", "client": "dev",
     "label": "AI Erven", "icon": "/mActionAddPolygon.svg",
     "callback": "_erven_erven_run",
     "tooltip": (
        "AI ERVEN — Buildings + property parcels (momepy tessellation).\n"
        "─────────────────────────────\n"
        "Runs AI Detect THEN generates Erven_detected parcels:\n"
        "each building gets a territory extending to the road\n"
        "edge and the midpoint between neighbouring buildings.\n"
        "─────────────────────────────\n"
        "Requires: C:/Temp/roads.json  (run /roads to refresh)\n"
        "          momepy 0.11.0+ installed in qgis-venv\n"
        "Output layers: Buildings_detected + Erven_detected\n"
        "Time: ~5–10 min (canvas tile + tessellation)")
     },
    {"id": "velo_detect", "kind": "callback", "group": "quick", "client": "dev",
     "label": "AutoDetect", "icon": "/mActionInOverview.svg",
     "callback": "_velo_detect_run",
     "tooltip": (
        "VELODECT — batch SAM2 building detection over the full AOI.\n"
        "─────────────────────────────\n"
        "Tiles the entire AOI at 0.3 m/px, sends each 512px chip\n"
        "to the SAM2 server, and places all buildings as\n"
        "'AI Centroids' + 'AI Buildings' memory layers.\n"
        "─────────────────────────────\n"
        "SAM2: http://192.168.1.150:8102/predict\n"
        "No clicking required — processes full AOI automatically.\n"
        "Start server: python C:/Temp/sam2_server.py")
     },
    {"id": "update_git", "kind": "callback", "group": "quick", "client": "dev",
     "label": "⬇ Update", "icon": "/mActionRefresh.svg",
     "callback": "_update_from_github",
     "tooltip": (
        "UPDATE FROM GITHUB — pull the latest code and reload this plugin.\n"
        "─────────────────────────────\n"
        "1. Runs  git pull  in your VeloPlan repo clone\n"
        "2. Copies the updated plugin files into QGIS\n"
        "3. Reloads FiberNetworkAutomation live (no QGIS restart)\n"
        "─────────────────────────────\n"
        "First use: you'll be asked to pick your VeloPlan repo folder\n"
        "(the clone that contains a .git folder). Needs Git installed.")
     },
    # New project is handled entirely by the welcome dialog (_show_welcome_dialog)
    # which fires automatically on File → New.  No toolbar buttons needed here.

    # ── Labelling — PRAK / MALM legacy (dropdown) ─────────────────────────────
    {"id": "lbl_aggregation", "kind": "algo", "group": "labelling",
     "label": "Label Aggregation Polygons", "icon": "/mActionCapturePolygon.svg",
     "algorithm": "fibernetwork:labelaggregation",
     "tooltip": "PRAK / MALM — labels the aggregation polygons"},
    {"id": "lbl_blocks",      "kind": "algo", "group": "labelling",
     "label": "Label Blocks",               "icon": "/mActionCapturePolygon.svg",
     "algorithm": "fibernetwork:labelblocks",
     "tooltip": "PRAK / MALM — labels the block polygons"},
    {"id": "lbl_poles",       "kind": "algo", "group": "labelling",
     "label": "Label Poles",                "icon": "/mActionCapturePoint.svg",
     "algorithm": "fibernetwork:labelpoles",
     "tooltip": "PRAK / MALM — labels the poles"},
    {"id": "lbl_dome_joints", "kind": "algo", "group": "labelling",
     "label": "Label Dome Joints",          "icon": "/mActionCapturePoint.svg",
     "algorithm": "fibernetwork:labeldomejoints",
     "tooltip": "PRAK / MALM — labels the dome joints"},
    {"id": "lbl_feeder_joints","kind": "algo", "group": "labelling",
     "label": "Label Feeder Joints",        "icon": "/mActionCapturePoint.svg",
     "algorithm": "fibernetwork:labelfeederjoints",
     "tooltip": "PRAK / MALM — labels the feeder joints"},
    {"id": "lbl_demand_pts",  "kind": "algo", "group": "labelling",
     "label": "Label Demand Points",        "icon": "/mActionCapturePoint.svg",
     "algorithm": "fibernetwork:labeldemandpoints",
     "tooltip": "PRAK / MALM — labels the demand points"},
    {"id": "lbl_feeder_cables","kind": "algo", "group": "labelling",
     "label": "Label Feeder Cables",        "icon": "/mActionCaptureLine.svg",
     "algorithm": "fibernetwork:labelfeedercables",
     "tooltip": "PRAK / MALM — labels the feeder cables"},
    {"id": "lbl_dist_cables", "kind": "algo", "group": "labelling",
     "label": "Label Distribution Cables",  "icon": "/mActionCaptureLine.svg",
     "algorithm": "fibernetwork:labeldistributioncables",
     "tooltip": "PRAK / MALM — labels the distribution cables"},
    # ── Fibertime ▾ : FT 1-7 pipeline, then Compliance, then Automation ────────
    {"id": "ft_hdr_pipeline", "kind": "header", "group": "ft", "label": "FT pipeline"},
    {"id": "ft1", "kind": "algo", "group": "ft",
     "label": "FT1 · Label Poles",            "icon": "/mActionNewVectorLayer.svg",
     "algorithm": "fibernetwork:ft_label_poles",
     "tooltip": "Phase 2 / MOA — writes label, lat, lon to Poles v1"},
    {"id": "ft2", "kind": "algo", "group": "ft",
     "label": "FT2 · Label Distribution Cable","icon": "/mActionAddLineString.svg",
     "algorithm": "fibernetwork:ft_label_distribution_cable",
     "tooltip": "Phase 2 / MOA — labels Distribution Cable v1 (label poles first)"},
    {"id": "ft3", "kind": "algo", "group": "ft",
     "label": "FT3 · Label Secondary Cable",   "icon": "/mActionAddLineString.svg",
     "algorithm": "fibernetwork:ft_label_secondary_cable",
     "tooltip": "⚠ hardcodes 24F — do NOT run on Phase 2 / MOA"},
    {"id": "ft4", "kind": "algo", "group": "ft",
     "label": "FT4 · Label Enclosure",         "icon": "/mActionAddOgrLayer.svg",
     "algorithm": "fibernetwork:ft_label_enclosure",
     "tooltip": "Phase 2 / MOA — labels Enclosure v1 (AGG / DIS domes)"},
    {"id": "ft4b","kind": "algo", "group": "ft",
     "label": "FT4b · Label STS Splitters",    "icon": "/mActionCapturePoint.svg",
     "algorithm": "fibernetwork:ft_label_sts_splitters",
     "tooltip": "Phase 2 / MOA — labels the STS splitter points"},
    {"id": "ft5", "kind": "algo", "group": "ft",
     "label": "FT5 · Generate PON Zones",      "icon": "/mActionAddPolygon.svg",
     "algorithm": "fibernetwork:ft_generate_pon_zones",
     "tooltip": "Phase 2 / MOA — builds PON zones (16 PONs = 1 zone)"},
    {"id": "ft6", "kind": "algo", "group": "ft",
     "label": "FT6 · Apply PON Order",         "icon": "/mActionArrowDown.svg",
     "algorithm": "fibernetwork:ft_apply_pon_order",
     "tooltip": "Phase 2 / MOA — applies feeder-path PON order (needs pon_feeder_order.txt)"},
    {"id": "ft7", "kind": "algo", "group": "ft",
     "label": "FT7 · Pole Thickness",          "icon": "/mIconRulers.svg",
     "algorithm": "fibernetwork:ft_pole_thickness",
     "tooltip": "Phase 2 / MOA — classifies pole thickness (needs C:/Temp/roads.json)"},
    {"id": "ft_sep",    "kind": "separator", "group": "ft"},
    {"id": "ft_all",    "kind": "macro", "group": "ft",
     "label": "⚡ Run All (FT 1→7)", "icon": "/mActionStart.svg",
     "callback": "_run_ft_pipeline",
     "tooltip": "Runs FT1 → FT2 → FT3 → FT4 → FT5 → FT6 → FT7 sequentially."},

    # ── Compliance (inside Fibertime ▾) ──────────────────────────────────────
    {"id": "ft_sep_compliance", "kind": "separator", "group": "ft"},
    {"id": "ft_hdr_compliance", "kind": "header", "group": "ft", "label": "Compliance"},
    {"id": "audit_hld",  "kind": "script", "group": "ft",
     "label": "HLD Audit",           "icon": "/mIconSuccess.svg",
     "script": r"C:/Users/jjsch/OneDrive - blitzfibre.com/Documents/Workspace/QGIS/audit_all_ph2.py",
     "tooltip": "Full Phase 2 HLD compliance audit — results in Python Console"},
    {"id": "span_check", "kind": "callback", "group": "ft",
     "label": "Check Spans",           "icon": "/mActionMeasure.svg",
     "callback": "_run_span_check",
     "tooltip": "Pole-to-pole span check. Drop>55m, Dist/Sec/Primary>70m.\nCreates a 'Span Violations' memory layer with each bad span as a red line."},
    {"id": "update_layers","kind": "callback", "group": "ft",
     "label": "Refresh Attributes",    "icon": "/mActionRefresh.svg",
     "callback": "_run_update_layers",
     "tooltip": "Re-run attribute refresh on Drop / Spare Drop / ONT / STS after edits"},

    # ── HeroTel ▾ : VN 1 + HT 1-6 (replaced 6 placeholder steps, JJ 2026-09-23).
    #    HT 1/3/4/5 still raise "not yet implemented" (pending the HeroTel TSD spec),
    #    so they show greyed out until they are built - never a button that errors.
    {"id": "ht_hdr_setup", "kind": "header", "group": "herotel", "label": "Setup"},
    {"id": "ht_vn1", "kind": "algo", "group": "herotel",
     "label": "VN 1 · Build HeroTel Layers", "icon": "/mActionAddOgrLayer.svg",
     "algorithm": "fibernetwork:vn_01_build_herotel_layers",
     "tooltip": "Build the 16 standard HeroTel layers, with their headings and styles, into a new GeoPackage"},
    {"id": "ht_hdr_design", "kind": "header", "group": "herotel", "label": "Design"},
    {"id": "ht1", "kind": "algo", "group": "herotel",
     "label": "HT 1 · ONT Placement (not built yet)", "enabled": False,        "icon": "/mActionCapturePoint.svg",
     "algorithm": "fibernetwork:ht_01_ont_placement",
     "tooltip": "Place ONTs from Overture buildings + RAMP"},
    {"id": "ht2", "kind": "algo", "group": "herotel",
     "label": "HT 2 · PON Clustering",       "icon": "/mActionAddPolygon.svg",
     "algorithm": "fibernetwork:ht_02_pon_clustering",
     "tooltip": "Cluster homes into PONs from the span layer"},
    {"id": "ht3", "kind": "algo", "group": "herotel",
     "label": "HT 3 · Splitter Placement (not built yet)", "enabled": False,   "icon": "/mActionCapturePoint.svg",
     "algorithm": "fibernetwork:ht_03_splitter_placement",
     "tooltip": "Place FTS + STS splitters"},
    {"id": "ht4", "kind": "algo", "group": "herotel",
     "label": "HT 4 · Drop Cable Routing (not built yet)", "enabled": False,   "icon": "/mActionAddLineString.svg",
     "algorithm": "fibernetwork:ht_04_drop_routing",
     "tooltip": "Route drop cables ONT → STS"},
    {"id": "ht5", "kind": "algo", "group": "herotel",
     "label": "HT 5 · Feeder Cable Routing (not built yet)", "enabled": False, "icon": "/mActionAddLineString.svg",
     "algorithm": "fibernetwork:ht_05_feeder_routing",
     "tooltip": "Route feeder cables STS → FTS → POP"},
    {"id": "ht_hdr_check", "kind": "header", "group": "herotel", "label": "Check"},
    {"id": "ht6", "kind": "algo", "group": "herotel",
     "label": "HT 6 · Schema Check",         "icon": "/mIconSuccess.svg",
     "algorithm": "fibernetwork:ht_06_schema_check",
     "tooltip": "Read-only check of the project against the HeroTel schema"},

    # ── Automations menu removed — duplicated by fibretime_tools toolbar ──

    # ── Interactive tools (inline) ────────────────────────────────────────────
    {"id": "enc_editor", "kind": "callback", "group": "tools", "client": "both",
     "label": "Enclosures",           "icon": "/mActionAddOgrLayer.svg",
     "callback": "_open_enc_editor",
     "tooltip": (
        "ENCLOSURE EDITOR — inspect & reclassify enclosures on the canvas.\n"
        "─────────────────────────────\n"
        "Opens a floating panel. Use the Select Features tool (S key) to pick\n"
        "enclosures on the map, then click a type button to reclassify:\n"
        "  🟠 Distribution Joint (ODCFD0 / 24F)  — standard distribution dome\n"
        "  🟣 Spur Route (M16 Microloop / 48F)   — diverging-route dome\n"
        "  🔵 Feeder Splice UMJ / 72F            — secondary feeder joint\n"
        "  🟢 Feeder Splice CMJ / 144F           — primary feeder joint\n"
        "─────────────────────────────\n"
        "Canvas overlays:\n"
        "  🟠 orange diamond = Distribution (ODCFD0/24F)\n"
        "  🟣 purple square  = Spur Route (M16 Microloop/48F)\n"
        "  🔵 cyan circle    = Feeder UMJ/72F\n"
        "  🟢 green circle   = Feeder CMJ/144F")
     },
    {"id": "pole_editor","kind": "callback", "group": "tools", "client": "both",
     "label": "📍 Pole Editor",       "icon": "/mActionCapturePoint.svg",
     "callback": "_open_pole_editor",
     "tooltip": (
        "POLE EDITOR — inspect & correct individual poles on the canvas.\n"
        "─────────────────────────────\n"
        "Opens a floating panel. Click any pole on the map, then use buttons to:\n"
        "  🟢 Mark Road Crossing      — tag this pole as an RC (affects FT7 thickness)\n"
        "  🔴 Not Road Crossing       — revoke RC tag (auto-downgrade to 120-140mm)\n"
        "  🔵 140-160mm (Thick)        — force dim2=140-160mm (anchor/strain)\n"
        "  ⚪  120-140mm (Thin)        — force dim2=120-140mm (intermediate)\n"
        "─────────────────────────────\n"
        "Canvas legend (dots on poles):\n"
        "  🔵 Cyan   = 140-160mm thick pole\n"
        "  🟢 Green  = road crossing pole\n"
        "  🔴 Red    = confirmed NOT road crossing\n"
        "  🟡 Yellow = FTS splitter pole\n"
        "Tip: Shift+click to multi-select. Edits auto-refresh when the panel closes.")
     },
    {"id": "route_viewer","kind": "callback", "group": "tools", "client": "both",
     "label": "🔦 Splice Viewer",      "icon": "/mActionTracing.svg",
     "callback": "_open_route_viewer",
     "tooltip": (
        "SPLICE ROUTE VIEWER — cross-check the Excel splice plan on the canvas.\n"
        "─────────────────────────────\n"
        "Opens a floating panel. Pick an OLT port (= one PON sheet in the Excel)\n"
        "and the panel lights up that PON's entire fibre route on the map,\n"
        "colour-coded by hop, zooms to it, and selects the features (so the\n"
        "attribute table shows exactly what's lit).\n"
        "  OLT port → feeder → AGG dome → FTS → distribution → DIS dome →\n"
        "  STS → drop → ONT\n"
        "Narrow to a single STS leg to trace one branch. Prev/Next steps PONs.\n"
        "─────────────────────────────\n"
        "Canvas colours:\n"
        "  🟥 feeder cable   🟧 distribution cable   🟨 drop cables\n"
        "  🔷 AGG dome (FTS/fusion)   🔵 DIS dome (STS/connectorised)\n"
        "  🟪 FTS 1:16   🟩 STS 1:8   ⚪ ONT / home\n"
        "Read-out lists every label so you can tick it against the sheet.")
     },
    {"id": "canvas",     "kind": "callback", "group": "tools", "client": "dev",
     "label": "📸 Canvas",             "icon": "/mActionSaveMapAsImage.svg",
     "callback": "_snap_canvas",
     "tooltip": (
        "CANVAS SNAPSHOT — save current map view to disk for Claude.\n"
        "─────────────────────────────\n"
        "Writes the visible canvas (current extent + layer state) to\n"
        "  C:/Temp/canvas.png\n"
        "Then copies it to the clipboard so Claude can paste-receive it.\n"
        "Use for visual verification after edits or to share a view.")
     },
    # Erven Generator moved into Vuma ▼ dropdown as step 01c — not a standalone toolbar button.
]

GROUPS = OrderedDict([
    ("quick",     {"title": None,              "kind": "inline", "client": "both"}),
    # One dropdown per client, always on the toolbar; the open project's client is lit,
    # the others dashed but still clickable (JJ, 2026-09-22/23, toolbar calls 1-3).
    ("ft",        {"title": "Fibertime ▾",     "kind": "menu",  "client": "ft",
                   "tooltip": (
                       "FIBERTIME\n"
                       "─────────────────────────\n"
                       "FT pipeline — FT1-FT7 in order, or ⚡ Run All.\n"
                       "  FT6 needs pon_feeder_order.txt, FT7 needs C:/Temp/roads.json.\n"
                       "  ⚠ FT3 hardcodes 24F: never run it on Phase 2 / MOA.\n"
                       "Compliance — HLD Audit · Check Spans · Refresh Attributes.\n"
                       "Automation — the project steps 1-10.")}),
    ("labelling", {"title": "Vuma ▾",          "kind": "menu",  "client": "vuma",
                   "tooltip": (
                       "VUMA\n"
                       "─────────────────────────\n"
                       "Label layers — legacy PRAK / MALM projects, one algorithm per\n"
                       "  layer (aggregation polygons, blocks, poles, dome + feeder joints,\n"
                       "  demand points, feeder + distribution cables).\n"
                       "Automation — the project steps 1-10.\n"
                       "Not for Phase 2 MOA.")}),
    ("herotel",   {"title": "HeroTel ▾",       "kind": "menu",  "client": "herotel",
                   "tooltip": (
                       "HEROTEL\n"
                       "─────────────────────────\n"
                       "VN 1 — standardise the project's layers.\n"
                       "HT 1-5 — ONTs, PONs, splitters, drops, feeders.\n"
                       "HT 6 — read-only schema check.")}),
    ("tools",     {"title": None,              "kind": "inline", "client": "both"}),
])


# ══════════════════════════════════════════════════════════════════════════════
# Stylesheet — applied once to the toolbar; children inherit.
# ══════════════════════════════════════════════════════════════════════════════
# Mirror eye QSS — three states (watching / idle / off)
_MIRROR_EYE_BASE = (
    "QPushButton#FNAMirrorEye {{"
    " background:{bg}; color:{fg};"
    " border:1px solid {border}; border-radius:6px;"
    " padding:4px 10px; margin:0 4px;"
    " font-family:'Segoe UI'; font-size:11px; font-weight:600;"
    " min-height:22px; }}"
    "QPushButton#FNAMirrorEye:hover {{ border:1px solid #8067D8; }}"
)
_MIRROR_EYE_WATCHING_QSS = _MIRROR_EYE_BASE.format(
    bg='#15803D', fg='#FFFFFF', border='#22C55E')
_MIRROR_EYE_IDLE_QSS = _MIRROR_EYE_BASE.format(
    bg='#92400E', fg='#FFFFFF', border='#F59E0B')
_MIRROR_EYE_OFF_QSS = _MIRROR_EYE_BASE.format(
    bg='#3A3D5C', fg='#A0A4BC', border='#5A5F88')

# Client-branded button QSS — Vuma = orange, Fibretime = teal
# Applied to group dropdown buttons and absorbed fibretime_tools buttons.
_VUMA_BTN_QSS = (
    'QToolButton { background: #FF0090; color: white; border: none;'
    ' border-radius: 4px; padding: 3px 10px;'
    ' font-family: "Segoe UI"; font-size: 11px; font-weight: 900; }'
    'QToolButton::menu-indicator { image: none; }'
    'QToolButton:hover { background: #FF33A8; }'
)
_FT_BTN_QSS = (
    'QToolButton { background: qlineargradient(x1:0,y1:0,x2:1,y2:0,'
    ' stop:0 #2ABFCC, stop:0.28 #2ABFCC,'
    ' stop:0.281 #FFE619, stop:0.719 #FFE619,'
    ' stop:0.72 #2ABFCC, stop:1 #2ABFCC);'
    ' color: #1A3040; border: none;'
    ' border-radius: 4px; padding: 3px 10px;'
    ' font-family: "Segoe UI"; font-size: 11px; font-weight: 800; }'
    'QToolButton::menu-indicator { image: none; }'
    'QToolButton:hover { background: #FFE619; color: #1A3040; }'
)
_HEROTEL_BTN_QSS = (
    'QToolButton { background: #FF4500; color: white; border: none;'
    ' border-radius: 4px; padding: 3px 10px;'
    ' font-family: "Segoe UI"; font-size: 11px; font-weight: 700; }'
    'QToolButton::menu-indicator { image: none; }'
    'QToolButton:hover { background: #FF6622; }'
)


def _ghost_btn_qss(colour):
    """A client dropdown that is NOT the open project's client: same place, same
    menu, drawn as a dashed outline in the client's colour so the lit one stands out."""
    return (
        'QToolButton { background: transparent; color: %s; border: 1px dashed %s;'
        ' border-radius: 4px; padding: 2px 9px;'
        ' font-family: "Segoe UI"; font-size: 11px; font-weight: 700; }'
        'QToolButton::menu-indicator { image: none; }'
        'QToolButton:hover { border-style: solid; }' % (colour, colour))


# client -> (lit QSS, dashed QSS) for the always-visible client dropdowns
_CLIENT_BTN_QSS = {
    'ft': (_FT_BTN_QSS, _ghost_btn_qss('#2ABFCC')),
    'vuma': (_VUMA_BTN_QSS, _ghost_btn_qss('#FF0090')),
    'herotel': (_HEROTEL_BTN_QSS, _ghost_btn_qss('#FF6A2A')),
}


_TOOLBAR_QSS_TEMPLATE = """
/* === FiberNetworkAutomation modern dark — scoped to plugin toolbar/menus ===
 * Material-3-derived tokens; does NOT touch QGIS chrome.
 * 2026-04-28 redesign per research_toolbar_ux_redesign_2026-04-28.md
 */
QToolBar#FiberNetworkAutomationToolbar {{
    background: {tb_bg}; border: 0;
    border-bottom: 1px solid {tb_border};
    padding: 4px 6px; spacing: 4px;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton {{
    background: {btn_bg}; color: {btn_text};
    border: 1px solid transparent; border-radius: 6px;
    padding: 6px 10px; margin: 0 2px;
    font-family: 'Segoe UI'; font-size: 12px; font-weight: 500;
    min-height: 22px;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton:hover {{
    background: {btn_hover}; border: 1px solid {tb_border};
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton:pressed {{
    background: {btn_hover};
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton:checked {{
    background: {checked_bg}; color: {checked_text}; border: 1px solid {checked_bg};
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton:disabled {{
    color: {disabled_text}; background: {tb_bg};
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton::menu-indicator {{
    subcontrol-position: right center; right: 4px;
    image: none; width: 8px;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton[popupMode="1"] {{
    padding-right: 16px;
}}

/* Brand tile — gradient + bridge state via dynamic property */
QToolBar#FiberNetworkAutomationToolbar QToolButton#FNABrandTile {{
    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                                stop:0 #6E56CF, stop:1 #8067D8);
    color: #FFFFFF; font-weight: 700;
    border: 1px solid #5A45B0; border-radius: 6px;
    padding: 6px 12px;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton#FNABrandTile:hover {{
    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                                stop:0 #8067D8, stop:1 #9A82E6);
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton#FNABrandTile[bridge="offline"] {{
    background: #DC2626; border-color: #991B1B;
}}
QToolBar#FiberNetworkAutomationToolbar QToolButton#FNABrandTile[bridge="online"] {{
    background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                                stop:0 #16A34A, stop:1 #22C55E);
    border-color: #15803D;
}}

QToolBar#FiberNetworkAutomationToolbar::separator {{
    background: {tb_border}; width: 1px; margin: 6px 6px;
}}

/* Dropdown menus opened from toolbar */
QToolBar#FiberNetworkAutomationToolbar QMenu {{
    background: {btn_bg}; color: {btn_text};
    border: 1px solid {tb_border}; border-radius: 6px;
    padding: 4px;
}}
QToolBar#FiberNetworkAutomationToolbar QMenu::item {{
    padding: 6px 14px 6px 28px; border-radius: 4px;
}}
QToolBar#FiberNetworkAutomationToolbar QMenu::item:selected {{
    background: {btn_hover};
}}
QToolBar#FiberNetworkAutomationToolbar QMenu::separator {{
    height: 1px; background: {tb_border}; margin: 4px 6px;
}}
"""


# ── Velocity-Nexus-theme → toolbar colour mapping (ticket: themes must switch
# the toolbar too, not just the panel). Reads the SAME THEMES dict the home panel
# uses, so the toolbar always matches the active Nexus theme.
def _toolbar_qss_for_theme(theme_name=None):
    """Build the toolbar QSS from the active Velocity Nexus theme palette so the
    toolbar bar matches the panel and switches with it. Falls back to the previous
    dark palette if the theme pack can't be imported."""
    _fallback = {
        "tb_bg": "#05070C", "tb_border": "#1B2940", "btn_bg": "#0D1320",
        "btn_text": "#C9DDF2", "btn_hover": "#131D2E", "checked_bg": "#1AE5FF",
        "checked_text": "#04070D", "disabled_text": "#53678A",
    }
    try:
        try:
            from .velocity_home_panel import THEMES as _TH
        except Exception:
            from velocity_home_panel import THEMES as _TH
        if theme_name is None:
            from qgis.core import QgsSettings
            theme_name = QgsSettings().value("VelocityFibre/panel_theme") or "velocity"
        c = _TH.get(theme_name) or _TH.get("velocity") or {}
        pal = {
            "tb_bg":         c.get("bg", _fallback["tb_bg"]),
            "tb_border":     c.get("step_border", _fallback["tb_border"]),
            "btn_bg":        c.get("tool_bg", c.get("step_bg", _fallback["btn_bg"])),
            "btn_text":      c.get("tool_text", c.get("title", _fallback["btn_text"])),
            "btn_hover":     c.get("tool_hover", c.get("step_hover", _fallback["btn_hover"])),
            "checked_bg":    c.get("step_hi", _fallback["checked_bg"]),
            "checked_text":  c.get("badge_text", _fallback["checked_text"]),
            "disabled_text": c.get("sub", c.get("chev", _fallback["disabled_text"])),
        }
    except Exception:
        pal = _fallback
    return _TOOLBAR_QSS_TEMPLATE.format(**pal)


# ══════════════════════════════════════════════════════════════════════════════
# Plugin
# ══════════════════════════════════════════════════════════════════════════════

class FiberNetworkPlugin:
    """QGIS Plugin Implementation for Fiber Network Automation"""

    def __init__(self, iface):
        self.iface = iface
        self.provider = None
        self._toolbar = None
        self._dock_chrome_watcher = None
        self._ui_heal_timers = []
        self._label_my_network_dock = None
        self._tools_dock = None
        self._tools_dockarea = None
        # Pre-v2.5.322 hot reloads leaked one main-window event filter per
        # restart. Remove them before this instance creates any dock.
        try:
            from .nexus_dock import uninstall_dock_chrome_watcher
            uninstall_dock_chrome_watcher(self.iface.mainWindow())
        except Exception:
            _swallowed_note()
        # A previous plugin instance may have been torn down after Qt queued its
        # deletions. Retire those named docks before this instance can create a
        # replacement with the same objectName.
        self._retire_stale_owned_docks()
        # Tools mark themselves busy here (via self._busy(...)) so a plugin update
        # DEFERS instead of interrupting long work. A set of active-operation labels.
        self._busy_ops = set()
        self._pole_editor_panel = None
        self._pole_editor_dock = None     # _PanelDock hosting the pole editor
        self._home_panel = None
        self._np_dock = None
        self._enc_editor_panel  = None
        self._enc_editor_dock = None      # _PanelDock hosting the enclosure editor
        self._route_viewer_panel = None
        self._route_viewer_dock = None    # _PanelDock hosting the route viewer
        self._actions = {}         # id -> QAction for state management
        self._group_btns = {}      # group_id -> QToolButton (menu groups only)
        self._group_acts = {}      # group_id -> QWidgetAction from tb.addWidget(btn)
        self._brand_label = None   # VF badge QLabel
        self._brand_status = None  # "Bridge Online/Offline" status QLabel
        self._bridge_timer = None  # QTimer polling bridge_port.txt
        self._bridge_fail_streak = 0     # consecutive failed polls (debounce)
        self._bridge_last_shown_alive = None  # last rendered state
        self._automation_sep = None      # QAction separator before client dropdown
        self._automation_widget = None   # QToolButton (Vuma/FT steps dropdown)
        self._automation_action = None   # toolbar action wrapping the button
        self._absorbed_ft_widgets = []        # QToolButtons absorbed from fibretime_tools toolbar
        self._absorbed_ft_widget_acts = []   # QWidgetActions returned by addWidget() — use for visibility
        self._absorbed_ft_actions = []       # plain QActions absorbed from fibretime_tools toolbar

    def _retire_stale_owned_docks(self):
        """Remove plugin-owned docks left behind by an interrupted hot reload.

        NOTE: this path does NOT go through _dispose_owned_dock — it inlines
        its own hide/setParent(None)/deleteLater — and it never calls close(),
        so closeEvent does not fire here either. It is therefore an INDEPENDENT
        teardown path and needs its own explicit call below; covering the
        disposal seam alone would leave this one uncovered.
        """
        try:
            self._close_pole_selection_all_paths()
        except Exception:
            _swallowed_note()
        try:
            from qgis.PyQt import sip
            from qgis.PyQt.QtWidgets import QDockWidget
            main_window = self.iface.mainWindow()
            owned_names = {
                "VFLabelMyNetworkDock",
                "VelocityNexusToolsDock",
            }
            for dock in main_window.findChildren(QDockWidget):
                if sip.isdeleted(dock) or dock.objectName() not in owned_names:
                    continue
                old_name = dock.objectName()
                try:
                    dock.hide()
                    # deleteLater is deferred; renaming immediately guarantees the
                    # replacement never coexists with a duplicate objectName.
                    dock.setObjectName(
                        f"{old_name}__retired_{id(dock)}"
                    )
                    self.iface.removeDockWidget(dock)
                    dock.setParent(None)
                    dock.deleteLater()
                except (RuntimeError, AttributeError):
                    pass
        except Exception:
            _swallowed_note()
        self._clear_labeling_dock_singletons()

    @staticmethod
    def _clear_labeling_dock_singletons():
        """Forget module-level LMN wrappers from either supported import path."""
        import sys
        for module_name in (
            "FiberNetworkAutomation.fibre_automation.labeling_wizard",
            "fibre_automation.labeling_wizard",
        ):
            module = sys.modules.get(module_name)
            if module is None:
                continue
            try:
                module._forget_dock()
            except Exception:
                _swallowed_note()

    @staticmethod
    def _close_pole_selection_all_paths():
        """Drop any live pole-selection map tool + rubber band.

        Mirrors _clear_labeling_dock_singletons: labeling_wizard can be loaded
        under EITHER qualified name, and each load carries its OWN module-level
        _POLE_SWAP. Calling only one of them would leave the other's rubber
        band attached to the canvas with no live Python owner — the ticket #138
        dead-container crash class. Neither path calls dock.close(), so
        closeEvent never fires here; this is the only teardown that runs.
        """
        import sys
        torn = False
        for module_name in (
            "FiberNetworkAutomation.fibre_automation.labeling_wizard",
            "fibre_automation.labeling_wizard",
        ):
            module = sys.modules.get(module_name)
            if module is None:
                continue
            try:
                if module.close_pole_selection():
                    torn = True
            except Exception:
                _swallowed_note()
            # Sever the panel's QgsProject connections too. Different lifetime
            # from the map tool: that ends on untoggle, this only ends with the
            # dock -- and neither unload() nor the retirement path fires
            # closeEvent, so this is the only place it can happen.
            try:
                if module.detach_pole_panels():
                    torn = True
            except Exception:
                _swallowed_note()
        return torn

    def _forget_owned_dock(self, attr, expected):
        """Clear an instance reference only if it still names this exact dock."""
        if getattr(self, attr, None) is expected:
            setattr(self, attr, None)

    def _dispose_owned_dock(self, dock):
        """Synchronously detach ownership, then queue the C++ widget for deletion."""
        if dock is None:
            return
        # This path NEVER calls dock.close(), so closeEvent does not fire and
        # the panel cannot tear itself down. Drop any pole-selection map tool
        # before the widget is freed — covers unload() AND the stale-dock
        # retirement path in one place. Idempotent, so double-calling is safe.
        try:
            self._close_pole_selection_all_paths()
        except Exception:
            _swallowed_note()
        try:
            from qgis.PyQt import sip
            if sip.isdeleted(dock):
                return
        except Exception:
            _swallowed_note()
        try:
            dock.hide()
            old_name = dock.objectName() or dock.__class__.__name__
            dock.setObjectName(f"{old_name}__retired_{id(dock)}")
            self.iface.removeDockWidget(dock)
            dock.setParent(None)
            dock.deleteLater()
        except (RuntimeError, AttributeError):
            pass

    def _busy(self, label):
        """Context manager a tool wraps around a long operation so a plugin update
        DEFERS while it runs and applies the moment it finishes — never interrupting
        the work. Always clears on exit, even if the operation raises:

            with self._busy("Exporting deliverable"):
                ...long work...
        """
        from contextlib import contextmanager

        @contextmanager
        def _cm():
            key = str(label)
            self._busy_ops.add(key)
            try:
                yield
            finally:
                self._busy_ops.discard(key)
        return _cm()

    # ── Setup ────────────────────────────────────────────────────────────────
    def initProcessing(self):
        reg = QgsApplication.processingRegistry()
        self.provider = FiberNetworkProvider()
        if not reg.addProvider(self.provider):
            # addProvider returned False → zombie "fibernetwork" key in the C++ map
            # (typically from a double-start or Plugin Reloader reload).
            # QGIS already deleted self.provider's C++ object; create a fresh probe
            # so removeProvider can look up and evict the zombie by ID.
            try:
                _probe = FiberNetworkProvider()
                reg.removeProvider(_probe)  # removes zombie by ID, NOT _probe itself
            except Exception:
                _swallowed_note()
            self.provider = FiberNetworkProvider()
            reg.addProvider(self.provider)

    def _erven_studio_dock_path(self):
        import os
        plugin_dir = os.path.dirname(__file__)
        cands = [
            os.path.join(plugin_dir, 'erven_studio', 'qgis_dock.py'),                   # bundled inside plugin
            os.path.join(os.path.dirname(plugin_dir), 'erven_studio', 'qgis_dock.py'),  # sibling
            r'C:/Users/jjsch/OneDrive - blitzfibre.com/Documents/Workspace/QGIS/erven_studio/qgis_dock.py',
        ]
        return next((p for p in cands if os.path.exists(p)), None)

    def _erven_studio_module(self):
        path = self._erven_studio_dock_path()
        if not path:
            self.iface.messageBar().pushWarning('Erven Studio', 'qgis_dock.py not found')
            return None
        import importlib.util
        spec = importlib.util.spec_from_file_location('erven_qgis_dock', path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod

    def _open_erven_studio(self):
        """Load erven_studio/qgis_dock.py and show the Erven Studio dock."""
        mod = self._erven_studio_module()
        if mod:
            mod.ErvenStudio.install()

    def _run_erven_now(self):
        """One-click: detect buildings → cadastral erven → demand points on the live AOI."""
        mod = self._erven_studio_module()
        if mod:
            mod.ErvenStudio.run_now()

    def _detect_buildings_now(self):
        """One-click building detection only (Google Open Buildings, no server)."""
        mod = self._erven_studio_module()
        if mod:
            mod.ErvenStudio.detect_now()

    def _install_ai_components(self):
        """One-time install of torch/sam2/geopandas etc. on plain QGIS so
        Detect Buildings works on a teammate's machine with zero setup."""
        try:
            from .fibre_automation.sam_detect.installer import get_installer
        except ImportError:
            from fibre_automation.sam_detect.installer import get_installer
        get_installer(self.iface).run()

    def _detect_buildings_sam(self):
        """Detect Buildings with local AI (SAM2) — works for ANY project AOI.

        Footprint boxes (GOB/Overture or an existing layer) -> SAM2 roof
        masks -> one house per erf (when a cadastre exists) -> regularized,
        shape-classified polygons. 100% local, no API keys/subscriptions.
        Degrades to the raw open-data footprints when the AI deps are absent.
        """
        runner = getattr(self, '_sam_detect_runner', None)
        if runner is None:
            try:
                from .fibre_automation.sam_detect.runner import SamDetectRunner
            except ImportError:
                from fibre_automation.sam_detect.runner import SamDetectRunner
            runner = SamDetectRunner(self.iface,
                                     fallback=self._detect_buildings_now)
            self._sam_detect_runner = runner
        runner.run()

    def _install_erven_studio_button(self):
        """Add an 'Erven Studio' toolbar button that opens the detect+tune dock."""
        from qgis.PyQt.QtGui import QAction
        if self._erven_studio_dock_path() is None:
            print('[FiberNet] Erven Studio: qgis_dock.py not found — button skipped')
            return
        act = QAction('Erven Studio', self.iface.mainWindow())
        act.setToolTip('Erven Studio — detect buildings + tune cadastral erven (sliders + Run)')
        act.triggered.connect(self._open_erven_studio)
        self._toolbar.addAction(act)
        self._actions['erven_studio'] = act
        self._erven_studio_action = act
        print('[FiberNet] Erven Studio button installed ✓')

    def _open_erven_detection(self):
        """Open the Erven Detection dock (SAM 2 + Grounding DINO via local MCP server).
        Lazy-loads erven_detection/ — works fully with the MCP server offline (the panel
        shows an offline notice and disables Run)."""
        from qgis.PyQt.QtCore import Qt
        panel = getattr(self, '_erven_detection_panel', None)
        if panel is not None:
            try:
                panel.show(); panel.raise_()
                return
            except RuntimeError:
                self._erven_detection_panel = None  # C++ object deleted — recreate
        try:
            from .erven_detection.erven_panel import ErvenPanel
        except ImportError:
            from erven_detection.erven_panel import ErvenPanel
        panel = ErvenPanel(self.iface, self.iface.mainWindow())
        _du = self._dock_util()
        if _du is not None:
            _du.dock_fully(self.iface, panel, width=440)
        else:
            self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, panel)
        panel.show(); panel.raise_()
        self._erven_detection_panel = panel

    def _run_splice_plan(self):
        """Step 5 — generate the splice plan (Excel workbook + A4 field cards) and open it.

        Runs the bundled fibre_automation/splice generators. They read the splice data
        JSON shipped alongside them and write to splice/output/. Falls back gracefully
        with a clear message if the Python deps (openpyxl/reportlab/networkx) are missing.
        """
        import os, subprocess
        from qgis.PyQt.QtWidgets import QApplication
        plugin_dir = os.path.dirname(__file__)
        cands = [
            os.path.join(plugin_dir, 'fibre_automation', 'splice'),                   # ZIP install (team)
            os.path.join(os.path.dirname(plugin_dir), 'fibre_automation', 'splice'),  # plugins-dir sibling
            os.path.expanduser('~/OneDrive - blitzfibre.com/Documents/Workspace/QGIS/'
                               'fibre_automation/splice'),                            # dev workspace fallback
        ]
        splice = next((c for c in cands if os.path.exists(os.path.join(c, 'build_splice_v3.py'))), cands[0])
        gen = os.path.join(splice, 'build_splice_v3.py')
        cards = os.path.join(splice, 'build_field_cards.py')
        flow = os.path.join(splice, 'build_flow_diagrams.py')
        if not os.path.exists(gen):
            self.iface.messageBar().pushWarning('Splice Plan', 'Splice generator not found.')
            return
        # Prefer a Python that has the deps (dev venv), else QGIS's bundled
        # python.exe — NEVER sys.executable here: inside QGIS on Windows that
        # is qgis-bin.exe and would open new QGIS windows.
        try:
            from .fibre_automation.shared.vf_paths import python_exe
        except ImportError:
            from fibre_automation.shared.vf_paths import python_exe
        py = python_exe()
        # Outputs go to the project folder (portable), not a hardcoded dev path.
        env = dict(os.environ)
        try:
            from .fibre_automation.shared.vf_paths import project_output_dir
            outdir = project_output_dir()
        except Exception:
            outdir = os.path.join(splice, 'output')
        os.makedirs(outdir, exist_ok=True)
        env['VF_SPLICE_OUT'] = outdir
        self.iface.messageBar().pushInfo('Splice Plan', 'Generating Excel + field cards + flow diagrams…')
        QApplication.processEvents()
        try:
            r1 = subprocess.run([py, gen], capture_output=True, text=True, timeout=300, cwd=splice, env=env)
            # Only run the downstream steps when the primary generator succeeded —
            # if r1 fails it produces no output files, so r2/r3 would only waste
            # ~600s of subprocess time failing too.
            if r1.returncode == 0:
                r2 = subprocess.run([py, cards], capture_output=True, text=True, timeout=300, cwd=splice, env=env)
                r3 = (subprocess.run([py, flow], capture_output=True, text=True, timeout=300, cwd=splice, env=env)
                      if os.path.exists(flow) else None)
            else:
                r2 = None
                r3 = None
        except Exception as e:
            self.iface.messageBar().pushWarning('Splice Plan', str(e)[:200])
            return
        if r1.returncode == 0:
            extra = '' if r2.returncode == 0 else ' (field cards step needs reportlab/qrcode)'
            if r3 is not None and r3.returncode != 0:
                extra += ' (flow diagrams step needs matplotlib)'
            self.iface.messageBar().pushSuccess('Splice Plan', f'Done → {outdir}{extra}')
            try:
                os.startfile(outdir)  # noqa: open the output folder for the user
            except Exception:
                _swallowed_note()
        else:
            msg = (r1.stderr or r1.stdout or 'failed').strip()[-220:]
            self.iface.messageBar().pushWarning(
                'Splice Plan', f'Could not generate: {msg}  (needs openpyxl/networkx)')

    def _open_network_planner(self):
        """Open the bundled Velocity Network Planner (FTTHPlanTool) dock."""
        from qgis.PyQt.QtCore import Qt
        try:
            try:
                from .network_planner.dock_widget import FTTHPlanToolDockWidget
            except Exception:
                from network_planner.dock_widget import FTTHPlanToolDockWidget
            try:
                if self._np_dock is not None:
                    self._np_dock.show(); self._np_dock.raise_(); return
            except RuntimeError:
                self._np_dock = None  # underlying C++ dock was deleted
            self._np_dock = FTTHPlanToolDockWidget(self.iface)
            _du = self._dock_util()
            if _du is not None:
                _du.dock_fully(self.iface, self._np_dock, width=460)
            else:
                self.iface.addDockWidget(
                    Qt.DockWidgetArea.RightDockWidgetArea, self._np_dock)
            # Tab it together with the Velocity Nexus Home panel so they share the
            # same area as tabs — opening the planner doesn't force Home to close.
            try:
                if self._home_panel is not None:
                    self.iface.mainWindow().tabifyDockWidget(self._home_panel, self._np_dock)
            except (RuntimeError, AttributeError):
                pass
            self._np_dock.show(); self._np_dock.raise_()
        except Exception as e:
            self.iface.messageBar().pushWarning(
                'Network Planner', f'Could not open: {str(e)[:200]}')

    def _open_labeling_wizard(self):
        """Open Label My Network — the recipe-dock edition (fibre_automation),
        the single source of truth: walk-order numbering, Find/Replace, per-row
        review, collision checks and the BETA relabel guard all live here."""
        try:
            try:
                from .fibre_automation.labeling_wizard import (
                    open_labeling_wizard)
            except Exception:
                from fibre_automation.labeling_wizard import (
                    open_labeling_wizard)
            self._label_my_network_dock = open_labeling_wizard(self.iface)
            dock = self._label_my_network_dock
            try:
                dock.destroyed.connect(
                    lambda *_args, d=dock: self._forget_owned_dock(
                        "_label_my_network_dock", d
                    )
                )
            except Exception:
                _swallowed_note()
            return dock
        except Exception as e:
            self.iface.messageBar().pushWarning(
                'Label My Network', f'Could not open: {str(e)[:200]}')

    def _apply_toolbar_theme(self, theme_name=None):
        """Re-colour the plugin toolbar to match the active Velocity Nexus theme.
        Called on startup and whenever the user switches theme in the home panel."""
        try:
            if getattr(self, '_toolbar', None) is not None:
                self._toolbar.setStyleSheet(_toolbar_qss_for_theme(theme_name or None))
        except Exception:
            _swallowed_note()

    def _install_home_panel(self):
        """Branded Velocity Nexus home dock — fronts the main tools in a friendly panel."""
        import os
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtGui import QAction
        try:
            from .velocity_home_panel import VelocityHomePanel
        except Exception:
            from velocity_home_panel import VelocityHomePanel

        def act(_id):
            a = self._actions.get(_id)
            if a:
                return lambda: a.trigger()
            return lambda: self.iface.messageBar().pushInfo(
                'Velocity Nexus', f'"{_id}" is not available in this mode.')

        def _planner_version():
            import re
            try:
                mp = os.path.join(os.path.dirname(__file__),
                                  'network_planner', 'metadata.txt')
                with open(mp, encoding='utf-8') as f:
                    m = re.search(r'^version=(\S+)', f.read(), flags=re.M)
                return f'V{m.group(1)}' if m else ''
            except Exception:
                return ''

        _np_ver = _planner_version()
        steps = [
            ('Detect Buildings', 'Local AI (SAM2) — shape-classified, any AOI', self._detect_buildings_sam),
            ('Generate Erven',   'Cadastral erven + demand (no server)', self._run_erven_now),
            ('Network Planner',  (f'PON design pipeline — {_np_ver}' if _np_ver
                                  else 'PON design pipeline'),
             self._open_network_planner),
            ('Label My Network', 'Auto-label every layer by client recipe — Fibertime/Vuma/HeroTel (BETA)',
             self._open_labeling_wizard),
            ('Check & Audit',    'HLD compliance + span check',       act('audit_hld')),
            ('Splice Plan',      'Excel workbook + A4 field cards',   self._run_splice_plan),
            ('HLD Atlas PDF',    'Editable PDF book — overview + one page per unit (BETA)',
             self._generate_hld_pdf),
        ]
        # Automations & tools — each wired to a REAL, proven plugin tool, with a
        # hover description. (label, callback, tooltip). The panel's _safe()
        # wrapper catches any error so a click can never break the UI.
        # Manual Planning toolkit (was a ⚙ Menu submenu) → a collapsible panel group.
        _mp_tools_panel = []
        _mpt_p = None
        try:
            try:
                from .manual_planning import get_tools as _mp_get_p, MENU_SPEC as _MP_SPEC
            except ImportError:
                from manual_planning import get_tools as _mp_get_p, MENU_SPEC as _MP_SPEC
            _mpt_p = _mp_get_p(self.iface)
            for _e in _MP_SPEC:
                if not _e:
                    continue
                _lbl, _attr, _tip = _e
                if hasattr(_mpt_p, _attr):
                    # short button label (drop the parenthetical detail → tooltip),
                    # so the 2-col grid stays even (ticket #93)
                    _short = _lbl.split(" (")[0].strip()
                    _mp_tools_panel.append((_short, getattr(_mpt_p, _attr),
                                            _tip or _lbl))
            if hasattr(_mpt_p, '_toggle_pon_recorder'):
                _mp_tools_panel.append(('🔴 Record PON Order', _mpt_p._toggle_pon_recorder,
                                        'Click PON polygons in feeder order → pon_feeder_order.txt'))
        except Exception as _mpe:
            print(f'[FiberNet] Manual Planning panel tools failed: {_mpe}')

        # Grouped into collapsible categories so the panel reads as clean
        # sections, not a wall of 20+ buttons. (category, [(label, cb, tip), ...])
        tools = [
            ("PON PLANNING", [
                ('🧬 Generate PONs from Span', self._run_pon_from_span,
                 'Group the demand points into PONs that follow the drawn fibre '
                 'route, then draw straight-edged PON boundaries 4 m apart. '
                 'Target 96 stands, never more than 120, numbered outward from '
                 'the DC. Just press Run — the layers are picked up for you.'),
            ]),
            ("QA & AUDIT", [
                ('🏅 Scorecard', self._run_acceptance_scorecard,
                 'Score the finished HLD against the spec → client-signable '
                 'ACCEPTED / CONDITIONAL / REJECTED certificate PDF.'),
                ('🔆 Power Budget', self._run_power_budget_check,
                 'Optical power-budget check (ITU-T G.984) — flags ONTs with tight '
                 'or failing optical margin before you build.'),
                ('📊 Capacity', self._run_capacity_report,
                 'Per-PON fill (80–102, max 128) + per-zone rollup; flags over/under.'),
                ('🔎 Anomalies', self._run_anomaly_scan,
                 'Orphaned poles + dangling cable ends → an "Anomalies" layer.'),
                ('🩺 Topology QA', self._run_topology_qa,
                 'Full integrity sweep: null geoms, dup DR/PON, zone-math, dangles, '
                 'over-length spans, ONTs outside AOI.'),
                ('📋 QA Report (HTML)', self._export_qa_report,
                 'Shareable PASS/REVIEW/FAIL HTML integrity report.'),
                ('🚦 FT Pre-Flight', self._run_preflight_check,
                 'Before FT6/FT7: verify pon_feeder_order.txt + roads.json + layers.'),
                ('📏 Span Inspector', self._open_span_inspector,
                 'Dial a max span (0–100 m) and every longer pole-to-pole run '
                 'lights up on the canvas — and clears itself the moment you fix '
                 'it. Read-only; never edits your data.'),
                ('🛡 Integrity Check', self._run_integrity_check,
                 'Fast structural self-check on the live project (<1s): off-map '
                 'blowout, null geoms, mixed CRS, empty key layers, span limits, '
                 'drop≈ONT → OK / REVIEW / FAIL. Run after any big edit or fix.'),
            ]),
            ("DELIVERABLES", [
                ('HeroTel BOQ', self._open_herotel_boq,
                 'Generate a scoped HeroTel BOQ with reviewed mappings, formulas and source tracing.'),
                # '📘 HLD PDF' button removed — superseded by the step-7 "HLD Atlas PDF"
                # (the editable atlas book). Only one HLD PDF path now.
                ('📄 Design Report', self._export_design_report,
                 'PDF map-book of the design.'),
                ('📋 Pole Schedule', self._run_pole_schedule,
                 'GPS pole schedule CSV (label, lat/lon, thickness, type).'),
                ('🌍 Export KMZ', self._export_kmz,
                 'Pick layers → KMZ for Google Earth / field phones (with attributes).'),
                ('📐 Export DXF', self._export_dxf,
                 'Pick layers → DXF CAD (metres) for contractors.'),
                ('🗄 Export GeoPackage', self._export_styled_gpkg,
                 'Pick layers → one pre-styled .gpkg (cleanest handoff).'),
                ('🌐 Export KML', self._export_kml,
                 'GeoPackage or project → client-spec KML (correct symbology + '
                 'every attribute) for Google Earth.'),
                ('📦 Export GeoParquet/OFDS', self._export_cloud_formats,
                 'Cloud / open-standard export (GeoParquet + OFDS).'),
            ]),
            ("DETECTION & EDITORS", [
                ('🏠 Detect Buildings', self._detect_buildings_sam,
                 'Local-AI (SAM2) building detection for the current AOI.'),
                ('🛰 Fetch Erven (CSG)', self._fetch_csg_erven,
                 'Download the REAL surveyed erven from the SA CSG cadastre.'),
                ('📍 Poles', act('pole_editor'),
                 'Road-Crossing Pole Editor — mark/unmark with live highlighting.'),
                ('🔌 Enclosures', act('enc_editor'), 'Open the Enclosures editor.'),
            ]),
            ("SYSTEM", [
                ('💾 Back up Project', self._backup_project,
                 'Zip every layer + the project file into a timestamped archive.'),
                ('💬 Hover Tips', self._toggle_feature_map_tips,
                 'Toggle map hover tips (label/length/status/PON) on any feature.'),
                ('🛡 Guardian Incidents', self._show_guardian_incidents,
                 'Mass geometry losses the Guardian caught + auto-restored (local).'),
                ('🩺 System Health', self._show_health_panel,
                 'Green/Amber/Red status of the safety nets + offline outbox.'),
            ]),
        ]
        # Tools submenu → panel: Route Viewer + OES + the Manual Planning group.
        try:
            tools[2][1].append(('🛣 Route Viewer', self._open_route_viewer,
                                'Open the cable Route Viewer.'))
            tools[2][1].append(('🔍 Review Buildings', self._open_building_review,
                                'Review + correct detected buildings; every '
                                'decision trains the AI on your own corrections.'))
            if _mpt_p is not None and hasattr(_mpt_p, 'run_oes_export'):
                tools[1][1].append(('💾 Export OES CSV', _mpt_p.run_oes_export,
                                    'Export the OES CSV for the project.'))
        except Exception:
            _swallowed_note()
        if _mp_tools_panel:
            tools.insert(3, ("MANUAL PLANNING", _mp_tools_panel))
        # '⬇ Update' is a DEV-only git pull; teammates get the Workflow Guide.
        if self._is_dev_mode():
            tools[0][1].append(('🔬 Project Audit', self._open_project_audit,
                                'DEV only — deep cell-by-cell + geometry + GPON-standard '
                                'audit of the whole project → HTML report + a zoom-to-issue panel.'))
            tools[-1][1].append(('⬇ Update', act('update_git'),
                                 'DEV only — git-pull the latest plugin code.'))
        else:
            tools[-1][1].append(('🧭 Next steps', self._open_workflow_dock,
                                 'Step-by-step workflow guide — what to run next.'))
        # VN 1: PROJECT SETUP is appended last, so no existing group or button moves.
        tools.append(("PROJECT SETUP", [
            ('🧱 Build HeroTel Layers', self._open_build_herotel_layers,
             'Create a new GeoPackage with the 16 empty HeroTel standard layers '
             '(columns and styles ready), then add them to this project.'),
        ]))
        logo = os.path.join(os.path.dirname(__file__), 'logo.png')
        self._home_panel = VelocityHomePanel(
            self.iface, steps, tools, logo_path=logo, owner=self
        )
        # Keep the toolbar colours in sync with the Nexus theme the user picks.
        try:
            self._home_panel.themeChanged.connect(self._apply_toolbar_theme)
        except Exception:
            _swallowed_note()
        _du = self._dock_util()
        if _du is not None:
            _du.dock_fully(self.iface, self._home_panel, width=440)
        else:
            self.iface.addDockWidget(
                Qt.DockWidgetArea.RightDockWidgetArea, self._home_panel)
        # Chrome EVERY Velocity dock (bright ✕ / float title) — now AND whenever one
        # opens later (Label My Network, Network Planner, Team Monitor, Erven, Bridge…).
        # A persistent watcher so no dock class is ever missed again. Fail-open.
        try:
            from .nexus_dock import install_dock_chrome_watcher
            self._dock_chrome_watcher = install_dock_chrome_watcher(self.iface.mainWindow())
        except Exception:
            _swallowed_note()
        # auto-notify (panel banner + one-click update) when we publish.
        # The panel can be rebuilt (C++ object deleted) — stop any previous
        # checker first or its 30-min timer leaks and double-notifies.
        try:
            if getattr(self, '_update_checker', None) is not None:
                self._update_checker.stop()
                self._update_checker = None
            try:
                from .update_check import UpdateChecker
            except ImportError:
                from update_check import UpdateChecker
            self._update_checker = UpdateChecker(
                self.iface, lambda: self._home_panel,
                user_getter=lambda: (lambda pr: (getattr(pr, 'display_name', None)
                                                 or getattr(pr, 'username', None)) if pr else None)(
                    getattr(getattr(self, '_nexus', None), 'profile', None)))
            # Wire the panel's 🔄 Check-for-updates button to a manual check.
            try:
                self._home_panel.set_check_updates_callback(
                    self._update_checker.check_now_manual)
            except Exception:
                _swallowed_note()
        except Exception as e:
            print(f'[FiberNet] update checker not started: {e}')
        # Wire the inline activation card (shown only while locked)
        try:
            try:
                from . import activation as _act
            except ImportError:
                import activation as _act
            self._home_panel.set_locked(not _act.is_activated(), self._panel_activate)
        except Exception as e:
            print(f'[FiberNet] home lock wiring failed: {e}')
        # Wire the ⚙ gear button → pops the full Velocity Nexus menu
        try:
            self._home_panel.set_settings_callback(self._open_velo_menu)
        except Exception as e:
            print(f'[FiberNet] settings button wiring failed: {e}')
        # Wire the 🎫 red ticket button → log a bug / feature request to the office
        try:
            self._home_panel.set_ticket_callback(self._open_ticket_dialog)
        except Exception as e:
            print(f'[FiberNet] ticket button wiring failed: {e}')
        # Wire the 👤 profile chip → personalization card; live re-theming
        try:
            nx = getattr(self, '_nexus', None)
            if nx is not None and nx.signed_in_name():
                self._home_panel.set_profile(
                    nx.signed_in_name(), nx.avatar_color(),
                    nx.open_profile_card)
                # let the profile card re-skin the panel live
                nx.on_theme_changed = self._apply_panel_theme
        except Exception as e:
            print(f'[FiberNet] profile chip wiring failed: {e}')
        # NOTE: we intentionally do NOT prompt for a password at startup. Identity
        # was already proven once at registration (company team code + per-user
        # password). Sign-in / password-reset is available on demand from the
        # profile card (login.open_account_dialog); the anon fallback keeps
        # notifications working for everyone with no friction.
        # Bridge status is a dev-only Claude channel — teammates have no bridge,
        # so hide the line for them (it would otherwise sit at "checking…" or read
        # a stale bridge_port.txt). Only JJ's dev machine shows/polls it.
        if self._is_dev_mode():
            # Start at "checking" and let the 3 s poller supply the truth. This
            # used to read a shared file and assert set_bridge(True, port) —
            # claiming online without ever checking, from a port that may belong
            # to a different QGIS window, and never updating again.
            try:
                from .bridge_state import CONNECTING
                self._home_panel.set_bridge_state(CONNECTING, None)
            except Exception:
                _swallowed_note()
            # Click-to-switch is OFF unless the dev flag is explicitly set, so
            # the label stays inert for everyone else. Absent setting -> False.
            try:
                self._home_panel.set_bridge_click_handler(
                    self._open_bridge_switcher)
            except Exception:
                _swallowed_note()
        else:
            try:
                self._home_panel.set_bridge_visible(False)
            except Exception:
                _swallowed_note()
        # "You are here" — reflect real project state on the workflow cards, and
        # keep it live as layers are added/removed by the tools.
        try:
            from qgis.core import QgsProject
            self._refresh_home_steps()
            # disconnect-before-connect: _install_home_panel runs again when the
            # panel is reopened, so guard against duplicate slot connections.
            for sig in (QgsProject.instance().layersAdded,
                        QgsProject.instance().layersRemoved):
                for _slot in (self._refresh_home_steps, self._home_refresh_debounced):
                    try:
                        sig.disconnect(_slot)
                    except (TypeError, RuntimeError):
                        pass
                # Debounced: opening a project fires layersAdded once PER layer (20
                # layers => 20 full context recomputes). A 150 ms single-shot coalesces
                # the burst into ONE refresh. Same end result, far less churn.
                sig.connect(self._home_refresh_debounced)
        except Exception as e:
            print(f'[FiberNet] step-state wiring failed: {e}')
        # Remove any prior toolbar action first — _install_home_panel() re-runs on
        # a dock rebuild (user closes + reopens the panel), which would otherwise
        # stack duplicate 'Velocity Nexus Home' buttons.
        _old_home = getattr(self, '_home_action', None)
        if _old_home is not None:
            try:
                self._toolbar.removeAction(_old_home)
            except Exception:
                _swallowed_note()
        self._home_action = QAction('Velocity Nexus Home', self.iface.mainWindow())
        self._home_action.setToolTip('Open the Velocity Nexus home panel')
        # Use the guarded opener (handles None / deleted-C++ panel + rebuild)
        # rather than touching self._home_panel directly, which crashes if the
        # dock was closed.
        self._home_action.triggered.connect(self._show_home_panel)
        self._toolbar.addAction(self._home_action)
        self._actions['home'] = self._home_action
        # Park the Splice Viewer button right next to Velocity Nexus Home
        rv = self._actions.get('route_viewer')
        if rv is not None:
            try:
                self._toolbar.removeAction(rv)
                self._toolbar.insertAction(self._home_action, rv)
                btn = self._toolbar.widgetForAction(rv)
                if btn is not None:
                    btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
            except Exception:
                _swallowed_note()
        print('[FiberNet] Velocity Nexus home panel installed ✓')

    def _build_menu(self):
        """Build the single 'Velocity Nexus' menu — the JJ-approved Phase 1 unified tree.
        Replaces the old VeloPlan menu. Reuses toolbar QActions where they exist; AI Erven
        is RETIRED (tessellation violates the no-Voronoi erven rule) and deliberately absent."""
        from qgis.PyQt.QtWidgets import QMenu
        from qgis.PyQt.QtGui import QAction
        mw = self.iface.mainWindow()
        if getattr(self, '_velo_menu', None) is not None:
            try:
                mw.menuBar().removeAction(self._velo_menu.menuAction())
            except Exception:
                _swallowed_note()
        # The menu is now opened from the ⚙ button in the Velocity Nexus panel,
        # NOT from the menu bar (JJ: remove the top 'Velocity Nexus' menu). It is a
        # standalone QMenu parented to the main window and popped up by _open_velo_menu.
        self._velo_menu = QMenu('Velocity Nexus', mw)
        self._velo_menu.setToolTipsVisible(True)   # show the authored tooltips

        try:
            try:
                from . import error_reporter as _er
            except ImportError:
                import error_reporter as _er
        except Exception:
            _er = None

        def mk(label, cb, tip=None):
            a = QAction(label, mw)
            # Nexus telemetry: record every menu action (choke point) — one
            # place captures all tools without per-tool edits. Fail-silent.
            nexus = getattr(self, '_nexus', None)
            if nexus is not None:
                cb = nexus.wrap(label, cb)
            # Wrap so a teammate gets a logged report, not a crash.
            a.triggered.connect(_er.guard(self.iface, label, cb) if _er else cb)
            if tip:
                a.setToolTip(tip)
            return a

        # Is our processing provider actually loaded right now? (False in a
        # headless/unactivated context where the provider is withheld.) Computed
        # once so alg() doesn't cry wolf about "unknown id" when the WHOLE
        # provider simply isn't up yet — that's a different situation from a
        # genuinely typo'd id, and warning on it just adds noise.
        from qgis.core import QgsApplication as _QgsApp
        _provider_loaded = any(
            a.id().startswith('fibernetwork:')
            for a in _QgsApp.processingRegistry().algorithms())

        def alg(label, alg_id):
            import processing as _p
            # Guard against the FT9-class bug: a menu entry pointing at an
            # algorithm id that isn't actually registered dies silently on
            # click. Surface it loudly at build time — but only when the provider
            # is loaded, so a withheld-provider context stays quiet.
            from qgis.core import QgsApplication
            if _provider_loaded and QgsApplication.processingRegistry().algorithmById(alg_id) is None:
                print(f'[FiberNet] ⚠ menu "{label}" references unknown algorithm '
                      f'"{alg_id}" — entry will not work until the id is fixed.')
            return mk(label, lambda: _p.execAlgorithmDialog(alg_id, {}))

        dev = self._is_dev_mode()

        def add_ids(menu, ids):
            for _id in ids:
                # dev-only actions never reach a teammate's menu
                if _id in self._actions and (
                        dev or not any(e.get('id') == _id and e.get('client') == 'dev'
                                       for e in TOOLBAR_SPEC)):
                    menu.addAction(self._actions[_id])

        # ── top level ────────────────────────────────────────────────────────
        self._velo_menu.addAction(mk('🏠  Velocity Nexus Panel (home dashboard)', self._show_home_panel))
        self._velo_menu.addAction(mk('🆕  New Project…', self._show_welcome_dialog))
        self._velo_menu.addAction(mk('🧭  Workflow Guide (what to do next)…', self._open_workflow_dock))
        # NOTE: automation buttons live in the Velocity Nexus PANEL groups, never in this
        # menu (menu = options/settings only). "Generate HLD PDF" is a DELIVERABLES panel button.

        # AI Mapping (Detect Buildings, Fetch Erven) is now panel buttons — removed
        # from the menu. Erven Studio + dev experiments live on the toolbar / Dev.

        # ALL automations are now physical panel buttons (collapsible groups):
        #  • Manual Planning toolkit (Place Pole/Dome, Draw cables, Auto PON/Zone,
        #    Connect Drops, Record PON Order, …) → "MANUAL PLANNING" panel group.
        #  • Labelling / FT Pipeline / HeroTel → the panel workflow steps + the
        #    Processing Toolbox.
        #  • QA & Output (Topology QA, exports, Pre-Flight, …) + Tools (Poles,
        #    Enclosures, Route Viewer, Backup) → panel button groups.
        # The ⚙ Menu now carries ONLY settings/options (below). Handlers retained.

        # ── 🧪 Dev / Experimental (dev machine only — never on a teammate menu) ─
        if dev:
            m_dev = self._velo_menu.addMenu('🧪  Dev / Experimental')
            add_ids(m_dev, ['ai_detect', 'velo_detect', 'canvas', 'run_q', 'update_git'])
            m_dev.addAction(mk('🛣  Generate Erven from roads (no cadastre)', self._gen_erven_osm,
                               'For areas with NO CSG coverage: generate regular erven from the '
                               'OSM road network (blocks → ~14×22m stands). Dev/venv only.'))
            m_dev.addAction(mk('▶  Run Erven + Demand (full AOI)', self._run_erven_now))

        # ── ⚙ Settings & Help (footer submenu) ───────────────────────────────
        self._velo_menu.addSeparator()
        m_set = self._velo_menu.addMenu('⚙  Settings & Help')
        self._report_action = mk('🐞  Report a Problem…', self._open_problem_report)
        m_set.addAction(self._report_action)
        self._about_action = mk('ℹ️  About & Activation…', self._open_about_activation)
        m_set.addAction(self._about_action)
        m_set.addAction(mk('🔄  Check for updates…', self._check_for_updates))
        m_set.addAction(mk('🗺  Tool Map (what does what)', self._open_tool_map))
        m_set.addAction(mk('⌨  Command Palette  (Ctrl+Shift+P)',
                           self._open_command_palette))
        # Render-only smoothing for big layers (faster pan/zoom; data untouched).
        # QAction is already imported from qgis.PyQt.QtGui at the top of _build_menu
        # (Qt6 moved QAction out of QtWidgets — re-importing from QtWidgets would fail).
        try:
            from fibre_automation import ui_smooth as _uism
            self._smooth_action = QAction('⚡  Fast render (large projects)',
                                          self.iface.mainWindow())
            self._smooth_action.setCheckable(True)
            self._smooth_action.setChecked(_uism.enabled())

            def _toggle_smooth(on):
                _uism.set_enabled(on)
                if on:
                    _uism.apply()                       # heavy-layer geometry simplify
                    _uism.apply_canvas(self.iface)      # parallel render + caching
                    self.iface.mapCanvas().refresh()
                    msg = "Fast render ON — heavy layers simplified + parallel/cached rendering"
                else:
                    _uism.restore_canvas(self.iface)    # put canvas prefs back
                    self.iface.mapCanvas().refresh()
                    msg = "Fast render OFF — canvas restored (layer simplify clears on next project load)"
                try:
                    self.iface.messageBar().pushMessage(
                        "Velocity Nexus", msg,
                        level=Qgis.MessageLevel.Info, duration=5)
                except Exception:
                    _swallowed_note()
            self._smooth_action.toggled.connect(_toggle_smooth)
            m_set.addAction(self._smooth_action)
        except Exception:
            _swallowed_note()
        # Theme switcher — moved here from the header (the red Ticket button took
        # its place). Default look is the premium blue.
        m_theme = m_set.addMenu('🎨  Theme')
        try:
            from .velocity_home_panel import THEMES as _TH
        except Exception:
            _TH = {}
        for _k, _v in _TH.items():
            m_theme.addAction(mk(_v.get('name', _k),
                              lambda *a, k=_k: self._home_panel
                              and self._home_panel.set_theme(k)))
        m_set.addSeparator()
        m_set.addAction(mk('🧩  Install AI components (Detect Buildings)…',
                           self._install_ai_components))
        # Team Monitor — only shown to the planning-office admin (JJ).
        try:
            if getattr(self, '_nexus', None) is not None and self._nexus.is_admin():
                m_set.addAction(mk('🛰  Team Monitor (who is using Nexus)…',
                                   self._nexus.open_team_monitor))
        except Exception:
            _swallowed_note()
        m_set.addAction(mk('🩺  Run health check', self._run_health_check))
        m_set.addAction(mk('📂  Open log / output folder', self._open_data_folder))
        m_set.addAction(mk('📋  Copy diagnostics', self._copy_diagnostics))
        m_set.addAction(mk('📖  Team guide', self._open_team_guide))
        self._apply_activation_gate()
        print('[FiberNet] Velocity Nexus menu built ✓')

    # ── ⚙ Settings menu popup (opened from the panel gear, not the menu bar) ──
    def _open_ticket_dialog(self, anchor=None):
        """Open the 🎫 Log-a-ticket form. Submitting sends the bug/feature request
        to the planning office via the Nexus backend (offline-safe spool)."""
        try:
            try:
                from .ticket_dialog import TicketDialog
            except ImportError:
                from ticket_dialog import TicketDialog
            from qgis.PyQt.QtCore import Qt
            dlg = TicketDialog(self.iface, self._submit_ticket)
            # destroy on close so it doesn't linger as a hidden top-level window
            # (these were piling up — visible in the taskbar hover-preview).
            dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
            dlg.exec()
        except Exception as e:
            self.iface.messageBar().pushWarning(
                'Velocity Nexus', f'Ticket form failed: {str(e)[:160]}')

    def _submit_ticket(self, payload):
        """Attach who/version/project and send the ticket. Returns True if it was
        queued/sent (insert spools offline), False if there's no backend."""
        try:
            from qgis.core import QgsProject
            nx = getattr(self, '_nexus', None)
            prof = getattr(nx, 'profile', None) if nx else None
            payload = dict(payload)
            payload.update({
                'username': getattr(prof, 'username', None),
                'display_name': getattr(prof, 'display_name', None),
                'plugin_version': getattr(nx, 'plugin_version', None),
                'qgis_version': getattr(nx, 'qgis_version', None),
                'project_name': QgsProject.instance().baseName() or None,
            })
            backend = getattr(nx, 'backend', None) if nx else None
            if backend is None:
                return False
            # Cap how many screenshots ride as their OWN uploaded URL (each is a
            # sync upload); ALL shots are still embedded in the PDF below, so any
            # beyond the cap are NOT lost, they just don't get a standalone URL.
            shots = payload.pop('_shots', None) or []
            MAX_URL_SHOTS = 6
            to_upload = shots[:MAX_URL_SHOTS]
            # Render the PDF on the MAIN thread — Qt's QTextDocument/QPdfWriter are
            # NOT thread-safe. PDF-FIRST (hard rule): every ticket is filed as a
            # clean full-ticket document, so a long traceback is never truncated.
            # Human-readable filename so it drags out of the ticket board named
            # after the ticket, not a raw uuid.
            tag = 'BUG' if payload.get('kind') == 'bug' else 'FEATURE'
            fname = f"{tag}-{payload.get('title') or 'ticket'}"
            pdf = self._render_ticket_pdf(payload, shots)
            # Run the SLOW urllib uploads (screenshots + PDF) OFF the main thread so
            # QGIS never freezes during submit — these were up to 8 synchronous
            # uploads x 20s that blocked the UI. Delivery logic is unchanged; only
            # WHERE the network calls run moved. See _run_ticket_uploads_off_thread.
            up = self._run_ticket_uploads_off_thread(backend, to_upload, pdf, fname)
            urls = up.get('shot_urls', [])
            if urls:
                payload['screenshots'] = urls
            pdf_ok = bool(up.get('doc_url'))
            if pdf_ok:
                payload['body_doc_url'] = up['doc_url']
            backend.insert('tickets', payload)   # main thread (QgsNetworkAccessManager)
            # shots_total = how many we ATTEMPTED to upload as URLs (capped), not
            # the raw attach count — so the dialog warns only on a REAL upload
            # failure (uploaded < attempted), never just because extras were capped
            # (those still ship inside the PDF).
            return {'sent': True, 'shots_total': len(to_upload),
                    'shots_uploaded': len(urls), 'pdf_ok': pdf_ok}
        except Exception:
            return False




    def _open_span_inspector(self):
        """Open the Span Inspector dock (read-only pole-to-pole span highlighter)."""
        try:
            from .span_inspector import show_span_inspector
        except ImportError:
            from FiberNetworkAutomation.span_inspector import show_span_inspector
        try:
            show_span_inspector(self.iface)
        except Exception as e:
            try:
                self.iface.messageBar().pushMessage(
                    "Span Inspector", f"could not open: {e}",
                    level=Qgis.MessageLevel.Critical)
            except Exception:
                _swallowed_note()

    def _run_integrity_check(self):
        """Run the bundled safety/invariants self-check on the live project."""
        try:
            try:
                from .fibre_automation.safety import invariants
            except ImportError:
                from fibre_automation.safety import invariants
            r = invariants.run()
            v = r.get("verdict", "?")
            crit = r.get("critical", [])
            warn = r.get("warnings", [])
            lvl = {"OK": 3, "REVIEW": 1, "FAIL": 2}.get(v, 0)
            if crit:
                msg = f"{v} — {len(crit)} CRITICAL: " + " · ".join(crit[:2])
            elif warn:
                msg = f"{v} — {len(warn)} to review (see Log)"
            else:
                msg = f"{v} — structurally sound"
            self.iface.messageBar().pushMessage("🛡 Integrity Check", msg,
                                                level=lvl, duration=14)
            try:
                from qgis.core import QgsMessageLog, Qgis
                body = "\n".join(f"[{c['status']}] {c['check']}: {c['detail']}"
                                 for c in r.get("checks", []))
                QgsMessageLog.logMessage("Integrity Check — verdict " + v + "\n" + body,
                                         "VelocityNexus", level=Qgis.MessageLevel.Info)
            except Exception:
                _swallowed_note()
        except Exception as e:
            try:
                self.iface.messageBar().pushMessage("Integrity Check", f"failed: {e}", level=Qgis.MessageLevel.Critical)
            except Exception:
                _swallowed_note()

    def _show_health_panel(self):
        """Open the local, read-only System Health panel (Green/Amber/Red)."""
        try:
            try:
                from .health_panel import show_health_panel
            except ImportError:
                from health_panel import show_health_panel
            show_health_panel(self.iface)
        except Exception as e:
            try:
                self.iface.messageBar().pushMessage(
                    "System Health", f"Could not open health panel: {e}", level=Qgis.MessageLevel.Warning)
            except Exception:
                _swallowed_note()

    def _show_guardian_incidents(self):
        """Open the local, read-only Geometry Guardian incidents viewer."""
        try:
            try:
                from .guardian_panel import show_guardian_incidents
            except ImportError:
                from guardian_panel import show_guardian_incidents
            show_guardian_incidents(self.iface)
        except Exception as e:
            try:
                self.iface.messageBar().pushMessage(
                    "Geometry Guardian", f"Could not open incidents panel: {e}", level=Qgis.MessageLevel.Warning)
            except Exception:
                _swallowed_note()

    def _auto_ticket_from_incident(self, inc):
        """Geometry Guardian → ticket. Turn a mass-geometry-loss incident into a
        deduplicated 'bug' ticket carrying the full crash report, so the ROOT CAUSE
        lands in the dev queue automatically. Best-effort, rate-limited, never raises.
        """
        try:
            import json
            import hashlib
            import time
            layer = inc.get('layer', '?')
            ctx = inc.get('context') or []
            cause = ctx[-1] if ctx else ''
            stack = inc.get('stack', '') or ''
            # stack signature = the last real code frame (skip the guardian/timer frames)
            sig = ''
            for ln in reversed(stack.splitlines()):
                s = ln.strip()
                if s.startswith('File "') and 'geometry_guardian' not in s:
                    sig = s
                    break
            fp = hashlib.sha1(f"{layer}|{cause}|{sig}".encode('utf-8', 'ignore')).hexdigest()[:12]

            # In-memory atomic claim — checked + set synchronously (no IO between),
            # so no reentrancy / timer re-fire can ever double-file the same fp in
            # this session, even before the file-based store below is written.
            claimed = getattr(self, '_guardian_ticketed_fps', None)
            if claimed is None:
                claimed = self._guardian_ticketed_fps = set()
            if fp in claimed:
                return
            claimed.add(fp)

            # rate-limit: one ticket per fingerprint per 6h on this machine (no spam)
            store = os.path.join(os.path.expanduser('~'), '.velocity_nexus',
                                 'guardian_ticketed.json')
            seen = {}
            try:
                with open(store, encoding='utf-8') as f:
                    seen = json.load(f)
            except Exception:
                seen = {}
            now = time.time()
            if fp in seen and (now - seen[fp]) < 6 * 3600:
                return  # already filed recently

            # Record the fingerprint BEFORE the (slow, off-thread) send so a repeat
            # incident can't slip a duplicate through while the first is still
            # uploading. Better to under-ticket than spam dupes — the data is
            # restored regardless; the ticket is best-effort for the dev queue.
            seen[fp] = now
            seen = {k: v for k, v in seen.items() if now - v < 7 * 86400}
            try:
                os.makedirs(os.path.dirname(store), exist_ok=True)
                with open(store, 'w', encoding='utf-8') as f:
                    json.dump(seen, f)
            except Exception:
                _swallowed_note()

            body = (
                "[Bug]  [Priority: \U0001f6a8 Auto]  [Area: Geometry Guardian]\n\n"
                "\U0001f6e1 The Geometry Guardian auto-RESTORED a massive geometry loss "
                "that the operator did NOT cause. The data is back on the operator's "
                "machine — this ticket exists so the ROOT CAUSE gets fixed.\n\n"
                f"Layer:     {layer}\n"
                f"Lost:      {inc.get('lost')}   Restored: {inc.get('restored')}   "
                f"(before={inc.get('before')} after={inc.get('after')})\n"
                f"In edit:   {inc.get('in_edit')}\n"
                f"Project:   {inc.get('project')}\n"
                f"When:      {inc.get('ts_iso')}\n"
                f"Fingerprint: {fp}\n\n"
                "WHAT THE PLUGIN WAS DOING (oldest → newest):\n"
                + ("\n".join(f"  - {c}" for c in ctx[-15:]) or "  (no breadcrumb)")
                + "\n\nSTACK AT DETECTION:\n" + (stack[-2200:] or "(none)")
            )
            payload = {
                'kind': 'bug',
                'title': (f"\U0001f6e1 Auto: {inc.get('lost')} features vanished from "
                          f"'{layer}' (Geometry Guardian)")[:160],
                'body': body,
            }
            self._submit_ticket(payload)
        except Exception:
            _swallowed_note()

    def _auto_ticket_from_error(self, where, exc, tb_text):
        """A captured plugin CRASH → a deduplicated bug ticket in the dev queue, so
        a massive error reaches the dev (not just the errors table). Flood-guarded +
        rate-limited like the Geometry Guardian. Best-effort, never raises."""
        try:
            import json
            import hashlib
            import time
            import re
            tb = tb_text or ''
            etype = type(exc).__name__ if exc is not None else 'Error'
            emsg = (str(exc) or '')[:200]
            funcs = re.findall(r'line \d+, in (\w+)', tb)[-3:]
            where_func = funcs[-1] if funcs else (where or '?')
            fp = hashlib.sha1(('ERR|' + etype + '|' + '|'.join(funcs)).encode('utf-8', 'ignore')).hexdigest()[:12]

            # in-memory atomic claim (shared store with the guardian)
            claimed = getattr(self, '_guardian_ticketed_fps', None)
            if claimed is None:
                claimed = self._guardian_ticketed_fps = set()
            if fp in claimed:
                return
            claimed.add(fp)

            store = os.path.join(os.path.expanduser('~'), '.velocity_nexus',
                                 'guardian_ticketed.json')
            seen = {}
            try:
                with open(store, encoding='utf-8') as f:
                    seen = json.load(f)
            except Exception:
                seen = {}
            now = time.time()
            if fp in seen and (now - seen[fp]) < 6 * 3600:
                return
            seen[fp] = now
            seen = {k: v for k, v in seen.items() if now - v < 7 * 86400}
            try:
                os.makedirs(os.path.dirname(store), exist_ok=True)
                with open(store, 'w', encoding='utf-8') as f:
                    json.dump(seen, f)
            except Exception:
                _swallowed_note()

            try:
                from .geometry_guardian import recent_activity
            except ImportError:
                from geometry_guardian import recent_activity
            ctx = recent_activity()
            body = (
                "[Bug]  [Priority: \U0001f4a5 Auto-crash]  [Area: Auto-captured]\n\n"
                "\U0001f4a5 An unhandled error occurred in the plugin and was auto-captured "
                "on this machine. Root cause needs fixing.\n\n"
                f"Error:   {etype}: {emsg}\n"
                f"Where:   {where}  (in {where_func})\n"
                f"Fingerprint: {fp}\n\n"
                "WHAT THE PLUGIN WAS DOING (oldest -> newest):\n"
                + ("\n".join(f"  - {c}" for c in ctx[-15:]) or "  (no breadcrumb)")
                + "\n\nTRACEBACK:\n" + (tb[-3500:] or "(none)")
            )
            payload = {
                'kind': 'bug',
                'title': (f"\U0001f4a5 Auto: {etype} in {where_func} (crash)")[:160],
                'body': body,
            }
            self._submit_ticket(payload)
        except Exception:
            _swallowed_note()

    def _run_ticket_uploads_off_thread(self, backend, shots, pdf, fname):
        """Do the BLOCKING urllib uploads (screenshots + PDF doc) on a worker
        thread so the submit never freezes the QGIS UI, pumping events while we
        wait (the ux.py philosophy — NO nested QEventLoop). urllib is pure network
        → safe off the main thread; backend.insert (QgsNetworkAccessManager) stays
        on the main thread, called by the caller AFTER this returns.

        Returns {'shot_urls': [...], 'doc_url': str|None}. Fail-soft: if threading
        is unavailable for any reason it falls back to a synchronous upload so a
        ticket is NEVER lost (PDF-first)."""
        out = {'shot_urls': [], 'doc_url': None}

        def _do():
            for png in shots:
                try:
                    u = backend.upload_screenshot(png)
                except Exception:
                    u = None
                if u:
                    out['shot_urls'].append(u)
            if pdf:
                for _attempt in range(2):       # one retry — uploads fail transiently
                    try:
                        d = backend.upload_bytes(
                            pdf, 'pdf', 'application/pdf', filename=fname)
                    except Exception:
                        d = None
                    if d:
                        out['doc_url'] = d
                        break

        try:
            from qgis.PyQt.QtCore import QThread
            from qgis.PyQt.QtWidgets import QApplication

            class _Uploader(QThread):
                def run(self_):
                    _do()

            w = _Uploader()
            w.start()
            # keep the UI responsive while the worker uploads; wait(ms) returns
            # True once the thread has finished, so the loop exits cleanly.
            while not w.wait(25):
                QApplication.processEvents()
        except Exception:
            _do()                                # no threads → synchronous fallback
        return out

    def _render_ticket_pdf(self, payload, shots=None):
        """Render the WHOLE ticket — title, metadata, body, and the actual
        screenshot images embedded — to PDF bytes for the ticket board. Qt
        only, no external deps. Qt5/Qt6-safe. Returns bytes or None — fail-soft.

        shots: list of raw PNG bytes (the originals), so the images are embedded
        in the PDF rather than just linked."""
        try:
            from qgis.PyQt.QtGui import (QPdfWriter, QTextDocument, QImage)
            from qgis.PyQt.QtCore import (QBuffer, QByteArray, QIODevice, QUrl,
                                          Qt)

            def _esc(s):
                return (str(s).replace('&', '&amp;').replace('<', '&lt;')
                        .replace('>', '&gt;'))

            kind = ('Bug report' if payload.get('kind') == 'bug'
                    else 'Feature request')
            meta = [
                ('Type', kind),
                ('From', payload.get('display_name')
                 or payload.get('username') or '-'),
                ('Plugin', payload.get('plugin_version') or '-'),
                ('QGIS', payload.get('qgis_version') or '-'),
                ('Project', payload.get('project_name') or '-'),
            ]
            meta_html = ''.join(
                f"<tr><td><b>{_esc(k)}</b>&nbsp;&nbsp;</td>"
                f"<td>{_esc(v)}</td></tr>" for k, v in meta)
            body = payload.get('body') or '(no details given)'

            ba = QByteArray()
            buf = QBuffer(ba)
            buf.open(QIODevice.OpenModeFlag.WriteOnly)
            writer = QPdfWriter(buf)
            # High DPI so embedded screenshots + text are crisp, not blurry (JJ).
            _pdf_res = 300
            try:
                writer.setResolution(_pdf_res)
            except Exception:
                _pdf_res = 150
                try:
                    writer.setResolution(_pdf_res)
                except Exception:
                    _swallowed_note()
            doc = QTextDocument()
            # CRITICAL: make the document convert font point sizes (and <img>
            # widths) at the writer's DPI, not Qt's default 96 dpi. Without this,
            # the page is sized in 300-dpi pixels while text stays 96-dpi -> every
            # letter renders ~1/3 size, crammed into the top corner (JJ 2026-07-13,
            # "letters looking funny"). Also set a comfortable field-readable base
            # font. Fail-soft: on any error keep the old behaviour, never drop the PDF.
            try:
                doc.documentLayout().setPaintDevice(writer)
                _f = doc.defaultFont()
                _f.setPointSizeF(11.0)
                doc.setDefaultFont(_f)
            except Exception:
                _swallowed_note()

            # Fill the printable page width so each screenshot uses the MOST device
            # pixels possible. Make the document page match the PDF page; fall back to
            # a sensible fixed width if the layout API isn't available.
            _page_w = 2200
            try:
                from qgis.PyQt.QtCore import QSizeF as _QSizeF
                _pr = writer.pageLayout().paintRectPixels(_pdf_res)
                doc.setPageSize(_QSizeF(_pr.width(), _pr.height()))
                _page_w = int(_pr.width() * 0.98)
            except Exception:
                _swallowed_note()

            # Embed the actual screenshot images as document resources so they render
            # inside the PDF (not just listed as URLs). Display each at its NATIVE
            # resolution up to the page width — never upscaled (that's what blurs a
            # small grab) and never needlessly shrunk below page width.
            shots_html = ''
            for i, png in enumerate(shots or []):
                try:
                    img = QImage()
                    if not img.loadFromData(bytes(png), 'PNG') or img.isNull():
                        continue
                    # No need to embed more pixels than we can display (page width).
                    if img.width() > _page_w:
                        img = img.scaledToWidth(
                            _page_w, Qt.TransformationMode.SmoothTransformation)
                    _disp_w = min(_page_w, img.width())   # never upscale -> never blur
                    name = f"shot{i}"
                    doc.addResource(
                        QTextDocument.ResourceType.ImageResource,
                        QUrl(name), img)
                    shots_html += (f"<p><b>Screenshot {i + 1}</b></p>"
                                   f"<p><img src='{name}' width='{_disp_w}'></p>")
                except Exception:
                    _swallowed_note(); continue

            html = (
                f"<h2>{_esc(payload.get('title') or 'Ticket')}</h2>"
                f"<table cellpadding='2'>{meta_html}</table><hr>"
                "<pre style=\"font-family:Consolas,'Courier New',monospace;"
                "font-size:10pt; white-space:pre-wrap;\">"
                f"{_esc(body)}</pre>{shots_html}")
            doc.setHtml(html)
            # PyQt5 exposes print_(), PyQt6 print() — support both.
            printer = getattr(doc, 'print_', None) or doc.print
            printer(writer)
            buf.close()
            return bytes(ba)
        except Exception:
            return None

    # ── Account guard (remote deactivate = total lockout) ─────────────────────
    def _start_account_guard(self):
        """Lock the whole tool if the planning office deactivated this account.
        Server-driven (is_user_active RPC) — only the office can reactivate; the
        teammate has no path to flip it. Cached lock survives restarts/offline."""
        try:
            from qgis.core import QgsSettings
            if QgsSettings().value('VelocityFibre/account_deactivated',
                                   False, type=bool):
                self._apply_deactivation(True)   # restore the lock immediately
        except Exception:
            _swallowed_note()
        self._report_machine_fingerprint()   # backfill so a deactivate can ban this PC
        self._check_account_active()
        try:
            from qgis.PyQt.QtCore import QTimer
            self._acct_timer = QTimer(self.iface.mainWindow())
            self._acct_timer.timeout.connect(self._check_account_active)
            self._acct_timer.start(10 * 60 * 1000)   # re-check every 10 min
            # notify-back: tell the teammate when a ticket they logged is fixed
            QTimer.singleShot(6000, self._check_resolved_tickets)
        except Exception:
            _swallowed_note()

    def _report_machine_fingerprint(self):
        """Record this machine's fingerprint on our installs row (anon UPDATE is
        allowed). If the office later deactivates this account, a DB trigger bans
        every fingerprint this user has used — so they can't sign up again under
        a new name from the same PC. Fire-and-forget; never blocks."""
        try:
            nx = getattr(self, '_nexus', None)
            backend = getattr(nx, 'backend', None) if nx else None
            prof = getattr(nx, 'profile', None) if nx else None
            if backend is None or prof is None:
                return
            try:
                from .fibre_automation.nexus_profile import fingerprint, profile as _pf
            except ImportError:
                from fibre_automation.nexus_profile import fingerprint, profile as _pf
            fp = fingerprint.machine_fingerprint()
            iid = _pf.Profile.install_id()
            if fp and iid:
                backend.update("installs", f"install_id=eq.{iid}",
                               {"machine_fingerprint": fp})
        except Exception:
            _swallowed_note()

    def _check_resolved_tickets(self):
        """Non-modal heads-up when a ticket THIS user logged has been resolved —
        either 'update to vX' or 'you're already on the fixed version'. Shown once
        per ticket (acknowledged IDs cached locally). Privacy-safe: the RPC only
        ever returns the caller's own tickets."""
        nx = getattr(self, '_nexus', None)
        prof = getattr(nx, 'profile', None) if nx else None
        backend = getattr(nx, 'backend', None) if nx else None
        u = getattr(prof, 'username', None)
        if backend is None or not u:
            return
        try:
            backend.my_resolved_tickets(u, self._on_resolved_tickets)
        except Exception:
            _swallowed_note()

    def _on_resolved_tickets(self, rows):
        if not rows:
            return
        try:
            import re as _re
            from qgis.core import QgsSettings, Qgis
            s = QgsSettings()
            acked = set(filter(None, (s.value('VelocityFibre/nexus/ackTickets', '')
                                      or '').split(',')))
            myver = getattr(getattr(self, '_nexus', None), 'plugin_version', None) or '0'

            def vt(x):
                return tuple(int(n) for n in _re.findall(r'\d+', str(x or '0')))

            new_ack = set(acked)
            shown = 0
            for r in rows:
                tid = str(r.get('id'))
                if not tid or tid in acked:
                    continue
                if shown >= 3:                       # don't flood the bar
                    # Do NOT ack here — leave un-shown tickets unacknowledged so
                    # they surface on a later call instead of being silenced forever.
                    continue
                title = r.get('title') or 'your ticket'
                fixver = r.get('resolved_in_version') or '?'
                is_bug = (r.get('kind') == 'bug')
                icon = '🐞' if is_bug else '💡'
                noun = 'bug report' if is_bug else 'feature request'
                verb = 'has been fixed' if is_bug else 'has been built'
                if vt(myver) >= vt(fixver):
                    self.iface.messageBar().pushSuccess(
                        'Velocity Nexus',
                        f'{icon} Your {noun} “{title}” {verb} — you’re already on the '
                        f'latest version. Thanks for reporting it!')
                else:
                    self.iface.messageBar().pushMessage(
                        'Velocity Nexus',
                        f'{icon} Your {noun} “{title}” {verb} in v{fixver} — please '
                        f'update (Plugins → Manage and Install Plugins → Upgradeable).',
                        level=Qgis.MessageLevel.Info, duration=15)
                new_ack.add(tid)
                shown += 1
            s.setValue('VelocityFibre/nexus/ackTickets', ','.join(sorted(new_ack)))
        except Exception:
            _swallowed_note()

    def _check_account_active(self):
        # Stage-2 tick first — runs every cycle even offline, so the 3-day
        # self-destruct countdown advances without needing the server.
        self._self_destruct_check()
        nx = getattr(self, '_nexus', None)
        prof = getattr(nx, 'profile', None) if nx else None
        backend = getattr(nx, 'backend', None) if nx else None
        u = getattr(prof, 'username', None)
        if backend is None or not u:
            return
        try:
            backend.check_active(u, self._on_active_result)
        except Exception:
            _swallowed_note()

    def _on_active_result(self, active):
        # True → active (lift any lock) · False → deactivated (lock) ·
        # None → offline/unknown (leave as-is; a cached lock persists)
        if active is True:
            self._apply_deactivation(False)
        elif active is False:
            self._apply_deactivation(True)

    def _is_owner_machine(self):
        """True on the planning-office (owner) machine — the admin read-key is
        present only there and never ships. Used to make the owner un-lockable."""
        try:
            from qgis.core import QgsSettings
            return bool(QgsSettings().value('VelocityFibre/nexus/adminKey') or '')
        except Exception:
            return False

    def _apply_deactivation(self, on):
        """Lock (on) or restore (off) the whole tool. Idempotent — only acts on
        an actual state change."""
        # Owner machine is NEVER locked — you can't deactivate yourself and get
        # shut out of the Team Monitor you'd need to re-enable from. (Restore,
        # on=False, is always allowed so a machine can never get stuck locked.)
        if on and self._is_owner_machine():
            return
        if getattr(self, '_deactivated', None) == on:
            return
        self._deactivated = on
        try:
            from qgis.core import QgsSettings
            QgsSettings().setValue('VelocityFibre/account_deactivated', on)
        except Exception:
            _swallowed_note()
        # 1. swap the home panel to the soft 'deactivated' screen
        try:
            if getattr(self, '_home_panel', None) is not None:
                self._home_panel.set_deactivated(on)
        except Exception:
            _swallowed_note()
        # 2. disable / re-enable the Velocity Nexus menu
        try:
            if getattr(self, '_velo_menu', None) is not None:
                self._velo_menu.menuAction().setEnabled(not on)
        except Exception:
            _swallowed_note()
        # 3. unregister / re-register the processing provider (no automation runs)
        try:
            from qgis.core import QgsApplication
            reg = QgsApplication.processingRegistry()
            if on:
                prov = getattr(self, 'provider', None)
                if prov is not None:
                    reg.removeProvider(prov)
            else:
                if reg.providerById('fibernetwork') is None:
                    self.initProcessing()
        except Exception:
            _swallowed_note()
        # 4. disable / re-enable the toolbar
        try:
            if getattr(self, '_toolbar', None) is not None:
                self._toolbar.setEnabled(not on)
        except Exception:
            _swallowed_note()
        # 5. disable / re-enable EVERY plugin action. This is what actually blocks
        #    the app-wide keyboard shortcuts (Ctrl+1..8, Ctrl+Shift+E, etc.) — a
        #    disabled QAction won't fire its shortcut, and disabling the toolbar
        #    alone does NOT do that. Remember prior enabled-state so restore is exact.
        try:
            acts = getattr(self, '_actions', {}) or {}
            if on:
                self._lock_prev_enabled = {k: a.isEnabled() for k, a in acts.items()}
                for a in acts.values():
                    a.setEnabled(False)
            else:
                prev = getattr(self, '_lock_prev_enabled', {})
                for k, a in acts.items():
                    a.setEnabled(prev.get(k, True))
                self._lock_prev_enabled = {}
        except Exception:
            _swallowed_note()
        # 6. Ctrl+K locator filter — deregister our results when locked (else a
        #    teammate could launch tools straight from the QGIS locator bar).
        try:
            if on:
                loc = getattr(self, '_locator', None)
                if loc is not None:
                    self.iface.deregisterLocatorFilter(loc)
                    self._locator = None
            elif getattr(self, '_locator', None) is None:
                self._install_locator_filter()
        except Exception:
            _swallowed_note()
        # 7. Ctrl+Shift+P command palette shortcut
        try:
            sc = getattr(self, '_cmd_palette_shortcut', None)
            if sc is not None:
                sc.setEnabled(not on)
        except Exception:
            _swallowed_note()
        # 8. close any floating tool panels that were already open at lock time
        if on:
            for attr in ('_pole_editor_panel', '_np_dock'):
                try:
                    w = getattr(self, attr, None)
                    if w is not None:
                        w.close()
                except Exception:
                    _swallowed_note()
        # 9. arm/disarm the self-destruct countdown (stamp now on a fresh lock,
        #    cancel it on reactivation). Stage 2 deletes the install after 3 days.
        self._self_destruct_check()

    def _self_destruct_check(self):
        """Stage 2 of the account guard. If this account has stayed deactivated
        for the configured window (default 3 days), remove the installed plugin
        from this machine. Owner-exempt and fail-open — see self_destruct.py."""
        try:
            import os
            try:
                from .fibre_automation.nexus_profile import self_destruct
            except ImportError:
                from fibre_automation.nexus_profile import self_destruct
            plugin_dir = os.path.dirname(os.path.abspath(__file__))
            self_destruct.evaluate(plugin_dir, self.iface)
        except Exception as e:
            print(f'[FiberNet] self-destruct check skipped: {e}')

    def _open_velo_menu(self, anchor=None):
        """Pop the full Velocity Nexus menu under the panel's ⚙ button."""
        from qgis.PyQt.QtCore import QPoint
        if getattr(self, '_velo_menu', None) is None:
            self._build_menu()
        try:
            if anchor is not None:
                self._velo_menu.popup(anchor.mapToGlobal(QPoint(0, anchor.height())))
            else:
                from qgis.PyQt.QtGui import QCursor
                self._velo_menu.popup(QCursor.pos())
        except Exception as e:
            self.iface.messageBar().pushWarning('Velocity Nexus', f'Menu error: {e}')

    def _run_health_check(self):
        """Quick self-check: bridge, roads data, PON order, activation, deps."""
        import os
        from qgis.PyQt.QtWidgets import QMessageBox
        rows = []
        try:
            from .fibre_automation.shared.vf_paths import roads_json, data_dir
        except ImportError:
            from fibre_automation.shared.vf_paths import roads_json, data_dir
        try:
            from . import activation as _a
        except ImportError:
            import activation as _a
        rows.append(('Activated', '✓' if _a.is_activated() else '✗ enter password'))
        rj = roads_json()
        rows.append(('Road data (FT7/FT8)', '✓ present' if os.path.exists(rj) else '— optional, not found'))
        rows.append(('Data/output folder', data_dir()))
        for pkg in ('geopandas', 'openpyxl', 'matplotlib'):
            try:
                __import__(pkg); rows.append((pkg, '✓'))
            except Exception:
                rows.append((pkg, '— installs on first use'))
        rows.append(('Plugin version', self._plugin_version()))
        QMessageBox.information(self.iface.mainWindow(), 'Velocity Nexus — Health check',
                               '\n'.join(f'{k}:  {v}' for k, v in rows))

    def _open_data_folder(self):
        from qgis.PyQt.QtCore import QUrl
        from qgis.PyQt.QtGui import QDesktopServices
        try:
            from .fibre_automation.shared.vf_paths import project_output_dir
        except ImportError:
            from fibre_automation.shared.vf_paths import project_output_dir
        try:
            QDesktopServices.openUrl(QUrl.fromLocalFile(project_output_dir()))
        except Exception as e:
            self.iface.messageBar().pushWarning('Velocity Nexus', str(e)[:160])

    def _copy_diagnostics(self):
        import platform
        from qgis.core import Qgis
        from qgis.PyQt.QtWidgets import QApplication
        try:
            from . import activation as _a
        except ImportError:
            import activation as _a
        txt = (f'Velocity Nexus {self._plugin_version()}\n'
               f'QGIS {Qgis.QGIS_VERSION}\nPython {platform.python_version()}\n'
               f'OS {platform.system()} {platform.release()} · {platform.node()}\n'
               f'Activated: {_a.is_activated()}')
        QApplication.clipboard().setText(txt)
        self.iface.messageBar().pushInfo('Velocity Nexus', 'Diagnostics copied to clipboard.')

    def _open_team_guide(self):
        """Show the bundled team guide rendered in-app (not the GitHub repo —
        that was the bug: with no local guide it fell back to opening GitHub)."""
        import os
        path = os.path.join(os.path.dirname(__file__), 'TEAM_GUIDE.md')
        if not os.path.exists(path):
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtGui import QDesktopServices
            QDesktopServices.openUrl(QUrl('https://github.com/JohanVelo/qz31-cache'))
            return
        try:
            from qgis.PyQt import sip
            _prev = getattr(self, '_team_guide_dlg', None)
            if _prev is not None and not sip.isdeleted(_prev):
                _prev.raise_(); _prev.activateWindow()
                return
        except Exception:
            _swallowed_note()
        try:
            from qgis.PyQt.QtCore import Qt
            from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QTextBrowser
            with open(path, encoding='utf-8') as _f:
                md = _f.read()
            dlg = QDialog(self.iface.mainWindow())
            dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)   # don't leak hidden windows
            dlg.setWindowTitle('Velocity Nexus — Team Guide')
            dlg.resize(780, 660)
            lay = QVBoxLayout(dlg)
            tb = QTextBrowser()
            tb.setOpenExternalLinks(True)
            try:
                tb.setMarkdown(md)          # Qt 5.14+: rendered markdown
            except Exception:
                tb.setPlainText(md)
            lay.addWidget(tb)
            try:
                from .nexus_dock import chrome_dialog
                chrome_dialog(dlg)
            except Exception:
                _swallowed_note()
            dlg.show()                      # non-modal (never block the UI)
            self._team_guide_dlg = dlg      # keep a ref so it isn't GC'd
        except Exception as e:
            self.iface.messageBar().pushWarning('Team guide', str(e)[:160])

    # ── Activation gate (build prompt §5) ────────────────────────────────────
    def _apply_activation_gate(self):
        """No valid token → every menu + toolbar action greyed except About & Activation."""
        try:
            try:
                from . import activation
            except ImportError:
                import activation
            active = activation.is_activated()
        except Exception as e:
            print(f'[FiberNet] activation check failed (leaving unlocked): {e}')
            return

        always_on = {getattr(self, '_about_action', None),
                     getattr(self, '_report_action', None)}

        def set_menu(menu, enabled):
            for a in menu.actions():
                sub = a.menu()
                if sub is not None:
                    set_menu(sub, enabled)
                    a.setEnabled(enabled)
                elif a not in always_on:
                    a.setEnabled(enabled)

        if getattr(self, '_velo_menu', None) is not None:
            try:
                set_menu(self._velo_menu, active)
            except RuntimeError:
                pass
        try:
            for a in self._toolbar.actions():
                a.setEnabled(active)
        except (RuntimeError, AttributeError):
            pass
        # No password → NOTHING works (JJ: "you won't get in at all"):
        # the Processing provider is unregistered (no Toolbox access) and the
        # Home panel is disabled, on top of the greyed menu/toolbar/shortcuts.
        try:
            from qgis.core import QgsApplication
            reg = QgsApplication.processingRegistry()
            registered = reg.providerById('fibernetwork') is not None
            if active and not registered:
                self.initProcessing()
            elif not active and registered:
                reg.removeProvider(self.provider)
                self.provider = None
        except Exception as e:
            print(f'[FiberNet] provider gate failed: {e}')
        try:
            if self._home_panel is not None:
                # The panel itself stays enabled so the lock card is usable;
                # the card visibility tracks activation.
                self._home_panel.setEnabled(True)
                self._home_panel.set_locked(not active, self._panel_activate)
        except (RuntimeError, AttributeError):
            pass
        if not active:
            self.iface.messageBar().pushWarning(
                'Velocity Nexus',
                'Locked — enter the company password in the Velocity Nexus panel (right) '
                'or via the popup to unlock all tools.')

    def _apply_panel_theme(self, theme_name, accent_hex):
        """Live re-skin the home panel when the user picks a theme/accent in
        their profile card."""
        try:
            if self._home_panel is not None:
                self._home_panel.apply_user_theme(theme_name, accent_hex)
                self._refresh_home_steps()   # re-apply step states after re-skin
        except Exception:
            _swallowed_note()

    # ── "you are here" workflow progress ─────────────────────────────────────
    def _proj_has_layer(self, *name_substrings):
        """True if a vector layer whose name contains any substring has >0
        features. Used to derive workflow progress from real project state."""
        try:
            from qgis.core import QgsProject, QgsMapLayer
            for lyr in QgsProject.instance().mapLayers().values():
                try:
                    if lyr.type() != QgsMapLayer.LayerType.VectorLayer:
                        continue
                    nm = lyr.name().lower()
                    if any(s in nm for s in name_substrings) and lyr.featureCount() > 0:
                        return True
                except Exception:
                    _swallowed_note(); continue
        except Exception:
            _swallowed_note()
        return False

    def _compute_home_step_states(self):
        """Map the 6 home-panel macro steps to done/current/todo from the
        project's layers. Conservative: only marks 'done' when the step's
        output clearly exists (never a false ✓). 'current' = first not-done."""
        done = [
            self._proj_has_layer('building'),                       # 1 Detect Buildings
            self._proj_has_layer('erven', 'erf'),                   # 2 Generate Erven
            self._proj_has_layer('pon', 'zone', 'splitter'),        # 3 Network Planner
            (self._proj_has_layer('pole')
             and self._proj_has_layer('distribution', 'cable')),    # 4 Label Network
            False,                                                  # 5 Check & Audit (not layer-detectable)
            False,                                                  # 6 Splice Plan (file output)
            False,                                                  # 7 HLD Atlas PDF (file output)
        ]
        states, current_set = [], False
        for d in done:
            if d:
                states.append('done')
            elif not current_set:
                states.append('current')
                current_set = True
            else:
                states.append('todo')
        return states

    def _home_refresh_debounced(self, *args):
        """Coalesce a burst of layersAdded/Removed (project open adds N layers, a tool
        emits several) into ONE _refresh_home_steps ~150 ms later, instead of N full
        context recomputes. Falls back to an immediate refresh if the timer can't start
        (the refresh must never be silently skipped)."""
        try:
            from qgis.PyQt.QtCore import QTimer
            t = getattr(self, '_home_ctx_timer', None)
            if t is None:
                t = QTimer(self.iface.mainWindow())
                t.setSingleShot(True)
                t.timeout.connect(self._refresh_home_steps)
                self._home_ctx_timer = t
            t.start(150)
        except Exception:
            try:
                self._refresh_home_steps()
            except Exception:
                _swallowed_note()

    def _refresh_home_steps(self, *args):
        try:
            if getattr(self, '_home_panel', None) is not None:
                self._home_panel.set_step_states(self._compute_home_step_states())
                self._refresh_home_context()
        except Exception:
            _swallowed_note()

    def _refresh_home_context(self):
        """Feed the home panel's live project-context strip. CHEAP ONLY —
        featureCount() (cached metadata, instant) + the pre-computed HLD score
        file. NEVER iterate features here (would freeze the QGIS main thread;
        see feedback_never_heavy_loops_via_bridge)."""
        panel = getattr(self, '_home_panel', None)
        if panel is None:
            return
        try:
            from qgis.core import QgsProject, QgsMapLayer
            proj = QgsProject.instance()
            layers = list(proj.mapLayers().values())

            def _count(*keys, mode='sum'):
                vals = [ly.featureCount() for ly in layers
                        if ly.type() == QgsMapLayer.LayerType.VectorLayer
                        and any(k in ly.name().lower() for k in keys)]
                if not vals:
                    return 0
                return max(vals) if mode == 'max' else sum(vals)

            ctx = {
                'project_name': proj.baseName() or None,
                'layer_count': len(layers),
                # max (not sum) — there can be several building layers (GOB + SAM)
                'buildings': _count('building', mode='max'),
                'erven': _count('erven', 'erf', mode='max'),
                'poles': _count('pole'),
                'onts': _count('ont', 'home connection', mode='max'),
                'splitters': _count('splitter', 'sts'),
            }
            # HLD score from the cached file (NOT a live audit) — only show when
            # it carries a real result (pass or fail present), never "✓ 0".
            try:
                import json as _json
                with open('C:/Temp/hld_score.json', encoding='utf-8') as _f:
                    s = _json.load(_f)
                p, fl = s.get('pass') or 0, s.get('fail') or 0
                if p or fl:
                    # numeric 0–100 readiness for the score ring
                    ctx['hld_score'] = int(round(100 * p / (p + fl)))
                    ctx['hld'] = (f'HLD ✓ {p}/{p + fl}' if not fl
                                  else f'HLD ⚠ {fl} issue' + ('s' if fl != 1 else ''))
            except Exception:
                _swallowed_note()
            panel.set_context(ctx)
        except Exception:
            _swallowed_note()

    def _panel_activate(self, password):
        """Activation callback for the Home-panel lock card.
        Returns (ok, message). On success: unlock gate + welcome screen."""
        try:
            from . import activation
        except ImportError:
            import activation
        if activation.seconds_locked() > 0:
            return (False, f'Too many attempts — wait {activation.seconds_locked()}s.')
        if activation.try_activate(password):
            self._apply_activation_gate()
            try:
                self._welcome_splash = activation.show_welcome(self.iface, self._plugin_version())
            except Exception:
                _swallowed_note()
            return (True, '')
        if activation.seconds_locked() > 0:
            return (False, f'Too many attempts — wait {activation.seconds_locked()}s.')
        return (False, 'Wrong password. Please try again.')

    def _prompt_activation_if_locked(self):
        """On startup, if not activated, make it impossible to miss: pop the branded
        Activation dialog (non-blocking) AND show the Home-panel lock card."""
        try:
            from . import activation
        except ImportError:
            import activation
        try:
            if activation.is_activated():
                return
            if self._home_panel is not None:
                self._home_panel.set_locked(True, self._panel_activate)
                self._home_panel.setVisible(True)
                self._home_panel.raise_()
            # non-blocking modal dialog, centred — the first thing they see
            dlg = activation.ActivationDialog(self.iface)
            dlg.dlg.setModal(True)
            dlg.dlg.show()
            dlg.dlg.raise_()
            dlg.dlg.activateWindow()

            def _after():
                if activation.is_activated():
                    self._apply_activation_gate()
                    if self._home_panel is not None:
                        self._home_panel.set_locked(False)
                    try:
                        self._welcome_splash = activation.show_welcome(
                            self.iface, self._plugin_version())
                    except Exception:
                        _swallowed_note()
            dlg.dlg.finished.connect(lambda _=0: _after())
            self._activation_prompt = dlg
        except Exception as e:
            print(f'[FiberNet] activation prompt failed: {e}')

    def _open_about_activation(self):
        try:
            from . import activation
        except ImportError:
            import activation
        from qgis.PyQt.QtWidgets import QMessageBox
        if activation.is_activated():
            ret = QMessageBox.question(
                self.iface.mainWindow(), 'Velocity Nexus',
                f'Velocity Nexus {self._plugin_version()}\n'
                'Status: ACTIVATED on this machine ✓\n\n'
                'Deactivate this machine?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
            if ret == QMessageBox.StandardButton.Yes:
                activation.deactivate()
                self._apply_activation_gate()
        else:
            if activation.ActivationDialog(self.iface).exec():
                self._apply_activation_gate()
                self.iface.messageBar().pushSuccess(
                    'Velocity Nexus', 'Activated — all tools unlocked ✓')
                try:
                    self._welcome_splash = activation.show_welcome(
                        self.iface, self._plugin_version())
                except Exception as e:
                    print(f'[FiberNet] welcome splash failed: {e}')

    def _export_cloud_formats(self):
        """Export all layers to GeoParquet + the network to OFDS JSON
        (cloud-native + open-standard deliverables; plain-QGIS via GDAL)."""
        import os
        from qgis.PyQt.QtWidgets import QFileDialog
        from qgis.PyQt.QtCore import Qt
        from qgis.core import QgsProject, Qgis
        default = (os.path.dirname(QgsProject.instance().fileName())
                   or os.path.expanduser('~'))
        out_dir = QFileDialog.getExistingDirectory(
            self.iface.mainWindow(),
            'Export GeoParquet + OFDS to folder…', default)
        if not out_dir:
            return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        mb = self.iface.messageBar()
        running = mb.createMessage('Export', 'Writing GeoParquet + OFDS…')
        mb.pushWidget(running, Qgis.MessageLevel.Info)
        QApplication.processEvents()
        try:
            try:
                from .fibre_automation import cloud_export as ce
            except ImportError:
                from fibre_automation import cloud_export as ce
            res = ce.export_project_to_geoparquet(out_dir)
            ok = [r for r in res if r['ok']]
            _, ofds_msg = ce.export_ofds(
                os.path.join(out_dir, 'network.ofds.json'))
            mb.pushSuccess(
                'Export', f"GeoParquet: {len(ok)}/{len(res)} layers · "
                          f"OFDS: {ofds_msg.split(' →')[0]}  →  {out_dir}")
        except Exception as e:
            self._log_and_push_critical('cloud export', e)
        finally:
            QApplication.restoreOverrideCursor()
            try:
                mb.popWidget(running)
            except Exception:
                _swallowed_note()

    def _export_design_report(self):
        """Generate the one-click Design Report PDF (Atlas map-book over PON/Zone)."""
        from qgis.PyQt.QtWidgets import QApplication
        from qgis.PyQt.QtCore import Qt
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            try:
                from . import report
            except ImportError:
                import report
            report.export_design_report(self.iface)
        except Exception as e:
            self.iface.messageBar().pushWarning('Velocity Nexus', f'Design Report: {e}')
        finally:
            QApplication.restoreOverrideCursor()

    def _show_home_panel(self):
        """Open / re-show the Velocity Nexus home dashboard panel.
        Re-creates it if it was closed (C++ object deleted)."""
        try:
            panel = getattr(self, '_home_panel', None)
            if panel is not None:
                try:
                    panel.setVisible(True)
                    panel.raise_()
                    return
                except RuntimeError:
                    self._home_panel = None  # deleted — rebuild below
            self._install_home_panel()
            if self._home_panel is not None:
                self._home_panel.setVisible(True)
                self._home_panel.raise_()
        except Exception as e:
            self.iface.messageBar().pushWarning('Velocity Nexus', f'Could not open the panel: {e}')

    def _open_workflow_dock(self):
        """Open the guided Workflow dock (checklist + validation)."""
        try:
            try:
                from . import workflow_dock
            except ImportError:
                import workflow_dock
            self._workflow_dock = workflow_dock.open_dock(self.iface)
        except Exception as e:
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.warning(self.iface.mainWindow(), 'Velocity Nexus',
                                f'Could not open the Workflow dock:\n{e}')

    def _generate_hld_pdf(self):
        """Open the Generate HLD PDF (BETA) dialog — builds the A3 atlas PDF in a
        separate headless process (never freezes QGIS); working project untouched."""
        try:
            try:
                from .hld_pdf import open_hld_pdf_dialog
            except ImportError:
                from hld_pdf import open_hld_pdf_dialog
            open_hld_pdf_dialog(self.iface)
        except Exception as e:
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.warning(self.iface.mainWindow(), 'Velocity Nexus',
                                f'Could not open Generate HLD PDF:\n{e}')

    def _maybe_whats_new(self):
        """Show the premium What's-New board once per new version after an upgrade
        (gated to activated machines). Card design grouped NEW / FIXED / IMPROVED,
        listing EVERYTHING since the version they last saw."""
        try:
            try:
                from . import activation, whats_new
            except ImportError:
                import activation, whats_new
            if not activation.is_activated():
                return
            from qgis.core import QgsSettings
            s = QgsSettings()
            version = self._plugin_version().lstrip('v')
            # same gate key the old text popup used → once-per-version, consistent
            seen = s.value('VelocityFibre/whatsNewVersion', '')
            if seen == version:
                return
            if not seen:
                # first ever install — the welcome screen covers this
                s.setValue('VelocityFibre/whatsNewVersion', version)
                return
            self._whats_new_dlg = whats_new.show_whats_new(
                seen, version, parent=self.iface.mainWindow())
            # Persist 'seen' only AFTER the dialog was shown successfully, so a
            # failure to display doesn't silently suppress this version forever.
            s.setValue('VelocityFibre/whatsNewVersion', version)
        except Exception as e:
            print(f'[FiberNet] whats-new failed: {e}')

    def _open_problem_report(self):
        """Open the Report a Problem dialog — teammates send their error log to JJ."""
        try:
            try:
                from . import error_reporter
            except ImportError:
                import error_reporter
            # Close any previous instance so repeated opens don't stack dialogs.
            try:
                from qgis.PyQt import sip
                _prev = getattr(self, '_problem_dlg', None)
                if _prev is not None and getattr(_prev, 'dlg', None) is not None \
                        and not sip.isdeleted(_prev.dlg):
                    _prev.dlg.close()
            except Exception:
                _swallowed_note()
            self._problem_dlg = error_reporter.ProblemReportDialog(self.iface)
            self._problem_dlg.show()
        except Exception as e:
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.warning(self.iface.mainWindow(), 'Velocity Nexus',
                                f'Could not open the report dialog:\n{e}')

    def _open_tool_map(self):
        """Generate + open the Admin/Tool Map page (JJ requirement, Phase 0 sign-off):
        a tidy HTML page of every menu action so you can always see what's where.
        Built from the LIVE menu, so it can never drift out of date."""
        import html as _html
        import tempfile
        from qgis.PyQt.QtCore import QUrl
        from qgis.PyQt.QtGui import QDesktopServices
        from qgis.core import QgsApplication

        def walk(menu, depth=0):
            rows = []
            for a in menu.actions():
                if a.isSeparator():
                    continue
                sub = a.menu()
                if sub is not None:
                    rows.append((depth, sub.title(), '', True))
                    rows.extend(walk(sub, depth + 1))
                elif a.text():
                    rows.append((depth, a.text(), a.toolTip() or '', False))
            return rows

        rows = walk(self._velo_menu)
        algs = sorted(a.id() + ' — ' + a.displayName()
                      for a in QgsApplication.processingRegistry().algorithms()
                      if a.id().startswith('fibernetwork:'))
        try:
            ver = self._plugin_version()
        except Exception:
            ver = ''
        body = ['<!DOCTYPE html><html><head><meta charset="utf-8"><title>Velocity Nexus — Tool Map</title>',
                '<style>body{font-family:Segoe UI,sans-serif;margin:2em auto;max-width:880px;color:#1a2050}',
                'h1{border-bottom:3px solid #8b2450}h2{color:#3d5cb8;margin-top:1.6em}',
                'table{border-collapse:collapse;width:100%}td{padding:5px 10px;border-bottom:1px solid #eee;vertical-align:top}',
                '.grp{font-weight:bold;background:#f4f6fb}.tip{color:#667;font-size:0.9em}</style></head><body>',
                f'<h1>Velocity Nexus — Tool Map</h1><p>Every tool in the plugin, where it lives, and what it does. '
                f'Generated live from the menu — always current. {_html.escape(ver)}</p><h2>Menu</h2><table>']
        for depth, text, tip, is_group in rows:
            ind = '&nbsp;' * 6 * depth
            cls = ' class="grp"' if is_group else ''
            body.append(f'<tr{cls}><td>{ind}{_html.escape(text)}</td>'
                        f'<td class="tip">{_html.escape(tip).replace(chr(10), "<br>")}</td></tr>')
        body.append('</table><h2>Processing algorithms (Toolbox)</h2><ul>')
        body += [f'<li><code>{_html.escape(s)}</code></li>' for s in algs]
        body.append('</ul></body></html>')

        out = os.path.join(tempfile.gettempdir(), 'velocity_fibre_tool_map.html')
        with open(out, 'w', encoding='utf-8') as f:
            f.write('\n'.join(body))
        QDesktopServices.openUrl(QUrl.fromLocalFile(out))

    def _plugin_version(self):
        import configparser
        cp = configparser.ConfigParser()
        cp.read(os.path.join(os.path.dirname(__file__), 'metadata.txt'), encoding='utf-8')
        return 'v' + cp.get('general', 'version', fallback='?')

    def _check_for_updates(self):
        """Fetch the distro plugins.xml and compare versions (deep-link to Plugin
        Manager). The network fetch (urlopen, up to an 8 s timeout) runs OFF the
        main thread via off_thread so QGIS never freezes while waiting; the result
        dialog is shown back on the main thread. Same comparison + messages as
        before — only WHERE the network call runs changed."""
        import urllib.request
        from qgis.PyQt.QtWidgets import QMessageBox
        URL = ('https://raw.githubusercontent.com/JohanVelo/qz31-cache/main/plugins.xml')

        def _fetch():                        # WORKER THREAD — pure network IO
            return urllib.request.urlopen(URL, timeout=8).read().decode('utf-8', 'replace')

        def _show(xml):                      # MAIN THREAD — parse + compare + dialog
            import re as _re
            # match the PLUGIN tag's version, not the <?xml version="1.0"?> prolog
            m = _re.search(r'<pyqgis_plugin[^>]*\bversion="([\d.]+)"', xml)
            remote = m.group(1) if m else '?'
            local = self._plugin_version().lstrip('v')

            def _vt(v):
                try:
                    return tuple(int(x) for x in v.split('.'))
                except Exception:
                    return ()
            if remote != '?' and _vt(remote) > _vt(local):
                QMessageBox.information(
                    self.iface.mainWindow(), 'Velocity Nexus — update available',
                    f'Version {remote} is available (you have {local}).\n\n'
                    'Open Plugins → Manage and Install Plugins → Upgradeable to update.')
            else:
                QMessageBox.information(
                    self.iface.mainWindow(), 'Velocity Nexus',
                    f'You are up to date (v{local}).')

        def _fail(exc):                      # MAIN THREAD
            QMessageBox.warning(self.iface.mainWindow(), 'Velocity Nexus',
                                f'Could not check for updates:\n{exc}')

        try:
            from fibre_automation import off_thread
        except Exception:
            off_thread = None
        if off_thread is not None:
            try:
                self.iface.messageBar().pushInfo('Velocity Nexus', 'Checking for updates…')
            except Exception:
                _swallowed_note()
            # run_off_thread has its own synchronous fallback if no task manager.
            off_thread.run_off_thread(_fetch, on_done=_show, on_error=_fail,
                                      description='Check for updates')
        else:
            try:                             # module missing (older bundle) → sync
                _show(_fetch())
            except Exception as e:
                _fail(e)

    def initGui(self):
        # Nuke any stale FiberNetworkAutomation toolbar left behind by a
        # previous init (happens if startPlugin ran twice without a clean unload).
        from qgis.PyQt.QtWidgets import QToolBar
        for tb in self.iface.mainWindow().findChildren(QToolBar):
            try:
                if tb.objectName() == 'FiberNetworkAutomationToolbar':
                    self.iface.mainWindow().removeToolBar(tb)
                    tb.deleteLater()
            except RuntimeError:
                pass

        # Velocity Nexus per-user profile + telemetry + team monitor (v2.4.0).
        # Starts the session (first-run dialog on a fresh machine). Fail-silent
        # and dry-run-safe — never blocks plugin load.
        try:
            if getattr(self, '_nexus', None) is None:
                try:
                    from .fibre_automation.nexus_profile.manager import NexusManager
                except ImportError:
                    from fibre_automation.nexus_profile.manager import NexusManager
                self._nexus = NexusManager(self.iface)
                self._nexus.start()
            # Auto-capture errors -> Team Monitor (so teammates need not file tickets)
            if getattr(self, '_nexus', None) is not None:
                try:
                    from .fibre_automation.nexus_profile import error_capture
                except ImportError:
                    from fibre_automation.nexus_profile import error_capture
                error_capture.install(self._nexus)
                # Also auto-FILE A TICKET for each captured crash (deduped +
                # flood-guarded) so a massive error reaches the dev queue, not
                # just the errors table.
                try:
                    error_capture.set_ticket_callback(self._auto_ticket_from_error)
                except Exception:
                    _swallowed_note()
            # UI-freeze watchdog: detects when the Qt main thread is blocked
            # (e.g. a hang after an autonet/Network-Planner run) and reports the
            # culprit stack to telemetry. Daemon thread is pure-Python (no Qt),
            # reports drained on the main-thread heartbeat. Degrade-not-crash.
            try:
                try:
                    from .freeze_watchdog import FreezeWatchdog
                except ImportError:
                    from freeze_watchdog import FreezeWatchdog
                nx = getattr(self, '_nexus', None)

                def _on_freeze(rec):
                    try:
                        from qgis.core import QgsMessageLog, Qgis
                        QgsMessageLog.logMessage(
                            f"UI freeze {rec['duration_ms']}ms [{rec['severity']}] "
                            f"fp={rec['fingerprint']}\n{rec['stack_text']}",
                            "VelocityNexus", level=Qgis.MessageLevel.Warning)
                    except Exception:
                        _swallowed_note()
                    if nx is not None:
                        nx.report_freeze(rec)

                # A PERMANENT hang last session (QGIS killed before it recovered)
                # spools to disk — the live recover-then-report path can't fire in
                # that case. Drain + report it now, on the next clean start.
                try:
                    try:
                        from . import freeze_watchdog as _fw
                    except ImportError:
                        import freeze_watchdog as _fw
                    _prev = _fw.drain_spool()
                    if _prev is not None:
                        _on_freeze(_prev)
                        print(f"[FiberNet] reported a permanent hang from the "
                              f"previous session ({_prev['duration_ms']}ms)")
                except Exception:
                    _swallowed_note()

                self._freeze_watchdog = FreezeWatchdog()
                self._freeze_watchdog.start(self.iface.mainWindow(), _on_freeze)
                print('[FiberNet] UI-freeze watchdog started ✓')
            except Exception as e:
                self._freeze_watchdog = None
                print(f'[FiberNet] freeze watchdog not started: {e}')

            # Geometry Guardian: black-box recorder + auto-restore. When a MASSIVE
            # number of features/geometries disappears that the operator did NOT
            # cause (a bug / rogue regen wiping a layer), it restores them from a
            # rolling healthy snapshot and reports a full incident centrally — so
            # the team never has to reconstruct "what went wrong".
            try:
                try:
                    from .geometry_guardian import GeometryGuardian
                except ImportError:
                    from geometry_guardian import GeometryGuardian
                _gnx = getattr(self, '_nexus', None)
                _giface = self.iface

                def _on_guardian_incident(inc):
                    try:
                        from qgis.core import QgsMessageLog, Qgis
                        QgsMessageLog.logMessage(
                            f"Geometry Guardian: {inc['lost']} features vanished from "
                            f"'{inc['layer']}' (not an operator delete) — restored "
                            f"{inc['restored']}. before={inc['before']} after={inc['after']}",
                            "VelocityNexus", level=Qgis.MessageLevel.Critical)
                    except Exception:
                        _swallowed_note()
                    try:
                        from qgis.core import Qgis as _Q
                        _giface.messageBar().pushMessage(
                            "🛡️ Geometry Guardian",
                            f"{inc['lost']} features disappeared from '{inc['layer']}' "
                            f"(not an operator delete) — auto-restored {inc['restored']}. "
                            "Incident logged.",
                            level=_Q.MessageLevel.Critical, duration=12)
                    except Exception:
                        _swallowed_note()
                    try:
                        if _gnx is not None and hasattr(_gnx, 'record_error'):
                            _gnx.record_error(
                                "geometry_guardian",
                                RuntimeError(
                                    f"mass geometry loss: {inc['lost']} from "
                                    f"'{inc['layer']}', restored {inc['restored']}"),
                                user_note=str(inc))
                    except Exception:
                        _swallowed_note()
                    # Close the loop: auto-file a deduplicated bug ticket carrying the
                    # full crash report so the root cause lands in the dev queue.
                    try:
                        self._auto_ticket_from_incident(inc)
                    except Exception:
                        _swallowed_note()

                self._geometry_guardian = GeometryGuardian(
                    report_cb=_on_guardian_incident, parent=self.iface.mainWindow())
                self._geometry_guardian.start()
                print('[FiberNet] Geometry Guardian started ✓')
            except Exception as e:
                self._geometry_guardian = None
                print(f'[FiberNet] Geometry Guardian not started: {e}')
        except Exception as e:
            self._nexus = None
            print(f'[FiberNet] Nexus profile init skipped: {e}')

        # Heal a stranded Splice-Viewer 'solo' dim on the ALREADY-open project
        # (readProject only fires for projects opened later). Fail-silent no-op
        # when nothing is stranded.
        try:
            self._heal_stranded_solo()
        except Exception:
            _swallowed_note()

        self._toolbar = self.iface.mainWindow().addToolBar('FiberNetworkAutomation')
        self._toolbar.setObjectName('FiberNetworkAutomationToolbar')
        self._toolbar.setIconSize(QSize(22, 22))  # research-recommended size
        # Toolbar QSS now follows the active Velocity Nexus theme (matches the panel
        # and switches with it).
        self._toolbar.setStyleSheet(_toolbar_qss_for_theme())
        self._build_toolbar()
        # Bridge poller is a dev-only Claude channel — teammates have no bridge.
        if self._is_dev_mode():
            self._start_bridge_poller()
        # Live HLD score tile in QGIS status bar (research_toolbar_ux 2026-04-28).
        # DEV ONLY — it polls a C:/Temp/hld_score.json every 30s; on a teammate
        # machine that file never exists, so it's a dead tile + a perpetual timer.
        if self._is_dev_mode():
            try:
                self._install_hld_score_tile()
            except Exception as e:
                print(f'[FiberNet] HLD score tile install failed: {e}')
        # Command palette — Ctrl+Shift+P fuzzy-finder for every plugin action
        try:
            self._install_command_palette()
        except Exception as e:
            print(f'[FiberNet] Command palette install failed: {e}')
        # Native QGIS locator — Ctrl+K, "vf <text>" jumps to a fiber feature
        try:
            self._install_locator_filter()
        except Exception as e:
            print(f'[FiberNet] Locator filter install failed: {e}')
        # Erven Studio — dock + button to detect buildings & tune cadastral erven (sliders + Run)
        try:
            self._install_erven_studio_button()
        except Exception as e:
            print(f'[FiberNet] Erven Studio button install failed: {e}')
        # Velocity Nexus branded home panel — friendly front-end for the main workflow
        try:
            self._install_home_panel()
        except Exception as e:
            print(f'[FiberNet] Home panel install failed: {e}')
        # Account guard — if the planning office deactivated this account, lock
        # the whole tool. Deferred so the panel + profile are fully ready.
        try:
            from qgis.PyQt.QtCore import QTimer as _QTimerAG
            _QTimerAG.singleShot(3000, self._start_account_guard)
        except Exception as e:
            print(f'[FiberNet] account guard schedule failed: {e}')
        # VeloPlan menu — one menu fronting every tool. Deferred so it captures ALL toolbar actions
        # (fibre_automation pipeline + absorbed fibretime actions are added after this point in initGui).
        try:
            from qgis.PyQt.QtCore import QTimer as _QTimer
            _QTimer.singleShot(2500, self._build_menu)
        except Exception as e:
            print(f'[FiberNet] VeloPlan menu schedule failed: {e}')
        # Mirror eye is a Claude dev tool — not installed for planners
        # Wire fibre_automation pipeline steps into STEP_MAP.
        # fibre_automation lives either:
        #   a) inside this plugin's directory (ZIP install — all planners)
        #   b) in the dev workspace (JJ's machine only, as a sibling folder)
        try:
            import sys, os
            plugin_dir = os.path.dirname(__file__)
            # (a) ZIP install: fibre_automation is a sub-package of the plugin dir
            if plugin_dir not in sys.path:
                sys.path.insert(0, plugin_dir)
            # (b) Dev fallback: workspace sibling (only adds if it actually exists)
            _ws = os.path.dirname(plugin_dir)
            if os.path.isdir(os.path.join(_ws, 'fibre_automation')) and _ws not in sys.path:
                sys.path.insert(0, _ws)
            # Evict cached fibre_automation modules so disk is read fresh — DEV
            # ONLY (a live-reload aid). On a teammate it would throw away cached
            # bytecode and force a ~24-module recompile on every plugin load.
            if self._is_dev_mode():
                for _mod in list(sys.modules.keys()):
                    if _mod.startswith('fibre_automation'):
                        del sys.modules[_mod]
            import fibre_automation.plugin_wiring  # noqa: F401
            print('[FiberNet] fibre_automation pipeline wired ✓')
            self._ensure_automation_sections()   # STEP_MAP is filled now
        except Exception as e:
            print(f'[FiberNet] fibre_automation wiring failed: {e}')

        # Restore SESSION from project file on open; clear it on new project
        try:
            from qgis.core import QgsProject
            QgsProject.instance().readProject.connect(self._on_project_read)
            QgsProject.instance().cleared.connect(self._on_project_cleared)
            # Restore from the project that's already open when the plugin loads
            self._on_project_read()
        except Exception as e:
            print(f'[FiberNet] project signal wiring failed: {e}')
        from qgis.PyQt.QtCore import QTimer
        # iface.newProjectCreated fires once during QGIS startup for the initial
        # blank "Untitled Project", then again every time the user does File → New
        # or clicks "New Empty Project".  Skip the first (startup) firing; show the
        # welcome dialog for all subsequent ones.
        self._new_project_count = 0

        def _on_new_project_created():
            self._new_project_count += 1
            if self._new_project_count <= 1:
                return  # startup blank project — ignore
            QTimer.singleShot(300, self._show_welcome_dialog)

        self._on_new_project_created = _on_new_project_created
        try:
            self.iface.newProjectCreated.connect(self._on_new_project_created)
            print('[FiberNet] newProjectCreated wired ✓')
        except Exception as e:
            print(f'[FiberNet] newProjectCreated wiring failed: {e}')
        # Connect to bridge dock client_changed signal (retry if bridge not ready yet)
        if not self._connect_bridge_client_signal():
            QTimer.singleShot(2000, self._connect_bridge_client_signal)
        # fibretime_tools buttons are RETIRED — everything is in the published VeloPlan plugin now
        # (home panel + VeloPlan menu). Do NOT absorb the fibretime_tools toolbar; instead disable
        # that redundant plugin so its toolbar never appears. (JJ: remove those buttons permanently.)
        self._absorb_attempts = 0
        self._absorb_watchdog = None
        QTimer.singleShot(1200, self._retire_fibretime_tools)
        # UI crash guard: disable drag-reorder on QGIS dock tab bars (prevents a Qt 6.11
        # QTabBar::moveTab access-violation crash) + self-heal the branded toolbar if it
        # was restored collapsed in a corner. Installed immediately + again after the
        # layout settles. Fail-open — never blocks startup.
        try:
            from .ui_crash_guard import install as _install_tab_guard, heal_toolbar as _heal_tb
        except ImportError:
            from ui_crash_guard import install as _install_tab_guard, heal_toolbar as _heal_tb
        mw = self.iface.mainWindow()
        _install_tab_guard(mw)
        # Heal the toolbar at two moments — QGIS restores the saved window layout
        # (which can leave the branded toolbar collapsed/off-window) at slightly
        # different times across machines, so run once early and once after it settles.
        self._ui_heal_timers = []
        for delay, callback in (
                (1500, lambda: (_install_tab_guard(mw), _heal_tb(mw))),
                (4000, lambda: _heal_tb(mw))):
            timer = QTimer(mw)
            timer.setSingleShot(True)
            timer.timeout.connect(callback)
            timer.start(delay)
            self._ui_heal_timers.append(timer)
        # "What's New" popup once per new version after an upgrade (not first install)
        QTimer.singleShot(3200, self._maybe_whats_new)
        # If locked, make activation impossible to miss: auto-popup + Home-panel card.
        # Deferred so the menu + home panel exist first.
        QTimer.singleShot(2900, self._prompt_activation_if_locked)
        # Register processing algorithms last so a crash above doesn't create a
        # zombie "fibernetwork" entry in the C++ registry (unload() can't remove
        # it once the C++ object is deleted by QGIS's exception-path cleanup).
        # Activation-gated: an unactivated machine gets NO algorithms either —
        # _apply_activation_gate registers the provider after a successful unlock.
        try:
            try:
                from . import activation as _act
            except ImportError:
                import activation as _act
            _gate_ok = _act.is_activated()
        except Exception:
            _gate_ok = True   # never let a gate bug brick the plugin for the team
        if _gate_ok:
            self.initProcessing()
        else:
            print('[FiberNet] not activated — processing provider withheld')

    # ── Dev vs team mode ─────────────────────────────────────────────────────
    def _is_dev_mode(self):
        """True only on JJ's machine. Dev-only buttons (Run q.py, AI server
        detect, git-pull Update, Canvas snapshot, Mirror Eye, Bridge status)
        are shown ONLY in dev mode; teammates never see them.

        Dev = the QGIS Bridge plugin is LOADED/active (Claude's control channel,
        which teammates don't run) OR the VF_DEV env var is set."""
        cached = getattr(self, '_dev_mode_cached', None)
        if cached is not None:
            return cached
        dev = bool(os.environ.get('VF_DEV'))
        if not dev:
            try:
                import qgis.utils as _qu
                # LOADED, not merely installed/available: a teammate who only has
                # the QGIS Bridge plugin present (disabled) must NOT get dev tools.
                # JJ always runs it loaded (Claude's control channel), so he stays dev.
                dev = 'QGISBridgePlugin' in getattr(_qu, 'plugins', {})
            except Exception:
                dev = False
        self._dev_mode_cached = dev
        print(f"[FiberNet] mode: {'DEV (JJ)' if dev else 'TEAM'}")
        return dev

    # ── Toolbar builder ──────────────────────────────────────────────────────
    def _build_toolbar(self):
        tb = self._toolbar
        dev = self._is_dev_mode()
        # Group spec entries by group id, preserving spec order.
        # In team mode, drop every dev-only entry (client == "dev").
        groups = OrderedDict((g, []) for g in GROUPS)
        for entry in TOOLBAR_SPEC:
            if entry.get("client") == "dev" and not dev:
                continue
            groups[entry["group"]].append(entry)

        for gid, entries in groups.items():
            meta = GROUPS[gid]
            if meta["kind"] == "menu":
                btn = QToolButton(tb)
                btn.setText(meta["title"])
                btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
                btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
                if meta.get("tooltip"):
                    btn.setToolTip(meta["tooltip"])
                menu = QMenu(btn)
                menu.setToolTipsVisible(True)   # show per-item tooltips
                menu.setStyleSheet(
                    f"QMenu {{ background: {_PANEL}; color: {_TEXT};"
                    f" border: 1px solid {_BORDER}; padding: 4px; }}"
                    f"QMenu::item {{ padding: 5px 18px; border-radius: 3px; }}"
                    f"QMenu::item:selected {{ background: {_ACCENT}; color: {_BG}; }}"
                    f"QMenu::item:disabled {{ color: {_DIM}; background: transparent; }}"
                    f"QMenu::separator {{ height: 1px; background: {_BORDER}; margin: 4px 8px; }}"
                )
                for e in entries:
                    if e["kind"] == "separator":
                        menu.addSeparator()
                    elif e["kind"] == "header":
                        # Non-clickable header — styled as grey italic label
                        hdr = QAction(e["label"], menu)
                        hdr.setEnabled(False)
                        f = hdr.font()
                        f.setItalic(True); f.setBold(True); f.setPointSize(8)
                        hdr.setFont(f)
                        menu.addAction(hdr)
                    else:
                        menu.addAction(self._make_action(e))
                btn.setMenu(menu)
                grp_act = tb.addWidget(btn)
                self._group_btns[gid] = btn
                self._group_acts[gid] = grp_act
            else:  # inline
                for e in entries:
                    if e["kind"] == "brand":
                        if dev:
                            tb.addWidget(self._make_brand_tile())
                        else:
                            tb.addWidget(self._make_static_logo())
                    else:
                        act = self._make_action(e)
                        tb.addAction(act)
                        btn = tb.widgetForAction(act)
                        if btn is not None:
                            eid = e.get("id", "")
                            # Client-selector buttons: large, branded, text-beside-icon
                            if eid == 'select_vuma':
                                btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
                                btn.setStyleSheet(_VUMA_BTN_QSS)
                            elif eid == 'select_ft':
                                btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
                                btn.setStyleSheet(_FT_BTN_QSS)
                            # Other named tool buttons also get text beside icon
                            elif eid in ("enc_editor", "pole_editor", "canvas",
                                         "route_viewer"):
                                btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)

        # Admin-only: a dedicated Team Monitor button on the toolbar (the
        # planning office / JJ). Shown ONLY when the owner read-key is present,
        # so teammates never see it. One click opens the live monitor.
        try:
            nx = getattr(self, '_nexus', None)
            if nx is not None and nx.is_admin():
                tb.addSeparator()
                mon_btn = QToolButton(tb)
                mon_btn.setText('🛰  Team Monitor')
                mon_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
                mon_btn.setCursor(Qt.CursorShape.PointingHandCursor)
                mon_btn.setToolTip('Live team activity — who is online and what '
                                   'they are doing right now (admin only)')
                mon_btn.setStyleSheet(
                    "QToolButton{background:#F5A623;color:#1A1206;border:none;"
                    "border-radius:6px;padding:5px 12px;font-weight:700;}"
                    "QToolButton:hover{background:#ffbe4d;}")
                mon_btn.clicked.connect(self._open_team_monitor)
                tb.addWidget(mon_btn)
                self._admin_monitor_btn = mon_btn
        except Exception:
            _swallowed_note()

        # Default state: no client chosen → show only brand + Setup Project
        self._update_toolbar_for_client(None)

    def _open_team_monitor(self, *args):
        """Toolbar handler — open/raise the JJ-only Team Monitor dock."""
        try:
            nx = getattr(self, '_nexus', None)
            if nx is not None:
                nx.open_team_monitor()
        except Exception:
            _swallowed_note()

    def _icon(self, path):
        return QgsApplication.getThemeIcon(path) if path else QIcon()

    def _make_action(self, e):
        act = QAction(self._icon(e.get("icon", "")), e["label"],
                      self.iface.mainWindow())
        if "tooltip" in e:
            act.setToolTip(e["tooltip"])
            act.setWhatsThis(e["tooltip"])
        act.setEnabled(e.get("enabled", True))
        # 2026-04-28: keyboard shortcuts per research_toolbar_ux_redesign_2026-04-28.md
        # (ft_all/Ctrl+Shift+F removed — redundant with the ⚡ Run FT 1..7 button
        #  in the Build FT 1-7 dropdown.)
        # 2026-07-13 shortcut audit: Ctrl+Shift+A/S/U/C collided with QGIS core
        # (Deselect Features / Save Project As / Show All Layers / Set CRS).
        # As ApplicationShortcuts those were AMBIGUOUS — Qt fired neither, so we
        # were quietly breaking core QGIS shortcuts. Moved to free Ctrl+Alt
        # combos. FT digit shortcuts + pole_editor/run_q had no conflict.
        SHORTCUTS = {
            'ft1':           'Ctrl+1', 'ft2': 'Ctrl+2', 'ft3': 'Ctrl+3',
            'ft4':           'Ctrl+4', 'ft4b':'Ctrl+5', 'ft5': 'Ctrl+6',
            'ft6':           'Ctrl+7', 'ft7': 'Ctrl+8',
            'audit_hld':     'Ctrl+Alt+D',
            'span_check':    'Ctrl+Alt+S',
            'update_layers': 'Ctrl+Alt+U',
            'pole_editor':   'Ctrl+Shift+E',
            'run_q':         'Ctrl+Shift+Q',
            'canvas':        'Ctrl+Alt+C',
        }
        if e["id"] in SHORTCUTS:
            act.setShortcut(SHORTCUTS[e["id"]])
            act.setShortcutContext(Qt.ShortcutContext.ApplicationShortcut)
            # Annotate tooltip with the shortcut so the user discovers it
            cur = act.toolTip() or e.get("label", "")
            act.setToolTip(f"{cur}  ({SHORTCUTS[e['id']]})")

        # route toolbar handlers through the friendly report flow, like the menu
        # path — a crash becomes a logged "Report a Problem" nudge, not a raw
        # traceback dumped on a teammate.
        try:
            try:
                from . import error_reporter as _er
            except ImportError:
                import error_reporter as _er
        except Exception:
            _er = None

        def _wire(cb):
            return _er.guard(self.iface, e["label"], cb) if _er else cb

        kind = e["kind"]
        if kind == "callback":
            act.triggered.connect(_wire(getattr(self, e["callback"])))
        elif kind == "action":
            # plain action with optional callback (used for stubs)
            if "callback" in e:
                act.triggered.connect(_wire(getattr(self, e["callback"])))
        elif kind == "algo":
            algo_id = e["algorithm"]
            eid = e["id"]
            act.triggered.connect(
                lambda _=False, a=algo_id, i=eid: self._run_algo(a, i))
        elif kind == "script":
            spath = e["script"]
            eid = e["id"]
            act.triggered.connect(
                lambda _=False, s=spath, i=eid: self._run_script(s, i))
        elif kind == "macro":
            act.triggered.connect(getattr(self, e["callback"]))

        self._actions[e["id"]] = act
        return act

    def _make_static_logo(self):
        """Team-mode toolbar identity: the RED-KNIGHT Velocity Nexus mark — no bridge
        status, no dev tools, not clickable. Rendered from the bundled icon.png IMAGE
        (not a font glyph) so it looks IDENTICAL on every teammate's machine; the old
        path drew the legacy 'V-mark' via branding.vf_style, which is why teammates
        kept seeing the old logo even on the newest version."""
        import os
        from qgis.PyQt.QtWidgets import QLabel, QHBoxLayout
        from qgis.PyQt.QtGui import QPixmap
        from qgis.PyQt.QtCore import Qt
        cont = QWidget()
        lay = QHBoxLayout(cont)
        lay.setContentsMargins(6, 0, 10, 0)
        lay.setSpacing(6)
        mark = QLabel()
        _logo = os.path.join(os.path.dirname(__file__), 'icon.png')
        _pm = QPixmap(_logo) if os.path.exists(_logo) else QPixmap()
        if not _pm.isNull():
            mark.setPixmap(_pm.scaledToHeight(
                22, Qt.TransformationMode.SmoothTransformation))
        else:
            # last-resort fallback only if the image is missing
            mark.setText('♞')
            mark.setStyleSheet(f'color:{theme_safe.colors()["bad"]}; font-weight:800; font-size:16px;')
        word = QLabel('Velocity Nexus')
        word.setStyleSheet(f'color: {_TEXT}; font-weight: 700; font-family:"Segoe UI";')
        lay.addWidget(mark)
        lay.addWidget(word)
        cont.setToolTip('Velocity Nexus')
        return cont

    def _make_brand_tile(self):
        """Clickable container: [VF badge] + [Bridge status label].
        Click → opens the VeloGIS Bridge dock widget."""

        class ClickableBrand(QWidget):
            def __init__(self, plugin):
                super().__init__()
                self._plugin = plugin
                self.setCursor(Qt.CursorShape.PointingHandCursor)
            def mousePressEvent(self, ev):
                self._plugin._open_bridge_dock()
                super().mousePressEvent(ev)

        container = ClickableBrand(self)
        layout = QHBoxLayout(container)
        layout.setContentsMargins(2, 0, 6, 0)
        layout.setSpacing(6)

        # Brand mark = the red knight chess piece (♞), replacing the old VF badge.
        # The status border (green/red) is driven by the bridge poller.
        badge = QLabel("♞")
        badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        badge.setMinimumWidth(28)
        badge.setStyleSheet(
            f"QLabel {{ background: #0D1320; color: #EF4444;"
            f" font-family:'Segoe UI Symbol','Segoe UI'; font-weight:800;"
            f" font-size:17px;"
            f" border: 2px solid {_DIM}; border-radius: 4px;"
            f" padding: 1px 7px; }}")
        self._brand_label = badge

        status = QLabel("Bridge …")
        status.setStyleSheet(
            f"QLabel {{ color: {_DIM}; font-family:'Segoe UI';"
            f" font-size:10px; font-weight:600; padding: 2px 4px; }}")
        self._brand_status = status

        layout.addWidget(badge)
        layout.addWidget(status)
        container.setToolTip("VelocityFibre  •  Click to open Bridge dock")
        return container

    # ── HLD score tile (status-bar widget) ───────────────────────────────────
    def _install_hld_score_tile(self):
        """Permanent QStatusBar widget showing live HLD pre-flight score.
        Reads C:/Temp/hld_score.json (written by hld_audit_writer.py)."""
        from qgis.PyQt.QtWidgets import QPushButton
        from qgis.PyQt.QtCore import QTimer
        # Defensive cleanup: remove any orphan tiles left by an unclean prior
        # shutdown. Match by objectName OR by text starting with "HLD:" so we
        # catch tiles created before the objectName patch.
        # NO QApplication.processEvents() — that caused re-entrance / freeze
        # 2026-04-28. setParent(None) + hide() are synchronous enough.
        try:
            mw = self.iface.mainWindow()
            sb = mw.statusBar()
            victims = []
            for child in mw.findChildren(QPushButton):
                if child.objectName() == 'FNAHLDScoreTile' or \
                   (child.text() or '').startswith('HLD:'):
                    victims.append(child)
            for child in victims:
                try:
                    sb.removeWidget(child)
                except Exception:
                    _swallowed_note()
                try:
                    child.setParent(None)  # synchronous detach from layout
                except Exception:
                    _swallowed_note()
                try:
                    child.hide()
                except Exception:
                    _swallowed_note()
                child.deleteLater()
        except Exception:
            _swallowed_note()
        tile = QPushButton("HLD: —")
        tile.setObjectName('FNAHLDScoreTile')
        tile.setFlat(True)
        tile.setCursor(Qt.CursorShape.PointingHandCursor)
        tile.setStyleSheet(
            # base text sits on the native toolbar, so it follows the theme; the hover
            # state paints its own dark background, so its light text stays fixed
            f"QPushButton {{ color:{theme_safe.colors(tile)['muted']}; padding:0 10px; font-weight:600;"
            " font-family:'Segoe UI'; font-size:11px; border:none; }"
            "QPushButton:hover { color:#E6E8F0; background:#3A3D5C; border-radius:4px; }"
        )
        tile.clicked.connect(self._refresh_hld_score)
        # First read
        self._hld_score_tile = tile
        self._refresh_hld_score_display()
        # Auto-refresh every 30s
        self._hld_timer = QTimer(self.iface.mainWindow())
        self._hld_timer.setInterval(30_000)
        self._hld_timer.timeout.connect(self._refresh_hld_score_display)
        self._hld_timer.start()
        # Add to status bar
        try:
            sb = self.iface.statusBarIface()
            sb.addPermanentWidget(tile, 0)
        except Exception:
            _swallowed_note()  # status bar API quirks — non-fatal

    def _refresh_hld_score_display(self):
        """Reads JSON, updates the tile label + colour. Does NOT run audit."""
        import json, os
        # Widget may have been deleted (deleteLater) between timer fire and
        # actual C++ destruction — catch the sip RuntimeError and self-clean.
        try:
            tile = self._hld_score_tile
            if tile is None:
                return
            path = 'C:/Temp/hld_score.json'
            if not os.path.exists(path):
                tile.setText("HLD: —")
                return
            try:
                with open(path, encoding='utf8') as f:
                    d = json.load(f)
            except Exception:
                return
            p = d.get('pass', 0); fa = d.get('fail', 0); n = d.get('note', 0)
            if fa == 0 and n == 0:
                color = "#16A34A"
            elif fa == 0:
                color = "#F59E0B"
            else:
                color = "#DC2626"
            tile.setText(f"HLD: {p}✓  {fa}✗  {n}!")
            tile.setStyleSheet(
                f"QPushButton {{ color:{color}; padding:0 10px; font-weight:700;"
                f" font-family:'Segoe UI'; font-size:11px; border:none; }}"
                f"QPushButton:hover {{ background:#3A3D5C; border-radius:4px; }}"
            )
            tile.setToolTip(
                f"Last audit: {d.get('ts','?')[:19]}\n"
                f"PASS: {p} · FAIL: {fa} · NOTE: {n}\n"
                "Click to re-run audit."
            )
        except RuntimeError:
            # C++ object already destroyed — stop the timer so it won't fire again
            try:
                if getattr(self, '_hld_timer', None):
                    self._hld_timer.stop()
            except RuntimeError:
                pass
            self._hld_score_tile = None

    def _refresh_hld_score(self):
        """Click handler — re-runs the audit script in-process.

        IMPORTANT: previously called the bridge via urllib.urlopen which
        deadlocked Qt main thread (bridge queue is processed on same
        thread → caused QGIS freeze + soft crash 2026-04-28).

        Now we just exec() the audit script directly since we're already
        inside QGIS. No HTTP, no thread, no deadlock.
        """
        from qgis.PyQt.QtWidgets import QApplication
        # Reentrancy guard: processEvents() below pumps the event loop, which can
        # deliver a queued clicked() and re-enter this handler (re-runs the audit
        # twice on the main thread / clobbers ns). Bail if already refreshing.
        if getattr(self, '_hld_refreshing', False):
            return
        self._hld_refreshing = True
        try:
            self.iface.messageBar().pushInfo("HLD score", "Refreshing…")
            QApplication.processEvents()
            with open('C:/Temp/hld_audit_writer.py', encoding='utf8') as f:
                code = f.read()
            # Run in a fresh namespace so we don't pollute plugin globals
            ns = {'__name__': '__hld_audit__'}
            exec(code, ns)
            self._refresh_hld_score_display()
            self.iface.messageBar().pushSuccess(
                "HLD score", "Audit refreshed — see status bar")
        except FileNotFoundError:
            self.iface.messageBar().pushWarning(
                "HLD score", "C:/Temp/hld_audit_writer.py not found")
        except Exception as e:
            self.iface.messageBar().pushWarning(
                "HLD score", f"refresh failed: {type(e).__name__}: {e}")
        finally:
            self._hld_refreshing = False

    # ── Cost estimator ────────────────────────────────────────────────────────
    def _open_herotel_boq(self):
        from qgis.PyQt import sip
        dialog = getattr(self, '_herotel_boq_dialog', None)
        if dialog is None or sip.isdeleted(dialog):
            try:
                from .herotel_boq_dialog import HeroTelBoqDialog
                dialog = HeroTelBoqDialog(self.iface.mainWindow())
                self._herotel_boq_dialog = dialog
            except ImportError as exc:
                self.iface.messageBar().pushWarning('HeroTel BOQ',
                    'BOQ could not load. Check that the complete plugin is synchronised and reload it. ' + str(exc))
                return
        dialog.show()
        dialog.raise_()
        dialog.activateWindow()

    def _open_build_herotel_layers(self):
        """VN 1 — ask where to save, build the 16 empty HeroTel standard layers, add them (D11)."""
        title = 'Build HeroTel Layers'
        try:
            from fibre_automation.herotel_layers import build as vn1_build
            from fibre_automation.herotel_layers import dialog as vn1_dialog
            from .network_planner.layer_names import role_of
        except ImportError as exc:
            self.iface.messageBar().pushWarning(title,
                'The layer builder could not load. Check that the complete plugin is synchronised and reload it. ' + str(exc))
            return
        parent = self.iface.mainWindow()
        ask_path, ask_crs, confirm_add = vn1_dialog.qt_prompts(parent)
        try:
            record = vn1_dialog.run_build_dialog(QgsProject.instance(), parent, ask_path, ask_crs, confirm_add,
                                                 role_of=role_of)
        except (vn1_build.BuildError, ValueError) as exc:
            self.iface.messageBar().pushCritical(title, str(exc))
            return
        outcome = record.get('outcome')
        if outcome == 'built':
            added = record.get('layers_added', 0)
            where = f"added {added} layers to this project" if added else "not added to this project"
            self.iface.messageBar().pushSuccess(title, f"Saved {record['path']} and {where}.")
        elif outcome == 'refused':
            self.iface.messageBar().pushWarning(title,
                f"Nothing was written: a file already exists at {record['path']}. Choose a new file name.")

    def _run_cost_estimator(self):
        """Open the transparent CAPEX / cost-per-home estimator."""
        try:
            from . import cost_estimator
        except ImportError:
            import cost_estimator
        cost_estimator.open_dialog(self.iface)

    # ── HLD client PDF ────────────────────────────────────────────────────────
    def _run_hld_pdf(self):
        """Generate the client HLD PDF. Gathers CHEAP data (featureCount + light
        scorecard — no heavy iteration), then builds the PDF in the venv
        subprocess (reportlab) so the QGIS UI never blocks."""
        import os
        import json
        import time
        import datetime
        import subprocess
        from qgis.core import QgsProject, QgsMapLayer
        from qgis.PyQt.QtWidgets import QFileDialog
        from qgis.PyQt.QtCore import Qt

        proj = QgsProject.instance()
        layers = list(proj.mapLayers().values())

        def count(*keys, mode='sum'):
            vals = [l.featureCount() for l in layers
                    if l.type() == QgsMapLayer.LayerType.VectorLayer
                    and any(k in l.name().lower() for k in keys)]
            if not vals:
                return 0
            return max(vals) if mode == 'max' else sum(vals)

        poles = count('pole')
        erven = count('erven', 'erf', mode='max')
        onts = count('ont', 'home connection', mode='max')
        splitters = count('splitter')
        pons = count('pon v1', 'pon zones', mode='max') or count(' pon', mode='max')
        zones = count('zone')
        stats = {'Poles': poles, 'Erven': erven, 'ONTs / homes': onts,
                 'Splitters': splitters, 'PONs': pons, 'Zones': zones}
        # lightweight, honest scorecard — presence/counts (instant), not the full audit
        audit = []
        for label, n in (('Poles', poles), ('Erven', erven), ('ONTs', onts),
                         ('Splitters', splitters)):
            audit.append((label, 'pass' if n > 0 else 'warn',
                          f'{n:,} features' if n > 0 else 'layer absent / empty'))
        try:
            from . import power_budget as pb
            audit.append(('Optical reach (Combo-1, C+)', 'pass',
                          f'max ~{pb.max_reach_km():.0f} km — design ONTs within this'))
        except Exception:
            _swallowed_note()

        data = {
            'project': proj.baseName() or 'project',
            'client': '', 'date': datetime.date.fromtimestamp(time.time()).isoformat(),
            'stats': stats,
            'capacity': {'onts': onts, 'pons': pons, 'zones': zones, 'fill': '80–102'},
            'audit': audit,
        }
        out, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 'Save HLD report',
            f'C:/Temp/HLD_{data["project"]}.pdf', 'PDF (*.pdf)')
        if not out:
            return
        djson = 'C:/Temp/hld_data.json'
        with open(djson, 'w', encoding='utf-8') as _f:
            json.dump(data, _f)

        try:
            from .fibre_automation.shared.vf_paths import python_exe
        except ImportError:
            from fibre_automation.shared.vf_paths import python_exe
        py = python_exe()
        runner = os.path.join(os.path.dirname(__file__), 'fibre_automation', 'hld_report_runner.py')

        from qgis.PyQt.QtWidgets import QApplication
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            r = subprocess.run([py, runner, djson, out], capture_output=True,
                               text=True, timeout=120)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            self.iface.messageBar().pushWarning('HLD Report', f'Build failed: {str(e)[:160]}')
            return
        QApplication.restoreOverrideCursor()
        if r.returncode == 0 and os.path.exists(out):
            self.iface.messageBar().pushSuccess('HLD Report', f'Client HLD PDF ready → {out}')
            try:
                os.startfile(out)   # open in the default PDF viewer
            except Exception:
                _swallowed_note()
        else:
            self.iface.messageBar().pushWarning(
                'HLD Report', f'Build failed: {(r.stderr or r.stdout or "")[:200]}')

    # ── Acceptance Scorecard (client-signable PDF) ────────────────────────────
    def _run_acceptance_scorecard(self):
        """Score the finished HLD against the Phase-2 spec and render a
        client-signable certificate. The score is built from the live layers
        (FREEZE-SAFE single pass via acceptance_scorecard); the PDF is rendered
        in the venv subprocess (reportlab) so the QGIS UI never blocks."""
        import os
        import json
        import time
        import datetime
        import subprocess
        from qgis.PyQt.QtWidgets import QFileDialog, QApplication
        from qgis.PyQt.QtCore import Qt

        try:
            from . import acceptance_scorecard as asc
        except ImportError:
            import acceptance_scorecard as asc
        try:
            data = asc.build_scorecard()
        except Exception as e:
            self.iface.messageBar().pushWarning(
                'Acceptance Scorecard', f'Could not score project: {str(e)[:160]}')
            return
        data['date'] = datetime.date.fromtimestamp(time.time()).isoformat()

        out, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 'Save acceptance certificate',
            f'C:/Temp/Acceptance_{data.get("project", "project")}.pdf', 'PDF (*.pdf)')
        if not out:
            return
        djson = 'C:/Temp/scorecard_data.json'
        with open(djson, 'w', encoding='utf-8') as _f:
            json.dump(data, _f)

        try:
            from .fibre_automation.shared.vf_paths import python_exe
        except ImportError:
            from fibre_automation.shared.vf_paths import python_exe
        py = python_exe()
        runner = os.path.join(os.path.dirname(__file__), 'acceptance_scorecard_pdf.py')

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            r = subprocess.run([py, runner, djson, out], capture_output=True,
                               text=True, timeout=120)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            self.iface.messageBar().pushWarning(
                'Acceptance Scorecard', f'Build failed: {str(e)[:160]}')
            return
        QApplication.restoreOverrideCursor()
        if r.returncode == 0 and os.path.exists(out):
            self.iface.messageBar().pushSuccess(
                'Acceptance Scorecard',
                f'{data.get("verdict", "?")} · {data.get("overall", "?")}/100 → {out}')
            try:
                os.startfile(out)
            except Exception:
                _swallowed_note()
        else:
            self.iface.messageBar().pushWarning(
                'Acceptance Scorecard',
                f'Build failed: {(r.stderr or r.stdout or "")[:200]}')

    # ── Pole schedule (field CSV) ─────────────────────────────────────────────
    def _run_pole_schedule(self):
        """Export a GPS pole schedule CSV for field crews. Bounded iteration
        (guarded against huge layers) + WGS84 lat/lon. Read-only on the data."""
        import csv
        from qgis.core import (QgsProject, QgsMapLayer, QgsWkbTypes,
                               QgsCoordinateTransform, QgsCoordinateReferenceSystem)
        from qgis.PyQt.QtWidgets import QFileDialog

        poles = None
        for l in QgsProject.instance().mapLayers().values():
            if (l.type() == QgsMapLayer.LayerType.VectorLayer
                    and l.geometryType() == QgsWkbTypes.GeometryType.PointGeometry
                    and 'pole' in l.name().lower()):
                poles = l
                break
        if poles is None:
            self.iface.messageBar().pushWarning('Pole Schedule', 'No Poles layer found.')
            return
        n = poles.featureCount()
        if n > 100000:
            self.iface.messageBar().pushWarning('Pole Schedule', f'{n:,} poles — too many to export safely.')
            return

        fields = [f.name() for f in poles.fields()]
        def pick(*cands):
            return next((f for f in fields if f.lower() in cands), None)
        f_lbl = pick('label', 'label_1', 'name')
        f_dim = pick('dim2', 'thickness', 'thickness_')
        f_typ = pick('type_1', 'type', 'spec_1')

        path, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 'Save pole schedule',
            f'C:/Temp/pole_schedule_{QgsProject.instance().baseName() or "project"}.csv',
            'CSV (*.csv)')
        if not path:
            return
        xform = QgsCoordinateTransform(poles.crs(),
                                       QgsCoordinateReferenceSystem('EPSG:4326'),
                                       QgsProject.instance())
        written = 0
        try:
            with open(path, 'w', newline='', encoding='utf-8') as fh:
                w = csv.writer(fh)
                w.writerow(['label', 'lat', 'lon', 'thickness', 'type'])
                for ft in poles.getFeatures():
                    g = ft.geometry()
                    if not g or g.isEmpty():
                        continue
                    p = g.centroid().asPoint()
                    p = xform.transform(p)
                    w.writerow([
                        ft[f_lbl] if f_lbl else '',
                        f'{p.y():.6f}', f'{p.x():.6f}',
                        ft[f_dim] if f_dim else '',
                        ft[f_typ] if f_typ else '',
                    ])
                    written += 1
        except Exception as e:
            self.iface.messageBar().pushWarning('Pole Schedule', f'Export failed: {str(e)[:160]}')
            return
        self.iface.messageBar().pushSuccess('Pole Schedule', f'Exported {written:,} poles → {path}')

    # ── shared export helpers ─────────────────────────────────────────────────
    @staticmethod
    def _default_export_path(ext):
        """Suggested save path: NEXT TO THE PROJECT, not C:/Temp.

        Exports belong with the .qgz the planner is working in — hunting for a KMZ
        that silently landed in C:/Temp wastes real time. Falls back to C:/Temp only
        for an unsaved project, which has no folder of its own yet.
        """
        import os
        from qgis.core import QgsProject
        proj = QgsProject.instance()
        base = proj.baseName() or "network"
        folder = proj.absolutePath() or ""       # "" while the project is unsaved
        if not folder or not os.path.isdir(folder):
            folder = "C:/Temp"
        return os.path.join(folder, f"{base}.{ext}").replace("\\", "/")

    # ── shared layer picker (used by the export buttons) ──────────────────────
    def _pick_layers(self, title, preselect='visible', parent=None, checked_ids=None):
        """Modal checklist of the project's vector layers → list[layer] | None.

        None means the operator cancelled — the caller must write nothing.
        Rows follow Layers-panel order so what you see here matches the panel.
        preselect='visible' pre-ticks the currently-ticked layers.
        checked_ids overrides preselect (used to re-open with the previous choice).
        parent: pass the calling dialog when opening from inside another modal.

        Reusable on purpose: Export KMZ and Export KML both use it; Export DXF and
        Export GeoPackage carry the same "visible layers" assumption and can adopt
        it with a one-line change.

        Qt6 notes: item data holds the layer ID (a string), never the layer object —
        a held C++ pointer can dangle. The dialog is WA_DeleteOnClose, so the ticks
        are captured in the accept handler, BEFORE exec() returns and the widgets die.
        """
        from qgis.core import QgsProject, QgsMapLayer
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                                         QListWidget, QListWidgetItem, QPushButton,
                                         QDialogButtonBox)

        root = QgsProject.instance().layerTreeRoot()
        nodes = [n for n in root.findLayers()
                 if n.layer() is not None
                 and n.layer().type() == QgsMapLayer.LayerType.VectorLayer]
        if not nodes:
            self.iface.messageBar().pushWarning(
                title, 'This project has no vector layers to export.')
            return None

        dlg = QDialog(parent or self.iface.mainWindow())
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        dlg.setWindowTitle(f'{title} — choose layers')
        dlg.setMinimumWidth(430)
        dlg.setStyleSheet(
            "QDialog { background:#1A1B26; }"
            "QLabel { color:#E6E8F0; font-family:'Segoe UI'; font-size:12px; }"
            "QListWidget { background:#11131F; color:#E6E8F0; border:1px solid #3A3D5C;"
            "  border-radius:6px; font-family:'Segoe UI'; font-size:12px; padding:3px; }"
            "QListWidget::item { padding:5px 6px; }"
            "QListWidget::item:hover { background:#24253A; }"
            "QPushButton { background:#24253A; color:#E6E8F0; border:1px solid #3A3D5C;"
            "  border-radius:5px; padding:5px 13px; font-family:'Segoe UI'; font-size:12px; }"
            "QPushButton:hover { background:#3A3D5C; }"
            "QPushButton:default { background:#6E56CF; border:1px solid #6E56CF; }"
        )
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(12, 12, 12, 12)
        lay.setSpacing(8)
        lay.addWidget(QLabel('Tick the layers to include:'))

        listw = QListWidget()
        listw.setMaximumHeight(340)
        for n in nodes:
            lyr = n.layer()
            try:
                cnt = lyr.featureCount()
            except Exception:
                cnt = -1
            cnt_txt = f'{cnt:,}' if cnt is not None and cnt >= 0 else '?'
            it = QListWidgetItem(f'{lyr.name()}   ({cnt_txt})')
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            if checked_ids is not None:
                on = lyr.id() in checked_ids
            else:
                on = n.isVisible() if preselect == 'visible' else True
            it.setCheckState(Qt.CheckState.Checked if on else Qt.CheckState.Unchecked)
            it.setData(Qt.ItemDataRole.UserRole, lyr.id())   # ID, not the layer object
            listw.addItem(it)
        lay.addWidget(listw)

        tally = QLabel('')
        lay.addWidget(tally)

        def _checked_items():
            return [listw.item(i) for i in range(listw.count())
                    if listw.item(i).checkState() == Qt.CheckState.Checked]

        def _retally(*_):
            sel = _checked_items()
            feats = 0
            for it_ in sel:
                lyr_ = QgsProject.instance().mapLayer(it_.data(Qt.ItemDataRole.UserRole))
                if lyr_ is not None:
                    try:
                        c = lyr_.featureCount()
                        if c and c > 0:
                            feats += c
                    except Exception:
                        _swallowed_note()
            tally.setText(f'{len(sel)} of {listw.count()} layers · ~{feats:,} features')
            ok_btn = box.button(QDialogButtonBox.StandardButton.Ok)
            if ok_btn is not None:
                ok_btn.setEnabled(bool(sel))

        def _set_all(state):
            for i in range(listw.count()):
                listw.item(i).setCheckState(state)

        row = QHBoxLayout()
        b_all = QPushButton('All')
        b_none = QPushButton('None')
        b_vis = QPushButton('Visible')
        b_all.clicked.connect(lambda: _set_all(Qt.CheckState.Checked))
        b_none.clicked.connect(lambda: _set_all(Qt.CheckState.Unchecked))

        def _reset_visible():
            for i in range(listw.count()):
                it_ = listw.item(i)
                vis = nodes[i].isVisible()
                it_.setCheckState(Qt.CheckState.Checked if vis else Qt.CheckState.Unchecked)
        b_vis.clicked.connect(_reset_visible)
        for b in (b_all, b_none, b_vis):
            row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)

        box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                               | QDialogButtonBox.StandardButton.Cancel)
        ok = box.button(QDialogButtonBox.StandardButton.Ok)
        ok.setText('Export')
        ok.setDefault(True)
        box.rejected.connect(dlg.reject)
        lay.addWidget(box)

        listw.itemChanged.connect(_retally)
        _retally()

        # Capture BEFORE exec() returns — WA_DeleteOnClose destroys the widgets on accept.
        picked = {}

        def _capture():
            picked['ids'] = [it_.data(Qt.ItemDataRole.UserRole) for it_ in _checked_items()]
            dlg.accept()
        box.accepted.connect(_capture)

        try:
            from .nexus_dock import chrome_dialog
            chrome_dialog(dlg)
        except Exception:
            _swallowed_note()
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return None
        ids = picked.get('ids') or []
        # Resolve IDs -> layers now; skip anything removed while the dialog was open.
        layers = [QgsProject.instance().mapLayer(i) for i in ids]
        return [lyr for lyr in layers if lyr is not None] or None

    # ── KMZ layer + label-field picker ────────────────────────────────────────
    def _pick_layers_kmz(self, title='Export KMZ'):
        """Like _pick_layers, but adds a per-layer 'Label' chooser so the operator
        decides which attribute field shows as each feature's name in Google Earth.

        Returns (layers, name_fields) where name_fields = {layer_id: choice}; choice
        is a field name, '' (no label) or '__auto__' (the smart auto-pick). Returns
        (None, None) if cancelled or nothing ticked.

        Qt6-safe: widgets hold the layer ID (never the C++ object); ticks AND combo
        choices are captured in the accept handler BEFORE exec() returns and the
        WA_DeleteOnClose widgets die (the past dangling-widget bug)."""
        from qgis.core import QgsProject, QgsMapLayer
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                                         QTableWidget, QTableWidgetItem, QComboBox,
                                         QPushButton, QDialogButtonBox, QHeaderView)

        root = QgsProject.instance().layerTreeRoot()
        nodes = [n for n in root.findLayers()
                 if n.layer() is not None
                 and n.layer().type() == QgsMapLayer.LayerType.VectorLayer]
        if not nodes:
            self.iface.messageBar().pushWarning(
                title, 'This project has no vector layers to export.')
            return None, None

        # auto-pick helper (shows the operator which field "Auto" will use)
        try:
            from .fibre_automation.kmz_export import _name_field as _auto_name
        except ImportError:
            try:
                from fibre_automation.kmz_export import _name_field as _auto_name
            except Exception:
                _auto_name = lambda _l: None
        except Exception:
            _auto_name = lambda _l: None

        dlg = QDialog(self.iface.mainWindow())
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        dlg.setWindowTitle(f'{title} — choose layers & labels')
        dlg.setMinimumWidth(520)
        dlg.setStyleSheet(
            "QDialog { background:#1A1B26; }"
            "QLabel { color:#E6E8F0; font-family:'Segoe UI'; font-size:12px; }"
            "QTableWidget { background:#11131F; color:#E6E8F0; border:1px solid #3A3D5C;"
            "  border-radius:6px; font-family:'Segoe UI'; font-size:12px;"
            "  gridline-color:#24253A; }"
            "QTableWidget::item { padding:4px 6px; }"
            "QHeaderView::section { background:#24253A; color:#B7BCE0; border:none;"
            "  padding:5px 6px; font-family:'Segoe UI'; font-size:11px; }"
            "QComboBox { background:#181A28; color:#E6E8F0; border:1px solid #3A3D5C;"
            "  border-radius:4px; padding:2px 6px; font-family:'Segoe UI'; font-size:12px; }"
            "QComboBox QAbstractItemView { background:#11131F; color:#E6E8F0;"
            "  selection-background-color:#3A3D5C; }"
            "QPushButton { background:#24253A; color:#E6E8F0; border:1px solid #3A3D5C;"
            "  border-radius:5px; padding:5px 13px; font-family:'Segoe UI'; font-size:12px; }"
            "QPushButton:hover { background:#3A3D5C; }"
            "QPushButton:default { background:#6E56CF; border:1px solid #6E56CF; }"
        )
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(12, 12, 12, 12)
        lay.setSpacing(8)
        lay.addWidget(QLabel('Tick the layers to include, and pick the field to '
                             'label each with in Google Earth:'))

        tbl = QTableWidget(len(nodes), 2)
        tbl.setHorizontalHeaderLabels(['Layer', 'Label field'])
        tbl.verticalHeader().setVisible(False)
        tbl.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
        tbl.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        tbl.setMaximumHeight(360)
        hdr = tbl.horizontalHeader()
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        hdr.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        tbl.setColumnWidth(1, 190)

        combos = {}          # row -> QComboBox
        for r, n in enumerate(nodes):
            lyr = n.layer()
            try:
                cnt = lyr.featureCount()
            except Exception:
                cnt = -1
            cnt_txt = f'{cnt:,}' if cnt is not None and cnt >= 0 else '?'
            it = QTableWidgetItem(f'{lyr.name()}   ({cnt_txt})')
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(Qt.CheckState.Checked if n.isVisible()
                             else Qt.CheckState.Unchecked)
            it.setData(Qt.ItemDataRole.UserRole, lyr.id())
            tbl.setItem(r, 0, it)

            cb = QComboBox()
            try:
                auto = _auto_name(lyr)
            except Exception:
                auto = None
            cb.addItem(f'🔤 Auto ({auto})' if auto else '🔤 Auto', '__auto__')
            cb.addItem('— None (no label)', '')
            try:
                for f in lyr.fields():
                    cb.addItem(f.name(), f.name())
            except Exception:
                _swallowed_note()
            cb.setCurrentIndex(0)           # default = Auto
            combos[r] = cb
            tbl.setCellWidget(r, 1, cb)
        lay.addWidget(tbl)

        tally = QLabel('')
        lay.addWidget(tally)

        def _checked_rows():
            return [r for r in range(tbl.rowCount())
                    if tbl.item(r, 0).checkState() == Qt.CheckState.Checked]

        def _retally(*_):
            rows = _checked_rows()
            feats = 0
            for r in rows:
                lyr_ = QgsProject.instance().mapLayer(
                    tbl.item(r, 0).data(Qt.ItemDataRole.UserRole))
                if lyr_ is not None:
                    try:
                        c = lyr_.featureCount()
                        if c and c > 0:
                            feats += c
                    except Exception:
                        _swallowed_note()
            tally.setText(f'{len(rows)} of {tbl.rowCount()} layers · ~{feats:,} features')
            ok_btn = box.button(QDialogButtonBox.StandardButton.Ok)
            if ok_btn is not None:
                ok_btn.setEnabled(bool(rows))

        def _set_all(state):
            for r in range(tbl.rowCount()):
                tbl.item(r, 0).setCheckState(state)

        def _reset_visible():
            for r in range(tbl.rowCount()):
                vis = nodes[r].isVisible()
                tbl.item(r, 0).setCheckState(
                    Qt.CheckState.Checked if vis else Qt.CheckState.Unchecked)

        row = QHBoxLayout()
        b_all, b_none, b_vis = QPushButton('All'), QPushButton('None'), QPushButton('Visible')
        b_all.clicked.connect(lambda: _set_all(Qt.CheckState.Checked))
        b_none.clicked.connect(lambda: _set_all(Qt.CheckState.Unchecked))
        b_vis.clicked.connect(_reset_visible)
        for b in (b_all, b_none, b_vis):
            row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)

        box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                               | QDialogButtonBox.StandardButton.Cancel)
        ok = box.button(QDialogButtonBox.StandardButton.Ok)
        ok.setText('Export')
        ok.setDefault(True)
        box.rejected.connect(dlg.reject)
        lay.addWidget(box)

        tbl.itemChanged.connect(_retally)
        _retally()

        picked = {}

        def _capture():
            ids, nfields = [], {}
            for r in _checked_rows():
                lid = tbl.item(r, 0).data(Qt.ItemDataRole.UserRole)
                ids.append(lid)
                cb = combos.get(r)
                choice = cb.currentData() if cb is not None else '__auto__'
                if choice != '__auto__':           # only record real overrides
                    nfields[lid] = choice
            picked['ids'] = ids
            picked['name_fields'] = nfields
            dlg.accept()
        box.accepted.connect(_capture)

        try:
            from .nexus_dock import chrome_dialog
            chrome_dialog(dlg)
        except Exception:
            _swallowed_note()
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return None, None
        ids = picked.get('ids') or []
        layers = [QgsProject.instance().mapLayer(i) for i in ids]
        layers = [lyr for lyr in layers if lyr is not None]
        if not layers:
            return None, None
        return layers, (picked.get('name_fields') or {})

    # ── KMZ export (Google Earth / field) ─────────────────────────────────────
    def _export_kmz(self):
        """Export chosen vector layers to a KMZ for Google Earth / field phones.

        The operator picks the layers (pre-ticked to whatever is visible) AND, per
        layer, which attribute field shows as the on-map label in Google Earth
        (default = smart auto-pick); every attribute-table field still rides along in
        each Placemark's <ExtendedData>, so a field tech can tap a feature and read
        its full row. Zero-dependency (KML XML + zip); read-only on the data."""
        from qgis.PyQt.QtWidgets import QFileDialog, QApplication
        from qgis.PyQt.QtCore import Qt

        # Ask BEFORE the save dialog, so you never name a file then cancel.
        layers, name_fields = self._pick_layers_kmz('Export KMZ')
        if not layers:
            return          # cancelled, or nothing ticked — write nothing
        path, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 'Export network to KMZ',
            self._default_export_path('kmz'),
            'Google Earth KMZ (*.kmz)')
        if not path:
            return
        try:
            from .fibre_automation.kmz_export import build_kmz
        except ImportError:
            from fibre_automation.kmz_export import build_kmz
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            res = build_kmz(layers, path, name_fields=name_fields)
        except Exception as e:
            self.iface.messageBar().pushWarning('Export KMZ', f'Export failed: {str(e)[:160]}')
            return
        finally:
            QApplication.restoreOverrideCursor()
        opened = self._open_in_google_earth(res["path"])   # parity with Export KML
        tail = ' — opening in Google Earth…' if opened else ''
        self.iface.messageBar().pushSuccess(
            'Export KMZ',
            f'Exported {res["features"]:,} features from {res["layers"]} layers '
            f'→ {res["path"]}{tail}')

    # ── DXF export (contractor CAD) ───────────────────────────────────────────
    def _export_dxf(self):
        """Export the VISIBLE vector layers to a DXF CAD drawing (native QgsDxfExport,
        zero deps). Read-only on the data; exports in the data's own metric CRS."""
        from qgis.PyQt.QtWidgets import QFileDialog, QApplication
        from qgis.PyQt.QtCore import Qt

        # Ask BEFORE the save dialog, so you never name a file then cancel.
        layers = self._pick_layers('Export DXF')
        if not layers:
            return          # cancelled, or nothing ticked — write nothing
        path, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 'Export network to DXF',
            self._default_export_path('dxf'),
            'CAD DXF (*.dxf)')
        if not path:
            return
        try:
            from .fibre_automation.dxf_export import build_dxf
        except ImportError:
            from fibre_automation.dxf_export import build_dxf
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            res = build_dxf(layers, path)
        except Exception as e:
            self.iface.messageBar().pushWarning('Export DXF', f'Export failed: {str(e)[:160]}')
            return
        finally:
            QApplication.restoreOverrideCursor()
        if res.get('ok'):
            self.iface.messageBar().pushSuccess(
                'Export DXF',
                f'Exported {res["layers"]} layers ({res.get("crs") or "CRS"}) → {res["path"]}')
        else:
            self.iface.messageBar().pushWarning(
                'Export DXF', f'Export did not complete: {res.get("msg") or res.get("result")}')

    # ── Styled GeoPackage export (one file, pre-styled) ───────────────────────
    def _export_styled_gpkg(self):
        """Package chosen vector layers into ONE GeoPackage with styles + metadata
        embedded (native:package). Read-only on the project."""
        import processing
        from qgis.PyQt.QtWidgets import QFileDialog, QApplication
        from qgis.PyQt.QtCore import Qt

        # Ask BEFORE the save dialog, so you never name a file then cancel.
        layers = self._pick_layers('Export GeoPackage')
        if not layers:
            return          # cancelled, or nothing ticked — write nothing
        path, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 'Export styled GeoPackage',
            self._default_export_path('gpkg'),
            'GeoPackage (*.gpkg)')
        if not path:
            return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            processing.run('native:package', {
                'LAYERS': layers, 'OUTPUT': path, 'OVERWRITE': True,
                'SAVE_STYLES': True, 'SAVE_METADATA': True,
                'SELECTED_FEATURES_ONLY': False})
        except Exception as e:
            self.iface.messageBar().pushWarning('Export GeoPackage', f'Export failed: {str(e)[:160]}')
            return
        finally:
            QApplication.restoreOverrideCursor()
        self.iface.messageBar().pushSuccess(
            'Export GeoPackage', f'Packaged {len(layers)} styled layers → {path}')

    # ── KML export (client-spec, Google Earth) ────────────────────────────────
    def _export_kml(self):
        """Export a GeoPackage (or the open project) to a client-spec KML: correct
        per-client symbology (Fibertime HLD / Vuma / HeroTel), status-based pole/ONT/
        home colours, grouped folders, a clean info-balloon + every attribute in
        ExtendedData. Zero-dependency; read-only on the data."""
        import os
        from qgis.core import QgsProject, QgsMapLayer
        from qgis.PyQt.QtWidgets import (
            QVBoxLayout, QHBoxLayout, QRadioButton, QLineEdit, QPushButton,
            QComboBox, QLabel, QDialogButtonBox, QButtonGroup, QFileDialog, QApplication)
        from qgis.PyQt.QtCore import Qt

        dlg = QDialog(self.iface.mainWindow())
        dlg.setWindowTitle("Export KML")
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        dlg.setMinimumWidth(470)
        lay = QVBoxLayout(dlg)

        lay.addWidget(QLabel("<b>Source</b>"))
        rb_project = QRadioButton("Current project")
        rb_project.setChecked(True)
        rb_gpkg = QRadioButton("GeoPackage file:")
        grp = QButtonGroup(dlg)
        grp.addButton(rb_project)
        grp.addButton(rb_gpkg)
        lay.addWidget(rb_project)

        # Layer choice for the project source. Defaults to the visible layers — the
        # long-standing behaviour — so this changes nothing unless you use it.
        chosen = {"ids": None}          # None = "whatever is visible at export time"

        def _visible_layers():
            root_ = QgsProject.instance().layerTreeRoot()
            return [n.layer() for n in root_.findLayers()
                    if n.isVisible() and n.layer() is not None
                    and n.layer().type() == QgsMapLayer.LayerType.VectorLayer]

        lyr_row = QHBoxLayout()
        lyr_row.addSpacing(20)
        lyr_lbl = QLabel("")
        btn_layers = QPushButton("Choose layers…")

        def _refresh_lyr_lbl():
            if chosen["ids"] is None:
                lyr_lbl.setText(f"<i>visible layers ({len(_visible_layers())})</i>")
            else:
                lyr_lbl.setText(f"<b>{len(chosen['ids'])} layer(s) chosen</b>")

        def _choose_layers():
            picked = self._pick_layers('Export KML', parent=dlg,
                                       checked_ids=chosen["ids"])
            if picked:                  # None/empty = cancelled -> keep previous
                chosen["ids"] = [lyr.id() for lyr in picked]
                rb_project.setChecked(True)
                _refresh_lyr_lbl()

        btn_layers.clicked.connect(_choose_layers)
        lyr_row.addWidget(btn_layers)
        lyr_row.addWidget(lyr_lbl, 1)
        lay.addLayout(lyr_row)
        _refresh_lyr_lbl()

        row1 = QHBoxLayout()
        gpkg_edit = QLineEdit()
        gpkg_edit.setEnabled(False)
        btn_gpkg = QPushButton("Browse…")
        row1.addWidget(rb_gpkg)
        row1.addWidget(gpkg_edit, 1)
        row1.addWidget(btn_gpkg)
        lay.addLayout(row1)

        lay.addWidget(QLabel("<b>Client spec</b>"))
        client_combo = QComboBox()
        client_combo.addItem("Auto-detect", None)
        client_combo.addItem("fibertime", "fibertime")
        client_combo.addItem("Vuma", "vuma")
        client_combo.addItem("HeroTel", "herotel")
        lay.addWidget(client_combo)

        lay.addWidget(QLabel("<b>Output KML</b>"))
        row2 = QHBoxLayout()
        out_edit = QLineEdit(self._default_export_path('kml'))
        btn_out = QPushButton("Browse…")
        row2.addWidget(out_edit, 1)
        row2.addWidget(btn_out)
        lay.addLayout(row2)

        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                              | QDialogButtonBox.StandardButton.Cancel)
        bb.button(QDialogButtonBox.StandardButton.Ok).setText("Export KML")
        lay.addWidget(bb)

        def _pick_gpkg():
            p, _ = QFileDialog.getOpenFileName(
                dlg, "Select GeoPackage", "C:/Temp", "GeoPackage (*.gpkg)")
            if p:
                gpkg_edit.setText(p)
                rb_gpkg.setChecked(True)
                out_edit.setText(os.path.splitext(p)[0] + ".kml")

        def _pick_out():
            p, _ = QFileDialog.getSaveFileName(
                dlg, "Save KML as", out_edit.text() or "C:/Temp/network.kml", "KML (*.kml)")
            if p:
                out_edit.setText(p)

        btn_gpkg.clicked.connect(_pick_gpkg)
        btn_out.clicked.connect(_pick_out)
        rb_gpkg.toggled.connect(gpkg_edit.setEnabled)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)

        # Capture widget values WHILE the dialog is still alive (WA_DeleteOnClose).
        captured = {}

        def _capture():
            captured["use_gpkg"] = rb_gpkg.isChecked()
            captured["gpkg"] = gpkg_edit.text().strip()
            captured["client"] = client_combo.currentData()
            captured["out"] = out_edit.text().strip()
            captured["layer_ids"] = chosen["ids"]
        dlg.accepted.connect(_capture)

        try:
            from .nexus_dock import chrome_dialog
            chrome_dialog(dlg)
        except Exception:
            _swallowed_note()
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        out = captured.get("out")
        if not out:
            self.iface.messageBar().pushWarning('Export KML', 'No output path chosen.')
            return
        client = captured.get("client")
        try:
            from .fibre_automation.kml_export import build_kml, build_kml_from_gpkg
        except ImportError:
            from fibre_automation.kml_export import build_kml, build_kml_from_gpkg

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            if captured.get("use_gpkg"):
                gpkg = captured.get("gpkg")
                if not gpkg or not os.path.exists(gpkg):
                    raise RuntimeError("Pick an existing GeoPackage file.")
                res = build_kml_from_gpkg(gpkg, out, client=client)
            else:
                ids = captured.get("layer_ids")
                if ids:                      # explicit choice from "Choose layers…"
                    proj = QgsProject.instance()
                    layers = [proj.mapLayer(i) for i in ids]
                    layers = [lyr for lyr in layers if lyr is not None]
                    if not layers:
                        raise RuntimeError(
                            "The chosen layers are no longer in the project.")
                else:                        # unchanged default: visible layers
                    layers = _visible_layers()
                    if not layers:
                        raise RuntimeError(
                            "No visible vector layers — tick layers in the Layers panel, "
                            "or use “Choose layers…”.")
                # Fingerprint the client off the WHOLE project, not just the chosen
                # layers — otherwise ticking a subset could flip the detected client
                # and silently change the symbology.
                res = build_kml(layers, out, client=client,
                                detect_names=[lyr.name() for lyr
                                              in QgsProject.instance().mapLayers().values()])
        except Exception as e:
            self.iface.messageBar().pushWarning('Export KML', f'Export failed: {str(e)[:160]}')
            return
        finally:
            QApplication.restoreOverrideCursor()
        opened = self._open_in_google_earth(res["path"])
        tail = ' — opening in Google Earth…' if opened else ''
        self.iface.messageBar().pushSuccess(
            'Export KML',
            f'Exported {res["features"]:,} features from {res["layers"]} layers '
            f'({res["client"]}) → {res["path"]}{tail}')

    @staticmethod
    def _open_in_google_earth(path):
        """Best-effort: launch an exported KML *or KMZ* in Google Earth Pro (Windows).
        Tries the GE Pro exe directly, then the file's default handler. NEVER raises —
        a missing Earth must not fail an export that already wrote its file."""
        import os
        import subprocess
        for exe in (r"C:\Program Files\Google\Google Earth Pro\client\googleearth.exe",
                    r"C:\Program Files (x86)\Google\Google Earth Pro\client\googleearth.exe"):
            if os.path.exists(exe):
                try:
                    subprocess.Popen([exe, path])
                    return True
                except Exception:
                    break
        try:
            os.startfile(path)  # .kml is associated with Google Earth on team machines
            return True
        except Exception:
            return False

    # ── Project backup (zip all file-based layers) ────────────────────────────
    def _backup_project(self):
        """One-click zip backup of every file-based layer + the project file. Read-only."""
        import os
        from datetime import datetime
        from qgis.core import QgsProject
        from qgis.PyQt.QtWidgets import QFileDialog, QApplication
        from qgis.PyQt.QtCore import Qt
        try:
            from .fibre_automation.project_backup import backup_project
        except ImportError:
            from fibre_automation.project_backup import backup_project

        proj = QgsProject.instance()
        base = proj.baseName() or 'project'
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        default_dir = (os.path.join(os.path.dirname(proj.fileName()), 'Backups')
                       if proj.fileName() else 'C:/Temp')
        try:
            os.makedirs(default_dir, exist_ok=True)
        except Exception:
            default_dir = 'C:/Temp'
        path, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 'Back up project layers',
            os.path.join(default_dir, f'{base}_{stamp}.zip'), 'Zip archive (*.zip)')
        if not path:
            return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            res = backup_project(proj, path)
        except Exception as e:
            self.iface.messageBar().pushWarning('Backup', f'Backup failed: {str(e)[:160]}')
            return
        finally:
            QApplication.restoreOverrideCursor()
        if res.get('ok'):
            mb = res['bytes'] / (1024 * 1024)
            self.iface.messageBar().pushSuccess(
                'Backup', f'Backed up {res["files"]} files ({mb:.1f} MB) → {res["path"]}')
        else:
            self.iface.messageBar().pushWarning('Backup', res.get('msg') or 'nothing to back up')

    # ── QA report (shareable HTML) ────────────────────────────────────────────
    def _open_project_audit(self):
        """DEV only — run the deep project auditor (research/project_deep_audit.py),
        open the HTML report, and inject the interactive zoom-to-issue panel. The
        engine + panel live in the dev-only research/ folder, so this button is
        gated to dev mode (teammates never see it)."""
        import os
        from qgis.PyQt.QtCore import QUrl
        from qgis.PyQt.QtGui import QDesktopServices
        rd = r"C:/Users/jjsch/OneDrive - blitzfibre.com/Documents/Workspace/QGIS/research"
        engine = os.path.join(rd, 'project_deep_audit.py')
        panel = os.path.join(rd, 'audit_panel.py')
        report = r'C:/Temp/project_audit_report.html'
        bar = self.iface.messageBar()
        try:
            if os.path.exists(engine):
                bar.pushInfo('Project Audit', 'Scanning every layer/cell/geometry…')
                self.iface.mainWindow().repaint()
                exec(compile(open(engine, encoding='utf-8').read(), engine, 'exec'), {})
        except Exception as e:
            bar.pushWarning('Project Audit', f'Audit engine error: {e}')
        if os.path.exists(report):
            QDesktopServices.openUrl(QUrl.fromLocalFile(report))
        else:
            bar.pushWarning('Project Audit', 'No report produced — is research/project_deep_audit.py present?')
        try:
            if os.path.exists(panel):
                exec(compile(open(panel, encoding='utf-8').read(), panel, 'exec'), {})
        except Exception as e:
            bar.pushWarning('Project Audit', f'Panel error: {e}')

    def _export_qa_report(self):
        """Run the integrity QA and write a shareable HTML report. Read-only."""
        import webbrowser
        from datetime import datetime
        from qgis.core import QgsProject
        from qgis.PyQt.QtWidgets import QFileDialog, QApplication
        from qgis.PyQt.QtCore import Qt
        try:
            from .fibre_automation.topology_qa import run_qa
            from .fibre_automation.qa_report import render_html
        except ImportError:
            from fibre_automation.topology_qa import run_qa
            from fibre_automation.qa_report import render_html

        proj = QgsProject.instance()
        base = proj.baseName() or 'project'
        path, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(), 'Export QA report',
            f'C:/Temp/QA_report_{base}.html', 'HTML report (*.html)')
        if not path:
            return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            issues = run_qa(proj)
            doc = render_html(issues, base, datetime.now().strftime('%Y-%m-%d %H:%M'))
            with open(path, 'w', encoding='utf-8') as fh:
                fh.write(doc)
        except Exception as e:
            self.iface.messageBar().pushWarning('QA Report', f'Failed: {str(e)[:160]}')
            return
        finally:
            QApplication.restoreOverrideCursor()
        try:
            webbrowser.open('file:///' + path.replace('\\', '/'))
        except Exception:
            _swallowed_note()
        errs = sum(1 for i in issues if i['severity'] == 'ERROR')
        self.iface.messageBar().pushSuccess(
            'QA Report', f'Saved QA report — {len(issues)} issue(s), {errs} error(s) → {path}')

    # ── Topology & Integrity QA ───────────────────────────────────────────────
    def _run_topology_qa(self):
        """Comprehensive, dependency-free data-integrity / topology QA. Read-only.
        Builds a 'QA Issues' point layer (coloured by severity) + a console summary,
        and zooms to the first ERROR."""
        from collections import Counter
        from qgis.core import (QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry,
                               QgsPointXY, QgsField)
        from qgis.PyQt.QtCore import QMetaType, Qt
        from qgis.PyQt.QtWidgets import QApplication
        try:
            from .fibre_automation.topology_qa import run_qa
        except ImportError:
            from fibre_automation.topology_qa import run_qa

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            issues = run_qa(QgsProject.instance())
        except Exception as e:
            self.iface.messageBar().pushWarning('Topology QA', f'QA failed: {str(e)[:160]}')
            return
        finally:
            QApplication.restoreOverrideCursor()

        errors = [i for i in issues if i['severity'] == 'ERROR']
        warns = [i for i in issues if i['severity'] == 'WARN']

        crs = QgsProject.instance().crs().authid() or 'EPSG:4326'
        vl = QgsVectorLayer(f'Point?crs={crs}', 'QA Issues', 'memory')
        dp = vl.dataProvider()
        dp.addAttributes([QgsField('severity', QMetaType.Type.QString),
                          QgsField('check', QMetaType.Type.QString),
                          QgsField('layer', QMetaType.Type.QString),
                          QgsField('fid', QMetaType.Type.Int),
                          QgsField('desc', QMetaType.Type.QString)])
        vl.updateFields()
        feats = []
        for i in issues:
            f = QgsFeature(vl.fields())
            f.setAttributes([i['severity'], i['check'], i['layer'], int(i['fid']), i['desc']])
            if i['x'] or i['y']:
                f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(i['x'], i['y'])))
            feats.append(f)
        dp.addFeatures(feats)
        vl.updateExtents()
        # colour by severity so problems pop on the canvas: red ERROR, amber WARN
        try:
            from qgis.core import (QgsCategorizedSymbolRenderer, QgsRendererCategory,
                                   QgsMarkerSymbol)
            cats = [
                QgsRendererCategory('ERROR', QgsMarkerSymbol.createSimple(
                    {'name': 'circle', 'color': '#E11D48', 'size': '3.4',
                     'outline_color': '#FFFFFF', 'outline_width': '0.4'}), 'ERROR'),
                QgsRendererCategory('WARN', QgsMarkerSymbol.createSimple(
                    {'name': 'triangle', 'color': '#F59E0B', 'size': '3.2',
                     'outline_color': '#FFFFFF', 'outline_width': '0.4'}), 'WARN'),
            ]
            vl.setRenderer(QgsCategorizedSymbolRenderer('severity', cats))
        except Exception:
            _swallowed_note()
        for old in QgsProject.instance().mapLayersByName('QA Issues'):
            QgsProject.instance().removeMapLayer(old.id())

        print(f'[FiberNet] Topology QA: {len(errors)} ERROR / {len(warns)} WARN')
        for sev, lst in (('ERROR', errors), ('WARN', warns)):
            for chk, n in Counter(i['check'] for i in lst).most_common():
                print(f'   {sev} {chk}: {n}')

        if not issues:
            self.iface.messageBar().pushSuccess(
                'Topology QA', 'No issues found — network passes data-integrity QA. ✓')
            return

        QgsProject.instance().addMapLayer(vl)
        target = errors[0] if errors else warns[0]
        if target['x'] or target['y']:
            try:
                self.iface.mapCanvas().setCenter(QgsPointXY(target['x'], target['y']))
                self.iface.mapCanvas().refresh()
            except Exception:
                _swallowed_note()
        push = self.iface.messageBar().pushWarning if errors else self.iface.messageBar().pushInfo
        push('Topology QA',
             f'{len(errors)} error(s), {len(warns)} warning(s) — see the "QA Issues" layer '
             f'+ Python console for the breakdown.')

    # ── FT pipeline pre-flight check ──────────────────────────────────────────
    def _run_preflight_check(self):
        """Verify the FT6/FT7 prerequisites BEFORE the operator runs the pipeline,
        so the two silent-failure traps (missing PON feeder order, stale roads)
        surface up front. Cheap: file stats + featureCount only."""
        import os
        import time
        from qgis.core import QgsProject

        checks = []   # (ok, label, detail)

        # FT6 — pon_feeder_order.txt (64 or 66 entries)
        order = None
        for cand in (os.path.join(os.path.dirname(os.path.dirname(__file__)), 'pon_feeder_order.txt'),
                     'C:/Temp/pon_feeder_order.txt'):
            if os.path.exists(cand):
                order = cand
                break
        try:
            from .fibre_automation.shared.vf_paths import data_file
            if data_file and os.path.exists(data_file('pon_feeder_order.txt')):
                order = data_file('pon_feeder_order.txt')
        except Exception:
            _swallowed_note()
        if order:
            try:
                with open(order) as _f:
                    n = sum(1 for ln in _f if ln.strip())
            except Exception:
                n = 0
            ok = n in (64, 66)
            checks.append((ok, 'FT6 PON feeder order',
                           f'{n} entries' + ('' if ok else ' — expected 64 or 66; re-record')))
        else:
            checks.append((False, 'FT6 PON feeder order',
                           'pon_feeder_order.txt NOT found — record it (🔴 Record PON Order) before FT6'))

        # FT7 — roads.json present + fresh
        roads = None
        for cand in ('C:/Temp/roads.json',):
            if os.path.exists(cand):
                roads = cand
        try:
            from .fibre_automation.shared.vf_paths import roads_json
            if roads_json and os.path.exists(roads_json()):
                roads = roads_json()
        except Exception:
            _swallowed_note()
        if roads:
            age_d = (time.time() - os.path.getmtime(roads)) / 86400.0
            ok = age_d < 30
            checks.append((ok, 'FT7 roads.json',
                           f'{age_d:.0f} days old' + ('' if ok else ' — stale; run /roads to refresh')))
        else:
            checks.append((False, 'FT7 roads.json', 'NOT found — run /roads before FT7'))

        # key layers present
        proj = QgsProject.instance()
        for name_keys in (('Poles', ('pole',)), ('PON', ('pon',)), ('Cables', ('cable', 'feeder'))):
            label, keys = name_keys
            present = any(any(k in l.name().lower() for k in keys)
                          for l in proj.mapLayers().values())
            checks.append((present, f'Layer: {label}', 'present' if present else 'missing'))

        passed = sum(1 for ok, _, _ in checks if ok)
        lines = '  '.join(f'{"✓" if ok else "✗"} {lbl}' for ok, lbl, _ in checks)
        print('[FiberNet] Pre-flight:')
        for ok, lbl, detail in checks:
            print(f'   {"✓" if ok else "✗"} {lbl}: {detail}')
        msg = f'Pre-flight {passed}/{len(checks)} OK — {lines}'
        if passed == len(checks):
            self.iface.messageBar().pushSuccess('FT Pre-Flight', 'All prerequisites OK — safe to run the FT pipeline.')
        else:
            self.iface.messageBar().pushWarning('FT Pre-Flight', msg + '  (see Python console for details)')

    # ── Zone & PON capacity report ────────────────────────────────────────────
    def _run_capacity_report(self):
        """Per-PON fill + per-zone rollup from the ONT layer. Flags over-capacity
        (>128) and under-utilised (<80) PONs against the Velocity target band.
        Degrades gracefully if no ONT layer / pon field is present."""
        from qgis.core import QgsProject, QgsMapLayer, QgsFeatureRequest
        from collections import Counter

        ont = None
        for l in QgsProject.instance().mapLayers().values():
            if l.type() != QgsMapLayer.LayerType.VectorLayer:
                continue
            nm = l.name().lower()
            if any(k in nm for k in ('ont', 'home connection', 'home_conn')) \
                    and l.featureCount() > 0:
                ont = l
                break
        if ont is None:
            self.iface.messageBar().pushWarning(
                'Capacity', 'No ONT / Home-Connection layer found.')
            return

        fields = [f.name() for f in ont.fields()]
        pon_f = next((f for f in fields if f.lower() in ('pon_no', 'pon')), None)
        if pon_f is None:
            self.iface.messageBar().pushWarning(
                'Capacity', f'ONT layer "{ont.name()}" has no pon_no field — run FT5/FT6 first.')
            return

        per_pon = Counter()
        unassigned = 0
        for f in ont.getFeatures(QgsFeatureRequest().setSubsetOfAttributes([pon_f], ont.fields())):
            v = f[pon_f]
            if v in (None, '') or str(v).lower() == 'null':
                unassigned += 1
                continue
            try:
                per_pon[int(float(v))] += 1
            except (ValueError, TypeError):
                unassigned += 1

        if not per_pon:
            self.iface.messageBar().pushWarning(
                'Capacity', f'No ONTs carry a PON number yet ({unassigned} unassigned).')
            return

        TARGET_LO, TARGET_HI, HARD_MAX = 80, 102, 128
        fills = list(per_pon.values())
        over = sorted((p for p, c in per_pon.items() if c > HARD_MAX))
        under = sorted((p for p, c in per_pon.items() if c < TARGET_LO))
        above = sorted((p for p, c in per_pon.items() if TARGET_HI < c <= HARD_MAX))
        zones = {(p - 235) // 16 + 17 for p in per_pon}
        total = sum(fills)
        msg = (f'{total} ONTs · {len(per_pon)} PONs · {len(zones)} zones · '
               f'fill {min(fills)}–{max(fills)} (avg {total // len(fills)}). '
               f'⛔ {len(over)} over {HARD_MAX} · ⚠ {len(above)} above target {TARGET_HI}'
               f' · ⚠ {len(under)} under {TARGET_LO}'
               + (f' · {unassigned} unassigned' if unassigned else ''))
        print('[FiberNet] Capacity: ' + msg)
        if over:
            print('  over-capacity PONs: ' + ', '.join(map(str, over)))
        if above:
            print(f'  above-target PONs ({TARGET_HI + 1}-{HARD_MAX}): ' + ', '.join(map(str, above)))
        if under:
            print('  under-utilised PONs: ' + ', '.join(map(str, under)))
        if over:
            self.iface.messageBar().pushCritical('Zone & PON Capacity', msg)
        elif above or under or unassigned:
            self.iface.messageBar().pushWarning('Zone & PON Capacity', msg)
        else:
            self.iface.messageBar().pushSuccess('Zone & PON Capacity', msg)

    # ── Spatial anomaly scan ──────────────────────────────────────────────────
    def _run_anomaly_scan(self):
        """Project-agnostic topology QA: flag orphaned poles (no cable vertex
        within the snap tolerance) and dangling cable ends (an endpoint not
        snapped to any node — pole/splitter/joint/enclosure). Loads the hits as
        an 'Anomalies' memory layer so they're zoomable. Read-only on the data."""
        from qgis.core import (QgsProject, QgsMapLayer, QgsWkbTypes,
                               QgsSpatialIndex, QgsFeature, QgsGeometry,
                               QgsPointXY, QgsVectorLayer, QgsField, QgsFeatureRequest)
        from qgis.PyQt.QtCore import QMetaType

        TOL_M = 10.0                   # 10 m snap tolerance (project convention)
        proj = QgsProject.instance()
        vlayers = [l for l in proj.mapLayers().values()
                   if l.type() == QgsMapLayer.LayerType.VectorLayer]

        # Skip temp / scratch / backup / working layers — QA only real deliverables.
        SKIP = ('temp', 'scratch', 'backup', '_bak', 'copy', '_best', '_old', 'test_')

        def _is(geom_type, *keys):
            out = []
            for l in vlayers:
                try:
                    nm = l.name().lower()
                    if l.geometryType() != geom_type:
                        continue
                    if any(s in nm for s in SKIP):
                        continue
                    if any(k in nm for k in keys):
                        out.append(l)
                except Exception:
                    _swallowed_note()
            return out

        pole_lyrs = _is(QgsWkbTypes.GeometryType.PointGeometry,
                        'pole', 'splitter', 'joint', 'enclosure', 'node', 'dome')
        # Connection cables only — NOT "span" (a Vuma midblock routing spine that
        # legitimately isn't pole-terminated, so it must not count as dangling).
        cable_lyrs = _is(QgsWkbTypes.GeometryType.LineGeometry,
                         'cable', 'feeder', 'distribution', 'drop', 'spur', 'link')
        cable_lyrs = [l for l in cable_lyrs if 'span' not in l.name().lower()]
        if not pole_lyrs or not cable_lyrs:
            self.iface.messageBar().pushWarning(
                'Anomaly Scan',
                'Need both point (pole/splitter) and line (cable) layers — '
                f'found {len(pole_lyrs)} point, {len(cable_lyrs)} line.')
            return

        # Scale the snap tolerance to the cable layer CRS: `d` below is a planar
        # Euclidean distance in CRS units. For a projected CRS (UTM metres, the
        # FTTH standard) compare against 10 m directly; for a geographic CRS
        # convert 10 m to degrees. Using degrees against metres flagged every
        # end/pole as an anomaly (and vice-versa).
        TOL = TOL_M / 111320.0 if cable_lyrs[0].crs().isGeographic() else TOL_M

        # index of all node points
        node_pts = []
        for l in pole_lyrs:
            for f in l.getFeatures(QgsFeatureRequest().setNoAttributes()):
                g = f.geometry()
                if g and not g.isEmpty():
                    node_pts.append(g.centroid().asPoint())
        node_idx = QgsSpatialIndex()
        for i, p in enumerate(node_pts):
            ft = QgsFeature(i)
            ft.setGeometry(QgsGeometry.fromPointXY(p))
            node_idx.addFeature(ft)

        anomalies = []   # (x, y, kind, detail)

        # 1) dangling cable ends — endpoint not within tol of any node
        for l in cable_lyrs:
            for f in l.getFeatures():
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                try:
                    pl = g.asMultiPolyline() or [g.asPolyline()]
                except Exception:
                    _swallowed_note(); continue
                for line in pl:
                    if len(line) < 2:
                        continue
                    for end in (line[0], line[-1]):
                        ids = node_idx.nearestNeighbor(QgsPointXY(end), 1)
                        ok = False
                        if ids:
                            np_ = node_pts[ids[0]]
                            d = ((np_.x()-end.x())**2 + (np_.y()-end.y())**2) ** 0.5
                            ok = d <= TOL
                        if not ok:
                            anomalies.append((end.x(), end.y(), 'dangling_end', l.name()))

        # 2) orphaned poles — no cable vertex within tol
        cab_idx = QgsSpatialIndex()
        cab_pts = []
        k = 0
        for l in cable_lyrs:
            for f in l.getFeatures():
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                for v in g.vertices():
                    cab_pts.append(QgsPointXY(v))
                    ft = QgsFeature(k); ft.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(v)))
                    cab_idx.addFeature(ft); k += 1
        if cab_pts:
            for l in pole_lyrs:
                if 'pole' not in l.name().lower():
                    continue   # only true poles count as "orphaned"
                for f in l.getFeatures():
                    g = f.geometry()
                    if not g or g.isEmpty():
                        continue
                    p = g.asPoint() if g.wkbType() in (QgsWkbTypes.Point,) else g.centroid().asPoint()
                    ids = cab_idx.nearestNeighbor(p, 1)
                    if ids:
                        cv = cab_pts[ids[0]]
                        d = ((cv.x()-p.x())**2 + (cv.y()-p.y())**2) ** 0.5
                        if d > TOL:
                            anomalies.append((p.x(), p.y(), 'orphaned_pole', l.name()))

        # build / refresh the Anomalies memory layer
        crs = cable_lyrs[0].crs().authid() or 'EPSG:4326'
        for old in proj.mapLayersByName('Anomalies'):
            proj.removeMapLayer(old.id())
        mem = QgsVectorLayer(f'Point?crs={crs}', 'Anomalies', 'memory')
        dp = mem.dataProvider()
        dp.addAttributes([QgsField('kind', QMetaType.Type.QString),
                          QgsField('layer', QMetaType.Type.QString)])
        mem.updateFields()
        feats = []
        for x, y, kind, src in anomalies:
            ft = QgsFeature()
            ft.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
            ft.setAttributes([kind, src])
            feats.append(ft)
        dp.addFeatures(feats)
        mem.updateExtents()
        if anomalies:
            proj.addMapLayer(mem)

        dang = sum(1 for a in anomalies if a[2] == 'dangling_end')
        orph = sum(1 for a in anomalies if a[2] == 'orphaned_pole')
        msg = f'{len(anomalies)} anomalies — {dang} dangling cable ends, {orph} orphaned poles (10 m tol).'
        if anomalies:
            self.iface.messageBar().pushWarning('Spatial Anomaly Scan',
                                                msg + ' See the "Anomalies" layer.')
        else:
            self.iface.messageBar().pushSuccess('Spatial Anomaly Scan',
                                                'No orphaned poles or dangling cable ends ✓')
        print('[FiberNet] Anomaly scan: ' + msg)

    # ── Optical power budget (ITU-T G.984) ───────────────────────────────────
    def _run_power_budget_check(self):
        """First-order per-ONT GPON power-budget estimate. Uses straight-line
        POP→ONT distance × routing factor (true routed length isn't traced yet),
        the Combo-1 splitter chain (1:8 FTS + 1:16 STS) and standard ITU-T G.984
        losses. Honestly reported as an ESTIMATE — flags over-reach / over-split
        links so the planner can investigate. Degrades gracefully if layers are
        missing."""
        from qgis.core import (QgsProject, QgsMapLayer, QgsDistanceArea)
        try:
            from . import power_budget as pb
        except ImportError:
            import power_budget as pb

        def _find(keys):
            for lyr in QgsProject.instance().mapLayers().values():
                if lyr.type() != QgsMapLayer.LayerType.VectorLayer:
                    continue
                nm = lyr.name().lower()
                if any(k in nm for k in keys) and lyr.featureCount() > 0:
                    return lyr
            return None

        ont = _find(('ont', 'home connection', 'home_conn'))
        pop = _find(('pop', 'olt', 'core', 'aggregation'))
        if ont is None:
            self.iface.messageBar().pushWarning(
                'Power Budget', 'No ONT / Home-Connection layer found — cannot estimate.')
            return

        da = QgsDistanceArea()
        da.setEllipsoid('WGS84')
        try:
            da.setSourceCrs(ont.crs(), QgsProject.instance().transformContext())
        except Exception:
            _swallowed_note()

        # nearest POP point (single ref is fine for a first-order estimate)
        pop_pt = None
        if pop is not None:
            for f in pop.getFeatures():
                g = f.geometry()
                if g and not g.isEmpty():
                    pop_pt = g.centroid().asPoint()
                    break

        counts = {'green': 0, 'amber': 0, 'red': 0}
        worst = None
        n = 0
        for f in ont.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            pt = g.centroid().asPoint()
            if pop_pt is not None:
                try:
                    km = da.measureLine(pop_pt, pt) / 1000.0
                except Exception:
                    km = da.measureLine(pop_pt, pt)  # already deg→m fallback
            else:
                km = 2.0   # no POP: assume a typical 2 km reach for the estimate
            _loss, m, cls = pb.budget_for_ont(km)
            counts[cls] += 1
            n += 1
            if worst is None or m < worst[0]:
                worst = (m, km)

        if n == 0:
            self.iface.messageBar().pushWarning('Power Budget', 'No ONT geometries to evaluate.')
            return

        reach = pb.max_reach_km()
        src = 'POP→ONT distance' if pop_pt is not None else 'assumed 2 km (no POP layer)'
        msg = (f'{n} ONTs · ✅ {counts["green"]} healthy · '
               f'⚠ {counts["amber"]} tight · ⛔ {counts["red"]} failing  '
               f'(worst margin {worst[0]:.1f} dB @ {worst[1]:.2f} km). '
               f'Combo-1 max reach ≈ {reach:.1f} km. Estimate from {src}.')
        if counts['red']:
            self.iface.messageBar().pushCritical('Optical Power Budget', msg)
        elif counts['amber']:
            self.iface.messageBar().pushWarning('Optical Power Budget', msg)
        else:
            self.iface.messageBar().pushSuccess('Optical Power Budget', msg)
        print('[FiberNet] Power budget: ' + msg)

    # ── OSM no-data erven generation (dev/venv) ───────────────────────────────
    def _gen_erven_osm(self):
        """Generate regular erven from the OSM road network for the current view
        (where there's no CSG cadastre). osmnx/geopandas are venv-only, and OSM
        fetch is slow, so this runs a venv subprocess inside a QgsTask — fully
        off the QGIS main thread."""
        import os
        from qgis.core import (QgsProject, QgsCoordinateTransform, QgsApplication,
                               QgsCoordinateReferenceSystem, QgsTask, QgsVectorLayer)
        canvas = self.iface.mapCanvas()
        to4326 = QgsCoordinateTransform(canvas.mapSettings().destinationCrs(),
                                        QgsCoordinateReferenceSystem('EPSG:4326'),
                                        QgsProject.instance())
        b = to4326.transformBoundingBox(canvas.extent())
        if (b.width() > 0.1 or b.height() > 0.1):
            self.iface.messageBar().pushWarning('OSM Erven', 'Zoom in first (view too large).')
            return
        # locate the erven_studio runner + venv python (dev-only)
        runner = None
        for base in ('C:/Users/jjsch/OneDrive - blitzfibre.com/Documents/Workspace/QGIS/erven_studio',
                     os.path.join(os.path.dirname(os.path.dirname(__file__)), 'erven_studio')):
            cand = os.path.join(base, 'osm_blocks_runner.py')
            if os.path.exists(cand):
                runner = cand
                break
        try:
            from .fibre_automation.shared.vf_paths import python_exe
        except ImportError:
            from fibre_automation.shared.vf_paths import python_exe
        py = python_exe()
        if not runner or not py or not os.path.exists(py):
            self.iface.messageBar().pushWarning(
                'OSM Erven', 'erven_studio / venv not available — this is a dev feature.')
            return
        out = 'C:/Temp/osm_erven.geojson'
        bbox = (b.xMinimum(), b.yMinimum(), b.xMaximum(), b.yMaximum())
        self.iface.messageBar().pushInfo('OSM Erven', 'Generating erven from OSM roads (background)…')

        class _Task(QgsTask):
            def __init__(self, iface):
                super().__init__('Generate erven from OSM', QgsTask.Flag.CanCancel)
                self.iface = iface; self.err = None

            def run(self):
                import subprocess
                try:
                    r = subprocess.run([py, runner, *[f'{c}' for c in bbox], out],
                                       capture_output=True, text=True, timeout=180)
                    if r.returncode != 0:
                        self.err = (r.stderr or r.stdout or 'failed')[:200]
                        return False
                except Exception as e:
                    self.err = str(e)[:200]
                    return False
                return True

            def finished(self, ok):
                if not ok or self.err:
                    self.iface.messageBar().pushWarning('OSM Erven', f'Failed: {self.err}')
                    return
                lyr = QgsVectorLayer(out, 'Erven (OSM-generated)', 'ogr')
                if lyr.isValid() and lyr.featureCount() > 0:
                    QgsProject.instance().addMapLayer(lyr)
                    self.iface.messageBar().pushSuccess(
                        'OSM Erven', f'Generated {lyr.featureCount():,} erven from OSM roads.')
                else:
                    self.iface.messageBar().pushWarning('OSM Erven', 'No erven generated for this view.')

        task = _Task(self.iface)
        QgsApplication.taskManager().addTask(task)
        if not hasattr(self, '_osm_tasks'):
            self._osm_tasks = []
        self._osm_tasks.append(task)

    # ── CSG cadastre erven fetch ─────────────────────────────────────────────
    def _fetch_csg_erven(self):
        """Download real surveyed erven for the current view from the SA CSG
        cadastre — off the main thread (QgsTask), so it never freezes QGIS."""
        try:
            from . import csg_fetch
        except ImportError:
            import csg_fetch
        csg_fetch.run_fetch_erven(self.iface)

    # ── Feature hover tips ───────────────────────────────────────────────────
    def _toggle_feature_map_tips(self):
        """Set rich map-tip templates on the fiber layers, then toggle the
        canvas hover-tips on/off. Hover a pole/cable/splitter/ONT to see its
        key attributes without opening the attribute table."""
        from qgis.core import QgsProject, QgsMapLayer
        KW = ('pole', 'cable', 'splitter', 'ont', 'drop', 'enclosure',
              'feeder', 'distribution', 'pon', 'span', 'dome', 'joint', 'node')
        # fields worth surfacing, in priority order
        FIELDS = ['label', 'label_1', 'name', 'pon_no', 'dim2', 'length',
                  'status', 'spec_1', 'type_1', 'strtfeat', 'endfeat']
        tipped = 0
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                if lyr.type() != QgsMapLayer.LayerType.VectorLayer:
                    continue
                if not any(k in lyr.name().lower() for k in KW):
                    continue
                fns = [f.name() for f in lyr.fields()]
                rows = []
                for want in FIELDS:
                    actual = next((x for x in fns if x.lower() == want), None)
                    if actual:
                        rows.append(f'<b>{actual}:</b> [% "{actual}" %]')
                    if len(rows) >= 5:
                        break
                if not rows:
                    continue
                lyr.setMapTipTemplate(
                    '<div style="font-family:Segoe UI;font-size:11px;'
                    f'line-height:1.4">{"<br>".join(rows)}</div>')
                tipped += 1
            except Exception:
                _swallowed_note(); continue
        # Toggle the global map-tips display action
        state = '?'
        try:
            act = self.iface.actionMapTips()
            if act is not None:
                act.trigger()                       # flips checked state
                state = 'ON' if act.isChecked() else 'OFF'
        except Exception:
            _swallowed_note()
        self.iface.messageBar().pushInfo(
            'Velocity Nexus',
            f'Feature hover tips {state} — {tipped} fiber layer(s) configured. '
            'Hover a feature on the map to see its details.')

    # ── Native QGIS locator (Ctrl+K) ─────────────────────────────────────────
    def _install_locator_filter(self):
        """Register the 'vf <text>' locator filter on the QGIS search bar."""
        try:
            from . import locator_filter
        except ImportError:
            import locator_filter
        # Drop a previous instance on reload so we don't stack duplicates.
        old = getattr(self, '_locator', None)
        if old is not None:
            try:
                self.iface.deregisterLocatorFilter(old)
            except Exception:
                _swallowed_note()
        self._locator = locator_filter.VelocityLocatorFilter(self.iface)
        self.iface.registerLocatorFilter(self._locator)
        print('[FiberNet] Locator filter "vf" registered ✓')

    # ── Command palette (Ctrl+Shift+P) ──────────────────────────────────────
    def _install_command_palette(self):
        """Bind Ctrl+Shift+P globally — fuzzy-finder for every plugin action."""
        from qgis.PyQt.QtGui import QShortcut
        from qgis.PyQt.QtGui import QKeySequence
        sc = QShortcut(QKeySequence("Ctrl+Shift+P"), self.iface.mainWindow())
        sc.setContext(Qt.ShortcutContext.ApplicationShortcut)
        sc.activated.connect(self._open_command_palette)
        self._cmd_palette_shortcut = sc

    # ── Mirror Eye indicator ──────────────────────────────────────────────────
    def _install_mirror_eye(self):
        """A small clickable eye on the toolbar that shows whether the Canvas
        Mirror server (port 8767) is actively watching JJ's screen.

        States (driven purely by file-mtime — NO HTTP from Qt main thread):
          - PNG age <5s   → 👁 Watching   (green, the eye is "open")
          - PNG age <30s  → 👁 Idle       (amber)
          - PNG age >30s  → 🚫 Off         (red, the eye is "closed")

        Click → opens http://127.0.0.1:8767/ in default browser.
        """
        from qgis.PyQt.QtWidgets import QPushButton
        from qgis.PyQt.QtCore import QTimer
        # Defensive cleanup — same lesson as HLD tile (don't leak on reload)
        try:
            for child in self._toolbar.findChildren(QPushButton):
                if child.objectName() == 'FNAMirrorEye':
                    child.setParent(None)
                    child.hide()
                    child.deleteLater()
        except Exception:
            _swallowed_note()

        eye = QPushButton('👁  …')
        eye.setObjectName('FNAMirrorEye')
        eye.setFlat(True)
        eye.setCursor(Qt.CursorShape.PointingHandCursor)
        eye.clicked.connect(self._open_mirror_viewer)
        eye.setToolTip(
            'Canvas Mirror — live screen capture of QGIS\n'
            'Click to open the viewer in your browser\n'
            'http://127.0.0.1:8767/'
        )
        self._mirror_eye = eye
        # Insert right after the brand tile, before any action
        self._toolbar.addWidget(eye)
        # Poll every 3s — file-mtime check only, no HTTP, no QGIS calls
        self._mirror_eye_timer = QTimer(self.iface.mainWindow())
        self._mirror_eye_timer.setInterval(3000)
        self._mirror_eye_timer.timeout.connect(self._refresh_mirror_eye)
        self._mirror_eye_timer.start()
        self._refresh_mirror_eye()  # initial state

    def _refresh_mirror_eye(self):
        """Update the eye state from PNG mtime. Pure file-stat — no I/O blocking."""
        import os
        import time
        if self._mirror_eye is None:
            return
        path = 'C:/Temp/canvas_mirror.png'
        try:
            if not os.path.exists(path):
                self._mirror_eye.setText('🚫  Mirror Off')
                self._mirror_eye.setStyleSheet(_MIRROR_EYE_OFF_QSS)
                return
            age = time.time() - os.path.getmtime(path)
            if age < 5:
                self._mirror_eye.setText(f'👁  Watching · {int(age)}s')
                self._mirror_eye.setStyleSheet(_MIRROR_EYE_WATCHING_QSS)
            elif age < 30:
                self._mirror_eye.setText(f'👁  Idle · {int(age)}s')
                self._mirror_eye.setStyleSheet(_MIRROR_EYE_IDLE_QSS)
            else:
                self._mirror_eye.setText('🚫  Mirror stale')
                self._mirror_eye.setStyleSheet(_MIRROR_EYE_OFF_QSS)
        except (OSError, RuntimeError):
            return  # widget was destroyed mid-tick; ignore

    def _open_mirror_viewer(self):
        """Click handler — opens the Canvas Mirror viewer in the user's default browser.
        Uses webbrowser stdlib (NOT urlopen — that would deadlock per
        feedback_never_http_to_self_from_qgis.md)."""
        import webbrowser
        webbrowser.open('http://127.0.0.1:8767/')

    def _open_command_palette(self):
        """Modal dialog with a single QLineEdit + filtered list of actions."""
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtWidgets import (QVBoxLayout, QLineEdit,
                                          QListWidget, QListWidgetItem)
        dlg = QDialog(self.iface.mainWindow())
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)   # don't leak hidden windows
        dlg.setWindowTitle("FiberNet — Command Palette")
        dlg.setMinimumWidth(520)
        dlg.setStyleSheet(
            "QDialog { background:#1A1B26; }"
            "QLineEdit { background:#24253A; color:#E6E8F0; border:1px solid #3A3D5C;"
            "  border-radius:6px; padding:8px 12px; font-size:14px;"
            "  font-family:'Segoe UI'; }"
            "QLineEdit:focus { border:1px solid #6E56CF; }"
            "QListWidget { background:#1A1B26; color:#E6E8F0; border:none;"
            "  font-family:'Segoe UI'; font-size:12px; padding:4px; }"
            "QListWidget::item { padding:7px 10px; border-radius:4px; }"
            "QListWidget::item:selected { background:#6E56CF; color:#FFFFFF; }"
            "QListWidget::item:hover { background:#3A3D5C; }"
        )
        layout = QVBoxLayout(dlg)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        edit = QLineEdit()
        edit.setPlaceholderText("Type to search actions… (Enter to run, Esc to close)")
        layout.addWidget(edit)

        listw = QListWidget()
        listw.setMaximumHeight(360)
        layout.addWidget(listw)

        # Build action catalogue.
        # Source 1: toolbar actions (self._actions).
        # Source 2: every action wired into the Velocity Nexus menu tree —
        # this is what surfaces the 18 Manual Planning tools, QA & Output and
        # Settings items that are added straight to the menu via mk() and never
        # land in self._actions. Without this the palette only finds toolbar
        # buttons (decode 1A: "biggest cheap discoverability win").
        items = []
        seen = set()  # dedup by the underlying QAction id()

        def _add(act, aid):
            if act is None or id(act) in seen:
                return
            if act.isSeparator() or act.menu() is not None:
                return  # skip dividers and submenu openers
            text = act.text().replace('&', '').strip()
            if not text:
                return
            seen.add(id(act))
            tip = act.toolTip() or ''
            ks = act.shortcut().toString() if act.shortcut() else ''
            items.append((aid, act, text, tip, ks))

        for aid, act in self._actions.items():
            _add(act, aid)

        def _walk_menu(menu):
            for act in menu.actions():
                sub = act.menu()
                if sub is not None:
                    _walk_menu(sub)
                else:
                    _add(act, act.text().replace('&', '').strip())

        velo_menu = getattr(self, '_velo_menu', None)
        if velo_menu is not None:
            try:
                _walk_menu(velo_menu)
            except Exception:
                _swallowed_note()  # never let palette-building crash the shortcut

        # Key every action by a stable integer so the list item can resolve
        # back to the exact QAction object — not all items live in self._actions
        # now that the menu tree is indexed too.
        act_by_key = {i: it[1] for i, it in enumerate(items)}

        def populate(query=''):
            listw.clear()
            q = query.lower().strip()
            scored = []
            for key, (aid, act, text, tip, ks) in enumerate(items):
                hay = f'{aid} {text} {tip}'.lower()
                if not q or all(part in hay for part in q.split()):
                    scored.append((key, text, ks))
            for key, text, ks in scored[:30]:
                label = f'{text}   ⌨ {ks}' if ks else text
                item = QListWidgetItem(label)
                item.setData(Qt.ItemDataRole.UserRole, key)
                listw.addItem(item)
            if listw.count() > 0:
                listw.setCurrentRow(0)

        populate()

        def trigger():
            cur = listw.currentItem()
            if cur:
                key = cur.data(Qt.ItemDataRole.UserRole)
                dlg.accept()
                act = act_by_key.get(key)
                if act is not None:
                    act.trigger()

        edit.textChanged.connect(populate)
        edit.returnPressed.connect(trigger)
        listw.itemActivated.connect(lambda _it: trigger())

        # Up/down arrow on the QLineEdit moves the list selection
        def edit_key(ev):
            if ev.key() == Qt.Key.Key_Down:
                listw.setCurrentRow(min(listw.currentRow()+1, listw.count()-1))
                return
            if ev.key() == Qt.Key.Key_Up:
                listw.setCurrentRow(max(listw.currentRow()-1, 0))
                return
            QLineEdit.keyPressEvent(edit, ev)
        edit.keyPressEvent = edit_key

        edit.setFocus()
        try:
            from .nexus_dock import chrome_dialog
            chrome_dialog(dlg)
        except Exception:
            _swallowed_note()
        dlg.exec()

    # ── Client selector (driven by VeloGIS Bridge dock) ──────────────────────

    def _get_bridge_dock(self):
        """Return the VeloGIS Bridge dock widget, or None if unavailable."""
        try:
            from qgis.utils import plugins as _plugins
            bp = _plugins.get('QGISBridgePlugin')
            if bp is None:
                return None
            for attr in ('_dock', 'dock', '_dock_widget', 'dock_widget'):
                dock = getattr(bp, attr, None)
                if dock is not None:
                    return dock
        except Exception:
            _swallowed_note()
        return None

    def _lock_dock_to_client(self, client: str):
        """Lock (or unlock) the bridge dock client buttons to match the project."""
        dock = self._get_bridge_dock()
        if dock is None:
            return
        try:
            if client:
                dock.set_client_locked(client.upper())
            else:
                dock.unlock_client()
        except AttributeError:
            pass  # older bridge plugin without locking support

    def _connect_bridge_client_signal(self) -> bool:
        """Connect to bridge dock client_changed signal. Returns True on success."""
        try:
            dock = self._get_bridge_dock()
            if dock is None:
                return False
            dock.client_changed.connect(self._rebuild_automation_group)
            print('[FiberNet] Bridge client_changed signal connected ✓')
            # Restore toolbar state from current dock selection
            current = getattr(dock, 'active_client', '')
            if current:
                self._rebuild_automation_group(current)
            return True
        except Exception as e:
            print(f'[FiberNet] Bridge signal connect failed: {e}')
            return False

    _VUMA_STEPS = [
        ('1 · Setup Layers',      'vuma_step_01'),
        ('1b · Fetch Data',       'vuma_step_01b'),
        ('1c · Erven Generator',  'vuma_step_01c'),
        ('2 · Tag Buildings',     'vuma_step_02'),
        ('3 · Demand Points',     'vuma_step_03'),
        ('4 · PON Zones',         'vuma_step_04'),
        ('5 · Place Nodes',       'vuma_step_05'),
        ('6 · Route Cables',      'vuma_step_06'),
        ('7 · Auto-Name',         'vuma_step_07'),
        ('8 · Attributes',        'vuma_step_08'),
        ('9 · QA Check',          'vuma_step_09'),
        ('10 · Export',           'vuma_step_10'),
    ]
    _FT_STEPS = [
        ('1 · Label Poles',       'ft_step_01'),
        ('2 · Distribution Cable','ft_step_02'),
        ('3 · Secondary Cable',   'ft_step_03'),
        ('4 · Enclosure',         'ft_step_04'),
        ('5 · PON Zones',         'ft_step_05'),
        ('6 · Apply PON Order',   'ft_step_06'),
        ('7 · Pole Thickness',    'ft_step_07'),
        ('8 · RC Update',         'ft_step_08'),
        ('9 · QA Report',         'ft_step_09'),
        ('10 · Export',           'ft_step_10'),
    ]
    # HeroTel has no STEP_MAP steps: its dropdown holds VN 1 + the real HT 1-6
    # algorithms (TOOLBAR_SPEC group "herotel"). The old list pointed at 5 placeholder
    # functions that only printed "not yet implemented".

    def _update_toolbar_for_client(self, client):
        """Show/hide toolbar buttons based on selected client.

        client=None  → fresh project: show ONLY brand + Setup Project (clean UX for planners)
        client='vuma'→ show vuma + both; hide ft + dev
        client='ft'  → show ft + both; hide vuma + dev
        client='dev' → show everything (JJ's dev mode — not a real client value)
        """
        c = (client or '').lower()
        no_client = (c == '')

        # Client dropdowns (Fibertime / Vuma / HeroTel): ALWAYS on the toolbar, so a
        # button never moves between projects. The open project's client is lit in its
        # brand colour; the others are a dashed outline but still open (JJ 2026-09-23).
        # Use the QWidgetAction (from tb.addWidget) for correct toolbar visibility.
        for gid, meta in GROUPS.items():
            grp_client = meta.get('client', 'both')
            act = self._group_acts.get(gid)
            btn = self._group_btns.get(gid)
            if act is not None:
                act.setVisible(True)
            if btn is not None:
                btn.setVisible(True)
                lit_dashed = _CLIENT_BTN_QSS.get(grp_client)
                if lit_dashed:
                    lit = (grp_client == c) or c == 'dev'
                    try:
                        btn.setStyleSheet(lit_dashed[0] if lit else lit_dashed[1])
                    except (RuntimeError, AttributeError):
                        pass

        # Show/hide absorbed fibretime_tools buttons — they are FT-only
        ft_active = (c == 'ft')
        # QToolButton menus: must hide via the QWidgetAction returned by addWidget(),
        # not the button itself — toolbar visibility is controlled by the action wrapper.
        for act in getattr(self, '_absorbed_ft_widget_acts', []):
            try:
                act.setVisible(ft_active)
            except (RuntimeError, AttributeError):
                pass
        # Re-apply FT styling when shown
        if ft_active:
            for w in self._absorbed_ft_widgets:
                try:
                    if w.styleSheet() == '':
                        w.setStyleSheet(_FT_BTN_QSS)
                except (RuntimeError, AttributeError):
                    pass
        # Plain QActions — hide via the action itself (most reliable)
        for act in getattr(self, '_absorbed_ft_actions', []):
            try:
                act.setVisible(ft_active)
            except (RuntimeError, AttributeError):
                pass

        # All inline actions — apply per-item client visibility
        for entry in TOOLBAR_SPEC:
            item_client = entry.get('client', 'both')
            act = self._actions.get(entry['id'])
            if act is None:
                continue
            if item_client == 'dev':
                visible = False  # dev tools always hidden from planners
            elif item_client == 'both':
                visible = True   # always visible regardless of client selection
            elif item_client == 'none':
                # Client-selector buttons: show ONLY when no client is chosen
                visible = no_client
                # Apply brand styling while visible
                if visible and self._toolbar:
                    w = self._toolbar.widgetForAction(act)
                    if w:
                        qss = (_VUMA_BTN_QSS if entry['id'] == 'select_vuma'
                               else _FT_BTN_QSS)
                        try:
                            w.setStyleSheet(qss)
                        except (RuntimeError, AttributeError):
                            pass
            elif no_client:
                # Hide everything else on a fresh project (client selectors + New Project only)
                visible = False
            else:
                visible = (item_client == c)
            act.setVisible(visible)
            if self._toolbar:
                w = self._toolbar.widgetForAction(act)
                if w:
                    try:
                        w.setVisible(visible)
                    except (RuntimeError, AttributeError):
                        pass

    def _rebuild_automation_group(self, client: str):
        """Record the open project's client, light its dropdown, add automation steps."""

        # Normalise client strings
        client = client.upper() if client else ''
        if client == 'FIBRETIME':
            client = 'FT'
        if client not in ('VUMA', 'FT', 'HEROTEL'):
            client = ''

        tb = self._toolbar

        # Show/hide fixed toolbar buttons for this client
        self._update_toolbar_for_client(client.lower() if client else '')

        # Remove previous automation widgets
        if self._automation_action is not None:
            tb.removeAction(self._automation_action)
            self._automation_action = None
        if self._automation_sep is not None:
            tb.removeAction(self._automation_sep)
            self._automation_sep = None
        if self._automation_widget is not None:
            self._automation_widget.deleteLater()
            self._automation_widget = None

        # Update SESSION
        try:
            from fibre_automation.startup import SESSION
            if client == 'VUMA':
                SESSION['client'] = 'VUMA'
            elif client == 'FT':
                SESSION['client'] = 'FT'
            elif client == 'HEROTEL':
                SESSION['client'] = 'HEROTEL'
            else:
                SESSION['client'] = None
        except Exception:
            _swallowed_note()

        # The client's automation steps live INSIDE its always-visible dropdown now
        # (one toolbar, one dropdown per client - JJ 2026-09-23), not in a separate
        # button that appeared and vanished with the client.
        self._ensure_automation_sections()

    # client group id -> (steps, run-all key) appended under an "Automation" header
    _AUTOMATION_SECTIONS = (
        ('ft', '_FT_STEPS', 'ft_run_all'),
        ('labelling', '_VUMA_STEPS', 'vuma_run_all'),
    )

    def _ensure_automation_sections(self):
        """Append each client's STEP_MAP automation steps to its dropdown, once.

        STEP_MAP is filled when the fibre_automation pipeline is wired, which can be
        after the toolbar is built - so this waits until it has entries, then adds the
        sections exactly once per menu."""
        try:
            from fibre_automation.startup import STEP_MAP
        except Exception:
            return
        if not STEP_MAP:
            return
        done = getattr(self, '_automation_sections_done', set())
        for gid, steps_attr, run_key in self._AUTOMATION_SECTIONS:
            if gid in done:
                continue
            btn = self._group_btns.get(gid)
            try:
                menu = btn.menu() if btn is not None else None
            except RuntimeError:
                menu = None
            if menu is None:
                continue
            menu.addSeparator()
            hdr = QAction('Automation', menu)
            hdr.setEnabled(False)
            f = hdr.font()
            f.setItalic(True); f.setBold(True); f.setPointSize(8)
            hdr.setFont(f)
            menu.addAction(hdr)
            for label, key in getattr(self, steps_attr):
                action = menu.addAction(label)
                fn = STEP_MAP.get(key)
                if fn:
                    action.triggered.connect(lambda _=False, fn=fn: fn())
                else:
                    action.setEnabled(False)
            run_fn = STEP_MAP.get(run_key)
            run_action = menu.addAction('⚡ Run All Steps')
            if run_fn:
                run_action.triggered.connect(lambda _=False, fn=run_fn: fn())
            else:
                run_action.setEnabled(False)
            done.add(gid)
        self._automation_sections_done = done

    def _open_bridge_dock(self):
        """Find the VeloGIS Bridge QDockWidget and show/raise it.
        Falls back to searching by title if the plugin instance isn't reachable."""
        try:
            # Try via plugin registry first
            from qgis.utils import plugins as _plugins
            bp = _plugins.get('QGISBridgePlugin')
            if bp is not None:
                # Bridge plugin may expose its dock as _dock / dock / _dock_widget
                for attr in ('_dock', 'dock', '_dock_widget', 'dock_widget'):
                    dock = getattr(bp, attr, None)
                    if dock is not None:
                        dock.setVisible(True)
                        dock.raise_()
                        return
        except Exception:
            _swallowed_note()
        # Fallback: search by title
        for dock in self.iface.mainWindow().findChildren(QDockWidget):
            title = dock.windowTitle() or ""
            if "VeloGIS" in title or "Bridge" in title:
                dock.setVisible(True)
                dock.raise_()
                return
        self.iface.messageBar().pushWarning(
            "Bridge", "VeloGIS Bridge dock not found — is QGISBridgePlugin loaded?")

    # ── Algorithm / script / macro runners ───────────────────────────────────
    def _log_and_push_critical(self, where, exc):
        """Log a failure to the error log AND surface it on the message bar
        with the Report-a-Problem pointer. Use in every except handler that
        a teammate can hit — a flashed message without a log entry is
        un-debuggable from their side."""
        try:
            try:
                from . import error_reporter
            except ImportError:
                import error_reporter
            error_reporter.log_error(where, exc)
        except Exception:
            _swallowed_note()
        # Nexus auto-capture: send the error + breadcrumbs to the team monitor
        # (silent; the operator's deliberate Report-a-Problem still works too).
        try:
            if getattr(self, '_nexus', None) is not None:
                self._nexus.report_error(where, exc)
        except Exception:
            _swallowed_note()
        self.iface.messageBar().pushCritical(
            where,
            f'{exc} — logged. Velocity Nexus menu → Report a Problem '
            'to send it to support.')

    def _run_algo(self, algo_id, entry_id):
        """Open the Processing dialog so user can tweak params."""
        import processing
        from qgis.core import Qgis
        act = self._actions.get(entry_id)
        if act: act.setEnabled(False)
        mb = self.iface.messageBar()
        running = mb.createMessage(entry_id, f"Running {algo_id} …")
        mb.pushWidget(running, Qgis.MessageLevel.Info)
        QApplication.processEvents()
        try:
            processing.execAlgorithmDialog(algo_id, {})
            mb.pushSuccess(entry_id, f"{algo_id} ✓")
        except Exception as e:
            self._log_and_push_critical(f'algorithm {algo_id}', e)
        finally:
            try: mb.popWidget(running)   # never leave a stale "Running…" banner
            except Exception: _swallowed_note()
            if act: act.setEnabled(True)

    def _run_script(self, script_path, entry_id):
        # Resolve robustly: the spec path is the dev location; on a team install fall back to the
        # copy bundled inside the plugin (same basename). Never fail with a cryptic file-not-found.
        if not os.path.exists(script_path):
            alt = os.path.join(os.path.dirname(__file__), os.path.basename(script_path))
            if os.path.exists(alt):
                script_path = alt
            else:
                self.iface.messageBar().pushWarning(
                    entry_id, f"{os.path.basename(script_path)} not found (not bundled).")
                return
        from qgis.PyQt.QtCore import Qt
        from qgis.core import Qgis
        act = self._actions.get(entry_id)
        if act: act.setEnabled(False)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        mb = self.iface.messageBar()
        running = mb.createMessage(
            entry_id, f"Running {os.path.basename(script_path)} …")
        mb.pushWidget(running, Qgis.MessageLevel.Info)
        QApplication.processEvents()
        try:
            with open(script_path, encoding='utf-8') as _f:
                _src = _f.read()
            exec(_src, {'__name__': '__audit_script__'})
            mb.pushSuccess(
                entry_id, f"{os.path.basename(script_path)} ✓ (Ctrl+Alt+P for output)")
        except Exception as e:
            self._log_and_push_critical(entry_id, e)
        finally:
            QApplication.restoreOverrideCursor()
            try: mb.popWidget(running)   # clear the stale "Running…" banner
            except Exception: _swallowed_note()
            if act: act.setEnabled(True)

    def _run_clean_buildings(self, silent_if_missing=False):
        """Auto-discover Buildings + Erven layers and run cleanbuildings (1 building per erven).

        silent_if_missing: if True, return quietly when layers are absent or empty
                           (used for auto-fire at project startup for all 3 clients).
        """
        import processing
        from qgis.core import QgsProject, QgsWkbTypes, QgsProcessingFeedback
        from qgis.PyQt.QtWidgets import QProgressBar

        # --- Layer discovery: works for Vuma, Fibertime and HeroTel ---
        buildings_lyr = None
        erven_lyr = None
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                if lyr.geometryType() != QgsWkbTypes.GeometryType.PolygonGeometry:
                    continue
            except Exception:
                _swallowed_note(); continue
            name_lower = lyr.name().lower()
            if 'building' in name_lower and buildings_lyr is None:
                buildings_lyr = lyr
            elif 'erven' in name_lower and erven_lyr is None:
                erven_lyr = lyr

        if buildings_lyr is None or erven_lyr is None:
            if not silent_if_missing:
                missing = []
                if buildings_lyr is None:
                    missing.append('Buildings')
                if erven_lyr is None:
                    missing.append('Erven')
                self.iface.messageBar().pushWarning(
                    'Clean Buildings',
                    f"Layer(s) not found: {', '.join(missing)}. Run Setup / Erven Generator first."
                )
            return

        total = buildings_lyr.featureCount()
        if total == 0:
            if not silent_if_missing:
                self.iface.messageBar().pushInfo(
                    'Clean Buildings', 'Buildings layer is empty — nothing to clean.'
                )
            return

        erven_count = erven_lyr.featureCount()

        # Interactive runs only: confirm before deleting (the startup auto-fire
        # passes silent_if_missing=True and must never prompt).
        if not silent_if_missing:
            from qgis.PyQt.QtWidgets import QMessageBox
            if QMessageBox.question(
                    self.iface.mainWindow(), 'Clean Buildings',
                    f"Reduce {total:,} buildings to one per erf "
                    f"({erven_count:,} erven)?\n\nThis deletes the extra "
                    "building polygons — make sure your layers are backed up.",
                    QMessageBox.StandardButton.Yes
                    | QMessageBox.StandardButton.Cancel,
                    QMessageBox.StandardButton.Cancel
            ) != QMessageBox.StandardButton.Yes:
                return

        # --- Embed a live progress bar in the message bar ---
        msg_item = self.iface.messageBar().createMessage(
            'Clean Buildings',
            f'Cleaning {total:,} buildings across {erven_count:,} erven…'
        )
        prog = QProgressBar()
        prog.setMinimum(0)
        prog.setMaximum(100)
        prog.setValue(0)
        prog.setFixedWidth(200)
        prog.setFormat('%p%')
        prog.setTextVisible(True)
        msg_item.layout().addWidget(prog)
        self.iface.messageBar().pushWidget(msg_item, level=Qgis.MessageLevel.Info, duration=0)
        QApplication.processEvents()

        # --- Custom feedback wired to the progress bar ---
        class _ProgressFeedback(QgsProcessingFeedback):
            def setProgress(self, progress):
                super().setProgress(progress)
                prog.setValue(int(progress))
                QApplication.processEvents()

        feedback = _ProgressFeedback()

        try:
            processing.run('fibernetwork:cleanbuildings', {
                'BUILDINGS': buildings_lyr,
                'ERVENS':    erven_lyr,
            }, feedback=feedback)
            remaining = buildings_lyr.featureCount()
            removed = total - remaining
            self.iface.messageBar().clearWidgets()
            self.iface.messageBar().pushSuccess(
                'Clean Buildings',
                f'Done — {removed:,} duplicate(s) removed, {remaining:,} buildings kept (1 per erven).'
            )
        except Exception as exc:
            self.iface.messageBar().clearWidgets()
            self._log_and_push_critical('Clean Buildings', exc)

    def _run_pon_from_span(self):
        """Open HT 2 — PON Clustering from the span.

        A thin launcher: everything the operator needs is defaulted inside the
        algorithm, so the dialog opens ready to run.
        """
        import processing
        from qgis.core import QgsApplication
        alg_id = 'fibernetwork:ht_02_pon_clustering'
        if QgsApplication.processingRegistry().algorithmById(alg_id) is None:
            self.iface.messageBar().pushWarning(
                'Generate PONs',
                'The PON clustering algorithm is not registered — reload the '
                'plugin and try again.')
            return
        try:
            processing.execAlgorithmDialog(alg_id, {})
        except Exception as exc:                      # pragma: no cover
            self._log_and_push_critical('Generate PONs from Span', exc)

    def _run_ft_pipeline(self):
        """Run FT1..7 (incl. FT4b) sequentially."""
        import processing
        pipeline = [
            ("FT1 Label Poles",            "fibernetwork:ft_label_poles"),
            ("FT2 Distribution Cable",     "fibernetwork:ft_label_distribution_cable"),
            ("FT3 Secondary Cable",        "fibernetwork:ft_label_secondary_cable"),
            ("FT4 Enclosure",              "fibernetwork:ft_label_enclosure"),
            ("FT4b STS Splitters",         "fibernetwork:ft_label_sts_splitters"),
            ("FT5 Generate PON Zones",     "fibernetwork:ft_generate_pon_zones"),
            ("FT6 Apply PON Order",        "fibernetwork:ft_apply_pon_order"),
            ("FT7 Pole Thickness",         "fibernetwork:ft_pole_thickness"),
        ]
        from qgis.PyQt.QtCore import Qt
        try:
            try:
                from .ux import StepProgress
            except ImportError:
                from ux import StepProgress
        except Exception:
            StepProgress = None
        # Pre-flight: warn (don't block) if FT6/FT7 inputs are missing, and
        # confirm — Run-All rewrites labels/attributes across the project.
        from qgis.PyQt.QtWidgets import QMessageBox
        warn = []
        try:
            from fibre_automation.shared import vf_paths
            if not os.path.exists(vf_paths.data_file('pon_feeder_order.txt')):
                warn.append("•  FT6 needs the PON feeder order — record it with "
                            "🔴 Record PON Order first, or FT6 will be wrong.")
            if not os.path.exists(vf_paths.roads_json()):
                warn.append("•  FT7 road-crossing needs roads.json — run /roads "
                            "first, or pole thickness skips road crossings.")
        except Exception:
            _swallowed_note()
        _msg = ("Run the full FT 1→7 pipeline?\n\nThis rewrites labels and "
                "attributes across Poles, Cables, Enclosures, PON/Zone and more.")
        if warn:
            _msg += "\n\nHeads-up:\n" + "\n".join(warn)
        if QMessageBox.question(
                self.iface.mainWindow(), "Run All FT 1→7", _msg,
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Cancel) != QMessageBox.StandardButton.Yes:
            return
        act = self._actions.get("ft_all")
        if act: act.setEnabled(False)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        ran = 0
        try:
            if StepProgress is not None:
                with StepProgress(self.iface, 'Run All FT 1→7',
                                  [n for n, _ in pipeline]) as prog:
                    for name, algo in pipeline:
                        if prog.canceled:
                            break
                        prog.step(name)
                        processing.run(algo, {})
                        ran += 1
                    prog.done()
            else:
                for name, algo in pipeline:
                    self.iface.messageBar().pushMessage(
                        "FT 1..7", f"{name} …", level=Qgis.MessageLevel.Info, duration=0)
                    QApplication.processEvents()
                    processing.run(algo, {})
                    ran += 1
            if ran == len(pipeline):
                self.iface.messageBar().pushSuccess(
                    "FT 1..7", f"✓ Ran all {ran} algorithms successfully")
            else:
                self.iface.messageBar().pushWarning(
                    "FT 1..7", f"Stopped after {ran}/{len(pipeline)} (cancelled)")
        except Exception as e:
            self._log_and_push_critical(f"FT 1..7 (step {ran + 1})", e)
        finally:
            QApplication.restoreOverrideCursor()
            if act: act.setEnabled(True)

    def _run_span_check(self):
        """Busy-cursor wrapper — the span walk can take a while on large
        projects; show a wait cursor so the UI reads as 'working', not frozen.
        The span maths + layer build are unchanged (in _span_check_impl)."""
        from qgis.PyQt.QtWidgets import QApplication
        from qgis.PyQt.QtGui import QCursor
        from qgis.PyQt.QtCore import Qt as _Qt
        QApplication.setOverrideCursor(QCursor(_Qt.CursorShape.WaitCursor))
        QApplication.processEvents()          # render the cursor before the walk
        try:
            self._span_check_impl()
        finally:
            QApplication.restoreOverrideCursor()

    def _span_check_impl(self):
        """Pole-to-pole span checker (v6, 2026-04-20).

        Produces a 'Span Violations' memory layer with one pink line per
        offending span. Thresholds:
          Drop / Spare Drop: 50 m · Distribution / Secondary / Primary: 70 m

        How it works:
          - Walks each v1 cable segment-by-segment.
          - For each segment's straight line, finds every pole within 5 m.
            (Matches physical reality: a cable running A→B is clamped to any
            pole its line passes within 5 m of, even if no vertex is drawn
            at that pole.)
          - Concatenates hits in along-cable order; collapses adjacent dupes
            (same pid at seg boundary) while preserving zig-zag re-visits.
          - For each consecutive pair, measures TRUE GEODESIC (ellipsoidal)
            distance via QgsDistanceArea (WGS84) — matches QGIS Measure
            tool. Prior versions used planar 111320 m/°, which over-inflated
            longitude by ~12% at MOA latitude.
          - Cables with <2 poles detected fall back to straight-line distance
            between first and last cable vertex (method='straight-endpoints').
        """
        from qgis.core import (QgsSpatialIndex, QgsFeature, QgsGeometry,
                                QgsVectorLayer, QgsField, QgsLineSymbol,
                                QgsRectangle, QgsDistanceArea,
                                QgsCoordinateReferenceSystem)
        from qgis.PyQt.QtCore import QMetaType
        import math
        M_DEG = 111320.0   # rough latitude metres per degree (dy only)
        SNAP_M = 5.0
        SNAP_DEG = SNAP_M / M_DEG

        # v6 (2026-04-20): use ellipsoidal distance via QgsDistanceArea to match
        # what QGIS Measure tool reports. Prior versions treated longitude and
        # latitude as equal metres-per-degree which inflated spans ~12% at MOA
        # latitude (cos(-26.74°) ≈ 0.893). Fix: compute dx using cos(lat), or
        # use QgsDistanceArea for true geodesic distance.
        _da = QgsDistanceArea()
        _da.setEllipsoid("WGS84")
        _da.setSourceCrs(QgsCoordinateReferenceSystem("EPSG:4326"),
                         QgsProject.instance().transformContext())

        def _geodesic_m(pa, pb):
            """True ellipsoidal metres between two WGS84 points."""
            return _da.measureLine([pa, pb])

        def _seg_dist_m(pt_xy, a, b):
            """Perpendicular distance pt→segment(a,b) in metres (corrected)."""
            seg = QgsGeometry.fromPolylineXY([a, b])
            # For distance-to-segment we still use planar approx but with the
            # longitude correction applied. For short cable segments this is
            # accurate to better than 1 cm.
            d_deg = seg.distance(QgsGeometry.fromPointXY(pt_xy))
            cos_lat = math.cos(math.radians((a.y()+b.y())/2))
            # Planar distance mixes dx and dy; use geometric mean scale.
            return d_deg * M_DEG * cos_lat  # conservative: use lon scale
        def _seg_along_m(pt_xy, a, b):
            ax, ay = a.x(), a.y(); bx, by = b.x(), b.y()
            dx, dy = (bx-ax), (by-ay)
            seg_len2 = dx*dx + dy*dy
            if seg_len2 == 0: return 0.0
            t = max(0.0, min(1.0, ((pt_xy.x()-ax)*dx + (pt_xy.y()-ay)*dy) / seg_len2))
            return t * _geodesic_m(a, b)
        THRESH = {
            "drop cable v1":         50.0,
            "spare drop cable v1":   50.0,
            "distribution cable v1": 70.0,
            "secondary cable v1":    70.0,
            "primary cable v1":      70.0,
        }
        act = self._actions.get("span_check")
        if act: act.setEnabled(False)
        self.iface.messageBar().pushMessage(
            "Span Check", "Scanning pole-to-pole spans …", level=Qgis.MessageLevel.Info, duration=0)
        QApplication.processEvents()
        try:
            proj = QgsProject.instance()
            pole_lyr = next((l for l in proj.mapLayers().values()
                             if l.name().lower() == "poles v1"), None)
            if not pole_lyr:
                self.iface.messageBar().pushCritical(
                    "Span Check", "Poles v1 layer not found.")
                return
            pole_index = QgsSpatialIndex()
            pole_pt = {}
            for f in pole_lyr.getFeatures():
                g = f.geometry()
                if not g or g.isEmpty(): continue
                pole_pt[f.id()] = (str(f["Label"] or "").strip(), g.asPoint())
                pf = QgsFeature(f.id())
                pf.setGeometry(g)
                pole_index.addFeature(pf)

            # remove existing violation layer
            for l in list(proj.mapLayers().values()):
                if l.name() == "Span Violations":
                    proj.removeMapLayer(l.id())

            crs = pole_lyr.crs().authid()
            mem = QgsVectorLayer(f"LineString?crs={crs}", "Span Violations", "memory")
            mp = mem.dataProvider()
            mp.addAttributes([
                QgsField("source",     QMetaType.Type.QString),
                QgsField("cable_lbl",  QMetaType.Type.QString),
                QgsField("pole_a",     QMetaType.Type.QString),
                QgsField("pole_b",     QMetaType.Type.QString),
                QgsField("span_m",     QMetaType.Type.Double),
                QgsField("threshold",  QMetaType.Type.Double),
                QgsField("excess_m",   QMetaType.Type.Double),
                QgsField("method",     QMetaType.Type.QString),
            ])
            mem.updateFields()

            feats = []
            per_layer = {}
            for lname, max_span in THRESH.items():
                lyr = next((l for l in proj.mapLayers().values()
                            if l.name().lower() == lname), None)
                if not lyr: continue
                n_viol = 0
                for f in lyr.getFeatures():
                    g = f.geometry()
                    if not g or g.isEmpty(): continue
                    try: cable_lbl = str(f["label"])
                    except (KeyError, IndexError): cable_lbl = f"fid={f.id()}"
                    lines = g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]
                    for line in lines:
                        if len(line) < 2: continue
                        # v5 (2026-04-20): per-segment-line detection.
                        # A pole is ATTACHED wherever it sits within SNAP_M of a
                        # cable SEGMENT LINE (not just at a drawn vertex). This
                        # matches physical reality: a cable running straight
                        # from A to B is clamped at every pole its line passes
                        # within arm's reach of — even if the drawing only has
                        # vertices at A and B. v4 was too strict (demanded
                        # vertex); v3 had wrong dedup on zigzag.
                        cable_poles = []
                        cum = 0.0
                        for i in range(len(line)-1):
                            a = line[i]; b = line[i+1]
                            seg_len_m = _geodesic_m(a, b)
                            bbox = QgsRectangle(
                                min(a.x(),b.x())-SNAP_DEG, min(a.y(),b.y())-SNAP_DEG,
                                max(a.x(),b.x())+SNAP_DEG, max(a.y(),b.y())+SNAP_DEG)
                            sp = []
                            for pid in pole_index.intersects(bbox):
                                lbl, ppt = pole_pt[pid]
                                if _seg_dist_m(ppt, a, b) < SNAP_M:
                                    sp.append((_seg_along_m(ppt, a, b), lbl, ppt, pid))
                            sp.sort()
                            for along, lbl, ppt, pid in sp:
                                cable_poles.append((cum + along, lbl, ppt, pid))
                            cum += seg_len_m

                        # Collapse IMMEDIATELY consecutive same-pid entries
                        # (same pole detected at seg boundary). Preserves
                        # re-visits on zigzag loops.
                        collapsed = []
                        for entry in cable_poles:
                            if collapsed and collapsed[-1][3] == entry[3]:
                                continue
                            collapsed.append(entry)

                        if len(collapsed) < 2:
                            pa = line[0]; pb = line[-1]
                            span = _geodesic_m(pa, pb)
                            if span > max_span:
                                nf = QgsFeature(mem.fields())
                                nf.setGeometry(QgsGeometry.fromPolylineXY([pa, pb]))
                                nf.setAttributes([lyr.name(), cable_lbl, "", "",
                                                  round(span,1), max_span,
                                                  round(span-max_span,1),
                                                  "straight-endpoints"])
                                feats.append(nf); n_viol += 1
                            continue
                        for j in range(len(collapsed)-1):
                            _, la, pa, _ = collapsed[j]
                            _, lb, pb, _ = collapsed[j+1]
                            span = _geodesic_m(pa, pb)
                            if span > max_span:
                                nf = QgsFeature(mem.fields())
                                nf.setGeometry(QgsGeometry.fromPolylineXY([pa, pb]))
                                nf.setAttributes([lyr.name(), cable_lbl, la, lb,
                                                  round(span,1), max_span,
                                                  round(span-max_span,1),
                                                  "pole-to-pole"])
                                feats.append(nf); n_viol += 1
                per_layer[lyr.name()] = n_viol

            mp.addFeatures(feats)
            mem.updateExtents()
            sym = QgsLineSymbol.createSimple({"color": "#ff0066", "width": "1.5",
                                              "capstyle": "round"})
            mem.renderer().setSymbol(sym)
            proj.addMapLayer(mem)
            if feats:
                self.iface.mapCanvas().setExtent(mem.extent().buffered(50 / M_DEG))
            self.iface.mapCanvas().refresh()

            summary = " · ".join(f"{k.replace(' v1','')}:{v}"
                                 for k, v in per_layer.items() if v > 0)
            self.iface.messageBar().pushSuccess(
                "Span Check", f"✓ {len(feats)} violations — {summary or 'none'}")
        except Exception as e:
            self._log_and_push_critical("Span Check", e)
        finally:
            if act: act.setEnabled(True)

    def _run_update_layers(self):
        """Run the post-edit attribute refresh pipeline."""
        act = self._actions.get("update_layers")
        if act: act.setEnabled(False)
        self.iface.messageBar().pushMessage(
            "Update Layers", "Running attribute refresh across layers …",
            level=Qgis.MessageLevel.Info, duration=0)
        QApplication.processEvents()
        scripts = [
            "C:/Temp/prod_strtfeat_fix.py",
            "C:/Temp/drop_fix.py",
            "C:/Temp/sdrop_strtfeat_fix.py",
            "C:/Temp/ont_fix.py",
            "C:/Temp/sts_full_fix.py",
        ]
        try:
            ok = 0; failed = []; missing = []
            for s in scripts:
                if not os.path.exists(s):
                    missing.append(os.path.basename(s)); continue
                try:
                    with open(s, encoding='utf-8') as _f:
                        exec(_f.read(), {'__name__': '__update__'})
                    ok += 1
                except Exception as e:
                    # Per-script try/except — one failing script shouldn't kill the chain
                    failed.append(f"{os.path.basename(s)}: {type(e).__name__}: {e}")
            if failed:
                self.iface.messageBar().pushWarning(
                    "Update Layers",
                    f"{ok}/{len(scripts)} OK · {len(failed)} failed · {len(missing)} missing — check Console")
                from qgis.core import QgsMessageLog
                for line in failed:
                    QgsMessageLog.logMessage(line, "Update Layers", level=Qgis.MessageLevel.Critical)
            elif ok == 0:
                # nothing ran — saying "✓ Refreshed" here would be a lie
                self.iface.messageBar().pushWarning(
                    "Update Layers",
                    "No refresh scripts found on this machine "
                    f"({len(missing)} missing from C:/Temp) — nothing was "
                    "updated. These are dev-machine fix scripts.")
            else:
                self.iface.messageBar().pushSuccess(
                    "Update Layers",
                    f"✓ Refreshed {ok}/{len(scripts)} scripts" +
                    (f" ({len(missing)} missing)" if missing else ""))
        except Exception as e:
            self._log_and_push_critical("Update Layers", e)
        finally:
            if act: act.setEnabled(True)

    # ── Direct callbacks (used by tools + quick actions) ─────────────────────
    def _select_client_vuma(self):
        """Toolbar client-selector: set client to VUMA and trigger dock update."""
        dock = self._get_bridge_dock()
        if dock:
            try:
                dock._select_client('VUMA')
                return
            except Exception:
                _swallowed_note()
        # Fallback — no dock available, update toolbar directly
        self._rebuild_automation_group('VUMA')
        self._lock_dock_to_client('VUMA')

    def _select_client_ft(self):
        """Toolbar client-selector: set client to FT and trigger dock update."""
        dock = self._get_bridge_dock()
        if dock:
            try:
                dock._select_client('FT')
                return
            except Exception:
                _swallowed_note()
        self._rebuild_automation_group('FT')
        self._lock_dock_to_client('FT')

    def _run_q(self):
        QApplication.clipboard().setText("exec(open('C:/Temp/q.py').read())")
        self.iface.messageBar().pushMessage(
            '⚙️ Run q.py', 'Copied — paste in Python Console (Ctrl+V)',
            level=Qgis.MessageLevel.Info, duration=3)

    def _update_from_github(self):
        """One-click 'git pull' on the VeloPlan repo clone + live plugin reload.

        Lets anyone (e.g. a colleague who just pulls) get the newest code from
        GitHub without touching a command line. The repo location is remembered
        in QSettings; first use prompts for it.
        """
        import os
        import shutil
        import subprocess
        from qgis.PyQt.QtCore import QSettings, QTimer
        from qgis.PyQt.QtWidgets import QMessageBox, QFileDialog

        mw = self.iface.mainWindow()
        s = QSettings()
        key = 'FiberNetworkAutomation/repo_path'
        repo = s.value(key, '', type=str)

        def _valid(p):
            return bool(p) and os.path.isdir(os.path.join(p, '.git')) \
                and os.path.isdir(os.path.join(p, 'FiberNetworkAutomation'))

        # First use (or stale path) → ask for the VeloPlan clone folder
        if not _valid(repo):
            picked = QFileDialog.getExistingDirectory(
                mw, 'Select your VeloPlan repo folder (the clone containing .git)')
            if not picked:
                return
            if not _valid(picked):
                QMessageBox.warning(
                    mw, 'Update from GitHub',
                    'That folder is not a VeloPlan git clone.\n'
                    'Pick the folder that contains a ".git" folder and a '
                    '"FiberNetworkAutomation" subfolder.')
                return
            repo = picked
            s.setValue(key, repo)

        # 1. git pull (fast-forward only — clean for pull-only users)
        try:
            res = subprocess.run(
                ['git', '-C', repo, 'pull', '--ff-only'],
                capture_output=True, text=True, timeout=180)
        except FileNotFoundError:
            QMessageBox.critical(mw, 'Update from GitHub',
                                 'Git is not installed / not on PATH.')
            return
        except Exception as e:
            QMessageBox.critical(mw, 'Update from GitHub', f'git pull failed:\n{e}')
            return
        if res.returncode != 0:
            QMessageBox.critical(mw, 'Update from GitHub',
                                 f'git pull failed:\n\n{res.stderr.strip()}')
            return
        pull_msg = (res.stdout.strip() or 'Already up to date.')

        # 2. Copy the updated plugin into the installed location (this folder),
        #    unless the plugin is already running from the clone itself.
        src = os.path.join(repo, 'FiberNetworkAutomation')
        dst = os.path.dirname(os.path.abspath(__file__))
        copied = False
        if os.path.normcase(os.path.normpath(src)) != \
           os.path.normcase(os.path.normpath(dst)):
            try:
                shutil.copytree(
                    src, dst, dirs_exist_ok=True,
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
                copied = True
            except Exception as e:
                QMessageBox.critical(mw, 'Update from GitHub',
                                     f'Pulled OK but copy failed:\n{e}')
                return

        # 3. Reload the plugin AFTER this handler returns (it is part of the
        #    plugin being unloaded), via the 3-step that re-registers the
        #    processing provider (reloadPlugin alone does not).
        def _do_reload():
            try:
                from qgis.utils import unloadPlugin, loadPlugin, startPlugin
                unloadPlugin('FiberNetworkAutomation')
                loadPlugin('FiberNetworkAutomation')
                startPlugin('FiberNetworkAutomation')
                self.iface.messageBar().pushMessage(
                    '⬇ Update', 'Reloaded with the latest code from GitHub.',
                    level=Qgis.MessageLevel.Info, duration=4)
            except Exception as e:
                self.iface.messageBar().pushCritical('⬇ Update', f'Reload failed: {e}')

        QMessageBox.information(
            mw, 'Update from GitHub',
            f'{pull_msg}\n\n'
            + ('Plugin files updated. ' if copied else '')
            + 'Reloading FiberNetworkAutomation now…')
        QTimer.singleShot(300, _do_reload)

    def _exec_erven_pipeline(self, action):
        script = r"C:/Users/jjsch/OneDrive - blitzfibre.com/Documents/Workspace/QGIS/run_erven_pipeline.py"
        btn_ids = ("erven_pipe", "erven_continue")
        for bid in btn_ids:
            a = self._actions.get(bid)
            if a: a.setEnabled(False)
        QApplication.processEvents()
        try:
            with open(script, encoding="utf-8") as _f:
                _code = compile(_f.read(), script, "exec")
            exec(_code, {"__name__": "__main__", "ACTION": action})
        except Exception as e:
            self._log_and_push_critical('Erven Pipeline', e)
        finally:
            for bid in btn_ids:
                a = self._actions.get(bid)
                if a: a.setEnabled(True)

    def _run_erven_pipeline(self):
        self._exec_erven_pipeline("start")

    def _continue_erven_pipeline(self):
        self._exec_erven_pipeline("continue")

    def _open_pole_editor(self):
        from qgis.PyQt import sip
        dock = getattr(self, '_pole_editor_dock', None)
        if dock is not None and not sip.isdeleted(dock):
            dock.setVisible(True); dock.raise_()
            if dock.isFloating():
                dock.activateWindow()
            return
        lyr = next(
            (l for l in QgsProject.instance().mapLayers().values()
             if 'poles v1' in l.name().lower()),
            None)
        if not lyr:
            self.iface.messageBar().pushWarning('Pole Editor', 'No "poles v1" layer found.')
            return
        panel = PoleEditorPanel(self.iface, lyr)
        self._pole_editor_panel = panel
        # interactive editor → finalize+destroy on close (delete-on-close dock runs _teardown)
        self._pole_editor_dock = self._dock_panel(
            panel, '🔧 Pole Editor', 'VFPoleEditorDock',
            on_close=panel._teardown, delete_on_close=True, float_size=(380, 660))
        self._pole_editor_dock.destroyed.connect(
            lambda *_: (setattr(self, '_pole_editor_dock', None),
                        setattr(self, '_pole_editor_panel', None)))
        # Summary counts — guard the field reads so a non-standard poles schema
        # (missing dim2 / thickness_) can't crash the editor on open.
        try:
            names = lyr.fields().names()
            thick = (sum(1 for f in lyr.getFeatures() if str(f['dim2']) == '140-160mm')
                     if 'dim2' in names else 0)
            rc = (sum(1 for f in lyr.getFeatures()
                      if 'road crossing' in str(f['thickness_']).lower())
                  if 'thickness_' in names else 0)
            self.iface.messageBar().pushMessage(
                '🔧 Pole Editor', f'{thick} thick (blue) · {rc} road crossings (green)',
                level=Qgis.MessageLevel.Info, duration=4)
        except Exception:
            _swallowed_note()

    def _dock_util(self):
        """The shared dock opener (bundled under fibre_automation)."""
        try:
            try:
                from .fibre_automation import dock_util
            except ImportError:
                from fibre_automation import dock_util
            return dock_util
        except Exception:
            return None

    def _dock_panel(self, content, title, object_name, on_close=None,
                    area=None, floating=False, float_size=(440, 820),
                    delete_on_close=False):
        """Host any content QWidget in a dockable + scrollable QGIS dock (see
        _PanelDock). Opens FULLY docked on a side (full height + a sensible
        width, raised) via dock_util.dock_fully — never a half floating window
        that needs a re-snap. Pass floating=True for the rare panel that must
        float. delete_on_close=True → closing DESTROYS it (finalize-on-close
        editors); default just hides (re-openable)."""
        from qgis.PyQt.QtWidgets import QScrollArea
        dock = _PanelDock(title, self.iface, on_close=on_close)
        dock.setObjectName(object_name)
        if delete_on_close:
            dock.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidget(content)
        dock.setWidget(scroll)
        area = area or Qt.DockWidgetArea.RightDockWidgetArea
        du = self._dock_util()
        if du is not None:
            du.dock_fully(self.iface, dock, area=area,
                          width=float_size[0], prefer_float=floating)
        else:                                   # fallback: at least dock it
            self.iface.addDockWidget(area, dock)
        return dock

    def _open_building_review(self):
        """Open the human-in-the-loop Detected Buildings review dock. Every
        keep/delete/fix is logged to corrections.gpkg (active-learning fuel)."""
        try:
            try:
                from .review_dock import open_building_review
            except ImportError:
                from review_dock import open_building_review
            open_building_review(self)
        except Exception as exc:
            try:
                try:
                    from . import error_reporter
                except ImportError:
                    import error_reporter
                error_reporter.log_error("Open Review Buildings", exc)
            except Exception:
                _swallowed_note()

    def _open_route_viewer(self):
        from qgis.PyQt import sip
        dock = getattr(self, '_route_viewer_dock', None)
        if dock is not None and not sip.isdeleted(dock):
            dock.setVisible(True); dock.raise_()
            if dock.isFloating():
                dock.activateWindow()
            return
        self._route_viewer_panel = SpliceRouteViewerPanel(self.iface)
        # dock-close just HIDES (cleanup runs on plugin unload), so re-opening the
        # same dock keeps the Excel poll + identify handlers working.
        self._route_viewer_dock = self._dock_panel(
            self._route_viewer_panel, '🔦 Splice Route Viewer',
            'VFSpliceRouteViewerDock', float_size=(440, 820))
        n = len(self._route_viewer_panel._idx['ports'])
        if n:
            self.iface.messageBar().pushMessage(
                '🔦 Route Viewer',
                f'{n} OLT ports loaded — pick one to light its fibre route. '
                'Drag the title bar to dock it on any edge.',
                level=Qgis.MessageLevel.Info, duration=5)
        else:
            self.iface.messageBar().pushWarning(
                '🔦 Route Viewer',
                'No FTS Splitters layer in this project — open the splice project.')

    def _open_enc_editor(self):
        from qgis.PyQt import sip
        dock = getattr(self, '_enc_editor_dock', None)
        if dock is not None and not sip.isdeleted(dock):
            dock.setVisible(True); dock.raise_()
            if dock.isFloating():
                dock.activateWindow()
            return
        panel = EnclosureEditorPanel(self.iface)
        self._enc_editor_panel = panel
        # interactive editor → finalize+destroy on close (delete-on-close dock runs _teardown)
        self._enc_editor_dock = self._dock_panel(
            panel, '🧰 Enclosure Editor', 'VFEncEditorDock',
            on_close=panel._teardown, delete_on_close=True, float_size=(400, 680))
        self._enc_editor_dock.destroyed.connect(
            lambda *_: (setattr(self, '_enc_editor_dock', None),
                        setattr(self, '_enc_editor_panel', None)))
        conn = next((l for l in QgsProject.instance().mapLayers().values()
                     if l.name() == 'Enclosures Connectorised v1'), None)
        splice = next((l for l in QgsProject.instance().mapLayers().values()
                       if l.name() == 'Enclosures Splice v1'), None)
        if not conn and not splice:
            self.iface.messageBar().pushWarning(
                'Enclosure Editor', 'No Enclosure layers found.')
            return
        parts = []
        if conn:
            feats = list(conn.getFeatures())
            n_spur = sum(1 for f in feats if str(f['spec_1']) == 'M16 Microloop')
            parts.append(f'{len(feats) - n_spur} dist · {n_spur} spur')
        if splice:
            feats = list(splice.getFeatures())
            n_cmj = sum(1 for f in feats if str(f['spec_1']) == 'CMJ')
            parts.append(f'{len(feats) - n_cmj} UMJ · {n_cmj} CMJ')
        self.iface.messageBar().pushMessage(
            '🔲 Enclosure Editor', '  |  '.join(parts),
            level=Qgis.MessageLevel.Info, duration=4)

    def _snap_canvas(self):
        import subprocess
        path = 'C:/Temp/canvas.png'
        win = self.iface.mainWindow()
        screen = QApplication.primaryScreen()
        pixmap = screen.grabWindow(win.winId())
        if pixmap.width() > 900:
            pixmap = pixmap.scaledToWidth(900, Qt.TransformationMode.SmoothTransformation)
        pixmap.save(path, 'JPEG', 82)
        ps1 = r'C:\Temp\canvas_paste.ps1'
        if os.path.exists(ps1):
            subprocess.Popen(
                [r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
                 '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ps1],
                creationflags=0x08000000)
        size = os.path.getsize(path)
        self.iface.messageBar().pushMessage(
            '📷 Canvas', f'Sent to Claude  ({size//1024} KB)',
            level=Qgis.MessageLevel.Info, duration=3)

    # ── Bridge status poller (brand tile lamp) ───────────────────────────────
    def _start_bridge_poller(self):
        self._bridge_timer = QTimer(self.iface.mainWindow())
        self._bridge_timer.setInterval(3000)  # 3s
        self._bridge_timer.timeout.connect(self._bridge_tick)
        self._bridge_timer.start()
        self._bridge_tick()  # immediate first check

    def _bridge_tick(self):
        """Scan ports 8765-8769 for live bridges, then verify the CURRENT port
        (from bridge_port.txt) is among them.

        Green  = current port is in the list of open bridge ports AND QGISBridgePlugin is loaded.
        Red    = current port is NOT a working bridge, even if other ports are open.

        Tooltip lists all available ports so user can switch to one.

        Note: socket.connect_ex() is used because urllib to our own bridge
        would deadlock (HTTP handler needs main thread we're blocking).
        Debouncing: 2 fails before flipping red."""
        if not self._brand_label:
            return
        import socket
        from qgis.utils import plugins as _plugins

        # Current port: the LOCAL bridge plugin's actual bound port. This is the
        # ONLY instance-specific truth — bridge_port.txt is one file shared by
        # every QGIS process and cannot distinguish them, so it is read only as
        # "which bridge is Claude pointed at", never as "which port am I on".
        current_port = None
        server_alive = None
        try:
            bp = _plugins.get('QGISBridgePlugin')
            srv = getattr(bp, '_server', None) if bp is not None else None
            if srv is not None:
                current_port = int(srv.port)
                # `running` is a PROPERTY (not a method) reporting whether the
                # serving thread is actually alive — a bound port with a dead
                # thread is "not responding", a different problem from "no
                # bridge here". Stays None if an older server object lacks it:
                # unknown must not masquerade as either answer.
                try:
                    server_alive = bool(srv.running)
                except Exception:
                    server_alive = None
        except Exception:
            _swallowed_note()
        # Separate question: which bridge has Claude been told to talk to?
        claude_port = None
        try:
            with open('C:/Temp/bridge_port.txt', 'r') as f:
                claude_port = int(f.read().strip())
        except Exception:
            _swallowed_note()

        # Scan 8765-8769 concurrently with NON-BLOCKING connects + a single bounded
        # select. The old version did 5 SEQUENTIAL blocking connects every 3s on the Qt
        # main thread, so a filtered/slow port stacked timeouts into a 3-4s UI freeze
        # (the #1 freeze on recent versions). This is behaviour-identical (same set of
        # locally-listening ports) but capped at one 0.3s select — pure socket, no Qt.
        import select as _select

        from .bridge_state import PORT_RANGE
        available_ports = []
        _pending = {}
        for p in PORT_RANGE:
            s = None
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.setblocking(False)
                rc = s.connect_ex(('127.0.0.1', p))
            except Exception:
                if s is not None:
                    try: s.close()
                    except Exception: _swallowed_note()
                continue
            if rc == 0:                       # connected immediately
                available_ports.append(p)
                s.close()
            else:                             # in progress (EWOULDBLOCK / EINPROGRESS)
                _pending[s] = p
        if _pending:
            try:
                _, _writable, _exc = _select.select([], list(_pending), list(_pending), 0.3)
            except Exception:
                _writable = []
            for s in _writable:
                try:
                    if s.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR) == 0:
                        available_ports.append(_pending[s])
                except Exception:
                    _swallowed_note()
            for s in _pending:
                try: s.close()
                except Exception: _swallowed_note()
        available_ports.sort()

        from . import bridge_state as _bs
        bridge_plugin_loaded = _plugins.get('QGISBridgePlugin') is not None
        state = _bs.classify(
            polled=True,
            plugin_loaded=bridge_plugin_loaded,
            server_port=current_port,
            server_alive=server_alive,
            listening_ports=available_ports)

        # Debounce only ever DELAYS bad news; it can never show green early.
        if state == _bs.CONNECTED:
            self._bridge_fail_streak = 0
        else:
            self._bridge_fail_streak += 1
        prev = getattr(self, '_bridge_last_state', _bs.CONNECTING)
        state = _bs.apply_debounce(state, prev, self._bridge_fail_streak)

        try:
            self._set_bridge_status(state, current_port, available_ports,
                                    claude_port)
            self._bridge_last_state = state
            self._bridge_last_shown_alive = _bs.is_healthy(state)
        except RuntimeError:
            pass

    def _open_bridge_switcher(self):
        """Dev-only: choose which bridge Claude talks to (never this window's).

        Reached only when velocity_nexus/dev/bridge_switcher_enabled is on --
        with the flag absent the handler is never attached."""
        try:
            from qgis.core import QgsProject
            from qgis.utils import plugins as _plugins
            from .bridge_switcher import BridgeSwitcherDialog
            own_port = None
            bp = _plugins.get('QGISBridgePlugin')
            srv = getattr(bp, '_server', None) if bp is not None else None
            if srv is not None:
                own_port = int(srv.port)
            dlg = BridgeSwitcherDialog(
                self.iface.mainWindow(), own_port=own_port,
                own_project=QgsProject.instance().baseName())
            # WA_DeleteOnClose: read what we need from the dialog BEFORE exec()
            # returns and the C++ object is freed.
            if dlg.exec():
                chosen = dlg.chosen_port()
                if chosen is not None:
                    self.iface.messageBar().pushMessage(
                        'Bridge',
                        f'Claude now talks to port {chosen}. This window still '
                        f'runs its own bridge on '
                        f'{own_port if own_port is not None else "—"}.',
                        level=Qgis.MessageLevel.Info, duration=5)
                    self._bridge_tick()      # repaint immediately
        except Exception as e:
            self.iface.messageBar().pushMessage(
                'Bridge', f'Could not open the bridge picker: {e}',
                level=Qgis.MessageLevel.Warning, duration=6)

    def _set_bridge_status(self, state, port, available_ports=None,
                           claude_port=None):
        """Paint every bridge indicator from ONE decided state.

        `state` is a bridge_state constant, not a bool: "the bridge is loaded but
        not serving" and "there is no bridge here" are different problems and
        used to render identically."""
        from . import bridge_state as _bs
        available_ports = available_ports or []
        alive = _bs.is_healthy(state)
        colour = (_GREEN if alive else
                  _AMBER if state == _bs.DEGRADED else _RED)
        text, tip_line = _bs.describe(state, port, claude_port)

        # The home panel is the indicator this fixes: it was told a hardcoded
        # True once at startup and never updated. Now it is driven from the same
        # decided state as the toolbar, every tick. Guarded because the panel is
        # WA_DeleteOnClose — a closed dock leaves a dead C++ object behind, and
        # `is None` does not catch that.
        from qgis.PyQt import sip
        panel = getattr(self, '_home_panel', None)
        if panel is not None and not sip.isdeleted(panel):
            try:
                panel.set_bridge_state(state, port, claude_port, text)
            except (RuntimeError, AttributeError):
                pass

        if not self._brand_label:
            return
        # Badge: red knight (♞) brand mark, border reflects bridge status
        self._brand_label.setStyleSheet(
            f"QLabel {{ background: #0D1320; color: #EF4444;"
            f" font-family:'Segoe UI Symbol','Segoe UI'; font-weight:800;"
            f" font-size:17px;"
            f" border: 2px solid {colour}; border-radius: 4px;"
            f" padding: 1px 7px; }}")

        # Status label: text + colour
        if getattr(self, '_brand_status', None):
            self._brand_status.setText(text)
            self._brand_status.setStyleSheet(
                f"QLabel {{ color: {colour}; font-family:'Segoe UI';"
                f" font-size:10px; font-weight:700; padding: 2px 4px; }}")

        # Tooltip on the container — lists available ports for easy switching
        parent = self._brand_label.parentWidget()
        if parent is not None:
            avail_str = (", ".join(str(p) for p in available_ports)
                         if available_ports else "none")
            # Deliberately "answering", not "bridges": this is a socket probe,
            # and other local servers sit in the same range (the canvas mirror
            # answers on 8767). Calling them bridges would be a guess.
            tip = (f"VelocityFibre Bridge\n{tip_line}\n\n"
                   f"This window: port {port if port is not None else '—'}\n"
                   f"Claude → port {claude_port if claude_port is not None else '—'}\n"
                   f"Ports answering {_bs.PORT_MIN}-{_bs.PORT_MAX}: {avail_str}\n\n"
                   f"Click to open Bridge dock (switch ports)")
            try:
                parent.setToolTip(tip)
            except RuntimeError:
                pass

    # ── Retire the redundant fibretime_tools plugin (its toolbar buttons) ────
    def _retire_fibretime_tools(self):
        """Permanently remove the separate fibretime_tools toolbar buttons: disable that plugin
        (won't load on restart), unload it now, and remove any leftover FibretimeToolbar.
        Everything those buttons did lives in the published VeloPlan plugin."""
        try:
            from qgis.core import QgsSettings
            from qgis.PyQt.QtWidgets import QToolBar
            import qgis.utils as U
            QgsSettings().setValue('PythonPlugins/fibretime_tools', False)
            if 'fibretime_tools' in U.plugins:
                try:
                    U.unloadPlugin('fibretime_tools')
                except Exception:
                    _swallowed_note()
            for tb in self.iface.mainWindow().findChildren(QToolBar):
                if tb.objectName() == 'FibretimeToolbar' or tb.windowTitle() == 'Fibertime Tools':
                    self.iface.mainWindow().removeToolBar(tb)
                    tb.setParent(None); tb.deleteLater()
            # erven_qgis_plugin is absorbed as erven_detection/ (Phase 1) — retire it too
            QgsSettings().setValue('PythonPlugins/erven_qgis_plugin', False)
            if 'erven_qgis_plugin' in U.plugins:
                try:
                    U.unloadPlugin('erven_qgis_plugin')
                except Exception:
                    _swallowed_note()
        except Exception as e:
            print(f'[FiberNet] retire fibretime_tools failed: {e}')

    # ── Watchdog — re-absorb if fibretime toolbar reappears ──────────────────
    def _watchdog_check(self):
        try:
            from qgis.PyQt.QtWidgets import QToolBar
            for tb in self.iface.mainWindow().findChildren(QToolBar):
                if tb.objectName() == "FibretimeToolbar" and tb.isVisible() and tb.actions():
                    # A fresh visible fibretime toolbar — re-absorb (idempotent)
                    self._fibretime_absorbed = False
                    self._absorb_attempts = 0
                    self._absorb_fibretime_toolbar()
                    return
        except RuntimeError:
            pass

    # ── Absorb fibretime_tools toolbar into ours ─────────────────────────────
    def _absorb_fibretime_toolbar(self):
        """Move actions from FibretimeToolbar + VelocityFibreLogoBar onto our
        toolbar so the user has a single, flowing bar. Hides the originals."""
        from qgis.PyQt.QtWidgets import QToolBar
        if not self._toolbar:
            return
        mw = self.iface.mainWindow()
        ft_bar = None
        logo_bar = None
        for tb in mw.findChildren(QToolBar):
            n = tb.objectName()
            if n == "FibretimeToolbar":
                ft_bar = tb
            elif n == "VelocityFibreLogoBar":
                logo_bar = tb
        if ft_bar is None:
            # fibretime_tools not yet loaded — retry up to 10 times at 1s intervals
            self._absorb_attempts += 1
            if self._absorb_attempts < 10:
                from qgis.PyQt.QtCore import QTimer
                QTimer.singleShot(1000, self._absorb_fibretime_toolbar)
            return
        # Guard — don't absorb twice
        if getattr(self, "_fibretime_absorbed", False):
            return
        self._fibretime_absorbed = True
        self._absorbed_from = (ft_bar, logo_bar)

        # Idempotent absorb: collect texts already present on our toolbar
        # so re-runs don't duplicate. Also skip fibretime duplicates we retire.
        from qgis.PyQt.QtWidgets import QToolButton
        from qgis.PyQt.QtCore import Qt as _Qt
        # Fibertime items retired in favour of FNA equivalents (stronger impl).
        RETIRED = {"📏  Check Long Spans", "New Project"}
        existing = set()
        for a in self._toolbar.actions():
            t = a.text()
            if not t:
                w = self._toolbar.widgetForAction(a)
                if w is not None and hasattr(w, "text"):
                    t = w.text()
            if t: existing.add(t.strip())

        self._absorbed_ft_widgets = []       # QToolButtons (for styling)
        self._absorbed_ft_widget_acts = []   # QWidgetActions from addWidget() — use for visibility
        self._absorbed_ft_actions = []       # plain QActions — hidden/shown via act.setVisible()
        for act in list(ft_bar.actions()):
            if isinstance(act, QWidgetAction):
                w = act.defaultWidget()
                if isinstance(w, QToolButton) and w.menu() is not None:
                    label = (w.text() or "").strip()
                    if label in existing:
                        continue
                    new_btn = QToolButton(self._toolbar)
                    new_btn.setText(w.text())
                    new_btn.setIcon(w.icon())
                    new_btn.setToolTip(w.toolTip())
                    new_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
                    new_btn.setToolButtonStyle(_Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
                    new_btn.setMenu(w.menu())
                    new_btn.setStyleSheet(_FT_BTN_QSS)
                    widget_act = self._toolbar.addWidget(new_btn)
                    self._absorbed_ft_widgets.append(new_btn)
                    self._absorbed_ft_widget_acts.append(widget_act)
                    existing.add(label)
            else:
                label = (act.text() or "").strip()
                if label in existing or label in RETIRED:
                    continue
                self._toolbar.addAction(act)
                # Style the button if we can get a handle to it
                w = self._toolbar.widgetForAction(act)
                if w is not None and hasattr(w, "setToolButtonStyle"):
                    try:
                        w.setToolButtonStyle(_Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
                        w.setStyleSheet(_FT_BTN_QSS)
                    except Exception:
                        _swallowed_note()
                # Always store the action — setVisible on the action is reliable
                self._absorbed_ft_actions.append(act)
                existing.add(label)

        # Fully remove the original toolbars — not just hide, so QGIS can't re-show
        mw = self.iface.mainWindow()
        try: mw.removeToolBar(ft_bar)
        except RuntimeError: pass
        try: ft_bar.hide()
        except RuntimeError: pass
        if logo_bar is not None:
            try: mw.removeToolBar(logo_bar)
            except RuntimeError: pass
            try: logo_bar.hide()
            except RuntimeError: pass

        # Re-apply current client visibility so absorbed buttons respect Vuma/FT/None
        try:
            from fibre_automation.startup import SESSION
            current_client = (SESSION.get('client') or '').lower()
            self._update_toolbar_for_client(current_client or None)
        except Exception:
            self._update_toolbar_for_client(None)

    # ── Project session persistence ───────────────────────────────────────────
    def _heal_stranded_solo(self):
        """If the Splice Viewer's 'solo' dim was left active by a crash/hide (so the
        whole project is stranded at 15 % opacity), restore the saved originals and
        clear the flag. No-op when nothing is stranded. Fail-silent."""
        try:
            import json as _json
            from qgis.core import QgsProject
            val, ok = QgsProject.instance().readEntry('SpliceViewer', 'soloSaved', '')
            if not ok or not val:
                return 0
            saved = _json.loads(val)
            n = 0
            for lid, op in saved.items():
                l = QgsProject.instance().mapLayer(lid)
                if l is not None:
                    try:
                        if abs(l.opacity() - float(op)) > 1e-6:
                            l.setOpacity(float(op)); l.triggerRepaint()
                        n += 1
                    except Exception:
                        _swallowed_note()
            QgsProject.instance().removeEntry('SpliceViewer', 'soloSaved')
            if n:
                print(f"[FiberNet] healed stranded 'solo' dim — restored {n} layer opacities")
                try:
                    self.iface.mapCanvas().refresh()
                except Exception:
                    _swallowed_note()
            return n
        except Exception as e:
            print(f"[FiberNet] solo heal skipped: {e}")
            return 0

    def _on_project_read(self, *_args):
        """Restore SESSION from the project that was just opened."""
        try:
            from fibre_automation.startup import load_session_from_project, SESSION
            if load_session_from_project():
                client = SESSION.get('client') or ''
                print(f"[FiberNet] Session restored: {client} / {SESSION.get('area_code')}")
                self._rebuild_automation_group(client)
                # Lock the bridge dock to this project's client
                self._lock_dock_to_client(client)
            else:
                # No stored session → collapse to Setup Project only
                self._update_toolbar_for_client(None)
                self._lock_dock_to_client('')
        except Exception as e:
            print(f'[FiberNet] session restore failed: {e}')
        # Self-heal basemaps: a project saved on a newer QGIS (4.0/Qt6) embeds its
        # XYZ tile layers with datasource cruft an OLDER QGIS (3.40/3.44) can't
        # round-trip, so the basemap opens as an INVALID "bad layer" and looks
        # deleted. Rebuild any such layer from a portable URI. No-op on the machine
        # that saved the project (everything already valid). Fail-silent.
        try:
            from fibre_automation import basemaps
            n_healed = basemaps.heal_basemaps()
            if n_healed:
                print(f"[FiberNet] healed {n_healed} basemap(s) after cross-version open")
        except Exception as e:
            print(f"[FiberNet] basemap heal skipped: {e}")
        # Self-heal a stranded Splice-Viewer 'solo' dim (project saved/opened with all
        # vector layers at 15 % because the viewer was closed/crashed mid-solo).
        self._heal_stranded_solo()
        # Re-point the home panel at the project just opened — its context strip
        # (name + live counts) and step "you are here" are driven by
        # QgsProject.instance(), so a project switch must refresh them. Without
        # this the panel keeps showing the previous project's name/counts until a
        # layer happens to be added/removed.
        self._refresh_home_steps()
        # Render-only smoothing for heavy layers (faster pan/zoom; data untouched).
        # Toggleable in ⚙ Settings & Help; fail-silent.
        try:
            from fibre_automation import ui_smooth
            n = ui_smooth.apply()
            ui_smooth.apply_canvas(self.iface)          # parallel render + caching
            if n:
                print(f"[FiberNet] render smoothing applied to {n} heavy layer(s)")
        except Exception as e:
            print(f"[FiberNet] render smoothing skipped: {e}")

    def _on_project_cleared(self, *_args):
        """Clear SESSION when the project is cleared (startup or File → New).
        The welcome dialog is triggered separately by iface.newProjectCreated,
        which only fires on explicit user-initiated new project, not on startup.
        """
        try:
            from fibre_automation.startup import clear_session
            clear_session()
            print('[FiberNet] Session cleared (new project)')
        except Exception as e:
            print(f'[FiberNet] session clear failed: {e}')
        # Collapse toolbar to brand only
        try:
            self._update_toolbar_for_client(None)
            self._rebuild_automation_group('')
        except Exception:
            _swallowed_note()
        # Unlock the bridge dock so the user can pick a client for the new project
        self._lock_dock_to_client('')
        # Reset the home panel to the now-empty project (no name, zero counts)
        self._refresh_home_steps()

    def _show_welcome_dialog(self):
        """Centered project-setup wizard — always shown on every new/blank project.

        Non-modal so the planner can drag-and-drop an AOI shapefile into the
        Layers panel while the dialog is open.  A blinking arrow to the left of
        the dialog points at the Layers panel with "Drag & drop AOI" text.
        When a polygon layer lands in the project the AOI combo is auto-filled
        and the arrow dismissed.  On "Start Project" the full step-01 pipeline
        (layers + basemap + Overture) is kicked off for the chosen client.
        """
        from qgis.PyQt.QtWidgets import (QVBoxLayout, QHBoxLayout,
                                          QPushButton, QLabel, QLineEdit,
                                          QComboBox, QFrame, QSizePolicy)
        from qgis.PyQt.QtCore import Qt, QPoint, QTimer

        mw = self.iface.mainWindow()

        # ── Kill any existing welcome dialog + arrow (singleton pattern) ──────
        _prev = getattr(self, '_welcome_dlg', None)
        if _prev is not None:
            try:
                _prev.hide()
                _prev.close()
                _prev.deleteLater()
            except RuntimeError:
                pass
            self._welcome_dlg = None

        for _old in mw.findChildren(QLabel):
            if _old.objectName() == "FNAWelcomeArrow":
                try:
                    _old.hide()
                    _old.deleteLater()
                except RuntimeError:
                    pass
        from qgis.PyQt.QtGui import QFont
        from qgis.core import (QgsCoordinateReferenceSystem, QgsWkbTypes,
                                QgsProject)

        _VUMA_PROJECTS = [
            ("— select project —",         "",      ""),
            ("Malmesbury",                  "MALM",  "Z1"),
            ("Praktiseer",                  "PRAK",  "Z1"),
            ("Ipelegeng",                   "IPG",   "Z1"),
            ("Driekoppies",                 "DRIEK", "Z1"),
            ("Kamatsamo",                   "KAM",   "Z1"),
            ("Schweizer-Reneke",            "SCHW",  "Z1"),
            ("Mothibistad",                 "MOTH",  "Z1"),
            ("Kuruman",                     "KUR",   "Z1"),
            ("Wrenchville",                 "WREN",  "Z1"),
            ("Zastron",                     "ZAST",  "Z1"),
            ("Tonga",                       "TONG",  "Z1"),
            ("Other (enter code manually)", "",      ""),
        ]
        _CRS_OPTIONS = [
            ("EPSG:4326",  "WGS 84 — geographic (default)"),
            ("EPSG:32734", "UTM Zone 34S"),
            ("EPSG:32735", "UTM Zone 35S"),
            ("EPSG:2048",  "Hartbeesthoek94 / LO19"),
        ]

        _chosen = {"client": None}

        # ── Blinking arrow overlay (parented to main window, NOT the dialog) ─
        arrow = QLabel(mw)
        arrow.setObjectName("FNAWelcomeArrow")
        arrow.setText("◀\nDrag & drop\nyour AOI here")
        arrow.setAlignment(Qt.AlignmentFlag.AlignCenter)
        arrow.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        arrow.setStyleSheet(
            "QLabel { background: rgba(0,0,0,210); color: #FFFFFF;"
            " border: 2px solid #FFFFFF; border-radius: 10px;"
            " padding: 12px 14px; }"
        )
        arrow.adjustSize()
        arrow.hide()  # positioned + shown after dialog is placed

        _blink_bright = [True]
        _blink_timer = QTimer(mw)
        _blink_timer.setInterval(550)

        def _arrow_blink():
            _blink_bright[0] = not _blink_bright[0]
            try:
                if _blink_bright[0]:
                    arrow.setStyleSheet(
                        "QLabel { background: rgba(0,0,0,210); color: #FFFFFF;"
                        " border: 2px solid #FFFFFF; border-radius: 10px;"
                        " padding: 12px 14px; }"
                    )
                else:
                    arrow.setStyleSheet(
                        "QLabel { background: rgba(40,40,60,160); color: #AAAAAA;"
                        " border: 2px solid #666688; border-radius: 10px;"
                        " padding: 12px 14px; }"
                    )
            except RuntimeError:
                _blink_timer.stop()

        _blink_timer.timeout.connect(_arrow_blink)

        def _stop_arrow():
            """Stop blinking; turn green with AOI-detected confirmation."""
            _blink_timer.stop()
            try:
                arrow.setText("✓  AOI detected")
                arrow.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
                arrow.setStyleSheet(
                    "QLabel { background: #14532d; color: #86efac;"
                    " border: 2px solid #22c55e; border-radius: 10px;"
                    " padding: 14px 20px; }"
                )
                arrow.adjustSize()
            except RuntimeError:
                pass

        # ── Dialog (non-modal, always-on-top) ─────────────────────────────────
        dlg = QDialog(mw)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)  # don't leak hidden windows
        dlg.setWindowTitle("VeloGIS — New Project")
        dlg.setWindowFlags(
            Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.Tool
        )
        dlg.setModal(False)
        dlg.setMinimumWidth(560)
        self._welcome_dlg = dlg  # singleton ref — killed on next call

        _QSS = """
        QDialog {
            background: #0E1525;
            border: 1px solid #1A2840;
            border-radius: 20px;
        }
        QLabel { color: #E6E8F0; font-family: 'Segoe UI'; }
        QLabel#hdr {
            font-size: 22px; font-weight: 900; color: #FFFFFF;
            letter-spacing: 0.5px;
        }
        QLabel#sub  { font-size: 11px; color: #3E4A62; }
        QLabel#field_lbl {
            font-size: 10px; color: #3E4A62; font-weight: 700;
            letter-spacing: 1.5px;
        }
        QLabel#client_desc { font-size: 10px; color: #3E4A62; }
        QLabel#section_label {
            font-size: 9px; color: #2A3450; font-weight: 700;
            letter-spacing: 2px;
        }

        QLineEdit, QComboBox {
            background: #091220; color: #B0BAD0;
            border: 1px solid #1A2840; border-radius: 8px;
            padding: 8px 12px; font-family: 'Segoe UI'; font-size: 12px;
        }
        QLineEdit:focus, QComboBox:focus {
            border: 1.5px solid #6050CC;
            background: #0D1830;
        }
        QComboBox QAbstractItemView {
            background: #091220; color: #B0BAD0;
            border: 1px solid #1A2840;
            selection-background-color: #1A2840;
        }
        QComboBox::drop-down { border: none; }

        /* ── Client card wrappers ─────────────────────────── */
        QFrame#card_vuma {
            background: #141830;
            border: 1.5px solid #251535;
            border-radius: 14px;
        }
        QFrame#card_vuma[active="true"] {
            border: 2px solid #FF0090;
            background: #180F28;
        }
        QFrame#card_ft {
            background: #141830;
            border: 1.5px solid #122030;
            border-radius: 14px;
        }
        QFrame#card_ft[active="true"] {
            border: 2px solid #2ABFCC;
            background: #0C1C28;
        }
        QFrame#card_herotel {
            background: #141830;
            border: 1.5px solid #221410;
            border-radius: 14px;
        }
        QFrame#card_herotel[active="true"] {
            border: 2px solid #FF4500;
            background: #1C0E08;
        }

        /* ── VUMA  hot magenta ─────────────────────────────── */
        QPushButton#vuma_sel {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #FF1FA0, stop:1 #CC0072);
            color: white; border: none; border-radius: 10px;
            font-family: 'Segoe UI'; font-size: 17px; font-weight: 900;
            letter-spacing: 5px;
            padding: 22px 16px; min-width: 130px;
        }
        QPushButton#vuma_sel:hover {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #FF44B4, stop:1 #FF0090);
        }

        /* ── fibertime  yellow + cyan columns ─────────────── */
        QPushButton#ft_sel {
            background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0    #2ABFCC, stop:0.25 #2ABFCC,
                stop:0.251 #FFE619, stop:0.749 #FFE619,
                stop:0.75 #2ABFCC, stop:1    #2ABFCC);
            color: #1A3040; border: none; border-radius: 10px;
            font-family: 'Segoe UI'; font-size: 17px; font-weight: 800;
            padding: 22px 16px; min-width: 130px;
        }
        QPushButton#ft_sel:hover {
            background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0    #40D8E4, stop:0.25 #40D8E4,
                stop:0.251 #FFF040, stop:0.749 #FFF040,
                stop:0.75 #40D8E4, stop:1    #40D8E4);
        }

        /* ── herotel  bright orange ────────────────────────── */
        QPushButton#herotel_sel {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #FF5500, stop:1 #CC3A00);
            color: white; border: none; border-radius: 10px;
            font-family: 'Segoe UI'; font-size: 17px; font-weight: 700;
            padding: 22px 16px; min-width: 130px;
        }
        QPushButton#herotel_sel:hover {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #FF6E1F, stop:1 #FF4400);
        }

        /* ── form container ─────────────────────────────────── */
        QFrame#form_box {
            background: #0A1220;
            border: 1px solid #1A2840;
            border-radius: 12px;
        }

        /* ── action buttons ─────────────────────────────────── */
        QPushButton#start_btn {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #7E66D8, stop:1 #5A48C0);
            color: white; border: none; border-radius: 9px;
            font-family: 'Segoe UI'; font-size: 13px; font-weight: 700;
            padding: 12px 40px; min-width: 160px;
        }
        QPushButton#start_btn:hover {
            background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
                stop:0 #9278E0, stop:1 #7E66D8);
        }
        QPushButton#start_btn:disabled { background: #101828; color: #252B3A; }
        QPushButton#cancel_btn {
            background: transparent; color: #303850;
            border: 1px solid #1A2840; border-radius: 7px;
            font-family: 'Segoe UI'; font-size: 11px; padding: 8px 20px;
        }
        QPushButton#cancel_btn:hover { color: #6070A0; border-color: #304060; }

        QFrame#accent_bar {
            background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0 #FF0090, stop:0.33 #7060D8,
                stop:0.66 #FFE619, stop:1 #FF4500);
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
        }
        """
        dlg.setStyleSheet(_QSS)


        root = QVBoxLayout(dlg)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── 5px rainbow accent bar pinned to top ──────────────────────────────
        accent_bar = QFrame()
        accent_bar.setObjectName("accent_bar")
        accent_bar.setFixedHeight(5)
        root.addWidget(accent_bar)

        # ── Inner layout carries side + bottom margins ─────────────────────────
        inner = QVBoxLayout()
        inner.setContentsMargins(32, 20, 32, 28)
        inner.setSpacing(0)
        root.addLayout(inner)

        # header row: centred title + a clear Windows-style ✕ in the top-right (this
        # dialog is frameless, so without this there is NO visible way to close it).
        from qgis.PyQt.QtWidgets import QToolButton as _QTB
        hdr_row = QHBoxLayout()
        hdr_row.setContentsMargins(0, 0, 0, 0)
        _lspacer = QWidget(); _lspacer.setFixedWidth(28)   # balance the ✕ → title stays centred
        hdr_row.addWidget(_lspacer)
        hdr_row.addStretch(1)
        hdr = QLabel("New Project")
        hdr.setObjectName("hdr")
        hdr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        hdr_row.addWidget(hdr)
        hdr_row.addStretch(1)
        _close_x = _QTB()
        _close_x.setFixedSize(28, 26)
        try:
            from .nexus_dock import style_windows_close
            style_windows_close(_close_x, dlg.reject)
        except Exception:
            _close_x.setText("✕"); _close_x.clicked.connect(dlg.reject)
        hdr_row.addWidget(_close_x, 0, Qt.AlignmentFlag.AlignTop)
        inner.addLayout(hdr_row)
        inner.addSpacing(5)

        sub = QLabel("Select your network client, then fill in the project details.")
        sub.setObjectName("sub")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub.setWordWrap(True)
        inner.addWidget(sub)
        inner.addSpacing(20)

        # ── Client card builder ───────────────────────────────────────────────
        def _make_shadow(blur=20, dy=5, alpha=130):
            from qgis.PyQt.QtWidgets import QGraphicsDropShadowEffect
            from qgis.PyQt.QtGui import QColor as _QColor
            sh = QGraphicsDropShadowEffect()
            sh.setBlurRadius(blur)
            sh.setOffset(0, dy)
            sh.setColor(_QColor(0, 0, 0, alpha))
            return sh

        sel_row = QHBoxLayout()
        sel_row.setSpacing(12)

        # VUMA card
        vuma_card = QFrame()
        vuma_card.setObjectName("card_vuma")
        vuma_card.setProperty("active", "false")
        vuma_card.setGraphicsEffect(_make_shadow())
        _vc = QVBoxLayout(vuma_card)
        _vc.setContentsMargins(8, 8, 8, 10)
        _vc.setSpacing(7)
        vuma_btn = QPushButton("VUMA")
        vuma_btn.setObjectName("vuma_sel")
        vuma_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        vuma_sub = QLabel("GPON aerial · Britelink / VTC")
        vuma_sub.setObjectName("client_desc")
        vuma_sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        _vc.addWidget(vuma_btn)
        _vc.addWidget(vuma_sub)
        sel_row.addWidget(vuma_card)

        # fibertime card
        ft_card = QFrame()
        ft_card.setObjectName("card_ft")
        ft_card.setProperty("active", "false")
        ft_card.setGraphicsEffect(_make_shadow())
        _fc = QVBoxLayout(ft_card)
        _fc.setContentsMargins(8, 8, 8, 10)
        _fc.setSpacing(7)
        ft_btn = QPushButton("fibertime")
        ft_btn.setObjectName("ft_sel")
        ft_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        ft_sub = QLabel("Informal settlement · VelocityFibre")
        ft_sub.setObjectName("client_desc")
        ft_sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        _fc.addWidget(ft_btn)
        _fc.addWidget(ft_sub)
        sel_row.addWidget(ft_card)

        # HeroTel card
        herotel_card = QFrame()
        herotel_card.setObjectName("card_herotel")
        herotel_card.setProperty("active", "false")
        herotel_card.setGraphicsEffect(_make_shadow())
        _hc = QVBoxLayout(herotel_card)
        _hc.setContentsMargins(8, 8, 8, 10)
        _hc.setSpacing(7)
        herotel_btn = QPushButton("herotel")
        herotel_btn.setObjectName("herotel_sel")
        herotel_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        herotel_sub = QLabel("FTTH aerial · SDU & MDU")
        herotel_sub.setObjectName("client_desc")
        herotel_sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        _hc.addWidget(herotel_btn)
        _hc.addWidget(herotel_sub)
        sel_row.addWidget(herotel_card)

        inner.addLayout(sel_row)
        inner.addSpacing(18)

        # ── Project details section label ─────────────────────────────────────
        sec_lbl = QLabel("PROJECT DETAILS")
        sec_lbl.setObjectName("section_label")
        inner.addWidget(sec_lbl)
        inner.addSpacing(6)

        # ── Glass form container ───────────────────────────────────────────────
        form_box = QFrame()
        form_box.setObjectName("form_box")
        form_inner = QVBoxLayout(form_box)
        form_inner.setContentsMargins(14, 12, 14, 12)
        form_inner.setSpacing(8)

        def _field_row(label_txt, widget):
            row = QHBoxLayout()
            lbl = QLabel(label_txt)
            lbl.setObjectName("field_lbl")
            lbl.setFixedWidth(90)
            row.addWidget(lbl)
            row.addWidget(widget)
            return row

        proj_combo = QComboBox()
        proj_combo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        for disp, _code, _zone in _VUMA_PROJECTS:
            proj_combo.addItem(disp)
        proj_row_widget = QFrame()
        proj_row_widget.setLayout(_field_row("Project:", proj_combo))
        proj_row_widget.setVisible(False)
        form_inner.addWidget(proj_row_widget)

        area_edit = QLineEdit()
        area_edit.setPlaceholderText("e.g. MALM, PRAK, MOA")
        area_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        form_inner.addLayout(_field_row("Area Code:", area_edit))

        zone_edit = QLineEdit()
        zone_edit.setPlaceholderText("e.g. Z1, Z2  (Vuma only)")
        zone_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        zone_row_frame = QFrame()
        zone_row_frame.setLayout(_field_row("Zone:", zone_edit))
        zone_row_frame.setVisible(False)
        form_inner.addWidget(zone_row_frame)

        crs_combo = QComboBox()
        crs_combo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        for authid, desc in _CRS_OPTIONS:
            crs_combo.addItem(f"{authid}  —  {desc}", userData=authid)
        form_inner.addLayout(_field_row("CRS:", crs_combo))

        # AOI layer picker — pre-populated + updated live when layers are dropped
        aoi_combo = QComboBox()
        aoi_combo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        aoi_combo.setToolTip(
            "Drag a shapefile into the Layers panel — it auto-fills here.\n"
            "An AOI must be selected before you can start the project."
        )
        aoi_combo.addItem("— drag & drop AOI shapefile —", userData=None)
        _sys_names = {
            "Erven", "Buildings", "P2 AOI Poly", "Aggregation Polygon", "Block",
            "Poles", "Dome Joint", "Spur Joints", "Feeder Joints", "Demand Points",
        }
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name() in _sys_names:
                continue
            try:
                gtype = lyr.geometryType()
            except Exception:
                _swallowed_note(); continue
            if gtype == QgsWkbTypes.GeometryType.PolygonGeometry and lyr.featureCount() > 0:
                aoi_combo.addItem(
                    f"{lyr.name()}  ({lyr.featureCount()} features)",
                    userData=lyr.id(),
                )
        form_inner.addLayout(_field_row("AOI Layer:", aoi_combo))

        aoi_error_lbl = QLabel("⚠  AOI required — drag & drop a shapefile into the Layers panel")
        aoi_error_lbl.setStyleSheet(
            f"QLabel {{ color: {theme_safe.colors()['bad']}; font-size: 11px; font-style: italic;"
            " padding-left: 96px; margin-top: 0px; }}"
        )
        aoi_error_lbl.setVisible(False)
        form_inner.addWidget(aoi_error_lbl)

        # ── Project folder ────────────────────────────────────────────────────
        from qgis.PyQt.QtWidgets import QFileDialog
        folder_row = QHBoxLayout()
        folder_row.setSpacing(6)
        folder_lbl = QLabel("Save Folder:")
        folder_lbl.setObjectName("field_lbl")
        folder_lbl.setFixedWidth(90)
        folder_edit = QLineEdit()
        folder_edit.setPlaceholderText("Choose folder for shapefiles…")
        folder_edit.setReadOnly(True)
        folder_edit.setStyleSheet(
            "QLineEdit { background: #091220; color: #4A5570;"
            " border: 1px solid #1A2840; border-radius: 8px; padding: 8px 12px; }"
            "QLineEdit[populated='true'] { color: #B0BAD0; border-color: #22c55e; }"
        )
        browse_btn = QPushButton("Browse")
        browse_btn.setObjectName("cancel_btn")
        browse_btn.setFixedWidth(72)
        browse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        folder_row.addWidget(folder_lbl)
        folder_row.addWidget(folder_edit)
        folder_row.addWidget(browse_btn)
        form_inner.addLayout(folder_row)

        inner.addWidget(form_box)
        inner.addSpacing(18)

        def _browse_folder():
            path = QFileDialog.getExistingDirectory(
                dlg, "Select folder for shapefiles"
            )
            if path:
                folder_edit.setText(path)
                folder_edit.setProperty("populated", "true")
                folder_edit.style().unpolish(folder_edit)
                folder_edit.style().polish(folder_edit)

        browse_btn.clicked.connect(_browse_folder)

        act_row = QHBoxLayout()
        act_row.setSpacing(12)
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setObjectName("cancel_btn")
        start_btn = QPushButton("Start Project")
        start_btn.setObjectName("start_btn")
        start_btn.setEnabled(False)
        start_btn.setGraphicsEffect(_make_shadow(blur=14, dy=3, alpha=100))
        act_row.addStretch()
        act_row.addWidget(cancel_btn)
        act_row.addWidget(start_btn)
        inner.addLayout(act_row)

        # ── Logic ─────────────────────────────────────────────────────────────
        def _refresh_card(card, active):
            card.setProperty("active", "true" if active else "false")
            card.style().unpolish(card)
            card.style().polish(card)

        _ACCENT_STYLES = {
            "vuma":      ("stop:0 #FF1FA0, stop:0.5 #CC0072, stop:1 #FF1FA0",),
            "fibretime": ("stop:0 #2ABFCC, stop:0.4 #FFE619, stop:1 #2ABFCC",),
            "herotel":   ("stop:0 #FF5500, stop:0.5 #CC3A00, stop:1 #FF5500",),
        }

        def _on_proj_preset(idx):
            _disp, code, zone = _VUMA_PROJECTS[idx]
            if code:
                area_edit.setText(code)
                zone_edit.setText(zone)

        proj_combo.currentIndexChanged.connect(_on_proj_preset)

        def _select(client):
            _chosen["client"] = client
            is_vuma = client == "vuma"
            _refresh_card(vuma_card, is_vuma)
            _refresh_card(ft_card, client == "fibretime")
            _refresh_card(herotel_card, client == "herotel")
            # Dynamic accent bar — changes to selected client's brand color
            stops = _ACCENT_STYLES.get(client, ("stop:0 #7060D8, stop:1 #7060D8",))[0]
            accent_bar.setStyleSheet(
                f"QFrame#accent_bar {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0,"
                f" {stops}); border-top-left-radius: 20px; border-top-right-radius: 20px; }}"
            )
            proj_row_widget.setVisible(is_vuma)
            zone_row_frame.setVisible(is_vuma)
            if is_vuma:
                area_edit.setPlaceholderText("e.g. MALM, PRAK, MOA")
            elif client == "herotel":
                area_edit.setPlaceholderText("e.g. HRT, KRN, BRK")
            else:
                area_edit.setPlaceholderText("e.g. MOA, VEL")
            _validate()

        # ── AOI validation — blocks Start until a real layer is chosen ──────────
        _AOI_COMBO_ERROR = (
            "QComboBox { background: #1A0808; color: #C0BAD0;"
            " border: 1.5px solid #EF4444; border-radius: 8px; padding: 6px 10px; }"
            "QComboBox::drop-down { border: none; width: 24px; }"
            "QComboBox QAbstractItemView { background: #0D1B2E; color: #B0BAD0;"
            " selection-background-color: #1A2840; }"
        )

        def _validate():
            client = _chosen.get("client")
            has_aoi = aoi_combo.currentData() is not None
            if not client:
                # No client chosen yet — neutral, button already disabled
                aoi_combo.setStyleSheet("")
                aoi_error_lbl.setVisible(False)
                start_btn.setEnabled(False)
            elif not has_aoi:
                # Client chosen but no AOI — show red + block
                aoi_combo.setStyleSheet(_AOI_COMBO_ERROR)
                aoi_error_lbl.setVisible(True)
                start_btn.setEnabled(False)
            else:
                # Both client + AOI — clear and enable
                aoi_combo.setStyleSheet("")
                aoi_error_lbl.setVisible(False)
                start_btn.setEnabled(True)
            _reposition()

        aoi_combo.currentIndexChanged.connect(_validate)

        vuma_btn.clicked.connect(lambda: _select("vuma"))
        ft_btn.clicked.connect(lambda: _select("fibretime"))
        herotel_btn.clicked.connect(lambda: _select("herotel"))

        # ── Live AOI detection — fires when planner drops a shapefile ─────────
        # Do NOT filter by _sys_names here — on a blank project the user's
        # shapefile IS the AOI, even if it happens to share a system name.
        def _on_layers_added(layers):
            for lyr in layers:
                try:
                    gtype = lyr.geometryType()
                except Exception:
                    _swallowed_note(); continue
                if gtype == QgsWkbTypes.GeometryType.PolygonGeometry:
                    label = f"{lyr.name()}  ({lyr.featureCount()} features)"
                    # Avoid duplicates (keyed by layer ID)
                    existing = [aoi_combo.itemData(i) for i in range(aoi_combo.count())]
                    if lyr.id() not in existing:
                        aoi_combo.addItem(label, userData=lyr.id())
                    # Auto-select the newly dropped layer
                    idx = aoi_combo.findData(lyr.id())
                    if idx >= 0:
                        aoi_combo.setCurrentIndex(idx)
                    # Dismiss the blinking arrow — planner has loaded an AOI
                    _stop_arrow()

        QgsProject.instance().layersAdded.connect(_on_layers_added)

        # ── Start Project — save SESSION and kick off step 01 ─────────────────
        _cleaned_up = [False]

        def _cleanup():
            if _cleaned_up[0]:
                return
            _cleaned_up[0] = True
            # Clear singleton ref so next call starts fresh
            if getattr(self, '_welcome_dlg', None) is dlg:
                self._welcome_dlg = None
            _blink_timer.stop()
            try:
                arrow.hide()
                arrow.deleteLater()
            except RuntimeError:
                pass
            try:
                QgsProject.instance().layersAdded.disconnect(_on_layers_added)
            except Exception:
                _swallowed_note()

        def _on_start():
            client = _chosen["client"]
            if not client:
                return
            authid = crs_combo.currentData()
            folder = folder_edit.text().strip() or None

            # Save session if fibre_automation is installed — optional, never blocks dialog close
            try:
                from fibre_automation.startup import SESSION, save_session_to_project
                SESSION.update({
                    "client":         client,
                    "area_code":      area_edit.text().strip().upper() or None,
                    "zone_code":      zone_edit.text().strip() or None,
                    "crs":            QgsCoordinateReferenceSystem(authid),
                    "aoi_source":     aoi_combo.currentData(),
                    "project_folder": folder,
                })
                save_session_to_project()
            except Exception:
                _swallowed_note()  # fibre_automation missing OR session-save errored — never block
                      # the dialog close (contract: session save is best-effort)

            _cleanup()
            dlg.close()
            # Defer post-close work — calling QGIS setup directly from a
            # button click handler while the dialog is being destroyed can
            # cause a Qt access violation.
            _chosen_client = client

            def _post_start():
                try:
                    self._rebuild_automation_group(_chosen_client.upper())
                    self._lock_dock_to_client(_chosen_client.upper())
                except Exception as e:
                    self.iface.messageBar().pushWarning("New Project", f"Toolbar rebuild failed: {e}")
                try:
                    if _chosen_client in ("ft", "fibretime"):
                        from fibre_automation.fibretime.step_01_setup import ft_step_01_setup
                        ft_step_01_setup()
                    elif _chosen_client == "herotel":
                        from fibre_automation.herotel.step_01_setup import herotel_step_01_setup
                        herotel_step_01_setup()
                    else:
                        from fibre_automation.vuma.step_01_setup import vuma_step_01_setup
                        vuma_step_01_setup()
                except Exception as e:
                    self._log_and_push_critical("New Project (Step 01)", e)
                    import traceback
                    traceback.print_exc()

                # Always run clean buildings as the final startup step — silently
                # skips if Buildings / Erven layers are missing or empty.
                self._run_clean_buildings(silent_if_missing=True)

            QTimer.singleShot(50, _post_start)

        start_btn.clicked.connect(_on_start)

        cancel_btn.clicked.connect(lambda: (_cleanup(), dlg.close()))
        dlg.finished.connect(lambda _r: _cleanup())

        # ── Position dialog + arrow ───────────────────────────────────────────
        def _reposition():
            if _cleaned_up[0]:
                return
            dlg.adjustSize()
            # Centre over the map canvas widget, not the full main window
            canvas = self.iface.mapCanvas()
            canvas_tl = canvas.mapToGlobal(canvas.rect().topLeft())
            dlg_x = canvas_tl.x() + (canvas.width() - dlg.width()) // 2
            dlg_y = canvas_tl.y() + (canvas.height() - dlg.height()) // 2
            dlg.move(dlg_x, dlg_y)

            # Find right edge of the Layers dock to anchor the arrow
            mw_geo = mw.geometry()
            layers_right = mw_geo.x() + 230  # default fallback
            try:
                for dw in mw.findChildren(QDockWidget):
                    if "layer" in (dw.windowTitle() or "").lower():
                        pt = dw.mapToGlobal(QPoint(dw.width(), 0))
                        layers_right = pt.x()
                        break
            except Exception:
                _swallowed_note()

            gap_center_x = layers_right + (dlg_x - layers_right) // 2
            try:
                arrow_x = gap_center_x - arrow.width() // 2
                arrow_y = dlg_y + (dlg.height() - arrow.height()) // 2
                # Convert global → main-window-local coords
                arrow_local = mw.mapFromGlobal(QPoint(arrow_x, arrow_y))
                arrow.move(arrow_local)
                arrow.raise_()
                arrow.show()
            except RuntimeError:
                pass  # arrow already deleted after _cleanup()

        _reposition()
        _blink_timer.start()
        dlg.show()

    # ── Unload ────────────────────────────────────────────────────────────────
    def unload(self):
        from qgis.PyQt import sip
        boq_dialog = getattr(self, '_herotel_boq_dialog', None)
        if boq_dialog is not None and not sip.isdeleted(boq_dialog):
            boq_dialog.close()
        self._herotel_boq_dialog = None
        """Idempotent: safe to call multiple times; swallows C++-deleted-object errors."""
        # Stop instance-owned delayed UI work before removing any toolbar/dock.
        # Static singleShot callbacks once survived into the next plugin instance.
        for timer in list(getattr(self, "_ui_heal_timers", []) or []):
            try:
                timer.stop()
                timer.timeout.disconnect()
                timer.deleteLater()
            except Exception:
                _swallowed_note()
        self._ui_heal_timers = []
        try:
            from .nexus_dock import uninstall_dock_chrome_watcher
            uninstall_dock_chrome_watcher(
                self.iface.mainWindow(),
                getattr(self, "_dock_chrome_watcher", None))
        except Exception:
            _swallowed_note()
        self._dock_chrome_watcher = None
        # Take the smooth-drag filters off every dock, including docks owned by
        # OTHER plugins (the VeloGIS Bridge dock). A filter left on another
        # plugin's dock runs our code during ITS unload, after our module is gone.
        try:
            from . import nexus_drag as _ndrag
            _ndrag.uninstall_all(self.iface.mainWindow())
        except Exception:
            _swallowed_note()
        # Save and destroy the two independently hosted Nexus docks BEFORE their
        # callbacks or the home panel are torn down. These docks are parented by
        # QGIS's main window, so deleting the home panel alone does not remove them.
        try:
            from . import nexus_dock as _nd
            tools_area = getattr(self, "_tools_dockarea", None)
            if tools_area is not None:
                _nd.save_layout(tools_area)
        except Exception:
            _swallowed_note()
        tools_dock = getattr(self, "_tools_dock", None)
        home_panel = getattr(self, "_home_panel", None)
        try:
            if home_panel is not None:
                home_panel._forget_tools_dock(tools_dock)
        except Exception:
            _swallowed_note()
        self._dispose_owned_dock(tools_dock)
        self._tools_dock = None
        self._tools_dockarea = None

        label_dock = getattr(self, "_label_my_network_dock", None)
        try:
            panel = getattr(label_dock, "_panel", None)
            if panel is not None:
                panel.save_session()
        except Exception:
            _swallowed_note()
        self._dispose_owned_dock(label_dock)
        self._label_my_network_dock = None
        self._clear_labeling_dock_singletons()  # calls module _forget_dock()
        # Span Inspector first: drop its canvas rubber band and layer-edit signal
        # connections before anything else is torn down, so a reload can't leave a
        # highlight painted over the map or a signal pointing at a dead panel.
        try:
            from .span_inspector import close_span_inspector
            close_span_inspector()
        except Exception:
            _swallowed_note()
        # Persist the Network Planner session BEFORE the dock is destroyed, so a
        # one-click update (which unloads + reloads the plugin) doesn't leave the
        # user's splitters/zones/groups "dead" — the fresh dock re-binds them.
        try:
            from qgis.PyQt import sip
            np = getattr(self, '_np_dock', None)
            if np is not None and not sip.isdeleted(np) and hasattr(np, '_session_save'):
                np._session_save()
        except Exception:
            _swallowed_note()
        try:
            from .fibre_automation.nexus_profile import error_capture
            error_capture.uninstall()
        except Exception:
            _swallowed_note()
        try:
            if getattr(self, '_freeze_watchdog', None) is not None:
                self._freeze_watchdog.stop()
                self._freeze_watchdog = None
        except Exception:
            _swallowed_note()
        try:
            if getattr(self, '_geometry_guardian', None) is not None:
                self._geometry_guardian.stop()
                self._geometry_guardian = None
        except Exception:
            _swallowed_note()
        try:
            if getattr(self, '_nexus', None) is not None:
                self._nexus.unload()
                self._nexus = None
        except Exception:
            _swallowed_note()
        try:
            if getattr(self, '_update_checker', None) is not None:
                self._update_checker.stop()
                self._update_checker = None
        except Exception:
            _swallowed_note()
        # Deregister the native locator filter
        try:
            if getattr(self, '_locator', None) is not None:
                self.iface.deregisterLocatorFilter(self._locator)
                self._locator = None
        except Exception:
            _swallowed_note()
        # Disconnect project signals
        try:
            from qgis.core import QgsProject
            QgsProject.instance().readProject.disconnect(self._on_project_read)
            QgsProject.instance().cleared.disconnect(self._on_project_cleared)
        except Exception:
            _swallowed_note()
        try:
            from qgis.core import QgsProject
            # _install_home_panel connects BOTH slots (incl. _home_refresh_debounced);
            # disconnect both or the debounced slot leaks on the dead instance.
            for _sig in (QgsProject.instance().layersAdded,
                         QgsProject.instance().layersRemoved):
                for _slot in (self._refresh_home_steps, self._home_refresh_debounced):
                    try:
                        _sig.disconnect(_slot)
                    except (TypeError, RuntimeError):
                        pass
        except Exception:
            _swallowed_note()
        # Disconnect the external bridge dock's client_changed (it lives in a
        # different plugin that isn't unloaded — leaks the old instance otherwise).
        try:
            dock = self._get_bridge_dock()
            if dock is not None:
                dock.client_changed.disconnect(self._rebuild_automation_group)
        except Exception:
            _swallowed_note()
        try:
            self.iface.newProjectCreated.disconnect(self._on_new_project_created)
        except Exception:
            _swallowed_note()

        # VeloPlan menu
        try:
            if getattr(self, '_velo_menu', None) is not None:
                self.iface.mainWindow().menuBar().removeAction(self._velo_menu.menuAction())
                self._velo_menu.deleteLater()
        except (RuntimeError, AttributeError):
            pass
        self._velo_menu = None

        # Erven Detection dock (ported erven_qgis_plugin panel)
        try:
            if getattr(self, '_erven_detection_panel', None) is not None:
                self.iface.removeDockWidget(self._erven_detection_panel)
                self._erven_detection_panel.deleteLater()
        except (RuntimeError, AttributeError):
            pass
        self._erven_detection_panel = None

        # Timer first — prevent further _bridge_tick calls on deleted widgets
        try:
            if self._bridge_timer:
                self._bridge_timer.stop()
        except RuntimeError:
            pass
        self._bridge_timer = None
        try:
            if getattr(self, "_absorb_watchdog", None):
                self._absorb_watchdog.stop()
        except RuntimeError:
            pass
        self._absorb_watchdog = None

        # Account-guard timer — was leaking on every reload (fires _check_account_active
        # against a torn-down instance). Stop it like every other timer.
        try:
            if getattr(self, "_acct_timer", None):
                self._acct_timer.stop()
                self._acct_timer.timeout.disconnect()
        except (RuntimeError, TypeError):
            pass
        self._acct_timer = None

        # Home-context debounce timer — stop so it can't fire _refresh_home_steps
        # against a torn-down panel after unload.
        try:
            if getattr(self, "_home_ctx_timer", None):
                self._home_ctx_timer.stop()
                self._home_ctx_timer.timeout.disconnect()
        except (RuntimeError, TypeError):
            pass
        self._home_ctx_timer = None

        # Deferred-update poller (module-global in update_check) — cancel so it
        # can't survive this unload and trigger a second hot-reload.
        try:
            from . import update_check as _uc
            _uc.cancel_deferred()
        except Exception:
            _swallowed_note()

        # HLD tile + timer — every reload was leaking another tile (2026-04-28).
        try:
            if getattr(self, "_hld_timer", None):
                self._hld_timer.stop()
                self._hld_timer.timeout.disconnect()
        except RuntimeError:
            pass
        self._hld_timer = None
        try:
            tile = getattr(self, "_hld_score_tile", None)
            self._hld_score_tile = None   # null FIRST so queued callbacks see None
            if tile is not None:
                self.iface.statusBarIface().removeWidget(tile)
                tile.deleteLater()
        except (RuntimeError, AttributeError):
            self._hld_score_tile = None

        # Command palette shortcut
        try:
            sc = getattr(self, "_cmd_palette_shortcut", None)
            if sc is not None:
                sc.setEnabled(False)
                sc.deleteLater()
        except (RuntimeError, AttributeError):
            pass
        self._cmd_palette_shortcut = None

        # Mirror eye + its timer
        try:
            t = getattr(self, "_mirror_eye_timer", None)
            if t is not None:
                t.stop()
        except RuntimeError:
            pass
        self._mirror_eye_timer = None
        try:
            eye = getattr(self, "_mirror_eye", None)
            if eye is not None:
                eye.setParent(None)
                eye.hide()
                eye.deleteLater()
        except (RuntimeError, AttributeError):
            pass
        self._mirror_eye = None

        try:
            # Prefer the live registry entry over the potentially-dead Python wrapper.
            # If self.provider's C++ object was already deleted (e.g. addProvider failed
            # and QGIS cleaned it up), calling removeProvider(dead_ptr) silently no-ops
            # inside QGIS but leaves the "fibernetwork" key in the C++ map → zombie.
            reg = QgsApplication.processingRegistry()
            live = reg.providerById("fibernetwork")
            target = None
            try:
                if live and live.id() == "fibernetwork":
                    target = live
            except RuntimeError:
                pass
            if target is None and self.provider:
                try:
                    if self.provider.id() == "fibernetwork":
                        target = self.provider
                except RuntimeError:
                    pass
            if target is not None:
                reg.removeProvider(target)
        except Exception:
            _swallowed_note()
        self.provider = None

        # Restore fibretime toolbars we hid during absorb
        try:
            absorbed = getattr(self, "_absorbed_from", None)
            if absorbed:
                for tb in absorbed:
                    if tb is not None:
                        try: tb.show()
                        except RuntimeError: pass
        except Exception:
            _swallowed_note()
        self._absorbed_from = None
        self._fibretime_absorbed = False

        try:
            if self._toolbar:
                self._toolbar.clear()
                self.iface.mainWindow().removeToolBar(self._toolbar)
        except RuntimeError:
            pass
        self._toolbar = None

        try:
            from qgis.PyQt import sip
            if self._pole_editor_panel is not None:
                self._pole_editor_panel._teardown()
            d = getattr(self, '_pole_editor_dock', None)
            if d is not None and not sip.isdeleted(d):
                self.iface.removeDockWidget(d); d.deleteLater()
        except Exception:
            _swallowed_note()
        self._pole_editor_dock = None
        self._pole_editor_panel = None

        try:
            if self._route_viewer_panel is not None:
                self._route_viewer_panel.cleanup()
        except Exception:
            _swallowed_note()
        try:
            from qgis.PyQt import sip
            d = getattr(self, '_route_viewer_dock', None)
            if d is not None and not sip.isdeleted(d):
                self.iface.removeDockWidget(d)
                d.deleteLater()
        except Exception:
            _swallowed_note()
        self._route_viewer_dock = None
        self._route_viewer_panel = None

        try:
            if self._home_panel:
                self.iface.removeDockWidget(self._home_panel)
                self._home_panel.deleteLater()
        except RuntimeError:
            pass
        self._home_panel = None

        try:
            if self._np_dock:
                self.iface.removeDockWidget(self._np_dock)
                self._np_dock.deleteLater()
        except RuntimeError:
            pass
        self._np_dock = None

        try:
            from qgis.PyQt import sip
            if self._enc_editor_panel is not None:
                self._enc_editor_panel._teardown()
            d = getattr(self, '_enc_editor_dock', None)
            if d is not None and not sip.isdeleted(d):
                self.iface.removeDockWidget(d); d.deleteLater()
        except Exception:
            _swallowed_note()
        self._enc_editor_dock = None
        self._enc_editor_panel = None

        # WA_DeleteOnClose dialogs parented to mainWindow() — close any that are
        # still open so they don't linger / leave dangling SIP wrappers on reload.
        try:
            from qgis.PyQt import sip
            for _attr in ('_team_guide_dlg', '_welcome_dlg', '_problem_dlg'):
                _d = getattr(self, _attr, None)
                if _d is None:
                    continue
                # _problem_dlg wraps the real QDialog in a .dlg attribute.
                _qd = getattr(_d, 'dlg', _d)
                try:
                    if _qd is not None and not sip.isdeleted(_qd):
                        _qd.close()
                except Exception:
                    _swallowed_note()
                setattr(self, _attr, None)
        except Exception:
            _swallowed_note()

        try:                                  # SAM2 detect poll-timer could fire into a torn-down plugin
            if getattr(self, "_erven_detect_poll_timer", None):
                self._erven_detect_poll_timer.stop()
        except (RuntimeError, AttributeError):
            pass
        self._erven_detect_poll_timer = None

        self._actions.clear()
        self._brand_label = None
        self._brand_status = None

    # ── Erven Detection (SAM2 + GroundingDINO via erven_mcp) ─────────────────

    def _erven_detect_run(self):
        """AI Detect button — SAM2 building footprints only (Buildings_detected)."""
        self._ai_detect_run(run_tessellation=False)

    def _erven_erven_run(self):
        """AI Erven button — buildings + momepy parcel tessellation (+ Erven_detected)."""
        self._ai_detect_run(run_tessellation=True)

    def _ai_detect_run(self, run_tessellation: bool = False):
        """Shared runner for AI Detect / AI Erven buttons.

        Posts to erven_mcp HTTP server on port 8780, polls progress every 2s,
        calls _erven_detect_on_complete() when done.

        Args:
            run_tessellation: If True, also generate Erven_detected property parcels
                              via momepy enclosed_tessellation (requires roads.json).
        """
        import json as _json
        import urllib.request

        from qgis.PyQt.QtCore import QTimer

        ERVEN_MCP_URL = "http://127.0.0.1:8780"
        iface = self.iface
        label = "AI Erven" if run_tessellation else "AI Detect"

        # ── Check server is up ───────────────────────────────────────────────
        try:
            with urllib.request.urlopen(f"{ERVEN_MCP_URL}/health", timeout=3):
                pass
        except Exception:
            iface.messageBar().pushMessage(
                label,
                "❌ erven_mcp server not running on port 8780.  "
                "Start: cd erven_detection/src && python -m erven_mcp.server --http",
                level=Qgis.MessageLevel.Critical, duration=20,
            )
            return

        # ── POST /pipeline/run ───────────────────────────────────────────────
        config = {
            "source": "canvas",
            "preset": "sa_formal_low",
            "run_tessellation": run_tessellation,
            "roads_source": "roads_json",
            "roads_json_path": "C:/Temp/roads.json",
        }
        payload = _json.dumps(config).encode("utf-8")
        req = urllib.request.Request(
            f"{ERVEN_MCP_URL}/pipeline/run",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                start_data = _json.loads(resp.read().decode("utf-8"))
        except Exception as exc:
            iface.messageBar().pushMessage(
                label, f"Could not start pipeline: {exc}", level=Qgis.MessageLevel.Critical, duration=10,
            )
            return

        if not start_data.get("started"):
            msg = start_data.get("message", "Pipeline not started")
            iface.messageBar().pushMessage(label, msg, level=Qgis.MessageLevel.Warning, duration=8)
            return

        est = "~5–10 min (buildings + erven)" if run_tessellation else "~3–7 min"
        iface.messageBar().pushMessage(
            label,
            f"⏳ SAM2 running… ({est})  Polling every 2s…",
            level=Qgis.MessageLevel.Info, duration=120,
        )

        # ── Poll /progress every 2 s ─────────────────────────────────────────
        poll_timer = QTimer(iface.mainWindow())   # parented so teardown can't orphan it
        poll_timer.setInterval(2000)
        plugin_self = self

        def _poll():
            try:
                with urllib.request.urlopen(
                    f"{ERVEN_MCP_URL}/progress", timeout=3
                ) as r:
                    prog = _json.loads(r.read().decode("utf-8"))
            except Exception:
                return  # transient error — keep polling

            # Default to False so a malformed/partial progress body (missing the
            # 'pipeline_running' key) STOPS the poll instead of looping forever.
            still_running = prog.get("pipeline_running", False)
            step    = prog.get("step", "")
            pct     = int(prog.get("progress", 0) * 100)
            message = prog.get("message", "")

            if still_running:
                iface.messageBar().pushMessage(
                    label,
                    f"[{pct}%] {step}: {message}",
                    level=Qgis.MessageLevel.Info, duration=3,
                )
                return

            poll_timer.stop()
            plugin_self._erven_detect_poll_timer = None
            plugin_self._erven_detect_on_complete(run_tessellation=run_tessellation)

        poll_timer.timeout.connect(_poll)
        poll_timer.start()
        self._erven_detect_poll_timer = poll_timer
        self._erven_mcp_url = ERVEN_MCP_URL

    def _erven_detect_on_complete(self, run_tessellation: bool = False):
        """Fetch /pipeline/result and show summary in the status bar."""
        import json as _json
        import urllib.request

        iface = self.iface
        url   = getattr(self, "_erven_mcp_url", "http://127.0.0.1:8780")
        label = "AI Erven" if run_tessellation else "AI Detect"

        try:
            with urllib.request.urlopen(f"{url}/pipeline/result", timeout=5) as r:
                result = _json.loads(r.read().decode("utf-8"))
        except Exception as exc:
            iface.messageBar().pushMessage(
                label, f"Could not fetch result: {exc}", level=Qgis.MessageLevel.Critical, duration=10,
            )
            return

        error = result.get("error")
        if error:
            failed_step = result.get("failed_step", "unknown")
            iface.messageBar().pushMessage(
                label,
                f"❌ Failed at step '{failed_step}': {error}",
                level=Qgis.MessageLevel.Critical, duration=15,
            )
            return

        n_buildings = result.get("num_buildings", result.get("num_erven", 0))
        n_erven     = result.get("num_erven", 0)    # only set if tessellation ran
        elapsed     = result.get("elapsed_s", 0)
        summary     = result.get("summary", f"{n_buildings} buildings")

        # Pipeline already loaded layer(s) via the bridge — just refresh canvas
        iface.mapCanvas().refreshAllLayers()
        iface.mapCanvas().refresh()

        if run_tessellation and n_erven:
            layers_msg = f"'Buildings_detected' + 'Erven_detected' ({n_erven} parcels)"
        else:
            layers_msg = "'Buildings_detected'"

        iface.messageBar().pushMessage(
            label,
            f"✅ {summary}  — {layers_msg} added to canvas"
            + (f" in {float(elapsed):.0f} s" if isinstance(elapsed, (int, float)) and elapsed else ""),
            level=Qgis.MessageLevel.Success, duration=15,
        )

    # ──────────────────────────────────────────────────────────────────────────
    # VeloDetect — batch SAM2 building detection over full AOI
    # ──────────────────────────────────────────────────────────────────────────

    def _place_ai_results(self, results, iface_ref):
        """Create 'AI Buildings' polygon + 'AI Centroids' point memory layers.

        Used by VeloDetect (_velo_detect_run).
        results: list of (cx_lon, cx_lat, [(lon, lat), ...])
        """
        from qgis.core import (
            QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY,
            QgsProject, QgsField,
            QgsSingleSymbolRenderer, QgsFillSymbol, QgsMarkerSymbol,
        )
        from qgis.PyQt.QtCore import QMetaType  # used by QgsField below (was NameError)

        proj = QgsProject.instance()

        poly_vl = QgsVectorLayer("Polygon?crs=EPSG:4326", "AI Buildings", "memory")
        poly_pr = poly_vl.dataProvider()
        poly_pr.addAttributes([QgsField("idx", QMetaType.Type.Int)])
        poly_vl.updateFields()
        poly_feats = []
        for i, (cx, cy, poly_pts) in enumerate(results):
            f = QgsFeature()
            f.setGeometry(QgsGeometry.fromPolygonXY(
                [[QgsPointXY(lon, lat) for lon, lat in poly_pts]]))
            f.setAttributes([i + 1])
            poly_feats.append(f)
        poly_pr.addFeatures(poly_feats)
        poly_vl.updateExtents()
        poly_vl.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple({
            "color": "0,212,255,60", "outline_color": "0,212,255,255",
            "outline_width": "0.5", "outline_width_unit": "MM",
        })))

        pt_vl = QgsVectorLayer("Point?crs=EPSG:4326", "AI Centroids", "memory")
        pt_pr = pt_vl.dataProvider()
        pt_pr.addAttributes([
            QgsField("idx", QMetaType.Type.Int),
            QgsField("lon", QMetaType.Type.Double),
            QgsField("lat", QMetaType.Type.Double),
        ])
        pt_vl.updateFields()
        pt_feats = []
        for i, (cx, cy, _) in enumerate(results):
            f = QgsFeature()
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(cx, cy)))
            f.setAttributes([i + 1, round(cx, 6), round(cy, 6)])
            pt_feats.append(f)
        pt_pr.addFeatures(pt_feats)
        pt_vl.updateExtents()
        pt_vl.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple({
            "name": "circle", "color": "255,210,0,220",
            "size": "2", "size_unit": "MM", "outline_style": "no",
        })))

        for name in ("AI Buildings", "AI Centroids"):
            for old in proj.mapLayersByName(name):
                proj.removeMapLayer(old)
        proj.addMapLayer(poly_vl)
        proj.addMapLayer(pt_vl)

    def _velo_detect_run(self):
        """Tile the full AOI and send each chip to the SAM2 server.

        Renders 512×512 JPEG tiles at 0.3 m/px, POSTs to SAM2 at :8101,
        collects building polygons, deduplicates at tile borders, and places
        results as 'AI Buildings' + 'AI Centroids' memory layers.
        """
        import math
        import json
        import urllib.request
        from qgis.core import (
            QgsProject, QgsMapSettings, QgsMapRendererCustomPainterJob,
            QgsRectangle, QgsGeometry, QgsPointXY,
            QgsCoordinateTransform, QgsCoordinateReferenceSystem,
        )
        from qgis.PyQt.QtCore import QSize, QBuffer, Qt
        from qgis.PyQt.QtGui import QImage, QPainter, QColor
        from qgis.PyQt.QtWidgets import QProgressDialog, QApplication

        SAM2_URL = "http://127.0.0.1:8102/predict"
        GSD_M    = 0.3    # target ground sampling distance (m/pixel)
        TILE_PX  = 512
        MIN_AREA = 50     # min mask area in pixels² (≈15 m² at 0.3 m/px)

        canvas       = self.iface.mapCanvas()
        map_settings = canvas.mapSettings()
        dest_crs     = map_settings.destinationCrs()
        wgs84        = QgsCoordinateReferenceSystem("EPSG:4326")
        proj         = QgsProject.instance()

        # ── 1. Ping SAM2 server ───────────────────────────────────────────────
        try:
            with urllib.request.urlopen(
                    SAM2_URL.replace("/predict", "/health"), timeout=4) as r:
                health = json.loads(r.read())
            if not health.get("model_loaded", False):
                self.iface.messageBar().pushMessage(
                    "AutoDetect",
                    "SAM2 server is up but model not loaded — check server logs.",
                    level=Qgis.MessageLevel.Critical, duration=10)
                return
        except Exception as exc:
            self.iface.messageBar().pushMessage(
                "AutoDetect",
                f"SAM2 server unreachable at {SAM2_URL}. "
                f"Run: python C:/Temp/sam2_server.py on 192.168.1.150  ({exc})",
                level=Qgis.MessageLevel.Critical, duration=15)
            return

        # ── 2. Find AOI layer ─────────────────────────────────────────────────
        aoi_geom = None
        aoi_bbox = None
        for name in ("P2 AOI Poly", "AOI", "Mohadin AOI", "AOI Poly"):
            layers = proj.mapLayersByName(name)
            if layers:
                feats = list(layers[0].getFeatures())
                if feats:
                    aoi_geom = feats[0].geometry()
                    # Null/empty geometry → boundingBox() returns a degenerate
                    # all-zero rect that bypasses the canvas-extent fallback.
                    if not aoi_geom or aoi_geom.isNull() or aoi_geom.isEmpty():
                        aoi_geom = None
                        continue
                    if layers[0].crs() != dest_crs:
                        xf = QgsCoordinateTransform(layers[0].crs(), dest_crs, proj)
                        aoi_geom.transform(xf)
                    aoi_bbox = aoi_geom.boundingBox()
                    break

        if aoi_bbox is None:
            # Fall back to current canvas extent
            aoi_bbox = canvas.extent()
            self.iface.messageBar().pushMessage(
                "AutoDetect",
                "No AOI layer found — using current canvas extent as AOI.",
                level=Qgis.MessageLevel.Warning, duration=6)

        # ── 3. Compute tile grid in CRS units ─────────────────────────────────
        cy = aoi_bbox.center().y()
        if dest_crs.isGeographic():
            m_per_lat = 110574.0
            m_per_lon = 111320.0 * math.cos(math.radians(cy))
            tile_w = (GSD_M * TILE_PX) / m_per_lon
            tile_h = (GSD_M * TILE_PX) / m_per_lat
        else:
            tile_w = tile_h = GSD_M * TILE_PX

        tiles = []
        y = aoi_bbox.yMinimum()
        while y < aoi_bbox.yMaximum():
            x = aoi_bbox.xMinimum()
            while x < aoi_bbox.xMaximum():
                tile_ext = QgsRectangle(x, y, x + tile_w, y + tile_h)
                if aoi_geom is None or aoi_geom.intersects(
                        QgsGeometry.fromRect(tile_ext)):
                    tiles.append(tile_ext)
                x += tile_w
            y += tile_h

        if not tiles:
            self.iface.messageBar().pushMessage(
                "AutoDetect", "No tiles generated — check AOI layer.", level=Qgis.MessageLevel.Critical, duration=8)
            return

        to_wgs84 = QgsCoordinateTransform(dest_crs, wgs84, proj)

        def _px2geo(px_x, px_y, tile_ext):
            mx = tile_ext.xMinimum() + (px_x / TILE_PX) * tile_ext.width()
            my = tile_ext.yMaximum() - (px_y / TILE_PX) * tile_ext.height()
            try:
                pt = to_wgs84.transform(QgsPointXY(mx, my))
                return (pt.x(), pt.y())
            except Exception:
                return (mx, my)

        # ── 4. Progress dialog ────────────────────────────────────────────────
        prog = QProgressDialog(
            f"AutoDetect — 0 / {len(tiles)} tiles", "Cancel", 0, len(tiles))
        prog.setWindowTitle("VeloDetect — Batch SAM2 Building Detection")
        prog.setWindowModality(Qt.WindowModality.WindowModal)
        prog.setMinimumDuration(0)
        prog.setValue(0)

        # ── 5. Tile → render → POST → collect ────────────────────────────────
        all_results = []
        errors      = 0

        for i, tile_ext in enumerate(tiles):
            QApplication.processEvents()
            if prog.wasCanceled():
                break

            prog.setLabelText(
                f"AutoDetect — {i}/{len(tiles)} tiles  "
                f"({len(all_results)} buildings so far)")

            # Render tile on main thread
            ts = QgsMapSettings()
            ts.setLayers(map_settings.layers())
            ts.setDestinationCrs(dest_crs)
            ts.setExtent(tile_ext)
            ts.setOutputSize(QSize(TILE_PX, TILE_PX))
            ts.setBackgroundColor(map_settings.backgroundColor())
            img = QImage(QSize(TILE_PX, TILE_PX), QImage.Format.Format_ARGB32)
            img.fill(QColor(255, 255, 255))
            painter = QPainter(img)
            job = QgsMapRendererCustomPainterJob(ts, painter)
            job.start()
            job.waitForFinished()
            painter.end()
            buf = QBuffer()
            buf.open(QBuffer.WriteOnly)
            img.save(buf, "JPEG", 85)
            jpg_bytes = bytes(buf.data())
            buf.close()

            # POST to SAM2 (synchronous, main thread — ~200-500 ms on GPU)
            try:
                boundary = b"VeloDetectBoundary7x3"
                body = (
                    b"--" + boundary + b"\r\n"
                    b'Content-Disposition: form-data; name="file"; filename="tile.jpg"\r\n'
                    b"Content-Type: image/jpeg\r\n\r\n"
                    + jpg_bytes
                    + b"\r\n--" + boundary + b"--\r\n"
                )
                req = urllib.request.Request(
                    SAM2_URL, data=body,
                    headers={"Content-Type":
                             f"multipart/form-data; boundary={boundary.decode()}"},
                    method="POST")
                with urllib.request.urlopen(req, timeout=60) as resp:
                    data = json.loads(resp.read())

                for bldg in data.get("buildings", []):
                    if bldg.get("area_px", 0) < MIN_AREA:
                        continue
                    cx_lon, cx_lat = _px2geo(bldg["cx_px"], bldg["cy_px"], tile_ext)
                    poly_pts = [_px2geo(p[0], p[1], tile_ext)
                                for p in bldg.get("polygon_px", [])]
                    if len(poly_pts) < 3:
                        poly_pts = [  # fallback bounding box
                            _px2geo(bldg["cx_px"]-10, bldg["cy_px"]-10, tile_ext),
                            _px2geo(bldg["cx_px"]+10, bldg["cy_px"]-10, tile_ext),
                            _px2geo(bldg["cx_px"]+10, bldg["cy_px"]+10, tile_ext),
                            _px2geo(bldg["cx_px"]-10, bldg["cy_px"]+10, tile_ext),
                        ]
                    all_results.append((cx_lon, cx_lat, poly_pts))

            except Exception as exc:
                errors += 1
                if errors <= 5:
                    print(f"[VeloDetect] tile {i} error: {exc}")

            prog.setValue(i + 1)

        prog.close()

        if not all_results:
            self.iface.messageBar().pushMessage(
                "AutoDetect",
                f"No buildings detected across {len(tiles)} tiles "
                f"({errors} tile errors).",
                level=Qgis.MessageLevel.Critical, duration=15)
            return

        # ── 6. Deduplicate cross-tile duplicates (5 m grid hash) ─────────────
        kept = []
        seen_cells = set()
        # cell size ≈ 5 m in degrees at Mohadin latitude.
        # all_results are WGS84 degrees (via _px2geo → to_wgs84), so the
        # cosine MUST use geographic latitude. cy is in dest_crs units (a
        # UTM northing when projected), so derive a real WGS84 latitude.
        ctr_geo = to_wgs84.transform(aoi_bbox.center())
        cell_lat = 5.0 / 110574.0
        cell_lon = 5.0 / (111320.0 * math.cos(math.radians(ctr_geo.y())))
        for cx, cl, poly in all_results:
            cell = (int(cx / cell_lon), int(cl / cell_lat))
            if cell not in seen_cells:
                seen_cells.add(cell)
                kept.append((cx, cl, poly))

        # ── 7. Place on canvas ────────────────────────────────────────────────
        self._place_ai_results(kept, self.iface)
        self.iface.messageBar().pushMessage(
            "AutoDetect",
            f"{len(kept)} buildings detected in {len(tiles)} tiles "
            f"({errors} errors). "
            f"Layers: 'AI Buildings' (cyan) · 'AI Centroids' (gold dots).",
            level=Qgis.MessageLevel.Success, duration=20)

# Panels live in splice_panels.py (moved verbatim 2026-09-22); re-exported so
# FiberNetworkPlugin and `from ..fiber_network_plugin import _PanelDock` keep working.
from .splice_panels import (  # noqa: E402,F401
    _BG,
    _PANEL,
    _ACCENT,
    _VIOLET,
    _BLUE,
    _GREEN,
    _RED,
    _AMBER,
    _TEXT,
    _DIM,
    _BORDER,
    _DIALOG_BG,
    _SECTION_LBL,
    _SUBTITLE_LBL,
    _STATUS_LBL,
    _HINT_LBL,
    _DIVIDER,
    _btn,
    _BTN_GREEN,
    _BTN_RED,
    _BTN_GRADIENT,
    _BTN_CLEAR,
    _BTN_S5,
    _BTN_ORANGE,
    _BTN_PURPLE,
    _BTN_CYAN,
    _BTN_TEAL,
    _SpinRing,
    _NullRing,
    _SpinRingPreview,
    _HOP_COLOURS,
    _HOP_TITLES,
    _RouteLabels,
    _ClickFrame,
    _PanelDock,
    SpliceRouteViewerPanel,
    _COMBO_CSS,
    PoleEditorPanel,
    EnclosureEditorPanel,
)
