# LayerView adapters. Two front ends, one set of checks.
#
#   from_qgis(project)     the layers open in JJ's QGIS - used by HT 6
#   from_ogr(path)         a GeoPackage on disk - used by the CLI
#
# Each returns plain LayerView objects, so `core.check()` never learns which one
# it is looking at. Both are read-only: the QGIS adapter only reads features and
# never opens an edit session, and the OGR adapter passes GDAL's read-only flag.
#
# ⛔ Import order matters if you also import hashlib in the same process - see
# the note at the top of research/herotel_schema/mapper.py. `import hashlib`
# before `from osgeo import gdal` breaks GDAL with "No module named '_gdal'".

from __future__ import annotations

from .core import VALUE_SAMPLE, LayerView


class QgisLayerView(LayerView):
    """A QgsVectorLayer, read-only.

    Feature counts come from the layer, not from a walk, so a big project stays
    fast. Values are sampled with a request that fetches only the columns being
    checked and no geometry at all - on a 13,570-feature Erven layer that is the
    difference between a check and a freeze.
    """

    def __init__(self, layer):
        self._layer = layer
        self.name = layer.name()

    @property
    def fields(self):
        return [f.name() for f in self._layer.fields()]

    @property
    def feature_count(self):
        n = self._layer.featureCount()
        return max(n, 0)              # -1 means "unknown" on some providers

    def sample_values(self, fields, limit=VALUE_SAMPLE):
        from qgis.core import QgsFeatureRequest

        names = [f for f in fields if f in self.fields]
        out = {n: set() for n in names}
        if not names:
            return out
        req = QgsFeatureRequest()
        req.setFlags(QgsFeatureRequest.Flag.NoGeometry)
        req.setSubsetOfAttributes(names, self._layer.fields())
        req.setLimit(int(limit))
        for feat in self._layer.getFeatures(req):
            for n in names:
                v = feat[n]
                if v is None:
                    continue
                s = str(v).strip()
                # QGIS hands back the literal string "NULL" for an unset field
                # on some providers. Treating it as a value would invent a
                # vocabulary member that is not in the data.
                if s and s.upper() != "NULL":
                    out[n].add(s)
        return out


class OgrLayerView(LayerView):
    """An OGR layer from a GeoPackage, opened read-only."""

    def __init__(self, layer):
        self._layer = layer
        self.name = layer.GetName()
        defn = layer.GetLayerDefn()
        self._fields = [defn.GetFieldDefn(i).GetName()
                        for i in range(defn.GetFieldCount())]

    @property
    def fields(self):
        return list(self._fields)

    @property
    def feature_count(self):
        return max(self._layer.GetFeatureCount(), 0)

    def sample_values(self, fields, limit=VALUE_SAMPLE):
        names = [f for f in fields if f in self._fields]
        out = {n: set() for n in names}
        if not names:
            return out
        self._layer.ResetReading()
        for i, feat in enumerate(self._layer):
            if i >= limit:
                break
            for n in names:
                v = feat.GetField(n)
                if v is None:
                    continue
                s = str(v).strip()
                if s and s.upper() != "NULL":
                    out[n].add(s)
        self._layer.ResetReading()
        return out


def from_qgis(project=None, layers=None):
    """Views over the open QGIS project (or an explicit layer list)."""
    from qgis.core import QgsProject, QgsVectorLayer

    if layers is None:
        proj = project or QgsProject.instance()
        layers = list(proj.mapLayers().values())
    return [QgisLayerView(l) for l in layers
            if isinstance(l, QgsVectorLayer) and l.isValid()]


def from_ogr(path):
    """Views over a dataset on disk. Returns (views, keepalive).

    ⚠ The GDAL Dataset must stay referenced for as long as the views are used -
    OGR layers are borrowed from it and go invalid the moment it is collected.
    That is why the dataset is handed back rather than closed here.
    """
    from osgeo import gdal

    gdal.UseExceptions()
    ds = gdal.OpenEx(str(path), gdal.OF_VECTOR | gdal.OF_READONLY)
    if ds is None:
        raise OSError(f"GDAL could not open {path}")
    views = [OgrLayerView(ds.GetLayer(i)) for i in range(ds.GetLayerCount())]
    return views, ds
