# -*- coding: utf-8 -*-
# claude:intent WRITE (edit buffer only) - user asked (JJ 2026-10-15): "build the click line vertex plus pole tool
#   into the span inspector ... underneath vertex measure ... my poles need to be 70 m apart, but I can't see where
#   70 m is" - plan: one Span Inspector row; a clean click on a cable adds a vertex there and a pole on it, while
#   the Vertex-measure marks show where 70 m is (a click near a mark lands exactly on it).
#   Pole Drop v2 (JJ GO 2026-10-16): hover shows every vertex (green = poled, orange = needs a pole), vertex snap
#   first, Shift+click = poles on every missing vertex, settings in the row, auto-pole a cable drawn with Add Line.
# claude:boq-impact adds one vertex + at most one pole per click (Shift+click / auto-pole: one pole per vertex
#   without one) to the project it is used in, edit buffer only; nothing reaches disk until the operator saves.
#   Refuses shipped projects (MOA / Mohadin PH2, Chloorkop, ' v1').
# claude:approved-destructive - edit-buffer adds only (no delete, no save); tested on memory layers.
"""Click line = vertex + pole (Span Inspector, under Vertex measure).

While ON the map tool is a Pan tool: a drag pans as usual. Hovering a cable (a line layer whose
name passes the cable rule - default: has 'cable', not 'drop') highlights it and every vertex on
it: a green dot where a pole already stands within the reuse distance, an orange ring where one
is missing. A clean click puts a pole there, in this order of priority:

  vertex  (within the vertex snap radius)  -> a pole on that vertex, the cable is not changed
  mark    (within MARK_PX of a 'Mark every' mark) -> a vertex + pole exactly on the mark
  line    -> a vertex + pole where clicked

Shift+click on a hovered cable puts a pole on every vertex of it that has none (ends included
unless switched off), in ONE edit command (one Ctrl+Z). A pole already within the reuse distance
is reused, never doubled. Afterwards every target vertex is checked again; any still without a
pole is reported in the message bar. (The click tool drops the Pan tool's Shift+drag zoom
rectangle: with it, QgsMapCanvas swallowed every Shift+click before the tool saw it.)

With 'Auto-pole while drawing' on, QGIS's Add Line keeps the row on and, on a cable layer, every
left click that adds a vertex puts a pole on it at once (one Ctrl+Z each on the pole layer).
Backspace / Delete that takes the last vertex back also takes its pole back; Esc or a right-click
that cancels the line takes back every pole that line made. When the line is finished every
vertex is checked and any vertex still without a pole gets one (one Ctrl+Z), never doubled.

With 'Exact spacing' on (off by default; Click Line v3 C), each Add Line click on a cable lands exactly
'Mark every' metres (WGS84 ellipsoid) from the previous vertex, towards the click; a click near a pole lands on
that pole. The click is read at mouse release and the vertex QGIS added is swapped before it gets a pole, then
read back (<= 5 mm), else put back as clicked and exact spacing switches off for the session. Alt, a snapped
click, Advanced Digitizing, tracing, curve / streaming capture, the first click, a click under 0.5 m, a frozen
project and QGIS < 4.2 with a reprojected cable layer (a 3.x undo fault) all stay as clicked.

Writes only to the edit buffers of the clicked cable layer and the pole layer.
Esc on the click tool, unticking the row, or picking a non-editing map tool (Pan, Identify,
Select, Zoom ...) switches it off; QGIS's editing tools (Add Line, Vertex tool ...) keep it on.
"""

import functools
import math
import re
import traceback
import warnings

from qgis.core import (
    Qgis,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsDistanceArea,
    QgsFeature,
    QgsFeatureRequest,
    QgsGeometry,
    QgsMessageLog,
    QgsPointXY,
    QgsProject,
    QgsRectangle,
    QgsUnitTypes,
    QgsVectorLayer,
)
from qgis.gui import (
    QgsMapCanvasTracer,
    QgsMapMouseEvent,
    QgsMapTool,
    QgsMapToolCapture,
    QgsMapToolDigitizeFeature,
    QgsMapToolPan,
    QgsRubberBand,
)
from qgis.PyQt import sip
from qgis.PyQt.QtCore import QEvent, QPoint, QPointF, Qt, QTimer
from qgis.PyQt.QtGui import QColor, QCursor, QKeyEvent

try:  # plugin package or plain module (tests)
    from . import live_measure as lm
    from . import live_measure_core as core
except ImportError:  # pragma: no cover
    import live_measure as lm
    import live_measure_core as core

TOL_M = 1.0          # default reuse distance: a pole within this many metres is the same pole (WGS84 ellipsoid)
HIT_PX = 14          # how close to a cable a click must be
VERTEX_PX = 14       # default vertex snap radius (setting cp_vertex_px)
MARK_PX = 10         # a click this close to a mark lands exactly on the mark
CLICK_PX = 4         # press -> release movement under this is a click, more is a pan
MARKER_PX = {"S": 7.0, "M": 10.0, "L": 13.0}
POLED = "#22C55E"    # green dot: a pole stands on this vertex
MISSING = "#FF8A00"  # orange ring: this vertex needs a pole
DARK = QColor(7, 11, 18, 235)
EXACT_FREE_M = 0.5   # exact spacing: a click this close to the previous vertex / previous click is never moved
EXACT_OK_M = 0.005   # exact spacing: the swapped vertex must read back this close to the exact point
FROZEN_HINTS = ("mohadin", "chloorkop")     # shipped / issued projects: never add features
OWN_DROP = "Click line: poles of an undone / deleted cable"
OWN_PREFIXES = ("Click line", "Auto-pole", "Shift+click")   # every pole-layer edit command this tool makes
_NUM = re.compile(r"^(.*?)(\d+)\s*PL\s*$", re.I)


# ── settings (QgsSettings via live_measure, cached) ─────────────────────────
def _opt(key, default):
    return lm._setting(key, default)


def _on_off(v):
    return str(v).strip().lower() in ("1", "true", "yes", "on")


def reuse_m():
    return min(25.0, max(0.05, lm._float(_opt("cp_reuse_m", TOL_M), TOL_M)))


def vertex_px():
    return int(min(60, max(2, lm._float(_opt("cp_vertex_px", VERTEX_PX), VERTEX_PX))))


def show_marks():
    return _on_off(_opt("cp_show_marks", "true"))


def include_ends():
    return _on_off(_opt("cp_include_ends", "true"))


def auto_draw():
    return _on_off(_opt("cp_auto_draw", "true"))


def exact_on():
    """Exact spacing while drawing with Add Line (Click Line v3 C): off unless the operator ticks it."""
    return _on_off(_opt("cp_exact", "false"))


def _qgis_int():
    try:
        return int(Qgis.versionInt())
    except Exception:
        return int(getattr(Qgis, "QGIS_VERSION_INT", 0))


def marker_px():
    return MARKER_PX.get(str(_opt("cp_marker_size", "M")).strip().upper()[:1], MARKER_PX["M"])


def _words(v):
    return [w.strip().lower() for w in str(v or "").split(",") if w.strip()]


def cable_rule():
    """(include words, exclude words): a cable layer's name has any include word and no exclude word."""
    return _words(_opt("cp_cable_inc", "cable")), _words(_opt("cp_cable_exc", "drop"))


def rule_text():
    inc, exc = cable_rule()
    a = "name has %s" % " or ".join("'%s'" % w for w in inc) if inc else "any line layer"
    return a + ((", not %s" % " / ".join("'%s'" % w for w in exc)) if exc else "")


def _is_line(lyr):
    return (isinstance(lyr, QgsVectorLayer) and not sip.isdeleted(lyr) and lyr.isValid()
            and lyr.geometryType() == Qgis.GeometryType.Line)


def is_cable(lyr):
    if not _is_line(lyr):
        return False
    name = lyr.name().lower()
    inc, exc = cable_rule()
    return (not inc or any(w in name for w in inc)) and not any(w in name for w in exc)


def cable_layers(project, active):
    """Layers a click may land on: the active layer first when it is a cable layer, then every
    visible cable layer (see cable_rule; drops excluded by default)."""
    out = []
    if is_cable(active):
        out.append(active)
    root = project.layerTreeRoot()
    for lyr in project.mapLayers().values():
        if lyr is active or not is_cable(lyr):
            continue
        node = root.findLayer(lyr.id()) if root is not None else None
        if node is not None and not node.isVisible():
            continue
        out.append(lyr)
    return out


def all_cable_layers(project):
    """Every cable layer, visible or not (auto-pole watches them all)."""
    return [lyr for lyr in project.mapLayers().values() if is_cable(lyr)]


def _is_point(lyr):
    return (isinstance(lyr, QgsVectorLayer) and not sip.isdeleted(lyr) and lyr.isValid()
            and lyr.geometryType() == Qgis.GeometryType.Point)


def poles_layer(project):
    """The pole layer picked in the settings, else the one point layer named 'Poles' (any case), else None."""
    lid = str(_opt("cp_pole_layer_id", "") or "")
    if lid:
        lyr = project.mapLayer(lid)
        if _is_point(lyr):
            return lyr
    hits = [lyr for lyr in project.mapLayers().values()
            if _is_point(lyr) and lyr.name().strip().lower() == "poles"]
    return hits[0] if len(hits) == 1 else None


def name_fields(pl):
    return [f for f in ("Name", "Pole ID") if pl is not None and pl.fields().indexOf(f) >= 0]


def frozen_reason(project, layers):
    """Why this project must not get new features, or ''."""
    path = (project.fileName() or "").lower()
    for hint in FROZEN_HINTS:
        if hint in path:
            return "this project is shipped / issued (%s)" % hint
    for lyr in layers:
        if lyr is None:
            continue
        if lyr.name().lower().endswith(" v1"):
            return "'%s' is a shipped ' v1' layer" % lyr.name()
        src = (lyr.source() or "").lower()
        for hint in FROZEN_HINTS:
            if hint in src:
                return "'%s' belongs to a shipped project (%s)" % (lyr.name(), hint)
    return ""


def _default_prefix(project):
    code = re.sub(r"[^A-Za-z]", "", project.baseName() or "")[:3].upper() or "XXX"
    return "HT_%s_" % code


def next_pole_name(pl, project):
    """(Name, Pole ID) for a new pole: the most common existing prefix, numbered on from the highest
    number in Name / Pole ID (HT_VRD_0123PL / 0123PL). No numbered pole yet: HT_<first 3 letters>_0001PL.
    (One full scan; the tool itself uses PoleIndex.next_name, which is cached.)"""
    flds = name_fields(pl)
    stats = [0, 4, {}]
    if flds:
        req = QgsFeatureRequest().setFlags(QgsFeatureRequest.Flag.NoGeometry).setSubsetOfAttributes(flds, pl.fields())
        for f in pl.getFeatures(req):
            _note_name(stats, f, flds)
    return _name_from(stats, project)


def _note_name(stats, f, flds):
    for fld in flds:
        v = f[fld]
        if v is None or str(v) == "NULL":
            continue
        m = _NUM.match(str(v).strip())
        if not m:
            continue
        stats[0] = max(stats[0], int(m.group(2)))
        stats[1] = max(stats[1], len(m.group(2)))
        if fld == "Name" and m.group(1):
            stats[2][m.group(1)] = stats[2].get(m.group(1), 0) + 1


def _name_from(stats, project):
    hi, width, prefixes = stats
    if prefixes:
        prefix = max(prefixes.items(), key=lambda kv: (kv[1], kv[0]))[0]
    else:
        prefix = _default_prefix(project)
    n = hi + 1
    return "%s%0*dPL" % (prefix, width, n), "%0*dPL" % (width, n)


def vertex_list(g):
    """[(global vertex index, QgsPointXY, is_end, part number)] of a (multi)line geometry, in order.
    Built from the parts (never geometry.vertices() on a temporary: that hung QGIS once)."""
    if g is None or g.isEmpty():
        return []
    parts = g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]
    out, i = [], 0
    for pn, part in enumerate(parts):
        last = len(part) - 1
        for vi, p in enumerate(part):
            out.append((i, QgsPointXY(p), vi == 0 or vi == last, pn))
            i += 1
    return out


# ── pole lookup: a grid index of the pole layer, kept in step with its edits ──
class PoleIndex:
    """Where the poles are (grid buckets in the pole CRS, metres measured on the WGS84 ellipsoid)
    and the next free pole number. Built on first use; a pole added to the layer is added to the
    index on the spot; a delete / move / rename / rollback / save rebuilds it on next use."""

    def __init__(self, project):
        self.p = project
        self.wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        self.da = QgsDistanceArea()
        self.da.setSourceCrs(self.wgs, self.p.transformContext())
        self.da.setEllipsoid("WGS84")
        self.layer = None
        self.version = 0          # bumps on every change (the hover markers rebuild on it)
        self.builds = 0           # full scans (tests)
        self._links = []
        self._to_w = None
        self._ident = False
        self._cs = 1.0
        self._geo = True
        self._factor = 1.0
        self._reset()

    def _reset(self):
        self.grid = None          # {(cx, cy): [fid]}
        self.pts = {}             # fid -> (QgsPointXY pole CRS, QgsPointXY WGS84)
        self.labels = {}          # fid -> Name / Pole ID
        self.stats = None         # [highest number, digits, {prefix: count}]

    def set_layer(self, pl):
        if pl is not None and pl is self.layer and not sip.isdeleted(pl):
            return
        self.close()
        if pl is None or sip.isdeleted(pl):
            return
        self.layer = pl
        self._to_w = QgsCoordinateTransform(pl.crs(), self.wgs, self.p)
        self._ident = pl.crs() == self.wgs           # most pole layers: no transform needed (speed)
        self._geo = pl.crs().isGeographic()
        if self._geo:
            self._factor, self._cs = 1.0, 0.0005
        else:
            try:
                self._factor = QgsUnitTypes.fromUnitToUnitFactor(Qgis.DistanceUnit.Meters, pl.crs().mapUnits())
            except Exception:
                lm._log_quiet(traceback.format_exc())
                self._factor = 1.0
            self._cs = 50.0 * self._factor
        for sig, slot in (("featureAdded", self._on_added), ("featureDeleted", self._on_dirty),
                          ("geometryChanged", self._on_dirty), ("attributeValueChanged", self._on_dirty),
                          ("afterRollBack", self._on_dirty), ("afterCommitChanges", self._on_dirty)):
            getattr(pl, sig).connect(slot)
            self._links.append((sig, slot))
        self.version += 1

    def close(self):
        pl, links = self.layer, self._links
        self.layer, self._links = None, []
        if pl is not None and not sip.isdeleted(pl):
            for sig, slot in links:
                try:
                    getattr(pl, sig).disconnect(slot)
                except (TypeError, RuntimeError):
                    pass
        self._reset()
        self.version += 1

    def alive(self):
        return self.layer is not None and not sip.isdeleted(self.layer)

    # Qt slots: never raise into Qt
    def _on_dirty(self, *args):
        self.grid = None
        self.stats = None
        self.version += 1

    def _on_added(self, fid, *args):
        try:
            self.version += 1
            if self.grid is None or not self.alive():
                return
            f = self.layer.getFeature(fid)
            if f.isValid():
                flds = name_fields(self.layer)
                self._put(f, flds)
                _note_name(self.stats, f, flds)
        except Exception:
            lm._log_quiet(traceback.format_exc())
            self._on_dirty()

    def _put(self, f, flds):
        g = f.geometry()
        if g is None or g.isEmpty():
            return
        p = QgsPointXY(g.vertexAt(0))
        fid = f.id()
        if fid in self.pts:
            return
        self.pts[fid] = (p, p if self._ident else self._to_w.transform(p))
        self.grid.setdefault((math.floor(p.x() / self._cs), math.floor(p.y() / self._cs)), []).append(fid)
        if flds:
            v = f[flds[0]]
            self.labels[fid] = str(v) if v is not None and str(v) != "NULL" else None

    def _ensure(self):
        if self.grid is not None and self.stats is not None:
            return
        pl = self.layer
        self.grid, self.pts, self.labels, self.stats = {}, {}, {}, [0, 4, {}]
        flds = name_fields(pl)
        req = QgsFeatureRequest()
        if flds:
            req.setSubsetOfAttributes(flds, pl.fields())
        else:
            req.setNoAttributes()
        for f in pl.getFeatures(req):
            self._put(f, flds)
            _note_name(self.stats, f, flds)
        self.builds += 1

    def near(self, pt, tol):
        """(fid, metres) of the nearest pole within tol metres of pt (pole CRS), else (None, None)."""
        if not self.alive():
            return None, None
        self._ensure()
        w = QgsPointXY(pt) if self._ident else self._to_w.transform(pt)
        if self._geo:
            ry = tol * 1.25 / 110000.0
            rx = ry / max(0.05, math.cos(math.radians(max(-89.0, min(89.0, pt.y())))))
        else:
            rx = ry = tol * 1.25 * self._factor
        best, best_m = None, None
        cs = self._cs
        for cx in range(math.floor((pt.x() - rx) / cs), math.floor((pt.x() + rx) / cs) + 1):
            for cy in range(math.floor((pt.y() - ry) / cs), math.floor((pt.y() + ry) / cs) + 1):
                for fid in self.grid.get((cx, cy), ()):
                    p, pw = self.pts[fid]
                    if abs(p.x() - pt.x()) > rx or abs(p.y() - pt.y()) > ry:
                        continue
                    m = self.da.measureLine(w, pw)
                    if m <= tol and (best_m is None or m < best_m):
                        best, best_m = fid, m
        return best, best_m

    def label(self, fid):
        self._ensure()
        lab = self.labels.get(fid)
        return lab if lab else "pole #%s" % fid

    def next_name(self):
        """(Name, Pole ID) the next new pole gets (cached; see next_pole_name)."""
        self._ensure()
        return _name_from(self.stats, self.p)


class PoleWriter:
    """Adds a vertex to a cable and a pole on it, or poles on many vertices (edit buffers only)."""

    def __init__(self, project=None):
        self.p = project or QgsProject.instance()
        self.wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        self.da = QgsDistanceArea()
        self.da.setSourceCrs(self.wgs, self.p.transformContext())
        self.da.setEllipsoid("WGS84")      # true metres even when the project ellipsoid is NONE
        self.made = []                     # pole names made this session (status line)
        self.index = PoleIndex(self.p)
        self.busy = False                  # True while this writer adds poles (auto-pole ignores them)
        self.last_fid = None               # edit-buffer fid of the last pole place_pole made
        self.last_made_at = []             # where each pole the last batch() made stands (pole CRS)
        self.last_made = []                # [(edit-buffer fid, spot)] of each pole the last batch() made
        self._xf = {}

    def close(self):
        self.index.close()

    def _to_wgs(self, crs):
        key = crs.authid() or crs.toWkt()
        xf = self._xf.get(key)
        if xf is None:
            xf = self._xf[key] = QgsCoordinateTransform(crs, self.wgs, self.p)
        return xf

    def metres(self, crs, a, b):
        xf = self._to_wgs(crs)
        return self.da.measureLine(xf.transform(a), xf.transform(b))

    def near_pole(self, pl, pt, tol=None):
        """(feature, metres) of the nearest pole within the reuse distance of pt (pole CRS), else (None, None)."""
        self.index.set_layer(pl)
        fid, m = self.index.near(pt, reuse_m() if tol is None else tol)
        if fid is None:
            return None, None
        return pl.getFeature(fid), m

    def _new_pole(self, pl, pt, phase):
        name, pole_id = self.index.next_name()
        w = self._to_wgs(pl.crs()).transform(pt)
        vals = {"Name": name, "Pole ID": pole_id, "x": round(w.x(), 8), "y": round(w.y(), 8)}
        if phase not in (None, "") and str(phase) != "NULL":
            vals["Phase"] = phase
        nf = QgsFeature(pl.fields())
        nf.setGeometry(QgsGeometry.fromPointXY(pt))
        for k, v in vals.items():
            i = pl.fields().indexOf(k)
            if i >= 0:
                nf.setAttribute(i, v)
        flds = name_fields(pl)
        label = name if "Name" in flds else (pole_id if flds else "unnamed pole")
        return nf, label

    def place_pole(self, pl, pt, phase=None):
        """A pole at pt (pole CRS) unless one is within the reuse distance. Returns (name, made, QgsPointXY in pole CRS)."""
        hit, _m = self.near_pole(pl, pt)
        if hit is not None:
            return self.index.label(hit.id()), False, QgsPointXY(hit.geometry().vertexAt(0))
        nf, label = self._new_pole(pl, pt, phase)
        self.busy = True
        self.last_fid = None
        try:
            pl.beginEditCommand("Click line: pole")
            ok = pl.addFeature(nf)
            if ok:
                pl.endEditCommand()
                self.last_fid = nf.id()
            else:
                pl.destroyEditCommand()
        finally:
            self.busy = False
        if not ok:
            return None, False, None
        self.made.append(label)
        return label, True, QgsPointXY(pt)

    def unpoled(self, pl, pts, tol=None):
        """Indexes of pts (pole CRS) with no pole within tol metres - read straight from the layer (one
        bounding-box query, own buckets), NOT from the PoleIndex, so it is an independent re-check."""
        if not pts:
            return []
        tol = reuse_m() if tol is None else tol
        xf = self._to_wgs(pl.crs())
        ws = [xf.transform(p) for p in pts]
        lat = max(abs(w.y()) for w in ws)
        cy = tol * 1.25 / 110000.0
        cx = cy / max(0.05, math.cos(math.radians(min(89.0, lat))))
        rect = QgsRectangle(min(w.x() for w in ws) - cx, min(w.y() for w in ws) - cy,
                            max(w.x() for w in ws) + cx, max(w.y() for w in ws) + cy)
        if pl.crs() != self.wgs:
            rect = QgsCoordinateTransform(self.wgs, pl.crs(), self.p).transformBoundingBox(rect)
        cells = {}
        for f in pl.getFeatures(QgsFeatureRequest().setFilterRect(rect).setNoAttributes()):
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            q = xf.transform(QgsPointXY(g.vertexAt(0)))
            cells.setdefault((math.floor(q.x() / cx), math.floor(q.y() / cy)), []).append(q)
        out = []
        for i, w in enumerate(ws):
            kx, ky = math.floor(w.x() / cx), math.floor(w.y() / cy)
            if not any(self.da.measureLine(w, q) <= tol for a in (-1, 0, 1) for b in (-1, 0, 1)
                       for q in cells.get((kx + a, ky + b), ())):
                out.append(i)
        return out

    def pole_at(self, pl, at):
        """fid of a pole standing exactly at `at` (pole CRS), else None. A save renumbers the fids of new
        features (OGR), so a pole this tool made is found again by where it stands."""
        e = 1e-7
        req = QgsFeatureRequest().setFilterRect(QgsRectangle(at.x() - e, at.y() - e, at.x() + e, at.y() + e))
        for f in pl.getFeatures(req.setNoAttributes()):
            g = f.geometry()
            if g is not None and not g.isEmpty() and QgsPointXY(g.vertexAt(0)).distance(at) <= 1e-9:
                return f.id()
        return None

    def take_back(self, pl, fid, at, stack_index, relocate=False):
        """Remove a pole this tool made (fid, at = its spot in the pole CRS), only while it still stands
        exactly there. Its own undo step is undone when it is still the top of the pole layer's undo
        stack (no trace left), else it is deleted in its own edit command. Returns True when removed.
        relocate=True (the pole layer was saved since the pole was made, so its fid changed): it is found
        by its spot instead. Without a save in between a missing fid means it was undone or moved."""
        if pl is None or sip.isdeleted(pl) or at is None or not pl.isEditable():
            return False
        f = pl.getFeature(fid) if fid is not None else QgsFeature()
        g = f.geometry() if f.isValid() else None
        if g is None or g.isEmpty() or QgsPointXY(g.vertexAt(0)).distance(at) > 1e-9:
            fid = self.pole_at(pl, at) if relocate else None
            if fid is None:
                return False               # gone already (undone / moved): not ours to touch
            stack_index = None             # the undo stack was cleared by that save: never undo by index
        st = pl.undoStack()
        if st is not None and stack_index is not None and st.index() == stack_index and stack_index > 0 \
                and st.command(stack_index - 1) is not None and st.command(stack_index - 1).text() == "Click line: pole":
            st.undo()
            if not pl.getFeature(fid).isValid():
                pl.triggerRepaint()
                return True
        pl.beginEditCommand("Click line: pole taken back")
        if pl.deleteFeature(fid):
            pl.endEditCommand()
            pl.triggerRepaint()
            return True
        pl.destroyEditCommand()
        return False

    def batch(self, pl, pts, phase, what):
        """A pole on each of pts (pole CRS) that has none within the reuse distance, all in ONE edit
        command (one Ctrl+Z). Returns (labels made, number of points that already had a pole)."""
        if not pl.isEditable() and not pl.startEditing():
            raise RuntimeError("the pole layer cannot be edited")
        self.index.set_layer(pl)
        tol = reuse_m()
        made, reused = [], 0
        self.last_made_at = []             # where each new pole of this batch stands (pole CRS)
        self.last_made = []                # [(edit-buffer fid, spot)] of each new pole of this batch
        self.busy = True
        pl.beginEditCommand(what)
        try:
            for pt in pts:
                fid, _m = self.index.near(pt, tol)       # the index follows each add, so no two land within tol
                if fid is not None:
                    reused += 1
                    continue
                nf, label = self._new_pole(pl, pt, phase)
                if pl.addFeature(nf):
                    made.append(label)
                    self.last_made_at.append(QgsPointXY(pt))
                    self.last_made.append((nf.id(), QgsPointXY(pt)))
        except Exception:
            pl.destroyEditCommand()
            self.busy = False
            raise
        self.busy = False
        if made:
            pl.endEditCommand()
            self.made.extend(made)
        else:
            pl.destroyEditCommand()
        pl.triggerRepaint()
        return made, reused

    def add(self, cable, fid, after, pt, pl):
        """Pole at pt (cable CRS) and, when `after` >= 0, a vertex inserted before vertex `after`
        at the pole's spot. Returns (pole name, pole made, vertex added) or raises RuntimeError."""
        if not pl.isEditable() and not pl.startEditing():
            raise RuntimeError("the pole layer cannot be edited")
        if after >= 0 and not cable.isEditable() and not cable.startEditing():
            raise RuntimeError("'%s' cannot be edited" % cable.name())
        f = cable.getFeature(fid)
        phase = _phase(cable, f, pl)
        to_pl = QgsCoordinateTransform(cable.crs(), pl.crs(), self.p)
        name, made, at = self.place_pole(pl, to_pl.transform(pt), phase)
        if name is None:
            raise RuntimeError("QGIS would not add the pole")
        added = False
        if after >= 0:
            q = QgsCoordinateTransform(pl.crs(), cable.crs(), self.p).transform(at)   # onto the pole exactly
            g = QgsGeometry(f.geometry())
            if g.insertVertex(q.x(), q.y(), after):
                cable.beginEditCommand("Click line: vertex")
                if cable.changeGeometry(fid, g):
                    cable.endEditCommand()
                    added = True
                else:
                    cable.destroyEditCommand()
        for lyr in (pl, cable):
            lyr.triggerRepaint()
        return name, made, added


def is_add_line(tool):
    """QGIS's Add Line tool (an add-feature digitizing tool in line mode). Split / Reshape are capture
    tools too, but not digitize-feature tools, so they never count."""
    try:
        return (tool is not None and not sip.isdeleted(tool) and isinstance(tool, QgsMapToolDigitizeFeature)
                and tool.mode() == QgsMapToolCapture.CaptureMode.CaptureLine)
    except Exception:
        lm._log_quiet(traceback.format_exc())
        return False


def is_edit_tool(tool):
    """A QGIS editing map tool (Add Line / Polygon, Vertex tool, move, reshape, split ...): the row stays on."""
    try:
        return bool(lm.LiveTools.is_edit_tool(tool))
    except Exception:
        lm._log_quiet(traceback.format_exc())
        return False


def capture_points(tool):
    """[QgsPointXY] (layer CRS, copies) the capture tool has so far, or None when this QGIS gives no way to read
    them. captureCurve() first (public on 3.x and 4.x); points() is the deprecated fallback."""
    try:
        c = tool.captureCurve()
        if c is not None:
            return [QgsPointXY(p.x(), p.y()) for p in c.points()]
    except Exception:
        lm._log_quiet(traceback.format_exc())
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            return [QgsPointXY(p) for p in tool.points()]
    except Exception:
        lm._log_quiet(traceback.format_exc())
        return None


def click_state(canvas, tool, pos, mods):
    """What a click at view pos is, read at mouse release BEFORE the capture tool adds its point (exact spacing
    never guesses afterwards): Alt held, QGIS snapping matched something, Advanced Digitizing on, tracing on,
    straight-segment capture, and the click in map CRS. A read that fails counts against the swap."""
    st = {"alt": bool(mods & Qt.KeyboardModifier.AltModifier), "snapped": True, "cad": True, "tracing": True,
          "straight": False, "map": canvas.getCoordinateTransform().toMapCoordinates(pos)}
    try:
        st["snapped"] = bool(canvas.snappingUtils().snapToMap(pos).isValid())
    except Exception:
        lm._log_quiet(traceback.format_exc())
    try:
        cad = tool.cadDockWidget()
        st["cad"] = bool(cad is not None and not sip.isdeleted(cad) and cad.cadEnabled())
    except Exception:
        lm._log_quiet(traceback.format_exc())
    try:
        tr = QgsMapCanvasTracer.tracerForCanvas(canvas)
        act = tr.actionEnableTracing() if tr is not None else None
        st["tracing"] = bool(act is not None and act.isChecked())
    except Exception:
        lm._log_quiet(traceback.format_exc())
    try:
        tech = tool.currentCaptureTechnique() if hasattr(tool, "currentCaptureTechnique") else None
        st["straight"] = tech is None or tech == Qgis.CaptureTechnique.StraightSegments
    except Exception:
        lm._log_quiet(traceback.format_exc())
    return st


def _backspace(tool):
    tool.keyPressEvent(QKeyEvent(QEvent.Type.KeyPress, Qt.Key.Key_Backspace, Qt.KeyboardModifier.NoModifier))


def _release_at(tool, canvas, map_pt):
    """A left release that carries map_pt (map CRS) exactly: the capture tool adds a vertex there."""
    q = canvas.getCoordinateTransform().transform(map_pt)
    ev = QgsMapMouseEvent(canvas, QEvent.Type.MouseButtonRelease, QPoint(int(round(q.x())), int(round(q.y()))),
                          Qt.MouseButton.LeftButton, Qt.MouseButton.NoButton, Qt.KeyboardModifier.NoModifier)
    ev.setMapPoint(map_pt)
    tool.cadCanvasReleaseEvent(ev)


def swap_last_vertex(tool, canvas, map_pt):
    """Replace the vertex the capture tool just added with map_pt (map CRS), keeping the capture going: its own
    Backspace, then a release event that carries the exact map point (S0: exact on QGIS 3.38-4.2; the plain
    canvasReleaseEvent re-derives the point from the pixel and is not used)."""
    _backspace(tool)
    _release_at(tool, canvas, map_pt)


def _phase(cable, f, pl):
    if f.isValid() and cable.fields().indexOf("Phase") >= 0 and pl.fields().indexOf("Phase") >= 0:
        return f["Phase"]
    return None


def _pos(event):
    """The view point of a mouse event, Qt5 and Qt6."""
    return event.position().toPoint() if hasattr(event, "position") else event.pos()


class ClickLineMapTool(QgsMapToolPan):
    """Pan tool: a drag pans, a clean left click goes to on_click(view pos, modifiers). Esc goes back to Pan."""

    def __init__(self, canvas, on_click, on_escape):
        super().__init__(canvas)
        self._down = None
        self._on_click = on_click
        self._on_escape = on_escape
        self._cross = QCursor(Qt.CursorShape.CrossCursor)
        self.setCursor(self._cross)

    def flags(self):
        """The Pan tool's flags without AllowZoomRect. With it, QgsMapCanvas takes every Shift+left press as
        the start of a zoom rectangle and the tool never sees the Shift+click (the 'Shift+click does not
        pole the missing vertices' bug, JJ 2026-10-16)."""
        f = super().flags()
        try:
            v = int(f) & ~int(QgsMapTool.Flag.AllowZoomRect)
            if v != int(f):
                g = type(f)(v)       # the SAME type sip handed us (PyQt6 IntEnum / PyQt5 QFlags): '^' gives a
                if type(g) is type(f):   # plain int on PyQt6, which sip rejects and QGIS aborts on
                    return g
        except Exception:
            lm._log_quiet(traceback.format_exc())
        return f

    def canvasPressEvent(self, e):
        self._down = QPoint(e.pos()) if e.button() == Qt.MouseButton.LeftButton else None
        super().canvasPressEvent(e)

    def canvasReleaseEvent(self, e):
        down, self._down = self._down, None
        if e.button() != Qt.MouseButton.LeftButton or down is None or (e.pos() - down).manhattanLength() >= CLICK_PX:
            super().canvasReleaseEvent(e)          # a drag: Pan finishes it
            self.canvas().setCursor(self._cross)   # Pan leaves its hand cursor behind
            return
        try:                                       # a clean click: never re-centre the map
            self._on_click(QPoint(e.pos()), e.modifiers())
        except Exception:
            QgsMessageLog.logMessage(traceback.format_exc(), lm.LOG_TAG, Qgis.MessageLevel.Warning)

    def canvasDoubleClickEvent(self, e):
        pass                                       # no zoom on a quick second click

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_Escape:
            self._on_escape()
            return
        super().keyPressEvent(e)


class ClickPoleTool(lm.VertexMeasureTool):
    """Span Inspector row 'Click line = vertex + pole': the hovered cable's vertices (poled / not), the
    Vertex-measure readout, a pole on each clean click, Shift+click = poles on every missing vertex, and
    auto-pole for a cable drawn with Add Line (see the module docstring)."""

    title = "Click line = vertex + pole"
    key = "t9"

    def __init__(self, host):
        super().__init__(host)
        self.map_tool = None
        self.writer = None
        self._cur_layer = None
        self._prev_tool = None
        self.drawing = False         # the row is on while QGIS's Add Line tool draws (auto-pole)
        self.paused = False          # the row is on while another QGIS editing tool is picked (does nothing)
        self.capture_log = []        # [(event, n poles)] per-click poles placed / taken back (tests, status)
        self.last_batch = None       # the last Shift+click / auto-pole batch and its re-check (tests)
        self._cap = None             # the line being drawn: {"tool", "layer", "rec": [[pt, pole fid, at, stack]], ...}
        self._cap_stash = None       # that line, kept while the row is off and QGIS may still drop it
        self._cap_done = []          # [(cable layer id, [(pole fid, at)])] lines just finished, waiting for _auto_pole
        self.problem = ""            # why clicks cannot work here (status line, F7)
        self.markers = []            # [(QgsPointXY layer CRS, has pole, vertex index, is end)] of the hovered cable
        self.hover = None            # {"layer", "fid", "n", "poled", "missing", "shift_missing"} of the hovered cable
        self.auto_log = []           # [{"layer", "fid", "made", "reused"}] (tests, status)
        self._mk_key = None
        self._verts = []
        self._bands = None           # (halo, poled, missing) rubber bands, made once and mutated
        self._pole_html = ""
        self._ap = {}                # cable layer id -> fids added inside its open edit command
        self._ap_wired = []
        self._owned = {}             # (cable layer id, fid) -> [QgsPointXY pole CRS] poles made for a cable drawn here
        self._parked = {}            # (cable layer id, fid) -> {"pts", "index"} poles taken away with an undone cable
        self.gap_log = []            # [(event, n)] cable undone / restored / Poles saved (tests, status)
        self._pole_saves = 0         # Poles saves seen: a pole recorded before the latest one has a new fid now
        self._warned = set()
        self._pending = None         # exact spacing: the left click just released, read before QGIS adds it
        self._exact_off = ""         # exact spacing switched itself off for this session (why), see _exact
        self._exact_said = set()     # one message per session per reason
        self.exact_log = []          # [(what, metres off)] per swapped click: 'step' | 'pole' | 'restored' (tests)
        self.exact_cross = None      # QgsPointXY (map CRS) of the preview cross, or None (tests)
        self._xband = None

    # this tool's map tool replaces the Vertex tool as the trigger --------------
    def is_vertex_tool(self, iface, tool):
        return tool is not None and tool is self.map_tool

    def _layer(self):
        return self._cur_layer

    def _pick_drag(self, pos):
        self._drag = None          # a press here starts a pan or a click, never a vertex drag
        self._anchor = None

    def _poles(self):
        return poles_layer(QgsProject.instance())

    # on / off ------------------------------------------------------------------
    def _on(self):
        super()._on()
        self.writer = PoleWriter()
        self.drawing = False
        self.paused = False
        stash, self._cap_stash = getattr(self, "_cap_stash", None), None
        self._cap = stash if stash is not None and not sip.isdeleted(stash["tool"]) and stash["rec"] else None
        self._cap_done = []
        self._warned = set()
        self.canvas.installEventFilter(self)       # Backspace / Delete / Esc reach the canvas, not the viewport
        self._canvas_filter = True
        if self.map_tool is None or sip.isdeleted(self.map_tool):
            self.map_tool = ClickLineMapTool(self.canvas, self._click, self._escape)
        # no setAction: the row follows mapToolSet itself (Add Line keeps it on while auto-pole is on)
        cur = self.canvas.mapTool()
        self._prev_tool = cur if cur is not self.map_tool else None
        self.canvas.setMapTool(self.map_tool)
        prj = QgsProject.instance()
        self._connect(prj, "layersAdded", self._on_layers_changed)
        self._connect(prj, "layersRemoved", self._on_layers_changed)
        self._wire_auto()
        self._check_project(tell=True)
        pl = self._poles()
        if pl is not None:                         # index the poles now, not on the first hover
            self.writer.index.set_layer(pl)
            self.writer.index.next_name()

    def _off(self):
        def release_tool():
            mt = self.map_tool
            if mt is not None and not sip.isdeleted(mt) and self.canvas.mapTool() is mt:
                pan = getattr(self.host.iface, "actionPan", None)
                act = pan() if pan is not None else None
                if act is not None:
                    act.trigger()
                else:
                    self.canvas.unsetMapTool(mt)

        def close_writer():
            w, self.writer = self.writer, None
            if w is not None:
                w.close()

        def unfilter_canvas():
            if getattr(self, "_canvas_filter", False) and not sip.isdeleted(self.canvas):
                self.canvas.removeEventFilter(self)
            self._canvas_filter = False

        def drop_abandoned():
            if self._drop_abandoned_line() is False:
                self._stash_line()

        def forget():
            self.drawing = False
            self.paused = False
            self._cap = None
            self._cap_done = []
            self._ap = {}
            self._ap_wired = []
            self._owned = {}
            self._parked = {}
        def drop_cross():
            self._pending = None
            self._cross(None)
            band, self._xband = self._xband, None
            sc = self.canvas.scene() if not sip.isdeleted(self.canvas) else None
            if band is not None and not sip.isdeleted(band) and sc is not None and band.scene() is sc:
                sc.removeItem(band)
        lm._best_effort(drop_abandoned, release_tool, unfilter_canvas, super()._off, self._drop_bands, drop_cross,
                        close_writer, forget)

    def destroy(self):
        super().destroy()
        mt, self.map_tool = self.map_tool, None
        if mt is not None and not sip.isdeleted(mt):
            mt.deleteLater()

    def _escape(self):
        if self.action is not None and not sip.isdeleted(self.action):
            self.action.setChecked(False)          # the controller switches the tool off

    def _check_project(self, tell=False):
        """F7: say at switch-on (and when layers change) why clicks would do nothing."""
        prj = QgsProject.instance()
        pl = self._poles()
        why = ""
        if pl is None:
            why = "No pole layer: name a point layer 'Poles' or pick one in Settings"
        else:
            fz = frozen_reason(prj, [pl])
            if fz:
                why = "No edits here: %s" % fz
            elif not all_cable_layers(prj):
                why = "No cable layers (%s) - change the rule in Settings" % rule_text()
            elif not name_fields(pl):
                why = "'%s' has no Name / Pole ID field: new poles get no name" % pl.name()
        if tell and why and why != self.problem:
            self.host.message("Click line: " + why + ".")
        self.problem = why

    @lm.guarded("{key}.layers")
    def _on_layers_changed(self, *args):
        if not self.active:
            return
        if self.writer is not None and not self.writer.index.alive():
            self.writer.index.close()
        self._wire_auto()
        self._mk_key = None
        self._check_project(tell=False)
        self.host.notify(self)

    @lm.guarded("{key}.toolset")
    def _on_tool_set(self, new_tool, *args):
        self._hide()
        self._pending = None
        self._cross(None)
        if not self.active:
            return
        if new_tool is not None and new_tool is self.map_tool:
            self.drawing = self.paused = False
        elif (auto_draw() or exact_on()) and is_add_line(new_tool):
            self.drawing, self.paused = True, False   # Add Line: stay on, a pole per click + the finished line
            self._wire_auto()                      # the cable rule may have changed since switch-on
        elif is_edit_tool(new_tool):
            self.drawing, self.paused = False, True   # Vertex tool & other editing tools: stay on, do nothing
        else:
            self._escape()                         # Pan / Identify / Select / Zoom ...: the row unticks, the tool goes off
            return
        self.host.notify(self)

    # events: no readout while the mouse pans ----------------------------------
    @lm.guarded("{key}.eventFilter", False)
    def eventFilter(self, obj, event):
        et = event.type()
        if self.drawing or self._cap is not None:
            if et == QEvent.Type.MouseButtonRelease:   # the capture tool adds / ends AFTER this filter: look next turn
                left = event.button() == Qt.MouseButton.LeftButton
                if left and self.drawing and exact_on() and obj is self.canvas.viewport():
                    self._pending = click_state(self.canvas, self.canvas.mapTool(), _pos(event), event.modifiers())
                QTimer.singleShot(0, functools.partial(self._cap_sync_later, left))
            elif et == QEvent.Type.KeyPress and event.key() in (Qt.Key.Key_Backspace, Qt.Key.Key_Delete,
                                                                Qt.Key.Key_Escape):
                QTimer.singleShot(0, functools.partial(self._cap_sync_later, False))
            elif et == QEvent.Type.MouseMove and self._pending is None:
                self._cap_sync(False)               # cheap; catches a line ended in a dialog / any missed event
        if self.drawing and et == QEvent.Type.MouseMove and obj is self.canvas.viewport():
            self._preview_cross(event)
        if obj is not self.canvas.viewport():
            return False                            # the canvas itself: only the keys above
        if (et == QEvent.Type.MouseMove and event.buttons() & Qt.MouseButton.LeftButton
                and self.canvas.mapTool() is self.map_tool):
            if self.last is not None:
                self._hide()
            return False
        return super().eventFilter(obj, event)

    def _hide(self, keep_anchor=False):
        super()._hide(keep_anchor)
        self._clear_bands()

    # hover markers (F1) ---------------------------------------------------------
    def _dpi(self):
        try:
            return max(1.0, self.canvas.logicalDpiX() / 96.0)   # Qt6 scales by itself (96); Qt5 high-DPI does not
        except Exception:
            lm._log_quiet(traceback.format_exc())
            return 1.0

    def _make_bands(self):
        if self._bands is not None and not any(sip.isdeleted(b) for b in self._bands):
            return self._bands
        halo = QgsRubberBand(self.canvas, Qgis.GeometryType.Line)
        poled = QgsRubberBand(self.canvas, Qgis.GeometryType.Point)
        miss = QgsRubberBand(self.canvas, Qgis.GeometryType.Point)
        halo.setZValue(1005)                 # under the measure graphics (1020) ...
        poled.setZValue(1021)                # ... the vertex markers over them: a dot is never hidden
        miss.setZValue(1022)
        self._bands = (halo, poled, miss)
        self._style_bands()
        return self._bands

    def _style_bands(self):
        halo, poled, miss = self._bands
        s = self._dpi()
        size = int(round(marker_px() * s))
        halo.setColor(QColor(26, 229, 255, 70))
        halo.setWidth(int(round(9 * s)))
        poled.setIcon(QgsRubberBand.IconType.ICON_CIRCLE)     # ICON_CIRCLE is drawn with the fill colour
        poled.setIconSize(size)
        poled.setFillColor(QColor(POLED))
        poled.setStrokeColor(DARK)
        poled.setWidth(int(round(2 * s)))
        miss.setIcon(QgsRubberBand.IconType.ICON_CIRCLE)
        miss.setIconSize(size)
        miss.setFillColor(QColor(0, 0, 0, 0))                    # a ring: no fill
        miss.setStrokeColor(QColor(MISSING))
        miss.setSecondaryStrokeColor(DARK)
        miss.setWidth(int(round(3 * s)))

    def _clear_bands(self):
        if self._bands is not None:
            for b, gt in zip(self._bands, (Qgis.GeometryType.Line, Qgis.GeometryType.Point, Qgis.GeometryType.Point)):
                if not sip.isdeleted(b):
                    b.reset(gt)
        self.markers, self._verts, self.hover, self._mk_key, self._pole_html = [], [], None, None, ""

    def _drop_bands(self):
        bands, self._bands = self._bands, None
        self.markers, self._verts, self.hover, self._mk_key = [], [], None, None
        if bands is None:
            return
        sc = self.canvas.scene() if not sip.isdeleted(self.canvas) else None
        for b in bands:
            if not sip.isdeleted(b) and sc is not None and b.scene() is sc:
                sc.removeItem(b)

    def _ensure_markers(self, lyr, fid, g):
        """Green dot / orange ring on every vertex of the hovered cable; rebuilt only when the cable, its
        geometry, the poles or a setting changed."""
        pl = self._poles()
        if pl is not None:
            self.writer.index.set_layer(pl)
        idx = self.writer.index
        key = (lyr.id(), fid, hash(bytes(g.asWkb())), pl.id() if pl is not None else None, idx.version,
               reuse_m(), marker_px(), include_ends())
        if key == self._mk_key:
            return
        bands = self._make_bands()
        if self._mk_key is None or self._mk_key[5:7] != key[5:7]:
            self._style_bands()
        self._verts = vertex_list(g)
        tol = reuse_m()
        same = pl is not None and lyr.crs() == pl.crs()
        to_pl = QgsCoordinateTransform(lyr.crs(), pl.crs(), QgsProject.instance()) if pl is not None and not same else None
        self.markers = []
        for i, pt, end, _part in self._verts:
            if pl is None:
                has = False
            else:
                has = idx.near(pt if same else to_pl.transform(pt), tol)[0] is not None
            self.markers.append((pt, has, i, end))
        halo, poled, miss = bands
        halo.setToGeometry(QgsGeometry(g), lyr)
        on = [m[0] for m in self.markers if m[1]]
        off = [m[0] for m in self.markers if not m[1]]
        for band, pts in ((poled, on), (miss, off)):
            if pts:
                band.setToGeometry(QgsGeometry.fromMultiPointXY(pts), lyr)
            else:
                band.reset(Qgis.GeometryType.Point)
        ends = include_ends()
        self.hover = {"layer": lyr.id(), "fid": fid, "n": len(self.markers), "poled": len(on), "missing": len(off),
                      "shift_missing": sum(1 for m in self.markers if not m[1] and (ends or not m[3]))}
        self._mk_key = key

    # hit / target ---------------------------------------------------------------
    def _hit_px(self):
        return max(HIT_PX, vertex_px())

    def _hit(self, pos):
        """(layer, fid, geometry, snap QgsPointXY, after vertex index, tolerance, mouse QgsPointXY) of the
        nearest cable within the hit radius of the view point (layer CRS); the active layer wins a tie. Else None."""
        best = None
        px = self._hit_px()
        for lyr in cable_layers(QgsProject.instance(), self.host.iface.activeLayer()):
            rect, p, tol_l = self._search_px(lyr, pos, px)
            req = QgsFeatureRequest().setFilterRect(rect).setNoAttributes().setLimit(50)
            for f in lyr.getFeatures(req):
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                d2, snap, after, _side = g.closestSegmentWithContext(p)
                if after <= 0 or d2 > tol_l * tol_l:
                    continue
                score = d2 / (tol_l * tol_l)
                if best is None or score < best[0] - 1e-9:
                    best = (score, lyr, f.id(), QgsGeometry(g), QgsPointXY(snap), after, tol_l, QgsPointXY(p))
        return best[1:] if best is not None else None

    def _search_px(self, lyr, pos, px):
        to_l, _back = self._xforms(lyr)
        p_map = self._map_pt(pos)
        tol = px * self.canvas.mapUnitsPerPixel()
        rect = QgsRectangle(p_map.x() - tol, p_map.y() - tol, p_map.x() + tol, p_map.y() + tol)
        if to_l is not None:
            rect = to_l.transformBoundingBox(rect)
        p = to_l.transform(p_map) if to_l is not None else QgsPointXY(p_map)
        return rect, p, max(rect.width(), rect.height()) / 2.0

    def _resolve(self, pos):
        """Everything a click at view pos would do, from ONE query of the cable layers, or None."""
        hit = self._hit(pos)
        if hit is None:
            return None
        lyr, fid, g, snap, after, tol_l, p = hit
        upp = tol_l / float(self._hit_px())                   # layer units per view pixel
        a, b = QgsPointXY(g.vertexAt(after - 1)), QgsPointXY(g.vertexAt(after))
        r = {"layer": lyr, "fid": fid, "geom": g, "snap": snap, "after": after, "a": a, "b": b, "mouse": p}
        vert = None                                           # (distance to the mouse, vertex, index)
        _v, at, _bef, _aft, d2 = g.closestVertex(p)
        if at >= 0:
            v = QgsPointXY(g.vertexAt(at))
            if self.writer.metres(lyr.crs(), v, snap) <= reuse_m():
                r.update(point=v, what="vertex", vidx=at, ins=-1)   # the same spot as a vertex: always that vertex
                return r
            if math.sqrt(d2) <= vertex_px() * upp:
                vert = (math.sqrt(d2), v, at)
        if show_marks():
            step = self.step()
            d_prev = self.writer.metres(lyr.crs(), a, snap)
            seg = d_prev + self.writer.metres(lyr.crs(), snap, b)
            k = round(d_prev / step)
            if k >= 1 and k * step < seg - reuse_m():
                fr = k * step / seg
                mark = QgsPointXY(a.x() + (b.x() - a.x()) * fr, a.y() + (b.y() - a.y()) * fr)
                # a mark and a vertex both in reach (a span just over 'Mark every'): the one nearer the mouse wins,
                # so a click on the 70 m mark of a 72 m span still splits it (stress walk, 2026-10-16)
                if mark.distance(snap) <= MARK_PX * upp and (vert is None or mark.distance(p) < vert[0]):
                    r.update(point=mark, what="mark", vidx=None, ins=after)
                    return r
        if vert is not None:
            r.update(point=vert[1], what="vertex", vidx=vert[2], ins=-1)
            return r
        r.update(point=snap, what="line", vidx=None, ins=after)
        return r

    def target(self, pos):
        """Where a click at view pos puts the pole: (layer, fid, after, point, what) in layer CRS, or None.
        after = -1 means an existing vertex is used (no new vertex). what = 'vertex' | 'mark' | 'line'."""
        r = self._resolve(pos)
        if r is None:
            return None
        return r["layer"], r["fid"], r["ins"], r["point"], r["what"]

    # hover -----------------------------------------------------------------------
    def _update(self, pos):
        if self.writer is None:
            return
        r = self._resolve(pos)
        if r is None:
            self._cur_layer = None
            note = self._not_cable_note(pos)
            if note:
                self._show_note(note)
            elif self.last is not None or self.markers:
                self._hide()
            return
        lyr = self._cur_layer = r["layer"]
        _to_l, back = self._xforms(lyr)

        def to_c(q):
            return back.transform(q) if back is not None else QgsPointXY(q)
        da = self._da(lyr.crs())
        step = self.step()
        limit = self.limit_for(lyr)
        self._ensure_markers(lyr, r["fid"], r["geom"])
        info = self._pole_info(r)
        self._pole_html = self._pole_block(r, info)
        if r["what"] == "vertex":
            vi = r["vidx"]
            vs = self._verts
            v = vs[vi]
            prev = vs[vi - 1][1] if vi > 0 and vs[vi - 1][3] == v[3] else None
            nxt = vs[vi + 1][1] if vi + 1 < len(vs) and vs[vi + 1][3] == v[3] else None
            d_prev = da.measureLine(prev, v[1]) if prev is not None else None
            d_next = da.measureLine(v[1], nxt) if nxt is not None else None
            shown = d_prev if d_prev is not None else d_next
            colour = core.span_colour(shown, limit) if shown is not None else core.NEUTRAL
            self._draw(to_c(prev) if prev is not None else None, to_c(nxt) if nxt is not None else None,
                       to_c(v[1]), [], None, core.NEUTRAL)
            self.last = {"from_prev": d_prev, "to_next": d_next, "step": step, "limit": limit, "colour": colour,
                         "dragging": False}
            self.last.update(info)
            if d_prev is not None:
                self._card(d_prev, "this vertex · from previous vertex", d_next, step, limit, colour, marks=False)
            elif d_next is not None:
                self._card(d_next, "cable end · to next vertex", None, step, limit, colour, marks=False)
            else:
                self._label(self._pole_html_only(), colour)
            return
        a, b, snap = r["a"], r["b"], r["snap"]
        d_prev, d_next = da.measureLine(a, snap), da.measureLine(snap, b)
        seg = d_prev + d_next
        marks = show_marks()
        ticks = []
        k = 1
        while marks and k * step < seg - 0.01 and k <= 200:
            fr = (k * step) / seg
            q = QgsPointXY(a.x() + (b.x() - a.x()) * fr, a.y() + (b.y() - a.y()) * fr)
            ticks.append((to_c(q), k * step, (k - 1) * step <= d_prev + lm.VM_ON_M < k * step,
                          abs(d_prev - k * step) <= lm.VM_ON_M or (r["what"] == "mark" and r["point"].distance(q) < 1e-12)))
            k += 1
        colour = core.span_colour(d_prev, limit)
        self._draw(to_c(a), to_c(b), to_c(r["point"]), ticks, None, colour)
        self.last = {"from_prev": d_prev, "to_next": d_next, "step": step, "limit": limit, "colour": colour,
                     "dragging": False}
        self.last.update(info)
        self._card(d_prev, "along the line · from previous vertex", d_next, step, limit, colour, marks=marks)

    def _pole_info(self, r):
        """What a click / Shift+click here would do (also kept in self.last for the tests)."""
        h = self.hover or {}
        pl = self._poles()
        info = {"what": r["what"], "n": h.get("n", 0), "poled": h.get("poled", 0), "missing": h.get("missing", 0),
                "shift_missing": h.get("shift_missing", 0), "vertex_i": None, "has_pole": None, "pole": None,
                "next_name": None}
        if pl is not None:
            name, pid = self.writer.index.next_name()
            flds = name_fields(pl)
            info["next_name"] = name if "Name" in flds else (pid if flds else None)
        if r["what"] == "vertex" and r["vidx"] is not None and r["vidx"] < len(self.markers):
            m = self.markers[r["vidx"]]
            info["vertex_i"] = r["vidx"] + 1
            info["has_pole"] = m[1]
            if m[1] and pl is not None:
                to_pl = QgsCoordinateTransform(r["layer"].crs(), pl.crs(), QgsProject.instance())
                fid, _m = self.writer.index.near(to_pl.transform(m[0]), reuse_m())
                info["pole"] = self.writer.index.label(fid) if fid is not None else None
        return info

    def _pole_block(self, r, info):
        mut, green, orange = lm.CHIP_MUTED, POLED, MISSING
        lines = []
        if info["what"] == "vertex":
            state = ("<span style='color:%s'>pole %s</span>" % (green, info["pole"] or "")) if info["has_pole"] \
                else "<span style='color:%s'>no pole</span>" % orange
            lines.append("<span style='color:%s;font-size:13px'>Vertex %d of %d</span> · %s"
                         % (lm.CHIP_TEXT, info["vertex_i"] or 0, info["n"], state))
        elif info["what"] == "mark":
            lines.append("<span style='color:%s;font-size:13px'>On the %g m mark</span> · new vertex + pole"
                         % (lm.VM_ON, self.step()))
        else:
            lines.append("<span style='color:%s;font-size:13px'>On the line</span> · new vertex + pole" % lm.CHIP_TEXT)
        if self._poles() is None:
            lines.append("<span style='color:%s'>Click: no pole layer (Settings)</span>" % orange)
        elif info["has_pole"]:
            lines.append("Click: nothing new (already poled)")
        else:
            lines.append("Click: pole <b>%s</b>" % (info["next_name"] or "(no Name field)"))
        sm = info["shift_missing"]
        lines.append(("Shift+click: <span style='color:%s'>%d missing pole%s</span>" % (orange, sm, "" if sm == 1 else "s"))
                     if sm else "Shift+click: <span style='color:%s'>every vertex poled</span>" % green)
        lines.append("this cable <span style='color:%s'>%d/%d poled</span>" % (green if not info["missing"] else mut,
                                                                              info["poled"], info["n"]))
        return "<span style='color:%s;font-size:11px'>%s</span>" % (mut, "<br>".join(lines))

    def _pole_html_only(self):
        return self._pole_html

    def _label(self, html, colour):
        if self._pole_html and html is not self._pole_html:
            html = self._pole_html + "<br>" + html
        super()._label(html, colour)

    def _not_cable_note(self, pos):
        """F7: the mouse is on a line of the ACTIVE layer, but that layer is not a cable layer."""
        act = self.host.iface.activeLayer()
        if not _is_line(act) or is_cable(act):
            return ""
        rect, p, tol_l = self._search_px(act, pos, HIT_PX)
        for f in act.getFeatures(QgsFeatureRequest().setFilterRect(rect).setNoAttributes().setLimit(10)):
            g = f.geometry()
            if g is not None and not g.isEmpty() and g.closestSegmentWithContext(p)[0] <= tol_l * tol_l:
                return "'%s' is not a cable layer - Click line skips it (cable layers: %s)" % (act.name(), rule_text())
        return ""

    def _show_note(self, note):
        self._clear_bands()
        if self.item is not None:
            self.item.set_state(None, None, None, [], None, lm.CHIP_TEXT)
        self.last = {"note": note, "from_prev": None}
        if self.label is not None and not sip.isdeleted(self.label):
            self.label.bar = None
        super()._label("<span style='color:%s;font-size:11px'>%s</span>" % (lm.CHIP_MUTED, note), core.AMBER)

    # the click ------------------------------------------------------------------
    def _click(self, pos, mods=None):
        if not self.active or self.writer is None:
            return
        shift = bool(mods is not None and (mods & Qt.KeyboardModifier.ShiftModifier))
        try:
            r = self._resolve(pos)
            if r is None:
                return                                   # off every cable: nothing, silently
            lyr = r["layer"]
            pl = self._poles()
            if pl is None:
                self.host.message("Click line: no pole layer (a point layer named 'Poles', or pick one in "
                                  "Settings) - nothing added.")
                return
            why = frozen_reason(QgsProject.instance(), [lyr, pl])
            if why:
                self.host.message("Click line refused: %s. Nothing added." % why)
                return
            self._warn_unnamed(pl)
            if shift:
                self._pole_every_vertex(lyr, r["fid"], pl, "Shift+click")
                return
            name, made, added = self.writer.add(lyr, r["fid"], r["ins"], r["point"], pl)
            what = r["what"]
            note = {"vertex": "on the vertex", "mark": "on the %g m mark" % self.step(), "line": "on the line"}[what]
            self._say("%s %s %s%s" % ("+ pole" if made else "pole", name, note,
                                      "" if added or r["ins"] < 0 else " (vertex not added)"))
        except RuntimeError as ex:
            self.host.message("Click line: %s - nothing added." % ex)
        finally:
            self._mk_key = None
            self._update(QPointF(pos))
            self.host.notify(self)

    def _warn_unnamed(self, pl):
        if not name_fields(pl) and pl.id() not in self._warned:
            self._warned.add(pl.id())
            self.host.message("Click line: '%s' has no Name or Pole ID field - new poles are added without a name."
                              % pl.name())

    def _pole_every_vertex(self, lyr, fid, pl, what):
        """A pole on every vertex of one cable that has none (ends per setting), one edit command."""
        f = lyr.getFeature(fid)
        if not f.isValid():
            return [], 0
        verts = vertex_list(f.geometry())
        if not include_ends():
            verts = [v for v in verts if not v[2]]
        to_pl = QgsCoordinateTransform(lyr.crs(), pl.crs(), QgsProject.instance())
        pts = [to_pl.transform(v[1]) for v in verts]
        made, reused = self.writer.batch(pl, pts, _phase(lyr, f, pl), "%s: poles on %s" % (what, lyr.name()))
        left = self.writer.unpoled(pl, pts)         # independent re-check: every target vertex poled now?
        self.last_batch = {"what": what, "targets": len(pts), "made": len(made), "reused": reused, "unpoled": len(left)}
        if left:
            n = len(left)
            self.host.message("%s: %d vert%s still ha%s no pole (vertex %s) - nothing could be added there."
                              % (what, n, "ex" if n == 1 else "ices", "s" if n == 1 else "ve",
                                 ", ".join(str(verts[i][0] + 1) for i in left[:8]) + (" ..." if n > 8 else "")))
        elif made:
            self._say("%s: + %d pole%s (%s%s)%s" % (what, len(made), "" if len(made) == 1 else "s", made[0],
                                                     (" .. %s" % made[-1]) if len(made) > 1 else "",
                                                     (" · %d vertex%s already poled" % (reused, "" if reused == 1 else "es"))
                                                     if reused else ""))
        else:
            self._say("%s: every vertex of this cable already has a pole" % what)
        return made, reused

    def _say(self, text):
        try:
            self.host.iface.messageBar().pushMessage("Click line", text, Qgis.MessageLevel.Info, 3)
        except Exception:
            QgsMessageLog.logMessage(text, lm.LOG_TAG, Qgis.MessageLevel.Info)

    # auto-pole a cable drawn with Add Line (F9) ------------------------------------
    def _wire_auto(self):
        for lyr in self._ap_wired:
            self._disconnect_owner(lyr)
        self._ap_wired, self._ap = [], {}
        for lyr in all_cable_layers(QgsProject.instance()):
            lid = lyr.id()
            self._connect(lyr, "editCommandStarted", functools.partial(self._ap_started, lid))
            self._connect(lyr, "editCommandEnded", functools.partial(self._ap_ended, lid))
            self._connect(lyr, "editCommandDestroyed", functools.partial(self._ap_destroyed, lid))
            self._connect(lyr, "featureAdded", functools.partial(self._ap_added, lid))
            self._connect(lyr, "featureDeleted", functools.partial(self._own_deleted, lid))
            self._connect(lyr, "afterCommitChanges", functools.partial(self._cable_saved, lid))
            self._connect(lyr, "afterRollBack", functools.partial(self._own_forget, lid))
            self._connect(lyr, "editingStopped", self._sync_next_turn)
            self._ap_wired.append(lyr)
        pl = self._poles()
        if pl is not None and pl not in self._ap_wired:
            self._connect(pl, "afterCommitChanges", self._poles_saved)
            self._ap_wired.append(pl)

    def _poles_saved(self, *args):
        """A Poles save gives every new pole a new fid: records made before it may find their pole by its spot."""
        self._pole_saves += 1

    def _take_rec(self, w, pl, r):
        """Take back the pole of one capture record [pt, pole fid, spot, undo index, Poles saves at the time]."""
        if r[1] is None:
            return False
        return w.take_back(pl, r[1], r[2], r[3], relocate=r[4] != self._pole_saves)

    def _find_own(self, w, pl, pfid, at, saves):
        """fid of the pole this tool made (pfid at `at`, recorded after `saves` Poles saves), or None when it is
        gone or moved. By its spot only when a Poles save has renumbered it since; never a different pole."""
        f = pl.getFeature(pfid) if pfid is not None else QgsFeature()
        g = f.geometry() if f.isValid() else None
        if g is not None and not g.isEmpty() and QgsPointXY(g.vertexAt(0)).distance(at) <= 1e-9:
            return pfid
        return w.pole_at(pl, at) if saves != self._pole_saves else None

    def _sync_next_turn(self, *args):
        """Editing stopped on a cable layer: QGIS drops the line being drawn; look once that has happened."""
        QTimer.singleShot(0, functools.partial(self._cap_sync_later, False))

    @lm.guarded("{key}.autopole")
    def _ap_started(self, lid, *args):
        self._ap[lid] = []

    @lm.guarded("{key}.autopole")
    def _ap_added(self, lid, fid, *args):
        lst = self._ap.get(lid)                  # undo / redo add features outside any edit command: ignored
        if lst is not None and not (self.writer is not None and self.writer.busy):
            lst.append(fid)
        elif lst is None and (lid, fid) in self._parked:
            QTimer.singleShot(0, functools.partial(self._own_restore, lid, fid))   # redo / undo of a delete

    # the poles of a cable drawn here follow that cable (G1: undo / redo / delete) -------------
    # claude:intent MUTATE (edit buffer + a save the operator started) - user asked (JJ 2026-10-23): "Fold into
    #   Click Line" the End-Poles gaps (undo / delete leaves poles, poles not saved with the cable) - plan: Click
    #   Line Gap Fixes rev 1 S1 + S3 (https://claude.ai/artifact/EaNgkmspMK5nu7E5YwXZnk), D2 = save Poles only
    #   when every pending Poles edit is this tool's.
    # claude:boq-impact none for shipped projects (frozen_reason refuses them at every add); elsewhere it only
    #   removes / restores poles THIS tool made for an unsaved cable that is undone, deleted or redone, and saves
    #   Poles after a cable save only when every pending Poles edit is this tool's.
    # claude:approved-destructive - deletes only poles this tool made for a cable that no longer exists, in one
    #   edit command the operator can undo; redo of the cable brings them back.
    @lm.guarded("{key}.owned")
    def _own_deleted(self, lid, fid, *args):
        pts = self._owned.pop((lid, fid), None)
        if pts:
            QTimer.singleShot(0, functools.partial(self._own_drop, lid, fid, pts))   # after the undo / delete

    @lm.guarded("{key}.owned")
    def _own_forget(self, lid, *args):
        """Saved or rolled back: the cable's edit-buffer fid is gone, so its poles are no longer tracked."""
        for d in (self._owned, self._parked):
            for k in [k for k in d if k[0] == lid]:
                del d[k]

    def _stands_on_cable(self, w, pl, at):
        """True when a vertex of any cable lies within the reuse distance of a pole at `at` (pole CRS)."""
        tol = reuse_m()
        prj = QgsProject.instance()
        for lyr in all_cable_layers(prj):
            to_c = QgsCoordinateTransform(pl.crs(), lyr.crs(), prj)
            q = to_c.transform(at)
            e = tol * 2.0 / 110000.0 if lyr.crs().isGeographic() else tol * 2.0 * QgsUnitTypes.fromUnitToUnitFactor(
                Qgis.DistanceUnit.Meters, lyr.crs().mapUnits())
            req = QgsFeatureRequest().setFilterRect(QgsRectangle(q.x() - e, q.y() - e, q.x() + e, q.y() + e))
            for f in lyr.getFeatures(req.setNoAttributes()):
                for v in vertex_list(f.geometry()):
                    if w.metres(lyr.crs(), q, v[1]) <= tol:
                        return True
        return False

    def _cable_back(self, lid, fid):
        lyr = QgsProject.instance().mapLayer(lid)
        if lyr is None or sip.isdeleted(lyr):
            return False
        f = lyr.getFeature(fid)
        return f.isValid() and f.hasGeometry()

    @lm.guarded("{key}.owned")
    def _own_drop(self, lid, fid, recs):
        """The cable is gone (undone / deleted): the poles made for it ([(pole fid, spot, Poles saves)]) go too, in
        ONE edit command, unless another cable stands on them. Remembered so a redo of the cable brings them back.
        A cable already back (undo + redo before this ran) keeps them and stays tracked."""
        if self._cable_back(lid, fid):
            self._owned[(lid, fid)] = recs
            return
        pl = self._poles()
        if pl is None or sip.isdeleted(pl) or not pl.isEditable():
            return
        w = self.writer if self.writer is not None else PoleWriter()   # row switched off since: still clean up
        try:
            fids, gone_pts = [], []
            for pfid, at, saves in recs:
                own = self._find_own(w, pl, pfid, at, saves)
                if own is None or self._stands_on_cable(w, pl, at):
                    continue
                fids.append(own)
                gone_pts.append(at)
        finally:
            if w is not self.writer:
                w.close()
        if not fids:
            return
        pl.beginEditCommand(OWN_DROP)
        n = sum(1 for pfid in fids if pl.deleteFeature(pfid))
        if not n:
            pl.destroyEditCommand()
            return
        pl.endEditCommand()
        pl.triggerRepaint()
        st = pl.undoStack()
        self._parked[(lid, fid)] = {"pts": gone_pts, "fids": fids, "index": st.index() if st is not None else None}
        self.gap_log.append(("dropped", n))
        self._mk_key = None
        lyr = QgsProject.instance().mapLayer(lid)
        self._say("%d pole%s of the undone / deleted %s taken away too" % (
            n, "" if n == 1 else "s", lyr.name() if lyr is not None else "cable"))
        self.host.notify(self)

    @lm.guarded("{key}.owned")
    def _own_restore(self, lid, fid):
        """The cable came back (redo, or undo of its delete): so do its poles - by undoing the edit command that
        took them, when it is still the last thing done on the pole layer, else as new poles on the same spots."""
        park = self._parked.pop((lid, fid), None)
        if park is not None and not self._cable_back(lid, fid):
            self._parked[(lid, fid)] = park          # undone again before this ran: still parked, nothing to do
            return
        pl = self._poles()
        if park is None or pl is None or self.writer is None or not pl.isEditable():
            return
        st = pl.undoStack()
        i = park["index"]
        w = self.writer
        # undo the very command that took them: the last one done on Poles, OWN_DROP, and every pole it took
        # still missing (so it cannot be another cable's drop that landed on the same undo index)
        if st is not None and i is not None and st.index() == i and i > 0 and st.command(i - 1) is not None \
                and st.command(i - 1).text() == OWN_DROP and all(not pl.getFeature(x).isValid() for x in park["fids"]) \
                and all(w.pole_at(pl, p) is None for p in park["pts"]):
            st.undo()
            pl.triggerRepaint()
            back = [(x, p) for x, p in zip(park["fids"], park["pts"]) if pl.getFeature(x).isValid()]
        else:
            lyr = QgsProject.instance().mapLayer(lid)
            f = lyr.getFeature(fid) if lyr is not None else QgsFeature()
            phase = _phase(lyr, f, pl) if f.isValid() else None
            w.batch(pl, park["pts"], phase, "Auto-pole: poles back with %s" % (
                lyr.name() if lyr is not None else "cable"))
            back = list(w.last_made)
        self._owned[(lid, fid)] = [(x, QgsPointXY(p), self._pole_saves) for x, p in back]
        self.gap_log.append(("restored", len(back)))
        self._mk_key = None
        self.host.notify(self)

    # saving a cable layer saves the poles drawn with it (G3, D2) ------------------------------
    @lm.guarded("{key}.save")
    def _cable_saved(self, lid, *args):
        self._own_forget(lid)
        QTimer.singleShot(0, functools.partial(self._save_poles_after, lid))

    @lm.guarded("{key}.save")
    def _save_poles_after(self, lid):
        """Poles saves right after the cable layer, when every pending Poles edit is Click Line's (D2); otherwise
        a message says so and nothing is saved for you."""
        # a line dropped by that save / stop editing loses its poles first; Stop Editing can also switch the
        # row off (QGIS picks another tool), so this runs with the row off too
        if self.active and self.writer is not None:
            self._cap_sync(False)
        else:
            self._late_abandon_check()
        pl = self._poles()
        if pl is None or not pl.isEditable() or not pl.isModified():
            return
        lyr = QgsProject.instance().mapLayer(lid)
        cname = lyr.name() if lyr is not None else "the cable layer"
        if frozen_reason(QgsProject.instance(), [pl]):
            return
        line = self._cap if self._cap is not None else self._cap_stash
        if line is not None and not line["finished"] and any(r[1] is not None for r in line["rec"]):
            self.gap_log.append(("save_deferred", 1))     # a line still being drawn: its poles are not a cable yet
            self.host.message("Click line: '%s' was saved. '%s' was not saved yet: a line is still being drawn - "
                              "finish it, then save '%s' again." % (cname, pl.name(), cname))
            return
        st = pl.undoStack()
        texts = [st.command(i).text() for i in range(st.index())] if st is not None else []
        foreign = [t for t in texts if not t.startswith(OWN_PREFIXES)]
        if foreign or st is None:
            self.host.message("Click line: '%s' was saved, '%s' was not - it also has %d unsaved edit%s Click line "
                              "did not make. Save '%s' yourself." % (cname, pl.name(), len(foreign),
                                                                    "" if len(foreign) == 1 else "s", pl.name()))
            self.gap_log.append(("save_skipped", len(foreign)))
            return
        if pl.commitChanges(False):
            self.gap_log.append(("poles_saved", len(texts)))
            self._say("'%s' saved with '%s'" % (pl.name(), cname))
        else:
            errs = "; ".join(pl.commitErrors()[:3])
            self.gap_log.append(("save_failed", 1))
            text = ("Click line: '%s' was saved but '%s' could not be (%s). The new poles are still unsaved - save "
                    "'%s' yourself." % (cname, pl.name(), errs or "no reason given", pl.name()))
            try:
                self.host.iface.messageBar().pushMessage(lm.LOG_TAG, text, Qgis.MessageLevel.Critical, 0)
            except Exception:
                self.host.message(text)
        self._mk_key = None
        self.host.notify(self)

    def _drop_abandoned_line(self):
        """The line being drawn is gone without being finished (tool or row switched off, editing stopped while
        another layer is current): every pole it made goes. A line still being captured is left alone."""
        cap = self._cap
        if cap is None or cap["finished"] or not cap["rec"] or self.writer is None:
            return
        tool = cap["tool"]
        if sip.isdeleted(tool):
            return                                 # the tool is gone (QGIS closing): its poles stay, as in _cap_sync
        pts = capture_points(tool)
        if pts is None or pts:
            return False                           # still being captured (or this QGIS cannot say): leave it
        rec, cap["rec"] = cap["rec"], []
        pl = self._poles()
        back = sum(1 for r in reversed(rec) if self._take_rec(self.writer, pl, r))
        if back:
            self.capture_log.append(("back", back))
            self._mk_key = None
        return True

    def _stash_line(self):
        """Switching off with a line still being captured: QGIS may drop that line a moment later (editing
        stopped, another tool picked). Keep it, look again on the next turn, and pick it up again if the row
        comes back on while the line is still there."""
        cap = self._cap
        if cap is None or cap["finished"] or not cap["rec"] or sip.isdeleted(cap["tool"]):
            return
        self._cap_stash = cap
        QTimer.singleShot(0, self._late_abandon_check)

    @lm.guarded("{key}.capture")
    def _late_abandon_check(self):
        cap = getattr(self, "_cap_stash", None)
        if cap is None or self.active:
            return                                 # the row is on again: the live sync owns the line
        if sip.isdeleted(cap["tool"]):
            self._cap_stash = None                 # the tool is gone (QGIS closing): its poles stay, as in _cap_sync
            return
        pts = capture_points(cap["tool"])
        if pts is None or pts:
            return
        self._cap_stash = None
        w = PoleWriter()
        try:
            pl = self._poles()
            back = sum(1 for r in reversed(cap["rec"]) if self._take_rec(w, pl, r))
        finally:
            w.close()
        if back:
            self.capture_log.append(("back", back))

    @lm.guarded("{key}.autopole")
    def _ap_destroyed(self, lid, *args):
        self._ap.pop(lid, None)

    @lm.guarded("{key}.autopole")
    def _ap_ended(self, lid, *args):
        added = self._ap.pop(lid, None)
        if not added or len(added) != 1 or not self.active or not auto_draw():
            return                               # one line drawn = one feature; a paste of many is not ours
        if not is_add_line(self.canvas.mapTool()):
            return
        lyr = QgsProject.instance().mapLayer(lid)
        cur = self.canvas.currentLayer()
        if not is_cable(lyr) or (cur is not None and cur is not lyr):
            return
        cap = self._cap
        if cap is not None and cap["layer"] == lid and not cap["finished"]:
            cap["finished"] = True               # the line is in: its per-click poles stay
            self._cap_done.append((lid, [(r[1], r[2], r[4]) for r in cap["rec"] if r[1] is not None]))
        QTimer.singleShot(0, functools.partial(self._auto_pole, lid, added[0]))

    @lm.guarded("{key}.autopole")
    def _auto_pole(self, lid, fid):
        if not self.active or self.writer is None:
            return
        lyr = QgsProject.instance().mapLayer(lid)
        if lyr is None or not is_cable(lyr):
            return
        pl = self._poles()
        if pl is None:
            self.host.message("Auto-pole: no pole layer (a point layer named 'Poles', or pick one in Settings) "
                              "- the line has no poles.")
            return
        why = frozen_reason(QgsProject.instance(), [lyr, pl])
        if why:
            self.host.message("Auto-pole refused: %s. No poles added." % why)
            return
        self._warn_unnamed(pl)
        mine = []
        for i, (d_lid, _poles) in enumerate(self._cap_done):
            if d_lid == lid:
                mine = self._cap_done.pop(i)[1]
                break
        if not self._cable_back(lid, fid):       # undone before this ran: its clicked poles go with it
            if mine:
                self._own_drop(lid, fid, [(m[0], QgsPointXY(m[1]), m[2]) for m in mine if m[1] is not None])
            return
        self.writer.last_made = []               # never a stale batch's poles when this one adds nothing
        try:
            made, reused = self._pole_every_vertex(lyr, fid, pl, "Auto-pole")
        except RuntimeError as ex:
            self.host.message("Auto-pole: %s - no poles added." % ex)
            return
        owned = [(m[0], QgsPointXY(m[1]), m[2]) for m in mine if m[1] is not None]
        owned += [(x, p, self._pole_saves) for x, p in self.writer.last_made]
        if owned:
            self._owned[(lid, fid)] = owned      # these poles follow this cable (undo / redo / delete)
        self._phase_clicked(lyr, fid, pl, [(m[0], m[1]) for m in mine])
        self.auto_log.append({"layer": lyr.name(), "fid": fid, "made": list(made), "reused": reused,
                              "clicked": len(mine)})
        self._mk_key = None
        self.host.notify(self)

    def _phase_clicked(self, lyr, fid, pl, poles):
        """The poles placed click by click get the finished line's Phase (as auto-pole poles do), one edit command."""
        i = pl.fields().indexOf("Phase")
        f = lyr.getFeature(fid)
        phase = _phase(lyr, f, pl) if f.isValid() else None
        if i < 0 or not poles or phase in (None, "") or str(phase) == "NULL" or not pl.isEditable():
            return
        todo = []
        for pfid, at in poles:
            pf = pl.getFeature(pfid)
            g = pf.geometry() if pf.isValid() else None
            if g is None or g.isEmpty() or QgsPointXY(g.vertexAt(0)).distance(at) > 1e-9:
                continue
            v = pf[i]
            if v is None or str(v) in ("", "NULL"):
                todo.append(pfid)
        if not todo:
            return
        pl.beginEditCommand("Auto-pole: Phase on clicked poles")
        for pfid in todo:
            pl.changeAttributeValue(pfid, i, phase)
        pl.endEditCommand()

    # a pole on each vertex as it is clicked (Add Line, auto-pole on) ---------------------
    @lm.guarded("{key}.capture")
    def _cap_sync_later(self, add):
        self._cap_sync(add)

    def _cap_sync(self, add):
        """Bring the poles in step with the line QGIS's Add Line is capturing: a pole on each vertex a left click
        added (add=True), the pole of a vertex taken back removed, all of them removed when the line is cancelled.
        Only poles this capture made are ever removed; a finished line keeps them."""
        pend = self._pending if add else None
        if add:
            self._pending = None                   # one release, one look (never left to block the move sync)
        if not self.active or self.writer is None:
            return
        cap = self._cap
        tool = self.canvas.mapTool()
        if cap is not None and (sip.isdeleted(cap["tool"]) or cap["tool"] is not tool):
            if sip.isdeleted(cap["tool"]):
                self._cap = cap = None             # the tool is gone: its poles stay (they are real poles)
            else:
                return                             # another tool for now: pick up again when it comes back
        if not (self.drawing and (auto_draw() or exact_on()) and is_add_line(tool)):
            return
        lyr = self.canvas.currentLayer()
        pts = capture_points(tool)
        if (cap is not None and not cap["finished"] and cap["rec"] and pts is not None and not pts
                and (not is_cable(lyr) or cap["layer"] != lyr.id())):
            self._drop_abandoned_line()            # dropped (Esc, editing off) after the current layer changed
            self.host.notify(self)
            return
        if not is_cable(lyr):
            return
        if pts is None:
            return
        if cap is None or cap["layer"] != lyr.id() or cap["finished"]:
            if cap is not None and not cap["finished"] and cap["rec"] and cap["layer"] != lyr.id():
                cap["layer"] = lyr.id()            # the current layer changed mid-line: the same line goes there
            else:
                self._cap = cap = {"tool": tool, "layer": lyr.id(), "rec": [], "finished": False, "said": False}
        rec = cap["rec"]
        k = 0
        while k < len(rec) and k < len(pts) and rec[k][0].distance(pts[k]) <= 1e-9:
            k += 1
        gone = rec[k:]
        if gone:
            del rec[k:]
            pl = self._poles()
            back = 0
            for r in reversed(gone):
                if self._take_rec(self.writer, pl, r):
                    back += 1
            if back:
                self.capture_log.append(("back", back))
                self._mk_key = None
        if add and pend is not None and not gone and k == len(rec) and len(pts) == k + 1:
            pts = self._exact(tool, lyr, pts, cap, pend)   # BEFORE its pole: a vertex is never poled, then moved
        new = pts[k:]
        if not new:
            if gone:
                self.host.notify(self)
            return
        made = 0
        for p in new:
            pfid, at, stack = self._click_pole(lyr, p, cap) if add and auto_draw() else (None, None, None)
            rec.append([QgsPointXY(p), pfid, at, stack, self._pole_saves])
            made += 1 if pfid is not None else 0
        if made:
            self.capture_log.append(("made", made))
            self._mk_key = None
        self.host.notify(self)

    # exact spacing while drawing (Click Line v3 C) ------------------------------------
    def _say_once(self, key, text):
        if key not in self._exact_said:
            self._exact_said.add(key)
            self.host.message(text)

    def _m_per_px(self, map_pt):
        upp = self.canvas.mapUnitsPerPixel()
        return self.writer.metres(self.canvas.mapSettings().destinationCrs(), map_pt,
                                  QgsPointXY(map_pt.x() + upp, map_pt.y()))

    def _exact_target(self, lyr, before, click_l, st, cap):
        """Where a click at click_l (layer CRS) goes with exact spacing: (point in layer CRS, 'step' | 'pole'),
        or (None, why) when the click stays as clicked. before = the vertices already captured (layer CRS)."""
        if not exact_on():
            return None, "off"
        if self._exact_off:
            return None, "self-off"
        for k in ("alt", "snapped", "cad", "tracing"):
            if st[k]:
                return None, k
        if not st["straight"]:
            return None, "curve"
        prj = QgsProject.instance()
        pl = self._poles()
        if frozen_reason(prj, [lyr, pl]):
            return None, "frozen"
        if _qgis_int() < 40200 and lyr.crs() != self.canvas.mapSettings().destinationCrs():
            self._say_once("reproj", "Exact spacing is off on QGIS %s while the cable layer's CRS differs from the "
                                     "map CRS (a QGIS 3.x undo fault): clicks stay where clicked." % Qgis.version())
            return None, "reprojected"
        w = self.writer
        to_w = w._to_wgs(lyr.crs())
        cw = to_w.transform(click_l)
        last = cap.get("last_click") if cap is not None else None
        if last is not None and w.da.measureLine(last, cw) < EXACT_FREE_M:
            return None, "double"                 # the second click of a double-click: never a point 50 m on
        if before and w.da.measureLine(to_w.transform(before[-1]), cw) < EXACT_FREE_M:
            return None, "short"
        if pl is not None:                        # a click near a pole: the vertex goes exactly on that pole
            w.index.set_layer(pl)
            to_pl = QgsCoordinateTransform(lyr.crs(), pl.crs(), prj)
            fid, _m = w.index.near(to_pl.transform(click_l), vertex_px() * self._m_per_px(st["map"]))
            if fid is not None:
                g = pl.getFeature(fid).geometry()
                if g is not None and not g.isEmpty():
                    return to_pl.transform(QgsPointXY(g.vertexAt(0)), Qgis.TransformDirection.Reverse), "pole"
        if not before:
            return None, "first"
        pw = to_w.transform(before[-1])
        tw = w.da.computeSpheroidProject(pw, self.step(), w.da.bearing(pw, cw))
        return to_w.transform(tw, Qgis.TransformDirection.Reverse), "step"

    def _exact(self, tool, lyr, pts, cap, pend):
        """The vertex this click just added, moved to its exact spot (see _exact_target) and read back; if QGIS
        did not put it there the click is put back as clicked and exact spacing switches off for the session."""
        click_l = QgsPointXY(pts[-1])
        target, what = self._exact_target(lyr, pts[:-1], click_l, pend, cap)
        cap["last_click"] = self.writer._to_wgs(lyr.crs()).transform(click_l)
        if target is None:
            self.exact_log.append(("as clicked: " + what, None))
            return pts
        to_m = QgsCoordinateTransform(lyr.crs(), self.canvas.mapSettings().destinationCrs(), QgsProject.instance())
        n0 = len(pts)
        try:
            swap_last_vertex(tool, self.canvas, to_m.transform(target))
        except Exception:
            lm._log_quiet(traceback.format_exc())
        after = capture_points(tool) or []
        off = self.writer.metres(lyr.crs(), after[-1], target) if len(after) == n0 else None
        if off is not None and off <= EXACT_OK_M:
            self.exact_log.append((what, off))
            return after
        try:                                       # put the click back where it was clicked
            if len(capture_points(tool) or []) == n0:
                _backspace(tool)
            if len(capture_points(tool) or []) == n0 - 1:
                _release_at(tool, self.canvas, to_m.transform(click_l))
        except Exception:
            lm._log_quiet(traceback.format_exc())
        back = capture_points(tool) or []
        ok = len(back) == n0 and self.writer.metres(lyr.crs(), back[-1], click_l) <= EXACT_OK_M
        self._exact_off = "read-back %s" % ("%.3f m off" % off if off is not None else "lost the vertex")
        self.exact_log.append(("restored" if ok else "restore failed", off))
        self._cross(None)
        self.host.message("Exact spacing switched itself off for this session: QGIS did not put the vertex on the "
                          "exact spot (%s). %s" % (self._exact_off, "The click is kept as clicked." if ok else
                                                   "Check the last vertex (Backspace takes it back)."))
        return back or pts

    @lm.guarded("{key}.cross")
    def _preview_cross(self, event):
        """The cross where the next click will land, shown only when that click will be moved."""
        if not exact_on() or self._exact_off or self.writer is None:
            return self._cross(None)
        tool = self.canvas.mapTool()
        lyr = self.canvas.currentLayer()
        pts = capture_points(tool) if is_add_line(tool) and is_cable(lyr) else None
        if pts is None:
            return self._cross(None)
        st = click_state(self.canvas, tool, _pos(event), event.modifiers())
        prj = QgsProject.instance()
        mcrs = self.canvas.mapSettings().destinationCrs()
        click_l = QgsCoordinateTransform(mcrs, lyr.crs(), prj).transform(st["map"])
        cap = self._cap
        if cap is not None and (cap["layer"] != lyr.id() or cap["finished"] or not pts):
            cap = None
        target, _what = self._exact_target(lyr, pts, click_l, st, cap)
        return self._cross(None if target is None else QgsCoordinateTransform(lyr.crs(), mcrs, prj).transform(target))

    def _cross(self, map_pt):
        self.exact_cross = None if map_pt is None else QgsPointXY(map_pt)
        band = self._xband
        if band is not None and sip.isdeleted(band):
            band = self._xband = None
        if map_pt is None:
            if band is not None:
                band.reset(Qgis.GeometryType.Point)
            return
        if band is None:
            band = self._xband = QgsRubberBand(self.canvas, Qgis.GeometryType.Point)
            band.setIcon(QgsRubberBand.IconType.ICON_X)
            band.setIconSize(int(round(14 * self._dpi())))
            band.setColor(QColor(MISSING))
            band.setWidth(int(round(2 * self._dpi())))
            band.setZValue(1023)
        band.reset(Qgis.GeometryType.Point)
        band.addPoint(QgsPointXY(map_pt))

    def _click_pole(self, lyr, p, cap):
        """A pole on the vertex just clicked (layer CRS). Returns (pole fid, its spot in the pole CRS, undo index)
        when a NEW pole was made, else (None, None, None) - an existing pole within the reuse distance is used."""
        none = (None, None, None)
        pl = self._poles()
        why = ""
        if pl is None:
            why = "no pole layer (a point layer named 'Poles', or pick one in Settings) - no poles while drawing"
        else:
            fz = frozen_reason(QgsProject.instance(), [lyr, pl])
            if fz:
                why = "refused: %s. No poles added" % fz
            elif not pl.isEditable() and not pl.startEditing():
                why = "the pole layer cannot be edited - no poles added"
        if why:
            if not cap["said"]:
                cap["said"] = True
                self.host.message("Auto-pole: " + why + ".")
            return none
        self._warn_unnamed(pl)
        to_pl = QgsCoordinateTransform(lyr.crs(), pl.crs(), QgsProject.instance())
        q = to_pl.transform(p)
        name, made, _at = self.writer.place_pole(pl, q, None)
        if name is None or not made or self.writer.last_fid is None:
            return none
        pl.triggerRepaint()
        st = pl.undoStack()
        return self.writer.last_fid, QgsPointXY(q), (st.index() if st is not None else None)

    # status line ------------------------------------------------------------------
    def status_text(self):
        step = self.step()
        if not self.active:
            return ("Hover a cable: every vertex shows (green = pole, orange = none) · click = pole · "
                    "Shift+click = all missing · marks every %g m" % step)
        self._check_project(tell=False)            # a setting changed since switch-on: say it as it is now
        if self.problem:
            return self.problem
        n = len(self.writer.made) if self.writer is not None else 0
        if self.drawing:
            ex = ""
            if exact_on():
                ex = ("exact spacing off (%s) · " % self._exact_off if self._exact_off
                      else "exact %g m (Alt = free click) · " % step)
            if not auto_draw():
                return "Drawing: %sno poles while drawing · Pan / Identify / Select stops it" % ex
            return ("Drawing: a pole on every vertex you click (Backspace takes it back, Esc takes the line's back) · "
                    "%s%d pole(s) added · Pan / Identify / Select stops it" % (ex, n))
        if self.paused:
            return ("On, waiting: another editing tool is picked · %d pole(s) added · Add Line poles as you click · "
                    "Pan / Identify / Select stops it" % n)
        last = self.last or {}
        if last.get("note"):
            return last["note"]
        head = ""
        if last.get("n"):
            head = "this cable %d/%d poled · " % (last.get("poled", 0), last["n"])
        elif last.get("from_prev") is not None:
            head = "%.1f m from previous vertex · " % last["from_prev"]
        return "%sOn · %d pole(s) added · marks every %g m · drag pans, Esc stops" % (head, n, step)
