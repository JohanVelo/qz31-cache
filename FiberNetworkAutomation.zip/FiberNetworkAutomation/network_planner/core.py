"""Core routing logic for FTTH network planning."""

import json
import math
from typing import Tuple, List, Dict, Any, Optional

try:
    import networkx as nx
    from shapely.geometry import shape, Point, LineString
except ImportError:
    # Dependencies will be installed separately
    pass

# Optional fast spatial index for nearest-node queries
try:
    from scipy.spatial import cKDTree as _KDTree
    _SCIPY_AVAILABLE = True
except ImportError:
    _SCIPY_AVAILABLE = False

# dB/km attenuation constants for single-mode fibre (ITU-T G.652D)
_ATTENUATION_DB_PER_KM = 0.35   # typical 1310 nm
_SPLICE_LOSS_DB = 0.1            # per fusion splice
_SPLICE_INTERVAL_M = 2000.0      # splice every 2 km of duct


def load_geojson(data_or_path: Any) -> Dict:
    """Load GeoJSON data from file path or dict."""
    if isinstance(data_or_path, str):
        with open(data_or_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    if isinstance(data_or_path, dict):
        return data_or_path
    raise ValueError('Unsupported geojson input; provide dict or file path')


def _snap_coord(coord: Tuple[float, float], precision: int) -> Tuple[float, float]:
    """Round a coordinate to *precision* decimal places for snap tolerance."""
    return (round(coord[0], precision), round(coord[1], precision))


def _euclidean_dist(a: Tuple[float, float], b: Tuple[float, float]) -> float:
    """2-D Euclidean distance between two coordinate tuples."""
    return math.hypot(b[0] - a[0], b[1] - a[1])


def _optical_loss_db(length_m: float) -> float:
    """Estimate total optical path loss for a duct segment.

    Accounts for fibre attenuation and estimated fusion-splice losses at
    every *_SPLICE_INTERVAL_M* metres.
    """
    loss = (length_m / 1000.0) * _ATTENUATION_DB_PER_KM
    splice_count = int(length_m / _SPLICE_INTERVAL_M)
    loss += splice_count * _SPLICE_LOSS_DB
    return loss


class NetworkGraph:
    """Build and manage a network graph for FTTH routing.

    Improvements over the original implementation:

    * **O(1) node lookup** — a coordinate-keyed dict replaces the O(n) loop
      in ``_ensure_node``.
    * **Snap tolerance** — coordinates are rounded to *snap_precision* decimal
      places before insertion so near-coincident vertices are merged
      automatically (eliminates phantom disconnected segments from floating-
      point drift in GIS data).
    * **Intermediate vertices** — every vertex along a multi-segment polyline
      duct is added to the graph, not just the start/end endpoints.  This
      ensures routes correctly follow bends in the duct network.
    * **KD-tree nearest-node** — ``nearest_node()`` uses a
      ``scipy.spatial.cKDTree`` (O(log n)) when scipy is available, falling
      back to a linear scan otherwise.
    * **A* routing** — ``shortest_path()`` uses ``nx.astar_path`` with a
      Euclidean heuristic for faster pathfinding on large networks.  Pure
      Dijkstra is still available via ``use_astar=False``.
    * **k-shortest paths** — ``k_shortest_paths()`` returns multiple
      alternative routes for resilience / redundancy planning.
    * **Optical-loss weight** — edges carry a ``loss_db`` attribute based on
      ITU-T G.652D fibre attenuation + estimated splice losses.  Pass
      ``weight='loss_db'`` to route by optical budget.
    * **Connected-component info** — ``get_graph_info()`` reports the number
      of isolated network islands.
    """

    def __init__(self, snap_precision: int = 6):
        """Initialise an empty graph.

        Args:
            snap_precision: Decimal places used when snapping coordinates.
                6 ≈ 0.1 m precision for geographic CRS (default).
                Use 2–3 for projected CRS in metres.
        """
        self.G = nx.Graph()
        self.snap_precision = snap_precision
        # O(1) lookup: snapped coord -> node_id
        self._coord_index: Dict[Tuple[float, float], str] = {}
        # KD-tree is rebuilt lazily on first nearest_node call after changes
        self._kdtree = None
        self._kdtree_keys: List[Tuple[float, float]] = []

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _invalidate_kdtree(self) -> None:
        """Mark the KD-tree as stale so it is rebuilt on next query."""
        self._kdtree = None

    def _build_kdtree(self) -> None:
        """Build (or rebuild) the scipy KD-tree from current node coords."""
        coords_with_nodes = [
            (d['coord'], n)
            for n, d in self.G.nodes(data=True)
            if d.get('coord') is not None
        ]
        if not coords_with_nodes:
            self._kdtree = None
            self._kdtree_keys = []
            return
        self._kdtree_keys = [c for c, _ in coords_with_nodes]
        self._kdtree_node_ids = [n for _, n in coords_with_nodes]
        import numpy as _np
        self._kdtree = _KDTree(_np.array(self._kdtree_keys))

    def _ensure_node(self, coord: Tuple[float, float], properties: Optional[Dict] = None) -> str:
        """Return the node ID at *coord*, creating the node if absent.

        Uses the O(1) ``_coord_index`` dict.  The coordinate is snapped to
        ``self.snap_precision`` decimal places before lookup so that
        near-coincident points are merged.
        """
        snapped = _snap_coord(coord, self.snap_precision)
        if snapped in self._coord_index:
            return self._coord_index[snapped]
        node_id = f'p_{snapped[0]}_{snapped[1]}'
        self.G.add_node(node_id, coord=snapped, properties=properties or {})
        self._coord_index[snapped] = node_id
        self._invalidate_kdtree()
        return node_id

    # ------------------------------------------------------------------
    # Public graph-building methods
    # ------------------------------------------------------------------

    def add_nodes_from_geojson(self, nodes_geojson: Any, id_field: str = 'id') -> None:
        """Add named nodes from a GeoJSON point feature collection.

        Args:
            nodes_geojson: GeoJSON dict or file path.
            id_field: Property field to use as the node ID.
        """
        data = load_geojson(nodes_geojson)
        for i, feat in enumerate(data.get('features', [])):
            props = feat.get('properties', {}) or {}
            geom = feat.get('geometry')
            if not geom:
                continue
            pt = shape(geom)
            node_id = props.get(id_field) or f'node_{i}'
            snapped = _snap_coord((float(pt.x), float(pt.y)), self.snap_precision)  # type: ignore[attr-defined]
            self.G.add_node(node_id, coord=snapped, properties=props)
            self._coord_index[snapped] = node_id
        self._invalidate_kdtree()

    def add_edges_from_geojson(
        self,
        ducts_geojson: Any,
        weight_attr: Optional[str] = None,
        add_intermediate_vertices: bool = True,
    ) -> None:
        """Add edges from a GeoJSON LineString feature collection.

        Each segment between consecutive vertices of a polyline becomes a
        separate graph edge (when *add_intermediate_vertices* is True).  This
        ensures the router can follow bends in the duct and correctly computes
        path lengths.

        Args:
            ducts_geojson: GeoJSON dict or file path.
            weight_attr: Optional property field to use for edge weight.
                If supplied and present on a feature, its value overrides the
                geometric length for that *entire* duct.  Per-segment weight
                is then proportionally allocated.
            add_intermediate_vertices: If True (default), every vertex of a
                multi-segment polyline is added as a graph node.  Set to
                False to revert to the legacy start/end-only behaviour.
        """
        data = load_geojson(ducts_geojson)
        for feat in data.get('features', []):
            geom = feat.get('geometry')
            if not geom:
                continue
            line = shape(geom)
            if not isinstance(line, LineString):
                continue
            coords = list(line.coords)
            if len(coords) < 2:
                continue

            props = feat.get('properties', {}) or {}
            total_length = float(line.length)

            # Determine whether a custom weight overrides length
            custom_weight_total: Optional[float] = None
            if weight_attr and weight_attr in props:
                try:
                    custom_weight_total = float(props[weight_attr])
                except (TypeError, ValueError):
                    pass

            if add_intermediate_vertices:
                segments = list(zip(coords[:-1], coords[1:]))
            else:
                segments = [(coords[0], coords[-1])]

            for seg_u_raw, seg_v_raw in segments:
                seg_u = _snap_coord((float(seg_u_raw[0]), float(seg_u_raw[1])), self.snap_precision)
                seg_v = _snap_coord((float(seg_v_raw[0]), float(seg_v_raw[1])), self.snap_precision)
                u = self._ensure_node(seg_u)
                v = self._ensure_node(seg_v)

                seg_length = _euclidean_dist(seg_u, seg_v)

                if custom_weight_total is not None and total_length > 0:
                    # Allocate custom weight proportionally to segment length
                    seg_weight = custom_weight_total * (seg_length / total_length)
                else:
                    seg_weight = seg_length

                loss_db = _optical_loss_db(seg_length)

                self.G.add_edge(
                    u, v,
                    length=seg_length,
                    weight=seg_weight,
                    loss_db=loss_db,
                    properties=props,
                )

    def add_node_from_qgis(self, node_id: str, coord: Tuple[float, float],
                           properties: Optional[Dict] = None) -> None:
        """Add a single named node from a QGIS feature (used by dock_widget).

        Args:
            node_id: Unique string identifier for the node.
            coord: (x, y) coordinate tuple.
            properties: Optional attribute dict.
        """
        snapped = _snap_coord(coord, self.snap_precision)
        self.G.add_node(node_id, coord=snapped, properties=properties or {})
        self._coord_index[snapped] = node_id
        self._invalidate_kdtree()

    def add_edge_from_qgis(
        self,
        coords: List[Tuple[float, float]],
        properties: Optional[Dict] = None,
        add_intermediate_vertices: bool = True,
    ) -> None:
        """Add edges from a QGIS linestring feature coordinate list.

        Args:
            coords: Ordered list of (x, y) vertex coordinates.
            properties: Optional attribute dict copied to every segment edge.
            add_intermediate_vertices: Decompose into per-segment edges.
        """
        if len(coords) < 2:
            return
        props = properties or {}
        if add_intermediate_vertices:
            segments = list(zip(coords[:-1], coords[1:]))
        else:
            segments = [(coords[0], coords[-1])]

        for seg_u_raw, seg_v_raw in segments:
            seg_u = _snap_coord(seg_u_raw, self.snap_precision)
            seg_v = _snap_coord(seg_v_raw, self.snap_precision)
            u = self._ensure_node(seg_u)
            v = self._ensure_node(seg_v)
            seg_length = _euclidean_dist(seg_u, seg_v)
            loss_db = _optical_loss_db(seg_length)
            self.G.add_edge(
                u, v,
                length=seg_length,
                weight=seg_length,
                loss_db=loss_db,
                properties=props,
            )

    # ------------------------------------------------------------------
    # Spatial query methods
    # ------------------------------------------------------------------

    def nearest_node(self, coord: Tuple[float, float]) -> Optional[str]:
        """Find the nearest graph node to *coord*.

        Uses a ``scipy.spatial.cKDTree`` (O(log n)) when scipy is available,
        otherwise falls back to an O(n) linear scan.

        Args:
            coord: (x, y) query coordinate.

        Returns:
            Node ID of the nearest node, or None if the graph is empty.
        """
        if not self.G.nodes():
            return None

        if _SCIPY_AVAILABLE:
            if self._kdtree is None:
                self._build_kdtree()
            if self._kdtree is None:
                return None
            import numpy as _np
            _, idx = self._kdtree.query(_np.array([coord[0], coord[1]]))
            return self._kdtree_node_ids[idx]

        # Fallback: linear scan
        best: Optional[str] = None
        best_dist = float('inf')
        for n, d in self.G.nodes(data=True):
            c = d.get('coord')
            if c is None:
                continue
            dist = _euclidean_dist(coord, c)
            if dist < best_dist:
                best_dist = dist
                best = n
        return best

    # ------------------------------------------------------------------
    # Routing methods
    # ------------------------------------------------------------------

    def shortest_path(
        self,
        source_coord: Tuple[float, float],
        target_coord: Tuple[float, float],
        weight: str = 'weight',
        use_astar: bool = True,
    ) -> List[Tuple[float, float]]:
        """Calculate the shortest path between two coordinates.

        Uses A* with a Euclidean heuristic by default (faster on large
        geographic networks).  Set *use_astar=False* to use Dijkstra.

        Args:
            source_coord: Starting (x, y) coordinate.
            target_coord: Ending (x, y) coordinate.
            weight: Edge attribute for path cost.  Use ``'weight'`` (length),
                ``'loss_db'`` (optical budget), or any custom attribute.
            use_astar: Use A* (default) instead of Dijkstra.

        Returns:
            Ordered list of (x, y) coordinates along the path.

        Raises:
            ValueError: If no path exists between the endpoints.
        """
        s = self.nearest_node(source_coord)
        t = self.nearest_node(target_coord)

        if s is None or t is None:
            raise ValueError('Source or target nearest node not found')

        def _heuristic(u: str, v: str) -> float:
            cu = self.G.nodes[u].get('coord', (0.0, 0.0))
            cv = self.G.nodes[v].get('coord', (0.0, 0.0))
            return _euclidean_dist(cu, cv)

        try:
            if use_astar:
                path_nodes = nx.astar_path(self.G, s, t, heuristic=_heuristic, weight=weight)
            else:
                path_nodes = nx.shortest_path(self.G, s, t, weight=weight)
        except nx.NetworkXNoPath:
            raise ValueError(f'No path exists between nodes {s} and {t}')

        coords = [tuple(self.G.nodes[n]['coord']) for n in path_nodes]
        return coords

    def shortest_path_with_cost(
        self,
        source_coord: Tuple[float, float],
        target_coord: Tuple[float, float],
        weight: str = 'weight',
        use_astar: bool = True,
    ) -> Tuple[List[Tuple[float, float]], float]:
        """Like ``shortest_path`` but also returns the total path cost.

        Returns:
            Tuple of (coordinate list, total cost).
        """
        s = self.nearest_node(source_coord)
        t = self.nearest_node(target_coord)
        if s is None or t is None:
            raise ValueError('Source or target nearest node not found')

        def _heuristic(u: str, v: str) -> float:
            cu = self.G.nodes[u].get('coord', (0.0, 0.0))
            cv = self.G.nodes[v].get('coord', (0.0, 0.0))
            return _euclidean_dist(cu, cv)

        try:
            if use_astar:
                path_nodes = nx.astar_path(self.G, s, t, heuristic=_heuristic, weight=weight)
            else:
                path_nodes = nx.shortest_path(self.G, s, t, weight=weight)
            cost = nx.path_weight(self.G, path_nodes, weight=weight)
        except nx.NetworkXNoPath:
            raise ValueError(f'No path exists between nodes {s} and {t}')

        coords = [tuple(self.G.nodes[n]['coord']) for n in path_nodes]
        return coords, cost

    def k_shortest_paths(
        self,
        source_coord: Tuple[float, float],
        target_coord: Tuple[float, float],
        k: int = 3,
        weight: str = 'weight',
    ) -> List[Tuple[List[Tuple[float, float]], float]]:
        """Return up to *k* shortest simple paths for resilience planning.

        Uses Yen's algorithm (``nx.shortest_simple_paths``).

        Args:
            source_coord: Starting (x, y) coordinate.
            target_coord: Ending (x, y) coordinate.
            k: Maximum number of paths to return.
            weight: Edge attribute for path cost.

        Returns:
            List of (coordinate list, total cost) tuples ordered by cost.
        """
        s = self.nearest_node(source_coord)
        t = self.nearest_node(target_coord)
        if s is None or t is None:
            raise ValueError('Source or target nearest node not found')

        results: List[Tuple[List[Tuple[float, float]], float]] = []
        try:
            for path_nodes in nx.shortest_simple_paths(self.G, s, t, weight=weight):
                cost = nx.path_weight(self.G, path_nodes, weight=weight)
                coords = [tuple(self.G.nodes[n]['coord']) for n in path_nodes]
                results.append((coords, cost))
                if len(results) >= k:
                    break
        except nx.NetworkXNoPath:
            pass
        return results

    # ------------------------------------------------------------------
    # Graph statistics
    # ------------------------------------------------------------------

    def get_graph_info(self) -> Dict[str, Any]:
        """Return graph statistics including connected-component breakdown.

        Returns:
            Dictionary with node/edge counts, connectivity status, number of
            isolated components, and their sizes.
        """
        n_nodes = self.G.number_of_nodes()
        n_edges = self.G.number_of_edges()
        if n_nodes == 0:
            return {
                'nodes': 0,
                'edges': 0,
                'connected': False,
                'components': 0,
                'component_sizes': [],
            }
        components = sorted(
            (len(c) for c in nx.connected_components(self.G)),
            reverse=True,
        )
        total_length = sum(
            d.get('length', 0.0) for _, _, d in self.G.edges(data=True)
        )
        return {
            'nodes': n_nodes,
            'edges': n_edges,
            'connected': len(components) == 1,
            'components': len(components),
            'component_sizes': components,
            'total_length': total_length,
        }


def build_network_from_files(
    nodes_path: Optional[str],
    ducts_path: str,
    weight_attr: Optional[str] = None,
    snap_precision: int = 6,
) -> NetworkGraph:
    """Build a NetworkGraph from GeoJSON files.

    Args:
        nodes_path: Path to nodes GeoJSON file (optional).
        ducts_path: Path to ducts GeoJSON file.
        weight_attr: Optional property field to use for edge weights.
        snap_precision: Coordinate snap precision (decimal places).

    Returns:
        Initialised NetworkGraph.
    """
    ng = NetworkGraph(snap_precision=snap_precision)
    if nodes_path:
        ng.add_nodes_from_geojson(nodes_path)
    ng.add_edges_from_geojson(ducts_path, weight_attr=weight_attr)
    return ng
