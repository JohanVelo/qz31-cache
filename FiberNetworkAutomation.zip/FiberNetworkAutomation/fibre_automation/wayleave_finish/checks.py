"""Check My Wayleave: read-only checks on a hand-drawn wayleave before it is generated.

Every check returns issues as dict(level, code, msg, at) where at is a metric point (or None).
level: 'error' = Generate will refuse until fixed; 'warn' = fix it or accept it; 'info' = for the record.
Nothing here changes the inputs.
"""
from __future__ import annotations

import math
from collections import defaultdict

from .engine import Net, TRANSPORT
from .geom import PointIndex, SegIndex, dijkstra, dist, line_length, seg_project

HOME_FAR = 60.0        # m, a home further than this from any distribution cable needs a drop that is too long
NEAR_MISS = (0.5, 5.0)  # m, a cable end this far from another cable looks like a missed snap
PON_HOMES_MAX = 112     # HeroTel: max 14 x 1:8 per PON (JJ 2026-10-13)


def check(inp, opts=None):
    net = Net(inp, opts); o = net.o
    out = []

    def add(level, code, msg, at=None):
        out.append(dict(level=level, code=code, msg=msg, at=at))

    cables = net.cables
    F = [c for c in cables if c['kind'] == 'F']; L = [c for c in cables if c['kind'] == 'L']; D = [c for c in cables if c['kind'] == 'D']
    # basics
    if not F:
        add('error', 'no_feeder', 'No feeder cable. Draw the feeder from the POP.')
    if net.pop is None:
        add('error', 'no_pop', 'No POP point. Add the POP.')
    if not net.pons:
        add('error', 'no_pons', 'No PON polygons.')
    if not D:
        add('error', 'no_dc', 'No distribution cables.')
    for c in cables:
        for part in c['parts_m']:
            if len(part) < 2 or line_length(part) < 0.01:
                add('error', 'empty_cable', f"A {c['label']} has no length (fid {c['fid']}). Delete it.", part[0] if part else None)
    if not net.pons or not F or net.pop is None:
        return out
    # 1:16s: on transport, one per PON
    tseg = SegIndex(50.0)
    for c in F + L:
        for part in c['parts_m']:
            for a, b in zip(part[:-1], part[1:]):
                tseg.add(c['fid'], a, b)

    def on_transport(p, tol):
        return any(seg_project(a, b, p)[0] <= tol for _, a, b in tseg.near(p, tol))
    rows = net.s16_pon_map()
    fed = defaultdict(list)
    for r in rows:
        s = r['s16']
        if not on_transport(s['m'], o['snap']):
            add('error', 's16_off_cable', 'This 1:16 is not on a feeder or link cable. Move it onto the cable (snap to a vertex).', s['m'])
        if not r['dcs']:
            add('error', 's16_unused', f"This 1:16 starts no distribution cable (nothing within {o['s16_reach']:.0f} m). Delete it, or move it to the PON that has none.", s['m'])
        elif len(r['pons']) > 1:
            add('error', 's16_two_pons', 'This 1:16 starts distribution cables in two PONs. Each PON needs its own 1:16.', s['m'])
        for k in r['pons']:
            fed[k].append(s)
        for c in r['dcs']:
            gap = min(dist(e, s['m']) for e in net.cable_ends(c))
            if o['snap'] < gap < o['s16_reach']:
                add('warn', 'dc_start_gap', f'A distribution cable starts {gap:.1f} m from its 1:16. Snap its first vertex onto the 1:16.', s['m'])
    for k, q in enumerate(net.pons):
        at = q['area'].polys[0][0][0] if q['area'].polys else None
        name = _pon_name(q)
        if len(fed[k]) == 0:
            # where should it go? the nearest point on a transport cable to this PON's own distribution
            add('error', 'pon_no_s16', f'{name} has no 1:16. Add one on the feeder/link where its distribution cable starts, and snap the cable to it.', _pon_anchor(net, k) or at)
        elif len(fed[k]) > 1:
            add('error', 'pon_two_s16', f'{name} has {len(fed[k])} 1:16s. Keep one.', fed[k][1]['m'])
    n16, npon = len(net.s16), len(net.pons)
    if n16 != npon:
        add('error', 's16_count', f'{n16} 1:16s for {npon} PONs. You need exactly one per PON.')
    # every PON has distribution
    dc_pons = defaultdict(int)
    for c in D:
        dc_pons[net.pon_at(net.cable_mid(c))] += 1
    for k, q in enumerate(net.pons):
        if not dc_pons.get(k):
            add('error', 'pon_no_dc', f"{_pon_name(q)} has no distribution cable.", q['area'].polys[0][0][0] if q['area'].polys else None)
    # connected: every 1:16 and link reachable from the POP over feeder/link cables
    nodes = {}; adj = defaultdict(list)

    def node(p):
        key = (round(p[0] / o['snap']), round(p[1] / o['snap']))
        return nodes.setdefault(key, (len(nodes), p))[0]
    allv = []
    for c in F + L:
        for part in c['parts_m']:
            ids = [node(v) for v in part]; allv += list(zip(ids, part))
            for a, b, pa, pb in zip(ids[:-1], ids[1:], part[:-1], part[1:]):
                adj[a].append((b, dist(pa, pb), None)); adj[b].append((a, dist(pa, pb), None))
    vindex = PointIndex([p for _, p in allv], cell=2.0)
    # joints: an end of one transport cable lying on another, on a vertex OR mid-segment (Generate adds the
    # vertex there, so Check must count it as joined) -> join to both ends of that segment
    for c in F + L:
        for e in net.cable_ends(c):
            a = node(e)
            for k in vindex.within(e, o['snap']):
                if allv[k][0] != a:
                    adj[a].append((allv[k][0], 0.0, None)); adj[allv[k][0]].append((a, 0.0, None))
            for _, sa, sb in tseg.near(e, o['snap']):
                if seg_project(sa, sb, e)[0] <= o['snap']:
                    for q in (sa, sb):
                        b = node(q)
                        if b != a:
                            w = dist(e, q); adj[a].append((b, w, None)); adj[b].append((a, w, None))
    starts = {}
    for c in F:
        near = min(net.cable_ends(c), key=lambda q: dist(q, net.pop)); far = dist(near, net.pop)
        if far > 25.0:
            add('error', 'feeder_far_pop', f'A feeder starts {far:.0f} m from the POP. Every feeder must start at the POP: move its first vertex there.', near)
        elif far > 5.0:
            add('warn', 'feeder_far_pop', f'A feeder starts {far:.0f} m from the POP. Snap its first vertex onto the POP.', near)
        starts[node(near)] = 0.0
    reach, _ = dijkstra(adj, starts)

    def reached(p):
        k = vindex.nearest(p, 5.0)
        return k is not None and dist(allv[k][1], p) <= 1.0 and allv[k][0] in reach
    for r in rows:
        if r['dcs'] and on_transport(r['s16']['m'], o['snap']) and not _reached_on_line(r['s16']['m'], tseg, allv, vindex, reach):
            add('error', 's16_not_connected', 'This 1:16 is on a cable that does not connect back to the POP. Join the link to a feeder/link vertex.', r['s16']['m'])
    for c in L:
        if not any(reached(e) for e in net.cable_ends(c)):
            add('error', 'link_loose', 'This link cable does not start on a feeder or link vertex. Snap its first vertex onto one.', c['parts_m'][0][0])
    # near misses: a cable end that stops just short of another cable
    allseg = SegIndex(50.0)
    for c in cables:
        for part in c['parts_m']:
            for a, b in zip(part[:-1], part[1:]):
                allseg.add(id(c), a, b)
    for c in cables:
        for e in net.cable_ends(c):
            best = min((seg_project(a, b, e)[0] for key, a, b in allseg.near(e, NEAR_MISS[1]) if key != id(c)), default=None)
            if best is not None and NEAR_MISS[0] < best <= NEAR_MISS[1]:
                add('warn', 'near_miss', f"A {c['label']} ends {best:.1f} m from another cable. If they should join, snap the end onto it.", e)
    # vertices of two different cables 0.5-3 m apart become two poles side by side
    vx = [(id(c), v) for c in cables for part in c['parts_m'] for v in part]
    vxi = PointIndex([v for _, v in vx], cell=3.0); flagged = []
    for a, (ca, va) in enumerate(vx):
        for b in vxi.within(va, o['near_pole']):
            if b > a and vx[b][0] != ca and dist(va, vx[b][1]) > o['pole_merge'] and all(dist(va, f) > o['near_pole'] for f in flagged):
                flagged.append(va)
                add('warn', 'close_vertices', f"Two cables have vertices {dist(va, vx[b][1]):.1f} m apart: they become two poles side by side. If it is one pole, snap one vertex onto the other.", va)
    # homes far from distribution, and PON size
    dseg = SegIndex(60.0)
    for c in D:
        for part in c['parts_m']:
            for a, b in zip(part[:-1], part[1:]):
                dseg.add(0, a, b)
    far_per_pon = defaultdict(int); homes = defaultdict(int)
    for dp in net.dps:
        k = net.pon_at(dp['m']); homes[k] += int(dp.get('count') or 1)
        d = min((seg_project(a, b, dp['m'])[0] for _, a, b in dseg.near(dp['m'], HOME_FAR)), default=math.inf)
        if d > HOME_FAR:
            far_per_pon[k] += 1
            add('warn', 'home_far', f'Home more than {HOME_FAR:.0f} m from a distribution cable: its drop would be too long.', dp['m'])
    for k, q in enumerate(net.pons):
        if homes.get(k, 0) > PON_HOMES_MAX:
            add('warn', 'pon_big', f"{_pon_name(q)} has {homes[k]} homes: more than {PON_HOMES_MAX} (14 x 1:8).", q['area'].polys[0][0][0])
    # long drawn gaps (Generate adds poles; informational)
    long_gaps = sum(1 for c in cables for part in c['parts_m'] for a, b in zip(part[:-1], part[1:]) if dist(a, b) > o['max_span'])
    if long_gaps:
        add('info', 'long_gaps', f"{long_gaps} drawn gaps are longer than {o['max_span']:.0f} m. Generate adds poles on them; you don't need to.")
    if inp.get('poles_count'):
        add('info', 'poles_exist', f"The Poles layer already has {inp['poles_count']} poles. Generate replaces them (after a backup).")
    return out


def _pon_name(q):
    lab = str(q.get('label') or q['fid']).strip()
    return lab if lab.upper().startswith('PON') else f'PON {lab}'


def _reached_on_line(p, tseg, allv, vindex, reach):
    """A 1:16 counts as connected if a vertex of the transport cable it sits on was reached."""
    for _, a, b in tseg.near(p, 1.0):
        if seg_project(a, b, p)[0] <= 1.0:
            for q in (a, b):
                k = vindex.nearest(q, 1.0)
                if k is not None and allv[k][0] in reach:
                    return True
    return False


def _pon_anchor(net, k):
    """Best spot for a missing 1:16: the PON's distribution-cable end closest to a feeder/link cable."""
    best = None
    T = [c for c in net.cables if c['kind'] in TRANSPORT]
    for c in net.dcs():
        if net.pon_at(net.cable_mid(c)) != k:
            continue
        for e in net.cable_ends(c):
            d = min((net.cable_distance(t, e) for t in T), default=math.inf)
            if best is None or d < best[0]:
                best = (d, e)
    return best[1] if best else None


def summary(issues):
    n = defaultdict(int)
    for i in issues:
        n[i['level']] += 1
    return dict(errors=n['error'], warnings=n['warn'], info=n['info'])
