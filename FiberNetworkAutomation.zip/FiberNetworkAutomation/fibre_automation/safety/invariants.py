"""invariants — cheap structural self-checks on an FTTH project (bundled, stdlib + native QGIS).

The single highest-ROI reliability lever: a set of fast, fail-soft assertions that
catch the "a fix silently broke something" class BEFORE it ships — the Rico
zone-over-the-whole-map class would have been caught here in <100 ms.

  run(project=None) → {verdict: OK|REVIEW|FAIL, checks: [{check, status, detail, severity}]}

Severity: CRITICAL (blocks publish) · WARN (advisory) · SKIP (not applicable / no layer).
Heavy per-feature checks SAMPLE (cap) to stay well under ~500 ms even on 20k+ layers.
Never raises out — a checker glitch downgrades to SKIP, it never blocks a real publish wrongly.
"""
SAMPLE_CAP = 1500            # per-feature checks sample up to this many features
EXTENT_RATIO_MAX = 10.0      # output extent area / AOI area — > this = blowout
SPAN_DROP_M = 55.0
SPAN_FEEDER_M = 70.0

# layer-name tokens (lowercased, ALL required) → role
_CABLE_TOKENS = {
    "primary": ("primary",), "secondary": ("secondary",),
    "distribution": ("distribution",), "drop": ("drop",),
}
_DROP_EXCLUDE = ("spare", "backup", "old")


def _vlayers(project):
    from qgis.core import QgsVectorLayer
    return [l for l in project.mapLayers().values()
            if isinstance(l, QgsVectorLayer) and l.isValid()]


def _find(layers, tokens, exclude=()):
    for l in layers:
        n = l.name().lower()
        if all(t in n for t in tokens) and not any(e in n for e in exclude):
            return l
    return None


def _safe(fn, default=None):
    try:
        return fn()
    except Exception:
        return default


def _add(out, check, status, detail, severity="WARN"):
    out.append({"check": check, "status": status, "detail": detail, "severity": severity})


# ── individual checks (each appends 0..n rows; never raises) ──────────────────
def _chk_extent_ratio(out, project, layers):
    aoi = _find(layers, ("aoi",)) or _find(layers, ("informal", "area"))
    if aoi is None or aoi.featureCount() == 0:
        _add(out, "extent_ratio", "SKIP", "no AOI layer to bound against", "WARN")
        return
    ae = aoi.extent()
    aoi_area = ae.width() * ae.height()
    if aoi_area <= 0:
        _add(out, "extent_ratio", "SKIP", "AOI extent is zero", "WARN")
        return
    for l in layers:
        if l is aoi or l.featureCount() == 0:
            continue
        nm = l.name().lower()
        if not any(t in nm for t in ("cable", "splitter", "pole", "ont", "zone",
                                     "enclosure", "drop", "home")):
            continue
        e = l.extent()
        ratio = (e.width() * e.height()) / aoi_area
        if ratio > EXTENT_RATIO_MAX:
            _add(out, "extent_ratio", "CRITICAL",
                 f"'{l.name()}' extent is {ratio:.1f}× the AOI — likely a feature "
                 f"placed far off-map (the zone-over-whole-map class)", "CRITICAL")
    if not any(c["check"] == "extent_ratio" and c["status"] == "CRITICAL" for c in out):
        _add(out, "extent_ratio", "OK", f"all layers within {EXTENT_RATIO_MAX:.0f}× the AOI", "CRITICAL")


def _chk_null_geoms(out, layers):
    bad = []
    for l in layers:
        nm = l.name().lower()
        if not any(t in nm for t in ("cable", "splitter", "pole", "ont", "enclosure",
                                     "zone", "home", "pon")):
            continue
        n = 0
        for i, f in enumerate(l.getFeatures()):
            if i >= SAMPLE_CAP:
                break
            g = f.geometry()
            if not g or g.isEmpty():
                n += 1
        if n:
            bad.append(f"{l.name()}:{n}")
    if bad:
        _add(out, "null_geometry", "CRITICAL",
             f"null/empty geometries (sampled ≤{SAMPLE_CAP}/layer): {', '.join(bad[:8])}",
             "CRITICAL")
    else:
        _add(out, "null_geometry", "OK", "no null/empty geometries in key layers", "CRITICAL")


def _chk_crs_consistent(out, layers):
    crs = {}
    for l in layers:
        nm = l.name().lower()
        if any(t in nm for t in ("cable", "splitter", "pole", "ont", "enclosure",
                                 "zone", "pon", "home")):
            crs.setdefault(l.crs().authid() or "(none)", []).append(l.name())
    if len(crs) > 1:
        _add(out, "crs_consistent", "CRITICAL",
             "mixed CRS across project layers: "
             + "; ".join(f"{k}×{len(v)}" for k, v in crs.items()), "CRITICAL")
    elif crs:
        _add(out, "crs_consistent", "OK", f"all key layers in {next(iter(crs))}", "CRITICAL")
    else:
        _add(out, "crs_consistent", "SKIP", "no key layers found", "WARN")


def _chk_key_layers_nonempty(out, layers):
    empties = []
    for role, toks in _CABLE_TOKENS.items():
        exc = _DROP_EXCLUDE if role == "drop" else ()
        l = _find(layers, toks, exc)
        if l is not None and l.featureCount() == 0:
            empties.append(l.name())
    if empties:
        # WARN not CRITICAL: an empty output layer is usually "not built yet"
        # (design mid-workflow), not corruption — don't hard-fail an in-progress project.
        _add(out, "key_layers_nonempty", "WARN",
             f"key output layer(s) empty (not built yet?): {', '.join(empties)}", "WARN")
    else:
        _add(out, "key_layers_nonempty", "OK", "key cable layers non-empty", "WARN")


def _chk_geom_valid(out, layers):
    bad = []
    for l in layers:
        nm = l.name().lower()
        if not any(t in nm for t in ("cable", "zone", "enclosure", "pon", "aoi")):
            continue
        n = 0
        for i, f in enumerate(l.getFeatures()):
            if i >= 600:   # validity is the most expensive — tighter sample
                break
            g = f.geometry()
            if g and not g.isEmpty() and not _safe(lambda: g.isGeosValid(), True):
                n += 1
        if n:
            bad.append(f"{l.name()}:{n}")
    if bad:
        _add(out, "geometry_valid", "WARN",
             f"invalid geometries (sampled ≤600/layer): {', '.join(bad[:6])}", "WARN")
    else:
        _add(out, "geometry_valid", "OK", "sampled geometries valid", "WARN")


def _chk_span_limits(out, project, layers):
    from qgis.core import QgsDistanceArea, QgsCoordinateReferenceSystem
    da = QgsDistanceArea()
    da.setSourceCrs(QgsCoordinateReferenceSystem("EPSG:32735"), project.transformContext())
    da.setEllipsoid("WGS84")
    from qgis.core import QgsGeometry, QgsCoordinateTransform
    over = []
    for role, toks in _CABLE_TOKENS.items():
        exc = _DROP_EXCLUDE if role == "drop" else ()
        l = _find(layers, toks, exc)
        if l is None:
            continue
        limit = SPAN_DROP_M if role == "drop" else SPAN_FEEDER_M
        lcrs = l.crs()
        utm = QgsCoordinateReferenceSystem("EPSG:32735")
        xform = QgsCoordinateTransform(lcrs, utm, project) if lcrs != utm else None
        n = 0
        for i, f in enumerate(l.getFeatures()):
            if i >= SAMPLE_CAP:
                break
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            if xform is not None:
                g = QgsGeometry(g)
                _safe(lambda: g.transform(xform))
            if _safe(lambda: da.measureLength(g), 0) > limit + 0.5:
                n += 1
        if n:
            over.append(f"{role}:{n}>{limit:.0f}m")
    if over:
        _add(out, "span_limits", "WARN",
             f"over-length spans (sampled): {', '.join(over)}", "WARN")
    else:
        _add(out, "span_limits", "OK", "sampled spans within limits", "WARN")


def _chk_drop_vs_ont(out, layers):
    drop = _find(layers, ("drop",), _DROP_EXCLUDE)
    ont = _find(layers, ("ont",)) or _find(layers, ("home", "connection"))
    if drop is None or ont is None:
        _add(out, "drop_vs_ont", "SKIP", "drop or ONT layer missing", "WARN")
        return
    d, o = drop.featureCount(), ont.featureCount()
    if o and abs(d - o) / o > 0.1:
        _add(out, "drop_vs_ont", "WARN",
             f"drops={d} vs ONTs={o} (>10% apart — orphans / missing drops?)", "WARN")
    else:
        _add(out, "drop_vs_ont", "OK", f"drops={d} ≈ ONTs={o}", "WARN")


# ── runner ────────────────────────────────────────────────────────────────────
def run(project=None):
    """Run all invariants on the live project. Returns {verdict, checks}. Never raises."""
    out = []
    try:
        from qgis.core import QgsProject
        project = project or QgsProject.instance()
        layers = _vlayers(project)
        if not layers:
            return {"verdict": "SKIP", "checks": [
                {"check": "project", "status": "SKIP", "detail": "no vector layers",
                 "severity": "WARN"}]}
        for fn in (lambda: _chk_extent_ratio(out, project, layers),
                   lambda: _chk_null_geoms(out, layers),
                   lambda: _chk_crs_consistent(out, layers),
                   lambda: _chk_key_layers_nonempty(out, layers),
                   lambda: _chk_geom_valid(out, layers),
                   lambda: _chk_span_limits(out, project, layers),
                   lambda: _chk_drop_vs_ont(out, layers)):
            _safe(fn)
    except Exception as e:
        out.append({"check": "runner", "status": "SKIP",
                    "detail": f"invariants errored (non-blocking): {e}", "severity": "WARN"})
    crit = [c for c in out if c["status"] == "CRITICAL" and c["severity"] == "CRITICAL"]
    warn = [c for c in out if c["status"] == "WARN"]
    verdict = "FAIL" if crit else ("REVIEW" if warn else "OK")
    return {"verdict": verdict, "checks": out,
            "critical": [c["detail"] for c in crit], "warnings": [c["detail"] for c in warn]}
