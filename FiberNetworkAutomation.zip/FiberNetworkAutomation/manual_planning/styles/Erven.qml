<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyDrawingHints="1" symbologyReferenceScale="-1" maxScale="0" hasScaleBasedVisibilityFlag="0" minScale="100000000" simplifyDrawingTol="1" simplifyLocal="1" styleCategories="AllStyleCategories" autoRefreshMode="Disabled" simplifyAlgorithm="0" version="3.44.4-Solothurn" readOnly="0" labelsEnabled="0" autoRefreshTime="0" simplifyMaxScale="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endField="" startExpression="" endExpression="" durationField="" mode="0" limitMode="0" startField="" enabled="0" fixedDuration="0" durationUnit="min" accumulate="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation zoffset="0" extrusion="0" type="IndividualFeatures" zscale="1" clamping="Terrain" extrusionEnabled="0" binding="Centroid" customToleranceEnabled="0" showMarkerSymbolInSurfacePlots="0" symbology="Line" respectLayerSymbol="1">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol name="" clip_to_extent="1" type="line" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleLine" id="{4090db19-db39-4fd8-b7d3-6671d2539cee}" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="164,113,88,255,rgb:0.6431373,0.4431373,0.345098,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol name="" clip_to_extent="1" type="fill" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleFill" id="{981d55c2-d406-4a7a-af45-56eb0f1f5c7f}" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="164,113,88,255,rgb:0.6431373,0.4431373,0.345098,1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="117,81,63,255,rgb:0.4588235,0.3176471,0.2470588,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol name="" clip_to_extent="1" type="marker" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleMarker" id="{5f8b6b18-85ad-46c5-8bb1-e068e07de0c9}" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="164,113,88,255,rgb:0.6431373,0.4431373,0.345098,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="diamond"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="117,81,63,255,rgb:0.4588235,0.3176471,0.2470588,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" type="singleSymbol" forceraster="0" referencescale="-1" symbollevels="0">
    <symbols>
      <symbol name="0" clip_to_extent="1" type="fill" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleLine" id="{c7946890-c812-4ea7-a8b1-b2bb876571b4}" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="17,17,3,255,hsv:0.16713888888888889,0.84817273212787059,0.06512550545510033,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.26"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol name="" clip_to_extent="1" type="fill" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleFill" id="{e6138117-38f9-4f57-b89f-35c970d35ea0}" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="0,0,255,255,rgb:0,0,1,1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.26"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style fontWeight="75" textOpacity="1" multilineHeight="1" fontSizeUnit="RenderMetersInMapUnits" forcedItalic="0" stretchFactor="100" isExpression="0" fontFamily="Open Sans" textOrientation="horizontal" tabStopDistance="80" fontKerning="1" capitalization="0" tabStopDistanceUnit="Point" legendString="Aa" blendMode="0" useSubstitutions="0" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" textColor="50,50,50,255,rgb:0.1960784,0.1960784,0.1960784,1" forcedBold="0" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fieldName="Label" multilineHeightUnit="Percentage" allowHtml="0" fontLetterSpacing="0" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" fontWordSpacing="0" namedStyle="Bold" fontItalic="0" fontStrikeout="0" fontSize="3">
        <families/>
        <text-buffer bufferSizeUnits="MM" bufferNoFill="1" bufferSize="1" bufferOpacity="1" bufferDraw="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferColor="250,250,250,255,rgb:0.9803922,0.9803922,0.9803922,1" bufferBlendMode="0"/>
        <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSize="1.5" maskedSymbolLayers="" maskSizeUnits="MM" maskEnabled="0" maskType="0" maskSize2="1.5" maskJoinStyle="128" maskOpacity="1"/>
        <background shapeBorderWidthUnit="Point" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeSizeX="0" shapeRadiiUnit="Point" shapeBlendMode="0" shapeDraw="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeSizeY="0" shapeSizeUnit="Point" shapeType="0" shapeOffsetY="0" shapeOffsetUnit="Point" shapeRadiiY="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeBorderWidth="0" shapeSVGFile="" shapeOffsetX="0" shapeRotation="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeSizeType="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeRotationType="0">
          <symbol name="markerSymbol" clip_to_extent="1" type="marker" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer locked="0" enabled="1" class="SimpleMarker" id="" pass="0">
              <Option type="Map">
                <Option name="angle" type="QString" value="0"/>
                <Option name="cap_style" type="QString" value="square"/>
                <Option name="color" type="QString" value="229,182,54,255,rgb:0.8980392,0.7137255,0.2117647,1"/>
                <Option name="horizontal_anchor_point" type="QString" value="1"/>
                <Option name="joinstyle" type="QString" value="bevel"/>
                <Option name="name" type="QString" value="circle"/>
                <Option name="offset" type="QString" value="0,0"/>
                <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="offset_unit" type="QString" value="MM"/>
                <Option name="outline_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
                <Option name="outline_style" type="QString" value="solid"/>
                <Option name="outline_width" type="QString" value="0"/>
                <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="outline_width_unit" type="QString" value="MM"/>
                <Option name="scale_method" type="QString" value="diameter"/>
                <Option name="size" type="QString" value="2"/>
                <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="size_unit" type="QString" value="MM"/>
                <Option name="vertical_anchor_point" type="QString" value="1"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol name="fillSymbol" clip_to_extent="1" type="fill" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer locked="0" enabled="1" class="SimpleFill" id="" pass="0">
              <Option type="Map">
                <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                <Option name="joinstyle" type="QString" value="bevel"/>
                <Option name="offset" type="QString" value="0,0"/>
                <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="offset_unit" type="QString" value="MM"/>
                <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                <Option name="outline_style" type="QString" value="no"/>
                <Option name="outline_width" type="QString" value="0"/>
                <Option name="outline_width_unit" type="QString" value="Point"/>
                <Option name="style" type="QString" value="solid"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowBlendMode="6" shadowOffsetAngle="135" shadowOffsetGlobal="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowScale="100" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetDist="1" shadowRadiusUnit="MM"/>
        <dd_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format rightDirectionSymbol=">" decimals="3" autoWrapLength="0" addDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" plussign="0" wrapChar="" reverseDirectionSymbol="0" placeDirectionSymbol="0" multilineAlign="3" leftDirectionSymbol="&lt;" formatNumbers="0"/>
      <placement preserveRotation="1" lineAnchorType="0" quadOffset="4" lineAnchorClipping="0" distMapUnitScale="3x:0,0,0,0,0,0" polygonPlacementFlags="2" geometryGenerator="" layerType="PolygonGeometry" dist="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" rotationAngle="0" rotationUnit="AngleDegrees" maxCurvedCharAngleIn="25" priority="5" centroidInside="0" yOffset="0" prioritization="PreferCloser" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" lineAnchorTextPoint="FollowPlacement" fitInPolygonOnly="0" repeatDistance="0" maximumDistanceUnit="MM" geometryGeneratorEnabled="0" repeatDistanceUnits="MM" overlapHandling="PreventOverlap" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" placementFlags="10" lineAnchorPercent="0.5" centroidWhole="0" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" maximumDistance="0" xOffset="0" placement="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" overrunDistanceUnit="MM" allowDegraded="0" distUnits="MM"/>
      <rendering labelPerPart="0" obstacleType="1" fontMaxPixelSize="10000" fontMinPixelSize="3" scaleMax="0" scaleMin="0" obstacle="1" maxNumLabels="2000" upsidedownLabels="0" obstacleFactor="1" scaleVisibility="0" fontLimitPixelSize="0" zIndex="0" unplacedVisibility="0" drawLabels="1" minFeatureSize="0" mergeLines="0" limitNumLabels="0"/>
      <dd_properties>
        <Option type="Map">
          <Option name="name" type="QString" value=""/>
          <Option name="properties"/>
          <Option name="type" type="QString" value="collection"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
          <Option name="blendMode" type="int" value="0"/>
          <Option name="ddProperties" type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
          <Option name="drawToAllParts" type="bool" value="false"/>
          <Option name="enabled" type="QString" value="0"/>
          <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
          <Option name="lineSymbol" type="QString" value="&lt;symbol name=&quot;symbol&quot; clip_to_extent=&quot;1&quot; type=&quot;line&quot; is_animated=&quot;0&quot; force_rhr=&quot;0&quot; alpha=&quot;1&quot; frame_rate=&quot;10&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; enabled=&quot;1&quot; class=&quot;SimpleLine&quot; id=&quot;{88a2447c-db9b-4f27-887d-c5738da2cca8}&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
          <Option name="minLength" type="double" value="0"/>
          <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="minLengthUnit" type="QString" value="MM"/>
          <Option name="offsetFromAnchor" type="double" value="0"/>
          <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
          <Option name="offsetFromLabel" type="double" value="0"/>
          <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option name="dualview/previewExpressions" type="List">
        <Option type="QString" value="&quot;Label&quot;"/>
      </Option>
      <Option name="embeddedWidgets/count" type="int" value="0"/>
      <Option name="variableNames" type="invalid"/>
      <Option name="variableValues" type="invalid"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <LinearlyInterpolatedDiagramRenderer upperValue="0" lowerHeight="0" diagramType="Histogram" attributeLegend="1" lowerWidth="0" lowerValue="0" upperWidth="5" classificationAttributeExpression="" upperHeight="5">
    <DiagramCategory rotationOffset="270" minScaleDenominator="0" width="15" sizeType="MM" barWidth="5" opacity="1" penAlpha="255" stackedDiagramMode="Horizontal" sizeScale="3x:0,0,0,0,0,0" minimumSize="0" scaleDependency="Area" spacingUnit="MM" height="15" spacing="5" diagramOrientation="Up" backgroundAlpha="255" spacingUnitScale="3x:0,0,0,0,0,0" showAxis="1" enabled="0" penWidth="0" scaleBasedVisibility="0" lineSizeType="MM" lineSizeScale="3x:0,0,0,0,0,0" labelPlacementMethod="XHeight" stackedDiagramSpacingUnit="MM" stackedDiagramSpacing="0" stackedDiagramSpacingUnitScale="3x:0,0,0,0,0,0" penColor="#000000" direction="0" backgroundColor="#ffffff" maxScaleDenominator="1e+08">
      <fontProperties style="" underline="0" strikethrough="0" bold="0" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0"/>
      <attribute label="" color="#000000" colorOpacity="1" field=""/>
      <axisSymbol>
        <symbol name="" clip_to_extent="1" type="line" is_animated="0" force_rhr="0" alpha="1" frame_rate="10">
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
          <layer locked="0" enabled="1" class="SimpleLine" id="{b3229ef7-f3b6-4e91-a455-a6bd2d40eb16}" pass="0">
            <Option type="Map">
              <Option name="align_dash_pattern" type="QString" value="0"/>
              <Option name="capstyle" type="QString" value="square"/>
              <Option name="customdash" type="QString" value="5;2"/>
              <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="customdash_unit" type="QString" value="MM"/>
              <Option name="dash_pattern_offset" type="QString" value="0"/>
              <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
              <Option name="draw_inside_polygon" type="QString" value="0"/>
              <Option name="joinstyle" type="QString" value="bevel"/>
              <Option name="line_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
              <Option name="line_style" type="QString" value="solid"/>
              <Option name="line_width" type="QString" value="0.26"/>
              <Option name="line_width_unit" type="QString" value="MM"/>
              <Option name="offset" type="QString" value="0"/>
              <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offset_unit" type="QString" value="MM"/>
              <Option name="ring_filter" type="QString" value="0"/>
              <Option name="trim_distance_end" type="QString" value="0"/>
              <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="trim_distance_end_unit" type="QString" value="MM"/>
              <Option name="trim_distance_start" type="QString" value="0"/>
              <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="trim_distance_start_unit" type="QString" value="MM"/>
              <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
              <Option name="use_custom_dash" type="QString" value="0"/>
              <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </LinearlyInterpolatedDiagramRenderer>
  <DiagramLayerSettings priority="0" dist="0" zIndex="0" obstacle="0" showAll="1" linePlacementFlags="18" placement="1">
    <properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration type="Map">
      <Option name="QgsGeometryGapCheck" type="Map">
        <Option name="allowedGapsBuffer" type="double" value="0"/>
        <Option name="allowedGapsEnabled" type="bool" value="false"/>
        <Option name="allowedGapsLayer" type="invalid"/>
      </Option>
    </checkConfiguration>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field name="FeatureId" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ID" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PRCL_KEY" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="LSTATUS" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="WSTATUS" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="GEOM_AREA" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DATE_STAMP" configurationFlags="NoFlag">
      <editWidget type="DateTime">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="MIN_REGION" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="MIN_CODE" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Easting" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Northing" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Altitude" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Measure" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Label" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Orientatio" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Length" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Area" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Key1" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="EntityId" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Key" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ParentId" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Track" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ClassId" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ChangeId" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="UserId" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Timestamp" configurationFlags="NoFlag">
      <editWidget type="DateTime">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Data" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" index="0" field="FeatureId"/>
    <alias name="" index="1" field="ID"/>
    <alias name="" index="2" field="PRCL_KEY"/>
    <alias name="" index="3" field="LSTATUS"/>
    <alias name="" index="4" field="WSTATUS"/>
    <alias name="" index="5" field="GEOM_AREA"/>
    <alias name="" index="6" field="DATE_STAMP"/>
    <alias name="" index="7" field="MIN_REGION"/>
    <alias name="" index="8" field="MIN_CODE"/>
    <alias name="" index="9" field="Easting"/>
    <alias name="" index="10" field="Northing"/>
    <alias name="" index="11" field="Altitude"/>
    <alias name="" index="12" field="Measure"/>
    <alias name="" index="13" field="Label"/>
    <alias name="" index="14" field="Orientatio"/>
    <alias name="" index="15" field="Length"/>
    <alias name="" index="16" field="Area"/>
    <alias name="" index="17" field="Key1"/>
    <alias name="" index="18" field="EntityId"/>
    <alias name="" index="19" field="Key"/>
    <alias name="" index="20" field="ParentId"/>
    <alias name="" index="21" field="Track"/>
    <alias name="" index="22" field="ClassId"/>
    <alias name="" index="23" field="ChangeId"/>
    <alias name="" index="24" field="UserId"/>
    <alias name="" index="25" field="Timestamp"/>
    <alias name="" index="26" field="Data"/>
  </aliases>
  <defaults>
    <default expression="" field="FeatureId" applyOnUpdate="0"/>
    <default expression="" field="ID" applyOnUpdate="0"/>
    <default expression="" field="PRCL_KEY" applyOnUpdate="0"/>
    <default expression="" field="LSTATUS" applyOnUpdate="0"/>
    <default expression="" field="WSTATUS" applyOnUpdate="0"/>
    <default expression="" field="GEOM_AREA" applyOnUpdate="0"/>
    <default expression="" field="DATE_STAMP" applyOnUpdate="0"/>
    <default expression="" field="MIN_REGION" applyOnUpdate="0"/>
    <default expression="" field="MIN_CODE" applyOnUpdate="0"/>
    <default expression="" field="Easting" applyOnUpdate="0"/>
    <default expression="" field="Northing" applyOnUpdate="0"/>
    <default expression="" field="Altitude" applyOnUpdate="0"/>
    <default expression="" field="Measure" applyOnUpdate="0"/>
    <default expression="" field="Label" applyOnUpdate="0"/>
    <default expression="" field="Orientatio" applyOnUpdate="0"/>
    <default expression="" field="Length" applyOnUpdate="0"/>
    <default expression="" field="Area" applyOnUpdate="0"/>
    <default expression="" field="Key1" applyOnUpdate="0"/>
    <default expression="" field="EntityId" applyOnUpdate="0"/>
    <default expression="" field="Key" applyOnUpdate="0"/>
    <default expression="" field="ParentId" applyOnUpdate="0"/>
    <default expression="" field="Track" applyOnUpdate="0"/>
    <default expression="" field="ClassId" applyOnUpdate="0"/>
    <default expression="" field="ChangeId" applyOnUpdate="0"/>
    <default expression="" field="UserId" applyOnUpdate="0"/>
    <default expression="" field="Timestamp" applyOnUpdate="0"/>
    <default expression="" field="Data" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="FeatureId"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="ID"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="PRCL_KEY"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="LSTATUS"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="WSTATUS"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="GEOM_AREA"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="DATE_STAMP"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="MIN_REGION"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="MIN_CODE"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="Easting"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="Northing"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="Altitude"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="Measure"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="Label"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="Orientatio"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="Length"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="Area"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="Key1"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="EntityId"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="Key"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="ParentId"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="Track"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="ClassId"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="ChangeId"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="UserId"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="Timestamp"/>
    <constraint unique_strength="0" exp_strength="0" constraints="0" notnull_strength="0" field="Data"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" field="FeatureId" desc=""/>
    <constraint exp="" field="ID" desc=""/>
    <constraint exp="" field="PRCL_KEY" desc=""/>
    <constraint exp="" field="LSTATUS" desc=""/>
    <constraint exp="" field="WSTATUS" desc=""/>
    <constraint exp="" field="GEOM_AREA" desc=""/>
    <constraint exp="" field="DATE_STAMP" desc=""/>
    <constraint exp="" field="MIN_REGION" desc=""/>
    <constraint exp="" field="MIN_CODE" desc=""/>
    <constraint exp="" field="Easting" desc=""/>
    <constraint exp="" field="Northing" desc=""/>
    <constraint exp="" field="Altitude" desc=""/>
    <constraint exp="" field="Measure" desc=""/>
    <constraint exp="" field="Label" desc=""/>
    <constraint exp="" field="Orientatio" desc=""/>
    <constraint exp="" field="Length" desc=""/>
    <constraint exp="" field="Area" desc=""/>
    <constraint exp="" field="Key1" desc=""/>
    <constraint exp="" field="EntityId" desc=""/>
    <constraint exp="" field="Key" desc=""/>
    <constraint exp="" field="ParentId" desc=""/>
    <constraint exp="" field="Track" desc=""/>
    <constraint exp="" field="ClassId" desc=""/>
    <constraint exp="" field="ChangeId" desc=""/>
    <constraint exp="" field="UserId" desc=""/>
    <constraint exp="" field="Timestamp" desc=""/>
    <constraint exp="" field="Data" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="" sortOrder="0">
    <columns>
      <column name="FeatureId" type="field" width="-1" hidden="0"/>
      <column name="ID" type="field" width="-1" hidden="0"/>
      <column name="PRCL_KEY" type="field" width="-1" hidden="0"/>
      <column name="LSTATUS" type="field" width="-1" hidden="0"/>
      <column name="WSTATUS" type="field" width="-1" hidden="0"/>
      <column name="GEOM_AREA" type="field" width="-1" hidden="0"/>
      <column name="DATE_STAMP" type="field" width="-1" hidden="0"/>
      <column name="MIN_REGION" type="field" width="-1" hidden="0"/>
      <column name="MIN_CODE" type="field" width="-1" hidden="0"/>
      <column name="Easting" type="field" width="-1" hidden="0"/>
      <column name="Northing" type="field" width="-1" hidden="0"/>
      <column name="Altitude" type="field" width="-1" hidden="0"/>
      <column name="Measure" type="field" width="-1" hidden="0"/>
      <column name="Label" type="field" width="-1" hidden="0"/>
      <column name="Orientatio" type="field" width="-1" hidden="0"/>
      <column name="Length" type="field" width="-1" hidden="0"/>
      <column name="Area" type="field" width="-1" hidden="0"/>
      <column name="Key1" type="field" width="-1" hidden="0"/>
      <column name="EntityId" type="field" width="-1" hidden="0"/>
      <column name="Key" type="field" width="-1" hidden="0"/>
      <column name="ParentId" type="field" width="-1" hidden="0"/>
      <column name="Track" type="field" width="-1" hidden="0"/>
      <column name="ClassId" type="field" width="-1" hidden="0"/>
      <column name="ChangeId" type="field" width="-1" hidden="0"/>
      <column name="UserId" type="field" width="-1" hidden="0"/>
      <column name="Timestamp" type="field" width="-1" hidden="0"/>
      <column name="Data" type="field" width="-1" hidden="0"/>
      <column type="actions" width="-1" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="Altitude" editable="1"/>
    <field name="Area" editable="1"/>
    <field name="ChangeId" editable="1"/>
    <field name="ClassId" editable="1"/>
    <field name="DATE_STAMP" editable="1"/>
    <field name="Data" editable="1"/>
    <field name="Easting" editable="1"/>
    <field name="EntityId" editable="1"/>
    <field name="FeatureId" editable="1"/>
    <field name="GEOM_AREA" editable="1"/>
    <field name="ID" editable="1"/>
    <field name="Key" editable="1"/>
    <field name="Key1" editable="1"/>
    <field name="LSTATUS" editable="1"/>
    <field name="Label" editable="1"/>
    <field name="Length" editable="1"/>
    <field name="MIN_CODE" editable="1"/>
    <field name="MIN_REGION" editable="1"/>
    <field name="Measure" editable="1"/>
    <field name="Northing" editable="1"/>
    <field name="Orientatio" editable="1"/>
    <field name="PRCL_KEY" editable="1"/>
    <field name="ParentId" editable="1"/>
    <field name="Timestamp" editable="1"/>
    <field name="Track" editable="1"/>
    <field name="UserId" editable="1"/>
    <field name="WSTATUS" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="Altitude" labelOnTop="0"/>
    <field name="Area" labelOnTop="0"/>
    <field name="ChangeId" labelOnTop="0"/>
    <field name="ClassId" labelOnTop="0"/>
    <field name="DATE_STAMP" labelOnTop="0"/>
    <field name="Data" labelOnTop="0"/>
    <field name="Easting" labelOnTop="0"/>
    <field name="EntityId" labelOnTop="0"/>
    <field name="FeatureId" labelOnTop="0"/>
    <field name="GEOM_AREA" labelOnTop="0"/>
    <field name="ID" labelOnTop="0"/>
    <field name="Key" labelOnTop="0"/>
    <field name="Key1" labelOnTop="0"/>
    <field name="LSTATUS" labelOnTop="0"/>
    <field name="Label" labelOnTop="0"/>
    <field name="Length" labelOnTop="0"/>
    <field name="MIN_CODE" labelOnTop="0"/>
    <field name="MIN_REGION" labelOnTop="0"/>
    <field name="Measure" labelOnTop="0"/>
    <field name="Northing" labelOnTop="0"/>
    <field name="Orientatio" labelOnTop="0"/>
    <field name="PRCL_KEY" labelOnTop="0"/>
    <field name="ParentId" labelOnTop="0"/>
    <field name="Timestamp" labelOnTop="0"/>
    <field name="Track" labelOnTop="0"/>
    <field name="UserId" labelOnTop="0"/>
    <field name="WSTATUS" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="Altitude" reuseLastValue="0"/>
    <field name="Area" reuseLastValue="0"/>
    <field name="ChangeId" reuseLastValue="0"/>
    <field name="ClassId" reuseLastValue="0"/>
    <field name="DATE_STAMP" reuseLastValue="0"/>
    <field name="Data" reuseLastValue="0"/>
    <field name="Easting" reuseLastValue="0"/>
    <field name="EntityId" reuseLastValue="0"/>
    <field name="FeatureId" reuseLastValue="0"/>
    <field name="GEOM_AREA" reuseLastValue="0"/>
    <field name="ID" reuseLastValue="0"/>
    <field name="Key" reuseLastValue="0"/>
    <field name="Key1" reuseLastValue="0"/>
    <field name="LSTATUS" reuseLastValue="0"/>
    <field name="Label" reuseLastValue="0"/>
    <field name="Length" reuseLastValue="0"/>
    <field name="MIN_CODE" reuseLastValue="0"/>
    <field name="MIN_REGION" reuseLastValue="0"/>
    <field name="Measure" reuseLastValue="0"/>
    <field name="Northing" reuseLastValue="0"/>
    <field name="Orientatio" reuseLastValue="0"/>
    <field name="PRCL_KEY" reuseLastValue="0"/>
    <field name="ParentId" reuseLastValue="0"/>
    <field name="Timestamp" reuseLastValue="0"/>
    <field name="Track" reuseLastValue="0"/>
    <field name="UserId" reuseLastValue="0"/>
    <field name="WSTATUS" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"Label"</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
