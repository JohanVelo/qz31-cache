"""project_backup — one-click, self-contained backup of the current QGIS project.

Produces:  <dest>/<Project> Backup <YYYY-MM-DD>/
               <Project>.qgz          (RELATIVE paths -> double-click opens straight away)
               + the layer data in the format the operator chose:
                   fmt="gpkg"  ->  <Project>.gpkg   (ALL vectors in one GeoPackage, lossless)
                   fmt="shp"   ->  Shapefiles/*.shp  (one shapefile per layer)

Design (JJ 2026-06-25):
 - CHOICE of output format (GeoPackage or Shapefiles). GeoPackage is lossless; Shapefile
   shortens field names >10 chars -> we warn per layer when that would happen.
 - The backup .qgz is built by writing the LIVE project (captures unsaved structure), then a
   DETACHED QgsProject repoints every layer at its local copy with RELATIVE paths. The live
   project is NEVER mutated (filename/dirty restored).
 - Rasters are copied verbatim; online basemaps (WMS/XYZ) are kept as live links + listed.
 - VERIFY: the written .qgz is re-opened headless and every layer must be .isValid().
"""
import os
import re
import shutil
import zipfile
from datetime import datetime

from qgis.core import (QgsProject, QgsVectorLayer, QgsRasterLayer,
                       QgsVectorFileWriter)

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

SIDECARS = (".shp", ".shx", ".dbf", ".prj", ".cpg", ".qpj", ".sbn", ".sbx",
            ".shp.xml", ".fix", ".aih", ".ain")


def _safe(name):
    return (re.sub(r'[<>:"/\\|?*\n\r\t]+', "_", str(name)).strip() or "layer")[:120]


def _uniq(name, used):
    n = name
    i = 2
    while n.lower() in used:
        n = "%s_%d" % (name, i)
        i += 1
    used.add(n.lower())
    return n


def _src_path(layer):
    """Absolute on-disk primary file of a file-based layer, or None (memory/remote)."""
    try:
        uri = layer.dataProvider().dataSourceUri()
    except Exception:
        return None
    p = uri.split("|")[0].strip().strip('"')
    if p and os.path.isabs(p) and os.path.exists(p):
        return p
    return None


def plan_layers(project):
    """MAIN THREAD. Classify every layer: vector | raster | online | skip."""
    items = []
    for lid, lyr in project.mapLayers().items():
        prov = lyr.dataProvider().name() if lyr.dataProvider() else ""
        it = {"id": lid, "name": lyr.name(), "prov": prov}
        src = _src_path(lyr)
        if prov in ("wms", "wcs", "xyz") or (isinstance(lyr, QgsRasterLayer) and not src):
            it["kind"] = "online"
        elif isinstance(lyr, QgsVectorLayer):
            it.update(kind="vector", src=src)
        elif isinstance(lyr, QgsRasterLayer) and src:
            it.update(kind="raster", src=src)
        else:
            it["kind"] = "skip"
        items.append(it)
    return items


def backup_dir_name(project, when=None):
    base = os.path.splitext(os.path.basename(project.fileName() or "Project"))[0]
    return "%s Backup %s" % (_safe(base) or "Project",
                             (when or datetime.now()).strftime("%Y-%m-%d"))


def _unique_dir(parent, name):
    d = os.path.join(parent, name)
    if not os.path.exists(d):
        return d
    for i in range(2, 1000):
        d2 = os.path.join(parent, "%s (%d)" % (name, i))
        if not os.path.exists(d2):
            return d2
    return os.path.join(parent, "%s %s" % (name, datetime.now().strftime("%H-%M-%S")))


def _copy_verbatim(src, dst):
    base_src, ext = os.path.splitext(src)
    base_dst = os.path.splitext(dst)[0]
    if ext.lower() == ".shp":
        for sc in SIDECARS:
            if os.path.exists(base_src + sc):
                shutil.copy2(base_src + sc, base_dst + sc)
    else:
        shutil.copy2(src, dst)
        for sc in ("-wal", "-shm"):
            if os.path.exists(src + sc):
                shutil.copy2(src + sc, dst + sc)


def create_backup(project, dest_root, fmt="gpkg", make_zip=False, progress_cb=None):
    """MAIN THREAD core. fmt = 'gpkg' (one consolidated GeoPackage) or 'shp' (Shapefiles
    folder). progress_cb(done, total, label). Returns a report dict."""
    fmt = "shp" if str(fmt).lower().startswith("shp") else "gpkg"
    rep = {"ok": False, "fmt": fmt, "exported": [], "copied": [], "online": [],
           "skipped": [], "failed": [], "warnings": [], "valid": 0, "verify_total": 0}
    items = plan_layers(project)
    rep["total_layers"] = len(items)
    bdir = _unique_dir(dest_root, backup_dir_name(project))
    os.makedirs(bdir, exist_ok=True)
    proj_base = _safe(os.path.splitext(os.path.basename(project.fileName() or "Project"))[0])
    gpkg_path = os.path.join(bdir, proj_base + ".gpkg")
    shp_dir = os.path.join(bdir, "Shapefiles")
    if fmt == "shp":
        os.makedirs(shp_dir, exist_ok=True)

    id_to_uri = {}
    used = set()
    first_gpkg = True
    total = len(items)
    for i, it in enumerate(items):
        if progress_cb:
            progress_cb(i, total, it["name"])
        try:
            if it["kind"] == "vector":
                lyr = project.mapLayer(it["id"])
                nm = _uniq(_safe(it["name"]), used)
                opts = QgsVectorFileWriter.SaveVectorOptions()
                opts.fileEncoding = "UTF-8"
                if fmt == "gpkg":
                    opts.driverName = "GPKG"
                    opts.layerName = nm
                    opts.actionOnExistingFile = (
                        QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteFile
                        if first_gpkg else
                        QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteLayer)
                    dst, uri = gpkg_path, "%s|layername=%s" % (gpkg_path, nm)
                else:
                    longf = [f.name() for f in lyr.fields() if len(f.name()) > 10]
                    if longf:
                        rep["warnings"].append(
                            "%s: %d field name(s) shortened to 10 chars (%s)"
                            % (it["name"], len(longf), ", ".join(longf[:4])))
                    opts.driverName = "ESRI Shapefile"
                    dst = os.path.join(shp_dir, nm + ".shp")
                    uri = dst
                res = QgsVectorFileWriter.writeAsVectorFormatV3(
                    lyr, dst, project.transformContext(), opts)
                err = res[0] if isinstance(res, (tuple, list)) else res
                if err != QgsVectorFileWriter.WriterError.NoError:
                    raise RuntimeError("export code %s" % err)
                first_gpkg = first_gpkg and fmt != "gpkg"
                id_to_uri[it["id"]] = uri
                rep["exported"].append(it["name"])
            elif it["kind"] == "raster":
                tgt = shp_dir if fmt == "shp" else bdir
                os.makedirs(tgt, exist_ok=True)
                dst = os.path.join(tgt, os.path.basename(it["src"]))
                _copy_verbatim(it["src"], dst)
                id_to_uri[it["id"]] = dst
                rep["copied"].append(it["name"])
            elif it["kind"] == "online":
                rep["online"].append(it["name"])
            else:
                rep["skipped"].append(it["name"])
        except Exception as e:
            rep["failed"].append((it["name"], str(e)))

    # ── write the backup .qgz: live state, then detached repoint to local copies ──
    if progress_cb:
        progress_cb(total, total, "writing project")
    qgz = os.path.join(bdir, proj_base + ".qgz")
    orig_name, orig_dirty = project.fileName(), project.isDirty()
    try:
        project.write(qgz)
    finally:
        project.setFileName(orig_name)
        project.setDirty(orig_dirty)

    bp = QgsProject()
    bp.read(qgz)
    bp.writeEntryBool("Paths", "Absolute", False)
    for lid, uri in id_to_uri.items():
        lyr = bp.mapLayer(lid)
        if lyr is not None:
            try:
                lyr.setDataSource(uri, lyr.name(), "ogr")
            except Exception as e:
                rep["failed"].append((lyr.name(), "repoint: %s" % e))
    bp.write(qgz)

    chk = QgsProject()
    chk.read(qgz)
    rep["valid"] = sum(1 for ly in chk.mapLayers().values() if ly.isValid())
    rep["verify_total"] = len(chk.mapLayers())

    if make_zip:
        zpath = bdir + ".zip"
        with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
            for root, _d, files in os.walk(bdir):
                for f in files:
                    fp = os.path.join(root, f)
                    z.write(fp, os.path.relpath(fp, os.path.dirname(bdir)))
        rep["zip"] = zpath

    rep["path"], rep["qgz"] = bdir, qgz
    rep["ok"] = (not rep["failed"]) and rep["valid"] == rep["verify_total"]
    return rep


# ─────────────────────────────────────────────────────────────────────────────
# UI — the Backup Project dialog (modern, on-brand). User-initiated; the copy runs
# behind a QProgressDialog with processEvents (not a timer/auto-flow) so the UI stays
# responsive and within the freeze rules.
# ─────────────────────────────────────────────────────────────────────────────

_DLG_QSS = """
QDialog{background:#0b0e13;}
QLabel{color:#e8ecf1;font-family:'Chakra Petch','Segoe UI';}
QFrame#bkHead{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #0B1019,stop:1 #070A11);
  border-bottom:1px solid #22303b;}
QLabel#bkIcon{font-size:22px;}
QLabel#bkTitle{font-size:18px;font-weight:800;}
QLabel#bkSub{color:#9aa4b2;font-size:10px;font-family:'JetBrains Mono',Consolas,monospace;letter-spacing:1px;}
QLabel#bkCap{color:#9aa4b2;font-size:10px;font-weight:700;letter-spacing:1.3px;}
QLabel#bkPreview{color:#22d3ee;font-family:'JetBrains Mono',monospace;font-size:12.5px;
  background:#0a2730;border:1px solid #19414c;border-radius:7px;padding:8px 10px;}
QLabel#bkSummary{color:#9aa4b2;font-size:12px;}
QRadioButton{color:#e8ecf1;font-size:13px;padding:2px 0;}
QCheckBox{color:#e8ecf1;font-size:12.5px;}
QLineEdit#bkInp{background:#0d1217;border:1px solid #2c3a44;border-radius:7px;padding:8px 10px;
  color:#e8ecf1;font-family:'JetBrains Mono',monospace;font-size:12px;}
QPushButton#bkBrowse{background:#11161d;border:1px solid #2c3a44;color:#e8ecf1;border-radius:7px;
  padding:7px 14px;font-weight:700;font-size:12px;}
QPushButton#bkBrowse:hover{border-color:#3f5a68;}
QFrame#bkFoot{background:#0b0e13;border-top:1px solid #22303b;}
QPushButton#bkGhost{background:transparent;color:#9aa4b2;border:1px solid #22303b;border-radius:7px;
  padding:9px 18px;font-weight:700;font-size:12.5px;}
QPushButton#bkGhost:hover{color:#e8ecf1;}
QPushButton#bkCta{background:#22d3ee;color:#062229;border:none;border-radius:7px;
  padding:9px 22px;font-weight:800;font-size:12.5px;}
QPushButton#bkCta:hover{background:#5BF0FF;}
"""


def _cap(text):
    from qgis.PyQt.QtWidgets import QLabel
    lbl = QLabel(text)
    lbl.setObjectName("bkCap")
    return lbl


def _open_folder(path):
    try:
        os.startfile(path)
    except Exception:
        _swallowed_note()


def _show_result(parent, iface, rep):
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                                     QPushButton)
    dlg = QDialog(parent)
    dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
    dlg.setWindowTitle("Backup complete")
    dlg.setMinimumWidth(440)
    dlg.setStyleSheet(_DLG_QSS)
    v = QVBoxLayout(dlg)
    v.setContentsMargins(20, 18, 20, 16)
    v.setSpacing(10)
    ok = rep.get("ok")
    head = QLabel(("✅  Backup ready" if ok else "⚠  Backup finished with issues"))
    head.setStyleSheet("font-size:16px;font-weight:800;color:%s;"
                       % ("#3fb950" if ok else "#f5b53d"))
    v.addWidget(head)
    fmt = "GeoPackage" if rep.get("fmt") == "gpkg" else "Shapefiles"
    line = QLabel("%d / %d layers valid · saved as %s%s"
                  % (rep.get("valid", 0), rep.get("verify_total", 0), fmt,
                     "  · .zip made" if rep.get("zip") else ""))
    line.setStyleSheet("color:#e8ecf1;font-size:12.5px;")  # dual-theme-ok: backup dialog paints #0b0e13 (_DLG_QSS)
    v.addWidget(line)
    p = QLabel(rep.get("path", ""))
    p.setObjectName("bkPreview")
    p.setWordWrap(True)
    v.addWidget(p)
    extras = []
    if rep.get("online"):
        extras.append("%d online basemap(s) kept as live link(s)." % len(rep["online"]))
    for w in rep.get("warnings", [])[:4]:
        extras.append("⚠ " + w)
    for nm, err in rep.get("failed", [])[:4]:
        extras.append("❌ %s — %s" % (nm, err))
    if extras:
        ex = QLabel("\n".join(extras))
        ex.setStyleSheet("color:#9aa4b2;font-size:11px;")  # dual-theme-ok: backup dialog paints #0b0e13 (_DLG_QSS)
        ex.setWordWrap(True)
        v.addWidget(ex)
    row = QHBoxLayout()
    row.addStretch(1)
    openb = QPushButton("📂  Open folder")
    openb.setObjectName("bkCta")
    openb.clicked.connect(lambda: _open_folder(rep.get("path", "")))
    done = QPushButton("Done")
    done.setObjectName("bkGhost")
    done.clicked.connect(dlg.accept)
    row.addWidget(openb)
    row.addWidget(done)
    v.addLayout(row)
    try:
        from .nexus_dock import chrome_dialog
        chrome_dialog(dlg)
    except Exception:
        _swallowed_note()
    dlg.show()
    dlg.raise_()


def open_backup_dialog(iface, project=None):
    """Entry point for the 💾 Backup button. Modern dialog: format choice, folder
    picker (remembers last), optional .zip, progress, result + Open folder."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                                     QPushButton, QRadioButton, QButtonGroup, QCheckBox,
                                     QLineEdit, QFileDialog, QProgressDialog, QFrame,
                                     QApplication)
    from qgis.core import QgsProject, QgsSettings
    proj = project or QgsProject.instance()
    if not proj.mapLayers():
        try:
            iface.messageBar().pushWarning("Backup Project", "No layers to back up.")
        except Exception:
            _swallowed_note()
        return
    dlg = QDialog(iface.mainWindow())
    dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
    dlg.setWindowTitle("Backup Project")
    dlg.setMinimumWidth(450)
    dlg.setStyleSheet(_DLG_QSS)
    root = QVBoxLayout(dlg)
    root.setContentsMargins(0, 0, 0, 0)
    root.setSpacing(0)

    head = QFrame()
    head.setObjectName("bkHead")
    hl = QHBoxLayout(head)
    hl.setContentsMargins(18, 15, 18, 14)
    hl.setSpacing(11)
    ic = QLabel("💾")
    ic.setObjectName("bkIcon")
    tcol = QVBoxLayout()
    tcol.setSpacing(1)
    tt = QLabel("Backup Project")
    tt.setObjectName("bkTitle")
    ts = QLabel("SELF-CONTAINED · OPENS ANYWHERE")
    ts.setObjectName("bkSub")
    tcol.addWidget(tt)
    tcol.addWidget(ts)
    hl.addWidget(ic)
    hl.addLayout(tcol)
    hl.addStretch(1)
    root.addWidget(head)

    body = QVBoxLayout()
    body.setContentsMargins(18, 14, 18, 10)
    body.setSpacing(11)
    body.addWidget(_cap("BACKUP FOLDER (AUTO-NAMED)"))
    prev = QLabel(backup_dir_name(proj))
    prev.setObjectName("bkPreview")
    prev.setWordWrap(True)
    body.addWidget(prev)

    body.addWidget(_cap("SAVE LAYERS AS"))
    rb_gpkg = QRadioButton("GeoPackage   ·  one file, lossless  (recommended)")
    rb_gpkg.setChecked(True)
    rb_shp = QRadioButton("Shapefiles   ·  a Shapefiles/ folder")
    grp = QButtonGroup(dlg)
    grp.addButton(rb_gpkg)
    grp.addButton(rb_shp)
    body.addWidget(rb_gpkg)
    body.addWidget(rb_shp)

    body.addWidget(_cap("SAVE INTO"))
    drow = QHBoxLayout()
    drow.setSpacing(8)
    last = (QgsSettings().value("VelocityFibre/backup_last_dir")
            or os.path.dirname(proj.fileName() or "") or os.path.expanduser("~"))
    dest = QLineEdit(last)
    dest.setObjectName("bkInp")
    browse = QPushButton("Browse…")
    browse.setObjectName("bkBrowse")

    def _browse():
        d = QFileDialog.getExistingDirectory(
            dlg, "Choose where to save the backup",
            dest.text() or os.path.expanduser("~"))
        if d:
            dest.setText(d)
    browse.clicked.connect(_browse)
    drow.addWidget(dest)
    drow.addWidget(browse)
    body.addLayout(drow)

    items = plan_layers(proj)
    nv = sum(1 for it in items if it["kind"] == "vector")
    nr = sum(1 for it in items if it["kind"] == "raster")
    no = sum(1 for it in items if it["kind"] == "online")
    summ = QLabel("%d layers  ·  %d data, %d raster, %d online basemap"
                  % (len(items), nv, nr, no))
    summ.setObjectName("bkSummary")
    body.addWidget(summ)
    zip_cb = QCheckBox("Also save a single .zip copy")
    body.addWidget(zip_cb)
    root.addLayout(body)

    foot = QFrame()
    foot.setObjectName("bkFoot")
    fr = QHBoxLayout(foot)
    fr.setContentsMargins(18, 12, 18, 14)
    fr.addStretch(1)
    cancel = QPushButton("Cancel")
    cancel.setObjectName("bkGhost")
    cancel.clicked.connect(dlg.reject)
    go = QPushButton("Create Backup")
    go.setObjectName("bkCta")
    fr.addWidget(cancel)
    fr.addWidget(go)
    root.addWidget(foot)

    def _run():
        dest_root = dest.text().strip()
        if not dest_root or not os.path.isdir(dest_root):
            try:
                iface.messageBar().pushWarning(
                    "Backup Project", "Pick a valid folder to save into.")
            except Exception:
                _swallowed_note()
            return
        QgsSettings().setValue("VelocityFibre/backup_last_dir", dest_root)
        fmt = "gpkg" if rb_gpkg.isChecked() else "shp"
        total = len(items) + 1
        prog = QProgressDialog("Starting backup…", None, 0, total, dlg)
        prog.setWindowTitle("Backing up…")
        prog.setWindowModality(Qt.WindowModality.WindowModal)
        prog.setMinimumDuration(0)
        prog.setAutoClose(False)
        prog.setValue(0)

        def _cb(done, tot, label):
            try:
                prog.setMaximum(tot + 1)
                prog.setValue(done)
                prog.setLabelText("Backing up — %s   (%d / %d)" % (label, done, tot))
                QApplication.processEvents()
            except Exception:
                _swallowed_note()
        try:
            rep = create_backup(proj, dest_root, fmt=fmt,
                                make_zip=zip_cb.isChecked(), progress_cb=_cb)
        except Exception as e:
            prog.close()
            try:
                iface.messageBar().pushWarning("Backup Project", "Backup failed: %s" % e)
            except Exception:
                _swallowed_note()
            return
        prog.setValue(prog.maximum())
        prog.close()
        dlg.accept()
        _show_result(iface.mainWindow(), iface, rep)
    go.clicked.connect(_run)
    try:
        from .nexus_dock import chrome_dialog
        chrome_dialog(dlg)
    except Exception:
        _swallowed_note()
    dlg.show()
    dlg.raise_()
    dlg.activateWindow()
