"""No-AI / any-laptop erven pipeline.

Footprints -> regularise -> ONT centroids -> erven, with NO GPU and NO AI model.
Pure-geometry + pretrained open building footprints (Overture = Google+Microsoft+OSM).

Pipeline (per research_ai_building_erven_automation_2026-06-02):
  1. Building footprints  : Overture Maps download for the AOI bbox (offline-capable,
     no GPU). Overture aggregates Google Open Buildings + Microsoft + OSM.
  2. Regularise           : buildingregulariser (orthogonal footprints, pure geometry).
  3. ONT centroids        : representative_point() per footprint (one ONT per dwelling).
  4. Enclosures           : momepy.enclosures() from the OSM road network + AOI bound.
  5. Erven                : momepy.enclosed_tessellation() (one parcel per building).
  6. Export               : buildings / ont_centroids / erven / roads as GeoJSON (EPSG:4326).

Usage:
    python no_ai_erven_pipeline.py [W S E N] [outdir]
    (defaults to the Humansdorp test bbox + ./no_ai_output)

Dependencies (all CPU, pip-installable): geopandas, shapely, momepy,
buildingregulariser, overturemaps, pyproj. No torch / no CUDA.
"""
import sys
import json
import urllib.request
import urllib.parse
from pathlib import Path

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

# Heavy deps live in the qgis-venv only — guarded so importing inside QGIS never fails.
try:
    import geopandas as gpd
    from shapely.geometry import box, LineString
    import momepy
    from buildingregulariser import regularize_geodataframe
    from overturemaps import core as overture_core
    _DEPS_ERR = None
except ImportError as _e:  # pragma: no cover - QGIS embedded Python
    _DEPS_ERR = _e

# Humansdorp AOI bbox (lon/lat): W, S, E, N
DEFAULT_BBOX = (24.73316, -34.030965, 24.758653, -34.005354)


def utm_epsg(lon, lat):
    """Pick the UTM EPSG for a lon/lat (projected metres for area + tessellation)."""
    zone = int((lon + 180) // 6) + 1
    return (32700 if lat < 0 else 32600) + zone


def fetch_overture_buildings(W, S, E, N, out_path=None):
    """Download Overture building footprints for the bbox (no GPU, no AI).

    Uses the overturemaps Python API (reads cloud GeoParquet directly). bbox order
    is (xmin, ymin, xmax, ymax) = (W, S, E, N) in lon/lat.
    """
    gdf = overture_core.geodataframe("building", bbox=(W, S, E, N))
    if gdf.crs is None:                          # Overture geometries are WGS84
        gdf = gdf.set_crs(4326, allow_override=True)
    if out_path:
        try:
            gdf.to_file(out_path, driver="GeoJSON")
        except Exception:
            _swallowed_note()
    return gdf


def fetch_osm_roads(W, S, E, N):
    """Fetch OSM road lines for the bbox via Overpass (for enclosure barriers)."""
    q = (f"[out:json][timeout:90];way['highway']({S},{W},{N},{E});out geom;")
    data = urllib.parse.urlencode({"data": q}).encode()
    req = urllib.request.Request("https://overpass-api.de/api/interpreter",
                                 data=data, headers={"User-Agent": "veloplan-noai/1.0"})
    with urllib.request.urlopen(req, timeout=120) as r:
        osm = json.loads(r.read().decode())
    lines = []
    for el in osm.get("elements", []):
        if el.get("type") == "way" and "geometry" in el:
            coords = [(p["lon"], p["lat"]) for p in el["geometry"]]
            if len(coords) >= 2:
                lines.append(LineString(coords))
    return gpd.GeoDataFrame(geometry=lines, crs=4326)


def run(bbox, outdir):
    W, S, E, N = bbox
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    epsg = utm_epsg((W + E) / 2, (S + N) / 2)
    print(f"AOI {bbox}  ->  projected EPSG:{epsg}")

    aoi = gpd.GeoDataFrame(geometry=[box(W, S, E, N)], crs=4326).to_crs(epsg)

    # 1. footprints (Overture)
    print("[1/5] downloading Overture building footprints ...")
    bld = fetch_overture_buildings(W, S, E, N, str(out / "_overture_raw.geojson")).to_crs(epsg)
    bld = bld[bld.geometry.notna() & ~bld.geometry.is_empty]
    bld = gpd.clip(bld, aoi)[["geometry"]].reset_index(drop=True)
    print(f"      footprints: {len(bld)}")
    if len(bld) == 0:
        sys.exit("ERROR: No building footprints found in AOI — check bbox or Overture connectivity.")

    # 2. regularise (pure geometry)
    print("[2/5] regularising footprints (buildingregulariser) ...")
    try:
        reg = regularize_geodataframe(bld)
    except Exception as e:                       # never block the pipeline on cleanup
        print(f"      regularise skipped ({e}); using raw footprints")
        reg = bld
    reg = reg[reg.geometry.notna() & ~reg.geometry.is_empty].reset_index(drop=True)
    reg.to_crs(4326).to_file(out / "buildings.geojson", driver="GeoJSON")

    # 3. ONT centroids — one per dwelling
    print("[3/5] placing ONT centroids ...")
    ont = reg.copy()
    ont["geometry"] = reg.geometry.representative_point()
    ont.to_crs(4326).to_file(out / "ont_centroids.geojson", driver="GeoJSON")
    print(f"      ONT centroids: {len(ont)}")

    # 4. roads -> enclosures
    print("[4/5] fetching roads + building enclosures ...")
    roads = fetch_osm_roads(W, S, E, N).to_crs(epsg)
    roads = gpd.clip(roads, aoi)
    roads.to_crs(4326).to_file(out / "roads.geojson", driver="GeoJSON")
    enc = momepy.enclosures(primary_barriers=roads, limit=aoi.geometry)
    print(f"      enclosures (road-bounded blocks): {len(enc)}")

    # 5. erven — one parcel per building inside each enclosure
    print("[5/5] generating erven (enclosed_tessellation) ...")
    tess = momepy.enclosed_tessellation(reg.geometry, enc.geometry)
    if not isinstance(tess, gpd.GeoDataFrame):
        tess = gpd.GeoDataFrame(geometry=tess, crs=epsg)
    tess = tess.set_crs(epsg, allow_override=True)
    tess.to_crs(4326).to_file(out / "erven.geojson", driver="GeoJSON")
    print(f"      erven: {len(tess)}")

    print(f"\nDONE (no AI, no GPU). Outputs in {out.resolve()}:")
    for f in ("buildings.geojson", "ont_centroids.geojson", "roads.geojson", "erven.geojson"):
        print(f"  - {f}")


if __name__ == "__main__":
    args = sys.argv[1:]
    if len(args) >= 4:
        bbox = tuple(float(x) for x in args[:4])
        outdir = args[4] if len(args) >= 5 else "no_ai_output"
    else:
        bbox = DEFAULT_BBOX
        outdir = args[0] if args else "no_ai_output"
    run(bbox, outdir)
