import sys
import io

# -----------------------------------------------------------------------
# Fix 1: sys.stderr / sys.stdout guard
# QGIS sets sys.stderr (and sometimes sys.stdout) to None during plugin
# load.  numpy/scipy call sys.stderr.write() on import, causing:
#   AttributeError: 'NoneType' object has no attribute 'write'
# -----------------------------------------------------------------------
if sys.stderr is None:
    sys.stderr = io.StringIO()
if sys.stdout is None:
    sys.stdout = io.StringIO()

# -----------------------------------------------------------------------
# Fix 2: NumPy version conflict guard
#
# Problem: user AppData (or a venv) may contain numpy 2.x which appears
# BEFORE QGIS's bundled numpy 1.x in sys.path.  scipy and other QGIS
# C-extensions compiled against 1.x will then raise:
#   ImportError: A module compiled using NumPy 1.x cannot run in NumPy 2.x
#
# Strategy:
#   a) If numpy is NOT yet imported, move QGIS's site-packages ahead of
#      user/venv site-packages so QGIS's numpy 1.x is loaded first.
#   b) If numpy IS already imported at 2.x, log a clear warning with the
#      fix command so the user knows what to do.
# -----------------------------------------------------------------------

def _reorder_path_for_qgis_numpy():
    """Promote QGIS Python312 site-packages above user/venv paths."""
    import re
    qgis_re = re.compile(r'QGIS.*Python312.*site-packages', re.IGNORECASE)
    user_re  = re.compile(r'AppData|\.venv', re.IGNORECASE)

    qgis_paths = [p for p in sys.path if qgis_re.search(p)]
    if not qgis_paths:
        return  # can't identify QGIS packages — leave path alone

    # Find the first user/venv entry
    first_user_idx = next(
        (i for i, p in enumerate(sys.path) if user_re.search(p)), None
    )
    if first_user_idx is None:
        return  # no user paths to worry about

    # Move QGIS paths to just before the first user/venv entry
    for p in qgis_paths:
        sys.path.remove(p)
    for i, p in enumerate(qgis_paths):
        sys.path.insert(first_user_idx + i, p)


def _warn_numpy_conflict(numpy_version: str):
    """Log a QGIS message bar warning with the fix command."""
    msg = (
        f"FTTHPlanTool: numpy {numpy_version} detected (numpy 2.x). "
        "QGIS extensions require numpy 1.x. "
        "Fix: open OSGeo4W Shell and run:\n"
        "    pip uninstall numpy -y\n"
        "then restart QGIS."
    )
    try:
        from qgis.core import QgsMessageLog, Qgis
        QgsMessageLog.logMessage(msg, "FTTHPlanTool", Qgis.MessageLevel.Warning)
    except Exception:
        pass  # QGIS not yet available — silently ignore


if 'numpy' not in sys.modules:
    # numpy not loaded yet — reorder path so QGIS's 1.x wins
    _reorder_path_for_qgis_numpy()
else:
    # numpy already loaded — check for 2.x conflict
    import numpy as _np
    _major = int(_np.__version__.split('.')[0])
    if _major >= 2:
        _warn_numpy_conflict(_np.__version__)


def classFactory(iface):
    """Load FTTHPlanTool class from file ftth_plan_tool.

    Args:
        iface: A QGIS interface instance.
    """
    from .ftth_plan_tool import FTTHPlanTool
    return FTTHPlanTool(iface)
