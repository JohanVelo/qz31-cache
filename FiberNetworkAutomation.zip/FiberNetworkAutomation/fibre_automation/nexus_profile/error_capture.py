"""error_capture — auto-report plugin errors to the Team Monitor so teammates
never have to file a ticket when something breaks.

Installs three chained hooks and routes anything whose traceback involves THIS
plugin into the existing backend `errors` table (via manager.report_error, which
already attaches breadcrumbs + project + version and rate-limits):
  1. sys.excepthook         — unhandled main-thread exceptions
  2. threading.excepthook   — unhandled QgsTask / worker-thread exceptions
  3. QgsMessageLog (Critical) — catch-all for tracebacks QGIS logs itself

Guardrails (research-backed, 2026):
  * Only OUR errors are sent — a traceback must mention the plugin package, so we
    don't slurp other plugins' or unrelated QGIS errors (privacy + noise).
  * Per-fingerprint dedup (same error within 5 min is dropped) on top of the
    backend's own 60 s rate-limit, so a crash-loop can't spam the table.
  * PII scrub (file paths + emails) happens in telemetry.record_error before the
    insert — POPIA-aware.
  * Every hook is CHAINED (we call the previous hook), so QGIS's own error dialog
    still appears and other plugins' hooks still run. Restored cleanly on unload.
"""
import sys
import threading
import time

_PKG_MARKERS = ("FiberNetworkAutomation", "fibre_automation", "VelocityFibre")

_state = {
    "installed": False,
    "prev_excepthook": None,
    "prev_threading": None,
    "log_connected": False,
    "mgr": None,
    "seen": {},          # fingerprint -> last_report_ts
}


def _relevant(tb_text):
    return any(m in (tb_text or "") for m in _PKG_MARKERS)


def _fingerprint(exc_type_name, tb_text):
    import hashlib
    import re
    parts = [exc_type_name or "?"]
    for fn in re.findall(r"line \d+, in (\w+)", tb_text or "")[-3:]:
        parts.append(fn)
    return hashlib.sha1("|".join(parts).encode()).hexdigest()[:16]


def _dedup_ok(fp):
    now = time.time()
    if now - _state["seen"].get(fp, 0) < 300:     # same error within 5 min
        return False
    _state["seen"][fp] = now
    if len(_state["seen"]) > 200:                 # keep the dict bounded
        _state["seen"].clear()
    return True


def _report(where, exc):
    mgr = _state["mgr"]
    if mgr is None or exc is None:
        return
    try:
        import traceback
        tb_text = "".join(traceback.format_exception(
            type(exc), exc, getattr(exc, "__traceback__", None)))
        if not _relevant(tb_text):
            return                                # not ours — ignore
        if not _dedup_ok(_fingerprint(type(exc).__name__, tb_text)):
            return
        mgr.report_error(where, exc)              # -> telemetry.record_error -> errors table
    except Exception:
        pass


def _excepthook(exc_type, exc_value, tb):
    try:
        ev = exc_value
        if ev is not None and getattr(ev, "__traceback__", None) is None and tb is not None:
            try:
                ev = ev.with_traceback(tb)
            except Exception:
                pass
        _report("unhandled", ev)
    finally:
        prev = _state["prev_excepthook"]
        if prev is not None:
            try:
                prev(exc_type, exc_value, tb)
            except Exception:
                pass


def _threading_hook(args):
    try:
        ev = getattr(args, "exc_value", None)
        tb = getattr(args, "exc_traceback", None)
        if ev is not None and getattr(ev, "__traceback__", None) is None and tb is not None:
            try:
                ev = ev.with_traceback(tb)
            except Exception:
                pass
        thread = getattr(args, "thread", None)
        _report(f"worker:{getattr(thread, 'name', '?')}", ev)
    finally:
        prev = _state["prev_threading"]
        if prev is not None:
            try:
                prev(args)
            except Exception:
                pass


def _on_log(message, tag, level):
    try:
        from qgis.core import Qgis
        if level != Qgis.MessageLevel.Critical:   # only hard errors, not warnings/info
            return
        if not _relevant(message):
            return
        if not _dedup_ok(_fingerprint("QgisLog", message)):
            return
        mgr = _state["mgr"]
        if mgr is not None:
            mgr.report_error(f"qgislog:{tag}", Exception(str(message)[:600]))
    except Exception:
        pass


def install(manager):
    """Idempotent. manager must expose report_error(where, exc)."""
    if _state["installed"] or manager is None:
        return
    _state["mgr"] = manager
    try:
        _state["prev_excepthook"] = sys.excepthook
        sys.excepthook = _excepthook
    except Exception:
        pass
    try:
        _state["prev_threading"] = threading.excepthook      # Py 3.8+
        threading.excepthook = _threading_hook
    except Exception:
        pass
    try:
        from qgis.core import QgsApplication
        QgsApplication.messageLog().messageReceived.connect(_on_log)
        _state["log_connected"] = True
    except Exception:
        pass
    _state["installed"] = True
    print("[FiberNet] auto error-capture installed ✓")


def uninstall():
    if not _state["installed"]:
        return
    try:
        if _state["prev_excepthook"] is not None:
            sys.excepthook = _state["prev_excepthook"]
    except Exception:
        pass
    try:
        if _state["prev_threading"] is not None:
            threading.excepthook = _state["prev_threading"]
    except Exception:
        pass
    try:
        if _state["log_connected"]:
            from qgis.core import QgsApplication
            QgsApplication.messageLog().messageReceived.disconnect(_on_log)
    except Exception:
        pass
    _state.update({"installed": False, "prev_excepthook": None,
                   "prev_threading": None, "log_connected": False, "mgr": None})
