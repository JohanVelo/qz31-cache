# FTTH Planning Department Workflow

## Purpose
Align all departments on what happens at each planning stage from High-Level Design (HLD) through As-Built handover.

## Scope
This operational workflow is for cross-department alignment and governance. It is not tied to any specific software tool.

## Departments Involved
- Planning
- GIS and Design
- Finance and Commercial
- Wayleave and Permitting
- Build and OSP Construction
- QA and Commissioning
- Operations and NOC

---

## Stage 0: Intake and Project Setup
**Objective:** Confirm project mandate, planning boundary, assumptions, and standards.

**Inputs:**
- Business case and rollout target
- Service area boundary
- Demand forecast and premise list
- Existing network records

**Outputs:**
- Approved design basis
- Shared assumptions register
- Project coding and naming standard

**Department Context:**
- Planning: sets engineering assumptions and design envelope.
- Finance: confirms budget ceiling and cost model.
- GIS: validates base data quality and CRS consistency.
- Wayleave: flags legal and access constraints early.

**Gate G0:** Design basis approved. Baseline datasets accepted.

---

## Stage 1: HLD (High-Level Design)
**Objective:** Define macro architecture, capacity strategy, and rollout concept.

**Inputs:**
- Approved design basis
- Demand clusters and growth assumptions
- Existing feeder/backbone context

**Outputs:**
- HLD map pack
- Preliminary BoQ and cost range
- HLD risks and dependency list

**Department Context:**
- Planning: defines PON architecture and service areas.
- Finance: validates cost envelope against business case.
- Wayleave: confirms high-level corridor feasibility.
- Program management: confirms phase priorities.

**Gate G1:** HLD approved and frozen. Cost envelope accepted.

---

## Stage 2: LLD (Low-Level Design)
**Objective:** Convert HLD intent into buildable network detail.

**Inputs:**
- Approved HLD baseline
- Field survey and occupancy information
- Permit and municipal constraints

**Outputs:**
- Detailed route and node design
- Construction-grade BoQ
- Engineering rule compliance log

**Department Context:**
- GIS/Design: creates detailed topology and asset structure.
- Planning: verifies splitter load, hierarchy, and distance rules.
- Build: reviews constructibility and practical access.
- Wayleave: confirms route-level permitting readiness.

**Gate G2:** Constructibility accepted. Rule checks pass or approved waivers documented.

---

## Stage 3: Splice Plan and Fiber Allocation
**Objective:** Define full fiber continuity and splice instructions.

**Inputs:**
- Approved LLD
- Fiber reserve policy
- Labeling and documentation standards

**Outputs:**
- Splice schedules and closure plans
- End-to-end continuity table
- Port and tray assignment sheets

**Department Context:**
- Fiber Design: assigns feeder, distribution, and drop continuity.
- QA: validates no over-subscription or ambiguous assignments.
- Build: confirms installation sequence is practical.

**Gate G3:** Continuity validation complete. Construction splice pack approved.

---

## Stage 4: Build Support and Redline Management
**Objective:** Control design changes during construction.

**Inputs:**
- Approved construction issue pack
- Daily/weekly field feedback and redlines

**Outputs:**
- Controlled revision updates
- Redline register with closure status
- Reissued affected documents

**Department Context:**
- Build: reports blocked routes, conflicts, and deviations.
- Planning/Design: assesses impact on capacity and continuity.
- PMO: controls revision communication and distribution.

**Gate G4:** Open redlines resolved or formally deferred. Latest revision acknowledged by all execution teams.

---

## Stage 5: As-Built and Handover
**Objective:** Deliver final installed network record and operations handover.

**Inputs:**
- Final redlines
- Completion evidence and test records

**Outputs:**
- As-Built maps and asset register
- Final splice continuity package
- Planned vs As-Built variance report
- Operations handover pack

**Department Context:**
- GIS As-Built: updates authoritative final records.
- QA/Commissioning: validates acceptance criteria and test compliance.
- Operations/NOC: accepts handover for support lifecycle.

**Gate G5:** As-Built QA passed. Operations handover signed. Project formally closed.

---

## Stage Gates Summary

| Gate | Transition | Sign-off Criteria |
|---|---|---|
| G0 | Intake → HLD | Design basis approved; baseline datasets accepted |
| G1 | HLD → LLD | HLD frozen; cost envelope accepted |
| G2 | LLD → Splice | Constructibility accepted; engineering checks passed/waived |
| G3 | Splice → Build | Continuity validated; splice pack approved |
| G4 | Build → As-Built | Redlines resolved/deferred; revision acknowledged |
| G5 | As-Built → Closeout | QA passed; handover signed; project closed |

**No stage is allowed to start without previous gate sign-off.**

---

## Governance and Controls
- Single source of truth for drawings, GIS, and schedules
- Mandatory revision IDs and change reasons on every update
- Formal approver name recorded per gate
- Versioning: major revision for topology change, minor for documentation correction

## Minimum QA Checks by Stage
- **HLD:** Coverage completeness, macro capacity feasibility, corridor feasibility
- **LLD:** Topology connectivity, distance limits, capacity compliance
- **Splice:** End-to-end continuity, conflict-free allocations
- **As-Built:** Installed reconciliation, final labeling consistency

## RACI (Lean)
- **Accountable:** Planning Lead (design integrity)
- **Responsible:** GIS/Design and Fiber Engineering (technical outputs)
- **Consulted:** Build, Wayleave, Finance, PMO
- **Informed:** Operations/NOC and leadership stakeholders

## KPI Set
- HLD approval cycle time
- LLD right-first-time percentage
- Splice issue rate detected during build
- Redline closure turnaround time
- Planned vs As-Built variance percentage
- Time to final handover acceptance

## 30-Day Rollout Plan
- **Week 1:** Confirm standards, naming conventions, and gate approvers
- **Week 2:** Pilot one area through HLD and LLD gate reviews
- **Week 3:** Implement splice QA and redline control rhythm
- **Week 4:** Run pilot to As-Built closeout and publish lessons learned

---
*Document Owner: Planning Department | Review Cadence: Monthly or per major milestone | Status: Active*
