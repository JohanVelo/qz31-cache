# Clean Buildings Algorithm

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterVectorLayer,
    QgsProcessing,
    QgsProcessingException,
    QgsSpatialIndex,
    QgsWkbTypes
)


class CleanBuildingsAlgorithm(QgsProcessingAlgorithm):
    """Algorithm to clean building polygons by keeping only the largest per erven"""

    BUILDINGS = 'BUILDINGS'
    ERVENS = 'ERVENS'

    def name(self):
        return 'cleanbuildings'

    def displayName(self):
        return '9. Clean Buildings'

    def group(self):
        return 'Fiber Network Utilities'

    def groupId(self):
        return 'fibernetworkutilities'

    def shortHelpString(self):
        return """
        Clean building polygons by keeping only one building per erven (parcel).

        Smart cleaning algorithm that:
        1. Sorts all buildings by size (largest first)
        2. For buildings fully inside an erven:
           - Keep if erven is empty
           - Delete if erven already has a building
        3. For buildings on erven boundaries:
           - Keep and assign to an empty erven if available
           - Delete if all touching ervens already have buildings
        4. Delete buildings outside all ervens

        Can be run multiple times until all buildings are properly assigned.

        Result: Each erven will have at most ONE building (the largest that fits).

        Inputs:
        - Buildings Layer: Polygon layer containing buildings to clean
        - Erven/Parcel Layer: Polygon layer defining property boundaries

        Note: This is a destructive operation. Make sure to backup your data first.
        """

    def createInstance(self):
        return CleanBuildingsAlgorithm()

    def initAlgorithm(self, config=None):
        # Buildings layer input
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.BUILDINGS,
                'Buildings Layer',
                [QgsProcessing.SourceType.TypeVectorPolygon]
            )
        )

        # Ervens/Parcels layer input
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.ERVENS,
                'Erven/Parcel Layer',
                [QgsProcessing.SourceType.TypeVectorPolygon]
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        # STEP 1: Get and validate layers
        feedback.setProgress(0)
        feedback.pushInfo("Initializing...")

        buildings_layer = self.parameterAsVectorLayer(parameters, self.BUILDINGS, context)
        ervens_layer = self.parameterAsVectorLayer(parameters, self.ERVENS, context)

        # Validate layers exist
        if not buildings_layer or not ervens_layer:
            raise QgsProcessingException("Invalid input layers")

        # Validate geometry types
        if buildings_layer.geometryType() != QgsWkbTypes.GeometryType.PolygonGeometry:
            raise QgsProcessingException("Buildings layer must be polygon type")

        if ervens_layer.geometryType() != QgsWkbTypes.GeometryType.PolygonGeometry:
            raise QgsProcessingException("Ervens layer must be polygon type")

        # Check CRS match - a mismatch makes the spatial predicates below
        # (intersects/within/intersection) compare raw coordinates in
        # different reference systems, so EVERY building falls into
        # "outside all ervens" and gets mass-deleted. Refuse rather than wipe.
        if buildings_layer.crs() != ervens_layer.crs():
            raise QgsProcessingException(
                f"CRS mismatch: Buildings ({buildings_layer.crs().authid()}) "
                f"vs Ervens ({ervens_layer.crs().authid()}). "
                f"Reproject both layers to the same CRS before running this algorithm."
            )

        # Handle empty layers
        if buildings_layer.featureCount() == 0:
            feedback.pushInfo("Buildings layer is empty, nothing to clean")
            return {self.BUILDINGS: buildings_layer.id()}

        if ervens_layer.featureCount() == 0:
            feedback.pushInfo("Ervens layer is empty, no buildings will be deleted")
            return {self.BUILDINGS: buildings_layer.id()}

        # STEP 2: Build erven spatial index and store erven geometries
        feedback.setProgress(5)
        feedback.pushInfo("Building erven spatial index...")

        erven_spatial_index = QgsSpatialIndex(ervens_layer.getFeatures())
        erven_geometries = {}  # erven_id -> geometry

        for erven_feature in ervens_layer.getFeatures():
            erven_geom = erven_feature.geometry()
            if erven_geom and erven_geom.isGeosValid():
                erven_geometries[erven_feature.id()] = erven_geom

        feedback.pushInfo(f"Found {len(erven_geometries)} valid ervens")

        # STEP 3: Collect ALL buildings with their areas
        feedback.setProgress(10)
        feedback.pushInfo("Collecting and sorting all buildings by size...")

        all_buildings = []  # List of (building_id, area, geometry)

        for building_feature in buildings_layer.getFeatures():
            building_geom = building_feature.geometry()

            # Validate building geometry
            if not building_geom or not building_geom.isGeosValid():
                feedback.pushWarning(f"Invalid geometry in building feature {building_feature.id()}, skipping")
                continue

            area = building_geom.area()
            all_buildings.append((building_feature.id(), area, building_geom))

        # Sort buildings by area (LARGEST FIRST)
        all_buildings.sort(key=lambda x: x[1], reverse=True)
        feedback.pushInfo(f"Processing {len(all_buildings)} buildings from largest to smallest...")

        # STEP 4: Process buildings from largest to smallest
        feedback.setProgress(20)

        erven_assigned = {}  # erven_id -> building_id (track which building is assigned to each erven)
        buildings_to_delete = set()

        stats = {
            'total_buildings': len(all_buildings),
            'buildings_retained': 0,
            'buildings_deleted': 0,
            'duplicate_in_erven': 0,
            'boundary_saved': 0,
            'boundary_deleted': 0,
            'outside_all_ervens': 0
        }

        for idx, (building_id, area, building_geom) in enumerate(all_buildings):
            # Check for user cancellation
            if feedback.isCanceled():
                feedback.pushInfo("Operation cancelled by user")
                return {}

            # Update progress (20% to 80%)
            progress = 20 + int((idx / len(all_buildings)) * 60)
            feedback.setProgress(progress)

            if idx % 50 == 0 and idx > 0:
                feedback.pushInfo(f"Processed {idx}/{len(all_buildings)} buildings...")

            # Find which ervens this building intersects
            candidate_erven_ids = erven_spatial_index.intersects(building_geom.boundingBox())

            intersecting_ervens = []  # ervens that this building intersects
            fully_within_ervens = []  # ervens that fully contain this building
            erven_overlaps = {}  # erven_id -> overlap area

            for erven_id in candidate_erven_ids:
                if erven_id not in erven_geometries:
                    continue

                erven_geom = erven_geometries[erven_id]

                # Check relationship with erven
                if building_geom.intersects(erven_geom):
                    intersecting_ervens.append(erven_id)

                    # Calculate overlap area
                    intersection = building_geom.intersection(erven_geom)
                    overlap_area = intersection.area() if intersection else 0
                    erven_overlaps[erven_id] = overlap_area

                    # Check if fully within
                    if building_geom.within(erven_geom):
                        fully_within_ervens.append(erven_id)

            # DECISION LOGIC: Determine fate of this building

            if len(fully_within_ervens) == 1:
                # Building is fully within exactly ONE erven
                erven_id = fully_within_ervens[0]

                if erven_id not in erven_assigned:
                    erven_assigned[erven_id] = building_id
                    stats['buildings_retained'] += 1
                else:
                    buildings_to_delete.add(building_id)
                    stats['buildings_deleted'] += 1
                    stats['duplicate_in_erven'] += 1

            elif len(fully_within_ervens) > 1:
                # Building is fully within MULTIPLE ervens (overlapping ervens)
                assigned = False
                for erven_id in fully_within_ervens:
                    if erven_id not in erven_assigned:
                        erven_assigned[erven_id] = building_id
                        stats['buildings_retained'] += 1
                        assigned = True
                        break

                if not assigned:
                    buildings_to_delete.add(building_id)
                    stats['buildings_deleted'] += 1
                    stats['duplicate_in_erven'] += 1

            elif len(fully_within_ervens) == 0 and len(intersecting_ervens) > 0:
                # Building is ON BOUNDARY (intersects but not fully within any erven)
                empty_ervens = [eid for eid in intersecting_ervens if eid not in erven_assigned]

                if empty_ervens:
                    best_erven = max(empty_ervens, key=lambda eid: erven_overlaps.get(eid, 0))
                    erven_assigned[best_erven] = building_id
                    stats['buildings_retained'] += 1
                    stats['boundary_saved'] += 1
                else:
                    buildings_to_delete.add(building_id)
                    stats['buildings_deleted'] += 1
                    stats['boundary_deleted'] += 1

            else:
                # Building doesn't intersect any erven - outside all ervens
                buildings_to_delete.add(building_id)
                stats['buildings_deleted'] += 1
                stats['outside_all_ervens'] += 1

        # STEP 5: Perform deletion
        feedback.setProgress(80)

        if buildings_to_delete:
            feedback.pushInfo(f"\nDeleting {len(buildings_to_delete)} buildings...")

            # Don't hijack an existing edit session: if the user already has
            # unsaved edits, opening edit mode is a no-op and our commitChanges()
            # below would silently save THEIR pending edits too (and a failure
            # would roll back their whole history). Refuse instead.
            if buildings_layer.isEditable():
                raise QgsProcessingException(
                    "Buildings layer is already in edit mode with unsaved changes. "
                    "Commit or roll back your edits before running this algorithm."
                )

            buildings_layer.startEditing()  # claude:approved-destructive

            try:
                success = buildings_layer.deleteFeatures(list(buildings_to_delete))

                if not success:
                    raise QgsProcessingException("Failed to delete features")

                feedback.setProgress(95)
                feedback.pushInfo("Committing changes...")

                if not buildings_layer.commitChanges():
                    errors = buildings_layer.commitErrors()
                    error_msg = "\n".join(errors)
                    raise QgsProcessingException(f"Commit failed: {error_msg}")

                feedback.pushInfo("✓ Changes committed successfully")

            except Exception as e:
                buildings_layer.rollBack()
                feedback.reportError(f"Operation rolled back: {e!s}")
                raise

        else:
            feedback.pushInfo("\n✓ No buildings to delete - layer is already clean!")

        # STEP 6: Report summary
        feedback.setProgress(100)
        buildings_layer.triggerRepaint()

        feedback.pushInfo("\n" + "=" * 60)
        feedback.pushInfo("CLEANING SUMMARY:")
        feedback.pushInfo(f"  Total buildings processed: {stats['total_buildings']}")
        feedback.pushInfo(f"  Buildings retained: {stats['buildings_retained']}")
        feedback.pushInfo(f"    - Fully inside ervens: {stats['buildings_retained'] - stats['boundary_saved']}")
        feedback.pushInfo(f"    - On boundaries (saved): {stats['boundary_saved']}")
        feedback.pushInfo(f"  Buildings deleted: {stats['buildings_deleted']}")
        feedback.pushInfo(f"    - Duplicates in same erven: {stats['duplicate_in_erven']}")
        feedback.pushInfo(f"    - On boundaries (all ervens full): {stats['boundary_deleted']}")
        feedback.pushInfo(f"    - Outside all ervens: {stats['outside_all_ervens']}")
        feedback.pushInfo(f"  Ervens with buildings assigned: {len(erven_assigned)} / {len(erven_geometries)}")

        remaining = stats['total_buildings'] - stats['buildings_deleted']
        if remaining == len(erven_assigned):
            feedback.pushInfo("\n✓ LAYER IS CLEAN! Each erven has exactly one building.")
        else:
            feedback.pushInfo("\n⚠ You can run this algorithm again to continue cleaning.")

        feedback.pushInfo("=" * 60)

        return {self.BUILDINGS: buildings_layer.id()}
