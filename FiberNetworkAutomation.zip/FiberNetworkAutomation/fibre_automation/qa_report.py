"""qa_report — render Topology & Integrity QA results into a shareable HTML report.

A document to email the team / attach to HLD sign-off (the in-canvas "QA Issues" layer is for
fixing; this is for handing over). Pure stdlib string building — zero deps. Mission-Control look
to match the plugin.

API:  render_html(issues, project_name, when) -> str
"""
import html
from collections import Counter

_CHECK_LABEL = {
    "null_geometry": "Null / empty geometry",
    "duplicate_dr": "Duplicate DR number",
    "duplicate_pon": "Duplicate PON number",
    "pon_range": "PON number out of range",
    "zone_math": "Zone-number mismatch",
    "orphan_pon_ref": "ONT/drop references a missing PON",
    "cable_dangle": "Cable endpoint not snapped",
    "span_over_limit": "Span over length limit",
    "ont_outside_aoi": "ONT outside the AOI",
}


def render_html(issues, project_name="project", when=""):
    errs = [i for i in issues if i["severity"] == "ERROR"]
    warns = [i for i in issues if i["severity"] == "WARN"]
    verdict = ("PASS" if not errs and not warns else
               "REVIEW" if not errs else "FAIL")
    vcolour = {"PASS": "#3DFF9A", "REVIEW": "#F59E0B", "FAIL": "#FF4D6D"}[verdict]

    by_check = Counter((i["severity"], i["check"]) for i in issues)
    rows = []
    for (sev, chk), n in sorted(by_check.items(), key=lambda x: (-x[1])):
        col = "#FF4D6D" if sev == "ERROR" else "#F59E0B"
        rows.append(
            f"<tr><td><span style='color:{col};font-weight:700'>{sev}</span></td>"
            f"<td>{html.escape(_CHECK_LABEL.get(chk, chk))}</td>"
            f"<td style='text-align:right;font-weight:700'>{n}</td></tr>")
    summary = "".join(rows) or "<tr><td colspan='3'>No issues found.</td></tr>"

    # up to 200 detail lines so the report stays openable
    det = []
    for i in (errs + warns)[:200]:
        col = "#FF4D6D" if i["severity"] == "ERROR" else "#F59E0B"
        det.append(
            f"<tr><td style='color:{col};font-weight:700'>{i['severity']}</td>"
            f"<td>{html.escape(str(i['layer']))}</td>"
            f"<td>{html.escape(str(i['fid']))}</td>"
            f"<td>{html.escape(str(i['desc']))}</td></tr>")
    more = "" if len(issues) <= 200 else f"<p class='muted'>… and {len(issues)-200} more (see the QA Issues layer in QGIS).</p>"

    return f"""<!doctype html><html><head><meta charset="utf-8">
<title>QA Report — {html.escape(project_name)}</title>
<style>
 body{{background:#0A1322;color:#EAF1FF;font-family:'Segoe UI',system-ui,sans-serif;margin:0;padding:28px}}
 h1{{font-size:20px;margin:0 0 2px}} .muted{{color:#7e93b0;font-size:12px}}
 .verdict{{display:inline-block;margin:14px 0;padding:8px 18px;border-radius:10px;
   font-weight:800;font-size:18px;color:#06121f;background:{vcolour}}}
 .grid{{display:flex;gap:14px;margin:8px 0 18px;flex-wrap:wrap}}
 .kpi{{background:rgba(255,255,255,.04);border:1px solid #1c3344;border-radius:12px;padding:12px 18px}}
 .kpi b{{font-size:24px;display:block}} .kpi span{{color:#9DB2C8;font-size:11px;letter-spacing:1px}}
 table{{border-collapse:collapse;width:100%;margin:6px 0 22px;font-size:13px}}
 th,td{{text-align:left;padding:7px 10px;border-bottom:1px solid #16283a}}
 th{{color:#6f86a0;font-size:11px;letter-spacing:1px;text-transform:uppercase}}
 h2{{font-size:13px;color:#2DD4BF;letter-spacing:1px;margin:18px 0 6px}}
</style></head><body>
 <h1>Topology &amp; Integrity QA</h1>
 <div class="muted">{html.escape(project_name)} · {html.escape(when)}</div>
 <div class="verdict">{verdict}</div>
 <div class="grid">
   <div class="kpi"><b style="color:#FF4D6D">{len(errs)}</b><span>ERRORS</span></div>
   <div class="kpi"><b style="color:#F59E0B">{len(warns)}</b><span>WARNINGS</span></div>
   <div class="kpi"><b>{len(issues)}</b><span>TOTAL</span></div>
 </div>
 <h2>// SUMMARY BY CHECK</h2>
 <table><tr><th>Severity</th><th>Check</th><th style="text-align:right">Count</th></tr>{summary}</table>
 <h2>// DETAIL</h2>
 <table><tr><th>Severity</th><th>Layer</th><th>FID</th><th>Description</th></tr>{"".join(det)}</table>
 {more}
</body></html>"""
