<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="4.2.0" styleCategories="Symbology|Labeling" labelsEnabled="1">
  <renderer-v2 referencescale="-1" forceraster="0" enableorderby="0" type="singleSymbol" symbollevels="0">
        <symbols>
          <symbol frame_rate="10" is_animated="0" force_rhr="0" type="marker" name="0" alpha="1" clip_to_extent="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </data_defined_properties>
            <layer locked="0" class="SimpleMarker" pass="0" id="{fd91a2a0-6b16-493b-ab11-72027ead050f}" enabled="1">
              <Option type="Map">
                <Option type="QString" value="0" name="angle" />
                <Option type="QString" value="square" name="cap_style" />
                <Option type="QString" value="0,0,0,255,hsv:0.13072222222222221,0,0,1" name="color" />
                <Option type="QString" value="1" name="horizontal_anchor_point" />
                <Option type="QString" value="bevel" name="joinstyle" />
                <Option type="QString" value="circle" name="name" />
                <Option type="QString" value="0,0" name="offset" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                <Option type="QString" value="MM" name="offset_unit" />
                <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                <Option type="QString" value="solid" name="outline_style" />
                <Option type="QString" value="0" name="outline_width" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" />
                <Option type="QString" value="MM" name="outline_width_unit" />
                <Option type="QString" value="diameter" name="scale_method" />
                <Option type="QString" value="1.8" name="size" />
                <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale" />
                <Option type="QString" value="MM" name="size_unit" />
                <Option type="QString" value="1" name="vertical_anchor_point" />
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name" />
                  <Option name="properties" />
                  <Option type="QString" value="collection" name="type" />
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </symbols>
        <rotation />
        <sizescale />
        <data-defined-properties>
          <Option type="Map">
            <Option type="QString" value="" name="name" />
            <Option name="properties" />
            <Option type="QString" value="collection" name="type" />
          </Option>
        </data-defined-properties>
      </renderer-v2>
  <labeling type="simple">
        <settings calloutType="simple">
          <text-style fontSizeUnit="RenderMetersInMapUnits" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWordSpacing="0" textColor="50,50,50,255,rgb:0.1960784,0.1960784,0.1960784,1" fontKerning="1" fontUnderline="0" useSubstitutions="0" multilineHeight="1" allowHtml="0" capitalization="0" blendMode="0" fieldName="&quot;Name&quot; || '\n' ||&#13;&#10;'Pole lengt: ' || &quot;Length&quot; || '\n' ||&#13;&#10;'Pole Size: ' || &quot;Size&quot;" multilineHeightUnit="Percentage" tabStopDistance="80" textOrientation="horizontal" fontSize="9" textOpacity="1" namedStyle="Bold" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" fontFamily="Open Sans" fontLetterSpacing="0" stretchFactor="100" fontWeight="75" legendString="Aa" forcedItalic="0" forcedBold="0" fontItalic="0" tabStopDistanceUnit="Point" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" isExpression="1" fontStrikeout="0">
            <families />
            <text-buffer bufferSize="1" bufferNoFill="1" bufferColor="250,250,250,255,rgb:0.9803922,0.9803922,0.9803922,1" bufferBlendMode="0" bufferDraw="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferOpacity="1" />
            <text-mask maskSize="1.5" maskedSymbolLayers="" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskJoinStyle="128" maskSize2="1.5" maskType="0" maskOpacity="1" maskEnabled="1" />
            <background shapeRadiiY="0" shapeRadiiUnit="Point" shapeBlendMode="0" shapeSizeType="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeRotationType="0" shapeSizeX="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeBorderWidth="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRotation="0" shapeOffsetX="0" shapeBorderWidthUnit="Point" shapeDraw="0" shapeOffsetUnit="Point" shapeSizeUnit="Point" shapeOpacity="1" shapeOffsetY="0" shapeSizeY="0" shapeSVGFile="" shapeType="0">
              <symbol frame_rate="10" is_animated="0" force_rhr="0" type="marker" name="markerSymbol" alpha="1" clip_to_extent="1">
                <data_defined_properties>
                  <Option type="Map">
                    <Option type="QString" value="" name="name" />
                    <Option name="properties" />
                    <Option type="QString" value="collection" name="type" />
                  </Option>
                </data_defined_properties>
                <layer locked="0" class="SimpleMarker" pass="0" id="" enabled="1">
                  <Option type="Map">
                    <Option type="QString" value="0" name="angle" />
                    <Option type="QString" value="square" name="cap_style" />
                    <Option type="QString" value="145,82,45,255,rgb:0.5686275,0.3215686,0.1764706,1" name="color" />
                    <Option type="QString" value="1" name="horizontal_anchor_point" />
                    <Option type="QString" value="bevel" name="joinstyle" />
                    <Option type="QString" value="circle" name="name" />
                    <Option type="QString" value="0,0" name="offset" />
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                    <Option type="QString" value="MM" name="offset_unit" />
                    <Option type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1" name="outline_color" />
                    <Option type="QString" value="solid" name="outline_style" />
                    <Option type="QString" value="0" name="outline_width" />
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" />
                    <Option type="QString" value="MM" name="outline_width_unit" />
                    <Option type="QString" value="diameter" name="scale_method" />
                    <Option type="QString" value="2" name="size" />
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale" />
                    <Option type="QString" value="MM" name="size_unit" />
                    <Option type="QString" value="1" name="vertical_anchor_point" />
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name" />
                      <Option name="properties" />
                      <Option type="QString" value="collection" name="type" />
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
              <symbol frame_rate="10" is_animated="0" force_rhr="0" type="fill" name="fillSymbol" alpha="1" clip_to_extent="1">
                <data_defined_properties>
                  <Option type="Map">
                    <Option type="QString" value="" name="name" />
                    <Option name="properties" />
                    <Option type="QString" value="collection" name="type" />
                  </Option>
                </data_defined_properties>
                <layer locked="0" class="SimpleFill" pass="0" id="" enabled="1">
                  <Option type="Map">
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" />
                    <Option type="QString" value="255,255,255,255,rgb:1,1,1,1" name="color" />
                    <Option type="QString" value="bevel" name="joinstyle" />
                    <Option type="QString" value="0,0" name="offset" />
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" />
                    <Option type="QString" value="MM" name="offset_unit" />
                    <Option type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" name="outline_color" />
                    <Option type="QString" value="no" name="outline_style" />
                    <Option type="QString" value="0" name="outline_width" />
                    <Option type="QString" value="Point" name="outline_width_unit" />
                    <Option type="QString" value="solid" name="style" />
                  </Option>
                  <data_defined_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name" />
                      <Option name="properties" />
                      <Option type="QString" value="collection" name="type" />
                    </Option>
                  </data_defined_properties>
                </layer>
              </symbol>
            </background>
            <shadow shadowScale="100" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowRadius="1.5" shadowOffsetGlobal="1" shadowDraw="0" shadowBlendMode="6" shadowOffsetDist="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusAlphaOnly="0" shadowUnder="0" shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" />
            <dd_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
            </dd_properties>
            <substitutions />
          </text-style>
          <text-format useMaxLineLengthForAutoWrap="1" leftDirectionSymbol="&lt;" placeDirectionSymbol="0" wrapChar="" plussign="0" multilineAlign="3" reverseDirectionSymbol="0" autoWrapLength="0" addDirectionSymbol="0" rightDirectionSymbol="&gt;" formatNumbers="0" decimals="3" />
          <placement predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" maximumDistanceUnit="MM" centroidWhole="0" rotationAngle="0" rotationUnit="AngleDegrees" geometryGenerator="" lineAnchorTextPoint="FollowPlacement" lineAnchorClipping="0" yOffset="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" quadOffset="4" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overlapHandling="PreventOverlap" centroidInside="0" dist="0" distUnits="MM" overrunDistance="0" prioritization="PreferCloser" polygonPlacementFlags="2" geometryGeneratorEnabled="0" distMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" placement="6" layerType="PointGeometry" priority="5" offsetUnits="MM" xOffset="0" repeatDistanceUnits="MM" lineAnchorType="0" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" fitInPolygonOnly="0" overrunDistanceUnit="MM" placementFlags="10" preserveRotation="1" maximumDistance="0" offsetType="1" maxCurvedCharAngleIn="25" repeatDistance="0" />
          <rendering minFeatureSize="0" scaleMax="0" mergeLines="0" unplacedVisibility="0" labelPerPart="0" fontMinPixelSize="3" drawLabels="1" fontLimitPixelSize="0" scaleMin="0" zIndex="0" fontMaxPixelSize="10000" scaleVisibility="0" obstacleFactor="1" upsidedownLabels="0" maxNumLabels="2000" obstacleType="1" limitNumLabels="0" obstacle="1" />
          <dd_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name" />
              <Option name="properties" />
              <Option type="QString" value="collection" name="type" />
            </Option>
          </dd_properties>
          <callout type="simple">
            <Option type="Map">
              <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint" />
              <Option type="int" value="0" name="blendMode" />
              <Option type="Map" name="ddProperties">
                <Option type="QString" value="" name="name" />
                <Option name="properties" />
                <Option type="QString" value="collection" name="type" />
              </Option>
              <Option type="bool" value="false" name="drawToAllParts" />
              <Option type="QString" value="0" name="enabled" />
              <Option type="QString" value="point_on_exterior" name="labelAnchorPoint" />
              <Option type="QString" value="&lt;symbol frame_rate=&quot;10&quot; is_animated=&quot;0&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; name=&quot;symbol&quot; alpha=&quot;1&quot; clip_to_extent=&quot;1&quot;&gt;&lt;data_defined_properties&gt;&lt;Option type=&quot;Map&quot;&gt;&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/&gt;&lt;Option name=&quot;properties&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/&gt;&lt;/Option&gt;&lt;/data_defined_properties&gt;&lt;layer locked=&quot;0&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; id=&quot;{8d233fc0-e504-4a14-8258-3f4d925f851f}&quot; enabled=&quot;1&quot;&gt;&lt;Option type=&quot;Map&quot;&gt;&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot; name=&quot;line_color&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/&gt;&lt;/Option&gt;&lt;data_defined_properties&gt;&lt;Option type=&quot;Map&quot;&gt;&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/&gt;&lt;Option name=&quot;properties&quot;/&gt;&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/&gt;&lt;/Option&gt;&lt;/data_defined_properties&gt;&lt;/layer&gt;&lt;/symbol&gt;" name="lineSymbol" />
              <Option type="double" value="0" name="minLength" />
              <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" />
              <Option type="QString" value="MM" name="minLengthUnit" />
              <Option type="double" value="0" name="offsetFromAnchor" />
              <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" />
              <Option type="QString" value="MM" name="offsetFromAnchorUnit" />
              <Option type="double" value="0" name="offsetFromLabel" />
              <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" />
              <Option type="QString" value="MM" name="offsetFromLabelUnit" />
            </Option>
          </callout>
        </settings>
      </labeling>
</qgis>
