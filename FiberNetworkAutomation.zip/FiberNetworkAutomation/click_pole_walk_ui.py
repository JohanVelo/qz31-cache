# -*- coding: utf-8 -*-
# claude:intent MUTATE - user asked (JJ GO 2026-10-16, Click Line v3 plan rev 4): "Preview before writing; one
#   Ctrl+Z undoes it" - plan: this dialog only previews (a canvas item, no layer restyle) and calls
#   click_pole_walk.apply / revert, which write the edit buffer after their own refusals + verified backup.
# claude:boq-impact none until JJ presses Apply on a planning project: pole Name / Pole ID and Distribution Type
#   change in the edit buffer only (BOQ quantities do not move: no feature is added, deleted or moved).
"""Number poles (BETA): Preview the walk on the map, then Apply / Revert.

The preview is ONE canvas item drawn in view pixels (the layers' own styles are never touched): new Pole IDs
at the poles, Distribution cables blue, Spur cables orange, loop spans red dashed."""
from qgis.core import QgsCoordinateTransform, QgsPointXY, QgsProject, QgsRectangle
from qgis.gui import QgsMapCanvasItem
from qgis.PyQt import sip
from qgis.PyQt.QtCore import QPointF, QRectF, Qt
from qgis.PyQt.QtGui import QColor, QFont, QPainter, QPainterPath, QPen, QPolygonF
from qgis.PyQt.QtWidgets import (QApplication, QCheckBox, QDialog, QHBoxLayout, QLabel, QLineEdit, QPushButton,
                                 QTreeWidget, QTreeWidgetItem, QVBoxLayout)

try:
    from . import click_pole_walk as W
except ImportError:  # pragma: no cover - plain-module tests
    import click_pole_walk as W

COL_MAIN = QColor(37, 99, 235)       # Distribution (main)
COL_SPUR = QColor(245, 158, 11)      # Spur
COL_LOOP = QColor(220, 38, 38)       # loop span (not walked)
HALO = QColor(7, 11, 18, 230)
_DLG = None


class _PreviewItem(QgsMapCanvasItem):
    """New numbers + Distribution/Spur colours. Points are copies in the canvas CRS; paint() only maps them to
    view pixels, culled to the visible extent, so pans and zooms cost nothing extra."""

    def __init__(self, canvas):
        super().__init__(canvas)
        self._canvas = canvas
        self.labels, self.lines = [], []     # [(QgsPointXY, text)], [([QgsPointXY], QColor, dashed)]
        self._r = QRectF()
        self.setZValue(1012)

    def updatePosition(self):
        try:
            self.setPos(0, 0)
        except Exception:
            pass

    def set_data(self, labels, lines):
        vp = self._canvas.viewport()
        r = QRectF(0, 0, vp.width(), vp.height())
        if r != self._r:
            self.prepareGeometryChange()
            self._r = r
        self.labels, self.lines = labels, lines
        self.update()

    def boundingRect(self):
        try:
            vp = self._canvas.viewport()
            r = QRectF(0, 0, vp.width(), vp.height())
            if r != self._r:
                self.prepareGeometryChange()
                self._r = r
            return QRectF(self._r)
        except Exception:
            return QRectF()

    def paint(self, painter, option=None, widget=None):
        try:
            ct = self._canvas.getCoordinateTransform()
            ext = self._canvas.extent()
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            for pts, col, dashed in self.lines:
                xs = [p.x() for p in pts]
                ys = [p.y() for p in pts]
                if max(xs) < ext.xMinimum() or min(xs) > ext.xMaximum() or max(ys) < ext.yMinimum() \
                        or min(ys) > ext.yMaximum():
                    continue
                poly = QPolygonF([QPointF(ct.transform(p).x(), ct.transform(p).y()) for p in pts])
                painter.setPen(QPen(HALO, 7.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
                painter.drawPolyline(poly)
                painter.setPen(QPen(col, 4.0, Qt.PenStyle.DashLine if dashed else Qt.PenStyle.SolidLine,
                                    Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
                painter.drawPolyline(poly)
            if self._canvas.mapUnitsPerPixel() <= 0:
                return
            f = QFont()
            f.setPointSizeF(8.5)
            f.setBold(True)
            painter.setFont(f)
            for p, text in self.labels:
                if not ext.contains(p):
                    continue
                q = ct.transform(p)
                path = QPainterPath()
                path.addText(QPointF(q.x() + 6, q.y() - 6), f, text)
                painter.setPen(QPen(HALO, 3.2, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawPath(path)
                painter.fillPath(path, QColor(255, 255, 255))
        except Exception:
            pass


class WalkDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent or iface.mainWindow())
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.item = None
        self.plan = None
        self.L = None
        self.refs = []
        self.setWindowTitle("Number poles - walk from the POP")
        self.setMinimumWidth(460)
        v = QVBoxLayout(self)
        head = QHBoxLayout()
        title = QLabel("<b>Number poles</b> - feeder, then each splitter's network: spurs first, right first")
        title.setWordWrap(True)
        beta = QLabel(" BETA ")
        beta.setStyleSheet("background:#FF8A00;color:#111111;font-weight:bold;border-radius:3px;padding:1px 4px;")
        head.addWidget(title, 1)
        head.addWidget(beta, 0, Qt.AlignmentFlag.AlignTop)
        v.addLayout(head)
        self.summary = QLabel("")
        self.summary.setWordWrap(True)
        self.summary.setTextFormat(Qt.TextFormat.RichText)
        v.addWidget(self.summary)
        pr = QHBoxLayout()
        pr.addWidget(QLabel("Names"))
        self.pattern = QLineEdit()
        self.pattern.setPlaceholderText("e.g. HT_VRE_####PL  (# = the number)")
        self.pattern.editingFinished.connect(self.preview)
        pr.addWidget(self.pattern, 1)
        v.addLayout(pr)
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setMinimumHeight(180)
        self.tree.itemDoubleClicked.connect(self._zoom)
        v.addWidget(self.tree, 1)
        self.refs_ok = QCheckBox("")
        self.refs_ok.setVisible(False)
        v.addWidget(self.refs_ok)
        self.confirm = QLineEdit()
        v.addWidget(self.confirm)
        self.status = QLabel("")
        self.status.setWordWrap(True)
        v.addWidget(self.status)
        b = QHBoxLayout()
        self.b_prev = QPushButton("Preview again")
        self.b_apply = QPushButton("Apply")
        self.b_revert = QPushButton("Revert numbering")
        self.b_close = QPushButton("Close")
        for w in (self.b_prev, self.b_apply, self.b_revert, self.b_close):
            b.addWidget(w)
        v.addLayout(b)
        self.b_prev.clicked.connect(lambda _c=False: self.preview())
        self.b_apply.clicked.connect(lambda _c=False: self._apply())
        self.b_revert.clicked.connect(lambda _c=False: self._revert())
        self.b_close.clicked.connect(lambda _c=False: self.close())
        self.finished.connect(lambda _r=0: self._drop_item())

    # ── preview ──────────────────────────────────────────────────────────────
    def preview(self):
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            self._preview()
        except Exception as e:
            self.status.setText("Preview failed: %s" % e)
        finally:
            QApplication.restoreOverrideCursor()

    def _preview(self):
        prj = QgsProject.instance()
        self.L = L = W.find_layers(prj)
        self.confirm.setPlaceholderText("type the project name to confirm: %s" % prj.baseName())
        miss = [k for k in ("poles", "feeder", "dist", "pop") if L.get(k) is None]
        if miss:
            self._fail("Missing layer(s): %s. %s" % (", ".join(miss), L.get("why", "")))
            return
        pat = W.parse_pattern(self.pattern.text()) if self.pattern.text().strip() else None
        self.plan = plan = W.make_plan(L, pattern=pat, project=prj)
        if plan["res"]["refused"]:
            self._fail(plan["res"]["refused"])
            return
        if plan["pattern"] is None:
            self._fail("No existing pole names to copy: type the name pattern above (e.g. HT_VRE_####PL).")
            return
        if not self.pattern.text().strip():
            self.pattern.setText(W.pattern_text(plan["pattern"]))
        self.refs = W.name_scan(prj, plan, skip=[L["poles"]])
        why = W.refuse_reason(prj, L, W.DEFAULTS["words"], plan["pattern"], plan)
        res, li = plan["res"], plan["res"]["listed"]
        types = list(res["dist_type"].values())
        self.summary.setText(
            "<b>%d</b> poles: <b>%d</b> from the POP, %d on networks not joined yet, %d loose.<br>"
            "<b>%d</b> names change. Cables: <b>%d</b> Distribution, <b>%d</b> Spur (%d change)."
            % (len(res["order"]), res["walked_from_pop"], len(res["order"]) - res["walked_from_pop"]
               - len(li["loose_poles"]), len(li["loose_poles"]), plan["n_renamed"], types.count(W.DEFAULTS["words"][0]),
               types.count(W.DEFAULTS["words"][1]), plan["n_typed"])
            + ("<br>Cable names: <b>%d</b> change (e.g. %s), %d cable(s) have no Cable Size and are not named."
               % (plan["n_named"], self._first_name(plan), len(plan["no_size"])) if not plan["names_off"]
               else "<br>Cable names are not written: %s." % plan["names_off"])
            + ("<br><span style='color:#DC2626'><b>Apply is refused here:</b> %s</span>" % why if why else ""))
        self._fill_tree(plan)
        if self.refs:
            n = sum(c for _l, c in self.refs)
            self.refs_ok.setText("I know: %d reference(s) in %s will be out of date" % (
                n, ", ".join(lname for lname, _c in self.refs)))
            self.refs_ok.setChecked(False)
        self.refs_ok.setVisible(bool(self.refs))
        self.b_apply.setEnabled(not why)
        self._draw(plan)
        self.status.setText("Preview drawn: blue = Distribution, orange = Spur, red dashed = loop span. "
                            "Nothing is written until Apply.")

    def _fail(self, text):
        self.summary.setText("<span style='color:#DC2626'><b>%s</b></span>" % text)
        self.tree.clear()
        self.b_apply.setEnabled(False)
        self._drop_item()

    def _fill_tree(self, plan):
        self.tree.clear()
        L, li = self.L, plan["res"]["listed"]
        P = {f.id(): f for f in L["poles"].getFeatures()}

        def pole_pt(fid):
            f = P.get(fid)
            return (L["poles"], f.geometry().asPoint()) if f is not None and not f.geometry().isEmpty() else None

        groups = [
            ("Networks not joined to the POP", [("%d poles" % len(nodes), pole_pt(nodes[0])) for nodes in li["islands"]]),
            ("Loose poles (on no cable)", [(str(P[f]["Name"] or f), pole_pt(f)) for f in li["loose_poles"]]),
            ("Loop spans (not walked)", [("%s - %s" % (P[a]["Name"] or a, P[b]["Name"] or b), pole_pt(a))
                                         for a, b in li["loop_spans"]]),
            ("Cables near 50/50 Distribution/Spur", [("cable %d" % f, self._feat_pt(L["dist"], f))
                                                     for f in li["near_half"]]),
            ("Distribution cables with no poles", [("cable %d" % f, self._feat_pt(L["dist"], f))
                                                   for f in li["unjoined_dist"]]),
            ("Splitters with no distribution pole within 3 m", [("splitter %d" % f, self._feat_pt(L["splitters"], f))
                                                                for f in li["offcable_splitters"]]),
            ("Extra splitters on one network", [("splitter %d" % f, self._feat_pt(L["splitters"], f))
                                                for f in li["extra_splitters"]]),
            ("Distribution cables with no Cable Size (not named)", [("cable %d" % f, self._feat_pt(L["dist"], f))
                                                                    for f in plan["no_size"]]),
            ("Old pole / cable names used in other layers", [("%s: %d" % r, None) for r in self.refs]),
        ]
        for title, rows in groups:
            top = QTreeWidgetItem(["%s (%d)" % (title, len(rows))])
            self.tree.addTopLevelItem(top)
            for text, at in rows[:500]:
                it = QTreeWidgetItem([text])
                it.setData(0, Qt.ItemDataRole.UserRole, at)
                top.addChild(it)

    @staticmethod
    def _first_name(plan):
        rows = [r["new"][0] for r in plan["dist_names"].values()]
        return min(rows) if rows else "-"

    @staticmethod
    def _feat_pt(lyr, fid):
        if lyr is None:
            return None
        f = lyr.getFeature(fid)
        g = f.geometry()
        if g is None or g.isEmpty():
            return None
        return lyr, g.pointOnSurface().asPoint()

    def _zoom(self, it, _col=0):
        at = it.data(0, Qt.ItemDataRole.UserRole)
        if not at:
            return
        lyr, pt = at
        xf = QgsCoordinateTransform(lyr.crs(), self.canvas.mapSettings().destinationCrs(), QgsProject.instance())
        p = xf.transform(QgsPointXY(pt))
        half = max(self.canvas.mapUnitsPerPixel() * 150, 1e-9)
        if self.canvas.mapUnitsPerPixel() > (0.0006 if self.canvas.mapSettings().destinationCrs().isGeographic()
                                             else 60):
            half = 0.0004 if self.canvas.mapSettings().destinationCrs().isGeographic() else 40
        self.canvas.setExtent(QgsRectangle(p.x() - half, p.y() - half, p.x() + half, p.y() + half))
        self.canvas.refresh()

    def _draw(self, plan):
        self._drop_item()
        L = self.L
        prj = QgsProject.instance()
        dst = self.canvas.mapSettings().destinationCrs()
        xp = QgsCoordinateTransform(L["poles"].crs(), dst, prj)
        labels = []
        for f in L["poles"].getFeatures():
            row = plan["poles"].get(f.id())
            g = f.geometry()
            if row is None or g is None or g.isEmpty():
                continue
            labels.append((QgsPointXY(xp.transform(g.asPoint())), row["new"][1] or row["new"][0]))
        xd = QgsCoordinateTransform(L["dist"].crs(), dst, prj)
        lines = []
        words = W.DEFAULTS["words"]
        for f in L["dist"].getFeatures():
            t = plan["res"]["dist_type"].get(f.id())
            if t is None:
                continue
            for part in W._parts(f.geometry()):
                lines.append(([QgsPointXY(xd.transform(p)) for p in part], COL_MAIN if t == words[0] else COL_SPUR,
                              False))
        P = {f.id(): f.geometry().asPoint() for f in L["poles"].getFeatures() if not f.geometry().isEmpty()}
        for a, b in plan["res"]["listed"]["loop_spans"]:
            if a in P and b in P:
                lines.append(([QgsPointXY(xp.transform(P[a])), QgsPointXY(xp.transform(P[b]))], COL_LOOP, True))
        self.item = _PreviewItem(self.canvas)
        self.item.set_data(labels, lines)

    def _drop_item(self):
        item, self.item = self.item, None
        if item is not None and not sip.isdeleted(item):
            sc = item.scene()
            if sc is not None:
                sc.removeItem(item)

    # ── apply / revert ───────────────────────────────────────────────────────
    def _apply(self):
        if self.plan is None:
            return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            ok, msg, info = W.apply(QgsProject.instance(), self.L, self.plan, self.confirm.text(),
                                    refs_ok=self.refs_ok.isChecked())
        except Exception as e:
            ok, msg, info = False, "Apply failed, nothing written: %s" % e, {}
        finally:
            QApplication.restoreOverrideCursor()
        self.status.setText(msg + ("<br>Backup: %s" % info["backup"] if ok and info.get("backup") else ""))
        if ok:
            self.iface.messageBar().pushSuccess("Number poles", msg + ". Ctrl+Z on each layer undoes it; save to keep.")
            self._drop_item()
            self.confirm.clear()
            self.plan = None
            self.b_apply.setEnabled(False)

    def _revert(self):
        L = W.find_layers(QgsProject.instance())
        if L.get("poles") is None or L.get("dist") is None:
            self.status.setText("No Poles / Distribution Cable layer to revert.")
            return
        ok, msg, kept = W.revert(QgsProject.instance(), L)
        self.status.setText(msg)
        if kept:
            self._fill_kept(kept)

    def _fill_kept(self, kept):
        top = QTreeWidgetItem(["Changed by hand since Apply - left alone (%d)" % len(kept)])
        self.tree.insertTopLevelItem(0, top)
        for kind, fid, cur in kept[:500]:
            top.addChild(QTreeWidgetItem(["%s %s: %s" % (kind, fid, cur)]))
        top.setExpanded(True)

    def closeEvent(self, e):
        self._drop_item()
        super().closeEvent(e)


def open_dialog(iface):
    """One dialog per QGIS session; preview runs when it opens."""
    global _DLG
    if _DLG is None or sip.isdeleted(_DLG):
        _DLG = WalkDialog(iface)
    _DLG.show()
    _DLG.raise_()
    _DLG.activateWindow()
    _DLG.preview()
    return _DLG
