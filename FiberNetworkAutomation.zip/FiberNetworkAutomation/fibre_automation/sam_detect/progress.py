"""progress — one themed, ACCURATE progress dialog for the long detection runs.

A single 0-100% bar that spans the whole pipeline via weighted stage bands, so the
user sees true overall progress (not three separate spinners). Each stage maps its
internal i/total into its band; a live ETA is derived from the real elapsed rate.

Used by Detect Buildings (sam_detect.runner) and Generate Erven (erven_studio).
"""
import time

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QDialog, QHBoxLayout, QLabel, QProgressBar,
                                 QPushButton, QVBoxLayout)

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

# (key, label, band_lo, band_hi) — bands sum the pipeline to 100%.
DETECT_STAGES = [
    ("tiles", "Rendering satellite tiles", 0, 40),
    ("ai", "AI detection (SAM2)", 40, 96),
    ("finish", "Building polygons", 96, 100),
]
ERVEN_STAGES = [
    ("buildings", "Detecting buildings", 0, 25),
    ("cadastre", "Fetching CSG cadastre", 25, 45),
    ("erven", "Generating erven", 45, 90),
    ("finish", "Finalising", 90, 100),
]

_QSS = """
QDialog { background:#0F1A30; }
QLabel { color:#EAF0FF; }
QLabel#hdr { font-size:16px; font-weight:800; color:#FFFFFF; }
QLabel#stage { color:#2ec4f1; font-size:13px; font-weight:700; }
QLabel#detail, QLabel#eta { color:#9FB4C8; font-size:12px; }
QProgressBar { background:#141E36; border:1px solid #243352; border-radius:8px;
               height:22px; text-align:center; color:#EAF0FF; font-weight:700; }
QProgressBar::chunk { background:#2ec4f1; border-radius:7px; }
QPushButton { background:#141E36; color:#EAF0FF; border:1px solid #243352;
              border-radius:8px; padding:6px 14px; }
QPushButton:hover { border:1px solid #E0607A; color:#E0607A; }
"""


class ProgressDialog(QDialog):
    """Themed accurate progress dialog. Drop-in-ish for QProgressDialog
    (wasCanceled()), plus set_stage()/set_sub() for band-mapped overall %."""

    def __init__(self, parent, title="Working…", stages=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.setStyleSheet(_QSS)
        self.setWindowTitle(title)
        self.setMinimumWidth(440)
        self.setModal(True)
        self._bands = {k: (lo, hi) for k, _, lo, hi in (stages or [])}
        self._labels = {k: lbl for k, lbl, _, _ in (stages or [])}
        self.cancelled = False
        self._t0 = time.monotonic()
        self._pct = 0.0

        v = QVBoxLayout(self)
        v.setContentsMargins(22, 18, 22, 16)
        v.setSpacing(10)
        self._hdr = QLabel(title)
        self._hdr.setObjectName("hdr")
        v.addWidget(self._hdr)
        self._stage = QLabel("Starting…")
        self._stage.setObjectName("stage")
        v.addWidget(self._stage)
        self._bar = QProgressBar()
        self._bar.setRange(0, 1000)
        self._bar.setValue(0)
        v.addWidget(self._bar)
        row = QHBoxLayout()
        self._detail = QLabel("")
        self._detail.setObjectName("detail")
        self._eta = QLabel("")
        self._eta.setObjectName("eta")
        row.addWidget(self._detail, 1)
        row.addWidget(self._eta)
        v.addLayout(row)
        brow = QHBoxLayout()
        brow.addStretch(1)
        self._cancel = QPushButton("Cancel")
        self._cancel.clicked.connect(self._on_cancel)
        brow.addWidget(self._cancel)
        v.addLayout(brow)

    def _on_cancel(self):
        self.cancelled = True
        self._stage.setText("Cancelling…")

    def wasCanceled(self):
        return self.cancelled

    def _apply(self, pct):
        from qgis.PyQt.QtWidgets import QApplication
        self._pct = max(self._pct, min(100.0, pct))   # monotonic, never goes back
        self._bar.setValue(int(self._pct * 10))
        self._bar.setFormat(f"{self._pct:.0f}%")
        el = time.monotonic() - self._t0
        if self._pct >= 1 and el > 1:
            rem = el * (100.0 - self._pct) / self._pct
            self._eta.setText("done" if rem < 1 else f"~{int(rem // 60)}m {int(rem % 60)}s left")
        QApplication.processEvents()

    def set_stage(self, key, detail=""):
        self._stage.setText(self._labels.get(key, key))
        self._detail.setText(detail)
        lo, _ = self._bands.get(key, (self._pct, self._pct))
        self._apply(lo)

    def set_sub(self, key, done, total, detail=None):
        """Map done/total within the stage's band -> overall %."""
        lo, hi = self._bands.get(key, (self._pct, self._pct))
        frac = (done / total) if total else 0.0
        frac = max(0.0, min(1.0, frac))
        self._apply(lo + (hi - lo) * frac)
        self._detail.setText(detail if detail is not None
                             else f"{int(done)}/{int(total)}")

    def overall(self, pct, detail=None):
        self._apply(pct)
        if detail is not None:
            self._detail.setText(detail)

    def finish(self):
        # NB: must NOT be named done() — that shadows QDialog.done(int), which Qt
        # calls with a result code on Escape / window-close / accept / reject. The
        # shadow crashed the dialog ("done() takes 1 positional argument but 2 were
        # given") whenever a user closed it, esp. on Qt5/older QGIS. Keep it renamed.
        self.overall(100, "Done")
        try:
            self.close()
        except Exception:
            _swallowed_note()
