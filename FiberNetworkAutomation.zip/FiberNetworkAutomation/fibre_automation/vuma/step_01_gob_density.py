"""
Step 01 — GOB Filter + Density Grid

Reads the full Google Open Buildings v3 download, applies confidence/area
filters, builds an 80m density grid, and flags low-density cells for RAMP.

Inputs  (set AOI_* constants below or pass via environment):
  GOB_RAW_PATH  — raw GOB geojson download for the AOI
  AOI_XMIN/YMIN/XMAX/YMAX — bounding box in WGS84

Outputs (all in OUT_DIR):
  gob_filtered.geojson   — filtered GOB centroids (conf>=0.70, area>=15m²)
  density_ok.geojson     — grid cells at or above 70% of median density
  density_gap.geojson    — gap cells <70% of median (RAMP targets these)
  density_zero.geojson   — empty cells (no GOB points at all)

Run in qgis-venv:
  python step_01_gob_density.py
"""

import json
import math
import numpy as np

# ── Config — adjust per project ──────────────────────────────────────────────
GOB_RAW_PATH = "C:/Temp/google_ob_aoi.geojson"
OUT_DIR      = "C:/Temp"

# Full Mohadin AOI (WGS84)
AOI_XMIN =  27.032512
AOI_YMIN = -26.739926
AOI_XMAX =  27.064755
AOI_YMAX = -26.710158

# Filter thresholds (GOB v3, SA informal settlements — confirmed via Mohadin)
CONF_MIN   = 0.70   # below = vegetation / rocks / shadows
AREA_MIN   = 15.0   # m² — removes walls, trees, tiny sheds (no upper cap)

# Density grid
GRID_M     = 80     # cell size in metres
GAP_THRESH = 0.70   # cells below 70% of median density are flagged as gaps
# ─────────────────────────────────────────────────────────────────────────────

MID_LAT = (AOI_YMIN + AOI_YMAX) / 2
DEG_PER_M_LAT = 1.0 / 111320.0
DEG_PER_M_LON = 1.0 / (111320.0 * math.cos(math.radians(MID_LAT)))
CELL_LAT = GRID_M * DEG_PER_M_LAT
CELL_LON = GRID_M * DEG_PER_M_LON

print(f"Loading GOB from {GOB_RAW_PATH} ...")
with open(GOB_RAW_PATH) as f:
    raw = json.load(f)
print(f"  Raw features: {len(raw['features']):,}")

filtered = [
    feat for feat in raw['features']
    if (AOI_XMIN <= feat['geometry']['coordinates'][0] <= AOI_XMAX and
        AOI_YMIN <= feat['geometry']['coordinates'][1] <= AOI_YMAX and
        feat['properties'].get('confidence', 0) >= CONF_MIN and
        feat['properties'].get('area_m2', 0) >= AREA_MIN)
]
print(f"  After filter (conf>={CONF_MIN}, area>={AREA_MIN}m2): {len(filtered):,}")

out_gob = f"{OUT_DIR}/gob_filtered.geojson"
with open(out_gob, 'w') as f:
    json.dump({"type": "FeatureCollection", "features": filtered}, f)
print(f"  Saved -> {out_gob}")

# Build density grid
cols = int((AOI_XMAX - AOI_XMIN) / CELL_LON) + 1
rows = int((AOI_YMAX - AOI_YMIN) / CELL_LAT) + 1
grid = [[0] * cols for _ in range(rows)]

for feat in filtered:
    lon, lat = feat['geometry']['coordinates']
    col = int((lon - AOI_XMIN) / CELL_LON)
    row = int((lat - AOI_YMIN) / CELL_LAT)
    if 0 <= col < cols and 0 <= row < rows:
        grid[row][col] += 1

flat = [v for row_vals in grid for v in row_vals if v > 0]
median_density = float(np.median(flat)) if flat else 1.0
threshold = GAP_THRESH * median_density
print(f"\nGrid {rows}x{cols} = {rows*cols:,} cells")
print(f"  Occupied: {len(flat):,}  Median density: {median_density:.1f}  Gap threshold: {threshold:.1f}")

gap_feats, ok_feats, zero_feats = [], [], []
for r in range(rows):
    for c in range(cols):
        count = grid[r][c]
        x0 = AOI_XMIN + c * CELL_LON
        y0 = AOI_YMIN + r * CELL_LAT
        x1, y1 = x0 + CELL_LON, y0 + CELL_LAT
        feat = {
            "type": "Feature",
            "geometry": {"type": "Polygon",
                "coordinates": [[[x0,y0],[x1,y0],[x1,y1],[x0,y1],[x0,y0]]]},
            "properties": {
                "count": count, "row": r, "col": c,
                "cx": round((x0+x1)/2, 6),
                "cy": round((y0+y1)/2, 6),
                "pct_of_median": round(count / median_density * 100, 1)
            }
        }
        if count == 0:
            zero_feats.append(feat)
        elif count < threshold:
            gap_feats.append(feat)
        else:
            ok_feats.append(feat)

print(f"  OK: {len(ok_feats):,}  GAP: {len(gap_feats):,}  Empty: {len(zero_feats):,}")

for name, feats in [('density_ok', ok_feats),
                    ('density_gap', gap_feats),
                    ('density_zero', zero_feats)]:
    path = f"{OUT_DIR}/{name}.geojson"
    with open(path, 'w') as f:
        json.dump({"type": "FeatureCollection", "features": feats}, f)
    print(f"  Saved {len(feats):,} -> {path}")

print("\nStep 01 done. Next: run step_01_ramp_fill.py on gap cells.")
