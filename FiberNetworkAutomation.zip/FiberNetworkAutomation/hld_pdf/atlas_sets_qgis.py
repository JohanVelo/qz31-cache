# -*- coding: utf-8 -*-
# claude:intent MUTATE - user asked (JJ 2026-10-26): "add more pages ... select which layers and labels
#   I want visible ... keep the HLD grid ... page count updated" - plan Atlas Page Sets rev 3, step 2.
#   Writes only the HLD atlas layout, its generated "HLD Book Pages" memory layer and private copy
#   layers it owns; never a network layer. All-or-nothing: any failure restores the snapshot.
# claude:boq-impact none - presentation only (pages, legends, private draw copies)
"""HLD Network Atlas page SETS - the QGIS side (atlas_sets.py holds the pure rules).

apply_sets(project, layout, sets) writes a set list into a grid atlas built by the engine:
  * "HLD Book Pages" gets set_no / set_title / page_ids and one row per set page,
  * the map draws the row's layers on set pages (NULL on Network pages: the theme decides),
  * a private guard layer keeps a set page's list from ever being empty, and private copies
    give a ticked layer its own label on/off,
  * every set gets its own legend (a copy of the Network legend, only its layers) and, when the
    book has PROJECT TOTALS, its own totals; each prints only on its own pages,
  * set page titles follow the Network title's own wording,
  * the set list is stored as JSON on the layout and in the project (for Rebuild).
An empty list puts the layout back exactly as the engine built it.
"""
import json

try:
    from . import atlas_sets as AS
except ImportError:          # run as a plain module (hld_generate.py headless)
    import atlas_sets as AS

PROJECT_SCOPE = "VelocityNexus"
PROP_OWNED = "vf_atlas_set_owned"          # on every layout item this module creates
PROP_TITLE_ORIG = "vf_atlas_set_title_orig"  # the title's own text, kept to undo the wrap
PROP_SRC = "vf_atlas_set_src"               # a copy layer's source layer id
PROP_BOOK = "vf_atlas_set_book"             # on every private layer: the book layer it serves
NATIVE_ROLE = "vf_native_role"

# Fault injection for the all-or-nothing tests: the name of the sub-step that raises.
FAULT_AT = None


class SetsRefused(Exception):
    """The layout is not one the Pages... window may change; the message says why."""


def _items(layout):
    """Layout items only (layout.items() also returns plain Qt graphics items)."""
    from qgis.core import QgsLayoutItem
    return [it for it in layout.items() if isinstance(it, QgsLayoutItem)]


def _step(name):
    if FAULT_AT == name:
        raise RuntimeError("fault injected at %s" % name)


# ── which layouts ───────────────────────────────────────────────────────────────────────
def book_layer(layout):
    try:
        at = layout.atlas()
        cov = at.coverageLayer() if at is not None else None
    except Exception:
        return None
    if cov is None or cov.customProperty("vf_hld_role") != "book_pages":
        return None
    return cov


def grid_layer(project):
    return next((l for l in project.mapLayers().values() if l.customProperty("vf_hld_role") == "grid"), None)


def check_layout(project, layout):
    """None when the layout is an HLD grid atlas the Pages... window may change, else why not."""
    book = book_layer(layout)
    if book is None or not layout.atlas().enabled():
        return "Page sets work on the HLD Network Atlas only (this layout is not one)."
    frame = book.customProperty("vf_hld_frame")
    if frame is None:
        return ("This atlas was built before page sets existed. Rebuild it once "
                "(HLD Network Atlas → Rebuild), then add pages.")
    if str(frame) != "hld":
        return "Page sets work on the HLD Network Atlas only (this is a %s layout)." % frame
    if grid_layer(project) is None:
        return "Page sets need a numbered grid (HLD Grid); this atlas pages over another layer."
    try:
        AS.check_network_rows(_network_rows(book))
    except AS.SetsError as e:
        return "The atlas pages cannot take page sets: %s." % e
    return None


def _network_rows(book):
    names = [f.name() for f in book.fields()]
    out = []
    for f in book.getFeatures():
        r = {n: _plain(f[n]) for n in names if n not in AS.NEW_FIELDS}
        if "set_no" in names and int(_plain(f["set_no"]) or 0) != 0:
            continue
        out.append(r)
    return out


def _plain(v):
    try:
        if v is None or (hasattr(v, "isNull") and v.isNull()):
            return None
    except Exception:
        pass
    return v


# ── stored set list ────────────────────────────────────────────────────────────────────
def _project_key(layout):
    # every key part becomes an XML element name in the .qgz, and QGIS drops (does not save) a
    # part that is not a valid name - "HLD (v2) & 2026" would lose its sets on Rebuild. Hex of
    # the name is always valid and never collides ("A B" and "A_B" stay apart).
    return "atlas_sets/L" + layout.name().encode("utf-8").hex()


def read_sets(project, layout):
    """(sets, message). The layout copy wins; a missing or unreadable copy -> Network only."""
    for text in (layout.customProperty(AS.PROP_SETS),
                 project.readEntry(PROJECT_SCOPE, _project_key(layout), "")[0]):
        if text:
            try:
                return AS.from_json(text), None
            except AS.SetsError as e:
                return AS.empty_sets(), str(e)
    return AS.empty_sets(), None


def _write_json(project, layout, sets):
    text = AS.to_json(sets) if sets["sets"] else ""
    layout.setCustomProperty(AS.PROP_SETS, text)
    _step("json_layout")
    if text:
        project.writeEntry(PROJECT_SCOPE, _project_key(layout), text)
    else:
        project.removeEntry(PROJECT_SCOPE, _project_key(layout))
    _step("json_project")


# ── snapshot / restore ─────────────────────────────────────────────────────────────────
def _the_map(layout):
    from qgis.core import QgsLayoutItemMap
    at = layout.atlas()
    m = at.coverageLayer() and next((it for it in _items(layout) if isinstance(it, QgsLayoutItemMap)
                                     and it.atlasDriven()), None)
    return m or next((it for it in _items(layout) if isinstance(it, QgsLayoutItemMap)), None)


_DD_KEYS = ("ExcludeFromExports", "Opacity")


def _dd(name):
    from qgis.core import QgsLayoutObject
    return getattr(QgsLayoutObject.DataDefinedProperty, name)


def _snapshot(project, layout):
    from qgis.core import QgsProperty
    book = book_layer(layout)
    m = _the_map(layout)
    items = {}
    for it in _items(layout):
        dd = it.dataDefinedProperties()
        items[it.uuid()] = {
            "dd": {k: QgsProperty(dd.property(_dd(k))) for k in _DD_KEYS},
            "set_no": it.customProperty(AS.PROP_SET_NO),
            "text": it.text() if hasattr(it, "text") and hasattr(it, "setText") else None,
            "title_orig": it.customProperty(PROP_TITLE_ORIG),
        }
    return {
        "layers": set(project.mapLayers().keys()),
        "fields": [f.name() for f in book.fields()],
        "fids": {f.id(): f.attributes() for f in book.getFeatures()},
        "map_dd": {k: QgsProperty(m.dataDefinedProperties().property(_dd(k))) for k in ("MapLayers",)},
        "items": items,
        "mfs": {mf.uuid() for mf in layout.multiFrames()},
        "layout_sets": layout.customProperty(AS.PROP_SETS),
        "project_sets": project.readEntry(PROJECT_SCOPE, _project_key(layout), "")[0],
    }


def _restore(project, layout, snap):
    """Put everything back as the snapshot had it. Nothing that existed before was deleted (old
    sets are only removed after a build succeeds), so this removes what was added and reverts
    what was changed."""
    book = book_layer(layout)
    if snap["project_sets"]:
        project.writeEntry(PROJECT_SCOPE, _project_key(layout), snap["project_sets"])
    else:
        project.removeEntry(PROJECT_SCOPE, _project_key(layout))
    layout.setCustomProperty(AS.PROP_SETS, snap["layout_sets"])
    for it in _items(layout):
        if it.uuid() not in snap["items"]:
            layout.removeLayoutItem(it)
    for mf in list(layout.multiFrames()):
        if mf.uuid() not in snap["mfs"]:
            layout.removeMultiFrame(mf)
    for it in _items(layout):
        rec = snap["items"].get(it.uuid())
        if rec is None:
            continue
        dd = it.dataDefinedProperties()
        for k, prop in rec["dd"].items():
            dd.setProperty(_dd(k), prop)
        _set_custom(it, AS.PROP_SET_NO, rec["set_no"])
        _set_custom(it, PROP_TITLE_ORIG, rec["title_orig"])
        if rec["text"] is not None and it.text() != rec["text"]:
            it.setText(rec["text"])
        it.refreshDataDefinedProperty()
    m = _the_map(layout)
    for k, prop in snap["map_dd"].items():
        m.dataDefinedProperties().setProperty(_dd(k), prop)
    dp = book.dataProvider()
    gone = [f.id() for f in book.getFeatures() if f.id() not in snap["fids"]]
    if gone:
        dp.deleteFeatures(gone)
    extra = [book.fields().indexOf(n) for n in [f.name() for f in book.fields()] if n not in snap["fields"]]
    if extra:
        dp.deleteAttributes(extra)
        book.updateFields()
    vals = {}
    for f in book.getFeatures():
        old = snap["fids"].get(f.id())
        if old is not None and f.attributes() != old:
            vals[f.id()] = {i: v for i, v in enumerate(old)}
    if vals:
        dp.changeAttributeValues(vals)
    book.updateExtents()
    for lid in list(project.mapLayers().keys()):
        if lid not in snap["layers"]:
            project.removeMapLayer(lid)
    layout.atlas().updateFeatures()
    layout.refresh()


def _set_custom(it, key, value):
    if value is None:
        it.removeCustomProperty(key)
    else:
        it.setCustomProperty(key, value)


def _old_sets(project, layout):
    """What the previous set list made: (item uuids, multi-frames, layer ids, set row fids)."""
    book = book_layer(layout)
    items = [it.uuid() for it in _items(layout) if it.customProperty(PROP_OWNED)]
    mfs = [mf for mf in layout.multiFrames() if mf.customProperty(PROP_OWNED)]
    # this book's private layers, and any whose book is gone (left behind by a Rebuild); never
    # another layout's
    layers = [lid for lid, l in project.mapLayers().items() if l.customProperty(AS.PROP_OWNER)
              and (l.customProperty(PROP_BOOK) in (None, book.id())
                   or project.mapLayer(str(l.customProperty(PROP_BOOK))) is None)]
    fids = []
    if book.fields().indexOf("set_no") >= 0:
        fids = [f.id() for f in book.getFeatures() if int(_plain(f["set_no"]) or 0) != 0]
    return items, mfs, layers, fids


def _drop_old(project, layout, old):
    """Remove the previous set list's own things - only after the new one is fully written."""
    items, mfs, layers, fids = old
    for it in _items(layout):
        if it.uuid() in items:
            layout.removeLayoutItem(it)
    for mf in mfs:
        if mf in layout.multiFrames():
            layout.removeMultiFrame(mf)
    book = book_layer(layout)
    if fids:
        book.dataProvider().deleteFeatures(fids)
        book.updateExtents()
    for lid in layers:
        if project.mapLayer(lid) is not None:
            project.removeMapLayer(lid)


def _unwrap(layout):
    """Back to the engine's own layout once no set is left: title, map rule, tags, fields."""
    from qgis.core import QgsProperty
    for it in _items(layout):
        if it.customProperty(AS.PROP_SET_NO) is not None:
            dd = it.dataDefinedProperties()
            for k in _DD_KEYS:
                dd.setProperty(_dd(k), QgsProperty())
            it.removeCustomProperty(AS.PROP_SET_NO)
            it.refreshDataDefinedProperty()
        orig = it.customProperty(PROP_TITLE_ORIG)
        if orig is not None:
            it.setText(orig)
            it.removeCustomProperty(PROP_TITLE_ORIG)
    m = _the_map(layout)
    cur = m.dataDefinedProperties().property(_dd("MapLayers"))
    if cur is not None and "page_ids" in (cur.expressionString() or ""):
        m.dataDefinedProperties().setProperty(_dd("MapLayers"), QgsProperty())
    book = book_layer(layout)
    extra = [book.fields().indexOf(n) for n in AS.NEW_FIELDS if book.fields().indexOf(n) >= 0]
    if extra:
        book.dataProvider().deleteAttributes(extra)
        book.updateFields()


# ── build ──────────────────────────────────────────────────────────────────────────────
def _private(lyr, owner, book):
    from qgis.core import QgsMapLayer
    lyr.setFlags(lyr.flags() | QgsMapLayer.LayerFlag.Private)
    lyr.setCustomProperty(AS.PROP_OWNER, owner)
    lyr.setCustomProperty(PROP_BOOK, book.id())


def _make_copies(project, book, x, labels_on_by_id, warnings):
    """{(source id, kind): copy id} for one set (plan label table)."""
    from qgis.core import QgsNullSymbolRenderer
    out = {}
    for n, (src_id, kind) in enumerate(AS.copies_needed(x, labels_on_by_id)):
        src = project.mapLayer(src_id)
        if src is None:
            continue
        if src.providerType() == "memory":
            warnings.append("Page set “%s”: “%s” is a scratch layer, so its labels cannot be "
                            "switched for this set." % (x["title"], src.name()))
            continue
        if kind == AS.COPY_LABELONLY and src.labeling() is None:
            warnings.append("Page set “%s”: “%s” has no label style to show." % (x["title"], src.name()))
            continue
        c = src.clone()
        c.setName(AS.copy_layer_name(x["set_id"], n, kind))
        if kind == AS.COPY_NOLABEL:
            c.setLabelsEnabled(False)
        else:
            c.setRenderer(QgsNullSymbolRenderer())
            c.setLabelsEnabled(True)
        _private(c, x["set_id"], book)
        c.setCustomProperty(PROP_SRC, src_id)
        project.addMapLayer(c, False)
        out[(src_id, kind)] = c.id()
        _step("copy")
    return out


def _labels_on(project):
    out = {}
    for lid, l in project.mapLayers().items():
        try:
            out[lid] = bool(l.labelsEnabled())
        except AttributeError:
            out[lid] = False
    return out


def _tree_order(project):
    return [n.layer().id() for n in project.layerTreeRoot().findLayers() if n.layer() is not None]


def _hide_unless(item, k):
    from qgis.core import QgsProperty
    expr = AS.set_hidden_expression(k)
    dd = item.dataDefinedProperties()
    dd.setProperty(_dd("ExcludeFromExports"), QgsProperty.fromExpression(expr))
    dd.setProperty(_dd("Opacity"), QgsProperty.fromExpression("if(%s, 0, 100)" % expr))
    item.setCustomProperty(AS.PROP_SET_NO, int(k))
    item.refreshDataDefinedProperty()


def _fresh_uuids(el):
    """A pasted copy must not share the original's uuid (rollback and page pictures key on it)."""
    from qgis.PyQt.QtCore import QUuid
    child = el.firstChildElement()
    while not child.isNull():
        for attr in ("uuid", "templateUuid"):
            if child.hasAttribute(attr):
                child.setAttribute(attr, QUuid.createUuid().toString())
        child = child.nextSiblingElement()


def _clone_item(layout, item):
    from qgis.core import QgsReadWriteContext
    from qgis.PyQt.QtXml import QDomDocument
    doc = QDomDocument()
    el = doc.createElement("Items")
    item.writeXml(el, doc, QgsReadWriteContext())
    _fresh_uuids(el)
    new = layout.addItemsFromXml(el, doc, QgsReadWriteContext())
    c = new[0]
    c.attemptMove(item.positionWithUnits())
    c.setCustomProperty(PROP_OWNED, True)
    return c


_COUNTS = {}      # layer id -> text, for one apply (legend and totals of every set ask again)


def _counts_text(project, lyr):
    if lyr.id() in _COUNTS:
        return _COUNTS[lyr.id()]
    _COUNTS[lyr.id()] = txt = _measure(project, lyr)
    return txt


def _measure(project, lyr):
    from qgis.core import QgsDistanceArea, Qgis
    da = QgsDistanceArea()
    da.setSourceCrs(lyr.crs(), project.transformContext())
    da.setEllipsoid(project.ellipsoid() if project.ellipsoid() not in ("", "NONE") else "WGS84")
    n = lyr.featureCount()
    if lyr.geometryType() == Qgis.GeometryType.Line:
        tot = sum(da.measureLength(f.geometry()) for f in lyr.getFeatures())
        return "%s · %s m" % (format(n, ","), format(int(round(tot)), ","))
    return format(n, ",")


def _set_legend(project, layout, leg0, k, x):
    """A copy of the Network legend that lists only the set's (still existing) vector layers."""
    from qgis.core import QgsLegendRenderer, QgsMapLayer
    leg = _clone_item(layout, leg0)
    leg.setId("legend_set_%d" % k)
    keep = [l_["id"] for l_ in x["layers"] if project.mapLayer(l_["id"]) is not None]
    root = leg.model().rootGroup()
    for node in list(root.findLayers()):
        if node.layerId() not in keep:
            node.parent().removeChildNode(node)
    from qgis.core import QgsLayerTree
    for grp in list(root.children()):
        if QgsLayerTree.isGroup(grp) and not grp.findLayers():
            root.removeChildNode(grp)
    have = {n.layerId() for n in root.findLayers()}
    for lid in keep:
        lyr = project.mapLayer(lid)
        if lid in have or lyr.type() != QgsMapLayer.LayerType.VectorLayer:
            continue
        same = [n for n in root.findLayers() if n.layer() is not None
                and n.layer().type() == QgsMapLayer.LayerType.VectorLayer
                and n.layer().geometryType() == lyr.geometryType()]
        ref = same[-1] if same else None
        if ref is not None:                    # beside its geometry twin, even inside a group
            par = ref.parent()
            node = par.insertLayer(par.children().index(ref) + 1, lyr)
        else:
            node = root.insertLayer(len(root.children()), lyr)
        if ref is not None:
            QgsLegendRenderer.setNodeLegendStyle(node, QgsLegendRenderer.nodeLegendStyle(ref, leg.model()))
        if len(lyr.renderer().legendSymbolItems()) <= 1:
            lab = "%s (%s)" % (lyr.name(), _counts_text(project, lyr))
            node.setCustomProperty("legend/title-label", lab)
            node.setCustomProperty("legend/label-0", lab)
        leg.model().refreshLayerLegend(node)
        have.add(lid)
    leg.updateLegend()
    _hide_unless(leg, k)
    return leg


def _clone_table(layout, frame):
    """A new manual table (multi-frame + one frame) with the same look as `frame`'s table."""
    from qgis.core import QgsReadWriteContext, QgsLayoutItemManualTable, QgsLayoutFrame
    from qgis.PyQt.QtXml import QDomDocument
    ctx = QgsReadWriteContext()
    doc = QDomDocument()
    el = doc.createElement("Items")
    frame.multiFrame().writeXml(el, doc, ctx, False)
    _fresh_uuids(el)
    table = QgsLayoutItemManualTable.create(layout)
    table.readXml(el.firstChildElement(), doc, ctx, False)
    layout.addMultiFrame(table)
    f = QgsLayoutFrame(layout, table)
    f.attemptMove(frame.positionWithUnits())
    f.attemptResize(frame.sizeWithUnits())
    f.setFrameEnabled(frame.frameEnabled())
    f.setBackgroundEnabled(frame.hasBackground())
    table.addFrame(f)
    role = frame.customProperty(NATIVE_ROLE)
    if role:
        f.setCustomProperty(NATIVE_ROLE, role)
    f.setCustomProperty(PROP_OWNED, True)
    table.setCustomProperty(PROP_OWNED, True)
    return table, f


def _set_totals(project, layout, tot0, head0, k, x):
    """The set's own totals: a copy of the PROJECT TOTALS table, one label|value line per ticked
    layer, in the Network table's own cell look. Returns (items, the height the table needs);
    _fit_sidebar sizes and places them."""
    from qgis.core import QgsTableCell, QgsMapLayer, QgsLayoutFrame
    if not isinstance(tot0, QgsLayoutFrame) or tot0.multiFrame() is None:
        return [], 0.0
    table, f = _clone_table(layout, tot0)
    old = table.tableContents()
    tpl = old[0] if old and len(old[0]) >= 2 else None
    ncol = max(2, len(old[0]) if old else 2)
    widths = list(table.columnWidths())

    def cell(text, j):
        c = QgsTableCell(text)
        if tpl is not None:                    # j 0 = label look, 1 = value look
            c.setTextFormat(tpl[j].textFormat())
            c.setHorizontalAlignment(tpl[j].horizontalAlignment())
            c.setVerticalAlignment(tpl[j].verticalAlignment())
        return c

    rows = []
    for l_ in x["layers"]:
        lyr = project.mapLayer(l_["id"])
        if lyr is None or lyr.type() != QgsMapLayer.LayerType.VectorLayer:
            continue
        rows.append([cell(lyr.name(), 0), cell(_counts_text(project, lyr), 1)])
    table.setTableContents(rows or [[cell("", 0), cell("", 1)]])
    if ncol > 2 and len(widths) >= 2:          # the Network table had 2 pairs a line: one pair, full width
        table.setColumnWidths([w_ * ncol / 2 for w_ in widths[:2]])
    table.refresh()
    _hide_unless(f, k)
    out = [f]
    if head0 is not None:
        hd = _clone_item(layout, head0)
        if hasattr(hd, "setText"):
            hd.setText("%s TOTALS" % x["title"].upper())
        _hide_unless(hd, k)
        out.append(hd)
    return out, table.totalHeight()


def _fit_sidebar(layout, k, x, legs, box0, rows0, parts, need, tot0, warnings):
    """Size set k's totals. When they need more height than the Network totals box, the set
    gets its own legend box, shorter by the difference (its legend is shorter than the
    Network's), and its totals move up into the space - never over the scale box below.
    Returns True when the set got its own legend box."""
    from qgis.core import QgsLayoutSize, QgsLayoutPoint
    if not parts:
        return False
    sz = tot0.sizeWithUnits()
    delta = max(0.0, need - sz.height())
    if delta > 0.01 and box0 is not None and legs:
        bottom = max(lg.positionWithUnits().y() + _legend_h(lg) for lg in legs)
        bp, bs = box0.positionWithUnits(), box0.sizeWithUnits()
        top = min([r.positionWithUnits().y() for r in rows0] or [bp.y() + bs.height()])
        delta = min(delta, max(0.0, top - bottom - 1.5))
    else:
        delta = 0.0
    own = delta > 0.01
    if own:
        b = _clone_item(layout, box0)
        b.attemptResize(QgsLayoutSize(bs.width(), bs.height() - delta, bs.units()))
        _hide_unless(b, k)
        for r in rows0:
            c = _clone_item(layout, r)
            rp = r.positionWithUnits()
            c.attemptMove(QgsLayoutPoint(rp.x(), rp.y() - delta, rp.units()))
            _hide_unless(c, k)
        for it in parts:
            ip = it.positionWithUnits()
            it.attemptMove(QgsLayoutPoint(ip.x(), ip.y() - delta, ip.units()))
    parts[0].attemptResize(QgsLayoutSize(sz.width(), max(1.0, min(need, sz.height() + delta)), sz.units()))
    if need > sz.height() + delta + 0.01:
        warnings.append("Page set “%s”: its %d layers do not all fit in the totals box - the last "
                        "rows are cut off." % (x["title"], len(x["layers"])))
    return own


def _legend_h(lg):
    """The legend's drawn height (its item keeps the Network legend's frame size)."""
    try:
        from qgis.core import QgsLayoutUtils, QgsLegendRenderer
        ctx = QgsLayoutUtils.createRenderContextForLayout(lg.layout(), None, 300)
        return min(lg.sizeWithUnits().height(),
                   QgsLegendRenderer(lg.model(), lg.legendSettings()).minimumSize(ctx).height())
    except Exception:
        return lg.sizeWithUnits().height()


def _hide_on(item, ks):
    """Hide a Network sidebar item on the pages of sets `ks` (they print their own copy)."""
    from qgis.core import QgsProperty
    expr = "%s IN (%s)" % (AS._SET_NO, ",".join(str(int(k)) for k in ks))
    dd = item.dataDefinedProperties()
    dd.setProperty(_dd("ExcludeFromExports"), QgsProperty.fromExpression(expr))
    dd.setProperty(_dd("Opacity"), QgsProperty.fromExpression("if(%s, 0, 100)" % expr))
    item.setCustomProperty(AS.PROP_SET_NO, 0)
    item.refreshDataDefinedProperty()


def _repin_pictures(project, layout, sets, warnings):
    """Write every page picture's rule again for the new set list. A picture pinned to a set
    page follows its SET (by set id), not the set's position: reorder the sets and it moves
    with its set; remove the set and it stops printing, with a warning. Pins made before the
    sets existed have no set and stay on the Network pages (plan: rules migrated)."""
    try:
        from . import page_pictures as PP
    except ImportError:
        import page_pictures as PP
    before, _m = read_sets(project, layout)            # still the previous list at this point
    before_ids = [x["set_id"] for x in before["sets"]]
    now = {x["set_id"]: k for k, x in enumerate(sets["sets"], start=1)}
    gone = 0
    for it in _items(layout):
        if it.customProperty(PP.ROLE_KEY) != PP.ROLE:
            continue
        try:
            key = json.loads(it.customProperty(PP.PIC_KEY) or "{}")
        except (TypeError, ValueError):
            continue
        if not key:
            continue
        k = int(key.get("set_no") or 0)
        if k:
            sid = key.get("set_id") or (before_ids[k - 1] if 1 <= k <= len(before_ids) else None)
            key["set_id"] = sid
            key["set_no"] = now.get(sid, -1)               # -1: no page has it, it never prints
            gone += key["set_no"] == -1
        PP.pin(it, layout, key)
    if gone:
        warnings.append("%d page picture(s) were pinned to a page set that is gone and no longer "
                        "print (Page pictures… lists them)." % gone)


def _wrapped(orig):
    return AS.title_expression(str(orig).strip()[2:-2].strip())


def apply_sets(project, layout, sets):
    """Write `sets` into the atlas. Returns {"pages", "warnings", "missing"}. Raises SetsRefused
    for a layout it may not change; any other failure restores the layout and re-raises.

    The new set pages are built beside the old ones; the old ones are removed only after every
    step succeeded, so a failure at any point leaves the layout exactly as it was."""
    from qgis.core import (QgsField, QgsFeature, QgsVectorLayer, QgsProperty, QgsLayoutItemLegend,
                           QgsLayoutItemLabel, QgsMapLayer)
    from qgis.PyQt.QtCore import QMetaType
    why = check_layout(project, layout)
    if why:
        raise SetsRefused(why)
    sets = AS.normalise(sets)
    book = book_layer(layout)
    names_by_id = {lid: l.name() for lid, l in project.mapLayers().items()}
    errors, warnings, missing = AS.validate(sets, names_by_id)
    if errors:
        raise SetsRefused("\n".join(errors))
    snap = _snapshot(project, layout)
    old = _old_sets(project, layout)
    _COUNTS.clear()
    try:
        _step("strip")
        net = _network_rows(book)
        n_blocks = AS.check_network_rows(net)
        if not sets["sets"]:
            _repin_pictures(project, layout, sets, warnings)
            _write_json(project, layout, sets)
        else:
            grid = grid_layer(project)
            m = _the_map(layout)
            tree = _tree_order(project)
            rasters = [l.id() for l in m.layers() if l.type() == QgsMapLayer.LayerType.RasterLayer]
            aerial_ids = rasters[:1] or [lid for lid in tree if project.mapLayer(lid).type()
                                         == QgsMapLayer.LayerType.RasterLayer][:1]
            guard = QgsVectorLayer("Point?crs=%s" % book.crs().authid(),
                                   "%sguard_%s" % (AS.NAME_PREFIX, book.id()[-8:]), "memory")
            _private(guard, "guard", book)
            project.addMapLayer(guard, False)
            _step("guard")
            labels_on = _labels_on(project)
            page_ids = {}
            for x in sets["sets"]:
                copies = _make_copies(project, book, x, labels_on, warnings)
                page_ids[x["set_id"]] = AS.set_page_ids(x, labels_on, tree, copies,
                                                        aerial_ids[0] if aerial_ids else "", guard.id(),
                                                        grid.id() if grid else "")
            dp = book.dataProvider()
            if book.fields().indexOf("set_no") < 0:
                dp.addAttributes([QgsField("set_no", QMetaType.Type.Int), QgsField("set_title", QMetaType.Type.QString),
                                  QgsField("page_ids", QMetaType.Type.QString)])
                book.updateFields()
            _step("fields")
            fi = {n: book.fields().indexOf(n) for n in AS.NEW_FIELDS}
            net_feats = [f for f in book.getFeatures() if f.id() not in old[3]]
            dp.changeAttributeValues({f.id(): {fi["set_no"]: 0, fi["set_title"]: "", fi["page_ids"]: ""}
                                      for f in net_feats})
            geom = {int(f["seq"]): f.geometry() for f in net_feats}
            new = []
            for r in AS.expand_rows(net, sets, page_ids):
                if r["set_no"] == 0:
                    continue
                nf = QgsFeature(book.fields())
                nf.setGeometry(geom[AS.network_seq(r["seq"], n_blocks)])
                for key, v in r.items():
                    nf[key] = v
                new.append(nf)
            dp.addFeatures(new)
            book.updateExtents()
            _step("rows")
            m.dataDefinedProperties().setProperty(_dd("MapLayers"),
                                                  QgsProperty.fromExpression(AS.map_layers_expression(guard.name())))
            _step("map")
            title = next((it for it in _items(layout) if isinstance(it, QgsLayoutItemLabel)
                          and it.customProperty(NATIVE_ROLE) == "sheet_title"), None)
            if title is not None:
                orig = title.customProperty(PROP_TITLE_ORIG)
                if orig is None or title.text() != _wrapped(orig):
                    orig = title.text()        # never wrapped, or edited by hand since: the text now
                txt = str(orig).strip()
                if txt.startswith("[%") and txt.endswith("%]") and txt.count("[%") == 1 and txt.count("%]") == 1:
                    title.setCustomProperty(PROP_TITLE_ORIG, orig)
                    title.setText(_wrapped(orig))
                else:
                    title.removeCustomProperty(PROP_TITLE_ORIG)
                    warnings.append("The page title is not one [% … %] expression, so set pages "
                                    "keep the Network title.")
            _step("title")
            mine = [it for it in _items(layout) if not it.customProperty(PROP_OWNED)]
            legends = [it for it in mine if isinstance(it, QgsLayoutItemLegend)]
            tot0 = next((it for it in mine if it.customProperty(NATIVE_ROLE) == "totals"), None)
            head0 = next((it for it in mine if it.customProperty(NATIVE_ROLE) == "totals_heading"), None)
            box0 = next((it for it in mine if it.customProperty(NATIVE_ROLE) == "legend_box"), None)
            rows0 = [it for it in mine if str(it.customProperty(NATIVE_ROLE) or "").startswith("legend_row_")]
            for it in legends + [t for t in (tot0, head0) if t is not None]:
                _hide_unless(it, 0)
            own_box = []
            for k, x in enumerate(sets["sets"], start=1):
                legs = []
                for leg0 in legends:
                    legs.append(_set_legend(project, layout, leg0, k, x))
                    _step("legend")
                if tot0 is not None:
                    parts, need = _set_totals(project, layout, tot0, head0, k, x)
                    if _fit_sidebar(layout, k, x, legs, box0, rows0, parts, need, tot0, warnings):
                        own_box.append(k)
                    _step("totals")
            if own_box:
                for it in [box0] + rows0:
                    _hide_on(it, own_box)
            _repin_pictures(project, layout, sets, warnings)
            _step("pictures")
            _write_json(project, layout, sets)
    except Exception:
        _restore(project, layout, snap)
        raise
    finally:
        _COUNTS.clear()
    try:                                       # the new sets are complete; this only tidies
        _drop_old(project, layout, old)
        if not sets["sets"]:
            _unwrap(layout)
    except Exception as e:
        warnings.append("The previous page sets could not all be removed (%s) - Rebuild the atlas "
                        "if old pages remain." % e)
    layout.atlas().updateFeatures()
    layout.refresh()
    return {"pages": AS.page_count(len(sets["sets"]), n_blocks), "warnings": warnings, "missing": missing}


def missing_report(project, layout):
    """[message] for every ticked layer that no longer exists (exports stop on these)."""
    sets, _msg = read_sets(project, layout)
    book = book_layer(layout)
    if book is None or not sets["sets"]:
        return []
    n_blocks = len(_network_rows(book)) - 1
    names_by_id = {lid: l.name() for lid, l in project.mapLayers().items()}
    _e, _w, missing = AS.validate(sets, names_by_id)
    titles = [x["title"] for x in sets["sets"]]
    return [AS.missing_layer_message(t, AS.name_from_layer_id(lid), titles.index(t) + 1, n_blocks)
            for t, lid in missing]


def _switched_off():
    try:
        from qgis.core import QgsSettings
        return str(QgsSettings().value(AS.SETTING_OFF, "false")).lower() in ("true", "1", "on", "yes")
    except Exception:
        return False


def reapply_after_build(project, layout):
    """After a Rebuild replaced the atlas: write the stored set list into the new layout (the
    project keeps a copy for exactly this). Returns [message] for the operator; [] when there
    is nothing to do. The off switch (vf/hld/atlas_sets_off) skips it: pre-feature output."""
    if layout is None or _switched_off():
        return []
    sets, msg = read_sets(project, layout)
    out = [msg] if msg else []
    if not sets["sets"]:
        return out
    try:
        res = apply_sets(project, layout, sets)
    except SetsRefused as e:
        return out + ["Page sets were not put back: %s" % e]
    except Exception as e:
        return out + ["Page sets were not put back (nothing changed): %s" % e]
    return out + res["warnings"] + missing_report(project, layout)


def export_block(project, layout):
    """The export gate (plan F4), or None. A message for: every ticked layer that was deleted;
    a set list that is stored but not in the atlas pages (its re-apply after a Rebuild failed or
    was refused, so the PDF would hold Network pages only); a ticked layer renamed since into a
    name the map cannot draw. Exports stop on it until fixed or confirmed."""
    try:
        sets, _msg = read_sets(project, layout)
        book = book_layer(layout)
        if book is None or not sets["sets"]:
            return None
        names_by_id = {lid: l.name() for lid, l in project.mapLayers().items()}
        errors, _w, _m = AS.validate(sets, names_by_id)
        msgs = list(errors)
        has_rows = book.fields().indexOf("set_no") >= 0 and any(
            int(_plain(f["set_no"]) or 0) != 0 for f in book.getFeatures())
        if book.featureCount() and not has_rows:     # (an empty book is the rebuild prompt's job)
            msgs.append("This layout has %d page set(s) stored, but the atlas pages do not hold them, "
                        "so the PDF would have the Network pages only. Open Pages… and press OK."
                        % len(sets["sets"]))
        msgs += missing_report(project, layout)
    except Exception:
        return None
    return "\n".join(msgs) if msgs else None


def page_count(layout):
    """The atlas's real page count (F1: never "1 + features" of one coverage layer)."""
    at = layout.atlas()
    at.updateFeatures()
    return at.count()


def sets_json(sets):
    return json.dumps(AS.normalise(sets), indent=1)
