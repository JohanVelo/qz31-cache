"""Check a project against the Velocity planning schema. Read-only, always.

Two halves, deliberately kept apart:

    layer_names.py   WHICH layer is this  (role resolution, every convention)
    schema.yaml      what that role must CONTAIN (fields, types, vocabularies)

Nothing here can write. A `LayerView` exposes a name, a geometry type and a
list of fields — there is no write path at all, so turning a finding into a fix
is a different module's job, and it always writes to a new GeoPackage.

Severity means something specific:

    ERROR  the data is wrong, or a required thing is absent
    WARN   recoverable without judgement — a truncated name, a foldable spelling
    INFO   worth saying, not worth blocking

⛔ `frozen: false` in schema.yaml means the rules rest on two towns. While that
holds, `check()` refuses to report ERROR at all and downgrades everything to
WARN — a gate built on two towns must not block anyone's work. Per JJ's D4 the
validator warns first and is promoted only once it has been seen to fail on a
real defect.
"""
from __future__ import annotations

import os

import yaml

ERROR, WARN, INFO = "ERROR", "WARN", "INFO"

SCHEMA_PATH = os.path.join(os.path.dirname(__file__), "schema.yaml")


def _resolver():
    """layer_names, imported by whichever route this package was loaded under."""
    try:
        from ..network_planner import layer_names            # inside the plugin
    except (ImportError, ValueError):
        try:
            from FiberNetworkAutomation.network_planner import layer_names
        except ImportError:
            import layer_names                               # bare sys.path
    return layer_names


class Finding:
    """One thing to say about one layer. Carries evidence, not just a verdict."""

    __slots__ = ("code", "evidence", "field", "layer", "message", "role", "severity")

    def __init__(self, severity, code, message, role=None, layer=None,
                 field=None, evidence=None):
        self.severity = severity
        self.code = code
        self.message = message
        self.role = role
        self.layer = layer
        self.field = field
        self.evidence = evidence or {}

    def __repr__(self):
        where = self.layer or self.role or "-"
        fld = ".%s" % self.field if self.field else ""
        return "<%s %s %s%s: %s>" % (self.severity, self.code, where, fld,
                                     self.message)


class LayerView:
    """A read-only window onto a layer. No write path, on purpose."""

    __slots__ = ("count", "fields", "geometry", "name", "values")

    def __init__(self, name, fields=(), geometry=None, count=None, values=None):
        self.name = name
        self.fields = list(fields)
        self.geometry = (geometry or "").lower()
        self.count = count
        #: {field name: [sampled values]} — optional. Absent means value checks
        #: are skipped for that field, never that they passed.
        self.values = values or {}


def _canon(role, spec=None):
    """The canonical layer name for ``role`` — the SAME answer mapper uses.

    ⛔ Two modules deciding the canonical name independently is how a validator
    passes a project the writer would then rename, so this delegates to
    `mapper.canonical_name` rather than keeping a second opinion.

    ⛔ It must be imported by the SAME three routes as `_resolver`. A bare
    `from . import mapper` fails whenever the package is loaded by file path —
    which is exactly how the test suite loads it — and the old except-branch then
    fell back to the schema name silently, so the validator and the writer would
    have disagreed for every role the schema does not describe. A fallback that
    hides a disagreement is worse than the ImportError.
    """
    import sys
    mapper = sys.modules.get("mapper")                        # already loaded
    if mapper is None:
        try:
            from . import mapper                              # inside the plugin
        except (ImportError, ValueError):
            try:
                from fibre_automation.velocity_schema import mapper
            except ImportError:
                # Last resort: load the file sitting next to this one. Always
                # correct, however the package was reached — a test that loads
                # `validate` by path and not `mapper` still gets the real answer
                # instead of a quiet fallback to the wrong name.
                import importlib.util
                path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    "mapper.py")
                spec_ = importlib.util.spec_from_file_location("mapper", path)
                mapper = importlib.util.module_from_spec(spec_)
                sys.modules["mapper"] = mapper
                spec_.loader.exec_module(mapper)
    return mapper.canonical_name(role, spec)


def load_schema(path=None):
    with open(path or SCHEMA_PATH, encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def _norm_field(name):
    return " ".join(str(name or "").split()).strip().lower()


def _norm_value(v):
    return " ".join(str(v).split()).strip().lower() if v is not None else None


def _alias_map(schema):
    """{alias -> canonical field name} from truncation + spelling aliases.

    ⛔ `pole_height_alias_watch` is deliberately NOT folded in. Its members
    (`Pole size`, `pole size`, `Height`) hold a pole HEIGHT while sitting next to
    a `Pole Thick` that holds the diameter. Treating them as plain aliases would
    be right; treating them as aliases of THICKNESS would silently turn a height
    into a diameter in the BOQ. They are mapped explicitly below instead.
    """
    out = {}
    for canon, aliases in (schema.get("truncation_aliases") or {}).items():
        for a in aliases:
            out[_norm_field(a)] = canon
        out[_norm_field(canon)] = canon
    for canon, aliases in (schema.get("spelling_aliases") or {}).items():
        if canon == "pole_height_alias_watch":
            for a in aliases:
                out[_norm_field(a)] = "pole_height"
            continue
        for a in aliases:
            out[_norm_field(a)] = canon
        out[_norm_field(canon)] = canon
    return out


def _fold(schema, vocab_name, value):
    """(canonical value, was_folded) for a value in a named vocabulary."""
    vocab = (schema.get("vocabularies") or {}).get(vocab_name)
    if not vocab or value is None:
        return value, False
    nv = _norm_value(value)
    for good in vocab.get("values") or []:
        if _norm_value(good) == nv:
            return good, False
    for good, alts in (vocab.get("equivalents") or {}).items():
        for alt in alts:
            if _norm_value(alt) == nv:
                return good, True
    return value, False


def check(views, schema=None, town=None, project_layer_names=None):
    """Every finding for a set of LayerViews. Never writes, never raises.

    `views` are the layers to judge. `project_layer_names` is every name in the
    project including ones with no view, so the unknown-layer report is complete.
    """
    schema = schema or load_schema()
    ln = _resolver()
    findings = []
    frozen = bool(schema.get("frozen"))

    def add(sev, code, msg, **kw):
        # See the module docstring: an unfrozen schema may not block.
        findings.append(Finding(sev if frozen else (WARN if sev == ERROR else sev),
                                code, msg, **kw))

    aliases = _alias_map(schema)
    by_role = {}
    for v in views:
        role = ln.role_of(v.name, town)
        if role is not None:
            by_role.setdefault(role, []).append(v)

    # ---- 1. unknown layers -------------------------------------------------
    for name in (project_layer_names if project_layer_names is not None
                 else [v.name for v in views]):
        if ln.role_of(name, town) is None and not ln.is_out_of_scope(name, town):
            add(INFO, "layer-unknown",
                "no role for this layer — it will be left untouched, not renamed",
                layer=name)

    for spec in schema.get("layers") or []:
        role = spec["role"]
        hits = by_role.get(role, [])

        # ---- 2. required role absent --------------------------------------
        if not hits:
            if spec.get("required"):
                add(ERROR, "layer-missing",
                    "no layer in the project resolves to this role",
                    role=role, evidence={"expected_name": _canon(role, spec)})
            continue

        # ---- 3. two layers claim one role ---------------------------------
        if len(hits) > 1:
            add(ERROR, "layer-ambiguous",
                "%d layers claim this role, so nothing can safely act on it"
                % len(hits),
                role=role, evidence={"layers": [h.name for h in hits]})

        for view in hits:
            # ---- 4. the name is not the canonical one ----------------------
            if view.name.strip() != _canon(role, spec):
                add(INFO, "layer-name-noncanonical",
                    "resolves correctly but would be renamed to %r" % _canon(role, spec),
                    role=role, layer=view.name)

            present = {_norm_field(f): f for f in view.fields}
            canon_present = {}
            for raw_norm, raw in present.items():
                canon_present.setdefault(aliases.get(raw_norm, raw), raw)

            # ---- 5. required field missing / recoverable -------------------
            for fspec in spec.get("fields") or []:
                fname = fspec["name"]
                actual = canon_present.get(fname)
                if actual is None and _norm_field(fname) in present:
                    actual = present[_norm_field(fname)]
                if actual is None:
                    if fspec.get("required"):
                        add(ERROR, "field-missing",
                            "required field is absent under any known spelling",
                            role=role, layer=view.name, field=fname)
                    continue
                if _norm_field(actual) != _norm_field(fname):
                    add(WARN, "field-name-recoverable",
                        "carried as %r — recoverable, no judgement needed" % actual,
                        role=role, layer=view.name, field=fname,
                        evidence={"found": actual})

                # ---- 6. values outside their vocabulary --------------------
                vocab_name = fspec.get("vocabulary")
                if not vocab_name or actual not in view.values:
                    continue
                vocab = (schema.get("vocabularies") or {}).get(vocab_name) or {}
                for raw in view.values.get(actual) or []:
                    if raw is None:
                        continue
                    folded, was_folded = _fold(schema, vocab_name, raw)
                    if was_folded:
                        add(WARN, "value-spelling",
                            "%r is %r written differently — foldable"
                            % (raw, folded),
                            role=role, layer=view.name, field=fname,
                            evidence={"raw": raw, "canonical": folded})
                    elif _norm_value(folded) not in {
                            _norm_value(x) for x in (vocab.get("values") or [])}:
                        # A value the vocabulary flags as a known WRONG KIND of
                        # thing is its own finding: "7m" in a thickness column is
                        # a height, not a misspelt diameter, and folding it would
                        # turn a pole height into a pole diameter in the BOQ.
                        if _norm_value(raw) in {_norm_value(x) for x in
                                                (vocab.get("suspect") or [])}:
                            add(ERROR, "value-suspect",
                                "%r is listed as suspect for this field — "
                                "reported, never folded" % raw,
                                role=role, layer=view.name, field=fname,
                                evidence={"raw": raw})
                        elif vocab.get("strict"):
                            add(ERROR, "value-outside-vocabulary",
                                "%r is not an allowed value" % raw,
                                role=role, layer=view.name, field=fname,
                                evidence={"raw": raw,
                                          "allowed": vocab.get("values")})
                        else:
                            add(WARN, "value-unrecognised",
                                "%r is not a known value for this field" % raw,
                                role=role, layer=view.name, field=fname,
                                evidence={"raw": raw})

            # ---- 7. geometry -----------------------------------------------
            want = (spec.get("geometry") or "").lower()
            got = view.geometry
            if want and got:
                mp = schema.get("geometry_multipart") or {}
                ok = {want}
                if mp.get("accept_equivalent"):
                    ok |= {x.lower() for x in (mp.get("pairs") or {}).get(want, [])}
                if got not in ok:
                    add(ERROR, "geometry-mismatch",
                        "geometry is %r, expected %r" % (got, want),
                        role=role, layer=view.name)

            # ---- 8. tooling residue ----------------------------------------
            drop = set()
            for group in (schema.get("drop_fields") or {}).values():
                drop |= {_norm_field(x) for x in group}
            junk = sorted(present[n] for n in present if n in drop)
            if junk:
                add(INFO, "field-cruft",
                    "%d tooling field(s) would be dropped" % len(junk),
                    role=role, layer=view.name, evidence={"fields": junk[:12]})

    return findings


def summarise(findings):
    out = {ERROR: 0, WARN: 0, INFO: 0, "by_code": {}}
    for f in findings:
        out[f.severity] = out.get(f.severity, 0) + 1
        out["by_code"][f.code] = out["by_code"].get(f.code, 0) + 1
    out["ok"] = out[ERROR] == 0
    return out


def views_from_ogr(path, town=None):
    """LayerViews for every layer in a GeoPackage or shapefile. Read-only.

    ⛔ osgeo must be imported before anything that pulls in hashlib, or the GDAL
    DLL fails to load with "No module named '_gdal'" — which looks exactly like
    a broken install and is not one.
    """
    from osgeo import ogr
    ogr.UseExceptions()
    GEOM = {1: "point", 2: "linestring", 3: "polygon",
            4: "multipoint", 5: "multilinestring", 6: "multipolygon"}
    ds = ogr.Open(path)
    if ds is None:
        return []
    out = []
    for i in range(ds.GetLayerCount()):
        lyr = ds.GetLayerByIndex(i)
        dfn = lyr.GetLayerDefn()
        names = [dfn.GetFieldDefn(j).GetName() for j in range(dfn.GetFieldCount())]
        values = {n: [] for n in names}
        for k, feat in enumerate(lyr):
            if k >= 500:          # sample; a vocabulary does not need the tail
                break
            for n in names:
                values[n].append(feat.GetField(n))
        out.append(LayerView(lyr.GetName(), names,
                             GEOM.get(lyr.GetGeomType(), ""),
                             lyr.GetFeatureCount(),
                             {n: sorted({v for v in vs if v is not None},
                                        key=str)[:60]
                              for n, vs in values.items()}))
    return out
