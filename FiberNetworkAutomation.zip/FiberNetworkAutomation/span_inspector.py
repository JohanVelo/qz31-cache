"""Span Inspector — dial a max span, see every longer POLE-TO-POLE run light up.

Set the limit (0–100 m). Every span from one pole to the next pole, measured ALONG
the cable, that is longer than the limit glows red on the canvas and STAYS glowing
until you switch it off. Fix a span — move a pole, re-route a cable — and it
un-highlights itself the moment it comes under the limit, so what is still glowing
is exactly what is still wrong.

A span is pole → next pole along the cable geometry. NOT the whole cable, and NOT
vertex-to-vertex: a cable's vertices are not poles (JJ, 2026-07-23). The measurement
lives in `fibre_automation.span_scan`; this module is UI only.

WORKS ON ANY PROJECT. Nothing here is Malmesbury- or PH2-specific: layers are
discovered from whatever project is open, the operator's choices are remembered per
project, and the lists rebuild themselves when the project or its layers change. A
project whose layers are named differently just needs the pole layer picked once.

READ-ONLY. No code path here starts an edit session or writes a feature, so it is
safe on live Mohadin PH2 / Malmesbury (write-off-limits). The highlight is a
QgsRubberBand — a canvas overlay, not a layer: nothing is added to the Layers panel
and nothing is written to disk.

Live re-check is SIGNAL-DRIVEN, never a polling loop. Edit signals on the cable
layers AND the pole layer arm a single-shot debounce; nothing ticks while you are
not editing.

Styling follows the live Velocity Nexus theme (`VelocityFibre/panel_theme`) using the
same colour keys as the home panel, so a theme switch restyles this panel too.
Semantic colours (ok/warn/bad) come from `theme_safe`, which contrast-checks against
the real background — hardcoding them is a bug class that has broken light mode here
before.
"""
from qgis.PyQt import sip
from qgis.PyQt.QtCore import QPointF, QRectF, QSize, Qt, QTimer
from qgis.PyQt.QtGui import QColor, QIcon, QPainter, QPen, QPixmap
from qgis.PyQt.QtWidgets import (
    QAbstractButton, QAbstractItemView, QAbstractSpinBox, QCheckBox, QComboBox, QDockWidget,
    QDoubleSpinBox, QFormLayout, QFrame, QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QPushButton,
    QScrollArea, QSizePolicy, QSlider, QSpinBox, QVBoxLayout, QWidget)
from qgis.core import QgsGeometry, QgsProject, QgsSettings, QgsWkbTypes
from qgis.gui import QgsRubberBand

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

try:
    from . import theme_safe
except ImportError:
    import theme_safe

try:                                     # bundled copy inside the installed plugin
    from .fibre_automation import span_scan
except ImportError:                      # workspace / dev checkout
    from fibre_automation import span_scan

_CABLE_HINTS = ("cable", "feeder", "span", "drop", "distribution", "primary",
                "secondary", "backhaul", "kabel")
_DEBOUNCE_MS = 250
_HL_COLOR = QColor(255, 45, 45)
_HL_WIDTH = 6
_EDIT_SIGNALS = ("geometryChanged", "featureAdded", "featuresDeleted",
                 "editCommandEnded", "afterCommitChanges", "afterRollBack")
_SETTINGS_ROOT = "VelocityFibre/span_inspector"

# Fallback theme — used only if the home panel's THEMES cannot be imported, so the
# panel is never unstyled.
_FALLBACK_THEME = {
    "bg": "#05070C", "step_bg": "#0D1320", "step_border": "#1E2A3D",
    "step_hi": "#1AE5FF", "section": "#7E93B8", "title": "#EAF3FF",
    "sub": "#9DB0CC", "word_bot": "#1AE5FF", "tool_bg": "#111A2B",
    "tool_text": "#C7D6EE", "tool_hover": "#16223A",
    "accent": "qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #1AE5FF, stop:1 #1AA6FF)",
    "badge_text": "#05070C",
}


def _alive(obj):
    """True if a Qt object is still usable — guards the deleted-C++ crash class."""
    if obj is None:
        return False
    try:
        return not sip.isdeleted(obj)
    except Exception:
        return True


def _theme():
    """The live Nexus theme dict. Falls back so a missing key can't break the UI."""
    try:
        try:
            from .velocity_home_panel import THEMES
        except ImportError:
            from velocity_home_panel import THEMES
        name = QgsSettings().value("VelocityFibre/panel_theme", "velocity")
        c = dict(THEMES.get(name) or THEMES.get("velocity") or {})
    except Exception:
        c = {}
    for k, v in _FALLBACK_THEME.items():
        c.setdefault(k, v)
    return c


def _project_key():
    """Stable per-project settings key (falls back to the name for unsaved projects)."""
    proj = QgsProject.instance()
    return (proj.fileName() or proj.baseName() or "unsaved").replace("/", "_") \
        .replace("\\", "_").replace(":", "")


def _build_qss(c, sem):
    """Panel stylesheet from the live theme + contrast-checked semantic colours."""
    return f"""
#vfSpanRoot {{ background:{c['bg']}; }}
#vfSpanRoot QLabel {{ color:{c['sub']}; }}
#vfSpanTitle {{ color:{c['title']}; font-size:15px; font-weight:800;
                letter-spacing:0.4px; }}
#vfSpanSub {{ color:{c['sub']}; font-size:11px; }}
#vfSpanSection {{ color:{c['section']}; font-size:10px; font-weight:700;
                letter-spacing:2px;
                font-family:'JetBrains Mono','Consolas','DejaVu Sans Mono',monospace;
                border-top:1px solid {c['step_border']}; padding-top:9px; }}
#vfSpanBeta {{ color:{sem['warn']}; font-size:10px; font-weight:700;
               letter-spacing:0.6px; border:1px solid {sem['warn']};
               border-radius:4px; padding:3px 7px; }}
QFrame#vfSpanCard {{ background:{c['step_bg']}; border:1px solid {c['step_border']};
                     border-radius:8px; }}
QFrame#vfSpanCard QLabel {{ border:none; }}
#vfSpanReadout {{ color:{c['word_bot']}; font-size:30px; font-weight:800;
                  letter-spacing:1px; }}
#vfSpanHint {{ color:{c['section']}; font-size:9px; font-weight:600;
               letter-spacing:1px;
               font-family:'JetBrains Mono','Consolas','DejaVu Sans Mono',monospace; }}
QSlider#vfSpanSlider::groove:horizontal {{ height:6px; border-radius:3px;
                                           background:{c['step_border']}; }}
QSlider#vfSpanSlider::sub-page:horizontal {{ background:{c['accent']};
                                             border-radius:3px; }}
QSlider#vfSpanSlider::handle:horizontal {{ background:{c['title']};
    border:2px solid {c['step_hi']}; width:14px; height:14px; margin:-6px 0;
    border-radius:8px; }}
QSpinBox#vfSpanSpin {{ background:{c['tool_bg']}; color:{c['title']};
    border:1px solid {c['step_border']}; border-radius:6px; padding:4px 6px;
    font-weight:700; }}
QComboBox#vfSpanCombo {{ background:{c['tool_bg']}; color:{c['tool_text']};
    border:1px solid {c['step_border']}; border-radius:6px; padding:5px 8px; }}
QComboBox#vfSpanCombo::drop-down {{ border:none; width:18px; }}
#vfSpanRoot QCheckBox {{ color:{c['tool_text']}; padding:2px 0; }}
QPushButton#vfSpanGo {{ background:{c['tool_bg']}; color:{c['title']};
    border:1px solid {c['step_border']}; border-radius:8px; padding:10px 12px;
    font-weight:800; letter-spacing:0.5px; }}
QPushButton#vfSpanGo:hover {{ background:{c['tool_hover']};
                              border:1px solid {c['step_hi']}; }}
QPushButton#vfSpanGo:checked {{ background:{sem['bad']}; color:#FFFFFF;
                                border:1px solid {sem['bad']}; }}
QPushButton#vfSpanMini {{ background:{c['tool_bg']}; color:{c['tool_text']};
    border:1px solid {c['step_border']}; border-radius:7px; padding:7px 10px;
    font-size:11px; font-weight:700; }}
QPushButton#vfSpanMini:hover {{ background:{c['tool_hover']};
                                border:1px solid {c['step_hi']}; }}
QPushButton#vfSpanMini:disabled {{ color:{c['section']}; }}
QListWidget#vfSpanList {{ background:{c['step_bg']}; color:{c['tool_text']};
    border:1px solid {c['step_border']}; border-radius:8px; padding:3px;
    font-family:'JetBrains Mono','Consolas','DejaVu Sans Mono',monospace;
    font-size:11px; }}
QListWidget#vfSpanList::item {{ padding:4px 6px; border-radius:5px; }}
QListWidget#vfSpanList::item:hover {{ background:{c['tool_hover']}; }}
QListWidget#vfSpanList::item:selected {{ background:{c['step_hi']};
                                         color:{c['badge_text']}; }}
QScrollArea#vfSpanScroll {{ border:none; background:transparent; }}
"""


# ── LIVE ON THE MAP (D18/D19) ───────────────────────────────────────────────
# The live tools (Live Measure, Group counter, Drop counter, Drop lengths, PON groups)
# live in live_measure.py; this section only shows them. Read-only like the rest.
_LIVE_KEYS = ("live", "group", "drops", "lengths", "pons")
_LIVE_NEXT = {"drops": "Next pole", "lengths": "Next red drop", "pons": "Next PON"}
_LIVE_NEXT_TIP = {"drops": "Zoom to the next pole with more drops than the max",
                  "lengths": "Zoom to the next drop longer than the red limit (longest first)",
                  "pons": "Zoom to the next PON with more drop groups than the limit"}


def _live_disabled():
    """Kill switch: env VF_NO_LIVE_MEASURE=1 or QgsSettings VelocityFibre/live_measure/disabled."""
    import os
    if os.environ.get("VF_NO_LIVE_MEASURE", "").strip() == "1":
        return True
    v = QgsSettings().value("VelocityFibre/live_measure/disabled", False)
    return str(v).strip().lower() in ("1", "true", "yes")


def _import_live_measure():
    """Lazy import; None when unavailable (the rest of the panel keeps working)."""
    if "live_import" in _LIVE_INJECT:
        raise ImportError("injected: live_measure unavailable")
    try:
        from . import live_measure as lm
    except ImportError:
        import live_measure as lm
    return lm


_LIVE_INJECT = set()   # test seam (fault injection names)


def _live_safe(fn):
    """Panel slots of the live section: log + one message, never raise into Qt."""
    import functools
    import traceback

    @functools.wraps(fn)
    def wrapper(self, *args):
        try:
            if "si." + fn.__name__ in _LIVE_INJECT:
                raise RuntimeError("injected fault: si." + fn.__name__)
            return fn(self, *args)
        except Exception:  # noqa: BLE001
            try:
                from qgis.core import Qgis, QgsMessageLog
                QgsMessageLog.logMessage(traceback.format_exc(), "Velocity Measure", Qgis.MessageLevel.Warning)
            except Exception:  # noqa: BLE001
                pass
            try:
                self._live_message("That live-tool action failed. Details are in the Log Messages panel.")
            except Exception:  # noqa: BLE001
                pass
            try:
                self._resync_switches()
            except Exception:  # noqa: BLE001
                pass
            return None
    return wrapper


def _narrow(combo):
    """A combo that never widens the dock: it shows what fits and elides the rest."""
    combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
    combo.setMinimumContentsLength(8)
    combo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
    return combo


def _keep_pairs(text):
    """'485 orange' -> '485<nbsp>orange': a number never wraps away from its word."""
    parts = text.split(" · ")
    # a short fact never breaks inside ("6 outside any PON"); a sentence may still wrap
    return " · ".join(p.replace(" ", "\u00a0") if len(p) <= 24 else p for p in parts)


def _solid(c, key, fallback):
    """A theme colour that QColor can paint (some theme keys are gradient strings)."""
    v = c.get(key, fallback)
    col = QColor(v) if isinstance(v, str) and not v.startswith("qlineargradient") else QColor()
    return col if col.isValid() else QColor(fallback)


class _Switch(QAbstractButton):
    """A small on/off switch painted in the theme's highlight colour."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.on_col, self.off_col, self.knob_col, self.edge_col = (
            QColor("#1AE5FF"), QColor("#1A2537"), QColor("#EAF3FF"), QColor("#24344C"))

    def sizeHint(self):  # noqa: N802
        return QSize(38, 20)

    def paintEvent(self, event):  # noqa: N802
        try:
            p = QPainter(self)
            try:
                p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
                r = QRectF(1, 1, self.width() - 2, self.height() - 2)
                on = self.isChecked()
                track = QColor(self.on_col) if on else QColor(self.off_col)
                if on:
                    track.setAlpha(90)
                if not self.isEnabled():
                    track.setAlpha(60)
                p.setPen(QPen(self.on_col if on else self.edge_col, 1.2))
                p.setBrush(track)
                p.drawRoundedRect(r, r.height() / 2, r.height() / 2)
                d = r.height() - 6
                x = r.right() - d - 3 if on else r.left() + 3
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(self.on_col if on else self.knob_col)
                p.drawEllipse(QRectF(x, r.top() + 3, d, d))
                if self.hasFocus():
                    p.setPen(QPen(self.on_col, 1, Qt.PenStyle.DotLine))
                    p.setBrush(Qt.BrushStyle.NoBrush)
                    p.drawRoundedRect(r.adjusted(-0.5, -0.5, 0.5, 0.5), r.height() / 2, r.height() / 2)
            finally:
                p.end()
        except Exception:  # noqa: BLE001
            _swallowed_note()


class _SplitBar(QWidget):
    """Green / orange / red proportion bar under the Drop lengths row."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.parts = (0, 0, 0)
        self.track = QColor("#1A2537")
        self.setFixedHeight(5)

    def paintEvent(self, event):  # noqa: N802
        try:
            p = QPainter(self)
            try:
                p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(self.track)
                p.drawRoundedRect(QRectF(0, 0, self.width(), self.height()), 2.5, 2.5)
                tot = float(sum(self.parts)) or 1.0
                x = 0.0
                for n, col in zip(self.parts, ("#1FA34A", "#F08A00", "#E01E1E")):
                    w = self.width() * n / tot
                    if w > 0:
                        p.setBrush(QColor(col))
                        p.drawRect(QRectF(x, 0, max(w, 2.0 if n else 0.0), self.height()))
                    x += w
            finally:
                p.end()
        except Exception:  # noqa: BLE001
            _swallowed_note()


def _gear(colour, size=16):
    """A small drawn gear (no font glyph needed)."""
    import math
    pm = QPixmap(size, size)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    try:
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        c = QPointF(size / 2.0, size / 2.0)
        p.setPen(QPen(colour, 2.2, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        for i in range(8):
            a = i * math.pi / 4
            p.drawLine(QPointF(c.x() + math.cos(a) * size * 0.30, c.y() + math.sin(a) * size * 0.30),
                       QPointF(c.x() + math.cos(a) * size * 0.44, c.y() + math.sin(a) * size * 0.44))
        p.setPen(QPen(colour, 1.8))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(c, size * 0.27, size * 0.27)
        p.drawEllipse(c, size * 0.10, size * 0.10)
    finally:
        p.end()
    return pm


def _glyph(key, colour, size=22):
    """Small drawn icon per tool (no emoji)."""
    pm = QPixmap(size, size)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    try:
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setPen(QPen(colour, 1.6, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        p.setBrush(Qt.BrushStyle.NoBrush)
        s = size / 24.0
        if key == "live":
            p.drawLine(QPointF(3 * s, 17 * s), QPointF(21 * s, 7 * s))
            for i in range(4):
                x, y = (5 + 4 * i) * s, (15.9 - 2.2 * i) * s
                p.drawLine(QPointF(x, y), QPointF(x + 1.5 * s, y + 2.5 * s))
        elif key == "group":
            # a drawn area (pentagon) with three homes inside, like the map tool
            poly = [QPointF(12 * s, 3 * s), QPointF(21 * s, 9.5 * s), QPointF(17.5 * s, 20 * s),
                    QPointF(6.5 * s, 20 * s), QPointF(3 * s, 9.5 * s)]
            p.drawPolygon(poly)
            p.setBrush(colour)
            for x, y in ((9.5, 11), (14.5, 11), (12, 15.5)):
                p.drawEllipse(QPointF(x * s, y * s), 1.3 * s, 1.3 * s)
            p.setBrush(Qt.BrushStyle.NoBrush)
        elif key == "drops":
            p.drawEllipse(QPointF(12 * s, 12 * s), 3.2 * s, 3.2 * s)
            for x, y in ((12, 3), (20, 17), (4, 17), (20, 7)):
                p.drawLine(QPointF(12 * s, 12 * s), QPointF(x * s, y * s))
        elif key == "lengths":
            p.drawLine(QPointF(3 * s, 19 * s), QPointF(9 * s, 13 * s))
            p.drawLine(QPointF(10 * s, 12 * s), QPointF(15 * s, 7 * s))
            p.drawLine(QPointF(16 * s, 6 * s), QPointF(21 * s, 3 * s))
        elif key == "pons":
            p.drawRect(QRectF(3 * s, 4 * s, 18 * s, 16 * s))
            p.drawEllipse(QPointF(12 * s, 12 * s), 4.2 * s, 4.2 * s)
    finally:
        p.end()
    return pm


class _LiveRow(QFrame):
    """One tool: icon · name · status · switch, then (optional) Next, bar and inline settings."""

    def __init__(self, panel, key, title):
        super().__init__()
        self.setObjectName("vfLiveRow")
        self.panel, self.key = panel, key
        v = QVBoxLayout(self)
        v.setContentsMargins(8, 8, 8, 8)   # 8 px sides: the section never widens the dock (AC-H7)
        v.setSpacing(4)
        top = QHBoxLayout()
        top.setSpacing(7)
        self.icon = QLabel()
        self.icon.setObjectName("vfLiveIcon")
        self.icon.setFixedSize(22, 22)
        top.addWidget(self.icon, 0, Qt.AlignmentFlag.AlignTop)
        self.name = QLabel(title)
        self.name.setObjectName("vfLiveName")
        top.addWidget(self.name, 1, Qt.AlignmentFlag.AlignVCenter)
        self.more = QPushButton()
        self.more.setObjectName("vfLiveMore")
        self.more.setCheckable(True)
        self.more.setCursor(Qt.CursorShape.PointingHandCursor)
        self.more.setToolTip("Settings")
        self.more.setAccessibleName(title + " settings")
        self.more.setFixedSize(30, 22)
        top.addWidget(self.more, 0, Qt.AlignmentFlag.AlignVCenter)
        self.switch = _Switch()
        self.switch.setObjectName("vfLiveSwitch_" + key)
        self.switch.setAccessibleName(title + " on/off")
        top.addWidget(self.switch, 0, Qt.AlignmentFlag.AlignVCenter)
        v.addLayout(top)
        # the status gets the full row width, so counts never wrap away from their words
        self.status = QLabel("")
        self.status.setObjectName("vfLiveStatus")
        self.status.setWordWrap(True)
        self.status.setContentsMargins(31, 0, 0, 0)
        v.addWidget(self.status)
        self.bar = None
        if key == "lengths":
            self.bar = _SplitBar()
            v.addWidget(self.bar)
        self.next_btn = None
        self.next_lbl = None
        if key in _LIVE_NEXT:
            nr = QHBoxLayout()
            nr.setContentsMargins(31, 0, 0, 0)
            self.next_btn = QPushButton(_LIVE_NEXT[key] + "  >")
            self.next_btn.setObjectName("vfLiveNext")
            self.next_btn.setToolTip(_LIVE_NEXT_TIP[key])
            self.next_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            nr.addWidget(self.next_btn)
            self.next_lbl = QLabel("")
            self.next_lbl.setObjectName("vfLiveHint")
            # never sets the dock's minimum width: it shrinks (elides) before the dock grows
            self.next_lbl.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
            self.next_lbl.setMinimumWidth(0)
            nr.addWidget(self.next_lbl, 1)
            v.addLayout(nr)
        self.settings = QWidget()
        self.settings.setObjectName("vfLiveSettings")
        self.form = QFormLayout(self.settings)
        self.form.setContentsMargins(31, 4, 0, 2)
        self.form.setSpacing(5)
        self.form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)   # narrow dock: label above field
        self.settings.setVisible(False)
        v.addWidget(self.settings)
        self.more.toggled.connect(self.settings.setVisible)
        self.more.toggled.connect(lambda _on: panel._live._run(panel._live.restyle, _theme()))


class _LiveSection(QWidget):
    """The LIVE ON THE MAP card. Owns the live tools controller while the panel is open."""

    def __init__(self, panel):
        super().__init__()
        self.panel = panel
        self.lm = None
        self.ctrl = None
        self.rows = {}
        self._pending_status = set()
        self._status_timer = QTimer(self)
        self._status_timer.setSingleShot(True)
        self._status_timer.setInterval(60)
        self._status_timer.timeout.connect(self._flush_status)
        self._editors = {}
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(6)
        self.note = QLabel("")
        self.note.setObjectName("vfLiveNote")
        self.note.setWordWrap(True)
        self.note.setVisible(False)
        v.addWidget(self.note)
        self.box = QFrame()
        self.box.setObjectName("vfSpanCard")
        self.box_v = QVBoxLayout(self.box)
        self.box_v.setContentsMargins(6, 6, 6, 6)
        self.box_v.setSpacing(5)
        v.addWidget(self.box)

    # lifecycle -------------------------------------------------------------
    def start(self):
        """Create (or re-create) the controller and the rows. Safe to call twice."""
        if self.ctrl is not None:
            return True
        try:
            self.lm = _import_live_measure()
        except Exception:  # noqa: BLE001 - import failure: the rest of the panel keeps working
            self.lm = None
            self.box.setVisible(False)
            self.note.setText("Live tools unavailable on this QGIS.")
            self.note.setVisible(True)
            return False
        try:
            if "si.controller" in _LIVE_INJECT:
                raise RuntimeError("injected fault: controller")
            self.ctrl = self.lm.install(self.panel.iface)
        except Exception:  # noqa: BLE001
            self.ctrl = None
            self._teardown_rows()
            self.box.setVisible(False)
            self.note.setText("Live tools unavailable on this QGIS.")
            self.note.setVisible(True)
            _swallowed_note()
            return False
        if self.ctrl is None:   # kill switch inside live_measure
            self.box.setVisible(False)
            return False
        try:
            self._build_rows()
        except Exception:  # noqa: BLE001 - a half-built section is torn down, the panel stays
            self.live_teardown()
            self.box.setVisible(False)
            self.note.setText("Live tools unavailable on this QGIS.")
            self.note.setVisible(True)
            _swallowed_note()
            return False
        self.note.setVisible(False)
        self.box.setVisible(True)
        self.ctrl.statusChanged.connect(self._on_status)
        self.ctrl.set_panel_visible(self.panel.isVisible())
        self.refresh_all()
        return True

    def live_teardown(self):
        """Switch every live tool off and drop the controller. Only close/unload call this."""
        ctrl, self.ctrl = self.ctrl, None
        try:
            self._status_timer.stop()
        except Exception:  # noqa: BLE001
            _swallowed_note()
        if ctrl is not None:
            try:
                ctrl.statusChanged.disconnect(self._on_status)
            except (TypeError, RuntimeError):
                pass
            try:
                if self.lm is not None and self.lm.current_host() is ctrl:
                    self.lm.uninstall()
                else:
                    ctrl.teardown()
            except Exception:  # noqa: BLE001
                _swallowed_note()
        self._teardown_rows()

    def _teardown_rows(self):
        for row in list(self.rows.values()):
            try:
                row.setParent(None)
                row.deleteLater()
            except Exception:  # noqa: BLE001
                _swallowed_note()
        self.rows = {}
        self._editors = {}

    # rows --------------------------------------------------------------------
    def _build_rows(self):
        names = self.lm.TOOL_NAMES
        for i, key in enumerate(_LIVE_KEYS):
            if "si.half_build" in _LIVE_INJECT and i == 2:
                raise RuntimeError("injected fault: half-built section")
            row = _LiveRow(self.panel, key, names[key])
            act = self.ctrl.actions[key]
            row.switch.setChecked(act.isChecked())
            row.switch.setEnabled(act.isEnabled())
            row.switch.setToolTip(act.toolTip())
            row.switch.toggled.connect(lambda on, k=key: self._on_switch(k, on))
            act.toggled.connect(lambda on, k=key: self._sync_switch(k, on))
            if row.next_btn is not None:
                row.next_btn.clicked.connect(lambda _c=False, k=key: self._on_next(k))
            self._build_settings(key, row)
            self.box_v.addWidget(row)
            self.rows[key] = row
        self.restyle(_theme())

    def _num(self, row, key, label, opt, default, lo, hi, decimals=0, step=1.0):
        w = QDoubleSpinBox() if decimals else QSpinBox()
        w.setObjectName("vfLiveSpin")
        w.setRange(lo, hi)
        if decimals:
            w.setDecimals(decimals)
            w.setSingleStep(step)
        try:
            val = float(self.ctrl.option(opt, default))
        except (TypeError, ValueError):
            val = default
        w.setValue(val if decimals else int(val))
        w.setKeyboardTracking(False)
        w.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.NoButtons)
        w.valueChanged.connect(lambda v, o=opt: self._set(o, v))
        row.form.addRow(label, w)
        self._editors[(key, opt)] = w
        return w

    def _layer_combo(self, row, key, label, opt, geom, auto_text):
        w = _narrow(QComboBox())
        w.setObjectName("vfSpanCombo")
        w.setProperty("_geom", geom)
        w.setProperty("_auto", auto_text)
        self._fill_layer_combo(w, opt)
        w.activated.connect(lambda _i, o=opt, cb=w: self._run(lambda: self._set(o, cb.currentData() or "")))
        row.form.addRow(label, w)
        self._editors[(key, opt)] = w
        return w

    def _fill_layer_combo(self, w, opt):
        from qgis.core import Qgis, QgsVectorLayer
        geom = {"point": Qgis.GeometryType.Point, "line": Qgis.GeometryType.Line,
                "polygon": Qgis.GeometryType.Polygon}[w.property("_geom")]
        cur = str(self.ctrl.option(opt, "") or "")
        w.blockSignals(True)
        try:
            w.clear()
            w.addItem(w.property("_auto"), "")
            for lyr in sorted(QgsProject.instance().mapLayers().values(), key=lambda x: x.name().lower()):
                if isinstance(lyr, QgsVectorLayer) and lyr.geometryType() == geom:
                    w.addItem("%s   (%d)" % (lyr.name(), lyr.featureCount()), lyr.id())
            i = w.findData(cur)
            w.setCurrentIndex(i if i >= 0 else 0)
        finally:
            w.blockSignals(False)

    def _build_settings(self, key, row):
        if key == "live":
            w = _narrow(QComboBox())
            w.setObjectName("vfSpanCombo")
            for text, val in (("Auto (drops 50 m, others 70 m)", "auto"), ("50 m", "50"), ("70 m", "70"),
                              ("90 m", "90"), ("Custom", "custom")):
                w.addItem(text, val)
            cur = str(self.ctrl.option("span_limit", "auto"))
            i = w.findData(cur)
            w.setCurrentIndex(i if i >= 0 else 4)
            row.form.addRow("Span limit", w)
            self._editors[(key, "span_limit")] = w
            custom = QDoubleSpinBox()
            custom.setObjectName("vfLiveSpin")
            custom.setRange(1, 1000)
            custom.setDecimals(1)
            custom.setSuffix(" m")
            custom.setKeyboardTracking(False)
            custom.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.NoButtons)
            try:
                custom.setValue(float(cur))
            except ValueError:
                custom.setValue(70.0)
            custom.setEnabled(w.currentData() == "custom")
            row.form.addRow("Custom limit", custom)
            self._editors[(key, "span_limit_custom")] = custom

            def on_mode(_i, cb=w, sp=custom):
                v = cb.currentData()
                sp.setEnabled(v == "custom")
                self._set("span_limit", "%g" % sp.value() if v == "custom" else v)
            w.activated.connect(lambda i: self._run(on_mode, i))
            custom.valueChanged.connect(lambda v, cb=w: self._run(
                lambda: cb.currentData() == "custom" and self._set("span_limit", "%g" % v)))
        elif key == "group":
            w = _narrow(QComboBox())
            w.setObjectName("vfSpanCombo")
            for text, val in (("PON homes", "pon"), ("STS drops", "sts"), ("FTS (STS points)", "fts")):
                w.addItem(text, val)
            i = w.findData(str(self.ctrl.option("mode", "sts")))
            w.setCurrentIndex(i if i >= 0 else 1)
            w.activated.connect(lambda _i, cb=w: self._run(lambda: self._set("mode", cb.currentData())))
            row.form.addRow("Count", w)
            self._editors[(key, "mode")] = w
            self._layer_combo(row, key, "Homes layer", "point_layer_id", "point", "Auto (Demand points)")
            self._layer_combo(row, key, "STS layer", "sts_layer_id", "point", "Choose for FTS mode")
            self._num(row, key, "PON low", "pon_low", 94, 1, 10000)
            self._num(row, key, "PON high", "pon_high", 102, 1, 10000)
            self._num(row, key, "PON cap", "pon_cap", 128, 1, 10000)
            self._num(row, key, "STS max", "sts_max", 16, 1, 10000)
            self._num(row, key, "FTS max", "fts_max", 8, 1, 10000)
        elif key == "drops":
            self._num(row, key, "Max drops per pole", "drop_max", 8, 1, 1000)
            em = _narrow(QComboBox())
            em.setObjectName("vfSpanCombo")
            em.setToolTip("While the Vertex tool or another edit tool is active (all live overlays)")
            for text, val in (("Fade under QGIS", "fade"), ("Hide", "hide"), ("Keep on top", "top")):
                em.addItem(text, val)
            i = em.findData(str(self.ctrl.option("edit_mode", "fade")))
            em.setCurrentIndex(i if i >= 0 else 0)
            em.activated.connect(lambda _i, cb=em: self._run(lambda: self._set("edit_mode", cb.currentData())))
            row.form.addRow("While editing", em)
            self._editors[(key, "edit_mode")] = em
            self._layer_combo(row, key, "Drop layer", "drop_layer_id", "line", "Auto (largest 'drop' layer)")
            sp = QCheckBox("Count Spare Drop too")
            sp.setChecked(str(self.ctrl.option("include_spare", "false")).lower() in ("true", "1"))
            sp.toggled.connect(lambda on: self._set("include_spare", "true" if on else "false"))
            row.form.addRow("", sp)
            self._editors[(key, "include_spare")] = sp
            self._num(row, key, "Join radius (m)", "join_radius", 0.5, 0.1, 5.0, decimals=2, step=0.1)
            rc = QPushButton("Recount now")
            rc.setObjectName("vfLiveAction")
            rc.clicked.connect(lambda _c=False: self._recount())
            row.form.addRow("", rc)
            self._editors[(key, "recount")] = rc
        elif key == "lengths":
            self._num(row, key, "Orange from (m)", "len_orange", 40.0, 1, 1000, decimals=1)
            self._num(row, key, "Red above (m)", "len_red", 50.0, 1, 1000, decimals=1)
            rc = QPushButton("Recount now")
            rc.setObjectName("vfLiveAction")
            rc.clicked.connect(lambda _c=False: self._recount())
            row.form.addRow("", rc)
            self._editors[(key, "recount")] = rc
        elif key == "pons":
            self._layer_combo(row, key, "PON layer", "pon_layer_id", "polygon", "Auto (layer named 'PON')")
            self._num(row, key, "Groups per PON (limit)", "pon_group_limit", 16, 1, 1000)

    def refresh_layer_combos(self):
        if self.ctrl is None:
            return
        for (key, opt), w in self._editors.items():
            if isinstance(w, QComboBox) and w.property("_geom"):
                self._fill_layer_combo(w, opt)

    # slots -------------------------------------------------------------------
    def _live_message(self, text):
        try:
            self.panel.iface.messageBar().pushMessage("Velocity Measure", text, Qgis_Warning(), 8)
        except Exception:  # noqa: BLE001
            _swallowed_note()

    @_live_safe
    def _run(self, fn, *args):
        """Every lambda the section connects to Qt goes through here: nothing reaches Qt."""
        return fn(*args)

    @_live_safe
    def _on_switch(self, key, on):
        if self.ctrl is not None:
            self.ctrl.set_on(key, on)
            self._sync_switch(key, self.ctrl.is_on(key) or self.ctrl.actions[key].isChecked())

    @_live_safe
    def _sync_switch(self, key, on):
        row = self.rows.get(key)
        if row is not None and _alive(row.switch) and row.switch.isChecked() != bool(on):
            row.switch.blockSignals(True)
            row.switch.setChecked(bool(on))
            row.switch.blockSignals(False)
            row.switch.update()
        self._queue(key)

    @_live_safe
    def _on_next(self, key):
        if self.ctrl is None:
            return
        i, n = self.ctrl.next_problem(key) or (0, 0)
        row = self.rows.get(key)
        if row is not None and row.next_lbl is not None:
            row.next_lbl.setProperty("nav", bool(n))
            row.next_lbl.setText("%d of %d" % (i, n) if n else "none")

    @_live_safe
    def _set(self, opt, value):
        if self.ctrl is not None:
            self.ctrl.set_option(opt, value)
            self._queue_all()

    @_live_safe
    def _recount(self):
        if self.ctrl is not None:
            self.ctrl._recount()

    def _none_text(self, key):
        """'none over 8' - says none of WHAT, with the live limit."""
        t = self.ctrl.tools.get(key) if self.ctrl is not None else None
        try:
            if key == "drops":
                return "none over %d" % t.sts_max()
            if key == "lengths":
                return "none over %g m" % t.thresholds()[1]
            if key == "pons":
                return "none over %d" % t.limit()
        except Exception:  # noqa: BLE001
            _swallowed_note()
        return "none"

    def _resync_switches(self):
        """Every switch shows its tool's real state (after a fault in a panel slot)."""
        for key, row in self.rows.items():
            on = self.ctrl is not None and self.ctrl.is_on(key)
            if _alive(row.switch) and row.switch.isChecked() != on:
                row.switch.blockSignals(True)
                row.switch.setChecked(on)
                row.switch.blockSignals(False)
                row.switch.update()

    def _on_status(self, key):
        self._queue(key)

    def _queue(self, key):
        self._pending_status.add(key)
        if _alive(self._status_timer) and not self._status_timer.isActive():
            self._status_timer.start()

    def _queue_all(self):
        for k in _LIVE_KEYS:
            self._queue(k)

    @_live_safe
    def _flush_status(self):
        keys, self._pending_status = self._pending_status, set()
        for k in keys:
            self._refresh_row(k)

    def refresh_all(self):
        for k in _LIVE_KEYS:
            self._refresh_row(k)

    def _refresh_row(self, key):
        row = self.rows.get(key)
        if row is None or self.ctrl is None or not _alive(row):
            return
        text = self.ctrl.status_text(key)
        row.status.setText(_keep_pairs(text))
        warn = "true" if text.startswith("No ") else "false"
        if row.status.property("warn") != warn:
            row.status.setProperty("warn", warn)
            row.status.style().unpolish(row.status)
            row.status.style().polish(row.status)
        on = self.ctrl.is_on(key)
        if row.switch.isChecked() != on:   # automatic off paths (fault, layer gone) uncheck silently
            row.switch.blockSignals(True)
            row.switch.setChecked(on)
            row.switch.blockSignals(False)
            row.switch.update()
        row.setProperty("on", "true" if on else "false")
        row.style().unpolish(row)
        row.style().polish(row)
        if row.bar is not None:
            t = self.ctrl.tools.get("lengths")
            if t is not None and on:
                c = t.counts
                row.bar.parts = (c.get("green", 0), c.get("amber", 0), c.get("red", 0))
            else:
                row.bar.parts = (0, 0, 0)
            row.bar.setVisible(on)
            row.bar.update()
        if row.next_btn is not None:
            t = self.ctrl.tools.get(key)
            n = len(t.next_targets()) if (t is not None and on) else 0
            row.next_btn.setEnabled(bool(n))
            row.next_btn.setVisible(on)
            row.next_lbl.setVisible(on)
            if not n:
                row.next_lbl.setProperty("nav", False)
                row.next_lbl.setText(self._none_text(key))
                self.ctrl.reset_next(key)
            elif not row.next_lbl.property("nav"):
                row.next_lbl.setText("")

    # styling -----------------------------------------------------------------
    def restyle(self, c):
        on_col = _solid(c, "step_hi", "#1AE5FF")
        for key, row in self.rows.items():
            row.icon.setPixmap(_glyph(key, on_col if self.ctrl is not None and self.ctrl.is_on(key)
                                      else _solid(c, "sub", "#9DB0CC")))
            row.more.setIcon(QIcon(_gear(on_col if row.more.isChecked() else _solid(c, "sub", "#9DB0CC"))))
            row.more.setIconSize(QSize(15, 15))
            row.switch.on_col = on_col
            row.switch.off_col = _solid(c, "tool_bg", "#111A2B")
            row.switch.knob_col = _solid(c, "sub", "#9DB0CC")
            row.switch.edge_col = _solid(c, "sub", "#9DB0CC")
            row.switch.update()
            if row.bar is not None:
                row.bar.track = _solid(c, "step_border", "#1E2A3D")


def Qgis_Warning():  # noqa: N802 - tiny helper so the module keeps one import of Qgis
    from qgis.core import Qgis
    return Qgis.MessageLevel.Warning


def _dim(col):
    """The colour at 45 % opacity (disabled text that still reads as text, in every theme)."""
    q = QColor(col) if isinstance(col, str) else QColor()
    if not q.isValid():
        q = QColor("#9DB0CC")
    return "rgba(%d,%d,%d,115)" % (q.red(), q.green(), q.blue())


def _live_qss(c):
    """Styles for the live section; appended to the panel stylesheet."""
    return f"""
QFrame#vfLiveRow {{ background:{c['tool_bg']}; border:1px solid {c['step_border']}; border-radius:7px; }}
QFrame#vfLiveRow[on="true"] {{ border:1px solid {c['step_hi']}; }}
QFrame#vfLiveRow QLabel {{ border:none; background:transparent; }}
QLabel#vfLiveName {{ color:{c['title']}; font-size:12px; font-weight:700; }}
QLabel#vfLiveStatus {{ color:{c['sub']}; font-size:12px;
    font-family:'JetBrains Mono','Consolas','DejaVu Sans Mono',monospace; }}
QLabel#vfLiveHint {{ color:{c['sub']}; font-size:11px; font-weight:700;
    font-family:'JetBrains Mono','Consolas','DejaVu Sans Mono',monospace; }}
QLabel#vfLiveNote {{ color:{c['section']}; font-size:11px; }}
QPushButton#vfLiveMore {{ background:transparent; color:{c['section']}; border:1px solid {c['step_border']};
    padding:0px;
    border-radius:5px; padding:2px 7px; font-size:10px; font-weight:700; }}
QPushButton#vfLiveMore:checked, QPushButton#vfLiveMore:hover {{ color:{c['title']}; border:1px solid {c['step_hi']}; }}
QPushButton#vfLiveNext {{ background:{c['step_bg']}; color:{c['title']}; border:1px solid {c['step_border']};
    border-radius:6px; padding:4px 9px; font-size:11px; font-weight:700; }}
QPushButton#vfLiveNext:hover {{ border:1px solid {c['step_hi']}; }}
QPushButton#vfLiveNext:disabled {{ color:{_dim(c['sub'])}; border:1px solid {c['step_border']}; background:transparent; }}
QPushButton#vfLiveAction {{ background:{c['step_bg']}; color:{c['title']}; border:1px solid {c['step_border']};
    border-radius:6px; padding:5px 10px; font-size:11px; font-weight:700; }}
QPushButton#vfLiveAction:hover {{ border:1px solid {c['step_hi']}; }}
QLabel#vfLiveStatus[warn="true"] {{ color:{c.get('warn', '#F5B83D')}; }}
QPushButton#vfLiveMore:checked {{ background:{c['step_bg']}; }}
QWidget#vfLiveSettings QLabel {{ color:{c['sub']}; font-size:11px; }}
QSpinBox#vfLiveSpin, QDoubleSpinBox#vfLiveSpin {{ background:{c['step_bg']}; color:{c['title']};
    border:1px solid {c['step_border']}; border-radius:5px; padding:2px 5px; }}
QWidget#vfLiveSettings QCheckBox {{ color:{c['tool_text']}; }}
"""


class SpanInspectorPanel(QDockWidget):
    """The dock. One instance is reused; closing it clears the highlight."""

    def __init__(self, iface, parent=None):
        super().__init__("Span Inspector", parent or iface.mainWindow())
        self.setObjectName("VelocitySpanInspector")
        self.iface = iface
        self._rb = None
        self._spans = []
        self._all_spans = []
        self._total_spans = 0
        self._watched = []
        self._active = False
        self._loading = False
        self._node_mode = "poles"   # "poles" | "splitters" — which point layers the node picker offers
        self._proj_signals = []
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._rescan)

        self.setWidget(self._build_ui())
        self._apply_theme()
        self._watch_project()
        if getattr(self, "_live", None) is not None:
            try:
                self._live.start()
            except Exception:
                _swallowed_note()
        self.visibilityChanged.connect(self._on_visibility)
        try:
            from .nexus_dock import apply_dock_chrome
            apply_dock_chrome(self)
        except Exception:
            _swallowed_note()

    # ── styling ───────────────────────────────────────────────────────────────
    def _apply_theme(self):
        """Re-style from the live Nexus theme. Safe to call any time."""
        c = _theme()
        # Contrast-check the ok/warn/bad colours against THIS PANEL's card colour,
        # not the QGIS window palette. The panel always paints on the Nexus theme
        # background (every bundled theme is dark), so checking against the QGIS
        # palette would return light-mode colours for a dark card — unreadable.
        sem = {"ok": "#2ea043", "warn": "#e0a020", "bad": "#e5534b"}
        try:
            bg = c.get("step_bg", "#0D1320")
            sem = {k: theme_safe.ensure_contrast(v, bg, 4.5).name()
                   for k, v in sem.items()}
        except Exception:
            _swallowed_note()
        try:
            self._root.setStyleSheet(_build_qss(c, sem) + _live_qss(c))
        except Exception:
            _swallowed_note()
        live = getattr(self, "_live", None)
        if live is not None:
            try:
                live.restyle(c)
            except Exception:
                _swallowed_note()
        self._paint_result()

    # ── UI ────────────────────────────────────────────────────────────────────
    def _sec(self, text):
        lbl = QLabel(f"// {text.upper()}")
        lbl.setObjectName("vfSpanSection")
        return lbl

    def _build_ui(self):
        outer = QScrollArea()
        outer.setObjectName("vfSpanScroll")
        outer.setWidgetResizable(True)
        outer.setFrameShape(QFrame.Shape.NoFrame)

        self._root = QWidget()
        self._root.setObjectName("vfSpanRoot")
        v = QVBoxLayout(self._root)
        v.setContentsMargins(14, 12, 14, 14)
        v.setSpacing(9)

        title = QLabel("SPAN INSPECTOR")
        title.setObjectName("vfSpanTitle")
        v.addWidget(title)

        sub = QLabel("Pole → next pole, measured along the cable. Anything longer "
                     "than your limit lights up, and clears itself when you fix it.")
        sub.setObjectName("vfSpanSub")
        sub.setWordWrap(True)
        v.addWidget(sub)

        beta = QLabel("BETA · READ-ONLY — never edits your data")
        beta.setObjectName("vfSpanBeta")
        beta.setWordWrap(True)
        v.addWidget(beta)

        # ── live tools (D18): Live Measure, Group counter, Drop counter, Drop lengths, PON groups ──
        self._live = None
        if not _live_disabled():
            v.addWidget(self._sec("live on the map"))
            self._live = _LiveSection(self)
            v.addWidget(self._live)

        # ── limit ──
        v.addWidget(self._sec("max span"))
        card = QFrame()
        card.setObjectName("vfSpanCard")
        cv = QVBoxLayout(card)
        cv.setContentsMargins(14, 12, 14, 12)
        cv.setSpacing(7)

        self.readout = QLabel("70 m")
        self.readout.setObjectName("vfSpanReadout")
        self.readout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cv.addWidget(self.readout)

        row = QHBoxLayout()
        row.setSpacing(9)
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setObjectName("vfSpanSlider")
        self.slider.setRange(int(span_scan.MIN_LIMIT_M), int(span_scan.MAX_LIMIT_M))
        self.slider.setValue(int(span_scan.DEFAULT_LIMIT_M))
        self.slider.setToolTip("0–100 m. 70 m = ADSS feeder/distribution · 50 m = drops.")
        row.addWidget(self.slider, 1)
        self.spin = QSpinBox()
        self.spin.setObjectName("vfSpanSpin")
        self.spin.setRange(int(span_scan.MIN_LIMIT_M), int(span_scan.MAX_LIMIT_M))
        self.spin.setValue(int(span_scan.DEFAULT_LIMIT_M))
        self.spin.setSuffix(" m")
        self.spin.setFixedWidth(82)
        row.addWidget(self.spin)
        cv.addLayout(row)

        hint = QLabel("70 M ADSS   ·   50 M DROPS")
        hint.setObjectName("vfSpanHint")
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cv.addWidget(hint)
        v.addWidget(card)
        self.slider.valueChanged.connect(self._on_limit)
        self.spin.valueChanged.connect(self._on_limit)

        # ── node layer (poles or splitters) ──
        v.addWidget(self._sec("node layer"))
        # Poles | Splitters toggle — switches which point layers the picker offers, so the
        # SAME span engine measures pole→pole runs OR drop→splitter runs (a drop's
        # splitter→house length, checked against the 55 m drop limit). Read-only.
        mode_row = QHBoxLayout()
        mode_row.setContentsMargins(0, 0, 0, 0)
        mode_row.setSpacing(6)
        self._btn_poles = QPushButton("Poles")
        self._btn_splitters = QPushButton("Splitters")
        for b, m in ((self._btn_poles, "poles"), (self._btn_splitters, "splitters")):
            b.setCheckable(True)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setToolTip("Measure spans between poles" if m == "poles"
                         else "Measure each drop's distance to its splitter (STS/FTS)")
            b.clicked.connect(lambda _checked=False, mode=m: self._set_node_mode(mode))
            mode_row.addWidget(b)
        self._btn_poles.setChecked(True)
        v.addLayout(mode_row)

        self.pole_combo = QComboBox()
        self.pole_combo.setObjectName("vfSpanCombo")
        self.pole_combo.setToolTip(
            "Spans run between the nodes (poles or splitters) ON each cable. A cable with "
            "fewer than two nodes has no spans (its far end is counted, so drops measure).")
        self.pole_combo.currentIndexChanged.connect(self._on_poles_changed)
        v.addWidget(self.pole_combo)


        # ── cables ──
        v.addWidget(self._sec("cable layers"))
        self._layer_box = QWidget()
        self._layer_v = QVBoxLayout(self._layer_box)
        self._layer_v.setContentsMargins(10, 8, 10, 8)
        self._layer_v.setSpacing(4)
        self._layer_scroll = QScrollArea()
        self._layer_scroll.setObjectName("vfSpanScroll")
        self._layer_scroll.setWidgetResizable(True)
        self._layer_scroll.setWidget(self._layer_box)
        self._layer_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self._layer_scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._layer_scroll.setSizePolicy(QSizePolicy.Policy.Expanding,
                                         QSizePolicy.Policy.Fixed)
        wrap = QFrame()
        wrap.setObjectName("vfSpanCard")
        wv = QVBoxLayout(wrap)
        wv.setContentsMargins(2, 2, 2, 2)
        wv.addWidget(self._layer_scroll)
        v.addWidget(wrap)
        self._checks = {}

        # ── actions ──
        self.btn_toggle = QPushButton("HIGHLIGHT VIOLATIONS")
        self.btn_toggle.setObjectName("vfSpanGo")
        self.btn_toggle.setCheckable(True)
        self.btn_toggle.setMinimumHeight(40)
        self.btn_toggle.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_toggle.clicked.connect(self._on_toggle)
        v.addWidget(self.btn_toggle)

        nav = QHBoxLayout()
        nav.setSpacing(8)
        self.btn_zoom = QPushButton("Zoom to worst")
        self.btn_zoom.setObjectName("vfSpanMini")
        self.btn_zoom.clicked.connect(self._zoom_worst)
        self.btn_zoom.setEnabled(False)
        nav.addWidget(self.btn_zoom)
        self.btn_refresh = QPushButton("Re-scan")
        self.btn_refresh.setObjectName("vfSpanMini")
        self.btn_refresh.setToolTip("Re-read the layers now (also automatic whenever "
                                    "you edit a cable or a pole).")
        self.btn_refresh.clicked.connect(self._rescan)
        nav.addWidget(self.btn_refresh)
        v.addLayout(nav)

        self.result = QLabel("Not running.")
        self.result.setObjectName("vfSpanResult")
        self.result.setWordWrap(True)
        v.addWidget(self.result)

        v.addWidget(self._sec("violations — click to zoom"))
        self.list = QListWidget()
        self.list.setObjectName("vfSpanList")
        self.list.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.list.setMinimumHeight(190)
        self.list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.list.itemClicked.connect(self._on_pick)
        v.addWidget(self.list, 1)

        outer.setWidget(self._root)
        self._result_kind = "idle"
        self.reload_layers()
        self._restore_settings()
        return outer

    # ── layer discovery (project-agnostic) ────────────────────────────────────
    def _set_node_mode(self, mode):
        """Switch the node picker between pole layers and splitter layers, then rebuild
        the picker. Read-only — nothing is measured until the user scans."""
        self._node_mode = "splitters" if mode == "splitters" else "poles"
        if _alive(self._btn_poles):
            self._btn_poles.setChecked(self._node_mode == "poles")
        if _alive(self._btn_splitters):
            self._btn_splitters.setChecked(self._node_mode == "splitters")
        self.reload_layers()
        self._save_settings()

    def reload_layers(self):
        """(Re)build the node picker and cable checklist from the OPEN project."""
        self._loading = True
        try:
            proj = QgsProject.instance()

            if _alive(self.pole_combo):
                keep = self.pole_combo.currentData()
                self.pole_combo.blockSignals(True)
                self.pole_combo.clear()
                if self._node_mode == "splitters":
                    found = span_scan.find_splitter_layers(proj)
                    empty_msg = "— no splitter layer in this project —"
                else:
                    found = span_scan.find_pole_layers(proj)
                    empty_msg = "— no point layer in this project —"
                for l in found:
                    self.pole_combo.addItem(f"{l.name()}   ({l.featureCount()})", l.id())
                if not found:
                    self.pole_combo.addItem(empty_msg, None)
                if keep:
                    i = self.pole_combo.findData(keep)
                    if i >= 0:
                        self.pole_combo.setCurrentIndex(i)
                self.pole_combo.blockSignals(False)

            prev = {lid: cb.isChecked() for lid, cb in self._checks.items()
                    if _alive(cb)}
            while self._layer_v.count():
                it = self._layer_v.takeAt(0)
                w = it.widget()
                if w:
                    w.setParent(None)
                    w.deleteLater()
            self._checks = {}
            lyrs = [l for l in proj.mapLayers().values() if span_scan.is_line_layer(l)]
            lyrs.sort(key=lambda l: l.name().lower())
            if not lyrs:
                msg = QLabel("No line layers in this project.")
                msg.setWordWrap(True)
                self._layer_v.addWidget(msg)
            for l in lyrs:
                cb = QCheckBox(f"{l.name()}   ({l.featureCount()})")
                cb.setChecked(prev.get(
                    l.id(), any(h in l.name().lower() for h in _CABLE_HINTS)))
                cb.stateChanged.connect(self._on_layers_changed)
                self._layer_v.addWidget(cb)
                self._checks[l.id()] = cb
            # Height must be a WHOLE number of rows, measured from a real row —
            # row height varies with theme + font, so any hardcoded guess clips a
            # row (top or bottom) and the panel looks broken.
            self._layer_box.adjustSize()
            spacing = self._layer_v.spacing()
            margins = self._layer_v.contentsMargins()
            chrome = margins.top() + margins.bottom() + 4
            first = next((cb for cb in self._checks.values() if _alive(cb)), None)
            row_h = (first.sizeHint().height() if first is not None else 20) + spacing
            visible = max(1, min(len(self._checks) or 1, 5))
            self._layer_scroll.setFixedHeight(visible * row_h + chrome)
            live = getattr(self, "_live", None)
            if live is not None:
                live.refresh_layer_combos()
        finally:
            self._loading = False

    def _pole_layer(self):
        if not _alive(self.pole_combo):
            return None
        lid = self.pole_combo.currentData()
        return QgsProject.instance().mapLayer(lid) if lid else None

    def _selected_layers(self):
        proj = QgsProject.instance()
        out = []
        for lid, cb in self._checks.items():
            if _alive(cb) and cb.isChecked():
                l = proj.mapLayer(lid)
                if l is not None:
                    out.append(l)
        return out

    # ── per-project memory ────────────────────────────────────────────────────
    def _settings_prefix(self):
        return f"{_SETTINGS_ROOT}/{_project_key()}"

    def _save_settings(self):
        if self._loading:
            return
        try:
            s = QgsSettings()
            p = self._settings_prefix()
            s.setValue(f"{p}/limit", int(self.spin.value()))
            s.setValue(f"{p}/node_mode", self._node_mode)
            s.setValue(f"{p}/pole", self.pole_combo.currentData() or "")
            s.setValue(f"{p}/cables", [lid for lid, cb in self._checks.items()
                                       if _alive(cb) and cb.isChecked()])
        except Exception:
            _swallowed_note()

    def _restore_settings(self):
        """Bring back this project's limit + layer choices, if we've seen it before."""
        self._loading = True
        try:
            s = QgsSettings()
            p = self._settings_prefix()
            # Node mode first — if this project was last used in Splitters mode, switch the
            # picker to splitter layers BEFORE we try to restore the chosen layer below.
            mode = (s.value(f"{p}/node_mode", "poles") or "poles")
            if mode == "splitters" and self._node_mode != "splitters":
                self._node_mode = "splitters"
                if _alive(self._btn_poles):
                    self._btn_poles.setChecked(False)
                if _alive(self._btn_splitters):
                    self._btn_splitters.setChecked(True)
                self.reload_layers()
                self._loading = True   # reload_layers cleared it; keep restore atomic
            lim = s.value(f"{p}/limit", None)
            if lim is not None:
                try:
                    val = int(span_scan.clamp_limit(lim))
                    self.spin.setValue(val)
                    self.slider.setValue(val)
                    self.readout.setText(f"{val} m")
                except Exception:
                    _swallowed_note()
            pole = s.value(f"{p}/pole", "") or ""
            if pole:
                i = self.pole_combo.findData(pole)
                if i >= 0:
                    self.pole_combo.setCurrentIndex(i)
            cables = s.value(f"{p}/cables", None)
            if cables:
                if isinstance(cables, str):
                    cables = [cables]
                want = set(cables)
                for lid, cb in self._checks.items():
                    if _alive(cb):
                        cb.setChecked(lid in want)
        except Exception:
            _swallowed_note()
        finally:
            self._loading = False

    # ── project tracking (signal-driven; no polling) ──────────────────────────
    def _watch_project(self):
        """Rebuild when the project or its layer set changes — any project, any time."""
        proj = QgsProject.instance()
        for name in ("layersAdded", "layersRemoved", "cleared", "readProject"):
            try:
                getattr(proj, name).connect(self._on_project_changed)
                self._proj_signals.append(name)
            except Exception:
                _swallowed_note(); continue

    def _unwatch_project(self):
        proj = QgsProject.instance()
        for name in self._proj_signals:
            try:
                getattr(proj, name).disconnect(self._on_project_changed)
            except Exception:
                _swallowed_note(); continue
        self._proj_signals = []

    def _on_project_changed(self, *args):
        was_active = self._active
        if was_active:
            self.deactivate()
        try:
            self.reload_layers()
            self._restore_settings()
        except Exception:
            _swallowed_note()
        if was_active:
            self.activate()

    # ── behaviour ─────────────────────────────────────────────────────────────
    def _on_limit(self, value):
        for w in (self.slider, self.spin):
            if _alive(w) and w.value() != value:
                w.blockSignals(True)
                w.setValue(value)
                w.blockSignals(False)
        if _alive(self.readout):
            self.readout.setText(f"{value} m")
        self._save_settings()
        if self._active:
            # Moving the dial does NOT need a re-measure — filter the spans we
            # already have, so the slider stays instant even on a 4,800-pole project.
            self._apply_limit()

    def _on_layers_changed(self, _state=None):
        self._save_settings()
        if self._active:
            self._watch_layers()
            self._schedule()


    def _on_poles_changed(self, _i=None):
        self._save_settings()
        if self._active:
            self._watch_layers()
            self._schedule()

    def _on_toggle(self, checked):
        self.activate() if checked else self.deactivate()

    def activate(self):
        self._active = True
        if _alive(self.btn_toggle):
            self.btn_toggle.setChecked(True)
            self.btn_toggle.setText("HIGHLIGHTING — CLICK TO STOP")
        self._watch_layers()
        self._rescan()

    def deactivate(self):
        """Stop watching and clear the canvas. Safe to call twice."""
        self._active = False
        self._unwatch_layers()
        try:
            self._timer.stop()
        except Exception:
            _swallowed_note()
        self._clear_band()
        self._spans = []
        self._all_spans = []
        self._total_spans = 0
        if _alive(self.list):
            self.list.clear()
        if _alive(self.btn_toggle):
            self.btn_toggle.setChecked(False)
            self.btn_toggle.setText("HIGHLIGHT VIOLATIONS")
        if _alive(self.btn_zoom):
            self.btn_zoom.setEnabled(False)
        self._set_result("Not running.", "idle")

    def _schedule(self):
        if self._active and _alive(self._timer):
            self._timer.start(_DEBOUNCE_MS)

    # ── live edit tracking ────────────────────────────────────────────────────
    def _watch_layers(self):
        """Watch the cables AND the poles — moving a pole changes a span too."""
        self._unwatch_layers()
        targets = list(self._selected_layers())
        pl = self._pole_layer()
        if pl is not None:
            targets.append(pl)
        for l in targets:
            for sig in _EDIT_SIGNALS:
                try:
                    getattr(l, sig).connect(self._on_layer_edited)
                except Exception:
                    _swallowed_note(); continue
            self._watched.append(l)

    def _unwatch_layers(self):
        for l in self._watched:
            if not _alive(l):
                continue
            for sig in _EDIT_SIGNALS:
                try:
                    getattr(l, sig).disconnect(self._on_layer_edited)
                except Exception:
                    _swallowed_note(); continue
        self._watched = []

    def _on_layer_edited(self, *args):
        self._schedule()

    # ── scan + draw ───────────────────────────────────────────────────────────
    def _set_result(self, text, kind="idle"):
        self._result_text = text
        self._result_kind = kind
        self._paint_result()

    def _paint_result(self):
        if not _alive(getattr(self, "result", None)):
            return
        sem = getattr(self, "_sem", {"ok": "#2ea043", "warn": "#e0a020",
                                     "bad": "#e5534b"})
        c = _theme()
        fg = {"ok": sem["ok"], "bad": sem["bad"]}.get(self._result_kind, c["section"])
        self.result.setStyleSheet(
            f"color:{fg}; background:{c['step_bg']}; border:1px solid {fg};"
            " border-radius:8px; padding:9px 11px; font-weight:700;")
        self.result.setText(getattr(self, "_result_text", "Not running."))

    def _rescan(self):
        if not self._active:
            return
        cables = self._selected_layers()
        poles = self._pole_layer()
        proj = QgsProject.instance()
        if not cables:
            self._all_spans = []
            self._spans = []
            self._total_spans = 0
            self._draw()
            self._set_result("Tick at least one cable layer to scan.", "idle")
            return
        if poles is None:
            self._all_spans = []
            self._spans = []
            self._total_spans = 0
            self._draw()
            self._set_result("Pick the pole layer — spans are measured pole to pole.",
                             "idle")
            return
        try:
            # ONE measuring pass; every limit change after this is a cheap filter.
            # Ends always count as span boundaries. Ticking a layer means "measure
            # it" — a separate opt-in was a technical detail leaking into the UI
            # (JJ, 2026-07-23). Backbone cables are unaffected: their end sits on a
            # pole and collapses onto it. Drops become measurable.
            self._all_spans = span_scan.scan_all(cables, poles, proj)
            self._total_spans = len(self._all_spans)
        except Exception as exc:
            self._all_spans = []
            self._spans = []
            self._total_spans = 0
            self._set_result(f"Scan failed: {exc}", "bad")
            return
        self._apply_limit()

    def _apply_limit(self):
        """Re-filter the measured spans against the current limit. No re-measure."""
        limit = span_scan.clamp_limit(self.spin.value() if _alive(self.spin)
                                      else span_scan.DEFAULT_LIMIT_M)
        self._spans = span_scan.over_limit(getattr(self, "_all_spans", []), limit)
        self._draw()
        self._fill_list()
        total, worst, per = span_scan.summarise(self._spans)
        if self._total_spans == 0:
            self._set_result(
                "No pole-to-pole spans found — do these cables have poles on them? "
                "Check the pole layer above.", "idle")
        elif total == 0:
            self._set_result(
                f"✅  All clear — no span over {limit:g} m\n"
                f"{self._total_spans} pole-to-pole spans checked", "ok")
        else:
            bits = "   ".join(f"{k} {v}" for k, v in sorted(per.items()))
            self._set_result(
                f"⚠  {total} of {self._total_spans} spans over {limit:g} m "
                f"· worst {worst:.1f} m\n{bits}", "bad")
        if _alive(self.btn_zoom):
            self.btn_zoom.setEnabled(bool(self._spans))

    def _band(self):
        canvas = self.iface.mapCanvas()
        if not _alive(self._rb):
            self._rb = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.LineGeometry)
            self._rb.setColor(_HL_COLOR)
            self._rb.setWidth(_HL_WIDTH)
        return self._rb

    def _draw(self):
        """One rubber band holding every offending span, drawn along the cable."""
        rb = self._band()
        rb.reset(QgsWkbTypes.GeometryType.LineGeometry)
        proj = QgsProject.instance()
        for s in self._spans:
            lyr = proj.mapLayer(s.layer_id)
            if lyr is None or not s.path:
                continue
            try:
                rb.addGeometry(QgsGeometry.fromPolylineXY(list(s.path)), lyr)
            except Exception:
                _swallowed_note(); continue
        rb.show()

    def _clear_band(self):
        if _alive(self._rb):
            try:
                self._rb.reset(QgsWkbTypes.GeometryType.LineGeometry)
                self._rb.hide()
            except Exception:
                _swallowed_note()
        self._rb = None

    def _fill_list(self):
        if not _alive(self.list):
            return
        self.list.clear()
        for s in self._spans[:500]:
            it = QListWidgetItem(
                f"{s.length_m:7.1f} m   {s.pole_a} → {s.pole_b}   {s.label}")
            it.setToolTip(f"{s.label}  ·  span {s.index}  ·  {s.layer_name}\n"
                          f"pole {s.pole_a} → pole {s.pole_b}\n"
                          f"{s.length_m:.3f} m along the cable")
            it.setData(Qt.ItemDataRole.UserRole, s)
            self.list.addItem(it)
        if len(self._spans) > 500:
            self.list.addItem(QListWidgetItem(f"… and {len(self._spans) - 500} more"))

    # ── navigation ────────────────────────────────────────────────────────────
    def _zoom_to(self, span):
        proj = QgsProject.instance()
        lyr = proj.mapLayer(span.layer_id)
        if lyr is None or not span.path:
            return
        try:
            from qgis.core import QgsCoordinateTransform, QgsRectangle
            rect = QgsRectangle(span.p1, span.p2)
            rect.normalize()
            canvas = self.iface.mapCanvas()
            xform = QgsCoordinateTransform(
                lyr.crs(), canvas.mapSettings().destinationCrs(), proj)
            rect = xform.transformBoundingBox(rect)
            rect.scale(3.0)
            canvas.setExtent(rect)
            canvas.refresh()
        except Exception:
            _swallowed_note()

    def _on_pick(self, item):
        span = item.data(Qt.ItemDataRole.UserRole)
        if span is not None:
            self._zoom_to(span)

    def _zoom_worst(self):
        if self._spans:
            self._zoom_to(self._spans[0])

    # ── live tools: show / hide / close ─────────────────────────────────────────
    def showEvent(self, event):
        """Re-read the Nexus theme each time the panel is shown, and bring the live tools
        back after a close."""
        try:
            super().showEvent(event)
        except Exception:
            _swallowed_note()
        try:
            self._apply_theme()
            live = getattr(self, "_live", None)
            if live is not None and live.ctrl is None:
                live.start()
        except Exception:
            _swallowed_note()

    def _on_visibility(self, visible):
        """Hidden but not closed (tabbed away / View menu): the live tools keep running and a
        'Live tools on' chip shows on the map (D19 Q3)."""
        try:
            live = getattr(self, "_live", None)
            if live is not None and live.ctrl is not None:
                live.ctrl.set_panel_visible(bool(visible))
        except Exception:
            _swallowed_note()

    def live_teardown(self):
        """Live tools off and gone. Called only from closeEvent and close_span_inspector
        (and so from plugin unload) - never from deactivate() or a project change."""
        live = getattr(self, "_live", None)
        if live is not None:
            try:
                live.live_teardown()
            except Exception:
                _swallowed_note()

    # ── teardown ──────────────────────────────────────────────────────────────
    def closeEvent(self, event):
        """Closing the panel must leave no overlay and no live signal behind."""
        try:
            # View menu / panel toggle: Qt unticks the toggle action BEFORE calling close(), so
            # an unticked action here means "hide" - the live tools keep running (D19 Q3).
            # The X button and close() from code arrive with the action still ticked.
            if self.toggleViewAction().isChecked():
                self.live_teardown()
        except Exception:
            _swallowed_note()
        try:
            self.deactivate()
        except Exception:
            _swallowed_note()
        try:
            self._unwatch_project()
        except Exception:
            _swallowed_note()
        try:
            super().closeEvent(event)
        except Exception:
            _swallowed_note()


_PANEL = None


def show_span_inspector(iface):
    """Open (or re-show) the Span Inspector. Returns the dock."""
    global _PANEL
    if not _alive(_PANEL):
        _PANEL = SpanInspectorPanel(iface)
        iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, _PANEL)
    else:
        _PANEL.reload_layers()
        _PANEL._restore_settings()
        _PANEL._apply_theme()
    _PANEL.show()
    _PANEL.raise_()
    return _PANEL


def is_open():
    """True if the Span Inspector dock is currently open + visible. The update flow
    calls this BEFORE a hot-reload so it knows to re-open the panel afterwards (the
    reload destroys it), instead of dumping the user back on the home menu."""
    try:
        return bool(_alive(_PANEL) and _PANEL.isVisible())
    except Exception:
        return False


def close_span_inspector():
    """Tear down on plugin unload — no dangling rubber band, signal or project hook."""
    global _PANEL
    if _alive(_PANEL):
        for fn in ("live_teardown", "deactivate", "_unwatch_project"):
            try:
                getattr(_PANEL, fn)()
            except Exception:
                _swallowed_note()
        try:
            _PANEL.setParent(None)
        except Exception:
            _swallowed_note()
    _PANEL = None
