"""Street blocks from a road network, for drawing PON boundaries.

A PON boundary tiled around the demand points wanders into open veld and takes
notches out of its neighbours. Boundaries drawn on STREET BLOCKS do not: the
edges are the roads, so they come out long and straight. Measured on
Ventersdorp, block-aligned boundaries scored 27 vertices per PON against the
Malmesbury reference's 27, where the demand-tiled ones scored 65.

Two traps, both hit for real:

* **The AOI boundary must be unioned into the road network before
  polygonizing.** ``polygonize`` only closes a ring at shared NODES, so without
  the AOI edge the outer blocks never close and the whole edge of town is lost.
* **A cached roads file is not necessarily this town's roads.**
  ``C:/Temp/roads.json`` is Potchefstroom and is used by FT7; reusing it for
  another AOI silently returns blocks for the wrong place. Callers must check
  the bbox against the AOI -- :func:`bbox_overlaps` is here for that.
"""

from __future__ import annotations

import shapely
from shapely.geometry import LineString
from shapely.ops import polygonize, unary_union

__all__ = ["bbox_overlaps", "block_adjacency", "lines_from_overpass",
           "street_blocks", "subdivide_blocks"]

#: Two blocks meeting only at a crossroads POINT are not usable neighbours: any
#: gap-cut separates them and the PON renders as two lobes. Require a real
#: shared frontage instead. Square metres of overlap between 0.5 m buffers.
MIN_SHARED_FRONTAGE_M2 = 12.0


def _valid(g):
    return g if g.is_valid else shapely.make_valid(g)


def bbox_overlaps(bounds_a, bounds_b, min_fraction=0.25):
    """True when two (minx, miny, maxx, maxy) boxes overlap meaningfully.

    Used to reject a cached road file that belongs to a different town.
    """
    ax0, ay0, ax1, ay1 = bounds_a
    bx0, by0, bx1, by1 = bounds_b
    ix = max(0.0, min(ax1, bx1) - max(ax0, bx0))
    iy = max(0.0, min(ay1, by1) - max(ay0, by0))
    inter = ix * iy
    area_a = max(1e-9, (ax1 - ax0) * (ay1 - ay0))
    return (inter / area_a) >= min_fraction


def lines_from_overpass(payload):
    """LineStrings from an Overpass JSON payload (``out geom;``), in lon/lat."""
    out = []
    for el in payload.get("elements", ()):
        geom = el.get("geometry")
        if geom and len(geom) > 1:
            out.append(LineString([(p["lon"], p["lat"]) for p in geom]))
    return out


def street_blocks(road_lines, aoi_polygon, min_area_m2=50.0):
    """Polygons enclosed by the roads, clipped to the AOI.

    ``road_lines`` and ``aoi_polygon`` must already be in a METRIC CRS --
    distances in EPSG:4326 are degrees, and a 20 m gap prints as 0.0.
    """
    if aoi_polygon is None or aoi_polygon.is_empty:
        raise ValueError("An AOI polygon is required to close the outer blocks.")
    lines = [g for g in road_lines if g is not None and not g.is_empty]
    if not lines:
        return []
    noded = unary_union(list(lines) + [aoi_polygon.boundary])
    out = []
    for poly in polygonize(noded):
        if poly.is_empty or poly.area < min_area_m2:
            continue
        # representative_point is guaranteed inside, unlike centroid
        if poly.representative_point().within(aoi_polygon):
            out.append(_valid(poly))
    return out


def block_adjacency(blocks):
    """{index: {neighbour indexes}} using EDGE adjacency, not corner touching.

    Corner-only neighbours are excluded on purpose: see
    :data:`MIN_SHARED_FRONTAGE_M2`.
    """
    import networkx as nx

    g = nx.Graph()
    g.add_nodes_from(range(len(blocks)))
    try:
        from shapely import STRtree
        tree = STRtree(blocks)
        query = lambda geom: tree.query(geom)
    except Exception:                                   # pragma: no cover
        query = lambda geom: range(len(blocks))
    for i, a in enumerate(blocks):
        ab = a.buffer(0.5)
        for k in query(ab):
            k = int(k)
            if k <= i:
                continue
            shared = ab.intersection(blocks[k].buffer(0.5))
            if not shared.is_empty and shared.area > MIN_SHARED_FRONTAGE_M2:
                g.add_edge(i, k)
    return g


def subdivide_blocks(blocks, stand_xy, block_of_stand, max_homes):
    """Cut any block holding more than ``max_homes`` into smaller whole blocks.

    A block is the atom of the PON plan, so a block that alone exceeds the PON
    cap can never be placed legally: measured on Ventersdorp, one block holds
    276 homes against a cap of 128, and four blocks together hold 10.4% of the
    town. No amount of re-planning fixes that -- the atom has to get smaller.

    The cut is a STRAIGHT line across the block, perpendicular to its longer
    axis, at the median home. Straight because the whole point of drawing on
    blocks is straight edges, and at the median so the two halves carry a
    similar load. Recursion continues until every piece is under the limit.

    Returns ``(blocks, block_of_stand)`` -- both rebuilt, indices renumbered.
    """
    from shapely.geometry import LineString
    from shapely.ops import split as shp_split

    homes = {}
    for i, b in enumerate(block_of_stand):
        if b is not None:
            homes.setdefault(int(b), []).append(i)

    out = []
    owner = {}                      # new block index -> stand indices

    def emit(poly, idx):
        out.append(poly)
        owner[len(out) - 1] = idx

    def cut(poly, idx, depth=0):
        if len(idx) <= max_homes or depth >= 12:
            emit(poly, idx)
            return
        x0, y0, x1, y1 = poly.bounds
        vertical = (x1 - x0) >= (y1 - y0)
        vals = sorted(stand_xy[i][0 if vertical else 1] for i in idx)
        c = _gap_cut(vals)
        if vertical:
            line = LineString([(c, y0 - 10.0), (c, y1 + 10.0)])
        else:
            line = LineString([(x0 - 10.0, c), (x1 + 10.0, c)])
        try:
            pieces = [g for g in shp_split(poly, line).geoms
                      if g.geom_type == "Polygon" and not g.is_empty]
        except Exception:                                   # pragma: no cover
            pieces = []
        if len(pieces) < 2:
            emit(poly, idx)                 # cannot be cut -- keep it whole
            return
        placed = set()
        for g in pieces:
            sub = [i for i in idx
                   if i not in placed and g.covers(_pt(stand_xy[i]))]
            placed.update(sub)
            cut(g, sub, depth + 1)
        left = [i for i in idx if i not in placed]
        if left:                            # a home exactly on the cut line
            out[-1] = out[-1]
            owner[len(out) - 1] = owner[len(out) - 1] + left

    for bid, poly in enumerate(blocks):
        cut(poly, homes.get(bid, []))

    new_of_stand = [None] * len(block_of_stand)
    for nb, idx in owner.items():
        for i in idx:
            new_of_stand[i] = nb
    # a stand whose block was never split keeps its home through `owner`; any
    # stand with no block at all stays None, exactly as it arrived
    return out, new_of_stand


def _gap_cut(vals):
    """Where to cut a run of coordinates: the LARGEST gap between neighbours.

    Cutting at the median puts homes exactly ON the cut line, and the 2 m gap
    later trimmed off each side then pushes those homes outside their own PON
    -- measured, 19 to 37 homes lost that way. Cutting at the widest gap in the
    housing leaves the line in empty ground, which is also where a planner
    would put it. Restricted to the middle of the range so the split stays
    balanced.
    """
    if len(vals) < 2:
        return float(vals[0]) if vals else 0.0
    lo_i = max(1, int(len(vals) * 0.25))
    hi_i = max(lo_i + 1, int(len(vals) * 0.75))
    window = [(vals[i] - vals[i - 1], i) for i in range(lo_i, min(hi_i + 1, len(vals)))]
    if not window:
        window = [(vals[i] - vals[i - 1], i) for i in range(1, len(vals))]
    _w, i = max(window)
    return float((vals[i] + vals[i - 1]) / 2.0)


def _pt(xy):
    from shapely.geometry import Point
    return Point(xy[0], xy[1])
