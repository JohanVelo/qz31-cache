"""spool — crash-safe offline event queue (JSONL).

One JSON object per line. Write-before-send so a crash never loses an event.
Each record carries a target table + an idempotency_key so resends dedupe.
Capped at config.SPOOL_MAX_BYTES, dropping the OLDEST low-priority rows first
(errors > events > heartbeats). Pure Python (no QGIS).
"""
import json
import os


_PRIORITY = {"errors": 3, "events": 2, "sessions": 2, "installs": 2,
             "users": 2, "user_consent": 2, "heartbeats": 1}


def spool_path(data_dir):
    return os.path.join(data_dir, "nexus_telemetry_spool.jsonl")


def append(data_dir, table, payload, idempotency_key=None, prefer=None):
    """Queue one record. Returns False on disk error (never raises)."""
    rec = {"table": table, "payload": payload}
    if idempotency_key:
        rec["idem"] = idempotency_key
    if prefer:
        rec["prefer"] = prefer
    try:
        os.makedirs(data_dir, exist_ok=True)
        with open(spool_path(data_dir), "a", encoding="utf-8") as f:
            f.write(json.dumps(rec) + "\n")
        return True
    except OSError:
        return False


def read_all(data_dir):
    p = spool_path(data_dir)
    out = []
    if not os.path.isfile(p):
        return out
    try:
        with open(p, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        out.append(json.loads(line))
                    except ValueError:
                        pass        # skip a torn line
    except OSError:
        pass
    return out


def remove(data_dir, idem):
    """Drop the one record with this idempotency key — called only once the
    server has CONFIRMED delivery (2xx/409). Best-effort; never raises."""
    if not idem:
        return
    try:
        recs = [r for r in read_all(data_dir) if r.get("idem") != idem]
        rewrite(data_dir, recs)
    except OSError:
        pass


def rewrite(data_dir, records):
    """Replace the spool with `records` (after a partial flush)."""
    p = spool_path(data_dir)
    try:
        if not records:
            if os.path.isfile(p):
                os.remove(p)
            return True
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            for r in records:
                f.write(json.dumps(r) + "\n")
        os.replace(tmp, p)
        return True
    except OSError:
        return False


def enforce_cap(data_dir, max_bytes):
    """If the spool exceeds max_bytes, drop oldest lowest-priority records."""
    p = spool_path(data_dir)
    try:
        if not os.path.isfile(p) or os.path.getsize(p) <= max_bytes:
            return
    except OSError:
        return
    recs = read_all(data_dir)
    # keep highest priority + newest; drop from the front of the low-priority set
    recs.sort(key=lambda r: _PRIORITY.get(r.get("table"), 2))
    # binary-ish trim: drop ~25% lowest-priority oldest until under cap
    keep = recs
    while keep:
        size = sum(len(json.dumps(r)) + 1 for r in keep)
        if size <= max_bytes:
            break
        keep = keep[len(keep) // 4 or 1:]
    rewrite(data_dir, keep)
