"""Pass 4 (PON per PON) — pure, unit-testable helper for the per-batch report and
the cumulative session summary.

The batch pipeline, the zone/group offset arithmetic and the accumulator handling in
``_pon_per_pon_run`` are NOT touched. This only turns a list of per-batch count
records into clean report lines so the planner can see, after several polygons,
exactly what has been built. No QGIS objects — fully testable on its own.
"""


def batch_line(batch_no, pons, splitters, stands):
    """One-line report for a single batch just finished."""
    return (f"  ✓ Batch {batch_no}: {pons} PON(s), {splitters} splitter(s), "
            f"{stands} stand(s)")


def session_summary(batches):
    """``batches``: list of dicts with keys ``batch``, ``pons``, ``splitters``,
    ``stands``. Returns cumulative summary lines (list[str]) — one per batch plus
    the running totals."""
    rows = list(batches or [])
    if not rows:
        return ["── PON per PON session ────────────────────────", "  (no batches run yet)"]
    lines = ["── PON per PON session ────────────────────────"]
    tot_pons = tot_spl = tot_stands = 0
    for r in rows:
        p = int(r.get("pons", 0) or 0)
        s = int(r.get("splitters", 0) or 0)
        st = int(r.get("stands", 0) or 0)
        tot_pons += p
        tot_spl += s
        tot_stands += st
        lines.append(batch_line(r.get("batch", "?"), p, s, st))
    lines.append(f"  ── total: {len(rows)} batch(es) · {tot_pons} PON(s) · "
                 f"{tot_spl} splitter(s) · {tot_stands} stand(s)")
    return lines
