"""ui_crash_guard — mitigate a Qt 6.11 hard crash (access violation in
`QTabBar::moveTab`) that fires when a QGIS **dock tab is drag-reordered**.

QGIS tabs stacked panels together using QMainWindow dock-area QTabBars. On
Qt 6.11.1 (QGIS 4.0.3) dragging one of those tabs to reorder can access-violation
and take the whole app down — it's a native Qt bug, not plugin code.

Mitigation: set those dock tab bars **non-movable**. Clicking a tab to switch
panels still works; only drag-to-reorder (the crashy path) is disabled. Existing
tab bars are swept immediately; new ones (created when docks get tabbed together)
are caught via an event filter on the main window — no polling loop.

Also `heal_toolbar()` restores the branded toolbar to its own full-width top row
if QGIS restored it collapsed into a corner.
"""
from qgis.PyQt.QtWidgets import QTabBar, QToolBar
from qgis.PyQt.QtCore import Qt, QObject, QEvent


class DockTabGuard(QObject):
    def __init__(self, mw):
        super().__init__(mw)
        self._mw = mw
        mw.installEventFilter(self)
        self.sweep()

    def sweep(self):
        """Disable drag-reorder on every dock-area tab bar (direct children of the
        main window — this excludes attribute-table / layout tab bars, which are
        nested deeper inside their own widgets)."""
        n = 0
        try:
            for tb in self._mw.findChildren(QTabBar):
                if tb.parent() is self._mw and tb.isMovable():
                    tb.setMovable(False)
                    n += 1
        except Exception:
            pass
        return n

    def eventFilter(self, obj, ev):
        try:
            if ev.type() == QEvent.Type.ChildAdded:
                ch = ev.child()
                if isinstance(ch, QTabBar) and ch.parent() is self._mw:
                    ch.setMovable(False)
        except Exception:
            pass
        return False   # never consume the event


def install(mw):
    """Install the dock-tab crash guard (idempotent). Keeps a reference on the
    main window so Qt doesn't garbage-collect it. Fail-open."""
    try:
        g = getattr(mw, "_vf_dock_tab_guard", None)
        if g is not None:
            g.sweep()
            return g
        g = DockTabGuard(mw)
        mw._vf_dock_tab_guard = g
        return g
    except Exception:
        return None


def heal_toolbar(mw, object_name="FiberNetworkAutomationToolbar"):
    """If QGIS restored the branded toolbar collapsed (into the overflow chevron) or
    floated off-window, re-dock it on its own full-width top row AND call adjustSize()
    so it actually expands to fit its buttons. The adjustSize() is the critical bit —
    without it the toolbar keeps its saved ~100px width and shows only a '>>' chevron.
    Fail-open."""
    try:
        from qgis.PyQt.QtWidgets import QApplication
        tb = next((t for t in mw.findChildren(QToolBar)
                   if t.objectName() == object_name
                   or t.windowTitle() == "FiberNetworkAutomation"), None)
        if tb is None:
            return
        collapsed = tb.width() < 300
        off_window = tb.window() is not mw
        if collapsed or off_window:               # re-dock on its own top row
            mw.removeToolBar(tb)
            mw.addToolBar(Qt.ToolBarArea.TopToolBarArea, tb)
            mw.insertToolBarBreak(tb)
        tb.setFloatable(False)                    # stop it floating off-screen again
        tb.setVisible(True)
        tb.adjustSize()                           # <-- expand to fit its buttons
        try:
            QApplication.processEvents()
        except Exception:
            pass
    except Exception:
        pass
