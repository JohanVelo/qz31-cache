import json, re
proj = QgsProject.instance()
def find(n):
    ls=proj.mapLayersByName(n); return ls[0] if ls else None
def lf(L):
    fn=[f.name() for f in L.fields()]
    for c in ['label','label_1','Label','LABEL','name']:
        if c in fn: return c
    return fn[0]

gt={}
# FTS distinct: label -> {agg, port}
L=find('FTS Splitters'); f=lf(L); d={}
for ft in L.getFeatures():
    lab=str(ft[f])
    if lab in d: continue
    m=re.search(r'C\d\dP\d\d',lab)
    agg=re.search(r'(MOA\.AGG\.DM\.P\.\w+)',lab)
    d[lab]={'port':m.group(0) if m else None,'agg':agg.group(1) if agg else None}
gt['fts']=d

# STS distinct: label -> {dis, port, leg}
L=find('STS Splitters'); f=lf(L); d={}
for ft in L.getFeatures():
    lab=str(ft[f])
    if lab in d: continue
    m=re.search(r'C\d\dP\d\d',lab); leg=re.search(r'\.(L\d+)$',lab)
    dis=re.search(r'(MOA\.DIS\.DM\.P\.\w+)',lab)
    d[lab]={'port':m.group(0) if m else None,'leg':leg.group(1) if leg else None,
            'dis':dis.group(1) if dis else None}
gt['sts']=d

# Drops distinct: by label -> {strt(dis), end(ont), pon}
L=find('Drop Cable'); f=lf(L)
fn=[x.name() for x in L.fields()]
si=L.fields().indexOf('strtfeat'); ei=L.fields().indexOf('endfeat'); pi=L.fields().indexOf('pon_no')
d={}
for ft in L.getFeatures():
    lab=str(ft[f])
    if lab in d: continue
    d[lab]={'strt':str(ft[si]) if si>=0 else None,'end':str(ft[ei]) if ei>=0 else None,
            'pon':ft[pi] if pi>=0 else None}
gt['drops']=d
gt['drop_fields']=fn

# Distribution distinct labels
L=find('Distribution Cable'); f=lf(L)
gt['dist']=sorted(set(str(ft[f]) for ft in L.getFeatures()))
# AGG + DIS dome labels
for k,n in [('agg','Enclosures Splice'),('dis','Enclosures Connectorised')]:
    L=find(n); f=lf(L)
    gt[k]=sorted(set(str(ft[f]) for ft in L.getFeatures()))
# ONT labels
L=find('ONT'); f=lf(L)
gt['ont']=sorted(set(str(ft[f]) for ft in L.getFeatures()))
# PON: pon_no/zone/port via label
L=find('PON'); f=lf(L)
zi=L.fields().indexOf('zone_no'); pi=L.fields().indexOf('pon_no')
d={}
for ft in L.getFeatures():
    lab=str(ft[f])
    if lab in d: continue
    d[lab]={'pon':ft[pi] if pi>=0 else None,'zone':ft[zi] if zi>=0 else None}
gt['pon']=d

with open(r'C:/Temp/splice_gt.json','w') as fh:
    json.dump(gt,fh)
print('WROTE', {k:(len(v) if hasattr(v,'__len__') else v) for k,v in gt.items()})
