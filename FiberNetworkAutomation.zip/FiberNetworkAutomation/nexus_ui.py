"""nexus_ui — the shared UI rules the Nexus surfaces obey.

WHY THIS EXISTS. The plugin has ~32 UI classes across ~42,000 lines and no shared
rules, so four panels grew four visual languages. Hand-styling 32 surfaces is not
a plan. This is the one place the rules live; surfaces call in rather than
inventing their own answer.

PURE ON PURPOSE. No Qt import at module level, no colour literals. Every function
takes a palette dict (the THEMES entry already in velocity_home_panel) and returns
strings. That makes it unit-testable without a QApplication, and it means a theme
change flows through automatically instead of being re-hardcoded per panel.

=== THE RULES ===

1. COLOUR MEANS ONE THING.
   A colour may encode exactly one idea across the whole product. Today green
   means AutoNet AND Renumber AND Create Enclosure, so it means nothing and you
   cannot see danger at a glance.

   THE EXCEPTION, AND IT IS A HARD ONE: the Network Planner's cable-type buttons
   (Feeder, Second/Third Feeder, Distribution 1/2/3) are painted the colour the
   cable will BE on the map. Red button draws red cable. That is not decoration,
   it is the legend, and normalising it would sever the button from what it
   produces. `role_for()` returns LEGEND for these and the caller must leave the
   existing stylesheet alone. Verified against dock_widget.py 2026-07-28.

2. ONE PRIMARY PER VIEW. Exactly one action may carry PRIMARY. If a view seems to
   need two, one of them is not primary.

3. DESTRUCTIVE NEVER COMPETES. Outlined, never filled, never adjacent to the
   primary. It should read as "are you sure" before it is clicked, not after.

4. NEVER SHOW A BARE DASH OR ZERO. An empty value states what is missing and
   offers the action that fills it. `empty_state()` builds that sentence. A dash
   is a dead end; "Run audit" is a door.

5. ONE NAME PER CLIENT. "Fibertime" is not "FIBRE TIME". `client_name()` is the
   only speller.

6. A SECTION LABEL NAMES ITS CONTENT. Two sections may not share a label — the
   home panel currently labels both the KPI row and the step list "// WORKFLOW",
   which are "what exists" and "what to do next".
"""

# ── button roles ───────────────────────────────────────────────────────────
PRIMARY = "primary"          # the one action this view is for
SECONDARY = "secondary"      # everything else that is safe
DESTRUCTIVE = "destructive"  # deletes, overwrites, renumbers in place
LEGEND = "legend"            # colour IS the meaning — do not restyle (rule 1)

ROLES = (PRIMARY, SECONDARY, DESTRUCTIVE, LEGEND)

#: Buttons whose colour is the map legend, not a style choice. Matched on a
#: lowercase substring of the label. Keep in step with dock_widget.py.
LEGEND_LABELS = (
    "feeder", "second feeder", "third feeder",
    "distribution 1", "distribution 2", "distribution 3",
    "feeder splice", "first tier splitter splice",
)

#: Words that make an action destructive regardless of how it is styled today.
_DESTRUCTIVE_WORDS = ("delete", "remove", "clear", "purge", "destroy", "wipe",
                      "reset", "discard", "revert")


def role_for(label, explicit=None, is_primary=False):
    """The semantic role of a button, from its visible label.

    explicit wins (a caller that knows better says so). Otherwise: legend
    buttons first — they must never be swept into a generic role — then
    destructive by wording, then primary if the caller flagged it, else
    secondary. Defaulting to SECONDARY is deliberate: a mis-classified
    secondary is invisible, a mis-classified primary shouts.
    """
    if explicit in ROLES:
        return explicit
    low = (label or "").strip().lower()
    for tok in LEGEND_LABELS:
        if tok in low:
            return LEGEND
    for w in _DESTRUCTIVE_WORDS:
        if w in low:
            return DESTRUCTIVE
    return PRIMARY if is_primary else SECONDARY


def button_qss(role, pal, *, selector="QPushButton"):
    """Stylesheet for one role, built from the ACTIVE palette.

    LEGEND returns "" — the caller keeps whatever it already had. That empty
    string is the rule, not an oversight.
    """
    if role == LEGEND:
        return ""
    accent = pal.get("step_hi") or pal.get("word_bot") or "#1AE5FF"
    bg = pal.get("step_bg", "#0D1320")
    border = pal.get("step_border", "#1B2940")
    text = pal.get("title", "#EAF3FF")
    sub = pal.get("sub", "#7E93B8")
    badge_text = pal.get("badge_text", "#04141A")
    danger = pal.get("status_err") or "#F2707F"

    if role == PRIMARY:
        body = ("background:%s; color:%s; border:1px solid %s; font-weight:600;"
                % (accent, badge_text, accent))
        hover = "background:%s;" % accent
    elif role == DESTRUCTIVE:
        # outlined, never filled — rule 3
        body = ("background:transparent; color:%s; border:1px solid %s;"
                % (danger, danger))
        hover = "background:rgba(242,112,127,0.12);"
    else:
        body = ("background:%s; color:%s; border:1px solid %s;"
                % (bg, text, border))
        hover = "background:%s;" % pal.get("step_hover", "#131D2E")

    return ("%s { %s border-radius:6px; padding:7px 10px; text-align:left; }\n"
            "%s:hover { %s }\n"
            "%s:disabled { color:%s; border-color:%s; background:transparent; }"
            % (selector, body, selector, hover, selector, sub, border))


def check_one_primary(roles):
    """(ok, msg) — rule 2. Pass the roles of every button in one view."""
    n = sum(1 for r in roles if r == PRIMARY)
    if n == 0:
        return True, "no primary action (fine for a read-only view)"
    if n == 1:
        return True, "one primary action"
    return False, ("%d primary actions in one view — rule 2 says exactly one; "
                   "demote %d of them to secondary" % (n, n - 1))


# ── empty states (rule 4) ──────────────────────────────────────────────────

def empty_state(noun, action=None, *, plural=True):
    """The sentence that replaces a bare 0 or dash.

    empty_state("ONT", "Detect buildings") ->
        ("No ONTs yet", "Detect buildings to create them")
    """
    label = "No %s%s yet" % (noun, "s" if plural and not noun.endswith("s") else "")
    if not action:
        return label, ""
    a = action.strip()
    return label, "%s to create them" % (a[0].lower() + a[1:] if a else a)


def is_empty_display(value):
    """True if this value would render as a dead end (rule 4)."""
    if value is None:
        return True
    s = str(value).strip()
    return s in ("", "-", "--", "—", "–", "0", "0.0", "None", "n/a", "N/A")


# ── client vocabulary (rule 5) ─────────────────────────────────────────────

_CLIENT_CANON = {
    "fibertime": "Fibertime", "fibre time": "Fibertime", "fibretime": "Fibertime",
    "fibre_time": "Fibertime", "ft": "Fibertime",
    "herotel": "HeroTel", "hero tel": "HeroTel", "hero_tel": "HeroTel",
    "vuma": "Vuma", "vumatel": "Vuma", "vuma reach": "Vuma",
}

#: The order they are shown in, everywhere.
CLIENTS = ("Fibertime", "HeroTel", "Vuma")


def client_name(raw):
    """One spelling per client. Unknown input is returned trimmed, not guessed."""
    s = (raw or "").strip()
    return _CLIENT_CANON.get(s.lower().replace("-", " "), s)


# ── section labels (rule 6) ────────────────────────────────────────────────

def check_section_labels(labels):
    """(ok, msg) — no two sections in one view may share a label."""
    seen, dupes = set(), []
    for lab in labels:
        k = (lab or "").strip().lower()
        if not k:
            continue
        if k in seen and k not in dupes:
            dupes.append(k)
        seen.add(k)
    if not dupes:
        return True, "all section labels unique"
    return False, ("duplicate section label(s): %s — a label must name its "
                   "content, and two things cannot have the same name"
                   % ", ".join(repr(d) for d in dupes))


def section_label(text):
    """The house style for a section heading: '// WORKFLOW'."""
    return "// %s" % (text or "").strip().upper()


if __name__ == "__main__":
    import sys
    ok = True

    def t(cond, name):
        global ok
        print("   %s  %s" % ("PASS " if cond else "FAIL*", name))
        ok = ok and cond

    print("nexus_ui rules — self-test")
    # rule 1: the legend exception must survive every other rule
    t(role_for("\U0001f534  Feeder") == LEGEND, "Feeder -> LEGEND (map colour)")
    t(role_for("\U0001f7e2  Distribution 1") == LEGEND, "Distribution 1 -> LEGEND")
    t(button_qss(LEGEND, {}) == "", "LEGEND yields NO stylesheet (keeps its own)")
    # destructive by wording, even when today it is styled like anything else
    t(role_for("\U0001f5d1 Delete + Renumber  ·BETA") == DESTRUCTIVE,
      "Delete + Renumber -> DESTRUCTIVE")
    t(role_for("Clear") == DESTRUCTIVE, "Clear -> DESTRUCTIVE")
    t(role_for("Properties") == SECONDARY, "Properties -> SECONDARY")
    t(role_for("AutoNet", is_primary=True) == PRIMARY, "AutoNet -> PRIMARY when flagged")
    t(role_for("anything", explicit=SECONDARY) == SECONDARY, "explicit role wins")
    # a destructive word must NOT be able to be forced primary by accident
    t(role_for("Delete everything") == DESTRUCTIVE, "destructive beats default")
    # rule 2
    t(check_one_primary([PRIMARY, SECONDARY, SECONDARY])[0], "one primary is fine")
    t(not check_one_primary([PRIMARY, PRIMARY])[0], "two primaries rejected")
    t(check_one_primary([SECONDARY])[0], "zero primaries fine (read-only view)")
    # rule 4
    t(is_empty_display("—") and is_empty_display(0) and is_empty_display(""),
      "dash / 0 / blank all read as empty")
    t(not is_empty_display("798"), "a real number is not empty")
    lab, hint = empty_state("ONT", "Detect buildings")
    t(lab == "No ONTs yet" and hint == "detect buildings to create them",
      "empty_state builds the sentence")
    # rule 5
    t(client_name("FIBRE TIME") == "Fibertime", "FIBRE TIME -> Fibertime")
    t(client_name("herotel") == "HeroTel", "herotel -> HeroTel")
    t(client_name("Vumatel") == "Vuma", "Vumatel -> Vuma")
    t(client_name("Unknown Co") == "Unknown Co", "unknown client not guessed")
    # rule 6
    t(not check_section_labels(["WORKFLOW", "CLIENT SPEC", "WORKFLOW"])[0],
      "duplicate section label rejected (the live home-panel bug)")
    t(check_section_labels(["IN THIS PROJECT", "NEXT STEP"])[0],
      "distinct labels accepted")
    t(section_label("next step") == "// NEXT STEP", "house style label")

    print("SELF-TEST:", "ALL PASS" if ok else "FAILURES")
    sys.exit(0 if ok else 1)
