"""Dock widget for FTTH Plan Tool."""

import os
import sip
import time
import colorsys

from qgis.PyQt import QtWidgets, uic
from qgis.PyQt.QtCore import pyqtSignal, QMetaType, Qt
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtWidgets import QApplication
from qgis.core import (
    QgsVectorLayer, QgsWkbTypes, QgsProject, QgsGeometry, QgsPointXY,
    QgsFeature, QgsField, QgsUnitTypes, QgsSpatialIndex, QgsRectangle,
    QgsFillSymbol, QgsMarkerSymbol, QgsSingleSymbolRenderer,
    QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsLineSymbol,
    QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
    QgsVectorLayerSimpleLabeling, QgsCoordinateTransform,
)
from qgis.gui import QgsMapLayerComboBox, QgsMapToolEmitPoint, QgsMapTool, QgsRubberBand

from .layer_utils import (
    get_layer_features,
    get_point_coordinates,
    get_linestring_coordinates,
    create_memory_layer,
    add_fields_to_layer,
    add_line_feature,
    count_features_by_geometry_type,
    get_layer_extent
)
from .core import NetworkGraph, _snap_coord
from .erf_grouping import (
    get_batch_statistics,
    find_optimal_splitter_locations,
    cluster_tight_groups_of_8,
    group_zones_from_groups,
    SKLEARN_AVAILABLE,
    NUMPY_AVAILABLE
)

# Cable profile functions (embedded until cable_profiles.py can be created)
import math
import bisect

CABLE_PROFILES = [2, 4, 6, 12, 24, 36, 48, 72, 96, 144, 288]
PROFILE_TYPE_DEFAULT = 'default'
PROFILE_TYPE_POPC = 'popc'
PROFILE_TYPE_OPERATOR = 'operator'

def get_cable_profile(demand, profile_type=PROFILE_TYPE_DEFAULT, reserve_percent=0.0):
    """Select smallest cable profile that accommodates demand."""
    if demand <= 0:
        return CABLE_PROFILES[0]
    if profile_type == PROFILE_TYPE_POPC:
        effective_demand = math.ceil(demand * 1.30)
    elif profile_type == PROFILE_TYPE_OPERATOR:
        return _get_operator_profile(demand)
    else:
        if reserve_percent > 0:
            effective_demand = math.ceil(demand * (1 + reserve_percent / 100))
        else:
            effective_demand = demand
    return _select_profile(effective_demand)

def _select_profile(demand):
    """Select smallest cable profile >= demand."""
    if demand <= 0:
        return CABLE_PROFILES[0]
    if demand in CABLE_PROFILES:
        return demand
    idx = bisect.bisect_right(CABLE_PROFILES, demand)
    if idx < len(CABLE_PROFILES):
        return CABLE_PROFILES[idx]
    else:
        return CABLE_PROFILES[-1]

def _get_operator_profile(demand):
    """Operator-specific cable thresholds."""
    if demand <= 9:
        return 12
    elif demand <= 20:
        return 24
    elif demand <= 40:
        return 48
    elif demand <= 60:
        return 72
    elif demand <= 80:
        return 96
    elif demand <= 120:
        return 144
    elif demand <= 180:
        return 216
    else:
        return 288

def format_cable_profile(profile):
    """Format cable profile as '48F', '144F', etc."""
    return f"{profile}F"


# ---------------------------------------------------------------------------
# Client profiles — network design parameters per operator
# ---------------------------------------------------------------------------
CLIENT_PROFILES = {
    "Herotel": {
        "max_pon_size": 128,
        "target_pon_size": 96,
        "splitter_ratio_feeder": "1:16",
        "splitter_ratio_dist": "1:8",
        "max_feeder_cable_fibres": 144,
        "feeder_pole_height_m": 7,
        "dist_pole_height_m": 6,
        "max_span_m": 70,
        "max_drop_length_m": 150,
        "description": "Herotel GPON — high-density, cascaded 1:16×1:8 split",
    },
    "Vuma": {
        "max_pon_size": 64,
        "target_pon_size": 48,
        "splitter_ratio_feeder": "1:32",
        "splitter_ratio_dist": "1:4",
        "max_feeder_cable_fibres": 96,
        "feeder_pole_height_m": 7,
        "dist_pole_height_m": 5,
        "max_span_m": 60,
        "max_drop_length_m": 100,
        "description": "Vuma FTTH — standard 1:32 split, 64-unit PON",
    },
    "Fibertime": {
        "max_pon_size": 96,
        "target_pon_size": 72,
        "splitter_ratio_feeder": "1:16",
        "splitter_ratio_dist": "1:4",
        "max_feeder_cable_fibres": 96,
        "feeder_pole_height_m": 7,
        "dist_pole_height_m": 5,
        "max_span_m": 70,
        "max_drop_length_m": 120,
        "description": "Fibertime GPON — balanced 1:16×1:4 split, 96-unit PON",
    },
}


FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'forms', 'dockwidget_base.ui'))


# ---------------------------------------------------------------------------
# Span-network routing helpers (used by Generate Drop Cables)
# ---------------------------------------------------------------------------

def _find_seg_index(pts, snap_pt):
    """Return (i, t) — index of sub-segment and fractional position along it
    where snap_pt is closest to the polyline defined by *pts*.
    """
    import math
    min_d = float('inf')
    best_i, best_t = 0, 0.0
    for i in range(len(pts) - 1):
        ax, ay = pts[i].x(), pts[i].y()
        bx, by = pts[i + 1].x(), pts[i + 1].y()
        dx, dy = bx - ax, by - ay
        seg_sq = dx * dx + dy * dy
        if seg_sq > 1e-20:
            t = max(0.0, min(1.0,
                ((snap_pt.x() - ax) * dx + (snap_pt.y() - ay) * dy) / seg_sq))
        else:
            t = 0.0
        cx, cy = ax + t * dx, ay + t * dy
        d = math.sqrt((snap_pt.x() - cx) ** 2 + (snap_pt.y() - cy) ** 2)
        if d < min_d:
            min_d, best_i, best_t = d, i, t
    return best_i, best_t


def _build_span_routing_graph(span_feats):
    """Build a NetworkX graph of the span network.

    Nodes  : (round(x, 4), round(y, 4)) tuples for segment endpoints.
    Edges  : one per span feature, carrying *pts* (vertex list) and *weight* (length).
    Returns: (G, seg_ep) where seg_ep[fid] = (start_node, end_node, [QgsPointXY …]).
    """
    import networkx as nx
    from qgis.core import QgsPointXY

    G = nx.Graph()
    seg_ep = {}
    for fid, feat in span_feats.items():
        geom = feat.geometry()
        if not geom or geom.isEmpty():
            continue
        pts = [QgsPointXY(v.x(), v.y()) for v in geom.vertices()]
        if len(pts) < 2:
            continue
        n_s = (round(pts[0].x(), 4), round(pts[0].y(), 4))
        n_e = (round(pts[-1].x(), 4), round(pts[-1].y(), 4))
        length = geom.length()
        if not G.has_edge(n_s, n_e) or G[n_s][n_e]['weight'] > length:
            G.add_edge(n_s, n_e, weight=length, fid=fid, pts=pts)
        seg_ep[fid] = (n_s, n_e, pts)
    return G, seg_ep


def _span_route_pts(snap_a, fid_a, snap_b, fid_b, G, seg_ep):
    """Return [QgsPointXY, …] following the span network from *snap_a* to *snap_b*.

    The list includes *snap_a* and *snap_b*.  Returns *None* if no path exists.
    """
    import networkx as nx
    import math

    n_sa, n_ea, pts_a = seg_ep[fid_a]
    n_sb, n_eb, pts_b = seg_ep[fid_b]
    i_a, _ = _find_seg_index(pts_a, snap_a)
    i_b, _ = _find_seg_index(pts_b, snap_b)

    # ---- Same segment: extract the portion between the two snap points -----
    if fid_a == fid_b:
        # Determine which snap is earlier along the segment
        def _along(pts, idx):
            return sum(math.dist((pts[j].x(), pts[j].y()),
                                 (pts[j + 1].x(), pts[j + 1].y()))
                       for j in range(idx))
        if _along(pts_a, i_a) <= _along(pts_a, i_b):
            return [snap_a] + pts_a[i_a + 1:i_b + 1] + [snap_b]
        else:
            return [snap_a] + list(reversed(pts_a[i_b + 1:i_a + 1])) + [snap_b]

    # ---- Different segments: route via endpoint graph ----------------------
    best_path, best_cost = None, float('inf')
    for da in [n_sa, n_ea]:
        for db in [n_sb, n_eb]:
            try:
                plen = nx.shortest_path_length(G, da, db, weight='weight')
                pnodes = nx.shortest_path(G, da, db, weight='weight')
            except Exception:
                continue
            cost = (plen
                    + math.dist(da, (snap_a.x(), snap_a.y()))
                    + math.dist(db, (snap_b.x(), snap_b.y())))
            if cost < best_cost:
                best_cost, best_path = cost, (pnodes, da, db)

    if best_path is None:
        return None

    pnodes, da, db = best_path
    result = [snap_a]

    # Part 1: snap_a → da along segment A
    if da == n_ea:
        result.extend(pts_a[i_a + 1:])               # forward to end
    else:
        result.extend(reversed(pts_a[:i_a + 1]))     # backward to start

    # Part 2: traverse path_nodes da → … → db
    for k in range(len(pnodes) - 1):
        n1, n2 = pnodes[k], pnodes[k + 1]
        ed = G[n1][n2]
        eps = ed['pts']
        en_s = (round(eps[0].x(), 4), round(eps[0].y(), 4))
        if n1 == en_s:
            result.extend(eps[1:])           # forward  — skip eps[0] (= n1, already added)
        else:
            result.extend(reversed(eps[:-1]))  # backward — skip eps[-1] (= n1, already added)

    # Part 3: db → snap_b along segment B  (db is already the last element)
    if db == n_sb:
        result.extend(pts_b[1:i_b + 1])              # forward from start
    else:
        result.extend(reversed(pts_b[i_b + 1:-1]))   # backward from end
    result.append(snap_b)

    return result

# ---------------------------------------------------------------------------


class AutoNetProgressDialog(QtWidgets.QDialog):
    """Modal progress dialog shown while AutoNet pipeline runs.

    Displays a scrolling log, per-step progress bar, elapsed timer and a
    Close button that is only enabled once the pipeline finishes.
    """

    STEP_LABELS = [
        "Detecting layers…",
        "Step 1/5 — Generate PON Groups",
        "Step 2/5 — Generate Demand Points",
        "Step 3/5 — Generate Group Boundaries",
        "Step 4/5 — Generate Splitter Points",
        "Step 5/5 — Generate Drops PTP",
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("⚡ AutoNet — Pipeline Progress")
        self.setMinimumWidth(560)
        self.setMinimumHeight(420)
        self.setModal(True)

        from qgis.PyQt.QtWidgets import (
            QVBoxLayout, QHBoxLayout, QLabel, QTextEdit,
            QProgressBar, QPushButton, QSizePolicy,
        )
        from qgis.PyQt.QtGui import QFont

        root = QVBoxLayout(self)
        root.setSpacing(6)
        root.setContentsMargins(10, 10, 10, 10)

        # ── Step label ────────────────────────────────────────────────
        self._step_lbl = QLabel("Initialising…")
        self._step_lbl.setStyleSheet("font-weight: bold; color: #1a5276; font-size: 11px;")
        root.addWidget(self._step_lbl)

        # ── Progress bar ──────────────────────────────────────────────
        self._prog = QProgressBar()
        self._prog.setRange(0, 100)
        self._prog.setValue(0)
        self._prog.setTextVisible(True)
        self._prog.setFixedHeight(18)
        self._prog.setStyleSheet(
            "QProgressBar{border:1px solid #aaa;border-radius:4px;background:#f0f0f0;}"
            "QProgressBar::chunk{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,"
            "stop:0 #2196F3,stop:1 #21CBF3);border-radius:3px;}"
        )
        root.addWidget(self._prog)

        # ── Timer row ─────────────────────────────────────────────────
        timer_row = QHBoxLayout()
        self._timer_lbl = QLabel("⏱ 0s")
        self._timer_lbl.setStyleSheet("color: #555; font-size: 10px;")
        timer_row.addWidget(self._timer_lbl)
        timer_row.addStretch()
        root.addLayout(timer_row)

        # ── Log / terminal output ─────────────────────────────────────
        self._log = QTextEdit()
        self._log.setReadOnly(True)
        self._log.setLineWrapMode(QTextEdit.NoWrap)
        font = QFont("Consolas", 9)
        if not font.exactMatch():
            font = QFont("Courier New", 9)
        self._log.setFont(font)
        self._log.setStyleSheet(
            "QTextEdit{background:#1e1e1e; color:#d4d4d4; border:1px solid #333;}"
        )
        self._log.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        root.addWidget(self._log, 1)

        # ── Close button (disabled until done) ───────────────────────
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        self._close_btn = QPushButton("Close")
        self._close_btn.setEnabled(False)
        self._close_btn.setFixedWidth(100)
        self._close_btn.setStyleSheet(
            "QPushButton{background:#2196F3;color:white;border-radius:4px;padding:4px 12px;}"
            "QPushButton:disabled{background:#aaa;color:#ddd;}"
            "QPushButton:hover:!disabled{background:#1565C0;}"
        )
        self._close_btn.clicked.connect(self.accept)
        btn_row.addWidget(self._close_btn)
        root.addLayout(btn_row)

        # ── Internal timer ────────────────────────────────────────────
        from qgis.PyQt.QtCore import QTimer
        self._t0 = time.time()
        self._tick_timer = QTimer(self)
        self._tick_timer.setInterval(500)
        self._tick_timer.timeout.connect(self._on_tick)
        self._tick_timer.start()

    # ------------------------------------------------------------------
    def _on_tick(self):
        elapsed = time.time() - self._t0
        if elapsed >= 3600:
            s = f"{int(elapsed // 3600)}h {int((elapsed % 3600) // 60)}m"
        elif elapsed >= 60:
            s = f"{int(elapsed // 60)}m {int(elapsed % 60)}s"
        else:
            s = f"{elapsed:.1f}s"
        pct = self._prog.value()
        if pct > 0:
            eta = elapsed * (100 - pct) / pct
            if eta >= 60:
                eta_s = f" | ETA ~{int(eta // 60)}m {int(eta % 60)}s"
            else:
                eta_s = f" | ETA ~{eta:.0f}s"
        else:
            eta_s = ""
        self._timer_lbl.setText(f"⏱ {s}{eta_s}")

    def set_step(self, step: int, label: str = ""):
        """Update step label and progress bar (step 0..5, TOTAL_STEPS=5)."""
        TOTAL = 5
        pct = int(step / TOTAL * 100) if step <= TOTAL else 100
        self._prog.setValue(pct)
        text = label or (self.STEP_LABELS[step] if step < len(self.STEP_LABELS) else "")
        self._step_lbl.setText(text)
        QApplication.processEvents()

    def append_log(self, message: str):
        """Append a line to the log area and auto-scroll."""
        self._log.append(message)
        sb = self._log.verticalScrollBar()
        sb.setValue(sb.maximum())
        QApplication.processEvents()

    def mark_complete(self, success: bool = True):
        """Called when the pipeline finishes."""
        self._tick_timer.stop()
        self._on_tick()  # final time update
        if success:
            elapsed = time.time() - self._t0
            self._step_lbl.setText(f"⚡ AutoNet Complete ✓  ({self._timer_lbl.text().replace('⏱ ', '')})")
            self._step_lbl.setStyleSheet("font-weight: bold; color: #1e8449; font-size: 11px;")
            self._prog.setValue(100)
        else:
            self._step_lbl.setText("⚠ AutoNet encountered errors — see log")
            self._step_lbl.setStyleSheet("font-weight: bold; color: #c0392b; font-size: 11px;")
        self._close_btn.setEnabled(True)
        self._close_btn.setFocus()
        QApplication.processEvents()

    def mark_error(self, msg: str = ""):
        self._tick_timer.stop()
        self._step_lbl.setText(f"❌ Error: {msg}")
        self._step_lbl.setStyleSheet("font-weight: bold; color: #c0392b; font-size: 11px;")
        self._close_btn.setEnabled(True)
        self._close_btn.setFocus()
        QApplication.processEvents()


class PonPolygonSelectTool(QgsMapTool):
    """Rubber-band polygon map tool for PON-per-PON dual-layer selection.

    Left-click  → add vertex to polygon.
    Right-click → complete polygon and select intersecting features on both layers.
    Escape      → cancel.
    """

    selection_complete = pyqtSignal(object, object)  # (demand_layer, span_layer)
    cancelled = pyqtSignal()

    def __init__(self, canvas, demand_lyr, span_lyr):
        super().__init__(canvas)
        self._demand_lyr = demand_lyr
        self._span_lyr = span_lyr
        self._points = []

        self._rb = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.PolygonGeometry)
        self._rb.setColor(QColor(255, 165, 0, 90))
        self._rb.setStrokeColor(QColor(200, 120, 0, 220))
        self._rb.setWidth(2)

    # ------------------------------------------------------------------ events
    def canvasPressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            pt = self.toMapCoordinates(event.pos())
            self._points.append(pt)
            self._rb.addPoint(pt, True)
        elif event.button() == Qt.MouseButton.RightButton:
            self._finish()

    def canvasMoveEvent(self, event):
        if self._points:
            pt = self.toMapCoordinates(event.pos())
            self._rb.movePoint(pt)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self._reset()
            self.cancelled.emit()

    # ------------------------------------------------------------------ logic
    def _finish(self):
        if len(self._points) < 3:
            self._reset()
            self.cancelled.emit()
            return

        poly_geom = QgsGeometry.fromPolygonXY([self._points])
        self._reset()

        # Select intersecting features on both layers
        for lyr in (self._demand_lyr, self._span_lyr):
            if lyr:
                lyr.removeSelection()
                ids = [
                    f.id()
                    for f in lyr.getFeatures()
                    if f.geometry() and f.geometry().intersects(poly_geom)
                ]
                lyr.selectByIds(ids)

        self.selection_complete.emit(self._demand_lyr, self._span_lyr)

    def _reset(self):
        self._rb.reset(QgsWkbTypes.GeometryType.PolygonGeometry)
        self._points = []

    def deactivate(self):
        self._reset()
        super().deactivate()


class FTTHPlanToolDockWidget(QtWidgets.QDockWidget, FORM_CLASS):
    """Dock widget for the FTTH Plan Tool plugin."""

    closingPlugin = pyqtSignal()

    def __init__(self, iface, parent=None):
        """Constructor.
        
        Args:
            iface: QGIS interface instance
            parent: Parent widget
        """
        super(FTTHPlanToolDockWidget, self).__init__(parent)
        self.setupUi(self)
        # Header (ticket #50): plain "Network Planner" — no "Velocity", no version.
        self.setWindowTitle("Network Planner")
        self.iface = iface
        self.network_graph = None
        self.result_layer = None
        self.grouped_layer = None
        self.demand_points_layer = None
        self.splitter_points_layer = None
        self.zone_boundaries_layer = None  # step 3 output — stored for PON-per-PON merge
        self.drop_ptp_layer = None          # step 5 output — stored for PON-per-PON merge
        self._op_last_pct = -1
        self._strip_gen = 0
        self.active_client = None
        self._cancel_requested = False  # set to True by Kill button to abort running operations
        # PON-per-PON state: tracks run count and cumulative zone/group offsets
        self._pon_batch_count   = 0   # increments each completed PON-per-PON run
        self._pon_zone_offset   = 0   # running max zone_id across all runs
        self._pon_group_offset  = 0   # running max group_id across all runs
        self._current_batch_label = None  # set during autonet run, used by steps 4 & 5
        self._pon_full_span_layer = None  # full (unfiltered) span layer preserved for splitter snapping
        self._pon_color_offset = 0.0  # hue offset for zone polygon colors (rotates per batch)
        # PON-per-PON persistent accumulator layers (append-only across batches)
        self._pon_accum_groups    = None  # "PON Groups" — all grouped demand points
        self._pon_accum_zones     = None  # "PON Zone Boundaries" — all zone polygons
        self._pon_accum_splitters = None  # "PON Splitter Points" — all splitters
        self._pon_accum_drops     = None  # "PON Drop Cables" — all drop lines
        # When True, the NEXT PON-per-PON run will start a fresh session (new layers,
        # counters reset to 1).  Accumulators are NOT nulled on cancel so that Manual
        # Override can continue editing the existing layers after the button is closed.
        self._pon_new_session_needed = False

        # --- Progress strip (inserted above textEdit_output) ---
        from qgis.PyQt.QtWidgets import QWidget as _QW, QHBoxLayout as _QHL, QProgressBar as _QPB, QLabel as _QL, QPushButton as _QPBS
        from qgis.PyQt.QtCore import QTimer as _QTm
        self._prog_strip = _QW()
        self._prog_strip.setFixedHeight(30)
        _ps_lay = _QHL(self._prog_strip)
        _ps_lay.setContentsMargins(4, 3, 4, 3)
        _ps_lay.setSpacing(6)
        self._prog_op_lbl = _QL("Processing...")
        self._prog_op_lbl.setStyleSheet("font-weight: bold; color: #2a6ebb;")
        _ps_lay.addWidget(self._prog_op_lbl)
        self._prog_bar = _QPB()
        self._prog_bar.setRange(0, 100)
        self._prog_bar.setValue(0)
        self._prog_bar.setTextVisible(False)
        self._prog_bar.setFixedHeight(14)
        self._prog_bar.setStyleSheet(
            "QProgressBar{border:1px solid #bbb;border-radius:4px;background:#f0f0f0;}"
            "QProgressBar::chunk{background:#2a6ebb;border-radius:3px;}"
        )
        _ps_lay.addWidget(self._prog_bar, 1)
        self._prog_time_lbl = _QL("0s")
        self._prog_time_lbl.setMinimumWidth(140)
        self._prog_time_lbl.setStyleSheet("color: #444; font-size: 9pt;")
        _ps_lay.addWidget(self._prog_time_lbl)
        # Kill / cancel button — stops any running operation
        self._prog_kill_btn = _QPBS("✕ Kill")
        self._prog_kill_btn.setFixedHeight(22)
        self._prog_kill_btn.setStyleSheet(
            "QPushButton{background:#c0392b;color:white;font-weight:bold;"
            "border-radius:3px;padding:0 8px;font-size:9pt;}"
            "QPushButton:hover{background:#e74c3c;}"
        )
        self._prog_kill_btn.setToolTip("Cancel the current operation")
        self._prog_kill_btn.clicked.connect(self._on_kill_clicked)
        _ps_lay.addWidget(self._prog_kill_btn)
        self._prog_strip.setVisible(False)
        _main_lay = self.dockWidgetContents.layout()
        for _i in range(_main_lay.count()):
            _item = _main_lay.itemAt(_i)
            if _item and _item.widget() is self.textEdit_output:
                _main_lay.insertWidget(_i, self._prog_strip)
                break

        # Hide the terminal log panel — output is shown in the AutoNet popup dialog
        self.textEdit_output.setVisible(False)
        self.textEdit_output.setMaximumHeight(0)
        self._prog_timer = _QTm(self)
        self._prog_timer.setInterval(500)
        self._prog_timer.timeout.connect(self._op_tick)
        self.active_client_profile = None

        # Connect client profile button
        self.pushButton_set_client.clicked.connect(self.on_set_client_clicked)
        self.pushButton_calculate.clicked.connect(self.on_calculate_clicked)
        self.pushButton_clear.clicked.connect(self.on_clear_clicked)
        self.pushButton_build_graph.clicked.connect(self.on_build_graph_clicked)
        self.pushButton_analyze.clicked.connect(self.on_analyze_clicked)
        self.pushButton_group_erven.clicked.connect(self.on_cluster_erven_clicked)
        self.pushButton_generate_demand_points.clicked.connect(self.on_generate_demand_points_clicked)
        self.pushButton_show_batch_stats.clicked.connect(self.on_show_batch_stats_clicked)
        self.pushButton_generate_boundaries.clicked.connect(self.on_generate_boundaries_clicked)
        self.pushButton_generate_splitters.clicked.connect(self.on_generate_splitters_clicked)
        self.pushButton_generate_drop_lashed.clicked.connect(self.on_generate_drop_lashed_clicked)
        self.pushButton_generate_drop_ptp.clicked.connect(self.on_generate_drop_ptp_clicked)
        self.pushButton_generate_aggregation_points.clicked.connect(self.on_generate_aggregation_points_clicked)
        self.pushButton_manual_override.clicked.connect(self.on_manual_override_clicked)
        self.pushButton_validate_span_network.clicked.connect(self.on_validate_span_network_clicked)
        self.pushButton_generate_feeder_routes.clicked.connect(self.on_generate_feeder_routes_clicked)
        self.pushButton_generate_poles.clicked.connect(self.on_generate_poles_clicked)
        self.pushButton_span_evaluate.clicked.connect(self.on_span_evaluate_clicked)
        self.pushButton_span_evaluate.setStyleSheet(
            "QPushButton { background-color: #2e4057; color: white; font-weight: bold; "
            "border-radius: 3px; padding: 3px; }"
            "QPushButton:hover { background-color: #3d5270; }"
            "QPushButton:pressed { background-color: #1e2d3e; }"
        )
        self.pushButton_restore_span_backup.clicked.connect(self.on_restore_span_backup_clicked)
        self.pushButton_restore_span_backup.setStyleSheet(
            "QPushButton { background-color: #7a3b2e; color: white; font-weight: bold; "
            "border-radius: 3px; padding: 3px; }"
            "QPushButton:hover { background-color: #9c4c3b; }"
            "QPushButton:pressed { background-color: #5c2c22; }"
            "QPushButton:disabled { background-color: #cccccc; color: #888888; }"
        )
        self.pushButton_explode_span.clicked.connect(self.on_explode_span_clicked)
        self.pushButton_explode_span.setStyleSheet(
            "QPushButton { background-color: #4a3060; color: white; font-weight: bold; "
            "border-radius: 3px; padding: 3px; }"
            "QPushButton:hover { background-color: #5e3d7a; }"
            "QPushButton:pressed { background-color: #36224a; }"
        )
        self._span_snap_backup = None   # {layer_id, layer_name, features: {fid: wkt}}

        # Hide buttons not needed at this stage
        self.pushButton_validate_span_network.setVisible(False)
        self.pushButton_show_batch_stats.setVisible(False)

        # ── Reorganize Generate PON groupbox layout ──────────────────────────
        # Final order:  [AutoNet] [ManualNet] [Manual Override] [_manual_section (hidden)]
        # _manual_section contains: form rows + all step buttons (shown on ManualNet toggle)
        from qgis.PyQt.QtWidgets import QPushButton as _QPB2, QWidget as _QW2, QVBoxLayout as _QVB2

        gb_layout = self.groupBox_4.layout()   # QVBoxLayout from UI file

        # 1. Drain ALL existing items from the groupBox layout (keeps widgets alive via parent)
        _gb_items = []
        while gb_layout.count():
            _item = gb_layout.takeAt(0)
            _w = _item.widget()
            _l = _item.layout()
            if _w:
                _gb_items.append(('widget', _w))
            elif _l:
                _gb_items.append(('layout', _l))

        # 2. Build _manual_section container for all items EXCEPT Manual Override
        self._manual_section = _QW2()
        self._manual_section.setObjectName("manualSection")
        _ms_lay = _QVB2(self._manual_section)
        _ms_lay.setContentsMargins(0, 0, 0, 0)
        _ms_lay.setSpacing(gb_layout.spacing())

        for _kind, _item in _gb_items:
            if _kind == 'widget' and _item is self.pushButton_manual_override:
                continue  # placed separately below
            if _kind == 'layout':
                _ms_lay.addLayout(_item)
            else:
                _ms_lay.addWidget(_item)

        # Extract ONLY the property fields (Demand / Method / Route / Road / Span
        # Corridor = formLayout_2) into a separate collapsible section that opens &
        # closes directly UNDER the 🔧 Properties button (ticket #38). The rest of
        # the manual section (Refresh Layers, Individual Steps, Sum buttons) stays
        # where it is and remains always visible.
        self._props_section = _QW2()
        self._props_section.setObjectName("propsSection")
        _ps_lay = _QVB2(self._props_section)
        _ps_lay.setContentsMargins(0, 0, 0, 0)
        _ps_lay.setSpacing(gb_layout.spacing())
        _ms_lay.removeItem(self.formLayout_2)     # take the 5 fields out of the manual block
        _ps_lay.addLayout(self.formLayout_2)      # …and into the Properties dropdown
        self._props_section.setVisible(False)     # collapsed by default (Properties off)
        self._manual_section.setVisible(True)     # the rest stays visible

        # ── 🔄 Refresh button (top of Properties) — re-detect project layers ──
        self._btn_refresh_props = _QPB2("🔄 Reload Layers")
        self._btn_refresh_props.setToolTip(
            "Re-scan the project and auto-detect the demand / route / road layers "
            "into the dropdowns — use after you add, rename or reload layers.")
        self._btn_refresh_props.setStyleSheet(
            "QPushButton { background-color: #0e7490; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #0891b2; }"
            "QPushButton:pressed { background-color: #155e75; }")
        self._btn_refresh_props.clicked.connect(self._refresh_properties)
        _ms_lay.insertWidget(0, self._btn_refresh_props)

        # ── "Sum Span Distance" button — added at the bottom of the manual section
        self._btn_sum_span = _QPB2("📏 Sum Span Distance")
        self._btn_sum_span.setToolTip(
            "Calculate the total length of all features in the selected Span (Route) layer.")
        self._btn_sum_span.setStyleSheet(
            "QPushButton { background-color: #5d4e8c; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #7060a8; }"
            "QPushButton:pressed { background-color: #46387a; }"
        )
        self._btn_sum_span.clicked.connect(self.on_sum_span_distance_clicked)
        _ms_lay.addWidget(self._btn_sum_span)

        # ── "Sum Pole Numbers" button
        self._btn_sum_poles = _QPB2("🔢 Sum Pole Numbers")
        self._btn_sum_poles.setToolTip(
            "Count the total number of poles across all Poles layers in the project.")
        self._btn_sum_poles.setStyleSheet(
            "QPushButton { background-color: #7a4a1e; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #9a5e28; }"
            "QPushButton:pressed { background-color: #5c3716; }"
        )
        self._btn_sum_poles.clicked.connect(self.on_sum_pole_numbers_clicked)
        _ms_lay.addWidget(self._btn_sum_poles)

        # ── "Sum Demand Points" button
        self._btn_sum_demand = _QPB2("🏠 Sum Demand Points")
        self._btn_sum_demand.setToolTip(
            "Count the total number of demand points in the Demand Points layer.")
        self._btn_sum_demand.setStyleSheet(
            "QPushButton { background-color: #1a5276; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #2471a3; }"
            "QPushButton:pressed { background-color: #154360; }"
        )
        self._btn_sum_demand.clicked.connect(self.on_sum_demand_points_clicked)
        _ms_lay.addWidget(self._btn_sum_demand)

        # ── "AutoSum" button
        self._btn_autosum = _QPB2("🧮 AutoSum")
        self._btn_autosum.setToolTip(
            "Calculate Span Distance + Pole Count + Demand Point Count and show all results in one window.")
        self._btn_autosum.setStyleSheet(
            "QPushButton { background-color: #4a235a; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 4px; }"
            "QPushButton:hover { background-color: #6c3483; }"
            "QPushButton:pressed { background-color: #381748; }"
        )
        self._btn_autosum.clicked.connect(self.on_auto_sum_clicked)
        _ms_lay.addWidget(self._btn_autosum)

        self._btn_autonet = _QPB2("⚡ AutoNet")
        self._btn_autonet.setToolTip(
            "Auto-detect layers and run the full pipeline:\n"
            "Generate PON Groups → Demand Points → Group Boundaries → Splitter Points → Drops PTP"
        )
        self._btn_autonet.setStyleSheet(
            "QPushButton { background-color: #1a6b3c; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #238a4f; }"
            "QPushButton:pressed { background-color: #145230; }"
        )
        self._btn_autonet.clicked.connect(self.on_autonet_clicked)

        # 4. ManualNet toggle button
        self._btn_manualnet = _QPB2("🔧 Properties")
        self._btn_manualnet.setCheckable(True)
        self._btn_manualnet.setChecked(False)
        self._btn_manualnet.setToolTip("Show / hide manual step controls")
        self._btn_manualnet.setStyleSheet(
            "QPushButton { background-color: #2a5b8a; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #336fa5; }"
            "QPushButton:pressed { background-color: #1f4468; }"
            "QPushButton:checked { background-color: #1f4468; }"
        )
        self._btn_manualnet.toggled.connect(
            lambda checked: self._props_section.setVisible(checked)
        )

        # 5. Output GeoPackage row (always visible — path stored inside the .qgz project file)
        from qgis.PyQt.QtWidgets import (QWidget as _QW3, QHBoxLayout as _QHL3,
                                         QLabel as _QL3, QLineEdit as _QLE3,
                                         QToolButton as _QTB3)
        from qgis.PyQt.QtCore import QSize as _QSz3

        _gpkg_row = _QW3()
        _gpkg_hl = _QHL3(_gpkg_row)
        _gpkg_hl.setContentsMargins(2, 2, 2, 2)
        _gpkg_hl.setSpacing(4)
        _gpkg_lbl = _QL3("Output GPKG:")
        _gpkg_lbl.setStyleSheet("font-size: 8pt; color: #444;")
        _gpkg_hl.addWidget(_gpkg_lbl)
        self._output_gpkg_edit = _QLE3()
        self._output_gpkg_edit.setPlaceholderText("(scratch — set file to persist layers)")
        self._output_gpkg_edit.setToolTip(
            "GeoPackage where ALL output layers are saved.\n"
            "Set once per project — layers reload automatically when project is reopened.")
        self._output_gpkg_edit.setStyleSheet("font-size: 8pt;")
        _gpkg_hl.addWidget(self._output_gpkg_edit, 1)
        _gpkg_btn = _QTB3()
        _gpkg_btn.setText("📁")
        _gpkg_btn.setFixedSize(_QSz3(26, 22))
        _gpkg_btn.setToolTip("Browse for output GeoPackage file")
        _gpkg_hl.addWidget(_gpkg_btn)

        _gpkg_btn.clicked.connect(self._browse_gpkg_path)

        # textChanged fires on every keystroke AND after setText — use it to always persist
        self._output_gpkg_edit.textChanged.connect(self._save_gpkg_path)

        # Load path whenever a project is opened or created
        from qgis.core import QgsProject as _QP4
        _QP4.instance().readProject.connect(self._reload_gpkg_path)
        _QP4.instance().cleared.connect(self._clear_gpkg_path)

        # ── "PON per PON Manual" button ────────────────────────────────
        self._btn_pon_per_pon = _QPB2("🎯 PON per PON Manual")
        self._btn_pon_per_pon.setToolTip(
            "Select a subset of Span features and Demand Points on the map,\n"
            "then run the full AutoNet pipeline on only those selected features.\n"
            "Repeat for each PON area individually."
        )
        self._btn_pon_per_pon.setStyleSheet(
            "QPushButton { background-color: #7d4e00; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #a06300; }"
            "QPushButton:pressed { background-color: #5a3800; }"
            "QPushButton:checked { background-color: #5a3800; }"
        )
        self._btn_pon_per_pon.setCheckable(True)
        self._btn_pon_per_pon.clicked.connect(self.on_pon_per_pon_clicked)
        self._pon_per_pon_active = False   # track whether we're in selection mode

        # 6. Rebuild layout: GPKG row → Properties (top, per request) → AutoNet → PON per PON → Manual Override → Create Enclosure → collapsible section
        gb_layout.addWidget(_gpkg_row)
        gb_layout.addWidget(self._btn_manualnet)        # 🔧 Properties — moved to top
        gb_layout.addWidget(self._props_section)        # 5 config fields collapse right under Properties
        gb_layout.addWidget(self._btn_autonet)
        gb_layout.addWidget(self._btn_pon_per_pon)
        # Ticket #42 — all override buttons light blue (shared style)
        _OVERRIDE_BTN_QSS = (
            "QPushButton { background-color: #4FC3F7; color: #06283D; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover   { background-color: #81D4FA; }"
            "QPushButton:pressed { background-color: #29B6F6; }"
        )
        self.pushButton_manual_override.setStyleSheet(_OVERRIDE_BTN_QSS)
        gb_layout.addWidget(self.pushButton_manual_override)

        # ── "Manual Override Final" — works on any existing saved layers ──
        self._btn_override_final = _QPB2("✏️ Manual Override Final")
        self._btn_override_final.setToolTip(
            "Edit existing saved PON layers: move/add/delete splitters, reassign demands, "
            "update zones and drop cables.")
        self._btn_override_final.setStyleSheet(_OVERRIDE_BTN_QSS)
        self._btn_override_final.clicked.connect(self.on_manual_override_final_clicked)
        gb_layout.addWidget(self._btn_override_final)


        self._btn_create_enclosure = _QPB2("📍 Create Enclosure")
        self._btn_create_enclosure.setToolTip("Manually place a Feeder Splice or First Tier Splitter Splice enclosure on the map")
        self._btn_create_enclosure.setStyleSheet(
            "QPushButton { background-color: #2d6e2d; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #3d8f3d; }"
            "QPushButton:pressed { background-color: #1f4f1f; }"
            "QPushButton:checked { background-color: #1f4f1f; border: 2px solid #90ee90; }"
        )
        self._btn_create_enclosure.setCheckable(True)
        self._btn_create_enclosure.clicked.connect(self.on_create_enclosure_clicked)
        self._create_enclosure_tool = None   # holds active map tool
        self._create_enclosure_type = None   # 'FS' or 'FTS'
        gb_layout.addWidget(self._btn_create_enclosure)

        # ── "Create Span" manual line drawing button ──────────────────────
        self._btn_create_span = _QPB2("📐 Create Span")
        self._btn_create_span.setToolTip("Manually draw Feeder, Distribution, or other span cables on the map")
        self._btn_create_span.setStyleSheet(
            "QPushButton { background-color: #3d5a7a; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #4d7a9a; }"
            "QPushButton:pressed { background-color: #2d3a5a; }"
            "QPushButton:checked { background-color: #2d3a5a; border: 2px solid #87ceeb; }"
        )
        self._btn_create_span.setCheckable(True)
        self._btn_create_span.clicked.connect(self.on_create_span_clicked)
        self._create_span_tool = None   # holds active map tool
        self._create_span_type = None   # 'Feeder', 'Second Feeder', etc.
        # Ticket #51 — Create Span (Generate Span Lines) + Generate Poles to the TOP
        # of the menu (index 1/2, right under the GPKG output row).
        gb_layout.insertWidget(1, self._btn_create_span)
        gb_layout.insertWidget(2, self.pushButton_generate_poles)

        gb_layout.addWidget(self._manual_section)
        
        # Connect collapsible group boxes
        self.groupBox_4.toggled.connect(lambda checked: self.toggle_groupbox(self.groupBox_4, checked))
        self.groupBox_feeder_routes.toggled.connect(lambda checked: self.toggle_groupbox(self.groupBox_feeder_routes, checked))
        self.groupBox_individual_steps.toggled.connect(
            lambda checked: self.toggle_groupbox(self.groupBox_individual_steps, checked)
        )

        # Style the individual steps groupbox as a collapsible section
        self.groupBox_individual_steps.setStyleSheet(
            "QGroupBox {"
            "  font-weight: bold; font-size: 9pt; color: #2a5b8a;"
            "  border: 1px solid #7090b0; border-radius: 4px;"
            "  margin-top: 6px; padding-top: 6px;"
            "}"
            "QGroupBox::title {"
            "  subcontrol-origin: margin; subcontrol-position: top left;"
            "  padding: 0 4px; left: 6px;"
            "}"
            "QGroupBox::indicator { width: 14px; height: 14px; }"
        )

        # Initialize collapsed state for groups that start collapsed
        self.toggle_groupbox(self.groupBox_feeder_routes, False)
        self.toggle_groupbox(self.groupBox_individual_steps, False)
        
        # Connect layer type combo box to update label
        self.comboBox_clustering_method.currentIndexChanged.connect(self.on_clustering_method_changed)
        
        # Check if advanced libraries are available
        if not SKLEARN_AVAILABLE or not NUMPY_AVAILABLE:
            self.log_message("NOTE: Advanced clustering (DBSCAN, K-Means) requires scikit-learn and numpy.")
            self.log_message("Install with: pip install scikit-learn numpy")

        # Lock all planning sections until a client profile is loaded
        self._set_planning_sections_enabled(False)

        self.log_message("Velocity Network Planner initialized. Select a Client Profile to begin.")

    def on_clustering_method_changed(self, index):
        """Update UI elements based on selected clustering method."""
        # Only "Tight Groups of 8" method remains, no UI updates needed

    def on_layer_type_changed(self, index):
        """Layer type is fixed to Demand Points."""

    def on_set_client_clicked(self):
        """Load the selected client profile and unlock planning tools."""
        client_name = self.comboBox_client.currentText()
        if client_name == "-- Select Client --":
            self.log_message("ERROR: Please select a client from the dropdown before loading a profile.")
            return

        self.active_client = client_name
        self.active_client_profile = CLIENT_PROFILES[client_name]
        profile = self.active_client_profile

        # Update status label
        self.label_active_client.setText(client_name)
        self.label_active_client.setStyleSheet("color: green; font-weight: bold;")

        # Unlock planning sections
        self._set_planning_sections_enabled(True)

        self.log_message(f"--- Client Profile Loaded: {client_name} ---")
        self.log_message(f"  {profile['description']}")
        self.log_message(f"  Max PON size: {profile['max_pon_size']}  |  Target: {profile['target_pon_size']}")
        self.log_message(f"  Split ratio: Feeder {profile['splitter_ratio_feeder']}  |  Dist {profile['splitter_ratio_dist']}")
        self.log_message(f"  Max feeder cable: {profile['max_feeder_cable_fibres']}F  |  Max span: {profile['max_span_m']}m")
        self.log_message(f"  Pole heights: Feeder {profile['feeder_pole_height_m']}m  |  Dist {profile['dist_pole_height_m']}m")
        self.log_message("Planning tools are now unlocked.")

    def _set_planning_sections_enabled(self, enabled: bool):
        """Enable or disable all planning group boxes."""
        for gb in (self.groupBox_4, self.groupBox_feeder_routes, self.groupBox_individual_steps):
            gb.setEnabled(enabled)

    def toggle_groupbox(self, groupbox, checked):
        """Toggle visibility of groupbox contents for collapsible behavior."""
        # Get the layout inside the groupbox
        layout = groupbox.layout()
        if layout:
            # Show/hide all widgets in the layout
            for i in range(layout.count()):
                item = layout.itemAt(i)
                widget = item.widget()
                if widget:
                    widget.setVisible(checked)
                # Handle nested layouts
                nested_layout = item.layout()
                if nested_layout:
                    for j in range(nested_layout.count()):
                        nested_item = nested_layout.itemAt(j)
                        nested_widget = nested_item.widget()
                        if nested_widget:
                            nested_widget.setVisible(checked)

    def log_message(self, message: str):
        """Add a message to the output text area.
        
        Args:
            message: Message to display
        """
        self.textEdit_output.append(message)

    # ------------------------------------------------------------------
    # Timer / progress helpers
    # ------------------------------------------------------------------
    def _fmt_time(self, secs: float) -> str:
        """Format seconds into human-readable string."""
        if secs >= 3600:
            return f"{int(secs // 3600)}h {int((secs % 3600) // 60)}m"
        elif secs >= 60:
            return f"{int(secs // 60)}m {int(secs % 60)}s"
        else:
            return f"{secs:.1f}s"

    def _op_tick(self):
        """Called every 500 ms by _prog_timer to update the elapsed/ETA display."""
        import time
        if self._op_t0 is None:
            return
        secs = time.time() - self._op_t0
        elapsed_str = self._fmt_time(secs)
        pct = self._prog_bar.value()
        if pct > 0:
            eta_secs = secs * (100 - pct) / pct
            eta_str = f" | ETA: ~{self._fmt_time(eta_secs)}"
        else:
            eta_str = ""
        self._prog_time_lbl.setText(f"\u23f1 {elapsed_str}{eta_str}")

    def _start_timer(self):
        """Record the start time and show the progress strip."""
        import time
        self._op_t0 = time.time()
        self._op_last_pct = -1
        self._strip_gen += 1
        self._prog_bar.setValue(0)
        self._prog_time_lbl.setText("0s")
        self._prog_op_lbl.setText("Processing\u2026")
        self._prog_strip.setVisible(True)
        self._prog_timer.start()

    def _hide_prog_strip(self, gen: int):
        """Hide the progress strip only if no newer operation has started since gen."""
        if self._strip_gen == gen:
            self._prog_strip.setVisible(False)

    def _elapsed(self, label: str = ''):
        """Log time elapsed since _start_timer() was called, then finalise the strip."""
        import time
        from qgis.PyQt.QtCore import QTimer as _QT
        from qgis.PyQt.QtWidgets import QApplication as _QApp
        if self._op_t0 is None:
            return
        secs = time.time() - self._op_t0
        t_str = self._fmt_time(secs)
        prefix = f"{label} \u2014 " if label else ''
        self.log_message(f"  \u23f1 {prefix}{t_str}")
        # Finalise the strip
        self._prog_timer.stop()
        self._prog_bar.setValue(100)
        self._prog_op_lbl.setText(f"\u2713 {label}" if label else "\u2713 Done")
        self._prog_time_lbl.setText(f"\u23f1 {t_str}")
        _QApp.processEvents()
        _gen = self._strip_gen
        _QT.singleShot(3000, lambda: self._hide_prog_strip(_gen))
        self._op_t0 = None

    def _progress(self, done: int, total: int, label: str = ''):
        """Update progress bar and log at 25 % milestones; flush Qt event queue."""
        from qgis.PyQt.QtWidgets import QApplication
        import time
        if total > 0:
            pct = done * 100 // total
            self._prog_bar.setValue(pct)
            if label:
                self._prog_op_lbl.setText(label)
            milestone = (pct // 25) * 25
            if milestone > 0 and milestone != self._op_last_pct:
                self._op_last_pct = milestone
                elapsed = (time.time() - self._op_t0) if self._op_t0 is not None else 0.0
                tag = f"{label}: " if label else ''
                self.log_message(
                    f"  {tag}{milestone}%  ({done}/{total})  [{elapsed:.1f}s]"
                )
        QApplication.processEvents()

    def _on_kill_clicked(self):
        """Set the cancel flag so any running loop can detect and abort."""
        self._cancel_requested = True
        self._prog_op_lbl.setText("⛔ Cancelled — stopping…")
        self.log_message("⛔ CANCELLED by user — operation stopped.")

    def _cancel_check(self) -> bool:
        """Return True (and reset flag) if the user pressed Kill. Callers should return early."""
        if self._cancel_requested:
            self._cancel_requested = False
            return True
        return False

    def _start_operation(self, label: str = "Processing…"):
        """Reset cancel flag and start the progress strip."""
        self._cancel_requested = False
        self._start_timer()
        self._prog_op_lbl.setText(label)
    # keeps a strong reference and the signal connections stay alive)
    # ------------------------------------------------------------------
    def _save_gpkg_path(self, text: str):
        """Write the GPKG path into the current project's custom properties."""
        from qgis.core import QgsProject
        QgsProject.instance().writeEntry("FTTHPlanTool", "output_gpkg", text.strip())

    def _reload_gpkg_path(self):
        """Read back the GPKG path from the project and populate the field."""
        from qgis.core import QgsProject
        path = QgsProject.instance().readEntry("FTTHPlanTool", "output_gpkg", "")[0]
        self._output_gpkg_edit.blockSignals(True)
        self._output_gpkg_edit.setText(path)
        self._output_gpkg_edit.blockSignals(False)

    def _clear_gpkg_path(self):
        """Clear the GPKG field when a new/empty project is created."""
        self._output_gpkg_edit.blockSignals(True)
        self._output_gpkg_edit.clear()
        self._output_gpkg_edit.blockSignals(False)

    def _browse_gpkg_path(self):
        """Open file browser, set the GPKG path field, and immediately persist it."""
        from qgis.core import QgsProject
        from qgis.PyQt.QtWidgets import QFileDialog
        start = self._output_gpkg_edit.text() or QgsProject.instance().homePath() or ''
        path, _ = QFileDialog.getSaveFileName(self, "Select Output GeoPackage", start,
                                              "GeoPackage (*.gpkg)")
        if path:
            if not path.lower().endswith('.gpkg'):
                path += '.gpkg'
            self._output_gpkg_edit.setText(path)   # triggers textChanged → _save_gpkg_path

    # ------------------------------------------------------------------
    # Output layer persistence
    # ------------------------------------------------------------------
    def _add_output_layer(self, mem_layer: 'QgsVectorLayer') -> 'QgsVectorLayer':
        """Write a memory layer to the configured output GeoPackage and add to project.

        If no GeoPackage path is configured, falls back to adding the memory
        (scratch) layer directly.  Returns the layer that was added to the project
        (file-based if GPKG was used, otherwise the original memory layer).
        """
        import os, re
        from qgis.core import QgsVectorFileWriter, QgsProject

        gpkg_path = self._output_gpkg_edit.text().strip()

        if not gpkg_path:
            QgsProject.instance().addMapLayer(mem_layer)
            return mem_layer

        # Sanitize layer name → GPKG table name
        layer_name = mem_layer.name()
        table_name = re.sub(r'[^a-zA-Z0-9]', '_', layer_name).strip('_') or 'ftth_layer'

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        options.layerName = table_name
        # If the GPKG file doesn't exist yet use CreateOrOverwriteFile (creates the file).
        # If it does exist use CreateOrOverwriteLayer (adds/replaces just this table).
        if os.path.exists(gpkg_path):
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
        else:
            options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile

        self.log_message(f"  💾 Writing '{layer_name}' → {os.path.basename(gpkg_path)} …")

        try:
            error, msg, _, _ = QgsVectorFileWriter.writeAsVectorFormatV3(
                mem_layer, gpkg_path, QgsProject.instance().transformContext(), options)
        except Exception as exc:
            self.log_message(f"  ❌ GPKG write exception: {exc}")
            self.log_message("  Layer added as temporary scratch layer instead.")
            QgsProject.instance().addMapLayer(mem_layer)
            return mem_layer

        if error != QgsVectorFileWriter.NoError:
            self.log_message(f"  ❌ GPKG write failed (code {error}): {msg}")
            self.log_message("  Layer added as temporary scratch layer instead.")
            QgsProject.instance().addMapLayer(mem_layer)
            return mem_layer

        # Reload from GPKG as a persistent file-based layer
        uri = f"{gpkg_path}|layername={table_name}"
        file_layer = QgsVectorLayer(uri, layer_name, "ogr")
        if not file_layer.isValid():
            self.log_message(f"  ❌ Saved OK but reload failed for '{layer_name}' — using scratch.")
            QgsProject.instance().addMapLayer(mem_layer)
            return mem_layer

        # Transfer renderer and labeling from the memory layer
        if mem_layer.renderer():
            file_layer.setRenderer(mem_layer.renderer().clone())
        if mem_layer.labeling():
            file_layer.setLabeling(mem_layer.labeling().clone())
            file_layer.setLabelsEnabled(mem_layer.labelsEnabled())

        QgsProject.instance().addMapLayer(file_layer)
        self.log_message(f"  ✅ Saved [{table_name}]")
        return file_layer


    def on_build_graph_clicked(self):
        """Build network graph from selected layers."""
        nodes_layer = self.comboBox_nodes.currentLayer()
        ducts_layer = self.comboBox_ducts.currentLayer()
        
        if not ducts_layer:
            self.log_message("ERROR: Please select a ducts layer.")
            return
        
        self._start_timer()
        try:
            self.log_message("Building network graph...")
            self.network_graph = NetworkGraph()

            # Add named nodes if a nodes layer is selected
            if nodes_layer:
                self.log_message(f"Loading nodes from '{nodes_layer.name()}'...")
                node_count = 0
                for feature in get_layer_features(nodes_layer):
                    coords = get_point_coordinates(feature)
                    if coords:
                        self.network_graph.add_node_from_qgis(
                            f"node_{feature.id()}",
                            coords,
                            properties=feature.attributeMap(),
                        )
                        node_count += 1
                self.log_message(f"  Added {node_count} nodes")

            # Add edges from ducts (intermediate vertices included)
            self.log_message(f"Loading ducts from '{ducts_layer.name()}'...")
            duct_count = 0
            for feature in get_layer_features(ducts_layer):
                coords = get_linestring_coordinates(feature)
                if coords and len(coords) >= 2:
                    self.network_graph.add_edge_from_qgis(
                        coords,
                        properties=feature.attributeMap(),
                    )
                    duct_count += 1
            self.log_message(f"  Processed {duct_count} duct features")

            # Display graph info
            info = self.network_graph.get_graph_info()
            self.log_message("\nGraph built successfully:")
            self.log_message(f"  Total nodes  : {info['nodes']}")
            self.log_message(f"  Total edges  : {info['edges']}")
            self.log_message(f"  Total length : {info.get('total_length', 0):.2f}")
            self.log_message(f"  Connected    : {info['connected']}")
            if info['components'] > 1:
                self.log_message(
                    f"  WARNING: {info['components']} isolated network islands detected. "
                    f"Sizes: {info['component_sizes']}"
                )
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR building graph: {e!s}")

    def on_calculate_clicked(self):
        """Calculate shortest path between two points."""
        if not self.network_graph or self.network_graph.G.number_of_nodes() == 0:
            self.log_message("ERROR: Please build the network graph first.")
            return
        
        ducts_layer = self.comboBox_ducts.currentLayer()
        if not ducts_layer:
            self.log_message("ERROR: No ducts layer selected.")
            return
        
        # For demonstration, use the extent of the ducts layer to pick random points
        extent = get_layer_extent(ducts_layer)
        
        # Use first and last node coordinates as example
        nodes = list(self.network_graph.G.nodes(data=True))
        if len(nodes) < 2:
            self.log_message("ERROR: Need at least 2 nodes for routing.")
            return
        
        source_coord = nodes[0][1]['coord']
        target_coord = nodes[-1][1]['coord']
        
        self.log_message("\nCalculating route...")
        self.log_message(f"  From: {source_coord}")
        self.log_message(f"  To: {target_coord}")
        self._start_timer()
        try:
            path_coords, total_length = self.network_graph.shortest_path_with_cost(
                source_coord, target_coord
            )
            self.log_message(f"  Route found with {len(path_coords)} vertices")
            self.log_message(f"  Total length : {total_length:.2f}")
            self.log_message(f"  Optical loss : {self._path_loss_db(path_coords):.3f} dB")

            # Create result layer
            self.create_result_layer(path_coords, total_length)
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR calculating route: {e!s}")

    def create_result_layer(self, path_coords, total_length):
        """Create a layer to display the routing result.
        
        Args:
            path_coords: List of (x, y) coordinate tuples
            total_length: Total path length
        """
        # Remove old result layer if exists
        if self.result_layer:
            QgsProject.instance().removeMapLayer(self.result_layer.id())
        
        # Get CRS from ducts layer
        ducts_layer = self.comboBox_ducts.currentLayer()
        crs = ducts_layer.crs().authid() if ducts_layer else "EPSG:4326"
        
        # Create new result layer
        self.result_layer = create_memory_layer("FTTH Route Result", "LineString", crs)
        
        # Add fields
        add_fields_to_layer(self.result_layer, [
            ('route_id', int, 'Integer'),
            ('length', float, 'Double'),
            ('num_points', int, 'Integer')
        ])
        self.result_layer.updateFields()
        
        # Add the route as a line feature
        attributes = {
            'route_id': 1,
            'length': total_length,
            'num_points': len(path_coords)
        }
        add_line_feature(self.result_layer, path_coords, attributes)
        
        # Update layer extent and add to map
        self.result_layer.updateExtents()
        QgsProject.instance().addMapLayer(self.result_layer)
        
        self.log_message("  Result layer added to map.")

    def _path_loss_db(self, path_coords: list) -> float:
        """Sum optical loss_db across graph edges that form *path_coords*.

        Walks consecutive coordinate pairs and looks up the edge in the graph.
        Coordinates are snapped via the graph's own precision before lookup.
        """
        if not self.network_graph:
            return 0.0
        ng = self.network_graph
        total = 0.0
        for raw_u, raw_v in zip(path_coords[:-1], path_coords[1:]):
            su = _snap_coord(raw_u, ng.snap_precision)
            sv = _snap_coord(raw_v, ng.snap_precision)
            nu = ng._coord_index.get(su)
            nv = ng._coord_index.get(sv)
            if nu and nv and ng.G.has_edge(nu, nv):
                total += ng.G.edges[nu, nv].get('loss_db', 0.0)
        return total

    def on_analyze_clicked(self):
        """Analyze selected layers and display statistics."""
        nodes_layer = self.comboBox_nodes.currentLayer()
        ducts_layer = self.comboBox_ducts.currentLayer()
        
        self.log_message("\n=== Layer Analysis ===")
        self._start_timer()
        if nodes_layer:
            self.log_message(f"\nNodes Layer: '{nodes_layer.name()}'")
            self.log_message(f"  Feature count: {nodes_layer.featureCount()}")
            self.log_message(f"  CRS: {nodes_layer.crs().authid()}")
            counts = count_features_by_geometry_type(nodes_layer)
            for geom_type, count in counts.items():
                if count > 0:
                    self.log_message(f"  {geom_type}: {count}")
            
            # List fields
            fields = nodes_layer.fields()
            field_names = [field.name() for field in fields]
            self.log_message(f"  Fields: {', '.join(field_names)}")
        
        if ducts_layer:
            self.log_message(f"\nDucts Layer: '{ducts_layer.name()}'")
            self.log_message(f"  Feature count: {ducts_layer.featureCount()}")
            self.log_message(f"  CRS: {ducts_layer.crs().authid()}")
            counts = count_features_by_geometry_type(ducts_layer)
            for geom_type, count in counts.items():
                if count > 0:
                    self.log_message(f"  {geom_type}: {count}")
            
            # List fields
            fields = ducts_layer.fields()
            field_names = [field.name() for field in fields]
            self.log_message(f"  Fields: {', '.join(field_names)}")
            
            # Calculate total length
            total_length = 0
            for feature in get_layer_features(ducts_layer):
                geom = feature.geometry()
                if geom:
                    total_length += geom.length()
            self.log_message(f"  Total length: {total_length:.2f}")
        self._elapsed("Total time")

    def on_clear_clicked(self):
        """Clear output and remove result layer."""
        self.textEdit_output.clear()
        
        if self.result_layer:
            QgsProject.instance().removeMapLayer(self.result_layer.id())
            self.result_layer = None

    def _refresh_properties(self):
        """🔄 Re-scan the project and auto-detect the demand / route / road layers
        into the dropdowns — so newly added, renamed or reloaded layers are picked
        up without re-running AutoNet. Purely re-selects layers; changes no data."""
        try:
            from qgis.core import QgsProject, QgsMapLayer, QgsWkbTypes
            G = QgsWkbTypes.GeometryType
            vlayers = [lyr for lyr in QgsProject.instance().mapLayers().values()
                       if lyr.type() == QgsMapLayer.LayerType.VectorLayer]

            def pick(combo, keywords, geoms):
                if combo is None:
                    return None
                cands = [lyr for lyr in vlayers if lyr.geometryType() in geoms]
                for kw in keywords:
                    for lyr in cands:
                        if kw in lyr.name().lower():
                            combo.setLayer(lyr)
                            return lyr.name()
                return None

            picked = {
                "demand": pick(getattr(self, "comboBox_erf", None),
                               ("demand", "parcel", "erf", "erven", "building",
                                "stand", "subscriber", "home", "ont"),
                               (G.PolygonGeometry, G.PointGeometry)),
                "route": pick(getattr(self, "comboBox_span_layer", None),
                              ("span", "route", "fibre", "fiber", "cable", "duct",
                               "trunk", "backbone"), (G.LineGeometry,)),
                "road": pick(getattr(self, "comboBox_road_layer", None),
                             ("road", "street", "highway", "lane", "avenue"),
                             (G.LineGeometry,)),
            }
            hits = ", ".join(f"{k}={v}" for k, v in picked.items() if v) or "no matches"
            try:
                self.log_message(f"🔄 Layers refreshed — {hits}")
            except Exception:
                pass
            try:
                self.iface.messageBar().pushSuccess(
                    "Network Planner", f"Layers refreshed ({hits}).")
            except Exception:
                pass
        except Exception as e:
            try:
                self.log_message(f"Refresh failed: {e}")
            except Exception:
                pass

    def on_autonet_clicked(self, _zone_offset=0, _group_offset=0, _batch_label=None):
        """AutoNet: auto-detect layers and run the full PON pipeline in one click.
        Steps: 1. PON Groups  2. Demand Points  3. Group Boundaries
               4. Splitter Points  5. Drops PTP
        Shows a floating progress dialog with scrolling log and elapsed timer.

        _zone_offset / _group_offset / _batch_label — forwarded to Step 1 so that
        PON-per-PON runs produce globally sequential zone and group IDs.
        """
        from qgis.core import QgsProject, QgsVectorLayer

        # ── Create and show progress dialog ───────────────────────────
        dlg = AutoNetProgressDialog(self)
        dlg.show()
        QApplication.processEvents()

        # Helper: write to BOTH the dock log AND the popup dialog
        def _log(msg):
            self.log_message(msg)
            dlg.append_log(msg)

        def _autonet_progress(step, label):
            pct = int((step - 1) / 5 * 100)
            self._prog_bar.setValue(pct)
            self._prog_op_lbl.setText(f"AutoNet {step}/5: {label}")
            self._prog_strip.setVisible(True)
            dlg.set_step(step, f"Step {step}/5 — {label}")
            QApplication.processEvents()

        _log("\n══════════════════════════════════════════")
        _log("  ⚡ AutoNet — Full Pipeline Started")
        _log("══════════════════════════════════════════")
        self._prog_strip.setVisible(True)
        self._prog_bar.setValue(0)
        self._prog_op_lbl.setText("AutoNet — detecting layers…")
        dlg.set_step(0, "Detecting layers…")
        QApplication.processEvents()

        # ── Layer auto-detection ───────────────────────────────────────
        _excl_fragments = (
            'groups of', 'group of', 'demand points -', 'splitter point',
            'drop cable', 'drop_cable', 'pon zone', 'pon boundary',
            'zone boundary', 'group boundary', 'aggregation point',
            'feeder route', 'poles_', 'autonet', 'shortest', 'routing',
        )
        _generic_exact = {'aoi', 'extent', 'bbox', 'boundary', 'mask',
                          'study area', 'project area', 'area of interest',
                          'shortest path', 'shortest_path', 'routing result'}

        def _is_output_layer(name_lower):
            if name_lower in _generic_exact:
                return True
            return any(frag in name_lower for frag in _excl_fragments)

        def _find_layer(keywords, geom_type=None):
            for lyr in QgsProject.instance().mapLayers().values():
                if not isinstance(lyr, QgsVectorLayer):
                    continue
                if geom_type is not None and lyr.geometryType() != geom_type:
                    continue
                ln = lyr.name().lower()
                if _is_output_layer(ln):
                    continue
                if any(kw in ln for kw in keywords):
                    return lyr
            return None

        def _resolve_layer(combo, keywords, geom_type=None, fallback_geom=None):
            current = combo.currentLayer()
            if current and isinstance(current, QgsVectorLayer):
                if not _is_output_layer(current.name().lower()):
                    return current
            lyr = _find_layer(keywords, geom_type)
            if not lyr and fallback_geom is not None:
                lyr = _find_layer(keywords, fallback_geom)
            if not lyr:
                lyr = _find_layer(keywords)
            return lyr

        demand_kw = ('erf', 'parcel', 'stand', 'plot', 'property', 'premise',
                     'demand', 'subscriber', 'home', 'household')
        demand_lyr = _resolve_layer(self.comboBox_erf, demand_kw,
                                    geom_type=2, fallback_geom=0)

        span_kw = ('span', 'route', 'fibre', 'fiber', 'cable', 'duct',
                   'network', 'trunk', 'backbone')
        span_lyr = _resolve_layer(self.comboBox_span_layer, span_kw, geom_type=1)

        road_kw = ('road', 'street', 'highway', 'lane', 'avenue')
        road_lyr = _resolve_layer(self.comboBox_road_layer, road_kw, geom_type=1)

        # ── Validate ──────────────────────────────────────────────────
        if not demand_lyr:
            _log("ERROR: AutoNet could not identify a demand/parcel layer.")
            _log("  Please set the Demand Layer combo manually and retry.")
            self._prog_strip.setVisible(False)
            dlg.mark_error("No demand layer found")
            return
        if not span_lyr:
            _log("ERROR: AutoNet could not identify a span/route layer.")
            _log("  Please set the Route Layer combo manually and retry.")
            self._prog_strip.setVisible(False)
            dlg.mark_error("No span/route layer found")
            return
        if not road_lyr:
            _log("WARNING: No road layer found — road-crossing rule will be skipped.")

        # ── Apply combos ──────────────────────────────────────────────
        self.comboBox_erf.setLayer(demand_lyr)
        self.comboBox_span_layer.setLayer(span_lyr)
        if road_lyr:
            self.comboBox_road_layer.setLayer(road_lyr)

        for i in range(self.comboBox_clustering_method.count()):
            if 'tight' in self.comboBox_clustering_method.itemText(i).lower():
                self.comboBox_clustering_method.setCurrentIndex(i)
                break

        _log(f"  Demand layer : {demand_lyr.name()}")
        _log(f"  Route layer  : {span_lyr.name()}")
        _log(f"  Road layer   : {road_lyr.name() if road_lyr else '(none)'}")
        _log(f"  Method       : {self.comboBox_clustering_method.currentText()}")
        QApplication.processEvents()

        # Store batch label so steps 4 & 5 can name their output layers accordingly
        self._current_batch_label = _batch_label

        # ── Step 1: Generate PON Groups ───────────────────────────────
        _autonet_progress(1, "Generate PON Groups")
        _log("\n── Step 1/5: Generate PON Groups ──")
        self.on_cluster_erven_clicked(
            _zone_offset=_zone_offset,
            _group_offset=_group_offset,
            _batch_label=_batch_label,
        )
        QApplication.processEvents()

        # ── Step 2: Generate Demand Points ───────────────────────────
        _autonet_progress(2, "Generate Demand Points")
        _log("\n── Step 2/5: Generate Demand Points ──")
        self.on_generate_demand_points_clicked()
        QApplication.processEvents()

        # ── Step 3: Generate Group Boundaries ────────────────────────
        _autonet_progress(3, "Generate Group Boundaries")
        _log("\n── Step 3/5: Generate Group Boundaries ──")
        self.on_generate_boundaries_clicked()
        QApplication.processEvents()

        # ── Step 4: Generate Splitter Points ─────────────────────────
        _autonet_progress(4, "Generate Splitter Points")
        _log("\n── Step 4/5: Generate Splitter Points ──")
        self.on_generate_splitters_clicked()
        QApplication.processEvents()

        # ── Step 5: Generate Drops PTP ───────────────────────────────
        _autonet_progress(5, "Generate Drops PTP")
        _log("\n── Step 5/5: Generate Drops PTP ──")
        self.on_generate_drop_ptp_clicked()
        QApplication.processEvents()

        # ── Done ─────────────────────────────────────────────────────
        self._prog_bar.setValue(100)
        self._prog_op_lbl.setText("⚡ AutoNet Complete ✓")
        from qgis.PyQt.QtCore import QTimer as _QT2
        _gen = self._strip_gen
        _QT2.singleShot(4000, lambda: self._hide_prog_strip(_gen))
        _log("")
        _log("══════════════════════════════════════════")
        _log("  ⚡ AutoNet — Pipeline Complete ✓")
        _log("══════════════════════════════════════════")
        dlg.mark_complete(success=True)

    # ------------------------------------------------------------------
    # PON per PON Manual
    # ------------------------------------------------------------------
    def on_pon_per_pon_clicked(self):
        """Toggle PON-per-PON selection mode.

        First click  → prompt user to select features on map, then run pipeline.
        Second click → cancel / exit selection mode.
        """
        if not self._btn_pon_per_pon.isChecked():
            # Button was unchecked — cancel any pending selection mode
            self._pon_per_pon_cancel()
            return
        self._pon_per_pon_start()

    def _pon_per_pon_cancel(self):
        """Exit PON-per-PON mode without running the pipeline."""
        canvas = self.iface.mapCanvas()
        if hasattr(self, '_pon_select_tool') and self._pon_select_tool:
            if hasattr(self, '_prev_map_tool') and self._prev_map_tool:
                canvas.setMapTool(self._prev_map_tool)
            self._pon_select_tool = None
        self.iface.messageBar().clearWidgets()
        self._btn_pon_per_pon.setChecked(False)
        self._btn_pon_per_pon.setText("🎯 PON per PON Manual")
        self._pon_per_pon_active = False
        # Signal that the NEXT PON-per-PON run should start a fresh session.
        # We deliberately do NOT null the accumulator refs here so that Manual
        # Override can continue editing the existing layers after this button is
        # closed.  The accumulators will be nulled at the start of the next run.
        self._pon_new_session_needed = True
        # NOTE: _pon_batch_count / _pon_zone_offset / _pon_group_offset are
        # intentionally NOT reset here — they will be reset in _pon_per_pon_run
        # when _pon_new_session_needed is True.


    def _pon_per_pon_start(self):
        """Install the rubber-band polygon map tool for dual-layer PON selection."""
        from qgis.PyQt.QtWidgets import QMessageBox

        self._btn_pon_per_pon.setText("✏ Drawing selection — Right-click to finish")
        self._pon_per_pon_active = True

        demand_lyr = self.comboBox_erf.currentLayer()
        span_lyr = self.comboBox_span_layer.currentLayer()

        if not demand_lyr or not span_lyr:
            QMessageBox.warning(
                self, "PON per PON",
                "Please set the Demand Layer and Route Layer combos before using PON per PON Manual."
            )
            self._pon_per_pon_cancel()
            return

        canvas = self.iface.mapCanvas()

        # Store the previous map tool so we can restore it on cancel
        self._prev_map_tool = canvas.mapTool()

        tool = PonPolygonSelectTool(canvas, demand_lyr, span_lyr)
        tool.selection_complete.connect(self._pon_per_pon_polygon_done)
        tool.cancelled.connect(self._pon_per_pon_cancel)
        self._pon_select_tool = tool
        canvas.setMapTool(tool)

        # Show a non-modal floating hint
        self.iface.messageBar().pushMessage(
            "PON per PON",
            "Left-click to draw polygon vertices. Right-click to complete selection. Esc to cancel.",
            level=0,   # Qgis.Info
            duration=0
        )

    def _pon_per_pon_polygon_done(self, demand_lyr, span_lyr):
        """Called when the rubber-band polygon is complete; restore map tool then review."""
        canvas = self.iface.mapCanvas()

        # Restore previous map tool
        if hasattr(self, '_prev_map_tool') and self._prev_map_tool:
            canvas.setMapTool(self._prev_map_tool)
        self._pon_select_tool = None

        # Clear message bar hint
        self.iface.messageBar().clearWidgets()

        self._btn_pon_per_pon.setText("🎯 PON per PON Manual")
        self._pon_per_pon_review(demand_lyr, span_lyr)

    def _pon_per_pon_review(self, demand_lyr, span_lyr):
        """Show count of selected features and ask user to confirm or reselect."""
        from qgis.PyQt.QtWidgets import QMessageBox, QDialog, QVBoxLayout, QLabel, QPushButton, QHBoxLayout
        from qgis.PyQt.QtCore import Qt

        n_demand = demand_lyr.selectedFeatureCount()
        n_span = span_lyr.selectedFeatureCount()

        if n_demand == 0 and n_span == 0:
            btn = QMessageBox.question(
                self, "PON per PON — No Selection",
                "No features are currently selected on either layer.\n\n"
                "Would you like to go back and select features?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if btn == QMessageBox.StandardButton.Yes:
                self._pon_per_pon_start()
            else:
                self._pon_per_pon_cancel()
            return

        # Build confirmation dialog
        dlg = QDialog(self)
        dlg.setWindowTitle("PON per PON — Confirm Selection")
        dlg.setMinimumWidth(380)
        lay = QVBoxLayout(dlg)
        lay.setSpacing(10)
        lay.setContentsMargins(16, 16, 16, 16)

        title_lbl = QLabel("<b>Selection Summary</b>")
        title_lbl.setStyleSheet("font-size: 11px; color: #1a5276;")
        lay.addWidget(title_lbl)

        import math as _math
        n_groups = _math.ceil(n_demand / 8) if n_demand > 0 else 0

        summary = (
            f"<table cellspacing='6'>"
            f"<tr><td>🏠 Demand points selected:</td><td><b>{n_demand}</b></td></tr>"
            f"<tr><td>📡 Span features selected:</td><td><b>{n_span}</b></td></tr>"
            f"<tr><td>🔀 Splitter groups (est.):</td><td><b>{n_groups}</b></td></tr>"
            f"</table>"
        )
        if n_demand == 0:
            summary += "<br><span style='color:#c0392b;'>⚠ No demand points selected — pipeline will have nothing to group.</span>"
        elif n_demand < 4:
            summary += f"<br><span style='color:#d35400;'>⚠ Only {n_demand} demand point(s) selected — very small PON.</span>"
        else:
            pct = min(100, int(n_demand / 96 * 100))
            summary += f"<br><span style='color:#1e8449;'>✓ ~{pct}% of a full 96-unit PON capacity.</span>"

        sum_lbl = QLabel(summary)
        sum_lbl.setTextFormat(Qt.TextFormat.RichText)
        sum_lbl.setWordWrap(True)
        lay.addWidget(sum_lbl)

        btn_row = QHBoxLayout()
        btn_run = QPushButton("▶ Run AutoNet on Selection")
        btn_run.setStyleSheet(
            "QPushButton{background:#1a6b3c;color:white;font-weight:bold;"
            "border-radius:4px;padding:5px 12px;}"
            "QPushButton:hover{background:#238a4f;}"
        )
        btn_reselect = QPushButton("↩ Reselect")
        btn_reselect.setStyleSheet(
            "QPushButton{background:#7d4e00;color:white;font-weight:bold;"
            "border-radius:4px;padding:5px 12px;}"
            "QPushButton:hover{background:#a06300;}"
        )
        btn_cancel = QPushButton("✕ Cancel")
        btn_cancel.setStyleSheet(
            "QPushButton{background:#922b21;color:white;font-weight:bold;"
            "border-radius:4px;padding:5px 12px;}"
            "QPushButton:hover{background:#b03a2e;}"
        )
        btn_row.addWidget(btn_run)
        btn_row.addWidget(btn_reselect)
        btn_row.addWidget(btn_cancel)
        lay.addLayout(btn_row)

        dlg._choice = 'cancel'
        btn_run.clicked.connect(lambda: (setattr(dlg, '_choice', 'run'), dlg.accept()))
        btn_reselect.clicked.connect(lambda: (setattr(dlg, '_choice', 'reselect'), dlg.accept()))
        btn_cancel.clicked.connect(lambda: (setattr(dlg, '_choice', 'cancel'), dlg.accept()))

        dlg.exec()

        if dlg._choice == 'reselect':
            self._pon_per_pon_start()
        elif dlg._choice == 'run':
            self._pon_per_pon_run(demand_lyr, span_lyr)
        else:
            self._pon_per_pon_cancel()

    def _pon_is_accum_valid(self, layer_ref):
        """Return True if an accumulator layer reference is still alive in the project."""
        import sip as _s
        try:
            if layer_ref is None or _s.isdeleted(layer_ref):
                return False
            from qgis.core import QgsProject
            return layer_ref.id() in QgsProject.instance().mapLayers()
        except Exception:
            return False

    def _pon_merge_batch_into_accumulators(self):
        """After a batch run, merge the batch-specific layers into the 4 persistent
        accumulator layers using direct stored references (not name searching).

        Accumulator layers created (first batch) or appended to (subsequent batches):
          • PON Groups          — grouped demand points (self.grouped_layer)
          • PON Zone Boundaries — zone polygon boundaries (self.zone_boundaries_layer)
          • PON Splitter Points — splitter points (self.splitter_points_layer)
          • PON Drop Cables     — drop cables PTP (self.drop_ptp_layer)
        """
        import sip as _sip_m
        from qgis.core import QgsProject, QgsVectorLayer, QgsFeature

        batch_label = getattr(self, '_current_batch_label', None) or 'unknown batch'

        # Map: (source ref attr, accumulator attr, accumulator name, geom_type str)
        ACCUM_MAP = [
            ('grouped_layer',          '_pon_accum_groups',    'PON Groups',          'Point'),
            ('zone_boundaries_layer',  '_pon_accum_zones',     'PON Zone Boundaries', 'Polygon'),
            ('splitter_points_layer',  '_pon_accum_splitters', 'PON Splitter Points', 'Point'),
            ('drop_ptp_layer',         '_pon_accum_drops',     'PON Drop Cables',     'LineString'),
        ]

        merged_count = 0
        for src_attr, accum_attr, accum_name, geom_str in ACCUM_MAP:
            # Get the batch layer from the stored reference
            batch_layer = getattr(self, src_attr, None)
            if batch_layer is None:
                self.log_message(f"  ⚠ Merge: '{accum_name}' — no source layer (self.{src_attr} is None)")
                continue
            try:
                if _sip_m.isdeleted(batch_layer):
                    self.log_message(f"  ⚠ Merge: '{accum_name}' — source layer was deleted")
                    continue
            except Exception:
                self.log_message(f"  ⚠ Merge: '{accum_name}' — source layer reference invalid")
                continue

            # Get or create the accumulator layer
            accum = getattr(self, accum_attr, None)
            if not self._pon_is_accum_valid(accum):
                crs = batch_layer.crs().authid()
                accum = QgsVectorLayer(f"{geom_str}?crs={crs}", accum_name, "memory")
                accum.dataProvider().addAttributes(batch_layer.fields().toList())
                accum.updateFields()
                if batch_layer.renderer():
                    accum.setRenderer(batch_layer.renderer().clone())
                if batch_layer.labeling():
                    accum.setLabeling(batch_layer.labeling().clone())
                    accum.setLabelsEnabled(batch_layer.labelsEnabled())
                QgsProject.instance().addMapLayer(accum)
                setattr(self, accum_attr, accum)
                self.log_message(f"  ✦ Created accumulator: '{accum_name}'")

            # Append features from batch layer into accumulator
            feats = [QgsFeature(f) for f in batch_layer.getFeatures()]
            accum.dataProvider().addFeatures(feats)
            accum.updateExtents()
            accum.triggerRepaint()
            self.log_message(f"  ✦ '{accum_name}': +{len(feats)} → {accum.featureCount()} total")
            merged_count += 1

            # Remove batch-specific layer from project
            try:
                QgsProject.instance().removeMapLayer(batch_layer.id())
            except Exception:
                pass

        if merged_count == 0:
            self.log_message(f"  ⚠ No layers merged for {batch_label} — check pipeline completed all 5 steps")
        else:
            self.log_message(f"  ✓ Merge complete: {merged_count}/4 layers merged for {batch_label}")

        # Also remove the Step 2 demand points layer (intermediate layer, data lives in PON Groups)
        dp_layer = getattr(self, 'demand_points_layer', None)
        if dp_layer is not None:
            try:
                if not _sip_m.isdeleted(dp_layer):
                    QgsProject.instance().removeMapLayer(dp_layer.id())
                    self.log_message("  ✦ Removed intermediate demand points layer")
            except Exception:
                pass

        # Refresh all accumulator renderers so new zone categories are visible
        self._pon_refresh_accum_renderers()

        # Force the map canvas to actually redraw — triggerRepaint only queues a redraw
        try:
            from qgis.PyQt.QtWidgets import QApplication as _QApp
            self.iface.mapCanvas().refresh()
            _QApp.processEvents()
        except Exception:
            pass

    def _pon_refresh_accum_renderers(self):
        """Rebuild the categorized renderer on each accumulator layer so that all
        zone/group values added from the latest batch appear with correct colours.
        Called after every merge."""
        import colorsys
        from qgis.PyQt.QtGui import QColor
        from qgis.core import (QgsCategorizedSymbolRenderer, QgsRendererCategory,
                               QgsFillSymbol)

        # ── Zone Boundaries: categorized by zone_name, distinct hue per zone ──
        zones_accum = getattr(self, '_pon_accum_zones', None)
        if self._pon_is_accum_valid(zones_accum):
            try:
                unique_zones = sorted(set(
                    str(f['zone_name']) for f in zones_accum.getFeatures()
                    if f['zone_name'] is not None
                ))
                n = max(len(unique_zones), 1)
                categories = []
                for i, z_name in enumerate(unique_zones):
                    hue = (i / n) % 1.0
                    r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.65, 0.88)]
                    fill_col    = QColor(r, g, b, 70)
                    outline_col = QColor(r, g, b, 230)
                    sym = QgsFillSymbol.createSimple({
                        'color':         fill_col.name(QColor.NameFormat.HexArgb),
                        'outline_color': outline_col.name(),
                        'outline_width': '1.2',
                        'outline_style': 'solid',
                    })
                    categories.append(QgsRendererCategory(z_name, sym, z_name))
                zones_accum.setRenderer(QgsCategorizedSymbolRenderer('zone_name', categories))
                zones_accum.triggerRepaint()
            except Exception as _e:
                self.log_message(f"  ⚠ Zone boundary renderer refresh failed: {_e}")

        # ── PON Groups: categorized by zone_id, distinct hue per zone ──
        groups_accum = getattr(self, '_pon_accum_groups', None)
        if self._pon_is_accum_valid(groups_accum):
            try:
                unique_zones = sorted(set(
                    f['zone_id'] for f in groups_accum.getFeatures()
                    if f['zone_id'] is not None
                ))
                n = max(len(unique_zones), 1)
                categories = []
                for i, z_id in enumerate(unique_zones):
                    hue = (i / n) % 1.0
                    r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.7, 0.9)]
                    sym = QgsMarkerSymbol.createSimple({
                        'name': 'circle', 'color': QColor(r, g, b).name(),
                        'size': '2.5', 'outline_style': 'no'
                    })
                    categories.append(QgsRendererCategory(z_id, sym, f"Zone {z_id}"))
                groups_accum.setRenderer(QgsCategorizedSymbolRenderer('zone_id', categories))
                groups_accum.triggerRepaint()
            except Exception as _e:
                self.log_message(f"  ⚠ Groups renderer refresh failed: {_e}")

        # ── Splitters: categorized by zone_id ──
        splitters_accum = getattr(self, '_pon_accum_splitters', None)
        if self._pon_is_accum_valid(splitters_accum):
            try:
                unique_zones = sorted(set(
                    f['zone_id'] for f in splitters_accum.getFeatures()
                    if f['zone_id'] is not None
                ))
                n = max(len(unique_zones), 1)
                categories = []
                for i, z_id in enumerate(unique_zones):
                    hue = (i / n) % 1.0
                    r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.8, 0.85)]
                    sym = QgsMarkerSymbol.createSimple({
                        'name': 'circle', 'color': QColor(r, g, b).name(),
                        'size': '4', 'outline_color': 'black', 'outline_width': '0.5'
                    })
                    categories.append(QgsRendererCategory(z_id, sym, f"Zone {z_id}"))
                splitters_accum.setRenderer(QgsCategorizedSymbolRenderer('zone_id', categories))
                splitters_accum.triggerRepaint()
            except Exception as _e:
                self.log_message(f"  ⚠ Splitters renderer refresh failed: {_e}")

        # ── Drop Cables: categorized by zone_id, colour-coded lines ──
        drops_accum = getattr(self, '_pon_accum_drops', None)
        if self._pon_is_accum_valid(drops_accum):
            try:
                unique_zones = sorted(set(
                    f['zone_id'] for f in drops_accum.getFeatures()
                    if f['zone_id'] is not None
                ))
                n = max(len(unique_zones), 1)
                categories = []
                for i, z_id in enumerate(unique_zones):
                    hue = (i / n) % 1.0
                    r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.9, 0.85)]
                    sym = QgsLineSymbol.createSimple({
                        'color': QColor(r, g, b).name(), 'width': '0.4'
                    })
                    categories.append(QgsRendererCategory(z_id, sym, f"Zone {z_id}"))
                drops_accum.setRenderer(QgsCategorizedSymbolRenderer('zone_id', categories))
                drops_accum.triggerRepaint()
            except Exception as _e:
                self.log_message(f"  ⚠ Drop cables renderer refresh failed: {_e}")

        # ── PON detail counts: keep zone labels (units + splitters) current ──
        self._pon_refresh_zone_counts()

    def _pon_refresh_zone_counts(self):
        """Recompute unit_count + splitter_count on each PON Zone Boundary feature
        from the LIVE splitter + groups accumulators, so the zone labels stay
        correct after a splitter or demand point is added/deleted in Manual
        Override (ticket #37 — counts must update on changes). No-op if there is
        no zone-boundary layer or it has neither count field."""
        import sip
        zones = getattr(self, '_pon_accum_zones', None)
        try:
            if not zones or sip.isdeleted(zones):
                return
        except Exception:
            return
        zfields = [f.name() for f in zones.fields()]
        has_sc = 'splitter_count' in zfields
        has_uc = 'unit_count' in zfields
        if not (has_sc or has_uc) or 'zone_id' not in zfields:
            return

        def _alive(lyr):
            try:
                return lyr is not None and not sip.isdeleted(lyr)
            except Exception:
                return lyr is not None

        def _count_by_zone(layer):
            out = {}
            if not _alive(layer):
                return out
            for f in layer.getFeatures():
                z = f['zone_id'] if 'zone_id' in [fld.name() for fld in layer.fields()] else None
                if z is None:
                    continue
                try:
                    z = int(z)
                except (TypeError, ValueError):
                    continue
                out[z] = out.get(z, 0) + 1
            return out

        # one splitter feature per group → splitters in a zone = features by zone_id
        sp_by_zone = _count_by_zone(getattr(self, '_pon_accum_splitters', None))
        uc_by_zone = _count_by_zone(getattr(self, '_pon_accum_groups', None))

        sc_idx = zones.fields().indexFromName('splitter_count') if has_sc else -1
        uc_idx = zones.fields().indexFromName('unit_count') if has_uc else -1
        attr_map = {}
        for f in zones.getFeatures():
            z = f['zone_id']
            try:
                z = int(z)
            except (TypeError, ValueError):
                continue
            upd = {}
            if has_sc:
                upd[sc_idx] = sp_by_zone.get(z, 0)
            if has_uc and z in uc_by_zone:
                upd[uc_idx] = uc_by_zone.get(z, 0)
            if upd:
                attr_map[f.id()] = upd
        if attr_map:
            try:
                zones.dataProvider().changeAttributeValues(attr_map)
                zones.updateExtents()
                zones.triggerRepaint()
                self.log_message(
                    f"  ✦ PON Zone counts refreshed ({len(attr_map)} zones: "
                    f"units + splitters)")
            except Exception as _e:
                self.log_message(f"  ⚠ Zone count refresh failed: {_e}")

    def _pon_existing_offsets(self):
        """Highest zone_id and group_id already present in the project's PON
        layers, so a resumed / re-opened PON-per-PON session CONTINUES numbering
        instead of restarting at Zone 1. Reads from the SAVED layers via the
        provider's maximumValue (cheap), so it survives a project re-open even
        though the in-memory accumulators are gone. Returns (max_zone, max_group)."""
        from qgis.core import QgsProject, QgsVectorLayer
        max_zone = 0
        max_group = 0
        for lyr in QgsProject.instance().mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer):
                continue
            fnames = [f.name() for f in lyr.fields()]
            if 'zone_id' in fnames:
                try:
                    v = lyr.maximumValue(lyr.fields().indexFromName('zone_id'))
                    if v is not None:
                        max_zone = max(max_zone, int(v))
                except Exception:
                    pass
            for gf in ('group_id', 'group_8', 'group_16', 'group_128', 'group_100'):
                if gf in fnames:
                    try:
                        v = lyr.maximumValue(lyr.fields().indexFromName(gf))
                        if v is not None:
                            max_group = max(max_group, int(v))
                    except Exception:
                        pass
                    break
        return max_zone, max_group

    def _pon_per_pon_run(self, demand_lyr, span_lyr):
        """Run the full AutoNet pipeline (all 5 steps) on only the polygon-selected features."""
        from qgis.PyQt.QtWidgets import QMessageBox
        from qgis.core import QgsVectorLayer, QgsFeatureRequest, QgsProject, QgsWkbTypes

        demand_ids = list(demand_lyr.selectedFeatureIds())
        span_ids   = list(span_lyr.selectedFeatureIds())

        if not demand_ids:
            QMessageBox.warning(self, "PON per PON", "No demand points selected — aborting.")
            self._pon_per_pon_cancel()
            return

        # Build an in-memory copy containing only the selected features
        def _filtered_layer(source_lyr, sel_ids, name):
            wkb = source_lyr.wkbType()
            geom_str = QgsWkbTypes.displayString(wkb)
            crs_str  = source_lyr.crs().authid()
            tmp = QgsVectorLayer(f"{geom_str}?crs={crs_str}", name, "memory")
            tmp.dataProvider().addAttributes(source_lyr.fields().toList())
            tmp.updateFields()
            feats = list(source_lyr.getFeatures(QgsFeatureRequest().setFilterFids(sel_ids)))
            tmp.dataProvider().addFeatures(feats)
            return tmp

        # Name the temp layers identically to the originals so on_autonet_clicked
        # layer-detection resolves them via the combo (not by name-search fallback)
        tmp_demand = _filtered_layer(demand_lyr, demand_ids, demand_lyr.name())
        tmp_span   = _filtered_layer(span_lyr, span_ids, span_lyr.name()) if span_ids else None

        _orig_demand = self.comboBox_erf.currentLayer()
        _orig_span   = self.comboBox_span_layer.currentLayer()
        _orig_road   = self.comboBox_road_layer.currentLayer()

        tmp_demand_id = None
        tmp_span_id   = None

        try:
            # Add WITH legend visibility so QgsMapLayerComboBox can reference them
            QgsProject.instance().addMapLayer(tmp_demand, True)
            tmp_demand_id = tmp_demand.id()
            self.comboBox_erf.setLayer(tmp_demand)

            if tmp_span:
                QgsProject.instance().addMapLayer(tmp_span, True)
                tmp_span_id = tmp_span.id()
                self.comboBox_span_layer.setLayer(tmp_span)

            # Ensure Tight PON of 96 clustering method is active
            for i in range(self.comboBox_clustering_method.count()):
                if 'tight' in self.comboBox_clustering_method.itemText(i).lower():
                    self.comboBox_clustering_method.setCurrentIndex(i)
                    break

            # Preserve the full (unfiltered) span layer so splitter snapping
            # can use all Distribution spans — not just those inside the polygon
            self._pon_full_span_layer = span_lyr

            # BUGFIX: Reset ALL layer references before each batch so that if any step
            # fails silently, subsequent steps won't use previous batch's stale layers.
            # Previously only grouped_layer was reset; demand_points_layer and
            # splitter_points_layer stale references caused missing drops on some zones.
            self.grouped_layer = None
            self.demand_points_layer = None
            self.splitter_points_layer = None
            self.zone_boundaries_layer = None
            self.drop_ptp_layer = None

            # If the previous session was closed (button toggled off), start fresh:
            # null the old accumulators so the merge step creates new ones, and reset
            # zone/group counters so numbering starts from 1 again.
            # Also treat truly first-ever run (all None) as a fresh session.
            _accum_fresh = (
                getattr(self, '_pon_new_session_needed', False) or
                (getattr(self, '_pon_accum_groups',    None) is None and
                 getattr(self, '_pon_accum_splitters', None) is None)
            )
            if _accum_fresh:
                self._pon_accum_groups    = None
                self._pon_accum_zones     = None
                self._pon_accum_splitters = None
                self._pon_accum_drops     = None
                self._pon_batch_count  = 0
                # Persistent numbering: continue from the highest zone/group that
                # already exists in the project's SAVED PON layers, so a planner
                # who stops & resumes (or re-opens the project) keeps counting up
                # instead of restarting at Zone 1.
                _ez, _eg = self._pon_existing_offsets()
                self._pon_zone_offset  = _ez
                self._pon_group_offset = _eg
                self._pon_new_session_needed = False
                if _ez or _eg:
                    self.log_message(
                        f"  [PON per PON] Resuming — continuing numbering from "
                        f"zone {_ez + 1} / group {_eg + 1} (existing PON layers found)")
                else:
                    self.log_message("  [PON per PON] Fresh project — zone/group numbering starts at 1")

            # Advance the batch counter BEFORE running so the label is correct
            self._pon_batch_count += 1
            batch_label = f"PON Batch {self._pon_batch_count}"
            
            # Rotate zone polygon colors per batch (golden angle ~137.5° for max separation)
            self._pon_color_offset = (self._pon_batch_count * 0.382) % 1.0

            # Run the full 5-step pipeline with sequential offsets
            self.on_autonet_clicked(
                _zone_offset=self._pon_zone_offset,
                _group_offset=self._pon_group_offset,
                _batch_label=batch_label,
            )

            # Advance offsets for the next run using the max IDs written this run
            self._pon_group_offset = getattr(self, '_last_max_group', self._pon_group_offset)
            self._pon_zone_offset  = getattr(self, '_last_max_zone',  self._pon_zone_offset)

            # Merge batch-specific layers into persistent accumulators
            self.log_message("\n── Merging batch layers into persistent accumulators ──")
            self._pon_merge_batch_into_accumulators()

            # CRITICAL: clear the batch label NOW so that Manual Override drop regen
            # (which calls on_generate_drop_ptp_clicked) does NOT think it is inside a
            # batch run and correctly targets the accumulator instead of creating a new layer.
            self._current_batch_label = None

        finally:
            # Clear the full-span override and color offset now that the pipeline is done
            self._pon_full_span_layer = None
            self._pon_color_offset = 0.0

            # Restore original combo selections
            self.comboBox_erf.setLayer(_orig_demand)
            self.comboBox_span_layer.setLayer(_orig_span)
            if _orig_road:
                self.comboBox_road_layer.setLayer(_orig_road)

            # Remove the temporary filtered layers from the project
            for tid in filter(None, [tmp_demand_id, tmp_span_id]):
                try:
                    QgsProject.instance().removeMapLayer(tid)
                except Exception:
                    pass

            demand_lyr.removeSelection()
            span_lyr.removeSelection()

        # Stay in PON-per-PON mode so user can immediately select the next batch
        self._btn_pon_per_pon.setChecked(True)
        self._btn_pon_per_pon.setText("🎯 PON per PON Manual")

        btn = QMessageBox.question(
            self, "PON per PON — Continue?",
            "PON pipeline complete for this batch.\n\n"
            "Would you like to select and run the next PON batch?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if btn == QMessageBox.StandardButton.Yes:
            self._pon_per_pon_start()
        else:
            self._pon_per_pon_cancel()

    def on_generate_demand_points_clicked(self):
        """Generate demand points from grouped parcels at their centroids."""
        # Use the most recently generated grouped layer
        selected_layer = self.grouped_layer
        
        if not selected_layer:
            self.log_message("ERROR: Please generate grouped parcels first.")
            return
        
        self.log_message("\n=== Generating Demand Points ===")
        self.log_message(f"Source Layer: '{selected_layer.name()}'")
        
        try:
            from qgis.core import QgsVectorLayer, QgsFeature
            
            # Get features from source layer
            features = list(selected_layer.getFeatures())
            
            if len(features) == 0:
                self.log_message("ERROR: Layer has no features.")
                return
            
            # Create new point layer with same CRS
            crs = selected_layer.crs().authid()
            demand_layer = QgsVectorLayer(f"Point?crs={crs}", 
                                         f"{selected_layer.name()} - Demand Points", 
                                         "memory")
            provider = demand_layer.dataProvider()
            
            # Copy all fields from source layer
            provider.addAttributes(selected_layer.fields().toList())
            demand_layer.updateFields()
            
            # Create demand point for each parcel at its centroid
            total_src = len(features)
            self.log_message(f"Processing {total_src} features...")
            self._start_timer()
            demand_features = []
            for idx, feature in enumerate(features):
                self._progress(idx + 1, total_src, 'Demand pts')
                geom = feature.geometry()
                if geom and not geom.isEmpty():
                    # Get centroid
                    centroid = geom.centroid()
                    
                    # Create new point feature
                    demand_feature = QgsFeature(demand_layer.fields())
                    demand_feature.setGeometry(centroid)
                    
                    # Copy all attributes from source feature
                    for field in selected_layer.fields():
                        demand_feature[field.name()] = feature[field.name()]
                    
                    demand_features.append(demand_feature)
            
            # Add features to layer
            provider.addFeatures(demand_features)
            demand_layer.updateExtents()
            
            # Add layer to project
            demand_layer = self._add_output_layer(demand_layer)
            
            # Store reference for drop cable generation
            self.demand_points_layer = demand_layer
            
            self.log_message(f"\nCreated {len(demand_features)} demand points")
            self._elapsed("Total time")
            self.log_message(f"New layer: '{demand_layer.name()}'")
            self.log_message("All attributes copied from source parcels")
            
        except Exception as e:
            self.log_message(f"ERROR: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def apply_batch_symbology(self, layer: QgsVectorLayer, field_name: str = 'batch_id'):
        """Apply categorized symbology to show different batches/clusters in different colors.
        
        Args:
            layer: Layer with grouping field
            field_name: Name of the field to use for symbology
        """
        try:
            from qgis.core import (
                QgsCategorizedSymbolRenderer,
                QgsRendererCategory,
                QgsSymbol
            )
            from qgis.PyQt.QtGui import QColor
            import random
            
            field_idx = layer.fields().indexOf(field_name)
            
            if field_idx < 0:
                return
            
            # Get unique values
            unique_values = set()
            for feature in layer.getFeatures():
                value = feature.attribute(field_name)
                if value is not None:
                    unique_values.add(value)
            
            # Create categories
            categories = []
            for value in sorted(unique_values):
                # Generate a color for each group
                random.seed(value)  # Consistent colors for same value
                color = QColor(
                    random.randint(100, 255),
                    random.randint(100, 255),
                    random.randint(100, 255),
                    180  # Some transparency
                )
                
                symbol = QgsSymbol.defaultSymbol(layer.geometryType())
                symbol.setColor(color)
                
                # Determine label — for zone_name the stored value IS already
                # the human-readable label ("Zone 1", "Zone 2", …)
                if field_name == 'zone_name':
                    label = str(value)
                elif 'batch' in field_name.lower():
                    label = f"Batch {value}"
                elif 'cluster' in field_name.lower():
                    label = f"Cluster {value}"
                elif 'pon' in field_name.lower():
                    label = f"PON {value}"
                elif 'zone' in field_name.lower():
                    label = f"Zone {value}"
                else:
                    label = f"Group {value}"
                
                category = QgsRendererCategory(
                    value,
                    symbol,
                    label
                )
                categories.append(category)
            
            # Apply renderer
            renderer = QgsCategorizedSymbolRenderer(field_name, categories)
            layer.setRenderer(renderer)
            layer.triggerRepaint()
            
            self.log_message("  Applied color-coded symbology.")
            
        except Exception as e:
            # If symbology fails, just log it but don't fail the whole operation
            self.log_message(f"  (Could not apply symbology: {e!s})")

    def on_find_splitters_clicked(self):
        """Find and display optimal splitter locations."""
        selected_layer = self.comboBox_erf.currentLayer()
        
        if not selected_layer:
            self.log_message("ERROR: Please select a layer.")
            return
        
        if not SKLEARN_AVAILABLE or not NUMPY_AVAILABLE:
            self.log_message("ERROR: Splitter optimization requires scikit-learn and numpy.")
            self.log_message("Install with: pip install scikit-learn numpy")
            return
        
        num_splitters = 10  # Default number of splitters
        
        self.log_message("\n=== Finding Optimal Splitter Locations ===")
        self.log_message(f"Layer: '{selected_layer.name()}'")
        self.log_message(f"Number of splitters: {num_splitters}")
        
        try:
            # Get features
            features = list(selected_layer.getFeatures())
            
            if len(features) == 0:
                self.log_message("ERROR: Layer has no features.")
                return
            
            # Find optimal locations
            self._start_timer()
            splitter_locations = find_optimal_splitter_locations(features, num_splitters)
            
            # Create a memory layer for splitter points
            from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject, QgsField
            from qgis.PyQt.QtCore import QMetaType
            
            # Get CRS from source layer
            crs = selected_layer.crs().authid()
            splitter_layer = QgsVectorLayer(f"Point?crs={crs}", "Optimal Splitter Locations", "memory")
            provider = splitter_layer.dataProvider()
            
            # Add fields
            provider.addAttributes([
                QgsField("splitter_id", QMetaType.Type.Int),
                QgsField("x_coord", QMetaType.Type.Double),
                QgsField("y_coord", QMetaType.Type.Double)
            ])
            splitter_layer.updateFields()
            
            # Add splitter points
            splitter_features = []
            for idx, location in enumerate(splitter_locations):
                feat = QgsFeature()
                feat.setGeometry(QgsGeometry.fromPointXY(location))
                feat.setAttributes([idx + 1, location.x(), location.y()])
                splitter_features.append(feat)
            
            provider.addFeatures(splitter_features)
            splitter_layer.updateExtents()
            
            # Style the splitter layer
            from qgis.core import QgsMarkerSymbol, QgsSingleSymbolRenderer
            
            symbol = QgsMarkerSymbol.createSimple({
                'name': 'star',
                'color': 'red',
                'size': '4',
                'outline_color': 'white',
                'outline_width': '0.5'
            })
            renderer = QgsSingleSymbolRenderer(symbol)
            splitter_layer.setRenderer(renderer)
            
            # Add layer to project
            QgsProject.instance().addMapLayer(splitter_layer)
            
            self.log_message(f"\nCreated {len(splitter_locations)} optimal splitter locations.")
            self.log_message("Splitter layer added to map.")
            self.log_message("Locations minimize average distance to parcels/points.")
            self._elapsed("Total time")
            
        except Exception as e:
            self.log_message(f"ERROR: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_cluster_erven_clicked(self, _zone_offset=0, _group_offset=0, _batch_label=None):
        """Generate PON groups using Tight PON of 96 (groups of 8) along Distribution spans.

        _zone_offset  – add this to every zone_id so runs don't clash (PON-per-PON mode).
        _group_offset – add this to every group_id so runs don't clash.
        _batch_label  – suffix appended to output layer names (e.g. "PON Batch 2").
        """
        from qgis.core import QgsVectorLayer, QgsFeature, QgsField
        from qgis.PyQt.QtCore import QMetaType

        selected_layer = self.comboBox_erf.currentLayer()
        if not selected_layer:
            self.log_message("ERROR: Please select a layer.")
            return

        layer_type_name = "Demand Points"
        target_size = 8
        continuous_mode = False

        self.log_message(f"\n=== Grouping {layer_type_name} ===")
        self.log_message(f"Layer: '{selected_layer.name()}' ({selected_layer.featureCount()} features)")

        _input_fields = [f.name() for f in selected_layer.fields()]
        if 'zone_name' in _input_fields or 'group_8' in _input_fields:
            self.log_message(
                "⚠ WARNING: The selected layer already has 'zone_name'/'group_8' fields — "
                "it appears to be a previously grouped layer, NOT the original demand points. "
                "Please select the ORIGINAL demand points layer in the dropdown above."
            )
        _subset = selected_layer.subsetString()
        if _subset:
            self.log_message(
                f"⚠ WARNING: Layer has an active filter: {_subset!r}. "
                "Only filtered features will be grouped."
            )

        try:
            features = list(selected_layer.getFeatures())
            total_features = len(features)

            if total_features == 0:
                self.log_message("ERROR: Layer has no features.")
                return

            route_layer = self.comboBox_span_layer.currentLayer()
            road_layer  = self.comboBox_road_layer.currentLayer()
            if road_layer:
                self.log_message(f"Road barrier layer: '{road_layer.name()}'")

            try:
                network_coverage = self.doubleSpinBox_span_corridor.value()
            except AttributeError:
                network_coverage = 150.0
            group_cohesion = 120
            gap_tolerance  = 3

            geom_type     = selected_layer.geometryType()
            is_point_layer = (geom_type == 0)

            if route_layer:
                self.log_message(f"Grouping along route: '{route_layer.name()}'")
                route_field_names = [f.name() for f in route_layer.fields()]
                if 'Cable Type' in route_field_names:
                    self.log_message("🎯 FILTERING: Only Distribution spans (Cable Type = 'Distribution')")
                else:
                    self.log_message("⚠ WARNING: Span layer has no 'Cable Type' field — using ALL spans")
                self.log_message(f"Span corridor: {network_coverage:.0f} m")
            else:
                self.log_message("Grouping without route — detecting block boundaries...")

            self.log_message(f"Clustering {total_features} features into groups of {target_size}...")
            self._start_operation("Generating PON Groups…")
            QApplication.processEvents()

            feature_to_group = cluster_tight_groups_of_8(
                features,
                route_layer=route_layer,
                target_size=target_size,
                span_proximity_limit=network_coverage,
                adjacency_distance=group_cohesion,
                gap_tolerance_multiplier=gap_tolerance,
                progress_callback=lambda done, total, lbl='Clustering': self._progress(done, total, lbl),
                road_layer=road_layer,
                demand_crs=selected_layer.crs(),
            )

            if not feature_to_group:
                self.log_message("ERROR: No features could be grouped.")
                return

            import time as _time
            self.log_message(f"  ⏱ Clustering — {self._fmt_time(_time.time() - self._op_t0)}")

            crs = selected_layer.crs().authid()
            geom_name = {0: "Point", 1: "LineString", 2: "Polygon"}.get(geom_type, "Polygon")
            _lyr_suffix = f" - {_batch_label}" if _batch_label else f" - Groups of {target_size}"
            new_layer = QgsVectorLayer(
                f"{geom_name}?crs={crs}",
                f"{selected_layer.name()}{_lyr_suffix}",
                "memory"
            )
            provider = new_layer.dataProvider()
            provider.addAttributes(selected_layer.fields().toList())
            field_name = f'group_{target_size}'
            provider.addAttributes([QgsField(field_name, QMetaType.Type.Int)])
            zone_field_name  = 'zone_id'
            zone_name_field  = 'zone_name'
            provider.addAttributes([
                QgsField(zone_field_name,  QMetaType.Type.Int),
                QgsField(zone_name_field,  QMetaType.Type.QString),
            ])
            new_layer.updateFields()

            feature_positions = {}
            for feat in features:
                geom = feat.geometry()
                if geom and not geom.isEmpty():
                    c = geom.centroid().asPoint()
                    feature_positions[feat.id()] = (c.x(), c.y())

            # In PON-per-PON mode the whole selection IS one zone — no 96-unit cap.
            # In normal AutoNet mode keep the 96-unit cap.
            zone_max_size = total_features if _batch_label else 96
            olt_layer = self.comboBox_olt_layer.currentLayer()
            feature_to_zone = group_zones_from_groups(
                feature_to_group,
                max_zone_size=zone_max_size,
                feature_positions=feature_positions,
                route_layer=route_layer,
                pop_layer=olt_layer,
            )

            _no_group = sum(1 for f in features if feature_to_group.get(f.id()) is None)
            self.log_message(
                f"Grouped: {len(feature_to_group)} / {total_features} features "
                f"({_no_group} skipped)"
            )

            self.log_message("Building output layer...")
            new_features = []
            _ungrouped_count = 0
            for idx, feat in enumerate(features):
                self._progress(idx + 1, total_features, 'Output')
                group_id = feature_to_group.get(feat.id())
                z_id = feature_to_zone.get(feat.id()) if group_id is not None else None
                if group_id is None:
                    _ungrouped_count += 1

                # Apply offsets so each PON-per-PON batch has globally unique IDs
                g_out = (group_id + _group_offset) if group_id is not None else None
                z_out = (z_id    + _zone_offset)   if z_id    is not None else None

                new_feat = QgsFeature(new_layer.fields())
                new_feat.setGeometry(feat.geometry())
                for field in selected_layer.fields():
                    new_feat[field.name()] = feat[field.name()]
                new_feat[field_name]        = g_out
                new_feat[zone_field_name]   = z_out
                new_feat[zone_name_field]   = f"Zone {z_out}" if z_out is not None else None
                new_features.append(new_feat)

            if _ungrouped_count:
                self.log_message(
                    f"WARNING: {_ungrouped_count} features had no group assignment"
                )

            provider.addFeatures(new_features)
            new_layer.updateExtents()
            new_layer = self._add_output_layer(new_layer)

            self.grouped_layer = new_layer

            total_clusters = len(set(v for v in feature_to_group.values() if v is not None))
            total_zones    = len(set(v for v in feature_to_zone.values()  if v is not None)) if feature_to_zone else 0

            # Compute the true max output IDs (with offset applied) for the caller
            max_group_out = (max((v for v in feature_to_group.values() if v is not None), default=0)
                             + _group_offset)
            max_zone_out  = (max((v for v in feature_to_zone.values()  if v is not None), default=0)
                             + _zone_offset) if feature_to_zone else _zone_offset

            self.apply_batch_symbology(new_layer, zone_name_field)

            self.log_message(
                f"\nCreated {total_clusters} groups → {total_zones} zones "
                f"(max {zone_max_size} units/zone)"
            )
            if _zone_offset:
                self.log_message(f"  Zone IDs: {_zone_offset + 1} – {max_zone_out}")
            self.log_message("\nGrouping completed successfully!")
            self._elapsed("Total time")
            self.log_message(f"  New layer: '{new_layer.name()}'")

            # Expose the max IDs so _pon_per_pon_run can advance the offsets
            self._last_max_group = max_group_out
            self._last_max_zone  = max_zone_out
        except Exception as e:
            self.log_message(f"ERROR: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def _apply_cluster_symbology(self, layer: QgsVectorLayer):
        """Apply categorized symbology to show different clusters in different colors.
        
        Args:
            layer: Layer with cluster_id field
        """
        try:
            from qgis.core import (
                QgsCategorizedSymbolRenderer,
                QgsRendererCategory,
                QgsSymbol
            )
            from qgis.PyQt.QtGui import QColor
            import random
            
            field_name = 'cluster_id'
            field_idx = layer.fields().indexOf(field_name)
            
            if field_idx < 0:
                return
            
            # Get unique cluster values
            unique_values = set()
            for feature in layer.getFeatures():
                cluster_id = feature.attribute(field_name)
                if cluster_id is not None:
                    unique_values.add(cluster_id)
            
            # Create categories
            categories = []
            for cluster_id in sorted(unique_values):
                # Generate a color for each cluster
                random.seed(cluster_id)  # Consistent colors for same cluster
                color = QColor(
                    random.randint(100, 255),
                    random.randint(100, 255),
                    random.randint(100, 255),
                    200  # Some transparency
                )
                
                symbol = QgsSymbol.defaultSymbol(layer.geometryType())
                symbol.setColor(color)
                
                category = QgsRendererCategory(
                    cluster_id,
                    symbol,
                    f"Cluster {cluster_id}"
                )
                categories.append(category)
            
            # Create and set the renderer
            renderer = QgsCategorizedSymbolRenderer(field_name, categories)
            layer.setRenderer(renderer)
            layer.triggerRepaint()
            
        except Exception as e:
            # If symbology fails, just log it but don't fail the whole operation
            self.log_message(f"  (Could not apply cluster symbology: {e!s})")

    def on_show_batch_stats_clicked(self):
        """Show statistics about batch assignments."""
        erf_layer = self.comboBox_erf.currentLayer()
        
        if not erf_layer:
            self.log_message("ERROR: Please select an ERF layer.")
            return
        
        field_idx = erf_layer.fields().indexOf('batch_id')
        if field_idx < 0:
            self.log_message("ERROR: Layer has no 'batch_id' field. Please group ERF parcels first.")
            return
        
        self.log_message("\n=== Batch Statistics ===")
        self.log_message(f"Layer: '{erf_layer.name()}'")
        
        try:
            stats = get_batch_statistics(erf_layer)
            self._start_timer()
            if not stats:
                self.log_message("No batch data found.")
                return
            
            self.log_message(f"\nTotal batches: {stats['total_batches']}")
            self.log_message(f"Average batch size: {stats['avg_batch_size']:.1f}")
            
            # Show details for each batch
            self.log_message("\nBatch Details:")
            for batch_id in sorted(stats['batch_counts'].keys()):
                count = stats['batch_counts'][batch_id]
                extent = stats['batch_extents'].get(batch_id)
                
                if extent:
                    extent_str = f"({extent.xMinimum():.2f}, {extent.yMinimum():.2f}) to ({extent.xMaximum():.2f}, {extent.yMaximum():.2f})"
                else:
                    extent_str = "N/A"
                
                self.log_message(f"  Batch {batch_id}: {count} parcels")
                self.log_message(f"    Extent: {extent_str}")
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR getting batch statistics: {e!s}")

    def _build_zone_polygon(self, grouped_layer, zone_feats):
        """Return a QgsGeometry zone polygon for a list of demand features.
        Uses the same buffer + morphological-closing algorithm as
        on_generate_boundaries_clicked so the shapes stay consistent."""
        from qgis.core import QgsGeometry, QgsUnitTypes
        is_point_layer = grouped_layer.geometryType() == 0
        geoms = [f.geometry() for f in zone_feats if not f.geometry().isEmpty()]
        if not geoms:
            return QgsGeometry()
        if is_point_layer:
            unit_type = grouped_layer.crs().mapUnits()
            if unit_type == QgsUnitTypes.DistanceUnit.DistanceDegrees:
                min_r, max_r = 0.00005, 0.00025
            else:
                min_r, max_r = 5.0, 30.0
            coords = [f.geometry().asPoint()
                      for f in zone_feats if not f.geometry().isEmpty()]
            if len(coords) <= 1:
                radius = max_r
            else:
                nn_sum, nn_count = 0.0, 0
                for i, pt in enumerate(coords):
                    best = float('inf')
                    for j, other in enumerate(coords):
                        if i == j:
                            continue
                        d = ((pt.x() - other.x()) ** 2 +
                             (pt.y() - other.y()) ** 2) ** 0.5
                        if d < best:
                            best = d
                    if best < float('inf'):
                        nn_sum += best
                        nn_count += 1
                mean_nn = nn_sum / nn_count if nn_count else max_r
                radius = max(min(mean_nn * 0.55, max_r), min_r)
            zone_geom = zone_feats[0].geometry().buffer(radius, 8)
            for f in zone_feats[1:]:
                if not f.geometry().isEmpty():
                    zone_geom = zone_geom.combine(
                        f.geometry().buffer(radius, 8))
            gap_r = radius * 2.5
            zone_geom = zone_geom.buffer(gap_r, 6).buffer(-gap_r * 0.92, 6)
            if not zone_geom.isEmpty():
                if zone_geom.isMultipart():
                    zone_geom = zone_geom.convexHull()
                else:
                    poly = zone_geom.asPolygon()
                    if poly:
                        zone_geom = QgsGeometry.fromPolygonXY([poly[0]])
        else:
            merged = geoms[0]
            for g in geoms[1:]:
                merged = merged.combine(g)
            zone_geom = merged.convexHull()
        return zone_geom

    # ── Boundary-generation helpers (class-level so they aren't recreated ──
    # ── on every button click)                                            ──

    @staticmethod
    def _snap_parts_together(geom, bridge_r):
        """Connect all multipart fragments by bridging nearest-point pairs."""
        if not geom.isMultipart():
            return geom
        parts = list(geom.asGeometryCollection())
        while len(parts) > 1:
            min_d = float('inf')
            bi, bj = 0, 1
            bp1 = bp2 = None
            for ii in range(len(parts)):
                for jj in range(ii + 1, len(parts)):
                    d = parts[ii].distance(parts[jj])
                    if d < min_d:
                        min_d = d
                        bi, bj = ii, jj
                        bp1 = parts[ii].nearestPoint(parts[jj]).asPoint()
                        bp2 = parts[jj].nearestPoint(parts[ii]).asPoint()
            if bp1 is None or bp2 is None:
                break
            bridge = QgsGeometry.fromPolylineXY([
                QgsPointXY(bp1.x(), bp1.y()),
                QgsPointXY(bp2.x(), bp2.y()),
            ]).buffer(bridge_r, 4)
            merged_part = parts[bi].combine(parts[bj]).combine(bridge)
            parts = [parts[k] for k in range(len(parts)) if k != bi and k != bj]
            parts.append(merged_part)
        return parts[0] if parts else geom

    @staticmethod
    def _centroid_xy(pts):
        """Return (mean_x, mean_y) of a list of QgsPointXY."""
        if not pts:
            return (0, 0)
        return (sum(p.x() for p in pts) / len(pts),
                sum(p.y() for p in pts) / len(pts))

    @staticmethod
    def _force_single(geom, z_n, zone_build_params):
        """Rebuild a multipart geometry into one solid polygon."""
        if not geom.isMultipart():
            return geom
        zp = zone_build_params.get(z_n, {})
        radius_z = zp.get('radius', 5.0)
        result = FTTHPlanToolDockWidget._snap_parts_together(geom, radius_z)
        if not result.isMultipart():
            return result
        hull = geom.convexHull()
        return hull if not hull.isEmpty() else geom

    def on_generate_boundaries_clicked(self):
        """Generate one polygon boundary per PON zone from the grouped demand points layer."""
        # Prefer the stored reference; fall back to searching project layers by field
        grouped_layer = self.grouped_layer
        if not grouped_layer:
            # Pick the grouped layer with the MOST features to avoid stale partial layers
            _best_layer = None
            _best_count = -1
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    if 'zone_name' in [f.name() for f in layer.fields()]:
                        _fc = layer.featureCount()
                        if _fc > _best_count:
                            _best_count = _fc
                            _best_layer = layer
            grouped_layer = _best_layer

        if not grouped_layer:
            self.log_message("ERROR: No grouped PON layer found. Run 'Generate PON Groups' first.")
            return

        field_names = [f.name() for f in grouped_layer.fields()]
        if 'zone_name' not in field_names:
            self.log_message("ERROR: Layer has no 'zone_name' field. Run 'Generate PON Groups' first.")
            return

        has_zone_id = 'zone_id' in field_names
        is_point_layer = grouped_layer.geometryType() == 0

        self.log_message("\n=== Generating PON Zone Boundaries ===")
        self.log_message(f"Source layer: '{grouped_layer.name()}' ({grouped_layer.featureCount()} features)")
        if not self.grouped_layer:
            self.log_message("  (using project layer — if incomplete, re-run 'Generate PON Groups' first)")

        try:
            crs = grouped_layer.crs().authid()

            polygon_layer = QgsVectorLayer(
                f"Polygon?crs={crs}",
                f"{grouped_layer.name()} - PON Zones",
                "memory"
            )
            poly_provider = polygon_layer.dataProvider()
            poly_provider.addAttributes([
                QgsField('zone_name', QMetaType.Type.QString),
                QgsField('zone_id', QMetaType.Type.Int),
                QgsField('unit_count', QMetaType.Type.Int),
                QgsField('splitter_count', QMetaType.Type.Int),
            ])
            polygon_layer.updateFields()

            # Group field on the source layer — one PON group == one STS splitter,
            # so the number of distinct groups in a zone IS its splitter count
            # (used for the zone-boundary label, per the planner request).
            _grp_field = next(
                (fn for fn in ('group_id', 'group_8', 'group_16', 'group_128',
                               'group_100', 'batch_id') if fn in field_names),
                None)

            # Collect features per zone
            features_by_zone = {}
            zone_id_map = {}
            _total_feats = 0
            _null_zone_feats = 0
            _null_zone_list = []
            for feat in grouped_layer.getFeatures():
                _total_feats += 1
                z_name = feat['zone_name']
                if not z_name:
                    _null_zone_feats += 1
                    _null_zone_list.append(feat)
                    continue
                if z_name not in features_by_zone:
                    features_by_zone[z_name] = []
                    zone_id_map[z_name] = feat['zone_id'] if has_zone_id else 0
                features_by_zone[z_name].append(feat)
            self.log_message(f"Layer features: {_total_feats} total, "
                             f"{_total_feats - _null_zone_feats} with zone, "
                             f"{_null_zone_feats} with NULL zone_name (assigning to nearest zone)")

            # Assign NULL-zone features to the geographically nearest zone
            if _null_zone_list and features_by_zone:
                # Build one centroid per zone from its members
                _zone_cx = {}
                _zone_cy = {}
                for _zn, _zfeats in features_by_zone.items():
                    _xs = [_zf.geometry().centroid().asPoint().x()
                           for _zf in _zfeats
                           if not _zf.geometry().isEmpty()]
                    _ys = [_zf.geometry().centroid().asPoint().y()
                           for _zf in _zfeats
                           if not _zf.geometry().isEmpty()]
                    if _xs:
                        _zone_cx[_zn] = sum(_xs) / len(_xs)
                        _zone_cy[_zn] = sum(_ys) / len(_ys)
                _zone_names_sorted = list(_zone_cx.keys())
                for _nf in _null_zone_list:
                    _nf_geom = _nf.geometry()
                    if not _nf_geom or _nf_geom.isEmpty():
                        continue
                    _pt = _nf_geom.centroid().asPoint()
                    _best_z = min(
                        _zone_names_sorted,
                        key=lambda _zn: (_pt.x() - _zone_cx[_zn]) ** 2
                                       + (_pt.y() - _zone_cy[_zn]) ** 2
                    )
                    features_by_zone[_best_z].append(_nf)

            # Build one polygon per zone
            zone_polygons = []
            zone_build_params = {}   # z_name → {radius, mean_nn, coords}
            _total_zones = len(features_by_zone)

            self._start_timer()
            _QApp = QApplication
            _QApp.processEvents()
            for _bz_idx, (z_name, zone_feats) in enumerate(sorted(
                    features_by_zone.items(),
                    key=lambda kv: zone_id_map.get(kv[0], 0))):
                self._progress(_bz_idx + 1, _total_zones, 'Boundaries')

                geoms = [f.geometry() for f in zone_feats if not f.geometry().isEmpty()]
                if not geoms:
                    continue

                z_id = zone_id_map.get(z_name, 0)
                count = len(zone_feats)
                # splitter count = distinct groups in this zone (1 STS per group)
                if _grp_field:
                    splitter_count = len({_zf[_grp_field] for _zf in zone_feats
                                          if _zf[_grp_field] is not None})
                else:
                    splitter_count = 0

                if is_point_layer:
                    unit_type = grouped_layer.crs().mapUnits()
                    if unit_type == QgsUnitTypes.DistanceUnit.DistanceDegrees:
                        min_r, max_r = 0.00004, 0.00025   # ~4 m – 28 m at equator
                    else:
                        min_r, max_r = 4.0, 30.0           # metres

                    coords = [f.geometry().asPoint()
                              for f in zone_feats if not f.geometry().isEmpty()]

                    if len(coords) <= 1:
                        radius = max_r
                        mean_nn = max_r
                    else:
                        nn_sum, nn_count = 0.0, 0
                        for i, pt in enumerate(coords):
                            best = float('inf')
                            for j, other in enumerate(coords):
                                if i == j:
                                    continue
                                d = ((pt.x()-other.x())**2 +
                                     (pt.y()-other.y())**2) ** 0.5
                                if d < best:
                                    best = d
                            if best < float('inf'):
                                nn_sum += best
                                nn_count += 1
                        mean_nn = nn_sum / nn_count if nn_count else max_r
                        radius = max(min(mean_nn * 0.55, max_r), min_r)

                    # Buffer every point and union
                    merged = geoms[0].buffer(radius, 12)
                    for g in geoms[1:]:
                        merged = merged.combine(g.buffer(radius, 12))

                    # First: light morphological close to merge same-side gaps
                    close_r = radius * 0.5
                    candidate = merged.buffer(close_r, 8).buffer(-close_r, 8)
                    zone_geom = candidate if not candidate.isEmpty() else merged

                    # Second: if still multipart, directly snap parts together
                    if zone_geom.isMultipart():
                        zone_geom = self._snap_parts_together(zone_geom, radius)

                    # Last resort: convex hull (always single polygon)
                    if zone_geom.isMultipart():
                        zone_geom = zone_geom.convexHull()

                    # Store params for post-overlap consolidation
                    zone_build_params[z_name] = {
                        'radius': radius, 'mean_nn': mean_nn, 'coords': coords
                    }

                else:
                    # Dissolve parcel polygons then convex hull for a clean outer envelope
                    merged = geoms[0]
                    for g in geoms[1:]:
                        merged = merged.combine(g)
                    zone_geom = merged.convexHull()

                poly_feat = QgsFeature(polygon_layer.fields())
                poly_feat.setGeometry(zone_geom)
                poly_feat.setAttributes([z_name, z_id, count, splitter_count])
                zone_polygons.append(poly_feat)

            # ── Remove overlaps between zone polygons ─────────────────────────
            # For any area where two zones overlap, assign it to whichever zone
            # has a demand point closer to that overlap region.
            if len(zone_polygons) > 1:
                # Build working list
                zone_data = []
                for pf in zone_polygons:
                    z = pf.attribute('zone_name')
                    pts = [f.geometry().asPoint()
                           for f in features_by_zone.get(z, [])
                           if not f.geometry().isEmpty()]
                    zone_data.append([pf.geometry(), pts, pf])

                # Subtract overlaps: zone that owns an overlap area keeps it
                clipped_geoms = []
                for i, (g_i, pts_i, feat_i) in enumerate(zone_data):
                    clipped = g_i
                    z_name_i = feat_i.attribute('zone_name')
                    cx_i, cy_i = self._centroid_xy(pts_i)
                    for j, (g_j, pts_j, feat_j) in enumerate(zone_data):
                        if i == j:
                            continue
                        inter = clipped.intersection(g_j)
                        if inter.isEmpty():
                            continue
                        oc = inter.centroid().asPoint()
                        cx_j, cy_j = self._centroid_xy(pts_j)
                        di = (oc.x()-cx_i)**2 + (oc.y()-cy_i)**2
                        dj = (oc.x()-cx_j)**2 + (oc.y()-cy_j)**2
                        if dj < di:
                            diff = clipped.difference(inter)
                            if not diff.isEmpty():
                                clipped = diff
                            # If the difference fragmented the polygon, immediately
                            # consolidate back to a single polygon.
                            if clipped.isMultipart():
                                clipped = self._force_single(clipped, z_name_i, zone_build_params)
                    clipped_geoms.append(clipped)

                # Re-add any demand point that fell outside its clipped polygon
                unit_type = grouped_layer.crs().mapUnits()
                for i in range(len(clipped_geoms)):
                    z_n = zone_polygons[i].attribute('zone_name')
                    pts_i = zone_data[i][1]
                    if not pts_i:
                        continue
                    pad_r = zone_build_params.get(z_n, {}).get(
                        'radius',
                        0.000009 if unit_type == QgsUnitTypes.DistanceUnit.DistanceDegrees else 5.0
                    )
                    clipped = clipped_geoms[i]
                    for _pt in pts_i:
                        pt_geom = QgsGeometry.fromPointXY(_pt)
                        if not clipped.contains(pt_geom):
                            clipped = clipped.combine(pt_geom.buffer(pad_r, 8))
                    clipped_geoms[i] = clipped

                # Final pass: guarantee every zone is a single solid polygon
                for i in range(len(clipped_geoms)):
                    if clipped_geoms[i].isMultipart():
                        z_n = zone_polygons[i].attribute('zone_name')
                        clipped_geoms[i] = self._force_single(clipped_geoms[i], z_n, zone_build_params)

                for i, pf in enumerate(zone_polygons):
                    pf.setGeometry(clipped_geoms[i])

            poly_provider.addFeatures(zone_polygons)
            polygon_layer.updateExtents()

            # Categorised renderer — distinct colour per zone
            # For PON-per-PON batches, rotate hue by _pon_color_offset for visual separation
            _hue_base = getattr(self, '_pon_color_offset', 0.0)
            n = max(len(zone_polygons), 1)
            categories = []
            for i, pf in enumerate(zone_polygons):
                z_name = pf.attribute('zone_name')
                hue = (_hue_base + (i / n)) % 1.0
                r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.65, 0.88)]
                fill_col    = QColor(r, g, b, 70)
                outline_col = QColor(r, g, b, 230)
                sym = QgsFillSymbol.createSimple({
                    'color':         fill_col.name(QColor.NameFormat.HexArgb),
                    'outline_color': outline_col.name(),
                    'outline_width': '1.2',
                    'outline_style': 'solid',
                })
                categories.append(QgsRendererCategory(z_name, sym, z_name))

            polygon_layer.setRenderer(QgsCategorizedSymbolRenderer('zone_name', categories))

            # Labels — zone name + unit count + splitter count
            label_settings = QgsPalLayerSettings()
            label_settings.fieldName = (
                "zone_name || '\n' || unit_count || ' units' || "
                "'\n' || splitter_count || ' splitters'")
            label_settings.isExpression = True
            label_settings.enabled = True

            text_fmt = QgsTextFormat()
            text_fmt.setFont(QFont('Arial', 9, QFont.Weight.Bold))
            text_fmt.setSize(9)
            text_fmt.setColor(QColor('#1a1a1a'))

            buf = QgsTextBufferSettings()
            buf.setEnabled(True)
            buf.setSize(1.0)
            buf.setColor(QColor('white'))
            text_fmt.setBuffer(buf)
            label_settings.setFormat(text_fmt)

            # Ticket #52 — flag the zone label BRIGHT RED when a PON exceeds 16 splitters
            # (16 is the max; >16 is over capacity). Data-defined text colour.
            try:
                from qgis.core import QgsProperty
                label_settings.dataDefinedProperties().setProperty(
                    QgsPalLayerSettings.Color,
                    QgsProperty.fromExpression(
                        "CASE WHEN \"splitter_count\" > 16 THEN '#ff0000' ELSE '#1a1a1a' END"))
            except Exception as _e:
                self.log_message(f"  ⚠ splitter-overflow label colour skipped: {_e}")

            polygon_layer.setLabeling(QgsVectorLayerSimpleLabeling(label_settings))
            polygon_layer.setLabelsEnabled(True)

            polygon_layer = self._add_output_layer(polygon_layer)
            self.zone_boundaries_layer = polygon_layer  # store for PON-per-PON merge
            self.log_message(f"Layer: '{polygon_layer.name()}'")
            for pf in zone_polygons:
                self.log_message(
                    f"  {pf.attribute('zone_name')}: {pf.attribute('unit_count')} units")
            self._elapsed("Total time")

        except Exception as e:
            self.log_message(f"ERROR generating PON zone boundaries: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_generate_splitters_clicked(self):
        """Generate splitter points on span line for each group."""
        from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject, QgsField, QgsPointXY
        from qgis.PyQt.QtCore import QMetaType
        import math
        
        # Find the grouped layer — prefer the instance reference set by Step 1
        grouped_layer = None
        try:
            import sip as _sip
            if self.grouped_layer and not _sip.isdeleted(self.grouped_layer):
                grouped_layer = self.grouped_layer
        except Exception:
            pass
        if not grouped_layer:
            # Fallback: find the most recently added grouped layer (highest feature count as tie-breaker)
            _best_layer = None
            _best_count = -1
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    layer_name = layer.name().lower()
                    if (('groups of 8' in layer_name or 'group of 8' in layer_name or
                         'groups of 16' in layer_name or 'group of 16' in layer_name or
                         'groups of 128' in layer_name or 'group of 128' in layer_name or
                         'groups of 100' in layer_name or 'group of 100' in layer_name) and
                       'boundary' not in layer_name and
                       'splitter' not in layer_name):
                        _fc = layer.featureCount()
                        if _fc > _best_count:
                            _best_count = _fc
                            _best_layer = layer
            if _best_layer:
                self.log_message(f"⚠ WARNING: self.grouped_layer was None — using fallback layer '{_best_layer.name()}' "
                                 f"({_best_count} features). Check if step 1 ran correctly for this batch.")
                grouped_layer = _best_layer
        
        if not grouped_layer:
            self.log_message("ERROR: Could not find grouped layer.")
            self.log_message("Please run 'Group Parcels/Points' first.")
            return
        
        # Get span layer — for PON-per-PON use the full (unfiltered) span so all
        # Distribution spans are available for snapping, not just those inside the polygon
        _full_span = getattr(self, '_pon_full_span_layer', None)
        if _full_span is not None:
            try:
                import sip as _sip_fs
                if _sip_fs.isdeleted(_full_span):
                    _full_span = None
            except Exception:
                _full_span = None
        span_layer = _full_span or self.comboBox_span_layer.currentLayer()
        if not span_layer:
            self.log_message("ERROR: Please select a Route/Span layer.")
            return
        
        # Check for group field
        group_field = None
        if 'group_8' in [f.name() for f in grouped_layer.fields()]:
            group_field = 'group_8'
        elif 'group_16' in [f.name() for f in grouped_layer.fields()]:
            group_field = 'group_16'
        elif 'group_128' in [f.name() for f in grouped_layer.fields()]:
            group_field = 'group_128'
        elif 'group_100' in [f.name() for f in grouped_layer.fields()]:
            group_field = 'group_100'
        elif 'batch_id' in [f.name() for f in grouped_layer.fields()]:
            group_field = 'batch_id'
        
        if not group_field:
            self.log_message("ERROR: Layer must have 'group_8', 'group_16', 'group_128', 'group_100', or 'batch_id' field.")
            return

        # Detect aggregation zone field so each splitter records which zone it belongs to
        src_field_names = [f.name() for f in grouped_layer.fields()]
        zone_field_src = None
        if 'zone_id' in src_field_names:
            zone_field_src = 'zone_id'
        elif 'group_100' in src_field_names:
            zone_field_src = 'group_100'

        self.log_message("\n=== Generating Splitter Points ===")
        self.log_message(f"Source layer: '{grouped_layer.name()}'")
        self.log_message(f"Source layer feature count: {grouped_layer.featureCount()}")
        self.log_message(f"Source layer fields: {[f.name() for f in grouped_layer.fields()]}")
        self.log_message(f"Span layer: '{span_layer.name()}'")
        self.log_message(f"Group field detected: '{group_field}'")
        # Check if span layer has Cable Type field for filtering Distribution spans
        span_field_names = [f.name() for f in span_layer.fields()]
        has_cable_type = 'Cable Type' in span_field_names
        if has_cable_type:
            self.log_message("🎯 FILTERING: Splitters will ONLY snap to Distribution spans (Cable Type = 'Distribution')")
            self.log_message("   Feeder and other span types will be IGNORED for splitter placement.")
            # Check all unique Cable Type values and count Distribution spans
            cable_types_found = set()
            dist_count = 0
            for _sf in span_layer.getFeatures():
                ct = str(_sf['Cable Type'] or '').strip()
                cable_types_found.add(ct)
                if ct.lower() == 'distribution':
                    dist_count += 1
            self.log_message(f"   Cable Type values in span layer: {sorted(cable_types_found)}")
            self.log_message(f"   Found {dist_count} Distribution span features")
            if dist_count == 0:
                self.log_message(
                    "⚠ WARNING: No Distribution spans found — falling back to ALL spans for splitter placement."
                )
                has_cable_type = False  # disable filter so all spans are used
        else:
            self.log_message("⚠ WARNING: Span layer has no 'Cable Type' field — using ALL spans for splitter placement")
        
        try:
            crs = grouped_layer.crs().authid()
            
            # Build layer name — include batch label when running PON-per-PON
            _splitter_layer_name = "Splitter Points"
            if getattr(self, '_current_batch_label', None):
                _splitter_layer_name = f"Splitter Points - {self._current_batch_label}"

            # Create splitter points layer
            splitter_layer = QgsVectorLayer(f"Point?crs={crs}",
                                           _splitter_layer_name,
                                           "memory")
            provider = splitter_layer.dataProvider()
            
            # Add fields
            provider.addAttributes([
                QgsField('fid', QMetaType.Type.Int),
                QgsField('ID', QMetaType.Type.QString),
                QgsField('group_id', QMetaType.Type.Int),
                QgsField('zone_id', QMetaType.Type.Int),    # aggregation zone membership
                QgsField('drop_count', QMetaType.Type.Int),   # number of demand points in this group
            ])
            splitter_layer.updateFields()
            
            # --- Locate poles layer for snapping (optional) ---
            from qgis.core import QgsSpatialIndex
            poles_layer = None
            for lyr in QgsProject.instance().mapLayers().values():
                if isinstance(lyr, QgsVectorLayer) and lyr.geometryType() == 0:  # Point
                    if lyr.name().lower().startswith('poles_') and 'pole_type' in [f.name() for f in lyr.fields()]:
                        poles_layer = lyr
                        break

            # Build spatial index + coordinate lookup for poles on DISTRIBUTION spans only
            pole_coords = {}   # feature_id -> QgsPointXY
            pole_index = None
            if poles_layer:
                # PRE-FILTER: Only include poles that are on Distribution spans
                # For each pole, check if it's within snap distance of a Distribution span
                distribution_pole_ids = set()
                pole_snap_tolerance = 5.0  # meters - poles within 5m of a Distribution span
                
                if has_cable_type:
                    # Build spatial index of Distribution spans
                    dist_span_index = QgsSpatialIndex()
                    dist_span_geoms = {}
                    for span_feat in span_layer.getFeatures():
                        if str(span_feat['Cable Type'] or '').strip().lower() == 'distribution':
                            dist_span_index.insertFeature(span_feat)
                            dist_span_geoms[span_feat.id()] = span_feat.geometry()
                    
                    # Check each pole against Distribution spans
                    for pf in poles_layer.getFeatures():
                        pole_pt = pf.geometry().asPoint()
                        pole_bbox = QgsRectangle(
                            pole_pt.x() - pole_snap_tolerance,
                            pole_pt.y() - pole_snap_tolerance,
                            pole_pt.x() + pole_snap_tolerance,
                            pole_pt.y() + pole_snap_tolerance
                        )
                        nearby_spans = dist_span_index.intersects(pole_bbox)
                        # If pole is near ANY Distribution span, include it
                        for span_id in nearby_spans:
                            span_geom = dist_span_geoms.get(span_id)
                            if span_geom and not span_geom.isEmpty():
                                pole_geom = QgsGeometry.fromPointXY(pole_pt)
                                dist = pole_geom.distance(span_geom)
                                if dist <= pole_snap_tolerance:
                                    distribution_pole_ids.add(pf.id())
                                    break
                    
                    self.log_message(f"Filtered poles: {len(distribution_pole_ids)} of {poles_layer.featureCount()} poles are on Distribution spans")
                else:
                    # No Cable Type field - use all poles
                    distribution_pole_ids = {pf.id() for pf in poles_layer.getFeatures()}
                
                # Build index only for Distribution poles
                if distribution_pole_ids:
                    pole_index = QgsSpatialIndex()
                    for pf in poles_layer.getFeatures():
                        if pf.id() in distribution_pole_ids:
                            pole_index.insertFeature(pf)
                            pole_coords[pf.id()] = pf.geometry().asPoint()
                    self.log_message(f"Snapping splitters to nearest Distribution pole ('{poles_layer.name()}')")
                else:
                    self.log_message("No poles on Distribution spans — snapping splitters to span line directly")
            else:
                self.log_message("No poles layer found — snapping splitters to nearest span line point")

            # Group features by group_id (skip ungrouped features where group_id is None)
            features_by_group = {}
            _ungrouped_sp = 0
            for feat in grouped_layer.getFeatures():
                group_id = feat[group_field]
                if group_id is None:
                    _ungrouped_sp += 1
                    continue
                if group_id not in features_by_group:
                    features_by_group[group_id] = []
                features_by_group[group_id].append(feat)
            if _ungrouped_sp:
                self.log_message(f"Skipping {_ungrouped_sp} ungrouped feature(s) (no group_id)")
            self.log_message(f"Groups found: {len(features_by_group)} (group IDs: {sorted(list(features_by_group.keys()))[:10]})")

            # BUGFIX: Guard against empty group dict — means step 1 produced no valid groups
            if not features_by_group:
                self.log_message("⛔ ERROR: No groups with valid group_id found in grouped layer.")
                self.log_message(f"   Layer: '{grouped_layer.name()}' has {grouped_layer.featureCount()} features but all have NULL group_id.")
                self.log_message("   This usually means step 1 (Group PON) failed or used the wrong layer.")
                self.log_message("   Re-draw the polygon selection and try again.")
                return

            # ----------------------------------------------------------------
            # Build spatial index of span geometries ONCE (fast per-group lookup)
            # ----------------------------------------------------------------
            from qgis.core import QgsSpatialIndex as _QSI2, QgsRectangle as _QRect2
            _snap_geoms = {}   # fid -> QgsGeometry
            _snap_index = _QSI2()
            _snap_count = 0
            for _sf in span_layer.getFeatures():
                if has_cable_type:
                    _ct = str(_sf['Cable Type'] or '').strip().lower()
                    if _ct != 'distribution':
                        continue
                _sg = _sf.geometry()
                if _sg and not _sg.isEmpty():
                    _snap_geoms[_sf.id()] = _sg
                    _snap_index.addFeature(_sf)
                    _snap_count += 1
            if _snap_count == 0 and has_cable_type:
                self.log_message("⚠ No Distribution spans indexed — falling back to all spans")
                for _sf in span_layer.getFeatures():
                    _sg = _sf.geometry()
                    if _sg and not _sg.isEmpty():
                        _snap_geoms[_sf.id()] = _sg
                        _snap_index.addFeature(_sf)
                        _snap_count += 1
            self.log_message(f"Span snap index: {_snap_count} feature(s) indexed")

            # Search radius for nearest-span lookup (expand if needed)
            _SNAP_RADIUS = 500.0

            # Create splitter point for each group
            splitter_features = []
            total_groups_sp = len(features_by_group)
            _groups_skipped_error = 0
            self.log_message(f"Processing {total_groups_sp} groups...")
            self._start_operation("Generating Splitter Points…")
            for sp_idx, (group_id, group_features) in enumerate(features_by_group.items()):
                self._progress(sp_idx + 1, total_groups_sp, 'Splitters')
                if self._cancel_check():
                    self.log_message("⛔ Splitter generation cancelled.")
                    return
                if not group_features:
                    continue

                try:
                    # Calculate centroid of all features in group
                    all_points = []
                    for feat in group_features:
                        geom = feat.geometry()
                        if geom:
                            centroid = geom.centroid().asPoint()
                            all_points.append(centroid)

                    if not all_points:
                        continue

                    avg_x = sum(pt.x() for pt in all_points) / len(all_points)
                    avg_y = sum(pt.y() for pt in all_points) / len(all_points)
                    group_centroid = QgsPointXY(avg_x, avg_y)

                    # --- Fast snap: use spatial index, expand search until hit found ---
                    best_dist_point = None
                    min_distance = float('inf')
                    radius = _SNAP_RADIUS
                    for _ in range(4):   # up to 4 doublings (~4000 m max)
                        bbox = _QRect2(
                            group_centroid.x() - radius, group_centroid.y() - radius,
                            group_centroid.x() + radius, group_centroid.y() + radius,
                        )
                        candidates = _snap_index.intersects(bbox)
                        for fid in candidates:
                            _sg = _snap_geoms[fid]
                            nearest = _sg.nearestPoint(QgsGeometry.fromPointXY(group_centroid))
                            if nearest.isEmpty():
                                continue
                            np_pt = nearest.asPoint()
                            d = math.sqrt(
                                (group_centroid.x() - np_pt.x()) ** 2 +
                                (group_centroid.y() - np_pt.y()) ** 2
                            )
                            if d < min_distance:
                                min_distance = d
                                best_dist_point = np_pt
                        if best_dist_point is not None:
                            break
                        radius *= 2  # expand and retry

                    if best_dist_point is None:
                        self.log_message(f"   ⚠ Group {group_id}: No span found within {radius:.0f} m — splitter skipped")
                        continue

                    # Optional pole snap: prefer nearest Distribution pole if within 10 m of span snap
                    nearest_point = best_dist_point
                    if pole_index and pole_coords:
                        _pole_cands = pole_index.nearestNeighbor(
                            QgsPointXY(best_dist_point.x(), best_dist_point.y()), 1)
                        if _pole_cands:
                            _pp = pole_coords[_pole_cands[0]]
                            _pd = math.sqrt(
                                (_pp.x() - best_dist_point.x()) ** 2 +
                                (_pp.y() - best_dist_point.y()) ** 2
                            )
                            if _pd <= 10.0:
                                nearest_point = _pp

                    # Create splitter point feature
                    splitter_feat = QgsFeature(splitter_layer.fields())
                    splitter_feat.setGeometry(QgsGeometry.fromPointXY(nearest_point))

                    drop_count = len(group_features)
                    zone_val = group_features[0][zone_field_src] if zone_field_src else None
                    zone_int = int(zone_val) if zone_val is not None else -1
                    splitter_feat.setAttributes([
                        int(group_id),  # fid
                        str(group_id),  # ID
                        int(group_id),  # group_id
                        zone_int,       # zone_id
                        drop_count,     # drop_count
                    ])
                    splitter_features.append(splitter_feat)

                except Exception as _grp_err:
                    _groups_skipped_error += 1
                    self.log_message(f"   ⚠ Group {group_id}: Exception — {_grp_err} (skipping this group, continuing)")

            if _groups_skipped_error:
                self.log_message(f"⚠ {_groups_skipped_error} group(s) skipped due to errors (see above)")
            if not splitter_features:
                self.log_message("⛔ ERROR: No splitter points generated for this batch — "
                                 "check span layer has Distribution features near demand points.")
                return
            
            # Add features to layer
            provider.addFeatures(splitter_features)
            splitter_layer.updateExtents()
            
            # Apply symbology - green circles
            symbol = QgsMarkerSymbol.createSimple({
                'name': 'circle',
                'color': '0,255,0',
                'outline_color': 'black',
                'outline_width': '0.5',
                'size': '4'
            })
            renderer = QgsSingleSymbolRenderer(symbol)
            splitter_layer.setRenderer(renderer)
            
            # Add labels showing drop count
            from qgis.core import QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings, QgsVectorLayerSimpleLabeling
            from qgis.PyQt.QtGui import QFont, QColor
            
            label_settings = QgsPalLayerSettings()
            # Label: "Grp <group_id> | Zone <zone_id> [<drop_count>]"
            if zone_field_src:
                label_settings.fieldName = (
                    '\'Grp \' || "group_id" || \' | Z\' || "zone_id" || \' [\' || "drop_count" || \']\''
                )
                label_settings.isExpression = True
            else:
                label_settings.fieldName = '\'Grp \' || "group_id" || \' [\' || "drop_count" || \']\''
                label_settings.isExpression = True
            label_settings.enabled = True
            label_settings.placement = QgsPalLayerSettings.AroundPoint
            
            text_format = QgsTextFormat()
            text_format.setFont(QFont('Arial', 8))
            text_format.setSize(8)
            text_format.setColor(QColor('black'))
            
            buffer_settings = QgsTextBufferSettings()
            buffer_settings.setEnabled(True)
            buffer_settings.setSize(1.0)
            buffer_settings.setColor(QColor('white'))
            text_format.setBuffer(buffer_settings)
            
            label_settings.setFormat(text_format)
            
            labeling = QgsVectorLayerSimpleLabeling(label_settings)
            splitter_layer.setLabeling(labeling)
            splitter_layer.setLabelsEnabled(True)
            
            # Add layer to project
            splitter_layer = self._add_output_layer(splitter_layer)
            
            # Store reference for drop cable generation
            self.splitter_points_layer = splitter_layer
            
            # Calculate statistics
            total_drops = sum(f['drop_count'] for f in splitter_features)
            max_drops = max((f['drop_count'] for f in splitter_features), default=0)
            min_drops = min((f['drop_count'] for f in splitter_features), default=0)
            
            self.log_message(f"\nCreated {len(splitter_features)} splitter points")
            self._elapsed("Total time")
            self.log_message(f"  Total demand points: {total_drops}")
            self.log_message(f"  Max drops per splitter: {max_drops}")
            self.log_message(f"  Min drops per splitter: {min_drops}")
            self.log_message(f"Layer: '{splitter_layer.name()}'")
            if zone_field_src:
                self.log_message(f"Zone membership sourced from field '{zone_field_src}'")
                self.log_message("Label shows: Zone ID [drop count]")
            else:
                self.log_message("No zone field found — zone_id set to -1; label shows drop count only")
            self.log_message("Splitters placed on span line for each group")
            
        except Exception as e:
            self.log_message(f"ERROR generating splitters: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def _build_road_crossing_checker(self, demand_crs=None):
        """Return a callable _crosses_road(x1,y1,x2,y2)->bool using the current road layer.

        Returns a no-op function (always False) if no road layer is selected.
        Handles CRS mismatch between demand layer and road layer.
        """
        from qgis.core import QgsGeometry, QgsPointXY, QgsProject
        road_layer = self.comboBox_road_layer.currentLayer() if hasattr(self, 'comboBox_road_layer') else None
        if road_layer is None:
            return lambda x1, y1, x2, y2: False

        road_geom_by_id = {}
        road_index = QgsSpatialIndex()
        _road_transform = None
        try:
            road_crs = road_layer.crs()
            if demand_crs is not None and demand_crs.isValid() and road_crs.isValid() and demand_crs != road_crs:
                _road_transform = QgsCoordinateTransform(demand_crs, road_crs, QgsProject.instance())
            for rf in road_layer.getFeatures():
                rg = rf.geometry()
                if rg and not rg.isEmpty():
                    road_geom_by_id[rf.id()] = rg
                    road_index.addFeature(rf)
        except Exception:
            return lambda x1, y1, x2, y2: False

        def _crosses_road(x1, y1, x2, y2):
            if not road_geom_by_id:
                return False
            if _road_transform is not None:
                try:
                    p1 = _road_transform.transform(QgsPointXY(x1, y1))
                    p2 = _road_transform.transform(QgsPointXY(x2, y2))
                except Exception:
                    p1, p2 = QgsPointXY(x1, y1), QgsPointXY(x2, y2)
            else:
                p1, p2 = QgsPointXY(x1, y1), QgsPointXY(x2, y2)
            line = QgsGeometry.fromPolylineXY([p1, p2])
            bbox = line.boundingBox()
            bbox.grow(max(abs(p2.x() - p1.x()), abs(p2.y() - p1.y())) * 0.05 + 1e-9)
            for fid in road_index.intersects(bbox):
                rg = road_geom_by_id.get(fid)
                if rg and line.intersects(rg) and not line.touches(rg):
                    return True
            return False

        return _crosses_road

    def on_generate_drop_lashed_clicked(self):
        """Generate drop cables that follow the span network for drops >50 m (aerial lashed)."""
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject,
                               QgsField, QgsPointXY,
                               QgsUnitTypes,
                               QgsRuleBasedRenderer)
        from qgis.PyQt.QtCore import QMetaType
        import math
        
        # Try to use stored layer references first, then search if needed
        demand_points_layer = None
        splitter_points_layer = None
        
        # Check if stored references are valid
        try:
            if self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                demand_points_layer = self.demand_points_layer
                self.log_message(f"Using stored demand points layer: '{demand_points_layer.name()}'")
        except:
            pass
        
        try:
            if self.splitter_points_layer and not sip.isdeleted(self.splitter_points_layer):
                splitter_points_layer = self.splitter_points_layer
                self.log_message(f"Using stored splitter points layer: '{splitter_points_layer.name()}'")
        except:
            pass
        
        # Find demand points layer if not stored — prefer point geometry over polygon
        if not demand_points_layer:
            _dm_candidates = []
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    layer_name = layer.name().lower()
                    if 'demand points' in layer_name or 'demand_points' in layer_name:
                        _dm_candidates.append(layer)
            # Prefer point (geometryType 0) layers; fall back to first match
            _pt_layers = [l for l in _dm_candidates if l.geometryType() == 0]
            if _pt_layers:
                demand_points_layer = _pt_layers[0]
            elif _dm_candidates:
                demand_points_layer = _dm_candidates[0]
            if demand_points_layer:
                self.log_message(f"Found demand points layer: '{demand_points_layer.name()}'")

        if not demand_points_layer:
            self.log_message("ERROR: Could not find demand points layer.")
            self.log_message("Please generate demand points first.")
            return
        
        # Find splitter points layer if not stored
        if not splitter_points_layer:
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    layer_name = layer.name().lower()
                    if 'splitter' in layer_name and layer.geometryType() == 0:  # Point layer
                        splitter_points_layer = layer
                        self.log_message(f"Found splitter points layer: '{splitter_points_layer.name()}'")
                        break
        
        if not splitter_points_layer:
            self.log_message("ERROR: Could not find splitter points layer.")
            self.log_message("Please generate splitter points first.")
            return
        
        self.log_message("\n=== Generating Drop Cables Lashed ===")
        self.log_message(f"Demand points: '{demand_points_layer.name()}'")
        self.log_message(f"Splitters: '{splitter_points_layer.name()}'")
        
        try:
            crs = demand_points_layer.crs().authid()
            
            # Build layer name — batch-specific to preserve previous PON-per-PON runs
            _lashed_layer_name = "Drop Cables Lashed"
            if getattr(self, '_current_batch_label', None):
                _lashed_layer_name = f"Drop Cables Lashed - {self._current_batch_label}"

            # Remove existing layer of the SAME name only (don't touch other batches)
            for layer in list(QgsProject.instance().mapLayers().values()):
                if isinstance(layer, QgsVectorLayer) and layer.name() == _lashed_layer_name:
                    self.log_message(f"Updating existing {_lashed_layer_name} layer...")
                    QgsProject.instance().removeMapLayer(layer.id())
                    break

            # Create drop cables layer
            drop_cable_layer = QgsVectorLayer(f"LineString?crs={crs}",
                                             _lashed_layer_name,
                                             "memory")
            provider = drop_cable_layer.dataProvider()
            
            # Add fields - including fiber count from cable profile system
            provider.addAttributes([
                QgsField('cable_id', QMetaType.Type.Int),
                QgsField('group_id', QMetaType.Type.Int),
                QgsField('demand_id', QMetaType.Type.Int),
                QgsField('fiber_count', QMetaType.Type.Int),
                QgsField('fiber_size', QMetaType.Type.QString),
                QgsField('via_span', QMetaType.Type.Int),      # 1 = routed via span; 0 = direct
                QgsField('cable_length', QMetaType.Type.Double),   # Cartesian length in CRS units
                QgsField('zone_id', QMetaType.Type.Int),      # aggregation zone membership
            ])
            drop_cable_layer.updateFields()
            
            # Add virtual field for length using $length expression
            from qgis.core import QgsField
            length_field = QgsField('length', QMetaType.Type.Double)
            length_field.setLength(10)
            length_field.setPrecision(2)
            drop_cable_layer.addExpressionField('$length', length_field)
            
            # Drop cables typically use smallest profile (1-2 fibers per customer)
            drop_fiber_count = get_cable_profile(1, PROFILE_TYPE_DEFAULT)  # 2F minimum
            drop_fiber_size = format_cable_profile(drop_fiber_count)
            self.log_message(f"Drop cable profile: {drop_fiber_size} (1 fiber per customer + spare)")
            
            # Get splitters indexed by group_id; also build zone lookup (group_id -> zone_id)
            splitters_by_group = {}
            zone_by_group = {}
            _sp_has_zone = 'zone_id' in [f.name() for f in splitter_points_layer.fields()]
            for _sp in splitter_points_layer.getFeatures():
                _sgid = _sp['group_id']
                _sgeom = _sp.geometry()
                if _sgeom and not _sgeom.isEmpty():
                    splitters_by_group[_sgid] = _sgeom.asPoint()
                if _sp_has_zone and _sgid is not None:
                    _zv = _sp['zone_id']
                    zone_by_group[_sgid] = int(_zv) if _zv is not None else -1

            self.log_message(f"Found {len(splitters_by_group)} splitter groups: {sorted(splitters_by_group.keys())}")

            # ---- Via-span routing setup ----------------------------------------
            # Drop cables longer than VIA_SPAN_THRESHOLD are routed to the nearest
            # point on the span line first, then onward to the splitter.
            # For PON-per-PON use the full span layer so routing covers the whole network
            _full_span_l = getattr(self, '_pon_full_span_layer', None)
            if _full_span_l is not None:
                try:
                    import sip as _sip_fl
                    if _sip_fl.isdeleted(_full_span_l):
                        _full_span_l = None
                except Exception:
                    _full_span_l = None
            span_layer = _full_span_l or self.comboBox_span_layer.currentLayer()
            span_feats = {}
            span_index = None
            crs_units = demand_points_layer.crs().mapUnits()
            is_geographic = (crs_units == QgsUnitTypes.DistanceUnit.DistanceDegrees)
            VIA_SPAN_THRESHOLD = 0.00045 if is_geographic else 50.0  # ~50 m
            if span_layer:
                span_feats = {f.id(): f for f in span_layer.getFeatures()}
                span_index = QgsSpatialIndex(span_layer.getFeatures())
                self.log_message(
                    f"Span layer: '{span_layer.name()}' ({len(span_feats)} segments)"
                    f" — cables >{VIA_SPAN_THRESHOLD:.0f} map units will follow span network")
            else:
                self.log_message("No span layer selected — all drop cables will be direct")

            # Build routing graph and pre-compute splitter snap points
            span_graph = None
            seg_ep = {}
            splitter_snaps = {}  # group_id -> (snap_pt, snap_fid)
            if span_feats:
                span_graph, seg_ep = _build_span_routing_graph(span_feats)
                self.log_message(
                    f"Routing graph: {span_graph.number_of_nodes()} nodes, "
                    f"{span_graph.number_of_edges()} edges")
                for _gid, _spt in splitters_by_group.items():
                    _nearest = span_index.nearestNeighbor(_spt, 5)
                    _best_snap, _best_fid, _best_d = None, None, float('inf')
                    for _fid in _nearest:
                        _sg = span_feats[_fid].geometry()
                        _near = _sg.nearestPoint(QgsGeometry.fromPointXY(_spt))
                        if _near.isEmpty():
                            continue
                        _np = _near.asPoint()
                        _d = math.sqrt((_spt.x() - _np.x()) ** 2 + (_spt.y() - _np.y()) ** 2)
                        if _d < _best_d:
                            _best_d = _d
                            _best_snap = QgsPointXY(_np.x(), _np.y())
                            _best_fid = _fid
                    splitter_snaps[_gid] = (_best_snap, _best_fid)
            # -------------------------------------------------------------------

            # Check what fields exist in demand points
            demand_fields = [f.name() for f in demand_points_layer.fields()]
            self.log_message(f"Demand points fields: {demand_fields}")

            # Road crossing check — skip drops whose direct demand→splitter line crosses a road
            _crosses_road_lashed = self._build_road_crossing_checker(demand_points_layer.crs())
            _road_lyr = self.comboBox_road_layer.currentLayer() if hasattr(self, 'comboBox_road_layer') else None
            if _road_lyr:
                self.log_message(f"Road barrier active: '{_road_lyr.name()}' — drops crossing roads will be skipped")

            # Create drop cable for each demand point to its group's splitter
            cable_features = []
            cable_id = 1
            skipped_no_group = 0
            skipped_no_splitter = 0
            skipped_road_cross = 0
            groups_found = set()
            connections_by_group = {}
            total_demand = demand_points_layer.featureCount()
            self.log_message(f"Connecting {total_demand} demand points to splitters...")
            self._start_operation("Generating Drop Cables Lashed…")
            for dc_idx, demand_point in enumerate(demand_points_layer.getFeatures()):
                self._progress(dc_idx + 1, total_demand, 'Drop cables')
                if self._cancel_check():
                    self.log_message("⛔ Drop cables (lashed) generation cancelled.")
                    return
                demand_geom = demand_point.geometry()
                if not demand_geom or demand_geom.isEmpty():
                    continue
                # Use centroid for polygon/line layers so non-point sources work correctly
                if demand_geom.type() == 0:  # Point
                    demand_pt = demand_geom.asPoint()
                else:
                    demand_pt = demand_geom.centroid().asPoint()
                
                # Find group_id field (could be group_8, group_16, group_128, or group_100)
                group_id = None
                group_field_used = None
                for field_name in ['group_8', 'group_16', 'group_128', 'group_100', 'batch_id']:
                    if field_name in demand_fields:
                        group_id = demand_point[field_name]
                        group_field_used = field_name
                        if group_id is not None:
                            groups_found.add(group_id)
                        break
                
                if group_id is None:
                    skipped_no_group += 1
                    continue
                
                # Get splitter for this group (each demand point connects to splitter with matching group_id)
                if group_id not in splitters_by_group:
                    skipped_no_splitter += 1
                    continue
                
                splitter_pt = splitters_by_group[group_id]

                # Straight-line distance from demand point to splitter
                direct_dist = math.sqrt(
                    (demand_pt.x() - splitter_pt.x()) ** 2 +
                    (demand_pt.y() - splitter_pt.y()) ** 2
                )

                # Via-span routing: cables beyond threshold follow the span network
                # path: demand_pt → snap_on_span → [span] → snap_on_span → splitter_pt
                via_span_used = 0
                if span_index and span_feats and direct_dist > VIA_SPAN_THRESHOLD:
                    # Find nearest point on span for this demand point
                    snap_d, snap_d_fid, min_snap_d = None, None, float('inf')
                    for fid in span_index.nearestNeighbor(demand_pt, 5):
                        sg = span_feats[fid].geometry()
                        if not sg or sg.isEmpty():
                            continue
                        near_geom = sg.nearestPoint(QgsGeometry.fromPointXY(demand_pt))
                        if near_geom.isEmpty():
                            continue
                        np_pt = near_geom.asPoint()
                        d = math.sqrt((demand_pt.x() - np_pt.x()) ** 2 +
                                      (demand_pt.y() - np_pt.y()) ** 2)
                        if d < min_snap_d:
                            min_snap_d = d
                            snap_d = QgsPointXY(np_pt.x(), np_pt.y())
                            snap_d_fid = fid

                    snap_s, snap_s_fid = splitter_snaps.get(group_id, (None, None))

                    if snap_d and snap_s and span_graph:
                        span_pts = _span_route_pts(
                            snap_d, snap_d_fid, snap_s, snap_s_fid, span_graph, seg_ep)
                        if span_pts:
                            line_geom = QgsGeometry.fromPolylineXY(
                                [demand_pt] + span_pts + [splitter_pt])
                            via_span_used = 1
                        else:
                            # No graph path — fall back to simple 3-point line
                            line_geom = QgsGeometry.fromPolylineXY(
                                [demand_pt, snap_d, snap_s, splitter_pt])
                            via_span_used = 1
                    elif snap_d:
                        line_geom = QgsGeometry.fromPolylineXY(
                            [demand_pt, snap_d, splitter_pt])
                        via_span_used = 1
                    else:
                        line_geom = QgsGeometry.fromPolylineXY([demand_pt, splitter_pt])
                else:
                    line_geom = QgsGeometry.fromPolylineXY([demand_pt, splitter_pt])

                # Create feature (length auto-calculated by virtual field)
                # Skip drop if the direct demand→splitter line crosses a road
                if _crosses_road_lashed(demand_pt.x(), demand_pt.y(),
                                        splitter_pt.x(), splitter_pt.y()):
                    skipped_road_cross += 1
                    continue

                cable_feat = QgsFeature(drop_cable_layer.fields())
                cable_feat.setGeometry(line_geom)
                cable_feat.setAttributes([
                    cable_id,
                    int(group_id),
                    int(demand_point.id()),
                    drop_fiber_count,
                    drop_fiber_size,
                    via_span_used,
                    line_geom.length(),  # Cartesian CRS units — used by renderer
                    zone_by_group.get(int(group_id), -1),  # zone_id
                ])
                
                cable_features.append(cable_feat)
                
                # Track connections per group
                if group_id not in connections_by_group:
                    connections_by_group[group_id] = 0
                connections_by_group[group_id] += 1
                
                cable_id += 1
            
            self.log_message(f"Demand point groups found: {sorted(groups_found)}")
            self.log_message(f"Connections per group: {dict(sorted(connections_by_group.items()))}")
            if skipped_no_group > 0:
                self.log_message(f"Warning: {skipped_no_group} demand points had no group_id field")
            if skipped_no_splitter > 0:
                self.log_message(f"Warning: {skipped_no_splitter} demand points had no matching splitter")
                self.log_message(f"  Splitter groups: {sorted(splitters_by_group.keys())}")
                self.log_message(f"  Demand groups:   {sorted(groups_found)}")
            if skipped_road_cross > 0:
                self.log_message(f"🚫 Road barrier: {skipped_road_cross} drop(s) crossed a road — skipped")
            
            if len(cable_features) == 0:
                self.log_message("ERROR: No drop cables were created!")
                self.log_message("Please check that:")
                self.log_message("  1. Demand points have group_8, group_16, group_128, or group_100 field")
                self.log_message("  2. Splitters have matching group_id values")
                return
            
            # Add features to layer
            provider.addFeatures(cable_features)
            drop_cable_layer.updateExtents()
            
            # Apply rule-based symbology using stored cable_length field:
            #   cable_length > VIA_SPAN_THRESHOLD  → neon orange solid (warning)
            #   cable_length <= VIA_SPAN_THRESHOLD → red dashed (normal)
            # Use cookbook-style construction: renderer from default sym, then replace rules
            renderer = QgsRuleBasedRenderer(
                QgsLineSymbol.createSimple({'color': '220,0,0', 'width': '0.5', 'line_style': 'dash'}))
            root_rule = renderer.rootRule()
            for _r in root_rule.children()[:]:
                root_rule.removeChild(_r)
            rule_warn = QgsRuleBasedRenderer.Rule(
                QgsLineSymbol.createSimple({'color': '255,140,0', 'width': '0.8', 'line_style': 'solid'}))
            rule_warn.setFilterExpression(f'"cable_length" > {VIA_SPAN_THRESHOLD}')
            rule_warn.setLabel('Drop >50 m (WARNING)')
            root_rule.appendChild(rule_warn)
            rule_normal = QgsRuleBasedRenderer.Rule(
                QgsLineSymbol.createSimple({'color': '220,0,0', 'width': '0.5', 'line_style': 'dash'}))
            rule_normal.setFilterExpression(f'"cable_length" <= {VIA_SPAN_THRESHOLD}')
            rule_normal.setLabel('Drop ≤50 m')
            root_rule.appendChild(rule_normal)
            drop_cable_layer.setRenderer(renderer)
            
            # Add layer to project
            drop_cable_layer = self._add_output_layer(drop_cable_layer)
            
            # Calculate total length from the added features (virtual field will be populated)
            total_length = 0
            over_warn = 0
            for feat in drop_cable_layer.getFeatures():
                fl = feat['length'] if feat['length'] else 0
                total_length += fl
                if fl > VIA_SPAN_THRESHOLD:
                    over_warn += 1
            
            avg_length = total_length / len(cable_features) if len(cable_features) > 0 else 0
            
            via_span_count = sum(
                1 for f in drop_cable_layer.getFeatures() if f['via_span'] == 1)
            direct_count = len(cable_features) - via_span_count

            self.log_message(f"\nCreated {len(cable_features)} drop cables")
            self._elapsed("Total time")
            self.log_message(f"Layer: '{drop_cable_layer.name()}'")
            self.log_message(f"Total cable length: {total_length:.2f} units")
            self.log_message(f"Average cable length: {avg_length:.2f} units")
            self.log_message(
                f"Direct (≤{VIA_SPAN_THRESHOLD:.0f} mu): {direct_count}  "
                f"Via-span (>{VIA_SPAN_THRESHOLD:.0f} mu): {via_span_count}")
            if over_warn > 0:
                self.log_message(
                    f"WARNING: {over_warn} cable(s) exceed {VIA_SPAN_THRESHOLD:.0f} m "
                    f"— shown in neon orange on map")
            self.log_message("Length field uses $length expression (auto-updates with geometry)")
            
        except Exception as e:
            self.log_message(f"ERROR generating drop cables: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_generate_drop_ptp_clicked(self, silent=False, demand_layer=None,
                                     splitter_layer=None, drop_layer=None):
        """Generate straight-line (point-to-point) drop cables from each demand point directly to its splitter.

        Args:
            silent: If True, suppress the main dock progress bar (used when called from Manual Override).
            demand_layer / splitter_layer / drop_layer: when supplied (e.g. from the
                Manual Override dialog), regenerate against THESE exact layers instead
                of re-resolving via accumulators / name-search. This guarantees that
                EVERY edit operation (reassign demand, move/delete splitter, add/delete
                demand point, the Regenerate-Drops button, …) rebuilds drops on the same
                layers the dialog is editing — no silent layer mismatch. When None, fall
                back to the accumulator → single-run-ref → name-search resolution.
        """
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject,
                               QgsField, QgsUnitTypes)
        from qgis.PyQt.QtCore import QMetaType

        # During a PON per PON batch run, use the batch-specific layers (set by pipeline steps).
        # Only use accumulators when called from Manual Override (regen after edit).
        _in_batch = bool(getattr(self, '_current_batch_label', None))

        def _alive(_lyr):
            if _lyr is None:
                return False
            try:
                return not sip.isdeleted(_lyr)
            except Exception:
                return True

        # Locate demand points layer — an explicit layer passed by the caller
        # (Manual Override) always wins over re-resolution.
        demand_points_layer = demand_layer if _alive(demand_layer) else None
        if not demand_points_layer and not _in_batch:
            try:
                _accum_grp = getattr(self, '_pon_accum_groups', None)
                if _accum_grp and not sip.isdeleted(_accum_grp) and _accum_grp.featureCount() > 0:
                    demand_points_layer = _accum_grp
            except Exception:
                pass
        try:
            if not demand_points_layer and self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                demand_points_layer = self.demand_points_layer
        except:
            pass
        if not demand_points_layer:
            _dm_candidates = []
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    ln = layer.name().lower()
                    if 'demand points' in ln or 'demand_points' in ln:
                        _dm_candidates.append(layer)
            # Prefer point geometry layers; fall back to first match
            _pt_layers = [l for l in _dm_candidates if l.geometryType() == 0]
            if _pt_layers:
                demand_points_layer = _pt_layers[0]
            elif _dm_candidates:
                demand_points_layer = _dm_candidates[0]
        if not demand_points_layer:
            self.log_message("ERROR: Could not find demand points layer. Generate demand points first.")
            return

        # Locate splitter points layer — explicit caller layer wins.
        splitter_points_layer = splitter_layer if _alive(splitter_layer) else None
        if not splitter_points_layer and not _in_batch:
            try:
                _accum_sp = getattr(self, '_pon_accum_splitters', None)
                if _accum_sp and not sip.isdeleted(_accum_sp) and _accum_sp.featureCount() > 0:
                    splitter_points_layer = _accum_sp
            except Exception:
                pass
        try:
            if not splitter_points_layer and self.splitter_points_layer and not sip.isdeleted(self.splitter_points_layer):
                splitter_points_layer = self.splitter_points_layer
        except:
            pass
        if not splitter_points_layer:
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    if 'splitter' in layer.name().lower() and layer.geometryType() == 0:
                        splitter_points_layer = layer
                        break
        if not splitter_points_layer:
            self.log_message("ERROR: Could not find splitter points layer. Generate splitter points first.")
            return

        self.log_message("\n=== Generating Drop Cables PTP ===")
        self.log_message(f"Demand points: '{demand_points_layer.name()}'")
        self.log_message(f"Splitters:     '{splitter_points_layer.name()}'")

        try:
            crs = demand_points_layer.crs().authid()

            # Use the PON Drop Cables accumulator only when called from Manual Override
            # (i.e. regen after edit) — NOT during a PON per PON batch run, because the
            # batch layer must be created fresh so the merge step can append it correctly.
            _in_pon_batch = bool(getattr(self, '_current_batch_label', None))
            # An explicit drop_layer from the caller (Manual Override) is the target
            # to regenerate into; otherwise use the PON drops accumulator.
            _accum_drops = drop_layer if _alive(drop_layer) else getattr(self, '_pon_accum_drops', None)
            _use_accum = False
            if not _in_pon_batch:
                try:
                    if _accum_drops and not sip.isdeleted(_accum_drops):
                        _use_accum = True
                except Exception:
                    pass

            if _use_accum:
                drop_ptp_layer = _accum_drops
                provider = drop_ptp_layer.dataProvider()
                # Do NOT wipe existing drops yet. The old behaviour cleared the
                # accumulator here, then returned early when the rebuild produced
                # zero cables (e.g. a transient group/splitter mismatch after a
                # demand reassignment, or a mid-rebuild exception) — which silently
                # deleted EVERY drop cable on the whole project. Defer the wipe
                # until we know the rebuild succeeded, so a zero-result regen is a
                # no-op instead of data loss.
                _existing_ids = list(drop_ptp_layer.allFeatureIds())
                # For accumulator use a plain QgsFields from the provider (no virtual fields)
                _accum_fields = provider.fields()
                self.log_message(f"  [Regen] Accumulator '{drop_ptp_layer.name()}': {len(_existing_ids)} existing features (wipe deferred until rebuild succeeds), fields: {[f.name() for f in _accum_fields]}")
            else:
                # Build layer name — batch-specific to preserve previous PON-per-PON runs
                _ptp_layer_name = "Drop Cables PTP"
                if getattr(self, '_current_batch_label', None):
                    _ptp_layer_name = f"Drop Cables PTP - {self._current_batch_label}"

                # Removal of the existing same-name layer is deferred until after
                # we confirm the rebuild produced features (see below) — so a
                # zero-result regen leaves the existing drop layer intact instead
                # of wiping it.
                # Create layer
                drop_ptp_layer = QgsVectorLayer(f"LineString?crs={crs}", _ptp_layer_name, "memory")
                provider = drop_ptp_layer.dataProvider()
                provider.addAttributes([
                    QgsField('cable_id', QMetaType.Type.Int),
                    QgsField('group_id', QMetaType.Type.Int),
                    QgsField('demand_id', QMetaType.Type.Int),
                    QgsField('fiber_count', QMetaType.Type.Int),
                    QgsField('fiber_size', QMetaType.Type.QString),
                    QgsField('via_span', QMetaType.Type.Int),      # always 0 for PTP
                    QgsField('cable_length', QMetaType.Type.Double),   # Cartesian CRS-unit length
                    QgsField('zone_id', QMetaType.Type.Int),      # aggregation zone membership
                ])
                drop_ptp_layer.updateFields()

                # Virtual length field
                vf = QgsField('length', QMetaType.Type.Double)
                vf.setLength(10)
                vf.setPrecision(2)
                drop_ptp_layer.addExpressionField('$length', vf)
                # For non-accum path, use layer fields (which includes virtual 'length')
                # but we set attributes by name so it's safe
                _accum_fields = drop_ptp_layer.dataProvider().fields()

            drop_fiber_count = get_cable_profile(1, PROFILE_TYPE_DEFAULT)
            drop_fiber_size = format_cable_profile(drop_fiber_count)
            self.log_message(f"Drop cable profile: {drop_fiber_size}")

            # Index splitters by group_id; also build zone lookup (group_id -> zone_id)
            # Normalise ALL keys to int to avoid type-mismatch misses (QVariant vs int)
            splitters_by_group = {}
            zone_by_group = {}
            _ptp_sp_has_zone = 'zone_id' in [f.name() for f in splitter_points_layer.fields()]
            for sp in splitter_points_layer.getFeatures():
                gid = sp['group_id']
                if gid is None:
                    continue
                try:
                    gid = int(gid)
                except (TypeError, ValueError):
                    continue
                sg = sp.geometry()
                if sg and not sg.isEmpty():
                    splitters_by_group[gid] = sg.asPoint()
                if _ptp_sp_has_zone:
                    _zv = sp['zone_id']
                    zone_by_group[gid] = int(_zv) if _zv is not None else -1

            # Threshold for colour warning (same units logic as lashed)
            crs_units = demand_points_layer.crs().mapUnits()
            is_geographic = (crs_units == QgsUnitTypes.DistanceUnit.DistanceDegrees)
            PTP_WARN_THRESHOLD = 0.00045 if is_geographic else 50.0

            demand_fields = [f.name() for f in demand_points_layer.fields()]

            # Road crossing check — skip drops whose demand→splitter line crosses a road
            _crosses_road_ptp = self._build_road_crossing_checker(demand_points_layer.crs())
            _road_lyr_ptp = self.comboBox_road_layer.currentLayer() if hasattr(self, 'comboBox_road_layer') else None
            if _road_lyr_ptp:
                self.log_message(f"Road barrier active: '{_road_lyr_ptp.name()}' — drops crossing roads will be skipped")

            cable_features = []
            cable_id = 1
            skipped_no_group = 0
            skipped_no_splitter = 0
            skipped_road_cross = 0
            groups_found = set()
            connections_by_group = {}
            total_demand = demand_points_layer.featureCount()
            self.log_message(f"Connecting {total_demand} demand points (straight line)...")
            if not silent:
                self._start_operation("Generating Drop Cables PTP…")

            for idx, demand_point in enumerate(demand_points_layer.getFeatures()):
                if not silent:
                    self._progress(idx + 1, total_demand, 'PTP drops')
                if not silent and self._cancel_check():
                    self.log_message("⛔ Drop cables (PTP) generation cancelled.")
                    return
                dg = demand_point.geometry()
                if not dg or dg.isEmpty():
                    continue
                # Use centroid for polygon/line sources so non-point layers work correctly
                if dg.type() == 0:  # Point
                    demand_pt = dg.asPoint()
                else:
                    demand_pt = dg.centroid().asPoint()

                # Resolve group_id — normalise to int to match splitters_by_group keys
                group_id = None
                for fn in ['group_8', 'group_16', 'group_128', 'group_100', 'batch_id']:
                    if fn in demand_fields:
                        _raw = demand_point[fn]
                        if _raw is not None:
                            try:
                                group_id = int(_raw)
                            except (TypeError, ValueError):
                                group_id = None
                        break
                if group_id is None:
                    skipped_no_group += 1
                    continue
                if group_id not in splitters_by_group:
                    skipped_no_splitter += 1
                    continue

                splitter_pt = splitters_by_group[group_id]
                line_geom = QgsGeometry.fromPolylineXY([demand_pt, splitter_pt])

                # Skip drop if it crosses a road
                if _crosses_road_ptp(demand_pt.x(), demand_pt.y(),
                                     splitter_pt.x(), splitter_pt.y()):
                    skipped_road_cross += 1
                    continue

                feat = QgsFeature(_accum_fields if _use_accum else drop_ptp_layer.fields())
                feat.setGeometry(line_geom)
                # Build attribute list matching provider fields only (no virtual expression fields)
                _attr_map = {
                    'cable_id':    cable_id,
                    'group_id':    int(group_id),
                    'demand_id':   int(demand_point.id()),
                    'fiber_count': drop_fiber_count,
                    'fiber_size':  drop_fiber_size,
                    'via_span':    0,
                    'cable_length': line_geom.length(),
                    'zone_id':     zone_by_group.get(int(group_id), -1),
                }
                _flds = _accum_fields if _use_accum else drop_ptp_layer.fields()
                feat.setAttributes([_attr_map.get(f.name(), None) for f in _flds])
                cable_features.append(feat)
                connections_by_group[group_id] = connections_by_group.get(group_id, 0) + 1
                cable_id += 1

            if skipped_no_group:
                self.log_message(f"Warning: {skipped_no_group} demand points had no group_id field")
            if skipped_no_splitter:
                self.log_message(f"Warning: {skipped_no_splitter} demand points had no matching splitter")
            if skipped_road_cross:
                self.log_message(f"🚫 Road barrier: {skipped_road_cross} drop(s) crossed a road — skipped")

            if not cable_features:
                self.log_message(
                    "⚠ No PTP drop cables produced — group_id/splitter alignment "
                    "yielded zero matches. Existing drop cables were LEFT UNTOUCHED "
                    "(regen aborted, nothing deleted).")
                return

            # Write features to layer
            if _use_accum:
                # SAFE ORDERING — add the NEW drops first, confirm they actually
                # landed, and only THEN delete the OLD ones. The previous order
                # (delete-then-add) could wipe the whole layer if the add failed —
                # e.g. a read-only or schema-mismatched disk layer (GPKG/shapefile),
                # which is exactly how a saved drop-cable layer lost all its data.
                # If the write fails we roll back the partial insert and abort with
                # the existing drops untouched.
                _before = drop_ptp_layer.featureCount()
                _res = provider.addFeatures(cable_features)
                _ok  = _res[0] if isinstance(_res, tuple) else bool(_res)
                _added = _res[1] if (isinstance(_res, tuple) and len(_res) > 1) else []
                _after = drop_ptp_layer.featureCount()
                if not _ok or _after <= _before:
                    # Write failed — undo any partial insert, keep the old drops.
                    try:
                        if _added:
                            provider.deleteFeatures([f.id() for f in _added])
                    except Exception:
                        pass
                    self.log_message(
                        f"  ⚠ Drop write FAILED on '{drop_ptp_layer.name()}' "
                        "(layer not editable or schema mismatch). Existing drop "
                        "cables were LEFT INTACT — nothing was deleted.")
                    return
                # Write succeeded — now remove the OLD features (captured up-front).
                if _existing_ids:
                    provider.deleteFeatures(_existing_ids)
                drop_ptp_layer.updateExtents()
                self.log_message(f"  [Regen] wrote {len(cable_features)} drop cables → '{drop_ptp_layer.name()}' (total={drop_ptp_layer.featureCount()})")
            else:
                provider.addFeatures(cable_features)
            drop_ptp_layer.updateExtents()

            # Simple black renderer — no expressions, no crash risk
            drop_ptp_layer.setRenderer(
                QgsSingleSymbolRenderer(
                    QgsLineSymbol.createSimple({'color': '0,0,0', 'width': '0.4', 'line_style': 'solid'})
                )
            )

            if _use_accum:
                drop_ptp_layer.triggerRepaint()
            else:
                # Now that we have features, remove the previous same-name layer
                # (deferred from above) and add the freshly built one.
                for _old in list(QgsProject.instance().mapLayers().values()):
                    if isinstance(_old, QgsVectorLayer) and _old.name() == _ptp_layer_name:
                        QgsProject.instance().removeMapLayer(_old.id())
                        break
                drop_ptp_layer = self._add_output_layer(drop_ptp_layer)
            self.drop_ptp_layer = drop_ptp_layer

            self.log_message(f"\nCreated {len(cable_features)} PTP drop cables")
            if not silent:
                self._elapsed("Total time")
            self.log_message(f"Layer: '{drop_ptp_layer.name()}'")
            avg_length = sum(f['cable_length'] or 0 for f in cable_features) / len(cable_features) if cable_features else 0
            self.log_message(f"Average cable length: {avg_length:.2f} units")
            self.log_message(f"Connections per group: {dict(sorted(connections_by_group.items()))}")

        except Exception as e:
            self.log_message(f"ERROR generating PTP drop cables: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_manual_override_clicked(self):
        """Open Manual Override dialog — reassign splitter zones or demand point group/zone."""
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                                          QListWidget, QAbstractItemView,
                                          QSpinBox, QPushButton, QComboBox,
                                          QGroupBox, QFormLayout, QFrame,
                                          QTabWidget, QWidget)
        from qgis.PyQt.QtCore import Qt
        from qgis.core import QgsProject, QgsVectorLayer
        import sip, math

        # ---- Locate Splitter Points layer ----
        # Priority: PON accumulator → batch ref → name search
        splitter_layer = None
        try:
            _accum_sp = getattr(self, '_pon_accum_splitters', None)
            if _accum_sp and not sip.isdeleted(_accum_sp) and _accum_sp.featureCount() > 0:
                splitter_layer = _accum_sp
        except Exception:
            pass
        if not splitter_layer:
            try:
                if self.splitter_points_layer and not sip.isdeleted(self.splitter_points_layer):
                    splitter_layer = self.splitter_points_layer
            except Exception:
                pass
        if not splitter_layer:
            for _lyr in QgsProject.instance().mapLayers().values():
                if isinstance(_lyr, QgsVectorLayer) and 'splitter' in _lyr.name().lower() and _lyr.geometryType() == 0:
                    splitter_layer = _lyr
                    break
        if not splitter_layer:
            self.log_message("ERROR: No Splitter Points layer found. Generate splitter points first.")
            return

        sp_field_names = [f.name() for f in splitter_layer.fields()]
        if 'zone_id' not in sp_field_names:
            self.log_message("WARNING: Splitter layer has no 'zone_id' field. Re-generate splitter points first.")
            return

        def _to_int(v, default=0):
            """Safely convert QVariant/None/str/int to int."""
            if v is None:
                return default
            try:
                from qgis.PyQt.QtCore import QVariant as _QV
                if isinstance(v, _QV):
                    return default if v.isNull() else int(v.value())
            except Exception:
                pass
            try:
                return int(v)
            except (TypeError, ValueError):
                return default

        # ---- Build splitter data list ----
        splitter_data = []
        for _feat in splitter_layer.getFeatures():
            _gid = _feat['group_id']
            _zid = _feat['zone_id']
            _dc  = _feat['drop_count'] if 'drop_count' in sp_field_names else 0
            _pt  = _feat.geometry().asPoint() if (_feat.geometry() and not _feat.geometry().isEmpty()) else None
            splitter_data.append({
                'fid':        _feat.id(),
                'group_id':   _to_int(_gid, 0),
                'zone_id':    _to_int(_zid, -1),
                'drop_count': _to_int(_dc,  0),
                'x':          _pt.x()  if _pt  else 0.0,
                'y':          _pt.y()  if _pt  else 0.0,
            })
        if not splitter_data:
            self.log_message("ERROR: Splitter Points layer is empty.")
            return

        # ---- Locate Demand Points layer + build demand_data ----
        # Priority: PON Groups accumulator → batch ref → name search
        _dem_layer = None
        _dp_link = None   # group link field (e.g. group_8)
        _dp_zi   = -1     # zone_id field index
        _dp_zni  = -1     # zone_name field index
        try:
            _accum_grp = getattr(self, '_pon_accum_groups', None)
            if _accum_grp and not sip.isdeleted(_accum_grp) and _accum_grp.featureCount() > 0:
                _dem_layer = _accum_grp
        except Exception:
            pass
        if not _dem_layer:
            try:
                if self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                    _dem_layer = self.demand_points_layer
            except Exception:
                pass
        if not _dem_layer:
            for _lyr in QgsProject.instance().mapLayers().values():
                if isinstance(_lyr, QgsVectorLayer):
                    _ln = _lyr.name().lower()
                    if 'demand points' in _ln or 'demand_points' in _ln or 'pon groups' in _ln:
                        _dem_layer = _lyr
                        break
        demand_data = []
        if _dem_layer:
            _dfnames = [f.name() for f in _dem_layer.fields()]
            _dp_link = next((fn for fn in ['group_8', 'group_16', 'group_128', 'group_100', 'batch_id']
                              if fn in _dfnames), None)
            _dp_zi   = _dem_layer.fields().indexFromName('zone_id')   if 'zone_id'   in _dfnames else -1
            _dp_zni  = _dem_layer.fields().indexFromName('zone_name') if 'zone_name' in _dfnames else -1
            if _dp_link:
                for _f in _dem_layer.getFeatures():
                    _gid = _f[_dp_link]
                    _zid = _f['zone_id'] if _dp_zi >= 0 else None
                    _pt  = _f.geometry().asPoint() if (_f.geometry() and not _f.geometry().isEmpty()) else None
                    demand_data.append({
                        'fid':      _f.id(),
                        'group_id': _to_int(_gid, 0),
                        'zone_id':  _to_int(_zid, -1),
                        'x':        _pt.x() if _pt else 0.0,
                        'y':        _pt.y() if _pt else 0.0,
                    })

        # ---- Resolve the Drop Cables layer this dialog regenerates into ----
        # Every regen call below passes this so drops are always rebuilt on the
        # SAME layer the dialog targets (Manual Override Final's picked drops layer
        # → PON drops accumulator → single-run ref → name search). Resolved ONCE
        # here so all edit operations stay consistent.
        _drop_layer = None
        for _cand in (getattr(self, '_pon_accum_drops', None),
                      getattr(self, 'drop_ptp_layer', None)):
            try:
                if _cand is not None and not sip.isdeleted(_cand):
                    _drop_layer = _cand
                    break
            except Exception:
                pass
        if _drop_layer is None:
            for _lyr in QgsProject.instance().mapLayers().values():
                if isinstance(_lyr, QgsVectorLayer) and _lyr.geometryType() == 1:
                    _ln = _lyr.name().lower()
                    if 'drop cables ptp' in _ln or _ln == 'drops' or 'drop cable' in _ln:
                        _drop_layer = _lyr
                        break
        self.log_message(
            f"[Manual Override] Editing — Splitters: '{splitter_layer.name()}', "
            f"Demand: '{_dem_layer.name() if _dem_layer else 'none'}', "
            f"Drops: '{_drop_layer.name() if _drop_layer else '(auto/new)'}'")

        # Single helper so every edit operation regenerates drops against the
        # exact layers this dialog is editing (no independent re-resolution).
        def _regen_drops():
            self.on_generate_drop_ptp_clicked(
                silent=True, demand_layer=_dem_layer,
                splitter_layer=splitter_layer, drop_layer=_drop_layer)

        # ---- Prevent second instance ----
        if getattr(self, '_override_dlg', None) and self._override_dlg.isVisible():
            self._override_dlg.raise_()
            self._override_dlg.activateWindow()
            return

        # ================================================================
        # Build dialog
        # ================================================================
        dlg = QDialog(self)
        self._override_dlg = dlg
        dlg.setWindowTitle("Manual Override")
        dlg.setMinimumWidth(500)
        dlg.setMinimumHeight(580)
        dlg.setModal(False)
        dlg.setWindowFlags(dlg.windowFlags() | Qt.WindowType.WindowStaysOnTopHint)
        layout = QVBoxLayout(dlg)
        layout.setSpacing(6)

        # Shared map-pick toggle (top of dialog)
        pick_row = QHBoxLayout()
        btn_pick = QPushButton("Map Picking: ON")
        btn_pick.setCheckable(True)
        btn_pick.setChecked(True)
        btn_pick.setStyleSheet(
            "QPushButton:checked  { background-color: #4CAF50; color: white; font-weight: bold; }"
            "QPushButton:!checked { background-color: #f0ad4e; color: black; }")
        btn_pick.setToolTip("Click on the map to select the nearest feature on the active tab.")
        pick_row.addStretch()
        pick_row.addWidget(btn_pick)
        layout.addLayout(pick_row)

        # Tab widget
        tab_widget = QTabWidget()
        layout.addWidget(tab_widget)

        # ----------------------------------------------------------------
        # TAB 0 — Splitter Zones
        # ----------------------------------------------------------------
        tab_sp = QWidget()
        sp_layout = QVBoxLayout(tab_sp)
        sp_layout.setSpacing(6)

        sp_layout.addWidget(QLabel("<b>Select splitters and reassign them to a new PON zone.</b>"))
        sp_layout.addWidget(QLabel("Click splitters on the map or use Ctrl/Shift+click on the list."))

        list_widget = QListWidget()
        list_widget.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        list_widget.setMinimumHeight(160)
        for sd in splitter_data:
            list_widget.addItem(f"Group {sd['group_id']}   |   Zone {sd['zone_id']}   |   {sd['drop_count']} drops")
        sp_layout.addWidget(list_widget)

        sp_sel_row = QHBoxLayout()
        btn_select_all = QPushButton("Select All")
        btn_clear_sel  = QPushButton("Clear Selection")
        btn_zoom_sel   = QPushButton("Zoom to Selected")
        btn_zoom_sel.setToolTip("Zoom the map canvas to the selected splitters")
        sp_sel_row.addWidget(btn_select_all)
        sp_sel_row.addWidget(btn_clear_sel)
        sp_sel_row.addWidget(btn_zoom_sel)
        sp_sel_row.addStretch()
        sp_layout.addLayout(sp_sel_row)

        summary_box = QGroupBox("Selection Summary")
        form = QFormLayout(summary_box)
        lbl_sel_count = QLabel("0")
        lbl_sel_zones = QLabel("—")
        lbl_sel_drops = QLabel("0")
        form.addRow("Selected:",      lbl_sel_count)
        form.addRow("Current Zones:", lbl_sel_zones)
        form.addRow("Total Drops:",   lbl_sel_drops)
        sp_layout.addWidget(summary_box)

        nz_box = QGroupBox("New Zone Assignment")
        nz_row = QHBoxLayout(nz_box)
        nz_row.addWidget(QLabel("New Zone ID:"))
        spin = QSpinBox()
        spin.setMinimum(0)
        spin.setMaximum(9999)
        nz_row.addWidget(spin)
        nz_row.addStretch()
        btn_apply_sp = QPushButton("Apply Zone Change")
        btn_apply_sp.setDefault(True)
        btn_undo_sp = QPushButton("↩ Undo")
        btn_undo_sp.setEnabled(False)
        btn_undo_sp.setToolTip("Undo the last applied change")
        nz_row.addWidget(btn_apply_sp)
        nz_row.addWidget(btn_undo_sp)
        sp_layout.addWidget(nz_box)

        tab_widget.addTab(tab_sp, "Splitter Zones")

        # ----------------------------------------------------------------
        # TAB 1 — Demand Points
        # ----------------------------------------------------------------
        tab_dp = QWidget()
        dp_layout = QVBoxLayout(tab_dp)
        dp_layout.setSpacing(6)

        # State for add-new-demand-point mode (shared with map tool section)
        _dp_new_point = [None]   # [QgsPointXY or None]
        _dp_add_mode  = [False]  # True while "Place on Map" is active

        if demand_data:
            dp_layout.addWidget(QLabel("<b>Select demand points and reassign them to a different splitter.</b>"))
            dp_layout.addWidget(QLabel(
                "Draw a polygon on the map (left-click to add vertices, right-click to finish and select) "
                "or use Ctrl/Shift+click on the list."))

            dem_list = QListWidget()
            dem_list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
            dem_list.setMinimumHeight(160)
            for dd in demand_data:
                dem_list.addItem(f"DP {dd['fid']}   |   Group {dd['group_id']}   |   Zone {dd['zone_id']}")
            dp_layout.addWidget(dem_list)

            dp_sel_row = QHBoxLayout()
            btn_dp_select_all = QPushButton("Select All")
            btn_dp_clear_sel  = QPushButton("Clear Selection")
            dp_sel_row.addWidget(btn_dp_select_all)
            dp_sel_row.addWidget(btn_dp_clear_sel)
            dp_sel_row.addStretch()
            dp_layout.addLayout(dp_sel_row)

            dp_info_box = QGroupBox("Selection Info")
            dp_form = QFormLayout(dp_info_box)
            lbl_dp_count = QLabel("0")
            lbl_dp_groups = QLabel("—")
            dp_form.addRow("Selected:",        lbl_dp_count)
            dp_form.addRow("Current Groups:",  lbl_dp_groups)
            dp_layout.addWidget(dp_info_box)

            tgt_box = QGroupBox("Target Splitter")
            tgt_form = QFormLayout(tgt_box)

            # Manual group ID entry
            from qgis.PyQt.QtWidgets import QSpinBox
            spin_grp = QSpinBox()
            spin_grp.setMinimum(1)
            spin_grp.setMaximum(99999)
            spin_grp.setValue(splitter_data[0]['group_id'] if splitter_data else 1)
            spin_grp.setToolTip("Type or select the target Group ID directly")
            tgt_form.addRow("Group ID (manual):", spin_grp)

            combo_target = QComboBox()
            combo_target.setMinimumWidth(300)
            for sd in splitter_data:
                combo_target.addItem(f"Group {sd['group_id']}  |  Zone {sd['zone_id']}  |  {sd['drop_count']} drops")
            tgt_form.addRow("Or pick from list:", combo_target)

            # Sync spin_grp ↔ combo_target
            def _combo_to_spin(idx):
                if 0 <= idx < len(splitter_data):
                    spin_grp.blockSignals(True)
                    spin_grp.setValue(splitter_data[idx]['group_id'])
                    spin_grp.blockSignals(False)

            def _spin_to_combo():
                gid = spin_grp.value()
                for i, sd in enumerate(splitter_data):
                    if sd['group_id'] == gid:
                        combo_target.blockSignals(True)
                        combo_target.setCurrentIndex(i)
                        combo_target.blockSignals(False)
                        return

            combo_target.currentIndexChanged.connect(_combo_to_spin)
            spin_grp.valueChanged.connect(_spin_to_combo)
            dp_layout.addWidget(tgt_box)

            dp_btn_row = QHBoxLayout()
            btn_apply_dp = QPushButton("Apply Demand Reassignment")
            btn_undo_dp  = QPushButton("↩ Undo")
            btn_undo_dp.setEnabled(False)
            btn_undo_dp.setToolTip("Undo the last applied change")
            btn_regen_drops_dp = QPushButton("🔄 Regenerate Drops")
            btn_regen_drops_dp.setStyleSheet(
                "QPushButton { background-color: #d9534f; color: white; font-weight: bold; }")
            btn_regen_drops_dp.setToolTip(
                "Manually regenerate drop cables after reassigning demand points or moving splitters.")
            dp_btn_row.addWidget(btn_apply_dp)
            dp_btn_row.addWidget(btn_undo_dp)
            dp_btn_row.addWidget(btn_regen_drops_dp)
            dp_btn_row.addStretch()
            dp_layout.addLayout(dp_btn_row)

            # ---- Add New Demand Point section --------------------------------
            add_dp_box = QGroupBox("Add New Demand Point")
            add_dp_vbox = QVBoxLayout(add_dp_box)
            add_dp_vbox.setSpacing(4)

            add_dp_vbox.addWidget(QLabel(
                "Click <b>📍 Place on Map</b>, then click the map to capture coordinates.\n"
                "Zone is auto-detected. Assign a splitter before adding."))

            # Captured location
            add_dp_loc_box = QGroupBox("Captured Location")
            add_dp_loc_form = QFormLayout(add_dp_loc_box)
            lbl_new_dp_x = QLabel("—")
            lbl_new_dp_y = QLabel("—")
            add_dp_loc_form.addRow("X (Easting):",  lbl_new_dp_x)
            add_dp_loc_form.addRow("Y (Northing):", lbl_new_dp_y)
            add_dp_vbox.addWidget(add_dp_loc_box)

            # Attributes
            add_dp_attr_box = QGroupBox("Demand Point Attributes")
            add_dp_attr_form = QFormLayout(add_dp_attr_box)

            from qgis.PyQt.QtWidgets import QSpinBox as _DPSpinBox
            spin_dp_zone = _DPSpinBox()
            spin_dp_zone.setMinimum(0)
            spin_dp_zone.setMaximum(99999)
            spin_dp_zone.setValue(0)
            spin_dp_zone.setToolTip("Auto-detected from PON Zone polygon; editable")

            combo_add_dp_grp = QComboBox()
            combo_add_dp_grp.setMinimumWidth(280)
            combo_add_dp_grp.addItem("— Select splitter —")
            for _sd in splitter_data:
                combo_add_dp_grp.addItem(
                    f"Group {_sd['group_id']}  |  Zone {_sd['zone_id']}  |  {_sd['drop_count']} drops")

            add_dp_attr_form.addRow("Zone ID (auto):",    spin_dp_zone)
            add_dp_attr_form.addRow("Assign to Splitter:", combo_add_dp_grp)
            add_dp_vbox.addWidget(add_dp_attr_box)

            add_dp_btn_row = QHBoxLayout()
            btn_place_dp = QPushButton("📍 Place on Map")
            btn_place_dp.setCheckable(True)
            btn_place_dp.setStyleSheet(
                "QPushButton:checked  { background-color: #9b59b6; color: white; font-weight: bold; }"
                "QPushButton:!checked { background-color: #ecf0f1; color: black; }")
            btn_place_dp.setToolTip("Enable then click the map to capture location for the new demand point.")

            btn_add_dp = QPushButton("Add Demand Point")
            btn_add_dp.setEnabled(False)
            btn_add_dp.setStyleSheet(
                "QPushButton:enabled  { background-color: #4CAF50; color: white; font-weight: bold; }"
                "QPushButton:disabled { background-color: #cccccc; color: #888; }")
            btn_add_dp.setToolTip("Disabled until a location is captured AND a splitter is selected.")

            btn_clear_new_dp = QPushButton("Clear")
            add_dp_btn_row.addWidget(btn_place_dp)
            add_dp_btn_row.addWidget(btn_add_dp)
            add_dp_btn_row.addWidget(btn_clear_new_dp)
            add_dp_btn_row.addStretch()
            add_dp_vbox.addLayout(add_dp_btn_row)
            dp_layout.addWidget(add_dp_box)

            # ---- Delete Demand Point section ---------------------------------
            del_dp_box = QGroupBox("Delete Demand Point")
            del_dp_vbox = QVBoxLayout(del_dp_box)
            del_dp_vbox.setSpacing(4)
            del_dp_vbox.addWidget(QLabel(
                "Select demand points in the list above, then click Delete to remove them from the layer."))
            del_dp_btn_row = QHBoxLayout()
            btn_delete_dp = QPushButton("🗑 Delete Selected Demand Points")
            btn_delete_dp.setStyleSheet(
                "QPushButton { background-color: #c0392b; color: white; font-weight: bold; }")
            btn_delete_dp.setToolTip("Permanently deletes the selected demand points from the layer.")
            del_dp_btn_row.addWidget(btn_delete_dp)
            del_dp_btn_row.addStretch()
            del_dp_vbox.addLayout(del_dp_btn_row)
            dp_layout.addWidget(del_dp_box)

            # helper: re-evaluate Add button state
            def _refresh_add_dp_btn():
                _has_pt  = _dp_new_point[0] is not None
                _has_grp = combo_add_dp_grp.currentIndex() > 0   # index 0 is "— Select splitter —"
                btn_add_dp.setEnabled(_has_pt and _has_grp)

            combo_add_dp_grp.currentIndexChanged.connect(lambda _: _refresh_add_dp_btn())

            def _clear_new_dp():
                _dp_new_point[0] = None
                lbl_new_dp_x.setText("—")
                lbl_new_dp_y.setText("—")
                spin_dp_zone.setValue(0)
                combo_add_dp_grp.setCurrentIndex(0)
                btn_place_dp.setChecked(False)
                btn_add_dp.setEnabled(False)

            btn_clear_new_dp.clicked.connect(_clear_new_dp)

        else:
            dp_layout.addWidget(QLabel("No Demand Points layer found.\nGenerate demand points first."))
            dem_list         = None
            combo_target     = None
            btn_apply_dp     = None
            btn_undo_dp      = None
            btn_regen_drops_dp = None
            btn_place_dp     = None
            btn_add_dp       = None
            btn_delete_dp    = None
            combo_add_dp_grp = None
            spin_dp_zone     = None
            lbl_new_dp_x     = None
            lbl_new_dp_y     = None

        tab_widget.addTab(tab_dp, "Demand Points")

        # ----------------------------------------------------------------
        # TAB 2 — Add Splitter Point
        # ----------------------------------------------------------------
        tab_ns = QWidget()
        ns_layout = QVBoxLayout(tab_ns)
        ns_layout.setSpacing(6)

        ns_layout.addWidget(QLabel("<b>Manually place a new splitter point on the map.</b>"))
        ns_layout.addWidget(QLabel(
            "Click on the map to capture coordinates, then confirm attributes and click Add."))

        # Captured location display
        ns_loc_box = QGroupBox("Captured Location")
        ns_loc_form = QFormLayout(ns_loc_box)
        lbl_ns_x = QLabel("—")
        lbl_ns_y = QLabel("—")
        ns_loc_form.addRow("X (Easting):", lbl_ns_x)
        ns_loc_form.addRow("Y (Northing):", lbl_ns_y)
        ns_layout.addWidget(ns_loc_box)

        # Auto-detected / editable attributes
        ns_attr_box = QGroupBox("Splitter Attributes")
        ns_attr_form = QFormLayout(ns_attr_box)

        _max_grp = max((sd['group_id'] for sd in splitter_data), default=0)
        from qgis.PyQt.QtWidgets import QSpinBox as _NSSpinBox
        spin_ns_zone = _NSSpinBox()
        spin_ns_zone.setMinimum(0)
        spin_ns_zone.setMaximum(99999)
        spin_ns_zone.setValue(0)
        spin_ns_zone.setToolTip("Auto-detected from PON Zone polygon; editable")

        spin_ns_group = _NSSpinBox()
        spin_ns_group.setMinimum(1)
        spin_ns_group.setMaximum(999999)
        spin_ns_group.setValue(_max_grp + 1)
        spin_ns_group.setToolTip("Suggested next group ID; editable")

        spin_ns_drops = _NSSpinBox()
        spin_ns_drops.setMinimum(0)
        spin_ns_drops.setMaximum(9999)
        spin_ns_drops.setValue(0)
        spin_ns_drops.setToolTip("Number of drop cables (demand points) for this splitter")

        ns_attr_form.addRow("Zone ID (auto):", spin_ns_zone)
        ns_attr_form.addRow("Group ID:",       spin_ns_group)
        ns_attr_form.addRow("Drop Count:",     spin_ns_drops)
        ns_layout.addWidget(ns_attr_box)

        ns_btn_row = QHBoxLayout()
        btn_add_sp  = QPushButton("Add Splitter Point")
        btn_add_sp.setEnabled(False)
        btn_add_sp.setStyleSheet(
            "QPushButton:enabled  { background-color: #4CAF50; color: white; font-weight: bold; }"
            "QPushButton:disabled { background-color: #cccccc; color: #888; }")
        btn_clear_ns = QPushButton("Clear")
        ns_btn_row.addWidget(btn_add_sp)
        ns_btn_row.addWidget(btn_clear_ns)
        ns_btn_row.addStretch()
        ns_layout.addLayout(ns_btn_row)
        ns_layout.addStretch()

        # Container for the pending point coords
        _ns_point = [None]   # [QgsPointXY or None]

        def _clear_ns():
            _ns_point[0] = None
            lbl_ns_x.setText("—")
            lbl_ns_y.setText("—")
            btn_add_sp.setEnabled(False)
            spin_ns_zone.setValue(0)
            spin_ns_group.setValue(max((sd['group_id'] for sd in splitter_data), default=0) + 1)
            spin_ns_drops.setValue(0)

        btn_clear_ns.clicked.connect(_clear_ns)

        def _do_add_splitter():
            if not _ns_point[0]:
                status_lbl.setText("<font color='red'>No point captured. Click the map first.</font>")
                return
            from qgis.core import QgsFeature, QgsGeometry, QgsPointXY
            _pt = _ns_point[0]
            _gid  = spin_ns_group.value()
            _zid  = spin_ns_zone.value()
            _dcnt = spin_ns_drops.value()

            # Guard: duplicate group_id
            if any(sd['group_id'] == _gid for sd in splitter_data):
                status_lbl.setText(
                    f"<font color='red'>Group ID {_gid} already exists. Choose a different Group ID.</font>")
                return

            new_feat = QgsFeature(splitter_layer.fields())
            new_feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(_pt.x(), _pt.y())))
            new_feat.setAttributes([
                _gid,          # fid
                str(_gid),     # ID
                _gid,          # group_id
                _zid,          # zone_id
                _dcnt,         # drop_count
            ])

            splitter_layer.startEditing()
            ok = splitter_layer.addFeature(new_feat)
            splitter_layer.commitChanges()

            # If writing to the PON accumulator, rebuild the renderer so the
            # new zone_id gets a colour category and the point becomes visible.
            _accum_sp = getattr(self, '_pon_accum_splitters', None)
            try:
                import sip as _sip2
                if _accum_sp and not _sip2.isdeleted(_accum_sp) and splitter_layer is _accum_sp:
                    self._pon_refresh_accum_renderers()
                else:
                    splitter_layer.triggerRepaint()
            except Exception:
                splitter_layer.triggerRepaint()

            if ok:
                # Update in-memory list so tab 0 reflects the new splitter
                _new_fid = new_feat.id()
                splitter_data.append({
                    'fid':        _new_fid,
                    'group_id':   _gid,
                    'zone_id':    _zid,
                    'drop_count': _dcnt,
                    'x':          _pt.x(),
                    'y':          _pt.y(),
                })
                list_widget.addItem(
                    f"Group {_gid}   |   Zone {_zid}   |   {_dcnt} drops")
                # Update combo in demand tab
                if demand_data:
                    combo_target.addItem(
                        f"Group {_gid}  |  Zone {_zid}  |  {_dcnt} drops")
                # Keep the Delete-Splitter and Assign-to-Splitter dropdowns in
                # sync — both map their index back into splitter_data by
                # position, so the just-appended splitter must be appended here
                # too or it can't be selected for deletion / demand assignment.
                combo_del_sp.addItem(
                    f"Group {_gid}  |  Zone {_zid}  |  {_dcnt} drops")
                if combo_add_dp_grp is not None:
                    combo_add_dp_grp.addItem(
                        f"Group {_gid}  |  Zone {_zid}  |  {_dcnt} drops")

                status_lbl.setText(
                    f"<font color='green'><b>✓ Splitter added:</b> "
                    f"Group {_gid} | Zone {_zid} | {_dcnt} drops at "
                    f"({_pt.x():.1f}, {_pt.y():.1f})</font>")
                self.log_message(
                    f"Manual Override — new splitter: Group {_gid}, Zone {_zid}, "
                    f"drops={_dcnt}, pos=({_pt.x():.2f}, {_pt.y():.2f})")
                _clear_ns()
            else:
                status_lbl.setText("<font color='red'>Failed to add splitter feature to layer.</font>")

        btn_add_sp.clicked.connect(_do_add_splitter)

        # ---- Move / Edit / Regenerate buttons ----
        action_btn_row = QHBoxLayout()
        btn_move_sp = QPushButton("Move Splitter")
        btn_move_sp.setCheckable(True)
        btn_move_sp.setStyleSheet(
            "QPushButton:checked  { background-color: #e67e22; color: white; font-weight: bold; }"
            "QPushButton:!checked { background-color: #ecf0f1; color: black; }")
        btn_move_sp.setToolTip(
            "Click to enable: then click a splitter on the map to select it, "
            "then click the new location to move it there.")

        btn_edit_sp = QPushButton("Edit Splitter")
        btn_edit_sp.setCheckable(True)
        btn_edit_sp.setStyleSheet(
            "QPushButton:checked  { background-color: #2980b9; color: white; font-weight: bold; }"
            "QPushButton:!checked { background-color: #ecf0f1; color: black; }")
        btn_edit_sp.setToolTip(
            "Click to enable: then click a splitter on the map to load its attributes, "
            "edit the values above, then click Apply Edit to save.")

        btn_regen_drops_sp = QPushButton("Regenerate Drops")
        btn_regen_drops_sp.setStyleSheet(
            "QPushButton { background-color: #d9534f; color: white; font-weight: bold; }")
        btn_regen_drops_sp.setToolTip("Re-run Generate Drops PTP to update drop cables from splitters to demand points.")

        action_btn_row.addWidget(btn_move_sp)
        action_btn_row.addWidget(btn_edit_sp)
        action_btn_row.addWidget(btn_regen_drops_sp)
        action_btn_row.addStretch()
        ns_layout.addLayout(action_btn_row)

        # Apply Edit button (hidden until edit mode is active)
        edit_apply_row = QHBoxLayout()
        btn_apply_edit_sp = QPushButton("Apply Edit")
        btn_apply_edit_sp.setEnabled(False)
        btn_apply_edit_sp.setStyleSheet(
            "QPushButton:enabled  { background-color: #27ae60; color: white; font-weight: bold; }"
            "QPushButton:disabled { background-color: #cccccc; color: #888; }")
        btn_apply_edit_sp.setToolTip("Save the edited attributes back to the selected splitter.")
        edit_apply_row.addWidget(btn_apply_edit_sp)
        edit_apply_row.addStretch()
        ns_layout.addLayout(edit_apply_row)

        _edit_state = {"fid": None}   # fid of splitter being edited

        def _apply_splitter_edit():
            fid = _edit_state["fid"]
            if fid is None:
                return
            new_zid  = spin_ns_zone.value()
            new_gid  = spin_ns_group.value()
            new_dcnt = spin_ns_drops.value()

            # Read old values before editing so we can detect zone changes
            fnames = [f.name() for f in splitter_layer.fields()]
            old_feat = splitter_layer.getFeature(fid)
            old_zid  = int(old_feat["zone_id"]  or 0) if "zone_id"  in fnames else new_zid
            try:
                old_gid = int(old_feat["group_id"]) if "group_id" in fnames else new_gid
            except (TypeError, ValueError):
                old_gid = new_gid

            splitter_layer.startEditing()
            if "zone_id"    in fnames: splitter_layer.changeAttributeValue(fid, fnames.index("zone_id"),    new_zid)
            if "group_id"   in fnames: splitter_layer.changeAttributeValue(fid, fnames.index("group_id"),   new_gid)
            if "drop_count" in fnames: splitter_layer.changeAttributeValue(fid, fnames.index("drop_count"), new_dcnt)
            splitter_layer.commitChanges()
            splitter_layer.removeSelection()
            # Rebuild renderer if editing accumulator so zone colour stays correct
            _accum_sp_e = getattr(self, '_pon_accum_splitters', None)
            try:
                import sip as _sip3
                if _accum_sp_e and not _sip3.isdeleted(_accum_sp_e) and splitter_layer is _accum_sp_e:
                    self._pon_refresh_accum_renderers()
                else:
                    splitter_layer.triggerRepaint()
            except Exception:
                splitter_layer.triggerRepaint()

            # --- Cascade group_id change to demand points --------------------
            # If group_id was changed, update all demand points that referenced the
            # old group_id so their physical splitter connection is preserved.
            if old_gid != new_gid and _dem_layer and _dp_link:
                _dp_grp_idx_ed = _dem_layer.fields().indexFromName(_dp_link)
                if _dp_grp_idx_ed >= 0:
                    _dem_layer.startEditing()
                    for _ef in _dem_layer.getFeatures():
                        try:
                            _ef_gid = int(_ef[_dp_link])
                        except (TypeError, ValueError):
                            continue
                        if _ef_gid == old_gid:
                            _dem_layer.changeAttributeValue(_ef.id(), _dp_grp_idx_ed, new_gid)
                    _dem_layer.commitChanges()
                    _dem_layer.triggerRepaint()
                # Update in-memory demand_data too
                for _de in demand_data:
                    if _de['group_id'] == old_gid:
                        _de['group_id'] = new_gid
                self.log_message(
                    f"[Edit Splitter] group_id cascade: {old_gid} → {new_gid} on demand layer '{_dem_layer.name()}'")

            # --- Cascade zone change to PON Zone boundary polygon -----------
            # Only needed when zone_id actually changed.
            if old_zid != new_zid:
                # Determine which group_id to look up demand points for.
                # Use new_gid (just edited) which is the authoritative group link.
                _edit_grp = new_gid

                # Locate demand / grouped layer and its group link field
                _el = None
                _el_link = None
                import sip as _sip2
                try:
                    if self.demand_points_layer and not _sip2.isdeleted(self.demand_points_layer):
                        _el = self.demand_points_layer
                except Exception:
                    pass
                if not _el:
                    for _lx in QgsProject.instance().mapLayers().values():
                        if isinstance(_lx, QgsVectorLayer):
                            _ln = _lx.name().lower()
                            if 'demand points' in _ln or 'demand_points' in _ln:
                                _el = _lx
                                break
                if _el:
                    _efnames = [f.name() for f in _el.fields()]
                    _el_link = next((fn for fn in ['group_8', 'group_16', 'group_128',
                                                    'group_100', 'batch_id']
                                      if fn in _efnames), None)
                    # Also update zone_id on demand points for this group
                    _el_zi = _el.fields().indexFromName('zone_id') if 'zone_id' in _efnames else -1
                    _el_zni = _el.fields().indexFromName('zone_name') if 'zone_name' in _efnames else -1
                    if _el_link and _el_zi >= 0:
                        _el.startEditing()
                        for _ef in _el.getFeatures():
                            if _ef[_el_link] == _edit_grp:
                                _el.changeAttributeValue(_ef.id(), _el_zi, new_zid)
                                if _el_zni >= 0:
                                    _el.changeAttributeValue(_ef.id(), _el_zni, f"Zone {new_zid}")
                        _el.commitChanges()
                        _el.triggerRepaint()

                # Rebuild PON Zone boundary polygons for old_zid and new_zid
                _src_lyr  = _el if (_el and _el_link) else None
                _src_link = _el_link

                # If demand layer not usable, fall back to grouped_layer
                if not _src_lyr:
                    _gl = getattr(self, 'grouped_layer', None)
                    try:
                        if _gl and not _sip2.isdeleted(_gl):
                            _gfn = [f.name() for f in _gl.fields()]
                            _gl_link = next((fn for fn in ['group_8', 'group_16', 'group_128',
                                                            'group_100', 'batch_id']
                                              if fn in _gfn), None)
                            if _gl_link:
                                _src_lyr  = _gl
                                _src_link = _gl_link
                    except Exception:
                        pass

                if _src_lyr and _src_link:
                    # Build zone→groups mapping from the full splitter layer (post-edit)
                    _z2g_edit: dict = {}
                    for _sf2 in splitter_layer.getFeatures():
                        _z = int(_sf2["zone_id"] or 0) if "zone_id" in fnames else -1
                        _g = _sf2["group_id"] if "group_id" in fnames else None
                        if _g is not None:
                            _z2g_edit.setdefault(_z, set()).add(_g)

                    for _pon_lyr in QgsProject.instance().mapLayers().values():
                        if not (isinstance(_pon_lyr, QgsVectorLayer) and 'PON Zones' in _pon_lyr.name()):
                            continue
                        _pf = [f.name() for f in _pon_lyr.fields()]
                        if 'zone_id' not in _pf or 'unit_count' not in _pf:
                            continue
                        _uc_idx = _pon_lyr.fields().indexFromName('unit_count')
                        _pon_lyr.startEditing()
                        _old_found = False
                        _new_found = False
                        _del_fids  = []
                        for _pf2 in _pon_lyr.getFeatures():
                            _pzid = int(_pf2['zone_id'] or 0)
                            if _pzid == old_zid:
                                _old_found = True
                                _rem_grps = _z2g_edit.get(old_zid, set())
                                _rem_feats = [_ff for _ff in _src_lyr.getFeatures()
                                              if _ff[_src_link] in _rem_grps]
                                if _rem_feats:
                                    _oz_geom = self._build_zone_polygon(_src_lyr, _rem_feats)
                                    if not _oz_geom.isEmpty():
                                        _pon_lyr.changeGeometry(_pf2.id(), _oz_geom)
                                    new_uc = sum(1 for _ in _rem_feats)
                                    _pon_lyr.changeAttributeValue(_pf2.id(), _uc_idx, new_uc)
                                else:
                                    _del_fids.append(_pf2.id())
                            elif _pzid == new_zid:
                                _new_found = True
                                _new_grps = _z2g_edit.get(new_zid, set())
                                _nz_feats = [_ff for _ff in _src_lyr.getFeatures()
                                             if _ff[_src_link] in _new_grps]
                                if _nz_feats:
                                    _nz_geom = self._build_zone_polygon(_src_lyr, _nz_feats)
                                    if not _nz_geom.isEmpty():
                                        _pon_lyr.changeGeometry(_pf2.id(), _nz_geom)
                                    new_uc = sum(1 for _ in _nz_feats)
                                    _pon_lyr.changeAttributeValue(_pf2.id(), _uc_idx, new_uc)
                        if _del_fids:
                            _pon_lyr.deleteFeatures(_del_fids)
                        # Create new polygon if new zone has no existing polygon
                        if not _new_found:
                            _new_grps = _z2g_edit.get(new_zid, set())
                            _nz_feats = [_ff for _ff in _src_lyr.getFeatures()
                                         if _ff[_src_link] in _new_grps]
                            if _nz_feats:
                                from qgis.core import QgsFeature as _QFe
                                _nz_geom = self._build_zone_polygon(_src_lyr, _nz_feats)
                                if not _nz_geom.isEmpty():
                                    _nf = _QFe(_pon_lyr.fields())
                                    _nf.setGeometry(_nz_geom)
                                    _nf['zone_id']    = new_zid
                                    _nf['zone_name']  = f"Zone {new_zid}"
                                    _nf['unit_count'] = sum(1 for _ in _nz_feats)
                                    _pon_lyr.addFeature(_nf)
                        _pon_lyr.commitChanges()
                        _pon_lyr.triggerRepaint()
                        break

            status_lbl.setText(
                f"<font color='green'><b>✓ Splitter FID {fid} updated:</b> "
                f"Zone {new_zid} | Group {new_gid} | Drops {new_dcnt} — regenerating drop cables…</font>")
            _edit_state["fid"] = None
            btn_apply_edit_sp.setEnabled(False)
            btn_edit_sp.setChecked(False)
            _clear_ns()
            # Regenerate drop cables so lines reflect any position or attribute changes
            _regen_drops()
            status_lbl.setText(
                f"<font color='green'><b>✓ Splitter FID {fid} updated</b> — drops regenerated.</font>")

        btn_apply_edit_sp.clicked.connect(_apply_splitter_edit)

        def _do_regen_drops():
            status_lbl.setText("<font color='orange'>Regenerating drop cables…</font>")
            try:
                _regen_drops()
                _dr = _drop_layer if (_drop_layer is not None and not sip.isdeleted(_drop_layer)) \
                    else getattr(self, 'drop_ptp_layer', None)
                _lyr_name = _dr.name() if _dr else "Drop Cables PTP"
                _cnt = _dr.featureCount() if _dr else 0
                status_lbl.setText(
                    f"<font color='green'><b>✓ Drop cables regenerated</b> — "
                    f"{_cnt} cables in '{_lyr_name}'</font>")
            except Exception as _regen_err:
                status_lbl.setText(
                    f"<font color='red'>⚠ Drop regen failed: {_regen_err}</font>")
                self.log_message(f"[Manual Override] Drop regen error: {_regen_err}")

        btn_regen_drops_sp.clicked.connect(_do_regen_drops)

        # State for two-click move: [selected_fid, selected_geom]
        _move_state = [None, None]   # [fid, QgsGeometry snapshot]

        class _MoveSplitterTool(self.iface.mapCanvas().__class__.__bases__[0]):
            """Dummy base placeholder — replaced below."""

        from qgis.gui import QgsMapToolEmitPoint as _QMTEP

        class _MoveSplitterTool(_QMTEP):
            def __init__(self, canvas, state, layer, status, btn, prev_tool, regen_cb=None):
                super().__init__(canvas)
                self._state    = state
                self._layer    = layer
                self._status   = status
                self._btn      = btn
                self._prev     = prev_tool
                self._regen_cb = regen_cb  # called after a successful move to regenerate drops

            def canvasReleaseEvent(self, e):
                from qgis.core import QgsGeometry, QgsRectangle
                pt = self.toMapCoordinates(e.pos())
                if self._state[0] is None:
                    # Phase 1: find nearest splitter within a tolerance
                    tol = self.canvas().extent().width() * 0.01
                    rect = QgsRectangle(pt.x()-tol, pt.y()-tol, pt.x()+tol, pt.y()+tol)
                    best_fid, best_dist = None, float("inf")
                    for feat in self._layer.getFeatures():
                        g = feat.geometry()
                        if g and not g.isEmpty():
                            d = g.distance(QgsGeometry.fromPointXY(pt))
                            if d < best_dist:
                                best_dist, best_fid = d, feat.id()
                    if best_fid is not None:
                        self._state[0] = best_fid
                        self._state[1] = QgsGeometry(self._layer.getFeature(best_fid).geometry())
                        self._layer.selectByIds([best_fid])
                        self._status.setText(
                            f"<font color='orange'>Splitter FID {best_fid} selected — "
                            f"now click the new location.</font>")
                    else:
                        self._status.setText(
                            "<font color='red'>No splitter found near click. Try again.</font>")
                else:
                    # Phase 2: move selected splitter to new location
                    fid = self._state[0]
                    self._layer.startEditing()
                    self._layer.changeGeometry(fid, QgsGeometry.fromPointXY(pt))
                    self._layer.commitChanges()
                    self._layer.removeSelection()
                    self._layer.triggerRepaint()
                    self._status.setText(
                        f"<font color='green'><b>✓ Splitter moved</b> to "
                        f"({pt.x():.1f}, {pt.y():.1f}) — regenerating drop cables…</font>")
                    self._state[0] = None
                    self._state[1] = None
                    # Deactivate move mode before regen so button state is correct
                    self._btn.setChecked(False)
                    self.canvas().setMapTool(self._prev)
                    # Regenerate drop cables so lines track the new splitter position
                    if self._regen_cb:
                        self._regen_cb()

        _mv_prev = {"tool": None}

        def _toggle_move(checked):
            if checked:
                _mv_prev["tool"] = self.iface.mapCanvas().mapTool()
                tool = _MoveSplitterTool(
                    self.iface.mapCanvas(),
                    _move_state,
                    splitter_layer,
                    status_lbl,
                    btn_move_sp,
                    _mv_prev["tool"],
                    regen_cb=_do_regen_drops)
                self.iface.mapCanvas().setMapTool(tool)
                # store so we can clean up on dialog close
                dlg._move_tool = tool
                status_lbl.setText(
                    "<font color='orange'>Move mode ON — click a splitter to select it.</font>")
            else:
                _move_state[0] = None
                _move_state[1] = None
                splitter_layer.removeSelection()
                if _mv_prev["tool"]:
                    self.iface.mapCanvas().setMapTool(_mv_prev["tool"])
                status_lbl.setText("Move mode OFF.")

        btn_move_sp.toggled.connect(_toggle_move)

        # ---- Edit Splitter map tool ----
        class _EditSplitterTool(_QMTEP):
            def __init__(self, canvas, edit_state, layer, status, btn,
                         spin_zone, spin_group, spin_drops, btn_apply, prev_tool):
                super().__init__(canvas)
                self._edit_state = edit_state
                self._layer      = layer
                self._status     = status
                self._btn        = btn
                self._spin_zone  = spin_zone
                self._spin_group = spin_group
                self._spin_drops = spin_drops
                self._btn_apply  = btn_apply
                self._prev       = prev_tool

            def canvasReleaseEvent(self, e):
                from qgis.core import QgsGeometry
                pt = self.toMapCoordinates(e.pos())
                # Find nearest splitter
                best_fid, best_dist = None, float("inf")
                for feat in self._layer.getFeatures():
                    g = feat.geometry()
                    if g and not g.isEmpty():
                        d = g.distance(QgsGeometry.fromPointXY(pt))
                        if d < best_dist:
                            best_dist, best_fid = d, feat.id()
                if best_fid is None:
                    self._status.setText("<font color='red'>No splitter found near click.</font>")
                    return
                feat = self._layer.getFeature(best_fid)
                fnames = [f.name() for f in self._layer.fields()]
                self._edit_state["fid"] = best_fid
                self._layer.selectByIds([best_fid])
                if "zone_id"    in fnames: self._spin_zone.setValue(int(feat["zone_id"]  or 0))
                if "group_id"   in fnames: self._spin_group.setValue(int(feat["group_id"] or 0))
                if "drop_count" in fnames: self._spin_drops.setValue(int(feat["drop_count"] or 0))
                self._btn_apply.setEnabled(True)
                self._status.setText(
                    f"<font color='blue'><b>Splitter FID {best_fid} loaded</b> — "
                    f"edit values above then click Apply Edit.</font>")
                # Return to previous tool after selection
                self.canvas().setMapTool(self._prev)
                self._btn.setChecked(False)

        _edit_prev = {"tool": None}

        def _toggle_edit(checked):
            if checked:
                # Ensure move mode is off
                if btn_move_sp.isChecked():
                    btn_move_sp.setChecked(False)
                _edit_prev["tool"] = self.iface.mapCanvas().mapTool()
                tool = _EditSplitterTool(
                    self.iface.mapCanvas(),
                    _edit_state,
                    splitter_layer,
                    status_lbl,
                    btn_edit_sp,
                    spin_ns_zone,
                    spin_ns_group,
                    spin_ns_drops,
                    btn_apply_edit_sp,
                    _edit_prev["tool"])
                self.iface.mapCanvas().setMapTool(tool)
                dlg._edit_tool = tool
                status_lbl.setText(
                    "<font color='blue'>Edit mode ON — click a splitter to load its attributes.</font>")
            else:
                if _edit_prev["tool"]:
                    self.iface.mapCanvas().setMapTool(_edit_prev["tool"])
                status_lbl.setText("Edit mode OFF.")

        btn_edit_sp.toggled.connect(_toggle_edit)

        # Cancel all modes when dialog closes
        _orig_close = dlg.closeEvent if hasattr(dlg, "closeEvent") else None
        def _dlg_close(ev):
            if btn_move_sp.isChecked():
                btn_move_sp.setChecked(False)
            if btn_edit_sp.isChecked():
                btn_edit_sp.setChecked(False)
            if _orig_close:
                _orig_close(ev)
            else:
                ev.accept()
        dlg.closeEvent = _dlg_close

        # ---- Delete Splitter section ----------------------------------------
        del_sp_box = QGroupBox("Delete Splitter")
        del_sp_vbox = QVBoxLayout(del_sp_box)
        del_sp_vbox.setSpacing(4)
        del_sp_vbox.addWidget(QLabel(
            "Choose a splitter to delete. All its demand points will be <b>unlinked</b> "
            "(group set to 0). Drops are regenerated automatically."))

        del_sp_form = QFormLayout()
        combo_del_sp = QComboBox()
        combo_del_sp.setMinimumWidth(300)
        combo_del_sp.addItem("— Select splitter to delete —")
        for _sd in splitter_data:
            combo_del_sp.addItem(
                f"Group {_sd['group_id']}  |  Zone {_sd['zone_id']}  |  {_sd['drop_count']} drops")
        del_sp_form.addRow("Splitter:", combo_del_sp)

        from qgis.PyQt.QtWidgets import QCheckBox as _QCB
        chk_renumber = _QCB("Renumber all remaining splitters sequentially after deletion")
        chk_renumber.setChecked(True)
        chk_renumber.setToolTip(
            "When checked, group IDs of all remaining splitters (and their demand points) "
            "are renumbered 1, 2, 3… to fill the gap left by the deleted splitter.")
        del_sp_form.addRow("", chk_renumber)
        del_sp_vbox.addLayout(del_sp_form)

        del_sp_btn_row = QHBoxLayout()
        btn_delete_sp = QPushButton("🗑 Delete Splitter")
        btn_delete_sp.setEnabled(False)
        btn_delete_sp.setStyleSheet(
            "QPushButton:enabled  { background-color: #c0392b; color: white; font-weight: bold; }"
            "QPushButton:disabled { background-color: #cccccc; color: #888; }")
        btn_delete_sp.setToolTip("Permanently delete the selected splitter from the layer.")
        del_sp_btn_row.addWidget(btn_delete_sp)
        del_sp_btn_row.addStretch()
        del_sp_vbox.addLayout(del_sp_btn_row)
        ns_layout.addWidget(del_sp_box)

        combo_del_sp.currentIndexChanged.connect(
            lambda idx: btn_delete_sp.setEnabled(idx > 0))

        # Auto-populate combo when a splitter is selected on the map
        def _on_splitter_selection_changed():
            if not splitter_layer or combo_del_sp.currentIndex() > 0:
                return  # Don't override user's manual selection
            _sel = splitter_layer.selectedFeatures()
            if len(_sel) == 1:
                _sel_feat = _sel[0]
                try:
                    _sel_gid = _sel_feat['group_id']
                except Exception:
                    _sel_gid = None
                if _sel_gid is not None:
                    # Find matching index in combo
                    for _i, _sd in enumerate(splitter_data):
                        if _sd['group_id'] == _sel_gid:
                            combo_del_sp.setCurrentIndex(_i + 1)  # +1 for placeholder
                            status_lbl.setText(
                                f"<font color='blue'>Splitter Group {_sel_gid} selected — "
                                f"click Delete to remove.</font>")
                            break
        
        splitter_layer.selectionChanged.connect(_on_splitter_selection_changed)

        def _do_delete_splitter():
            _idx = combo_del_sp.currentIndex() - 1   # offset for placeholder
            if _idx < 0 or _idx >= len(splitter_data):
                status_lbl.setText("<font color='red'>Select a splitter to delete.</font>")
                return
            _victim = splitter_data[_idx]
            _victim_gid = _victim['group_id']
            _victim_fid = _victim['fid']

            # --- 1. Delete feature from splitter layer ----------------------
            splitter_layer.startEditing()
            if not splitter_layer.deleteFeature(_victim_fid):
                splitter_layer.rollBack()
                status_lbl.setText(
                    f"<font color='red'>Failed to delete splitter FID {_victim_fid}.</font>")
                return
            splitter_layer.commitChanges()

            # Remove from in-memory list
            splitter_data.pop(_idx)

            # --- 2. Unlink demand points belonging to deleted splitter --------
            if _dem_layer and _dp_link:
                _dp_fnames = [f.name() for f in _dem_layer.fields()]
                _dp_grp_idx = _dem_layer.fields().indexFromName(_dp_link)
                if _dp_grp_idx >= 0:
                    _dem_layer.startEditing()
                    for _df in _dem_layer.getFeatures():
                        if _df[_dp_link] == _victim_gid:
                            _dem_layer.changeAttributeValue(_df.id(), _dp_grp_idx, 0)
                    _dem_layer.commitChanges()
                # Update in-memory demand_data
                for _de in demand_data:
                    if _de['group_id'] == _victim_gid:
                        _de['group_id'] = 0

            # --- 3. Optional renumber ----------------------------------------
            _old_to_new = {}   # old group_id → new group_id
            if chk_renumber.isChecked() and splitter_data:
                # Sort by current group_id so order is preserved
                splitter_data.sort(key=lambda s: s['group_id'])
                _sp_fnames = [f.name() for f in splitter_layer.fields()]
                splitter_layer.startEditing()
                for _new_num, _sd in enumerate(splitter_data, start=1):
                    _old_gid = _sd['group_id']
                    if _old_gid == _new_num:
                        continue  # no change needed
                    _old_to_new[_old_gid] = _new_num
                    if 'fid'      in _sp_fnames:
                        splitter_layer.changeAttributeValue(
                            _sd['fid'], _sp_fnames.index('fid'), _new_num)
                    if 'ID'       in _sp_fnames:
                        splitter_layer.changeAttributeValue(
                            _sd['fid'], _sp_fnames.index('ID'), str(_new_num))
                    if 'group_id' in _sp_fnames:
                        splitter_layer.changeAttributeValue(
                            _sd['fid'], _sp_fnames.index('group_id'), _new_num)
                    _sd['group_id'] = _new_num
                splitter_layer.commitChanges()

                # Cascade renumber to demand points
                if _old_to_new and _dem_layer and _dp_link:
                    _dp_grp_idx2 = _dem_layer.fields().indexFromName(_dp_link)
                    if _dp_grp_idx2 >= 0:
                        _dem_layer.startEditing()
                        for _df in _dem_layer.getFeatures():
                            try:
                                _og = int(_df[_dp_link])  # explicit int() to avoid QVariant mismatch
                            except (TypeError, ValueError):
                                continue
                            if _og in _old_to_new:
                                _dem_layer.changeAttributeValue(
                                    _df.id(), _dp_grp_idx2, _old_to_new[_og])
                        _dem_layer.commitChanges()
                    # Update in-memory demand_data
                    for _de in demand_data:
                        if _de['group_id'] in _old_to_new:
                            _de['group_id'] = _old_to_new[_de['group_id']]

            # Refresh accumulator renderer after delete/renumber
            _accum_sp_d = getattr(self, '_pon_accum_splitters', None)
            try:
                import sip as _sip4
                if _accum_sp_d and not _sip4.isdeleted(_accum_sp_d) and splitter_layer is _accum_sp_d:
                    self._pon_refresh_accum_renderers()
                else:
                    splitter_layer.triggerRepaint()
                    if _dem_layer:
                        _dem_layer.triggerRepaint()
            except Exception:
                splitter_layer.triggerRepaint()
                if _dem_layer:
                    _dem_layer.triggerRepaint()

            # --- 4. Rebuild UI lists / combos ---------------------------------
            # list_widget (Tab 0)
            list_widget.clear()
            for _sd in splitter_data:
                list_widget.addItem(
                    f"Group {_sd['group_id']}   |   Zone {_sd['zone_id']}   |   {_sd['drop_count']} drops")

            # combo_target (Demand Points tab)
            if combo_target:
                combo_target.clear()
                for _sd in splitter_data:
                    combo_target.addItem(
                        f"Group {_sd['group_id']}  |  Zone {_sd['zone_id']}  |  {_sd['drop_count']} drops")

            # combo_add_dp_grp (Add New Demand Point)
            if combo_add_dp_grp:
                combo_add_dp_grp.clear()
                combo_add_dp_grp.addItem("— Select splitter —")
                for _sd in splitter_data:
                    combo_add_dp_grp.addItem(
                        f"Group {_sd['group_id']}  |  Zone {_sd['zone_id']}  |  {_sd['drop_count']} drops")

            # dem_list (Demand Points tab)
            if dem_list:
                dem_list.clear()
                for _de in demand_data:
                    dem_list.addItem(
                        f"DP {_de['fid']}   |   Group {_de['group_id']}   |   Zone {_de['zone_id']}")

            # Rebuild this combo too
            combo_del_sp.blockSignals(True)
            combo_del_sp.clear()
            combo_del_sp.addItem("— Select splitter to delete —")
            for _sd in splitter_data:
                combo_del_sp.addItem(
                    f"Group {_sd['group_id']}  |  Zone {_sd['zone_id']}  |  {_sd['drop_count']} drops")
            combo_del_sp.setCurrentIndex(0)
            combo_del_sp.blockSignals(False)
            btn_delete_sp.setEnabled(False)

            _rn_msg = " All splitters renumbered." if chk_renumber.isChecked() and _old_to_new else ""
            status_lbl.setText(
                f"<font color='green'><b>✓ Splitter Group {_victim_gid} deleted.</b>"
                f"{_rn_msg} Regenerating drops…</font>")
            _regen_drops()
            status_lbl.setText(
                f"<font color='green'>Splitter Group {_victim_gid} deleted and drops regenerated.</font>")

        btn_delete_sp.clicked.connect(_do_delete_splitter)

        tab_widget.addTab(tab_ns, "Splitters")

        # ----------------------------------------------------------------
        # Polygon-select map tool — used on the Demand Points tab
        # ----------------------------------------------------------------
        from qgis.gui import QgsMapTool as _QMTBase
        from qgis.core import QgsWkbTypes as _WKB
        from qgis.PyQt.QtCore import Qt as _Qt3

        class _PolySelectDemandTool(_QMTBase):
            """Left-click to add polygon vertices; right-click to close and select
            all demand points that fall inside the drawn polygon."""

            def __init__(self, canvas, demand_data, dem_list, status_lbl, layer_crs):
                super().__init__(canvas)
                self._demand_data = demand_data
                self._dem_list    = dem_list
                self._status      = status_lbl
                self._layer_crs   = layer_crs
                self._vertices    = []   # confirmed vertices in layer CRS
                from qgis.gui import QgsRubberBand
                from qgis.PyQt.QtGui import QColor
                self._rb = QgsRubberBand(canvas, _WKB.PolygonGeometry)
                self._rb.setColor(QColor(0, 120, 215, 200))
                self._rb.setFillColor(QColor(0, 120, 215, 40))
                self._rb.setWidth(2)

            def canvasPressEvent(self, e):
                from qgis.core import QgsCoordinateTransform, QgsProject
                if e.button() == _Qt3.LeftButton:
                    canvas_pt = self.toMapCoordinates(e.pos())
                    xform = QgsCoordinateTransform(
                        QgsProject.instance().crs(), self._layer_crs, QgsProject.instance())
                    try:
                        layer_pt = xform.transform(canvas_pt)
                    except Exception:
                        layer_pt = canvas_pt
                    self._vertices.append(layer_pt)
                    if len(self._vertices) == 1:
                        # First vertex: add a confirmed point + a live "preview" duplicate
                        self._rb.addPoint(canvas_pt)
                        self._rb.addPoint(canvas_pt)
                    else:
                        # Confirm the live point, then start a new live point at same position
                        self._rb.movePoint(canvas_pt)
                        self._rb.addPoint(canvas_pt)
                    n = len(self._vertices)
                    self._status.setText(
                        f"<font color='blue'>Polygon: {n} vertex/vertices — "
                        f"left-click to add more, right-click to finish.</font>")
                elif e.button() == _Qt3.RightButton:
                    self._finish_selection()

            def canvasMoveEvent(self, e):
                if not self._vertices:
                    return
                # Move the live "preview" point to track the cursor
                self._rb.movePoint(self.toMapCoordinates(e.pos()))

            def _finish_selection(self):
                from qgis.core import QgsGeometry, QgsPointXY
                if len(self._vertices) < 3:
                    self._status.setText(
                        "<font color='red'>Need at least 3 vertices to close the polygon. "
                        "Keep left-clicking to add more points.</font>")
                    return
                poly = QgsGeometry.fromPolygonXY([self._vertices + [self._vertices[0]]])
                matched = []
                for i, dd in enumerate(self._demand_data):
                    pt_geom = QgsGeometry.fromPointXY(QgsPointXY(dd['x'], dd['y']))
                    if poly.contains(pt_geom):
                        matched.append(i)
                for i in matched:
                    self._dem_list.item(i).setSelected(True)
                n_sel = len(self._dem_list.selectedItems())
                self._status.setText(
                    f"<font color='green'><b>{len(matched)} demand point(s) added to selection</b> "
                    f"({n_sel} total selected). "
                    f"Draw another polygon or click Apply to reassign.</font>")
                self._reset()

            def _reset(self):
                self._vertices.clear()
                self._rb.reset(_WKB.PolygonGeometry)

            def deactivate(self):
                self._reset()
                super().deactivate()

        # ----------------------------------------------------------------
        # Shared status + close
        # ----------------------------------------------------------------
        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setFrameShadow(QFrame.Shadow.Sunken)
        layout.addWidget(sep)

        status_lbl = QLabel("Switch tabs to work with splitters or demand points.")
        status_lbl.setWordWrap(True)
        layout.addWidget(status_lbl)

        btn_close = QPushButton("Close")
        layout.addWidget(btn_close)

        # ================================================================
        # Undo stack
        # ================================================================
        _undo_stack = []   # max 10 entries; each is a snapshot dict

        def _enable_undo():
            btn_undo_sp.setEnabled(True)
            if btn_undo_dp:
                btn_undo_dp.setEnabled(True)

        def _disable_undo():
            btn_undo_sp.setEnabled(False)
            if btn_undo_dp:
                btn_undo_dp.setEnabled(False)

        def undo_last():
            if not _undo_stack:
                return
            snap = _undo_stack.pop()

            # 1. Restore attributes — group ops by layer to batch editing sessions
            _by_lyr = {}
            for (lyr, fid, fidx, oval) in snap.get('attr_ops', []):
                _lid = id(lyr)
                if _lid not in _by_lyr:
                    _by_lyr[_lid] = (lyr, [])
                _by_lyr[_lid][1].append((fid, fidx, oval))
            for _lid, (lyr, ops) in _by_lyr.items():
                lyr.startEditing()
                for fid, fidx, oval in ops:
                    lyr.changeAttributeValue(fid, fidx, oval)
                lyr.commitChanges()
                lyr.triggerRepaint()

            # 2. Restore geometries
            _by_lyr_g = {}
            for (lyr, fid, ogeom) in snap.get('geom_ops', []):
                _lid = id(lyr)
                if _lid not in _by_lyr_g:
                    _by_lyr_g[_lid] = (lyr, [])
                _by_lyr_g[_lid][1].append((fid, ogeom))
            for _lid, (lyr, ops) in _by_lyr_g.items():
                lyr.startEditing()
                for fid, ogeom in ops:
                    lyr.changeGeometry(fid, ogeom)
                lyr.commitChanges()
                lyr.triggerRepaint()

            # 3. Re-add features that were deleted by apply (e.g. empty PON zone polygons)
            for (lyr, feats) in snap.get('del_feats', []):
                lyr.startEditing()
                lyr.addFeatures(feats)
                lyr.commitChanges()
                lyr.triggerRepaint()

            # 4. Delete PON zone polygons that were newly created by apply
            _pon_lyr = snap.get('pon_lyr')
            for _nzid in snap.get('add_zone_ids', []):
                if _pon_lyr:
                    _fids_del = [_f.id() for _f in _pon_lyr.getFeatures()
                                 if _f['zone_id'] == _nzid]
                    if _fids_del:
                        _pon_lyr.startEditing()
                        _pon_lyr.deleteFeatures(_fids_del)
                        _pon_lyr.commitChanges()
                        _pon_lyr.triggerRepaint()

            # 5. Restore in-memory data dicts
            for (d, key, oval) in snap.get('mem_ops', []):
                d[key] = oval

            # 6. Restore list widget labels
            for (lw, idx, otxt) in snap.get('list_ops', []):
                lw.item(idx).setText(otxt)

            # 7. Restore combo labels
            for (cb, idx, otxt) in snap.get('combo_ops', []):
                cb.setItemText(idx, otxt)

            if not _undo_stack:
                _disable_undo()

            status_lbl.setText(
                f"<font color='orange'><b>Undone:</b> {snap['desc']}</font>")
            self.log_message(f"Undo: {snap['desc']}")

        # ================================================================
        # Splitter tab helpers
        # ================================================================
        def refresh_summary():
            sel_rows = [list_widget.row(it) for it in list_widget.selectedItems()]
            if not sel_rows:
                lbl_sel_count.setText("0")
                lbl_sel_zones.setText("—")
                lbl_sel_drops.setText("0")
                return
            zones = sorted({splitter_data[i]['zone_id'] for i in sel_rows})
            total_drops = sum(splitter_data[i]['drop_count'] for i in sel_rows)
            lbl_sel_count.setText(str(len(sel_rows)))
            lbl_sel_zones.setText(", ".join(str(z) for z in zones))
            lbl_sel_drops.setText(str(total_drops))
            if len(zones) == 1:
                spin.setValue(zones[0])

        list_widget.itemSelectionChanged.connect(refresh_summary)
        btn_select_all.clicked.connect(list_widget.selectAll)
        btn_clear_sel.clicked.connect(list_widget.clearSelection)

        def _zoom_to_selected_splitters():
            sel_rows = [list_widget.row(it) for it in list_widget.selectedItems()]
            if not sel_rows:
                return
            sel_fids = [splitter_data[i]['fid'] for i in sel_rows]
            from qgis.core import QgsRectangle, QgsCoordinateTransform, QgsProject, QgsPointXY
            canvas = self.iface.mapCanvas()
            canvas_crs = canvas.mapSettings().destinationCrs()
            layer_crs = splitter_layer.crs()
            xform = QgsCoordinateTransform(layer_crs, canvas_crs, QgsProject.instance())

            # Collect splitter points + their group_ids
            sel_group_ids = []
            pts = []
            for feat in splitter_layer.getFeatures():
                if feat.id() not in sel_fids:
                    continue
                g = feat.geometry()
                if g and not g.isEmpty():
                    g_clone = QgsGeometry(g)
                    g_clone.transform(xform)
                    pts.append(g_clone.centroid().asPoint())
                gid = feat['group_id']
                if gid is not None:
                    sel_group_ids.append(int(gid))

            if not pts:
                return

            # Highlight splitter points
            splitter_layer.selectByIds(sel_fids)

            # Highlight matching drop cables in any drop layer
            for lyr in QgsProject.instance().mapLayers().values():
                from qgis.core import QgsVectorLayer
                if not isinstance(lyr, QgsVectorLayer):
                    continue
                lname = lyr.name().lower()
                if 'drop cable' not in lname and 'drop_cable' not in lname:
                    continue
                if 'group_id' not in [f.name() for f in lyr.fields()]:
                    continue
                drop_fids = [
                    f.id() for f in lyr.getFeatures()
                    if f['group_id'] is not None and int(f['group_id']) in sel_group_ids
                ]
                lyr.selectByIds(drop_fids)

            # Zoom to centroid of all selected points at a fixed 1:1000 scale
            cx = sum(p.x() for p in pts) / len(pts)
            cy = sum(p.y() for p in pts) / len(pts)
            canvas.zoomByFactor(1.0)  # no-op, just ensures renderer is ready
            # If multiple splitters span a wide area, fit them all; otherwise use 1:1000
            bbox = QgsRectangle(pts[0].x(), pts[0].y(), pts[0].x(), pts[0].y())
            for p in pts[1:]:
                bbox.combineExtentWith(QgsRectangle(p.x(), p.y(), p.x(), p.y()))
            span = max(bbox.width(), bbox.height())
            if span > 0:
                # Multiple spread-out points — fit with 30% margin
                bbox.grow(span * 0.3)
                canvas.setExtent(bbox)
            else:
                # Single point (or all same location) — centre and set 1:1000 scale
                canvas.setCenter(QgsPointXY(cx, cy))
                canvas.zoomScale(1000)
            canvas.refresh()

        btn_zoom_sel.clicked.connect(_zoom_to_selected_splitters)

        # ================================================================
        # Demand tab helpers
        # ================================================================
        if demand_data and dem_list:
            def refresh_dp_summary():
                sel_rows = [dem_list.row(it) for it in dem_list.selectedItems()]
                if not sel_rows:
                    lbl_dp_count.setText("0")
                    lbl_dp_groups.setText("—")
                    return
                groups = sorted({demand_data[i]['group_id'] for i in sel_rows})
                lbl_dp_count.setText(str(len(sel_rows)))
                lbl_dp_groups.setText(", ".join(str(g) for g in groups))

            dem_list.itemSelectionChanged.connect(refresh_dp_summary)
            btn_dp_select_all.clicked.connect(dem_list.selectAll)
            btn_dp_clear_sel.clicked.connect(dem_list.clearSelection)

        # ---- Apply change (batch over all selected splitters) ----
        def apply_change():
            sel_rows = [list_widget.row(it) for it in list_widget.selectedItems()]
            if not sel_rows:
                status_lbl.setText("No splitters selected.")
                return

            new_zone  = spin.value()
            to_change = [splitter_data[i] for i in sel_rows
                         if splitter_data[i]['zone_id'] != new_zone]
            if not to_change:
                status_lbl.setText("No change — all selected splitters are already in that zone.")
                return

            # Net drops leaving each old zone (may span multiple old zones)
            old_zones_delta = {}   # {old_zone_id: total drops moving out}
            for sd in to_change:
                oz = sd['zone_id']
                old_zones_delta[oz] = old_zones_delta.get(oz, 0) + sd['drop_count']
            new_zone_gain = sum(sd['drop_count'] for sd in to_change)
            changing_groups = {sd['group_id'] for sd in to_change}

            # ---- Snapshot for undo ----
            _snap = {
                'desc':         f"{len(to_change)} splitter(s) → Zone {new_zone}",
                'attr_ops':     [],
                'geom_ops':     [],
                'del_feats':    [],
                'add_zone_ids': [],
                'pon_lyr':      None,
                'mem_ops':      [],
                'list_ops':     [],
                'combo_ops':    [],
            }
            # Splitter attributes
            _zi_s = splitter_layer.fields().indexFromName('zone_id')
            for _sf in splitter_layer.getFeatures():
                if _sf['group_id'] in changing_groups:
                    _snap['attr_ops'].append((splitter_layer, _sf.id(), _zi_s, _sf['zone_id']))
            # In-memory splitter_data + list labels
            for sd in to_change:
                _si = splitter_data.index(sd)
                _snap['mem_ops'].append((sd, 'zone_id', sd['zone_id']))
                _snap['list_ops'].append((list_widget, _si, list_widget.item(_si).text()))
            # Limit stack depth
            if len(_undo_stack) >= 10:
                _undo_stack.pop(0)

            results = []
            _link = None   # group link field name on demand / grouped layer

            # 1. Update splitter points (one editing session for all)
            _zi = splitter_layer.fields().indexFromName('zone_id')
            splitter_layer.startEditing()
            for sd in to_change:
                splitter_layer.changeAttributeValue(sd['fid'], _zi, new_zone)
            splitter_layer.commitChanges()
            # Rebuild accumulator renderer if needed, else just repaint
            _accum_sp_z = getattr(self, '_pon_accum_splitters', None)
            try:
                import sip as _sip5
                if _accum_sp_z and not _sip5.isdeleted(_accum_sp_z) and splitter_layer is _accum_sp_z:
                    self._pon_refresh_accum_renderers()
                else:
                    splitter_layer.triggerRepaint()
            except Exception:
                splitter_layer.triggerRepaint()
            results.append(f"Splitter Points — {len(to_change)} splitter(s)")

            # 2. Update demand points
            _dem_layer = None
            _zone_fld = None   # kept in outer scope for step 4
            try:
                if self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                    _dem_layer = self.demand_points_layer
            except Exception:
                pass
            if not _dem_layer:
                for _lyr in QgsProject.instance().mapLayers().values():
                    if isinstance(_lyr, QgsVectorLayer):
                        _ln = _lyr.name().lower()
                        if 'demand points' in _ln or 'demand_points' in _ln:
                            _dem_layer = _lyr
                            break
            if _dem_layer:
                _dfnames = [f.name() for f in _dem_layer.fields()]
                _link = next((fn for fn in ['group_8', 'group_16', 'group_128', 'group_100', 'batch_id']
                               if fn in _dfnames), None)
                _zone_fld = next((fn for fn in ['zone_id', 'group_100']  # sets outer _zone_fld
                                   if fn in _dfnames and fn != _link), None)
                if _link and _zone_fld:
                    _dzi = _dem_layer.fields().indexFromName(_zone_fld)
                    _zni = _dem_layer.fields().indexFromName('zone_name') if 'zone_name' in _dfnames else -1
                    # Snapshot demand points before editing
                    for _f in _dem_layer.getFeatures():
                        if _f[_link] in changing_groups:
                            _snap['attr_ops'].append((_dem_layer, _f.id(), _dzi, _f[_zone_fld]))
                            if _zni >= 0:
                                _snap['attr_ops'].append((_dem_layer, _f.id(), _zni, _f['zone_name']))
                    _dem_layer.startEditing()
                    _upd = 0
                    for _f in _dem_layer.getFeatures():
                        if _f[_link] in changing_groups:
                            _dem_layer.changeAttributeValue(_f.id(), _dzi, new_zone)
                            if _zni >= 0:
                                _dem_layer.changeAttributeValue(_f.id(), _zni, f"Zone {new_zone}")
                            _upd += 1
                    _dem_layer.commitChanges()
                    _dem_layer.triggerRepaint()
                    results.append(f"Demand Points — {_upd} feature(s)")

            # 2b. Keep grouped_layer (parcels) in sync — it's a separate layer from demand_points_layer
            _grp_lyr = getattr(self, 'grouped_layer', None)
            try:
                _grp_deleted = sip.isdeleted(_grp_lyr) if _grp_lyr else True
            except Exception:
                _grp_deleted = True
            if _grp_lyr and not _grp_deleted and _grp_lyr != _dem_layer:
                _grp_fnames = [f.name() for f in _grp_lyr.fields()]
                _grp_link = next((fn for fn in ['group_8', 'group_16', 'group_128', 'group_100', 'batch_id']
                                   if fn in _grp_fnames), None)
                _grp_zi  = _grp_lyr.fields().indexFromName('zone_id')  if 'zone_id'   in _grp_fnames else -1
                _grp_zni = _grp_lyr.fields().indexFromName('zone_name') if 'zone_name' in _grp_fnames else -1
                if _grp_link and _grp_zi >= 0:
                    # Snapshot grouped layer before editing
                    for _f in _grp_lyr.getFeatures():
                        if _f[_grp_link] in changing_groups:
                            _snap['attr_ops'].append((_grp_lyr, _f.id(), _grp_zi, _f['zone_id']))
                            if _grp_zni >= 0:
                                _snap['attr_ops'].append((_grp_lyr, _f.id(), _grp_zni, _f['zone_name']))
                    _grp_lyr.startEditing()
                    _grp_upd = 0
                    for _f in _grp_lyr.getFeatures():
                        if _f[_grp_link] in changing_groups:
                            _grp_lyr.changeAttributeValue(_f.id(), _grp_zi, new_zone)
                            if _grp_zni >= 0:
                                _grp_lyr.changeAttributeValue(_f.id(), _grp_zni, f"Zone {new_zone}")
                            _grp_upd += 1
                    _grp_lyr.commitChanges()
                    _grp_lyr.triggerRepaint()
                    if _grp_upd:
                        results.append(f"Grouped Layer — {_grp_upd} feature(s)")

            # 3. Update drop cable layers
            for _dc_name in ("Drop Cables Lashed", "Drop Cables PTP"):
                for _lyr in QgsProject.instance().mapLayers().values():
                    if isinstance(_lyr, QgsVectorLayer) and _lyr.name() == _dc_name:
                        _dc_fnames = [f.name() for f in _lyr.fields()]
                        if 'zone_id' in _dc_fnames and 'group_id' in _dc_fnames:
                            _dczi = _lyr.fields().indexFromName('zone_id')
                            # Snapshot drop cables before editing
                            for _f in _lyr.getFeatures():
                                if _f['group_id'] in changing_groups:
                                    _snap['attr_ops'].append((_lyr, _f.id(), _dczi, _f['zone_id']))
                            _lyr.startEditing()
                            _upd_dc = 0
                            for _f in _lyr.getFeatures():
                                if _f['group_id'] in changing_groups:
                                    _lyr.changeAttributeValue(_f.id(), _dczi, new_zone)
                                    _upd_dc += 1
                            _lyr.commitChanges()
                            _lyr.triggerRepaint()
                            if _upd_dc:
                                results.append(f"{_dc_name} — {_upd_dc} cable(s)")
                        break

            # 4. Update PON Zone boundaries — unit_count + regenerate polygon geometry
            # Use group link field + splitter_data zone mapping to find demand features per zone.
            # This avoids relying on zone_id field being present or type-consistent on the demand layer.
            _src_lyr  = None   # source point layer for polygon building
            _src_link = None   # group link field name on _src_lyr
            if _dem_layer and _link:
                _src_lyr  = _dem_layer
                _src_link = _link
            else:
                _grp_cand = getattr(self, 'grouped_layer', None)
                try:
                    if _grp_cand and not sip.isdeleted(_grp_cand):
                        _gcnames = [f.name() for f in _grp_cand.fields()]
                        _src_link = next((fn for fn in ['group_8', 'group_16', 'group_128',
                                                        'group_100', 'batch_id']
                                          if fn in _gcnames), None)
                        if _src_link:
                            _src_lyr = _grp_cand
                except Exception:
                    pass

            # Zone → set-of-group_ids mapping from splitter_data (PRE-move state)
            _z2g = {}
            for _sd in splitter_data:
                _z2g.setdefault(int(_sd['zone_id']), set()).add(_sd['group_id'])

            for _lyr in QgsProject.instance().mapLayers().values():
                _lname_zs = _lyr.name() if hasattr(_lyr, 'name') else ''
                if isinstance(_lyr, QgsVectorLayer) and (
                        'PON Zone Boundaries' in _lname_zs or 'PON Zones' in _lname_zs):
                    _b_fnames = [f.name() for f in _lyr.fields()]
                    if 'zone_id' in _b_fnames and 'unit_count' in _b_fnames:
                        _snap['pon_lyr'] = _lyr
                        _uc_idx = _lyr.fields().indexFromName('unit_count')
                        # Snapshot PON zone features BEFORE editing
                        for _f in _lyr.getFeatures():
                            _fzid = int(_f['zone_id']) if _f['zone_id'] is not None else -1
                            if _fzid in old_zones_delta:
                                _n_out = old_zones_delta[_fzid]
                                _will_empty = max(0, (_f['unit_count'] or 0) - _n_out) == 0
                                if _will_empty:
                                    # Will be deleted — save full copy to restore on undo
                                    from qgis.core import QgsFeature as _QFsnap
                                    _snap['del_feats'].append((_lyr, [_QFsnap(_f)]))
                                else:
                                    _snap['attr_ops'].append((_lyr, _f.id(), _uc_idx, _f['unit_count']))
                                    _snap['geom_ops'].append((_lyr, _f.id(), QgsGeometry(_f.geometry())))
                            elif _fzid == new_zone:
                                _snap['attr_ops'].append((_lyr, _f.id(), _uc_idx, _f['unit_count']))
                                _snap['geom_ops'].append((_lyr, _f.id(), QgsGeometry(_f.geometry())))
                        _lyr.startEditing()
                        _b_upd = []
                        _new_zone_found = False
                        _fids_to_delete = []
                        for _f in _lyr.getFeatures():
                            _fzid = int(_f['zone_id']) if _f['zone_id'] is not None else -1
                            if _fzid in old_zones_delta:
                                _n_out = old_zones_delta[_fzid]
                                _new_uc = max(0, (_f['unit_count'] or 0) - _n_out)
                                _b_upd.append(f"Zone {_fzid}: {(_f['unit_count'] or 0)} → {_new_uc}")
                                if _new_uc == 0:
                                    # Zone is now empty — delete the polygon
                                    _fids_to_delete.append(_f.id())
                                else:
                                    _lyr.changeAttributeValue(_f.id(), _uc_idx, _new_uc)
                                    if _src_lyr and _src_link:
                                        # Remaining groups in old zone = zone's groups minus those moving out
                                        _rem_grps = _z2g.get(int(_fzid), set()) - changing_groups
                                        _oz_feats = [_ff for _ff in _src_lyr.getFeatures()
                                                     if _ff[_src_link] in _rem_grps]
                                        if _oz_feats:
                                            _oz_geom = self._build_zone_polygon(_src_lyr, _oz_feats)
                                            if not _oz_geom.isEmpty():
                                                _lyr.changeGeometry(_f.id(), _oz_geom)
                            elif int(_fzid) == new_zone:
                                _new_zone_found = True
                                _new_uc = (_f['unit_count'] or 0) + new_zone_gain
                                _lyr.changeAttributeValue(_f.id(), _uc_idx, _new_uc)
                                _b_upd.append(f"Zone {new_zone}: {(_f['unit_count'] or 0)} → {_new_uc}")
                                if _src_lyr and _src_link:
                                    # New zone groups = original new zone groups + moving groups
                                    _new_grps = _z2g.get(new_zone, set()) | changing_groups
                                    _nz_feats = [_ff for _ff in _src_lyr.getFeatures()
                                                 if _ff[_src_link] in _new_grps]
                                    if _nz_feats:
                                        _nz_geom = self._build_zone_polygon(_src_lyr, _nz_feats)
                                        if not _nz_geom.isEmpty():
                                            _lyr.changeGeometry(_f.id(), _nz_geom)
                        if _fids_to_delete:
                            _lyr.deleteFeatures(_fids_to_delete)
                            _b_upd.append(f"Removed {len(_fids_to_delete)} empty zone polygon(s)")
                        # Create a new boundary polygon if new_zone has no existing feature
                        if not _new_zone_found and _src_lyr and _src_link:
                            _new_grps = _z2g.get(new_zone, set()) | changing_groups
                            _nz_feats = [_ff for _ff in _src_lyr.getFeatures()
                                         if _ff[_src_link] in _new_grps]
                            if _nz_feats:
                                _nz_geom = self._build_zone_polygon(_src_lyr, _nz_feats)
                                if not _nz_geom.isEmpty():
                                    from qgis.core import QgsFeature as _QF
                                    _new_feat = _QF(_lyr.fields())
                                    _new_feat.setGeometry(_nz_geom)
                                    _new_feat['zone_id']    = new_zone
                                    _new_feat['zone_name']  = f"Zone {new_zone}"
                                    _new_feat['unit_count'] = new_zone_gain
                                    _lyr.addFeature(_new_feat)
                                    _snap['add_zone_ids'].append(new_zone)
                                    _b_upd.append(f"Zone {new_zone}: (new) {new_zone_gain}")
                        _lyr.commitChanges()
                        _lyr.triggerRepaint()
                        if _b_upd:
                            results.append(f"PON Zone Boundaries — {'; '.join(_b_upd)}")
                    break

            # Update local splitter_data and list item labels
            for sd in to_change:
                _i = splitter_data.index(sd)
                sd['zone_id'] = new_zone
                list_widget.item(_i).setText(
                    f"Group {sd['group_id']}   |   Zone {new_zone}   |   {sd['drop_count']} drops")
            # Auto-deselect after successful apply
            list_widget.clearSelection()
            refresh_summary()

            # Push snapshot to undo stack
            _undo_stack.append(_snap)
            _enable_undo()

            _old_str = ", ".join(f"Zone {z}" for z in sorted(old_zones_delta))
            _summary = "<br>".join(results)
            status_lbl.setText(
                f"<font color='green'><b>Done:</b> {len(to_change)} splitter(s): "
                f"{_old_str} → Zone {new_zone}<br>{_summary}<br>Regenerating drop cables…</font>")
            self.log_message(f"Manual Override: {len(to_change)} splitter(s) → Zone {new_zone}")
            for _r in results:
                self.log_message(f"  {_r}")
            # Regenerate drop cables so zone_id on cables matches the new assignment
            _regen_drops()
            status_lbl.setText(
                f"<font color='green'><b>Done:</b> {len(to_change)} splitter(s): "
                f"{_old_str} → Zone {new_zone} — drops regenerated.</font>")

        # ================================================================
        # Demand reassignment apply
        # ================================================================
        def apply_demand_change():
            if not (demand_data and dem_list and combo_target):
                return
            sel_rows = [dem_list.row(it) for it in dem_list.selectedItems()]
            if not sel_rows:
                status_lbl.setText("No demand points selected.")
                return

            # Resolve target: spin_grp takes priority if it matches a known splitter,
            # otherwise fall back to combo selection.
            _manual_gid = spin_grp.value()
            tgt_sd = next((sd for sd in splitter_data if sd['group_id'] == _manual_gid), None)
            if tgt_sd is None:
                tgt_sd = splitter_data[combo_target.currentIndex()]
            new_grp  = tgt_sd['group_id']
            new_zone = tgt_sd['zone_id']

            # Collect only those that actually change
            moves = [(demand_data[r], demand_data[r]['group_id'], demand_data[r]['zone_id'], r)
                     for r in sel_rows if demand_data[r]['group_id'] != new_grp]
            if not moves:
                status_lbl.setText("No change — all selected demand points are already in that group.")
                dem_list.clearSelection()
                return

            # ---- Snapshot for undo ----
            _snap_dp = {
                'desc':         f"{len(moves)} demand point(s) → Group {new_grp} / Zone {new_zone}",
                'attr_ops':     [],
                'geom_ops':     [],
                'del_feats':    [],
                'add_zone_ids': [],
                'pon_lyr':      None,
                'mem_ops':      [],
                'list_ops':     [],
                'combo_ops':    [],
            }
            # Demand point attributes
            _link_idx_s = _dem_layer.fields().indexFromName(_dp_link)
            for dd, old_g, old_z, row in moves:
                _snap_dp['attr_ops'].append((_dem_layer, dd['fid'], _link_idx_s, old_g))
                if _dp_zi >= 0:
                    _snap_dp['attr_ops'].append((_dem_layer, dd['fid'], _dp_zi, old_z))
                if _dp_zni >= 0:
                    _f_tmp = next((_ff for _ff in _dem_layer.getFeatures()
                                   if _ff.id() == dd['fid']), None)
                    if _f_tmp:
                        _snap_dp['attr_ops'].append((_dem_layer, dd['fid'], _dp_zni,
                                                     _f_tmp['zone_name']))
                _snap_dp['mem_ops'].append((dd, 'group_id', dd['group_id']))
                _snap_dp['mem_ops'].append((dd, 'zone_id',  dd['zone_id']))
                _snap_dp['list_ops'].append((dem_list, row, dem_list.item(row).text()))
            # Splitter drop_count
            _old_grps_dp = {dd['group_id'] for dd, _, _, _ in moves}
            _dc_idx_s = splitter_layer.fields().indexFromName('drop_count') \
                if 'drop_count' in sp_field_names else -1
            if _dc_idx_s >= 0:
                for _spf in splitter_layer.getFeatures():
                    _sgid = _spf['group_id']
                    if _sgid in _old_grps_dp or _sgid == new_grp:
                        _snap_dp['attr_ops'].append((splitter_layer, _spf.id(), _dc_idx_s,
                                                     _spf['drop_count'] or 0))
                        for sd in splitter_data:
                            if sd['group_id'] == _sgid:
                                _si = splitter_data.index(sd)
                                _snap_dp['mem_ops'].append((sd, 'drop_count', sd['drop_count']))
                                _snap_dp['list_ops'].append((list_widget, _si,
                                                             list_widget.item(_si).text()))
                                _snap_dp['combo_ops'].append((combo_target, _si,
                                                              combo_target.itemText(_si)))
            # Limit stack depth
            if len(_undo_stack) >= 10:
                _undo_stack.pop(0)

            results_dp = []

            # 1. Update demand point attributes
            if not _dem_layer:
                status_lbl.setText("ERROR: Demand Points layer not accessible.")
                return
            _link_idx = _dem_layer.fields().indexFromName(_dp_link)
            _dem_layer.startEditing()
            for dd, old_g, old_z, row in moves:
                _dem_layer.changeAttributeValue(dd['fid'], _link_idx, new_grp)
                if _dp_zi >= 0:
                    _dem_layer.changeAttributeValue(dd['fid'], _dp_zi, new_zone)
                if _dp_zni >= 0:
                    _dem_layer.changeAttributeValue(dd['fid'], _dp_zni, f"Zone {new_zone}")
            _dem_layer.commitChanges()
            # Rebuild accumulator renderer if demand layer is PON Groups accum
            _accum_grp_r = getattr(self, '_pon_accum_groups', None)
            try:
                import sip as _sip_dm
                if _accum_grp_r and not _sip_dm.isdeleted(_accum_grp_r) and _dem_layer is _accum_grp_r:
                    self._pon_refresh_accum_renderers()
                else:
                    _dem_layer.triggerRepaint()
            except Exception:
                _dem_layer.triggerRepaint()
            results_dp.append(f"Demand Points — {len(moves)} updated")

            # 2. Update splitter drop_counts
            old_grp_delta = {}   # {old_group: count of points leaving}
            for dd, old_g, old_z, row in moves:
                old_grp_delta[old_g] = old_grp_delta.get(old_g, 0) + 1
            _dc_idx = splitter_layer.fields().indexFromName('drop_count') if 'drop_count' in sp_field_names else -1
            if _dc_idx >= 0:
                splitter_layer.startEditing()
                for _spf in splitter_layer.getFeatures():
                    _sgid = _spf['group_id']
                    if _sgid in old_grp_delta:
                        _new_dc = max(0, (_spf['drop_count'] or 0) - old_grp_delta[_sgid])
                        splitter_layer.changeAttributeValue(_spf.id(), _dc_idx, _new_dc)
                        for sd in splitter_data:
                            if sd['group_id'] == _sgid:
                                sd['drop_count'] = _new_dc
                    elif _sgid == new_grp:
                        _new_dc = (_spf['drop_count'] or 0) + len(moves)
                        splitter_layer.changeAttributeValue(_spf.id(), _dc_idx, _new_dc)
                        for sd in splitter_data:
                            if sd['group_id'] == new_grp:
                                sd['drop_count'] = _new_dc
                splitter_layer.commitChanges()
                # Rebuild accumulator renderer if splitter layer is PON Splitter Points accum
                _accum_sp_r = getattr(self, '_pon_accum_splitters', None)
                try:
                    import sip as _sip_sp
                    if _accum_sp_r and not _sip_sp.isdeleted(_accum_sp_r) and splitter_layer is _accum_sp_r:
                        self._pon_refresh_accum_renderers()
                    else:
                        splitter_layer.triggerRepaint()
                except Exception:
                    splitter_layer.triggerRepaint()
                results_dp.append("Splitter drop counts updated")
                # Refresh splitter list labels
                for i, sd in enumerate(splitter_data):
                    list_widget.item(i).setText(
                        f"Group {sd['group_id']}   |   Zone {sd['zone_id']}   |   {sd['drop_count']} drops")
                # Refresh target combo labels
                for i, sd in enumerate(splitter_data):
                    combo_target.setItemText(i,
                        f"Group {sd['group_id']}  |  Zone {sd['zone_id']}  |  {sd['drop_count']} drops")

            # 3. Update drop cable group_id + zone_id for moved demand points
            # demand_id field exists but is unpopulated; match by group_id only.
            # Match both single-run names and the PON accumulator "PON Drop Cables".
            _old_grps_moved = {dd['group_id'] for dd, _, _, _ in moves}
            _drop_lyrs_done = set()
            for _lyr in QgsProject.instance().mapLayers().values():
                if not isinstance(_lyr, QgsVectorLayer):
                    continue
                _lname = _lyr.name()
                if _lname in _drop_lyrs_done:
                    continue
                _is_drop = (_lname in ("Drop Cables Lashed", "Drop Cables PTP", "PON Drop Cables")
                            or 'drop cable' in _lname.lower())
                if not _is_drop:
                    continue
                _dc_fnames = [f.name() for f in _lyr.fields()]
                if 'zone_id' not in _dc_fnames or 'group_id' not in _dc_fnames:
                    continue
                _drop_lyrs_done.add(_lname)
                _dczi2 = _lyr.fields().indexFromName('zone_id')
                _dcgi2 = _lyr.fields().indexFromName('group_id')
                _lyr.startEditing()
                _upd_dc2 = 0
                for _f in _lyr.getFeatures():
                    if _f['group_id'] in _old_grps_moved:
                        _lyr.changeAttributeValue(_f.id(), _dcgi2, new_grp)
                        _lyr.changeAttributeValue(_f.id(), _dczi2, new_zone)
                        _upd_dc2 += 1
                _lyr.commitChanges()
                # Rebuild renderer if this is the drop cable accumulator
                _accum_dr = getattr(self, '_pon_accum_drops', None)
                try:
                    import sip as _sip_dc
                    if _accum_dr and not _sip_dc.isdeleted(_accum_dr) and _lyr is _accum_dr:
                        self._pon_refresh_accum_renderers()
                    else:
                        _lyr.triggerRepaint()
                except Exception:
                    _lyr.triggerRepaint()
                if _upd_dc2:
                    results_dp.append(f"{_lname} — {_upd_dc2} cable(s) updated")

            # 4. Update PON Zone boundaries using group link field + splitter_data zone mapping.
            # Works even if demand points have no zone_id field.
            affected_old_zones = {int(old_z) for _, _, old_z, _ in moves
                                  if old_z is not None and int(old_z) != new_zone}
            moved_fids = {dd['fid'] for dd, _, _, _ in moves}
            # Build zone → group_ids mapping from splitter_data (zone assignments unchanged by this op)
            _z2g_dp = {}
            for _sd in splitter_data:
                _z2g_dp.setdefault(int(_sd['zone_id']), set()).add(_sd['group_id'])

            for _lyr in QgsProject.instance().mapLayers().values():
                _lname_zdp = _lyr.name() if hasattr(_lyr, 'name') else ''
                if isinstance(_lyr, QgsVectorLayer) and (
                        'PON Zone Boundaries' in _lname_zdp or 'PON Zones' in _lname_zdp):
                    _b_fnames = [f.name() for f in _lyr.fields()]
                    if 'zone_id' in _b_fnames and 'unit_count' in _b_fnames:
                        _uc_idx2 = _lyr.fields().indexFromName('unit_count')
                        # Snapshot PON zones BEFORE editing
                        _snap_dp['pon_lyr'] = _lyr
                        for _f in _lyr.getFeatures():
                            _fzid2 = int(_f['zone_id']) if _f['zone_id'] is not None else -1
                            if _fzid2 in affected_old_zones:
                                # Check if zone will be empty after moves
                                _rem_grps2 = _z2g_dp.get(_fzid2, set())
                                _rem_feats_chk = [_ff for _ff in _dem_layer.getFeatures()
                                                  if _ff[_dp_link] in _rem_grps2
                                                  and _ff.id() not in moved_fids]
                                if len(_rem_feats_chk) == 0:
                                    from qgis.core import QgsFeature as _QFsnap2
                                    _snap_dp['del_feats'].append((_lyr, [_QFsnap2(_f)]))
                                else:
                                    _snap_dp['attr_ops'].append((_lyr, _f.id(), _uc_idx2,
                                                                 _f['unit_count'] or 0))
                                    _snap_dp['geom_ops'].append((_lyr, _f.id(),
                                                                 QgsGeometry(_f.geometry())))
                            elif _fzid2 == new_zone:
                                _snap_dp['attr_ops'].append((_lyr, _f.id(), _uc_idx2,
                                                             _f['unit_count'] or 0))
                                _snap_dp['geom_ops'].append((_lyr, _f.id(),
                                                             QgsGeometry(_f.geometry())))
                        _lyr.startEditing()
                        _new_zone_found2 = False
                        _fids_del2 = []
                        for _f in _lyr.getFeatures():
                            _fzid2 = int(_f['zone_id']) if _f['zone_id'] is not None else -1
                            if _fzid2 in affected_old_zones:
                                # Remaining demand: in this zone's groups, excluding moved fids
                                _rem_grps2 = _z2g_dp.get(_fzid2, set())
                                _rem_feats = [_ff for _ff in _dem_layer.getFeatures()
                                              if _ff[_dp_link] in _rem_grps2
                                              and _ff.id() not in moved_fids]
                                _new_uc = len(_rem_feats)
                                if _new_uc == 0:
                                    _fids_del2.append(_f.id())
                                else:
                                    _lyr.changeAttributeValue(_f.id(), _uc_idx2, _new_uc)
                                    _oz_geom = self._build_zone_polygon(_dem_layer, _rem_feats)
                                    if not _oz_geom.isEmpty():
                                        _lyr.changeGeometry(_f.id(), _oz_geom)
                            elif _fzid2 == new_zone:
                                _new_zone_found2 = True
                                # All demand in new zone's groups + moved demand points
                                _nz_grps2 = _z2g_dp.get(new_zone, set())
                                _nz_feats = [_ff for _ff in _dem_layer.getFeatures()
                                             if _ff[_dp_link] in _nz_grps2
                                             or _ff.id() in moved_fids]
                                _lyr.changeAttributeValue(_f.id(), _uc_idx2, len(_nz_feats))
                                _nz_geom = self._build_zone_polygon(_dem_layer, _nz_feats)
                                if not _nz_geom.isEmpty():
                                    _lyr.changeGeometry(_f.id(), _nz_geom)
                        if _fids_del2:
                            _lyr.deleteFeatures(_fids_del2)
                        if not _new_zone_found2:
                            _nz_grps2 = _z2g_dp.get(new_zone, set())
                            _nz_feats = [_ff for _ff in _dem_layer.getFeatures()
                                         if _ff[_dp_link] in _nz_grps2
                                         or _ff.id() in moved_fids]
                            if _nz_feats:
                                from qgis.core import QgsFeature as _QF2
                                _nf = _QF2(_lyr.fields())
                                _nf['zone_id']    = new_zone
                                _nf['zone_name']  = f"Zone {new_zone}"
                                _nf['unit_count'] = len(_nz_feats)
                                _nz_geom = self._build_zone_polygon(_dem_layer, _nz_feats)
                                if not _nz_geom.isEmpty():
                                    _nf.setGeometry(_nz_geom)
                                _lyr.addFeature(_nf)
                                _snap_dp['add_zone_ids'].append(new_zone)
                        _lyr.commitChanges()
                        # Rebuild renderer if zone boundaries layer is the accumulator
                        _accum_zn = getattr(self, '_pon_accum_zones', None)
                        try:
                            import sip as _sip_zn
                            if _accum_zn and not _sip_zn.isdeleted(_accum_zn) and _lyr is _accum_zn:
                                self._pon_refresh_accum_renderers()
                            else:
                                _lyr.triggerRepaint()
                        except Exception:
                            _lyr.triggerRepaint()
                        results_dp.append("PON Zone Boundaries updated")
                    break

            # Update in-memory demand_data + list labels, then auto-deselect
            for dd, old_g, old_z, row in moves:
                dd['group_id'] = new_grp
                dd['zone_id']  = new_zone
                dem_list.item(row).setText(
                    f"DP {dd['fid']}   |   Group {new_grp}   |   Zone {new_zone}")
            dem_list.clearSelection()

            # Push snapshot to undo stack
            _undo_stack.append(_snap_dp)
            _enable_undo()

            status_lbl.setText(
                f"<font color='green'><b>Done:</b> {len(moves)} demand point(s) → "
                f"Group {new_grp} / Zone {new_zone}<br>"
                + "<br>".join(results_dp)
                + "<br>Regenerating drop cables…</font>")
            self.log_message(f"Demand Override: {len(moves)} point(s) → Group {new_grp} / Zone {new_zone}")

            # Auto-regenerate drops so cable geometry reflects the new assignments
            _regen_drops()
            status_lbl.setText(
                f"<font color='green'><b>Done:</b> {len(moves)} demand point(s) → "
                f"Group {new_grp} / Zone {new_zone} — drops regenerated.</font>")

        # ================================================================
        # Map tool — tab-aware picking
        # ================================================================
        from qgis.core import QgsCoordinateTransform, QgsProject as _QP

        _canvas    = self.iface.mapCanvas()
        _prev_tool = _canvas.mapTool()
        _map_tool  = QgsMapToolEmitPoint(_canvas)
        _picking   = [True]

        # Polygon-select tool for the Demand Points tab
        _poly_tool = _PolySelectDemandTool(
            _canvas,
            demand_data,
            dem_list if demand_data else None,
            None,   # status_lbl placeholder — set below after status_lbl is defined
            splitter_layer.crs()) if demand_data else None

        def _on_canvas_click(point, _button):
            if not _picking[0]:
                return
            _xform = QgsCoordinateTransform(
                _QP.instance().crs(), splitter_layer.crs(), _QP.instance())
            try:
                _lp = _xform.transform(point)
            except Exception:
                _lp = point

            if tab_widget.currentIndex() == 0:
                # Splitter picking
                _best_idx, _best_d = 0, float('inf')
                for _i, _sd in enumerate(splitter_data):
                    _d = math.sqrt((_sd['x'] - _lp.x()) ** 2 + (_sd['y'] - _lp.y()) ** 2)
                    if _d < _best_d:
                        _best_d = _d
                        _best_idx = _i
                _item = list_widget.item(_best_idx)
                _item.setSelected(not _item.isSelected())
                _n = len(list_widget.selectedItems())
                _word = "selected" if _item.isSelected() else "deselected"
                status_lbl.setText(
                    f"<font color='blue'>Group {splitter_data[_best_idx]['group_id']} {_word} "
                    f"— {_n} splitter(s) selected.</font>")

            else:
                # Tab 2 — capture coordinate for new splitter
                from qgis.core import QgsGeometry, QgsPointXY as _PXY, QgsVectorLayer as _VL
                _ns_point[0] = _lp
                lbl_ns_x.setText(f"{_lp.x():.4f}")
                lbl_ns_y.setText(f"{_lp.y():.4f}")
                btn_add_sp.setEnabled(True)

                # Auto-detect zone from PON Zone polygon layer
                _auto_zone = 0
                for _lyr in _QP.instance().mapLayers().values():
                    if not isinstance(_lyr, _VL) or _lyr.geometryType() != 2:
                        continue
                    _ln = _lyr.name().lower()
                    if ('pon' in _ln or 'zone' in _ln) and ('zone' in _ln or 'boundar' in _ln):
                        _pt_geom = QgsGeometry.fromPointXY(_PXY(_lp.x(), _lp.y()))
                        for _zf in _lyr.getFeatures():
                            if _zf.geometry() and _pt_geom.within(_zf.geometry()):
                                _zval = _zf['zone_id'] if 'zone_id' in [_fd.name() for _fd in _lyr.fields()] else None
                                if _zval is not None:
                                    try:
                                        _auto_zone = int(_zval)
                                    except (TypeError, ValueError):
                                        pass
                                break
                        break
                spin_ns_zone.setValue(_auto_zone)
                status_lbl.setText(
                    f"<font color='blue'>Point captured at ({_lp.x():.2f}, {_lp.y():.2f}) "
                    f"— Zone auto-detected: {_auto_zone}. "
                    f"Adjust attributes and click <b>Add Splitter Point</b>.</font>")

        def _on_tool_deactivate():
            if _picking[0]:
                _picking[0] = False
                btn_pick.setChecked(False)
                btn_pick.setText("Map Picking: OFF")
                status_lbl.setText(
                    "Map picking paused — another tool was activated. "
                    "Click 'Map Picking: OFF' to resume.")

        _map_tool.canvasClicked.connect(_on_canvas_click)
        _map_tool.deactivated.connect(_on_tool_deactivate)

        # Wire status_lbl into the poly-select tool now that it exists
        if _poly_tool:
            _poly_tool._status = status_lbl
            _poly_tool.deactivated.connect(_on_tool_deactivate)

        # Add-new-demand-point placement tool
        _dp_add_tool = QgsMapToolEmitPoint(_canvas) if demand_data else None

        def _on_dp_place_click(_pt, _btn):
            """Capture a map click as the location for the new demand point."""
            if not _dp_add_mode[0]:
                return
            from qgis.core import QgsGeometry, QgsPointXY as _PXY, QgsVectorLayer as _VL
            _dp_new_point[0] = _pt
            if lbl_new_dp_x and lbl_new_dp_y:
                lbl_new_dp_x.setText(f"{_pt.x():.4f}")
                lbl_new_dp_y.setText(f"{_pt.y():.4f}")

            # Auto-detect zone from PON Zone polygon layer (same logic as splitter tab)
            _auto_zone = 0
            for _lyr in _QP.instance().mapLayers().values():
                if not isinstance(_lyr, _VL) or _lyr.geometryType() != 2:
                    continue
                _ln = _lyr.name().lower()
                if ('pon' in _ln or 'zone' in _ln) and ('zone' in _ln or 'boundar' in _ln):
                    _pt_geom = QgsGeometry.fromPointXY(_PXY(_pt.x(), _pt.y()))
                    for _zf in _lyr.getFeatures():
                        if _zf.geometry() and _pt_geom.within(_zf.geometry()):
                            _zval = _zf['zone_id'] if 'zone_id' in [_fd.name() for _fd in _lyr.fields()] else None
                            if _zval is not None:
                                try:
                                    _auto_zone = int(_zval)
                                except (TypeError, ValueError):
                                    pass
                            break
                    break
            if spin_dp_zone:
                spin_dp_zone.setValue(_auto_zone)

            # Refresh Add button — still needs splitter selection
            _has_grp = combo_add_dp_grp is not None and combo_add_dp_grp.currentIndex() > 0
            if btn_add_dp:
                btn_add_dp.setEnabled(_has_grp)
            status_lbl.setText(
                f"<font color='purple'>Location captured at ({_pt.x():.2f}, {_pt.y():.2f}) "
                f"— Zone auto-detected: {_auto_zone}. "
                f"{'Select a splitter then click <b>Add Demand Point</b>.' if not _has_grp else 'Click <b>Add Demand Point</b> to confirm.'}</font>")

        def _do_add_demand_point():
            """Create a new demand point feature on the demand layer."""
            _pt = _dp_new_point[0]
            if _pt is None:
                status_lbl.setText("<font color='red'>No location captured. Click 📍 Place on Map first.</font>")
                return
            if not demand_data:
                return
            # Index 0 is the placeholder "— Select splitter —"
            _idx_combo = (combo_add_dp_grp.currentIndex() - 1) if combo_add_dp_grp else -1
            if _idx_combo < 0 or _idx_combo >= len(splitter_data):
                status_lbl.setText("<font color='red'>Select a splitter from the list before adding.</font>")
                return
            _target_sp = splitter_data[_idx_combo]
            _zid = spin_dp_zone.value() if spin_dp_zone else _target_sp['zone_id']

            _new_feat = QgsFeature(_dem_layer.fields())
            _new_feat.setGeometry(QgsGeometry.fromPointXY(_pt))
            try:
                _new_feat[_dp_link] = _target_sp['group_id']
            except Exception:
                pass
            try:
                _new_feat['zone_id'] = _zid
            except Exception:
                pass
            try:
                _new_feat['zone_name'] = _target_sp.get('zone_name', '')
            except Exception:
                pass

            _dem_layer.startEditing()
            _ok = _dem_layer.addFeature(_new_feat)
            if _ok:
                _dem_layer.commitChanges()
                # Rebuild accumulator renderer if demand layer is the PON Groups accum
                _accum_grp_dp = getattr(self, '_pon_accum_groups', None)
                try:
                    import sip as _sip6
                    if _accum_grp_dp and not _sip6.isdeleted(_accum_grp_dp) and _dem_layer is _accum_grp_dp:
                        self._pon_refresh_accum_renderers()
                    else:
                        _dem_layer.triggerRepaint()
                except Exception:
                    _dem_layer.triggerRepaint()
                _new_fid = _new_feat.id()
                _entry = {
                    'fid':      _new_fid,
                    'group_id': _target_sp['group_id'],
                    'zone_id':  _zid,
                    'x':        _pt.x(),
                    'y':        _pt.y(),
                }
                demand_data.append(_entry)
                if dem_list:
                    dem_list.addItem(
                        f"DP {_new_fid}   |   Group {_entry['group_id']}   |   Zone {_entry['zone_id']}")
                # Update drop count on target splitter
                _target_sp['drop_count'] = _target_sp.get('drop_count', 0) + 1
                _new_label = (f"Group {_target_sp['group_id']}  |  Zone {_target_sp['zone_id']}  |  "
                              f"{_target_sp['drop_count']} drops")
                if combo_target:
                    for _ci in range(combo_target.count()):
                        if f"Group {_target_sp['group_id']}" in combo_target.itemText(_ci):
                            combo_target.setItemText(_ci, _new_label)
                            break
                if combo_add_dp_grp:
                    combo_add_dp_grp.setItemText(_idx_combo + 1, _new_label)
                # Reset
                _dp_new_point[0] = None
                if lbl_new_dp_x and lbl_new_dp_y:
                    lbl_new_dp_x.setText("—")
                    lbl_new_dp_y.setText("—")
                if spin_dp_zone:
                    spin_dp_zone.setValue(0)
                if combo_add_dp_grp:
                    combo_add_dp_grp.setCurrentIndex(0)
                if btn_place_dp:
                    btn_place_dp.setChecked(False)
                if btn_add_dp:
                    btn_add_dp.setEnabled(False)
                self.log_message(
                    f"Manual Override — new demand point: Group {_target_sp['group_id']}, "
                    f"Zone {_zid}, pos=({_pt.x():.2f}, {_pt.y():.2f})")
                status_lbl.setText(
                    f"<font color='green'><b>✓ Demand point added:</b> "
                    f"Group {_target_sp['group_id']} | Zone {_zid} at "
                    f"({_pt.x():.1f}, {_pt.y():.1f}). Regenerating drops…</font>")
                _regen_drops()
                status_lbl.setText(
                    "<font color='green'>Demand point added and drops regenerated.</font>")
            else:
                _dem_layer.rollBack()
                status_lbl.setText("<font color='red'>Failed to add demand point to layer.</font>")

        def _do_delete_demand_points():
            """Delete selected demand points from the layer and refresh UI."""
            if not dem_list:
                return
            _sel_rows = sorted([dem_list.row(it) for it in dem_list.selectedItems()], reverse=True)
            if not _sel_rows:
                status_lbl.setText("<font color='orange'>No demand points selected for deletion.</font>")
                return
            _fids_to_del = [demand_data[r]['fid'] for r in _sel_rows if r < len(demand_data)]
            _dem_layer.startEditing()
            _ok = _dem_layer.deleteFeatures(_fids_to_del)
            if _ok:
                _dem_layer.commitChanges()
                _dem_layer.triggerRepaint()
                for r in _sel_rows:
                    if r < len(demand_data):
                        demand_data.pop(r)
                    dem_list.takeItem(r)
                status_lbl.setText(
                    f"<font color='green'>Deleted {len(_fids_to_del)} demand point(s). Regenerating drops…</font>")
                _regen_drops()
                status_lbl.setText(
                    f"<font color='green'>Deleted {len(_fids_to_del)} demand point(s) and drops regenerated.</font>")
            else:
                _dem_layer.rollBack()
                status_lbl.setText("<font color='red'>Failed to delete demand points.</font>")

        def _toggle_place_dp(checked):
            """Toggle 'Place on Map' mode for adding a new demand point."""
            _dp_add_mode[0] = checked
            if checked:
                if not _picking[0]:
                    _picking[0] = True
                    btn_pick.setChecked(True)
                    btn_pick.setText("Map Picking: ON")
                _canvas.setMapTool(_dp_add_tool)
                status_lbl.setText(
                    "<font color='purple'>Click on the map to place the new demand point location.</font>")
            else:
                if _picking[0]:
                    _canvas.setMapTool(_poly_tool if _poly_tool else _map_tool)
                status_lbl.setText("Place on Map cancelled.")

        if _dp_add_tool:
            _dp_add_tool.canvasClicked.connect(_on_dp_place_click)

        def _start_picking():
            _picking[0] = True
            if tab_widget.currentIndex() == 1 and _poly_tool:
                _canvas.setMapTool(_poly_tool)
            else:
                _canvas.setMapTool(_map_tool)
            btn_pick.setChecked(True)
            btn_pick.setText("Map Picking: ON")

        def _stop_picking(restore_tool=True):
            _picking[0] = False
            if restore_tool:
                _canvas.setMapTool(_prev_tool)
            btn_pick.setChecked(False)
            btn_pick.setText("Map Picking: OFF")

        def _on_pick_toggle(checked):
            if checked:
                _start_picking()
                _idx = tab_widget.currentIndex()
                if _idx == 0:
                    status_lbl.setText("Map picking ON — click splitters on the map.")
                elif _idx == 1:
                    status_lbl.setText(
                        "Map picking ON — left-click to draw a polygon, right-click to finish and select demand points.")
                else:
                    status_lbl.setText("Map picking ON — click the map to place a new splitter point.")
            else:
                _stop_picking()
                status_lbl.setText("Map picking paused — use the list for selection.")

        def _on_tab_changed(_idx):
            if _picking[0]:
                if _idx == 1:
                    if _dp_add_mode[0] and _dp_add_tool:
                        _canvas.setMapTool(_dp_add_tool)
                        status_lbl.setText(
                            "<font color='purple'>Click on the map to place the new demand point location.</font>")
                    elif _poly_tool:
                        _canvas.setMapTool(_poly_tool)
                        status_lbl.setText(
                            "Map picking ON — left-click to draw a polygon, right-click to finish and select demand points.")
                elif _idx == 0:
                    _canvas.setMapTool(_map_tool)
                    status_lbl.setText("Map picking ON — click splitters on the map.")
                else:
                    _canvas.setMapTool(_map_tool)
                    status_lbl.setText("Map picking ON — click the map to place a new splitter point.")

        def _on_dialog_close():
            _picking[0] = False
            _dp_add_mode[0] = False
            try:
                _map_tool.canvasClicked.disconnect(_on_canvas_click)
            except Exception:
                pass
            try:
                _map_tool.deactivated.disconnect(_on_tool_deactivate)
            except Exception:
                pass
            if _poly_tool:
                try:
                    _poly_tool.deactivated.disconnect(_on_tool_deactivate)
                except Exception:
                    pass
                try:
                    _poly_tool.deactivate()
                except Exception:
                    pass
            if _dp_add_tool:
                try:
                    _dp_add_tool.canvasClicked.disconnect(_on_dp_place_click)
                except Exception:
                    pass
            _canvas.setMapTool(_prev_tool)

        btn_pick.toggled.connect(_on_pick_toggle)
        tab_widget.currentChanged.connect(_on_tab_changed)
        dlg.finished.connect(_on_dialog_close)
        btn_apply_sp.clicked.connect(apply_change)
        btn_undo_sp.clicked.connect(undo_last)
        if demand_data and btn_apply_dp:
            btn_apply_dp.clicked.connect(apply_demand_change)
        if btn_undo_dp:
            btn_undo_dp.clicked.connect(undo_last)
        if btn_regen_drops_dp is not None:
            def _do_regen_drops_dp():
                status_lbl.setText("<font color='orange'>Regenerating drop cables…</font>")
                _regen_drops()
                _dr2 = _drop_layer if (_drop_layer is not None and not sip.isdeleted(_drop_layer)) \
                    else getattr(self, 'drop_ptp_layer', None)
                _lyr_name2 = _dr2.name() if _dr2 else "Drop Cables PTP"
                status_lbl.setText(
                    f"<font color='green'><b>✓ Drop cables regenerated</b> — layer: {_lyr_name2}</font>")
            btn_regen_drops_dp.clicked.connect(_do_regen_drops_dp)
        if btn_place_dp:
            btn_place_dp.toggled.connect(_toggle_place_dp)
        if btn_add_dp:
            btn_add_dp.clicked.connect(_do_add_demand_point)
        if btn_delete_dp:
            btn_delete_dp.clicked.connect(_do_delete_demand_points)
        btn_close.clicked.connect(dlg.close)

        _start_picking()
        status_lbl.setText("Map picking ON — click splitters on the map.")
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()

    # ================================================================
    def on_manual_override_final_clicked(self):
        """Open layer-picker then launch Manual Override on any existing saved layers.

        Works independently of whether a PON per PON session was ever run.
        The user selects which project layers represent splitters, demand points,
        zone boundaries and drop cables, then the full Manual Override dialog opens
        pointed at those layers.
        """
        from qgis.PyQt.QtWidgets import (
            QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
            QComboBox, QFrame, QFormLayout, QMessageBox)
        from qgis.PyQt.QtCore import Qt
        from qgis.core import QgsProject, QgsVectorLayer

        proj_layers = {
            lyr.name(): lyr
            for lyr in QgsProject.instance().mapLayers().values()
            if isinstance(lyr, QgsVectorLayer)
        }
        if not proj_layers:
            QMessageBox.warning(self, "No Layers", "No vector layers found in the current project.")
            return

        # ── Auto-detect layers by name patterns ──────────────────────────
        def _best(patterns, geom_type=None):
            """Return the best-matching layer name, or '' if none found."""
            for lyr_name, lyr in proj_layers.items():
                n = lyr_name.lower()
                if geom_type is not None and lyr.geometryType() != geom_type:
                    continue
                if any(p in n for p in patterns):
                    return lyr_name
            return ''

        def_splitters = _best(['splitter'], geom_type=0)
        def_demand    = _best(['demand', 'groups of'], geom_type=0)
        def_zones     = _best(['zone', 'boundar'], geom_type=2)
        def_drops     = _best(['drop', 'cable'], geom_type=1)

        # ── Layer-picker dialog ───────────────────────────────────────────
        picker = QDialog(self)
        picker.setWindowTitle("Manual Override Final — Select Layers")
        picker.setMinimumWidth(480)
        picker.setModal(True)
        picker.setWindowFlags(picker.windowFlags() | Qt.WindowType.WindowStaysOnTopHint)
        pl = QVBoxLayout(picker)
        pl.setSpacing(8)

        info = QLabel(
            "<b>Select the layers to edit.</b><br>"
            "Splitters and Demand Points are required.<br>"
            "Zone Boundaries and Drop Cables are optional but enable zone updates and drop regeneration."
        )
        info.setWordWrap(True)
        pl.addWidget(info)

        sep = QFrame(); sep.setFrameShape(QFrame.Shape.HLine); sep.setFrameShadow(QFrame.Shadow.Sunken)
        pl.addWidget(sep)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        all_names = [''] + list(proj_layers.keys())

        def _combo(default_name, geom_type=None):
            cb = QComboBox()
            filtered = [''] + [n for n, lyr in proj_layers.items()
                               if geom_type is None or lyr.geometryType() == geom_type]
            cb.addItems(filtered)
            if default_name in filtered:
                cb.setCurrentText(default_name)
            return cb

        cb_sp  = _combo(def_splitters, geom_type=0)
        cb_dem = _combo(def_demand,    geom_type=0)
        cb_zon = _combo(def_zones,     geom_type=2)
        cb_drp = _combo(def_drops,     geom_type=1)

        form.addRow("🔴 Splitters layer (required):", cb_sp)
        form.addRow("🔵 Demand Points layer (required):", cb_dem)
        form.addRow("🟩 Zone Boundaries layer (optional):", cb_zon)
        form.addRow("⬛ Drop Cables layer (optional):", cb_drp)
        pl.addLayout(form)

        btns = QHBoxLayout()
        btn_ok     = QPushButton("Open Manual Override")
        btn_cancel = QPushButton("Cancel")
        btn_ok.setStyleSheet(
            "QPushButton { background-color: #1a3a5c; color: white; font-weight: bold; "
            "border-radius: 3px; padding: 4px 12px; }")
        btns.addStretch()
        btns.addWidget(btn_cancel)
        btns.addWidget(btn_ok)
        pl.addLayout(btns)

        btn_cancel.clicked.connect(picker.reject)
        btn_ok.clicked.connect(picker.accept)

        if picker.exec() != QDialog.DialogCode.Accepted:
            return

        # ── Validate ─────────────────────────────────────────────────────
        sp_name  = cb_sp.currentText()
        dem_name = cb_dem.currentText()
        zon_name = cb_zon.currentText()
        drp_name = cb_drp.currentText()

        if not sp_name:
            QMessageBox.warning(self, "Missing Layer", "Please select a Splitters layer.")
            return
        if not dem_name:
            QMessageBox.warning(self, "Missing Layer", "Please select a Demand Points layer.")
            return

        # ── Wire accumulators to selected layers ─────────────────────────
        self._pon_accum_splitters = proj_layers[sp_name]
        self._pon_accum_groups    = proj_layers[dem_name]
        self._pon_accum_zones     = proj_layers[zon_name]  if zon_name else None
        self._pon_accum_drops     = proj_layers[drp_name]  if drp_name else None

        # Prevent _pon_per_pon_run from nulling these on next run
        self._pon_new_session_needed = False

        # Also mirror to the standard single-run layer refs used by drop regen
        self.splitter_points_layer = self._pon_accum_splitters
        self.demand_points_layer   = self._pon_accum_groups
        if self._pon_accum_zones:
            self.zone_boundaries_layer = self._pon_accum_zones
        if self._pon_accum_drops:
            self.drop_ptp_layer = self._pon_accum_drops

        self.log_message(
            f"[Manual Override Final] Layers linked — "
            f"Splitters: '{sp_name}', Demand: '{dem_name}', "
            f"Zones: '{zon_name or 'none'}', Drops: '{drp_name or 'none'}'"
        )

        # ── Open the standard Manual Override dialog ──────────────────────
        self.on_manual_override_clicked()

    def on_create_enclosure_clicked(self):
        """Open enclosure type chooser, then let user click map to place enclosure point."""
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                          QPushButton)
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY,
                                QgsField, QgsProject, QgsMarkerSymbol, QgsSingleSymbolRenderer,
                                QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                                QgsVectorLayerSimpleLabeling)
        from qgis.PyQt.QtCore import QMetaType
        from qgis.PyQt.QtGui import QColor, QFont

        # If button is unchecked, cancel any active placement
        if not self._btn_create_enclosure.isChecked():
            if self._create_enclosure_tool:
                self.iface.mapCanvas().unsetMapTool(self._create_enclosure_tool)
                self._create_enclosure_tool = None
            self._create_enclosure_type = None
            self.log_message("Create Enclosure: placement cancelled.")
            return

        # ── Step 1: Ask user what type of enclosure ──────────────────────────
        dlg = QDialog(self.iface.mainWindow())
        dlg.setWindowTitle("Create Enclosure — Select Type")
        dlg.setMinimumWidth(320)
        layout = QVBoxLayout(dlg)

        lbl = QLabel("Select the enclosure type to place on the map:")
        lbl.setWordWrap(True)
        layout.addWidget(lbl)

        btn_fs = QPushButton("📦  Feeder Splice  (FS)")
        btn_fs.setStyleSheet(
            "QPushButton { background-color: #1a5276; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #2471a3; }"
        )
        btn_fts = QPushButton("📦  First Tier Splitter Splice  (FTS)")
        btn_fts.setStyleSheet(
            "QPushButton { background-color: #145a32; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #1e8449; }"
        )
        btn_cancel = QPushButton("Cancel")

        layout.addWidget(btn_fs)
        layout.addWidget(btn_fts)
        layout.addSpacing(6)
        layout.addWidget(btn_cancel)

        chosen_type = [None]

        def _pick(enc_type):
            chosen_type[0] = enc_type
            dlg.accept()

        btn_fs.clicked.connect(lambda: _pick('FS'))
        btn_fts.clicked.connect(lambda: _pick('FTS'))
        btn_cancel.clicked.connect(dlg.reject)

        if dlg.exec() != QDialog.DialogCode.Accepted or not chosen_type[0]:
            self._btn_create_enclosure.setChecked(False)
            return

        enc_type = chosen_type[0]
        self._create_enclosure_type = enc_type
        self.log_message(f"Create Enclosure: type={enc_type} — click on the map to place. Right-click to finish.")

        # ── Step 2: Activate map click tool ──────────────────────────────────
        canvas = self.iface.mapCanvas()
        crs = canvas.mapSettings().destinationCrs().authid()
        layer_name = f"Manual Enclosures ({enc_type})"

        # Get or create the enclosure layer for this type
        enc_layer = None
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name() == layer_name:
                enc_layer = lyr
                break

        if enc_layer is None:
            color = '30,82,172,255' if enc_type == 'FS' else '21,128,50,255'
            enc_layer = QgsVectorLayer(f"Point?crs={crs}", layer_name, "memory")
            provider = enc_layer.dataProvider()
            provider.addAttributes([
                QgsField('enclosure_id', QMetaType.Type.Int),
                QgsField('enclosure_name', QMetaType.Type.QString),
                QgsField('enclosure_type', QMetaType.Type.QString),
            ])
            enc_layer.updateFields()

            symbol = QgsMarkerSymbol.createSimple({
                'name': 'square',
                'color': color,
                'outline_color': '255,255,255,255',
                'outline_width': '0.6',
                'size': '7',
            })
            enc_layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            # Labels
            lbl_s = QgsPalLayerSettings()
            lbl_s.fieldName = 'enclosure_name'
            lbl_s.enabled = True
            fmt = QgsTextFormat()
            fmt.setFont(QFont("Arial", 7))
            fmt.setColor(QColor(255, 255, 255))
            buf = QgsTextBufferSettings()
            buf.setEnabled(True)
            buf.setSize(1.0)
            buf.setColor(QColor(0, 0, 0))
            fmt.setBuffer(buf)
            lbl_s.setFormat(fmt)
            enc_layer.setLabeling(QgsVectorLayerSimpleLabeling(lbl_s))
            enc_layer.setLabelsEnabled(True)

            QgsProject.instance().addMapLayer(enc_layer)
            self.log_message(f"  Created new layer: '{layer_name}'")

        # Track next ID for this layer
        existing_ids = [f['enclosure_id'] for f in enc_layer.getFeatures() if f['enclosure_id']]
        next_id = [max(existing_ids) + 1 if existing_ids else 1]

        # Map click tool
        map_tool = QgsMapToolEmitPoint(canvas)

        def _on_map_click(point, button):
            from qgis.PyQt.QtCore import Qt as _Qt
            if button == _Qt.RightButton:
                # Right-click to finish
                canvas.unsetMapTool(map_tool)
                self._btn_create_enclosure.setChecked(False)
                self._create_enclosure_tool = None
                self.log_message(f"Create Enclosure: placement finished. {next_id[0]-1} enclosure(s) placed.")
                enc_layer.triggerRepaint()
                return

            # Place enclosure at clicked point
            feat = QgsFeature(enc_layer.fields())
            feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(point.x(), point.y())))
            enc_name = f"{enc_type}_{next_id[0]:03d}"
            feat.setAttributes([next_id[0], enc_name, enc_type])
            enc_layer.dataProvider().addFeatures([feat])
            enc_layer.updateExtents()
            enc_layer.triggerRepaint()
            self.log_message(f"  Placed: {enc_name} at ({point.x():.2f}, {point.y():.2f})")
            next_id[0] += 1

        map_tool.canvasClicked.connect(_on_map_click)
        self._create_enclosure_tool = map_tool
        canvas.setMapTool(map_tool)
        self.log_message("  Click on the map to place enclosures. Right-click when done.")

    def on_create_span_clicked(self):
        """Open span type chooser, then let user draw lines on the map."""
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                          QPushButton)
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY, QgsField, QgsProject, QgsLineSymbol, QgsSingleSymbolRenderer)
        from qgis.PyQt.QtCore import QMetaType
        from qgis.PyQt.QtGui import QColor

        # If button is unchecked, cancel any active drawing
        if not self._btn_create_span.isChecked():
            if self._create_span_tool:
                self.iface.mapCanvas().unsetMapTool(self._create_span_tool)
                self._create_span_tool = None
            self._create_span_type = None
            self.log_message("Create Span: drawing cancelled.")
            return

        # ── Step 1: Ask user what type of span ─────────────────────────────
        dlg = QDialog(self.iface.mainWindow())
        dlg.setWindowTitle("Create Span — Select Type")
        dlg.setMinimumWidth(340)
        layout = QVBoxLayout(dlg)

        lbl = QLabel("Select the span cable type to draw on the map:")
        lbl.setWordWrap(True)
        layout.addWidget(lbl)

        # Create buttons for each span type
        btn_feeder = QPushButton("🔴  Feeder")
        btn_feeder.setStyleSheet(
            "QPushButton { background-color: #8B0000; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #B22222; }"
        )
        
        btn_second = QPushButton("🟣  Second Feeder")
        btn_second.setStyleSheet(
            "QPushButton { background-color: #8B008B; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #BA55D3; }"
        )
        
        btn_third = QPushButton("🔵  Third Feeder")
        btn_third.setStyleSheet(
            "QPushButton { background-color: #00008B; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #0000FF; }"
        )
        
        btn_dist1 = QPushButton("🟢  Distribution 1")
        btn_dist1.setStyleSheet(
            "QPushButton { background-color: #008000; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #00FF00; }"
        )
        
        btn_dist2 = QPushButton("🔷  Distribution 2")
        btn_dist2.setStyleSheet(
            "QPushButton { background-color: #008080; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #00FFFF; }"
        )
        
        btn_dist3 = QPushButton("🟡  Distribution 3")
        btn_dist3.setStyleSheet(
            "QPushButton { background-color: #808000; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #FFFF00; }"
        )
        
        btn_cancel = QPushButton("Cancel")

        layout.addWidget(btn_feeder)
        layout.addWidget(btn_second)
        layout.addWidget(btn_third)
        layout.addWidget(btn_dist1)
        layout.addWidget(btn_dist2)
        layout.addWidget(btn_dist3)
        layout.addSpacing(6)
        layout.addWidget(btn_cancel)

        chosen_type = [None]

        def _pick(span_type):
            chosen_type[0] = span_type
            dlg.accept()

        btn_feeder.clicked.connect(lambda: _pick('Feeder'))
        btn_second.clicked.connect(lambda: _pick('Second Feeder'))
        btn_third.clicked.connect(lambda: _pick('Third Feeder'))
        btn_dist1.clicked.connect(lambda: _pick('Distribution 1'))
        btn_dist2.clicked.connect(lambda: _pick('Distribution 2'))
        btn_dist3.clicked.connect(lambda: _pick('Distribution 3'))
        btn_cancel.clicked.connect(dlg.reject)

        if dlg.exec() != QDialog.DialogCode.Accepted or not chosen_type[0]:
            self._btn_create_span.setChecked(False)
            return

        span_type = chosen_type[0]
        self._create_span_type = span_type
        self.log_message(f"Create Span: type={span_type} — click on the map to draw vertices. Right-click to finish.")

        # ── Step 2: Activate map tool ────────────────────────────────────────
        canvas = self.iface.mapCanvas()
        crs = canvas.mapSettings().destinationCrs().authid()
        layer_name = f"Manual Spans ({span_type})"

        # Span type colors and cable type
        span_colors = {
            'Feeder': ('#FF0000', 'Feeder'),
            'Second Feeder': ('#FF00FF', 'Second Feeder'),
            'Third Feeder': ('#0000FF', 'Third Feeder'),
            'Distribution 1': ('#00FF00', 'Distribution'),
            'Distribution 2': ('#00FFFF', 'Distribution'),
            'Distribution 3': ('#FFFF00', 'Distribution'),
        }
        color_hex, cable_type = span_colors.get(span_type, ('#000000', 'Unknown'))

        # Get or create the span layer for this type
        span_layer = None
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name() == layer_name:
                span_layer = lyr
                break

        if span_layer is None:
            span_layer = QgsVectorLayer(f"LineString?crs={crs}", layer_name, "memory")
            provider = span_layer.dataProvider()
            provider.addAttributes([
                QgsField('span_id', QMetaType.Type.Int),
                QgsField('span_name', QMetaType.Type.QString),
                QgsField('span_type', QMetaType.Type.QString),
                QgsField('Cable Type', QMetaType.Type.QString),
                QgsField('length_m', QMetaType.Type.Double),  # Length in meters
            ])
            span_layer.updateFields()

            # Convert hex color to RGB
            r = int(color_hex[1:3], 16)
            g = int(color_hex[3:5], 16)
            b = int(color_hex[5:7], 16)

            symbol = QgsLineSymbol.createSimple({
                'line_color': f'{r},{g},{b}',
                'line_width': '1.86',
                'line_width_unit': 'mm',
                'line_style': 'solid',
            })
            span_layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            QgsProject.instance().addMapLayer(span_layer)
            self.log_message(f"  Created new layer: '{layer_name}'")

        # Ensure length_m field exists on any pre-existing layer
        if span_layer.fields().indexOf('length_m') < 0:
            span_layer.dataProvider().addAttributes([QgsField('length_m', QMetaType.Type.Double)])
            span_layer.updateFields()

        # Track next ID and current line vertices
        existing_ids = [f['span_id'] for f in span_layer.getFeatures() if f['span_id']]
        next_id = [max(existing_ids) + 1 if existing_ids else 1]
        vertices = [[]]  # list of vertex lists per line being drawn

        # ── Create rubber band for preview line trace ────────────────────────
        from qgis.gui import QgsRubberBand
        from qgis.core import QgsWkbTypes
        rubber_band = QgsRubberBand(canvas, QgsWkbTypes.GeometryType.LineGeometry)
        # Convert hex color to bright RGB for visibility
        r = int(color_hex[1:3], 16)
        g = int(color_hex[3:5], 16)
        b = int(color_hex[5:7], 16)
        # Boost saturation for preview visibility
        preview_color = QColor(r, g, b, 200)  # 200 alpha for semi-transparency
        rubber_band.setColor(preview_color)
        rubber_band.setWidth(3)  # Thicker for visibility during drawing

        # Map click tool
        map_tool = QgsMapToolEmitPoint(canvas)

        def _on_map_click(point, button):
            from qgis.PyQt.QtCore import Qt as _Qt
            if button == _Qt.RightButton:
                # Right-click to finish current line
                if vertices[-1]:
                    line_pts = [QgsPointXY(v.x(), v.y()) for v in vertices[-1]]
                    geom = QgsGeometry.fromPolylineXY(line_pts)
                    
                    # Calculate length in meters using QgsDistanceArea (handles geographic/projected CRS)
                    from qgis.core import QgsDistanceArea
                    da = QgsDistanceArea()
                    da.setSourceCrs(span_layer.crs(), QgsProject.instance().transformContext())
                    da.setEllipsoid(QgsProject.instance().ellipsoid())
                    line_length = round(da.measureLength(geom), 2)  # Meters, 2 decimal places
                    
                    feat = QgsFeature(span_layer.fields())
                    feat.setGeometry(geom)
                    span_name = f"{span_type.replace(' ', '_')}_{next_id[0]:03d}"
                    feat.setAttributes([next_id[0], span_name, span_type, cable_type, line_length])
                    span_layer.dataProvider().addFeatures([feat])
                    span_layer.updateExtents()
                    span_layer.triggerRepaint()
                    self.log_message(f"  Completed: {span_name} ({len(vertices[-1])} vertices, {line_length:.2f} m)")
                    next_id[0] += 1
                    vertices.append([])  # start fresh for next line
                    
                    # Clear rubber band for next line
                    rubber_band.reset(QgsWkbTypes.GeometryType.LineGeometry)
                else:
                    # No vertices on current line — just finish
                    rubber_band.reset()
                    canvas.unsetMapTool(map_tool)
                    self._btn_create_span.setChecked(False)
                    self._create_span_tool = None
                    self.log_message(f"Create Span: drawing finished. {next_id[0]-1} span(s) created.")
                    return
            else:
                # Left-click: add vertex
                vertices[-1].append(QgsPointXY(point.x(), point.y()))
                
                # Update rubber band with new point
                rubber_band.addPoint(QgsPointXY(point.x(), point.y()))
                
                self.log_message(f"  Vertex added: ({point.x():.2f}, {point.y():.2f})")

        map_tool.canvasClicked.connect(_on_map_click)
        self._create_span_tool = map_tool
        canvas.setMapTool(map_tool)
        self.log_message("  Click on the map to add vertices. Right-click to finish the current line.")

    def on_generate_aggregation_points_clicked(self):
        """Generate Enclosure points where 2+ Feeder/Second/Third Feeder cables converge (at any point, including mid-path)."""
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject, QgsField,
                                QgsPointXY, QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                                QgsVectorLayerSimpleLabeling)
        from qgis.PyQt.QtCore import QMetaType
        from qgis.PyQt.QtGui import QColor, QFont

        # ── 1. Get the Span layer ──────────────────────────────────────────────
        span_layer = self.comboBox_span_layer.currentLayer()
        if span_layer is None:
            self.log_message("ERROR: Please select a Span (Route) layer first.")
            return

        if span_layer.geometryType() != 1:   # 1 = Line
            self.log_message(f"ERROR: '{span_layer.name()}' is not a line layer.")
            return

        self.log_message("\n=== Generating Feeder Enclosure Points ===")
        self.log_message(f"Source layer: '{span_layer.name()}'")
        self.log_message(f"Feature count: {span_layer.featureCount()}")

        # ── 2. Identify feeder-class cables ────────────────────────────────────
        has_cable_type = 'Cable Type' in [f.name() for f in span_layer.fields()]
        feeder_cables = []
        feeder_geoms = {}

        for feat in span_layer.getFeatures():
            geom = feat.geometry()
            if geom is None or geom.isEmpty():
                continue

            # Filter to feeder-class cables
            cable_type_str = ''
            if has_cable_type:
                cable_type_str = str(feat['Cable Type'] or '').strip().lower()

            cable_lower = feat['Name'].lower() if 'Name' in [f.name() for f in span_layer.fields()] else ''
            is_feeder_class = (
                ('feeder' in cable_lower or 'second' in cable_lower or 'third' in cable_lower)
                and 'distribution' not in cable_lower
            ) or cable_type_str in ['feeder', 'second feeder', 'third feeder']

            if is_feeder_class:
                feat_id = feat.id()
                feeder_cables.append((feat_id, geom, feat))
                feeder_geoms[feat_id] = geom

        if not feeder_cables:
            self.log_message("⚠ No Feeder-class cables found.")
            return

        self.log_message(f"Found {len(feeder_cables)} feeder-class cables")

        # ── 3. Collect convergence points: Method 1 (vertex-based) ─────────────
        processed_locations = set()
        convergence_points = {}  # {rounded_key: {"count": N, "geoms": [list], "exact_pts": [list]}}

        for feat_id, geom, feat in feeder_cables:
            # Collect all vertices along the cable
            all_points = []
            if geom.wkbType() in [2, 1002]:  # LineString
                pts = geom.asPolyline()
            elif geom.wkbType() in [5, 1005]:  # MultiLineString
                pts = []
                for part in geom.asMultiPolyline():
                    pts.extend(part)
            else:
                continue

            for pt in pts:
                # Round for deduplication
                key = (round(pt.x(), 2), round(pt.y(), 2))
                if key not in processed_locations:
                    all_points.append((key, pt))
                    processed_locations.add(key)

            # Collect all unique points for this cable
            for rounded_key, exact_pt in all_points:
                if rounded_key not in convergence_points:
                    convergence_points[rounded_key] = {"count": 0, "geoms": [], "exact_pts": []}
                convergence_points[rounded_key]["count"] += 1
                convergence_points[rounded_key]["geoms"].append(feat_id)
                convergence_points[rounded_key]["exact_pts"].append(exact_pt)

        # ── 4. Method 2: Geometry intersection detection ────────────────────────
        for i, (feat_id_1, geom_1, _) in enumerate(feeder_cables):
            for feat_id_2, geom_2, _ in feeder_cables[i+1:]:
                if geom_1.intersects(geom_2):
                    # Use centroid as intersection point
                    int_geom = geom_1.intersection(geom_2)
                    if int_geom and not int_geom.isEmpty():
                        if int_geom.type() == 0:  # Point
                            pt = int_geom.asPoint()
                        elif int_geom.type() == 1:  # Line
                            pt = int_geom.centroid().asPoint()
                        else:
                            continue

                        key = (round(pt.x(), 2), round(pt.y(), 2))
                        if key not in processed_locations:
                            if key not in convergence_points:
                                convergence_points[key] = {"count": 0, "geoms": [], "exact_pts": []}
                            convergence_points[key]["count"] += 1
                            convergence_points[key]["geoms"].extend([feat_id_1, feat_id_2])
                            convergence_points[key]["exact_pts"].append(pt)
                            processed_locations.add(key)

        # ── 5. Filter: only points where 2+ cables meet ─────────────────────────
        enclosure_locations = {}
        for rounded_key, data in convergence_points.items():
            if len(set(data["geoms"])) >= 2:  # At least 2 distinct cables
                # Use the first exact point (they're all very close)
                exact_pt = data["exact_pts"][0]
                enclosure_locations[rounded_key] = exact_pt

        if not enclosure_locations:
            self.log_message("⚠ No convergence points found.")
            return

        self.log_message(f"Found {len(enclosure_locations)} convergence points")

        # ── 6. Create or find Enclosure layer ──────────────────────────────────
        enclosure_layer_name = "Feeder Enclosures"
        enclosure_layer = None

        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name() == enclosure_layer_name:
                enclosure_layer = lyr
                break

        if enclosure_layer is None:
            crs = span_layer.crs().authid()
            enclosure_layer = QgsVectorLayer(f"Point?crs={crs}", enclosure_layer_name, "memory")
            provider = enclosure_layer.dataProvider()
            provider.addAttributes([
                QgsField('enclosure_id', QMetaType.Type.Int),
                QgsField('enclosure_name', QMetaType.Type.QString),
                QgsField('converging_cables', QMetaType.Type.Int),
            ])
            enclosure_layer.updateFields()

            # Apply symbology - cyan/teal squares
            symbol = QgsMarkerSymbol.createSimple({
                'name': 'square',
                'color': '0,200,200,255',
                'outline_color': '0,0,0,255',
                'outline_width': '0.5',
                'size': '5',
            })
            enclosure_layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            # Labels
            lbl_settings = QgsPalLayerSettings()
            lbl_settings.fieldName = 'enclosure_name'
            lbl_settings.enabled = True
            fmt = QgsTextFormat()
            fmt.setFont(QFont("Arial", 7))
            fmt.setColor(QColor(0, 0, 0))
            buf = QgsTextBufferSettings()
            buf.setEnabled(True)
            buf.setSize(1.0)
            buf.setColor(QColor(255, 255, 255))
            fmt.setBuffer(buf)
            lbl_settings.setFormat(fmt)
            enclosure_layer.setLabeling(QgsVectorLayerSimpleLabeling(lbl_settings))
            enclosure_layer.setLabelsEnabled(True)

            QgsProject.instance().addMapLayer(enclosure_layer)
            self.log_message(f"  Created layer: '{enclosure_layer_name}'")

        # ── 7. Add features ────────────────────────────────────────────────────
        existing_ids = [f['enclosure_id'] for f in enclosure_layer.getFeatures() if f['enclosure_id']]
        next_id = max(existing_ids) + 1 if existing_ids else 1

        provider = enclosure_layer.dataProvider()
        features = []

        for rounded_key, exact_pt in enclosure_locations.items():
            feat = QgsFeature(enclosure_layer.fields())
            feat.setGeometry(QgsGeometry.fromPointXY(exact_pt))
            feat.setAttributes([
                next_id,
                f"Encl_{next_id:03d}",
                convergence_points[rounded_key]["count"],
            ])
            features.append(feat)
            next_id += 1

        provider.addFeatures(features)
        enclosure_layer.updateExtents()
        enclosure_layer.triggerRepaint()

        self.log_message(f"✓ Created {len(features)} enclosure point(s)")


        """Generate Enclosure points where 2+ Feeder/Second/Third Feeder cables converge (at any point, including mid-path)."""
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject, QgsField,
                                QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                                QgsVectorLayerSimpleLabeling)
        # QgsMarkerSymbol/QgsSingleSymbolRenderer are module-level; re-importing them
        # here made them local and broke the earlier uses (UnboundLocalError).
        from qgis.PyQt.QtCore import QMetaType
        from qgis.PyQt.QtGui import QColor, QFont

        # ── 1. Get the Span layer ──────────────────────────────────────────────
        span_layer = self.comboBox_span_layer.currentLayer()
        if span_layer is None:
            self.log_message("ERROR: Please select a Span (Route) layer first.")
            return

        if span_layer.geometryType() != 1:   # 1 = Line
            self.log_message(f"ERROR: '{span_layer.name()}' is not a line layer.")
            return

        # Check for Cable Type field
        span_flds_orig = [f.name() for f in span_layer.fields()]
        span_flds_lower = [f.lower() for f in span_flds_orig]
        cable_type_field = None
        
        for fld_check in ['cable_type', 'cable type', 'type', 'cabletype', 'cabletype_name']:
            if fld_check in span_flds_lower:
                idx = span_flds_lower.index(fld_check)
                cable_type_field = span_flds_orig[idx]
                break

        if not cable_type_field:
            self.log_message("ERROR: Span layer must have a 'Cable Type' field.")
            self.log_message(f"Available fields: {', '.join(span_flds_orig)}")
            return

        self.log_message("\n=== Generating Enclosure Points (Feeder-class Convergence) ===")
        self.log_message(f"Source layer: '{span_layer.name()}'")
        self.log_message(f"Cable Type field: '{cable_type_field}'")
        self.log_message("Detecting junctions where Feeder/Second Feeder/Third Feeder cables meet...")

        try:
            from qgis.PyQt.QtWidgets import QApplication as _QApp
            crs = span_layer.crs().authid()
            
            # Get all features from span layer
            span_list = list(span_layer.getFeatures())
            self._start_timer()

            # ── 2. Collect ALL vertices + endpoints from feeder-class cables ────
            # Also detect intersections and close proximity points
            vertex_map = {}  # (rounded_x, rounded_y) -> list of (cable_type_str, geom, exact_pt)
            rounding = 3
            unique_cable_types = set()
            feeder_class_count = 0
            feeder_geoms = []  # Keep all feeder geometries for intersection checking

            self.log_message(f"Analyzing {len(span_list)} spans...")

            for idx, sf in enumerate(span_list):
                if idx % max(1, len(span_list) // 20) == 0:
                    self._progress(idx + 1, len(span_list), 'Analyze')
                    _QApp.processEvents()

                geom = sf.geometry()
                if not geom or geom.isEmpty():
                    continue

                cable_type = sf[cable_type_field]
                if cable_type is None:
                    cable_type = "Unknown"
                cable_type_str = str(cable_type).strip()
                cable_lower = cable_type_str.lower()
                unique_cable_types.add(cable_type_str)

                # Only process feeder-class cables (exclude Distribution)
                is_feeder_class = ('feeder' in cable_lower or 'second' in cable_lower or 'third' in cable_lower) and 'distribution' not in cable_lower
                if not is_feeder_class:
                    continue

                feeder_class_count += 1
                feeder_geoms.append((cable_type_str, geom))

                # Get ALL vertices along this line (not just endpoints)
                try:
                    if geom.isMultipart():
                        coords = geom.asMultiPolyline()[0] if geom.asMultiPolyline() else []
                    else:
                        coords = geom.asPolyline()
                except Exception:
                    continue

                if len(coords) < 2:
                    continue

                # Record EVERY vertex of this feeder-class cable WITH exact coordinates
                for pt in coords:
                    key = (round(pt.x(), rounding), round(pt.y(), rounding))
                    if key not in vertex_map:
                        vertex_map[key] = []
                    vertex_map[key].append((cable_type_str, geom, pt))

            self.log_message(f"Found {len(vertex_map)} vertex locations from {feeder_class_count} feeder-class spans")
            self.log_message(f"Unique cable types: {', '.join(sorted(unique_cable_types))}")

            # ── 3. Find convergence points: 2+ unique feeder-class cables ───────
            # Method 1: Exact vertex matches (rounding-based)
            convergence_points = []
            enclosure_num = 1
            processed_locations = set()  # Avoid duplicates

            for (rounded_x, rounded_y), cables_at_vertex in sorted(vertex_map.items()):
                # Get unique cables at this vertex (avoid counting same cable multiple times)
                unique_geoms = {}  # geom_id -> (cable_type_str, geom, exact_pt)
                for cable_type_str, geom, exact_pt in cables_at_vertex:
                    geom_id = id(geom)
                    if geom_id not in unique_geoms:
                        unique_geoms[geom_id] = (cable_type_str, geom, exact_pt)

                # Create enclosure if 2+ different feeder-class cables converge
                if len(unique_geoms) >= 2:
                    # Use exact coordinates from the convergence points (already on the lines)
                    exact_points = [exact_pt for _, _, exact_pt in unique_geoms.values()]
                    
                    if exact_points:
                        # Average exact coordinates (better precision than rounding)
                        avg_x = sum(p.x() for p in exact_points) / len(exact_points)
                        avg_y = sum(p.y() for p in exact_points) / len(exact_points)

                        # Collect unique cable types at this junction
                        junction_types = sorted(set(ct for ct, _, _ in unique_geoms.values()))

                        loc_key = (round(avg_x, 2), round(avg_y, 2))
                        if loc_key not in processed_locations:
                            convergence_points.append({
                                'num': enclosure_num,
                                'x': avg_x,
                                'y': avg_y,
                                'cable_count': len(unique_geoms),
                                'cable_types': junction_types
                            })
                            processed_locations.add(loc_key)
                            enclosure_num += 1

            # ── Method 2: Proximity-based detection for near-touching cables ────
            # For cables that cross or touch but don't share exact vertices
            snap_tolerance = 0.5  # meters - adjust based on your data precision
            
            for i, (cable_type_1, geom_1) in enumerate(feeder_geoms):
                for cable_type_2, geom_2 in feeder_geoms[i+1:]:
                    # Skip same geometry
                    if id(geom_1) == id(geom_2):
                        continue
                    
                    try:
                        # Check if geometries intersect or touch
                        if geom_1.intersects(geom_2):
                            intersection = geom_1.intersection(geom_2)
                            
                            if intersection.type() == 0:  # Point
                                int_pt = intersection.asPoint()
                                int_x, int_y = int_pt.x(), int_pt.y()
                            elif intersection.type() == 1:  # MultiPoint or PointSet
                                # Get first intersection point
                                try:
                                    pts = intersection.asMultiPoint() if hasattr(intersection, 'asMultiPoint') else [intersection.asPoint()]
                                    if pts:
                                        int_pt = pts[0]
                                        int_x, int_y = int_pt.x(), int_pt.y()
                                    else:
                                        continue
                                except:
                                    continue
                            else:
                                # Line-line intersection, use centroid of intersection
                                int_pt = intersection.centroid().asPoint()
                                int_x, int_y = int_pt.x(), int_pt.y()
                            
                            # Check if already processed
                            loc_key = (round(int_x, 2), round(int_y, 2))
                            if loc_key not in processed_locations:
                                convergence_points.append({
                                    'num': enclosure_num,
                                    'x': int_x,
                                    'y': int_y,
                                    'cable_count': 2,
                                    'cable_types': sorted(set([cable_type_1, cable_type_2]))
                                })
                                processed_locations.add(loc_key)
                                enclosure_num += 1
                    except Exception:
                        continue

            self.log_message(f"Found {len(convergence_points)} feeder-class convergence points (2+ cables meeting)")

            if not convergence_points:
                self.log_message("⚠ No convergence points found (need 2+ Feeder/Second/Third Feeder cables meeting).")
                return

            # ── 4. Build output layer ─────────────────────────────────────────
            agg_layer = QgsVectorLayer(f"Point?crs={crs}", "Aggregation Points (Enclosures)", "memory")
            provider = agg_layer.dataProvider()
            provider.addAttributes([
                QgsField('enclosure_id', QMetaType.Type.Int),
                QgsField('enclosure_name', QMetaType.Type.QString),
                QgsField('cable_types', QMetaType.Type.QString),
                QgsField('cable_count', QMetaType.Type.Int),
            ])
            agg_layer.updateFields()

            agg_features = []
            for cp in convergence_points:
                feat = QgsFeature(agg_layer.fields())
                feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(cp['x'], cp['y'])))
                encl_name = f"Enclosure_{cp['num']:03d}"
                types_str = ', '.join(cp['cable_types'])
                feat.setAttributes([
                    cp['num'],
                    encl_name,
                    types_str,
                    cp['cable_count']
                ])
                agg_features.append(feat)

            provider.addFeatures(agg_features)
            agg_layer.updateExtents()

            # ── 5. Symbology ──────────────────────────────────────────────────
            symbol = QgsMarkerSymbol.createSimple({
                'name':          'circle',
                'color':         '0,200,255,255',
                'outline_color': '0,100,200,255',
                'outline_width': '0.8',
                'size':          '7',
            })
            agg_layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            # ── 6. Labels ─────────────────────────────────────────────────────
            lbl_settings = QgsPalLayerSettings()
            lbl_settings.fieldName = 'enclosure_name'
            lbl_settings.isExpression = False
            lbl_settings.enabled = True
            lbl_settings.placement = QgsPalLayerSettings.Placement.OverPoint

            txt = QgsTextFormat()
            txt.setFont(QFont('Arial', 7, QFont.Weight.Bold))
            txt.setSize(7)
            txt.setColor(QColor('#003366'))
            buf = QgsTextBufferSettings()
            buf.setEnabled(True)
            buf.setSize(0.6)
            buf.setColor(QColor('white'))
            txt.setBuffer(buf)
            lbl_settings.setFormat(txt)
            agg_layer.setLabeling(QgsVectorLayerSimpleLabeling(lbl_settings))
            agg_layer.setLabelsEnabled(True)

            agg_layer = self._add_output_layer(agg_layer)

            self._elapsed("Total time")
            self.log_message(f"✓ Created {len(agg_features)} Enclosure points")
            self.log_message("Fields: enclosure_id, enclosure_name, cable_types, feeder_count")
            for af in agg_features:
                self.log_message(
                    f"  {af['enclosure_name']}: {af['cable_types']} ({af['feeder_count']} cables)"
                )

        except Exception as e:
            self.log_message(f"ERROR generating enclosure points: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_sum_span_distance_clicked(self):
        """Calculate total length of the selected Span layer and show a persistent result dialog."""
        from qgis.core import QgsDistanceArea, QgsProject, QgsUnitTypes
        from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton
        from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
        from qgis.PyQt.QtGui import QFont

        span_layer = self.comboBox_span_layer.currentLayer()
        if span_layer is None:
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.warning(None, "No Span Layer",
                                "Please select a Span (Route) layer first.")
            return

        if span_layer.geometryType() != 1:   # 1 = Line
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.warning(None, "Wrong Layer Type",
                                f"'{span_layer.name()}' is not a line layer.")
            return

        layer_name = span_layer.name()
        feature_count = span_layer.featureCount()

        # ── Worker thread ────────────────────────────────────────────────────
        class _Worker(QThread):
            finished = pyqtSignal(float, int)   # total_m, feature_count
            error    = pyqtSignal(str)

            def __init__(self, layer):
                super().__init__()
                self._layer = layer

            def run(self):
                try:
                    da = QgsDistanceArea()
                    da.setSourceCrs(
                        self._layer.crs(),
                        QgsProject.instance().transformContext())
                    da.setEllipsoid(QgsProject.instance().ellipsoid())
                    total = 0.0
                    count = 0
                    for feat in self._layer.getFeatures():
                        geom = feat.geometry()
                        if geom and not geom.isEmpty():
                            total += da.measureLength(geom)
                            count += 1
                    # Convert to metres
                    total_m = da.convertLengthMeasurement(
                        total, QgsUnitTypes.DistanceUnit.DistanceMeters)
                    self.finished.emit(total_m, count)
                except Exception as exc:
                    self.error.emit(str(exc))

        # ── Progress / waiting dialog (non-blocking) ─────────────────────────
        wait_dlg = QDialog(None)
        wait_dlg.setWindowTitle("Calculating…")
        wait_dlg.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint | Qt.WindowType.CustomizeWindowHint)
        wait_dlg.setFixedWidth(300)
        wait_lay = QVBoxLayout(wait_dlg)
        wait_lbl = QLabel(
            f"<b>Summing span distances…</b><br>"
            f"Layer: <i>{layer_name}</i><br>"
            f"{feature_count} features")
        wait_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wait_lay.addWidget(wait_lbl)
        wait_dlg.show()
        QApplication.processEvents()

        # ── Result dialog builder ─────────────────────────────────────────────
        def _show_result(total_m, counted):
            wait_dlg.close()

            from qgis.PyQt.QtWidgets import (QFrame, QHBoxLayout, QDoubleSpinBox,
                                             QLabel as _QL)

            res_dlg = QDialog(None)
            res_dlg.setWindowTitle("Span Layer — Total Distance")
            res_dlg.setWindowFlags(
                Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
            res_dlg.setMinimumWidth(380)
            res_lay = QVBoxLayout(res_dlg)
            res_lay.setSpacing(10)
            res_lay.setContentsMargins(18, 18, 18, 18)

            title_lbl = QLabel("📏  Span Layer — Total Distance")
            title_fnt = QFont()
            title_fnt.setBold(True)
            title_fnt.setPointSize(11)
            title_lbl.setFont(title_fnt)
            title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            res_lay.addWidget(title_lbl)

            # ── Base distance display ─────────────────────────────────────
            km = total_m / 1000.0
            base_lbl = QLabel(
                f"<table cellspacing='6'>"
                f"<tr><td><b>Layer:</b></td><td>{layer_name}</td></tr>"
                f"<tr><td><b>Features measured:</b></td><td>{counted:,}</td></tr>"
                f"<tr><td><b>Raw total distance:</b></td>"
                f"<td><span style='font-size:12pt; color:#555;'>"
                f"<b>{total_m:,.1f} m</b></span></td></tr>"
                f"<tr><td></td>"
                f"<td><span style='font-size:9pt; color:#888;'>"
                f"({km:,.3f} km)</span></td></tr>"
                f"</table>")
            base_lbl.setAlignment(Qt.AlignmentFlag.AlignLeft)
            res_lay.addWidget(base_lbl)

            # ── Divider ───────────────────────────────────────────────────
            div = QFrame()
            div.setFrameShape(QFrame.Shape.HLine)
            div.setStyleSheet("color: #ccc;")
            res_lay.addWidget(div)

            # ── Slack / Sag % row ─────────────────────────────────────────
            pct_row = QHBoxLayout()
            pct_lbl = _QL("Slack & Sag allowance:")
            pct_lbl.setToolTip(
                "Extra cable percentage added for slack, sag, splices and\n"
                "vertical drops on HLD cable quantity estimations.")
            pct_spin = QDoubleSpinBox()
            pct_spin.setRange(0.0, 100.0)
            pct_spin.setDecimals(1)
            pct_spin.setSingleStep(0.5)
            pct_spin.setSuffix(" %")
            pct_spin.setValue(22.0)
            pct_spin.setFixedWidth(90)
            pct_spin.setToolTip("Default 22 % — edit as required")
            pct_row.addWidget(pct_lbl)
            pct_row.addStretch()
            pct_row.addWidget(pct_spin)
            res_lay.addLayout(pct_row)

            # ── Adjusted distance display (updates live) ──────────────────
            adj_lbl = QLabel()
            adj_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            adj_lbl.setStyleSheet(
                "background: #eaf4ea; border: 1px solid #a8d5a8; "
                "border-radius: 5px; padding: 8px;")
            res_lay.addWidget(adj_lbl)

            def _update_adjusted():
                pct = pct_spin.value()
                adj_m  = total_m * (1.0 + pct / 100.0)
                adj_km = adj_m / 1000.0
                extra_m = adj_m - total_m
                adj_lbl.setText(
                    f"<div style='text-align:center;'>"
                    f"<span style='font-size:9pt; color:#555;'>Adjusted total (+{pct:.1f}%)</span><br>"
                    f"<span style='font-size:14pt; color:#1a6b3c; font-weight:bold;'>"
                    f"{adj_m:,.1f} m</span>"
                    f"<span style='font-size:9pt; color:#555;'>  ({adj_km:,.3f} km)</span><br>"
                    f"<span style='font-size:8pt; color:#888;'>"
                    f"+{extra_m:,.1f} m slack/sag allowance</span>"
                    f"</div>")

            pct_spin.valueChanged.connect(_update_adjusted)
            _update_adjusted()   # populate on open

            # ── Close button ──────────────────────────────────────────────
            close_btn = QPushButton("Close")
            close_btn.setStyleSheet(
                "QPushButton { background-color: #2a5b8a; color: white; "
                "font-weight: bold; padding: 5px 20px; border-radius: 4px; }"
                "QPushButton:hover { background-color: #336fa5; }")
            close_btn.clicked.connect(res_dlg.accept)
            res_lay.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)

            res_dlg.exec()   # modal — stays open until user clicks Close

        def _show_error(msg):
            wait_dlg.close()
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.critical(None, "Error Calculating Span Distance",
                                 f"An error occurred:\n{msg}")

        worker = _Worker(span_layer)
        worker.finished.connect(_show_result)
        worker.error.connect(_show_error)
        # Keep reference so GC doesn't destroy it
        self._span_dist_worker = worker
        worker.start()

    def on_sum_pole_numbers_clicked(self):
        """Count total poles across all Poles layers and show a persistent result dialog."""
        from qgis.core import QgsProject, QgsVectorLayer
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                         QPushButton, QMessageBox)
        from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
        from qgis.PyQt.QtGui import QFont

        # Find all poles layers (name starts with 'Poles_' and has pole_type field)
        pole_layers = []
        for lyr in QgsProject.instance().mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer):
                continue
            if lyr.geometryType() != 0:   # Point only
                continue
            ln = lyr.name().lower()
            fnames = [f.name() for f in lyr.fields()]
            if ln.startswith('poles_') and 'pole_type' in fnames:
                pole_layers.append(lyr)

        if not pole_layers:
            QMessageBox.warning(None, "No Poles Layer Found",
                                "No Poles layer was found in the project.\n"
                                "Run Generate Poles first.")
            return

        # ── Worker thread ──────────────────────────────────────────────────
        class _PoleWorker(QThread):
            # emits list of (layer_name, count) and grand total
            finished = pyqtSignal(list, int)
            error    = pyqtSignal(str)

            def __init__(self, layers):
                super().__init__()
                self._layers = layers

            def run(self):
                try:
                    results = []
                    total = 0
                    for lyr in self._layers:
                        cnt = lyr.featureCount()
                        results.append((lyr.name(), cnt))
                        total += cnt
                    self.finished.emit(results, total)
                except Exception as exc:
                    self.error.emit(str(exc))

        # ── Waiting dialog ─────────────────────────────────────────────────
        wait_dlg = QDialog(None)
        wait_dlg.setWindowTitle("Counting…")
        wait_dlg.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint | Qt.WindowType.CustomizeWindowHint)
        wait_dlg.setFixedWidth(280)
        wait_lay = QVBoxLayout(wait_dlg)
        wait_lbl = QLabel(
            f"<b>Counting poles…</b><br>"
            f"{len(pole_layers)} Poles layer(s) found")
        wait_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wait_lay.addWidget(wait_lbl)
        wait_dlg.show()
        QApplication.processEvents()

        def _show_result(results, total):
            wait_dlg.close()

            res_dlg = QDialog(None)
            res_dlg.setWindowTitle("Poles — Total Count")
            res_dlg.setWindowFlags(
                Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
            res_dlg.setMinimumWidth(340)
            res_lay = QVBoxLayout(res_dlg)
            res_lay.setSpacing(10)
            res_lay.setContentsMargins(18, 18, 18, 18)

            title_lbl = QLabel("🔢  Poles — Total Count")
            title_fnt = QFont()
            title_fnt.setBold(True)
            title_fnt.setPointSize(11)
            title_lbl.setFont(title_fnt)
            title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            res_lay.addWidget(title_lbl)

            # Build per-layer rows
            rows_html = "".join(
                f"<tr><td>&nbsp;&nbsp;{name}:</td>"
                f"<td align='right'><b>{cnt:,}</b></td></tr>"
                for name, cnt in results)
            info_lbl = QLabel(
                f"<table cellspacing='6'>"
                f"{rows_html}"
                f"<tr><td colspan='2'><hr/></td></tr>"
                f"<tr><td><b>Total Poles:</b></td>"
                f"<td align='right'><span style='font-size:13pt; color:#7a4a1e;'>"
                f"<b>{total:,}</b></span></td></tr>"
                f"</table>")
            info_lbl.setAlignment(Qt.AlignmentFlag.AlignLeft)
            res_lay.addWidget(info_lbl)

            close_btn = QPushButton("Close")
            close_btn.setStyleSheet(
                "QPushButton { background-color: #7a4a1e; color: white; "
                "font-weight: bold; padding: 5px 20px; border-radius: 4px; }"
                "QPushButton:hover { background-color: #9a5e28; }")
            close_btn.clicked.connect(res_dlg.accept)
            res_lay.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)

            res_dlg.exec()   # modal — stays open until user clicks Close

        def _show_error(msg):
            wait_dlg.close()
            QMessageBox.critical(None, "Error Counting Poles",
                                 f"An error occurred:\n{msg}")

        worker = _PoleWorker(pole_layers)
        worker.finished.connect(_show_result)
        worker.error.connect(_show_error)
        self._pole_count_worker = worker
        worker.start()

    def on_sum_demand_points_clicked(self):
        """Count total demand points in the Demand Points layer and show a persistent result dialog."""
        import sip
        from qgis.core import QgsProject, QgsVectorLayer
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                         QPushButton, QMessageBox)
        from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
        from qgis.PyQt.QtGui import QFont

        # Resolve demand points layer — prefer stored reference, then search by name
        dp_layer = None
        try:
            if self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                dp_layer = self.demand_points_layer
        except Exception:
            pass

        if not dp_layer:
            for lyr in QgsProject.instance().mapLayers().values():
                if not isinstance(lyr, QgsVectorLayer):
                    continue
                if lyr.geometryType() != 0:   # Point only
                    continue
                ln = lyr.name().lower()
                if 'demand points' in ln or 'demand_points' in ln:
                    dp_layer = lyr
                    break

        if not dp_layer:
            QMessageBox.warning(None, "No Demand Points Layer Found",
                                "No Demand Points layer was found in the project.\n"
                                "Please generate demand points first.")
            return

        # ── Worker thread ──────────────────────────────────────────────────
        class _DPWorker(QThread):
            finished = pyqtSignal(str, int)
            error    = pyqtSignal(str)

            def __init__(self, layer):
                super().__init__()
                self._layer = layer

            def run(self):
                try:
                    cnt = self._layer.featureCount()
                    self.finished.emit(self._layer.name(), cnt)
                except Exception as exc:
                    self.error.emit(str(exc))

        # ── Waiting dialog ─────────────────────────────────────────────────
        wait_dlg = QDialog(None)
        wait_dlg.setWindowTitle("Counting…")
        wait_dlg.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint | Qt.WindowType.CustomizeWindowHint)
        wait_dlg.setFixedWidth(280)
        wait_lay = QVBoxLayout(wait_dlg)
        wait_lbl = QLabel(f"<b>Counting demand points…</b><br>{dp_layer.name()}")
        wait_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wait_lay.addWidget(wait_lbl)
        wait_dlg.show()
        QApplication.processEvents()

        def _show_result(layer_name, total):
            wait_dlg.close()

            res_dlg = QDialog(None)
            res_dlg.setWindowTitle("Demand Points — Total Count")
            res_dlg.setWindowFlags(
                Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
            res_dlg.setMinimumWidth(340)
            res_lay = QVBoxLayout(res_dlg)
            res_lay.setSpacing(10)
            res_lay.setContentsMargins(18, 18, 18, 18)

            title_lbl = QLabel("🏠  Demand Points — Total Count")
            title_fnt = QFont()
            title_fnt.setBold(True)
            title_fnt.setPointSize(11)
            title_lbl.setFont(title_fnt)
            title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            res_lay.addWidget(title_lbl)

            info_lbl = QLabel(
                f"<table cellspacing='6'>"
                f"<tr><td>Layer:</td><td><b>{layer_name}</b></td></tr>"
                f"<tr><td colspan='2'><hr/></td></tr>"
                f"<tr><td><b>Total Demand Points:</b></td>"
                f"<td align='right'><span style='font-size:13pt; color:#1a5276;'>"
                f"<b>{total:,}</b></span></td></tr>"
                f"</table>")
            info_lbl.setAlignment(Qt.AlignmentFlag.AlignLeft)
            res_lay.addWidget(info_lbl)

            close_btn = QPushButton("Close")
            close_btn.setStyleSheet(
                "QPushButton { background-color: #1a5276; color: white; "
                "font-weight: bold; padding: 5px 20px; border-radius: 4px; }"
                "QPushButton:hover { background-color: #2471a3; }")
            close_btn.clicked.connect(res_dlg.accept)
            res_lay.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)

            res_dlg.exec()   # stays open until user clicks Close

        def _show_error(msg):
            wait_dlg.close()
            QMessageBox.critical(None, "Error Counting Demand Points",
                                 f"An error occurred:\n{msg}")

        worker = _DPWorker(dp_layer)
        worker.finished.connect(_show_result)
        worker.error.connect(_show_error)
        self._dp_count_worker = worker
        worker.start()

    def on_auto_sum_clicked(self):
        """Run Span Distance + Pole Count + Demand Count in one thread and show combined result."""
        import sip
        from qgis.core import (QgsProject, QgsVectorLayer,
                               QgsDistanceArea, QgsUnitTypes)
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                         QPushButton, QMessageBox)
        from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
        from qgis.PyQt.QtGui import QFont

        # ── Resolve span layer ────────────────────────────────────────────
        span_layer = self.comboBox_span_layer.currentLayer()
        span_ok = span_layer is not None and span_layer.geometryType() == 1

        # ── Resolve pole layers ───────────────────────────────────────────
        pole_layers = []
        for lyr in QgsProject.instance().mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer):
                continue
            if lyr.geometryType() != 0:
                continue
            ln = lyr.name().lower()
            fnames = [f.name() for f in lyr.fields()]
            if ln.startswith('poles_') and 'pole_type' in fnames:
                pole_layers.append(lyr)

        # ── Resolve demand points layer ───────────────────────────────────
        dp_layer = None
        try:
            if self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                dp_layer = self.demand_points_layer
        except Exception:
            pass
        if not dp_layer:
            for lyr in QgsProject.instance().mapLayers().values():
                if not isinstance(lyr, QgsVectorLayer):
                    continue
                if lyr.geometryType() != 0:
                    continue
                ln = lyr.name().lower()
                if 'demand points' in ln or 'demand_points' in ln:
                    dp_layer = lyr
                    break

        if not span_ok and not pole_layers and not dp_layer:
            QMessageBox.warning(None, "AutoSum",
                                "No Span layer, Poles layers, or Demand Points layer found.\n"
                                "Please generate network layers first.")
            return

        # ── Single worker thread ──────────────────────────────────────────
        class _AutoSumWorker(QThread):
            # span_m, span_name, span_feat_count, pole_results, pole_total, dp_name, dp_count
            finished = pyqtSignal(float, str, int, list, int, str, int)
            error    = pyqtSignal(str)

            def __init__(self, s_layer, p_layers, d_layer):
                super().__init__()
                self._sl = s_layer
                self._pl = p_layers
                self._dl = d_layer

            def run(self):
                try:
                    # Span distance
                    span_m, span_name, span_cnt = 0.0, '', 0
                    if self._sl:
                        da = QgsDistanceArea()
                        da.setSourceCrs(
                            self._sl.crs(),
                            QgsProject.instance().transformContext())
                        da.setEllipsoid(QgsProject.instance().ellipsoid())
                        for feat in self._sl.getFeatures():
                            geom = feat.geometry()
                            if geom and not geom.isEmpty():
                                span_m += da.measureLength(geom)
                                span_cnt += 1
                        span_m = da.convertLengthMeasurement(
                            span_m, QgsUnitTypes.DistanceUnit.DistanceMeters)
                        span_name = self._sl.name()

                    # Pole counts
                    pole_results, pole_total = [], 0
                    for lyr in self._pl:
                        cnt = lyr.featureCount()
                        pole_results.append((lyr.name(), cnt))
                        pole_total += cnt

                    # Demand count
                    dp_name, dp_count = '', 0
                    if self._dl:
                        dp_count = self._dl.featureCount()
                        dp_name  = self._dl.name()

                    self.finished.emit(
                        span_m, span_name, span_cnt,
                        pole_results, pole_total,
                        dp_name, dp_count)
                except Exception as exc:
                    self.error.emit(str(exc))

        # ── Waiting dialog ────────────────────────────────────────────────
        wait_dlg = QDialog(None)
        wait_dlg.setWindowTitle("AutoSum — Calculating…")
        wait_dlg.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint | Qt.WindowType.CustomizeWindowHint)
        wait_dlg.setFixedWidth(320)
        wait_lay = QVBoxLayout(wait_dlg)
        wait_lbl = QLabel(
            "<b>AutoSum running…</b><br>"
            "Calculating Span Distance, Poles &amp; Demand Points.")
        wait_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wait_lay.addWidget(wait_lbl)
        wait_dlg.show()
        QApplication.processEvents()

        # ── Result dialog ─────────────────────────────────────────────────
        def _show_result(span_m, span_name, span_cnt,
                         pole_results, pole_total, dp_name, dp_count):
            wait_dlg.close()

            res_dlg = QDialog(None)
            res_dlg.setWindowTitle("AutoSum — Network Summary")
            res_dlg.setWindowFlags(
                Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
            res_dlg.setMinimumWidth(380)
            res_lay = QVBoxLayout(res_dlg)
            res_lay.setSpacing(12)
            res_lay.setContentsMargins(20, 20, 20, 20)

            # Title
            title_lbl = QLabel("🧮  AutoSum — Network Summary")
            title_fnt = QFont()
            title_fnt.setBold(True)
            title_fnt.setPointSize(11)
            title_lbl.setFont(title_fnt)
            title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            res_lay.addWidget(title_lbl)

            # ── Span Distance section ─────────────────────────────────────
            span_header = QLabel("📏  Span Distance")
            span_hfnt = QFont()
            span_hfnt.setBold(True)
            span_hfnt.setPointSize(9)
            span_header.setFont(span_hfnt)
            span_header.setStyleSheet("color: #1a6b3c;")
            res_lay.addWidget(span_header)

            if span_name:
                km = span_m / 1000.0
                span_html = (
                    f"<table cellspacing='4'>"
                    f"<tr><td>Layer:</td><td><b>{span_name}</b></td></tr>"
                    f"<tr><td>Features:</td><td>{span_cnt:,}</td></tr>"
                    f"<tr><td>Total:</td>"
                    f"<td><b><span style='color:#1a6b3c; font-size:12pt;'>"
                    f"{span_m:,.1f} m</span></b>"
                    f"&nbsp;&nbsp;<span style='color:#555;'>({km:,.3f} km)</span></td></tr>"
                    f"</table>")
            else:
                span_html = "<i style='color:#888;'>No span layer selected.</i>"
            span_lbl = QLabel(span_html)
            res_lay.addWidget(span_lbl)

            # ── Pole Count section ────────────────────────────────────────
            pole_header = QLabel("🔢  Pole Count")
            pole_hfnt = QFont()
            pole_hfnt.setBold(True)
            pole_hfnt.setPointSize(9)
            pole_header.setFont(pole_hfnt)
            pole_header.setStyleSheet("color: #7a4a1e;")
            res_lay.addWidget(pole_header)

            if pole_results:
                rows = "".join(
                    f"<tr><td>&nbsp;&nbsp;{n}:</td>"
                    f"<td align='right'><b>{c:,}</b></td></tr>"
                    for n, c in pole_results)
                pole_html = (
                    f"<table cellspacing='4'>{rows}"
                    f"<tr><td colspan='2'><hr/></td></tr>"
                    f"<tr><td><b>Total:</b></td>"
                    f"<td align='right'><b><span style='color:#7a4a1e; font-size:12pt;'>"
                    f"{pole_total:,}</span></b></td></tr>"
                    f"</table>")
            else:
                pole_html = "<i style='color:#888;'>No Poles layers found.</i>"
            pole_lbl = QLabel(pole_html)
            res_lay.addWidget(pole_lbl)

            # ── Demand Points section ─────────────────────────────────────
            dp_header = QLabel("🏠  Demand Points")
            dp_hfnt = QFont()
            dp_hfnt.setBold(True)
            dp_hfnt.setPointSize(9)
            dp_header.setFont(dp_hfnt)
            dp_header.setStyleSheet("color: #1a5276;")
            res_lay.addWidget(dp_header)

            if dp_name:
                dp_html = (
                    f"<table cellspacing='4'>"
                    f"<tr><td>Layer:</td><td><b>{dp_name}</b></td></tr>"
                    f"<tr><td><b>Total:</b></td>"
                    f"<td><b><span style='color:#1a5276; font-size:12pt;'>"
                    f"{dp_count:,}</span></b></td></tr>"
                    f"</table>")
            else:
                dp_html = "<i style='color:#888;'>No Demand Points layer found.</i>"
            dp_lbl = QLabel(dp_html)
            res_lay.addWidget(dp_lbl)

            # ── Close button ──────────────────────────────────────────────
            close_btn = QPushButton("Close")
            close_btn.setStyleSheet(
                "QPushButton { background-color: #4a235a; color: white; "
                "font-weight: bold; padding: 5px 20px; border-radius: 4px; }"
                "QPushButton:hover { background-color: #6c3483; }")
            close_btn.clicked.connect(res_dlg.accept)
            res_lay.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)

            res_dlg.exec()   # stays open until user clicks Close

        def _show_error(msg):
            wait_dlg.close()
            QMessageBox.critical(None, "AutoSum Error",
                                 f"An error occurred:\n{msg}")

        worker = _AutoSumWorker(
            span_layer if span_ok else None, pole_layers, dp_layer)
        worker.finished.connect(_show_result)
        worker.error.connect(_show_error)
        self._autosum_worker = worker
        worker.start()

    def on_span_evaluate_clicked(self):
        """Snap and merge span lines within a tolerance to form one continuous network.

        Strategy:
          1. For every line endpoint within `snap_radius` of another endpoint (but
             not the same feature) → move both to their midpoint (snap together).
          2. For overlapping / nearly-overlapping lines → dissolve/merge them into
             a single continuous polyline where possible.
          3. All edits are made in-place on the selected span layer.
          4. A full report is shown on completion.
        """
        from qgis.core import (QgsGeometry,
                               QgsPointXY, QgsFeature)
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout,
                                         QFormLayout, QLabel, QPushButton,
                                         QDoubleSpinBox, QCheckBox,
                                         QMessageBox, QTextEdit)
        from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
        from qgis.PyQt.QtGui import QFont

        span_layer = self.comboBox_span_layer.currentLayer()
        if span_layer is None:
            QMessageBox.warning(None, "Span Evaluate & Snap",
                                "Please select a Span (Route) layer first.")
            return
        if span_layer.geometryType() != 1:
            QMessageBox.warning(None, "Span Evaluate & Snap",
                                f"'{span_layer.name()}' is not a line layer.")
            return

        # ── Settings dialog ───────────────────────────────────────────────
        dlg = QDialog(None)
        dlg.setWindowTitle("Span Evaluate & Snap — Settings")
        dlg.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                           Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
        dlg.setMinimumWidth(380)
        lay = QVBoxLayout(dlg)
        lay.setSpacing(10)
        lay.setContentsMargins(18, 18, 18, 18)

        hdr = QLabel("🔗  Span Evaluate & Snap")
        hf = QFont(); hf.setBold(True); hf.setPointSize(10)
        hdr.setFont(hf); hdr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(hdr)

        desc = QLabel(
            "Snaps line endpoints that are within the snap radius to each\n"
            "other, and merges lines that share endpoints into a single\n"
            "continuous network. Edits the layer in-place.")
        desc.setWordWrap(True)
        lay.addWidget(desc)

        form = QFormLayout()
        radius_spin = QDoubleSpinBox()
        radius_spin.setRange(0.1, 100.0)
        radius_spin.setDecimals(1)
        radius_spin.setValue(4.0)
        radius_spin.setSuffix(" m")
        radius_spin.setToolTip("Endpoints within this distance will be snapped together.")
        form.addRow("Snap radius (m):", radius_spin)

        dry_chk = QCheckBox("Dry run — report only, do not modify layer")
        dry_chk.setChecked(False)
        lay.addLayout(form)
        lay.addWidget(dry_chk)

        btn_row = QHBoxLayout()
        run_btn = QPushButton("Run")
        run_btn.setStyleSheet(
            "QPushButton { background-color: #2e4057; color: white; font-weight: bold; "
            "padding: 5px 18px; border-radius: 4px; }"
            "QPushButton:hover { background-color: #3d5270; }")
        cancel_btn = QPushButton("Cancel")
        btn_row.addWidget(run_btn); btn_row.addWidget(cancel_btn)
        lay.addLayout(btn_row)
        run_btn.clicked.connect(dlg.accept)
        cancel_btn.clicked.connect(dlg.reject)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        snap_radius = radius_spin.value()
        dry_run = dry_chk.isChecked()

        # ── Worker ────────────────────────────────────────────────────────
        class _SnapWorker(QThread):
            finished = pyqtSignal(int, int, list, dict)   # snaps, merges, report_lines, backup
            error    = pyqtSignal(str)

            def __init__(self, layer, radius, dry):
                super().__init__()
                self._layer  = layer
                self._radius = radius
                self._dry    = dry

            def run(self):
                try:
                    import math
                    layer  = self._layer
                    radius = self._radius
                    dry    = self._dry
                    report = []

                    # ----------------------------------------------------------
                    # STEP 1: Collect all endpoints
                    # endpoint_map: {fake_id: (fid, 'start'|'end', QgsPointXY)}
                    # ----------------------------------------------------------
                    endpoint_map = {}
                    fid_geoms = {}   # fid -> list of vertex QgsPointXY
                    eid = 0
                    for feat in layer.getFeatures():
                        geom = feat.geometry()
                        if not geom or geom.isEmpty():
                            continue
                        if geom.isMultipart():
                            parts = geom.asMultiPolyline()
                        else:
                            parts = [geom.asPolyline()]
                        fid_geoms[feat.id()] = parts
                        for part in parts:
                            if len(part) >= 2:
                                endpoint_map[eid] = (feat.id(), 'start', part[0])
                                eid += 1
                                endpoint_map[eid] = (feat.id(), 'end', part[-1])
                                eid += 1

                    total_endpoints = len(endpoint_map)
                    report.append(f"Layer: {layer.name()}")
                    report.append(f"Features: {layer.featureCount()}")
                    report.append(f"Endpoints collected: {total_endpoints}")
                    report.append(f"Snap radius: {radius} m")
                    report.append("")

                    if total_endpoints == 0:
                        report.append("No endpoints found — check layer geometry.")
                        self.finished.emit(0, 0, report, {})
                        return

                    # ----------------------------------------------------------
                    # STEP 2: Build spatial index over endpoint points
                    # ----------------------------------------------------------
                    idx = QgsSpatialIndex()
                    for eid2, (fid, role, pt) in endpoint_map.items():
                        f = QgsFeature()
                        f.setId(eid2)
                        f.setGeometry(QgsGeometry.fromPointXY(pt))
                        idx.insertFeature(f)

                    # ----------------------------------------------------------
                    # STEP 2b: Identify eligible (non-terminal) endpoints
                    # An endpoint is eligible for snapping ONLY if the OTHER end
                    # of its own feature is already connected to the network
                    # (i.e., touches another feature within connect_threshold).
                    # This prevents true dead-end branch tips from being snapped.
                    # ----------------------------------------------------------
                    from qgis.core import QgsRectangle
                    connect_threshold = min(0.5, radius / 4.0)

                    # Build fid → {role: eid} lookup
                    fid_to_eids = {}
                    for eid2, (fid2, role2, pt2) in endpoint_map.items():
                        fid_to_eids.setdefault(fid2, {})[role2] = eid2

                    def _is_connected(pt, own_fid):
                        """True if pt touches any endpoint from a different feature."""
                        nearby = idx.intersects(QgsRectangle(
                            pt.x()-connect_threshold, pt.y()-connect_threshold,
                            pt.x()+connect_threshold, pt.y()+connect_threshold))
                        for nid in nearby:
                            nfid, _, npt = endpoint_map[nid]
                            if nfid == own_fid:
                                continue
                            if math.sqrt((pt.x()-npt.x())**2 +
                                         (pt.y()-npt.y())**2) <= connect_threshold:
                                return True
                        return False

                    # An endpoint is eligible if the OTHER end of its feature is connected
                    eligible_eids = set()
                    for fid2, roles in fid_to_eids.items():
                        s_eid = roles.get('start')
                        e_eid = roles.get('end')
                        if s_eid is None or e_eid is None:
                            continue
                        _, _, s_pt = endpoint_map[s_eid]
                        _, _, e_pt = endpoint_map[e_eid]
                        if _is_connected(e_pt, fid2):
                            eligible_eids.add(s_eid)   # start is eligible (end is anchored)
                        if _is_connected(s_pt, fid2):
                            eligible_eids.add(e_eid)   # end is eligible (start is anchored)

                    report.append(f"Eligible (non-terminal) endpoints: {len(eligible_eids)}")

                    # ----------------------------------------------------------
                    # STEP 3: Find dangling endpoints (no neighbour within radius
                    #         from a DIFFERENT feature) — terminals excluded
                    # ----------------------------------------------------------
                    # We'll build a list of snap pairs (each endpoint used once)
                    snap_pairs = []   # [(eid_a, eid_b, midpoint)]
                    used = set()

                    for eid_a, (fid_a, role_a, pt_a) in endpoint_map.items():
                        if eid_a in used:
                            continue
                        # Skip true terminal ends — only snap network-interior gaps
                        if eid_a not in eligible_eids:
                            continue
                        nearby_ids = idx.intersects(QgsRectangle(
                            pt_a.x()-radius, pt_a.y()-radius,
                            pt_a.x()+radius, pt_a.y()+radius))

                        best_dist = radius + 1.0
                        best_eid  = None
                        for eid_b in nearby_ids:
                            if eid_b == eid_a or eid_b in used:
                                continue
                            if eid_b not in eligible_eids:
                                continue   # also skip terminal partner endpoints
                            fid_b, role_b, pt_b = endpoint_map[eid_b]
                            if fid_b == fid_a:
                                continue   # same feature — skip
                            dist = math.sqrt((pt_a.x()-pt_b.x())**2 +
                                             (pt_a.y()-pt_b.y())**2)
                            if dist <= radius and dist < best_dist:
                                best_dist = dist
                                best_eid  = eid_b

                        if best_eid is not None:
                            fid_b, role_b, pt_b = endpoint_map[best_eid]
                            mid = QgsPointXY(
                                (pt_a.x()+pt_b.x())/2.0,
                                (pt_a.y()+pt_b.y())/2.0)
                            snap_pairs.append((eid_a, fid_a, role_a, pt_a,
                                               best_eid, fid_b, role_b, pt_b,
                                               mid, best_dist))
                            used.add(eid_a)
                            used.add(best_eid)

                    report.append(f"Snap pairs found: {len(snap_pairs)}")

                    # How many endpoints are still dangling (no partner found)?
                    paired_eids = used
                    dangling = [eid2 for eid2, (fid2, r2, pt2) in endpoint_map.items()
                                if eid2 not in paired_eids]
                    report.append(f"Still-dangling endpoints after snap: {len(dangling)}")
                    report.append("")

                    if dry or not snap_pairs:
                        for sp in snap_pairs:
                            eid_a2, fid_a2, role_a2, pt_a2, eid_b2, fid_b2, role_b2, pt_b2, mid2, dist2 = sp
                            report.append(
                                f"  SNAP fid={fid_a2}({role_a2}) ↔ fid={fid_b2}({role_b2})  "
                                f"dist={dist2:.3f}m → midpoint({mid2.x():.2f},{mid2.y():.2f})")
                        if not snap_pairs:
                            report.append(
                                f"  No snap pairs found within {radius} m.\n"
                                f"  The network may already be connected, or try increasing the radius.")
                        self.finished.emit(0, 0, report, {})
                        return

                    # ----------------------------------------------------------
                    # BACKUP: Capture all geometries before any edits
                    # ----------------------------------------------------------
                    backup_geoms = {}
                    for feat in layer.getFeatures():
                        g = feat.geometry()
                        backup_geoms[feat.id()] = g.asWkt() if g and not g.isEmpty() else None
                    backup = {
                        'layer_id':   layer.id(),
                        'layer_name': layer.name(),
                        'features':   backup_geoms,
                    }

                    # ----------------------------------------------------------
                    # STEP 4: Apply snaps — move endpoints to midpoints
                    # Build a dict of {fid: {'start': new_pt, 'end': new_pt}}
                    # ----------------------------------------------------------
                    snap_updates = {}   # fid -> {role: new QgsPointXY}
                    for sp in snap_pairs:
                        eid_a2, fid_a2, role_a2, pt_a2, eid_b2, fid_b2, role_b2, pt_b2, mid2, dist2 = sp
                        snap_updates.setdefault(fid_a2, {})[role_a2] = mid2
                        snap_updates.setdefault(fid_b2, {})[role_b2] = mid2

                    layer.startEditing()
                    snaps_applied = 0
                    for fid_edit, roles in snap_updates.items():
                        feat = layer.getFeature(fid_edit)
                        geom = feat.geometry()
                        if not geom or geom.isEmpty():
                            continue
                        if geom.isMultipart():
                            parts = geom.asMultiPolyline()
                            changed = False
                            new_parts = []
                            for part in parts:
                                if len(part) < 2:
                                    new_parts.append(part)
                                    continue
                                pl = list(part)
                                if 'start' in roles:
                                    pl[0] = roles['start']
                                    changed = True
                                if 'end' in roles:
                                    pl[-1] = roles['end']
                                    changed = True
                                new_parts.append(pl)
                            if changed:
                                new_geom = QgsGeometry.fromMultiPolylineXY(new_parts)
                                layer.changeGeometry(fid_edit, new_geom)
                                snaps_applied += 1
                        else:
                            pts = list(geom.asPolyline())
                            if len(pts) < 2:
                                continue
                            changed = False
                            if 'start' in roles:
                                pts[0] = roles['start']
                                changed = True
                            if 'end' in roles:
                                pts[-1] = roles['end']
                                changed = True
                            if changed:
                                new_geom = QgsGeometry.fromPolylineXY(pts)
                                layer.changeGeometry(fid_edit, new_geom)
                                snaps_applied += 1

                    layer.commitChanges()
                    layer.triggerRepaint()

                    report.append(f"✅ Snaps applied: {snaps_applied} feature(s) updated.")
                    report.append("")

                    # ----------------------------------------------------------
                    # STEP 5: Merge connected lines using QGIS dissolve
                    # After snapping, features whose endpoints now touch can be
                    # dissolved into single polylines using the processing framework
                    # ----------------------------------------------------------
                    merges = 0
                    try:
                        import processing
                        result = processing.run("native:dissolve", {
                            'INPUT': layer,
                            'FIELD': [],
                            'SEPARATE_DISJOINT': False,
                            'OUTPUT': 'TEMPORARY_OUTPUT'
                        })
                        merged_layer = result['OUTPUT']
                        orig_count = layer.featureCount()
                        merged_count = merged_layer.featureCount()
                        merges = orig_count - merged_count

                        if merges > 0:
                            report.append(
                                f"🔗 Merge: {orig_count} lines → {merged_count} "
                                f"(reduced by {merges})")
                            # Replace features in original layer with merged result
                            layer.startEditing()
                            layer.selectAll()
                            layer.deleteSelectedFeatures()
                            merged_feats = [f for f in merged_layer.getFeatures()]
                            layer.dataProvider().addFeatures(merged_feats)
                            layer.commitChanges()
                            layer.triggerRepaint()
                            report.append("✅ Merged features written back to layer.")
                        else:
                            report.append(
                                "ℹ️  No further line merges possible after snapping.")
                    except Exception as me:
                        report.append(f"ℹ️  Merge step skipped: {me}")

                    report.append("")
                    report.append("Done. Reload the layer in QGIS if display looks stale.")
                    self.finished.emit(snaps_applied, merges, report, backup)

                except Exception as exc:
                    import traceback
                    self.error.emit(str(exc) + "\n" + traceback.format_exc())

        # ── Wait dialog ───────────────────────────────────────────────────
        wait_dlg = QDialog(None)
        wait_dlg.setWindowTitle("Span Evaluate — Running…")
        wait_dlg.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint | Qt.WindowType.CustomizeWindowHint)
        wait_dlg.setFixedWidth(340)
        wl = QVBoxLayout(wait_dlg)
        wl.addWidget(QLabel(
            f"<b>Evaluating span layer…</b><br>"
            f"Layer: <i>{span_layer.name()}</i><br>"
            f"Snap radius: {snap_radius} m"))
        wait_dlg.show()
        QApplication.processEvents()

        def _show_result(snaps, merges, report, backup):
            wait_dlg.close()
            # Store backup on widget so the restore button can use it
            if backup and snaps > 0:
                self._span_snap_backup = backup
                self.pushButton_restore_span_backup.setEnabled(True)
                self.pushButton_restore_span_backup.setToolTip(
                    f"Restore '{backup.get('layer_name', '')}' to its state before the last snap "
                    f"({len(backup.get('features', {}))} features backed up)")
            res_dlg = QDialog(None)
            title = ("Span Evaluate — Dry Run" if dry_run else
                     f"Span Evaluate — {snaps} snap(s), {merges} merge(s)")
            res_dlg.setWindowTitle(title)
            res_dlg.setWindowFlags(
                Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
            res_dlg.setMinimumWidth(500)
            res_dlg.setMinimumHeight(360)
            r_lay = QVBoxLayout(res_dlg)
            r_lay.setContentsMargins(18, 18, 18, 18)

            hdr2 = QLabel(f"🔗  {title}")
            hf2 = QFont(); hf2.setBold(True); hf2.setPointSize(10)
            hdr2.setFont(hf2); hdr2.setAlignment(Qt.AlignmentFlag.AlignCenter)
            r_lay.addWidget(hdr2)

            if backup and snaps > 0:
                note = QLabel("💾  A backup of the original layer was saved.\n"
                              "    Use '↩ Restore Span Backup' to undo these changes.")
                note.setStyleSheet("color: #7a3b2e; font-style: italic;")
                r_lay.addWidget(note)

            txt = QTextEdit()
            txt.setReadOnly(True)
            txt.setPlainText("\n".join(report))
            txt.setStyleSheet("font-family: monospace; font-size: 9pt;")
            r_lay.addWidget(txt)

            close_btn = QPushButton("Close")
            close_btn.setStyleSheet(
                "QPushButton { background-color: #2e4057; color: white; "
                "font-weight: bold; padding: 5px 20px; border-radius: 4px; }"
                "QPushButton:hover { background-color: #3d5270; }")
            close_btn.clicked.connect(res_dlg.accept)
            r_lay.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)
            res_dlg.exec()

        def _show_error(msg):
            wait_dlg.close()
            QMessageBox.critical(None, "Span Evaluate Error",
                                 f"An error occurred:\n{msg}")

        worker = _SnapWorker(span_layer, snap_radius, dry_run)
        worker.finished.connect(_show_result)
        worker.error.connect(_show_error)
        self._snap_worker = worker
        worker.start()

    def on_restore_span_backup_clicked(self):
        """Restore the span layer to the geometry state captured before the last Span Evaluate & Snap."""
        from qgis.core import QgsProject, QgsGeometry
        from qgis.PyQt.QtWidgets import QMessageBox

        backup = getattr(self, '_span_snap_backup', None)
        if not backup:
            QMessageBox.information(None, "Restore Span Backup",
                                    "No backup available.\n\n"
                                    "Run Span Evaluate & Snap first (not dry run) to create a backup.")
            return

        layer_id   = backup.get('layer_id')
        layer_name = backup.get('layer_name', 'unknown')
        features   = backup.get('features', {})

        # Resolve layer
        layer = QgsProject.instance().mapLayer(layer_id)
        if layer is None:
            QMessageBox.warning(None, "Restore Span Backup",
                                f"Layer '{layer_name}' (id: {layer_id}) is no longer in the project.\n"
                                "Cannot restore.")
            return

        reply = QMessageBox.question(
            None, "Restore Span Backup",
            f"This will restore <b>{layer_name}</b> to its state before the last snap.<br><br>"
            f"<b>{len(features)}</b> feature geometry/geometries will be reverted.<br><br>"
            "Are you sure?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return

        layer.startEditing()
        restored = 0
        errors = 0
        for fid, wkt in features.items():
            if wkt is None:
                continue
            geom = QgsGeometry.fromWkt(wkt)
            if geom and not geom.isEmpty():
                if layer.changeGeometry(fid, geom):
                    restored += 1
                else:
                    errors += 1

        layer.commitChanges()
        layer.triggerRepaint()

        # Clear backup so the restore button can't be used again for the same snap
        self._span_snap_backup = None
        self.pushButton_restore_span_backup.setEnabled(False)
        self.pushButton_restore_span_backup.setToolTip(
            "Restore the span layer to the state before the last Span Evaluate & Snap was applied")

        msg = (f"✅ Restore complete.\n\n"
               f"Layer: {layer_name}\n"
               f"Features restored: {restored}")
        if errors:
            msg += f"\nErrors: {errors} (feature IDs may have changed after merge step)"
        QMessageBox.information(None, "Restore Span Backup", msg)

    def on_explode_span_clicked(self):
        """Explode the span layer into individual 2-point segments.

        Each polyline (or multipart polyline) is broken into its constituent
        straight-line segments, one segment per feature.  This is the reverse
        of a dissolve/merge and restores the layer to separate line segments.
        """
        from qgis.core import QgsGeometry, QgsFeature
        from qgis.PyQt.QtWidgets import QMessageBox, QApplication
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtGui import QCursor

        span_layer = self.comboBox_span_layer.currentLayer()
        if span_layer is None:
            QMessageBox.warning(None, "Explode to Segments",
                                "Please select a Span (Route) layer first.")
            return
        if span_layer.geometryType() != 1:
            QMessageBox.warning(None, "Explode to Segments",
                                f"'{span_layer.name()}' is not a line layer.")
            return

        feat_count = span_layer.featureCount()
        reply = QMessageBox.question(
            None, "Explode to Segments",
            f"Break all lines in <b>{span_layer.name()}</b> into individual 2-point segments?<br><br>"
            f"Current feature count: <b>{feat_count}</b><br>"
            "Each polyline with N vertices will become N–1 separate features.<br><br>"
            "This cannot be undone automatically — save a backup first if needed.<br>"
            "Continue?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return

        QApplication.setOverrideCursor(QCursor(Qt.CursorShape.WaitCursor))
        QApplication.processEvents()

        try:
            # Collect all existing features and their attribute data
            all_feats = list(span_layer.getFeatures())
            fields = span_layer.fields()

            # Build new segment features
            new_segments = []
            for feat in all_feats:
                geom = feat.geometry()
                if not geom or geom.isEmpty():
                    continue
                if geom.isMultipart():
                    parts = geom.asMultiPolyline()
                else:
                    parts = [geom.asPolyline()]

                attrs = feat.attributes()
                for part in parts:
                    for i in range(len(part) - 1):
                        seg = QgsFeature(fields)
                        seg.setAttributes(attrs)
                        seg.setGeometry(QgsGeometry.fromPolylineXY([part[i], part[i+1]]))
                        new_segments.append(seg)

            if not new_segments:
                QApplication.restoreOverrideCursor()
                QMessageBox.information(None, "Explode to Segments",
                                        "No segments could be extracted from the layer.")
                return

            # Replace layer contents
            span_layer.startEditing()
            span_layer.selectAll()
            span_layer.deleteSelectedFeatures()
            span_layer.dataProvider().addFeatures(new_segments)
            span_layer.commitChanges()
            span_layer.triggerRepaint()

            QApplication.restoreOverrideCursor()
            QMessageBox.information(
                None, "Explode to Segments — Done",
                f"✅ Explode complete.\n\n"
                f"Layer: {span_layer.name()}\n"
                f"Original features: {feat_count}\n"
                f"Segments created: {len(new_segments)}")

        except Exception as exc:
            QApplication.restoreOverrideCursor()
            import traceback
            QMessageBox.critical(None, "Explode to Segments — Error",
                                 f"An error occurred:\n{exc}\n\n{traceback.format_exc()}")

    def on_validate_span_network_clicked(self):
        """Validate span network topology and identify connectivity issues."""
        from qgis.core import QgsVectorLayer, QgsProject, QgsGeometry, QgsPointXY, QgsFeature
        from qgis.PyQt.QtCore import QMetaType
        import math
        
        self.log_message("="*60)
        self.log_message("VALIDATING SPAN NETWORK TOPOLOGY")
        self.log_message("="*60)
        self._start_timer()
        span_layer = self.comboBox_span_layer.currentLayer()
        if not span_layer:
            self.log_message("ERROR: No span layer selected")
            return
        
        # Validate geometry type
        geom_type = span_layer.geometryType()
        if geom_type != 1:  # LineString
            self.log_message(f"ERROR: Span layer must contain LineString geometry (found type {geom_type})")
            return
        
        self.log_message(f"Analyzing span layer: {span_layer.name()}")
        self.log_message(f"Total features: {span_layer.featureCount()}")
        
        # Build endpoint catalog
        endpoints = {}  # {(x, y): [feature_ids]}
        segment_endpoints = {}  # {feature_id: [(x1, y1), (x2, y2)]}
        valid_segments = 0
        
        for feat in span_layer.getFeatures():
            geom = feat.geometry()
            if geom and not geom.isNull():
                if geom.wkbType() in [2, 5]:  # LineString or MultiLineString
                    if geom.isMultipart():
                        lines = geom.asMultiPolyline()
                        if lines:
                            points = lines[0]
                        else:
                            continue
                    else:
                        points = geom.asPolyline()
                    
                    if len(points) >= 2:
                        valid_segments += 1
                        start = (round(points[0].x(), 4), round(points[0].y(), 4))
                        end = (round(points[-1].x(), 4), round(points[-1].y(), 4))
                        
                        segment_endpoints[feat.id()] = (start, end)
                        
                        # Track which segments connect to each endpoint
                        if start not in endpoints:
                            endpoints[start] = []
                        endpoints[start].append(feat.id())
                        
                        if end not in endpoints:
                            endpoints[end] = []
                        endpoints[end].append(feat.id())
        
        self.log_message(f"Valid line segments: {valid_segments}")
        self.log_message(f"Unique endpoints: {len(endpoints)}")
        
        # Analyze connectivity
        dead_ends = []  # Endpoints with only 1 connection
        junctions = []  # Endpoints with 3+ connections
        
        for coord, feature_ids in endpoints.items():
            connection_count = len(feature_ids)
            if connection_count == 1:
                dead_ends.append((coord, feature_ids[0]))
            elif connection_count >= 3:
                junctions.append((coord, connection_count))
        
        self.log_message("\nCONNECTIVITY ANALYSIS:")
        self.log_message(f"  Dead ends (dangling nodes): {len(dead_ends)}")
        self.log_message(f"  Junctions (3+ connections): {len(junctions)}")
        self.log_message(f"  Normal connections (2 segments): {len(endpoints) - len(dead_ends) - len(junctions)}")
        
        # Find disconnected components using flood-fill
        visited = set()
        components = []
        
        def flood_fill(start_coord):
            """Find all connected endpoints from starting point."""
            component = set()
            stack = [start_coord]
            
            while stack:
                coord = stack.pop()
                if coord in visited:
                    continue
                
                visited.add(coord)
                component.add(coord)
                
                # Find all segments connected to this endpoint
                if coord in endpoints:
                    for fid in endpoints[coord]:
                        if fid in segment_endpoints:
                            start, end = segment_endpoints[fid]
                            if start not in visited:
                                stack.append(start)
                            if end not in visited:
                                stack.append(end)
            
            return component
        
        # Find all connected components
        for coord in endpoints:
            if coord not in visited:
                component = flood_fill(coord)
                if component:
                    components.append(component)
        
        self.log_message("\nCOMPONENT ANALYSIS:")
        self.log_message(f"  Number of disconnected components: {len(components)}")
        
        for i, component in enumerate(components, 1):
            segment_count = sum(1 for fid, (s, e) in segment_endpoints.items() if s in component or e in component)
            self.log_message(f"  Component {i}: {len(component)} endpoints, {segment_count} segments")
        
        # Check aggregation points connectivity (if they exist)
        agg_layer = None
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer):
                if 'aggregation' in layer.name().lower() and 'point' in layer.name().lower():
                    agg_layer = layer
                    break
        
        if agg_layer and len(components) > 1:
            self.log_message("\nAGGREGATION POINTS ANALYSIS:")
            
            # Map each agg point to nearest component
            agg_to_component = {}
            
            for agg_feat in agg_layer.getFeatures():
                agg_geom = agg_feat.geometry()
                if agg_geom:
                    agg_point = agg_geom.asPoint()
                    agg_coord = (agg_point.x(), agg_point.y())
                    
                    # Find nearest endpoint in any component
                    min_dist = float('inf')
                    nearest_component = None
                    
                    for comp_idx, component in enumerate(components):
                        for endpoint in component:
                            dist = math.sqrt((agg_coord[0] - endpoint[0])**2 + 
                                           (agg_coord[1] - endpoint[1])**2)
                            if dist < min_dist:
                                min_dist = dist
                                nearest_component = comp_idx
                    
                    if nearest_component is not None:
                        if nearest_component not in agg_to_component:
                            agg_to_component[nearest_component] = []
                        agg_to_component[nearest_component].append(agg_feat['group_100'])
            
            # Report distribution
            for comp_idx in range(len(components)):
                agg_groups = agg_to_component.get(comp_idx, [])
                self.log_message(f"  Component {comp_idx + 1} has {len(agg_groups)} aggregation points")
                if agg_groups and len(agg_groups) <= 5:
                    self.log_message(f"    Groups: {', '.join(map(str, agg_groups))}")
        
        # Create visualization layer for problem areas
        if dead_ends or len(components) > 1:
            self.log_message("\nCREATING VISUALIZATION LAYER...")
            
            # Create problem points layer
            problem_layer = QgsVectorLayer(
                "Point?crs=" + span_layer.crs().authid(),
                "Span Network Issues",
                "memory"
            )
            
            provider = problem_layer.dataProvider()
            provider.addAttributes([
                QgsField("issue_type", QMetaType.Type.QString),
                QgsField("description", QMetaType.Type.QString),
                QgsField("component", QMetaType.Type.Int)
            ])
            problem_layer.updateFields()
            
            features = []
            
            # Add dead ends
            for coord, fid in dead_ends:
                feat = QgsFeature(problem_layer.fields())
                feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(coord[0], coord[1])))
                feat['issue_type'] = 'Dead End'
                feat['description'] = f'Segment {fid} has dangling endpoint'
                feat['component'] = -1
                features.append(feat)
            
            # Add component markers (first endpoint of each component)
            for comp_idx, component in enumerate(components):
                if component:
                    coord = next(iter(component))
                    feat = QgsFeature(problem_layer.fields())
                    feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(coord[0], coord[1])))
                    feat['issue_type'] = 'Component'
                    feat['description'] = f'Component {comp_idx + 1} ({len(component)} endpoints)'
                    feat['component'] = comp_idx + 1
                    features.append(feat)
            
            provider.addFeatures(features)
            
            # Style the layer
            symbol = QgsMarkerSymbol.createSimple({
                'name': 'triangle',
                'color': 'red',
                'size': '4',
                'outline_color': 'black',
                'outline_width': '0.5'
            })
            problem_layer.setRenderer(QgsSingleSymbolRenderer(symbol))
            
            QgsProject.instance().addMapLayer(problem_layer)
            self.log_message(f"Created layer 'Span Network Issues' with {len(features)} problem points")
        
        # Provide recommendations
        self.log_message("\n" + "="*60)
        self.log_message("RECOMMENDATIONS:")
        
        if len(components) > 1:
            self.log_message(f"  ⚠ CRITICAL: Network has {len(components)} disconnected components")
            self.log_message("  → Use Vector → Geometry Tools → Snap Geometries (tolerance: 0.0001)")
            self.log_message("  → Or use Processing → GRASS → v.clean (tools: break,snap,rmdupl)")
        
        if len(dead_ends) > 10:
            self.log_message(f"  ⚠ WARNING: {len(dead_ends)} dead ends found")
            self.log_message("  → Check if these are intentional network endpoints")
            self.log_message("  → Use Topology Checker to find gaps")
        
        if len(components) == 1 and len(dead_ends) <= 10:
            self.log_message("  ✓ Network appears well-connected!")
            self.log_message("  ✓ Ready for feeder route generation")
        
        self.log_message("="*60)
        self._elapsed("Validation")
        """Generate feeder cable routes from OLT to aggregation points."""
        from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject, QgsPointXY  # QgsField is module-level; local re-import shadowed it -> UnboundLocalError in span validation
        from qgis.core import QgsLineSymbol, QgsCategorizedSymbolRenderer, QgsRendererCategory
        from qgis.PyQt.QtCore import QMetaType
        import math
        
        # Get layers from combo boxes
        olt_layer = self.comboBox_olt_layer.currentLayer()
        if not olt_layer:
            self.log_message("ERROR: Please select an OLT layer (Start Point).")
            return
        
        agg_layer = self.comboBox_aggregation_layer.currentLayer()
        if not agg_layer:
            self.log_message("ERROR: Please select an Aggregation Points layer (End Points).")
            return
        
        span_layer = self.comboBox_routing_layer.currentLayer()
        if not span_layer:
            self.log_message("ERROR: Please select a Routing Layer (Path).")
            return
        
        # Validate layer types
        if olt_layer.geometryType() != 0:  # Point
            self.log_message("ERROR: OLT layer must be a Point layer.")
            return
        
        if agg_layer.geometryType() != 0:  # Point
            self.log_message("ERROR: Aggregation Points layer must be a Point layer.")
            return
        
        if span_layer.geometryType() != 1:  # LineString
            geom_types = {0: "Point", 1: "Line", 2: "Polygon"}
            actual_type = geom_types.get(span_layer.geometryType(), "Unknown")
            self.log_message("ERROR: Routing Layer must be a LineString layer!")
            self.log_message(f"  Selected layer '{span_layer.name()}' is {actual_type} geometry")
            return
        
        self.log_message("\n=== Generating Feeder Routes ===")
        self.log_message(f"OLT layer: '{olt_layer.name()}'")
        self.log_message(f"Aggregation points: '{agg_layer.name()}'")
        self.log_message(f"Routing layer: '{span_layer.name()}'")
        self._start_timer()
        try:
            # Get OLT point (use first one if multiple)
            olt_features = list(olt_layer.getFeatures())
            if len(olt_features) == 0:
                self.log_message("ERROR: OLT layer has no features.")
                return
            
            olt_point = olt_features[0].geometry().asPoint()
            self.log_message(f"OLT location: ({olt_point.x():.2f}, {olt_point.y():.2f})")
            
            # Get all aggregation points
            agg_points = []
            for feat in agg_layer.getFeatures():
                geom = feat.geometry()
                if geom and not geom.isEmpty():
                    point = geom.asPoint()
                    # Try to get group ID from various possible field names
                    group_id = None
                    for field_name in ['group_id', 'group_100', 'group', 'id']:
                        if field_name in feat.fields().names():
                            group_id = feat[field_name]
                            break
                    if group_id is None:
                        group_id = feat.id()
                    
                    agg_points.append({
                        'id': feat.id(),
                        'group_id': group_id,
                        'point': point,
                        'feature': feat
                    })
            
            if len(agg_points) == 0:
                self.log_message("ERROR: No aggregation points found.")
                return
            
            self.log_message(f"Found {len(agg_points)} aggregation points")
            
            # Build span network graph with tolerance-based endpoint clustering
            span_features = list(span_layer.getFeatures())
            
            self.log_message(f"Processing {len(span_features)} span segments...")
            
            # First pass: collect all raw endpoints
            raw_endpoints = []  # List of (x, y, segment_geom, is_start)
            segments_processed = 0
            
            for span_feat in span_features:
                geom = span_feat.geometry()
                if not geom or geom.isEmpty():
                    continue
                
                if geom.type() == 1:  # LineString
                    try:
                        if geom.isMultipart():
                            lines = geom.asMultiPolyline()
                            if lines:
                                vertices = lines[0]
                            else:
                                continue
                        else:
                            vertices = geom.asPolyline()
                        
                        if len(vertices) >= 2:
                            start = vertices[0]
                            end = vertices[-1]
                            raw_endpoints.append((start.x(), start.y(), geom, True))
                            raw_endpoints.append((end.x(), end.y(), geom, False))
                            segments_processed += 1
                    except Exception as e:
                        self.log_message(f"  Error processing segment: {e!s}")
                        continue
            
            self.log_message(f"Processed {segments_processed} valid line segments")
            self.log_message(f"Found {len(raw_endpoints)} raw endpoints")
            
            # Second pass: cluster nearby endpoints
            # Auto-detect appropriate tolerance based on coordinate system
            # If coordinates are in degrees (lat/lon), use smaller tolerance
            # If in meters (projected), use larger tolerance
            sample_coords = [abs(x) for x, y, g, s in raw_endpoints[:10]]
            avg_coord = sum(sample_coords) / len(sample_coords) if sample_coords else 0
            
            if avg_coord < 360:  # Likely degrees (lat/lon)
                snap_tolerance = 0.0005  # ~50 meters in degrees - generous to connect nearby segments
                self.log_message(f"Detected geographic coordinates (degrees), using tolerance: {snap_tolerance} (~50m)")
            else:  # Likely meters (projected)
                snap_tolerance = 50.0  # 50 meters
                self.log_message(f"Detected projected coordinates (meters), using tolerance: {snap_tolerance}m")
            
            endpoint_clusters = []  # Each cluster = list of (x, y, geom, is_start)
            used = [False] * len(raw_endpoints)
            
            for i, (x1, y1, geom1, is_start1) in enumerate(raw_endpoints):
                if used[i]:
                    continue
                
                cluster = [(x1, y1, geom1, is_start1)]
                used[i] = True
                
                # Find all endpoints within tolerance
                for j, (x2, y2, geom2, is_start2) in enumerate(raw_endpoints):
                    if used[j]:
                        continue
                    
                    dist = math.sqrt((x1 - x2)**2 + (y1 - y2)**2)
                    if dist <= snap_tolerance:
                        cluster.append((x2, y2, geom2, is_start2))
                        used[j] = True
                
                endpoint_clusters.append(cluster)
            
            self.log_message(f"Clustered into {len(endpoint_clusters)} network nodes (tolerance: {snap_tolerance})")
            
            # Determine rounding precision based on coordinate system
            if avg_coord < 360:  # Geographic coordinates (degrees)
                round_precision = 6  # 6 decimal places = ~0.1m precision
            else:  # Projected coordinates (meters)
                round_precision = 2  # 2 decimal places = 1cm precision
            
            # Third pass: build network graph using clustered nodes
            network_graph = {}  # node_key -> [(connected_node_key, segment_geom)]
            node_to_cluster = {}  # Maps approximate coordinate to cluster centroid
            
            for cluster in endpoint_clusters:
                # Calculate cluster centroid
                avg_x = sum(x for x, y, g, s in cluster) / len(cluster)
                avg_y = sum(y for x, y, g, s in cluster) / len(cluster)
                centroid = (round(avg_x, round_precision), round(avg_y, round_precision))
                
                # Map all endpoints in cluster to the centroid
                for x, y, geom, is_start in cluster:
                    node_to_cluster[(round(x, round_precision), round(y, round_precision))] = centroid
                
                if centroid not in network_graph:
                    network_graph[centroid] = []
            
            # Connect nodes based on segment connectivity
            for span_feat in span_features:
                geom = span_feat.geometry()
                if not geom or geom.isEmpty() or geom.type() != 1:
                    continue
                
                try:
                    if geom.isMultipart():
                        lines = geom.asMultiPolyline()
                        if lines:
                            vertices = lines[0]
                        else:
                            continue
                    else:
                        vertices = geom.asPolyline()
                    
                    if len(vertices) >= 2:
                        start = vertices[0]
                        end = vertices[-1]
                        
                        start_approx = (round(start.x(), round_precision), round(start.y(), round_precision))
                        end_approx = (round(end.x(), round_precision), round(end.y(), round_precision))
                        
                        if start_approx in node_to_cluster and end_approx in node_to_cluster:
                            start_node = node_to_cluster[start_approx]
                            end_node = node_to_cluster[end_approx]
                            
                            if start_node != end_node:  # Avoid self-loops
                                network_graph[start_node].append((end_node, geom))
                                network_graph[end_node].append((start_node, geom))
                except:
                    continue
            
            self.log_message(f"Built network graph with {len(network_graph)} nodes")
            
            # Analyze network connectivity - find connected components
            def find_connected_components(graph):
                """Find all connected components using flood-fill."""
                visited = set()
                components = []
                
                for start_node in graph.keys():
                    if start_node in visited:
                        continue
                    
                    # BFS from this node
                    component = []
                    queue = [start_node]
                    while queue:
                        node = queue.pop(0)
                        if node in visited:
                            continue
                        visited.add(node)
                        component.append(node)
                        
                        for neighbor, _ in graph.get(node, []):
                            if neighbor not in visited:
                                queue.append(neighbor)
                    
                    components.append(component)
                
                return components
            
            components = find_connected_components(network_graph)
            self.log_message(f"Network has {len(components)} connected component(s)")
            if len(components) > 1:
                component_sizes = sorted([len(c) for c in components], reverse=True)
                self.log_message(f"  Component sizes: {component_sizes[:5]}{'...' if len(components) > 5 else ''}")
            
            # Snap points to nearest network node using tolerance
            def snap_to_network_node(point, max_snap_dist=1000.0):
                """Find nearest network node to a point."""
                min_dist = float('inf')
                nearest_node = None
                
                for node in network_graph.keys():
                    dist = math.sqrt(
                        (point.x() - node[0])**2 + 
                        (point.y() - node[1])**2
                    )
                    if dist < min_dist:
                        min_dist = dist
                        nearest_node = node
                
                if min_dist > max_snap_dist:
                    return None, float('inf')
                
                return nearest_node, min_dist
            
            olt_node, olt_dist = snap_to_network_node(olt_point)
            if olt_node is None:
                self.log_message(f"ERROR: OLT is too far from span network (distance: {olt_dist:.2f})")
                self.log_message("Please move OLT closer to the span layer or check span layer coverage.")
                return
            
            self.log_message(f"OLT snapped to network node (distance: {olt_dist:.2f})")
            self.log_message(f"OLT node: ({olt_node[0]:.4f}, {olt_node[1]:.4f})")
            
            # Snap all aggregation points
            self.log_message("\nSnapping aggregation points to network...")
            snapped_count = 0
            for agg in agg_points:
                agg['network_node'], agg['snap_dist'] = snap_to_network_node(agg['point'])
                if agg['network_node'] is not None:
                    snapped_count += 1
                else:
                    self.log_message(f"  WARNING: Agg {agg['group_id']} too far from network (dist: {agg['snap_dist']:.2f})")
            
            self.log_message(f"Successfully snapped {snapped_count}/{len(agg_points)} aggregation points to network")
            
            if snapped_count == 0:
                self.log_message("ERROR: No aggregation points could be snapped to span network.")
                self.log_message("Aggregation points may be too far from span layer.")
                return
            
            # Find furthest aggregation point from OLT (this defines main route)
            def network_distance(start_node, end_node):
                """Calculate shortest path through network using Dijkstra.
                Returns distance, path of nodes, and list of segment geometries."""
                if start_node not in network_graph or end_node not in network_graph:
                    return float('inf'), [], []
                
                import heapq
                distances = {start_node: 0}
                previous = {start_node: (None, None)}  # (previous_node, segment_geom)
                pq = [(0, start_node)]
                visited = set()
                
                while pq:
                    current_dist, current_node = heapq.heappop(pq)
                    
                    if current_node in visited:
                        continue
                    
                    visited.add(current_node)
                    
                    if current_node == end_node:
                        # Reconstruct path and segments
                        path = []
                        segments = []
                        node = end_node
                        while node is not None:
                            path.append(node)
                            prev_node, segment = previous.get(node, (None, None))
                            if segment is not None:
                                segments.append(segment)
                            node = prev_node
                        path.reverse()
                        segments.reverse()
                        return current_dist, path, segments
                    
                    for neighbor, segment_geom in network_graph.get(current_node, []):
                        if neighbor in visited:
                            continue
                        
                        edge_dist = segment_geom.length()
                        new_dist = current_dist + edge_dist
                        
                        if neighbor not in distances or new_dist < distances[neighbor]:
                            distances[neighbor] = new_dist
                            previous[neighbor] = (current_node, segment_geom)
                            heapq.heappush(pq, (new_dist, neighbor))
                
                return float('inf'), [], []
            
            # Calculate distances to all aggregation points
            self.log_message("\nCalculating routes to aggregation points...")
            for agg in agg_points:
                dist, path, segments = network_distance(olt_node, agg['network_node'])
                agg['network_distance'] = dist
                agg['path'] = path
                agg['segments'] = segments
                self.log_message(f"  Agg {agg['group_id']}: distance={dist:.2f}, path nodes={len(path)}, segments={len(segments)}")
            
            # Filter out only truly unreachable points (infinite distance or same node as OLT)
            reachable_agg_points = [agg for agg in agg_points if agg['network_distance'] < float('inf')]
            unreachable_agg_points = [agg for agg in agg_points if agg['network_distance'] == float('inf')]
            
            if len(reachable_agg_points) == 0:
                self.log_message("ERROR: No aggregation points are reachable from OLT via the span network.")
                self.log_message("Please check that:")
                self.log_message("  1. OLT and aggregation points are near the span layer")
                self.log_message("  2. Span segments are connected (endpoints touch)")
                return
            
            if len(unreachable_agg_points) > 0:
                self.log_message(f"\nWARNING: {len(unreachable_agg_points)} aggregation points are not reachable:")
                # Analyze why they're unreachable
                for agg in unreachable_agg_points:
                    if agg['network_node'] is None:
                        self.log_message(f"  Agg {agg['group_id']}: Too far from span network")
                    else:
                        # Check if this node is in a different connected component
                        node = agg['network_node']
                        if node in network_graph:
                            neighbor_count = len(network_graph[node])
                            self.log_message(f"  Agg {agg['group_id']}: On disconnected component ({neighbor_count} neighbors at node)")
                        else:
                            self.log_message(f"  Agg {agg['group_id']}: Snapped to invalid node")
            
            # Use Prim's algorithm to build Minimum Spanning Tree from OLT to all aggregation points
            # This creates a single connected network (main trunk + branches)
            
            def prim_mst(start_node, terminal_nodes, graph):
                """
                Build Minimum Spanning Tree using Prim's algorithm.
                Returns tree as dict of parent relationships and edge geometries.
                """
                import heapq
                
                # MST edges: {node: (parent_node, edge_geom, distance)}
                mst = {start_node: (None, None, 0)}
                in_tree = {start_node}
                terminals_needed = set(terminal_nodes)
                
                # Priority queue: (distance, current_node, next_node, edge_geom)
                pq = []
                
                # Add all edges from start node
                for neighbor, edge_geom in graph.get(start_node, []):
                    dist = edge_geom.length()
                    heapq.heappush(pq, (dist, start_node, neighbor, edge_geom))
                
                while pq and terminals_needed:
                    dist, from_node, to_node, edge_geom = heapq.heappop(pq)
                    
                    if to_node in in_tree:
                        continue
                    
                    # Add to tree
                    mst[to_node] = (from_node, edge_geom, dist)
                    in_tree.add(to_node)
                    terminals_needed.discard(to_node)
                    
                    # Add edges from newly added node
                    for neighbor, neighbor_edge in graph.get(to_node, []):
                        if neighbor not in in_tree:
                            neighbor_dist = neighbor_edge.length()
                            heapq.heappush(pq, (neighbor_dist, to_node, neighbor, neighbor_edge))
                
                return mst
            
            # Get aggregation node locations
            agg_nodes = set(agg['network_node'] for agg in reachable_agg_points if agg['network_node'])
            
            self.log_message(f"\nBuilding Minimum Spanning Tree from OLT to {len(agg_nodes)} aggregation points...")
            
            # Build MST
            mst_tree = prim_mst(olt_node, agg_nodes, network_graph)
            
            # Create unique edges from MST - ONLY include edges needed to reach aggregation points
            # Each path stops at an aggregation point (no pass-through beyond agg points)
            mst_edges = {}  # {edge_key: {'from': node, 'to': node, 'geom': geom}}
            
            # For each aggregation point, trace back to OLT and collect needed edges
            needed_edges = set()
            for agg_node in agg_nodes:
                current = agg_node
                while current in mst_tree:
                    parent, edge_geom, dist = mst_tree[current]
                    if parent is None:
                        break
                    edge_key = tuple(sorted([current, parent]))
                    needed_edges.add(edge_key)
                    current = parent
            
            # Only include edges that are needed to reach aggregation points
            for node, (parent, edge_geom, dist) in mst_tree.items():
                if parent is None or edge_geom is None:
                    continue
                
                edge_key = tuple(sorted([node, parent]))
                
                # Only include if this edge is needed
                if edge_key in needed_edges and edge_key not in mst_edges:
                    mst_edges[edge_key] = {
                        'from': parent,
                        'to': node,
                        'geom': edge_geom,
                        'distance': dist
                    }
            
            self.log_message(f"MST has {len(mst_edges)} unique edges (pruned to reach agg points only)")
            
            # Find the path from OLT to each aggregation point
            def get_path_to_olt(node):
                """Get list of nodes from given node back to OLT."""
                path = []
                current = node
                while current in mst_tree:
                    path.append(current)
                    parent, _, _ = mst_tree[current]
                    if parent is None:
                        break
                    current = parent
                return path
            
            # Calculate geographic direction and distance for each aggregation point
            import math
            
            def get_direction(from_point, to_point):
                """Get compass direction in degrees (0=North, 90=East, 180=South, 270=West)."""
                dx = to_point[0] - from_point[0]
                dy = to_point[1] - from_point[1]
                angle = math.degrees(math.atan2(dx, dy))  # atan2(x,y) gives angle from North
                if angle < 0:
                    angle += 360
                return angle
            
            def get_quadrant(angle):
                """Get quadrant: 0=North, 1=East, 2=South, 3=West."""
                return int((angle + 45) % 360 / 90)
            
            # Analyze each aggregation point
            agg_analysis = []
            for agg in reachable_agg_points:
                if agg['network_node']:
                    path = get_path_to_olt(agg['network_node'])
                    # Calculate total path distance (network distance)
                    total_dist = 0
                    for node in path[:-1]:
                        if node in mst_tree:
                            _, edge_geom, _ = mst_tree[node]
                            if edge_geom:
                                total_dist += edge_geom.length()
                    
                    # Calculate direct geographic distance and direction from OLT
                    agg_node = agg['network_node']
                    direct_dist = math.sqrt((agg_node[0] - olt_node[0])**2 + (agg_node[1] - olt_node[1])**2)
                    direction = get_direction(olt_node, agg_node)
                    quadrant = get_quadrant(direction)
                    
                    agg_analysis.append({
                        'agg': agg,
                        'path': path,
                        'network_dist': total_dist,
                        'direct_dist': direct_dist,
                        'direction': direction,
                        'quadrant': quadrant
                    })
            
            # Group aggregation points by quadrant
            quadrants = {0: [], 1: [], 2: [], 3: []}  # N, E, S, W
            for analysis in agg_analysis:
                quadrants[analysis['quadrant']].append(analysis)
            
            # Sort each quadrant by direct distance (furthest first)
            for q in quadrants:
                quadrants[q].sort(key=lambda x: x['direct_dist'], reverse=True)
            
            # Select main trunk endpoints: furthest point in opposite directions
            main_trunk_endpoints = []
            main_trunk_paths = []
            
            # Find quadrants with aggregation points
            populated_quadrants = [q for q in range(4) if quadrants[q]]
            
            self.log_message("\nQuadrant analysis (from OLT):")
            quadrant_names = ['North', 'East', 'South', 'West']
            for q in range(4):
                count = len(quadrants[q])
                if count > 0:
                    furthest = quadrants[q][0]['agg']['group_id']
                    self.log_message(f"  {quadrant_names[q]}: {count} points, furthest: Agg {furthest}")
                else:
                    self.log_message(f"  {quadrant_names[q]}: 0 points")
            
            # Select main trunks from opposite quadrants (N-S or E-W preference)
            if populated_quadrants:
                # Try to get opposite quadrants first
                opposite_pairs = [(0, 2), (1, 3), (2, 0), (3, 1)]  # N-S, E-W pairs
                
                for q1, q2 in opposite_pairs:
                    if quadrants[q1] and quadrants[q2]:
                        # Found opposite quadrants with points
                        main_trunk_endpoints.append(quadrants[q1][0]['agg'])
                        main_trunk_paths.append(set(quadrants[q1][0]['path']))
                        main_trunk_endpoints.append(quadrants[q2][0]['agg'])
                        main_trunk_paths.append(set(quadrants[q2][0]['path']))
                        break
                
                # If no opposite pair found, just use the 2 most populated quadrants
                if not main_trunk_endpoints:
                    sorted_quadrants = sorted(populated_quadrants, key=lambda q: len(quadrants[q]), reverse=True)
                    for q in sorted_quadrants[:2]:
                        if quadrants[q]:
                            main_trunk_endpoints.append(quadrants[q][0]['agg'])
                            main_trunk_paths.append(set(quadrants[q][0]['path']))
            
            self.log_message(f"\nMain trunk endpoints: {len(main_trunk_endpoints)}")
            for i, agg in enumerate(main_trunk_endpoints):
                self.log_message(f"  Main {i+1}: Agg {agg['group_id']}")
            
            # Collect all edges that are part of main trunk paths
            main_trunk_edges = set()
            for path_set in main_trunk_paths:
                path_list = list(path_set)
                for node in path_list:
                    if node in mst_tree:
                        parent, _, _ = mst_tree[node]
                        if parent is not None:
                            edge_key = tuple(sorted([node, parent]))
                            main_trunk_edges.add(edge_key)
            
            self.log_message(f"Main trunk has {len(main_trunk_edges)} edges")
            
            # Determine edge hierarchy level (distance from main trunk)
            def get_edge_level(edge_key, visited=None):
                """
                Get hierarchy level of an edge:
                0 = Main trunk (144F)
                1 = Direct branch from main (96F)
                2+ = Branch from branch (72F)
                """
                if edge_key in main_trunk_edges:
                    return 0
                
                if visited is None:
                    visited = set()
                
                if edge_key in visited:
                    return 999  # Avoid infinite loops
                visited.add(edge_key)
                
                edge_data = mst_edges.get(edge_key)
                if not edge_data:
                    return 999
                
                # Find the parent edge (edge that connects 'from' node to its parent)
                from_node = edge_data['from']
                if from_node in mst_tree:
                    parent_of_from, _, _ = mst_tree[from_node]
                    if parent_of_from is not None:
                        parent_edge_key = tuple(sorted([from_node, parent_of_from]))
                        parent_level = get_edge_level(parent_edge_key, visited)
                        return parent_level + 1
                
                # If from_node is OLT, this is level 1 (direct from OLT but not main)
                if from_node == olt_node:
                    return 1
                
                return 1  # Default to level 1
            
            # Calculate total demand at each aggregation point
            # This is used to determine cable sizing based on actual demand
            total_demand = len(reachable_agg_points)  # Count of aggregation points
            
            # Use cable profile system to determine appropriate fiber sizes
            # Main trunk carries all demand, spurs carry partial demand
            main_fiber_count = get_cable_profile(total_demand * 8, PROFILE_TYPE_POPC)  # 8 fibers per agg point estimate
            spur_fiber_count = get_cable_profile(total_demand * 4, PROFILE_TYPE_POPC)
            sub_spur_fiber_count = get_cable_profile(8, PROFILE_TYPE_DEFAULT)  # Minimum for single group
            
            self.log_message("\nCable Profile Calculation (using POPC 30% reserve):")
            self.log_message(f"  Estimated demand: {total_demand} aggregation points")
            self.log_message(f"  Main trunk: {format_cable_profile(main_fiber_count)} (for {total_demand * 8} est. fibers)")
            self.log_message(f"  Spur: {format_cable_profile(spur_fiber_count)}")
            self.log_message(f"  Sub-Spur: {format_cable_profile(sub_spur_fiber_count)}")
            
            # Assign fiber sizes based on hierarchy level
            for edge_key, edge_data in mst_edges.items():
                level = get_edge_level(edge_key)
                edge_data['level'] = level
                
                if level == 0:
                    edge_data['fiber_size'] = format_cable_profile(main_fiber_count)
                    edge_data['fiber_count'] = main_fiber_count
                    edge_data['route_type'] = 'Main'
                elif level == 1:
                    edge_data['fiber_size'] = format_cable_profile(spur_fiber_count)
                    edge_data['fiber_count'] = spur_fiber_count
                    edge_data['route_type'] = 'Spur'
                else:  # level >= 2
                    edge_data['fiber_size'] = format_cable_profile(sub_spur_fiber_count)
                    edge_data['fiber_count'] = sub_spur_fiber_count
                    edge_data['route_type'] = 'Sub-Spur'
            
            self.log_message("\nNetwork Structure:")
            fiber_counts = {}
            for edge_data in mst_edges.values():
                fs = edge_data['fiber_size']
                fiber_counts[fs] = fiber_counts.get(fs, 0) + 1
            for fs, count in sorted(fiber_counts.items()):
                self.log_message(f"  {fs}: {count} segments")
            
            # Create feeder routes layer
            crs = span_layer.crs().authid()
            feeder_layer = QgsVectorLayer(f"LineString?crs={crs}", 
                                         "Feeder Routes", 
                                         "memory")
            provider = feeder_layer.dataProvider()
            
            # Add fields
            provider.addAttributes([
                QgsField('route_id', QMetaType.Type.Int),
                QgsField('route_type', QMetaType.Type.QString),  # 'Main', 'Spur', 'Sub-Spur'
                QgsField('fiber_size', QMetaType.Type.QString),  # e.g., '144F', '96F', '72F'
                QgsField('fiber_count', QMetaType.Type.Int),    # Numeric fiber count
                QgsField('level', QMetaType.Type.Int),          # Hierarchy level (0=Main, 1=Spur, 2+=Sub-Spur)
                QgsField('length', QMetaType.Type.Double)
            ])
            feeder_layer.updateFields()
            
            route_features = []
            route_id = 1
            
            self.log_message("\nCreating route geometries...")
            
            # Determine dedup tolerance
            if avg_coord < 360:  # Degrees
                dedup_tolerance = 0.000001
            else:  # Meters
                dedup_tolerance = 0.001
            
            # Create a feature for each unique MST edge
            for edge_key, edge_data in mst_edges.items():
                segment = edge_data['geom']
                
                try:
                    if segment.isMultipart():
                        lines = segment.asMultiPolyline()
                        if lines:
                            vertices = lines[0]
                        else:
                            continue
                    else:
                        vertices = segment.asPolyline()
                    
                    if len(vertices) >= 2:
                        route_geom = QgsGeometry.fromPolylineXY(vertices)
                        route_feat = QgsFeature(feeder_layer.fields())
                        route_feat.setGeometry(route_geom)
                        route_feat.setAttributes([
                            route_id,
                            edge_data['route_type'],
                            edge_data['fiber_size'],
                            edge_data['fiber_count'],
                            edge_data['level'],
                            route_geom.length()
                        ])
                        route_features.append(route_feat)
                        route_id += 1
                except Exception as e:
                    self.log_message(f"  Error creating edge geometry: {e!s}")
                    continue
            
            if len(route_features) == 0:
                self.log_message("ERROR: No route features were created!")
                self.log_message("Check that aggregation points can be reached from OLT via span network.")
                return
            
            # Add features to layer
            self.log_message(f"\nAdding {len(route_features)} route segments to layer...")
            provider.addFeatures(route_features)
            feeder_layer.updateExtents()
            
            # Apply categorized symbology by fiber size
            categories = []
            # Dynamic fiber colors based on calculated profiles
            fiber_colors = {
                format_cable_profile(main_fiber_count): ('255,0,0', '3.0'),      # Red, thick - Main
                format_cable_profile(spur_fiber_count): ('255,128,0', '2.0'),    # Orange, medium - Spur
                format_cable_profile(sub_spur_fiber_count): ('255,255,0', '1.5') # Yellow, thin - Sub-Spur
            }
            
            for fiber_size, (color, width) in fiber_colors.items():
                symbol = QgsLineSymbol.createSimple({
                    'color': color,
                    'width': width,
                    'capstyle': 'round'
                })
                category = QgsRendererCategory(
                    fiber_size,
                    symbol,
                    f"{fiber_size} Fiber"
                )
                categories.append(category)
            
            renderer = QgsCategorizedSymbolRenderer('fiber_size', categories)
            feeder_layer.setRenderer(renderer)
            
            # Add layer to project
            feeder_layer = self._add_output_layer(feeder_layer)
            
            # Calculate statistics
            total_length = sum(feat['length'] for feat in route_features)
            main_count = sum(1 for f in route_features if f['route_type'] == 'Main')
            spur_count = sum(1 for f in route_features if f['route_type'] == 'Spur')
            sub_spur_count = sum(1 for f in route_features if f['route_type'] == 'Sub-Spur')
            
            self.log_message(f"\nCreated {len(route_features)} feeder route segments (no overlaps)")
            self.log_message(f"  Main trunk: {main_count} segments ({format_cable_profile(main_fiber_count)}) - to furthest aggregation points")
            self.log_message(f"  Spurs: {spur_count} segments ({format_cable_profile(spur_fiber_count)}) - branches from main trunk")
            self.log_message(f"  Sub-Spurs: {sub_spur_count} segments ({format_cable_profile(sub_spur_fiber_count)}) - branches from spurs")
            self.log_message(f"Total route length: {total_length:.4f} units")
            self.log_message(f"Layer: '{feeder_layer.name()}'")
            self.log_message("\nHierarchy (Cable Profiles - POPC 30% Reserve):")
            self.log_message(f"  {format_cable_profile(main_fiber_count)} (Red) - Main trunk from OLT to furthest points")
            self.log_message(f"  {format_cable_profile(spur_fiber_count)} (Orange) - Spur cables branching from main")
            self.log_message(f"  {format_cable_profile(sub_spur_fiber_count)} (Yellow) - Sub-spurs branching from spurs")
            self.log_message(f"\nAvailable cable profiles: {', '.join(format_cable_profile(p) for p in CABLE_PROFILES)}")
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR generating feeder routes: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    # ── PHASE 1: POLE SPECIFICATION HELPERS (Herotel FTTH Standards) ──
    def _detect_span_type(self, layer_name: str) -> str:
        """Auto-detect span type from layer name.
        Returns 'feeder' if 'feeder' in name (case-insensitive), else 'distribution'."""
        if not layer_name:
            return "distribution"
        return "feeder" if "feeder" in layer_name.lower() else "distribution"

    def _get_pole_height(self, pole_role: str, is_crossing: bool = False) -> float:
        """Get pole height per Herotel spec.
        Feeder: 7m | Distribution midblock: 5.4m | Distribution crossing: 7m"""
        if pole_role == "feeder":
            return 7.0
        if pole_role == "distribution":
            return 7.0 if is_crossing else 5.4
        if pole_role == "support":
            return 5.4
        return 5.4

    def _get_pole_thickness(self, pole_role: str, is_corner: bool = False) -> str:
        """Get pole thickness per Herotel spec (mm).
        Standard: 100/120 | Corner (>15°): 120/140"""
        return "120/140" if (is_corner or pole_role in ["terminal", "support"]) else "100/120"

    def _get_installation_notes(self, pole_role: str, pole_type: str,
                                 pole_height: float, pole_thickness: str) -> str:
        """Generate SANS 754 H4 compliant installation notes."""
        notes = [
            "SANS 754 (63 MPa H4 treated)",
            f"Diameter: {pole_thickness}mm | Height: {pole_height}m",
            f"Depth: {'1.0' if pole_height != 9.0 else '1.2'}m hole | 300x300mm top, taper to 200x200mm bottom",
            "Backfill: 200mm soil + 2x 200mm Soil Crete + compacted fill",
        ]
        if pole_role == "feeder":
            notes.append("FEEDER: 70m max span, double+ capacity, hook @ 5.5m")
        elif pole_role == "distribution":
            notes.append("DISTRIBUTION: 8 homes per pole (4 direct + 4 via tangent)")
        if pole_type in ["start", "end"]:
            notes.append("TERMINAL: Verify cable slack")
        if pole_type == "kink":
            notes.append("KINK: Direction change — check support requirements")
        return " | ".join(notes)

    def _resolve_span_type_field(self, lyr):
        """Find the field holding the span TYPE (primary/secondary feeder,
        distribution, …). Span layers name this field many different ways, so the
        old hard-coded case-sensitive 'Type' lookup found nothing on most real
        layers (e.g. 'type', 'Span Type', 'Classification') and the Generate-Poles
        'Filter by Type' dropdown showed only 'All spans'. Match common names
        case-insensitively first, then fall back to scanning text fields for
        span-type-like values. Returns the field index, or -1 if none looks like
        a type field."""
        if not lyr:
            return -1
        flds = lyr.fields()
        # 1) common explicit names — lookupField is case-INSENSITIVE
        for cand in ('Type', 'span_type', 'spantype', 'SpanType', 'cable_type',
                     'cabletype', 'Cable Type', 'span_role', 'SpanRole', 'role',
                     'category', 'class', 'classification', 'Classification'):
            idx = flds.lookupField(cand)
            if idx >= 0:
                return idx
        # 2) fallback: single pass over text fields, pick the one whose values look
        #    most like span types (small category set + type keywords).
        _kw = ('feeder', 'distribution', 'primary', 'secondary', 'spur',
               'drop', 'trunk', 'backbone', 'link')
        str_idxs = []
        for i, f in enumerate(flds):
            try:
                tn = f.typeName().lower()
            except Exception:
                tn = ''
            if 'char' in tn or 'string' in tn or 'text' in tn:
                str_idxs.append(i)
        if not str_idxs:
            return -1
        vals = {i: set() for i in str_idxs}
        hits = {i: 0 for i in str_idxs}
        n = 0
        for ft in lyr.getFeatures():
            n += 1
            for i in str_idxs:
                v = ft[i]
                if v:
                    s = str(v).lower()
                    if len(vals[i]) <= 40:
                        vals[i].add(s)
                    if any(k in s for k in _kw):
                        hits[i] += 1
            if n >= 5000:          # cap the scan on very large layers
                break
        best_idx, best_hits = -1, 0
        for i in str_idxs:
            if hits[i] > best_hits and 1 <= len(vals[i]) <= 40:
                best_idx, best_hits = i, hits[i]
        return best_idx

    def on_generate_poles_clicked(self):
        """Generate pole points along span layer at specified intervals — PHASE 1: Enhanced attributes per Herotel spec."""
        from qgis.core import QgsWkbTypes, QgsPointXY
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
                                         QLabel, QPushButton, QComboBox, QSpinBox)
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtGui import QFont
        from qgis.core import QgsMapLayerProxyModel
        import math

        # ── Settings popup ────────────────────────────────────────────────
        dlg = QDialog(None)
        dlg.setWindowTitle("Generate Poles — PHASE 1 (Enhanced Herotel Specs)")
        dlg.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                           Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
        dlg.setMinimumWidth(380)
        lay = QVBoxLayout(dlg)
        lay.setSpacing(10)
        lay.setContentsMargins(18, 18, 18, 18)

        hdr = QLabel("🪧  Generate Poles — V105.1")
        hf = QFont(); hf.setBold(True); hf.setPointSize(10)
        hdr.setFont(hf); hdr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(hdr)

        info = QLabel("Choose Span Role: Feeder (7m) or Distribution (5.4-7m)\nRun separately for each span layer type")
        info.setAlignment(Qt.AlignmentFlag.AlignCenter)
        info.setStyleSheet("color: #666; font-size: 9pt;")
        lay.addWidget(info)

        form = QFormLayout()
        form.setRowWrapPolicy(QFormLayout.DontWrapRows)

        span_combo = QgsMapLayerComboBox()
        span_combo.setFilters(QgsMapLayerProxyModel.LineLayer)
        current_span = self.comboBox_span_layer.currentLayer()
        if current_span:
            span_combo.setLayer(current_span)
        form.addRow("Span Layer:", span_combo)

        # NEW: Type filter (filter spans by their TYPE attribute before generation)
        # Resolver is an instance method (_resolve_span_type_field) so the dropdown
        # population and the generation-time filter use the EXACT same field.
        _resolve_type_field = self._resolve_span_type_field

        type_filter_combo = QComboBox()
        type_filter_combo.addItem("All spans")

        def _on_span_layer_change(lyr):
            """Update Type filter options when span layer changes."""
            type_filter_combo.blockSignals(True)
            type_filter_combo.clear()
            type_filter_combo.addItem("All spans")

            if lyr and lyr.geometryType() == 1:  # LineGeometry
                try:
                    type_idx = _resolve_type_field(lyr)
                    if type_idx >= 0:
                        unique_types = set()
                        for feat in lyr.getFeatures():
                            val = feat[type_idx]
                            if val is not None and str(val).strip():
                                unique_types.add(str(val))
                        for t in sorted(unique_types):
                            type_filter_combo.addItem(t)
                        self.log_message(
                            f"[Generate Poles] Type filter field: "
                            f"'{lyr.fields()[type_idx].name()}' "
                            f"({len(unique_types)} types)")
                except Exception:
                    pass
            type_filter_combo.blockSignals(False)

        span_combo.layerChanged.connect(_on_span_layer_change)
        _on_span_layer_change(current_span)
        form.addRow("Filter by Type:", type_filter_combo)

        # NEW: Explicit span role selector (override auto-detect)
        span_role_combo = QComboBox()
        span_role_combo.addItem("Auto-detect (from layer name)")
        span_role_combo.addItem("Feeder")
        span_role_combo.addItem("Distribution")
        span_role_combo.setCurrentIndex(0)
        form.addRow("Assign Pole Role:", span_role_combo)

        dist_combo = QComboBox()
        for v in [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]:
            dist_combo.addItem(str(v))
        dist_combo.addItem("Custom…")
        dist_combo.setCurrentIndex(4)   # default 50 m

        custom_spin = QSpinBox()
        custom_spin.setRange(1, 500)
        custom_spin.setValue(50)
        custom_spin.setEnabled(False)
        custom_spin.setSuffix(" m")

        def _on_dist_change(text):
            custom_spin.setEnabled(text == "Custom…")
        dist_combo.currentTextChanged.connect(_on_dist_change)

        form.addRow("Distance (m):", dist_combo)
        form.addRow("Custom value:", custom_spin)
        lay.addLayout(form)

        btn_row = QHBoxLayout()
        run_btn = QPushButton("Generate")
        run_btn.setStyleSheet("QPushButton { background-color: #2e4057; color: white; font-weight: bold; "
                              "padding: 5px 18px; border-radius: 4px; } QPushButton:hover { background-color: #3d5270; }")
        cancel_btn = QPushButton("Cancel")
        btn_row.addWidget(run_btn)
        btn_row.addWidget(cancel_btn)
        lay.addLayout(btn_row)

        run_btn.clicked.connect(dlg.accept)
        cancel_btn.clicked.connect(dlg.reject)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        span_layer = span_combo.currentLayer()
        if not span_layer:
            self.log_message("ERROR: Please select a span layer for pole generation.")
            return
        if span_layer.geometryType() != QgsWkbTypes.GeometryType.LineGeometry:
            self.log_message("ERROR: Span layer must be a line layer.")
            return

        dist_text = dist_combo.currentText()
        distance_meters = custom_spin.value() if dist_text == "Custom…" else int(dist_text)

        # Get Type filter selection (V105.1 feature)
        type_filter_value = type_filter_combo.currentText()
        type_filter_enabled = (type_filter_value != "All spans")

        # Get explicit span role selection (V105.1 feature)
        span_role_selection = span_role_combo.currentText()
        if span_role_selection == "Auto-detect (from layer name)":
            span_type = self._detect_span_type(span_layer.name())
            self.log_message("\n=== Generating Poles — PHASE 1.1 (Enhanced, V105.1) ===")
            self.log_message(f"Span layer: '{span_layer.name()}'")
            self.log_message(f"Span role: Auto-detected as {span_type.upper()}")
        else:
            span_type = span_role_selection.lower()
            self.log_message("\n=== Generating Poles — PHASE 1.1 (Enhanced, V105.1) ===")
            self.log_message(f"Span layer: '{span_layer.name()}'")
            self.log_message(f"Span role: Explicitly set to {span_type.upper()}")
        
        if type_filter_enabled:
            self.log_message(f"Type filter: '{type_filter_value}'")
        self.log_message(f"Distance between poles: {distance_meters}m")

        try:
            from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry, QgsField
            from qgis.PyQt.QtCore import QMetaType
            from qgis.core import QgsMarkerSymbol, QgsCategorizedSymbolRenderer, QgsRendererCategory

            self._start_timer()

            # CRS handling
            crs = span_layer.crs()
            is_geographic = crs.isGeographic()
            
            if is_geographic:
                extent = span_layer.extent()
                center_lat = (extent.yMinimum() + extent.yMaximum()) / 2
                meters_per_degree = 111320 * math.cos(math.radians(center_lat))
                distance_units = distance_meters / meters_per_degree
                self.log_message(f"Geographic CRS: converting {distance_meters}m to ~{distance_units:.6f}°")
            else:
                distance_units = distance_meters
                meters_per_degree = 1.0
                self.log_message(f"Projected CRS: using {distance_meters}m directly")
            
            # Create output pole layer with PHASE 1 schema
            pole_layer = QgsVectorLayer(f"Point?crs={crs.authid()}", 
                                       f"Poles_{distance_meters}m_{span_type}", 
                                       "memory")
            provider = pole_layer.dataProvider()
            
            # PHASE 1: Enhanced attribute schema
            provider.addAttributes([
                QgsField('pole_id', QMetaType.Type.Int),
                QgsField('span_id', QMetaType.Type.Int),
                QgsField('distance_along', QMetaType.Type.Double),
                QgsField('pole_type', QMetaType.Type.QString),     # start, intermediate, end, kink
                QgsField('pole_role', QMetaType.Type.QString),     # NEW: feeder, distribution, support
                QgsField('pole_height', QMetaType.Type.Double),    # NEW: meters (7.0, 5.4, etc)
                QgsField('pole_thickness', QMetaType.Type.QString),# NEW: "100/120" or "120/140"
                QgsField('installation_notes', QMetaType.Type.QString)  # NEW: SANS 754 specs
            ])
            pole_layer.updateFields()
            
            pole_features = []
            pole_id = 1
            total_poles = 0
            global_placed_coords = set()
            
            # Get Type field index for filtering (if enabled) — use the SAME
            # resolver that populated the dropdown so we filter on the right field.
            type_field_idx = -1
            if type_filter_enabled:
                type_field_idx = _resolve_type_field(span_layer)
                if type_field_idx < 0:
                    self.log_message("WARNING: span type field not found. Filtering disabled.")
                    type_filter_enabled = False
            
            # Process each span segment
            for span_feat in span_layer.getFeatures():
                geom = span_feat.geometry()
                if not geom or geom.isEmpty():
                    continue
                
                # NEW: Apply Type filter
                if type_filter_enabled:
                    feat_type = span_feat[type_field_idx]
                    if str(feat_type) != type_filter_value:
                        continue  # Skip this feature, doesn't match filter
                
                span_id = span_feat.id()
                
                if geom.isMultipart():
                    lines = geom.asMultiPolyline()
                else:
                    lines = [geom.asPolyline()]
                
                for line in lines:
                    if len(line) < 2:
                        continue
                    
                    cumulative = 0.0

                    for i, vertex in enumerate(line):
                        if i == 0:
                            vtype = 'start'
                        elif i == len(line) - 1:
                            vtype = 'end'
                        else:
                            vtype = 'kink'

                        key = (round(vertex.x(), 4), round(vertex.y(), 4))
                        if key not in global_placed_coords:
                            global_placed_coords.add(key)
                            dist_out = cumulative if not is_geographic else cumulative * meters_per_degree
                            
                            # PHASE 1: Assign pole attributes
                            pole_role = span_type if vtype == 'start' else 'distribution'
                            pole_height = self._get_pole_height(pole_role)
                            pole_thickness = self._get_pole_thickness(pole_role, is_corner=(vtype == 'kink'))
                            install_notes = self._get_installation_notes(pole_role, vtype, pole_height, pole_thickness)
                            
                            pole_feat = QgsFeature(pole_layer.fields())
                            pole_feat.setGeometry(QgsGeometry.fromPointXY(vertex))
                            pole_feat.setAttributes([
                                pole_id, span_id, round(dist_out, 2), vtype,
                                pole_role, pole_height, pole_thickness, install_notes
                            ])
                            pole_features.append(pole_feat)
                            pole_id += 1
                            total_poles += 1

                        # Fill segment with intermediate poles
                        if i < len(line) - 1:
                            nv = line[i + 1]
                            dx = nv.x() - vertex.x()
                            dy = nv.y() - vertex.y()
                            seg_len = math.sqrt(dx * dx + dy * dy)

                            if seg_len > distance_units:
                                n_steps = int(seg_len / distance_units)
                                for k in range(1, n_steps + 1):
                                    frac = (k * distance_units) / seg_len
                                    if frac >= 0.999:
                                        break
                                    ix = vertex.x() + frac * dx
                                    iy = vertex.y() + frac * dy
                                    ikey = (round(ix, 4), round(iy, 4))
                                    if ikey not in global_placed_coords:
                                        global_placed_coords.add(ikey)
                                        int_dist = cumulative + k * distance_units
                                        dist_out = int_dist if not is_geographic else int_dist * meters_per_degree
                                        
                                        # PHASE 1: Intermediate poles
                                        pole_role = 'distribution'
                                        pole_height = self._get_pole_height(pole_role)
                                        pole_thickness = self._get_pole_thickness(pole_role)
                                        install_notes = self._get_installation_notes(pole_role, 'intermediate', pole_height, pole_thickness)
                                        
                                        pole_feat = QgsFeature(pole_layer.fields())
                                        pole_feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(ix, iy)))
                                        pole_feat.setAttributes([
                                            pole_id, span_id, round(dist_out, 2), 'intermediate',
                                            pole_role, pole_height, pole_thickness, install_notes
                                        ])
                                        pole_features.append(pole_feat)
                                        pole_id += 1
                                        total_poles += 1

                            cumulative += seg_len
            
            if len(pole_features) == 0:
                self.log_message("WARNING: No poles were generated. Check span layer geometry.")
                return
            
            # Add features to layer
            provider.addFeatures(pole_features)
            pole_layer.updateExtents()
            
            # Apply symbology
            categories = []
            pole_styles = {
                'start': ('0,200,0', 4.0),        # Bright green
                'intermediate': ('100,149,237', 3.0),  # Cornflower blue
                'kink': ('255,140,0', 4.0),      # Dark orange
                'end': ('220,20,60', 4.0)        # Crimson red
            }
            
            for pole_type, (color, size) in pole_styles.items():
                symbol = QgsMarkerSymbol.createSimple({
                    'name': 'circle',
                    'color': color,
                    'size': str(size),
                    'outline_color': 'black',
                    'outline_width': '0.8'
                })
                category = QgsRendererCategory(pole_type, symbol, pole_type.capitalize())
                categories.append(category)
            
            renderer = QgsCategorizedSymbolRenderer('pole_type', categories)
            pole_layer.setRenderer(renderer)
            
            # Add layer to project
            pole_layer = self._add_output_layer(pole_layer)
            
            # Summary statistics
            feeder_count = sum(1 for f in pole_features if f['pole_role'] == 'feeder')
            distribution_count = sum(1 for f in pole_features if f['pole_role'] == 'distribution')
            start_count = sum(1 for f in pole_features if f['pole_type'] == 'start')
            intermediate_count = sum(1 for f in pole_features if f['pole_type'] == 'intermediate')
            kink_count = sum(1 for f in pole_features if f['pole_type'] == 'kink')
            end_count = sum(1 for f in pole_features if f['pole_type'] == 'end')
            
            self.log_message(f"\n✓ PHASE 1: Generated {total_poles} poles with enhanced attributes")
            self.log_message(f"  Feeder poles: {feeder_count} @ 7.0m")
            self.log_message(f"  Distribution poles: {distribution_count} @ 5.4-7.0m")
            self.log_message(f"  By type: {start_count} start (green) | {intermediate_count} intermediate (blue) | "
                            f"{kink_count} kink (orange) | {end_count} end (red)")
            self.log_message("  All poles: SANS 754 H4 treated with FTTH spec details in attributes")
            self.log_message(f"Layer: '{pole_layer.name()}'")
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR generating poles: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_generate_feeder_routes_clicked(self):
        """Generate fiber feeder routes from OLT to aggregation points along routing layer."""
        from qgis.core import (
            QgsVectorLayer, QgsFeature, QgsGeometry, QgsWkbTypes, QgsField
        )
        from qgis.PyQt.QtCore import QMetaType
        from qgis.PyQt.QtGui import QColor

        olt_layer = self.comboBox_olt_layer.currentLayer()
        agg_layer = self.comboBox_aggregation_layer.currentLayer()
        routing_layer = self.comboBox_routing_layer.currentLayer()

        if not olt_layer:
            self.log_message("ERROR: Please select an OLT layer.")
            return
        if not agg_layer:
            self.log_message("ERROR: Please select an Aggregation Points layer.")
            return

        self.log_message("\n=== Generating Feeder Routes ===")
        self._start_timer()  # _start_timer takes no args (matches all other call sites)
        from qgis.PyQt.QtWidgets import QApplication
        QApplication.processEvents()

        try:
            # Get OLT point (use first feature)
            olt_features = list(olt_layer.getFeatures())
            if not olt_features:
                self.log_message("ERROR: OLT layer has no features.")
                return
            olt_geom = olt_features[0].geometry()
            if not olt_geom or olt_geom.isEmpty():
                self.log_message("ERROR: OLT feature has no geometry.")
                return
            olt_point = olt_geom.asPoint() if olt_geom.type() == QgsWkbTypes.GeometryType.PointGeometry else olt_geom.centroid().asPoint()

            # Collect aggregation points
            agg_points = []
            for feat in agg_layer.getFeatures():
                geom = feat.geometry()
                if geom and not geom.isEmpty():
                    pt = geom.asPoint() if geom.type() == QgsWkbTypes.GeometryType.PointGeometry else geom.centroid().asPoint()
                    zone_name = feat['zone_name'] if 'zone_name' in [f.name() for f in agg_layer.fields()] else str(feat.id())
                    agg_points.append((pt, zone_name, feat.id()))

            if not agg_points:
                self.log_message("ERROR: No aggregation points found.")
                return

            self.log_message(f"OLT point: ({olt_point.x():.1f}, {olt_point.y():.1f})")
            self.log_message(f"Aggregation points: {len(agg_points)}")

            # Build routing graph from span layer if available
            route_segments = []
            if routing_layer and routing_layer.geometryType() == QgsWkbTypes.GeometryType.LineGeometry:
                self.log_message(f"Routing layer: '{routing_layer.name()}'")
                for feat in routing_layer.getFeatures():
                    geom = feat.geometry()
                    if geom and not geom.isEmpty():
                        route_segments.append(geom)

            # Create feeder routes layer
            crs_str = agg_layer.crs().authid()
            feeder_layer = QgsVectorLayer(f"LineString?crs={crs_str}", "Feeder Routes", "memory")
            provider = feeder_layer.dataProvider()
            provider.addAttributes([
                QgsField('route_id', QMetaType.Type.Int),
                QgsField('zone_name', QMetaType.Type.QString),
                QgsField('agg_point_id', QMetaType.Type.Int),
                QgsField('length_m', QMetaType.Type.Double),
            ])
            feeder_layer.updateFields()

            route_id = 1
            feeder_layer.startEditing()

            for pt, zone_name, agg_id in agg_points:
                self._progress(route_id - 1, len(agg_points), f"Routing to {zone_name}")
                QApplication.processEvents()

                if route_segments:
                    # Snap OLT and target to nearest point on routing network, then connect via straight line
                    # Simple approach: find nearest route segment endpoints and connect
                    best_line = self._route_along_network(olt_point, pt, route_segments)
                else:
                    # Straight-line feeder
                    best_line = QgsGeometry.fromPolylineXY([olt_point, pt])

                feat = QgsFeature(feeder_layer.fields())
                feat.setGeometry(best_line)
                feat['route_id'] = route_id
                feat['zone_name'] = zone_name
                feat['agg_point_id'] = agg_id
                feat['length_m'] = round(best_line.length(), 2)
                feeder_layer.addFeature(feat)
                route_id += 1

            feeder_layer.commitChanges()

            # Style: dark blue line, width 0.8
            from qgis.core import QgsSimpleLineSymbolLayer, QgsSingleSymbolRenderer, QgsSymbol
            symbol = QgsSymbol.defaultSymbol(QgsWkbTypes.GeometryType.LineGeometry)
            sym_layer = QgsSimpleLineSymbolLayer()
            sym_layer.setColor(QColor('#003399'))
            sym_layer.setWidth(0.8)
            symbol.changeSymbolLayer(0, sym_layer)
            feeder_layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            feeder_layer = self._add_output_layer(feeder_layer)
            self.log_message(f"Generated {route_id - 1} feeder routes.")
            self._elapsed("Total time")

        except Exception as e:
            self.log_message(f"ERROR generating feeder routes: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def _route_along_network(self, start_pt, end_pt, route_segments):
        """Find a path along route segments from start to end using nearest-segment snapping.
        Falls back to straight line if no path found."""
        from qgis.core import QgsGeometry, QgsPointXY
        import math

        def dist(p1, p2):
            return math.sqrt((p1.x() - p2.x()) ** 2 + (p1.y() - p2.y()) ** 2)

        def nearest_point_on_segment(px, py, ax, ay, bx, by):
            dx, dy = bx - ax, by - ay
            if dx == 0 and dy == 0:
                return QgsPointXY(ax, ay)
            t = max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)))
            return QgsPointXY(ax + t * dx, ay + t * dy)

        # Find closest point on network to start and end
        best_start, best_end = None, None
        best_sd, best_ed = float('inf'), float('inf')

        for seg_geom in route_segments:
            pts = seg_geom.asPolyline() if seg_geom.isMultipart() is False else []
            if not pts:
                try:
                    for part in seg_geom.asMultiPolyline():
                        pts.extend(part)
                except Exception:
                    continue
            for i in range(len(pts) - 1):
                snap_s = nearest_point_on_segment(start_pt.x(), start_pt.y(), pts[i].x(), pts[i].y(), pts[i+1].x(), pts[i+1].y())
                snap_e = nearest_point_on_segment(end_pt.x(), end_pt.y(), pts[i].x(), pts[i].y(), pts[i+1].x(), pts[i+1].y())
                ds = dist(start_pt, snap_s)
                de = dist(end_pt, snap_e)
                if ds < best_sd:
                    best_sd, best_start = ds, snap_s
                if de < best_ed:
                    best_ed, best_end = de, snap_e

        if best_start and best_end:
            return QgsGeometry.fromPolylineXY([start_pt, best_start, best_end, end_pt])
        return QgsGeometry.fromPolylineXY([start_pt, end_pt])

    def on_clear_output_clicked(self):
        """Clear the output text."""
        self.log_message("Output cleared.")

    def closeEvent(self, event):
        """Handle the close event."""
        self.closingPlugin.emit()
        event.accept()
