# -*- coding: utf-8 -*-
"""HLD Book (custom pages) — the page SPEC, in pure Python (no QGIS imports).

A custom-pages book is one atlas whose every page draws its own layer set. This module
holds everything about that spec that can be decided without QGIS, so it can be property
tested in isolation:

  * the spec dict (overview pages, the shared PON-page set, per-zone overrides) and its
    JSON round-trip + validation,
  * the default page contents (JJ 2026-10-08: page 1 area, page 2 PONs with labels,
    page 3 FTS splitters, page 4 feeders, then one page per PON with the network on),
  * the never-show rule for layers that no book draws,
  * draw order, the "expected draw set" (listed ids plus same-named twins, JJ 18:00:
    draw both and warn, never refuse) and the per-page draw check verdict,
  * the metric zone fingerprint used to tie a per-PON override to its zone, not its number.

QGIS-side reading and writing lives in book_pages_qgis.py.
"""
import json
import math
import os
import re
import secrets

SPEC_VERSION = 1

# QSettings keys. The model switch is the master: while it is off nothing of this feature
# is reachable (no model in the dialog, no designer hook). Default OFF until the release
# that switches it on (plan Rev 8, S8).
SETTING_MODEL = "vf/hld/book_pages_model"
SETTING_BUTTON = "vf/hld/book_pages_button"
SETTING_GUARD = "vf/hld/book_pages_guard"
MODEL_DEFAULT_ON = False
BUTTON_DEFAULT_ON = True
GUARD_DEFAULT_ON = True

MODEL_ID = "hld_book_pages"
ASBUILT_MODEL_ID = "hld_asbuilt"
BOOK_MODEL_IDS = (MODEL_ID, ASBUILT_MODEL_ID)
FRAME_HLD = "hld"
FRAME_ASBUILT = "asbuilt"
PROP_BOOK_ID = "vf_book_id"          # on the layout and on every book-owned layer
PROP_SPEC = "vf_book_spec"           # full spec JSON on the layout
PROP_ROLE = "vf_book_role"           # pages | guard | label (on book-owned layers)
PROP_AUTO_LABEL = "vf_auto_label"    # on legend nodes the tool may still rewrite
NAME_PREFIX = "vfbk_"
# Oldest QGIS the book was MEASURED on (2026-10-09: all ACs on 3.38.0, 3.40.3, 3.44.9 and 4.2.0 -
# every version the team runs). Older versions see the model greyed out with the reason.
MIN_QGIS_INT = 33800
MIN_QGIS_TEXT = "3.38"

# Network roles the engine knows (hld_atlas_engine.py CFG["roles"]); every one the project
# has is always on a PON page (A3: "feeders poles splitters ect all on").
PON_PAGE_ROLES = ("primary", "secondary", "distribution", "drop", "spare_drop", "poles",
                  "fts", "sts", "enc_splice", "enc_conn", "enclosure", "ont", "coverage")
FEEDER_ROLES = ("primary", "secondary")

# Kinds no book draws (phases.py _NEVER_SHOW + hld_atlas_engine.py detail_exclude + the
# demand-point layers the round-8 review found on Mohadin). Matched on whole words in the
# lower-cased name, so "Splitter Points" is not "demand point".
_NEVER_SHOW_RE = re.compile(
    r"(?i)\b(demand\s*points?|demand\s*units?|ajoint|splicing|zones?|slack|erven|erfs?|"
    r"tbc|to be confirmed)\b")

_HEX12 = re.compile(r"^[0-9a-f]{12}$")
NAME_RE = re.compile(r"^vfbk_[0-9a-f]{12}_(pages|guard|lbl_[0-9]+)$")
ROLE_KEYWORDS = ("pon", "zone", "pole", "fts", "sts", "agg", "splitter", "enclosure", "closure",
                 "joint", "manhole", "chamber", "handhole", "splice", "connectoris", "connectoriz",
                 "ont", "home connection", "premise", "drop point", "customer", "primary",
                 "feeder", "secondary", "distribution", "mini", "drop", "spare", "greenfield",
                 "overbuild", "boundary", "aoi", "area of interest", "extent", "erven", "erf",
                 "building", "grid")


# ── ids and names ──────────────────────────────────────────────────────────────────────
def new_book_id():
    """12 random lowercase hex chars — hex can never spell a role keyword."""
    return secrets.token_hex(6)


def is_book_id(s):
    return bool(_HEX12.match(str(s or "")))


def pages_layer_name(book_id):
    return "%s%s_pages" % (NAME_PREFIX, book_id)


def guard_layer_name(book_id):
    return "%s%s_guard" % (NAME_PREFIX, book_id)


def label_layer_name(book_id, n):
    return "%s%s_lbl_%d" % (NAME_PREFIX, book_id, int(n))


def name_has_role_keyword(name):
    low = (name or "").lower()
    return any(k in low for k in ROLE_KEYWORDS)


def is_never_show(name):
    return bool(_NEVER_SHOW_RE.search(name or ""))


# ── spec ───────────────────────────────────────────────────────────────────────────────
def empty_spec(book_id=None, title="HLD"):
    return {
        "version": SPEC_VERSION,
        "book_id": book_id or new_book_id(),
        "title": title,
        "layout_name": "",
        "phase": None,
        "pon_layer_id": "",
        "pon_label_field": "",
        "pon_sort_field": "",
        "pon_sort_numeric": False,
        "pon_title_prefix": "PON ",
        "metric_epsg": 0,
        "overview_wkt": "",
        "overview_srid": 0,
        "aerial_id": "",
        "guard_id": "",
        "pages_id": "",
        "label_layers": {},        # source layer id -> label layer id
        "overview": [],            # [{"title","ids","labels","note"}]
        "pon": {"ids": [], "labels": [], "note": ""},
        "overrides": [],           # [{"cx","cy","area","pon","ids","labels","note"}]
        "legend_known": [],        # layer ids the legend already offered (user deletions stick)
        "defaults_left_out": [],   # default page titles left out because no layer matched
        "frame": None,             # {"x","y","w","h"} the designed map frame (mm)
        "frame_kind": FRAME_HLD,   # hld = A3 + sidebar; asbuilt = A4 + bottom strip
        "asbuilt": {},             # As-Built typed details + the layers its counts read
    }


def make_page(title, ids=(), labels=(), note=""):
    return {"title": str(title), "ids": _uniq(ids), "labels": _uniq(labels), "note": str(note or "")}


def _uniq(seq):
    out, seen = [], set()
    for x in seq or ():
        x = str(x)
        if x and x not in seen:
            seen.add(x); out.append(x)
    return out


def unique_titles(titles):
    """Make page titles unique by suffixing ' (2)', ' (3)'… — order kept."""
    out, used = [], set()
    for t in titles:
        base = str(t).strip() or "Page"
        cand, n = base, 2
        while cand.lower() in used:
            cand = "%s (%d)" % (base, n); n += 1
        used.add(cand.lower()); out.append(cand)
    return out


def normalise(spec):
    """Return a cleaned copy: unique titles, de-duplicated id lists, labels ⊆ ids."""
    s = json.loads(json.dumps(spec))
    base = empty_spec(s.get("book_id"), s.get("title", "HLD"))
    for k, v in base.items():
        s.setdefault(k, v)
    ov = []
    for p in s.get("overview") or []:
        ids = _uniq(p.get("ids"))
        ov.append(make_page(p.get("title", ""), ids, [x for x in _uniq(p.get("labels")) if x in ids],
                            p.get("note", "")))
    for p, t in zip(ov, unique_titles([p["title"] for p in ov])):
        p["title"] = t
    s["overview"] = ov
    pon = s.get("pon") or {}
    pids = _uniq(pon.get("ids"))
    s["pon"] = {"ids": pids, "labels": [x for x in _uniq(pon.get("labels")) if x in pids],
                "note": str(pon.get("note") or "")}
    ovr = []
    for o in s.get("overrides") or []:
        ids = _uniq(o.get("ids"))
        ovr.append({"cx": float(o["cx"]), "cy": float(o["cy"]), "area": float(o["area"]),
                    "pon": str(o.get("pon", "")), "ids": ids,
                    "labels": [x for x in _uniq(o.get("labels")) if x in ids],
                    "note": str(o.get("note") or "")})
    s["overrides"] = ovr
    s["legend_known"] = _uniq(s.get("legend_known"))
    s["frame_kind"] = FRAME_ASBUILT if s.get("frame_kind") == FRAME_ASBUILT else FRAME_HLD
    s["asbuilt"] = dict(s.get("asbuilt") or {}) if s["frame_kind"] == FRAME_ASBUILT else {}
    s["label_layers"] = {str(k): str(v) for k, v in (s.get("label_layers") or {}).items()}
    return s


def to_json(spec):
    return json.dumps(normalise(spec), sort_keys=True, separators=(",", ":"))


def from_json(text):
    s = json.loads(text)
    if not isinstance(s, dict) or int(s.get("version", 0)) != SPEC_VERSION:
        raise ValueError("not a version-%d book spec" % SPEC_VERSION)
    if not is_book_id(s.get("book_id")):
        raise ValueError("book spec has no valid book id")
    return normalise(s)


def validate(spec, names_by_id):
    """(errors, warnings). `names_by_id` = {layer id: current name} of the project.

    Errors refuse a build/export: a page with nothing listed, a listed layer whose name
    contains '|' (the map's layer expression is '|'-joined), the PON layer missing.
    Warnings never refuse: a listed layer that no longer exists (the page draws without
    it), and same-named layers (both draw — JJ 18:00)."""
    errors, warnings = [], []
    s = normalise(spec)
    if not s.get("pon_layer_id") or s["pon_layer_id"] not in names_by_id:
        errors.append("The PON layer this book pages over is missing from the project "
                      "(use “Re-attach PON layer”).")
    pages = [(p["title"], p["ids"]) for p in s["overview"]] + [("PON pages", s["pon"]["ids"])]
    pages += [("PON %s (own layers)" % (o.get("pon") or "?"), o["ids"]) for o in s["overrides"]]
    counts = {}
    for n in names_by_id.values():
        counts[n] = counts.get(n, 0) + 1
    for title, ids in pages:
        if not ids:
            errors.append("Page “%s” has no layers ticked." % title)
        for i in ids:
            n = names_by_id.get(i)
            if n is None:
                warnings.append("Page “%s”: a listed layer no longer exists." % title)
                continue
            if "|" in n:
                errors.append("Page “%s”: layer name “%s” contains “|” — rename it." % (title, n))
            if counts.get(n, 0) > 1:
                warnings.append("Page “%s”: %d layers are named “%s”; all of them draw."
                                % (title, counts[n], n))
    return errors, _uniq(warnings)


# ── defaults ───────────────────────────────────────────────────────────────────────────
def default_pages(roles, ticked, aoi_id="", pon_id="", fts_id="", label_pon=True):
    """Default overview pages + shared PON-page set.

    roles  : {role: [layer id, ...]} — the engine's own resolution per role (v1-canonical).
    ticked : [(layer id, name)] — vector layers ticked in the Layers panel.
    Returns (overview_pages, pon_ids, pon_labels)."""
    feeders = []
    for r in FEEDER_ROLES:
        feeders += list(roles.get(r) or [])
    ov = [make_page("Area", [aoi_id] if aoi_id else []),
          make_page("PON zones", [pon_id] if pon_id else [], [pon_id] if (pon_id and label_pon) else []),
          make_page("FTS splitters", [fts_id] if fts_id else []),
          make_page("Feeders", feeders)]
    pon_ids = []
    for r in PON_PAGE_ROLES:
        for lid in roles.get(r) or []:
            pon_ids.append(lid)
    for lid, name in ticked or []:
        if not is_never_show(name):
            pon_ids.append(lid)
    return ov, _uniq(pon_ids), []


# ── draw order / page ids ──────────────────────────────────────────────────────────────
_KIND_RANK = {"point": 0, "line": 1, "polygon": 2, "unknown": 3, "raster": 4}


def ordered_ids(ids, kinds, tree_order=None):
    """Top-first draw order: points, lines, polygons, then rasters; ties keep the Layers
    panel order (`tree_order` = ids top-first), then the listed order."""
    pos = {lid: i for i, lid in enumerate(tree_order or [])}
    lst = _uniq(ids)
    return sorted(lst, key=lambda i: (_KIND_RANK.get(kinds.get(i, "unknown"), 3),
                                      pos.get(i, 10 ** 6), lst.index(i)))


def page_id_list(ids, labels, label_layers, aerial_id, guard_id, kinds, tree_order=None):
    """The ids a page's row stores: its layers (top-first) with each labelled layer's label
    layer directly above it, then aerial, then the guard. Aerial + guard are always there,
    so a row can never resolve to nothing."""
    out = []
    for i in ordered_ids([x for x in ids if x not in (aerial_id, guard_id)], kinds, tree_order):
        if i in labels and label_layers.get(i):
            out.append(label_layers[i])
        out.append(i)
    if aerial_id:
        out.append(aerial_id)
    if guard_id:
        out.append(guard_id)
    return _uniq(out)


def join_ids(ids):
    return "|".join(ids)


def split_ids(text):
    return [x for x in str(text or "").split("|") if x]


# ── draw check ─────────────────────────────────────────────────────────────────────────
def expected_draw_set(page_ids, names_by_id):
    """Listed ids that still exist, plus every layer sharing a listed layer's current name
    (QGIS draws by name, so a same-named twin always comes along — JJ 18:00: allowed)."""
    listed = {i for i in page_ids if i in names_by_id}
    names = {names_by_id[i] for i in listed}
    twins = {i for i, n in names_by_id.items() if n in names and i not in listed}
    return listed | twins, twins


def check_page(page_ids, rendered_ids, names_by_id):
    """Verdict for one page. Returns dict(ok, missing, extra, twins, deleted).

    ok is False when something draws that is not expected, or a listed layer that exists
    does not draw. Same-named twins and deleted layers never make it False on their own
    (twins warn; a deleted layer is reported by validate() and refused by the exports)."""
    expected, twins = expected_draw_set(page_ids, names_by_id)
    rendered = set(rendered_ids)
    listed_existing = {i for i in page_ids if i in names_by_id}
    missing = sorted(listed_existing - rendered)
    extra = sorted(rendered - expected)
    deleted = sorted(i for i in page_ids if i not in names_by_id)
    return {"ok": not missing and not extra, "missing": missing, "extra": extra,
            "twins": sorted(twins & rendered), "deleted": deleted}


# ── zone fingerprint ───────────────────────────────────────────────────────────────────
ZONE_DIST_M = 5.0
ZONE_AREA_FRAC = 0.02


def utm_epsg(lon, lat):
    """WGS84 UTM zone EPSG for a lon/lat (south 327xx, north 326xx)."""
    z = int(math.floor((float(lon) + 180.0) / 6.0)) % 60 + 1
    return (32700 if float(lat) < 0 else 32600) + z


def zone_matches(fp, cx, cy, area):
    """Same zone? centroid within 5 m and area within 2 % — all in metres."""
    try:
        a0 = float(fp["area"])
        d = math.hypot(float(cx) - float(fp["cx"]), float(cy) - float(fp["cy"]))
        return d <= ZONE_DIST_M and a0 > 0 and abs(float(area) - a0) <= ZONE_AREA_FRAC * a0
    except Exception:
        return False


# ── SQL (virtual page layer) ───────────────────────────────────────────────────────────
def sql_str(s):
    return "'" + str(s if s is not None else "").replace("'", "''") + "'"


def sql_ident(s):
    return '"' + str(s).replace('"', '""') + '"'


def page_layer_sql(spec, page_rows, pon_alias="pon"):
    """SQL for the virtual page layer.

    page_rows: {"overview": [(title, ids_text, note)], "pon_ids": text, "pon_note": text,
                "overrides": [(cx, cy, area, ids_text, note)], "aerial_guard": text}
    Columns: seq, is_overview, unit, page_title, page_note, page_ids, geometry.
    The override CASE measures centroid distance and area in metres after ST_Transform
    to the spec's metric EPSG, so an EPSG:4326 project never compares degrees."""
    srid = int(spec["overview_srid"])
    geom = "GeomFromText(%s, %d)" % (sql_str(spec["overview_wkt"]), srid)
    # transient key (fixed As-Built books only, v2): one frame per overview page, None = default
    own = list(spec.get("overview_wkts") or [])
    parts = []
    for i, (title, ids_text, note) in enumerate(page_rows["overview"]):
        g = geom
        if i < len(own) and own[i]:
            g = "GeomFromText(%s, %d)" % (sql_str(own[i]), srid)
        parts.append("SELECT %d AS seq, 1 AS is_overview, %s AS unit, %s AS page_title, "
                     "%s AS page_note, %s AS page_ids, %s AS geometry"
                     % (i, sql_str("Overview"), sql_str(title), sql_str(note),
                        sql_str(ids_text), g))
    k = len(page_rows["overview"])
    fld = sql_ident(spec["pon_label_field"]) if spec.get("pon_label_field") else "NULL"
    sfld = sql_ident(spec["pon_sort_field"]) if spec.get("pon_sort_field") else fld
    order = ("CAST(%s AS REAL), %s" % (sfld, sfld)) if spec.get("pon_sort_numeric") else sfld
    unit = "COALESCE(CAST(%s AS TEXT), '')" % fld
    title = "%s || %s" % (sql_str(spec.get("pon_title_prefix") or ""), unit)
    if spec.get("pon_title_field"):        # transient key: fixed As-Built books only (S1)
        title = asbuilt_title_sql(spec["pon_title_field"], asbuilt_unit_word(spec))
    m = int(spec.get("metric_epsg") or 0)
    ids_case, note_case = [], []
    for cx, cy, area, ids_text, note in page_rows.get("overrides") or []:
        cond = ("ST_Distance(ST_Transform(ST_Centroid(geometry), %d), MakePoint(%r, %r, %d)) <= %r "
                "AND abs(ST_Area(ST_Transform(geometry, %d)) - %r) <= %r"
                % (m, float(cx), float(cy), m, ZONE_DIST_M, m, float(area), ZONE_AREA_FRAC * float(area)))
        ids_case.append("WHEN %s THEN %s" % (cond, sql_str(ids_text)))
        note_case.append("WHEN %s THEN %s" % (cond, sql_str(note)))
    ids_expr = sql_str(page_rows["pon_ids"])
    note_expr = sql_str(page_rows["pon_note"])
    if ids_case and m:
        ids_expr = "CASE %s ELSE %s END" % (" ".join(ids_case), ids_expr)
        note_expr = "CASE %s ELSE %s END" % (" ".join(note_case), note_expr)
    ids_expr = "COALESCE(NULLIF(%s, ''), %s)" % (ids_expr, sql_str(page_rows["aerial_guard"]))
    where = ""
    skip = sorted({int(x) for x in spec.get("skip_pon_fids") or ()})   # transient: fixed As-Built only
    if skip:
        where = " WHERE %s.rowid NOT IN (%s)" % (pon_alias, ", ".join(str(x) for x in skip))
    parts.append("SELECT %d + ROW_NUMBER() OVER (ORDER BY %s) AS seq, 0 AS is_overview, "
                 "%s AS unit, %s AS page_title, %s AS page_note, %s AS page_ids, "
                 "geometry FROM %s%s"
                 % (k - 1, order, unit, title, note_expr, ids_expr, pon_alias, where))
    return " UNION ALL ".join(parts)


# ── As-Built fixes (JJ 2026-10-27/28): PON titles from Name, isolated PON pages, readable
# labels. Fixed books carry spec["asbuilt_fix"]; A3 books and unfixed books never do, and
# every function below leaves their output byte-identical. ─────────────────────────────
ASBUILT_FIX_V = 1
ISO_TOL_M = 15.0               # JJ 19:30: within 15 m of a neighbouring zone counts as inside it
ISO_MAX_FEATURES = 100000      # a layer bigger than this is left whole (main-thread compute bound)
ISO_MAX_JSON = 4 * 1024 * 1024
ISO_RENDERERS = ("singleSymbol", "categorizedSymbol", "graduatedSymbol", "RuleRenderer")
NO_NAME_TITLE = "PON (no Name)"
_PK_RE = re.compile(r"^(fid|id|objectid|ogc_fid|fid_\d+)$", re.I)


def label_fit_on(spec):
    """The 'Make every label readable' tick: As-Built books only (the A3 book draws live labels, there
    is nothing of its own to fit). Stored choice, else on."""
    if (spec or {}).get("frame_kind") != FRAME_ASBUILT:
        return False
    v = (spec or {}).get("label_fit")
    return True if v is None else bool(v)


def label_printed_twice(placed):
    """How many labels really print more than once. placed = [(layer id, feature id, text)], one row per
    result QGIS returns. A curved label comes back one result per letter ('37' = 2 rows): that is one
    label, seen on Fouriesburg's cable ids."""
    groups = {}
    for lid, fid, text in placed:
        k = (lid, fid)
        groups.setdefault(k, [0, len(str(text or "").replace(chr(10), ""))])[0] += 1
    return sum(1 for n, chars in groups.values() if n > 1 and n != chars)


def label_report_lines(rows, max_pages=12):
    """Text for the check after a PDF export. rows = [{title, placed, missing: [text], overlaps, over_symbols}]."""
    rows = list(rows or [])
    placed = sum(r["placed"] for r in rows)
    missing = sum(len(r["missing"]) for r in rows)
    overlaps = sum(r["overlaps"] for r in rows)
    touching = sum(r["over_symbols"] for r in rows)
    twice = sum(r.get("printed_twice", 0) for r in rows)
    out = ["%d label(s) checked on %d page(s): %d missing, %d overlapping another label, %d touching a symbol%s."
           % (placed + missing, len(rows), missing, overlaps, touching,
              ", %d printed twice" % twice if twice else "")]
    bad = [r for r in rows if r["missing"] or r["overlaps"]]
    for r in bad[:max_pages]:
        bits = []
        if r["missing"]:
            bits.append("missing: " + ", ".join(t.replace("\n", " ") for t in r["missing"][:6])
                        + (" +%d more" % (len(r["missing"]) - 6) if len(r["missing"]) > 6 else ""))
        if r["overlaps"]:
            bits.append("%d overlapping" % r["overlaps"])
        out.append("%s - %s" % (r["title"], "; ".join(bits)))
    if len(bad) > max_pages:
        out.append("... and %d more page(s)." % (len(bad) - max_pages))
    return out


def new_asbuilt_fix(isolate=False):
    return {"v": ASBUILT_FIX_V, "isolate": bool(isolate), "owned_overrides": [], "clip_ids": []}


def valid_asbuilt_fix(fix):
    """True for a fix dict this code wrote (v 1, bool isolate, two string lists)."""
    if not isinstance(fix, dict) or fix.get("v") != ASBUILT_FIX_V or not isinstance(fix.get("isolate"), bool):
        return False
    for k in ("owned_overrides", "clip_ids"):
        v = fix.get(k, [])
        if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
            return False
    return True


def carry_asbuilt_fix(old_fix, spec):
    """Rule C (update_book): the stored fix wins; the incoming spec's value is ignored, so an
    unfixed or A3 book never gains the key and a fixed book keeps v + isolate as stored."""
    if old_fix is not None:
        spec["asbuilt_fix"] = json.loads(json.dumps(old_fix))
    else:
        spec.pop("asbuilt_fix", None)
    return spec


def _descriptor_pick(field_names, *cands):
    """Pure copy of presets.coverage_descriptor's pick(): exact, then normalised match."""
    def _norm(s):
        return s.strip().rstrip(" .:_-#").lower()
    for c in cands:
        if c in field_names:
            return c
    nc = {_norm(c) for c in cands}
    for n in field_names:
        if _norm(n) in nc:
            return n
    return None


def asbuilt_title_field(field_names, label_field, pk_names=()):
    """The PON layer's Name field for page titles, or None to keep today's title.

    Name wins when the stored label field is not a deliberate PON-number pick: empty or
    missing, the primary key, an id-like column (fid / id / objectid / ogc_fid), or the
    names[0] fallback of presets.coverage_descriptor (none of pon_no / pon / label resolved).
    A real pon_no / pon / label field (Cradock style) keeps its title."""
    names = list(field_names or [])
    name = next((f for f in names if f.lower() == "name"), None)
    if name is None:
        return None
    lf = label_field or ""
    if lf.lower() == "name":
        return None
    if not lf or lf not in names or lf in (pk_names or ()) or _PK_RE.match(lf):
        return name
    if _descriptor_pick(names, "pon_no", "pon", "label", "Label") is None and names and lf == names[0]:
        return name
    return None


# Universality (JJ 2026-10-30 "it needs to be universal"): HeroTel PON layers name their PON column
# PON / Pond / PON_No / ... and some Name columns are blank (KML imports) or one constant per phase
# ("HT_Mahikeng_P1" on every PON). A title column must tell the PONs apart.
_PON_FIELD_RE = re.compile(r"^(pon|pons|pond|ponds)([ _\-]?(no|nr|num|number|id|ref))?$", re.I)


def title_values_ok(values):
    """A column can title the PON pages: at least half the rows filled and the filled values
    (almost) all different - 3 in 4 distinct, and 2+ distinct when there are 2+ rows."""
    vals = list(values or [])
    if not vals:
        return False
    filled = [str(v).strip() for v in vals if v is not None and str(v).strip() and str(v).strip().upper() != "NULL"]
    if 2 * len(filled) < len(vals):
        return False
    distinct = len(set(s.lower() for s in filled))
    if len(vals) > 1 and distinct < 2:
        return False
    return 4 * distinct >= 3 * len(filled)


def asbuilt_title_pick(field_names, label_field, pk_names=(), values=None):
    """The column that titles a fixed As-Built book's PON pages, or None to keep today's title.

    values = {field: [value per PON row]}. Order: the Name column chosen by asbuilt_title_field
    when its values tell the PONs apart; else the stored label column when it is a real column
    that tells them apart (returned so a blank row reads 'PON (no Name)', not an empty title);
    else the first PON-named column (PON, Pond, PON_No ...), then Name, that tells them apart;
    else None (the label column - an id - keeps titling the pages: a data gap, reported)."""
    names = list(field_names or [])
    values = values or {}

    def ok(f):
        return f in names and f in values and title_values_ok(values[f])
    nm = asbuilt_title_field(names, label_field, pk_names)
    if nm and ok(nm):
        return nm
    lf = label_field or ""
    if lf in names and lf not in (pk_names or ()) and not _PK_RE.match(lf) and ok(lf):
        return lf
    for f in names:
        if f != lf and _PON_FIELD_RE.match(f.strip()) and ok(f):
            return f
    for f in names:
        if f.lower() == "name" and ok(f):
            return f
    return None


def title_candidates(field_names, label_field):
    """The columns asbuilt_title_pick may read values from (so the caller reads only those)."""
    names = list(field_names or [])
    return [f for f in names if f == label_field or f.lower() == "name" or _PON_FIELD_RE.match(f.strip())]


def asbuilt_unit_word(spec):
    """'PON ' -> 'PON'; 'Botshabelo - PON ' -> 'PON'; '' -> 'PON'."""
    toks = str(spec.get("pon_title_prefix") or "").split()
    return toks[-1] if toks else "PON"


def asbuilt_title_sql(name_field, unit_word="PON"):
    """SQL page title from the Name field: blank -> 'PON (no Name)'; a Name that already starts
    with the unit word is used as is ('PON 001'); else '<unit> <Name>'."""
    n = sql_ident(name_field)
    u = sql_str(unit_word or "PON")
    return ("CASE WHEN TRIM(COALESCE(CAST(%s AS TEXT), '')) = '' THEN %s "
            "WHEN lower(TRIM(CAST(%s AS TEXT))) LIKE lower(%s) || '%%' THEN TRIM(CAST(%s AS TEXT)) "
            "ELSE %s || ' ' || TRIM(CAST(%s AS TEXT)) END"
            % (n, sql_str(NO_NAME_TITLE if (unit_word or "PON") == "PON" else "%s (no Name)" % unit_word),
               n, u, n, u, n))


def asbuilt_title_py(name, unit_word="PON"):
    """Python twin of asbuilt_title_sql (messages + tests)."""
    s = "" if name is None else str(name).strip()
    u = unit_word or "PON"
    if not s:
        return NO_NAME_TITLE if u == "PON" else "%s (no Name)" % u
    return s if s.lower().startswith(u.lower()) else "%s %s" % (u, s)


def name_defects(rows):
    """rows: [(fid, name)] -> (blank fids, {name: [fids]} for duplicated names)."""
    blank, seen = [], {}
    for fid, name in rows:
        s = "" if name is None else str(name).strip()
        if not s:
            blank.append(fid)
        else:
            seen.setdefault(s.lower(), []).append(fid)
    return sorted(blank), {k: sorted(v) for k, v in seen.items() if len(v) > 1}


def iso_pages_for(hits, tol=ISO_TOL_M):
    """The PON pages that draw one feature. hits = [(unit, distance_m)] to every zone near it
    (distance 0 = touches / inside). Returns a sorted unit list, or None = drawn on every page
    whose frame shows it (it lies farther than tol from every zone: JJ keeps no-zone assets).

    JJ 2026-10-28 10:30 + 19:30: a feature is hidden on a PON page when it lies inside or
    within tol of a NEIGHBOURING zone and does not touch the page's own zone. A feature in no
    zone but within tol of one or more is shown on the nearest zone's page (UD-NOPAGE (a))."""
    inside = sorted({str(u) for u, d in hits if d is not None and d <= 0})
    if inside:
        return inside
    near = sorted((float(d), str(u)) for u, d in hits if d is not None and d <= tol)
    if near:
        return [near[0][1]]
    return None


def iso_merge(prev, new, first=False):
    """Two features with the same key: drawn wherever either is (None = every page wins)."""
    if first:
        return new
    if prev is None or new is None:
        return None
    return sorted(set(prev) | set(new))


def beside_copy_name(project_path, book_id, stamp):
    """'<stem>.before_asbuilt_fix_<book_id>_<stamp>.<qgz|qgs>' in the project's own folder."""
    stem, ext = os.path.splitext(project_path)
    return "%s.before_asbuilt_fix_%s_%s%s" % (stem, book_id, stamp, ext or ".qgz")


def iso_map_json(pages_by_key):
    """{feature key: [units] | None} -> compact JSON {key: '|u1|u2|'}; None (all pages) is left out."""
    m = {}
    for k, units in pages_by_key.items():
        if units is None or k is None:
            continue
        prev = m.get(k)
        cur = set(prev.strip("|").split("|")) if prev else set()
        cur |= {str(u) for u in units}
        m[k] = "|" + "|".join(sorted(cur)) + "|"
    return json.dumps(m, sort_keys=True, separators=(",", ":"))


def iso_key_expr(geographic):
    """QGIS expression giving a feature its isolate key from its geometry (layer CRS): the
    centroid to ~1 cm plus the vertex count. Geometry, never the fid (OGR renumbers fids)."""
    return ("geom_to_wkt(centroid($geometry), %d) || '/' || to_string(num_points($geometry))"
            % (7 if geographic else 2))


def iso_filter_expr(map_json, key_expr):
    """Render-time filter for one layer on the book map: true on overview pages, on a PON page
    true when the feature's stored page list names this page; a feature with no stored list
    (in no zone, or added after the last Rebuild / Edit pages) is always drawn. A plain hash
    lookup in a static JSON literal - no overlay_* call at render time."""
    lit = "'" + map_json.replace("\\", "\\\\").replace("'", "''") + "'"
    return ("coalesce(attribute(@atlas_feature, 'is_overview'), 1) = 1 OR "
            "coalesce(strpos(map_get(from_json(%s), %s), '|' || to_string(attribute(@atlas_feature, 'unit')) || '|') > 0, true)"
            % (lit, key_expr))


def label_priority(name, kind, is_pon=False):
    """Label priority on the book's own label copies: PON 9 > FAP / CTP 8 > poles 6 > cables 4."""
    if is_pon:
        return 9
    n = (name or "").lower()
    if any(w in n for w in ("fap", "ctp", "link joint", "dc joint", "dc_joint", "link_joint")):
        return 8
    if "pole" in n:
        return 6
    if kind == "line":
        return 4
    return 5


def map_layers_expression(guard_name):
    """Data-defined map layers: the page row's ids turned into CURRENT names when drawn
    (a rename never drops a layer), falling back to the guard layer so the list can never
    be empty — an empty list makes QGIS draw every ticked Layers-panel layer."""
    return ("coalesce(nullif(array_to_string(array_filter(array_foreach("
            "string_to_array(coalesce(attribute(@atlas_feature,'page_ids'),''),'|'),"
            "layer_property(@element,'name')), @element IS NOT NULL AND @element <> ''),'|'),''),"
            "%s)" % sql_str(guard_name))


def legend_label(friendly, total_text):
    return "%s (%s)" % (friendly, total_text) if total_text else friendly


# ── As-Built frame (JJ 2026-10-21: Lodewijk's Cradock Phase 1 As-built PDF) ─────────────
# A4 landscape. Map on top, a bottom strip on every page: "Asbuilt" + the page name and a
# north arrow | legend with feature counts | 3 x 5 facts table | logo. Measured off the PDF
# (pages 1-16 share the strip): frame 2.2 mm in, map bottom 174.0, table 134.4-240.4 x
# 175.1-205.2 in five 6 mm rows, logo box from 240.6.
ASBUILT = dict(page_w=297.0, page_h=210.0, frame_x=2.2, frame_y=2.2, frame_w=292.0, frame_h=204.9,
               map_x=2.2, map_y=2.2, map_w=292.0, map_h=171.8,
               strip_y=174.0, strip_h=33.1,
               title_x=4.0, title_y=175.5, title_w=42.0, title_h=10.0,
               north_x=6.0, north_y=186.0, north_w=11.0, north_h=15.0,
               legend_x=47.0, legend_y=175.0, legend_w=85.5, legend_h=31.2,
               table_x=134.4, table_y=175.1, table_w=106.0, table_row_h=6.02,
               table_cols=(38.6, 25.1, 42.3),
               logo_x=240.6, logo_w=53.6,
               tiein_x=10.2, tiein_y=71.5, tiein_w=60.0, tiein_h=10.0)   # under page_pictures' default slot (map + 8 mm, 80 x 60)

# Layer roles an as-built page shows, matched on the layer NAME (HeroTel names differ per
# town: 16Way_Splitter, FAP, Feeder Joints...). Each role lists keyword groups in priority
# order: the first group that matches a layer wins, so a real 1:16 splitter layer beats a
# feeder-joint layer. Every keyword is matched on the lower-cased name with "_" / "-" read as
# spaces, and also with the spaces removed ("16Way_Splitter" -> "16way splitter", "16waysplitter").
ASBUILT_ROLES = (
    # role,           geometry, keyword groups (priority order),                         exclude,                          many
    ("backhaul",      "line",  (("backhaul",), ("back haul",), ("bh pop", "pop route", "bh route")),
                                                                                         ("pole", "joint"),                False),
    ("feeder_link",   "line",  (("feeder link", "link fibre", "link cable"), ("link",)),  ("joint", "pole"),                False),
    ("feeder",        "line",  (("feeder",), ("primary",)),                              ("link", "joint", "pole"),        False),
    ("spur",          "line",  (("spur",),),                                             ("joint", "pole"),                False),
    ("distribution",  "line",  (("distribution",), ("dc fibre", "dc cable"), (r"re:\bdc\b",),
                                (r"re:\bcables?\b",)),
                                                                                         ("spare", "joint", "spur", "pole", "drop"), True),
    ("existing_pole", "point", (("existing herotel pole", "existing ht pole", "tie in", "tie-in", "breakin", "break in"),
                                ("existing pole",)),                                    (),                               False),
    ("poles",         "point", (("pole",),),                                             ("existing", "joint"),            True),
    ("fap",           "point", (("16way", "16 way", "1:16", "1x16"), ("fap",), ("fts",), ("feeder joint",)),
                                                                                         ("link joint",),                  False),
    ("ctp",           "point", (("8way", "8 way", "1:8", "1x8"), ("ctp",), ("sts",), ("dc joint",), ("dome joint", "dome")),
                                                                                         (),                               False),
    ("units",         "point", (("demand point", "demand unit", "demand"), ("home connection", "premise")),
                                                                                         ("pole", "joint"),                False),
    # not drawn by default: only the unit count's fallback when a project has no demand points
    ("drops",         "line",  (("drop",),),                                             ("spare", "pole", "joint"),       False),
)
ASBUILT_LINE_ROLES = ("backhaul", "feeder_link", "feeder", "spur", "distribution")

# Legend wording off Lodewijk's sheets.
ASBUILT_LABELS = {"backhaul": "Backhaul", "feeder_link": "Feeder Link", "feeder": "Feeder",
                  "spur": "Dist Spur", "distribution": "Distribution", "existing_pole": "Existing Herotel Pole",
                  "poles": "Poles", "fap": "FAP's", "ctp": "CTP's", "pon": "PON"}


def _role_name(name):
    low = re.sub(r"[_\-]+", " ", str(name or "").lower())
    return low, low.replace(" ", "")


def _hits(name, words):
    """A keyword hit on the name; a keyword written 're:<pattern>' is a regex on the spaced
    lower-case name (whole-word 'dc' in 'DC 12F' / 'dc_24f_phs1', never inside 'abdc')."""
    low, tight = _role_name(name)
    for w in words:
        if w.startswith("re:"):
            if re.search(w[3:], low):
                return True
        elif (w in low) or (w.replace(" ", "") in tight):
            return True
    return False


def asbuilt_roles(layers):
    """{role: [layer id, ...]} for the as-built page set.

    layers: [(id, name, kind, feature count)] in Layers-panel order (top first), book-owned
    layers already left out. A layer is taken by at most one role (the first in ASBUILT_ROLES
    that wants it). Within a role the best keyword group wins; ties go to a non-empty layer,
    then to the panel order. A role marked many keeps every layer of its best group."""
    taken, out = set(), {}
    for role, kind, groups, exclude, many in ASBUILT_ROLES:
        pick = []
        for words in groups:
            cand = [(lid, n) for lid, name, k, n in layers
                    if lid not in taken and k == kind and _hits(name, words) and not _hits(name, exclude)]
            if not cand:
                continue
            if many:
                pick = [lid for lid, _n in cand]
            else:
                full = [lid for lid, n in cand if (n or 0) > 0]
                pick = [(full or [cand[0][0]])[0]]
            break
        out[role] = pick
        taken.update(pick)
    return out


# Universality: some towns keep every cable in ONE line layer with a type column (Mahikeng
# "Phase 1 Cables" Type = Feeder / Link / Distribution / Spur; Palm Ridge "Cables"). The as-built
# roles are then read from that column's values and each overview page draws only its own types.
_TYPE_FIELD_RE = re.compile(r"^(type|cable[ _]?type|cabletype|cable[ _]?use|category|class|kind|layer)$", re.I)
_TYPE_ROLE_WORDS = (("backhaul", ("backhaul", "back haul", "bh")),
                    ("feeder_link", ("feeder link", "link")),
                    ("feeder", ("feeder", "primary")),
                    ("spur", ("spur",)),
                    ("distribution", ("distribution", "dist", "dc", "secondary")))


_PER_PON_RE = re.compile(r"^\s*(pon|zone)\s*[-_ ]?\s*\d+\s*$", re.I)


def per_pon_layers(name, polygon_names):
    """The client-package shape (Barberton Rev1.0, Palm Ridge Preview): one polygon layer PER PON
    ('PON 001', 'PON 002', ...). Returns the sibling names when `name` is one of 2+ such layers
    (an As-Built book pages over ONE PON layer), else []."""
    if not _PER_PON_RE.match(str(name or "")):
        return []
    fam = [n for n in polygon_names or [] if _PER_PON_RE.match(str(n or ""))]
    return fam if len(fam) >= 2 else []


def cable_type_role(value):
    """'Feeder' / 'feeder_ph1' -> 'feeder'; 'Link' -> 'feeder_link'; 'DC' -> 'distribution';
    'Drop' / 'Spare' / blank -> None. Whole words only ('dc', 'bh' never match inside a word)."""
    if value is None:
        return None
    words = re.sub(r"[^a-z0-9]+", " ", str(value).lower()).split()
    if not words or any(w in ("drop", "drops", "spare") for w in words):
        return None
    text = " " + " ".join(words) + " "
    for role, keys in _TYPE_ROLE_WORDS:
        if any((" %s " % k) in text for k in keys):
            return role
    return None


def typed_cable_roles(field_names, values_by_field):
    """(type field, {role: [values]}) when one column of a line layer names 2+ cable roles,
    else None. values_by_field = {field: [distinct values]}; a column named Type beats 'layer'."""
    best = None
    for f in field_names or []:
        if not _TYPE_FIELD_RE.match(str(f).strip()):
            continue
        roles = {}
        for v in values_by_field.get(f) or []:
            r = cable_type_role(v)
            if r is not None:
                roles.setdefault(r, [])
                if str(v) not in roles[r]:
                    roles[r].append(str(v))
        if len(roles) >= 2 and (best is None or len(roles) > len(best[1])):
            best = (f, {k: sorted(v) for k, v in roles.items()})
    return best


def typed_page_values(title, typed_roles):
    """The type values an overview page draws from a typed cable layer: the backhaul page its
    backhaul values, a feeder page feeder + link values; None = no filter (every type)."""
    if is_backhaul_title(title):
        keys = ("backhaul",)
    elif "feeder" in str(title or "").lower():
        keys = ("feeder", "feeder_link")
    else:
        return None
    vals = []
    for k in keys:
        vals += list((typed_roles or {}).get(k) or [])
    return _uniq(vals) if vals else None


def typed_filter_expr(field, page_values):
    """Render-time filter for a typed cable layer on the book map. page_values = {overview seq:
    [values]}: on those overview pages only the listed types draw; every other page draws all."""
    whens = ["WHEN coalesce(attribute(@atlas_feature, 'seq'), -1) = %d THEN %s IN (%s)"
             % (int(seq), sql_ident(field), ", ".join(sql_str(v) for v in vals))
             for seq, vals in sorted(page_values.items()) if vals]
    if not whens:
        return None
    return ("coalesce(attribute(@atlas_feature, 'is_overview'), 0) = 0 OR "
            "coalesce(CASE %s ELSE true END, false)" % " ".join(whens))


def asbuilt_default_pages(roles, pon_id, aoi_id=""):
    """(overview pages, PON-page ids, PON-page labels) for an as-built book, or None when the
    project has none of the as-built line layers (the caller then uses the standard pages).

    Page 1 Backhaul overview (only with a backhaul layer), PON overview, Feeder overview (only
    with a FAP or feeder layer), then one page per PON. The PON layer is labelled on every page
    that shows it, like Lodewijk's sheets."""
    r = {k: list(v or []) for k, v in (roles or {}).items()}
    if not any(r.get(k) for k in ASBUILT_LINE_ROLES):
        return None
    pon = [pon_id] if pon_id else []
    outline = [aoi_id] if aoi_id else []       # the black phase outline: on every sheet, like Cradock's
    ov = []
    if r.get("backhaul"):
        # v2 (Cradock p1): the backhaul cable, its poles (only those on the route: bh_pole_filter_expr)
        # and the existing tie-in pole labelled, zones under it
        lab = _uniq(r["backhaul"] + r.get("existing_pole", []) + r.get("poles", []) + pon)
        ov.append(make_page("Backhaul Overview", lab + outline, lab))
    ov.append(make_page("PON Overview", pon + outline, pon))
    if r.get("fap") or r.get("feeder"):
        # v2 (Cradock p3): FAP splitter + ratio, the backhaul coming in, feeder and link cable names
        lab = _uniq(r.get("fap", []) + r.get("feeder", []) + r.get("feeder_link", []) + r.get("backhaul", []) + pon)
        ov.append(make_page("Feeder Overview", lab + outline, lab))
    ids = []
    for k in ("distribution", "spur", "feeder", "feeder_link", "backhaul", "existing_pole",
              "poles", "ctp", "fap"):
        ids += r.get(k, [])
    ids += pon + outline
    return ov, _uniq(ids), list(pon)


def bh_pole_filter_expr(seqs, lit, key_expr):
    """Render filter for a pole layer on the backhaul page(s) `seqs`: only the poles listed in `lit`
    (those on the backhaul route) draw there; every other page is unchanged."""
    return "(coalesce(attribute(@atlas_feature,'seq'),-1) NOT IN (%s) OR map_get(from_json(%s), %s) IS NOT NULL)" % (
        ", ".join(str(int(s)) for s in seqs), lit, key_expr)


def drop_unit_filter(values_by_field):
    """Which drops count as units when a project has no demand-point layer. values_by_field =
    {field name: [values]}. A type column holding SDU: the SDU drops only (Cradock: 1121 of 1138,
    the total on Lodewijk's sheets). Else everything but spares. '' = every drop."""
    for field, vals in (values_by_field or {}).items():
        if not _TYPE_FIELD_RE.match(str(field).strip()):
            continue
        texts = [str(v) for v in vals if v is not None]
        sdu = [v for v in texts if v.strip().upper() == "SDU"]
        if sdu:
            return "%s IN (%s)" % (sql_ident(field), ", ".join(sql_str(v) for v in _uniq(sdu)))
        spare = [v for v in texts if "spare" in v.lower()]
        if spare:
            return "coalesce(%s, '') NOT IN (%s)" % (sql_ident(field), ", ".join(sql_str(v) for v in _uniq(spare)))
    return ""


def asbuilt_drop_count_expr(layer_id, filt=""):
    """QGIS expression: how many drops of `layer_id` count as units."""
    extra = ", filter:=%s" % filt if filt else ""
    return "aggregate(layer:=%s, aggregate:='count', expression:=1%s)" % (sql_str(layer_id), extra)


def asbuilt_drop_in_page_expr(layer_id, filt="", transform=None):
    """QGIS expression: those drops on this page's PON. A drop belongs where its middle is: a drop
    runs from a pole to a house and can touch two zones, so 'intersects' would count it twice."""
    geom = "geometry(@parent)"
    if transform and transform[0] != transform[1]:
        geom = "transform(%s, %s, %s)" % (geom, sql_str(transform[0]), sql_str(transform[1]))
    inside = "contains(%s, centroid($geometry))" % geom
    return "aggregate(layer:=%s, aggregate:='count', expression:=1, filter:=%s)" % (
        sql_str(layer_id), "(%s) AND %s" % (filt, inside) if filt else inside)


def asbuilt_count_expr(layer_ids):
    """QGIS expression: total feature count over the given layers (by id), or None."""
    ids = [i for i in _uniq(layer_ids)]
    if not ids:
        return None
    return " + ".join("aggregate(layer:=%s, aggregate:='count', expression:=1)" % sql_str(i)
                      for i in ids)


def asbuilt_in_page_expr(layer_id, transform=None):
    """QGIS expression: features of `layer_id` inside the page's own polygon. `transform` =
    (from authid, to authid) when the page layer and the counted layer differ in CRS.
    @parent is the atlas page feature, so each page counts its own PON."""
    if not layer_id:
        return None
    geom = "geometry(@parent)"
    if transform and transform[0] != transform[1]:
        geom = "transform(%s, %s, %s)" % (geom, sql_str(transform[0]), sql_str(transform[1]))
    return ("aggregate(layer:=%s, aggregate:='count', expression:=1, filter:=intersects($geometry, %s))"
            % (sql_str(layer_id), geom))


_OVERVIEW = "coalesce(attribute(@atlas_feature,'is_overview'),0) = 1"


def _with_word(word, value):
    """'Phase' + '1' -> 'Phase 1'; 'Phase' + 'Phase 1' -> 'Phase 1'."""
    v = str(value or "").strip()
    return v if v.lower().startswith(word.lower()) else ("%s %s" % (word, v)).strip()


def asbuilt_facts_rows(details, counts):
    """The 5 x 3 facts table as cell specs (the engine's _nt_cell format), in Lodewijk's order.

    details: typed values {province, area, phase, date, drawn_by, split_ratio} - plain text
    cells the operator edits in the designer. counts: {units, units_in_pon, poles, fap, ctp,
    pons} - QGIS expressions (None = layer not found: the cell stays as editable text)."""
    d = details or {}
    c = counts or {}

    def count(label, key):
        e = c.get(key)
        return {"expr": "concat(%s, %s)" % (sql_str(label), e)} if e else {"text": label}

    pon_cell = {"expr": "if(%s, 'PON', attribute(@atlas_feature,'page_title'))" % _OVERVIEW}
    if c.get("units_in_pon"):
        units_cell = {"expr": "if(%s, 'Units', concat('Units in PON: ', %s))" % (_OVERVIEW, c["units_in_pon"])}
    else:
        units_cell = {"text": "Units in PON: "}
    return [
        [{"text": "Province: %s" % (d.get("province") or "")}, {"text": "Area: %s" % (d.get("area") or "")}, pon_cell],
        [{"text": _with_word("Phase", d.get("phase"))}, count("Total PONS ", "pons"), units_cell],
        [count("Unit Count: ", "units"), count("Poles: ", "poles"), {"text": _with_word("Date", d.get("date"))}],
        [count("FAP: ", "fap"), count("CTP: ", "ctp"), {"text": "Drawn by %s" % (d.get("drawn_by") or "")}],
        [{"text": "Splitting Ratio %s" % (d.get("split_ratio") or "")}, {"text": ""}, {"text": ""}],
    ]


def asbuilt_default_details(title="", phase=None, today=""):
    """Typed details before the operator changes them. Splitting ratio = the HeroTel cascade
    measured on every delivered town (1:16 feeder then 1:8)."""
    return {"province": "", "area": str(title or ""), "phase": "" if phase is None else str(phase),
            "date": str(today or ""), "drawn_by": "", "split_ratio": "1:16-1:8"}


def format_latlon(lat, lon, dp=7):
    """'32.1739121 S, 25.6233960 E' - hemisphere letters from the signs (never a minus sign
    AND a letter, which is how Lodewijk's sheet came to read '-32.17N, 25.62S')."""
    lat, lon = float(lat), float(lon)
    if not (-90.0 <= lat <= 90.0 and -180.0 <= lon <= 180.0):
        raise ValueError("not a latitude/longitude: %r, %r" % (lat, lon))
    return "%.*f %s, %.*f %s" % (dp, abs(lat), "S" if lat < 0 else "N", dp, abs(lon), "W" if lon < 0 else "E")


# ── As-Built v2 (JJ 2026-10-30, decision asbuilt-fixes-cradock-gaps): backhaul page with the
# tie-in pole, overview pages framed on the phase, FAP / cable labels, the Velocity logo. Fixed
# As-Built books only (spec["asbuilt_fix"]); A3 and unfixed books never reach this code. ────
TIEIN_LABEL = "Existing HT Pole - Breakpoint"
TIEIN_LEGEND = "Existing Herotel Pole"
TIEIN_SNAP_M = 15.0            # a pole within 15 m of the backhaul's free end is the tie-in pole
END_JOIN_M = 1.0               # two cable ends closer than this are one joint, not a free end
_BH_WORDS = ("backhaul", "back haul", "bachaul", "bakhaul")
_BH_WORD_RE = re.compile(r"(?i)(?:^|[^a-z0-9])bh(?:[^a-z0-9]|$)")
_PHASE_RE = re.compile(r"(?i)\bphase[\s_\-]*(\d+[a-z]?)\b")
_POLE_NO_NAMES = ("pole_no", "poleno", "pole no", "pole number", "pole_number", "pole_num")
_SPLIT_NAMES = ("splitter", "splitter_type", "splitter type", "splittertype", "splitter_ratio",
                "split_ratio", "split ratio", "ratio")
_NAME_FIELDS = ("LABEL", "Label", "label", "NAME", "Name", "name")
_CABLE_FIELDS = ("NAME", "Name", "name", "LABEL", "Label", "label", "CABLE_NO", "Cable_No", "cable_no")


def is_backhaul_title(title):
    """'Backhaul Overview', 'Bachaul Overview' (Botshabelo's typo), 'Back haul' -> True."""
    t = re.sub(r"[_\-]+", " ", str(title or "").lower())
    return any(w in t for w in _BH_WORDS)


def is_backhaul_name(name):
    """A line layer that IS the backhaul by name: 'BACKHAUL', 'BH POP Route', 'bh_route'."""
    return is_backhaul_title(name) or bool(_BH_WORD_RE.search(str(name or "")))


def backhaul_page_index(pages, backhaul_ids=()):
    """Index of the backhaul overview page: the first page drawing a backhaul-role layer, else the
    first page whose title reads as a backhaul page, else None. pages = [(title, ids)]."""
    bh = set(backhaul_ids or ())
    for i, (_t, ids) in enumerate(pages):
        if bh & set(ids or ()):
            return i
    for i, (t, _ids) in enumerate(pages):
        if is_backhaul_title(t):
            return i
    return None


def pick_backhaul_layer(page_layers, backhaul_ids=()):
    """The backhaul cable on the backhaul page. page_layers = [(id, name, kind)] in page order.
    A backhaul-role layer wins, then a line layer named as a backhaul ('BH POP Route'), else None
    (a feeder drawn on the page is never taken for the backhaul)."""
    bh = list(backhaul_ids or ())
    lines = [(i, n) for i, n, k in page_layers if k == "line"]
    for i, _n in lines:
        if i in bh:
            return i
    for i, n in lines:
        if is_backhaul_name(n):
            return i
    return None


def free_ends(parts, tol=END_JOIN_M):
    """End points of the backhaul's line parts that do not meet another part's end (within tol,
    metric). parts = [((x, y), (x, y))]. A chained cable (trench + aerial) has two free ends."""
    pts = [pt for ab in parts for pt in ab]
    out = []
    for i, a in enumerate(pts):
        if not any(j != i and math.hypot(a[0] - b[0], a[1] - b[1]) <= tol for j, b in enumerate(pts)):
            out.append(a)
    return out


def tiein_pick(d_feeder, d_zone=None):
    """Index of the tie-in end among the backhaul's free ends: the end FARTHEST from the feeder
    network (the other end is the POP, where every feeder starts). With no feeder distance known,
    the end farthest from the PON zones. d_feeder / d_zone = [distance m | None] per end."""
    for d in (d_feeder, d_zone):
        vals = [(float(x), i) for i, x in enumerate(d or []) if x is not None]
        if len(vals) >= 2 and max(vals)[0] > min(vals)[0]:
            return max(vals)[1]
    return None


def snap_pick(cands, tol=TIEIN_SNAP_M):
    """cands = [(priority, distance m, key)] -> key of the best pole within tol (lowest priority
    first, then nearest), or None (the tie-in is then the cable end itself)."""
    ok = sorted((int(p), float(d), str(k)) for p, d, k in cands if d is not None and float(d) <= tol)
    return ok[0][2] if ok else None


def _fold(s):
    return re.sub(r"[\s_\-.:#]+", " ", str(s or "").strip().lower()).strip()


def short_pole_field(field_names):
    """The short pole-number field ('Pole_No', 'POLE_NO' -> '3111PL'), or None."""
    want = {_fold(x) for x in _POLE_NO_NAMES}
    for f in field_names or ():
        if _fold(f) in want:
            return f
    return None


def short_pole_expr(field_names, label_text, is_expr=False):
    """Label expression for a pole on the backhaul page: the short number ('1764PL', not
    'HT_BOTS_3143PL'). The pole-number field when there is one, else the current label with
    everything up to the last '_' removed."""
    f = short_pole_field(field_names)
    if f:
        return sql_ident(f)
    src = label_text if is_expr else sql_ident(label_text)
    return "regexp_replace(to_string(%s), '^.*_', '')" % src


def short_pole_line_expr(field_names, label_text, is_expr=False):
    """PON pages of a universality book: the short pole number only ('2001PL'), never the HLD's
    three-line pole label ('2001PL / Pole lengt: 7m / Pole Size: ...', Lulekani) - the pole-number
    field when there is one, else the FIRST line of the current label with everything up to the
    last '_' removed."""
    f = short_pole_field(field_names)
    if f:
        return sql_ident(f)
    src = label_text if is_expr else sql_ident(label_text)
    return "regexp_replace(regexp_replace(to_string(%s), '(?s)\\n.*$', ''), '^.*_', '')" % src


def splitter_label_expr(field_names, layer_name="", current=""):
    """FAP label = splitter name + ratio on two lines ('HT_CDKP2_0218DJ_SP08/09' / '2 X 1:16').
    None when the current label already shows the ratio field, or there is no name field. A
    16-way layer without a ratio field gets '1:16' written out."""
    names = list(field_names or ())
    want = {_fold(x) for x in _SPLIT_NAMES}
    ratio = next((f for f in names if _fold(f) in want), None)
    cur = str(current or "").lower()
    if ratio and ratio.lower() in cur:
        return None
    name = next((f for f in _NAME_FIELDS if f in names), None)
    if name is None:
        return None
    if ratio:
        # splitters sharing one joint (Cradock 0218DJ SP08/09: two rows, one place) read
        # '2 X 1:16' like Lodewijk's sheet; splitter_show_expr leaves one label per joint
        n = "count(expression:=1, group_by:=%s)" % splitter_group_key(name)
        return "%s || '\\n' || if(%s > 1, to_string(%s) || ' X ', '') || %s" % (
            sql_ident(name), n, n, sql_ident(ratio))
    low, tight = _role_name(layer_name)
    if any(w in low or w.replace(" ", "") in tight for w in ("16way", "16 way", "1:16", "1x16")):
        return "%s || '\\n1:16'" % sql_ident(name)
    return None


def splitter_group_key(name_field):
    """Expression naming one joint: its place and the splitter name."""
    return "geom_to_wkt($geometry, 6) || '|' || to_string(%s)" % sql_ident(name_field)


def splitter_show_expr(name_field):
    """Data-defined Show: the first splitter of a joint only (one label per joint)."""
    return "$id = minimum(expression:=$id, group_by:=%s)" % splitter_group_key(name_field)


def splitter_name_field(field_names):
    names = list(field_names or ())
    return next((f for f in _NAME_FIELDS if f in names), None)


def cable_name_field(field_names):
    """The cable-name field for a feeder / link / backhaul label, or None."""
    names = list(field_names or ())
    return next((f for f in _CABLE_FIELDS if f in names), None)


def cable_field_ok(field, field_names):
    """A cable label field worth keeping: it exists and is not an id column ('id', 'fid'...)."""
    return bool(field) and field in (field_names or ()) and not _PK_RE.match(str(field))


_STRIP_HEAD = "if(left(to_string("


def common_code_prefix(texts, min_texts=2):
    """The project-code prefix every label of a layer repeats ('HT_MFKGP4_' in 'HT_MFKGP4_DC01_12F_Aerial',
    'HT_PABA1_Z1_' in 'HT_PABA1_Z1_0059DJ_1SP'): the longest prefix shared by ALL non-empty texts, cut
    back to its last '_', holding a letter, and leaving something after it on every text. '' when
    there is none (fewer than min_texts labels, or the texts do not share one). Order-independent."""
    vals = [str(t) for t in texts or () if t is not None and str(t).strip() and str(t) != "NULL"]
    if len(vals) < max(int(min_texts), 1):
        return ""
    lo, hi = min(vals), max(vals)              # the LCP of a set = the LCP of its min and max
    n = 0
    while n < min(len(lo), len(hi)) and lo[n] == hi[n]:
        n += 1
    pre = lo[:n]
    cut = pre.rfind("_")
    if cut < 0:
        return ""
    pre = pre[:cut + 1]
    if len(pre) < 3 or not re.search(r"[A-Za-z]", pre) or "\n" in pre:
        return ""
    if any(len(v) <= len(pre) or not v[len(pre):].strip() for v in vals):
        return ""
    return pre


def strip_prefix_expr(text_expr, prefix):
    """Label expression showing `text_expr` without `prefix` when it starts with it (else unchanged)."""
    if not prefix:
        return text_expr
    n = len(prefix)
    return "%s%s), %d) = %s, substr(to_string(%s), %d), to_string(%s))" % (
        _STRIP_HEAD, text_expr, n, sql_str(prefix), text_expr, n + 1, text_expr)


_SHORT_HEAD = "if(coalesce(attribute(@atlas_feature,'seq'),-1) IN ("
_SHORT_RE = re.compile(r"if\(coalesce\(attribute\(@atlas_feature,'seq'\),-1\) IN \([-\d, ]*\) AND left\(")


def page_strip_expr(text_expr, prefix, seqs=()):
    """Label expression: the full name everywhere, without `prefix` only on the pages `seqs` (JJ
    2026-11-05: full names like Lodewijk's sheets; only a page that would otherwise lose a label
    goes short)."""
    if not prefix:
        return text_expr
    n = len(prefix)
    pages = ", ".join(str(int(s)) for s in sorted(seqs)) or "-1"
    return "%s%s) AND left(to_string(%s), %d) = %s, substr(to_string(%s), %d), to_string(%s))" % (
        _SHORT_HEAD, pages, text_expr, n, sql_str(prefix), text_expr, n + 1, text_expr)


def has_short_pages(expr):
    return bool(_SHORT_RE.search(str(expr or "")))


def set_short_pages(expr, seqs):
    """`expr` with its short-name page list replaced; any other part of the text stays exactly."""
    pages = ", ".join(str(int(s)) for s in sorted(seqs)) or "-1"
    head = "%s%s) AND left(" % (_SHORT_HEAD, pages)
    return _SHORT_RE.sub(lambda _m: head, str(expr))


def is_strip_expr(text_expr):
    return str(text_expr or "").startswith(_STRIP_HEAD)


def phase_text(spec_phase=None, layer_name="", values=(), typed=""):
    """'Phase 1' for the overview label: the book's phase, else a 'Phase N' in the outline layer's
    name ('Phase 1'), else in one of its attribute values, else the typed As-Built phase."""
    if spec_phase is not None and str(spec_phase).strip():
        return _with_word("Phase", spec_phase)
    for s in [layer_name] + [str(v) for v in values or () if v is not None]:
        m = _PHASE_RE.search(str(s or ""))
        if m:
            return "Phase %s" % m.group(1)
    t = str(typed or "").strip()
    return _with_word("Phase", t) if t else None


def outline_rank(name):
    """Phase-outline candidates, best first: 'phase' in the name, then AOI / boundary words.
    None = not an outline layer."""
    low, _t = _role_name(name)
    if "phase" in low:
        return 0
    if any(w in low.split() for w in ("aoi", "aol", "boundary", "extent")) or "area of interest" in low:
        return 1
    return None


def frame_ok(outline_box, zones_box, max_ratio=25.0):
    """The phase outline frames the overview only when it overlaps the named zones and is not
    vastly bigger than them (a whole-town AOI on a phase book). Boxes = (xmin, ymin, xmax, ymax)."""
    if not outline_box:
        return False
    if not zones_box:
        return True
    ox0, oy0, ox1, oy1 = outline_box
    zx0, zy0, zx1, zy1 = zones_box
    if ox1 < zx0 or zx1 < ox0 or oy1 < zy0 or zy1 < oy0:
        return False
    oa = max(ox1 - ox0, 0.0) * max(oy1 - oy0, 0.0)
    za = max(zx1 - zx0, 1e-12) * max(zy1 - zy0, 1e-12)
    return oa <= max_ratio * za


POLE_PT = 4.5                  # short pole labels on the backhaul page (Botshabelo p1: 39 poles in 115 mm)
POLE_BUF_MM = 0.3
CABLE_PT = 5.5                 # cable names on overview pages (Cradock p3: LC01 fits between two FAP labels at any dpi)
BH_PON_PT = 4.5                # zone labels on the backhaul page, where the zones are drawn small
FAP_OBSTACLE = False          # measured: FAP symbol obstacles cleared Feeder Overview (1 -> 0) but put PON 014 up 35 -> 36 symbol hits
LADDER_STAGGER_MM = 6.0        # every other pole's label one ring further out (3.38 placed 54/56 without it)
LADDER_MAX = 2000              # more poles than this on one page: no ladder (main-thread compute bound)
_PAGE_SIZE_RE = re.compile(r"^if\(coalesce\(attribute\(@atlas_feature,'seq'\),-1\) = -?\d+, [0-9.]+, (.*)\)$", re.S)


def page_size_expr(page_seq, size_on_page, current):
    """Data-defined label size: `size_on_page` on page `page_seq`, `current` (a number or an
    expression) elsewhere. Idempotent like page_text_expr."""
    cur = str(current)
    m = _PAGE_SIZE_RE.match(cur)
    inner = m.group(1) if m else cur
    out = "if(coalesce(attribute(@atlas_feature,'seq'),-1) = %d, %g, %s)" % (int(page_seq), float(size_on_page), inner)
    return None if out == cur else out


def live_label_show_expr(ticked_overview, ticked_pon):
    """Show for a LIVE layer's labels on the book map when its book copy labels it on some pages
    only: the live labels stay on the pages that do not tick it (as before), and step aside on
    the pages where the copy draws them (no doubled label). None when every page ticks it."""
    ov = sorted({int(i) for i in ticked_overview or ()})
    parts = []
    if ov:
        parts.append("(coalesce(attribute(@atlas_feature,'is_overview'),0) = 1 AND "
                     "coalesce(attribute(@atlas_feature,'seq'),-1) IN (%s))" % ", ".join(str(i) for i in ov))
    if ticked_pon:
        parts.append("coalesce(attribute(@atlas_feature,'is_overview'),0) = 0")
    if not parts:
        return None
    return "NOT (%s)" % " OR ".join(parts)


def ladder_base_dist(dist, current_expr=""):
    """The inner-ring label distance for the ladder stagger: the copy's own static distance; None
    when someone else's data-defined distance is set (left alone). Our own stagger is rewritten."""
    cur = str(current_expr or "")
    if cur and not cur.startswith("if(coalesce(to_int(array_get(map_get(from_json("):
        return None
    return float(dist)


def ladder_layout(pts):
    """Dense poles along a route, labelled like a ladder (Cradock p1): each label perpendicular
    to the local pole line, read left to right. pts = [(x, y)] in map units (screen axes).
    Returns [(rotation degrees clockwise, stagger 0|1)] per point; the line direction at a pole
    comes from its two nearest neighbours, and every other pole along the chain gets stagger 1."""
    n = len(pts)
    if n == 0:
        return []
    if n == 1:
        return [(0.0, 0)]
    rot = []
    for i, (x, y) in enumerate(pts):
        near = sorted((math.hypot(px - x, py - y), j) for j, (px, py) in enumerate(pts) if j != i)[:2]
        if len(near) == 1:
            a, b = pts[i], pts[near[0][1]]
        else:
            a, b = pts[near[0][1]], pts[near[1][1]]
        dx, dy = b[0] - a[0], b[1] - a[1]
        if dx == 0 and dy == 0:
            rot.append(0.0)
            continue
        cw = round(-(math.degrees(math.atan2(dy, dx)) + 90.0), 1)     # rounded first: -89.97 is 90.0
        while cw <= -90.0:
            cw += 180.0
        while cw > 90.0:
            cw -= 180.0
        rot.append(cw)
    cx = sum(x for x, _y in pts) / n
    cy = sum(y for _x, y in pts) / n
    start = max(range(n), key=lambda i: (math.hypot(pts[i][0] - cx, pts[i][1] - cy), -i))
    order, seen = [start], {start}
    while len(order) < n:
        lx, ly = pts[order[-1]]
        nxt = min((j for j in range(n) if j not in seen), key=lambda j: (math.hypot(pts[j][0] - lx, pts[j][1] - ly), j))
        order.append(nxt)
        seen.add(nxt)
    stag = [0] * n
    for k, i in enumerate(order):
        stag[i] = k % 2
    return [(rot[i], stag[i]) for i in range(n)]
_PAGE_TEXT_RE = re.compile(r"^if\(coalesce\(attribute\(@atlas_feature,'seq'\),-1\) = -?\d+, \"(?:[^\"]|\"\")*\", (.*)\)$",
                           re.S)


def page_text_expr(page_seq, short_field, current):
    """Label text = the short page name ('PON 001') on page `page_seq` and the current text on
    every other page. Idempotent; a wrap written for another page number is replaced, never
    nested. None when nothing would change."""
    cur = str(current or "")
    m = _PAGE_TEXT_RE.match(cur)
    inner = m.group(1) if m else cur
    if not inner:
        return None
    out = "if(coalesce(attribute(@atlas_feature,'seq'),-1) = %d, %s, %s)" % (int(page_seq), sql_ident(short_field), inner)
    return None if out == cur else out


def photo_field(field_names):
    """The pole photo field for the tie-in photo inset: an 'after' / whole-pole photo first, then
    any photo / picture / image field (never the permission slip). None when there is none."""
    low = [(f, str(f).lower()) for f in field_names or ()]
    for f, lo in low:
        if "photo" in lo and ("after" in lo or "entire pole" in lo):
            return f
    for f, lo in low:
        if any(w in lo for w in ("photo", "picture", "image", "foto")) and "permission" not in lo:
            return f
    return None


# ── round 2 (2026-10-30): every label shows on any project ──────────────────────────────────
# Book label copies of universality books only. Each wrap below has a fixed, anchored shape so a
# Rebuild (which seeds the new copy from the old copy's labelling) unwraps it before re-applying:
# never nested, never stacked.
_ISO_KEY_RE = r"geom_to_wkt\(centroid\(\$geometry\), \d+\) \|\| '/' \|\| to_string\(num_points\(\$geometry\)\)"
_LIT_RE = r"'(?:[^']|'')*'"
_DUP_TEXT_RE = re.compile(r"^coalesce\(array_get\(map_get\(from_json\(%s\), %s\), 0\), (.*)\)$"
                          % (_LIT_RE, _ISO_KEY_RE), re.S)
_FIT_RE = re.compile(r"^max\(min\((.*), ([0-9.]+)\), \((.*)\) \* coalesce\(to_real\(map_get\(from_json\(%s\), "
                     r"to_string\(coalesce\(attribute\(@atlas_feature,'seq'\),-1\)\)\)\), 1\)\)$" % _LIT_RE, re.S)
FIT_STEPS = (0.85, 0.72, 0.6, 0.5, 0.42)   # a page that drops a label: every book label on it shrinks by these, in turn
FIT_FLOOR_PT = 4.0              # ... never below 4 pt (a label already smaller keeps its size)
FIT_FLOOR_MM = 1.4
CABLE_STUB_MM = 25.0            # less of a cable than this on the sheet cannot hold its name: it is named on its own page
DUP_MAX = 100000                # coincident-point groups are found for layers up to this size


def json_lit(obj):
    """A QGIS string literal holding JSON (for from_json)."""
    import json as _json
    return "'" + _json.dumps(obj, sort_keys=True, separators=(",", ":")).replace("\\", "\\\\").replace("'", "''") + "'"


def dup_groups(items):
    """items: [(location key, label text)] -> {key: [combined text, the text that shows it]} for the
    locations holding two or more labelled features (two poles drawn on one spot: Lulekani 3200PL +
    3201PL). One label per location lists every distinct text, sorted (' / ' between one-line texts,
    a new line otherwise); the feature whose text is first carries it. Order-independent."""
    by = {}
    for k, t in items or ():
        if k is None or t is None:
            continue
        t = str(t)
        if not t.strip() or t == "NULL":
            continue
        by.setdefault(str(k), []).append(t)
    out = {}
    for k, ts in by.items():
        if len(ts) < 2:
            continue
        u = sorted(set(ts))
        if len(u) < 2:
            continue
        sep = "\n" if any("\n" in t for t in u) else " / "
        out[k] = [sep.join(u), u[0]]
    return out


def dup_text_expr(lit, key_expr, text_expr):
    return "coalesce(array_get(map_get(from_json(%s), %s), 0), %s)" % (lit, key_expr, text_expr)


def dup_show_expr(lit, key_expr, text_expr):
    return ("coalesce(to_string(array_get(map_get(from_json(%s), %s), 1)) = to_string(%s), true)"
            % (lit, key_expr, text_expr))


def unwrap_dup_text(expr):
    """(inner text expression, True) when `expr` is a dup_text_expr wrap, else (expr, False)."""
    m = _DUP_TEXT_RE.match(str(expr or ""))
    return (m.group(1), True) if m else (expr, False)


def remove_dup_show(show, text_expr):
    """`show` without any dup_show_expr(…, text_expr) part (None when nothing is left)."""
    s = str(show or "")
    pat = re.compile(r"coalesce\(to_string\(array_get\(map_get\(from_json\(%s\), %s\), 1\)\) = to_string\(%s\), true\)"
                     % (_LIT_RE, _ISO_KEY_RE, re.escape(str(text_expr))), re.S)
    m = pat.search(s)
    while m:
        d = m.group(0)
        if s == d:
            return None
        if s.startswith("(%s) AND " % d):
            s = s[len("(%s) AND " % d):]
        else:
            s = s.replace(" AND (%s)" % d, "", 1) if (" AND (%s)" % d) in s else s.replace(d, "true", 1)
        m = pat.search(s)
    return s or None


def fit_size_expr(base, floor, factors):
    """Label size = base x the page's factor (factors: {page seq: factor}), never below `floor`
    (a base already under the floor keeps its size). None when no page shrinks."""
    f = {str(int(k)): round(float(v), 4) for k, v in (factors or {}).items() if float(v) < 1.0}
    if not f:
        return None
    return ("max(min(%s, %g), (%s) * coalesce(to_real(map_get(from_json(%s), "
            "to_string(coalesce(attribute(@atlas_feature,'seq'),-1)))), 1))" % (base, float(floor), base, json_lit(f)))


def unwrap_fit_size(expr):
    """(base expression, True) when `expr` is a fit_size_expr wrap, else (expr, False)."""
    m = _FIT_RE.match(str(expr or ""))
    if m and m.group(1) == m.group(3):
        return m.group(1), True
    return expr, False


_GAP_RE = re.compile(r"^max\(coalesce\((.*), (-?[0-9.]+)\), coalesce\(to_real\(map_get\(from_json\(%s\), %s\)\), 0\)\)$"
                     % (_LIT_RE, _ISO_KEY_RE), re.S)
OVERVIEW_ONLY_FILTER = "coalesce(attribute(@atlas_feature,'is_overview'),0) = 1"
COINCIDE_M = 1.0                # a point within 1 m of another layer's point shares its symbol on the page


def gap_dist_expr(lit, key_expr, current, base):
    """Label distance = the copy's own distance (`current`: its data-defined expression, or the
    number; `base` when that is NULL), never less than the per-point value in `lit` (a point
    sharing its spot with another layer's symbol)."""
    return "max(coalesce(%s, %g), coalesce(to_real(map_get(from_json(%s), %s)), 0))" % (
        current, float(base), lit, key_expr)


def unwrap_gap_dist(expr):
    """(the copy's own distance expression, True) for a gap_dist_expr wrap, else (expr, False)."""
    m = _GAP_RE.match(str(expr or ""))
    return (m.group(1), True) if m else (expr, False)


# ── detail pages (round 2): an overview page still too crowded at the smallest label size ─────
DETAIL_ZOOM = 3.0               # a detail page shows 1/3 of its overview's width (3x the scale)
DETAIL_MAX = 6                  # never more than this many detail pages per overview page
DETAIL_ROUNDS = 2               # a detail page still too crowded gets its own closer view (once)
_HIDE_RE = re.compile(r"\(coalesce\(attribute\(@atlas_feature,'seq'\),-1\) <> \d+ OR map_get\(from_json\(%s\), %s\) "
                      r"IS NULL\)" % (_LIT_RE, _ISO_KEY_RE), re.S)


def detail_frames(points, main_box, zoom=DETAIL_ZOOM, max_frames=DETAIL_MAX):
    """Frames (x0, y0, x1, y1) for detail pages: each the overview frame's shape at 1/zoom of its
    size, together covering every point (the features whose labels found no room). Points that sit
    within one frame share it; more than max_frames clusters -> the frames grow (zoom / 1.5) until
    they fit. Deterministic and order-independent (points are sorted)."""
    pts = sorted({(float(x), float(y)) for x, y in points or ()})
    if not pts:
        return []
    x0, y0, x1, y1 = [float(v) for v in main_box]
    W0, H0 = max(x1 - x0, 1e-12), max(y1 - y0, 1e-12)
    z = float(zoom)
    while True:
        W, H = W0 / z, H0 / z
        clusters = []
        for x, y in pts:
            for c in clusters:
                nx0, ny0, nx1, ny1 = min(c[0], x), min(c[1], y), max(c[2], x), max(c[3], y)
                if nx1 - nx0 <= 0.8 * W and ny1 - ny0 <= 0.8 * H:
                    c[:] = [nx0, ny0, nx1, ny1]
                    break
            else:
                clusters.append([x, y, x, y])
        if len(clusters) <= max_frames or z <= 1.0:
            break
        z = max(1.0, z / 1.5)
    out = []
    for c in clusters:
        cx, cy = (c[0] + c[2]) / 2.0, (c[1] + c[3]) / 2.0
        out.append((cx - W / 2.0, cy - H / 2.0, cx + W / 2.0, cy + H / 2.0))
    return out


def detail_title(main_title, k, n):
    if " - detail" in str(main_title):        # a detail page's own closer view
        return "%s - closer %d of %d" % (main_title, k, n) if n > 1 else "%s - closer" % main_title
    return "%s - detail %d of %d" % (main_title, k, n) if n > 1 else "%s - detail" % main_title


def detail_hide_expr(main_seq, lit, key_expr):
    """Show part: on overview page `main_seq` the features listed in `lit` are labelled on its
    detail page instead (they found no room on the overview); everywhere else unchanged."""
    return "(coalesce(attribute(@atlas_feature,'seq'),-1) <> %d OR map_get(from_json(%s), %s) IS NULL)" % (
        int(main_seq), lit, key_expr)


def remove_show_parts(show, pattern):
    """`show` without every part matching `pattern` (as _with_show AND-ed it in); None when empty."""
    s = str(show or "")
    m = pattern.search(s)
    while m:
        d = m.group(0)
        if s == d or s == "(%s)" % d:
            return None
        if s.startswith("(%s) AND " % d):
            s = s[len("(%s) AND " % d):]
        elif (" AND (%s)" % d) in s:
            s = s.replace(" AND (%s)" % d, "", 1)
        else:
            s = s.replace(d, "true", 1)
        m = pattern.search(s)
    return s or None


def remove_detail_hide(show):
    return remove_show_parts(show, _HIDE_RE)
