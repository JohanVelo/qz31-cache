"""backend — the ONE place that talks to Supabase (PostgREST).

QgsNetworkAccessManager + QNetworkRequest + JSON. No pip libraries. Every
write is fire-and-forget and NEVER blocks the UI. In dry-run mode (default
until the backend is configured) nothing is POSTed — records go to the spool.

Insert / heartbeat-upsert use the shipped ANON key. The admin SELECTs (Team
Monitor) use the owner read-key, passed in explicitly and never shipped.
"""
import json
import uuid

from . import config, spool


def _plugin_version():
    try:
        import os
        import re
        here = os.path.dirname(os.path.abspath(__file__))
        mp = os.path.normpath(os.path.join(here, "..", "..", "metadata.txt"))
        m = re.search(r"^version=(\S+)", open(mp, encoding="utf-8").read(),
                      flags=re.M)
        return m.group(1) if m else "?"
    except Exception:
        return "?"


class Backend:
    """One instance, dependency-injected so dry-run is trivial.

    data_dir   : portable scratch dir (vf_paths.data_dir())
    dry_run    : when True, writes go to the spool only (no network)
    """

    def __init__(self, data_dir, dry_run=None):
        self.data_dir = data_dir
        if dry_run is None:
            dry_run = config.DRY_RUN_DEFAULT or not config.is_backend_configured()
        self.dry_run = dry_run
        self.version = _plugin_version()
        self._ua = f"VelocityNexus/{self.version} (QGIS)".encode()

    # ── writes (anon key, insert/upsert) ────────────────────────────────────
    def insert(self, table, payload, upsert_on=None):
        """Queue+send one insert (or upsert when upsert_on given). Returns the
        idempotency key. Never raises, never blocks."""
        idem = str(uuid.uuid4())
        payload = dict(payload)
        payload.setdefault("idempotency_key", idem) if table in (
            "events", "errors") else None
        prefer = "return=minimal"
        if upsert_on:
            prefer = "resolution=merge-duplicates,return=minimal"
        # always spool first (crash-safe); flush() will clear it on success
        spool.append(self.data_dir, table, payload, idem, prefer)
        spool.enforce_cap(self.data_dir, config.SPOOL_MAX_BYTES)
        if not self.dry_run:
            self._post(table, payload, prefer, upsert_on)
        return idem

    # ── flush the spool (called on a timer + on reconnect) ──────────────────
    def flush(self):
        if self.dry_run or not config.is_backend_configured():
            return
        records = spool.read_all(self.data_dir)
        if not records:
            return
        # Best-effort: fire each; on success the record is dropped by the
        # reply handler rewriting the spool. To keep it simple+safe we re-post
        # all and clear; idempotency_key dedupes server-side.
        remaining = []
        for r in records:
            ok = self._post(r["table"], r["payload"], r.get("prefer"),
                            on_conflict=r.get("upsert_on"))
            if not ok:
                remaining.append(r)
        spool.rewrite(self.data_dir, remaining)

    # ── low-level POST (async, fire-and-forget) ─────────────────────────────
    def _post(self, table, payload, prefer=None, on_conflict=None):
        try:
            from qgis.core import QgsNetworkAccessManager
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtNetwork import QNetworkRequest
        except Exception:
            return False
        url = f"{config.SUPABASE_URL}/rest/v1/{table}"
        if on_conflict:
            url += f"?on_conflict={on_conflict}"
        req = QNetworkRequest(QUrl(url))
        req.setHeader(QNetworkRequest.ContentTypeHeader, "application/json")
        req.setRawHeader(b"apikey", config.SUPABASE_ANON_KEY.encode())
        req.setRawHeader(b"Authorization",
                         f"Bearer {config.SUPABASE_ANON_KEY}".encode())
        req.setRawHeader(b"User-Agent", self._ua)
        if prefer:
            req.setRawHeader(b"Prefer", prefer.encode())
        body = json.dumps(payload).encode("utf-8")
        try:
            nam = QgsNetworkAccessManager.instance()
            try:
                nam.setAutoDeleteReplies(True)   # Qt 5.14+: clean reply lifecycle
            except Exception:
                pass
            reply = nam.post(req, body)
            reply.finished.connect(lambda r=reply: self._safe_delete(r))
            return True
        except Exception:
            return False        # network stack unavailable — keep in spool

    @staticmethod
    def _safe_delete(reply):
        try:
            reply.deleteLater()
        except Exception:
            pass

    # ── admin reads (owner read-key; never shipped) ─────────────────────────
    def admin_get(self, query, admin_key, callback):
        """GET .../rest/v1/<query> with the owner key; callback(list|None).
        Used only by the Team Monitor on JJ's machine."""
        try:
            from qgis.core import QgsNetworkAccessManager
            from qgis.PyQt.QtCore import QUrl
            from qgis.PyQt.QtNetwork import QNetworkRequest
        except Exception:
            callback(None)
            return
        req = QNetworkRequest(QUrl(f"{config.SUPABASE_URL}/rest/v1/{query}"))
        req.setRawHeader(b"apikey", admin_key.encode())
        req.setRawHeader(b"Authorization", f"Bearer {admin_key}".encode())
        req.setRawHeader(b"User-Agent", self._ua)
        try:
            reply = QgsNetworkAccessManager.instance().get(req)

            def _done(r=reply):
                try:
                    if int(r.error()) != 0:
                        callback(None)
                    else:
                        callback(json.loads(
                            bytes(r.readAll()).decode("utf-8", "replace")))
                except Exception:
                    callback(None)
                finally:
                    self._safe_delete(r)

            reply.finished.connect(_done)
        except Exception:
            callback(None)
