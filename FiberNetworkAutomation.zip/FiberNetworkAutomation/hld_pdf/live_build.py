# -*- coding: utf-8 -*-
# Build the HLD map-book layouts INSIDE the live QGIS project so JJ can tweak them
# by hand in the Print Layout designer and export the PDF himself (his usual way of
# getting a nice PDF). This is the interactive counterpart to the headless one-shot
# generator (hld_generate.py) — same engine, same config, but run on the GUI thread
# against QgsProject.instance() and then the designer is opened.
#
# SAFE on the GUI thread: the engine only *builds* layout items (fast) and freezes
# the canvas while it does; the heavy N-page render happens later, when JJ hits
# Export in the designer — never here.
import os
import traceback


def _layer_source_path(layer):
    try:
        return os.path.normpath(layer.source().split("|")[0])
    except Exception:
        return ""


def _add_missing_extras(project, extra_layers):
    """Load framing helpers (e.g. the greenfield boundary) if not already present,
    mirroring the headless generator so the overview frames identically."""
    from qgis.core import QgsVectorLayer, QgsFillSymbol
    have = {_layer_source_path(l) for l in project.mapLayers().values()
            if isinstance(l, QgsVectorLayer)}
    for el in (extra_layers or []):
        src = el.get("path")
        if not src or not os.path.exists(src):
            continue
        if os.path.normpath(src) in have:
            continue
        vl = QgsVectorLayer(src, el.get("name", os.path.basename(src)), "ogr")
        if not vl.isValid():
            continue
        if el.get("fill"):
            try:
                vl.renderer().setSymbol(QgsFillSymbol.createSimple(el["fill"]))
            except Exception:
                pass
        project.addMapLayer(vl, el.get("add_to_tree", True))


def build_in_project(iface, hld_cfg, extra_layers=None):
    """Build both HLD layouts in the CURRENT project and open the Print Layout designer.

    Returns (ok: bool, message: str, overview_name: str|None, atlas_name: str|None).
    The map layers get the HLD deliverable styling (the layouts render the live
    layers, so the styling has to live on them). Nothing is saved — close without
    saving to revert, or Save to keep the layouts + styling in your project.
    """
    from qgis.core import QgsProject
    p = QgsProject.instance()
    here = os.path.dirname(os.path.abspath(__file__))
    engine = os.path.join(here, "hld_atlas_engine.py")
    if not os.path.exists(engine):
        return (False, f"Engine not found: {engine}", None, None)

    try:
        _add_missing_extras(p, extra_layers)
    except Exception as e:
        # framing helper is optional — never fail the whole build over it
        print("HLD live build: extra-layer add skipped:", e)

    hld_cfg = dict(hld_cfg or {})
    hld_cfg["build_mode"] = "layouts"          # page-view overview + detail atlas (WYSIWYG)
    ns = {"HLD_CFG": hld_cfg}
    try:
        with open(engine, encoding="utf-8") as f:
            exec(compile(f.read(), engine, "exec"), ns)   # runs build_all() at module end
    except Exception as e:
        return (False, f"Layout build failed: {e}\n{traceback.format_exc()[-700:]}", None, None)

    eff = ns.get("CFG", {}) or {}
    ov_name = eff.get("layout_overview", "MOA PH2 HLD Overview")
    at_name = eff.get("layout_atlas", "MOA PH2 HLD Atlas")
    lm = p.layoutManager()
    overview = lm.layoutByName(ov_name)     # only exists in grid/commercial page-layout mode
    atlas = lm.layoutByName(at_name)        # the book atlas (overview page 1 + detail pages)
    if atlas is None:
        return (False, "Layout was not created (engine build produced nothing).", None, None)

    _role = ns.get("_role")
    cov = _role("coverage") if callable(_role) else None
    n = cov.featureCount() if cov else 0
    if not cov or n < 1:
        return (False, "Coverage layer is empty or unresolved — check the coverage/model selection.",
                None, None)

    def _relock_frame(layout):
        """QGIS4 atlas preview grows the map frame to the first feature's aspect; force it
        back to its designed size (stored by the engine) — then it holds across all pages."""
        from qgis.core import QgsLayoutItemMap, QgsLayoutPoint, QgsLayoutSize, QgsUnitTypes
        MM = QgsUnitTypes.LayoutUnit.LayoutMillimeters
        for it in layout.items():
            if isinstance(it, QgsLayoutItemMap):
                w = it.customProperty("hld_frame_w"); h = it.customProperty("hld_frame_h")
                x = it.customProperty("hld_frame_x"); y = it.customProperty("hld_frame_y")
                if w and h:
                    if x is not None and y is not None:
                        it.attemptMove(QgsLayoutPoint(float(x), float(y), MM))
                    it.attemptResize(QgsLayoutSize(float(w), float(h), MM))

    def _show_atlas_toolbar(designer):
        """The Atlas Toolbar (◀ [page] ▶ page-flip arrows) is hidden by default in a fresh
        designer window — show it so the operator can flip through the pages."""
        try:
            from qgis.PyQt.QtWidgets import QToolBar
            win = designer.window() if hasattr(designer, "window") else None
            if win is None:
                return
            for tb in win.findChildren(QToolBar):
                if (tb.objectName() or "").lower() == "matlastoolbar":
                    tb.setVisible(True)
        except Exception:
            pass

    def _open_front(layout, atlas_preview=False):
        try:
            d = iface.openLayoutDesigner(layout)
            if atlas_preview:
                try:
                    d.setAtlasPreviewEnabled(True)
                    layout.atlas().seekTo(0)
                    _relock_frame(layout)                 # undo the preview resize, then fit
                    layout.atlas().refreshCurrentFeature()
                    _relock_frame(layout)                 # belt-and-suspenders
                    layout.refresh()
                    _show_atlas_toolbar(d)                # reveal the page-flip arrows
                except Exception:
                    pass
            try:
                w = d.window() if hasattr(d, "window") else None
                if w is not None:
                    w.show(); w.raise_(); w.activateWindow()
            except Exception:
                pass
        except Exception as e:
            print("HLD live build: openLayoutDesigner skipped:", e)

    # open the book atlas: page 1 = overview, flip ▶ to each detail page
    if overview is not None and overview is not atlas:
        _open_front(overview)                          # grid/commercial: separate overview
    _open_front(atlas, atlas_preview=True)

    pages = 1 + n
    return (True, f"Built “{at_name}” — page 1 overview, flip ▶ through {n} detail pages "
            f"({pages} total).", at_name, None)
