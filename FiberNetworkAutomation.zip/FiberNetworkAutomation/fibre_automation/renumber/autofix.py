# claude:intent MUTATE — user asked (verbatim): "make it so that the automation can
#   fix all of these and detect whats going on ... study and use it". Plan: repair
#   ONLY the data problems the geometry provably answers (a blank/unreadable _SP that
#   sits inside exactly one PON polygon -> that PON's number). propose() is read-only;
#   apply() is the only writer and the dialog backs up before calling it. The genuine
#   network gaps (P019 missing an FTS, P014 with two) are deliberately NOT touched —
#   traced on 2026-07-16, the data does not contain their answer, so a "fix" would
#   fabricate topology.
"""autofix — repair the data problems whose answer the GEOMETRY already contains.

The renumber cannot fix what it cannot prove. But some "data issues" are not guesses
at all: a joint whose `_SP` is blank/unreadable but which sits inside exactly ONE PON
polygon HAS a provable PON — the one it is physically inside. On Malmsbury 536 of 540
`_SP` joints already match the polygon they sit in (100%), so "the polygon you are in
IS your PON" is not a heuristic here, it is what the data says.

What this fixes (and ONLY this):
  * a joint with a blank/unreadable `_SP` that sits inside exactly one PON
    -> its `_SP` is set to that PON. Deterministic, reversible, backed up.

What it deliberately does NOT touch, because the data does not contain the answer:
  * a PON with no splitter / a PON with two (P019/P014 on Malmsbury) — traced: both
    P014 joints genuinely serve P014, P019 truly lacks an FTS. That is a network
    PLANNING gap, not a label error. Inventing a label would fabricate topology.
  * a joint that sits OUTSIDE every PON — geometry cannot judge it.

READ-ONLY detect (`propose`) is separate from the only writer (`apply`), same shape
as scan/plan/apply. No Qt at module level.
"""
import re

_SP_RX = re.compile(r"_SP0*(\d+)(?!\d)", re.I)
# a name that carries an _SP token but no number after it: 'MMB_DJ539_SP', 'X_SP_'
_SP_BLANK_RX = re.compile(r"_SP(?![0-9])", re.I)


def _pon_polygons(project):
    """[(pon_number, geometry)] for the PON polygons."""
    from qgis.core import QgsVectorLayer
    out = []
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
            continue
        if lyr.name().strip().lower() not in ("pons", "pon"):
            continue
        fields = [f.name() for f in lyr.fields()]
        pf = next((x for x in ("PON", "pon_no", "pon") if x in fields), None)
        if pf is None:
            continue
        for f in lyr.getFeatures():
            m = re.search(r"(\d+)", str(f[pf] or ""))
            g = f.geometry()
            if m and g and not g.isEmpty():
                out.append((int(m.group(1)), g))
    return out


def _containing(polys, geom):
    """The PON number(s) whose polygon contains this geometry's surface point."""
    if not geom or geom.isEmpty():
        return []
    pt = geom.pointOnSurface()
    return [n for n, g in polys if g and g.contains(pt)]


class Fix:
    """One proposed, geometry-proven label repair."""
    __slots__ = ("fid", "field", "layer_id", "layer_name", "new", "old", "reason")

    def __init__(self, layer_id, layer_name, fid, field, old, new, reason):
        self.layer_id = layer_id
        self.layer_name = layer_name
        self.fid = fid
        self.field = field
        self.old = old
        self.new = new
        self.reason = reason


def propose(project, scans):
    """READ-ONLY. Return [Fix] for every blank/unreadable _SP that sits in exactly
    one PON — the only repair the geometry proves. Never writes.

    `scans` is used only to find WHICH layers/fields carry the SP reference, so this
    stays schema-driven (no hardcoded 'Dome Joints'/'Name').
    """
    from qgis.core import QgsVectorLayer
    sp = None
    for name, sc in scans.items():
        if sc.spec.is_reference and sc.spec.follows == "PON":
            sp = sc.spec
            break
    if sp is None:
        return []
    polys = _pon_polygons(project)
    if not polys:
        return []

    want_layers = {n.strip().lower() for n in sp.layers}
    fixes = []
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
            continue
        if lyr.name().strip().lower() not in want_layers:
            continue
        names = [f.name() for f in lyr.fields()]
        for field in sp.fields:
            real = next((n for n in names if n.strip().lower() == field.strip().lower()),
                        None)
            if real is None:
                continue
            for f in lyr.getFeatures():
                v = str(f[real] or "")
                if not _SP_BLANK_RX.search(v):
                    continue                     # no bare _SP token here
                if _SP_RX.search(v):
                    continue                     # it HAS a number — not blank
                host = _containing(polys, f.geometry())
                if len(host) != 1:
                    continue                     # 0 or many PONs — cannot prove
                n = host[0]
                # write the number right where the bare _SP token sits
                new = _SP_BLANK_RX.sub(f"_SP{n}", v, count=1)
                if new != v:
                    fixes.append(Fix(
                        lyr.id(), lyr.name(), f.id(), real, v, new,
                        f"sits inside P{n:03d} (geometry) — its blank _SP resolves to "
                        f"_SP{n}"))
    return fixes


def apply(project, fixes):
    """The ONLY writer. Bulk provider write per layer. Returns {"ok","written",
    "undo": {(layer_id, fid, field): old}, "errors"}. Caller backs up first.
    """
    from collections import defaultdict
    by_layer = defaultdict(list)
    for fx in fixes:
        by_layer[fx.layer_id].append(fx)
    written = 0
    undo = {}
    errors = []
    for layer_id, group in by_layer.items():
        lyr = project.mapLayer(layer_id)
        if lyr is None:
            errors.append(f"layer {layer_id} vanished")
            continue
        idx = {f.name(): lyr.fields().indexOf(f.name()) for f in lyr.fields()}
        changes = {}
        for fx in group:
            i = idx.get(fx.field, -1)
            if i < 0:
                errors.append(f"{fx.layer_name}: no field {fx.field}")
                continue
            changes[fx.fid] = {i: fx.new}
            undo[(layer_id, fx.fid, fx.field)] = fx.old
        if changes and lyr.dataProvider().changeAttributeValues(changes):
            written += len(changes)
            lyr.triggerRepaint()
        elif changes:
            errors.append(f"{lyr.name()}: provider write failed")
    return {"ok": not errors, "written": written, "undo": undo, "errors": errors}
