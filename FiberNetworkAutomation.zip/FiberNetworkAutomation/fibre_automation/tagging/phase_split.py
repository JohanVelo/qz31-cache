try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

"""phase_split — give every feature ONE phase, from the phase polygons it sits in.

The engine behind the "Split into Phases" button (JJ, 2026-10-27). It decides the
``Phase`` value for each feature; ``phase_export`` writes the Combined / Phase N
folders and ``phase_tree`` builds the Phases group in the Layers panel.

Why not ``zone_tag``: that tool lists EVERY zone a cable crosses ("Phase 1, Phase 2"),
which is right for a PON column but would make a fake folder per combination here.
A phase split needs exactly one answer per feature. Reused from zone_tag: the
metre-safe measurer, value normalising, field lookup and the bulk-write discipline.

Rules (measured on the Lulekani hand split + JJ's calls, 2026-10-27):
  * point            → the phase polygon it sits in.
  * line             → the phase it runs furthest inside (Lulekani: 233/233 cables).
  * polygon          → the phase it overlaps most by area.
  * inside none      → the NEAREST phase, flagged "nearest" with its distance
                       (Lulekani hand-tagged all 65 feeder-route poles; JJ chose nearest).
  * tie / overlap    → the lowest phase number, flagged.
  * existing value   → never overwritten unless the user ticks that conflict.

TWO PHASES, like zone_tag: ``build_plan`` only READS; ``apply_plan`` is the only writer.
NO Qt AT MODULE LEVEL — qgis imports are function-local so the rules stay unit-testable.
"""
import os
import re

OUT_FIELD = "Phase"

HOW_INSIDE = "inside"      # point inside / line or polygon wholly inside one phase
HOW_OVERLAP = "overlap"    # crosses several phases, most-overlap won
HOW_NEAREST = "nearest"    # inside no phase at all
HOW_TIE = "tie"            # equal overlap / overlapping phase polygons
HOW_NONE = "none"          # no geometry, or no phase polygons at all

_SHP_FIELD_MAX = 10
_STRING_TYPE_NAMES = ("string", "text", "varchar", "qstring", "character")

# Names that mark a layer as an existing per-phase COPY (Lulekani "Poles PH1",
# Malmesbury "PH1 poles", "Phase 3"). Pre-unticked so a split never splits a split.
_PHASE_COPY_RE = re.compile(r"(\bPH\s*\d+\b)|(^\s*phase\s*\d+\s*$)", re.IGNORECASE)


# ── pure helpers (no QGIS) ───────────────────────────────────────────────────
def norm_text(v):
    """Attribute → stripped string, or None for NULL/blank."""
    if v is None:
        return None
    try:
        from qgis.PyQt.QtCore import QVariant
        if isinstance(v, QVariant) and v.isNull():
            return None
    except Exception:
        _swallowed_note()
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    s = str(v).strip()
    if not s or s.lower() in ("null", "none"):
        return None
    return s


def phase_label(raw):
    """The value written to the Phase column for a polygon's raw value.

    A bare number becomes "Phase N" (Lulekani / Mahikeng convention); anything else
    is kept as typed. None stays None (a blank polygon is skipped by the caller).
    """
    s = norm_text(raw)
    if s is None:
        return None
    if re.fullmatch(r"\d+", s):
        return "Phase %d" % int(s)
    return s


def phase_key(value):
    """Comparison key: "Phase 1", "phase 1", "PHASE  1 " and "1" are the same phase."""
    s = norm_text(value)
    if s is None:
        return None
    low = re.sub(r"\s+", " ", s.lower())
    m = re.fullmatch(r"(?:phase|ph)?\s*0*(\d+)", low)
    if m:
        return "phase %d" % int(m.group(1))
    return low


def phase_number(value):
    """Integer in a phase value ("Phase 12" → 12), else None."""
    m = re.search(r"(\d+)", str(value or ""))
    return int(m.group(1)) if m else None


def natural_key(s):
    out = []
    for part in re.split(r"(\d+)", str(s)):
        if part.isdigit():
            out.append((1, int(part), ""))
        elif part:
            out.append((0, 0, part.lower()))
    return out


def looks_like_phase_copy(name):
    """True for layer names that already are a per-phase copy ("Poles PH1")."""
    return bool(_PHASE_COPY_RE.search(str(name or "")))


def pick_best(shares):
    """{phase: amount>0} → (phase, how). Largest wins; a tie goes to the lowest phase."""
    shares = {k: v for k, v in shares.items() if v and v > 0}
    if not shares:
        return None, HOW_NONE
    if len(shares) == 1:
        return next(iter(shares)), HOW_INSIDE
    top = max(shares.values())
    best = sorted((k for k, v in shares.items() if abs(v - top) <= 1e-9 * max(1.0, top)),
                  key=natural_key)
    if len(best) > 1:
        return best[0], HOW_TIE
    return best[0], HOW_OVERLAP


# ── QGIS helpers ─────────────────────────────────────────────────────────────
def _field_lookup(layer, name):
    want = str(name).lower()
    for f in layer.fields():
        if f.name().lower() == want:
            return f.name()
    return None


def _is_string_field(field):
    try:
        return any(t in (field.typeName() or "").lower() for t in _STRING_TYPE_NAMES)
    except Exception:
        return False


def is_shapefile(layer):
    try:
        return "shapefile" in (layer.dataProvider().storageType() or "").lower()
    except Exception:
        return False


def _geom_type(layer):
    from qgis.core import QgsWkbTypes
    try:
        return QgsWkbTypes.geometryType(layer.wkbType())
    except Exception:
        return None


def _measurer(crs, project):
    try:
        from ..shared.crs_utils import metre_measurer
    except ImportError:                       # pragma: no cover - flat import
        from fibre_automation.shared.crs_utils import metre_measurer
    return metre_measurer(crs, project)


def _measures_metres(da):
    try:
        from ..shared.crs_utils import measures_metres
    except ImportError:                       # pragma: no cover
        from fibre_automation.shared.crs_utils import measures_metres
    return measures_metres(da)


def layer_file(layer):
    """Absolute primary file behind a file-based layer, or None."""
    try:
        from qgis.core import QgsProviderRegistry
        parts = QgsProviderRegistry.instance().decodeUri(layer.providerType(), layer.source())
        p = parts.get("path") or ""
    except Exception:
        p = (layer.source() or "").split("|")[0]
    p = p.strip().strip('"')
    return os.path.normpath(p) if p and os.path.isabs(p) else None


# ── phase source ─────────────────────────────────────────────────────────────
class PhaseSource:
    """Where the phase polygons come from.

    kind "field":  ONE polygon layer, the phase name in ``field`` (Lulekani, Mahikeng).
    kind "layers": SEVERAL polygon layers, one per phase, the layer NAME is the phase.
    """

    def __init__(self, kind, layer_ids, field=None):
        self.kind = kind
        self.layer_ids = list(layer_ids)
        self.field = field

    def __repr__(self):   # pragma: no cover - debug aid
        return "PhaseSource(%s, %s, %s)" % (self.kind, self.layer_ids, self.field)


class _Phases:
    """Phase polygons in ONE working CRS, with a spatial index + prepared engines."""

    def __init__(self, project, source):
        from qgis.core import (QgsCoordinateTransform, QgsFeature, QgsGeometry,
                               QgsSpatialIndex, QgsVectorLayer, QgsWkbTypes)
        self.warnings = []
        self.errors = []
        self.geoms = {}        # phase label → QgsGeometry (parts of one phase unioned)
        self.order = []        # phase labels, natural order
        self.raw_values = {}   # phase label → set of raw source values (for the filters)
        self.source_fids = {}  # (layer_id, phase label) → [fid, …] of the source polygons
        self.crs = None
        layers = []
        for lid in source.layer_ids:
            lyr = project.mapLayer(lid)
            if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
                self.errors.append("A phase polygon layer is missing from the project.")
                continue
            if _geom_type(lyr) != QgsWkbTypes.PolygonGeometry:
                self.errors.append("'%s' is not a polygon layer." % lyr.name())
                continue
            layers.append(lyr)
        if not layers:
            self.errors.append("No phase polygons to split with.")
            return
        self.crs = layers[0].crs()
        parts = {}
        for lyr in layers:
            xf = None if lyr.crs() == self.crs else QgsCoordinateTransform(
                lyr.crs(), self.crs, project)
            real = _field_lookup(lyr, source.field) if source.kind == "field" else None
            if source.kind == "field" and real is None:
                self.errors.append("'%s' has no field '%s'." % (lyr.name(), source.field))
                continue
            blanks = 0
            for f in lyr.getFeatures():
                raw = f[real] if real else lyr.name()
                label = phase_label(raw)
                if label is None:
                    blanks += 1
                    continue
                g = f.geometry()
                if g is None or g.isEmpty():
                    self.warnings.append("'%s': %s has no geometry — skipped." % (lyr.name(), label))
                    continue
                g = QgsGeometry(g)
                if xf is not None:
                    g.transform(xf)
                if not g.isGeosValid():
                    g = g.makeValid()
                parts.setdefault(label, []).append(g)
                self.raw_values.setdefault(label, set()).add(norm_text(raw))
                self.source_fids.setdefault((lyr.id(), label), []).append(f.id())
            if blanks:
                self.warnings.append(
                    "'%s': %d polygon%s with no phase value — skipped."
                    % (lyr.name(), blanks, "" if blanks == 1 else "s"))
        # one geometry per phase; keyed by the comparison key so "1" and "Phase 1" merge
        merged = {}
        for label, gs in parts.items():
            key = phase_key(label)
            if key in merged:
                lab0, g0 = merged[key]
                merged[key] = (lab0, QgsGeometry.unaryUnion([g0] + gs))
                self.raw_values[lab0] |= self.raw_values.pop(label, set())
                for (lid, lab), fids in list(self.source_fids.items()):
                    if lab == label:
                        self.source_fids.setdefault((lid, lab0), []).extend(fids)
                        del self.source_fids[(lid, lab)]
            else:
                merged[key] = (label, gs[0] if len(gs) == 1 else QgsGeometry.unaryUnion(gs))
        for _k, (label, g) in merged.items():
            self.geoms[label] = g
        self.order = sorted(self.geoms, key=natural_key)
        if not self.order:
            self.errors.append("The phase layer has no polygons with a phase value.")
            return
        self.da = _measurer(self.crs, project)
        self.metres_ok = _measures_metres(self.da)
        self.index = QgsSpatialIndex()
        self._ids = {}
        for i, label in enumerate(self.order, start=1):
            nf = QgsFeature(i)
            nf.setGeometry(self.geoms[label])
            self.index.addFeature(nf)
            self._ids[i] = label
        self._engines = {}

    def __len__(self):
        return len(self.order)

    def _engine(self, label):
        eng = self._engines.get(label)
        if eng is None:
            from qgis.core import QgsGeometry
            eng = QgsGeometry.createGeometryEngine(self.geoms[label].constGet())
            eng.prepareGeometry()
            self._engines[label] = eng
        return eng

    def _candidates(self, geom):
        return [self._ids[i] for i in self.index.intersects(geom.boundingBox())]

    def assign(self, geom, gtype):
        """(phase, how, metres_to_nearest_or_None) for one geometry in self.crs."""
        from qgis.core import QgsWkbTypes
        if geom is None or geom.isEmpty():
            return None, HOW_NONE, None
        cands = self._candidates(geom)
        shares = {}
        if gtype == QgsWkbTypes.PointGeometry:
            for lab in cands:
                if self._engine(lab).intersects(geom.constGet()):
                    shares[lab] = 1.0
        else:
            hits = [lab for lab in cands if self._engine(lab).intersects(geom.constGet())]
            if len(hits) == 1 and self._engine(hits[0]).contains(geom.constGet()):
                return hits[0], HOW_INSIDE, None
            for lab in hits:
                try:
                    inter = self.geoms[lab].intersection(geom)
                except Exception:
                    inter = None
                if inter is None or inter.isEmpty():
                    continue
                if gtype == QgsWkbTypes.LineGeometry:
                    v = self.da.measureLength(inter)
                else:
                    v = self.da.measureArea(inter)
                if v and v > 0:
                    shares[lab] = v
        lab, how = pick_best(shares)
        if lab is not None:
            return lab, how, None
        return self._nearest(geom)

    def _nearest(self, geom):
        best, best_d = None, None
        for lab in self.order:
            try:
                line = self.geoms[lab].shortestLine(geom)
                pts = line.asPolyline() if line and not line.isEmpty() else []
                if len(pts) >= 2:
                    d = self.da.measureLine(pts[0], pts[-1])
                else:
                    d = self.geoms[lab].distance(geom)
            except Exception:
                continue
            if d is None:
                continue
            if best_d is None or d < best_d - 1e-9 or (abs(d - best_d) <= 1e-9 and
                                                       natural_key(lab) < natural_key(best)):
                best, best_d = lab, d
        if best is None:
            return None, HOW_NONE, None
        return best, HOW_NEAREST, best_d


# ── plan containers ──────────────────────────────────────────────────────────
class LayerPlan:
    def __init__(self, layer_id, name):
        self.layer_id = layer_id
        self.name = name
        self.field = OUT_FIELD          # real field name on this layer (may already exist)
        self.field_exists = False
        self.assign = {}                # fid → computed phase (None = nothing to say)
        self.how = {}                   # fid → HOW_*
        self.dist = {}                  # fid → metres (nearest only)
        self.old = {}                   # fid → existing value (only where not blank)
        self.fill = {}                  # fid → value: blanks that WILL be written
        self.conflicts = {}             # fid → (old, computed): needs a tick to overwrite
        self.labels = {}                # fid → readable label for the preview
        self.skipped_reason = None      # a reason this layer cannot be tagged

    def counts(self):
        """phase → features that will carry it after Apply (conflicts keep their old value)."""
        out = {}
        for fid, v in self.assign.items():
            val = self.old.get(fid) if fid in self.conflicts else (self.old.get(fid) or v)
            out[val] = out.get(val, 0) + 1
        return out


class PhasePlan:
    def __init__(self):
        self.source = None
        self.phases = []                # phase labels, natural order
        self.layers = {}                # layer_id → LayerPlan (ordered as given)
        self.source_layer_ids = []
        self.raw_values = {}
        self.source_fids = {}
        self.warnings = []
        self.errors = []
        self.elapsed_s = 0.0
        self.metres_ok = True

    @property
    def total_fill(self):
        return sum(len(lp.fill) for lp in self.layers.values())

    @property
    def total_conflicts(self):
        return sum(len(lp.conflicts) for lp in self.layers.values())

    def nearest_rows(self):
        out = []
        for lp in self.layers.values():
            for fid, how in lp.how.items():
                if how == HOW_NEAREST:
                    out.append((lp.name, fid, lp.labels.get(fid, str(fid)),
                                lp.assign.get(fid), lp.dist.get(fid)))
        return out


_LABEL_FIELDS = ("name", "label", "pole id", "pole_no", "cable no", "pon", "id", "fid")


def _label_field(layer):
    lut = {f.name().lower(): f.name() for f in layer.fields()}
    for c in _LABEL_FIELDS:
        if c in lut:
            return lut[c]
    return None


# ── build (READ-ONLY) ────────────────────────────────────────────────────────
def build_plan(project, source, target_layer_ids, out_field=OUT_FIELD):
    """Work out the phase of every feature in every target layer. Writes NOTHING."""
    import time
    from qgis.core import QgsCoordinateTransform, QgsGeometry, QgsProject, QgsVectorLayer
    t0 = time.time()
    project = project or QgsProject.instance()
    plan = PhasePlan()
    plan.source = source
    phases = _Phases(project, source)
    plan.warnings.extend(phases.warnings)
    plan.errors.extend(phases.errors)
    if phases.errors and not len(phases):
        plan.elapsed_s = time.time() - t0
        return plan
    plan.phases = list(phases.order)
    plan.raw_values = {k: set(v) for k, v in phases.raw_values.items()}
    plan.source_fids = dict(phases.source_fids)
    plan.source_layer_ids = list(source.layer_ids)
    plan.metres_ok = phases.metres_ok
    if not phases.metres_ok:
        plan.errors.append(
            "This project has no ellipsoid set, so lengths can't be measured in metres "
            "and cables crossing two phases can't be compared. Set one in Project ▸ "
            "Properties ▸ General ▸ Measurements (WGS 84 is fine).")
        plan.elapsed_s = time.time() - t0
        return plan

    for lid in target_layer_ids:
        lyr = project.mapLayer(lid)
        if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
            plan.warnings.append("A chosen layer is no longer in the project — skipped.")
            continue
        if lid in source.layer_ids:
            continue                          # the phase polygons tag nothing of their own
        lp = LayerPlan(lid, lyr.name())
        plan.layers[lid] = lp
        real = _field_lookup(lyr, out_field)
        if real is not None:
            fld = lyr.fields()[lyr.fields().indexFromName(real)]
            if not _is_string_field(fld):
                lp.skipped_reason = ("already has a '%s' field of type %s — it can't hold "
                                     "'Phase 1'. Rename that field first."
                                     % (real, fld.typeName()))
                continue
            lp.field, lp.field_exists = real, True
        elif is_shapefile(lyr) and len(out_field) > _SHP_FIELD_MAX:
            lp.field = out_field[:_SHP_FIELD_MAX]
        gtype = _geom_type(lyr)
        xf = None if lyr.crs() == phases.crs else QgsCoordinateTransform(
            lyr.crs(), phases.crs, project)
        lbl = _label_field(lyr)
        for f in lyr.getFeatures():
            fid = f.id()
            g = f.geometry()
            if g is not None and not g.isEmpty() and xf is not None:
                try:
                    g = QgsGeometry(g)
                    g.transform(xf)
                except Exception:
                    g = None
            val, how, dist = phases.assign(g, gtype)
            lp.assign[fid] = val
            lp.how[fid] = how
            if dist is not None:
                lp.dist[fid] = dist
            lp.labels[fid] = (norm_text(f[lbl]) if lbl else None) or ("#%d" % fid)
            old = norm_text(f[real]) if real else None
            if old is not None:
                lp.old[fid] = old
                if val is not None and phase_key(old) != phase_key(val):
                    lp.conflicts[fid] = (old, val)
            elif val is not None:
                lp.fill[fid] = val
    if not plan.layers and not plan.errors:
        plan.errors.append("No layers chosen to split.")
    plan.elapsed_s = time.time() - t0
    return plan


# ── backup (before the only writer) ──────────────────────────────────────────
_SIDECARS = (".shp", ".shx", ".dbf", ".prj", ".cpg", ".qix", ".sbn", ".sbx", ".qmd")


def backup_layers(project, layer_ids, dest_dir):
    """Copy every file behind ``layer_ids`` into ``dest_dir``. Returns (ok, copied, problems).

    Verbatim copies (shapefile + sidecars, or the whole GeoPackage), so a restore is a
    plain copy back. A layer with no file (memory / database) is reported in
    ``problems`` but does not make ``ok`` False; only a failed COPY does.
    """
    import shutil
    os.makedirs(dest_dir, exist_ok=True)
    copied, problems, seen = [], [], set()
    failed = False
    for lid in layer_ids:
        lyr = project.mapLayer(lid)
        if lyr is None:
            continue
        path = layer_file(lyr)
        if not path or not os.path.exists(path):
            problems.append("'%s' has no file on disk to back up." % lyr.name())
            continue
        if path.lower() in seen:
            continue
        seen.add(path.lower())
        base, ext = os.path.splitext(path)
        files = ([base + s for s in _SIDECARS if os.path.exists(base + s)]
                 if ext.lower() == ".shp" else [path])
        for src in files:
            dst = os.path.join(dest_dir, os.path.basename(src))
            if os.path.exists(dst):            # two folders, same file name
                stem, e = os.path.splitext(os.path.basename(src))
                dst = os.path.join(dest_dir, "%s__%d%s" % (stem, len(seen), e))
            try:
                shutil.copy2(src, dst)
                copied.append((src, dst))
            except Exception as exc:
                problems.append("could not copy %s: %s" % (os.path.basename(src), exc))
                failed = True
    return not failed, copied, problems


# ── apply (THE ONLY WRITER) ──────────────────────────────────────────────────
class ApplyResult:
    def __init__(self):
        self.written = {}       # layer_id → features changed
        self.fields_added = []  # layer names that got the field
        self.skipped = []
        self.errors = []

    @property
    def ok(self):
        return not self.errors

    @property
    def total_written(self):
        return sum(self.written.values())


# claude:intent MUTATE fibre_automation/tagging/phase_split.py apply_plan
#   Adds the Phase text field where missing and fills ONLY blank Phase cells from the
#   plan the user previewed, plus the conflicts the user ticked. No other field and no
#   geometry is touched; the caller backs the layer files up first. JJ approved the
#   tool 2026-10-27 ("Split into Phases" GO). approved-destructive
# claude:boq-impact none - writes only the Phase attribute; quantities are not changed.
def apply_plan(project, plan, overwrite=None):
    """Write the plan. ``overwrite`` = {layer_id: set(fid)} of conflicts the user ticked."""
    from qgis.core import QgsField, QgsProject, QgsVectorDataProvider
    from qgis.PyQt.QtCore import QMetaType
    project = project or QgsProject.instance()
    overwrite = overwrite or {}
    res = ApplyResult()
    for lid, lp in plan.layers.items():
        if lp.skipped_reason:
            res.skipped.append("'%s' %s" % (lp.name, lp.skipped_reason))
            continue
        values = dict(lp.fill)
        for fid in overwrite.get(lid, ()):
            if fid in lp.conflicts:
                values[fid] = lp.conflicts[fid][1]
        lyr = project.mapLayer(lid)
        if lyr is None or not lyr.isValid():
            res.errors.append("'%s' is no longer in the project." % lp.name)
            continue
        if lyr.isEditable():
            res.errors.append("'%s' is in edit mode — save or discard its edits, then run "
                              "again." % lp.name)
            continue
        dp = lyr.dataProvider()
        caps = dp.capabilities()
        if not lp.field_exists and _field_lookup(lyr, lp.field) is None:
            if not (caps & QgsVectorDataProvider.Capability.AddAttributes):
                res.skipped.append("'%s' is read-only (can't add a Phase field)." % lp.name)
                continue
            if not dp.addAttributes([QgsField(lp.field, QMetaType.Type.QString, len=50)]):
                res.errors.append("'%s': could not add the %s field — left unchanged."
                                  % (lp.name, lp.field))
                continue
            lyr.updateFields()
            res.fields_added.append(lp.name)
        if not values:
            res.written[lid] = 0
            continue
        if not (caps & QgsVectorDataProvider.Capability.ChangeAttributeValues):
            res.skipped.append("'%s' doesn't allow attribute edits." % lp.name)
            continue
        real = _field_lookup(lyr, lp.field)
        idx = dp.fields().indexOf(real) if real else -1
        if idx < 0:
            res.errors.append("'%s': the %s field did not appear — left unchanged."
                              % (lp.name, lp.field))
            continue
        # ONE bulk provider write per layer (never per-feature in a loop)
        if dp.changeAttributeValues({fid: {idx: v} for fid, v in values.items()}):
            res.written[lid] = len(values)
        else:
            res.errors.append("'%s': the provider rejected the write." % lp.name)
        try:
            lyr.updateFields()
            lyr.triggerRepaint()
        except Exception:
            _swallowed_note()
    return res


# ── dialog conveniences ──────────────────────────────────────────────────────
_PHASE_FIELD_HINTS = ("phase", "phase num", "phase_num", "phase_no", "phases", "ph", "name")


def phase_layers(project=None):
    """[(layer, is_likely_phase_layer)] for every polygon layer, phase-looking first."""
    from qgis.core import QgsProject, QgsVectorLayer, QgsWkbTypes
    project = project or QgsProject.instance()
    out = []
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
            continue
        if _geom_type(lyr) != QgsWkbTypes.PolygonGeometry:
            continue
        likely = "phase" in lyr.name().lower() and not looks_like_phase_copy(lyr.name())
        out.append((lyr, likely))
    out.sort(key=lambda t: (not t[1], -t[0].featureCount() if t[1] else 0, t[0].name().lower()))
    return out


_PHASE_VALUE_RE = re.compile(r"^\s*(phase|ph)\s*\d+\s*$", re.IGNORECASE)


def guess_phase_field(layer, sample=500):
    """The field holding the phase name, or "" when nothing is convincing.

    Judged by VALUES first: a field whose values read "Phase 1" / "PH2" wins whatever
    it is called (Botshabelo keeps them in "layer", left by Merge Vector Layers).
    A bare-number field only counts when its NAME says phase, so "fid" / "id" (also
    1…9) are never picked. No silent first-field fallback: "" makes the user choose.
    """
    names = [f.name() for f in layer.fields()]
    if not names:
        return ""
    hits = {n: 0 for n in names}
    seen = {n: 0 for n in names}
    for i, f in enumerate(layer.getFeatures()):
        if i >= sample:
            break
        for n in names:
            v = norm_text(f[n])
            if v is None:
                continue
            seen[n] += 1
            if _PHASE_VALUE_RE.match(v):
                hits[n] += 1
    by_value = [n for n in names if seen[n] and hits[n] >= 0.8 * seen[n]]
    if by_value:
        by_value.sort(key=lambda n: ("phase" not in n.lower(), -hits[n]))
        return by_value[0]
    lut = {n.lower(): n for n in names}
    for c in _PHASE_FIELD_HINTS:
        if c in lut and c != "name":
            return lut[c]
    for low, real in lut.items():
        if "phase" in low:
            return real
    return ""
