"""Structure-mode graph core for the Labeling Wizard.

Builds a connectivity graph from raw cable segments + splitter/demand points,
then walks it per subtree root (one FTS per zone) in deterministic DFS
preorder.  This generalizes network_planner/feeder_walk.py one level deeper:
instead of only ordering ZONES along the feeder, it orders every cable run,
splitter and demand point in a CONFIG-DRIVEN hierarchy (numbering.
HierarchyConfig — duck-typed here, no import needed), rooted per subtree.

Pure Python (math + stdlib only) — no QGIS, no Qt, no shapely / networkx /
numpy — so it imports identically inside QGIS 4.0.3 python and a plain
Python 3.12, and is Hypothesis-property-testable
(tests/property/test_structure_graph.py).

Deterministic: no random, no time, every collection is processed in an
explicitly sorted order — the same input (in any order) yields the identical
graph, walk and flags every run.

Data contracts (the QGIS adapter, built separately, produces these):
    Segment = {"id": hashable, "cls": str, "coords": [(x, y), ...],
               "size": optional number}          # polyline; cls = tier name
    Point   = {"id": hashable, "role": str, "xy": (x, y), "attrs": dict}

Coordinates are lon/lat degrees (EPSG:4326).  ALL tolerances are METRES and
converted internally via DEG_PER_M.

API:
    build_graph(segments, points, *, snap_m=2.0, tap_m=6.0) -> Graph
    traverse(graph, roots, config) -> (walks, anomalies)
        walks     : [{"root": rid, "items": [item, ...]}, ...]  (root-id order)
        item      : {"feature_id", "level", "kind", "parent_id", "order",
                     "chainage", "members", "flagged"}
        anomalies : [{"feature_id", "code", "detail"}, ...]   (flag, NEVER mutate)

Anomaly codes: pop_count, unreachable, dangling_end, loop_closed,
point_off_network, zone_mismatch, unmerged_segments.
FATAL_CODES cause numbering to NULL the label; INFO_CODES only report (e.g.
a merged multi-segment run is flagged unmerged_segments but still numbers as
ONE parent — that is the required behaviour, not an error state).
"""
import math
from dataclasses import dataclass, field

# metres -> degrees at this latitude (spec constant for the target networks)
DEG_PER_M = 1.0 / 102000.0

# Flags that must NULL the feature's label downstream.
FATAL_CODES = frozenset({
    "point_off_network", "unreachable", "loop_closed", "zone_mismatch",
})
# Informational flags — reported, but the feature still gets a label.
INFO_CODES = frozenset({"pop_count", "dangling_end", "unmerged_segments"})

_MAX_DEPTH = 500  # traversal depth guard (config depth is small; belt+braces)


# ---------------------------------------------------------------------------
# geometry helpers (hand-written — no shapely)
# ---------------------------------------------------------------------------

def dist_m(a, b):
    """Metric distance in metres between two (lon, lat) degree pairs."""
    return math.hypot(a[0] - b[0], a[1] - b[1]) / DEG_PER_M


def project_point_to_segment(p, a, b):
    """Project point p onto segment a->b.

    Returns (foot_xy, t, d_m) where t in [0, 1] is the fractional chainage of
    the foot along a->b and d_m is the metre distance p->foot.
    """
    dx, dy = b[0] - a[0], b[1] - a[1]
    l2 = dx * dx + dy * dy
    if l2 <= 0.0:
        t = 0.0
    else:
        t = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / l2
        t = max(0.0, min(1.0, t))
    foot = (a[0] + t * dx, a[1] + t * dy)
    return foot, t, dist_m(p, foot)


def snap_key(xy, snap_m):
    """Grid-snap key for a (lon, lat) pair: cell size = snap_m metres."""
    cell = max(float(snap_m), 1e-9) * DEG_PER_M
    return (int(round(xy[0] / cell)), int(round(xy[1] / cell)))


def _cum_chain(coords):
    """Cumulative metre chainage at every vertex of a polyline."""
    out = [0.0]
    for i in range(1, len(coords)):
        out.append(out[-1] + dist_m(coords[i - 1], coords[i]))
    return out


def _point_at(coords, cum, c):
    """Interpolated point at metre chainage c along the polyline."""
    if c <= 0.0:
        return coords[0]
    if c >= cum[-1]:
        return coords[-1]
    for i in range(1, len(coords)):
        if cum[i] >= c:
            seg = cum[i] - cum[i - 1]
            t = (c - cum[i - 1]) / seg if seg > 0 else 0.0
            return (coords[i - 1][0] + (coords[i][0] - coords[i - 1][0]) * t,
                    coords[i - 1][1] + (coords[i][1] - coords[i - 1][1]) * t)
    return coords[-1]


def _slice(coords, cum, c0, c1):
    """Sub-polyline between metre chainages c0 < c1 (endpoints interpolated)."""
    pts = [_point_at(coords, cum, c0)]
    for i in range(len(coords)):
        if c0 < cum[i] < c1:
            pts.append(coords[i])
    pts.append(_point_at(coords, cum, c1))
    return tuple(pts)


# ---------------------------------------------------------------------------
# graph model
# ---------------------------------------------------------------------------

@dataclass
class Edge:
    """One piece of a segment between two graph nodes (split at taps)."""
    u: tuple
    v: tuple
    seg_id: object
    cls: str
    coords: tuple
    length_m: float
    chain0: float   # chainage of u along the ORIGINAL segment
    chain1: float   # chainage of v along the ORIGINAL segment


@dataclass
class Run:
    """A merged logical cable run: chained same-class degree-2 edges.

    A distribution run chopped into N pole-to-pole segments (or split at N
    tap nodes) is ONE Run — it numbers as one parent feature.
    """
    fid: object            # canonical feature id (min member id by str)
    cls: str
    members: tuple         # distinct source segment ids (sorted by str)
    size: float
    nodes: tuple           # node keys in run order
    node_chain: dict       # node key -> metre chainage from run start
    edge_idxs: tuple
    length_m: float
    is_ring: bool


@dataclass
class Graph:
    """Snapped + tap-split network graph. All maps are deterministic."""
    nodes: dict            # node key -> (lon, lat)
    edges: list            # [Edge]
    adj: dict              # node key -> tuple(edge index)
    segments: dict         # seg id -> {"cls", "size"}
    points: dict           # point id -> {"id","role","xy","attrs"}
    point_node: dict       # point id -> node key | None (off-network)
    runs: dict             # run fid -> Run
    runs_at_node: dict     # node key -> tuple(run fid)
    points_at_node: dict   # node key -> tuple(point id)
    flags: list = field(default_factory=list)
    snap_m: float = 2.0
    tap_m: float = 6.0


# ---------------------------------------------------------------------------
# build_graph
# ---------------------------------------------------------------------------

def build_graph(segments, points, *, snap_m=2.0, tap_m=6.0, cable_tap_m=6.0,
                role_tap_m=None):
    """Build the snapped, tap-split connectivity graph.

    1. grid-snap every segment endpoint to a node (key = snap_key).
    2. mid-span POINT tap: project every point onto its nearest segment
       polyline within tap_m; an interior foot SPLITS that edge at a new tap
       node (connectivity + chainage preserved), an end foot attaches to the
       existing endpoint node.  ``role_tap_m`` ({role: metres}) overrides tap_m
       for named roles ONLY — e.g. a POP is often sited a block off the feeder,
       so it gets a generous attach distance while dense drop/splitter points
       stay tight; keeps a loose root from silently bridging real gaps
       elsewhere.
    2b. mid-span CABLE-ENDPOINT tap: a spur cable whose free END lands in the
       interior of another same-or-bigger-class run (by `size`) T-junctions
       into it within cable_tap_m — the target is SPLIT at the tap and the
       spur endpoint fused to it, so the spur + its subtree stay reachable.
       (Junctions are ~0 m in practice, so a modest cable_tap_m avoids false
       links; raising snap_m/tap_m does not help — this is a distinct pass.)
    3. attach points to nodes (point_node index); points farther than tap_m
       from every segment -> flagged point_off_network (node = None).
    Flags are appended, never mutate the input.
    """
    flags = []
    nodes = {}
    role_tap_m = {str(k): float(v) for k, v in dict(role_tap_m or {}).items()}

    def _node(xy):
        k = snap_key(xy, snap_m)
        if k not in nodes:
            nodes[k] = (float(xy[0]), float(xy[1]))
        return k

    # -- 1. segments: sorted by str(id) so results never depend on input order
    segs = []
    seg_meta = {}
    for s in sorted(segments, key=lambda s: str(s.get("id"))):
        sid = s.get("id")
        coords = [(float(x), float(y)) for (x, y) in (s.get("coords") or [])]
        if len(coords) < 2:
            flags.append({"feature_id": sid, "code": "dangling_end",
                          "detail": "segment has fewer than 2 coordinates"})
            continue
        cum = _cum_chain(coords)
        sg = {"id": sid, "cls": str(s.get("cls")),
              "size": float(s.get("size") or 0), "coords": coords, "cum": cum,
              "cuts": [[0.0, _node(coords[0])], [cum[-1], _node(coords[-1])]]}
        segs.append(sg)
        seg_meta[sid] = {"cls": sg["cls"], "size": sg["size"],
                         "attrs": dict(s.get("attrs") or {})}

    # -- spatial index over segment EDGES (grid buckets) so the tap-projection
    # passes below are ~O(points) instead of O(points x segments).  Cell size =
    # the largest tap tolerance, so a 3x3 neighbourhood is guaranteed to contain
    # every edge within tolerance of a query point.  The min-by-(d, str(id),
    # chain) selection is order-independent, so candidate order never changes the
    # result -> identical output + determinism preserved vs the brute-force scan.
    _cell = (max([float(tap_m), float(cable_tap_m), 1e-9]
                 + list(role_tap_m.values())) * DEG_PER_M)
    _edge_grid = {}

    def _cix(xy):
        return (int(math.floor(xy[0] / _cell)), int(math.floor(xy[1] / _cell)))

    for _si, _sg in enumerate(segs):
        _co = _sg["coords"]
        for _i in range(1, len(_co)):
            (ax, ay), (bx, by) = _co[_i - 1], _co[_i]
            cx0, cy0 = _cix((ax, ay))
            cx1, cy1 = _cix((bx, by))
            for _cx in range(min(cx0, cx1), max(cx0, cx1) + 1):
                for _cy in range(min(cy0, cy1), max(cy0, cy1) + 1):
                    _edge_grid.setdefault((_cx, _cy), []).append((_si, _i))

    def _cand_edges(xy):
        cx, cy = _cix(xy)
        out = []
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                out.extend(_edge_grid.get((cx + dx, cy + dy), ()))
        return out

    # -- 2 + 3. points: tap-by-projection.  A device may sit where a smaller
    # cable meets a bigger run (STS = drop end + mid-span DISTRIBUTION tap),
    # so we attach to the nearest segment of EACH class within tap_m and
    # fuse all of those attachments into ONE node.
    points_d = {}
    point_node = {}
    for p in sorted(points, key=lambda p: str(p.get("id"))):
        pid = p.get("id")
        xy = (float(p["xy"][0]), float(p["xy"][1]))
        p_role = str(p.get("role"))
        points_d[pid] = {"id": pid, "role": p_role, "xy": xy,
                         "attrs": dict(p.get("attrs") or {})}
        p_tap = role_tap_m.get(p_role, tap_m)   # per-role attach distance
        best_per_seg = {}  # seg_index -> ((d, str(sid), chain), seg_index, foot)
        for si, i in _cand_edges(xy):
            sg = segs[si]
            coords, cum = sg["coords"], sg["cum"]
            foot, t, d = project_point_to_segment(xy, coords[i - 1], coords[i])
            if d > p_tap:
                continue
            chain = cum[i - 1] + (cum[i] - cum[i - 1]) * t
            cand = ((d, str(sg["id"]), chain), si, foot)
            prev = best_per_seg.get(si)
            if prev is None or cand[0] < prev[0]:
                best_per_seg[si] = cand
        best_per_cls = {}  # cls -> ((d, str(sid), chain), seg_index, foot)
        for si, cand in best_per_seg.items():
            cls = segs[si]["cls"]
            prev = best_per_cls.get(cls)
            if prev is None or cand[0] < prev[0]:
                best_per_cls[cls] = cand
        if not best_per_cls:
            point_node[pid] = None
            flags.append({"feature_id": pid, "code": "point_off_network",
                          "detail": "no segment within %.1f m" % float(p_tap)})
            continue
        # primary attach = overall nearest; reuse an existing cut on that
        # segment within snap_m (endpoint attach), else split at a new node
        primary_cls = min(best_per_cls, key=lambda c: best_per_cls[c][0])
        (_d, _sidstr, chain), si, foot = best_per_cls[primary_cls]
        sg = segs[si]
        near = min(sg["cuts"], key=lambda c: (abs(c[0] - chain), str(c[1])))
        if abs(near[0] - chain) <= snap_m:
            node = near[1]                   # endpoint / existing-tap attach
        else:
            node = _node(foot)               # interior mid-span tap: split here
            sg["cuts"].append([chain, node])
        point_node[pid] = node
        # secondary taps: fuse the same node onto every CO-NEAREST segment —
        # each class's nearest, plus any segment within snap_m of its class
        # minimum.  A junction device sits where several cables MEET (an STS
        # at the joint of street-span A and street-span B is ~0 m from BOTH);
        # the old nearest-PER-CLASS rule fused only one of them, so same-class
        # chains fragmented at every device junction.  The snap_m window keeps
        # it tight: a genuinely distinct cable a few metres away stays free.
        dmin_cls = {c: best_per_cls[c][0][0] for c in best_per_cls}
        for si2 in sorted(best_per_seg, key=lambda s: str(segs[s]["id"])):
            (d2, _s2, chain2), _si2, _foot2 = best_per_seg[si2]
            if si2 == si:
                continue                     # the primary attach, already cut
            sg2 = segs[si2]
            if d2 > dmin_cls[sg2["cls"]] + snap_m:
                continue                     # not co-nearest for its class
            near2 = min(sg2["cuts"], key=lambda c: (abs(c[0] - chain2), str(c[1])))
            if near2[1] == node and abs(near2[0] - chain2) <= snap_m:
                continue                     # already fused here
            sg2["cuts"].append([chain2, node])

    # -- 2b. cable-endpoint mid-span tap (cable-to-cable T-junctions).
    # Mirror the point mid-span tap for a spur cable's FREE endpoint.  Both
    # the "dangling" decision and every projection use the ORIGINAL endpoint
    # positions / segment geometry captured in this SNAPSHOT (coords + cuts
    # never feed the projection), so mutating a target's cuts mid-loop cannot
    # change any other decision — the pass is order-independent.
    _attached = {n for n in point_node.values() if n is not None}
    end_nodes = {}                    # seg index -> [start_node, end_node]
    node_ends = {}                    # node key -> set(seg index) (snapshot)
    for si, sg in enumerate(segs):
        sk = snap_key(sg["coords"][0], snap_m)
        ek = snap_key(sg["coords"][-1], snap_m)
        end_nodes[si] = [sk, ek]
        node_ends.setdefault(sk, set()).add(si)
        node_ends.setdefault(ek, set()).add(si)

    def _rewrite_end(sg, endpoint_chain, old_key, new_key):
        for c in sg["cuts"]:
            if c[1] == old_key and abs(c[0] - endpoint_chain) <= 1e-9:
                c[1] = new_key

    for si in range(len(segs)):       # segs already sorted by str(id)
        sg = segs[si]
        for which in (0, 1):
            node_key = end_nodes[si][which]
            # dangling = endpoint not shared with another segment's endpoint
            # and carrying no attached device (both from the snapshot)
            if len(node_ends.get(node_key, ())) > 1 or node_key in _attached:
                continue
            end_xy = sg["coords"][0] if which == 0 else sg["coords"][-1]
            best = None               # ((d, str(id), chain), target index, foot)
            for ti, i in _cand_edges(end_xy):
                if ti == si:
                    continue
                tg = segs[ti]
                if tg["size"] < sg["size"]:
                    continue          # bigger cable never taps a smaller one
                tcoords, tcum = tg["coords"], tg["cum"]
                foot, t, d = project_point_to_segment(
                    end_xy, tcoords[i - 1], tcoords[i])
                if d > cable_tap_m:
                    continue
                chain = tcum[i - 1] + (tcum[i] - tcum[i - 1]) * t
                cand = ((d, str(tg["id"]), chain), ti, foot)
                if best is None or cand[0] < best[0]:
                    best = cand
            if best is None:
                continue
            (_d, _sid, tchain), ti, _foot = best
            tg = segs[ti]
            near = min(tg["cuts"], key=lambda c: (abs(c[0] - tchain), str(c[1])))
            other_key = end_nodes[si][1 - which]
            endpoint_chain = 0.0 if which == 0 else sg["cum"][-1]
            if abs(near[0] - tchain) <= snap_m:
                shared = near[1]      # tap at target endpoint / prior cut
                if shared == node_key or shared == other_key:
                    continue          # already connected / would self-loop spur
                _rewrite_end(sg, endpoint_chain, node_key, shared)
                end_nodes[si][which] = shared
            else:                     # interior: split target at the SPUR node
                tg["cuts"].append([tchain, node_key])

    # nodes with at least one attached device — a chain of DIFFERENT segments
    # must not merge through a device (e.g. two drops fanning from one STS)
    device_nodes = {n for n in point_node.values() if n is not None}

    # -- emit edge pieces between consecutive cuts
    edges = []
    adj = {}
    for sg in segs:
        cuts = sorted(sg["cuts"], key=lambda c: (c[0], str(c[1])))
        cleaned = []
        for c in cuts:
            if cleaned and c[1] == cleaned[-1][1] and (c[0] - cleaned[-1][0]) <= snap_m:
                continue
            cleaned.append(c)
        for (c0, u), (c1, v) in zip(cleaned, cleaned[1:]):
            if u == v and (c1 - c0) <= snap_m:
                continue          # snapping artefact; a u!=v jumper is kept
                                  # even at ~0 length (connectivity matters)
            e = Edge(u=u, v=v, seg_id=sg["id"], cls=sg["cls"],
                     coords=_slice(sg["coords"], sg["cum"], c0, c1),
                     length_m=c1 - c0, chain0=c0, chain1=c1)
            idx = len(edges)
            edges.append(e)
            adj.setdefault(u, []).append(idx)
            if v != u:
                adj.setdefault(v, []).append(idx)

    # -- merge chained same-class degree-2 pieces into logical Runs
    runs = _merge_runs(edges, seg_meta, device_nodes, flags)

    runs_at_node = {}
    for fid in sorted(runs, key=str):
        seen = set()
        for n in runs[fid].nodes:
            if n in seen:
                continue
            seen.add(n)
            runs_at_node.setdefault(n, []).append(fid)
    points_at_node = {}
    for pid in sorted(point_node, key=str):
        n = point_node[pid]
        if n is not None:
            points_at_node.setdefault(n, []).append(pid)

    return Graph(
        nodes=nodes, edges=edges,
        adj={k: tuple(v) for k, v in adj.items()},
        segments=seg_meta, points=points_d, point_node=point_node,
        runs=runs,
        runs_at_node={k: tuple(v) for k, v in runs_at_node.items()},
        points_at_node={k: tuple(v) for k, v in points_at_node.items()},
        flags=flags, snap_m=float(snap_m), tap_m=float(tap_m),
    )


def _merge_runs(edges, seg_meta, device_nodes, flags):
    """Chain same-class edges through pass-through nodes into logical Runs.

    Continuation is INCOMING-EDGE aware so a cable-to-cable T-junction never
    fragments the trunk: arriving at a node along a piece of segment S,
    * if another edge of the SAME source segment S leaves the node, the run
      continues along it — a trunk stays ONE run even where a spur T-juncts
      into its middle (degree 3+) or a mid-span tap splits it (degree 2);
    * else, only when exactly two class edges meet with NO attached device do
      DIFFERENT segments chain (plain pole-to-pole pieces of one run).
    Two different segments meeting at a device (drops fanning off one STS), or
    a branch (3+ different segments), stay separate runs.  Closed rings are
    detected and flagged loop_closed (fatal).
    """
    by_cls = {}
    for i, e in enumerate(edges):
        by_cls.setdefault(e.cls, []).append(i)

    runs = {}
    for cls in sorted(by_cls):
        idxs = by_cls[cls]
        deg = {}
        for i in idxs:
            e = edges[i]
            deg.setdefault(e.u, []).append(i)
            if e.v != e.u:
                deg.setdefault(e.v, []).append(i)
        used = set()

        def _next_edge(node, in_eidx):
            """Edge continuing in_eidx's logical run through node, or None."""
            lst = deg.get(node, ())
            in_seg = edges[in_eidx].seg_id
            same = sorted(j for j in lst
                          if j != in_eidx and edges[j].seg_id == in_seg)
            if same:
                return same[0] if len(same) == 1 else None
            if len(lst) == 2 and node not in device_nodes:
                other = [j for j in lst if j != in_eidx]
                return other[0] if other else None
            return None

        def _walk_from(node, eidx):
            path = [eidx]
            used.add(eidx)
            e = edges[eidx]
            cur = e.v if e.u == node else e.u
            while True:
                j = _next_edge(cur, path[-1])
                if j is None or j in used:
                    break
                used.add(j)
                path.append(j)
                e = edges[j]
                cur = e.v if e.u == cur else e.u
            return path, cur

        chains = []
        for eidx in idxs:                     # start at run boundaries
            if eidx in used:
                continue
            e = edges[eidx]
            if _next_edge(e.u, eidx) is None:
                start = e.u
            elif _next_edge(e.v, eidx) is None:
                start = e.v
            else:
                continue                      # interior edge; started from an end
            chains.append((start, _walk_from(start, eidx)[0], False))
        for eidx in idxs:                     # leftovers = closed rings
            if eidx in used:
                continue
            e = edges[eidx]
            start = min(e.u, e.v)
            chains.append((start, _walk_from(start, eidx)[0], True))

        for start, path, is_ring in chains:
            node_seq = [start]
            chain_m = [0.0]
            members = []
            cur = start
            for j in path:
                e = edges[j]
                nxt = e.v if e.u == cur else e.u
                node_seq.append(nxt)
                chain_m.append(chain_m[-1] + e.length_m)
                members.append(e.seg_id)
                cur = nxt
            uniq = sorted({str(m): m for m in members}.items())
            member_ids = tuple(m for _s, m in uniq)
            fid = member_ids[0]
            while fid in runs:                # same segment split across runs
                fid = ("run", fid) if not isinstance(fid, tuple) else fid + (len(runs),)
            node_chain = {}
            for n, c in zip(node_seq, chain_m):
                node_chain.setdefault(n, c)
            runs[fid] = Run(
                fid=fid, cls=cls, members=member_ids,
                size=max(seg_meta[m]["size"] for m in member_ids),
                nodes=tuple(node_seq), node_chain=node_chain,
                edge_idxs=tuple(path), length_m=chain_m[-1], is_ring=is_ring,
            )
            if len(member_ids) > 1:
                flags.append({"feature_id": fid, "code": "unmerged_segments",
                              "detail": "merged %d chained %s segments into one "
                                        "run: %s" % (len(member_ids), cls,
                                                     [str(m) for m in member_ids])})
            if is_ring:
                flags.append({"feature_id": fid, "code": "loop_closed",
                              "detail": "%s run forms a closed ring" % cls})
    return runs


# ---------------------------------------------------------------------------
# traverse
# ---------------------------------------------------------------------------

def traverse(graph, roots, config):
    """DFS-preorder walk of the graph per root, driven by the hierarchy config.

    config is duck-typed (numbering.HierarchyConfig fits): it needs .levels,
    each level exposing .name, .cls_or_role, .parent and optionally .kind
    ("point" | "cable" | "auto" — auto is inferred from the data).

    Children of a feature are sorted by
        (chainage_along_parent, -cable_size_or_0, str(child_id))
    exactly like feeder_walk's spur ordering, one level deeper.  Root order =
    the CALLER's order (duplicates flagged + skipped), so multi-root walks
    (POP first, then each island's splitter) come out in the intended
    sequence.

    Returns (walks, anomalies).  Anomalies FLAG, never mutate: fatally
    flagged features are still walked but item["flagged"] is True so
    numbering NULLs them.
    """
    levels = list(config.levels)

    def _pnames(lv):
        """Parent level names as a tuple (multi-parent / self-branch aware)."""
        f = getattr(lv, "parent_names", None)
        if callable(f):
            return f()
        p = getattr(lv, "parent", None)
        if p is None:
            return ()
        return tuple(p) if isinstance(p, (list, tuple)) else (p,)

    # A level is a child of every parent it names (including itself when it
    # self-branches, e.g. distribution -> sub-distribution branch).
    kids = {lv.name: [c for c in levels if lv.name in _pnames(c)]
            for lv in levels}
    seg_classes = {m["cls"] for m in graph.segments.values()}

    def _kind(lv):
        k = getattr(lv, "kind", "auto") or "auto"
        if k in ("point", "cable"):
            return k
        return "cable" if lv.cls_or_role in seg_classes else "point"

    anomalies = [dict(f) for f in graph.flags]
    walks = []
    visited = set()
    # Roots are walked in the CALLER's order (first occurrence wins) — the
    # caller decides subtree precedence, e.g. the POP first, then FTS_001..
    # FTS_055 so every disconnected PON island is walked in splitter order.
    # Determinism holds because the caller passes an explicit sequence; the
    # old sorted(key=str) put FTS:10 before FTS:2 and is gone on purpose.
    _seen_roots = set()
    roots_sorted = []
    for _r in roots:
        if _r in _seen_roots:
            anomalies.append({"feature_id": _r, "code": "pop_count",
                              "detail": "duplicate root"})
            continue
        _seen_roots.add(_r)
        roots_sorted.append(_r)
    if not roots_sorted:
        anomalies.append({"feature_id": None, "code": "pop_count",
                          "detail": "no roots supplied"})
    root_levels = [lv for lv in levels if not _pnames(lv)]

    for rid in roots_sorted:
        pt = graph.points.get(rid)
        if pt is None:
            anomalies.append({"feature_id": rid, "code": "pop_count",
                              "detail": "root id not found among points"})
            continue
        if rid in visited:
            anomalies.append({"feature_id": rid, "code": "pop_count",
                              "detail": "duplicate root"})
            continue
        lv = next((l for l in root_levels if l.cls_or_role == pt["role"]),
                  root_levels[0] if root_levels else None)
        if lv is None:
            anomalies.append({"feature_id": rid, "code": "pop_count",
                              "detail": "config has no root level"})
            continue
        items = []
        root_zone = pt["attrs"].get("zone")

        def _visit_point(pid, plv, parent_fid, chain, depth, pzone):
            visited.add(pid)
            p = graph.points[pid]
            zone = p["attrs"].get("zone", pzone)
            items.append({"feature_id": pid, "level": plv.name, "kind": "point",
                          "parent_id": parent_fid, "order": len(items),
                          "chainage": chain, "members": None, "flagged": False,
                          "xy": p["xy"], "attrs": dict(p["attrs"]),
                          "zone": zone})
            if root_zone is not None and pid != rid:
                z = p["attrs"].get("zone")
                if z is not None and z != root_zone:
                    anomalies.append({"feature_id": pid, "code": "zone_mismatch",
                                      "detail": "zone %r != root zone %r"
                                                % (z, root_zone)})
            node = graph.point_node.get(pid)
            if node is None or depth > _MAX_DEPTH:
                return
            cands = []
            for child_lv in kids.get(plv.name, ()):
                if _kind(child_lv) == "cable":
                    for fid2 in graph.runs_at_node.get(node, ()):
                        if fid2 in visited:
                            continue
                        r2 = graph.runs[fid2]
                        if r2.cls != child_lv.cls_or_role:
                            continue
                        cands.append((0.0, -r2.size, str(fid2), "cable",
                                      fid2, child_lv, node))
                else:
                    for pid2 in graph.points_at_node.get(node, ()):
                        if pid2 in visited:
                            continue
                        if graph.points[pid2]["role"] != child_lv.cls_or_role:
                            continue
                        cands.append((0.0, 0.0, str(pid2), "point",
                                      pid2, child_lv, node))
            _dispatch(cands, pid, depth, zone)

        def _visit_run(fid, rlv, parent_fid, entry_node, chain, depth, pzone):
            run = graph.runs[fid]
            visited.add(fid)
            meta = graph.segments.get(run.members[0], {})
            items.append({"feature_id": fid, "level": rlv.name, "kind": "cable",
                          "parent_id": parent_fid, "order": len(items),
                          "chainage": chain, "members": list(run.members),
                          "flagged": False,
                          "xy": graph.nodes.get(entry_node),
                          "attrs": dict(meta.get("attrs") or {}),
                          "zone": pzone})
            if depth > _MAX_DEPTH:
                return
            entry_chain = run.node_chain.get(entry_node, 0.0)
            cands = []
            seen_nodes = set()
            for node in run.nodes:
                if node in seen_nodes:
                    continue
                seen_nodes.add(node)
                ch = abs(run.node_chain[node] - entry_chain)
                for child_lv in kids.get(rlv.name, ()):
                    if _kind(child_lv) == "point":
                        for pid2 in graph.points_at_node.get(node, ()):
                            if pid2 in visited:
                                continue
                            if graph.points[pid2]["role"] != child_lv.cls_or_role:
                                continue
                            cands.append((ch, 0.0, str(pid2), "point",
                                          pid2, child_lv, node))
                    else:
                        for fid2 in graph.runs_at_node.get(node, ()):
                            if fid2 == fid or fid2 in visited:
                                continue
                            r2 = graph.runs[fid2]
                            if r2.cls != child_lv.cls_or_role:
                                continue
                            cands.append((ch, -r2.size, str(fid2), "cable",
                                          fid2, child_lv, node))
            _dispatch(cands, fid, depth, pzone)
            for tnode in (run.nodes[0], run.nodes[-1]):
                if tnode == entry_node:
                    continue
                if len(graph.adj.get(tnode, ())) == 1 \
                        and not graph.points_at_node.get(tnode):
                    anomalies.append({"feature_id": fid, "code": "dangling_end",
                                      "detail": "far end has no device or "
                                                "continuation"})

        def _dispatch(cands, parent_fid, depth, pzone):
            for c in sorted(cands, key=lambda c: (c[0], c[1], c[2])):
                ch, _negsize, _sid, ckind, cid, child_lv, node = c
                if cid in visited:
                    continue
                if ckind == "point":
                    _visit_point(cid, child_lv, parent_fid, ch, depth + 1, pzone)
                else:
                    _visit_run(cid, child_lv, parent_fid, node, ch,
                               depth + 1, pzone)

        _visit_point(rid, lv, None, 0.0, 0, None)
        walks.append({"root": rid, "items": items})

    # unreachable: configured-level features never visited by any walk
    point_roles = {lv.cls_or_role for lv in levels if _kind(lv) == "point"}
    cable_classes = {lv.cls_or_role for lv in levels if _kind(lv) == "cable"}
    for pid in sorted(graph.points, key=str):
        if pid not in visited and graph.points[pid]["role"] in point_roles:
            anomalies.append({"feature_id": pid, "code": "unreachable",
                              "detail": "point never reached from any root"})
    for fid in sorted(graph.runs, key=str):
        run = graph.runs[fid]
        if fid not in visited and run.cls in cable_classes:
            anomalies.append({"feature_id": fid, "code": "unreachable",
                              "detail": "run never reached from any root"})
            for m in run.members:
                if str(m) != str(fid):
                    anomalies.append({"feature_id": m, "code": "unreachable",
                                      "detail": "member of unreachable run %r"
                                                % (fid,)})

    fatal = {a["feature_id"] for a in anomalies if a["code"] in FATAL_CODES}
    for w in walks:
        for it in w["items"]:
            it["flagged"] = (it["feature_id"] in fatal
                             or bool(set(it.get("members") or ()) & fatal))
    return walks, anomalies
