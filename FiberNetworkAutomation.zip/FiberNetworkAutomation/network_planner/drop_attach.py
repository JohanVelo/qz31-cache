"""Attach drop cables to homes that have none. Ticket #140 (Luke, 2026-07-28).

# claude:boq-impact ADDS DROP CABLES — and that is the point of the ticket: a home
# with no drop is not connected. Each attachment adds one drop-cable feature and
# raises one splitter's drop_count by one, so the BoQ gains that many drops. The
# count is previewed before anything is written and reported after. This tool is
# NEVER run automatically and is refused on a layer that is open for editing.
#
# claude:intent MUTATE — user asked: "will you please build a tool that picks up on
# and demand points that have no drop cables attached to them and then make it that
# drop cables can be attached by picking from which splitter they would be feeding
# from" (ticket #140), and then "build everything, taste everything, do everything".
# Plan: find the unserved homes, propose a splitter for each, show every proposed
# cable, and write only what the operator confirms — after a backup that has been
# re-opened and read back.
#
# claude:approved-destructive — writing is gated on pon_merge.backup_is_usable, the
# same gate the Merge and Reshaper tools use: the backup must exist on disk AND
# re-open as a readable dataset before one feature is added.

EVERY RULE BELOW WAS MEASURED ON LUKE'S REAL DATA, NOT ASSUMED
--------------------------------------------------------------
**Reach.** Existing drop lengths, per network::

    BF   n=5906   median 27.6 m   p95 59.8 m   max 133.8 m
    LK   n=5226   median 28.8 m   p95 63.7 m   max 172.6 m
    MK   n=4978   median 32.1 m   p95 67.2 m   max 155.0 m

So there is no single correct maximum. :func:`default_reach_m` takes the layer's
OWN 95th percentile and rounds up, which lands near 60-70 m on all three — a new
drop that would be longer than 95% of the drops already in that network is worth
the operator seeing, not silently allowing.

**Capacity.** These are 8-way splitters, but the accepted build already runs some
of them past 8: measured load (by geometry) tops out at 11 on Benfarm, 10 on
Lulekani and 10 on Makhushane, with 11 / 4 / 3 splitters respectively above 8.
A rule must be benchmarked against the build we already accept before a deviation
is called a defect — so this tool does NOT refuse to run, does NOT "fix" those,
and simply never makes one worse: a splitter at or over capacity is skipped when
choosing, and the over-capacity ones are reported.

**Stored counts are trustworthy here.** ``drop_count`` matched the geometric load
exactly on all three networks (same min, median and max), so it is updated rather
than recomputed from scratch — but the load this tool works from is always
measured from geometry, because geometry is the arbiter.

**Schema differs per network, so the writer mirrors the TARGET layer.**
``BF_Drop Cables`` has two columns (``cable_id``, ``Name``); LK and MK have nine
(``group_id``, ``demand_id``, ``fiber_coun``, ``fiber_size``, ``via_span``,
``cable_leng``, ``zone_id``, ``length``). A fixed field list would fail on one and
punch holes in the other. ``cable_leng`` is stored in DEGREES on LK/MK — the
layer's own units — and is written the same way rather than "corrected" to metres.

**Labels are copied, never invented.** Benfarm's drops read
``HT_MMB_Z1_DR1_Aeriel`` — including their spelling of "Aerial". The pattern is
derived from the existing values and the sequence continued. If it cannot be
derived confidently the label is left EMPTY and reported, because a label composed
with a hole in it looks finished and is worse than an obvious blank.
"""

import re

from . import field_names as vf_fields

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

#: A drop end is either coincident with its home or absent — measured, the served
#: count is identical anywhere from 0.01 m to 10 m.
SNAP_TOL_M = 1.0

#: Splitters are 1:8. Used to choose, never to refuse — see the module docstring.
DEFAULT_CAPACITY = 8

#: Bounds on the derived reach, so a network with freak outliers cannot produce an
#: absurd default in either direction.
REACH_MIN_M = 40.0
REACH_MAX_M = 150.0

_DR_RE = re.compile(r"^(?P<head>.*?)(?P<num>\d+)(?P<tail>[^0-9]*)$")


def _measurer(layer):
    """True-metre measurer. A bare QgsDistanceArea measures in degrees."""
    from qgis.core import QgsCoordinateTransformContext, QgsDistanceArea
    da = QgsDistanceArea()
    try:
        da.setSourceCrs(layer.crs(), QgsCoordinateTransformContext())
        da.setEllipsoid(layer.crs().ellipsoidAcronym() or "WGS84")
    except Exception:
        try:
            da.setEllipsoid("WGS84")
        except Exception:
            _swallowed_note()
    return da


def _parts(geom):
    try:
        return geom.asMultiPolyline() or [geom.asPolyline()]
    except Exception:
        return []


def drop_lengths_m(drop_layer):
    """Straight-line length of every existing drop, in true metres."""
    da = _measurer(drop_layer)
    out = []
    try:
        for f in drop_layer.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            for line in _parts(g):
                if len(line) >= 2:
                    try:
                        out.append(da.measureLine(line[0], line[-1]))
                    except Exception:
                        _swallowed_note(); continue
    except Exception:
        _swallowed_note()
    return out


def reach_from_lengths(lengths):
    """The 95th-percentile drop length, rounded to 5 m and clamped. Pure.

    Split out from :func:`default_reach_m` so the rule can be property-tested
    without a layer: it decides how far this tool is willing to run a new cable,
    and a silent change to it would quietly re-scope every proposal.
    """
    lens = sorted(v for v in lengths if v > 0)
    if not lens:
        return 75.0
    p95 = lens[min(len(lens) - 1, int(len(lens) * 0.95))]
    rounded = 5.0 * round((p95 + 2.5) / 5.0)
    return max(REACH_MIN_M, min(REACH_MAX_M, rounded))


def default_reach_m(drop_layer):
    """The layer's own 95th-percentile drop length, rounded up to 5 m."""
    return reach_from_lengths(drop_lengths_m(drop_layer))


def splitter_loads(splitter_layer, drop_layer, tol_m=SNAP_TOL_M):
    """{splitter fid: drops currently landing on it} — measured from GEOMETRY.

    The stored ``drop_count`` agreed with this exactly on all three of Luke's
    networks, but geometry is the arbiter: a stale count is precisely what made a
    PON claim splitters it no longer held.
    """
    from qgis.core import QgsFeature, QgsGeometry, QgsPointXY, QgsSpatialIndex

    pts, order = [], []
    try:
        for f in splitter_layer.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            try:
                p = g.asPoint() if not g.isMultipart() else g.centroid().asPoint()
            except Exception:
                _swallowed_note(); continue
            pts.append(QgsPointXY(p))
            order.append(f.id())
    except Exception:
        return {}
    if not pts:
        return {}

    idx = QgsSpatialIndex()
    for i, p in enumerate(pts):
        ft = QgsFeature(i)
        ft.setGeometry(QgsGeometry.fromPointXY(p))
        idx.addFeature(ft)
    da = _measurer(splitter_layer)

    loads = {fid: 0 for fid in order}
    try:
        for f in drop_layer.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            for line in _parts(g):
                if len(line) < 2:
                    continue
                for end in (line[0], line[-1]):
                    best, bd = None, float("inf")
                    for i in idx.nearestNeighbor(QgsPointXY(end), 4):
                        try:
                            d = da.measureLine(QgsPointXY(end), pts[i])
                        except Exception:
                            _swallowed_note(); continue
                        if d < bd:
                            best, bd = i, d
                    if best is not None and bd <= tol_m:
                        loads[order[best]] += 1
    except Exception:
        _swallowed_note()
    return loads


def _modal_values(layer, skip):
    """Most common non-null value per field — the layer's own convention.

    Copying what is already there beats inventing a value: it reproduces the
    client's spelling, their fibre size, their via_span default, and their gaps.
    """
    from collections import Counter
    counters = {}
    names = [f.name() for f in layer.fields() if f.name() not in skip]
    try:
        for f in layer.getFeatures():
            for n in names:
                try:
                    v = f[n]
                except Exception:
                    _swallowed_note(); continue
                if v is not None and v != "":
                    counters.setdefault(n, Counter())[str(v)] = \
                        counters.setdefault(n, Counter())[str(v)] + 1
    except Exception:
        _swallowed_note()
    out = {}
    for n, c in counters.items():
        if not c:
            continue
        best = c.most_common(1)[0]
        # Only treat it as a convention when it genuinely dominates; a field with
        # 5,906 distinct values is an identifier, not a default.
        if best[1] >= 2:
            out[n] = best[0]
    return out


def _next_int(layer, field):
    hi = 0
    try:
        i = layer.fields().indexOf(field)
        if i < 0:
            return 1
        for f in layer.getFeatures():
            try:
                v = int(f[field])
            except (TypeError, ValueError):
                continue
            hi = max(hi, v)
    except Exception:
        _swallowed_note()
    return hi + 1


def _label_pattern(drop_layer, field):
    """(head, tail, next_number) derived from existing labels, or None.

    Benfarm reads ``HT_MMB_Z1_DR1_Aeriel``: head ``HT_MMB_Z1_DR``, tail
    ``_Aeriel``. Only accepted when one head/tail pair actually dominates the
    layer — otherwise the labels are not following a single scheme and guessing
    one would stamp a wrong name onto real cable.
    """
    from collections import Counter
    pairs, highest = Counter(), {}
    try:
        idx = drop_layer.fields().indexOf(field)
        if idx < 0:
            return None
        for f in drop_layer.getFeatures():
            v = f[field]
            if v in (None, ""):
                continue
            m = _DR_RE.match(str(v))
            if not m:
                continue
            key = (m.group("head"), m.group("tail"))
            pairs[key] += 1
            n = int(m.group("num"))
            highest[key] = max(highest.get(key, 0), n)
    except Exception:
        return None
    if not pairs:
        return None
    (head, tail), count = pairs.most_common(1)[0]
    total = sum(pairs.values())
    if total == 0 or count / float(total) < 0.80:
        return None                      # no single dominant scheme — stay blank
    return head, tail, highest.get((head, tail), 0) + 1


def plan_attachments(demand_layer, unserved, splitter_layer, drop_layer,
                     capacity=DEFAULT_CAPACITY, reach_m=None,
                     chosen=None):
    """Propose one drop per unserved home. ``(proposals, stats)``. Writes nothing.

    ``unserved`` is the ``(fid, point, distance, label)`` rows from
    :func:`connectivity_scan.scan_unserved`. ``chosen`` optionally maps
    ``{demand_fid: splitter_fid}`` so the operator can override any pick.
    """
    from qgis.core import QgsFeature, QgsGeometry, QgsPointXY, QgsSpatialIndex

    stats = {"proposed": 0, "no_splitter": 0, "over_capacity_existing": 0,
             "reach_m": reach_m, "capacity": capacity, "labelled": 0,
             "unlabelled": 0, "reason": "", "splitters_touched": 0}
    if not unserved:
        stats["reason"] = "no unserved homes to attach"
        return [], stats
    if splitter_layer is None or drop_layer is None:
        stats["reason"] = "pick both a splitter layer and a drop-cable layer"
        return [], stats

    if reach_m is None:
        reach_m = default_reach_m(drop_layer)
        stats["reach_m"] = reach_m

    loads = splitter_loads(splitter_layer, drop_layer)
    stats["over_capacity_existing"] = sum(1 for v in loads.values() if v > capacity)

    sp_pts, sp_ids, sp_feat = [], [], {}
    try:
        for f in splitter_layer.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            try:
                p = g.asPoint() if not g.isMultipart() else g.centroid().asPoint()
            except Exception:
                _swallowed_note(); continue
            sp_pts.append(QgsPointXY(p))
            sp_ids.append(f.id())
            sp_feat[f.id()] = f
    except Exception:
        _swallowed_note()
    if not sp_pts:
        stats["reason"] = "the splitter layer holds no usable points"
        return [], stats

    idx = QgsSpatialIndex()
    for i, p in enumerate(sp_pts):
        ft = QgsFeature(i)
        ft.setGeometry(QgsGeometry.fromPointXY(p))
        idx.addFeature(ft)
    da = _measurer(demand_layer)

    demand_by_fid = {}
    try:
        for f in demand_layer.getFeatures():
            demand_by_fid[f.id()] = f
    except Exception:
        _swallowed_note()

    # Field plan for the TARGET layer — mirrors whatever it actually has.
    fields = drop_layer.fields()
    names = [f.name() for f in fields]
    id_field = "cable_id" if "cable_id" in names else None
    label_field = None
    for cand in ("Name", "name", "label", "Label"):
        if cand in names:
            label_field = cand
            break
    identifiers = {n for n in (id_field, label_field, "demand_id", "group_id",
                               "zone_id", "cable_leng", "length") if n}
    template = _modal_values(drop_layer, skip=identifiers)
    next_id = _next_int(drop_layer, id_field) if id_field else None
    pattern = _label_pattern(drop_layer, label_field) if label_field else None

    sp_group = vf_fields.resolve(splitter_layer, vf_fields.SPLITTER_ID)
    sp_pon = vf_fields.resolve(splitter_layer, vf_fields.PON_NUM)
    dem_id_field = None
    for cand in ("demand_id", "id", "ID"):
        try:
            if demand_layer.fields().indexOf(cand) >= 0:
                dem_id_field = cand
                break
        except Exception:
            _swallowed_note()

    working = dict(loads)
    proposals = []
    seq = 0
    for fid, pt, _d, label in unserved:
        pick = None
        forced = chosen.get(fid) if chosen else None
        if forced is not None and forced in sp_feat:
            pick = forced
        else:
            best, bd = None, float("inf")
            for i in idx.nearestNeighbor(pt, 24):
                sid = sp_ids[i]
                if working.get(sid, 0) >= capacity:
                    continue          # never make a full splitter fuller
                try:
                    dist = da.measureLine(pt, sp_pts[i])
                except Exception:
                    _swallowed_note(); continue
                if dist <= reach_m and dist < bd:
                    best, bd = sid, dist
            pick = best
        if pick is None:
            stats["no_splitter"] += 1
            continue

        sp_pt = sp_pts[sp_ids.index(pick)]
        try:
            length_m = da.measureLine(pt, sp_pt)
        except Exception:
            length_m = 0.0

        attrs = dict(template)
        if id_field and next_id is not None:
            attrs[id_field] = next_id + seq
        if label_field:
            if pattern:
                head, tail, start = pattern
                attrs[label_field] = f"{head}{start + seq}{tail}"
                stats["labelled"] += 1
            else:
                attrs[label_field] = None
                stats["unlabelled"] += 1
        sf = sp_feat[pick]
        if "group_id" in names and sp_group:
            try:
                attrs["group_id"] = sf[sp_group]
            except Exception:
                _swallowed_note()
        if "zone_id" in names and sp_pon:
            try:
                attrs["zone_id"] = sf[sp_pon]
            except Exception:
                _swallowed_note()
        if "demand_id" in names:
            dv = fid
            if dem_id_field:
                try:
                    dv = demand_by_fid[fid][dem_id_field]
                except Exception:
                    dv = fid
            attrs["demand_id"] = dv
        if "cable_leng" in names:
            # DEGREES — the layer's own convention (0.00065 on LK). Writing metres
            # here would silently corrupt every downstream length sum.
            attrs["cable_leng"] = ((pt.x() - sp_pt.x()) ** 2
                                   + (pt.y() - sp_pt.y()) ** 2) ** 0.5

        proposals.append({
            "demand_fid": fid,
            "demand_label": label,
            "demand_pt": pt,
            "splitter_fid": pick,
            "splitter_pt": sp_pt,
            "length_m": length_m,
            "attrs": attrs,
        })
        working[pick] = working.get(pick, 0) + 1
        seq += 1

    stats["proposed"] = len(proposals)
    stats["splitters_touched"] = len({p["splitter_fid"] for p in proposals})
    if not proposals and not stats["reason"]:
        stats["reason"] = (
            f"no splitter with spare capacity is within {reach_m:.0f} m of any "
            "of these homes")
    return proposals, stats


def apply_attachments(drop_layer, splitter_layer, proposals, backup_path,
                      update_counts=True):
    """Write the proposed drops. ``(ok, message, stats)``.

    ``backup_path`` must point at a backup that ALREADY EXISTS and re-opens — an
    argument rather than a convention so it cannot be forgotten.
    """
    from qgis.core import QgsFeature, QgsGeometry

    from . import pon_merge

    stats = {"written": 0, "counts_updated": 0, "verified": 0, "reason": ""}
    if not proposals:
        return False, "Nothing to attach.", stats

    ok_backup, why = pon_merge.backup_is_usable(backup_path)
    if not ok_backup:
        return False, (f"Refusing to attach: {why} Adding drop cables changes the "
                       "BoQ, so a restorable backup must exist first."), stats

    # ONE DROP PER HOME. A list naming the same home twice would put two cables
    # on it and bill for both — a BoQ error nobody would ever spot on the map.
    # plan_attachments cannot produce one (it walks unique demand fids), so this
    # changes nothing on the normal path; it is here so no caller can introduce
    # one. Caught by stress_connectivity.py feeding 3 proposals for 2 homes.
    seen = set()
    unique = []
    for p in proposals:
        fid = p.get("demand_fid")
        if fid in seen:
            continue
        seen.add(fid)
        unique.append(p)
    stats["duplicates_skipped"] = len(proposals) - len(unique)
    proposals = unique

    fields = drop_layer.fields()
    feats = []
    for p in proposals:
        ft = QgsFeature(fields)
        ft.setGeometry(QgsGeometry.fromPolylineXY([p["demand_pt"], p["splitter_pt"]]))
        for k, v in p["attrs"].items():
            i = fields.indexOf(k)
            if i < 0:
                continue
            try:
                ft.setAttribute(i, _coerce(v, fields.at(i)))
            except Exception:
                _swallowed_note(); continue
        feats.append(ft)

    ok, _added = drop_layer.dataProvider().addFeatures(feats)
    if not ok:
        stats["reason"] = "the drop layer refused the new features"
        return False, "The drop-cable layer refused the new cables — nothing was written.", stats
    drop_layer.reload()
    stats["written"] = len(feats)

    # PROVE IT — re-measure from the layer instead of trusting the return code.
    from . import connectivity_scan as cs
    verified = 0
    ends, _sk = cs.line_endpoints(drop_layer)
    if ends:
        idx = cs._index_of(ends)
        da = cs._measurer(drop_layer)
        for p in proposals:
            if cs.nearest_metres(p["demand_pt"], ends, idx, da) <= SNAP_TOL_M:
                verified += 1
    stats["verified"] = verified

    if update_counts and splitter_layer is not None:
        field = None
        for cand in ("drop_count", "drop_cnt", "drops"):
            if splitter_layer.fields().indexOf(cand) >= 0:
                field = cand
                break
        if field:
            loads = splitter_loads(splitter_layer, drop_layer)
            i = splitter_layer.fields().indexOf(field)
            changes = {}
            try:
                for f in splitter_layer.getFeatures():
                    want = int(loads.get(f.id(), 0))
                    try:
                        have = int(f[field])
                    except (TypeError, ValueError):
                        have = None
                    if have != want:
                        changes[f.id()] = {i: want}
            except Exception:
                changes = {}
            if changes and splitter_layer.dataProvider().changeAttributeValues(changes):
                splitter_layer.reload()
                stats["counts_updated"] = len(changes)

    msg = (f"Attached {stats['written']} drop cable(s); "
           f"{verified} confirmed connected on re-read")
    if stats["counts_updated"]:
        msg += f"; {stats['counts_updated']} splitter count(s) refreshed"
    return True, msg + ".", stats


def _coerce(value, field):
    """Best-effort type match, because a provider silently rejects a mismatch."""
    from qgis.PyQt.QtCore import QMetaType
    if value is None:
        return None
    try:
        t = field.type()
    except Exception:
        return value
    try:
        if t in (QMetaType.Type.Int, QMetaType.Type.LongLong):
            return int(float(value))
        if t == QMetaType.Type.Double:
            return float(value)
        if t == QMetaType.Type.QString:
            return str(value)
    except (TypeError, ValueError):
        return None
    return value
