"""nexus_dock — IDE-style dockable Velocity Nexus tools (pyqtgraph.dockarea, MIT).

Replaces the rejected in-panel reorder. Each tool group becomes a floatable / tabbable
/ re-dockable ``Dock`` inside a ``DockArea``; the layout saves to QgsSettings and
restores across restarts. Qt6-safe (qgis.PyQt shim, scoped enums, no ``.exec_()``).

Fail-open by contract: the caller wraps ``build_dockarea`` in try/except and falls back
to today's static panel if anything here raises (flag ``VF_NO_DOCK=1`` forces the
fallback). Nothing here changes any tool's behaviour — it only re-hosts the widgets.
"""
from qgis.PyQt.QtCore import QByteArray
from qgis.PyQt.QtWidgets import QWidget

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

try:                                    # bundled: relative inside the plugin package
    from .vendor.dockarea import DockArea, Dock
except ImportError:                     # headless / test: plugin dir on sys.path
    from vendor.dockarea import DockArea, Dock

_SETTINGS_KEY = "VelocityNexus/dock_layout_v1"


def build_dockarea(groups, first_edge="left"):
    """Build a DockArea from ``groups`` = [(title, content_widget), ...].

    Each group's ``content_widget`` is placed in its own Dock. The first Dock docks to
    ``first_edge``; each subsequent Dock stacks BELOW the previous (a vertical tool
    column by default — the operator then drags to float/tab/redock). Returns
    (area, {title: dock}). Never raises on an individual group — a bad group is skipped.
    """
    area = DockArea()
    docks = {}
    prev = None
    for title, widget in groups:
        try:
            # autoOrientation=False → title bars stay HORIZONTAL (card headers on top),
            # not the rotated side-labels pyqtgraph uses for tall docks.
            d = Dock(title, closable=True, autoOrientation=False)
            d.setObjectName(
                "VelocityNexusInternalDock_" +
                "".join(ch if ch.isalnum() else "_" for ch in str(title)).strip("_")
            )
            if widget is not None:
                d.addWidget(widget)
            if prev is None:
                area.addDock(d, first_edge)
            else:
                area.addDock(d, "bottom", prev)
            docks[title] = d
            prev = d
        except Exception:
            _swallowed_note(); continue
    return area, docks


# Velocity Nexus design tokens (the 'velocity' theme from velocity_home_panel).
THEME = {
    "bg": "#05070C", "cell": "#0D1320", "cell_hover": "#131D2E",
    "cell_press": "#0A1622", "hairline": "#1B2940", "cyan": "#1AE5FF",
    "text": "#C9DDF2", "text_hi": "#EAF3FF", "muted": "#7E93B8",
}

# One cascading stylesheet on the DockArea → styles the whole tool surface to match
# the Velocity Nexus console (near-black body, console-cell buttons, cyan hover,
# hairline borders, muted section labels). The DockLabel title bars are styled
# separately in the vendored updateStyle (they set their own sheet). objectNames:
# body = NexusDockBody · buttons = NexusTool · group caption = NexusGroupTitle.
NEXUS_QSS = """
DockArea, Container {{ background: {bg}; }}
QSplitter::handle {{ background: {bg}; }}
QSplitter::handle:hover {{ background: {cyan}; }}
QSplitter::handle:horizontal {{ width: 6px; }}
QSplitter::handle:vertical {{ height: 6px; }}
QWidget#NexusDockBody {{ background: {bg}; }}
QLabel#NexusGroupTitle {{
    color: {muted}; font-family: 'Chakra Petch','Segoe UI',sans-serif;
    font-size: 10px; font-weight: bold; letter-spacing: 1px;
    padding: 2px 2px 6px 2px;
}}
QPushButton#NexusTool {{
    background: {cell}; color: {text};
    border: 1px solid {hairline}; border-radius: 6px;
    padding: 9px 12px; font-family: 'Chakra Petch','Segoe UI',sans-serif;
    font-size: 12px; text-align: center;
}}
QPushButton#NexusTool:hover {{
    background: {cell_hover}; border: 1px solid {cyan}; color: {text_hi};
}}
QPushButton#NexusTool:pressed {{ background: {cell_press}; }}
QToolButton#WinClose, QPushButton#WinClose {{
    background: transparent; border: none; color: {muted};
    font-size: 13px; font-weight: bold; padding: 2px 9px;
}}
QToolButton#WinClose:hover, QPushButton#WinClose:hover {{
    background: #E81123; color: #ffffff;
}}
QToolButton#WinClose:pressed, QPushButton#WinClose:pressed {{
    background: #C50F1F; color: #ffffff;
}}
""".format(**THEME)


def style_windows_close(btn, on_close=None, tooltip="Close"):
    """Make any button behave + look like the Windows title-bar close button:
    a crisp ✕ that turns a red block with a white ✕ on hover, 'Close' tooltip, and
    closes on click. Reusable across the whole Nexus plugin. Fail-open — a styling
    hiccup never breaks the button. ``on_close`` is optional (dock close buttons are
    already wired to close themselves; pass it for plain buttons that aren't)."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtGui import QIcon
    try:
        btn.setObjectName("WinClose")
        btn.setToolTip(tooltip)
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        if hasattr(btn, "setToolButtonStyle"):
            btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
        btn.setIcon(QIcon())          # drop the stock grey glyph → crisp themed ✕
        btn.setText("✕")
        # SELF-CONTAINED stylesheet so the button looks right in ANY panel/dialog
        # regardless of its ancestor QSS (transparent → red block + white ✕ on hover).
        btn.setStyleSheet(
            "QToolButton, QPushButton {"
            " background: transparent; border: none; color: #8AA0BE;"
            " font-size: 15px; font-weight: bold; padding: 2px 8px; border-radius: 3px; }"
            "QToolButton:hover, QPushButton:hover { background: #E81123; color: #ffffff; }"
            "QToolButton:pressed, QPushButton:pressed { background: #C50F1F; color: #ffffff; }")
        if on_close is not None:
            btn.clicked.connect(on_close)
    except Exception:
        _swallowed_note()
    return btn


_DOCK_WHITELIST = ("velocity", "nexus", "erven", "team monitor", "teammonitor",
                   "label", "splice", "pole editor", "enclosure", "bridge", "velogis",
                   "ftth", "network planner", "planner")


def _is_velocity_dock(d):
    s = ((d.objectName() or "") + " " + (d.windowTitle() or "") + " "
         + d.__class__.__name__).lower()
    return any(k in s for k in _DOCK_WHITELIST)


def chrome_all_velocity_docks(main_window):
    """Chrome EVERY Velocity dock currently in the main window (idempotent, fail-open).
    Skips QGIS's own docks via the whitelist."""
    try:
        from qgis.PyQt.QtWidgets import QDockWidget
        for d in main_window.findChildren(QDockWidget):
            if _is_velocity_dock(d):
                apply_dock_chrome(d)
    except Exception:
        _swallowed_note()


def uninstall_dock_chrome_watcher(main_window, watcher=None):
    """Remove all Velocity dock watchers, including leaked older instances."""
    try:
        from qgis.PyQt import sip
        from qgis.PyQt.QtCore import QObject
        candidates = []
        for obj in (watcher, getattr(main_window, "_vf_dock_chrome_watcher", None)):
            if obj is not None:
                candidates.append(obj)
        candidates.extend(
            obj for obj in main_window.findChildren(QObject)
            if obj.__class__.__name__ == "_DockWatcher")
        seen = set()
        for obj in candidates:
            if id(obj) in seen or sip.isdeleted(obj):
                continue
            seen.add(id(obj))
            try:
                if hasattr(obj, "shutdown"):
                    obj.shutdown()
                else:
                    main_window.removeEventFilter(obj)
            except Exception:
                _swallowed_note()
            try:
                obj.deleteLater()
            except Exception:
                _swallowed_note()
        main_window._vf_dock_chrome_watcher = None
        return len(seen)
    except Exception:
        return 0


def install_dock_chrome_watcher(main_window):
    """Persistently chrome every Velocity dock — now AND whenever one opens later —
    so a dock class we didn't individually edit still gets the bright ✕/float title.

    Lightweight: only reacts to a QDockWidget being ADDED (rare), never a general
    loop. Filters to Velocity docks so QGIS's own panels are untouched. Idempotent +
    fail-open. Returns the watcher (keep a ref so it isn't GC'd)."""
    try:
        from qgis.PyQt import sip
        from qgis.PyQt.QtCore import QObject, QEvent, QTimer

        existing = getattr(main_window, "_vf_dock_chrome_watcher", None)
        if (existing is not None and not sip.isdeleted(existing)
                and hasattr(existing, "schedule")):
            existing.schedule(0)
            return existing

        uninstall_dock_chrome_watcher(main_window)

        class _DockWatcher(QObject):
            def __init__(self, parent):
                super().__init__(parent)
                self._main_window = parent
                self._timer = QTimer(self)
                self._timer.setSingleShot(True)
                self._timer.timeout.connect(self.sweep)
                parent.installEventFilter(self)

            def schedule(self, delay=60):
                if not self._timer.isActive() or delay == 0:
                    self._timer.start(max(0, int(delay)))

            def sweep(self):
                try:
                    if sip.isdeleted(self._main_window):
                        return
                    # A held mouse button means a dock drag may be in flight. Even the
                    # now-idempotent chrome pass is kept out of a live gesture: come
                    # back once the button is released (see apply_dock_chrome).
                    from qgis.PyQt.QtCore import Qt
                    from qgis.PyQt.QtWidgets import QApplication
                    if QApplication.mouseButtons() != Qt.MouseButton.NoButton:
                        self.schedule(250)
                        return
                    chrome_all_velocity_docks(self._main_window)
                except Exception:
                    _swallowed_note()

            def shutdown(self):
                try:
                    self._timer.stop()
                    self._timer.timeout.disconnect(self.sweep)
                except Exception:
                    _swallowed_note()
                try:
                    if not sip.isdeleted(self._main_window):
                        self._main_window.removeEventFilter(self)
                except Exception:
                    _swallowed_note()

            def eventFilter(self, obj, ev):
                try:
                    # a dock/toolbar/etc. was added to the main window → after it's
                    # built, sweep + chrome any Velocity dock (idempotent + cheap, so
                    # re-running is free; a full sweep is far more reliable than trying
                    # to target the specific child, which can be an intermediate).
                    if ev.type() == QEvent.Type.ChildAdded:
                        c = ev.child()
                        if c is not None and getattr(c, "isWidgetType", lambda: False)():
                            self.schedule(60)
                except Exception:
                    _swallowed_note()
                return False

        w = _DockWatcher(main_window)
        main_window._vf_dock_chrome_watcher = w
        w.sweep()                                   # catch everything already open
        return w
    except Exception:
        return None
# ── top-level QGIS dock chrome ────────────────────────────────────────────────
def apply_dock_chrome(dock):
    """Use the native QGIS/Qt title bar and docking gesture.

    A custom title widget cannot participate in QMainWindow's magnetic docking
    lifecycle. Qt therefore owns float, tab, drop and cancel behaviour.

    ⚠️ NO-OP WHEN ALREADY CORRECT. ``setFeatures``/``setTitleBarWidget`` rebuild a
    QDockWidget's title bar, and doing that to a dock the user is DRAGGING destroys
    Qt's in-flight drag state: the dock then sticks to the cursor and the drop never
    lands (measured 2026-08-27 — watcher on: 2/2 drags failed to dock; watcher off:
    the same drag docked). The watcher sweeps on every ChildAdded, and floating a
    dock mid-drag IS a ChildAdded, so the sweep used to land inside the gesture.
    Every Qt call below is now guarded by a read-first comparison, so a re-sweep of
    an already-chromed dock touches nothing.
    """
    try:
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtWidgets import QDockWidget
        want_features = (
            QDockWidget.DockWidgetFeature.DockWidgetClosable
            | QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QDockWidget.DockWidgetFeature.DockWidgetFloatable
        )
        if dock.features() != want_features:
            dock.setFeatures(want_features)
        if dock.allowedAreas() != Qt.DockWidgetArea.AllDockWidgetAreas:
            dock.setAllowedAreas(Qt.DockWidgetArea.AllDockWidgetAreas)
        if not (dock.objectName() or "").strip():
            stable = "".join(
                ch if ch.isalnum() else "_" for ch in
                (dock.__class__.__name__ + "_" +
                 (dock.windowTitle() or "VelocityDock"))
            ).strip("_")
            dock.setObjectName(stable)
        if dock.titleBarWidget() is not None:
            dock.setTitleBarWidget(None)
        dock._vf_titlebar = None
        dock._vf_native_chrome = True
        # smooth (non-opaque) dragging: preview follows the cursor, the real dock
        # is not touched until the drop. Fail-open; VF_NO_SMOOTH_DRAG=1 disables.
        try:
            from . import nexus_drag
        except ImportError:
            import nexus_drag
        nexus_drag.install(dock, main_window=dock.parent())
    except Exception:
        _swallowed_note()
    return dock


# ── in-panel section headings (the "// WORKFLOW" style) ───────────────────────
SECTION_HEADING_QSS = (
    "color: {muted}; font-family: 'Chakra Petch','Segoe UI',sans-serif;"
    " font-size: 11px; font-weight: bold; letter-spacing: 1.5px;"
    " padding: 2px 0 4px 0;"
).format(**THEME)


def style_section_heading(label, text=None):
    """Style a QLabel as a Velocity section heading: muted, upper, spaced, with the
    '// ' console prefix (matches the panel's '// WORKFLOW'). Fail-open."""
    try:
        if text is not None or label.text():
            t = (text if text is not None else label.text()).strip().lstrip("/ ").upper()
            label.setText("// " + t)
        label.setStyleSheet(SECTION_HEADING_QSS)
    except Exception:
        _swallowed_note()
    return label


def _make_drag_filter():
    """Factory for a QObject event-filter that lets a frameless dialog be dragged by
    its title bar (defined lazily so QtCore is only imported at call time)."""
    from qgis.PyQt.QtCore import QObject, QEvent, Qt

    class _Filter(QObject):
        def __init__(self, dlg):
            super().__init__(dlg)
            self._dlg = dlg
            self._pos = None

        def eventFilter(self, obj, ev):
            try:
                t = ev.type()
                if t == QEvent.Type.MouseButtonPress and ev.button() == Qt.MouseButton.LeftButton:
                    self._pos = (ev.globalPosition().toPoint()
                                 - self._dlg.frameGeometry().topLeft())
                elif (t == QEvent.Type.MouseMove and self._pos is not None
                      and (ev.buttons() & Qt.MouseButton.LeftButton)):
                    self._dlg.move(ev.globalPosition().toPoint() - self._pos)
                elif t == QEvent.Type.MouseButtonRelease:
                    self._pos = None
            except Exception:
                self._pos = None
            return False
    return _Filter


def chrome_dialog(dlg, title=None):
    """Reshape a QDialog to the Velocity look: FRAMELESS with a custom dark title bar
    (cyan accent + a Windows-red ✕ that calls reject), draggable by the title bar.

    SAFE + fail-open: only proceeds when the dialog's top layout is a box layout we can
    insert a title bar into; otherwise the dialog is left exactly as it was (native
    frame, still fully working) — never raises, never crashes. Idempotent. MUST be
    called BEFORE the dialog is shown/exec'd (changing window flags hides a live one)."""
    try:
        from qgis.PyQt.QtWidgets import (QWidget, QHBoxLayout, QLabel, QToolButton,
                                         QBoxLayout)
        from qgis.PyQt.QtCore import Qt
        if getattr(dlg, "_vf_chromed", False):
            return dlg
        lay = dlg.layout()
        if not isinstance(lay, QBoxLayout):
            return dlg                      # can't safely insert a title bar → leave framed
        ttl = title or dlg.windowTitle() or "Velocity Nexus"
        dlg.setWindowFlags(dlg.windowFlags() | Qt.WindowType.FramelessWindowHint)
        bar = QWidget(dlg)
        bar.setObjectName("NexusDlgTitle")
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(12, 7, 6, 6)
        bl.setSpacing(6)
        tl = QLabel(ttl)
        tl.setObjectName("NexusDlgTitleText")
        bl.addWidget(tl)
        bl.addStretch(1)
        x = QToolButton()
        x.setFixedSize(28, 24)
        style_windows_close(x, dlg.reject)
        bl.addWidget(x, 0, Qt.AlignmentFlag.AlignTop)
        bar.setStyleSheet(
            "#NexusDlgTitle{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,"
            "stop:0 #0B1019,stop:1 #070A11);border-bottom:2px solid #1AE5FF;}"
            "#NexusDlgTitleText{color:#EAF3FF;font-family:'Chakra Petch','Segoe UI',"
            "sans-serif;font-size:13px;font-weight:bold;}")
        lay.insertWidget(0, bar)
        filt = _make_drag_filter()(dlg)
        bar.installEventFilter(filt)
        tl.installEventFilter(filt)
        dlg._vf_drag_filter = filt          # keep a ref so it isn't GC'd
        dlg._vf_chromed = True
    except Exception:
        _swallowed_note()
    return dlg


def make_tool_button(label, on_click=None):
    """A Velocity-Nexus-styled tool button (objectName NexusTool → themed by QSS)."""
    from qgis.PyQt.QtWidgets import QPushButton
    b = QPushButton(label)
    b.setObjectName("NexusTool")
    b.setMinimumHeight(32)
    b.setCursor(_pointing_cursor())
    if on_click is not None:
        b.clicked.connect(on_click)
    return b


def make_group_body(title, buttons, columns=2):
    """A themed dock body: the given tool buttons laid out in a ``columns``-wide grid
    on the near-black console background (2-col keeps long tool lists compact). The
    group name is the Dock's own (draggable) title bar, so no redundant caption.
    ``buttons`` = list of QWidgets."""
    from qgis.PyQt.QtWidgets import QVBoxLayout, QGridLayout, QSizePolicy
    w = QWidget()
    w.setObjectName("NexusDockBody")
    lay = QVBoxLayout(w)
    lay.setContentsMargins(10, 10, 10, 10)
    lay.setSpacing(7)
    grid = QGridLayout()
    grid.setSpacing(6)
    cols = max(1, int(columns))
    for c in range(cols):
        grid.setColumnStretch(c, 1)
    for i, b in enumerate(buttons):
        try:
            b.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        except Exception:
            _swallowed_note()
        grid.addWidget(b, i // cols, i % cols)
    lay.addLayout(grid)
    lay.addStretch(1)
    return w


def _pointing_cursor():
    from qgis.PyQt.QtCore import Qt
    return Qt.CursorShape.PointingHandCursor


def apply_polish(area, docks):
    """Apply the Velocity Nexus theme + smoothness to a built DockArea (no behaviour
    change): near-black body, console-cell buttons + cyan hover, wider hover-cyan
    splitter handles, and an open-hand grab cursor on every title bar. All external
    styling (the label title bars are themed in the vendored updateStyle). Fail-open."""
    from qgis.PyQt.QtCore import Qt
    try:
        area.setStyleSheet(NEXUS_QSS)
    except Exception:
        _swallowed_note()
    for d in (docks or {}).values():
        try:
            lbl = getattr(d, "label", None)
            if lbl is not None:
                lbl.setCursor(Qt.CursorShape.OpenHandCursor)
                lbl.fontSize = "13px"          # prominent card-header title
                lbl.updateStyle()
                cb = getattr(lbl, "closeButton", None)
                if cb is not None:             # Windows-style red close (already wired
                    style_windows_close(cb)    # to close the dock via sigCloseClicked)
        except Exception:
            _swallowed_note(); continue


def save_layout(area, settings=None):
    """Persist the DockArea layout to QgsSettings (global). Returns True on success."""
    try:
        from qgis.core import QgsSettings
        st = area.saveState()
        (settings or QgsSettings()).setValue(_SETTINGS_KEY, repr(st))
        return True
    except Exception:
        return False


def restore_layout(area, settings=None):
    """Restore a previously-saved layout onto ``area``. Returns True if one was applied.

    Safe: a missing / unparseable / stale layout (docks that no longer exist) is
    swallowed and the freshly-built default layout stays."""
    try:
        from qgis.core import QgsSettings
        import ast
        raw = (settings or QgsSettings()).value(_SETTINGS_KEY, None)
        if not raw:
            return False
        state = ast.literal_eval(raw) if isinstance(raw, str) else raw
        area.restoreState(state, missing="ignore")
        if hasattr(area, "clampFloatingWindows"):
            area.clampFloatingWindows()
        return True
    except Exception:
        return False


def clear_layout(settings=None):
    """'Reset layout' — drop the saved state so the next open uses the default."""
    try:
        from qgis.core import QgsSettings
        (settings or QgsSettings()).remove(_SETTINGS_KEY)
        return True
    except Exception:
        return False


# keep the import used (QByteArray may back saveState in some builds) discoverable
__all__ = [
    "Dock",
    "DockArea",
    "QByteArray",
    "build_dockarea",
    "clear_layout",
    "restore_layout",
    "save_layout",
]
