"""Feeder-walk PON ordering — the cable-hierarchy walk JJ confirmed by recording
his manual walk (2026-06-24). Pure Python (math only), no QGIS imports.

compute(feeder, dist, zones, pop) -> {'order': [...], 'walk': [[lon,lat],...],
                                      'pen': [0|1,...]}   (pen[i]=draw segment to walk[i])
walk_order(...) -> just the order list.

Rule: walk the 144F from the POP (or a chosen start); descend each spur in position
order along the parent (bigger LINK first when two spur at ~the same point); along a
link, dip a LITTLE way into each distribution -> that zone's number; a sub-link tapping
right at the entry junction is DEFERRED until after the cable's own distributions;
dedup by zone. Numbers are assigned ONLY on the forward dip; returns/jumps have pen=0.
See memory: project_feeder_walk_auto_renumber_2026-06-24.

Inputs (all coords [lon, lat] degrees — the metric helper assumes WGS84):
  feeder : [{'pts': [[lon,lat],...], 'size': 144|48|24}, ...]
  dist   : [[[lon,lat],...], ...]
  zones  : [{'id': str, 'rings': [[[lon,lat],...], ...], 'c': [lon,lat]}, ...]
  pop    : [lon, lat]
"""
import math

# How far the walk dips into each distribution before reading the zone. JJ set this to
# 40 m (2026-06-25) so the dip reaches well inside the polygon and every zone is detected
# reliably, and so the drawn route clearly enters each zone (followable on the canvas).
# Only affects dip DEPTH / which zone is read — not the order spurs are visited in.
STUB_M = 40.0
TOL = 4.0
START = 25.0


def _md(a, b):
    dy = (a[1] - b[1]) * 110540.0
    dx = (a[0] - b[0]) * 111320.0 * math.cos(math.radians(a[1]))
    return math.hypot(dx, dy)


def _proj(P, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    l2 = dx * dx + dy * dy
    t = 0.0 if l2 == 0 else max(0.0, min(1.0, ((P[0] - a[0]) * dx + (P[1] - a[1]) * dy) / l2))
    q = [a[0] + t * dx, a[1] + t * dy]
    return _md(P, q), q


def _proj_cum(pts, P):
    best = (1e18, 0.0, pts[0])
    acc = 0.0
    for i in range(1, len(pts)):
        d, q = _proj(P, pts[i - 1], pts[i])
        if d < best[0]:
            best = (d, acc + _md(pts[i - 1], q), q)
        acc += _md(pts[i - 1], pts[i])
    return best


def _point_along(pts, dist_m):
    acc = 0.0
    for i in range(1, len(pts)):
        seg = _md(pts[i - 1], pts[i])
        if acc + seg >= dist_m:
            t = (dist_m - acc) / seg if seg > 0 else 0.0
            return [pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * t,
                    pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * t]
        acc += seg
    return pts[-1]


def _pip(lon, lat, ring):
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i]
        xj, yj = ring[j]
        if ((yi > lat) != (yj > lat)) and \
           (lon < (xj - xi) * (lat - yi) / ((yj - yi) or 1e-12) + xi):
            inside = not inside
        j = i
    return inside


def compute(feeder, dist, zones, pop):
    """Full result: {'order', 'walk', 'pen'}. Never raises on empty inputs."""
    # Tag every cable by SOURCE: 'feeder' = the backbone (144F/48F/24F) that runs THROUGH
    # zones but never numbers one; 'dist' = a distribution that splits off the feeder INTO
    # a zone — the ONLY thing that numbers a zone. JJ's rule (2026-06-25): the feeder just
    # carries the walk between zones; only a distribution tap-off assigns a zone its number.
    cables = [{'pts': f['pts'], 'size': f.get('size') or 0, 'kind': 'feeder'}
              for f in feeder if len(f.get('pts', [])) >= 2]
    for ln in dist:
        if len(ln) >= 2:
            cables.append({'pts': ln, 'size': 1, 'kind': 'dist'})
    if not cables or not zones:
        return {'order': [], 'walk': [], 'pen': []}
    # Trunk = the biggest FEEDER. A distribution must never become the trunk even if a
    # feeder's Size field is missing/unparsed (size 0).
    _feeders = [i for i, c in enumerate(cables) if c['kind'] == 'feeder']
    idx144 = (max(_feeders, key=lambda i: cables[i]['size']) if _feeders
              else max(range(len(cables)), key=lambda i: cables[i]['size']))

    def zone_of(P):
        for z in zones:
            for ring in z.get('rings', []):
                if len(ring) >= 3 and _pip(P[0], P[1], ring):
                    return z['id']
        return None

    def nearest_zone(P):
        return min(zones, key=lambda z: _md(P, z['c']))['id']

    orient = [None] * len(cables)
    parent = [None] * len(cables)
    tap_end = [None] * len(cables)
    a0, a1 = cables[idx144]['pts'][0], cables[idx144]['pts'][-1]
    orient[idx144] = cables[idx144]['pts'][:] if _md(a0, pop) <= _md(a1, pop) \
        else cables[idx144]['pts'][::-1]
    for ci, c in enumerate(cables):
        if ci == idx144:
            continue
        best = None
        for end in (c['pts'][0], c['pts'][-1]):
            for ti, tg in enumerate(cables):
                if ti == ci:
                    continue
                # A spur always taps onto a FEEDER (a distribution never carries another
                # cable); a feeder spur must tap onto a BIGGER feeder.
                if tg['kind'] != 'feeder':
                    continue
                if c['kind'] == 'feeder' and tg['size'] <= c['size']:
                    continue
                d, _cum, _q = _proj_cum(tg['pts'], end)
                if d <= TOL:
                    cand = (d, -tg['size'], ti, end)
                    if best is None or cand[:2] < best[:2]:
                        best = cand
        if best is None:
            continue
        parent[ci], tap_end[ci] = best[2], best[3]
        orient[ci] = c['pts'][:] if best[3] == c['pts'][0] else c['pts'][::-1]

    children = [[] for _ in cables]
    for ci in range(len(cables)):
        if parent[ci] is None or orient[parent[ci]] is None:
            continue
        cum = _proj_cum(orient[parent[ci]], tap_end[ci])[1]
        children[parent[ci]].append((cum, ci))

    walk, pen, order = [], [], []
    seen = set()
    visited = set()

    def add(pt, draw=True):
        if not walk:
            draw = False
        walk.append([pt[0], pt[1]])
        pen.append(1 if draw else 0)

    def dip(ci, tap_pt):
        pts = orient[ci]
        if not pts:
            return
        inside = _point_along(pts, STUB_M)
        add(tap_pt, True)
        add(pts[0], True)
        add(inside, True)
        add(pts[0], False)
        add(tap_pt, False)
        zid = (zone_of(inside) or zone_of(_point_along(pts, STUB_M * 2))
               or zone_of(pts[-1]) or nearest_zone(inside))
        if zid is not None and zid not in seen:
            seen.add(zid)
            order.append(zid)

    def point_at_cum(pts, target):
        acc = 0.0
        for i in range(1, len(pts)):
            seg = _md(pts[i - 1], pts[i])
            if acc + seg >= target:
                t = (target - acc) / seg if seg > 0 else 0.0
                return [pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * t,
                        pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * t]
            acc += seg
        return pts[-1]

    def process(ci, depth=0):
        if ci in visited or depth > 5000:
            return
        visited.add(ci)
        pts = orient[ci]
        if not pts:
            return
        add(pts[0])
        kids = children[ci]
        deferred = [(c, k) for c, k in kids
                    if cables[k]['kind'] == 'feeder' and c < START]
        inline = sorted([(c, k) for c, k in kids
                         if not (cables[k]['kind'] == 'feeder' and c < START)],
                        key=lambda x: (round(x[0], 1), -cables[x[1]]['size']))
        ii = 0
        acc = 0.0
        for i in range(1, len(pts)):
            seg = _md(pts[i - 1], pts[i])
            while ii < len(inline) and inline[ii][0] <= acc + seg + 1e-9:
                _cum, k = inline[ii]
                ii += 1
                if k in visited:
                    continue
                t = max(0.0, min(1.0, (inline[ii - 1][0] - acc) / seg if seg > 0 else 0.0))
                tap = [pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * t,
                       pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * t]
                if cables[k]['kind'] == 'dist':
                    visited.add(k)
                    dip(k, tap)
                else:
                    add(tap)
                    process(k, depth + 1)
                    add(tap, False)
            add(pts[i])
            acc += seg
        while ii < len(inline):
            _cum, k = inline[ii]
            ii += 1
            if k in visited:
                continue
            if cables[k]['kind'] == 'dist':
                visited.add(k)
                dip(k, pts[-1])
            else:
                add(pts[-1])
                process(k, depth + 1)
                add(pts[-1], False)
        for cum, k in sorted(deferred, key=lambda x: (round(x[0], 1), -cables[x[1]]['size'])):
            if k in visited:
                continue
            tap = point_at_cum(pts, cum)
            add(tap, False)
            process(k, depth + 1)
            add(tap, False)

    process(idx144)
    return {'order': order,
            'walk': [[round(p[0], 7), round(p[1], 7)] for p in walk],
            'pen': pen}


def walk_order(feeder, dist, zones, pop):
    return compute(feeder, dist, zones, pop)['order']
