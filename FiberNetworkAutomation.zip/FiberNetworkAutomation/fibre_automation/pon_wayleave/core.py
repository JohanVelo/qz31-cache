"""Span-constrained PON grouping — the engine.

Groups demand points into PONs by walking the drawn fibre route, so that every
PON is one continuous run of span. Returns ASSIGNMENTS ONLY; the polygons are
built by ``network_planner.pon_tiles`` + ``pon_merge.shrink`` (the boundary
pipeline already shipped and stress-tested on 2026-07-23), so there is exactly
one implementation of what a PON boundary looks like.

No QGIS imports. The engine runs headless on shapely/networkx/numpy, which is
what lets the gates in ``research/pon_wayleave_verify/`` exercise it without a
QGIS process. The QGIS adapter lives in ``qgis_adapter.py``.

The rules it enforces, from the 2026 OPL GPON FTTH standard and JJ 2026-09-04:

* target ``TARGET_STANDS`` (96) stands per PON,
* hard ceiling ``MAX_STANDS`` (120) — never exceeded,
* **no minimum.** JJ, 2026-09-04: once the full PONs are packed, the ones left
  under are fine. Earlier revisions enforced a 60 floor and it forced bad
  merges; there is deliberately no floor here.
* a PON's span is one connected subgraph, and runs are atomic — a cut can only
  land on a junction, never part-way along a run. That is what stops a boundary
  slicing a span, which would force a second distribution cable.
"""

from __future__ import annotations

import math
from collections import defaultdict

import networkx as nx
import numpy as np
from scipy.spatial import cKDTree
from shapely.geometry import LineString

__all__ = [
    "DEFAULT_SNAP_M",
    "MAX_STANDS",
    "RESTART_SEEDS",
    "TARGET_STANDS",
    "PonWayleaveError",
    "SpanGraph",
    "check_zone_fit",
    "utm_epsg_for",
]

TARGET_STANDS = 96
MAX_STANDS = 120
DEFAULT_SNAP_M = 0.5

#: Seeds tried by the multi-restart. A fixed list, not a random draw, so the
#: result is reproducible; the best inertia wins.
RESTART_SEEDS = (20260904, 7, 12345, 99, 2718)


class PonWayleaveError(RuntimeError):
    """Raised for input the operator has to fix, with a readable message."""


# ── CRS ─────────────────────────────────────────────────────────────────────

def utm_epsg_for(lon: float, lat: float) -> int:
    """EPSG code of the UTM zone containing this longitude/latitude.

    Derived from the data, never hardcoded: a fixed zone reprojects a project
    from another part of the world *successfully* and silently corrupts every
    distance by up to the false-northing offset.
    """
    if not (-180.0 <= lon <= 180.0) or not (-90.0 <= lat <= 90.0):
        raise PonWayleaveError(
            f"Coordinates ({lon:.5f}, {lat:.5f}) are not valid longitude/latitude. "
            "The layers must be in a geographic or projected CRS that can be "
            "converted to WGS84."
        )
    zone = int(math.floor((lon + 180.0) / 6.0) % 60) + 1
    return (32600 if lat >= 0 else 32700) + zone


def check_zone_fit(lons, lats, epsg: int) -> None:
    """Fail loudly if the data does not belong in the chosen UTM zone.

    A zone is 6 degrees wide. Data more than ~5 degrees off the central
    meridian, or in the wrong hemisphere, means the caller picked the zone from
    the wrong place — better a clear error than silently wrong metres.
    """
    zone = epsg % 100
    central = -180.0 + 6.0 * zone - 3.0
    lons = np.asarray(lons, dtype=float)
    lats = np.asarray(lats, dtype=float)
    off = float(np.max(np.abs(lons - central)))
    if off > 5.0:
        raise PonWayleaveError(
            f"The data sits {off:.1f} degrees from the centre of UTM zone {zone}. "
            "That is outside the zone, so distances would be wrong. Check the "
            "layer CRS."
        )
    northern = epsg < 32700
    if northern and float(np.min(lats)) < -1.0:
        raise PonWayleaveError("Northern-hemisphere UTM zone chosen for southern data.")
    if not northern and float(np.max(lats)) > 1.0:
        raise PonWayleaveError("Southern-hemisphere UTM zone chosen for northern data.")


# ── span graph ──────────────────────────────────────────────────────────────

class SpanGraph:
    """The fibre route as a graph of atomic runs.

    Two things here are easy to get wrong and both were measured wrong once:

    * **T-junctions.** Span lines mostly do not meet end-to-end; a line's
      endpoint lands on the *middle* of its neighbour. Matching endpoints to
      endpoints reported 272 disconnected fragments on a route that is actually
      one network. Lines are split wherever another line's endpoint touches.
    * **Node identity by tolerance, not by rounding.** Rounding coordinates onto
      a grid splits two endpoints 0.3 m apart into different cells whenever they
      straddle a cell boundary, inventing components that are not there. Nodes
      are clustered with a union-find over a KD-tree instead.
    """

    def __init__(self, lines, snap_m: float = DEFAULT_SNAP_M):
        self.snap_m = float(snap_m)
        self.runs: list[LineString] = self._split_at_junctions(lines, self.snap_m)
        if not self.runs:
            raise PonWayleaveError("The span layer has no usable lines.")
        self._build_graph()

    # -- construction --------------------------------------------------------

    @staticmethod
    def _flatten(lines):
        out = []
        for g in lines:
            if g is None or g.is_empty:
                continue
            if g.geom_type == "MultiLineString":
                out.extend([p for p in g.geoms if p.length > 0])
            elif g.geom_type == "LineString" and g.length > 0:
                out.append(g)
        return out

    @classmethod
    def _split_at_junctions(cls, lines, snap_m):
        """Split every line wherever another line's ENDPOINT touches it.

        The query must be against the LINE, not against its vertices. A
        T-junction often lands part-way along a straight segment whose nearest
        drawn vertex is tens of metres away, so a vertex-radius search misses it
        and the route comes apart into fragments that are not really there
        (measured: 81 components instead of 1).
        """
        from shapely import STRtree
        from shapely.geometry import Point as _P

        parts = cls._flatten(lines)
        if not parts:
            return []

        ends = []
        for p in parts:
            ends.append(_P(p.coords[0]))
            ends.append(_P(p.coords[-1]))
        tree = STRtree(ends)

        runs = []
        for p in parts:
            cuts = {0.0, p.length}
            for i in tree.query(p.buffer(snap_m)):
                pt = ends[int(i)]
                if p.distance(pt) > snap_m:
                    continue
                d = p.project(pt)
                if snap_m < d < p.length - snap_m:
                    cuts.add(d)
            ordered = sorted(cuts)
            for a, b in zip(ordered[:-1], ordered[1:]):
                if b - a < 0.01:
                    continue
                n = max(2, int((b - a) / 5.0) + 2)
                runs.append(
                    LineString([p.interpolate(x) for x in np.linspace(a, b, n)])
                )
        return runs

    def _build_graph(self):
        ends = []
        for r in self.runs:
            ends.append(r.coords[0])
            ends.append(r.coords[-1])
        ends = np.asarray(ends, dtype=float)

        tree = cKDTree(ends)
        parent = np.arange(len(ends))

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        for a, b in tree.query_pairs(r=self.snap_m, output_type="ndarray"):
            ra, rb = find(int(a)), find(int(b))
            if ra != rb:
                parent[rb] = ra

        self.node_of_end = {i: find(i) for i in range(len(ends))}
        self.node_xy = {}
        for i in range(len(ends)):
            self.node_xy.setdefault(self.node_of_end[i], ends[i])

        # A MultiGraph, so a ring feed (two runs joining the same pair of
        # junctions) keeps BOTH runs. A plain Graph silently drops one, and the
        # dropped run then has no neighbours and can never be repaired.
        self.G = nx.MultiGraph()
        self.run_nodes: dict[int, tuple] = {}
        for i, r in enumerate(self.runs):
            a = self.node_of_end[2 * i]
            b = self.node_of_end[2 * i + 1]
            self.run_nodes[i] = (a, b)
            if a == b:
                continue           # a closed loop touches one junction only
            self.G.add_edge(a, b, key=i, weight=r.length, run=i)

        node_runs = defaultdict(set)
        for i, (a, b) in self.run_nodes.items():
            node_runs[a].add(i)
            node_runs[b].add(i)
        self.run_neighbours = defaultdict(set)
        for rs in node_runs.values():
            for i in rs:
                self.run_neighbours[i] |= (rs - {i})

    # -- queries -------------------------------------------------------------

    @property
    def n_components(self) -> int:
        return nx.number_connected_components(self.G) if self.G.number_of_nodes() else 0

    def total_length_m(self) -> float:
        return float(sum(r.length for r in self.runs))

    def runs_connected(self, run_ids) -> bool:
        """True when this set of runs forms ONE connected piece of span."""
        run_ids = set(run_ids)
        if len(run_ids) <= 1:
            return True
        H = nx.Graph()
        H.add_nodes_from(run_ids)
        for i in run_ids:
            for j in self.run_neighbours.get(i, ()):
                if j in run_ids:
                    H.add_edge(i, j)
        return nx.number_connected_components(H) == 1

    def run_groups(self, run_ids):
        """Connected groups within a set of runs."""
        run_ids = set(run_ids)
        H = nx.Graph()
        H.add_nodes_from(run_ids)
        for i in run_ids:
            for j in self.run_neighbours.get(i, ()):
                if j in run_ids:
                    H.add_edge(i, j)
        return [set(c) for c in nx.connected_components(H)]

    def nearest_node(self, x: float, y: float):
        keys = list(self.node_xy)
        arr = np.asarray([self.node_xy[k] for k in keys], dtype=float)
        d = np.hypot(arr[:, 0] - x, arr[:, 1] - y)
        i = int(d.argmin())
        return keys[i], float(d[i])

    def distance_from(self, node) -> dict:
        """Shortest path length along the span from one node to every other."""
        return nx.single_source_dijkstra_path_length(self.G, node, weight="weight")
