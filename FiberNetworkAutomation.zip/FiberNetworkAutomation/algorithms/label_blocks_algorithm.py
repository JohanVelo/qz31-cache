# Label Blocks Algorithm

from qgis.core import (
    QgsProcessingParameterVectorLayer,
    QgsProcessing
)

from .base_algorithm import BaseFiberAlgorithm


class LabelBlocksAlgorithm(BaseFiberAlgorithm):
    """Algorithm to label Block layers"""

    def name(self):
        return 'labelblocks'

    def displayName(self):
        return '2. Label Blocks'

    def shortHelpString(self):
        return """
        Auto-populate Block fields.

        Fields updated:
        - Label.: PRAK-Z1-B001, B002, B003...
        - fid: 1, 2, 3...

        ⚠️ Run this SECOND (after Aggregation Polygons)!
        """

    def initAlgorithm(self, config=None):
        # Input layer
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT,
                'Block Layer',
                [QgsProcessing.SourceType.TypeVectorPolygon]
            )
        )

        # Project selection
        self.add_common_parameters()

    def processAlgorithm(self, parameters, context, feedback):
        # Get parameters
        layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        project = self.get_project_code(parameters, context)

        feedback.pushInfo(f"Labeling Blocks for {project}...")

        # Update fid
        feedback.pushInfo("Updating fid...")
        self.calculate_field(layer, "fid", "@row_number", feedback)

        # Update Label. (note the dot!)
        feedback.pushInfo("Updating Label....")
        formula = f"'{project}-Z1-B' || lpad(to_string(\"fid\"), 3, '0')"
        self.calculate_field(layer, "Label.", formula, feedback)

        layer.triggerRepaint()
        feedback.pushInfo("✅ Blocks labeled successfully!")

        return {self.INPUT: layer.id()}
