"""ticket_dialog — a small "Log a ticket" form for the home panel's red button.

A teammate reports a bug or requests a feature; on submit, `on_submit(payload)`
is called (the plugin sends it to the planning office via the Nexus backend).
Screenshots can be pasted (Ctrl+V) or attached — they ride along in
payload['_shots'] as a list of PNG bytes for the plugin to upload.
Returns True on a successful (queued) send. Fully fail-soft.
"""
from qgis.PyQt.QtCore import Qt, QBuffer, QByteArray, QIODevice
from qgis.PyQt.QtGui import QPixmap, QImage
from qgis.PyQt.QtWidgets import (QComboBox, QDialog, QFileDialog, QFrame,
                                 QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                                 QPlainTextEdit, QPushButton, QVBoxLayout,
                                 QApplication)

_MAX_SHOTS = 6

_QSS = """
QDialog { background:#0F172A; }
QLabel { color:#F1F5F9; }
QLabel#vfTkHint { color:#94A3B8; font-size:11px; }
QLabel#vfTkLbl  { color:#64748B; font-size:9px; font-weight:700; letter-spacing:1px; }
QComboBox, QLineEdit, QPlainTextEdit {
    background:#1A2942; color:#F1F5F9; border:1px solid #2A3A52;
    border-radius:7px; padding:7px 9px; font-size:12px;
}
QComboBox:focus, QLineEdit:focus, QPlainTextEdit:focus { border:1px solid #06B6D4; }
QPushButton#vfTkSend {
    background:qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #06B6D4, stop:1 #3B82F6);
    color:#08131F; border:none; border-radius:8px; padding:9px 14px; font-weight:800;
}
QPushButton#vfTkSend:hover { border:1px solid #FFFFFF; }
QPushButton#vfTkCancel { background:transparent; color:#94A3B8; border:none; padding:9px 12px; }
QPushButton#vfTkCancel:hover { color:#F1F5F9; }
QPushButton#vfTkAttach {
    background:#1A2942; color:#CBD5E1; border:1px solid #2A3A52;
    border-radius:7px; padding:6px 10px; font-size:11px; font-weight:600;
}
QPushButton#vfTkAttach:hover { border:1px solid #06B6D4; color:#F1F5F9; }
QFrame#vfTkShots { background:#142036; border:1px dashed #2A3A52; border-radius:8px; }
QLabel#vfTkThumb { border:1px solid #2A3A52; border-radius:5px; }
QLabel#vfTkThumb:hover { border:1px solid #F87171; }
"""


class TicketDialog(QDialog):
    def __init__(self, iface, on_submit, parent=None):
        super().__init__(parent or iface.mainWindow())
        self.iface = iface
        self._on_submit = on_submit
        self._shots = []                       # list[bytes] (PNG)
        self.setWindowTitle("Log a ticket")
        self.setMinimumWidth(460)
        self.setStyleSheet(_QSS)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(8)

        t = QLabel("🎫  Log a ticket")
        t.setStyleSheet("font-size:16px; font-weight:800;")
        lay.addWidget(t)
        hint = QLabel("Report a bug or request a feature — it goes straight to the "
                      "planning office.")
        hint.setObjectName("vfTkHint")
        hint.setWordWrap(True)
        lay.addWidget(hint)
        lay.addSpacing(4)

        lay.addWidget(self._lbl("TYPE"))
        self.kind = QComboBox()
        self.kind.addItems(["🐞  Bug — something is broken or wrong",
                            "💡  Feature — something I'd like built"])
        lay.addWidget(self.kind)

        lay.addWidget(self._lbl("TITLE"))
        self.title = QLineEdit()
        self.title.setPlaceholderText("Short summary (e.g. 'Span check misses drop cables')")
        self.title.setMaxLength(140)
        lay.addWidget(self.title)

        lay.addWidget(self._lbl("DETAILS"))
        self.body = QPlainTextEdit()
        self.body.setPlaceholderText("What happened, the steps to reproduce, or exactly "
                                     "what you'd like the tool to do…")
        self.body.setMinimumHeight(110)
        lay.addWidget(self.body)

        # ── screenshots ──────────────────────────────────────────────────────
        sr = QHBoxLayout()
        sr.setContentsMargins(0, 0, 0, 0)
        sr.addWidget(self._lbl("SCREENSHOTS  (optional)"))
        sr.addStretch(1)
        paste = QPushButton("📋  Paste")
        paste.setObjectName("vfTkAttach")
        paste.setToolTip("Paste an image from the clipboard (Ctrl+V also works)")
        paste.clicked.connect(self._paste)
        sr.addWidget(paste)
        attach = QPushButton("📎  Attach…")
        attach.setObjectName("vfTkAttach")
        attach.setToolTip("Choose image file(s) to attach")
        attach.clicked.connect(self._attach)
        sr.addWidget(attach)
        lay.addLayout(sr)

        self._shots_box = QFrame()
        self._shots_box.setObjectName("vfTkShots")
        self._shots_box.setMinimumHeight(74)
        self._thumbs = QHBoxLayout(self._shots_box)
        self._thumbs.setContentsMargins(8, 8, 8, 8)
        self._thumbs.setSpacing(6)
        self._empty = QLabel("Paste a screenshot (Ctrl+V) or attach images — click a "
                             "thumbnail to remove it.")
        self._empty.setObjectName("vfTkHint")
        self._empty.setWordWrap(True)
        self._thumbs.addWidget(self._empty)
        self._thumbs.addStretch(1)
        lay.addWidget(self._shots_box)

        row = QHBoxLayout()
        row.addStretch(1)
        cancel = QPushButton("Cancel")
        cancel.setObjectName("vfTkCancel")
        cancel.clicked.connect(self.reject)
        row.addWidget(cancel)
        self.send = QPushButton("Send ticket  →")
        self.send.setObjectName("vfTkSend")
        self.send.setCursor(Qt.CursorShape.PointingHandCursor)
        self.send.clicked.connect(self._submit)
        row.addWidget(self.send)
        lay.addLayout(row)

    def _lbl(self, text):
        ll = QLabel(text)
        ll.setObjectName("vfTkLbl")
        return ll

    # ── screenshots ──────────────────────────────────────────────────────────
    def keyPressEvent(self, e):
        # Ctrl+V anywhere in the dialog pastes a clipboard image
        if (e.key() == Qt.Key.Key_V
                and (e.modifiers() & Qt.KeyboardModifier.ControlModifier)):
            if self._paste(quiet=True):
                return
        super().keyPressEvent(e)

    def _paste(self, quiet=False):
        cb = QApplication.clipboard()
        img = cb.image()
        if img is not None and not img.isNull():
            self._add_image(img)
            return True
        md = cb.mimeData()
        if md is not None and md.hasUrls():
            added = False
            for u in md.urls():
                p = u.toLocalFile()
                if p:
                    im = QImage(p)
                    if not im.isNull():
                        self._add_image(im)
                        added = True
            if added:
                return True
        if not quiet:
            QMessageBox.information(self, "Paste screenshot",
                                    "No image found on the clipboard. Take a screenshot "
                                    "(e.g. Win+Shift+S) first, then click Paste.")
        return False

    def _attach(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Attach screenshot(s)", "",
            "Images (*.png *.jpg *.jpeg *.bmp *.gif)")
        for p in paths or []:
            im = QImage(p)
            if not im.isNull():
                self._add_image(im)

    def _add_image(self, qimage):
        if len(self._shots) >= _MAX_SHOTS:
            QMessageBox.information(self, "Screenshots",
                                    f"You can attach up to {_MAX_SHOTS} images per ticket.")
            return
        # downscale very large grabs so uploads stay small (max 1600px wide)
        if qimage.width() > 1600:
            qimage = qimage.scaledToWidth(1600, Qt.TransformationMode.SmoothTransformation)
        ba = QByteArray()
        buf = QBuffer(ba)
        buf.open(QIODevice.OpenModeFlag.WriteOnly)
        qimage.save(buf, "PNG")
        buf.close()
        self._shots.append(bytes(ba))
        self._rebuild_thumbs()

    def _rebuild_thumbs(self):
        # clear
        while self._thumbs.count():
            it = self._thumbs.takeAt(0)
            w = it.widget()
            if w is not None:
                w.deleteLater()
        if not self._shots:
            self._thumbs.addWidget(self._empty)
            self._empty.show()
            self._thumbs.addStretch(1)
            return
        for i, data in enumerate(self._shots):
            pix = QPixmap()
            pix.loadFromData(data, "PNG")
            thumb = QLabel()
            thumb.setObjectName("vfTkThumb")
            thumb.setPixmap(pix.scaled(82, 56, Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation))
            thumb.setToolTip("Click to remove")
            thumb.setCursor(Qt.CursorShape.PointingHandCursor)
            thumb.mousePressEvent = lambda _e, idx=i: self._remove_shot(idx)
            self._thumbs.addWidget(thumb)
        self._thumbs.addStretch(1)

    def _remove_shot(self, idx):
        if 0 <= idx < len(self._shots):
            self._shots.pop(idx)
            self._rebuild_thumbs()

    # ── submit ─────────────────────────────────────────────────────────────--
    def _submit(self):
        title = self.title.text().strip()
        if not title:
            QMessageBox.information(self, "Log a ticket",
                                    "Please add a short title so it's easy to triage.")
            return
        payload = {
            "kind": "bug" if self.kind.currentIndex() == 0 else "feature",
            "title": title,
            "body": self.body.toPlainText().strip(),
            "_shots": list(self._shots),     # plugin uploads these, then drops the key
        }
        self.send.setEnabled(False)
        self.send.setText("Sending…")
        QApplication.processEvents()
        try:
            ok = self._on_submit(payload)
        except Exception:
            ok = False
        if ok is not False:
            QMessageBox.information(self, "Ticket sent",
                                    "Thanks! Your ticket was sent to the planning office. ✓")
            self.accept()
        else:
            QMessageBox.warning(self, "Log a ticket",
                                "Couldn't reach the server right now — your ticket is "
                                "saved and will send automatically when you're back online.")
            self.accept()
