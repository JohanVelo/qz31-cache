"""project_snapshot — a project backup you can PROVE restores.

`project_backup.py` already zips every file behind every layer, and it already
gets the hard part right: all shapefile sidecars, and a loud failure when a file
is dropped (a restored shapefile whose .dbf went missing opens with the right
feature count, the right geometry, and silently no attributes). That module is
wired to the "Back up Project" button and to the labeling wizard, and nothing
here changes it.

What it does not do is prove anything. It reports how many files it wrote, not
whether what it wrote still matches what it read. This module adds the half that
makes a backup a safety net rather than a hope:

    snapshot()  copy every source file, recording a SHA-256 per file
    verify()    re-hash the stored copies and compare against the manifest
    restore()   copy back out, then hash the RESTORED files, not the stored ones
    prune()     keep the N newest snapshots of a project, delete the rest

Four deliberate choices:

* **Plain files, not an archive.** A snapshot is a folder of ordinary files plus
  a manifest. It costs disk that a zip would save, but it means a restore is a
  copy, a verification is a hash, and — the point — if every tool in this repo is
  broken, JJ can still recover the project by dragging a folder in Explorer.

* **Stored names are content-addressed** (`<sha256[:12]>_<basename>`). Two layers
  in different folders that share a basename cannot collide, because different
  content yields a different prefix; two byte-identical files deduplicate onto
  one stored copy. No counter loop, no silent overwrite.

* **`restore()` never writes to the original paths.** It takes an explicit
  destination. Restoring over live data is a different, louder operation than
  checking that a restore would work, and conflating the two is how a
  verification step becomes an incident.

* **`prune()` can only ever delete a directory that proves it is a snapshot** —
  see `_is_prunable_snapshot`. This module is the rollback path for a tool that
  rewrites layers, so the one function in it that deletes anything is the last
  place to rely on callers passing the right argument.

Pure stdlib. No QGIS import at module level, so the whole thing is testable in
the venv without a QGIS process.
"""
from __future__ import annotations

import datetime
import hashlib
import json
import os
import shutil

# Decision (JJ, 2026-09-11): local disk, OUTSIDE OneDrive. OneDrive-backed paths
# sync every snapshot to the cloud, stall on large writes, and can hand back a
# placeholder instead of the file — none of which a rollback path can afford.
DEFAULT_ROOT = "C:/VelocityNexus/snapshots"

# Decision (JJ, 2026-09-11): keep the last 5 runs per project.
DEFAULT_KEEP = 5

MANIFEST_NAME = "manifest.json"
DATA_DIR = "data"
MANIFEST_VERSION = 1

_CHUNK = 1 << 20


def sha256_file(path):
    """Hash a file in chunks — these run to hundreds of MB."""
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(_CHUNK), b""):
            h.update(block)
    return h.hexdigest()


def _safe_name(name):
    """Strip anything that cannot be a Windows path segment.

    Project names reach this from `QgsProject.baseName()`, which is whatever the
    user typed. A colon or a slash in there would otherwise scatter the snapshot
    across directories, or fail the write outright.
    """
    out = "".join("_" if c in '<>:"/\\|?*' else c for c in str(name)).strip(" .")
    return out or "unnamed_project"


def sources_from_project(project):
    """Every on-disk file backing the open project, via the existing collector.

    Imported lazily and by several names because this package is loaded three
    different ways (installed plugin, workspace copy, bare sys.path) and a
    module-level import would make the whole file unimportable in the venv.
    """
    try:
        from .project_backup import collect_sources
    except ImportError:
        try:
            from fibre_automation.project_backup import collect_sources
        except ImportError:
            from project_backup import collect_sources
    return sorted(collect_sources(project))


def unsaveable_layers(project):
    """Layers in the project that NO file-based backup can capture.

    Measured on Lulekani, 2026-09-11: four of its layers — `PON Drop Cables`,
    `PON Groups`, `PON Splitter Points` and `PON Zone Boundaries` — are memory
    layers, and `Overbuild` points at a file that is no longer there. Those four
    are precisely the layers a benchmark most wants to standardise, and they die
    when QGIS closes.

    `collect_sources` skips them, correctly — there is nothing on disk to copy.
    The bug is what happens next: the backup then reports success, so a snapshot
    that is missing the four most important layers looks identical to a complete
    one. Anything that rewrites layers must call this FIRST and refuse to
    proceed while the list is non-empty, because the rollback it is relying on
    does not cover them.

    Returns a list of `{"name", "provider", "reason"}`, empty when every layer
    is backed by a real file.
    """
    out = []
    for lyr in project.mapLayers().values():
        try:
            provider = lyr.dataProvider().name()
        except Exception:
            provider = "?"
        try:
            name = lyr.name()
            src = lyr.source().split("|")[0]
        except Exception:
            continue
        if provider in ("wms", "wcs", "xyz"):
            continue          # basemaps are not project data; nothing to lose
        if provider == "memory":
            out.append({"name": name, "provider": provider,
                        "reason": "scratch layer — exists only in RAM and is "
                                  "lost when QGIS closes"})
        elif src and not os.path.isfile(src.split("?")[0]):
            out.append({"name": name, "provider": provider,
                        "reason": "source file is missing: %s" % src})
    return out


def snapshot(files, project_name, root=DEFAULT_ROOT, keep=DEFAULT_KEEP,
             label=None, feedback=None):
    """Copy `files` into a new timestamped snapshot and hash every one.

    Returns a dict carrying the snapshot directory, the file count, the byte
    total, the elapsed seconds, and `ok`. `ok` is False if ANY file failed to
    copy — a partial snapshot must never read as success, for the same reason
    the zip backup fails loudly on a dropped sidecar.
    """
    started = datetime.datetime.now()
    stamp = started.strftime("%Y%m%d_%H%M%S")
    proj = _safe_name(project_name)

    snap_dir = os.path.join(root, proj, stamp if not label
                            else "%s_%s" % (stamp, _safe_name(label)))
    data_dir = os.path.join(snap_dir, DATA_DIR)
    os.makedirs(data_dir, exist_ok=True)

    entries, failed, total = [], [], 0
    files = [f for f in files if f]
    for i, src in enumerate(files):
        try:
            digest = sha256_file(src)
            stored = "%s_%s" % (digest[:12], os.path.basename(src))
            dst = os.path.join(data_dir, stored)
            # Identical content under an identical basename lands on the same
            # stored name. Copying it twice is wasted IO, not a conflict.
            if not os.path.exists(dst):
                shutil.copy2(src, dst)
            size = os.path.getsize(src)
            entries.append({"stored": stored, "original": src.replace("\\", "/"),
                            "sha256": digest, "bytes": size})
            total += size
        except Exception as exc:
            failed.append("%s (%s)" % (os.path.basename(src), type(exc).__name__))
        if feedback is not None:
            try:
                feedback.setProgress(int((i + 1) / max(1, len(files)) * 100))
            except Exception:
                pass

    elapsed = (datetime.datetime.now() - started).total_seconds()
    manifest = {
        "version": MANIFEST_VERSION,
        "project": str(project_name),
        "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "elapsed_s": round(elapsed, 2),
        "files": entries,
        "failed": failed,
    }
    with open(os.path.join(snap_dir, MANIFEST_NAME), "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=1)

    pruned = []
    if keep and not failed:
        # Only prune after a CLEAN snapshot. Pruning on the back of a partial one
        # would delete good history to make room for a broken replacement.
        pruned = prune(root, project_name, keep=keep)

    return {"dir": snap_dir, "files": len(entries), "bytes": total,
            "elapsed_s": round(elapsed, 2), "failed": failed,
            "pruned": pruned, "ok": bool(entries) and not failed,
            "msg": None if not failed else
            "snapshot INCOMPLETE — %d file(s) could not be copied: %s. "
            "Do not rely on it." % (len(failed), ", ".join(failed[:5]))}


def read_manifest(snap_dir):
    with open(os.path.join(snap_dir, MANIFEST_NAME), encoding="utf-8") as fh:
        return json.load(fh)


def verify(snap_dir):
    """Re-hash every stored file and compare it to the manifest.

    This is the check that makes the snapshot worth having, so it reports which
    files are wrong rather than a bare boolean: `missing` for a stored copy that
    is gone, `mismatch` for one whose bytes have changed.
    """
    try:
        manifest = read_manifest(snap_dir)
    except Exception as exc:
        return {"ok": False, "checked": 0, "missing": [], "mismatch": [],
                "total": 0, "msg": "manifest unreadable: %s" % exc}

    data_dir = os.path.join(snap_dir, DATA_DIR)
    missing, mismatch, checked = [], [], 0
    for e in manifest.get("files", []):
        path = os.path.join(data_dir, e["stored"])
        if not os.path.isfile(path):
            missing.append(e["original"])
            continue
        checked += 1
        if sha256_file(path) != e["sha256"]:
            mismatch.append(e["original"])

    ok = not missing and not mismatch and checked > 0
    return {"ok": ok, "checked": checked, "missing": missing,
            "mismatch": mismatch, "total": len(manifest.get("files", [])),
            "msg": None if ok else
            "snapshot FAILED verification — %d missing, %d corrupted"
            % (len(missing), len(mismatch))}


def restore(snap_dir, dest, flat=False):
    """Copy a snapshot back out to `dest`, then hash what was WRITTEN.

    Verifying the stored copies proves the snapshot is intact; it does not prove
    a restore produces the original bytes. This hashes the restored files
    themselves, which is the claim that actually matters.

    `dest` is required and is never the original location — see the module
    docstring. `flat=True` drops everything into one directory under its original
    basename, which is what a human recovering by hand wants; the default
    rebuilds the original folder layout beneath `dest`.
    """
    manifest = read_manifest(snap_dir)
    data_dir = os.path.join(snap_dir, DATA_DIR)
    os.makedirs(dest, exist_ok=True)

    written, failed, bad = [], [], []
    for e in manifest.get("files", []):
        src = os.path.join(data_dir, e["stored"])
        if flat:
            out = os.path.join(dest, os.path.basename(e["original"]))
        else:
            # Rebuild the original tree under dest, with the drive letter turned
            # into a plain folder so the path stays relative to dest.
            rel = e["original"].replace(":", "", 1).lstrip("/")
            out = os.path.join(dest, rel)
        try:
            os.makedirs(os.path.dirname(out), exist_ok=True)
            shutil.copy2(src, out)
        except Exception as exc:
            failed.append("%s (%s)" % (os.path.basename(e["original"]),
                                       type(exc).__name__))
            continue
        if sha256_file(out) != e["sha256"]:
            bad.append(e["original"])
        written.append(out)

    ok = bool(written) and not failed and not bad
    return {"ok": ok, "restored": len(written), "dest": dest,
            "failed": failed, "mismatch": bad,
            "msg": None if ok else
            "restore FAILED — %d could not be written, %d differ from the "
            "original bytes" % (len(failed), len(bad))}


def list_snapshots(root, project_name):
    """Snapshot directories for one project, NEWEST FIRST."""
    proj_dir = os.path.join(root, _safe_name(project_name))
    if not os.path.isdir(proj_dir):
        return []
    names = [n for n in os.listdir(proj_dir)
             if os.path.isdir(os.path.join(proj_dir, n))]
    # The directory name starts with a sortable timestamp, so a plain reverse
    # sort is newest-first without stat()-ing anything. mtime would be wrong
    # here: copying or restoring a snapshot folder rewrites it.
    return [os.path.join(proj_dir, n) for n in sorted(names, reverse=True)]


def _is_prunable_snapshot(path, root):
    """True only for a directory that is demonstrably one of OUR snapshots.

    Three independent conditions, all required. This is the only delete in the
    module, and it is the rollback path for a tool whose whole job is rewriting
    layers, so it does not get to trust its caller:

      1. the path resolves to somewhere strictly BENEATH `root`
      2. it is a real directory, not a symlink pointing out of the tree
      3. it carries a readable manifest naming files we wrote

    A directory failing any of them is left alone. Refusing to prune costs disk
    space; pruning the wrong directory costs data.
    """
    try:
        real_root = os.path.realpath(root)
        real_path = os.path.realpath(path)
    except OSError:
        return False
    if os.path.islink(path) or not os.path.isdir(real_path):
        return False
    if os.path.commonpath([real_root, real_path]) != real_root:
        return False
    if real_path == real_root:
        return False
    manifest = os.path.join(real_path, MANIFEST_NAME)
    if not os.path.isfile(manifest):
        return False
    try:
        with open(manifest, encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return False
    return data.get("version") == MANIFEST_VERSION and "files" in data


def prune(root, project_name, keep=DEFAULT_KEEP):
    """Delete all but the `keep` newest snapshots of one project.

    Every candidate must pass `_is_prunable_snapshot` first; anything that does
    not is skipped and reported, never deleted.
    """
    if keep is None or keep < 1:
        return []
    snaps = list_snapshots(root, project_name)
    removed, refused = [], []
    for old in snaps[keep:]:
        if not _is_prunable_snapshot(old, root):
            refused.append(old)
            continue
        try:
            # claude:approved-destructive — bounded by _is_prunable_snapshot
            # above: strictly beneath the snapshot root, not a symlink, and
            # carrying a manifest this module wrote. Deletes snapshot history
            # only; it can never reach a project, a layer or a source file.
            shutil.rmtree(old)
            removed.append(old)
        except OSError:
            # A snapshot we cannot delete is a disk-space problem, never a
            # reason to fail the snapshot that just succeeded.
            refused.append(old)
    return removed
